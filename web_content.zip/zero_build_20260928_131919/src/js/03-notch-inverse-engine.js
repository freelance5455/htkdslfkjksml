/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 03-notch-inverse-engine.js
 مرشحات Notch + محرك الموجة المعاكسة (INV/buildInverse) + المحرك الرئيسي toggleAI + لوحات Sheet/Pipe الأساسية
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */
const SESSION_STAT={startT:0,hopCount0:0,envCount:{},notchPeak:0,suppEffSum:0,suppEffN:0};
let notchDecayT=null;
const PEAKS_DATA={peaks:[],lastT:0,maxPeaks:5};
const SQI={val:0,kfConf:0,suppEff:0,envStab:0,hopPenalty:0};
const NOTCH_SUGGEST={hz:0,count:0,threshold:5,shown:false,toastT:0,_toastTimer:null};
// Dev110 globals
const SQI_HIST={vals:[],maxLen:60}; // ~1 min rolling at ~1s update
const FREQ_ALARMS=new Map(); // key=fBin(hz), val={hz,tol,count,lastTrigT,cooldown,enabled}
const BAND_POWER={BANDS:[{lo:20,hi:63,lbl:'20'},{lo:63,hi:125,lbl:'63'},{lo:125,hi:250,lbl:'125'},{lo:250,hi:500,lbl:'250'},{lo:500,hi:1000,lbl:'500'},{lo:1000,hi:2000,lbl:'1k'},{lo:2000,hi:4000,lbl:'2k'},{lo:4000,hi:8000,lbl:'4k'},{lo:8000,hi:20000,lbl:'8k'}],vals:new Float32Array(9)};
const SPEC_DELTA={baseline:null,baseT:0,bHz:0.5};
let lastFFD=null; // last Float32Array FFT frame — for DELTA baseline compare
// Dev120 globals
const KF_LOCK={enabled:false,hz:0,tol:15}; // constrain KF tracking to target ±tol Hz
const ADAPTIVE_ALERT={enabled:false,warnSQI:50,critSQI:25,warnHops:5,level:'ok',lastT:0,cooldown:8000};
const REC={active:false,buf:[],maxLen:3000,startT:0}; // 3000×40ms ≈ 2 min recording

function activateNotch(hz,_order){
 // تشديد أكثر: نفس فئة خلل NaNHz لكن في قائمة NOTCH — نقطتا نقر الطيف/الخط الزمني
 // (initCanvasTap) تحسبان hz=pct*nyq حيث pct=x/rect.width؛ لو كانت rect.width=0 (عنصر
 // Canvas لم يُخطَّط بعد، سيناريو واقعي جداً عند نقر سريع فور فتح لوحة) فإن x/0 قد تُنتِج
 // NaN، والشرط القديم في تلك الدالتين كان hz<1 فقط — وهذا لا يرفض NaN إطلاقاً (أي مقارنة
 // بـNaN تُقيَّم false)! التحصين الأضمن هنا في نقطة الدخول المشتركة لكل نداءات activateNotch.
 if(!hz||!isFinite(hz)||hz<1)return;
 const k=fBin(hz);if(NOTCH_SUPPRESS.has(k))return;
 if(_order>1&&actx&&hz>actx.sampleRate/2)return; // harmonic out of Nyquist
 const e=freqDB.get(k);const cls=e?e.class:5;
 // Tonal classes (C1/C2) → narrow notch; broadband/unknown → wider
 const halfBins=cls<=2?2:cls===5?3:4;
 const depth=cls<=2?40:32;
 const order=_order||1;
 NOTCH_SUPPRESS.set(k,{hz,depth,halfBins,lastHit:Date.now(),order});
 // Auto harmonic chain — add 2f, 3f … if enabled
 if(NOTCH_HARM.enabled&&order===1){
 const nyq=actx?actx.sampleRate/2:20000;
 for(let n=2;n<=NOTCH_HARM.maxOrder;n++){const hHz=hz*n;if(hHz<nyq)activateNotch(hHz,n);}
 }
 updateNotchUI();
}

function deactivateNotch(hz){
 NOTCH_SUPPRESS.delete(fBin(hz));
 updateNotchUI();
}

function updateNotchUI(){
 const nc=E('notch-count');const nl=E('notch-list');
 if(nc)nc.textContent=NOTCH_SUPPRESS.size;
 if(NOTCH_SUPPRESS.size>SESSION_STAT.notchPeak)SESSION_STAT.notchPeak=NOTCH_SUPPRESS.size;
 if(!nl)return;
 if(!NOTCH_SUPPRESS.size){
 nl.innerHTML='<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">No confirmed freqs yet — فور التأكيد يُنشأ notch تلقائياً</div>';
 return;
 }
 const rows=[];
 // خط دفاع أخير (مثل renderBanList/renderPermSettings): استبعاد أي hz غير منتهٍ حتى لو
 // تسرَّب من مسار غير متوقَّع — activateNotch نفسها مُحصَّنة الآن فهذا احتياطي بحت
 NOTCH_SUPPRESS.forEach(({hz,depth,halfBins,order})=>{
 if(typeof hz!=='number'||!isFinite(hz))return;
 const hTag=order>1?`<span style="color:var(--muted);font-size:7px;margin-left:3px">×${order}</span>`:'';
 rows.push(`<div class="notch-item"><span class="notch-hz"> ${hz.toFixed(1)} Hz${hTag}</span><span class="notch-meta">-${depth}dB · ±${halfBins}bin</span><button class="notch-rm" onclick="deactivateNotch(${hz})">✕</button></div>`);
 });
 nl.innerHTML=rows.join('');
}

/* ══════════════════════════════════════════════
 MINI SPECTROGRAM — rolling FFT waterfall
══════════════════════════════════════════════ */
const specHistory=[];
const SPEC_MAX_ROWS=40;

function pushSpecFrame(fd8){
 // fd8 = Uint8Array from ana.getByteFrequencyData
 specHistory.push(fd8);
 if(specHistory.length>SPEC_MAX_ROWS)specHistory.shift();
}

function drawMiniSpec(){
 const cv=E('specCv');if(!cv)return;
 const W=cv.clientWidth||300;const H=48;
 if(cv.width!==W*window.devicePixelRatio){cv.width=Math.round(W*(window.devicePixelRatio||1));cv.height=Math.round(H*(window.devicePixelRatio||1));}
 const ctx=cv.getContext('2d');if(!ctx)return;
 const cW=cv.width,cH=cv.height;
 const rows=specHistory.length;if(!rows)return;
 const rowH=cH/SPEC_MAX_ROWS;
 const img=ctx.createImageData(cW,cH);
 const d=img.data;
 for(let ri=0;ri<rows;ri++){
 const frame=specHistory[ri];
 const yBase=Math.round((SPEC_MAX_ROWS-1-ri)*rowH); // newest at bottom
 const yEnd=Math.round((SPEC_MAX_ROWS-ri)*rowH);
 for(let xi=0;xi<cW;xi++){
 const fi=Math.floor(xi/cW*frame.length);
 const v=fi<frame.length?frame[fi]:0;
 // heat map: cold-blue → cyan → green → yellow → red
 let r,g,b;
 if(v<64){r=0;g=0;b=v*4;}
 else if(v<128){r=0;g=(v-64)*4;b=255-(v-64)*4;}
 else if(v<192){r=(v-128)*4;g=255;b=0;}
 else{r=255;g=255-(v-192)*4;b=0;}
 for(let y=yBase;y<yEnd&&y<cH;y++){
 const idx=(y*cW+xi)*4;
 d[idx]=r;d[idx+1]=g;d[idx+2]=b;d[idx+3]=220;
 }
 }
 }
 ctx.putImageData(img,0,0);
 // Overlay confirmed-notch frequency markers
 if(NOTCH_SUPPRESS.size>0&&ana&&actx){
 const bHz=actx.sampleRate/ana.fftSize;
 ctx.strokeStyle='rgba(165,165,165,0.75)';ctx.lineWidth=1;ctx.setLineDash([3,3]);
 NOTCH_SUPPRESS.forEach(({hz})=>{
 const x=Math.round(hz/bHz/specHistory[0].length*cW);
 if(x>=0&&x<cW){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,cH);ctx.stroke();}
 });
 ctx.setLineDash([]);
 }
}

function fBin(hz){return Math.round(hz/0.5)*0.5;}

function fRecord(hz,energy){
 if(!hz||hz<0.01)return;
 if(AI_GATE.enabled&&AI_BAN.has(fBin(hz))){trackPostBanDetection(hz,energy);return;} // banned — track & skip
 const bin=fBin(hz),now=Date.now();
 if(freqDB.has(bin)){
 const e=freqDB.get(bin);e.count++;e.energy=e.energy*.8+energy*.2;e.lastSeen=now;
 if(e.count===FREQ_THRESH&&!e.confirmed){
 e.confirmed=true;freqFile.totalConf++;
 if(P.useInv)buildInverse(hz,energy,e);
 activateNotch(hz);
 logNN(' Confirmed: '+hz.toFixed(2)+'Hz (×'+e.count+') → notch+inverse queued');
 }
 }else{
 freqDB.set(bin,{hz:bin,count:1,energy,firstSeen:now,lastSeen:now,confirmed:false,cancelled:false,invHz:null,invOk:false,class:0});
 freqFile.totalCap++;
 }
 writeFreqFile();
}

function fPurge(){const now=Date.now();freqDB.forEach((v,k)=>{if(now-v.lastSeen>30000&&!v.confirmed)freqDB.delete(k);});}

// مراجعة سابعة ضمن إصلاح "الوميض/التجمّد المؤقت عند فتح التطبيق وتبديل القوائم": هذه
// الدالة تُستدعى من fRecord() — أي في كل دورة detectAll تقريباً (حتى 25 مرة/ثانية) طوال
// تشغيل المحرك — وكانت تُعيد فرز **كامل** freqDB (Map ينمو بلا سقف طوال الجلسة: كل تردد
// "مؤكَّد" لا يُحذَف منه أبداً حتى لو صمت لاحقاً — fPurge() تحذف فقط غير المؤكَّد بعد 30
// ثانية صمت) من الصفر في كل مرة. مع تقدّم الجلسة (بيئة صاخبة، جلسة طويلة)، freqDB قد
// يتجاوز المئات أو الآلاف من الإدخالات — فتكلفة هذا الفرز (O(n log n)) تتصاعد كلما طالت
// مدة الاستخدام، بالضبط نمط "الأداء يزداد سوءاً بمرور الوقت"، ويحدث على نفس الخيط
// الرئيسي الوحيد الذي يُعالج أيضاً أي تفاعل واجهة لحظي (بما فيه فتح/تبديل القوائم).
// الإصلاح: تحديد تحديث النسخة المُرتَّبة (freqFile.entries، المُستخدَمة للعرض والتصدير
// فقط) بمعدّل معقول (~250ms) بدل كل دورة على حدة — freqDB نفسها (مصدر الحقيقة الحي)
// تبقى محدَّثة فوراً في fRecord() كما كانت تماماً بلا أي تغيير؛ فارق التأخير (أقل من ربع
// ثانية) غير مُدرَك إطلاقاً سواء في العرض الحي أو في تصدير يدوي يُطلقه المستخدم لاحقاً.
let _lastFreqFileWrite=0;
function writeFreqFile(){
 const now=Date.now();
 if(now-_lastFreqFileWrite<250)return;
 _lastFreqFileWrite=now;
 freqFile.entries=[...freqDB.values()].sort((a,b)=>b.count-a.count).slice(0,100);
 updateFreqUI();
}

/* ══════════════════════════════════
 INVERSE GENERATOR
 Confirmed freq → build anti-phase.
 Verify via mic → anti-search if fail.
══════════════════════════════════ */
const INV={active:new Map(),failed:new Map(),maxTry:5,verMs:800};

function buildInverse(hz,energy,dbEntry){
 // تشديد أكثر: hz<0.01 وحدها لا ترفض NaN — لو وصل NaN هنا فسيُمرَّر إلى
 // osc.frequency.value/dly.delayTime.value، وضبط AudioParam بقيمة NaN يرمي استثناءً
 // في محرّك الصوت الحقيقي (لا مجرد "NaNHz" في العرض، بل توقّف فعلي لدورة الكشف)
 if(!hz||!isFinite(hz)||hz<0.01||!actx||INV.active.has(hz))return;
 if(AI_GATE.enabled&&AI_BAN.has(fBin(hz))){trackPostBanDetection(hz,energy);return;} // AI banned — track & skip
 // متابعة تقرير "يتجمد أثناء التشغيل" — خلافاً لكل خريطة مماثلة في الملف (HEBBIAN وBAN_VOTE
 // بسقف 500، NOTCH_SUPPRESS محمية بـ NOTCH_DECAY)، لم يكن لـ INV.active أي سقف أو تنظيف دوري
 // إطلاقاً. verifyInv() عند النجاح تضع verified=true فقط ولا تحذف الإدخال أبداً — فيبقى
 // osc.start() الحقيقي المتّصل بـ actx.destination يعمل للأبد. عبر جلسة طويلة، انجراف Kalman
 // الطبيعي للضوضاء الفيزيائية (مروحة، دندنة كهرومغناطيسية...) عبر خانات fBin (0.5Hz) متجاورة
 // يجعل كل خانة جديدة تُؤكَّد تُنشئ oscillator/gain دائمَين إضافيَّين — تراكم غير محدود لموارد
 // صوت حيّة فعلية عبر الوقت (لا عبر الضغط المتكرر)، يثقل معالجة الصوت تدريجياً حتى التجمّد —
 // يطابق تماماً وصف المستخدم: "يتجمد أثناء التشغيل" لا فور الضغط. الإصلاح: سقف بنفس أسلوب
 // HEBBIAN/BAN_VOTE، مع إيقاف/فصل الأوسيلاتور الأقدم فعلياً (لا مجرد حذف إدخال الخريطة).
 if(INV.active.size>=40){
 const oldestKey=INV.active.keys().next().value;
 const oldest=INV.active.get(oldestKey);
 if(oldest){try{oldest.osc.stop();oldest.g.disconnect();}catch(e){}}
 INV.active.delete(oldestKey);
 }
 const osc=actx.createOscillator(),g=actx.createGain(),dly=actx.createDelay(0.5);
 osc.type='sine';osc.frequency.value=hz;
 // Phase inversion via half-period delay
 const halfPeriod=Math.min(1/(hz*2),0.5);
 dly.delayTime.value=halfPeriod;
 // Gain: inaudible for audible freqs, physical for sub/ultra
 g.gain.value=(hz<20||hz>20000)?energy*.12:energy*.025;
 osc.connect(dly);dly.connect(g);g.connect(actx.destination);
 osc.start();
 INV.active.set(hz,{osc,g,dly,attempts:1,verified:false,t:Date.now(),hz,energy});
 dbEntry.invHz=hz;
 setTimeout(()=>verifyInv(hz,dbEntry),INV.verMs);
 updateInvUI();
}

// تشديد: أي إبطال صوتي (inverse) نشط فعلاً على السماعة لتردد ما، لحظة أن يُحظر هذا التردد
// عبر أي مسار (تعب/تصويت/تباطؤ — وليس فقط banFreq/autoDetectAndBan اللذين كانا يوقفانه فعلاً)
// يجب إيقافه فوراً؛ وإلا يستمر صوت الإبطال بالتشغيل من السماعة رغم أن التردد أصبح محظوراً
function stopActiveInverse(hz){
 // تشديد: مطابقة بالصندوق (fBin) لا بالقيمة الخام — hz الوارد هنا (من updateFreqFatigue/
 // castBanVote/monitorSlugFreqs/escalateInterferenceZone/banFreq/autoDetectAndBan) هو تردد
 // اللحظة الحالية (قد يكون متذبذباً قليلاً بفعل Kalman) بينما مفتاح INV.active المخزَّن هو
 // القيمة الخام وقت buildInverse الأصلي — قد يختلفان بكسور هرتز فتفشل مطابقة hz===hz
 // الحرفية صامتة ويستمر صوت الإبطال بالتشغيل رغم الحظر. المطابقة بـfBin تضمن الإيقاف دائماً.
 const bin=fBin(hz);let stopped=false;
 INV.active.forEach((inv,key)=>{
 if(fBin(key)===bin){
 try{inv.osc.stop();inv.g.disconnect();}catch(e){}
 INV.active.delete(key);
 stopped=true;
 }
 });
 if(stopped)updateInvUI();
}

function verifyInv(hz,dbEntry){
 if(!INV.active.has(hz))return;
 const inv=INV.active.get(hz);
 const bin=fBin(hz);const dbE=freqDB.get(bin);
 // Check mic — if freq gone, inverse worked
 if(!dbE||dbE.count===0||dbE.energy<0.01){
 inv.verified=true;dbEntry.cancelled=true;dbEntry.invOk=true;
 freqFile.totalCanc++;writeFreqFile();
 logNN('✓ CANCELLED: '+hz.toFixed(2)+'Hz — inverse success');
 nnTrain(nnInp(),0.9);return;
 }
 if(inv.attempts<INV.maxTry){inv.attempts++;antiSearch(hz,inv,dbEntry);}
 else{
 logNN('✗ FAILED: '+hz.toFixed(2)+'Hz — switching to anti-pattern search');
 nnTrain(nnInp(),-0.4);
 doAntiPattern(hz,inv,dbEntry);
 }
}

function antiSearch(hz,inv,dbEntry){
 // Rotate phase in 22.5° steps
 const prev=INV.failed.get(hz)||{phase:Math.PI};
 const newPhase=prev.phase+(Math.PI/8);
 if(inv.dly){inv.dly.delayTime.value=Math.min((newPhase/(2*Math.PI))/hz,0.5);}
 inv.osc.frequency.value=hz+(hz*0.001*inv.attempts);
 INV.failed.set(hz,{phase:newPhase});
 logNN('⟳ Anti-search: '+hz.toFixed(2)+'Hz φ='+(newPhase*180/Math.PI).toFixed(0)+'°');
 setTimeout(()=>verifyInv(hz,dbEntry),INV.verMs*1.5);
}

function doAntiPattern(hz,inv,dbEntry){
 // Search harmonic neighbors: if hz repeats and inverse fails, try related freqs
 const cands=[hz/2,hz*1.5,hz/3,hz*2].filter(f=>f>0.01&&f<(actx?actx.sampleRate/2:24000));
 cands.forEach((cf,i)=>{
 setTimeout(()=>{
 if(!INV.active.has(hz))return;
 INV.active.get(hz).osc.frequency.value=cf;
 logNN('↩ Anti-pattern: '+hz.toFixed(2)+'Hz → trying '+cf.toFixed(2)+'Hz');
 setTimeout(()=>{const bin=fBin(hz);const d=freqDB.get(bin);if(!d||d.energy<0.01){logNN('✓ Anti-pattern SUCCESS via '+cf.toFixed(2)+'Hz');nnTrain(nnInp(),.7);}},INV.verMs);
 },i*600);
 });
}

/* ══ MIC PROFILE ══ */
const MIC={sr:0,nyq:0,fftRes:0,minDet:0,maxDet:0,dynRange:0,latMs:0,feat:{cent:0,zcr:0,crest:0,flat:0,hnr:0}};

function profileMic(){
 if(!actx||!ana)return;
 MIC.sr=actx.sampleRate;MIC.nyq=actx.sampleRate/2;
 MIC.fftRes=actx.sampleRate/ana.fftSize;
 MIC.minDet=MIC.fftRes;MIC.maxDet=MIC.nyq;
 MIC.dynRange=Math.abs(ana.maxDecibels-ana.minDecibels);
 MIC.latMs=((actx.baseLatency||0)+(actx.outputLatency||0))*1000;
 updateMicUI();logNN(' Mic profiled: '+MIC.sr/1000+'kHz · '+MIC.fftRes.toFixed(3)+'Hz/bin · '+MIC.dynRange+'dB');
}

function extractFeat(td,fd,bHz){
 const N=td.length,M=Math.min(fd.length,4096);
 let sw=0,s=0;for(let i=1;i<M;i++){const p=Math.pow(10,fd[i]/10);sw+=i*bHz*p;s+=p;}
 MIC.feat.cent=s>0?sw/s:0;
 let zc=0;for(let i=1;i<N;i++){if((td[i-1]-128)*(td[i]-128)<0)zc++;}MIC.feat.zcr=zc/N;
 let pk=0,rv=0;for(let i=0;i<N;i++){const v=Math.abs(td[i]-128)/128;if(v>pk)pk=v;rv+=v*v;}
 rv=Math.sqrt(rv/N);MIC.feat.crest=rv>0?pk/rv:0;
 let ls=0,as2=0;for(let i=1;i<M;i++){const p=Math.max(1e-12,Math.pow(10,fd[i]/10));ls+=Math.log(p);as2+=p;}
 MIC.feat.flat=as2>0?Math.exp(ls/(M-1))/(as2/(M-1)):0;
 MIC.feat.hnr=fanFreq>0?fanE/Math.max(noiseE,0.001):0;
}

/* ══ INIT ══ */
/* addMsg stub — chat tab replaced by EXEC; forward to exec log */
function addMsg(role, txt) {
 if(role==='bot'){
 // Convert markdown-like text to plain exec lines
 const lines = txt.replace(/\*\*/g,'').replace(/\*/g,'').split('\n').filter(l=>l.trim());
 logExec({prog:'SYS',lines:lines.slice(0,8),ms:0,auto:true});
 }
}
window.addEventListener('load',()=>{
 buildCoh(); // استدعاء bgLoop() (خلفية النجوم المتحركة) حُذف — أُزيلت الميزة بالكامل (28 سبتمبر 2026)
 // Load permanent bans immediately
 setTimeout(()=>{
 // ① استعادة حالة الفئات من PERSIST أولاً (قبل loadDefaultBans)
 PERSIST.loadCats();
 loadDefaultBans();
 },200);
 // Initial exec log message — show 8-class system info
 setTimeout(()=>{
 logExec({prog:'INIT',lines:[
 'ZERO AI v25 — Neural Intelligence',
 'C1⊕ Positive · C2⊖ Negative · C3∓ Neg→Pos · C4± Pos→Neg',
 'C5+ Mic-Detectable · C6- Mic-Invisible',
 'C7+ Spk-Emittable · C8- Spk-Blocked',
 'Neural Net 16→24→8 · FreqDB + Inverse Gen',
 ' حضر دائم: ترددات ضارة · صاخبة · mic (قابل للتعديل في الإعدادات)',
 'Type LIST for programs · Tap AI to begin',
 ],ms:0,auto:true});
 },0);
});

/* ══ UI STATE ══ */
function setS(st){
 app.classList.remove('s-on','s-off','s-zero');app.classList.add('s-'+st);
}

/* ══ TOGGLE ══ */
// إغلاق الفراغات: ضغط زر التشغيل/الإيقاف أكثر من مرة بسرعة (قبل اكتمال دورة startAll() السابقة)
// كان يُسبِّب تجمّد التطبيق فعلياً. السبب الجذري: initAudio() يتحقّق من `actx&&micStr` لتفادي
// إعادة التهيئة — لكن كلا المتغيّرين يبقيان null طوال مدة await navigator.mediaDevices.
// getUserMedia(...) (قد تستغرق مئات المللي ثانية). ضغطة تشغيل ثانية أثناء هذا الانتظار (حتى لو
// سبقتها ضغطة إيقاف بينهما) تتجاوز هذا الفحص وتبدأ طلب getUserMedia()+AudioContext جديداً كلياً
// بالتوازي — فيُصبح لدينا أكثر من AudioContext حي يعمل فعلياً في آن واحد. الأسوأ: عند اكتمال
// الطلبين، آخر واحد يكتمل يكتب فوق actx/micStr العامّين، فيضيع المرجع إلى الطلب الأقدم (الذي ظل
// حياً ويعمل) إلى الأبد — لا يمكن لاحقاً استدعاء actx.close()/micStr.getTracks().stop() عليه
// إطلاقاً. تكرار الضغط "أكثر من مرة" يراكم عدة سياقات صوت حيّة متروكة (كل واحد يستهلك المعالج
// والميكروفون فعلياً)، وهذا يُثقل الخيط الرئيسي في WebView أندرويد حتى يتجمّد التطبيق تماماً —
// بالضبط العرض المُبلَّغ عنه (تجمّد، تعذّر التمرير/التنقل).
// الإصلاح: حارس تكرار (_toggleBusy) يرفض أي ضغطة جديدة أثناء انتقال قيد التنفيذ فعلياً (سواء
// تشغيل أو إيقاف)، ويُعطِّل الزر نفسه أثناء ذلك كحماية مضاعفة على مستوى DOM — فلا يمكن لأي عدد
// من الضغطات المتكررة أن يُنشئ أكثر من طلب تهيئة صوت واحد أبداً.
// متابعة نفس تقرير المستخدم بعد التوضيح الإضافي: "1) لا يمكن التمرير 2) مدة فاصلة بين
// التشغيل والإيقاف 3) ضغطات يستجيب لها الزر وضغطات لا استجابة لها" — الحارس أعلاه (_toggleBusy)
// يمنع التجمّد الفعلي (١) بالفعل، لكن (٢) و(٣) كشفا عن مشكلتين حقيقيتين إضافيتين في toggleAI()
// نفسها لم تكونا موجودتين في initAudio():
// (أ) كانت الشيفرة تُحدِّث كل نصوص/ألوان الواجهة إلى حالة "يعمل الآن " فوراً وبشكل متزامن —
// قبل معرفة هل نجحت await startAll() أصلاً (قد تفشل: رفض إذن الميكروفون مثلاً). فتظهر
// الواجهة "تعمل" بينما isRun ما زالت false فعلياً — عدم اتّساق حقيقي بين الحالة الظاهرة
// والحالة الفعلية، يجعل الضغطة التالية تتصرف بشكل يبدو عشوائياً ("ضغطة تستجيب وأخرى لا").
// (ب) الزر كان يتحول فوراً إلى نص " إيقاف" النهائي ثم يُعطَّل بصرياً (باهت فقط) طوال-١
// الانتظار الحقيقي لتهيئة الميكروفون/AudioContext على العتاد الفعلي (قد يستغرق ثوانٍ) — بلا
// أي مؤشر "جارٍ المعالجة" مميّز؛ فتبدو تلك المدة الفاصلة الحقيقية والضرورية أشبه بزر لا
// يستجيب لا بعملية تحدث فعلاً.
// الإصلاح: (أ) لا تُطبَّق حالة "تشغيل" النهائية على الواجهة إلا بعد نجاح startAll() فعلياً؛ عند
// الفشل تُعاد isOn/الواجهة إلى حالة "متوقف" حقيقية ومتّسقة فوراً بدل تركها عالقة. (ب) حالة
// وسيطة مرئية صريحة " جارِ التشغيل..." تُعرض طوال هذه المدة الفاصلة الحقيقية، فتُفهَم كعملية
// جارية لا كتجمّد.
let _toggleBusy=false;
async function toggleAI(e){
 if(_toggleBusy)return;
 _toggleBusy=true;
 const hrbBusy=E('homeRunBtn');if(hrbBusy)hrbBusy.disabled=true;
 try{
 isOn=!isOn;
 const b=E('cb');if(b){b.classList.add('press');setTimeout(()=>b.classList.remove('press'),300);}
 mkRip(e,isOn?'rgba(129,129,129,.3)':'rgba(123,123,123,.3)');
 if(isOn){
 zVibrate([12,4,8]);
 // حالة وسيطة مرئية فوراً — قبل أي await — كي لا تبدو الضغطة بلا أثر إطلاقاً.
 const hrbW=E('homeRunBtn');if(hrbW){hrbW.textContent='جارِ التشغيل...';hrbW.className='home-run-btn wait';}
 const ht2w=E('homeT2');if(ht2w)ht2w.textContent='جارِ تهيئة الميكروفون...';
 const ok=await startAll();
 if(!ok){
 // فشلت التهيئة فعلياً — أعد isOn/الواجهة لحالة "متوقف" حقيقية بدل تركها عالقة على
 // "تشغيل" وهمية بينما isRun ما زالت false. رسالة الخطأ التي كتبتها initAudio() في
 // homeT2 تبقى كما هي — لا تُستبدَل هنا.
 isOn=false;
 const tt0=E('tTxt');if(tt0)tt0.textContent='OFF';
 const st20=E('sTit');if(st20)st20.textContent='ZERO AI v25 — Neural Intelligence';
 const ss0=E('sSub');if(ss0)ss0.textContent='Neural Net · Inverse Gen · 8 Classes · Silent Output';
 const sw0=E('sw-ai');if(sw0)sw0.checked=false;
 const hd0=E('homeDot');if(hd0)hd0.classList.remove('on');
 const ht10=E('homeT1');if(ht10)ht10.textContent='متوقف';
 const hrb0=E('homeRunBtn');if(hrb0){hrb0.textContent='▶ تشغيل';hrb0.className='home-run-btn off';}
 setS('off');
 return;
 }
 const tt=E('tTxt');if(tt)tt.textContent='ON';
 const st2=E('sTit');if(st2)st2.textContent='ZERO AI v25 Active';
 const ss=E('sSub');if(ss)ss.textContent='Neural Net · FreqDB · Inverse Gen · Silent Output';
 const sw=E('sw-ai');if(sw)sw.checked=true;
 const hd=E('homeDot');if(hd)hd.classList.add('on');
 const ht1=E('homeT1');if(ht1)ht1.textContent='يعمل الآن';
 const ht2=E('homeT2');if(ht2)ht2.textContent='الكشف والتحليل نشط';
 const hrb=E('homeRunBtn');if(hrb){hrb.textContent='إيقاف';hrb.className='home-run-btn on';}
 const lr=E('lr'),siD=E('siD'),siT=E('siT');
 setS('on');if(lr)lr.classList.add('go');if(siD)siD.className='si-d proc';if(siT)siT.textContent='Processing — NO audible sound from speaker';animLF();
 }else{
 zVibrate([8]);
 const tt=E('tTxt');if(tt)tt.textContent='OFF';
 const st2=E('sTit');if(st2)st2.textContent='ZERO AI v25 — Neural Intelligence';
 const ss=E('sSub');if(ss)ss.textContent='Neural Net · Inverse Gen · 8 Classes · Silent Output';
 const sw=E('sw-ai');if(sw)sw.checked=false;
 const hd=E('homeDot');if(hd)hd.classList.remove('on');
 const ht1=E('homeT1');if(ht1)ht1.textContent='متوقف';
 const ht2=E('homeT2');if(ht2)ht2.textContent='ZERO AI v25 — جاهز للتشغيل';
 const hrb=E('homeRunBtn');if(hrb){hrb.textContent='▶ تشغيل';hrb.className='home-run-btn off';}
 const lr=E('lr'),siD=E('siD'),siT=E('siT');
 setS('off');if(lr)lr.classList.remove('go');if(siD)siD.className='si-d';if(siT)siT.textContent='Speaker emits NO audible sound';
 stopAll();
 }
 } finally {
 _toggleBusy=false;
 const hrbDone=E('homeRunBtn');if(hrbDone)hrbDone.disabled=false;
 }
}

function mkRip(e,c){
 const el=e.currentTarget||e.target;if(!el)return;
 const r=el.getBoundingClientRect(),rip=document.createElement('div');const sz=Math.max(r.width,r.height)*2;
 Object.assign(rip.style,{position:'absolute',width:sz+'px',height:sz+'px',left:((e.clientX||r.left+r.width/2)-r.left)-sz/2+'px',top:((e.clientY||r.top+r.height/2)-r.top)-sz/2+'px',borderRadius:'50%',background:c||'rgba(129,129,129,.2)',opacity:'.25',transform:'scale(0)',animation:'ripA .6s ease-out forwards',pointerEvents:'none',zIndex:'100'});
 el.style.position='relative';el.style.overflow='hidden';el.appendChild(rip);setTimeout(()=>rip.remove(),700);
}

function animLF(){/* loop flow animation — reserved for future UI */}

/* ══ PANELS ══ */
function openSheet(){sOpen=true;E('ovl').classList.add('on');E('bSheet').classList.add('open');}
function closeSheet(){sOpen=false;if(!pOpen&&!aOpen&&!zpOpen&&!dmOpen&&!menuOpen&&!filesOpen&&!tOpen&&!maskOpen&&!physOpen&&!aboutOpen&&!privacyOpen&&!loopDiagOpen)E('ovl').classList.remove('on');E('bSheet').classList.remove('open');}
function togglePipe(){pOpen?closePipe():openPipe();}
function openPipe(){pOpen=true;E('ovl').classList.add('on');E('ppnl').classList.add('open');}
