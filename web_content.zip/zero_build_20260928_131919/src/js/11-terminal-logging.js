/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 11-terminal-logging.js
 الطرفية ونظام السجلّ الكامل (tLog) + خطاطيف المراقبة (monkey-patch hooks) لتغذية الطرفية
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */
const ST_LOG=[];
function stLog(msg){
 const ts=new Date(),t=String(ts.getMinutes()).padStart(2,'0')+':'+String(ts.getSeconds()).padStart(2,'0');
 ST_LOG.unshift({msg,t});if(ST_LOG.length>60)ST_LOG.pop();
 if(curTab===7){const el=E('st-log');if(el)el.innerHTML=ST_LOG.slice(0,10).map(l=>`<div style="font-family:var(--fm);font-size:9px;color:var(--muted);padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="color:rgba(169,169,169,.45)">${l.t}</span> ${l.msg}</div>`).join('');}
}
/* addToStLog — اسم استُخدم في banFreq/unbanFreq وعدة أماكن أخرى (partitions، auto-ban،
 post-ban confirmation) لكنه لم يكن مُعرَّفاً إطلاقاً — ما كان يعني أن banFreq وغيرها
 تنفجر بـ ReferenceError في نهاية تنفيذها في كل مرة يُحضَر فيها تردد جديد فعلياً (بعد أن
 يكون AI_BAN.set/renderBanList قد نُفِّذا، فتُقطَع العملية دون أن تُكمل return true).
 الإصلاح: alias بسيط إلى stLog الموجودة فعلياً بنفس التوقيع (رسالة نصية واحدة). */
function addToStLog(msg){stLog(msg);}

function updateFilesUI(){
 // Storage paths display
 const pathEl=E('st-paths');
 if(pathEl){
 const p=getStoragePaths();
 if(p.available){
 pathEl.innerHTML='Internal: <span style="color:var(--zero)">'+p.internal+'</span><br> Export: <span style="color:var(--c5)">'+p.export+'</span>';
 }else{
 pathEl.innerHTML='Browser: <span style="color:var(--zero)">IndexedDB</span><br> Export: <span style="color:var(--c5)">Browser Download</span>';
 }
 }
 // Stats — query UDS for live counts
 const kb=E('st-kb');if(kb)kb.textContent=Math.round(freqDB.size*0.2+EXEC_LOG.length*0.1+TBUF.length*0.05);
 // Terminal event count from TBUF
 const tev=E('st-term-ev');if(tev)tev.textContent=TBUF.length;
 // System Links status
 const ls=E('link-status');
 if(ls){
 const rows=[
 {label:'AI EXEC → UDS',ok:!!zeroDB,detail:'exec_history: '+EXEC_LOG.length+' cached'},
 {label:'Terminal → UDS',ok:!!zeroDB,detail:'terminal_events: '+TBUF.length+' buffered'},
 {label:'AI_CTX ← UDS',ok:AI_CTX.ready,detail:'topFreqs='+AI_CTX.topFreqs.length+' patterns='+AI_CTX.confirmedPatterns.length},
 {label:'IndexedDB',ok:!!zeroDB,detail:DBNAME+' v'+DBVER},
 {label:'Storage Persist',ok:false,detail:'checking...'},
 {label:'Android Bridge',ok:typeof ZeroAndroid!=='undefined',detail:typeof ZeroAndroid!=='undefined'?'✓ '+ZeroAndroid.getDeviceModel():'browser mode'},
 ];
 // Check persist async
 if(navigator.storage&&navigator.storage.persisted){
 navigator.storage.persisted().then(p=>{
 const row=ls.querySelector('[data-link="persist"]');
 if(row)row.innerHTML=`<span style="color:${p?'var(--zero)':'var(--c3)'}">${p?'✓':'✗'}</span><span style="color:rgba(255,255,255,.3)"> Storage Persist</span> <span style="color:var(--muted)">${p?'no-evict':'evictable'}</span>`;
 });
 }
 ls.innerHTML=rows.map((r,i)=>`<div data-link="${i===4?'persist':''}" style="display:flex;align-items:center;gap:6px;padding:2px 0;border-bottom:1px solid rgba(255,255,255,.04)"><span style="color:${r.ok?'var(--zero)':'var(--c3)'}">${r.ok?'✓':'✗'}</span><span style="font-family:var(--fm);font-size:9px;color:rgba(255,255,255,.45);flex:1">${r.label}</span><span style="font-family:var(--fm);font-size:8px;color:var(--muted)">${r.detail}</span></div>`).join('');
 }
 // Storage log
 const sl=E('st-log');
 if(sl&&ST_LOG.length)sl.innerHTML=ST_LOG.slice(0,10).map(l=>`<div style="font-family:var(--fm);font-size:9px;color:var(--muted);padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="color:rgba(169,169,169,.45)">${l.t}</span> ${l.msg}</div>`).join('');
 renderAchievements();
 refreshSessionList();
}

/* INIT */
async function initStorage(){
 try{
 // 1. Init unified data store (sessions + terminal_events + exec_history + nn_history + freq_patterns)
 await initDB();
 stLog(' UDS ready: '+DBNAME+' v'+DBVER+' · 7 stores');
 // 2. Request persistent storage (no-evict)
 await reqStoragePersist();
 // 3. Load achievements + NN weights + sessions
 await loadAchievements();
 await loadLastWeights();
 await loadFreqDB();
 await refreshSessionList();
 // 4. Build initial AI context from historical data
 await updateAICtx();
 stLog(' AI_CTX ready · topFreqs='+AI_CTX.topFreqs.length+' patterns='+AI_CTX.confirmedPatterns.length);
 // 5. Terminal startup message
 tLog('SYS',
 `# UDS initialized: ${DBNAME} v${DBVER} · persist=${AI_CTX.ready}`,
 `# stores: terminal_events, exec_history, nn_history, freq_patterns, sessions, achievements, patterns`
 );
 // 6. Write to Android storage if available
 if(typeof ZeroAndroid!=='undefined'){
 const paths={internal:ZeroAndroid.getInternalPath(),export:ZeroAndroid.getExportPath()};
 ZeroAndroid.saveFile('logs','init.txt','ZERO AI v25 UDS init: '+new Date().toISOString()+'\n'+JSON.stringify(paths));
 stLog(' Android paths ready');
 }
 }catch(e){stLog(' Storage error: '+e.message);}
}




/* ════════════════════════════════════════════════════════════════
 LIVE TERMINAL — Python DSL Feed
 All engine events streamed in real-time using Python syntax.
 The AI EXEC system reads this feed to understand the full state.

 AI Language: Python (pseudocode) — chosen for:
 • Native AI training language (most LLM-friendly syntax)
 • Expressive: state.FC['c7'], iLv = min(1.0, iLv*1.07)
 • Self-documenting: logic is readable by both human and AI
 • Matches how neural network research is written
════════════════════════════════════════════════════════════════ */

/* ══ TERMINAL STATE ══ */
const TBUF = []; // ring buffer 300 entries — تبقى تُخزِّن كل الأنواع (FREQ/NN/EXEC/...)
 // كما كانت، فأنظمة أخرى (udsWriteEvent→terminal_events، AI_CTX،
 // pattern learning) تعتمد عليها بلا تغيير — التصفية أدناه للعرض فقط.
const TMAX = 300;
// tOpen declared at top scope (line 688) — no re-declaration needed
let tPaused = false;
let tFilter = 'ALL'; // استُعيدت 28 سبتمبر 2026 — تتحكم بعرض الطرفية الحيّ (ALL أو فئة واحدة)
// بحث نصّي حرّ — أُضيف 28 سبتمبر 2026 (تطوير Logs): تصفية الفئة وحدها (tFilter) لا تكفي
// لإيجاد سطر بعينه وسط مئات الأسطر (مثلاً تردد رقمي محدد أو رسالة خطأ معيّنة)؛ يعمل هذا
// البحث فوق تصفية الفئة (AND بينهما، لا بديل عنها) وعلى نص السطر (code) وسطره الفرعي (sub)
// معاً، غير حسّاس لحالة الأحرف. فارغ = بلا أثر (كل السلوك القديم كما هو تماماً).
let tSearchQuery = '';
// TERM_VISIBLE_TYPES يبقى استخدامه الآن مقصوراً على أهلية "تجميع التكرارات" (dedup) فقط —
// السبب: SYS/WARN/ERR هي الأنواع المعرَّضة تاريخياً لفيضان تكرار حقيقي (خطأ JS يتكرر كل
// ~320ms)، بخلاف FREQ/NN/EXEC/INV/SF/COH التي تُسجَّل بمعدل دورة الكشف الطبيعي فلا تحتاج ذلك.
// العرض الحيّ نفسه يعتمد الآن على tFilter أدناه (ALL يعرض كل الأنواع، أو فئة واحدة محددة).
const TERM_VISIBLE_TYPES = new Set(['SYS','WARN','ERR']);
const TC = { // Python color scheme per type
 FREQ: '#959595',
 NN: '#a5a5a5',
 EXEC: '#cecece',
 INV: '#9c9c9c',
 SF: '#aaaaaa',
 COH: '#818181',
 DB: '#a9a9a9',
 SYS: '#a4a4a4',
 BG: '#888888',
 WARN: '#888888',
 ERR: '#686868',
};
const TTAG = {
 FREQ:'[FREQ]',NN:'[NN ]',EXEC:'[EXEC]',INV:'[INV ]',
 SF:'[SF ]',COH:'[COH ]',DB:'[DB ]',SYS:'[SYS ]',
 BG:'[BG ]',WARN:'[WARN]',ERR:'[ERR ]',
};

/* ══ تطوير سجلّ الأخطاء (طلب المستخدم) — ميزتان جديدتان ══
 ① تجميع التكرارات: حالة حقيقية أثبتها سجلّ الأخطاء الذي أرسله المستخدم فعلياً — نفس الانهيار
 الواحد تكرر كل ~320ms لعشرات الثواني (~90 سطراً متطابقاً من أصل 98). بلا تجميع، رسالة متكررة
 بسرعة تُغرق المخزن المحدود (300) والعرض والتصدير بنسخ متطابقة، فيُفقَد أي سياق آخر مختلف حدث
 في نفس النافذة الزمنية. الآن: تكرار (type+code+sub) نفسه خلال ≤3 ثوانٍ من آخر ظهور له لا يُنشئ
 سطراً جديداً — يزيد عدّاد السطر القائم (×N) ويحدّث وقته فقط. مقصور على الأنواع المعروضة
 (SYS/WARN/ERR) حصراً — لا يمسّ إطلاقاً سجلّ FREQ/NN/EXEC/INV/SF/COH (حدث واحد لكل استدعاء
 كما كان دوماً، لأن AI_CTX/pattern learning تعتمد على ذلك التدفق الخام).
 ② الاستمرارية عبر إعادة التحميل: رسائل SYS/WARN/ERR (المرئية فقط) تُحفظ في localStorage
 وتُستعاد تلقائياً عند تحميل الصفحة من جديد — فإن أدّى عطل حقيقي لإعادة تشغيل الصفحة/التطبيق
 قبل أن يفتح المستخدم اللوحة أو يحفظ TXT، لا يُفقَد سجلّ ذلك العطل بالكامل. ══ */
let _tIdSeq = 0;
const _dedupMap = new Map(); // key(type|code|sub) → {entry, lastMs}
const _DEDUP_WINDOW_MS = 3000;
const TLOG_PERSIST_KEY = 'zero_syslog_v1';
const TLOG_PERSIST_MAX = 150;
let _persistTimer = null;
function _persistTermLog(){
 try{
 const items = TBUF.filter(e=>TERM_VISIBLE_TYPES.has(e.type)).slice(0,TLOG_PERSIST_MAX)
 .map(e=>({type:e.type,t:e.t,code:e.code,sub:e.sub,count:e.count||1}));
 localStorage.setItem(TLOG_PERSIST_KEY, JSON.stringify(items));
 }catch(e){}
}
function _schedulePersistTermLog(){
 if(_persistTimer)return;
 _persistTimer=setTimeout(()=>{_persistTimer=null;_persistTermLog();},1500);
}
function _restoreTermLog(){
 try{
 const raw=localStorage.getItem(TLOG_PERSIST_KEY);
 if(!raw)return;
 const items=JSON.parse(raw);
 if(!Array.isArray(items)||!items.length)return;
 // items مخزَّنة الأحدث أولاً (كترتيب TBUF) — تُدرَج بترتيب عكسي كي يبقى الأحدث فعلياً
 // أول عنصر في TBUF بعد الاستعادة، تماماً كما لو أنها سُجِّلت للتو بنفس ترتيبها الأصلي.
 for(let i=items.length-1;i>=0;i--){
 const it=items[i];
 if(!it||!it.type||!it.code)continue;
 TBUF.unshift({id:++_tIdSeq,type:it.type,t:it.t||'--:--.--',code:it.code,sub:it.sub||null,count:it.count||1,restored:true});
 }
 if(TBUF.length>TMAX)TBUF.length=TMAX;
 setTimeout(()=>tLog('SYS','# استُعيد '+items.length+' رسالة من الجلسة السابقة'),0);
 }catch(e){}
}
_restoreTermLog(); // تنفيذ فوري عند تحميل السكربت — قبل أي استدعاء آخر لـtLog() في هذه الجلسة

// مطابقة سطر لاستعلام البحث الحالي — مشتركة بين العرض الحيّ (tLog) وإعادة البناء الكاملة
// (termRenderAll)، لتفادي انحراف أحدهما عن الآخر (نفس درس "تناسق الفحص/المقارنة" في هذه الجلسة).
function _termMatchesSearch(code, sub) {
 if (!tSearchQuery) return true;
 return (code && code.toLowerCase().includes(tSearchQuery)) ||
 (sub && sub.toLowerCase().includes(tSearchQuery));
}

/* ══ TERMINAL LOGGER — PYTHON SYNTAX ══ */
function tLog(type, pyCode, sub) {
 // ERR (أخطاء JS حقيقية ملتقَطة تلقائياً) يجب أن تُسجَّل دوماً كـSYS تماماً — قد يحدث خطأ
 // حتى قبل الضغط على تشغيل، ولا يجوز إسقاطه بسبب isRun===false.
 if(!isRun && type !== 'SYS' && type !== 'ERR') return;
 const nowMs = Date.now();
 const ts = new Date(nowMs);
 const t = String(ts.getMinutes()).padStart(2,'0') + ':' +
 String(ts.getSeconds()).padStart(2,'0') + '.' +
 String(ts.getMilliseconds()).slice(0,3);
 const visible = TERM_VISIBLE_TYPES.has(type); // أهلية تجميع التكرارات (dedup) فقط
 const shown = (tFilter==='ALL' || tFilter===type) && _termMatchesSearch(pyCode, sub); // فئة + بحث معاً
 const dkey = visible ? (type+'|'+pyCode+'|'+(sub||'')) : null;
 if(visible){
 const dhit = _dedupMap.get(dkey);
 if(dhit && (nowMs-dhit.lastMs) < _DEDUP_WINDOW_MS){
 dhit.entry.count=(dhit.entry.count||1)+1;
 dhit.entry.t=t;
 dhit.lastMs=nowMs;
 const ld=E('termLiveDot');
 if(ld){ld.className='term-live-dot on';setTimeout(()=>{if(ld)ld.className='term-live-dot'+(isRun?' on':'');},120);}
 if(tOpen && !tPaused && shown) updateTermLine(dhit.entry);
 _schedulePersistTermLog();
 return;
 }
 }
 const entry = {id:++_tIdSeq, type, t, code: pyCode, sub: sub || null, count:1};
 TBUF.unshift(entry);
 if(TBUF.length > TMAX) TBUF.pop();
 if(visible){
 if(_dedupMap.size>=200){const oldestKey=_dedupMap.keys().next().value;_dedupMap.delete(oldestKey);}
 _dedupMap.set(dkey,{entry,lastMs:nowMs});
 }
 // ── Write to UDS (persistent memory) ────────────
 udsWriteEvent(entry);
 // ── Write NN snapshot to nn_history ─────────────
 if(type==='NN') udsWriteNN();
 // Live dot pulse
 const ld = E('termLiveDot');
 if(ld) { ld.className = 'term-live-dot on'; setTimeout(() => { if(ld) ld.className = 'term-live-dot' + (isRun?' on':''); }, 120); }
 if(tOpen && !tPaused && shown) renderTermLine(entry);
 if(visible) _schedulePersistTermLog();
}

// جسم السطر (اللون + النص + شارة التكرار ×N إن وُجدت) — مشترك بين render/update لتفادي الازدواج.
function _tBodyHTML(entry){
 const c = TC[entry.type] || '#ccc';
 const cnt = (entry.count||1) > 1 ? `<span class="tl-cnt">×${entry.count}</span>` : '';
 return `<span class="tl-body" style="color:${c}">${escH(entry.code)}</span>${cnt}`;
}

function renderTermLine(entry) {
 const out = E('termOut'); if(!out) return;
 const c = TC[entry.type] || '#ccc';
 const tag = TTAG[entry.type] || '[ ]';
 const row = document.createElement('div');
 row.className = 'tline';
 row.dataset.tid = entry.id;
 row.innerHTML =
 `<span class="tl-ts">${entry.t}</span>` +
 `<span class="tl-tag" style="color:${c}">${tag}</span>` +
 _tBodyHTML(entry);
 if(entry.sub) {
 const sub = document.createElement('div');
 sub.className = 'tl-sub';
 sub.dataset.tid = entry.id;
 sub.textContent = entry.sub;
 out.insertBefore(sub, out.firstChild);
 }
 out.insertBefore(row, out.firstChild);
 // Trim UI to 80 rows
 while(out.children.length > 80) out.removeChild(out.lastChild);
}

// تحديث سطر معروض بالفعل مكانه (بدل إدراج سطر جديد) عند تجميع تكرار — انظر تعليق _dedupMap.
function updateTermLine(entry){
 const out = E('termOut'); if(!out) return;
 const row = out.querySelector(`.tline[data-tid="${entry.id}"]`);
 if(!row){ renderTermLine(entry); return; } // خرج من نافذة الـ80 سطر المعروضة — أضِف سطراً بأمان
 row.innerHTML =
 `<span class="tl-ts">${entry.t}</span>` +
 `<span class="tl-tag" style="color:${TC[entry.type]||'#ccc'}">${TTAG[entry.type]||'[ ]'}</span>` +
 _tBodyHTML(entry);
}

function termRenderAll() {
 const out = E('termOut'); if(!out) return;
 out.innerHTML = '';
 const byCat = tFilter==='ALL' ? TBUF : TBUF.filter(e => e.type === tFilter);
 const items = tSearchQuery ? byCat.filter(e => _termMatchesSearch(e.code, e.sub)) : byCat;
 const cntEl = E('termSearchCnt');
 if (cntEl) cntEl.textContent = tSearchQuery ? `${items.length} نتيجة` : '';
 items.slice(0, 60).reverse().forEach(e => {
 const c = TC[e.type] || '#ccc';
 const tag = TTAG[e.type] || '[ ]';
 const row = document.createElement('div');
 row.className = 'tline';
 row.dataset.tid = e.id;
 row.innerHTML =
 `<span class="tl-ts">${e.t}</span>` +
 `<span class="tl-tag" style="color:${c}">${tag}</span>` +
 _tBodyHTML(e);
 if(e.sub){const s=document.createElement('div');s.className='tl-sub';s.dataset.tid=e.id;s.textContent=e.sub;out.appendChild(s);}
 out.appendChild(row);
 });
 out.scrollTop = out.scrollHeight;
}

/* ══ TERMINAL CONTROL ══ */
function openTerm() {
 tOpen = true;
 E('ovl').classList.add('on');
 E('termPanel').classList.add('open');
 termRenderAll();
 const el = E('termLiveDot');
 if(el) el.className = 'term-live-dot' + (isRun?' on':'');
}

function closeTerm() {
 tOpen = false;
 if(!sOpen && !pOpen && !aOpen && !zpOpen && !dmOpen && !menuOpen && !filesOpen && !maskOpen && !physOpen && !aboutOpen && !privacyOpen && !loopDiagOpen) E('ovl').classList.remove('on');
 E('termPanel').classList.remove('open');
}

function termTogglePause() {
 tPaused = !tPaused;
 const btn = E('termPauseBtn');
 const lbl = E('termPauseLbl');
 if(btn) btn.textContent = tPaused ? '▶ RESUME' : ' PAUSE';
 if(lbl) lbl.style.display = tPaused ? '' : 'none';
 if(!tPaused) termRenderAll();
}

function termClear() {
 TBUF.length = 0;
 _dedupMap.clear();
 try{localStorage.removeItem(TLOG_PERSIST_KEY);}catch(e){} // "مسح" يعني مسح كامل — بما في ذلك النسخة المحفوظة
 const out = E('termOut');
 if(out) out.innerHTML = '<div style="color:rgba(169,169,169,.3);font-size:9px;padding:4px 0">-- terminal cleared --</div>';
}

// استُعيدت 28 سبتمبر 2026: تصفية الطرفية بالفئة (tFilter) — نفس السلوك الأصلي قبل الحذف.
function termFilter(btn, f) {
 tFilter = f;
 document.querySelectorAll('.tfc').forEach(b => b.classList.remove('on'));
 btn.classList.add('on');
 termRenderAll();
}

// بحث نصّي حرّ في السجلّ — تطوير Logs، 28 سبتمبر 2026. يعمل فوق تصفية الفئة الحالية (AND).
function termSearch(val) {
 tSearchQuery = (val || '').trim().toLowerCase();
 termRenderAll();
}

// استُعيدت 28 سبتمبر 2026: تنفيذ أمر من حقل الطرفية — يُمرَّر لمحرك EXEC نفسه (#execInp/
// runExecCmd) الموجود أصلاً في لوحة أخرى، فلا يوجد منطق EXEC مكرَّر هنا إطلاقاً.
function termRunCmd() {
 const inp = E('termCmd'); if(!inp) return;
 const cmd = inp.value.trim(); inp.value = '';
 if(!cmd) return;
 tLog('SYS', `>>> ${cmd}`);
 const ei = E('execInp');
 if(ei) { ei.value = cmd; runExecCmd(); }
}

// ميزة حُفظت من مرحلة "مراقبة فقط": حفظ سجلّ النظام/الأخطاء المعروض كملف TXT — تبقى مفيدة
// حتى بعد استعادة التفاعل الكامل أعلاه (تصدير مخصَّص لـSYS/WARN/ERR فقط، بمعزل عن التصفية الحية).
function termSaveTXT() {
 const items = TBUF.filter(e => TERM_VISIBLE_TYPES.has(e.type)).slice().reverse(); // الأقدم أولاً
 if(!items.length){ tLog('SYS', '# لا توجد رسائل نظام/أخطاء لحفظها بعد'); return; }
 const lines = items.map(e => {
 const tag = (TTAG[e.type] || '[' + e.type + ']').trim();
 const cnt = (e.count||1) > 1 ? ` (×${e.count})` : '';
 return `${e.t} ${tag} ${e.code}${cnt}` + (e.sub ? `\n ${e.sub}` : '');
 });
 const now = new Date();
 const stamp = now.getFullYear() + String(now.getMonth()+1).padStart(2,'0') + String(now.getDate()).padStart(2,'0') +
 '_' + String(now.getHours()).padStart(2,'0') + String(now.getMinutes()).padStart(2,'0') + String(now.getSeconds()).padStart(2,'0');
 const filename = `ZERO_SystemLog_${stamp}.txt`;
 const content = `ZERO AI v25 — System/Error Log\nExported: ${now.toISOString()}\nEntries: ${items.length}\n${'='.repeat(48)}\n\n${lines.join('\n')}\n`;
 // نفس أسلوب exportBans() الراسخ في المشروع: محاولة جسر أندرويد أولاً، ثم التنزيل عبر المتصفح.
 if(typeof ZeroAndroid!=='undefined'){
 try{
 if(ZeroAndroid.exportFile(filename,content)){
 tLog('SYS', `# saved → ${ZeroAndroid.getExportPath()}/${filename}`);
 return;
 }
 }catch(e){}
 }
 try{
 const blob=new Blob([content],{type:'text/plain'});
 const url=URL.createObjectURL(blob);
 const a=document.createElement('a');
 a.href=url;a.download=filename;
 document.body.appendChild(a);a.click();
 setTimeout(()=>{URL.revokeObjectURL(url);document.body.removeChild(a);},1000);
 tLog('SYS', `# downloading: ${filename}`);
 }catch(e){
 tLog('SYS', `# save failed: ${e.message}`);
 }
}

/* ════════════════════════════════════════════
 PYTHON DSL HOOKS — instrument every engine event
 Every function below calls tLog() with Python syntax
════════════════════════════════════════════ */

/* Hook: fRecord → FREQ event */
const _fRecordOrig = fRecord;
let _fRecHooked = false; // re-entry guard
window.fRecord = function(hz, energy) {
 _fRecordOrig.call(this, hz, energy);
 if(!hz || hz < 0.01 || _fRecHooked) return;
 _fRecHooked = true;
 const bin = fBin(hz);
 const e = freqDB.get(bin);
 if(!e) return;
 const cls = e.class || 0;
 const cn = ['','C1⊕','C2⊖','C3∓','C4±','C5+','C6-','C7+','C8-'][cls] || '';
 tLog('FREQ',
 `hz = ${hz.toFixed(3)} # class=${cn} energy=${energy.toFixed(3)} count=${e.count}${e.confirmed?' [CONFIRMED]':''}${e.cancelled?' [CANCELLED]':''}`,
 e.count===FREQ_THRESH ? `# → THRESHOLD ×${FREQ_THRESH} reached — inverse queued` : null
 );
 _fRecHooked = false;
};

/* Hook: nnTrain → NN event in Python */
const _nnTrainOrig = nnTrain;
window.nnTrain = function(inp, reward) {
 if(!NN.w1) return; // guard: NN not initialized yet
 const prevLoss = NN.loss;
 _nnTrainOrig.call(this, inp, reward);
 if(NN.trainN % 5 !== 0) return; // log every 5th train to reduce noise
 tLog('NN',
 `loss = ${prevLoss.toFixed(4)} → ${NN.loss.toFixed(4)} # reward=${reward>0?'+':''}${reward.toFixed(3)} step=${NN.trainN} lr=${NN.lr.toFixed(4)}`,
 NN.loss < prevLoss ? `# ↓ improving Δ=${(prevLoss-NN.loss).toFixed(5)}` : `# ↑ loss spike`
 );
};

/* Hook: buildInverse → INV event */
const _buildInvOrig = buildInverse;
window.buildInverse = function(hz, energy, dbEntry) {
 _buildInvOrig.call(this, hz, energy, dbEntry);
 const hp = Math.min(1/(hz*2), 0.5);
 tLog('INV',
 `buildInverse(hz=${hz.toFixed(3)}, φ=π) # delay=${hp.toFixed(6)}s gain=${((hz<20||hz>20000)?energy*0.12:energy*0.025).toFixed(4)}`,
 `# anti-phase oscillator → verifyInv() in ${INV.verMs}ms`
 );
};

/* Hook: logExec → EXEC event in Python */
const _logExecOrig = logExec;
window.logExec = function(args) {
 _logExecOrig.call(this, args);
 if(!args || !args.prog) return;
 // Format EXEC as Python def
 const lines = (args.lines || []).slice(0,3);
 const pyStr = `def ${args.prog}(): # cycle=${args.cycle||aiCyc} ${args.auto?'auto':'manual'} ${args.ms||0}ms\n ${lines.map(l=>'# '+l).join('\n ')}`;
 tLog('EXEC', pyStr, lines.length > 3 ? ` # ... +${args.lines.length-3} more` : null);
};

/* Hook: updSFGains → SF event — sampled to avoid spam */
let _sfLogN = 0;
const _updSFGainsOrig = updSFGains;
window.updSFGains = function() {
 _updSFGainsOrig.call(this);
 if(++_sfLogN % 5 !== 0) return; // log every 5th call
 const oCount = Object.keys(silOscs).filter(k=>k!=='_m').length;
 tLog('SF',
 `SF.gains = {INF:${iLv.toFixed(3)}, ULT:${uLv.toFixed(3)}, PHF:${pLv.toFixed(3)}, SUB:${bLv.toFixed(3)}, PIE:${eLv.toFixed(3)}}`,
 `# ${oCount} oscillators active`
 );
};

/* Hook: Coherence update (from updCoh) — sampled every 10th update */
let _cohCount = 0;
const _updCohOrig = updCoh;
window.updCoh = function(tS, tR) {
 _updCohOrig.call(this, tS, tR);
 _cohCount++;
 if(_cohCount % 10 !== 0) return;
 const avgCoh = Array.from(cV).reduce((a,b)=>a+b,0)/cV.length;
 tLog('COH',
 `γ²_avg = ${avgCoh.toFixed(4)} # silence=${silSc}% bands=12 Δsilence=${silSc-bestSil}%`,
 `# ${silSc>=80?'✓ γ²→0 achieved':'↻ converging...'}`
 );
};

/* BG mode events */
const _docVisCB = () => {
 if(document.hidden) tLog('BG', `# → BACKGROUND run#${bgRuns} cycle=${aiCyc} silence=${silSc}%`);
 else tLog('BG', `# ← FOREGROUND bgTime=${(bgTotalMs/1000).toFixed(1)}s workerCyc=${wkCycs}`);
};
document.addEventListener('visibilitychange', _docVisCB);

/* System log: forward logNN to terminal */
const _logNNOrig = logNN;
window.logNN = function(msg) {
 _logNNOrig.call(this, msg);
 // Only forward NN-specific internal messages, not EXEC duplicates
 if(msg.startsWith(' EXEC:') || msg.startsWith('') || msg.startsWith('')) return;
 tLog('SYS', `# ${msg}`);
};

/* closeAll already calls closeTerm() — no hook needed */

/* ══ التقاط الأخطاء الحقيقية تلقائياً — لم يكن للتطبيق أي مستمع error/unhandledrejection
 عام إطلاقاً قبل هذا؛ كل الاستثناءات غير الملتقَطة كانت تظهر فقط في console المطوّر ولا تصل
 لسجلّ النظام المعروض للمستخدم. الآن كل خطأ JS غير مُعالَج (بما فيها رفض Promise غير معالَج
 — بالضبط فئة الأخطاء التي واجهناها مراراً في هذا الملف: سباقات initAudio/reqWL وغيرها) يُسجَّل
 فوراً في سجلّ النظام بنوع ERR (يبقى مرئياً دوماً بصرف النظر عن isRun). ══ */
window.addEventListener('error', e => {
 const msg = e.message || (e.error && e.error.message) || 'Unknown error';
 const loc = e.filename ? `${String(e.filename).split('/').pop()}:${e.lineno}:${e.colno}` : null;
 // تطوير سجلّ الأخطاء: تضمين أول أطر استدعاء حقيقية من stack trace عند توفّرها — يسرّع تشخيص
 // العطل التالي فوراً (بدل الاكتفاء بموضع سطر واحد فقط، كما كانت النسخة السابقة).
 let stackBit = '';
 try{
 if(e.error && e.error.stack){
 const frames = String(e.error.stack).split('\n').slice(1,4).map(s=>s.trim()).filter(Boolean);
 if(frames.length) stackBit = ' · ' + frames.join(' ← ').slice(0,260);
 }
 }catch(err){}
 const sub = (loc ? `# at ${loc}` : '') + stackBit;
 tLog('ERR', ` ${msg}`, sub || null);
});
window.addEventListener('unhandledrejection', e => {
 const reason = e.reason;
 const msg = (reason && reason.message) ? reason.message : String(reason);
 tLog('ERR', ` Unhandled promise rejection: ${msg}`, null);
});

/* ══ Terminal init on startup — called from logExec SYS entry ══ */

document.addEventListener('keydown',e=>{if(e.key==='Escape')closeAll();if(e.key===' '){e.preventDefault();toggleAI({});}});
// مستمع resize الخاص بـ bgCv (خلفية النجوم المتحركة) حُذف مع حذف الميزة بالكامل (28 سبتمبر 2026)

/* ══════════════════════════════════════════
 SINGLE UNIFIED INIT — all systems start here
 Order: BG → Storage → DB → Achievements → UI
══════════════════════════════════════════ */
window.addEventListener('load',()=>{
 // Init storage after UI is ready
 setTimeout(async()=>{
 await initStorage();
 // UI refresh
 updBGUI();
 updateFilesUI();
 bgLog(' ZERO AI v25 — All systems ready (local mode)');
 stLog(' Storage ready · '+DBNAME+' v'+DBVER+' · '+('serviceWorker' in navigator?'SW support':'no SW'));
 },800);
});

/* ══════════════════════════════════════════════════════════════════
 غرفة الصمت (MASKING NOISE) — استُعيدت 28 سبتمبر 2026 من anechoic-
 chamber.html ("تجميع كل الأفكار"). فكرة لم تظهر إطلاقاً في أي نسخة
 سابقة من ZERO — الإلغاء الفعّال (ANC) يحاول محو الصوت، بينما هذه
 ميزة مختلفة كلياً: إخفاؤه بضوضاء مريحة (إخفاء نفسي/سمعي لا فيزيائي).
 محرك صوت مستقل تماماً (maskCtx خاص) — لا يشارك actx الخاص بمحرك ANC
 الرئيسي، فلا يوجد أي تداخل أو تنافس على الموارد بين الاثنين، ويمكن
 تشغيلهما معاً أو كل على حدة. المنطق منقول حرفياً من anechoic-
 chamber.html (نفس خوارزميات توليد الضوضاء) مع إعادة تسمية كل الدوال
 بسابقة mask* لضمان عدم تعارضها مع أي شيء آخر في هذا الملف الضخم.
 ══════════════════════════════════════════════════════════════════ */
