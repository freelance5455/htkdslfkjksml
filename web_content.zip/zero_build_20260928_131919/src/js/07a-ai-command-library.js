/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 07a-ai-command-library.js
 مكتبة أوامر AI الضخمة (AI_LIB) — قاموس البرامج/الأوامر المتاحة لمحرك التنفيذ الذاتي
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): تقسيم إضافي لملف كان
 أضخم من بقية الملفات — نفس المنهج: قصّ آلي عند حدود تصريحات علوية
 آمنة، بلا أي تغيير منطقي أو إعادة ترتيب.
 ══════════════════════════════════════════════════════════════════ */
const AI_LIB={

 OPTIMIZE_SF:{
 desc:'Adjusts SF gains from 8-class distribution + AI_CTX.topFreqs patterns',
 run(st){
 const changes=[];const tot=Object.values(st.FC).reduce((a,b)=>a+b,0)||1;
 // Read DB-derived pattern context
 if(AI_CTX.ready&&AI_CTX.topFreqs.length){
 const tf=AI_CTX.topFreqs[0];
 changes.push(`# db_context: top_hz=${tf.hz}Hz(×${tf.count}) cohTrend=${AI_CTX.cohTrend.toFixed(3)}`);
 // Pattern-specific boost: if top freq is below 100Hz → boost INF harder
 if(tf.hz<100&&tf.count>5){const p=iLv;iLv=Math.min(1,iLv*1.10);if(Math.abs(iLv-p)>0.001)changes.push(`INF ${p.toFixed(3)}→${iLv.toFixed(3)} [pattern<100Hz]`);}
 // COH improving → keep current strategy; declining → switch
 if(AI_CTX.cohDelta<-0.05){const p=uLv;uLv=Math.min(1,uLv*1.08);changes.push(`ULT ${p.toFixed(3)}→${uLv.toFixed(3)} [coh↓ switch]`);}
 }
 // C7 dominant (spk-emittable) → boost INF field
 if(st.FC.c7/tot>0.28){const p=iLv;iLv=Math.min(1,iLv*1.07);if(Math.abs(iLv-p)>0.001)changes.push(`INF ${p.toFixed(3)}→${iLv.toFixed(3)} [C7↑]`);}
 // C1 dominant (positive energy) → strengthen PHF
 if(st.FC.c1/tot>0.35){const p=pLv;pLv=Math.min(1,pLv*1.05);if(Math.abs(pLv-p)>0.001)changes.push(`PHF ${p.toFixed(3)}→${pLv.toFixed(3)} [C1↑]`);}
 // C2 dominant (negative/cancel) → boost ULT coherence break
 if(st.FC.c2/tot>0.3){const p=uLv;uLv=Math.min(1,uLv*1.06);if(Math.abs(uLv-p)>0.001)changes.push(`ULT ${p.toFixed(3)}→${uLv.toFixed(3)} [C2↑]`);}
 // C6 dominant (mic-invisible) → boost SUB reset
 if(st.FC.c6/tot>0.25){const p=bLv;bLv=Math.min(1,bLv*1.04);if(Math.abs(bLv-p)>0.001)changes.push(`SUB ${p.toFixed(3)}→${bLv.toFixed(3)} [C6↑]`);}
 // Low silence → increase all SF gains
 if(st.silSc<25){iLv=Math.min(1,iLv*1.03);uLv=Math.min(1,uLv*1.03);pLv=Math.min(1,pLv*1.03);changes.push(`ALL+3% [sil<25%]`);}
 updSFGains();
 return changes.length?changes:['SF gains optimal — no adjustment'];
 }
 },

 TUNE_NN:{
 desc:'Adapts NN lr/momentum from loss trend + AI_CTX.nnLossTrend history',
 run(st){
 const changes=[];const loss=st.NN.loss;
 // Use DB-derived trend for smarter adaptation
 if(AI_CTX.ready){
 changes.push(`# db_context: nnLossTrend=${AI_CTX.nnLossTrend.toFixed(5)} bestLoss=${AI_CTX.nnBestLoss.toFixed(4)} bestProg=${AI_CTX.bestProg||'—'}`);
 // If loss trend is worsening fast → aggressive lr boost
 if(AI_CTX.nnLossTrend<-0.01){const p=NN.lr;NN.lr=Math.min(0.06,NN.lr*1.25);changes.push(`lr ${p.toFixed(4)}→${NN.lr.toFixed(4)} [trend↓ aggressive]`);}
 // If we're far from best loss → reduce momentum to explore
 if(loss>AI_CTX.nnBestLoss*2&&NN.mom>0.75){const p=NN.mom;NN.mom=Math.max(0.7,NN.mom-0.03);changes.push(`mom ${p.toFixed(3)}→${NN.mom.toFixed(3)} [explore: loss>>best]`);}
 }
 // Learning rate adaptation
 const prevLR=NN.lr;
 if(loss>0.6){NN.lr=Math.min(0.05,NN.lr*1.18);changes.push(`lr ${prevLR.toFixed(4)}→${NN.lr.toFixed(4)} [loss>0.6 boost]`);}
 else if(loss>0.35){NN.lr=Math.min(0.03,NN.lr*1.08);changes.push(`lr ${prevLR.toFixed(4)}→${NN.lr.toFixed(4)} [loss>0.35 up]`);}
 else if(loss<0.08&&st.aiCyc>200){NN.lr=Math.max(0.0008,NN.lr*0.90);changes.push(`lr ${prevLR.toFixed(4)}→${NN.lr.toFixed(4)} [converging↓]`);}
 // Momentum adaptation
 const prevM=NN.mom;
 if(loss>0.5&&NN.mom>0.8){NN.mom=Math.max(0.7,NN.mom-0.02);changes.push(`mom ${prevM.toFixed(3)}→${NN.mom.toFixed(3)} [high loss↓]`);}
 else if(loss<0.1&&NN.mom<0.95){NN.mom=Math.min(0.97,NN.mom+0.01);changes.push(`mom ${prevM.toFixed(3)}→${NN.mom.toFixed(3)} [low loss↑]`);}
 // Wiener α from noise floor
 const prevA=P.alpha;
 if(st.noiseE>0.55){P.alpha=Math.min(3.5,P.alpha*1.06);changes.push(`Wiener.α ${prevA.toFixed(2)}→${P.alpha.toFixed(2)} [noise↑]`);}
 else if(st.noiseE<0.08){P.alpha=Math.max(0.8,P.alpha*0.96);changes.push(`Wiener.α ${prevA.toFixed(2)}→${P.alpha.toFixed(2)} [noise↓]`);}
 // ① Loss-Momentum Warmup: slope of NN.hist guides mom direction
 if(NN.hist.length>=10){const re=NN.hist.slice(-10);const sl=(re[9].loss-re[0].loss)/10;if(sl>0.005&&NN.mom>0.80){const pm=NN.mom;NN.mom=Math.max(0.70,NN.mom-0.02);changes.push(`mom↓ ${pm.toFixed(3)}→${NN.mom.toFixed(3)} [loss rising slope=${sl.toFixed(4)}]`);}else if(sl<-0.005&&NN.mom<0.92){const pm=NN.mom;NN.mom=Math.min(0.95,NN.mom+0.01);changes.push(`mom↑ ${pm.toFixed(3)}→${NN.mom.toFixed(3)} [loss falling]`);}}
 // ① SPEC_FLAT×NN — Flatness-Adaptive LR: noise→explore, tonal→converge
 if(SPEC_FLAT.val>0.6){const p=NN.lr;NN.lr=Math.min(0.05,NN.lr*1.10);changes.push(`lr↑×1.10 [SPEC_FLAT=${SPEC_FLAT.val.toFixed(3)} noisy→explore]`);}
 else if(SPEC_FLAT.val<0.15&&NN.loss<0.3){const p=NN.lr;NN.lr=Math.max(0.001,NN.lr*0.92);changes.push(`lr↓×0.92 [SPEC_FLAT=${SPEC_FLAT.val.toFixed(3)} tonal→converge]`);}
 // ⑩ ZCRATE×NN — ZCR-Guided LR Boost: percussive/noisy signal → faster adaptation
 if(typeof ZCRATE!=='undefined'&&ZCRATE.val>0.3){const p=NN.lr;NN.lr=Math.min(0.06,NN.lr*(1+ZCRATE.val*0.3));changes.push(`lr↑ [ZCR=${ZCRATE.val.toFixed(4)} percussive→adapt]`);}
 return changes.length?changes:[`NN params optimal · lr=${NN.lr.toFixed(4)} · mom=${NN.mom.toFixed(3)}`];
 }
 },

 ADAPT_THRESH:{
 desc:'Adapts FREQ_THRESH and INV.verMs based on DB capture rate + success',
 run(st){
 const changes=[];
 const rate=st.freqFile.totalCap/Math.max(st.aiCyc,1);
 const prevT=FREQ_THRESH;
 if(rate>10){FREQ_THRESH=Math.min(8,FREQ_THRESH+1);changes.push(`THRESH ${prevT}→${FREQ_THRESH} [rate=${rate.toFixed(1)}/cyc high]`);}
 else if(rate<1){FREQ_THRESH=Math.max(2,FREQ_THRESH-1);changes.push(`THRESH ${prevT}→${FREQ_THRESH} [rate=${rate.toFixed(1)}/cyc low]`);}
 else changes.push(`THRESH=${FREQ_THRESH} stable · rate=${rate.toFixed(1)}/cyc`);
 // Inv verification timing
 if(st.freqFile.totalConf>0){
 const sr=st.freqFile.totalCanc/st.freqFile.totalConf;
 const prev=INV.verMs;
 if(sr<0.2){INV.verMs=Math.max(300,INV.verMs-40);changes.push(`verMs ${prev}→${INV.verMs}ms [success<20%↓]`);}
 else if(sr>0.75){INV.verMs=Math.min(1400,INV.verMs+20);changes.push(`verMs ${prev}→${INV.verMs}ms [success>75%↑]`);}
 }
 return changes;
 }
 },

 INVERSE_STRAT:{
 desc:'Optimizes inverse generator: anti-search angle + anti-pattern selection',
 run(st){
 const changes=[];
 if(st.freqFile.totalConf===0)return['No confirmed freqs — INVERSE_STRAT waiting'];
 const sr=st.freqFile.totalCanc/st.freqFile.totalConf;
 // Expand anti-search rotation if success low
 changes.push(`Cancel rate: ${(sr*100).toFixed(0)}% (${st.freqFile.totalCanc}/${st.freqFile.totalConf})`);
 if(sr<0.15){changes.push(`→ Anti-search: expand to 8 steps (was ${INV.maxTry})`);INV.maxTry=8;}
 else if(sr>0.8){changes.push(`→ Anti-search: compress to 3 steps`);INV.maxTry=3;}
 // Log active inverses
 if(st.INV.active.size>0)changes.push(`Active inverses: ${st.INV.active.size}`);
 if(st.INV.failed.size>3)changes.push(` Failed queue: ${st.INV.failed.size} — clearing stale entries`);
 return changes;
 }
 },

 BOOST_SIL:{
 desc:'Emergency: aggressively boost silence when silSc stagnant',
 run(st){
 const changes=[];
 // Push all SF gains toward max
 const prev=[iLv,uLv,pLv,bLv,eLv];
 iLv=Math.min(1,iLv*1.15);uLv=Math.min(1,uLv*1.15);
 pLv=Math.min(1,pLv*1.12);bLv=Math.min(1,bLv*1.1);eLv=Math.min(1,eLv*1.1);
 updSFGains();
 if(isRun&&loopN%12===0)updSF();
 changes.push(`INF ${prev[0].toFixed(2)}→${iLv.toFixed(2)}`);
 changes.push(`ULT ${prev[1].toFixed(2)}→${uLv.toFixed(2)}`);
 changes.push(`PHF ${prev[2].toFixed(2)}→${pLv.toFixed(2)}`);
 // Increase NN reward signal
 if(NN.lr<0.025){NN.lr*=1.2;changes.push(`NN.lr×1.2 → ${NN.lr.toFixed(4)}`);}
 // Push Kalman to track faster
 if(KF.Q[0]<0.05){KF.Q[0]*=2;KF.Q[1]*=2;changes.push(`KF.Q doubled [faster tracking]`);}
 // ⑦ Cluster-Targeted Boost: target dominant cluster frequency range
 if(FREQ_CLUSTER.groups&&FREQ_CLUSTER.groups.length>0){const dom=FREQ_CLUSTER.groups.slice().sort((a,b)=>(b.count||0)-(a.count||0))[0];const cHz=((dom.min||0)+(dom.max||0))/2;if(cHz<80){iLv=Math.min(1,iLv*1.08);changes.push(`CLUSTER-BOOST INF ×1.08 [ctr ${cHz.toFixed(0)}Hz]`);}else if(cHz<500){pLv=Math.min(1,pLv*1.08);changes.push(`CLUSTER-BOOST PHF ×1.08 [ctr ${cHz.toFixed(0)}Hz]`);}else{uLv=Math.min(1,uLv*1.08);changes.push(`CLUSTER-BOOST ULT ×1.08 [ctr ${cHz.toFixed(0)}Hz]`);}}
 return changes;
 }
 },

 RESET_KF:{
 desc:'Resets Kalman filter state — use if tracking is stuck',
 run(st){
 // ⑤ Context-Anchored KF Reset: seed from AI_CTX.topFreqs if available
 const seedHz=(AI_CTX.topFreqs&&AI_CTX.topFreqs.length>0)?AI_CTX.topFreqs[0].hz:(fanFreq||0);
 KF.x=[seedHz,0];KF.P=[2,1];KF.Q=[.01,.1];KF.R=5;KF.init=seedHz>0;
 return[`KF reset: x=[${seedHz.toFixed(1)},0] P=[2,1] (seeded from ${(AI_CTX.topFreqs&&AI_CTX.topFreqs.length>0)?'AI_CTX.topFreqs':'fanFreq'})`];
 }
 },

 RESET_BAYES:{
 desc:'Resets Bayesian mixer to equal weights w₁=w₂=w₃=0.333',
 run(st){
 DRV.wS=1/3;DRV.wE=1/3;DRV.wM=1/3;
 return[`Bayesian equalized: w₁=w₂=w₃=${(1/3).toFixed(3)}`];
 }
 },

 ANALYZE:{
 desc:'Full engine state analysis + AI_CTX history + UDS stats',
 run(st){
 const lines=[];const nyq=(st.actxSR/2)||24000;
 lines.push(`Cycle:${st.aiCyc} · Silence:${st.silSc}% · Best:${st.bestSil}%`);
 lines.push(`FreqDB:${st.freqDB.size} · conf:${st.freqFile.totalConf} · canc:${st.freqFile.totalCanc}`);
 lines.push(`NN: trained=${st.NN.trainN} · loss=${st.NN.loss.toFixed(4)} · lr=${st.NN.lr.toFixed(4)}`);
 lines.push(`SF: INF=${iLv.toFixed(2)} ULT=${uLv.toFixed(2)} PHF=${pLv.toFixed(2)} SUB=${bLv.toFixed(2)}`);
 const tot=Object.values(st.FC).reduce((a,b)=>a+b,0)||1;
 const dom=Object.entries(st.FC).sort((a,b)=>b[1]-a[1])[0];
 lines.push(`DOM-class:${dom[0]} (${(dom[1]/tot*100).toFixed(0)}%)`);
 lines.push(`EVP:${(st.evpE*100).toFixed(0)}%@${st.evpHz.toFixed(1)}Hz · EMF:${(st.emfE*100).toFixed(0)}%`);
 lines.push(`Loop:${st.loopN} · err:${(st.loopE*100).toFixed(2)}%`);
 lines.push(`Bayesian w₁=${(st.DRV.wS*100).toFixed(0)}% w₂=${(st.DRV.wE*100).toFixed(0)}% w₃=${(st.DRV.wM*100).toFixed(0)}%`);
 // Recommendations
 if(st.silSc<20)lines.push('→ RUN: BOOST_SIL (silence critical)');
 else if(st.silSc<50)lines.push('→ RUN: OPTIMIZE_SF + TUNE_NN');
 if(st.NN.loss>0.5)lines.push('→ RUN: TUNE_NN (high loss)');
 if(st.freqDB.size>80)lines.push('→ RUN: ADAPT_THRESH (large DB)');
 if(st.freqFile.totalConf>5&&st.freqFile.totalCanc/st.freqFile.totalConf<0.2)
 lines.push('→ RUN: INVERSE_STRAT (low cancel rate)');
 // AI_CTX derived insights
 if(AI_CTX.ready){
 lines.push(`# db: topHz=${AI_CTX.topFreqs.map(f=>f.hz+'(×'+f.count+')').slice(0,3).join(' ')}`);
 lines.push(`# db: cohTrend=${AI_CTX.cohTrend.toFixed(3)} Δ=${AI_CTX.cohDelta.toFixed(3)} nnTrend=${AI_CTX.nnLossTrend.toFixed(5)}`);
 lines.push(`# db: patterns=${AI_CTX.confirmedPatterns.length} bestProg=${AI_CTX.bestProg||'—'} execStats=${Object.keys(AI_CTX.execStats).length}`);
 if(AI_CTX.bestProg&&AI_LIB[AI_CTX.bestProg])
 lines.push(`→ PREFERRED: ${AI_CTX.bestProg} (highest silence gain in history)`);
 }
 // ⑥ FreqDB Entropy Monitor: measure distribution spread of spectral energy
 if(st.freqDB.size>2){let eTot=0,eEnt=0;st.freqDB.forEach(v=>{eTot+=(v.energy||0.01);});st.freqDB.forEach(v=>{const p=(v.energy||0.01)/eTot;if(p>0)eEnt-=p*Math.log2(p);});const mxE=Math.log2(st.freqDB.size);const nEnt=mxE>0?eEnt/mxE:0;lines.push(`FreqDB entropy: ${eEnt.toFixed(2)}bits · norm=${nEnt.toFixed(2)} (${nEnt<0.3?'NARROW':nEnt>0.85?'WIDE':'MIXED'})`);if(nEnt<0.2&&st.freqDB.size>10)lines.push('→ Low entropy: overfitting narrow band — consider RESET_KF');}
 return lines;
 }
 },

 SELF_OPTIMIZE:{
 desc:'Meta-program: adapts to history — runs META_ADAPT then top effective programs',
 run(st){
 const log=[];
 // ⑩ PERSIST History Seed: if stored history >> active bans, elevate INVERSE_STRAT
 const pTotal=PERSIST.totalCount();if(pTotal>AI_BAN.size*1.5)log.push(`PERSIST History: ${pTotal} stored > ${AI_BAN.size} active — elevating INVERSE_STRAT`);
 // 1. Always analyze first
 log.push('--- ANALYZE ---');log.push(...AI_LIB.ANALYZE.run(st));
 // 2. Run META_ADAPT to learn which programs are effective
 log.push('--- META_ADAPT ---');log.push(...AI_LIB.META_ADAPT.run(st));
 // 3. Build adaptive run list from ranked programs (skip low-eff)
 const alwaysRun=['OPTIMIZE_SF','TUNE_NN','ADAPT_THRESH'];
 const extras=[];
 if(st.freqFile.totalConf>3)extras.push('INVERSE_STRAT');
 if(AI_CTX.confirmedPatterns.length>0)extras.push('FREQ_PREDICT');
 if(st.freqDB.size>=5)extras.push('PATTERN_LEARN');
 // Rank by effectiveness from META_ADAPT output
 const ranked=AI_CTX.rankedProgs.length
 ? AI_CTX.rankedProgs.filter(n=>AI_LIB[n]&&!AI_CTX.lowEffProgs.has(n))
 : alwaysRun;
 const toRun=[...new Set([...ranked.slice(0,3),...alwaysRun,...extras])].slice(0,6);
 toRun.forEach(name=>{
 if(AI_LIB[name]){log.push(`--- ${name} ---`);log.push(...AI_LIB[name].run(st));}
 });
 return log;
 }
 },

 FREQ_PREDICT:{
 desc:'Predicts next dominant frequencies from pattern history → pre-positions inverses',
 run(st){
 const lines=[];
 if(!AI_CTX.confirmedPatterns.length&&st.freqDB.size===0)
 return['FREQ_PREDICT: no pattern data yet — run longer to capture freqs'];
 // Use both confirmed patterns and freqDB
 const allHz=[];
 AI_CTX.confirmedPatterns.forEach(p=>allHz.push({hz:parseFloat(p.hz),w:p.count||1}));
 if(!allHz.length)freqDB.forEach((v,k)=>allHz.push({hz:parseFloat(k),w:v.count||1}));
 if(!allHz.length)return['FREQ_PREDICT: FreqDB empty'];
 allHz.sort((a,b)=>b.w-a.w);
 const topHz=allHz[0].hz;
 // Harmonic series prediction
 const harmonics=[1,2,3,4].map(n=>parseFloat((topHz*n).toFixed(1)));
 const subHarm=parseFloat((topHz/2).toFixed(1));
 lines.push(`Dominant source: ${topHz}Hz (w=${allHz[0].w})`);
 lines.push(`Harmonic series: ${harmonics.join('Hz · ')}Hz`);
 lines.push(`Sub-harmonic: ${subHarm}Hz`);
 // Band analysis
 const bands={sub:allHz.filter(f=>f.hz<20),inf:allHz.filter(f=>f.hz>=20&&f.hz<200),aud:allHz.filter(f=>f.hz>=200&&f.hz<2000),hf:allHz.filter(f=>f.hz>=2000)};
 const domBand=Object.entries(bands).sort((a,b)=>b[1].length-a[1].length)[0];
 lines.push(`Band distribution: sub=${bands.sub.length} inf=${bands.inf.length} aud=${bands.aud.length} hf=${bands.hf.length}`);
 lines.push(`Dominant band: ${domBand[0]} (${domBand[1].length} entries)`);
 // Frequency spacing → noise type hint
 if(allHz.length>2){
 const intervals=[];
 for(let i=1;i<Math.min(allHz.length,6);i++)intervals.push(Math.abs(allHz[i].hz-allHz[i-1].hz));
 const avgInt=intervals.reduce((a,b)=>a+b,0)/intervals.length;
 const noiseHint=avgInt<30?'harmonic hum':avgInt<200?'tonal noise':'broadband';
 lines.push(`Freq spacing: avg=${avgInt.toFixed(0)}Hz → ${noiseHint}`);
 }
 // Store prediction
 const predicted=harmonics[1]; // 2nd harmonic most likely next
 AI_CTX.predictedHz=predicted;
 lines.push(`→ PREDICTED NEXT: ${predicted}Hz (2nd harmonic)`);
 lines.push(`→ PRE-ARM: queued inverse for ${predicted}Hz`);
 // ③ Recurrence-Guided Prediction: ETA from RECURRENCE.period
 if(RECURRENCE.period>0&&RECURRENCE.det>0.5){const etaCyc=RECURRENCE.period-((aiCyc)%RECURRENCE.period||RECURRENCE.period);lines.push(`→ RECURRENCE: period=${RECURRENCE.period}cyc · det=${RECURRENCE.det.toFixed(2)} · ETA ~${etaCyc} cycles`);}
 return lines;
 }
 },

 PATTERN_LEARN:{
 desc:'K-means clustering of freqDB → noise signature → adapts Bayesian weights',
 run(st){
 const lines=[];
 if(st.freqDB.size<5)return[`PATTERN_LEARN: FreqDB=${st.freqDB.size} (need ≥5)`];
 // Extract frequency list
 const freqs=[...freqDB.keys()].map(k=>({hz:parseFloat(k),count:freqDB.get(k).count||1}));
 freqs.sort((a,b)=>a.hz-b.hz);
 const hzArr=freqs.map(f=>f.hz);
 // 1D k-means with k=3, 10 iterations
 let c=[hzArr[0],hzArr[Math.floor(hzArr.length/2)],hzArr[hzArr.length-1]];
 for(let iter=0;iter<10;iter++){
 const g=[[],[],[]];
 hzArr.forEach(hz=>{const d=c.map(ci=>Math.abs(hz-ci));g[d.indexOf(Math.min(...d))].push(hz);});
 c=g.map((gr,i)=>gr.length?gr.reduce((a,b)=>a+b,0)/gr.length:c[i]);
 }
 lines.push(`Clusters: A=${c[0].toFixed(0)}Hz · B=${c[1].toFixed(0)}Hz · C=${c[2].toFixed(0)}Hz`);
 // Noise signature from cluster spread
 const spread=c[2]-c[0];
 let sig='unknown';
 if(spread<50)sig='tonal/hum';
 else if(spread<300)sig='narrowband';
 else if(spread<2000)sig='mixed';
 else sig='wideband';
 AI_CTX.noiseSignature=sig;
 lines.push(`Noise signature: ${sig} (spread=${spread.toFixed(0)}Hz)`);
 // Bayesian weight optimization per signature
 const prev={wS:DRV.wS.toFixed(2),wE:DRV.wE.toFixed(2),wM:DRV.wM.toFixed(2)};
 if(sig==='tonal/hum'){DRV.wS=0.60;DRV.wE=0.25;DRV.wM=0.15;}
 else if(sig==='narrowband'){DRV.wS=0.45;DRV.wE=0.35;DRV.wM=0.20;}
 else if(sig==='mixed'){DRV.wS=0.35;DRV.wE=0.35;DRV.wM=0.30;}
 else if(sig==='wideband'){DRV.wS=0.25;DRV.wE=0.45;DRV.wM=0.30;}
 lines.push(`Bayes ${prev.wS}/${prev.wE}/${prev.wM} → ${DRV.wS.toFixed(2)}/${DRV.wE.toFixed(2)}/${DRV.wM.toFixed(2)} [${sig}]`);
 // Most weighted frequencies
 const topFreqs=freqs.sort((a,b)=>b.count-a.count).slice(0,3);
 lines.push(`Top targets: ${topFreqs.map(f=>f.hz+'Hz(×'+f.count+')').join(' · ')}`);
 // Coherence feedback
 if(AI_CTX.cohTrend>0.7)lines.push(`→ High coherence (${AI_CTX.cohTrend.toFixed(2)}) — stay course`);
 else if(AI_CTX.cohTrend<0.3)lines.push(`→ Low coherence (${AI_CTX.cohTrend.toFixed(2)}) — consider RESET_KF`);
 // ④ Hebbian-Pattern Co-Registration: reinforce inter-cluster frequency pairs
 if(c.length>=2){hebbLearn(c[0],c[1],.05);if(c[2])hebbLearn(c[1],c[2],.03);lines.push(`Hebbian: reinforced ${c[0].toFixed(0)}↔${c[1].toFixed(0)}Hz cluster pair`);}
 return lines;
 }
 },

 META_ADAPT:{
 desc:'Meta-learning: ranks programs by silence efficiency (UCB1) → reshapes exec schedule',
 run(st){
 const lines=[];
 const stats=AI_CTX.execStats;
 if(!stats||!Object.keys(stats).length)
 return['META_ADAPT: no exec history yet — needs more cycles'];
 // Compute efficiency = avgSil / (avgMs + 1) — silence per millisecond
 const totalRuns=Object.values(stats).reduce((a,s)=>a+s.runs,0)||1;
 const eff=Object.entries(stats).map(([name,s])=>{
 const avgSil=parseFloat(s.avgSil)||0;
 const avgMs=parseFloat(s.avgMs)||1;
 const runs=s.runs||1;
 const exploit=avgSil;
 const explore=2*Math.sqrt(Math.log(totalRuns)/runs);
 return{name,eff:avgSil/(avgMs+1),ucb:exploit+explore,runs,avgSil,avgMs};
 }).sort((a,b)=>b.ucb-a.ucb);
 lines.push(`UCB1 ranking (runs=${totalRuns}):`);
 eff.slice(0,6).forEach((e,i)=>
 lines.push(` ${i+1}. ${e.name}: sil=${e.avgSil.toFixed(1)}% ucb=${e.ucb.toFixed(2)} runs=${e.runs}`));
 // Update AI_CTX
 AI_CTX.rankedProgs=eff.map(e=>e.name);
 // Flag underperformers (eff<0.01 with ≥8 runs)
 const underperf=eff.filter(e=>e.eff<0.01&&e.runs>=8);
 AI_CTX.lowEffProgs=new Set(underperf.map(e=>e.name));
 if(underperf.length)lines.push(`Low-eff (skip): ${underperf.map(e=>e.name).join(' ')}`);
 // Set priority program
 const top=eff[0];
 if(top&&top.avgSil>silSc+3){
 AI_CTX.priorityProg=top.name;
 lines.push(`→ PRIORITY → ${top.name} (sil gain=${( top.avgSil-silSc).toFixed(1)}%)`);
 } else {
 AI_CTX.priorityProg=null;
 lines.push(`→ No single dominant — balanced scheduling`);
 }
 // Noise signature context
 if(AI_CTX.noiseSignature!=='unknown')
 lines.push(`Noise: ${AI_CTX.noiseSignature} · cohTrend=${AI_CTX.cohTrend.toFixed(2)}`);
 // ② META Loss Trend Gate: NN stagnation → auto-trigger RESET_BAYES
 if(NN.hist.length>=20){const sl20=NN.hist.slice(-20);const lSlope=Math.abs((sl20[19].loss-sl20[0].loss)/20);if(lSlope<0.0002&&NN.loss>0.3){AI_LIB.RESET_BAYES.run(st);lines.push(`RESET_BAYES triggered [NN stagnant Δloss=${lSlope.toFixed(6)}]`);}}
 return lines;
 }
 },

 FREQ_GATE:{
 desc:'AI ban/unban gate: detects chronically-failing freqs → bans them to free resources',
 run(st){
 const lines=[];
 if(!AI_GATE.enabled)return['FREQ_GATE: gate disabled (AI_GATE.enabled=false)'];
 // Auto-unban expired entries
 let unbanned=0;
 AI_BAN.forEach((d,bin)=>{
 if(execCyc>=d.autoUnbanAt){AI_BAN.delete(bin);unbanned++;}
 else{d.cycles=execCyc-d.bannedAt;}
 });
 if(unbanned)lines.push(`Auto-unbanned: ${unbanned} frequencies (trial re-entry)`);
 // Scan INV.failed for chronic high-fail frequencies
 const failCandidates=[];
 INV.failed.forEach((d,hz)=>{
 const bin=fBin(hz);
 if(AI_BAN.has(bin))return; // already banned
 // Get active inverse attempts
 const activeInv=st.INV.active.get(hz);
 const attempts=activeInv?activeInv.attempts:INV.maxTry;
 if(attempts>=AI_GATE.failThresh){
 const entry=freqDB.get(bin);
 if(entry&&entry.confirmed){
 failCandidates.push({hz,bin,attempts,energy:entry.energy});
 }
 }
 });
 // Also check confirmed freqs with no successful inverse
 freqDB.forEach((e,bin)=>{
 if(!e.confirmed||AI_BAN.has(bin))return;
 // If confirmed but no inverse succeeded after many attempts
 if(e.invOk===false&&e.count>FREQ_THRESH*2){
 const score=e.energy/(e.count||1);
 if(score<0.01){failCandidates.push({hz:parseFloat(bin),bin:parseFloat(bin),attempts:e.count,energy:e.energy});}
 }
 });
 // Deduplicate
 const unique=[];const seen=new Set();
 failCandidates.forEach(f=>{if(!seen.has(f.bin)){seen.add(f.bin);unique.push(f);}});
 if(unique.length===0){
 lines.push(`FREQ_GATE: ${AI_BAN.size} banned · no new candidates`);
 lines.push(`Watched: ${INV.failed.size} failed inverse entries`);
 return lines;
 }
 // Ban up to available slots — السقف على الجديد فقط (بدون الأساسي/المؤكَّد)
 const slots=AI_GATE.maxBan-newBanCount();
 const toBan=unique.slice(0,Math.max(0,slots));
 toBan.forEach(f=>{
 // ⑧ Recurrence-Weighted Ban: amplify ban priority if freq aligns with recurrence period
 const recW=RECURRENCE.det>0.5&&Math.abs(f.hz-fanFreq)<(fanFreq*.05)?2:1;
 banFreq(f.hz,'GATE:fail×'+f.attempts+(recW>1?'+REC':''));
 lines.push(`→ BANNED ${f.hz.toFixed(2)}Hz (fail×${f.attempts} energy=${(f.energy*100).toFixed(1)}%${recW>1?' +RECURRENCE':''})`);
 });
 const skipped=unique.length-toBan.length;
 lines.push(`Total banned: ${AI_BAN.size} (new: ${newBanCount()}/${AI_GATE.maxBan})${skipped>0?' (+'+skipped+' queue full)':''}`);
 // Report current ban list
 if(AI_BAN.size){
 lines.push('Active bans:');
 [...AI_BAN.entries()].slice(0,6).forEach(([hz,d])=>lines.push(` ${hz.toFixed(2)}Hz [${d.reason}] منذ c${d.bannedAt}`));
 }
 renderBanList();
 return lines;
 }
 }
};

/* ══ EXEC ENGINE ══ */
