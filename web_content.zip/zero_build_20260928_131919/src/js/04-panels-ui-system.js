/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 04-panels-ui-system.js
 نظام اللوحات المشترك بالكامل: كل openXPanel/closeXPanel + closeAll + _wireSheetDrag + لوحة الأذونات ومراقب الجهاز
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */
function closePipe(){pOpen=false;if(!sOpen&&!aOpen&&!zpOpen&&!dmOpen&&!menuOpen&&!filesOpen&&!tOpen&&!maskOpen&&!physOpen&&!aboutOpen&&!privacyOpen&&!loopDiagOpen)E('ovl').classList.remove('on');E('ppnl').classList.remove('open');}
function openAIP(){aOpen=true;E('ovl').classList.add('on');E('aiPanel').classList.add('open');zVibrate(6);}
function closeAIP(){aOpen=false;if(!sOpen&&!pOpen&&!zpOpen&&!dmOpen&&!menuOpen&&!filesOpen&&!tOpen&&!maskOpen&&!physOpen&&!aboutOpen&&!privacyOpen&&!loopDiagOpen)E('ovl').classList.remove('on');E('aiPanel').classList.remove('open');}
/* ── القائمة الرئيسية (Menu) — تجمع كل أقسام التطبيق، تُفتح من زر الهامبرغر ── */
function toggleMenu(){menuOpen?closeMenu():openMenu();}
function openMenu(){menuOpen=true;E('ovl').classList.add('on');E('menuPanel').classList.add('open');E('mBtn').classList.add('open');zVibrate(6);}
function closeMenu(){menuOpen=false;if(!sOpen&&!pOpen&&!aOpen&&!zpOpen&&!dmOpen&&!filesOpen&&!tOpen&&!maskOpen&&!physOpen&&!aboutOpen&&!privacyOpen&&!loopDiagOpen)E('ovl').classList.remove('on');E('menuPanel').classList.remove('open');E('mBtn').classList.remove('open');}
/* ── نافذة "الملفات" — تصدير/استيراد قائمة الترددات المحظورة ── */
function openFilesPanel(){
 filesOpen=true;E('ovl').classList.add('on');E('filesPanel').classList.add('open');zVibrate(6);
 updateFolderAccessUI();
 const sr=E('share-row');if(sr)sr.style.display=(typeof navigator.share==='function')?'':'none';
 const cr=E('clip-row');if(cr)cr.style.display=(navigator.clipboard&&typeof navigator.clipboard.writeText==='function')?'':'none';
 const cir=E('clip-import-row');if(cir)cir.style.display=(navigator.clipboard&&typeof navigator.clipboard.readText==='function')?'':'none';
}
function closeFilesPanel(){filesOpen=false;if(!sOpen&&!pOpen&&!aOpen&&!zpOpen&&!dmOpen&&!menuOpen&&!tOpen&&!maskOpen&&!physOpen&&!aboutOpen&&!privacyOpen&&!loopDiagOpen)E('ovl').classList.remove('on');E('filesPanel').classList.remove('open');}
function closeAll(){closeSheet();closePipe();closeAIP();closeZPPanel();closeDevMon();closeMenu();closeFilesPanel();if(typeof closeTerm!=='undefined')closeTerm();if(typeof closeMaskPanel!=='undefined')closeMaskPanel();if(typeof closePhysPanel!=='undefined')closePhysPanel();if(typeof closeAboutPanel!=='undefined')closeAboutPanel();if(typeof closePrivacyPanel!=='undefined')closePrivacyPanel();if(typeof closeLoopDiagPanel!=='undefined')closeLoopDiagPanel();}

/* ── غرفة الصمت (Masking Noise) — فتح/إغلاق اللوحة، النمط نفسه المتَّبع لبقية اللوحات ── */
function openMaskPanel(){maskOpen=true;E('ovl').classList.add('on');E('maskPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);}
function closeMaskPanel(){maskOpen=false;if(!sOpen&&!pOpen&&!aOpen&&!zpOpen&&!dmOpen&&!menuOpen&&!filesOpen&&!tOpen&&!physOpen&&!aboutOpen&&!privacyOpen&&!loopDiagOpen)E('ovl').classList.remove('on');const p=E('maskPanel');if(p)p.classList.remove('open');}

/* ── فيزياء الإلغاء (Cancellation Physics) — فتح/إغلاق اللوحة، نفس نمط بقية اللوحات ── */
function openPhysPanel(){physOpen=true;E('ovl').classList.add('on');E('physPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);if(typeof physDrawLoop==='function')physDrawLoop();if(typeof physSimDraw==='function')physSimDraw();}
function closePhysPanel(){physOpen=false;if(!sOpen&&!pOpen&&!aOpen&&!zpOpen&&!dmOpen&&!menuOpen&&!filesOpen&&!tOpen&&!maskOpen&&!aboutOpen&&!privacyOpen&&!loopDiagOpen)E('ovl').classList.remove('on');const p=E('physPanel');if(p)p.classList.remove('open');if(physAnimFrame){cancelAnimationFrame(physAnimFrame);physAnimFrame=null;}}

/* ── الحلقة المغلقة (Closed-Loop diagram) — فتح/إغلاق + حلقة تنبيه المراحل ── */
let loopDiagTimer=null,loopDiagPhase=0;
function openLoopDiagPanel(){loopDiagOpen=true;E('ovl').classList.add('on');E('loopDiagPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);loopDiagPhase=0;animateLoopDiagram();}
function closeLoopDiagPanel(){loopDiagOpen=false;if(!sOpen&&!pOpen&&!aOpen&&!zpOpen&&!dmOpen&&!menuOpen&&!filesOpen&&!tOpen&&!maskOpen&&!physOpen&&!aboutOpen&&!privacyOpen)E('ovl').classList.remove('on');const p=E('loopDiagPanel');if(p)p.classList.remove('open');if(loopDiagTimer){clearTimeout(loopDiagTimer);loopDiagTimer=null;}}
function animateLoopDiagram(){
 if(!loopDiagOpen)return;
 const steps=['lfStepMic','lfStepAI','lfStepProc','lfStepSpk','lfStepMeas','lfStepZero'];
 const arrows=['lfArr1','lfArr2','lfArr3','lfArr4','lfArr5'];
 steps.forEach(s=>{const el=E(s);if(el)el.classList.remove('active-step','processing','zero-step');});
 arrows.forEach(a=>{const el=E(a);if(el)el.classList.remove('active');});
 const ms=E('lfMeasSub');if(ms)ms.textContent=isRun?('Coherence γ²(f) — '+(typeof silSc!=='undefined'?silSc:0)+'%'):'Coherence γ²(f)';
 if(!isRun){loopDiagTimer=setTimeout(animateLoopDiagram,600);return;}
 const idx=loopDiagPhase%steps.length;
 const el=E(steps[idx]);
 if(el)el.classList.add(idx===2?'processing':idx===steps.length-1?'zero-step':'active-step');
 if(idx<arrows.length){const ae=E(arrows[idx]);if(ae)ae.classList.add('active');}
 loopDiagPhase++;
 loopDiagTimer=setTimeout(animateLoopDiagram,600);
}

/* ── حول التطبيق / الخصوصية — فتح/إغلاق، نفس نمط بقية اللوحات ── */
function openAboutPanel(){aboutOpen=true;E('ovl').classList.add('on');E('aboutPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);}
function closeAboutPanel(){aboutOpen=false;if(!sOpen&&!pOpen&&!aOpen&&!zpOpen&&!dmOpen&&!menuOpen&&!filesOpen&&!tOpen&&!maskOpen&&!physOpen&&!privacyOpen&&!loopDiagOpen)E('ovl').classList.remove('on');const p=E('aboutPanel');if(p)p.classList.remove('open');}
function openPrivacyPanel(){privacyOpen=true;E('ovl').classList.add('on');E('privacyPanel').classList.add('open');if(typeof zVibrate==='function')zVibrate(6);}
function closePrivacyPanel(){privacyOpen=false;if(!sOpen&&!pOpen&&!aOpen&&!zpOpen&&!dmOpen&&!menuOpen&&!filesOpen&&!tOpen&&!maskOpen&&!physOpen&&!aboutOpen&&!loopDiagOpen)E('ovl').classList.remove('on');const p=E('privacyPanel');if(p)p.classList.remove('open');}

/* ── PERMS MGMT PANEL ── */
const PERMS_MGMT=[
 {id:'RECORD_AUDIO',ico:'',name:'الميكروفون',desc:'تسجيل الصوت لتحليل الضوضاء',err:' هذا الإذن ضروري — لن يعمل تحليل الصوت بدونه'},
 {id:'POST_NOTIFICATIONS',ico:'',name:'الإشعارات',desc:'تنبيهات العمليات في الخلفية',err:'ℹ لن تظهر إشعارات الخلفية — يمكن تفعيله لاحقاً من إعدادات الجهاز'},
 {id:'MANAGE_STORAGE',ico:'',name:'إدارة الملفات',desc:'حفظ بيانات التطبيق والسجلات',err:' ضروري لحفظ البيانات — اضغط مرة أخرى لفتح إعدادات الجهاز'},
 {id:'MEDIA_AUDIO',ico:'',name:'ملفات الصوت',desc:'الوصول لملفات الصوت في الجهاز',err:' ضروري للوصول لملفات الصوت — اضغط للمحاولة مجدداً'}
];
function openZPPanel(){
 zpOpen=true;
 E('ovl').classList.add('on');
 E('zpPanel').classList.add('open');
 zVibrate(6);
 zpRefreshAll();
 window.onPermResult=zpOnPermResult;
 window.onPermPermanentDenied=zpOnPermPermanentDenied;
}
function closeZPPanel(){
 if(!zpOpen)return;
 zpOpen=false;
 if(!sOpen&&!pOpen&&!aOpen&&!dmOpen&&!menuOpen&&!filesOpen&&!tOpen&&!maskOpen&&!physOpen&&!aboutOpen&&!privacyOpen&&!loopDiagOpen)E('ovl').classList.remove('on');
 E('zpPanel').classList.remove('open');
 window.onPermResult=null;
 window.onPermPermanentDenied=null;
}

/* ══════════════════════════════════════════════
 DEVICE MONITOR — open / close / refresh
══════════════════════════════════════════════ */
function openDevMon(){
 dmOpen=true;
 E('ovl').classList.add('on');
 E('devPanel').classList.add('open');
 zVibrate(6);
 // مراجعة تتمة إصلاح "الوميض/التجمّد المؤقت عند فتح التطبيق وتبديل القوائم": dmRefresh()
 // تُجري عدّة نداءات bridge متزامنة دفعة واحدة (getRamInfo/getBatteryInfo/getCpuInfo/
 // getStorageInfo/getNetworkType/getAppMemory) من بينها getThermalZones() التي تقرأ فعلياً
 // ملفات /sys/class/thermal من القرص (حتى عشرات المناطق الحرارية على بعض الأجهزة، ملفَّين
 // لكل منطقة) — واستدعاء JS إلى دالة @JavascriptInterface يُوقِف تنفيذ JS بانتظار عودة
 // Java، تماماً كأي نداء متزامن. كان هذا النداء الثقيل يُنفَّذ في نفس دورة JS المتزامنة التي
 // أضافت صنف 'open' للتوّ أعلاه — فيمنع المتصفح من رسم أول إطار لانتقال انزلاق اللوحة
 // (CSS transform .38s) إلى أن تنتهي كل تلك القراءات، ما يبدو بالضبط كـ"تجمّد مؤقت" عند
 // فتح هذه اللوحة تحديداً. الإصلاح: تأجيل النداء الثقيل الأول بإطار واحد فقط (rAF) — يترك
 // للمتصفح فرصة لبدء رسم الانتقال أولاً؛ فارق التأخير (~16ms) غير مُدرَك إطلاقاً في ظهور
 // الإحصائيات نفسها.
 requestAnimationFrame(dmRefresh);
 if(!dmTimer)dmTimer=setInterval(dmRefresh,3000);
}
function closeDevMon(){
 if(!dmOpen)return;
 dmOpen=false;
 if(!sOpen&&!pOpen&&!aOpen&&!zpOpen&&!menuOpen&&!filesOpen&&!tOpen&&!maskOpen&&!physOpen&&!aboutOpen&&!privacyOpen&&!loopDiagOpen)E('ovl').classList.remove('on');
 E('devPanel').classList.remove('open');
 if(dmTimer){clearInterval(dmTimer);dmTimer=null;}
 removeThermalAlert();
}
/* ── Sparkline renderer ── */
function renderSpark(svgId,data,maxVal,defaultColor,warnThresh,hotThresh){
 const svg=E(svgId);
 if(!svg||data.length<2)return;
 const W=100,H=30;
 const lo=Math.max(0,Math.min(...data)-5);
 const hi=Math.max(maxVal,Math.max(...data)+5);
 const pts=data.length;
 const step=W/(pts-1);
 const scaleY=v=>H-((v-lo)/(hi-lo))*H*0.88-H*0.06;
 const coords=data.map((v,i)=>(i*step).toFixed(1)+','+scaleY(v).toFixed(1));
 const last=data[data.length-1];
 const lx=((pts-1)*step).toFixed(1);
 const ly=scaleY(last).toFixed(1);
 const c=last>=hotThresh?'#808080':last>=warnThresh?'#b0b0b0':defaultColor;
 svg.innerHTML=`<polyline points="${coords.join(' ')}" fill="none" stroke="${c}" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round" opacity=".9"/><circle cx="${lx}" cy="${ly}" r="2.5" fill="${c}"/><text x="${lx}" y="${parseFloat(ly)-5}" text-anchor="middle" font-size="6" fill="${c}" font-family="monospace">${last%1===0?last:last.toFixed(1)}</text>`;
}
/* ── Thermal alert ── */
function showThermalAlert(msg){
 let el=E('dm-thermal-alert');
 if(!el){
 el=document.createElement('div');
 el.id='dm-thermal-alert';
 el.className='dm-alert';
 E('app').appendChild(el);
 }
 el.innerHTML='<span class="dm-alert-ico"></span><span class="dm-alert-txt">'+msg+'</span><span class="dm-alert-cl" onclick="removeThermalAlert()">✕</span>';
 el.hidden=false;
 setThermalThrottle(true);
}
function removeThermalAlert(){
 const el=E('dm-thermal-alert');
 if(el)el.hidden=true;
 setThermalThrottle(false);
}
/* ── Memory pressure callbacks from Android ── */
window.onLowMemory=function(severity){
 if(typeof stLog==='function')stLog(' ذاكرة حرجة ('+severity+') — تم تحرير الكاش');
 if(severity==='critical')setThermalThrottle(true);
 if(dmOpen)dmRefresh();
};
window.onTrimMemory=function(level,code){
 if(level==='critical'||level==='moderate'){
 if(typeof stLog==='function')stLog(' ضغط ذاكرة ('+level+' / '+code+')');
 if(level==='critical')setThermalThrottle(true);
 else if(level==='low')setThermalThrottle(false);
 }
 if(dmOpen)dmRefresh();
};
function dmScroll(dir){
 const s=E('devPanel').querySelector('.dm-scr');
 if(s)s.scrollBy({top:dir*160,behavior:'smooth'});
}
function dmRefresh(){
 const za=window.ZeroAndroid;
 const now=new Date();
 const ts=now.getHours().toString().padStart(2,'0')+':'+now.getMinutes().toString().padStart(2,'0')+':'+now.getSeconds().toString().padStart(2,'0');
 E('dm-ts')&&(E('dm-ts').textContent='آخر تحديث: '+ts);

 // ── helpers ──
 function tempBadge(el,c){
 if(!el)return;
 if(c>=55){el.textContent=c.toFixed(1)+'°C ';el.className='dm-badge hot';}
 else if(c>=40){el.textContent=c.toFixed(1)+'°C';el.className='dm-badge warm';}
 else{el.textContent=c.toFixed(1)+'°C';el.className='dm-badge cool';}
 }
 function tempClass(c){return c>=55?'hot':c>=40?'warm':'cool';}
 function fmtMB(mb){return mb>=1024?(mb/1024).toFixed(1)+' GB':mb+' MB';}

 // ── RAM ──
 if(za&&za.getRamInfo){
 try{
 const r=JSON.parse(za.getRamInfo());
 if(r.totalMB){
 E('dm-ram-used')&&(E('dm-ram-used').textContent=fmtMB(r.usedMB)+' ('+r.usedPct+'%)');
 E('dm-ram-avail')&&(E('dm-ram-avail').textContent=fmtMB(r.availMB));
 E('dm-ram-total')&&(E('dm-ram-total').textContent=fmtMB(r.totalMB));
 const bEl=E('dm-ram-bar');if(bEl)bEl.style.width=Math.min(r.usedPct,100)+'%';
 const bg=E('dm-ram-badge');
 if(bg){if(r.usedPct>=80){bg.textContent=r.usedPct+'% عالٍ';bg.className='dm-badge hot';}
 else if(r.usedPct>=60){bg.textContent=r.usedPct+'%';bg.className='dm-badge warm';}
 else{bg.textContent=r.usedPct+'%';bg.className='dm-badge cool';}}
 // Device mem for info section
 E('dm-dev-mem')&&(E('dm-dev-mem').textContent=fmtMB(r.totalMB));
 }
 }catch(e){}
 }

 // ── Battery ──
 if(za&&za.getBatteryInfo){
 try{
 const b=JSON.parse(za.getBatteryInfo());
 if(b.tempC!==undefined){
 E('dm-bat-temp')&&(E('dm-bat-temp').textContent=b.tempC.toFixed(1)+'°C / '+(b.tempC*9/5+32).toFixed(1)+'°F');
 E('dm-bat-level')&&(E('dm-bat-level').textContent=b.levelPct+'%');
 const bb=E('dm-bat-bar');if(bb)bb.style.width=Math.min(b.levelPct,100)+'%';
 E('dm-bat-volt')&&(E('dm-bat-volt').textContent=(b.voltageMV/1000).toFixed(2)+' V');
 E('dm-bat-status')&&(E('dm-bat-status').textContent=b.isCharging?'يشحن الآن':'على البطارية');
 E('dm-bat-health')&&(E('dm-bat-health').textContent=b.health||'—');
 const bb2=E('dm-bat-badge');
 if(bb2)tempBadge(bb2,b.tempC);
 }
 }catch(e){}
 }

 // ── CPU ──
 if(za&&za.getCpuInfo){
 try{
 const c=JSON.parse(za.getCpuInfo());
 E('dm-cpu-cores')&&(E('dm-cpu-cores').textContent=(c.cores||navigator.hardwareConcurrency||'—')+' نواة');
 E('dm-dev-cores')&&(E('dm-dev-cores').textContent=(c.cores||navigator.hardwareConcurrency||'—')+' أنوية');
 if(c.curMHz){
 const ghz=c.curMHz>=1000?(c.curMHz/1000).toFixed(2)+' GHz':c.curMHz+' MHz';
 const mxghz=c.maxMHz>=1000?(c.maxMHz/1000).toFixed(2)+' GHz':c.maxMHz+' MHz';
 E('dm-cpu-freq')&&(E('dm-cpu-freq').textContent=ghz+' / '+mxghz);
 const cb=E('dm-cpu-bar');if(cb)cb.style.width=Math.min(c.freqPct,100)+'%';
 const cbg=E('dm-cpu-badge');
 if(cbg){cbg.textContent=c.freqPct+'%';cbg.className='dm-badge '+(c.freqPct>=80?'hot':c.freqPct>=50?'warm':'cool');}
 }
 }catch(e){}
 } else {
 // Fallback: JS navigator
 const cores=navigator.hardwareConcurrency||'—';
 E('dm-cpu-cores')&&(E('dm-cpu-cores').textContent=cores+' نواة');
 E('dm-dev-cores')&&(E('dm-dev-cores').textContent=cores+' أنوية');
 }

 // ── Thermal Zones ──
 if(za&&za.getThermalZones){
 try{
 const zones=JSON.parse(za.getThermalZones());
 const grid=E('dm-thermal-grid');
 if(grid&&zones.length){
 // Sort hottest first, show top 12 max
 zones.sort((a,b)=>b.tempC-a.tempC);
 const top=zones.slice(0,12);
 grid.innerHTML=top.map(z=>{const cls=tempClass(z.tempC);const pct=Math.min(Math.max((z.tempC-20)/80*100,0),100).toFixed(0);const f=(z.tempC*9/5+32).toFixed(1);return`<div class="dm-th-row"><div class="dm-th-name">${z.name}</div><div class="dm-th-fill-row"><div class="dm-th-fill-w"><div class="dm-th-fill ${cls}" style="width:${pct}%"></div></div><div class="dm-th-val ${cls}">${z.tempC.toFixed(1)}°C / ${f}°F</div></div></div>`;}).join('');
 // CPU temp from hottest relevant zone (cpu, big, cluster, etc.)
 const cpuZ=zones.find(z=>/cpu|big|little|cluster|core|tsens/i.test(z.name));
 if(cpuZ){
 E('dm-cpu-temp')&&(E('dm-cpu-temp').textContent=cpuZ.tempC.toFixed(1)+'°C / '+(cpuZ.tempC*9/5+32).toFixed(1)+'°F');
 const cbg=E('dm-cpu-badge');
 if(cbg)tempBadge(cbg,cpuZ.tempC);
 }
 } else if(grid){
 grid.innerHTML='<div class="dm-th-row"><div class="dm-th-name">لا توجد مناطق حرارية</div><div class="dm-th-fill-row"><div class="dm-th-fill-w"><div class="dm-th-fill cool" style="width:0%"></div></div><div class="dm-th-val cool">—</div></div></div>';
 }
 }catch(e){}
 }

 // ── JS Heap (built-in browser API) ──
 if(performance&&performance.memory){
 const pm=performance.memory;
 const used=Math.round(pm.usedJSHeapSize/1048576);
 const limit=Math.round(pm.jsHeapSizeLimit/1048576);
 const pct=Math.round(used*100/limit);
 E('dm-js-used')&&(E('dm-js-used').textContent=used+' MB ('+pct+'%)');
 E('dm-js-limit')&&(E('dm-js-limit').textContent=limit+' MB');
 const jb=E('dm-js-bar');if(jb)jb.style.width=Math.min(pct,100)+'%';
 const jbg=E('dm-js-badge');
 if(jbg){jbg.textContent=pct+'%';jbg.className='dm-badge '+(pct>=75?'hot':pct>=50?'warm':'cool');}
 }

 // ── Storage Info ──
 if(za&&za.getStorageInfo){
 try{
 const s=JSON.parse(za.getStorageInfo());
 if(s.intTotalMB){
 E('dm-int-used')&&(E('dm-int-used').textContent=fmtMB(s.intUsedMB)+' / '+fmtMB(s.intTotalMB)+' ('+s.intUsedPct+'%)');
 E('dm-int-free')&&(E('dm-int-free').textContent=fmtMB(s.intFreeMB));
 const ib=E('dm-int-bar');if(ib)ib.style.width=Math.min(s.intUsedPct,100)+'%';
 const sb=E('dm-stor-badge');
 if(sb){sb.textContent=s.intUsedPct+'%';sb.className='dm-badge '+(s.intUsedPct>=85?'hot':s.intUsedPct>=65?'warm':'cool');}
 if(s.extAvail){
 const extRow=E('dm-ext-row');if(extRow)extRow.style.display='flex';
 E('dm-ext-free')&&(E('dm-ext-free').textContent=fmtMB(s.extFreeMB));
 }
 }
 }catch(e){}
 }

 // ── Network ──
 if(za&&za.getNetworkType){
 try{
 const n=JSON.parse(za.getNetworkType());
 const wrap=E('dm-net-chip-wrap');
 if(wrap)wrap.innerHTML='<div class="dm-net-chip '+(n.connected?'online':'offline')+'"><div class="dm-net-dot"></div>'+(n.connected?'متصل':'غير متصل')+'</div>';
 const typeMap={WIFI:'Wi-Fi ',CELLULAR:'شبكة خلوية ',ETHERNET:'إيثرنت ',NONE:'غير متصل',UNKNOWN:'غير معروف'};
 E('dm-net-type')&&(E('dm-net-type').textContent=typeMap[n.type]||n.type||'—');
 const subMap={LTE:'4G LTE','5G NR':'5G',EDGE:'2G EDGE',HSPA:'3G HSPA',HSDPA:'3G HSDPA',HSPAP:'3G H+',UMTS:'3G UMTS'};
 E('dm-net-sub')&&(E('dm-net-sub').textContent=n.subtype?(subMap[n.subtype]||n.subtype):'—');
 }catch(e){}
 } else {
 const wrap=E('dm-net-chip-wrap');
 if(wrap)wrap.innerHTML='<div class="dm-net-chip '+(navigator.onLine?'online':'offline')+'"><div class="dm-net-dot"></div>'+(navigator.onLine?'متصل':'غير متصل')+'</div>';
 }

 // ── App Memory (Android PSS) ──
 if(za&&za.getAppMemory){
 try{
 const am=JSON.parse(za.getAppMemory());
 if(am.heapUsedMB!==undefined){
 const hPct=am.heapMaxMB?Math.round(am.heapUsedMB*100/am.heapMaxMB):0;
 E('dm-app-heap')&&(E('dm-app-heap').textContent=fmtMB(am.heapUsedMB)+' / '+fmtMB(am.heapMaxMB)+' ('+hPct+'%)');
 E('dm-app-nat')&&(E('dm-app-nat').textContent=fmtMB(am.nativeMB));
 E('dm-app-pss')&&(E('dm-app-pss').textContent=fmtMB(am.totalPssMB));
 const ab=E('dm-app-badge');
 if(ab){ab.textContent=fmtMB(am.totalPssMB);ab.className='dm-badge '+(hPct>=80?'hot':hPct>=55?'warm':'cool');}
 }
 }catch(e){}
 }

 // ── Sparklines history push ──
 (function(){
 const cpuEl=E('dm-cpu-temp');
 if(cpuEl&&cpuEl.textContent&&cpuEl.textContent!=='—'){
 const v=parseFloat(cpuEl.textContent);
 if(!isNaN(v)){dmCpuHist.push(v);if(dmCpuHist.length>12)dmCpuHist.shift();}
 }
 const ramBdg=E('dm-ram-badge');
 if(ramBdg){
 const v=parseInt(ramBdg.textContent);
 if(!isNaN(v)){dmRamHist.push(v);if(dmRamHist.length>12)dmRamHist.shift();}
 }
 renderSpark('dm-spark-cpu',dmCpuHist,80,'#808080',40,55);
 renderSpark('dm-spark-ram',dmRamHist,100,'#7b7b7b',60,80);
 })();

 // ── Auto Thermal Alert ──
 (function(){
 let maxT=0;
 // مراجعة "المشروع بالكامل": الصف الفعلي لكل منطقة حرارية (renderThermalGrid) يُنشئ
 // العنصر بصنف .dm-th-val — أما .dm-th-temp فلا وجود له إطلاقاً في أي مكان آخر بالملف
 // (لا CSS ولا HTML)؛ فكان هذا الفحص التلقائي يفوّت كل قراءات وحدة المعالجة المركزية/
 // الرسوميات/بقية المناطق الحرارية المعروضة في نفس اللوحة تماماً، ويعتمد فقط على حرارة
 // البطارية أدناه — فقد يسخن المعالج بشدة دون أن يظهر أي تحذير إطلاقاً.
 document.querySelectorAll('.dm-th-val').forEach(el=>{const v=parseFloat(el.textContent);if(!isNaN(v)&&v>maxT)maxT=v;});
 const batT=E('dm-bat-temp');if(batT){const v=parseFloat(batT.textContent);if(!isNaN(v)&&v>maxT)maxT=v;}
 if(maxT>=55)showThermalAlert(' تحذير — الحرارة وصلت '+maxT.toFixed(1)+'°C — أغلق التطبيق مؤقتاً للتبريد');
 else removeThermalAlert();
 })();

 // ── Device Info (static, set once) ──
 if(!E('dm-dev-model').dataset.set){
 E('dm-dev-model').dataset.set='1';
 E('dm-dev-model')&&(E('dm-dev-model').textContent=za?za.getDeviceModel():'—');
 E('dm-dev-api')&&(E('dm-dev-api').textContent=za?'API '+za.getAndroidVersion():'—');
 if(!E('dm-dev-cores').textContent||E('dm-dev-cores').textContent==='—')
 E('dm-dev-cores')&&(E('dm-dev-cores').textContent=(navigator.hardwareConcurrency||'—')+' أنوية');
 const dm=navigator.deviceMemory;
 if(dm&&!E('dm-dev-mem').textContent.includes('GB')&&!E('dm-dev-mem').textContent.includes('MB'))
 E('dm-dev-mem')&&(E('dm-dev-mem').textContent=dm+' GB (تقريبي)');
 }
}
// مراجعة "المشروع بالكامل": زر طلب الإذن هو الحالة الوحيدة في كل الملف التي تُعطِّل نفسها
// (disabled=true) بانتظار رد خارجي (من كود Android الأصلي عبر zpOnPermResult) دون أي مهلة —
// بالضبط النمط الموصوف كـ"Button State Stuck + State Transition Stuck": OFF→CLICKED→
// " جارٍ الطلب..."→تبقى كذلك للأبد لو لم يصل الرد إطلاقاً (مثلاً: أُعيد إنشاء الـActivity
// أثناء ظهور مربع حوار الإذن — دوران الشاشة، قتل العملية بضغط الذاكرة — فيضيع استدعاء
// onRequestPermissionsResult الأصلي ولا يُستدعى zpOnPermResult أبداً). الإصلاح: حارس زمني
// (12 ثانية، أطول بكثير من وقت رد مستخدم طبيعي) يعيد الزر لحالة "أعد المحاولة" تلقائياً إن لم
// يصل أي رد — يُلغى الحارس فوراً إن وصل رد حقيقي (ناجحاً أو مرفوضاً) قبل انتهاء المهلة.
const _zpPendingT={};
function _zpClearPending(id){if(_zpPendingT[id]){clearTimeout(_zpPendingT[id]);delete _zpPendingT[id];}}
function zpOnPermResult(id,granted){
 _zpClearPending(id);
 const btn=E('zpb-'+id);
 const err=E('zpe-'+id);
 if(granted){
 if(btn){btn.textContent='✓ تم الحصول على الإذن';btn.className='zp-mb ok';btn.disabled=true;}
 if(err)err.hidden=true;
 }else{
 if(btn){btn.textContent='اضغط للمحاولة مجدداً ←';btn.className='zp-mb retry';btn.disabled=false;}
 if(err)err.hidden=false;
 }
}
function zpRequestPerm(id){
 const btn=E('zpb-'+id);
 if(btn){btn.textContent='جارٍ الطلب...';btn.disabled=true;}
 _zpClearPending(id);
 if(typeof ZeroAndroid!=='undefined'){
 try{
 ZeroAndroid.requestPermission(id);
 _zpPendingT[id]=setTimeout(()=>{
 delete _zpPendingT[id];
 const b2=E('zpb-'+id);
 if(b2&&b2.disabled&&b2.textContent==='جارٍ الطلب...'){
 b2.textContent='لم يصل رد — اضغط للمحاولة مجدداً ←';b2.className='zp-mb retry';b2.disabled=false;
 }
 },12000);
 }
 catch(e){if(btn){btn.textContent='خطأ - حاول مجدداً';btn.className='zp-mb retry';btn.disabled=false;}}
 } else {
 setTimeout(()=>{if(btn){btn.textContent='اضغط للحصول على الإذن ←';btn.className='zp-mb req';btn.disabled=false;}},400);
 }
}
function zpOnPermPermanentDenied(id){
 _zpClearPending(id);
 const btn=E('zpb-'+id);
 const err=E('zpe-'+id);
 if(btn){
 btn.textContent='افتح إعدادات التطبيق ←';
 btn.className='zp-mb retry';
 btn.disabled=false;
 btn.onclick=function(){if(typeof ZeroAndroid!=='undefined')ZeroAndroid.openAppSettings();};
 }
 if(err){
 err.textContent='تم رفض الإذن نهائياً — اضغط لفتح الإعدادات ومنحه يدوياً';
 err.hidden=false;
 }
}
function zpRefreshAll(){
 PERMS_MGMT.forEach(p=>{
 const granted=typeof ZeroAndroid!=='undefined'&&!!ZeroAndroid.isPermissionGranted(p.id);
 const btn=E('zpb-'+p.id);
 const err=E('zpe-'+p.id);
 if(granted){
 if(btn){btn.textContent='✓ تم الحصول على الإذن';btn.className='zp-mb ok';btn.disabled=true;}
 if(err)err.hidden=true;
 }else{
 if(btn){btn.textContent='اضغط للحصول على الإذن ←';btn.className='zp-mb req';btn.disabled=false;}
 if(err)err.hidden=true;
 }
 });
}
function tSW(id){const sw=E(id);if(!sw)return;sw.checked=!sw.checked;applySW(id,sw.checked);}
function applySW(id,v){
 const m={
 // مراجعة "المشروع بالكامل": هذا المفتاح كان دالة فارغة (()=>null) — تبديل "Self-Learning"
 // في الإعدادات لم يكن له أي أثر إطلاقاً، رغم أن وصفه الظاهر "FreqDB + NN continuous
 // training" يوحي بأنه يوقف التدريب المستمر؛ startLearn() (نمط النسخ الاحتياطي والتعلّم
 // المُعاد) لم يكن يفحص أي علم من هذا النوع إطلاقاً. الإصلاح: علم P.useLearn حقيقي يُقرأ
 // الآن داخل startLearn() نفسها.
 'sw-cl':()=>P.useCL=v,'sw-evp':()=>P.useEVP=v,'sw-emf':()=>P.useEMF=v,'sw-inv':()=>P.useInv=v,'sw-learn':()=>P.useLearn=v,
 'sw-inf':()=>P.useSF.inf=v,'sw-ult':()=>P.useSF.ult=v,'sw-phf':()=>P.useSF.phf=v,'sw-sub':()=>P.useSF.sub=v,'sw-pie':()=>P.useSF.pie=v,
 'sw-c1':()=>P.useC.c1=v,'sw-c2':()=>P.useC.c2=v,'sw-c3':()=>P.useC.c3=v,'sw-c4':()=>P.useC.c4=v,
 'sw-c5':()=>P.useC.c5=v,'sw-c6':()=>P.useC.c6=v,'sw-c7':()=>P.useC.c7=v,'sw-c8':()=>P.useC.c8=v,
 'sw-ai':()=>{if(v!==isOn)toggleAI({});}
 };
 if(m[id])m[id]();
 if(isRun&&['sw-inf','sw-ult','sw-phf','sw-sub','sw-pie'].includes(id))updSF();
}
function syncAI(sw){if(sw.checked!==isOn)toggleAI({});}
/* selSrc: removed — unused function */

/* Swipe */
// اكمال بناء "الأزرار": في ويب-فيو الأندرويد لا يُفعَّل الاختيار الزائف :active على اللمس إطلاقاً
// ما لم يوجد مستمع touchstart واحد على الأقل في سلسلة الأجداد وصولاً إلى document/body — والملف
// يحوي أكثر من 18 قاعدة :active (.btn:active، .home-run-btn:active، .tog-row:active... إلخ) لكن
// بلا أي مستمع touchstart عام، ما يعني أن كل أزرار التطبيق كانت تفتقد فعلياً لتغذية الضغط
// البصرية (opacity/scale) على جهاز حقيقي رغم وجود التنسيق الخاص بها. مستمع فارغ لا يفعل شيئاً
// سوى تفعيل :active عبر كامل الشجرة، بلا أي أثر جانبي آخر.
document.addEventListener('touchstart',function(){},{passive:true});
const bsEl=E('bSheet'),apEl=E('aiPanel'),zpEl=E('zpPanel');
const tmEl=E('termPanel'),mnEl=E('menuPanel'),flEl=E('filesPanel'),dmEl=E('devPanel');
/* تطوير حرية الحركة داخل النوافذ (bSheet/aiPanel/zpPanel): كانت مستمعات السحب الثلاثة
 مثبَّتة مباشرة على عنصر اللوحة (.pnl) بأكمله، لا على مقبض السحب (.phdl) وحده — وبما أن
 أحداث اللمس تصعد (bubble) من أي عنصر داخلي، فأي لمسة تبدأ داخل محتوى قابل للتمرير
 (.shsc في bSheet، .pane في aiPanel، .zp-scr في zpPanel) كانت تُفعِّل نفس حركة سحب
 اللوحة كاملة (translateY) بالتوازي مع التمرير الطبيعي للقائمة — فتتصارع الحركتان: أي
 محاولة سحب لأعلى أو لأسفل داخل قائمة تحوي عناصر كثيرة كانت تُحرِّك اللوحة كلها بدل أن
 تُمرِّر محتواها فقط، فيبدو التمرير "جامداً" أو متذبذباً بالضبط في اللوحات التي تحتاج
 حرية حركة أكبر (كثرة العناصر).
 الإصلاح: عند بدء اللمس، تُحدَّد أقرب حاوية تمرير فعلية للعنصر المُلامَس (إن وُجدت)؛
 وطالما تلك الحاوية ليست في أعلاها (scrollTop>0)، تُترَك حركة التمرير الطبيعية تعمل
 بحرية كاملة بلا أي تدخل من حركة اللوحة (لا يُطبَّق أي transform إطلاقاً في تلك الحالة).
 فقط حين يصل المحتوى لأعلاه فعلاً ويستمر السحب لأسفل — أو حين تبدأ اللمسة على المقبض
 نفسه أصلاً (لا حاوية تمرير حوله) — تُستأنف حركة "سحب لإغلاق" المعتادة، تماماً كسلوك
 الأوراق السفلية القياسي (bottom sheet) في أنظمة التشغيل. */
// اكمال بناء "الأزرار" (تتمة): مستمعات السحب أعلاه مثبَّتة على عنصر اللوحة (.pnl) كاملاً، فأي لمسة
// تبدأ على عنصر تحكم يقع خارج contentSel القابل للتمرير (أزرار تبويب aiPanel .tbtn التي هي شقيقة
// لـ.pane لا داخلها، أزرار termPanel .term-ph-r/.term-fil، وأزرار إغلاق الرأس .pcl/.ai-ph-c في كل
// اللوحات) لا تستفيد من بوابة scrollEl إطلاقاً (تُصبح null لهذه العناصر) — فأي ارتعاش طبيعي بسيط
// بالإصبع أثناء نقرة عادية على أحد هذه الأزرار كان يُفعِّل transform السحب فوراً (d>0)، ما يجعل
// الزر يبدو "مهتزاً"/متذبذباً تحت الإصبع بدل أن يبقى ثابتاً كنقرة عادية. الإصلاح: عتبة "touch slop"
// صغيرة (8px) بنفس قيمة ViewConfiguration.getScaledTouchSlop() القياسية في أندرويد — لا يُطبَّق أي
// تحريك للوحة إطلاقاً إلا بعد تجاوز الإصبع هذه المسافة الصغيرة، فالنقرات العادية (ارتعاش أقل من
// 8px) تبقى ثابتة تماماً بصرياً مهما كان العنصر الملموس داخل اللوحة أو خارج contentSel.
// تشديد إضافي: القفل الاتجاهي. البوابات أعلاه (scrollEl + عتبة SLOP) لا تحمي حركة أفقية صريحة —
// مثل تمرير شريط تبويبات aiPanel (.tab-bar، عنصر overflow-x:auto أفقي، يقع خارج contentSel أصلاً)
// بإصبع يتحرك يميناً/يساراً. لو رافق هذا التمرير الأفقي أي ميل رأسي طفيف (طبيعي جداً في حركة يد
// حقيقية)، وتجاوز ذلك الميل عتبة SLOP الرأسية، كانت اللوحة بأكملها تنزلق أيضاً رغم أن نية المستخدم
// الوحيدة كانت التمرير الأفقي بين التبويبات — تشديد أدق من عتبة SLOP وحدها. الإصلاح: تتبُّع
// الإزاحة الأفقية أيضاً منذ بدء اللمس، ورفض تطبيق transform اللوحة كلياً ما دامت الحركة الأفقية
// مساوية أو أكبر من الرأسية (أي أن اتجاه الإصبع الغالب أفقي لا رأسي) — فقط حين تتفوق الحركة
// الرأسية بوضوح على الأفقية يُعتبر السحب سحباً عمودياً حقيقياً لإغلاق اللوحة.
function _wireSheetDrag(panelEl,contentSel,closeFn){
 const SLOP=8;
 let sX=0,sY=0,sDr=false,scrollEl=null,dragged=false;
 panelEl.addEventListener('touchstart',ev=>{
 sX=ev.touches[0].clientX;sY=ev.touches[0].clientY;sDr=true;dragged=false;
 scrollEl=ev.target.closest(contentSel);
 // حذف الجمود أثناء السحب الفعلي: .pnl تحمل transition:transform .38s دائماً (لحركة
 // الفتح/الإغلاق العادية عبر الأزرار) — لكن هذا الانتقال نفسه كان لا يزال مُفعَّلاً أثناء
 // السحب باللمس أيضاً، فكل تحديث touchmove (عشرات المرات في الثانية) كان يُشغِّل نفس
 // انتقال الـ.38s من جديد في كل إطار، فتتراكم الانتقالات المتتالية ويتخلَّف موضع اللوحة
 // المرئي عن موضع الإصبع الفعلي بمسافة وزمن ملحوظين (أُثبِت هذا فعلياً: بعد 16ms من
 // تحريك 60px، اللوحة لم تكن قد تحرَّكت سوى ~28px) — هذا بالضبط ما يجعل السحب "يشعر"
 // بالجمود والتذبذب رغم أن الإحداثيات المحسوبة صحيحة تماماً. تعطيل الانتقال هنا يجعل
 // اللوحة تتبع الإصبع فوراً بلا أي تأخير، وإعادة تفعيله عند رفع الإصبع (touchend) تُبقي
 // حركة "العودة لمكانها" أو "الإغلاق" الأخيرة ناعمة كما كانت دائماً.
 panelEl.style.transition='none';
 },{passive:true});
 panelEl.addEventListener('touchmove',ev=>{
 if(!sDr)return;
 const d=ev.touches[0].clientY-sY;
 const dx=ev.touches[0].clientX-sX;
 if(scrollEl&&scrollEl.scrollTop>0)return; // المحتوى ليس في أعلاه — اترك تمريره حراً بلا تدخل
 if(Math.abs(dx)>=Math.abs(d))return; // قفل اتجاهي: الحركة أفقية غالبة أو متعادلة — ليست سحباً عمودياً
 if(d>SLOP){dragged=true;panelEl.style.transform=`translateX(-50%) translateY(${d-SLOP}px)`;}
 },{passive:true});
 panelEl.addEventListener('touchend',ev=>{
 if(!sDr)return;sDr=false;
 const d=ev.changedTouches[0].clientY-sY;
 panelEl.style.transition=''; // إعادة تفعيل انتقال .pnl قبل آخر حركة (عودة/إغلاق ناعمة)
 panelEl.style.transform='';
 if(dragged&&d>100)closeFn();
 scrollEl=null;dragged=false;
 },{passive:true});
}

/* ══ TABS ══ */
