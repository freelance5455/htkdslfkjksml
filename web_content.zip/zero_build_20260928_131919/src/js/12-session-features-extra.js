/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 12-session-features-extra.js
 الميزات المُضافة في هذه الجلسة: غرفة الصمت (Mask) + وضع النوم الذكي + مؤقت النوم + فيزياء الإلغاء والمحاكي التفاعلي
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */
let maskCtx=null,maskSrcNode=null,maskGainNode=null,maskFilterNode=null,maskAnalyser=null;
let maskRunning=false,maskNoiseType='white',maskAnimFrame=null;
const MASK_STORE_KEY='zero_mask_v1';

function maskSaveState(){
 try{localStorage.setItem(MASK_STORE_KEY,JSON.stringify({type:maskNoiseType,vol:E('maskVolSlider')?.value,freq:E('maskFreqSlider')?.value}));}catch(e){}
}
function maskLoadState(){
 try{
 const raw=localStorage.getItem(MASK_STORE_KEY);if(!raw)return;
 const s=JSON.parse(raw);if(!s)return;
 if(s.type){maskNoiseType=s.type;const btn=document.querySelector(`.mask-btn[data-t="${s.type}"]`);if(btn){document.querySelectorAll('.mask-btn').forEach(b=>b.classList.remove('on'));btn.classList.add('on');}}
 if(s.vol!=null){const vs=E('maskVolSlider');if(vs){vs.value=s.vol;const l=E('maskVolLbl');if(l)l.textContent=s.vol+'%';}}
 if(s.freq!=null){const fs=E('maskFreqSlider');if(fs){fs.value=s.freq;const l=E('maskFreqLbl');if(l)l.textContent=s.freq+' Hz';}}
 const fr=E('maskFreqRow');if(fr)fr.style.display=(maskNoiseType==='rain'||maskNoiseType==='pink')?'':'none';
 }catch(e){}
}

function maskCreateWhite(ctx){
 const bufLen=ctx.sampleRate*2,buf=ctx.createBuffer(1,bufLen,ctx.sampleRate),data=buf.getChannelData(0);
 for(let i=0;i<bufLen;i++)data[i]=Math.random()*2-1;
 const src=ctx.createBufferSource();src.buffer=buf;src.loop=true;return src;
}
function maskCreatePink(ctx){
 const bufLen=ctx.sampleRate*2,buf=ctx.createBuffer(1,bufLen,ctx.sampleRate),data=buf.getChannelData(0);
 let b0=0,b1=0,b2=0,b3=0,b4=0,b5=0,b6=0;
 for(let i=0;i<bufLen;i++){
 const w=Math.random()*2-1;
 b0=0.99886*b0+w*0.0555179;b1=0.99332*b1+w*0.0750759;
 b2=0.96900*b2+w*0.1538520;b3=0.86650*b3+w*0.3104856;
 b4=0.55000*b4+w*0.5329522;b5=-0.7616*b5-w*0.0168980;
 data[i]=(b0+b1+b2+b3+b4+b5+b6+w*0.5362)*0.11;
 b6=w*0.115926;
 }
 const src=ctx.createBufferSource();src.buffer=buf;src.loop=true;return src;
}
function maskCreateBrown(ctx){
 const bufLen=ctx.sampleRate*2,buf=ctx.createBuffer(1,bufLen,ctx.sampleRate),data=buf.getChannelData(0);
 let last=0;
 for(let i=0;i<bufLen;i++){const w=Math.random()*2-1;data[i]=(last+0.02*w)/1.02;last=data[i];data[i]*=3.5;}
 const src=ctx.createBufferSource();src.buffer=buf;src.loop=true;return src;
}
function maskCreateRain(ctx){return maskCreatePink(ctx);}
function maskCreateDeep(ctx){return maskCreateBrown(ctx);}
function maskBuildNoise(ctx,type){
 if(type==='white')return maskCreateWhite(ctx);
 if(type==='pink')return maskCreatePink(ctx);
 if(type==='brown')return maskCreateBrown(ctx);
 if(type==='rain')return maskCreateRain(ctx);
 if(type==='deep')return maskCreateDeep(ctx);
 return maskCreateWhite(ctx);
}
function maskApplyFilter(filter,type,freq){
 filter.type='bandpass';
 if(type==='white'){filter.type='allpass';}
 else if(type==='pink'){filter.frequency.value=600;filter.Q.value=0.5;}
 else if(type==='brown'){filter.type='lowpass';filter.frequency.value=400;}
 else if(type==='rain'){filter.type='bandpass';filter.frequency.value=freq;filter.Q.value=1.2;}
 else if(type==='deep'){filter.type='lowpass';filter.frequency.value=250;}
}

function maskToggle(){if(maskRunning)maskStop();else maskStart();}

function maskStart(){
 try{
 maskCtx=new(window.AudioContext||window.webkitAudioContext)();
 maskGainNode=maskCtx.createGain();
 maskFilterNode=maskCtx.createBiquadFilter();
 maskAnalyser=maskCtx.createAnalyser();maskAnalyser.fftSize=256;
 const freq=parseInt(E('maskFreqSlider')?.value||1200);
 maskApplyFilter(maskFilterNode,maskNoiseType,freq);
 maskSrcNode=maskBuildNoise(maskCtx,maskNoiseType);
 maskSrcNode.connect(maskFilterNode);maskFilterNode.connect(maskGainNode);
 maskGainNode.connect(maskAnalyser);maskGainNode.connect(maskCtx.destination);
 const vol=parseInt(E('maskVolSlider')?.value||45)/100;
 maskGainNode.gain.value=vol;
 maskSrcNode.start();
 maskRunning=true;
 const btn=E('maskRunBtn');if(btn){btn.textContent='■ إيقاف';btn.classList.add('on');}
 maskSaveState();
 stLog(' غرفة الصمت: تشغيل ('+maskNoiseType+')');
 maskDrawLoop();
 }catch(e){
 stLog(' غرفة الصمت: تعذَّر التشغيل — '+e.message);
 }
}
function maskStop(){
 if(maskSrcNode){try{maskSrcNode.stop();}catch(e){}maskSrcNode=null;}
 if(maskCtx){try{maskCtx.close();}catch(e){}maskCtx=null;}
 if(maskAnimFrame){cancelAnimationFrame(maskAnimFrame);maskAnimFrame=null;}
 maskRunning=false;
 const btn=E('maskRunBtn');if(btn){btn.textContent='▶ تشغيل غرفة الصمت';btn.classList.remove('on');}
 const cv=E('maskViz');if(cv){const c=cv.getContext('2d');c.clearRect(0,0,cv.width,cv.height);}
 stLog(' غرفة الصمت: إيقاف');
}
function maskSelectNoise(type,btn){
 maskNoiseType=type;
 document.querySelectorAll('.mask-btn').forEach(b=>b.classList.remove('on'));
 if(btn)btn.classList.add('on');
 const fr=E('maskFreqRow');if(fr)fr.style.display=(type==='rain'||type==='pink')?'':'none';
 if(maskRunning){
 if(maskSrcNode){try{maskSrcNode.stop();}catch(e){}}
 const freq=parseInt(E('maskFreqSlider')?.value||1200);
 maskApplyFilter(maskFilterNode,maskNoiseType,freq);
 maskSrcNode=maskBuildNoise(maskCtx,maskNoiseType);
 maskSrcNode.connect(maskFilterNode);
 maskSrcNode.start();
 }
 maskSaveState();
}
function maskUpdateVolume(v){
 const l=E('maskVolLbl');if(l)l.textContent=v+'%';
 if(maskGainNode)maskGainNode.gain.value=v/100;
 maskSaveState();
}
function maskUpdateFreq(v){
 const l=E('maskFreqLbl');if(l)l.textContent=v+' Hz';
 if(maskFilterNode&&(maskNoiseType==='rain'||maskNoiseType==='pink'))maskFilterNode.frequency.value=parseInt(v);
 maskSaveState();
}
function maskDrawLoop(){
 if(!maskRunning)return;
 maskAnimFrame=requestAnimationFrame(maskDrawLoop);
 const cv=E('maskViz');if(!cv||!maskAnalyser)return;
 if(cv.width!==cv.offsetWidth)cv.width=cv.offsetWidth;
 if(cv.height!==cv.offsetHeight)cv.height=cv.offsetHeight;
 const c=cv.getContext('2d'),w=cv.width,h=cv.height;
 const data=new Uint8Array(maskAnalyser.frequencyBinCount);
 maskAnalyser.getByteFrequencyData(data);
 c.clearRect(0,0,w,h);
 const barW=w/data.length*2.5;
 for(let i=0;i<data.length;i++){
 const v=data[i]/255;
 c.fillStyle=`rgba(178,178,178,${0.15+v*0.5})`;
 c.fillRect(i*barW,h-v*h,Math.max(1,barW-1),v*h);
 }
}
maskLoadState(); // استعادة آخر إعداد (نوع/مستوى/تردد) محفوظ محلياً — بلا تشغيل تلقائي

/* ══════════════════════════════════════════════════════════════════
 SMART BEDTIME — فكرة مُستعادة من ZERO-WAVE-v5.html (toggleBedtime)
 تحسين عن الأصل: الأصل كان يحفظ "الساعة الحالية وقت الضغط" كموعد التشغيل
 (سلوك غير بديهي)، هنا المستخدم يختار الوقت صراحةً عبر<input type="time">
 ويُحفظ محلياً (localStorage) فلا يُفقد بعد إغلاق التطبيق. التشغيل الفعلي
 يستدعي toggleAI({}) — نفس مسار زر التشغيل اليدوي — فيستفيد تلقائياً من
 كل تحسينات المحرك (initAudio، PERSIST، إلخ) دون تكرار منطق التشغيل.
 ══════════════════════════════════════════════════════════════════ */
let bedtimeTimer=null,bedtimeEnabled=false,bedtimeTime='23:00',bedtimeLastFired=null;
const BEDTIME_STORE_KEY='zero_bedtime_v1';
function bedtimeSaveState(){try{localStorage.setItem(BEDTIME_STORE_KEY,JSON.stringify({enabled:bedtimeEnabled,time:bedtimeTime}));}catch(e){}}
function bedtimeLoadState(){
 try{
 const raw=localStorage.getItem(BEDTIME_STORE_KEY);
 if(raw){
 const d=JSON.parse(raw);
 bedtimeTime=d.time||'23:00';
 bedtimeEnabled=!!d.enabled;
 const inp=E('bedtimeTimeInp');if(inp)inp.value=bedtimeTime;
 const sw=E('sw-bedtime');if(sw)sw.checked=bedtimeEnabled;
 bedtimeUpdateStatus();
 if(bedtimeEnabled)bedtimeStart();
 }
 }catch(e){}
}
function bedtimeUpdateStatus(){
 const el=E('bedtime-status');if(!el)return;
 el.textContent=bedtimeEnabled?(' مُفعّل — سيُشغَّل المحرك تلقائياً عند '+bedtimeTime+' يومياً'):'■ متوقف — فعّل المفتاح لجدولة تشغيل تلقائي';
}
function toggleBedtime(chk){
 bedtimeEnabled=!!chk.checked;
 bedtimeSaveState();bedtimeUpdateStatus();
 if(bedtimeEnabled)bedtimeStart();else bedtimeStop();
 if(typeof zVibrate==='function')zVibrate(6);
}
function bedtimeSetTime(v){
 if(!v)return;
 bedtimeTime=v;bedtimeSaveState();bedtimeUpdateStatus();
 if(bedtimeEnabled){bedtimeStop();bedtimeStart();}
}
function bedtimeStart(){
 if(bedtimeTimer)clearInterval(bedtimeTimer);
 bedtimeTimer=setInterval(()=>{
 const now=new Date();
 const hh=String(now.getHours()).padStart(2,'0'),mm=String(now.getMinutes()).padStart(2,'0');
 const stamp=now.toDateString()+' '+hh+':'+mm;
 if((hh+':'+mm)===bedtimeTime&&!isRun&&bedtimeLastFired!==stamp){
 bedtimeLastFired=stamp;
 toggleAI({});
 if(typeof stLog==='function')stLog(' Smart Bedtime: تشغيل تلقائي عند '+bedtimeTime);
 }
 },15000);
}
function bedtimeStop(){if(bedtimeTimer){clearInterval(bedtimeTimer);bedtimeTimer=null;}}
bedtimeLoadState();

/* ══════════════════════════════════════════════════════════════════
 مؤقت النوم (Sleep Timer) — فكرة مُستعادة من ZERO-WAVE-v5.html (toggleSleep/
 setTimer). عدّ تنازلي يدوي: يشغّل المحرك الآن (إن لم يكن يعمل) لمدة محددة،
 ثم يوقفه تلقائياً عند الصفر — يتكامل مع "وضع النوم الذكي" أعلاه (ذاك يبدأ
 عند وقت ثابت يومياً، وهذا يوقف بعد مدة من بدء النوم الفعلي). إلغاء العد
 يدوياً (زر الإيقاف قبل الصفر) لا يوقف المحرك نفسه — فقط يلغي جدولة
 الإيقاف التلقائي، بالضبط كسلوك toggleSleep() الأصلي.
 ══════════════════════════════════════════════════════════════════ */
let sleepTimerId=null,sleepSecLeft=0,sleepMinutesSel=30,sleepRunning=false;
const SLEEP_STORE_KEY='zero_sleeptimer_v1';
function sleepSaveState(){try{localStorage.setItem(SLEEP_STORE_KEY,JSON.stringify({minutes:sleepMinutesSel}));}catch(e){}}
function sleepLoadState(){
 try{
 const raw=localStorage.getItem(SLEEP_STORE_KEY);
 if(raw){
 const d=JSON.parse(raw);
 if(d.minutes){
 sleepMinutesSel=d.minutes;
 document.querySelectorAll('.sleep-preset-btn').forEach(b=>{
 b.classList.toggle('sel',b.textContent.trim()===sleepMinutesSel+' د');
 });
 }
 }
 }catch(e){}
}
function sleepSetMinutes(m,btn){
 if(sleepRunning)return; // لا تغيير المدة أثناء عدّ فعلي جارٍ
 sleepMinutesSel=m;
 document.querySelectorAll('.sleep-preset-btn').forEach(b=>b.classList.remove('sel'));
 if(btn)btn.classList.add('sel');
 sleepSaveState();
}
function sleepFmt(s){const m=Math.floor(s/60),ss=s%60;return String(m).padStart(2,'0')+':'+String(ss).padStart(2,'0');}
function sleepUpdateDisplay(){const d=E('sleepTimerDisp');if(d)d.textContent=sleepFmt(sleepSecLeft);}
function sleepToggle(){if(sleepRunning)sleepStop();else sleepStart();}
function sleepStart(){
 sleepSecLeft=sleepMinutesSel*60;
 sleepRunning=true;
 if(!isRun)toggleAI({});
 const d=E('sleepTimerDisp');if(d)d.style.display='block';
 sleepUpdateDisplay();
 const btn=E('sleepTimerBtn');if(btn){btn.textContent='إيقاف المؤقت';btn.classList.add('run');}
 if(typeof stLog==='function')stLog(' مؤقت النوم: '+sleepMinutesSel+' دقيقة');
 if(typeof zVibrate==='function')zVibrate(6);
 sleepTimerId=setInterval(()=>{
 sleepSecLeft--;
 sleepUpdateDisplay();
 if(sleepSecLeft<=0){
 sleepStop();
 if(isRun)toggleAI({});
 if(typeof stLog==='function')stLog(' مؤقت النوم: انتهت المدة — تم إيقاف المحرك تلقائياً');
 }
 },1000);
}
function sleepStop(){
 if(sleepTimerId){clearInterval(sleepTimerId);sleepTimerId=null;}
 sleepRunning=false;
 const d=E('sleepTimerDisp');if(d)d.style.display='none';
 const btn=E('sleepTimerBtn');if(btn){btn.textContent='بدء مؤقت النوم';btn.classList.remove('run');}
}
sleepLoadState();

/* ══════════════════════════════════════════════════════════════════
 فيزياء الإلغاء (Cancellation Physics) — تصوّر تعليمي مُستعاد من
 zero-wave-anc.html/zero-wave-complete.html (drawFanWave/drawAntiWave/
 drawNullWave). الأصل نفسه كان يرسم "الموجة المضادة" كانعكاس تخطيطي
 لنفس عيّنة الميكروفون (وليس بالتقاط مسار صوت منفصل فعلي) — نفس المبدأ
 محفوظ هنا حرفياً. أما "الموجة الصفرية" فتُحسَب هنا عبر استدعاء دالة
 sfEff() الموجودة فعلاً في محرك الرسم الرئيسي (بدل تكرار حساب جديد) —
 فلا تُضاف أي معادلة إلغاء صوت جديدة، هذه طبقة عرض فقط تقرأ من نفس
 المحلّل (ana) الحي دون أي مصدر/التقاط صوت إضافي ودون لمس خط أنابيب DSP.
 ══════════════════════════════════════════════════════════════════ */
let physAnimFrame=null;
function physDrawWave(canvasId,data,color){
 const cv=E(canvasId);if(!cv)return;
 if(cv.width!==cv.offsetWidth)cv.width=cv.offsetWidth;
 if(cv.height!==cv.offsetHeight)cv.height=cv.offsetHeight;
 const c=cv.getContext('2d'),w=cv.width,h=cv.height;
 c.clearRect(0,0,w,h);
 c.beginPath();c.strokeStyle=color;c.lineWidth=1.5;
 const pts=Math.min(data.length,Math.max(64,Math.floor(w)));
 const stride=Math.max(1,Math.floor(data.length/pts));
 const stepX=w/pts;let x=0,n=0;
 for(let i=0;i<data.length&&n<pts;i+=stride,n++){
 const v=(data[i]-128)/128;const y=h/2-(v*h*0.42);
 if(n===0)c.moveTo(x,y);else c.lineTo(x,y);
 x+=stepX;
 }
 c.stroke();
}
function physDrawLoop(){
 if(!physOpen){physAnimFrame=null;return;}
 physAnimFrame=requestAnimationFrame(physDrawLoop);
 if(!ana||!isRun)return;
 const td=new Uint8Array(ana.fftSize);
 ana.getByteTimeDomainData(td);
 // ① الموجة الأصلية — من الميكروفون مباشرة
 physDrawWave('physFanCv',td,'#707070');
 const fs=E('physFanStat');if(fs)fs.textContent=fanFreq>0?fanFreq.toFixed(0)+' Hz':'— Hz';
 // ② الموجة المضادة — انعكاس تخطيطي 180° لنفس العيّنة (تصوّر تعليمي)
 const anti=new Uint8Array(td.length);
 for(let i=0;i<td.length;i++)anti[i]=Math.max(0,Math.min(255,256-td[i]));
 physDrawWave('physAntiCv',anti,'#9a9a9a');
 const asEl=E('physAntiStat');if(asEl)asEl.textContent=INV.active.size+' نشِط';
 // ③ الموجة الصفرية — نفس sfEff() المستخدَمة فعلياً في drawLoop() الرئيسية (بلا حساب جديد)
 const nullW=sfEff(td);
 physDrawWave('physNullCv',nullW,'#a5a5a5');
 let rms=0;for(let i=0;i<nullW.length;i++){const v=(nullW[i]-128)/128;rms+=v*v;}
 rms=Math.sqrt(rms/nullW.length);
 const ns=E('physNullStat');if(ns)ns.textContent=rms<0.015?'≈ 0':rms.toFixed(3);
}

/* محاكاة تفاعلية رياضية بحتة — بلا صوت وبلا محرك حي، تعمل بمجرد فتح اللوحة (زر تجريبي تعليمي) */
let physSimPhase=180;
function physSimUpdatePhase(v){
 physSimPhase=+v;
 const lbl=E('physSimPhaseLbl');if(lbl)lbl.textContent=v+'°';
 physSimDraw();
}
function physSimDraw(){
 const cv=E('physSimCv');if(!cv)return;
 if(cv.width!==cv.offsetWidth)cv.width=cv.offsetWidth;
 if(cv.height!==cv.offsetHeight)cv.height=cv.offsetHeight;
 const c=cv.getContext('2d'),w=cv.width,h=cv.height;
 c.clearRect(0,0,w,h);
 const phi=physSimPhase*Math.PI/180,cycles=3,N=200,step=w/N;
 // الموجة الأصلية (وهمية — تمثيل تعليمي)
 c.beginPath();c.strokeStyle='#707070';c.lineWidth=1.5;
 for(let i=0;i<=N;i++){const x=i*step,t=(i/N)*cycles*2*Math.PI,y=h*0.28-Math.sin(t)*h*0.16;i===0?c.moveTo(x,y):c.lineTo(x,y);}
 c.stroke();
 // الموجة المضادة (بفارق الطور المُختار)
 c.beginPath();c.strokeStyle='#9a9a9a';c.lineWidth=1.5;
 for(let i=0;i<=N;i++){const x=i*step,t=(i/N)*cycles*2*Math.PI,y=h*0.28-Math.sin(t+phi)*h*0.16;i===0?c.moveTo(x,y):c.lineTo(x,y);}
 c.stroke();
 // المحصّلة (الناتج الفعلي بعد الجمع)
 c.beginPath();c.strokeStyle='#a5a5a5';c.lineWidth=2;
 for(let i=0;i<=N;i++){const x=i*step,t=(i/N)*cycles*2*Math.PI;const sum=Math.sin(t)+Math.sin(t+phi);const y=h*0.75-sum*h*0.16;i===0?c.moveTo(x,y):c.lineTo(x,y);}
 c.stroke();
}
physSimDraw();
