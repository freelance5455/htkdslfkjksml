/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 13-zero-integration-aicore.js
 طبقة تكامل ZERO-v25 (الخدمة الخلفية/الشاشة/الإشعارات) + نواة AI الموحّدة — كانت وسم<script>ثانٍ منفصل، الآن ملف مستقل يُحمَّل بعد كل ملفات المحرك
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════════════════════════
 ZERO-v25 INTEGRATION LAYER (مُدمَج الآن داخل index.html نفسه)
 ──────────────────────────────────────────────────────────────────
 طبقة تكامل ZERO-v25: كل ما يمثّل تعامل التطبيق مع تطبيق ZERO-v25
 الأصلي (خدمة الخلفية، الشاشة، الإشعارات) + نواة AI الموحّدة (AICore).

 كان يُحمَّل سابقاً كملف zero-core.js منفصل بعد index.html مباشرة؛ الآن
 وسم<script>مستقل ثانٍ في نفس الملف، بنفس ترتيب التنفيذ تماماً —
 يستخدم كل ثوابت/دوال المحرك المعرَّفة أعلاه (E، isRun، AI_BAN، ...)
 دون تكرارها. الفصل معماري فقط (توثيقي)، لا تنفيذي: index.html بالكامل
 الآن = واجهة المستخدم + محرك الكشف/DSP + تكامل ZERO-v25 + نواة AI،
 في ملف واحد فقط.

 لم يتغيّر أي سطر منطقي هنا عن نسخته داخل index.html — نقل حرفي فقط.
 ══════════════════════════════════════════════════════════════════ */

/* ════════════════════════════════════════════════════
 BACKGROUND MODE — 5-Layer System
 ① Wake Lock — screen stays on, no sleep
 ② Web Worker — precision timer, not throttled
 ③ Service Worker — keep-alive heartbeat
 ④ Notification — live status when tab is hidden
 ⑤ Visibility API — detects + handles bg transitions
════════════════════════════════════════════════════ */

let bgEnabled=true,bgMode=false,bgStartT=0,bgRuns=0,bgTotalMs=0,bgNotifN=0;
const BG_LOG=[];

function bgLog(msg){
 const ts=new Date(),t=String(ts.getMinutes()).padStart(2,'0')+':'+String(ts.getSeconds()).padStart(2,'0');
 BG_LOG.unshift({msg,t});if(BG_LOG.length>30)BG_LOG.pop();
 if(curTab===6){const el=E('bg-log');if(el)el.innerHTML=BG_LOG.slice(0,12).map(l=>`<div style="font-family:var(--fm);font-size:9px;color:var(--muted);padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="color:rgba(169,169,169,.4)">${l.t}</span> ${l.msg}</div>`).join('');}
 logNN(' BG: '+msg);
}

/* ═══════════════
 ① WAKE LOCK
═══════════════ */
let wakeLock=null,wlOk=false;
// إغلاق الفراغات — نفس نمط سباق initAudio(): reqWL() لها 4 مصادر استدعاء مستقلة تماماً
// (startAll، _exitBG عند العودة من الخلفية، toggleBGMode بلا await، وتجديدها الذاتي أدناه) —
// ولم يكن لها أي حارس تكرار إطلاقاً. wakeLock يبقى null طوال await navigator.wakeLock.
// request(...)؛ نداءان متزامنان (مثلاً toggleBGMode ضُغط مرتين، أو تزامن مع تجديد ذاتي) كانا
// يُنشئان WakeLockSentinel جديدين، وآخر واحد يكتمل يكتب فوق wakeLock العام فيُضيع مرجع الأقدم
// إلى الأبد (لا يمكن استدعاء release() عليه بعدها). كما أن معالج 'release' كان يفحص isRun
// لحظة وقوع الحدث فقط لا لحظة تنفيذ setTimeout بعد ثانية — فقد يُعاد طلب قفل شاشة جديد بعد أن
// يكون المستخدم قد ضغط "إيقاف" فعلاً خلال تلك الثانية، فيبقى القفل عالقاً حياً للأبد رغم التوقف.
let _wlReqPromise=null;
async function reqWL(){
 if(wakeLock)return;
 if(_wlReqPromise)return _wlReqPromise;
 if(!('wakeLock' in navigator)){wlOk=false;updBGUI();return;}
 _wlReqPromise=(async()=>{
 try{
 wakeLock=await navigator.wakeLock.request('screen');
 wlOk=true;
 wakeLock.addEventListener('release',()=>{
 wlOk=false;wakeLock=null;updBGUI();
 // فحص isRun عند التنفيذ الفعلي بعد ثانية، لا عند وقوع الحدث — يمنع تجديداً عالقاً
 // بعد أن يكون المستخدم قد أوقف التطبيق فعلاً خلال هذه الثانية.
 setTimeout(()=>{if(isRun&&!document.hidden)reqWL();},1000);
 });
 updBGUI();bgLog(' Wake Lock acquired — screen stays on');
 }catch(e){wlOk=false;updBGUI();bgLog(' Wake Lock denied: '+e.message);}
 finally{_wlReqPromise=null;}
 })();
 return _wlReqPromise;
}

function relWL(){
 if(wakeLock){wakeLock.release();wakeLock=null;wlOk=false;updBGUI();bgLog(' Wake Lock released');}
}

/* ═══════════════════════════
 ② WEB WORKER — precision timer
 Not throttled when tab hidden
═══════════════════════════ */
const WK_CODE=`
'use strict';
let ti=null,cyc=0;
self.onmessage=function(e){
 const{type,data}=e.data||{};
 if(type==='start'){
 cyc=data.cyc||0;
 if(ti)clearInterval(ti);
 ti=setInterval(()=>{
 cyc++;
 self.postMessage({type:'tick',cyc});
 },350);
 self.postMessage({type:'ready'});
 }else if(type==='sync'){
 cyc=data.cyc||cyc;
 }else if(type==='stop'){
 if(ti)clearInterval(ti);
 ti=null;
 self.postMessage({type:'stopped'});
 }
};
`;
let bgWorker=null,wkOk=false,wkCycs=0;

function startBGWorker(){
 if(bgWorker)return;
 try{
 const blob=new Blob([WK_CODE],{type:'application/javascript'});
 const url=URL.createObjectURL(blob);
 bgWorker=new Worker(url);
 bgWorker.onmessage=function(e){
 const{type,cyc}=e.data;
 if(type==='ready'){wkOk=true;updBGUI();}
 else if(type==='tick'){
 wkCycs=cyc;
 // Keep AI engine running even when hidden
 if(isRun&&ana){
 aiCyc=cyc;
 // AudioContext + AnalyserNode continue in background
 if(NN.w1){
 const inp=nnInp();
 const{out}=nnFwd(inp);
 nnCtrlSF(out);
 // Train every 4 worker cycles
 if(cyc%4===0){const rw=silSc>50?(silSc-50)/50:-0.1;nnTrain(inp,rw);}
 }
 // Update bg badge if visible
 if(!document.hidden)syncBGUI();
 else{const bt=E('bgBadgeTxt');if(bt)bt.textContent='BG '+silSc+'%';}
 }
 }
 else if(type==='stopped'){wkOk=false;updBGUI();}
 };
 bgWorker.postMessage({type:'start',data:{cyc:aiCyc}});
 bgLog(' Web Worker started — unthrottled timer running');
 }catch(err){wkOk=false;updBGUI();bgLog(' Worker error: '+err.message);}
}

function stopBGWorker(){
 if(bgWorker){bgWorker.postMessage({type:'stop'});bgWorker.terminate();bgWorker=null;wkOk=false;updBGUI();}
}

/* ═══════════════════════════
 ③ SERVICE WORKER — keep-alive
═══════════════════════════ */
let swOk=false,swReg=null,swT=null;

async function regSW(){
 if(!('serviceWorker' in navigator)){updBGUI();return;}
 const SW=`
self.addEventListener('message',e=>{
 if(e.data==='keepalive'){
 self.clients.matchAll({includeUncontrolled:true}).then(cls=>{
 cls.forEach(c=>c.postMessage({type:'swPing',t:Date.now()}));
 });
 }
});
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
 `;
 try{
 const blob=new Blob([SW],{type:'application/javascript'});
 const swURL=URL.createObjectURL(blob);
 // Try to register — may fail due to blob: scope restrictions
 try{
 swReg=await navigator.serviceWorker.register(swURL,{scope:location.pathname||'/'});
 swOk=true;
 navigator.serviceWorker.addEventListener('message',e=>{
 if(e.data&&e.data.type==='swPing')bgLog(' SW heartbeat: '+new Date(e.data.t).toLocaleTimeString());
 });
 bgLog(' Service Worker registered — keep-alive active');
 }catch(e2){
 // SW can't use blob: URL scope — that's OK, worker covers timing
 swOk=false;
 bgLog(' SW: using Worker fallback (blob scope restriction)');
 }
 // إغلاق الفراغات — نفس نمط تسرب regSW(): كان swT=setInterval(...) يُعاد تعيينه دون تصفية
 // المؤقّت السابق أولاً. toggleBGMode() (المُفعِّل الحقيقي لـ regSW()) غير محمي من التكرار —
 // ضغطتان سريعتان عليه تستدعيان regSW() مرتين، فينشأ مؤقّتا نبض (25 ثانية) بدلاً من واحد،
 // ويُفقد المرجع إلى الأول تماماً (لا يمكن لـ stopSW() تصفيته بعد الآن، لأنها تصفّي فقط swT
 // الحالي)، فيبقى يعمل للأبد حتى بعد إيقاف التطبيق فعلياً — نفس نمط initAudio()/reqWL() تماماً.
 if(swT)clearInterval(swT);
 // Heartbeat every 25s regardless
 swT=setInterval(()=>{
 if(isRun){
 // Keep page active via storage ping
 try{localStorage.setItem('zero-heartbeat',Date.now());}catch(e){}
 if(swReg&&swReg.active)swReg.active.postMessage('keepalive');
 }
 },25000);
 updBGUI();
 }catch(e){swOk=false;updBGUI();bgLog(' SW init failed');}
}

function stopSW(){
 if(swT){clearInterval(swT);swT=null;}
 if(swReg&&swReg.active){try{swReg.unregister();}catch(e){}}
 swOk=false;updBGUI();
}

/* ═══════════════════════════
 ④ NOTIFICATION SYSTEM
═══════════════════════════ */
let notifPerm='default',bgNotif=null,notifRefT=null;

async function reqNotifPerm(){
 if(!('Notification' in window)){updBGUI();return;}
 if(Notification.permission!=='default'){notifPerm=Notification.permission;updBGUI();return;}
 notifPerm=await Notification.requestPermission();
 updBGUI();
 bgLog(' Notification permission: '+notifPerm);
}

function showBGNotif(){
 // عندما يعمل التطبيق داخل ZERO-v25 الأصلي، الإشعار الدائم لـBgService كافٍ وحده —
 // إظهار إشعار متصفح موازٍ هنا كان يُنتج إشعارين متزامنين (تدخل في عمل ZERO-v25)
 if(typeof ZeroAndroid!=='undefined')return;
 if(notifPerm!=='granted'||!isRun)return;
 const body=`Silence: ${silSc}% · Cycle: ${aiCyc} · FreqDB: ${freqDB.size} freqs · NN trained: ${NN.trainN}`;
 if(bgNotif){try{bgNotif.close();}catch(e){}}
 try{
 bgNotif=new Notification('ZERO AI v25 — Running in Background',{
 body,tag:'zero-v25-active',silent:true,requireInteraction:false
 });
 bgNotif.onclick=()=>{window.focus();if(bgNotif)bgNotif.close();bgNotif=null;};
 bgNotifN++;updBGUI();
 // Refresh notification every 15s while in background
 if(notifRefT)clearInterval(notifRefT);
 notifRefT=setInterval(()=>{
 if(document.hidden&&isRun)showBGNotif();
 else{closeBGNotif();}
 },15000);
 }catch(e){bgLog(' Notification blocked: '+e.message);}
}

function closeBGNotif(){
 if(bgNotif){try{bgNotif.close();}catch(e){}bgNotif=null;}
 if(notifRefT){clearInterval(notifRefT);notifRefT=null;}
}

/* ═══════════════════════════
 ⑤ BACKGROUND TRANSITIONS
 المصدر الأساسي: خطافات ZERO-v25 الأصلية — window.onAppBackground/onAppForeground
 (يستدعيها MainActivity.onPause/onResume فعلياً؛ كانت موجودة في الجسر الأصلي
 ولم يكن index.html يستمع لها إطلاقاً، ويعيد اكتشاف الخلفية بنفسه عبر
 Page Visibility API بشكل مواز — هذا هو "التدخل" الذي صُحح هنا).
 المصدر الاحتياطي: Page Visibility API — فقط عند غياب تطبيق ZERO-v25 الأصلي.
═══════════════════════════ */
function _enterBG(){
 if(!isRun)return;
 bgMode=true;bgStartT=Date.now();bgRuns++;
 if(bgWorker)bgWorker.postMessage({type:'sync',data:{cyc:aiCyc}});
 showBGNotif(); // لا يفعل شيئاً فعلياً داخل ZERO-v25 الأصلي (مُحصَّن أعلاه) — يعمل بوضع المتصفح فقط
 const ban=E('bgBanner');if(ban)ban.classList.add('on');
 const badge=E('bgBadge');if(badge)badge.classList.add('on');
 if(drawId){cancelAnimationFrame(drawId);drawId=null;}
 bgLog(`→ BACKGROUND: run #${bgRuns} started`);
 updBGUI();
}
function _exitBG(){
 if(bgMode){
 const elapsed=Date.now()-bgStartT;
 bgTotalMs+=elapsed;
 bgMode=false;
 bgLog(`← FOREGROUND: back after ${(elapsed/1000).toFixed(1)}s · total bg: ${(bgTotalMs/1000).toFixed(0)}s`);
 }
 closeBGNotif();
 const ban=E('bgBanner');if(ban)ban.classList.remove('on');
 if(wkCycs>aiCyc)aiCyc=wkCycs;
 // إعادة WakeLock الويب فقط بوضع المتصفح — داخل ZERO-v25 الأصلي الشاشة تُدار عبر setKeepScreenOn
 if(typeof ZeroAndroid==='undefined'&&isRun&&!wlOk&&bgEnabled)reqWL();
 if(isRun&&!drawId)drawLoop();
 updBGUI();syncBGUI();
}
// يُستدعى فعلياً من MainActivity.onPause()/onResume() عبر evaluateJavascript —
// هذا هو المصدر الصحيح والموثوق لانتقال الخلفية داخل ZERO-v25 الأصلي
window.onAppBackground=function(){_enterBG();};
window.onAppForeground=function(){_exitBG();};
// احتياطي لوضع المتصفح فقط (بدون تطبيق ZERO-v25 الأصلي، لا خطافات أصلية متاحة)
document.addEventListener('visibilitychange',()=>{
 if(typeof ZeroAndroid!=='undefined')return;
 if(document.hidden)_enterBG();else _exitBG();
});

/* ═══════════════════════════
 BACKGROUND MODE CONTROL
═══════════════════════════ */
function toggleBGMode(){
 bgEnabled=!bgEnabled;
 const btn=E('bg-toggle');
 if(btn){btn.className='bg-tgl'+(bgEnabled?'':' off');btn.textContent='BG MODE: '+(bgEnabled?'ON':'OFF');}
 if(bgEnabled&&isRun){
 if(typeof ZeroAndroid!=='undefined'){
 try{ZeroAndroid.setKeepScreenOn(true);}catch(e){}
 startBGWorker();
 }else{
 reqWL();startBGWorker();regSW();reqNotifPerm();
 }
 bgLog(' Background mode ENABLED');
 }else{
 if(typeof ZeroAndroid!=='undefined'){try{ZeroAndroid.setKeepScreenOn(false);}catch(e){}}
 relWL();stopBGWorker();stopSW();closeBGNotif();
 bgLog(' Background mode DISABLED');
 }
 updBGUI();
}

function hideBgBanner(){const el=E('bgBanner');if(el)el.classList.remove('on');}
function openBGTab(){openAIP();setTimeout(()=>openTab(6),80);}

/* ═══════════════════════════
 BG UI UPDATE
═══════════════════════════ */
function updBGUI(){
 // System status badges
 const wl=E('bg-wl');if(wl){wl.className='sy'+(wlOk?' ok':' warn');wl.innerHTML='<div class="syd"></div>WakeLock'+(wlOk?' ✓':' ✗');}
 const wk=E('bg-wk');if(wk){wk.className='sy'+(wkOk?' ok':' warn');wk.innerHTML='<div class="syd"></div>Worker'+(wkOk?' ✓':' ✗');}
 const sw2=E('bg-sw');if(sw2){sw2.className='sy'+(swOk?' ok':' warn');sw2.innerHTML='<div class="syd"></div>SW'+(swOk?' ✓':' ✗');}
 const nf=E('bg-nf');if(nf){const p=notifPerm;nf.className='sy'+(p==='granted'?' ok':p==='denied'?' err':' warn');nf.innerHTML='<div class="syd"></div>Notif'+(p==='granted'?' ✓':p==='denied'?' ✗':' ?');}
 // Stats
 const br=E('bg-runs');if(br)br.textContent=bgRuns;
 const bm=E('bg-ms');if(bm)bm.textContent=bgTotalMs>0?(bgTotalMs/1000).toFixed(0)+'s':'—';
 const bwk=E('bg-wkc');if(bwk)bwk.textContent=wkCycs>0?wkCycs:'—';
 const bn=E('bg-notifs');if(bn)bn.textContent=bgNotifN;
 // Log
 if(curTab===6){const el=E('bg-log');if(el&&BG_LOG.length)el.innerHTML=BG_LOG.slice(0,12).map(l=>`<div style="font-family:var(--fm);font-size:9px;color:var(--muted);padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="color:rgba(169,169,169,.4)">${l.t}</span> ${l.msg}</div>`).join('');}
 // Topbar badge
 const badge=E('bgBadge');if(badge)badge.className='bg-badge'+(bgMode&&isRun?' on':'');
}

function syncBGUI(){
 updBGUI();
 const bbtxt=E('bgBTxt');if(bbtxt)bbtxt.textContent=`Background · Silence: ${silSc}% · Cycle: ${aiCyc} · FreqDB: ${freqDB.size} · NN: ${NN.trainN}`;
 const btxt=E('bgBadgeTxt');if(btxt)btxt.textContent=bgMode?'BG '+silSc+'%':'BG';
}

/* BG + Storage hooks integrated into startAll/stopAll */

// Periodic BG UI sync every 5s
setInterval(()=>{if(isRun)syncBGUI();},5000);

// Initial UI state
updBGUI();
bgLog(' ZERO AI v25 · Background system ready');

/* ═══════════════════════════════════════════════════════════════
 نواة AI — AI CORE
 تجميع معماري لكل أفكار ومنطق ZERO AI v25 (ANC/ENC) في واجهة واحدة.
 هذه واجهة إضافية (façade) فقط — لا تُنقل أي شيفرة فعلياً ولا تُعاد
 كتابتها؛ كل خوارزمية ودالة مختبَرة تبقى كما هي في مكانها الأصلي.
 AICore يوفّر نقطة وصول موحّدة لحالتها ولإجراءاتها كي تُقرأ كـ"نواة"
 واحدة متكاملة، تماماً كما طُلب: تجميع الأفكار والنوافذ السابقة
 (والتي أصبحت الآن نوافذ زجاجية فوق هذه النواة) ضمن نواة AI واحدة.
 ═══════════════════════════════════════════════════════════════ */
const AICore={
 meta:{name:'ZERO AI v25 Core',build:'ANC/ENC',desc:'نواة موحّدة تجمع محرك الكشف، التصنيف، حظر الترددات، مراقبة التداخل، والمراقبة الحرارية/البيئية للجهاز'},

 // ── الحالة الحية (state) — مراجع مباشرة لهياكل البيانات الفعلية،
 // أي تعديل هنا هو نفسه التعديل على الأصل (Map/Object بالمرجع)
 state:{
 get KF(){return KF}, // مرشّح كالمان لتتبّع التردد
 get AI_BAN(){return AI_BAN}, // خريطة الترددات المحظورة (دائم)
 get AI_GATE(){return AI_GATE}, // بوابة الحظر التلقائي
 get THERMAL(){return THERMAL}, // مراقبة حرارة الجهاز
 get PERSIST(){return PERSIST}, // طبقة الحفظ (IndexedDB/localStorage)
 get INTERFERENCE_BAN(){return INTERFERENCE_BAN}, // مراقبة التداخل بين الترددات
 get freqDB(){return freqDB}, // قاعدة بيانات الترددات المرصودة
 get ENV_FP(){return ENV_FP}, // البصمة البيئية
 get SESSION_STAT(){return SESSION_STAT}, // إحصائيات الجلسة
 get NN(){return NN}, // الشبكة العصبية للتصنيف
 // قيم لحظية (أعداد/منطقية) — getters لضمان قراءة القيمة الحيّة دوماً
 get isOn(){return isOn},
 get isRun(){return isRun},
 get execCyc(){return execCyc},
 get aiCyc(){return aiCyc},
 get silSc(){return silSc},
 },

 // ── الإجراءات (actions) — مراجع للدوال الفعلية المختبَرة، بلا تكرار للمنطق
 actions:{
 toggleAI:(e)=>toggleAI(e), // تشغيل/إيقاف محرك AI
 startAll:()=>startAll(),
 stopAll:()=>stopAll(),
 banFreq:(hz,reason,opts)=>banFreq(hz,reason,opts), // حظر تردد يدوياً من الداخل
 unbanFreq:(hz)=>unbanFreq(hz), // رفع حظر تردد
 toggleAllPermBans:()=>toggleAllPermBans(), // تفعيل/إيقاف كل الحظر الدائم
 checkInterference:(hz)=>checkInterference(hz), // فحص تداخل تردد جديد
 dmRefresh:()=>dmRefresh(), // تحديث مراقبة الجهاز
 saveSession:()=>saveSession(), // حفظ/تصدير الجلسة
 },

 // ── النوافذ (windows) — كل نافذة زجاجية تفتح/تغلق فوق النواة نفسها
 windows:{
 menu:{open:()=>openMenu(),close:()=>closeMenu()}, // القائمة الرئيسية (تجمع كل النوافذ أدناه)
 aiBrain:{open:()=>openAIP(),close:()=>closeAIP()}, // دماغ AI (FreqDB/NN/سجلات)
 pipeline:{open:()=>openPipe(),close:()=>closePipe()}, // Pipeline — حالة الخوارزميات اللحظية
 deviceMonitor:{open:()=>openDevMon(),close:()=>closeDevMon()}, // مراقبة الجهاز
 terminal:{open:()=>openTerm(),close:()=>(typeof closeTerm!=='undefined'?closeTerm():null)}, // الطرفية
 settings:{open:()=>openSheet(),close:()=>closeSheet()}, // الإعدادات
 permissions:{open:()=>openZPPanel(),close:()=>closeZPPanel()}, // الأذونات
 closeAll:()=>closeAll(),
 },
};
// كل الأفكار والنوافذ والتفرّعات السابقة مجمّعة الآن داخل AICore —
// الواجهة الرئيسية تضم فقط: زر التشغيل + حضر الترددات الدائمة.
// بقية الأقسام (دماغ AI · Pipeline · مراقبة الجهاز · الطرفية · الإعدادات · الأذونات)
// جُمعت في نافذة القائمة (menuPanel) التي يفتحها زر الهامبرغر أعلى اليسار.
console.log('%c AICore ready','color:#a9a9a9;font-weight:bold',AICore.meta);

/* ══════════════════════════════════════════════════════════════════
 قائمة الحظر المؤكّدة — CONFIRMED BAN PROFILE (جلستان حقيقيتان، مدموجتان)
 ──────────────────────────────────────────────────────────────────
 الدفعة الأولى: 257 تردد + 194 منطقة تداخل (تصدير 2026-09-24 16:27)
 — بعد استبعاد 30 مطابقة لـDEFAULT_BANNED_FREQS: 227 تردد + 194 منطقة.

 الدفعة الثانية: 237 تردد + 171 منطقة تداخل جديدة (تصدير 2026-09-24
 22:28، بعد ~2.5 ساعة استماع فعلي إضافي) — من أصل الـ237، تحقّقنا أن
 34 منها متطابقة أصلاً مع الدفعة الأولى (على الأرجح كان الجهاز وقتها
 يشغّل نسخة أقدم من zero-core.js لم تحتوِ بعد على الدفعة الأولى، فأعاد
 اكتشافها كـ"جديدة")، فاستُبعدت لتفادي التكرار؛ الباقي 203 تردد + 171
 منطقة تداخل حقيقياً جديدة أُضيفت هنا. من ضمنها نطاق ±4Hz حول 158Hz
 (155–162Hz) الذي كان قد صُعِّد فعلياً في التطبيق (منطقة 158Hz مُسجَّلة
 بعدّاد 0 بعد إعادة تعيينه إثر التصعيد) — كل التردد الفردية ضمن ذلك
 النطاق موجودة كإدخالات مستقلة في القائمة أدناه، فالحماية الفعلية
 محفوظة كاملة حتى لو لم يُخزَّن رقم "التوسيع" ±4Hz نفسه هنا (نفس
 المخطط المستخدَم لكل مناطق التداخل الأخرى: hz + count فقط).

 الدفعة الثالثة: 98 تردد + 75 منطقة تداخل جديدة (تصدير 2026-09-25
 00:02، جلسة استماع بتاريخ 2026-09-24 21:02) — كل الـ98/75 تحقّقنا أنها
 جديدة فعلاً (لا تطابق أي شيء في الدفعتين السابقتين ولا DEFAULT_BANNED_FREQS)،
 فأُضيفت كاملة بلا استبعاد. النطاق الجديد بمعظمه امتداد فوق 240.5Hz
 (241–306.5Hz) بالإضافة إلى عدد قليل من الترددات المتفرقة الأعلى
 (449 وحتى 2600.5Hz).

 الدفعة الرابعة: 159 تردد + 113 منطقة تداخل جديدة (تصدير 2026-09-25
 01:23، جلسة استماع بتاريخ 2026-09-24 22:23) — من أصل الـ159، 4 مطابقة
 أصلاً لإدخالات من الدفعة الأولى (128.5/129.5/132/135.5Hz — نفس نمط
 "جهاز بنسخة أقدم" من الدفعات السابقة) فاستُبعدت؛ الباقي 155 تردد
 + 113 منطقة تداخل حقيقياً جديدة أُضيفت. النطاق الجديد يملأ الفجوة بين
 306.5Hz والدفعة السابقة تقريباً حتى ~420Hz بكثافة، مع امتداد متفرق
 حتى 1077.5Hz، إضافة لبضعة ترددات منخفضة (18.5/22.5Hz).

 الإجمالي المدموج الآن: 683 تردد محظور + 553 منطقة تداخل — تُحمَّل
 كخط أساس دائم مع كل تشغيل/تثبيت جديد، بدل الاعتماد فقط على إعادة
 تعلّمها حيّاً من الصفر في كل جلسة.

 index.html يوفّر فقط آلية AI_BAN والعرض العامة (لا علاقة له بأي
 قرار حظر لتردد بعينه) — أما *ما هي الترددات المحظورة فعلياً* فهو
 بيانات تكامل تخص نشر ZERO-v25، لذا تعيش هنا في zero-core.js.
 ══════════════════════════════════════════════════════════════════ */
const CONFIRMED_BANS=[18.5,20,20.5,21,21.5,22,22.5,23,23.5,24,24.5,25,25.5,26,26.5,27,27.5,28,28.5,29,29.5,30,30.5,31,31.5,32,32.5,33,33.5,34,34.5,35,35.5,36,36.5,37,37.5,38,38.5,39,39.5,40,40.5,41,41.5,42,42.5,43,43.5,44,44.5,45,45.5,46,46.5,47,47.5,48,48.5,49,49.5,50.5,51,51.5,52,52.5,53,53.5,54,54.5,55,55.5,56,56.5,57,57.5,58,58.5,59,59.5,60.5,61,61.5,62,62.5,63,63.5,64,64.5,65,65.5,66,66.5,67,67.5,68,68.5,69,69.5,70,70.5,71,71.5,72,72.5,73,73.5,74,74.5,75,75.5,76,76.5,77,77.5,78,78.5,79,79.5,80,80.5,81,81.5,82,82.5,83,83.5,84,84.5,85,85.5,86,86.5,87,87.5,88,88.5,89,89.5,90,90.5,91,91.5,92,92.5,93,93.5,94,94.5,95,95.5,96,96.5,97,97.5,98,98.5,99,99.5,100.5,101,101.5,102,102.5,103,103.5,104,104.5,105,105.5,106,106.5,107,107.5,108,108.5,109,109.5,110,110.5,111,111.5,112,112.5,113,113.5,114,114.5,115,115.5,116,116.5,117,117.5,118,118.5,119,119.5,120.5,121,121.5,122,122.5,123,123.5,124,124.5,125,125.5,126,126.5,127,127.5,128,128.5,129,129.5,130,130.5,131,131.5,132,132.5,133,133.5,134,134.5,135,135.5,136,136.5,137,137.5,138,138.5,139,139.5,140,140.5,141,141.5,142,142.5,143,143.5,144,144.5,145,145.5,146,146.5,147,147.5,148,148.5,149,149.5,150.5,151,151.5,152,152.5,153,153.5,154,154.5,155,155.5,156,156.5,157,157.5,158,158.5,159,159.5,160,160.5,161,161.5,162,162.5,163,163.5,164,164.5,165,165.5,166,166.5,167,167.5,168,168.5,169,169.5,170,170.5,171,171.5,172,172.5,173,173.5,174,174.5,175,175.5,176,176.5,177,177.5,178,178.5,179,179.5,180.5,181,181.5,182,182.5,183,183.5,184,184.5,185,185.5,186,186.5,187,187.5,188,188.5,189,189.5,190,190.5,191,191.5,192,192.5,193,193.5,194,194.5,195,195.5,196,196.5,197,197.5,198,198.5,199,199.5,200.5,201,201.5,202,202.5,203,203.5,204,204.5,205,205.5,206,206.5,207,207.5,208,208.5,209,209.5,210,210.5,211,211.5,212,212.5,213,213.5,214,214.5,215,215.5,216,216.5,217,217.5,218,218.5,219,219.5,220,220.5,221,221.5,222,222.5,223,223.5,224,224.5,225,225.5,226,226.5,227,227.5,228,228.5,229,229.5,230,230.5,231,231.5,232,232.5,233,233.5,234,234.5,235,235.5,236,236.5,237,237.5,238,238.5,239,239.5,240.5,241,241.5,242,242.5,243,243.5,244,244.5,245,245.5,246,246.5,247,247.5,248,248.5,249,249.5,250.5,251,251.5,252,252.5,253,253.5,254,254.5,255,255.5,256,256.5,257,257.5,258,258.5,259,259.5,260,260.5,261,261.5,262,262.5,263,263.5,264,264.5,265,265.5,266,266.5,267,267.5,268,268.5,269,269.5,270,270.5,271,271.5,272,272.5,273,273.5,274,274.5,275,275.5,276,276.5,277,277.5,278,278.5,279,279.5,280.5,281,281.5,282,282.5,283,283.5,284,284.5,285,285.5,286,286.5,287,287.5,288,288.5,289,289.5,290,290.5,291,291.5,292,292.5,293,293.5,294,294.5,295,295.5,296,296.5,297,297.5,298,298.5,299,299.5,300.5,301,301.5,302,302.5,303,303.5,304,304.5,305,305.5,306,306.5,307,307.5,308,308.5,309,309.5,310,310.5,311,311.5,312,312.5,313,313.5,314,314.5,315,315.5,316,316.5,317,317.5,318,318.5,319,319.5,320,320.5,321,321.5,322,322.5,323,323.5,324,324.5,325,325.5,326,326.5,327,327.5,328,328.5,329,329.5,330,331,331.5,332,332.5,333.5,334,334.5,335,336,336.5,337,338.5,340.5,344.5,346,348,350.5,351,351.5,359,360,360.5,361,362,363,368,369,372.5,375.5,380,399,400.5,402,418.5,437,449,451,468.5,478.5,479,479.5,489,500,500.5,541,549.5,550,593.5,599,601.5,649,650,663.5,701,712.5,749.5,750,750.5,780.5,841,922.5,949,950,959,999,1020,1077.5,1079.5,1098.5,1100.5,1255.5,2600.5];
const CONFIRMED_INTERFERENCE=[[19.5,1],[20.5,1],[21,1],[21.5,1],[22,1],[22.5,1],[23.5,1],[24,1],[24.5,1],[25,1],[25.5,1],[26,1],[26.5,1],[27,1],[28,1],[28.5,1],[29,1],[29.5,1],[30,1],[30.5,1],[31,1],[31.5,2],[32.5,1],[33,1],[33.5,1],[34,1],[34.5,1],[35.5,1],[36,1],[36.5,1],[37,1],[37.5,1],[38,1],[38.5,2],[39.5,1],[40,1],[40.5,1],[41.5,1],[42,1],[42.5,1],[43,1],[43.5,1],[44,1],[44.5,1],[45,1],[45.5,1],[46,1],[46.5,1],[47,1],[47.5,1],[48,1],[48.5,1],[49,1],[49.5,1],[50,1],[50.5,2],[51.5,1],[52,1],[52.5,1],[53,1],[53.5,1],[54,1],[54.5,1],[55,1],[55.5,1],[56,1],[56.5,1],[57.5,1],[58,1],[58.5,1],[59,1],[59.5,1],[60,1],[60.5,1],[61,1],[61.5,1],[62,1],[62.5,2],[63.5,1],[64,2],[65.5,1],[66,1],[66.5,1],[67,1],[67.5,1],[68,1],[68.5,2],[69.5,1],[70.5,1],[71,1],[71.5,1],[72,1],[72.5,1],[73,1],[73.5,1],[74,1],[74.5,1],[75,1],[75.5,1],[76,1],[76.5,1],[77,1],[77.5,1],[78,1],[79,1],[79.5,1],[80,1],[80.5,1],[81,2],[82,1],[82.5,1],[83.5,1],[84,1],[84.5,1],[85,1],[86,1],[86.5,1],[87,1],[87.5,1],[88,1],[88.5,1],[89,1],[89.5,1],[90,1],[90.5,1],[91,1],[91.5,1],[92,1],[92.5,1],[93.5,2],[94,1],[94.5,1],[95,1],[95.5,2],[97,1],[97.5,1],[98,1],[98.5,1],[99,1],[99.5,1],[100,1],[100.5,1],[101,1],[101.5,2],[102,1],[103,1],[103.5,1],[104.5,2],[105,1],[105.5,1],[106,2],[107,1],[108,1],[108.5,1],[109,1],[109.5,1],[110.5,2],[111,1],[111.5,1],[112,1],[112.5,1],[113,1],[114,1],[114.5,1],[115,1],[115.5,1],[116,1],[116.5,1],[117,1],[118,1],[118.5,1],[119,1],[119.5,1],[120,1],[120.5,1],[121,1],[121.5,1],[122,1],[122.5,2],[123.5,1],[124,1],[124.5,2],[125.5,1],[126,1],[127,1],[127.5,1],[128,1],[128.5,1],[129,1],[129.5,1],[130,1],[130.5,2],[131.5,1],[132,1],[133,1],[133.5,1],[134,2],[135,1],[135.5,2],[136,1],[136.5,1],[137,1],[137.5,2],[138.5,1],[139,1],[139.5,1],[140,1],[140.5,1],[141,1],[141.5,2],[142.5,1],[143,2],[144,1],[144.5,1],[145.5,1],[146,1],[146.5,1],[147,1],[147.5,1],[148,1],[148.5,1],[149,1],[149.5,1],[150,1],[150.5,2],[151.5,1],[152,2],[153,1],[153.5,2],[154.5,1],[155,2],[155.5,1],[156.5,1],[157,1],[157.5,1],[158,0],[158.5,1],[159,1],[159.5,1],[160.5,1],[161,1],[161.5,1],[162,2],[163,1],[164,1],[164.5,1],[165,1],[165.5,2],[166.5,1],[167,1],[168,1],[168.5,1],[169,1],[169.5,1],[170,1],[170.5,1],[171,1],[171.5,1],[172,1],[172.5,1],[173,1],[173.5,1],[174,1],[174.5,1],[175,1],[175.5,2],[176.5,1],[177.5,1],[178,1],[178.5,1],[179,1],[179.5,1],[180,1],[180.5,2],[181.5,2],[182.5,1],[183,1],[183.5,2],[184.5,2],[185.5,1],[186,1],[186.5,1],[187,2],[188,1],[189,1],[189.5,1],[190,1],[190.5,1],[191,1],[192,1],[192.5,1],[193,1],[193.5,1],[194,1],[194.5,1],[195.5,2],[196,1],[196.5,1],[197,1],[197.5,2],[198.5,1],[199.5,1],[200,1],[200.5,1],[201,1],[201.5,1],[202,1],[202.5,2],[203.5,1],[204,1],[204.5,2],[206,1],[206.5,1],[207,1],[207.5,2],[208.5,1],[209,1],[210,1],[210.5,1],[211,1],[211.5,1],[212,2],[213,1],[213.5,1],[214,2],[215,1],[215.5,1],[216,1],[216.5,1],[217,1],[217.5,1],[218.5,1],[219,1],[219.5,1],[220,1],[220.5,1],[221,1],[221.5,1],[222,1],[222.5,1],[223,1],[223.5,2],[224.5,2],[225.5,1],[226,2],[227,1],[227.5,1],[228,1],[228.5,1],[229,1],[229.5,1],[230,1],[230.5,1],[231,1],[231.5,1],[232,2],[233,1],[233.5,1],[234,1],[234.5,1],[235.5,1],[236,1],[237,1],[237.5,1],[238,1],[238.5,1],[239,1],[239.5,1],[240.5,1],[241,1],[241.5,1],[242,1],[242.5,1],[243,1],[243.5,2],[244,1],[245,1],[245.5,1],[246,1],[247,1],[247.5,1],[248,1],[248.5,1],[249,1],[249.5,1],[250,1],[250.5,1],[251,1],[251.5,1],[252.5,1],[253,1],[253.5,1],[254,1],[255,1],[255.5,1],[256,1],[256.5,1],[257,1],[257.5,1],[258,1],[258.5,1],[259,1],[259.5,1],[260,1],[261,1],[262,1],[262.5,1],[263,1],[263.5,2],[264.5,2],[265.5,1],[266.5,1],[267.5,2],[268,1],[269,2],[270,1],[270.5,1],[271.5,1],[272,1],[272.5,1],[273,1],[273.5,1],[274,1],[274.5,1],[275,1],[275.5,1],[276.5,1],[277,1],[277.5,1],[278,1],[279,1],[279.5,1],[280,1],[280.5,1],[281,1],[281.5,1],[282.5,1],[283,1],[283.5,1],[284,1],[284.5,1],[285.5,1],[286,1],[287,1],[287.5,1],[288.5,1],[289,1],[289.5,1],[290,1],[290.5,1],[291.5,1],[292,1],[293,1],[294,1],[294.5,1],[295,1],[295.5,1],[296,1],[296.5,1],[297,1],[297.5,1],[298,1],[298.5,1],[299,1],[299.5,1],[300.5,2],[301.5,1],[302,1],[302.5,1],[303,1],[303.5,1],[304.5,1],[305,1],[305.5,1],[306,1],[306.5,1],[307,2],[308,1],[308.5,1],[309,1],[309.5,2],[310.5,1],[311.5,1],[312,2],[313,1],[314,1],[314.5,1],[315,1],[315.5,1],[316,1],[316.5,2],[317.5,1],[318,1],[318.5,1],[319,1],[319.5,1],[320,1],[321,1],[321.5,1],[322,1],[322.5,1],[323.5,1],[324,1],[324.5,1],[325,1],[325.5,1],[326,1],[326.5,1],[327.5,1],[328,1],[328.5,1],[329,1],[329.5,1],[330,1],[330.5,1],[331.5,1],[332,1],[332.5,1],[334,1],[334.5,2],[336,1],[336.5,1],[337,1],[339.5,1],[340.5,1],[345.5,1],[347,1],[351,1],[351.5,1],[360,1],[360.5,1],[361,1],[361.5,1],[362.5,1],[368.5,1],[374,1],[399.5,1],[400.5,1],[401,1],[450,1],[479,1],[479.5,1],[500.5,1],[550,1],[599.5,1],[601,1],[649.5,1],[750,1],[750.5,1],[949.5,1],[999.5,1],[1078.5,1],[1099.5,1]];

function loadConfirmedBans(){
 if(typeof AI_BAN==='undefined'||typeof fBin!=='function')return;
 if(typeof PERM_BAN_CATS!=='undefined'&&PERM_BAN_CATS.env)PERM_BAN_CATS.env.enabled=true; // مؤكَّدة فعلياً على الجهاز — الفئة env تُفعَّل
 const reason='مؤكَّد من جلسات استماع حقيقية — 2026-09-24/25 (×4)';
 let added=0;
 CONFIRMED_BANS.forEach(hz=>{
 const bin=fBin(hz);
 if(!AI_BAN.has(bin)){
 // baseline:true — يميّزها كقائمة أساسية مُعاد توليدها في كل تشغيل، فلا
 // تُكرَّر عند حفظ/تصدير الملفات (PERSIST.saveBans و _getBansForExport
 // يركّزان على الجديد فقط ويستبعدان أي مدخل baseline)
 AI_BAN.set(bin,{reason,bannedAt:0,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:'env',baseline:true,
 preBanEnergy:0,postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null});
 added++;
 }
 });
 let zonesAdded=0;
 if(typeof INTERFERENCE_BAN!=='undefined'){
 CONFIRMED_INTERFERENCE.forEach(([hz,count])=>{
 const bin=fBin(hz);
 if(!INTERFERENCE_BAN.zones.has(bin)){
 INTERFERENCE_BAN.zones.set(bin,{count,widen:0,lastT:0,baseline:true});
 zonesAdded++;
 }
 });
 }
 if(added||zonesAdded){
 if(typeof PERSIST!=='undefined')PERSIST.scheduleSaveBans();
 if(typeof renderBanList==='function')renderBanList();
 if(typeof renderPermSettings==='function')renderPermSettings();
 if(typeof stLog==='function')stLog(' حضر مؤكَّد: '+added+' تردد + '+zonesAdded+' منطقة تداخل مُستعادة (4 جلسات 2026-09-24/25)');
 }
 return{added,zonesAdded};
}
loadConfirmedBans();



/* ── ربط سحب-للإغلاق (drag-to-dismiss) لكل اللوحات ──
 نُقِلت هذه الكتلة إلى هنا (آخر ملف يُحمَّل) أثناء إعادة الهيكلة المعمارية
 (سبتمبر 2026): في الأصل كانت هذه الاستدعاءات (مع كل التعليقات التوضيحية
 الأصلية أدناه) تقع داخل js/04-panels-ui-system.js مباشرة بعد تعريف
 _wireSheetDrag — وكانت تعمل هناك بأمان في الملف الواحد الأصلي لأن كل
 دوال closeXxx (بما فيها closeTerm من ملف الطرفية، وclose{Mask,Phys,
 About,Privacy,LoopDiag}Panel من ملف الميزات المتأخرة) كانت "مرفوعة"
 (hoisted) عبر السكربت الكامل بلا استثناء. بعد التقسيم إلى ملفات<script
 src>متعددة، يقتصر الرفع (hoisting) على كل ملف بمفرده فقط — فاستدعاء
 _wireSheetDrag(tmEl,...,closeTerm) وهو لا يزال في ملف اللوحات (يُحمَّل
 قبل ملف الطرفية) كان سيرمي "closeTerm is not defined" فوراً عند التحميل
 (تأكَّد هذا فعلياً عبر اختبار متصفح حقيقي)، ويوقف تنفيذ بقية استدعاءات
 الملف صامتاً. النقل إلى هنا — بعد كل الملفات الأخرى — يضمن أن كل الدوال
 المُشار إليها مُعرَّفة فعلياً بحلول لحظة التنفيذ، مطابقاً تماماً للسلوك
 الأصلي في الملف الواحد، بلا أي تغيير منطقي. ── */
_wireSheetDrag(bsEl,'.shsc',closeSheet);
_wireSheetDrag(apEl,'.pane',closeAIP);
_wireSheetDrag(zpEl,'.zp-scr',closeZPPanel);
// اكمال بناء كل النوافذ: النوافذ الأربع التالية (termPanel/menuPanel/filesPanel/devPanel) كانت
// تعرض نفس مقبض السحب المرئي (.phdl/.pbar) الموجود في الثلاث نوافذ أعلاه، لكن بلا أي مستمع لمس
// موصول به إطلاقاً — مقبض السحب كان عنصراً زخرفياً ميتاً فيها، لا يستجيب لأي سحب، ما يجعل بناء
// هذه النوافذ غير مكتمل مقارنةً ببقية التطبيق. الآن تحصل جميعها على نفس السلوك الكامل (حرية
// تمرير المحتوى + سحب بلا جمود بصري) الذي أُصلِح أعلاه.
_wireSheetDrag(tmEl,'.term-out',closeTerm);
_wireSheetDrag(mnEl,'.shsc',closeMenu);
_wireSheetDrag(flEl,'.shsc',closeFilesPanel);
_wireSheetDrag(dmEl,'.dm-scr',closeDevMon);
// لوحتا "غرفة الصمت" و"فيزياء الإلغاء" (أُضيفتا 28 سبتمبر 2026) تحصلان على نفس سلوك السحب
// للإغلاق منذ إنشائهما — بدل أن يتكرر نقص "مقبض سحب بلا استجابة" الذي أُصلِح أعلاه للوحات القديمة.
if(typeof closeMaskPanel!=='undefined'){const mkEl=E('maskPanel');if(mkEl)_wireSheetDrag(mkEl,'.shsc',closeMaskPanel);}
if(typeof closePhysPanel!=='undefined'){const phEl=E('physPanel');if(phEl)_wireSheetDrag(phEl,'.shsc',closePhysPanel);}
if(typeof closeAboutPanel!=='undefined'){const abEl=E('aboutPanel');if(abEl)_wireSheetDrag(abEl,'.shsc',closeAboutPanel);}
if(typeof closePrivacyPanel!=='undefined'){const prEl=E('privacyPanel');if(prEl)_wireSheetDrag(prEl,'.shsc',closePrivacyPanel);}
if(typeof closeLoopDiagPanel!=='undefined'){const ldEl=E('loopDiagPanel');if(ldEl)_wireSheetDrag(ldEl,'.shsc',closeLoopDiagPanel);}
