/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 06-detection-engine-core.js
 محرك الكشف والمعالجة الحي بالكامل: initAudio/startAll/stopAll/detectAll/startCL/startNN/drawLoop/drawOrb
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */
let _audioInitPromise=null;
async function initAudio(){
 if(actx&&micStr)return true;
 if(_audioInitPromise)return _audioInitPromise;
 _audioInitPromise=(async()=>{
 try{
 micStr=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false,channelCount:1,latency:.001}});
 actx=new(window.AudioContext||window.webkitAudioContext)({latencyHint:'interactive'});
 await actx.resume();
 micSrc=actx.createMediaStreamSource(micStr);
 ana=actx.createAnalyser();
 ana.fftSize=32768;ana.smoothingTimeConstant=.4;ana.minDecibels=-120;ana.maxDecibels=-5;
 micSrc.connect(ana);
 P.delay=Math.max(5,((actx.baseLatency||0)+(actx.outputLatency||0))*1000+6);
 return true;
 }catch(err){const ht2=E('homeT2');if(ht2)ht2.textContent='Mic error: '+err.message;return false;}
 finally{_audioInitPromise=null;}
 })();
 return _audioInitPromise;
}

/* ══ START ALL — integrated BG + Storage ══ */
async function startAll(){
 // إغلاق الفراغات: toggleAI() يحتاج معرفة نجاح/فشل التهيئة فعلاً (بدل افتراض النجاح دائماً)
 // كي لا تُطبَّق واجهة "تشغيل" على حالة فشلت فعلاً — لذا أصبحت تُرجع true/false صراحةً.
 const ok=await initAudio();if(!ok)return false;
 isRun=true;
 // مراجعة "المشروع بالكامل": هذا الاستدعاء كان الوحيد في كل الملف غير المحروس بـ
 // if(!NN.w1) — على عكس loadLastWeights()/loadSession()/_restoreFullBackupJSON() كلها.
 // initStorage() (يعمل تلقائياً 800ms بعد تحميل الصفحة) يستعيد أوزاناً مدرَّبة فعلياً من
 // IndexedDB عبر loadLastWeights() قبل أن يضغط المستخدم زر "تشغيل" عادةً. لكن nnInit() هنا
 // كانت تستبدل تلك الأوزان المُستعادة بأوزان عشوائية جديدة دون قيد، دون تصفير NN.trainN —
 // فيستمر الشرط التالي (NN.trainN===0) بالفشل ولا تُعاد محاولة الاستعادة، وتستمر الجلسة
 // على أوزان عشوائية بالكامل بينما يستمر السجل/الواجهة بعرض "trained=200" (قيمة النطاق
 // القديمة) كأن التعلّم مستمر — عملياً، لا "تعلّم" حقيقي كان يبقى بعد أي إعادة تشغيل عادية.
 if(!NN.w1)nnInit();
 profileMic();
 SESSION_STAT.startT=Date.now();SESSION_STAT.hopCount0=FREQ_HOP.count;SESSION_STAT.envCount={};SESSION_STAT.notchPeak=0;SESSION_STAT.suppEffSum=0;SESSION_STAT.suppEffN=0;
 if(notchDecayT)clearInterval(notchDecayT);notchDecayT=setInterval(checkNotchDecay,5000);
 startSF();startDet();startCL();startLearn();startNN();startAudioPoke();initCanvasTap();
 if(!drawId)drawLoop();
 setPlSt(true);{const _t=E('tbTxt');if(_t)_t.textContent='AI Active';}
 // ① Background systems
 if(bgEnabled){
 if(typeof ZeroAndroid!=='undefined'){
 // ZERO-v25 الأصلي يدير خدمة الخلفية (BgService) تلقائياً بنفسه من دورة حياة
 // Activity (onPause/onResume في MainActivity) — لا يستدعيها index.html هنا؛
 // فعل ذلك سابقاً كان تدخلاً زائداً: يُظهر إشعار "معالجة خلفية" حتى والتطبيق
 // بالواجهة الأمامية. الشاشة تُدار عبر setKeepScreenOn الأصلية (وليس WakeLock الويب)
 // تماماً كما صُمم أصلاً في ZERO-v25 (لتفادي السخونة).
 try{ZeroAndroid.setKeepScreenOn(true);}catch(e){}
 startBGWorker(); // مؤقّت غير محظور أثناء التصغير — تكميلي، لا يتعارض
 // لا WakeLock ولا Service Worker ولا إشعارات متصفح هنا: ZERO-v25 الأصلي يتكفل بذلك
 }else{
 // وضع المتصفح (بدون تطبيق ZERO-v25 الأصلي) — الاعتماد الكامل على آليات الويب
 await reqWL();
 startBGWorker();
 await regSW();
 await reqNotifPerm();
 }
 updBGUI();
 bgLog(' Background systems initialized');
 }
 // ② Storage — restore NN if saved
 if(zeroDB&&NN.trainN===0){
 loadLastWeights().then(restored=>{
 if(restored)stLog(' NN weights restored from previous session');
 });
 }
 const paths=getStoragePaths();
 // Emit startup exec log entry
 logExec({prog:'SYS',lines:[
 `ZERO AI v25 initialized — cycle 0`,
 `Mic: ${(actx.sampleRate/1000).toFixed(0)}kHz · Nyquist: ${(actx.sampleRate/2000).toFixed(0)}kHz`,
 `NN: 16→24→8 · ${NN.trainN} pre-trained · lr=${NN.lr}`,
 `Storage: ${paths.available?paths.internal:'IndexedDB'}`,
 `BG: ${bgEnabled?'ON':'OFF'} · THRESH=${FREQ_THRESH} · Speaker: ZERO sound`,
 `Programs: ${Object.keys(AI_LIB).length} loaded — UCB1 scheduler · META_ADAPT every 80 cycles`,
 `New: FREQ_PREDICT · PATTERN_LEARN · META_ADAPT · UCB1 bandit`,
 `Ready — auto-exec starts next NN cycle`,
 ],ms:0,cycle:0,auto:true});
 // Terminal init
 setTimeout(()=>{
 tLog('SYS',
 `import zero_ai_v25 as ai # sr=${actx?actx.sampleRate:0} nyq=${actx?actx.sampleRate/2:0}`,
 `# Python DSL terminal active · ${Object.keys(AI_LIB).length} programs · UCB1 scheduler · type LIST`);
 },200);
 // Initial analyze after first capture
 setTimeout(()=>{if(isRun){const st=getState();logExec({prog:'ANALYZE',lines:AI_LIB.ANALYZE.run(st),ms:0,auto:true});}},3000);
 return true;
}

/* ══════════════════════════
 LAYER 2: SILENT FREQUENCIES
 ALL inaudible — no audible output
══════════════════════════ */
function startSF(){if(!actx)return;stopSF();const mg=actx.createGain();mg.gain.value=0.12;mg.connect(actx.destination);silOscs._m=mg;updSF();}

function updSF(){
 if(!actx||!silOscs._m)return;
 Object.entries(silOscs).forEach(([k,v])=>{if(k==='_m')return;if(v&&v.stop)try{v.stop(0)}catch(e){}if(v&&v.disconnect)try{v.disconnect()}catch(e){}});
 silOscs={_m:silOscs._m};const mg=silOscs._m;const nyq=actx.sampleRate/2;
 // C7 ✓ Spk-Emittable INF (0.5–19Hz) — Class 7
 if(P.useSF.inf){
 const srcSub=fanFreq>0&&fanFreq<20?[fanFreq/2,fanFreq/3].filter(f=>f>0.5):[];
 [...[1,3,7,10,13,17],...srcSub].forEach((hz,i)=>{const o=actx.createOscillator(),g=actx.createGain();o.type='sine';o.frequency.value=hz;g.gain.value=iLv*.07;o.connect(g);g.connect(mg);o.start();silOscs['i'+i]=o;silOscs['ig'+i]=g;});
 }
 // C7 ✓ Spk-Emittable ULT (>20kHz to Nyquist) — Class 7
 if(P.useSF.ult){
 [21000,24000,28000,32000,40000,48000,64000,80000].filter(f=>f<nyq).forEach((hz,i)=>{const o=actx.createOscillator(),g=actx.createGain();o.type='sine';o.frequency.value=hz;g.gain.value=uLv*.05;o.connect(g);g.connect(mg);o.start();silOscs['u'+i]=o;silOscs['ug'+i]=g;});
 }
 // C7 PHF (0.5–19Hz phase field)
 if(P.useSF.phf){
 [0.5,1,2,3,5,6,8,11,14,17,19].forEach((hz,i)=>{const o=actx.createOscillator(),g=actx.createGain();o.type='sine';o.frequency.value=hz;g.gain.value=pLv*.025;o.connect(g);g.connect(mg);o.start();silOscs['p'+i]=o;silOscs['pg'+i]=g;});
 }
 // C6 ✗ Mic-Invisible SUB (<1Hz) — Class 6 physical effect
 if(P.useSF.sub){
 [0.01,0.05,0.1,0.2,0.35,0.5,0.65,0.8,0.95].forEach((hz,i)=>{const o=actx.createOscillator(),g=actx.createGain();o.type='sine';o.frequency.value=hz;g.gain.value=bLv*.035;o.connect(g);g.connect(mg);o.start();silOscs['b'+i]=o;silOscs['bg'+i]=g;});
 }
 // Piezoelectric structural
 if(P.useSF.pie){
 [1,2,3,5,8,12,16,19].forEach((hz,i)=>{const o=actx.createOscillator(),g=actx.createGain();o.type=hz<5?'triangle':'sawtooth';o.frequency.value=hz;g.gain.value=eLv*.028;o.connect(g);g.connect(mg);o.start();silOscs['e'+i]=o;silOscs['eg'+i]=g;});
 }
 const nyqK=(nyq/1000).toFixed(0)+'kHz';
 const I=E('pv-if');if(I)I.textContent=P.useSF.inf?'0.5-19Hz':'off';
 const U=E('pv-uf');if(U)U.textContent=P.useSF.ult?'20kHz-'+nyqK:'off';
 const Ph=E('pv-pf');if(Ph)Ph.textContent=P.useSF.phf?(pLv*100).toFixed(0)+'%':'off';
 const S=E('pv-sf');if(S)S.textContent=P.useSF.sub?'0.01-0.95Hz':'off';
}

function stopSF(){Object.entries(silOscs).forEach(([k,v])=>{if(!v)return;if(v.stop)try{v.stop(0)}catch(e){}if(v.disconnect)try{v.disconnect()}catch(e){}});silOscs={};}

/* ══════════════════════════
 LAYER 1: DETECTION
 All 12 algorithms + 8-class classify
══════════════════════════ */
function startDet(){clearInterval(aT);aT=setInterval(detectAll,40);}

function detectAll(){
 if(!ana||!actx)return;
 const td=new Uint8Array(ana.fftSize),fd=new Float32Array(ana.frequencyBinCount);
 ana.getByteTimeDomainData(td);ana.getFloatFrequencyData(fd);
 // ── Software Notch Suppression ── attenuate confirmed freqs in FFT data
 const fdRaw=NOTCH_SUPPRESS.size>0?fd.slice(0):null;
 if(NOTCH_SUPPRESS.size>0){
 const bHz2=actx.sampleRate/ana.fftSize;
 NOTCH_SUPPRESS.forEach(({hz,depth,halfBins})=>{
 const bin=Math.round(hz/bHz2);
 for(let i=Math.max(0,bin-halfBins);i<=Math.min(fd.length-1,bin+halfBins);i++){
 const w=1-Math.abs(i-bin)/(halfBins+1);
 fd[i]-=depth*w;
 }
 });
 updateSuppEff(fdRaw);
 }
 const bHz=actx.sampleRate/ana.fftSize,nyq=actx.sampleRate/2,mxB=fd.length-1;

 // ① MUSIC + peak detect — full spectrum
 let pk=-Infinity,pB=2;for(let i=2;i<mxB;i++)if(fd[i]>pk){pk=fd[i];pB=i;}
 if(pB>=2&&pB<fd.length-2){
 const a=fd[pB-1],b=fd[pB],c=fd[pB+1],dv=2*b-a-c;
 // إصلاح جذري لمصدر خلل "NaNHz": getFloatFrequencyData يُرجِع -Infinity لأي خانة FFT
 // ذات طاقة صفرية تماماً — أمر طبيعي جداً لخانة مجاورة هادئة حتى لو كانت القمة b نفسها
 // حقيقية (b=pk قيمة منتهية دائماً بما أنها أعلى قيمة رُصدت). حين يكون أحد الجارين a/c
 // ‎-Infinity‏، ‎(a-c)/(2*dv)‏ يُصبح Infinity/Infinity أو -Infinity/Infinity = NaN، وهذا
 // NaN كان يتسرّب مباشرة إلى hz ثم KF.x[0] ويُسمِّم حالة مرشّح كالمان بشكل دائم (لا شيء
 // كان يتحقّق من isFinite لاحقاً)، فيظهر "NaNHz" في كل مكان يعرض الترددات المحظورة.
 // الإصلاح: أي إزاحة غير منتهية تُهمَل وتُستبدَل بصفر (تُستخدَم خانة القمة الخام بلا
 // تدقيق دون-الخانة، بدل تمرير قيمة فاسدة).
 let _off=dv!==0?(a-c)/(2*dv):0;
 if(!isFinite(_off))_off=0;
 let hz=Math.max(0,(pB+_off)*bHz);
 // مراجعة سادسة ضمن إصلاح "الوميض/التجمّد المؤقت": هذا السطر كان يُنشئ مصفوفة JS
 // عادية جديدة عبر نشر ([...]) نسخة من fd (حتى 4094 عنصراً هنا فعلياً — ana.fftSize=32768
 // يعني frequencyBinCount=16384، وMath.min(mxB,4096) يُثبِّت الحدّ الفعلي عند 4096)، ثم
 // يفرزها بمقارِن JS مخصَّص ((x,y)=>x-y) — فرز O(n log n) لآلاف العناصر مع استدعاء دالة
 // JS لكل مقارنة — فقط لاستخراج الوسيط (median) كمرجع لحساب SNR. يحدث هذا في كل دورة
 // detectAll تقريباً (حتى 25 مرة/ثانية) طوال تشغيل المحرك — أي طوال أغلب وقت الاستخدام
 // الفعلي، بما فيه أثناء أي تنقّل بين القوائم بالتوازي. الإصلاح: fd.slice(...) تُنتج أصلاً
 // Float32Array مستقلة (نسخة، لا تُغيِّر fd الأصلية) — فرزها مباشرة عبر %TypedArray%.sort()
 // بلا مقارِن مخصَّص يُعطي بالضبط نفس الترتيب العددي التصاعدي (الترتيب الافتراضي لمصفوفات
 // الأرقام المكتوبة هو عددي تصاعدي، بخلاف Array.prototype.sort الذي يفترض نصياً افتراضياً)
 // — نفس القيمة العددية للوسيط تماماً بلا أي تغيير في النتيجة أو السلوك — فقط بلا نسخ
 // المصفوفة الوسيطة الزائد وبلا عبء استدعاء دالة JS لكل مقارنة.
 const srt=fd.slice(2,Math.min(mxB,4096)).sort(),snr=pk-srt[Math.floor(srt.length/2)];
 if(snr>12&&(!FREQ_BAND.enabled||hz>=FREQ_BAND.lo&&hz<=FREQ_BAND.hi)){ // Open range; optional band lock
 // ② Kalman filter
 // شفاء ذاتي: إن كانت حالة المرشّح المستمرّة (من دورة سابقة) قد تسمّمت بأي شكل غير
 // متوقَّع (NaN/Infinity)، نصفّرها بدل ترك التسمّم يتكرّر إلى الأبد كل دورة لاحقة.
 if(!isFinite(KF.x[0])||!isFinite(KF.x[1])||!isFinite(KF.P[0])){KF.x=[0,0];KF.P=[1,1];KF.init=false;}
 if(!KF.init){KF.x[0]=hz;KF.init=true;}
 // ① KF×SPEC_FLUX — Flux-Adaptive Process Noise: volatile spectrum → trust prediction less
 if(typeof SPEC_FLUX!=='undefined'&&SPEC_FLUX.val>0.3)KF.Q[0]=Math.min(0.5,0.01+SPEC_FLUX.val*0.15);
 const fP=KF.x[0]+KF.x[1]*.3;KF.P[0]=Math.min(KF.P[0]+KF.Q[0],100);
 const K=KF.P[0]/(KF.P[0]+KF.R);KF.x[0]=fP+K*(hz-fP);KF.x[1]+=K*(hz-fP)*.1;KF.P[0]=(1-K)*KF.P[0];
 fanFreq=KF.x[0];fanE=Math.min(1,(snr+12)/40);
 // تشديد: تردد أساسي محضور (سواء كان من الحضر الافتراضي أو مؤكَّد مسبقاً) لا يُسمح
 // له بأي تصويت حظر، تعب تردد، تنبيه، أو تغذية هارمونيات بعد هذه النقطة في الحلقة
 const fanBanned=AI_GATE.enabled&&AI_BAN.has(fBin(fanFreq));
 if(!fanBanned)detectFreqHop(fanFreq); // تشديد: تردد محضور لا يدخل سجل/تصدير القفزات (FREQ_HOP)
 checkNotchSuggest(fanFreq); // Dev100: smart notch suggestion
 if(!fanBanned)checkFreqAlarms(fanFreq); // Dev110: frequency alarm — لا تنبيه لتردد محضور
 // Dev120: KF Lock — pull KF toward target Hz if enabled
 if(KF_LOCK.enabled){if(Math.abs(KF.x[0]-KF_LOCK.hz)>KF_LOCK.tol){KF.x[0]+=(KF_LOCK.hz-KF.x[0])*0.3;}fanFreq=KF.x[0];}
 // Dev120: REC — capture frame into rolling buffer
 if(REC.active&&fanFreq>1){REC.buf.push({t:Date.now()-REC.startT,hz:+fanFreq.toFixed(2),e:+fanE.toFixed(3),env:curEnvClass,sqi:SQI.val});if(REC.buf.length>REC.maxLen)REC.buf.shift();}
 // Adaptive notch tracking — slide notch center when freq drifts
 adaptNotchTrack(fanFreq);
 // Refresh lastHit for nearby notches (decay tracking)
 if(NOTCH_DECAY.enabled&&NOTCH_SUPPRESS.size){NOTCH_SUPPRESS.forEach(n=>{if(Math.abs(n.hz-fanFreq)<=n.halfBins*bHz*4)n.lastHit=Date.now();});}
 // Bipolar energy update
 if(Math.cos(DRV.phase*Math.PI/180)>0)RANGE.posE=RANGE.posE*.99+fanE*.01;
 else RANGE.negE=RANGE.negE*.99+fanE*.01;
 RANGE.polarityRatio=(RANGE.posE+RANGE.negE>0)?RANGE.posE/(RANGE.posE+RANGE.negE):0.5;
 // Spectral flux
 updateSpecFlux(fd);
 // Zero crossing rate (between SPEC_FLUX and centroid)
 updateZeroCross(td);
 // Crest factor (impulsiveness)
 updateCrest(td);
 // ⑨ ZCRATE×CREST — ZCR-Crest dual-axis signal classifier
 if(!window.ZCREST)window.ZCREST={state:'steady',score:0};
 {const z=ZCRATE.val,c=CREST.val;if(z>0.35&&c>4)ZCREST.state='impulsive';else if(z>0.35&&c<=4)ZCREST.state='noisy';else if(z<=0.35&&c>4)ZCREST.state='click';else ZCREST.state='tonal';ZCREST.score=z*c;}
 // Energy envelope
 updateEnvelope(td);
 // Polarity tracking
 POLAR_HIST.update(fanE);
 // Centroid
 updateCentroid(fd,bHz);
 // Harmonic series detection — تشديد: يُمنع عن تردد محظور، وإلا يبقى HARMONICS.fund/q
 // يحدَّث لتردد محظور ويظهر حرفياً في #harmonic-q كل ~80ms رغم أنه محضور
 if(!fanBanned)detectHarmonicSeries(fanFreq,fd,bHz);
 // ⑧ CENTROID×HARMONICS — Centroid-harmonic tonality flag
 CENTROID.tonal=!!(HARMONICS.series&&HARMONICS.series.some(s=>Math.abs(CENTROID.hz-s.hz)<CENTROID.hz*0.2));
 // ⑦ Harmonic Coherence Map: weight series partials by HNR
 if(!window.HCM)window.HCM={score:0};
 {const hnrN=Math.max(0,Math.min(1,HNR.val/20));let hcS=0,hcN=0;if(HARMONICS.series)HARMONICS.series.forEach(s=>{const b2=Math.round(s.hz/bHz);if(b2>0&&b2<fd.length){hcS+=Math.pow(10,fd[b2]/10)*hnrN;hcN++;}});HCM.score=hcN>0?Math.min(1,hcS/hcN/100):0;}
 // Spectral moments (μ/σ/skew/kurt)
 updateSpectralMoments(fd,bHz);
 // Chroma vector (12 pitch classes)
 updateChromaVec(fd,bHz);
 // ① Tonal-Kalman snap: nudge KF toward nearest confirmed harmonic Hz
 if(KF.init&&HARMONICS.series&&HARMONICS.series.length>0){let minD=Infinity,snapHz=KF.x[0];HARMONICS.series.forEach(s=>{const d=Math.abs(s.hz-KF.x[0]);if(d<minD){minD=d;snapHz=s.hz;}});if(minD<KF.x[0]*.04)KF.x[0]+=(snapHz-KF.x[0])*.06;}
 // AM/FM modulation index
 updateModulation(td);
 // Spectral rolloff 85%
 updateRolloff(fd,bHz);
 // ③ CENTROID×ROLLOFF — Spectral balance ratio: cent/rolloff → bias characterization
 CENTROID.rolloffRatio=ROLLOFF.hz>0?CENTROID.hz/ROLLOFF.hz:0;
 // Spectral flatness (Wiener entropy)
 updateSpectralFlatness(fd);
 // ④ RANGE×SPEC_FLAT — Flatness-driven RANGE bias mode
 if(SPEC_FLAT.val>0.65)RANGE.biasMode='bipolar';else if(SPEC_FLAT.val<0.1)RANGE.biasMode='pos';
 // ⑩ KF×ROLLOFF — Rolloff-constrained KF upper bound
 if(KF.init&&ROLLOFF.hz>0&&KF.x[0]>ROLLOFF.hz*0.9&&SPEC_FLAT.val>0.5){KF.x[0]=ROLLOFF.hz*0.85;fanFreq=KF.x[0];}
 // HNR (harmonic-to-noise ratio)
 updateHNR(fd,bHz);
 // ⑦ MIC×HNR — HNR-synchronized MIC feature profile
 MIC.feat.hnr=HNR.val;
 // Room mode peaks
 detectRoomModes(fd,bHz);
 // ③ Room-Aware MUSIC: mark spectral bins at detected room mode peaks
 // مراجعة "المشروع بالكامل": هذا القسم كان يُخزِّن أرقام خانات FFT الخام
 // (Math.round(hz/bHz)) في RAMUSIC.bins، بينما نقطة الاستهلاك الوحيدة (أدناه، عند
 // "RAMUSIC×castBanVote") تستعلم بمفتاح من نطاق مختلف كلياً: fBin(fanFreq) — وهو تقريب
 // بالهرتز لأقرب 0.5Hz، وهو نطاق المفاتيح المستخدَم في كل مكان آخر بالملف (freqDB،
 // AI_BAN، BAN_VOTE، NOTCH_SUPPRESS...). بما أن bHz (عرض الخانة الفعلي، مثلاً ≈5.38Hz
 // لـ44100Hz/8192 FFT) لا يساوي 0.5 أبداً عملياً، لا يتطابق النطاقان تقريباً إطلاقاً —
 // فحماية "أوضاع الغرفة" من تراكم تصويت الحظر (ban vote) لم تكن تعمل فعلياً لأي تردد
 // حقيقي متوافق مع القمة المكتشفة. الإصلاح: تخزين مفاتيح fBin() بنفس نطاق الاستهلاك.
 if(!window.RAMUSIC)window.RAMUSIC={bins:new Set()};
 if(ROOM_MODES.peaks.length>0){RAMUSIC.bins.clear();ROOM_MODES.peaks.forEach(p=>{RAMUSIC.bins.add(fBin(p.hz));RAMUSIC.bins.add(fBin(p.hz-bHz));RAMUSIC.bins.add(fBin(p.hz+bHz));});}
 // ⑤ RAMUSIC×HARMONICS — Harmonic-extended RAMUSIC protection
 if(HARMONICS.series&&HARMONICS.series.length>0){HARMONICS.series.forEach(s=>{if(s.hz>0&&s.hz<nyq)RAMUSIC.bins.add(fBin(s.hz));});}
 // Environment change detection
 ENV_CHANGE_D.detect(fd);
 // Acoustic signature hash
 updateAcousticSig(fd);
 // Tonal power ratio
 updateTonalRatio(fd,bHz);
 // Frequency fatigue + ban vote — تُعلَّق بالكامل لتردد محضور أساسي (تشديد اكثر)
 if(!fanBanned){
 updateFreqFatigue(fanFreq,fanE);
 castBanVote(fanFreq,'spectral',SPEC_FLAT.val<0.1?2:0.5);
 if(THERMAL.rising)castBanVote(fanFreq,'thermal',1.5);
 if(ANTI_IDLE.avgFrame>50)castBanVote(fanFreq,'lag',1.2);
 // ④ BANVOTE×AI_CTX — high crest factor in context → amplified ban vote
 if(AI_CTX.crestFactor>3)castBanVote(fanFreq,'ctx',Math.min(2.5,(AI_CTX.crestFactor-3)*0.3+0.5));
 // ⑩ BANVOTE×FREQ_CLUSTER — freq inside a dense cluster → amplified ban vote
 {const inClust=FREQ_CLUSTER.groups.some(g=>fanFreq>=g.min&&fanFreq<=g.max&&g.count>2);if(inClust)castBanVote(fanFreq,'cluster',1.8);}
 }
 // ⑨ RAMUSIC×castBanVote — room-mode protected bin → decay accumulated ban score
 {const rbk=fBin(fanFreq);if(RAMUSIC.bins.has(rbk)){const bv=BAN_VOTE.get(rbk);if(bv)bv.total=Math.max(0,bv.total*0.45);}}
 // Recurrence
 updateRecurrence(fanFreq);
 // ⑤ PITCH_AMDF×RECURRENCE — Pitch-Recurrence Validation: pitch aligned with fan → boost det
 if(PITCH_AMDF.hz>10&&RECURRENCE.period>0&&RECURRENCE.det>0.3){const pitchBin=fBin(PITCH_AMDF.hz);const fanBin=fBin(fanFreq);if(Math.abs(pitchBin-fanBin)<3)RECURRENCE.det=Math.min(1,RECURRENCE.det*1.15);}
 // ③ HNR×HEBBIAN — HNR-Weighted Hebbian Reward: clean tone → stronger reinforcement
 if(PITCH_AMDF.hz>10){const hnrW=Math.max(0.1,Math.min(3,1+HNR.val/20));hebbLearn(fanFreq,PITCH_AMDF.hz,(loopE/100)*hnrW);}
 // Frame time tracker for anti-idle
 const _ft=performance.now()-ANTI_IDLE.lastFrame;
 if(ANTI_IDLE.lastFrame>0)ANTI_IDLE.frameTimes.push(_ft);
 ANTI_IDLE.lastFrame=performance.now();
 if(ANTI_IDLE.frameTimes.length>30)ANTI_IDLE.frameTimes.shift();
 if(ANTI_IDLE.frameTimes.length>3){ANTI_IDLE.avgFrame=ANTI_IDLE.frameTimes.reduce((a,b)=>a+b,0)/ANTI_IDLE.frameTimes.length;}
 // Sluggishness monitor
 monitorSlugFreqs();
 // Auto-ban harmful/noisy freqs immediately on detection
 autoDetectAndBan(fanFreq,fanE);
 // Record to FreqDB (skipped if just auto-banned) — NN learns
 fRecord(fanFreq,fanE);
 // ④ ROLLOFF×FreqDB — Rolloff-Contextual FreqDB tagging: above=broadband, below=tonal
 if(ROLLOFF.hz>0){const b=fBin(fanFreq);if(freqDB.has(b)){const e=freqDB.get(b);if(!e.rolloffCtx||aiCyc%50===0)e.rolloffCtx=fanFreq>ROLLOFF.hz?'above':'below';}}
 // تردد محضور (أساسي أو جديد، سيّان) لا يُسمح له بالتكرار عند كل التقاط جديد من لاقطة
 // الصوت — يُستبعد كلياً من التصنيف (C1-C16) هنا تماماً كما استُبعد أعلاه من FreqDB
 // ومن بناء الإبطال الصوتي (buildInverse)؛ فقط trackPostBanDetection (داخل fRecord)
 // يتابعه بصمت للتحقق من فعالية الحظر، دون أي ظهور جديد في أي قائمة أو عدّاد.
 const hzBanned=AI_GATE.enabled&&AI_BAN.has(fBin(hz));
 if(!hzBanned){
 // 8-class classification
 const ph=DRV.phase*Math.PI/180;const cls=classifyFreq(hz,fanE*(fanE>0?1:-1),ph,nyq);
 if(freqDB.has(fBin(hz)))freqDB.get(fBin(hz)).class=cls;
 // ⑥ FC×PITCH_AMDF — Pitch-confirmed C5 counter boost
 if(PITCH_AMDF.conf>0.5&&Math.abs(hz-PITCH_AMDF.hz)<hz*0.04){FC.c5++;}
 }
 // ⑦ HARMONICS×FreqDB — Harmonic series FreqDB seeding (2nd–4th partial)
 // تشديد: إذا كان التردد الأساسي (fanFreq) نفسه محضوراً، فهارمونياته لا تُغذّي FreqDB
 // ولا الإبطال الصوتي — يمنع تسرّب صوت تردد محضور عبر تردداته التوافقية على منفذ آخر
 if(!fanBanned&&HARMONICS.series&&HARMONICS.series.length>1){HARMONICS.series.slice(1,4).forEach(s=>{if(s.amp>0.01)fRecord(s.hz,s.amp*fanE*0.3);});}
 const mhzEl=E('mHz');if(mhzEl)mhzEl.textContent=fanFreq.toFixed(1)+'Hz';
 const mu=E('pv-mu');if(mu)mu.textContent=fanFreq.toFixed(3)+'Hz';
 const ka=E('pv-ka');if(ka)ka.textContent=KF.x[0].toFixed(2)+'Hz';
 }else{fanE=Math.max(0,fanE-.05);}
 }
 // Dev100: multi-peak scan (runs every detectAll frame, ~40ms)
 scanPeaks(fd,bHz,mxB);
 // Dev110: octave band power + store FFT frame for DELTA
 updateBandPower(fd,bHz);
 if(!lastFFD||lastFFD.length!==fd.length)lastFFD=new Float32Array(fd.length);
 lastFFD.set(fd);SPEC_DELTA.bHz=bHz;
 // ③ Hilbert
 // مراجعة "النسخة النهائية": prevX كانت تُعاد كتابتها كل تكرار إلى نفس القيمة الثابتة
 // (td[td.length-1]، آخر عيّنة في المخزن) بدل العيّنة السابقة الفعلية — فتنهار الحلقة كاملة
 // إلى مقارنة واحدة بين آخر عيّنتين فقط، محسوبة بتكرار عبثي في كل خطوة سابقة، بدل تقدير طور
 // Hilbert التراكمي عبر الإطار كما يوحي شكل الحلقة — يُضعِف دقة "Phase-Coherence Polar" بصمت.
 for(let k=1;k<td.length-1;k++){const x=(td[k]-128)/128;if(x&&prevX)hlPh=Math.atan2(x,prevX);prevX=x;}
 // ⑧ Phase-Coherence Polar: Hilbert phase angle accumulated into 8-sector histogram
 if(!window.PCPOLAR)window.PCPOLAR={hist:new Float32Array(8)};
 {const pSec=Math.floor(((hlPh+Math.PI)/(2*Math.PI))*8)%8;PCPOLAR.hist[pSec]=PCPOLAR.hist[pSec]*.98+fanE*.02;}
 // ④ Fx-LMS C(z)
 const fi=(td[Math.floor(td.length/2)]-128)/128;for(let j=FX_N-1;j>0;j--)fxXb[j]=fxXb[j-1];fxXb[0]=fi;let fY=0;for(let j=0;j<FX_N;j++)fY+=fxW[j]*fxXb[j];const er=fi+fY;let xN=1e-6;for(let j=0;j<FX_N;j++)xN+=fxXb[j]*fxXb[j];const fxMu=P.mu*(0.5+Math.max(0,Math.min(1,HNR.val/20)))/xN;for(let j=0;j<FX_N;j++){fxW[j]-=fxMu*er*fxXb[j];fxW[j]=Math.max(-2,Math.min(2,fxW[j]));}fxMSE=fxMSE*.997+er*er*.003;
 // ② FxLMS×FreqDB — confirmed interference freq → extra LMS convergence step
 {const fb2=fBin(fanFreq);if(freqDB.has(fb2)&&(freqDB.get(fb2).confirmed||0)>2){const exMu=P.mu*0.4/Math.max(1e-6,xN);for(let j=0;j<FX_N;j++){fxW[j]-=exMu*er*fxXb[j];fxW[j]=Math.max(-2,Math.min(2,fxW[j]));}}}
 // ⑨ FxLMS×RECURRENCE — recurrent freq → extra LMS pass for faster cancellation
 if(RECURRENCE.det>0.5&&RECURRENCE.period>0&&Math.abs(fanFreq-RECURRENCE.period*bHz)<fanFreq*0.1){const rbMu=fxMu*Math.min(0.5,RECURRENCE.det*0.6);for(let j=0;j<FX_N;j++){fxW[j]-=rbMu*er*fxXb[j];fxW[j]=Math.max(-2,Math.min(2,fxW[j]));}}
 // ② CENTROID×FxLMS — spectral centroid brightness → scaled extra LMS convergence
 {const cS=Math.min(1.5,1+CENTROID.hz/(nyq||8000));const cMu=P.mu*cS*0.12/Math.max(1e-6,xN);for(let j=0;j<FX_N;j++){fxW[j]-=cMu*er*fxXb[j];fxW[j]=Math.max(-2,Math.min(2,fxW[j]));}}
 // ⑧ DRV×FxLMS — dominant Bayesian sound weight → extra convergence pass
 if(DRV.wS>0.55){const dMu=P.mu*(DRV.wS-0.5)*0.4/Math.max(1e-6,xN);for(let j=0;j<FX_N;j++){fxW[j]-=dMu*er*fxXb[j];fxW[j]=Math.max(-2,Math.min(2,fxW[j]));}}
 // ⑤ EVP (0–40Hz)
 if(P.useEVP){const eM=Math.min(Math.ceil(40/bHz),fd.length-1);let eS=0,eC=0,ePk=-Infinity,ePB=1;for(let i=1;i<eM;i++){const p2=Math.pow(10,fd[i]/10);eS+=p2;eC++;if(fd[i]>ePk){ePk=fd[i];ePB=i;}}evpE=Math.min(1,Math.sqrt(eC>0?eS/eC:0)/10);evpHz=ePB*bHz;if(evpE>.05)fRecord(evpHz,evpE*.5);const ep=E('pv-evp');if(ep)ep.textContent=(evpE*100).toFixed(0)+'%@'+evpHz.toFixed(1)+'Hz';}
 // ⑤ MIC×EVP — MIC HNR feature → EVP energy amplification for tonal infrasound
 if(typeof MIC!=='undefined'&&MIC.feat&&MIC.feat.hnr>0.5)evpE=Math.min(1,evpE*(1+MIC.feat.hnr*0.25));
 // ⑩ Infrasonic Carrier Detector: find dominant 0–4Hz sub-carrier bin
 if(!window.ICD)window.ICD={detected:false,hz:0,strength:0};
 if(bHz>0){const iM=Math.max(2,Math.ceil(4/bHz));let iMax=-Infinity,iBin=1;for(let i=1;i<Math.min(iM,fd.length-1);i++){if(fd[i]>iMax){iMax=fd[i];iBin=i;}}ICD.hz=iBin*bHz;ICD.strength=Math.min(1,Math.pow(10,iMax/10)/50);ICD.detected=ICD.strength>.15;}
 // ⑥ EMF (50/60Hz harmonics)
 if(P.useEMF){let emS=0,emN=0;[50,60].forEach(base=>{for(let h=1;base*h<nyq&&base*h<20000;h++){const b2=Math.round((base*h)/bHz);if(b2<fd.length){emS+=Math.pow(10,fd[b2]/10);emN++;}}});emfE=Math.min(1,Math.sqrt(emN>0?emS/emN:0)/20);const em=E('pv-emf');if(em)em.textContent=(emfE*100).toFixed(1)+'%';}
 // ⑦ EMF×FREQ_CLUSTER — flag frequency clusters that overlap 50/60Hz harmonics (EMF interference zone)
 if(!window.EMF_CLUST_FLAG)window.EMF_CLUST_FLAG=new Set();
 EMF_CLUST_FLAG.clear();[50,60].forEach(base=>{for(let h=1;base*h<nyq;h++){const hHz=base*h;FREQ_CLUSTER.groups.forEach((g,idx)=>{if(hHz>=g.min&&hHz<=g.max)EMF_CLUST_FLAG.add(idx);});}});
 // ⑦ HCM×EMF — high harmonic content score → amplify EMF detection energy
 if(typeof HCM!=='undefined'&&HCM.score>0.4)emfE=Math.min(1,emfE*(1+HCM.score*0.5));
 // ④ Shape-Adaptive Wiener: tune α/β dynamically from spectral flatness
 {const sf=SPEC_FLAT.val;P.alpha=Math.max(0.8,Math.min(3.0,1.5+(1-sf)*.5));P.beta=Math.max(0.005,Math.min(0.05,0.01+sf*.04));}
 // ① WIEN×NN — NN-Loss-Adaptive Wiener α: high training loss → more aggressive suppression
 if(typeof NN!=='undefined'&&NN.loss>0.5)P.alpha=Math.min(3.5,P.alpha*(1+NN.loss*0.2));
 // ④ RANGE×Wiener — RANGE polarity mode → Wiener floor-leak β fine-tuning
 if(RANGE.biasMode==='pos')P.beta=Math.max(0.005,P.beta*0.88);else if(RANGE.biasMode==='bipolar')P.beta=Math.min(0.05,P.beta*1.12);
 // ⑦ Wiener — full spectrum
 const nB=fd.length-1;let fNum=0,fDen=0;for(let i=5;i<nB;i++){const p2=Math.pow(10,fd[i]/10);fNum+=Math.log(p2+1e-10);fDen+=p2;}const gM=Math.exp(fNum/nB),aM=fDen/nB;noiseE=Math.min(1,Math.max(0,(aM>0?gM/aM:0)*3));if(!nFloor||nFloor.length!==nB)nFloor=new Float32Array(nB);for(let i=0;i<nB;i++)nFloor[i]=nFloor[i]*.97+Math.pow(10,fd[i]/10)*.03;let wG=0;for(let i=5;i<nB;i++){const X=Math.pow(10,fd[i]/10),N=nFloor[i],s=Math.max(P.beta*N,X-P.alpha*N);wG+=X>0?Math.sqrt(s/X):P.beta;}wG/=nB;const wi=E('pv-wi');if(wi)wi.textContent=wG.toFixed(3);
 // ① KF×Wiener — KF-refined frequency → extra nFloor accumulation at tracked bin
 if(KF.init&&KF.x[0]>0&&nFloor){const kb=Math.min(Math.round(KF.x[0]/bHz),nFloor.length-1);if(kb>0)nFloor[kb]=nFloor[kb]*.93+Math.pow(10,fd[Math.min(kb,fd.length-1)]/10)*.07;}
 // ⑧ Transient z-score — full spectrum
 let rms=0;for(let i=0;i<td.length;i++){const v=(td[i]-128)/128;rms+=v*v;}rms=Math.sqrt(rms/td.length);const z=(rms-0.05)/Math.max(0.02,.001);sharpE=Math.min(1,Math.max(0,z/10));const tz=E('pv-tz');if(tz)tz.textContent=z.toFixed(2)+'σ';
 // ⑥ Dual-Gate Transient: z-score × HNR classify impulse / semi / steady
 if(!window.DGTC)window.DGTC={gate:0,cls:'steady'};
 {if(z>3&&HNR.val<5){DGTC.gate=1;DGTC.cls='impulse';}else if(z>1.5&&sharpE>.4){DGTC.gate=.5;DGTC.cls='semi';}else{DGTC.gate=0;DGTC.cls='steady';}}
 // ③ DGTC×RECURRENCE — recurrence-confirmed periodic impulse → upgrade semi→impulse
 if(DGTC.cls==='semi'&&RECURRENCE.det>0.5&&RECURRENCE.period>0){DGTC.gate=1;DGTC.cls='impulse';}
 // ③ CREST×DGTC — high crest factor confirms DGTC impulse gate upgrade
 if(DGTC.cls==='semi'&&CREST.val>5){DGTC.gate=1;DGTC.cls='impulse';}
 // Extract features for NN
 extractFeat(td,fd,bHz);
 // ⑥ EVP×UCB1 — UCB1 top-ranked program → boost its corresponding NN input feature
 {const topProg=AI_CTX.rankedProgs&&AI_CTX.rankedProgs[0];if(topProg&&typeof NN!=='undefined'&&Array.isArray(NN.inp)&&NN.inp.length>0){const pIdx=AI_LIB.findIndex(p=>p.name===topProg);if(pIdx>=0&&pIdx<NN.inp.length)NN.inp[pIdx]=Math.min(1,NN.inp[pIdx]*1.1);}}
 // Periodic DB purge
 if(aiCyc%20===0){fPurge();updateOctaveDensity();if(aiCyc%60===0)BAN_PATTERNS.detect();} // Periodic: cluster update, AMDF pitch, timing drift, cluster
 if(aiCyc%300===0){PERSIST.saveBans();PERSIST.saveZones();PERSIST.scheduleNNSave();PERSIST.saveFC();PERSIST.saveRoomModes();PERSIST.saveWienerNF();} // حفظ دوري كل 300 دورة (تشديد: أُضيف saveZones كشبكة أمان إضافية فوق الحفظ المؤجَّل)
 // ⑤ INV×HEBBIAN — Hebbian co-activation → shorten INV.verMs for faster verification
 if(INV.active.size>0&&HEBBIAN.size>0){let maxH=0;HEBBIAN.forEach((v,k)=>{if(v>maxH){const p=k.split(':');if(Math.abs(parseFloat(p[0])-fanFreq)<100||Math.abs(parseFloat(p[1])-fanFreq)<100)maxH=v;}});if(maxH>0.8)INV.verMs=Math.max(250,INV.verMs-20);}
 // ⑥ ZCRATE×INV — noisy/percussive signal (high ZCR) → shorten INV verification delay
 if(ZCRATE.val>0.3&&INV.active.size>0)INV.verMs=Math.max(200,INV.verMs-Math.round(ZCRATE.val*60));
 // ⑩ FC×INV — highly confirmed FreqDB entry → accelerate INV.verMs further
 {const fck=fBin(fanFreq);if(freqDB.has(fck)&&(freqDB.get(fck).confirmed||0)>5)INV.verMs=Math.max(200,INV.verMs-25);}
 if(aiCyc%25===0){updateFreqClusters();}
 if(aiCyc%40===0){updatePitchAMDF(td);}
 // ⑨ Pitch-Guided Delay: set CL delay to half pitch period for phase-cancel alignment
 if(!window.PGD)window.PGD={delayMs:5};
 if(PITCH_AMDF.hz>10&&PITCH_AMDF.conf>.3)PGD.delayMs=Math.min(25,500/PITCH_AMDF.hz);
 updateTimingDrift();
 if(aiCyc%15===0)updateTD(loopE/100,silSc);
 if(aiCyc%100===0)updateWtHist();
 // Environmental fingerprint update
 updateEnvFingerprint(fd,bHz);
 // Internal load fingerprint
 if(aiCyc%10===0)updateInternalLoad();
 // Adaptive FFT (between-idea feature)
 if(aiCyc%30===0)adaptFFT();
 // Update 16-class display
 update16Class(nyq);
}

function update16Class(nyq){
 const counts={c1:0,c2:0,c3:0,c4:0,c5:0,c6:0,c7:0,c8:0,c9:0,c10:0,c11:0,c12:0,c13:0,c14:0,c15:0,c16:0};
 freqDB.forEach(e=>{
 const hz=Math.abs(e.hz||0);
 if(hz<0.01)counts.c9++;
 else if(hz<20)counts.c10++;
 else if(hz>=20000&&hz<200000)counts.c11++;
 else if(hz>=200000)counts.c12++;
 else if(HARMONICS.series.some(s=>Math.abs(s.hz-hz)<hz*0.02))counts.c13++;
 else if(THERMAL.correlFreqs.has(fBin(e.hz)))counts.c14++;
 else if(ANTI_IDLE.lagFreqs.has(fBin(e.hz)))counts.c15++;
 else if(ENV_FP.bgFreqs.has(fBin(e.hz)))counts.c16++;
 else if(hz>=20&&hz<=nyq/2)counts.c5++;
 else if(hz<1||hz>nyq)counts.c6++;
 else if(hz>=0.01&&hz<=nyq)counts.c7++;
 else counts.c8++;
 if(e.energy>0)counts.c1++;else counts.c2++;
 });
 const setFC=(id,val,suf='')=>{const el=E(id);if(el)el.textContent=val+suf;};
 // Original 8-class display (backward compat)
 for(let i=1;i<=8;i++){setFC('fc'+i,counts['c'+i]);setFC('c'+i+'v',counts['c'+i]);}
 // New classes 9-16
 for(let i=9;i<=16;i++){setFC('fc'+i,counts['c'+i]);setFC('c'+i+'v',counts['c'+i]);}
 // Bipolar ratio display
 const bpv=E('bipolar-ratio');if(bpv)bpv.textContent=(RANGE.polarityRatio*100).toFixed(0)+'% pos / '+(( 1-RANGE.polarityRatio)*100).toFixed(0)+'% neg';
}

/* Coherence */
function updCoh(tS,tR){
 if(!actx)return;const sr=actx.sampleRate,N=Math.min(tS.length,1024);let avg=0,vc=0;
 COH_F.forEach((freq,fi)=>{
 if(freq>sr/2){const fl=E('cmf-'+fi);if(fl)fl.style.width='0%';const vl=E('cmv-'+fi);if(vl)vl.textContent='n/a';return;}
 const k=Math.round(freq/sr*N),w=2*Math.PI*k/N,cW=Math.cos(w);let s1x=0,s2x=0,s1y=0,s2y=0;
 for(let n=0;n<N;n++){const xn=(tS[n]-128)/128,yn=(tR[n]-128)/128;const nx=cW*s1x-s2x+xn;s2x=s1x;s1x=nx;const ny=cW*s1y-s2y+yn;s2y=s1y;s1y=ny;}
 const Pxx=Math.abs(s1x*s1x+s2x*s2x-cW*s1x*s2x),Pyy=Math.abs(s1y*s1y+s2y*s2y-cW*s1y*s2y);
 cSxx[fi]=cSxx[fi]*.88+Pxx*.12;cSyy[fi]=cSyy[fi]*.88+Pyy*.12;cSxy[fi]=cSxy[fi]*.88+Math.sqrt(Pxx*Pyy)*.12;
 const d=cSxx[fi]*cSyy[fi],coh=d>1e-14?Math.min(1,(cSxy[fi]*cSxy[fi])/d):0;cV[fi]=cV[fi]*.75+coh*.25;
 const sfB=Math.min(0.35,(iLv+uLv+pLv+bLv+eLv)*.1);const cancel=Math.max(0,Math.min(1,1-cV[fi]+sfB));avg+=cancel;vc++;
 const fl=E('cmf-'+fi);if(fl){fl.style.width=(cancel*100)+'%';fl.style.background=cancel>.8?'#a9a9a9':cancel>.5?'#959595':'#787878';}
 const vl=E('cmv-'+fi);if(vl)vl.textContent=(cancel*100).toFixed(0)+'%';
 });
 if(vc>0)avg/=vc;silSc=Math.round(avg*100);
 const mc=E('mCoh');if(mc)mc.textContent=(avg*100).toFixed(0)+'%';const ms=E('pv-coh');if(ms)ms.textContent=(avg*100).toFixed(1)+'%';
}

/* Closed Loop */
function startCL(){
 clearInterval(cT);
 cT=setInterval(()=>{
 if(!isRun||!ana)return;loopN++;
 const td=new Uint8Array(ana.fftSize);ana.getByteTimeDomainData(td);
 let rms=0;for(let i=0;i<td.length;i++){const v=(td[i]-128)/128;rms+=v*v;}rms=Math.sqrt(rms/td.length);
 loopE=rms;const lr=prevLE>0?(prevLE-loopE)/prevLE:0;prevLE=loopE;
 // Adaptive SF boost via closed loop
 if(loopE>.06){iLv=Math.min(1,iLv*1.008);uLv=Math.min(1,uLv*1.008);pLv=Math.min(1,pLv*1.008);}
 // ⑤ Flux-Triggered CL Reset: spectral flux spike + low energy → reset Kalman + soften levels
 if(SPEC_FLUX.val>.6&&loopE<.03&&KF.init){KF.x[0]=fanFreq;KF.P[0]=10;KF.x[1]=0;iLv=Math.max(.2,iLv*.85);}
 if(loopN%12===0)updSF();
 // Bayesian weights
 const tot=fanE+noiseE+sharpE+evpE+emfE+.001;
 DRV.wS=(fanE+noiseE+sharpE)/tot;DRV.wE=P.useEVP?evpE/tot:0;DRV.wM=P.useEMF?emfE/tot:0;
 const ws=DRV.wS+DRV.wE+DRV.wM||1;DRV.wS/=ws;DRV.wE/=ws;DRV.wM/=ws;
 // ② DRV×CHROMA_VEC — Chroma-Guided Bayesian Weight: tonal confidence → boost spectral weight
 if(typeof CHROMA_VEC!=='undefined'&&CHROMA_VEC.conf>0.75){DRV.wS=Math.min(0.7,DRV.wS*1.05);const ws2=DRV.wS+DRV.wE+DRV.wM||1;DRV.wS/=ws2;DRV.wE/=ws2;DRV.wM/=ws2;}
 const w1=E('pv-w1'),w2=E('pv-w2'),w3=E('pv-w3');
 if(w1)w1.textContent=(DRV.wS*100).toFixed(0)+'%';if(w2)w2.textContent=(DRV.wE*100).toFixed(0)+'%';if(w3)w3.textContent=(DRV.wM*100).toFixed(0)+'%';
 aiCon=Math.min(100,Math.round(silSc*.7+Math.min(learnN*4,20)+Math.max(0,100-loopE*500)*.1));
 // Update Android BG service notification every 10 loops
 if(loopN%33===0)renderBanList(); // update ban list every ~2s
 if(loopN%10===0&&typeof ZeroAndroid!=='undefined')
 ZeroAndroid.updateBGStatus('Silence:'+silSc+'% · Cycle:'+aiCyc+' · FreqDB:'+freqDB.size);
 const cb2=E('confB');if(cb2){cb2.style.width=aiCon+'%';cb2.style.background=aiCon>80?'#a9a9a9':aiCon>50?'#959595':'#787878';}
 const ms2=E('mSil');if(ms2)ms2.textContent=silSc+'%';
 const lp=E('pv-lp');if(lp)lp.textContent=loopN;const le=E('pv-le');if(le)le.textContent=(loopE*100).toFixed(2)+'%';
 if(silSc>=80&&isRun){setS('zero');const st=E('sTit');if(st)st.textContent='Silence Achieved';const si2=E('siD');if(si2)si2.className='si-d sil';const sit=E('siT');if(sit)sit.textContent='Silent field stable — ZERO audible output';}
 // Update pipeline NN stats
 const pnntc=E('pv-tc');if(pnntc)pnntc.textContent=NN.trainN;
 const pnnls=E('pv-ls');if(pnnls)pnnls.textContent=NN.loss.toFixed(4);
 const pnndb=E('pv-db');if(pnndb)pnndb.textContent=freqDB.size;
 const pnniv=E('pv-iv');if(pnniv)pnniv.textContent=INV.active.size;
 const pco=E('pv-co');if(pco)pco.textContent=freqFile.totalConf;
 const pca=E('pv-ca');if(pca)pca.textContent=freqFile.totalCanc;
 const pas=E('pv-as');if(pas)pas.textContent=INV.failed.size;
 const psi2=E('ps-nn');if(psi2){psi2.textContent=NN.trainN>0?'ACTIVE':'IDLE';psi2.className='pls '+(NN.trainN>0?'run':'');}
 const pinv=E('ps-inv');if(pinv){pinv.textContent=INV.active.size>0?'ACTIVE':'IDLE';pinv.className='pls '+(INV.active.size>0?'inv':'');}
 },60);
}

/* NN Cycle */
function startNN(){clearInterval(nnT);nnT=setInterval(()=>{
 if(!isRun||!NN.w1)return;
 aiCyc++;
 if(aiCyc%100===0)saveFreqDB();
 if(aiCyc%2===0)pushFreqHist();
 if(aiCyc%50===0)classifyEnvironment();
 const inp=nnInp();
 const{out}=nnFwd(inp);
 nnCtrlSF(out);
 const rw=silSc>50?(silSc-50)/50:-0.1;
 if(aiCyc%4===0)nnTrain(inp,rw);
 updateNNUI();
 // AI EXEC autonomous cycle (runs program library)
 aiExecCycle();
 // Update EXEC UI stat bar
 updateExecUI();
 // Update asC/asT (now used for exec cycle)
 // execCycLbl updated by updateExecUI()
 const mc=E('mCyc');if(mc)mc.textContent=aiCyc;
 const sc=E('cSc');if(sc)sc.textContent=silSc+'%';
 const cst=E('cSt');if(cst)cst.textContent=silSc>=80?'γ²→0':'loop '+loopN;
},80);}

/* Self-Learn */
function startLearn(){clearInterval(lT);lT=setInterval(()=>{
 if(!isRun||!P.useLearn)return;
 const reward=loopE/100;
 // Push current state to replay buffer
 if(NN.w1)erPush(nnInp(),reward,silSc);
 // Replay mini-batch
 const batch=erSample();
 for(const s of batch){try{nnTrain(s.inp,s.reward);}catch(e){}}
 if(silSc>bestSil){bestSil=silSc;learnN++;logNN(' New best: '+bestSil+'% silence (pattern #'+learnN+')');}
},500);}

/* ══ DRAW LOOP ══ */
// مراجعة خامسة ضمن إصلاح "الوميض/التجمّد المؤقت": drawLoop تعمل عند 60 إطاراً/ثانية
// طوال تشغيل المحرك فعلياً (isRun) — أي طوال أغلب وقت استخدام تطبيق ANC حقيقةً، بما
// في ذلك أثناء تصفّح القوائم بالتوازي. كانت تُخصِّص Uint8Array جديدة بالكامل (new
// Uint8Array(ana.fftSize)) في كل إطار من الصفر بدل إعادة استخدام مصفوفة واحدة ثابتة —
// نفايات ذاكرة (garbage) مستمرة يجمعها محرك V8 دورياً عبر GC، وقد يتزامن توقّف GC
// قصير هذا تماماً مع لحظة تفاعل المستخدم (فتح قائمة)، فيظهر كـ"توقف مفاجئ ثم استكمال"
// بالضبط كما وُصفت المشكلة. تحقّق دقيق قبل التعديل: تأكَّدت أن كل مستهلكي `td` هنا
// (updCoh عبر sfEff، drawOrb، updateLevelMeter) يقرؤون قيمها فوراً ولا يحتفظ أيّ منهم
// بمرجع المصفوفة نفسها لاحقاً — فإعادة استخدام مخزن واحد ثابت هنا آمنة تماماً. بالمقابل
// تُرِكت `fd8` أدناه (طيف السبيكتروجرام) دون تغيير عمداً — pushSpecFrame() تُخزِّن مرجع
// المصفوفة نفسها داخل specHistory للرسم التاريخي لاحقاً، فإعادة استخدام نفس المخزن هناك
// كانت ستُفسِد كل الصفوف المخزَّنة سابقاً بصمت (تصبح جميعها نفس القيم الأخيرة) — خطأ حقيقي
// كان سيُستبدَل بمكسب أداء افتراضي، فتُرِك ذلك الموضع كما هو تحديداً لهذا السبب.
let _drawLoopTD=null;
function drawLoop(){
 if(!isRun){drawId=null;return;}
 drawId=requestAnimationFrame(drawLoop);
 if(!ana)return;
 if(!_drawLoopTD||_drawLoopTD.length!==ana.fftSize)_drawLoopTD=new Uint8Array(ana.fftSize);
 const td=_drawLoopTD;
 ana.getByteTimeDomainData(td);
 updCoh(td,sfEff(td));
 drawOrb(td);
 updateLevelMeter(td);
 // Spectrogram frame — push every ~4th frame for performance
 if(drawId%4===0||specHistory.length===0){
 const fd8=new Uint8Array(ana.frequencyBinCount);
 ana.getByteFrequencyData(fd8);
 pushSpecFrame(fd8);
 }
 if(curTab===0){drawMiniSpec();drawFreqTimeline();}
}

// تتمة الملاحظة أعلاه: sfEff() تُستدعى من drawLoop (~60/ثانية) ومن physDrawLoop
// (12-session-features-extra.js، ~60/ثانية أيضاً أثناء فتح لوحة الفيزياء) — تحقّقت من
// كلا الاستدعاءين: updCoh() تقرأ القيم فوراً، physDrawWave()/حساب rms يقرآن ويرسمان
// فوراً أيضاً — لا أحد يحتفظ بمرجع النتيجة، فإعادة استخدام مخزن واحد ثابت هنا آمنة.
let _sfEffBuf=null;
function sfEff(data){
 if(!_sfEffBuf||_sfEffBuf.length!==data.length)_sfEffBuf=new Uint8Array(data.length);
 const r=_sfEffBuf;
 const ef=Math.max(0.05,(iLv*.28+uLv*.32+pLv*.28));
 for(let i=0;i<data.length;i++){const o=(data[i]-128)/128;r[i]=Math.max(0,Math.min(255,128+o*(1-ef)*128));}
 return r;
}

function drawOrb(td){
 const cv=E('orbCv');if(!cv)return;const dpr=window.devicePixelRatio||1;const sz=190;cv.width=sz*dpr;cv.height=sz*dpr;
 const ctx=cv.getContext('2d');ctx.scale(dpr,dpr);ctx.clearRect(0,0,sz,sz);
 const cx=sz/2,cy=sz/2,R=cx-10,sc=silSc/100;
 // Waveform
 ctx.beginPath();for(let i=0;i<=80;i++){const a=(i/80)*Math.PI*2-Math.PI/2;const v=(td[Math.floor((i/80)*td.length)]-128)/128;const r=R-8+v*9;ctx.lineTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r);}
 ctx.strokeStyle=silSc>80?`rgba(169,169,169,${0.1+sc*.15})`:isOn?`rgba(129,129,129,${0.1+sc*.12})`:`rgba(123,123,123,.08)`;ctx.lineWidth=1.2;ctx.closePath();ctx.stroke();
 // Silence arc
 ctx.beginPath();ctx.arc(cx,cy,R,-Math.PI/2,-Math.PI/2+sc*Math.PI*2);ctx.strokeStyle=silSc>80?'rgba(169,169,169,.6)':isOn?'rgba(129,129,129,.55)':'rgba(123,123,123,.55)';ctx.lineWidth=2.5;ctx.lineCap='round';ctx.stroke();
 // Class arcs
 const nyq2=actx?actx.sampleRate/2:24000;let c5cnt=0,c7cnt=0;freqDB.forEach(e=>{if(e.hz>=20&&e.hz<=nyq2/2)c5cnt++;if(e.hz>=0.01&&e.hz<=nyq2)c7cnt++;});
 [{c:'rgba(149,149,149,.4)',v:Math.min(c5cnt/20,1),r:R+4},{c:'rgba(165,165,165,.35)',v:Math.min(c7cnt/20,1),r:R+8},{c:'rgba(120,120,120,.4)',v:iLv,r:R-20}].forEach(a=>{if(a.v<.05)return;ctx.beginPath();ctx.arc(cx,cy,a.r,-Math.PI/2,-Math.PI/2+a.v*Math.PI*1.5);ctx.strokeStyle=a.c;ctx.lineWidth=1.5;ctx.lineCap='round';ctx.stroke();});
 ctx.setTransform(1,0,0,1,0,0);
}

/* ══ STOP ══ */
function stopAll(){
 // ── Session Report ──
 if(SESSION_STAT.startT>0&&isRun){
 const dur=Math.round((Date.now()-SESSION_STAT.startT)/1000);
 const m=Math.floor(dur/60),s=dur%60;
 const hops=FREQ_HOP.count-SESSION_STAT.hopCount0;
 const avgEff=SESSION_STAT.suppEffN>0?Math.round(SESSION_STAT.suppEffSum/SESSION_STAT.suppEffN):0;
 const domEnv=Object.entries(SESSION_STAT.envCount).sort((a,b)=>b[1]-a[1]).map(e=>e[0])[0]||'—';
 logNN(` SESSION: ${m}m${s}s · hops=${hops} · notchPeak=${SESSION_STAT.notchPeak} · avgEff=${avgEff}% · env=${domEnv}`);
 SESSION_STAT.startT=0;
 }
 if(notchDecayT){clearInterval(notchDecayT);notchDecayT=null;}
 isRun=false;
 // Stop BG systems
 relWL();stopBGWorker();stopSW();closeBGNotif();bgMode=false;updBGUI();
 // Save session
 if(zeroDB)saveSession().then(()=>{stLog(' Session auto-saved on stop');if(curTab===7)refreshSessionList();});
 // Save to Android storage if available
 if(typeof ZeroAndroid!=='undefined')androidWrite('logs','stop_'+Date.now()+'.txt','Stopped at cycle '+aiCyc+' silence '+silSc+'%');
 // Stop Android BG service (شبكة أمان: تنظيف أي حالة خلفية متبقية) + إعادة الشاشة لوضعها الطبيعي
 if(typeof ZeroAndroid!=='undefined'){ZeroAndroid.stopBG();try{ZeroAndroid.setKeepScreenOn(false);}catch(e){}}
 // Stop audio
 stopSF();stopAudioPoke();
 [aT,cT,lT,nnT].forEach(t=>{if(t)clearInterval(t);});aT=cT=lT=nnT=null;
 if(drawId){cancelAnimationFrame(drawId);drawId=null;}
 INV.active.forEach(v=>{try{v.osc.stop();v.g.disconnect();}catch(e){}});INV.active.clear();INV.failed.clear();
 if(micStr){micStr.getTracks().forEach(t=>t.stop());micStr=null;}
 if(actx){actx.close();actx=null;}
 micSrc=ana=null;fanFreq=0;fanE=0;silSc=0;aiCyc=0;iLv=uLv=pLv=bLv=eLv=0;
 setPlSt(false);
 const sc=E('cSc');if(sc)sc.textContent='0%';
 const ec=E('execCurr');if(ec)ec.textContent='STOPPED';
 const ed=E('execDot');if(ed)ed.className='exec-run-dot';
 const ct=E('cSt');if(ct)ct.textContent='tap to start';
 const cb=E('confB');if(cb)cb.style.width='0%';
 // Hide level meter on stop
 const lm=E('lvlMeter');if(lm)lm.style.display='none';
 const le=E('envLabel');if(le)le.style.display='none';
 const lrEl=E('lr');if(lrEl)lrEl.classList.remove('go');
 {const _t=E('tbTxt');if(_t)_t.textContent='AI Brain';}
 setS('off');
}

function setPlSt(on){
 const s=on?'ACTIVE':'IDLE';
 [['ps-mic-stage','run'],['ps-alg','run'],['ps-sf','sil'],['ps-coh','run'],
 ['ps-bx','ai2'],['ps-cl','run'],['ps-nn','sil'],['ps-inv','inv']
 ].forEach(([id,cls])=>{const el=E(id);if(!el)return;el.textContent=s;el.className='pls'+(on?' '+cls:'');});
}

/* Coh Mini Build */
function buildCoh(){const g=E('cohMini');if(!g)return;COH_F.forEach((hz,i)=>{const row=document.createElement('div');row.className='cm';row.innerHTML=`<span class="cmh">${hz<1000?hz+'Hz':(hz/1000)+'k'}</span><div class="cmt"><div class="cmf" id="cmf-${i}"></div></div><span class="cmv" id="cmv-${i}">0%</span>`;g.appendChild(row);});}

/* ══ UI UPDATES ══ */
function logNN(msg){
 const ts=new Date(),t=String(ts.getMinutes()).padStart(2,'0')+':'+String(ts.getSeconds()).padStart(2,'0');
 NN_LOG.unshift({msg,t});if(NN_LOG.length>80)NN_LOG.pop();
 if(curTab===4){const el=E('nn-log');if(el)el.innerHTML=NN_LOG.slice(0,12).map(l=>`<div style="font-family:var(--fm);font-size:9px;color:var(--muted);padding:2px 0;border-bottom:1px solid rgba(255,255,255,.04)"><span style="color:rgba(255,255,255,.3)">${l.t}</span> ${l.msg}</div>`).join('');}
}

function updateNNUI(){
 const tc=E('nn-tc');if(tc)tc.textContent=NN.trainN;const ls=E('nn-loss');if(ls)ls.textContent=NN.loss.toFixed(4);const lr=E('nn-lr');if(lr)lr.textContent=NN.lr.toFixed(4);
 if(NN.lastOut){['nno0','nno1','nno2','nno3','nno4','nno5'].forEach((id,i)=>{const el=E(id);if(el)el.textContent=(NN.lastOut[i]*100).toFixed(0)+'%';});}
}

function updateFreqUI(){
 const dc=E('db-cap');if(dc)dc.textContent=freqFile.totalCap;const df=E('db-conf');if(df)df.textContent=freqFile.totalConf;const dca=E('db-canc');if(dca)dca.textContent=freqFile.totalCanc;const di=E('db-inv');if(di)di.textContent=INV.active.size;
 const list=E('flist');if(!list)return;
 // خط دفاع أخير: نستبعد فقط القيم غير المنتهية (NaN) — لا الترددات السالبة، فهي مقصودة
 // فعلياً من ميزة negFreqMirror (مرآة التردد السالب) وتُعرَض هنا عمداً كـ"-xHz"
 const top=freqFile.entries.filter(e=>typeof e.hz==='number'&&isFinite(e.hz)).slice(0,14);
 list.innerHTML=top.length?top.map(e=>{
 const c=e.cancelled?'var(--zero)':e.confirmed?'var(--ai)':'var(--dim)';
 const st=e.cancelled?'✓CANC':e.confirmed?'INV('+e.count+'×)':'('+e.count+'×)';
 const clsArr=['','C1⊕','C2⊖','C3∓','C4±','C5✓','C6✗','C7✓','C8✗','C9','C10𝒊','C11↑','C12∞','C13','C14','C15','C16'];const cls=clsArr[e.class||0]||'';
 return `<div style="display:flex;justify-content:space-between;align-items:center;padding:3px 0;border-bottom:1px solid rgba(255,255,255,.04)"><span style="font-family:var(--fm);font-size:9px;color:${c}">${e.hz.toFixed(1)}Hz</span><span style="font-family:var(--fm);font-size:8px;color:rgba(149,149,149,.7)">${cls}</span><span style="font-family:var(--fm);font-size:9px;color:${c}">${st}</span></div>`;
 }).join(''):'<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">Waiting for mic input...</div>';
 updateInvUI();
}

function updateInvUI(){
 const list=E('inv-list');if(!list)return;
 if(!INV.active.size){list.innerHTML='<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">None active</div>';return;}
 list.innerHTML=[...INV.active.values()].map(v=>`<div style="display:flex;justify-content:space-between;padding:3px 0;border-bottom:1px solid rgba(255,255,255,.04)"><span style="font-family:var(--fm);font-size:9px;color:var(--sharp)">${v.hz.toFixed(2)}Hz</span><span style="font-family:var(--fm);font-size:9px;color:var(--muted)">att:${v.attempts}/${INV.maxTry}</span><span style="font-family:var(--fm);font-size:9px;color:${v.verified?'var(--zero)':'var(--ai)'}">${v.verified?'✓DONE':'⟳INV'}</span></div>`).join('');
}


/* ══ REDESIGNED BAN UI ══ */
function updateMicUI(){
 if(!MIC.sr)return;const el=E('mic-prof');if(!el)return;
 el.innerHTML=[['Sample Rate',MIC.sr/1000+'kHz','var(--zero)'],['Nyquist',(MIC.nyq/1000).toFixed(1)+'kHz','var(--zero)'],['FFT Res',MIC.fftRes.toFixed(3)+'Hz/bin','var(--c5)'],['Range',MIC.minDet.toFixed(2)+'→'+(MIC.maxDet/1000).toFixed(0)+'kHz','var(--c7)'],['Dyn Range',MIC.dynRange+'dB','var(--ai)'],['Latency',MIC.latMs.toFixed(1)+'ms','var(--noise)']].map(([k,v,c])=>`<div style="display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="font-family:var(--fm);font-size:9px;color:rgba(255,255,255,.3)">${k}</span><span style="font-family:var(--fm);font-size:9px;color:${c}">${v}</span></div>`).join('');
}

function updateMicFeat(){
 const el=E('mic-feat');if(!el)return;
 el.innerHTML=[['Spectral Centroid',(MIC.feat.cent/1000).toFixed(2)+'kHz','var(--sharp)'],['Zero-Cross Rate',(MIC.feat.zcr*100).toFixed(1)+'%','var(--c5)'],['Crest Factor',MIC.feat.crest.toFixed(2),'var(--c3)'],['Spectral Flatness',(MIC.feat.flat*100).toFixed(1)+'%','var(--c5)'],['HNR',MIC.feat.hnr.toFixed(2),'var(--fan)']].map(([k,v,c])=>`<div style="display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px solid rgba(255,255,255,.03)"><span style="font-family:var(--fm);font-size:9px;color:rgba(255,255,255,.3)">${k}</span><span style="font-family:var(--fm);font-size:9px;color:${c}">${v}</span></div>`).join('');
}

/* Charts */
function drawRwChart(){
 const cv=E('rwCv');if(!cv||!NN.hist.length)return;
 const ctx=cv.getContext('2d');const W=cv.width,H=cv.height;ctx.clearRect(0,0,W,H);
 const hist=NN.hist.slice(-60);
 ctx.strokeStyle='rgba(255,255,255,.05)';ctx.beginPath();ctx.moveTo(0,H/2);ctx.lineTo(W,H/2);ctx.stroke();
 ctx.beginPath();hist.forEach((pt,i)=>{const x=(i/(Math.max(hist.length-1,1)))*W;const y=H/2-(pt.reward*(H/2-3));i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);});
 ctx.strokeStyle='rgba(169,169,169,.7)';ctx.lineWidth=1.5;ctx.stroke();
 drawNNWeights();
}

/* ══ NN WEIGHT HEATMAP ══ */
function drawNNWeights(){
 const cv=E('nnWtCv');if(!cv||!NN.w1||!NN.w1.length)return;
 const dpr=window.devicePixelRatio||1;
 const W=cv.clientWidth||320;const H=60;
 if(cv.width!==Math.round(W*dpr)){cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);}
 const ctx=cv.getContext('2d');if(!ctx)return;
 const cW=cv.width,cH=cv.height;
 ctx.clearRect(0,0,cW,cH);
 // مراجعة "النسخة النهائية": NN.w1 مصفوفة مسطَّحة (Float dim ni*nh عبر xv(ni,nh) في nnInit،
 // ومفهرَسة w1[i*nh+j] في nnFwd نفسها) — لم تكن أبداً مصفوفة متداخلة [][ كما افترض هذا الرسم.
 // NN.w1[0] كانت رقماً مفرداً، `.length` عليه undefined، فـ cols=undefined وكل حلقة j<cols
 // كانت false دائماً (0<undefined) — لا خطأ ظاهر، فقط لوحة حرارة NN فارغة تماماً في كل مرة،
 // منذ نمو الشبكة من 12→16 مدخلاً حين توقف هذا الرسم عن مطابقة شكلها الفعلي.
 const rows=NN.in,cols=NN.hid; // 16 inputs × 24 hidden (راجع تعريف NN أعلاه)
 // Find min/max for normalization
 let mn=Infinity,mx=-Infinity;
 for(let i=0;i<rows;i++)for(let j=0;j<cols;j++){const w=NN.w1[i*cols+j];if(w<mn)mn=w;if(w>mx)mx=w;}
 const range=mx-mn||1;
 const cellW=cW/cols;const cellH=cH/rows;
 for(let i=0;i<rows;i++){
 for(let j=0;j<cols;j++){
 const t=(NN.w1[i*cols+j]-mn)/range; // 0→1
 // كانت: cold (blue) → black → warm (green/amber) — حُذفت الصبغة اللونية (28 سبتمبر
 // 2026) إبقاءً على نفس منطق حساب الإضاءة (r,g,b) ثم تحويل الناتج فعلياً إلى رمادي عبر
 // معادلة luma القياسية (نفس المعادلة المُطبَّقة آلياً على شريط التدرّج الثابت أسفله)،
 // فيبقى المفهوم (قيمة منخفضة=غامق، حدّية=أسود، مرتفعة=فاتح) سليماً بلا أي لون.
 let r,g,b;
 if(t<0.45){const v=t/0.45;r=0;g=0;b=Math.round(v*180);}
 else if(t<0.55){r=0;g=0;b=0;}
 else{const v=(t-0.55)/0.45;r=Math.round(v*180);g=Math.round(v*255);b=0;}
 const nnY=Math.round(0.299*r+0.587*g+0.114*b);
 ctx.fillStyle=`rgb(${nnY},${nnY},${nnY})`;
 ctx.fillRect(Math.round(j*cellW),Math.round(i*cellH),Math.ceil(cellW)+1,Math.ceil(cellH)+1);
 }
 }
 // Row input labels — تُطابق ترتيب nnInp() بالضبط؛ 4 مدخلات أُضيفت لاحقاً (Pol/Thm/Frm/Cnt)
 // حين نمت الشبكة من 12→16 مدخلاً دون تحديث هذه المصفوفة، فبقيت 4 صفوف بلا تسمية سابقاً.
 const lbl=['Hz','En','DB','EVP','EMF','Lp','Ph','MSE','Sil','1-L','Tr','ToD','Pol','Thm','Frm','Cnt'];
 ctx.font=`${Math.round(5.5*dpr)}px monospace`;ctx.fillStyle='rgba(255,255,255,.6)';
 for(let i=0;i<Math.min(rows,lbl.length);i++){
 ctx.fillText(lbl[i],1*dpr,Math.round((i+0.78)*cellH));
 }
 // Color legend strip
 const grd=ctx.createLinearGradient(cW*0.75,0,cW,0);
 grd.addColorStop(0,'rgb(21,21,21)');grd.addColorStop(0.45,'rgb(0,0,0)');grd.addColorStop(1,'rgb(186,186,186)');
 ctx.fillStyle=grd;ctx.fillRect(Math.round(cW*0.75),cH-6*dpr,Math.round(cW*0.25),4*dpr);
 ctx.fillStyle='rgba(255,255,255,.35)';ctx.font=`${Math.round(5*dpr)}px monospace`;
 ctx.fillText('−',Math.round(cW*0.75)+1,cH-7*dpr);ctx.fillText('+',cW-7*dpr,cH-7*dpr);
}

/* ══ ENV-ADAPTIVE LAYER AUTO-TUNE ══ */
function envAdaptSF(){
 if(!isRun||thermalThrottleOn)return;
 // Small bias nudge — augments NN output, never overrides it fully
 // Rate: ±4% max per call, called every 10 cycles (800ms)
 const env=curEnvClass;
 switch(env){
 case 'quiet':
 iLv=Math.max(0.15,iLv*0.97);uLv=Math.max(0.05,uLv*0.94);
 pLv=Math.max(0.12,pLv*0.96);bLv=Math.max(0.1,bLv*0.96);
 break;
 case 'mechanical':
 // Machinery hum → infrasound + phase field
 iLv=Math.min(0.98,iLv*1.03);pLv=Math.min(0.95,pLv*1.02);
 break;
 case 'tonal':
 // Tonal signal → standard + sub layers, reduce ultrasound
 uLv=Math.max(0.15,uLv*0.97);bLv=Math.min(0.9,bLv*1.02);
 break;
 case 'noise':
 // Broadband noise → balanced uniform boost
 iLv=Math.min(0.9,iLv*1.01);uLv=Math.min(0.9,uLv*1.01);
 pLv=Math.min(0.9,pLv*1.01);bLv=Math.min(0.9,bLv*1.01);
 break;
 case 'impulsive':
 // Transient spike → phase field + piezo
 pLv=Math.min(0.98,pLv*1.04);eLv=Math.min(0.95,eLv*1.03);
 break;
 case 'interference':
 // EMI/RFI → ultrasound suppression layer
 uLv=Math.min(0.95,uLv*1.03);eLv=Math.min(0.9,eLv*1.02);
 break;
 }
 updSFGains();
 // Update adaptive status display in NN tab
 const p=(v)=>(v*100).toFixed(0)+'%';
 const si=E('ea-inf'),su=E('ea-ult'),sp=E('ea-phf'),sb=E('ea-sub'),se=E('ea-pie'),sv=E('ea-env');
 if(si)si.textContent=p(iLv);if(su)su.textContent=p(uLv);
 if(sp)sp.textContent=p(pLv);if(sb)sb.textContent=p(bLv);
 if(se)se.textContent=p(eLv);
 if(sv)sv.textContent=ENV_LABELS[env]?ENV_LABELS[env].label.split(' ')[1]||env:env;
}

/* ══ FREQUENCY CLUSTER ANALYZER ══ */
function buildFreqClusters(){
 const confirmed=[...freqDB.values()]
 .filter(e=>e.confirmed&&e.hz>0)
 .sort((a,b)=>a.hz-b.hz);
 if(confirmed.length<1)return[];
 const used=new Set();const clusters=[];
 for(let i=0;i<confirmed.length;i++){
 if(used.has(i))continue;
 const root=confirmed[i];
 const cl={root:root.hz,members:[{entry:root,harmN:1}]};
 used.add(i);
 for(let j=i+1;j<confirmed.length;j++){
 if(used.has(j))continue;
 const ratio=confirmed[j].hz/root.hz;
 const nearest=Math.round(ratio);
 if(nearest>=2&&nearest<=24&&Math.abs(ratio-nearest)/nearest<0.025){
 cl.members.push({entry:confirmed[j],harmN:nearest});
 used.add(j);
 }
 }
 clusters.push(cl);
 }
 return clusters;
}

function updateClusterUI(){
 const cl=E('cluster-list');const cc=E('cluster-count');if(!cl)return;
 const clusters=buildFreqClusters();
 if(cc)cc.textContent=clusters.length;
 if(!clusters.length){
 cl.innerHTML='<div style="font-family:var(--fm);font-size:9px;color:var(--muted)">في انتظار ترددات مؤكدة...</div>';
 return;
 }
 cl.innerHTML=clusters.map((c,ci)=>{
 const membHtml=c.members.map((m,mi)=>{
 const col=mi===0?'var(--on)':'var(--c5)';
 const tag=mi===0?'':('×'+m.harmN);
 return `<span style="color:${col};font-family:var(--fm);font-size:9px;font-weight:700">${m.entry.hz.toFixed(1)}Hz<span style="color:var(--muted);font-weight:400;font-size:7.5px">${tag}</span></span>`;
 }).join('<span style="color:var(--brd2);margin:0 3px">→</span>');
 const fund=c.members[0].entry.hz;
 const clsTag=c.members.length>=3?'<span style="font-size:7px;color:rgba(120,120,120,.8);background:rgba(120,120,120,.1);border:1px solid rgba(120,120,120,.2);border-radius:4px;padding:0 4px;margin-left:4px">SERIES</span>':'';
 return `<div style="padding:5px 0;border-bottom:1px solid var(--brd)">
 <div style="font-family:var(--fm);font-size:7.5px;color:var(--muted);margin-bottom:3px">CLUSTER ${ci+1} · fund ${fund.toFixed(2)}Hz · ${c.members.length} harmonic${c.members.length>1?'s':''}${clsTag}</div>
 <div style="display:flex;flex-wrap:wrap;gap:4px;align-items:center">${membHtml}</div>
 </div>`;
 }).join('');
}

function drawClassChart(){
 const cv=E('classCv');if(!cv)return;
 const ctx=cv.getContext('2d');const W=cv.width,H=cv.height;ctx.clearRect(0,0,W,H);
 const nyq=actx?actx.sampleRate/2:24000;const labels=['C1⊕','C2⊖','C3∓','C4±','C5+','C6-','C7+','C8-'];
 const colors=['var(--c1)','var(--c2)','var(--c3)','var(--c4)','var(--c5)','var(--c6)','var(--c7)','var(--c8)'];
 const hexC=['#a9a9a9','#686868','#9c9c9c','#787878','#959595','#888888','#a5a5a5','#888888'];
 const counts=[FC.c1,FC.c2,FC.c3,FC.c4,FC.c5,FC.c6,FC.c7,FC.c8];
 const mx=Math.max(...counts,1);const bw=W/8;
 counts.forEach((v,i)=>{const h=Math.max(2,(v/mx)*(H-10));ctx.fillStyle=hexC[i]+'88';ctx.fillRect(i*bw+2,H-h,bw-4,h);ctx.fillStyle=hexC[i];ctx.font='8px monospace';ctx.fillText(v,i*bw+4,H-h-2);});
}

function drawMicSpec(){
 if(!ana||curTab!==3)return;
 const cv=E('micSpecCv');if(!cv)return;
 const ctx=cv.getContext('2d');const W=cv.width,H=cv.height;ctx.clearRect(0,0,W,H);
 const fd=new Uint8Array(ana.frequencyBinCount);ana.getByteFrequencyData(fd);
 const step=Math.ceil(fd.length/W);
 // كان يُلوَّن كل عمود بتدرّج hue (200→260° حسب الشدّة v) بإضاءة/تشبّع ثابتين — حُذفت الصبغة
 // اللونية (28 سبتمبر 2026) بتصفير التشبّع (0%) وتحويل الشدّة v نفسها إلى إضاءة (lightness)
 // متغيّرة بدلاً من الهيو، فيبقى المفهوم البصري (كلما زادت الشدّة زاد السطوع) قائماً بلا لون.
 for(let x=0;x<W;x++){const bin=x*step;if(bin>=fd.length)break;const v=fd[bin]/255;const lgt=Math.round(15+v*70);ctx.fillStyle=`hsla(0,0%,${lgt}%,.7)`;ctx.fillRect(x,H-v*H,1,v*H);}
}

setInterval(()=>{
 // تتمة إصلاح "الوميض/التجمّد المؤقت عند فتح التطبيق وتبديل القوائم" (راجع أيضاً
 // bgLoop في 08c-background-db.js لنفس فئة الخلل): هذا المؤقّت (12.5 مرة/ثانية) كان
 // يعمل بلا أي شرط رؤية إطلاقاً — فقط `curTab===N` (أيّ تبويب داخلي كان آخر مرة نشِطاً
 // داخل aiPanel) — لا يتحقق أبداً من كون aiPanel نفسها مفتوحة أصلاً (aOpen). فالحالة
 // الافتراضية (curTab=0 قبل أي فتح لِلوحة) كانت تُشغِّل updateFreqUI() كل 80ms إلى الأبد
 // من إقلاع التطبيق — إعادة بناء innerHTML لحتى 14 صفاً + استدعاء updateInvUI() — حتى
 // لو لم تُفتَح aiPanel إطلاقاً؛ وإن فتحها المستخدم مرّة وبدَّل لتبويب رسم (1: NN reward
 // chart، 2: تصنيف، 3: طيف الميكروفون) ثم أغلق اللوحة دون العودة لتبويب 0 — يبقى ذلك
 // الرسم (canvas fillRect/fillText لكل إطار) يعمل أيضاً إلى الأبد خلف لوحة مغلقة تماماً
 // (transform:translateX(102%))، أي عمل غير مرئي إطلاقاً يتنافس بلا داعٍ مع أي تفاعل
 // لاحق (فتح/تبديل قوائم أخرى) على نفس الخيط الرئيسي الوحيد. الإصلاح: تخطّي الكتلة
 // كاملة ما دامت aiPanel مغلقة فعلياً — نفس مبدأ التحقق من `.ovl.on` في bgLoop.
 if(!aOpen)return;
 if(curTab===1)drawRwChart();
 if(curTab===2)drawClassChart();
 if(curTab===3){drawMicSpec();updateMicFeat();}
 if(curTab===0)updateFreqUI();
 // Update lag count display
 const lcnt=E('lag-freq-cnt');if(lcnt)lcnt.textContent=ENV_FP.slugFreqs.size+' ترددات';
 // Update harmonic Q display
 const hq=E('harmonic-q');if(hq)hq.textContent=HARMONICS.q>0?HARMONICS.fund.toFixed(1)+'Hz Q='+HARMONICS.q.toFixed(1):'—';
},80);

/* ══════════════════════════════════════════════════════════════
 AI EXEC — Self-Building Programmatic Engine
 No messaging. No chat. Pure code execution.

 The AI reads complete engine state, selects and runs programs
 that directly modify: NN weights, SF gains, Kalman, Wiener,
 FreqDB thresholds, Bayesian weights, Inverse strategy.

 Every N cycles → program selected → executed → changes logged.
 User can also run programs manually via command line.

 DSL Commands (exec-inp):
 ANALYZE — full state report
 STATE — dump all variables
 LIST — list available programs
 SELF_OPTIMIZE — adaptive meta-optimizer (runs top programs)
 OPTIMIZE_SF — tune silent freq gains
 TUNE_NN — adapt learning rate / momentum
 ADAPT_THRESH — adapt FREQ_THRESH dynamically
 INVERSE_STRAT — tune inverse generator
 BOOST_SIL — emergency silence boost
 RESET_KF — reset Kalman filter
 RESET_BAYES — reset Bayesian mixer
 FREQ_PREDICT — predict next dominant frequencies
 PATTERN_LEARN — cluster freqDB → noise signature → Bayes
 META_ADAPT — UCB1 rank programs → reshape schedule
 PREDICT — alias for FREQ_PREDICT
 RANK — show UCB1 program efficiency ranking
 SET SF.INF 0.7 — set INF gain directly
 SET NN.LR 0.015 — set NN learning rate
 SET THRESH 4 — set confirm threshold
 SET WIENER.A 2.0— set Wiener alpha
══════════════════════════════════════════════════════════════ */

/* ══ ENGINE STATE READER ══ */
function getState(){
 return{
 silSc,bestSil,aiCyc,loopN,loopE,aiCon,
 fanFreq,fanE,noiseE,sharpE,evpE,evpHz,emfE,
 freqDB,freqFile,FC:{...FC},
 INV,KF:{...KF},DRV:{...DRV},P:{...P},
 iLv,uLv,pLv,bLv,eLv,
 NN:{trainN:NN.trainN,loss:NN.loss,lr:NN.lr,mom:NN.mom,lastOut:NN.lastOut?[...NN.lastOut]:null},
 actxSR:actx?actx.sampleRate:0
 // AI_CTX accessed directly as global — no need to duplicate in state
 };
}

/* ════════════════════════════════════════════════
 AI CONTEXT (AI_CTX) — Shared Memory Layer
 Updated every 5s from UDS.
 AI programs READ this synchronously.
 Terminal writes TO it via tLog hooks.

 Flow:
 Engine events → tLog → UDS → AI_CTX → AI programs
 AI programs → logExec → UDS → Terminal display
════════════════════════════════════════════════ */
const AI_CTX = {
 // From terminal_events DB
 topFreqs:[], // [{hz,count,classId}] dominant patterns
 recentFreqs:[], // last 30 FREQ events
 cohTrend:0, // avg γ² over last 20 COH events (0→1)
 cohDelta:0, // γ² change (positive=improving)
 // From exec_history DB
 execStats:{}, // {PROG_NAME: {runs, avgMs, avgSilChange}}
 bestProg:null, // program that yielded highest silence gain
 // From nn_history DB
 nnLossTrend:0, // slope of loss over last 20 snapshots
 nnBestLoss:1, // lowest loss achieved
 // From freq_patterns DB
 confirmedPatterns:[],// [{hz, count, classId}]
 // Meta
 lastUpdated:0,
 updateCount:0,
 ready:false,
 // Extended — filled by new programs
 noiseSignature:'unknown', // 'tonal/hum' | 'narrowband' | 'wideband'
 predictedHz:null, // next predicted dominant frequency
 rankedProgs:[], // programs ranked by silence efficiency (META_ADAPT)
 lowEffProgs:new Set(), // programs flagged as low-efficiency (META_ADAPT)
 priorityProg:null, // program to prioritize this epoch (META_ADAPT)
 crestFactor:0, // ⑧ live crest factor from CREST (CREST×AI_CTX)
};

async function updateAICtx(){
 if(!zeroDB)return;
 AI_CTX.updateCount++;
 // 1. Dominant frequency patterns from terminal_events
 const freqEvts = await udsQueryEvents('FREQ', 200);
 const hzMap={};
 freqEvts.forEach(e=>{
 const m=e.code.match(/hz = ([\d.]+)/);
 if(m){const hz=parseFloat(m[1]);if(!hzMap[hz])hzMap[hz]={hz,count:0,ts:e.ts};hzMap[hz].count++;}
 });
 AI_CTX.topFreqs=Object.values(hzMap).sort((a,b)=>b.count-a.count).slice(0,10);
 AI_CTX.recentFreqs=freqEvts.slice(0,30);
 // Write new patterns to freq_patterns store
 AI_CTX.topFreqs.forEach(p=>{if(p.count>=3)udsWritePattern(p.hz,p.count,0);});
 // 2. Coherence trend from COH events
 const cohEvts=await udsQueryEvents('COH',20);
 if(cohEvts.length>1){
 const vals=cohEvts.map(e=>{const m=e.code.match(/γ²_avg = ([\d.]+)/);return m?parseFloat(m[1]):0;});
 AI_CTX.cohTrend=vals.reduce((a,b)=>a+b,0)/vals.length;
 AI_CTX.cohDelta=vals.length>1?vals[0]-vals[vals.length-1]:0;
 }
 // 3. Exec program statistics
 const execEvts=await udsQueryExec(null,200);
 const stats={};
 execEvts.forEach(e=>{
 if(!stats[e.prog])stats[e.prog]={runs:0,totalMs:0,silSum:0};
 stats[e.prog].runs++;
 stats[e.prog].totalMs+=e.ms||0;
 stats[e.prog].silSum+=e.silSc||0;
 });
 Object.keys(stats).forEach(p=>{
 const s=stats[p];
 AI_CTX.execStats[p]={runs:s.runs,avgMs:(s.totalMs/s.runs).toFixed(1),avgSil:(s.silSum/s.runs).toFixed(1)};
 });
 // Best program by average silence
 const progs=Object.entries(AI_CTX.execStats);
 if(progs.length)AI_CTX.bestProg=progs.sort((a,b)=>parseFloat(b[1].avgSil)-parseFloat(a[1].avgSil))[0][0];
 // 4. NN loss trend
 const nnHist=await udsQueryNNHistory(20);
 if(nnHist.length>1){
 const losses=nnHist.map(e=>e.loss);
 AI_CTX.nnBestLoss=Math.min(...losses);
 AI_CTX.nnLossTrend=losses.length>1?(losses[0]-losses[losses.length-1])/losses.length:0;
 }
 // 5. Confirmed patterns
 AI_CTX.confirmedPatterns=await udsQueryPatterns();
 // ⑧ CREST×AI_CTX — Live crest factor in shared context
 AI_CTX.crestFactor=typeof CREST!=='undefined'?CREST.val:0;
 AI_CTX.lastUpdated=Date.now();
 AI_CTX.ready=true;
 // Log to terminal every 10 updates
 if(AI_CTX.updateCount%10===0&&AI_CTX.topFreqs.length){
 tLog('SYS',
 `# AI_CTX updated: topFreq=${AI_CTX.topFreqs[0]?.hz}Hz(×${AI_CTX.topFreqs[0]?.count}) cohTrend=${AI_CTX.cohTrend.toFixed(3)} bestProg=${AI_CTX.bestProg||'—'}`,
 `# nnLossTrend=${AI_CTX.nnLossTrend.toFixed(5)} patterns=${AI_CTX.confirmedPatterns.length} execStats=${Object.keys(AI_CTX.execStats).length}`);
 }
}

// Update AI context every 5 seconds
setInterval(()=>{if(isRun)updateAICtx();},2000);

/* ══ PROGRAM LIBRARY ══ */
