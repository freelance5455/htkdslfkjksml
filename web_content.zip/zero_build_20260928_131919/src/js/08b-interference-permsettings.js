/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 08b-interference-permsettings.js
 كشف التداخل بين الترددات المحظورة + تصعيد مناطق التداخل + واجهة إعدادات الأذونات + الحظر المخصص
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): تقسيم إضافي لملف كان
 أضخم من بقية الملفات — نفس المنهج: قصّ آلي عند حدود تصريحات علوية
 آمنة، بلا أي تغيير منطقي أو إعادة ترتيب.
 ══════════════════════════════════════════════════════════════════ */
const INTERFERENCE_BAN={
 enabled:true,
 tolHz:3, // نافذة اعتبار ترددين "متداخلين" بالهرتز
 escalateAt:3, // عدد مرات التداخل المتكرر في نفس المنطقة قبل التصعيد
 widenStep:4, // Hz تُضاف لنطاق الحظر عند كل تصعيد
 maxWiden:32, // أقصى توسّع حول المركز
 zones:new Map() // centerBin → {count, widen, lastT}
};
function checkInterference(newHz){
 if(!INTERFERENCE_BAN.enabled||!newHz||newHz<=0)return;
 const newBin=fBin(newHz);
 let nearest=null,nearestDist=Infinity;
 AI_BAN.forEach((d,bin)=>{
 if(bin===newBin)return;
 const dist=Math.abs(bin-newBin);
 if(dist<=INTERFERENCE_BAN.tolHz&&dist<nearestDist){nearest=bin;nearestDist=dist;}
 });
 if(nearest===null)return; // لا تداخل مع أي تردد محظور آخر
 const center=fBin((nearest+newBin)/2);
 let z=INTERFERENCE_BAN.zones.get(center);
 if(!z){z={count:0,widen:0,lastT:0};INTERFERENCE_BAN.zones.set(center,z);}
 z.count++;z.lastT=Date.now();
 if(z.count>=INTERFERENCE_BAN.escalateAt&&z.widen<INTERFERENCE_BAN.maxWiden){
 z.widen=Math.min(INTERFERENCE_BAN.maxWiden,z.widen+INTERFERENCE_BAN.widenStep);
 escalateInterferenceZone(center,z.widen);
 z.count=0; // إعادة العدّاد بعد كل تصعيد
 }
 PERSIST.scheduleSaveZones(); // تشديد: حفظ تقدّم منطقة التداخل فوراً — كان مفقوداً كلياً سابقاً
 renderPermSettings(); // القائمة مدمجة الآن (حضر + تداخل) — تحديث واحد يكفي كليهما
}
function escalateInterferenceZone(center,widenHz){
 const step=0.5;let added=0;
 for(let off=-widenHz;off<=widenHz;off+=step){
 const hz=center+off;
 // تشديد أكثر: hz<=0 وحدها لا ترفض NaN (أي مقارنة بـNaN تُقيَّم false دائماً) — التحقّق
 // الكامل isFinite يضمن رفض NaN أيضاً، دفاعاً إضافياً حتى لو وصل center نفسه فاسداً
 if(!isFinite(hz)||hz<=0)continue;
 const bin=fBin(hz);
 if(AI_BAN.has(bin))continue;
 if(newBanCount()>=AI_GATE.maxBan)break;
 AI_BAN.set(bin,{reason:'حظر تداخل ±'+widenHz.toFixed(0)+'Hz حول '+center.toFixed(1)+'Hz',
 bannedAt:execCyc,cycles:0,bannedAtTime:Date.now(),autoUnbanAt:Infinity,hz:bin,permanent:true,category:'interference'});
 if(freqDB.has(bin)){freqDB.delete(bin);writeFreqFile();} // تشديد: تنظيف FreqDB عند حظر تصعيد التداخل
 stopActiveInverse(hz); // تشديد: إيقاف أي إبطال نشط على تردد التصعيد المحضور حديثاً (كان مفقوداً)
 deactivateNotch(hz); // تشديد: إزالة أي notch نشط على تردد التصعيد المحضور حديثاً
 added++;
 }
 if(added){
 stLog(' تصعيد حظر التداخل: ±'+widenHz.toFixed(0)+'Hz حول '+center.toFixed(2)+'Hz ('+added+' تردد)');
 PERSIST.scheduleSaveBans();
 renderBanList();
 }
}
/* ── القائمة المدمجة: الترددات المحظورة + مناطق التداخل معاً ──
 تغيير كامل: حُذف زر تفعيل/إيقاف الحظر الدائم نهائياً من الواجهة — الحظر الدائم نشِط
 دائماً وغير مشروط بأي زر بعد الآن. العدّاد والقائمة هنا يعرضان "الجديد فقط" (غير
 الأساسي/baseline) — الأساسي (الحضر الافتراضي DEFAULT_BANNED_FREQS + المؤكَّد من
 zero-core.js) يعمل بصمت تام في الخلفية ولا يظهر هنا إطلاقاً، لا بعدّاد ولا بعلامة
 "· أساسي" في القائمة (حُذفت العلامة كلياً). حين لا يوجد أي جديد بعد، العدّاد يبدأ
 من 0 والقائمة تعرض رسالة "لا يوجد ترددات جديدة". */
function renderPermSettings(){
 const zonesArr=[...INTERFERENCE_BAN.zones.entries()].sort((a,b)=>a[0]-b[0]);
 // استُعيد 28 سبتمبر 2026: عدّاد لكل فئة على حدة + مفتاح تفعيل/إيقاف — بدل العدّاد الموحّد
 // الوحيد. يحسب الجديد فقط (غير baseline) اتساقاً مع نفس مبدأ العدّاد الموحّد السابق —
 // الأساسي (683 تردد مؤكَّد) يعمل بصمت في الخلفية بصرف النظر عن حالة المفتاح هنا.
 Object.keys(PERM_BAN_CATS).forEach(cat=>{
 const el=E('pban-cnt-'+cat);if(!el)return;
 const sw=E('sw-pban-'+cat);
 const enabled=PERM_BAN_CATS[cat].enabled;
 if(sw)sw.checked=enabled;
 if(enabled){
 const n=[...AI_BAN.values()].filter(d=>d.permanent&&!d.baseline&&d.category===cat).length;
 el.textContent=n+' تردد';
 el.style.color='';el.style.background='';el.style.borderColor='';
 }else{
 const n=PERSIST.countCategory(cat);
 el.textContent=n+' موقوف';
 el.style.color='rgba(176,176,176,.85)';
 el.style.background='rgba(176,176,176,.08)';
 el.style.borderColor='rgba(176,176,176,.22)';
 }
 });
 // تشديد: نسخة القائمة الأساسية المحمَّلة فعلياً — تُحسَب حيّاً، بلا حاجة لتحديث يدوي هنا
 const verEl=E('pban-baseline-ver');
 if(verEl){
 const cb=typeof CONFIRMED_BANS!=='undefined'?CONFIRMED_BANS.length:0;
 const ci=typeof CONFIRMED_INTERFERENCE!=='undefined'?CONFIRMED_INTERFERENCE.length:0;
 verEl.textContent=cb?(' نسخة القائمة الأساسية: '+cb+' تردد مؤكَّد + '+ci+' منطقة تداخل (zero-core.js) — تحقّق أنها أحدث نسخة قبل جلسة استماع جديدة'):' zero-core.js غير محمَّل — القائمة المؤكَّدة غير متاحة';
 }
 // القائمة الموحّدة: الترددات الجديدة () + مناطق التداخل الجديدة () معاً، مرتّبة بالتردد تصاعدياً
 const listEl=E('pban-settings-list');if(!listEl)return;
 // نأخذ الترددات من مفتاح الـMap دائماً (لا نعتمد على d.hz المُخزّن — قد يكون غائباً)
 // — ونستبعد أي إدخال baseline كلياً: هذه القائمة للجديد فقط
 // خط دفاع أخير (انظر renderBanList): استبعاد أي مفتاح NaN/غير موجب حتى لو تسرَّب استثناءً
 const validHzKey=hz=>typeof hz==='number'&&isFinite(hz)&&hz>=1;
 const perms=[...AI_BAN.entries()].filter(([hz,d])=>d.permanent&&!d.baseline&&validHzKey(hz)).map(([hz,d])=>({...d,hz,_t:'ban'}));
 const zones=zonesArr.filter(([hz,z])=>!z.baseline&&validHzKey(hz)).map(([hz,z])=>({hz,_t:'zone',count:z.count,widen:z.widen||0,crossConfirms:z.crossConfirms||0}));
 const merged=[...perms,...zones].sort((a,b)=>a.hz-b.hz);
 if(!merged.length){listEl.innerHTML='<div class="ban-empty">لا يوجد ترددات جديدة</div>';return;}
 listEl.innerHTML=merged.map(d=>{
 if(d._t==='zone'){
 // تأكيد متقاطع: نفس شارة N المستخدَمة في قائمة الحظر — منطقة تداخل رُصدت أيضاً من
 // جهاز/جلسة أخرى مستقلة عبر الاستيراد، دليل إضافي أنها تداخل بيئي حقيقي لا ضجيج عابر
 const cross=d.crossConfirms>0?`<span class="ban-cross" title="تأكَّدت من ${d.crossConfirms} مصدر مستقل">${d.crossConfirms}</span>`:'';
 return `<div class="ban-row zone"><span class="ban-hz">${d.hz.toFixed(2)}Hz</span><span class="ban-why" style="flex:2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">تداخل ×${d.count}${d.widen?' · موسّع ±'+d.widen.toFixed(0)+'Hz':''}</span>${cross}</div>`;
 }
 return `<div class="ban-row perm"><span class="ban-hz">${d.hz.toFixed(2)}Hz</span><span class="ban-why" style="flex:2;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"> ${escH(d.reason||'')}</span><span class="ban-rmv" onclick="unbanFreq(${d.hz})">✕</span></div>`;
 }).join('');
}

// استُعيدت 28 سبتمبر 2026 ("تجميع كل الأفكار") — تفعيل/إيقاف فئة حظر كاملة. كانت قد أُزيلت
// نهائياً سابقاً بحجة أن الحظر الدائم يجب أن يبقى نشِطاً دوماً؛ استُعيدت بلا تعديل منطقي عن
// نسختها الأخيرة العاملة — لا تمسّ الحظر الأساسي (baseline) إطلاقاً، فقط ترددات هذه الفئة.
function togglePermCat(cat){
 if(!PERM_BAN_CATS[cat])return;
 PERM_BAN_CATS[cat].enabled=!PERM_BAN_CATS[cat].enabled;
 const sw=E('sw-pban-'+cat);if(sw)sw.checked=PERM_BAN_CATS[cat].enabled;
 if(PERM_BAN_CATS[cat].enabled){
 const restoredPersist=PERSIST.restoreCategory(cat);
 DEFAULT_BANNED_FREQS.forEach(([hz,c,reason])=>{
 if(c!==cat)return;
 const bin=fBin(hz);
 if(!AI_BAN.has(bin))AI_BAN.set(bin,{reason,bannedAt:execCyc,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:cat,
 preBanEnergy:0,postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null});
 });
 PERSIST.saveCats();
 PERSIST.scheduleSaveBans();
 stLog(' تفعيل حضر: '+PERM_BAN_CATS[cat].label+(restoredPersist?' ('+restoredPersist+' محفوظ استُعيد)':''));
 }else{
 PERSIST.saveBans();
 AI_BAN.forEach((d,bin)=>{if(d.permanent&&d.category===cat)AI_BAN.delete(bin);});
 PERSIST.saveCats();
 stLog(' إيقاف حضر: '+PERM_BAN_CATS[cat].label+' (البيانات محفوظة في PERSIST)');
 }
 renderBanList();
 renderPermSettings();
}

// استُعيدت 28 سبتمبر 2026 — إضافة تردد مخصَّص للحظر الدائم يدوياً من حقل نصي مباشر
// (البديل الموازي: أمر EXEC الموجود أصلاً `BAN <hz>` — كلاهما يعمل الآن جنباً إلى جنب).
function addCustomPermBan(){
 const inp=E('pban-custom-inp');if(!inp)return;
 const hz=parseFloat(inp.value);
 if(isNaN(hz)||hz<=0){inp.style.borderColor='rgba(104,104,104,.5)';setTimeout(()=>inp.style.borderColor='',1200);return;}
 const bin=fBin(hz);
 if(AI_BAN.has(bin)){stLog(' '+bin.toFixed(2)+'Hz محضور مسبقاً');inp.value='';return;}
 AI_BAN.set(bin,{reason:'حضر مخصص',bannedAt:execCyc,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:'custom',
 preBanEnergy:0,postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null});
 stLog(' حضر مخصص: '+bin.toFixed(2)+'Hz');
 inp.value='';renderBanList();
}

/* ══ POST-BAN PROBABILISTIC ANALYSIS ══
 When mic detects a banned freq:
 - First detection: sets energy baseline (preBanEnergy)
 - Subsequent: probEnvironmental = postEnergy / preBanEnergy
 ≥0.65 → 'env' (environmental source, ban correct)
 0.25–0.64 → 'mixed'
 <0.25 → 'spk' (speaker was re-emitting, ban worked)
═══════════════════════════════════════ */
function trackPostBanDetection(hz,energy){
 const bin=fBin(hz);
 const e=AI_BAN.get(bin);
 if(!e)return;
 // First mic detection after ban → establish baseline
 if(!e.preBanEnergy||e.preBanEnergy===0){
 e.preBanEnergy=energy;
 e.postBanDetections=1;
 e.lastPostBanEnergy=energy;
 e.probEnvironmental=1.0;
 e.verdict='env'; // first hit = baseline, assume environmental
 return;
 }
 e.postBanDetections=(e.postBanDetections||0)+1;
 // Exponential moving average — slow decay to track steady-state
 e.lastPostBanEnergy=(e.lastPostBanEnergy||energy)*.75+energy*.25;
 // Probability: how much energy remains vs baseline?
 e.probEnvironmental=Math.min(1,e.lastPostBanEnergy/e.preBanEnergy);
 if(e.probEnvironmental>=0.65)e.verdict='env';
 else if(e.probEnvironmental>=0.25)e.verdict='mixed';
 else e.verdict='spk';
 // If verdict is 'spk' for ≥3 detections, ban was effective → log once
 if(e.verdict==='spk'&&e.postBanDetections===3)
 addToStLog('✓ Ban confirmed effective: '+bin.toFixed(2)+'Hz — speaker was source (energy ↓'+(e.probEnvironmental*100).toFixed(0)+'%)');
}

/* Auto-detect and immediately ban a newly observed harmful/noisy freq.
 Called before fRecord() so the ban is in place before DB write. */
function autoDetectAndBan(hz,energy){
 if(!hz||hz<=0||!AI_GATE.enabled)return;
 const bin=fBin(hz);
 if(AI_BAN.has(bin))return; // already handled
 // Match against DEFAULT_BANNED_FREQS lookup table
 for(let i=0;i<DEFAULT_BANNED_FREQS.length;i++){
 const [defHz,cat,reason]=DEFAULT_BANNED_FREQS[i];
 if(fBin(defHz)===bin){
 if(!PERM_BAN_CATS[cat]||!PERM_BAN_CATS[cat].enabled)return;
 AI_BAN.set(bin,{
 reason:reason||cat,bannedAt:execCyc,cycles:0,
 autoUnbanAt:Infinity,hz:bin,permanent:true,category:cat,
 preBanEnergy:energy, // capture energy right before ban
 postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null
 });
 if(freqDB.has(bin)){freqDB.delete(bin);writeFreqFile();} // تشديد: تنظيف FreqDB عند الحظر
 deactivateNotch(hz); // تشديد: إزالة أي notch نشط — محضور لا يحتاج كبت إضافي ولا يظهر في NOTCH LIST
 checkInterference(bin);
 stopActiveInverse(hz);
 addToStLog(' Auto-ban: '+bin.toFixed(2)+'Hz ('+cat+') — mic تحسّس');
 renderBanList();
 return;
 }
 }
 // Also auto-ban unregistered EMF harmonics detected live with sufficient energy
 if(energy>0.08){
 const isEMFHarm=[50,60].some(base=>{
 for(let h=1;base*h<20000;h++){if(Math.abs(hz-base*h)<1.5)return true;}
 return false;
 });
 if(isEMFHarm&&PERM_BAN_CATS.harmful.enabled){
 AI_BAN.set(bin,{
 reason:'EMF harmonic (auto)',bannedAt:execCyc,cycles:0,
 autoUnbanAt:Infinity,hz:bin,permanent:true,category:'harmful',
 preBanEnergy:energy,
 postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null
 });
 if(freqDB.has(bin)){freqDB.delete(bin);writeFreqFile();} // تشديد: تنظيف FreqDB عند الحظر
 deactivateNotch(hz); // تشديد: إزالة أي notch نشط — محضور لا يحتاج كبت إضافي ولا يظهر في NOTCH LIST
 checkInterference(bin);
 stopActiveInverse(hz);
 addToStLog(' Auto-ban EMF: '+bin.toFixed(2)+'Hz');
 renderBanList();
 }
 }
}

