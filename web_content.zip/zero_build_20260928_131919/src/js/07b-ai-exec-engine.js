/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 07b-ai-exec-engine.js
 محرك التنفيذ الذاتي: دورة تنفيذ الأوامر (aiExecCycle/runExecCmd) + اختيار UCB1 bandit + سجلّ التنفيذ + واجهة الأذونات
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): تقسيم إضافي لملف كان
 أضخم من بقية الملفات — نفس المنهج: قصّ آلي عند حدود تصريحات علوية
 آمنة، بلا أي تغيير منطقي أو إعادة ترتيب.
 ══════════════════════════════════════════════════════════════════ */
let execTotal=0;const EXEC_LOG=[];

function getExecType(prog){
 if(['BOOST_SIL','WARN'].includes(prog))return'warn';
 if(['ERROR','ERR'].includes(prog))return'err';
 if(['SYS','INIT','STATE','LIST','RANK'].includes(prog))return'sys';
 if(['SELF_OPTIMIZE','ANALYZE','META_ADAPT','PATTERN_LEARN','FREQ_PREDICT','FREQ_GATE'].includes(prog))return'opt';
 return'';
}

function logExec({prog,lines,ms,cycle,auto}){
 const ts=new Date();const t=String(ts.getMinutes()).padStart(2,'0')+':'+String(ts.getSeconds()).padStart(2,'0')+'.'+String(ts.getMilliseconds()).slice(0,2);
 execTotal++;
 const entry={prog,lines,ms:ms||0,t,cycle:cycle||aiCyc,auto:!!auto};
 EXEC_LOG.unshift(entry);if(EXEC_LOG.length>80)EXEC_LOG.pop();
 // ── Write to UDS exec_history (AI's action log) ─
 udsWriteExec({prog,lines,ms:ms||0,cycle:cycle||aiCyc,auto:!!auto});
 // Update exec stat bar
 const ep=E('ex-prog');if(ep)ep.textContent=execTotal;
 const ec=E('execCurr');if(ec)ec.textContent=prog;
 const el=E('execDot');if(el)el.className='exec-run-dot run';
 setTimeout(()=>{const el2=E('execDot');if(el2&&!isRun)el2.className='exec-run-dot';},600);
 // logNN removed — avoid tLog→logExec→logNN→tLog cycle
 if(curTab===5)renderExecLog();
}

function renderExecLog(){
 const el=E('execLog');if(!el)return;
 el.innerHTML=EXEC_LOG.slice(0,18).map(e=>{
 const type=getExecType(e.prog);
 const arrow=type==='warn'?'warn':type==='err'?'err':'mod';
 const linesHtml=(e.lines||[]).map(l=>`<div class="exec-line"><span class="exec-arrow ${arrow}">→</span><span>${escH(l)}</span></div>`).join('');
 return`<div class="exec-entry ${type}">
 <div class="exec-eh">
 <span class="exec-prog ${type}">${e.auto?'':'▶'} ${e.prog}</span>
 <span class="exec-meta">${e.t}${e.ms?' · '+e.ms+'ms':''}</span>
 </div>
 <div class="exec-lines">${linesHtml}</div>
 </div>`;
 }).join('');
 el.scrollTop=0;
}

/* أُضيف escH(&quot;) لاحقاً (تشديد اكثر — ثغرة حقن HTML عبر أسماء ملفات المجلد الثابت، انظر
 renderFixedFolderBrowser): لا يغيّر سلوك أي من نداءات escH() الحالية (كلها داخل عقدة نص لا
 سمة HTML، حيث لا فرق مرئي بين " الحرفي وHTML&quot; بعد تحليل المتصفح لهما). */
function escH(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

/* ══ AUTONOMOUS EXEC CYCLE ══ */
let execCyc=0,lastSilForBoost=0,boostCooldown=0;

/* UCB1 bandit selector — picks program with highest exploration-exploitation score */
function ucb1Select(){
 const CANDIDATES=['OPTIMIZE_SF','TUNE_NN','ADAPT_THRESH','INVERSE_STRAT','FREQ_PREDICT','PATTERN_LEARN'];
 // Remove low-efficiency programs tagged by META_ADAPT
 const active=CANDIDATES.filter(n=>AI_LIB[n]&&!AI_CTX.lowEffProgs.has(n));
 if(!active.length)return{ucbProg:AI_LIB.OPTIMIZE_SF,ucbName:'OPTIMIZE_SF'};
 const stats=AI_CTX.execStats||{};
 const totalRuns=Object.values(stats).reduce((a,s)=>a+s.runs,0)||1;
 const scores=active.map(n=>{
 const s=stats[n];
 if(!s||!s.runs)return{name:n,score:9999}; // unexplored → top priority
 const exploit=parseFloat(s.avgSil)||0;
 const lossFact=NN&&NN.loss>0.4?Math.min(2.5,1.5+NN.loss*1.5):1.5;// ⑨ Loss-Gated UCB1
 const fluxFact=typeof SPEC_FLUX!=='undefined'&&SPEC_FLUX.val>0.4?Math.min(1.8,1+SPEC_FLUX.val):1;// ⑥ Flux-Volatility
 const explore=lossFact*fluxFact*Math.sqrt(Math.log(totalRuns)/s.runs);
 return{name:n,score:exploit+explore};
 });
 scores.sort((a,b)=>b.score-a.score);
 const best=scores[0].name;
 return{ucbProg:AI_LIB[best],ucbName:best};
}

function aiExecCycle(){
 if(!isRun||!NN.w1)return;
 execCyc++;
 const st=getState();
 let prog,progName;
 // ── Priority ladder ──────────────────────────────
 // P1: Emergency silence boost
 if(st.silSc<15&&execCyc-boostCooldown>30){
 prog=AI_LIB.BOOST_SIL;progName='BOOST_SIL';boostCooldown=execCyc;
 }
 // P2: META_ADAPT — reshapes scheduler every 80 cycles
 else if(execCyc%80===0){
 prog=AI_LIB.META_ADAPT;progName='META_ADAPT';
 }
 // P3: Full self-optimize every 50 cycles
 else if(execCyc%50===0){
 prog=AI_LIB.SELF_OPTIMIZE;progName='SELF_OPTIMIZE';
 }
 // P4: PATTERN_LEARN every 40 cycles when DB has data
 else if(execCyc%40===0&&st.freqDB.size>=5){
 prog=AI_LIB.PATTERN_LEARN;progName='PATTERN_LEARN';
 }
 // P5: FREQ_PREDICT every 30 cycles when patterns exist
 else if(execCyc%30===0&&(AI_CTX.confirmedPatterns.length>0||st.freqDB.size>3)){
 prog=AI_LIB.FREQ_PREDICT;progName='FREQ_PREDICT';
 }
 // P5b: FREQ_GATE every 35 cycles (ban chronic failures)
 else if(execCyc%35===0&&AI_GATE.enabled){
 prog=AI_LIB.FREQ_GATE;progName='FREQ_GATE';
 }
 // P6: Priority program from META_ADAPT every 8 cycles
 else if(AI_CTX.priorityProg&&AI_LIB[AI_CTX.priorityProg]&&execCyc%8===0){
 progName=AI_CTX.priorityProg;prog=AI_LIB[progName];
 }
 // P7: High NN loss → tune every 15 cycles
 else if(st.NN.loss>0.4&&execCyc%15===0){
 prog=AI_LIB.TUNE_NN;progName='TUNE_NN';
 }
 // P8: UCB1 bandit selection every 5 cycles
 else if(execCyc%5===0){
 const sel=ucb1Select();prog=sel.ucbProg;progName=sel.ucbName;
 }
 else return; // idle cycle
 // ── Execute ──────────────────────────────────────
 const t0=performance.now();
 const lines=prog.run(st);
 const ms=Math.round(performance.now()-t0);
 logExec({prog:progName,lines,ms,cycle:aiCyc,auto:true});
 // Auto-ban check every 25 cycles
 if(execCyc%25===0)autoBanCheck();
 // Update exec stat bar
 const es=E('ex-sil');if(es)es.textContent=st.silSc+'%';
 const en=E('ex-nn');if(en)en.textContent=NN.loss.toFixed(3);
 const ed=E('ex-db');if(ed)ed.textContent=freqDB.size;
}

/* ══ MANUAL COMMAND EXECUTOR ══ */
function runExecCmd(){
 const inp=E('execInp');if(!inp)return;
 const raw=inp.value.trim();inp.value='';
 if(!raw)return;
 const parts=raw.toUpperCase().split(/\s+/);
 const cmd=parts[0];const st=getState();
 // Direct program names
 if(AI_LIB[cmd]){
 const t0=performance.now();
 const lines=AI_LIB[cmd].run(st);
 logExec({prog:cmd,lines,ms:Math.round(performance.now()-t0),auto:false});
 return;
 }
 // SET path value
 if(cmd==='SET'){
 const path=parts[1]||'';const val=parseFloat(parts[2]);
 if(isNaN(val)){logExec({prog:'SET',lines:['Error: SET <path> <value> e.g. SET SF.INF 0.8'],auto:false});return;}
 const setMap={
 'SF.INF':()=>{const p=iLv;iLv=Math.max(0,Math.min(1,val));updSFGains();return`SF.INF ${p.toFixed(3)}→${iLv.toFixed(3)}`;},
 'SF.ULT':()=>{const p=uLv;uLv=Math.max(0,Math.min(1,val));updSFGains();return`SF.ULT ${p.toFixed(3)}→${uLv.toFixed(3)}`;},
 'SF.PHF':()=>{const p=pLv;pLv=Math.max(0,Math.min(1,val));updSFGains();return`SF.PHF ${p.toFixed(3)}→${pLv.toFixed(3)}`;},
 'SF.SUB':()=>{const p=bLv;bLv=Math.max(0,Math.min(1,val));updSFGains();return`SF.SUB ${p.toFixed(3)}→${bLv.toFixed(3)}`;},
 'SF.PIE':()=>{const p=eLv;eLv=Math.max(0,Math.min(1,val));updSFGains();return`SF.PIE ${p.toFixed(3)}→${eLv.toFixed(3)}`;},
 'NN.LR':()=>{const p=NN.lr;NN.lr=Math.max(0.0001,Math.min(0.1,val));return`NN.LR ${p.toFixed(4)}→${NN.lr.toFixed(4)}`;},
 'NN.MOM':()=>{const p=NN.mom;NN.mom=Math.max(0.1,Math.min(0.999,val));return`NN.MOM ${p.toFixed(4)}→${NN.mom.toFixed(4)}`;},
 'THRESH':()=>{const p=FREQ_THRESH;FREQ_THRESH=Math.max(2,Math.min(10,Math.round(val)));return`FREQ_THRESH ${p}→${FREQ_THRESH}`;},
 'WIENER.A':()=>{const p=P.alpha;P.alpha=Math.max(0.1,Math.min(5,val));return`Wiener.α ${p.toFixed(3)}→${P.alpha.toFixed(3)}`;},
 'KF.R':()=>{const p=KF.R;KF.R=Math.max(0.01,Math.min(200,val));return`KF.R ${p}→${KF.R}`;},
 'MU':()=>{const p=P.mu;P.mu=Math.max(0.001,Math.min(0.5,val));return`FxLMS.μ ${p.toFixed(4)}→${P.mu.toFixed(4)}`;},
 };
 const fn=setMap[path];
 if(fn)logExec({prog:'SET',lines:[fn()],auto:false});
 else logExec({prog:'SET',lines:['Unknown: '+path,'Valid: SF.INF SF.ULT SF.PHF SF.SUB SF.PIE NN.LR NN.MOM THRESH WIENER.A KF.R MU'],auto:false});
 return;
 }
 // STATE dump
 if(cmd==='STATE'){
 logExec({prog:'STATE',lines:[
 `sil=${st.silSc}% best=${st.bestSil}% cyc=${st.aiCyc} loop=${st.loopN}`,
 `src=${st.fanFreq.toFixed(2)}Hz E=${(st.fanE*100).toFixed(0)}% noise=${(st.noiseE*100).toFixed(0)}%`,
 `NN: trained=${st.NN.trainN} loss=${st.NN.loss.toFixed(4)} lr=${st.NN.lr.toFixed(4)} mom=${st.NN.mom}`,
 `SF: INF=${iLv.toFixed(3)} ULT=${uLv.toFixed(3)} PHF=${pLv.toFixed(3)} SUB=${bLv.toFixed(3)} PIE=${eLv.toFixed(3)}`,
 `C1=${st.FC.c1} C2=${st.FC.c2} C3=${st.FC.c3} C4=${st.FC.c4} C5=${st.FC.c5} C6=${st.FC.c6} C7=${st.FC.c7} C8=${st.FC.c8}`,
 `THRESH=${FREQ_THRESH} · Wiener.α=${P.alpha.toFixed(2)} · KF.R=${KF.R} · μ=${P.mu}`,
 `DB:${st.freqDB.size} conf:${st.freqFile.totalConf} canc:${st.freqFile.totalCanc} inv:${st.INV.active.size}`,
 `Bayes: w1=${(st.DRV.wS*100).toFixed(0)}% w2=${(st.DRV.wE*100).toFixed(0)}% w3=${(st.DRV.wM*100).toFixed(0)}%`,
 ],auto:false});
 return;
 }
 // LIST programs
 if(cmd==='LIST'){
 logExec({prog:'LIST',lines:Object.entries(AI_LIB).map(([k,v])=>`${k}: ${v.desc}`),auto:false});
 return;
 }
 // DB QUERY commands
 if(cmd==='QUERY'){
 const qType=(parts[1]||'FREQ').toUpperCase();
 const qLimit=parseInt(parts[2])||30;
 udsQueryEvents(qType,qLimit).then(events=>{
 const lines=[`query: terminal_events WHERE type='${qType}' LIMIT ${qLimit}`,`found: ${events.length} events`];
 events.slice(0,10).forEach(e=>lines.push(` [${e.t}] ${e.code.slice(0,60)}`));
 if(events.length>10)lines.push(` ... +${events.length-10} more`);
 tLog('SYS',`>>> QUERY ${qType} ${qLimit}`,lines.join('\n'));
 });
 return;
 }
 if(cmd==='PATTERN'){
 udsQueryPatterns().then(patterns=>{
 const lines=[`query: freq_patterns ORDER BY count DESC`,`found: ${patterns.length} patterns`];
 patterns.slice(0,12).forEach(p=>{
 const cn=['','C1⊕','C2⊖','C3∓','C4±','C5','C6','C7','C8'][p.classId||0]||'';
 lines.push(` hz=${p.hz.toFixed(2)} count=${p.count} class=${cn} @sil=${p.silSc}%`);
 });
 tLog('SYS',`>>> PATTERN`,lines.join('\n'));
 });
 return;
 }
 if(cmd==='CONTEXT'){
 const lines=[
 `AI_CTX.ready=${AI_CTX.ready} updated=${AI_CTX.updateCount}×`,
 `topFreqs: ${AI_CTX.topFreqs.slice(0,5).map(f=>f.hz+'(×'+f.count+')').join(' ')||'none'}`,
 `cohTrend=${AI_CTX.cohTrend.toFixed(4)} Δ=${AI_CTX.cohDelta.toFixed(4)}`,
 `nnLossTrend=${AI_CTX.nnLossTrend.toFixed(6)} bestLoss=${AI_CTX.nnBestLoss.toFixed(4)}`,
 `bestProg=${AI_CTX.bestProg||'—'} patterns=${AI_CTX.confirmedPatterns.length}`,
 `execStats: ${Object.entries(AI_CTX.execStats).slice(0,4).map(([k,v])=>k+'('+v.runs+'rx)').join(' ')}`,
 `noiseSignature=${AI_CTX.noiseSignature} predictedHz=${AI_CTX.predictedHz||'—'}`,
 `priorityProg=${AI_CTX.priorityProg||'—'} rankedProgs=[${AI_CTX.rankedProgs.slice(0,4).join(',')}]`,
 `lowEffProgs: ${[...AI_CTX.lowEffProgs].join(' ')||'none'}`,
 `AI_BAN: ${AI_BAN.size} total (new ${newBanCount()}/${AI_GATE.maxBan}) · gate=${AI_GATE.enabled?'ON':'OFF'}`,
 `perms: mic=${PERMS.mic} notif=${PERMS.notifications} store=${PERMS.storage} wake=${PERMS.wakeLock} file=${PERMS.fileAccess}`,
 ];
 tLog('SYS',`>>> CONTEXT`,lines.join('\n'));
 return;
 }
 if(cmd==='PREDICT'){
 const st=getState();
 const t0=performance.now();
 const lines=AI_LIB.FREQ_PREDICT.run(st);
 logExec({prog:'FREQ_PREDICT',lines,ms:Math.round(performance.now()-t0),auto:false});
 return;
 }
 if(cmd==='RANK'){
 // Show UCB1 ranking from META_ADAPT
 if(!AI_CTX.rankedProgs.length){logExec({prog:'RANK',lines:['No ranking yet — run META_ADAPT or SELF_OPTIMIZE first'],auto:false});return;}
 const stats=AI_CTX.execStats;
 const lines=AI_CTX.rankedProgs.map((n,i)=>{
 const s=stats[n];
 if(!s)return`${i+1}. ${n}: no history`;
 return`${i+1}. ${n}: sil=${parseFloat(s.avgSil).toFixed(1)}% ms=${parseFloat(s.avgMs).toFixed(0)} runs=${s.runs}${AI_CTX.lowEffProgs.has(n)?' [LOW-EFF]':''}${n===AI_CTX.priorityProg?' [PRIORITY]':''}`;
 });
 logExec({prog:'RANK',lines,auto:false});
 return;
 }
 if(cmd==='STATS'){
 udsGetStats().then(counts=>{
 navigator.storage&&navigator.storage.estimate().then(est=>{
 const lines=[
 `IndexedDB: ${DBNAME} v${DBVER}`,
 ...Object.entries(counts).map(([s,c])=>` ${s}: ${c} records`),
 `Storage used: ~${Math.round((est.usage||0)/1024)}KB / ${Math.round((est.quota||0)/1024/1024)}MB`,
 `Persist: ${AI_CTX.ready?'ready':'not ready'}`,
 ];
 if(typeof ZeroAndroid!=='undefined'){
 lines.push(`Android internal: ${ZeroAndroid.getInternalPath()}`);
 lines.push(`Android export: ${ZeroAndroid.getExportPath()}`);
 lines.push(`Storage used: ${Math.round(ZeroAndroid.getStorageUsed()/1024)}KB`);
 }
 tLog('SYS',`>>> STATS`,lines.join('\n'));
 }).catch(()=>{
 const lines=[`IndexedDB: ${DBNAME} v${DBVER}`,...Object.entries(counts).map(([s,c])=>` ${s}: ${c} records`)];
 tLog('SYS',`>>> STATS`,lines.join('\n'));
 });
 });
 return;
 }
 if(cmd==='REFRESH'){
 updateAICtx().then(()=>tLog('SYS','>>> REFRESH: AI_CTX updated from UDS'));
 return;
 }
 if(cmd==='ENV'){
 classifyEnvironment();
 const info=ENV_LABELS[curEnvClass]||ENV_LABELS.mixed;
 const sf=typeof SPEC_FLAT!=='undefined'?SPEC_FLAT.val:0;
 const hnr=typeof HNR!=='undefined'?HNR.val:0;
 const zcr=typeof ZCRATE!=='undefined'?ZCRATE.val:0;
 const crest=typeof CREST!=='undefined'?CREST.val:1;
 const lines=[
 `Environment: ${info.label}`,
 `SpectralFlat=${sf.toFixed(4)} HNR=${hnr.toFixed(1)}dB`,
 `ZCR=${zcr.toFixed(4)} Crest=${crest.toFixed(2)}`,
 `Silence=${silSc}% FreqDB=${typeof freqDB!=='undefined'?freqDB.size:0}`,
 ];
 tLog('SYS',`>>> ENV`,lines.join('\n'));
 return;
 }
 if(cmd==='HISTORY'){
 const mins=parseInt(parts[1])||5;
 const cutoff=Date.now()-mins*60000;
 udsQueryEvents('ALL',500).then(evts=>{
 const recent=evts.filter(e=>(e.ts||0)>cutoff);
 tLog('SYS',`>>> HISTORY ${mins}min`,`${recent.length} events in last ${mins}min`);
 });
 return;
 }
 // BAN a frequency
 if(cmd==='BAN'){
 const hz=parseFloat(parts[1]);
 if(isNaN(hz)||hz<=0){logExec({prog:'BAN',lines:['Usage: BAN <hz> e.g. BAN 50'],auto:false});return;}
 const reason=(parts.slice(2).join(' '))||'manual';
 const ok=banFreq(hz,reason);
 logExec({prog:'BAN',lines:[ok?`Banned: ${fBin(hz).toFixed(2)}Hz (${reason})`:`Could not ban: max=${AI_GATE.maxBan} or already banned`],auto:false});
 return;
 }
 // UNBAN a frequency
 if(cmd==='UNBAN'){
 const hz=parseFloat(parts[1]);
 if(isNaN(hz)){
 if(parts[1]==='ALL'){AI_BAN.clear();PERSIST.saveBans();renderBanList();logExec({prog:'UNBAN',lines:['All frequencies unbanned',' PERSIST cleared — restart will load fresh'],auto:false});return;}
 if(parts[1]==='PERSIST'||parts[1]==='CACHE'){PERSIST.clear();AI_BAN.clear();renderBanList();logExec({prog:'UNBAN',lines:['PERSIST + AI_BAN cleared','Next restart: fresh start (12 defaults only)'],auto:false});return;}
 logExec({prog:'UNBAN',lines:['Usage: UNBAN <hz> or UNBAN ALL'],auto:false});return;
 }
 const ok=unbanFreq(hz);
 logExec({prog:'UNBAN',lines:[ok?`Unbanned: ${fBin(hz).toFixed(2)}Hz`:`Not banned: ${fBin(hz).toFixed(2)}Hz`],auto:false});
 return;
 }
 // BANLIST — show all banned
 if(cmd==='BANLIST'){
 if(!AI_BAN.size){logExec({prog:'BANLIST',lines:['No frequencies banned','Tip: BAN <hz> or let FREQ_GATE auto-ban'],auto:false});return;}
 const lines=[` ${AI_BAN.size} محضور دائماً (جديد: ${newBanCount()}/${AI_GATE.maxBan})`];
 [...AI_BAN.entries()].sort((a,b)=>a[0]-b[0]).forEach(([hz,d])=>
 lines.push(` ${hz.toFixed(2)}Hz [${d.reason}] (${execCyc-d.bannedAt} دورة)`));
 logExec({prog:'BANLIST',lines,auto:false});
 return;
 }
 // PARTITIONS — build and show
 if(cmd==='PARTITIONS'){
 const p=buildFreqPartitions();
 if(!p){logExec({prog:'PARTITIONS',lines:['FreqDB empty — run AI first to capture frequencies'],auto:false});return;}
 const lines=[
 `Partitions built at cycle ${p.aiCyc} sil=${p.silSc}%`,
 `hot=${p.counts.hot} cold=${p.counts.cold} conf=${p.counts.conf}`,
 `inv=${p.counts.inv} banned=${p.counts.banned} pred=${p.counts.predicted}`,
 `noise: ${p.noiseSignature}`,
 ];
 if(parts[1]==='SAVE'){saveFreqPartitions();lines.push('→ Saving to file...');}
 logExec({prog:'PARTITIONS',lines,auto:false});
 return;
 }
 // NOTCH — manage software notch suppression
 if(cmd==='NOTCH'){
 const sub=parts[1]||'';
 if(sub==='OFF'){NOTCH_SUPPRESS.clear();updateNotchUI();logExec({prog:'NOTCH',lines:['All notches cleared'],auto:false});}
 else if(sub==='LIST'){
 const ls=NOTCH_SUPPRESS.size?[...NOTCH_SUPPRESS.values()].map(n=>`${n.hz.toFixed(1)}Hz -${n.depth}dB ±${n.halfBins}bin${n.order>1?' ×'+n.order:''}`):'No active notches';
 logExec({prog:'NOTCH',lines:Array.isArray(ls)?['Active notches:',...ls]:['No active notches'],auto:false});
 } else if(sub==='HARM'){
 NOTCH_HARM.enabled=!NOTCH_HARM.enabled;
 logExec({prog:'NOTCH',lines:[`Harmonic chain: ${NOTCH_HARM.enabled?'ON ':'OFF '}`,`maxOrder=×${NOTCH_HARM.maxOrder} — adds 2f, 3f notches automatically`,'NOTCH HARM to toggle · NOTCH <hz> to add root'],auto:false});
 } else if(sub==='DECAY'){
 const val=parseFloat(parts[2]);
 if(parts[2]&&parts[2].toUpperCase()==='OFF'){NOTCH_DECAY.enabled=false;logExec({prog:'NOTCH',lines:['Notch decay: OFF '],auto:false});}
 else if(!isNaN(val)&&val>0){NOTCH_DECAY.afterMs=val*1000;NOTCH_DECAY.enabled=true;logExec({prog:'NOTCH',lines:[`Notch decay: ON — after ${val}s idle`],auto:false});}
 else{NOTCH_DECAY.enabled=!NOTCH_DECAY.enabled;logExec({prog:'NOTCH',lines:[`Notch decay: ${NOTCH_DECAY.enabled?'ON ':'OFF '}`,`Expires after ${NOTCH_DECAY.afterMs/1000}s · NOTCH DECAY <secs> · NOTCH DECAY OFF`],auto:false});}
 } else if(!isNaN(parseFloat(sub))&&parseFloat(sub)>0){
 const hz=parseFloat(sub);
 if(NOTCH_SUPPRESS.has(fBin(hz))){deactivateNotch(hz);logExec({prog:'NOTCH',lines:[`Removed notch @ ${hz}Hz`],auto:false});}
 else{activateNotch(hz);logExec({prog:'NOTCH',lines:[`Added notch @ ${hz}Hz${NOTCH_HARM.enabled?' + harmonics':''}`],auto:false});}
 } else {
 logExec({prog:'NOTCH',lines:[`Active: ${NOTCH_SUPPRESS.size} notches`,'NOTCH LIST · NOTCH OFF · NOTCH <hz>','NOTCH HARM (harmonic chain) · NOTCH DECAY <secs>'],auto:false});
 }
 return;
 }
 // BAND — frequency band lock for KF tracking
 if(cmd==='BAND'){
 if(!parts[1]||parts[1].toUpperCase()==='OFF'){
 FREQ_BAND.enabled=false;
 logExec({prog:'BAND',lines:['Band lock: OFF — full spectrum tracking'],auto:false});
 } else if(!isNaN(parseFloat(parts[1]))&&!isNaN(parseFloat(parts[2]))){
 FREQ_BAND.lo=parseFloat(parts[1]);FREQ_BAND.hi=parseFloat(parts[2]);FREQ_BAND.enabled=true;
 logExec({prog:'BAND',lines:[`Band lock: ON — ${FREQ_BAND.lo}–${FREQ_BAND.hi}Hz`,'KF only tracks freqs within this range · BAND OFF to release'],auto:false});
 } else {
 logExec({prog:'BAND',lines:[`Band lock: ${FREQ_BAND.enabled?FREQ_BAND.lo+'–'+FREQ_BAND.hi+'Hz ':'OFF '}`,'Usage: BAND <lo> <hi> · BAND OFF','Example: BAND 40 120 (fan hum range)'],auto:false});
 }
 return;
 }
 // SCENE — named environment profile snapshots
 if(cmd==='SCENE'){
 const sub=(parts[1]||'').toUpperCase();
 const arg2=parts.slice(2).join(' ').trim()||parts[1]||'';
 if(!sub||sub==='LIST'){
 sceneList().then(ss=>{
 if(!ss.length){logExec({prog:'SCENE',lines:['No scenes saved','Use: SCENE SAVE <name>'],auto:false});return;}
 const fmtTs=ts=>{const d=new Date(ts);return d.toLocaleDateString()+' '+d.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'});};
 logExec({prog:'SCENE',lines:['Saved scenes ↓',...ss.map(s=>`• "${s.name}" — ${s.freqCount} freqs, ${s.notchCount} notches [${fmtTs(s.ts)}]`)] ,auto:false});
 });
 } else if(sub==='SAVE'){
 const nm=parts.slice(2).join(' ').trim()||parts[1];
 if(!nm||nm==='SAVE'){logExec({prog:'SCENE',lines:['Usage: SCENE SAVE <name>'],auto:false});return;}
 sceneSave(nm).then(s=>{
 if(!s){logExec({prog:'SCENE',lines:[' Save failed'],auto:false});return;}
 logExec({prog:'SCENE',lines:[` Saved: "${nm}"`,` ${s.freqCount} freqs · ${s.notchCount} notches · env=${s.env}`],auto:false});
 });
 } else if(sub==='LOAD'){
 const nm=parts.slice(2).join(' ').trim()||parts[1];
 if(!nm||nm==='LOAD'){logExec({prog:'SCENE',lines:['Usage: SCENE LOAD <name>'],auto:false});return;}
 sceneLoad(nm).then(s=>{
 if(!s){logExec({prog:'SCENE',lines:[` Scene not found: "${nm}"`],auto:false});return;}
 logExec({prog:'SCENE',lines:[` Loaded: "${nm}"`,` ${s.freqCount} freqs restored · ${s.notchCount} notches active`],auto:false});
 });
 } else if(sub==='DEL'||sub==='DELETE'||sub==='RM'){
 const nm=parts.slice(2).join(' ').trim();
 if(!nm){logExec({prog:'SCENE',lines:['Usage: SCENE DEL <name>'],auto:false});return;}
 sceneDelete(nm).then(ok=>{
 logExec({prog:'SCENE',lines:[ok?` Deleted: "${nm}"`:(` Not found: "${nm}"`)],auto:false});
 });
 } else {
 // Treat bare arg as scene name → LOAD shortcut
 const nm=parts.slice(1).join(' ').trim();
 sceneLoad(nm).then(s=>{
 if(s)logExec({prog:'SCENE',lines:[` Loaded: "${nm}" (${s.freqCount} freqs, ${s.notchCount} notches)`],auto:false});
 else logExec({prog:'SCENE',lines:[`SCENE LIST · SCENE SAVE <name> · SCENE LOAD <name> · SCENE DEL <name>`],auto:false});
 });
 }
 return;
 }
 // NOTCH_ADAPT — toggle adaptive notch tracking
 if(cmd==='ADAPT'){
 NOTCH_ADAPT.enabled=!NOTCH_ADAPT.enabled;
 logExec({prog:'ADAPT',lines:[`Adaptive notch tracking: ${NOTCH_ADAPT.enabled?'ON ':'OFF '}`,`maxDrift=±${NOTCH_ADAPT.maxDrift}Hz · cooldown=2.5s`],auto:false});
 return;
 }
 // GATE — control AI ban gate
 if(cmd==='GATE'){
 const sub=parts[1]||'';
 if(sub==='ON'){AI_GATE.enabled=true;logExec({prog:'GATE',lines:['AI gate ENABLED'],auto:false});}
 else if(sub==='OFF'){AI_GATE.enabled=false;logExec({prog:'GATE',lines:['AI gate DISABLED — no freq banning'],auto:false});}
 else if(sub==='MAX'){const n=parseInt(parts[2]);if(!isNaN(n)&&n>0){AI_GATE.maxBan=n;logExec({prog:'GATE',lines:['maxBan='+n],auto:false});}else logExec({prog:'GATE',lines:['Usage: GATE MAX <n>'],auto:false});}
 else logExec({prog:'GATE',lines:[`AI_GATE: enabled=${AI_GATE.enabled} maxBan=${AI_GATE.maxBan} autoUnbanAfter=${AI_GATE.autoUnbanAfter} failThresh=${AI_GATE.failThresh}`,'Subcommands: GATE ON · GATE OFF · GATE MAX <n>'],auto:false});
 return;
 }
 // PERMS — show permission status
 if(cmd==='PERMS'){
 logExec({prog:'PERMS',lines:[
 `mic: ${PERMS.mic}`,`notifications: ${PERMS.notifications}`,
 `storage: ${PERMS.storage}`,`wakeLock: ${PERMS.wakeLock}`,
 `fileAccess: ${PERMS.fileAccess}`,
 PERMS.fileHandle?'fileHandle: directory open':'fileHandle: none',
 'Tip: type PERMS in terminal or tap "Request Permissions" in BG tab',
 ],auto:false});
 return;
 }
 // AUTOPRESET — toggle auto preset switching by environment
 if(cmd==='AUTOPRESET'){
 const sub=parts[1]||'';
 if(sub==='ON'||sub==='OFF'){
 AUTOPRESET.enabled=(sub==='ON');
 logExec({prog:'AUTOPRESET',lines:[`Auto-preset by environment: ${AUTOPRESET.enabled?'ON ':'OFF '}`,`cooldown=${AUTOPRESET.cooldown/1000}s`,`Map: quiet→${AUTOPRESET.map.quiet} tonal→${AUTOPRESET.map.tonal} noise→${AUTOPRESET.map.noise}`],auto:false});
 } else if(sub==='MAP'&&parts[2]&&parts[3]){
 const envK=parts[2].toLowerCase(),preK=parts[3].toLowerCase();
 if(AUTOPRESET.map.hasOwnProperty(envK)&&['low','balanced','full'].includes(preK)){
 AUTOPRESET.map[envK]=preK;
 logExec({prog:'AUTOPRESET',lines:[`Mapped: ${envK} → ${preK}`],auto:false});
 } else logExec({prog:'AUTOPRESET',lines:['Usage: AUTOPRESET MAP <env> <preset>','envs: quiet tonal noise impulsive mechanical interference mixed','presets: low balanced full'],auto:false});
 } else {
 AUTOPRESET.enabled=!AUTOPRESET.enabled;
 logExec({prog:'AUTOPRESET',lines:[`Auto-preset: ${AUTOPRESET.enabled?'ON ':'OFF '}`,`cooldown=${AUTOPRESET.cooldown/1000}s · AUTOPRESET ON/OFF · AUTOPRESET MAP <env> <preset>`,...Object.entries(AUTOPRESET.map).map(([e,p])=>` ${e} → ${p}`)],auto:false});
 }
 return;
 }
 // LOCK — KF frequency lock (Dev120)
 if(cmd==='LOCK'){
 const hz=parseFloat(parts[1]);
 if(parts[1]&&parts[1].toUpperCase()==='OFF'){KF_LOCK.enabled=false;logExec({prog:'LOCK',lines:['KF Lock disabled — free tracking resumed'],auto:false});return;}
 if(isNaN(hz)||hz<20||hz>20000){logExec({prog:'LOCK',lines:['KF Frequency Lock','Usage: LOCK <hz> [tol] — constrain Kalman filter to target ±tol Hz','Example: LOCK 50 → lock to 50Hz ±15Hz','Example: LOCK 100 5 → lock to 100Hz ±5Hz','LOCK OFF → release lock'],auto:false});return;}
 KF_LOCK.hz=hz;KF_LOCK.tol=isNaN(parseFloat(parts[2]))?15:parseFloat(parts[2]);KF_LOCK.enabled=true;
 logExec({prog:'LOCK',lines:[` KF Lock engaged: ${hz.toFixed(1)}Hz ±${KF_LOCK.tol}Hz`,`KF will be pulled toward target by 30% per frame`,`Current KF: ${fanFreq.toFixed(2)}Hz → LOCK OFF to release`],auto:false});
 return;
 }
 // FMAP — frequency persistence ASCII histogram (Dev120)
 if(cmd==='FMAP'){
 if(!freqDB.size){logExec({prog:'FMAP',lines:['FreqDB empty — run analysis first','FMAP shows detection count histogram across frequency bins'],auto:false});return;}
 const entries=[...freqDB.values()].filter(e=>e.count>0).sort((a,b)=>a.hz-b.hz);
 const maxC=Math.max(...entries.map(e=>e.count),1);
 const barW=12;
 const lines=['Freq (Hz) Count Map','─────────────────────────────────',...entries.map(e=>{const pct=e.count/maxC;const bar='█'.repeat(Math.round(pct*barW)).padEnd(barW);const conf=e.confirmed?'*':'';return `${e.hz.toFixed(1).padStart(8)} ${String(e.count).padStart(5)} ${bar}${conf}`;}),'','(* = confirmed) · sorted by frequency'];
 logExec({prog:'FMAP',lines,auto:false});
 return;
 }
 // ALERT — adaptive SQI/hop alert system (Dev120)
 if(cmd==='ALERT'){
 const sub=(parts[1]||'').toUpperCase();
 if(sub==='ON'){ADAPTIVE_ALERT.enabled=true;ADAPTIVE_ALERT.level='ok';logExec({prog:'ALERT',lines:[` Adaptive Alert ON`,`Warn: SQI<${ADAPTIVE_ALERT.warnSQI} or hops>${ADAPTIVE_ALERT.warnHops}`,`Critical: SQI<${ADAPTIVE_ALERT.critSQI}`,`Cooldown: ${ADAPTIVE_ALERT.cooldown/1000}s between alerts`],auto:false});return;}
 if(sub==='OFF'){ADAPTIVE_ALERT.enabled=false;logExec({prog:'ALERT',lines:[' Adaptive Alert OFF'],auto:false});return;}
 if(sub==='WARN'&&!isNaN(parseFloat(parts[2]))){ADAPTIVE_ALERT.warnSQI=+parseFloat(parts[2]).toFixed(0);logExec({prog:'ALERT',lines:[`Warn threshold: SQI<${ADAPTIVE_ALERT.warnSQI}`],auto:false});return;}
 if(sub==='CRIT'&&!isNaN(parseFloat(parts[2]))){ADAPTIVE_ALERT.critSQI=+parseFloat(parts[2]).toFixed(0);logExec({prog:'ALERT',lines:[`Critical threshold: SQI<${ADAPTIVE_ALERT.critSQI}`],auto:false});return;}
 // status
 logExec({prog:'ALERT',lines:[`Adaptive Alert: ${ADAPTIVE_ALERT.enabled?'ON ':'OFF '}`,`Level: ${ADAPTIVE_ALERT.level} · Current SQI: ${SQI.val}`,`Thresholds: warn SQI<${ADAPTIVE_ALERT.warnSQI} | critical SQI<${ADAPTIVE_ALERT.critSQI}`,`Hop warn: >${ADAPTIVE_ALERT.warnHops} hops · Cooldown: ${ADAPTIVE_ALERT.cooldown/1000}s`,'ALERT ON/OFF · ALERT WARN <sqi> · ALERT CRIT <sqi>'],auto:false});
 return;
 }
 // REC — detection recording buffer (Dev120)
 if(cmd==='REC'){
 const sub=(parts[1]||'').toUpperCase();
 if(sub==='START'){
 if(!isRun){logExec({prog:'REC',lines:['Start analysis first before recording'],auto:false});return;}
 REC.buf=[];REC.active=true;REC.startT=Date.now();
 logExec({prog:'REC',lines:[` Recording started — captures {t, hz, energy, env, sqi} per frame (~40ms)`,`Buffer: max ${REC.maxLen} frames (~${Math.round(REC.maxLen*0.04/60*10)/10} min)`,`REC STOP · REC STATUS · REC DUMP`],auto:false});
 return;
 }
 if(sub==='STOP'){REC.active=false;logExec({prog:'REC',lines:[` Recording stopped — ${REC.buf.length} frames captured`,`Duration: ~${(REC.buf.length*0.04).toFixed(1)}s · REC DUMP to export`],auto:false});return;}
 if(sub==='STATUS'){logExec({prog:'REC',lines:[`REC: ${REC.active?' ACTIVE':' stopped'}`,`Frames: ${REC.buf.length}/${REC.maxLen} · ~${(REC.buf.length*0.04).toFixed(1)}s`,REC.buf.length?`Last: hz=${REC.buf[REC.buf.length-1].hz} env=${REC.buf[REC.buf.length-1].env} sqi=${REC.buf[REC.buf.length-1].sqi}`:'(empty)'],auto:false});return;}
 if(sub==='DUMP'){
 if(!REC.buf.length){logExec({prog:'REC',lines:['Buffer empty — REC START first'],auto:false});return;}
 const snap=REC.buf.slice(-20);
 const lines=[`Recording dump (last ${snap.length} of ${REC.buf.length} frames):`,`${'t(ms)'.padEnd(8)} ${'hz'.padEnd(8)} ${'energy'.padEnd(8)} ${'env'.padEnd(12)} sqi`,'─'.repeat(50),...snap.map(r=>`${String(r.t).padEnd(8)} ${String(r.hz).padEnd(8)} ${String(r.e).padEnd(8)} ${String(r.env).padEnd(12)} ${r.sqi}`),'','Full JSON via EXPORT command'];
 logExec({prog:'REC',lines,auto:false});return;
 }
 if(sub==='CLEAR'){REC.buf=[];REC.active=false;logExec({prog:'REC',lines:['Buffer cleared'],auto:false});return;}
 logExec({prog:'REC',lines:['Detection Recording Buffer','REC START — begin capturing detection frames','REC STOP — stop capture','REC STATUS — show current state','REC DUMP — print last 20 frames','REC CLEAR — wipe buffer'],auto:false});
 return;
 }
 // ALARM — frequency alarm system (Dev110)
 if(cmd==='ALARM'){
 const sub=parts[1]||'';
 if(sub.toUpperCase()==='LIST'){
 if(!FREQ_ALARMS.size){logExec({prog:'ALARM',lines:['No active alarms','Usage: ALARM <hz> [tol] — e.g. ALARM 50 3'],auto:false});return;}
 const lines=[`${FREQ_ALARMS.size} active alarm${FREQ_ALARMS.size!==1?'s':''}:`,...[...FREQ_ALARMS.values()].map(a=>` ${a.enabled?'':''} ${a.hz.toFixed(1)}Hz ±${a.tol}Hz — triggered ${a.count}× — cd ${a.cooldown/1000}s`),'','ALARM OFF — disable all · ALARM OFF <hz> — remove one'];
 logExec({prog:'ALARM',lines,auto:false});
 } else if(sub.toUpperCase()==='CLEAR'||sub.toUpperCase()==='OFF'&&!parts[2]){
 FREQ_ALARMS.clear();logExec({prog:'ALARM',lines:['All alarms cleared '],auto:false});
 } else if(sub.toUpperCase()==='OFF'&&parts[2]){
 const hz=parseFloat(parts[2]);if(!isNaN(hz)){FREQ_ALARMS.delete(fBin(hz));logExec({prog:'ALARM',lines:[`Alarm at ~${hz}Hz removed`],auto:false});}
 } else if(!isNaN(parseFloat(sub))&&parseFloat(sub)>0){
 const hz=parseFloat(sub),tol=!isNaN(parseFloat(parts[2]))?parseFloat(parts[2]):5;
 const cd=!isNaN(parseFloat(parts[3]))?parseFloat(parts[3])*1000:3000;
 FREQ_ALARMS.set(fBin(hz),{hz,tol,count:0,lastTrigT:0,cooldown:cd,enabled:true});
 logExec({prog:'ALARM',lines:[` Alarm set: ${hz}Hz ±${tol}Hz · cooldown ${cd/1000}s`,`Will fire logNN + visual pulse on detection`,'ALARM LIST · ALARM OFF <hz>'],auto:false});
 } else {
 logExec({prog:'ALARM',lines:['Frequency detection alarm','Usage: ALARM <hz> [±tol] [cooldown_s]','Example: ALARM 50 3 5 → fires when 50±3Hz detected, 5s cooldown','ALARM LIST · ALARM OFF · ALARM CLEAR'],auto:false});
 }
 return;
 }
 // POWER — octave band power levels (Dev110)
 if(cmd==='POWER'){
 if(!isRun||!lastFFD){logExec({prog:'POWER',lines:['No audio data — start analysis first'],auto:false});return;}
 const maxV=Math.max(-20,...BAND_POWER.vals);
 const bar=v=>{const n=Math.round(Math.max(0,(v-(-80))/(maxV-(-80))*14));return '█'.repeat(n)+'░'.repeat(14-n);};
 const lines=[
 '─── Octave Band Power ──────────────',
 ...BAND_POWER.BANDS.map((b,i)=>{const v=BAND_POWER.vals[i];const lbl=(b.lbl+'Hz').padStart(5);return ` ${lbl} ${bar(v)} ${v.toFixed(1)} dB`;}),
 '────────────────────────────────────',
 `Peak band: ${BAND_POWER.BANDS[BAND_POWER.vals.indexOf(Math.max(...BAND_POWER.vals))].lbl}Hz`,
 ];
 logExec({prog:'POWER',lines,auto:false});
 return;
 }
 // DELTA — spectral comparison (Dev110)
 if(cmd==='DELTA'){
 const sub=parts[1]||'';
 if(sub.toUpperCase()==='SAVE'){
 if(!lastFFD){logExec({prog:'DELTA',lines:['No FFT data yet — start analysis first'],auto:false});return;}
 SPEC_DELTA.baseline=Float32Array.from(lastFFD);SPEC_DELTA.baseT=Date.now();
 logExec({prog:'DELTA',lines:[` Baseline saved (${lastFFD.length} bins @ ${SPEC_DELTA.bHz.toFixed(3)}Hz/bin)`,`Saved at: ${new Date().toLocaleTimeString()}`,'Now run DELTA to compare current vs baseline'],auto:false});
 } else if(sub.toUpperCase()==='CLEAR'){
 SPEC_DELTA.baseline=null;SPEC_DELTA.baseT=0;
 logExec({prog:'DELTA',lines:['Baseline cleared'],auto:false});
 } else {
 if(!SPEC_DELTA.baseline){logExec({prog:'DELTA',lines:['No baseline saved','Run "DELTA SAVE" first, then change environment, then "DELTA" to compare'],auto:false});return;}
 const changes=computeSpecDelta();
 if(!changes||!changes.length){logExec({prog:'DELTA',lines:['No significant changes (threshold >3 dB)','Try DELTA SAVE in a different environment first'],auto:false});return;}
 const age=((Date.now()-SPEC_DELTA.baseT)/1000).toFixed(0);
 const lines=[`Δ spectrum vs baseline (${age}s ago) — top changes:`,
 '─────────────────────────────────────',
 ...changes.map(c=>` ${c.hz<1000?c.hz.toFixed(1)+'Hz':(c.hz/1000).toFixed(2)+'kHz'} ${c.diff>0?'+':''}${c.diff.toFixed(1)} dB ${c.diff>0?'▲ risen':'▼ fallen'}`),
 '─────────────────────────────────────',
 `${changes.filter(c=>c.diff>0).length} risen · ${changes.filter(c=>c.diff<0).length} fallen`];
 logExec({prog:'DELTA',lines,auto:false});
 }
 return;
 }
 // PEAKS — top-5 spectral peaks from last FFT frame (Dev100)
 if(cmd==='PEAKS'){
 if(!PEAKS_DATA.peaks||!PEAKS_DATA.peaks.length){logExec({prog:'PEAKS',lines:['No peak data yet — start analysis first','Multi-peak detector runs every 40ms during detection'],auto:false});return;}
 const age=PEAKS_DATA.lastT?((Date.now()-PEAKS_DATA.lastT)/1000).toFixed(1):'?';
 const lines=[`Top ${PEAKS_DATA.peaks.length} spectral peaks (${age}s ago)`,
 '─────────────────────────────',
 ...PEAKS_DATA.peaks.map((p,i)=>` #${i+1} ${p.hz.toFixed(2)} Hz ${p.db.toFixed(1)} dB${NOTCH_SUPPRESS.has(fBin(p.hz))?' ':''}`),
 '─────────────────────────────',
 'Notched + banned peaks are excluded from results'];
 logExec({prog:'PEAKS',lines,auto:false});
 return;
 }
 // SQI — Signal Quality Index breakdown (Dev100)
 if(cmd==='SQI'){
 computeSQI();
 const bar=n=>'█'.repeat(Math.round(n/10))+'░'.repeat(10-Math.round(n/10));
 const lines=[
 `Signal Quality Index: ${SQI.val}/100 ${SQI.val>=80?'':SQI.val>=50?'':''}`,
 '─────────────────────────────────────',
 ` KF Confidence [${bar(SQI.kfConf)}] ${SQI.kfConf}% ×0.30`,
 ` Supp. Eff. [${bar(SQI.suppEff)}] ${SQI.suppEff}% ×0.30`,
 ` Env Stability [${bar(SQI.envStab)}] ${SQI.envStab}% ×0.40`,
 ` Hop Penalty −${SQI.hopPenalty} pts (${Math.max(0,FREQ_HOP.count-(SESSION_STAT.hopCount0||0))} hops since start)`,
 '─────────────────────────────────────',
 ` Final: ${SQI.val}/100 — ${SQI.val>=80?'Strong signal, high confidence':SQI.val>=50?'Moderate — check for hops/env changes':'Weak signal — unstable tracking'}`];
 logExec({prog:'SQI',lines,auto:false});
 return;
 }
 // EXPORT — JSON snapshot to terminal + clipboard (Dev100)
 if(cmd==='EXPORT'){
 computeSQI();
 const snap={
 timestamp:new Date().toISOString(),version:'ZERO-v25-Dev100',
 session:{uptime:SESSION_STAT.startT?Date.now()-SESSION_STAT.startT:0,aiCycles:aiCyc,env:curEnvClass,preset:curPreset},
 sqi:SQI,
 freqs:[...freqDB.values()].slice(0,50).map(e=>({hz:e.hz,confirmed:e.confirmed,class:e.class})),
 notches:[...NOTCH_SUPPRESS.values()].map(n=>({hz:n.hz,depth:n.depth,order:n.order||1})),
 peaks:PEAKS_DATA.peaks,
 hops:{total:FREQ_HOP.count,recent:FREQ_HOP.hops.slice(-10)},
 suppEff:{current:SUPP_EFF.val,sessionAvg:SESSION_STAT.suppEffN>0?Math.round(SESSION_STAT.suppEffSum/SESSION_STAT.suppEffN):0},
 notchPeak:SESSION_STAT.notchPeak,
 envBreakdown:SESSION_STAT.envCount
 };
 const json=JSON.stringify(snap,null,2);
 const lines=['═══ ZERO v25 EXPORT ═══','',json.slice(0,800)+(json.length>800?'\n... (truncated — full copy sent to clipboard)':''),'','═══════════════════════'];
 logExec({prog:'EXPORT',lines,auto:false});
 // Copy to clipboard
 if(navigator.clipboard&&navigator.clipboard.writeText){
 navigator.clipboard.writeText(json).then(()=>logNN(' EXPORT: full JSON copied to clipboard')).catch(()=>logNN(' EXPORT: clipboard write failed'));
 }
 return;
 }
 // HOPS — frequency hop history
 if(cmd==='HOPS'){
 if(!FREQ_HOP.hops.length){logExec({prog:'HOPS',lines:['No freq hops detected yet',`Threshold: Δ>${FREQ_HOP.threshold}Hz · debounce 500ms`],auto:false});return;}
 const lines=[`Total hops: ${FREQ_HOP.count} · Threshold: Δ>${FREQ_HOP.threshold}Hz`,'--- Recent hops (newest first) ---',...[...FREQ_HOP.hops].reverse().slice(0,15).map(h=>{const d=new Date(h.t);return `${d.toLocaleTimeString()} ${h.from.toFixed(1)}→${h.to.toFixed(1)}Hz (Δ${h.delta.toFixed(1)}Hz)`;})];
 logExec({prog:'HOPS',lines,auto:false});
 return;
 }
 // Unknown
 logExec({prog:'ERR',lines:['Unknown: '+raw,'Programs: '+Object.keys(AI_LIB).join(' '),'DB: QUERY · PATTERN · CONTEXT · STATS · REFRESH · HISTORY','Analysis: PREDICT · RANK · ENV','BAN: BAN <hz> · UNBAN <hz> · BANLIST · GATE ON/OFF','Notch: NOTCH <hz> · NOTCH LIST · NOTCH OFF · ADAPT · NOTCH HARM · NOTCH DECAY <s>','Scenes: SCENE LIST · SCENE SAVE <n> · SCENE LOAD <n> · SCENE DEL <n>','Partitions: PARTITIONS · PARTITIONS SAVE','Perms: PERMS','SET: SET SF.INF 0.8 · SET NN.LR 0.015 · SET THRESH 4','Hop: HOPS · Preset: AUTOPRESET ON/OFF','Band: BAND <lo> <hi> · BAND OFF','Dev100: PEAKS · SQI · EXPORT','Dev110: ALARM <hz> · POWER · DELTA SAVE · DELTA','Dev120: LOCK <hz> · FMAP · ALERT ON/OFF · REC START'],auto:false});
}

/* ══ EXEC CYCLE UPDATE (called from startNN) ══ */
function updateExecUI(){
 const es=E('ex-sil');if(es)es.textContent=silSc+'%';
 const en=E('ex-nn');if(en)en.textContent=NN.loss.toFixed(3);
 const ed=E('ex-db');if(ed)ed.textContent=freqDB.size;
 const ec=E('execCycLbl');if(ec)ec.textContent='cycle '+aiCyc;
 computeSQI(); // Dev100: update SQI every NN cycle (~80ms)
 checkAdaptiveAlert(); // Dev120: progressive alert when SQI/hops degrade
 if(curTab===5)renderExecLog();
}

/* ═══════════════════════════════════════
 PERMISSION SYSTEM
═══════════════════════════════════════ */
function _setStatusBadge(id,state){
 const b=E(id);if(!b)return;
 b.className='ps-badge '+(state==='granted'?'ok':state==='denied'?'no':'warn');
}
function updatePermsUI(){
 _setStatusBadge('ps-mic',PERMS.mic);
 _setStatusBadge('ps-notif',PERMS.notifications);
 _setStatusBadge('ps-store',PERMS.storage);
 _setStatusBadge('ps-wake',PERMS.wakeLock);
 _setStatusBadge('ps-file',PERMS.fileAccess);
}

/* ═══════════════════════════════════════
 FREQUENCY PARTITIONS
═══════════════════════════════════════ */
