/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 07c-freq-bans-partitions.js
 إدارة تقسيمات الترددات وحظرها: buildFreqPartitions/banFreq/unbanFreq/renderBanList/autoBanCheck
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): تقسيم إضافي لملف كان
 أضخم من بقية الملفات — نفس المنهج: قصّ آلي عند حدود تصريحات علوية
 آمنة، بلا أي تغيير منطقي أو إعادة ترتيب.
 ══════════════════════════════════════════════════════════════════ */
let _freqPartitions=null;
function buildFreqPartitions(){
 const all=[...freqDB.values()];
 if(!all.length){addToStLog('Partitions: FreqDB empty — run AI first');return null;}
 // Sort by energy
 const sorted=[...all].sort((a,b)=>b.energy-a.energy);
 const topN=Math.max(1,Math.ceil(sorted.length*.25));
 const botN=Math.max(1,Math.ceil(sorted.length*.25));
 // Hot = top 25% energy, Cold = bottom 25%
 const hot=sorted.slice(0,topN).map(e=>({hz:e.hz,energy:e.energy,count:e.count}));
 const cold=sorted.slice(-botN).map(e=>({hz:e.hz,energy:e.energy,count:e.count}));
 // Positive (class 1/3/4)
 const pos=all.filter(e=>[1,3,4].includes(e.class||0)).map(e=>({hz:e.hz,energy:e.energy}));
 // Negative (class 2)
 const neg=all.filter(e=>(e.class||0)===2).map(e=>({hz:e.hz,energy:e.energy}));
 // Confirmed
 const conf=all.filter(e=>e.confirmed).map(e=>({hz:e.hz,energy:e.energy,count:e.count}));
 // Inverse active
 const inv=[...INV.active.values()].map(v=>({hz:v.hz,attempts:v.attempts,verified:v.verified}));
 // Banned
 const banned=[...AI_BAN.entries()].map(([hz,d])=>({hz,reason:d.reason,bannedAt:d.bannedAt,autoUnbanAt:d.autoUnbanAt}));
 // Predicted
 const predicted=AI_CTX.predictedHz?[{hz:AI_CTX.predictedHz,source:'FREQ_PREDICT'}]:[];
 // Inverse-active (negated freqs in use)
 const inverseActive=inv.filter(v=>!v.verified).map(v=>({hz:v.hz,attempts:v.attempts}));
 _freqPartitions={
 ts:Date.now(),
 silSc,
 aiCyc,
 noiseSignature:AI_CTX.noiseSignature,
 partitions:{
 hot,cold,positive:pos,negative:neg,
 confirmed:conf,inversed:inv,banned,predicted,
 inverseActive
 },
 counts:{
 hot:hot.length,cold:cold.length,pos:pos.length,neg:neg.length,
 conf:conf.length,inv:inv.length,banned:banned.length,predicted:predicted.length
 }
 };
 // Update UI
 const sv=id=>E(id);
 if(sv('part-hot-v'))sv('part-hot-v').textContent=hot.length;
 if(sv('part-cold-v'))sv('part-cold-v').textContent=cold.length;
 if(sv('part-conf-v'))sv('part-conf-v').textContent=conf.length;
 if(sv('part-ban-v'))sv('part-ban-v').textContent=banned.length;
 if(sv('part-inv-v'))sv('part-inv-v').textContent=inv.length;
 if(sv('part-pred-v'))sv('part-pred-v').textContent=predicted.length;
 addToStLog('Partitions built: hot='+hot.length+' cold='+cold.length+' conf='+conf.length+' ban='+banned.length);
 return _freqPartitions;
}
async function saveFreqPartitions(){
 const p=_freqPartitions||buildFreqPartitions();
 if(!p){return;}
 const json=JSON.stringify(p,null,2);
 const fname='zero-freq-partitions-'+_isoFname()+'.json';
 // 1. Save to IndexedDB (sessions store)
 try{
 const db=await openDB();
 const tx=db.transaction('sessions','readwrite');
 tx.objectStore('sessions').put({id:'freq_partitions',ts:p.ts,data:json,type:'partitions'});
 await new Promise((res,rej)=>{tx.oncomplete=res;tx.onerror=rej;});
 addToStLog('Partitions saved to IDB');
 }catch(e){addToStLog('IDB partitions err: '+e.message);}
 // 1.5 تعميم: نسخة دائمة إضافية إلى المجلد الثابت (WebToApkFS) إن كان الوصول ممنوحاً —
 // مستقلة عن باقي الخطوات أدناه، بنفس نمط exportBans/androidWrite.
 try{
 if(typeof WebToApkFS!=='undefined'&&WebToApkFS.hasAccess&&WebToApkFS.hasAccess()){
 if(WebToApkFS.writeText(fname,json)){addToStLog('Partitions saved to fixed folder (WebToApkFS): '+fname);_cleanupFixedFolderBackups();}
 }
 }catch(e){}
 // 2. File System API (browser)
 if(PERMS.fileHandle){
 try{
 const fh=await PERMS.fileHandle.getFileHandle(fname,{create:true});
 const w=await fh.createWritable();
 await w.write(json);await w.close();
 addToStLog('Partitions saved to file: '+fname);
 }catch(e){addToStLog('File save err: '+e.message);}
 }
 // 3. Android bridge
 if(typeof ZeroAndroid!=='undefined'){
 try{ZeroAndroid.saveFile(fname,json);addToStLog('Partitions saved via Android');}catch(e){}
 }
 // 4. Fallback download
 if(!PERMS.fileHandle&&typeof ZeroAndroid==='undefined'){
 try{
 const a=document.createElement('a');
 a.href='data:application/json;charset=utf-8,'+encodeURIComponent(json);
 a.download=fname;a.click();
 addToStLog('Partitions downloaded: '+fname);
 }catch(e){}
 }
}

/* ═══════════════════════════════════════
 AI FREQUENCY BAN / UNBAN
═══════════════════════════════════════ */
function banFreq(hz,reason,opts){
 // تشديد أكثر: هذه هي الدالة العامة الأكثر استخداماً لإنشاء حظر يدوي/تلقائي في كل
 // أنحاء الملف — التحقّق يوضَع هنا في نقطة الدخول نفسها بدل الاعتماد على كل مستدعٍ
 // ليتذكّر التحقّق بنفسه (نفس نمط التحصين المطبَّق على castBanVote/updateFreqFatigue).
 if(!hz||hz<1||!isFinite(hz))return false;
 // كل الحضر دائم — لا وجود للحضر المؤقت
 const cat=opts&&opts.category||null;
 if(!AI_GATE.enabled)return false;
 const bin=fBin(hz);
 if(AI_BAN.has(bin))return false; // محضور مسبقاً
 if(newBanCount()>=AI_GATE.maxBan)return false; // السقف على الجديد فقط — لا نحذف دائماً لإفساح مجال
 AI_BAN.set(bin,{
 reason:reason||'AI',
 bannedAt:execCyc,cycles:0,
 bannedAtTime:Date.now(),
 autoUnbanAt:Infinity,
 hz:bin,permanent:true,category:cat,
 preBanEnergy:(opts&&opts.preBanEnergy)||0,
 postBanDetections:0,lastPostBanEnergy:0,probEnvironmental:null,verdict:null
 });
 // تشديد: أي سجلّ سابق لهذا التردد في قاعدة بيانات الترددات (FreqDB) يُحذف فوراً عند
 // الحظر — وإلا يبقى ظاهراً في قائمة #flist وفي تصدير EXPORT رغم حظره
 if(freqDB.has(bin)){freqDB.delete(bin);writeFreqFile();}
 checkInterference(bin);
 // إيقاف أي إبطال نشط لهذا التردد
 stopActiveInverse(hz);
 // إزالة notch هذا التردد — محضور لا يحتاج كبت إضافي
 deactivateNotch(hz);
 PERSIST.scheduleSaveBans();
 renderBanList();
 addToStLog(' محضور دائماً: '+bin.toFixed(2)+'Hz ('+reason+')');
 return true;
}
function unbanFreq(hz){
 const bin=fBin(hz);
 const had=AI_BAN.has(bin);
 AI_BAN.delete(bin);
 if(had){
 PERSIST.scheduleSaveBans();renderBanList();addToStLog('Unbanned: '+bin.toFixed(2)+'Hz');
 // Restore notch if freq is still confirmed in freqDB
 const e=freqDB.get(bin);if(e&&e.confirmed)activateNotch(hz);
 }
 return had;
}
function renderBanList(){
 const el=E('ban-list');if(!el)return;
 const total=AI_BAN.size;
 const bs=E('ban-stat');if(bs)bs.textContent=total+' محضور دائماً';
 const tot=E('ban-total-badge');if(tot)tot.textContent=total+' مُحضَر';
 if(!total){el.innerHTML='<div class="ban-empty">No frequencies banned</div>';return;}
 // نعتمد على مفتاح الـMap (hz) كمصدر الحقيقة الوحيد — لا نثق بـ d.hz المخزّن فقط
 // بلا شارات تصنيف فرعية — كل الترددات المحظورة في تصنيف واحد "ترددات محظورة"
 // خط دفاع أخير: أي مفتاح غير رقمي/غير منتهٍ (NaN) لا يظهر إطلاقاً حتى لو تسرَّب من مسار
 // غير متوقَّع — يُنظَّف فعلياً بواسطة _purgeInvalidFrequencies، وهذا الفلتر احتياطي فقط.
 el.innerHTML=[...AI_BAN.entries()].filter(([hz])=>typeof hz==='number'&&isFinite(hz)&&hz>=1).sort((a,b)=>a[0]-b[0]).map(([hz,d])=>{
 const prob=d.postBanDetections>0?
 `<span class="ban-prob"><span class="ban-prob-wrap"><span class="ban-prob-bar ${d.verdict||'pending'}" style="width:${Math.round((d.probEnvironmental||0)*100)}%"></span></span><span class="ban-verdict ${d.verdict||'pending'}">${d.verdict==='env'?'env':d.verdict==='spk'?'spk':d.verdict==='mixed'?'mix':'…'}</span></span>`:
 '<span class="ban-verdict pending" style="opacity:.35">—</span>';
 // تأكيد متقاطع بين الأجهزة: ·N يظهر فقط إن استُورد هذا التردد ولو مرة من جهاز/جلسة
 // أخرى — !N إضافية إن تعارض حكم هذا الجهاز (env/spk) مع حكم المصدر المستورَد، ما قد
 // يشير إلى تردد خاص بجهاز واحد (سماعته) وليس تداخلاً بيئياً عاماً.
 // (28 سبتمبر 2026: استُبدل رمزا / الملوَّنان بعلامتين نصيتين بسيطتين !/· — نفس
 // التمييز البصري بين الحالتين بلا أي لون، ويبقى class="conflict" + title يحملان
 // التفصيل الكامل كما كانا تماماً.)
 const cross=d.crossConfirms>0?
 `<span class="ban-cross${d.verdictAgreement==='conflict'?' conflict':''}" title="${d.verdictAgreement==='conflict'?'تعارض في الحكم بين هذا الجهاز ('+(d.verdict||'—')+') والمصدر المستورَد ('+(d.importedVerdict||'—')+')':'تأكَّد استيراده من '+d.crossConfirms+' مصدر مستقل'}">${d.verdictAgreement==='conflict'?'!':'·'}${d.crossConfirms}</span>`:'';
 return`<div class="ban-row perm"><span class="ban-hz">${hz.toFixed(2)}Hz</span><span class="ban-why">${escH(d.reason||'AI')}</span>${prob}${cross}<span class="ban-lock"></span><span class="ban-rmv" onclick="unbanFreq(${hz})">✕</span></div>`;
 }).join('');
 // Also refresh the settings perm list if open
 renderPermSettings();
}
function autoBanCheck(){
 if(!AI_GATE.enabled||!execCyc)return;
 // تحديث عداد الدورات لكل حضر (كلها دائمة — لا إلغاء تلقائي)
 AI_BAN.forEach((d)=>{d.cycles=execCyc-d.bannedAt;});
 // فحص الترددات الفاشلة المزمنة
 if(INV.failed.size>0){
 INV.failed.forEach((d,hz)=>{
 const failEntry=freqDB.get(fBin(hz));
 if(failEntry&&failEntry.confirmed&&!AI_BAN.has(fBin(hz))){
 const attempts=(INV.active.get(hz)||{attempts:0}).attempts;
 if(attempts>=INV.maxTry){banFreq(hz,'FAIL×'+INV.maxTry);}
 }
 });
 }
 renderBanList();
}

/* ══ PERMANENT BAN HELPERS ══ */

/* ══════════════════════════════════════════════════════════════════════════
 PERSIST — هيكلية تخزين منفصلة متصلة
 منفصل: تعيش في localStorage بشكل مستقل عن AI_BAN في الذاكرة
 متصل: تتزامن مع AI_BAN عند كل تغيير (save) وعند كل بداية (load)
 يحل: فقدان 400 تردد عند إعادة التشغيل أو toggle الفئة
═══════════════════════════════════════════════════════════════════════════ */
