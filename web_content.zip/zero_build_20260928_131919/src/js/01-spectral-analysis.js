/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 01-spectral-analysis.js
 تحليل طيفي متقدم: chroma, rolloff, flatness, harmonics, centroid, room modes, pitch AMDF, HNR, tonal ratio
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */
function updateChromaVec(fd,bHz){
 CHROMA_VEC.vec.fill(0);
 for(let i=1;i<fd.length;i++){
 const hz=i*bHz;if(hz<20||hz>8000)continue;
 const midi=12*Math.log2(hz/440)+69;
 const cls=((Math.round(midi)%12)+12)%12;
 CHROMA_VEC.vec[cls]+=Math.pow(10,fd[i]/10);
 }
 const mx=Math.max(...CHROMA_VEC.vec,1e-12);
 for(let i=0;i<12;i++)CHROMA_VEC.vec[i]/=mx;
 CHROMA_VEC.dominant=Array.from(CHROMA_VEC.vec).indexOf(Math.max(...CHROMA_VEC.vec));
 CHROMA_VEC.conf=CHROMA_VEC.vec[CHROMA_VEC.dominant];
 CHROMA_VEC.hist.push(CHROMA_VEC.dominant);if(CHROMA_VEC.hist.length>60)CHROMA_VEC.hist.shift();
 const cv=E('chroma-dom');if(cv)cv.textContent=NOTE_NAMES[CHROMA_VEC.dominant]+'('+CHROMA_VEC.conf.toFixed(2)+')';
}

/* ── MODULATION INDEX — AM/FM envelope analysis ── */
const MOD_IDX={am:0,fm:0,hist:[]};
function updateModulation(td){
 const s=[];for(let i=0;i<td.length;i++)s.push((td[i]-128)/128);
 let env=0;const envArr=[];
 for(let i=0;i<s.length;i++){env=env*0.92+Math.abs(s[i])*0.08;envArr.push(env);}
 const envMean=envArr.reduce((a,b)=>a+b)/envArr.length;
 const envPeak=envArr.reduce((a,b)=>b>a?b:a,0);
 MOD_IDX.am=envMean>1e-9?(envPeak-envMean)/envMean:0;
 let phChg=0;for(let i=1;i<s.length;i++)if(s[i]*s[i-1]<0)phChg+=Math.abs(s[i]-s[i-1]);
 MOD_IDX.fm=phChg/s.length;
 MOD_IDX.hist.push(MOD_IDX.am);if(MOD_IDX.hist.length>60)MOD_IDX.hist.shift();
 const mv=E('mod-v');if(mv)mv.textContent='AM:'+MOD_IDX.am.toFixed(2)+' FM:'+MOD_IDX.fm.toFixed(3);
}

/* ── SPECTRAL ROLLOFF — 85th-percentile energy frequency ── */
const ROLLOFF={hz:0,hist:[]};
function updateRolloff(fd,bHz){
 let total=0;for(let i=1;i<fd.length;i++)total+=Math.pow(10,fd[i]/10);
 let cumul=0,rHz=0;
 for(let i=1;i<fd.length;i++){
 cumul+=Math.pow(10,fd[i]/10);
 if(cumul>=total*0.85){rHz=i*bHz;break;}
 }
 ROLLOFF.hz=rHz||0;
 ROLLOFF.hist.push(ROLLOFF.hz);if(ROLLOFF.hist.length>60)ROLLOFF.hist.shift();
 const rv=E('rolloff-val');if(rv)rv.textContent=(ROLLOFF.hz/1000).toFixed(2)+'kHz';
}

/* ── SPECTRAL FLATNESS — tonality vs noise (Wiener entropy) ── */
const SPEC_FLAT={val:0,hist:[]};
function updateSpectralFlatness(fd){
 let logSum=0,linSum=0,n=0;
 for(let i=1;i<fd.length;i++){
 const p=Math.pow(10,fd[i]/10);
 logSum+=Math.log(p+1e-12);linSum+=p;n++;
 }
 const geo=Math.exp(logSum/n);const ari=linSum/n;
 SPEC_FLAT.val=ari>0?geo/ari:0;
 SPEC_FLAT.hist.push(SPEC_FLAT.val);if(SPEC_FLAT.hist.length>60)SPEC_FLAT.hist.shift();
 const fv=E('flat-val');if(fv)fv.textContent=SPEC_FLAT.val.toFixed(4);
}

/* ══ PERMISSIONS STATE ══ */
const PERMS={mic:'unknown',notifications:'unknown',storage:'unknown',wakeLock:'unknown',fileAccess:'unknown',fileHandle:null};

/* ══ AI FREQUENCY BAN SYSTEM ══ */
const AI_BAN=new Map(); // hz → {reason, bannedAt, cycles, permanent:true (دائم دائماً)}
const AI_GATE={enabled:true,maxBan:50,autoUnbanAfter:100,failThresh:4};
/* عدد الترددات "الجديدة" فقط (بدون الحضر الأساسي/الافتراضي والمؤكَّد من طبقة التكامل) —
 maxBan يحدّ من الحظر الحيّ الجديد تحديداً، لا من إجمالي AI_BAN؛ فالحضر الأساسي وحده
 (٢٥٧+ تردد) يتجاوز maxBan الأصلي (٥٠) وكان سيمنع أي حظر جديد لو قِيس على الإجمالي. */
function newBanCount(){return [...AI_BAN.values()].filter(d=>!d.baseline).length;}
function newZoneCount(){return [...INTERFERENCE_BAN.zones.values()].filter(z=>!z.baseline).length;}

/* ══ OPEN FREQUENCY RANGE ══
 No fixed Hz / kHz / MHz floor.
 Fully open: negative phase (C2/C3) and positive phase (C1/C4).
 RANGE.minHz / maxHz are soft guidance only — never enforced as hard limits.
 Bipolar energy tracked separately: posE (C1/C4) vs negE (C2/C3).
 Polarity ratio drives Wiener alpha and SF gain strategy.
══════════════════════════════════════════════ */
const RANGE={
 minHz:0, // 0 = fully open (was 0.01)
 maxHz:Infinity, // no upper limit (was Nyquist)
 allowNeg:true, // allow negative amplitude / phase-inverted detection
 biasMode:'auto',// 'auto'|'pos'|'neg'|'bipolar'
 posE:0, negE:0, // bipolar energy accumulators
 polarityRatio:0,// posE/(posE+negE), 0.5=balanced
 subBinEnable:true, // double-pass sub-bin interpolation
 negFreqMirror:false, // mirror detected freq as its negative analytic signal
};

/* Harmonic series auto-detector: detects fundamental + overtone ladder */
const HARMONICS={fund:0,series:[],q:0,resonantBands:[]};
function detectHarmonicSeries(hz,fd,bHz){
 if(!hz||hz<0.01)return;
 const series=[];let fund=hz;let maxQ=0;
 // Try hz as fundamental, look for 2nd→8th harmonic
 for(let h=2;h<=8;h++){
 const targetHz=hz*h;const bin=Math.round(targetHz/bHz);
 if(bin<fd.length){
 const amp=Math.pow(10,(fd[bin]||-120)/10);
 if(amp>1e-6)series.push({h,hz:targetHz,amp});
 }
 }
 if(series.length>=2){
 // Q factor = peak sharpness = fundamental_amp / average_neighbor_amp
 const fundBin=Math.round(hz/bHz);
 const peak=fd[fundBin]||-120;
 // تشديد أكثر: نفس فئة الخلل مرة أخرى — لو كانت خانتا الجوار كلتاهما -Infinity (طاقة
 // صفرية تماماً، حالة طبيعية أخرى لـgetFloatFrequencyData)، فإن جمعهما يبقى -Infinity
 // لا NaN هنا (لأنه ليس طرح Infinity من Infinity)، لكن peak-neighbor يُصبح Infinity
 // (منتهٍ-(-Infinity)=Infinity)، فيظهر "Q=Infinity" حرفياً في السجلّ بدل رقم منطقي
 let neighbor=(fd[fundBin-1]+fd[fundBin+1])/2;
 if(!isFinite(neighbor))neighbor=-120;
 maxQ=Math.max(0.1,Math.min(100,peak-neighbor));
 HARMONICS.fund=hz;HARMONICS.series=series;HARMONICS.q=maxQ;
 // Resonant band detection
 HARMONICS.resonantBands=series.filter(s=>s.amp>0.001).map(s=>({hz:s.hz,band:getBand(s.hz)}));
 if(maxQ>6)logNN(' Harmonic series: '+hz.toFixed(1)+'Hz · Q='+maxQ.toFixed(1)+' ('+series.length+' overtones)');
 }
}

function getBand(hz){
 // تشديد أكثر: كل هذه المقارنات (hz<X) تُعطي false مع NaN — دون هذا الحارس، تردد فاسد
 // كان سيُصنَّف صمتاً كـ"hypersound" (آخر return) بدل رفضه، بنفس نمط خلل NaN/0Hz المُعالَج
 // في كل الدوال الأخرى بالملف.
 if(!isFinite(hz))return'invalid';
 if(hz<0.01)return'sub-sub';if(hz<0.5)return'sub-infra';
 if(hz<20)return'infrasound';if(hz<100)return'bass';
 if(hz<500)return'mid-low';if(hz<2000)return'mid';
 if(hz<8000)return'mid-high';if(hz<20000)return'high';
 if(hz<40000)return'ultrasound';return'hypersound';
}

/* Spectral centroid real-time tracker */
const CENTROID={hz:0,hist:[],drift:0};
function updateCentroid(fd,bHz){
 let num=0,den=0;
 for(let i=1;i<fd.length;i++){const p=Math.pow(10,(fd[i]||-120)/10);num+=i*bHz*p;den+=p;}
 const c=den>0?num/den:0;
 if(CENTROID.hist.length>0)CENTROID.drift=c-CENTROID.hist[CENTROID.hist.length-1];
 CENTROID.hz=c;CENTROID.hist.push(c);if(CENTROID.hist.length>50)CENTROID.hist.shift();
 const cv2=E('centroid-v');if(cv2)cv2.textContent=(c/1000).toFixed(2)+'kHz';
 const cdv=E('centroid-drift');if(cdv)cdv.textContent=(CENTROID.drift>0?'+':'')+CENTROID.drift.toFixed(1)+'Hz/frame';
}

/* Frequency density map per octave */
const OCTAVE_DENSITY={bands:new Map()};
function updateOctaveDensity(){
 OCTAVE_DENSITY.bands.clear();
 freqDB.forEach(e=>{
 // تشديد أكثر: !e.hz يرفض NaN فعلاً (NaN مزيَّفة القيمة)، لكنه لا يرفض Infinity — وكانت
 // Math.pow(2,Math.floor(Math.log2(Infinity))) تُنتج مفتاحاً حرفياً "Infinity→...Hz".
 if(!e.hz||e.hz<=0||!isFinite(e.hz))return;
 const oct=Math.floor(Math.log2(e.hz));
 const k=oct+'→'+(Math.pow(2,oct).toFixed(0)+'-'+Math.pow(2,oct+1).toFixed(0)+'Hz');
 OCTAVE_DENSITY.bands.set(k,(OCTAVE_DENSITY.bands.get(k)||0)+1);
 });
}

/* Negative frequency analytic signal mirror */
function negFreqMirror(hz,energy){
 // تشديد أكثر: !hz يرفض NaN لكن لا يرفض Infinity — بدونه، fBin(-Infinity) يُدرِج مفتاح
 // -Infinity فعلياً داخل freqDB (نفس فئة الخلل المُعالَجة في كل الدوال الأخرى).
 if(!RANGE.negFreqMirror||!hz||!isFinite(hz))return;
 // Mirror detected freq into its negative analytic representation
 // Builds inverse for the -hz component (phase conjugate)
 const negHz=-Math.abs(hz);
 if(freqDB.has(fBin(negHz)))return;
 freqDB.set(fBin(negHz),{hz:negHz,count:1,energy:-energy,firstSeen:Date.now(),
 lastSeen:Date.now(),confirmed:false,cancelled:false,invHz:null,invOk:false,class:2,
 isMirror:true});
 freqFile.totalCap++;
}



/* ── PITCH TRACKER (AMDF) — Average Magnitude Difference Function ── */
const PITCH_AMDF={hz:0,conf:0,hist:[],note:''};
function updatePitchAMDF(td){
 if(!actx)return;
 const win=Math.min(1024,td.length);
 const data=new Float32Array(win);
 for(let i=0;i<win;i++)data[i]=(td[i]-128)/128;
 let bestLag=20,bestVal=Infinity;
 for(let lag=20;lag<win>>1;lag++){
 let sum=0;for(let i=0;i<win-lag;i++)sum+=Math.abs(data[i]-data[i+lag]);
 const v=sum/(win-lag);if(v<bestVal){bestVal=v;bestLag=lag;}
 }
 const sr=actx.sampleRate||44100;
 PITCH_AMDF.hz=bestLag>0?sr/bestLag:0;
 PITCH_AMDF.conf=Math.max(0,1-bestVal*2);
 if(PITCH_AMDF.hz>20&&typeof NOTE_NAMES!=='undefined'){
 const midi=Math.round(12*Math.log2(PITCH_AMDF.hz/440)+69);
 PITCH_AMDF.note=NOTE_NAMES[((midi%12)+12)%12];
 }
 PITCH_AMDF.hist.push(PITCH_AMDF.hz);if(PITCH_AMDF.hist.length>30)PITCH_AMDF.hist.shift();
 const pv=E('pitch-amdf');if(pv)pv.textContent=PITCH_AMDF.hz>10?PITCH_AMDF.hz.toFixed(1)+'Hz '+PITCH_AMDF.note:'—';
}

/* ── HARMONIC-TO-NOISE RATIO (HNR) — signal purity metric ── */
const HNR={val:0,hist:[]};
function updateHNR(fd,bHz){
 if(!fanFreq||fanFreq<1||!fd)return;
 let harmE=0,noiseEn=0;
 for(let i=1;i<fd.length;i++){
 const hz=i*bHz;const pw=Math.pow(10,fd[i]/10);
 let isHarm=false;
 for(let h=1;h<=8;h++){if(Math.abs(hz-fanFreq*h)<bHz*2){isHarm=true;break;}}
 if(isHarm)harmE+=pw;else noiseEn+=pw;
 }
 HNR.val=noiseEn>0?10*Math.log10((harmE+1e-12)/(noiseEn+1e-12)):0;
 HNR.hist.push(HNR.val);if(HNR.hist.length>30)HNR.hist.shift();
 const hv=E('hnr-val');if(hv)hv.textContent=HNR.val.toFixed(1)+'dB';
}

/* ── ROOM MODE DETECTOR — acoustic resonance peak finder ── */
const ROOM_MODES={peaks:[],dominant:0};
const C_SOUND=343;
function detectRoomModes(fd,bHz){
 const peaks=[];
 for(let i=4;i<fd.length-4;i++){
 if(fd[i]>fd[i-1]+2&&fd[i]>fd[i+1]+2&&fd[i]>fd[i-3]+3&&fd[i]>-55){
 peaks.push({hz:i*bHz,db:fd[i],dimM:(C_SOUND/(2*i*bHz)).toFixed(2)});
 }
 }
 peaks.sort((a,b)=>b.db-a.db);
 ROOM_MODES.peaks=peaks.slice(0,6);
 ROOM_MODES.dominant=ROOM_MODES.peaks[0]?ROOM_MODES.peaks[0].hz:0;
 const rv=E('room-mode-v');if(rv)rv.textContent=ROOM_MODES.dominant?(ROOM_MODES.dominant/1000).toFixed(2)+'kHz':'—';
}

/* ── ENVIRONMENT CHANGE DETECTOR — detects acoustic scene transitions ── */
const ENV_CHANGE_D={
 prevSig:[],score:0,events:0,lastChange:0,
 detect(fd){
 const step=Math.max(1,Math.floor(fd.length/16));const sig=[];
 for(let i=0;i<16;i++){
 let s=0;const start=i*step;
 for(let j=start;j<start+step&&j<fd.length;j++)s+=Math.pow(10,fd[j]/10);
 sig.push(s/step);
 }
 if(this.prevSig.length===16){
 let diff=0;
 for(let i=0;i<16;i++)diff+=Math.abs((sig[i]-this.prevSig[i])/(this.prevSig[i]+1e-12));
 this.score=diff/16;
 if(this.score>0.35){
 this.events++;this.lastChange=Date.now();
 logNN(' ENV CHANGE: score='+this.score.toFixed(2));
 if(typeof ENV_FP!=='undefined')ENV_FP.bgFreqs.clear();
 }
 }
 this.prevSig=[...sig];
 const ev=E('env-change-v');if(ev)ev.textContent=this.score.toFixed(3);
 }
};

/* ── ACOUSTIC SIGNATURE — rolling spectral hash fingerprint ── */
const ACOUSTIC_SIG={hash:0,stable:false,stableN:0,prevHash:0};
function updateAcousticSig(fd){
 let h=5381;const step=Math.max(1,Math.floor(fd.length/32));
 for(let i=0;i<32;i++){
 const bin=i*step;const q=Math.max(0,Math.round((fd[Math.min(bin,fd.length-1)]+120)*4));
 h=((h<<5)+h+q)&0x7FFFFFFF;
 }
 ACOUSTIC_SIG.prevHash=ACOUSTIC_SIG.hash;ACOUSTIC_SIG.hash=h;
 ACOUSTIC_SIG.stable=Math.abs(h-ACOUSTIC_SIG.prevHash)<8000;
 if(ACOUSTIC_SIG.stable)ACOUSTIC_SIG.stableN++;else ACOUSTIC_SIG.stableN=0;
 const sv=E('acoustic-sig-v');if(sv)sv.textContent=(h>>>0).toString(16).toUpperCase().padStart(8,'0');
}

/* ── TONAL POWER RATIO — tonal peaks vs broadband noise ── */
const TONAL={ratio:0,hist:[],noiseFloor:0};
function updateTonalRatio(fd,bHz){
 let tonalE=0,noiseE2=0,total=0;
 const W=5;
 for(let i=W;i<fd.length-W;i++){
 const local=[];for(let j=i-W;j<=i+W;j++)local.push(fd[j]);
 local.sort((a,b)=>a-b);const med=local[W];
 const pw=Math.pow(10,fd[i]/10);total+=pw;
 if(fd[i]>med+6)tonalE+=pw;else noiseE2+=pw;
 }
 TONAL.ratio=total>0?tonalE/total:0;
 TONAL.hist.push(TONAL.ratio);if(TONAL.hist.length>60)TONAL.hist.shift();
 const tv=E('tonal-v');if(tv)tv.textContent=(TONAL.ratio*100).toFixed(0)+'%';
}

/* ══ PERMANENT BAN SYSTEM ══
 Three built-in categories pre-loaded at startup, always active.
 Permanent entries in AI_BAN carry {permanent:true} — never auto-unbanned.
 User can toggle categories or add/remove individual freqs from Settings.
══════════════════════════════════════════════════════════════════ */
const PERM_BAN_CATS={
 harmful:{enabled:true,label:'ترددات ضارة', icon:'',desc:'Power-line harmonics & EMF interference'},
 noisy: {enabled:true,label:'ترددات صاخبة', icon:'',desc:'Fan / motor / HVAC ambient noise'},
 mic: {enabled:true,label:'ملتقطة mic', icon:'',desc:'Frequencies always captured by the microphone'},
 thermal:{enabled:true,label:'ترددات حرارية', icon:'',desc:'Frequencies correlated with CPU/GPU/RAM heat — auto-detected'},
 lag: {enabled:true,label:'ترددات تخمّل', icon:'',desc:'Frequencies that cause frame drops & system sluggishness'},
 env: {enabled:false,label:'بيئة خارجية', icon:'',desc:'Frequencies from external environment fingerprint'},
};
// [hz, category, reason]
const DEFAULT_BANNED_FREQS=[
 // ── HARMFUL — power line & EMF harmonics ──
 [50, 'harmful','EMF 50Hz (power line)'],
 [60, 'harmful','EMF 60Hz (power line)'],
 [100, 'harmful','Harmonic 100Hz (50×2)'],
 [120, 'harmful','Harmonic 120Hz (60×2)'],
 [150, 'harmful','Harmonic 150Hz (50×3)'],
 [180, 'harmful','Harmonic 180Hz (60×3)'],
 [200, 'harmful','Harmonic 200Hz (50×4)'],
 [240, 'harmful','Harmonic 240Hz (60×4)'],
 [250, 'harmful','Harmonic 250Hz (50×5)'],
 [300, 'harmful','Harmonic 300Hz (60×5)'],
 [16.67, 'harmful','Railway EMF 16.67Hz'],
 [7.83, 'harmful','Schumann Resonance 7.83Hz'],
 // ── NOISY — fan / motor / HVAC ──
 [120, 'noisy','Fan motor 120Hz'], // may overlap with harmful — bin dedup handles it
 [180, 'noisy','Fan motor 180Hz'],
 [280, 'noisy','Fan hum 280Hz'],
 [340, 'noisy','Fan hum 340Hz'],
 [400, 'noisy','Motor noise 400Hz'],
 [600, 'noisy','HVAC 600Hz'],
 [800, 'noisy','HVAC resonance 800Hz'],
 [1000, 'noisy','HVAC peak 1kHz'],
 [1200, 'noisy','AC noise 1.2kHz'],
 [2000, 'noisy','Ambient noise 2kHz'],
 [3200, 'noisy','Ambient noise 3.2kHz'],
 // ── MIC-CAPTURED — always picked up by mic ──
 [1500, 'mic','Mic self-resonance 1.5kHz'],
 [2500, 'mic','Mic response peak 2.5kHz'],
 [3400, 'mic','Phone mic cutoff 3.4kHz'],
 [5000, 'mic','Mic resonance 5kHz'],
 [6000, 'mic','Mic resonance 6kHz'],
 [8000, 'mic','Mic self-noise 8kHz'],
 [10000, 'mic','Mic harmonic 10kHz'],
 [12000, 'mic','Mic resonance 12kHz'],
 [14000, 'mic','High mic sensitivity 14kHz'],
];

/* ── FREQUENCY FATIGUE — tracks over-detected frequencies for consensus-ban ── */
const FREQ_FATIGUE=new Map(); // bin → {count, lastSeen, score, hz}
function updateFreqFatigue(hz,energy){
 // إصلاح جذري لخلل "0.00Hz" في قائمة الحظر: الشرط القديم !hz&&hz!==0 كان في الواقع
 // يُصرِّح صراحةً بمرور hz=0 (لأن hz!==0 تكون false حين hz=0، فيصبح الشرط كله false ولا
 // يُرجِع)، بينما 0Hz ليس تردداً صوتياً حقيقياً إطلاقاً — فكان أي تجمّع تعب صدفةً عند 0Hz
 // (من حساب قمة طيفية غير مُدقَّق يُؤول لـ0 لاحقاً) يُنتِج حظراً دائماً بعنوان "0.00Hz".
 // التحقّق الصحيح: أي تردد غير محدود القيمة (NaN) أو أقل من 1Hz يُرفَض فوراً.
 if(!hz||hz<1||!isFinite(hz))return;
 const k=fBin(hz);
 if(!FREQ_FATIGUE.has(k))FREQ_FATIGUE.set(k,{count:0,lastSeen:0,score:0,hz});
 const f=FREQ_FATIGUE.get(k);
 const dt=f.lastSeen>0?(Date.now()-f.lastSeen)/1000:0;
 f.count++;f.lastSeen=Date.now();
 f.score=f.score*Math.exp(-dt*0.0004)+energy*0.09;
 if(f.score>75&&!AI_BAN.has(k)){
 AI_BAN.set(k,{reason:'Fatigue ×'+f.count+' (score '+f.score.toFixed(0)+')',
 bannedAt:aiCyc,cycles:0,autoUnbanAt:Infinity,hz:k,permanent:true,category:'env',fatigueScore:f.score});
 if(freqDB.has(k)){freqDB.delete(k);writeFreqFile();} // تشديد: تنظيف FreqDB عند الحظر
 stopActiveInverse(hz); // تشديد: إيقاف أي إبطال صوتي نشط لهذا التردد على السماعة
 deactivateNotch(hz); // تشديد: إزالة أي notch نشط — محضور لا يحتاج كبت إضافي ولا يظهر في NOTCH LIST
 checkInterference(k);
 logNN(' FATIGUE BAN: '+hz.toFixed(1)+'Hz ('+f.score.toFixed(0)+')');
 }
 if(FREQ_FATIGUE.size>800)FREQ_FATIGUE.delete(FREQ_FATIGUE.keys().next().value);
}

/* ── BAN VOTE SYSTEM — multi-method consensus banning ── */
const BAN_VOTE=new Map(); // bin → {votes:{method:weight}, total, hz}
function castBanVote(hz,method,weight=1){
 // إصلاح جذري لخلل "NaNHz" في قائمة الحظر: هذه الدالة لم تكن تتحقّق من hz إطلاقاً —
 // أي تردد NaN (مثلاً من تسمّم مرشّح كالمان KF بعد قيمة غير منتهية) كان يُستخدَم مباشرةً
 // كمفتاح Map (NaN يُقارَن بنفسه بمساواة SameValueZero فيعمل كمفتاح "صالح" تقنياً) وتتراكم
 // له أصوات حتى يتجاوز حدّ الحظر، فيُنشَأ AI_BAN.set(NaN,...) ويظهر حرفياً "NaNHz" في الواجهة.
 if(!hz||hz<1||!isFinite(hz))return;
 const k=fBin(hz);
 if(!BAN_VOTE.has(k))BAN_VOTE.set(k,{votes:{},total:0,hz,firstSeen:Date.now()});
 const v=BAN_VOTE.get(k);
 v.votes[method]=(v.votes[method]||0)+weight;
 v.total=Object.values(v.votes).reduce((a,b)=>a+b,0);
 const numMethods=Object.keys(v.votes).length;
 if(v.total>=6&&numMethods>=2&&!AI_BAN.has(k)){
 const reason='Vote-ban: '+Object.entries(v.votes).map(([m,w])=>m+'×'+w.toFixed(0)).join(', ');
 AI_BAN.set(k,{reason,bannedAt:aiCyc,cycles:0,autoUnbanAt:Infinity,hz:k,permanent:true,category:'env',voteTotal:v.total});
 if(freqDB.has(k)){freqDB.delete(k);writeFreqFile();} // تشديد: تنظيف FreqDB عند الحظر
 stopActiveInverse(hz); // تشديد: إيقاف أي إبطال صوتي نشط لهذا التردد على السماعة
 deactivateNotch(hz); // تشديد: إزالة أي notch نشط — محضور لا يحتاج كبت إضافي ولا يظهر في NOTCH LIST
 checkInterference(k);
 logNN(' VOTE BAN: '+hz.toFixed(1)+'Hz ('+numMethods+' methods, total='+v.total.toFixed(1)+')');
 }
 if(BAN_VOTE.size>500)BAN_VOTE.delete(BAN_VOTE.keys().next().value);
}

/* ── FREQUENCY CLUSTER TRACKER — groups nearby banned frequencies ── */
const FREQ_CLUSTER={groups:[],maxGap:100};
function updateFreqClusters(){
 const banned=Array.from(AI_BAN.keys()).map(Number).filter(v=>!isNaN(v)).sort((a,b)=>a-b);
 const groups=[];let cur=null;
 for(const hz of banned){
 if(!cur){cur={min:hz,max:hz,count:1};}
 else if(hz-cur.max<FREQ_CLUSTER.maxGap){cur.max=hz;cur.count++;}
 else{groups.push(cur);cur={min:hz,max:hz,count:1};}
 }
 if(cur)groups.push(cur);
 FREQ_CLUSTER.groups=groups;
 // ② CHROMA_VEC×FREQ_CLUSTER — Chroma-Seeded Cluster Formation
 if(typeof CHROMA_VEC!=='undefined'&&CHROMA_VEC.conf>0.7){
 const noteHz=440*Math.pow(2,(CHROMA_VEC.dominant-9)/12);
 if(noteHz>20&&!FREQ_CLUSTER.groups.find(g=>Math.abs(((g.min+g.max)/2)-noteHz)<60))
 FREQ_CLUSTER.groups.push({min:noteHz*0.95,max:noteHz*1.05,count:0,chromaSeeded:true});
 }
 const cv=E('cluster-v');if(cv)cv.textContent=groups.length+' مجموعة';
}

/* ── RECURRENCE QUANTIFICATION — detects periodic frequency return ── */
const RECURRENCE={matrix:[],period:0,det:0,maxLen:50};
function updateRecurrence(hz){
 if(!hz||hz<0.1)return;
 const k=fBin(hz);
 RECURRENCE.matrix.push(k);
 if(RECURRENCE.matrix.length>RECURRENCE.maxLen)RECURRENCE.matrix.shift();
 const n=RECURRENCE.matrix.length;let det=0,maxPer=0;
 for(let lag=2;lag<n>>1;lag++){
 let matches=0;
 for(let i=lag;i<n;i++)if(Math.abs(RECURRENCE.matrix[i]-RECURRENCE.matrix[i-lag])<2)matches++;
 const rate=(n-lag)>0?matches/(n-lag):0;
 if(rate>0.6&&lag>maxPer){maxPer=lag;det=rate;}
 }
 RECURRENCE.period=maxPer;RECURRENCE.det=det;
}

/* ══ 8 FREQUENCY CLASSES ══
 C1 ⊕ Positive: phase amp > 0, energy building
 C2 ⊖ Negative: phase amp < 0, energy cancelling
 C3 ∓ Neg→Pos: alternating, starts negative
 C4 ± Pos→Neg: alternating, starts positive
 C5 ✓ Mic-Detectable: 20Hz ≤ hz ≤ Nyquist/2
 C6 ✗ Mic-Invisible: hz < 1Hz OR hz > Nyquist
 C7 ✓ Spk-Emittable: 0.01Hz ≤ hz ≤ Nyquist
 C8 ✗ Spk-Blocked: hz > Nyquist (hardware limit)
══════════════════════════════════ */
/* ══════════════════════════════════
 16-FREQUENCY CLASS SYSTEM (expanded)
 C1-C8: original polarity/range classes
 C9-C16: sub-infrasound, infrasound, ultrasound,
 hypersound, harmonic series, thermal-correlated,
 lag-correlated, environmental signature
══════════════════════════════════ */
