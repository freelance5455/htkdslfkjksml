/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 00-core-state-metrics.js
 الحالة العامة (E/app/isOn) + المقاييس الأساسية للإشارة (zero-cross, crest, envelope, spectral flux/moments)
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */

'use strict';
const E=id=>document.getElementById(id);
const app=E('app');
// اهتزاز: يستخدم Vibrator الأصلي في ZERO-v25 (ZeroAndroid.vibrate) بدل Vibration API
// الخاصة بالمتصفح، والتي غير مدعومة بشكل موثوق داخل WebView — احتياط للمتصفح فقط
function zVibrate(pat){
 if(typeof ZeroAndroid!=='undefined'&&ZeroAndroid.vibrate){
 try{ZeroAndroid.vibrate(Array.isArray(pat)?pat[0]:pat);}catch(e){}
 return;
 }
 if(navigator.vibrate)navigator.vibrate(pat);
}

// ── إغلاق الفراغات (المشروع بالكامل) ──
// المشكلة ①: `.app` كانت height:100vh ثابتة. 100vh تُحسَب مرة واحدة من ارتفاع نافذة العرض
// (layout viewport) الأولي ولا تتحدّث تلقائياً مع تغيّر الارتفاع الفعلي المرئي لاحقاً — وهذا
// التطبيق يستخدم بالفعل windowSoftInputMode="adjustResize" مع سمة Fullscreen (لا أشرطة نظام)،
// وبه حقول إدخال حقيقية تستدعي لوحة المفاتيح (#termCmd في لوحة الطرفية، #execInp). فتح لوحة
// المفاتيح على WebView أندرويد يُغيّر الارتفاع المرئي الفعلي دون أن يُعاد حساب 100vh دوماً بشكل
// موثوق عبر كل إصدارات WebView — ما يترك فراغاً فارغاً (بلون الخلفية خلف .app) أسفل أو أعلى
// الواجهة عند فتح/إغلاق لوحة المفاتيح، أو عند أي تغيّر مفاجئ في نافذة العرض (تدوير الشاشة، إلخ).
//
// المشكلة ②: كل النوافذ المنبثقة من الأسفل (.pnl: bSheet/aiPanel/zpPanel/termPanel/menuPanel/
// filesPanel/devPanel)، الستارة الخلفية (.ovl)، اللوحة الجانبية (.ppnl)، وتنبيهات "توست" العائمة
// (achToast وتلميح الاكتشاف) كلها position:fixed مع bottom:0 (أو إزاحة ثابتة من الأسفل) — وهذه
// أيضاً تُحسَب نسبةً لحاوية التموضع الأولية (initial containing block) التي لا تتقلّص بالضرورة
// مع تقلّص المساحة المرئية الحقيقية عند فتح لوحة المفاتيح. النتيجة: قد تنزلق هذه العناصر جزئياً
// خلف لوحة المفاتيح (فراغ/تغطية غير مرئية) بدل الجلوس فوقها تماماً — أخطرها لوحة الطرفية نفسها،
// إذ يُخفي هذا حقل الإدخال (#termCmd) الذي استدعى لوحة المفاتيح أصلاً خلفها.
//
// الإصلاح: تتبّع الارتفاع الفعلي عبر VisualViewport API (الأدق لتغيّرات لوحة المفاتيح، مدعوم في
// WebView الحديث) مع احتياط window.innerHeight للأجهزة/الإصدارات الأقدم، وكتابة خاصيتي CSS
// مخصّصتين: (--app-h) الارتفاع الحقيقي الكامل تقرأه .app بدل 100vh الثابتة، و(--vv-bottom-inset)
// المسافة الفعلية بين حافة نافذة العرض التخطيطية السفلية وحافة المساحة المرئية الحقيقية السفلية
// (تساوي صفراً في كل الحالات الطبيعية، ولا تكبر إلا عند تباعد فعلي حقيقي) — تقرأها كل العناصر
// المثبَّتة أسفل الشاشة بدل bottom:0/88px الثابتة، فتبقى دوماً فوق المساحة المرئية الحقيقية تماماً
// ولا يظهر أي فراغ أو تغطية في أي نافذة من نوافذ المشروع.
function _closeGaps(){
 const vv=window.visualViewport;
 const h=(vv&&vv.height)||window.innerHeight;
 if(h>0)document.documentElement.style.setProperty('--app-h',h+'px');
 const bottomInset=vv?Math.max(0,window.innerHeight-(vv.height+vv.offsetTop)):0;
 document.documentElement.style.setProperty('--vv-bottom-inset',bottomInset+'px');
}
_closeGaps();
if(window.visualViewport){
 window.visualViewport.addEventListener('resize',_closeGaps);
 window.visualViewport.addEventListener('scroll',_closeGaps);
}
window.addEventListener('resize',_closeGaps);
window.addEventListener('orientationchange',()=>setTimeout(_closeGaps,80));

/* ══ PARAMS ══ */
const P={delay:20,harmonics:8,alpha:1.5,beta:.01,transThresh:3.0,mu:.02,sens:70,useCL:true,useEVP:true,useEMF:true,useInv:true,useLearn:true,useSF:{inf:true,ult:true,phf:true,sub:true,pie:true},useC:{c1:true,c2:true,c3:true,c4:true,c5:true,c6:true,c7:true,c8:true}};
let FREQ_THRESH=3;

/* ══ AUDIO STATE ══ */
let isOn=false,isRun=false,sOpen=false,pOpen=false,aOpen=false,tOpen=false,zpOpen=false,dmOpen=false,menuOpen=false,filesOpen=false,maskOpen=false,physOpen=false,aboutOpen=false,privacyOpen=false,loopDiagOpen=false;
let dmTimer=null,dmCpuHist=[],dmRamHist=[];
let actx=null,micStr=null,micSrc=null,ana=null;
let silOscs={};
let fanFreq=0,fanE=0,noiseE=0,sharpE=0,evpE=0,evpHz=5,emfE=0;
let silSc=0,aiCyc=0,aiCon=0,loopN=0,loopE=1,prevLE=1;
let hlPh=0,prevX=0,fxMSE=0;
const FX_N=32; let fxW=new Array(FX_N).fill(0),fxXb=new Array(FX_N).fill(0);
const KF={x:[0,0],P:[1,1],Q:[.01,.1],R:5,init:false};
let nFloor=null;
const COH_F=[5,10,20,50,100,200,500,1000,2000,4000,8000,16000];
const cSxx=new Float32Array(COH_F.length),cSyy=new Float32Array(COH_F.length);
const cSxy=new Float32Array(COH_F.length),cV=new Float32Array(COH_F.length);
const DRV={phase:180,amp:1.0,wS:.5,wE:.3,wM:.2};
let iLv=0,uLv=0,pLv=0,bLv=0,eLv=0;
let aT=null,dT=null,cT=null,lT=null,nnT=null;
/* AI EXEC mode — no chat variables */
let learnN=0,bestSil=0;
let drawId=null;

/* ══ ANTI-IDLE SYSTEM ══
 Prevents Android WebView from throttling:
 - Adaptive FFT size scaling (keeps up with audio load)
 - AudioContext resume on visibility restore
 - Silent poke oscillator (sub-Hz keeps audio thread alive)
 - Wake-lock heartbeat counter
 - Micro-interval sentinel (detects & corrects interval drift)
══════════════════════════════════════════════ */
const ANTI_IDLE={
 lastFrame:0, frameTimes:[], avgFrame:16.7,
 drift:0, // interval drift accumulator (ms)
 pokeOsc:null, pokeGain:null,
 fftSizeIdx:0, fftSizes:[4096,8192,16384,32768],
 heartbeat:0, lastHb:0,
 lagFreqs:new Map(), // hz→{lagCount,totalLag} — tracks which freqs cause lag
};

// Adaptive FFT: downscale when frame time > 40ms (heavy load)
function adaptFFT(){
 if(!ana||!actx)return;
 const ft=ANTI_IDLE.avgFrame;
 if(ft>40&&ANTI_IDLE.fftSizeIdx>0){
 ANTI_IDLE.fftSizeIdx--;
 ana.fftSize=ANTI_IDLE.fftSizes[ANTI_IDLE.fftSizeIdx];
 logNN(' FFT downscaled→'+ANTI_IDLE.fftSizes[ANTI_IDLE.fftSizeIdx]+' (load '+ft.toFixed(0)+'ms)');
 }else if(ft<12&&ANTI_IDLE.fftSizeIdx<ANTI_IDLE.fftSizes.length-1){
 ANTI_IDLE.fftSizeIdx++;
 ana.fftSize=ANTI_IDLE.fftSizes[ANTI_IDLE.fftSizeIdx];
 logNN(' FFT upscaled→'+ANTI_IDLE.fftSizes[ANTI_IDLE.fftSizeIdx]+' (load '+ft.toFixed(0)+'ms)');
 }
}

// Anti-idle poke oscillator (0.07 Hz — inaudible, keeps audio thread running)
function startAudioPoke(){
 if(!actx||ANTI_IDLE.pokeOsc)return;
 try{
 ANTI_IDLE.pokeOsc=actx.createOscillator();
 ANTI_IDLE.pokeGain=actx.createGain();
 ANTI_IDLE.pokeOsc.frequency.value=0.07;
 ANTI_IDLE.pokeGain.gain.value=0.0001; // effectively silent
 ANTI_IDLE.pokeOsc.connect(ANTI_IDLE.pokeGain);
 ANTI_IDLE.pokeGain.connect(actx.destination);
 ANTI_IDLE.pokeOsc.start();
 logNN(' Anti-idle poke osc started (0.07Hz)');
 }catch(e){logNN(' Poke osc fail: '+e.message);}
}

function stopAudioPoke(){
 if(ANTI_IDLE.pokeOsc){try{ANTI_IDLE.pokeOsc.stop();ANTI_IDLE.pokeOsc.disconnect();}catch(e){}ANTI_IDLE.pokeOsc=null;ANTI_IDLE.pokeGain=null;}
}

// AudioContext resume on tab/app visibility restore
document.addEventListener('visibilitychange',()=>{
 if(document.visibilityState==='visible'&&actx&&actx.state==='suspended'){
 actx.resume().then(()=>{logNN(' AudioContext resumed on focus');});
 }
});

// Anti-sleep ping every 15s
setInterval(()=>{
 if(!actx||!isRun)return;
 if(actx.state==='suspended')actx.resume();
 ANTI_IDLE.heartbeat++;
 const now=performance.now();
 if(ANTI_IDLE.lastHb>0){const gap=now-ANTI_IDLE.lastHb;if(gap>18000)logNN(' Heartbeat gap: '+(gap/1000).toFixed(1)+'s (system was idle)');}
 ANTI_IDLE.lastHb=now;
 // Spectral entropy computation (between speed & bipolar ideas)
 if(ana){
 const fd2=new Float32Array(ana.frequencyBinCount);ana.getFloatFrequencyData(fd2);
 let se=0,sp=0;
 for(let i=5;i<fd2.length;i++){const p=Math.pow(10,fd2[i]/10);sp+=p;}
 if(sp>0){for(let i=5;i<fd2.length;i++){const p=Math.pow(10,fd2[i]/10)/sp;if(p>1e-12)se-=p*Math.log2(p);}}
 const maxSE=Math.log2(fd2.length-5);
 const seNorm=Math.min(1,se/maxSE);
 const ef=E('spec-entropy-fill');if(ef){ef.style.width=(seNorm*100)+'%';}
 const ev=E('spec-entropy-v');if(ev)ev.textContent=seNorm.toFixed(3);
 // High entropy = wideband noise → boost Wiener
 if(seNorm>0.85&&isRun){P.alpha=Math.min(3.5,P.alpha*1.01);}
 }
},15000);


/* ── JITTER ANALYZER — frame-time variance & spike detector ── */
const JITTER={
 hist:[],maxLen:80,variance:0,stdDev:0,spikes:0,lastT:0,
 update(){
 const now=performance.now();
 if(this.lastT>0){
 const dt=now-this.lastT;
 this.hist.push(dt);if(this.hist.length>this.maxLen)this.hist.shift();
 const mean=this.hist.reduce((a,b)=>a+b,0)/this.hist.length;
 const v=this.hist.reduce((a,b)=>a+(b-mean)**2,0)/this.hist.length;
 this.variance=v;this.stdDev=Math.sqrt(v);
 this.spikes=this.hist.filter(x=>x>mean+2*this.stdDev).length;
 }
 this.lastT=now;
 }
};

/* ── ZERO CROSSING RATE — waveform texture, voiced/unvoiced ── */
const ZCRATE={val:0,hist:[],peak:0};
function updateZeroCross(td){
 let zc=0;
 for(let i=1;i<td.length;i++){if((td[i]-128)*(td[i-1]-128)<0)zc++;}
 ZCRATE.val=zc/td.length;
 ZCRATE.hist.push(ZCRATE.val);if(ZCRATE.hist.length>80)ZCRATE.hist.shift();
 ZCRATE.peak=Math.max(...ZCRATE.hist,0);
 const v=E('zcr-val');if(v)v.textContent=ZCRATE.val.toFixed(4);
}

/* ── CREST FACTOR — peak:RMS impulsiveness ratio ── */
const CREST={val:0,hist:[]};
function updateCrest(td){
 const vals=Array.from(td).map(x=>Math.abs(x-128)/128);
 const peak=vals.reduce((a,b)=>b>a?b:a,0)+1e-9;
 const rms=Math.sqrt(vals.reduce((a,b)=>a+b*b,0)/vals.length);
 CREST.val=rms>0?peak/rms:1;
 CREST.hist.push(CREST.val);if(CREST.hist.length>80)CREST.hist.shift();
 const v=E('crest-val');if(v)v.textContent=CREST.val.toFixed(2);
}

/* ── POLARITY HISTORY — positive/negative amplitude balance ── */
const POLAR_HIST={
 posCount:0,negCount:0,flipCount:0,lastPol:0,hist:[],maxLen:300,
 update(amp){
 const pol=amp>=0?1:-1;
 if(this.lastPol!==0&&this.lastPol!==pol)this.flipCount++;
 if(pol>0)this.posCount++;else this.negCount++;
 this.lastPol=pol;
 this.hist.push(pol);if(this.hist.length>this.maxLen)this.hist.shift();
 },
 get ratio(){const t=this.posCount+this.negCount;return t>0?this.negCount/t:0.5;}
};

/* ── ENERGY ENVELOPE TRACKER — amplitude envelope extraction ── */
const ENV_ENVELOPE={val:0,hist:[],attack:0.02,release:0.998};
function updateEnvelope(td){
 let peak=0;
 for(let i=0;i<td.length;i++){const a=Math.abs((td[i]-128)/128);if(a>peak)peak=a;}
 ENV_ENVELOPE.val=ENV_ENVELOPE.val>peak
 ?ENV_ENVELOPE.val*ENV_ENVELOPE.release
 :ENV_ENVELOPE.val+(peak-ENV_ENVELOPE.val)*ENV_ENVELOPE.attack;
 ENV_ENVELOPE.hist.push(ENV_ENVELOPE.val);
 if(ENV_ENVELOPE.hist.length>200)ENV_ENVELOPE.hist.shift();
}

/* ── SPECTRAL FLUX — between-frame energy change tracker ── */
let _prevFD=null;
const SPEC_FLUX={val:0,hist:[],peak:0};
function updateSpecFlux(fd){
 if(_prevFD&&_prevFD.length===fd.length){
 let flux=0;
 for(let i=0;i<fd.length;i++){const d=Math.pow(10,fd[i]/10)-Math.pow(10,_prevFD[i]/10);flux+=d>0?d*d:0;}
 SPEC_FLUX.val=Math.sqrt(flux/fd.length);
 SPEC_FLUX.hist.push(SPEC_FLUX.val);if(SPEC_FLUX.hist.length>100)SPEC_FLUX.hist.shift();
 SPEC_FLUX.peak=Math.max(...SPEC_FLUX.hist,0.001);
 }
 _prevFD=new Float32Array(fd);
 const flv=E('spec-flux-v');if(flv)flv.textContent=SPEC_FLUX.val.toFixed(4);
}




/* ── SPECTRAL MOMENTS — mean/variance/skewness/kurtosis ── */
const SMOM={mean:0,var:0,skew:0,kurt:0};
function updateSpectralMoments(fd,bHz){
 let total=0;
 for(let i=1;i<fd.length;i++)total+=Math.pow(10,fd[i]/10);
 if(total<1e-12)return;
 let m1=0;
 for(let i=1;i<fd.length;i++)m1+=i*bHz*Math.pow(10,fd[i]/10)/total;
 let m2=0,m3=0,m4=0;
 for(let i=1;i<fd.length;i++){
 const p=Math.pow(10,fd[i]/10)/total,d=i*bHz-m1;
 m2+=p*d*d;m3+=p*d*d*d;m4+=p*d*d*d*d;
 }
 SMOM.mean=m1;SMOM.var=m2;
 SMOM.skew=m2>0?m3/Math.pow(m2,1.5):0;
 SMOM.kurt=m2>0?m4/(m2*m2)-3:0;
 const sv=E('smom-v');if(sv)sv.textContent='μ='+(m1/1000).toFixed(1)+'k K='+SMOM.kurt.toFixed(1);
}

/* ── CHROMA VECTOR — 12 pitch-class energy distribution ── */
const NOTE_NAMES=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const CHROMA_VEC={vec:new Float32Array(12),dominant:0,conf:0,hist:[]};
