/* ══════════════════════════════════════════════════════════════════
 ZERO AI v25 — 02-classification-thermal-nn.js
 تصنيف الترددات (16 فئة) + مراقبة الحرارة + الشبكة العصبية الأساسية (NN) + Hebbian/TD learning
 ──────────────────────────────────────────────────────────────────
 جزء من إعادة الهيكلة المعمارية (سبتمبر 2026): هذا الملف كان قطعة
 متتالية من ملف index.html الواحد الضخم (+11000 سطر)، فُصلت آلياً
 بلا أي تغيير منطقي أو إعادة ترتيب — يُحمَّل بترتيب صارم عبر وسوم
 <script src>في index.html، وكل الدوال/المتغيرات تبقى في نفس
 النطاق العام المشترك (window) تماماً كما كانت من قبل.
 ══════════════════════════════════════════════════════════════════ */
const FC={c1:0,c2:0,c3:0,c4:0,c5:0,c6:0,c7:0,c8:0,
 c9:0,c10:0,c11:0,c12:0,c13:0,c14:0,c15:0,c16:0};

const CLS16_META=[
 {id:1, label:'C1⊕', name:'Positive Energy', color:'#8f8f8f', desc:'amp>0, phase 0-90°, building energy'},
 {id:2, label:'C2⊖', name:'Negative Energy', color:'#7c7c7c', desc:'amp<0 or phase 180°, cancelling energy'},
 {id:3, label:'C3∓', name:'Neg→Pos Bipolar', color:'#9c9c9c', desc:'alternating, starts negative'},
 {id:4, label:'C4±', name:'Pos→Neg Bipolar', color:'#828282', desc:'alternating, starts positive'},
 {id:5, label:'C5✓', name:'Mic-Detectable', color:'#959595', desc:'20Hz ≤ hz ≤ Nyquist/2'},
 {id:6, label:'C6✗', name:'Mic-Invisible', color:'#929292', desc:'hz<1Hz or hz>Nyquist'},
 {id:7, label:'C7✓', name:'Speaker-Emittable', color:'#797979', desc:'0.01Hz ≤ hz ≤ Nyquist'},
 {id:8, label:'C8✗', name:'Speaker-Blocked', color:'#929292', desc:'hz > Nyquist (hardware limit)'},
 {id:9, label:'C9', name:'Sub-Infrasound', color:'#818181', desc:'hz < 0.01Hz — seismic/geological'},
 {id:10,label:'C10𝒊', name:'Infrasound', color:'#6d6d6d', desc:'0.01-20Hz — below hearing'},
 {id:11,label:'C11↑', name:'Ultrasound', color:'#8b8b8b', desc:'20kHz-200kHz — above hearing'},
 {id:12,label:'C12∞', name:'Hypersound', color:'#828282', desc:'200kHz+ — molecular/thermal domain'},
 {id:13,label:'C13', name:'Harmonic Series', color:'#cecece', desc:'Part of detected harmonic ladder'},
 {id:14,label:'C14', name:'Thermal-Correlated', color:'#6a6a6a', desc:'Detected when device temp rises'},
 {id:15,label:'C15', name:'Lag-Correlated', color:'#9c9c9c', desc:'Detected during frame drops > 50ms'},
 {id:16,label:'C16', name:'Environmental', color:'#969696', desc:'Persistent background from env fingerprint'},
];

function classifyFreq(hz,amp,phase,nyq){
 // First run 16-class system, return primary class
 return classifyFreq16(hz,amp,phase,nyq);
}

function classifyFreq16(hz,amp,phase,nyq){
 const micLo=20,spkHi=nyq;
 const isPos=amp>=0;
 const altPhase=Math.abs(Math.sin(phase));
 const absHz=Math.abs(hz);

 // ── C9: Sub-Infrasound (< 0.01 Hz)
 if(absHz<0.01){FC.c9++;return 9;}
 // ── C10: Infrasound (0.01-20 Hz)
 if(absHz>=0.01&&absHz<20){FC.c10++;return 10;}
 // ── C11: Ultrasound (20kHz-200kHz)
 if(absHz>=20000&&absHz<200000){FC.c11++;return 11;}
 // ── C12: Hypersound (200kHz+)
 if(absHz>=200000){FC.c12++;return 12;}
 // ── C13: Harmonic series member
 if(HARMONICS.series.some(s=>Math.abs(s.hz-absHz)<(absHz*0.02))){FC.c13++;return 13;}
 // ── C14: Thermal-correlated (if temp rising and freq was detected then)
 if(THERMAL.rising&&THERMAL.correlFreqs.has(fBin(hz))){FC.c14++;return 14;}
 // ── C15: Lag-correlated
 if(ANTI_IDLE.lagFreqs.has(fBin(hz))&&(ANTI_IDLE.lagFreqs.get(fBin(hz)).lagCount||0)>=3){FC.c15++;return 15;}
 // ── C16: Environmental background
 if(ENV_FP.bgFreqs.has(fBin(hz))){FC.c16++;return 16;}
 // ── Original C1-C8
 if(isPos&&Math.cos(phase)>0.5){FC.c1++;RANGE.posE+=Math.abs(amp);return 1;}
 if(!isPos||Math.abs(Math.cos(phase)-(-1))<0.3){FC.c2++;RANGE.negE+=Math.abs(amp);return 2;}
 if(altPhase>0.7&&!isPos){FC.c3++;RANGE.negE+=Math.abs(amp);return 3;}
 if(altPhase>0.7&&isPos){FC.c4++;RANGE.posE+=Math.abs(amp);return 4;}
 if(absHz>=micLo&&absHz<=nyq/2){FC.c5++;return 5;}
 if(absHz<1||absHz>nyq){FC.c6++;return 6;}
 if(absHz>=0.01&&absHz<=spkHi){FC.c7++;return 7;}
 FC.c8++;return 8;
}


/* ══════════════════════════════════════════════════════════
 THERMAL MONITORING SYSTEM
 CPU: frame-time proxy (long frames = CPU hot)
 GPU: AudioContext baseLatency proxy
 RAM: performance.memory if available
 Freq correlation: which Hz values appear when temp rises
 Auto-ban: frequencies causing sustained heat are banned
 60-second rolling history per component
 Component stress index: aggregate thermal pressure score
══════════════════════════════════════════════════════════ */
const THERMAL={
 cpu:{val:0,hist:[],unit:'°C*',label:'CPU'}, // * = estimated via frame time
 gpu:{val:0,hist:[],unit:'°C*',label:'GPU'}, // estimated via AudioContext latency
 ram:{val:0,hist:[],unit:'%',label:'RAM'}, // from performance.memory
 dsp:{val:0,hist:[],unit:'°C*',label:'DSP'}, // AudioContext worklet stress
 stress:0, // 0-100 aggregate stress index
 rising:false, // true when any component trending up
 correlFreqs:new Map(), // hz→{heatCount,totalHeat} — freqs seen during heat
 thermBanned:new Set(), // hz values auto-banned due to thermal correlation
 histLen:360, // 60s at 6/s samples
 lastSample:0,
 energyEff:new Map(), // hz→energy-efficiency score (lower=worse)
};

/* BETWEEN thermal & ban-redesign:
 Thermal prediction model — rolling linear regression on history */
const THERM_PRED={
 predict(hist,steps=30){
 if(hist.length<5)return null;
 const n=Math.min(hist.length,30);const d=hist.slice(-n);
 let sx=0,sy=0,sxy=0,sx2=0;
 for(let i=0;i<n;i++){sx+=i;sy+=d[i];sxy+=i*d[i];sx2+=i*i;}
 const slope=(n*sxy-sx*sy)/(n*sx2-sx*sx||1);
 const intercept=(sy-slope*sx)/n;
 return intercept+slope*(n+steps-1);
 }
};

function sampleThermal(){
 const now=performance.now();
 if(now-THERMAL.lastSample<167)return; // ~6 samples/sec
 THERMAL.lastSample=now;
 const HIST=THERMAL.histLen;

 // ── CPU proxy: exponential moving average of frame time
 const ft=ANTI_IDLE.avgFrame;
 // Rough mapping: <8ms≈ambient, 16ms≈load, >33ms≈hot, >50ms≈thermal throttle
 const cpuEst=Math.max(20,Math.min(95, 20 + ft*1.5));
 THERMAL.cpu.val=THERMAL.cpu.val*0.92+cpuEst*0.08;
 THERMAL.cpu.hist.push(THERMAL.cpu.val);if(THERMAL.cpu.hist.length>HIST)THERMAL.cpu.hist.shift();

 // ── GPU/DSP proxy: AudioContext baseLatency (high latency = DSP overloaded)
 if(actx){
 const lat=(actx.baseLatency||0.005)*1000; // ms
 const gpuEst=Math.max(20,Math.min(90, 20 + lat*8));
 THERMAL.gpu.val=THERMAL.gpu.val*0.9+gpuEst*0.1;
 THERMAL.gpu.hist.push(THERMAL.gpu.val);if(THERMAL.gpu.hist.length>HIST)THERMAL.gpu.hist.shift();
 // DSP = AudioContext outputLatency proxy
 const dspLat=(actx.outputLatency||0.01)*1000;
 THERMAL.dsp.val=Math.max(20,Math.min(85, 20+dspLat*5));
 THERMAL.dsp.hist.push(THERMAL.dsp.val);if(THERMAL.dsp.hist.length>HIST)THERMAL.dsp.hist.shift();
 }

 // ── RAM: performance.memory (Chrome/Android WebView)
 if(performance.memory){
 const used=performance.memory.usedJSHeapSize;
 const total=performance.memory.jsHeapSizeLimit||performance.memory.totalJSHeapSize||1;
 THERMAL.ram.val=Math.round((used/total)*100);
 THERMAL.ram.hist.push(THERMAL.ram.val);if(THERMAL.ram.hist.length>HIST)THERMAL.ram.hist.shift();
 }

 // ── Stress index
 THERMAL.stress=Math.round(
 (THERMAL.cpu.val - 20) * 0.4 +
 (THERMAL.gpu.val - 20) * 0.3 +
 THERMAL.ram.val * 0.15 +
 (THERMAL.dsp.val - 20) * 0.15
 );
 THERMAL.stress=Math.max(0,Math.min(100,THERMAL.stress));

 // ── Rising trend detection (last 30 samples vs previous 30)
 const cpuH=THERMAL.cpu.hist;
 if(cpuH.length>=60){
 const recent=cpuH.slice(-30).reduce((a,b)=>a+b,0)/30;
 const older=cpuH.slice(-60,-30).reduce((a,b)=>a+b,0)/30;
 THERMAL.rising=(recent-older)>1.5;
 }

 // ── Frequency thermal correlation
 if(THERMAL.rising&&fanFreq>0){
 const bin=fBin(fanFreq);
 if(!THERMAL.correlFreqs.has(bin))THERMAL.correlFreqs.set(bin,{heatCount:0,totalHeat:0,hz:fanFreq});
 const tc=THERMAL.correlFreqs.get(bin);
 tc.heatCount++;tc.totalHeat+=THERMAL.stress;
 // Auto-ban if this freq has caused heat 8+ times
 if(tc.heatCount>=8&&!THERMAL.thermBanned.has(bin)){
 THERMAL.thermBanned.add(bin);
 AI_BAN.set(bin,{reason:'Thermal: '+tc.heatCount+'× heat events (stress '+THERMAL.stress+')',
 // تشديد (إصلاح خلل): autoUnbanAt يجب أن تكون Infinity كبقية مسارات الحظر الدائم —
 // كانت -1 هنا خطأً، وبما أن execCyc يبدأ من 0 ولا ينخفض أبداً فإن execCyc>=-1 صحيحة
 // دائماً، ما يجعل FREQ_GATE يحذف هذا الحظر الحراري فوراً في أول تمريرة تالية له
 // (خلال ثوانٍ)، رغم كونه permanent:true ومُصمَّماً ليبقى — يُبطل الحماية الحرارية كلياً
 bannedAt:aiCyc,cycles:0,autoUnbanAt:Infinity,hz:bin,permanent:true,category:'thermal',
 heatScore:Math.round(tc.totalHeat/tc.heatCount)});
 checkInterference(bin);
 logNN(' THERMAL BAN: '+fanFreq.toFixed(1)+'Hz (heat×'+tc.heatCount+', stress='+THERMAL.stress+')');
 }
 }

 // ── Energy efficiency score
 if(fanFreq>0&&fanE>0){
 const bin=fBin(fanFreq);
 if(!THERMAL.energyEff.has(bin))THERMAL.energyEff.set(bin,{hz:fanFreq,score:50,samples:0});
 const ef=THERMAL.energyEff.get(bin);
 // Low efficiency = high thermal stress per unit of energy benefit
 const eff=Math.max(0,100-(THERMAL.stress * fanE * 2));
 ef.score=ef.score*0.95+eff*0.05;ef.samples++;
 }

 // ── Update thermal UI
 updateThermalUI();
}

function updateThermalUI(){
 const parts=[
 {id:'therm-cpu',val:THERMAL.cpu.val,unit:THERMAL.cpu.unit,max:95},
 {id:'therm-gpu',val:THERMAL.gpu.val,unit:THERMAL.gpu.unit,max:90},
 {id:'therm-ram',val:THERMAL.ram.val,unit:THERMAL.ram.unit,max:100},
 {id:'therm-dsp',val:THERMAL.dsp.val,unit:THERMAL.dsp.unit,max:85},
 {id:'therm-str',val:THERMAL.stress,unit:'%',max:100},
 ];
 parts.forEach(p=>{
 const pct=Math.min(1,p.val/p.max);
 const cls=pct<0.5?'cold':pct<0.75?'warm':'hot';
 const bar=E(p.id+'-bar');if(bar){bar.style.width=(pct*100)+'%';bar.className='therm-bar '+cls;}
 const val=E(p.id+'-val');if(val){val.textContent=p.val.toFixed(0)+p.unit;val.className='therm-val '+cls;}
 });
 // Prediction
 const pred=THERM_PRED.predict(THERMAL.cpu.hist,60);
 const pv=E('therm-pred');if(pv)pv.textContent=pred?pred.toFixed(0)+'°C* (predicted)':'—';
 // Thermal banned count
 const tb=E('therm-ban-cnt');if(tb)tb.textContent=THERMAL.thermBanned.size+' thermal bans';
 // Stress ring on main circle
 const sr=E('stress-ring');if(sr){sr.style.opacity=THERMAL.stress>30?'1':'0';
 sr.style.color=THERMAL.stress>70?'#7c7c7c':THERMAL.stress>40?'#9c9c9c':'#c4c4c4';}
}

// Sample thermal at 6 Hz
setInterval(sampleThermal,167);


/* ══════════════════════════════════════════════════════════
 ENVIRONMENTAL FINGERPRINT ENGINE
 External: persistent background frequencies captured over time
 Internal: OS/system load fingerprint (frame times, memory, latency)
 AI: monitors which frequencies cause sluggishness
 Anti-entropy: correlates environment changes with freq changes
══════════════════════════════════════════════════════════ */
const ENV_FP={
 bgFreqs:new Map(), // hz→{count,firstSeen,lastSeen} — persistent env freqs
 internalLoad:{frameScore:0,memScore:0,latScore:0}, // internal system fingerprint
 external:{freqs:[],fingerprint:'',noiseType:'unknown'}, // external acoustic env
 slugFreqs:new Map(), // hz→{slugCount,totalFrameTime} — lag-causing freqs
 envChanged:false,
 lastFingerprint:'',
 sampleCount:0,
};

/* كل حضر دائم — لا يوجد مؤقت — لا تصعيد مطلوب */

/* Ban pattern recognition — detects band bans */
const BAN_PATTERNS={
 bands:[], // {minHz,maxHz,density,isBand}
 detect(){
 const sorted=[...AI_BAN.keys()].sort((a,b)=>a-b);
 const bands=[];let start=sorted[0],prev=sorted[0],count=1;
 for(let i=1;i<sorted.length;i++){
 if(sorted[i]-prev<prev*0.15){count++;prev=sorted[i];}
 else{if(count>=3)bands.push({minHz:start,maxHz:prev,count});start=sorted[i];prev=sorted[i];count=1;}
 }
 if(count>=3)bands.push({minHz:start,maxHz:prev,count});
 BAN_PATTERNS.bands=bands;
 if(bands.length)logNN(' Ban band: '+bands[0].minHz.toFixed(0)+'-'+bands[0].maxHz.toFixed(0)+'Hz ('+bands[0].count+' freqs)');
 return bands;
 }
};

function updateEnvFingerprint(fd,bHz){
 ENV_FP.sampleCount++;
 // Compute acoustic environment fingerprint (top-5 persistent peaks)
 if(ENV_FP.sampleCount%60!==0)return; // every 10s at 6fps
 const peaks=[];
 for(let i=2;i<Math.min(fd.length,4096);i++){
 if(fd[i]>fd[i-1]&&fd[i]>fd[i+1]&&fd[i]>-50){peaks.push({hz:i*bHz,dB:fd[i]});}
 }
 peaks.sort((a,b)=>b.dB-a.dB);
 const top5=peaks.slice(0,5);
 top5.forEach(p=>{
 const k=fBin(p.hz);
 if(!ENV_FP.bgFreqs.has(k))ENV_FP.bgFreqs.set(k,{hz:p.hz,count:0,firstSeen:Date.now(),lastSeen:Date.now()});
 const e=ENV_FP.bgFreqs.get(k);e.count++;e.lastSeen=Date.now();
 });
 // Purge stale env freqs (not seen in last 5 minutes)
 const now=Date.now();
 ENV_FP.bgFreqs.forEach((v,k)=>{if(now-v.lastSeen>300000)ENV_FP.bgFreqs.delete(k);});
 // Fingerprint string
 const fp=top5.map(p=>p.hz.toFixed(0)).join(',');
 if(fp!==ENV_FP.lastFingerprint){
 ENV_FP.envChanged=true;ENV_FP.lastFingerprint=fp;
 logNN(' Env fingerprint: ['+fp+']Hz');
 }
 // Noise type classification
 const spread=top5.length>1?(top5[top5.length-1].hz-top5[0].hz):0;
 ENV_FP.external.noiseType=spread>5000?'wideband':spread>500?'narrowband':'tonal';
 const ntv=E('env-noise-type');if(ntv)ntv.textContent=ENV_FP.external.noiseType;
}

/* Sluggishness monitor — correlation of detected freqs with frame drops */
let _lastFrameCheck=0;
function monitorSlugFreqs(){
 const now=performance.now();const ft=now-_lastFrameCheck;
 _lastFrameCheck=now;
 if(ft>50&&fanFreq>0){ // frame > 50ms = sluggish
 const k=fBin(fanFreq);
 if(AI_GATE.enabled&&AI_BAN.has(k))return; // تشديد: لا تراكم بيانات تباطؤ لتردد محضور مسبقاً
 if(!ENV_FP.slugFreqs.has(k))ENV_FP.slugFreqs.set(k,{hz:fanFreq,slugCount:0,totalFT:0});
 const sf=ENV_FP.slugFreqs.get(k);sf.slugCount++;sf.totalFT+=ft;
 if(sf.slugCount>=5){
 ANTI_IDLE.lagFreqs.set(k,{hz:fanFreq,lagCount:sf.slugCount,avgLag:sf.totalFT/sf.slugCount});
 // Auto-ban lag-causing frequencies after 8 confirmed sluggish events
 if(sf.slugCount>=8&&!AI_BAN.has(k)){
 AI_BAN.set(k,{reason:'Lag: '+sf.slugCount+'× frame>50ms (avg '+
 (sf.totalFT/sf.slugCount).toFixed(0)+'ms)',
 // تشديد (إصلاح خلل): نفس خلل الحظر الحراري — autoUnbanAt:-1 كانت تجعل FREQ_GATE
 // يحذف حظر التباطؤ فوراً في أول تمريرة تالية، فيعيد monitorSlugFreqs حظره من جديد
 // في الإطار التالي (frame) الذي يتجاوز 50ms — تكرار عديم الفائدة بلا نهاية
 bannedAt:aiCyc,cycles:0,autoUnbanAt:Infinity,hz:k,permanent:true,category:'lag',
 lagScore:Math.round(sf.totalFT/sf.slugCount)});
 if(freqDB.has(k)){freqDB.delete(k);writeFreqFile();} // تشديد: تنظيف FreqDB عند الحظر
 stopActiveInverse(fanFreq); // تشديد: إيقاف أي إبطال صوتي نشط لهذا التردد على السماعة
 deactivateNotch(fanFreq); // تشديد: إزالة أي notch نشط — محضور لا يحتاج كبت إضافي ولا يظهر في NOTCH LIST
 checkInterference(k);
 logNN(' LAG BAN: '+fanFreq.toFixed(1)+'Hz (×'+sf.slugCount+' drops)');
 }
 }
 }
}

/* Internal system load fingerprint update */
function updateInternalLoad(){
 // Frame score: normalized frame time
 ENV_FP.internalLoad.frameScore=Math.min(1,ANTI_IDLE.avgFrame/50);
 // Memory score
 if(performance.memory){
 ENV_FP.internalLoad.memScore=performance.memory.usedJSHeapSize/
 (performance.memory.jsHeapSizeLimit||1);
 }
 // Latency score
 if(actx)ENV_FP.internalLoad.latScore=Math.min(1,(actx.baseLatency||0)*20);
 const iv=E('env-int-load');
 if(iv)iv.textContent='Frame:'+ANTI_IDLE.avgFrame.toFixed(0)+'ms Mem:'+
 (ENV_FP.internalLoad.memScore*100).toFixed(0)+'% Lat:'+
 (ENV_FP.internalLoad.latScore*100).toFixed(0)+'%';
}


/* ── MEMORY PRESSURE MONITOR — heap usage & GC event detection ── */
const MEM_PRESS={val:0,hist:[],gcCount:0,lastGC:0,leakScore:0,lastUsed:0};
function updateMemPressure(){
 if(!performance.memory)return;
 const used=performance.memory.usedJSHeapSize;
 const limit=performance.memory.jsHeapSizeLimit||1;
 MEM_PRESS.val=(used/limit)*100;
 if(MEM_PRESS.lastUsed>0&&MEM_PRESS.lastUsed-used>5e6){
 MEM_PRESS.gcCount++;MEM_PRESS.lastGC=Date.now();
 }
 MEM_PRESS.lastUsed=used;
 MEM_PRESS.hist.push(MEM_PRESS.val);if(MEM_PRESS.hist.length>120)MEM_PRESS.hist.shift();
 if(MEM_PRESS.hist.length>=60){
 const first=MEM_PRESS.hist.slice(0,20).reduce((a,b)=>a+b)/20;
 const last=MEM_PRESS.hist.slice(-20).reduce((a,b)=>a+b)/20;
 MEM_PRESS.leakScore=Math.max(0,last-first);
 }
 const mv=E('mem-press-v');if(mv)mv.textContent=MEM_PRESS.val.toFixed(0)+'% GC:'+MEM_PRESS.gcCount;
}
setInterval(updateMemPressure,2500);

/* ── TIMING DRIFT — systematic interval drift detection ── */
const TIMING_DRIFT={expected:40,actual:[],drift:0,driftRate:0,_lastT:0};
function updateTimingDrift(){
 const now=performance.now();
 if(TIMING_DRIFT._lastT>0){
 const dt=now-TIMING_DRIFT._lastT;
 TIMING_DRIFT.actual.push(dt);if(TIMING_DRIFT.actual.length>100)TIMING_DRIFT.actual.shift();
 const mean=TIMING_DRIFT.actual.reduce((a,b)=>a+b)/TIMING_DRIFT.actual.length;
 TIMING_DRIFT.drift=mean-TIMING_DRIFT.expected;
 if(TIMING_DRIFT.actual.length>=20){
 const first=TIMING_DRIFT.actual.slice(0,10).reduce((a,b)=>a+b)/10;
 const last2=TIMING_DRIFT.actual.slice(-10).reduce((a,b)=>a+b)/10;
 TIMING_DRIFT.driftRate=last2-first;
 }
 const tv=E('drift-v');if(tv)tv.textContent=(TIMING_DRIFT.drift>0?'+':'')+TIMING_DRIFT.drift.toFixed(1)+'ms';
 }
 TIMING_DRIFT._lastT=now;
}

/* ── EXPERIENCE REPLAY — NN training sample buffer for offline learning ── */
const EXP_REPLAY={buf:[],maxSize:256,miniBatch:12};
function erPush(inp,reward,sil){
 EXP_REPLAY.buf.push({inp:[...inp],reward,sil,t:Date.now()});
 if(EXP_REPLAY.buf.length>EXP_REPLAY.maxSize)EXP_REPLAY.buf.shift();
}
function erSample(){
 const n=Math.min(EXP_REPLAY.miniBatch,EXP_REPLAY.buf.length);
 if(n<3)return[];
 const out=[];const used=new Set();
 while(out.length<n){
 const idx=Math.floor(Math.random()*EXP_REPLAY.buf.length);
 if(!used.has(idx)){used.add(idx);out.push(EXP_REPLAY.buf[idx]);}
 }
 return out;
}

/* ── TEMPORAL DIFFERENCE — TD(0) error tracker for value estimation ── */
const TD_LEARN={err:0,hist:[],gamma:0.92,curVal:0,prevVal:0};
function updateTD(reward,curSil){
 TD_LEARN.prevVal=TD_LEARN.curVal;TD_LEARN.curVal=curSil/100;
 TD_LEARN.err=reward+TD_LEARN.gamma*TD_LEARN.curVal-TD_LEARN.prevVal;
 TD_LEARN.hist.push(TD_LEARN.err);if(TD_LEARN.hist.length>100)TD_LEARN.hist.shift();
 const tv=E('td-err-v');if(tv)tv.textContent=TD_LEARN.err.toFixed(3);
}

/* ── HEBBIAN FREQ ASSOCIATION — co-activation learning between frequencies ── */
const HEBBIAN=new Map(); // 'binA:binB' → strength
function hebbLearn(hz1,hz2,reward){
 if(!hz1||!hz2||Math.abs(hz1-hz2)<0.5)return;
 const k=[fBin(hz1),fBin(hz2)].sort().join(':');
 const cur=HEBBIAN.get(k)||0;
 HEBBIAN.set(k,cur*0.97+reward*0.03);
 if(HEBBIAN.size>500)HEBBIAN.delete(HEBBIAN.keys().next().value);
}
function hebbStrength(hz1,hz2){
 const k=[fBin(hz1),fBin(hz2)].sort().join(':');
 return HEBBIAN.get(k)||0;
}

/* ── SYNAPTIC WEIGHT HISTOGRAM — NN weight distribution monitor ── */
const WT_HIST={bins:new Array(20).fill(0),min:-1,max:1};
function updateWtHist(){
 if(!NN.w1)return;
 WT_HIST.bins.fill(0);
 const all=[...NN.w1,...NN.w2,...NN.b1,...NN.b2];
 for(const w of all){
 const idx=Math.floor(((w-WT_HIST.min)/(WT_HIST.max-WT_HIST.min))*WT_HIST.bins.length);
 if(idx>=0&&idx<WT_HIST.bins.length)WT_HIST.bins[idx]++;
 }
}

/* ══════════════════════════════════
 NEURAL NETWORK — 16→24→8
 Full policy-gradient with momentum
══════════════════════════════════ */
const NN={in:16,hid:24,out:8,lr:0.012,mom:0.88,trainN:0,loss:1.0,lastOut:null,hist:[],
 w1:null,b1:null,w2:null,b2:null,dw1:null,db1:null,dw2:null,db2:null};

function nnInit(){
 const ni=NN.in,nh=NN.hid,no=NN.out;
 const xv=(r,c)=>Array.from({length:r*c},()=>(Math.random()*2-1)*Math.sqrt(2/(r+c)));
 NN.w1=xv(ni,nh);NN.b1=Array(nh).fill(0);
 NN.w2=xv(nh,no);NN.b2=Array(no).fill(0);
 NN.dw1=Array(ni*nh).fill(0);NN.db1=Array(nh).fill(0);
 NN.dw2=Array(nh*no).fill(0);NN.db2=Array(no).fill(0);
 logNN(' NN dims: in='+ni+' hid='+nh+' out='+no+' params='+(ni*nh+nh+nh*no+no));
 logNN(' NN initialized: 16→24→8 · mom=0.88 · lr=0.012 (16-class expanded)');
}

function nnFwd(inp){
 const ni=NN.in,nh=NN.hid,no=NN.out,{w1,b1,w2,b2}=NN;
 const h=Array(nh).fill(0);
 for(let j=0;j<nh;j++){let s=b1[j];for(let i=0;i<ni;i++)s+=inp[i]*w1[i*nh+j];h[j]=Math.tanh(s);}
 const out=Array(no).fill(0);
 for(let k=0;k<no;k++){let s=b2[k];for(let j=0;j<nh;j++)s+=h[j]*w2[j*no+k];out[k]=1/(1+Math.exp(-s));}
 NN.lastOut=out;return{h,out};
}

function nnTrain(inp,reward){
 if(!NN.w1)return;
 const ni=NN.in,nh=NN.hid,no=NN.out,{w1,b1,w2,b2,lr,mom}=NN;
 const{h,out}=nnFwd(inp);
 const dO=out.map((o,k)=>reward*(o>0.5?1:-1)*o*(1-o)*lr);
 const dH=Array(nh).fill(0);
 for(let j=0;j<nh;j++){let s=0;for(let k=0;k<no;k++){const i2=j*no+k;NN.dw2[i2]=mom*NN.dw2[i2]+dO[k]*h[j];w2[i2]+=NN.dw2[i2];s+=dO[k]*w2[i2];}dH[j]=s*(1-h[j]*h[j]);}
 for(let k=0;k<no;k++){NN.db2[k]=mom*NN.db2[k]+dO[k];b2[k]+=NN.db2[k];}
 for(let i=0;i<ni;i++){for(let j=0;j<nh;j++){const i2=i*nh+j;NN.dw1[i2]=mom*NN.dw1[i2]+dH[j]*inp[i];w1[i2]+=NN.dw1[i2];}}
 for(let j=0;j<nh;j++){NN.db1[j]=mom*NN.db1[j]+dH[j];b1[j]+=NN.db1[j];}
 NN.trainN++;const lv=1-Math.abs(reward);NN.loss=NN.loss*.95+lv*.05;
 NN.hist.push({reward,loss:NN.loss,sil:silSc,cyc:aiCyc});if(NN.hist.length>200)NN.hist.shift();
}

function nnInp(){
 const nyq=actx?actx.sampleRate/2:24000;
 return[Math.min(Math.abs(fanFreq)/nyq,1),fanE,Math.min(freqDB.size/200,1),evpE,emfE,Math.min(loopE*10,1),Math.abs(DRV.phase-180)/90,Math.min(fxMSE*1000,1),silSc/100,1-loopE,Math.min(NN.trainN/1000,1),(new Date().getHours())/24,RANGE.polarityRatio,Math.min(THERMAL.stress/100,1),Math.min(ANTI_IDLE.avgFrame/50,1),Math.min(CENTROID.hz/nyq,1)];
}

function nnCtrlSF(out){
 if(!out)return;
 iLv=0.3+out[0]*.7;uLv=0.3+out[1]*.7;
 pLv=0.3+out[4]*.7;bLv=0.2+out[3]*.8;eLv=0.2+out[5]*.8;
 // Out[6]: thermal aggression, out[7]: anti-lag boost
 if(THERMAL.stress>50)iLv=Math.min(1,iLv*(1+out[6]*.1));
 if(ANTI_IDLE.avgFrame>30)uLv=Math.min(1,uLv*(1+out[7]*.05));
 updSFGains();
}

function updSFGains(){
 Object.entries(silOscs).forEach(([k,v])=>{
 if(!v||!v.gain)return;
 if(k.startsWith('ig'))v.gain.value=iLv*.07;
 else if(k.startsWith('ug'))v.gain.value=uLv*.05;
 else if(k.startsWith('pg'))v.gain.value=pLv*.025;
 else if(k.startsWith('bg'))v.gain.value=bLv*.035;
 else if(k.startsWith('eg'))v.gain.value=eLv*.028;
 });
}

/* ══════════════════════════════════
 FREQUENCY DATABASE
 Records every captured frequency.
 Confirmed at ×THRESH → inverse built.
══════════════════════════════════ */
const freqDB=new Map();
let freqFile={totalCap:0,totalConf:0,totalCanc:0,entries:[]};
const NN_LOG=[];

/* ══════════════════════════════════════════════
 SOFTWARE NOTCH SUPPRESSION — applied to FFT data
 Confirmed freqs get a -depth_dB triangular notch
 before peak detection so the detector ignores them
══════════════════════════════════════════════ */
const NOTCH_SUPPRESS=new Map(); // key=fBin, val={hz,depth,halfBins,lastHit,order}
const NOTCH_HARM={enabled:false,maxOrder:3}; // auto-add harmonic notches
const NOTCH_DECAY={enabled:false,afterMs:30000}; // auto-deactivate stale notches
const FREQ_BAND={enabled:false,lo:20,hi:20000}; // KF band lock
