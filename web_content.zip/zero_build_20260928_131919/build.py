#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ZERO AI v25 — سكربت البناء (يدمج بين الفكرتين: مصدر مقسّم + ملف واحد مُسلَّم)
════════════════════════════════════════════════════════════════════════════
يقرأ src/index.template.html (الغلاف + وسوم <link>/<script src>)،
src/css/style.css، وكل ملفات src/js/*.js (بالترتيب الوارد في القالب)،
ويدمجها في ملف واحد ذاتي الاكتفاء: android-complete/index.html — هذا هو
الملف الذي يُحمِّله MainActivity فعلياً عبر file:///android_asset/index.html.

الفكرة: التطوير والتعديل يحدث في src/ (بنية معمارية مقسّمة حسب الوظيفة،
سهلة القراءة والصيانة) — لكن الناتج المُسلَّم للتطبيق نفسه ملف واحد فقط
(بلا أي طلبات شبكة/ملفات إضافية عند التشغيل، مطابق تماماً للفلسفة الأصلية
"الكل في ملف واحد"). التشغيل بعد أي تعديل في src/:

    python3 build.py

لا يوجد أي تغيير منطقي أثناء الدمج — فقط تجميع نصّي بالترتيب، تماماً
بالعكس من عملية التقسيم الأصلية (فُصل هذا الملف آلياً من ملف واحد، والآن
يُعاد تجميعه آلياً بلا أي فرق سلوكي).
"""
import re
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'src')
TEMPLATE_PATH = os.path.join(SRC, 'index.template.html')
CSS_PATH = os.path.join(SRC, 'css', 'style.css')
JS_DIR = os.path.join(SRC, 'js')
OUT_PATH = os.path.join(HERE, 'index.html')


def strip_file_header(js_src):
    """Each src/js/*.js file starts with a standardized header comment block
    (/* ══...  ══ */) describing that file's role in the split architecture.
    That framing doesn't apply to the bundled single file, so it's dropped;
    everything after it (the actual code) is kept byte-for-byte."""
    marker = '*/'
    if js_src.lstrip().startswith('/*'):
        idx = js_src.index(marker) + len(marker)
        rest = js_src[idx:]
        if rest.startswith('\n'):
            rest = rest[1:]
        return rest
    return js_src


def main():
    template = open(TEMPLATE_PATH, encoding='utf-8').read()
    css = open(CSS_PATH, encoding='utf-8').read()

    # Locate the <link rel="stylesheet" href="css/style.css"> tag and the
    # ordered list of <script src="js/....js"></script> tags, in the exact
    # order they appear in the template -- this is also the load order.
    link_pat = re.compile(r'<link rel="stylesheet" href="css/style\.css">\n?')
    link_m = link_pat.search(template)
    assert link_m, "template missing the css/style.css <link> tag"

    script_pat = re.compile(r'<script src="js/([\w.-]+\.js)"></script>\n?')
    script_matches = list(script_pat.finditer(template))
    assert script_matches, "template has no <script src=\"js/...\"> tags"

    js_names = [m.group(1) for m in script_matches]

    # Build the combined <script> block, in template order, each file's
    # section header comment stripped and replaced by a short divider.
    js_parts = []
    for name in js_names:
        path = os.path.join(JS_DIR, name)
        code = open(path, encoding='utf-8').read()
        code = strip_file_header(code)
        js_parts.append(f'/* ── {name} ── */\n' + code.rstrip('\n'))
    combined_js = '\n\n'.join(js_parts) + '\n'

    # Replace the <link> with an inline <style> block.
    out = link_pat.sub(lambda m: '<style>' + css + '</style>\n', template, count=1)

    # Replace the whole contiguous run of <script src="js/..."> tags with one
    # inline <script> block holding everything, in the same order. Matched
    # fresh against `out` (already mutated by the css substitution above) --
    # never reuse offsets computed against an earlier version of the string,
    # since every substitution shifts everything after it.
    run_pat = re.compile(r'(?:<script src="js/[\w.-]+\.js"></script>\n?)+')
    run_m = run_pat.search(out)
    assert run_m, "could not find the contiguous <script src> run in the css-updated template"
    out = out[:run_m.start()] + '<script>\n' + combined_js + '</script>\n' + out[run_m.end():]

    with open(OUT_PATH, 'w', encoding='utf-8') as f:
        f.write(out)

    print(f"Built {OUT_PATH}")
    print(f"  from template: {TEMPLATE_PATH}")
    print(f"  css: {len(css)} chars")
    print(f"  js files bundled ({len(js_names)}): {', '.join(js_names)}")
    print(f"  output size: {len(out)} chars, {out.count(chr(10)) + 1} lines")


if __name__ == '__main__':
    main()
