# ZERO AI v25 — Android Project

## Project layout — مصدر مقسّم + ملف واحد مُسلَّم

دُمجت هنا فكرتان كانتا في نسختين منفصلتين: "كل شيء في ملف واحد" (بساطة
التسليم/التشغيل) و"معمارية مقسّمة حسب الوظيفة" (سهولة الصيانة). الحل:
التطوير يحدث في مصدر مقسّم، والتطبيق يُحمِّل ناتجاً واحداً مُجمَّعاً منه تلقائياً.

```
android-complete/
├── index.html          ← النّاتج المُجمَّع: ملف واحد ذاتي الاكتفاء بالكامل
│                          (HTML+CSS+JS معاً) — هذا وحده ما يُحزَّم في الـ APK
│                          ويُحمَّله MainActivity؛ لا يُعدَّل يدوياً أبداً (مُولَّد)
├── build.py             ← يُعيد توليد index.html من src/ (شغّله بعد أي تعديل)
├── src/                 ← المصدر القابل للصيانة (لا يدخل الـ APK، لا يُقرأ وقت التشغيل)
│   ├── index.template.html   الغلاف: بنية DOM + ترتيب تحميل css/js
│   ├── css/style.css         كل الأنماط
│   └── js/                   محرك ZERO كاملاً، 18 ملفاً حسب الوظيفة (ترتيب التحميل أدناه)
│       ├── 00-core-state-metrics.js       الحالة العامة + مقاييس الإشارة الأساسية
│       ├── 01-spectral-analysis.js        تحليل طيفي متقدم (chroma/rolloff/harmonics/…)
│       ├── 02-classification-thermal-nn.js تصنيف الترددات + مراقبة الحرارة + الشبكة العصبية
│       ├── 03-notch-inverse-engine.js     مرشحات Notch + محرك الموجة المعاكسة + toggleAI
│       ├── 04-panels-ui-system.js         نظام اللوحات المشترك (open/close/closeAll)
│       ├── 05-presets-scenes-tracking.js  الإعدادات المسبقة + تصنيف البيئة + المشاهد
│       ├── 06-detection-engine-core.js    محرك الكشف والمعالجة الحي (startAll/detectAll/…)
│       ├── 07a-ai-command-library.js      مكتبة أوامر AI الضخمة (AI_LIB)
│       ├── 07b-ai-exec-engine.js          محرك التنفيذ الذاتي (aiExecCycle/UCB1 bandit) + واجهة التنفيذ/الأذونات
│       ├── 07c-freq-bans-partitions.js    تقسيمات الترددات وحظرها (buildFreqPartitions/banFreq/…)
│       ├── 08a-persist-bans-store.js      كائن PERSIST (الحفظ المزدوج) + تطهير/تحميل الحظر الافتراضي
│       ├── 08b-interference-permsettings.js كشف التداخل + تصعيد المناطق + إعدادات الأذونات
│       ├── 08c-background-db.js           خلفية النجوم المتحركة + طبقة IndexedDB (initDB + udsWrite*)
│       ├── 09-sessions-export-wtafs.js    الجلسات + جسر الأندرويد + بداية WTAFS
│       ├── 10-wtafs-backup-achievements.js تكملة WTAFS + الإنجازات
│       ├── 11-terminal-logging.js         الطرفية ونظام السجلّ
│       ├── 12-session-features-extra.js   غرفة الصمت + النوم الذكي + مؤقت النوم + الفيزياء
│       └── 13-zero-integration-aicore.js  طبقة تكامل ZERO-v25 + نواة AI (يُحمَّل أخيراً)
└── ZERO-v25/            ← هذا المشروع: غلاف Android أصلي (Java) حول index.html
```

### سير العمل
1. عدّل الملف المناسب داخل `src/js/` أو `src/css/style.css` أو `src/index.template.html`.
2. شغّل: `python3 android-complete/build.py`
3. يُعاد توليد `android-complete/index.html` بالكامل — دمج نصّي بحت بلا أي
   تغيير منطقي، بنفس ترتيب `src/js/` الظاهر في القالب. **لا تعدّل
   `index.html` مباشرة** — أي تعديل يدوي فيه يُفقَد عند أول `build.py` تالٍ.

### لماذا هذا الترتيب تحديداً في src/js
الملفات كلها كانت أصلاً أجزاءً متتالية من سكربت واحد؛ فُصلت بلا أي إعادة
ترتيب، فالترتيب أعلاه هو ترتيب التنفيذ الفعلي الأصلي أيضاً. لا يستدعي أي
ملف — داخل تنفيذه الفوري عند التحميل، لا داخل دالة — شيئاً لم يُعرَّف بعد؛
أي دالة/متغير مُعرَّف في ملف لاحق يُستخدم فقط داخل دوال تُستدعى لاحقاً (بعد
اكتمال تحميل كل الملفات)، ما عدا كتلة ربط "السحب للإغلاق" (`_wireSheetDrag`)
لكل اللوحات، والمنقولة عمداً إلى نهاية `13-zero-integration-aicore.js` (آخر
ملف في `src/js/`) لهذا السبب بالتحديد — نفس القاعدة يطبّقها `build.py` تلقائياً
عبر الحفاظ على ترتيب `src/js/` نفسه داخل السكربت المُجمَّع الواحد.

لا شيء من `src/` يُنسخ إلى `app/src/main/assets/` ولا يُحزَّم في الـ APK —
`app/build.gradle` يوجّه `sourceSets.main.assets.srcDirs` مباشرة إلى `../../`
(أي `android-complete/`) مع `include 'index.html'` فقط. `MainActivity` يحمّله
عبر: `webView.loadUrl("file:///android_asset/index.html")` — ملف واحد، بلا أي
طلب شبكة أو ملف إضافي وقت التشغيل.

## Storage Architecture
```
INTERNAL (private, /data/data/com.zero.v25/files/ZeroAI_v25/):
  sessions/       → JSON session files (auto-saved every 2 min + on stop)
  freqdb/         → Frequency database snapshots
  nn_weights/     → Neural network weight files
  logs/           → Startup, shutdown, error logs

DATA (dedicated program data — freq bans, NN weights, FC counters, categories):
  Android 11+:  /sdcard/ZeroAI/v25/Data/
  Android 10:   /sdcard/Android/data/com.zero.v25/files/Data/
  Android 9-:   /sdcard/ZeroAI/v25/Data/

EXPORT (user-visible exports):
  Android 11+:  /sdcard/ZeroAI/v25/Export/
  Android 10:   /sdcard/Android/data/com.zero.v25/files/Export/
  Android 9-:   /sdcard/ZeroAI/v25/Export/
```

## JavaScript Bridge (window.ZeroAndroid)

### Internal storage
| Method | Description |
|--------|-------------|
| `getInternalPath()` | Returns internal storage path |
| `saveFile(subdir, name, content)` | Save to internal storage (`sessions`\|`freqdb`\|`nn_weights`\|`logs`) |
| `saveFile(name, content)` | 2-arg overload — saves directly to `sessions` |
| `readFile(subdir, name)` | Read from internal storage; `null` if not found |
| `listFiles(subdir)` | List files in a subdir as a JSON array |
| `deleteFile(subdir, name)` | Delete a file from internal storage |
| `getStorageUsed()` | Total bytes used by ZERO AI |

### Program Data & Export
| Method | Description |
|--------|-------------|
| `getDataPath()` | Returns the dedicated program Data directory path |
| `saveData(name, content)` | Save to the Data directory (bans, NN weights, FC counters, categories) |
| `loadData(name)` | Load from the Data directory; `null` if not found |
| `listData()` | List all files in the Data directory as a JSON array |
| `getExportPath()` | Returns the user-accessible export directory path |
| `exportFile(name, content)` | Save to the user-accessible Export location |

### Permissions
| Method | Description |
|--------|-------------|
| `isPermissionGranted(id)` | `id`: `MANAGE_STORAGE`\|`POST_NOTIFICATIONS`\|`RECORD_AUDIO`\|`MEDIA_AUDIO`. True if granted or not required on this Android version |
| `requestPermission(id)` | Requests one permission from the checklist UI; result delivered via `window.onPermResult(id, granted)` |
| `openAppSettings()` | Opens this app's system Settings page (for a permanently-denied permission) |
| `launchApp()` | Loads the main app (`index.html`) in the WebView, called from the permission-check screen |

### Background service
| Method | Description |
|--------|-------------|
| `startBG(status)` | Starts the foreground service to prevent background kill |
| `stopBG()` | Stops the foreground service |
| `updateBGStatus(status)` | Updates the foreground notification text |
| `isBGRunning()` | Whether the background service is currently running |

### Device & diagnostics
| Method | Description |
|--------|-------------|
| `getAndroidVersion()` | Android SDK version (int) |
| `getDeviceModel()` | Device model string |
| `getPackageName()` | App package name |
| `getRamInfo()` | JSON `{totalMB, availMB, usedMB, usedPct}` |
| `getBatteryInfo()` | JSON `{tempC, levelPct, voltageMV, isCharging, health}` |
| `getThermalZones()` | JSON array `[{name, tempC}, ...]` from `/sys/class/thermal/` |
| `getCpuInfo()` | JSON `{cores, curMHz, maxMHz, freqPct}` for cpu0 |
| `getStorageInfo()` | JSON `{intTotalMB, intUsedMB, intFreeMB, intUsedPct, extAvail, extTotalMB, extUsedMB, extFreeMB}` |
| `getNetworkType()` | JSON `{connected, type, subtype}` — type: wifi\|cellular\|ethernet\|none |
| `getAppMemory()` | JSON `{heapUsedMB, heapMaxMB, nativeMB, totalPssMB}` |

### Misc
| Method | Description |
|--------|-------------|
| `setKeepScreenOn(on)` | JS-controlled screen-wake flag — call `true` only while ANC/ENC is actively processing, `false` when stopped |
| `vibrate(ms)` | Haptic feedback |

## Build
```bash
# Debug APK
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk

# Release APK (needs signing)
./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release-unsigned.apk
```
Requires the Android SDK (`compileSdk 34` / `minSdk 24` / `targetSdk 34`) — set
`sdk.dir` in `local.properties` (not checked in) to your local SDK path.

## Permissions
- `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS` — microphone capture
- `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MICROPHONE` — background mic capture stays alive
  on Android 12+ (`MEDIA_PLAYBACK` type does **not** cover background-mic restrictions —
  must be `MICROPHONE` specifically)
- `WAKE_LOCK` — keep-alive during active processing
- `POST_NOTIFICATIONS` — runtime prompt on Android 13+
- `READ_EXTERNAL_STORAGE` (maxSdk 32), `WRITE_EXTERNAL_STORAGE` (maxSdk 29) — legacy storage, Android 9 and below
- `MANAGE_EXTERNAL_STORAGE` — unrestricted storage access, Android 11+
- `READ_MEDIA_AUDIO` — scoped audio-file access, Android 13+
- `VIBRATE` — haptic feedback
- `android.hardware.microphone` (`required="true"`) — declares the app needs a mic

## Requirements
- Android 7.0+ (API 24)
- Microphone hardware
- No internet required — 100% local, no network permission requested
