package com.zero.v25;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/**
 * ZERO AI v25 — Foreground Service
 * Prevents Android from killing the app during background audio processing.
 * Shows a persistent notification while active.
 */
public class BgService extends Service {

    static final String CHANNEL_ID      = "zero_v25_bg";
    static final String CHANNEL_NAME    = "ZERO AI v25 Background";
    static final int    NOTIF_ID        = 1501;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String status = "Processing frequencies in background...";
        if (intent != null && intent.hasExtra("status")) {
            status = intent.getStringExtra("status");
        }

        // Tap notification → open app
        Intent launch = new Intent(this, MainActivity.class);
        launch.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingLaunch = PendingIntent.getActivity(
            this, 0, launch,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
            builder.setPriority(Notification.PRIORITY_LOW);
        }

        builder.setContentTitle("ZERO AI v25")
               .setContentText(status)
               .setSmallIcon(android.R.drawable.ic_media_play)
               .setContentIntent(pendingLaunch)
               .setOngoing(true)
               .setShowWhen(false);

        // مراجعة "النسخة النهائية": هذه الخدمة موجودة لإبقاء التقاط/معالجة الميكروفون حيّاً
        // والشاشة مطفأة (راجع "5-Layer background mode" في zero-core.js) — لا لتشغيل وسائط.
        // Android 12+ (ويُفرَض بصرامة أكبر حتى 14، targetSdk 34) يُعفي من قيود الميكروفون في
        // الخلفية فقط نوع "microphone" + إذن FOREGROUND_SERVICE_MICROPHONE المطابق — لا
        // "mediaPlayback"، الذي كان يُستخدَم هنا خطأً. بلا هذا الإصلاح: الخدمة تبدأ بلا أي
        // انهيار ظاهر، لكن النظام يُسكِت/يمنع دخل الميكروفون بصمت في الخلفية بالضبط في الحالة
        // التي وُجدت هذه الخدمة أصلاً لتنجو منها — الميزة الجوهرية (معالجة ANC في الخلفية)
        // تتوقف بصمت. (راجع أيضاً AndroidManifest.xml: foregroundServiceType + الإذن المطابقان
        // له بالضبط).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, builder.build(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIF_ID, builder.build());
        }
        // Restart if killed by system
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } else {
            stopForeground(true);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            );
            ch.setDescription("ZERO AI v25 frequency processing runs in background");
            ch.setShowBadge(false);
            ch.enableLights(false);
            ch.enableVibration(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }
}
