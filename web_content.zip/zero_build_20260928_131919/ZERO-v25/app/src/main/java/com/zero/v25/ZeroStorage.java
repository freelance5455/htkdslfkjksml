package com.zero.v25;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * ZERO AI v25 — Local File Storage Manager
 *
 * Internal paths (private to app):
 *   /data/data/com.zero.v25/files/ZeroAI_v25/sessions/
 *   /data/data/com.zero.v25/files/ZeroAI_v25/freqdb/
 *   /data/data/com.zero.v25/files/ZeroAI_v25/nn_weights/
 *   /data/data/com.zero.v25/files/ZeroAI_v25/logs/
 *
 * User-accessible paths (My Files):
 *   Android 11+: /sdcard/ZeroAI/v25/Data/     ← dedicated program data folder
 *   Android 10:  /sdcard/Android/data/com.zero.v25/files/Data/
 *   Android 9-:  /sdcard/ZeroAI/v25/Data/
 *
 * Export paths (user exports):
 *   Android 11+: /sdcard/ZeroAI/v25/Export/
 *   Android 10:  /sdcard/Android/data/com.zero.v25/files/Export/
 *   Android 9-:  /sdcard/ZeroAI/v25/Export/
 */
public class ZeroStorage {
    public static final String APP_DIR     = "ZeroAI_v25";
    public static final String SESSIONS    = "sessions";
    public static final String FREQDB      = "freqdb";
    public static final String NN_WEIGHTS  = "nn_weights";
    public static final String LOGS        = "logs";
    public static final String PARTITIONS  = "partitions";
    public static final String EXPORT      = "Export";
    public static final String DATA        = "Data";   // مجلد البيانات الأساسي (My Files)

    /** Get internal app files directory for a subdir */
    public static File getInternalDir(Context ctx, String subdir) {
        File dir = new File(ctx.getFilesDir(), APP_DIR + "/" + subdir);
        dir.mkdirs();
        return dir;
    }

    /**
     * Get dedicated program data directory — visible in My Files.
     * This is where PERSIST stores bans, NN weights, FC counters, etc.
     * Strategy mirrors getExportDir but uses "Data" subfolder.
     */
    public static File getDataDir(Context ctx) {
        File dir;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                && android.os.Environment.isExternalStorageManager()) {
            dir = new File(android.os.Environment.getExternalStorageDirectory(),
                "ZeroAI/v25/" + DATA);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // مراجعة "المشروع بالكامل": getExternalFilesDir(null) قد تُرجِع null إن كان التخزين
            // الخارجي غير مُركَّب حالياً — على عكس getStorageInfo() في ZeroBridge التي تتحقق من
            // ذلك صراحةً (`if (extDir != null)`)، هذا المسار لم يكن يتحقق إطلاقاً. new File(null,
            // "Data") لا يرمي استثناءً لكنها تُنتِج مساراً نسبياً يُحلّ ضد مجلد عمل العملية بدل
            // مجلد التطبيق الخارجي المقصود — فتفشل mkdirs()/الكتابة اللاحقة بصمت (رفض صلاحية ضد
            // الجذر)، فتتوقف PERSIST.saveData/loadData عن العمل دون أي استثناء أو سجل ظاهر.
            // الإصلاح: احتياطي آمن إلى مجلد التطبيق الداخلي (متاح دوماً) إن كان الخارجي غير متاح.
            File ext = ctx.getExternalFilesDir(null);
            dir = new File(ext != null ? ext : ctx.getFilesDir(), DATA);
        } else {
            dir = new File(android.os.Environment.getExternalStorageDirectory(),
                "ZeroAI/v25/" + DATA);
        }
        dir.mkdirs();
        return dir;
    }

    /** Get user-accessible export directory. */
    public static File getExportDir(Context ctx) {
        File dir;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                && android.os.Environment.isExternalStorageManager()) {
            dir = new File(android.os.Environment.getExternalStorageDirectory(),
                "ZeroAI/v25/" + EXPORT);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // انظر التعليق المطابق في getDataDir أعلاه — نفس احتياط null الآمن.
            File ext = ctx.getExternalFilesDir(null);
            dir = new File(ext != null ? ext : ctx.getFilesDir(), EXPORT);
        } else {
            dir = new File(android.os.Environment.getExternalStorageDirectory(),
                "ZeroAI/v25/" + EXPORT);
        }
        dir.mkdirs();
        return dir;
    }

    /** Get the UDS data directory */
    public static File getUDSDir(Context ctx) {
        File dir = new File(ctx.getFilesDir(), APP_DIR + "/uds");
        dir.mkdirs();
        return dir;
    }

    /* مراجعة "النسخة النهائية": كانت كل دالة هنا تفتح الملف وتكتب/تقرأ ثم تُغلِقه بأمر close()
       صريح داخل نفس try — إن رمى write()/readLine() استثناءً (قرص ممتلئ، خطأ إدخال/إخراج) كان
       close() يُتخطَّى بالكامل فيتسرَّب واصف الملف (file descriptor) تحت الغطاء. استُبدِلت
       بـ try-with-resources (يُغلِق تلقائياً حتى عند الاستثناء) — هذه الخدمة تعمل في الخلفية
       طويلاً، فتسرّب متكرر تحت ظرف "قرص شبه ممتلئ" مستمر كان قابلاً لاستنفاد واصفات الملفات
       فعلياً مع الوقت. */
    /** Append a line to a JSONL file */
    public static boolean appendLine(Context ctx, String subdir, String filename, String line) {
        File dir = getInternalDir(ctx, subdir);
        File file = new File(dir, filename);
        try (java.io.FileWriter fw = new java.io.FileWriter(file, true)) {
            fw.write(line + "\n");
            return true;
        } catch (Exception e) { return false; }
    }

    /** Write file to internal subdir */
    public static boolean write(Context ctx, String subdir, String filename, String content) {
        File dir = getInternalDir(ctx, subdir);
        File file = new File(dir, filename);
        try (FileWriter fw = new FileWriter(file, false)) {
            fw.write(content);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Read file from internal subdir */
    public static String read(Context ctx, String subdir, String filename) {
        File file = new File(getInternalDir(ctx, subdir), filename);
        if (!file.exists()) return null;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    /** List files in internal subdir as JSON array of names */
    public static String listFiles(Context ctx, String subdir) {
        File dir = getInternalDir(ctx, subdir);
        File[] files = dir.listFiles();
        if (files == null) return "[]";
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (File f : files) {
            if (!first) sb.append(",");
            sb.append("\"").append(f.getName()).append("\"");
            first = false;
        }
        sb.append("]");
        return sb.toString();
    }

    /** Export file to user-accessible export location */
    public static boolean export(Context ctx, String filename, String content) {
        File dir = getExportDir(ctx);
        File file = new File(dir, filename);
        try (FileWriter fw = new FileWriter(file, false)) {
            fw.write(content);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Save file to the dedicated Data directory (My Files — visible to user) */
    public static boolean saveToData(Context ctx, String filename, String content) {
        File dir = getDataDir(ctx);
        File file = new File(dir, filename);
        try (FileWriter fw = new FileWriter(file, false)) {
            fw.write(content);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Read file from the dedicated Data directory */
    public static String loadFromData(Context ctx, String filename) {
        File file = new File(getDataDir(ctx), filename);
        if (!file.exists()) return null;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    /** List files in the Data directory as JSON array */
    public static String listDataFiles(Context ctx) {
        File dir = getDataDir(ctx);
        File[] files = dir.listFiles();
        if (files == null) return "[]";
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (File f : files) {
            if (!first) sb.append(",");
            sb.append("\"").append(f.getName()).append("\"");
            first = false;
        }
        sb.append("]");
        return sb.toString();
    }

    /** Delete file from internal subdir */
    public static boolean delete(Context ctx, String subdir, String filename) {
        File file = new File(getInternalDir(ctx, subdir), filename);
        return file.delete();
    }

    /** Get total storage size in bytes for all ZERO AI files */
    public static long getTotalSize(Context ctx) {
        File root = new File(ctx.getFilesDir(), APP_DIR);
        return getFolderSize(root);
    }

    private static long getFolderSize(File dir) {
        if (!dir.exists()) return 0;
        long size = 0;
        File[] files = dir.listFiles();
        if (files == null) return 0;
        for (File f : files) {
            if (f.isDirectory()) size += getFolderSize(f);
            else size += f.length();
        }
        return size;
    }
}
