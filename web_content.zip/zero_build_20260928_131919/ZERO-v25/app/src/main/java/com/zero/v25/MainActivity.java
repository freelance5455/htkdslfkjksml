package com.zero.v25;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private static final int PERM_MANAGE_STORAGE = 101;
    private static final int PERM_REQ_SINGLE     = 103;

    private WebView    webView;
    private ZeroBridge bridge;
    private boolean    bgStartedByPause = false;
    private boolean    overlayInjected  = false;
    private String     pendingPermId    = null;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    /* ══════════════════════════════════════════════════ */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // مراجعة "المشروع بالكامل": pendingPermId حقل عادي في الـActivity — يُصفَّر إلى قيمته
        // الابتدائية null عند أي إعادة إنشاء (دوران الشاشة، أو استعادة بعد قتل العملية بضغط
        // الذاكرة) بينما مربع حوار إذن النظام لا يزال معلَّقاً. حين يصل الرد أخيراً إلى نسخة
        // الـActivity الجديدة، guessPermId(perms) هو المسار الوحيد المتاح — وفرعها الخاص بـ
        // MANAGE_STORAGE كان ميتاً أصلاً لأنه يقارن pendingPermId (وهو null دوماً في تلك اللحظة
        // بالضبط) بنفسه، فيصنِّف طلب MANAGE_STORAGE خطأً كـMEDIA_AUDIO — يبقى صف "وصول كامل
        // للملفات" عالقاً على "مطلوب" رغم منح الإذن فعلياً. الإصلاح الجذري: استعادة pendingPermId
        // نفسها من الحالة المحفوظة بدل محاولة تخمينها لاحقاً.
        if (savedInstanceState != null) pendingPermId = savedInstanceState.getString("pendingPermId");

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // FLAG_KEEP_SCREEN_ON removed — controlled by JS via ZeroAndroid.setKeepScreenOn()
        // Activating it permanently is the primary cause of excessive device heat.
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        ZeroStorage.getInternalDir(this, ZeroStorage.SESSIONS);
        ZeroStorage.getInternalDir(this, ZeroStorage.FREQDB);
        ZeroStorage.getInternalDir(this, ZeroStorage.NN_WEIGHTS);
        ZeroStorage.getInternalDir(this, ZeroStorage.LOGS);

        ZeroStorage.write(this, ZeroStorage.LOGS, "startup.txt",
            "ZERO AI v25 started: "  + new java.util.Date()        + "\n" +
            "Device: "               + Build.MANUFACTURER + " "
                                     + Build.MODEL                 + "\n" +
            "Android SDK: "          + Build.VERSION.SDK_INT       + "\n" +
            "Internal: "             + getFilesDir().getAbsolutePath()
                                     + "/" + ZeroStorage.APP_DIR   + "\n" +
            "Export: "               + ZeroStorage.getExportDir(this)
                                         .getAbsolutePath()        + "\n");

        webView = new WebView(this);
        setContentView(webView);
        setupWebView();

        webView.loadUrl("file:///android_asset/index.html");
    }

    /* ══════════════════════════════════════════════════ */

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        bridge = new ZeroBridge(this);
        webView.addJavascriptInterface(bridge, "ZeroAndroid");

        webView.setWebChromeClient(new WebChromeClient() {
            // فلترة صارمة (28 سبتمبر 2026 — بطلب المستخدم: حذف احتياج التطبيق للكاميرا نهائياً):
            // كانت r.grant(r.getResources()) تمنح تلقائياً أي مورد يطلبه WebView دون أي تمييز —
            // بما فيها PermissionRequest.RESOURCE_VIDEO_CAPTURE (الكاميرا) لو طلبتها أي صفحة/كود
            // JS مستقبلاً، رغم أن AndroidManifest.xml لا يُعلن إذن CAMERA أصلاً وأن الاستخدام
            // الفعلي الوحيد في كل المشروع هو navigator.mediaDevices.getUserMedia({audio:...})
            // (06-detection-engine-core.js) — صوت فقط. الآن: يُمنَح RESOURCE_AUDIO_CAPTURE حصراً
            // إن طُلب، ويُرفَض أي طلب آخر (كاميرا/MIDI/معرّف وسائط محمية) صراحةً — فيستحيل على
            // الكاميرا أن تُمنَح عبر هذا الجسر مهما كان الطلب.
            @Override public void onPermissionRequest(PermissionRequest r) {
                java.util.List<String> allowed = new java.util.ArrayList<>();
                for (String res : r.getResources()) {
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) allowed.add(res);
                }
                if (allowed.isEmpty()) { r.deny(); return; }
                r.grant(allowed.toArray(new String[0]));
            }
            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, android.webkit.JsResult r) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                    .setMessage(msg)
                    .setPositiveButton("OK",     (d,w) -> r.confirm())
                    .setNegativeButton("Cancel", (d,w) -> r.cancel())
                    .setCancelable(false).show();
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                v.loadUrl(req.getUrl().toString()); return true;
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                if (!overlayInjected && url != null && url.contains("index.html")) {
                    overlayInjected = true;
                    mainHandler.postDelayed(MainActivity.this::injectPermOverlay, 400);
                }
            }
        });
    }

    /* ══════════════════════════════════════════════════
       Overlay inject / remove
    ══════════════════════════════════════════════════ */

    private void injectPermOverlay() {
        if (webView == null) return;
        webView.evaluateJavascript(buildPermOverlayScript(), null);
    }

    public void closePermOverlay() {
        mainHandler.post(() -> {
            if (webView != null)
                webView.evaluateJavascript(
                    "(function(){var e=document.getElementById('zp-ov');if(e)e.remove();})()", null);
        });
    }

    /* ══════════════════════════════════════════════════
       JS overlay builder
    ══════════════════════════════════════════════════ */

    private String buildPermOverlayScript() {
        return "(function(){" +
        "if(document.getElementById('zp-ov'))return;" +

        /* ── CSS ── */
        "var _st=document.createElement('style');" +
        "_st.textContent=" +
        "'#zp-ov{position:fixed;top:0;right:0;bottom:0;left:0;z-index:99999;" +
             "background:#07070f;overflow-y:auto;font-family:system-ui,-apple-system,sans-serif;" +
             "direction:rtl;color:#e2e8f0;}'" +
        "+'#zp-ov *{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}'" +
        "+'.zp-pg{width:100%;max-width:460px;margin:0 auto;padding:24px 16px 36px;display:flex;flex-direction:column;gap:0;}'" +
        "+'.zp-hdr{text-align:center;padding:20px 0 22px;}'" +
        "+'.zp-brand{display:inline-flex;align-items:center;gap:8px;margin-bottom:12px;}'" +
        "+'.zp-logo{width:38px;height:38px;background:rgba(99,102,241,.12);border:1px solid rgba(99,102,241,.35);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;}'" +
        "+'.zp-bname{font-size:18px;font-weight:800;letter-spacing:2px;color:#6366f1;}'" +
        "+'.zp-h1{font-size:20px;font-weight:700;color:#e2e8f0;margin-bottom:5px;}'" +
        "+'.zp-sub{font-size:13px;color:#64748b;line-height:1.5;}'" +
        "+'.zp-list{display:flex;flex-direction:column;gap:10px;margin-bottom:22px;}'" +
        "+'.zp-row{background:#0d0d1c;border:1px solid rgba(99,102,241,.18);border-radius:16px;padding:16px;display:flex;flex-direction:column;gap:10px;transition:border-color .3s,background .3s;}'" +
        "+'.zp-row.r-ok{border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.03);}'" +
        "+'.zp-row.r-no{border-color:rgba(239,68,68,.25);background:rgba(239,68,68,.02);}'" +
        "+'.zp-top{display:flex;align-items:center;gap:12px;}'" +
        "+'.zp-ico{width:44px;height:44px;background:#111124;border:1px solid rgba(99,102,241,.08);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;}'" +
        "+'.zp-meta{flex:1;min-width:0;}'" +
        "+'.zp-name{font-size:15px;font-weight:600;color:#e2e8f0;margin-bottom:2px;}'" +
        "+'.zp-desc{font-size:12px;color:#64748b;line-height:1.45;}'" +
        "+'.zp-bdg{flex-shrink:0;font-size:11px;font-weight:700;padding:4px 10px;border-radius:20px;white-space:nowrap;}'" +
        "+'.b-need{background:rgba(245,158,11,.1);color:#f59e0b;border:1px solid rgba(245,158,11,.25);}'" +
        "+'.b-ok{background:rgba(34,197,94,.1);color:#22c55e;border:1px solid rgba(34,197,94,.25);}'" +
        "+'.b-opt{background:rgba(59,130,246,.1);color:#3b82f6;border:1px solid rgba(59,130,246,.2);}'" +
        "+'.b-no{background:rgba(239,68,68,.1);color:#ef4444;border:1px solid rgba(239,68,68,.2);}'" +
        "+'.zp-btn{width:100%;padding:12px 16px;border:none;border-radius:11px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit;direction:rtl;transition:opacity .15s,background .2s;display:flex;align-items:center;justify-content:center;gap:8px;}'" +
        "+'.zp-btn:active:not(:disabled){opacity:.75;}.zp-btn:disabled{cursor:default;opacity:.7;}'" +
        "+'.btn-p{background:#3b82f6;color:#fff;}'" +
        "+'.btn-g{background:rgba(34,197,94,.12);color:#22c55e;}'" +
        "+'.btn-d{background:rgba(239,68,68,.12);color:#ef4444;}'" +
        "+'.btn-o{background:rgba(99,102,241,.12);color:#6366f1;}'" +
        /* Error reason box */
        "+'.zp-err{display:none;font-size:12px;color:#fca5a5;background:rgba(239,68,68,.07);border:1px solid rgba(239,68,68,.18);border-radius:9px;padding:10px 12px;line-height:1.6;direction:rtl;}'" +
        "+'.zp-err.show{display:block;}'" +
        "+'.zp-div{height:1px;background:rgba(99,102,241,.15);margin:4px 0 16px;}'" +
        /* Next button */
        "+'.zp-next{width:100%;padding:16px;background:#6366f1;color:#fff;border:none;border-radius:14px;font-size:16px;font-weight:700;cursor:pointer;font-family:inherit;direction:rtl;transition:opacity .15s;margin-bottom:10px;display:flex;align-items:center;justify-content:center;gap:8px;}'" +
        "+'.zp-next:active{opacity:.8;}'" +
        "+'.zp-note{text-align:center;font-size:12px;color:#64748b;line-height:1.5;}'" +
        "+'.zp-note.n-ok{color:#22c55e;}';" +
        "document.head.appendChild(_st);" +

        /* ── Overlay ── */
        "var ov=document.createElement('div');ov.id='zp-ov';" +
        "document.body.appendChild(ov);" +
        "var pg=document.createElement('div');pg.className='zp-pg';ov.appendChild(pg);" +

        /* Header */
        "var hdr=document.createElement('div');hdr.className='zp-hdr';" +
        "var brd=document.createElement('div');brd.className='zp-brand';" +
        "var lgw=document.createElement('div');lgw.className='zp-logo';lgw.textContent='⚙';brd.appendChild(lgw);" +
        "var bnm=document.createElement('div');bnm.className='zp-bname';bnm.textContent='ZERO AI';brd.appendChild(bnm);" +
        "hdr.appendChild(brd);" +
        /* التحقق من الأذونات */
        "var h1=document.createElement('h1');h1.className='zp-h1';" +
        "h1.textContent='التحقق من الأذونات';" +
        "hdr.appendChild(h1);" +
        /* اضغط على زر كل إذن للحصول عليه بشكل مستقل */
        "var sb=document.createElement('p');sb.className='zp-sub';" +
        "sb.textContent='اضغط على زر كل إذن للحصول عليه بشكل مستقل';" +
        "hdr.appendChild(sb);pg.appendChild(hdr);" +

        /* List */
        "var lst=document.createElement('div');lst.className='zp-list';pg.appendChild(lst);" +

        /* Divider */
        "var dv=document.createElement('div');dv.className='zp-div';pg.appendChild(dv);" +

        /* Next button — التالي */
        "var nb=document.createElement('button');nb.className='zp-next';" +
        "nb.textContent='التالي ←';" +
        "nb.onclick=function(){try{if(typeof ZeroAndroid!='undefined')ZeroAndroid.launchApp();}catch(e){}};" +
        "pg.appendChild(nb);" +

        /* Note */
        "var nt=document.createElement('p');nt.className='zp-note';nt.id='zp-note';" +
        /* يمكنك المتابعة وإعطاء الأذونات لاحقاً من إعدادات الجهاز */
        "nt.textContent='يمكنك المتابعة وإعطاء الأذونات لاحقاً من إعدادات الجهاز';" +
        "pg.appendChild(nt);" +

        /* ── PERMS (with error messages) ── */
        "var PERMS=[" +
          /* 📂 وصول كامل للملفات */
          "{id:'MANAGE_STORAGE',icon:'📂'," +
           "name:'وصول كامل للملفات'," +
           "desc:'يتيح حفظ بيانات الذكاء الاصطناعي في My Files تلقائياً'," +
           /* هذا الإذن ضروري لحفظ البيانات — اضغط مرة أخرى لفتح الإعدادات */
           "err:'⚠ هذا الإذن ضروري لحفظ بيانات التطبيق — اضغط مرة أخرى لفتح إعدادات التطبيق'," +
           "needApi:30,optional:false}," +
          /* 🔔 الإشعارات */
          "{id:'POST_NOTIFICATIONS',icon:'🔔'," +
           "name:'الإشعارات'," +
           "desc:'لإعلامك بحالة المعالجة عند تشغيل التطبيق في الخلفية'," +
           /* لن تظهر إشعارات الخلفية — يمكن تفعيله لاحقاً من إعدادات الجهاز */
           "err:'ℹ لن تظهر إشعارات الخلفية — يمكن تفعيله لاحقاً من إعدادات الجهاز'," +
           "needApi:33,optional:true}," +
          /* 🎙 الميكروفون */
          "{id:'RECORD_AUDIO',icon:'🎙'," +
           "name:'الميكروفون'," +
           "desc:'ضروري لتحليل الترددات الصوتية واكتشاف الموجات الصوتية'," +
           /* ⚠ هذا الإذن ضروري للتطبيق — لن يعمل تحليل الصوت بدونه */
           "err:'⚠ هذا الإذن ضروري للتطبيق — لن يعمل تحليل الصوت بدونه'," +
           "needApi:0,optional:false}," +
          /* 🎵 الصوت والملفات */
          "{id:'MEDIA_AUDIO',icon:'🎵'," +
           "name:'الصوت والملفات'," +
           "desc:'يسمح بالوصول لملفات الصوت وبيانات التخزين الخارجي'," +
           /* ⚠ هذا الإذن ضروري للوصول لملفات الصوت — اضغط للمحاولة مجدداً */
           "err:'⚠ هذا الإذن ضروري للوصول لملفات الصوت — اضغط للمحاولة مجدداً'," +
           "needApi:0,optional:false}" +
        "];" +

        /* ── Helpers ── */
        "var _api=(typeof ZeroAndroid!='undefined')?ZeroAndroid.getAndroidVersion():33;" +
        "var _vis=PERMS.filter(function(p){return _api>=p.needApi;});" +
        "var _refs={};" +

        "function _isG(id){try{return typeof ZeroAndroid!='undefined'&&ZeroAndroid.isPermissionGranted(id);}catch(e){return false;}}" +

        /* Text constants (Unicode-safe) */
        "var T={" +
          /* ✅ ممنوح */
          "granted:'✅ ممنوح'," +
          /* مطلوب */
          "req:'مطلوب'," +
          /* اختياري */
          "opt:'اختياري'," +
          /* مرفوض ✗ */
          "denied:'مرفوض ✗'," +
          /* ✅ تم المنح */
          "btnOk:'✅ تم المنح'," +
          /* ↺ اضغط مجدداً */
          "btnRetry:'↺ اضغط مجدداً'," +
          /* اضغط للحصول على الإذن ← */
          "btnAsk:'اضغط للحصول على الإذن ←'," +
          /* ⏳ جارٍ الطلب… */
          "req2:'⏳ جارٍ الطلب…'," +
          /* يمكنك المتابعة وإعطاء الأذونات لاحقاً من إعدادات الجهاز */
          "noteW:'يمكنك المتابعة وإعطاء الأذونات لاحقاً من إعدادات الجهاز'," +
          /* ✅ جميع الأذونات الأساسية ممنوحة — التطبيق جاهز */
          "noteOk:'✅ جميع الأذونات الأساسية ممنوحة — التطبيق جاهز'" +
        "};" +

        /* ── Build rows ── */
        "_vis.forEach(function(p){" +
            "var g=_isG(p.id);" +
            "var row=document.createElement('div');" +
            "row.className='zp-row'+(g?' r-ok':'');row.id='zp-row-'+p.id;" +

            /* top */
            "var top=document.createElement('div');top.className='zp-top';" +
            "var ico=document.createElement('div');ico.className='zp-ico';ico.textContent=p.icon;top.appendChild(ico);" +
            "var met=document.createElement('div');met.className='zp-meta';" +
            "var nm=document.createElement('div');nm.className='zp-name';nm.textContent=p.name;met.appendChild(nm);" +
            "var dc=document.createElement('div');dc.className='zp-desc';dc.textContent=p.desc;met.appendChild(dc);" +
            "top.appendChild(met);" +
            "var bdg=document.createElement('div');bdg.id='zp-bdg-'+p.id;" +
            "bdg.className='zp-bdg '+(g?'b-ok':(p.optional?'b-opt':'b-need'));" +
            "bdg.textContent=g?T.granted:(p.optional?T.opt:T.req);" +
            "top.appendChild(bdg);row.appendChild(top);" +

            /* error box (hidden until denied) */
            "var eb=document.createElement('div');eb.className='zp-err';eb.id='zp-err-'+p.id;" +
            "eb.textContent=p.err;row.appendChild(eb);" +

            /* button — IIFE to capture p */
            "(function(pid,pp,rrow,rbdg,reb){" +
                "var btn=document.createElement('button');btn.id='zp-btn-'+pid;" +
                "btn.className='zp-btn '+(g?'btn-g':(pp.optional?'btn-o':'btn-p'));" +
                "btn.textContent=g?T.btnOk:T.btnAsk;btn.disabled=g;" +
                "btn.onclick=function(){" +
                    "btn.textContent=T.req2;btn.disabled=true;" +
                    "try{if(typeof ZeroAndroid!='undefined')ZeroAndroid.requestPermission(pid);}" +
                    "catch(e){btn.className='zp-btn btn-p';btn.textContent=T.btnAsk;btn.disabled=false;}" +
                "};" +
                "rrow.appendChild(btn);" +
                "_refs[pid]={row:rrow,bdg:rbdg,btn:btn,err:reb,p:pp};" +
            "})(p.id,p,row,bdg,eb);" +

            "lst.appendChild(row);" +
        "});" +

        /* ── onPermResult ── */
        "window.onPermResult=function(id,granted){" +
            "var r=_refs[id];if(!r)return;" +
            "var p=r.p;" +
            /* button */
            "r.btn.disabled=granted;" +
            "r.btn.className='zp-btn '+(granted?'btn-g':'btn-d');" +
            "r.btn.textContent=granted?T.btnOk:T.btnRetry;" +
            /* badge */
            "r.bdg.textContent=granted?T.granted:(p.optional?T.opt+' – مرفوض':T.denied);" +  /* اختياري – مرفوض */
            "r.bdg.className='zp-bdg '+(granted?'b-ok':'b-no');" +
            /* row */
            "r.row.className='zp-row '+(granted?'r-ok':'r-no');" +
            /* error box — show only when denied */
            "r.err.className='zp-err'+(granted?'':' show');" +
            "_refNote();" +
        "};" +

        /* ── onPermPermanentDenied ── */
        "window.onPermPermanentDenied=function(id){" +
            "var r=_refs[id];if(!r)return;" +
            "r.btn.disabled=false;" +
            "r.btn.className='zp-btn btn-d';" +
            "r.btn.textContent='⚙ فتح إعدادات التطبيق';" +
            "r.btn.onclick=function(){" +
                "try{if(typeof ZeroAndroid!='undefined')ZeroAndroid.openAppSettings();}catch(e){}" +
            "};" +
            "r.bdg.textContent='مرفوض نهائياً';" +
            "r.bdg.className='zp-bdg b-no';" +
            "r.row.className='zp-row r-no';" +
            "r.err.textContent='⚠ تم الرفض نهائياً — افتح إعدادات التطبيق وامنح الإذن يدوياً';" +
            "r.err.className='zp-err show';" +
            "_refNote();" +
        "};" +

        /* ── Note refresh ── */
        "function _refNote(){" +
            "var req=_vis.filter(function(p){return !p.optional;});" +
            "var allOk=req.every(function(p){return _isG(p.id);});" +
            "var n=document.getElementById('zp-note');" +
            "n.textContent=allOk?T.noteOk:T.noteW;" +
            "n.className='zp-note'+(allOk?' n-ok':'');" +
        "}" +

        "_refNote();" +
        "})();";
    }

    /* ══════════════════════════════════════════════════
       Permission handling
    ══════════════════════════════════════════════════ */

    public void handlePermissionRequest(final String id) {
        mainHandler.post(() -> {
            pendingPermId = id;
            switch (id) {
                case "MANAGE_STORAGE":
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        if (Environment.isExternalStorageManager()) {
                            notifyPermResult("MANAGE_STORAGE", true); pendingPermId = null;
                        } else { openManageStorageSettings(); }
                    } else {
                        // API 24-29: request WRITE_EXTERNAL_STORAGE via standard dialog
                        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                            notifyPermResult("MANAGE_STORAGE", true); pendingPermId = null;
                        } else { requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERM_REQ_SINGLE); }
                    }
                    break;
                case "POST_NOTIFICATIONS":
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                            notifyPermResult("POST_NOTIFICATIONS", true); pendingPermId = null;
                        } else { requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, PERM_REQ_SINGLE); }
                    } else { notifyPermResult("POST_NOTIFICATIONS", true); pendingPermId = null; }
                    break;
                case "RECORD_AUDIO":
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        notifyPermResult("RECORD_AUDIO", true); pendingPermId = null;
                    } else { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERM_REQ_SINGLE); }
                    break;
                case "MEDIA_AUDIO":
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            notifyPermResult("MEDIA_AUDIO", true); pendingPermId = null;
                        } else { requestPermissions(new String[]{Manifest.permission.READ_MEDIA_AUDIO}, PERM_REQ_SINGLE); }
                    } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                        boolean rOk = checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
                        boolean wOk = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
                        if (rOk && wOk) { notifyPermResult("MEDIA_AUDIO", true); pendingPermId = null; }
                        else { requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERM_REQ_SINGLE); }
                    } else {
                        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                            notifyPermResult("MEDIA_AUDIO", true); pendingPermId = null;
                        } else { requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERM_REQ_SINGLE); }
                    }
                    break;
            }
        });
    }

    private void openManageStorageSettings() {
        try {
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:" + getPackageName())), PERM_MANAGE_STORAGE);
        } catch (Exception e1) {
            try { startActivityForResult(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION), PERM_MANAGE_STORAGE); }
            catch (Exception e2) { notifyPermResult("MANAGE_STORAGE", false); pendingPermId = null; }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PERM_MANAGE_STORAGE) return;
        boolean ok = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager();
        notifyPermResult("MANAGE_STORAGE", ok);
        pendingPermId = null;
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req != PERM_REQ_SINGLE) return;
        // مراجعة "المشروع بالكامل": حسب عقد Android الرسمي، إن أُلغي طلب الإذن (مثلاً: انتقل
        // المستخدم للخلفية أثناء ظهور مربع الحوار قبل الرد عليه)، تصل perms/results كمصفوفتين
        // فارغتين تماماً. الحلقة أدناه لا تُنفَّذ إطلاقاً على مصفوفة فارغة، فتبقى allOk على قيمتها
        // الابتدائية true — يُبلَّغ JS بأن الإذن "مُنِح" رغم أنه لم يُطلَب فعلياً؛ تعرض واجهة
        // فحص الأذونات "✅ ممنوح" بينما الإذن الحقيقي لا يزال مرفوضاً، فيفشل أي كود لاحق يعتمد
        // عليه (SecurityException أو فشل صامت في التقاط الصوت). الإصلاح: مصفوفة نتائج فارغة
        // تعني إلغاءً لا منحاً — تُعامَل كرفض، تماماً كأي رفض عادي (تتيح للمستخدم إعادة المحاولة).
        boolean allOk = results != null && results.length > 0;
        for (int r : results) if (r != PackageManager.PERMISSION_GRANTED) { allOk = false; break; }
        String id = pendingPermId != null ? pendingPermId : guessPermId(perms);
        if (!allOk && perms != null && perms.length > 0
                && !shouldShowRequestPermissionRationale(perms[0])) {
            // Permanently denied (user checked "Don't ask again") — guide to Settings
            notifyPermPermanentDenied(id);
        } else {
            notifyPermResult(id, allOk);
        }
        pendingPermId = null;
    }

    private String guessPermId(String[] perms) {
        if (perms == null || perms.length == 0) return "UNKNOWN";
        String p = perms[0];
        if (p.contains("RECORD_AUDIO"))          return "RECORD_AUDIO";
        if (p.contains("POST_NOTIFICATIONS"))    return "POST_NOTIFICATIONS";
        if (p.contains("READ_MEDIA_AUDIO"))      return "MEDIA_AUDIO";
        if (p.contains("WRITE_EXTERNAL_STORAGE"))
            return "MANAGE_STORAGE".equals(pendingPermId) ? "MANAGE_STORAGE" : "MEDIA_AUDIO";
        if (p.contains("READ_EXTERNAL_STORAGE")) return "MEDIA_AUDIO";
        return "UNKNOWN";
    }

    private void notifyPermResult(String id, boolean granted) {
        if (webView == null) return;
        final String js = "if(window.onPermResult)window.onPermResult('" + id + "'," + granted + ");";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void notifyPermPermanentDenied(String id) {
        if (webView == null) return;
        final String js = "if(window.onPermPermanentDenied)window.onPermPermanentDenied('" + id + "');" +
                          "else if(window.onPermResult)window.onPermResult('" + id + "',false);";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    /* ══════════════════════════════════════════════════
       Lifecycle
    ══════════════════════════════════════════════════ */

    @Override protected void onPause() {
        super.onPause();
        // Heat fix #2: pause WebView rendering — releases GPU and halts JS timers
        if (webView != null) {
            webView.onPause();         // suspend rendering pipeline
            webView.pauseTimers();     // halt ALL WebView JS timers globally
            // Notify JS to throttle audio loops and heavy processing
            webView.evaluateJavascript(
                "if(typeof window.onAppBackground==='function')window.onAppBackground();", null);
        }
        if (bridge != null && !bgStartedByPause) {
            bridge.startBG("ZERO AI v25 processing in background...");
            bgStartedByPause = true;
        }
    }

    @Override protected void onResume() {
        super.onResume();
        // Heat fix #3: resume WebView rendering and JS timers
        if (webView != null) {
            webView.resumeTimers();    // restore JS timer execution
            webView.onResume();        // resume rendering pipeline
        }
        // مراجعة "المشروع بالكامل": كان هذا يستدعي stopService() مباشرة من الـActivity، متجاوزاً
        // bridge.stopBG() — التي تُصفِّر أيضاً bgRunning داخل ZeroBridge. النتيجة: الخدمة تتوقف
        // فعلياً، لكن bridge.bgRunning تبقى true للأبد. طالما الجلسة نشطة، JS يستدعي
        // ZeroAndroid.updateBGStatus(...) كل ~600ms، وبما أنها تتحقق فقط من bgRunning (لا من حالة
        // الخدمة الفعلية)، تُعيد تشغيل BgService وتُظهر إشعار "معالجة خلفية" من جديد رغم أن
        // التطبيق في الواجهة الأمامية بالكامل — حتى isBGRunning() كانت تكذب على JS. الإصلاح:
        // استدعاء bridge.stopBG() نفسها، التي توقف الخدمة وتُصفِّر العلم معاً بذرّة واحدة.
        if (bgStartedByPause) { if (bridge != null) bridge.stopBG(); else stopService(new Intent(this, BgService.class)); bgStartedByPause = false; }
        if (webView != null)
            webView.post(() -> webView.evaluateJavascript(
                // Notify JS that app is foreground — restore audio loops at normal speed
                "if(typeof window.onAppForeground==='function')window.onAppForeground();" +
                "if(typeof syncBGUI==='function'){syncBGUI();" +
                "if(typeof stLog==='function')stLog('📱 عاد التطبيق إلى الواجهة');}" +
                /* Refresh permission buttons automatically when returning from Settings */
                "if(window.zpOpen&&typeof zpRefreshAll==='function')zpRefreshAll();", null));
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        ZeroStorage.write(this, ZeroStorage.LOGS, "shutdown.txt",
            "ZERO AI v25 stopped: " + new java.util.Date() + "\n");
        stopService(new Intent(this, BgService.class));
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // انظر التعليق في onCreate — يحفظ pendingPermId قبل إعادة إنشاء محتملة للـActivity.
        if (pendingPermId != null) outState.putString("pendingPermId", pendingPermId);
    }

    /* ══════════════════════════════════════════════════
       Memory pressure — notify JS to free resources
    ══════════════════════════════════════════════════ */

    @Override public void onLowMemory() {
        super.onLowMemory();
        if (webView != null) {
            webView.clearCache(true);      // release WebView render cache
            webView.post(() -> webView.evaluateJavascript(
                "if(typeof window.onLowMemory==='function')window.onLowMemory('critical');" +
                "if(typeof stLog==='function')stLog('⚠ ذاكرة منخفضة — تم تحرير الكاش');", null));
        }
    }

    @Override public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (webView == null) return;
        // TRIM_MEMORY_RUNNING_CRITICAL = 15, UI_HIDDEN = 20, MODERATE = 60
        final String lvlStr;
        if      (level >= 80) { webView.clearCache(false); lvlStr = "critical"; }
        else if (level >= 40) { lvlStr = "moderate"; }
        else                  { lvlStr = "low"; }
        webView.post(() -> webView.evaluateJavascript(
            "if(typeof window.onTrimMemory==='function')window.onTrimMemory('" + lvlStr + "'," + level + ");", null));
    }
}
