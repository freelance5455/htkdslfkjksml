package com.golestan.customermanager;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_SMS = 4102;
    private static final String ACTION_SMS_SENT = "com.golestan.customermanager.SMS_SENT";
    private WebView webView;
    private BroadcastReceiver smsReceiver;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new SmsBridge(), "Android");
        setContentView(webView);
        registerSmsReceiver();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void registerSmsReceiver() {
        smsReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                boolean ok = getResultCode() == Activity.RESULT_OK;
                String phone = intent.getStringExtra("phone");
                String reason = getResultCode() == SmsManager.RESULT_ERROR_NO_SERVICE ? "no_service" :
                        getResultCode() == SmsManager.RESULT_ERROR_RADIO_OFF ? "radio_off" :
                        getResultCode() == SmsManager.RESULT_ERROR_NULL_PDU ? "null_pdu" :
                        getResultCode() == SmsManager.RESULT_ERROR_GENERIC_FAILURE ? "generic_failure" : "unknown";
                try {
                    JSONObject payload = new JSONObject();
                    payload.put("phone", phone == null ? "" : phone);
                    payload.put("ok", ok);
                    payload.put("reason", reason);
                    final String js = "window.onNativeSmsResult && window.onNativeSmsResult(" +
                            JSONObject.quote(phone == null ? "" : phone) + "," + ok + "," +
                            JSONObject.quote(reason) + ");";
                    runOnUiThread(() -> webView.evaluateJavascript(js, null));
                } catch (Exception ignored) { }
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_SMS_SENT);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(smsReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(smsReceiver, filter);
        }
    }

    public class SmsBridge {
        @JavascriptInterface
        public String requestSmsPermission() {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                return "granted";
            }
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SMS));
            return "requested";
        }

        @JavascriptInterface
        public String sendSms(String phone, String message) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                return "no_permission";
            }
            if (phone == null || !phone.matches("^\\+?[0-9]{8,15}$") || message == null || message.trim().isEmpty()) {
                return "invalid_number_or_message";
            }
            try {
                SmsManager manager;
                if (Build.VERSION.SDK_INT >= 31) {
                    manager = getSystemService(SmsManager.class);
                } else {
                    manager = SmsManager.getDefault();
                }
                ArrayList<String> parts = manager.divideMessage(message);
                ArrayList<android.app.PendingIntent> sentIntents = new ArrayList<>();
                for (int i = 0; i < parts.size(); i++) {
                    Intent sent = new Intent(ACTION_SMS_SENT);
                    sent.setPackage(getPackageName());
                    sent.putExtra("phone", phone);
                    int flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT;
                    if (Build.VERSION.SDK_INT >= 23) flags |= android.app.PendingIntent.FLAG_IMMUTABLE;
                    sentIntents.add(android.app.PendingIntent.getBroadcast(
                            MainActivity.this, (int)(System.currentTimeMillis() + i), sent, flags));
                }
                if (parts.size() == 1) {
                    manager.sendTextMessage(phone, null, message, sentIntents.get(0), null);
                } else {
                    manager.sendMultipartTextMessage(phone, null, parts, sentIntents, null);
                }
                return "queued";
            } catch (Exception e) {
                return "error:" + e.getClass().getSimpleName();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SMS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            String js = "window.onSmsPermissionResult && window.onSmsPermissionResult(" + granted + ");";
            webView.evaluateJavascript(js, null);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (smsReceiver != null) {
            try { unregisterReceiver(smsReceiver); } catch (Exception ignored) { }
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
