THAKUR TEMPLE RUN
=================

Files
-----
index.html : Complete mobile-friendly 3D endless-runner game.

How to play
-----------
1. Open index.html in a modern browser (Chrome recommended).
2. Internet is required because Three.js is loaded from jsDelivr CDN.
3. Tap "गेम शुरू करें".
4. Use ◀ and ▶ to change lanes, JUMP to jump.
5. You can also swipe left/right/up on the game screen.

Controls
--------
Left / Right arrow keys: change lane
Up arrow / Space: jump
Touch buttons: mobile controls
Swipe left / right / up: mobile gesture controls

Notes
-----
- This is a browser HTML game, not an APK.
- For the 3D engine to load, the device needs an internet connection.
- If you later want an offline version, the Three.js library must be bundled locally.
