// Plugins compartilhados pelos módulos. As versões ficam aqui para o projeto inteiro.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
