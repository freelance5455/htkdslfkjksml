# SaturnIA para Android

Aplicativo Android nativo (Kotlin) que hospeda a SaturnIA em uma WebView, com um serviço de voz
em primeiro plano e uma ponte segura entre o HTML e o código nativo.

O HTML, CSS, JavaScript, o design e a integração com a IA (Worker) são os mesmos da versão web.
As alterações no HTML foram mínimas e estão listadas abaixo.

## Status do projeto (leia antes de tudo)

- **O APK não foi compilado nem executado em um aparelho neste ambiente.** O ambiente de
  desenvolvimento não tem acesso aos repositórios do Android SDK, Google Maven e Gradle,
  então nada foi montado de ponta a ponta.
- **Verificado neste ambiente:**
  - Todos os arquivos XML são bem-formados.
  - Os arquivos Kotlin passam pela checagem de sintaxe do compilador Kotlin 2.0. Restaram
    apenas erros de referências ao SDK do Android, que só podem ser resolvidos com o SDK instalado.
  - A lógica de reconhecimento da frase de ativação (`WakeWord`) foi executada com os 7 casos do
    teste unitário: todos passaram.
  - O HTML foi testado em Chromium headless com uma ponte nativa simulada: frase padrão
    "Ei, SaturnIA", todos os estados (ativo, inativo, sem permissão, indisponível, erro, interrompido),
    `listApps`, `launch` (verdadeiro e falso), comando nativo chegando à página e resposta
    falada pela ponte. Sem erros de JavaScript.
- **Ainda não verificado:** build com Gradle, instalação, permissões em aparelho real, escuta em
  segundo plano, bateria, login Firebase dentro da WebView. Esses pontos precisam de teste no
  aparelho (checklist abaixo).

## Estrutura

```
saturnia-android/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── .gitignore
├── README.md
└── app/
    ├── build.gradle.kts
    ├── src/main/
    │   ├── AndroidManifest.xml
    │   ├── assets/saturnia/index.html      ← cópia do HTML da SaturnIA (com as alterações listadas)
    │   ├── java/com/serius/saturnia/
    │   │   ├── MainActivity.kt             ← WebView, permissões, seletor de arquivos, downloads
    │   │   ├── SaturnBridge.kt             ← window.SaturnIANative (ponte JavaScript)
    │   │   ├── VoiceService.kt             ← serviço em primeiro plano com a escuta
    │   │   ├── VoiceState.kt               ← estado do serviço e fila de comandos
    │   │   ├── VoicePrefs.kt               ← frase de ativação salva no aparelho
    │   │   └── WakeWord.kt                 ← reconhecimento da frase (função pura, testada)
    │   └── res/
    │       ├── drawable/ic_notification.xml
    │       ├── drawable/ic_launcher_foreground.xml
    │       ├── mipmap-anydpi-v26/ic_launcher.xml
    │       ├── mipmap-anydpi-v26/ic_launcher_round.xml
    │       └── values/{strings,colors,themes}.xml
    └── src/test/java/com/serius/saturnia/WakeWordTest.kt
```

## Como compilar e instalar

Requisitos: **JDK 17**, **Android Studio Iguana (2023.2) ou mais novo** (ou o Android SDK com
command line tools), e Gradle 8.9 para gerar o wrapper.

1. Abra a pasta `saturnia-android` no Android Studio e aguarde a sincronização.
   Se o Studio pedir para instalar o SDK da plataforma 34, aceite.
2. Gere o Gradle wrapper (uma vez, na raiz do projeto), com o Gradle instalado:
   ```bash
   gradle wrapper --gradle-version 8.9
   ```
   Isso cria `gradlew`, `gradlew.bat` e `gradle/wrapper/gradle-wrapper.jar`, que não estão no projeto.
3. Compile o APK de depuração:
   ```bash
   ./gradlew assembleDebug
   ```
   O arquivo fica em `app/build/outputs/apk/debug/app-debug.apk`.
4. Rode os testes unitários da frase de ativação:
   ```bash
   ./gradlew testDebugUnitTest
   ```
5. Instale no aparelho (depuração USB ligada):
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

Para usar a versão publicada no site em vez do HTML empacotado, defina `SATURNIA_URL` em
`app/build.gradle.kts` (ex.: `"\"https://seu-dominio.exemplo\""`). Com o campo vazio, o app usa o
HTML empacotado em `assets/saturnia/`.

## Antes de publicar: ajuste obrigatório no Worker

A WebView envia requisições com a origem `https://appassets.androidplatform.net` (o endereço
interno onde o HTML empacotado roda). O Worker só aceita origens listadas em `ALLOWED_ORIGINS`.
**Adicione `https://appassets.androidplatform.net` a `ALLOWED_ORIGINS`**, senão as chamadas à IA
serão bloqueadas pelo CORS no app. Eu não alterei o Worker publicado.

Se usar `SATURNIA_URL` (site remoto), a origem é a do próprio site, que já deve estar na lista.

## Como funciona o assistente de voz

- Na tela de ajustes da SaturnIA, o switch **"Assistente de voz em segundo plano"** liga o serviço.
  O app pede a permissão de microfone e, no Android 13+, de notificações. Sem elas, o status mostra
  "sem permissão" e o serviço não inicia.
- O serviço fica em primeiro plano com uma notificação persistente e o botão **Parar**.
- Ele escuta em ciclos curtos. Quando ouve a frase de ativação (padrão **"Ei, SaturnIA"**), o que
  vem depois é enviado ao HTML como comando. Se a frase vier sozinha, o próximo trecho falado é o comando.
- Os comandos passam pelo fluxo normal da SaturnIA (mesma IA, mesmas ações). As respostas são lidas
  em voz alta pelo sintetizador do aparelho, em português (Brasil), se a opção de som estiver ativa.
- Nenhum áudio é gravado em disco pelo app.
- O status aparece no ajuste como **ativo**, **inativo** (desativado pelo usuário), **sem permissão**,
  **interrompido pelo sistema**, **erro** ou **não disponível neste aparelho**.

### Tratamento de erros

| Situação | Comportamento |
|---|---|
| Silêncio (sem fala) | Normal, volta a aguardar a frase. Não é erro. |
| Sem conexão | Tenta de novo com espera crescente (1s, 2s, 4s, 8s). Após várias falhas, desliga e mostra erro. |
| Microfone ocupado por outro app | Estado "interrompido", tenta de novo. |
| Permissão negada | Estado "sem permissão". O serviço não inicia. |
| Português indisponível no reconhecedor | Tenta o reconhecedor padrão; se também falhar, mostra erro. |
| Aparelho sem reconhecimento de voz | Estado "não disponível". |
| Página fechada | Comandos ficam na fila (até 5) e são entregues quando o app voltar. |

## Segurança e privacidade

- **Sem chaves de API no app.** As chaves continuam no Worker (Cloudflare). Nada disso está no APK.
- **Ponte mínima.** `window.SaturnIANative` expõe apenas: `startVoiceService`, `stopVoiceService`,
  `getVoiceServiceState`, `setWakePhrase`, `speak`, `listApps` e `launch`. Nenhuma função executa
  código, lê arquivos ou acessa a rede.
- **`launch(pkg)`** só abre apps que aparecem na lista de apps do aparelho.
- **Navegação restrita.** Links externos abrem no navegador do aparelho; a WebView só carrega a
  própria página (e o domínio configurado em `SATURNIA_URL`).
- **Permissões só quando necessárias.** O microfone é pedido ao ligar o assistente, não na abertura.
  Câmera e outros recursos da página são negados.
- **Consentimento.** Nada é ouvido sem o usuário ligar o switch. Enquanto o serviço roda, a
  notificação fica visível e o botão **Parar** está disponível a qualquer momento.
- **Sem acessibilidade.** O app não usa serviço de acessibilidade para contornar restrições.
- **Backup do Android desligado** (`allowBackup=false`) para não copiar dados locais.
- **Sem tráfego em texto puro** (`usesCleartextTraffic=false`).

## Limites reais (importante)

1. **Escuta contínua não é garantida.** O reconhecedor do Android foi feito para frases isoladas,
   não para escuta permanente. O serviço reinicia os ciclos, mas pode haver pequenas falhas entre
   uma frase e outra.
2. **Áudio e reconhecimento.** Por padrão o Android envia o áudio ao serviço de reconhecimento de
   voz do aparelho (em geral do Google), mesmo com o assistente ligado. Se o modelo offline de
   português estiver instalado, o app o usa; o próprio sistema decide. Não há como garantir
   processamento 100% no aparelho sem um detector de palavra-chave dedicado (ver alternativas).
3. **Android 14.** O serviço de microfone só pode iniciar com a permissão já concedida e com a
   interface em primeiro plano. Por isso o início é feito pelo switch dentro do app.
4. **Economia de bateria do fabricante.** Samsung, Xiaomi, Motorola e outros podem encerrar o serviço.
   Se isso acontecer, o status mostra "interrompido" ou "erro". Para evitar, ajuste o app para
   "Sem restrições" em Ajustes > Aplicativos > SaturnIA > Bateria.
5. **Só funciona com o processo vivo.** Comandos e respostas dependem da WebView. Ao apertar Voltar
   com o assistente ligado, o app vai para segundo plano (não fecha) para manter a escuta. Se o
   sistema encerrar o app, o serviço para e o status mostra isso.
6. **Não inicia sozinho.** Depois de reiniciar o aparelho, o usuário liga o assistente de novo.
7. **Login Google (Firebase) dentro da WebView.** O Google bloqueia login OAuth em WebViews
   embutidas. O login pode falhar. Não testado. Alternativa: abrir o login em uma Custom Tab.
8. **Pop-ups (`window.open`) não são suportados.** Links abrem no navegador do aparelho.
9. **Downloads.** Só `http`/`https` são baixados. Arquivos gerados em `blob:` (ex.: alguns PDFs)
   não são suportados nesta versão. Em Android 9 e anteriores, o arquivo vai para a pasta do app.
10. **Ponte exposta à página.** `addJavascriptInterface` fica disponível para todos os frames da
    WebView, inclusive iframes de terceiros, se houver algum na página. A mitigação atual é restringir
    a navegação, mas o risco permanece. A alternativa mais segura é `WebViewCompat.addWebMessageListener`
    com `allowedOriginRules`, que exige reescrever a ponte como chamadas assíncronas (ver alternativas).
11. **Respostas de voz só enquanto o processo estiver vivo.** O sintetizador é do app.

## Alternativas, se os limites atrapalharem

- **Detector de palavra-chave no aparelho** (ex.: Porcupine ou openWakeWord, com um modelo treinado
  para "Ei, SaturnIA"). Ele escuta sem enviar áudio a serviços externos e é mais estável em segundo
  plano. Exige licença e treinamento do modelo.
- **Ponte com `WebMessageListener`** e regras de origem: fecha a exposição a iframes. Exige
  mudar o HTML para chamadas assíncronas.
- **Login em Custom Tab** (ou App Link de volta para o app) em vez de login dentro da WebView.

## Alterações no HTML (index.html, copiado para assets/saturnia/)

Todas as mudanças são pequenas e aditivas. A versão web continua funcionando sem o aplicativo
(a ponte só é usada quando `window.SaturnIANative` existe).

1. Frase de ativação padrão: **"Ei, SaturnIA"** (antes "OK, SaturnIA"). Vale também para a versão web.
2. Novo estado **unavailable** no mapa de status (`bgState`), com a mensagem
   "Ativação por voz contínua não disponível neste aparelho".
3. Ao salvar a frase, o HTML chama `SaturnIANative.setWakePhrase` (se existir).
4. Novas funções globais `window.saturniaNativeCommand(texto)` e `window.saturniaNativeStatus()`,
   chamadas pelo código nativo.
5. Na inicialização, a frase salva é enviada ao código nativo.
6. Comandos vindos do código nativo usam a flag `NATIVE_CMD`: não reabrem a escuta do navegador e
   a resposta é lida pela ponte (`SaturnIANative.speak`), se a opção de som estiver ativa.
7. `launch` agora devolve um booleano (`false` quando o app não abre), e o HTML trata esse caso.

## Arquivos substituídos

A pasta `/mnt/attach/outputs/android-nativo/` (rascunho anterior: `SaturnNativeBridge.kt`,
`VoiceForegroundService.kt`, `AndroidManifest-trechos.xml`, `README.md`) não foi compilada e foi
substituída por este projeto. Pode ser apagada.

## Checklist de teste no aparelho (Android 8 a 14)

- [ ] O app abre e carrega a SaturnIA (sem tela branca).
- [ ] Ligar o switch pede microfone (e notificações no Android 13+).
- [ ] Negar a permissão mostra "sem permissão" e o switch não fica "ativo".
- [ ] Com permissões, a notificação aparece e o status vira "ativo".
- [ ] Dizer "Ei, SaturnIA" e depois um comando executa a ação (ex.: abrir um app) e fala a resposta.
- [ ] Dizer só "Ei, SaturnIA" e depois o comando: funciona.
- [ ] Botão "Parar" na notificação desliga e mostra "inativo".
- [ ] Sem internet: mostra erro de conexão depois de algumas tentativas.
- [ ] Apertar Voltar com o assistente ligado: o app vai para segundo plano e a escuta continua.
- [ ] Após 30 minutos com a tela apagada, a escuta continua (testar no fabricante do aparelho).
- [ ] Chat com a IA funciona dentro do app (confirma o CORS do Worker).
- [ ] Anexar um arquivo abre o seletor do Android.
