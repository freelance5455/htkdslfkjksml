plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.serius.saturnia"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.serius.saturnia"
        minSdk = 26          // Android 8.0 ou superior
        targetSdk = 34       // Android 14: exige tipo de serviço em primeiro plano e permissão FOREGROUND_SERVICE_MICROPHONE
        versionCode = 1
        versionName = "1.0.0"

        // Endereço público do site SaturnIA (HTTPS). Vazio = usa o HTML empacotado em assets/saturnia/.
        // ATENÇÃO: o login Google (Firebase) pode não funcionar dentro de WebView; ver README.md.
        buildConfigField("String", "SATURNIA_URL", "\"\"")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")

    testImplementation("junit:junit:4.13.2")
}
