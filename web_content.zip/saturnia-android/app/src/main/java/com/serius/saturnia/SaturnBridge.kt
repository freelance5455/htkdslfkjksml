package com.serius.saturnia

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Ponte entre o HTML (window.SaturnIANative) e o código nativo.
 *
 * Segurança:
 *  - Só expõe as funções listadas abaixo. Nenhuma delas recebe código, URL ou caminho de arquivo.
 *  - launch() só abre apps que já têm ícone na tela inicial (validado pelo PackageManager).
 *  - Nenhuma chave de API existe aqui: as chamadas de IA continuam no Worker.
 *  - A ponte é exposta à página. Veja README: a WebView só carrega a própria página
 *    (ou a URL configurada) e bloqueia navegação para outros sites.
 */
class SaturnBridge(private val activity: MainActivity) {

    private var tts: TextToSpeech? = null
    @Volatile
    private var ttsReady = false

    init {
        tts = TextToSpeech(activity) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("pt", "BR"))
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    fun shutdown() {
        ttsReady = false
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    // ----------------------------------------------------- serviço de voz

    /** Chamado pelo switch "Assistente de voz em segundo plano" quando o usuário liga. */
    @JavascriptInterface
    fun startVoiceService() {
        activity.runOnUiThread { activity.requestVoiceStart() }
    }

    /** Chamado quando o usuário desliga o switch. */
    @JavascriptInterface
    fun stopVoiceService() {
        VoiceService.stop(activity)
        VoiceState.set(VoiceState.STOPPED)
    }

    /** Estado atual: stopped, starting, running, interrupted, error, permission ou unavailable. */
    @JavascriptInterface
    fun getVoiceServiceState(): String = VoiceState.state

    @JavascriptInterface
    fun setWakePhrase(phrase: String) {
        VoicePrefs.setWake(activity, phrase)
    }

    // ----------------------------------------------------- respostas faladas

    /** Lê a resposta em voz alta (pt-BR). Sem efeito se o TTS não estiver pronto. */
    @JavascriptInterface
    fun speak(text: String) {
        val clean = text.trim().take(4000)
        if (clean.isEmpty()) return
        activity.runOnUiThread {
            if (ttsReady) {
                tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "saturnia-${System.nanoTime()}")
            }
        }
    }

    // ----------------------------------------------------- apps do aparelho

    /**
     * Lista os apps com ícone na tela inicial, como JSON:
     * [{"pkg":"...","name":"...","icon":null,"cat":"SOCIAL"}]
     */
    @JavascriptInterface
    fun listApps(): String {
        val pm = activity.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val array = JSONArray()
        for (info in pm.queryIntentActivities(launcherIntent, 0)) {
            val pkg = info.activityInfo.packageName
            if (pkg == activity.packageName || !seen.add(pkg)) continue
            val appInfo: ApplicationInfo = try {
                pm.getApplicationInfo(pkg, 0)
            } catch (e: Exception) {
                continue
            }
            val name = info.loadLabel(pm).toString()
            array.put(
                JSONObject()
                    .put("pkg", pkg)
                    .put("name", name)
                    .put("icon", JSONObject.NULL)
                    .put("cat", categoryKey(appInfo.category))
            )
        }
        return array.toString()
    }

    /** Abre um app pelo nome do pacote. Retorna false se não for possível. */
    @JavascriptInterface
    fun launch(pkg: String): Boolean {
        if (pkg.isBlank() || pkg.length > 200) return false
        val intent = activity.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun categoryKey(category: Int): String = when (category) {
        ApplicationInfo.CATEGORY_GAME -> "GAME"
        ApplicationInfo.CATEGORY_AUDIO -> "AUDIO"
        ApplicationInfo.CATEGORY_VIDEO -> "VIDEO"
        ApplicationInfo.CATEGORY_IMAGE -> "IMAGE"
        ApplicationInfo.CATEGORY_SOCIAL -> "SOCIAL"
        ApplicationInfo.CATEGORY_NEWS -> "NEWS"
        ApplicationInfo.CATEGORY_MAPS -> "MAPS"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "PRODUCTIVITY"
        else -> ""
    }
}
