package com.serius.saturnia

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Serviço em primeiro plano que escuta a frase de ativação enquanto o app está aberto
 * ou em segundo plano.
 *
 * Como funciona:
 *  - Usa o SpeechRecognizer em ciclos curtos (um ciclo = uma frase falada).
 *  - Se a transcrição contém a frase de ativação, o texto depois dela vira um comando,
 *    entregue à WebView por VoiceState.postCommand().
 *  - Se a frase vier sozinha, o próximo ciclo captura o comando.
 *  - Não grava áudio em disco. O áudio só é enviado ao reconhecedor enquanto o serviço está ligado.
 *
 * Limites reais (ver README): o reconhecedor do Android não foi feito para escuta contínua,
 * o aparelho pode encerrar serviços por economia de bateria, e o Android 14 exige que
 * a permissão de microfone esteja concedida no momento de iniciar o serviço.
 */
class VoiceService : Service() {

    companion object {
        private const val ACTION_START = "com.serius.saturnia.action.START_VOICE"
        private const val ACTION_STOP = "com.serius.saturnia.action.STOP_VOICE"
        private const val CHANNEL_ID = "saturnia_voice"
        private const val NOTIFICATION_ID = 4101
        private const val MAX_CONSECUTIVE_ERRORS = 4
        private const val POST_NOTIFICATIONS = "android.permission.POST_NOTIFICATIONS"

        /** Inicia o serviço. Deve ser chamado com a interface do app em primeiro plano. */
        fun start(context: Context) {
            val intent = Intent(context, VoiceService::class.java).setAction(ACTION_START)
            ContextCompat.startForegroundService(context, intent)
        }

        /** Pede para parar. Se o serviço não estiver rodando, apenas termina sem efeito. */
        fun stop(context: Context) {
            val intent = Intent(context, VoiceService::class.java).setAction(ACTION_STOP)
            try {
                context.startService(intent)
            } catch (e: IllegalStateException) {
                VoiceState.set(VoiceState.STOPPED)
            }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var useOnDevice = false
    private var running = false
    private var awaitingCommand = false
    private var consecutiveErrors = 0

    private val restartRunnable = Runnable { listen() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown(VoiceState.STOPPED)
            return START_NOT_STICKY
        }

        // Já está escutando: não reinicia nada.
        if (running) return START_NOT_STICKY

        // Sem permissão, não entra em primeiro plano: apenas informa e encerra.
        if (!hasRequiredPermissions()) {
            VoiceState.set(VoiceState.PERMISSION, "Permissão de microfone ou notificações ausente.")
            stopSelf()
            return START_NOT_STICKY
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            VoiceState.set(VoiceState.UNAVAILABLE, "Este aparelho não tem serviço de reconhecimento de voz.")
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()

        running = true
        awaitingCommand = false
        consecutiveErrors = 0
        useOnDevice = Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
        VoiceState.set(VoiceState.STARTING, "")
        main.post { listen() }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacks(restartRunnable)
        recognizer?.destroy()
        recognizer = null
        if (running) {
            running = false
            VoiceState.set(VoiceState.STOPPED)
        }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- escuta

    private fun listen() {
        if (!running) return
        if (!hasRequiredPermissions()) {
            shutdown(VoiceState.PERMISSION, "Permissão de microfone ou notificações foi removida.")
            return
        }

        val rec = recognizer ?: createRecognizer().also { recognizer = it }
        rec.setRecognitionListener(listener)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, useOnDevice)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        }

        try {
            rec.startListening(intent)
        } catch (e: Exception) {
            retryLater(VoiceState.ERROR, "Não foi possível iniciar a escuta (${e.javaClass.simpleName}).")
        }
    }

    private fun createRecognizer(): SpeechRecognizer =
        if (useOnDevice && Build.VERSION.SDK_INT >= 31) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this)
        }

    private fun scheduleRestart(delayMs: Long) {
        main.removeCallbacks(restartRunnable)
        main.postDelayed(restartRunnable, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            if (awaitingCommand) {
                VoiceState.set(VoiceState.RUNNING, "Pode falar o comando.")
            } else {
                VoiceState.set(VoiceState.RUNNING, "Aguardando “${VoicePrefs.wake(this@VoiceService)}”.")
            }
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            consecutiveErrors = 0
            val texts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            handleTranscripts(texts)
        }

        override fun onError(error: Int) {
            handleError(error)
        }
    }

    private fun handleTranscripts(texts: List<String>) {
        if (!running) return
        val phrase = VoicePrefs.wake(this)

        // A frase de ativação veio antes; agora o próximo trecho é o comando.
        if (awaitingCommand) {
            awaitingCommand = false
            val raw = texts.firstOrNull()?.trim().orEmpty()
            val command = (WakeWord.match(raw, phrase) ?: raw).trim()
            if (command.isNotEmpty()) deliver(command)
            scheduleRestart(300)
            return
        }

        for (text in texts) {
            val rest = WakeWord.match(text, phrase) ?: continue
            if (rest.isEmpty()) {
                // Ouviu só a frase: aguarda o comando no próximo ciclo.
                awaitingCommand = true
                scheduleRestart(200)
            } else {
                deliver(rest)
                scheduleRestart(300)
            }
            return
        }

        scheduleRestart(200)
    }

    private fun deliver(command: String) {
        VoiceState.set(VoiceState.RUNNING, "Comando recebido.")
        VoiceState.postCommand(command)
    }

    private fun handleError(error: Int) {
        if (!running) return
        when (error) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                // Silêncio normal: não é falha. Volta a aguardar a frase.
                awaitingCommand = false
                consecutiveErrors = 0
                scheduleRestart(200)
            }

            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                shutdown(VoiceState.PERMISSION, "Permissão de microfone negada.")

            SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                retryLater(VoiceState.INTERRUPTED, "O microfone está em uso por outro app.")

            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> {
                if (useOnDevice) {
                    // O modelo offline não tem português: tenta o reconhecedor padrão uma vez.
                    useOnDevice = false
                    recognizer?.destroy()
                    recognizer = null
                    scheduleRestart(300)
                } else {
                    shutdown(VoiceState.ERROR, "Reconhecimento de português (Brasil) indisponível neste aparelho.")
                }
            }

            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
            SpeechRecognizer.ERROR_SERVER ->
                retryLater(VoiceState.ERROR, "Sem conexão com o serviço de reconhecimento de voz.")

            else -> retryLater(VoiceState.ERROR, "Falha no reconhecimento de voz (código $error).")
        }
    }

    /** Tenta de novo com espera crescente; desiste depois de algumas falhas seguidas. */
    private fun retryLater(state: String, detail: String) {
        awaitingCommand = false
        consecutiveErrors++
        if (consecutiveErrors > MAX_CONSECUTIVE_ERRORS) {
            shutdown(state, "$detail Desligado após várias tentativas.")
            return
        }
        VoiceState.set(state, "$detail Tentando de novo.")
        val delay = 1000L shl (consecutiveErrors - 1)
        scheduleRestart(delay)
    }

    // ---------------------------------------------------------------- ciclo de vida

    private fun shutdown(finalState: String, detail: String = "") {
        running = false
        main.removeCallbacks(restartRunnable)
        recognizer?.destroy()
        recognizer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        VoiceState.set(finalState, detail)
        stopSelf()
    }

    private fun hasRequiredPermissions(): Boolean {
        val mic = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        val notifications = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        return mic && notifications
    }

    private fun startAsForeground() {
        createChannel()
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type)
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Assistente de voz",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Aparece enquanto o assistente de voz da SaturnIA está escutando."
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("SaturnIA: assistente de voz ativo")
            .setContentText("Diga “${VoicePrefs.wake(this)}” para dar um comando.")
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "Parar", stopIntent)
            .build()
    }
}
