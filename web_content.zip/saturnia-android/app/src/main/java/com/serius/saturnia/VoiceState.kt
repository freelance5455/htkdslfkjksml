package com.serius.saturnia

import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Estado do serviço de voz. O HTML lê o valor com getVoiceServiceState()
 * e recebe mudanças por saturniaNativeStatus().
 *
 * Também guarda os comandos ouvidos enquanto a WebView não está pronta para recebê-los.
 */
object VoiceState {
    const val STOPPED = "stopped"          // desligado pelo usuário
    const val STARTING = "starting"        // ligando
    const val RUNNING = "running"          // escutando
    const val INTERRUPTED = "interrupted"  // o microfone foi tomado por outro app
    const val ERROR = "error"              // falha (rede, reconhecedor, idioma)
    const val PERMISSION = "permission"    // falta permissão de microfone ou notificações
    const val UNAVAILABLE = "unavailable"  // o aparelho não tem reconhecimento de voz

    private const val MAX_PENDING = 5

    @Volatile
    var state: String = STOPPED
        private set

    @Volatile
    var detail: String = ""
        private set

    private val stateListeners = CopyOnWriteArrayList<(String) -> Unit>()
    private val commandListeners = CopyOnWriteArrayList<() -> Unit>()

    /** Comandos ouvidos sem a interface pronta; entregues quando ela estiver disponível. */
    private val pending = ConcurrentLinkedQueue<String>()

    fun set(newState: String, newDetail: String = "") {
        if (newState == state && newDetail == detail) return
        state = newState
        detail = newDetail
        stateListeners.forEach { it(newState) }
    }

    fun addStateListener(listener: (String) -> Unit) {
        stateListeners.add(listener)
    }

    fun removeStateListener(listener: (String) -> Unit) {
        stateListeners.remove(listener)
    }

    fun addCommandListener(listener: () -> Unit) {
        commandListeners.add(listener)
    }

    fun removeCommandListener(listener: () -> Unit) {
        commandListeners.remove(listener)
    }

    /** Guarda um comando (limitado aos últimos MAX_PENDING) e avisa quem estiver ouvindo. */
    fun postCommand(text: String) {
        pending.offer(text)
        while (pending.size > MAX_PENDING) pending.poll()
        commandListeners.forEach { it() }
    }

    /** Retira o próximo comando pendente, se houver. */
    fun takeCommand(): String? = pending.poll()
}
