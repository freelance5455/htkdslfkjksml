package com.serius.saturnia

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/**
 * Hospeda a SaturnIA em uma WebView. O HTML, CSS e JS são os mesmos do site,
 * copiados para app/src/main/assets/saturnia/index.html.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        /** Domínio interno do WebViewAssetLoader: a página local roda sob https, sem servidor. */
        private const val LOCAL_HOST = "appassets.androidplatform.net"
        private const val LOCAL_START = "https://$LOCAL_HOST/assets/saturnia/index.html"
    }

    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var bridge: SaturnBridge? = null

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingMicRequest: PermissionRequest? = null
    private var voicePermissionPending = false

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        fileCallback?.onReceiveValue(uris.takeIf { it.isNotEmpty() }?.toTypedArray())
        fileCallback = null
    }

    /** Permissão de microfone pedida pela própria página (ex.: ditado do chat). */
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val request = pendingMicRequest
        pendingMicRequest = null
        if (granted) {
            request?.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
        } else {
            request?.deny()
        }
    }

    /** Permissões do assistente de voz (microfone e notificações), pedidas só ao ligar o recurso. */
    private val voicePermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            voicePermissionPending = false
            if (missingVoicePermissions().isEmpty()) {
                VoiceService.start(this)
            } else {
                VoiceState.set(
                    VoiceState.PERMISSION,
                    "Permissão negada. Ative o microfone e as notificações nos ajustes do aparelho."
                )
            }
        }

    private val stateListener: (String) -> Unit = { _ ->
        runOnUiThread { pushStatusToPage() }
    }

    private val commandListener: () -> Unit = {
        runOnUiThread { drainCommandsToPage() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        configureWebView()
        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    webView.canGoBack() -> webView.goBack()
                    // Com o assistente ligado, o app vai para segundo plano e a escuta continua.
                    VoiceState.state != VoiceState.STOPPED -> moveTaskToBack(true)
                    else -> finish()
                }
            }
        })

        VoiceState.addStateListener(stateListener)
        VoiceState.addCommandListener(commandListener)

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(startUrl())
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
        }
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        // Ponte nativa. O nome "SaturnIANative" é o que o HTML procura em window.
        bridge = SaturnBridge(this).also { webView.addJavascriptInterface(it, "SaturnIANative") }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                // Navegação dentro da própria página (ou do domínio configurado) fica na WebView.
                val allowedHosts = setOf(LOCAL_HOST, Uri.parse(BuildConfig.SATURNIA_URL).host)
                if (uri.scheme == "https" && uri.host in allowedHosts) return false
                // Qualquer outro link abre no navegador do aparelho.
                openExternal(uri)
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pushStatusToPage()
                drainCommandsToPage()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                // Só microfone. Câmera e outros recursos são negados.
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE !in request.resources) {
                    request.deny()
                    return
                }
                if (hasPermission(Manifest.permission.RECORD_AUDIO)) {
                    request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                } else {
                    pendingMicRequest?.deny()
                    pendingMicRequest = request
                    micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                if (pendingMicRequest == request) pendingMicRequest = null
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    filePicker.launch("*/*")
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    false
                }
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(url, userAgent, contentDisposition, mimeType)
        }
    }

    private fun startUrl(): String =
        BuildConfig.SATURNIA_URL.takeIf { it.isNotBlank() } ?: LOCAL_START

    // ------------------------------------------------------------ voz

    /** Chamado pela ponte quando o usuário liga o assistente. Pede as permissões que faltam. */
    fun requestVoiceStart() {
        if (voicePermissionPending) return
        val missing = missingVoicePermissions()
        if (missing.isEmpty()) {
            VoiceService.start(this)
            return
        }
        VoiceState.set(VoiceState.PERMISSION, "Conceda as permissões para ativar o assistente.")
        voicePermissionPending = true
        voicePermissions.launch(missing.toTypedArray())
    }

    private fun missingVoicePermissions(): List<String> = buildList {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && !hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    /** Envia o estado atual para a página (atualiza o switch e o texto de status). */
    private fun pushStatusToPage() {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript(
            "if(window.saturniaNativeStatus)window.saturniaNativeStatus(${JSONObject.quote(VoiceState.state)});",
            null
        )
    }

    /** Entrega os comandos ouvidos enquanto a página estava indisponível. */
    private fun drainCommandsToPage() {
        if (!::webView.isInitialized) return
        while (true) {
            val command = VoiceState.takeCommand() ?: break
            webView.evaluateJavascript(
                "if(window.saturniaNativeCommand)window.saturniaNativeCommand(${JSONObject.quote(command)});",
                null
            )
        }
    }

    // ------------------------------------------------------------ links e downloads

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Nenhum app para abrir este link.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startDownload(url: String, userAgent: String, contentDisposition: String, mimeType: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" && uri.scheme != "http") {
            Toast.makeText(this, "Este tipo de download não é suportado nesta versão.", Toast.LENGTH_SHORT).show()
            return
        }
        val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
        val request = DownloadManager.Request(uri)
            .setMimeType(mimeType)
            .addRequestHeader("User-Agent", userAgent)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setTitle(fileName)

        // Em Android 9 e anteriores, a pasta pública exige permissão de escrita (não declarada).
        // Nesses casos o arquivo vai para a pasta do próprio app.
        if (Build.VERSION.SDK_INT >= 29) {
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        } else {
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, fileName)
        }

        val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        Toast.makeText(this, "Baixando $fileName", Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------ ciclo de vida

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::webView.isInitialized) webView.saveState(outState)
    }

    override fun onDestroy() {
        VoiceState.removeStateListener(stateListener)
        VoiceState.removeCommandListener(commandListener)
        bridge?.shutdown()
        bridge = null
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
