package com.serius.saturnia

import android.content.Context

/** Preferências do assistente de voz (apenas a frase de ativação; nada de áudio). */
object VoicePrefs {

    const val DEFAULT_WAKE = "Ei, SaturnIA"

    private const val FILE = "saturnia_voice"
    private const val KEY_WAKE = "wake"
    private const val MAX_WAKE_LENGTH = 60

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun wake(context: Context): String =
        prefs(context).getString(KEY_WAKE, null)?.takeIf { it.isNotBlank() } ?: DEFAULT_WAKE

    /** Salva a frase somente se ela tiver pelo menos uma palavra reconhecível. */
    fun setWake(context: Context, phrase: String) {
        val clean = phrase.trim().take(MAX_WAKE_LENGTH)
        if (WakeWord.tokens(clean).isEmpty()) return
        prefs(context).edit().putString(KEY_WAKE, clean).apply()
    }
}
