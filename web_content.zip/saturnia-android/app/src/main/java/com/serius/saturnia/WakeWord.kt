package com.serius.saturnia

import java.text.Normalizer

/**
 * Reconhece a frase de ativação dentro de uma transcrição de voz.
 * É uma função pura (sem Android), coberta por testes unitários em WakeWordTest.kt.
 */
object WakeWord {

    private val NON_ALNUM = Regex("[^a-z0-9]+")
    private val ACCENTS = Regex("\\p{Mn}+")
    private val SPACES = Regex("\\s+")

    /** Palavras normalizadas: minúsculas, sem acentos e sem pontuação. */
    fun tokens(text: String): List<String> =
        Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD)
            .replace(ACCENTS, "")
            .split(NON_ALNUM)
            .filter { it.isNotEmpty() }

    /**
     * Procura [phrase] em [transcript], palavra por palavra.
     * Devolve o texto que vem depois da frase (pode ser vazio), ou null se a frase não aparecer.
     */
    fun match(transcript: String, phrase: String): String? {
        val wake = tokens(phrase)
        if (wake.isEmpty()) return null
        val words = transcript.trim().split(SPACES).filter { it.isNotEmpty() }
        if (words.size < wake.size) return null
        val normalized = words.map { tokens(it).joinToString(" ") }

        for (start in 0..(words.size - wake.size)) {
            var found = true
            for (j in wake.indices) {
                if (normalized[start + j] != wake[j]) {
                    found = false
                    break
                }
            }
            if (found) {
                return words.drop(start + wake.size)
                    .joinToString(" ")
                    .trimStart(',', '.', ':', ';', '!', '?', ' ')
            }
        }
        return null
    }
}
