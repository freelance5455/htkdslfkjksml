package com.serius.saturnia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WakeWordTest {

    private val phrase = "Ei, SaturnIA"

    @Test
    fun frasePuraDevolveTextoVazio() {
        assertEquals("", WakeWord.match("Ei, SaturnIA", phrase))
    }

    @Test
    fun comandoLogoDepoisDaFrase() {
        assertEquals("abra o WhatsApp", WakeWord.match("Ei SaturnIA abra o WhatsApp", phrase))
    }

    @Test
    fun ignoraAcentosEMaiusculas() {
        assertEquals("qual é a capital", WakeWord.match("EI, saturnia! qual é a capital", phrase))
    }

    @Test
    fun frasePodeAparecerNoMeioDaFala() {
        assertEquals("qual o clima", WakeWord.match("oi tudo bem ei saturnia qual o clima", phrase))
    }

    @Test
    fun saturniaSozinhaNaoAtiva() {
        assertNull(WakeWord.match("saturnia tudo bem", phrase))
    }

    @Test
    fun falaSemAFraseNaoAtiva() {
        assertNull(WakeWord.match("bom dia para todos", phrase))
    }

    @Test
    fun fraseVaziaNaoAtivaNada() {
        assertNull(WakeWord.match("ei saturnia", ""))
    }
}
