GMAIL TOOLS - PROJECT ANDROID

Isi:
- Aplikasi Android sederhana yang membuka Gmail Tools secara lokal di WebView.
- Riwayat disimpan di penyimpanan browser WebView pada perangkat.
- Tidak memerlukan internet untuk fungsi pemisahan dan selisih.

Cara membuat APK:
1. Ekstrak ZIP ini di komputer.
2. Buka folder GmailTools menggunakan Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK akan muncul di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
Paket ini adalah project sumber Android Studio, bukan file APK yang sudah dikompilasi.
Build APK memerlukan Android Studio/Android SDK dan koneksi untuk mengunduh komponen Gradle pertama kali.
