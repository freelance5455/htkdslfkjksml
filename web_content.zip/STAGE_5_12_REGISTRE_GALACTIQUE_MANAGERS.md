# STAGE 5.12 — REGISTRE GALACTIQUE DES CLUBS, DAMISTES ET MANAGERS

## Intégration dans CGD V117

Le catalogue complet fourni dans `galactique_data_complete.zip` est intégré au socle V117.

### Référentiel intégré
- 5 divisions et 60 clubs (12 par division).
- 120 damistes de première génération dans les effectifs des clubs, avec genre et origine galactique.
- 24 galaxies et 48 représentants nommés (deux par galaxie) intégrés au monde galactique.
- 60 managers de clubs (MGR-C001 à MGR-C060).
- 24 sélectionneurs (MGR-S001 à MGR-S024).

### Règles de fonctionnement
- Les 36 clubs de Super League, Ligue A et Ligue B sont chargés dans les divisions actives.
- Les 24 clubs des Ligues C et D sont présents dans `world.clubCatalog` et dans le catalogue de sélection, mais restent verrouillés jusqu'à l'ouverture de leur division.
- À l'activation, `activateExpansions` récupère les 12 clubs préenregistrés de la division concernée, avec leurs effectifs et leur manager de référence.
- Les managers de clubs et les sélectionneurs sont enregistrés séparément des contrats des damistes.
- Les sélectionneurs ont pour origine la galaxie qu'ils dirigent.

### Origines des managers de clubs — règle de complétion
Les fichiers sources donnent les noms et les clubs des managers, mais ne précisent pas leur galaxie d'origine. Le jeu complète ce champ de manière déterministe en reprenant l'origine galactique du premier damiste du club correspondant. Cette attribution est une donnée générée pour le jeu, pas une information historique fournie par la source.

### Point de rapprochement des données C/D
Les noms de clubs C/D du fichier `clubs_c_d.json` ne correspondent pas aux noms des clubs indiqués pour MGR-C037 à MGR-C060 dans `managers.json`. Pour conserver les 60 managers et les 60 clubs sans perdre de données, les 24 managers C/D ont été associés par division et ordre de liste. Les noms de managers d'origine sont conservés. Cette correspondance doit être validée si un tableau de correspondance officiel est fourni ultérieurement.

### Fichiers
- `src/universe-catalog.js` : catalogue intégré consommé par le jeu.
- `data/galactique_data/` : copie des JSON, CSV et README sources pour audit.
- `tests/universe-catalog.test.js` : tests de couverture et d'activation.

### Vérification
- 280 tests automatisés réussis.

### Interface de consultation
Un écran dédié est accessible depuis **Gestion → Registre galactique**. Il présente les divisions, les clubs, les deux damistes de chaque effectif, les managers de clubs et les sélectionneurs. Les fiches sont dépliables et une recherche transversale permet de retrouver un nom, un identifiant ou une galaxie d'origine. Les divisions C et D restent visuellement signalées comme verrouillées.
