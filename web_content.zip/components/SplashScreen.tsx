
import React, { useEffect } from 'react';

const SplashScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[11000] bg-white flex flex-col items-center justify-center overflow-hidden">
      {/* Background patterns */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-50 rounded-full -mr-32 -mt-32 blur-3xl opacity-50"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-100 rounded-full -ml-32 -mb-32 blur-3xl opacity-50"></div>

      <div className="relative flex flex-col items-center animate-in fade-in zoom-in duration-1000">
        <div className="w-28 h-28 flex items-center justify-center mb-8 animate-bounce transition-all duration-1000 relative">
          <div className="absolute inset-0 bg-emerald-500/15 rounded-full blur-xl scale-90"></div>
          <img 
            src="/assets/logo-icon.svg" 
            alt="SwiftHustle SA Logo" 
            className="w-24 h-24 object-contain relative z-10 drop-shadow-xl" 
          />
        </div>
        
        <h1 className="text-3xl font-black text-gray-900 tracking-tighter mb-2">
          SwiftHustle<span className="text-emerald-600">SA</span>
        </h1>
        <p className="text-gray-400 font-bold text-[10px] uppercase tracking-[0.4em]">Gig Economy Premium</p>
      </div>

      <div className="absolute bottom-16 flex flex-col items-center">
        <div className="flex gap-1.5 mb-4">
          <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full animate-pulse"></div>
          <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full animate-pulse delay-75"></div>
          <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full animate-pulse delay-150"></div>
        </div>
        <p className="text-gray-300 text-[9px] font-black uppercase tracking-widest">Secure Connection Active</p>
      </div>
    </div>
  );
};

export default SplashScreen;