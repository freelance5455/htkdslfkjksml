
import React from 'react';
import { Gig } from '../types';

interface FeaturedGigCardProps {
  gig: Gig;
  onClick: (gig: Gig) => void;
}

const FeaturedGigCard: React.FC<FeaturedGigCardProps> = ({ gig, onClick }) => {
  return (
    <button 
      onClick={() => onClick(gig)}
      className="relative shrink-0 w-64 h-32 bg-white rounded-3xl border-2 border-[#D4AF37] shadow-lg shadow-[#D4AF37]/10 p-4 flex flex-col justify-between text-left overflow-hidden group active:scale-95 transition-all"
    >
      <div className="absolute top-0 right-0 px-3 py-1 bg-[#D4AF37] text-white text-[8px] font-black uppercase tracking-widest rounded-bl-xl z-10">
        Featured
      </div>
      
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0">
          <img src={`https://picsum.photos/seed/${gig.id}/100`} className="w-full h-full rounded-xl object-cover" alt="icon" />
        </div>
        <div className="overflow-hidden">
          <div className="flex items-center gap-1 mb-0.5">
            <h3 className="text-xs font-black text-[#1B263B] truncate uppercase tracking-tight">{gig.title}</h3>
            <svg className="w-3 h-3 text-blue-500 shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
          </div>
          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">{gig.category}</p>
        </div>
      </div>

      <div className="flex justify-between items-end">
        <div>
          <p className="text-[8px] font-black text-slate-300 uppercase tracking-tighter">Budget</p>
          <p className="text-sm font-black text-[#1B263B]">R{gig.price}</p>
        </div>
        <div className="flex items-center gap-1 bg-[#D4AF37] px-2 py-1 rounded-lg">
          <span className="text-[9px] font-black text-white uppercase tracking-widest">Apply Now</span>
          <svg className="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>

      {/* Subtle Gold Glow Overlay */}
      <div className="absolute inset-0 bg-gradient-to-tr from-[#D4AF37]/5 to-transparent pointer-events-none"></div>
    </button>
  );
};

export default FeaturedGigCard;
