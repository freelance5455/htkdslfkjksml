
import React from 'react';
import { ServiceCategory } from '../types';

interface Props {
  service: ServiceCategory;
}

const ServiceCard: React.FC<Props> = ({ service }) => {
  return (
    <div className="bg-[#0d1b35] p-8 rounded-[2.5rem] border border-blue-500/10 shadow-lg hover:shadow-cyan-500/5 transition-all duration-500 group relative overflow-hidden">
      <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full blur-2xl group-hover:bg-cyan-500/10 transition-colors"></div>
      <div className="text-4xl mb-8 bg-[#050b1a] w-20 h-20 flex items-center justify-center rounded-[1.5rem] border border-white/5 group-hover:border-cyan-500/50 transition-all shadow-inner">
        {service.icon}
      </div>
      <h3 className="text-2xl font-black mb-6 text-white group-hover:text-cyan-400 transition-colors">{service.title}</h3>
      <ul className="space-y-4">
        {service.subServices.map((sub, idx) => (
          <li key={idx} className="flex items-start text-slate-400 text-xs font-bold uppercase tracking-widest">
            <span className="w-1.5 h-1.5 bg-cyan-500 rounded-full mr-3 mt-0.5 shadow-[0_0_5px_cyan]"></span>
            {sub}
          </li>
        ))}
      </ul>
      <div className="mt-10 pt-8 border-t border-white/5">
        <button className="text-white text-[10px] font-black uppercase tracking-[0.2em] flex items-center group-hover:text-cyan-400 transition-all">
          Authorize Access
          <svg className="w-4 h-4 ml-3 group-hover:translate-x-2 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13 7l5 5m0 0l-5 5m5-5H6" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default ServiceCard;
