export interface PanicContactInfo {
  raw: string;
  cleanWhatsApp: string;
  cleanSMS: string;
  whatsAppUrl: string;
  smsUrl: string;
}

export interface PanicDispatchResult {
  latitude: number;
  longitude: number;
  mapUrl: string;
  isFallbackLocation: boolean;
  locationDescription: string;
  message: string;
  contacts: PanicContactInfo[];
}

/**
 * Format phone number for WhatsApp URL.
 * South African numbers starting with 0 (e.g. 082 123 4567) become 27821234567.
 * Leading + is stripped for wa.me.
 */
export const cleanPhoneForWhatsApp = (raw: string): string => {
  let digits = raw.replace(/[^0-9]/g, '');
  if (digits.startsWith('0')) {
    digits = '27' + digits.slice(1);
  }
  return digits;
};

/**
 * Format phone number for SMS scheme.
 */
export const cleanPhoneForSMS = (raw: string): string => {
  let trimmed = raw.trim();
  let digits = trimmed.replace(/[^0-9+]/g, '');
  if (digits.startsWith('0')) {
    digits = '+27' + digits.slice(1);
  } else if (!digits.startsWith('+') && digits.startsWith('27')) {
    digits = '+' + digits;
  }
  return digits;
};

/**
 * Acquire device geolocation coordinates with high accuracy and a safe timeout fallback.
 */
export const getGeolocationCoordinates = async (): Promise<{
  latitude: number;
  longitude: number;
  isFallback: boolean;
  description: string;
}> => {
  return new Promise((resolve) => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      resolve({
        latitude: -26.1076,
        longitude: 28.0567,
        isFallback: true,
        description: 'Sandton Central, Johannesburg (GPS Fallback)'
      });
      return;
    }

    let resolved = false;
    const timer = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        resolve({
          latitude: -26.1076,
          longitude: 28.0567,
          isFallback: true,
          description: 'Sandton Central, Johannesburg (Network Fallback)'
        });
      }
    }, 4500);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          resolve({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            isFallback: false,
            description: `Live GPS (${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)})`
          });
        }
      },
      (_err) => {
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          resolve({
            latitude: -26.1076,
            longitude: 28.0567,
            isFallback: true,
            description: 'Sandton, Johannesburg (Default Location)'
          });
        }
      },
      { timeout: 4000, enableHighAccuracy: true, maximumAge: 30000 }
    );
  });
};

/**
 * Formulates the emergency SOS message stating "I'm in danger & the location"
 */
export const generateEmergencyMessage = (
  userName: string,
  latitude: number,
  longitude: number,
  mapUrl: string
): string => {
  const name = userName?.trim() ? userName.trim() : 'SwiftHustle Member';
  return `🚨 EMERGENCY ALERT from ${name}: I'm in danger & the location is ${mapUrl} (GPS: ${latitude.toFixed(5)}, ${longitude.toFixed(5)}). Please send help or contact authorities immediately!`;
};

/**
 * Prepare panic dispatch package with location and URLs for each emergency contact.
 */
export const preparePanicDispatch = async (
  userName: string,
  rawContacts: string[]
): Promise<PanicDispatchResult> => {
  const { latitude, longitude, isFallback, description } = await getGeolocationCoordinates();
  const mapUrl = `https://maps.google.com/?q=${latitude.toFixed(6)},${longitude.toFixed(6)}`;
  const message = generateEmergencyMessage(userName, latitude, longitude, mapUrl);

  const validContacts = rawContacts
    .map(c => c.trim())
    .filter(c => c.length >= 6);

  const contactsData: PanicContactInfo[] = validContacts.map(phone => {
    const cleanWA = cleanPhoneForWhatsApp(phone);
    const cleanSMS = cleanPhoneForSMS(phone);
    const whatsAppUrl = `https://wa.me/${cleanWA}?text=${encodeURIComponent(message)}`;
    const smsUrl = `sms:${cleanSMS}?body=${encodeURIComponent(message)}`;

    return {
      raw: phone,
      cleanWhatsApp: cleanWA,
      cleanSMS: cleanSMS,
      whatsAppUrl,
      smsUrl
    };
  });

  return {
    latitude,
    longitude,
    mapUrl,
    isFallbackLocation: isFallback,
    locationDescription: description,
    message,
    contacts: contactsData
  };
};

/**
 * Launches the selected channel (WhatsApp or SMS) in a new tab/window or native app.
 */
export const triggerChannelLaunch = (channel: 'whatsapp' | 'sms', contact: PanicContactInfo) => {
  if (channel === 'whatsapp') {
    window.open(contact.whatsAppUrl, '_blank', 'noopener,noreferrer');
  } else {
    // For SMS on mobile and desktop
    window.location.href = contact.smsUrl;
  }
};
