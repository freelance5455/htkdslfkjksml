import React, { useState } from 'react';
import { Gig, UserStats, UserTier } from '../types';

interface ManageGigsPageProps {
  gigs: Gig[];
  stats: UserStats;
  boostCredits?: number;
  onBoost: (gigId: string) => void;
  onBack: () => void;
}

const ManageGigsPage: React.FC<ManageGigsPageProps> = ({ 
  gigs, 
  stats, 
  boostCredits = 3, 
  onBoost, 
  onBack 
}) => {
  const isPremium = stats.currentTier === UserTier.PREMIUM || stats.currentTier === UserTier.ELITE;
  const [isExiting, setIsExiting] = useState(false);
  const [recentlyBoostedId, setRecentlyBoostedId] = useState<string | null>(null);

  const handleBack = () => {
    setIsExiting(true);
    setTimeout(onBack, 300);
  };

  const handleBoostClick = (gigId: string) => {
    if (boostCredits <= 0) {
      alert("No boost credits remaining for this month.");
      return;
    }
    setRecentlyBoostedId(gigId);
    onBoost(gigId);
    setTimeout(() => setRecentlyBoostedId(null), 2500);
  };

  return (
    <div className={`flex flex-col h-full bg-[#FAFBFC] transition-transform duration-300 ${isExiting ? 'translate-x-full' : 'translate-x-0'}`}>
      <header className="bg-[#1B263B] p-4 pb-8 relative overflow-hidden shrink-0 shadow-lg">
        <div className="flex items-center gap-4 relative z-10">
          <button 
            onClick={handleBack}
            className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center text-white active:scale-90 transition-all border border-white/5"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M11 17l-5-5m0 0l5-5m-5 5h12"/></svg>
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-black text-white tracking-tight">Manage My Gigs</h1>
            <p className="text-white/40 text-[9px] font-black uppercase tracking-widest mt-1">Hustle Control Center</p>
          </div>
          {/* Quick Credit Badge in Header */}
          <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10">
            <span className="text-[#D4AF37] text-xs">⚡</span>
            <span className="text-white text-[10px] font-black">{boostCredits} Boosts</span>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4AF37]/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
      </header>

      <div className="flex-1 overflow-y-auto px-6 mt-6 no-scrollbar pb-32">
        {gigs.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-4 text-3xl">📭</div>
            <h3 className="text-lg font-black text-slate-900">No active posts</h3>
            <p className="text-xs text-slate-400 font-medium px-10 mt-2">Post a new gig from the radar screen to see it here.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {gigs.map(gig => (
              <div key={gig.id} className="bg-white rounded-[32px] p-6 shadow-sm border border-slate-50 relative overflow-hidden group">
                {gig.isFeatured && (
                  <div className="absolute top-0 right-0 px-3 py-1 bg-[#D4AF37] text-white text-[8px] font-black uppercase tracking-widest rounded-bl-xl shadow-sm flex items-center gap-1">
                    <span>★</span> Boost Active
                  </div>
                )}
                
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-sm font-black text-[#1B263B] uppercase tracking-tight">{gig.title}</h3>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{gig.category}</p>
                  </div>
                  <p className="text-sm font-black text-[#1B263B]">R{gig.price}</p>
                </div>

                <div className="flex items-center gap-2 mb-6">
                  <div className="flex items-center gap-1 bg-emerald-50 text-emerald-600 px-2 py-1 rounded-lg">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span className="text-[9px] font-black uppercase">Live on Radar</span>
                  </div>
                  <div className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">Posted {new Date(gig.datePosted).toLocaleDateString()}</div>
                </div>

                <div className="flex gap-2">
                  <button 
                    disabled={gig.isFeatured || (!gig.isFeatured && boostCredits <= 0 && isPremium)}
                    onClick={() => handleBoostClick(gig.id)}
                    className={`flex-[2] py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2
                      ${gig.isFeatured 
                        ? 'bg-slate-100 text-slate-400 shadow-none' 
                        : (isPremium 
                            ? (boostCredits > 0 
                                ? 'bg-[#D4AF37] text-white shadow-[#D4AF37]/20 hover:brightness-105' 
                                : 'bg-slate-100 text-slate-400 shadow-none cursor-not-allowed')
                            : 'bg-slate-200 text-slate-400 cursor-not-allowed')
                      }`}
                  >
                    {gig.isFeatured ? (
                      <>
                        <svg className="w-4 h-4 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"/></svg>
                        Already Boosted
                      </>
                    ) : boostCredits <= 0 && isPremium ? (
                      <>
                        <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        No Credits Left
                      </>
                    ) : (
                      <>
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                        Boost to Featured
                      </>
                    )}
                  </button>
                  <button className="flex-1 py-3 bg-slate-50 text-slate-400 border border-slate-100 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-100 transition-colors">
                    Edit
                  </button>
                </div>

                {recentlyBoostedId === gig.id && (
                  <div className="mt-2.5 p-2 bg-emerald-50 border border-emerald-100 rounded-xl text-center animate-in fade-in duration-200">
                    <p className="text-[9px] font-black text-emerald-700 uppercase tracking-wider">
                      ⚡ Gig successfully boosted! 1 Credit used.
                    </p>
                  </div>
                )}

                {!isPremium && !gig.isFeatured && (
                  <div className="mt-3 flex items-center justify-center gap-1.5 p-2 bg-amber-50 rounded-xl border border-amber-100">
                    <svg className="w-3.5 h-3.5 text-amber-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd"/></svg>
                    <p className="text-[8px] font-black text-amber-600 uppercase tracking-widest">Rank up to Elite to unlock Boosts</p>
                  </div>
                )}

                {isPremium && !gig.isFeatured && boostCredits === 0 && (
                  <div className="mt-3 flex items-center justify-center gap-1.5 p-2 bg-slate-50 rounded-xl border border-slate-100">
                    <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">You have used all 3 monthly boosts</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="mt-8 p-6 bg-gradient-to-br from-[#1B263B] to-slate-900 rounded-[40px] text-white shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#D4AF37]/20 rounded-full -mr-12 -mt-12 blur-2xl"></div>
          <h4 className="text-sm font-black mb-1 uppercase tracking-widest">Premium Benefits</h4>
          <p className="text-[10px] text-white/50 leading-relaxed font-medium mb-4">
            Elite and Premium members get 3 free monthly boosts. Boosted gigs appear at the top of the radar with a Gold marker.
          </p>
          <div className="flex items-center justify-between">
            <span className={`px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all ${
              boostCredits > 0 ? 'bg-[#D4AF37] text-slate-950' : 'bg-slate-700 text-slate-300'
            }`}>
              Available Credits: {boostCredits}
            </span>
            {boostCredits === 0 ? (
              <span className="text-[8px] font-black text-amber-400 uppercase tracking-wider">
                Refills on 1st of month
              </span>
            ) : (
              <span className="text-[8px] font-bold text-white/40 uppercase tracking-wider">
                {boostCredits} of 3 remaining
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageGigsPage;
