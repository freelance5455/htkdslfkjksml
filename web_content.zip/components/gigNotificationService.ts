import { Gig, HighPayingGigAlert, EmployerHustlerMatchAlert, AvailableHustler, PushNotificationSettings } from '../types';

export const AVAILABLE_SKILLS = [
  'Electrical',
  'Handyman',
  'Plumbing',
  'Painting',
  'Cleaning',
  'Carpentry',
  'Gardening',
  'Moving',
  'Tech Support',
  'General'
] as const;

export const DEFAULT_PUSH_SETTINGS: PushNotificationSettings = {
  enabled: true,
  immediateRadiusKm: 5, // Strictly immediate 5km radius for hustlers
  highPayingThreshold: 800, // R800+ threshold for high-paying gigs in SA
  skillsOnly: true, // Only alert when matching user's skill set
  soundEnabled: true,
  browserPushEnabled: true,
  employerMatchAlertsEnabled: true, // Alert employers when available hustlers match posted gigs
  minHustlerRating: 4.5 // Minimum rating for employer alerts
};

/**
 * Standard Haversine distance in kilometers between two GPS coordinates
 */
export function calculateDistanceKm(loc1: [number, number], loc2: [number, number]): number {
  const [lat1, lon1] = loc1;
  const [lat2, lon2] = loc2;
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

const SKILL_KEYWORDS: Record<string, string[]> = {
  'Electrical': ['electrical', 'electric', 'wire', 'wiring', 'inverter', 'battery', 'solar', 'db board', 'circuit', 'power', 'plugs', 'cctv'],
  'Plumbing': ['plumbing', 'plumber', 'pipe', 'leak', 'drain', 'geyser', 'tap', 'toilet', 'sink', 'water', 'burst'],
  'Handyman': ['handyman', 'assemble', 'assembly', 'cabinet', 'mount', 'drill', 'fix', 'repair', 'door', 'lock', 'curtain', 'shelf'],
  'Painting': ['paint', 'painting', 'painter', 'wall', 'primer', 'coat', 'perimeter', 'ceiling'],
  'Cleaning': ['clean', 'cleaning', 'cleaner', 'deep clean', 'wash', 'laundry', 'carpet', 'window'],
  'Carpentry': ['carpenter', 'carpentry', 'wood', 'cupboard', 'furniture', 'timber', 'deck', 'cabinetry'],
  'Gardening': ['garden', 'gardening', 'lawn', 'mow', 'tree', 'bush', 'grass', 'hedge', 'weeds'],
  'Moving': ['moving', 'relocation', 'furniture', 'boxes', 'truck', 'bakkie', 'van', 'haul', 'unpack'],
  'Tech Support': ['tech', 'computer', 'wifi', 'network', 'router', 'laptop', 'software', 'tv', 'setup'],
  'General': ['general', 'labor', 'errands', 'helper', 'assist', 'yard', 'rubble']
};

/**
 * Checks if a gig matches any of the user's skills
 */
export function matchGigToSkills(gig: Gig, userSkills: string[]): string | null {
  if (!userSkills || userSkills.length === 0) return null;

  const gigCategory = (gig.category || '').toLowerCase();
  const gigTitle = (gig.title || '').toLowerCase();
  const gigDesc = (gig.description || '').toLowerCase();
  const gigContent = `${gigCategory} ${gigTitle} ${gigDesc}`;

  for (const skill of userSkills) {
    const sLower = skill.toLowerCase();
    
    // Direct category match
    if (gigCategory.includes(sLower) || sLower.includes(gigCategory)) {
      return skill;
    }

    // Direct title/desc match with skill name
    if (gigTitle.includes(sLower) || gigDesc.includes(sLower)) {
      return skill;
    }

    // Keyword match
    const keywords = SKILL_KEYWORDS[skill] || [sLower];
    for (const kw of keywords) {
      if (gigContent.includes(kw)) {
        return skill;
      }
    }
  }

  return null;
}

/**
 * Evaluates whether a gig meets all conditions for a high-paying 5km push alert
 */
export function evaluateGigForAlert(
  gig: Gig,
  userLocation: [number, number],
  userSkills: string[],
  settings: PushNotificationSettings = DEFAULT_PUSH_SETTINGS
): HighPayingGigAlert | null {
  if (!settings.enabled) return null;
  if (gig.status !== 'open') return null;

  const threshold = settings.highPayingThreshold || 800;
  if (gig.price < threshold) return null;

  const radius = settings.immediateRadiusKm || 5;
  const distance = calculateDistanceKm(userLocation, gig.location);
  if (distance > radius) return null;

  let matchedSkill = 'High-Value Opportunity';
  if (settings.skillsOnly) {
    const match = matchGigToSkills(gig, userSkills);
    if (!match) return null;
    matchedSkill = match;
  } else {
    const match = matchGigToSkills(gig, userSkills);
    if (match) matchedSkill = match;
  }

  return {
    id: `alert-${gig.id}-${Date.now()}`,
    gig,
    distanceKm: distance,
    matchedSkill,
    timestamp: Date.now(),
    read: false
  };
}

/**
 * Checks if an available hustler's skill/category matches a posted gig
 */
export function matchHustlerToGig(hustler: AvailableHustler, gig: Gig): boolean {
  const gigCategory = (gig.category || '').toLowerCase();
  const gigTitle = (gig.title || '').toLowerCase();
  const gigDesc = (gig.description || '').toLowerCase();
  const gigContent = `${gigCategory} ${gigTitle} ${gigDesc}`;

  const hCategory = (hustler.category || '').toLowerCase();
  const hSkill = (hustler.skill || '').toLowerCase();

  // Category equality
  if (gigCategory === hCategory || gigCategory.includes(hCategory) || hCategory.includes(gigCategory)) {
    return true;
  }

  // Skill text match in gig content
  if (gigContent.includes(hSkill) || gigContent.includes(hCategory)) {
    return true;
  }

  // Keyword check
  const keywords = SKILL_KEYWORDS[hustler.category] || [];
  for (const kw of keywords) {
    if (gigContent.includes(kw)) {
      return true;
    }
  }

  return false;
}

/**
 * Evaluates available hustlers against an employer's posted gig
 * Returns an EmployerHustlerMatchAlert for the highest-rated or closest matching candidate
 */
export function evaluateHustlerMatchForEmployer(
  postedGig: Gig,
  hustlers: AvailableHustler[],
  employerLocation: [number, number],
  settings: PushNotificationSettings = DEFAULT_PUSH_SETTINGS
): EmployerHustlerMatchAlert | null {
  if (!settings.enabled) return null;
  if (settings.employerMatchAlertsEnabled === false) return null;
  if (postedGig.status !== 'open') return null;

  const minRating = settings.minHustlerRating || 4.5;
  const radius = settings.immediateRadiusKm || 5;

  // Filter candidates who are online, meet the minimum rating, and match the gig
  const matchingCandidates = hustlers
    .filter(h => h.isOnline && h.rating >= minRating)
    .filter(h => matchHustlerToGig(h, postedGig))
    .map(h => {
      const distToGig = calculateDistanceKm(postedGig.location, h.location);
      const distToEmployer = calculateDistanceKm(employerLocation, h.location);
      const effectiveDistance = Math.min(distToGig, distToEmployer);
      return {
        hustler: h,
        distanceKm: effectiveDistance
      };
    })
    // Candidate should ideally be in or near the 5km-10km work vicinity
    .filter(item => item.distanceKm <= Math.max(radius * 1.5, 10))
    .sort((a, b) => {
      // Prioritize higher rating, then closer proximity
      if (b.hustler.rating !== a.hustler.rating) {
        return b.hustler.rating - a.hustler.rating;
      }
      return a.distanceKm - b.distanceKm;
    });

  if (matchingCandidates.length === 0) return null;

  const bestMatch = matchingCandidates[0];

  return {
    id: `employer-match-${postedGig.id}-${bestMatch.hustler.id}-${Date.now()}`,
    hustler: bestMatch.hustler,
    matchedGig: postedGig,
    distanceKm: bestMatch.distanceKm,
    timestamp: Date.now(),
    read: false
  };
}

/**
 * Audio Synthesizer: Plays a pleasant, high-priority notification chime
 */
let audioCtx: AudioContext | null = null;

export function playNotificationChime() {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    if (!audioCtx || audioCtx.state === 'suspended') {
      audioCtx = new AudioContextClass();
    }

    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    const now = audioCtx.currentTime;

    // Chime Note 1: 587.33 Hz (D5)
    const osc1 = audioCtx.createOscillator();
    const gain1 = audioCtx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now);
    gain1.gain.setValueAtTime(0, now);
    gain1.gain.linearRampToValueAtTime(0.18, now + 0.04);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc1.connect(gain1);
    gain1.connect(audioCtx.destination);
    osc1.start(now);
    osc1.stop(now + 0.35);

    // Chime Note 2: 880.00 Hz (A5)
    const osc2 = audioCtx.createOscillator();
    const gain2 = audioCtx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880.0, now + 0.09);
    gain2.gain.setValueAtTime(0, now + 0.09);
    gain2.gain.linearRampToValueAtTime(0.22, now + 0.13);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    osc2.connect(gain2);
    gain2.connect(audioCtx.destination);
    osc2.start(now + 0.09);
    osc2.stop(now + 0.55);

    // Chime Note 3: 1174.66 Hz (D6) - Bright harmonic peak
    const osc3 = audioCtx.createOscillator();
    const gain3 = audioCtx.createGain();
    osc3.type = 'triangle';
    osc3.frequency.setValueAtTime(1174.66, now + 0.18);
    gain3.gain.setValueAtTime(0, now + 0.18);
    gain3.gain.linearRampToValueAtTime(0.15, now + 0.22);
    gain3.gain.exponentialRampToValueAtTime(0.0001, now + 0.7);
    osc3.connect(gain3);
    gain3.connect(audioCtx.destination);
    osc3.start(now + 0.18);
    osc3.stop(now + 0.7);
  } catch (err) {
    console.warn("Could not play audio chime:", err);
  }
}

/**
 * Request Web Notification API permission
 */
export async function requestBrowserNotificationPermission(): Promise<NotificationPermission> {
  if (!('Notification' in window)) {
    return 'denied';
  }
  try {
    const perm = await Notification.requestPermission();
    return perm;
  } catch (err) {
    console.warn("Error requesting notification permission:", err);
    return Notification.permission;
  }
}

/**
 * Sends a native browser push notification
 */
export function sendBrowserPushNotification(
  alert: HighPayingGigAlert,
  onOpen?: () => void
): Notification | null {
  if (!('Notification' in window) || Notification.permission !== 'granted') {
    return null;
  }

  try {
    const title = `🔥 High-Paying Gig Nearby (${alert.distanceKm}km)!`;
    const body = `R${alert.gig.price.toLocaleString()} • ${alert.gig.title} in ${alert.gig.category}\nMatches your "${alert.matchedSkill}" skill. Tap to claim!`;

    const notification = new Notification(title, {
      body,
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      tag: `gig-alert-${alert.gig.id}`,
      requireInteraction: true
    });

    notification.onclick = (event) => {
      event.preventDefault();
      window.focus();
      notification.close();
      if (onOpen) onOpen();
    };

    return notification;
  } catch (err) {
    console.warn("Could not display native notification:", err);
    return null;
  }
}

/**
 * Sends a native browser push notification for an Employer when a matching hustler is found
 */
export function sendBrowserPushNotificationForEmployer(
  alert: EmployerHustlerMatchAlert,
  onOpen?: () => void
): Notification | null {
  if (!('Notification' in window) || Notification.permission !== 'granted') {
    return null;
  }

  try {
    const title = `⚡ Available Hustler Found for "${alert.matchedGig.title}"!`;
    const body = `${alert.hustler.name} (${alert.hustler.rating}★, ${alert.hustler.skill}) is available ${alert.distanceKm}km away (R${alert.hustler.hourlyRate}/hr). Tap to direct hire!`;

    const notification = new Notification(title, {
      body,
      icon: alert.hustler.avatar || '/favicon.ico',
      badge: '/favicon.ico',
      tag: `employer-match-${alert.matchedGig.id}-${alert.hustler.id}`,
      requireInteraction: true
    });

    notification.onclick = (event) => {
      event.preventDefault();
      window.focus();
      notification.close();
      if (onOpen) onOpen();
    };

    return notification;
  } catch (err) {
    console.warn("Could not display native employer notification:", err);
    return null;
  }
}
