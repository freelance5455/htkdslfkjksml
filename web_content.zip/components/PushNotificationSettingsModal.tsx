import React, { useState, useEffect } from 'react';
import { PushNotificationSettings, UserProfile, Gig } from '../types';
import {
  AVAILABLE_SKILLS,
  DEFAULT_PUSH_SETTINGS,
  requestBrowserNotificationPermission,
  playNotificationChime
} from './gigNotificationService';

interface PushNotificationSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onSimulateAlert: (sampleGig?: Gig) => void;
  isHustler?: boolean;
  onSimulateEmployerAlert?: () => void;
  isNotificationsPaused?: boolean;
  pausedReason?: string;
}

export const PushNotificationSettingsModal: React.FC<PushNotificationSettingsModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
  onSimulateAlert,
  isHustler = true,
  onSimulateEmployerAlert,
  isNotificationsPaused,
  pausedReason
}) => {
  const currentSettings: PushNotificationSettings = {
    ...DEFAULT_PUSH_SETTINGS,
    ...(profile.pushNotificationSettings || {})
  };

  const userSkills = profile.skills && profile.skills.length > 0
    ? profile.skills
    : ['Electrical', 'Handyman', 'Plumbing', 'General'];

  const [settings, setSettings] = useState<PushNotificationSettings>(currentSettings);
  const [skills, setSkills] = useState<string[]>(userSkills);
  const [browserPermission, setBrowserPermission] = useState<NotificationPermission>('default');

  useEffect(() => {
    if ('Notification' in window) {
      setBrowserPermission(Notification.permission);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleToggleSkill = (skill: string) => {
    const updated = skills.includes(skill)
      ? skills.filter(s => s !== skill)
      : [...skills, skill];
    setSkills(updated);
    onUpdateProfile({ skills: updated });
  };

  const handleUpdateSetting = <K extends keyof PushNotificationSettings>(
    key: K,
    val: PushNotificationSettings[K]
  ) => {
    const updated = { ...settings, [key]: val };
    setSettings(updated);
    onUpdateProfile({ pushNotificationSettings: updated });

    if (key === 'soundEnabled' && val) {
      playNotificationChime();
    }
  };

  const handleRequestBrowserPermission = async () => {
    const perm = await requestBrowserNotificationPermission();
    setBrowserPermission(perm);
    if (perm === 'granted') {
      handleUpdateSetting('browserPushEnabled', true);
    }
  };

  const handleTestChime = () => {
    playNotificationChime();
  };

  const thresholds = [500, 800, 1000, 1500];
  const ratings = [4.0, 4.5, 4.8, 5.0];

  return (
    <div className="fixed inset-0 z-[8000] bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-t-[36px] sm:rounded-[36px] max-h-[90vh] flex flex-col shadow-2xl relative overflow-hidden animate-in slide-in-from-bottom duration-300 border border-slate-100">
        {/* Header */}
        <div className="bg-[#1B263B] p-6 text-white shrink-0 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4AF37]/15 rounded-full -mr-16 -mt-16 blur-2xl pointer-events-none"></div>
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#D4AF37] to-amber-200 text-slate-900 flex items-center justify-center text-xl shadow-lg border border-white/20">
                {isHustler ? '⚡' : '👥'}
              </div>
              <div>
                <span className="text-[9px] font-black uppercase tracking-[0.25em] text-[#D4AF37] block">
                  {isHustler ? 'Hustler Skill Radar' : 'Employer Talent Radar'}
                </span>
                <h3 className="text-base font-black tracking-tight text-white">
                  {isHustler ? '5km Gig Push Alerts' : 'Candidate Match Push Alerts'}
                </h3>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
              title="Close settings"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Scrollable Settings Form */}
        <div className="p-6 overflow-y-auto space-y-6 no-scrollbar">
          {/* Working / Active Hire Notification Pause Banner */}
          {isNotificationsPaused && (
            <div className="bg-amber-50 border border-amber-200/90 rounded-2xl p-4 flex items-start gap-3 shadow-xs">
              <span className="text-xl shrink-0 mt-0.5">🔕</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-1">
                  <h4 className="text-xs font-black text-amber-950 uppercase tracking-tight">
                    Notifications Temporarily Paused
                  </h4>
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                </div>
                <p className="text-[11px] text-amber-800 leading-relaxed font-medium">
                  {pausedReason || (isHustler 
                    ? 'You are currently in working mode on an active gig. Skill match push notifications are paused so you can focus, and will automatically resume once the job is completed.'
                    : 'You have selected and hired a worker who is currently on the job. Candidate match push notifications are stopped until the active job is done.')}
                </p>
              </div>
            </div>
          )}

          {/* Main Master Toggle */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 flex items-center justify-between">
            <div className="pr-4">
              <span className="text-xs font-black text-slate-900 block">
                {isHustler ? 'Instant High-Paying Gig Alerts' : 'Candidate Match Push Alerts'}
              </span>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {isHustler
                  ? 'Only alert when high-paying gigs appear within 5km matching your selected skills.'
                  : 'Alert when available, top-rated hustlers matching your posted gigs are ready to work nearby.'}
              </p>
            </div>
            <button
              onClick={() => {
                if (isHustler) {
                  handleUpdateSetting('enabled', !settings.enabled);
                } else {
                  handleUpdateSetting('employerMatchAlertsEnabled', !settings.employerMatchAlertsEnabled);
                }
              }}
              className={`w-14 h-8 rounded-full p-1 transition-colors flex items-center shrink-0 ${
                (isHustler ? settings.enabled : settings.employerMatchAlertsEnabled !== false)
                  ? 'bg-emerald-500 justify-end'
                  : 'bg-slate-300 justify-start'
              }`}
            >
              <div className="w-6 h-6 rounded-full bg-white shadow-md"></div>
            </button>
          </div>

          {/* Browser Notification Status Banner */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">
                Browser Push Notifications
              </span>
              <span
                className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-md ${
                  browserPermission === 'granted'
                    ? 'bg-emerald-100 text-emerald-800'
                    : browserPermission === 'denied'
                    ? 'bg-rose-100 text-rose-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {browserPermission === 'granted' ? 'Active' : browserPermission === 'denied' ? 'Blocked' : 'Permission Needed'}
              </span>
            </div>

            <p className="text-[11px] text-slate-600 mb-3 leading-relaxed">
              {browserPermission === 'granted'
                ? 'Browser notifications are active. You will receive real-time push alerts even with the tab in the background.'
                : 'Allow browser notifications so you receive immediate dispatches even when SwiftHustle is minimized.'}
            </p>

            {browserPermission !== 'granted' && (
              <button
                onClick={handleRequestBrowserPermission}
                className="w-full py-2.5 bg-[#1B263B] hover:bg-slate-800 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <span>🔔</span>
                <span>Enable Browser Notifications</span>
              </button>
            )}
          </div>

          {/* Hustler-specific: Skill Set Selector */}
          {isHustler && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                  My Skills ({skills.length} Selected)
                </label>
                <span className="text-[10px] text-slate-500 font-bold">
                  Tap to toggle
                </span>
              </div>

              <p className="text-[11px] text-slate-500 mb-3">
                Only gigs matching your verified skills will trigger high-priority push notifications.
              </p>

              <div className="flex flex-wrap gap-2">
                {AVAILABLE_SKILLS.map((skill) => {
                  const isSelected = skills.includes(skill);
                  return (
                    <button
                      key={skill}
                      type="button"
                      onClick={() => handleToggleSkill(skill)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-[#1B263B] text-white shadow-sm border border-[#1B263B]'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200 border border-slate-200'
                      }`}
                    >
                      <span>{isSelected ? '✓' : '+'}</span>
                      <span>{skill}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Hustler-specific: High-Paying Minimum Threshold */}
          {isHustler && (
            <div>
              <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-2">
                Minimum Payout Threshold (High-Paying Gigs)
              </label>
              <div className="grid grid-cols-4 gap-2">
                {thresholds.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => handleUpdateSetting('highPayingThreshold', t)}
                    className={`py-2.5 rounded-xl text-xs font-black transition-all ${
                      settings.highPayingThreshold === t
                        ? 'bg-gradient-to-tr from-[#D4AF37] to-amber-300 text-slate-950 shadow-md border-2 border-[#D4AF37]'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                    }`}
                  >
                    R{t}+
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-400 mt-1.5">
                Gigs paying R{settings.highPayingThreshold} or higher will trigger immediate push alerts.
              </p>
            </div>
          )}

          {/* Employer-specific: Minimum Candidate Rating */}
          {!isHustler && (
            <div>
              <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-2">
                Minimum Hustler Rating For Alerts
              </label>
              <div className="grid grid-cols-4 gap-2">
                {ratings.map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => handleUpdateSetting('minHustlerRating', r)}
                    className={`py-2.5 rounded-xl text-xs font-black transition-all ${
                      (settings.minHustlerRating || 4.5) === r
                        ? 'bg-gradient-to-tr from-emerald-400 to-teal-200 text-slate-950 shadow-md border-2 border-emerald-400'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                    }`}
                  >
                    ★ {r.toFixed(1)}+
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-400 mt-1.5">
                Only available hustlers with a rating of ★{(settings.minHustlerRating || 4.5).toFixed(1)} or higher will trigger push alerts.
              </p>
            </div>
          )}

          {/* Immediate Radius & Sound Settings */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-black text-slate-900 block">
                  Alert Perimeter
                </span>
                <span className="text-[11px] text-slate-500">
                  {isHustler ? 'Immediate 5km radius around your location' : 'Matches available hustlers nearby'}
                </span>
              </div>
              <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                5.0 km
              </span>
            </div>

            <div className="border-t border-slate-200 pt-3 flex items-center justify-between">
              <div>
                <span className="text-xs font-black text-slate-900 block">
                  Audio Chime Ping
                </span>
                <span className="text-[11px] text-slate-500">
                  Play harmonic chime on new dispatch
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleTestChime}
                  className="px-2 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] font-black rounded-lg"
                  title="Test Audio"
                >
                  🔊 Test
                </button>
                <button
                  onClick={() => handleUpdateSetting('soundEnabled', !settings.soundEnabled)}
                  className={`w-12 h-7 rounded-full p-0.5 transition-colors flex items-center ${
                    settings.soundEnabled ? 'bg-emerald-500 justify-end' : 'bg-slate-300 justify-start'
                  }`}
                >
                  <div className="w-5 h-5 rounded-full bg-white shadow-md"></div>
                </button>
              </div>
            </div>
          </div>

          {/* Role-Specific Simulator & Test Alert Action */}
          {isHustler ? (
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200/80 rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-base">⚡</span>
                <span className="text-xs font-black text-amber-900 uppercase tracking-wide">
                  Hustler Alert Simulator
                </span>
              </div>
              <p className="text-[11px] text-amber-800 leading-relaxed mb-3">
                Test how an immediate high-paying gig alert looks and sounds right now matching your skill set ({skills[0] || 'Electrical'}).
              </p>
              <button
                type="button"
                onClick={() => {
                  onSimulateAlert();
                  onClose();
                }}
                className="w-full py-3 bg-gradient-to-r from-[#D4AF37] to-amber-500 hover:from-amber-500 hover:to-[#D4AF37] text-slate-950 rounded-xl text-xs font-black uppercase tracking-wider shadow-md active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <span>🔥</span>
                <span>Simulate High-Paying 5km Gig Alert</span>
              </button>
            </div>
          ) : (
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200/80 rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-base">👥</span>
                <span className="text-xs font-black text-emerald-900 uppercase tracking-wide">
                  Candidate Match Simulator
                </span>
              </div>
              <p className="text-[11px] text-emerald-800 leading-relaxed mb-3">
                Test how a push alert notifies you when a verified, available hustler matching your posted job is ready to work nearby.
              </p>
              <button
                type="button"
                onClick={() => {
                  if (onSimulateEmployerAlert) {
                    onSimulateEmployerAlert();
                  } else {
                    onSimulateAlert();
                  }
                  onClose();
                }}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 rounded-xl text-xs font-black uppercase tracking-wider shadow-md active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <span>⚡</span>
                <span>Simulate Available Hustler Match Alert</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3.5 bg-[#1B263B] text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg active:scale-95 transition-all"
          >
            Save &amp; Return
          </button>
        </div>
      </div>
    </div>
  );
};

export default PushNotificationSettingsModal;
