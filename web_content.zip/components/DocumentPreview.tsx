
import { DocumentMetadata, MarginPreset, Section } from '../types';
import React, { useMemo } from 'react';

interface DocumentPreviewProps {
  metadata: DocumentMetadata;
  sections: Section[];
  className?: string;
  previewRef?: React.RefObject<HTMLDivElement>;
}

const LatexText: React.FC<{ text: string, style?: React.CSSProperties }> = ({ text, style }) => {
  const renderedContent = useMemo(() => {
    if (!text) return null;
    
    const katex = (window as any).katex;
    if (!katex) return <span>{text}</span>;

    const mathRegex = /(\$\$.*?\$\$|\$.*?\$|\\\(.*?\\\)|\\\[.*?\\\])/gs;
    const parts = text.split(mathRegex);

    return parts.map((part, index) => {
      if (!part) return null;
      
      const isMath = (part.startsWith('$') || part.startsWith('\\(') || part.startsWith('\\[')) && part.length > 2;

      if (isMath) {
        let formula = part;
        const isDisplay = part.startsWith('$$') || part.startsWith('\\[');
        
        if (part.startsWith('$$')) formula = part.slice(2, -2);
        else if (part.startsWith('$')) formula = part.slice(1, -1);
        else if (part.startsWith('\\(')) formula = part.slice(2, -2);
        else if (part.startsWith('\\[')) formula = part.slice(2, -2);
        
        try {
          const html = katex.renderToString(formula.trim(), {
            displayMode: isDisplay,
            throwOnError: false,
            output: 'htmlAndMathml', 
            trust: true
          });
          
          return (
            <span 
              key={index} 
              className="math-container" 
              dangerouslySetInnerHTML={{ __html: html }} 
              style={{ fontStyle: 'normal', color: 'inherit' }} 
            />
          );
        } catch (e) {
          return <span key={index} style={{ color: '#ef4444' }}>{part}</span>;
        }
      }
      return <span key={index}>{part}</span>;
    });
  }, [text]);

  return (
    <span style={{ ...style, whiteSpace: 'pre-wrap', color: 'inherit' }}>
      {renderedContent}
    </span>
  );
};

const DocumentPreview: React.FC<DocumentPreviewProps> = ({ metadata, sections, className = "", previewRef }) => {
  const optionLabels = ['A', 'B', 'C', 'D'];

  const getPadding = (margin: MarginPreset) => {
    switch (margin) {
      case 'Narrow': return '12.7mm';
      case 'Moderate': return '25.4mm 19.05mm';
      case 'Wide': return '25.4mm 50.8mm';
      default: return '25.4mm';
    }
  };

  let currentNum = 0;

  return (
    <div className={`flex justify-center ${className}`}>
      <div 
        ref={previewRef}
        id="preview-content"
        style={{ 
          padding: getPadding(metadata.pageSettings.margin),
          backgroundColor: 'white',
          color: 'black',
          width: '210mm',
          minHeight: '297mm',
          fontFamily: '"Nirmala UI", "Segoe UI", Arial, sans-serif'
        }}
        className="shadow-2xl print:shadow-none relative overflow-hidden transition-all duration-300"
      >
        {/* Border */}
        {metadata.pageSettings.showBorder && (
          <div className="absolute inset-0 pointer-events-none" style={{ padding: '5mm' }}>
            <div className="w-full h-full border-[1.5pt] border-black"></div>
          </div>
        )}

        {/* Header */}
        {(metadata.showTitle || metadata.showSubtitle) && (
          <div className="text-center mb-10">
            {metadata.showTitle && (
              <h1 className="text-[22pt] font-bold m-0 mb-1 text-slate-900">{metadata.title}</h1>
            )}
            {metadata.showSubtitle && metadata.subtitle && (
              <h2 className="text-[14pt] text-slate-400 font-bold m-0 tracking-wider uppercase">{metadata.subtitle}</h2>
            )}
          </div>
        )}

        {/* Main Content */}
        <div>
          {sections.map((section) => {
            if (section.startNumber !== undefined) currentNum = section.startNumber - 1;
            
            return (
              <div key={section.id} className="mb-8 section-container">
                {section.title && (
                  <div className="text-center mb-8 border-b border-slate-100 pb-2">
                    <h3 className="text-[13pt] font-bold uppercase tracking-widest text-slate-800">
                      {section.title}
                    </h3>
                  </div>
                )}

                {section.questions.map((q) => {
                  currentNum++;
                  return (
                    <div key={q.id} className="mb-20 question-wrapper" style={{ pageBreakInside: 'avoid' }}>
                      
                      {/* Question Text (Red) */}
                      <div style={{ color: '#dc2626' }} className="mb-4 text-[12.5pt] leading-relaxed font-semibold question-text-container">
                        <span className="mr-2">{currentNum}.</span>
                        <LatexText text={q.text} />
                      </div>

                      {/* Options (Black) */}
                      <div className="ml-2 mb-6 space-y-3 options-container">
                        {q.options.map((opt, i) => (
                          <div key={i} className="text-[12pt] text-black option-item">
                            <span className="mr-3 font-medium">({optionLabels[i]})</span>
                            <LatexText text={opt} />
                          </div>
                        ))}
                      </div>

                      {/* Answer Line (Green Bold Underline) */}
                      <div className="mb-6 answer-line">
                        <span className="text-[13pt] font-bold text-[#15803d] underline decoration-[#15803d] decoration-1 underline-offset-4">
                          Ans:- ({optionLabels[q.correctAnswer]})
                        </span>
                      </div>

                      {/* Explanation Box */}
                      {q.explanation && (
                        <div className="bg-[#f0fdf4] border border-[#bbf7d0] rounded-xl p-6 mt-4 explanation-box">
                          <div className="text-[11.5pt] leading-relaxed explanation-text-container">
                            <span className="font-bold text-[#92400e] mr-2">Explanation -</span> 
                            <span className="text-black">
                              <LatexText text={q.explanation} />
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default DocumentPreview;
