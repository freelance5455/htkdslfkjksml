// Authentication service for SwiftHustle SA
// Handles Gmail / Google Sign-In, Email/Password Login, Sign Up registration, and Session Persistence ('Remember Me')

export interface RegisteredUser {
  id: string;
  fullName: string;
  email: string;
  password?: string;
  phone: string;
  role: 'hustler' | 'client';
  avatarUrl?: string;
  provider: 'google' | 'email';
  createdAt: number;
}

export interface AuthSession {
  token: string;
  user: RegisteredUser;
  rememberMe: boolean;
  loginTimestamp: number;
}

const USERS_DB_KEY = 'sh_registered_users_db';
const SESSION_KEY = 'sh_auth_session';
const REMEMBERED_USER_KEY = 'sh_remembered_user';

// Pre-seeded users so users can immediately test or log in with their email
const DEFAULT_USERS: RegisteredUser[] = [
  {
    id: 'user_jong_cobo',
    fullName: 'Jong Cobo',
    email: 'jongcobo114@gmail.com',
    password: 'password123',
    phone: '+27 82 555 1234',
    role: 'hustler',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300',
    provider: 'google',
    createdAt: Date.now() - 86400000 * 30
  },
  {
    id: 'user_mandla_zulu',
    fullName: 'Mandla Zulu',
    email: 'admin@swifthustle.co.za',
    password: 'password123',
    phone: '+27 72 123 4567',
    role: 'hustler',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300',
    provider: 'email',
    createdAt: Date.now() - 86400000 * 60
  }
];

// Helper to get all registered users
export function getRegisteredUsers(): RegisteredUser[] {
  try {
    const raw = localStorage.getItem(USERS_DB_KEY);
    if (!raw) {
      localStorage.setItem(USERS_DB_KEY, JSON.stringify(DEFAULT_USERS));
      return DEFAULT_USERS;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      localStorage.setItem(USERS_DB_KEY, JSON.stringify(DEFAULT_USERS));
      return DEFAULT_USERS;
    }
    return parsed;
  } catch {
    return DEFAULT_USERS;
  }
}

// Save a newly registered user
export function saveRegisteredUser(user: RegisteredUser): void {
  const users = getRegisteredUsers();
  const existingIndex = users.findIndex(u => u.email.toLowerCase() === user.email.toLowerCase());
  if (existingIndex >= 0) {
    users[existingIndex] = { ...users[existingIndex], ...user };
  } else {
    users.push(user);
  }
  localStorage.setItem(USERS_DB_KEY, JSON.stringify(users));
}

// Retrieve currently active session
export function getActiveSession(): AuthSession | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) {
      // Check legacy auth token
      const legacyToken = localStorage.getItem('sh_auth_token');
      if (legacyToken) {
        const remembered = getRememberedUser();
        if (remembered) {
          return {
            token: legacyToken,
            user: remembered,
            rememberMe: true,
            loginTimestamp: Date.now()
          };
        }
      }
      return null;
    }
    const session = JSON.parse(raw) as AuthSession;
    return session;
  } catch {
    return null;
  }
}

// Save active session
export function saveActiveSession(user: RegisteredUser, rememberMe: boolean): AuthSession {
  const token = `sh_tok_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const session: AuthSession = {
    token,
    user,
    rememberMe,
    loginTimestamp: Date.now()
  };

  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  localStorage.setItem('sh_auth_token', token);

  // If user chose "remember me", preserve their remembered identity for instant auto-login
  if (rememberMe) {
    localStorage.setItem(REMEMBERED_USER_KEY, JSON.stringify(user));
    localStorage.setItem('sh_remember_me', 'true');
    localStorage.setItem('sh_remembered_email', user.email);
  } else {
    localStorage.removeItem('sh_remember_me');
    localStorage.removeItem(REMEMBERED_USER_KEY);
  }

  return session;
}

// Get remembered user for quick 1-click re-login
export function getRememberedUser(): RegisteredUser | null {
  try {
    const raw = localStorage.getItem(REMEMBERED_USER_KEY);
    if (raw) return JSON.parse(raw);
    const rememberedEmail = localStorage.getItem('sh_remembered_email');
    if (rememberedEmail) {
      const users = getRegisteredUsers();
      return users.find(u => u.email.toLowerCase() === rememberedEmail.toLowerCase()) || null;
    }
    return null;
  } catch {
    return null;
  }
}

// Clear session upon sign out
export function clearAuthSession(keepRememberedEmail: boolean = true): void {
  localStorage.removeItem(SESSION_KEY);
  localStorage.removeItem('sh_auth_token');
  if (!keepRememberedEmail) {
    localStorage.removeItem(REMEMBERED_USER_KEY);
    localStorage.removeItem('sh_remember_me');
    localStorage.removeItem('sh_remembered_email');
  }
}

// Authenticate via Email & Password
export function authenticateWithEmail(email: string, password?: string, rememberMe: boolean = true): { success: boolean; session?: AuthSession; error?: string } {
  const normalizedEmail = email.trim().toLowerCase();
  const users = getRegisteredUsers();
  const user = users.find(u => u.email.toLowerCase() === normalizedEmail);

  if (!user) {
    return {
      success: false,
      error: 'No account found with this email address. Please click Sign Up to register.'
    };
  }

  // If user registered with password and password is supplied, verify it (demo allows fallback password)
  if (user.password && password && user.password !== password && password !== 'password123') {
    return {
      success: false,
      error: 'Incorrect password. Try again or use "password123" for demo.'
    };
  }

  const session = saveActiveSession(user, rememberMe);
  return { success: true, session };
}

// Authenticate via Google / Gmail
export function authenticateWithGoogle(googleProfile: {
  email: string;
  name: string;
  avatarUrl?: string;
  role?: 'hustler' | 'client';
}, rememberMe: boolean = true): AuthSession {
  const normalizedEmail = googleProfile.email.trim().toLowerCase();
  const users = getRegisteredUsers();
  let user = users.find(u => u.email.toLowerCase() === normalizedEmail);

  if (!user) {
    // Automatically create a new registered profile for the Google user
    user = {
      id: `google_${Date.now()}`,
      fullName: googleProfile.name || 'SwiftHustle User',
      email: normalizedEmail,
      phone: '+27 82 ' + Math.floor(1000000 + Math.random() * 9000000).toString(),
      role: googleProfile.role || 'hustler',
      avatarUrl: googleProfile.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=300',
      provider: 'google',
      createdAt: Date.now()
    };
    saveRegisteredUser(user);
  } else {
    // Update existing user's name or avatar if provided from Google
    if (googleProfile.name && user.fullName === 'Mandla Zulu' && googleProfile.name !== user.fullName) {
      user.fullName = googleProfile.name;
    }
    if (googleProfile.avatarUrl) {
      user.avatarUrl = googleProfile.avatarUrl;
    }
    saveRegisteredUser(user);
  }

  return saveActiveSession(user, rememberMe);
}

// Register a new user account
export function registerNewUser(data: {
  fullName: string;
  email: string;
  password?: string;
  phone: string;
  role: 'hustler' | 'client';
  rememberMe: boolean;
}): { success: boolean; session?: AuthSession; error?: string } {
  const normalizedEmail = data.email.trim().toLowerCase();
  const users = getRegisteredUsers();
  const existing = users.find(u => u.email.toLowerCase() === normalizedEmail);

  if (existing) {
    return {
      success: false,
      error: 'An account with this email already exists. Please switch to Log In.'
    };
  }

  const newUser: RegisteredUser = {
    id: `user_${Date.now()}`,
    fullName: data.fullName.trim(),
    email: normalizedEmail,
    password: data.password || 'password123',
    phone: data.phone.trim() || '+27 72 000 0000',
    role: data.role || 'hustler',
    avatarUrl: `https://images.unsplash.com/photo-${data.role === 'hustler' ? '1507003211169-0a1dd7228f2d' : '1534528741775-53994a69daeb'}?auto=format&fit=crop&q=80&w=300`,
    provider: 'email',
    createdAt: Date.now()
  };

  saveRegisteredUser(newUser);
  const session = saveActiveSession(newUser, data.rememberMe);
  return { success: true, session };
}
