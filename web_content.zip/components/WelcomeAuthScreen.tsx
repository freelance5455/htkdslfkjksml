import React, { useState, useEffect } from 'react';
import {
  RegisteredUser,
  getRegisteredUsers,
  getRememberedUser,
  authenticateWithEmail,
  authenticateWithGoogle,
  registerNewUser
} from './authService';

interface WelcomeAuthScreenProps {
  onLogin: (user?: RegisteredUser, rememberMe?: boolean) => void;
}

const WelcomeAuthScreen: React.FC<WelcomeAuthScreenProps> = ({ onLogin }) => {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [rememberMe, setRememberMe] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Sign In State
  const [signInEmail, setSignInEmail] = useState<string>('');
  const [signInPassword, setSignInPassword] = useState<string>('');
  const [showSignInPassword, setShowSignInPassword] = useState<boolean>(false);

  // Sign Up State
  const [signUpName, setSignUpName] = useState<string>('');
  const [signUpEmail, setSignUpEmail] = useState<string>('');
  const [signUpPhone, setSignUpPhone] = useState<string>('+27 ');
  const [signUpPassword, setSignUpPassword] = useState<string>('');
  const [signUpConfirmPassword, setSignUpConfirmPassword] = useState<string>('');
  const [signUpRole, setSignUpRole] = useState<'hustler' | 'client'>('hustler');
  const [showSignUpPassword, setShowSignUpPassword] = useState<boolean>(false);
  const [agreeTerms, setAgreeTerms] = useState<boolean>(true);

  // Google Modal State
  const [isGoogleModalOpen, setIsGoogleModalOpen] = useState<boolean>(false);
  const [customGoogleEmail, setCustomGoogleEmail] = useState<string>('');
  const [customGoogleName, setCustomGoogleName] = useState<string>('');
  const [showCustomGoogleInput, setShowCustomGoogleInput] = useState<boolean>(false);

  // Forgot Password Modal State
  const [isForgotModalOpen, setIsForgotModalOpen] = useState<boolean>(false);
  const [forgotEmail, setForgotEmail] = useState<string>('');
  const [forgotSent, setForgotSent] = useState<boolean>(false);

  // Remembered user from previous session
  const [rememberedUser, setRememberedUser] = useState<RegisteredUser | null>(null);

  useEffect(() => {
    const remembered = getRememberedUser();
    if (remembered) {
      setRememberedUser(remembered);
      setSignInEmail(remembered.email);
    } else {
      // Default to jongcobo114@gmail.com for seamless experience
      setSignInEmail('jongcobo114@gmail.com');
    }
  }, []);

  // Quick email domain appender
  const appendDomain = (domain: string, isSignUp: boolean = false) => {
    if (isSignUp) {
      const parts = signUpEmail.split('@');
      setSignUpEmail(`${parts[0]}${domain}`);
    } else {
      const parts = signInEmail.split('@');
      setSignInEmail(`${parts[0]}${domain}`);
    }
  };

  // Sign In Submit
  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!signInEmail.trim()) {
      setErrorMsg('Please enter your email or Gmail address.');
      return;
    }
    if (!signInPassword) {
      setErrorMsg('Please enter your password.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const result = authenticateWithEmail(signInEmail, signInPassword, rememberMe);
      setIsLoading(false);
      if (result.success && result.session) {
        setSuccessMsg(`Welcome back, ${result.session.user.fullName}!`);
        setTimeout(() => {
          onLogin(result.session?.user, rememberMe);
        }, 500);
      } else {
        setErrorMsg(result.error || 'Authentication failed. Please check credentials.');
      }
    }, 700);
  };

  // Sign Up Submit
  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!signUpName.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    if (!signUpEmail.trim() || !signUpEmail.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    if (signUpPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters.');
      return;
    }
    if (signUpPassword !== signUpConfirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }
    if (!agreeTerms) {
      setErrorMsg('Please agree to the Terms of Service & Privacy Policy.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const result = registerNewUser({
        fullName: signUpName,
        email: signUpEmail,
        password: signUpPassword,
        phone: signUpPhone,
        role: signUpRole,
        rememberMe
      });
      setIsLoading(false);

      if (result.success && result.session) {
        setSuccessMsg(`Account created! Welcome to SwiftHustle, ${result.session.user.fullName}!`);
        setTimeout(() => {
          onLogin(result.session?.user, rememberMe);
        }, 600);
      } else {
        setErrorMsg(result.error || 'Failed to create account.');
      }
    }, 800);
  };

  // Google Sign-In Handler
  const handleSelectGoogleAccount = (accountEmail: string, accountName: string) => {
    setIsLoading(true);
    setIsGoogleModalOpen(false);
    setErrorMsg('');

    setTimeout(() => {
      const session = authenticateWithGoogle({
        email: accountEmail,
        name: accountName,
        role: signUpRole
      }, rememberMe);

      setIsLoading(false);
      setSuccessMsg(`Connected via Google (${accountEmail})!`);
      setTimeout(() => {
        onLogin(session.user, rememberMe);
      }, 500);
    }, 600);
  };

  // Quick 1-Click login as remembered user
  const handleQuickLoginAsRemembered = () => {
    if (!rememberedUser) return;
    setIsLoading(true);
    setTimeout(() => {
      const result = authenticateWithEmail(rememberedUser.email, 'password123', true);
      setIsLoading(false);
      if (result.success && result.session) {
        onLogin(result.session.user, true);
      } else {
        // Fallback
        onLogin(rememberedUser, true);
      }
    }, 500);
  };

  // Calculate password strength
  const getPasswordStrength = (pwd: string) => {
    if (!pwd) return { label: '', color: 'bg-slate-200', width: '0%' };
    let score = 0;
    if (pwd.length >= 6) score += 1;
    if (pwd.length >= 8) score += 1;
    if (/[0-9]/.test(pwd)) score += 1;
    if (/[^A-Za-z0-9]/.test(pwd)) score += 1;

    if (score <= 1) return { label: 'Weak', color: 'bg-rose-500', width: '25%' };
    if (score === 2) return { label: 'Fair', color: 'bg-amber-500', width: '50%' };
    if (score === 3) return { label: 'Good', color: 'bg-blue-500', width: '75%' };
    return { label: 'Strong', color: 'bg-emerald-500', width: '100%' };
  };

  const passwordStrength = getPasswordStrength(signUpPassword);

  return (
    <div className="fixed inset-0 z-[10500] bg-slate-900 flex flex-col overflow-y-auto no-scrollbar">
      {/* Background Graphic */}
      <div className="relative min-h-[220px] max-h-[260px] bg-gradient-to-br from-emerald-700 via-teal-800 to-[#1B263B] p-6 flex flex-col justify-between shrink-0 overflow-hidden">
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <img 
            src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&q=80&w=800" 
            className="w-full h-full object-cover mix-blend-overlay"
            alt="Collaboration Background"
          />
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none"></div>

        {/* Top Branding */}
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 bg-white/10 backdrop-blur-md rounded-xl p-1.5 border border-white/20 shadow-md flex items-center justify-center">
              <img src="/assets/logo-icon.svg" alt="SwiftHustle" className="w-full h-full object-contain" />
            </div>
            <div>
              <span className="text-white font-black text-lg tracking-tight block leading-none">SwiftHustle</span>
              <span className="text-emerald-400 font-bold text-[9px] uppercase tracking-[0.25em] block">South Africa</span>
            </div>
          </div>
          <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full bg-white/15 text-white/90 border border-white/10">
            Secure Portal
          </span>
        </div>

        {/* Hero Title */}
        <div className="relative z-10 mt-2">
          <h1 className="text-2xl sm:text-3xl font-black text-white leading-tight">
            {authMode === 'signin' ? 'Welcome Back.' : 'Start Hustling.'}
          </h1>
          <p className="text-emerald-100/80 text-xs mt-1">
            {authMode === 'signin' 
              ? 'Log in to access your gigs, escrow wallet, and instant chats.' 
              : 'Create your account to unlock verified gigs & hire local talent.'}
          </p>
        </div>
      </div>

      {/* Main Auth Form Container */}
      <div className="flex-1 bg-white rounded-t-[36px] -mt-6 relative z-20 px-6 pt-6 pb-12 flex flex-col shadow-2xl">
        {/* Auth Mode Tabs (Sign In vs Sign Up) */}
        <div className="flex p-1.5 bg-slate-100 rounded-2xl mb-5">
          <button
            type="button"
            onClick={() => { setAuthMode('signin'); setErrorMsg(''); setSuccessMsg(''); }}
            className={`flex-1 py-2.5 text-xs font-black rounded-xl transition-all ${
              authMode === 'signin'
                ? 'bg-white text-[#1B263B] shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Log In
          </button>
          <button
            type="button"
            onClick={() => { setAuthMode('signup'); setErrorMsg(''); setSuccessMsg(''); }}
            className={`flex-1 py-2.5 text-xs font-black rounded-xl transition-all ${
              authMode === 'signup'
                ? 'bg-[#1B263B] text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Sign Up
          </button>
        </div>

        {/* Feedback alerts */}
        {errorMsg && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-700 flex items-start gap-2.5 animate-in fade-in">
            <svg className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <div className="flex-1 font-semibold">{errorMsg}</div>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-700 flex items-start gap-2.5 animate-in fade-in">
            <svg className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 13l4 4L19 7" />
            </svg>
            <div className="flex-1 font-semibold">{successMsg}</div>
          </div>
        )}

        {/* Google One-Click Button */}
        <button
          type="button"
          onClick={() => setIsGoogleModalOpen(true)}
          className="w-full flex items-center justify-center gap-3 bg-white border-2 border-slate-200 py-3.5 px-4 rounded-2xl font-bold text-slate-700 hover:bg-slate-50 hover:border-slate-300 active:scale-[0.98] transition-all shadow-sm mb-4 group"
        >
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span className="text-xs sm:text-sm">
            {authMode === 'signin' ? 'Continue with Google / Gmail' : 'Sign Up with Google / Gmail'}
          </span>
          <span className="ml-auto text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
            Instant
          </span>
        </button>

        {/* Divider */}
        <div className="relative flex py-2 items-center mb-4">
          <div className="flex-grow border-t border-slate-200"></div>
          <span className="flex-shrink mx-3 text-slate-400 text-[10px] font-black uppercase tracking-widest">
            or with credentials
          </span>
          <div className="flex-grow border-t border-slate-200"></div>
        </div>

        {/* Returning user quick login card (Sign In Mode) */}
        {authMode === 'signin' && rememberedUser && (
          <div className="mb-5 p-3.5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200/80 rounded-2xl flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-emerald-500 shadow-sm shrink-0">
                <img src={rememberedUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'} alt="Avatar" className="w-full h-full object-cover" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-black text-slate-900 truncate">{rememberedUser.fullName}</span>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 bg-emerald-100 text-emerald-700 rounded-full">Remembered</span>
                </div>
                <p className="text-[11px] text-slate-500 truncate">{rememberedUser.email}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleQuickLoginAsRemembered}
              disabled={isLoading}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black active:scale-95 transition-all shadow-sm shrink-0"
            >
              1-Tap Log In
            </button>
          </div>
        )}

        {/* -------------------- SIGN IN FORM -------------------- */}
        {authMode === 'signin' && (
          <form onSubmit={handleSignInSubmit} className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-700">Gmail or Email Address</label>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => appendDomain('@gmail.com', false)}
                    className="text-[10px] font-bold text-slate-500 bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded-md transition-colors"
                  >
                    @gmail.com
                  </button>
                </div>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.206" />
                  </svg>
                </div>
                <input
                  type="email"
                  required
                  value={signInEmail}
                  onChange={(e) => setSignInEmail(e.target.value)}
                  placeholder="e.g. jongcobo114@gmail.com"
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white transition-colors"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-700">Password</label>
                <button
                  type="button"
                  onClick={() => setIsForgotModalOpen(true)}
                  className="text-[11px] font-semibold text-emerald-600 hover:text-emerald-700"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <input
                  type={showSignInPassword ? 'text' : 'password'}
                  required
                  value={signInPassword}
                  onChange={(e) => setSignInPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowSignInPassword(!showSignInPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600"
                >
                  {showSignInPassword ? (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18" /></svg>
                  ) : (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                  )}
                </button>
              </div>
            </div>

            {/* Remember Me Checkbox */}
            <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                />
                <div>
                  <span className="text-xs font-bold text-slate-800 block">Remember me</span>
                  <span className="text-[10px] text-slate-500 block">Stay signed in on this device</span>
                </div>
              </label>
              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
                Recommended
              </span>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-[#1B263B] hover:bg-slate-800 text-white font-black py-3.5 rounded-2xl text-xs sm:text-sm active:scale-[0.98] transition-all shadow-lg shadow-slate-900/10 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                  <span>Signing In...</span>
                </>
              ) : (
                <span>Sign In to SwiftHustle</span>
              )}
            </button>

            <div className="text-center pt-2">
              <p className="text-xs text-slate-500">
                Don't have an account yet?{' '}
                <button
                  type="button"
                  onClick={() => { setAuthMode('signup'); setErrorMsg(''); }}
                  className="font-black text-emerald-600 hover:text-emerald-700 underline underline-offset-2"
                >
                  Create one now
                </button>
              </p>
            </div>
          </form>
        )}

        {/* -------------------- SIGN UP FORM -------------------- */}
        {authMode === 'signup' && (
          <form onSubmit={handleSignUpSubmit} className="space-y-3.5">
            {/* Full Name */}
            <div>
              <label className="text-xs font-bold text-slate-700 mb-1 block">Full Name</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
                <input
                  type="text"
                  required
                  value={signUpName}
                  onChange={(e) => setSignUpName(e.target.value)}
                  placeholder="e.g. Jong Cobo"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white transition-colors"
                />
              </div>
            </div>

            {/* Email / Gmail */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">Email Address (Gmail preferred)</label>
                <button
                  type="button"
                  onClick={() => appendDomain('@gmail.com', true)}
                  className="text-[10px] font-bold text-slate-500 bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded-md transition-colors"
                >
                  @gmail.com
                </button>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.206" />
                  </svg>
                </div>
                <input
                  type="email"
                  required
                  value={signUpEmail}
                  onChange={(e) => setSignUpEmail(e.target.value)}
                  placeholder="name@gmail.com"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white transition-colors"
                />
              </div>
            </div>

            {/* Phone Number */}
            <div>
              <label className="text-xs font-bold text-slate-700 mb-1 block">South African Mobile Number</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <input
                  type="tel"
                  required
                  value={signUpPhone}
                  onChange={(e) => setSignUpPhone(e.target.value)}
                  placeholder="+27 82 123 4567"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white transition-colors"
                />
              </div>
            </div>

            {/* Role Preference */}
            <div>
              <label className="text-xs font-bold text-slate-700 mb-1.5 block">I am joining as:</label>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setSignUpRole('hustler')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    signUpRole === 'hustler'
                      ? 'border-emerald-500 bg-emerald-50/70 text-slate-900 shadow-xs'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-base">🛠️</span>
                    {signUpRole === 'hustler' && (
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    )}
                  </div>
                  <span className="text-xs font-black block text-[#1B263B]">Hustler</span>
                  <span className="text-[10px] text-slate-500 block leading-tight">Find jobs & earn</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSignUpRole('client')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    signUpRole === 'client'
                      ? 'border-emerald-500 bg-emerald-50/70 text-slate-900 shadow-xs'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-base">💼</span>
                    {signUpRole === 'client' && (
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    )}
                  </div>
                  <span className="text-xs font-black block text-[#1B263B]">Employer</span>
                  <span className="text-[10px] text-slate-500 block leading-tight">Post gigs & hire</span>
                </button>
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="text-xs font-bold text-slate-700 mb-1 block">Password</label>
              <div className="relative">
                <input
                  type={showSignUpPassword ? 'text' : 'password'}
                  required
                  value={signUpPassword}
                  onChange={(e) => setSignUpPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full pl-3.5 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowSignUpPassword(!showSignUpPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600"
                >
                  {showSignUpPassword ? (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18" /></svg>
                  ) : (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                  )}
                </button>
              </div>
              {signUpPassword && (
                <div className="mt-1.5 flex items-center gap-2">
                  <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className={`h-full transition-all duration-300 ${passwordStrength.color}`} style={{ width: passwordStrength.width }}></div>
                  </div>
                  <span className="text-[10px] font-bold text-slate-500">{passwordStrength.label}</span>
                </div>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label className="text-xs font-bold text-slate-700 mb-1 block">Confirm Password</label>
              <input
                type={showSignUpPassword ? 'text' : 'password'}
                required
                value={signUpConfirmPassword}
                onChange={(e) => setSignUpConfirmPassword(e.target.value)}
                placeholder="Re-enter password"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white transition-colors"
              />
            </div>

            {/* Remember Me Checkbox */}
            <div className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-100 rounded-xl">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                />
                <span className="text-xs font-bold text-slate-800">Remember me on this device</span>
              </label>
              <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">Auto-login</span>
            </div>

            {/* Terms checkbox */}
            <div className="flex items-start gap-2 pt-1">
              <input
                type="checkbox"
                id="terms"
                checked={agreeTerms}
                onChange={(e) => setAgreeTerms(e.target.checked)}
                className="w-4 h-4 mt-0.5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
              />
              <label htmlFor="terms" className="text-[11px] text-slate-500 leading-tight">
                I agree to the <span className="text-emerald-600 font-bold underline">Terms of Service</span> and <span className="text-emerald-600 font-bold underline">Privacy Policy</span>.
              </label>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3.5 rounded-2xl text-xs sm:text-sm active:scale-[0.98] transition-all shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                  <span>Creating Account...</span>
                </>
              ) : (
                <span>Create Account & Sign In</span>
              )}
            </button>

            <div className="text-center pt-1">
              <p className="text-xs text-slate-500">
                Already registered?{' '}
                <button
                  type="button"
                  onClick={() => { setAuthMode('signin'); setErrorMsg(''); }}
                  className="font-black text-emerald-600 hover:text-emerald-700 underline underline-offset-2"
                >
                  Log in here
                </button>
              </p>
            </div>
          </form>
        )}
      </div>

      {/* ----------------- GOOGLE IDENTITY DIALOG MODAL ----------------- */}
      {isGoogleModalOpen && (
        <div className="fixed inset-0 z-[11000] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl animate-in zoom-in-95 duration-200 border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span className="font-black text-sm text-slate-800">Sign in with Google</span>
              </div>
              <button
                type="button"
                onClick={() => setIsGoogleModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600 mt-3 mb-4">
              Choose your Gmail account to continue to <span className="font-bold text-[#1B263B]">SwiftHustle SA</span>
            </p>

            <div className="space-y-2 mb-4">
              {/* Primary User Account (From Context: jongcobo114@gmail.com) */}
              <button
                type="button"
                onClick={() => handleSelectGoogleAccount('jongcobo114@gmail.com', 'Jong Cobo')}
                className="w-full flex items-center gap-3 p-3 rounded-2xl border-2 border-emerald-500/60 bg-emerald-50/40 hover:bg-emerald-50 transition-all text-left group"
              >
                <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-200 border border-slate-300 shrink-0">
                  <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200" alt="Avatar" className="w-full h-full object-cover" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-xs text-slate-900 group-hover:text-emerald-700">Jong Cobo</span>
                    <span className="text-[9px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">Active</span>
                  </div>
                  <span className="text-[11px] text-slate-500 truncate block">jongcobo114@gmail.com</span>
                </div>
              </button>

              {/* SwiftHustle Admin Account */}
              <button
                type="button"
                onClick={() => handleSelectGoogleAccount('admin@swifthustle.co.za', 'Mandla Zulu')}
                className="w-full flex items-center gap-3 p-3 rounded-2xl border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-all text-left"
              >
                <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-200 border border-slate-300 shrink-0">
                  <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200" alt="Avatar" className="w-full h-full object-cover" />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="font-black text-xs text-slate-800 block">Mandla Zulu</span>
                  <span className="text-[11px] text-slate-500 truncate block">admin@swifthustle.co.za</span>
                </div>
              </button>

              {/* Custom Google Account Option */}
              {!showCustomGoogleInput ? (
                <button
                  type="button"
                  onClick={() => setShowCustomGoogleInput(true)}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl border border-dashed border-slate-300 hover:border-slate-400 text-slate-600 hover:text-slate-900 transition-all text-left text-xs font-bold"
                >
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 text-lg">
                    +
                  </div>
                  <span>Use another Gmail account</span>
                </button>
              ) : (
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 animate-in fade-in">
                  <input
                    type="text"
                    value={customGoogleName}
                    onChange={(e) => setCustomGoogleName(e.target.value)}
                    placeholder="Your Full Name"
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs"
                  />
                  <input
                    type="email"
                    value={customGoogleEmail}
                    onChange={(e) => setCustomGoogleEmail(e.target.value)}
                    placeholder="your.email@gmail.com"
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs"
                  />
                  <button
                    type="button"
                    disabled={!customGoogleEmail || !customGoogleEmail.includes('@')}
                    onClick={() => handleSelectGoogleAccount(customGoogleEmail, customGoogleName || 'Google User')}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold"
                  >
                    Connect this Gmail
                  </button>
                </div>
              )}
            </div>

            {/* Remember Me Option on Google */}
            <div className="flex items-center gap-2 mb-4 p-2 bg-slate-50 rounded-xl">
              <input
                type="checkbox"
                id="googleRemember"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
              />
              <label htmlFor="googleRemember" className="text-[11px] text-slate-600 cursor-pointer">
                Remember this account on this device
              </label>
            </div>

            <p className="text-[10px] text-slate-400 leading-tight text-center">
              To continue, Google will share your name, email address, language preference, and profile picture with SwiftHustle SA.
            </p>
          </div>
        </div>
      )}

      {/* ----------------- FORGOT PASSWORD MODAL ----------------- */}
      {isForgotModalOpen && (
        <div className="fixed inset-0 z-[11000] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="font-black text-sm text-slate-900">Reset Your Password</span>
              <button
                type="button"
                onClick={() => { setIsForgotModalOpen(false); setForgotSent(false); }}
                className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            {!forgotSent ? (
              <div className="mt-3 space-y-3">
                <p className="text-xs text-slate-600">
                  Enter your registered Gmail or email address and we will dispatch an instant password reset link.
                </p>
                <input
                  type="email"
                  value={forgotEmail || signInEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="your.email@gmail.com"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (forgotEmail || signInEmail) {
                      setForgotSent(true);
                    }
                  }}
                  className="w-full py-3 bg-[#1B263B] text-white rounded-xl text-xs font-bold hover:bg-slate-800"
                >
                  Send Reset Link
                </button>
              </div>
            ) : (
              <div className="mt-4 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-xl">
                  ✓
                </div>
                <h4 className="font-bold text-sm text-slate-900">Reset Link Sent!</h4>
                <p className="text-xs text-slate-500">
                  Check your inbox at <span className="font-bold text-slate-800">{forgotEmail || signInEmail}</span> to complete your password reset.
                </p>
                <button
                  type="button"
                  onClick={() => { setIsForgotModalOpen(false); setForgotSent(false); }}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold"
                >
                  Back to Log In
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default WelcomeAuthScreen;
