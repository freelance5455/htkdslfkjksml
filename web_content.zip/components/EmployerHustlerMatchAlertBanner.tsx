import React, { useEffect, useState } from 'react';
import { EmployerHustlerMatchAlert, AvailableHustler, Gig } from '../types';

interface EmployerHustlerMatchAlertBannerProps {
  alert: EmployerHustlerMatchAlert | null;
  onDismiss: () => void;
  onHireHustler: (hustler: AvailableHustler, gig?: Gig) => void;
  onChatHustler: (hustler: AvailableHustler) => void;
  onViewOnRadar?: (hustler: AvailableHustler) => void;
}

export const EmployerHustlerMatchAlertBanner: React.FC<EmployerHustlerMatchAlertBannerProps> = ({
  alert,
  onDismiss,
  onHireHustler,
  onChatHustler,
  onViewOnRadar
}) => {
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (!alert || isPaused) return;

    const timer = setTimeout(() => {
      onDismiss();
    }, 15000);

    return () => clearTimeout(timer);
  }, [alert, isPaused, onDismiss]);

  if (!alert) return null;

  return (
    <div
      role="alert"
      aria-live="assertive"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      className="fixed top-3 left-3 right-3 sm:left-auto sm:right-4 sm:w-[440px] z-[9999] animate-in slide-in-from-top-4 fade-in duration-300 pointer-events-auto"
    >
      <div className="bg-[#1B263B] text-white rounded-3xl p-4 sm:p-5 shadow-[0_20px_50px_rgba(0,0,0,0.45)] border-2 border-emerald-400 relative overflow-hidden backdrop-blur-xl">
        {/* Glow & Decorative accents */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-emerald-500/20 rounded-full -mr-16 -mt-16 blur-2xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-[#D4AF37]/15 rounded-full -ml-12 -mb-12 blur-xl pointer-events-none"></div>

        {/* Top Header Badge */}
        <div className="flex items-center justify-between gap-2 mb-3 relative z-10">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-400">
              Candidate Match • Ready to Work
            </span>
          </div>

          <button
            onClick={onDismiss}
            className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 text-white/70 hover:text-white flex items-center justify-center transition-colors"
            title="Dismiss notification"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Hustler Profile & Gig Context */}
        <div className="relative z-10">
          <div className="flex items-start gap-3 mb-2.5">
            {/* Avatar with online & verification indicator */}
            <div className="relative shrink-0">
              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-emerald-400/80 bg-slate-800 shadow-md">
                <img
                  src={alert.hustler.avatar}
                  alt={alert.hustler.name}
                  className="w-full h-full object-cover aspect-square"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-[#1B263B] shadow-sm"></div>
              {alert.hustler.isVerified && (
                <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#D4AF37] border-2 border-[#1B263B] text-[9px] font-black text-slate-950 flex items-center justify-center">
                  ★
                </div>
              )}
            </div>

            {/* Details */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <h4 className="text-sm font-black text-white tracking-tight truncate">
                  {alert.hustler.name}
                </h4>
                <span className="text-xs font-black text-amber-300 flex items-center gap-0.5 shrink-0">
                  <span>★</span> {alert.hustler.rating.toFixed(1)}
                  <span className="text-[10px] text-slate-400 font-normal">({alert.hustler.completedJobs} jobs)</span>
                </span>
              </div>

              <p className="text-xs text-emerald-300 font-bold truncate">
                {alert.hustler.skill}
              </p>

              <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-300">
                <span className="font-black text-white">R{alert.hustler.hourlyRate}/hr</span>
                <span>•</span>
                <span className="font-semibold text-slate-300">{alert.distanceKm} km away</span>
              </div>
            </div>
          </div>

          {/* Matched Gig Callout Box */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-2.5 mb-3 flex items-center justify-between gap-2">
            <div className="min-w-0">
              <span className="text-[9px] font-black uppercase tracking-wider text-slate-400 block">
                Matching Your Posted Job:
              </span>
              <p className="text-xs font-bold text-white truncate">
                {alert.matchedGig.title}
              </p>
            </div>
            <div className="shrink-0 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-lg text-xs font-black">
              R{alert.matchedGig.price.toLocaleString()}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-3 gap-2 pt-1 border-t border-white/10">
            <button
              onClick={() => {
                onHireHustler(alert.hustler, alert.matchedGig);
                onDismiss();
              }}
              className="py-2.5 px-2 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1 shadow-md active:scale-95 transition-all truncate"
              title="Direct hire with escrow hold"
            >
              <span>Direct Hire</span>
            </button>

            <button
              onClick={() => {
                onChatHustler(alert.hustler);
                onDismiss();
              }}
              className="py-2.5 px-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1 active:scale-95 transition-all border border-white/10 truncate"
              title="Message candidate"
            >
              <span>Chat</span>
              <span>💬</span>
            </button>

            {onViewOnRadar && (
              <button
                onClick={() => {
                  onViewOnRadar(alert.hustler);
                  onDismiss();
                }}
                className="py-2.5 px-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1 active:scale-95 transition-all border border-white/10 truncate"
                title="View candidate position on map"
              >
                <span>Radar</span>
                <span>📍</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployerHustlerMatchAlertBanner;
