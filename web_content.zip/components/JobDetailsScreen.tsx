
import React from 'react';
import { Gig, UserStats } from '../types';

interface JobDetailsScreenProps {
  gig: Gig;
  onBack: () => void;
  onApply: (gig: Gig) => void;
  isHustler: boolean;
}

const JobDetailsScreen: React.FC<JobDetailsScreenProps> = ({ gig, onBack, onApply, isHustler }) => {
  return (
    <div className="flex flex-col h-full bg-[#FAFBFC] animate-in slide-in-from-right duration-300">
      <header className="relative h-64 overflow-hidden shrink-0">
        <img 
          src={gig.referencePhoto || `https://picsum.photos/seed/${gig.id}/800/600`} 
          className="w-full h-full object-cover" 
          alt={gig.title} 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
        <button 
          onClick={onBack}
          className="absolute top-6 left-6 w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-white border border-white/20 active:scale-90 transition-all"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7"/>
          </svg>
        </button>
        
        <div className="absolute bottom-6 left-6 right-6">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 bg-[#D4AF37] text-white text-[9px] font-black uppercase tracking-widest rounded-lg">
              {gig.category}
            </span>
            {gig.isVerifiedUser && (
              <span className="px-3 py-1 bg-blue-500 text-white text-[9px] font-black uppercase tracking-widest rounded-lg flex items-center gap-1">
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"/>
                </svg>
                Verified
              </span>
            )}
          </div>
          <h1 className="text-2xl font-black text-white leading-tight uppercase tracking-tight">{gig.title}</h1>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-6 py-8 no-scrollbar">
        <div className="flex items-center justify-between mb-8 p-6 bg-white rounded-[32px] border border-slate-50 shadow-sm">
           <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Escrowed Budget</p>
              <p className="text-3xl font-black text-[#1B263B]">R {gig.price}</p>
           </div>
           <div className="text-right">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Posted</p>
              <p className="text-sm font-black text-slate-600">{new Date(gig.datePosted).toLocaleDateString()}</p>
           </div>
        </div>

        <section className="mb-8">
          <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Job Description</h3>
          <p className="text-sm text-slate-600 leading-relaxed font-medium">
            {gig.description}
          </p>
        </section>

        <section className="mb-8">
           <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Verification Requirements</h3>
           <div className="bg-slate-50 rounded-3xl p-5 border border-slate-100 flex items-center gap-4">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                 {gig.requiresPoW ? '📸' : '✅'}
              </div>
              <div>
                 <h4 className="text-xs font-black text-[#1B263B] uppercase tracking-tight">
                    {gig.requiresPoW ? 'Smart Proof of Work' : 'Simple Completion'}
                 </h4>
                 <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                    {gig.requiresPoW ? 'Requires Before/After photos' : 'Standard status toggle'}
                 </p>
              </div>
           </div>
        </section>

        <section className="mb-8">
           <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Employer Trust Score</h3>
           <div className="bg-white rounded-[32px] p-6 border border-slate-100 flex items-center gap-4 shadow-sm">
              <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-2xl border border-slate-100">
                 🤝
              </div>
              <div className="flex-1">
                 <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-black text-[#1B263B]">4.9 / 5.0</span>
                    <div className="flex gap-0.5 text-[#D4AF37]">
                       {[...Array(5)].map((_, i) => (
                         <svg key={i} className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                       ))}
                    </div>
                 </div>
                 <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Secure Escrow Guaranteed</p>
              </div>
           </div>
        </section>
      </div>

      <div className="p-6 bg-white border-t border-slate-100 shrink-0">
        <button 
          onClick={() => onApply(gig)}
          className={`w-full py-5 rounded-[24px] font-black text-xs uppercase tracking-[0.4em] shadow-2xl active:scale-95 transition-all
            ${isHustler ? 'bg-[#1B263B] text-white shadow-[#1B263B]/20' : 'bg-slate-100 text-slate-400 cursor-not-allowed'}
          `}
        >
          {isHustler ? 'Apply for Gig' : 'Hustler Mode Only'}
        </button>
      </div>
    </div>
  );
};

export default JobDetailsScreen;
