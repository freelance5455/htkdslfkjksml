import React, { useEffect, useState } from 'react';
import { HighPayingGigAlert, Gig } from '../types';

interface HighPayingGigAlertBannerProps {
  alert: HighPayingGigAlert | null;
  onDismiss: () => void;
  onViewGig: (gig: Gig) => void;
  onViewOnRadar?: (gig: Gig) => void;
}

export const HighPayingGigAlertBanner: React.FC<HighPayingGigAlertBannerProps> = ({
  alert,
  onDismiss,
  onViewGig,
  onViewOnRadar
}) => {
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (!alert || isPaused) return;

    const timer = setTimeout(() => {
      onDismiss();
    }, 14000);

    return () => clearTimeout(timer);
  }, [alert, isPaused, onDismiss]);

  if (!alert) return null;

  return (
    <div
      role="alert"
      aria-live="assertive"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      className="fixed top-3 left-3 right-3 sm:left-auto sm:right-4 sm:w-[420px] z-[9999] animate-in slide-in-from-top-4 fade-in duration-300 pointer-events-auto"
    >
      <div className="bg-[#1B263B] text-white rounded-3xl p-4 sm:p-5 shadow-[0_20px_50px_rgba(0,0,0,0.4)] border-2 border-[#D4AF37] relative overflow-hidden backdrop-blur-xl">
        {/* Glow & Decorative accents */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-[#D4AF37]/20 rounded-full -mr-16 -mt-16 blur-2xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-emerald-500/10 rounded-full -ml-12 -mb-12 blur-xl pointer-events-none"></div>

        {/* Top Header Badge */}
        <div className="flex items-center justify-between gap-2 mb-2.5 relative z-10">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#D4AF37]">
              Nearby High-Paying Gig • Within 5km
            </span>
          </div>

          <button
            onClick={onDismiss}
            className="w-7 h-7 rounded-xl bg-white/10 hover:bg-white/20 text-white/70 hover:text-white flex items-center justify-center transition-colors"
            title="Dismiss notification"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Gig Info */}
        <div className="relative z-10">
          <div className="flex items-start justify-between gap-3 mb-1.5">
            <h4 className="text-base font-black text-white tracking-tight leading-snug line-clamp-1">
              {alert.gig.title}
            </h4>
            <div className="shrink-0 bg-gradient-to-r from-[#D4AF37] to-amber-300 text-slate-950 px-2.5 py-0.5 rounded-full text-xs font-black shadow-sm">
              R{alert.gig.price.toLocaleString()}
            </div>
          </div>

          <p className="text-xs text-slate-300 line-clamp-1 mb-3 font-medium">
            {alert.gig.description}
          </p>

          {/* Tags row: Matched Skill & Distance */}
          <div className="flex items-center flex-wrap gap-2 mb-3.5">
            <span className="inline-flex items-center gap-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider">
              <span>⚡</span> Skill: {alert.matchedSkill}
            </span>
            <span className="inline-flex items-center gap-1 bg-white/10 text-slate-200 border border-white/10 px-2.5 py-0.5 rounded-lg text-[10px] font-bold">
              <span>📍</span> {alert.distanceKm} km away
            </span>
            <span className="inline-flex items-center gap-1 bg-white/10 text-slate-200 border border-white/10 px-2.5 py-0.5 rounded-lg text-[10px] font-bold">
              <span>🏷️</span> {alert.gig.category}
            </span>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-1 border-t border-white/10">
            <button
              onClick={() => {
                onViewGig(alert.gig);
                onDismiss();
              }}
              className="py-2.5 px-3 bg-gradient-to-r from-[#D4AF37] to-amber-400 hover:from-amber-400 hover:to-[#D4AF37] text-slate-950 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
            >
              <span>View &amp; Apply</span>
              <span>→</span>
            </button>

            {onViewOnRadar && (
              <button
                onClick={() => {
                  onViewOnRadar(alert.gig);
                  onDismiss();
                }}
                className="py-2.5 px-3 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 active:scale-95 transition-all border border-white/10"
              >
                <span>Radar Pin</span>
                <span>📍</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HighPayingGigAlertBanner;
