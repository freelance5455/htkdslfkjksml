
import React, { useState } from 'react';

interface NavbarProps {
  onAuth: (mode: 'login' | 'signup') => void;
  userSession?: any;
  onLogout?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onAuth, userSession, onLogout }) => {
  const [logoError, setLogoError] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-[#050b1a]/80 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl overflow-hidden border border-white/10 p-1 bg-white shadow-[0_0_15px_rgba(255,255,255,0.1)] flex-shrink-0 flex items-center justify-center">
              {!logoError ? (
                <img 
                  src="HOPE-PAY.jpg" 
                  alt="Hope Pay Logo" 
                  className="w-full h-full object-cover"
                  onError={() => setLogoError(true)}
                />
              ) : (
                <div className="w-full h-full bg-[#050b1a] flex items-center justify-center text-cyan-400 font-black text-2xl">L</div>
              )}
            </div>
            <div className="flex flex-col text-left">
                <span className="text-xl font-black tracking-tighter text-white leading-none uppercase">LUMINA <span className="text-cyan-400">PAY</span></span>
                <span className="text-[8px] font-black text-slate-500 uppercase tracking-[0.3em] mt-1">Sovereign Portal</span>
            </div>
          </div>
          <div className="hidden lg:flex space-x-10">
            <a href="#services" className="text-slate-400 hover:text-cyan-400 text-[10px] font-black uppercase tracking-widest transition">Services</a>
            <a href="#lumina-balance" className="text-slate-400 hover:text-cyan-400 text-[10px] font-black uppercase tracking-widest transition">Lumina Vault</a>
            <a href="#banking" className="text-slate-400 hover:text-cyan-400 text-[10px] font-black uppercase tracking-widest transition">Nexus Bridge</a>
            <a href="#tugs" className="text-slate-400 hover:text-cyan-400 text-[10px] font-black uppercase tracking-widest transition">TU5G Gate</a>
          </div>
          <div className="flex items-center gap-6">
            {!userSession ? (
              <>
                <button 
                  onClick={() => onAuth('login')}
                  className="text-slate-400 hover:text-white text-[10px] font-black uppercase tracking-widest transition"
                >
                  Portal Login
                </button>
                <button 
                  onClick={() => onAuth('signup')}
                  className="bg-white text-[#050b1a] px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-[0_0_20px_rgba(255,255,255,0.15)] hover:bg-cyan-400 transition transform hover:-translate-y-0.5"
                >
                  Join GAISN
                </button>
              </>
            ) : (
              <div className="flex items-center gap-4">
                 <div className="flex flex-col items-end">
                    <span className="text-white text-[10px] font-black uppercase tracking-wider">{userSession.name}</span>
                    <span className={`text-[8px] font-black uppercase tracking-widest ${userSession.role.includes('admin') ? 'text-red-500' : 'text-cyan-400'}`}>
                      {userSession.role === 'user' ? 'VERIFIED MEMBER' : userSession.role.replace('_', ' ')}
                    </span>
                 </div>
                 <button 
                    onClick={onLogout}
                    className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-red-500/20 hover:border-red-500/50 hover:text-red-500 transition-all text-slate-400"
                 >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                 </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
