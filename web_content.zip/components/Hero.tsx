
import React, { useState } from 'react';

const Hero: React.FC = () => {
  const [imgError, setImgError] = useState(false);

  return (
    <section className="relative pt-12 pb-32 overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full gradient-bg -skew-y-3 origin-top-left -z-10"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
        {/* Official Logo Display */}
        <div className="flex justify-center mb-12 animate-in fade-in zoom-in duration-1000">
          <div className="relative p-3 bg-white rounded-[2.5rem] shadow-2xl">
            <div className="w-32 h-32 md:w-48 md:h-48 rounded-[2rem] overflow-hidden bg-white flex items-center justify-center">
              {!imgError ? (
                <img 
                  src="HOPE-PAY.jpg" 
                  alt="Hope Pay Official Logo" 
                  className="w-full h-full object-contain p-2"
                  onError={() => setImgError(true)}
                />
              ) : (
                <div className="w-full h-full gradient-bg flex flex-col items-center justify-center text-white font-black">
                  <span className="text-4xl">H</span>
                  <span className="text-xs tracking-tighter">HOPE PAY</span>
                </div>
              )}
            </div>
            <div className="absolute -bottom-4 -right-4 bg-amber-500 text-[#050b1a] text-[10px] font-black px-4 py-1.5 rounded-full border-4 border-white shadow-xl animate-bounce">
              TMC ACTIVATED
            </div>
            <div className="absolute -top-4 -left-4 bg-cyan-500 text-white text-[9px] font-black px-4 py-1.5 rounded-full border-4 border-white shadow-xl flex items-center gap-2">
              <span className="w-2 h-2 bg-white rounded-full animate-ping"></span>
              CCTU AUDITED
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-4 mb-8">
          <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-amber-500/10 backdrop-blur-md border border-amber-500/30 text-[10px] font-black text-amber-400 uppercase tracking-[0.2em]">
            <span className="w-2 h-2 bg-amber-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(245,158,11,0.8)]"></span>
            TMC & TC ASSETS LIVE
          </div>
          <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-cyan-500/10 backdrop-blur-md border border-cyan-500/30 text-[10px] font-black text-cyan-400 uppercase tracking-[0.2em]">
            <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(34,211,238,0.8)]"></span>
            GAIC & CCTU AUDIT READY
          </div>
          <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-blue-500/10 backdrop-blur-md border border-blue-500/30 text-[10px] font-black text-blue-400 uppercase tracking-[0.2em]">
            <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></span>
            TUT TREASURY BACKED
          </div>
          <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-violet-500/10 backdrop-blur-md border border-violet-500/30 text-[10px] font-black text-violet-400 uppercase tracking-[0.2em]">
            <span className="w-2 h-2 bg-violet-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(167,139,250,0.8)]"></span>
            UDIA INTERNET AUTHORITY
          </div>
        </div>

        <h1 className="text-5xl md:text-8xl font-black mb-8 tracking-tighter leading-none uppercase">
          Digital <br />
          <span className="text-amber-400">Asset Sovereignty.</span>
        </h1>
        
        <p className="text-lg md:text-2xl text-blue-100 max-w-3xl mx-auto mb-12 leading-relaxed font-bold uppercase tracking-tight">
          CCTU Audited TMC, TC, and GAIC Assets. 
          Universal cryptographic trust for the global thimothism nexus.
        </p>

        <div className="flex flex-col sm:flex-row justify-center gap-6">
          <button className="bg-white text-blue-900 px-12 py-5 rounded-2xl font-black text-sm uppercase tracking-widest shadow-[0_20px_50px_rgba(255,255,255,0.2)] hover:scale-105 transition-all">
            ASSET PORTAL
          </button>
          <button className="bg-white/10 backdrop-blur-md text-white border border-white/30 px-12 py-5 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-white/20 transition-all">
            AUDIT REPORTS
          </button>
        </div>
        
        <div className="mt-24 flex justify-center px-4">
            <div className="relative group max-w-5xl w-full">
                <div className="absolute -inset-1 bg-cyan-500/20 rounded-[3rem] blur-3xl opacity-20 group-hover:opacity-40 transition duration-1000"></div>
                <div className="relative rounded-[3rem] overflow-hidden border border-white/10 shadow-2xl bg-[#0d1b35]">
                  <img 
                      src="https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=1200&q=80" 
                      alt="Digital Asset Infrastructure" 
                      className="w-full h-auto opacity-60 grayscale hover:grayscale-0 transition-all duration-1000"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0d1b35] via-[#0d1b35]/40 to-transparent"></div>
                  <div className="absolute bottom-12 left-12 text-left">
                    <div className="flex flex-wrap items-center gap-4 mb-4">
                      <div className="bg-cyan-600 text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-[0_0_10px_rgba(34,211,238,0.8)]">CCTU AUDIT ACTIVE</div>
                      <div className="bg-amber-600 text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-[0_0_10px_rgba(245,158,11,0.8)]">TMC & TC READY</div>
                      <div className="bg-violet-600 text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-[0_0_10px_violet]">UDIA NET AUTHORITY</div>
                    </div>
                    <h3 className="text-4xl font-black text-white uppercase tracking-tighter leading-none">Global Asset Nexus Portal</h3>
                  </div>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
