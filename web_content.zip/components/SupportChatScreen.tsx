
import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import { getSwiftyResponse } from './swiftyEngine';

interface SupportChatScreenProps {
  onBack: () => void;
}

const SupportChatScreen: React.FC<SupportChatScreenProps> = ({ onBack }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '0',
      senderId: 'ai',
      text: "Howzit! I'm Swifty, your SwiftHustle AI assistant. ⚡\n\nI'm here 24/7 to answer your questions, assist with gigs, guide your escrow payments & withdrawals, or ensure your safety. What's on your mind today?",
      timestamp: Date.now(),
      isAi: true
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isExiting, setIsExiting] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleBack = () => {
    setIsExiting(true);
    setTimeout(onBack, 300);
  };

  const handleCallPolice = () => {
    window.location.href = "tel:10111";
  };

  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      senderId: 'user',
      text: text.trim(),
      timestamp: Date.now(),
      isAi: false
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    try {
      const reply = await getSwiftyResponse(text.trim(), messages);
      
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        senderId: 'ai',
        text: reply,
        timestamp: Date.now(),
        isAi: true
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error("Swifty interaction error:", error);
      // Even in a worst-case scenario, provide a helpful engaging fallback, NOT a glitch message!
      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          senderId: 'ai',
          text: "I'm right here with you! Whether you need advice on finding gigs, setting up your escrow payment, or staying safe on site, ask me anything.",
          timestamp: Date.now(),
          isAi: true
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickReplies = [
    { label: '🛡️ Escrow Protection', text: 'Can you explain how Escrow protection works on SwiftHustle?' },
    { label: '💸 How do I withdraw?', text: 'What are my options to withdraw money from my wallet?' },
    { label: '📍 Safe Meeting Tips', text: 'What are the best safety tips for meeting clients in South Africa?' },
    { label: '⭐ Get More Gigs', text: 'How do I improve my rating and win more gigs?' },
    { label: '🙋 Speak to Support', text: 'I would like to speak to a human admin team member.' }
  ];

  return (
    <div className={`flex flex-col h-full bg-[#F4F7F9] transition-transform duration-300 ${isExiting ? 'translate-x-full' : 'translate-x-0'}`}>
      {/* Top Header */}
      <header className="bg-[#1B263B] p-4 flex items-center justify-between shrink-0 shadow-lg relative z-10 border-b border-white/5">
        <div className="flex items-center gap-3">
          <button 
            onClick={handleBack}
            className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white active:scale-90 transition-all border border-white/5"
            title="Go back"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M11 17l-5-5m0 0l5-5m-5 5h12"/></svg>
          </button>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#D4AF37] to-amber-200 flex items-center justify-center text-xl shadow-inner border-2 border-white/20">
              ⚡
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-white font-black tracking-tight text-sm leading-none">Swifty</h2>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              </div>
              <span className="text-[9px] font-black text-emerald-400 uppercase tracking-widest block mt-0.5">24/7 AI Assistant</span>
            </div>
          </div>
        </div>
        
        {/* Emergency quick-dial button */}
        <button 
          onClick={handleCallPolice}
          className="flex items-center gap-2 px-3.5 py-2 bg-[#F43F5E] hover:bg-rose-600 rounded-xl text-white shadow-lg shadow-rose-500/20 active:scale-95 transition-all"
          title="Emergency Police Hotline"
        >
          <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"/></svg>
          <span className="text-[10px] font-black uppercase tracking-widest">SAPS 10111</span>
        </button>
      </header>

      {/* Messages Scroll Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4 no-scrollbar pb-36"
      >
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex ${msg.isAi ? 'justify-start' : 'justify-end'} animate-in slide-in-from-bottom-2 fade-in duration-200`}
          >
            {msg.isAi && (
              <div className="w-7 h-7 rounded-full bg-[#1B263B] text-white flex items-center justify-center text-xs font-black mr-2 self-end mb-1 shrink-0 border border-white/10 shadow-sm">
                ⚡
              </div>
            )}
            <div className={`max-w-[85%] p-4 sm:p-5 rounded-3xl shadow-sm ${
              msg.isAi 
                ? 'bg-[#1B263B] rounded-bl-xs border border-white/5 text-white' 
                : 'bg-[#D4AF37] rounded-br-xs text-slate-900 font-medium'
            }`}>
              <p className="text-xs sm:text-sm font-medium leading-relaxed whitespace-pre-wrap">{msg.text || '...'}</p>
              <p className={`text-[8px] font-bold mt-2 uppercase tracking-widest ${msg.isAi ? 'text-white/40' : 'text-slate-900/50'}`}>
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start items-center gap-2 animate-in slide-in-from-bottom-2 fade-in duration-200">
            <div className="w-7 h-7 rounded-full bg-[#1B263B] text-white flex items-center justify-center text-xs font-black shrink-0 border border-white/10">
              ⚡
            </div>
            <div className="bg-[#1B263B] rounded-3xl rounded-bl-xs px-4 py-3 shadow-sm border border-white/5 flex items-center gap-1.5">
              <div className="w-2 h-2 bg-[#D4AF37] rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-[#D4AF37] rounded-full animate-bounce [animation-delay:0.15s]"></div>
              <div className="w-2 h-2 bg-[#D4AF37] rounded-full animate-bounce [animation-delay:0.3s]"></div>
              <span className="text-[10px] text-white/50 font-bold ml-1">Swifty is thinking...</span>
            </div>
          </div>
        )}
      </div>

      {/* Input & Quick Actions Bar */}
      <div className="bg-white/95 backdrop-blur-xl border-t border-slate-200/80 p-3 sm:p-4 absolute bottom-0 left-0 right-0 space-y-2.5 shadow-2xl">
        {/* Quick Suggestion Pills */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {quickReplies.map((q, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(q.text)}
              className="whitespace-nowrap px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-200/80 rounded-full text-[10px] font-black text-[#1B263B] uppercase tracking-wider transition-all active:scale-95 shadow-xs"
            >
              {q.label}
            </button>
          ))}
        </div>
        
        {/* Input Field */}
        <div className="flex gap-2.5">
          <input 
            type="text" 
            placeholder="Ask Swifty about gigs, escrow, safety..."
            className="flex-1 bg-slate-100/90 border border-slate-200 rounded-2xl px-5 py-3.5 text-xs sm:text-sm font-medium focus:ring-2 focus:ring-[#1B263B]/20 outline-none transition-all placeholder:text-slate-400 text-slate-800"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage(inputText)}
          />
          <button 
            disabled={!inputText.trim() || isLoading}
            onClick={() => handleSendMessage(inputText)}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all shadow-md active:scale-90 shrink-0
              ${!inputText.trim() || isLoading ? 'bg-slate-200 text-slate-400 shadow-none' : 'bg-[#1B263B] text-white hover:bg-slate-800 shadow-[#1B263B]/20'}
            `}
            title="Send Message"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SupportChatScreen;
