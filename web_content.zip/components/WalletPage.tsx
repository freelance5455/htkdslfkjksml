
import React, { useState, useMemo } from 'react';
import { UserProfile, Transaction, UserStats, UserTier } from '../types';

interface WalletPageProps {
  profile: UserProfile;
  stats: UserStats;
  transactions: Transaction[];
  onAddTx: (tx: Omit<Transaction, 'id' | 'timestamp'>) => void;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  isHustler: boolean;
}

interface BankInfo {
  name: string;
  code: string;
  shortName: string;
  badge: string;
  themeColor: string;
}

const SA_BANKS_DETAILED: BankInfo[] = [
  { name: 'Capitec Bank', code: '470010', shortName: 'Capitec', badge: 'Fastest Payout', themeColor: '#002C6C' },
  { name: 'First National Bank (FNB)', code: '250655', shortName: 'FNB', badge: 'eWallet Linked', themeColor: '#009999' },
  { name: 'Standard Bank', code: '051001', shortName: 'Standard Bank', badge: 'Instant Money', themeColor: '#0033AA' },
  { name: 'Absa Bank', code: '632005', shortName: 'Absa', badge: 'CashSend Hub', themeColor: '#FF0000' },
  { name: 'Nedbank', code: '198765', shortName: 'Nedbank', badge: 'MobiMoney', themeColor: '#004A26' },
  { name: 'TymeBank', code: '678910', shortName: 'TymeBank', badge: 'Zero Admin Fee', themeColor: '#10B981' },
  { name: 'Discovery Bank', code: '679000', shortName: 'Discovery Bank', badge: 'PayShap Certified', themeColor: '#4F46E5' },
  { name: 'Investec Bank', code: '580105', shortName: 'Investec', badge: 'Private Banking', themeColor: '#1B263B' },
];

const EWALLET_SERVICES = [
  { id: 'fnb_ewallet', name: 'FNB eWallet', icon: '🔵', bank: 'FNB', fee: 10, speed: 'Instant (5–10 mins)' },
  { id: 'sb_instant', name: 'Standard Bank Instant Money', icon: '🔷', bank: 'Standard Bank', fee: 10, speed: 'Instant (5–10 mins)' },
  { id: 'absa_cashsend', name: 'Absa CashSend', icon: '🔴', bank: 'Absa', fee: 10, speed: 'Instant (5–10 mins)' },
  { id: 'ned_mobi', name: 'Nedbank MobiMoney', icon: '🟢', bank: 'Nedbank', fee: 10, speed: 'Instant (5–10 mins)' }
];

const PAYSHAP_BANKS = ['Capitec Bank', 'FNB', 'Nedbank', 'Standard Bank', 'Absa Bank', 'TymeBank', 'Discovery Bank'];

const RETAIL_STORES = [
  { id: 'shoprite_checkers', name: 'Shoprite / Checkers Money Market', icon: '🛍️', note: 'Over 1,200 stores nationwide' },
  { id: 'pnp', name: 'Pick n Pay Till Points', icon: '🛒', note: 'Collect at any till or kiosk' },
  { id: 'boxer', name: 'Boxer Superstores', icon: '🥊', note: 'Instant cash out with ID' }
];

const DEPOSIT_METHODS = [
  { id: 'ozow', name: 'Instant EFT (Ozow)', icon: '⚡', provider: 'PayFast' },
  { id: '1voucher', name: '1Voucher / OTT', icon: '🎟️', provider: 'Retail' },
  { id: 'eft', name: 'Manual Bank EFT', icon: '🏦', provider: 'Direct' }
];

type WithdrawMethodType = 'bank' | 'ewallet' | 'payshap' | 'retail';

interface WithdrawOptionConfig {
  id: WithdrawMethodType;
  title: string;
  subtitle: string;
  icon: string;
  badge: string;
  badgeColor: string;
  fee: number;
  speed: string;
}

const WITHDRAW_OPTIONS: WithdrawOptionConfig[] = [
  {
    id: 'bank',
    title: 'Bank Transfer (EFT)',
    subtitle: 'Direct deposit to any South African bank account',
    icon: '🏦',
    badge: 'Free • 1–2 Days',
    badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    fee: 0,
    speed: '1–2 Business Days'
  },
  {
    id: 'ewallet',
    title: 'ATM Cash Voucher',
    subtitle: 'Withdraw cash at ATM without a card via SMS PIN',
    icon: '📱',
    badge: 'R10 Fee • 5–15 Mins',
    badgeColor: 'bg-blue-50 text-blue-700 border-blue-200',
    fee: 10,
    speed: 'Instant (5–15 Mins)'
  },
  {
    id: 'payshap',
    title: 'PayShap™ Instant RTC',
    subtitle: 'Real-time bank clearing via ShapID or cellphone',
    icon: '⚡',
    badge: 'R7.50 Fee • < 60s',
    badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
    fee: 7.50,
    speed: 'Real-time (< 60 Seconds)'
  },
  {
    id: 'retail',
    title: 'Retail Till Payout',
    subtitle: 'Cash collection at Shoprite, Checkers, Pick n Pay, Boxer',
    icon: '🛒',
    badge: 'R8 Fee • Instant Barcode',
    badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
    fee: 8,
    speed: 'Instant Barcode'
  }
];

interface WithdrawalSuccessReceipt {
  reference: string;
  amount: number;
  fee: number;
  net: number;
  method: string;
  destination: string;
  speed: string;
  date: string;
}

const WalletPage: React.FC<WalletPageProps> = ({ profile, stats, transactions, onAddTx, onUpdateProfile, isHustler }) => {
  const [activeSubView, setActiveSubView] = useState<'main' | 'deposit' | 'withdraw' | 'instant_payout'>('main');
  const [withdrawType, setWithdrawType] = useState<WithdrawMethodType>('bank');
  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [withdrawalSuccess, setWithdrawalSuccess] = useState<WithdrawalSuccessReceipt | null>(null);
  
  // Withdrawal State - Bank
  const [withdrawBank, setWithdrawBank] = useState(SA_BANKS_DETAILED[0].shortName);
  const [accountHolder, setAccountHolder] = useState(profile.fullName || 'Registered Account');
  const [withdrawAcc, setWithdrawAcc] = useState('');
  const [withdrawAccType, setWithdrawAccType] = useState<'Cheque / Current' | 'Savings'>('Savings');
  const [withdrawBranch, setWithdrawBranch] = useState(SA_BANKS_DETAILED[0].code);

  // Withdrawal State - eWallet
  const [selectedEWallet, setSelectedEWallet] = useState(EWALLET_SERVICES[0]);
  const [ewalletPhone, setEwalletPhone] = useState(profile.phone || '');

  // Withdrawal State - PayShap
  const [shapId, setShapId] = useState(profile.phone || '');
  const [shapBank, setShapBank] = useState(PAYSHAP_BANKS[0]);

  // Withdrawal State - Retail Store
  const [retailStore, setRetailStore] = useState(RETAIL_STORES[0].name);
  const [retailIdNumber, setRetailIdNumber] = useState(profile.idNumber || '');

  // Active bank object
  const activeBankObj = useMemo(() => {
    return SA_BANKS_DETAILED.find(b => b.shortName === withdrawBank) || SA_BANKS_DETAILED[0];
  }, [withdrawBank]);

  // Handle bank change with auto branch code
  const handleBankChange = (shortName: string) => {
    setWithdrawBank(shortName);
    const bank = SA_BANKS_DETAILED.find(b => b.shortName === shortName);
    if (bank) {
      setWithdrawBranch(bank.code);
    }
  };

  // Task 1: Instant Payout Logic Eligibility
  const instantPayoutUnlocked = useMemo(() => {
    return profile.verification.identity === 'verified' && (stats.jobsPostedCount || 0) >= 5 && stats.averageRating >= 4.5;
  }, [profile, stats]);

  const handleDeposit = async () => {
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) return;
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    onAddTx({ type: 'in', label: 'Funds Added via EFT', amount: num, status: 'completed', method: 'Ozow' });
    setIsProcessing(false);
    setActiveSubView('main');
    setAmount('');
  };

  const handleWithdrawalRequest = async () => {
    const num = parseFloat(amount);
    if (isNaN(num) || num < 50 || num > profile.walletBalance) return;
    
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 1800));

    const selectedOption = WITHDRAW_OPTIONS.find(o => o.id === withdrawType)!;
    const currentFee = selectedOption.fee;
    const netPayout = Math.max(0, num - currentFee);
    
    let methodLabel = '';
    let destinationDetail = '';

    if (withdrawType === 'bank') {
      methodLabel = `Bank EFT (${withdrawBank})`;
      destinationDetail = `${withdrawBank} • ${withdrawAccType} • Acc ending in ${withdrawAcc.slice(-4) || '****'}`;
    } else if (withdrawType === 'ewallet') {
      methodLabel = selectedEWallet.name;
      destinationDetail = `SMS Voucher to ${ewalletPhone}`;
    } else if (withdrawType === 'payshap') {
      methodLabel = `PayShap™ (${shapBank})`;
      destinationDetail = `ShapID ${shapId} • ${shapBank}`;
    } else if (withdrawType === 'retail') {
      methodLabel = `Retail Cash-Out (${retailStore.split(' ')[0]})`;
      destinationDetail = `${retailStore} • Till Barcode with ID ending in ${retailIdNumber.slice(-4) || '****'}`;
    }

    const reference = `WTH-ZA-${Math.floor(100000 + Math.random() * 900000)}`;

    onUpdateProfile({ walletBalance: Math.max(0, profile.walletBalance - num) });
    onAddTx({
      type: 'out',
      label: `Withdrawal: ${methodLabel}`,
      amount: num,
      status: withdrawType === 'bank' ? 'pending' : 'completed',
      method: methodLabel,
      fee: currentFee
    });

    setIsProcessing(false);
    setWithdrawalSuccess({
      reference,
      amount: num,
      fee: currentFee,
      net: netPayout,
      method: methodLabel,
      destination: destinationDetail,
      speed: selectedOption.speed,
      date: new Date().toLocaleDateString('en-ZA', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })
    });
  };

  // Task 2: Instant Rails payout execution
  const handleInstantPayoutSubmit = async () => {
    if (!profile.escrowBalance || isProcessing) return;
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const releaseAmount = profile.escrowBalance;
    const fee = 15; // R15 Convenience Fee

    onUpdateProfile({ 
      walletBalance: profile.walletBalance - fee,
      escrowBalance: 0 
    });

    onAddTx({
      type: 'transfer',
      label: 'Instant Escrow Release (RTC)',
      amount: releaseAmount,
      status: 'completed',
      method: 'PayShap/RTC',
      fee: fee
    });

    setIsProcessing(false);
    setActiveSubView('main');
    alert(`Instant Release Successful! R${releaseAmount} moved to hustler's wallet via real-time clearing rails.`);
  };

  // Calculate fees & net payout
  const numAmount = parseFloat(amount) || 0;
  const activeOptionConfig = WITHDRAW_OPTIONS.find(o => o.id === withdrawType)!;
  const currentFee = activeOptionConfig.fee;
  const netPayout = Math.max(0, numAmount - currentFee);

  // Form validity check
  const isAmountValid = numAmount >= 50 && numAmount <= profile.walletBalance;
  let isFormValid = isAmountValid;
  if (withdrawType === 'bank') {
    isFormValid = isAmountValid && withdrawAcc.trim().length >= 6 && accountHolder.trim().length >= 3;
  } else if (withdrawType === 'ewallet') {
    isFormValid = isAmountValid && ewalletPhone.trim().length >= 9;
  } else if (withdrawType === 'payshap') {
    isFormValid = isAmountValid && shapId.trim().length >= 8;
  } else if (withdrawType === 'retail') {
    isFormValid = isAmountValid && retailIdNumber.trim().length >= 6;
  }

  // SUBVIEW: WITHDRAW FUNDS
  if (activeSubView === 'withdraw') {
    // If successfully submitted, show the confirmation receipt
    if (withdrawalSuccess) {
      return (
        <div className="flex flex-col h-full bg-[#FAFBFC] p-6 animate-in fade-in duration-300 overflow-y-auto no-scrollbar pb-10">
          <div className="my-auto max-w-sm mx-auto w-full">
            <div className="bg-white rounded-[36px] p-7 shadow-2xl border border-slate-100 text-center relative overflow-hidden">
              <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-3xl mx-auto mb-5 flex items-center justify-center text-4xl shadow-inner border border-emerald-100">
                ✓
              </div>
              <h2 className="text-2xl font-black text-[#1B263B] mb-1">Withdrawal Initiated</h2>
              <p className="text-xs text-slate-400 font-semibold mb-6">Your payout has been authorized and dispatched to SARB clearing rails.</p>

              {/* Reference Box */}
              <div className="bg-slate-50 rounded-2xl p-3 mb-6 flex items-center justify-between border border-slate-100">
                <div className="text-left">
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Reference Number</p>
                  <p className="text-xs font-black text-[#1B263B] tracking-wider">{withdrawalSuccess.reference}</p>
                </div>
                <span className="text-[10px] font-black bg-emerald-100 text-emerald-700 px-2.5 py-1 rounded-full uppercase tracking-wider">
                  Queued
                </span>
              </div>

              {/* Breakdown */}
              <div className="space-y-3 text-left mb-6 text-xs bg-slate-50/60 p-4 rounded-2xl border border-slate-100">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-bold">Payout Method</span>
                  <span className="font-black text-[#1B263B]">{withdrawalSuccess.method}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-bold">Destination</span>
                  <span className="font-bold text-[#1B263B] max-w-[180px] truncate text-right">{withdrawalSuccess.destination}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-bold">Gross Amount</span>
                  <span className="font-bold text-[#1B263B]">R {withdrawalSuccess.amount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-bold">Processing Fee</span>
                  <span className="font-bold text-rose-500">{withdrawalSuccess.fee === 0 ? 'FREE (R0.00)' : `R ${withdrawalSuccess.fee.toFixed(2)}`}</span>
                </div>
                <div className="h-[1px] bg-slate-200"></div>
                <div className="flex justify-between items-center pt-1">
                  <span className="font-black text-[#1B263B] uppercase text-[10px] tracking-wider">Net Amount Received</span>
                  <span className="font-black text-emerald-600 text-base">R {withdrawalSuccess.net.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-400">
                  <span>Estimated Arrival</span>
                  <span className="font-bold text-[#1B263B]">{withdrawalSuccess.speed}</span>
                </div>
              </div>

              <button
                onClick={() => {
                  setWithdrawalSuccess(null);
                  setActiveSubView('main');
                  setAmount('');
                }}
                className="w-full py-4 bg-[#1B263B] text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl active:scale-95 transition-all"
              >
                Return to Wallet
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="flex flex-col h-full bg-[#FAFBFC] overflow-y-auto no-scrollbar p-6 animate-in slide-in-from-right duration-300 pb-20">
        {/* Header */}
        <header className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => {
                setActiveSubView('main');
                setAmount('');
              }} 
              className="p-2.5 bg-white rounded-2xl shadow-sm border border-slate-100 text-slate-500 active:scale-95 transition-all hover:bg-slate-50"
              title="Back to Wallet"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 19l-7-7 7-7"/>
              </svg>
            </button>
            <div>
              <h1 className="text-xl font-black text-[#1B263B]">Withdraw Funds</h1>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Select Payout Option</p>
            </div>
          </div>
          <span className="px-2.5 py-1 bg-slate-100 text-slate-500 rounded-full text-[9px] font-black uppercase tracking-wider flex items-center gap-1 border border-slate-200">
            <span>🔒</span> SARB Secured
          </span>
        </header>

        {/* Available Balance Pill */}
        <div className="bg-gradient-to-r from-[#1B263B] to-[#2B3B52] rounded-3xl p-5 text-white mb-6 shadow-xl flex items-center justify-between">
          <div>
            <p className="text-white/60 text-[9px] font-black uppercase tracking-widest mb-1">Available to Withdraw</p>
            <h3 className="text-2xl font-black">R {profile.walletBalance.toLocaleString()}.00</h3>
          </div>
          <button 
            type="button"
            onClick={() => setAmount(profile.walletBalance.toString())}
            className="px-3.5 py-2 bg-[#D4AF37] hover:bg-[#c29f2e] text-white rounded-xl text-[10px] font-black uppercase tracking-wider shadow-md active:scale-95 transition-all"
          >
            Cash Out All
          </button>
        </div>

        {/* Step 1: Amount Selection */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 mb-6">
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">
            1. Enter Withdrawal Amount (ZAR)
          </label>
          <div className="relative mb-3">
            <span className="absolute left-5 top-1/2 -translate-y-1/2 text-2xl font-black text-slate-300">R</span>
            <input 
              autoFocus 
              type="number" 
              placeholder="0.00" 
              className={`w-full bg-slate-50 border-2 rounded-2xl py-4 pl-12 pr-4 text-2xl font-black text-[#1B263B] outline-none transition-all ${
                numAmount > profile.walletBalance 
                  ? 'border-rose-400 bg-rose-50/30' 
                  : numAmount >= 50 
                    ? 'border-emerald-400 bg-emerald-50/10' 
                    : 'border-slate-100 focus:border-[#1B263B]'
              }`}
              value={amount} 
              onChange={e => setAmount(e.target.value)} 
            />
          </div>

          {/* Validation Warnings */}
          {numAmount > profile.walletBalance && (
            <p className="text-[11px] font-bold text-rose-500 mb-3 flex items-center gap-1">
              <span>⚠️</span> Amount exceeds your available balance of R{profile.walletBalance.toLocaleString()}.
            </p>
          )}
          {numAmount > 0 && numAmount < 50 && (
            <p className="text-[11px] font-bold text-amber-500 mb-3 flex items-center gap-1">
              <span>ℹ️</span> Minimum withdrawal amount is R50.00.
            </p>
          )}

          {/* Quick Amount Chips */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
            {[100, 250, 500, 1000].map(val => (
              <button
                key={val}
                type="button"
                onClick={() => setAmount(val.toString())}
                disabled={val > profile.walletBalance}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all ${
                  amount === val.toString()
                    ? 'bg-[#1B263B] text-white shadow-sm'
                    : val > profile.walletBalance
                      ? 'bg-slate-100 text-slate-300 cursor-not-allowed'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 active:scale-95'
                }`}
              >
                R{val}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setAmount(profile.walletBalance.toString())}
              disabled={profile.walletBalance <= 0}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all ${
                amount === profile.walletBalance.toString() && profile.walletBalance > 0
                  ? 'bg-[#D4AF37] text-white shadow-sm'
                  : 'bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100 active:scale-95'
              }`}
            >
              MAX
            </button>
          </div>
        </div>

        {/* Step 2: Withdrawal Options Grid */}
        <div className="mb-6">
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 px-1">
            2. Choose Withdrawal Option
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {WITHDRAW_OPTIONS.map(opt => {
              const isSelected = withdrawType === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setWithdrawType(opt.id)}
                  className={`p-4 rounded-3xl text-left transition-all border-2 flex flex-col justify-between relative group active:scale-[0.98] ${
                    isSelected
                      ? 'bg-white border-[#1B263B] shadow-lg ring-2 ring-[#1B263B]/10'
                      : 'bg-white/80 hover:bg-white border-slate-100 hover:border-slate-200 shadow-sm'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-2xl p-2 bg-slate-50 rounded-2xl group-hover:scale-110 transition-transform">
                      {opt.icon}
                    </span>
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded-full border uppercase tracking-wider ${opt.badgeColor}`}>
                      {opt.badge}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-black text-xs text-[#1B263B] mb-0.5">{opt.title}</h4>
                    <p className="text-[10px] text-slate-400 font-medium leading-tight">{opt.subtitle}</p>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[9px] font-bold">
                    <span className="text-slate-400">Arrival: <strong className="text-slate-700">{opt.speed}</strong></span>
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      isSelected ? 'border-[#1B263B] bg-[#1B263B]' : 'border-slate-300'
                    }`}>
                      {isSelected && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 3: Destination Inputs Based on Chosen Option */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 mb-6">
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">
            3. Destination Details ({activeOptionConfig.title})
          </label>

          {/* Option A: Bank Account (EFT) */}
          {withdrawType === 'bank' && (
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                  Select Bank
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {SA_BANKS_DETAILED.map(bank => (
                    <button
                      key={bank.code}
                      type="button"
                      onClick={() => handleBankChange(bank.shortName)}
                      className={`p-3 rounded-2xl text-left border text-xs font-black transition-all flex items-center justify-between ${
                        withdrawBank === bank.shortName
                          ? 'border-[#1B263B] bg-[#1B263B]/5 text-[#1B263B]'
                          : 'border-slate-100 hover:border-slate-200 text-slate-600 bg-slate-50/50'
                      }`}
                    >
                      <span className="truncate">{bank.shortName}</span>
                      {withdrawBank === bank.shortName && <span className="text-[#1B263B] text-xs">●</span>}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                    Universal Branch Code
                  </label>
                  <input
                    type="text"
                    readOnly
                    value={withdrawBranch}
                    className="w-full bg-slate-100 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-black text-slate-700 cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                    Account Type
                  </label>
                  <select
                    value={withdrawAccType}
                    onChange={e => setWithdrawAccType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-black text-slate-700 outline-none"
                  >
                    <option value="Savings">Savings</option>
                    <option value="Cheque / Current">Cheque / Current</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Account Holder Full Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Sipho Ndlovu"
                  value={accountHolder}
                  onChange={e => setAccountHolder(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-black text-slate-800 outline-none focus:border-[#1B263B]"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Bank Account Number
                </label>
                <input
                  type="number"
                  placeholder="e.g. 1029384756"
                  value={withdrawAcc}
                  onChange={e => setWithdrawAcc(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-black text-slate-800 outline-none focus:border-[#1B263B]"
                />
                <p className="text-[9px] text-slate-400 font-medium mt-1">Please ensure account details match your registered KYC name.</p>
              </div>
            </div>
          )}

          {/* Option B: ATM Cash Voucher (eWallet) */}
          {withdrawType === 'ewallet' && (
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                  Select eWallet Service
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {EWALLET_SERVICES.map(srv => (
                    <button
                      key={srv.id}
                      type="button"
                      onClick={() => setSelectedEWallet(srv)}
                      className={`p-3 rounded-2xl text-left border text-xs font-black transition-all flex items-center gap-2 ${
                        selectedEWallet.id === srv.id
                          ? 'border-[#1B263B] bg-[#1B263B]/5 text-[#1B263B]'
                          : 'border-slate-100 hover:border-slate-200 text-slate-600 bg-slate-50/50'
                      }`}
                    >
                      <span>{srv.icon}</span>
                      <span className="truncate">{srv.name.split(' ')[0]}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    Recipient Cellphone Number
                  </label>
                  {profile.phone && (
                    <button
                      type="button"
                      onClick={() => setEwalletPhone(profile.phone)}
                      className="text-[9px] font-black text-[#D4AF37] uppercase tracking-wider hover:underline"
                    >
                      Use My Number
                    </button>
                  )}
                </div>
                <input
                  type="tel"
                  placeholder="e.g. 082 123 4567"
                  value={ewalletPhone}
                  onChange={e => setEwalletPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-black text-slate-800 outline-none focus:border-[#1B263B]"
                />
              </div>

              <div className="bg-blue-50/60 border border-blue-100 rounded-2xl p-3.5 text-[10px] text-blue-900 leading-relaxed flex items-start gap-2.5">
                <span className="text-base shrink-0">📲</span>
                <div>
                  <strong className="block font-black uppercase tracking-tight mb-0.5">Cardless ATM Cashout:</strong>
                  An SMS with a voucher number and ATM PIN will be delivered to this number. Cash can be drawn immediately at any {selectedEWallet.bank} ATM without requiring a bank card.
                </div>
              </div>
            </div>
          )}

          {/* Option C: PayShap™ Instant RTC */}
          {withdrawType === 'payshap' && (
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Recipient Bank (PayShap Enabled)
                </label>
                <select
                  value={shapBank}
                  onChange={e => setShapBank(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-3 text-xs font-black text-slate-800 outline-none focus:border-[#1B263B]"
                >
                  {PAYSHAP_BANKS.map(b => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    ShapID or Linked Cellphone Number
                  </label>
                  {profile.phone && (
                    <button
                      type="button"
                      onClick={() => setShapId(profile.phone)}
                      className="text-[9px] font-black text-[#D4AF37] uppercase tracking-wider hover:underline"
                    >
                      Use My Number
                    </button>
                  )}
                </div>
                <input
                  type="text"
                  placeholder="e.g. 0821234567@capitec or 0821234567"
                  value={shapId}
                  onChange={e => setShapId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-black text-slate-800 outline-none focus:border-[#1B263B]"
                />
              </div>

              <div className="bg-amber-50/60 border border-amber-200/60 rounded-2xl p-3.5 text-[10px] text-amber-900 leading-relaxed flex items-start gap-2.5">
                <span className="text-base shrink-0">⚡</span>
                <div>
                  <strong className="block font-black uppercase tracking-tight mb-0.5">Instant Clearing (&lt; 60 seconds):</strong>
                  PayShap is South Africa's rapid payment system. Funds clear directly into the recipient's bank account within a minute, 24/7/365.
                </div>
              </div>
            </div>
          )}

          {/* Option D: Retail Store Cash-Out */}
          {withdrawType === 'retail' && (
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                  Select Retail Partner
                </label>
                <div className="space-y-2">
                  {RETAIL_STORES.map(store => (
                    <button
                      key={store.id}
                      type="button"
                      onClick={() => setRetailStore(store.name)}
                      className={`w-full p-3.5 rounded-2xl text-left border text-xs font-black transition-all flex items-center justify-between ${
                        retailStore === store.name
                          ? 'border-[#1B263B] bg-[#1B263B]/5 text-[#1B263B]'
                          : 'border-slate-100 hover:border-slate-200 text-slate-600 bg-slate-50/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{store.icon}</span>
                        <div>
                          <p className="font-black text-[#1B263B] text-xs">{store.name}</p>
                          <p className="text-[9px] text-slate-400 font-normal">{store.note}</p>
                        </div>
                      </div>
                      {retailStore === store.name && <span className="text-[#1B263B] text-sm">✓</span>}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Recipient South African ID Number
                </label>
                <input
                  type="text"
                  maxLength={13}
                  placeholder="e.g. 9508125192083"
                  value={retailIdNumber}
                  onChange={e => setRetailIdNumber(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-black text-slate-800 outline-none focus:border-[#1B263B]"
                />
                <p className="text-[9px] text-slate-400 font-medium mt-1">Cashier will check your green barcoded ID or smartcard at checkout.</p>
              </div>

              <div className="bg-purple-50/60 border border-purple-100 rounded-2xl p-3.5 text-[10px] text-purple-900 leading-relaxed flex items-start gap-2.5">
                <span className="text-base shrink-0">🛒</span>
                <div>
                  <strong className="block font-black uppercase tracking-tight mb-0.5">Collect at Store Till:</strong>
                  You will receive an in-app barcode and reference code. Present it along with your SA ID at any store till point to receive physical cash.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Step 4: Summary & Payout Calculation */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 mb-6">
          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">
            Payout Breakdown
          </h4>
          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between items-center text-slate-500 font-medium">
              <span>Gross Withdrawal</span>
              <span className="font-bold text-[#1B263B]">R {numAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center text-slate-500 font-medium">
              <span>Clearing / Rail Fee</span>
              <span className="font-bold text-rose-500">{currentFee === 0 ? 'FREE (R0.00)' : `R ${currentFee.toFixed(2)}`}</span>
            </div>
            <div className="h-[1px] bg-slate-100 my-1"></div>
            <div className="flex justify-between items-center text-sm font-black text-[#1B263B]">
              <span>You Receive</span>
              <span className="text-emerald-600 text-lg">R {netPayout.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold pt-1">
              <span>Estimated Delivery</span>
              <span className="text-[#1B263B]">{activeOptionConfig.speed}</span>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button
          type="button"
          disabled={!isFormValid || isProcessing}
          onClick={handleWithdrawalRequest}
          className={`w-full py-5 rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl transition-all flex items-center justify-center gap-3 ${
            isFormValid && !isProcessing
              ? 'bg-[#1B263B] text-white active:scale-95 shadow-[#1B263B]/20 hover:bg-[#25344d]'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
          }`}
        >
          {isProcessing ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              <span>Authorizing Rail Transfer...</span>
            </div>
          ) : (
            `Authorize Withdrawal • R ${netPayout.toFixed(2)}`
          )}
        </button>
      </div>
    );
  }

  // SUBVIEW: DEPOSIT FUNDS
  if (activeSubView === 'deposit') {
    return (
      <div className="flex flex-col h-full bg-[#FAFBFC] p-6 animate-in slide-in-from-right duration-300">
        <header className="flex items-center gap-4 mb-8">
          <button onClick={() => setActiveSubView('main')} className="p-2 bg-white rounded-xl shadow-sm border border-slate-100 text-slate-400">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7"/></svg>
          </button>
          <h1 className="text-xl font-black text-[#1B263B]">Add Funds</h1>
        </header>

        <div className="bg-white rounded-[32px] p-8 shadow-xl border border-slate-50 mb-6">
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Enter Amount (ZAR)</label>
          <div className="relative mb-8">
            <span className="absolute left-6 top-1/2 -translate-y-1/2 text-2xl font-black text-slate-300">R</span>
            <input autoFocus type="number" placeholder="0.00" className="w-full bg-slate-50 border-2 border-slate-100 rounded-[24px] py-6 pl-14 pr-6 text-3xl font-black text-[#1B263B] outline-none" value={amount} onChange={e => setAmount(e.target.value)} />
          </div>
          <div className="space-y-3">
             <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Select Payment Method</label>
             {DEPOSIT_METHODS.map(method => (
               <button key={method.id} className="w-full flex items-center justify-between p-5 bg-slate-50 rounded-[20px] border border-transparent hover:border-[#1B263B] transition-all group">
                 <div className="flex items-center gap-4"><span className="text-2xl">{method.icon}</span><div className="text-left"><p className="text-sm font-black text-[#1B263B]">{method.name}</p><p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">Powered by {method.provider}</p></div></div>
                 <div className="w-5 h-5 rounded-full border-2 border-slate-200 group-hover:border-[#1B263B]"></div>
               </button>
             ))}
          </div>
        </div>
        <button disabled={!amount || isProcessing} onClick={handleDeposit} className="w-full py-5 bg-[#1B263B] text-white rounded-[24px] font-black text-xs uppercase tracking-[0.2em] shadow-xl active:scale-95 flex items-center justify-center gap-3">
          {isProcessing ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Proceed to Secure Payment'}
        </button>
      </div>
    );
  }

  // SUBVIEW: INSTANT PAYOUT
  if (activeSubView === 'instant_payout') {
    return (
      <div className="flex flex-col h-full bg-[#FAFBFC] p-6 animate-in slide-in-from-right duration-300">
        <header className="flex items-center gap-4 mb-8">
          <button onClick={() => setActiveSubView('main')} className="p-2 bg-white rounded-xl shadow-sm border border-slate-100 text-slate-400">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7"/></svg>
          </button>
          <h1 className="text-xl font-black text-[#1B263B]">Instant Payout</h1>
        </header>

        <div className="bg-white rounded-[40px] p-8 shadow-xl border border-slate-50 mb-8">
           <div className="text-center mb-10">
              <div className="w-20 h-20 bg-[#D4AF37]/10 text-4xl flex items-center justify-center rounded-3xl mx-auto mb-6">⚡</div>
              <h2 className="text-2xl font-black text-[#1B263B]">Execute PayShap™</h2>
              <p className="text-sm text-slate-400 font-medium px-4">Move escrow funds instantly to your service provider's wallet.</p>
           </div>

           <div className="space-y-6">
              <div className="flex justify-between items-center px-2">
                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Escrow Total</span>
                 <span className="text-xl font-black text-[#1B263B]">R {profile.escrowBalance.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center px-2">
                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Convenience Fee</span>
                 <span className="text-sm font-black text-rose-500">R 15.00</span>
              </div>
              <div className="h-[1px] bg-slate-100"></div>
              <div className="flex justify-between items-center px-2">
                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">To be Dispatched</span>
                 <span className="text-2xl font-black text-[#D4AF37]">R {profile.escrowBalance.toLocaleString()}</span>
              </div>
           </div>
        </div>

        <button 
          disabled={isProcessing || !profile.escrowBalance}
          onClick={handleInstantPayoutSubmit}
          className="w-full py-5 bg-[#D4AF37] text-white rounded-[24px] font-black text-xs uppercase tracking-[0.2em] shadow-xl active:scale-95 flex items-center justify-center gap-3 transition-all"
        >
          {isProcessing ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Confirm Instant Transfer'}
        </button>
        <p className="text-center text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-6 px-10 leading-relaxed">By confirming, you authorize immediate fund release via SARB clearing rails. This cannot be reversed.</p>
      </div>
    );
  }

  // MAIN WALLET VIEW
  return (
    <div className="flex flex-col h-full bg-[#FAFBFC] no-scrollbar overflow-y-auto pb-24">
      <header className="p-6 pt-8 pb-4">
        <h1 className="text-3xl font-black text-[#1B263B]">Wallet</h1>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mt-1">Secured with SwiftHustle Escrow</p>
      </header>

      <div className="px-6 mb-8">
        <div className="bg-gradient-to-br from-[#1B263B] to-[#2C3E50] rounded-[40px] p-8 text-white shadow-2xl relative overflow-hidden">
          <p className="text-white/40 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Available Balance</p>
          <h2 className="text-4xl font-black mb-8">R {profile.walletBalance.toLocaleString()}.00</h2>
          
          <div className="flex gap-4">
            <button onClick={() => setActiveSubView('withdraw')} className="flex-1 bg-white/10 backdrop-blur-md py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest border border-white/10 active:scale-95 transition-all hover:bg-white/20">Withdraw</button>
            <button onClick={() => setActiveSubView('deposit')} className="flex-1 bg-[#D4AF37] text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg active:scale-95 transition-all hover:bg-[#c29f2e]">Add Funds</button>
          </div>
        </div>
      </div>

      <div className="px-6 mb-8">
        <div className="bg-white rounded-[32px] p-6 shadow-xl border border-slate-50 flex items-center justify-between relative overflow-hidden group">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-amber-50 rounded-[22px] flex items-center justify-center text-2xl">🔒</div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Held in Escrow</p>
              <h3 className="text-xl font-black text-[#1B263B]">R {profile.escrowBalance.toLocaleString()}.00</h3>
            </div>
          </div>
          
          {/* Task 1: Instant Payout Button */}
          {!isHustler && (
            <button 
              disabled={!instantPayoutUnlocked || profile.escrowBalance <= 0}
              onClick={() => setActiveSubView('instant_payout')}
              className={`px-4 py-2 rounded-xl text-[8px] font-black uppercase tracking-widest transition-all
                ${instantPayoutUnlocked ? 'bg-[#D4AF37] text-white shadow-lg shadow-[#D4AF37]/20 active:scale-95' : 'bg-slate-100 text-slate-300 cursor-not-allowed'}
              `}
            >
              {instantPayoutUnlocked ? 'Instant Payout' : 'Locked'}
            </button>
          )}
        </div>
        {!isHustler && !instantPayoutUnlocked && (
           <p className="text-[8px] font-black text-rose-500 uppercase tracking-tighter mt-3 text-center">Complete Employer Goals in Account tab to unlock Instant Releases</p>
        )}
      </div>

      <div className="px-6 flex-1 min-h-0">
        <div className="flex items-center justify-between mb-6 px-1"><h3 className="text-xs font-black text-[#1B263B] uppercase tracking-widest">Recent Activity</h3><button className="text-[9px] font-black text-slate-400 uppercase tracking-widest">View All</button></div>
        <div className="space-y-4">
          {transactions.map(tx => (
            <div key={tx.id} className="bg-white rounded-[28px] p-4 shadow-sm border border-slate-50 flex items-center justify-between group">
              <div className="flex items-center gap-4">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-lg shadow-inner ${tx.type === 'in' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-[#1B263B]'}`}>{tx.type === 'in' ? '➕' : (tx.type === 'transfer' ? '⚡' : '🏦')}</div>
                <div>
                  <h4 className="text-xs font-black text-[#1B263B] uppercase tracking-tight">{tx.label}</h4>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">{new Date(tx.timestamp).toLocaleDateString()} • {tx.status}</p>
                </div>
              </div>
              <div className="text-right"><p className={`text-sm font-black ${tx.type === 'in' ? 'text-emerald-600' : 'text-[#1B263B]'}`}>{tx.type === 'in' ? '+' : '-'} R{tx.amount.toLocaleString()}</p></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WalletPage;
