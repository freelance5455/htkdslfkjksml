
import React, { useState, useEffect, useRef } from 'react';
import { UserStats, UserTier, GigStatus, Gig } from '../types';

interface GigFormProps {
  onClose: () => void;
  isHustler: boolean;
  stats: UserStats;
  onAddGig?: (gig: Gig) => void;
  userLocation?: [number, number];
}

const CATEGORIES = [
  { id: 'General', pow: true },
  { id: 'Plumbing', pow: true },
  { id: 'Electrical', pow: true },
  { id: 'Cleaning', pow: true },
  { id: 'Tech Support', pow: false },
  { id: 'Errands', pow: false },
];

const GigForm: React.FC<GigFormProps> = ({ onClose, isHustler, stats, onAddGig, userLocation }) => {
  const isPremium = stats.currentTier === UserTier.PREMIUM;
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    category: 'General',
    isFeatured: false,
    requiresPoW: true,
    referencePhoto: ''
  });

  // Task 1: Auto-set requiresPoW based on category
  useEffect(() => {
    const cat = CATEGORIES.find(c => c.id === formData.category);
    if (cat) {
      setFormData(prev => ({ ...prev, requiresPoW: cat.pow }));
    }
  }, [formData.category]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData(prev => ({ ...prev, referencePhoto: reader.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const baseLoc = userLocation || [-26.1076, 28.0567];
    // Slightly randomize offset (within 1-3km) so it looks like a realistic nearby job
    const latOffset = (Math.random() - 0.5) * 0.03;
    const lngOffset = (Math.random() - 0.5) * 0.03;
    const gigLoc: [number, number] = [baseLoc[0] + latOffset, baseLoc[1] + lngOffset];

    const newGig: Gig = {
      id: `gig-${Date.now()}`,
      title: formData.title,
      description: formData.description,
      price: parseFloat(formData.price) || 850,
      location: gigLoc,
      category: formData.category,
      datePosted: Date.now(),
      status: 'open',
      requiresPoW: formData.requiresPoW,
      referencePhoto: formData.referencePhoto,
      isVerifiedUser: true,
      isFeatured: formData.isFeatured
    };

    if (onAddGig) {
      onAddGig(newGig);
    }
    alert(`${isHustler ? 'Work offer' : 'Job request'} posted successfully! Live on Radar.`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[2000] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center">
      <div className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-[32px] p-8 shadow-2xl animate-in slide-in-from-bottom duration-300 max-h-[90vh] overflow-y-auto no-scrollbar">
        <input type="file" className="hidden" ref={fileInputRef} accept="image/*" onChange={handlePhotoUpload} />
        
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-black text-gray-900">
            {isHustler ? 'Offer Your Services' : 'Post a New Job'}
          </h2>
          <button onClick={onClose} className="p-2 bg-gray-100 rounded-full text-gray-500 hover:text-gray-800 transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pb-4">
          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Title</label>
            <input 
              required
              type="text" 
              placeholder={isHustler ? "e.g., Professional Plumber" : "e.g., Fix leaking pipe"}
              className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#1B263B] outline-none transition-all"
              value={formData.title}
              onChange={e => setFormData({...formData, title: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Description</label>
            <textarea 
              required
              rows={3}
              placeholder="Tell us more about the gig..."
              className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#1B263B] outline-none transition-all resize-none"
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Budget (R)</label>
              <input 
                required
                type="number" 
                placeholder="450"
                className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#1B263B] outline-none transition-all"
                value={formData.price}
                onChange={e => setFormData({...formData, price: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 ml-1">Category</label>
              <select 
                className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#1B263B] outline-none transition-all appearance-none"
                value={formData.category}
                onChange={e => setFormData({...formData, category: e.target.value})}
              >
                {CATEGORIES.map(c => (
                  <option key={c.id} value={c.id}>{c.id}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Task 1: Add Reference Photo Button */}
          {!isHustler && (
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Reference Photo (Optional)</label>
              <div className="flex gap-4">
                {formData.referencePhoto ? (
                  <div className="relative w-full aspect-video rounded-2xl overflow-hidden group">
                    <img src={formData.referencePhoto} className="w-full h-full object-cover" alt="Reference" />
                    <button 
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, referencePhoto: '' }))}
                      className="absolute top-2 right-2 p-2 bg-black/50 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12"/></svg>
                    </button>
                  </div>
                ) : (
                  <button 
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-6 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center gap-2 text-slate-400 hover:bg-slate-50 transition-all active:scale-[0.98]"
                  >
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    <span className="text-[10px] font-black uppercase tracking-widest">Add Reference Photo</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* PoW Indicator */}
          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-sm">
                📸
              </div>
              <div>
                <h4 className="text-[10px] font-black text-gray-800 uppercase tracking-tight">Smart Proof of Work</h4>
                <p className="text-[8px] text-gray-500 font-bold uppercase tracking-widest">
                  {formData.requiresPoW ? 'Before/After Photos Required' : 'Simple Toggle Verification'}
                </p>
              </div>
            </div>
            <div className={`w-3 h-3 rounded-full ${formData.requiresPoW ? 'bg-emerald-500' : 'bg-slate-300'}`}></div>
          </div>

          {/* Featured Listing */}
          <div className="relative group">
            <div className={`p-4 rounded-2xl flex items-center justify-between border-2 transition-all ${isPremium ? 'bg-emerald-50 border-emerald-200' : 'bg-slate-50 border-slate-100 opacity-60'}`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm">
                  🚀
                </div>
                <div>
                  <h4 className="text-xs font-black text-gray-800 uppercase tracking-tight">Featured Listing</h4>
                  <p className="text-[9px] text-gray-500 font-bold uppercase">Boost visibility by 500%</p>
                </div>
              </div>
              <input 
                type="checkbox" 
                disabled={!isPremium}
                checked={formData.isFeatured}
                onChange={e => setFormData({...formData, isFeatured: e.target.checked})}
                className="w-5 h-5 rounded border-gray-300 text-[#D4AF37] focus:ring-[#D4AF37] cursor-pointer"
              />
            </div>
            {!isPremium && (
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                <div className="bg-gray-900 text-white text-[8px] font-black uppercase tracking-widest px-3 py-1 rounded-full shadow-2xl">
                  Unlock at Premium Tier
                </div>
              </div>
            )}
          </div>

          <div className="pt-4">
            <button 
              type="submit"
              className="w-full bg-[#1B263B] text-white py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg shadow-[#1B263B]/20 hover:bg-slate-800 active:scale-[0.98] transition-all"
            >
              Post to Radar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default GigForm;
