import React from 'react';
import { ChatThread, AvailableHustler } from '../types';

interface ChatOccupantProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  thread: ChatThread;
  isHustlerViewer?: boolean; // True if the current user viewing is a Hustler
  isContactHired?: boolean;
  onDirectHire?: (hustler: AvailableHustler) => void;
  onCallContact?: (thread: ChatThread) => void;
  onCompleteJob?: (job: { id: string, title: string, price: number }, isInstant: boolean) => void;
}

export const ChatOccupantProfileModal: React.FC<ChatOccupantProfileModalProps> = ({
  isOpen,
  onClose,
  thread,
  isHustlerViewer = false,
  isContactHired = false,
  onDirectHire,
  onCallContact,
  onCompleteJob
}) => {
  if (!isOpen) return null;

  // Determine whether the occupant being viewed is a Hustler or an Employer
  // If occupantRole is specified, use it. Otherwise, if current viewer is Hustler, occupant is Employer, and vice versa.
  const isOccupantHustler = thread.occupantRole 
    ? thread.occupantRole === 'hustler' 
    : !isHustlerViewer;

  // Resolved metrics with sensible defaults for high-fidelity presentation
  const rating = thread.rating || 4.9;
  const reviewsCount = thread.reviewsCount || (isOccupantHustler ? 48 : 28);
  const jobsWorked = thread.completedJobs ?? (isOccupantHustler ? 54 : 3);
  const hustlersHired = thread.hustlersHired ?? (isOccupantHustler ? 4 : 19);
  const jobsPosted = thread.jobsPosted ?? (isOccupantHustler ? 6 : 24);
  const hourlyRate = thread.hourlyRate || 280;
  const memberSince = thread.memberSince || 'March 2023';

  // Resolved skills list
  const defaultHustlerSkills = [
    thread.skill || 'Master Electrical',
    thread.category || 'Maintenance',
    'Solar & Inverter Diagnostics',
    'Emergency DB Board Faults',
    'Loadshedding Backup Wiring',
    'Compliance Testing (CoC)'
  ];

  const defaultEmployerSkills = [
    'Electrical & Inverter Maintenance',
    'Plumbing & Geyser Replacement',
    'Interior Drywall & Painting',
    'Appliance Diagnostics',
    'General Property Handyman'
  ];

  const skillsList = thread.skills && thread.skills.length > 0 
    ? thread.skills 
    : (isOccupantHustler ? defaultHustlerSkills : defaultEmployerSkills);

  const bioText = thread.bio || (isOccupantHustler
    ? `Certified professional with over 8 years of specialized hands-on experience in domestic & commercial projects across Sandton, Rosebank, and surrounding Gauteng suburbs. Fully equipped with certified diagnostic tools and emergency callout capabilities.`
    : `Verified property owner and commercial project lead based in Sandton. Regular employer of local artisans with a strict policy of 100% upfront escrow locking and instant payout release upon job inspection.`);

  return (
    <div 
      className="fixed inset-0 z-[999] bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Cover / Brand Header */}
        <div className="relative bg-gradient-to-br from-[#1B263B] via-[#24334C] to-[#0F172A] text-white p-5 pt-6 shrink-0">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors active:scale-95 z-10"
            title="Close Profile"
          >
            ✕
          </button>

          <div className="flex items-start gap-4">
            {/* Circular Avatar with status ring */}
            <div className="relative shrink-0">
              <img
                src={thread.avatar}
                alt={thread.otherUserName}
                className="w-18 h-18 sm:w-20 sm:h-20 rounded-full aspect-square object-cover border-3 border-emerald-400 shadow-lg"
              />
              <div 
                className={`absolute bottom-0 right-0 w-4.5 h-4.5 rounded-full border-2 border-[#1B263B] flex items-center justify-center ${
                  isContactHired ? 'bg-orange-500' : 'bg-emerald-500'
                }`}
                title={isContactHired ? 'Currently Working' : 'Available Online'}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
              </div>
            </div>

            {/* Identity & Badges */}
            <div className="flex-1 min-w-0 pr-6">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-xl font-black text-white tracking-tight truncate">
                  {thread.otherUserName}
                </h3>
                {thread.isVerified !== false && (
                  <span className="text-[10px] text-[#D4AF37] font-black bg-[#D4AF37]/20 border border-[#D4AF37]/40 px-2 py-0.5 rounded-full shrink-0 flex items-center gap-1 shadow-2xs">
                    <span>✓</span> Verified SA
                  </span>
                )}
              </div>

              {/* Role badge */}
              <div className="mt-1 flex items-center gap-1.5 flex-wrap">
                <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-md tracking-wider ${
                  isOccupantHustler 
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' 
                    : 'bg-blue-500/20 text-blue-300 border border-blue-400/30'
                }`}>
                  {isOccupantHustler ? '⚡ SwiftHustle Professional' : '🏢 Verified Employer'}
                </span>
                {thread.tier && (
                  <span className="text-[10px] font-bold text-amber-300 bg-amber-400/15 border border-amber-400/30 px-1.5 py-0.5 rounded-md">
                    {thread.tier} Tier
                  </span>
                )}
              </div>

              {/* Location & Distance */}
              <p className="text-xs text-slate-300 mt-2 flex items-center gap-1 font-medium truncate">
                <span>📍</span>
                <span>{thread.distanceKm ? `${thread.distanceKm} km away` : 'Within Sandton Area'}</span>
                <span className="text-slate-500">•</span>
                <span className="text-slate-300">{isOccupantHustler ? (thread.skill || 'Artisan') : 'Property Owner'}</span>
              </p>
            </div>
          </div>

          {/* Working Mode Notice */}
          {isContactHired && (
            <div className="mt-4 bg-orange-500/20 border border-orange-400/40 rounded-xl px-3 py-2 flex items-center gap-2 text-xs text-orange-200">
              <span className="w-2 h-2 rounded-full bg-orange-400 animate-ping shrink-0"></span>
              <span className="font-bold text-white">Currently Working in Escrow</span>
              <span className="text-orange-200/80 text-[11px] ml-auto">🔕 Alerts Paused</span>
            </div>
          )}
        </div>

        {/* Scrollable Body Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 no-scrollbar bg-slate-50/60">
          {/* Key Metric Highlights Grid */}
          <div>
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2.5">
              Verified Reputation & Track Record
            </h4>
            <div className="grid grid-cols-3 gap-2.5">
              {/* Rating Card */}
              <div className="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-2xs text-center flex flex-col justify-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Rating</span>
                <div className="flex items-center justify-center gap-1 my-0.5">
                  <span className="text-amber-500 text-sm">★</span>
                  <span className="text-base font-black text-slate-900">{rating.toFixed(1)}</span>
                </div>
                <span className="text-[10px] text-slate-500 font-semibold">{reviewsCount} reviews</span>
              </div>

              {/* How Many Jobs Worked Card */}
              <div className={`bg-white p-3 rounded-2xl border shadow-2xs text-center flex flex-col justify-center ${
                isOccupantHustler ? 'border-emerald-200 bg-emerald-50/20' : 'border-slate-200/80'
              }`}>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Jobs Worked</span>
                <span className="text-base font-black text-slate-900 my-0.5">{jobsWorked}</span>
                <span className="text-[10px] text-emerald-700 font-bold">
                  {isOccupantHustler ? '100% Finished' : 'Worker Exp.'}
                </span>
              </div>

              {/* How Many Hustlers Hired Card */}
              <div className={`bg-white p-3 rounded-2xl border shadow-2xs text-center flex flex-col justify-center ${
                !isOccupantHustler ? 'border-blue-200 bg-blue-50/20' : 'border-slate-200/80'
              }`}>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Hustlers Hired</span>
                <span className="text-base font-black text-slate-900 my-0.5">{hustlersHired}</span>
                <span className="text-[10px] text-blue-700 font-bold">
                  {!isOccupantHustler ? 'Verified Payer' : 'Hiring History'}
                </span>
              </div>
            </div>
          </div>

          {/* Pricing & Reliability Banner */}
          <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-2xs flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-lg shrink-0">
                {isOccupantHustler ? '💰' : '🛡️'}
              </div>
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                  {isOccupantHustler ? 'Standard Escrow Rate' : 'Escrow Payout Track Record'}
                </p>
                <p className="text-sm font-black text-[#1B263B]">
                  {isOccupantHustler ? `R${hourlyRate} / hour` : '100% Instant Escrow Release'}
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-black uppercase px-2 py-1 rounded-lg bg-emerald-100 text-emerald-800">
                {isOccupantHustler ? 'Guaranteed Pay' : `${jobsPosted} Jobs Posted`}
              </span>
            </div>
          </div>

          {/* Skills & Specialties */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between mb-2.5">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                {isOccupantHustler ? 'Verified Skills & Specializations' : 'Frequently Hired Trades & Skills'}
              </h4>
              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                {skillsList.length} Skills
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {skillsList.map((skill, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200/80 text-slate-800 rounded-xl text-xs font-bold border border-slate-200/60 transition-colors"
                >
                  {isOccupantHustler ? '✓ ' : '🔧 '}{skill}
                </span>
              ))}
            </div>
          </div>

          {/* About / Professional Bio */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">
              {isOccupantHustler ? 'About This Hustler' : 'Employer Background'}
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              {bioText}
            </p>
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-semibold">
              <span>Member Since: {memberSince}</span>
              <span className="text-emerald-600 font-bold">Biometrics Verified ✓</span>
            </div>
          </div>

          {/* Trust & Safety Highlights */}
          <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-3.5">
            <h5 className="text-[10px] font-black text-emerald-950 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <span>🛡️</span> SwiftHustle Escrow Protection
            </h5>
            <p className="text-[11px] text-emerald-900 leading-normal font-medium">
              All gigs conducted with {thread.otherUserName} are secured by SwiftHustle escrow. Funds are held safely until work is completed and verified with photo proof of work.
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-white border-t border-slate-200/80 shrink-0 flex items-center gap-2">
          {/* Call contact */}
          <button
            onClick={() => {
              if (onCallContact) {
                onCallContact(thread);
              } else if (thread.phone) {
                window.location.href = `tel:${thread.phone}`;
              }
            }}
            className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-xs uppercase tracking-wider rounded-2xl transition-all active:scale-95 flex items-center gap-1.5"
            title={`Call ${thread.otherUserName}`}
          >
            <svg className="w-4 h-4 text-emerald-600" fill="currentColor" viewBox="0 0 20 20">
              <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 4V3z" />
            </svg>
            <span>Call</span>
          </button>

          {/* Contextual Primary Action */}
          {!isHustlerViewer && isOccupantHustler ? (
            isContactHired ? (
              <div className="flex-1 flex gap-2">
                <button
                  disabled
                  className="flex-1 py-3 bg-slate-200 text-slate-400 font-black text-xs uppercase tracking-wider rounded-2xl cursor-not-allowed select-none flex items-center justify-center gap-1"
                >
                  <span>✓</span>
                  <span>Currently Hired</span>
                </button>
                {onCompleteJob && (
                  <button
                    onClick={() => {
                      onClose();
                      onCompleteJob({ 
                        id: 'gig-1', 
                        title: `Job with ${thread.otherUserName}`, 
                        price: (thread.hourlyRate || 250) * 3 
                      }, false);
                    }}
                    className="flex-1 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs uppercase tracking-wider rounded-2xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-1"
                  >
                    Finish Job
                  </button>
                )}
              </div>
            ) : (
              <button
                onClick={() => {
                  onClose();
                  if (onDirectHire) {
                    onDirectHire({
                      id: thread.hustlerId || 'hustler-custom',
                      name: thread.otherUserName,
                      avatar: thread.avatar,
                      skill: thread.skill || 'Professional Hustler',
                      category: thread.category || 'General',
                      rating: thread.rating || 4.9,
                      reviewsCount: reviewsCount,
                      hourlyRate: hourlyRate,
                      location: [-26.1076, 28.0567],
                      distanceKm: thread.distanceKm || 1.2,
                      isVerified: true,
                      tier: 'Rising Star' as any,
                      bio: bioText,
                      isOnline: true,
                      completedJobs: jobsWorked
                    });
                  }
                }}
                className="flex-1 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs uppercase tracking-wider rounded-2xl shadow-md shadow-emerald-500/20 active:scale-95 transition-all flex items-center justify-center gap-1.5"
              >
                <span>Direct Hire (R{(hourlyRate * 3).toLocaleString()})</span>
              </button>
            )
          ) : (
            <button
              onClick={onClose}
              className="flex-1 py-3 bg-[#1B263B] hover:bg-slate-800 text-white font-black text-xs uppercase tracking-wider rounded-2xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
            >
              <span>Back to Chat</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
