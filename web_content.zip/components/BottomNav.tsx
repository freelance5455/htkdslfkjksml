
import React from 'react';
import { View } from '../types';

interface BottomNavProps {
  currentView: View;
  setView: (v: View) => void;
  onAction: () => void;
  isHustler: boolean;
}

const BottomNav: React.FC<BottomNavProps> = ({ currentView, setView, onAction, isHustler }) => {
  const activeColorClass = isHustler ? 'text-[#D4AF37]' : 'text-[#1B263B]';
  const fabGradientClass = isHustler 
    ? 'from-[#D4AF37] to-[#B8860B]' 
    : 'from-[#1B263B] to-[#2C3E50]';

  return (
    <div className="absolute bottom-0 left-0 right-0 h-20 z-50">
      {/* Semi-transparent background with blur */}
      <div className="absolute inset-x-0 bottom-0 h-16 bg-white/95 backdrop-blur-md border-t border-gray-100 flex items-center justify-between px-6 shadow-[0_-4px_20px_-5px_rgba(0,0,0,0.1)]">
        <button 
          onClick={() => setView(View.RADAR)}
          className={`flex flex-col items-center gap-1 ${currentView === View.RADAR ? activeColorClass + ' scale-110' : 'text-gray-400'} transition-all`}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>
          <span className="text-[10px] font-bold uppercase tracking-tighter">Radar</span>
        </button>

        <button 
          onClick={() => setView(View.CHAT)}
          className={`flex flex-col items-center gap-1 ${currentView === View.CHAT ? activeColorClass + ' scale-110' : 'text-gray-400'} transition-all`}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
          <span className="text-[10px] font-bold uppercase tracking-tighter">Chat</span>
        </button>

        {/* Space for the FAB */}
        <div className="w-12"></div>

        <button 
          onClick={() => setView(View.WALLET)}
          className={`flex flex-col items-center gap-1 ${currentView === View.WALLET ? activeColorClass + ' scale-110' : 'text-gray-400'} transition-all`}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
          <span className="text-[10px] font-bold uppercase tracking-tighter">Wallet</span>
        </button>

        <button 
          onClick={() => setView(View.ACCOUNT)}
          className={`flex flex-col items-center gap-1 ${currentView === View.ACCOUNT ? activeColorClass + ' scale-110' : 'text-gray-400'} transition-all`}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
          <span className="text-[10px] font-bold uppercase tracking-tighter">Account</span>
        </button>
      </div>

      {/* Floating Action Button (Docked) */}
      <button 
        onClick={onAction}
        className={`absolute bottom-6 left-1/2 -translate-x-1/2 w-16 h-16 bg-gradient-to-tr ${fabGradientClass} rounded-full flex items-center justify-center text-white shadow-xl shadow-black/20 border-4 border-white active:scale-90 transition-all z-[60]`}
      >
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 4v16m8-8H4"/></svg>
      </button>
    </div>
  );
};

export default BottomNav;
