
import React, { useState, useEffect, useRef } from 'react';

interface LogEntry {
  time: string;
  text: string;
}

interface TucbBankingProps {
  userSession?: any;
}

const IBAN_REGEX = /^[A-Z]{2}[0-9A-Z]{11,30}$/;
const SWIFT_REGEX = /^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const TucbBanking: React.FC<TucbBankingProps> = ({ userSession }) => {
  const [processing, setProcessing] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [log, setLog] = useState<LogEntry[]>([]);
  const [amount, setAmount] = useState('');
  const [selectedBank, setSelectedBank] = useState('Direct Bank Transfer (IBAN)');
  const [iban, setIban] = useState('');
  const [swift, setSwift] = useState('');
  const [email, setEmail] = useState('');
  const [errors, setErrors] = useState<{iban?: string; swift?: string; email?: string}>({});
  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [log]);

  const validateInputs = () => {
    const newErrors: {iban?: string; swift?: string; email?: string} = {};
    let isValid = true;

    if (!email || !EMAIL_REGEX.test(email)) {
      newErrors.email = "Invalid UDIA Email Format";
      isValid = false;
    }

    if (selectedBank === 'Direct Bank Transfer (IBAN)') {
      const cleanIban = iban.replace(/[\s]+/g, '').toUpperCase();
      if (!cleanIban || !IBAN_REGEX.test(cleanIban)) {
        newErrors.iban = "Invalid International Bank Account Number";
        isValid = false;
      }
      
      const cleanSwift = swift.trim().toUpperCase();
      if (!cleanSwift || !SWIFT_REGEX.test(cleanSwift)) {
        newErrors.swift = "Invalid SWIFT/BIC Code";
        isValid = false;
      }
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleInitiateWithdrawal = () => {
    if (!amount) return;
    if (!validateInputs()) return;
    setShowConfirmation(true);
  };

  const confirmWithdrawal = () => {
    setShowConfirmation(false);
    setProcessing(true);
    setLog([]);
    
    // Simulate HpayGateway4D logic
    const steps = [
      `HpayGateway4D: Initializing request for ${amount} LU...`,
      'TUCB_Core: Verifying Card Hash ****-4567...',
      `HOPE_ID: Initiating Identity Check for ${email}...`,
      'HOPE_ID: Verifying Email Integrity via UDIA Nexus...',
      'HOPE_ID: Email Identity CONFIRMED (Level 4 Clearance).',
      'HOPE_AI: Analyzing transaction risk pattern...',
      'HOPE_AI: Risk Score 0.01 (SAFE) - Authorization GRANTED',
      `TUCB_Core: Allocating funds from Truest Bank Pool...`,
      `HpayGateway4D: Bridge open to ${selectedBank}...`,
    ];

    if (selectedBank === 'Direct Bank Transfer (IBAN)') {
      steps.push(`Banking_Net: Validating IBAN Checksum [${iban.substring(0, 4)}***]...`);
      steps.push(`Banking_Net: Routing via SWIFT Network [${swift.toUpperCase()}]...`);
      steps.push('Banking_Net: Inter-bank Settlement Protocol ACCEPTS.');
    }

    steps.push('Network: 256-bit SSL Handshake established.');
    steps.push('SUCCESS: Instant Settlement Transfer Complete.');
    steps.push('TUCB_Docs: Generating Remittance Advice PDF...');
    steps.push('Mail_Server: Encrypting PDF attachment...');
    steps.push(`Mail_Server: Sending Remittance Advice to ${email}...`);
    steps.push('SUCCESS: Remittance Advice PDF Delivered.');

    let currentStep = 0;

    const executeStep = () => {
      if (currentStep < steps.length) {
        const time = new Date().toLocaleTimeString();
        setLog(prev => [...prev, { time, text: steps[currentStep] }]);
        currentStep++;
        const delay = 800 + Math.random() * 500;
        setTimeout(executeStep, delay);
      } else {
        setProcessing(false);
      }
    };

    executeStep();
  };

  return (
    <section id="banking" className="py-24 bg-[#081125] relative overflow-hidden border-t border-white/5">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-cyan-500/5 blur-3xl -z-10"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-16 text-center">
            <div className="inline-flex items-center gap-2 mb-4">
                 <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Gateway Active</span>
            </div>
            <h2 className="text-3xl md:text-5xl font-black text-white mb-4 uppercase tracking-tighter">
              TUCB <span className="text-cyan-400">{userSession ? `${userSession.bank || 'Cloud'} Cards` : 'Cloud Cards'}</span>
            </h2>
            <p className="text-slate-500 text-sm font-bold uppercase tracking-widest max-w-2xl mx-auto">
              Universal Gateway Access via HpayGateway4D Protocol. Powered by Hope AI.
            </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Cards Column */}
            <div className="space-y-8 perspective-1000">
                {/* Card 1: Black Card / User Generated Card */}
                <div className="relative h-60 rounded-[2rem] overflow-hidden shadow-2xl group transition-all duration-500 hover:scale-[1.02] hover:shadow-cyan-500/20 border border-white/10">
                    <div className="absolute inset-0 bg-[#050b1a]"></div>
                    <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
                    <div className="absolute top-0 right-0 p-40 bg-gradient-to-bl from-white/10 to-transparent rounded-full blur-2xl -translate-y-1/2 translate-x-1/2"></div>
                    
                    <div className="relative p-8 h-full flex flex-col justify-between z-10">
                        <div className="flex justify-between items-start">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-700 to-black border border-white/10 flex items-center justify-center shadow-inner">
                                    <span className="text-xl">🦅</span>
                                </div>
                                <div>
                                    <span className="block text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">
                                      {userSession?.bank === 'HACB' ? 'HACB Core' : 'TUCB Core'}
                                    </span>
                                    <span className="block text-sm font-black text-white uppercase tracking-widest leading-none">
                                      {userSession ? 'Sovereign Member' : 'Sovereign Black'}
                                    </span>
                                </div>
                            </div>
                            <span className="text-white/80 font-black text-lg italic tracking-tighter">VISA <span className="text-[8px] not-italic align-top font-normal opacity-70">Infinite</span></span>
                        </div>
                        
                        <div className="flex items-center gap-4 my-2">
                             <div className="w-10 h-8 bg-gradient-to-r from-amber-200 to-amber-500 rounded-md opacity-80"></div>
                             <span className="text-xs text-white/50 font-mono">((( )))</span>
                        </div>

                        <div className="space-y-1">
                            <p className="text-2xl font-mono text-white tracking-[0.15em] drop-shadow-md">
                              {userSession ? userSession.accountNumber : '4921 88•• •••• 4567'}
                            </p>
                        </div>
                        
                        <div className="flex justify-between items-end">
                            <div>
                                <p className="text-slate-500 text-[8px] font-bold uppercase tracking-widest mb-1">Authorized Holder</p>
                                <p className="text-sm font-bold text-white uppercase tracking-wider">
                                  {userSession ? userSession.name : 'UNIVERSAL MEMBER'}
                                </p>
                            </div>
                            <div className="text-right">
                                <p className="text-slate-500 text-[8px] font-bold uppercase tracking-widest mb-1">Valid Thru</p>
                                <p className="text-xs font-mono text-white">12/30</p>
                            </div>
                        </div>
                    </div>
                </div>

                 {/* Card 2: QR / HAG ID Card */}
                 <div className="relative h-60 rounded-[2rem] overflow-hidden shadow-2xl group transition-all duration-500 hover:scale-[1.02] hover:shadow-blue-500/20 border border-white/10 translate-x-4 -mt-12 lg:-mt-16 z-0">
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-[#0d1b35] to-[#050b1a]"></div>
                    
                    <div className="relative p-6 h-full flex items-center gap-6 z-10">
                        {/* QR Code Section */}
                        <div className="w-40 h-40 bg-white p-2 rounded-xl flex-shrink-0">
                           <div className="w-full h-full bg-[#050b1a] flex items-center justify-center relative overflow-hidden">
                              <div className="grid grid-cols-4 gap-0.5 w-full h-full p-1 opacity-80">
                                  {[...Array(16)].map((_,i) => <div key={i} className={`bg-black ${Math.random() > 0.4 ? 'opacity-100' : 'opacity-0'}`}></div>)}
                              </div>
                              <div className="absolute inset-0 flex items-center justify-center">
                                <div className="bg-white p-1 rounded-full"><div className="w-4 h-4 bg-blue-600 rounded-full"></div></div>
                              </div>
                           </div>
                        </div>

                        {/* HAG Details */}
                        <div className="flex flex-col justify-between h-40 py-2">
                           <div>
                              <span className="bg-cyan-500/20 text-cyan-400 text-[9px] font-black px-2 py-1 rounded uppercase mb-2 inline-block">Universal ID</span>
                              <h4 className="text-white font-black uppercase text-sm leading-tight">Unified Access</h4>
                              <p className="text-[9px] text-slate-400 uppercase">One QR • One ID</p>
                           </div>

                           <div className="space-y-2">
                              <div>
                                 <p className="text-[8px] text-slate-500 font-bold uppercase tracking-wider">HAG5G Number</p>
                                 <p className="text-lg font-mono text-amber-400 font-bold">{userSession ? userSession.hagNumber : '+984 799 ••••••'}</p>
                              </div>
                              {userSession?.localMobile && (
                                <div>
                                   <p className="text-[8px] text-slate-500 font-bold uppercase tracking-wider">Linked Mobile</p>
                                   <p className="text-xs font-mono text-white">{userSession.localMobile}</p>
                                </div>
                              )}
                           </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Gateway Simulator Interface */}
            <div className="bg-[#050b1a] rounded-[2rem] border border-white/5 p-8 relative shadow-2xl">
                <div className="absolute -top-3 left-8 bg-gradient-to-r from-cyan-600 to-blue-600 text-white px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">
                    HpayGateway4D
                </div>

                <div className="mt-4 space-y-6">
                    <div>
                        <div className="flex justify-between items-end mb-2">
                             <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block">Withdrawal Amount (LU)</label>
                             <span className="text-[10px] font-bold text-cyan-500">Available: ∞</span>
                        </div>
                        <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-black">$</span>
                            <input 
                                type="number" 
                                value={amount}
                                onChange={(e) => setAmount(e.target.value)}
                                className="w-full bg-[#0d1b35] border border-white/10 rounded-xl pl-8 pr-4 py-4 text-white font-mono text-lg focus:border-cyan-500 outline-none transition-all placeholder:text-slate-700"
                                placeholder="0.00"
                            />
                        </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-end mb-2">
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block">Recipient Email (Verification Required)</label>
                      </div>
                      <input 
                          type="email" 
                          value={email}
                          onChange={(e) => {
                            setEmail(e.target.value);
                            if (errors.email) setErrors({...errors, email: undefined});
                          }}
                          className={`w-full bg-[#0d1b35] border ${errors.email ? 'border-red-500' : 'border-white/10'} rounded-xl px-4 py-4 text-white font-mono text-sm focus:border-cyan-500 outline-none transition-all placeholder:text-slate-700`}
                          placeholder="recipient@domain.com"
                      />
                      {errors.email && <p className="text-red-500 text-[9px] mt-1 font-black uppercase tracking-wider animate-pulse">{errors.email}</p>}
                    </div>
                    
                    <div>
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 block">Target Destination</label>
                        <div className="relative">
                            <select 
                                value={selectedBank}
                                onChange={(e) => setSelectedBank(e.target.value)}
                                className="w-full bg-[#0d1b35] border border-white/10 rounded-xl px-4 py-4 text-white text-xs font-bold uppercase tracking-wider focus:border-cyan-500 outline-none transition-all appearance-none cursor-pointer"
                            >
                                <option>Direct Bank Transfer (IBAN)</option>
                                <option>Visa Direct (Instant)</option>
                                <option>Mastercard Send</option>
                                <option>TUCB Internal Wallet</option>
                                <option>USDT (TRC20) Bridge</option>
                            </select>
                            <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                            </div>
                        </div>
                    </div>

                    {selectedBank === 'Direct Bank Transfer (IBAN)' && (
                      <div className="grid grid-cols-2 gap-4 animate-in fade-in slide-in-from-top-2 duration-300">
                        <div>
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 block">IBAN Number</label>
                          <input 
                            type="text" 
                            value={iban}
                            onChange={(e) => {
                                setIban(e.target.value.toUpperCase());
                                if (errors.iban) setErrors({...errors, iban: undefined});
                            }}
                            className={`w-full bg-[#0d1b35] border ${errors.iban ? 'border-red-500' : 'border-white/10'} rounded-xl px-4 py-3 text-white text-xs font-mono focus:border-cyan-500 outline-none transition-all placeholder:text-slate-700 uppercase`}
                            placeholder="AL98 2011..."
                          />
                          {errors.iban && <p className="text-red-500 text-[8px] mt-1 font-black uppercase tracking-wider">{errors.iban}</p>}
                        </div>
                        <div>
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 block">SWIFT / BIC</label>
                          <input 
                            type="text" 
                            value={swift}
                            onChange={(e) => {
                                setSwift(e.target.value.toUpperCase());
                                if (errors.swift) setErrors({...errors, swift: undefined});
                            }}
                            className={`w-full bg-[#0d1b35] border ${errors.swift ? 'border-red-500' : 'border-white/10'} rounded-xl px-4 py-3 text-white text-xs font-mono focus:border-cyan-500 outline-none transition-all placeholder:text-slate-700 uppercase`}
                            placeholder="DEUT..."
                          />
                           {errors.swift && <p className="text-red-500 text-[8px] mt-1 font-black uppercase tracking-wider">{errors.swift}</p>}
                        </div>
                      </div>
                    )}

                    <button 
                        onClick={handleInitiateWithdrawal}
                        disabled={processing || !amount || !email}
                        className="w-full bg-white hover:bg-cyan-400 text-[#050b1a] font-black uppercase tracking-widest py-4 rounded-xl transition-all flex items-center justify-center gap-3 shadow-lg transform active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {processing ? (
                             <div className="flex items-center gap-2">
                                <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                <span>Processing TUCB Core...</span>
                             </div>
                        ) : (
                             <>
                                <span>Initiate Instant Withdrawal</span>
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                             </>
                        )}
                    </button>
                    
                    {/* Console Log */}
                    <div className="bg-black/80 rounded-xl p-4 font-mono text-[9px] h-48 overflow-y-auto border border-white/10 shadow-inner relative">
                        <div className="sticky top-0 bg-black/80 pb-2 border-b border-white/10 mb-2 flex justify-between items-center">
                             <span className="text-slate-500 font-bold">GATEWAY LOG</span>
                             <div className="flex gap-1">
                                 <div className="w-2 h-2 rounded-full bg-red-500"></div>
                                 <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                                 <div className="w-2 h-2 rounded-full bg-green-500"></div>
                             </div>
                        </div>
                        {log.length === 0 ? (
                            <div className="h-full flex items-center justify-center text-slate-700 italic">
                                Ready to initialize HpayGateway4D...
                            </div>
                        ) : (
                            <div className="space-y-1.5">
                                {log.map((entry, i) => (
                                    <div key={i} className="flex gap-2">
                                        <span className="text-slate-600">[{entry.time}]</span>
                                        <span className={`${
                                            entry.text.includes('SUCCESS') ? 'text-green-400 font-bold' : 
                                            entry.text.includes('HOPE_AI') ? 'text-cyan-400' : 
                                            entry.text.includes('HOPE_ID') ? 'text-cyan-200' :
                                            entry.text.includes('TUCB_Core') ? 'text-amber-400' :
                                            entry.text.includes('Mail_Server') ? 'text-violet-400' :
                                            'text-slate-300'
                                        }`}>{entry.text}</span>
                                    </div>
                                ))}
                                <div ref={logsEndRef}></div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
      </div>

      {showConfirmation && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowConfirmation(false)}></div>
          <div className="relative bg-[#0d1b35] border border-white/10 rounded-2xl p-6 max-w-sm w-full shadow-2xl animate-in zoom-in duration-200">
            <h3 className="text-xl font-black text-white uppercase mb-4">Confirm Transaction</h3>
            
            <div className="space-y-3 mb-6 text-sm">
                <div className="flex justify-between">
                    <span className="text-slate-500 uppercase font-bold text-[10px] tracking-widest">Amount</span>
                    <span className="text-white font-mono font-bold">{amount} LU</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-slate-500 uppercase font-bold text-[10px] tracking-widest">Recipient</span>
                    <span className="text-white font-mono text-xs">{email}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-slate-500 uppercase font-bold text-[10px] tracking-widest">Method</span>
                    <span className="text-cyan-400 text-xs font-bold">{selectedBank}</span>
                </div>
                {selectedBank === 'Direct Bank Transfer (IBAN)' && (
                    <>
                        <div className="flex justify-between">
                            <span className="text-slate-500 uppercase font-bold text-[10px] tracking-widest">IBAN</span>
                            <span className="text-slate-300 font-mono text-xs">{iban}</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-slate-500 uppercase font-bold text-[10px] tracking-widest">SWIFT</span>
                            <span className="text-slate-300 font-mono text-xs">{swift}</span>
                        </div>
                    </>
                )}
            </div>

            <div className="flex gap-3">
                <button 
                    onClick={() => setShowConfirmation(false)}
                    className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-colors"
                >
                    Cancel
                </button>
                <button 
                    onClick={confirmWithdrawal}
                    className="flex-1 bg-cyan-500 hover:bg-cyan-400 text-[#050b1a] py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-colors shadow-lg"
                >
                    Confirm
                </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default TucbBanking;
