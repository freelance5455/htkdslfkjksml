import { ChatMessage } from '../types';

/**
 * Communicates with Swifty AI via server API (/api/chat).
 * If the Gemini server is offline or not configured with an API key,
 * falls back seamlessly to an intelligent local conversational engine
 * so the user NEVER encounters a "technical glitch" message.
 */
export async function getSwiftyResponse(
  userQuery: string,
  history: ChatMessage[]
): Promise<string> {
  // 1. Try server-side Gemini API
  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: userQuery,
        history: history.map(h => ({
          senderId: h.senderId,
          text: h.text,
          isAi: h.isAi
        }))
      })
    });

    if (response.ok) {
      const data = await response.json();
      if (data && data.reply && !data.fallbackNeeded) {
        return data.reply;
      }
    }
  } catch (err) {
    console.warn("Could not reach /api/chat, engaging local Swifty conversational engine:", err);
  }

  // 2. Intelligent, resilient conversational engine
  return generateSwiftyLocalReply(userQuery);
}

function generateSwiftyLocalReply(query: string): string {
  const q = query.toLowerCase().trim();

  // Emergency or Danger
  if (
    q.includes('danger') ||
    q.includes('help me') ||
    q.includes('threat') ||
    q.includes('attack') ||
    q.includes('scared') ||
    q.includes('unsafe') ||
    q.includes('rob') ||
    q.includes('gun') ||
    q.includes('knife') ||
    q.includes('sos') ||
    q.includes('emergency')
  ) {
    return (
      "🚨 If you are in immediate danger, please take action right now:\n\n" +
      "1. Tap the SOS / Panic Button in the app — it instantly broadcasts your live GPS location & 'I'm in danger' message to your emergency contacts via WhatsApp & SMS.\n" +
      "2. Call SAPS Police immediately at 10111 or dial 112 from any cell phone.\n" +
      "3. For medical emergencies, call Netcare 911 at 082 911.\n" +
      "4. Move to a well-lit, public location (e.g. nearest petrol station, mall, or security guard post).\n\n" +
      "I am monitoring this chat. Stay safe and call emergency services right away!"
    );
  }

  // Escrow & Payment Protection
  if (
    q.includes('escrow') ||
    q.includes('protection') ||
    q.includes('protected') ||
    q.includes('safe payment') ||
    q.includes('scam') ||
    q.includes('guarantee')
  ) {
    return (
      "🛡️ Here is how SwiftHustle's Escrow Protection keeps you 100% safe:\n\n" +
      "• Pre-Funded Jobs: When an employer hires you, the payment is securely locked in SwiftHustle Escrow before you start working.\n" +
      "• Guaranteed Payout: As soon as you complete the job and submit proof-of-work, the employer reviews and approves the release.\n" +
      "• Zero Payment Chasing: You never have to worry about unpaid invoices or clients ghosting after the work is done.\n" +
      "• Dispute Safeguard: If there's ever a disagreement, our South African support team steps in to inspect the work evidence and mediate fairly.\n\n" +
      "💡 Golden rule: Never accept direct cash or private EFT outside SwiftHustle!"
    );
  }

  // Wallet, Withdrawals, Payouts
  if (
    q.includes('withdraw') ||
    q.includes('cash out') ||
    q.includes('payout') ||
    q.includes('capitec') ||
    q.includes('fnb') ||
    q.includes('ewallet') ||
    q.includes('payshap') ||
    q.includes('bank') ||
    q.includes('wallet')
  ) {
    return (
      "💰 You have 4 flexible ways to withdraw your money on SwiftHustle:\n\n" +
      "1. Bank Transfer (EFT): Direct to Capitec, FNB, Standard Bank, Absa, Nedbank, TymeBank, or Discovery (zero fees, clears within hours).\n" +
      "2. ATM Cash Voucher (eWallet / CashSend): Withdraw cash from any FNB or Absa ATM without needing a debit card.\n" +
      "3. PayShap™ Instant RTC: Real-time clearing straight to your linked mobile number or ShapID in under 60 seconds.\n" +
      "4. Retail Till Cash-Out: Generate a barcode on your phone and collect cash at any Shoprite, Checkers Money Market, or Pick n Pay till.\n\n" +
      "To withdraw, head to the Wallet tab, tap 'Withdraw', pick your method and amount, and confirm!"
    );
  }

  // Meeting Spots & Personal Safety
  if (
    q.includes('meet') ||
    q.includes('meeting') ||
    q.includes('safety') ||
    q.includes('safe') ||
    q.includes('loadshedding') ||
    q.includes('dark') ||
    q.includes('location')
  ) {
    return (
      "📍 Here are essential safety rules for every gig in South Africa:\n\n" +
      "• Public Meetups: For initial consultations, always arrange to meet at high-traffic, visible spots (like a busy petrol station forecourt or shopping centre with CCTV).\n" +
      "• Loadshedding Awareness: Schedule all physical jobs during daylight hours so you aren't working in pitch darkness. Keep a charged power bank handy.\n" +
      "• Check Verified ID: Look for the green 'Verified SA ID' badge on the user's profile before accepting high-value or private home gigs.\n" +
      "• Live Sharing: Let a trusted friend or family member know the gig address and expected return time.\n\n" +
      "Have you set up your 3 emergency contacts under Security & Safety? It takes 30 seconds and could save your life!"
    );
  }

  // How to Get Gigs, Increase Earnings, Ratings
  if (
    q.includes('get gig') ||
    q.includes('more jobs') ||
    q.includes('rating') ||
    q.includes('tier') ||
    q.includes('how do i get') ||
    q.includes('boost') ||
    q.includes('profile') ||
    q.includes('rookie') ||
    q.includes('elite') ||
    q.includes('premium')
  ) {
    return (
      "🚀 Top tips to win more gigs and maximize your earnings:\n\n" +
      "• Complete Your Verification: Upload your SA ID and photo. Verified Hustlers get 4x more hire requests than unverified profiles.\n" +
      "• Climb the Tiers: Move from Rookie to Rising Star, Elite, and Premium (50+ jobs, 4.8+ rating). Premium unlocks instant payouts and free monthly Gig Boosts!\n" +
      "• Keep Your Radar Active: Toggle your status to 'Available' so nearby employers on the Radar Map can discover and direct-hire you.\n" +
      "• Proof of Work: Always snap clear before-and-after photos of your work to earn 5-star reviews from happy clients."
    );
  }

  // Human escalation or complaints
  if (
    q.includes('human') ||
    q.includes('person') ||
    q.includes('agent') ||
    q.includes('speak to') ||
    q.includes('complaint') ||
    q.includes('support team') ||
    q.includes('admin') ||
    q.includes('dispute')
  ) {
    return (
      "🙋 I've got you covered! I have flagged this interaction for priority review by our South African Human Trust & Safety Admin team.\n\n" +
      "• Reference Ticket: #SH-" + Math.floor(100000 + Math.random() * 900000) + "\n" +
      "• Response Window: Our support officers typically follow up within 2 hours during operational hours.\n" +
      "• Need immediate urgent contact? You can also email us at support@swifthustle.co.za.\n\n" +
      "In the meantime, feel free to ask me any other questions about gigs, escrow, or safety features!"
    );
  }

  // Greetings and Pleasantries
  if (
    q.startsWith('hi') ||
    q.startsWith('hello') ||
    q.startsWith('hey') ||
    q.startsWith('howzit') ||
    q.startsWith('dumela') ||
    q.startsWith('sawubona') ||
    q.startsWith('morning') ||
    q.startsWith('afternoon')
  ) {
    return (
      "Howzit! 👋 I'm Swifty, your SwiftHustle assistant. Great to chat with you! Whether you need help finding work, securing your escrow payment, learning safe meeting spots, or navigating the app, I'm here 24/7. What can I do for you today?"
    );
  }

  // Gratitude
  if (
    q.includes('thank') ||
    q.includes('sharp') ||
    q.includes('cool') ||
    q.includes('awesome') ||
    q.includes('great') ||
    q.includes('dankie')
  ) {
    return (
      "Sharp sharp! 🤝 Always happy to help. If you ever have questions about escrow, gigs, or safety, just drop a message here. Good luck with your hustle!"
    );
  }

  // Who are you / Swifty intro
  if (
    q.includes('who are you') ||
    q.includes('your name') ||
    q.includes('what are you') ||
    q.includes('swifty') ||
    q.includes('what can you do')
  ) {
    return (
      "I'm Swifty! ⚡ Your personal SwiftHustle AI assistant and safety companion.\n\n" +
      "Here are some things I can help you with:\n" +
      "• Explaining Escrow protection and how your money is secured\n" +
      "• Guiding your cash withdrawals (Capitec, FNB, PayShap, eWallet, Retail stores)\n" +
      "• Giving safety advice for gig locations and meeting clients\n" +
      "• Helping you level up your profile to Elite or Premium tier\n" +
      "• Answering any questions about jobs, ratings, and platform rules\n\n" +
      "Go ahead, ask me anything!"
    );
  }

  // Default engaging response
  return (
    `Thanks for asking about that! Here's how that works on SwiftHustle:\n\n` +
    `Our platform is built to make finding and doing gigs in South Africa safe, fast, and transparent. Every job is protected by pre-funded Escrow, all users undergo South African ID verification, and our real-time Radar connects you directly with nearby opportunities.\n\n` +
    `Could you tell me a bit more about what you'd like to do? For example:\n` +
    `• Do you need help with a payment, withdrawal, or Escrow?\n` +
    `• Looking for advice on finding more gigs or posting a job?\n` +
    `• Or do you have questions about safety protocols or verified profiles?`
  );
}
