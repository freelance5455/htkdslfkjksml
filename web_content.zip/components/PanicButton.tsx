
import React, { useState } from 'react';
import {
  preparePanicDispatch,
  PanicDispatchResult,
  triggerChannelLaunch
} from './emergencyUtils';

interface PanicButtonProps {
  className?: string;
}

const PanicButton: React.FC<PanicButtonProps> = ({ className = '' }) => {
  const [isActivating, setIsActivating] = useState(false);
  const [status, setStatus] = useState<'idle' | 'activating' | 'sent'>('idle');
  const [showSosModal, setShowSosModal] = useState(false);
  const [dispatchResult, setDispatchResult] = useState<PanicDispatchResult | null>(null);
  const [copied, setCopied] = useState(false);

  const handleTrigger = async () => {
    setStatus('activating');
    
    // Retrieve user profile contacts from storage
    let contacts: string[] = ['+27 82 000 0000'];
    let userName = 'SwiftHustle Member';
    try {
      const saved = localStorage.getItem('sh_user_profile');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.fullName) userName = parsed.fullName;
        if (Array.isArray(parsed.emergencyContacts) && parsed.emergencyContacts.length > 0) {
          contacts = parsed.emergencyContacts;
        } else if (parsed.emergencyContact) {
          contacts = [parsed.emergencyContact];
        }
      }
    } catch (e) {
      console.warn("Could not read stored emergency contacts", e);
    }

    try {
      const result = await preparePanicDispatch(userName, contacts);
      setDispatchResult(result);
      setStatus('sent');
      setShowSosModal(true);

      // Attempt to launch WhatsApp immediately for primary emergency contact
      if (result.contacts.length > 0) {
        triggerChannelLaunch('whatsapp', result.contacts[0]);
      }

      setTimeout(() => {
        setStatus('idle');
      }, 3000);
    } catch (err) {
      console.error("Panic button error:", err);
      setStatus('idle');
      alert("Emergency Signal: Please ensure location is enabled on your device.");
    }
  };

  const handleCopy = () => {
    if (dispatchResult?.message) {
      navigator.clipboard.writeText(dispatchResult.message);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <>
      <div className={`relative ${className}`}>
        <button 
          onMouseDown={() => setIsActivating(true)}
          onMouseUp={() => setIsActivating(false)}
          onClick={handleTrigger}
          title="Emergency Panic / SOS Signal (Alerts Contacts & Location)"
          className={`group relative flex items-center justify-center h-11 rounded-2xl shadow-xl transition-all duration-300 border-2 border-white/80 active:scale-95
            ${status === 'sent' 
              ? 'bg-emerald-600 px-4' 
              : status === 'activating' 
                ? 'bg-rose-700 px-3.5' 
                : 'bg-gradient-to-tr from-rose-600 to-rose-500 hover:from-rose-700 hover:to-rose-600 px-3.5'
            }
          `}
        >
          <div className="flex items-center justify-center gap-1.5">
            {status === 'sent' ? (
              <span className="text-white text-xs font-black uppercase whitespace-nowrap flex items-center gap-1.5">
                <svg className="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"/>
                </svg>
                Signal Sent
              </span>
            ) : (
              <>
                <svg 
                  className={`w-4 h-4 text-white shrink-0 ${status === 'activating' ? 'animate-ping' : ''}`} 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
                <span className="text-white text-[11px] font-black uppercase tracking-wider">
                  {status === 'activating' ? 'Sending...' : 'SOS'}
                </span>
              </>
            )}
          </div>

          {/* Activation Ring */}
          {status === 'activating' && (
            <div className="absolute inset-0 border-2 border-white/40 rounded-2xl animate-spin"></div>
          )}
        </button>
      </div>

      {/* Floating Panic Alert Dispatch Modal */}
      {showSosModal && dispatchResult && (
        <div className="fixed inset-0 z-[7000] bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-[32px] max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-300 border border-slate-200">
            <div className="bg-rose-600 p-5 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-2xl animate-pulse">🚨</span>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wide">SOS Panic Alert Sent</h3>
                  <p className="text-[10px] text-rose-100 font-medium">Emergency contacts notified with your location</p>
                </div>
              </div>
              <button 
                onClick={() => setShowSosModal(false)}
                className="w-8 h-8 rounded-xl bg-white/20 hover:bg-white/30 flex items-center justify-center text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs">
                <div className="flex justify-between items-center text-slate-500 font-bold mb-1 text-[10px] uppercase">
                  <span>GPS Location Fix</span>
                  <a href={dispatchResult.mapUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 font-bold">
                    Open Map ↗
                  </a>
                </div>
                <p className="font-mono text-[11px] text-slate-800">
                  {dispatchResult.latitude.toFixed(6)}, {dispatchResult.longitude.toFixed(6)}
                </p>
              </div>

              <div className="bg-slate-900 text-white p-3.5 rounded-2xl text-xs space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-[9px] uppercase tracking-wider text-rose-400 font-bold">Outgoing Message</span>
                  <button onClick={handleCopy} className="text-[10px] text-slate-300 hover:text-white underline">
                    {copied ? 'Copied!' : 'Copy'}
                  </button>
                </div>
                <p className="text-slate-200 text-[11px] leading-relaxed break-words">
                  {dispatchResult.message}
                </p>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">
                  Resend via WhatsApp or SMS
                </span>
                {dispatchResult.contacts.map((c, i) => (
                  <div key={i} className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                    <span className="text-xs font-bold text-slate-700">{c.raw}</span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => triggerChannelLaunch('whatsapp', c)}
                        className="px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-[10px] font-black uppercase flex items-center gap-1"
                      >
                        WhatsApp
                      </button>
                      <button
                        onClick={() => triggerChannelLaunch('sms', c)}
                        className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase flex items-center gap-1"
                      >
                        SMS
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 border-t border-slate-100">
              <button
                onClick={() => setShowSosModal(false)}
                className="w-full py-3 bg-[#1B263B] text-white font-black text-xs uppercase tracking-wider rounded-xl"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default PanicButton;
