
import React, { useState, useMemo } from 'react';
import { Gig, Transaction, UserProfile, VerificationStatus } from '../types';

interface AdminPanelPageProps {
  gigs: Gig[];
  transactions: Transaction[];
  onBack: () => void;
  onUpdateTransactions: (txs: Transaction[]) => void;
}

// Mocking a queue of users needing verification for demo
const MOCK_PENDING_USERS: UserProfile[] = [
  {
    id: 'user_sabelo_88',
    fullName: 'Sabelo Mkhize',
    email: 'sabelo@mail.com',
    phone: '+27 82 555 1234',
    idNumber: '9005051234085',
    address: 'Soweto, Gauteng',
    bio: 'Professional plumber with 5 years experience.',
    isAvailable: true,
    walletBalance: 1200,
    escrowBalance: 0,
    emergencyContact: '',
    emergencyContacts: [],
    verification: {
      phone: 'verified',
      identity: 'pending',
      facial: 'pending',
      address: 'unverified'
    },
    verificationDocs: {
      idFront: 'https://picsum.photos/seed/id1/600/400',
      selfie: 'https://picsum.photos/seed/selfie1/400/400'
    }
  },
  {
    id: 'user_lerato_44',
    fullName: 'Lerato Modise',
    email: 'lerato@mail.com',
    phone: '+27 71 888 4321',
    idNumber: '9508085678082',
    address: 'Cape Town, WC',
    bio: 'Freelance graphic designer.',
    isAvailable: true,
    walletBalance: 850,
    escrowBalance: 0,
    emergencyContact: '',
    emergencyContacts: [],
    verification: {
      phone: 'verified',
      identity: 'pending',
      facial: 'pending',
      address: 'unverified'
    },
    verificationDocs: {
      idFront: 'https://picsum.photos/seed/id2/600/400',
      selfie: 'https://picsum.photos/seed/selfie2/400/400'
    }
  }
];

const AdminPanelPage: React.FC<AdminPanelPageProps> = ({ gigs, transactions, onBack, onUpdateTransactions }) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'verifications' | 'withdrawals'>('stats');
  const [pendingUsers, setPendingUsers] = useState<UserProfile[]>(MOCK_PENDING_USERS);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  // Fix: Initialized as string | null to correctly track specific processing item IDs (User or Transaction)
  const [isProcessing, setIsProcessing] = useState<string | null>(null);

  // Task 4: God View Stats
  const stats = useMemo(() => {
    const activeGigs = gigs.filter(g => g.status === 'open').length;
    const totalTransactions = transactions.reduce((acc, tx) => acc + (tx.type === 'transfer' ? tx.amount : 0), 0);
    const platformRevenue = transactions.reduce((acc, tx) => acc + (tx.fee || 0), 0);
    
    return {
      activeGigs,
      onlineUsers: 42, // Mocked live users
      platformRevenue,
      totalVolume: totalTransactions
    };
  }, [gigs, transactions]);

  const withdrawalRequests = useMemo(() => {
    return transactions.filter(tx => tx.type === 'out' && tx.status === 'pending');
  }, [transactions]);

  const handleApproveUser = async (userId: string) => {
    // Fix: Passing string ID to setIsProcessing
    setIsProcessing(userId);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setPendingUsers(prev => prev.filter(u => u.id !== userId));
    setSelectedUser(null);
    setIsProcessing(null);
    alert('User Verified Successfully! Identity Trust Synced.');
  };

  const handleRejectUser = async (userId: string) => {
    // Fix: Passing string ID to setIsProcessing
    setIsProcessing(userId);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setPendingUsers(prev => prev.filter(u => u.id !== userId));
    setSelectedUser(null);
    setIsProcessing(null);
    alert('Verification Rejected. User notified for re-upload.');
  };

  const handleMarkAsPaid = async (txId: string) => {
    // Fix: Passing string ID to setIsProcessing
    setIsProcessing(txId);
    await new Promise(resolve => setTimeout(resolve, 2000));
    const updated = transactions.map(tx => tx.id === txId ? { ...tx, status: 'completed' as const } : tx);
    onUpdateTransactions(updated);
    setIsProcessing(null);
    alert('💰 Payout Dispatched! Transaction moved to history.');
  };

  return (
    <div className="flex flex-col h-full bg-[#0B0F19] text-white overflow-hidden">
      {/* Task 5: UI Branding Header */}
      <header className="bg-[#1B263B] p-6 pb-8 border-b border-white/5 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4AF37]/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
        <div className="flex items-center gap-4 relative z-10">
          <button onClick={onBack} className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-white/60 active:scale-90 transition-all border border-white/5">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M11 17l-5-5m0 0l5-5m-5 5h12"/></svg>
          </button>
          <div>
            <h1 className="text-lg font-black tracking-tight uppercase flex items-center gap-2">
              <span className="text-[#D4AF37]">Admin</span> Command Center
            </h1>
            <p className="text-white/30 text-[9px] font-black uppercase tracking-[0.2em] mt-1 italic">Security Clearance: God Mode</p>
          </div>
        </div>
      </header>

      {/* Task 4: God View Stats Bar */}
      <div className="grid grid-cols-3 gap-3 p-4 bg-black/40 border-b border-white/5">
        <div className="bg-[#1B263B]/50 p-3 rounded-2xl border border-white/5 text-center">
          <p className="text-[8px] font-black text-white/40 uppercase tracking-widest mb-1">Active Gigs</p>
          <p className="text-lg font-black text-emerald-500">{stats.activeGigs}</p>
        </div>
        <div className="bg-[#1B263B]/50 p-3 rounded-2xl border border-white/5 text-center">
          <p className="text-[8px] font-black text-white/40 uppercase tracking-widest mb-1">Online</p>
          <p className="text-lg font-black text-blue-400">{stats.onlineUsers}</p>
        </div>
        <div className="bg-[#1B263B]/50 p-3 rounded-2xl border border-white/5 text-center">
          <p className="text-[8px] font-black text-white/40 uppercase tracking-widest mb-1">Fee Rev</p>
          <p className="text-lg font-black text-[#D4AF37]">R{stats.platformRevenue}</p>
        </div>
      </div>

      {/* Tab Navigation */}
      <nav className="flex bg-[#121926] p-1 gap-1 border-b border-white/5">
        {(['stats', 'verifications', 'withdrawals'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 text-[10px] font-black uppercase tracking-[0.2em] rounded-xl transition-all
              ${activeTab === tab ? 'bg-[#D4AF37] text-white shadow-xl' : 'text-white/40 hover:bg-white/5'}
            `}
          >
            {tab}
          </button>
        ))}
      </nav>

      <div className="flex-1 overflow-y-auto no-scrollbar p-6">
        {activeTab === 'stats' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom duration-500">
             <div className="bg-[#1B263B] rounded-[32px] p-8 border border-white/10 shadow-inner">
               <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-[#D4AF37] mb-6">Total Transaction Volume</h3>
               <p className="text-4xl font-black mb-4">R {stats.totalVolume.toLocaleString()}</p>
               <div className="h-2 w-full bg-black/40 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-[#D4AF37] to-amber-200 w-[65%] shadow-[0_0_15px_rgba(212,175,55,0.4)]"></div>
               </div>
               <p className="text-[9px] text-white/30 font-bold mt-4 italic uppercase tracking-widest">Calculated from completed smart escrow transfers</p>
             </div>
             
             <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#1B263B]/30 rounded-3xl p-6 border border-white/5">
                   <h4 className="text-[9px] font-black uppercase tracking-widest text-white/40 mb-2">Escrow Lockup</h4>
                   <p className="text-xl font-black text-white">R 128,450</p>
                </div>
                <div className="bg-[#1B263B]/30 rounded-3xl p-6 border border-white/5">
                   <h4 className="text-[9px] font-black uppercase tracking-widest text-white/40 mb-2">Resolved Today</h4>
                   <p className="text-xl font-black text-emerald-500">24 Gigs</p>
                </div>
             </div>
          </div>
        )}

        {/* Task 2: Verification Queue */}
        {activeTab === 'verifications' && (
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom duration-500">
            {pendingUsers.length === 0 ? (
              <div className="text-center py-20 opacity-20"><span className="text-6xl mb-4 block">✅</span><p className="font-black uppercase tracking-widest text-xs">Queue Clear</p></div>
            ) : (
              pendingUsers.map(user => (
                <button 
                  key={user.id}
                  onClick={() => setSelectedUser(user)}
                  className="w-full bg-[#1B263B]/40 border border-white/5 rounded-3xl p-5 flex items-center justify-between hover:bg-[#1B263B] transition-all"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center text-xl">👤</div>
                    <div className="text-left">
                      <h4 className="text-sm font-black text-white uppercase tracking-tight">{user.fullName}</h4>
                      <p className="text-[9px] text-white/40 font-bold uppercase tracking-widest">{user.idNumber}</p>
                    </div>
                  </div>
                  <div className="w-8 h-8 rounded-xl bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7"/></svg>
                  </div>
                </button>
              ))
            )}
          </div>
        )}

        {/* Task 3: Withdrawal Manager */}
        {activeTab === 'withdrawals' && (
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom duration-500">
            {withdrawalRequests.length === 0 ? (
              <div className="text-center py-20 opacity-20"><span className="text-6xl mb-4 block">💸</span><p className="font-black uppercase tracking-widest text-xs">No Payouts Pending</p></div>
            ) : (
              withdrawalRequests.map(tx => (
                <div key={tx.id} className="bg-[#1B263B]/40 border border-white/5 rounded-[32px] p-6">
                   <div className="flex justify-between items-start mb-6">
                      <div>
                        <h4 className="text-sm font-black text-white uppercase tracking-tight">{tx.userName}</h4>
                        <p className="text-[9px] text-white/40 font-bold uppercase tracking-widest">{tx.method} Request</p>
                      </div>
                      <p className="text-lg font-black text-[#D4AF37]">R{tx.amount}</p>
                   </div>
                   <button 
                    disabled={isProcessing === tx.id}
                    onClick={() => handleMarkAsPaid(tx.id)}
                    className="w-full py-4 bg-emerald-600 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-500/10 active:scale-95 transition-all flex items-center justify-center gap-2"
                   >
                     {isProcessing === tx.id ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Mark as Paid'}
                   </button>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Verification Detailed View Task 2 */}
      {selectedUser && (
        <div className="fixed inset-0 z-[10000] bg-black/95 flex flex-col p-6 overflow-y-auto animate-in fade-in duration-300">
           <header className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-black text-white uppercase tracking-tighter">Verify Identity</h2>
              <button onClick={() => setSelectedUser(null)} className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-white"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12"/></svg></button>
           </header>

           <div className="grid grid-cols-1 gap-6 mb-8">
              <div>
                <p className="text-[9px] font-black text-white/40 uppercase tracking-widest mb-3 ml-1">Live Selfie Comparison</p>
                <div className="aspect-square bg-white/5 rounded-3xl overflow-hidden border border-white/10">
                   <img src={selectedUser.verificationDocs?.selfie} className="w-full h-full object-cover" alt="Selfie" />
                </div>
              </div>
              <div>
                <p className="text-[9px] font-black text-white/40 uppercase tracking-widest mb-3 ml-1">ID Document (Front)</p>
                <div className="aspect-[4/3] bg-white/5 rounded-3xl overflow-hidden border border-white/10">
                   <img src={selectedUser.verificationDocs?.idFront} className="w-full h-full object-cover" alt="ID Front" />
                </div>
              </div>
           </div>

           <div className="bg-[#1B263B] rounded-3xl p-6 mb-12 border border-white/10">
              <div className="flex justify-between items-center mb-4">
                 <span className="text-[10px] font-black text-white/40 uppercase">Full Legal Name</span>
                 <span className="text-sm font-bold">{selectedUser.fullName}</span>
              </div>
              <div className="flex justify-between items-center">
                 <span className="text-[10px] font-black text-white/40 uppercase">SA ID Number</span>
                 <span className="text-sm font-bold">{selectedUser.idNumber}</span>
              </div>
           </div>

           <div className="flex gap-4 mt-auto">
              <button 
                disabled={!!isProcessing}
                onClick={() => handleRejectUser(selectedUser.id)}
                className="flex-1 py-5 bg-rose-600/20 border border-rose-600/50 text-rose-500 rounded-[24px] font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all"
              >
                Reject & Notify
              </button>
              <button 
                disabled={!!isProcessing}
                onClick={() => handleApproveUser(selectedUser.id)}
                className="flex-[2] py-5 bg-emerald-600 text-white rounded-[24px] font-black text-[10px] uppercase tracking-widest shadow-xl shadow-emerald-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                {isProcessing === selectedUser.id ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Approve Profile'}
              </button>
           </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanelPage;
