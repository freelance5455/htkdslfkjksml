
import React, { useState, useEffect, useMemo } from 'react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode: 'login' | 'signup';
  onLoginSuccess: (userData: any) => void;
  onLoginAttempt?: (creds: any) => { success: boolean; user?: any; error?: string };
  onRegister?: (userData: any) => void;
}

type AuthStep = 
  | 'role_selection'
  | 'initial' 
  | 'kyc_otp' 
  | 'kyc_processing' 
  | 'generation_success'
  | 'forgot_password';

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, initialMode, onLoginSuccess, onLoginAttempt, onRegister }) => {
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot_password'>(initialMode);
  const [step, setStep] = useState<AuthStep>('initial');
  const [role, setRole] = useState<'user' | 'admin' | 'super_admin'>('user');
  const [bankChoice, setBankChoice] = useState<'HACB' | 'TUTB'>('TUTB');
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    localMobile: '',
    emailOtp: '',
    mobileOtp: '',
  });
  
  const [errors, setErrors] = useState<any>({});
  const [isVerifying, setIsVerifying] = useState(false);
  const [kycProgress, setKycProgress] = useState(0);
  const [resendTimer, setResendTimer] = useState(30);

  // Generated Data
  const [genData, setGenData] = useState({
    hagNumber: '',
    accountNumber: '',
    qrCode: ''
  });

  useEffect(() => {
    if (!isOpen) {
      setStep('initial');
      setFormData({ name: '', email: '', password: '', confirmPassword: '', localMobile: '', emailOtp: '', mobileOtp: '' });
      setErrors({});
    }
  }, [isOpen]);

  useEffect(() => {
    let interval: number;
    if (step === 'kyc_otp' && resendTimer > 0) {
      interval = window.setInterval(() => setResendTimer(p => p - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [step, resendTimer]);

  useEffect(() => {
    if (step === 'kyc_processing') {
      const interval = setInterval(() => {
        setKycProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            generateUserAssets();
            return 100;
          }
          return prev + 2; // 50 ticks = approx 2-3 seconds
        });
      }, 50);
      return () => clearInterval(interval);
    }
  }, [step]);

  const generateUserAssets = () => {
    // Generate +984 HAG Number
    const randomSuffix = Math.floor(799000000 + Math.random() * 999999);
    const hag = `+984 ${randomSuffix}`;
    
    // Generate 12 Digit Account Number
    const acc = Math.floor(100000000000 + Math.random() * 900000000000).toString();
    
    setGenData({
      hagNumber: hag,
      accountNumber: acc,
      qrCode: `TUCB-QR-${acc}-${hag.replace(/\s/g,'')}`
    });
    setStep('generation_success');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: undefined });
  };

  const validateSignup = () => {
    const newErrors: any = {};
    if (!formData.email.includes('@')) newErrors.email = 'Invalid UDIA ID';
    if (!formData.localMobile) newErrors.localMobile = 'Required for HAG Pairing';
    if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Mismatch';
    return newErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'login') {
      setIsVerifying(true);
      
      // Perform validation via parent callback if available
      setTimeout(() => {
        if (onLoginAttempt) {
            const result = onLoginAttempt({ email: formData.email, password: formData.password, role });
            if (result.success) {
                onLoginSuccess(result.user);
                onClose();
            } else {
                setErrors({ general: result.error });
            }
        } else {
             // Fallback default
             onLoginSuccess({
                name: formData.email.split('@')[0],
                email: formData.email,
                role: role,
                accountNumber: '1092 8374 9128',
                hagNumber: '+984 799 123456',
                bank: 'TUTB'
             });
             onClose();
        }
        setIsVerifying(false);
      }, 1000);

    } else {
      // Signup Flow
      const errs = validateSignup();
      if (Object.keys(errs).length > 0) {
        setErrors(errs);
        return;
      }
      setResendTimer(30);
      setStep('kyc_otp');
    }
  };

  const handleVerifyKYC = () => {
    // Simulate OTP Check
    if (formData.emailOtp !== '1234' || formData.mobileOtp !== '1234') {
      setErrors({ otp: 'Invalid Master Code (Use 1234)' });
      return;
    }
    setStep('kyc_processing');
  };

  const handleFinalize = () => {
    const newUser = {
      name: formData.name,
      email: formData.email,
      role: role,
      localMobile: formData.localMobile,
      accountNumber: genData.accountNumber,
      hagNumber: genData.hagNumber,
      bank: bankChoice
    };
    
    if (onRegister) {
        onRegister(newUser);
    } else {
        onLoginSuccess(newUser);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#050b1a]/95 backdrop-blur-xl" onClick={onClose} />
      <div className="relative bg-[#0d1b35] w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/5 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="gradient-bg p-8 text-white relative flex-shrink-0">
          <button onClick={onClose} className="absolute top-6 right-6 text-white/50 hover:text-white"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
          <div className="flex gap-2 mb-2">
            <span className="bg-white/20 text-[9px] font-black px-2 py-0.5 rounded uppercase">Hope Pay V1.0</span>
            {mode === 'signup' && <span className="bg-amber-500 text-[#050b1a] text-[9px] font-black px-2 py-0.5 rounded uppercase">New Registration</span>}
          </div>
          <h2 className="text-2xl font-black mb-1 uppercase">
            {step === 'initial' ? (mode === 'login' ? 'Portal Access' : 'Sovereign Registry') : 
             step === 'kyc_otp' ? 'Multi-Factor KYC' :
             step === 'kyc_processing' ? 'Automated Verification' : 'Activation Complete'}
          </h2>
          <p className="text-blue-100/70 text-xs font-bold">
            {step === 'generation_success' ? 'One QR & Universal ID Generated' : 'Secure UDIA & TU5G Nexus Bridge'}
          </p>
        </div>

        {/* Content */}
        <div className="p-8 overflow-y-auto custom-scrollbar">
          
          {step === 'initial' && (
            <form onSubmit={handleSubmit} className="space-y-5">
              
              {/* Role Selection Panel */}
              <div className="grid grid-cols-3 gap-2 p-1 bg-[#050b1a] rounded-xl border border-white/10">
                {['user', 'admin', 'super_admin'].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRole(r as any)}
                    className={`py-2 text-[9px] font-black uppercase tracking-widest rounded-lg transition-all ${role === r ? 'bg-cyan-500 text-[#050b1a] shadow-lg' : 'text-slate-500 hover:text-white'}`}
                  >
                    {r.replace('_', ' ')}
                  </button>
                ))}
              </div>

              {mode === 'signup' && role === 'user' && (
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Select Banking Core</label>
                  <div className="grid grid-cols-2 gap-4">
                    <button type="button" onClick={() => setBankChoice('TUTB')} className={`p-4 rounded-xl border-2 text-left transition-all ${bankChoice === 'TUTB' ? 'border-cyan-500 bg-cyan-500/10' : 'border-white/10 bg-[#050b1a] opacity-60'}`}>
                      <div className="text-xl mb-1">🏛️</div>
                      <div className="text-[10px] font-black text-white uppercase">Truest Bank</div>
                      <div className="text-[8px] text-slate-400">Universal Trust Pool</div>
                    </button>
                    <button type="button" onClick={() => setBankChoice('HACB')} className={`p-4 rounded-xl border-2 text-left transition-all ${bankChoice === 'HACB' ? 'border-blue-500 bg-blue-500/10' : 'border-white/10 bg-[#050b1a] opacity-60'}`}>
                      <div className="text-xl mb-1">☁️</div>
                      <div className="text-[10px] font-black text-white uppercase">Hope AI Cloud</div>
                      <div className="text-[8px] text-slate-400">Digital Cloud Bank</div>
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {mode === 'signup' && (
                  <>
                    <input type="text" name="name" placeholder="Full Legal Name" value={formData.name} onChange={handleInputChange} className="w-full bg-[#050b1a] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-cyan-500 outline-none placeholder:text-slate-600" />
                    <input type="tel" name="localMobile" placeholder="Local Mobile Number" value={formData.localMobile} onChange={handleInputChange} className="w-full bg-[#050b1a] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-cyan-500 outline-none placeholder:text-slate-600" />
                    {errors.localMobile && <p className="text-red-500 text-[9px] font-black">{errors.localMobile}</p>}
                  </>
                )}
                <input type="email" name="email" placeholder={role === 'admin' || role === 'super_admin' ? "Admin Username/Email" : "Email Address (UDIA ID)"} value={formData.email} onChange={handleInputChange} className="w-full bg-[#050b1a] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-cyan-500 outline-none placeholder:text-slate-600" />
                <input type="password" name="password" placeholder="Cipher Token (Password)" value={formData.password} onChange={handleInputChange} className="w-full bg-[#050b1a] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-cyan-500 outline-none placeholder:text-slate-600" />
                
                {mode === 'signup' && (
                  <input type="password" name="confirmPassword" placeholder="Confirm Cipher Token" value={formData.confirmPassword} onChange={handleInputChange} className="w-full bg-[#050b1a] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-cyan-500 outline-none placeholder:text-slate-600" />
                )}
              </div>

              {errors.general && <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-500 text-[10px] font-black uppercase text-center">{errors.general}</div>}

              <button type="submit" disabled={isVerifying} className="w-full bg-white text-[#050b1a] py-4 rounded-xl font-black uppercase tracking-widest text-xs hover:bg-cyan-400 transition-all shadow-lg flex items-center justify-center gap-2">
                {isVerifying ? 'Authenticating...' : (mode === 'login' ? 'Access Dashboard' : 'Initiate KYC Verification')}
              </button>

              <div className="text-center">
                 {role === 'user' && (
                     <button type="button" onClick={() => setMode(mode === 'login' ? 'signup' : 'login')} className="text-slate-500 hover:text-white text-[10px] font-black uppercase tracking-widest">
                       {mode === 'login' ? 'New User? Register Account' : 'Existing User? Login'}
                     </button>
                 )}
                 {role !== 'user' && mode === 'signup' && (
                    <button type="button" onClick={() => setMode('login')} className="text-slate-500 hover:text-white text-[10px] font-black uppercase tracking-widest">
                       Admin Registration is Restricted
                    </button>
                 )}
              </div>
            </form>
          )}

          {step === 'kyc_otp' && (
             <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
               <div className="text-center space-y-2">
                 <div className="w-16 h-16 bg-cyan-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-cyan-500/20">
                   <span className="text-2xl">🔐</span>
                 </div>
                 <h3 className="text-white font-bold">Verify Identity Sources</h3>
                 <p className="text-[10px] text-slate-400 max-w-xs mx-auto">
                   We sent One-Time Passwords to <br/> <span className="text-cyan-400">{formData.email}</span> & <span className="text-cyan-400">{formData.localMobile}</span>
                 </p>
               </div>

               <div className="grid grid-cols-2 gap-4">
                 <div>
                   <label className="text-[9px] font-black text-slate-500 uppercase block mb-1">Email OTP</label>
                   <input type="text" name="emailOtp" maxLength={4} placeholder="0000" value={formData.emailOtp} onChange={handleInputChange} className="w-full text-center text-xl font-mono bg-[#050b1a] border border-white/10 rounded-xl py-3 text-white focus:border-cyan-500 outline-none" />
                 </div>
                 <div>
                   <label className="text-[9px] font-black text-slate-500 uppercase block mb-1">Mobile OTP</label>
                   <input type="text" name="mobileOtp" maxLength={4} placeholder="0000" value={formData.mobileOtp} onChange={handleInputChange} className="w-full text-center text-xl font-mono bg-[#050b1a] border border-white/10 rounded-xl py-3 text-white focus:border-cyan-500 outline-none" />
                 </div>
               </div>
               
               {errors.otp && <p className="text-red-500 text-center text-[10px] font-black uppercase">{errors.otp}</p>}
               <p className="text-center text-[9px] text-slate-500">Test Code: 1234</p>

               <button onClick={handleVerifyKYC} className="w-full bg-cyan-500 text-[#050b1a] py-4 rounded-xl font-black uppercase tracking-widest text-xs hover:bg-cyan-400 transition-all shadow-lg">
                 Verify & Start Auto-KYC
               </button>
             </div>
          )}

          {step === 'kyc_processing' && (
            <div className="text-center py-8 space-y-6">
              <div className="relative w-32 h-32 mx-auto">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="64" cy="64" r="60" stroke="#1e293b" strokeWidth="8" fill="none" />
                  <circle cx="64" cy="64" r="60" stroke="#22d3ee" strokeWidth="8" fill="none" strokeDasharray={377} strokeDashoffset={377 - (377 * kycProgress) / 100} className="transition-all duration-100 ease-linear" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center flex-col">
                  <span className="text-2xl font-black text-white">{kycProgress}%</span>
                </div>
              </div>
              <div className="bg-[#050b1a] p-4 rounded-xl border border-white/10 text-left font-mono text-[9px] space-y-2 h-24 overflow-hidden">
                <p className="text-emerald-500">> Initiating Biometric Scan...</p>
                {kycProgress > 20 && <p className="text-emerald-500">> Verifying Local Mobile Network...</p>}
                {kycProgress > 40 && <p className="text-emerald-500">> Mapping HAG5G Node Protocol...</p>}
                {kycProgress > 60 && <p className="text-emerald-500">> Generating 12-Digit Account Ledger...</p>}
                {kycProgress > 80 && <p className="text-emerald-500">> Minting Unified TUCB QR...</p>}
              </div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest animate-pulse">DO NOT CLOSE WINDOW</p>
            </div>
          )}

          {step === 'generation_success' && (
            <div className="space-y-6 animate-in zoom-in duration-500">
               <div className="bg-gradient-to-br from-[#050b1a] to-[#0d1b35] border border-cyan-500/30 p-6 rounded-2xl relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-3"><span className="text-4xl opacity-20">🎉</span></div>
                  <h3 className="text-cyan-400 font-black uppercase text-sm mb-4">Activation Successful</h3>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between items-center border-b border-white/5 pb-2">
                       <span className="text-[10px] text-slate-500 font-black uppercase">Account Number</span>
                       <span className="text-sm font-mono text-white font-bold tracking-wider">{genData.accountNumber.match(/.{1,4}/g)?.join(' ')}</span>
                    </div>
                    <div className="flex justify-between items-center border-b border-white/5 pb-2">
                       <span className="text-[10px] text-slate-500 font-black uppercase">HAG5G Number</span>
                       <span className="text-sm font-mono text-amber-400 font-bold tracking-wider">{genData.hagNumber}</span>
                    </div>
                    <div className="flex justify-between items-center">
                       <span className="text-[10px] text-slate-500 font-black uppercase">Linked Mobile</span>
                       <span className="text-sm font-mono text-slate-300">{formData.localMobile}</span>
                    </div>
                  </div>
               </div>

               <div className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/10">
                 <div className="w-16 h-16 bg-white p-1 rounded-lg">
                    {/* Mock QR */}
                    <div className="w-full h-full bg-[#050b1a] flex items-center justify-center overflow-hidden">
                        <div className="grid grid-cols-4 gap-0.5 w-full h-full p-1">
                            {[...Array(16)].map((_,i) => <div key={i} className={`bg-black ${Math.random() > 0.5 ? 'opacity-100' : 'opacity-0'}`}></div>)}
                        </div>
                    </div>
                 </div>
                 <div>
                   <h4 className="text-white font-bold text-xs uppercase">Unified TUCB QR</h4>
                   <p className="text-[9px] text-slate-400">One QR for all payments & transfers.</p>
                 </div>
               </div>

               <button onClick={handleFinalize} className="w-full bg-green-500 text-[#050b1a] py-4 rounded-xl font-black uppercase tracking-widest text-xs hover:bg-green-400 transition-all shadow-[0_0_20px_rgba(34,197,94,0.4)]">
                 Enter Portal Dashboard
               </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default AuthModal;
