import React, { useState, useEffect, useRef } from 'react';
import { ChatThread, ChatMessage, AvailableHustler } from '../types';
import { NEARBY_HUSTLERS } from '../data/hustlers';
import { ChatOccupantProfileModal } from './ChatOccupantProfileModal';

interface ChatSystemProps {
  activeContact?: AvailableHustler | null;
  onClearActiveContact?: () => void;
  onBackToRadar?: () => void;
  isHustler?: boolean;
  onDirectHire?: (hustler: AvailableHustler) => void;
  hiredHustlerIds?: string[];
  onCompleteJob?: (job: { id: string, title: string, price: number }, isInstant: boolean) => void;
}

const STORAGE_KEY = 'swifthustle_chat_threads_v3';

export const INITIAL_HUSTLER_THREADS: ChatThread[] = [
  {
    id: 'thread-hustler-1',
    hustlerId: 'hustler-1',
    otherUserName: 'Sipho Dlamini',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    skill: 'Master Electrician & Solar Tech',
    category: 'Electrical',
    hourlyRate: 280,
    rating: 4.9,
    phone: '+27 82 459 1102',
    distanceKm: 0.5,
    isVerified: true,
    occupantRole: 'hustler',
    completedJobs: 54, // how many jobs worked
    hustlersHired: 4,  // how many hustlers hired (dual role)
    jobsPosted: 6,
    reviewsCount: 48,
    tier: 'Premium',
    skills: [
      'Master Electrical Wiring',
      'Solar & Inverter Diagnostics',
      'Emergency DB Board Faults',
      'Loadshedding Backup Power',
      'CoC Compliance Certificates',
      '3-Phase Industrial Faults'
    ],
    bio: 'Certified wireman with 8+ years experience in domestic wiring, solar inverters, and emergency DB board faults in Sandton & surrounds. PIRB registered with full tool set.',
    lastMessage: 'Sawubona! Yes, I have my testing meter & tools ready in Sandton.',
    timestamp: Date.now() - 1000 * 60 * 12,
    unread: false,
    messages: [
      {
        id: 'msg-s1',
        senderId: 'me',
        text: 'Hi Sipho! I saw you on the Radar map. Can you inspect an inverter tripping during loadshedding?',
        timestamp: Date.now() - 1000 * 60 * 25
      },
      {
        id: 'msg-s2',
        senderId: 'other',
        text: 'Sawubona! Yes, I have my testing meter & tools ready in Sandton. I can be there in 20 minutes if you need an emergency callout.',
        timestamp: Date.now() - 1000 * 60 * 12
      }
    ]
  },
  {
    id: 'thread-hustler-2',
    hustlerId: 'hustler-2',
    otherUserName: 'Thabo Ndlovu',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    skill: 'Appliance Repair & Diagnostics',
    category: 'Appliances',
    hourlyRate: 220,
    rating: 4.8,
    phone: '+27 73 980 4421',
    distanceKm: 1.0,
    isVerified: true,
    occupantRole: 'hustler',
    completedJobs: 39,
    hustlersHired: 2,
    jobsPosted: 3,
    reviewsCount: 36,
    tier: 'Elite',
    skills: [
      'Defy & Samsung Diagnostics',
      'Commercial Refrigeration',
      'Oven Heating Elements',
      'Washing Machines & Dryers',
      'Thermostat Replacement'
    ],
    bio: 'Specialist in washing machines, refrigeration, and ovens. Same-day diagnostics with genuine parts and a 6-month guarantee on all installed components.',
    lastMessage: 'I carry spare heating elements for Defy and Samsung ovens.',
    timestamp: Date.now() - 1000 * 60 * 120,
    unread: true,
    messages: [
      {
        id: 'msg-t1',
        senderId: 'me',
        text: 'Hello Thabo, do you fix Defy oven thermostats today?',
        timestamp: Date.now() - 1000 * 60 * 180
      },
      {
        id: 'msg-t2',
        senderId: 'other',
        text: 'I carry spare heating elements for Defy and Samsung ovens. Ready whenever you initiate escrow!',
        timestamp: Date.now() - 1000 * 60 * 120
      }
    ]
  },
  {
    id: 'thread-hustler-3',
    hustlerId: 'hustler-3',
    otherUserName: 'Lerato Khumalo',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    skill: 'Interior Painter & Drywall Pro',
    category: 'Painting',
    hourlyRate: 195,
    rating: 5.0,
    phone: '+27 84 312 8847',
    distanceKm: 2.3,
    isVerified: true,
    occupantRole: 'hustler',
    completedJobs: 68,
    hustlersHired: 5,
    jobsPosted: 7,
    reviewsCount: 62,
    tier: 'Premium',
    skills: [
      'Precision Interior Finishing',
      'Waterproof Wall Coatings',
      'Cornices & Skirting Boards',
      'Drywall Patching & Sanding',
      'Texture Matching'
    ],
    bio: 'Precision interior finishing, waterproof coatings, cornices and drywall patching. Clean, fast, and detail-obsessed artisan with 5-star verified track record.',
    lastMessage: 'Thanks for the payment release! Pleasure doing business.',
    timestamp: Date.now() - 1000 * 60 * 60 * 24,
    unread: false,
    messages: [
      {
        id: 'msg-l1',
        senderId: 'other',
        text: 'Job completed and photos uploaded for proof of work.',
        timestamp: Date.now() - 1000 * 60 * 60 * 26
      },
      {
        id: 'msg-l2',
        senderId: 'me',
        text: 'Looks fantastic Lerato, verified and released!',
        timestamp: Date.now() - 1000 * 60 * 60 * 25
      },
      {
        id: 'msg-l3',
        senderId: 'other',
        text: 'Thanks for the payment release! Pleasure doing business.',
        timestamp: Date.now() - 1000 * 60 * 60 * 24
      }
    ]
  }
];

export const INITIAL_EMPLOYER_THREADS: ChatThread[] = [
  {
    id: 'thread-employer-1',
    otherUserName: 'Dr. Nomvula Sithole',
    avatar: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=150&auto=format&fit=crop&q=80',
    skill: 'Residential Estate Owner',
    category: 'Home & Property',
    hourlyRate: 320,
    rating: 5.0,
    phone: '+27 82 890 2311',
    distanceKm: 1.2,
    isVerified: true,
    occupantRole: 'employer',
    completedJobs: 2,
    hustlersHired: 19, // how many hustlers they have hired!
    jobsPosted: 24,
    reviewsCount: 28,
    tier: 'Elite',
    skills: [
      'Electrical & Inverter Maintenance',
      'Appliance Diagnostics',
      'Plumbing & Emergency Geysers',
      'Solar Panel Maintenance',
      'General Handyman Projects'
    ],
    bio: 'Residential property owner in Sandton. Frequent employer on SwiftHustle with a strict policy of 100% upfront escrow locking and immediate sign-off upon completion.',
    lastMessage: 'Sawubona! I am initiating the escrow deposit now. Please bring spare breakers.',
    timestamp: Date.now() - 1000 * 60 * 15,
    unread: true,
    messages: [
      {
        id: 'msg-e1',
        senderId: 'other',
        text: 'Sawubona! I saw your verified profile and excellent reviews on the SwiftHustle Radar. Are you free to inspect an inverter tripping during loadshedding in Sandton today?',
        timestamp: Date.now() - 1000 * 60 * 30
      },
      {
        id: 'msg-e2',
        senderId: 'me',
        text: 'Sawubona Dr. Nomvula! Yes, I have my testing meter and gear ready in Sandton. I can be there in 20 minutes if you need an emergency callout.',
        timestamp: Date.now() - 1000 * 60 * 20
      },
      {
        id: 'msg-e3',
        senderId: 'other',
        text: 'Sawubona! I am initiating the escrow deposit now. Please bring spare breakers if possible.',
        timestamp: Date.now() - 1000 * 60 * 15
      }
    ]
  },
  {
    id: 'thread-employer-2',
    otherUserName: 'Markus Van Der Merwe',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    skill: 'Commercial Facility Director',
    category: 'Commercial Maintenance',
    hourlyRate: 350,
    rating: 4.9,
    phone: '+27 79 432 1098',
    distanceKm: 0.8,
    isVerified: true,
    occupantRole: 'employer',
    completedJobs: 0,
    hustlersHired: 34, // how many hustlers they have hired!
    jobsPosted: 42,
    reviewsCount: 39,
    tier: 'Premium',
    skills: [
      'Commercial DB Maintenance',
      'Air Conditioning & HVAC',
      'Drywall & Partitioning',
      'CoC Compliance Inspection'
    ],
    bio: 'Facility Director at Sandton City Hub. Certified high-volume employer with 100% instant payment verification and verified escrow backing.',
    lastMessage: 'Sawubona, we need a certified technician for DB board inspection tomorrow morning.',
    timestamp: Date.now() - 1000 * 60 * 150,
    unread: false,
    messages: [
      {
        id: 'msg-m1',
        senderId: 'other',
        text: 'Sawubona, we need a certified technician for DB board inspection tomorrow morning. Escrow is pre-approved for full day rate.',
        timestamp: Date.now() - 1000 * 60 * 150
      }
    ]
  }
];

const ChatSystem: React.FC<ChatSystemProps> = ({
  activeContact,
  onClearActiveContact,
  onBackToRadar,
  isHustler = false,
  onDirectHire,
  hiredHustlerIds = [],
  onCompleteJob
}) => {
  const roleStorageKey = `${STORAGE_KEY}_${isHustler ? 'hustler' : 'employer'}`;
  const defaultThreads = isHustler ? INITIAL_EMPLOYER_THREADS : INITIAL_HUSTLER_THREADS;

  // Load initial threads according to role
  const [threads, setThreads] = useState<ChatThread[]>(() => {
    try {
      const saved = localStorage.getItem(roleStorageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return defaultThreads;
  });

  const [selectedThread, setSelectedThread] = useState<ChatThread | null>(null);
  const [messageText, setMessageText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [callNotice, setCallNotice] = useState<string | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [viewingProfileThread, setViewingProfileThread] = useState<ChatThread | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Switch threads on role change
  useEffect(() => {
    try {
      const saved = localStorage.getItem(roleStorageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setThreads(parsed);
          return;
        }
      }
    } catch {
      // ignore
    }
    setThreads(defaultThreads);
  }, [isHustler, roleStorageKey]);

  // Save threads to localStorage on change
  useEffect(() => {
    try {
      localStorage.setItem(roleStorageKey, JSON.stringify(threads));
    } catch {
      // ignore
    }
  }, [threads, roleStorageKey]);

  // Handle opening or creating chat for activeContact when passed
  useEffect(() => {
    if (!activeContact) return;

    // Check if a thread already exists for this hustler (by id or name)
    const existing = threads.find(
      t => (t.hustlerId && t.hustlerId === activeContact.id) ||
           t.otherUserName.toLowerCase() === activeContact.name.toLowerCase()
    );

    if (existing) {
      // Enrich with latest hustler data if available
      const matchedHustler = NEARBY_HUSTLERS.find(h => h.id === activeContact.id);
      const enriched: ChatThread = {
        ...existing,
        unread: false,
        completedJobs: existing.completedJobs || matchedHustler?.completedJobs || activeContact.completedJobs || 54,
        hustlersHired: existing.hustlersHired || 4,
        rating: existing.rating || activeContact.rating || 4.9,
        reviewsCount: existing.reviewsCount || matchedHustler?.reviewsCount || activeContact.reviewsCount || 48,
        skills: existing.skills && existing.skills.length > 0 
          ? existing.skills 
          : [
              activeContact.skill,
              activeContact.category,
              'Solar & Inverter Diagnostics',
              'Emergency DB Board Faults',
              'Loadshedding Backup Power',
              'CoC Compliance Certificates'
            ],
        bio: existing.bio || activeContact.bio || matchedHustler?.bio
      };

      const updated = threads.map(t => t.id === existing.id ? enriched : t);
      setThreads(updated);
      setSelectedThread(enriched);
    } else {
      // Create new thread for this contacted hustler
      const matchedHustler = NEARBY_HUSTLERS.find(h => h.id === activeContact.id);
      const newThread: ChatThread = {
        id: `thread-${activeContact.id}`,
        hustlerId: activeContact.id,
        otherUserName: activeContact.name,
        avatar: activeContact.avatar,
        skill: activeContact.skill,
        category: activeContact.category,
        hourlyRate: activeContact.hourlyRate,
        rating: activeContact.rating,
        phone: activeContact.phone,
        distanceKm: activeContact.distanceKm,
        isVerified: activeContact.isVerified,
        occupantRole: 'hustler',
        completedJobs: matchedHustler?.completedJobs || activeContact.completedJobs || 54,
        hustlersHired: 4,
        jobsPosted: 6,
        reviewsCount: matchedHustler?.reviewsCount || activeContact.reviewsCount || 48,
        tier: (matchedHustler?.tier || activeContact.tier || 'Elite') as any,
        skills: [
          activeContact.skill,
          activeContact.category,
          'Solar & Inverter Diagnostics',
          'Emergency DB Board Faults',
          'Loadshedding Backup Power',
          'CoC Compliance Certificates'
        ],
        bio: activeContact.bio || matchedHustler?.bio,
        timestamp: Date.now(),
        unread: false,
        lastMessage: `Inquiry started for ${activeContact.skill}`,
        messages: [
          {
            id: `msg-init-${Date.now()}-1`,
            senderId: 'me',
            text: `Hi ${activeContact.name.split(' ')[0]}! I saw your verified profile on the SwiftHustle Radar (${activeContact.skill} • R${activeContact.hourlyRate}/hr). Are you available for a gig?`,
            timestamp: Date.now() - 45000
          },
          {
            id: `msg-init-${Date.now()}-2`,
            senderId: 'other',
            text: `Sawubona! Yes, I am online and available right now with full gear. What are the job details?`,
            timestamp: Date.now() - 15000
          }
        ]
      };

      setThreads(prev => [newThread, ...prev]);
      setSelectedThread(newThread);
    }
  }, [activeContact]);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (selectedThread) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [selectedThread?.messages, isTyping]);

  const handleSelectThread = (thread: ChatThread) => {
    const updated = threads.map(t => t.id === thread.id ? { ...t, unread: false } : t);
    setThreads(updated);
    setSelectedThread({ ...thread, unread: false });
  };

  const handleBackToList = () => {
    setSelectedThread(null);
    onClearActiveContact?.();
  };

  const handleSendMessage = (customText?: string) => {
    const textToSend = (customText || messageText).trim();
    if (!textToSend || !selectedThread) return;

    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderId: 'me',
      text: textToSend,
      timestamp: Date.now()
    };

    const updatedMessages = [...(selectedThread.messages || []), newMessage];
    const updatedThread: ChatThread = {
      ...selectedThread,
      messages: updatedMessages,
      lastMessage: textToSend,
      timestamp: Date.now(),
      unread: false
    };

    setSelectedThread(updatedThread);
    setThreads(prev => [updatedThread, ...prev.filter(t => t.id !== selectedThread.id)]);
    setMessageText('');

    // Trigger realistic AI/Worker reply after a brief typing pause
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const replyText = generateResponse(textToSend, selectedThread);
      const replyMessage: ChatMessage = {
        id: `msg-rep-${Date.now()}`,
        senderId: 'other',
        text: replyText,
        timestamp: Date.now()
      };

      const finalMessages = [...updatedMessages, replyMessage];
      const finalThread: ChatThread = {
        ...updatedThread,
        messages: finalMessages,
        lastMessage: replyText,
        timestamp: Date.now()
      };

      setSelectedThread(finalThread);
      setThreads(prev => [finalThread, ...prev.filter(t => t.id !== selectedThread.id)]);
    }, 1200);
  };

  const generateResponse = (incoming: string, thread: ChatThread): string => {
    const isOccupantEmployer = thread.occupantRole === 'employer' || isHustler;

    if (isOccupantEmployer) {
      const lower = incoming.toLowerCase();
      if (lower.includes('where') || lower.includes('address') || lower.includes('pin') || lower.includes('location')) {
        return `We are located in Sandton (near Grayston Drive). Security gate will grant access under your name.`;
      }
      if (lower.includes('rate') || lower.includes('cost') || lower.includes('price') || lower.includes('quote')) {
        return `Your rate is confirmed and already deposited into SwiftHustle escrow. Once verified, funds release instantly!`;
      }
      if (lower.includes('arrived') || lower.includes('there') || lower.includes('gate') || lower.includes('here')) {
        return `Great! Please buzz unit 4B or mention SwiftHustle at the boom gate.`;
      }
      if (lower.includes('tool') || lower.includes('part') || lower.includes('material')) {
        return `Please bring all specialized diagnostic tools. Any needed replacement parts will be added to the escrow milestone.`;
      }
      return `Sounds great! Thank you for the quick communication. Looking forward to getting this sorted.`;
    }

    return generateHustlerResponse(incoming, thread);
  };

  const generateHustlerResponse = (incoming: string, thread: ChatThread): string => {
    const lower = incoming.toLowerCase();

    if (lower.includes('escrow') || lower.includes('pay') || lower.includes('hire') || lower.includes('deposit')) {
      return `Perfect! Once escrow is secured via SwiftHustle, my GPS tracker activates and I will head straight over.`;
    }
    if (lower.includes('where') || lower.includes('eta') || lower.includes('time') || lower.includes('arrive') || lower.includes('now')) {
      return `I am currently in ${thread.distanceKm ? `${thread.distanceKm} km away` : 'the area'}. I can arrive in about 20–30 minutes.`;
    }
    if (lower.includes('tool') || lower.includes('equipment') || lower.includes('parts')) {
      return `Yes, I carry all standard professional tools, testing equipment, and safety gear in my bakkie.`;
    }
    if (lower.includes('location') || lower.includes('address') || lower.includes('pin') || lower.includes('sandton')) {
      return `Got the location! Pin confirmed. Ready to start as soon as you confirm the job scope.`;
    }
    if (lower.includes('rate') || lower.includes('cost') || lower.includes('price')) {
      return `My hourly rate is R${thread.hourlyRate || 250}/hr. SwiftHustle holds the funds safely until you sign off on the proof-of-work.`;
    }

    return `Understood! I'm ready to assist. Let me know if you want me to head over right now, or if you need any specific preparations.`;
  };

  const handleCallContact = (thread: ChatThread) => {
    const phone = thread.phone || '+27 82 459 1102';
    setCallNotice(`Calling ${thread.otherUserName} on ${phone}...`);
    setTimeout(() => {
      setCallNotice(null);
    }, 3500);
  };

  const handleQuickHire = () => {
    if (!selectedThread) return;
    const hustlerObj = NEARBY_HUSTLERS.find(h => h.id === selectedThread.hustlerId) || {
      id: selectedThread.hustlerId || 'hustler-custom',
      name: selectedThread.otherUserName,
      avatar: selectedThread.avatar,
      skill: selectedThread.skill || 'Professional Hustler',
      category: selectedThread.category || 'General',
      rating: selectedThread.rating || 4.9,
      reviewsCount: 42,
      hourlyRate: selectedThread.hourlyRate || 250,
      location: [-26.1076, 28.0567] as [number, number],
      distanceKm: selectedThread.distanceKm || 1.2,
      isVerified: true,
      tier: 'Rising Star' as any,
      bio: '',
      isOnline: true,
      isWorking: true,
      status: 'working' as const,
      completedJobs: 18
    };

    const deposit = (selectedThread.hourlyRate || 250) * 3;
    const hireMsg: ChatMessage = {
      id: `msg-hire-${Date.now()}`,
      senderId: 'me',
      text: `💼 Escrow Confirmed: You hired ${selectedThread.otherUserName} for this job. Escrow deposit of R${deposit} locked securely. Work status: Currently Working.`,
      timestamp: Date.now()
    };

    const updatedMessages = [...(selectedThread.messages || []), hireMsg];
    const updatedThread: ChatThread = {
      ...selectedThread,
      isHired: true,
      messages: updatedMessages,
      lastMessage: hireMsg.text,
      timestamp: Date.now()
    };

    setSelectedThread(updatedThread);
    setThreads(prev => [updatedThread, ...prev.filter(t => t.id !== selectedThread.id)]);

    if (onDirectHire) {
      onDirectHire({
        ...hustlerObj,
        isWorking: true,
        status: 'working'
      } as AvailableHustler);
    }

    // Trigger worker live confirmation
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const replyMsg: ChatMessage = {
        id: `msg-rep-hire-${Date.now()}`,
        senderId: 'other',
        text: `Sawubona! Escrow deposit of R${deposit} is confirmed and locked. My GPS tracker is now live and I am currently working on this job for you!`,
        timestamp: Date.now()
      };
      setSelectedThread(curr => {
        if (!curr) return curr;
        const msgs = [...(curr.messages || []), replyMsg];
        const t = { ...curr, messages: msgs, lastMessage: replyMsg.text, timestamp: Date.now() };
        setThreads(prev => [t, ...prev.filter(x => x.id !== t.id)]);
        return t;
      });
    }, 1000);
  };

  // Filtered threads for search
  const filteredThreads = threads.filter(t =>
    t.otherUserName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (t.skill && t.skill.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (t.lastMessage && t.lastMessage.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // VIEW 1: ACTIVE CHAT SCREEN WITH SELECTED HUSTLER
  if (selectedThread) {
    const hustlerObj = NEARBY_HUSTLERS.find(h => h.id === selectedThread.hustlerId);
    const messages = selectedThread.messages || [];
    const isContactHired = Boolean(
      selectedThread.isHired ||
      (selectedThread.hustlerId && hiredHustlerIds.includes(selectedThread.hustlerId)) ||
      (activeContact?.id === selectedThread.hustlerId && activeContact?.isWorking)
    );

    return (
      <div className="flex flex-col h-full bg-slate-50 relative pb-20 select-text">
        {/* Call Toast Notification */}
        {callNotice && (
          <div className="absolute top-16 left-4 right-4 z-50 bg-[#1B263B] text-white p-3 rounded-2xl shadow-2xl border border-emerald-400 flex items-center justify-between animate-in fade-in duration-200">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span className="text-xs font-bold">{callNotice}</span>
            </div>
            <a
              href={`tel:${selectedThread.phone || '+27824591102'}`}
              className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-[10px] uppercase rounded-lg"
            >
              Dial
            </a>
          </div>
        )}

        {/* Top Chat Header */}
        <header className="bg-[#1B263B] text-white p-3.5 sm:p-4 flex items-center justify-between shadow-md sticky top-0 z-20 border-b border-white/10">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <button
              onClick={handleBackToList}
              className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors shrink-0 active:scale-95"
              title="Back to all conversations"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 19l-7-7 7-7" />
              </svg>
            </button>

            {/* Clickable occupant profile trigger */}
            <button
              type="button"
              onClick={() => {
                setViewingProfileThread(selectedThread);
                setIsProfileModalOpen(true);
              }}
              className="flex items-center gap-2.5 sm:gap-3 min-w-0 text-left hover:opacity-95 transition-all group cursor-pointer"
              title="Click to view full occupant profile, ratings, skills, jobs worked & hustlers hired"
            >
              <div className="relative shrink-0">
                <img
                  src={selectedThread.avatar}
                  className="w-10 h-10 rounded-full aspect-square object-cover border-2 border-emerald-400 shadow-sm group-hover:ring-2 group-hover:ring-emerald-300 transition-all"
                  alt={selectedThread.otherUserName}
                />
                <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#1B263B] ${isContactHired ? 'bg-orange-500' : 'bg-emerald-500'}`}></div>
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h2 className="font-black text-sm text-white tracking-tight truncate group-hover:text-emerald-300 transition-colors flex items-center gap-1">
                    <span>{selectedThread.otherUserName}</span>
                  </h2>
                  {selectedThread.isVerified !== false && (
                    <span className="text-[10px] text-[#D4AF37] font-black bg-[#D4AF37]/15 px-1 rounded border border-[#D4AF37]/30 shrink-0">
                      ✓ Verified
                    </span>
                  )}
                  <span className="text-[9px] text-emerald-300 bg-emerald-500/20 group-hover:bg-emerald-500/35 border border-emerald-400/30 px-1.5 py-0.5 rounded-md font-bold transition-all shrink-0 flex items-center gap-0.5">
                    <span>Profile</span>
                    <span>↗</span>
                  </span>
                </div>
                <p className="text-[11px] truncate flex items-center gap-1.5">
                  {isContactHired ? (
                    <span className="text-orange-400 font-black flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-pulse"></span>
                      Currently Working
                    </span>
                  ) : (
                    <span className="text-emerald-300 font-bold">{selectedThread.skill || (isHustler ? 'Verified Employer' : 'Verified Worker')}</span>
                  )}
                  {selectedThread.hourlyRate && !isHustler && (
                    <span className="text-white/80 font-normal"> • R{selectedThread.hourlyRate}/hr</span>
                  )}
                  <span className="text-slate-400 font-normal text-[10px] hidden sm:inline">• Click to view stats</span>
                </p>
              </div>
            </button>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => handleCallContact(selectedThread)}
              className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all active:scale-95"
              title={`Call ${selectedThread.otherUserName}`}
            >
              <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
                <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 4V3z" />
              </svg>
            </button>

            {!isHustler && (
              isContactHired ? (
                <div className="flex items-center gap-1.5">
                  <button
                    disabled
                    className="px-3 py-1.5 bg-slate-200 text-slate-400 border border-slate-300 rounded-xl text-[10px] font-black uppercase tracking-wider cursor-not-allowed shadow-none flex items-center gap-1 pointer-events-none select-none"
                    title="Worker is already hired and currently working"
                  >
                    <span>✓</span>
                    <span>Hired</span>
                  </button>
                  {onCompleteJob && (
                    <button
                      onClick={() => onCompleteJob({ id: 'gig-1', title: `Job with ${selectedThread.otherUserName}`, price: (selectedThread.hourlyRate || 250) * 3 }, false)}
                      className="px-2.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-[10px] uppercase rounded-xl shadow-xs transition-all active:scale-95"
                      title="Mark work complete to resume notifications"
                    >
                      Finish Job
                    </button>
                  )}
                </div>
              ) : (
                <button
                  onClick={handleQuickHire}
                  className="px-2.5 py-1.5 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 rounded-xl text-[10px] font-black uppercase tracking-wider shadow-sm active:scale-95 transition-all"
                  title="Direct Escrow Hire"
                >
                  Hire &amp; Escrow
                </button>
              )
            )}
          </div>
        </header>

        {/* Occupant Quick Info & Context Banner */}
        <div className="bg-white border-b border-slate-200/80 px-4 py-2 flex items-center justify-between text-xs shrink-0 flex-wrap gap-2">
          <div className="flex items-center gap-2 truncate">
            <span className={`w-2 h-2 rounded-full shrink-0 ${isContactHired ? 'bg-orange-500 animate-pulse' : 'bg-emerald-500'}`}></span>
            <span className="text-[11px] text-slate-600 font-bold truncate">
              {isContactHired ? (
                <>
                  <strong className="text-orange-600">Currently Working (In Escrow)</strong>
                  <span className="text-slate-400 ml-1.5 font-normal">🔕 Notifications paused until job is completed</span>
                </>
              ) : (
                isHustler ? 'Verified Employer Client' : 'Available for Hire'
              )}
              {selectedThread.distanceKm ? ` • 📍 ${selectedThread.distanceKm} km away` : ' • 📍 Sandton Area'}
              {selectedThread.rating && ` • ★ ${selectedThread.rating.toFixed(1)}`}
              {isHustler 
                ? (selectedThread.hustlersHired ? ` • ${selectedThread.hustlersHired} hustlers hired` : ' • 19 hustlers hired')
                : (hustlerObj?.completedJobs || selectedThread.completedJobs ? ` • ${hustlerObj?.completedJobs || selectedThread.completedJobs} jobs worked` : ' • 54 jobs worked')
              }
            </span>
          </div>
          <button
            type="button"
            onClick={() => {
              setViewingProfileThread(selectedThread);
              setIsProfileModalOpen(true);
            }}
            className="text-[10px] text-emerald-800 hover:text-emerald-900 font-black bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2.5 py-1 rounded-full shrink-0 flex items-center gap-1 transition-all active:scale-95 cursor-pointer shadow-2xs"
            title="Click to view occupant profile: ratings, skills, jobs worked & hustlers hired"
          >
            <span>👤 View Profile &amp; Stats</span>
            <span className="text-[9px] text-emerald-600 font-normal">↗</span>
          </button>
        </div>

        {/* Chat Messages List */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3.5 no-scrollbar">
          <div className="text-center my-2">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 bg-slate-200/60 px-3 py-1 rounded-full">
              End-to-End Escrow Communication
            </span>
          </div>

          {messages.map((msg) => {
            const isMe = msg.senderId === 'me';
            const timeStr = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

            return (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${isMe ? 'flex-row-reverse items-end' : 'flex-row items-end'} transition-all`}
              >
                {!isMe && (
                  <div className="shrink-0 mb-3">
                    <img
                      src={selectedThread.avatar}
                      alt={selectedThread.otherUserName}
                      className="w-7 h-7 rounded-full aspect-square object-cover border border-slate-200 shadow-2xs"
                    />
                  </div>
                )}
                <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-[80%] sm:max-w-[70%]`}>
                  <div
                    className={`p-3.5 rounded-2xl shadow-sm text-xs leading-relaxed ${
                      isMe
                        ? 'bg-gradient-to-br from-[#1B263B] to-slate-800 text-white rounded-tr-none border border-slate-700/60'
                        : 'bg-white text-slate-800 rounded-tl-none border border-slate-200/80'
                    }`}
                  >
                    <p className="font-medium whitespace-pre-wrap">{msg.text}</p>
                  </div>
                  <div className="flex items-center gap-1 mt-1 px-1 text-[10px] text-slate-400 font-semibold">
                    <span>{timeStr}</span>
                    {isMe && <span className="text-emerald-500 font-black">✓✓</span>}
                  </div>
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex items-center gap-2 text-slate-500 text-xs bg-white border border-slate-200 px-3 py-2 rounded-2xl rounded-tl-none w-fit shadow-sm">
              <img
                src={selectedThread.avatar}
                alt={selectedThread.otherUserName}
                className="w-5 h-5 rounded-full aspect-square object-cover border border-slate-200"
              />
              <span className="flex gap-1">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.4s]"></span>
              </span>
              <span className="text-[11px] font-bold text-slate-600">
                {selectedThread.otherUserName.split(' ')[0]} is typing...
              </span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Action Prompt Chips */}
        <div className="px-3 py-1.5 bg-slate-100/80 border-t border-slate-200/80 overflow-x-auto flex items-center gap-1.5 shrink-0 no-scrollbar">
          <button
            onClick={() => handleSendMessage('📍 My location is Sandton Central. Can you start now?')}
            className="px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-[11px] font-bold rounded-xl whitespace-nowrap shadow-xs active:scale-95 transition-all"
          >
            📍 Share Sandton Location
          </button>
          <button
            onClick={() => handleSendMessage('⏱️ How quickly can you arrive with your tools?')}
            className="px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-[11px] font-bold rounded-xl whitespace-nowrap shadow-xs active:scale-95 transition-all"
          >
            ⏱️ Ask ETA
          </button>
          <button
            onClick={() => handleSendMessage('🛠️ Do you have all the required tools and materials?')}
            className="px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-[11px] font-bold rounded-xl whitespace-nowrap shadow-xs active:scale-95 transition-all"
          >
            🛠️ Check Tools
          </button>
          {!isHustler && (
            isContactHired ? (
              <span className="px-2.5 py-1 bg-orange-100 text-orange-800 border border-orange-300 text-[11px] font-black rounded-xl whitespace-nowrap flex items-center gap-1.5 shadow-xs select-none">
                <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
                ✓ Hired &amp; Currently Working
              </span>
            ) : (
              <button
                onClick={handleQuickHire}
                className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 text-emerald-900 text-[11px] font-black rounded-xl whitespace-nowrap shadow-xs active:scale-95 transition-all"
              >
                💼 Lock Escrow &amp; Hire
              </button>
            )
          )}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0">
          <input
            type="text"
            placeholder={`Message ${selectedThread.otherUserName}...`}
            className="flex-1 bg-slate-100 border border-slate-200 rounded-full px-4 py-2.5 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#1B263B] transition-all"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleSendMessage();
              }
            }}
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={!messageText.trim()}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all shadow-md ${
              messageText.trim()
                ? 'bg-[#1B263B] text-white active:scale-90 hover:bg-slate-900'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
            title="Send Message"
          >
            <svg className="w-4 h-4 ml-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
          </button>
        </div>

        {/* Profile Details Modal for Active Chat Occupant */}
        {viewingProfileThread && (
          <ChatOccupantProfileModal
            isOpen={isProfileModalOpen}
            onClose={() => setIsProfileModalOpen(false)}
            thread={viewingProfileThread}
            isHustlerViewer={isHustler}
            isContactHired={isContactHired}
            onDirectHire={onDirectHire}
            onCallContact={handleCallContact}
            onCompleteJob={onCompleteJob}
          />
        )}
      </div>
    );
  }

  // VIEW 2: CONVERSATIONS LIST
  return (
    <div className="flex flex-col h-full bg-white pb-20 select-text">
      {/* Header */}
      <div className="p-5 pb-3 border-b border-slate-100 bg-white">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-2xl font-black text-[#1B263B] tracking-tight">Messages</h1>
            <p className="text-xs text-slate-500 font-medium">
              {isHustler ? 'Coordinate jobs with employers securely' : 'Direct communication with verified talent'}
            </p>
          </div>
          {onBackToRadar && (
            <button
              onClick={onBackToRadar}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all"
            >
              Radar Map
            </button>
          )}
        </div>

        {/* Search Input */}
        <div className="relative mt-2">
          <input
            type="text"
            placeholder="Search conversations by name or skill..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-100 border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#1B263B]"
          />
          <svg className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
      </div>

      {/* Threads List */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-100 no-scrollbar">
        {filteredThreads.length === 0 ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-slate-100 text-2xl flex items-center justify-center mx-auto mb-3">
              💬
            </div>
            <h3 className="font-bold text-sm text-slate-800 mb-1">No conversations found</h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              Find verified workers on the Radar Map and tap "Send Message" to start coordinating immediately.
            </p>
          </div>
        ) : (
          filteredThreads.map((thread) => {
            const timeFormatted = new Date(thread.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            const isThreadHired = Boolean(
              thread.isHired ||
              (thread.hustlerId && hiredHustlerIds.includes(thread.hustlerId))
            );

            return (
              <div
                key={thread.id}
                onClick={() => handleSelectThread(thread)}
                className="flex items-center p-4 hover:bg-slate-50 cursor-pointer transition-colors active:bg-slate-100"
              >
                <div 
                  className="relative shrink-0 cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation();
                    setViewingProfileThread(thread);
                    setIsProfileModalOpen(true);
                  }}
                  title={`View ${thread.otherUserName}'s profile & stats`}
                >
                  <img
                    src={thread.avatar}
                    className="w-12 h-12 rounded-full aspect-square object-cover border border-slate-200 shadow-2xs hover:ring-2 hover:ring-emerald-400 transition-all"
                    alt={thread.otherUserName}
                  />
                  <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white ${isThreadHired ? 'bg-orange-500' : 'bg-emerald-500'}`}></div>
                  {thread.unread && (
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-white animate-pulse"></div>
                  )}
                </div>

                <div className="ml-3.5 flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-0.5">
                    <div className="flex items-center gap-1.5 truncate">
                      <h3 className="font-black text-sm text-[#1B263B] truncate hover:text-emerald-700 transition-colors">{thread.otherUserName}</h3>
                      {thread.isVerified !== false && (
                        <span className="text-[10px] text-[#D4AF37] font-black">✓</span>
                      )}
                      {isThreadHired && (
                        <span className="text-[9px] font-black text-orange-600 bg-orange-50 border border-orange-200 px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                          Working
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setViewingProfileThread(thread);
                          setIsProfileModalOpen(true);
                        }}
                        className="text-[9px] font-bold text-slate-400 hover:text-emerald-700 hover:bg-emerald-50 px-1.5 py-0.5 rounded transition-colors ml-1"
                        title="View occupant ratings, skills, jobs worked & hustlers hired"
                      >
                        Info ↗
                      </button>
                    </div>
                    <span className="text-[10px] text-slate-400 font-bold shrink-0 ml-2">{timeFormatted}</span>
                  </div>

                  {thread.skill && (
                    <span className="text-[10px] font-bold text-emerald-600 block truncate">
                      {thread.skill} {thread.hourlyRate ? `• R${thread.hourlyRate}/hr` : ''}
                    </span>
                  )}

                  <p className={`text-xs mt-0.5 truncate ${thread.unread ? 'text-slate-900 font-bold' : 'text-slate-500'}`}>
                    {thread.lastMessage}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Profile Details Modal for Thread List selection */}
      {viewingProfileThread && (
        <ChatOccupantProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          thread={viewingProfileThread}
          isHustlerViewer={isHustler}
          isContactHired={Boolean(
            viewingProfileThread.isHired ||
            (viewingProfileThread.hustlerId && hiredHustlerIds.includes(viewingProfileThread.hustlerId))
          )}
          onDirectHire={onDirectHire}
          onCallContact={handleCallContact}
          onCompleteJob={onCompleteJob}
        />
      )}
    </div>
  );
};

export default ChatSystem;
