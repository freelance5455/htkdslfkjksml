
import React, { useState } from 'react';

interface RatingDialogProps {
  jobTitle: string;
  hustlerName?: string;
  onClose: () => void;
  onSubmit: (rating: number, comment: string) => Promise<void>;
}

const RatingDialog: React.FC<RatingDialogProps> = ({ jobTitle, hustlerName = "Hustler", onClose, onSubmit }) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const colors = {
    gold: '#D4AF37',
    navy: '#1B263B',
    slate: '#64748B',
    emerald: '#10B981',
    lightGold: '#FDF7E7'
  };

  const StarPart = ({ value, isHover }: { value: number; isHover: boolean }) => {
    const isHalf = value % 1 !== 0;
    const isActive = (isHover ? hoverRating : rating) >= value;
    
    return (
      <div 
        className={`h-12 w-6 flex items-center justify-center cursor-pointer transition-all duration-150 ${isHover ? 'scale-110' : ''}`}
        onMouseEnter={() => setHoverRating(value)}
        onMouseLeave={() => setHoverRating(0)}
        onClick={() => setRating(value)}
      >
        <div 
          className="overflow-hidden" 
          style={{ width: isHalf ? '50%' : '100%', position: 'relative', left: isHalf ? '25%' : '0' }}
        >
          <svg 
            className={`w-10 h-10 ${isActive ? 'fill-[#D4AF37]' : 'fill-slate-200'}`}
            viewBox="0 0 24 24"
            style={{ 
              transform: isHalf ? 'translateX(25%)' : 'none',
              filter: isActive ? 'drop-shadow(0 0 4px rgba(212, 175, 55, 0.3))' : 'none'
            }}
          >
            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
          </svg>
        </div>
      </div>
    );
  };

  const StarContainer = ({ starIndex }: { starIndex: number; key?: number | string }) => (
    <div className="flex relative">
      <StarPart value={starIndex + 0.5} isHover={hoverRating >= starIndex + 0.5 && hoverRating < starIndex + 1} />
      <StarPart value={starIndex + 1} isHover={hoverRating >= starIndex + 1} />
    </div>
  );

  const handleSubmit = async () => {
    if (rating === 0) return;
    setIsSubmitting(true);
    await onSubmit(rating, comment);
    setIsSubmitting(false);
    setIsSuccess(true);
    setTimeout(onClose, 2500);
  };

  if (isSuccess) {
    return (
      <div className="fixed inset-0 z-[6000] bg-black/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
        <div className="bg-white w-full max-w-sm rounded-[48px] p-10 shadow-2xl text-center animate-in zoom-in duration-500">
          <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-12 h-12 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-2xl font-black text-[#1B263B] mb-2">Hustle Verified!</h2>
          <p className="text-sm text-slate-500 font-medium leading-relaxed">
            Thank you for helping the <span className="text-[#1B263B] font-black underline decoration-[#D4AF37]">SwiftHustle community</span> stay safe and reliable!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[6000] bg-black/70 backdrop-blur-sm flex items-center justify-center p-6 animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-sm rounded-[40px] p-8 shadow-2xl animate-in slide-in-from-bottom duration-400">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#1B263B]/5 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-[#1B263B]/10">
            <svg className="w-8 h-8 text-[#1B263B]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
          </div>
          <h2 className="text-xl font-black text-[#1B263B]">Rate {hustlerName}'s Performance</h2>
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em] mt-1">Ref: {jobTitle}</p>
        </div>

        {/* Task 1: Half-Rating Star Bar */}
        <div className="flex justify-center gap-1 mb-10 relative">
          <div className="flex bg-slate-50 p-4 rounded-3xl border border-slate-100">
            {[0, 1, 2, 3, 4].map((i) => (
              <StarContainer key={i} starIndex={i} />
            ))}
          </div>
          <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] font-black text-[#D4AF37] uppercase tracking-widest">
            {rating > 0 ? `${rating} Stars` : 'Select Stars'}
          </div>
        </div>

        <div className="mb-8">
          <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-2">Feedback / Comments</label>
          <textarea
            placeholder="Share details about the quality of work, punctuality, and professionalism..."
            className="w-full bg-slate-50 border border-slate-100 rounded-3xl p-5 text-sm focus:ring-4 focus:ring-[#1B263B]/5 focus:bg-white focus:border-[#1B263B] outline-none transition-all resize-none h-32 font-medium text-[#1B263B]"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
        </div>

        <div className="flex flex-col gap-4">
          <button
            onClick={handleSubmit}
            disabled={rating === 0 || isSubmitting}
            className={`w-full py-5 rounded-[24px] font-black text-xs uppercase tracking-[0.3em] shadow-xl transition-all active:scale-95
              ${rating === 0 || isSubmitting 
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none' 
                : 'bg-[#1B263B] text-white shadow-[#1B263B]/20 hover:bg-slate-800'}`}
          >
            {isSubmitting ? 'Processing Vault...' : 'Submit Review'}
          </button>
          
          <button
            disabled={isSubmitting}
            onClick={onClose}
            className="w-full py-2 text-slate-300 font-black text-[9px] uppercase tracking-widest hover:text-rose-500 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default RatingDialog;
