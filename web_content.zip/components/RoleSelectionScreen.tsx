
import React from 'react';

interface RoleSelectionScreenProps {
  onSelect: (role: 'hustler' | 'client') => void;
}

const RoleSelectionScreen: React.FC<RoleSelectionScreenProps> = ({ onSelect }) => {
  return (
    <div className="fixed inset-0 z-[10600] bg-white flex flex-col p-8 overflow-y-auto">
      <div className="mt-8 mb-12">
        <h1 className="text-3xl font-black text-slate-900 leading-tight">
          Choose Your <br />
          <span className="text-emerald-600 underline decoration-emerald-200">Swift Journey</span>.
        </h1>
        <p className="text-slate-500 text-sm mt-2 font-medium">
          How do you plan to use SwiftHustle SA?
        </p>
      </div>

      <div className="space-y-6 flex-1">
        {/* Hustler Card */}
        <button 
          onClick={() => onSelect('hustler')}
          className="w-full group text-left bg-white border-2 border-slate-100 p-6 rounded-[32px] transition-all hover:border-emerald-500 hover:shadow-xl hover:shadow-emerald-500/10 active:scale-[0.98]"
        >
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center transition-colors group-hover:bg-emerald-600 group-hover:text-white">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900">Become a Hustler</h3>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-0.5">Find Work & Get Paid</p>
            </div>
          </div>
          <p className="mt-4 text-slate-400 text-sm leading-relaxed">
            Browse high-paying gigs nearby, showcase your skills, and earn secure payments through escrow.
          </p>
        </button>

        {/* Employer Card */}
        <button 
          onClick={() => onSelect('client')}
          className="w-full group text-left bg-white border-2 border-slate-100 p-6 rounded-[32px] transition-all hover:border-blue-500 hover:shadow-xl hover:shadow-blue-500/10 active:scale-[0.98]"
        >
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center transition-colors group-hover:bg-blue-600 group-hover:text-white">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
              </svg>
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900">Hire a Professional</h3>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-0.5">Post a Job & Hire</p>
            </div>
          </div>
          <p className="mt-4 text-slate-400 text-sm leading-relaxed">
            Post your requirements, receive offers from verified experts, and manage projects with safety.
          </p>
        </button>
      </div>

      <div className="mt-12 text-center">
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-loose">
          You can always switch between modes <br />
          in your account settings.
        </p>
      </div>
    </div>
  );
};

export default RoleSelectionScreen;