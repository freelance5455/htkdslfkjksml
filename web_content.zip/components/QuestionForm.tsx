
import React, { useState, useEffect } from 'react';
import { Question } from '../types';
import { Save, X, Activity } from 'lucide-react';

interface QuestionFormProps {
  onSave: (question: Question) => void;
  onCancel: () => void;
  initialQuestion?: Question;
}

const QuestionForm: React.FC<QuestionFormProps> = ({ onSave, onCancel, initialQuestion }) => {
  const [text, setText] = useState('');
  const [options, setOptions] = useState(['', '', '', '']);
  const [correctAnswer, setCorrectAnswer] = useState(0);
  const [explanation, setExplanation] = useState('');

  useEffect(() => {
    if (initialQuestion) {
      setText(initialQuestion.text);
      setOptions(initialQuestion.options);
      setCorrectAnswer(initialQuestion.correctAnswer);
      setExplanation(initialQuestion.explanation);
    }
  }, [initialQuestion]);

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || options.some(o => !o.trim())) {
      alert("Please fill in the question and all options.");
      return;
    }
    
    onSave({
      id: initialQuestion ? initialQuestion.id : crypto.randomUUID(),
      text,
      options,
      correctAnswer,
      explanation
    });
  };

  return (
    <div className="bg-white border border-blue-200 rounded-xl p-5 shadow-sm space-y-5 animate-in fade-in slide-in-from-top-2 duration-300">
      <div className="flex justify-between items-center">
        <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
          {initialQuestion ? 'Edit Question' : 'New Question'}
        </h3>
        <button onClick={onCancel} className="text-slate-300 hover:text-slate-500"><X size={18} /></button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1">
          <label className="text-[10px] font-bold text-slate-400 uppercase">Question Text</label>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-md text-sm outline-none focus:border-blue-500 min-h-[80px]"
            placeholder="Enter question (Use \( ... \) for math)"
          />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase">Options (Click letter to set as correct)</label>
          <div className="space-y-2">
            {options.map((opt, index) => (
              <div key={index} className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setCorrectAnswer(index)}
                  className={`w-8 h-8 flex items-center justify-center rounded-md font-bold text-xs transition-all ${correctAnswer === index ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`}
                >
                  {['A', 'B', 'C', 'D'][index]}
                </button>
                <input
                  type="text"
                  value={opt}
                  onChange={(e) => handleOptionChange(index, e.target.value)}
                  className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-md text-sm outline-none focus:border-blue-500"
                  placeholder={`Option ${index + 1}`}
                />
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-[10px] font-bold text-slate-400 uppercase">Explanation (Optional)</label>
          <textarea
            value={explanation}
            onChange={(e) => setExplanation(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-md text-sm outline-none focus:border-blue-500 min-h-[60px]"
            placeholder="How to solve..."
          />
        </div>

        <div className="pt-2">
          <button
            type="submit"
            className="w-full py-2 bg-blue-600 text-white rounded-lg text-sm font-bold shadow-md hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
          >
            <Save size={16} /> Save Changes
          </button>
        </div>
      </form>
    </div>
  );
};

export default QuestionForm;
