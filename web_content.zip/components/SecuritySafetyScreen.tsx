
import React, { useState } from 'react';
import { UserProfile } from '../types';
import {
  preparePanicDispatch,
  PanicDispatchResult,
  triggerChannelLaunch,
  cleanPhoneForWhatsApp,
  cleanPhoneForSMS
} from './emergencyUtils';

interface SecuritySafetyScreenProps {
  profile: UserProfile;
  onUpdate: (updates: Partial<UserProfile>) => void;
  onBack: () => void;
  onNavigateSupportChat: () => void;
}

const SecuritySafetyScreen: React.FC<SecuritySafetyScreenProps> = ({ profile, onUpdate, onBack, onNavigateSupportChat }) => {
  const [isExiting, setIsExiting] = useState(false);
  const [contacts, setContacts] = useState<string[]>(profile.emergencyContacts || []);
  const [activeToolboxTip, setActiveToolboxTip] = useState<string | null>(null);
  const [isTestFiring, setIsTestFiring] = useState(false);
  const [testStage, setTestStage] = useState<'idle' | 'gps' | 'dispatching'>('idle');
  const [preferredChannel, setPreferredChannel] = useState<'whatsapp' | 'sms' | 'both'>('whatsapp');
  const [dispatchResult, setDispatchResult] = useState<PanicDispatchResult | null>(null);
  const [copiedText, setCopiedText] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  const colors = {
    navy: '#1B263B',
    gold: '#D4AF37',
    rose: '#F43F5E',
    emerald: '#10B981',
    slate: '#64748B'
  };

  const handleBack = () => {
    setIsExiting(true);
    setTimeout(onBack, 300);
  };

  const handleAddContact = () => {
    if (contacts.length < 3) {
      const updated = [...contacts, ''];
      setContacts(updated);
      setValidationError(null);
    }
  };

  const handleUpdateContact = (index: number, val: string) => {
    const updated = [...contacts];
    updated[index] = val;
    setContacts(updated);
    onUpdate({ emergencyContacts: updated });
    setValidationError(null);
  };

  const handleRemoveContact = (index: number) => {
    const updated = contacts.filter((_, i) => i !== index);
    setContacts(updated);
    onUpdate({ emergencyContacts: updated });
    setValidationError(null);
  };

  const handleQuickAddUserPhone = () => {
    const phoneToAdd = profile.phone || '+27 82 123 4567';
    if (!contacts.includes(phoneToAdd)) {
      const updated = [...contacts.filter(c => c.trim().length > 0), phoneToAdd].slice(0, 3);
      setContacts(updated);
      onUpdate({ emergencyContacts: updated });
      setValidationError(null);
    }
  };

  const handleTestPanic = async () => {
    const validContacts = contacts.map(c => c.trim()).filter(c => c.length >= 6);

    if (validContacts.length === 0) {
      setValidationError("Please enter at least one valid emergency contact phone number before testing the panic alert.");
      return;
    }

    setValidationError(null);
    setIsTestFiring(true);
    setTestStage('gps');

    try {
      // Step 1: Resolve high-precision GPS coordinates
      setTestStage('gps');
      const result = await preparePanicDispatch(profile.fullName, validContacts);
      
      // Step 2: Prepare dispatch package
      setTestStage('dispatching');
      await new Promise(r => setTimeout(r, 600));

      setDispatchResult(result);
      setIsTestFiring(false);
      setTestStage('idle');

      // Step 3: Trigger the primary channel for the primary emergency contact immediately
      if (result.contacts.length > 0) {
        const primary = result.contacts[0];
        if (preferredChannel === 'whatsapp' || preferredChannel === 'both') {
          triggerChannelLaunch('whatsapp', primary);
        } else if (preferredChannel === 'sms') {
          triggerChannelLaunch('sms', primary);
        }
      }
    } catch (err) {
      console.error("Test panic error:", err);
      setIsTestFiring(false);
      setTestStage('idle');
      alert("Unable to complete panic dispatch test. Please verify location permissions.");
    }
  };

  const handleCopyMessage = () => {
    if (dispatchResult?.message) {
      navigator.clipboard.writeText(dispatchResult.message);
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2500);
    }
  };

  const handleBroadcastAll = (channel: 'whatsapp' | 'sms') => {
    if (!dispatchResult) return;
    dispatchResult.contacts.forEach((contact, idx) => {
      setTimeout(() => {
        triggerChannelLaunch(channel, contact);
      }, idx * 500);
    });
  };

  const safetyTips = {
    'PublicPlaces': {
      title: 'Safe Meeting Spots',
      content: 'Always arrange your first meeting for a gig in high-traffic, public areas like shopping malls (e.g., Sandton City or Gateway) or petrol stations with CCTV. Never meet in isolated areas after dark. Let a friend know exactly where you are going.'
    },
    'Loadshedding': {
      title: 'Loadshedding Awareness',
      content: 'Schedule jobs during daylight hours to ensure safety and visibility. Always check the EskomSePush app for the latest schedule to avoid working in the dark or getting stuck in traffic. Carry a charged power bank at all times.'
    },
    'Verification': {
      title: 'Verification Check',
      content: 'Only work with users who have a "Verified ID" badge and a 4+ star rating. Check their history and read recent comments. SwiftHustle profiles are linked to SA ID numbers for your protection. If a profile seems too new for a high-value gig, proceed with caution.'
    },
    'Escrow': {
      title: 'How our Escrow protects you',
      content: 'Never accept direct cash or EFT payments outside the platform. Our Escrow system ensures the employer has the funds before you start, and ensures you get paid as soon as the work is approved. If there is a dispute, our SA-based support team steps in.'
    }
  };

  return (
    <div className={`flex flex-col h-full bg-[#FAFBFC] transition-transform duration-300 ${isExiting ? 'translate-x-full' : 'translate-x-0'}`}>
      <header className="bg-[#1B263B] p-4 pb-8 relative overflow-hidden shrink-0 shadow-lg">
        <div className="flex items-center gap-4 relative z-10">
          <button 
            onClick={handleBack}
            className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center text-white active:scale-90 transition-all border border-white/5"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M11 17l-5-5m0 0l5-5m-5 5h12"/></svg>
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-black text-white tracking-tight">Security & Safety</h1>
            <p className="text-white/40 text-[9px] font-black uppercase tracking-widest mt-1">Guardian Protocol Active</p>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#F43F5E]/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
      </header>

      <div className="flex-1 overflow-y-auto px-6 mt-6 no-scrollbar pb-32">
        {/* AI Support Button */}
        <section className="mb-8">
           <button 
            onClick={onNavigateSupportChat}
            className="w-full relative group overflow-hidden bg-gradient-to-br from-[#1B263B] to-slate-900 rounded-[32px] p-6 text-white shadow-2xl transition-all active:scale-95 border border-white/5"
           >
             <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4AF37]/10 rounded-full -mr-16 -mt-16 blur-2xl group-hover:bg-[#D4AF37]/20 transition-all"></div>
             <div className="flex items-center gap-5 relative z-10">
               <div className="w-14 h-14 bg-gradient-to-tr from-[#D4AF37] to-amber-200 text-slate-900 rounded-2xl flex items-center justify-center text-2xl border border-white/20 shadow-inner group-hover:scale-110 transition-transform">
                 ⚡
               </div>
               <div className="text-left">
                 <h3 className="text-lg font-black tracking-tight mb-0.5">Chat with Swifty</h3>
                 <p className="text-[10px] font-black text-[#D4AF37] uppercase tracking-[0.2em]">24/7 Smart AI &amp; Safety Assistant</p>
               </div>
               <div className="ml-auto">
                 <svg className="w-6 h-6 text-white/30 group-hover:text-[#D4AF37] transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7"/></svg>
               </div>
             </div>
           </button>
        </section>

        {/* Task 2: Emergency Contacts Section */}
        <section className="bg-white rounded-[40px] p-8 shadow-xl shadow-slate-200/50 border border-slate-50 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Emergency Contacts</h3>
              <p className="text-xs text-slate-600 font-semibold mt-0.5">Recipients for emergency WhatsApp & SMS alerts</p>
            </div>
            <span className="text-[10px] font-black text-[#1B263B] bg-slate-100 px-2.5 py-1 rounded-lg">
              {contacts.filter(c => c.trim().length > 0).length}/3
            </span>
          </div>

          {/* Preferred Dispatch Channel Selector */}
          <div className="bg-slate-50 p-3.5 rounded-2xl mb-5 border border-slate-100">
            <div className="flex items-center justify-between mb-2">
              <label className="text-[9px] font-black uppercase tracking-wider text-slate-400">
                Preferred Alert Channel
              </label>
              <span className="text-[9px] font-black text-[#D4AF37] uppercase tracking-wider">
                Automatic Dispatch
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setPreferredChannel('whatsapp')}
                className={`py-2 px-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                  preferredChannel === 'whatsapp'
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>📲</span> WhatsApp
              </button>
              <button
                type="button"
                onClick={() => setPreferredChannel('sms')}
                className={`py-2 px-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                  preferredChannel === 'sms'
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>💬</span> SMS
              </button>
              <button
                type="button"
                onClick={() => setPreferredChannel('both')}
                className={`py-2 px-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                  preferredChannel === 'both'
                    ? 'bg-[#1B263B] text-white shadow-md shadow-[#1B263B]/20'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>⚡</span> Both
              </button>
            </div>
          </div>

          <div className="space-y-4 mb-5">
            {contacts.map((contact, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="flex-1 bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3 flex items-center gap-3 focus-within:border-[#1B263B] transition-colors">
                  <span className="text-sm">🇿🇦</span>
                  <input 
                    type="tel" 
                    placeholder="e.g. 082 123 4567 or +27..."
                    className="bg-transparent border-none outline-none text-sm font-bold text-[#1B263B] w-full"
                    value={contact}
                    onChange={(e) => handleUpdateContact(i, e.target.value)}
                  />
                </div>
                <button 
                  onClick={() => handleRemoveContact(i)}
                  className="w-10 h-10 rounded-xl bg-rose-50 text-rose-500 hover:bg-rose-100 flex items-center justify-center active:scale-90 transition-all"
                  title="Remove contact"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
              </div>
            ))}
            
            {contacts.length < 3 && (
              <div className="flex gap-2">
                <button 
                  onClick={handleAddContact}
                  className="flex-1 py-3.5 border-2 border-dashed border-slate-200 rounded-2xl text-[9px] font-black uppercase tracking-widest text-slate-500 flex items-center justify-center gap-2 hover:bg-slate-50 transition-all active:scale-98"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 4v16m8-8H4"/></svg>
                  Add Contact Number
                </button>

                {contacts.filter(c => c.trim().length > 0).length === 0 && (
                  <button
                    onClick={handleQuickAddUserPhone}
                    className="px-4 py-3.5 bg-amber-50 text-amber-800 border border-amber-200 rounded-2xl text-[9px] font-black uppercase tracking-wider hover:bg-amber-100 transition-all"
                    title="Add your verified phone number"
                  >
                    Use My Number
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Validation Error Banner */}
          {validationError && (
            <div className="p-3 mb-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-rose-700 text-xs font-semibold">
              <span className="text-base">⚠️</span>
              <p className="flex-1">{validationError}</p>
            </div>
          )}

          {/* Test Panic Alert Button */}
          <button 
            onClick={handleTestPanic}
            disabled={isTestFiring}
            className={`w-full py-4 rounded-2xl font-black text-xs uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3
              ${isTestFiring ? 'bg-slate-100 text-slate-400' : 'bg-[#F43F5E] hover:bg-[#e11d48] text-white shadow-lg shadow-rose-500/25 active:scale-95'}
            `}
          >
            {isTestFiring ? (
              <div className="flex items-center gap-2.5">
                <div className="w-4 h-4 border-2 border-slate-300 border-t-rose-500 rounded-full animate-spin"></div>
                <span>
                  {testStage === 'gps' ? 'Acquiring GPS Coordinates...' : 'Launching SOS Dispatch...'}
                </span>
              </div>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                <span>Test Panic Alert (SMS & WhatsApp)</span>
              </>
            )}
          </button>
          <p className="text-[10px] text-slate-400 text-center font-medium mt-2.5">
            Sends: &quot;I&apos;m in danger &amp; the location&quot; directly to emergency contacts.
          </p>
        </section>

        {/* Task 3: Safety Toolbox Section */}
        <section className="mb-8">
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-4 px-2">Safety Toolbox</h3>
          <div className="space-y-3">
            <button 
              onClick={() => setActiveToolboxTip('PublicPlaces')}
              className="w-full bg-white rounded-3xl p-5 flex items-center justify-between shadow-sm border border-slate-50 group hover:border-[#D4AF37]/30 transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                </div>
                <span className="text-sm font-bold text-[#1B263B]">Safe Meeting Spots</span>
              </div>
              <svg className="w-4 h-4 text-slate-200 group-hover:text-[#D4AF37]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M9 5l7 7-7 7"/></svg>
            </button>

            <button 
              onClick={() => setActiveToolboxTip('Loadshedding')}
              className="w-full bg-white rounded-3xl p-5 flex items-center justify-between shadow-sm border border-slate-50 group hover:border-[#D4AF37]/30 transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-slate-50 text-slate-500 flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                </div>
                <span className="text-sm font-bold text-[#1B263B]">Loadshedding Awareness</span>
              </div>
              <svg className="w-4 h-4 text-slate-200 group-hover:text-[#D4AF37]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M9 5l7 7-7 7"/></svg>
            </button>

            <button 
              onClick={() => setActiveToolboxTip('Verification')}
              className="w-full bg-white rounded-3xl p-5 flex items-center justify-between shadow-sm border border-slate-50 group hover:border-[#D4AF37]/30 transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-500 flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                </div>
                <span className="text-sm font-bold text-[#1B263B]">Verification Check</span>
              </div>
              <svg className="w-4 h-4 text-slate-200 group-hover:text-[#D4AF37]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M9 5l7 7-7 7"/></svg>
            </button>

            <button 
              onClick={() => setActiveToolboxTip('Escrow')}
              className="w-full bg-white rounded-3xl p-5 flex items-center justify-between shadow-sm border border-slate-50 group hover:border-[#D4AF37]/30 transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-500 flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                </div>
                <span className="text-sm font-bold text-[#1B263B]">How our Escrow protects you</span>
              </div>
              <svg className="w-4 h-4 text-slate-200 group-hover:text-[#D4AF37]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M9 5l7 7-7 7"/></svg>
            </button>
          </div>
        </section>

        {/* Local Support */}
        <div className="bg-slate-900 rounded-[40px] p-8 text-white shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full -mr-12 -mt-12 blur-2xl"></div>
          <h4 className="text-sm font-black mb-1 uppercase tracking-widest">24/7 Support</h4>
          <p className="text-[10px] text-white/50 leading-relaxed font-medium mb-6">
            In case of any safety concerns during a gig, our dedicated South African trust & safety team is available 24/7 via the help center.
          </p>
          <button className="w-full py-4 bg-white/10 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] hover:bg-white/20 transition-all">Contact Safety Team</button>
        </div>
      </div>

      {/* Safety Tip Overlay */}
      {activeToolboxTip && (
        <div className="fixed inset-0 z-[6000] bg-black/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-sm rounded-[48px] p-10 shadow-2xl relative overflow-hidden animate-in zoom-in duration-400">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4AF37]/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
            
            <div className="w-16 h-16 bg-[#1B263B]/5 rounded-2xl flex items-center justify-center mb-6">
              <svg className="w-8 h-8 text-[#1B263B]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
            
            <h2 className="text-2xl font-black text-[#1B263B] mb-4 tracking-tight leading-tight">
              {safetyTips[activeToolboxTip as keyof typeof safetyTips].title}
            </h2>
            
            <p className="text-sm text-slate-500 font-medium leading-relaxed mb-10">
              {safetyTips[activeToolboxTip as keyof typeof safetyTips].content}
            </p>
            
            <button 
              onClick={() => setActiveToolboxTip(null)}
              className="w-full py-5 bg-[#1B263B] text-white font-black text-xs uppercase tracking-[0.4em] rounded-[24px] shadow-2xl active:scale-95 transition-all"
            >
              I Understand
            </button>
          </div>
        </div>
      )}

      {/* Emergency Dispatch Result Modal */}
      {dispatchResult && (
        <div className="fixed inset-0 z-[6500] bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-6 animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-t-[36px] sm:rounded-[36px] max-h-[90vh] flex flex-col shadow-2xl relative overflow-hidden animate-in slide-in-from-bottom duration-300 border border-slate-100">
            {/* Top Alert Header */}
            <div className="bg-gradient-to-r from-rose-600 via-rose-700 to-[#1B263B] p-6 text-white shrink-0 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
              <div className="flex items-center justify-between relative z-10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center border border-white/20 animate-pulse text-xl">
                    🚨
                  </div>
                  <div>
                    <span className="text-[9px] font-black uppercase tracking-[0.25em] text-rose-200 block">
                      Emergency Alert Dispatched
                    </span>
                    <h3 className="text-base font-black tracking-tight text-white">
                      Panic Alert (Test Mode)
                    </h3>
                  </div>
                </div>
                <button
                  onClick={() => setDispatchResult(null)}
                  className="w-9 h-9 rounded-xl bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition-colors"
                  title="Close alert preview"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
              </div>
            </div>

            {/* Scrollable Body */}
            <div className="p-6 overflow-y-auto space-y-5">
              {/* Location Badge */}
              <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">
                      Location Acquired
                    </span>
                  </div>
                  <a
                    href={dispatchResult.mapUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] font-black text-blue-600 hover:text-blue-800 uppercase tracking-wider flex items-center gap-1"
                  >
                    Open Map ↗
                  </a>
                </div>
                <p className="text-xs font-bold text-slate-800">
                  {dispatchResult.locationDescription}
                </p>
                <p className="text-[11px] font-mono text-slate-500 mt-1">
                  GPS: {dispatchResult.latitude.toFixed(6)}, {dispatchResult.longitude.toFixed(6)}
                </p>
              </div>

              {/* Message Payload Preview */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                    Emergency Message Sent
                  </label>
                  <button
                    onClick={handleCopyMessage}
                    className="text-[10px] font-black text-[#1B263B] bg-slate-100 hover:bg-slate-200 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1"
                  >
                    {copiedText ? '✓ Copied' : '📋 Copy Text'}
                  </button>
                </div>
                <div className="bg-slate-900 text-white p-4 rounded-2xl text-xs font-medium leading-relaxed border border-slate-800">
                  <span className="text-rose-400 font-bold block mb-1">
                    &quot;I&apos;m in danger &amp; the location&quot;
                  </span>
                  <p className="text-slate-200 break-words">
                    {dispatchResult.message}
                  </p>
                </div>
              </div>

              {/* Emergency Contacts Dispatch Action Cards */}
              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block mb-2.5">
                  Send Directly to Contacts ({dispatchResult.contacts.length})
                </label>
                <div className="space-y-3">
                  {dispatchResult.contacts.map((contact, idx) => (
                    <div
                      key={idx}
                      className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-sm space-y-2.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-black text-slate-800 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center text-[10px]">
                            {idx + 1}
                          </span>
                          {contact.raw}
                        </span>
                        <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
                          Ready to Send
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        {/* WhatsApp Action Button */}
                        <button
                          type="button"
                          onClick={() => triggerChannelLaunch('whatsapp', contact)}
                          className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all active:scale-95"
                        >
                          <span>📲</span>
                          <span>WhatsApp</span>
                        </button>

                        {/* SMS Action Button */}
                        <button
                          type="button"
                          onClick={() => triggerChannelLaunch('sms', contact)}
                          className="py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all active:scale-95"
                        >
                          <span>💬</span>
                          <span>SMS</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Broadcast to All (if multiple contacts) */}
              {dispatchResult.contacts.length > 1 && (
                <div className="pt-1 flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleBroadcastAll('whatsapp')}
                    className="flex-1 py-3 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-2xl text-[10px] font-black uppercase tracking-wider hover:bg-emerald-100 transition-all flex items-center justify-center gap-1.5"
                  >
                    <span>📲</span> All via WhatsApp
                  </button>
                  <button
                    type="button"
                    onClick={() => handleBroadcastAll('sms')}
                    className="flex-1 py-3 bg-blue-50 text-blue-800 border border-blue-200 rounded-2xl text-[10px] font-black uppercase tracking-wider hover:bg-blue-100 transition-all flex items-center justify-center gap-1.5"
                  >
                    <span>💬</span> All via SMS
                  </button>
                </div>
              )}

              {/* Armed Response / SAPS Notice */}
              <div className="bg-amber-50 border border-amber-200/80 rounded-2xl p-3.5 flex items-start gap-3 text-amber-900">
                <span className="text-base mt-0.5">🛡️</span>
                <p className="text-[11px] leading-relaxed font-medium">
                  <strong>Live Emergency Mode:</strong> In an active emergency during a job, triggering SOS sends this alert and dispatches nearest security response partners to your coordinates.
                </p>
              </div>
            </div>

            {/* Modal Bottom Actions */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setDispatchResult(null)}
                className="w-full py-3.5 bg-[#1B263B] text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg active:scale-95 transition-all"
              >
                Close &amp; Return
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SecuritySafetyScreen;
