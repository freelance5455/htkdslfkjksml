
import React, { useEffect } from 'react';

interface AchievementOverlayProps {
  onClose: () => void;
}

const AchievementOverlay: React.FC<AchievementOverlayProps> = ({ onClose }) => {
  useEffect(() => {
    // Task 4: Haptic Feedback (Web Vibration API)
    if ('vibrate' in navigator) {
      navigator.vibrate([100, 50, 200]);
    }
    
    // Play success sound (Simulated or via Audio object if needed)
    // const audio = new Audio('/success-chime.mp3');
    // audio.play().catch(() => {});
  }, []);

  return (
    <div className="fixed inset-0 z-[12000] bg-[#1B263B]/95 backdrop-blur-xl flex items-center justify-center p-8 animate-in fade-in duration-500">
      {/* Background Particle Effects (CSS only) */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(12)].map((_, i) => (
          <div 
            key={i} 
            className="absolute bg-[#D4AF37]/20 rounded-full animate-pulse"
            style={{
              width: Math.random() * 100 + 50 + 'px',
              height: Math.random() * 100 + 50 + 'px',
              top: Math.random() * 100 + '%',
              left: Math.random() * 100 + '%',
              animationDelay: i * 0.5 + 's',
              animationDuration: Math.random() * 3 + 2 + 's'
            }}
          ></div>
        ))}
      </div>

      <div className="relative z-10 w-full max-w-sm text-center animate-in zoom-in slide-in-from-bottom-12 duration-700">
        {/* Task 2: Centerpiece - Gold Bolt Icon */}
        <div className="relative mb-8">
          <div className="w-32 h-32 bg-[#D4AF37] rounded-[40px] flex items-center justify-center mx-auto shadow-[0_0_50px_rgba(212,175,55,0.4)] animate-bounce duration-1000">
             <svg className="w-16 h-16 text-white" fill="currentColor" viewBox="0 0 24 24">
               <path d="M13 10V3L4 14h7v7l9-11h-7z" />
             </svg>
          </div>
          {/* Decorative Rings */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 border-2 border-[#D4AF37]/30 rounded-full animate-ping duration-[2000ms]"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 border border-[#D4AF37]/20 rounded-full animate-pulse"></div>
        </div>

        {/* Headline */}
        <h1 className="text-3xl font-black text-[#D4AF37] mb-4 tracking-tighter uppercase leading-none italic">
          INSTANT PAYOUTS UNLOCKED!
        </h1>

        {/* Sub-headline */}
        <p className="text-white/80 text-sm font-medium leading-relaxed mb-12 px-2">
          Congratulations! You are now a <span className="text-white font-black underline decoration-[#D4AF37]">Trusted Employer</span>. 
          You can now release funds to Hustlers instantly via PayShap & RTC clearing rails.
        </p>

        {/* Action Button */}
        <button 
          onClick={onClose}
          className="w-full py-6 bg-[#10B981] text-white rounded-[32px] font-black text-sm uppercase tracking-[0.4em] shadow-2xl shadow-emerald-500/20 active:scale-95 transition-all"
        >
          Let's Go!
        </button>

        <p className="mt-8 text-[10px] font-black text-white/30 uppercase tracking-[0.6em]">Achievement Sync Complete</p>
      </div>
    </div>
  );
};

export default AchievementOverlay;
