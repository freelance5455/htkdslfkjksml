
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { UserProfile, VerificationStatus, StructuredAddress } from '../types';

interface PersonalInformationPageProps {
  profile: UserProfile | null;
  onUpdate: (updates: Partial<UserProfile>) => void;
  onBack: () => void;
}

const PROVINCES = [
  'Gauteng',
  'Western Cape',
  'KwaZulu-Natal',
  'Eastern Cape',
  'Free State',
  'Limpopo',
  'Mpumalanga',
  'North West',
  'Northern Cape'
];

// Task 4: SA Postal Code Ranges Mapping
const POSTAL_CODE_RANGES: Record<string, [number, number][]> = {
  'Gauteng': [[0, 299], [1400, 2199]],
  'Western Cape': [[6500, 8099]],
  'KwaZulu-Natal': [[3200, 4099]],
  'Eastern Cape': [[4700, 6499]],
  'Free State': [[9300, 9999]],
  'Limpopo': [[0, 999]],
  'Mpumalanga': [[1000, 1399]],
  'North West': [[2500, 2899]],
  'Northern Cape': [[8100, 8999]]
};

const validatePostalCode = (code: string, province: string): boolean => {
  const numericCode = parseInt(code);
  if (isNaN(numericCode) || code.length !== 4) return false;
  const ranges = POSTAL_CODE_RANGES[province];
  if (!ranges) return true;
  return ranges.some(([min, max]) => numericCode >= min && numericCode <= max);
};

// Validation Helpers
const validateSAID = (id: string) => /^\d{13}$/.test(id);
const validateSAPhone = (phone: string) => /^((\+27)|0)\d{9}$/.test(phone.replace(/\s/g, ''));

const PersonalInformationPage: React.FC<PersonalInformationPageProps> = ({ profile, onUpdate, onBack }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [isExiting, setIsExiting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Form State
  const [fullName, setFullName] = useState(profile?.fullName || '');
  const [idNumber, setIdNumber] = useState(profile?.idNumber || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [email, setEmail] = useState(profile?.email || '');
  
  // Structured Address State
  const initialAddress = typeof profile?.address === 'object' ? profile.address : {
    street: '', suburb: '', city: '', province: 'Gauteng', postalCode: ''
  };
  const [addressDraft, setAddressDraft] = useState<StructuredAddress>(initialAddress);
  const [isGeocoding, setIsGeocoding] = useState(false);

  // Verification State
  const [activeVerification, setActiveVerification] = useState<'id' | 'selfie' | 'residence' | null>(null);
  const [idStep, setIdStep] = useState<1 | 2>(1);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const colors = {
    gold: '#D4AF37', // SwiftHustle Gold
    navy: '#1B263B',
    emerald: '#10B981',
    amber: '#F59E0B',
    rose: '#F43F5E',
    white: '#FFFFFF',
    slate: '#64748B'
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  // Task 2: Smart Save Logic
  const isPostalValid = useMemo(() => {
    if (!addressDraft.postalCode) return true;
    return validatePostalCode(addressDraft.postalCode, addressDraft.province);
  }, [addressDraft.postalCode, addressDraft.province]);

  const isFormValid = useMemo(() => {
    const isNameValid = fullName.trim().length > 2;
    const isIDValid = validateSAID(idNumber);
    const isPhoneValid = validateSAPhone(phone);
    const isAddressValid = 
      addressDraft.street.length > 2 && 
      addressDraft.suburb.length > 2 && 
      addressDraft.city.length > 2 && 
      addressDraft.postalCode.length === 4 && 
      isPostalValid;

    return isNameValid && isIDValid && isPhoneValid && isAddressValid;
  }, [fullName, idNumber, phone, addressDraft, isPostalValid]);

  const handleBack = () => {
    setIsExiting(true);
    setTimeout(onBack, 300);
  };

  // Task 1 & 4: Firestore Update simulation with auto-nav
  const handleSaveAll = async () => {
    if (!isFormValid || isSaving) return;
    setIsSaving(true);
    
    try {
      // Simulate Firestore/Auth sync: 
      // await FirebaseFirestore.instance.collection('users').doc(userId).update({...})
      // await FirebaseAuth.instance.currentUser.updateDisplayName(fullName)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      onUpdate({
        fullName,
        idNumber,
        phone,
        email,
        address: addressDraft
      });
      
      setSaveSuccess(true);
      setIsSaving(false);

      // Auto-navigate back to Account Tab after success
      setTimeout(() => {
        handleBack();
      }, 1500);
      
    } catch (err) {
      console.error("Profile update failed", err);
      setIsSaving(false);
      alert('Sync failed. Please check your connection.');
    }
  };

  const handleUseLocation = () => {
    if (!navigator.geolocation) return;
    setIsGeocoding(true);
    navigator.geolocation.getCurrentPosition(async (pos) => {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setAddressDraft({
        street: '123 Rivonia Road',
        suburb: 'Morningside',
        city: 'Sandton',
        province: 'Gauteng',
        postalCode: '2196'
      });
      setIsGeocoding(false);
    }, () => setIsGeocoding(false));
  };

  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeVerification) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      if (activeVerification === 'id') {
        if (idStep === 1) {
          onUpdate({ verificationDocs: { ...profile?.verificationDocs, idFront: base64 } });
          setIdStep(2);
        } else {
          onUpdate({ 
            verificationDocs: { ...profile?.verificationDocs, idBack: base64 },
            verification: { ...profile!.verification, identity: 'pending' }
          });
          setActiveVerification(null);
        }
      } else if (activeVerification === 'selfie') {
        onUpdate({ 
          verificationDocs: { ...profile?.verificationDocs, selfie: base64 },
          verification: { ...profile!.verification, facial: 'pending' }
        });
        setActiveVerification(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const StatusBadge = ({ label, status, icon, onClick }: { label: string; status: VerificationStatus; icon: string; onClick: () => void }) => {
    const isVerified = status === 'verified';
    const isPending = status === 'pending';
    return (
      <button 
        disabled={isVerified || isPending}
        onClick={onClick}
        className={`flex flex-col items-center flex-1 p-4 rounded-3xl border-2 transition-all active:scale-95
          ${isVerified ? 'border-[#D4AF37]/20 bg-amber-50/30' : 'border-slate-50 bg-white shadow-sm'}
          ${isPending ? 'opacity-70 grayscale' : ''}
        `}
      >
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3 shadow-inner relative" style={{ backgroundColor: isVerified ? '#D4AF37' : '#F8FAFC' }}>
          {isVerified ? <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 01.414 0z" clipRule="evenodd"/></svg> : <span className="text-xl">{icon}</span>}
          {isPending && <div className="absolute inset-0 flex items-center justify-center bg-white/60 rounded-2xl"><div className="w-5 h-5 border-2 border-amber-500 border-t-transparent rounded-full animate-spin"></div></div>}
        </div>
        <span className={`text-[8px] font-black uppercase tracking-widest mb-1 ${isVerified ? 'text-[#D4AF37]' : 'text-slate-400'}`}>{label}</span>
      </button>
    );
  };

  if (isLoading) return <div className="flex flex-col h-full bg-white items-center justify-center"><div className="w-12 h-12 border-4 border-slate-100 border-t-navy rounded-full animate-spin mb-4"></div></div>;

  return (
    <div className={`flex flex-col h-full bg-[#FAFBFC] transition-transform duration-300 ${isExiting ? 'translate-x-full' : 'translate-x-0'}`}>
      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" capture={activeVerification === 'selfie' ? 'user' : 'environment'} onChange={handlePhotoCapture} />
      
      {/* Header with Gold background and Navy foreground as per task */}
      <header className="bg-[#D4AF37] p-4 pb-8 relative overflow-hidden shrink-0 shadow-sm border-b border-[#B8860B]/20">
        <div className="flex items-center gap-4 relative z-10">
          <button 
            onClick={handleBack} 
            className="w-12 h-12 rounded-2xl bg-black/5 flex items-center justify-center text-[#1B263B] active:scale-90 transition-all border border-black/5"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M11 17l-5-5m0 0l5-5m-5 5h12"/></svg>
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-black text-[#1B263B] tracking-tight uppercase">Profile Verification</h1>
            <p className="text-[#1B263B]/60 text-[9px] font-black uppercase tracking-widest mt-1">Identity Trust Protocol</p>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/20 rounded-full -mr-16 -mt-16 blur-3xl"></div>
      </header>

      <div className="flex-1 overflow-y-auto px-6 mt-6 no-scrollbar pb-40">
        {/* Success Overlay Task 4 */}
        {saveSuccess && (
          <div className="bg-emerald-600 rounded-3xl p-4 mb-6 text-white flex items-center gap-4 animate-in slide-in-from-top duration-500 shadow-lg shadow-emerald-500/20">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"/></svg>
            </div>
            <div>
               <p className="text-[10px] font-black uppercase tracking-widest">Profile Sync Successful</p>
               <p className="text-[8px] font-bold opacity-70">Updating global credentials...</p>
            </div>
          </div>
        )}

        <div className="bg-white rounded-[40px] p-6 shadow-xl shadow-slate-200/50 border border-slate-50 mb-8">
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-5 px-2">Identity Trust Tiers</h3>
          <div className="flex justify-between gap-3">
            <StatusBadge label="ID Book" status={profile?.verification.identity || 'unverified'} icon="🪪" onClick={() => setActiveVerification('id')} />
            <StatusBadge label="Live Selfie" status={profile?.verification.facial || 'unverified'} icon="🤳" onClick={() => setActiveVerification('selfie')} />
            <StatusBadge label="Residence" status={profile?.verification.address || 'unverified'} icon="🏠" onClick={() => setActiveVerification('residence')} />
          </div>
        </div>

        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-4 px-2">Legal Profile</h3>
        <div className="space-y-4 mb-8">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-50">
            <label className="block text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1.5 ml-1">Full Legal Name</label>
            <input 
              className="w-full bg-transparent text-sm font-bold text-slate-800 outline-none focus:text-navy transition-all"
              value={fullName}
              onChange={e => setFullName(e.target.value)}
              placeholder="As per SA ID Document"
            />
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-50">
            <label className="block text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1.5 ml-1">South African ID Number</label>
            <input 
              maxLength={13}
              className="w-full bg-transparent text-sm font-bold text-slate-800 outline-none focus:text-navy transition-all"
              value={idNumber}
              onChange={e => setIdNumber(e.target.value.replace(/\D/g, ''))}
              placeholder="13-digit number"
            />
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-50">
            <label className="block text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1.5 ml-1">Cellphone Number</label>
            <input 
              type="tel"
              className="w-full bg-transparent text-sm font-bold text-slate-800 outline-none focus:text-navy transition-all"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="+27..."
            />
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-50">
            <label className="block text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1.5 ml-1">Email Address</label>
            <input 
              type="email"
              className="w-full bg-transparent text-sm font-bold text-slate-800 outline-none focus:text-navy transition-all"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="your@email.com"
            />
          </div>
        </div>

        <div className="flex items-center justify-between mb-4 px-2">
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Physical Residency</h3>
          <button 
            onClick={handleUseLocation}
            className="flex items-center gap-1.5 text-[9px] font-black text-[#D4AF37] uppercase tracking-widest"
          >
            {isGeocoding ? 'Detecting...' : 'Use GPS'}
          </button>
        </div>

        <div className="bg-white rounded-[40px] p-8 shadow-sm border border-slate-50 space-y-5">
           <div className="border-b border-slate-50 pb-4">
              <label className="block text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1.5 ml-1">Street Address</label>
              <input 
                className="w-full bg-transparent text-sm font-bold text-slate-800 outline-none"
                value={addressDraft.street}
                onChange={e => setAddressDraft({...addressDraft, street: e.target.value})}
                placeholder="123 Example Street"
              />
           </div>
           
           <div className="grid grid-cols-2 gap-4 border-b border-slate-50 pb-4">
             <div>
                <label className="block text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1.5 ml-1">Suburb</label>
                <input 
                  className="w-full bg-transparent text-sm font-bold text-slate-800 outline-none"
                  value={addressDraft.suburb}
                  onChange={e => setAddressDraft({...addressDraft, suburb: e.target.value})}
                  placeholder="Suburb"
                />
             </div>
             <div>
                <label className="block text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1.5 ml-1">City</label>
                <input 
                  className="w-full bg-transparent text-sm font-bold text-slate-800 outline-none"
                  value={addressDraft.city}
                  onChange={e => setAddressDraft({...addressDraft, city: e.target.value})}
                  placeholder="City"
                />
             </div>
           </div>

           <div className="border-b border-slate-50 pb-4">
              <label className="block text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1.5 ml-1">Province</label>
              <select 
                className="w-full bg-transparent text-sm font-bold text-slate-800 outline-none appearance-none"
                value={addressDraft.province}
                onChange={e => setAddressDraft({...addressDraft, province: e.target.value})}
              >
                {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
           </div>

           <div>
              <label className="block text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1.5 ml-1">Postal Code (4 Digits)</label>
              <input 
                maxLength={4}
                className={`w-full bg-transparent text-sm font-bold outline-none transition-all ${!isPostalValid ? 'text-rose-500' : 'text-slate-800'}`}
                value={addressDraft.postalCode}
                onChange={e => setAddressDraft({...addressDraft, postalCode: e.target.value.slice(0, 4)})}
                placeholder="0000"
              />
              {!isPostalValid && <p className="text-[8px] font-black text-rose-500 uppercase mt-1">Code mismatch for {addressDraft.province}</p>}
           </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-white/80 backdrop-blur-md border-t border-slate-100 z-20">
        <button 
          disabled={!isFormValid || isSaving || saveSuccess}
          onClick={handleSaveAll}
          className={`w-full py-5 rounded-[24px] font-black text-xs uppercase tracking-[0.4em] shadow-2xl transition-all flex items-center justify-center gap-3
            ${isFormValid && !saveSuccess
              ? 'bg-[#10B981] text-white active:scale-95 shadow-emerald-500/20' 
              : (saveSuccess ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-300 cursor-not-allowed shadow-none')}
          `}
        >
          {isSaving ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            <>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"/></svg>
              {saveSuccess ? 'Profile Synced' : 'Save Information'}
            </>
          )}
        </button>
      </div>

      {activeVerification && (
        <div className="fixed inset-0 z-[6000] bg-navy/95 backdrop-blur-md flex flex-col p-8 animate-in fade-in duration-300">
          <header className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-tight">{activeVerification === 'id' ? `ID Document (${idStep}/2)` : 'Live Selfie'}</h2>
              <p className="text-white/40 text-[10px] font-black uppercase tracking-[0.2em] mt-1">Identity Protocol Active</p>
            </div>
            <button onClick={() => { setActiveVerification(null); setIdStep(1); }} className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-white"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12"/></svg></button>
          </header>
          <div className="flex-1 flex flex-col items-center justify-center text-center">
             <div className="w-full aspect-[4/3] bg-white/5 border-4 border-dashed border-white/10 rounded-[40px] flex flex-col items-center justify-center mb-12 p-8">
               <span className="text-5xl mb-6">{activeVerification === 'id' ? '🪪' : '🤳'}</span>
               <p className="text-white/60 text-xs font-bold leading-relaxed">{activeVerification === 'id' ? (idStep === 1 ? 'Capture the FRONT of your ID' : 'Capture the BACK of your ID') : 'Take a clear live selfie'}</p>
             </div>
             <button onClick={() => fileInputRef.current?.click()} className="w-full py-5 bg-[#D4AF37] text-white rounded-[24px] font-black text-xs uppercase tracking-[0.4em] shadow-2xl active:scale-95 flex items-center justify-center gap-3">Open Camera</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PersonalInformationPage;
