import React, { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Gig, UserStats, AvailableHustler } from '../types';
import { NEARBY_HUSTLERS } from '../data/hustlers';
import PanicButton from './PanicButton';

const SA_CENTER: [number, number] = [-26.1076, 28.0567]; // Focused on Sandton, JHB

// Calculate distance between two coordinates in kilometers using Haversine formula
function calculateDistanceKm(loc1: [number, number], loc2: [number, number]): number {
  const toRad = (x: number) => (x * Math.PI) / 180;
  const R = 6371; // Earth radius in km
  const dLat = toRad(loc2[0] - loc1[0]);
  const dLon = toRad(loc2[1] - loc1[1]);
  const lat1 = toRad(loc1[0]);
  const lat2 = toRad(loc2[0]);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return parseFloat((R * c).toFixed(1));
}

const createIcon = (color: string) => new L.Icon({
  iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const clientIcon = createIcon('blue');
const featuredIcon = createIcon('gold');
const occupiedJobIcon = createIcon('orange');

const userIcon = new L.DivIcon({
  className: 'custom-div-icon',
  html: `<div class="relative flex items-center justify-center">
          <div class="absolute w-8 h-8 bg-[#50C878] rounded-full animate-ping opacity-20"></div>
          <div class="absolute w-12 h-12 border border-[#50C878] rounded-full animate-pulse opacity-10"></div>
          <div class="relative w-4 h-4 bg-[#50C878] rounded-full border-2 border-white shadow-xl"></div>
         </div>`,
  iconSize: [32, 32],
  iconAnchor: [16, 16]
});

const createHustlerDivIcon = (avatarUrl: string, isVerified: boolean, isWorking: boolean = false) => new L.DivIcon({
  className: 'custom-hustler-icon',
  html: `
    <div style="position: relative; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; cursor: pointer;">
      <div style="position: absolute; inset: -3px; background: ${isWorking ? 'rgba(249, 115, 22, 0.4)' : 'rgba(80, 200, 120, 0.3)'}; border-radius: 9999px; animation: pulse 2s infinite;"></div>
      <div style="width: 38px; height: 38px; border-radius: 9999px; border: 2.5px solid ${isWorking ? '#EA580C' : '#1B263B'}; overflow: hidden; background: white; box-shadow: 0 4px 10px rgba(0,0,0,0.25);">
        <img src="${avatarUrl}" style="width: 100%; height: 100%; object-fit: cover;" />
      </div>
      <div style="position: absolute; bottom: 0; right: 0; width: 13px; height: 13px; background: ${isWorking ? '#F97316' : '#50C878'}; border: 2px solid white; border-radius: 9999px; box-shadow: 0 1px 3px rgba(0,0,0,0.3);"></div>
      ${isVerified ? '<div style="position: absolute; top: 0; right: 0; width: 13px; height: 13px; background: #D4AF37; border: 2px solid white; border-radius: 9999px; font-size: 8px; color: white; display: flex; align-items: center; justify-content: center; font-weight: 900;">★</div>' : ''}
    </div>
  `,
  iconSize: [44, 44],
  iconAnchor: [22, 22],
  popupAnchor: [0, -22]
});

// Internal component to handle smooth map centering
const MapUpdater = ({ center, isAutoFollow }: { center: [number, number] | null, isAutoFollow: boolean }) => {
  const map = useMap();
  useEffect(() => {
    if (center && isAutoFollow) {
      map.flyTo(center, map.getZoom(), {
        animate: true,
        duration: 1.5
      });
    }
  }, [center, isAutoFollow, map]);
  return null;
};

interface RadarMapProps {
  isHustler: boolean;
  isAvailable?: boolean;
  isUserVerified?: boolean;
  userStats?: UserStats;
  onToggleAvailability?: (v: boolean) => void;
  onSelectGig?: (gig: Gig) => void;
  onCompleteJob?: (job: { id: string, title: string, price: number }, isInstant: boolean) => void;
  gigs?: Gig[];
  hustlers?: AvailableHustler[];
  onHireHustler?: (hustler: AvailableHustler) => void;
  onChatHustler?: (hustler: AvailableHustler) => void;
  onOpenPushSettings?: () => void;
  onSimulateAlert?: () => void;
  currentHustlerId?: string;
  onSwitchHustlerPersona?: (hustlerId: string) => void;
  hiredHustlerIds?: string[];
}

const RADIUS_PRESETS = [2, 5, 10, 15, 25, 50];

const RadarMap: React.FC<RadarMapProps> = ({ 
  isHustler, 
  isAvailable, 
  isUserVerified,
  userStats, 
  onToggleAvailability, 
  onSelectGig, 
  onCompleteJob,
  gigs = [],
  hustlers = NEARBY_HUSTLERS,
  onHireHustler,
  onChatHustler,
  onOpenPushSettings,
  onSimulateAlert,
  currentHustlerId,
  onSwitchHustlerPersona,
  hiredHustlerIds = []
}) => {
  const [sheetHeight, setSheetHeight] = useState(45); // Height in percentage
  const [userLocation, setUserLocation] = useState<[number, number] | null>(SA_CENTER);
  const [isAutoFollow, setIsAutoFollow] = useState(true);
  const [selectedHustler, setSelectedHustler] = useState<AvailableHustler | null>(null);
  
  // Radius setting state (persisted per role in localStorage)
  const [radiusKm, setRadiusKm] = useState<number>(() => {
    const saved = localStorage.getItem(`sh_radar_radius_${isHustler ? 'hustler' : 'employer'}`);
    return saved ? Math.min(50, Math.max(1, parseInt(saved, 10))) : 10;
  });
  const [isRadiusModalOpen, setIsRadiusModalOpen] = useState(false);

  // Ref for dragging logic
  const isDragging = useRef(false);
  const startY = useRef(0);
  const startHeight = useRef(0);

  const centerPoint = userLocation || SA_CENTER;

  // Real-time Geolocation Watcher
  useEffect(() => {
    let watchId: number;
    if ("geolocation" in navigator) {
      watchId = navigator.geolocation.watchPosition(
        (position) => {
          const newPos: [number, number] = [position.coords.latitude, position.coords.longitude];
          setUserLocation(newPos);
        },
        (error) => console.warn("Geolocation error:", error),
        { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }
      );
    }
    return () => {
      if (watchId) navigator.geolocation.clearWatch(watchId);
    };
  }, []);

  const handleRadiusChange = (newRadius: number) => {
    setRadiusKm(newRadius);
    localStorage.setItem(`sh_radar_radius_${isHustler ? 'hustler' : 'employer'}`, newRadius.toString());
  };

  // Filter Gigs strictly by chosen radius for Hustler Mode
  // If a job is hired/occupied (has gig.hustlerId set):
  // It is NOT visible on the radar for other hustlers, EXCEPT for the occupant / hustler that is hired!
  const visibleGigs = useMemo(() => {
    return gigs
      .map(gig => ({
        ...gig,
        calculatedDistance: calculateDistanceKm(centerPoint, gig.location)
      }))
      .filter(gig => {
        if (gig.calculatedDistance > radiusKm) return false;

        // If the gig has an assigned/hired hustler (occupied):
        if (gig.hustlerId) {
          // ONLY visible to the hired occupant!
          return gig.hustlerId === currentHustlerId;
        }

        // Open unassigned gigs are visible to all hustlers
        return gig.status === 'open';
      })
      .sort((a, b) => a.calculatedDistance - b.calculatedDistance);
  }, [gigs, centerPoint, radiusKm, currentHustlerId]);

  // Count occupied jobs hidden from this hustler's radar within radius
  const hiddenOccupiedCount = useMemo(() => {
    if (!isHustler) return 0;
    return gigs.filter(gig => {
      const dist = calculateDistanceKm(centerPoint, gig.location);
      return dist <= radiusKm && gig.hustlerId && gig.hustlerId !== currentHustlerId;
    }).length;
  }, [gigs, centerPoint, radiusKm, isHustler, currentHustlerId]);

  // Hired occupants for quick persona switching / verification
  const hiredOccupants = useMemo(() => {
    const ids = new Set(gigs.filter(g => g.hustlerId).map(g => g.hustlerId as string));
    return hustlers.filter(h => ids.has(h.id));
  }, [gigs, hustlers]);

  // Filter Hustlers strictly by chosen radius for Employer Mode
  const visibleHustlers = useMemo(() => {
    return hustlers
      .map(hustler => ({
        ...hustler,
        calculatedDistance: calculateDistanceKm(centerPoint, hustler.location)
      }))
      .filter(hustler => hustler.calculatedDistance <= radiusKm)
      .sort((a, b) => a.calculatedDistance - b.calculatedDistance);
  }, [hustlers, centerPoint, radiusKm]);

  // Draggable Bottom Sheet Logic
  const handleDragStart = (e: React.MouseEvent | React.TouchEvent) => {
    isDragging.current = true;
    startY.current = 'touches' in e ? (e as React.TouchEvent).touches[0].clientY : (e as React.MouseEvent).clientY;
    startHeight.current = sheetHeight;
    document.body.style.overflow = 'hidden'; 
  };

  const handleDragMove = useCallback((e: MouseEvent | TouchEvent) => {
    if (!isDragging.current) return;
    
    const currentY = 'touches' in e ? (e as TouchEvent).touches[0].clientY : (e as MouseEvent).clientY;
    const deltaY = startY.current - currentY;
    const windowHeight = window.innerHeight;
    const deltaHeightPercent = (deltaY / windowHeight) * 100;
    
    let newHeight = startHeight.current + deltaHeightPercent;
    
    // Constraints: min 10%, max 90%
    if (newHeight < 10) newHeight = 10;
    if (newHeight > 90) newHeight = 90;
    
    setSheetHeight(newHeight);
  }, [sheetHeight]);

  const handleDragEnd = useCallback(() => {
    if (!isDragging.current) return;
    isDragging.current = false;
    document.body.style.overflow = '';
    
    // Snapping logic (Snaps to 10%, 45%, or 90%)
    if (sheetHeight < 25) setSheetHeight(10);
    else if (sheetHeight < 65) setSheetHeight(45);
    else setSheetHeight(90);
  }, [sheetHeight]);

  useEffect(() => {
    window.addEventListener('mousemove', handleDragMove);
    window.addEventListener('mouseup', handleDragEnd);
    window.addEventListener('touchmove', handleDragMove as any);
    window.addEventListener('touchend', handleDragEnd);
    
    return () => {
      window.removeEventListener('mousemove', handleDragMove);
      window.removeEventListener('mouseup', handleDragEnd);
      window.removeEventListener('touchmove', handleDragMove as any);
      window.removeEventListener('touchend', handleDragEnd);
    };
  }, [handleDragMove, handleDragEnd]);

  const GoldCheck = () => (
    <svg className="w-4 h-4 text-[#D4AF37] shrink-0" fill="currentColor" viewBox="0 0 20 20">
      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"/>
    </svg>
  );

  return (
    <div className="h-full w-full relative bg-slate-100 flex flex-col overflow-hidden">
      {/* Map Content Layer */}
      <div className="flex-1 relative z-0">
        <MapContainer 
          center={SA_CENTER} 
          zoom={13} 
          className="h-full w-full"
          zoomControl={false}
        >
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <MapUpdater center={userLocation} isAutoFollow={isAutoFollow} />
          
          {/* User Location Beacon */}
          {userLocation && (
            <Marker position={userLocation} icon={userIcon}>
              <Popup>
                <div className="p-1 font-sans text-xs font-bold text-[#1B263B]">
                  {isHustler ? 'Your Hustler Beacon' : 'Your Employer Location'}
                </div>
              </Popup>
            </Marker>
          )}

          {/* Interactive Radar Perimeter Circle */}
          <Circle 
            center={centerPoint} 
            radius={radiusKm * 1000} 
            pathOptions={{
              color: isHustler ? '#D4AF37' : '#1B263B',
              fillColor: isHustler ? '#D4AF37' : '#50C878',
              fillOpacity: 0.08,
              weight: 2,
              dashArray: '6, 8'
            }}
          />

          {/* Hustler Mode: Show Gigs strictly within radius on Radar */}
          {isHustler && visibleGigs.map(gig => {
            const isAssignedToMe = gig.hustlerId === currentHustlerId;
            return (
              <Marker 
                key={gig.id} 
                position={gig.location} 
                icon={isAssignedToMe ? occupiedJobIcon : (gig.isFeatured ? featuredIcon : clientIcon)}
              >
                <Popup>
                  <div className="p-3 min-w-[170px] font-sans">
                    <div className="flex items-center gap-1.5 mb-1">
                      <h4 className="font-black text-xs text-[#1B263B] uppercase tracking-tight truncate max-w-[130px]">{gig.title}</h4>
                      {gig.isVerifiedUser && <GoldCheck />}
                    </div>

                    {isAssignedToMe && (
                      <div className="mb-1.5">
                        <span className="text-[9px] font-black text-orange-700 bg-orange-100 border border-orange-300 px-2 py-0.5 rounded-full flex items-center gap-1 w-fit">
                          <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span>
                          Your Assigned Job (In Progress)
                        </span>
                      </div>
                    )}

                    <div className="flex justify-between items-center mb-1 text-[10px]">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{gig.category}</span>
                      <span className="text-sm font-black text-[#50C878]">R{gig.price}</span>
                    </div>
                    <div className="text-[9px] font-bold text-slate-500 mb-3">
                      📍 {gig.calculatedDistance} km away (within {radiusKm} km radius)
                    </div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectGig?.(gig);
                      }}
                      className="w-full py-2 bg-[#1B263B] text-white text-[9px] font-black uppercase tracking-[0.2em] rounded-lg shadow-md active:scale-95 transition-all"
                    >
                      {isAssignedToMe ? 'View My Job & PoW' : 'Details'}
                    </button>
                  </div>
                </Popup>
              </Marker>
            );
          })}

          {/* Employer Mode: Show Available Hustlers strictly within radius on Radar */}
          {!isHustler && visibleHustlers.map(hustler => {
            const isWorking = Boolean(hustler.isWorking || (hiredHustlerIds && hiredHustlerIds.includes(hustler.id)));
            return (
              <Marker 
                key={hustler.id} 
                position={hustler.location} 
                icon={createHustlerDivIcon(hustler.avatar, hustler.isVerified, isWorking)}
              >
                <Popup>
                  <div className="p-3 min-w-[210px] font-sans">
                    <div className="flex items-center gap-2.5 mb-2">
                      <div className="relative shrink-0">
                        <img src={hustler.avatar} alt={hustler.name} className="w-10 h-10 rounded-full object-cover border-2 border-slate-100 shadow-sm" />
                        <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white ${isWorking ? 'bg-orange-500' : 'bg-emerald-500'}`}></div>
                      </div>
                      <div className="overflow-hidden">
                        <div className="flex items-center gap-1">
                          <h4 className="font-black text-xs text-[#1B263B] uppercase tracking-tight truncate">{hustler.name}</h4>
                          {hustler.isVerified && <GoldCheck />}
                        </div>
                        <p className="text-[10px] font-bold text-slate-500 truncate">{hustler.skill}</p>
                      </div>
                    </div>

                    <div className="mb-2">
                      {isWorking ? (
                        <span className="text-[9px] font-black text-orange-700 bg-orange-100 border border-orange-300 px-2 py-0.5 rounded-full flex items-center gap-1 w-fit">
                          <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span>
                          Currently Working
                        </span>
                      ) : (
                        <span className="text-[9px] font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1 w-fit">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                          Available for Hire
                        </span>
                      )}
                    </div>

                    <div className="flex justify-between items-center mb-1 text-[10px] bg-slate-50 p-2 rounded-lg">
                      <span className="font-black text-amber-500">★ {hustler.rating} ({hustler.completedJobs} jobs)</span>
                      <span className="font-black text-[#1B263B]">R{hustler.hourlyRate}<span className="text-[8px] text-slate-400 font-bold">/hr</span></span>
                    </div>
                    <div className="text-[9px] font-bold text-slate-500 mb-3 px-1">
                      📍 {hustler.calculatedDistance} km away (within {radiusKm} km radius)
                    </div>
                    <div className="flex gap-1.5">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          onChatHustler?.(hustler);
                        }}
                        className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-[#1B263B] text-[9px] font-black uppercase tracking-wider rounded-lg active:scale-95 transition-all flex items-center justify-center gap-1"
                      >
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                        </svg>
                        Chat
                      </button>
                      {isWorking ? (
                        <button 
                          disabled
                          className="flex-1 py-2 bg-slate-200 text-slate-400 border border-slate-300 text-[9px] font-black uppercase tracking-wider rounded-lg cursor-not-allowed shadow-none flex items-center justify-center gap-1 select-none pointer-events-none"
                          title="Worker is already hired and currently working"
                        >
                          <span>✓</span>
                          <span>Hired</span>
                        </button>
                      ) : (
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedHustler(hustler);
                          }}
                          className="flex-1 py-2 bg-[#1B263B] text-white text-[9px] font-black uppercase tracking-wider rounded-lg shadow-md active:scale-95 transition-all"
                        >
                          Hire
                        </button>
                      )}
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>

        {/* Map Top Floating Controls (z-[800]) */}
        <div className="absolute top-4 left-4 right-4 z-[800] flex items-center justify-between pointer-events-none">
          {/* Left Controls: GPS Centering & Emergency SOS */}
          <div className="flex items-center gap-2 pointer-events-auto">
            {/* Centering button */}
            <button 
              onClick={() => setIsAutoFollow(!isAutoFollow)}
              className={`p-3 rounded-2xl shadow-xl transition-all border-2 border-white/50 backdrop-blur-md ${isAutoFollow ? 'bg-[#1B263B] text-white' : 'bg-white text-slate-400'}`}
              title="Toggle Auto Follow GPS"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
              </svg>
            </button>

            {/* Emergency SOS Panic Button */}
            <PanicButton />
          </div>

          {/* Right Controls: Radius & 5km Alerts */}
          <div className="flex items-center gap-2 pointer-events-auto">
            {onOpenPushSettings && (
              <button
                onClick={onOpenPushSettings}
                className="flex items-center gap-1.5 px-3 py-2.5 bg-[#1B263B] text-white rounded-2xl shadow-xl border border-[#D4AF37]/50 font-black text-xs uppercase tracking-wider active:scale-95 transition-all hover:bg-slate-900"
                title={isHustler ? "Configure 5km High-Paying Push Alerts" : "Configure Candidate Match Push Alerts"}
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className={isHustler ? "text-[#D4AF37] text-[11px]" : "text-emerald-400 text-[11px]"}>
                  {isHustler ? '5km' : 'Match'}
                </span>
                <span className="text-white text-[10px]">Alerts</span>
              </button>
            )}

            {/* Dedicated Set Radius Button */}
            <button
              onClick={() => setIsRadiusModalOpen(true)}
              className="pointer-events-auto flex items-center gap-2 px-3.5 py-2.5 bg-white/95 backdrop-blur-md rounded-2xl shadow-xl border border-slate-200/80 text-[#1B263B] font-black text-xs uppercase tracking-wider active:scale-95 transition-all hover:bg-white"
            >
              <span className="text-[#D4AF37]">🎯</span>
              <span>Radius: <strong className="text-[#1B263B] font-black">{radiusKm} km</strong></span>
              <svg className="w-3.5 h-3.5 text-slate-400 ml-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Draggable Bottom Sheet (z-[1100]) */}
      <div 
        className="absolute bottom-0 left-0 right-0 bg-white rounded-t-[40px] shadow-[0_-15px_50px_rgba(0,0,0,0.15)] z-[1100] flex flex-col transition-none border-t border-slate-100"
        style={{ height: `${sheetHeight}%` }}
      >
        <div 
          className="h-10 w-full flex items-center justify-center cursor-grab active:cursor-grabbing shrink-0"
          onMouseDown={handleDragStart}
          onTouchStart={handleDragStart}
        >
          <div className="w-12 h-1.5 bg-slate-200 rounded-full"></div>
        </div>

        <div className="flex-1 overflow-y-auto px-6 pb-12 no-scrollbar">
          {/* Title and Role Badge */}
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-xl font-black text-[#1B263B] uppercase tracking-tight">
              {isHustler ? 'Nearby Gigs' : 'Nearby Hustlers'}
            </h2>
            {isHustler ? (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-[#50C878]/10 rounded-xl border border-[#50C878]/20">
                <div className="w-2 h-2 bg-[#50C878] rounded-full animate-pulse"></div>
                <span className="text-[10px] font-black text-[#50C878] uppercase tracking-widest">
                  {visibleGigs.length} in {radiusKm}km
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-[#1B263B]/10 rounded-xl border border-[#1B263B]/20">
                <div className="w-2 h-2 bg-[#50C878] rounded-full animate-pulse"></div>
                <span className="text-[10px] font-black text-[#1B263B] uppercase tracking-widest">
                  {visibleHustlers.length} in {radiusKm}km
                </span>
              </div>
            )}
          </div>

          {/* Radius Quick Selector Row */}
          <div className="mb-5 bg-slate-50 p-3 rounded-2xl border border-slate-100">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <span className="text-xs">🎯</span>
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Radar Radius</span>
              </div>
              <button 
                onClick={() => setIsRadiusModalOpen(true)}
                className="text-[9px] font-black text-[#1B263B] uppercase tracking-wider hover:underline"
              >
                Custom Range ({radiusKm} km)
              </button>
            </div>

            {/* Quick Preset Buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {RADIUS_PRESETS.map(r => (
                <button
                  key={r}
                  onClick={() => handleRadiusChange(r)}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-black whitespace-nowrap transition-all ${
                    radiusKm === r 
                      ? (isHustler ? 'bg-[#D4AF37] text-white shadow-sm' : 'bg-[#1B263B] text-white shadow-sm')
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {r} km
                </button>
              ))}
            </div>
          </div>

          {/* Hustler Mode: List of Gigs strictly in Radius */}
          {isHustler && (
            <div className="space-y-4">
              {/* 5km Immediate Push Alert Status Card */}
              <div className="bg-gradient-to-r from-slate-900 to-[#1B263B] text-white p-3.5 rounded-2xl border border-[#D4AF37]/40 shadow-sm flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#D4AF37] to-amber-200 text-slate-950 flex items-center justify-center text-sm font-black shadow">
                    ⚡
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[9px] font-black uppercase tracking-wider text-[#D4AF37]">
                        5km Skill Radar Alerts
                      </span>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    </div>
                    <span className="text-xs font-bold text-slate-200 block">
                      Alerts for high-paying gigs nearby
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {onSimulateAlert && (
                    <button
                      type="button"
                      onClick={onSimulateAlert}
                      className="px-2.5 py-1.5 bg-[#D4AF37] hover:bg-amber-400 text-slate-950 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all active:scale-95 shadow-sm"
                      title="Test/Simulate a high-paying 5km gig alert"
                    >
                      Test Alert
                    </button>
                  )}
                  {onOpenPushSettings && (
                    <button
                      type="button"
                      onClick={onOpenPushSettings}
                      className="p-1.5 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-all"
                      title="Alert Settings & Skills"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </button>
                  )}
                </div>
              </div>

              {visibleGigs.length === 0 ? (
                <div className="py-10 text-center bg-slate-50/60 rounded-3xl border border-dashed border-slate-200 p-6">
                  <div className="text-3xl mb-2">📡</div>
                  <h4 className="text-sm font-black text-[#1B263B] mb-1">No Gigs Within {radiusKm} km</h4>
                  <p className="text-slate-400 text-xs font-medium max-w-xs mx-auto mb-4">
                    There are currently no active job postings inside this radius. Expand your perimeter to see opportunities further out.
                  </p>
                  <div className="flex items-center justify-center gap-2">
                    <button 
                      onClick={() => handleRadiusChange(Math.min(50, radiusKm + 10))}
                      className="px-4 py-2 bg-[#1B263B] text-white rounded-xl text-[10px] font-black uppercase tracking-wider"
                    >
                      +10 km Radius
                    </button>
                    <button 
                      onClick={() => handleRadiusChange(25)}
                      className="px-4 py-2 bg-slate-200 text-slate-700 rounded-xl text-[10px] font-black uppercase tracking-wider"
                    >
                      Set to 25 km
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {hiddenOccupiedCount > 0 && (
                    <div className="p-3 bg-amber-50 border border-amber-200/80 rounded-2xl flex items-center gap-2.5 text-xs text-amber-900 shadow-xs">
                      <span className="text-base shrink-0">🔒</span>
                      <p className="text-[11px] font-medium leading-tight">
                        <strong className="font-black">{hiddenOccupiedCount} occupied job{hiddenOccupiedCount > 1 ? 's are' : ' is'}</strong> hidden from other hustlers (visible only to the hired occupant).
                      </p>
                    </div>
                  )}
                  {visibleGigs.map(gig => {
                    const isAssignedToMe = gig.hustlerId === currentHustlerId;
                    return (
                      <div 
                        key={gig.id} 
                        onClick={() => onSelectGig?.(gig)}
                        className={`p-5 rounded-[28px] border-2 transition-all active:scale-[0.98] cursor-pointer
                          ${isAssignedToMe 
                            ? 'border-orange-400 bg-orange-50/50 shadow-md ring-2 ring-orange-200' 
                            : (gig.isFeatured ? 'border-[#D4AF37] bg-[#D4AF37]/5' : 'border-slate-50 bg-white shadow-sm hover:border-[#1B263B]/10')}
                        `}
                      >
                        <div className="flex justify-between items-start mb-1.5">
                          <div className="flex items-center gap-2">
                            <h3 className="font-black text-[#1B263B] uppercase tracking-tight text-sm">{gig.title}</h3>
                            {gig.isVerifiedUser && <GoldCheck />}
                          </div>
                          <span className="text-sm font-black text-[#1B263B]">R{gig.price}</span>
                        </div>

                        {isAssignedToMe && (
                          <div className="mb-2">
                            <span className="text-[9px] font-black text-orange-800 bg-orange-100 border border-orange-300 px-2 py-0.5 rounded-full inline-flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span>
                              Assigned to You (In Progress)
                            </span>
                          </div>
                        )}

                        <p className="text-xs text-slate-500 line-clamp-2 mb-3 font-medium leading-relaxed">{gig.description}</p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex flex-col">
                            <div className="flex items-center gap-2">
                              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{gig.category}</span>
                              <span className="text-[9px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
                                📍 {gig.calculatedDistance} km
                              </span>
                            </div>
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                onCompleteJob?.({ id: gig.id, title: gig.title, price: gig.price }, !!gig.isFeatured);
                              }}
                              className="text-[8px] font-black text-emerald-600 uppercase mt-1 hover:underline text-left"
                            >
                              Mark as Done
                            </button>
                          </div>
                          <button className={`px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all
                            ${isAssignedToMe ? 'bg-orange-500 text-white font-black' : (gig.isFeatured ? 'bg-[#D4AF37] text-white' : 'bg-[#1B263B] text-white')}
                          `}>
                            {isAssignedToMe ? 'My Job' : 'Details'}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </>
              )}
            </div>
          )}

          {/* Employer Mode: List of Available Hustlers strictly in Radius */}
          {!isHustler && (
            <div className="space-y-3.5">
              {/* Employer Candidate Match Push Alert Status Card */}
              <div className="bg-gradient-to-r from-slate-900 to-[#1B263B] text-white p-3.5 rounded-2xl border border-emerald-500/40 shadow-sm flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-400 to-teal-200 text-slate-950 flex items-center justify-center text-sm font-black shadow">
                    👥
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[9px] font-black uppercase tracking-wider text-emerald-400">
                        Candidate Match Alerts
                      </span>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    </div>
                    <span className="text-xs font-bold text-slate-200 block">
                      Alerts for available hustlers matching your gigs
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {onSimulateAlert && (
                    <button
                      type="button"
                      onClick={onSimulateAlert}
                      className="px-2.5 py-1.5 bg-emerald-400 hover:bg-emerald-300 text-slate-950 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all active:scale-95 shadow-sm"
                      title="Test/Simulate a candidate match alert for your posted gig"
                    >
                      Test Match
                    </button>
                  )}
                  {onOpenPushSettings && (
                    <button
                      type="button"
                      onClick={onOpenPushSettings}
                      className="p-1.5 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-all"
                      title="Candidate Match Alert Settings"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </button>
                  )}
                </div>
              </div>
              {visibleHustlers.length === 0 ? (
                <div className="py-10 text-center bg-slate-50/60 rounded-3xl border border-dashed border-slate-200 p-6">
                  <div className="text-3xl mb-2">👷</div>
                  <h4 className="text-sm font-black text-[#1B263B] mb-1">No Hustlers Within {radiusKm} km</h4>
                  <p className="text-slate-400 text-xs font-medium max-w-xs mx-auto mb-4">
                    No verified workers are currently available in this specific radius. Expand your perimeter to discover talent nearby.
                  </p>
                  <div className="flex items-center justify-center gap-2">
                    <button 
                      onClick={() => handleRadiusChange(Math.min(50, radiusKm + 10))}
                      className="px-4 py-2 bg-[#1B263B] text-white rounded-xl text-[10px] font-black uppercase tracking-wider"
                    >
                      +10 km Radius
                    </button>
                    <button 
                      onClick={() => handleRadiusChange(25)}
                      className="px-4 py-2 bg-slate-200 text-slate-700 rounded-xl text-[10px] font-black uppercase tracking-wider"
                    >
                      Set to 25 km
                    </button>
                  </div>
                </div>
              ) : (
                visibleHustlers.map(hustler => {
                  const isWorking = Boolean(hustler.isWorking || (hiredHustlerIds && hiredHustlerIds.includes(hustler.id)));
                  return (
                    <div 
                      key={hustler.id} 
                      onClick={() => setSelectedHustler(hustler)}
                      className="p-4 rounded-[24px] border-2 border-slate-100/80 bg-white shadow-sm hover:border-[#1B263B]/20 transition-all active:scale-[0.98] cursor-pointer"
                    >
                      <div className="flex items-start gap-3.5">
                        <div className="relative shrink-0">
                          <img 
                            src={hustler.avatar} 
                            alt={hustler.name} 
                            className="w-14 h-14 rounded-2xl object-cover border border-slate-100 shadow-sm" 
                          />
                          <div className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 border-2 border-white rounded-full ${isWorking ? 'bg-orange-500 shadow-xs' : 'bg-[#50C878]'}`}></div>
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1 mb-0.5">
                            <div className="flex items-center gap-1.5 truncate">
                              <h3 className="font-black text-[#1B263B] text-sm tracking-tight truncate">{hustler.name}</h3>
                              {hustler.isVerified && <GoldCheck />}
                            </div>
                            <span className="text-sm font-black text-[#1B263B] shrink-0">
                              R{hustler.hourlyRate}<span className="text-[10px] text-slate-400 font-bold">/hr</span>
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
                            <p className="text-xs text-slate-600 font-bold truncate">{hustler.skill}</p>
                            {isWorking ? (
                              <span className="text-[9px] font-black text-orange-700 bg-orange-50 border border-orange-200 px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span>
                                Currently Working
                              </span>
                            ) : (
                              <span className="text-[9px] font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded-full">
                                Available
                              </span>
                            )}
                          </div>

                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 text-[10px]">
                              <span className="flex items-center gap-0.5 text-amber-500 font-black">
                                ★ {hustler.rating}
                              </span>
                              <span className="text-slate-300">•</span>
                              <span className="text-slate-400 font-bold">{hustler.completedJobs} jobs</span>
                              <span className="text-slate-300">•</span>
                              <span className="text-emerald-700 font-black bg-emerald-50 px-1.5 py-0.5 rounded">
                                {hustler.calculatedDistance} km
                              </span>
                            </div>

                            <div className="flex items-center gap-1.5">
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onChatHustler?.(hustler);
                                }}
                                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-[#1B263B] rounded-xl text-[9px] font-black uppercase tracking-widest active:scale-90 transition-all flex items-center gap-1"
                                title="Send Message"
                              >
                                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                                </svg>
                                Chat
                              </button>
                              {isWorking ? (
                                <button 
                                  disabled
                                  className="px-3 py-1.5 bg-slate-200 text-slate-400 border border-slate-300 rounded-xl text-[9px] font-black uppercase tracking-widest cursor-not-allowed shadow-none select-none pointer-events-none"
                                  title="Worker is already hired and currently working"
                                >
                                  ✓ Hired
                                </button>
                              ) : (
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedHustler(hustler);
                                  }}
                                  className="px-3 py-1.5 bg-[#1B263B] text-white rounded-xl text-[9px] font-black uppercase tracking-widest active:scale-90 transition-all shadow-sm"
                                >
                                  Hire
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>

      {/* Top Banner: Status Header */}
      {isHustler ? (
        <div className="absolute top-20 left-4 right-4 z-[800] space-y-2">
          {/* Persona selector if any hustlers are hired to let user easily test "other hustler" vs "hired occupant" */}
          {hiredOccupants.length > 0 && onSwitchHustlerPersona && (
            <div className="bg-[#1B263B] text-white px-3.5 py-2 rounded-2xl shadow-lg border border-slate-700 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 truncate">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 shrink-0">Radar Persona:</span>
                <span className="text-xs font-bold truncate text-white">
                  {currentHustlerId === 'hustler-1' ? 'Sipho (Other Hustler)' : (hustlers.find(h => h.id === currentHustlerId)?.name || 'Hired Occupant')}
                </span>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => onSwitchHustlerPersona('hustler-1')}
                  className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all ${
                    currentHustlerId === 'hustler-1' ? 'bg-slate-200 text-slate-900 font-bold' : 'bg-white/10 hover:bg-white/20 text-slate-300'
                  }`}
                  title="View as other hustler (occupied jobs will be hidden)"
                >
                  Other Hustler
                </button>
                {hiredOccupants.map(occ => (
                  <button
                    key={occ.id}
                    onClick={() => onSwitchHustlerPersona(occ.id)}
                    className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all ${
                      currentHustlerId === occ.id ? 'bg-orange-500 text-white font-black shadow' : 'bg-white/10 hover:bg-white/20 text-orange-300'
                    }`}
                    title="View as the hired occupant (assigned job is visible)"
                  >
                    {occ.name.split(' ')[0]} (Occupant)
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Hustler Availability Status Card */}
          {(() => {
            const isHustlerWorking = Boolean(currentHustlerId && hiredHustlerIds.includes(currentHustlerId));
            return (
              <div className="bg-white/90 backdrop-blur-md rounded-2xl p-4 shadow-xl border border-white/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-3.5 h-3.5 rounded-full border-2 border-white shadow-xs ${
                    isHustlerWorking 
                      ? 'bg-orange-500 animate-pulse' 
                      : (isAvailable ? 'bg-[#50C878]' : 'bg-slate-300')
                  }`}></div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <p className="text-[10px] font-black text-[#1B263B] uppercase tracking-widest leading-none">
                        Radar Status:
                      </p>
                      {isHustlerWorking ? (
                        <span className="text-[10px] font-black text-orange-600 uppercase tracking-wide bg-orange-50 border border-orange-200 px-1.5 py-0.5 rounded-full">
                          Currently Working
                        </span>
                      ) : (
                        <span className={`text-[10px] font-black uppercase tracking-wide ${isAvailable ? 'text-emerald-600' : 'text-slate-400'}`}>
                          {isAvailable ? 'Available' : 'Offline'}
                        </span>
                      )}
                    </div>
                    <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tight mt-1">
                      {isHustlerWorking 
                        ? 'Active Escrow Job In Progress • 🔕 Notifications Paused' 
                        : (isAvailable ? `Broadcasting within ${radiusKm}km` : 'Hidden from Radar')}
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => onToggleAvailability?.(!isAvailable)}
                  className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all
                    ${isHustlerWorking 
                      ? 'bg-orange-500 hover:bg-orange-600 text-white shadow-sm' 
                      : (isAvailable ? 'bg-[#1B263B] text-white' : 'bg-slate-100 text-slate-400')}
                  `}
                >
                  {isHustlerWorking ? 'Working' : (isAvailable ? 'Go Offline' : 'Go Online')}
                </button>
              </div>
            );
          })()}
        </div>
      ) : (
        <div className="absolute top-20 left-4 right-4 z-[800]">
          {(() => {
            const hasHiredWorker = hiredHustlerIds.length > 0;
            return (
              <div className="bg-white/90 backdrop-blur-md rounded-2xl p-3.5 shadow-xl border border-white/50 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className={`w-2.5 h-2.5 rounded-full ${hasHiredWorker ? 'bg-orange-500 animate-pulse' : 'bg-[#50C878] animate-pulse'}`}></div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <p className="text-[10px] font-black text-[#1B263B] uppercase tracking-widest leading-none">Employer Radar Active</p>
                      {hasHiredWorker && (
                        <span className="text-[9px] font-black text-orange-700 bg-orange-50 border border-orange-200 px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                          Worker Hired
                        </span>
                      )}
                    </div>
                    <p className="text-[9px] text-slate-500 font-semibold mt-0.5">
                      {hasHiredWorker 
                        ? 'Worker active on job • 🔕 Candidate alerts paused'
                        : `Scanning verified talent within ${radiusKm}km`}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  {hasHiredWorker && onCompleteJob && (
                    <button
                      onClick={() => onCompleteJob({ id: 'gig-1', title: 'Hired Hustler Job', price: 950 }, false)}
                      className="px-2 py-1 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg text-[9px] font-black uppercase tracking-wider transition-all shadow-xs"
                      title="Mark current job done to resume alerts"
                    >
                      Finish Job
                    </button>
                  )}
                  <button 
                    onClick={() => setIsRadiusModalOpen(true)}
                    className="px-2.5 py-1 bg-[#1B263B]/5 border border-[#1B263B]/10 rounded-lg text-[9px] font-black text-[#1B263B] uppercase tracking-wider hover:bg-[#1B263B]/10 transition-all"
                  >
                    {visibleHustlers.length} Active
                  </button>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* Set Radius Modal / Dialog */}
      {isRadiusModalOpen && (
        <div className="fixed inset-0 z-[13000] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-sm rounded-[32px] shadow-2xl p-6 overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-sm">
                  🎯
                </div>
                <div>
                  <h3 className="text-base font-black text-[#1B263B] tracking-tight">Set Radar Radius</h3>
                  <p className="text-[9px] text-slate-400 font-black uppercase tracking-wider">
                    {isHustler ? 'Visible Gig Opportunities' : 'Visible Hustlers'}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setIsRadiusModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-all"
              >
                ✕
              </button>
            </div>

            {/* Current Range Display */}
            <div className="text-center p-5 bg-gradient-to-b from-slate-50 to-slate-100/50 rounded-2xl border border-slate-100 mb-5">
              <span className="text-3xl font-black text-[#1B263B]">{radiusKm}</span>
              <span className="text-sm font-bold text-slate-400 ml-1">km radius</span>
              <p className="text-xs font-semibold text-slate-500 mt-1">
                {isHustler 
                  ? `Showing ${visibleGigs.length} available gigs in this range`
                  : `Showing ${visibleHustlers.length} available hustlers in this range`}
              </p>
            </div>

            {/* Slider */}
            <div className="mb-5 px-1">
              <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">
                <span>1 km</span>
                <span className="text-[#1B263B] font-black">{radiusKm} km</span>
                <span>50 km</span>
              </div>
              <input 
                type="range" 
                min={1} 
                max={50} 
                value={radiusKm} 
                onChange={(e) => handleRadiusChange(parseInt(e.target.value, 10))}
                className="w-full accent-[#1B263B] h-2 bg-slate-200 rounded-lg cursor-pointer"
              />
            </div>

            {/* Quick Presets */}
            <div className="mb-6">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">
                Quick Distance Presets
              </label>
              <div className="grid grid-cols-3 gap-2">
                {RADIUS_PRESETS.map(r => (
                  <button
                    key={r}
                    onClick={() => handleRadiusChange(r)}
                    className={`py-2 rounded-xl text-xs font-black transition-all ${
                      radiusKm === r
                        ? (isHustler ? 'bg-[#D4AF37] text-white shadow-md' : 'bg-[#1B263B] text-white shadow-md')
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {r} km
                  </button>
                ))}
              </div>
            </div>

            {/* Confirm */}
            <button
              onClick={() => setIsRadiusModalOpen(false)}
              className="w-full py-3.5 bg-[#1B263B] text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-slate-900/20 active:scale-95 transition-all"
            >
              Apply Radius
            </button>
          </div>
        </div>
      )}

      {/* Selected Hustler Detail Modal */}
      {selectedHustler && (() => {
        const isWorking = Boolean(selectedHustler.isWorking || (hiredHustlerIds && hiredHustlerIds.includes(selectedHustler.id)));
        return (
          <div className="fixed inset-0 z-[12000] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
            <div className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-[32px] shadow-2xl p-6 overflow-hidden max-h-[85vh] flex flex-col animate-in slide-in-from-bottom duration-300">
              {/* Header & Close */}
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-amber-50 border border-amber-200 text-amber-800 rounded-full text-[10px] font-black uppercase tracking-wider">
                    {selectedHustler.tier} Hustler
                  </span>
                  {isWorking ? (
                    <span className="px-3 py-1 bg-orange-50 border border-orange-200 text-orange-800 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse"></span>
                      Currently Working
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-full text-[10px] font-black uppercase tracking-wider">
                      Available
                    </span>
                  )}
                </div>
                <button 
                  onClick={() => setSelectedHustler(null)}
                  className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-all"
                >
                  ✕
                </button>
              </div>

              {/* Profile Overview */}
              <div className="flex items-center gap-4 mb-4">
                <div className="relative shrink-0">
                  <img 
                    src={selectedHustler.avatar} 
                    alt={selectedHustler.name} 
                    className="w-20 h-20 rounded-full aspect-square object-cover border-2 border-slate-100 shadow-md"
                  />
                  <div className={`absolute -bottom-1 -right-1 w-4 h-4 border-2 border-white rounded-full ${isWorking ? 'bg-orange-500 shadow-xs' : 'bg-[#50C878]'}`}></div>
                </div>
                <div className="overflow-hidden">
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-black text-[#1B263B] tracking-tight">{selectedHustler.name}</h3>
                    {selectedHustler.isVerified && <GoldCheck />}
                  </div>
                  <p className="text-xs font-bold text-slate-600 mt-0.5">{selectedHustler.skill}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-sm font-black text-[#1B263B]">R{selectedHustler.hourlyRate}<span className="text-[10px] text-slate-400 font-bold">/hr</span></span>
                    <span className="text-slate-300">•</span>
                    <span className="text-xs font-black text-amber-500">★ {selectedHustler.rating}</span>
                    <span className="text-slate-400 text-xs font-bold">({selectedHustler.reviewsCount} reviews)</span>
                  </div>
                </div>
              </div>

              {/* Stats Pills */}
              <div className="grid grid-cols-3 gap-2.5 mb-4 text-center">
                <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Completed</p>
                  <p className="text-base font-black text-[#1B263B]">{selectedHustler.completedJobs} Gigs</p>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Distance</p>
                  <p className="text-base font-black text-[#50C878]">{selectedHustler.calculatedDistance ?? selectedHustler.distanceKm} km</p>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Verification</p>
                  <p className="text-xs font-black text-[#D4AF37] mt-1">SA ID & Face ✓</p>
                </div>
              </div>

              {/* Bio */}
              <div className="mb-5 overflow-y-auto">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">About This Hustler</h4>
                <p className="text-xs text-slate-600 font-medium leading-relaxed bg-slate-50/80 p-3 rounded-2xl border border-slate-100">
                  {selectedHustler.bio}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2.5 mt-auto pt-2 border-t border-slate-100">
                <button 
                  onClick={() => {
                    const hustler = selectedHustler;
                    setSelectedHustler(null);
                    onChatHustler?.(hustler);
                  }}
                  className="flex-1 py-3.5 rounded-2xl border-2 border-slate-200 text-[#1B263B] font-black text-xs uppercase tracking-wider active:scale-95 transition-all"
                >
                  Send Message
                </button>
                {isWorking ? (
                  <div className="flex-1 flex gap-2">
                    <button 
                      disabled
                      className="flex-1 py-3.5 rounded-2xl bg-slate-200 text-slate-400 border border-slate-300 font-black text-xs uppercase tracking-wider cursor-not-allowed shadow-none select-none pointer-events-none flex items-center justify-center gap-1.5"
                      title="Worker is already hired and currently working"
                    >
                      <span>✓</span>
                      <span>Hired</span>
                    </button>
                    {onCompleteJob && (
                      <button
                        onClick={() => {
                          const hustler = selectedHustler;
                          setSelectedHustler(null);
                          onCompleteJob({ id: 'gig-1', title: `Job with ${hustler.name}`, price: hustler.hourlyRate * 3 }, false);
                        }}
                        className="flex-1 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs uppercase tracking-wider shadow-md active:scale-95 transition-all flex items-center justify-center gap-1"
                        title="Mark work complete to resume notifications"
                      >
                        Finish Job
                      </button>
                    )}
                  </div>
                ) : (
                  <button 
                    onClick={() => {
                      const hustler = selectedHustler;
                      setSelectedHustler(null);
                      onHireHustler?.(hustler);
                    }}
                    className="flex-1 py-3.5 rounded-2xl bg-[#1B263B] text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-slate-900/20 active:scale-95 transition-all"
                  >
                    Hire & Escrow
                  </button>
                )}
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};

export default RadarMap;
