import React, { useState, useRef, useMemo } from 'react';
import { UserStats, UserTier, UserProfile } from '../types';

interface AccountPageProps {
  isHustler: boolean;
  setIsHustler: (v: boolean) => void;
  onSignOut: () => void;
  stats: UserStats;
  profile: UserProfile;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onNavigatePersonalInfo: () => void;
  onNavigateManageGigs: () => void;
  onNavigateSecuritySafety: () => void;
  onOpenPushSettings?: () => void;
}

const AccountPage: React.FC<AccountPageProps> = ({ isHustler, setIsHustler, onSignOut, stats, profile, onUpdateProfile, onNavigatePersonalInfo, onNavigateManageGigs, onNavigateSecuritySafety, onOpenPushSettings }) => {
  const colors = {
    gold: '#D4AF37',
    goldLight: '#F5E6BE',
    navy: '#1B263B',
    navyLight: '#2C3E50',
    white: '#FFFFFF',
    slate: '#F8FAFC',
    emerald: '#10B981',
    silver: '#C0C0C0',
    track: '#121926'
  };

  const [showSnackBar, setShowSnackBar] = useState(false);
  const [snackBarMsg, setSnackBarMsg] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [profilePicUrl, setProfilePicUrl] = useState<string>(() => {
    return localStorage.getItem('swifthustle_profile_pic') || `https://picsum.photos/seed/swifthustle_${isHustler ? 'hustle' : 'client'}/300`;
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const instantPayoutStatus = useMemo(() => {
    const isVerified = profile.verification.identity === 'verified';
    const jobsGoal = 5;
    const ratingGoal = 4.5;
    const jobsDone = stats.jobsPostedCount || 0;
    const currentRating = stats.averageRating;

    const progress = Math.min(jobsDone / jobsGoal, 1);
    const unlocked = isVerified && jobsDone >= jobsGoal && currentRating >= ratingGoal;

    return {
      unlocked,
      jobsProgress: progress,
      jobsCount: jobsDone,
      jobsGoal,
      rating: currentRating,
      ratingGoal,
      verified: isVerified
    };
  }, [stats, profile]);

  const tierProgress = useMemo(() => {
    const jobs = stats.jobsCompleted;
    let nextTier = UserTier.RISING_STAR;
    let targetJobs = 10;
    let targetRating = 4.0;
    let progress = 0;
    let label = '';
    let requirementsMsg = '';

    if (stats.currentTier === UserTier.PREMIUM) {
      return { 
        progress: 1, 
        label: 'MAX LEVEL REACHED', 
        nextTier: 'Top Elite',
        requirementsMsg: 'You have reached the highest tier! Keep providing top service to maintain your status.' 
      };
    } else if (stats.currentTier === UserTier.ELITE) {
      nextTier = UserTier.PREMIUM;
      targetJobs = 50;
      targetRating = 4.8;
      label = `${jobs}/${targetJobs} Jobs to reach ${nextTier}`;
      progress = jobs / targetJobs;
      requirementsMsg = `Maintain a ${targetRating}+ star rating and complete ${targetJobs} jobs to reach ${nextTier} status.`;
    } else if (stats.currentTier === UserTier.RISING_STAR) {
      nextTier = UserTier.ELITE;
      targetJobs = 25;
      targetRating = 4.5;
      label = `${jobs}/${targetJobs} Jobs to reach ${nextTier}`;
      progress = jobs / targetJobs;
      requirementsMsg = `Maintain a ${targetRating}+ star rating and complete ${targetJobs} jobs to reach ${nextTier} status.`;
    } else {
      nextTier = UserTier.RISING_STAR;
      targetJobs = 10;
      targetRating = 4.0;
      label = `${jobs}/${targetJobs} Jobs to reach ${nextTier}`;
      progress = jobs / targetJobs;
      requirementsMsg = `Maintain a ${targetRating}+ star rating and complete ${targetJobs} jobs to reach ${nextTier} status.`;
    }

    return { 
      progress: Math.min(progress, 1), 
      label, 
      nextTier,
      requirementsMsg
    };
  }, [stats]);

  const tierConfig = useMemo(() => {
    switch (stats.currentTier) {
      case UserTier.PREMIUM:
        return { color: colors.gold, icon: '💎', next: null };
      case UserTier.ELITE:
        return { color: colors.navy, icon: '🏆', next: UserTier.PREMIUM };
      case UserTier.RISING_STAR:
        return { color: colors.emerald, icon: '⭐', next: UserTier.ELITE };
      default:
        return { color: colors.silver, icon: '🌱', next: UserTier.RISING_STAR };
    }
  }, [stats.currentTier]);

  const triggerSnackBar = (msg: string) => {
    setSnackBarMsg(msg);
    setShowSnackBar(true);
    setTimeout(() => setShowSnackBar(false), 4000);
  };

  const handleToggleRole = async () => {
    const newRole = !isHustler;
    setIsHustler(newRole);
    triggerSnackBar(`Switching to ${newRole ? 'Hustler' : 'Employer'} Mode...`);
  };

  const handleToggleAvailability = (v: boolean) => {
    onUpdateProfile({ isAvailable: v });
    triggerSnackBar(v ? 'You are now visible to nearby employers!' : 'Availability turned off.');
  };

  const handlePickImage = () => fileInputRef.current?.click();

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        localStorage.setItem('swifthustle_profile_pic', base64String);
        setProfilePicUrl(base64String);
        setIsUploading(false);
        triggerSnackBar('Profile picture updated!');
      };
      reader.readAsDataURL(file);
    } catch (error) {
      setIsUploading(false);
    }
  };

  const activeThemeColor = isHustler ? colors.gold : colors.navy;

  const menuItems = [
    { icon: '👤', label: 'Personal Information', action: onNavigatePersonalInfo },
    { icon: '📡', label: isHustler ? '5km High-Paying Gig Alerts' : 'Candidate Match Push Alerts', action: onOpenPushSettings },
    { icon: '💼', label: 'Manage My Gigs', action: onNavigateManageGigs, hide: isHustler },
    { icon: '🚀', label: 'Instant Payout', restricted: isHustler && stats.currentTier !== UserTier.PREMIUM },
    { icon: '🛡️', label: 'Security & Safety', action: onNavigateSecuritySafety },
    { icon: '🚪', label: 'Sign Out', danger: true, action: onSignOut },
  ];

  return (
    <div className="flex flex-col h-full bg-[#fcfcfc] overflow-y-auto pb-32 relative no-scrollbar">
      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />

      {isUploading && (
        <div className="fixed inset-0 z-[4000] bg-black/60 backdrop-blur-sm flex items-center justify-center">
          <div className="bg-white p-8 rounded-[40px] shadow-2xl flex flex-col items-center">
            <div className="w-14 h-14 border-4 border-slate-100 border-t-emerald-600 rounded-full animate-spin mb-4"></div>
            <p className="text-slate-900 font-black text-sm uppercase tracking-widest">Saving Profile...</p>
          </div>
        </div>
      )}

      {showSnackBar && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[5000] w-[90%] max-w-sm">
          <div className="bg-slate-900 text-white p-4 rounded-3xl shadow-2xl flex items-center justify-between animate-in slide-in-from-bottom duration-300">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: activeThemeColor }}></div>
              <span className="text-[10px] font-black uppercase tracking-widest leading-normal pr-2">{snackBarMsg}</span>
            </div>
            <button onClick={() => setShowSnackBar(false)} className="text-white/40"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12"/></svg></button>
          </div>
        </div>
      )}

      <div className="relative shrink-0">
        <div 
          className="h-56 w-full transition-colors duration-700 relative overflow-hidden" 
          style={{ background: isHustler 
            ? `linear-gradient(135deg, ${colors.gold} 0%, #B8860B 100%)` 
            : `linear-gradient(135deg, ${colors.navy} 0%, ${colors.navyLight} 100%)` 
          }}
        >
          {/* Top Header Watermark Layer */}
          <div className="absolute inset-0 opacity-15 flex items-center justify-center pointer-events-none select-none">
            <img 
              src="/assets/logo-icon.svg" 
              alt="SwiftHustle Icon Branding" 
              className="w-40 h-40 object-contain tracking-normal" 
            />
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 border-[40px] border-white rounded-full -mr-32 -mt-32 opacity-10"></div>
        </div>

        <div className="absolute left-1/2 -translate-x-1/2 -bottom-20 z-20">
          <div className="relative group p-1.5 bg-white rounded-full shadow-2xl transition-transform hover:scale-105 duration-300">
            <div className="w-36 h-36 rounded-full overflow-hidden border-[6px] border-white bg-slate-100 shadow-inner">
              <img src={profilePicUrl} className="w-full h-full object-cover" alt="Profile" />
            </div>
            <div className="absolute -top-1 -right-1 w-12 h-12 rounded-full bg-white shadow-lg border-[3px] border-slate-50 flex items-center justify-center text-2xl z-40">
              {tierConfig.icon}
            </div>
            <button 
              onClick={handlePickImage}
              className="absolute bottom-1 right-1 w-11 h-11 rounded-full border-[4px] border-white flex items-center justify-center shadow-lg transition-all active:scale-90"
              style={{ backgroundColor: activeThemeColor }}
            >
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 9a2 2 0 012-2h.93a2 2 0 011.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0118.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Main Stats Profile Wrapper with Absolute Watermark Background */}
      <div className="mt-24 px-8 text-center relative min-h-[220px]">
        {/* Connected "H"-Steps Profile Center Watermark */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden select-none z-0 opacity-[0.03]">
          <img 
            src="/assets/logo-icon.svg" 
            alt="SwiftHustle Large Watermark" 
            className="w-72 h-72 object-contain max-w-full"
          />
        </div>

        <div className="relative z-10">
          <h1 className="text-3xl font-black tracking-tight text-[#1B263B]">{profile.fullName}</h1>
          
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white border border-slate-200/80 shadow-xs rounded-full text-[11px] font-semibold text-slate-600 mt-2 mb-1">
            <svg className="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.206" /></svg>
            <span className="truncate max-w-[200px]">{profile.email}</span>
            {profile.email.includes('@gmail.com') && (
              <span className="text-[9px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">Gmail Connected</span>
            )}
          </div>

          <div className="flex items-center justify-center gap-2 mt-2 mb-4">
            <div className="flex items-center gap-1 bg-white border border-slate-100 px-3 py-1 rounded-full shadow-sm">
              <span className="text-amber-400 text-sm">★</span>
              <span className="text-[11px] font-black text-navy">{stats.averageRating}</span>
            </div>
            <span className="w-1 h-1 bg-slate-200 rounded-full"></span>
            <span className="text-[11px] font-black uppercase tracking-[0.25em]" style={{ color: tierConfig.color }}>
              {stats.currentTier} {isHustler ? 'Hustler' : 'Employer'}
            </span>
          </div>

          {!isHustler && (
            <div className="bg-white rounded-[32px] p-6 shadow-sm border border-slate-100 mb-8 max-w-sm mx-auto animate-in slide-in-from-top duration-500">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-[#1B263B]">Trust Meter Progress</h4>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${instantPayoutStatus.unlocked ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                  {instantPayoutStatus.unlocked ? (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                  ) : (
                    <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" /></svg>
                  )}
                </div>
              </div>
              
              <div className="space-y-4">
                 <div>
                    <div className="flex justify-between text-[9px] font-black uppercase tracking-widest mb-1">
                      <span className="text-slate-400">Step {instantPayoutStatus.jobsCount} of 5 to Instant Payouts</span>
                      <span className="text-[#1B263B] font-black">{Math.round(instantPayoutStatus.jobsProgress * 100)}%</span>
                    </div>
                    <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-1000 ${instantPayoutStatus.unlocked ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]' : 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700]'}`}
                        style={{ width: `${instantPayoutStatus.jobsProgress * 100}%` }}
                      ></div>
                    </div>
                 </div>
                 
                 <div className="flex justify-between items-center px-1">
                    <div className="flex flex-col items-start">
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Employer Rating</span>
                      <span className={`text-[10px] font-black ${instantPayoutStatus.rating >= instantPayoutStatus.ratingGoal ? 'text-emerald-500' : 'text-slate-400'}`}>
                        {instantPayoutStatus.rating} / {instantPayoutStatus.ratingGoal}
                      </span>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">ID Verified</span>
                      <span className={`text-[10px] font-black ${instantPayoutStatus.verified ? 'text-emerald-500' : 'text-rose-500'}`}>
                        {instantPayoutStatus.verified ? 'YES' : 'NO'}
                      </span>
                    </div>
                 </div>
              </div>
              
              {instantPayoutStatus.unlocked ? (
                <div className="mt-4 p-2 bg-emerald-50 rounded-xl flex items-center justify-center gap-2">
                  <span className="text-emerald-600 text-[9px] font-black uppercase tracking-widest">PayShap & RTC Active</span>
                </div>
              ) : (
                <p className="mt-4 text-[8px] font-bold text-slate-400 italic leading-relaxed">
                  Complete all goals to unlock instant fund releases via PayShap.
                </p>
              )}
            </div>
          )}

          <div className="px-4 max-w-sm mx-auto mb-8">
            <div className="flex justify-between items-center mb-1.5 px-1">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.15em]">{tierProgress.label}</span>
              <span className="text-[9px] font-black text-[#D4AF37] uppercase tracking-widest">{Math.round(tierProgress.progress * 100)}%</span>
            </div>
            
            <div 
              onClick={() => triggerSnackBar(tierProgress.requirementsMsg)}
              className="relative h-3 w-full bg-[#121926] rounded-full overflow-hidden shadow-inner cursor-pointer group active:scale-[0.98] transition-transform"
            >
              <div className="absolute inset-0 flex justify-between px-[25%] pointer-events-none z-10">
                 <div className="h-full w-[1px] bg-white/10 relative">
                    <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-white/20 border border-white/5"></div>
                 </div>
                 <div className="h-full w-[1px] bg-white/10 relative" style={{ left: '50%' }}>
                    <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-white/20 border border-white/5"></div>
                 </div>
              </div>
              <div 
                className={`h-full bg-gradient-to-r from-[#D4AF37] to-[#FFD700] transition-all duration-1000 ease-out relative shadow-[0_0_10px_rgba(212,175,55,0.4)]
                  ${stats.currentTier === UserTier.PREMIUM ? 'animate-pulse' : ''}
                `}
                style={{ width: `${tierProgress.progress * 100}%` }}
              >
                 <div className="absolute inset-0 bg-white/10 animate-pulse"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 space-y-4 relative z-10">
        {isHustler && (
          <div className="bg-white rounded-[32px] p-6 shadow-sm border border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-xl shadow-inner ${profile.isAvailable ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                {profile.isAvailable ? '👁️' : '🕶️'}
              </div>
              <div>
                <h4 className="text-sm font-black text-slate-800 uppercase tracking-tight">Gig Availability</h4>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                  {profile.isAvailable ? 'Visible for Work' : 'Currently Offline'}
                </p>
              </div>
            </div>
            <button 
              onClick={() => handleToggleAvailability(!profile.isAvailable)}
              className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${profile.isAvailable ? 'bg-emerald-600' : 'bg-slate-200'}`}
            >
              <span className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${profile.isAvailable ? 'translate-x-5' : 'translate-x-0'}`}></span>
            </button>
          </div>
        )}

        <div className="bg-white rounded-[40px] p-7 shadow-xl shadow-slate-200/50 border border-slate-50">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-[#1B263B]">Switch Mode</h3>
            <div className="w-11 h-11 rounded-2xl flex items-center justify-center rotate-45" style={{ backgroundColor: `${activeThemeColor}15`, color: activeThemeColor }}>
              <svg className="w-5 h-5 -rotate-45" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
            </div>
          </div>
          <button 
            onClick={handleToggleRole}
            className="w-full group relative flex items-center justify-between p-5 rounded-3xl transition-all active:scale-[0.98] overflow-hidden shadow-lg bg-[#1B263B]"
          >
            <span className="text-white text-base font-black relative z-10">{isHustler ? 'Employer' : 'Hustler'} Mode</span>
            <div className="relative z-10 w-11 h-11 rounded-2xl flex items-center justify-center bg-white/10 text-white">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
            </div>
          </button>
        </div>
      </div>

      <div className="px-6 mt-8 space-y-3 relative z-10">
        {menuItems.map((item, i) => {
          if (item.hide) return null;
          return (
            <div key={i} className="relative group">
              <button 
                disabled={item.restricted}
                onClick={item.action}
                className={`w-full flex items-center justify-between p-5 rounded-[32px] bg-white border border-slate-50 shadow-sm transition-all
                  ${item.restricted ? 'opacity-60 grayscale' : 'hover:translate-x-1 active:scale-95'}
                  ${item.danger ? 'text-rose-500' : 'text-slate-700'}
                  `}
              >
                <div className="flex items-center gap-5">
                  <span className="text-xl filter grayscale-[0.2]">{item.icon}</span>
                  <span className="font-black text-sm uppercase tracking-tight">{item.label}</span>
                </div>
                {!item.restricted && <svg className="text-slate-200 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M9 5l7 7-7 7" /></svg>}
                {item.restricted && <svg className="w-4 h-4 text-amber-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" /></svg>}
              </button>
            </div>
          );
        })}
      </div>

      <div className="mt-16 text-center pb-12 relative z-10">
        <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.6em]">SwiftHustle SA v2.5</p>
      </div>
    </div>
  );
};

export default AccountPage;