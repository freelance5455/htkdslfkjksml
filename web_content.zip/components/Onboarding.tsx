
import React, { useState } from 'react';

interface OnboardingProps {
  onComplete: () => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);

  const slides = [
    {
      title: "Real-time Gig Radar",
      description: "Find jobs or skilled hustlers in your immediate vicinity using our interactive map.",
      icon: "📍",
      color: "bg-blue-600"
    },
    {
      title: "Secure Escrow",
      description: "Payments are held safely in escrow until the work is done and approved. No more payment risks.",
      icon: "🛡️",
      color: "bg-emerald-600"
    },
    {
      title: "Safety First",
      description: "Integrated panic button and verified user profiles ensure a safe working environment.",
      icon: "🚨",
      color: "bg-rose-600"
    }
  ];

  const handleNext = () => {
    if (step < slides.length - 1) {
      setStep(step + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/80 backdrop-blur-md p-6">
      <div className="bg-white rounded-[40px] w-full max-w-sm overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in duration-300">
        <div className={`${slides[step].color} h-48 flex items-center justify-center transition-colors duration-500`}>
          <span className="text-8xl">{slides[step].icon}</span>
        </div>
        
        <div className="p-8 text-center flex-1">
          <h2 className="text-2xl font-black text-gray-900 mb-4">{slides[step].title}</h2>
          <p className="text-gray-500 text-sm leading-relaxed mb-10">
            {slides[step].description}
          </p>

          <div className="flex justify-center gap-2 mb-10">
            {slides.map((_, i) => (
              <div key={i} className={`h-2 rounded-full transition-all duration-300 ${i === step ? 'w-8 bg-emerald-500' : 'w-2 bg-gray-200'}`}></div>
            ))}
          </div>

          <button 
            onClick={handleNext}
            className="w-full bg-gray-900 text-white py-4 rounded-2xl font-bold hover:bg-emerald-600 transition-colors shadow-lg active:scale-95 transition-transform"
          >
            {step === slides.length - 1 ? 'Get Started' : 'Next'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Onboarding;
