# JobFinder AI – Android starter project

This is a first Android Studio project containing a mobile-friendly JobFinder AI app.

## Included
- Job category search and links to South African job-search sources
- CV draft builder
- Cover-letter draft builder
- Interview practice questions and tips
- Android WebView shell with external links opened in the browser

## Important limitations
- This version does not contain a live job-feed API, user accounts, cloud storage, push notifications or AI-generated responses.
- Job categories are search prompts, not confirmed vacancies. Users are directed to external sources to check current listings.
- The app has not been signed, built or tested on a physical Android device.

## Build in Android Studio
1. Install the latest stable Android Studio.
2. Extract this ZIP and open the `JobFinderAI_Android` folder.
3. Allow Gradle sync and install any requested Android SDK platform/build tools.
4. Select **Build > Generate Signed Bundle / APK**.
5. Choose **Android App Bundle (AAB)** for Play Store submission.
6. Create and safely back up your signing key. Do not share it.
7. Complete Play Console's current app-content, privacy, testing and release requirements before publishing.

Package ID: `za.co.jobfinderai`
Version: `1.0` (versionCode 1)
Target SDK: 35

Before public release, add a privacy policy if required by the data practices and Play Console declarations, test on multiple screen sizes, and verify every external job-source link.
