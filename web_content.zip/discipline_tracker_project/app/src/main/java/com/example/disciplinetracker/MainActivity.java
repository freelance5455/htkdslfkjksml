package com.example.disciplinetracker;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Window w=getWindow(); w.setStatusBarColor(0xFF111111); w.setNavigationBarColor(0xFF111111);
    WebView view=new WebView(this); view.setBackgroundColor(0xFFF3F4F6);
    WebSettings s=view.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true); s.setAllowContentAccess(false);
    view.setWebViewClient(new WebViewClient()); view.loadUrl("file:///android_asset/index.html");
    setContentView(view);
  }
  @Override public void onBackPressed() { super.onBackPressed(); }
}
