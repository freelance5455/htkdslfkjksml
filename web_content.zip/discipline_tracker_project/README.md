# 24-Day Discipline Tracker (Android)

An offline-first Android WebView app inspired by the supplied tracker sheet.

## Features
- 24-day overview with daily completion percentage
- Editable routine and daily task checklists
- Daily notes and final reflection
- Four six-day review averages
- Local browser storage only; no account, network permission, or internet required

## Build an APK
1. Install Android Studio (with Android SDK Platform 35 and JDK 17 or newer).
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

The build environment used to prepare this source bundle did not include the Android SDK/Gradle, so a compiled APK could not be produced here. The project is ready to open and build in Android Studio.
