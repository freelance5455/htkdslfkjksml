# PingMe 🔔 : transformer le code en application Android

`www/index.html` contient toute l'application. Le reste du dossier sert à l'emballer en vraie application Android (APK), avec de **vraies notifications système** :

- elles arrivent même si PingMe est fermé et même sans Internet ;
- elles font sonner et vibrer le téléphone selon tes réglages dans PingMe (Son / Vibration) ;
- elles respectent toujours le mode silencieux et « Ne pas déranger ».

## Obtenir l'APK sans rien installer (GitHub, gratuit, ~15 min)

1. Crée un compte sur https://github.com et clique sur **New repository**. Nom : `pingme`, case **Private** cochée, puis **Create repository**.
2. Clique sur **uploading an existing file**. Glisse **tout le contenu** du dossier `PingMe` (`www`, `android-res`, `package.json`, `capacitor.config.json`…), puis **Commit changes**.
3. Le dossier caché `.github` passe rarement par glisser-déposer, alors ajoute-le à la main :
   **Add file → Create new file**, tape comme nom `.github/workflows/build-apk.yml`, colle le contenu du fichier `build-apk.yml`, puis **Commit changes**.
4. Ouvre l'onglet **Actions**. La compilation « Construire l'APK PingMe » démarre toute seule (environ 8 minutes). Quand elle est verte ✅, clique dessus et télécharge **PingMe-APK** en bas de la page.
5. Sur ton téléphone, dézippe le fichier, ouvre `app-debug.apk` et accepte l'installation (Android demande d'autoriser « sources inconnues » une fois).

## Au premier lancement

- Crée ton compte, puis **autorise les notifications** quand Android le demande.
- Touche **Autoriser** sur la carte « Rappels pile à l'heure ». Sinon, Android peut retarder un rappel de quelques minutes.
- Dans **Paramètres → Envoyer une notification test**, verrouille ton téléphone : la notification arrive 5 secondes plus tard.

### Spécial Samsung (Galaxy A35)

Samsung met en veille les applications qu'il juge peu utilisées, ce qui peut bloquer les rappels. Pour l'éviter :
**Paramètres → Batterie → Limites d'utilisation en arrière-plan →** vérifie que PingMe n'est **pas** dans « Applications en veille » ou « en veille prolongée ». Ajoute-le si possible à « Applications jamais en veille ».

## Bon à savoir

- Les comptes et les rappels sont enregistrés **sur le téléphone**. Le mot de passe est haché (PBKDF2-SHA256), jamais stocké en clair. Désinstaller l'application efface tout.
- « Mot de passe oublié » ne peut pas envoyer d'e-mail tant qu'il n'y a pas de serveur en ligne.
- Ouvert dans un simple navigateur ou dans un convertisseur « site → appli », `index.html` fonctionne, mais les notifications ne marchent **que pendant que l'appli est ouverte**. C'est une limite des navigateurs, d'où ce kit.
- L'APK « debug » suffit pour ton téléphone. Pour le Play Store, il faudra une version signée.
