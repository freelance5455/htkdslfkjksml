package com.zehani.salespro

import android.app.Activity
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.Context
import android.view.ViewGroup
import android.widget.FrameLayout

class MainActivity : Activity() {
    private lateinit var webView: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(PrintBridge(this), "AndroidPrint")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }
    class PrintBridge(private val activity: Activity) {
        @JavascriptInterface fun printPage() {
            activity.runOnUiThread {
                val manager = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = (activity.findViewById<android.view.ViewGroup>(android.R.id.content)
                    .getChildAt(0) as WebView).createPrintDocumentAdapter("ZEHANI_SALES_REPORT")
                manager.print("ZEHANI SALES REPORT", adapter, PrintAttributes.Builder().build())
            }
        }
    }
    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}