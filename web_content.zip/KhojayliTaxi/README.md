# Khojayli Taxi Pro — Android (APK)

Bu loyiha `taxi-1.html` ni WebView orqali APK ga o'raydi.

## Variant 1 — GitHub orqali (kompyuterda hech narsa o'rnatmasdan)
1. github.com da yangi repo oching va shu papkadagi hamma fayllarni yuklang (`.github` papkasi bilan).
2. Repo -> **Actions** -> **Build APK** -> **Run workflow**.
3. Tugagach, natija sahifasidan **KhojayliTaxi-apk** ni yuklab oling, ichidan `app-debug.apk` chiqadi.
4. Telefonga o'tkazib o'rnating ("Noma'lum manbalardan o'rnatish"ga ruxsat bering).

## Variant 2 — Android Studio
1. Android Studio -> **Open** -> shu papkani tanlang, sinxronlash tugashini kuting.
2. **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

## HTML ni yangilash
`app/src/main/assets/index.html` ni almashtiring va qayta build qiling.
