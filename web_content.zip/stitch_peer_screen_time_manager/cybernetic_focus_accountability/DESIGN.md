---
name: Cybernetic Focus & Accountability
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#faf3ff'
  on-tertiary: '#3c0091'
  tertiary-container: '#e1d2ff'
  on-tertiary-container: '#6d3bd7'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.08em
  counter-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  counter-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 3rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
---

## Brand & Style

This design system channels an authoritative, high-tech cybernetic aesthetic tailored for deep digital discipline, focused study environments, and real-time social accountability pacts. It merges the ergonomics of modern enterprise-grade utility with luminous, telemetry-driven UI cues.

### Brand Personality & Emotional Response
The interface evokes hyper-focus, technological precision, and mutual digital vigilance. Users should feel empowered, lucid, and in control of their behavioral loops. The atmosphere departs from punitive, clinical blockers to project the feel of a command deck: crisp, responsive, stealthy, and luminous.

### Design Movement: Cyber-Glass Minimalism
The visual execution relies on a refined dark aesthetic paired with micro-luminous accents:
- **OLED Surface Depths**: Deep Obsidian and Void bases (#0B0F17, #111827) provide maximum contrast while minimizing ocular strain during night and focus sessions.
- **Controlled Luminescence**: Neon cyan, lime, and violet signals guide status feedback without visual noise. Luminescence is earned—reserved strictly for operational states, active timers, locked statuses, and real-time pact indicators.
- **Subtle Glass Structuring**: Semi-translucent panels with fine 1px neon-tinted boundary strokes convey structural discipline and modern tactile polish.

## Colors

The color system is calibrated for OLED dark performance, employing high-contrast telemetry signaling over tiered dark backgrounds.

### Core Swatches
- **Primary (`#00F0FF`)**: Electric Cyan. Anchors focal interactions, active pact trackers, core CTAs, and master progress indicators.
- **Secondary (`#10B981`)**: Neon Emerald / Matrix Lime. Signifies active focus milestones, unlocked states, steady streaks, and peer check-ins.
- **Tertiary (`#8B5CF6`)**: Vivid Cyber Violet. Denotes collaborative accountability pods, study room tags, and passive social telemetry.
- **Alert / Lockdown (`#F43F5E`)**: Critical Rose-Amber. Reserved strictly for active app lockouts, session abort penalties, emergency overrides, and boundary violations.

### Surface Architecture
- **Surface Canvas**: `#0B0F17` (Deep Obsidian Void)
- **Surface Base / Card**: `#111827` (Sub-canvas structural plate)
- **Surface Layer 1**: `#162032` (Interactive card base & controls)
- **Surface Highlight**: `#1E293B` (Dropdowns, modals, floating panels)
- **Border Default**: `rgba(255, 255, 255, 0.08)`
- **Border Active / Glowing**: `rgba(0, 240, 255, 0.35)`

### Typography & Content Color
- **Text High-Contrast**: `#F8FAFC`
- **Text Medium-Contrast**: `#94A3B8`
- **Text Muted / Subtle**: `#64748B`

## Typography

The typographic hierarchy centers on crisp geometric legibility, balancing systematic text scales with strict tabular numeric pacing.

### Tabular Figures & Numerics
All countdown clocks, time-budget indicators, lockout telemetry, and streak counters enforce `font-feature-settings: "tnum" 1, "cv05" 1` alongside tabular variants. This guarantees zero optical jitter during real-time countdowns.

### Uppercase Tracking
Sub-labels, status indicator categories, and telemetry descriptors use `label-sm` or `label-md` in full uppercase with wider letter spacing (`0.04em` to `0.08em`) to mimic instrumentation dashboards without overpowering body context.

## Layout & Spacing

A strictly rhythmic 8-point base grid drives density across dashboard cards, accountability grids, and telemetric counters.

### Responsive Breakpoints
- **Compact (Mobile: < 640px)**: 4-column layout with 16px (`1rem`) outer margins and 16px gutters. Timer modules span full width. Pacts stack vertically.
- **Medium (Tablet: 640px - 1024px)**: 8-column layout with 24px (`1.5rem`) outer margins and 24px gutters. Splits active session stats and pact member grids side by side.
- **Expanded (Desktop: > 1024px)**: 12-column layout capped at 1280px maximum content width. 48px (`3rem`) margins with modular cards adhering to 4-column telemetry panels and 8-column tracking graphs.

### Spacing Consistency
All layout intervals derive exclusively from the `space-*` scale. Content blocks avoid arbitrary top and bottom margins, relying instead on auto-flex gap distributions calibrated to `space-sm` (tight metadata groupings) and `space-md` / `space-lg` (container partitions).

## Elevation & Depth

Depth is established through translucent dark layers and subtle colored photon back-scattering, bypassing blunt gray drop shadows.

### Surface Tiers
- **Tier 0 (Canvas Base)**: `#0B0F17`. The foundational void plane.
- **Tier 1 (Surface Panel)**: `#111827` at `85%` opacity with a `12px` backdrop blur. Edged with a 1px border of `rgba(255, 255, 255, 0.07)`.
- **Tier 2 (Floating Action Modules & Modals)**: `#162032` at `90%` opacity with a `20px` backdrop blur. Supported by an outer ambient shadow of `0 12px 32px -8px rgba(0, 0, 0, 0.65)`.

### Luminous Accent Elevation
Critical elements utilize targeted photon halos instead of conventional shadows:
- **Active Focus Aura**: `0 0 24px -4px rgba(0, 240, 255, 0.35)`.
- **Lockdown Warning Halo**: `0 0 28px -4px rgba(244, 63, 94, 0.45)`.
- **Streak & Success Glow**: `0 0 20px -4px rgba(16, 185, 129, 0.35)`.

## Shapes

The design system employs a geometric radius profile (Level 2) that marries structural digital sharpness with comfortable handling ergonomics.

### Corner Radii Guidelines
- **Base Geometry (`0.5rem` / `8px`)**: Input controls, list elements, compact chips, and segment tabs.
- **Container Surfaces (`1rem` / `16px`)**: Standard dashboard cards, session meters, pact monitor plates, and popup overlays.
- **Elevated Modals (`1.5rem` / `24px`)**: Full-screen lockout dialogs, focus completion sheets, and pact creation wizards.
- **Terminal Radii (`9999px`)**: Interactive action badges, pill chips, avatar frames, and continuous status lights.

## Components

### Buttons
- **Primary Cyber Button**: Height 44px (Compact) or 52px (Prominent). Solid `#00F0FF` background, `#0B0F17` ultra-bold label. Hover triggers a `0 0 18px rgba(0, 240, 255, 0.5)` halo and scale to 1.01.
- **Secondary Ghost**: Dark translucent plate (`#111827`), 1px border (`rgba(0, 240, 255, 0.3)`), cyan text. Active press scales down to 0.98 with inner surface brightening.
- **Destructive / Abort**: Translucent rose-tinted plate with 1px border (`#F43F5E`). Used strictly for broken streaks or leaving an active pact.

### Circular Focus Progress Rings
- Vector SVG track with dual-stroke engineering: a muted charcoal under-rail (`#1E293B`, 8px stroke) overlaid by an animated gradient path running from Electric Cyan (`#00F0FF`) to Matrix Lime (`#10B981`).
- The ring terminator hosts a 10px circular node with a multi-layered neon glow that highlights current session completion percentage.

### Status Chips & Badges
- 24px to 28px pill form with high-density padding (`space-xs` vertical, `space-md` horizontal).
- Dark semi-translucent fill carrying 12% accent color opacity.
- Left-aligned 6px pulsating dot indicating live user status: Pulsing Cyan (Focusing), Solid Lime (Goal Met), Blinking Red (Pact Breached / In Lockdown).

### Cards & Pact Telemetry Modules
- Backed by Tier 1 glass panels (`#111827`, 85% opacity, 12px blur) bordered by 1px `rgba(255, 255, 255, 0.08)`.
- Cards featuring an active focus partner highlight the top border edge with an animated, slim 1px gradient accent (`#00F0FF` to `#8B5CF6`).

### Futuristic Toggle Switches
- Track: 48px width by 26px height, pill form, deep charcoal (`#1E293B`) when inactive.
- Active Track: High-contrast `#00F0FF` background.
- Thumb: 20px solid white circle, elevated with ambient drop-shadow. Sliding includes a brief elastic spring snap (`cubic-bezier(0.34, 1.56, 0.64, 1)`).

### Input Fields
- Dark structured surface (`#162032`), 1px neutral stroke (`rgba(255, 255, 255, 0.12)`), text rendered in `#F8FAFC`.
- Focus state switches the stroke to 1px `#00F0FF` with a subtle `0 0 10px rgba(0, 240, 255, 0.2)` outer ring.
- Numeric time input fields lock to monospaced numeric styling (`counter-sm`) with integrated stepper increments.

### Selection Controls (Checkboxes & Radios)
- Square (checkbox) and circular (radio) silhouettes with 18px base footprint.
- Inactive: 1px border of `rgba(255, 255, 255, 0.25)` over transparent background.
- Active: Filled `#00F0FF` with deep obsidian checkmark icon or center dot, accompanied by an instantaneous electric cyan ping animation upon state switch.