@echo off
cd /d "%~dp0server"
where node >nul 2>nul || (echo Node.js is not installed. Get it from https://nodejs.org & pause & exit /b)
node server.js
pause
