#!/bin/sh
cd "$(dirname "$0")/server" || exit 1
command -v node >/dev/null || { echo "Node.js is not installed. Get it from https://nodejs.org"; exit 1; }
node server.js
