#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is required. In Termux: pkg install gradle"
  exit 1
fi
gradle --no-daemon clean assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
if [ ! -f "$APK" ]; then echo "APK was not produced"; exit 2; fi
mkdir -p ../../build-output
cp "$APK" ../../build-output/Lavish-POS-debug.apk
echo "APK: $(realpath ../../build-output/Lavish-POS-debug.apk)"
