package com.lavish.pos;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

/** Lavish POS: a thin shell that opens the shop's store server full screen. */
public class MainActivity extends Activity {
    private WebView web;
    private SharedPreferences prefs;
    private PermissionRequest pendingCamera;

    public class Bridge {
        @JavascriptInterface
        public void changeServer() {
            runOnUiThread(new Runnable() { public void run() { askServer(); } });
        }
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("lavish", MODE_PRIVATE);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#FFF8F5"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        web.addJavascriptInterface(new Bridge(), "LavishApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showError(String.valueOf(e.getDescription()));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        String host = Uri.parse(prefs.getString("url", "")).getHost();
                        if (host == null || !host.equals(request.getOrigin().getHost())) { request.deny(); return; }
                        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            request.grant(request.getResources());
                        } else {
                            pendingCamera = request;
                            requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
                        }
                    }
                });
            }
        });

        String url = prefs.getString("url", "");
        if (url.isEmpty()) askServer(); else web.loadUrl(url);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (pendingCamera != null) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) pendingCamera.grant(pendingCamera.getResources());
            else pendingCamera.deny();
            pendingCamera = null;
        }
    }

    private void askServer() {
        final EditText box = new EditText(this);
        box.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        String saved = prefs.getString("url", "");
        box.setText(saved.isEmpty() ? "https://" : saved);
        AlertDialog.Builder b = new AlertDialog.Builder(this)
            .setTitle("Store server address")
            .setMessage("Example: https://192.168.1.20:8080")
            .setView(box)
            .setPositiveButton("Connect", new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface d, int w) {
                    String u = box.getText().toString().trim();
                    if (u.isEmpty()) return;
                    if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
                    prefs.edit().putString("url", u).apply();
                    web.loadUrl(u);
                }
            });
        if (!saved.isEmpty()) b.setNegativeButton("Cancel", null); else b.setCancelable(false);
        b.show();
    }

    private void showError(String why) {
        String url = prefs.getString("url", "");
        String html = "<html><body style='font-family:sans-serif;padding:24px;background:#FFF8F5;color:#2B1B2E'>"
            + "<h2>Can't reach the store server</h2><p>" + why.replace("<", "&lt;") + "</p>"
            + "<p>Check that the shop PC is on and this phone is on the shop Wi-Fi.</p>"
            + "<p><a href='" + url.replace("'", "") + "'>Try again</a></p>"
            + "<p><button onclick='LavishApp.changeServer()' style='padding:12px 18px;font-size:16px'>Change server address</button></p>"
            + "</body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
