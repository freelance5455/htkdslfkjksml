'use strict';
// Lavish Beauty and Deco POS: store server (zero dependencies). Serves the app and the API.
const http=require('http'),https=require('https'),net=require('net'),fs=require('fs'),os=require('os'),path=require('path'),crypto=require('crypto');
try{fs.readFileSync(path.join(__dirname,'settings.env'),'utf8').split(/\r?\n/).forEach(l=>{const m=l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);if(m&&!(m[1] in process.env))process.env[m[1]]=m[2]})}catch(e){}
const PORT=+process.env.PORT||8080,DB=process.env.DB||path.join(__dirname,'data.json'),PUB=path.join(__dirname,'public');
const LOCK_MS=+process.env.LOCK_MS||90000,SHIFT_H=+process.env.SHIFT_HOURS||12;
const hrs=h=>Math.min(16,Math.max(+h||SHIFT_H,0.0005));
const devLive=d=>!!d&&d.st==='ACTIVE'&&(!d.exp||Date.now()<d.exp);
const devWhy=d=>d.st!=='ACTIVE'?'This gadget is disabled':'Pairing ended with the shift. Ask the Owner to renew it';
const CAPS=['sell','till','discount','refundReq','refundOk','restock','finance','reports','emps','devices','credit','stockOk','view'];
const ROLES={Owner:CAPS,Manager:['sell','till','discount','refundReq','refundOk','restock','finance','reports','credit','stockOk','view'],Cashier:['sell','till','refundReq','credit','view'],'Stock clerk':['restock','view'],Finance:['finance','reports','credit','view']};
const can=(r,c)=>(ROLES[r]||[]).includes(c);
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const scr=(pin,salt)=>crypto.scryptSync(String(pin),salt,32).toString('hex');
const eq=(a,b)=>{const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&crypto.timingSafeEqual(x,y)};
let db;
const save=()=>{fs.writeFileSync(DB+'.tmp',JSON.stringify(db));fs.renameSync(DB+'.tmp',DB)};
function seed(){const used=new Set();
 const mk=(id,name,role)=>{let pin;do pin=String(crypto.randomInt(100000,1000000));while(used.has(pin));used.add(pin);const salt=crypto.randomBytes(16).toString('hex');console.log('  '+name.padEnd(8)+role.padEnd(13)+pin);return{id,name,role,on:1,salt,h:scr(pin,salt),fails:0,lock:0}};
 console.log('First run. Sign-in PINs (shown once, stored hashed):');
 db={secret:crypto.randomBytes(32).toString('hex'),emps:[mk(1,'Carol','Owner'),mk(2,'Brian','Manager'),mk(3,'Amina','Cashier'),mk(4,'Dan','Stock clerk'),mk(5,'Eve','Finance')],
  prods:[['Rose glow serum',2400,18],['Velvet matte lipstick',1500,4],['Argan hair oil',1800,25],['Vanilla soy candle',1200,3],['Ceramic bud vase',2200,12],['Rattan wall mirror',5600,0],['Nail lacquer set',1400,30],['Shea body butter',950,40],['Pampas grass stems',800,22],['Dried flower bundle',1650,9],['Bamboo brush kit',2100,15],['Linen room spray',1100,2]].map((x,i)=>({id:i+1,n:x[0],p:x[1],s:x[2]})),
  sales:{},seq:1,devs:[],pairs:{},audit:[],used:{}};save()}
if(fs.existsSync(DB))db=JSON.parse(fs.readFileSync(DB));else seed();
db.refunds=db.refunds||[];db.locks=db.locks||{};
db.fin=db.fin||[];db.fk=db.fk||1;db.pos=db.pos||[];db.mv=db.mv||[];db.customers=db.customers||[];db.cled=db.cled||[];db.cid=db.cid||1;db.counts=db.counts||[];db.mp=db.mp||{};db.mpq=db.mpq||{};db.mused=db.mused||{};db.settings=db.settings||{};
db.sups=db.sups||[{id:1,name:'Nairobi Beauty Wholesalers',owed:0},{id:2,name:'Deco House Ltd',owed:0},{id:3,name:'Glow Imports',owed:0}];
const lockLive=(L,n)=>{if(!L)return false;const d=L.dev&&db.devs.find(x=>x.id===L.dev);return d?devLive(d):n-L.seen<LOCK_MS};
const sign=o=>{const p=Buffer.from(JSON.stringify(o)).toString('base64url');return p+'.'+crypto.createHmac('sha256',db.secret).update(p).digest('base64url')};
const unsign=t=>{if(typeof t!=='string')return null;const[p,s]=t.split('.');if(!p||!s)return null;if(!eq(s,crypto.createHmac('sha256',db.secret).update(p).digest('base64url')))return null;try{const o=JSON.parse(Buffer.from(p,'base64url'));return o.x>Date.now()?o:null}catch{return null}};
function audit(who,a){const prev=db.audit.length?db.audit[db.audit.length-1].h:'0',t=new Date().toISOString();db.audit.push({t,who,a,prev,h:sha(prev+t+who+a)})}
const chainOk=()=>db.audit.every((e,i)=>e.prev===(i?db.audit[i-1].h:'0')&&e.h===sha(e.prev+e.t+e.who+e.a));
const hits={};const limited=ip=>{const n=Date.now(),a=hits[ip]=(hits[ip]||[]).filter(t=>n-t<6e4);a.push(n);return a.length>30};
const send=(res,c,o)=>{res.writeHead(c,{'content-type':'application/json'});res.end(JSON.stringify(o))};
const body=req=>new Promise(ok=>{let d='';req.on('data',c=>{d+=c;if(d.length>1e6)req.destroy()});req.on('end',()=>{try{ok(d?JSON.parse(d):{})}catch{ok({})}})});
const stock=()=>Object.fromEntries(db.prods.map(p=>[p.id,p.s]));
function auth(req,cap){const t=unsign((req.headers.authorization||'').replace(/^Bearer /,''));if(!t||t.k!=='u')return{e:[401,'Sign in required']};
 const u=db.emps.find(e=>e.name===t.n&&e.on&&e.role===t.r);if(!u)return{e:[401,'Session is no longer valid']};
 if(cap&&!can(u.role,cap)){audit(u.name,'BLOCKED '+cap+' as '+u.role);save();return{e:[403,'Your role cannot do that']}}return{u}}
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript','.png':'image/png','.webmanifest':'application/manifest+json','.txt':'text/plain'};
function fin(type,acct,amt,dir,ref,by,till){db.fin.push({id:db.fk++,type,acct,amt,dir,ref,by,till:till||0,at:Date.now()});if(db.fin.length>5000)db.fin.shift()}
function mv(pid,d,src,by){db.mv.push({t:Date.now(),pid,d,src,by});if(db.mv.length>500)db.mv.shift()}
const jreq=(u,o,body)=>new Promise((ok,no)=>{const r=https.request(u,o,res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{try{ok(JSON.parse(d))}catch{no(new Error('Bad reply'))}})});r.on('error',no);r.setTimeout(15000,()=>r.destroy(new Error('Timeout')));if(body)r.write(JSON.stringify(body));r.end()});
const MP=()=>({key:process.env.MPESA_KEY,secret:process.env.MPESA_SECRET,code:process.env.MPESA_SHORTCODE,partyb:process.env.MPESA_PARTYB||process.env.MPESA_SHORTCODE,pass:process.env.MPESA_PASSKEY,env:process.env.MPESA_ENV==='live'?'api.safaricom.co.ke':'sandbox.safaricom.co.ke',type:process.env.MPESA_TYPE||'CustomerPayBillOnline',cb:process.env.MPESA_CALLBACK||'https://example.com/lavish-unused',sim:process.env.MPESA_SIM==='1'});
const mpToken=async m=>(await jreq('https://'+m.env+'/oauth/v1/generate?grant_type=client_credentials',{method:'GET',headers:{authorization:'Basic '+Buffer.from(m.key+':'+m.secret).toString('base64')}})).access_token;
const stamp=()=>new Date().toISOString().replace(/\D/g,'').slice(0,14);
const phone254=p=>{p=String(p||'').replace(/\D/g,'');if(/^0[17]\d{8}$/.test(p))return '254'+p.slice(1);if(/^254[17]\d{8}$/.test(p))return p;return null};
function receipt(sale,drawer){const C=+process.env.PRINT_COLS||42,b=[],raw=(...x)=>b.push(Buffer.from(x)),t=s=>b.push(Buffer.from(String(s).replace(/[^\x20-\x7e]/g,'?')+'\n','latin1'));
 const row=(l,r)=>{l=String(l);r=String(r);const room=C-r.length-1;if(l.length>room)l=l.slice(0,room);return l+' '.repeat(C-l.length-r.length)+r};
 raw(0x1b,0x40);raw(0x1b,0x61,1);raw(0x1b,0x45,1);t('Lavish Beauty and Deco');raw(0x1b,0x45,0);t(new Date(sale.at).toLocaleString());t(sale.id+'  Till '+sale.till+'  '+sale.by);raw(0x1b,0x61,0);t('-'.repeat(C));
 sale.items.forEach(i=>t(row(i.q+' x '+i.n,Math.round(i.q*i.p).toLocaleString('en-US'))));t('-'.repeat(C));
 if(sale.disc)t(row('Discount '+sale.disc+'%',''));raw(0x1b,0x45,1);t(row('TOTAL KES',Math.round(sale.total).toLocaleString('en-US')));raw(0x1b,0x45,0);t('Paid by '+sale.pay+(sale.pay==='Credit'?' (on account)':''));
 raw(0x1b,0x61,1);t('Thank you, come again');t('');t('');raw(0x1d,0x56,0x42,0x00);if(drawer)raw(0x1b,0x70,0,25,250);return Buffer.concat(b)}
const sendPrinter=buf=>new Promise((ok,no)=>{const p=db.settings.printer||{};if(!p.host)return no(new Error('No printer is set up yet'));
 const s=net.connect({host:p.host,port:+p.port||9100,timeout:4000},()=>s.end(buf));s.on('close',()=>ok());s.on('timeout',()=>{s.destroy();no(new Error('Printer not reachable'))});s.on('error',()=>no(new Error('Printer not reachable')))});
async function handle(req,res){
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','no-referrer');
 res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'");
 const p=new URL(req.url,'http://x').pathname,POST=req.method==='POST',ip=req.socket.remoteAddress;
 const fail=a=>send(res,a.e[0],{error:a.e[1]});
 if(p==='/api/ping')return send(res,200,{ok:1,names:db.emps.filter(e=>e.on).map(e=>e.name)});
 if(p==='/api/login'&&POST){const b=await body(req);if(limited(ip))return send(res,429,{error:'Too many attempts. Wait a minute.'});
  const e=db.emps.find(x=>x.name===b.name&&x.on);if(!e)return send(res,401,{error:'Wrong name or PIN'});
  if(e.lock>Date.now())return send(res,423,{error:'Account locked. Try again in 5 minutes.'});
  if(!eq(scr(b.pin||'',e.salt),e.h)){e.fails++;if(e.fails>=5){e.lock=Date.now()+3e5;e.fails=0;audit(e.name,'Account locked after 5 wrong PINs')}save();return send(res,401,{error:'Wrong name or PIN'})}
  e.fails=0;audit(e.name,'Signed in');save();
  return send(res,200,{token:sign({k:'u',n:e.name,r:e.role,x:Date.now()+SHIFT_H*36e5}),name:e.name,role:e.role,emps:db.emps.map(x=>({id:x.id,name:x.name,role:x.role,on:x.on})),stock:stock()})}
 if(p==='/api/state'){const a=auth(req,'view');return a.e?fail(a):send(res,200,{stock:stock()})}
 if(p==='/api/approval'&&POST){const a=auth(req,'sell');if(a.e)return fail(a);if(limited(ip))return send(res,429,{error:'Too many attempts'});
  const b=await body(req),m=db.emps.find(x=>x.on&&can(x.role,'discount')&&eq(scr(b.pin||'',x.salt),x.h));
  if(!m)return send(res,403,{error:'PIN not accepted'});audit(m.name,'Approved a discount for '+a.u.name);save();
  return send(res,200,{token:sign({k:'a',i:crypto.randomUUID(),by:m.name,x:Date.now()+12e4}),by:m.name})}
 if(p==='/api/sales/sync'&&POST){const a=auth(req,'sell');if(a.e)return fail(a);
  const dv=req.headers['x-device'],dd=dv&&db.devs.find(x=>x.id===dv);if(dd&&dd.st!=='ACTIVE'){audit(a.u.name,'BLOCKED sale upload from disabled gadget '+dd.name);save();return send(res,403,{error:'This gadget is disabled'})}
  const b=await body(req),out=[];
  for(const s of(Array.isArray(b.sales)?b.sales:[]).slice(0,200)){
   if(!s||typeof s.key!=='string'||s.key.length>120||!Array.isArray(s.items))continue;
   const ex=db.sales[s.key];if(ex){out.push({key:s.key,status:ex.status,server_id:ex.id,err:ex.err,dup:1});continue}
   let err='',sub=0;const items=[],need={};
   for(const it of s.items.slice(0,100)){const pr=db.prods.find(x=>x.id===+it.id),q=Math.floor(+it.q);if(!pr||!(q>0)){err='Invalid item';break}items.push({id:pr.id,n:pr.n,q,p:pr.p});sub+=pr.p*q;need[pr.id]=(need[pr.id]||0)+q}
   const disc=+s.disc;if(!err&&!items.length)err='Empty sale';
   if(!err&&![0,5,10,20].includes(disc))err='Invalid discount';
   if(!err&&!['Cash','M-Pesa','Card','Credit'].includes(s.pay))err='Invalid payment method';
   if(!err&&disc>10&&!can(a.u.role,'discount')){const t=unsign(s.approval);if(!t||t.k!=='a'||db.used[t.i])err='Discount over 10% needs manager approval';else db.used[t.i]=1}
   if(!err)for(const id in need){const pr=db.prods.find(x=>x.id==id);if(pr.s<need[id]){err='Not enough stock for '+pr.n;break}}
   const total=sub*(1-disc/100),mr=String(s.mref||'').trim(),cu=s.pay==='Credit'?db.customers.find(x=>x.id===+s.cust):null;let mq=null;
   if(!err&&s.pay==='Credit'){if(!can(a.u.role,'credit'))err='Your role cannot sell on credit';else if(!cu)err='Choose a customer for a credit sale';else if(cu.bal+total>cu.limit+0.001)err='Over the credit limit for '+cu.name}
   if(!err&&s.pay==='M-Pesa'){if(!/^[A-Za-z0-9_\-]{8,60}$/.test(mr))err='M-Pesa code is required';else if(db.mused[mr])err='M-Pesa code already used';else{mq=db.mp[mr];if(mq&&mq.amt<Math.round(total))err='M-Pesa amount is less than the total'}}
   const id='S'+String(db.seq++).padStart(5,'0');if(!err)for(const k in need)db.prods.find(x=>x.id==k).s-=need[k];
   if(!err){for(const k in need)mv(+k,-need[k],'Sale '+id,a.u.name);const tl=+s.till||0;
    if(s.pay==='Cash')fin('CASH_SALE','Cash',total,1,id,a.u.name,tl);else if(s.pay==='M-Pesa'){fin('MPESA_SALE','M-Pesa',total,1,id+' '+mr,a.u.name,tl);db.mused[mr]=id}else if(s.pay==='Card')fin('CARD_SALE','Card',total,1,id,a.u.name,tl);
    else{cu.bal+=total;db.cled.push({cid:cu.id,type:'SALE',amt:total,ref:id,by:a.u.name,at:Date.now()})}}
   const rec={id,status:err?'CONFLICT':'SYNCED',err,by:a.u.name,till:+s.till||0,dev:dv||'',items,disc,total:sub*(1-disc/100),pay:s.pay,cust:cu?cu.id:0,mref:mr,verified:!!mq,at:new Date().toISOString()};
   db.sales[s.key]=rec;audit(a.u.name,(err?'REJECTED ':'Sale ')+id+' KES '+Math.round(rec.total)+(err?' ('+err+')':''));out.push({key:s.key,status:rec.status,server_id:id,err})}
  save();return send(res,200,{results:out,stock:stock()})}
 if(p==='/api/pair/create'&&POST){const a=auth(req,'devices');if(a.e)return fail(a);const b=await body(req),code=String(crypto.randomInt(100000,1000000));
  db.pairs[code]={name:String(b.name||'Gadget').slice(0,40),till:+b.till||1,hrs:hrs(b.hours),exp:Date.now()+6e5};audit(a.u.name,'Pairing code created for '+db.pairs[code].name);save();return send(res,200,{code,exp:db.pairs[code].exp})}
 if(p==='/api/pair/join'&&POST){if(limited(ip))return send(res,429,{error:'Too many attempts'});const b=await body(req),c=db.pairs[String(b.code)];
  if(!c||c.exp<Date.now())return send(res,400,{error:'Code is wrong or expired'});delete db.pairs[String(b.code)];
  const d={id:'D'+crypto.randomBytes(4).toString('hex'),name:c.name,till:c.till,st:'ACTIVE',since:new Date().toISOString(),exp:Date.now()+c.hrs*36e5};db.devs.push(d);audit('gadget','Paired '+d.name+' to till '+d.till);save();return send(res,200,d)}
 if(p==='/api/device'&&POST){const a=auth(req,'devices');if(a.e)return fail(a);const b=await body(req),d=db.devs.find(x=>x.id===b.id);
  if(!d)return send(res,400,{error:'Unknown gadget'});
  if(b.renew){d.exp=Date.now()+hrs(b.hours)*36e5;d.st='ACTIVE';audit(a.u.name,'Renewed pairing of '+d.name+' for a shift');save();return send(res,200,d)}
  if(!['ACTIVE','DISABLED'].includes(b.st))return send(res,400,{error:'Unknown gadget'});d.st=b.st;audit(a.u.name,b.st+' gadget '+d.name);save();return send(res,200,d)}
 if(p==='/api/audit'){const a=auth(req,'reports');return a.e?fail(a):send(res,200,{chainValid:chainOk(),log:db.audit.slice(-100).reverse()})}
 if(p==='/api/refunds'&&!POST){const a=auth(req,'refundReq');return a.e?fail(a):send(res,200,{refunds:db.refunds.slice(-200).reverse()})}
 if(p==='/api/refunds/request'&&POST){const a=auth(req,'refundReq');if(a.e)return fail(a);const b=await body(req),sale=Object.values(db.sales).find(x=>x.id===b.sid);
  if(!sale||sale.status!=='SYNCED')return send(res,400,{error:'Only synced sales can be refunded'});
  const why=String(b.reason||'').trim().slice(0,200);if(why.length<3)return send(res,400,{error:'A reason is required'});
  if(db.refunds.filter(x=>x.by===a.u.name&&Date.now()-Date.parse(x.at)<864e5).length>=10)return send(res,429,{error:'Daily refund request limit reached'});
  const have={},used={};sale.items.forEach(l=>{const h=have[l.id]=have[l.id]||{id:l.id,n:l.n,p:l.p,q:0};h.q+=l.q});
  db.refunds.filter(x=>x.sid===sale.id&&x.st!=='REJECTED').forEach(x=>(x.items||sale.items).forEach(i=>used[i.id]=(used[i.id]||0)+i.q));
  const want={};(Array.isArray(b.items)&&b.items.length?b.items:Object.values(have).map(h=>({id:h.id,q:h.q-(used[h.id]||0)}))).forEach(i=>{const q=Math.floor(+i.q);if(q>0)want[+i.id]=(want[+i.id]||0)+q});
  const ids=Object.keys(want);if(!ids.length)return send(res,400,{error:'Nothing left to refund on this sale'});
  for(const id of ids)if(!have[id]||want[id]>have[id].q-(used[id]||0))return send(res,400,{error:'That is more than was sold and not yet refunded'});
  const items=ids.map(id=>({id:+id,n:have[id].n,q:want[id],p:have[id].p})),amt=items.reduce((t,i)=>t+i.q*i.p,0)*(1-sale.disc/100);
  const r={id:'R'+String(db.refunds.length+1).padStart(4,'0'),sid:sale.id,items,amt,pay:sale.pay,rsn:why,by:a.u.name,st:'REFUND_PENDING',at:new Date().toISOString()};
  db.refunds.push(r);audit(a.u.name,'Refund requested '+r.id+' for '+sale.id+' ('+items.map(i=>i.q+'x '+i.n).join(', ')+'): '+why);save();return send(res,200,r)}
 if(p==='/api/refunds/approve'&&POST){const a=auth(req,'refundOk');if(a.e)return fail(a);const b=await body(req),r=db.refunds.find(x=>x.id===b.id);
  if(!r||r.st!=='REFUND_PENDING')return send(res,400,{error:'No pending refund with that id'});
  if(r.by===a.u.name){audit(a.u.name,'BLOCKED self-approval of '+r.id);save();return send(res,403,{error:'A different person must approve your request'})}
  if(!b.ok){r.st='REJECTED';r.ap=a.u.name;audit(a.u.name,'Rejected refund '+r.id);save();return send(res,200,{refund:r,stock:stock()})}
  const sale=Object.values(db.sales).find(x=>x.id===r.sid);(r.items||sale.items).forEach(it=>{const pr=db.prods.find(x=>x.id===it.id);if(pr){pr.s+=it.q;mv(it.id,it.q,'Refund '+r.id,a.u.name)}});
  if(sale.pay==='Credit'){const cu=db.customers.find(x=>x.id===sale.cust);if(cu){cu.bal=Math.max(0,cu.bal-r.amt);db.cled.push({cid:cu.id,type:'REFUND',amt:-r.amt,ref:r.id,by:a.u.name,at:Date.now()})}}
  else fin(sale.pay==='Cash'?'CASH_REFUND':sale.pay==='M-Pesa'?'MPESA_REFUND':'CARD_REFUND',sale.pay,r.amt,-1,r.id+' for '+sale.id,a.u.name,sale.till);
  r.st='REFUNDED';r.ap=a.u.name;audit(a.u.name,'Approved refund '+r.id+' KES '+Math.round(r.amt)+', stock restored');save();return send(res,200,{refund:r,stock:stock()})}
 if(p==='/api/tills'&&!POST){const a=auth(req,'view');if(a.e)return fail(a);const n=Date.now();
  return send(res,200,{tills:Object.entries(db.locks).filter(([k,l])=>lockLive(l,n)).map(([k,l])=>({till:+k,user:l.user,devName:l.devName,since:l.since}))})}
 if(p==='/api/devices'&&!POST){const a=auth(req,'devices');return a.e?fail(a):send(res,200,{devs:db.devs})}
 if(p==='/api/till/cash'&&!POST){const a=auth(req,'till');if(a.e)return fail(a);const q=new URL(req.url,'http://x').searchParams,tl=+q.get('till'),since=+q.get('since')||0;
  return send(res,200,{extra:db.fin.filter(x=>x.acct==='Cash'&&x.till===tl&&x.type!=='CASH_SALE'&&x.at>=since).reduce((t,x)=>t+x.dir*x.amt,0)})}
 if(p==='/api/till/claim'&&POST){const a=auth(req,'till');if(a.e)return fail(a);const b=await body(req),t=Math.floor(+b.till);if(!(t>=1&&t<=99))return send(res,400,{error:'Unknown till'});
  const dv=req.headers['x-device']||'',dd=dv&&db.devs.find(x=>x.id===dv);
  if(dd&&!devLive(dd))return send(res,403,{error:devWhy(dd)});
  if(dd&&dd.till!==t)return send(res,403,{error:'This gadget is paired to Till '+dd.till});
  const L=db.locks[t],now=Date.now(),live=lockLive(L,now),same=live&&L.user===a.u.name&&L.dev===dv;
  if(live&&!same){audit(a.u.name,'BLOCKED login to active Till '+t+' (in use by '+L.user+')');save();return send(res,409,{error:'Till '+t+' is in use by '+L.user+(L.devName?' on '+L.devName:'')})}
  for(const k in db.locks)if(db.locks[k].user===a.u.name&&+k!==t)delete db.locks[k];
  if(!same)audit(a.u.name,'Took Till '+t+(dd?' on '+dd.name:''));
  db.locks[t]={user:a.u.name,dev:dv,devName:dd?dd.name:'',since:same?L.since:now,seen:now};save();return send(res,200,{till:t})}
 if(p==='/api/till/release'&&POST){const a=auth(req,'till');if(a.e)return fail(a);const b=await body(req),t=Math.floor(+b.till),L=db.locks[t];if(!L)return send(res,200,{ok:1});
  const mine=L.user===a.u.name&&L.dev===(req.headers['x-device']||'');
  if(!mine&&!(b.force&&can(a.u.role,'discount'))){audit(a.u.name,'BLOCKED release of Till '+t);save();return send(res,403,{error:'Only a manager can free a till someone else is using'})}
  delete db.locks[t];audit(a.u.name,(mine?'Released Till ':'Force-freed Till ')+t+(mine?'':' (was '+L.user+')'));save();return send(res,200,{ok:1})}

 // ---------- finance ledger ----------
 if(p==='/api/fin'&&!POST){const a=auth(req,'finance');if(a.e)return fail(a);const bal={};['Cash','Bank','M-Pesa','Card'].forEach(k=>bal[k]=db.fin.filter(x=>x.acct===k).reduce((t,x)=>t+x.dir*x.amt,0));
  return send(res,200,{entries:db.fin.slice(-150).reverse(),bal,sups:db.sups,recv:db.customers.reduce((t,c)=>t+c.bal,0)})}
 if(p==='/api/fin'&&POST){const a=auth(req,'finance');if(a.e)return fail(a);const b=await body(req),amt=+b.amt,T=b.type,ref=String(b.ref||'').trim().slice(0,80),ac=['Cash','Bank','M-Pesa'].includes(b.acct)?b.acct:'Cash',tl=+b.till||0,w=a.u.name;
  if(!(amt>0)||!ref)return send(res,400,{error:'Amount and reference are required'});
  if(a.u.role==='Manager'&&amt>20000){audit(w,'BLOCKED finance movement above limit');save();return send(res,403,{error:'Above your KES 20,000 limit. Ask the Owner or Finance.'})}
  if(T==='CASH_IN')fin(T,'Cash',amt,1,ref,w,tl);else if(T==='CASH_OUT'||T==='EXPENSE')fin(T,ac,amt,-1,ref,w,tl);
  else if(T==='BANK_DEPOSIT'){fin(T,'Cash',amt,-1,ref,w,tl);fin(T,'Bank',amt,1,ref,w,tl)}
  else if(T==='SUPPLIER_PAYMENT'){const u=db.sups.find(x=>x.id===+b.sup);if(!u)return send(res,400,{error:'Unknown supplier'});if(amt>u.owed+0.001)return send(res,400,{error:'That is more than '+u.name+' is owed'});fin(T,ac,amt,-1,u.name+' - '+ref,w,tl);u.owed-=amt}
  else return send(res,400,{error:'Unknown movement type'});
  audit(w,T+' KES '+Math.round(amt)+' - '+ref);save();return send(res,200,{ok:1})}
 // ---------- purchasing ----------
 if(p==='/api/po'&&!POST){const a=auth(req,'restock');return a.e?fail(a):send(res,200,{pos:db.pos.slice(-100).reverse(),sups:db.sups,mv:db.mv.slice(-30).reverse()})}
 if(p==='/api/po'&&POST){const a=auth(req,'restock');if(a.e)return fail(a);const b=await body(req),q=Math.floor(+b.qty),c=+b.cost;
  if(!db.sups.find(x=>x.id===+b.sup)||!db.prods.find(x=>x.id===+b.pid)||!(q>0&&q<=1e5)||!(c>0))return send(res,400,{error:'Check supplier, product, quantity and cost'});
  const o={id:'PO'+String(db.pos.length+1).padStart(4,'0'),sup:+b.sup,pid:+b.pid,qty:q,cost:c,st:'ORDERED',by:a.u.name};db.pos.push(o);audit(a.u.name,'Created '+o.id);save();return send(res,200,o)}
 if(p==='/api/po/receive'&&POST){const a=auth(req,'restock');if(a.e)return fail(a);const b=await body(req),o=db.pos.find(x=>x.id===b.id),v=Math.floor(+b.recv);
  if(!o||o.st!=='ORDERED')return send(res,400,{error:'That order is not waiting for delivery'});if(!(v>=0&&v<=o.qty*10))return send(res,400,{error:'Enter the quantity actually delivered'});
  const pr=db.prods.find(x=>x.id===o.pid);o.recv=v;o.st=v<o.qty?'RECEIVED_SHORT':v>o.qty?'RECEIVED_OVER':'RECEIVED';pr.s+=v;db.sups.find(x=>x.id===o.sup).owed+=v*o.cost;mv(pr.id,v,o.id,a.u.name);
  audit(a.u.name,'Received '+v+'/'+o.qty+' x '+pr.n+' on '+o.id+(v!==o.qty?' (exception)':''));save();return send(res,200,{order:o,stock:stock()})}
 // ---------- stock counts ----------
 if(p==='/api/counts'&&!POST){const a=auth(req,'restock');return a.e?fail(a):send(res,200,{counts:db.counts.slice(-30).reverse()})}
 if(p==='/api/counts'&&POST){const a=auth(req,'restock');if(a.e)return fail(a);const b=await body(req),lines=[];
  for(const l of(Array.isArray(b.lines)?b.lines:[]).slice(0,200)){const pr=db.prods.find(x=>x.id===+l.id),c=Math.floor(+l.counted);if(!pr||!(c>=0&&c<=1e6))return send(res,400,{error:'Invalid count line'});if(c!==pr.s)lines.push({id:pr.id,n:pr.n,sys:pr.s,counted:c,diff:c-pr.s})}
  if(!lines.length)return send(res,400,{error:'The count matches the system. Nothing to approve.'});
  const r={id:'C'+String(db.counts.length+1).padStart(4,'0'),by:a.u.name,note:String(b.note||'').slice(0,100),lines,st:'PENDING',at:Date.now()};db.counts.push(r);audit(a.u.name,'Stock count '+r.id+' submitted, '+lines.length+' difference(s)');save();return send(res,200,r)}
 if(p==='/api/counts/approve'&&POST){const a=auth(req,'stockOk');if(a.e)return fail(a);const b=await body(req),r=db.counts.find(x=>x.id===b.id);
  if(!r||r.st!=='PENDING')return send(res,400,{error:'No pending count with that id'});
  if(r.by===a.u.name){audit(a.u.name,'BLOCKED self-approval of '+r.id);save();return send(res,403,{error:'A different person must approve the count'})}
  if(!b.ok){r.st='REJECTED';r.ap=a.u.name;audit(a.u.name,'Rejected count '+r.id);save();return send(res,200,{count:r,stock:stock()})}
  r.lines.forEach(l=>{const pr=db.prods.find(x=>x.id===l.id);pr.s=Math.max(0,pr.s+l.diff);mv(l.id,l.diff,'Count '+r.id,a.u.name)});r.st='APPROVED';r.ap=a.u.name;audit(a.u.name,'Approved count '+r.id+', stock adjusted');save();return send(res,200,{count:r,stock:stock()})}
 // ---------- customers and credit ----------
 if(p==='/api/customers'&&!POST){const a=auth(req,'credit');return a.e?fail(a):send(res,200,{customers:db.customers})}
 if(p==='/api/customers'&&POST){const a=auth(req,'credit');if(a.e)return fail(a);const b=await body(req),name=String(b.name||'').trim().slice(0,40),lim=Math.max(0,+b.limit||0);
  if(name.length<2)return send(res,400,{error:'Enter the customer name'});if(lim>0&&!can(a.u.role,'discount'))return send(res,403,{error:'Only a Manager or Owner can set a credit limit'});
  const c={id:db.cid++,name,phone:String(b.phone||'').replace(/[^\d+]/g,'').slice(0,15),limit:lim,bal:0};db.customers.push(c);audit(a.u.name,'Created customer '+name+' (limit '+lim+')');save();return send(res,200,c)}
 if(p==='/api/customers/pay'&&POST){const a=auth(req,'credit');if(a.e)return fail(a);const b=await body(req),c=db.customers.find(x=>x.id===+b.id),amt=+b.amount,m=['Cash','M-Pesa','Bank','Card'].includes(b.method)?b.method:'Cash';
  if(!c||!(amt>0))return send(res,400,{error:'Choose a customer and an amount'});if(amt>c.bal+0.001)return send(res,400,{error:'That is more than '+c.name+' owes ('+Math.round(c.bal)+')'});
  c.bal-=amt;fin('CUSTOMER_PAYMENT',m,amt,1,c.name,a.u.name,+b.till||0);db.cled.push({cid:c.id,type:'PAYMENT',amt:-amt,ref:m,by:a.u.name,at:Date.now()});audit(a.u.name,'Payment KES '+Math.round(amt)+' from '+c.name);save();return send(res,200,c)}
 if(p==='/api/customers/statement'&&!POST){const a=auth(req,'credit');if(a.e)return fail(a);const id=+new URL(req.url,'http://x').searchParams.get('id');return send(res,200,{rows:db.cled.filter(x=>x.cid===id).slice(-40).reverse()})}
 // ---------- employees ----------
 const pubEmp=e=>({id:e.id,name:e.name,role:e.role,on:e.on});
 const newPin=()=>{for(let i=0;i<50;i++){const pin=String(crypto.randomInt(100000,1000000));if(!db.emps.some(e=>eq(scr(pin,e.salt),e.h)))return pin}throw new Error('pin')};
 if(p==='/api/emps'&&!POST){const a=auth(req,'emps');return a.e?fail(a):send(res,200,{emps:db.emps.map(pubEmp)})}
 if(p==='/api/emps/add'&&POST){const a=auth(req,'emps');if(a.e)return fail(a);const b=await body(req),name=String(b.name||'').trim();
  if(!/^[A-Za-z][A-Za-z .'-]{1,24}$/.test(name)||!ROLES[b.role])return send(res,400,{error:'Enter a name and choose a role'});if(db.emps.some(e=>e.name.toLowerCase()===name.toLowerCase()))return send(res,400,{error:'That name is already used'});
  const pin=newPin(),salt=crypto.randomBytes(16).toString('hex'),e={id:Date.now(),name,role:b.role,on:0,salt,h:scr(pin,salt),fails:0,lock:0};db.emps.push(e);audit(a.u.name,'Created employee '+name+' ('+b.role+'), not yet active');save();return send(res,200,{emp:pubEmp(e),pin})}
 if(p==='/api/emps/update'&&POST){const a=auth(req,'emps');if(a.e)return fail(a);const b=await body(req),e=db.emps.find(x=>x.id===+b.id);if(!e)return send(res,400,{error:'Unknown employee'});
  const role=b.role!==undefined?b.role:e.role,on=b.on!==undefined?(b.on?1:0):e.on;if(!ROLES[role])return send(res,400,{error:'Unknown role'});
  if(e.name===a.u.name&&(role!==e.role||on!==e.on))return send(res,403,{error:'You cannot change your own role or status'});
  if(e.role==='Owner'&&e.on&&(role!=='Owner'||!on)&&!db.emps.some(x=>x.id!==e.id&&x.on&&x.role==='Owner'))return send(res,400,{error:'There must be at least one active Owner'});
  let pin;if(b.resetPin){pin=newPin();e.salt=crypto.randomBytes(16).toString('hex');e.h=scr(pin,e.salt);e.fails=0;e.lock=0}
  const ch=[];if(role!==e.role)ch.push('role '+e.role+' to '+role);if(on!==e.on)ch.push(on?'activated':'deactivated');if(pin)ch.push('PIN reset');e.role=role;e.on=on;audit(a.u.name,'Employee '+e.name+': '+(ch.join(', ')||'no change'));save();return send(res,200,{emp:pubEmp(e),pin})}
 // ---------- receipt printer and cash drawer ----------
 if(p==='/api/printer'&&!POST){const a=auth(req,'view');return a.e?fail(a):send(res,200,{printer:db.settings.printer||{}})}
 if(p==='/api/printer'&&POST){const a=auth(req,'devices');if(a.e)return fail(a);const b=await body(req),host=String(b.host||'').trim(),port=+b.port||9100;
  if(host&&!/^[\w.\-]{1,60}$/.test(host)||!(port>0&&port<65536))return send(res,400,{error:'Enter the printer IP address and port (usually 9100)'});
  db.settings.printer=host?{host,port}:{};audit(a.u.name,host?'Printer set to '+host+':'+port:'Printer removed');save();return send(res,200,{printer:db.settings.printer})}
 if(p==='/api/print'&&POST){const a=auth(req,'sell');if(a.e)return fail(a);const b=await body(req),sale=b.sid?Object.values(db.sales).find(x=>x.id===b.sid):null;
  if(b.sid&&!sale)return send(res,400,{error:'Unknown sale'});
  try{await sendPrinter(sale?receipt(sale,sale.pay==='Cash'&&b.drawer!==false):b.test?receipt({id:'TEST',at:new Date().toISOString(),till:0,by:a.u.name,items:[{n:'Test print',q:1,p:0}],disc:0,total:0,pay:'Cash'},false):Buffer.from([0x1b,0x40,0x1b,0x70,0,25,250]));
   audit(a.u.name,sale?'Printed '+sale.id:b.test?'Test print':'Opened cash drawer');save();return send(res,200,{ok:1})}catch(e){return send(res,502,{error:e.message})}}
 // ---------- M-Pesa (Daraja STK push) ----------
 if(p==='/api/mpesa/stk'&&POST){const a=auth(req,'sell');if(a.e)return fail(a);const b=await body(req),ph=phone254(b.phone),amt=Math.round(+b.amount),m=MP();
  if(!ph||!(amt>=1&&amt<=250000))return send(res,400,{error:'Enter a valid Safaricom number and amount'});
  if(m.sim){const id='ws_CO_SIM'+crypto.randomBytes(5).toString('hex');db.mpq[id]={amt,ph,by:a.u.name,at:Date.now(),st:'PENDING'};save();return send(res,200,{id})}
  if(!m.key||!m.secret||!m.code||!m.pass)return send(res,501,{error:'M-Pesa is not set up on the server yet'});
  try{const tk=await mpToken(m),ts=stamp(),r=await jreq('https://'+m.env+'/mpesa/stkpush/v1/processrequest',{method:'POST',headers:{authorization:'Bearer '+tk,'content-type':'application/json'}},{BusinessShortCode:m.code,Password:Buffer.from(m.code+m.pass+ts).toString('base64'),Timestamp:ts,TransactionType:m.type,Amount:amt,PartyA:ph,PartyB:m.partyb,PhoneNumber:ph,CallBackURL:m.cb,AccountReference:'Lavish',TransactionDesc:'Shop payment'});
   if(r.ResponseCode!=='0')return send(res,502,{error:r.errorMessage||r.ResponseDescription||'M-Pesa refused the request'});
   db.mpq[r.CheckoutRequestID]={amt,ph,by:a.u.name,at:Date.now(),st:'PENDING'};save();return send(res,200,{id:r.CheckoutRequestID})}catch(e){return send(res,502,{error:'Could not reach M-Pesa'})}}
 if(p==='/api/mpesa/status'&&!POST){const a=auth(req,'sell');if(a.e)return fail(a);const id=new URL(req.url,'http://x').searchParams.get('id'),q=db.mpq[id];if(!q)return send(res,404,{error:'Unknown payment request'});
  if(q.st==='PENDING'){const m=MP();
   if(m.sim){if(Date.now()-q.at>=(+process.env.MPESA_SIM_MS||3000))q.st=q.ph==='254700000000'?'FAILED':'PAID'}
   else{try{const tk=await mpToken(m),ts=stamp(),r=await jreq('https://'+m.env+'/mpesa/stkpushquery/v1/query',{method:'POST',headers:{authorization:'Bearer '+tk,'content-type':'application/json'}},{BusinessShortCode:m.code,Password:Buffer.from(m.code+m.pass+ts).toString('base64'),Timestamp:ts,CheckoutRequestID:id});
     if(r.ResultCode!==undefined)q.st=String(r.ResultCode)==='0'?'PAID':'FAILED'}catch(e){}}
   if(q.st==='PENDING'&&Date.now()-q.at>12e4)q.st='FAILED';
   if(q.st==='PAID'){db.mp[id]={amt:q.amt,at:Date.now()};audit(q.by,'M-Pesa payment confirmed KES '+q.amt)}save()}
  return send(res,200,{status:q.st})}
 if(p.startsWith('/api/'))return send(res,404,{error:'Not found'});
 const f=path.normalize(path.join(PUB,p==='/'?'index.html':p));
 if(!f.startsWith(PUB+path.sep)||!fs.existsSync(f)||fs.statSync(f).isDirectory()){res.writeHead(404);return res.end('Not found')}
 res.writeHead(200,{'content-type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(res)}
const h=(q,r)=>handle(q,r).catch(e=>{console.error(e);if(!r.headersSent)send(r,500,{error:'Server error'})});
const tls=fs.existsSync(path.join(__dirname,'cert.pem'))&&fs.existsSync(path.join(__dirname,'key.pem'));
const srv=tls?https.createServer({key:fs.readFileSync(path.join(__dirname,'key.pem')),cert:fs.readFileSync(path.join(__dirname,'cert.pem'))},h):http.createServer(h);
srv.listen(PORT,'0.0.0.0',()=>{console.log('\nLavish POS store server ('+(tls?'https':'http')+') on port '+PORT);
 if(tls&&fs.existsSync(CA))console.log('  New phone? First open http://<address above>:'+(PORT+1)+' to install the shop certificate');
 Object.values(os.networkInterfaces()).flat().filter(i=>i.family==='IPv4'&&!i.internal).forEach(i=>console.log('  Tills open: '+(tls?'https':'http')+'://'+i.address+':'+PORT));
 if(!tls)console.log('  No cert.pem/key.pem found: phones will not offer Install on plain http. See README.')});

// Certificate helper: plain-http page (PORT+1) so phones can install the shop's root certificate once.
const CA=path.join(__dirname,'public-ca','rootCA.pem');
if(tls&&fs.existsSync(CA))http.createServer((q,r)=>{const p=new URL(q.url,'http://x').pathname;
 if(p==='/rootCA.crt'||p==='/rootCA.pem'){r.writeHead(200,{'content-type':'application/x-x509-ca-cert','content-disposition':'attachment; filename=lavish-pos-shop-certificate.crt'});return fs.createReadStream(CA).pipe(r)}
 const host=(q.headers.host||'').split(':')[0].replace(/[^\w.\-]/g,'');
 r.writeHead(200,{'content-type':'text/html; charset=utf-8'});
 r.end(`<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><body style="font:16px system-ui;max-width:520px;margin:24px auto;padding:0 16px;line-height:1.5"><h2>Lavish POS: install shop certificate</h2><p>Do this once per phone, on the shop network only.</p><p><a href="/rootCA.crt" style="background:#FF3D7F;color:#fff;padding:12px 18px;border-radius:12px;text-decoration:none">Download certificate</a></p><h3>Android</h3><ol><li>Open the downloaded file, or go to Settings, Security, Encryption and credentials, Install a certificate, CA certificate.</li><li>Pick the file and confirm.</li></ol><h3>iPhone / iPad</h3><ol><li>Tap Allow to download the profile, then open Settings and tap Profile Downloaded, Install.</li><li>Go to Settings, General, About, Certificate Trust Settings and switch it on.</li></ol><p>Then open <a href="https://${host}:${PORT}">https://${host}:${PORT}</a> and install the app.</p>`)}).listen(PORT+1,'0.0.0.0');
