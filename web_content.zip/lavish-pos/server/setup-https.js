// One-time HTTPS setup for the shop PC (needed so phones can install the app and use the camera).
const {execFileSync,spawnSync}=require('child_process'),os=require('os'),fs=require('fs'),path=require('path');
const run=(c,a)=>spawnSync(c,a,{stdio:'inherit'});
if(spawnSync('mkcert',['-version']).error){console.log('mkcert is not installed. Install it, then run this again:\n  Windows: winget install FiloSottile.mkcert   (or: choco install mkcert)\n  Mac:     brew install mkcert\n  Linux:   https://github.com/FiloSottile/mkcert');process.exit(1)}
const ips=Object.values(os.networkInterfaces()).flat().filter(i=>i.family==='IPv4'&&!i.internal).map(i=>i.address);
run('mkcert',['-install']);
if(run('mkcert',['-cert-file','cert.pem','-key-file','key.pem','localhost','127.0.0.1','::1',...ips,os.hostname()]).status)process.exit(1);
const root=path.join(execFileSync('mkcert',['-CAROOT']).toString().trim(),'rootCA.pem');
fs.mkdirSync('public-ca',{recursive:true});fs.copyFileSync(root,path.join('public-ca','rootCA.pem'));
console.log('\nDone. Certificate covers: '+ips.join(', ')+'\nRestart the server with: node server.js\nTip: give this PC a fixed IP in your router, or re-run this script if the IP changes.\nThe private CA key stays on this PC. Only the public certificate is shared with phones.');
