# Lavish Beauty and Deco POS: store server

One small server (Node 18+, nothing to install) that runs the shop. It serves the app to every till and keeps the real stock, sales, sign-ins, refunds and audit log.

## Start
1. Install Node.js 18 or newer on the shop PC.
2. In this folder run: `node server.js`
3. First run prints one sign-in PIN per employee. Write them down: PINs are stored hashed and never shown again. To reset, delete data.json.
4. The console lists an address for each till, for example http://192.168.1.20:8080. Open it on every phone, tablet or PC on the shop network.

## Install on phones (needs HTTPS)
Phones only offer Install, and only allow the camera, over HTTPS.
1. On the shop PC install mkcert (Windows: `winget install FiloSottile.mkcert`, Mac: `brew install mkcert`).
2. Run `node setup-https.js`. It creates cert.pem and key.pem for the PC's addresses and prepares the phone certificate.
3. Restart with `node server.js`. It now runs on https, plus a helper page one port higher (8081).
4. On each phone, once, on the shop network only: open `http://<PC address>:8081`, download the certificate and install it. The page shows the Android and iPhone steps.
5. Open `https://<PC address>:8080`, then tap Install app (Android) or Share, Add to Home Screen (iPhone).
Give the PC a fixed IP in your router. If the address changes, run `node setup-https.js` again.

## Tills
- A till can be used by one person on one gadget at a time. Anyone else trying to log onto an active till is blocked, and the attempt is logged.
- A paired gadget can only use the till it is paired to. A disabled gadget cannot use any till.
- A till that stops checking in for 90 seconds frees itself. Offline sales keep queuing and upload later.
- Owner or Manager can free a stuck till from the Tills tab.
- Signing out, or moving to another till, releases the till.

## Refunds
- Pick the items and quantities to refund. Partial refunds work, and you can refund again until everything sold has been returned.
- The server works out the amount at the price actually paid, discount included, and never allows more than was sold.
- A different Manager or Owner must approve. Approval puts only the returned items back in stock.

## Barcode scanning
Each product has an EAN-13 barcode (Stock tab). Scan with a Bluetooth or USB scanner into the search box, or tap Scan to use the phone camera (Chrome on Android, HTTPS needed). Safari on iPhone does not support camera scanning yet, so use a scanner there.

## Enforced on the server
- Own-PIN sign-in (scrypt hashed), lockout after 5 wrong tries, shift-length sessions, sign-out after 5 idle minutes in the app.
- Role checks on every action, with blocked attempts in the audit log.
- Server-side pricing and stock checks, no double posting on retries, overselling flagged for review.
- Discounts over 10% need a manager's own PIN, single use, expiring in 2 minutes.
- Pairing codes made and checked by the server, single use, 10 minutes.
- Hash-chained audit log (Owner: /api/audit shows chainValid).

## Shifts and pairing
- The Owner picks the shift length (4, 8, 12 or 16 hours) when pairing a gadget. Pairing and the till reservation last the whole shift, even through Wi-Fi drops or a locked screen.
- When the shift ends the gadget stops until the Owner taps Renew shift on the Devices tab. Sales made earlier in the shift still upload.
- Sign-in sessions last one shift (SHIFT_HOURS). The app locks after 5 idle minutes and asks for the PIN.

## Finance, purchasing, counts, credit, staff (all on the server)
- **Finance:** every sale, refund and customer payment is written to one ledger. Owner, Finance and Manager (up to KES 20,000 each) record cash in/out, expenses, bank deposits and supplier payments.
- **Purchasing:** create an order, then receive what actually arrived. Shortages are flagged, stock goes up by the amount received, and the supplier balance grows until paid.
- **Stock counts:** count the shelf, submit, and a different Manager or Owner approves. Only differences are adjusted.
- **Customer credit:** Manager or Owner sets a credit limit. Credit sales are refused over the limit. Record payments and print a statement.
- **Employees:** the Owner adds staff (inactive until activated, with a one-time PIN), changes roles, deactivates, and resets PINs. You cannot change your own role or remove the last Owner.

## M-Pesa
Copy `settings.env.example` to `settings.env` and fill in your Daraja details. At the till choose M-Pesa, enter the customer phone and tap Send M-Pesa prompt. The server checks the payment with Safaricom (no public web address needed) and each payment can pay one sale only. Without Daraja set up, type the code from the customer SMS instead: it is accepted once, and never twice. Untested against live Safaricom here: try it on the sandbox first.

## Receipt printer and cash drawer
Owner: Devices tab, Receipt printer, enter the IP of a Wi-Fi/LAN ESC/POS thermal printer (port 9100), Save, Test print. Print from the receipt window with Shop printer. Cash sales kick the cash drawer wired to the printer. Bluetooth and USB printers are not supported. The browser Print button still works for any printer.

## Not built yet
Local encryption on the phone, Swahili, editable product prices and images, split payments and KRA eTIMS receipts.

Run the checks with `node test.js` (100 checks).
