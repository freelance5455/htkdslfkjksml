# Lavish Beauty and Deco POS: install guide

Three parts: the **store server** (one shop PC), the **app on phones/tablets** (install from the browser or as an APK), and the **APK project**.

## 1. Start the store server (shop PC)
1. Install Node.js 18 or newer from nodejs.org.
2. Windows: double-click `start-windows.bat`. Mac/Linux: run `./start-mac-linux.sh`.
3. The first run prints a sign-in PIN for each employee. Write them down. They are never shown again.
4. The window lists the address for tills, for example `http://192.168.1.20:8080`.
Give the PC a fixed IP in your router so the address never changes.

## 2. Secure the connection (needed for camera scanning and Install)
1. Install mkcert (Windows: `winget install FiloSottile.mkcert`, Mac: `brew install mkcert`).
2. In the `server` folder run `node setup-https.js`, then restart the server.
3. On each phone or tablet, once, on the shop network: open `http://<PC address>:8081`, download the certificate and install it (the page shows the Android and iPhone steps).
Details are in `server/README.md`.

## 3a. Install as a web app (no APK)
Open `https://<PC address>:8080` on the phone. Android Chrome: tap Install app. iPhone Safari: Share, Add to Home Screen.

## 3b. Build the Android APK
The `android` folder is a ready Android project. It opens the store server full screen, allows the camera for barcode scanning, and remembers the server address.
**Easiest, no software to install:**
1. Create a free GitHub account and a new private repository.
2. Upload everything inside the `android` folder to it (keep the `.github` folder).
3. Open the Actions tab, run "Build Lavish POS APK", wait about 5 minutes.
4. Download `lavish-pos-apk` from the finished run and unzip it to get `app-debug.apk`.

**Or with Android Studio:** open the `android` folder, then Build, Build APK(s).

**Install on each tablet/phone:** copy the APK across, allow "Install unknown apps" when asked, open Lavish POS, type the server address (for example `https://192.168.1.20:8080`), then sign in. Install the shop certificate first (step 2.3) so the https address works and the camera can scan.
This APK is signed with a debug key, which is fine for your own shop devices. Publishing on Google Play needs a release key.

## Set up M-Pesa and the receipt printer (optional)
- **M-Pesa:** in the `server` folder copy `settings.env.example` to `settings.env`, fill in your Safaricom Daraja details, restart. Try the sandbox first. Without it, staff type the M-Pesa SMS code and each code works once.
- **Printer:** sign in as Owner, Devices tab, Receipt printer. Enter the IP of a Wi-Fi/LAN thermal printer (port 9100) and tap Test print.

## What the POS covers
Sales, discounts with manager PIN, partial refunds with approval, till and shift control, gadget pairing per shift, barcode scanning, M-Pesa, credit customers, purchasing and receiving, stock counts, finance ledger, employees and roles, audit log, offline queue and sync.

## 4. Turn on M-Pesa and the receipt printer
- **M-Pesa prompts:** in the `server` folder copy `settings.env.example` to `settings.env`, fill in your Safaricom Daraja details, and restart. Without them the till still accepts M-Pesa by typing the 10-character code from the customer's SMS (each code works once).
- **Receipt printer and cash drawer:** sign in as Owner, open Devices, Receipt printer, enter the IP address of a Wi-Fi or LAN thermal printer (port 9100), Save, then Test print. Phones and the APK print through the server, so no Bluetooth pairing is needed.

## What is on the server
Sales, refunds (partial too), the finance ledger, purchase orders and receiving, stock counts, customer credit with statements, employees and PINs, gadget pairing and the audit log. All tills see the same numbers.

## Pair a till gadget
Sign in as Owner, open Devices, name the gadget, pick its till and shift length, and tap Generate code. On the gadget, sign in, open Devices and enter the code. The gadget stays paired and keeps its till for the whole shift.

## Daily use
Start of shift: pair or renew gadgets, open tills. End of shift: close till (count cash), sign out. Sales made offline upload by themselves when the connection returns.
