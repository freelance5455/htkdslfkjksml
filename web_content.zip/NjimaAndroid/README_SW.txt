NJIMA RIDER'S CHOICE APP — ANDROID PROJECT

Hii ni project ya Android Studio ya toleo la kwanza. Inaweka mfumo wa mauzo ndani ya app na kufanya kazi bila intaneti. Data huhifadhiwa kwenye hifadhi ya WebView ya kifaa hiki.

JINSI YA KUTENGENEZA APK:
1. Kwenye kompyuta, sakinisha Android Studio (toleo linalotumia Android Gradle Plugin 8.6.1) na JDK 17.
2. Fungua Android Studio > Open, chagua folda ya NjimaAndroid.
3. Subiri Gradle Sync ikamilike na ukubali kupakua Android SDK Platform 35 ikihitajika.
4. Chagua Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK itapatikana kwa kawaida kwenye app/build/outputs/apk/debug/app-debug.apk.
6. Hamisha APK kwenye simu ya Android na uisakinishe. Simu inaweza kuhitaji uruhusu usakinishaji kutoka chanzo hicho.

MUHIMU:
- Hii ni project source, si APK iliyokwisha compile.
- App haihitaji intaneti wakati wa kutumia mauzo/stoo baada ya kusakinishwa.
- Data inabaki kwenye kifaa hiki; tengeneza chelezo mara kwa mara kupitia sehemu ya Chelezo ndani ya app.
- Kwa sasa exports/downloads na kuchagua faili la kurejesha chelezo zinaweza kutegemea uwezo wa WebView ya kifaa; jaribu kabla ya kuingiza data nyingi.
- Usifute data ya app au kuiondoa bila ku-export chelezo kwanza.
