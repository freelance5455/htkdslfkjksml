BTC Signal Pro Android Project (v2.0)
====================================

यह Android Studio में APK बनाने के लिए source project है; यह पहले से बनी APK नहीं है।

ऐप की जानकारी:
- BTC/USDT के लिए 15m default timeframe
- 10 technical indicator-based educational signal display
- Hindi BUY / SELL / WAIT, reference entry, ATR-based SL/Target estimate
- Binance public API से data fetch; internet जरूरी है
- इस prototype में वास्तविक BTC Futures exchange data या broker/exchange order execution नहीं है
- संकेत गलत हो सकते हैं; पहले paper-trading में जांचें

APK बनाने के लिए:
1. ZIP को extract करें।
2. Android Studio खोलें और "Open" चुनकर BTC_Signal_Pro_Android_Project folder चुनें।
3. Gradle sync पूरा होने दें। Android Studio में compatible Android SDK (API 35) और JDK/Gradle setup चाहिए।
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. Build पूरा होने पर APK का सामान्य path होगा:
   app/build/outputs/apk/debug/app-debug.apk
6. APK को फोन में भेजें/डाउनलोड करें, खोलें और जरूरत पड़े तो Android Settings में उस source से "Install unknown apps" अनुमति दें।
7. यदि किसी दूसरे व्यक्ति को स्थायी रूप से वितरित करना है, तो release build बनाकर निजी signing key से sign करें। अपनी signing key/पासवर्ड सुरक्षित रखें।

नोट:
- Android Studio और Gradle versions के कारण पहली sync में version adjustment लग सकता है।
- इस environment में Android SDK/Gradle build चलाकर APK compile/test नहीं किया गया; इसलिए APK की सफलता की गारंटी नहीं है।
