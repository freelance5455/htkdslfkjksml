V39 Excel Import Native Fix

- Uses a visible native file input instead of a programmatic click on a hidden input.
- Template download uses a direct bundled XLSX link; Android invokes the native save dialog.
- XLSX parsing no longer depends on an external CDN for standard XLSX files.
- CSV/TXT remains supported.
- Import button enables only after successful preview/validation.
- No Supabase schema change required.
