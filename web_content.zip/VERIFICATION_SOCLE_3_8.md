# Vérification — Socle 3.8

- Tests automatisés : **224 réussis / 224**, aucun échec.
- Vérification syntaxique JavaScript : `node --check` sur tous les fichiers `src` et `tests`.
- Intégrité de l'archive : contrôle `unzip -t` après création.
- Moteurs de compétition et règles du jeu : comparés à la base 3.7, inchangés.
- Interface navigateur réelle : non validée dans cette exécution ; les tests automatisés ne remplacent pas un essai visuel sur appareil.
