Grade 8 English - TTS compatibility update
============================================

Included:
- index.html: updated Web Speech API handling, delayed voice initialization,
  English voice selection, longer startup timeout, audio fallback retry,
  and clearer failure messages.
- lessons.js: original lesson data, unchanged.

Important limitations:
- This ZIP is an HTML/JavaScript project, not a native Android/Kotlin project.
- It does NOT install Android TTS engines or voice packs.
- It does NOT contain a custom Android TextToSpeech JavaScript bridge.
- The Web Speech API uses whatever speech synthesis implementation the
  Android WebView exposes. If the WebView does not expose speechSynthesis,
  or if the selected engine is not connected to WebView, offline speech
  cannot be guaranteed by this ZIP alone.
- Online fallback uses Google Translate TTS / Youdao and requires internet.
- For guaranteed native TTS integration, export the Gradle + Kotlin project
  from HTML to APK Builder and add Android TextToSpeech code in the native
  WebView host, then expose a safe JS interface. The builder's public listing
  confirms a generic Native JS Bridge and Kotlin project export, but does not
  document a built-in TTS method.

Suggested test:
1. In Android Settings > Text-to-speech output, choose TTS Accessibility
   Engine, download an English voice if offered, then use Play sample.
2. Build/install this ZIP and test a short word and a full paragraph.
3. Repeat with Google Speech Services selected and an English voice downloaded.
4. Test once offline. If offline playback fails, the WebView is not using
   the selected native engine; a native Kotlin bridge is required.
