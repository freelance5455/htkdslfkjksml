package com.grade8english.offline

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Locale
import java.util.UUID

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    @Volatile private var initialized = false
    @Volatile private var state = "initializing"
    private val pending = ArrayDeque<Pair<String, Float>>()

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this) // uses the Android system-selected TTS engine
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidTtsBridge(), "AndroidTTS")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        val engine = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            state = "error:init"
            return
        }
        val result = engine.setLanguage(Locale.US)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            val gb = engine.setLanguage(Locale.UK)
            if (gb == TextToSpeech.LANG_MISSING_DATA || gb == TextToSpeech.LANG_NOT_SUPPORTED) {
                state = "error:english_voice_missing"
                initialized = false
                return
            }
        }
        engine.setSpeechRate(1.0f)
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String) { state = "speaking" }
            override fun onDone(utteranceId: String) { state = if (pending.isEmpty()) "ready" else "queued" }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String) { state = "error:synthesis" }
            override fun onError(utteranceId: String, errorCode: Int) { state = "error:$errorCode" }
        })
        initialized = true
        state = "ready"
        while (pending.isNotEmpty()) {
            val item = pending.removeFirst()
            speakNow(item.first, item.second)
        }
    }

    private fun speakNow(text: String, rate: Float) {
        val engine = tts ?: return
        engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
        state = "queued"
        val result = engine.speak(text, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
        if (result == TextToSpeech.ERROR) state = "error:speak"
    }

    inner class AndroidTtsBridge {
        @JavascriptInterface fun speak(text: String?, rate: Float): Boolean {
            val value = text?.trim().orEmpty()
            if (value.isEmpty()) return false
            runOnUiThread {
                if (initialized) speakNow(value, rate) else if (state.startsWith("error")) {
                    // Keep the failure visible to JavaScript; do not pretend audio started.
                } else {
                    pending.addLast(value to rate)
                    state = "initializing"
                }
            }
            return true
        }
        @JavascriptInterface fun stop() {
            runOnUiThread {
                pending.clear()
                tts?.stop()
                state = if (initialized) "ready" else "initializing"
            }
        }
        @JavascriptInterface fun getState(): String = state
        @JavascriptInterface fun openTtsSettings() {
            runOnUiThread { startActivity(Intent("android.settings.TTS_SETTINGS")) }
        }
        @JavascriptInterface fun getEnginePackage(): String = tts?.defaultEngine.orEmpty()
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else finish()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidTTS")
            webView.destroy()
        }
        super.onDestroy()
    }
}
