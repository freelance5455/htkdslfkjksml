GRADE 8 ENGLISH — ANDROID NATIVE TTS PROJECT

This is an Android Studio Gradle + Kotlin project, not an APK.
It wraps the existing offline HTML lessons in an Android WebView and exposes
Android's native TextToSpeech API to the lesson page through AndroidTTS.

TTS behavior:
- Uses the system-selected Android TTS engine. The user can select Google
  Speech Services or another installed engine in Android TTS settings.
- Speaks English (US), falling back to English (UK) if available.
- Uses downloaded voice data from the selected engine; no voice pack is bundled.
- HTML lesson content is bundled locally in app/src/main/assets.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync (Android SDK 35 and JDK 17 required).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK.

Important:
- The native bridge is implemented in MainActivity.kt; the generic bridge
  mentioned by HTML to APK Builder is not assumed to provide a TTS method.
- This project uses Android's default selected TTS engine; Google Speech
  Services and TTS Accessibility Engine are alternatives selected in Android
  settings, not two engines spoken simultaneously.
- Offline speech works only if the chosen engine has a downloaded offline
  English voice and the device supports it. The app cannot force an engine to
  download voice data or guarantee every third-party engine works.
- The project package id is com.grade8english.offline. Change it only if you
  need to match an existing Play Store/app identity.
