YARIEL SENSI - PROYECTO ANDROID ACTUALIZADO
Incluye tres modos de generación: PVP, BR y DECLA (Duelo de Escuadras).
Cada modo aplica un perfil inicial distinto y conserva selector de marca, modelo, nivel de sensibilidad y DPI opcional.

Para compilar: abre esta carpeta en Android Studio en una computadora, sincroniza Gradle y elige Build > Build Bundle(s) / APK(s) > Build APK(s).
También puedes probar AndroidIDE en Android, aunque puede requerir descargas grandes.

Los valores son sugerencias de prueba, no ajustes oficiales ni garantía de mejor puntería. La aplicación no modifica Free Fire.
