import { AlignmentType, Document, Packer, Paragraph } from "docx";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";
import type { Express, Request, Response } from "express";
import express from "express";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

const execFileAsync = promisify(execFile);
const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;
const MAX_PDF_PAGES = 120;

class DocumentError extends Error {
  constructor(
    readonly code: string,
    readonly status: number,
    message: string,
  ) {
    super(message);
    this.name = "DocumentError";
  }
}

function getFilename(req: Request) {
  const raw = typeof req.query.filename === "string" ? req.query.filename : "document";
  const basename = path.basename(raw.replaceAll("\\", "/"));
  const normalized = basename.normalize("NFKC").replace(/[^\p{L}\p{N}._ -]/gu, "_").slice(0, 120);
  return normalized || "document";
}

function getExtension(filename: string) {
  return path.extname(filename).toLowerCase();
}

function validateBuffer(buffer: Buffer, extension: string) {
  if (!buffer.length) {
    throw new DocumentError("EMPTY_FILE", 400, "The selected file is empty.");
  }
  const isPdf = buffer.subarray(0, 1024).includes(Buffer.from("%PDF-"));
  const isZip = buffer.length >= 4 && buffer[0] === 0x50 && buffer[1] === 0x4b;
  const isLegacyWord = buffer.subarray(0, 8).equals(Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]));
  const valid = extension === ".pdf" ? isPdf : extension === ".docx" ? isZip : extension === ".doc" ? isLegacyWord : false;
  if (!valid) {
    throw new DocumentError("INVALID_FILE", 415, "The file contents do not match a supported document format.");
  }
}

async function wordToPdf(buffer: Buffer, extension: ".doc" | ".docx") {
  const workDir = await mkdtemp(path.join(tmpdir(), "docreader-"));
  const inputPath = path.join(workDir, `source${extension}`);
  const outputPath = path.join(workDir, "source.pdf");
  try {
    await writeFile(inputPath, buffer, { mode: 0o600 });
    await execFileAsync(
      "libreoffice",
      [
        `-env:UserInstallation=${pathToFileURL(path.join(workDir, "profile")).toString()}`,
        "--headless",
        "--convert-to",
        "pdf:writer_pdf_Export",
        "--outdir",
        workDir,
        inputPath,
      ],
      { timeout: 60_000, maxBuffer: 1024 * 1024 },
    );
    return await readFile(outputPath);
  } catch (error) {
    console.error("[Document conversion] Word to PDF failed:", error);
    throw new DocumentError("CONVERSION_FAILED", 422, "The Word document could not be converted.");
  } finally {
    await rm(workDir, { recursive: true, force: true }).catch(() => undefined);
  }
}

function isRtl(text: string) {
  return /[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]/u.test(text);
}

async function pdfToDocx(buffer: Buffer) {
  let loadingTask: ReturnType<typeof getDocument> | undefined;
  try {
    loadingTask = getDocument({ data: new Uint8Array(buffer), useSystemFonts: true });
    const pdf = await loadingTask.promise;
    if (pdf.numPages > MAX_PDF_PAGES) {
      throw new DocumentError("TOO_MANY_PAGES", 413, "The PDF contains too many pages to convert.");
    }

    const paragraphs: Paragraph[] = [];
    let textLength = 0;
    for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
      const page = await pdf.getPage(pageNumber);
      const content = await page.getTextContent();
      const pageLines: string[] = [];
      let line = "";
      for (const candidate of content.items) {
        if (!("str" in candidate) || typeof candidate.str !== "string") continue;
        line += candidate.str;
        if (candidate.hasEOL) {
          const cleaned = line.trim();
          if (cleaned) pageLines.push(cleaned);
          line = "";
        }
      }
      const trailing = line.trim();
      if (trailing) pageLines.push(trailing);
      page.cleanup();

      for (const [lineIndex, text] of pageLines.entries()) {
        textLength += text.length;
        if (textLength > 1_000_000) {
          throw new DocumentError("DOCUMENT_TOO_LARGE", 413, "The extracted document text is too large.");
        }
        const rtl = isRtl(text);
        paragraphs.push(new Paragraph({
          text,
          bidirectional: rtl,
          alignment: rtl ? AlignmentType.RIGHT : AlignmentType.LEFT,
          pageBreakBefore: pageNumber > 1 && lineIndex === 0,
          spacing: { after: 100 },
        }));
      }
    }

    if (paragraphs.length === 0) {
      throw new DocumentError("NO_EXTRACTABLE_TEXT", 422, "No selectable text was found in this PDF.");
    }

    const document = new Document({
      sections: [{
        properties: { page: { margin: { top: 900, right: 900, bottom: 900, left: 900 } } },
        children: paragraphs,
      }],
    });
    return await Packer.toBuffer(document);
  } catch (error) {
    if (error instanceof DocumentError) throw error;
    console.error("[Document conversion] PDF text extraction failed:", error);
    throw new DocumentError("CONVERSION_FAILED", 422, "The PDF text could not be converted to Word.");
  } finally {
    if (loadingTask) await loadingTask.destroy().catch(() => undefined);
  }
}

function setDownloadHeaders(res: Response, filename: string, contentType: string, disposition: "inline" | "attachment") {
  const encoded = encodeURIComponent(filename).replace(/[!'()*]/g, character => `%${character.charCodeAt(0).toString(16).toUpperCase()}`);
  res.setHeader("Content-Type", contentType);
  res.setHeader("Content-Disposition", `${disposition}; filename*=UTF-8''${encoded}`);
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
}

function sendDocumentError(res: Response, error: unknown) {
  if (error instanceof DocumentError) {
    return res.status(error.status).json({ code: error.code, error: error.message });
  }
  console.error("[Document processing] Unexpected error:", error);
  return res.status(500).json({ code: "INTERNAL_ERROR", error: "The document could not be processed." });
}

function documentHandler(
  operation: (req: Request, buffer: Buffer, filename: string) => Promise<{ data: Buffer; filename: string; contentType: string; disposition: "inline" | "attachment" }>,
) {
  return async (req: Request, res: Response) => {
    try {
      if (!Buffer.isBuffer(req.body)) {
        throw new DocumentError("EMPTY_FILE", 400, "No document was received.");
      }
      const filename = getFilename(req);
      const extension = getExtension(filename);
      validateBuffer(req.body, extension);
      const result = await operation(req, req.body, filename);
      setDownloadHeaders(res, result.filename, result.contentType, result.disposition);
      return res.status(200).send(result.data);
    } catch (error) {
      return sendDocumentError(res, error);
    }
  };
}

export function registerDocumentRoutes(app: Express) {
  const rawDocument = express.raw({ type: "application/octet-stream", limit: MAX_UPLOAD_BYTES });

  app.post(
    "/api/documents/preview",
    rawDocument,
    documentHandler(async (_req, buffer, filename) => {
      const extension = getExtension(filename);
      if (extension !== ".doc" && extension !== ".docx") {
        throw new DocumentError("UNSUPPORTED_FORMAT", 415, "Only Word documents can be previewed here.");
      }
      const data = await wordToPdf(buffer, extension);
      return { data, filename: `${path.parse(filename).name}.pdf`, contentType: "application/pdf", disposition: "inline" };
    }),
  );

  app.post(
    "/api/documents/convert",
    rawDocument,
    documentHandler(async (req, buffer, filename) => {
      const target = typeof req.query.to === "string" ? req.query.to : "";
      const extension = getExtension(filename);
      if (target === "pdf" && (extension === ".doc" || extension === ".docx")) {
        const data = await wordToPdf(buffer, extension);
        return { data, filename: `${path.parse(filename).name}.pdf`, contentType: "application/pdf", disposition: "attachment" };
      }
      if (target === "docx" && extension === ".pdf") {
        const data = await pdfToDocx(buffer);
        return { data, filename: `${path.parse(filename).name}.docx`, contentType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", disposition: "attachment" };
      }
      throw new DocumentError("UNSUPPORTED_CONVERSION", 415, "This conversion is not supported for the selected file.");
    }),
  );
}
