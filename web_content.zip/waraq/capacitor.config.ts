import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.waraq.reader',
  appName: 'وَرَق',
  webDir: 'dist/public',
  bundledWebRuntime: false,
  android: { allowMixedContent: false },
};

export default config;
