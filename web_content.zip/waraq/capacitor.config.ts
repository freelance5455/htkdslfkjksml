import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.waraq.reader',
  appName: 'ورق',
  webDir: 'dist/public',
  bundledWebRuntime: false,
  android: { backgroundColor: '#f6f5f0' },
};

export default config;
