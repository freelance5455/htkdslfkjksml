import { useEffect, useRef, useState } from "react";
import { getDocument, GlobalWorkerOptions } from "pdfjs-dist";
import workerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";
import { ChevronLeft, ChevronRight, LoaderCircle, ZoomIn, ZoomOut } from "lucide-react";

GlobalWorkerOptions.workerSrc = workerUrl;

type Language = "ar" | "en";
type PdfDocument = Awaited<ReturnType<typeof getDocument>["promise"]>;

const labels = {
  ar: { previous: "الصفحة السابقة", next: "الصفحة التالية", zoomOut: "تصغير", zoomIn: "تكبير", page: "صفحة", of: "من", loading: "يتم تجهيز المعاينة…", loadError: "تعذرت قراءة هذا الملف. جرّب ملف PDF آخر." },
  en: { previous: "Previous page", next: "Next page", zoomOut: "Zoom out", zoomIn: "Zoom in", page: "Page", of: "of", loading: "Preparing preview…", loadError: "Could not read this file. Try another PDF." },
} satisfies Record<Language, Record<string, string>>;

export default function PdfViewer({ sourceUrl, language }: { sourceUrl: string; language: Language }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const renderTaskRef = useRef<{ cancel: () => void } | null>(null);
  const [documentProxy, setDocumentProxy] = useState<PdfDocument | null>(null);
  const [pageNumber, setPageNumber] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState(false);
  const [stageWidth, setStageWidth] = useState(0);
  const text = labels[language];

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    const updateWidth = () => setStageWidth(stage.clientWidth);
    updateWidth();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(updateWidth);
    observer?.observe(stage);
    window.addEventListener("resize", updateWidth);
    return () => {
      observer?.disconnect();
      window.removeEventListener("resize", updateWidth);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    let loadingTask: ReturnType<typeof getDocument> | null = null;
    setBusy(true);
    setError(false);
    setPageNumber(1);
    setDocumentProxy(null);

    async function load() {
      try {
        const response = await fetch(sourceUrl);
        if (!response.ok) throw new Error("PDF request failed");
        const data = new Uint8Array(await response.arrayBuffer());
        loadingTask = getDocument({ data });
        const loaded = await loadingTask.promise;
        if (cancelled) {
          await loadingTask.destroy();
          return;
        }
        setDocumentProxy(loaded);
        setBusy(false);
      } catch {
        if (!cancelled) {
          setError(true);
          setBusy(false);
        }
      }
    }

    void load();
    return () => {
      cancelled = true;
      if (loadingTask) void loadingTask.destroy();
    };
  }, [sourceUrl]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const stage = stageRef.current;
    if (!documentProxy || !canvas || !stage || stageWidth === 0) return;

    let cancelled = false;
    renderTaskRef.current?.cancel();
    setBusy(true);

    async function render() {
      try {
        const page = await documentProxy!.getPage(pageNumber);
        if (cancelled) return;
        const baseViewport = page.getViewport({ scale: 1 });
        const availableWidth = Math.max(280, stageWidth - 48);
        const fitScale = Math.min(1.4, availableWidth / baseViewport.width);
        const viewport = page.getViewport({ scale: fitScale * zoom });
        const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
        canvas!.width = Math.floor(viewport.width * pixelRatio);
        canvas!.height = Math.floor(viewport.height * pixelRatio);
        canvas!.style.width = `${viewport.width}px`;
        canvas!.style.height = `${viewport.height}px`;
        const task = page.render({
          canvas: canvas!,
          viewport,
          transform: pixelRatio === 1 ? undefined : [pixelRatio, 0, 0, pixelRatio, 0, 0],
        });
        renderTaskRef.current = task;
        await task.promise;
        if (!cancelled) setBusy(false);
      } catch (renderError) {
        if (!cancelled && !(renderError instanceof Error && renderError.name === "RenderingCancelledException")) {
          setError(true);
          setBusy(false);
        }
      }
    }

    void render();
    return () => {
      cancelled = true;
      renderTaskRef.current?.cancel();
    };
  }, [documentProxy, pageNumber, zoom, stageWidth]);

  const pageCount = documentProxy?.numPages ?? 0;

  return (
    <section className="pdf-viewer" aria-label={language === "ar" ? "عارض المستند" : "Document viewer"}>
      <div className="viewer-toolbar">
        <div className="viewer-page-control">
          <button type="button" className="icon-button" onClick={() => setPageNumber(value => Math.max(1, value - 1))} disabled={pageNumber <= 1 || busy} aria-label={text.previous} title={text.previous}>
            {language === "ar" ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>
          <span className="page-count"><strong>{pageCount ? pageNumber : "—"}</strong><span>{text.of}</span><strong>{pageCount || "—"}</strong></span>
          <button type="button" className="icon-button" onClick={() => setPageNumber(value => Math.min(pageCount, value + 1))} disabled={!pageCount || pageNumber >= pageCount || busy} aria-label={text.next} title={text.next}>
            {language === "ar" ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
          </button>
        </div>
        <span className="viewer-divider" />
        <div className="viewer-zoom-control">
          <button type="button" className="icon-button" onClick={() => setZoom(value => Math.max(0.7, +(value - 0.15).toFixed(2)))} disabled={zoom <= 0.7} aria-label={text.zoomOut} title={text.zoomOut}><ZoomOut size={17} /></button>
          <span className="zoom-value">{Math.round(zoom * 100)}%</span>
          <button type="button" className="icon-button" onClick={() => setZoom(value => Math.min(1.75, +(value + 0.15).toFixed(2)))} disabled={zoom >= 1.75} aria-label={text.zoomIn} title={text.zoomIn}><ZoomIn size={17} /></button>
        </div>
      </div>
      <div className="pdf-stage" ref={stageRef}>
        {busy && <div className="viewer-loading"><LoaderCircle className="spin" size={22} /><span>{text.loading}</span></div>}
        {error && <div className="viewer-error">{text.loadError}</div>}
        <canvas ref={canvasRef} className={`pdf-canvas${busy || error ? " is-hidden" : ""}`} />
      </div>
    </section>
  );
}
