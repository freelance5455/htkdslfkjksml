import { lazy, Suspense, useEffect, useRef, useState, type ChangeEvent, type DragEvent } from "react";
import { ArrowDownToLine,
  ArrowLeftRight,
  BookOpenText,
  Check,
  ChevronLeft,
  ChevronRight,
  Download,
  FilePlus2,
  FileText,
  Languages,
  LoaderCircle,
  LockKeyhole,
  RefreshCw,
  Sparkles,
  Upload,
  X,
} from "lucide-react";
const PdfViewer = lazy(() => import("@/components/PdfViewer"));

type Language = "ar" | "en";
type ConversionState = "idle" | "preview" | "convert";
type DeferredInstallPrompt = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
};

const copy = {
  ar: {
    brand: "وَرَق", brandSub: "قارئ المستندات", switchLanguage: "English", eyebrow: "مساحة قراءة ثنائية اللغة", heroTitle: "ملفاتك،\nأوضح من أي وقت.", heroText: "اقرأ PDF وWord في مساحة واحدة، ثم حوّل الملف إلى الصيغة التي تحتاجها — بخطوات بسيطة ومن جهازك.", workspace: "مساحة المستندات", workspaceHint: "افتح ملفًا من جهازك للبدء", selectFile: "اختيار مستند", dropTitle: "أفلت المستند هنا", dropHint: "أو اضغط لاختيار ملف من جهازك", formats: "PDF · DOCX · DOC", maxSize: "حتى 25 ميغابايت", privateTitle: "مستندك يبقى لك", privateText: "تُعالج الملفات مؤقتًا لإظهار المعاينة أو التحويل، ولا تُحفظ في مكتبة سحابية.", itemRead: "قراءة واضحة", itemReadSub: "تنقل وتكبير مريح", itemConvert: "تحويل داخل التطبيق", itemConvertSub: "Word ↔ PDF", itemLanguage: "لغتان", itemLanguageSub: "عربي وإنجليزي", languageArabic: "العربية", languageEnglish: "English", openDocument: "فتح مستند", back: "العودة للمكتبة", convertToPdf: "تحويل إلى PDF", convertToWord: "تحويل إلى Word", previewing: "تحضير معاينة Word…", converting: "جارٍ تحويل المستند…", uploadError: "تعذر فتح الملف. تأكد من أن الملف Word أو PDF صالح.", unsupported: "هذا النوع غير مدعوم. اختر ملف PDF أو Word بصيغة DOCX أو DOC.", tooLarge: "حجم الملف أكبر من 25 ميغابايت.", conversionError: "تعذر التحويل. جرّب ملفًا آخر أو تأكد من سلامة المستند.", noText: "لم يُعثر على نص قابل للاستخراج. قد يكون PDF ممسوحًا ضوئيًا؛ يلزم OCR لتحويله إلى Word.", successPdf: "تم تنزيل ملف PDF.", successWord: "تم تنزيل ملف Word. قد يختلف التخطيط عن ملف PDF الأصلي.", privacy: "المعالجة مؤقتة وآمنة", previewNote: "المعاينة لا تغيّر الملف الأصلي.", convertingNote: "بعض ملفات PDF المعقدة أو الممسوحة ضوئيًا قد لا تتحول إلى Word بتنسيق مطابق.", fileLabel: "المستند المفتوح", fileWord: "مستند Word", filePdf: "مستند PDF", replaceFile: "فتح ملف آخر", closeMessage: "إغلاق التنبيه",
  },
  en: {
    brand: "WARAQ", brandSub: "Document reader", switchLanguage: "العربية", eyebrow: "A bilingual reading space", heroTitle: "Your documents,\nclearer than ever.", heroText: "Read PDF and Word in one place, then convert to the format you need — in a few simple steps, right from your device.", workspace: "Document workspace", workspaceHint: "Open a file from your device to begin", selectFile: "Choose a document", dropTitle: "Drop your document here", dropHint: "or tap to choose a file from your device", formats: "PDF · DOCX · DOC", maxSize: "Up to 25 MB", privateTitle: "Your document stays yours", privateText: "Files are processed temporarily for preview or conversion and are not saved to a cloud library.", itemRead: "Clear reading", itemReadSub: "Comfortable page navigation", itemConvert: "Convert in-app", itemConvertSub: "Word ↔ PDF", itemLanguage: "Two languages", itemLanguageSub: "Arabic and English", languageArabic: "العربية", languageEnglish: "English", openDocument: "Open a document", back: "Back to library", convertToPdf: "Convert to PDF", convertToWord: "Convert to Word", previewing: "Preparing Word preview…", converting: "Converting document…", uploadError: "Could not open this file. Make sure it is a valid Word or PDF document.", unsupported: "Unsupported file type. Choose a PDF or a Word file in DOCX or DOC format.", tooLarge: "This file is larger than 25 MB.", conversionError: "Conversion failed. Try another file or check that this document is valid.", noText: "No selectable text was found. This may be a scanned PDF; OCR is required to convert it to Word.", successPdf: "PDF downloaded.", successWord: "Word document downloaded. Its layout may differ from the original PDF.", privacy: "Temporary, private processing", previewNote: "Previewing does not change the original file.", convertingNote: "Complex layouts or scanned PDFs may not convert to Word with matching formatting.", fileLabel: "Open document", fileWord: "Word document", filePdf: "PDF document", replaceFile: "Open another file", closeMessage: "Dismiss message",
  },
} satisfies Record<Language, Record<string, string>>;

const pdfConversionLimitations: Record<Language, string> = {
  ar: "PDF إلى Word يعيد بناء النص القابل للاستخراج فقط؛ قد لا يحفظ الصور أو التخطيط. لا يتوفر OCR للصفحات المصوّرة. حد التحويل 120 صفحة.",
  en: "PDF to Word reconstructs selectable text only; images and layout may be lost. OCR for scanned pages is not included. Conversion limit: 120 pages.",
};
const installCopy: Record<Language, { label: string; fallback: string }> = {
  ar: { label: "تثبيت التطبيق", fallback: "للتثبيت على Android، افتح قائمة Chrome (⋮) واختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية». على iPhone، استخدم «مشاركة» ثم «إضافة إلى الشاشة الرئيسية»." },
  en: { label: "Install app", fallback: "On Android, open Chrome menu (⋮) and choose Install app or Add to Home screen. On iPhone, use Share, then Add to Home Screen." },
};

function extensionOf(fileName: string) {
  return fileName.split(".").pop()?.toLowerCase() ?? "";
}

function localError(code: string, text: Record<string, string>) {
  if (code === "TOO_LARGE" || code === "LIMIT_FILE_SIZE") return text.tooLarge;
  if (code === "TOO_MANY_PAGES") return text.brand === "وَرَق" ? "يدعم التحويل ملفات PDF حتى 120 صفحة." : "PDF conversion supports up to 120 pages.";
  if (code === "NO_EXTRACTABLE_TEXT") return text.noText;
  if (code === "UNSUPPORTED_FORMAT" || code === "UNSUPPORTED_CONVERSION" || code === "INVALID_FILE") return text.unsupported;
  return text.conversionError;
}

export default function Home() {
  const [language, setLanguage] = useState<Language>(() => {
    try {
      return localStorage.getItem("waraq-language") === "en" ? "en" : "ar";
    } catch {
      return "ar";
    }
  });
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [conversionState, setConversionState] = useState<ConversionState>("idle");
  const [message, setMessage] = useState<{ text: string; kind: "success" | "error" } | null>(null);
  const [dragging, setDragging] = useState(false);
  const [converting, setConverting] = useState(false);
  const [installPromptEvent, setInstallPromptEvent] = useState<DeferredInstallPrompt | null>(null);
  const [isInstalled, setIsInstalled] = useState(() => {
    if (typeof window === "undefined") return false;
    const standalone = typeof window.matchMedia === "function" && window.matchMedia("(display-mode: standalone)").matches;
    const iosStandalone = (navigator as Navigator & { standalone?: boolean }).standalone === true;
    return standalone || iosStandalone;
  });
  const pickerRef = useRef<HTMLInputElement>(null);
  const text = copy[language];
  const fileExtension = file ? extensionOf(file.name) : "";
  const isPdf = fileExtension === "pdf";
  const outputType = isPdf ? "docx" : "pdf";

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    try {
      localStorage.setItem("waraq-language", language);
    } catch {
      // Language selection still works when storage is unavailable.
    }
  }, [language]);

  useEffect(() => {
    const captureInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPromptEvent(event as DeferredInstallPrompt);
    };
    const markInstalled = () => {
      setInstallPromptEvent(null);
      setIsInstalled(true);
    };
    window.addEventListener("beforeinstallprompt", captureInstallPrompt);
    window.addEventListener("appinstalled", markInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", captureInstallPrompt);
      window.removeEventListener("appinstalled", markInstalled);
    };
  }, []);

  useEffect(() => () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
  }, [previewUrl]);

  async function handleInstall() {
    if (!installPromptEvent) {
      setMessage({ text: installCopy[language].fallback, kind: "success" });
      return;
    }
    try {
      await installPromptEvent.prompt();
      const choice = await installPromptEvent.userChoice;
      if (choice.outcome === "accepted") setIsInstalled(true);
    } catch {
      setMessage({ text: installCopy[language].fallback, kind: "success" });
    } finally {
      setInstallPromptEvent(null);
    }
  }

  async function openFile(nextFile: File) {
    setMessage(null);
    const extension = extensionOf(nextFile.name);
    if (!new Set(["pdf", "docx", "doc"]).has(extension)) {
      setMessage({ text: text.unsupported, kind: "error" });
      return;
    }
    if (nextFile.size > 25 * 1024 * 1024) {
      setMessage({ text: text.tooLarge, kind: "error" });
      return;
    }

    setFile(nextFile);
    setPreviewUrl("");
    if (extension === "pdf") {
      setPreviewUrl(URL.createObjectURL(nextFile));
      setConversionState("idle");
      return;
    }

    setConversionState("preview");
    try {
      const response = await fetch(`/api/documents/preview?filename=${encodeURIComponent(nextFile.name)}`, {
        method: "POST",
        headers: { "Content-Type": "application/octet-stream" },
        body: nextFile,
      });
      if (!response.ok) {
        const problem = await response.json().catch(() => ({})) as { code?: string };
        throw new Error(problem.code ?? (response.status === 413 ? "TOO_LARGE" : "CONVERSION_FAILED"));
      }
      const pdf = await response.blob();
      setPreviewUrl(URL.createObjectURL(pdf));
      setMessage({ text: text.previewNote, kind: "success" });
      setConversionState("idle");
    } catch (error) {
      setFile(null);
      setConversionState("idle");
      setMessage({ text: localError(error instanceof Error ? error.message : "", text), kind: "error" });
    }
  }

  function handleInputChange(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.target.files?.[0];
    if (selected) void openFile(selected);
    event.target.value = "";
  }

  function handleDrop(event: DragEvent<HTMLButtonElement>) {
    event.preventDefault();
    setDragging(false);
    const dropped = event.dataTransfer.files[0];
    if (dropped) void openFile(dropped);
  }

  async function convertFile() {
    if (!file || converting) return;
    setConverting(true);
    setConversionState("convert");
    setMessage(null);
    try {
      const params = new URLSearchParams({ to: outputType, filename: file.name });
      const response = await fetch(`/api/documents/convert?${params.toString()}`, {
        method: "POST",
        headers: { "Content-Type": "application/octet-stream" },
        body: file,
      });
      if (!response.ok) {
        const problem = await response.json().catch(() => ({})) as { code?: string };
        throw new Error(problem.code ?? (response.status === 413 ? "TOO_LARGE" : "CONVERSION_FAILED"));
      }
      const converted = await response.blob();
      const url = URL.createObjectURL(converted);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `${file.name.replace(/\.[^.]+$/, "")}.${outputType}`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1500);
      setMessage({ text: isPdf ? text.successWord : text.successPdf, kind: "success" });
    } catch (error) {
      setMessage({ text: localError(error instanceof Error ? error.message : "", text), kind: "error" });
    } finally {
      setConverting(false);
      setConversionState("idle");
    }
  }

  function clearFile() {
    setFile(null);
    setPreviewUrl("");
    setConversionState("idle");
    setMessage(null);
  }

  return (
    <div className={`app-shell ${language === "ar" ? "is-arabic" : "is-english"}`} dir={language === "ar" ? "rtl" : "ltr"} lang={language}>
      <header className="topbar">
        <a className="brand" href="/" onClick={event => { event.preventDefault(); clearFile(); }} aria-label={text.brandSub}>
          <span className="brand-mark"><span /><span /><span /></span>
          <span className="brand-copy"><strong>{text.brand}</strong><small>{text.brandSub}</small></span>
        </a>
        <div className="topbar-actions">
          <span className="topbar-caption"><span className="status-dot" />{text.privacy}</span>
          {!isInstalled && <button className="install-button" type="button" onClick={() => void handleInstall()} aria-label={installCopy[language].label} title={installCopy[language].label}><Download size={16} /><span className="install-label">{installCopy[language].label}</span></button>}
          <button className="language-button" type="button" onClick={() => setLanguage(value => value === "ar" ? "en" : "ar")} aria-label={text.switchLanguage}>
            <Languages size={17} /><span>{text.switchLanguage}</span>
          </button>
        </div>
      </header>

      {file && previewUrl ? (
        <main className="reader-page">
          <div className="reader-heading">
            <button className="back-button" type="button" onClick={clearFile}>
              {language === "ar" ? <ChevronRight size={17} /> : <ChevronLeft size={17} />}
              <span>{text.back}</span>
            </button>
            <div className="reader-file-meta">
              <span className={`file-type-icon ${isPdf ? "pdf" : "word"}`}><FileText size={19} /></span>
              <div className="reader-file-name"><span>{text.fileLabel}</span><strong title={file.name}>{file.name}</strong></div>
            </div>
            <div className="reader-actions">
              <button className="secondary-button replace-button" type="button" onClick={() => pickerRef.current?.click()}><RefreshCw size={16} /><span>{text.replaceFile}</span></button>
              <button className="primary-button convert-button" type="button" onClick={() => void convertFile()} disabled={converting}>
                {converting ? <LoaderCircle className="spin" size={17} /> : <ArrowDownToLine size={17} />}
                <span>{converting ? text.converting : isPdf ? text.convertToWord : text.convertToPdf}</span>
              </button>
            </div>
          </div>
          <section className="reader-canvas-area">
            <div className="reader-canvas-header"><span>{isPdf ? text.filePdf : text.fileWord}</span><span className="format-chip">.{isPdf ? "PDF" : fileExtension.toUpperCase()}</span></div>
            <Suspense fallback={<div className="pdf-viewer"><div className="pdf-stage"><div className="viewer-loading"><LoaderCircle className="spin" size={22} /><span>{text.previewing}</span></div></div></div>}>
              <PdfViewer sourceUrl={previewUrl} language={language} />
            </Suspense>
            {!isPdf && <p className="conversion-note"><Sparkles size={14} />{text.previewNote}</p>}
            {isPdf && <p className="conversion-note"><Sparkles size={14} />{pdfConversionLimitations[language]}</p>}
          </section>
        </main>
      ) : (
        <main className="home-page">
          <section className="hero-copy">
            <span className="eyebrow"><span className="eyebrow-line" />{text.eyebrow}</span>
            <h1>{text.heroTitle.split("\n").map((line, index) => <span key={line} className={index === 1 ? "hero-title-accent" : ""}>{line}</span>)}</h1>
            <p>{text.heroText}</p>
            <div className="feature-list">
              <div className="feature-item"><span className="feature-icon"><BookOpenText size={19} /></span><span><strong>{text.itemRead}</strong><small>{text.itemReadSub}</small></span></div>
              <div className="feature-item"><span className="feature-icon"><ArrowLeftRight size={19} /></span><span><strong>{text.itemConvert}</strong><small>{text.itemConvertSub}</small></span></div>
              <div className="feature-item"><span className="feature-icon"><Languages size={19} /></span><span><strong>{text.itemLanguage}</strong><small>{text.itemLanguageSub}</small></span></div>
            </div>
          </section>

          <section className="workspace-card">
            <div className="workspace-card-head">
              <div className="workspace-title-icon"><BookOpenText size={22} /></div>
              <div className="workspace-title"><h2>{text.workspace}</h2><p>{text.workspaceHint}</p></div>
              <span className="workspace-counter"><span className="status-dot" />{text.openDocument}</span>
            </div>
            <button
              className={`dropzone${dragging ? " is-dragging" : ""}`}
              type="button"
              onClick={() => pickerRef.current?.click()}
              onDragOver={event => { event.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
            >
              <span className="upload-orbit"><Upload size={24} /></span>
              <span className="dropzone-title">{dragging ? text.dropTitle : text.dropTitle}</span>
              <span className="dropzone-subtitle">{text.dropHint}</span>
              <span className="format-pills"><span>PDF</span><span>DOCX</span><span>DOC</span></span>
              <span className="dropzone-foot"><FilePlus2 size={14} />{text.maxSize}</span>
            </button>
            <input ref={pickerRef} className="visually-hidden-input" type="file" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" onChange={handleInputChange} />
            <div className="privacy-callout"><span className="privacy-icon"><LockKeyhole size={16} /></span><span><strong>{text.privateTitle}</strong><small>{text.privateText}</small></span><Check className="privacy-check" size={16} /></div>
          </section>

          <footer className="home-footer"><span>{text.brand} · {text.brandSub}</span><span><span className="status-dot" />{text.privacy}</span></footer>
        </main>
      )}

      {conversionState !== "idle" && (
        <div className="processing-toast" role="status" aria-live="polite">
          <LoaderCircle className="spin" size={18} /><span>{conversionState === "preview" ? text.previewing : text.converting}</span>
          <span className="processing-bar"><span /></span>
        </div>
      )}
      {message && (
        <div className={`notice-toast ${message.kind}`} role="status" aria-live="polite">
          {message.kind === "success" ? <Check size={17} /> : <X size={17} />}
          <span>{message.text}</span>
          <button type="button" onClick={() => setMessage(null)} aria-label={text.closeMessage}><X size={16} /></button>
        </div>
      )}
      {file && !previewUrl && conversionState === "preview" && (
        <button className="floating-back" type="button" onClick={clearFile}>{text.back}</button>
      )}
    </div>
  );
}
