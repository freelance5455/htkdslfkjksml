const CACHE_NAME = "waraq-pwa-v1";
const SHELL_ASSETS = [
  "/manifest.webmanifest",
  "/favicon.svg",
  "/icons/waraq-180.png",
  "/icons/waraq-192.png",
  "/icons/waraq-512.png",
];
const NEVER_CACHE_PREFIXES = ["/api/", "/manus-storage/", "/__manus/", "/__system__/"];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(SHELL_ASSETS))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith("waraq-pwa-") && key !== CACHE_NAME).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin || NEVER_CACHE_PREFIXES.some(prefix => url.pathname.startsWith(prefix))) return;
  if (url.pathname === "/manus-routes.json") return;

  if (request.mode === "navigate") {
    event.respondWith(fetch(request).then(async response => {
      const cacheControl = response.headers.get("cache-control") || "";
      const safeToCache = response.ok
        && (response.headers.get("content-type") || "").includes("text/html")
        && !response.headers.has("set-cookie")
        && !/no-store|private/i.test(cacheControl);
      if (safeToCache) {
        try {
          await (await caches.open(CACHE_NAME)).put("/", response.clone());
        } catch {
          // Keep the online response even when storage is full or unavailable.
        }
      }
      return response;
    }).catch(async () => {
      return await caches.match("/") || new Response("أنت غير متصل بالإنترنت. أعد الاتصال لفتح وَرَق.", {
        status: 503,
        headers: { "Content-Type": "text/plain; charset=utf-8" },
      });
    }));
    return;
  }

  const isPublicAsset = url.pathname.startsWith("/assets/")
    || url.pathname.startsWith("/icons/")
    || url.pathname === "/favicon.svg"
    || url.pathname === "/manifest.webmanifest";
  if (!isPublicAsset) return;

  event.respondWith(caches.match(request).then(async cached => {
    if (cached) return cached;
    const response = await fetch(request);
    if (response.ok && response.type === "basic") {
      await (await caches.open(CACHE_NAME)).put(request, response.clone());
    }
    return response;
  }));
});
