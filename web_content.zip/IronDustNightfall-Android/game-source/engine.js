import * as THREE from 'three';
import {createMaterials} from './materials';
import {buildRobot} from './robots';
import {buildArena,SCENES} from './arena';
import scoreUrl from './assets/nightfall-score.ogg';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'three/addons/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/addons/postprocessing/OutputPass.js';
export function createGame(host, update, input) {
  const scene=new THREE.Scene();scene.fog=new THREE.FogExp2(0xbca58e,.018);
  const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;renderer.shadowMap.autoUpdate=false;
  renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;host.appendChild(renderer.domElement);
  const camera=new THREE.PerspectiveCamera(70,1,.08,150);camera.rotation.order='YXZ';scene.add(camera);
  const sky=new THREE.Mesh(new THREE.SphereGeometry(100,24,16),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,uniforms:{low:{value:new THREE.Color(0xc58966)},high:{value:new THREE.Color(0x344855)},clock:{value:0}},vertexShader:'varying vec3 p; void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 p; uniform vec3 low; uniform vec3 high;uniform float clock; void main(){vec3 n=normalize(p);float t=clamp(n.y*1.8,0.,1.);float cloud=sin(n.x*37.+sin(n.z*23.+clock*.015))*sin(n.z*44.)*.022;vec3 col=mix(low,high,pow(t,.65))+cloud;gl_FragColor=vec4(col,1.);}'}));scene.add(sky);
  const hemi=new THREE.HemisphereLight(0xc4d9e1,0x766444,1.7);scene.add(hemi);
  const sun=new THREE.DirectionalLight(0xffc48c,2.6);sun.position.set(-20,24,-35);sun.castShadow=true;sun.shadow.mapSize.set(512,512);Object.assign(sun.shadow.camera,{left:-32,right:32,top:32,bottom:-32,near:1,far:100});sun.shadow.bias=-.001;scene.add(sun);
  const sunDisc=new THREE.Mesh(new THREE.SphereGeometry(3,24,16),new THREE.MeshBasicMaterial({color:0xffd199}));sunDisc.position.set(-38,24,-70);scene.add(sunDisc);
  // Lightweight local reflection sky; defer GPU conversion until the first actual scene render.
  const reflectionCanvas=document.createElement('canvas');reflectionCanvas.width=128;reflectionCanvas.height=64;const ctx=reflectionCanvas.getContext('2d'),gradient=ctx.createLinearGradient(0,0,0,64);gradient.addColorStop(0,'#5a809d');gradient.addColorStop(.48,'#c3bbb0');gradient.addColorStop(.52,'#806746');gradient.addColorStop(1,'#343b3b');ctx.fillStyle=gradient;ctx.fillRect(0,0,128,64);ctx.fillStyle='#e4d5b5';ctx.fillRect(25,19,12,9);const env=new THREE.CanvasTexture(reflectionCanvas);env.mapping=THREE.EquirectangularReflectionMapping;env.colorSpace=THREE.SRGBColorSpace;scene.environment=env;scene.environmentIntensity=.4;
  const composer=new EffectComposer(renderer);composer.addPass(new RenderPass(scene,camera));const bloom=new UnrealBloomPass(new THREE.Vector2(640,360),.24,.5,1.3);composer.addPass(bloom);composer.addPass(new OutputPass());
  let quality='balanced',lastRender=0,lastShadow=0;bloom.enabled=false;
  const {mats,textures}=createMaterials(renderer);
  let arena=buildArena(scene,mats,0),solids=arena.solids,obstacles=arena.obstacles;
  const bots=[],effects=[];
  function box(w,h,d,mat,x,y,z,parent=scene){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
  // Slow-moving floating dust, rendered in a single draw call.
  const dustPositions=new Float32Array(180*3);for(let i=0;i<180;i++){dustPositions[i*3]=Math.sin(i*72)*28;dustPositions[i*3+1]=.3+(i%30)*.2;dustPositions[i*3+2]=Math.cos(i*37)*28;}
  const dustGeo=new THREE.BufferGeometry();dustGeo.setAttribute('position',new THREE.BufferAttribute(dustPositions,3));const dust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0xeac8a0,size:.04,transparent:true,opacity:.38,depthWrite:false}));scene.add(dust);
  const flashlight=new THREE.SpotLight(0xaecfed,0,25,Math.PI/7,.7,1.2);flashlight.position.set(0,1.6,0);scene.add(flashlight);scene.add(flashlight.target);
  const muzzleLight=new THREE.PointLight(0xffc15c,0,7);camera.add(muzzleLight);muzzleLight.position.set(.25,-.1,-1);
  const gun=new THREE.Group();camera.add(gun);gun.position.set(.32,-.32,-.6);
  box(.19,.19,.57,mats.dark,0,0,0,gun);box(.21,.06,.5,mats.metal,0,.1,0,gun);box(.14,.16,.28,mats.steel,0,-.01,-.37,gun);box(.075,.075,.35,mats.dark,0,.015,-.62,gun);box(.12,.27,.16,mats.dark,0,-.2,.04,gun);
  box(.18,.035,.08,mats.metal,0,.27,-.12,gun);box(.03,.16,.08,mats.metal,-.08,.19,-.12,gun);box(.03,.16,.08,mats.metal,.08,.19,-.12,gun);box(.18,.03,.08,mats.metal,0,.12,-.12,gun);
  for(let i=0;i<8;i++)box(.2,.02,.022,mats.metal,0,.14,.17-i*.05,gun);
  const muzzle=new THREE.Mesh(new THREE.ConeGeometry(.12,.32,7),new THREE.MeshBasicMaterial({color:0xffdf88}));muzzle.rotation.x=-Math.PI/2;muzzle.position.set(0,.015,-.88);gun.add(muzzle);muzzle.visible=false;
  const handMat=new THREE.MeshStandardMaterial({color:0x3c4943,roughness:.95});box(.16,.15,.33,handMat,.12,-.14,.3,gun);box(.15,.12,.3,handMat,-.11,-.1,-.22,gun);
  let state='menu',hp=100,ammo=24,wave=1,kills=0,total=0,reloading=0,nextWave=0,lastShot=-1,yaw=0,pitch=0,time=0,recoil=0,shake=0,hit=0,lastHUD=0,intro=0,sceneIndex=0,selectedScene=0,campaign=true;
  let pos=new THREE.Vector3(0,1.7,20),audio=null,ambient=null,audioOn=true,musicOn=true;
  const music=new Audio(scoreUrl);music.loop=true;music.volume=.28;music.preload='auto';
  function playMusic(){if(musicOn)music.play().catch(()=>{});}
  const ray=new THREE.Raycaster();let previous=performance.now(),raf,disposed=false;
  function sound(type){if(!audioOn||!audio)return;const t=audio.currentTime;
    if(type==='shot'||type==='damage'){const len=type==='shot'?.14:.24,b=audio.createBuffer(1,audio.sampleRate*len,audio.sampleRate),a=b.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=(Math.random()*2-1)*Math.pow(1-i/a.length,3);const s=audio.createBufferSource();s.buffer=b;const f=audio.createBiquadFilter();f.type='lowpass';f.frequency.value=type==='shot'?1800:550;const g=audio.createGain();g.gain.value=.38;s.connect(f).connect(g).connect(audio.destination);s.start();}
    const o=audio.createOscillator(),g=audio.createGain();o.type=type==='kill'?'sine':'triangle';o.frequency.setValueAtTime(type==='shot'?130:type==='kill'?760:type==='reload'?340:95,t);o.frequency.exponentialRampToValueAtTime(type==='kill'?1200:45,t+.15);g.gain.setValueAtTime(.09,t);g.gain.exponentialRampToValueAtTime(.001,t+.22);o.connect(g).connect(audio.destination);o.start();o.stop(t+.25);
  }
  function initAudio(){playMusic();try{if(!audio){audio=new (window.AudioContext||window.webkitAudioContext)();const b=audio.createBuffer(1,audio.sampleRate*3,audio.sampleRate),a=b.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=(Math.random()*2-1)*.15;const s=audio.createBufferSource();s.buffer=b;s.loop=true;const f=audio.createBiquadFilter();f.type='lowpass';f.frequency.value=180;ambient=audio.createGain();ambient.gain.value=audioOn?.09:0;s.connect(f).connect(ambient).connect(audio.destination);s.start();}audio.resume();}catch(e){}}
  function clearBots(){for(const b of bots){scene.remove(b.group);b.group.traverse(o=>o.geometry?.dispose());}bots.length=0;}
  function clearEffects(){for(const e of effects){scene.remove(e.mesh);e.mesh.geometry.dispose();if(!e.bullet)e.mesh.material.dispose();}effects.length=0;}
  function setScene(index){sceneIndex=index;arena.dispose();arena=buildArena(scene,mats,index);solids=arena.solids;obstacles=arena.obstacles;const cfg=SCENES[index];sky.material.uniforms.low.value.set(cfg.skyLow);sky.material.uniforms.high.value.set(cfg.skyHigh);scene.fog.color.set(cfg.fog);scene.fog.density=index===2?.021:.014;sun.color.set(cfg.sun);sun.intensity=cfg.intensity;hemi.intensity=cfg.ambient;hemi.groundColor.set(index===2?0x1e2a3a:0x766444);renderer.toneMappingExposure=cfg.exposure;sunDisc.visible=index===0;scene.environmentIntensity=index===2?.25:.4;flashlight.intensity=index===2?15:0;}
  function spawnWave(){clearBots();total=wave+2;for(let i=0;i<total;i++){const robot=buildRobot(mats,sceneIndex===2&&i%2===0?2:sceneIndex===1?1:0);robot.group.position.set((i-(total-1)/2)*3.8,0,-8-(i%2)*6);scene.add(robot.group);bots.push({...robot,hp:sceneIndex===2&&i%2===0?6:3+Math.floor(wave/3),cooldown:3+i*.5,phase:i,alive:true,flash:0,avoid:0});}sound('reload');}
  function hud(){update({state,hp:Math.ceil(hp),ammo,wave,kills,remaining:bots.filter(b=>b.alive).length,reloading:reloading>0,hit:hit>0,damage:shake>.06,audioOn,musicOn,quality,sceneIndex,selectedScene,campaign,intro:Math.ceil(intro),transition:nextWave>0});}
  function blocked(x,z){return Math.abs(x)>27.8||Math.abs(z)>27.8||obstacles.some(b=>Math.abs(x-b.x)<b.w/2+.4&&Math.abs(z-b.z)<b.d/2+.4);}
  function move(p,dx,dz){if(!blocked(p.x+dx,p.z))p.x+=dx;if(!blocked(p.x,p.z+dz))p.z+=dz;}
  function reload(){if(state!=='playing'||reloading||ammo===24)return;reloading=1.5;sound('reload');hud();}
  function particle(at,color,count=8){for(let i=0;i<count;i++){const m=new THREE.Mesh(new THREE.BoxGeometry(.055,.055,.055),new THREE.MeshBasicMaterial({color}));m.position.copy(at);scene.add(m);effects.push({mesh:m,vel:new THREE.Vector3((Math.random()-.5)*4,Math.random()*3,(Math.random()-.5)*4),life:.45});}}
  function shoot(){if(state!=='playing'||reloading||time-lastShot<.115)return;if(ammo<=0){reload();return;}ammo--;lastShot=time;recoil=.09;muzzle.visible=true;sound('shot');
    scene.updateMatrixWorld(true);ray.setFromCamera(new THREE.Vector2(0,0),camera);const targets=bots.filter(b=>b.alive).map(b=>b.group);const intersections=ray.intersectObjects([...solids,...targets],true);let impact=intersections[0],target=null;
    if(impact){let o=impact.object;while(o){target=bots.find(b=>b.alive&&b.group===o);if(target)break;o=o.parent;}}
    // A small aim-assist cone keeps thumb aiming forgiving without shooting through cover.
    if(!target){const maxDistance=impact?.distance??80;let nearest=maxDistance;for(const b of bots){if(!b.alive)continue;const center=b.group.position.clone().add(new THREE.Vector3(0,1.65,0)),v=center.clone().sub(ray.ray.origin),along=v.dot(ray.ray.direction);if(along>0&&along<nearest&&ray.ray.distanceToPoint(center)<Math.max(.4,along*.018)){nearest=along;target=b;impact={point:center,distance:along};}}}
    if(target){target.hp--;target.flash=.18;hit=.16;particle(impact.point,0x9ffff1);if(target.hp<=0){target.alive=false;kills++;sound('kill');particle(target.group.position.clone().add(new THREE.Vector3(0,1.4,0)),0xffbb6a,18);target.fall=1;target.group.rotation.z=.1;if(bots.every(q=>!q.alive)){if(wave===3){state='won';music.volume=.18;}else{nextWave=3;hp=Math.min(100,hp+25);}}}}else if(impact)particle(impact.point,0xffce83,5);
    hud();
  }
  function beginIntro(){state='intro';intro=3.5;input.current.fire=false;input.current.moveX=input.current.moveY=0;music.volume=.28;pos.set(0,1.7,20);yaw=pitch=0;camera.position.copy(pos);camera.rotation.set(0,0,0);}
  const api={start(){initAudio();hp=100;ammo=24;wave=1;kills=0;setScene(campaign?0:selectedScene);reloading=nextWave=0;clearEffects();spawnWave();beginIntro();hud();},pause(){if(state==='playing'){state='paused';music.volume=.12;}else if(state==='paused'){state='playing';previous=performance.now();initAudio();music.volume=.28;}input.current.fire=false;hud();},menu(){state='menu';input.current.fire=false;music.volume=.15;hud();},skipIntro(){if(state==='intro'){intro=0;state='playing';hud();}},selectScene(index){selectedScene=index;campaign=false;initAudio();hud();},campaign(){campaign=true;initAudio();hud();},quality(){quality=quality==='balanced'?'cinematic':'balanced';bloom.enabled=quality==='cinematic';renderer.setPixelRatio(Math.min(devicePixelRatio,quality==='cinematic'?1.65:1.25));resize();hud();},music(){musicOn=!musicOn;if(musicOn)playMusic();else music.pause();hud();},reload,audio(){audioOn=!audioOn;if(ambient)ambient.gain.value=audioOn?.09:0;hud();},look(dx,dy){if(state==='playing'){yaw-=dx*.004;pitch=THREE.MathUtils.clamp(pitch-dy*.003,-1.15,1.15);}},shoot};
  function resize(){const w=host.clientWidth,h=host.clientHeight;renderer.setSize(w,h);composer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();}const ro=new ResizeObserver(resize);ro.observe(host);resize();
  function frame(){if(disposed)return;raf=requestAnimationFrame(frame);const now=performance.now();if(now-lastRender<33)return;lastRender=now;const dt=Math.min((now-previous)/1000,.1);previous=now;time+=dt;
    sky.material.uniforms.clock.value=time;dust.rotation.y=Math.sin(time*.025)*.05;dust.position.y=Math.sin(time*.3)*.15;arena.animated.forEach(a=>a.rotation.y+=dt*.18);
    if(state==='intro'){intro-=dt;camera.position.set(Math.sin(intro*.5)*1.5,2.1,20-intro*.4);camera.lookAt(0,1.7,-8);if(intro<=0){state='playing';camera.position.copy(pos);camera.rotation.set(pitch,yaw,0);hud();}}
    if(state==='playing'){
      const ix=input.current;let mx=ix.moveX+(ix.keys.d?1:0)-(ix.keys.a?1:0),mz=ix.moveY+(ix.keys.s?1:0)-(ix.keys.w?1:0);let mag=Math.hypot(mx,mz);if(mag>1){mx/=mag;mz/=mag;}const speed=(ix.run||ix.keys.shift?6.7:4.2)*(ix.aim?.65:1);move(pos,(Math.cos(yaw)*mx+Math.sin(yaw)*mz)*speed*dt,(-Math.sin(yaw)*mx+Math.cos(yaw)*mz)*speed*dt);
      if(ix.keys.arrowleft)yaw+=dt*1.5;if(ix.keys.arrowright)yaw-=dt*1.5;
      if(ix.fire||ix.keys[' '])shoot();
      if(reloading>0){reloading-=dt;if(reloading<=0){ammo=24;sound('reload');hud();}}
      if(nextWave>0){nextWave-=dt;if(nextWave<=0){wave++;ammo=24;if(campaign){setScene(wave-1);clearEffects();spawnWave();beginIntro();}else spawnWave();hud();}}
      camera.position.copy(pos);camera.position.y+=mag>.1?Math.sin(time*(ix.run?15:10))*.035:Math.sin(time*1.4)*.007;camera.rotation.set(pitch+recoil*.5,yaw,0);
      scene.updateMatrixWorld(true);
      for(const b of bots){if(!b.alive){if(b.fall>0){b.fall-=dt;b.group.rotation.x=-Math.min(1,1-b.fall)*1.45;b.group.position.y=-Math.min(1,1-b.fall)*.25;if(b.fall<=0)scene.remove(b.group);}continue;}
        const p=b.group.position,dist=Math.hypot(pos.x-p.x,pos.z-p.z);b.group.lookAt(pos.x,0,pos.z);
        if(dist>7){let vx=(pos.x-p.x)/dist*(b.group.userData.type===1?1.9:1.1+wave*.18)*dt,vz=(pos.z-p.z)/dist*(b.group.userData.type===1?1.9:1.1+wave*.18)*dt;const old=p.clone();if(b.avoid>0){b.avoid-=dt;move(p,-vz*(b.phase%2?1:-1)*2,vx*(b.phase%2?1:-1)*2);}else{move(p,vx,vz);if(p.distanceTo(old)<dt*.2)b.avoid=1.3;}b.legs[0].rotation.x=Math.sin(time*4.8+b.phase)*.33;b.legs[1].rotation.x=-b.legs[0].rotation.x;b.knees.forEach((k,i)=>k.rotation.x=Math.max(0,Math.sin(time*4.8+b.phase+i*Math.PI))*.32);b.chest.position.y=Math.abs(Math.sin(time*4.8+b.phase))*.035;}
        else{b.legs.forEach(l=>l.rotation.x*=.9);b.knees.forEach(k=>k.rotation.x*=.9);}
        b.head.rotation.y=Math.sin(time*.7+b.phase)*.07;b.arms[1].rotation.x=-.48;b.arms[0].rotation.x=Math.sin(time*3+b.phase)*.08;
        b.flash=Math.max(0,b.flash-dt);b.chest.rotation.z=b.flash>0?Math.sin(time*50)*.06:0;
        b.cooldown-=dt;if(b.cooldown<=0&&dist<27){b.cooldown=2.8-wave*.25+Math.random();const origin=p.clone().add(new THREE.Vector3(0,1.75,0));ray.set(origin,pos.clone().sub(origin).normalize());const ob=ray.intersectObjects(solids);if(!ob.length||ob[0].distance>dist){const bolt=new THREE.Mesh(new THREE.SphereGeometry(.075,6,6),mats.alert);bolt.position.copy(origin);scene.add(bolt);effects.push({mesh:bolt,vel:pos.clone().sub(origin).normalize().multiplyScalar(13),life:dist/13+.2,bullet:true});b.arms[1].rotation.x=-.7;}}}
    }else if(state==='menu'){camera.position.set(1,2,19);camera.rotation.set(-.02,Math.sin(time*.13)*.1,0);}
    if(state==='playing'){for(let i=effects.length-1;i>=0;i--){let e=effects[i];e.life-=dt;e.mesh.position.addScaledVector(e.vel,dt);if(!e.bullet)e.vel.y-=dt*8;else if(e.mesh.position.distanceTo(pos)<.65){hp=Math.max(0,hp-(6+wave*2));shake=.2;e.life=0;sound('damage');if(hp<=0){state='lost';hud();}}if(e.life<=0){scene.remove(e.mesh);e.mesh.geometry.dispose();if(!e.bullet)e.mesh.material.dispose();effects.splice(i,1);}}}
    recoil=Math.max(0,recoil-dt*.6);hit=Math.max(0,hit-dt);shake=Math.max(0,shake-dt);muzzle.visible=time-lastShot<.045&&state==='playing';muzzleLight.intensity=muzzle.visible?12:0;gun.visible=state==='playing'||state==='paused';flashlight.position.copy(pos);flashlight.target.position.set(pos.x-Math.sin(yaw)*10,pos.y+Math.sin(pitch)*10,pos.z-Math.cos(yaw)*10);
    const aim=input.current.aim,portrait=camera.aspect<1,scale=portrait?.5:.88;gun.scale.setScalar(scale);const smoothing=Math.min(1,dt*12);gun.position.x=THREE.MathUtils.lerp(gun.position.x,aim?0:portrait?.13:.29,smoothing);gun.position.y=THREE.MathUtils.lerp(gun.position.y,(aim?-.15:portrait?-.28:-.3)-(reloading>0?.2*Math.sin(reloading/1.5*Math.PI):0),smoothing);gun.position.z=-.6+recoil;gun.rotation.z=reloading>0?-.35:Math.sin(time*2)*.007;
    camera.fov=THREE.MathUtils.lerp(camera.fov,aim?48:70,smoothing);camera.updateProjectionMatrix();if(shake>0)camera.rotation.z=Math.sin(time*90)*shake*.1;
    if(time-lastHUD>.2){lastHUD=time;hud();}if(state!=='menu'){if(time-lastShadow>.5){renderer.shadowMap.needsUpdate=true;lastShadow=time;}if(quality==='cinematic')composer.render();else renderer.render(scene,camera);}
  }
  spawnWave();hud();frame();
  return {...api,dispose(){disposed=true;cancelAnimationFrame(raf);ro.disconnect();music.pause();music.src='';audio?.close();scene.traverse(o=>{o.geometry?.dispose();if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.dispose());});textures.forEach(t=>t.dispose());env.dispose();composer.dispose();renderer.dispose();renderer.domElement.remove();}};
}
