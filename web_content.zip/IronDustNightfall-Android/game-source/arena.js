import * as THREE from 'three';
export const SCENES=[
  {name:'DUST YARD',time:'18:42',subtitle:'Last light at Outpost 07',code:'01',description:'Patrol sentries. Open sightlines.',skyLow:0xc58966,skyHigh:0x344855,fog:0xb7aa96,sun:0xffba80,intensity:2.6,ambient:1.7,exposure:1.1},
  {name:'REACTOR DEPOT',time:'19:16',subtitle:'The grid is coming alive',code:'02',description:'Hunters. Narrow cargo lanes.',skyLow:0x845b67,skyHigh:0x263346,fog:0x626e7a,sun:0xdca8a5,intensity:1.1,ambient:1.15,exposure:1.2},
  {name:'BLACKOUT',time:'20:03',subtitle:'Hold the perimeter until extraction',code:'03',description:'Heavy units. Night engagement.',skyLow:0x283a52,skyHigh:0x0f1b2c,fog:0x273846,sun:0x94b8ea,intensity:.55,ambient:.8,exposure:1.35}
];
export function buildArena(scene,mats,index){
  const root=new THREE.Group();scene.add(root);const solids=[],obstacles=[],lights=[],animated=[];
  function mesh(geo,mat,x,y,z,solid=false){const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);m.receiveShadow=true;root.add(m);return m;}
  function box(w,h,d,mat,x,y,z,solid=false){const m=mesh(new THREE.BoxGeometry(w,h,d),mat,x,y,z);m.castShadow=solid;if(solid){solids.push(m);obstacles.push({x,z,w,d});}return m;}
  function cylinder(r,h,mat,x,y,z){return mesh(new THREE.CylinderGeometry(r,r,h,12),mat,x,y,z);}
  box(66,.2,66,mats.sand,0,-.1,0);
  [[0,-29,64,1],[0,29,64,1],[-29,0,1,58],[29,0,1,58]].forEach(([x,z,w,d])=>{box(w,6.5,d,mats.wall,x,3.25,z,true);box(w+.1,.22,d+.1,mats.dark,x,6.55,z);});
  for(let x=-24;x<=24;x+=6){box(.4,6.5,1.3,mats.wall,x,3.25,-29);box(.4,6.5,1.3,mats.wall,x,3.25,29);}
  const layouts=[
    [[-11,-8,8,4],[11,-15,8,4],[-14,9,8,4],[14,7,8,4],[0,-23,6,3]],
    [[-9,-10,6,4],[9,-10,6,4],[-9,5,6,4],[9,5,6,4],[-18,-19,7,4],[18,16,7,4]],
    [[-15,-7,7,4],[15,-7,7,4],[-12,14,7,4],[13,14,7,4],[0,-20,8,4]]
  ];
  layouts[index].forEach(([x,z,w,d],i)=>{const mat=i%3===1?mats.rust:mats.steel;box(w,3,d,mat,x,1.5,z,true);box(w+.1,.1,d+.1,mats.dark,x,3.03,z);for(let a=-w/2+.2;a<w/2;a+=.32)box(.045,2.86,.055,mats.dark,x+a,1.5,z+d/2+.025);for(const side of [-1,1]){box(.06,2.9,.05,mats.edge,x+side*w*.25,1.5,z+d/2+.06);box(.38,.08,.07,mats.gold,x+side*w*.25,1.3,z+d/2+.09);}});
  const crateLayouts=[[[-4,-4],[6,0],[-6,16],[18,-3],[-20,-18],[8,19]],[[-17,4],[17,-2],[-3,-22],[3,14]],[[-6,0],[7,-1],[-20,19],[20,-20],[-3,23]]];
  crateLayouts[index].forEach(([x,z])=>{box(2.3,1.8,2.3,mats.crate,x,.9,z,true);for(let a of [-.8,.8]){box(.07,1.85,2.35,mats.edge,x+a,.93,z);}box(2.35,.08,2.35,mats.edge,x,1.8,z);});
  [[-23,-23],[22,-23]].forEach(([x,z])=>{box(6,8,5,mats.wall,x,4,z,true);box(6.5,.3,5.5,mats.dark,x,8,z);for(let a=-1;a<=1;a++){box(1.1,1.3,.08,mats.dark,x+a*1.5,6.5,z+2.55);box(1,.03,.04,mats.lamp,x+a*1.5,6.5,z+2.62);}cylinder(.06,4,mats.edge,x,10,z);});
  // Radar tower with animated dish.
  for(const side of [-1,1]){box(.14,12,.14,mats.dark,-24+side*1.6,6,-12);box(.14,12,.14,mats.dark,-24,6,-12+side*1.6);}
  for(let h=1;h<12;h+=2)box(3.5,.1,3.5,mats.edge,-24,h,-12);
  const dish=new THREE.Group();dish.position.set(-24,13,-12);root.add(dish);
  const d=new THREE.Mesh(new THREE.SphereGeometry(1.6,16,12,0,Math.PI*2,0,Math.PI*.35),mats.edge);d.rotation.x=Math.PI/2.4;dish.add(d);animated.push(dish);
  // Floodlights and warm pools during later scenes.
  for(let x=-22;x<=22;x+=11){box(.13,7.3,.13,mats.dark,x,3.65,-26.7);box(1.4,.2,.7,mats.dark,x,7.3,-26.5);box(1.1,.06,.5,mats.lamp,x,7.17,-26.45);const light=new THREE.PointLight(0xffc881,index===0?5:23,17,1.4);light.position.set(x,6.9,-25.5);root.add(light);lights.push(light);}
  // Curbs, pipeline, oil drums, cable troughs and hazard markings.
  box(.4,.25,46,mats.wall,-25,.125,0);box(.4,.25,46,mats.wall,25,.125,0);
  const pipe=cylinder(.17,46,mats.rust,-27,3,0);pipe.rotation.x=Math.PI/2;
  for(let z=-24;z<26;z+=6){box(.15,.5,.45,mats.edge,-27,3,z);box(.12,.01,1.9,mats.gold,-1,.012,z);}
  for(const [x,z] of [[-20,10],[20,2],[-18,-3],[18,-19]]){cylinder(.38,1.2,mats.rust,x,.6,z);cylinder(.4,.08,mats.edge,x,1.16,z);cylinder(.4,.06,mats.dark,x,.1,z);}
  if(index===1){for(const x of [-18,18]){cylinder(1.3,4.2,mats.steel,x,2.1,-11);cylinder(1.36,.2,mats.edge,x,3.4,-11);box(.8,2,.8,mats.dark,x,1,-9.4);box(.65,.08,.1,mats.glow,x,1.6,-8.98);const l=new THREE.PointLight(0x45daca,14,12);l.position.set(x,2.6,-9);root.add(l);}}
  if(index===2){box(6,.25,6,mats.dark,0,.12,-11);for(let a=-2;a<=2;a++)box(.16,.02,5,mats.gold,a,.26,-11);for(const x of [-4,4]){box(.35,4,.35,mats.dark,x,2,-11);box(.5,.5,.5,mats.alert,x,4,-11);const l=new THREE.PointLight(0xff5432,20,13);l.position.set(x,3.8,-11);root.add(l);}}
  const gravel=new THREE.InstancedMesh(new THREE.DodecahedronGeometry(.07,0),mats.wall,220),dummy=new THREE.Object3D();for(let i=0;i<220;i++){dummy.position.set(Math.sin(i*94)*27,.035,Math.cos(i*47)*27);dummy.scale.setScalar(.5+(i%5)*.3);dummy.updateMatrix();gravel.setMatrixAt(i,dummy.matrix);}root.add(gravel);
  return {root,solids,obstacles,animated,dispose(){scene.remove(root);root.traverse(o=>o.geometry?.dispose());}};
}
