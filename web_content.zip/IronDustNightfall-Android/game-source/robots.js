import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';

// Original AEGIS sentries: layered chamfered armor, articulated pistons and luminous optics.
// Bake static subassemblies per material so detailed silhouettes stay lightweight on mobile.
export function buildRobot(materials,type=0) {
  const root=new THREE.Group(),chest=new THREE.Group();root.add(chest);
  const steel=materials.robot,edge=materials.edge,dark=materials.dark;
  const accent=type===2?materials.alert:type===1?materials.gold:materials.glow;
  const groups=[];
  function piece(parent,geo,mat,pos,rot=[0,0,0]){const m=new THREE.Mesh(geo,mat);m.position.set(...pos);m.rotation.set(...rot);m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
  function plate(p,w,h,d,mat,x,y,z,rot){return piece(p,new RoundedBoxGeometry(w,h,d,2,.055),mat,[x,y,z],rot);}
  function orb(p,r,mat,x,y,z){return piece(p,new THREE.SphereGeometry(r,10,8),mat,[x,y,z]);}
  function cylinder(p,r,len,mat,x,y,z,rot){return piece(p,new THREE.CylinderGeometry(r,r,len,10),mat,[x,y,z],rot);}
  function bake(p){p.updateMatrixWorld(true);const mats=new Map();
    for(const m of [...p.children])if(m.isMesh){m.updateMatrix();const g=m.geometry.clone().applyMatrix4(m.matrix);if(!mats.has(m.material))mats.set(m.material,[]);mats.get(m.material).push(g);p.remove(m);m.geometry.dispose();}
    for(const [mat,geos] of mats){const normalized=geos.map(x=>{const a=x.index?x.toNonIndexed():x.clone();x.dispose();return a;});const g=mergeGeometries(normalized,false);normalized.forEach(g=>g.dispose());if(!g)continue;const m=new THREE.Mesh(g,mat);m.castShadow=m.receiveShadow=true;p.add(m);}
  }
  plate(chest,.91,.78,.56,steel,0,1.8,0);
  plate(chest,.65,.46,.11,edge,0,1.86,.34,[.08,0,0]);
  plate(chest,.56,.2,.12,dark,0,1.73,.42);
  cylinder(chest,.1,.025,accent,0,1.91,.415,[Math.PI/2,0,0]);
  // Vent slats and exposed reinforced spine.
  for(let i=0;i<5;i++)plate(chest,.04,.21,.03,dark,-.22+i*.11,1.64,.41);
  cylinder(chest,.17,.42,dark,0,1.21,0);
  for(const side of [-1,1]){cylinder(chest,.04,.58,edge,side*.24,1.42,.03,[0,0,-side*.15]);plate(chest,.23,.34,.12,steel,side*.28,1.26,.24);}
  plate(chest,.76,.22,.44,dark,0,1.07,0);
  plate(chest,.22,.19,.15,accent,0,1.08,.28);
  plate(chest,.71,.5,.28,dark,0,1.82,-.37);for(const side of [-1,1])cylinder(chest,.1,.45,edge,side*.22,1.8,-.54);
  const head=new THREE.Group();head.position.y=2.32;chest.add(head);
  cylinder(head,.13,.23,edge,0,-.06,0);
  plate(head,.61,.36,.45,steel,0,.13,.015);
  plate(head,.63,.2,.47,edge,0,.25,-.03,[-.12,0,0]);
  plate(head,.52,.12,.035,dark,0,.15,.26);
  plate(head,.45,.065,.03,accent,0,.17,.29);
  plate(head,.23,.11,.08,dark,0,-.02,.24);
  cylinder(head,.017,.34,edge,-.28,.51,-.1);
  orb(head,.035,accent,-.28,.69,-.1);
  const legs=[],knees=[],arms=[];
  for(const side of [-1,1]){
    const leg=new THREE.Group();leg.position.set(side*.29,1,0);root.add(leg);legs.push(leg);
    orb(leg,.15,dark,0,0,0);
    cylinder(leg,.09,.4,edge,0,-.23,0);
    plate(leg,.31,.45,.35,steel,0,-.25,.04,[0,0,side*.05]);
    plate(leg,.26,.23,.08,edge,0,-.2,.24);
    const knee=new THREE.Group();knee.position.y=-.51;leg.add(knee);knees.push(knee);
    cylinder(knee,.14,.35,dark,0,0,0,[0,0,Math.PI/2]);
    plate(knee,.27,.19,.12,edge,0,0,.19);
    cylinder(knee,.065,.38,edge,0,-.23,-.04);
    plate(knee,.29,.35,.3,steel,0,-.25,.035,[-.1,0,0]);
    plate(knee,.06,.19,.035,accent,side*.08,-.23,.2);
    plate(knee,.36,.15,.56,dark,0,-.42,.1);
    plate(knee,.34,.07,.37,edge,0,-.39,.21);
    const arm=new THREE.Group();arm.position.set(side*.64,2.03,0);chest.add(arm);arms.push(arm);
    orb(arm,.19,dark,0,0,0);plate(arm,.44,.26,.51,steel,side*.015,.08,.015,[0,0,side*.1]);
    plate(arm,.21,.035,.25,accent,side*.05,.23,.03);
    cylinder(arm,.1,.37,edge,0,-.28,0);plate(arm,.26,.31,.28,steel,0,-.27,.06);
    orb(arm,.13,dark,0,-.48,.01);
    plate(arm,.32,.37,.38,steel,0,-.67,.05,[-.12,0,0]);
    cylinder(arm,.09,.25,dark,0,-.88,.13);
    plate(arm,.24,.2,.26,dark,0,-.91,.17);
    if(side===1){plate(arm,.24,.24,.6,dark,0,-.6,.36);plate(arm,.15,.12,.42,edge,0,-.54,.42);cylinder(arm,.07,.46,dark,0,-.6,.79,[Math.PI/2,0,0]);cylinder(arm,.085,.04,accent,0,-.6,1.02,[Math.PI/2,0,0]);}
    else for(let i=0;i<3;i++)plate(arm,.045,.15,.04,edge,-.07+i*.07,-.96,.32);
    bake(arm);bake(knee);bake(leg);
  }
  bake(head);bake(chest);
  root.scale.setScalar(type===2?1.14:type===1?.94:1);
  root.userData.type=type;
  return {group:root,legs,knees,arms,chest,head};
}
