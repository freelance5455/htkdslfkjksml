import * as THREE from 'three';
import sand from './assets/sand.jpg';
import concrete from './assets/concrete.jpg';
import metal from './assets/metal.jpg';
import rust from './assets/rust.jpg';
import sandBump from './assets/sand-bump.jpg';
import concreteBump from './assets/concrete-bump.jpg';
import metalBump from './assets/metal-bump.jpg';
import rustBump from './assets/rust-bump.jpg';

export function createMaterials(renderer){
  const loader=new THREE.TextureLoader(),textures=[];
  function texture(url,repeat=1,color=false){const t=loader.load(url);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(repeat,repeat);t.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());if(color)t.colorSpace=THREE.SRGBColorSpace;textures.push(t);return t;}
  function surface(diffuse,bump,repeat,color,roughness,metalness=0,bumpScale=.05){return new THREE.MeshStandardMaterial({map:texture(diffuse,repeat,true),bumpMap:texture(bump,repeat),bumpScale,color,roughness,metalness});}
  const mats={
    sand:surface(sand,sandBump,22,0xe5c99c,.97,0,.08),
    wall:surface(concrete,concreteBump,3,0xb7b9b0,.88,0,.07),
    steel:surface(metal,metalBump,2,0x6896ab,.6,.45,.025),
    rust:surface(rust,rustBump,2,0xc89873,.72,.32,.035),
    crate:surface(metal,metalBump,1,0x6e7562,.84,.25,.03),
    robot:surface(metal,metalBump,1,0x6b8795,.42,.7,.013),
    dark:surface(metal,metalBump,1,0x293238,.52,.65,.012),
    metal:new THREE.MeshStandardMaterial({color:0x9caeaf,metalness:.8,roughness:.3}),
    edge:new THREE.MeshStandardMaterial({color:0x889da5,metalness:.8,roughness:.3}),
    glow:new THREE.MeshStandardMaterial({color:0x84f1ec,emissive:0x65fff5,emissiveIntensity:3,roughness:.3}),
    alert:new THREE.MeshStandardMaterial({color:0xff7650,emissive:0xff4115,emissiveIntensity:2.2,roughness:.3}),
    gold:new THREE.MeshStandardMaterial({color:0xd5ae68,metalness:.55,roughness:.4}),
    lamp:new THREE.MeshStandardMaterial({color:0xffdb9c,emissive:0xffc670,emissiveIntensity:4}),
    rubber:new THREE.MeshStandardMaterial({color:0x202628,roughness:.98}),
  };
  return {mats,textures};
}
