# Iron Dust: Nightfall | Android project

This is an Android Studio source project, not a compiled APK. The version 2 game is
bundled inside a hardware-accelerated Android WebView with landscape orientation,
immersive fullscreen, a launcher icon and local textures/music.

## Build an installable APK

1. Extract this ZIP and open the **IronDustNightfall-Android** folder in a current
   Android Studio version that supports Android Gradle Plugin 8.7.3 or newer.
2. Use **JDK 17**, **Android SDK Platform 35**, and **Gradle 8.9**.
   The Gradle wrapper binaries could not be bundled in the packaging environment.
   In **Settings > Build, Execution, Deployment > Build Tools > Gradle**, select a
   local Gradle 8.9 installation (download it from https://gradle.org/releases/).
   Let Android Studio sync the project. This first build needs internet access on
   your development computer to obtain build dependencies.
3. Connect an Android phone with USB debugging enabled, then click **Run** to
   install a development build. Or use **Build > Build App Bundle(s) / APK(s) >
   Build APK(s)** (some versions call this **Generate APKs**).
4. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`. Transfer it
   to your phone and allow installation from that trusted source.

With Gradle 8.9 installed and your Android SDK configured, command-line builds:

```sh
gradle assembleDebug
```

To generate a wrapper for later use:

```sh
gradle wrapper --gradle-version 8.9
```

For a distributable production build, use Android Studio's **Generate Signed
Bundle / APK** and create your own signing key. Keep that key safe: future
updates need the same key. This ZIP intentionally contains no signing key.

## Requirements and controls

- Android 8.0 (API 26) or newer, OpenGL ES 3 capable GPU.
- Updated Android System WebView/Chrome; Android 8 itself is the native minimum,
  not a guarantee that its original WebView supports this modern game.
- Left joystick: movement; swipe arena: look; hold Fire: shoot.
- Aim, Sprint and Reload buttons; music and effects have separate toggles.
- Balanced visuals are the default. Cinematic adds bloom and costs more GPU time.
- Campaign: Dust Yard, Reactor Depot, Blackout. Individual sectors are selectable.
- System Back pauses combat and shows an exit prompt.
- Backgrounding pauses combat/music; tap to resume audio when you return.
- Leaving/restarting the app starts a new mission; there is no save-game system.

## Local runtime

All required game assets are included. There is **no INTERNET permission** and
no remote runtime resource dependency. Web requests to the virtual
`https://appassets.androidplatform.net/game/` origin are served from APK assets
by the native WebViewClient. Other web hosts are blocked. No sensitive-device
permissions, analytics or JavaScript-to-native bridge are included.

Google Fonts were replaced with local Android system-font fallbacks, so the
typography differs slightly from the ClickUp preview. The original game design,
textures, menu artwork, robots and soundtrack remain bundled.

## Source and edits

The executable game is `app/src/main/assets/game/index.html`.
Editable React/Three.js source is included in `game-source/` for reference.
It is not an independent npm project and no JavaScript build toolchain is
included; the Android app uses the prebuilt game. Changing Android settings or
resources requires only an Android rebuild. React changes require re-exporting
the compiled game.

The source package uses application ID `com.irondust.nightfall`. Change it before
publishing if needed. Play Store submission also requires your own store listing,
content-rating questionnaire, signing and compatibility/device tests.

## Validation and limitations

- Bundled HTML and local asset references were checked during packaging.
- The game was browser-tested before packaging, including combat and sector selection.
- Android compilation, signing, installation and device performance have **not**
  been verified: the packaging environment has no Android SDK or Gradle and no
  internet access to install them.
- This is a WebView-based Android app, not a native Unity/Unreal port.

See `THIRD-PARTY-NOTICES.txt` for bundled library notices.
