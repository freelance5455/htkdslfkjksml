// Android-only compatibility: local host storage, lifecycle audio, native fullscreen.
(() => {
  window.clickup = window.clickup || {};
  window.clickup.storage = {
    get: async (key) => localStorage.getItem("irondust:" + key),
    set: async (key, value) => localStorage.setItem("irondust:" + key, value),
  };
  const NativeAudio = window.Audio;
  const tracks = new Set();
  window.Audio = function (...args) {
    const audio = new NativeAudio(...args);
    tracks.add(audio);
    return audio;
  };
  window.Audio.prototype = NativeAudio.prototype;
  const pausedTracks = new Set();
  window.IronDustAndroid = {
    pause() {
      const game = document.querySelector(".game");
      if (game && game.classList.contains("playing")) {
        window.dispatchEvent(new KeyboardEvent("keydown", {key: "Escape"}));
        window.dispatchEvent(new KeyboardEvent("keyup", {key: "Escape"}));
      }
      for (const audio of tracks) {
        if (!audio.paused) { pausedTracks.add(audio); audio.pause(); }
      }
      document.querySelectorAll("audio,video").forEach(media => media.pause());
    }
  };
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) window.IronDustAndroid.pause();
  });
  document.addEventListener("pointerdown", () => {
    for (const audio of pausedTracks) {
      const musicButton = document.querySelector('[aria-label="Toggle music"]');
      if (!musicButton || musicButton.getAttribute("aria-pressed") !== "false") {
        audio.play().catch(() => {});
      }
    }
    pausedTracks.clear();
  }, {passive: true});
  // Android Activity is already immersive; prevent a redundant WebView fullscreen overlay.
  document.addEventListener("click", (event) => {
    if (event.target.closest('[aria-label="Fullscreen"]')) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);
})();
