package com.irondust.nightfall;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collections;

/**
 * Native Android container for the bundled Three.js game.
 * HTTPS requests to the virtual game host are served only from APK assets.
 * No network permissions, remote scripts, JavaScript bridge, or file access.
 */
public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/game/index.html";
    private WebView webView;
    private FrameLayout frame;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(24, 40, 46));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(24, 40, 46));
        frame.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new LocalGameClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullscreenView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                fullscreenView = view;
                fullscreenCallback = callback;
                webView.setVisibility(View.GONE);
                frame.addView(view, new FrameLayout.LayoutParams(-1, -1));
                hideSystemBars();
            }
            @Override public void onHideCustomView() { closeCustomView(); }
        });
        hideSystemBars();
        webView.loadUrl(START);
    }

    private static WebResourceResponse deny() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden",
                Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }
    private static String mime(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".ogg")) return "audio/ogg";
        if (path.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }
    private final class LocalGameClient extends WebViewClient {
        @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            return !("https".equals(uri.getScheme()) && HOST.equals(uri.getHost())
                    && "/game/index.html".equals(uri.getPath()));
        }
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            String path = uri.getPath();
            if (!"GET".equals(request.getMethod()) || !"https".equals(uri.getScheme())
                    || !HOST.equals(uri.getHost()) || path == null
                    || !path.startsWith("/game/") || path.contains("..")
                    || path.contains("\\") || path.indexOf('\0') >= 0) return deny();
            try {
                return new WebResourceResponse(mime(path), path.endsWith(".html") ? "UTF-8" : null,
                        200, "OK", Collections.singletonMap("Cache-Control", "no-store"),
                        getAssets().open(path.substring(1)));
            } catch (IOException e) {
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                        Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
            }
        }
        @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) {
                runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Could not load the game")
                        .setMessage("Update Android System WebView or Chrome, then reopen Iron Dust.")
                        .setPositiveButton("Retry", (dialog, which) -> webView.loadUrl(START))
                        .setNegativeButton("Close", (dialog, which) -> finish()).show());
            }
        }
    }
    private void hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
    }
    private void closeCustomView() {
        if (fullscreenView == null) return;
        frame.removeView(fullscreenView);
        fullscreenView = null;
        webView.setVisibility(View.VISIBLE);
        if (fullscreenCallback != null) fullscreenCallback.onCustomViewHidden();
        fullscreenCallback = null;
        hideSystemBars();
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }
    @Override protected void onPause() {
        if (webView != null) {
            webView.evaluateJavascript("window.IronDustAndroid && window.IronDustAndroid.pause()", null);
            webView.onPause();
        }
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        hideSystemBars();
    }
    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        if (fullscreenView != null) { closeCustomView(); return; }
        webView.evaluateJavascript("window.IronDustAndroid && window.IronDustAndroid.pause()", null);
        new AlertDialog.Builder(this)
                .setTitle("Leave the outpost?")
                .setMessage("Exit Iron Dust: Nightfall?")
                .setPositiveButton("Exit", (dialog, which) -> finish())
                .setNegativeButton("Stay", (dialog, which) -> hideSystemBars())
                .show();
    }
    @Override protected void onDestroy() {
        if (webView != null) {
            frame.removeAllViews();
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
