# Anonymoux Studios 2.6.1

## Visual identity
- Updated the application and onboarding UI to charcoal `#111318`, white `#FFFFFF`, and neon green `#A3FF12`.
- Kept purple `#8B5CF6`, teal `#00D6C9`, and blue `#3897FF` as secondary accent tokens.
- Added subtle dark grain and restrained ambient green lighting.
- Applied Space Grotesk headings and Inter interface typography.
- Updated admin and realtime navigation accent colors and page metadata.

## Database
- Confirmed PDO SQLite remains the sole database driver.
- The private database remains `storage/workspace.sqlite`; no MySQL switch or DSN setting is exposed.
- Added a source-level regression test for PDO SQLite configuration.

## Verification limitations
- PHP and JavaScript syntax checks and source/regression tests are run locally.
- The build container does not have the PHP PDO SQLite extension, so live PDO database execution and InfinityFree hosting behavior remain NOT TESTED here.


## 2.6.2 — Theme and workspace pricing
- Unified dashboard/admin/workspace theme tokens and normalized legacy red accents to the charcoal, white and neon-green identity.
- Added editable default pricing for Image, Video, Realtime, Lip Sync, Voice and AI Agent workspaces.
- Preserved server-side billing safeguards; Realtime pricing is configuration/display only until provider session metering is implemented.
