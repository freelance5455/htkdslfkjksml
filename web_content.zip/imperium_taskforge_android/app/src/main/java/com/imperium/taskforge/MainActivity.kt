package com.imperium.taskforge

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import java.io.OutputStreamWriter

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingExport: String? = null
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    companion object {
        private const val EXPORT_REQUEST = 4101
        private const val IMPORT_REQUEST = 4102
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 9, 12)
        window.navigationBarColor = Color.rgb(7, 9, 12)
        window.decorView.systemUiVisibility = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.navigationBarDividerColor = Color.rgb(55, 43, 27)
        }
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(7, 9, 12))
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            settings.javaScriptEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString() ?: return true
                    // Keep all navigation inside the packaged, offline app.
                    return !url.startsWith("file:///android_asset/")
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                    this@MainActivity.fileChooserCallback = filePathCallback
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain"))
                    }
                    return try {
                        startActivityForResult(intent, IMPORT_REQUEST)
                        true
                    } catch (_: Exception) {
                        this@MainActivity.fileChooserCallback = null
                        false
                    }
                }
            }
            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun vibrate(milliseconds: Int) {
            if (milliseconds <= 0) return
            runOnUiThread {
                try {
                    @Suppress("DEPRECATION")
                    val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator
                    if (vibrator?.hasVibrator() == true) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            vibrator.vibrate(VibrationEffect.createOneShot(milliseconds.coerceAtMost(250).toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            @Suppress("DEPRECATION")
                            vibrator.vibrate(milliseconds.coerceAtMost(250).toLong())
                        }
                    }
                } catch (_: Exception) { }
            }
        }

        @JavascriptInterface
        fun exportJson(payload: String) {
            if (payload.length > 2_000_000) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Record is too large to export.", Toast.LENGTH_LONG).show() }
                return
            }
            runOnUiThread {
                pendingExport = payload
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "taskforge-personnel-record.json")
                }
                try {
                    startActivityForResult(intent, EXPORT_REQUEST)
                } catch (_: Exception) {
                    pendingExport = null
                    Toast.makeText(this@MainActivity, "No file provider is available to save the record.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Android document picker result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            EXPORT_REQUEST -> {
                val payload = pendingExport
                pendingExport = null
                if (resultCode == RESULT_OK && data?.data != null && payload != null) {
                    try {
                        contentResolver.openOutputStream(data.data!!)?.use { stream ->
                            OutputStreamWriter(stream, Charsets.UTF_8).use { it.write(payload) }
                        }
                        Toast.makeText(this, "Personnel record exported.", Toast.LENGTH_SHORT).show()
                    } catch (_: Exception) {
                        Toast.makeText(this, "Unable to save the personnel record.", Toast.LENGTH_LONG).show()
                    }
                }
            }
            IMPORT_REQUEST -> {
                val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
                fileChooserCallback?.onReceiveValue(result)
                fileChooserCallback = null
            }
        }
    }

    @Deprecated("Android back button compatibility")
    override fun onBackPressed() {
        if (!::webView.isInitialized) {
            super.onBackPressed()
            return
        }
        webView.evaluateJavascript("window.handleSystemBack ? window.handleSystemBack() : false") { handled ->
            if (handled != "true") finish()
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidBridge")
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
