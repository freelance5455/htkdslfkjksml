(() => {
  'use strict';
  const STORE_KEY = 'taskforge40k.campaign.v1';
  const DAILY_QUOTES = [
    'Small deeds forge great legions.',
    'Discipline is a weapon. Wield it.',
    'The next victory begins with the next order.',
    'Strength is built in the moments no one sees.',
    'The Imperium is vast. Your next action is simple.',
    'A vow fulfilled is a victory secured.'
  ];
  const WISDOM_QUOTES = [
    'Doubt may visit. It does not command. The next action is yours.',
    'A fortress is raised stone by stone. A stronger self is raised task by task.',
    'Do not wait for inspiration. Muster discipline, and begin.',
    'The most important order is often the one you give yourself.',
    'A victory, however small, is proof that your will can move the world.',
    'In the grim darkness of an unfinished to-do list, there is still progress.'
  ];
  const CATEGORIES = ['Personal', 'Training', 'Study', 'Work', 'Health', 'Other'];
  const CATEGORY_SYMBOL = {Personal:'♙', Training:'⚔', Study:'▤', Work:'⌘', Health:'✚', Other:'◈'};
  const DIFFICULTY_DATA = {
    Routine: {points:15, label:'Routine'}, Standard:{points:30,label:'Standard'}, Hard:{points:60,label:'Hard'},
    Heroic:{points:100,label:'Heroic'}, Legendary:{points:200,label:'Legendary'}
  };
  const RANKS = [
    {min:1,max:2,name:'Imperial Citizen',short:'UNTESTED • MORTAL',symbol:'♙',desc:'The journey begins. Every legend starts with a decision.',motto:'Every crusade begins with a single step.'},
    {min:3,max:5,name:'Recruit',short:'INDUCTEE • PROBATIONARY',symbol:'⚑',desc:'You have answered the call and begun your training.',motto:'Prove that your word has weight.'},
    {min:6,max:9,name:'Guardsman',short:'ASTRA MILITARUM • LINE TROOPER',symbol:'⚔',desc:'Reliability is your armour. Duty is your oath.',motto:'Hold the line. Honour the oath.'},
    {min:10,max:13,name:'Veteran Guardsman',short:'DECORATED • BATTLE-PROVEN',symbol:'✦',desc:'Consistency under pressure separates the steady from the rest.',motto:'You have held when others faltered.'},
    {min:14,max:17,name:'Astartes Neophyte',short:'ADEPTUS ASTARTES • INDUCTION',symbol:'⛨',desc:'The trials grow harder. Your will is being reforged.',motto:'Become more than you were yesterday.'},
    {min:18,max:21,name:'Space Marine',short:'ADEPTUS ASTARTES • BATTLE-BROTHER',symbol:'⚔',desc:'You are no longer merely surviving. You are becoming formidable.',motto:'Your discipline is your second skin.'},
    {min:22,max:25,name:'Battle-Brother',short:'ASTARTES • PROVEN WARRIOR',symbol:'✠',desc:'Every completed order strengthens the warrior you are building.',motto:'Victory is a habit, not an accident.'},
    {min:26,max:30,name:'Sergeant',short:'SQUAD LEADER • NON-COMMISSIONED',symbol:'♜',desc:'You lead by example, and your standards shape the squad.',motto:'Your example is your first command.'},
    {min:31,max:35,name:'Lieutenant',short:'JUNIOR OFFICER • TRUSTED',symbol:'⚜',desc:'You have earned responsibility for a greater mission.',motto:'Think clearly. Act decisively.'},
    {min:36,max:40,name:'Captain',short:'COMPANY COMMAND • SENIOR OFFICER',symbol:'♛',desc:'Plans become action under your command.',motto:'A commander is measured by what gets done.'},
    {min:41,max:45,name:'Company Champion',short:'ELITE WARRIOR • EXEMPLAR',symbol:'✹',desc:'Your discipline now sets the pace for others.',motto:'Make excellence your ordinary standard.'},
    {min:46,max:50,name:'Chapter Champion',short:'HONOURED • PROVEN IN TRIAL',symbol:'⚔',desc:'You carry a reputation forged through repeated action.',motto:'Let action speak where words fall short.'},
    {min:51,max:59,name:'Chapter Master',short:'CHAPTER COMMAND • LEGENDARY',symbol:'♜',desc:'You direct a campaign rather than merely survive a day.',motto:'Build systems that make victory repeatable.'},
    {min:60,max:66,name:'Lord Commander',short:'HIGH COMMAND • IMPERIAL STRATEGIST',symbol:'♛',desc:'Vision and discipline combine into sustained achievement.',motto:'Command the day before the day commands you.'},
    {min:67,max:79,name:'Hero of the Imperium',short:'LIVING LEGEND • ASCENDANT',symbol:'✹',desc:'Your progress is the sum of hundreds of kept promises.',motto:'The extraordinary is built from the ordinary.'},
    {min:80,max:9999,name:'Primarch',short:'SON OF THE EMPEROR • SOVEREIGN EXEMPLAR',symbol:'☼',desc:'The ultimate symbol of self-mastery and purpose.',motto:'You have become the standard you once pursued.'}
  ];  const $ = (selector, root=document) => root.querySelector(selector);
  const $$ = (selector, root=document) => Array.from(root.querySelectorAll(selector));
  const todayKey = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const yesterdayKey = () => { const d=new Date(); d.setDate(d.getDate()-1); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const makeId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,9)}`;
  const safeNum = (n, fallback=0) => Number.isFinite(Number(n)) ? Number(n) : fallback;
  const initialState = () => ({
    version:1,
    xpTotal:0,
    tasks:[
      {id:makeId(),title:'Plan the next day',points:30,difficulty:'Standard',category:'Personal',notes:'Choose the three things that matter most.',createdAt:Date.now(),completed:false,completedAt:null},
      {id:makeId(),title:'Finish one priority task',points:60,difficulty:'Hard',category:'Work',notes:'Protect a focused block of time.',createdAt:Date.now(),completed:false,completedAt:null},
      {id:makeId(),title:'Move with purpose for 20 minutes',points:60,difficulty:'Hard',category:'Training',notes:'Any honest effort counts.',createdAt:Date.now(),completed:false,completedAt:null}
    ],
    streak:0,bestStreak:0,lastCompletionDate:null,completionDays:[],
    settings:{sound:true,embers:true,haptics:true},
    createdCount:3,firstLaunch:true
  });
  const normalizeState = (x) => {
    const fallback=initialState();
    if (!x || typeof x!=='object') return fallback;
    const settings=Object.assign({sound:true,embers:true,haptics:true}, x.settings||{});
    const tasks=Array.isArray(x.tasks) ? x.tasks.filter(t=>t&&typeof t.title==='string').map(t=>({
      id:String(t.id||makeId()), title:String(t.title).slice(0,90), points:Math.min(5000,Math.max(0,safeNum(t.points,30))),
      difficulty:String(t.difficulty||'Standard'),category:CATEGORIES.includes(t.category)?t.category:'Other',notes:String(t.notes||'').slice(0,240),
      createdAt:safeNum(t.createdAt,Date.now()),completed:!!t.completed,completedAt:t.completedAt||null
    })) : fallback.tasks;
    const days=Array.isArray(x.completionDays)?x.completionDays.filter(d=>/^\d{4}-\d\d-\d\d$/.test(d)):[];
    return {version:1,xpTotal:Math.max(0,safeNum(x.xpTotal,0)),tasks,streak:Math.max(0,safeNum(x.streak,0)),bestStreak:Math.max(0,safeNum(x.bestStreak,0)),lastCompletionDate:x.lastCompletionDate||null,completionDays:[...new Set(days)],settings,createdCount:Math.max(tasks.length,safeNum(x.createdCount,tasks.length)),firstLaunch:!!x.firstLaunch};
  };
  let state;
  try { state=normalizeState(JSON.parse(localStorage.getItem(STORE_KEY)||'null')); }
  catch(e) { state=initialState(); }
  let currentView='command';
  let currentFilter='active';
  let selectedPoints=30, selectedDifficulty='Standard', selectedCategory='Personal', editingTaskId=null;
  let toastTimer=null, audioContext=null;
  const progressFor = (xpTotal) => {
    let level=1, remaining=Math.max(0,safeNum(xpTotal,0)), guard=0;
    const need=(lv)=>Math.floor(100+lv*35);
    while (remaining>=need(level) && guard<1000) { remaining-=need(level); level++; guard++; }
    return {level,within:remaining,need:need(level),percent:Math.max(0,Math.min(100,remaining/need(level)*100))};
  };
  const rankForLevel = (level) => RANKS.find(r=>level>=r.min&&level<=r.max)||RANKS[RANKS.length-1];
  const currentProgress=()=>progressFor(state.xpTotal);
  const currentRank=()=>rankForLevel(currentProgress().level);
  const completedTasks=()=>state.tasks.filter(t=>t.completed);
  const activeTasks=()=>state.tasks.filter(t=>!t.completed);
  const todayCompleted=()=>state.tasks.filter(t=>t.completed && t.completedAt && dateFrom(t.completedAt)===todayKey()).length;
  const dateFrom=(stamp)=>{const d=new Date(stamp);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
  const formatNum=(n)=>Math.floor(safeNum(n)).toLocaleString('en-US');
  const escapeHtml=(str)=>String(str).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const save=()=>{try{localStorage.setItem(STORE_KEY,JSON.stringify(state));}catch(e){showToast('Local storage is full. Export your personnel record.');}};
  const randomFrom=(arr)=>arr[Math.floor(Math.random()*arr.length)];
  const categorySymbol=(cat)=>CATEGORY_SYMBOL[cat]||CATEGORY_SYMBOL.Other;
  const taskCard=(task)=>{
    const notes=task.notes?`<div class="order-notes">${escapeHtml(task.notes)}</div>`:'';
    const completed=task.completed?' completed':'';
    const status=task.completed?'✓':'○';
    const when=task.completed && task.completedAt?`FULFILLED ${escapeHtml(new Date(task.completedAt).toLocaleDateString(undefined,{month:'short',day:'numeric'}).toUpperCase())}`:'PENDING EXECUTION';
    const editButton=task.completed?'':`<button class="order-edit" data-action="edit" data-id="${escapeHtml(task.id)}" aria-label="Edit ${escapeHtml(task.title)}" title="Edit order">✎</button>`;
    const deleteButton=task.completed?'':`<button class="order-delete" data-action="delete" data-id="${escapeHtml(task.id)}" aria-label="Delete ${escapeHtml(task.title)}" title="Delete order">✕</button>`;
    return `<article class="order-card${completed}" data-id="${escapeHtml(task.id)}" data-category="${escapeHtml(task.category)}" data-difficulty="${escapeHtml(task.difficulty)}">
      <div class="order-symbol" aria-hidden="true">${categorySymbol(task.category)}</div>
      <div class="order-copy"><div class="order-title">${escapeHtml(task.title)}</div><div class="order-meta"><span class="category-pill">${escapeHtml(task.category.toUpperCase())}</span><span class="difficulty-pill">${escapeHtml(task.difficulty.toUpperCase())}</span><span>${when}</span></div>${notes}</div>
      <div class="order-reward"><span class="order-xp">+${formatNum(task.points)} XP</span><button class="complete-button" data-action="${task.completed?'already-complete':'complete'}" data-id="${escapeHtml(task.id)}" ${task.completed?'aria-label="Completed order" title="Order fulfilled"':'aria-label="Complete order" title="Complete order"'}>${status}</button></div><div class="order-actions">${editButton}${deleteButton}</div>
    </article>`;
  };
  const emptyState=(kind='active')=>{
    const completed=kind==='completed';
    return `<div class="empty-state"><div class="empty-symbol">${completed?'✦':'✠'}</div><h3>${completed?'No fulfilled orders yet':'The slate is clear'}</h3><p>${completed?'Complete an order and your victories will be recorded here.':'Your next campaign begins with a single order. Define something meaningful and claim your first requisition.'}</p>${completed?'':'<button class="primary-button" data-action="add-from-empty" style="margin:auto;min-width:180px;justify-content:center">ISSUE FIRST ORDER ＋</button>'}</div>`;
  };
  const updateSettingsUI=()=>{
    $('#soundGlyph').textContent=state.settings.sound?'♫':'♪̸';
    $('#soundBtn').style.opacity=state.settings.sound?'1':'.55';
    $('#soundSetting').classList.toggle('on',state.settings.sound);$('#soundSetting').setAttribute('aria-checked',String(state.settings.sound));
    $('#emberSetting').classList.toggle('on',state.settings.embers);$('#emberSetting').setAttribute('aria-checked',String(state.settings.embers));
    $('#hapticSetting').classList.toggle('on',state.settings.haptics);$('#hapticSetting').setAttribute('aria-checked',String(state.settings.haptics));
    $('#embers').style.opacity=state.settings.embers?'.42':'0';
  };
  const renderCommand=()=>{
    const p=currentProgress(),r=currentRank(),done=completedTasks().length,active=activeTasks().length;
    $('#rankSeal').textContent=r.symbol;$('#rankShort').textContent=r.short;$('#rankName').textContent=r.name;
    $('#levelNumber').textContent=String(p.level).padStart(2,'0');$('#heroXp').textContent=`${formatNum(p.within)} / ${formatNum(p.need)} REQUISITION`;
    $('#heroXpFill').style.width=`${p.percent}%`;$('#totalXp').textContent=formatNum(state.xpTotal);$('#heroQuote').textContent=`“${r.motto}”`;
    $('#activeCount').textContent=active;$('#completedCount').textContent=done;$('#streakCount').textContent=state.streak;
    const today=state.tasks.filter(t=>!t.completed || (t.completedAt && dateFrom(t.completedAt)===todayKey())).length;
    const todayDone=todayCompleted();$('#todayDone').textContent=todayDone;$('#todayTotal').textContent=today;
    const pct=today>0?Math.round(todayDone/today*100):0;$('#todayFill').style.width=`${pct}%`;$('#dailyPercent').textContent=`${pct}%`;
    $('#dailyMessage').textContent=today===0?'Issue an order today to set your directive.':pct===100?'Directive fulfilled. You kept the line.':`${today-todayDone} order${today-todayDone===1?'':'s'} still await execution.`;
    $('#commandOrders').innerHTML=active?activeTasks().slice(0,4).map(taskCard).join('')+ (active>4?`<div class="list-overflow-note">+ ${active-4} MORE ORDERS IN THE MISSION LOG</div>`:''):emptyState('active');
    $('#wisdomQuote').textContent=randomFrom(WISDOM_QUOTES);
    $('#navActiveDot').textContent=active>0?' ':'';
    $('#filterActiveCount').textContent=active;$('#filterCompletedCount').textContent=done;
    $('#filterActiveCount').style.display='inline';$('#filterCompletedCount').style.display='inline';
  };
  const renderOrders=()=>{
    const query=$('#searchOrders').value.trim().toLowerCase();
    let list=state.tasks.slice().sort((a,b)=>(a.completed===b.completed?b.createdAt-a.createdAt:(a.completed?1:-1)));
    if(currentFilter==='active')list=list.filter(t=>!t.completed);if(currentFilter==='completed')list=list.filter(t=>t.completed);
    if(query)list=list.filter(t=>(t.title+' '+t.category+' '+t.difficulty+' '+t.notes).toLowerCase().includes(query));
    $('#allOrders').innerHTML=list.length?list.map(taskCard).join(''):emptyState(currentFilter==='completed'?'completed':'active');
    $$('.filter-chip').forEach(b=>b.classList.toggle('selected',b.dataset.filter===currentFilter));
  };
  const renderAscension=()=>{
    const p=currentProgress(),r=currentRank();$('#ascensionSeal').textContent=r.symbol;$('#ascensionRank').textContent=r.name;$('#ascensionRange').textContent=`Level ${r.min}${r.max>=9999?'+':`–${r.max}`} · ${r.desc}`;$('#ascensionLevel').textContent=String(p.level).padStart(2,'0');
    $('#rankLadder').innerHTML=RANKS.map(rank=>{
      const achieved=p.level>rank.max,current=rank===r,locked=!achieved&&!current;
      const stateText=current?'CURRENT DESIGNATION':achieved?'HONOURS EARNED':'CLASSIFIED / LOCKED';
      return `<div class="rank-row ${current?'current':''} ${achieved?'achieved':''} ${locked?'locked':''}"><div class="ladder-seal">${rank.symbol}</div><div class="ladder-info"><h3>${escapeHtml(rank.name)}</h3><p>${escapeHtml(rank.desc)}</p><span class="rank-state">${stateText}</span></div><div class="ladder-range">${rank.max>=9999?`LVL ${rank.min}+`:`LVL ${rank.min}–${rank.max}`}</div></div>`;
    }).join('');
    const primarchPct=Math.max(0,Math.min(100,(p.level-1)/(80-1)*100));$('#primarchProgressFill').style.width=`${primarchPct}%`;$('#primarchProgressText').textContent=`LEVEL ${Math.min(80,p.level)} OF 80`;
  };
  const renderChronicle=()=>{
    const p=currentProgress(),r=currentRank(),done=completedTasks();$('#profileRank').textContent=r.name;$('#profileLevel').textContent=String(p.level).padStart(2,'0');$('#profileTitle').textContent=r.short.split('•')[0].trim();$('#profileXpFill').style.width=`${p.percent}%`;$('#profileXpCaption').textContent=`${formatNum(p.within)} / ${formatNum(p.need)} XP TO NEXT LEVEL`;
    $('#chronTotalXp').textContent=formatNum(state.xpTotal);$('#chronCompleted').textContent=formatNum(done.length);$('#chronStreak').innerHTML=`${formatNum(state.bestStreak||state.streak)} <i>days</i>`;$('#chronCreated').textContent=formatNum(state.createdCount||state.tasks.length);
    const counts={};CATEGORIES.forEach(c=>counts[c]=state.tasks.filter(t=>t.category===c).length);const max=Math.max(1,...Object.values(counts));
    $('#categoryStats').innerHTML=CATEGORIES.map(c=>`<div class="category-stat-row"><span>${escapeHtml(c)}</span><div class="category-stat-bar"><div style="width:${counts[c]/max*100}%"></div></div><strong>${counts[c]}</strong></div>`).join('');
    const achievements=[
      {icon:'✦',name:'FIRST BLOOD',desc:'Complete an order',earned:done.length>=1},
      {icon:'⚔',name:'TENACITY',desc:'Complete 10 orders',earned:done.length>=10},
      {icon:'♜',name:'CENTURION',desc:'Complete 100 orders',earned:done.length>=100},
      {icon:'☼',name:'ASCENDANT',desc:'Reach level 10',earned:p.level>=10},
      {icon:'✹',name:'UNBROKEN',desc:'Build a 7-day streak',earned:state.bestStreak>=7},
      {icon:'♛',name:'DEMIGOD',desc:'Reach Primarch rank',earned:p.level>=80}
    ];
    $('#achievements').innerHTML=achievements.map(a=>`<div class="achievement ${a.earned?'':'locked'}"><div class="achievement-icon">${a.icon}</div><b>${a.name}</b><small>${a.desc}</small></div>`).join('');
  };
  const renderAll=()=>{renderCommand();renderOrders();renderAscension();renderChronicle();updateSettingsUI();};
  const goTo=(view)=>{
    if(!['command','orders','ascension','chronicle'].includes(view))return;
    currentView=view;$$('.view').forEach(v=>v.classList.toggle('active',v.dataset.view===view));$$('.nav-item').forEach(b=>b.classList.toggle('selected',b.dataset.go===view));
    window.scrollTo({top:0,behavior:'smooth'});if(view==='orders')renderOrders();
  };
  const openModal=(id)=>{const el=$(id);if(!el)return;el.classList.add('open');el.setAttribute('aria-hidden','false');document.body.classList.add('modal-open');setTimeout(()=>{if(id==='#modalBackdrop')$('#taskTitle').focus();},120);};
  const closeModal=(id)=>{const el=$(id);if(!el)return;el.classList.remove('open');el.setAttribute('aria-hidden','true');if(!$('.modal-backdrop.open'))document.body.classList.remove('modal-open');};
  const syncTaskChoices=()=>{ $$('.difficulty-option').forEach(b=>b.classList.toggle('selected',b.dataset.difficulty===selectedDifficulty)); $$('.category-choice').forEach(b=>b.classList.toggle('selected',b.dataset.category===selectedCategory)); $('#rewardPreview').textContent=`+${formatNum(selectedPoints)} REQUISITION XP`; };
  const openTaskModal=()=>{ editingTaskId=null;$('#taskForm').reset();selectedPoints=30;selectedDifficulty='Standard';selectedCategory='Personal';$('#taskModalTitle').textContent='ISSUE AN ORDER';$('.modal-subtitle').textContent='Define the mission. Choose its difficulty. Claim your requisition.';$('#taskSubmitLabel').textContent='CONFIRM & ISSUE ORDER';syncTaskChoices();openModal('#modalBackdrop'); };
  const openEditTaskModal=(id)=>{const task=state.tasks.find(t=>t.id===id&&!t.completed);if(!task)return;editingTaskId=id;$('#taskForm').reset();$('#taskTitle').value=task.title;$('#taskNotes').value=task.notes||'';selectedPoints=task.points;selectedDifficulty=task.difficulty;selectedCategory=task.category;$('#taskModalTitle').textContent='AMEND ACTIVE ORDER';$('.modal-subtitle').textContent='Revise the designation, difficulty, theatre, or mission notes. Changes are saved to your active roster.';$('#taskSubmitLabel').textContent='SAVE ORDER AMENDMENTS';syncTaskChoices();openModal('#modalBackdrop');};
  const showToast=(message)=>{const t=$('#toast');t.textContent=message;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2700);};
  const playTone=(freq,dur,delay=0,kind='sine',gain=.035)=>{
    if(!state.settings.sound)return;
    try{
      const AudioCtx=window.AudioContext||window.webkitAudioContext;if(!AudioCtx)return;if(!audioContext)audioContext=new AudioCtx();
      if(audioContext.state==='suspended')audioContext.resume();
      const start=audioContext.currentTime+delay,osc=audioContext.createOscillator(),amp=audioContext.createGain(),filter=audioContext.createBiquadFilter();filter.type='lowpass';filter.frequency.setValueAtTime(2600,start);osc.type=kind;osc.frequency.setValueAtTime(freq,start);amp.gain.setValueAtTime(.0001,start);amp.gain.exponentialRampToValueAtTime(gain,start+.025);amp.gain.exponentialRampToValueAtTime(.0001,start+dur);osc.connect(filter);filter.connect(amp);amp.connect(audioContext.destination);osc.start(start);osc.stop(start+dur+.02);
    }catch(e){}
  };
  const playSuccessSound=(levelUp=false,rankUp=false)=>{playTone(523,.19,0,'triangle',.025);playTone(659,.22,.1,'triangle',.025);playTone(784,.28,.2,'sine',.035);if(levelUp){playTone(988,.34,.42,'triangle',.04);playTone(rankUp?1318:1174,.55,.62,'sine',.045);}};
  const playHaptic=(milestone=false)=>{if(!state.settings.haptics)return;try{if(window.AndroidBridge&&typeof window.AndroidBridge.vibrate==='function')window.AndroidBridge.vibrate(milestone?70:28);else if(navigator.vibrate)navigator.vibrate(milestone?[35,30,70]:25);}catch(e){}};
  const particleBurst=(x,y,count=27)=>{if(!state.settings.embers)return;for(let i=0;i<count;i++){const p=document.createElement('i');p.className='particle';p.style.left=`${x}px`;p.style.top=`${y}px`;const angle=Math.PI*2*i/count+Math.random()*.3,dist=35+Math.random()*115;p.style.setProperty('--dx',`${Math.cos(angle)*dist}px`);p.style.setProperty('--dy',`${Math.sin(angle)*dist-25}px`);p.style.animationDelay=`${Math.random()*.13}s`;p.style.width=p.style.height=`${2+Math.random()*3}px`;document.body.appendChild(p);setTimeout(()=>p.remove(),1700);}};
  const flashScreen=()=>{const f=document.createElement('div');f.className='screen-flash';document.body.appendChild(f);setTimeout(()=>f.remove(),650);};
  const updateStreak=()=>{
    const today=todayKey(),last=state.lastCompletionDate;
    if(last!==today){state.streak=last===yesterdayKey()?state.streak+1:1;state.lastCompletionDate=today;state.completionDays.push(today);state.completionDays=[...new Set(state.completionDays)];state.bestStreak=Math.max(state.bestStreak,state.streak);}
  };
  const completeTask=(id,sourceButton)=>{
    const task=state.tasks.find(t=>t.id===id);if(!task||task.completed)return;
    const rect=(sourceButton||document.body).getBoundingClientRect();
    const burstX=rect.left+rect.width/2,burstY=rect.top+rect.height/2;
    const oldLevel=currentProgress().level,oldRank=currentRank();task.completed=true;task.completedAt=Date.now();state.xpTotal+=task.points;updateStreak();
    const newLevel=currentProgress().level,newRank=currentRank(),levelUp=newLevel>oldLevel,rankUp=newRank.name!==oldRank.name;
    save();renderAll();playSuccessSound(levelUp,rankUp);playHaptic(levelUp||rankUp);flashScreen();
    particleBurst(burstX,burstY,levelUp?44:27);
    showCelebration(task,oldRank,newRank,oldLevel,newLevel,levelUp,rankUp);
  };
  const showCelebration=(task,oldRank,newRank,oldLevel,newLevel,levelUp,rankUp)=>{
    $('#celebrationTask').textContent=task.title;$('#celebrationXP').innerHTML=`+${formatNum(task.points)} <span>XP</span>`;
    $('#celebrationEmblem').textContent=rankUp?newRank.symbol:levelUp?'✹':'✠';
    $('#celebrationKicker').textContent=rankUp?'PROMOTION CONFIRMED':levelUp?'LEVEL ASCENDED':'MISSION ACCOMPLISHED';
    $('#celebrationTitle').textContent=rankUp?'A NEW DESIGNATION':levelUp?'LEVEL UP':'ORDER FULFILLED';
    $('#celebrationQuote').textContent=rankUp?`“${newRank.motto}”`:levelUp?'Your discipline has moved you forward. Muster for the next objective.':'“A victory, however small, is still a victory.”';
    const transition=$('#rankTransition');transition.hidden=!rankUp;
    if(rankUp){$('#oldRank').textContent=oldRank.name+` · LVL ${oldLevel}`;$('#newRank').textContent=newRank.name+` · LVL ${newLevel}`;}
    openModal('#celebrationBackdrop');
  };
  const addTask=(title,points,difficulty,category,notes)=>{
    const task={id:makeId(),title:title.trim(),points:safeNum(points,30),difficulty,category,notes:notes.trim(),createdAt:Date.now(),completed:false,completedAt:null};state.tasks.unshift(task);state.createdCount=(state.createdCount||0)+1;save();renderAll();closeModal('#modalBackdrop');$('#taskTitle').value='';playTone(740,.12,0,'triangle',.025);playTone(990,.18,.09,'sine',.03);showToast('New order authorised. Execute it with intent.');if(currentView==='orders')renderOrders();
  };
  const updateTask=(id,title,points,difficulty,category,notes)=>{const task=state.tasks.find(t=>t.id===id&&!t.completed);if(!task)return;task.title=title.trim();task.points=safeNum(points,30);task.difficulty=difficulty;task.category=category;task.notes=notes.trim();save();renderAll();closeModal('#modalBackdrop');editingTaskId=null;playTone(620,.12,0,'triangle',.025);playTone(830,.16,.1,'sine',.03);showToast('Order amendments recorded in the mission log.');if(currentView==='orders')renderOrders();};
  const deleteTask=(id)=>{const task=state.tasks.find(t=>t.id===id);if(!task||task.completed)return;if(!confirm(`Abandon this order?\n\n${task.title}`))return;state.tasks=state.tasks.filter(t=>t.id!==id);save();renderAll();showToast('Order removed from the active roster.');};
  const exportRecord=()=>{
    const payload=JSON.stringify({...state,exportedAt:new Date().toISOString()},null,2);
    if(window.AndroidBridge&&typeof window.AndroidBridge.exportJson==='function'){window.AndroidBridge.exportJson(payload);return;}
    const blob=new Blob([payload],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='taskforge-personnel-record.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);showToast('Personnel record prepared for export.');
  };
  const importRecord=(file)=>{
    if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const parsed=JSON.parse(String(reader.result));if(!parsed||typeof parsed!=='object'||!Array.isArray(parsed.tasks)||!Number.isFinite(Number(parsed.xpTotal)))throw new Error('bad record');const next=normalizeState(parsed);if(!confirm('Replace the current campaign with this personnel record?'))return;state=next;save();renderAll();goTo('command');showToast('Personnel record restored successfully.');}catch(e){showToast('Unable to import that record. Check that it is a Taskforge JSON backup.');}};reader.readAsText(file);};
  const resetCampaign=()=>{if(!confirm('Reset all campaign data, XP, and orders on this device? Export your record first if you may need it.'))return;if(!confirm('Final confirmation: permanently erase this local campaign?'))return;state=initialState();save();renderAll();goTo('command');closeModal('#settingsBackdrop');showToast('Campaign reset. A new crusade begins.');};

  // Navigation and action delegation
  document.addEventListener('click',(event)=>{
    const nav=event.target.closest('[data-go]');if(nav){goTo(nav.dataset.go);return;}
    const close=event.target.closest('[data-close-modal]');if(close){closeModal('#modalBackdrop');return;}
    const closeSettings=event.target.closest('[data-close-settings]');if(closeSettings){closeModal('#settingsBackdrop');return;}
    const filter=event.target.closest('[data-filter]');if(filter){currentFilter=filter.dataset.filter;renderOrders();return;}
    const difficulty=event.target.closest('.difficulty-option');if(difficulty){selectedPoints=Number(difficulty.dataset.points);selectedDifficulty=difficulty.dataset.difficulty;$$('.difficulty-option').forEach(b=>b.classList.toggle('selected',b===difficulty));$('#rewardPreview').textContent=`+${formatNum(selectedPoints)} REQUISITION XP`;return;}
    const category=event.target.closest('.category-choice');if(category){selectedCategory=category.dataset.category;$$('.category-choice').forEach(b=>b.classList.toggle('selected',b===category));return;}
    const action=event.target.closest('[data-action]');if(action){if(action.dataset.action==='complete'){completeTask(action.dataset.id,action);}else if(action.dataset.action==='delete'){deleteTask(action.dataset.id);}else if(action.dataset.action==='edit'){openEditTaskModal(action.dataset.id);}else if(action.dataset.action==='add-from-empty'){openTaskModal();}return;}
  });
  $('#addOrderButton').addEventListener('click',openTaskModal);$('#addOrderButton2').addEventListener('click',openTaskModal);$('#addOrderTop').addEventListener('click',openTaskModal);
  $('#taskForm').addEventListener('submit',(event)=>{event.preventDefault();const title=$('#taskTitle').value.trim(),notes=$('#taskNotes').value.trim();if(!title){$('#taskTitle').focus();return;}if(editingTaskId)updateTask(editingTaskId,title,selectedPoints,selectedDifficulty,selectedCategory,notes);else addTask(title,selectedPoints,selectedDifficulty,selectedCategory,notes);});
  $('#celebrationContinue').addEventListener('click',()=>{closeModal('#celebrationBackdrop');});
  $('#settingsBtn').addEventListener('click',()=>openModal('#settingsBackdrop'));
  $('#soundBtn').addEventListener('click',()=>{state.settings.sound=!state.settings.sound;save();updateSettingsUI();if(state.settings.sound)playSuccessSound(false,false);showToast(state.settings.sound?'Immersive sound enabled.':'Immersive sound muted.');});
  $('#soundSetting').addEventListener('click',()=>{state.settings.sound=!state.settings.sound;save();updateSettingsUI();if(state.settings.sound)playSuccessSound(false,false);});
  $('#emberSetting').addEventListener('click',()=>{state.settings.embers=!state.settings.embers;save();updateSettingsUI();});
  $('#hapticSetting').addEventListener('click',()=>{state.settings.haptics=!state.settings.haptics;save();updateSettingsUI();if(state.settings.haptics)playHaptic();});
  $('#searchOrders').addEventListener('input',renderOrders);
  $('#exportDataBtn').addEventListener('click',exportRecord);
  $('#importDataBtn').addEventListener('click',()=>$('#importFile').click());
  $('#importFile').addEventListener('change',(event)=>{importRecord(event.target.files&&event.target.files[0]);event.target.value='';});
  $('#resetDataBtn').addEventListener('click',resetCampaign);
  ['#modalBackdrop','#celebrationBackdrop','#settingsBackdrop'].forEach(id=>$(id).addEventListener('click',(e)=>{if(e.target.id===id){if(id==='#celebrationBackdrop')closeModal(id);else closeModal(id);}}));
  document.addEventListener('keydown',(e)=>{if(e.key==='Escape'){if($('#celebrationBackdrop').classList.contains('open'))closeModal('#celebrationBackdrop');else if($('#settingsBackdrop').classList.contains('open'))closeModal('#settingsBackdrop');else if($('#modalBackdrop').classList.contains('open'))closeModal('#modalBackdrop');}});
  window.handleSystemBack=()=>{for(const id of ['#celebrationBackdrop','#settingsBackdrop','#modalBackdrop'])if($(id).classList.contains('open')){closeModal(id);return true;}if(currentView!=='command'){goTo('command');return true;}return false;};
  $('#exportDataBtn').addEventListener('keydown',(e)=>{if(e.key==='Enter')exportRecord();});

  // Atmospheric embers. Paused when the app is backgrounded or effects are disabled.
  const canvas=$('#embers'),ctx=canvas.getContext('2d');let emberList=[],frame=0,canvasW=0,canvasH=0;
  const resizeCanvas=()=>{const scale=Math.min(window.devicePixelRatio||1,1.5);canvasW=window.innerWidth;canvasH=window.innerHeight;canvas.width=Math.floor(canvasW*scale);canvas.height=Math.floor(canvasH*scale);canvas.style.width=canvasW+'px';canvas.style.height=canvasH+'px';ctx.setTransform(scale,0,0,scale,0,0);emberList=Array.from({length:Math.max(15,Math.min(42,Math.round(canvasW/11)))},()=>newEmber(true));};
  const newEmber=(randomY=false)=>({x:Math.random()*canvasW,y:randomY?Math.random()*canvasH:canvasH+Math.random()*60,r:.45+Math.random()*1.2,vy:.12+Math.random()*.35,vx:(Math.random()-.5)*.15,alpha:.12+Math.random()*.4,phase:Math.random()*Math.PI*2});
  const drawEmbers=()=>{frame++;ctx.clearRect(0,0,canvasW,canvasH);if(state.settings.embers&&document.visibilityState==='visible'){for(let i=0;i<emberList.length;i++){const p=emberList[i];p.y-=p.vy;p.x+=p.vx+Math.sin(frame*.012+p.phase)*.13;if(p.y<-8)emberList[i]=newEmber(false);ctx.beginPath();ctx.fillStyle=`rgba(221,165,76,${p.alpha*(.55+.45*Math.sin(frame*.02+p.phase))})`;ctx.shadowBlur=5;ctx.shadowColor='rgba(227,164,64,.45)';ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();}ctx.shadowBlur=0;}requestAnimationFrame(drawEmbers);};
  window.addEventListener('resize',resizeCanvas);resizeCanvas();requestAnimationFrame(drawEmbers);

  // Render initial application state.
  renderAll();
  if(state.firstLaunch){state.firstLaunch=false;save();setTimeout(()=>showToast('Welcome, operative. Your first orders await.'),500);}
})();
