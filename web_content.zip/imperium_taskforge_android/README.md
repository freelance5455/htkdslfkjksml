# Taskforge 40K — Android project

A Warhammer 40K-inspired, offline-first personal task RPG packaged in a native Android WebView shell.

## Features
- Create task orders with Routine, Standard, Hard, Heroic, and Legendary XP rewards.
- Edit any active order (title, difficulty/XP, category, and mission notes) using the ✎ button on its card.
- Complete orders to earn XP, level up, and progress through ranks up to Primarch.
- Animated completion and promotion ceremonies, ember particles, haptic feedback, and synthesized sound cues.
- Sound, ember, and haptic toggles; campaign stats; streaks; local persistence; JSON export/import.
- Works offline after installation; task data is stored locally on the device.

## Build an installable APK
This folder is the complete Android Studio source project. The APK must be compiled with Android build tools.

1. Install Android Studio and its Android SDK (API 35 platform/build tools).
2. Open this project folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build APK(s)**.
5. Android Studio will show the output location; typically `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy that APK to your Android phone and open it to install. If prompted, allow installation from that source.

The project uses Gradle plugin 8.7.3 and Kotlin Android plugin 2.0.21. First build requires access to the Gradle/plugin repositories unless those dependencies are already cached.

## Browser/PWA version
The `app/src/main/assets` folder also contains the standalone HTML/CSS/JS app. `Taskforge_40K_PWA.zip` is the separate PWA package.

## Automated cloud build (when a local Android SDK is unavailable)
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. Upload this project to a GitHub repository, open **Actions → Build Taskforge 40K APK → Run workflow**, and download the `Taskforge-40K-debug-apk` artifact from the completed run. GitHub builds it on a hosted runner and produces `app-debug.apk`.
