LAHORE SALAH TIME — UPDATED PROJECT
===================================

This ZIP contains the updated web-app source for Lahore Salah Time.

INCLUDED
- Lahore prayer times from AlAdhan API
- Correct API request format:
  https://api.aladhan.com/v1/timingsByCity?city=Lahore&country=Pakistan&method=1
- Five daily prayer cards and next-prayer countdown
- Green and gold responsive design
- PWA manifest, service worker and app icon

IMPORTANT — THIS IS NOT AN APK YET
This is an updated web/PWA project ZIP, not a compiled or signed Android APK.
Acode Preview is not a full Android app runtime and may not support browser
notifications. The current browser reminder code only works while the page
is active. Notifications while the app is closed require a native Android
package with scheduled local notifications.

HOW TO USE
1. Extract this ZIP.
2. In Acode, open the new folder "Lahore_Salah_Time_Updated".
3. Open index.html and use Preview.
4. Internet is required to fetch current prayer times.

NATIVE APK REQUIREMENTS
To produce an installable APK with reminders while closed, the project must
be wrapped as a native Android app (for example, using Capacitor plus a
local-notifications plugin), then built and signed. Acode Preview alone
cannot perform that build. Do not expect this ZIP itself to install as APK.

PRAYER-TIME NOTE
Calculation method is University of Islamic Sciences, Karachi (method=1).
Local mosque timetables may differ by a few minutes; verify against your
preferred Lahore mosque timetable.
