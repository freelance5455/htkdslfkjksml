(() => {
  const status = document.getElementById("pwa-status");
  const installButton = document.getElementById("install-pwa");
  let installPrompt = null;

  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    navigator.serviceWorker.register("/static/sw.js").catch(() => {
      if (status) status.textContent = "تعذر تفعيل التخزين المؤقت؛ يمكنك استخدام المتجر عبر الإنترنت.";
    });
  } else if (status) {
    status.textContent = "التثبيت يحتاج إلى HTTPS أو localhost.";
  }

  window.addEventListener("beforeinstallprompt", event => {
    event.preventDefault();
    installPrompt = event;
    if (installButton) installButton.hidden = false;
  });

  if (installButton) {
    installButton.addEventListener("click", async () => {
      if (!installPrompt) {
        if (status) status.textContent = "من قائمة المتصفح اختر «إضافة إلى الشاشة الرئيسية» أو «تثبيت التطبيق» إذا ظهر الخيار.";
        return;
      }
      installPrompt.prompt();
      await installPrompt.userChoice;
      installPrompt = null;
      installButton.hidden = true;
    });
  }

  window.addEventListener("appinstalled", () => {
    if (status) status.textContent = "تم تثبيت PLDOSER على الجهاز.";
    if (installButton) installButton.hidden = true;
  });
})();