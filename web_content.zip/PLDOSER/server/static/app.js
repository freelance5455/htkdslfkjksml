const grid = document.getElementById('app-grid');
const search = document.getElementById('search');
const categoryFilter = document.getElementById('category-filter');
const sort = document.getElementById('sort');
const message = document.getElementById('message');
let kind = 'app', items = [], categories = [];

const esc = (value='') => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const formatSize = n => n === null || n === undefined || n === '' ? 'الحجم غير محدد' : `${Number(n).toLocaleString('ar-EG')} م.ب`;
function showEmpty(title, desc){grid.innerHTML=`<div class="empty-state"><div class="empty-icon">⌕</div><h3>${esc(title)}</h3><p>${esc(desc)}</p></div>`;}
async function loadCategories(){
  try {
    const res = await fetch(`/api/categories?type=${kind}`);
    categories = res.ok ? await res.json() : [];
    categoryFilter.innerHTML = '<option value="">كل التصنيفات</option>' + categories.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');
  } catch { categories=[]; }
}
async function loadItems(){
  grid.innerHTML='<div class="empty-state"><h3>جارٍ تحميل المتجر</h3><p>يتم الاتصال بالخادم...</p></div>';
  message.textContent='';
  try {
    const res=await fetch(`/api/apps?type=${kind}`);
    if(!res.ok) throw new Error('تعذر تحميل البيانات.');
    items=await res.json(); render();
  } catch(e) {
    showEmpty('تعذر الاتصال بالمتجر','تحقق من اتصال الخادم ثم حاول مرة أخرى.');
    message.textContent=e.message;
  }
}
function render(){
  const q=search.value.trim().toLocaleLowerCase();
  let visible=items.filter(x=>{
    const match=[x.name,x.developer,x.short_description,x.category_name].join(' ').toLocaleLowerCase().includes(q);
    return match && (!categoryFilter.value || String(x.category_id)===categoryFilter.value);
  });
  if(sort.value==='name') visible.sort((a,b)=>a.name.localeCompare(b.name,'ar'));
  if(sort.value==='size') visible.sort((a,b)=>(a.size_mb??Infinity)-(b.size_mb??Infinity));
  document.getElementById('result-count').textContent=`${visible.length.toLocaleString('ar-EG')} عنصر`;
  document.getElementById('section-title').textContent=kind==='app'?'التطبيقات المنشورة':'الألعاب المنشورة';
  if(!visible.length){showEmpty(q?'لا توجد نتائج مطابقة':'لا توجد عناصر منشورة بعد',q?'جرّب كلمة بحث أخرى أو غيّر التصنيف.':'سيظهر هنا المحتوى الحقيقي بعد أن يضيفه المدير وينشره.');return;}
  grid.innerHTML=visible.map(x=>`<article class="app-card">
    <div class="app-card-head"><div class="app-icon">${x.icon_url?`<img src="${esc(x.icon_url)}" alt="" loading="lazy" onerror="this.remove()">`:'P'}</div><div><h3>${esc(x.name)}</h3><div class="developer">${esc(x.developer||'المطور غير محدد')}</div></div></div>
    <p>${esc(x.short_description||x.description||'لا يوجد وصف مضاف.')}</p>
    <div class="meta"><span class="pill">${esc(x.category_name||'غير مصنف')}</span><span>${esc(x.version||'إصدار غير محدد')}</span><span>${esc(formatSize(x.size_mb))}</span></div>
    <div class="card-actions"><button class="button primary" data-download="${x.id}">صفحة التنزيل ↗</button><button class="button secondary" data-details="${x.id}">التفاصيل</button></div>
    </article>`).join('');
  grid.querySelectorAll('[data-download]').forEach(b=>b.addEventListener('click',()=>downloadItem(Number(b.dataset.download))));
  grid.querySelectorAll('[data-details]').forEach(b=>b.addEventListener('click',()=>showDetails(Number(b.dataset.details))));
}
async function downloadItem(id){
  message.textContent='جارٍ التحقق من رابط التنزيل...';
  try{
    const res=await fetch(`/api/download/${id}`,{method:'POST'});
    const data=await res.json();
    if(!res.ok) throw new Error(data.error||'تعذر فتح رابط التنزيل.');
    message.textContent=data.message;
    window.open(data.download_url,'_blank','noopener,noreferrer');
  }catch(e){message.textContent=e.message;message.className='message error';}
}
async function showDetails(id){
  try{
    const res=await fetch(`/api/apps/${id}`); const x=await res.json();
    if(!res.ok) throw new Error(x.error||'تعذر جلب التفاصيل.');
    alert(`${x.name}\n\nالمطور: ${x.developer||'غير محدد'}\nالتصنيف: ${x.category_name||'غير مصنف'}\nالإصدار: ${x.version||'غير محدد'}\nالحجم: ${formatSize(x.size_mb)}\nأندرويد: ${x.min_android||'غير محدد'}\n\n${x.description||x.short_description||'لا يوجد وصف.'}\n\nملاحظة: المتجر لا يفحص الملف ولا يضمن سلامته.`);
  }catch(e){message.textContent=e.message;}
}
document.querySelectorAll('[data-kind]').forEach(b=>b.addEventListener('click',async()=>{
  kind=b.dataset.kind;document.querySelectorAll('[data-kind]').forEach(x=>x.classList.toggle('active',x===b));
  await loadCategories();await loadItems();
}));
search.addEventListener('input',render);categoryFilter.addEventListener('change',render);sort.addEventListener('change',render);
document.getElementById('clear-search').addEventListener('click',()=>{search.value='';render();});
(async()=>{await loadCategories();await loadItems();})();
