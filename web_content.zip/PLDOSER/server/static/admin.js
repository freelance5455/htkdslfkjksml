const $=id=>document.getElementById(id);
const esc = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let allItems=[], allCategories=[];
const fields=['name','kind','developer','short_description','description','category_id','version','size_mb','min_android','internet_required','icon_url','cover_url','download_url','requirements','featured','published'];
async function api(url,options={}){
  const res=await fetch(url,{...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.error||'حدث خطأ أثناء تنفيذ الطلب.');
  return data;
}
function msg(text,error=false){$('form-message').textContent=text;$('form-message').className='message'+(error?' error':'');}
async function loadStats(){
 try{const s=await api('/api/admin/stats');$('stats').innerHTML=[['التطبيقات',s.apps],['الألعاب',s.games],['المنشور',s.published],['طلبات فتح التنزيل',s.download_requests]].map(([k,v])=>`<div class="stat"><span>${k}</span><b>${Number(v).toLocaleString('ar-EG')}</b></div>`).join('');}catch(e){console.error(e);}
}
async function loadCategories(){
 allCategories=await api('/api/admin/categories');
 $('category_id').innerHTML='<option value="">بدون تصنيف</option>'+allCategories.filter(c=>c.kind===$('kind').value).map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');
 $('category-list').innerHTML=allCategories.map(c=>`<span class="category-chip">${esc(c.name)} · ${c.kind==='app'?'تطبيقات':'ألعاب'} <button class="tiny-button delete" data-cat-delete="${c.id}" aria-label="حذف التصنيف">×</button></span>`).join('')||'<span class="message">لا توجد تصنيفات بعد.</span>';
 $('category-list').querySelectorAll('[data-cat-delete]').forEach(b=>b.onclick=async()=>{if(confirm('حذف هذا التصنيف؟')){try{await api('/api/admin/categories/'+b.dataset.catDelete,{method:'DELETE'});await refreshAll();}catch(e){alert(e.message);}}});
}
function resetForm(){
 $('item-form').reset();$('item-id').value='';$('form-title').textContent='إضافة تطبيق أو لعبة';loadCategories();
}
function fillForm(x){
 $('item-id').value=x.id;
 fields.forEach(f=>{const el=$(f);if(!el)return;if(el.type==='checkbox')el.checked=Boolean(x[f]);else el.value=x[f]??'';});
 $('form-title').textContent='تعديل: '+x.name;loadCategories().then(()=>$('category_id').value=x.category_id??'');
 window.scrollTo({top:0,behavior:'smooth'});
}
async function loadItems(){
 allItems=await api('/api/admin/apps');
 $('admin-items').innerHTML=allItems.map(x=>`<div class="admin-item"><div class="app-icon">${x.icon_url?`<img src="${esc(x.icon_url)}" alt="" onerror="this.remove()">`:'P'}</div><div class="item-info"><b>${esc(x.name)}</b><small>${x.kind==='app'?'تطبيق':'لعبة'} · ${x.published?'منشور':'مسودة'} · ${esc(x.version||'إصدار غير محدد')}</small></div><div class="item-buttons"><button class="tiny-button" data-edit="${x.id}">تعديل</button><button class="tiny-button delete" data-delete="${x.id}">حذف</button></div></div>`).join('')||'<div class="empty-state"><h3>لا توجد بيانات بعد</h3><p>أضف أول تطبيق أو لعبة من النموذج.</p></div>';
 $('admin-items').querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>fillForm(allItems.find(x=>x.id===Number(b.dataset.edit))));
 $('admin-items').querySelectorAll('[data-delete]').forEach(b=>b.onclick=async()=>{if(confirm('هل تريد حذف هذا العنصر نهائيًا؟')){try{await api('/api/admin/apps/'+b.dataset.delete,{method:'DELETE'});await refreshAll();}catch(e){alert(e.message);}}});
}
async function refreshAll(){await Promise.all([loadStats(),loadItems()]);await loadCategories();}
$('item-form').addEventListener('submit',async e=>{
 e.preventDefault();
 const payload={};
 fields.forEach(f=>{const el=$(f);if(el.type==='checkbox')payload[f]=el.checked;else payload[f]=el.value;});
 if(payload.category_id)payload.category_id=Number(payload.category_id);else payload.category_id=null;
 if(payload.size_mb==='')payload.size_mb=null;else payload.size_mb=Number(payload.size_mb);
 try{
  const id=$('item-id').value;
  await api(id?'/api/admin/apps/'+id:'/api/admin/apps',{method:id?'PUT':'POST',body:JSON.stringify(payload)});
  msg('تم حفظ البيانات في قاعدة البيانات.');resetForm();await refreshAll();
 }catch(err){msg(err.message,true);}
});
$('reset-form').onclick=resetForm;
$('refresh').onclick=refreshAll;
$('kind').onchange=loadCategories;
$('category-form').addEventListener('submit',async e=>{
 e.preventDefault();
 try{await api('/api/admin/categories',{method:'POST',body:JSON.stringify({name:$('category-name').value,kind:$('category-kind').value})});$('category-name').value='';await loadCategories();msg('تم إضافة التصنيف.');}
 catch(err){msg(err.message,true);}
});
refreshAll().catch(e=>{ $('admin-items').textContent=e.message; });
