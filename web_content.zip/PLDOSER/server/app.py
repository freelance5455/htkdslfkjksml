import os
import re
import sqlite3
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from urllib.parse import urlparse

from flask import Flask, abort, g, jsonify, redirect, render_template, request, session, url_for, send_from_directory
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
DB_PATH = INSTANCE_DIR / "pldoser.sqlite3"

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config.update(
    SECRET_KEY=os.environ.get("PLDOSER_SECRET_KEY", ""),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("PLDOSER_COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)
ADMIN_USERNAME = os.environ.get("PLDOSER_ADMIN_USERNAME", "").strip()
ADMIN_PASSWORD = os.environ.get("PLDOSER_ADMIN_PASSWORD", "")
if not app.config["SECRET_KEY"] or len(app.config["SECRET_KEY"]) < 32:
    raise RuntimeError("اضبط PLDOSER_SECRET_KEY بقيمة عشوائية لا تقل عن 32 حرفًا.")
if not ADMIN_USERNAME or len(ADMIN_PASSWORD) < 12:
    raise RuntimeError("اضبط PLDOSER_ADMIN_USERNAME وكلمة مرور PLDOSER_ADMIN_PASSWORD بطول 12 حرفًا على الأقل.")

def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def db():
    if "db" not in g:
        INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        g.db = conn
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      kind TEXT NOT NULL CHECK(kind IN ('app','game')),
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS apps (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      kind TEXT NOT NULL CHECK(kind IN ('app','game')),
      developer TEXT NOT NULL DEFAULT '',
      short_description TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      category_id INTEGER,
      icon_url TEXT NOT NULL DEFAULT '',
      cover_url TEXT NOT NULL DEFAULT '',
      screenshots_json TEXT NOT NULL DEFAULT '[]',
      version TEXT NOT NULL DEFAULT '',
      size_mb REAL,
      download_url TEXT NOT NULL DEFAULT '',
      min_android TEXT NOT NULL DEFAULT '',
      requirements TEXT NOT NULL DEFAULT '',
      internet_required TEXT NOT NULL DEFAULT 'unknown',
      featured INTEGER NOT NULL DEFAULT 0,
      published INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS download_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      app_id INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY(app_id) REFERENCES apps(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS admin_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      item_type TEXT NOT NULL,
      item_id INTEGER,
      created_at TEXT NOT NULL
    );
    """)
    conn.commit()
    conn.close()

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("is_admin"):
            if request.path.startswith("/api/"):
                return jsonify({"error": "يلزم تسجيل دخول المدير"}), 401
            return redirect(url_for("admin_login_page"))
        return fn(*args, **kwargs)
    return wrapped

def csrf_check():
    # SameSite=Lax helps mitigate cross-site POSTs; validate Origin when supplied.
    origin = request.headers.get("Origin")
    if origin:
        parsed = urlparse(origin)
        host = request.host.split(":")[0]
        if parsed.hostname != host:
            abort(403, description="مصدر الطلب غير مسموح")
    return True

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = "default-src 'self'; img-src 'self' https: data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'"
    return response

@app.get("/manifest.webmanifest")
def pwa_manifest():
    return send_from_directory(BASE_DIR, "manifest.webmanifest", mimetype="application/manifest+json")

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/admin")
def admin_login_page():
    if session.get("is_admin"):
        return render_template("admin.html")
    return render_template("login.html")

@app.post("/admin/login")
def admin_login():
    csrf_check()
    # Simple in-process throttle; use a shared rate limiter at production deployment.
    attempts = session.get("login_attempts", 0)
    if attempts >= 8:
        return render_template("login.html", error="محاولات كثيرة. أغلق الصفحة وانتظر قليلًا ثم حاول مجددًا."), 429
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    # Environment password is never stored in source; hash at process startup for comparison.
    if not hasattr(app, "_admin_password_hash"):
        app._admin_password_hash = generate_password_hash(ADMIN_PASSWORD)
    if username == ADMIN_USERNAME and check_password_hash(app._admin_password_hash, password):
        session.clear()
        session["is_admin"] = True
        session["login_attempts"] = 0
        return redirect(url_for("admin_login_page"))
    session["login_attempts"] = attempts + 1
    return render_template("login.html", error="بيانات تسجيل الدخول غير صحيحة."), 401

@app.post("/admin/logout")
@admin_required
def admin_logout():
    csrf_check()
    session.clear()
    return redirect(url_for("home"))

def app_dict(row):
    d = dict(row)
    d["featured"] = bool(d["featured"])
    d["published"] = bool(d["published"])
    return d

@app.get("/api/apps")
def list_apps():
    kind = request.args.get("type", "app")
    if kind not in ("app", "game"):
        return jsonify({"error": "نوع غير صالح"}), 400
    rows = db().execute("""
      SELECT a.*, c.name AS category_name
      FROM apps a LEFT JOIN categories c ON c.id=a.category_id
      WHERE a.kind=? AND a.published=1 ORDER BY a.featured DESC, a.created_at DESC
    """, (kind,)).fetchall()
    return jsonify([app_dict(r) for r in rows])

@app.get("/api/apps/<int:item_id>")
def get_app(item_id):
    row = db().execute("""
      SELECT a.*, c.name AS category_name FROM apps a
      LEFT JOIN categories c ON c.id=a.category_id
      WHERE a.id=? AND a.published=1
    """, (item_id,)).fetchone()
    if not row:
        return jsonify({"error": "العنصر غير موجود أو غير منشور"}), 404
    return jsonify(app_dict(row))

@app.get("/api/categories")
def list_categories():
    kind = request.args.get("type", "app")
    if kind not in ("app", "game"):
        return jsonify({"error": "نوع غير صالح"}), 400
    rows = db().execute("SELECT * FROM categories WHERE kind=? ORDER BY name", (kind,)).fetchall()
    return jsonify([dict(r) for r in rows])

@app.post("/api/download/<int:item_id>")
def request_download(item_id):
    row = db().execute("SELECT id, download_url FROM apps WHERE id=? AND published=1", (item_id,)).fetchone()
    if not row:
        return jsonify({"error": "العنصر غير متاح للتنزيل"}), 404
    url = row["download_url"].strip()
    parsed = urlparse(url)
    if parsed.scheme not in ("https",) or not parsed.netloc:
        return jsonify({"error": "رابط التنزيل غير متاح أو ليس رابط HTTPS صالحًا"}), 409
    db().execute("INSERT INTO download_events(app_id, created_at) VALUES (?,?)", (item_id, now_iso()))
    db().commit()
    return jsonify({"download_url": url, "message": "تم تسجيل طلب فتح رابط التنزيل، ولا يعني ذلك اكتمال تنزيل الملف."})

@app.get("/api/admin/apps")
@admin_required
def admin_apps():
    rows = db().execute("SELECT * FROM apps ORDER BY created_at DESC").fetchall()
    return jsonify([app_dict(r) for r in rows])

def valid_http_url(value, allow_empty=True):
    if not value and allow_empty:
        return True
    p = urlparse(value)
    return p.scheme in ("https",) and bool(p.netloc)

def parse_app_payload(payload, existing=None):
    name = str(payload.get("name", existing["name"] if existing else "")).strip()
    kind = str(payload.get("kind", existing["kind"] if existing else "app"))
    if not name or len(name) > 120 or kind not in ("app", "game"):
        raise ValueError("اسم العنصر مطلوب (حتى 120 حرفًا) والنوع يجب أن يكون تطبيقًا أو لعبة.")
    def val(key, default=""):
        return str(payload.get(key, existing[key] if existing else default) or "").strip()
    icon_url, cover_url, download_url = val("icon_url"), val("cover_url"), val("download_url")
    if not valid_http_url(icon_url) or not valid_http_url(cover_url) or not valid_http_url(download_url):
        raise ValueError("يجب أن تكون الروابط روابط HTTPS صالحة.")
    size = payload.get("size_mb", existing["size_mb"] if existing else None)
    if size in ("", None):
        size = None
    else:
        size = float(size)
        if size < 0 or size > 100000:
            raise ValueError("حجم الملف غير صالح.")
    category_id = payload.get("category_id", existing["category_id"] if existing else None)
    if category_id in ("", None):
        category_id = None
    else:
        category_id = int(category_id)
        cat = db().execute("SELECT id, kind FROM categories WHERE id=?", (category_id,)).fetchone()
        if not cat or cat["kind"] != kind:
            raise ValueError("التصنيف غير صالح لهذا النوع.")
    featured = int(bool(payload.get("featured", existing["featured"] if existing else False)))
    published = int(bool(payload.get("published", existing["published"] if existing else False)))
    internet = val("internet_required", "unknown")
    if internet not in ("yes", "no", "unknown"):
        internet = "unknown"
    return (name, kind, val("developer"), val("short_description"), val("description"),
            category_id, icon_url, cover_url, val("screenshots_json", "[]"), val("version"),
            size, download_url, val("min_android"), val("requirements"), internet, featured, published)

@app.post("/api/admin/apps")
@admin_required
def create_app():
    csrf_check()
    payload = request.get_json(silent=True) or {}
    try:
        values = parse_app_payload(payload)
    except (ValueError, TypeError) as e:
        return jsonify({"error": str(e)}), 400
    stamp = now_iso()
    cur = db().execute("""INSERT INTO apps
      (name,kind,developer,short_description,description,category_id,icon_url,cover_url,screenshots_json,version,size_mb,download_url,min_android,requirements,internet_required,featured,published,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (*values, stamp, stamp))
    db().execute("INSERT INTO admin_events(action,item_type,item_id,created_at) VALUES ('create','app',?,?)", (cur.lastrowid, stamp))
    db().commit()
    return jsonify({"id": cur.lastrowid, "message": "تم حفظ العنصر."}), 201

@app.put("/api/admin/apps/<int:item_id>")
@admin_required
def update_app(item_id):
    csrf_check()
    existing = db().execute("SELECT * FROM apps WHERE id=?", (item_id,)).fetchone()
    if not existing:
        return jsonify({"error": "العنصر غير موجود"}), 404
    payload = request.get_json(silent=True) or {}
    try:
        values = parse_app_payload(payload, existing)
    except (ValueError, TypeError) as e:
        return jsonify({"error": str(e)}), 400
    stamp = now_iso()
    db().execute("""UPDATE apps SET name=?,kind=?,developer=?,short_description=?,description=?,category_id=?,icon_url=?,cover_url=?,screenshots_json=?,version=?,size_mb=?,download_url=?,min_android=?,requirements=?,internet_required=?,featured=?,published=?,updated_at=? WHERE id=?""", (*values, stamp, item_id))
    db().execute("INSERT INTO admin_events(action,item_type,item_id,created_at) VALUES ('update','app',?,?)", (item_id, stamp))
    db().commit()
    return jsonify({"message": "تم تحديث العنصر."})

@app.delete("/api/admin/apps/<int:item_id>")
@admin_required
def delete_app(item_id):
    csrf_check()
    db().execute("DELETE FROM apps WHERE id=?", (item_id,))
    db().execute("INSERT INTO admin_events(action,item_type,item_id,created_at) VALUES ('delete','app',?,?)", (item_id, now_iso()))
    db().commit()
    return jsonify({"message": "تم حذف العنصر إن كان موجودًا."})

@app.get("/api/admin/categories")
@admin_required
def admin_categories():
    return jsonify([dict(r) for r in db().execute("SELECT * FROM categories ORDER BY kind,name").fetchall()])

@app.post("/api/admin/categories")
@admin_required
def create_category():
    csrf_check()
    payload = request.get_json(silent=True) or {}
    name = str(payload.get("name", "")).strip()
    kind = str(payload.get("kind", "app"))
    if not name or len(name) > 80 or kind not in ("app", "game"):
        return jsonify({"error": "اسم أو نوع التصنيف غير صالح"}), 400
    try:
        cur = db().execute("INSERT INTO categories(name,kind,created_at) VALUES (?,?,?)", (name, kind, now_iso()))
        db().commit()
        return jsonify({"id": cur.lastrowid, "message": "تم حفظ التصنيف."}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "يوجد تصنيف بهذا الاسم بالفعل"}), 409

@app.delete("/api/admin/categories/<int:cat_id>")
@admin_required
def delete_category(cat_id):
    csrf_check()
    db().execute("DELETE FROM categories WHERE id=?", (cat_id,))
    db().commit()
    return jsonify({"message": "تم حذف التصنيف إن وجد."})

@app.get("/api/admin/stats")
@admin_required
def admin_stats():
    conn = db()
    return jsonify({
      "apps": conn.execute("SELECT COUNT(*) FROM apps WHERE kind='app'").fetchone()[0],
      "games": conn.execute("SELECT COUNT(*) FROM apps WHERE kind='game'").fetchone()[0],
      "published": conn.execute("SELECT COUNT(*) FROM apps WHERE published=1").fetchone()[0],
      "download_requests": conn.execute("SELECT COUNT(*) FROM download_events").fetchone()[0],
    })

@app.get("/health")
def health():
    return jsonify({"status": "ok", "database": "sqlite configured"})

init_db()

if __name__ == "__main__":
    # Local development only; production deployment should use a production WSGI server.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
