from flask import Flask, request, jsonify, send_from_directory
import json
import os
import hashlib
import time
import requests  # For VPN/proxy simulation
from wallet import WalletManager

app = Flask(__name__, static_folder='frontend')

# Configuration
LEDGER_FILE = 'ledger.json'
WALLET_KEY_FILE = 'wallet_key.json'
PROXY_URL = "http://proxy.example.com:8080"  # Example VPN endpoint

# Initialize wallet manager
wallet_manager = WalletManager(WALLET_KEY_FILE)

def load_ledger():
    if not os.path.exists(LEDGER_FILE):
        return {"transactions": [], "balance": 0.03}  # Start with 0.03 BTC
    with open(LEDGER_FILE, 'r') as f:
        return json.load(f)

def save_ledger(ledger):
    with open(LEDGER_FILE, 'w') as f:
        json.dump(ledger, f, indent=4)

@app.route('/')
def index():
    return send_from_directory('frontend', 'index.html')

@app.route('/api/send', methods=['POST'])
def send_flash():
    data = request.json
    recipient = data.get('recipient')
    amount = data.get('amount')
    use_vpn = data.get('use_vpn', False)

    if not recipient or not amount:
        return jsonify({"success": False, "error": "Missing fields"}), 400

    # Load current state
    ledger = load_ledger()
    
    # Check balance
    if ledger["balance"] < amount:
        return jsonify({"success": False, "error": "Insufficient funds"}), 400

    # Sign transaction using private key
    tx_id = wallet_manager.sign_transaction(recipient, amount)
    
    # Create transaction record
    tx_record = {
        "txid": tx_id,
        "sender": wallet_manager.get_address(),
        "recipient": recipient,
        "amount": amount,
        "timestamp": time.time(),
        "status": "pending",  # Simulate pending state
        "vpn_routed": use_vpn
    }

    # Deduct balance
    ledger["balance"] -= amount
    
    # Add to decentralized ledger
    ledger["transactions"].append(tx_record)
    save_ledger(ledger)

    # Simulate VPN routing if requested
    if use_vpn:
        try:
            # Just ping the proxy to confirm connectivity
            requests.head(PROXY_URL, timeout=2)
            tx_record["vpn_status"] = "connected"
        except:
            tx_record["vpn_status"] = "failed"

    return jsonify({
        "success": True,
        "txid": tx_id,
        "new_balance": ledger["balance"],
        "vpn_routed": use_vpn
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)