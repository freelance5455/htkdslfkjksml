# NEXCODE AI — Complete HTML Export

Build Anything. Code Everything.

## Included Files
- `index.html` — Entry HTML with responsive mobile viewport and NEXCODE AI metadata.
- `styles.css` — Complete Tailwind CSS v4 stylesheet, dark theme, typography, animations, and custom scrollbars.
- `script.js` — Complete bundled application logic (Onboarding Permissions, Chat, Markdown/Code blocks & Copy buttons, Attachments, History Drawer, Live Voice Call, Camera Preview, Language Switching, and Android Bridge hooks).
- `assets/nexcode-logo.svg` — Vector NEXCODE AI brand mark / favicon.

## API Configuration (Zero Exposed Keys)
- Private Gemini API keys are never stored in the HTML/JS files.
- All AI chat (`POST /api/chat`) and voice call (`WS /api/live`) traffic routes through the server proxy.
- When hosted separately or opened locally, requests automatically target your configured backend URL (customizable before loading `script.js` via `window.NEXCODE_API_BASE = 'https://your-server-url'`).

## Browser vs. Native Android Notes
- **Works directly in Chrome / Android mobile browsers (HTTPS)**: Onboarding permissions, AI Chat, Markdown & code highlighting, Copy code buttons, History Drawer, image/video/code file attachments, real-time Voice Call, language switching, and browser camera sharing.
- **Requires compiled Native Android APK (`/android`)**: System-wide cross-app Android screen sharing (`MediaProjection`) and floating overlay indicator (`SYSTEM_ALERT_WINDOW`). Standard HTML/JavaScript in mobile browsers cannot capture other installed Android apps like WhatsApp or Roblox.
