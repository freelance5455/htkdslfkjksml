Mis Tarjetas y Mis Créditos

Abrir index.html en Chrome o utilizar esta carpeta/ZIP para convertirla en APK.
Los datos se guardan localmente en el navegador mediante localStorage.
Esta versión muestra el PAGO DEL MES y FECHA DE PAGO en grande, descuenta los pagos registrados dentro del periodo y agrega un resumen final por fecha y tarjeta.
