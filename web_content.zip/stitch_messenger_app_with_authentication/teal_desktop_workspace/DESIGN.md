---
name: Teal Desktop Workspace
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3e494a'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6f797a'
  outline-variant: '#bec8ca'
  surface-tint: '#006972'
  primary: '#00535b'
  on-primary: '#ffffff'
  primary-container: '#006d77'
  on-primary-container: '#9becf7'
  inverse-primary: '#82d3de'
  secondary: '#006b5f'
  on-secondary: '#ffffff'
  secondary-container: '#6df5e1'
  on-secondary-container: '#006f64'
  tertiary: '#00554e'
  on-tertiary: '#ffffff'
  tertiary-container: '#006f67'
  on-tertiary-container: '#99efe4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9ff0fb'
  primary-fixed-dim: '#82d3de'
  on-primary-fixed: '#001f23'
  on-primary-fixed-variant: '#004f56'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#9cf2e8'
  tertiary-fixed-dim: '#80d5cb'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#00504a'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-sm:
    fontFamily: Manrope
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  headline-sm:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-compact: 0.75rem
  margin: 1.5rem
  margin-panel: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system delivers a focused, architectural desktop workspace tailored for modern real-time communication, team coordination, and bilingual dialogue (English and Bengali). The visual language bridges technical clarity with calming ergonomics: deep structural teal conveys reliability and architectural rigor, while crisp mint and cyan accents provide sharp interactive feedback.

The aesthetic blends **Modern Corporate** structure with **Soft Tactile Workspace** cues. It avoids visual clutter, favoring disciplined planar surfaces, subtle tinted borders, and high-legibility typographic hierarchy. The emotional response is intentional, dependable, and serene—allowing high-volume chat streams, thread trees, and data-backed user workflows to feel organized and effortlessly scannable across long operational sessions.

## Colors

The palette balances authoritative deep jewel tones with crisp slate surfaces and luminous teal interactions:

- **Primary (`#006D77`)**: The grounding architectural color. Utilized for core navigation sidebars, persistent active tabs, primary action buttons, key thread headers, and high-priority brand indicators.
- **Secondary (`#14B8A6`)**: An electric, clarifying mint-cyan. Used strictly for real-time signaling: active user status indicators, unread message badges, focused inputs, transmission highlights, and interactive toggles.
- **Tertiary (`#0F766E`)**: A dense, grounded pine-teal used for secondary containers, sent chat bubble backdrops, subtle hover fills, and pressed states.
- **Neutral (`#64748B`)**: Slate neutral scale. Drives structural dividers, secondary metadata timestamps, thread counts, muted icons, and inactive control outlines.

### Surface System
- **App Canvas / Workspace Ground**: `#F8FAFC` (Slate-50), offering a glare-free, clinical canvas.
- **Surface Elevation 1 (Sidebar / Pane Panels)**: `#F1F5F9` (Slate-100), defining functional navigation perimeters.
- **Surface Elevation 2 (Active Cards / Chat Canvas)**: `#FFFFFF`, ensuring crisp contrast for incoming message bubbles and rich content payloads.
- **Border / Framing Rules**: `#E2E8F0` with subtle alpha transitions (`rgba(0, 109, 119, 0.08)`) to preserve clean segmentation without jarring contrast.

## Typography

Typography prioritizes dual-script legibility across complex messaging panes:
- **Headlines (`Manrope`)**: Provides geometric precision, robust counters, and structural anchoring for desktop navigation titles, user identifiers, and panel headers.
- **Body & Labels (`Hanken Grotesk`)**: Ensures clarity across high-density chat logs, code snippets, and bilingual script rendering (Latin and Bengali script fallbacks).

### Bilingual Typesetting Rules
When rendering Bengali alongside English:
1. Maintain consistent vertical metrics (`lineHeight: 1.45` to `1.5`) to accommodate complex Bengali vowel signs (Kar) and conjunct clusters without clipping.
2. Pair Bengali UI strings with equivalent visual weight: `Hanken Grotesk 500` matches standard Bengali UI font weights seamlessly.
3. Label elements, badge counts, and timestamp markers default to tabular numeral alignment to ensure uniform vertical stacking in chat lists.

## Layout & Spacing

The layout is architected around a multi-column desktop workstation layout:
- **Workspace Navigation Column (Left-fixed)**: 68px icon dock for system navigation.
- **Conversations & Threads List**: 320px fixed fluid drawer with `space-sm` item margins and `space-md` inner padding.
- **Active Stage / Chat Canvas**: Fluid column expanding to fill central real estate with a maximum content reading width of 880px to preserve line-length legibility.
- **Contextual Inspector / Meta Panel (Right-collapsible)**: 280px–340px adaptive pane for participants, shared documents, database state, and settings.

Spacing enforces an 8pt base grid with a 4pt sub-rhythm:
- Spacing within continuous message bubbles: `space-xs` (4px) to `space-sm` (8px).
- Spacing between different authors: `space-lg` (20px).
- Chat input and tool docks utilize `space-md` (12px) horizontal and vertical inner buffers.

## Elevation & Depth

Visual hierarchy uses low-elevation tonal layering paired with cool-toned ambient borders:

- **Level 0 (App Shell Ground)**: `#F8FAFC`. Zero elevation, non-reflective base plane.
- **Level 1 (Structural Panes & Toolbars)**: `#F1F5F9`. Separated by a 1px solid border in `#E2E8F0` or translucent teal `rgba(0, 109, 119, 0.08)`. No blur shadow required.
- **Level 2 (Chat Bubble & Message Row Hover)**: `#FFFFFF`. Low-contrast perimeter shadow: `0 1px 3px rgba(15, 118, 110, 0.05), 0 1px 2px rgba(0, 0, 0, 0.03)`.
- **Level 3 (Flyouts, Menus & Autocomplete Thread Modals)**: `#FFFFFF` surface raised with layered ambient elevation: `0 8px 24px -4px rgba(0, 109, 119, 0.12), 0 2px 6px -1px rgba(0, 0, 0, 0.04)`.
- **Outlines & Focus Rings**: Form elements and interactive targets express focus via a double ring: a 2px inner white gap followed by a 2px solid `#14B8A6` glow.

## Shapes

With `roundedness: 1`, the workspace utilizes a soft geometric language. Elements maintain disciplined edges that align with engineering workflows, softened just enough to feel approachable:

- **Standard Elements (Buttons, Inputs, List Items)**: `0.25rem` (4px).
- **Secondary Surfaces (Message Bubbles, Cards, Floating Palettes)**: `0.5rem` (8px).
- **Large Modals & App Drawers**: `0.75rem` (12px).
- **Specialized Real-time Status Badges & Avatar Containers**: Fully rounded circles (`9999px`) to contrast against rectangular panes and data streams.

## Components

### Buttons
- **Primary Action**: Background `#006D77`, text `#FFFFFF`, corner radius `0.25rem`. Hover shifts to `#0F766E`. Active state applies `scale(0.99)`.
- **Secondary Mint/Cyan Action**: Background `rgba(20, 184, 166, 0.12)`, text `#0F766E`, border `1px solid rgba(20, 184, 166, 0.3)`. Hover: background `rgba(20, 184, 166, 0.22)`.
- **Ghost / Tool Button**: Background transparent, text `#64748B`, corner radius `0.25rem`. Hover applies `#F1F5F9` and text `#006D77`.

### Message Bubbles
- **Sent Message (User)**: Background `#006D77`, text `#FFFFFF`. Metadata timestamps rendered in `rgba(255, 255, 255, 0.75)`. Top-right border radius reduced to `0.125rem` (2px) to denote speech origin.
- **Received Message**: Background `#FFFFFF`, text `#0F172A`, border `1px solid #E2E8F0`. Metadata rendered in `#64748B`. Top-left border radius reduced to `0.125rem` (2px).
- **System Event / Connection Pill**: Centered, background `#F1F5F9`, border `1px solid #E2E8F0`, text `#64748B`, `label-sm`, rounded `9999px`.

### Input Fields & Search Bars
- **Search Header**: Height 36px, background `#FFFFFF`, border `1px solid #E2E8F0`, text `body-md`. Left icon tinted `#64748B`. Focus border shifts to `#14B8A6`.
- **Composer Textarea**: Multi-line auto-expanding dock on `#FFFFFF`, padded `space-md`, with an integrated attachment bar at the footer. Border `1px solid #CBD5E1`. Focus: border `#006D77` with secondary mint ambient aura.

### Badges, Avatars & Chips
- **Presence Badge**: 10px circular indicator overlaid on user avatar: `#2DD4BF` for Online/Socket Active, `#94A3B8` for Offline, `#E2E8F0` border ring (2px).
- **Unread Counter**: Background `#14B8A6`, text `#042F2E`, `label-sm` font weight 700, padding `2px 6px`, pill-shaped (`9999px`).
- **Connection / Protocol Chips**: Background `rgba(0, 109, 119, 0.08)`, border `1px solid rgba(0, 109, 119, 0.2)`, text `#006D77`, height 24px, `label-sm`.

### Channel & Thread List Items
- **List Item Container**: Height 64px, padding `space-sm` `space-md`, radius `0.25rem`.
- **Active Selection**: Background `rgba(0, 109, 119, 0.08)` with a 3px left border accent in `#006D77`.
- **Hover State**: Background `#F8FAFC`.