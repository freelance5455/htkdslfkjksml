BAHRIDDIN CALC — 1.0.0

Bu papkada ishlaydigan, o‘zbek tilidagi mobilga mos PWA kalkulyator mavjud.

Ishga tushirish:
1) index.html faylini brauzerda oching. Ba’zi brauzerlarda offline o‘rnatish uchun HTTPS hosting kerak bo‘ladi.
2) Android APK/AAB qilish uchun ushbu papkani Android Studio/WebView wrapper yoki APKForge kabi HTML-to-APK vositasiga import qiling.
3) Play Market uchun keyin Android App Bundle (.aab), imzolash kaliti, maxfiylik siyosati va Play Console ma’lumotlari kerak bo‘ladi.

Eslatma:
- Valyuta kursi qo‘lda kiritiladi; jonli kurs API ulanmagan.
- Kredit hisoblagichi annuitet usulida taxminiy oylik to‘lovni hisoblaydi; bank komissiyalari/sug‘urta kiritilmagan.
- Asosiy hisoblar va tarix qurilmada ishlaydi; tarix localStorage'da saqlanadi.
