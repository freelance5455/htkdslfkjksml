Villa Manager Pro - Android WebView Project

This project wraps the existing Villa Manager Pro HTML app into an Android WebView app.
It includes the current calendar, bookings, local storage, backup/restore and Bulk Price Edit features.

To build an APK, open this folder in Android Studio with Android SDK installed and run:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

No GitHub is required.

Important: the current app uses local browser/app storage and demo login. It is not a secure server-backed production PMS.
