# Foodie Bitez Rider — موبائل ایپ (Android APK + iPhone)

یہ فولڈر آپ کی `demo.html` سے بنا ہے۔ ایپ کا کوڈ `www/index.html` میں ہے، یعنی وہی جو آپ نے بھیجا، اور اس میں صرف ایپ کے اندر چلنے والا ایک چھوٹا سا حصہ جوڑا گیا ہے (Android کا back بٹن، splash screen)۔ باقی ایپ کے کسی فنکشن کو نہیں چھیڑا۔

باقی فائلیں اس ایپ کو **Capacitor** کے ذریعے Android اور iPhone کی اصلی ایپ میں بدلتی ہیں۔

## فولڈر میں کیا ہے

| فائل / فولڈر | کام |
|---|---|
| `www/` | آپ کی ایپ (index.html، آئیکن، manifest) |
| `capacitor.config.json` | ایپ کا نام اور ID |
| `assets/` | آئیکن اور splash screen کی تصویریں (ان سے سارے سائز خود بن جاتے ہیں) |
| `scripts/` | Android/iPhone کی اجازتیں (لوکیشن، کیمرہ) خود لگانے والی اسکرپٹس |
| `.github/workflows/android.yml` | GitHub پر APK خود بنانے والا کام |
| `package.json` | ضروری پیکیجز کی فہرست |

---

## پہلے یہ دو چیزیں طے کریں

1. **ایپ کی ID:** `capacitor.config.json` میں `"appId": "com.foodiebitez.rider"` لکھا ہے۔ اگر آپ اپنے نام کی ID چاہتے ہیں (جیسے `com.aapkanaam.rider`) تو **پہلی بار بنانے سے پہلے** بدل لیں۔ Play Store یا App Store پر ڈالنے کے بعد ID بدلی نہیں جا سکتی۔
2. **رجسٹریشن:** ایپ کے اندر نئے رائیڈر کی رجسٹریشن (email لنک اور SMS reCAPTCHA) ایپ کے اندر قابلِ اعتماد نہیں چلتی، کیونکہ یہ ویب کے لیے بنی ہے۔ حل: اپنی ایپ کا ویب ورژن کسی ایڈریس پر چلا دیں، اور `www/index.html` میں `const WEB_URL=""` کے اندر وہ ایڈریس لکھ دیں۔ پھر ایپ کے اندر "Rider register karein" دبانے پر رجسٹریشن براؤزر میں کھلے گی۔ پہلے سے بنے رائیڈرز کا لاگ اِن ایپ کے اندر بالکل ٹھیک چلتا ہے۔

---

## طریقہ 1: APK بنانا — کمپیوٹر پر کچھ انسٹال کیے بغیر (GitHub سے)

یہ سب سے آسان طریقہ ہے۔

1. github.com پر مفت اکاؤنٹ بنائیں، پھر نیا **Private repository** بنائیں۔
2. اس فولڈر کی **ساری فائلیں** اس میں اپلوڈ کریں۔ `.github` نام کا چھپا ہوا فولڈر بھی لازمی اپلوڈ ہو۔ (کمپیوٹر پر Git ہو تو `git add . && git commit -m app && git push` سب سے محفوظ ہے۔)
3. GitHub میں **Actions** ٹیب کھولیں ← **Build Android (APK + AAB)** ← **Run workflow**۔
4. 8 سے 12 منٹ بعد کام مکمل ہو جائے گا۔ اس پر کلک کریں اور نیچے **Artifacts** میں `foodie-bitez-rider-debug-apk` ڈاؤن لوڈ کریں۔
5. ZIP کھولیں۔ اندر `app-debug.apk` ہے۔ اسے اپنے Android فون میں بھیجیں اور انسٹال کریں (فون کہے تو "Unknown sources / نامعلوم ذرائع" کی اجازت دیں)۔

یہ APK آپ کے اپنے موبائل اور اپنے رائیڈرز کے فونز پر انسٹال کرنے کے لیے ہے۔ **Play Store کے لیے** نیچے والا حصہ دیکھیں۔

## طریقہ 2: APK بنانا — اپنے کمپیوٹر پر

ضرورت: **Node.js 22** اور **Android Studio** (تازہ ورژن)۔

```bash
npm install
npm run android:add      # Android پروجیکٹ، اجازتیں اور آئیکن خود بنا دیتا ہے
npm run android:open     # Android Studio کھل جائے گا
```

Android Studio میں: **Build ← Build Bundle(s) / APK(s) ← Build APK(s)**۔

بعد میں `www/index.html` بدلیں تو صرف یہ چلائیں: `npm run android:sync`، پھر دوبارہ Build کریں۔

---

## Play Store پر ڈالنا

Play Store **APK نہیں، AAB فائل** مانگتا ہے اور وہ آپ کی اپنی signing key سے سائن ہونی چاہیے۔

### 1. اپنی signing key بنائیں (صرف ایک بار)

کمپیوٹر پر (Java انسٹال ہو):

```bash
keytool -genkeypair -v -keystore release.keystore -alias upload -keyalg RSA -keysize 2048 -validity 10000
```

اس فائل `release.keystore` اور اس کے پاس ورڈ کو **محفوظ جگہ پر کئی کاپیوں میں رکھیں**۔ کھو گئی تو ایپ اپڈیٹ کرنا مشکل ہو جاتا ہے۔ اسے GitHub پر اپلوڈ **نہ** کریں۔

### 2. GitHub میں 4 Secrets لگائیں

Repository ← **Settings ← Secrets and variables ← Actions ← New repository secret**:

| Secret کا نام | کیا لکھنا ہے |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | keystore فائل کا base64۔ Mac/Linux: `base64 -w0 release.keystore`۔ Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("release.keystore"))` |
| `ANDROID_KEYSTORE_PASSWORD` | keystore کا پاس ورڈ |
| `ANDROID_KEY_ALIAS` | `upload` |
| `ANDROID_KEY_PASSWORD` | key کا پاس ورڈ (عام طور پر وہی) |

### 3. دوبارہ Run workflow کریں

اب Artifacts میں `foodie-bitez-rider-release` بھی آئے گا۔ اس میں **`app-release.aab`** ہے، یہی Play Store پر جاتی ہے۔ ہر بار نیا ورژن خود بنتا ہے (`versionCode` GitHub کے run نمبر سے بڑھتا ہے)۔

### 4. Play Console

- play.google.com/console پر ڈیولپر اکاؤنٹ بنائیں (ایک بار کی فیس 25 ڈالر)۔
- نئی ایپ بنائیں، AAB اپلوڈ کریں۔ پہلے **Internal testing** میں رکھ کر اپنے فون پر آزمائیں، پھر Production میں بھیجیں۔
- ضروری چیزیں: **Privacy Policy کا لنک**، **Data safety فارم** (آپ کی ایپ لوکیشن، تصویریں، فون نمبر اور ای میل لیتی ہے، اس لیے سب کا ذکر کریں)، اسکرین شاٹس، 512×512 آئیکن اور 1024×500 کی feature graphic۔
- Google کی شرط: ایپ کا **target API 36** ہونا لازمی ہے (31 اگست 2026 سے)۔ اس پروجیکٹ میں Capacitor 8 ہے جو یہی target رکھتا ہے۔
- نئے ذاتی (personal) ڈیولپر اکاؤنٹس کے لیے Google کبھی کبھی "closed testing" کے چند ٹیسٹرز کی شرط رکھتا ہے۔ Play Console میں دیکھ لیں۔

---

## iPhone / App Store

iPhone کی ایپ **صرف Mac پر** بنتی ہے (Windows یا Linux پر نہیں)۔

ضرورت: Mac، **Xcode 26** یا نیا، Node.js 22، اور **Apple Developer اکاؤنٹ** (سالانہ 99 ڈالر)۔

```bash
npm install
npm run ios:add        # iOS پروجیکٹ، اجازتوں کے متن اور آئیکن خود لگا دیتا ہے
npm run ios:open       # Xcode کھل جائے گا
```

Xcode میں:

1. App ← **Signing & Capabilities** ← اپنی **Team** منتخب کریں۔
2. اوپر ڈیوائس میں **Any iOS Device** چنیں۔
3. **Product ← Archive** ← **Distribute App ← App Store Connect**۔
4. appstoreconnect.apple.com پر ایپ بنائیں، **TestFlight** میں آزمائیں، پھر Review کے لیے بھیجیں۔

**Apple Review کے لیے مشورہ:** Review notes میں لکھیں کہ ایپ کے لاگ اِن اسکرین پر **"Demo mode" بٹن** ہے جس سے ریویور بغیر اکاؤنٹ کے پوری ایپ آزما سکتا ہے۔ یہ آپ کی demo.html کی خوبی ہے اور ریویو میں بہت کام آتی ہے۔

---

## Firebase میں ایک چیز دیکھ لیں

ایپ آپ کے پرانے `sargodhafooddelivery` Firebase پروجیکٹ ہی پر چلتی ہے، اس لیے merchant ایپ کے ساتھ ویسے ہی کام کرے گی۔ ایپ کے اندر کی ویب ایڈریس `https://localhost` ہوتی ہے۔ اگر آپ کسی نئے لاگ اِن طریقے (فون OTP وغیرہ) کو ایپ کے اندر چلانا چاہیں تو Firebase Console ← Authentication ← Settings ← **Authorized domains** میں `localhost` بھی شامل کر دیں۔ عام email/password لاگ اِن کو اس کی ضرورت نہیں۔

---

## ایمانداری سے: کیا چیزیں ابھی ایسی ہیں اور کیا نہیں آزمایا گیا

- **میں نے APK یا iPhone کی ایپ بنا کر نہیں دیکھی۔** یہاں Android SDK اور انٹرنیٹ نہیں تھا۔ ایپ کا کوڈ (back بٹن، demo mode، کنفیگ اور patch اسکرپٹس) میں نے آزمایا ہے اور وہ ٹھیک چلا، لیکن پہلی بار GitHub پر بنانے میں کوئی چھوٹی غلطی آ سکتی ہے۔ آئے تو وہ لال ایرر کا متن بھیج دیں، میں ٹھیک کر دوں گا۔
- **پس منظر میں چلنا (Android):** رائیڈر جب Online ہو تو ایپ ایک مستقل نوٹیفکیشن کے ساتھ پس منظر میں چلتی رہتی ہے (foreground service)، یعنی رائیڈر Google Maps یا کوئی اور ایپ چلائے، تب بھی GPS اور آرڈر آتے رہتے ہیں۔ ایپ پیچھے ہو تو نئے آرڈر اور "order ready / late" کا الرٹ نوٹیفکیشن بن کر آتا ہے۔ یہ سب `scripts/patch-android.mjs` خود لگا دیتا ہے (`npm run android:add` یا `android:sync` پر)، کوئی نیا پیکیج نہیں چاہیے۔ پہلی بار Online ہونے پر ایپ پوچھتی ہے کہ فون کی battery سیٹنگ "Unrestricted" کریں۔ یہ ضرور کر لیں، ورنہ Xiaomi، Oppo، Vivo جیسے فون ایپ بند کر دیتے ہیں۔ **یہ میں نے اصلی فون پر آزمایا نہیں**، پہلے اپنے فون پر جانچ لیں۔ اگر رائیڈر ایپ کو خود بند (swipe/force stop) کر دے یا فون ایپ کو مار دے تو آرڈر کا الرٹ نہیں آئے گا۔ اس کے لیے سرور سے push notifications (FCM) الگ سے لگانی ہوں گی۔ iPhone پر یہ پس منظر والا حصہ ابھی نہیں لگا۔
- **انٹرنیٹ لازمی ہے۔** Firebase، نقشہ اور چہرے کی جانچ کی لائبریریاں انٹرنیٹ سے آتی ہیں۔ رائیڈر کی ایپ ویسے بھی آن لائن ہی چلتی ہے۔
- **رجسٹریشن** کے بارے میں اوپر لکھا ہے: ویب ایڈریس `WEB_URL` میں لگا دیں۔
- **npm کے ورژن:** میں نے انٹرنیٹ کی کمی کی وجہ سے پیکیجز کے ورژن خود جانچ نہیں سکا۔ `npm install` پر ورژن کا ایرر آئے تو `package.json` میں `@capacitor/app` اور `@capacitor/splash-screen` کے آگے `^8.0.0` کو `latest` کر دیں۔
