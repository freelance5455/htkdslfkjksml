// Run after "npx cap add ios" (npm run ios:add does it automatically).
// Adds the permission texts Apple requires (App Review rejects the app without them).
import fs from "node:fs";

const plist = "ios/App/App/Info.plist";
if (!fs.existsSync(plist)) {
  console.error("ios folder nahi mila. Pehle chalayein: npx cap add ios");
  process.exit(1);
}
let x = fs.readFileSync(plist, "utf8");
const keys = {
  NSLocationWhenInUseUsageDescription: "Foodie Bitez Rider uses your location to show nearby orders, navigate to the restaurant and customer, and confirm you have arrived.",
  NSCameraUsageDescription: "The camera is used for your profile verification and to take pickup / issue proof photos.",
  NSPhotoLibraryUsageDescription: "Photos are used to upload your documents and proof pictures.",
  ITSAppUsesNonExemptEncryption: false,
};
let add = "";
for (const [k, v] of Object.entries(keys)) {
  if (x.includes(`<key>${k}</key>`)) continue;
  add += `\t<key>${k}</key>\n\t` + (typeof v === "boolean" ? (v ? "<true/>" : "<false/>") : `<string>${v}</string>`) + "\n";
}
if (add) x = x.replace(/<\/dict>\s*<\/plist>/, add + "</dict>\n</plist>");
fs.writeFileSync(plist, x);
console.log("iOS patch done.");
