// Run after "npx cap add android" (npm run android:add does it automatically).
// Adds the permissions the rider app needs, sets version, and (optionally) release signing.
import fs from "node:fs";

const manifest = "android/app/src/main/AndroidManifest.xml";
const gradle = "android/app/build.gradle";
if (!fs.existsSync(manifest) || !fs.existsSync(gradle)) {
  console.error("android folder nahi mila. Pehle chalayein: npx cap add android");
  process.exit(1);
}

// ---- 1. Manifest: permissions (location for rider tracking, camera for photos / face check) ----
let x = fs.readFileSync(manifest, "utf8");
const perms = [
  "android.permission.INTERNET",
  "android.permission.ACCESS_FINE_LOCATION",
  "android.permission.ACCESS_COARSE_LOCATION",
  "android.permission.CAMERA",
  "android.permission.VIBRATE",
  "android.permission.WAKE_LOCK",
  "android.permission.MODIFY_AUDIO_SETTINGS",
  // background (dusri app chalate waqt bhi app chalti rahe)
  "android.permission.FOREGROUND_SERVICE",
  "android.permission.FOREGROUND_SERVICE_LOCATION",
  "android.permission.POST_NOTIFICATIONS",
];
let add = "";
for (const p of perms) if (!x.includes(`"${p}"`)) add += `    <uses-permission android:name="${p}" />\n`;
for (const f of ["android.hardware.camera", "android.hardware.location.gps"])
  if (!x.includes(`"${f}"`)) add += `    <uses-feature android:name="${f}" android:required="false" />\n`;
if (add) x = x.replace("</manifest>", add + "</manifest>");
fs.writeFileSync(manifest, x);

// ---- 1b. Background: foreground service + notification (rider dusri app chalaye tab bhi app chalti rahe) ----
{
  let m = fs.readFileSync(manifest, "utf8");
  if (!m.includes("RiderBgService")) {
    m = m.replace("</application>", `        <service android:name=".RiderBgService" android:exported="false" android:foregroundServiceType="location" />\n    </application>`);
    fs.writeFileSync(manifest, m);
  }
  const cfg = JSON.parse(fs.readFileSync("capacitor.config.json", "utf8"));
  const javaRoot = "android/app/src/main/java";
  let pkg = cfg.appId, dir = `${javaRoot}/${cfg.appId.replace(/\./g, "/")}`;
  const mainPath = `${dir}/MainActivity.java`;
  if (fs.existsSync(mainPath)) { const mm = /package\s+([\w.]+);/.exec(fs.readFileSync(mainPath, "utf8")); if (mm) pkg = mm[1]; }
  fs.mkdirSync(dir, { recursive: true });

  fs.writeFileSync(`${dir}/MainActivity.java`, `package ${pkg};

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

// rider-bg: JS ko "RiderBg" deta hai, aur background mein JavaScript ke timers ko chalta rakhta hai
public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try { getBridge().getWebView().addJavascriptInterface(new RiderBgApi(this), "RiderBg"); } catch (Exception e) { }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
        }
    }
    @Override
    public void onPause() {
        super.onPause();
        try { getBridge().getWebView().resumeTimers(); } catch (Exception e) { }
    }
    @Override
    public void onStop() {
        super.onStop();
        try { getBridge().getWebView().resumeTimers(); } catch (Exception e) { }
    }
}
`);

  fs.writeFileSync(`${dir}/RiderBgService.java`, `package ${pkg};

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

// Online rehte hue notification ke saath chalti hai, taake Android app ko band na kare aur GPS chalta rahe
public class RiderBgService extends Service {
    static final String CH = "rider_online";
    @Override public IBinder onBind(Intent i) { return null; }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            String t = intent != null && intent.getStringExtra("t") != null ? intent.getStringExtra("t") : "Foodie Bitez Rider";
            String x = intent != null && intent.getStringExtra("x") != null ? intent.getStringExtra("x") : "Aap online hain";
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH, "Online status", NotificationManager.IMPORTANCE_LOW));
            Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
            b.setContentTitle(t).setContentText(x).setSmallIcon(getApplicationInfo().icon).setContentIntent(pi).setOngoing(true);
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            else startForeground(1, b.build());
        } catch (Exception e) { stopSelf(); }
        return START_STICKY;
    }
}
`);

  fs.writeFileSync(`${dir}/RiderBgApi.java`, `package ${pkg};

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

// JavaScript se: RiderBg.start(title, text) / stop() / notify(title, text) / batteryOpt()
public class RiderBgApi {
    private final Context ctx;
    RiderBgApi(Context c) { ctx = c; }

    @JavascriptInterface
    public void start(String title, String text) {
        try {
            Intent i = new Intent(ctx, RiderBgService.class).putExtra("t", title).putExtra("x", text);
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
        } catch (Exception e) { }
    }
    @JavascriptInterface
    public void stop() { try { ctx.stopService(new Intent(ctx, RiderBgService.class)); } catch (Exception e) { } }

    @JavascriptInterface
    public void notify(String title, String text) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel("rider_alert", "Naye orders aur alerts", NotificationManager.IMPORTANCE_HIGH));
            Intent open = new Intent(ctx, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(ctx, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, "rider_alert") : new Notification.Builder(ctx);
            b.setContentTitle(title).setContentText(text).setSmallIcon(ctx.getApplicationInfo().icon).setContentIntent(pi).setAutoCancel(true);
            if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
            nm.notify(2, b.build());
        } catch (Exception e) { }
    }
    @JavascriptInterface
    public void batteryOpt() {
        try { ctx.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception e) { }
    }
}
`);
}

// ---- 2. build.gradle: version + optional signing ----
let g = fs.readFileSync(gradle, "utf8");
const vc = process.env.VERSION_CODE, vn = process.env.VERSION_NAME;
if (vc) g = g.replace(/versionCode\s+\d+/, `versionCode ${vc}`);
if (vn) g = g.replace(/versionName\s+"[^"]*"/, `versionName "${vn}"`);

if (process.env.KEYSTORE_PATH && process.env.KEYSTORE_PASSWORD && !g.includes("// rider-signing")) {
  const q = (s) => JSON.stringify(String(s));
  const block = `
    // rider-signing
    signingConfigs {
        release {
            storeFile file(${q(process.env.KEYSTORE_PATH)})
            storePassword ${q(process.env.KEYSTORE_PASSWORD)}
            keyAlias ${q(process.env.KEY_ALIAS || "upload")}
            keyPassword ${q(process.env.KEY_PASSWORD || process.env.KEYSTORE_PASSWORD)}
        }
    }
`;
  g = g.replace(/android\s*\{/, (m) => m + block);
  g = g.replace(/(buildTypes\s*\{\s*release\s*\{)/, "$1\n            signingConfig signingConfigs.release");
}
fs.writeFileSync(gradle, g);
console.log("Android patch done (background service included).");
