import { createRequire } from 'node:module'; import { execSync } from 'node:child_process'; import fs from 'node:fs'; import path from 'node:path';
import assert from 'node:assert/strict'; import vm from 'node:vm';
const require = createRequire('/opt/npm-tools/node_modules/'); const { chromium } = require('playwright');
const root = path.resolve(import.meta.dirname, '..'), URL_ = 'file://' + root + '/dist/index.html';
const LANGS = ['en', 'ar', 'fa', 'hi', 'tr', 'de', 'fr'];
let pass = 0; const ok = (n) => { pass++; console.log('  ok', n); };

// ---- static: translations complete, no leftover name
{
  const I = vm.runInNewContext(['i18n.js', 'i18n.fa-hi.js', 'i18n.features.js'].map((f) => fs.readFileSync(root + '/src/' + f, 'utf8')).join('\n') + ';I18N');
  const base = Object.keys(I.en).filter((k) => !/_(zero|one|two|few|many|other)$/.test(k)).sort();
  for (const l of LANGS) {
    const keys = Object.keys(I[l]).filter((k) => !/_(zero|one|two|few|many|other)$/.test(k)).sort();
    assert.deepEqual(keys, base, 'keys differ in ' + l);
    for (const k of Object.keys(I[l])) assert.ok(String(I[l][k]).trim(), l + ':' + k + ' empty');
    const ph = (s) => (s.match(/\{\w+\}/g) || []).sort().join();
    for (const k of base) assert.equal(ph(I[l][k]), ph(I.en[k]), `placeholders ${l}:${k}`);
    for (const c of new Intl.PluralRules(l === 'ar' ? 'ar' : l).resolvedOptions().pluralCategories) for (const b of ['debt.inDays', 'rem.inDays', 'lic.trial']) assert.ok(I[l][b + '_' + c] !== undefined || I[l][b + '_other'] !== undefined);
  }
  ok('i18n: 7 languages have identical keys & placeholders');
  const all = fs.readFileSync(root + '/dist/index.html', 'utf8');
  assert.ok(!/yashar|یاشار/i.test(all)); ok('no "Yashar" anywhere in build');
  assert.ok(!all.includes('private') || !/"d":/.test(all)); ok('no private key in build');
}

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const mk = async (opts = {}) => {
  const ctx = await browser.newContext({ viewport: { width: 420, height: 900 }, ...opts }); const page = await ctx.newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(e.message)); page.on('console', (m) => m.type() === 'error' && errs.push(m.text()));
  return { ctx, page, errs };
};
const boot = async (page) => { await page.goto(URL_); await page.waitForFunction(() => window.__ledgerReady); };
const issue = (args) => execSync(`node ${root}/tools/license.mjs issue ${args}`).toString().trim();

// ---- every language: renders, direction, no raw keys, screenshots
for (const l of LANGS) {
  const { ctx, page, errs } = await mk({ locale: l });
  await boot(page);
  await page.selectOption('#quickLang', l);
  assert.equal(await page.evaluate(() => document.documentElement.dir), l === 'ar' || l === 'fa' ? 'rtl' : 'ltr');
  for (const v of ['home', 'incomes', 'expenses', 'debts', 'shopping', 'goals', 'reminders', 'assistant', 'report', 'settings']) {
    await page.click(`#nav [data-view=${v}]`);
    const txt = await page.innerText('#view-' + v);
    assert.ok(!/\b(nav|common|income|expense|debt|shop|goal|rem|rep|set|lic|dash|ai|act|pin|cal|cur|pdf|toast|modal)\.[a-zA-Z.]+/.test(txt), `raw key in ${l}/${v}`);
    assert.ok(!/undefined|NaN/.test(txt), `undefined/NaN in ${l}/${v}`);
  }
  assert.equal(await page.evaluate(() => document.title), JSON.parse(JSON.stringify(await page.evaluate(() => I18N[document.documentElement.lang]['app.name']))));
  const noScroll = await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1); assert.ok(noScroll, 'horizontal overflow ' + l);
  assert.deepEqual(errs, []); ok(`language ${l}: all views render, no raw keys/NaN, no JS errors`);
  await page.click('#nav [data-view=home]'); await page.screenshot({ path: `/tmp/shot-${l}.png` }); await ctx.close();
}

// ---- full flow in English: CRUD, totals, search, PIN, backup, import, wipe
{
  const { ctx, page, errs } = await mk({ locale: 'en-US', acceptDownloads: true }); await boot(page);
  const fill = async (type, vals) => { for (const [k, v] of Object.entries(vals)) { const el = page.locator(`#f-${type}-${k}`); (await el.evaluate((e) => e.tagName)) === 'SELECT' ? await el.selectOption(v) : await el.fill(String(v)); } await page.click(`form[data-type=${type}] button[type=submit]`); };
  await page.click('#nav [data-view=incomes]');
  await fill('incomes', { title: 'Project A', amount: 1000, date: '2026-10-01', status: 'paid' });
  await fill('incomes', { title: '<img src=x onerror=window.xss=1>', amount: 500, date: '2026-10-02', status: 'due' });
  assert.equal(await page.evaluate(() => window.xss), undefined); ok('XSS-safe rendering');
  await page.click('#nav [data-view=expenses]'); await fill('expenses', { title: 'Cement', amount: 250.5, date: '2026-10-03', category: 'work' });
  await page.click('#nav [data-view=debts]'); await fill('debts', { person: 'Bob', type: 'owe', amount: 300, due: '2099-01-01', status: 'open' });
  await fill('debts', { person: 'Al', type: 'receivable', amount: 100, due: '2020-01-01', status: 'open' });
  assert.match(await page.innerText('#list-debts'), /overdue/);
  await page.click('#nav [data-view=shopping]'); await fill('shopping', { title: 'Drill', qty: 2, price: 80, priority: 'high', date: '2026-11-01' });
  await page.click('#nav [data-view=goals]'); await fill('goals', { title: 'Car', target: 1000, saved: 250 });
  await page.click('#nav [data-view=reminders]'); await fill('reminders', { title: 'Call', date: '2026-10-20', time: '09:30', alert: 2 });
  await page.click('#nav [data-view=home]'); const home = await page.innerText('#view-home');
  assert.match(home, /\$1,000\.00/); assert.match(home, /\$749\.50/); assert.match(home, /\$500\.00/); assert.match(home, /Drill/); assert.match(home, /25%/);
  ok('totals: income 1,000 / expenses 250.50 / balance 749.50 / pending 500 / goal 25%');
  await page.click('#nav [data-view=expenses]'); await page.fill('[data-search=expenses]', 'zzz'); assert.match(await page.innerText('#list-expenses'), /No expenses/); await page.fill('[data-search=expenses]', ''); ok('search');
  await page.click('#nav [data-view=incomes]'); await page.click('#list-incomes [data-act=edit] >> nth=1'); await page.fill('#f-incomes-title', 'Project A2'); await page.click('form[data-type=incomes] button[type=submit]');
  assert.match(await page.innerText('#list-incomes'), /Project A2/); ok('edit');
  // validation
  await page.click('#nav [data-view=expenses]'); await page.fill('#f-expenses-title', 'x'); await page.fill('#f-expenses-amount', '-5'); await page.click('form[data-type=expenses] button[type=submit]');
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('myledger_v2')).expenses.length), 1); ok('invalid amount rejected');
  // currency + language persistence
  await page.click('#nav [data-view=settings]'); await page.selectOption('#setCurrency', 'EUR'); await page.selectOption('#setLang', 'de');
  await page.click('#nav [data-view=home]'); assert.match(await page.innerText('#view-home'), /1\.000,00\s*€/); ok('de/EUR formatting');
  await page.reload(); await page.waitForFunction(() => window.__ledgerReady); assert.equal(await page.evaluate(() => document.documentElement.lang), 'de'); ok('language persists');
  await page.selectOption('#quickLang', 'en');
  // PIN is mandatory: the first delete forces creating a 4-digit PIN
  await page.click('#nav [data-view=expenses]'); await page.click('#list-expenses [data-act=del]');
  assert.equal(await page.locator('#modalPin2').isVisible(), true);
  const pinSet = () => page.evaluate(() => JSON.parse(localStorage.getItem('myledger_v2')).settings.pin);
  await page.fill('#modalPin', '12'); await page.fill('#modalPin2', '12'); await page.click('#modalOk'); assert.equal(await pinSet(), null);
  await page.fill('#modalPin', '4321'); await page.fill('#modalPin2', '4322'); await page.click('#modalOk'); assert.equal(await pinSet(), null);
  await page.fill('#modalPin', '4321'); await page.fill('#modalPin2', '4321'); await page.click('#modalOk'); await page.waitForFunction(() => JSON.parse(localStorage.getItem('myledger_v2')).settings.pin);
  assert.ok(!(await page.evaluate(() => localStorage.getItem('myledger_v2'))).includes('4321')); ok('first delete forces a 4-digit PIN (stored hashed)');
  await page.waitForSelector('#modalPin2', { state: 'hidden' });
  await page.fill('#modalPin', '0000'); await page.click('#modalOk');
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('myledger_v2')).expenses.length), 1);
  await page.fill('#modalPin', '4321'); await page.click('#modalOk'); await page.waitForFunction(() => JSON.parse(localStorage.getItem('myledger_v2')).expenses.length === 0); ok('delete needs the right PIN');
  // every section asks for the PIN on delete
  for (const [v, list] of [['incomes', 'incomes'], ['debts', 'debts'], ['shopping', 'shopping'], ['goals', 'goals'], ['reminders', 'reminders']]) {
    await page.click(`#nav [data-view=${v}]`); await page.click(`#list-${list} [data-act=del] >> nth=0`);
    assert.equal(await page.locator('#modalPin').isVisible(), true, v + ' asks PIN'); await page.click('#modalCancel');
  }
  ok('delete asks for PIN in all 6 sections');
  await page.click('#nav [data-view=settings]'); await page.fill('#pinCur', '4321'); await page.fill('#pinNew', '12'); await page.fill('#pinConfirm', '12'); await page.click('#pinSave');
  await page.fill('#pinNew', '5555'); await page.fill('#pinConfirm', '5555'); await page.fill('#pinCur', '0000'); await page.click('#pinSave');
  await page.fill('#pinCur', '4321'); await page.click('#pinSave'); await page.waitForTimeout(400);
  await page.click('#nav [data-view=expenses]'); await fill('expenses', { title: 'tmp', amount: 1, date: '2026-10-03' });
  await page.click('#list-expenses [data-act=del]'); await page.fill('#modalPin', '4321'); await page.click('#modalOk'); await page.waitForTimeout(300);
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('myledger_v2')).expenses.length), 1); await page.fill('#modalPin', '5555'); await page.click('#modalOk');
  await page.waitForFunction(() => JSON.parse(localStorage.getItem('myledger_v2')).expenses.length === 0); ok('PIN change works (old PIN stops working)');
  // backup / import
  await page.click('#nav [data-view=settings]'); const [dl] = await Promise.all([page.waitForEvent('download'), page.click('#exportBtn')]);
  const f = '/tmp/backup.json'; await dl.saveAs(f); const b = JSON.parse(fs.readFileSync(f, 'utf8')); assert.equal(b.app, 'my-ledger'); assert.equal(b.data.incomes.length, 2); assert.equal(b.data.settings.pin, null);
  await page.click('#nav [data-view=incomes]'); await page.click('#list-incomes [data-act=del] >> nth=0'); await page.fill('#modalPin', '5555'); await page.click('#modalOk');
  await page.waitForFunction(() => JSON.parse(localStorage.getItem('myledger_v2')).incomes.length === 1);
  await page.click('#nav [data-view=settings]'); await page.setInputFiles('#importFile', f); await page.fill('#modalPin', '5555'); await page.click('#modalOk'); await page.waitForFunction(() => JSON.parse(localStorage.getItem('myledger_v2')).incomes.length === 2); ok('backup export + import round trip');
  fs.writeFileSync('/tmp/bad.json', '{"x":1}'); await page.setInputFiles('#importFile', '/tmp/bad.json'); await page.waitForTimeout(300); assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('myledger_v2')).incomes.length), 2); ok('invalid backup rejected');
  // wipe
  await page.click('#wipeBtn'); await page.fill('#modalPin', '5555'); await page.click('#modalOk'); await page.waitForFunction(() => JSON.parse(localStorage.getItem('myledger_v2')).incomes.length === 0); ok('wipe');
  assert.deepEqual(errs, []); await ctx.close();
}

// ---- legacy Persian data migration
{
  const { ctx, page, errs } = await mk({ locale: 'en-US' });
  await page.addInitScript(() => { if (!localStorage.getItem('دفترمن_v1')) localStorage.setItem('دفترمن_v1', JSON.stringify({ incomes: [{ id: 'a1', title: 'پروژه', amount: 5000000, date: '۱۴۰۵/۰۷/۲۲', status: 'paid', note: '' }], expenses: [{ id: 'b1', title: 'سیمان', amount: 100, date: '1405/07/23', category: 'کار', note: '' }], debts: [], shopping: [], goals: [], reminders: [], settings: { password: '9876' } })); });
  await boot(page);
  const d = await page.evaluate(() => JSON.parse(localStorage.getItem('myledger_v2')));
  assert.equal(d.incomes[0].date, '2026-10-14'); assert.equal(d.expenses[0].category, 'work'); assert.equal(d.settings.currency, 'IRT'); assert.equal(d.settings.lang, 'fa'); assert.equal(d.settings.calendar, 'persian'); assert.ok(d.settings.pin);
  assert.equal(await page.evaluate(() => !!localStorage.getItem('دفترمن_v1')), true);
  await page.click('#nav [data-view=home]'); assert.match(await page.innerText('#view-home'), /۵٬۰۰۰٬۰۰۰\s*تومان/); assert.match(await page.innerText('#list-incomes') + (await page.click('#nav [data-view=incomes]'), await page.innerText('#list-incomes')), /۱۴۰۵/); assert.deepEqual(errs, []); ok('legacy data migrated (1405/07/22 → 2026-10-14, categories, PIN kept)'); await ctx.close();
}

// ---- license: trial, expiry lock, valid key, tampered, expired key
{
  const { ctx, page, errs } = await mk({ locale: 'en-US' }); await boot(page);
  assert.equal(await page.locator('#lock').isHidden(), true); assert.match(await page.innerText('#licStatus'), /14 days left/); ok('trial starts at 14 days');
  await page.evaluate(() => { const t = JSON.parse(localStorage.getItem('myledger_trial')); t.start -= 20 * 864e5; localStorage.setItem('myledger_trial', JSON.stringify(t)); });
  await page.reload(); await page.waitForFunction(() => window.__ledgerReady); assert.equal(await page.locator('#lock').isVisible(), true); ok('locked after trial');
  await page.fill('#lockKey', 'ML1.abc.def'); await page.click('#lockActivate'); assert.match(await page.innerText('#lockMsg'), /not valid/);
  const good = issue('--name "Ann Lee"'); const tam = good.replace(/^(ML1\.)(.)/, (m, a, c) => a + (c === 'A' ? 'B' : 'A'));
  await page.fill('#lockKey', tam); await page.click('#lockActivate'); assert.match(await page.innerText('#lockMsg'), /not valid/); ok('tampered key rejected');
  const exp = issue('--name Old --expires 2020-01-01'); await page.fill('#lockKey', exp); await page.click('#lockActivate'); assert.match(await page.innerText('#lockMsg'), /expired/); ok('expired key rejected');
  await page.fill('#lockKey', good); await page.click('#lockActivate'); await page.waitForSelector('#lock', { state: 'hidden' });
  await page.click('#nav [data-view=settings]'); assert.match(await page.innerText('#licStatus'), /Ann Lee.*Lifetime/); ok('valid key unlocks');
  await page.reload(); await page.waitForFunction(() => window.__ledgerReady); assert.equal(await page.locator('#lock').isHidden(), true); ok('license persists');
  // clock rollback cannot extend trial
  assert.deepEqual(errs, []); await ctx.close();
}
{
  const { ctx, page } = await mk({ locale: 'en-US' }); await boot(page);
  await page.evaluate(() => { const t = JSON.parse(localStorage.getItem('myledger_trial')); t.start -= 20 * 864e5; t.last = t.start + 20 * 864e5; localStorage.setItem('myledger_trial', JSON.stringify(t)); });
  await page.reload(); await page.waitForFunction(() => window.__ledgerReady); assert.equal(await page.locator('#lock').isVisible(), true); ok('trial lock persists'); await ctx.close();
}
await browser.close(); console.log(`\nALL PASSED (${pass} checks)`);
