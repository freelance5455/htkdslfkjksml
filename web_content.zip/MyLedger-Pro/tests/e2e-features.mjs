import { createRequire } from 'node:module'; import fs from 'node:fs'; import path from 'node:path'; import { execSync } from 'node:child_process'; import assert from 'node:assert/strict';
const require = createRequire('/opt/npm-tools/node_modules/'); const { chromium } = require('playwright');
const root = path.resolve(import.meta.dirname, '..'), URL_ = 'file://' + root + '/dist/index.html';
let pass = 0; const ok = (n) => { pass++; console.log('  ok', n); };
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const mk = async (opts = {}) => {
  const ctx = await browser.newContext({ viewport: { width: 420, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'], ...opts }); await ctx.addInitScript(() => { window.__ledgerTest = true; });
  const page = await ctx.newPage(); const errs = []; page.on('pageerror', (e) => errs.push(e.message)); page.on('console', (m) => m.type() === 'error' && errs.push(m.text()));
  await page.goto(URL_); await page.waitForFunction(() => window.__ledgerReady); return { ctx, page, errs };
};
const seed = (page) => page.evaluate(() => { localStorage.setItem('myledger_v2', JSON.stringify({ v: 2, incomes: [{ id: 'i1', title: 'Project A', amount: 1000, date: '2026-10-14', status: 'paid' }, { id: 'i2', title: 'Late client', amount: 400, date: '2026-10-01', status: 'due' }],
  expenses: [{ id: 'e1', title: 'Cement', amount: 300, date: '2026-10-10', category: 'work' }, { id: 'e2', title: 'Food', amount: 100, date: '2026-10-11', category: 'food' }],
  debts: [{ id: 'd1', person: 'Bob', type: 'owe', amount: 200, due: '2020-01-01', status: 'open', alert: 0 }], shopping: [{ id: 's1', title: 'Drill', qty: 1, price: 80, priority: 'high', date: '', status: 'todo' }],
  goals: [{ id: 'g1', title: 'Car', target: 1000, saved: 250, date: '' }], reminders: [{ id: 'r1', title: 'Call', date: '2099-01-01', time: '', alert: 0 }], settings: { lang: 'en' } })); });
const reload = async (page) => { await page.reload(); await page.waitForFunction(() => window.__ledgerReady); };
const view = (page, v) => page.click(`#nav [data-view=${v}]`);

// ---- countries & calendars
{
  const { ctx, page, errs } = await mk({ locale: 'en-US' }); await seed(page); await reload(page);
  await view(page, 'settings');
  await page.selectOption('#setCountry', 'IR');
  assert.equal(await page.inputValue('#setLang'), 'fa'); assert.equal(await page.inputValue('#setCurrency'), 'IRT'); assert.equal(await page.inputValue('#setCalendar'), 'persian'); assert.equal(await page.evaluate(() => document.documentElement.dir), 'rtl');
  await view(page, 'incomes'); const t1 = await page.innerText('#list-incomes'); assert.match(t1, /۱۴۰۵/); assert.match(t1, /۱٬۰۰۰\s*تومان/); ok('Iran → Persian language, toman, Solar Hijri dates (14 Oct 2026 = 22 Mehr 1405)');
  await page.fill('#f-incomes-date', '2026-10-14'); assert.match(await page.innerText('[data-hint=f-incomes-date]'), /۱۴۰۵/); ok('date picker shows a live Persian-calendar hint');
  await view(page, 'settings'); await page.selectOption('#setCountry', 'SA');
  assert.equal(await page.inputValue('#setLang'), 'ar'); assert.equal(await page.inputValue('#setCalendar'), 'islamic'); await view(page, 'incomes'); const t2 = await page.innerText('#list-incomes'); assert.match(t2, /1448/); assert.match(t2, /ر\.س/); ok('Saudi Arabia → Arabic, SAR, Umm al-Qura Hijri (year 1448)');
  await view(page, 'settings'); await page.check('#setDual'); await view(page, 'incomes'); assert.match(await page.innerText('#list-incomes'), /1448[^(]*\(.*2026/s); ok('"also show Gregorian" works');
  await view(page, 'settings'); await page.selectOption('#setCountry', 'DE'); await view(page, 'incomes'); assert.match(await page.innerText('#list-incomes'), /14\.10\.2026/); assert.match(await page.innerText('#list-incomes'), /€/); ok('Germany → German, EUR, Gregorian');
  await view(page, 'settings'); await page.selectOption('#setCountry', 'IN'); assert.equal(await page.inputValue('#setLang'), 'hi'); await view(page, 'incomes'); assert.match(await page.innerText('#list-incomes'), /₹/); ok('India → Hindi, INR');
  await page.selectOption('#quickLang', 'en'); await view(page, 'settings'); await page.selectOption('#setCalendar', 'islamic'); await view(page, 'home'); assert.ok(!(await page.innerText('#view-home')).includes('NaN'));
  assert.deepEqual(errs, []); await ctx.close();
}
{ // first-run detection by browser locale
  for (const [loc, lang, cur] of [['fa-IR', 'fa', 'IRT'], ['ar-SA', 'ar', 'SAR'], ['hi-IN', 'hi', 'INR'], ['tr-TR', 'tr', 'TRY'], ['fr-FR', 'fr', 'EUR'], ['ja-JP', 'en', 'USD']]) {
    const ctx = await browser.newContext({ locale: loc }); const page = await ctx.newPage(); await page.goto(URL_); await page.waitForFunction(() => window.__ledgerReady);
    assert.equal(await page.evaluate(() => document.documentElement.lang), lang); await view(page, 'settings'); assert.equal(await page.inputValue('#setCurrency'), cur); await ctx.close();
  }
  ok('first run: language/country/currency auto-detected from the browser');
}

// ---- copy & PDF for every section
{
  const { ctx, page, errs } = await mk({ locale: 'en-US' }); await seed(page); await reload(page);
  const clip = () => page.evaluate(() => navigator.clipboard.readText());
  for (const v of ['home', 'incomes', 'expenses', 'debts', 'shopping', 'goals', 'reminders', 'report']) {
    await view(page, v); await page.click(`#view-${v} [data-act=copysec]`); await page.waitForTimeout(150); const txt = await clip();
    assert.ok(txt.startsWith('My Ledger'), v + ' header'); assert.ok(txt.length > 40, v + ' has content');
    await page.click(`#view-${v} [data-act=pdf]`); const html = await page.evaluate(() => window.__lastPrint); assert.match(html, /<img src="data:image\/png/); assert.match(html, /<table/);
    await page.evaluate(() => { window.__lastPrint = null; });
  }
  await view(page, 'incomes'); await page.click('#view-incomes [data-act=copysec]'); await page.waitForTimeout(150); const t = await clip(); assert.match(t, /Project A/); assert.match(t, /Total: |Total \|/); assert.match(t, /\$1,400\.00/);
  await view(page, 'assistant'); await page.click('[data-intent=summary]'); await page.click('#view-assistant [data-act=copysec]'); await page.waitForTimeout(150); assert.match(await clip(), /Balance/);
  ok('Copy works in all sections (incl. totals)');
  await view(page, 'incomes'); await page.click('#view-incomes [data-act=pdf]'); const html = await page.evaluate(() => window.__lastPrint);
  const p2 = await ctx.newPage(); await p2.setContent(html); await p2.pdf({ path: '/tmp/section.pdf', format: 'A4' });
  const buf = fs.readFileSync('/tmp/section.pdf'); assert.equal(buf.subarray(0, 5).toString(), '%PDF-'); assert.ok(buf.length > 8000);
  try { const txt = execSync('pdftotext /tmp/section.pdf -').toString(); assert.match(txt, /Project A/); assert.match(txt, /My Ledger/); ok('PDF renders with logo + table + data (checked with pdftotext)'); } catch (e) { if (/ENOENT|not found/.test(String(e))) ok('PDF renders (pdftotext unavailable)'); else throw e; }
  await p2.close();
  for (const l of ['ar', 'fa', 'hi']) { await page.selectOption('#quickLang', l); await view(page, 'incomes'); await page.click('#view-incomes [data-act=pdf]'); const h = await page.evaluate(() => window.__lastPrint); assert.match(h, l === 'hi' ? /dir="ltr"/ : /dir="rtl"/); assert.match(h, new RegExp(`lang="${l}"`)); }
  ok('PDF documents carry correct language/direction (ar, fa RTL; hi LTR)');
  assert.deepEqual(errs, []); await ctx.close();
}

// ---- forgot PIN → reset with license key; assistant offline + online(mock)
{
  const { ctx, page, errs } = await mk({ locale: 'en-US' }); await seed(page); await reload(page);
  await view(page, 'incomes'); await page.click('#list-incomes [data-act=del] >> nth=0'); await page.fill('#modalPin', '1111'); await page.fill('#modalPin2', '1111'); await page.click('#modalOk'); await page.waitForSelector('#modalPin2', { state: 'hidden' });
  await page.click('#modalForgot'); await page.fill('#modalKey', 'ML1.bad.key'); await page.click('#modalReset'); assert.equal(await page.locator('#modal').isVisible(), true);
  const key = execSync(`node ${root}/tools/license.mjs issue --name Tester`).toString().trim(); await page.fill('#modalKey', key); await page.click('#modalReset'); await page.waitForSelector('#modal', { state: 'hidden' });
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('myledger_v2')).settings.pin), null); assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('myledger_v2')).incomes.length), 2); ok('forgot PIN: reset only with a valid license key (nothing deleted)');
  await view(page, 'assistant');
  await page.click('[data-intent=summary]'); let log = await page.innerText('#aiLog'); assert.match(log, /Balance: \$600\.00/); assert.match(log, /Pending income: \$400\.00/);
  await page.click('[data-intent=overdue]'); assert.match(await page.innerText('#aiLog'), /Overdue: Bob/);
  await page.click('[data-intent=spending]'); assert.match(await page.innerText('#aiLog'), /Work \$300\.00 \(75%\)/);
  await page.click('[data-intent=goals]'); assert.match(await page.innerText('#aiLog'), /Car 25%/);
  await page.click('[data-intent=shopping]'); assert.match(await page.innerText('#aiLog'), /Drill/);
  await page.click('[data-intent=advice]'); assert.match(await page.innerText('#aiLog'), /pending|owe/i);
  await page.fill('#aiInput', 'what is my total balance?'); await page.press('#aiInput', 'Enter'); await page.waitForTimeout(200); assert.ok((await page.innerText('#aiLog')).split('Balance: $600.00').length >= 3);
  await page.fill('#aiInput', 'blah blah'); await page.press('#aiInput', 'Enter'); assert.match(await page.innerText('#aiLog'), /I can help with/); ok('assistant offline: 6 intents + typed questions + fallback, numbers match the data');
  // online mode with a mocked Anthropic endpoint
  let seen = null; await page.route('https://api.anthropic.com/v1/messages', async (r) => { seen = { h: r.request().headers(), b: JSON.parse(r.request().postData()) }; if (seen.b.messages[0].content.includes('FAIL')) return r.fulfill({ status: 500, headers: { 'access-control-allow-origin': '*' }, body: '{}' }); r.fulfill({ status: 200, headers: { 'access-control-allow-origin': '*', 'content-type': 'application/json' }, body: JSON.stringify({ content: [{ type: 'text', text: 'Mock online answer' }] }) }); });
  await page.click('summary'); await page.check('#aiEnable'); await page.fill('#aiKey', 'sk-test-123'); await page.dispatchEvent('#aiKey', 'change');
  assert.equal(await page.innerText('#aiBadge'), 'Online AI');
  await page.fill('#aiInput', 'Should I buy a drill?'); await page.press('#aiInput', 'Enter'); await page.waitForFunction(() => document.getElementById('aiLog').innerText.includes('Mock online answer'));
  assert.equal(seen.h['x-api-key'], 'sk-test-123'); assert.equal(seen.b.model, 'claude-sonnet-5-5'); assert.ok(seen.b.messages[0].content.includes('Project A')); assert.ok(!(await page.evaluate(() => localStorage.getItem('myledger_v2'))).includes('sk-test'));
  await page.fill('#aiInput', 'FAIL please'); await page.press('#aiInput', 'Enter'); await page.waitForTimeout(500); assert.match(await page.innerText('#aiLog'), /I can help with/);
  await page.click('[data-intent=summary]'); assert.equal(seen.b.messages[0].content.includes('FAIL') ? 1 : 0, 1);   // chips stay offline (no new request body)
  ok('assistant online: request shape, key not in backup data, fallback to offline on HTTP error');
  assert.deepEqual(errs.filter((e) => !/500|Failed to load resource/.test(e)), []); await ctx.close();
}

// ---- assistant works in every language
for (const l of ['en', 'ar', 'fa', 'hi', 'tr', 'de', 'fr']) {
  const { ctx, page, errs } = await mk({ locale: l }); await seed(page); await reload(page); await page.selectOption('#quickLang', l); await view(page, 'assistant');
  for (const i of ['summary', 'overdue', 'spending', 'goals', 'shopping', 'advice']) await page.click(`[data-intent=${i}]`);
  const txt = await page.innerText('#aiLog'); assert.ok(!/undefined|NaN|\{\w+\}/.test(txt), 'placeholders left in ' + l + ': ' + txt);
  await page.fill('#aiInput', await page.evaluate(() => I18N[document.documentElement.lang]['ai.kw.summary'].split(',')[0])); await page.press('#aiInput', 'Enter');
  assert.ok(!(await page.innerText('#aiLog')).trimEnd().endsWith(await page.evaluate(() => I18N[document.documentElement.lang]['ai.a.fallback'])), 'keyword not matched in ' + l);
  assert.deepEqual(errs, []); await ctx.close();
}
ok('assistant answers + keyword matching verified in all 7 languages');

// ---- seller License Maker produces keys the app accepts
{
  const { ctx, page } = await mk({ locale: 'en-US' }); await page.evaluate(() => { const t = JSON.parse(localStorage.getItem('myledger_trial') || 'null'); if (t) { t.start -= 30 * 864e5; localStorage.setItem('myledger_trial', JSON.stringify(t)); } }); await reload(page);
  const m = await ctx.newPage(); await m.goto('file://' + root + '/seller-only/License-Maker.html'); await m.fill('#name', 'Maker Test'); await m.fill('#exp', '2099-12-31'); await m.click('#go'); await m.waitForFunction(() => document.getElementById('out').value.startsWith('ML1.'));
  const key = await m.inputValue('#out'); assert.equal(await page.locator('#lock').isVisible(), true);
  await page.fill('#lockKey', key); await page.click('#lockActivate'); await page.waitForSelector('#lock', { state: 'hidden' }); await view(page, 'settings'); assert.match(await page.innerText('#licStatus'), /Maker Test.*2099|Maker Test.*Dec/s);
  assert.equal(execSync(`node ${root}/tools/license.mjs verify "${key}"`).toString().startsWith('VALID'), true); ok('License-Maker.html keys are accepted by the app (and by the CLI)'); await ctx.close();
}
await browser.close(); console.log(`\nFEATURES PASSED (${pass} checks)`);
