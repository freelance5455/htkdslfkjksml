// Section-level paywall: builds a variant with paid sections, tests it, then restores the normal build.
import { createRequire } from 'node:module'; import fs from 'node:fs'; import path from 'node:path'; import { execSync } from 'node:child_process'; import assert from 'node:assert/strict';
const require = createRequire('/opt/npm-tools/node_modules/'); const { chromium } = require('playwright');
const root = path.resolve(import.meta.dirname, '..'), cfg = root + '/build.config.json', orig = fs.readFileSync(cfg, 'utf8');
const issue = (a) => execSync(`node ${root}/tools/license.mjs issue ${a}`).toString().trim();
try {
  fs.writeFileSync(cfg, JSON.stringify({ trialDays: 14, paidViews: ['assistant', 'report', 'settings', 'home'], lockAfterTrial: false })); execSync(`node ${root}/tools/build.mjs`);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }), ctx = await b.newContext({ locale: 'en-US' }), page = await ctx.newPage(); const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.goto('file://' + root + '/dist/index.html'); await page.waitForFunction(() => window.__ledgerReady);
  const view = (v) => page.click(`#nav [data-view=${v}]`), shown = () => page.evaluate(() => document.querySelector('.view.active').id);
  await view('assistant'); assert.equal(await shown(), 'view-assistant'); console.log('  ok trial: paid sections open');
  await page.evaluate(() => { const t = JSON.parse(localStorage.getItem('myledger_trial')); t.start -= 30 * 864e5; localStorage.setItem('myledger_trial', JSON.stringify(t)); }); await page.reload(); await page.waitForFunction(() => window.__ledgerReady);
  assert.equal(await page.locator('#lock').isHidden(), true); await view('assistant'); assert.equal(await shown(), 'view-locked'); await view('report'); assert.equal(await shown(), 'view-locked');
  await view('incomes'); assert.equal(await shown(), 'view-incomes'); await view('settings'); assert.equal(await shown(), 'view-settings'); await view('home'); assert.equal(await shown(), 'view-home');
  assert.equal(await page.locator('#nav [data-view=assistant].locked').count(), 1); assert.match(await page.innerText('#licStatus'), /Free edition/); console.log('  ok free edition: paid sections locked, free ones + settings/home open');
  await view('settings'); await page.fill('#licKey', issue('--name Partial --sections report,incomes')); await page.click('#licActivate'); await page.waitForTimeout(400);
  await view('report'); assert.equal(await shown(), 'view-report'); await view('assistant'); assert.equal(await shown(), 'view-locked'); console.log('  ok key limited to "report": report opens, assistant stays locked');
  await view('settings'); await page.fill('#licKey', issue('--name Full')); await page.click('#licActivate'); await page.waitForTimeout(400); await view('assistant'); assert.equal(await shown(), 'view-assistant'); assert.equal(await page.locator('#nav .locked').count(), 0); console.log('  ok key without section list: everything opens');
  assert.deepEqual(errs, []); await b.close();
} finally { fs.writeFileSync(cfg, orig); execSync(`node ${root}/tools/build.mjs`); }
console.log('PAID-SECTIONS PASSED');
