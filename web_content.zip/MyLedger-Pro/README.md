# My Ledger Pro — 7 languages (en · ar · fa · hi · tr · de · fr)

**To use:** open `index.html` (single offline file; works from a folder, a USB stick or any web host with https). Data stays on the device.

## Features
- Income, expenses, debts/receivables, shopping, goals, reminders, dashboard, report.
- Country picker → language + currency + calendar set automatically (Gregorian, Hijri Umm al-Qura, Persian Solar Hijri; optional dual dates).
- Copy (text) and PDF (print → "Save as PDF") from every section.
- AI assistant: offline analysis of your data; optional online mode with your own Anthropic API key.
- Mandatory 4-digit PIN for every delete / import / erase (stored as PBKDF2 hash; reset only with a valid license key).
- Backup export/import; automatic import of the old Persian edition's data.
- Paid edition: 14-day trial, then a signed license key is required.

## Selling
Open `SELLER-ONLY/License-Maker.html` (double-click) → customer name, optional expiry → copy the key and send it to the customer.
`SELLER-ONLY/` contains your private key: never ship it. To show your contact on the lock screen edit `build.config.json` and run `node tools/build.mjs`.
Limit: the license check is client-side; a determined developer could bypass it.

## Develop
`node tools/build.mjs` → dist/index.html · `node tests/e2e.mjs && node tests/e2e-features.mjs` (Playwright + Chromium).
Translations: `src/i18n*.js` (machine-drafted — have native speakers review before selling).

## Making some sections paid later
Edit `build.config.json`, then `node tools/build.mjs`:
`{"contact":"you@x.com","trialDays":14,"paidViews":["assistant","report"],"lockAfterTrial":false}`
- `paidViews`: sections that need a license (ids: incomes, expenses, debts, shopping, goals, reminders, assistant, report). Empty = everything is covered by the one license/trial.
- `lockAfterTrial:false`: after the trial the free sections stay usable (free edition); `true` locks the whole app.
- Keys made in License-Maker with all sections ticked open every section, so keys sold now keep working when you add paid sections later. Untick sections to sell partial licenses.
