(() => {
'use strict';
/* ============ constants ============ */
const KEY = 'myledger_v2', OLD_KEY = 'دفترمن_v1', LIC_KEY = 'myledger_license', TRIAL_KEY = 'myledger_trial';
const TRIAL_DAYS = Number(CONFIG.trialDays) || 14;
const PAID_VIEWS = (Array.isArray(CONFIG.paidViews) ? CONFIG.paidViews : []).filter((v) => v !== 'settings' && v !== 'home');   // sections sold separately (see build.config.json)
const LANGS = ['en', 'ar', 'fa', 'hi', 'tr', 'de', 'fr'];
const BASE_LOCALE = { en: 'en-US', ar: 'ar', fa: 'fa-IR', hi: 'hi-IN', tr: 'tr-TR', de: 'de-DE', fr: 'fr-FR' };
const CURRENCIES = ['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'CHF', 'TRY', 'AED', 'SAR', 'EGP', 'IQD', 'KWD', 'QAR', 'JOD', 'INR', 'AFN', 'IRT', 'none'];
const CALENDARS = ['gregory', 'islamic', 'persian'];
const INTL_CAL = { gregory: 'gregory', islamic: 'islamic-umalqura', persian: 'persian' };
/* country -> [language, currency, calendar] */
const COUNTRIES = {
  US: ['en', 'USD', 'gregory'], GB: ['en', 'GBP', 'gregory'], CA: ['en', 'CAD', 'gregory'], AU: ['en', 'AUD', 'gregory'],
  DE: ['de', 'EUR', 'gregory'], AT: ['de', 'EUR', 'gregory'], CH: ['de', 'CHF', 'gregory'], FR: ['fr', 'EUR', 'gregory'], BE: ['fr', 'EUR', 'gregory'],
  TR: ['tr', 'TRY', 'gregory'], SA: ['ar', 'SAR', 'islamic'], AE: ['ar', 'AED', 'gregory'], EG: ['ar', 'EGP', 'gregory'], IQ: ['ar', 'IQD', 'gregory'],
  KW: ['ar', 'KWD', 'gregory'], QA: ['ar', 'QAR', 'gregory'], JO: ['ar', 'JOD', 'gregory'], IR: ['fa', 'IRT', 'persian'], AF: ['fa', 'AFN', 'persian'], IN: ['hi', 'INR', 'gregory']
};
const LANG_COUNTRY = { en: 'US', ar: 'SA', fa: 'IR', hi: 'IN', tr: 'TR', de: 'DE', fr: 'FR' };
const CATS = ['home', 'food', 'car', 'work', 'school', 'health', 'shopping', 'bills', 'other'];
const LEGACY_CATS = { 'خانه': 'home', 'خوراک': 'food', 'خودرو': 'car', 'کار': 'work', 'مدرسه': 'school', 'درمان': 'health', 'خرید': 'shopping', 'قبض': 'bills', 'سایر': 'other' };
const TYPES = ['incomes', 'expenses', 'debts', 'shopping', 'goals', 'reminders'];
const AI_KEY = 'myledger_ai';

/* ============ tiny helpers ============ */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const store = {
  ok: true,
  get(k) { try { return localStorage.getItem(k); } catch { this.ok = false; return null; } },
  set(k, v) { try { localStorage.setItem(k, v); return true; } catch { this.ok = false; return false; } },
  del(k) { try { localStorage.removeItem(k); } catch { this.ok = false; } }
};

/* ============ dates (ISO yyyy-mm-dd, calendar-only, no time zones) ============ */
const pad = (n) => String(n).padStart(2, '0');
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
function validISO(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
  if (!m) return false;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3];
}
const dayNum = (iso) => { const [y, m, d] = iso.split('-').map(Number); return Date.UTC(y, m - 1, d) / 864e5; };
const daysUntil = (iso) => (validISO(iso) ? Math.round(dayNum(iso) - dayNum(todayISO())) : null);

/* Legacy (Persian-calendar) conversion, only used to import data from the old Persian edition. */
function jalaliToGregorian(jy, jm, jd) {
  let gy; if (jy > 979) { gy = 1600; jy -= 979; } else { gy = 621; }
  let days = 365 * jy + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + 78 + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
  gy += 400 * Math.floor(days / 146097); days %= 146097;
  if (days > 36524) { gy += 100 * Math.floor(--days / 36524); days %= 36524; if (days >= 365) days++; }
  gy += 4 * Math.floor(days / 1461); days %= 1461;
  if (days > 365) { gy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
  let gd = days + 1; const sal = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) sal[2] = 29;
  let gm = 1; while (gd > sal[gm]) { gd -= sal[gm]; gm++; }
  return [gy, gm, gd];
}
const westernDigits = (s) => String(s ?? '').replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[०-९]/g, (d) => '०१२३४५६७८९'.indexOf(d));
function anyDateToISO(s) {
  s = westernDigits(s).trim();
  if (validISO(s)) return s;
  const m = /^(\d{4})[\/.-](\d{1,2})[\/.-](\d{1,2})$/.exec(s);
  if (!m) return '';
  let [y, mo, d] = [+m[1], +m[2], +m[3]];
  if (y < 1700) { if (y < 1200 || mo < 1 || mo > 12 || d < 1 || d > 31) return ''; [y, mo, d] = jalaliToGregorian(y, mo, d); }
  const iso = `${y}-${pad(mo)}-${pad(d)}`;
  return validISO(iso) ? iso : '';
}

/* ============ data model ============ */
const STATUS = {
  incomes: ['paid', 'partial', 'due'], debts: ['open', 'partial', 'paid'], shopping: ['todo', 'bought']
};
const blank = () => ({ v: 2, incomes: [], expenses: [], debts: [], shopping: [], goals: [], reminders: [], settings: { lang: null, country: null, currency: null, calendar: null, dual: false, pin: null, notified: {} } });
const S = (x, max = 300) => String(x ?? '').slice(0, max);
const N = (x) => { const n = Number(westernDigits(x)); return Number.isFinite(n) ? n : 0; };
const pick = (x, list, d) => (list.includes(x) ? x : d);
const D = (x) => anyDateToISO(x);
const T = (x) => (/^([01]\d|2[0-3]):[0-5]\d$/.test(String(x || '')) ? x : '');
const A = (x) => Math.min(365, Math.max(0, Math.floor(N(x))));
const ID = (x) => (/^[\w-]{1,40}$/.test(String(x || '')) ? String(x) : uid());
const CLEAN = {
  incomes: (o) => ({ id: ID(o.id), title: S(o.title, 120), amount: N(o.amount), date: D(o.date), status: pick(o.status, STATUS.incomes, 'due'), note: S(o.note, 500) }),
  expenses: (o) => ({ id: ID(o.id), title: S(o.title, 120), amount: N(o.amount), date: D(o.date), category: pick(CATS.includes(o.category) ? o.category : LEGACY_CATS[o.category], CATS, 'other'), note: S(o.note, 500) }),
  debts: (o) => ({ id: ID(o.id), person: S(o.person, 120), type: pick(o.type, ['owe', 'receivable'], 'owe'), amount: N(o.amount), due: D(o.due), status: pick(o.status, STATUS.debts, 'open'), alert: A(o.alert), note: S(o.note, 500) }),
  shopping: (o) => ({ id: ID(o.id), title: S(o.title, 120), qty: Math.max(1, Math.floor(N(o.qty)) || 1), price: N(o.price), priority: pick(o.priority, ['high', 'med', 'low'], 'low'), date: D(o.date), status: pick(o.status, STATUS.shopping, 'todo'), note: S(o.note, 500) }),
  goals: (o) => ({ id: ID(o.id), title: S(o.title, 120), target: N(o.target), saved: N(o.saved), date: D(o.date), note: S(o.note, 500) }),
  reminders: (o) => ({ id: ID(o.id), title: S(o.title, 120), date: D(o.date), time: T(o.time), alert: A(o.alert), note: S(o.note, 500) })
};
function sanitize(src) {
  const out = blank();
  if (!src || typeof src !== 'object') return out;
  for (const t of TYPES) if (Array.isArray(src[t])) out[t] = src[t].filter((o) => o && typeof o === 'object').slice(0, 20000).map(CLEAN[t]);
  const s = src.settings && typeof src.settings === 'object' ? src.settings : {};
  out.settings.lang = LANGS.includes(s.lang) ? s.lang : null;
  out.settings.currency = CURRENCIES.includes(s.currency) ? s.currency : null;
  out.settings.country = COUNTRIES[s.country] ? s.country : null;
  out.settings.calendar = CALENDARS.includes(s.calendar) ? s.calendar : null;
  out.settings.dual = s.dual === true;
  const p = s.pin;
  out.settings.pin = p && typeof p.salt === 'string' && typeof p.hash === 'string' && Number.isInteger(p.iter) ? { salt: p.salt, hash: p.hash, iter: p.iter } : null;
  out.settings.notified = s.notified && typeof s.notified === 'object' ? s.notified : {};
  return out;
}

let db = blank();
let lang = 'en';
let lic = { state: 'trial', daysLeft: TRIAL_DAYS, payload: null };

function persist() {
  if (store.set(KEY, JSON.stringify(db))) return true;
  toast(store.ok ? 'toast.storageFail' : 'toast.storageOff'); return false;
}

/* ============ i18n ============ */
function t(key, vars) {
  let s = (I18N[lang] && I18N[lang][key]) ?? I18N.en[key] ?? key;
  if (vars) s = s.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? vars[k] : m));
  return s;
}
function tp(base, n, vars) {
  const cat = new Intl.PluralRules(BASE_LOCALE[lang]).select(n);
  const key = I18N[lang][`${base}_${cat}`] !== undefined ? `${base}_${cat}` : `${base}_other`;
  return t(key, { n: nf().format(n), ...(vars || {}) });
}
const numLoc = () => BASE_LOCALE[lang] + (lang === 'ar' ? '-u-nu-latn' : '');
const nf = () => new Intl.NumberFormat(numLoc(), { maximumFractionDigits: 2 });
const country = () => db.settings.country || LANG_COUNTRY[lang];
const currencyCode = () => db.settings.currency || COUNTRIES[country()][1];
const calendarId = () => db.settings.calendar || COUNTRIES[country()][2];
function money(n) {
  const c = currencyCode(); n = Number(n) || 0;
  if (c === 'none') return nf().format(n);
  if (c === 'IRT') return `${nf().format(n)} ${t('cur.IRT')}`;
  return new Intl.NumberFormat(numLoc(), { style: 'currency', currency: c, maximumFractionDigits: c === 'IQD' || c === 'KWD' ? 3 : 2 }).format(n);
}
function dateIn(iso, cal) {
  const ext = ['ca-' + INTL_CAL[cal]]; if (lang === 'ar') ext.push('nu-latn');
  return new Intl.DateTimeFormat(`${BASE_LOCALE[lang]}-u-${ext.join('-')}`, { dateStyle: 'medium', timeZone: 'UTC' }).format(new Date(iso + 'T00:00:00Z'));
}
function fmtDate(iso) {
  if (!validISO(iso)) return '';
  const cal = calendarId(), main = dateIn(iso, cal);
  return db.settings.dual && cal !== 'gregory' ? `${main} (${dateIn(iso, 'gregory')})` : main;
}
function detectLang() { return detectLocale().lang; }
function detectLocale() {
  for (const l of navigator.languages || [navigator.language || 'en']) {
    const [b, reg] = String(l).replace('_', '-').split('-'), r = (reg || '').toUpperCase(), base = b.toLowerCase();
    if (COUNTRIES[r] && (LANGS.includes(base))) return { lang: base, country: r };
    if (COUNTRIES[r]) return { lang: COUNTRIES[r][0], country: r };
    if (LANGS.includes(base)) return { lang: base, country: LANG_COUNTRY[base] };
  }
  return { lang: 'en', country: 'US' };
}
function applyI18n(root = document) {
  root.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  root.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
}
function setLang(l, remember = true) {
  lang = LANGS.includes(l) ? l : 'en';
  const el = document.documentElement;
  el.lang = lang; el.dir = lang === 'ar' || lang === 'fa' ? 'rtl' : 'ltr';
  document.title = t('app.name');
  if (remember) { db.settings.lang = lang; persist(); }
  fillSelects(); applyI18n(); renderAll();
}

/* ============ toast & modal ============ */
let toastTimer;
function toast(keyOrText) {
  const el = $('toast'); el.textContent = I18N.en[keyOrText] !== undefined ? t(keyOrText) : keyOrText;
  el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}
const pinDigits = (v) => westernDigits(v).trim();
const validPin = (v) => /^\d{4}$/.test(v);
/* pin: 'none' (plain confirm) | 'check' (ask for the PIN) | 'setup' (create a new PIN) */
function modal({ title, text, okKey = 'common.delete', pin = 'none' }) {
  return new Promise((resolve) => {
    const m = $('modal'), p1 = $('modalPin'), p2 = $('modalPin2'), box = $('modalResetBox');
    $('modalTitle').textContent = title; $('modalText').textContent = text; $('modalOk').textContent = t(okKey);
    $('modalOk').className = 'btn ' + (pin === 'setup' || okKey !== 'common.delete' && okKey !== 'set.wipe' ? 'gold' : 'danger');
    p1.hidden = pin === 'none'; p2.hidden = pin !== 'setup'; p1.value = p2.value = ''; box.hidden = true; $('modalForgot').hidden = pin !== 'check'; $('modalKey').value = '';
    p1.placeholder = t(pin === 'setup' ? 'pin.new' : 'modal.pinPh'); p2.placeholder = t('pin.confirm');
    m.hidden = false; (pin === 'none' ? $('modalCancel') : p1).focus();
    const done = (v) => { m.hidden = true; m.onkeydown = null; ['modalOk', 'modalCancel', 'modalForgot', 'modalReset'].forEach((id) => { $(id).onclick = null; }); resolve(v); };
    $('modalCancel').onclick = () => done(false);
    m.onkeydown = (e) => { if (e.key === 'Escape') done(false); if (e.key === 'Enter' && e.target.tagName === 'INPUT') $('modalOk').click(); };
    $('modalForgot').onclick = () => { box.hidden = false; $('modalKey').focus(); };
    $('modalReset').onclick = async () => {
      if (!hasCrypto()) { toast('toast.cryptoMissing'); return; }
      const r = await verifyKey($('modalKey').value);
      if (!r.ok) { toast('pin.resetNeedsLicense'); return; }
      db.settings.pin = null; persist(); toast('pin.resetDone'); done(false);
    };
    $('modalOk').onclick = async () => {
      if (pin === 'check') {
        if (!(await checkPin(pinDigits(p1.value)))) { toast('toast.wrongPin'); p1.value = ''; p1.focus(); return; }
      } else if (pin === 'setup') {
        const a = pinDigits(p1.value), b = pinDigits(p2.value);
        if (!validPin(a)) { toast('toast.pinShort'); p1.focus(); return; }
        if (a !== b) { toast('pin.mismatch'); p2.focus(); return; }
        if (!hasCrypto()) { toast('toast.cryptoMissing'); return; }
        db.settings.pin = await makePin(a); if (!persist()) return; toast('toast.pinSet');
      }
      done(true);
    };
  });
}
/* Every destructive action goes through here: a 4-digit PIN must exist and be entered. */
async function guarded(opts) {
  if (!db.settings.pin && !(await modal({ title: t('pin.setupTitle'), text: t('pin.setupText'), okKey: 'pin.save', pin: 'setup' }))) return false;
  return modal({ ...opts, pin: 'check' });
}

/* ============ PIN (PBKDF2) ============ */
const hasCrypto = () => !!(globalThis.crypto && crypto.subtle);
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
async function pbkdf2(pin, saltHex, iter) {
  const salt = new Uint8Array(saltHex.match(/../g).map((h) => parseInt(h, 16)));
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']);
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, k, 256));
}
async function makePin(pin) {
  const salt = hex(crypto.getRandomValues(new Uint8Array(16))), iter = 150000;
  return { salt, iter, hash: await pbkdf2(pin, salt, iter) };
}
async function checkPin(pin) {
  const p = db.settings.pin; if (!p) return true;
  if (!hasCrypto()) return false;
  return (await pbkdf2(String(pin), p.salt, p.iter)) === p.hash;
}

/* ============ forms / lists definition ============ */
const F = (n, l, type, o = {}) => ({ n, l, type, ...o });
const SCHEMA = {
  incomes: { title: 'income.formTitle', list: 'income.list', empty: 'income.empty', save: 'income.save', fields: [
    F('title', 'income.titleLabel', 'text', { req: 1, ph: 'income.titlePh' }), F('amount', 'common.amount', 'number', { req: 1, pos: 1 }),
    F('date', 'common.date', 'date', { req: 1, def: 'today' }),
    F('status', 'common.status', 'select', { opts: [['paid', 'income.status.paid'], ['partial', 'income.status.partial'], ['due', 'income.status.due']] }),
    F('note', 'common.note', 'textarea', { wide: 1 })] },
  expenses: { title: 'expense.formTitle', list: 'expense.list', empty: 'expense.empty', save: 'expense.save', fields: [
    F('title', 'expense.titleLabel', 'text', { req: 1, ph: 'expense.titlePh' }), F('amount', 'common.amount', 'number', { req: 1, pos: 1 }),
    F('date', 'common.date', 'date', { req: 1, def: 'today' }),
    F('category', 'expense.category', 'select', { opts: CATS.map((c) => [c, 'cat.' + c]) }),
    F('note', 'common.note', 'textarea', { wide: 1 })] },
  debts: { title: 'debt.formTitle', list: 'debt.list', empty: 'debt.empty', save: 'debt.save', fields: [
    F('person', 'debt.person', 'text', { req: 1 }), F('type', 'debt.type', 'select', { opts: [['owe', 'debt.type.owe'], ['receivable', 'debt.type.receivable']] }),
    F('amount', 'common.amount', 'number', { req: 1, pos: 1 }), F('due', 'debt.due', 'date'),
    F('status', 'common.status', 'select', { opts: [['open', 'debt.status.open'], ['partial', 'debt.status.partial'], ['paid', 'debt.status.paid']] }),
    F('alert', 'debt.remind', 'number', { int: 1, def: '0' }), F('note', 'common.note', 'textarea', { wide: 1 })] },
  shopping: { title: 'shop.formTitle', list: 'shop.list', empty: 'shop.empty', save: 'shop.save', fields: [
    F('title', 'shop.name', 'text', { req: 1 }), F('qty', 'shop.qty', 'number', { int: 1, def: '1' }), F('price', 'shop.price', 'number'),
    F('priority', 'shop.priority', 'select', { def: 'low', opts: [['high', 'shop.priority.high'], ['med', 'shop.priority.med'], ['low', 'shop.priority.low']] }),
    F('date', 'shop.needBy', 'date'), F('status', 'common.status', 'select', { opts: [['todo', 'shop.status.todo'], ['bought', 'shop.status.bought']] }),
    F('note', 'common.note', 'textarea', { wide: 1 })] },
  goals: { title: 'goal.formTitle', list: 'goal.list', empty: 'goal.empty', save: 'goal.save', fields: [
    F('title', 'goal.title', 'text', { req: 1, ph: 'goal.titlePh' }), F('target', 'goal.target', 'number', { req: 1, pos: 1 }),
    F('saved', 'goal.saved', 'number'), F('date', 'goal.date', 'date'), F('note', 'common.note', 'textarea', { wide: 1 })] },
  reminders: { title: 'rem.formTitle', list: 'rem.list', empty: 'rem.empty', save: 'rem.save', fields: [
    F('title', 'rem.title', 'text', { req: 1 }), F('date', 'rem.date', 'date', { req: 1, def: 'today' }), F('time', 'rem.time', 'time'),
    F('alert', 'rem.before', 'number', { int: 1, def: '0' }), F('note', 'common.note', 'textarea', { wide: 1 })] }
};

function fieldHTML(type, f) {
  const id = `f-${type}-${f.n}`, cls = f.wide ? ' class="wide"' : '';
  let ctl;
  if (f.type === 'select') ctl = `<select id="${id}" name="${f.n}">${f.opts.map(([v, k]) => `<option value="${v}" data-i18n="${k}"></option>`).join('')}</select>`;
  else if (f.type === 'textarea') ctl = `<textarea id="${id}" name="${f.n}" rows="2" maxlength="500"></textarea>`;
  else if (f.type === 'number') ctl = `<input id="${id}" name="${f.n}" type="number" inputmode="decimal" step="${f.int ? 1 : 'any'}" min="${f.pos ? '0.01' : '0'}" ${f.req ? 'required' : ''}>`;
  else ctl = `<input id="${id}" name="${f.n}" type="${f.type}" ${f.req ? 'required' : ''} ${f.type === 'text' ? 'maxlength="120" autocomplete="off"' : ''}${f.ph ? ` data-i18n-ph="${f.ph}"` : ''}>`;
  const hint = f.type === 'date' ? `<small class="calhint" data-hint="${id}"></small>` : '';
  return `<label${cls}><span data-i18n="${f.l}"></span>${ctl}${hint}</label>`;
}
function buildViews() {
  for (const type of TYPES) {
    const sc = SCHEMA[type];
    $('view-' + type).innerHTML = `
      <div class="card"><h2 data-i18n="${sc.title}"></h2>
        <form data-type="${type}" novalidate autocomplete="off"><input type="hidden" name="id">
          <div class="formgrid">${sc.fields.map((f) => fieldHTML(type, f)).join('')}</div>
          <div class="row"><button class="btn gold" type="submit" data-i18n="${sc.save}"></button>
          <button class="btn" type="button" data-act="reset" data-type="${type}" data-i18n="common.clear"></button></div>
        </form></div>
      <div class="card"><div class="card-head"><h2 data-i18n="${sc.list}"></h2>${tools(type)}</div>
        <div class="toolbar"><input type="search" data-search="${type}" data-i18n-ph="common.search" aria-label="search"></div>
        <div id="list-${type}"></div></div>`;
    resetForm(type);
  }
  $('view-home').innerHTML = `<div class="card-head">${tools('home')}</div><div id="homeNotice"></div><div id="homeStats" class="grid"></div>
    <div class="two" style="margin-block-start:14px">
      <div class="card"><h3 data-i18n="dash.upcoming"></h3><div id="homeUpcoming"></div></div>
      <div class="card"><h3 data-i18n="dash.importantShopping"></h3><div id="homeShop"></div></div>
      <div class="card"><h3 data-i18n="dash.topGoal"></h3><div id="homeGoal"></div></div></div>`;
  buildAssistant();
  $('view-report').insertAdjacentHTML('afterbegin', `<div class="card-head">${tools('report')}</div>`);
  $('view-reminders').insertAdjacentHTML('afterbegin', `<div class="card"><button class="btn" id="notifBtn" data-i18n="rem.enableNotif"></button></div>`);
}
const tools = (view) => `<div class="mini"><button class="btn small" type="button" data-act="copysec" data-view="${view}">${'<span data-i18n="act.copy"></span>'}</button><button class="btn small" type="button" data-act="pdf" data-view="${view}"><span data-i18n="act.pdf"></span></button></div>`;
const formEl = (type) => document.querySelector(`form[data-type="${type}"]`);
function resetForm(type) {
  const form = formEl(type); form.reset(); form.elements.id.value = '';
  for (const f of SCHEMA[type].fields) {
    const el = form.elements[f.n]; if (!el) continue;
    if (f.def === 'today') el.value = todayISO(); else if (f.def !== undefined) el.value = f.def;
  }
}

/* ============ CRUD ============ */
function formToObject(type) {
  const form = formEl(type), o = { id: form.elements.id.value || uid() };
  for (const f of SCHEMA[type].fields) o[f.n] = form.elements[f.n].value;
  return o;
}
function submitForm(type) {
  const sc = SCHEMA[type], form = formEl(type), raw = formToObject(type);
  for (const f of sc.fields) {
    const v = String(raw[f.n] ?? '').trim();
    if (f.req && !v) { toast(f.type === 'date' ? 'toast.invalidDate' : f.type === 'number' ? 'toast.invalidAmount' : f.l); form.elements[f.n].focus(); return; }
    if (f.type === 'number' && v !== '' && (!Number.isFinite(Number(v)) || Number(v) < 0 || (f.pos && Number(v) <= 0))) { toast('toast.invalidAmount'); form.elements[f.n].focus(); return; }
    if (f.type === 'date' && v !== '' && !validISO(v)) { toast('toast.invalidDate'); form.elements[f.n].focus(); return; }
  }
  const obj = CLEAN[type](raw);
  const i = db[type].findIndex((x) => x.id === obj.id);
  if (i >= 0) db[type][i] = obj; else db[type].push(obj);
  if (persist()) { toast('toast.saved'); resetForm(type); renderAll(); }
}
function editItem(type, id) {
  const o = db[type].find((x) => x.id === id); if (!o) return;
  const form = formEl(type); form.elements.id.value = o.id;
  for (const f of SCHEMA[type].fields) form.elements[f.n].value = o[f.n] ?? '';
  go(type); form.scrollIntoView({ behavior: 'smooth', block: 'start' }); form.elements[SCHEMA[type].fields[0].n].focus();
}
async function deleteItem(type, id) {
  const ok = await guarded({ title: t('modal.deleteTitle'), text: t('modal.deleteConfirm') });
  if (!ok) return;
  db[type] = db[type].filter((x) => x.id !== id);
  if (persist()) { toast('toast.deleted'); renderAll(); }
}
function toggleBought(id) {
  const o = db.shopping.find((x) => x.id === id); if (!o) return;
  o.status = o.status === 'bought' ? 'todo' : 'bought'; if (persist()) renderAll();
}

/* ============ rendering ============ */
const sum = (arr, f = (x) => x.amount) => arr.reduce((a, x) => a + (Number(f(x)) || 0), 0);
const matches = (o, q) => !q || Object.values(o).some((v) => String(v).toLowerCase().includes(q));
const searchTerm = (type) => ((document.querySelector(`[data-search="${type}"]`) || {}).value || '').trim().toLowerCase();
const btns = (type, id, extra = '') => `<div class="actions">${extra}<button class="btn small" data-act="edit" data-type="${type}" data-id="${esc(id)}">${esc(t('common.edit'))}</button><button class="btn small danger" data-act="del" data-type="${type}" data-id="${esc(id)}">${esc(t('common.delete'))}</button></div>`;
const noteHTML = (o) => (o.note ? `<div class="muted">${esc(o.note)}</div>` : '');
const dueText = (iso) => {
  const d = daysUntil(iso); if (d === null) return { txt: '', cls: '' };
  if (d < 0) return { txt: t('debt.overdue'), cls: 'bad' };
  if (d === 0) return { txt: t('debt.today'), cls: 'warn' };
  return { txt: tp('debt.inDays', d), cls: d <= 7 ? 'warn' : '' };
};
const listOrEmpty = (type, rows) => ($('list-' + type).innerHTML = rows.length ? rows.join('') : `<div class="empty">${esc(t(SCHEMA[type].empty))}</div>`);

const RENDER = {
  incomes() {
    const q = searchTerm('incomes');
    listOrEmpty('incomes', [...db.incomes].filter((o) => matches(o, q)).sort((a, b) => b.date.localeCompare(a.date)).map((o) =>
      `<div class="item"><div class="head"><b>${esc(o.title)}</b><span class="amount green">${esc(money(o.amount))}</span></div>
       <div class="muted"><span class="badge ${o.status === 'paid' ? 'ok' : o.status === 'partial' ? 'warn' : 'bad'}">${esc(t('income.status.' + o.status))}</span>${esc(fmtDate(o.date))}</div>${noteHTML(o)}${btns('incomes', o.id)}</div>`));
  },
  expenses() {
    const q = searchTerm('expenses');
    listOrEmpty('expenses', [...db.expenses].filter((o) => matches(o, q) || t('cat.' + o.category).toLowerCase().includes(q)).sort((a, b) => b.date.localeCompare(a.date)).map((o) =>
      `<div class="item"><div class="head"><b>${esc(o.title)}</b><span class="amount red">${esc(money(o.amount))}</span></div>
       <div class="muted"><span class="badge">${esc(t('cat.' + o.category))}</span>${esc(fmtDate(o.date))}</div>${noteHTML(o)}${btns('expenses', o.id)}</div>`));
  },
  debts() {
    const q = searchTerm('debts');
    listOrEmpty('debts', [...db.debts].filter((o) => matches(o, q)).sort((a, b) => (a.due || '9999').localeCompare(b.due || '9999')).map((o) => {
      const open = o.status !== 'paid', du = open ? dueText(o.due) : { txt: '', cls: '' };
      return `<div class="item"><div class="head"><b>${esc(o.person)}</b><span class="amount ${o.type === 'owe' ? 'red' : 'green'}">${esc(money(o.amount))}</span></div>
       <div class="muted"><span class="badge ${o.type === 'owe' ? 'bad' : 'ok'}">${esc(t('debt.type.' + o.type))}</span><span class="badge">${esc(t('debt.status.' + o.status))}</span>
       ${o.due ? esc(t('debt.dueLabel', { date: fmtDate(o.due) })) : ''} ${du.txt ? `<span class="badge ${du.cls}">${esc(du.txt)}</span>` : ''}</div>${noteHTML(o)}${btns('debts', o.id)}</div>`;
    }));
  },
  shopping() {
    const q = searchTerm('shopping'), rank = { high: 0, med: 1, low: 2 };
    listOrEmpty('shopping', [...db.shopping].filter((o) => matches(o, q)).sort((a, b) => (a.status === 'bought') - (b.status === 'bought') || rank[a.priority] - rank[b.priority] || (a.date || '9999').localeCompare(b.date || '9999')).map((o) =>
      `<div class="item"><div class="head"><b>${esc(o.title)}</b><span class="amount">${esc(money(o.price))}</span></div>
       <div class="muted"><span class="badge ${o.priority === 'high' ? 'bad' : o.priority === 'med' ? 'warn' : ''}">${esc(t('shop.priority.' + o.priority))}</span><span class="badge ${o.status === 'bought' ? 'ok' : ''}">${esc(t('shop.status.' + o.status))}</span>
       ${esc(t('shop.qtyUnit', { n: nf().format(o.qty) }))} · ${o.date ? esc(t('shop.needByLabel', { date: fmtDate(o.date) })) : esc(t('shop.noDate'))}</div>${noteHTML(o)}
       ${btns('shopping', o.id, `<button class="btn small" data-act="bought" data-id="${esc(o.id)}">${esc(t(o.status === 'bought' ? 'shop.status.todo' : 'shop.status.bought'))}</button>`)}</div>`));
  },
  goals() {
    const q = searchTerm('goals');
    listOrEmpty('goals', db.goals.filter((o) => matches(o, q)).map((o) => {
      const pct = o.target > 0 ? Math.min(100, Math.round((o.saved / o.target) * 100)) : 0;
      return `<div class="item"><div class="head"><b>${esc(o.title)}</b><span class="amount gold">${pct}%</span></div>
       <div class="bar"><i style="width:${pct}%"></i></div><div class="muted">${esc(t('goal.of', { saved: money(o.saved), target: money(o.target) }))}${o.date ? ' · ' + esc(t('goal.dateLabel', { date: fmtDate(o.date) })) : ''}</div>${noteHTML(o)}${btns('goals', o.id)}</div>`;
    }));
  },
  reminders() {
    const q = searchTerm('reminders');
    listOrEmpty('reminders', [...db.reminders].filter((o) => matches(o, q)).sort((a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || ''))).map((o) => {
      const d = daysUntil(o.date); let st, cls;
      if (d === null) { st = ''; cls = ''; } else if (d < 0) { st = t('rem.state.past'); cls = ''; } else if (d === 0) { st = t('rem.state.today'); cls = 'warn'; } else if (d <= Math.max(o.alert, 3)) { st = tp('rem.inDays', d); cls = 'warn'; } else { st = tp('rem.inDays', d); cls = ''; }
      return `<div class="item"><div class="head"><b>${esc(o.title)}</b><span class="badge ${cls}">${esc(st)}</span></div>
       <div class="muted">${esc(fmtDate(o.date))}${o.time ? ' · ' + esc(o.time) : ''}</div>${noteHTML(o)}${btns('reminders', o.id)}</div>`;
    }));
  }
};
function totals() {
  const paid = sum(db.incomes.filter((x) => x.status === 'paid')), pending = sum(db.incomes.filter((x) => x.status !== 'paid'));
  const ex = sum(db.expenses), owe = sum(db.debts.filter((x) => x.type === 'owe' && x.status !== 'paid')), rec = sum(db.debts.filter((x) => x.type === 'receivable' && x.status !== 'paid'));
  return { paid, pending, ex, owe, rec, balance: paid - ex, netDebt: owe - rec };
}
const stat = (label, value, cls = '') => `<div class="stat"><div class="label">${esc(label)}</div><div class="value ${cls}">${esc(value)}</div></div>`;
function renderHome() {
  const tt = totals();
  $('homeNotice').innerHTML = tt.pending > 0 ? `<div class="notice">${esc(t('dash.unpaidNotice', { amount: money(tt.pending) }))}</div>` : '';
  $('homeStats').innerHTML = stat(t('dash.totalIncome'), money(tt.paid), 'green') + stat(t('dash.totalExpense'), money(tt.ex), 'red') + stat(t('dash.balance'), money(tt.balance), tt.balance < 0 ? 'red' : 'gold') + stat(t('dash.netDebt'), money(tt.netDebt), tt.netDebt > 0 ? 'red' : 'green');
  const ups = upcomingItems().slice(0, 6);
  $('homeUpcoming').innerHTML = ups.length ? ups.map((x) => { const du = dueText(x.date); return `<div class="item"><div class="head"><b>${esc(x.title)}</b><span class="badge ${du.cls}">${esc(du.txt)}</span></div><div class="muted">${esc(t(x.kind))} · ${esc(fmtDate(x.date))}</div></div>`; }).join('') : `<div class="empty">${esc(t('dash.emptyUpcoming'))}</div>`;
  const sh = db.shopping.filter((x) => x.priority === 'high' && x.status === 'todo').slice(0, 5);
  $('homeShop').innerHTML = sh.length ? sh.map((x) => `<div class="item"><div class="head"><b>${esc(x.title)}</b><span class="amount">${esc(money(x.price))}</span></div></div>`).join('') : `<div class="empty">${esc(t('dash.emptyShopping'))}</div>`;
  const pct = (g) => (g.target > 0 ? g.saved / g.target : 0);
  const g = [...db.goals].sort((a, b) => (pct(a) >= 1) - (pct(b) >= 1) || pct(b) - pct(a))[0];
  $('homeGoal').innerHTML = g ? `<div class="item"><div class="head"><b>${esc(g.title)}</b><span class="amount gold">${Math.min(100, Math.round(pct(g) * 100))}%</span></div><div class="bar"><i style="width:${Math.min(100, Math.round(pct(g) * 100))}%"></i></div><div class="muted">${esc(t('goal.of', { saved: money(g.saved), target: money(g.target) }))}</div></div>` : `<div class="empty">${esc(t('dash.emptyGoal'))}</div>`;
}
function reportText() {
  const tt = totals();
  return [t('rep.line.title', { app: t('app.name') }), t('rep.line.date', { date: fmtDate(todayISO()) }), '',
    t('rep.line.received', { v: money(tt.paid) }), t('rep.line.pending', { v: money(tt.pending) }), t('rep.line.expenses', { v: money(tt.ex) }), t('rep.line.balance', { v: money(tt.balance) }), '',
    t('rep.line.debt', { v: money(tt.owe) }), t('rep.line.receivable', { v: money(tt.rec) })].join('\n');
}
function renderReport() {
  const tt = totals();
  $('reportStats').innerHTML = stat(t('rep.received'), money(tt.paid), 'green') + stat(t('rep.pending'), money(tt.pending), 'gold') + stat(t('rep.expenses'), money(tt.ex), 'red') + stat(t('rep.balance'), money(tt.balance), tt.balance < 0 ? 'red' : 'gold');
  const by = {}; db.expenses.forEach((x) => { by[x.category] = (by[x.category] || 0) + x.amount; });
  const rows = Object.entries(by).sort((a, b) => b[1] - a[1]);
  $('reportCats').innerHTML = rows.length ? rows.map(([c, v]) => { const pct = tt.ex > 0 ? Math.round((v / tt.ex) * 100) : 0; return `<div class="catrow"><div class="head"><span>${esc(t('cat.' + c))}</span><b>${esc(money(v))} · ${pct}%</b></div><div class="bar"><i style="width:${pct}%"></i></div></div>`; }).join('') : `<div class="empty">${esc(t('rep.emptyCategory'))}</div>`;
  $('reportText').value = reportText();
}
function renderSettings() {
  $('setLang').value = lang; $('setCurrency').value = currencyCode(); $('setCountry').value = country(); $('setCalendar').value = calendarId(); $('setDual').checked = db.settings.dual;
  $('pinState').textContent = t(db.settings.pin ? 'set.pinOn' : 'set.pinOff');
  $('pinCurWrap').hidden = !db.settings.pin;
  $('pinSave').textContent = t(db.settings.pin ? 'set.pinChange' : 'set.pinSet');
  renderLicense();
}
function renderAll() {
  $('todayLabel').textContent = t('app.today', { date: fmtDate(todayISO()) });
  for (const k of Object.keys(RENDER)) RENDER[k]();
  renderHome(); renderReport(); renderSettings(); renderAssistant(); updateHints();
  document.querySelectorAll('#nav button').forEach((b) => b.classList.toggle('locked', !viewAllowed(b.dataset.view)));
  go(currentView);
  document.querySelectorAll('#nav button').forEach((b) => b.setAttribute('aria-current', b.dataset.view === currentView ? 'page' : 'false'));
}
function updateHints() {
  const show = calendarId() !== 'gregory' || db.settings.dual;
  document.querySelectorAll('[data-hint]').forEach((h) => { const v = $(h.dataset.hint).value; h.textContent = show && validISO(v) ? fmtDate(v) : ''; });
}
function fillSelects() {
  const opts = LANGS.map((l) => `<option value="${l}">${esc(I18N[l]['lang.name'])}</option>`).join('');
  ['quickLang', 'setLang', 'lockLang'].forEach((id) => { $(id).innerHTML = opts; $(id).value = lang; });
  $('setCurrency').innerHTML = CURRENCIES.map((c) => {
    let label = c;
    if (c === 'none') label = t('cur.none'); else if (c === 'IRT') label = 'IRT — ' + t('cur.IRT');
    else { try { label = `${c} — ${new Intl.DisplayNames(BASE_LOCALE[lang], { type: 'currency' }).of(c)}`; } catch { /* keep code */ } }
    return `<option value="${c}">${esc(label)}</option>`;
  }).join('');
  let regions = null; try { regions = new Intl.DisplayNames(BASE_LOCALE[lang], { type: 'region' }); } catch { /* codes only */ }
  $('setCountry').innerHTML = Object.keys(COUNTRIES).map((c) => [c, regions ? regions.of(c) : c]).sort((a, b) => a[1].localeCompare(b[1], BASE_LOCALE[lang])).map(([c, n]) => `<option value="${c}">${esc(n)}</option>`).join('');
  $('setCalendar').innerHTML = CALENDARS.map((c) => `<option value="${c}">${esc(t('cal.' + c))}</option>`).join('');
}


/* ============ section documents: copy as text / print as PDF ============ */
const MONEY_FIELDS = new Set(['amount', 'price', 'target', 'saved']);
function cellText(f, o) {
  const v = o[f.n];
  if (f.type === 'select') { const op = f.opts.find((x) => x[0] === v); return op ? t(op[1]) : ''; }
  if (f.type === 'date') return fmtDate(v);
  if (MONEY_FIELDS.has(f.n)) return money(v);
  return String(v ?? '');
}
const SORTERS = {
  incomes: (a, b) => b.date.localeCompare(a.date), expenses: (a, b) => b.date.localeCompare(a.date),
  debts: (a, b) => (a.due || '9999').localeCompare(b.due || '9999'),
  shopping: (a, b) => (a.status === 'bought') - (b.status === 'bought') || ({ high: 0, med: 1, low: 2 }[a.priority] - { high: 0, med: 1, low: 2 }[b.priority]),
  goals: () => 0, reminders: (a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || ''))
};
function upcomingItems() {
  return [...db.debts.filter((x) => x.status !== 'paid' && x.due).map((x) => ({ title: x.person, date: x.due, kind: x.type === 'owe' ? 'debt.type.owe' : 'debt.type.receivable' })),
    ...db.reminders.filter((x) => x.date).map((x) => ({ title: x.title, date: x.date, kind: 'nav.reminder' }))]
    .filter((x) => daysUntil(x.date) >= -30).sort((a, b) => a.date.localeCompare(b.date));
}
function sectionDoc(view) {
  const doc = { title: '', blocks: [] };
  if (TYPES.includes(view)) {
    const sc = SCHEMA[view], rows = [...db[view]].sort(SORTERS[view]).map((o) => sc.fields.map((f) => cellText(f, o)));
    doc.title = t(sc.list);
    const headers = sc.fields.map((f) => t(f.l));
    if (view === 'incomes' || view === 'expenses') {
      const idx = sc.fields.findIndex((f) => f.n === 'amount'), tot = headers.map(() => ''); tot[0] = t('common.total'); tot[idx] = money(sum(db[view]));
      if (rows.length) rows.push(tot);
    }
    doc.blocks.push({ headers, rows });
  } else if (view === 'home' || view === 'report') {
    const tt = totals();
    if (view === 'home') {
      doc.title = t('nav.home');
      doc.blocks.push({ kv: true, rows: [[t('dash.totalIncome'), money(tt.paid)], [t('dash.totalExpense'), money(tt.ex)], [t('dash.balance'), money(tt.balance)], [t('dash.netDebt'), money(tt.netDebt)], [t('rep.pending'), money(tt.pending)]] });
      doc.blocks.push({ heading: t('dash.upcoming'), headers: [t('common.note'), t('common.status'), t('common.date')], rows: upcomingItems().slice(0, 10).map((x) => [x.title, t(x.kind), fmtDate(x.date)]) });
      doc.blocks.push({ heading: t('dash.importantShopping'), headers: [t('shop.name'), t('shop.price')], rows: db.shopping.filter((x) => x.priority === 'high' && x.status === 'todo').map((x) => [x.title, money(x.price)]) });
      doc.blocks.push({ heading: t('dash.topGoal'), headers: [t('goal.title'), t('goal.saved'), t('goal.target')], rows: db.goals.map((g) => [g.title, money(g.saved), money(g.target)]) });
    } else {
      doc.title = t('rep.title');
      doc.blocks.push({ kv: true, rows: [[t('rep.received'), money(tt.paid)], [t('rep.pending'), money(tt.pending)], [t('rep.expenses'), money(tt.ex)], [t('rep.balance'), money(tt.balance)], [t('dash.netDebt'), money(tt.netDebt)]] });
      const by = {}; db.expenses.forEach((x) => { by[x.category] = (by[x.category] || 0) + x.amount; });
      doc.blocks.push({ heading: t('rep.byCategory'), headers: [t('expense.category'), t('common.amount'), '%'], rows: Object.entries(by).sort((a, b) => b[1] - a[1]).map(([c, v]) => [t('cat.' + c), money(v), (tt.ex > 0 ? Math.round((v / tt.ex) * 100) : 0) + '%']) });
    }
  } else if (view === 'assistant') {
    doc.title = t('ai.title');
    doc.blocks.push({ kv: true, rows: ai.log.map((m) => [t(m.role === 'you' ? 'ai.you' : 'ai.bot'), m.text]) });
  }
  return doc;
}
function docToText(doc) {
  const out = [`${t('app.name')} — ${doc.title}`, fmtDate(todayISO()), ''];
  for (const b of doc.blocks) {
    if (b.heading) out.push(b.heading);
    for (const r of b.rows) out.push(b.kv ? `${r[0]}: ${r[1]}` : '• ' + r.filter((c) => c !== '').join(' | '));
    out.push('');
  }
  return out.join('\n').trim();
}
function docToHTML(doc) {
  const rtl = lang === 'ar' || lang === 'fa';
  const tbl = (b) => (b.kv
    ? `<table>${b.rows.map((r) => `<tr><th>${esc(r[0])}</th><td>${esc(r[1])}</td></tr>`).join('')}</table>`
    : `<table><thead><tr>${b.headers.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${b.rows.length ? b.rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('') : `<tr><td colspan="${b.headers.length}">—</td></tr>`}</tbody></table>`);
  return `<!doctype html><html lang="${lang}" dir="${rtl ? 'rtl' : 'ltr'}"><head><meta charset="utf-8"><title>${esc(t('app.name') + ' — ' + doc.title)}</title><style>
@page{margin:14mm}body{font:11pt/1.45 system-ui,"Segoe UI",Roboto,"Noto Sans","Noto Naskh Arabic","Noto Sans Devanagari",Arial,sans-serif;color:#111;margin:0}
header{display:flex;align-items:center;gap:12px;border-bottom:2px solid #b8891f;padding-bottom:10px;margin-bottom:12px}header img{width:52px;height:52px;border-radius:10px}
h1{font-size:17pt;margin:0}h2{font-size:12.5pt;margin:16px 0 6px}.sub{color:#555;font-size:9.5pt}
table{width:100%;border-collapse:collapse;margin:6px 0 4px;page-break-inside:auto}tr{page-break-inside:avoid}
th,td{border:1px solid #bbb;padding:5px 8px;text-align:start;vertical-align:top;font-size:10pt;overflow-wrap:anywhere}thead th,tbody th{background:#f4ebd3}tbody th{width:38%}
footer{margin-top:18px;color:#777;font-size:8.5pt;border-top:1px solid #ddd;padding-top:6px}</style></head><body>
<header><img src="${CONFIG.icon}" alt=""><div><h1>${esc(t('app.name'))}</h1><div class="sub">${esc(doc.title)} · ${esc(fmtDate(todayISO()))}</div></div></header>
${doc.blocks.map((b) => (b.heading ? `<h2>${esc(b.heading)}</h2>` : '') + tbl(b)).join('')}
<footer>${esc(t('app.footer'))}</footer></body></html>`;
}
function copySection(view) { copyText(docToText(sectionDoc(view)), 'toast.sectionCopied'); }
function printSection(view) {
  const html = docToHTML(sectionDoc(view));
  if (window.__ledgerTest) { window.__lastPrint = html; return; }
  const fr = document.createElement('iframe'); fr.setAttribute('aria-hidden', 'true'); fr.style.cssText = 'position:fixed;inset-inline-end:0;bottom:0;width:0;height:0;border:0';
  fr.srcdoc = html; document.body.appendChild(fr);
  fr.onload = () => { try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch { toast('toast.copyManual'); } setTimeout(() => fr.remove(), 120000); };
  toast('toast.pdfHint');
}

/* ============ AI assistant (offline analysis + optional online mode with the user's own key) ============ */
const ai = { log: [], cfg: { enabled: false, key: '', model: 'claude-sonnet-5-5' }, busy: false };
function loadAi() {
  try { const o = JSON.parse(store.get(AI_KEY) || 'null'); if (o) ai.cfg = { enabled: o.enabled === true, key: S(o.key, 300), model: S(o.model, 80) || 'claude-sonnet-5-5' }; } catch { /* defaults */ }
}
const saveAi = () => store.set(AI_KEY, JSON.stringify(ai.cfg));
const AI_INTENTS = ['summary', 'overdue', 'spending', 'goals', 'shopping', 'advice'];
function topCategories() {
  const by = {}; db.expenses.forEach((x) => { by[x.category] = (by[x.category] || 0) + x.amount; });
  return Object.entries(by).sort((a, b) => b[1] - a[1]);
}
const ANSWERS = {
  summary() {
    if (!db.incomes.length && !db.expenses.length && !db.debts.length) return t('ai.a.noData');
    const tt = totals();
    return t('ai.a.summary', { received: money(tt.paid), pending: money(tt.pending), expenses: money(tt.ex), balance: money(tt.balance), netdebt: money(tt.netDebt) });
  },
  overdue() {
    const items = upcomingItems(), late = db.debts.filter((x) => x.status !== 'paid' && x.due && daysUntil(x.due) < 0).map((x) => ({ title: x.person, date: x.due })), soon = items.filter((x) => { const d = daysUntil(x.date); return d >= 0 && d <= 14; });
    const f = (x) => `${x.title} (${fmtDate(x.date)})`, out = [];
    if (late.length) out.push(t('ai.a.overdue', { items: late.map(f).join('; ') }));
    if (soon.length) out.push(t('ai.a.upcoming', { items: soon.map(f).join('; ') }));
    return out.length ? out.join('\n') : t('ai.a.nothingDue');
  },
  spending() {
    const cats = topCategories(), tot = sum(db.expenses);
    if (!cats.length) return t('ai.a.noSpending');
    return t('ai.a.spending', { items: cats.slice(0, 3).map(([c, v]) => `${t('cat.' + c)} ${money(v)} (${Math.round((v / tot) * 100)}%)`).join('; ') });
  },
  goals() {
    if (!db.goals.length) return t('ai.a.noGoals');
    return t('ai.a.goals', { items: db.goals.map((g) => `${g.title} ${g.target > 0 ? Math.min(100, Math.round((g.saved / g.target) * 100)) : 0}% (${money(g.saved)} / ${money(g.target)})`).join('; ') });
  },
  shopping() {
    const it = db.shopping.filter((x) => x.priority === 'high' && x.status === 'todo');
    return it.length ? t('ai.a.shopping', { items: it.map((x) => x.title).join(', '), total: money(sum(it, (x) => x.price)) }) : t('ai.a.noShopping');
  },
  advice() {
    if (!db.incomes.length && !db.expenses.length) return t('ai.a.adviceNone');
    const tt = totals(), out = [], cats = topCategories();
    if (tt.ex > tt.paid) out.push(t('ai.a.adviceOver', { cat: cats[0] ? t('cat.' + cats[0][0]) : '—' }));
    else if (tt.paid > 0) out.push(t('ai.a.adviceOk', { pct: Math.round((tt.ex / tt.paid) * 100) }));
    if (tt.pending > 0) out.push(t('ai.a.advicePending', { amount: money(tt.pending) }));
    if (tt.owe > 0) out.push(t('ai.a.adviceDebt', { amount: money(tt.owe) }));
    return out.join('\n');
  }
};
function matchIntent(q) {
  q = q.toLowerCase();
  for (const it of AI_INTENTS) if (t('ai.kw.' + it).split(',').map((k) => k.trim().toLowerCase()).filter(Boolean).some((k) => q.includes(k))) return it;
  return null;
}
function aiContext() {
  const tt = totals();
  return JSON.stringify({ today: todayISO(), currency: currencyCode() === 'none' ? '' : currencyCode(), totals: tt,
    incomes: db.incomes.slice(0, 60).map((x) => [x.title, x.amount, x.date, x.status]), expenses: db.expenses.slice(0, 80).map((x) => [x.title, x.amount, x.date, x.category]),
    debts: db.debts.slice(0, 40).map((x) => [x.person, x.type, x.amount, x.due, x.status]), goals: db.goals.slice(0, 20).map((x) => [x.title, x.target, x.saved, x.date]),
    shopping: db.shopping.slice(0, 40).map((x) => [x.title, x.price, x.priority, x.status]), reminders: db.reminders.slice(0, 40).map((x) => [x.title, x.date]) });
}
async function askOnline(q) {
  const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', signal: AbortSignal.timeout(45000),
    headers: { 'content-type': 'application/json', 'x-api-key': ai.cfg.key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
    body: JSON.stringify({ model: ai.cfg.model, max_tokens: 700,
      system: `You are a concise, careful financial assistant inside a personal ledger app. Reply in the language with code "${lang}". Use ONLY the JSON data provided; never invent numbers; if the data cannot answer, say so. Keep answers under 150 words and plain text.`,
      messages: [{ role: 'user', content: `DATA:\n${aiContext()}\n\nQUESTION: ${q}` }] }) });
  if (!r.ok) { const e = new Error('http'); e.status = r.status; throw e; }
  const j = await r.json(); const txt = (j.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('\n').trim();
  if (!txt) throw Object.assign(new Error('empty'), { status: 'empty' });
  return txt;
}
function renderAssistant() {
  const log = $('aiLog'); if (!log) return;
  log.innerHTML = ai.log.map((m) => `<div class="bubble ${m.role}"><b>${esc(t(m.role === 'you' ? 'ai.you' : 'ai.bot'))}</b><div>${esc(m.text)}</div></div>`).join('');
  log.scrollTop = log.scrollHeight;
  const online = ai.cfg.enabled && !!ai.cfg.key; $('aiBadge').textContent = t(online ? 'ai.badge.online' : 'ai.badge.offline'); $('aiBadge').className = 'badge ' + (online ? 'ok' : '');
  $('aiEnable').checked = ai.cfg.enabled; $('aiKey').value = ai.cfg.key; $('aiModel').value = ai.cfg.model;
}
async function sendQuestion(text, intent) {
  if (ai.busy) return; const q = String(text || '').trim(); if (!q) return;
  ai.log.push({ role: 'you', text: q }); ai.busy = true; renderAssistant();
  let a = null; const it = intent || null;
  try {
    if (!it && ai.cfg.enabled && ai.cfg.key) {
      ai.log.push({ role: 'bot', text: t('ai.thinking') }); renderAssistant();
      try { a = await askOnline(q); } catch (e) { toast(t('ai.online.err', { status: e.status || 'network' })); }
      ai.log.pop();
    }
    if (a === null) { const k = it || matchIntent(q); a = k ? ANSWERS[k]() : t('ai.a.fallback'); }
  } finally { ai.busy = false; }
  ai.log.push({ role: 'bot', text: a }); renderAssistant();
}
function buildAssistant() {
  $('view-assistant').innerHTML = `<div class="card"><div class="card-head"><h2 data-i18n="ai.title"></h2>${tools('assistant')}</div>
    <p class="muted" data-i18n="ai.intro"></p><p><span id="aiBadge" class="badge"></span></p>
    <div class="chips">${AI_INTENTS.map((i) => `<button class="btn small" type="button" data-act="aiq" data-intent="${i}" data-i18n="ai.chip.${i}"></button>`).join('')}</div>
    <div id="aiLog" class="chat" aria-live="polite"></div>
    <form id="aiForm" class="row" autocomplete="off"><input id="aiInput" type="text" maxlength="500" data-i18n-ph="ai.placeholder" style="flex:1;min-width:0"><button class="btn gold" type="submit" data-i18n="ai.send"></button>
    <button class="btn" type="button" data-act="aiclear" data-i18n="ai.clear"></button></form></div>
    <details class="card"><summary data-i18n="ai.online.title"></summary><p class="muted" data-i18n="ai.online.note"></p>
      <label class="check"><input id="aiEnable" type="checkbox"><span data-i18n="ai.online.enable"></span></label>
      <div class="two"><label><span data-i18n="ai.online.key"></span><input id="aiKey" type="password" autocomplete="off" spellcheck="false" dir="ltr"></label>
      <label><span data-i18n="ai.online.model"></span><input id="aiModel" type="text" dir="ltr" spellcheck="false"></label></div></details>`;
}

/* ============ navigation ============ */
let currentView = 'home';
const VIEWS = ['home', ...TYPES, 'assistant', 'report', 'settings'];
/* A section listed in CONFIG.paidViews is usable during the trial and with a license (that covers it: payload.f = list of sections, absent = all). */
const viewAllowed = (view) => !PAID_VIEWS.includes(view) || lic.state === 'trial' || (lic.state === 'licensed' && (!Array.isArray(lic.payload.f) || lic.payload.f.includes(view)));
function go(view) {
  if (!VIEWS.includes(view)) view = 'home';
  currentView = view;
  const shown = viewAllowed(view) ? 'view-' + view : 'view-locked';
  document.querySelectorAll('.view').forEach((s) => s.classList.toggle('active', s.id === shown));
  document.querySelectorAll('#nav button').forEach((b) => b.setAttribute('aria-current', b.dataset.view === view ? 'page' : 'false'));
  try { if (location.hash !== '#' + view) history.replaceState(null, '', '#' + view); } catch { /* file:// or sandbox */ }
  window.scrollTo({ top: 0 });
}

/* ============ backup ============ */
function backupObject() {
  const d = JSON.parse(JSON.stringify(db)); d.settings.pin = null; d.settings.notified = {};
  return { app: 'my-ledger', version: 2, exportedAt: new Date().toISOString(), data: d };
}
function download(name, text, type = 'application/json') {
  const url = URL.createObjectURL(new Blob([text], { type })), a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
}
const exportBackup = () => { download(`my-ledger-backup-${todayISO()}.json`, JSON.stringify(backupObject(), null, 2)); toast('toast.backupDone'); };
async function copyText(text, okKey) {
  try { await navigator.clipboard.writeText(text); toast(okKey); return; } catch { /* fall through */ }
  const ta = document.createElement('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select();
  let ok = false; try { ok = document.execCommand('copy'); } catch { /* ignore */ } ta.remove(); toast(ok ? okKey : 'toast.copyManual');
}
async function importBackup(file) {
  if (!file) return;
  let text; try { text = await file.text(); } catch { toast('toast.readError'); return; }
  let parsed; try { parsed = JSON.parse(text); } catch { toast('toast.badFile'); return; }
  const src = parsed && parsed.app === 'my-ledger' && parsed.data ? parsed.data : parsed;   // new format or the legacy Persian edition's raw export
  if (!src || !Array.isArray(src.incomes) || !Array.isArray(src.expenses)) { toast('toast.badFile'); return; }
  if (!(await guarded({ title: t('set.import'), text: t('confirm.import'), okKey: 'common.save' }))) return;
  const next = sanitize(src), legacy = !(parsed.app === 'my-ledger');
  next.settings = legacy ? { ...db.settings, currency: 'IRT', country: 'IR', calendar: 'persian' } : { ...db.settings, currency: next.settings.currency || db.settings.currency };
  db = next; if (persist()) { toast('toast.imported'); renderAll(); }
}

/* ============ license ============ */
const b64uToBytes = (s) => { s = s.replace(/-/g, '+').replace(/_/g, '/'); s += '='.repeat((4 - (s.length % 4)) % 4); return Uint8Array.from(atob(s), (c) => c.charCodeAt(0)); };
async function verifyKey(key) {
  const parts = String(key || '').trim().split('.');
  if (parts.length !== 3 || parts[0] !== 'ML1') return { ok: false, reason: 'invalid' };
  try {
    const pub = await crypto.subtle.importKey('jwk', CONFIG.publicKey, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    const good = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, pub, b64uToBytes(parts[2]), new TextEncoder().encode(parts[0] + '.' + parts[1]));
    if (!good) return { ok: false, reason: 'invalid' };
    const p = JSON.parse(new TextDecoder().decode(b64uToBytes(parts[1])));
    if (!p || p.p !== 'ML') return { ok: false, reason: 'invalid' };
    if (p.x && (!validISO(p.x) || daysUntil(p.x) < 0)) return { ok: false, reason: 'expired', payload: p };
    return { ok: true, payload: p };
  } catch { return { ok: false, reason: 'invalid' }; }
}
function trialDaysLeft() {
  const now = Date.now(); let tr = null;
  try { tr = JSON.parse(store.get(TRIAL_KEY) || 'null'); } catch { /* ignore */ }
  if (!tr || !Number.isFinite(tr.start) || !Number.isFinite(tr.last)) tr = { start: now, last: now };
  tr.last = Math.max(tr.last, now);              // a clock moved backwards cannot extend the trial
  store.set(TRIAL_KEY, JSON.stringify(tr));
  return Math.max(0, TRIAL_DAYS - Math.floor((tr.last - tr.start) / 864e5));
}
async function evaluateLicense() {
  const stored = store.get(LIC_KEY);
  if (stored && hasCrypto()) { const r = await verifyKey(stored); if (r.ok) { lic = { state: 'licensed', payload: r.payload, daysLeft: 0 }; return; } }
  const left = trialDaysLeft();
  lic = { state: left > 0 ? 'trial' : (CONFIG.lockAfterTrial === false ? 'free' : 'locked'), daysLeft: left, payload: null };
}
function renderLicense() {
  const el = $('licStatus'); let txt;
  if (lic.state === 'licensed') {
    const p = lic.payload; txt = t('lic.active') + (p.n ? ' — ' + t('lic.licensedTo', { name: p.n }) : '') + ' — ' + (p.x ? t('lic.until', { date: fmtDate(p.x) }) : t('lic.lifetime'));
  } else txt = lic.state === 'trial' ? tp('lic.trial', lic.daysLeft) : lic.state === 'free' ? t('lic.freeEdition') : t('lic.lockedTitle');
  el.textContent = txt;
  const c = CONFIG.contact ? t('lic.contact', { contact: CONFIG.contact }) : '';
  $('licContact').textContent = c; $('lockContact').textContent = c;
  $('lock').hidden = lic.state !== 'locked';
  document.body.style.overflow = lic.state === 'locked' ? 'hidden' : '';
}
async function activate(key, msgEl) {
  const say = (k) => { if (msgEl) msgEl.textContent = k ? t(k) : ''; if (k) toast(k); };
  if (!hasCrypto()) { say('lic.needCrypto'); return; }
  const r = await verifyKey(key);
  if (!r.ok) { say(r.reason === 'expired' ? 'lic.expired' : 'lic.invalid'); return; }
  store.set(LIC_KEY, String(key).trim());
  await evaluateLicense(); if (msgEl) msgEl.textContent = ''; $('licKey').value = ''; $('lockKey').value = '';
  renderAll(); toast('lic.activated');
}

/* ============ notifications ============ */
async function enableNotifications() {
  if (!('Notification' in window)) { toast('toast.notifUnsupported'); return; }
  try { const p = await Notification.requestPermission(); toast(p === 'granted' ? 'toast.notifGranted' : 'toast.notifDenied'); if (p === 'granted') checkDue(); } catch { toast('toast.notifUnsupported'); }
}
function checkDue() {
  if (!('Notification' in window) || Notification.permission !== 'granted' || lic.state === 'locked') return;
  const today = todayISO(), now = new Date(), hm = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
  const n = db.settings.notified; for (const k of Object.keys(n)) if (!k.endsWith('@' + today)) delete n[k];
  const items = [...db.reminders.map((x) => ({ id: x.id, title: x.title, date: x.date, alert: x.alert, time: x.time })),
    ...db.debts.filter((x) => x.status !== 'paid' && x.due).map((x) => ({ id: x.id, title: x.person, date: x.due, alert: x.alert, time: '' }))];
  let changed = false;
  for (const it of items) {
    const d = daysUntil(it.date); if (d === null || d < 0 || d > it.alert) continue;
    if (d === 0 && it.time && hm < it.time) continue;
    const k = it.id + '@' + today; if (n[k]) continue;
    try { new Notification(it.title, { body: t('rem.notifBody', { when: d === 0 ? t('debt.today') : tp('debt.inDays', d), date: fmtDate(it.date) }), icon: CONFIG.icon, tag: k }); } catch { /* some browsers need a service worker */ }
    n[k] = 1; changed = true;
  }
  if (changed) store.set(KEY, JSON.stringify(db));
}

/* ============ PIN settings & wipe ============ */
async function savePin() {
  if (!hasCrypto()) { toast('toast.cryptoMissing'); return; }
  const cur = pinDigits($('pinCur').value), nw = pinDigits($('pinNew').value), cf = pinDigits($('pinConfirm').value);
  if (db.settings.pin && !(await checkPin(cur))) { toast('toast.pinBadCurrent'); return; }
  if (!validPin(nw)) { toast('toast.pinShort'); return; }
  if (nw !== cf) { toast('pin.mismatch'); return; }
  db.settings.pin = await makePin(nw); $('pinCur').value = $('pinNew').value = $('pinConfirm').value = '';
  if (persist()) { toast('toast.pinSet'); renderSettings(); }
}
async function wipeAll() {
  if (!(await guarded({ title: t('set.wipeTitle'), text: t('confirm.wipe'), okKey: 'set.wipe' }))) return;
  const keep = { ...db.settings, pin: null, notified: {} };
  db = blank(); Object.assign(db.settings, keep); store.del(AI_KEY); ai.cfg = { enabled: false, key: '', model: 'claude-sonnet-5-5' };
  if (persist()) { TYPES.forEach(resetForm); toast('toast.wiped'); renderAll(); go('home'); }
}

/* ============ legacy (Persian edition) migration ============ */
async function migrateLegacy() {
  const raw = store.get(OLD_KEY); if (!raw) return false;
  try {
    const old = JSON.parse(raw); if (!old || !Array.isArray(old.incomes)) return false;
    const next = sanitize(old); Object.assign(next.settings, { lang: 'fa', country: 'IR', currency: 'IRT', calendar: 'persian' });
    const pw = old.settings && old.settings.password;
    if (pw && pw !== '1234' && validPin(pinDigits(pw)) && hasCrypto()) next.settings.pin = await makePin(pinDigits(pw));
    db = next; persist(); return true;     // the old key is left untouched
  } catch { return false; }
}

/* ============ boot ============ */
function wire() {
  $('nav').addEventListener('click', (e) => { const b = e.target.closest('button[data-view]'); if (b) go(b.dataset.view); });
  document.addEventListener('submit', (e) => { const f = e.target.closest('form[data-type]'); if (f) { e.preventDefault(); submitForm(f.dataset.type); } });
  document.addEventListener('input', (e) => { const s = e.target.closest('[data-search]'); if (s) RENDER[s.dataset.search](); });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const { act, type, id, view, intent } = b.dataset;
    if (act === 'edit') editItem(type, id); else if (act === 'del') deleteItem(type, id);
    else if (act === 'reset') { resetForm(type); updateHints(); } else if (act === 'bought') toggleBought(id);
    else if (act === 'gosettings') go('settings'); else if (act === 'copysec') copySection(view); else if (act === 'pdf') printSection(view);
    else if (act === 'aiq') sendQuestion(t('ai.chip.' + intent), intent); else if (act === 'aiclear') { ai.log = []; renderAssistant(); }
  });
  const langChange = (e) => setLang(e.target.value);
  ['quickLang', 'setLang', 'lockLang'].forEach((id) => $(id).addEventListener('change', langChange));
  $('setCurrency').addEventListener('change', (e) => { db.settings.currency = e.target.value; if (persist()) renderAll(); });
  $('setCountry').addEventListener('change', (e) => { const c = e.target.value, [l, cur, cal] = COUNTRIES[c]; Object.assign(db.settings, { country: c, currency: cur, calendar: cal }); setLang(l); });
  $('setCalendar').addEventListener('change', (e) => { db.settings.calendar = e.target.value; if (persist()) renderAll(); });
  $('setDual').addEventListener('change', (e) => { db.settings.dual = e.target.checked; if (persist()) renderAll(); });
  document.addEventListener('input', (e) => { if (e.target.type === 'date') updateHints(); });
  document.addEventListener('submit', (e) => { if (e.target.id === 'aiForm') { e.preventDefault(); const i = $('aiInput'); const v = i.value; i.value = ''; sendQuestion(v); } });
  document.addEventListener('change', (e) => {
    if (e.target.id === 'aiEnable') ai.cfg.enabled = e.target.checked; else if (e.target.id === 'aiKey') ai.cfg.key = e.target.value.trim(); else if (e.target.id === 'aiModel') ai.cfg.model = e.target.value.trim() || 'claude-sonnet-5-5'; else return;
    saveAi(); renderAssistant();
  });
  $('copyReport').addEventListener('click', () => copyText($('reportText').value, 'toast.copied'));
  $('exportBtn').addEventListener('click', exportBackup); $('lockExport').addEventListener('click', exportBackup);
  $('copyBackupBtn').addEventListener('click', () => copyText(JSON.stringify(backupObject()), 'toast.backupCopied'));
  $('importBtn').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', (e) => { importBackup(e.target.files[0]); e.target.value = ''; });
  $('pinSave').addEventListener('click', savePin); $('wipeBtn').addEventListener('click', wipeAll);
  $('licActivate').addEventListener('click', () => activate($('licKey').value));
  $('lockActivate').addEventListener('click', () => activate($('lockKey').value, $('lockMsg')));
  document.addEventListener('click', (e) => { if (e.target.id === 'notifBtn') enableNotifications(); });
  window.addEventListener('hashchange', () => go(location.hash.slice(1)));
}
async function boot() {
  buildViews(); wire();
  const raw = store.get(KEY);
  if (raw) { try { db = sanitize(JSON.parse(raw)); } catch { db = blank(); } }
  else await migrateLegacy();
  loadAi(); await evaluateLicense();
  if (!db.settings.lang && !db.settings.country) { const d = detectLocale(); db.settings.country = d.country; setLang(d.lang, false); } else setLang(db.settings.lang || detectLang(), false);
  go(location.hash.slice(1) || 'home');
  checkDue(); setInterval(() => { checkDue(); const d = todayISO(); if (boot.day !== d) { boot.day = d; renderAll(); } }, 60000); boot.day = todayISO();
  window.__ledgerReady = true;
}
window.addEventListener('error', (e) => { try { console.error('[ledger]', e.message); } catch { /* ignore */ } });
boot();
})();
