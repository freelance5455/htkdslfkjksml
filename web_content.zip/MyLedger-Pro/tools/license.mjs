#!/usr/bin/env node
// Seller-only license tool.   node tools/license.mjs keygen | issue --name "Ann" [--email a@b.c] [--expires 2027-12-31] | verify <key>
import { generateKeyPairSync, createPrivateKey, createPublicKey, sign, verify } from 'node:crypto';
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PRIV = path.join(root, 'seller-only', 'private.jwk.json'), PUB = path.join(root, 'src', 'pubkey.json');
const b64u = (b) => Buffer.from(b).toString('base64url');
const [cmd, ...rest] = process.argv.slice(2);
const arg = (n) => { const i = rest.indexOf('--' + n); return i >= 0 ? rest[i + 1] : undefined; };
if (cmd === 'keygen') {
  if (fs.existsSync(PRIV) && !rest.includes('--force')) { console.error('A private key already exists. Use --force to replace it (all issued keys become invalid).'); process.exit(1); }
  const { privateKey, publicKey } = generateKeyPairSync('ec', { namedCurve: 'P-256' });
  fs.mkdirSync(path.dirname(PRIV), { recursive: true });
  fs.writeFileSync(PRIV, JSON.stringify(privateKey.export({ format: 'jwk' }), null, 2), { mode: 0o600 });
  const pj = publicKey.export({ format: 'jwk' }); fs.writeFileSync(PUB, JSON.stringify({ kty: pj.kty, crv: pj.crv, x: pj.x, y: pj.y }, null, 2));
  console.log('Keys created. Keep seller-only/private.jwk.json secret; never ship it.');
} else if (cmd === 'issue') {
  const name = arg('name'); if (!name) { console.error('--name is required'); process.exit(1); }
  const x = arg('expires') || 0; if (x && !/^\d{4}-\d{2}-\d{2}$/.test(x)) { console.error('--expires must be YYYY-MM-DD'); process.exit(1); }
  const sec = arg('sections'); const payload = { p: 'ML', n: name, ...(sec ? { f: sec.split(',').map((v) => v.trim()).filter(Boolean) } : {}), ...(arg('email') ? { e: arg('email') } : {}), x, i: Date.now().toString(36), c: new Date().toISOString().slice(0, 10) };
  const head = 'ML1.' + b64u(JSON.stringify(payload));
  const key = createPrivateKey({ key: JSON.parse(fs.readFileSync(PRIV, 'utf8')), format: 'jwk' });
  console.log(head + '.' + b64u(sign('sha256', Buffer.from(head), { key, dsaEncoding: 'ieee-p1363' })));
} else if (cmd === 'verify') {
  const [h, p, s] = String(rest[0] || '').split('.'); const pub = createPublicKey({ key: JSON.parse(fs.readFileSync(PUB, 'utf8')), format: 'jwk' });
  const ok = h === 'ML1' && verify('sha256', Buffer.from(h + '.' + p), { key: pub, dsaEncoding: 'ieee-p1363' }, Buffer.from(s || '', 'base64url'));
  console.log(ok ? 'VALID ' + Buffer.from(p, 'base64url').toString() : 'INVALID'); process.exit(ok ? 0 : 1);
} else { console.error('Usage: keygen | issue --name N [--email E] [--expires YYYY-MM-DD] | verify KEY'); process.exit(1); }
