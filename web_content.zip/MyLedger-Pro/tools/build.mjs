// Builds dist/index.html (single offline file) from src/. Config: build.config.json {contact, trialDays}
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url'; import vm from 'node:vm';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), r = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const uri = (f) => 'data:image/png;base64,' + fs.readFileSync(path.join(root, 'assets', f)).toString('base64');
const cfgFile = path.join(root, 'build.config.json'), cfg = fs.existsSync(cfgFile) ? JSON.parse(r('build.config.json')) : {};
const config = { contact: cfg.contact || '', trialDays: cfg.trialDays || 14, paidViews: cfg.paidViews || [], lockAfterTrial: cfg.lockAfterTrial !== false, publicKey: JSON.parse(r('src/pubkey.json')), icon: uri('logo-192.png') };
const I18N_FILES = ['src/i18n.js', 'src/i18n.fa-hi.js', 'src/i18n.features.js'], I18N_SRC = I18N_FILES.map(r).join('\n');
const safe = (s) => s.replace(/<\/script/gi, '<\\/script');
let html = r('src/template.html')
  .replace('{{CSS}}', () => r('src/styles.css')).replace('{{I18N}}', () => safe(I18N_SRC))
  .replace('{{CONFIG}}', () => safe(JSON.stringify(config))).replace('{{APP}}', () => safe(r('src/app.js')))
  .replace(/\{\{LOGO_(\d+)\}\}/g, (_, n) => uri(`logo-${n}.png`));
if (/\{\{\w+\}\}/.test(html)) throw new Error('unreplaced placeholder');
new vm.Script(I18N_SRC); new vm.Script('const CONFIG={};' + r('src/app.js'));   // syntax check
fs.mkdirSync(path.join(root, 'dist'), { recursive: true }); fs.writeFileSync(path.join(root, 'dist', 'index.html'), html);
console.log('dist/index.html', (html.length / 1024).toFixed(0) + ' KB');
