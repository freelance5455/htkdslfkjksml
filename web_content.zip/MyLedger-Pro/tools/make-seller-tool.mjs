// Creates seller-only/License-Maker.html — a double-click page for the SELLER to create license keys (no Node needed).
// It contains the PRIVATE key. Never give it to customers.
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const jwk = JSON.parse(fs.readFileSync(path.join(root, 'seller-only', 'private.jwk.json'), 'utf8'));
const logo = 'data:image/png;base64,' + fs.readFileSync(path.join(root, 'assets', 'logo-96.png')).toString('base64');
const html = `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>License Maker — سازنده لایسنس</title>
<style>body{margin:0;background:#0a0a0a;color:#f3efe6;font:16px/1.5 system-ui,"Segoe UI",Tahoma,sans-serif;padding:16px}main{max-width:640px;margin:auto}
h1{color:#f0cd73;font-size:1.3rem;display:flex;gap:12px;align-items:center}img{border-radius:12px}.warn{background:#2a1111;border:1px solid #5a2b2b;border-radius:12px;padding:10px 12px;color:#ff9b9b}
label{display:block;margin-block:10px;color:#a79f8d}input,textarea{width:100%;box-sizing:border-box;background:#0f0f0f;color:#f3efe6;border:1px solid #2c2c2c;border-radius:10px;padding:10px;font:inherit}
button{background:#d4a63a;color:#1a1405;font-weight:700;border:0;border-radius:10px;padding:10px 18px;font:inherit;font-weight:700;cursor:pointer;margin-block:10px;margin-inline-end:8px}button.alt{background:#1d1d1d;color:#f3efe6;border:1px solid #2c2c2c}
#out{direction:ltr;font-family:ui-monospace,Consolas,monospace;font-size:.8rem}.hist div{border-top:1px solid #2c2c2c;padding:6px 0;font-size:.85rem;color:#a79f8d}</style></head><body><main>
<h1><img src="${logo}" width="48" height="48" alt=""> License Maker / سازنده لایسنس</h1>
<p class="warn">⚠ محرمانه: این فایل کلید خصوصی شما را دارد. آن را به مشتری ندهید و در اینترنت قرار ندهید. / CONFIDENTIAL — contains your private signing key.</p>
<label>نام مشتری / Customer name<input id="name" maxlength="80"></label>
<label>ایمیل (اختیاری) / Email (optional)<input id="email" type="email" maxlength="120"></label>
<label>تاریخ انقضا (خالی = دائمی) / Expiry (empty = lifetime)<input id="exp" type="date"></label>
<fieldset style="border:1px solid #2c2c2c;border-radius:10px;margin-block:10px"><legend>بخش‌های مجاز / Sections included</legend>${["incomes","expenses","debts","shopping","goals","reminders","assistant","report"].map(v=>`<label style="display:inline-block;margin:4px 10px;color:#f3efe6"><input class="sec" type="checkbox" value="${v}" checked style="width:auto"> ${v}</label>`).join("")}<p style="color:#a79f8d;font-size:.85rem;margin:4px 10px">همه تیک‌دار = همهٔ بخش‌ها (حتی بخش‌های پولیِ آینده). / All checked = every section, including future paid ones.</p></fieldset>
<button id="go">ساخت کلید / Generate key</button><button class="alt" id="copy">کپی / Copy</button>
<textarea id="out" rows="5" readonly></textarea><p id="msg"></p><div class="hist" id="hist"></div></main>
<script>
const JWK=${JSON.stringify(jwk)};
const b64u=(b)=>btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\\+/g,'-').replace(/\\//g,'_').replace(/=+$/,'');
const enc=new TextEncoder(), $=(i)=>document.getElementById(i);
let hist=[];try{hist=JSON.parse(localStorage.getItem('lm_hist')||'[]')}catch{}
const draw=()=>{$('hist').innerHTML=hist.slice(0,30).map(h=>'<div>'+h.c+' — '+h.n.replace(/[<>&]/g,'')+(h.x?' → '+h.x:' (lifetime)')+'</div>').join('')};draw();
$('go').onclick=async()=>{const n=$('name').value.trim();if(!n){$('msg').textContent='نام لازم است / name required';return}
 const f=[...document.querySelectorAll('.sec:checked')].map(c=>c.value),all=document.querySelectorAll('.sec').length;
 const x=$('exp').value||0,p={p:'ML',n,...(f.length<all?{f}:{}),...($('email').value.trim()?{e:$('email').value.trim()}:{}),x,i:Date.now().toString(36),c:new Date().toISOString().slice(0,10)};
 const head='ML1.'+b64u(enc.encode(JSON.stringify(p)));
 const key=await crypto.subtle.importKey('jwk',JWK,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
 const sig=await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},key,enc.encode(head));
 $('out').value=head+'.'+b64u(sig);$('msg').textContent='✔';hist.unshift({c:p.c,n,x:p.x});try{localStorage.setItem('lm_hist',JSON.stringify(hist.slice(0,200)))}catch{}draw()};
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText($('out').value);$('msg').textContent='✔ copied'}catch{$('out').select();document.execCommand('copy')}};
</script></body></html>`;
fs.writeFileSync(path.join(root, 'seller-only', 'License-Maker.html'), html);
console.log('seller-only/License-Maker.html written');
