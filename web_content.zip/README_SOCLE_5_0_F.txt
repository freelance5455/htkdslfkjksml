CGD V117 — SOCLE 5.0-F
Intégration générale des versions 5.0-C, 5.0-D et 5.0-E.
Navigation principale : 9 rubriques.
Lancer les vérifications avec : npm test
Voir STAGE_5_0_F_INTEGRATION_GENERALE.md pour le périmètre de cette intégration.
