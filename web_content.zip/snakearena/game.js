(() => {
const $ = id => document.getElementById(id);
const cv = $('c'), ctx = cv.getContext('2d');
const W = 3200, FOOD_N = 1500, BOTS = 10;
const LVLS = [2, 0, 1, 2, 0, 1, 0, 2, 1, 0];
const NAMES = ['Viper','Mamba','Cobra','Python','Rattler','Anaconda','Taipan','Sidewinder','Boa','Adder'];
const R = (a, b) => a + Math.random() * (b - a);
let vw, vh, dpr, snakes = [], foods = [], drop = null, dropT = 10, P = null, king = null;
let over = true, cam = { x: W / 2, y: W / 2 }, last = 0, lbT = 0, wasKing = false, best = 0, tt;
try { best = +localStorage.getItem('snk_best') || 0; } catch (e) {}
const inp = { a: 0, boost: false };

function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 2); vw = innerWidth; vh = innerHeight;
  cv.width = vw * dpr; cv.height = vh * dpr;
}
addEventListener('resize', resize); resize();

const cell = (x, y) => String.fromCharCode(65 + Math.min(7, x / 400 | 0)) + (1 + Math.min(7, y / 400 | 0));
const rad = s => Math.min(8 + Math.sqrt(Math.max(s, 0)) * 0.5, 30);   // thickness grows with score
const cnt = s => Math.min(10 + Math.floor(s / 6), 400);                // length grows with score

function toast(t) {
  const e = $('toast'); e.textContent = t; e.classList.add('on');
  clearTimeout(tt); tt = setTimeout(() => e.classList.remove('on'), 2300);
}

let pt;
function popup(t, me) {
  const e = $('pop'); e.textContent = t; e.className = 'on' + (me ? ' me' : '');
  clearTimeout(pt); pt = setTimeout(() => { e.className = ''; }, 2800);
}

/* ---------- world ---------- */
function addFood(x, y, v, h) {
  h = h == null ? R(0, 360) : h;
  foods.push({ x, y, v, r: 2.5 + v * 0.8, c: 'hsl(' + h + ',90%,60%)' });
}
function fillFood() {
  while (foods.length < FOOD_N) {
    const q = Math.random(), v = q < .6 ? 2 : q < .88 ? 4 : 8;
    addFood(R(20, W - 20), R(20, W - 20), v);
  }
}
function spawnPos() {
  let p;
  for (let k = 0; k < 30; k++) {
    p = { x: R(300, W - 300), y: R(300, W - 300) };
    let ok = true;
    for (const o of snakes) {
      if (!o.alive) continue;
      for (let i = 0; i < o.segs.length; i += 6) {
        const dx = o.segs[i].x - p.x, dy = o.segs[i].y - p.y;
        if (dx * dx + dy * dy < 300 * 300) { ok = false; break; }
      }
      if (!ok) break;
    }
    if (ok) break;
  }
  return p;
}
function mk(name, hue, isP, score, lvl) {
  const p = spawnPos(), a = R(0, 6.283);
  const s = { name, hue, isP, a, score, alive: true, segs: [], boost: false, dr: 0, tgt: null, tt: 0, wa: a, ta: a, rs: 0, inv: 1.8, lvl: lvl || 0, en: 100, lock: false, bo: false, prey: null };
  s.r = rad(score);
  const g = Math.max(4.5, s.r * 0.6);
  for (let i = 0; i < cnt(score); i++) s.segs.push({ x: p.x - Math.cos(a) * i * g, y: p.y - Math.sin(a) * i * g });
  return s;
}

/* ---------- movement ---------- */
function step(s, dt, ta, turn) {
  let d = ta - s.a;
  while (d > Math.PI) d -= 6.283;
  while (d < -Math.PI) d += 6.283;
  s.a += Math.max(-turn * dt, Math.min(turn * dt, d));
  let b = s.boost && !s.lock && s.score > 20;       // boost needs energy
  if (b) { s.en -= 28 * dt; if (s.en <= 0) { s.en = 0; s.lock = true; b = false; } }
  else { s.en = Math.min(100, s.en + 10 * dt); if (s.lock && s.en >= 30) s.lock = false; }
  s.bo = b;
  const sp = (b ? 2 : 1) * Math.max(125, 175 - (s.r - 8) * 1.2);
  const h = s.segs[0];
  h.x += Math.cos(s.a) * sp * dt; h.y += Math.sin(s.a) * sp * dt;
  const g = Math.max(4.5, s.r * 0.6);
  for (let i = 1; i < s.segs.length; i++) {
    const p = s.segs[i - 1], q = s.segs[i], dx = p.x - q.x, dy = p.y - q.y, dd = Math.hypot(dx, dy);
    if (dd > g) { q.x = p.x - dx / dd * g; q.y = p.y - dy / dd * g; }
  }
  if (b) {                             // boost burns score and leaves food behind
    s.score -= 9 * dt; s.dr += dt;
    if (s.dr > 0.4) { s.dr = 0; const t = s.segs[s.segs.length - 1]; addFood(t.x, t.y, 3, s.hue); }
  }
  const want = cnt(s.score);
  while (s.segs.length < want) s.segs.push({ x: s.segs[s.segs.length - 1].x, y: s.segs[s.segs.length - 1].y });
  while (s.segs.length > want && s.segs.length > 8) s.segs.pop();
  s.r += (rad(s.score) - s.r) * Math.min(1, dt * 4);
  if (s.inv > 0) s.inv -= dt;
}
function eat(s) {
  const h = s.segs[0], r2 = s.r + 14;
  for (let i = foods.length - 1; i >= 0; i--) {
    const f = foods[i], dx = f.x - h.x, dy = f.y - h.y, rr = r2 + f.r;
    if (dx * dx + dy * dy < rr * rr) { s.score += f.v; s.en = Math.min(100, s.en + f.v * 1.5); foods[i] = foods[foods.length - 1]; foods.pop(); }
  }
  if (drop) {
    const dx = drop.x - h.x, dy = drop.y - h.y, rr = s.r + 32;
    if (dx * dx + dy * dy < rr * rr) {
      s.score += 100; drop = null;
      popup(s.isP ? '\uD83D\uDCE6 You collected the Airdrop! +100' : '\uD83D\uDCE6 ' + s.name + ' collected the Airdrop +100', s.isP);
    }
  }
}
function kill(s) {
  if (!s.alive) return;
  const rank = snakes.filter(x => x.alive && x.score > s.score).length + 1;
  s.alive = false; s.rs = 2.5;
  const n = s.segs.length, v = Math.max(2, Math.round(s.score / (n / 2) * 0.8));
  for (let i = 0; i < n; i += 2) addFood(s.segs[i].x + R(-8, 8), s.segs[i].y + R(-8, 8), v, s.hue);
  if (s.isP) {
    over = true;
    if (s.score > best) { best = Math.floor(s.score); try { localStorage.setItem('snk_best', best); } catch (e) {} }
    $('gs').textContent = Math.floor(s.score); $('gb').textContent = best; $('gr').textContent = rank;
    setTimeout(() => { $('over').hidden = false; }, 700);
  }
}
function collide(s) {               // head touches another snake's body = die
  if (!s.alive || s.inv > 0) return;
  const h = s.segs[0];
  for (const o of snakes) {
    if (o === s || !o.alive) continue;
    const lim = s.r * 0.7 + o.r * 0.9, l2 = lim * lim;
    for (let i = 1; i < o.segs.length; i += 2) {
      const p = o.segs[i], dx = p.x - h.x, dy = p.y - h.y;
      if (dx * dx + dy * dy < l2) { kill(s); return; }
    }
  }
}

/* ---------- bot AI ---------- */
function danger(s, x, y) {
  if (x < 50 || y < 50 || x > W - 50 || y > W - 50) return true;
  for (const o of snakes) {
    if (!o.alive) continue;
    const lim = o.r + s.r + 10, l2 = lim * lim;
    for (let i = o === s ? 12 : 0; i < o.segs.length; i += 2) {
      const dx = o.segs[i].x - x, dy = o.segs[i].y - y;
      if (dx * dx + dy * dy < l2) return true;
    }
  }
  return false;
}
const LV = [   // 0 easy, 1 medium, 2 hard
  { turn: 2.6, look: 0.55, fr: [1], think: [0.5, 0.9], range: 240, pr: [0.8, -0.8] },
  { turn: 3.6, look: 1.0, fr: [0.5, 1], think: [0.25, 0.5], range: 380, pr: [0.8, -0.8, 1.5, -1.5, 2.4] },
  { turn: 5.2, look: 1.5, fr: [0.35, 0.65, 1], think: [0.1, 0.2], range: 620, pr: [0.6, -0.6, 1.2, -1.2, 1.8, -1.8, 2.6] }
];
function ai(s, dt) {
  const h = s.segs[0], lv = LV[s.lvl]; s.tt -= dt; s.boost = false;
  if (s.tt <= 0) {
    s.tt = R(lv.think[0], lv.think[1]); s.tgt = null; s.prey = null; let b = lv.range * lv.range;
    for (const f of foods) { const dx = f.x - h.x, dy = f.y - h.y, d = dx * dx + dy * dy; if (d < b) { b = d; s.tgt = f; } }
    if (drop) { const dx = drop.x - h.x, dy = drop.y - h.y, r = s.lvl ? 900 : 500; if (dx * dx + dy * dy < r * r) s.tgt = drop; }
    if (s.lvl && s.score > 40 && s.tgt !== drop) {            // medium and hard bots hunt
      let bd = (s.lvl === 2 ? 650 : 300) ** 2;
      for (const o of snakes) {
        if (o === s || !o.alive || o.score > s.score * (s.lvl === 2 ? 0.8 : 0.5)) continue;
        const ph = o.segs[0], dx = ph.x - h.x, dy = ph.y - h.y, d = dx * dx + dy * dy;
        if (d < bd) { bd = d; s.prey = o; }
      }
      if (s.prey && (s.lvl === 2 || Math.random() < 0.3)) s.tgt = null; else s.prey = null;
    }
    if (!s.tgt && !s.prey) s.wa += R(-1.2, 1.2);
  }
  let ta;
  if (s.prey && s.prey.alive) {                                // aim in front of the prey's head to cut it off
    const ph = s.prey.segs[0], d = Math.hypot(ph.x - h.x, ph.y - h.y), lead = Math.min(d * 0.7, 260);
    ta = Math.atan2(ph.y + Math.sin(s.prey.a) * lead - h.y, ph.x + Math.cos(s.prey.a) * lead - h.x);
    if (d < 380 && s.score > 70) s.boost = true;
  } else if (s.tgt) {
    ta = Math.atan2(s.tgt.y - h.y, s.tgt.x - h.x);
    if (s.tgt === drop && s.lvl && s.score > 70 && Math.hypot(drop.x - h.x, drop.y - h.y) > 250) s.boost = true;
  } else ta = s.wa;
  const L = (60 + s.r * 2.5) * lv.look * (s.bo ? 1.7 : 1), pr = a => lv.fr.some(f => danger(s, h.x + Math.cos(a) * L * f, h.y + Math.sin(a) * L * f));
  if (pr(s.a)) { for (const o of lv.pr) if (!pr(s.a + o)) { ta = s.a + o; break; } }
  else if (pr(ta)) ta = s.a;
  if (s.boost && (pr(s.a) || pr(ta))) s.boost = false;      // never boost into danger
  const m = 140 + s.r * 2;                                   // wall safety for every bot
  if (h.x < m || h.y < m || h.x > W - m || h.y > W - m) {
    ta = Math.atan2(W / 2 - h.y, W / 2 - h.x); s.boost = false; s.prey = null;
  }
  s.ta = ta;
}

/* ---------- update ---------- */
function update(dt) {
  dropT -= dt;
  if (dropT <= 0) {
    dropT = 10; drop = { x: R(300, W - 300), y: R(300, W - 300), t: 0 };
  }
  for (let i = 0; i < snakes.length; i++) {
    const s = snakes[i];
    if (!s.alive) {
      s.rs -= dt;
      if (!s.isP && s.rs <= 0) snakes[i] = mk(s.name, s.hue, false, s.lvl === 2 ? R(40, 100) : R(15, 60), s.lvl);
      continue;
    }
    if (s.isP) { s.boost = inp.boost; step(s, dt, inp.a, 5); }
    else { ai(s, dt); step(s, dt, s.ta, LV[s.lvl].turn); }
    const hd = s.segs[0];
    if (hd.x < s.r || hd.y < s.r || hd.x > W - s.r || hd.y > W - s.r) { kill(s); continue; }   // wall touch = death
    eat(s);
  }
  for (const s of snakes) collide(s);
  fillFood();
  if (drop) drop.t += dt;
  lbT -= dt; if (lbT <= 0) { lbT = 0.15; board(); }
  const ref = P && P.alive ? P : king;
  if (ref) {
    const h = ref.segs[0], k = ref === P ? 1 : Math.min(1, dt * 2);
    cam.x += (h.x - cam.x) * k; cam.y += (h.y - cam.y) * k;
  }
}
function board() {
  const a = snakes.filter(s => s.alive).sort((x, y) => y.score - x.score);
  king = a[0] || null;
  $('lb').innerHTML = a.map((s, i) =>
    '<li class="' + (s.isP ? 'me' : '') + '"><span>' + (i + 1) + '. ' + (i ? '' : '\uD83E\uDD34 ') +
    (s.isP ? '' : '<i style="color:' + ['#6fe08a', '#ffd84d', '#ff5d5d'][s.lvl] + '">\u25CF</i> ') + s.name.replace(/[<>&]/g, '') + '</span><b>' + Math.floor(s.score) + '</b></li>').join('');
  if (P && P.alive) {
    $('sc').textContent = 'Score ' + Math.floor(P.score);
    $('enf').style.width = P.en + '%'; $('boost').classList.toggle('lock', P.lock);
    const isK = king === P;
    if (isK && !wasKing) toast('\uD83E\uDD34 You are the King!');
    wasKing = isK;
  }
  $('sub').textContent = 'Best ' + best + ' \u00B7 Airdrop ' + (drop ? 'at ' + cell(drop.x, drop.y) + ' \u00B7 ' : '') + 'next ' + Math.ceil(dropT) + 's';
}

/* ---------- render ---------- */
function circle(x, y, r) { ctx.beginPath(); ctx.arc(x, y, r, 0, 6.283); ctx.fill(); }
function drawSnake(s, z) {
  const sg = s.segs;
  ctx.lineCap = ctx.lineJoin = 'round';
  ctx.globalAlpha = s.inv > 0 && Math.floor(s.inv * 8) % 2 ? 0.45 : 1;
  ctx.beginPath(); ctx.moveTo(sg[0].x, sg[0].y);
  for (let i = 1; i < sg.length; i++) ctx.lineTo(sg[i].x, sg[i].y);
  if (s.isP) { ctx.strokeStyle = '#fff'; ctx.lineWidth = s.r * 2 + 8; ctx.stroke(); }
  ctx.strokeStyle = 'hsl(' + s.hue + ',60%,22%)'; ctx.lineWidth = s.r * 2 + 4; ctx.stroke();
  ctx.strokeStyle = 'hsl(' + s.hue + ',80%,' + (s.bo ? 66 : 52) + '%)'; ctx.lineWidth = s.r * 2; ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = s.r * 0.8; ctx.stroke();
  const h = sg[0], ca = Math.cos(s.a), sa = Math.sin(s.a), er = s.r * 0.38;
  for (const k of [-1, 1]) {
    const ex = h.x + ca * s.r * 0.35 - sa * k * s.r * 0.5, ey = h.y + sa * s.r * 0.35 + ca * k * s.r * 0.5;
    ctx.fillStyle = '#fff'; circle(ex, ey, er);
    ctx.fillStyle = '#111'; circle(ex + ca * er * 0.35, ey + sa * er * 0.35, er * 0.55);
  }
  ctx.globalAlpha = 1;
  ctx.textAlign = 'center'; ctx.font = 'bold ' + 13 / z + 'px sans-serif';
  ctx.lineWidth = 3 / z; ctx.strokeStyle = '#000'; ctx.fillStyle = '#fff';
  const ny = h.y - s.r - 8 / z;
  ctx.strokeText(s.name, h.x, ny); ctx.fillText(s.name, h.x, ny);
  if (s === king) { ctx.font = 28 / z + 'px serif'; ctx.fillText('\uD83D\uDC51', h.x, ny - 10 / z); }
}
function arrow(a, rr, col, label) {
  const x = vw / 2 + Math.cos(a) * rr, y = vh / 2 + Math.sin(a) * rr;
  ctx.save(); ctx.translate(x, y); ctx.rotate(a);
  ctx.fillStyle = col; ctx.strokeStyle = '#000'; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(18, 0); ctx.lineTo(-10, -13); ctx.lineTo(-3, 0); ctx.lineTo(-10, 13); ctx.closePath();
  ctx.stroke(); ctx.fill(); ctx.restore();
  ctx.font = 'bold 12px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = col;
  ctx.fillText(label, x + Math.cos(a) * 40, y + Math.sin(a) * 40 + 4);
}
function render() {
  const pr = P && P.alive ? P.r : 10;
  const z = Math.min(vw, vh) / 520 * Math.max(0.6, 1 - (pr - 8) / 80);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = '#050d14'; ctx.fillRect(0, 0, vw, vh);
  ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * (vw / 2 - cam.x * z), dpr * (vh / 2 - cam.y * z));
  ctx.fillStyle = '#0d1c28'; ctx.fillRect(0, 0, W, W);
  const x0 = cam.x - vw / 2 / z - 60, x1 = cam.x + vw / 2 / z + 60, y0 = cam.y - vh / 2 / z - 60, y1 = cam.y + vh / 2 / z + 60;
  ctx.strokeStyle = '#14293a'; ctx.lineWidth = 2; ctx.beginPath();
  for (let x = Math.max(0, Math.ceil(x0 / 120) * 120); x <= Math.min(W, x1); x += 120) { ctx.moveTo(x, Math.max(0, y0)); ctx.lineTo(x, Math.min(W, y1)); }
  for (let y = Math.max(0, Math.ceil(y0 / 120) * 120); y <= Math.min(W, y1); y += 120) { ctx.moveTo(Math.max(0, x0), y); ctx.lineTo(Math.min(W, x1), y); }
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,77,94,.13)';
  ctx.fillRect(0, 0, W, 70); ctx.fillRect(0, W - 70, W, 70); ctx.fillRect(0, 70, 70, W - 140); ctx.fillRect(W - 70, 70, 70, W - 140);
  ctx.strokeStyle = '#ff4d5e'; ctx.lineWidth = 14; ctx.strokeRect(0, 0, W, W);
  for (const f of foods) {
    if (f.x < x0 || f.x > x1 || f.y < y0 || f.y > y1) continue;
    ctx.fillStyle = f.c; circle(f.x, f.y, f.r);
  }
  if (drop) {
    const pu = 1 + 0.15 * Math.sin(drop.t * 6);
    ctx.strokeStyle = '#5de1ff'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(drop.x, drop.y, 36 * pu, 0, 6.283); ctx.stroke();
    ctx.font = '40px serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.fillText('\uD83D\uDCE6', drop.x, drop.y + 14);
    ctx.font = 'bold 14px sans-serif'; ctx.fillStyle = '#5de1ff'; ctx.fillText('+100', drop.x, drop.y - 44);
  }
  for (const s of snakes.filter(s => s.alive).sort((a, b) => a.score - b.score)) drawSnake(s, z);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  if (P && P.alive) {
    const h = P.segs[0];
    if (king && king !== P) {
      const k = king.segs[0], a = Math.atan2(k.y - h.y, k.x - h.x);
      arrow(a, 70 + P.r * z * 2, '#ffd84d', '\uD83D\uDC51 ' + Math.round(Math.hypot(k.x - h.x, k.y - h.y) / 10) + 'm');
    }
    if (drop) {
      const a = Math.atan2(drop.y - h.y, drop.x - h.x);
      arrow(a, 110 + P.r * z * 2, '#5de1ff', '\uD83D\uDCE6 ' + Math.round(Math.hypot(drop.x - h.x, drop.y - h.y) / 10) + 'm');
    }
  }
  minimap();
}

function minimap() {
  const S = Math.min(120, vh * 0.32), x = 12, y = 68, k = S / W;
  ctx.fillStyle = 'rgba(5,13,20,.65)'; ctx.fillRect(x, y, S, S);
  ctx.strokeStyle = 'rgba(255,255,255,.12)'; ctx.lineWidth = 1; ctx.beginPath();
  for (let i = 1; i < 8; i++) { const a = S * i / 8; ctx.moveTo(x + a, y); ctx.lineTo(x + a, y + S); ctx.moveTo(x, y + a); ctx.lineTo(x + S, y + a); }
  ctx.stroke(); ctx.strokeStyle = '#ff4d5e'; ctx.strokeRect(x, y, S, S);
  for (const s of snakes) {
    if (!s.alive) continue;
    const h = s.segs[0];
    ctx.fillStyle = s === king ? '#ffd84d' : s === P ? '#fff' : 'hsl(' + s.hue + ',70%,55%)';
    ctx.beginPath(); ctx.arc(x + h.x * k, y + h.y * k, s === P || s === king ? 3.5 : 2.2, 0, 6.283); ctx.fill();
  }
  ctx.textAlign = 'center';
  if (drop) {
    const dx = x + drop.x * k, dy = y + drop.y * k, pu = 5 + 2 * Math.sin(drop.t * 6);
    ctx.strokeStyle = '#5de1ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(dx, dy, pu + 3, 0, 6.283); ctx.stroke();
    ctx.font = '13px serif'; ctx.fillStyle = '#fff'; ctx.fillText('\uD83D\uDCE6', dx, dy + 5);
    ctx.font = 'bold 11px sans-serif'; ctx.fillStyle = '#5de1ff';
    ctx.fillText('Airdrop ' + cell(drop.x, drop.y), x + S / 2, y + S + 14);
  }
}

/* ---------- controls ---------- */
const joy = $('joy'), knob = $('knob'); let jd = false;
function jset(e) {
  const b = joy.getBoundingClientRect(), dx = e.clientX - (b.left + b.width / 2), dy = e.clientY - (b.top + b.height / 2);
  const d = Math.hypot(dx, dy), m = b.width / 2 - 14;
  if (d > 8) inp.a = Math.atan2(dy, dx);
  const k = Math.min(d, m) / (d || 1);
  knob.style.transform = 'translate(' + dx * k + 'px,' + dy * k + 'px)';
}
joy.addEventListener('pointerdown', e => { jd = true; joy.setPointerCapture(e.pointerId); jset(e); });
joy.addEventListener('pointermove', e => { if (jd) jset(e); });
const jend = () => { jd = false; knob.style.transform = 'translate(0,0)'; };
joy.addEventListener('pointerup', jend); joy.addEventListener('pointercancel', jend);
const bt = $('boost');
const bset = v => { inp.boost = v; bt.classList.toggle('on', v); };
bt.addEventListener('pointerdown', e => { bt.setPointerCapture(e.pointerId); bset(true); });
bt.addEventListener('pointerup', () => bset(false)); bt.addEventListener('pointercancel', () => bset(false));
addEventListener('contextmenu', e => e.preventDefault());
const keys = {};
function kupdate() {
  const x = (keys.ArrowRight || keys.d ? 1 : 0) - (keys.ArrowLeft || keys.a ? 1 : 0);
  const y = (keys.ArrowDown || keys.s ? 1 : 0) - (keys.ArrowUp || keys.w ? 1 : 0);
  if (x || y) inp.a = Math.atan2(y, x);
  bset(!!keys[' ']);
}
addEventListener('keydown', e => { keys[e.key] = true; kupdate(); });
addEventListener('keyup', e => { keys[e.key] = false; kupdate(); });

/* ---------- start / loop ---------- */
function world() {
  snakes = []; foods = []; drop = null; dropT = 10; wasKing = false;
  fillFood();
  for (let i = 0; i < BOTS; i++) snakes.push(mk(NAMES[i], (i * 36 + 10) % 360, false, R(15, 150), LVLS[i]));
}
function start() {
  world();
  const nm = ($('name').value || 'You').trim().slice(0, 12) || 'You';
  P = mk(nm, 175, true, 10); snakes.push(P);
  over = false; inp.a = P.a; jend();
  try {
    const el = document.documentElement;
    (el.requestFullscreen ? el.requestFullscreen() : Promise.resolve()).then(() => screen.orientation.lock('landscape')).catch(() => {});
  } catch (e) {}
  $('start').hidden = true; $('over').hidden = true;
  toast('Eat food, avoid bodies, reach #1 \uD83E\uDD34');
}
$('play').onclick = start; $('again').onclick = start;
function loop(t) {
  const dt = Math.min(0.05, (t - last) / 1000 || 0); last = t;
  update(dt); render(); requestAnimationFrame(loop);
}
world(); board();
requestAnimationFrame(loop);
})();
