LEVELUP — PHONE-ONLY STARTER
============================

This is a first prototype of LevelUp built as a mobile-friendly web app.
It uses HTML, CSS and JavaScript, so you can edit and preview it on Android
with Acode or another editor that supports HTML preview.

START ON YOUR ANDROID PHONE
1. Download LevelUpPhoneStarter.zip and extract it using your phone's Files app.
2. Install Acode from the official site: https://acode.app/
3. In Acode, open the extracted folder and open index.html.
4. Use Acode's Preview/Open in browser option to run it.
5. Try completing quests, adding a custom quest, changing your hunter name,
   and refreshing the page. Progress should persist in the same browser.
6. Keep the extracted folder somewhere safe. This is your editable project.

IMPORTANT
- This is a web prototype, not a signed Android APK and not ready for Play Store.
- Progress is stored in local browser storage on that device/browser.
- Clearing browser/site data may erase progress; no cloud sync or account system exists yet.
- The streak is a simple prototype and should be tested further before release.
- No ads, payments, accounts, analytics, or backend are included.
- Do not use the Solo Leveling name, logos, artwork, or other copyrighted assets in a commercial release without appropriate rights. "LevelUp" is a working name; check name/trademark availability before publishing.
- To publish a real Android app, later package/test it with an Android-compatible build workflow and comply with current Google Play and privacy requirements.

FEATURES
- Dark RPG-style dashboard
- Five starter daily quests
- XP, levels and ranks
- Custom daily quests
- Local saving via localStorage
- Simple streak tracking
- Safe recovery missions that do not deduct XP
