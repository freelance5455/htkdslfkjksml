const T={
ar:{tagline:"رفيقك إلى الطمأنينة",welcome:"السلام عليكم ورحمة الله",welcomeSub:"اجعل لقلبك نصيباً من القرآن والذكر كل يوم",prayerTimes:"أوقات الصلاة",locationPrompt:"حدّد موقعك لحساب المواقيت محلياً",locate:"تحديد موقعي",duaTitle:"دعاء لأهل فلسطين وللمستضعفين",explore:"استكشف التطبيق",quran:"القرآن الكريم",quranSub:"السور والقراءة",adhkar:"الأذكار",adhkarSub:"أذكار مختارة",tasbih:"المسبحة",tasbihSub:"عداد التسبيح",qibla:"اتجاه القبلة",qiblaSub:"احسب اتجاه مكة",settings:"الإعدادات",settingsSub:"اللغة والموقع",home:"الرئيسية",quranNotice:"أُدرج النص العربي بالرسم العثماني، وأضيفت ترجمتا المعاني الإنجليزية والتركية من الملفين المرفوعين. تم التحقق من وجود ٦٢٣٦ مدخلاً في كل ملف ومطابقة أرقام السور والآيات بينها. الترجمة بيان لمعاني الآيات وليست نص القرآن العربي.",tasbihHint:"اضغط للعدّ",reset:"إعادة التصفير",qiblaDesc:"احصل على موقعك لحساب اتجاه القبلة من الشمال الحقيقي.",calculate:"حساب الاتجاه",language:"لغة التطبيق",offline:"العمل دون إنترنت",offlineDesc:"الواجهة والميزات الموجودة في هذه الحزمة تعمل محلياً. يلزم فتح التطبيق مرة عبر خادم/حزمة APK لتثبيت ملفات التخزين المؤقت.",prayerMethod:"طريقة حساب الصلاة",prayerMethodDesc:"حساب فلكي محلي مبدئي؛ راجع الطريقة المعتمدة في بلدك واضبطها قبل الاعتماد.",locationDenied:"تعذّر تحديد الموقع. اسمح بإذن الموقع أو استخدم مدينة/إحداثيات لاحقاً.",locationFound:"تم تحديد الموقع",next:"الصلاة القادمة",noLocation:"حدّد موقعك لعرض المواقيت",fajr:"الفجر",sunrise:"الشروق",dhuhr:"الظهر",asr:"العصر",maghrib:"المغرب",isha:"العشاء",surah:"سورة",ayahs:"آية",morning:"أذكار الصباح",evening:"أذكار المساء",afterPrayer:"أذكار بعد الصلاة"},
tr:{tagline:"Huzura yol arkadaşınız",welcome:"Selâmün aleyküm ve rahmetullah",welcomeSub:"Her gün kalbinize Kur’an ve zikirden pay ayırın",prayerTimes:"Namaz vakitleri",locationPrompt:"Vakitleri yerel hesaplamak için konumunuzu belirleyin",locate:"Konumumu bul",duaTitle:"Filistin ve mazlumlar için dua",explore:"Uygulamayı keşfedin",quran:"Kur’an-ı Kerim",quranSub:"Sureler ve okuma",adhkar:"Zikirler",adhkarSub:"Seçilmiş zikirler",tasbih:"Tesbih",tasbihSub:"Zikir sayacı",qibla:"Kıble yönü",qiblaSub:"Mekke yönünü hesapla",settings:"Ayarlar",settingsSub:"Dil ve konum",home:"Ana sayfa",quranNotice:"Kur’an metni Osmanlı hattıyla eklenmiştir. İngilizce ve Türkçe meal dosyaları yüklenen kaynak dosyalardan alınmıştır; her birinde 6236 ayet anahtarı kontrol edilmiştir. Mealler Kur’an’ın Arapça metninin yerine geçmez.",tasbihHint:"Saymak için dokunun",reset:"Sıfırla",qiblaDesc:"Gerçek kuzeye göre kıble yönünü hesaplamak için konumunuzu alın.",calculate:"Yönü hesapla",language:"Uygulama dili",offline:"Çevrimdışı kullanım",offlineDesc:"Bu paketteki arayüz ve mevcut özellikler yerel çalışır. Önbelleği kurmak için uygulama bir kez sunucu/APK üzerinden açılmalıdır.",prayerMethod:"Namaz hesaplama yöntemi",prayerMethodDesc:"Başlangıç niteliğinde yerel astronomik hesaplama; kullanmadan önce ülkenizdeki yöntemi kontrol edin.",locationDenied:"Konum alınamadı. Konum izni verin.",locationFound:"Konum alındı",next:"Sonraki namaz",noLocation:"Vakitleri görmek için konumunuzu belirleyin",fajr:"İmsak",sunrise:"Güneş",dhuhr:"Öğle",asr:"İkindi",maghrib:"Akşam",isha:"Yatsı",surah:"Sure",ayahs:"ayet",morning:"Sabah zikirleri",evening:"Akşam zikirleri",afterPrayer:"Namaz sonrası zikirler"},
en:{tagline:"Your companion towards tranquility",welcome:"Peace be upon you",welcomeSub:"Give your heart a share of Qur’an and remembrance every day",prayerTimes:"Prayer times",locationPrompt:"Set your location to calculate times locally",locate:"Find my location",duaTitle:"Prayer for Palestine and the oppressed",explore:"Explore the app",quran:"The Holy Qur’an",quranSub:"Surahs and reading",adhkar:"Remembrance",adhkarSub:"Selected adhkar",tasbih:"Tasbih",tasbihSub:"Dhikr counter",qibla:"Qibla direction",qiblaSub:"Calculate direction to Makkah",settings:"Settings",settingsSub:"Language and location",home:"Home",quranNotice:"The Uthmani Arabic text and English/Turkish meaning translations from the supplied files are included. Each file contains 6,236 verse entries with matching surah and verse keys. Translations convey meanings and are not the Arabic Qur’an text.",tasbihHint:"Tap to count",reset:"Reset",qiblaDesc:"Use your location to calculate the Qibla bearing from true north.",calculate:"Calculate direction",language:"App language",offline:"Offline use",offlineDesc:"The interface and features in this package run locally. Open the app once through a server/APK to install cached files.",prayerMethod:"Prayer calculation method",prayerMethodDesc:"Preliminary local astronomical calculation; verify your local authority’s method before relying on it.",locationDenied:"Could not get location. Please allow location access.",locationFound:"Location found",next:"Next prayer",noLocation:"Set your location to show prayer times",fajr:"Fajr",sunrise:"Sunrise",dhuhr:"Dhuhr",asr:"Asr",maghrib:"Maghrib",isha:"Isha",surah:"Surah",ayahs:"verses",morning:"Morning adhkar",evening:"Evening adhkar",afterPrayer:"After-prayer adhkar"}
};
const surahsAr=["الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"];
const adhkar={
ar:[["morning","أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير."],["morning","اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور."],["evening","أمسينا وأمسى الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير."],["evening","اللهم بك أمسينا وبك أصبحنا وبك نحيا وبك نموت وإليك المصير."],["afterPrayer","أستغفر الله (ثلاثاً)، اللهم أنت السلام ومنك السلام، تباركت يا ذا الجلال والإكرام."]],
tr:[["morning","Sabaha eriştik; mülk Allah’ındır. Hamd Allah’a mahsustur. Allah’tan başka ilah yoktur; O tektir, ortağı yoktur."],["morning","Allah’ım, Senin yardımınla sabaha erdik, Senin yardımınla akşama erdik; Senin yardımınla yaşar ve ölürüz."],["evening","Akşama eriştik; mülk Allah’ındır. Hamd Allah’a mahsustur. Allah’tan başka ilah yoktur; O tektir, ortağı yoktur."],["evening","Allah’ım, Senin yardımınla akşama erdik ve sabaha erdik; Senin yardımınla yaşar ve ölürüz."],["afterPrayer","Allah’tan bağışlanma dilerim. Allah’ım, Sen es-Selâm’sın; esenlik Sendendir."]],
en:[["morning","We have entered the morning and all dominion belongs to Allah. Praise be to Allah; none has the right to be worshipped but Allah alone."],["morning","O Allah, by You we enter the morning and by You we enter the evening; by You we live and by You we die."],["evening","We have entered the evening and all dominion belongs to Allah. Praise be to Allah; none has the right to be worshipped but Allah alone."],["evening","O Allah, by You we enter the evening and by You we enter the morning; by You we live and by You we die."],["afterPrayer","I ask Allah for forgiveness (three times). O Allah, You are Peace and from You is peace."]]
};
let lang=localStorage.getItem("huda-lang")||"ar", coords=null, counter=Number(localStorage.getItem("huda-count")||0);
const $=id=>document.getElementById(id), tr=k=>T[lang][k]||k;
function setLang(l){lang=l;localStorage.setItem("huda-lang",l);document.documentElement.lang=l;document.documentElement.dir=l==="ar"?"rtl":"ltr";document.querySelectorAll("[data-i18n]").forEach(e=>e.textContent=tr(e.dataset.i18n));$("language").value=l;$("language2").value=l;renderSurahs();renderAdhkar();renderPrayer();if(coords) $("locationLabel").textContent=tr("locationFound");}
$("language").addEventListener("change",e=>setLang(e.target.value));$("language2").addEventListener("change",e=>setLang(e.target.value));
function show(id){document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===id));document.querySelectorAll("footer button").forEach(b=>b.classList.toggle("active",b.dataset.tab===id));}
document.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>show(b.dataset.open));document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>show(b.dataset.tab));document.querySelectorAll("[data-home]").forEach(b=>b.onclick=()=>show("home"));
let quranData=null;
let translationMode="ar", translations={en:null,tr:null};
function renderSurahs(){
 const box=$("surahList");
 if(!quranData){box.textContent=lang==="ar"?"جارٍ تحميل نص المصحف…":lang==="tr"?"Kur’an metni yükleniyor…":"Loading Qur’an text…";return;}
 box.innerHTML="";
 surahsAr.forEach((name,i)=>{
  const verses=quranData[i+1]||[],btn=document.createElement("button");
  btn.className="surah-btn";btn.type="button";
  const title=document.createElement("b");title.textContent=(i+1)+". "+name;
  const count=document.createElement("span");count.className="small";count.textContent=verses.length+" "+tr("ayahs");
  btn.append(title,count);btn.addEventListener("click",()=>openSurah(i+1));box.append(btn);
 });
}
async function loadTranslations(){
 for(const code of ["en","tr"]){
  try{const r=await fetch(`./data/translation-${code}.json`);if(!r.ok)continue;translations[code]=await r.json();}
  catch(_){translations[code]=null;}
 }
 updateTranslationStatus();
}
function updateTranslationStatus(){
 const el=$("translationStatus");if(!el)return;
 if(translationMode==="ar"){el.textContent=lang==="ar"?"النص العربي معروض. اختر لغة لإظهار الترجمة عند توفر ملفها.":"Arabic text is shown. Choose English or Turkish to display the uploaded meaning translation.";return;}
 el.textContent=translations[translationMode]?(translationMode==="en"?"English translation loaded.":"Türkçe meal yüklendi."):(lang==="ar"?"تعذّر تحميل ملف الترجمة؛ تحقق من مجلد data.":"Translation file could not be loaded; check the data folder.");
}
$("translationMode").addEventListener("change",e=>{translationMode=e.target.value;updateTranslationStatus();const current=Number(localStorage.getItem("huda-last-surah")||1);if($("quranReader").style.display!=="none")openSurah(current);});
function openSurah(num){
 if(!quranData||!quranData[num])return;
 const name=surahsAr[num-1],verses=quranData[num];
 const previousSurah=Number(localStorage.getItem("huda-last-surah")||0); const previousAyah=Number(localStorage.getItem("huda-last-ayah")||1);
 localStorage.setItem("huda-last-surah",String(num));
 $("surahList").style.display="none";$("quranReader").style.display="block";
 $("readerTitle").textContent=name;$("readerMeta").textContent=verses.length+" "+tr("ayahs");
 const box=$("verseList");box.innerHTML="";
 verses.forEach(v=>{
  const row=document.createElement("div");row.className="verse";row.id=`ayah-${num}-${v.n}`;
  const arabic=document.createElement("div");arabic.className="verse-ar";arabic.append(document.createTextNode(v.t+" "));
  const badge=document.createElement("span");badge.className="verse-num";badge.textContent=v.n;arabic.append(badge);row.append(arabic);
  if(translationMode!=="ar"){
   const key=`${num}:${v.n}`, translated=translations[translationMode]?.[key];
   if(translated){const t=document.createElement("div");t.className="verse-translation";t.lang=translationMode;t.textContent=translated;row.append(t);}
  }
  const tools=document.createElement("div");tools.style.cssText="display:flex;justify-content:flex-end;gap:8px;margin-top:6px";
  const fav=document.createElement("button");fav.className="action secondary";fav.textContent=isFavorite(num,v.n)?"★ إزالة من المفضلة":"☆ حفظ في المفضلة";fav.onclick=()=>{toggleFavorite(num,v.n);fav.textContent=isFavorite(num,v.n)?"★ إزالة من المفضلة":"☆ حفظ في المفضلة";renderFavorites();};tools.append(fav);row.append(tools);box.append(row);
 });
 const savedAyah=previousSurah===num?previousAyah:1;
 window.scrollTo({top:0,behavior:"smooth"});
 if(Number(localStorage.getItem("huda-last-surah"))===num && savedAyah>1){setTimeout(()=>document.getElementById(`ayah-${num}-${savedAyah}`)?.scrollIntoView({block:"start",behavior:"smooth"}),120);}
}
function backToSurahs(){$("quranReader").style.display="none";$("surahList").style.display="block";window.scrollTo({top:0,behavior:"smooth"});}
$("backSurahs").addEventListener("click",backToSurahs);
async function loadQuran(){
 try{const res=await fetch("./data/quran-uthmani.json");if(!res.ok)throw new Error("Quran data unavailable");quranData=await res.json();renderSurahs();
  const last=Number(localStorage.getItem("huda-last-surah")||0);if(last>=1&&last<=114){/* محفوظة للعودة لاحقاً دون فتح مفاجئ */}
 }catch(e){$("surahList").textContent=lang==="ar"?"تعذّر تحميل ملف القرآن. تأكد من وجود مجلد data داخل التطبيق.":"Could not load Qur’an data. Check the app data folder.";}
}
function renderAdhkar(){
 const a=adhkar[lang], labels={ar:{morning:"أذكار الصباح",evening:"أذكار المساء",afterPrayer:"أذكار بعد الصلاة",count:"العدد",reset:"تصفير"},tr:{morning:"Sabah zikirleri",evening:"Akşam zikirleri",afterPrayer:"Namaz sonrası",count:"Sayı",reset:"Sıfırla"},en:{morning:"Morning adhkar",evening:"Evening adhkar",afterPrayer:"After-prayer adhkar",count:"Count",reset:"Reset"}}[lang];
 const saved=JSON.parse(localStorage.getItem("huda-adhkar-counts")||"{}");
 $("adhkarList").innerHTML=a.map(([cat,txt],i)=>{const key=lang+":"+i;return `<div class="listitem" style="padding:14px 0;border-bottom:1px solid #e8e2d4"><b>${labels[cat]||cat}</b><div style="line-height:2;margin:9px 0">${txt}</div><div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap"><button class="action" data-dh-count="${key}">＋</button><strong id="dh-${i}">${saved[key]||0}</strong><small>${labels.count}</small><button class="action secondary" data-dh-reset="${key}" data-dh-id="${i}">${labels.reset}</button></div></div>`}).join("");
 $("adhkarList").querySelectorAll("[data-dh-count]").forEach(b=>b.onclick=()=>{const k=b.dataset.dhCount;const v=JSON.parse(localStorage.getItem("huda-adhkar-counts")||"{}");v[k]=(v[k]||0)+1;localStorage.setItem("huda-adhkar-counts",JSON.stringify(v));$("dh-"+k.split(":")[1]).textContent=v[k];});
 $("adhkarList").querySelectorAll("[data-dh-reset]").forEach(b=>b.onclick=()=>{const k=b.dataset.dhReset,v=JSON.parse(localStorage.getItem("huda-adhkar-counts")||"{}");v[k]=0;localStorage.setItem("huda-adhkar-counts",JSON.stringify(v));$("dh-"+b.dataset.dhId).textContent="0";});
}
const tasbihPhrases={ar:["سُبْحَانَ اللَّه","الْحَمْدُ لِلَّه","اللَّهُ أَكْبَر","أَسْتَغْفِرُ اللَّه"],tr:["Sübhanallah","Elhamdülillah","Allahu ekber","Estağfirullah"],en:["SubhanAllah","Alhamdulillah","Allahu Akbar","Astaghfirullah"]};
const phraseSelect=document.createElement("select");phraseSelect.id="tasbihPhrase";phraseSelect.className="action secondary";phraseSelect.style.margin="12px auto";tasbihPhrases[lang].forEach((x,i)=>{const o=document.createElement("option");o.value=i;o.textContent=x;phraseSelect.append(o)});$("bead").before(phraseSelect);phraseSelect.onchange=()=>{$("bead").textContent=tasbihPhrases[lang][Number(phraseSelect.value)]};
$("bead").onclick=()=>{counter++;$("count").textContent=counter;localStorage.setItem("huda-count",counter)};$("reset").onclick=()=>{counter=0;$("count").textContent=0;localStorage.setItem("huda-count",0)};$("count").textContent=counter;
const prayerKeys=["fajr","sunrise","dhuhr","asr","maghrib","isha"];
const prayerOffsetKeys=["fajr","sunrise","dhuhr","asr","maghrib","isha"];
let prayerOffsets=(()=>{try{const v=JSON.parse(localStorage.getItem("huda-prayer-offsets")||"{}");return Object.fromEntries(prayerOffsetKeys.map(k=>[k,Number.isFinite(Number(v[k]))?Math.max(-30,Math.min(30,Math.trunc(Number(v[k])))):0]));}catch{return Object.fromEntries(prayerOffsetKeys.map(k=>[k,0]));}})();
function adjustedPrayerTimes(times){return times.map((t,i)=>Number.isFinite(t)?((t+prayerOffsets[prayerOffsetKeys[i]]+1440)%1440):t);}
function savePrayerOffsets(){localStorage.setItem("huda-prayer-offsets",JSON.stringify(prayerOffsets));}

function rad(d){return d*Math.PI/180} function deg(r){return r*180/Math.PI}
function dayOfYear(d){return Math.floor((Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())-Date.UTC(d.getFullYear(),0,0))/86400000)}
function daysInYear(d){return new Date(d.getFullYear(),1,29).getMonth()===1?366:365}
const prayerMethods={MWL:{fajr:18,isha:17},EGYPT:{fajr:19.5,isha:17.5},UMM:{fajr:18.5,isha:0,ishaInterval:90},TURKEY:{fajr:18,isha:17},NORTH:{fajr:15,isha:15}};
let prayerMethod=localStorage.getItem("huda-prayer-method")||"AUTO", selectedCountryCode=localStorage.getItem("huda-country-code")||"", asrFactor=Number(localStorage.getItem("huda-asr-factor")||1), customFajr=Number(localStorage.getItem("huda-custom-fajr")||18),customIsha=Number(localStorage.getItem("huda-custom-isha")||17), notificationTimer=null, lastPrayerAlert="", selectedTimeZone=localStorage.getItem("huda-timezone")||"UTC", timezoneConfirmed=!!localStorage.getItem("huda-timezone");
const countryPrayerPresets={
 // Presets are limited to countries with an established, commonly used national/institutional calculation convention.
 tr:"TURKEY", eg:"EGYPT", sa:"UMM",
 // North America preset is a calculation convention, not a claim that every locality uses it.
 us:"NORTH", ca:"NORTH"
};
function effectivePrayerMethod(){
 if(prayerMethod!=="AUTO")return prayerMethod;
 return countryPrayerPresets[selectedCountryCode]||"MWL";
}
function autoPrayerMethodLabel(){
 const method=effectivePrayerMethod();
 const labels={TURKEY:"تقريب طريقة تركيا",EGYPT:"الهيئة المصرية العامة للمساحة",UMM:"أم القرى – مكة",NORTH:"طريقة أمريكا الشمالية",MWL:"رابطة العالم الإسلامي (افتراضي عند عدم وجود إعداد محلي موثوق)"};
 return labels[method]||"طريقة الحساب المختارة";
}
function updatePrayerMethodHint(){
 const el=$("autoMethodHint");
 if(el)el.textContent=prayerMethod==="AUTO"
  ? `الطريقة التلقائية الحالية: ${autoPrayerMethodLabel()}. إذا لم تتوفر قاعدة محلية موثوقة لبلدك، يستخدم التطبيق رابطة العالم الإسلامي كإعداد افتراضي؛ راجع تقويم مسجدك المحلي.`
  : "تم اعتماد الطريقة التي اخترتها يدويًا.";
}
function currentPrayerParams(){let active=effectivePrayerMethod();let p=prayerMethods[active]||prayerMethods.MWL;if(active==="CUSTOM")p={fajr:Number($("customFajr")?.value||18),isha:Number($("customIsha")?.value||17)};return p;}
function zonedParts(date,zone=selectedTimeZone){
 const parts=new Intl.DateTimeFormat("en-GB",{timeZone:zone,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"}).formatToParts(date);
 const out={};for(const p of parts)if(p.type!=="literal")out[p.type]=Number(p.value);return out;
}
function zoneOffsetMinutes(date,zone=selectedTimeZone){
 const p=zonedParts(date,zone);return (Date.UTC(p.year,p.month-1,p.day,p.hour,p.minute,p.second)-date.getTime())/60000;
}
function zonedDate(date,zone=selectedTimeZone){const p=zonedParts(date,zone);return new Date(p.year,p.month-1,p.day,12,0,0);}
async function resolveTimeZone(lat,lon){
 try{
  const u=`https://timeapi.io/api/Time/current/coordinate?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}`;
  const r=await fetch(u,{headers:{Accept:"application/json"}});if(!r.ok)throw new Error("timezone lookup failed");const d=await r.json();
  const z=d.timeZone||d.timezone||d.timeZoneId;if(!z)throw new Error("timezone missing");new Intl.DateTimeFormat("en",{timeZone:z});selectedTimeZone=z;timezoneConfirmed=true;localStorage.setItem("huda-timezone",z);return z;
 }catch(e){timezoneConfirmed=false;selectedTimeZone="UTC";localStorage.removeItem("huda-timezone");return null;}
}
function solar(lat,lon,date){
 const localDate=zonedDate(date),N=dayOfYear(localDate),g=2*Math.PI/daysInYear(date)*(N-1),eq=229.18*(0.000075+0.001868*Math.cos(g)-0.032077*Math.sin(g)-0.014615*Math.cos(2*g)-0.040849*Math.sin(2*g)),dec=0.006918-0.399912*Math.cos(g)+0.070257*Math.sin(g)-0.006758*Math.cos(2*g)+0.000907*Math.sin(2*g)-0.002697*Math.cos(3*g)+0.00148*Math.sin(3*g);
 // Convert UTC-based solar noon to the selected city's local clock time.
 // zoneOffsetMinutes() returns local minus UTC, so the offset MUST be added.
 const noon=720-4*lon-eq+zoneOffsetMinutes(date);
 function hourAngle(alt){const x=(Math.sin(rad(alt))-Math.sin(rad(lat))*Math.sin(dec))/(Math.cos(rad(lat))*Math.cos(dec));if(x < -1 || x > 1)return NaN;return Math.acos(x)*720/Math.PI;}
 const params=currentPrayerParams(), sunrise=noon-hourAngle(-0.833), sunset=noon+hourAngle(-0.833), dhuhr=noon+2, asrAltitude=deg(Math.atan(1/(asrFactor+Math.tan(Math.abs(rad(lat)-dec))))),asr=noon+hourAngle(asrAltitude);
 // For high-latitude summer dates where twilight angle does not occur, use a documented one-seventh-of-night fallback.
 const nightMinutes=Number.isFinite(sunrise)&&Number.isFinite(sunset)?1440-(sunset-sunrise):NaN;
 let fajr=noon-hourAngle(-params.fajr);
 if(!Number.isFinite(fajr)&&Number.isFinite(nightMinutes))fajr=sunrise-nightMinutes/7;
 let isha=params.ishaInterval? sunset+params.ishaInterval : noon+hourAngle(-params.isha);
 if(!Number.isFinite(isha)&&Number.isFinite(nightMinutes))isha=sunset+nightMinutes/7;
 return [fajr,sunrise,dhuhr,asr,sunset,isha].map(x=>Number.isFinite(x)?((x%1440)+1440)%1440:NaN);
}
function fmt(m){
 if(!Number.isFinite(m))return "—:—";
 const total=Math.floor(((m%1440)+1440)%1440),h24=Math.floor(total/60),mi=total%60;
 const h12=h24%12||12;
 const period=lang==="ar"?(h24<12?"صباحًا":"مساءً"):lang==="tr"?(h24<12?"ÖÖ":"ÖS"):(h24<12?"AM":"PM");
 return `${h12}:${String(mi).padStart(2,"0")} ${period}`;
}
function renderPrayer(){const grid=$("prayerGrid");if(!coords){grid.innerHTML=prayerKeys.map(k=>`<div class="prayer"><b>${tr(k)}</b><span>--:--</span></div>`).join("");$("nextPrayer").textContent=tr("noLocation");return}if(!timezoneConfirmed){grid.innerHTML=prayerKeys.map(k=>`<div class="prayer"><b>${tr(k)}</b><span>—:—</span></div>`).join("");$("nextPrayer").textContent="تعذّر تأكيد المنطقة الزمنية. حدّدها يدويًا قبل عرض المواقيت.";return}const now=new Date(),times=adjustedPrayerTimes(solar(coords.lat,coords.lon,now));grid.innerHTML=prayerKeys.map((k,i)=>`<div class="prayer"><b>${tr(k)}</b><span>${fmt(times[i])}</span></div>`).join("");const localNow=zonedParts(now),mins=localNow.hour*60+localNow.minute;let idx=times.findIndex((v,i)=>i!==1&&Number.isFinite(v)&&v>mins);if(idx<0)idx=0;$("nextPrayer").textContent=tr("next")+": "+tr(prayerKeys[idx])+" — "+fmt(times[idx]);schedulePrayerAlert(times);}
function persistCoords(){if(coords)localStorage.setItem("huda-coordinates",JSON.stringify(coords));}
function getLocation(cb){
 const label=$("locationLabel");
 localStorage.setItem("huda-location-mode","auto");
 if(!window.isSecureContext && location.protocol!=="file:"){
   label.textContent="يلزم تشغيل التطبيق عبر HTTPS أو داخل WebView مُعدّ بإذن الموقع؛ لن يعمل تحديد الموقع من صفحة HTTP عادية.";
   return;
 }
 if(!navigator.geolocation){label.textContent="ميزة تحديد الموقع غير متاحة في بيئة التشغيل هذه. استخدم إدخال الإحداثيات يدوياً من الإعدادات.";return;}
 label.textContent="جارٍ طلب إذن الموقع…";
 navigator.geolocation.getCurrentPosition(p=>{
   coords={lat:p.coords.latitude,lon:p.coords.longitude};persistCoords();
   label.textContent=`تم تحديد الموقع: ${coords.lat.toFixed(4)}, ${coords.lon.toFixed(4)}`;
   $("selectedCity").textContent="تم تحديد موقعك تلقائياً عبر GPS";
   Promise.all([resolveTimeZone(coords.lat,coords.lon),resolveCountryCode(coords.lat,coords.lon)]).then(()=>{renderPrayer();if(cb)cb();});
 },err=>{
   const messages={1:"تم رفض إذن الموقع. اسمح للتطبيق بالوصول إلى الموقع من إعدادات الهاتف ثم حاول مجدداً.",2:"تعذّر الوصول إلى إشارة الموقع. تحقق من تشغيل خدمات الموقع أو أدخل الإحداثيات يدوياً.",3:"انتهت مهلة تحديد الموقع. حاول مجدداً أو أدخل الإحداثيات يدوياً."};
   label.textContent=messages[err.code]||"تعذّر تحديد الموقع. أدخل الإحداثيات يدوياً من الإعدادات.";
 },{enableHighAccuracy:true,timeout:25000,maximumAge:600000});
}


async function resolveCountryCode(lat,lon){
 try{const u=`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&zoom=3&addressdetails=1`;const r=await fetch(u,{headers:{Accept:"application/json"}});if(!r.ok)throw new Error("reverse geocoding failed");const d=await r.json();const code=(d.address?.country_code||"").toLowerCase();if(code){selectedCountryCode=code;localStorage.setItem("huda-country-code",code);updatePrayerMethodHint();return code;}}catch(e){}return "";
}

let lastCitySearchAt=0;
async function searchCityByName(){
 const city=$("cityName").value.trim(),country=$("countryName").value.trim(),status=$("citySearchStatus"),results=$("cityResults");
 if(!city){status.textContent="اكتب اسم المدينة أولاً.";return;}
 // Public Nominatim has a strict request limit; this is a user-triggered search, never autocomplete.
 const wait=1100-(Date.now()-lastCitySearchAt);
 if(wait>0){status.textContent="انتظر لحظة قبل إجراء بحث جديد…";await new Promise(resolve=>setTimeout(resolve,wait));}
 lastCitySearchAt=Date.now();status.textContent="جارٍ البحث عالميًا عن المدينة…";results.innerHTML="";
 try{
  const params=new URLSearchParams({format:"jsonv2",addressdetails:"1",namedetails:"1",limit:"10", "accept-language":lang+",en"});
  // Use Nominatim's structured city/country query when both fields are supplied.
  if(country){params.set("city",city);params.set("country",country);}else{params.set("q",city);}
  const url="https://nominatim.openstreetmap.org/search?"+params.toString();
  const response=await fetch(url,{headers:{"Accept":"application/json"}});
  if(!response.ok)throw new Error("تعذّر الاتصال بخدمة البحث.");
  const data=await response.json();
  const places=data.filter(p=>Number.isFinite(Number(p.lat))&&Number.isFinite(Number(p.lon)));
  if(!places.length){status.textContent="لم نعثر على نتيجة. جرّب الاسم المحلي أو الإنجليزي، وأضف اسم الدولة لتضييق البحث.";return;}
  status.textContent=`عُثر على ${places.length} نتيجة. اختر المدينة أو البلدة الصحيحة:`;
  places.forEach(place=>{
   const button=document.createElement("button");button.type="button";button.className="action secondary";button.style.cssText="display:block;width:100%;margin:6px 0;text-align:start";
   const addr=place.address||{};
   const placeName=place.name||addr.city||addr.town||addr.village||place.display_name;
   const countryName=addr.country||"";
   const region=addr.state||addr.region||addr.county||"";
   button.textContent=[placeName,region,countryName].filter((v,i,a)=>v&&a.indexOf(v)===i).join("، ")||place.display_name;
   button.title=place.display_name;
   button.addEventListener("click",async()=>{
    coords={lat:Number(place.lat),lon:Number(place.lon)};timezoneConfirmed=false;selectedTimeZone="UTC";localStorage.removeItem("huda-timezone");localStorage.setItem("huda-location-mode","manual");
    selectedCountryCode=(addr.country_code||"").toLowerCase();if(selectedCountryCode)localStorage.setItem("huda-country-code",selectedCountryCode);else localStorage.removeItem("huda-country-code");updatePrayerMethodHint();
    persistCoords();
    const shortName=[placeName,region,countryName].filter((v,i,a)=>v&&a.indexOf(v)===i).join("، ");
    localStorage.setItem("huda-city-name",shortName||place.display_name);
    $("locationLabel").textContent=shortName||place.display_name;$("selectedCity").textContent="المدينة المختارة: "+(shortName||place.display_name);
    $("citySearchStatus").textContent="تم حفظ الموقع. جارٍ تحديد المنطقة الزمنية…";results.innerHTML="";
    const zone=await resolveTimeZone(coords.lat,coords.lon);
    $("citySearchStatus").textContent=zone?`تم حفظ الموقع والمنطقة الزمنية (${zone}).`:`تم حفظ الإحداثيات؛ تعذّر تحديد المنطقة الزمنية تلقائيًا. راجع إعدادات الوقت قبل الاعتماد على المواقيت.`;
    renderPrayer();
   });results.appendChild(button);
  });
 }catch(error){status.textContent="تعذّر البحث الآن. تحقق من الإنترنت وحاول مجددًا، أو استخدم تحديد موقعي.";}
}

function setupPrayerSettings(){
 const offsetPanel=$("prayerOffsets");
 if(offsetPanel){
  offsetPanel.querySelectorAll("[data-prayer-offset]").forEach(input=>{
   const key=input.dataset.prayerOffset;input.value=String(prayerOffsets[key]||0);
   input.addEventListener("change",()=>{
    const n=Number(input.value);
    if(!Number.isInteger(n)||n < -30||n > 30){input.value=String(prayerOffsets[key]||0);return;}
    prayerOffsets[key]=n;savePrayerOffsets();renderPrayer();
   });
  });
  $("resetPrayerOffsets").addEventListener("click",()=>{
   prayerOffsets=Object.fromEntries(prayerOffsetKeys.map(k=>[k,0]));savePrayerOffsets();
   offsetPanel.querySelectorAll("[data-prayer-offset]").forEach(input=>input.value="0");renderPrayer();
  });
 }

  const tzInput=$("manualTimeZone"),tzApply=$("applyTimeZone");
 if(tzInput&&tzApply){tzInput.value=timezoneConfirmed?selectedTimeZone:"";tzApply.addEventListener("click",()=>{const value=tzInput.value.trim();try{new Intl.DateTimeFormat("en",{timeZone:value});selectedTimeZone=value;timezoneConfirmed=true;localStorage.setItem("huda-timezone",value);$("citySearchStatus").textContent=`تم اعتماد المنطقة الزمنية يدويًا: ${value}`;renderPrayer();}catch(e){$("citySearchStatus").textContent="اسم غير صالح. استخدم صيغة IANA مثل Europe/Paris أو Asia/Damascus.";}});}
 const method=$("prayerMethodSelect"),asr=$("asrMethod"),cf=$("customFajr"),ci=$("customIsha"),notify=$("prayerNotifications");
 method.value=prayerMethod;asr.value=String(asrFactor);cf.value=String(customFajr);ci.value=String(customIsha);$("customAngles").style.display=effectivePrayerMethod()==="CUSTOM"?"flex":"none";updatePrayerMethodHint();
 method.addEventListener("change",()=>{prayerMethod=method.value;localStorage.setItem("huda-prayer-method",prayerMethod);$("customAngles").style.display=effectivePrayerMethod()==="CUSTOM"?"flex":"none";updatePrayerMethodHint();renderPrayer();});
 asr.addEventListener("change",()=>{asrFactor=Number(asr.value);localStorage.setItem("huda-asr-factor",String(asrFactor));renderPrayer();});
 [cf,ci].forEach(el=>el.addEventListener("change",()=>{const v=Number(el.value);if(!Number.isFinite(v)||v<0||v>30){el.value=el===cf?String(customFajr):String(customIsha);return;}if(el===cf){customFajr=v;localStorage.setItem("huda-custom-fajr",String(v));}else{customIsha=v;localStorage.setItem("huda-custom-isha",String(v));}if(effectivePrayerMethod()==="CUSTOM")renderPrayer();}));
 const saved=JSON.parse(localStorage.getItem("huda-coordinates")||"null");if(saved&&Number.isFinite(saved.lat)&&Number.isFinite(saved.lon)){coords=saved;const city=localStorage.getItem("huda-city-name")||"";$("locationLabel").textContent=city||tr("locationFound");$("selectedCity").textContent=city?`المدينة المحفوظة: ${city}`:"تم استعادة الموقع المحفوظ";}
 $("searchCity").addEventListener("click",searchCityByName);
 $("cityName").addEventListener("keydown",e=>{if(e.key==="Enter")searchCityByName();});
 $("clearManualLocation").addEventListener("click",()=>{coords=null;localStorage.setItem("huda-location-mode","auto");localStorage.removeItem("huda-coordinates");localStorage.removeItem("huda-city-name");$("cityName").value="";$("countryName").value="";$("cityResults").innerHTML="";$("selectedCity").textContent="";$("locationLabel").textContent=tr("locationPrompt");renderPrayer();});
 if(coords){if(!timezoneConfirmed)resolveTimeZone(coords.lat,coords.lon).then(()=>renderPrayer());if(!selectedCountryCode)resolveCountryCode(coords.lat,coords.lon).then(()=>renderPrayer());}
 notify.checked=localStorage.getItem("huda-prayer-notifications")==="true";notify.addEventListener("change",async()=>{if(notify.checked){if(!("Notification" in window)){notify.checked=false;$("notificationStatus").textContent="الإشعارات غير مدعومة في هذا المتصفح.";return;}const permission=await Notification.requestPermission();if(permission!=="granted"){notify.checked=false;$("notificationStatus").textContent="لم يتم منح إذن الإشعارات.";return;}localStorage.setItem("huda-prayer-notifications","true");$("notificationStatus").textContent="التنبيهات مفعّلة أثناء بقاء التطبيق مفتوحاً.";}else{localStorage.setItem("huda-prayer-notifications","false");$("notificationStatus").textContent="تم إيقاف التنبيهات.";}renderPrayer();});
 const pre=$("prayerPreReminder"),lead=$("prayerLeadMinutes"),choiceInputs=[...document.querySelectorAll("[data-prayer-alert]")];
 pre.checked=localStorage.getItem("huda-prayer-pre-reminder")==="true";
 lead.value=localStorage.getItem("huda-prayer-lead")||"10";
 const savedChoices=JSON.parse(localStorage.getItem("huda-prayer-alert-choices")||"[0,2,3,4,5]");
 choiceInputs.forEach(input=>{input.checked=savedChoices.includes(Number(input.dataset.prayerAlert));input.addEventListener("change",()=>{
  const selected=choiceInputs.filter(x=>x.checked).map(x=>Number(x.dataset.prayerAlert));
  if(!selected.length){input.checked=true;$("notificationStatus").textContent="اختر صلاة واحدة على الأقل.";return;}
  localStorage.setItem("huda-prayer-alert-choices",JSON.stringify(selected));renderPrayer();
 });});
 pre.addEventListener("change",async()=>{
  if(pre.checked){
   if(!("Notification"in window)){pre.checked=false;$("notificationStatus").textContent="الإشعارات غير مدعومة في هذا المتصفح.";return;}
   const permission=await Notification.requestPermission();
   if(permission!=="granted"){pre.checked=false;$("notificationStatus").textContent="لم يتم منح إذن الإشعارات.";return;}
  }
  localStorage.setItem("huda-prayer-pre-reminder",String(pre.checked));renderPrayer();
 });
 lead.addEventListener("change",()=>{localStorage.setItem("huda-prayer-lead",String(Number(lead.value)));renderPrayer();});
 initAdhanAudio();
} 

const DHIKR_CHOICES=[
 ["salawat","اللهم صلِّ وسلم على نبينا محمد"],
 ["istighfar","أستغفر الله العظيم وأتوب إليه"],
 ["tasbih","سبحان الله والحمد لله ولا إله إلا الله والله أكبر"],
 ["tahlil","لا إله إلا الله"],
 ["general","لا تنسَ ذكر الله"]
];
let dhikrReminderTimer=null;
function readDhikrReminders(){
 try{const a=JSON.parse(localStorage.getItem("huda-dhikr-reminders")||"[]");return Array.isArray(a)?a:[];}catch(e){return [];}
}
function saveDhikrReminders(a){localStorage.setItem("huda-dhikr-reminders",JSON.stringify(a));}
function renderDhikrReminders(){
 const box=$("dhikrReminderList");if(!box)return;
 const items=readDhikrReminders();box.innerHTML="";
 if(!items.length){const p=document.createElement("p");p.className="small";p.textContent="لا توجد تذكيرات مضافة بعد.";box.append(p);}
 items.forEach(item=>{
  const row=document.createElement("div");row.className="listitem";row.style.margin="10px 0";
  const title=document.createElement("b");title.textContent="التذكير";
  const textLabel=document.createElement("label");textLabel.style.display="block";textLabel.style.marginTop="8px";textLabel.textContent="الذكر ";
  const textSelect=document.createElement("select");textSelect.setAttribute("aria-label","اختر الذكر");
  DHIKR_CHOICES.forEach(([v,t])=>{const o=document.createElement("option");o.value=v;o.textContent=t;textSelect.append(o);});
  textSelect.value=item.text||"salawat";textLabel.append(textSelect);
  const intervalLabel=document.createElement("label");intervalLabel.style.display="block";intervalLabel.style.marginTop="8px";intervalLabel.textContent="التكرار ";
  const interval=document.createElement("select");interval.setAttribute("aria-label","فاصل التذكير بالدقائق");
  [[5,"كل 5 دقائق"],[10,"كل 10 دقائق"],[15,"كل 15 دقيقة"],[30,"كل 30 دقيقة"],[60,"كل ساعة"],[120,"كل ساعتين"],[180,"كل 3 ساعات"],[240,"كل 4 ساعات"]].forEach(([v,t])=>{const o=document.createElement("option");o.value=String(v);o.textContent=t;interval.append(o);});
  interval.value=String([5,10,15,30,60,120,180,240].includes(Number(item.minutes))?Number(item.minutes):10);intervalLabel.append(interval);
  const enabledLabel=document.createElement("label");enabledLabel.style.display="block";enabledLabel.style.marginTop="8px";
  const enabled=document.createElement("input");enabled.type="checkbox";enabled.checked=item.enabled!==false;enabledLabel.append(enabled,document.createTextNode(" تفعيل هذا التذكير"));
  const remove=document.createElement("button");remove.type="button";remove.className="action secondary";remove.textContent="حذف التذكير";remove.style.marginTop="8px";
  function update(){const all=readDhikrReminders(),x=all.find(v=>v.id===item.id);if(!x)return;x.text=textSelect.value;x.minutes=Number(interval.value);x.enabled=enabled.checked;if(!x.lastAt)x.lastAt=Date.now();saveDhikrReminders(all);startDhikrReminderTicker();}
  textSelect.addEventListener("change",update);interval.addEventListener("change",update);
  enabled.addEventListener("change",async()=>{
   if(enabled.checked&&"Notification"in window&&Notification.permission==="default"){const p=await Notification.requestPermission();if(p!=="granted"){enabled.checked=false;}}
   update();
  });
  remove.addEventListener("click",()=>{saveDhikrReminders(readDhikrReminders().filter(x=>x.id!==item.id));renderDhikrReminders();startDhikrReminderTicker();});
  row.append(title,textLabel,intervalLabel,enabledLabel,remove);box.append(row);
 });
}
async function addDhikrReminder(){
 if(!("Notification"in window)){ $("dhikrReminderStatus").textContent="هذا المتصفح لا يدعم إشعارات النظام.";return; }
 if(Notification.permission==="default"){const p=await Notification.requestPermission();if(p!=="granted"){$("dhikrReminderStatus").textContent="لم يتم منح إذن الإشعارات؛ يمكنك تعديل الإذن من إعدادات الجهاز.";return;}}
 if(Notification.permission!=="granted"){$("dhikrReminderStatus").textContent="إذن الإشعارات غير متاح. راجع إعدادات المتصفح أو التطبيق.";return;}
 const a=readDhikrReminders();a.push({id:"d"+Date.now()+Math.random().toString(16).slice(2,6),text:"salawat",minutes:10,enabled:true,lastAt:Date.now()});
 saveDhikrReminders(a);renderDhikrReminders();startDhikrReminderTicker();
 $("dhikrReminderStatus").textContent="أُضيف تذكير الصلاة على النبي ﷺ كل 10 دقائق. يمكنك تغيير الذكر والفاصل الزمني.";
}
function startDhikrReminderTicker(){
 if(dhikrReminderTimer)clearInterval(dhikrReminderTimer);
 dhikrReminderTimer=setInterval(()=>{
  if(document.visibilityState!=="visible"||!("Notification"in window)||Notification.permission!=="granted")return;
  const a=readDhikrReminders(),now=Date.now();let changed=false;
  a.forEach(x=>{
   if(x.enabled===false)return;
   const mins=Math.max(1,Number(x.minutes)||10),last=Number(x.lastAt)||now;
   if(now-last>=mins*60000){
    const phrase=(DHIKR_CHOICES.find(v=>v[0]===x.text)||DHIKR_CHOICES[0])[1];
    try{new Notification("هُدَى لِلْعَالَمِينَ",{body:phrase,tag:"dhikr-"+x.id});x.lastAt=now;changed=true;}catch(e){}
   }
  });
  if(changed)saveDhikrReminders(a);
 },15000);
}
function setupDhikrReminders(){
 const add=$("addDhikrReminder");if(!add)return;
 add.addEventListener("click",addDhikrReminder);
 renderDhikrReminders();startDhikrReminderTicker();
}

// حفظ ملف الأذان كـ Blob في IndexedDB بدلاً من localStorage لتجنب حدود الحجم.
const ADHAN_DB_NAME="huda-audio-storage", ADHAN_STORE="audio-files";
function openAdhanDB(){return new Promise((resolve,reject)=>{
 const request=indexedDB.open(ADHAN_DB_NAME,1);
 request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains(ADHAN_STORE))request.result.createObjectStore(ADHAN_STORE);};
 request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
 });}
async function saveAdhanBlob(blob,name){const db=await openAdhanDB();return new Promise((resolve,reject)=>{const tx=db.transaction(ADHAN_STORE,"readwrite");tx.objectStore(ADHAN_STORE).put({blob,name,type:blob.type||"audio/*",savedAt:Date.now()},"selected-adhan");tx.oncomplete=()=>{db.close();resolve();};tx.onerror=()=>{db.close();reject(tx.error);};});}
async function getAdhanBlob(){const db=await openAdhanDB();return new Promise((resolve,reject)=>{const tx=db.transaction(ADHAN_STORE,"readonly"),r=tx.objectStore(ADHAN_STORE).get("selected-adhan");r.onsuccess=()=>{db.close();resolve(r.result||null);};r.onerror=()=>{db.close();reject(r.error);};});}
async function removeAdhanBlob(){const db=await openAdhanDB();return new Promise((resolve,reject)=>{const tx=db.transaction(ADHAN_STORE,"readwrite");tx.objectStore(ADHAN_STORE).delete("selected-adhan");tx.oncomplete=()=>{db.close();resolve();};tx.onerror=()=>{db.close();reject(tx.error);};});}
let adhanObjectUrl=null;
async function loadAdhanIntoPlayer(){const saved=await getAdhanBlob();const player=document.getElementById("adhanAudioPlayer");if(adhanObjectUrl){URL.revokeObjectURL(adhanObjectUrl);adhanObjectUrl=null;}if(saved?.blob){adhanObjectUrl=URL.createObjectURL(saved.blob);player.src=adhanObjectUrl;}return saved;}
async function playSavedAdhan(){const saved=await loadAdhanIntoPlayer();if(!saved?.blob)throw new Error("no-adhan");const player=document.getElementById("adhanAudioPlayer");player.currentTime=0;await player.play();}
function initAdhanAudio(){
 const input=document.getElementById("adhanFileInput"),status=document.getElementById("adhanFileStatus"),test=document.getElementById("testAdhanButton"),del=document.getElementById("deleteAdhanButton"),auto=document.getElementById("playAdhanAtPrayer");
 if(!input||input.dataset.bound)return;input.dataset.bound="1";
 auto.checked=localStorage.getItem("huda-play-adhan-at-prayer")==="true";
 auto.addEventListener("change",()=>{localStorage.setItem("huda-play-adhan-at-prayer",String(auto.checked));status.textContent=auto.checked?"سيُشغّل الأذان عند دخول الوقت أثناء بقاء التطبيق مفتوحاً.":"التشغيل التلقائي للأذان متوقف.";});
 input.addEventListener("change",async()=>{const file=input.files?.[0];if(!file)return;if(!file.type.startsWith("audio/")&&!/\.(mp3|m4a|aac|wav|ogg|opus)$/i.test(file.name)){status.textContent="الملف المحدد ليس ملفاً صوتياً مدعوماً.";input.value="";return;}try{await saveAdhanBlob(file,file.name);await loadAdhanIntoPlayer();status.textContent=`تم حفظ ملف الأذان داخل التطبيق: ${file.name} (${(file.size/1024/1024).toFixed(2)} MB).`; }catch(e){status.textContent="تعذّر حفظ الملف. تحقق من مساحة التخزين وأذونات التطبيق.";}});
 test.addEventListener("click",async()=>{try{await playSavedAdhan();status.textContent="يتم الآن تشغيل ملف الأذان للتجربة.";}catch(e){status.textContent=e.message==="no-adhan"?"اختر ملف الأذان أولاً.":"تعذّر تشغيل الملف. جرّب صيغة صوتية أخرى أو اضغط تشغيل مرة أخرى.";}});
 del.addEventListener("click",async()=>{try{document.getElementById("adhanAudioPlayer").pause();document.getElementById("adhanAudioPlayer").removeAttribute("src");if(adhanObjectUrl)URL.revokeObjectURL(adhanObjectUrl);adhanObjectUrl=null;await removeAdhanBlob();input.value="";status.textContent="تم حذف ملف الأذان المحفوظ.";}catch(e){status.textContent="تعذّر حذف ملف الأذان.";}});
 getAdhanBlob().then(saved=>{status.textContent=saved?.blob?`ملف الأذان محفوظ: ${saved.name||"ملف صوتي"}.`:"لم يتم اختيار ملف أذان بعد.";return loadAdhanIntoPlayer();}).catch(()=>{status.textContent="تخزين الصوت غير متاح في بيئة التشغيل الحالية.";});
}

function prayerAlertSettings(){
 let selected;try{selected=JSON.parse(localStorage.getItem("huda-prayer-alert-choices")||"[0,2,3,4,5]");}catch(e){selected=[0,2,3,4,5];}
 return {
  at:localStorage.getItem("huda-prayer-notifications")==="true",
  before:localStorage.getItem("huda-prayer-pre-reminder")==="true",
  lead:Number(localStorage.getItem("huda-prayer-lead")||10),
  selected:selected.length?selected:[0,2,3,4,5],
  audio:localStorage.getItem("huda-play-adhan-at-prayer")==="true"
 };
}
function prayerAlertEventKey(dateKey,index,kind){return `huda-prayer-alert-${dateKey}-${index}-${kind}`;}
function schedulePrayerAlert(times){
 if(notificationTimer)clearTimeout(notificationTimer);
 if(document.visibilityState==="hidden")return;
 const cfg=prayerAlertSettings();
 if(!cfg.at&&!cfg.before&&!cfg.audio)return;
 const canNotify=("Notification"in window)&&Notification.permission==="granted";
 if(!canNotify&&!cfg.audio)return;
 const now=new Date(),zp=zonedParts(now),mins=zp.hour*60+zp.minute+zp.second/60;
 const dateKey=`${zp.year}-${String(zp.month).padStart(2,"0")}-${String(zp.day).padStart(2,"0")}`;
 let next=null;
 for(const i of cfg.selected){
  if(!Number.isFinite(times[i]))continue;
  let prayerDelta=times[i]-mins;
  if(prayerDelta<=0)prayerDelta+=1440;
  if(cfg.before&&canNotify){
   const preDelta=prayerDelta-cfg.lead;
   const key=prayerAlertEventKey(dateKey,i,"before");
   if(preDelta>0.02&&localStorage.getItem(key)!=="1"){
    const event={i,kind:"before",delta:preDelta};
    if(!next||event.delta<next.delta)next=event;
   }
  }
  if(cfg.at&&canNotify){
   const key=prayerAlertEventKey(dateKey,i,"at");
   if(prayerDelta>0.02&&localStorage.getItem(key)!=="1"){
    const event={i,kind:"at",delta:prayerDelta};
    if(!next||event.delta<next.delta)next=event;
   }
  }
 }
 if(!next)return;
 notificationTimer=setTimeout(()=>{
  if(document.visibilityState==="visible"){
   const label=tr(prayerKeys[next.i]);
   if(next.kind==="at"&&cfg.audio){
    playSavedAdhan().catch(()=>{const status=document.getElementById("adhanFileStatus");if(status)status.textContent="تعذّر تشغيل الأذان تلقائياً. افتح التطبيق وتحقق من الملف وإعدادات الصوت.";});
   }
   if(canNotify){
    const body=next.kind==="before"?`باقي ${cfg.lead} دقائق على صلاة ${label}. تهيّأ للصلاة.`:`حان الآن وقت صلاة ${label}.`;
    new Notification("هُدَى لِلْعَالَمِينَ",{body});
    const current=zonedParts(new Date());
    const keyDate=`${current.year}-${String(current.month).padStart(2,"0")}-${String(current.day).padStart(2,"0")}`;
    localStorage.setItem(prayerAlertEventKey(keyDate,next.i,next.kind),"1");
   }
  }
  renderPrayer();
 },Math.max(1000,next.delta*60000));
}
document.addEventListener("visibilitychange",()=>{if(coords)renderPrayer();});
setInterval(()=>{if(coords&&document.visibilityState==="visible")renderPrayer();},60000);
let qiblaBearing=null, deviceHeading=null, orientationListening=false;
function calculateQibla(){
 if(!coords){$("qiblaStatus").textContent="حدّد موقعك من زر تحديد الاتجاه أو أدخل الإحداثيات في الإعدادات أولاً.";return;}
 const lat1=rad(coords.lat),lat2=rad(21.4225),dl=rad(39.8262-coords.lon);
 const y=Math.sin(dl),x=Math.cos(lat1)*Math.tan(lat2)-Math.sin(lat1)*Math.cos(dl);
 qiblaBearing=(deg(Math.atan2(y,x))+360)%360;
 $("bearing").textContent=Math.round(qiblaBearing)+"°";
 $("qiblaStatus").textContent=`اتجاه القبلة من الشمال الحقيقي: ${qiblaBearing.toFixed(1)}°. ${deviceHeading===null?"فعّل البوصلة الحركية لمعرفة اتجاه تدوير الهاتف.":"البوصلة الحركية مفعّلة."}`;
 updateQiblaNeedle();
}
function updateQiblaNeedle(){if(qiblaBearing===null)return;const angle=qiblaBearing-(deviceHeading===null?0:deviceHeading);$("qiblaNeedle").style.transform=`translate(-50%,-50%) rotate(${angle}deg)`;}
function onDeviceOrientation(e){let heading=null;if(typeof e.webkitCompassHeading==="number")heading=e.webkitCompassHeading;else if(e.absolute&&typeof e.alpha==="number")heading=(360-e.alpha)%360;if(heading!==null){deviceHeading=heading;updateQiblaNeedle();if(qiblaBearing!==null)$("qiblaStatus").textContent=`اتجاه الهاتف بالنسبة للشمال: ${Math.round(heading)}° — اتبع السهم نحو القبلة.`;}}
async function enableQiblaCompass(){try{if(typeof DeviceOrientationEvent==="undefined"){ $("qiblaStatus").textContent="حساس اتجاه الهاتف غير متاح على هذا الجهاز؛ يمكنك استخدام زاوية القبلة الرقمية.";return;}if(typeof DeviceOrientationEvent.requestPermission==="function"){const permission=await DeviceOrientationEvent.requestPermission();if(permission!=="granted")throw new Error("لم يُمنح إذن حساس الاتجاه.");}if(!orientationListening){window.addEventListener("deviceorientationabsolute",onDeviceOrientation,true);window.addEventListener("deviceorientation",onDeviceOrientation,true);orientationListening=true;}$("qiblaStatus").textContent="تم طلب البوصلة. حرّك الهاتف ببطء على شكل رقم 8 لمعايرته.";}catch(err){$("qiblaStatus").textContent=err.message||"تعذّر تفعيل البوصلة؛ استخدم الزاوية الرقمية.";}}
$("qiblaLocate").onclick=()=>{if(coords){calculateQibla();return;}getLocation(calculateQibla);};
$("qiblaCompassEnable").onclick=enableQiblaCompass;
$("locate").addEventListener("click",()=>getLocation());
setLang(lang);setupPrayerSettings();setupDhikrReminders();renderPrayer();
// Automatic GPS on first launch (or when the user selected automatic location). A manually selected city is preserved.
if(localStorage.getItem("huda-location-mode")!=="manual"){getLocation();}
loadQuran();loadTranslations();
if("serviceWorker" in navigator && location.protocol!=="file:"){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}


// Phase 4: streaming and per-surah offline audio library.
const AUDIO_API="https://www.mp3quran.net/api/v3/reciters?language=ar";
const AUDIO_CACHE="huda-quran-audio-v1";
const preferredReciters=[
 {match:["مشاري العفاسي","مشاري بن راشد العفاسي"],fallback:"مشاري العفاسي"},
 {match:["عبد الباسط عبد الصمد","عبدالباسط عبدالصمد"],fallback:"عبد الباسط عبد الصمد"},
 {match:["ماهر المعيقلي"],fallback:"ماهر المعيقلي"},
 {match:["محمود خليل الحصري","محمود خليل الحصرى"],fallback:"محمود خليل الحصري"},
 {match:["سعد الغامدي"],fallback:"سعد الغامدي"},
 {match:["عبدالرحمن السديس","عبد الرحمن السديس"],fallback:"عبدالرحمن السديس"},
 {match:["ياسر الدوسري","ياسر بن راشد الدوسري"],fallback:"ياسر الدوسري"}
];
let audioReciters=[], audioObjectUrl=null;
function audioMessage(text){const el=$("audioStatus");if(el)el.textContent=text;}
function fillAudioSurahs(){const el=$("audioSurah");if(!el)return;el.innerHTML="";surahsAr.forEach((name,i)=>{const o=document.createElement("option");o.value=String(i+1);o.textContent=`${i+1}. ${name}`;el.append(o);});}
async function loadAudioReciters(){
 const select=$("audioReciter"); if(!select)return;
 try{
  const response=await fetch(AUDIO_API,{cache:"no-store"}); if(!response.ok)throw new Error("HTTP "+response.status);
  const data=await response.json(); const all=data.reciters||[];
  audioReciters=[];
  for(const wanted of preferredReciters){
   let found=null;
   for(const r of all){const name=String(r.name||"");if(wanted.match.some(m=>name.includes(m))){const moshaf=(r.moshaf||[]).find(x=>x.server&&x.surah_list)|| (r.moshaf||[]).find(x=>x.server);if(moshaf){found={name,server:moshaf.server,moshafName:moshaf.name||"رواية حفص",surahs:(moshaf.surah_list||"").split(",").map(Number).filter(Boolean)};break;}}}
   if(found)audioReciters.push(found);
  }
  select.innerHTML="";
  if(!audioReciters.length)throw new Error("لم يتم العثور على القراء المطلوبين في رد المصدر");
  audioReciters.forEach((r,i)=>{const o=document.createElement("option");o.value=String(i);o.textContent=r.name+" — "+r.moshafName;select.append(o);});
  updateAudioAvailability(); audioMessage(`تم تحميل قائمة القراء. المتاح حالياً ${audioReciters.length} من أصل ${preferredReciters.length} قراء مقترحين.`);
 }catch(e){select.innerHTML='<option value="">تعذّر تحميل قائمة القراء</option>';audioMessage("تعذّر الاتصال بمصدر قائمة القراء. تحقق من الإنترنت ثم أعد فتح قسم التلاوات.");}
}
function selectedAudio(){const r=audioReciters[Number($("audioReciter")?.value||0)];const surah=Number($("audioSurah")?.value||1);if(!r)return null;return {reciter:r,surah,url:r.server+String(surah).padStart(3,"0")+".mp3",key:`${r.name}|${surah}`};}
function updateAudioAvailability(){const item=selectedAudio();if(!item)return;const available=!item.reciter.surahs.length||item.reciter.surahs.includes(item.surah);$("audioPlay").disabled=!available;$("audioDownload").disabled=!available;if(!available)audioMessage("هذه السورة غير مدرجة ضمن التسجيلات المتاحة لهذا القارئ.");}
async function getAudioCache(){return await caches.open(AUDIO_CACHE);}
async function playSelectedAudio(){
 const item=selectedAudio();if(!item){audioMessage("اختر قارئاً أولاً.");return;}
 try{const cache=await getAudioCache();const saved=await cache.match(item.url);let src=item.url;
  if(saved){if(audioObjectUrl)URL.revokeObjectURL(audioObjectUrl);audioObjectUrl=URL.createObjectURL(await saved.blob());src=audioObjectUrl;audioMessage("تشغيل النسخة المحفوظة على الجهاز — دون إنترنت.");}
  else audioMessage("جارٍ الاتصال لتشغيل التلاوة. لتنزيلها للاستماع دون إنترنت اضغط زر التنزيل.");
  const player=$("quranAudio");player.src=src;await player.play();
 }catch(e){audioMessage("تعذّر التشغيل. قد يكون الاتصال أو مصدر الصوت غير متاح حالياً.");}
}
async function downloadSelectedAudio(){
 const item=selectedAudio();if(!item){audioMessage("اختر قارئاً أولاً.");return;}
 const btn=$("audioDownload");btn.disabled=true;audioMessage("جارٍ تنزيل السورة… أبقِ التطبيق مفتوحاً حتى اكتمال التنزيل.");
 try{
  const response=await fetch(item.url,{mode:"cors",cache:"no-store"});if(!response.ok||response.type==="opaque")throw new Error("تعذر الوصول إلى ملف الصوت");
  const blob=await response.blob();if(!blob.size)throw new Error("ملف الصوت فارغ");
  const cache=await getAudioCache();await cache.put(item.url,new Response(blob,{headers:{"Content-Type":response.headers.get("Content-Type")||"audio/mpeg","X-Huda-Reciter":encodeURIComponent(item.reciter.name),"X-Huda-Surah":String(item.surah),"X-Huda-Size":String(blob.size)}}));
  audioMessage(`اكتمل تنزيل سورة ${surahsAr[item.surah-1]} (${formatBytes(blob.size)}). أصبحت متاحة دون إنترنت على هذا الجهاز.`);await renderDownloadedAudio();
 }catch(e){audioMessage("لم يكتمل التنزيل. قد يمنع خادم الصوت التنزيل المباشر أو لا يدعم الاتصال من WebView. يمكن تجربة التشغيل عبر الإنترنت أو إعداد خادم وسيط لاحقاً.");}
 finally{btn.disabled=false;updateAudioAvailability();}
}
function formatBytes(n){if(n<1024*1024)return (n/1024).toFixed(0)+" KB";return (n/1024/1024).toFixed(1)+" MB";}
async function renderDownloadedAudio(){
 const box=$("downloadedAudioList");if(!box)return;
 try{const cache=await getAudioCache(),keys=await cache.keys();box.innerHTML="";
  if(!keys.length){box.innerHTML='<p class="small">لم تُنزّل تلاوات بعد.</p>';$("audioStorage").textContent="";return;}
  let total=0;
  for(const request of keys){const res=await cache.match(request);const size=Number(res.headers.get("X-Huda-Size")||0);total+=size;const rec=decodeURIComponent(res.headers.get("X-Huda-Reciter")||"قارئ");const surah=Number(res.headers.get("X-Huda-Surah")||0);const row=document.createElement("div");row.className="audio-item";const info=document.createElement("div");info.textContent=`${rec} — ${surahsAr[surah-1]||"سورة"}`;const small=document.createElement("small");small.textContent=formatBytes(size)+" • محفوظة دون إنترنت";info.append(small);const del=document.createElement("button");del.className="action secondary";del.textContent="حذف";del.onclick=async()=>{await cache.delete(request);await renderDownloadedAudio();};row.append(info,del);box.append(row);
  }
  $("audioStorage").textContent=`المساحة التقريبية المستخدمة للتلاوات: ${formatBytes(total)}.`;
 }catch(e){box.textContent="ميزة التخزين غير متاحة في هذا المتصفح.";}
}
$("audioPlay")?.addEventListener("click",playSelectedAudio);
$("audioDownload")?.addEventListener("click",downloadSelectedAudio);
$("audioReciter")?.addEventListener("change",updateAudioAvailability);
$("audioSurah")?.addEventListener("change",updateAudioAvailability);
$("refreshAudioDownloads")?.addEventListener("click",renderDownloadedAudio);

// Phase 8: Hijri date, ayah favorites, and reading position.
function getFavorites(){try{return JSON.parse(localStorage.getItem("huda-quran-favorites")||"[]");}catch(_){return [];}}
function isFavorite(s,a){return getFavorites().some(x=>x.s===s&&x.a===a);}
function toggleFavorite(s,a){let f=getFavorites();f=isFavorite(s,a)?f.filter(x=>!(x.s===s&&x.a===a)):[...f,{s,a}];localStorage.setItem("huda-quran-favorites",JSON.stringify(f));}
function renderFavorites(){const box=$("favoritesList");if(!box)return;const f=getFavorites();box.innerHTML="";if(!f.length){box.textContent="لا توجد آيات محفوظة بعد.";return;}f.forEach(x=>{const verse=quranData?.[x.s]?.find(v=>v.n===x.a);const row=document.createElement("div");row.className="listitem";const title=document.createElement("b");title.textContent=`${surahsAr[x.s-1]} — الآية ${x.a}`;const text=document.createElement("p");text.textContent=verse?.t||"";const open=document.createElement("button");open.className="action secondary";open.textContent="فتح الآية";open.onclick=()=>{show("quran");openSurah(x.s);setTimeout(()=>document.getElementById(`ayah-${x.s}-${x.a}`)?.scrollIntoView({behavior:"smooth",block:"center"}),180);};const remove=document.createElement("button");remove.className="action secondary";remove.textContent="إزالة";remove.style.marginRight="8px";remove.onclick=()=>{toggleFavorite(x.s,x.a);renderFavorites();};row.append(title,text,open,remove);box.append(row);});}
function renderHijriDate(){const now=new Date();let h="";try{h=new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura",{weekday:"long",year:"numeric",month:"long",day:"numeric"}).format(now);}catch(e){try{h=new Intl.DateTimeFormat("ar-SA-u-ca-islamic",{weekday:"long",year:"numeric",month:"long",day:"numeric"}).format(now);}catch(_){h="التقويم الهجري غير مدعوم في هذا الجهاز";}}const a=$("hijriDate"),b=$("gregorianDate"),c=$("homeHijriDate");if(a)a.textContent=h;if(c)c.textContent=h;if(b)b.textContent=new Intl.DateTimeFormat(lang==="ar"?"ar":lang==="tr"?"tr-TR":"en-GB",{dateStyle:"full"}).format(now);}
function updateLastReading(){const s=Number(localStorage.getItem("huda-last-surah")||0),a=Number(localStorage.getItem("huda-last-ayah")||1);$("lastReadingInfo").textContent=s?`${surahsAr[s-1]} — الآية ${a}`:"لم تبدأ القراءة بعد.";}
function resumeLastReading(){const s=Number(localStorage.getItem("huda-last-surah")||0),a=Number(localStorage.getItem("huda-last-ayah")||1);if(s>=1&&s<=114){show("quran");openSurah(s);setTimeout(()=>document.getElementById(`ayah-${s}-${a}`)?.scrollIntoView({behavior:"smooth",block:"start"}),180);}else{show("quran");}}
$("resumeReading")?.addEventListener("click",resumeLastReading);$("resumeReading2")?.addEventListener("click",resumeLastReading);
window.addEventListener("scroll",()=>{if($("quranReader")?.style.display==="block"){const rows=[...document.querySelectorAll("#verseList .verse")];let current=rows.find(r=>r.getBoundingClientRect().bottom>100);if(current){const m=current.id.match(/^ayah-(\d+)-(\d+)$/);if(m){localStorage.setItem("huda-last-surah",m[1]);localStorage.setItem("huda-last-ayah",m[2]);updateLastReading();}}}},{passive:true});
renderHijriDate();renderFavorites();updateLastReading();
fillAudioSurahs();loadAudioReciters();renderDownloadedAudio();
