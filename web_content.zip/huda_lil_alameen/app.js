const T={
ar:{tagline:"رفيقك إلى الطمأنينة",welcome:"السلام عليكم ورحمة الله",welcomeSub:"اجعل لقلبك نصيباً من القرآن والذكر كل يوم",prayerTimes:"أوقات الصلاة",locationPrompt:"حدّد موقعك لحساب المواقيت محلياً",locate:"تحديد موقعي",duaTitle:"دعاء لأهل فلسطين وللمستضعفين",explore:"استكشف التطبيق",quran:"القرآن الكريم",quranSub:"السور والقراءة",adhkar:"الأذكار",adhkarSub:"أذكار مختارة",tasbih:"المسبحة",tasbihSub:"عداد التسبيح",qibla:"اتجاه القبلة",qiblaSub:"احسب اتجاه مكة",settings:"الإعدادات",settingsSub:"اللغة والموقع",home:"الرئيسية",quranNotice:"أُدرج النص العربي بالرسم العثماني، وأضيفت ترجمتا المعاني الإنجليزية والتركية من الملفين المرفوعين. تم التحقق من وجود ٦٢٣٦ مدخلاً في كل ملف ومطابقة أرقام السور والآيات بينها. الترجمة بيان لمعاني الآيات وليست نص القرآن العربي.",tasbihHint:"اضغط للعدّ",reset:"إعادة التصفير",qiblaDesc:"احصل على موقعك لحساب اتجاه القبلة من الشمال الحقيقي.",calculate:"حساب الاتجاه",language:"لغة التطبيق",offline:"العمل دون إنترنت",offlineDesc:"الواجهة والميزات الموجودة في هذه الحزمة تعمل محلياً. يلزم فتح التطبيق مرة عبر خادم/حزمة APK لتثبيت ملفات التخزين المؤقت.",prayerMethod:"طريقة حساب الصلاة",prayerMethodDesc:"حساب فلكي محلي مبدئي؛ راجع الطريقة المعتمدة في بلدك واضبطها قبل الاعتماد.",locationDenied:"تعذّر تحديد الموقع. اسمح بإذن الموقع أو استخدم مدينة/إحداثيات لاحقاً.",locationFound:"تم تحديد الموقع",next:"الصلاة القادمة",noLocation:"حدّد موقعك لعرض المواقيت",fajr:"الفجر",sunrise:"الشروق",dhuhr:"الظهر",asr:"العصر",maghrib:"المغرب",isha:"العشاء",surah:"سورة",ayahs:"آية",morning:"أذكار الصباح",evening:"أذكار المساء",afterPrayer:"أذكار بعد الصلاة"},
tr:{tagline:"Huzura yol arkadaşınız",welcome:"Selâmün aleyküm ve rahmetullah",welcomeSub:"Her gün kalbinize Kur’an ve zikirden pay ayırın",prayerTimes:"Namaz vakitleri",locationPrompt:"Vakitleri yerel hesaplamak için konumunuzu belirleyin",locate:"Konumumu bul",duaTitle:"Filistin ve mazlumlar için dua",explore:"Uygulamayı keşfedin",quran:"Kur’an-ı Kerim",quranSub:"Sureler ve okuma",adhkar:"Zikirler",adhkarSub:"Seçilmiş zikirler",tasbih:"Tesbih",tasbihSub:"Zikir sayacı",qibla:"Kıble yönü",qiblaSub:"Mekke yönünü hesapla",settings:"Ayarlar",settingsSub:"Dil ve konum",home:"Ana sayfa",quranNotice:"Kur’an metni Osmanlı hattıyla eklenmiştir. İngilizce ve Türkçe meal dosyaları yüklenen kaynak dosyalardan alınmıştır; her birinde 6236 ayet anahtarı kontrol edilmiştir. Mealler Kur’an’ın Arapça metninin yerine geçmez.",tasbihHint:"Saymak için dokunun",reset:"Sıfırla",qiblaDesc:"Gerçek kuzeye göre kıble yönünü hesaplamak için konumunuzu alın.",calculate:"Yönü hesapla",language:"Uygulama dili",offline:"Çevrimdışı kullanım",offlineDesc:"Bu paketteki arayüz ve mevcut özellikler yerel çalışır. Önbelleği kurmak için uygulama bir kez sunucu/APK üzerinden açılmalıdır.",prayerMethod:"Namaz hesaplama yöntemi",prayerMethodDesc:"Başlangıç niteliğinde yerel astronomik hesaplama; kullanmadan önce ülkenizdeki yöntemi kontrol edin.",locationDenied:"Konum alınamadı. Konum izni verin.",locationFound:"Konum alındı",next:"Sonraki namaz",noLocation:"Vakitleri görmek için konumunuzu belirleyin",fajr:"İmsak",sunrise:"Güneş",dhuhr:"Öğle",asr:"İkindi",maghrib:"Akşam",isha:"Yatsı",surah:"Sure",ayahs:"ayet",morning:"Sabah zikirleri",evening:"Akşam zikirleri",afterPrayer:"Namaz sonrası zikirler"},
en:{tagline:"Your companion towards tranquility",welcome:"Peace be upon you",welcomeSub:"Give your heart a share of Qur’an and remembrance every day",prayerTimes:"Prayer times",locationPrompt:"Set your location to calculate times locally",locate:"Find my location",duaTitle:"Prayer for Palestine and the oppressed",explore:"Explore the app",quran:"The Holy Qur’an",quranSub:"Surahs and reading",adhkar:"Remembrance",adhkarSub:"Selected adhkar",tasbih:"Tasbih",tasbihSub:"Dhikr counter",qibla:"Qibla direction",qiblaSub:"Calculate direction to Makkah",settings:"Settings",settingsSub:"Language and location",home:"Home",quranNotice:"The Uthmani Arabic text and English/Turkish meaning translations from the supplied files are included. Each file contains 6,236 verse entries with matching surah and verse keys. Translations convey meanings and are not the Arabic Qur’an text.",tasbihHint:"Tap to count",reset:"Reset",qiblaDesc:"Use your location to calculate the Qibla bearing from true north.",calculate:"Calculate direction",language:"App language",offline:"Offline use",offlineDesc:"The interface and features in this package run locally. Open the app once through a server/APK to install cached files.",prayerMethod:"Prayer calculation method",prayerMethodDesc:"Preliminary local astronomical calculation; verify your local authority’s method before relying on it.",locationDenied:"Could not get location. Please allow location access.",locationFound:"Location found",next:"Next prayer",noLocation:"Set your location to show prayer times",fajr:"Fajr",sunrise:"Sunrise",dhuhr:"Dhuhr",asr:"Asr",maghrib:"Maghrib",isha:"Isha",surah:"Surah",ayahs:"verses",morning:"Morning adhkar",evening:"Evening adhkar",afterPrayer:"After-prayer adhkar"}
};
const surahsAr=["الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"];
const adhkar={
ar:[["morning","أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير."],["morning","اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور."],["evening","أمسينا وأمسى الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير."],["evening","اللهم بك أمسينا وبك أصبحنا وبك نحيا وبك نموت وإليك المصير."],["afterPrayer","أستغفر الله (ثلاثاً)، اللهم أنت السلام ومنك السلام، تباركت يا ذا الجلال والإكرام."]],
tr:[["morning","Sabaha eriştik; mülk Allah’ındır. Hamd Allah’a mahsustur. Allah’tan başka ilah yoktur; O tektir, ortağı yoktur."],["morning","Allah’ım, Senin yardımınla sabaha erdik, Senin yardımınla akşama erdik; Senin yardımınla yaşar ve ölürüz."],["evening","Akşama eriştik; mülk Allah’ındır. Hamd Allah’a mahsustur. Allah’tan başka ilah yoktur; O tektir, ortağı yoktur."],["evening","Allah’ım, Senin yardımınla akşama erdik ve sabaha erdik; Senin yardımınla yaşar ve ölürüz."],["afterPrayer","Allah’tan bağışlanma dilerim. Allah’ım, Sen es-Selâm’sın; esenlik Sendendir."]],
en:[["morning","We have entered the morning and all dominion belongs to Allah. Praise be to Allah; none has the right to be worshipped but Allah alone."],["morning","O Allah, by You we enter the morning and by You we enter the evening; by You we live and by You we die."],["evening","We have entered the evening and all dominion belongs to Allah. Praise be to Allah; none has the right to be worshipped but Allah alone."],["evening","O Allah, by You we enter the evening and by You we enter the morning; by You we live and by You we die."],["afterPrayer","I ask Allah for forgiveness (three times). O Allah, You are Peace and from You is peace."]]
};
let lang=localStorage.getItem("huda-lang")||"ar", coords=null, counter=Number(localStorage.getItem("huda-count")||0);
const $=id=>document.getElementById(id), tr=k=>T[lang][k]||k;
function setLang(l){lang=l;localStorage.setItem("huda-lang",l);document.documentElement.lang=l;document.documentElement.dir=l==="ar"?"rtl":"ltr";document.querySelectorAll("[data-i18n]").forEach(e=>e.textContent=tr(e.dataset.i18n));$("language").value=l;$("language2").value=l;renderSurahs();renderAdhkar();renderPrayer();if(coords) $("locationLabel").textContent=tr("locationFound");}
$("language").addEventListener("change",e=>setLang(e.target.value));$("language2").addEventListener("change",e=>setLang(e.target.value));
function show(id){document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===id));document.querySelectorAll("footer button").forEach(b=>b.classList.toggle("active",b.dataset.tab===id));}
document.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>show(b.dataset.open));document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>show(b.dataset.tab));document.querySelectorAll("[data-home]").forEach(b=>b.onclick=()=>show("home"));
let quranData=null;
let translationMode="ar", translations={en:null,tr:null};
function renderSurahs(){
 const box=$("surahList");
 if(!quranData){box.textContent=lang==="ar"?"جارٍ تحميل نص المصحف…":lang==="tr"?"Kur’an metni yükleniyor…":"Loading Qur’an text…";return;}
 box.innerHTML="";
 surahsAr.forEach((name,i)=>{
  const verses=quranData[i+1]||[],btn=document.createElement("button");
  btn.className="surah-btn";btn.type="button";
  const title=document.createElement("b");title.textContent=(i+1)+". "+name;
  const count=document.createElement("span");count.className="small";count.textContent=verses.length+" "+tr("ayahs");
  btn.append(title,count);btn.addEventListener("click",()=>openSurah(i+1));box.append(btn);
 });
}
async function loadTranslations(){
 for(const code of ["en","tr"]){
  try{const r=await fetch(`./data/translation-${code}.json`);if(!r.ok)continue;translations[code]=await r.json();}
  catch(_){translations[code]=null;}
 }
 updateTranslationStatus();
}
function updateTranslationStatus(){
 const el=$("translationStatus");if(!el)return;
 if(translationMode==="ar"){el.textContent=lang==="ar"?"النص العربي معروض. اختر لغة لإظهار الترجمة عند توفر ملفها.":"Arabic text is shown. Choose English or Turkish to display the uploaded meaning translation.";return;}
 el.textContent=translations[translationMode]?(translationMode==="en"?"English translation loaded.":"Türkçe meal yüklendi."):(lang==="ar"?"تعذّر تحميل ملف الترجمة؛ تحقق من مجلد data.":"Translation file could not be loaded; check the data folder.");
}
$("translationMode").addEventListener("change",e=>{translationMode=e.target.value;updateTranslationStatus();const current=Number(localStorage.getItem("huda-last-surah")||1);if($("quranReader").style.display!=="none")openSurah(current);});
function openSurah(num){
 if(!quranData||!quranData[num])return;
 const name=surahsAr[num-1],verses=quranData[num];
 const previousSurah=Number(localStorage.getItem("huda-last-surah")||0); const previousAyah=Number(localStorage.getItem("huda-last-ayah")||1);
 localStorage.setItem("huda-last-surah",String(num));
 $("surahList").style.display="none";$("quranReader").style.display="block";
 $("readerTitle").textContent=name;$("readerMeta").textContent=verses.length+" "+tr("ayahs");
 const box=$("verseList");box.innerHTML="";
 verses.forEach(v=>{
  const row=document.createElement("div");row.className="verse";row.id=`ayah-${num}-${v.n}`;
  const arabic=document.createElement("div");arabic.className="verse-ar";arabic.append(document.createTextNode(v.t+" "));
  const badge=document.createElement("span");badge.className="verse-num";badge.textContent=v.n;arabic.append(badge);row.append(arabic);
  if(translationMode!=="ar"){
   const key=`${num}:${v.n}`, translated=translations[translationMode]?.[key];
   if(translated){const t=document.createElement("div");t.className="verse-translation";t.lang=translationMode;t.textContent=translated;row.append(t);}
  }
  const tools=document.createElement("div");tools.style.cssText="display:flex;justify-content:flex-end;gap:8px;margin-top:6px";
  const fav=document.createElement("button");fav.className="action secondary";fav.textContent=isFavorite(num,v.n)?"★ إزالة من المفضلة":"☆ حفظ في المفضلة";fav.onclick=()=>{toggleFavorite(num,v.n);fav.textContent=isFavorite(num,v.n)?"★ إزالة من المفضلة":"☆ حفظ في المفضلة";renderFavorites();};tools.append(fav);row.append(tools);box.append(row);
 });
 const savedAyah=previousSurah===num?previousAyah:1;
 window.scrollTo({top:0,behavior:"smooth"});
 if(Number(localStorage.getItem("huda-last-surah"))===num && savedAyah>1){setTimeout(()=>document.getElementById(`ayah-${num}-${savedAyah}`)?.scrollIntoView({block:"start",behavior:"smooth"}),120);}
}
function backToSurahs(){$("quranReader").style.display="none";$("surahList").style.display="block";window.scrollTo({top:0,behavior:"smooth"});}
$("backSurahs").addEventListener("click",backToSurahs);
async function loadQuran(){
 try{const res=await fetch("./data/quran-uthmani.json");if(!res.ok)throw new Error("Quran data unavailable");quranData=await res.json();renderSurahs();
  const last=Number(localStorage.getItem("huda-last-surah")||0);if(last>=1&&last<=114){/* محفوظة للعودة لاحقاً دون فتح مفاجئ */}
 }catch(e){$("surahList").textContent=lang==="ar"?"تعذّر تحميل ملف القرآن. تأكد من وجود مجلد data داخل التطبيق.":"Could not load Qur’an data. Check the app data folder.";}
}
function renderAdhkar(){
 const a=adhkar[lang], labels={ar:{morning:"أذكار الصباح",evening:"أذكار المساء",afterPrayer:"أذكار بعد الصلاة",count:"العدد",reset:"تصفير"},tr:{morning:"Sabah zikirleri",evening:"Akşam zikirleri",afterPrayer:"Namaz sonrası",count:"Sayı",reset:"Sıfırla"},en:{morning:"Morning adhkar",evening:"Evening adhkar",afterPrayer:"After-prayer adhkar",count:"Count",reset:"Reset"}}[lang];
 const saved=JSON.parse(localStorage.getItem("huda-adhkar-counts")||"{}");
 $("adhkarList").innerHTML=a.map(([cat,txt],i)=>{const key=lang+":"+i;return `<div class="listitem" style="padding:14px 0;border-bottom:1px solid #e8e2d4"><b>${labels[cat]||cat}</b><div style="line-height:2;margin:9px 0">${txt}</div><div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap"><button class="action" data-dh-count="${key}">＋</button><strong id="dh-${i}">${saved[key]||0}</strong><small>${labels.count}</small><button class="action secondary" data-dh-reset="${key}" data-dh-id="${i}">${labels.reset}</button></div></div>`}).join("");
 $("adhkarList").querySelectorAll("[data-dh-count]").forEach(b=>b.onclick=()=>{const k=b.dataset.dhCount;const v=JSON.parse(localStorage.getItem("huda-adhkar-counts")||"{}");v[k]=(v[k]||0)+1;localStorage.setItem("huda-adhkar-counts",JSON.stringify(v));$("dh-"+k.split(":")[1]).textContent=v[k];});
 $("adhkarList").querySelectorAll("[data-dh-reset]").forEach(b=>b.onclick=()=>{const k=b.dataset.dhReset,v=JSON.parse(localStorage.getItem("huda-adhkar-counts")||"{}");v[k]=0;localStorage.setItem("huda-adhkar-counts",JSON.stringify(v));$("dh-"+b.dataset.dhId).textContent="0";});
}
const tasbihPhrases={ar:["سُبْحَانَ اللَّه","الْحَمْدُ لِلَّه","اللَّهُ أَكْبَر","أَسْتَغْفِرُ اللَّه"],tr:["Sübhanallah","Elhamdülillah","Allahu ekber","Estağfirullah"],en:["SubhanAllah","Alhamdulillah","Allahu Akbar","Astaghfirullah"]};
const phraseSelect=document.createElement("select");phraseSelect.id="tasbihPhrase";phraseSelect.className="action secondary";phraseSelect.style.margin="12px auto";tasbihPhrases[lang].forEach((x,i)=>{const o=document.createElement("option");o.value=i;o.textContent=x;phraseSelect.append(o)});$("bead").before(phraseSelect);phraseSelect.onchange=()=>{$("bead").textContent=tasbihPhrases[lang][Number(phraseSelect.value)]};
$("bead").onclick=()=>{counter++;$("count").textContent=counter;localStorage.setItem("huda-count",counter)};$("reset").onclick=()=>{counter=0;$("count").textContent=0;localStorage.setItem("huda-count",0)};$("count").textContent=counter;
const prayerKeys=["fajr","sunrise","dhuhr","asr","maghrib","isha"];
function rad(d){return d*Math.PI/180} function deg(r){return r*180/Math.PI}
function dayOfYear(d){return Math.floor((Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())-Date.UTC(d.getFullYear(),0,0))/86400000)}
const prayerMethods={MWL:{fajr:18,isha:17},EGYPT:{fajr:19.5,isha:17.5},UMM:{fajr:18.5,isha:0,ishaInterval:90},TURKEY:{fajr:18,isha:17},NORTH:{fajr:15,isha:15}};
let prayerMethod=localStorage.getItem("huda-prayer-method")||"MWL", asrFactor=Number(localStorage.getItem("huda-asr-factor")||1), customFajr=18,customIsha=17, notificationTimer=null, lastPrayerAlert="";
function currentPrayerParams(){let p=prayerMethods[prayerMethod]||prayerMethods.MWL;if(prayerMethod==="CUSTOM")p={fajr:Number($("customFajr")?.value||18),isha:Number($("customIsha")?.value||17)};return p;}
function solar(lat,lon,date){
 const N=dayOfYear(date),g=2*Math.PI/365*(N-1),eq=229.18*(0.000075+0.001868*Math.cos(g)-0.032077*Math.sin(g)-0.014615*Math.cos(2*g)-0.040849*Math.sin(2*g)),dec=0.006918-0.399912*Math.cos(g)+0.070257*Math.sin(g)-0.006758*Math.cos(2*g)+0.000907*Math.sin(2*g)-0.002697*Math.cos(3*g)+0.00148*Math.sin(3*g);
 const noon=720-4*lon-eq-date.getTimezoneOffset();
 function hourAngle(alt){const x=(Math.sin(rad(alt))-Math.sin(rad(lat))*Math.sin(dec))/(Math.cos(rad(lat))*Math.cos(dec));if(x < -1 || x > 1)return NaN;return Math.acos(x)*12/Math.PI;}
 const params=currentPrayerParams(), sunrise=noon-hourAngle(-0.833), sunset=noon+hourAngle(-0.833), dhuhr=noon+2, asrAltitude=deg(Math.atan(1/(asrFactor+Math.tan(Math.abs(rad(lat)-dec))))),asr=noon+hourAngle(asrAltitude);
 // For high-latitude summer dates where twilight angle does not occur, use a documented one-seventh-of-night fallback.
 const nightMinutes=Number.isFinite(sunrise)&&Number.isFinite(sunset)?1440-(sunset-sunrise):NaN;
 let fajr=noon-hourAngle(-params.fajr);
 if(!Number.isFinite(fajr)&&Number.isFinite(nightMinutes))fajr=sunrise-nightMinutes/7;
 let isha=params.ishaInterval? sunset+params.ishaInterval : noon+hourAngle(-params.isha);
 if(!Number.isFinite(isha)&&Number.isFinite(nightMinutes))isha=sunset+nightMinutes/7;
 return [fajr,sunrise,dhuhr,asr,sunset,isha].map(x=>Number.isFinite(x)?((x%1440)+1440)%1440:NaN);
}
function fmt(m){if(!Number.isFinite(m))return "—:—";let h=Math.floor(m/60),mi=Math.floor(m%60);return `${String(h).padStart(2,"0")}:${String(mi).padStart(2,"0")}`}
function renderPrayer(){const grid=$("prayerGrid");if(!coords){grid.innerHTML=prayerKeys.map(k=>`<div class="prayer"><b>${tr(k)}</b><span>--:--</span></div>`).join("");$("nextPrayer").textContent=tr("noLocation");return}const times=solar(coords.lat,coords.lon,new Date());grid.innerHTML=prayerKeys.map((k,i)=>`<div class="prayer"><b>${tr(k)}</b><span>${fmt(times[i])}</span></div>`).join("");const now=new Date(),mins=now.getHours()*60+now.getMinutes();let idx=times.findIndex((v,i)=>i!==1&&Number.isFinite(v)&&v>mins);if(idx<0)idx=0;$("nextPrayer").textContent=tr("next")+": "+tr(prayerKeys[idx])+" — "+fmt(times[idx]);schedulePrayerAlert(times);}
function persistCoords(){if(coords)localStorage.setItem("huda-coordinates",JSON.stringify(coords));}
function getLocation(cb){
 const label=$("locationLabel");
 if(!window.isSecureContext && location.protocol!=="file:"){
   label.textContent="يلزم تشغيل التطبيق عبر HTTPS أو داخل WebView مُعدّ بإذن الموقع؛ لن يعمل تحديد الموقع من صفحة HTTP عادية.";
   return;
 }
 if(!navigator.geolocation){label.textContent="ميزة تحديد الموقع غير متاحة في بيئة التشغيل هذه. استخدم إدخال الإحداثيات يدوياً من الإعدادات.";return;}
 label.textContent="جارٍ طلب إذن الموقع…";
 navigator.geolocation.getCurrentPosition(p=>{
   coords={lat:p.coords.latitude,lon:p.coords.longitude};persistCoords();
   label.textContent=`تم تحديد الموقع: ${coords.lat.toFixed(4)}, ${coords.lon.toFixed(4)}`;
   $("manualLat").value=coords.lat;$("manualLon").value=coords.lon;
   renderPrayer();if(cb)cb();
 },err=>{
   const messages={1:"تم رفض إذن الموقع. اسمح للتطبيق بالوصول إلى الموقع من إعدادات الهاتف ثم حاول مجدداً.",2:"تعذّر الوصول إلى إشارة الموقع. تحقق من تشغيل خدمات الموقع أو أدخل الإحداثيات يدوياً.",3:"انتهت مهلة تحديد الموقع. حاول مجدداً أو أدخل الإحداثيات يدوياً."};
   label.textContent=messages[err.code]||"تعذّر تحديد الموقع. أدخل الإحداثيات يدوياً من الإعدادات.";
 },{enableHighAccuracy:true,timeout:25000,maximumAge:600000});
}
function setupPrayerSettings(){
 const method=$("prayerMethodSelect"),asr=$("asrMethod"),cf=$("customFajr"),ci=$("customIsha"),notify=$("prayerNotifications");
 method.value=prayerMethod;asr.value=String(asrFactor);$("customAngles").style.display=prayerMethod==="CUSTOM"?"flex":"none";
 method.addEventListener("change",()=>{prayerMethod=method.value;localStorage.setItem("huda-prayer-method",prayerMethod);$("customAngles").style.display=prayerMethod==="CUSTOM"?"flex":"none";renderPrayer();});
 asr.addEventListener("change",()=>{asrFactor=Number(asr.value);localStorage.setItem("huda-asr-factor",String(asrFactor));renderPrayer();});
 [cf,ci].forEach(el=>el.addEventListener("change",()=>{if(prayerMethod==="CUSTOM")renderPrayer();}));
 const saved=JSON.parse(localStorage.getItem("huda-coordinates")||"null");if(saved&&Number.isFinite(saved.lat)&&Number.isFinite(saved.lon)){coords=saved;$("locationLabel").textContent=tr("locationFound");$("manualLat").value=saved.lat;$("manualLon").value=saved.lon;}
 $("saveManualLocation").addEventListener("click",()=>{const lat=Number($("manualLat").value),lon=Number($("manualLon").value);if(!$("manualLat").value||!$("manualLon").value||lat < -90||lat>90||lon < -180||lon>180){$("notificationStatus").textContent="أدخل إحداثيات صحيحة: العرض من -90 إلى 90 والطول من -180 إلى 180.";return;}coords={lat,lon};persistCoords();$("locationLabel").textContent=`الموقع: ${lat.toFixed(4)}, ${lon.toFixed(4)}`;renderPrayer();});
 $("clearManualLocation").addEventListener("click",()=>{coords=null;localStorage.removeItem("huda-coordinates");$("manualLat").value="";$("manualLon").value="";$("locationLabel").textContent=tr("locationPrompt");renderPrayer();});
 notify.checked=localStorage.getItem("huda-prayer-notifications")==="true";notify.addEventListener("change",async()=>{if(notify.checked){if(!("Notification" in window)){notify.checked=false;$("notificationStatus").textContent="الإشعارات غير مدعومة في هذا المتصفح.";return;}const permission=await Notification.requestPermission();if(permission!=="granted"){notify.checked=false;$("notificationStatus").textContent="لم يتم منح إذن الإشعارات.";return;}localStorage.setItem("huda-prayer-notifications","true");$("notificationStatus").textContent="التنبيهات مفعّلة أثناء بقاء التطبيق مفتوحاً.";}else{localStorage.setItem("huda-prayer-notifications","false");$("notificationStatus").textContent="تم إيقاف التنبيهات.";}renderPrayer();});
}
function schedulePrayerAlert(times){if(notificationTimer)clearTimeout(notificationTimer);if(localStorage.getItem("huda-prayer-notifications")!=="true"||document.visibilityState==="hidden")return;const now=new Date(),mins=now.getHours()*60+now.getMinutes()+now.getSeconds()/60;let next=null;for(let i=0;i<times.length;i++){if(i===1||!Number.isFinite(times[i]))continue;let delta=times[i]-mins;if(delta<=0)delta+=1440;if(!next||delta<next.delta)next={i,delta};}if(!next)return;notificationTimer=setTimeout(()=>{if(document.visibilityState==="visible"&&"Notification" in window&&Notification.permission==="granted"){const label=tr(prayerKeys[next.i]);new Notification("هُدَى لِلْعَالَمِينَ",{body:`حان الآن وقت صلاة ${label}`});lastPrayerAlert=label;}renderPrayer();},Math.max(1000,next.delta*60000));}
document.addEventListener("visibilitychange",()=>{if(coords)renderPrayer();});
setInterval(()=>{if(coords&&document.visibilityState==="visible")renderPrayer();},60000);
let qiblaBearing=null, deviceHeading=null, orientationListening=false;
function calculateQibla(){
 if(!coords){$("qiblaStatus").textContent="حدّد موقعك من زر تحديد الاتجاه أو أدخل الإحداثيات في الإعدادات أولاً.";return;}
 const lat1=rad(coords.lat),lat2=rad(21.4225),dl=rad(39.8262-coords.lon);
 const y=Math.sin(dl),x=Math.cos(lat1)*Math.tan(lat2)-Math.sin(lat1)*Math.cos(dl);
 qiblaBearing=(deg(Math.atan2(y,x))+360)%360;
 $("bearing").textContent=Math.round(qiblaBearing)+"°";
 $("qiblaStatus").textContent=`اتجاه القبلة من الشمال الحقيقي: ${qiblaBearing.toFixed(1)}°. ${deviceHeading===null?"فعّل البوصلة الحركية لمعرفة اتجاه تدوير الهاتف.":"البوصلة الحركية مفعّلة."}`;
 updateQiblaNeedle();
}
function updateQiblaNeedle(){if(qiblaBearing===null)return;const angle=qiblaBearing-(deviceHeading===null?0:deviceHeading);$("qiblaNeedle").style.transform=`translate(-50%,-50%) rotate(${angle}deg)`;}
function onDeviceOrientation(e){let heading=null;if(typeof e.webkitCompassHeading==="number")heading=e.webkitCompassHeading;else if(e.absolute&&typeof e.alpha==="number")heading=(360-e.alpha)%360;if(heading!==null){deviceHeading=heading;updateQiblaNeedle();if(qiblaBearing!==null)$("qiblaStatus").textContent=`اتجاه الهاتف بالنسبة للشمال: ${Math.round(heading)}° — اتبع السهم نحو القبلة.`;}}
async function enableQiblaCompass(){try{if(typeof DeviceOrientationEvent==="undefined"){ $("qiblaStatus").textContent="حساس اتجاه الهاتف غير متاح على هذا الجهاز؛ يمكنك استخدام زاوية القبلة الرقمية.";return;}if(typeof DeviceOrientationEvent.requestPermission==="function"){const permission=await DeviceOrientationEvent.requestPermission();if(permission!=="granted")throw new Error("لم يُمنح إذن حساس الاتجاه.");}if(!orientationListening){window.addEventListener("deviceorientationabsolute",onDeviceOrientation,true);window.addEventListener("deviceorientation",onDeviceOrientation,true);orientationListening=true;}$("qiblaStatus").textContent="تم طلب البوصلة. حرّك الهاتف ببطء على شكل رقم 8 لمعايرته.";}catch(err){$("qiblaStatus").textContent=err.message||"تعذّر تفعيل البوصلة؛ استخدم الزاوية الرقمية.";}}
$("qiblaLocate").onclick=()=>{if(coords){calculateQibla();return;}getLocation(calculateQibla);};
$("qiblaCompassEnable").onclick=enableQiblaCompass;
$("locate").addEventListener("click",()=>getLocation());
setLang(lang);setupPrayerSettings();renderPrayer();loadQuran();loadTranslations();
if("serviceWorker" in navigator && location.protocol!=="file:"){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}


// Phase 4: streaming and per-surah offline audio library.
const AUDIO_API="https://www.mp3quran.net/api/v3/reciters?language=ar";
const AUDIO_CACHE="huda-quran-audio-v1";
const preferredReciters=[
 {match:["مشاري العفاسي","مشاري بن راشد العفاسي"],fallback:"مشاري العفاسي"},
 {match:["عبد الباسط عبد الصمد","عبدالباسط عبدالصمد"],fallback:"عبد الباسط عبد الصمد"},
 {match:["ماهر المعيقلي"],fallback:"ماهر المعيقلي"},
 {match:["محمود خليل الحصري","محمود خليل الحصرى"],fallback:"محمود خليل الحصري"},
 {match:["سعد الغامدي"],fallback:"سعد الغامدي"},
 {match:["عبدالرحمن السديس","عبد الرحمن السديس"],fallback:"عبدالرحمن السديس"},
 {match:["ياسر الدوسري","ياسر بن راشد الدوسري"],fallback:"ياسر الدوسري"}
];
let audioReciters=[], audioObjectUrl=null;
function audioMessage(text){const el=$("audioStatus");if(el)el.textContent=text;}
function fillAudioSurahs(){const el=$("audioSurah");if(!el)return;el.innerHTML="";surahsAr.forEach((name,i)=>{const o=document.createElement("option");o.value=String(i+1);o.textContent=`${i+1}. ${name}`;el.append(o);});}
async function loadAudioReciters(){
 const select=$("audioReciter"); if(!select)return;
 try{
  const response=await fetch(AUDIO_API,{cache:"no-store"}); if(!response.ok)throw new Error("HTTP "+response.status);
  const data=await response.json(); const all=data.reciters||[];
  audioReciters=[];
  for(const wanted of preferredReciters){
   let found=null;
   for(const r of all){const name=String(r.name||"");if(wanted.match.some(m=>name.includes(m))){const moshaf=(r.moshaf||[]).find(x=>x.server&&x.surah_list)|| (r.moshaf||[]).find(x=>x.server);if(moshaf){found={name,server:moshaf.server,moshafName:moshaf.name||"رواية حفص",surahs:(moshaf.surah_list||"").split(",").map(Number).filter(Boolean)};break;}}}
   if(found)audioReciters.push(found);
  }
  select.innerHTML="";
  if(!audioReciters.length)throw new Error("لم يتم العثور على القراء المطلوبين في رد المصدر");
  audioReciters.forEach((r,i)=>{const o=document.createElement("option");o.value=String(i);o.textContent=r.name+" — "+r.moshafName;select.append(o);});
  updateAudioAvailability(); audioMessage(`تم تحميل قائمة القراء. المتاح حالياً ${audioReciters.length} من أصل ${preferredReciters.length} قراء مقترحين.`);
 }catch(e){select.innerHTML='<option value="">تعذّر تحميل قائمة القراء</option>';audioMessage("تعذّر الاتصال بمصدر قائمة القراء. تحقق من الإنترنت ثم أعد فتح قسم التلاوات.");}
}
function selectedAudio(){const r=audioReciters[Number($("audioReciter")?.value||0)];const surah=Number($("audioSurah")?.value||1);if(!r)return null;return {reciter:r,surah,url:r.server+String(surah).padStart(3,"0")+".mp3",key:`${r.name}|${surah}`};}
function updateAudioAvailability(){const item=selectedAudio();if(!item)return;const available=!item.reciter.surahs.length||item.reciter.surahs.includes(item.surah);$("audioPlay").disabled=!available;$("audioDownload").disabled=!available;if(!available)audioMessage("هذه السورة غير مدرجة ضمن التسجيلات المتاحة لهذا القارئ.");}
async function getAudioCache(){return await caches.open(AUDIO_CACHE);}
async function playSelectedAudio(){
 const item=selectedAudio();if(!item){audioMessage("اختر قارئاً أولاً.");return;}
 try{const cache=await getAudioCache();const saved=await cache.match(item.url);let src=item.url;
  if(saved){if(audioObjectUrl)URL.revokeObjectURL(audioObjectUrl);audioObjectUrl=URL.createObjectURL(await saved.blob());src=audioObjectUrl;audioMessage("تشغيل النسخة المحفوظة على الجهاز — دون إنترنت.");}
  else audioMessage("جارٍ الاتصال لتشغيل التلاوة. لتنزيلها للاستماع دون إنترنت اضغط زر التنزيل.");
  const player=$("quranAudio");player.src=src;await player.play();
 }catch(e){audioMessage("تعذّر التشغيل. قد يكون الاتصال أو مصدر الصوت غير متاح حالياً.");}
}
async function downloadSelectedAudio(){
 const item=selectedAudio();if(!item){audioMessage("اختر قارئاً أولاً.");return;}
 const btn=$("audioDownload");btn.disabled=true;audioMessage("جارٍ تنزيل السورة… أبقِ التطبيق مفتوحاً حتى اكتمال التنزيل.");
 try{
  const response=await fetch(item.url,{mode:"cors",cache:"no-store"});if(!response.ok||response.type==="opaque")throw new Error("تعذر الوصول إلى ملف الصوت");
  const blob=await response.blob();if(!blob.size)throw new Error("ملف الصوت فارغ");
  const cache=await getAudioCache();await cache.put(item.url,new Response(blob,{headers:{"Content-Type":response.headers.get("Content-Type")||"audio/mpeg","X-Huda-Reciter":encodeURIComponent(item.reciter.name),"X-Huda-Surah":String(item.surah),"X-Huda-Size":String(blob.size)}}));
  audioMessage(`اكتمل تنزيل سورة ${surahsAr[item.surah-1]} (${formatBytes(blob.size)}). أصبحت متاحة دون إنترنت على هذا الجهاز.`);await renderDownloadedAudio();
 }catch(e){audioMessage("لم يكتمل التنزيل. قد يمنع خادم الصوت التنزيل المباشر أو لا يدعم الاتصال من WebView. يمكن تجربة التشغيل عبر الإنترنت أو إعداد خادم وسيط لاحقاً.");}
 finally{btn.disabled=false;updateAudioAvailability();}
}
function formatBytes(n){if(n<1024*1024)return (n/1024).toFixed(0)+" KB";return (n/1024/1024).toFixed(1)+" MB";}
async function renderDownloadedAudio(){
 const box=$("downloadedAudioList");if(!box)return;
 try{const cache=await getAudioCache(),keys=await cache.keys();box.innerHTML="";
  if(!keys.length){box.innerHTML='<p class="small">لم تُنزّل تلاوات بعد.</p>';$("audioStorage").textContent="";return;}
  let total=0;
  for(const request of keys){const res=await cache.match(request);const size=Number(res.headers.get("X-Huda-Size")||0);total+=size;const rec=decodeURIComponent(res.headers.get("X-Huda-Reciter")||"قارئ");const surah=Number(res.headers.get("X-Huda-Surah")||0);const row=document.createElement("div");row.className="audio-item";const info=document.createElement("div");info.textContent=`${rec} — ${surahsAr[surah-1]||"سورة"}`;const small=document.createElement("small");small.textContent=formatBytes(size)+" • محفوظة دون إنترنت";info.append(small);const del=document.createElement("button");del.className="action secondary";del.textContent="حذف";del.onclick=async()=>{await cache.delete(request);await renderDownloadedAudio();};row.append(info,del);box.append(row);
  }
  $("audioStorage").textContent=`المساحة التقريبية المستخدمة للتلاوات: ${formatBytes(total)}.`;
 }catch(e){box.textContent="ميزة التخزين غير متاحة في هذا المتصفح.";}
}
$("audioPlay")?.addEventListener("click",playSelectedAudio);
$("audioDownload")?.addEventListener("click",downloadSelectedAudio);
$("audioReciter")?.addEventListener("change",updateAudioAvailability);
$("audioSurah")?.addEventListener("change",updateAudioAvailability);
$("refreshAudioDownloads")?.addEventListener("click",renderDownloadedAudio);

// Phase 8: Hijri date, ayah favorites, and reading position.
function getFavorites(){try{return JSON.parse(localStorage.getItem("huda-quran-favorites")||"[]");}catch(_){return [];}}
function isFavorite(s,a){return getFavorites().some(x=>x.s===s&&x.a===a);}
function toggleFavorite(s,a){let f=getFavorites();f=isFavorite(s,a)?f.filter(x=>!(x.s===s&&x.a===a)):[...f,{s,a}];localStorage.setItem("huda-quran-favorites",JSON.stringify(f));}
function renderFavorites(){const box=$("favoritesList");if(!box)return;const f=getFavorites();box.innerHTML="";if(!f.length){box.textContent="لا توجد آيات محفوظة بعد.";return;}f.forEach(x=>{const verse=quranData?.[x.s]?.find(v=>v.n===x.a);const row=document.createElement("div");row.className="listitem";const title=document.createElement("b");title.textContent=`${surahsAr[x.s-1]} — الآية ${x.a}`;const text=document.createElement("p");text.textContent=verse?.t||"";const open=document.createElement("button");open.className="action secondary";open.textContent="فتح الآية";open.onclick=()=>{show("quran");openSurah(x.s);setTimeout(()=>document.getElementById(`ayah-${x.s}-${x.a}`)?.scrollIntoView({behavior:"smooth",block:"center"}),180);};const remove=document.createElement("button");remove.className="action secondary";remove.textContent="إزالة";remove.style.marginRight="8px";remove.onclick=()=>{toggleFavorite(x.s,x.a);renderFavorites();};row.append(title,text,open,remove);box.append(row);});}
function renderHijriDate(){const now=new Date();let h="";try{h=new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura",{weekday:"long",year:"numeric",month:"long",day:"numeric"}).format(now);}catch(e){try{h=new Intl.DateTimeFormat("ar-SA-u-ca-islamic",{weekday:"long",year:"numeric",month:"long",day:"numeric"}).format(now);}catch(_){h="التقويم الهجري غير مدعوم في هذا الجهاز";}}const a=$("hijriDate"),b=$("gregorianDate"),c=$("homeHijriDate");if(a)a.textContent=h;if(c)c.textContent=h;if(b)b.textContent=new Intl.DateTimeFormat(lang==="ar"?"ar":lang==="tr"?"tr-TR":"en-GB",{dateStyle:"full"}).format(now);}
function updateLastReading(){const s=Number(localStorage.getItem("huda-last-surah")||0),a=Number(localStorage.getItem("huda-last-ayah")||1);$("lastReadingInfo").textContent=s?`${surahsAr[s-1]} — الآية ${a}`:"لم تبدأ القراءة بعد.";}
function resumeLastReading(){const s=Number(localStorage.getItem("huda-last-surah")||0),a=Number(localStorage.getItem("huda-last-ayah")||1);if(s>=1&&s<=114){show("quran");openSurah(s);setTimeout(()=>document.getElementById(`ayah-${s}-${a}`)?.scrollIntoView({behavior:"smooth",block:"start"}),180);}else{show("quran");}}
$("resumeReading")?.addEventListener("click",resumeLastReading);$("resumeReading2")?.addEventListener("click",resumeLastReading);
window.addEventListener("scroll",()=>{if($("quranReader")?.style.display==="block"){const rows=[...document.querySelectorAll("#verseList .verse")];let current=rows.find(r=>r.getBoundingClientRect().bottom>100);if(current){const m=current.id.match(/^ayah-(\d+)-(\d+)$/);if(m){localStorage.setItem("huda-last-surah",m[1]);localStorage.setItem("huda-last-ayah",m[2]);updateLastReading();}}}},{passive:true});
renderHijriDate();renderFavorites();updateLastReading();
fillAudioSurahs();loadAudioReciters();renderDownloadedAudio();
