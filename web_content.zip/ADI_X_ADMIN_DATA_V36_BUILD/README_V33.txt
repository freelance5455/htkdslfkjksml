ADI X ADMIN DATA V33 — Communication + Maintenance + Premium Notification Deep Fix

Admin-only build. User app files are intentionally not modified in this release.

Changes:
- Six dedicated Telegram destinations remain independent; Open Telegram uses a direct anchor navigation from the click gesture to avoid popup/webview errors.
- Emergency Command Deck is removed from Settings and its legacy command flags are removed from the save/reset model.
- Maintenance settings now include a dedicated title and message so the client can render an unclosable maintenance popup from Firebase state.
- Notifications now write premium-popup metadata: title, message, dismissible close button, optional auto-close, close countdown seconds, and live-countdown intent.
- Existing keys, withdrawal, users, support, financial telemetry and other settings are preserved.
- Visible product name: ADI X ADMIN DATA.
