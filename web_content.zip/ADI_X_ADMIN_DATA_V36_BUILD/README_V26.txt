ADI X DATA V26
Base: ADI X DATA V10 Permission Ultimate.
Key redemption reconciliation: Admin now reads activationRedemptions/levelRedemptions, resolves user name/mobile, marks authoritative keys USED, stops countdown timers for used/revoked keys, and updates public status mirrors without exposing private user fields. UI/style preserved. Firebase project: data-x-pro-77. Publish the included Firebase V10/V26-compatible rules already used in the live project.
