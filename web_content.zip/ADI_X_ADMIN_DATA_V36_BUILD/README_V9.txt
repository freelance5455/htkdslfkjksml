ADI X DATA V9 - Admin

Base: existing ADI X DATA V7 Admin UI/ecosystem.
Backend: new Firebase project data-x-pro-77.

V9 changes:
- Admin identity now matches BOTH authorised email and the current Admin UID.
- Delete action is optimistic: the card is removed immediately; Firebase cleanup continues in the background.
- Public key mirror cleanup no longer blocks authoritative key deletion.
- Expired-key cleanup is parallelised and non-blocking for UI refresh.
- Automatic safety snapshots are stored under /backup and in browser localStorage before destructive actions.
- Security Center includes a manual full JSON backup download.
- Public mirror diagnostics remain visible.
- Firebase V9 rules are included and must be published in Realtime Database.

IMPORTANT:
Publishing FIREBASE_V9_RULES.json in the new data-x-pro-77 Realtime Database is required for server-side permissions.
