// ADI X ADMIN DATA V35
// ADI X DATA V27 Permanent User Delete backend integration

import {initializeApp} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import {getAuth,signInWithEmailAndPassword,onAuthStateChanged,signOut} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";
import {getDatabase,ref,onValue,get,set,update,remove,push,runTransaction} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-database.js";

const cfg={
  apiKey:"AIzaSyAG0gMcBIiRurtXssJ-R4TuCL4zmLcXxJ4",
  authDomain:"data-x-pro-77.firebaseapp.com",
  databaseURL:"https://data-x-pro-77-default-rtdb.firebaseio.com",
  projectId:"data-x-pro-77",
  storageBucket:"data-x-pro-77.firebasestorage.app",
  messagingSenderId:"369843405458",
  appId:"1:369843405458:android:43a7307528772e95ac5c4b"
};
let app,auth,db;
try{app=initializeApp(cfg);auth=getAuth(app);db=getDatabase(app)}catch(e){document.body.innerHTML=`<main style="padding:24px;color:#fff;font-family:system-ui"><h2>Admin could not start</h2><p>Firebase configuration could not be loaded. Check the Firebase configuration and reload.</p></main>`;throw e}
const ADMIN_EMAIL="adityanooption@gmail.com";
const ADMIN_UID="uUXSoYnTLxNpDgF8fqh0Ea3IGWK2";
function isConfiguredAdmin(){
  const u=auth.currentUser;
  return !!u && String(u.email||"").toLowerCase()===ADMIN_EMAIL && String(u.uid||"")===ADMIN_UID;
}
function adminIdentityError(){
  const u=auth.currentUser;
  if(!u)return "No authenticated Firebase session.";
  if(isConfiguredAdmin())return "";
  return "This Firebase account is not the configured Admin account.";
}

const $=id=>document.getElementById(id);
const show=e=>e?.classList.remove("hidden"), hide=e=>e?.classList.add("hidden");
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const safeKey=s=>String(s??"").replace(/[^A-Za-z0-9_-]/g,"");
const maskEmail=e=>{const s=String(e||"");const [a,b]=s.split("@");return a?(a.slice(0,2)+"•••"+(b?"@"+b:"")):"—"};
const maskMobile=m=>{const s=String(m||"");return s.length>4?"••••••"+s.slice(-4):"••••"};
const money=n=>"₹"+Number(n||0).toFixed(2);
function fmtDT(ms){ const n=Number(ms); if(!Number.isFinite(n)||n<=0)return "—"; return new Date(n).toLocaleString(undefined,{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:true}); }
function random(n=9){ const chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let out=""; const a=new Uint32Array(n); crypto.getRandomValues(a); for(let i=0;i<n;i++) out+=chars[a[i]%chars.length]; return out; }
function keyLifetime(policy){ const value=Math.max(1,Number(policy?.keyLifetimeValue)||24); const unit=policy?.keyLifetimeUnit||"hours"; return unit==="seconds"?value*1000:unit==="minutes"?value*60*1000:value*60*60*1000; }
function keyLifetimeLabel(policy){ const value=Math.max(1,Number(policy?.keyLifetimeValue)||24); const unit=policy?.keyLifetimeUnit||"hours"; const label=unit==="seconds"?"second":unit==="minutes"?"minute":"hour"; return `${value} ${label}${value===1?"":"s"}`; }
async function ensureAdminSession(){
  const u=auth.currentUser;
  if(!u) throw new Error("Admin session is not signed in.");
  if(String(u.email||"").toLowerCase()!==ADMIN_EMAIL) throw new Error("Authorised admin email mismatch.");
  await u.getIdToken(true);
  return u;
}
async function safeRemove(path){
  await ensureAdminSession();
  // Use RTDB remove() for an explicit server-side delete.
  await remove(ref(db,path));
}

async function safetyBackup(type,payload){
  const record={type,createdAt:Date.now(),adminUid:auth.currentUser?.uid||null,payload};
  try{
    const local=JSON.parse(localStorage.getItem("adi_x_data_safety_backups")||"[]");
    local.unshift(record);
    localStorage.setItem("adi_x_data_safety_backups",JSON.stringify(local.slice(0,25)));
  }catch(e){}
  try{await set(push(ref(db,"backup")),record)}catch(e){console.warn("Safety backup write failed",e)}
}
function downloadJson(filename,data){
  try{const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}catch(e){console.warn("Backup download failed",e)}
}
async function firebaseAdminSelfTest(){
  if(!isConfiguredAdmin()) throw new Error("Admin authorisation required");
  const token=await auth.currentUser.getIdToken(true);
  if(!token) throw new Error("Admin token unavailable");
  return {uid:auth.currentUser.uid,admin:true};
}
window.toast=(text,type="ok")=>{let t=document.querySelector(".lux-toast");if(!t){t=document.createElement("div");t.className="lux-toast";document.body.appendChild(t)}t.textContent=text;t.classList.toggle("bad",type==="bad");requestAnimationFrame(()=>t.classList.add("show"));clearTimeout(t._timer);t._timer=setTimeout(()=>t.classList.remove("show"),1800)};
async function withRefresh(btn,fn){
  if(!btn||btn.dataset.busy==="1")return;
  btn.dataset.busy="1";btn.classList.add("is-refreshing");
  const old=btn.innerHTML;btn.innerHTML='<span class="spin">↻</span> Refreshing';
  const started=performance.now();
  try{await fn()}catch(e){window.toast("Refresh failed: "+(e?.code||e?.message||"Unknown error"),"bad")}
  finally{
    const wait=Math.max(0,250-(performance.now()-started));
    setTimeout(()=>{btn.innerHTML=old;btn.classList.remove("is-refreshing");btn.dataset.busy="0"},wait);
  }
}
function setActionBusy(btn,busy,label){if(!btn)return;if(busy){btn.dataset.oldText=btn.innerHTML;btn.disabled=true;btn.innerHTML='<span class="spin">◌</span> '+(label||"Working") }else{btn.disabled=false;btn.innerHTML=btn.dataset.oldText||btn.innerHTML}}

function normalizeAdminSupport(raw){
  let u=String(raw||"").trim().replace(/\s+/g,"");
  if(!u)return "";
  if(/^https?:\/\//i.test(u))return u;
  if(/^t\.me\//i.test(u))return "https://"+u;
  if(/^telegram\.me\//i.test(u))return "https://"+u;
  if(/^@/.test(u))return "https://t.me/"+u.slice(1);
  if(/^[A-Za-z0-9_]{3,64}$/.test(u))return "https://t.me/"+u;
  return "";
}
function authMessage(e){const c=e?.code||"";if(["auth/invalid-credential","auth/wrong-password","auth/user-not-found","auth/invalid-email"].includes(c))return "Wrong email or password.";if(c==="auth/too-many-requests")return "Too many attempts. Please try again later.";if(c==="auth/network-request-failed")return "Network error. Check your internet connection.";return "Something went wrong. Please try again."}
async function audit(action,extra={}){try{await push(ref(db,"auditLogs"),{action,at:Date.now(),...extra})}catch(e){console.warn("Audit write failed",e)}}
async function deregisterUser(uid){
  if(!isConfiguredAdmin()) throw new Error("Admin authorisation required");
  if(!uid) throw new Error("User ID is required.");
  if(uid===ADMIN_UID) throw new Error("The Admin account cannot be deleted from the app.");

  const confirmed=confirm("DELETE USER FROM APP\n\nThis will deregister the user from DATA X PRO and remove the active user profile and sessions. The Firebase Authentication login is intentionally kept because the free setup cannot delete another user's Auth account.\n\nThe user can register again with the SAME email and password plus a NEW activation key.\n\nA safety backup is created before deletion.\n\nContinue?");
  if(!confirmed) return false;

  await ensureAdminSession();
  const [profileSnap,sessionsSnap,supportSnap,withdrawalsSnap]=await Promise.all([
    get(ref(db,`users/${uid}`)),
    get(ref(db,`sellSessions/${uid}`)),
    get(ref(db,`support/${uid}`)).catch(()=>({exists:()=>false,val:()=>null})),
    get(ref(db,"withdrawals")).catch(()=>({exists:()=>false,val:()=>null}))
  ]);
  const profile=profileSnap.exists()?profileSnap.val():{};
  const sessions=sessionsSnap.exists()?sessionsSnap.val():{};
  const support=supportSnap?.exists?.()?supportSnap.val():null;
  const withdrawals=withdrawalsSnap?.exists?.()?withdrawalsSnap.val():{};
  const userWithdrawals=Object.fromEntries(Object.entries(withdrawals||{}).filter(([,w])=>String(w?.uid||w?.userId||w?.user?.uid||"")===String(uid)));

  const backupPayload={
    uid,
    email:profile.email||null,
    name:profile.name||null,
    mobile:profile.mobile||null,
    deletedAt:Date.now(),
    deletedBy:auth.currentUser?.uid||null,
    reason:"ADMIN_APP_DEREGISTRATION_V29",
    profile,
    sellSessions:sessions,
    support,
    withdrawals:userWithdrawals
  };
  await safetyBackup("USER_DEREGISTRATION",backupPayload);

  const deletionRecord={
    uid,
    email:profile.email||null,
    name:profile.name||null,
    mobile:profile.mobile||null,
    deletedAt:Date.now(),
    deletedBy:auth.currentUser?.uid||null,
    status:"DEREGISTERED",
    reRegisterRequired:true
  };

  // Keep Auth intact, but remove the active DATA X PRO profile/session layer.
  const updates={};
  updates[`deletedUsers/${uid}`]=deletionRecord;
  updates[`users/${uid}`]=null;
  updates[`sellSessions/${uid}`]=null;
  updates[`support/${uid}`]=null;
  await update(ref(db),updates);

  try{await audit("User deregistered from app",{uid,reRegisterRequired:true,authDeleted:false})}catch{}
  return true;
}

let adminUiOpening=false;
async function openAdminUi(){
  if(adminUiOpening)return;
  const u=auth.currentUser;
  if(!u || !isConfiguredAdmin()){window.toast("Admin account required","bad");return;}
  adminUiOpening=true;
  hide($("auth"));show($("logout"));hide($("dash"));
  const gate=document.createElement("div");gate.className="access-granted";gate.innerHTML='<div class="grant-icon">✓</div><div class="grant-kicker">SECURITY VERIFIED</div><h2>AUTHORISED GRANTED</h2><p>Admin identity verified successfully.</p>';document.body.appendChild(gate);
  setTimeout(()=>{gate.classList.add("leave");setTimeout(()=>{gate.remove();show($("dash"));loadDashboard();adminUiOpening=false},260)},420);
}
$("login").addEventListener("click",async()=>{
  const email=$("email").value.trim(),pass=$("pass").value,btn=$("login"),state=$("loginState");
  $("msg").className="msg"; $("msg").textContent="";
  if(!email||!pass){$("msg").className="msg error";$("msg").textContent="Enter admin email and password.";return}
  btn.disabled=true;btn.textContent="Authenticating…";state.textContent="● VERIFYING AUTHORISATION";
  try{
    const credential=await signInWithEmailAndPassword(auth,email,pass);
    if(String(credential.user.email||"").toLowerCase()!==ADMIN_EMAIL){await signOut(auth);throw Object.assign(new Error("Only authorised admin login is allowed."),{code:"auth/not-admin"})}
    state.textContent="● AUTHORISATION VERIFIED";
    await openAdminUi();
  }catch(e){$("msg").className="msg error";$("msg").textContent=e?.code==="auth/not-admin"?"Only authorised admin login is allowed.":authMessage(e);state.textContent="● ADMIN ACCESS DENIED"}
  finally{btn.disabled=false;btn.textContent="Secure Admin Login"}
});
$("pass").addEventListener("keydown",e=>{if(e.key==="Enter")$("login").click()});
$("logout").addEventListener("click",async()=>{try{await signOut(auth);$("msg").className="msg";$("msg").textContent=""}catch(e){window.toast("Logout failed. Try again.","bad")}});

onAuthStateChanged(auth,async u=>{
  if(isConfiguredAdmin()){
    $("loginState").textContent="● AUTHORISATION VERIFIED";
    openAdminUi();
  }else if(u){
    await signOut(auth).catch(()=>{});show($("auth"));hide($("dash"));hide($("logout"));$("msg").className="msg error";$("msg").textContent="Only authorised admin login is allowed.";$("loginState").textContent="● ADMIN ACCESS REQUIRED";
  }else{show($("auth"));hide($("dash"));hide($("logout"));$("loginState").textContent="● ADMIN-ONLY ACCESS"}
});

document.querySelectorAll("[data-p]").forEach(btn=>{
  btn.addEventListener("click",()=>openPage(btn.dataset.p,btn));
});

async function loadDashboard(){
  if(dashboardLiveTimer){clearTimeout(dashboardLiveTimer);dashboardLiveTimer=null;}
  const renderToken=++dashboardRenderToken;
  try{await ensureAdminSession();
    await syncPublicKeyCatalogs().catch(()=>{});
    const [u,w,a,settingsSnap]=await Promise.all([get(ref(db,"users")),get(ref(db,"withdrawals")),get(ref(db,"activationKeys")),get(ref(db,"settings"))]);
    if(renderToken!==dashboardRenderToken || activeSection) return;
    const userMap=u.val()||{};
    const users=Object.keys(userMap).length;
    const withdrawals=Object.values(w.val()||{});
    const keys=Object.values(a.val()||{});
    const settings=settingsSnap.val()||{};
    const totalDataSold=Object.values(userMap).reduce((sum,user)=>{
      const n=Number(user?.totalDataSold);
      return sum+(Number.isFinite(n)?n:0);
    },0);
    const totalPaidOut=withdrawals.filter(x=>['APPROVED','COMPLETED','PAID'].includes(String(x?.status||'').toUpperCase())).reduce((sum,item)=>{
      const n=Number(item?.amount);
      return sum+(Number.isFinite(n)?n:0);
    },0);
    const showTotalBalance=settings.showTotalBalance!==false;
    const showPendingWithdrawalBalance=settings.showPendingWithdrawalBalance!==false;
    const pendingRows=withdrawals.filter(x=>String(x.status||"PENDING").toUpperCase()==="PENDING");
    const pending=pendingRows.length;
    // Financial dashboard values are read-only aggregates of stored records.
    // Total Balance intentionally uses users/*/balance only, so pending withdrawal
    // amounts are never silently added a second time.
    const totalBalance=Object.values(userMap).reduce((sum,user)=>{
      const n=Number(user?.balance);
      return sum+(Number.isFinite(n)?n:0);
    },0);
    const pendingWithdrawalBalance=pendingRows.reduce((sum,item)=>{
      const n=Number(item?.amount);
      return sum+(Number.isFinite(n)?n:0);
    },0);
    const now=Date.now();
    const active=keys.filter(x=>{
      const status=String(x.status||"ACTIVE").toUpperCase();
      const exp=Number(x.expiresAt||0);
      return status==="ACTIVE" && (!exp || exp>now);
    }).length;
    const liveUsers=Object.values(u.val()||{}).filter(x=>x?.online===true || (x?.lastSeenAt && now-Number(x.lastSeenAt)<5*60*1000)).length;
    const expired=keys.filter(x=>String(x.status||"").toUpperCase()==="EXPIRED" || ((x.expiresAt||0)>0 && Number(x.expiresAt)<=now)).length;
    $("page").innerHTML=`<div class="section-head dashboard-head"><div><span class="eyebrow">PRIVATE ADMIN SPACE</span><h2>Control Center</h2><p class="muted">Secure controls for DATA X PRO. Sensitive identifiers are hidden from the dashboard.</p></div>
      <div class="dashboard-tools"><button class="secondary" id="refreshDashboard">↻ Refresh</button><div class="hero-orb">✦</div></div></div>
    <div class="admin-command-banner">
      <span class="admin-command-icon">♛</span>
      <div><small>PRIVATE CONTROL</small><strong>ADMIN-ONLY ACCESS</strong><em>Protected command environment · Sensitive identifiers hidden</em></div>
      <span class="admin-command-status"><i></i>SECURE</span>
    </div>
    <div class="live-control-grid premium-live-grid">
      <article class="live-control-card live-user-card"><span class="live-dot"></span><small>LIVE USERS</small><b id="liveUsersCount">${liveUsers}</b><em>online / recently active</em></article>
      <article class="live-control-card live-key-card"><span class="live-dot"></span><small>ACTIVE KEYS</small><b id="activeKeysCount">${active}</b><em>currently valid</em></article>
      <article class="live-control-card live-expired-card"><span class="live-dot"></span><small>EXPIRED KEYS</small><b id="expiredKeysCount">${expired}</b><em>past expiry</em></article>
      <article class="live-control-card live-withdrawal-card"><span class="live-dot"></span><small>PENDING WITHDRAWALS</small><b id="pendingWithdrawalsCount">${pending}</b><em>awaiting review</em></article>
      <article class="live-control-card live-total-card"><span class="live-dot"></span><small>TOTAL USERS</small><b id="totalUsersCount">${users}</b><em>registered accounts</em></article><article class="live-control-card live-total-card"><span class="live-dot"></span><small>TOTAL DATA SOLD</small><b id="totalDataSoldCount">${Math.round(totalDataSold)} MB</b><em>sum of users/*/totalDataSold</em></article><article class="live-control-card live-total-card"><span class="live-dot"></span><small>TOTAL PAID OUT</small><b id="totalPaidOutCount">${money(totalPaidOut)}</b><em>approved · completed · paid withdrawals</em></article>
      ${showTotalBalance?`<article class="live-control-card live-balance-card financial-control-card"><span class="live-dot"></span><div class="financial-label"><small>TOTAL BALANCE</small><span class="financial-lock">LIVE</span></div><b id="totalBalanceValue">${money(totalBalance)}</b><em>sum of all users' stored balance</em></article>`:""}
      ${showPendingWithdrawalBalance?`<article class="live-control-card live-pending-balance-card financial-control-card"><span class="live-dot"></span><div class="financial-label"><small>PENDING WITHDRAWAL BALANCE</small><span class="financial-lock">QUEUE</span></div><b id="pendingWithdrawalBalanceValue">${money(pendingWithdrawalBalance)}</b><em>sum of pending withdrawal amounts</em></article>`:""}
    </div>
    <div class="financial-integrity-strip"><span>◈</span><div><strong>FINANCIAL SNAPSHOT</strong><small>Read-only aggregation · source: users/{uid}/balance + pending withdrawal amounts</small></div><time>${esc(fmtDT(Date.now()))}</time></div>`;
    const rd=$("refreshDashboard"); if(rd) rd.onclick=()=>withRefresh(rd,loadDashboard);
    const refreshSeconds=Math.max(5,Math.min(120,Number(settings.controlCenterRefreshSeconds)||10));
    dashboardLiveTimer=setTimeout(()=>{if(!activeSection) loadDashboard();},refreshSeconds*1000);
  }catch(e){if(renderToken===dashboardRenderToken && !activeSection)$("page").innerHTML=`<div class="notice error">Dashboard error: ${esc(e.message)}</div>`}
}

let sectionTransitionTimer=0;
let sectionOriginEl=null;
let sectionOriginRect=null;
let sectionMotionToken=0;
let dashboardRenderToken=0;
let activeSection=false;
let keyCountdownTimer=null;
let dashboardLiveTimer=null;

function rectNow(el){
  if(!el || !el.isConnected) return null;
  const r=el.getBoundingClientRect();
  if(!r.width || !r.height) return null;
  return {left:r.left,top:r.top,width:r.width,height:r.height};
}
function makeTransitionCard(el){
  // Blank shared-element shell: never clone the source text/content.
  // Cloning content and then non-uniformly scaling it is what creates the
  // "merged/warped" look on mobile. The shell is only a visual surface.
  const card=document.createElement("div");
  card.className="section-motion-card";
  card.setAttribute("aria-hidden","true");
  return card;
}
function placeMotionCard(card,r){
  card.style.left=r.left+"px";
  card.style.top=r.top+"px";
  card.style.width=r.width+"px";
  card.style.height=r.height+"px";
}
function animateMotionCard(card,from,to,duration,reverse=false){
  const dx=from.left-to.left, dy=from.top-to.top;
  const sx=from.width/to.width, sy=from.height/to.height;
  return card.animate([
    {transform:`translate3d(${dx}px,${dy}px,0) scale(${sx},${sy})`,opacity:reverse?1:.98},
    {transform:"translate3d(0,0,0) scale(1,1)",opacity:1}
  ],{duration,easing:"cubic-bezier(.22,1,.36,1)",fill:"forwards"}).finished;
}
function getPageTargetRect(){
  const mobile=window.matchMedia?.("(max-width:650px)")?.matches;
  const left=window.innerWidth*(mobile?.025:.03);
  const right=window.innerWidth*(mobile?.025:.03);
  const top=mobile?74:96;
  const bottom=mobile?10:18;
  return {left,top,width:Math.max(1,window.innerWidth-left-right),height:Math.max(1,window.innerHeight-top-bottom)};
}
function cleanupMotionCard(card){
  try{card?.getAnimations().forEach(a=>a.cancel())}catch{}
  card?.remove();
}
function nextFrame(){return new Promise(r=>requestAnimationFrame(()=>r()));}

async function enterFullSection(source){
  const dash=$("dash"), page=$("page");
  if(!dash || !page)return;
  clearTimeout(sectionTransitionTimer);
  sectionMotionToken++;
  const token=sectionMotionToken;
  sectionOriginEl=source||null;
  sectionOriginRect=rectNow(sectionOriginEl);

  // Freeze the old dashboard BEFORE changing #page. This prevents the
  // dashboard's Control Center text from ever being painted underneath the
  // transition shell.
  dash.classList.add("section-open","section-nav-lock");
  page.classList.add("section-prep");
  void page.offsetWidth;
  const target=getPageTargetRect();
  const shell=sectionOriginRect?makeTransitionCard(source):null;
  if(shell){
    document.body.appendChild(shell);
    placeMotionCard(shell,sectionOriginRect);
  }

  // Let the browser paint the starting frame before doing any animation.
  await nextFrame();
  if(token!==sectionMotionToken){cleanupMotionCard(shell);return}

  if(shell&&target){
    try{await animateMotionCard(shell,sectionOriginRect,target,260)}catch{}
  }
  if(token!==sectionMotionToken){cleanupMotionCard(shell);return}

  page.classList.remove("section-prep");
  page.classList.add("section-enter-content");
  sectionTransitionTimer=setTimeout(()=>page.classList.remove("section-enter-content"),340);
  cleanupMotionCard(shell);
  window.scrollTo({top:0,left:0,behavior:"auto"});
}

async function exitFullSection(){
  const dash=$("dash"), page=$("page");
  if(!dash || !page)return;
  clearTimeout(sectionTransitionTimer);
  sectionMotionToken++;
  const token=sectionMotionToken;
  const sourceRect=sectionOriginRect;
  const from=getPageTargetRect();

  page.classList.remove("section-enter-content");
  page.classList.add("section-closing");
  await nextFrame();
  if(token!==sectionMotionToken)return false;

  const shell=sourceRect?makeTransitionCard(sectionOriginEl):null;
  if(shell&&from){
    document.body.appendChild(shell);
    placeMotionCard(shell,sourceRect);
    try{
      const dx=from.left-sourceRect.left,dy=from.top-sourceRect.top;
      const sx=from.width/sourceRect.width,sy=from.height/sourceRect.height;
      await shell.animate([
        {transform:`translate3d(${dx}px,${dy}px,0) scale(${sx},${sy})`,opacity:1},
        {transform:"translate3d(0,0,0) scale(1,1)",opacity:1}
      ],{duration:240,easing:"cubic-bezier(.7,0,.84,1)",fill:"forwards"}).finished;
    }catch{}
    cleanupMotionCard(shell);
  }
  if(token!==sectionMotionToken)return false;

  dash.classList.remove("section-open","section-nav-lock");
  page.classList.remove("section-closing","section-leave","section-prep");
  sectionOriginEl=null;
  sectionOriginRect=null;
  activeSection=false;
  return true;
}
function addSectionBackButton(){
  const page=$("page");
  if(!page || page.querySelector("[data-back-dashboard],.section-back"))return;
  const head=page.querySelector(".section-head");
  if(!head)return;
  const b=document.createElement("button");
  b.type="button";b.className="secondary section-back";b.dataset.backDashboard="1";
  b.innerHTML="<span>←</span> Dashboard";
  b.addEventListener("click",async()=>{if(b.dataset.busy==="1")return;b.dataset.busy="1";activeSection=false;dashboardRenderToken++;await exitFullSection();await loadDashboard()});
  head.insertBefore(b,head.firstChild);
}
async function openPage(p,source){
  const el=$("page");
  try{
    if(p==="dashboard"){activeSection=false;dashboardRenderToken++;await exitFullSection();return loadDashboard();}
    activeSection=true;
    dashboardRenderToken++;
    await enterFullSection(source);
    let r=null;
    if(p==="users")r=openUsers(el);
    else if(p==="keys")r=openKeys(el);
    else if(p==="topsellers")r=openTopSellers(el);
    else if(p==="withdrawals")r=openWithdrawals(el);
    else if(p==="support")r=openSupport(el);
    else if(p==="notifications")r=openNotifications(el);
    else if(p==="settings")r=openSettings(el);
    else if(p==="audit")r=openAudit(el);
    else if(p==="security")r=openSecurity(el);
    else return loadDashboard();
    if(r && typeof r.then==="function")await r;
    setTimeout(addSectionBackButton,0);
    return true;
  }catch(e){
    console.error("Section failed:",e);
    activeSection=true;
    if(el){
      el.innerHTML=`<div class="notice error"><strong>${esc(p.toUpperCase())} could not open.</strong><div>${esc(e?.message||"Unknown error")}</div><button class="secondary section-back" id="sectionRecoverBack">← Dashboard</button></div>`;
      $("sectionRecoverBack")?.addEventListener("click",()=>openPage("dashboard"));
    }
    window.toast("Section recovered from an error","bad");
    return false;
  }
}

function openUsers(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">USER CONTROL</span><h2>Users</h2><p class="muted">Edit, level-control, block/unblock and remove user profiles.</p></div><button class="secondary" id="refreshUsers">↻ Refresh</button></div>
  <div class="glassbar"><input id="userSearch" placeholder="Search by name, masked email or mobile ending"></div><div id="usersList">Loading…</div>`;
  $("refreshUsers").onclick=()=>withRefresh($("refreshUsers"),loadUsers);
  $("userSearch").oninput=()=>renderUsers(window.__users||{});
  loadUsers();
}
async function loadUsers(){await ensureAdminSession();
  try{const s=await get(ref(db,"users"));window.__users=s.val()||{};renderUsers(window.__users)}
  catch(e){$("usersList").innerHTML=`<div class="notice error">${esc(e.message)}</div>`}
}
function renderUsers(data){
  const q=($("userSearch")?.value||"").toLowerCase();
  const entries=Object.entries(data).filter(([uid,u])=>{
    const hay=[u.name,maskEmail(u.email),maskMobile(u.mobile),String(u.level??0),u.status].join(" ").toLowerCase();
    return !q||hay.includes(q);
  });
  $("usersList").innerHTML=entries.length?entries.map(([uid,u])=>{
    const status=String(u.status||"ACTIVE"),level=Number(u.level||0);
    return `<article class="user-card">
      <div class="user-main">
        <div class="avatar">${esc((u.name||"U").slice(0,1).toUpperCase())}</div>
        <div><b>${esc(u.name||"Unnamed")}</b><div class="muted">${esc(maskEmail(u.email))} · ${esc(maskMobile(u.mobile))}</div></div>
        <div class="user-level">LEVEL ${level}</div><div class="user-status ${status==="BLOCKED"?"blocked":""}">${esc(status)}</div>
      </div>
      <div class="user-actions">
        <button data-act="edit" data-uid="${esc(uid)}">✎ Edit</button>
        <button data-act="level" data-uid="${esc(uid)}">◆ Level</button>
        <button data-act="${status==="BLOCKED"?"unblock":"block"}" data-uid="${esc(uid)}">${status==="BLOCKED"?"✓ Unblock":"⛔ Block"}</button>
        <button class="danger" data-act="delete" data-uid="${esc(uid)}">⌫ Delete</button>
      </div>
    </article>`;
  }).join(""):`<div class="notice">No users found.</div>`;
  $("usersList").querySelectorAll("[data-act]").forEach(b=>b.onclick=()=>userAction(b.dataset.act,b.dataset.uid));
}
async function userAction(action,uid){
  const u=window.__users?.[uid]; if(!u)return;
  try{
    if(action==="edit")return openUserEditor(uid);
    if(action==="level") return openLevelEditor(uid);
    if(action==="block"||action==="unblock"){
      const status=action==="block"?"BLOCKED":"ACTIVE";
      await update(ref(db,`users/${uid}`),{status,blockedAt:status==="BLOCKED"?Date.now():null,updatedAt:Date.now()});
      await audit(status==="BLOCKED"?"Blocked user":"Unblocked user",{uid});window.toast(status==="BLOCKED"?"User blocked":"User unblocked");return loadUsers();
    }
    if(action==="delete"){
      const done=await deregisterUser(uid);
      if(done){window.toast("User deregistered. Same email + password + new activation key required.");return loadUsers();}
      return;
    }
  }catch(e){window.toast("Action failed: "+e.message,"bad")}
}
async function openLevelEditor(uid){
  const u=window.__users?.[uid]; if(!u)return;
  const modal=document.createElement("div");modal.className="modal-backdrop";
  const allowedLevels=[[0,'Bronze'],[2,'Gold'],[3,'Platinum'],[5,'Master']];
  modal.innerHTML=`<div class="editor-modal level-modal"><div class="section-head"><div><span class="eyebrow">LEVEL CONTROL</span><h2>Set User Level</h2><p class="muted">Only active levels are available: Bronze, Gold, Platinum and Master.</p></div><button class="secondary" data-close>×</button></div><div class="level-picker">${allowedLevels.map(([n,label])=>`<button class="level-option ${Number(u.level||0)===n?'selected':''}" data-level="${n}"><span>LEVEL ${n}</span><small>${label}</small></button>`).join('')}</div><div class="editor-footer"><button class="secondary" data-close>Cancel</button><button data-save>Save Level</button></div></div>`;
  document.body.appendChild(modal);
  modal.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>modal.remove());
  let selected=Number(u.level||0);
  modal.querySelectorAll('[data-level]').forEach(b=>b.onclick=()=>{selected=Number(b.dataset.level);modal.querySelectorAll('[data-level]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')});
  modal.querySelector('[data-save]').onclick=async()=>{try{await update(ref(db,`users/${uid}`),{level:selected,updatedAt:Date.now()});await audit('Set exact user level',{uid,level:selected});modal.remove();window.toast('Level saved');await loadUsers()}catch(e){window.toast('Level save failed: '+e.message,'bad')}};
}

async function addUserBalance(uid, rawAmount, source="Admin balance top-up"){
  await ensureAdminSession();
  const amount=Number(rawAmount);
  if(!Number.isFinite(amount)||amount<=0)throw new Error("Enter a positive balance amount.");
  if(amount>100000000)throw new Error("Balance amount is too large.");
  const tx=await runTransaction(ref(db,`users/${uid}/balance`),current=>{
    const n=Number(current||0);
    if(!Number.isFinite(n))return Math.round(amount*100)/100;
    return Math.round((n+amount)*100)/100;
  });
  if(!tx.committed)throw new Error("Balance update was not committed.");
  const newBalance=Number(tx.snapshot.val()||0);
  await audit("Added user balance",{uid,amount,newBalance,source});
  return newBalance;
}

async function decreaseUserBalance(uid, rawAmount, source="Admin balance reduction"){
  await ensureAdminSession();
  const amount=Number(rawAmount);
  if(!Number.isFinite(amount)||amount<=0)throw new Error("Enter a positive reduction amount.");
  if(amount>100000000)throw new Error("Balance amount is too large.");
  const tx=await runTransaction(ref(db,`users/${uid}/balance`),current=>{
    const n=Number(current||0);
    if(!Number.isFinite(n))return Math.round((-amount)*100)/100;
    // Intentionally allow the balance to become negative; Admin requested
    // a manual debit control without clamping at zero.
    return Math.round((n-amount)*100)/100;
  });
  if(!tx.committed)throw new Error("Balance update was not committed.");
  const newBalance=Number(tx.snapshot.val()||0);
  await audit("Reduced user balance",{uid,amount,newBalance,source,canBecomeNegative:true});
  return newBalance;
}

async function openUserEditor(uid){
  const s=await get(ref(db,`users/${uid}`));if(!s.exists())return window.toast("User not found","bad");
  const u=s.val()||{};
  const currentBalance=Number(u.balance||0);
  const modal=document.createElement("div");modal.className="modal-backdrop";
  modal.innerHTML=`<div class="editor-modal">
    <div class="section-head"><div><span class="eyebrow">PRIVATE PROFILE</span><h2>Edit User</h2><p class="muted">Profile fields and a dedicated live balance top-up.</p></div><button class="secondary" data-close>×</button></div>
    <div class="editor-grid">
      <label>Name<input id="eName" value="${esc(u.name||"")}"></label>
      <label>Mobile<input id="eMobile" value="${esc(u.mobile||"")}"></label>
      <label>Email<input id="eEmail" value="${esc(u.email||"")}"></label>
      <label>Exact Level<select id="eLevel">${[[0,'Bronze'],[2,'Gold'],[3,'Platinum'],[5,'Master']].map(([n,label])=>`<option value="${n}" ${Number(u.level||0)===n?"selected":""}>Level ${n} · ${label}</option>`).join("")}</select></label>
      <label>Status<select id="eStatus"><option ${u.status!=="BLOCKED"?"selected":""}>ACTIVE</option><option ${u.status==="BLOCKED"?"selected":""}>BLOCKED</option></select></label>
    </div>
    <div class="balance-control-card">
      <div class="balance-control-head"><div><span class="eyebrow">LIVE WALLET CONTROL</span><strong>Current Balance</strong><small id="eBalanceCurrent">₹${currentBalance.toFixed(2)}</small></div><span class="balance-live-badge">LIVE</span></div>
      <div class="balance-control-row balance-add-row"><label>Add Balance<input id="eAddBalance" type="number" inputmode="decimal" min="0.01" step="0.01" placeholder="e.g. 299"></label><button type="button" id="addBalanceBtn">＋ Add Balance</button></div>
      <div class="balance-control-row balance-reduce-row"><label>Decrease Balance<input id="eReduceBalance" type="number" inputmode="decimal" min="0.01" step="0.01" placeholder="e.g. 100"></label><button type="button" class="danger" id="reduceBalanceBtn">− Decrease Balance</button></div>
      <small class="field-help">Both controls update the existing balance atomically. Decrease Balance is allowed to move the account below ₹0 when required.</small>
    </div>
    <div class="notice">Profile changes and balance top-ups are audited separately. Delete User from App removes the active DATA X PRO profile and sessions; the Firebase Authentication login remains available for re-registration with a new activation key.</div>
    <div class="editor-footer"><button class="danger" data-delete>Delete User from App</button><button data-save>Save changes</button></div>
  </div>`;
  document.body.appendChild(modal);
  modal.querySelector("[data-close]").onclick=()=>modal.remove();
  modal.querySelector("[data-delete]").onclick=async()=>{modal.remove();await userAction("delete",uid)};
  modal.querySelector("[data-save]").onclick=async()=>{
    const btn=modal.querySelector("[data-save]");
    setActionBusy(btn,true,"Saving");
    try{
      await update(ref(db,`users/${uid}`),{
        name:$('eName').value.trim(),mobile:$('eMobile').value.trim(),email:$('eEmail').value.trim(),
        level:Number($('eLevel').value),status:$('eStatus').value,updatedAt:Date.now()
      });
      await audit("Edited user profile",{uid});
      window.toast("Profile changes saved");
      await loadUsers();
      const fresh=await get(ref(db,`users/${uid}`));
      const n=Number(fresh.val()?.balance||0);
      const bal=modal.querySelector('#eBalanceCurrent');
      if(bal)bal.textContent=`₹${n.toFixed(2)}`;
    }catch(e){window.toast("Save failed: "+(e.message||e),"bad")}
    finally{setActionBusy(btn,false)}
  };
  modal.querySelector('#addBalanceBtn').onclick=async()=>{
    const btn=modal.querySelector('#addBalanceBtn');
    const input=modal.querySelector('#eAddBalance');
    setActionBusy(btn,true,"Adding");
    try{
      const amount=Number(input?.value);
      const newBalance=await addUserBalance(uid,amount);
      const bal=modal.querySelector('#eBalanceCurrent');
      if(bal)bal.textContent=`₹${newBalance.toFixed(2)}`;
      if(input)input.value='';
      window.__users=window.__users||{};
      if(window.__users[uid])window.__users[uid].balance=newBalance;
      await loadUsers();
      window.toast(`Balance added · new balance ₹${newBalance.toFixed(2)}`);
    }catch(e){window.toast("Balance add failed: "+(e.message||e),"bad")}
    finally{setActionBusy(btn,false)}
  };
  modal.querySelector('#reduceBalanceBtn').onclick=async()=>{
    const btn=modal.querySelector('#reduceBalanceBtn');
    const input=modal.querySelector('#eReduceBalance');
    setActionBusy(btn,true,"Reducing");
    try{
      const amount=Number(input?.value);
      const newBalance=await decreaseUserBalance(uid,amount);
      const bal=modal.querySelector('#eBalanceCurrent');
      if(bal)bal.textContent=`₹${newBalance.toFixed(2)}`;
      if(input)input.value='';
      window.__users=window.__users||{};
      if(window.__users[uid])window.__users[uid].balance=newBalance;
      await loadUsers();
      window.toast(`Balance reduced · new balance ₹${newBalance.toFixed(2)}`);
    }catch(e){window.toast("Balance reduction failed: "+(e.message||e),"bad")}
    finally{setActionBusy(btn,false)}
  };
}

function openKeys(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">SECURE KEY CENTER</span><h2>Key Command</h2><p class="muted">Premium credential center · Gold ₹100 · Platinum ₹149 · Master ₹199 · exact expiry and one-time lifecycle.</p></div><div class="toolbar"><button class="secondary" id="syncKeyCatalog">⇄ Sync Key Catalog</button><button class="secondary" id="refreshKeys">↻ Refresh</button><button class="secondary" id="cleanKeys">🧹 Clean expired</button></div></div>
  <div class="god-eyes card"><div><span class="eyebrow">GOD EYES · LIVE KEY WATCH</span><h3>Key Command Vision</h3><p class="muted">Live expiry telemetry updates every second from the stored expiry timestamp.</p></div><div class="eyes-stats"><div><small>ACTIVE</small><b id="eyesActive">—</b></div><div><small>EXPIRING &lt; 1H</small><b id="eyesSoon">—</b></div><div><small>EXPIRED</small><b id="eyesExpired">—</b></div><div><small>NEXT EXPIRY</small><b id="eyesNext">—</b></div></div></div><div class="key-grid">${[["ACTIVATION","🔥","Activation","ADX-"],["WITHDRAWAL","💳","Withdrawal","A_WD_"],["GOLD","🥇","Gold · ₹100","GOLD_"],["PLATINUM","💎","Platinum · ₹149","PLATINUM_"],["MASTER","👑","Master · ₹199","MASTER_"]].map(x=>`<button class="keytype" data-keytype="${x[0]}"><span class="icon">${x[1]}</span><b>${x[2]}</b><small>${x[3]}…</small></button>`).join("")}</div>
  <div id="keyGenerator"></div>
  <div class="glassbar"><input id="keySearch" placeholder="Search key, username, number or status"><select id="keyFilter"><option>ALL</option><option>ACTIVE</option><option>USED</option><option>EXPIRED</option><option>REVOKED</option></select></div>
  <div class="key-head card"><span>Key</span><span>Created</span><span>Expiry</span><span>Status</span><span>Number</span><span>Username</span><span>Action</span></div><div id="keysList">Loading…</div>`;
  document.querySelectorAll("[data-keytype]").forEach(b=>b.onclick=()=>openKeyGenerator(b.dataset.keytype));
  $("refreshKeys").onclick=()=>withRefresh($("refreshKeys"),loadKeys);$("cleanKeys").onclick=cleanExpiredKeys;$('syncKeyCatalog').onclick=async()=>{const b=$('syncKeyCatalog');setActionBusy(b,true,"Syncing");try{await syncPublicKeyCatalogs();await audit("Synced public key catalog");window.toast("Key catalog synchronized");await loadKeys();}catch(e){window.toast("Key sync failed: "+(e?.message||e),"bad")}finally{setActionBusy(b,false)}};$('keySearch').oninput=loadKeys;$('keyFilter').onchange=loadKeys;loadKeys();
}
async function getKeyPolicy(){const s=await get(ref(db,"settings"));return s.val()||{keyLifetimeValue:24,keyLifetimeUnit:"hours"}}
function openKeyGenerator(type){
  const names={ACTIVATION:"Activation",WITHDRAWAL:"Withdrawal",GOLD:"Gold · ₹100",PLATINUM:"Platinum · ₹149",MASTER:"Master · ₹199"};
  $("keyGenerator").innerHTML=`<div class="card generator"><div class="section-head"><div><span class="eyebrow">ISSUE CREDENTIAL</span><h3>${names[type]} Key</h3><p id="keyPolicyText" class="muted">Loading policy…</p></div></div><div class="toolbar"><label class="qty-label">Quantity<input id="keyQty" type="number" min="1" max="100" value="1"></label><button id="generateKey">Generate Secure Key</button></div><div id="generated"></div></div>`;
  getKeyPolicy().then(v=>$("keyPolicyText").textContent=`Validity: ${keyLifetimeLabel(v)} from the exact creation time · one-time binding`);$("generateKey").onclick=()=>generateKeys(type);
}
async function generateKeys(type){
  const policy=await getKeyPolicy();
  const prefix={ACTIVATION:"ADX-",WITHDRAWAL:"A_WD_",GOLD:"GOLD_",PLATINUM:"PLATINUM_",MASTER:"MASTER_"}[type];
  if(!["ACTIVATION","WITHDRAWAL","GOLD","PLATINUM","MASTER"].includes(type)){window.toast("Unsupported key type","bad");return;}
  const path=type==="ACTIVATION"?"activationKeys":"levelKeys";
  const qty=Math.max(1,Math.min(100,Number($("keyQty").value)||1)),out=[];
  const levelMap={GOLD:2,PLATINUM:3,MASTER:5};
  try{
    await ensureAdminSession();
    const life=keyLifetime(policy);
    const now=Date.now();
    const baseBatch={}, publicBatch={};
    for(let i=0;i<qty;i++){
      const key=prefix+random(9),createdAt=now+i,expiresAt=createdAt+life;
      const record={key,type,status:"ACTIVE",createdAt,expiresAt,expiresIn:keyLifetimeLabel(policy),boundDeviceId:null,usedBy:null,usedAt:null,usedNumber:null,username:null,number:null};
      baseBatch[`${path}/${key}`]=record;
      if(type==="ACTIVATION") publicBatch[`publicActivationKeys/${key}`]={key,type,status:"ACTIVE",createdAt,expiresAt};
      else publicBatch[`publicLevelKeys/${key}`]={key,type,status:"ACTIVE",level:levelMap[type],createdAt,expiresAt};
      out.push({key,createdAt,expiresAt});
    }

    // Always persist the authoritative key first. This keeps key issuance
    // functional even when the live database still has legacy rules that do
    // not know about the public catalog paths.
    await update(ref(db),baseBatch);

    // V1 public catalog is best-effort. With the V1 rules this succeeds
    // and the User app can use the public catalog. On legacy rules this may be
    // denied, but the generated key remains usable through the compatibility
    // path in the User app.
    let publicSynced=true;
    try{await update(ref(db),publicBatch);}catch(_){publicSynced=false;}

    $("generated").innerHTML=`<div class="notice success key-issued">✓ ${qty} key${qty===1?"":"s"} generated${publicSynced?", catalogued":""} and ready for the User app.</div>`;
    await audit("Generated keys",{type,quantity:qty,lifetimeMs:life,publicCatalog:publicSynced,compatibilityMode:!publicSynced});
    await loadKeys();
  }catch(e){
    const code=String(e?.code||"").toUpperCase();
    const detail=code==="PERMISSION_DENIED"
      ? "Firebase denied the authoritative key write. Sign in with the configured Admin account and check the Admin Firebase Rules."
      : (e?.message||"Key generation failed.");
    $("generated").innerHTML=`<div class="notice error">${esc(detail)}</div>`;
  }
}

function updateKeyCountdowns(){
  const now=Date.now();
  let active=0,soon=0,expired=0,next=Infinity;
  document.querySelectorAll(".time-left[data-expiry]").forEach(el=>{
    const status=String(el.dataset.status||"ACTIVE").toUpperCase();
    if(status==="USED"){el.textContent="REDEEMED";el.classList.remove("expired");return}
    if(status==="REVOKED"){el.textContent="REVOKED";el.classList.add("expired");return}
    const exp=Number(el.dataset.expiry||0), left=exp-now;
    if(left<=0){expired++;el.textContent="EXPIRED";el.classList.add("expired");return;}
    active++; if(left<=3600000)soon++; if(exp<next)next=exp;
    const total=Math.floor(left/1000),d=Math.floor(total/86400),h=Math.floor(total%86400/3600),m=Math.floor(total%3600/60),s=total%60;
    el.textContent=(d?d+"d ":"")+String(h).padStart(2,"0")+"h "+String(m).padStart(2,"0")+"m "+String(s).padStart(2,"0")+"s";
    el.classList.remove("expired");
  });
  if($("eyesActive")) $("eyesActive").textContent=active;
  if($("eyesSoon")) $("eyesSoon").textContent=soon;
  if($("eyesExpired")) $("eyesExpired").textContent=expired;
  if($("eyesNext")) $("eyesNext").textContent=next===Infinity?"—":(next-now<=3600000?Math.max(0,Math.floor((next-now)/1000))+"s":"in "+fmtDT(next));
}
function startKeyCountdown(){clearInterval(keyCountdownTimer);updateKeyCountdowns();keyCountdownTimer=setInterval(updateKeyCountdowns,1000);}

async function reconcileUsedKeyRecords(activation,level,users,activationClaims,levelClaims){
  const updates={};
  const changed=[];
  const makeUsage=(claim,source,user)=>{
    const usedAt=Number(claim?.usedAt||claim?.redeemedAt||claim?.createdAt||source?.usedAt||Date.now());
    const usedBy=String(claim?.uid||source?.usedBy||"");
    const username=String(claim?.username||claim?.name||user?.name||user?.username||source?.username||"").trim();
    const number=String(claim?.number||claim?.mobile||user?.mobile||user?.number||source?.number||source?.usedNumber||"").trim();
    return {status:"USED",usedBy:usedBy||null,usedAt:usedAt||null,redeemedAt:usedAt||null,username:username||null,number:number||null,usedNumber:number||null};
  };
  const inspect=(path,key,source,claim,user,isPublic)=>{
    if(!claim)return;
    const usage=makeUsage(claim,source,user);
    if(!isPublic){
      const needs=String(source?.status||"").toUpperCase()!=="USED" || String(source?.usedBy||"")!==String(usage.usedBy||"") || String(source?.username||"")!==String(usage.username||"") || String(source?.number||source?.usedNumber||"")!==String(usage.number||"");
      if(needs){
        const patch={...usage};
        Object.keys(patch).forEach(k=>updates[`${path}/${key}/${k}`]=patch[k]);
        changed.push({path,key,before:source||{},after:{...(source||{}),...patch}});
      }
    }
  };
  for(const [key,v] of Object.entries(activation||{})) inspect("activationKeys",key,v,activationClaims?.[key],users?.[activationClaims?.[key]?.uid]||{},false);
  for(const [key,v] of Object.entries(level||{})) inspect("levelKeys",key,v,levelClaims?.[key],users?.[levelClaims?.[key]?.uid]||{},false);
  // Public mirrors intentionally receive only non-sensitive usage state.
  for(const [key,claim] of Object.entries(activationClaims||{})){
    if(activation?.[key]){updates[`publicActivationKeys/${key}/status`]='USED';updates[`publicActivationKeys/${key}/usedAt`]=Number(claim?.usedAt||claim?.redeemedAt||claim?.createdAt||Date.now());}
  }
  for(const [key,claim] of Object.entries(levelClaims||{})){
    if(level?.[key]){updates[`publicLevelKeys/${key}/status`]='USED';updates[`publicLevelKeys/${key}/usedAt`]=Number(claim?.usedAt||claim?.redeemedAt||claim?.createdAt||Date.now());}
  }
  if(Object.keys(updates).length){
    if(changed.length) await safetyBackup('key-usage-reconcile',{items:changed,at:Date.now()});
    await update(ref(db),updates);
  }
  return {changed:changed.length,updates:Object.keys(updates).length};
}

async function syncPublicKeyCatalogs(){
  await ensureAdminSession();
  // Read each source independently so legacy databases without one of the
  // newer redemption trees do not break the entire Admin Keys page.
  const safeGet=async(path)=>{try{return (await get(ref(db,path))).val()||{};}catch(_){return {} }};
  const [activation,level,activationClaims,levelClaims]=await Promise.all([
    safeGet("activationKeys"),safeGet("levelKeys"),safeGet("activationRedemptions"),safeGet("levelRedemptions")
  ]);
  const batch={};
  const levelMap={GOLD:2,PLATINUM:3,MASTER:5};
  for(const [key,v] of Object.entries(activation)){
    const claim=activationClaims[key];
    const baseStatus=String(v?.status||"ACTIVE").toUpperCase();
    const status=claim?"USED":baseStatus;
    batch[`publicActivationKeys/${key}`]={key,type:"ACTIVATION",status,createdAt:Number(v.createdAt||Date.now()),...(Number(v.expiresAt||0)>0?{expiresAt:Number(v.expiresAt)}:{})};
  }
  for(const [key,v] of Object.entries(level)){
    const claim=levelClaims[key];
    const baseStatus=String(v?.status||"ACTIVE").toUpperCase();
    const status=claim?"USED":baseStatus;
    const type=String(v?.type||"").toUpperCase();
    const levelNo=Number(v?.level||levelMap[type]||0);
    batch[`publicLevelKeys/${key}`]={key,type,status,level:levelNo,createdAt:Number(v.createdAt||Date.now()),...(Number(v.expiresAt||0)>0?{expiresAt:Number(v.expiresAt)}:{})};
  }
  if(Object.keys(batch).length){try{await update(ref(db),batch);}catch(_){/* legacy rules: public catalog unavailable; continue */}}
}

async function loadKeys(){await ensureAdminSession();
  try{
    const [a,l,u,ar,lr]=await Promise.all([
      get(ref(db,"activationKeys")),get(ref(db,"levelKeys")),get(ref(db,"users")),
      get(ref(db,"activationRedemptions")),get(ref(db,"levelRedemptions"))
    ]);
    const activation=JSON.parse(JSON.stringify(a.val()||{}));
    const level=JSON.parse(JSON.stringify(l.val()||{}));
    const users=u.val()||{},activationClaims=ar.val()||{},levelClaims=lr.val()||{};
    // Reconcile claimed keys into the authoritative Admin key store. This is the
    // bridge between the User redemption tree and the Admin Key Center.
    try{await reconcileUsedKeyRecords(activation,level,users,activationClaims,levelClaims);}catch(e){console.warn("Usage reconciliation failed",e)}
    // Apply the same derived state locally so the Admin card updates immediately,
    // without waiting for another network fetch.
    for(const [key,claim] of Object.entries(activationClaims)){
      if(activation[key]){
        const usr=users[claim?.uid]||{}; const usedAt=Number(claim?.usedAt||claim?.redeemedAt||claim?.createdAt||activation[key].usedAt||Date.now());
        activation[key]={...activation[key],status:"USED",usedBy:claim?.uid||activation[key].usedBy||null,usedAt,redeemedAt:usedAt,username:claim?.username||claim?.name||usr.name||usr.username||activation[key].username||null,number:claim?.number||claim?.mobile||usr.mobile||usr.number||activation[key].number||activation[key].usedNumber||null,usedNumber:claim?.number||claim?.mobile||usr.mobile||usr.number||activation[key].usedNumber||activation[key].number||null};
      }
    }
    for(const [key,claim] of Object.entries(levelClaims)){
      if(level[key]){
        const usr=users[claim?.uid]||{}; const usedAt=Number(claim?.usedAt||claim?.redeemedAt||claim?.createdAt||level[key].usedAt||Date.now());
        level[key]={...level[key],status:"USED",usedBy:claim?.uid||level[key].usedBy||null,usedAt,redeemedAt:usedAt,username:claim?.username||claim?.name||usr.name||usr.username||level[key].username||null,number:claim?.number||claim?.mobile||usr.mobile||usr.number||level[key].number||level[key].usedNumber||null,usedNumber:claim?.number||claim?.mobile||usr.mobile||usr.number||level[key].usedNumber||level[key].number||null};
      }
    }
    syncPublicKeyCatalogs().catch(()=>{});
    const rows=[];
    for(const [id,v] of Object.entries(activation))rows.push({id,path:"activationKeys",...v});
    for(const [id,v] of Object.entries(level))rows.push({id,path:"levelKeys",...v});
    window.__keyRecords={};rows.forEach(k=>window.__keyRecords[`${k.path}|${k.id}`]=k);
    const now=Date.now(),q=($("keySearch")?.value||"").toLowerCase(),f=$("keyFilter")?.value||"ALL";
    rows.forEach(k=>{
      const exp=Number(k.expiresAt||0),baseStatus=String(k.status||"ACTIVE").toUpperCase();
      k._status=baseStatus==="USED"?"USED":(baseStatus==="REVOKED"?"REVOKED":(baseStatus==="ACTIVE"&&exp>0&&exp<=now?"EXPIRED":baseStatus));
      const usr=users[k.usedBy]||{};
      k._username=k.username||k.username===null?String(k.username||"—"):String(usr.username||usr.name||"—");
      if(k._username==="—" && usr.name) k._username=usr.name;
      k._number=k.number||k.usedNumber||usr.mobile||usr.number||"—";
      k._usedAt=Number(k.usedAt||k.redeemedAt||0);
    });
    const filtered=rows.filter(k=>(f==="ALL"||k._status===f)&&(!q||[k.key,k._status,k._username,k._number].some(v=>String(v||"").toLowerCase().includes(q)))).sort((a,b)=>Number(b.createdAt||0)-Number(a.createdAt||0));
    $("keysList").innerHTML=filtered.slice(0,300).map(k=>`<article class="card key-row key-table"><div><code>${esc(k.key)}</code><small>${esc(k.type||"")}</small></div><div>${esc(fmtDT(k.createdAt))}</div><div><span>${esc(fmtDT(k.expiresAt))}</span><small class="time-left" data-status="${esc(k._status)}" data-expiry="${Number(k.expiresAt||0)}">${k._status==="ACTIVE"?"calculating…":k._status==="USED"?`REDEEMED${k._usedAt?" · "+esc(fmtDT(k._usedAt)):""}`:k._status}</small></div><div><span class="status-pill ${String(k._status).toLowerCase()}">${esc(k._status)}</span></div><div>${esc(k._number)}</div><div>${esc(k._username)}</div><div class="toolbar"><button data-copy="${esc(k.key)}">Copy</button>${k._status==="ACTIVE"?`<button class="secondary" data-revoke="${esc(k.path)}|${esc(k.id)}">Revoke</button>`:""}<button class="danger" data-delete="${esc(k.path)}|${esc(k.id)}">Delete</button></div></article>`).join("")||`<div class="notice">No matching keys.</div>`;
    startKeyCountdown();
    $("keysList").querySelectorAll("[data-copy]").forEach(b=>b.onclick=async()=>{try{await navigator.clipboard.writeText(b.dataset.copy);window.toast("Copied")}catch{window.toast("Copy unavailable","bad")}});
    $("keysList").querySelectorAll("[data-revoke]").forEach(b=>b.onclick=async()=>{const [path,id]=b.dataset.revoke.split("|");setActionBusy(b,true,"Revoking");try{
        const patch={status:"REVOKED",revokedAt:Date.now()}; await update(ref(db),{[`${path}/${id}`]:patch});
        try{const pubPath=path==="levelKeys"?`publicLevelKeys/${id}`:`publicActivationKeys/${id}`;await update(ref(db),{[`${pubPath}/status`]:"REVOKED",[`${pubPath}/revokedAt`]:patch.revokedAt});}catch(_){ }
        await audit("Revoked key",{id});window.toast("Key revoked");await loadKeys();
      }catch(e){window.toast("Revoke failed: "+e.message,"bad")}finally{setActionBusy(b,false)}});
    if(!$('keysList').dataset.deleteBound){
      $('keysList').dataset.deleteBound='1';
      $('keysList').addEventListener('click',ev=>{
        const b=ev.target.closest('[data-delete]'); if(!b||!$('keysList').contains(b))return;
        ev.preventDefault();ev.stopPropagation();const raw=b.dataset.delete||'';const cut=raw.indexOf('|');if(cut<1)return window.toast('Invalid key reference','bad');
        const path=raw.slice(0,cut),id=raw.slice(cut+1),keyRecord=window.__keyRecords?.[`${path}|${id}`]||{key:id,path};const article=b.closest('.key-row');article?.remove();window.toast('Deleting…');
        safetyBackup('key-delete',{path,id,record:keyRecord,deletedAt:Date.now()}).catch(()=>{});try{downloadJson(`ADI_X_DATA_KEY_BACKUP_${id}_${Date.now()}.json`,{path,id,record:keyRecord,deletedAt:Date.now()})}catch{}
        (async()=>{try{await ensureAdminSession();await remove(ref(db,`${path}/${id}`));const targets=path==='levelKeys'?[`publicLevelKeys/${id}`]:[`publicActivationKeys/${id}`];await Promise.allSettled(targets.map(target=>remove(ref(db,target))));await audit('Deleted key',{id,path});window.toast('Key deleted permanently');loadKeys().catch(()=>{})}catch(e){window.toast(e?.code==='PERMISSION_DENIED'?'Firebase denied delete. Check published Firebase Rules.':'Key delete failed: '+(e?.message||'Unknown error'),'bad');loadKeys().catch(()=>{})}})();
      });
    }
  }catch(e){$("keysList").innerHTML=`<div class="notice error">Key load failed: ${esc(e.message)}</div>`}
}
async function cleanExpiredKeys(){
  try{
    await ensureAdminSession();
    const [a,l]=await Promise.all([get(ref(db,"activationKeys")),get(ref(db,"levelKeys"))]);
    const now=Date.now(), jobs=[], backups=[];
    for(const [id,v] of Object.entries(a.val()||{})){
      if(v.status==="ACTIVE"&&Number(v.expiresAt||0)<=now){
        backups.push({path:"activationKeys",id,record:v});
        jobs.push([`activationKeys/${id}`,`publicActivationKeys/${id}`]);
      }
    }
    for(const [id,v] of Object.entries(l.val()||{})){
      if(v.status==="ACTIVE"&&Number(v.expiresAt||0)<=now){
        backups.push({path:"levelKeys",id,record:v});
        jobs.push([`levelKeys/${id}`,`publicLevelKeys/${id}`]);
      }
    }
    if(!jobs.length){window.toast('0 expired key(s) removed');return}
    await safetyBackup('expired-keys-cleanup',{items:backups,at:Date.now()});
    await Promise.allSettled(jobs.flat().map(path=>remove(ref(db,path))));
    await audit('Cleaned expired keys',{count:jobs.length});
    window.toast(`${jobs.length} expired key(s) removed`);
    loadKeys().catch(()=>{});
  }catch(e){window.toast('Clean expired failed: '+(e?.message||e),'bad')}
}

function openTopSellers(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">PUBLIC LEADERBOARD</span><h2>Top Sellers</h2><p class="muted">Create curated display entries. These are public leaderboard profiles and are separate from real user accounts.</p></div><div class="toolbar"><button class="secondary" id="refreshTopSellers">↻ Refresh</button></div></div>
  <div class="card form-card" style="margin-bottom:16px"><div class="setting-section"><h3>🏆 Add / Edit Top Seller</h3><div class="settings-grid">
    <label>Display name<input id="tsName" maxlength="40" placeholder="Alex Data Seller"></label>
    <label>Mobile / number<input id="tsNumber" maxlength="24" placeholder="98••••••42"></label>
    <label>Total data sold (MB)<input id="tsData" type="number" min="0" step="1" value="1000"></label>
    <label>Level / badge<input id="tsLevel" maxlength="30" placeholder="Platinum"></label>
  </div><div class="toolbar" style="margin-top:14px"><input id="tsId" type="hidden"><button id="saveTopSeller">Save Top Seller</button><button class="secondary" id="clearTopSeller">Clear</button></div><div id="tsMsg" class="msg"></div></div></div>
  <div id="topSellerListAdmin">Loading…</div>`;
  const fill=async()=>{
    let data={};
    try{data=(await get(ref(db,"publicTopSellers"))).val()||{};}catch(_){data={};}
    if(!Object.keys(data).length){
      try{data=(await get(ref(db,"settings/topSellers"))).val()||{};}catch(_){data={};}
    }
    const rows=Object.entries(data).map(([id,v])=>({id,...(v||{})})).sort((a,b)=>Number(a.rank||999)-Number(b.rank||999));
    const list=$("topSellerListAdmin");
    list.innerHTML=rows.length?rows.map((r,i)=>`<article class="card" style="margin:10px 0"><div class="row"><div><b>#${i+1} · ${esc(r.name||"Unnamed")}</b><div class="muted">${esc(r.number||"—")} · ${esc(r.level||"Bronze")} · ${Math.round(Number(r.dataSold||0))} MB</div></div><div class="toolbar"><button data-ts-edit="${esc(r.id)}">Edit</button><button class="danger" data-ts-delete="${esc(r.id)}">Delete</button></div></div></article>`).join(""):"<div class='notice'>No curated sellers yet.</div>";
    list.querySelectorAll("[data-ts-edit]").forEach(b=>b.onclick=()=>{const r=data[b.dataset.tsEdit]||{};$("tsId").value=b.dataset.tsEdit;$("tsName").value=r.name||"";$("tsNumber").value=r.number||"";$("tsData").value=Number(r.dataSold||0);$("tsLevel").value=r.level||"Bronze";$("tsMsg").textContent="Editing selected entry.";});
    list.querySelectorAll("[data-ts-delete]").forEach(b=>b.onclick=async()=>{
      const id=b.dataset.tsDelete;
      const article=b.closest('.card'); article?.remove();
      window.toast('Deleting Top Seller…');
      try{
        const snapshot=data[id]||{}; await safetyBackup('top-seller-delete',{id,record:snapshot});
        const results=await Promise.allSettled([remove(ref(db,`publicTopSellers/${id}`)),remove(ref(db,`settings/topSellers/${id}`))]);
        if(results.every(r=>r.status==='rejected')) throw (results[0].reason||new Error('Delete denied'));
        await audit("Deleted Top Seller",{id});window.toast("Top Seller deleted");fill();
      }catch(e){window.toast("Delete failed: "+(e.message||e),"bad");fill()}
    });
  };
  $("refreshTopSellers").onclick=()=>withRefresh($("refreshTopSellers"),fill);
  $("clearTopSeller").onclick=()=>{$("tsId").value="";$('tsName').value="";$('tsNumber').value="";$('tsData').value=1000;$('tsLevel').value="Bronze";$('tsMsg').textContent=""};
  $("saveTopSeller").onclick=async()=>{
    const b=$("saveTopSeller");setActionBusy(b,true,"Saving");
    try{
      const id=$("tsId").value.trim()||push(ref(db,"publicTopSellers")).key;
      const existing=await get(ref(db,`publicTopSellers/${id}`));
      const old=existing.val()||{};
      const all=(await get(ref(db,"publicTopSellers"))).val()||{};
      const rank=Number(old.rank||Math.max(0,...Object.values(all).map(v=>Number(v?.rank||0)))+1);
      const payload={name:$("tsName").value.trim()||"Top Seller",number:$("tsNumber").value.trim(),dataSold:Math.max(0,Number($("tsData").value)||0),level:$("tsLevel").value.trim()||"Bronze",rank,updatedAt:Date.now(),source:"admin-curated"};
      const sanitized={};Object.keys(payload).forEach(k=>sanitized[k]=payload[k]);
      const results=await Promise.allSettled([
        set(ref(db,`publicTopSellers/${id}`),sanitized),
        set(ref(db,`settings/topSellers/${id}`),sanitized)
      ]);
      if(results.every(r=>r.status==='rejected')) throw (results[0].reason||new Error('Top Seller write denied'));
      await audit(old.name?"Updated Top Seller":"Created Top Seller",{id,name:payload.name,dataSold:payload.dataSold});
      $("tsMsg").className="msg success";$("tsMsg").textContent="✓ Saved. User app updates in real time.";window.toast("Top Seller saved");await fill();
    }catch(e){$("tsMsg").className="msg error";$("tsMsg").textContent="Save failed: "+(e.message||e);window.toast("Top Seller save failed","bad")}finally{setActionBusy(b,false)}
  };
  fill().catch(e=>$("topSellerListAdmin").innerHTML=`<div class="notice error">${esc(e.message||e)}</div>`);
}

function withdrawalStatusUpper(w){return String(w?.status||"PENDING").trim().toUpperCase()||"PENDING";}
function withdrawalDetails(w={}){
  const d=(w&&typeof w.details==='object'&&w.details)?w.details:{};
  return {
    upiId:String(w.upiId||d.upiId||d.upi||"").trim(),
    accountName:String(w.accountName||d.name||w.bankAccountName||d.accountHolder||"").trim(),
    bankName:String(w.bankName||d.bankName||"").trim(),
    accountNumber:String(w.accountNumber||d.accountNumber||d.accountNo||"").trim(),
    ifsc:String(w.ifsc||d.ifsc||"").trim(),
    number:String(w.mobile||w.number||d.mobile||d.number||"").trim(),
    email:String(w.email||d.email||"").trim(),
    name:String(w.name||d.name||w.accountName||"").trim()
  };
}
function withdrawalDateParts(ms){
  const n=Number(ms); if(!Number.isFinite(n)||n<=0)return {full:'—',time:'—',ms:'—'};
  const d=new Date(n);
  const full=d.toLocaleString(undefined,{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'});
  return {full,time:d.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit',second:'2-digit'}),ms:String(n)};
}
function copyValue(text,label){
  const value=String(text||'');
  if(!value){window.toast(label+' is empty','bad');return;}
  navigator.clipboard?.writeText(value).then(()=>window.toast(label+' copied')).catch(()=>{
    const ta=document.createElement('textarea');ta.value=value;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();window.toast(label+' copied');
  });
}
function renderWithdrawalDetailModal(id,w){
  const existing=document.getElementById('withdrawalDetailModal'); if(existing)existing.remove();
  const det=withdrawalDetails(w), created=withdrawalDateParts(w.createdAt), updated=withdrawalDateParts(w.updatedAt||w.createdAt);
  const status=withdrawalStatusUpper(w), order=String(w.orderId||id||'—');
  const reason=String(w.rejectionReason||w.reason||w.statusReason||'').trim();
  const modal=document.createElement('div');modal.id='withdrawalDetailModal';modal.className='admin-modal-layer';
  const valueRow=(label,value,key)=>`<div class="admin-detail-box"><small>${esc(label)}</small><strong>${esc(value||'—')}</strong>${value?`<button type="button" class="secondary tiny copy-detail" data-copy="${esc(value)}">Copy</button>`:''}</div>`;
  modal.innerHTML=`<div class="editor-modal withdrawal-detail-modal"><div class="section-head"><div><span class="eyebrow">WITHDRAWAL RECORD</span><h2>${esc(order)}</h2><p class="muted">Complete payout details · exact submission and update time.</p></div><button class="secondary" data-close>×</button></div>
    <div class="withdrawal-detail-status status-${status.toLowerCase().replace(/[^a-z0-9_-]/g,'')}"><span class="pill withdrawal-status status-pill-${status.toLowerCase().replace(/[^a-z0-9_-]/g,'')}">${esc(status)}</span><b>${money(w.amount)}</b></div>
    <div class="withdrawal-detail-grid">
      ${valueRow('Order ID',order)}${valueRow('User',det.name||w.name||'—')} ${valueRow('Mobile / Number',det.number,'number')}${valueRow('Email',det.email,'email')}
      ${valueRow('Method',String(w.method||'—').toUpperCase())}${valueRow('Amount',money(w.amount))}${valueRow('Submitted on',created.full)}${valueRow('Submitted at',created.time)}
      ${valueRow('Last updated',updated.full)}${valueRow('Updated at',updated.time)}${valueRow('UID',w.uid)}
      ${valueRow('UPI ID',det.upiId,'upi')}${valueRow('Bank Name',det.bankName)}${valueRow('Account Name',det.accountName)}${valueRow('Account Number',det.accountNumber)}${valueRow('IFSC',det.ifsc,'ifsc')}
    </div>
    ${reason?`<div class="withdrawal-reason-box"><small>DECISION / REJECTION REASON</small><p>${esc(reason)}</p></div>`:''}
    <div class="editor-footer"><button class="secondary" data-close>Close</button>${['PENDING','PROCESSING','IN_PROGRESS'].includes(status)?`<button data-detail-action="APPROVED">Approve</button><button class="danger" data-detail-action="REJECTED">Reject</button><button class="danger" data-detail-action="REJECT_RETURN">Reject & Return</button>`:(['APPROVED','COMPLETED','PAID'].includes(status)&&!w.balanceReturned?`<button class="danger" data-detail-action="REJECT_RETURN">Reject & Return</button>`:'')}</div></div>`;
  document.body.appendChild(modal);
  modal.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>copyValue(b.dataset.copy,b.parentElement.querySelector('small')?.textContent||'Value'));
  modal.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>modal.remove());
  modal.querySelectorAll('[data-detail-action]').forEach(b=>b.onclick=async()=>{await decideWithdrawal(id,b.dataset.detailAction);if(document.body.contains(modal))modal.remove();});
  modal.addEventListener('click',e=>{if(e.target===modal)modal.remove()});
}
async function requestWithdrawalDecisionReason(action){
  const normalAction=String(action||'').toUpperCase();
  const isReturn=normalAction==='REJECT_RETURN';
  const existing=document.getElementById('withdrawalReasonModal');
  if(existing) existing.remove();
  return await new Promise(resolve=>{
    const modal=document.createElement('div');
    modal.id='withdrawalReasonModal';
    modal.className='admin-modal-layer withdrawal-reason-layer';
    modal.innerHTML=`<div class="editor-modal withdrawal-reason-modal" role="dialog" aria-modal="true" aria-labelledby="withdrawalReasonTitle">
      <div class="withdrawal-reason-hero ${isReturn?'return':''}"><span class="withdrawal-reason-icon">${isReturn?'↩':'✦'}</span><div><span class="eyebrow">DECISION NOTE</span><h2 id="withdrawalReasonTitle">${isReturn?'Reject & Return':'Reject Withdrawal'}</h2><p>${isReturn?'A refund will be issued when the return action completes.':'This reason will be saved with the withdrawal record and shown to the user.'}</p></div></div>
      <label class="withdrawal-reason-field"><span>Reason</span><textarea id="withdrawalDecisionReason" rows="6" maxlength="600" autofocus placeholder="Type the reason clearly…"></textarea><div class="withdrawal-reason-footer"><small id="withdrawalReasonCount">0 / 600</small><span>Required</span></div></label>
      <div class="editor-footer withdrawal-reason-actions"><button type="button" class="secondary" data-reason-cancel>Cancel</button><button type="button" class="danger" data-reason-submit>${isReturn?'Reject & Return':'Reject'}</button></div>
    </div>`;
    document.body.appendChild(modal);
    const textarea=modal.querySelector('#withdrawalDecisionReason');
    const count=modal.querySelector('#withdrawalReasonCount');
    const close=value=>{modal.remove();resolve(value);};
    const updateCount=()=>{if(count) count.textContent=`${String(textarea?.value||'').length} / 600`;};
    textarea?.addEventListener('input',updateCount);
    modal.querySelector('[data-reason-cancel]')?.addEventListener('click',()=>close(null));
    modal.querySelector('[data-reason-submit]')?.addEventListener('click',()=>{
      const clean=String(textarea?.value||'').trim();
      if(!clean){textarea?.focus();window.toast('Please enter a reason','bad');return;}
      close(clean);
    });
    modal.addEventListener('click',e=>{if(e.target===modal)close(null)});
    setTimeout(()=>{textarea?.focus();updateCount();},0);
  });
}
async function decideWithdrawal(id,action){
  await ensureAdminSession();
  const snap=await get(ref(db,`withdrawals/${id}`));
  if(!snap.exists())throw new Error('Withdrawal record not found.');
  const w=snap.val()||{};
  const status=withdrawalStatusUpper(w);
  const normalAction=String(action||'').toUpperCase();
  if(['REJECTED','REJECT_RETURN'].includes(normalAction)){
    const clean=await requestWithdrawalDecisionReason(normalAction);
    if(clean===null)return;
    const payload={status:'REJECTED',statusMessage:clean,reason:clean,rejectionReason:clean,decisionReason:clean,updatedAt:Date.now(),decisionAt:Date.now(),decisionBy:auth.currentUser?.uid||'admin'};
    if(normalAction==='REJECT_RETURN'){
      if(String(w.balanceReturned||false)!=='true' && String(w.balanceAdjusted||false)==='true' && w.uid){
        await runTransaction(ref(db,`users/${w.uid}/balance`),current=>Number(current||0)+Number(w.amount||0));
        payload.balanceReturned=true;payload.balanceReturnedAt=Date.now();payload.balanceReturnBy=auth.currentUser?.uid||'admin';
      }else if(String(w.balanceReturned||false)==='true'){
        window.toast('This withdrawal was already returned','bad');return;
      }
    }
    await update(ref(db,`withdrawals/${id}`),payload);
    await audit(normalAction==='REJECT_RETURN'?'Rejected withdrawal and returned balance':'Rejected withdrawal',{id,uid:w.uid,amount:Number(w.amount||0),reason:clean,action:normalAction});
    window.toast(normalAction==='REJECT_RETURN'?'Withdrawal rejected • balance returned':'Withdrawal rejected');
    await loadWithdrawalsOnce();return;
  }
  if(normalAction==='APPROVED'){
    if(!['PENDING','PROCESSING','IN_PROGRESS'].includes(status)){window.toast(`Cannot approve a ${status.toLowerCase()} withdrawal`,'bad');return;}
    const amount=Number(w.amount||0);if(!Number.isFinite(amount)||amount<0)throw new Error('Invalid withdrawal amount.');
    if(!w.uid)throw new Error('Withdrawal has no user UID.');
    let adjusted=String(w.balanceAdjusted||false)==='true';
    if(!adjusted){
      const tx=await runTransaction(ref(db,`users/${w.uid}/balance`),current=>{
        const n=Number(current||0);if(n<amount)return;return n-amount;
      });
      if(!tx.committed)throw new Error('User balance is too low for this approval.');
      adjusted=true;
    }
    await update(ref(db,`withdrawals/${id}`),{status:'APPROVED',statusMessage:'Withdrawal approved',updatedAt:Date.now(),decisionAt:Date.now(),decisionBy:auth.currentUser?.uid||'admin',balanceAdjusted:adjusted,balanceAdjustedAt:w.balanceAdjustedAt||Date.now(),balanceReturned:false});
    await audit('Approved withdrawal',{id,uid:w.uid,amount,orderId:w.orderId||id,balanceAdjusted:adjusted});
    window.toast('Withdrawal approved');await loadWithdrawalsOnce();return;
  }
}
function openWithdrawals(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">PAYOUT CONTROL</span><h2>Withdrawals</h2><p class="muted">Deep payout view with exact time, payout details, searchable identifiers and decision reasons.</p></div><button class="secondary" id="refreshWd">↻ Refresh</button></div>
  <div class="toolbar withdrawal-search-toolbar"><label style="flex:1;min-width:220px">Search withdrawal<input id="wdSearch" type="search" autocomplete="off" placeholder="Name, mobile, UPI, account, IFSC, email, Order ID or amount"></label></div><div id="wdList">Loading…</div>`;
  $('refreshWd').onclick=()=>withRefresh($('refreshWd'),loadWithdrawalsOnce);
  $('wdSearch').addEventListener('input',()=>loadWithdrawalsOnce());
  loadWithdrawalsOnce();
}
async function loadWithdrawalsOnce(){await ensureAdminSession();
 try{const s=await get(ref(db,'withdrawals'));const entries=Object.entries(s.val()||{}).reverse();const q=String($('wdSearch')?.value||'').trim().toLowerCase();
  const filtered=entries.filter(([id,w])=>{const d=withdrawalDetails(w);return !q||[id,w?.orderId,w?.name,w?.number,w?.mobile,w?.email,w?.uid,w?.method,w?.status,w?.amount,w?.createdAt,d.upiId,d.accountName,d.bankName,d.accountNumber,d.ifsc].map(v=>String(v??'').toLowerCase()).join(' ').includes(q)});
  $('wdList').innerHTML=filtered.length?filtered.map(([id,w])=>{const d=withdrawalDetails(w),st=withdrawalStatusUpper(w),created=withdrawalDateParts(w.createdAt);const pending=['PENDING','PROCESSING','IN_PROGRESS'].includes(st);const canReturn=['APPROVED','COMPLETED','PAID'].includes(st)&&!w.balanceReturned;return `<article class="card withdrawal-row-card"><div class="withdrawal-row-main"><div class="withdrawal-row-top"><b>${money(w.amount)}</b><span class="pill withdrawal-status status-pill-${st.toLowerCase().replace(/[^a-z0-9_-]/g,'')}">${esc(st)}</span></div><div class="withdrawal-row-meta"><span>${esc(w.orderId||id)}</span><span>${esc(created.full)}</span><span>${esc(String(w.method||'').toUpperCase())}</span></div><div class="withdrawal-row-user"><b>${esc(d.name||w.name||'User')}</b><span>${esc(d.number||w.mobile||w.number||'—')}</span><span>${esc(d.upiId||d.accountNumber||'')}</span></div></div><div class="toolbar withdrawal-row-actions"><button class="secondary" data-wd-view="${esc(id)}">View details</button>${pending?`<button data-wd="${esc(id)}|APPROVED">Approve</button><button class="danger" data-wd="${esc(id)}|REJECTED">Reject</button><button class="danger" data-wd="${esc(id)}|REJECT_RETURN">Reject & Return</button>`:canReturn?`<button class="danger" data-wd="${esc(id)}|REJECT_RETURN">Reject & Return</button>`:''}</div></article>`}).join(''):`<div class='notice'>${q?`No withdrawal matches <b>${esc(q)}</b>.`:'No withdrawal requests.'}</div>`;
  $('wdList').querySelectorAll('[data-wd]').forEach(btn=>btn.onclick=async()=>{const [id,action]=String(btn.dataset.wd).split('|');try{setActionBusy(btn,true,'Working');await decideWithdrawal(id,action);}catch(e){window.toast(e?.message||'Withdrawal action failed','bad')}finally{setActionBusy(btn,false)}});
  $('wdList').querySelectorAll('[data-wd-view]').forEach(btn=>btn.onclick=async()=>{try{const s2=await get(ref(db,`withdrawals/${btn.dataset.wdView}`));if(s2.exists())renderWithdrawalDetailModal(btn.dataset.wdView,s2.val()||{});}catch(e){window.toast('Could not open details: '+(e?.message||e),'bad')}});
 }catch(e){$('wdList').innerHTML=`<div class='notice error'>Failed to load withdrawals: ${esc(e?.message||e)}</div>`;}}

function openSupport(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">PRIVATE INBOX</span><h2>Support Center</h2><p class="muted">Active chats can be removed from the inbox. A permanent archive remains available to admin.</p></div><div class="toolbar"><button class="secondary" id="refreshSupport">↻ Refresh</button><button class="secondary" id="showSupportArchive">Permanent Archive</button></div></div><div id="supportList">Loading…</div><div id="supportArchive" class="hidden"></div>`;
  const render=(data)=>{
    const cards=Object.entries(data||{}).reverse();
    $("supportList").innerHTML=cards.length?cards.map(([uid,msgs])=>`<article class="card support-card"><div class="row"><div><b>Conversation</b><div class="muted mono">${esc(uid)}</div></div><button class="danger tiny" data-delete-support="${esc(uid)}">Delete Inbox</button></div>${Object.entries(msgs||{}).map(([mid,m])=>`<div class="chat ${m.from==="admin"?"mine":""}"><span>${esc(m.text||"")}</span><small>${m.createdAt?new Date(m.createdAt).toLocaleString():""}</small></div>`).join("")}<div class="reply-row"><input data-reply="${esc(uid)}" placeholder="Reply privately"><button data-send="${esc(uid)}">Send</button></div></article>`).join(""):"<div class='notice'>No active support messages.</div>";
    $("supportList").querySelectorAll("[data-send]").forEach(b=>b.onclick=async()=>{
      const uid=b.dataset.send,input=document.querySelector(`[data-reply="${CSS.escape(uid)}"]`),text=input?.value.trim();if(!text)return;
      setActionBusy(b,true,"Sending");try{const msgRef=push(ref(db,`support/${uid}`));const payload={from:"admin",text,createdAt:Date.now(),messageId:msgRef.key};await set(ref(db,`support/${uid}/${msgRef.key}`),payload);try{await set(ref(db,`supportArchive/${uid}/${msgRef.key}`),{...payload,archivedAt:Date.now(),archivedBy:auth.currentUser?.uid||"admin"});}catch(archiveErr){window.toast("Message sent • Archive needs its Firebase rule","ok")}await audit("Replied to support",{uid,messageId:msgRef.key});input.value="";window.toast("Reply sent");loadSupportOnce()}catch(e){window.toast("Reply failed: "+(e?.code||e?.message||"Unknown error")+" — verify the V3 Firebase Rules","bad")}finally{setActionBusy(b,false)}
    });
    $("supportList").querySelectorAll("[data-delete-support]").forEach(b=>b.onclick=async()=>{
      const uid=b.dataset.deleteSupport;if(!confirm("Remove this conversation from the active inbox? The permanent archive will remain."))return;
      setActionBusy(b,true,"Deleting");try{await safeRemove(`support/${uid}`);try{await audit("Deleted support inbox conversation",{uid})}catch{}window.toast("Conversation deleted from active inbox");await loadSupportOnce()}catch(e){window.toast(e?.code==="PERMISSION_DENIED"?"Delete denied by Firebase Rules. Verify the published admin UID.":"Delete failed: "+(e?.code||e?.message||"Unknown error"),"bad")}finally{setActionBusy(b,false)}});
  };
  const renderArchive=(data)=>{
    const cards=Object.entries(data||{}).reverse();
    $("supportArchive").innerHTML=`<div class="card archive-card"><div class="section-head"><div><span class="eyebrow">IMMUTABLE HISTORY</span><h3>Permanent Support Archive</h3><p class="muted">Archived support messages are retained for admin records and are not removed when an active inbox conversation is deleted.</p></div><button class="secondary" id="hideSupportArchive">Hide</button></div>${cards.length?cards.map(([uid,msgs])=>`<div class="archive-thread"><div class="row"><b>User ${esc(uid)}</b><span class="pill">PERMANENT</span></div>${Object.values(msgs||{}).map(m=>`<div class="chat ${m.from==="admin"?"mine":""}"><span>${esc(m.text||"")}</span><small>${m.createdAt?new Date(m.createdAt).toLocaleString():""}</small></div>`).join("")}</div>`).join(""):"<div class='notice'>No archived support messages.</div>"}</div>`;
    $("hideSupportArchive").onclick=()=>$("supportArchive").classList.add("hidden");
  };
  window.loadSupportOnce=async()=>{
    let activeVal=null,archiveVal=null;
    try{ const active=await get(ref(db,"support")); activeVal=active.val(); render(activeVal); }
    catch(e){ $("supportList").innerHTML=`<div class="notice error">Support load failed: ${esc(e.message)}<br><small>Firebase Rules must allow the authorised admin account to read/write <b>support</b>.</small></div>`; return; }
    try{ const archive=await get(ref(db,"supportArchive")); archiveVal=archive.val(); renderArchive(archiveVal); }
    catch(e){ $("supportArchive").innerHTML=`<div class="card archive-card"><div class="notice error">Archive load failed: ${esc(e.message)}<br><small>Verify the V3 Firebase Rules to enable the permanent admin archive.</small></div></div>`; }
  };
  $("refreshSupport").onclick=()=>withRefresh($("refreshSupport"),loadSupportOnce);
  $("showSupportArchive").onclick=()=>$("supportArchive").classList.remove("hidden");
  loadSupportOnce();
}

function openNotifications(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">BROADCAST</span><h2>Notifications</h2><p class="muted">Premium user popup broadcast with heading, message, close control and optional live countdown metadata.</p></div></div><div class="card form-card notification-composer"><label>Popup title<input id="nt" placeholder="Important update"></label><label>Popup message<textarea id="nb" rows="5" placeholder="Write the message users should see."></textarea></label><div class="notification-options"><label>Closable<select id="nDismiss"><option value="true" selected>YES</option><option value="false">NO</option></select></label><label>Auto close<select id="nAuto"><option value="false" selected>OFF</option><option value="true">ON</option></select></label><label>Close countdown (seconds)<input id="nSeconds" type="number" min="1" max="120" value="15"></label></div><button id="sendN">Send premium popup to all users</button><div id="nm" class="msg"></div></div>`;
  $("sendN").onclick=async()=>{
    const title=$("nt").value.trim(),body=$("nb").value.trim();
    if(!title||!body){$("nm").className="msg error";$("nm").textContent="Title and message are required.";return;}
    const dismissible=$("nDismiss").value==='true';
    const autoClose=$("nAuto").value==='true';
    const autoCloseSeconds=Math.max(1,Math.min(120,Number($("nSeconds").value)||15));
    try{
      await push(ref(db,"notifications/all"),{title,body,createdAt:Date.now(),popup:true,displayType:"premium",dismissible,showCloseButton:dismissible,autoClose,autoCloseSeconds:autoClose?autoCloseSeconds:0,closeLabel:"Close",liveCountdown:autoClose});
      await audit("Sent premium broadcast notification",{autoClose,dismissible,autoCloseSeconds:autoClose?autoCloseSeconds:0});
      $("nm").className="msg success";$("nm").textContent="Premium notification sent.";
    }catch(e){$("nm").className="msg error";$("nm").textContent=e.message}
  };
}

function applyAppearanceSettings(v={}){
  const root=document.documentElement;
  const themes={emerald:['#52f2a3','#8c78ff'],violet:['#b89cff','#6f62ff'],ice:['#8fe8ff','#718cff'],amber:['#ffd58a','#b88a5a']};
  const pair=themes[v.accentTheme||'emerald']||themes.emerald;
  root.style.setProperty('--accent',pair[0]);root.style.setProperty('--accent2',pair[1]);
  const blur={soft:12,balanced:20,rich:28}[v.glassIntensity||'balanced']||20;
  root.style.setProperty('--glass-blur',blur+'px');
  const fonts={cinzel:"Cinzel",playfair:"Playfair Display",cormorant:"Cormorant Garamond",dmserif:"DM Serif Display",libre:"Libre Baskerville",lora:"Lora",merriweather:"Merriweather",montserrat:"Montserrat",poppins:"Poppins",manrope:"Manrope",space:"Space Grotesk",outfit:"Outfit",sora:"Sora",jakarta:"Plus Jakarta Sans",raleway:"Raleway",josefin:"Josefin Sans",bebas:"Bebas Neue",rubik:"Rubik"};
  root.style.setProperty('--font-all',`"${fonts[v.fontFamily||'manrope']||fonts.manrope}",system-ui,sans-serif`);
  root.dataset.motion=v.motionMode||'full';root.dataset.density=v.dashDensity||'comfortable';
  root.dataset.liveBadges=v.liveBadges===false?'off':'on';
  root.dataset.glass=v.glassIntensity||'balanced';
}

function openSettings(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">GLOBAL CONFIG</span><h2>Settings</h2><p class="muted">A premium command layer for app limits, presentation, performance, notifications and admin safety.</p></div><button class="secondary" id="refreshSettings">↻ Refresh</button></div>
  <div class="settings-grid">
   <div class="card form-card feature-card"><div class="setting-section"><h3>💳 Withdrawal</h3><p class="setting-hint">Configure the genuine withdrawal threshold and the methods shown to users.</p><label>Minimum withdrawal<input id="min" type="number" step="1" value="899"></label><label>Withdrawal method label<input id="wdLabel" placeholder="UPI + Bank"></label></div>
   <div class="setting-section communication-settings"><div class="communication-head"><div><span class="eyebrow">LIVE TELEGRAM CONTROL</span><h3>📣 Telegram Control Center</h3></div><span class="telegram-live-chip">● LIVE</span></div><p class="setting-hint">Change any Telegram destination here. User apps read these links live from Firebase, so a saved change propagates without rebuilding the User app. This compartment always uses the system font.</p><div class="telegram-destination-grid">
<label>Main Support / Chooser<input id="tgSupport" placeholder="https://t.me/username or @username"><button class="secondary tg-test" type="button" data-tg-test="tgSupport">Open Telegram</button></label>
<label>AI Support / Chat Actions<input id="tgAI" placeholder="https://t.me/username or @username"><button class="secondary tg-test" type="button" data-tg-test="tgAI">Open Telegram</button></label>
<label>Profile Support<input id="tgProfile" placeholder="https://t.me/username or @username"><button class="secondary tg-test" type="button" data-tg-test="tgProfile">Open Telegram</button></label>
<label>Withdrawal Support<input id="tgWithdrawal" placeholder="https://t.me/username or @username"><button class="secondary tg-test" type="button" data-tg-test="tgWithdrawal">Open Telegram</button></label>
<label>Level Support<input id="tgLevel" placeholder="https://t.me/username or @username"><button class="secondary tg-test" type="button" data-tg-test="tgLevel">Open Telegram</button></label>
<label>Other / Backup<input id="tgOther" placeholder="https://t.me/username or @username"><button class="secondary tg-test" type="button" data-tg-test="tgOther">Open Telegram</button></label>
</div><div class="telegram-control-actions"><button class="primary" type="button" id="saveTelegramControl">✓ Save Telegram Control</button><span id="telegramControlMsg" class="telegram-control-msg"></span></div><input type="hidden" id="tg"><label>Support email<input id="supportEmail"></label><label>Announcement<input id="announcement"></label></div>
   <div class="setting-section"><h3>⚙️ App state</h3><p class="setting-hint">Operational controls. Maintenance mode should only be used when needed.</p><label>Maintenance<select id="mm"><option value="false">OFF</option><option value="true">ON</option></select></label><label>Maintenance popup title<input id="maintenanceTitle" placeholder="App in maintenance mode"></label><label>Maintenance message<textarea id="maintenanceMessage" rows="3" placeholder="We'll be back shortly."></textarea></label><label>App announcement enabled<select id="announceOn"><option value="true">ON</option><option value="false">OFF</option></select></label></div>
   <div class="setting-section"><h3>🔑 Key policy</h3><p class="setting-hint">Supported active upgrade keys: Gold ₹100 · Platinum ₹149 · Master ₹199. Silver is removed from the level/key system.</p><label>Key expiry value<input id="keyLife" type="number" min="1" max="168" value="24"></label><label>Key expiry unit<select id="keyUnit"><option value="seconds">Seconds</option><option value="minutes">Minutes</option><option value="hours" selected>Hours</option></select></label><label>One-time redemption<select id="oneTime"><option value="true">ENFORCED</option><option value="false">OFF</option></select></label><label>Default user level<select id="defaultLevel">${[[0,'Bronze'],[2,'Gold'],[3,'Platinum'],[5,'Master']].map(([n,label])=>`<option value="${n}">Level ${n} · ${label}</option>`).join("")}</select></label><label>Max keys per generation<input id="maxKeys" type="number" min="1" max="100" value="25"></label></div>
   <div class="card form-card feature-card"><div class="setting-section"><h3>✨ Luxury Appearance</h3><p class="setting-hint">These preferences are stored in Firebase so the admin UI can keep the same presentation after reload.</p><label>Accent theme<select id="accentTheme"><option value="emerald">Emerald Glass</option><option value="violet">Royal Violet</option><option value="ice">Ice Blue</option><option value="amber">Champagne Amber</option></select></label><label>Global UI font<select id="fontFamily">${[{v:"cinzel",n:"Cinzel — Luxury"},{v:"playfair",n:"Playfair Display"},{v:"cormorant",n:"Cormorant Garamond"},{v:"dmserif",n:"DM Serif Display"},{v:"libre",n:"Libre Baskerville"},{v:"lora",n:"Lora"},{v:"merriweather",n:"Merriweather"},{v:"montserrat",n:"Montserrat"},{v:"poppins",n:"Poppins"},{v:"manrope",n:"Manrope"},{v:"space",n:"Space Grotesk"},{v:"outfit",n:"Outfit"},{v:"sora",n:"Sora"},{v:"jakarta",n:"Plus Jakarta Sans"},{v:"raleway",n:"Raleway"},{v:"josefin",n:"Josefin Sans"},{v:"bebas",n:"Bebas Neue"},{v:"rubik",n:"Rubik"}].map(x=>`<option value="${x.v}">${x.n}</option>`).join("")}</select><small class="field-help">Applies across the complete admin UI.</small></label><label>Glass intensity<select id="glassIntensity"><option value="soft">Soft</option><option value="balanced" selected>Balanced</option><option value="rich">Rich</option></select></label><label>Dashboard density<select id="dashDensity"><option value="comfortable" selected>Comfortable</option><option value="compact">Compact</option></select></label><label>Motion<select id="motionMode"><option value="full" selected>Full luxury</option><option value="reduced">Reduced</option></select></label></div></div>
   <div class="card form-card feature-card"><div class="setting-section"><h3>⚡ Performance & Behaviour</h3><p class="setting-hint">Tune background refresh and safety prompts without changing Firebase data.</p><label>Auto-refresh interval<select id="autoRefresh"><option value="0">OFF</option><option value="15">15 seconds</option><option value="30" selected>30 seconds</option><option value="60">60 seconds</option></select></label><label>Default landing page<select id="landingPage"><option value="dashboard">Dashboard</option><option value="users">Users</option><option value="keys">Keys</option><option value="withdrawals">Withdrawals</option><option value="settings">Settings</option></select></label><label>Destructive-action confirmation<select id="confirmDanger"><option value="true" selected>ON</option><option value="false">OFF</option></select></label><label>Live dashboard badges<select id="liveBadges"><option value="true" selected>ON</option><option value="false">OFF</option></select></label></div></div>
   <div class="card form-card feature-card"><div class="setting-section"><h3>🛡️ Admin Safety</h3><p class="setting-hint">Local-session controls and export tools. These do not weaken Firebase authentication.</p><div class="settings-toggle-row"><div class="settings-badge">● ADMIN ACCESS LOCKED</div><div class="settings-badge">● AUDIT READY</div></div><label>Session reminder<select id="sessionReminder"><option value="15">15 minutes</option><option value="30" selected>30 minutes</option><option value="60">60 minutes</option></select></label><label>Audit detail<select id="auditDetail"><option value="standard" selected>Standard</option><option value="verbose">Verbose</option><option value="critical">Critical only</option></select></label><label>Show sensitive admin hints<select id="sensitiveHints"><option value="true">ON</option><option value="false">OFF</option></select></label><div class="settings-actions"><button class="secondary" id="resetUiState">Reset local UI</button><button class="secondary" id="exportSettings">Export config</button></div></div></div>
   <div class="card form-card feature-card command-card"><div class="setting-section"><h3>🎛️ Global Feature Control</h3><p class="setting-hint">Master switches for user-facing modules. Turning a switch off should be treated as an operational policy, not a data edit.</p><div class="control-grid"><label class="switch-line"><span>Registration</span><select id="registrationEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label><label class="switch-line"><span>Sell Data</span><select id="sellDataEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label><label class="switch-line"><span>Withdrawals</span><select id="withdrawalsEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label><label class="switch-line"><span>Support Chat</span><select id="supportEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label><label class="switch-line"><span>Notifications</span><select id="notificationsEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label><label class="switch-line"><span>Level Upgrades</span><select id="upgradesEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label></div></div></div>
   <div class="card form-card feature-card financial-settings-card"><div class="setting-section"><h3>💎 Control Center · Financial Telemetry</h3><p class="setting-hint">Dedicated controls for the live financial cards. Values are calculated from genuine Firebase records; this panel does not create or edit balances.</p><label>Total Balance card<select id="showTotalBalance"><option value="true">SHOW</option><option value="false">HIDE</option></select></label><label>Pending Withdrawal Balance card<select id="showPendingWithdrawalBalance"><option value="true">SHOW</option><option value="false">HIDE</option></select></label><label>Control Center refresh<select id="controlCenterRefresh"><option value="5">5 seconds</option><option value="10" selected>10 seconds</option><option value="15">15 seconds</option><option value="30">30 seconds</option><option value="60">60 seconds</option></select></label><div class="financial-source-note"><span>✓</span><div><strong>Calculation source locked</strong><small>Total Balance = Σ users/*/balance<br>Pending Withdrawal Balance = Σ pending withdrawals.amount<br>Pending withdrawal amounts are kept separate to avoid double-counting.</small></div></div></div></div>
   <div class="card form-card feature-card command-card"><div class="setting-section"><h3>🧠 Governance & Limits</h3><p class="setting-hint">Central policy values for future client/backend enforcement. Keep them transparent and auditable.</p><label>Daily withdrawal limit per user (₹)<input id="dailyWithdrawalLimit" type="number" min="0" step="1" value="0"><small class="field-help">0 = unlimited. Approval checks the user's withdrawals for the current calendar day.</small></label><label>Daily data activity cap (MB)<input id="dailyDataCap" type="number" min="0" step="1" value="0"></label><label>Max pending withdrawals per user<input id="maxPendingWithdrawals" type="number" min="1" max="20" value="1"></label><label>Transaction correction window (hours)<input id="correctionWindow" type="number" min="0" max="720" value="24"></label><label>Privacy mode<select id="privacyMode"><option value="standard" selected>Standard</option><option value="strict">Strict</option></select></label></div></div>
  </div>
  <div class="card form-card"><h3>💎 Active level rates (₹ / MB)</h3>${[["Bronze",0],["Gold",1],["Platinum",2],["Master",3]].map(([n,i])=>`<label>${n}<input id="rate${i}" type="number" step="0.001"></label>`).join("")}<div class="settings-actions"><button id="saveSettings">Save all settings</button><button class="secondary" id="resetSettings">Reset defaults</button></div><div id="sm" class="msg"></div></div>`;
  async function fill(){
    await ensureAdminSession();
    const s=await get(ref(db,"settings"));const v=s.val()||{};
    if(v.rates && (Object.prototype.hasOwnProperty.call(v.rates,'Silver')||Object.prototype.hasOwnProperty.call(v.rates,'Diamond'))){ update(ref(db,"settings"),{"rates/Silver":null,"rates/Diamond":null}).catch(()=>{}); }
    $('min').value=v.minWithdrawal??899;$('wdLabel').value=v.withdrawalMethodLabel||"UPI + Bank";$('maintenanceTitle').value=v.maintenanceTitle||'App in maintenance mode';const tgMap=v.telegramDestinations||{};$('tgSupport').value=tgMap.support||v.telegramDestination||"";$('tgAI').value=tgMap.ai||v.telegramDestination||"";$('tgProfile').value=tgMap.profile||v.telegramDestination||"";$('tgWithdrawal').value=tgMap.withdrawal||v.telegramDestination||"";$('tgLevel').value=tgMap.level||v.telegramDestination||"";$('tgOther').value=tgMap.other||v.telegramDestination||"";$('tg').value=tgMap.support||v.telegramDestination||"";$('mm').value=String(!!v.maintenanceMode);$('supportEmail').value=v.supportEmail||"";$('announcement').value=v.announcement||"";$('maintenanceMessage').value=v.maintenanceMessage||"We'll be back shortly.";$('announceOn').value=String(v.announcementEnabled!==false);
    $('keyLife').value=v.keyLifetimeValue??v.keyLifetimeHours??24;$('keyUnit').value=v.keyLifetimeUnit||'hours';$('oneTime').value=String(v.oneTimeRedemption!==false);$('defaultLevel').value=String(v.defaultUserLevel??0);$('maxKeys').value=v.maxKeysPerGeneration??25;
    const defaults=[.10,.20,.30,.50],r=v.rates||{};[["Bronze",0],["Gold",1],["Platinum",2],["Master",3]].forEach(([n,i])=>$('rate'+i).value=r[n]??defaults[i]);
    $('accentTheme').value=v.accentTheme||'emerald';$('fontFamily').value=v.fontFamily||'manrope';$('glassIntensity').value=v.glassIntensity||'balanced';$('dashDensity').value=v.dashDensity||'comfortable';$('motionMode').value=v.motionMode||'full';$('autoRefresh').value=String(v.autoRefreshSeconds??30);$('landingPage').value=v.landingPage||'dashboard';$('confirmDanger').value=String(v.confirmDanger!==false);$('liveBadges').value=String(v.liveBadges!==false);$('sessionReminder').value=String(v.sessionReminderMinutes??30);$('auditDetail').value=v.auditDetail||'standard';$('sensitiveHints').value=String(v.sensitiveHints!==false);$('registrationEnabled').value=String(v.registrationEnabled!==false);$('sellDataEnabled').value=String(v.sellDataEnabled!==false);$('withdrawalsEnabled').value=String(v.withdrawalsEnabled!==false);$('supportEnabled').value=String(v.supportEnabled!==false);$('notificationsEnabled').value=String(v.notificationsEnabled!==false);$('upgradesEnabled').value=String(v.upgradesEnabled!==false);$('showTotalBalance').value=String(v.showTotalBalance!==false);$('showPendingWithdrawalBalance').value=String(v.showPendingWithdrawalBalance!==false);$('controlCenterRefresh').value=String(v.controlCenterRefreshSeconds??10);$('dailyWithdrawalLimit').value=v.dailyWithdrawalLimitPerUser??0;$('dailyDataCap').value=v.dailyDataCapMB??0;$('maxPendingWithdrawals').value=v.maxPendingWithdrawalsPerUser??1;$('correctionWindow').value=v.transactionCorrectionWindowHours??24;$('privacyMode').value=v.privacyMode||'standard';
    applyAppearanceSettings(v);
  }
  fill();$('refreshSettings').onclick=()=>withRefresh($('refreshSettings'),fill);
  setTimeout(()=>{
    document.querySelectorAll('[data-tg-test]').forEach(btn=>btn.onclick=()=>{
      const input=$(btn.dataset.tgTest);const url=normalizeAdminSupport(input?.value?.trim()||'');
      if(!url){window.toast('Enter a valid Telegram destination first','bad');return}
      try{const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener noreferrer';a.style.display='none';document.body.appendChild(a);a.click();a.remove();}catch(_){location.href=url}
    });
  },0);
  const syncKeyLifeLimit=()=>{$('keyLife').max=$('keyUnit').value==='seconds'?86400:($('keyUnit').value==='minutes'?1440:168);if(Number($('keyLife').value)>Number($('keyLife').max))$('keyLife').value=$('keyLife').max;};$('keyUnit').addEventListener('change',syncKeyLifeLimit);syncKeyLifeLimit();
  ['accentTheme','fontFamily','glassIntensity','dashDensity','motionMode','liveBadges'].forEach(id=>$(id)?.addEventListener('change',()=>{applyAppearanceSettings({accentTheme:$('accentTheme').value,fontFamily:$('fontFamily').value,glassIntensity:$('glassIntensity').value,dashDensity:$('dashDensity').value,motionMode:$('motionMode').value,liveBadges:$('liveBadges').value==='true'})}));
  $('saveTelegramControl').onclick=async()=>{
    const btn=$('saveTelegramControl'),msg=$('telegramControlMsg'); if(!btn)return;
    const fields={support:'tgSupport',ai:'tgAI',profile:'tgProfile',withdrawal:'tgWithdrawal',level:'tgLevel',other:'tgOther'},map={};
    try{setActionBusy(btn,true,"Saving");
      for(const [slot,id] of Object.entries(fields)){const raw=String($(id)?.value||'').trim();const n=normalizeAdminSupport(raw);if(raw&&!n)throw new Error('Invalid Telegram destination in '+slot+'.');map[slot]=n;}
      await update(ref(db,'settings'),{telegramDestination:map.support||'',telegramDestinations:map,telegramUpdatedAt:Date.now()});
      $('tgSupport').value=map.support;$('tgAI').value=map.ai;$('tgProfile').value=map.profile;$('tgWithdrawal').value=map.withdrawal;$('tgLevel').value=map.level;$('tgOther').value=map.other;$('tg').value=map.support;
      msg.className='telegram-control-msg ok';msg.textContent='✓ Saved · User links update live.';window.toast('Telegram control saved');
      try{await audit('Updated Telegram Control Center',{slots:Object.keys(map).join(',')})}catch(_){}
    }catch(e){msg.className='telegram-control-msg bad';msg.textContent='Save failed · '+(e?.message||e);window.toast('Telegram save failed','bad')}finally{setActionBusy(btn,false)}
  };

  $('saveSettings').onclick=async()=>{
    const btn=$('saveSettings');
    setActionBusy(btn,true,"Saving");
    try{
      const rateMap=[["Bronze",0],["Gold",1],["Platinum",2],["Master",3]],rates={};
      rateMap.forEach(([n,i])=>rates[n]=Number($('rate'+i).value)||0);
      const telegramDestinations={support:normalizeAdminSupport($('tgSupport').value.trim()),ai:normalizeAdminSupport($('tgAI').value.trim()),profile:normalizeAdminSupport($('tgProfile').value.trim()),withdrawal:normalizeAdminSupport($('tgWithdrawal').value.trim()),level:normalizeAdminSupport($('tgLevel').value.trim()),other:normalizeAdminSupport($('tgOther').value.trim())};
      const invalidTelegram=Object.entries(telegramDestinations).find(([k,v])=>String($({support:'tgSupport',ai:'tgAI',profile:'tgProfile',withdrawal:'tgWithdrawal',level:'tgLevel',other:'tgOther'}[k])?.value||'').trim() && !v);
      if(invalidTelegram)throw new Error('Invalid Telegram destination in '+invalidTelegram[0]+'. Use https://t.me/username, t.me/username, @username or a Telegram username.');
      const normalizedSupport=telegramDestinations.support;
      const payload={
        minWithdrawal:Number($('min').value)||899,
        withdrawalMethodLabel:$('wdLabel').value.trim(),
        telegramDestination:normalizedSupport,
        telegramDestinations,
        maintenanceMode:$('mm').value==='true',
        maintenanceTitle:$('maintenanceTitle').value.trim()||'App in maintenance mode',
        supportEmail:$('supportEmail').value.trim(),
        announcement:$('announcement').value.trim(),
        maintenanceMessage:$('maintenanceMessage').value.trim(),
        announcementEnabled:$('announceOn').value==='true',
        keyLifetimeValue:Math.max(1,Math.min($('keyUnit').value==='seconds'?86400:($('keyUnit').value==='minutes'?1440:168),Number($('keyLife').value)||24)),
        keyLifetimeUnit:$('keyUnit').value,
        keyLifetimeHours:$('keyUnit').value==='hours'?Math.max(1,Math.min(168,Number($('keyLife').value)||24)):1,
        oneTimeRedemption:$('oneTime').value==='true',
        defaultUserLevel:[0,2,3,5].includes(Number($('defaultLevel').value))?Number($('defaultLevel').value):0,
        maxKeysPerGeneration:Math.max(1,Math.min(100,Number($('maxKeys').value)||25)),
        rates,
        accentTheme:$('accentTheme').value,fontFamily:$('fontFamily').value,glassIntensity:$('glassIntensity').value,dashDensity:$('dashDensity').value,motionMode:$('motionMode').value,
        autoRefreshSeconds:Number($('autoRefresh').value)||0,landingPage:$('landingPage').value,confirmDanger:$('confirmDanger').value==='true',liveBadges:$('liveBadges').value==='true',
        sessionReminderMinutes:Number($('sessionReminder').value)||30,auditDetail:$('auditDetail').value,sensitiveHints:$('sensitiveHints').value==='true',
        registrationEnabled:$('registrationEnabled').value==='true',sellDataEnabled:$('sellDataEnabled').value==='true',withdrawalsEnabled:$('withdrawalsEnabled').value==='true',supportEnabled:$('supportEnabled').value==='true',
        notificationsEnabled:$('notificationsEnabled').value==='true',upgradesEnabled:$('upgradesEnabled').value==='true',
        dailyWithdrawalLimitPerUser:Math.max(0,Number($('dailyWithdrawalLimit').value)||0),dailyDataCapMB:Math.max(0,Number($('dailyDataCap').value)||0),
        maxPendingWithdrawalsPerUser:Math.max(1,Math.min(20,Number($('maxPendingWithdrawals').value)||1)),
        transactionCorrectionWindowHours:Math.max(0,Math.min(720,Number($('correctionWindow').value)||24)),
        privacyMode:$('privacyMode').value,
        freezeKeyIssuance:null,freezeWithdrawals:null,adminReadOnly:null,autoExpireSweep:null,strictActionAudit:null,requireActionNote:null,
        showTotalBalance:$('showTotalBalance').value==='true',showPendingWithdrawalBalance:$('showPendingWithdrawalBalance').value==='true',
        controlCenterRefreshSeconds:Math.max(5,Math.min(60,Number($('controlCenterRefresh').value)||10)),
        updatedAt:Date.now()
      };
      await update(ref(db,"settings"),payload);
      applyAppearanceSettings(payload);
      try{await audit("Updated app settings",{sections:"global,appearance,performance,safety"})}catch(e){console.warn("Audit failure after settings save",e)}
      $('sm').className='msg success';
      $('sm').textContent='✓ All settings saved successfully.';
      window.toast('Settings saved');
      // Immediately rebuild the Settings page from the saved data, keeping the view intact.
      await openSettings($("page"));
      setTimeout(addSectionBackButton,0);
      setTimeout(()=>{if($("sm")){$("sm").className='msg success';$("sm").textContent='✓ All settings saved successfully.'}},60);
    }catch(e){
      $('sm').className='msg error';
      $('sm').textContent='Save failed: '+(e?.message||e);
      window.toast('Settings save failed','bad');
      if(!$("page")?.innerHTML.trim())openSettings($("page"));
    }finally{
      setActionBusy(btn,false);
    }
  };

  $('resetSettings').onclick=async()=>{if(!confirm('Reset settings to safe defaults?'))return;const defaults={minWithdrawal:899,withdrawalMethodLabel:'UPI + Bank',telegramDestination:'',maintenanceMode:false,maintenanceTitle:'App in maintenance mode',supportEmail:'',announcement:'',maintenanceMessage:"We'll be back shortly.",announcementEnabled:true,keyLifetimeValue:24,keyLifetimeUnit:'hours',keyLifetimeHours:24,oneTimeRedemption:true,defaultUserLevel:0,maxKeysPerGeneration:25,rates:{Bronze:.10,Gold:.20,Platinum:.30,Master:.50},telegramDestinations:{support:'',ai:'',profile:'',withdrawal:'',level:'',other:''},telegramUpdatedAt:Date.now(),accentTheme:'emerald',glassIntensity:'balanced',dashDensity:'comfortable',motionMode:'full',autoRefreshSeconds:30,landingPage:'dashboard',confirmDanger:true,liveBadges:true,sessionReminderMinutes:30,auditDetail:'standard',sensitiveHints:true,registrationEnabled:true,sellDataEnabled:true,withdrawalsEnabled:true,supportEnabled:true,notificationsEnabled:true,upgradesEnabled:true,dailyWithdrawalLimitPerUser:0,dailyDataCapMB:0,maxPendingWithdrawalsPerUser:1,transactionCorrectionWindowHours:24,privacyMode:'standard',freezeKeyIssuance:null,freezeWithdrawals:null,adminReadOnly:null,autoExpireSweep:null,strictActionAudit:null,requireActionNote:null,showTotalBalance:true,showPendingWithdrawalBalance:true,controlCenterRefreshSeconds:10,updatedAt:Date.now()};try{await update(ref(db,'settings'),defaults);await audit('Reset app settings to defaults');await fill();$('sm').className='msg success';$('sm').textContent='✓ Defaults restored.'}catch(e){$('sm').className='msg error';$('sm').textContent='Reset failed: '+e.message}};
  $('exportSettings').onclick=async()=>{try{const s=await get(ref(db,'settings'));const blob=new Blob([JSON.stringify(s.val()||{},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='ADI_X_DATA_settings.json';a.click();URL.revokeObjectURL(url);window.toast('Config exported')}catch(e){window.toast('Export failed: '+e.message,'bad')}};
  $('resetUiState').onclick=()=>{try{sessionStorage.clear();localStorage.removeItem('adi_x_data_ui');window.toast('Local UI state reset')}catch(e){window.toast('Nothing to reset','bad')}};
}

async function showSecurityDiagnostics(){
  const box=$("securityDiagnostics");
  if(!box)return;
  const checks=[
    ["Admin authentication",async()=>{if(!isConfiguredAdmin())throw new Error("Signed-in email is not the authorised admin email.");return "OK"}],
    ["/settings",async()=>{await get(ref(db,"settings"));return "READ OK"}],
    ["/support",async()=>{await get(ref(db,"support"));return "READ OK"}],
    ["/supportArchive",async()=>{await get(ref(db,"supportArchive"));return "READ OK"}],
    ["/users",async()=>{await get(ref(db,"users"));return "READ OK"}],
    ["/levelKeys",async()=>{await get(ref(db,"levelKeys"));return "READ OK"}],
    ["/activationKeys",async()=>{await get(ref(db,"activationKeys"));return "READ OK"}],
    ["/publicLevelKeys",async()=>{await get(ref(db,"publicLevelKeys"));return "READ OK"}],
    ["/publicActivationKeys",async()=>{await get(ref(db,"publicActivationKeys"));return "READ OK"}],
    ["/publicTopSellers",async()=>{await get(ref(db,"publicTopSellers"));return "READ OK"}]
  ];
  box.innerHTML='<div class="notice">Running Firebase permission diagnostics…</div>';
  const rows=[];
  for(const [name,fn] of checks){
    try{const result=await fn();rows.push(`<div class="row"><span>${esc(name)}</span><strong style="color:#65f7b5">✓ ${esc(result)}</strong></div>`)}
    catch(e){const code=esc(e?.code||'ERROR');const msg=esc(e?.message||'Permission denied');rows.push(`<div class="row"><span>${esc(name)}</span><strong style="color:#ff9daf">✕ ${code}</strong><small class="muted">${msg}</small></div>`)}
  }
  box.innerHTML='<div class="card form-card"><h3>Firebase Permission Diagnostics</h3>'+rows.join('')+'</div>';
}

function openSecurity(el){
  el.innerHTML=`<div class="security-back-wrap"><button type="button" class="secondary section-back" id="securityBack"><span>←</span> Dashboard</button></div><div class="section-head"><div><span class="eyebrow">ADVANCED COMMAND</span><h2>Security Center</h2><p class="muted">Admin-only diagnostics for Firebase access and local session state.</p></div></div>
  <div class="security-command-strip"><span class="lux-command-badge">● ADMIN VERIFIED</span><span class="lux-command-badge">● RTDB PRIVATE</span><span class="lux-command-badge">● DESTRUCTIVE ACTIONS PROTECTED</span></div><div class="settings-grid">
   <div id="securityDiagnostics"></div>
   <div class="card form-card"><h3>🛡️ Access</h3><div class="notice success">Admin identity verified by the authenticated email session.</div><div class="mono">Expected admin: ${esc(ADMIN_EMAIL)}<br>Signed-in UID: ${esc(auth.currentUser?.uid||"—")}</div></div>
   <div class="card form-card"><h3>⚡ Database Health</h3><div id="healthResult" class="notice">Running safe read test…</div><button id="healthTest">Run test again</button></div>
   <div class="card form-card"><h3>🧹 Session Tools</h3><p class="muted">Clear only this browser's temporary UI state. Firebase records are not changed.</p><button class="secondary" id="clearUi">Reset local UI state</button></div><div class="card form-card"><h3>💾 Safety Backup</h3><p class="muted">Download a snapshot of the Admin database paths currently accessible to this session.</p><button class="secondary" id="downloadBackup">Download Backup</button></div>
  </div>`;
  $("securityBack").onclick=async()=>{if($('securityBack').dataset.busy==='1')return;$('securityBack').dataset.busy='1';activeSection=false;dashboardRenderToken++;await exitFullSection();await loadDashboard()};
  async function test(){const box=$("healthResult");box.textContent="Testing…";try{if(!isConfiguredAdmin())throw new Error("Admin account required.");await get(ref(db,"settings"));box.className="notice success";box.textContent="✓ Firebase Admin access is working."}catch(e){box.className="notice error";box.textContent="Firebase Admin test failed: "+(e?.code||"ERROR")+" · "+(e?.message||"Check the V3 Firebase Rules and Admin account.")}}
  showSecurityDiagnostics();$("healthTest").onclick=test;$("clearUi").onclick=()=>{try{sessionStorage.clear();localStorage.removeItem("adi_x_data_ui");window.toast("Local UI state reset")}catch(e){window.toast("Nothing to reset","bad")}};$("downloadBackup").onclick=async()=>{try{await ensureAdminSession();const paths=["settings","users","levelKeys","activationKeys","publicLevelKeys","publicActivationKeys","publicTopSellers","support","supportArchive","withdrawals","notifications","activity","auditLogs","deletedUsers","levelRedemptions","activationRedemptions","sellSessions","stats","telegram"];const entries={};for(const p of paths){try{entries[p]=(await get(ref(db,p))).val()??null}catch(e){entries[p]={error:e?.code||"DENIED"}}}downloadJson(`ADI_X_DATA_FULL_BACKUP_${Date.now()}.json`,{exportedAt:Date.now(),projectId:"data-x-pro-77",adminUid:auth.currentUser?.uid||null,data:entries});window.toast("Backup downloaded")}catch(e){window.toast("Backup failed: "+(e?.message||e),"bad")}};test();
}

function openAudit(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">SECURITY TRAIL</span><h2>Audit Log</h2><p class="muted">Review admin activity. Logs can be removed only after confirmation.</p></div><div class="toolbar"><button class="secondary" id="refreshAudit">↻ Refresh</button><button class="danger" id="deleteAudit">Delete Logs</button></div></div><div id="auditList">Loading…</div>`;
  $("refreshAudit").onclick=()=>withRefresh($("refreshAudit"),loadAuditOnce);$("deleteAudit").onclick=deleteAllAudit;loadAuditOnce();
}
async function loadAuditOnce(){await ensureAdminSession();try{const s=await get(ref(db,"auditLogs"));const rows=Object.entries(s.val()||{}).reverse();$("auditList").innerHTML=rows.slice(0,300).map(([id,a])=>`<article class="row audit-row"><span>${esc(a.action||"Action")}</span><span class="muted">${a.at?new Date(a.at).toLocaleString():""}</span><button class="danger tiny" data-audit-delete="${esc(id)}">×</button></article>`).join("")||"<div class='notice'>No entries.</div>";$("auditList").querySelectorAll('[data-audit-delete]').forEach(b=>b.onclick=async()=>{if(!confirm('Delete this audit entry permanently?'))return;try{await safeRemove(`auditLogs/${b.dataset.auditDelete}`);window.toast('Audit entry deleted permanently');await loadAuditOnce()}catch(e){window.toast('Delete failed: '+e.message,'bad')}})}catch(e){$("auditList").innerHTML=`<div class="notice error">${esc(e.message)}</div>`}}
async function deleteAllAudit(){if(!confirm('Delete ALL audit logs permanently? This cannot be undone.'))return;try{await safeRemove('auditLogs');window.toast('All audit logs deleted permanently');await loadAuditOnce()}catch(e){window.toast(e?.code==='PERMISSION_DENIED'?'Delete blocked by deployed Firebase Rules.':'Delete failed: '+e.message,'bad')}}

window.addEventListener("unhandledrejection",e=>{console.error(e.reason);window.toast(e?.reason?.code||"Something went wrong. Please try again.","bad")});
