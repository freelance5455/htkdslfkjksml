ADI X ADMIN DATA V37

Live Telegram Control Center with six dedicated destinations and a dedicated Save Telegram Control action. User app reads these destinations live from Firebase. Existing admin systems are preserved.
