ADI X DATA V29

Base: ADI X DATA V10 Permission Ultimate / V28.
Free-plan Delete User from App: creates a safety backup, removes the active DATA X PRO profile, sessions and support thread, records the deregistration event, and keeps the Firebase Authentication identity so the user can re-register with the SAME email + password and a NEW activation key.

No service-account private key is bundled in the client package.
