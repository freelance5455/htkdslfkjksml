ADI X DATA V32 — Admin Deep Withdrawal + Communication + Level Cleanup

Base: ADI X DATA V31 Withdrawal Search.

Changes:
- Withdrawal center rebuilt with deep details: Order ID, user, mobile/number, email, UID, method, amount, exact submitted/updated time including seconds, UPI ID, bank name, account name/number and IFSC.
- Copy buttons for UPI, number, account number, IFSC and other identifiers.
- Search now covers name, mobile/number, UPI, account number, IFSC, email, Order ID, UID, method, status and amount.
- Approve: atomically deducts the approved amount only when the withdrawal was not already balance-adjusted.
- Reject: requires a reason and stores it in statusMessage/reason/rejectionReason so the User app can show it.
- Reject & Return: requires a reason and, when the withdrawal had already been balance-adjusted, returns the amount to the user's balance exactly once.
- Every decision stores decisionAt / decisionBy and remains auditable.
- Communication now has six separate Telegram destinations: Main Support, AI Support, Profile Support, Withdrawal Support, Level Support, Other/Backup. Legacy telegramDestination remains as a fallback.
- Communication compartment is pinned to system font and is unaffected by Global UI Font changes.
- Removed Total Earned from Control Center; replaced by Total Paid Out.
- Active level system is Bronze, Gold, Platinum and Master. Silver and legacy Diamond rate entries are removed from the level-rate controls; legacy settings keys are cleaned on Settings load/save.
- User level editor now offers only the active levels.
- Existing Firebase project/config/rules remain unchanged.

Firebase project: data-x-pro-77
