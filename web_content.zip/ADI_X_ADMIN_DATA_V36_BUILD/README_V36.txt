ADI X ADMIN DATA V36

Balance reduction + mobile overflow/performance stabilization.
- Users → Edit User now has both Add Balance and Decrease Balance.
- Decrease Balance uses a Firebase transaction and intentionally allows the stored balance to become negative.
- Add and Decrease operations are separately audited.
- Existing balance is never overwritten by profile save.
- Global horizontal overflow is blocked so the admin UI no longer drags left/right into empty space on mobile.
- Mobile grids/flex children now use minmax(0,1fr)/min-width:0 guards to stop accidental width expansion.
- Heavy hover sheen/backdrop effects are disabled on touch screens while the premium visual system remains intact.
- Section navigation animation was shortened for faster response.
- Existing Firebase schema, key system, withdrawals, settings, Telegram destinations, maintenance/notifications and Admin-only branding are preserved.
