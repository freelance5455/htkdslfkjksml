ADI X DATA V30
- Withdrawal approval atomically deducts approved amount from users/{uid}/balance.
- Rejection leaves balance unchanged so the reserved amount becomes available again.
- Existing support, users, keys, top-seller and UI systems preserved.
