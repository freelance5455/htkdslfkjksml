ADI X ADMIN DATA V34

Withdrawal UI polish update.
- Removed browser window.prompt for Reject / Reject & Return reasons.
- Added premium in-app reason modal with textarea, validation, character count, cancel and submit.
- Withdrawal status capsules are premium state-aware: Approved/Completed/Paid = green, Rejected = red, Pending/Processing = amber.
- Detail status panel receives matching premium treatment.
- Existing Firebase schema and withdrawal decision logic preserved.
