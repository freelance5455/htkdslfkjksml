ADI X ADMIN DATA V35

User balance control + deep bug-fix pass.
- Restored a dedicated Add Balance control inside Users → Edit User.
- Add Balance uses a Firebase transaction, so it adds to the live balance without replacing or subtracting the existing value.
- Current balance is shown live in the editor and profile saves no longer overwrite the balance field.
- Added audit logging for balance top-ups.
- Preserved the V34 premium withdrawal reason modal, status capsules, withdrawal details/search, Telegram destinations, maintenance/notification settings, and key/level systems.
- Removed legacy UI/runtime prompt and Emergency Command Deck paths remain absent.
- Display branding/build metadata updated to ADI X ADMIN DATA V35.
