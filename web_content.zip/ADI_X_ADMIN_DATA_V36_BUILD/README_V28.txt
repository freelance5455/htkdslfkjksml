ADI X DATA V28 — FREE USER DEREGISTRATION

Delete User from App removes the active DATA X PRO profile and sell sessions after creating a safety backup. Firebase Authentication is intentionally retained so the same email/password can be used again with a new activation key.

No Cloud Functions or service-account key is required for this V28 flow.
