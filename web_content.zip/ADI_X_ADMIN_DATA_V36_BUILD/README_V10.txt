ADI X DATA V10
================
Base UI/app files are preserved from V9.

Main fix:
- Explicit parent-level read/write rules for users and support.
- Explicit parent-level permissions for all public catalogs.
- Full Admin UID access retained.
- Child rules retained for user-owned records.
- New Firebase project: data-x-pro-77.

IMPORTANT:
Publish FIREBASE_V10_MASTER_RULES.json in the live Realtime Database Rules editor.
No application code change is required for the permission issue shown in diagnostics.
