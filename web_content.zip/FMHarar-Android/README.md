# FM Harar 102.3 Rundown – Android app

Offline WebView app. The whole UI lives in `app/src/main/assets/index.html` (+ `logo.png`).

## Build the APK
**Android Studio:** File ▸ Open this folder ▸ wait for sync ▸ Build ▸ Build APK(s).
Output: `app/build/outputs/apk/debug/app-debug.apk`

**Command line** (JDK 17 + Android SDK, `ANDROID_HOME` set): `gradle assembleDebug`

**No PC setup:** push this folder to a GitHub repo; the *Build APK* action produces the APK under Actions ▸ Artifacts.

## Using the app
- ✎ Fooyyessi (top right): edit/add/delete/reorder rundown rows and programs; edit the About page.
- Changes are saved on the phone automatically. Use "Kuusaa" to share a backup file and "Backup deebisi" to restore.
