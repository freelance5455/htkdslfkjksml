const { httpServer, io } = require('../server');
const ioc = require('socket.io-client');
const assert = require('assert');
httpServer.listen(0, async () => {
  const url = 'http://localhost:' + httpServer.address().port;
  const mk = () => new Promise(r => { const s = ioc(url); s.on('connect', () => r(s)); });
  const once = (s, e) => new Promise(r => s.once(e, r));
  const [a, b, c, d, e, q] = await Promise.all([mk(), mk(), mk(), mk(), mk(), mk()]);
  a.emit('room:create', { name: 'Host', type: 'private' });
  const ja = await once(a, 'room:joined'); const code = ja.room.code;
  q.emit('room:quick', { name: 'Random' }); assert.strictEqual((await once(q, 'error:msg')).code, 'TIDAK_ADA_ROOM'); // private tak muncul
  b.emit('room:join', { name: 'Budi', code }); await once(b, 'room:joined');
  c.emit('room:join', { name: 'Cici', code }); await once(c, 'room:joined');
  d.emit('room:join', { name: 'Dodi', code }); await once(d, 'room:joined');
  e.emit('room:join', { name: 'Eko', code }); assert.strictEqual((await once(e, 'error:msg')).code, 'ROOM_PENUH');
  e.emit('room:join', { name: 'Eko', code: 'ZZZZZ' }); assert.strictEqual((await once(e, 'error:msg')).code, 'ROOM_TIDAK_DITEMUKAN');
  console.log('BERHASIL: semua tes lobby lulus'); process.exit(0);
});
