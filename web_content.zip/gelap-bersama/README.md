# GELAP BERSAMA - Server

## Jalankan lokal
    npm install
    cp .env.example .env   # opsional
    npm start              # http://localhost:3000/health
    npm test               # uji Room/Private/Quick Join/batas 4 pemain

## Deploy (skliffy atau hosting Node.js lain)
1. Unggah folder ini; perintah build: `npm install`, perintah start: `npm start`.
2. Set env `PORT` (jika tidak diberikan otomatis oleh hosting) dan `CORS_ORIGIN` ke domain client.
3. Pastikan hosting mendukung WebSocket dan HTTPS (WSS).
4. Cek `https://DOMAIN-ANDA/health` -> `{"ok":true}`.
5. Masukkan URL itu ke client (alamat server).

## Status
- BELUM DIUJI (tes ada di tests/, jalankan `npm test`): Room, Public/Private, Quick Join, batas 4, kode salah/penuh.
- Model: hantu Sunderbolong + karakter MC (low-poly dari kode), pratinjau di PENGATURAN. Karakter MC baru terlihat di multiplayer (BELUM DIIMPLEMENTASIKAN).
- Client: index.html (menu, nama, pengaturan, lobby multiplayer, Solo 3 map dengan menu PILIH MAP, 2-4 hantu, ambush/lunge, 15x serang, UI tanpa scroll: Rumah Sakit, Sekolah Angker, Rumah Angker; kontrol sentuh). BELUM DIUJI di browser. Three.js dimuat dari assets/three.min.js atau CDN cdnjs.
- BELUM DIIMPLEMENTASIKAN: basement dan lantai atas, sentuhan Android, gameplay multiplayer di client, AI hantu/pintu/item di server, knock/revive/spectator, reconnect, TURN.
- BELUM DIUJI: relay posisi, signaling suara, deploy di skliffy.

## Alamat server di client
- Tidak ada kolom alamat server di menu. Saat MULTIPLAYER dibuka, game menyambung otomatis.
- Jika game dibuka dari alamat server itu sendiri (https://domain-anda), alamat terdeteksi otomatis, tidak perlu setting.
- Jika game dibuka dari APK, alamat internal aplikasi (appassets.androidplatform.net) bukan server. Isi konstanta `DEFAULT_SERVER` di `index.html` satu kali dengan URL server, lalu bangun ulang APK.
- Di server, set `CORS_ORIGIN=*` untuk uji coba, atau `https://appassets.androidplatform.net` (+ domain web) untuk produksi. Tanpa ini koneksi dari APK ditolak.

## Latar menu
Gambar latar menu/lobby: `assets/images/lobby.jpg` (ganti file ini untuk mengubahnya, disarankan 1280x720 JPG di bawah 300 KB).

## Mengganti suara
Taruh file di `assets/audio/` (nama persis): `jumpscare.mp3` (suara jumpscare), `ambient.mp3` (musik latar, di-loop), `whisper.mp3` (bisikan acak). Jika file tidak ada, dipakai suara sintetis bawaan. Volume diatur di PENGATURAN.

## Map & misi
Denah tiap map dibuat prosedural dengan seed tetap (denah sama tiap main, lorong lebar 1 petak, ruangan besar, banyak pintu dan jalur alternatif). Misi acak tiap main: kunci 4, buku 5, kristal merah 8. Minimap hanya mengungkap area yang sudah dijelajahi.

## Mabar LAN (WiFi sama) dan Online (internet)
Menu MULTIPLAYER punya dua mode: ONLINE (INTERNET) dan LAN (WIFI SAMA). Keduanya memakai server yang sama (`server.js`); bedanya hanya di mana server dijalankan.
- **LAN:** jalankan server di satu PC/laptop di WiFi yang sama (`npm install` lalu `npm start`). Server menampilkan alamat seperti `http://192.168.1.5:3000`.
  - Cara paling andal: semua pemain membuka alamat itu di browser HP/PC. Game terbuka dan otomatis tersambung, tanpa setting.
  - Dari APK: pilih LAN, ketik IP server (mis. 192.168.1.5) lalu SAMBUNG, atau tekan CARI OTOMATIS.
  - Izinkan port 3000 di firewall PC (Windows biasanya menanyakan saat pertama jalan). HP dan PC harus di WiFi yang sama (hotspot HP host juga bisa).
- **Online:** deploy server ke hosting (lihat bagian deploy), isi `DEFAULT_SERVER` di `index.html`.
- Catatan: APK adalah halaman https, dan sebagian Android memblokir koneksi ke alamat http (LAN) dari halaman https. Jika terjadi, pakai cara browser di atas.
- Server tidak bisa dijalankan di dalam APK. Host LAN harus PC/laptop (atau HP yang menjalankan Node lewat Termux, belum diuji).

## Furnitur & tekstur
Dinding, lantai, pintu, dan furnitur memakai tekstur yang dibuat otomatis (tanpa file gambar). Rak berisi buku pajangan (buku misi ada di rak). Lemari bisa dibuka/ditutup (INTERAKSI), sebagian kunci/kristal tersembunyi di dalamnya. Ada juga kasur, meja, dan sofa sesuai tema map.

## Dua cara mabar
1. **LAN (HP HOST)**: seperti Minecraft. Satu HP jadi host (tanpa server), teman menyambung lewat kode salin-tempel. Satu HP menyalakan hotspot, HP lain menyambung ke hotspot itu.
   - Host: MULTIPLAYER > LAN (HP HOST) > JADI HOST > di lobby tekan TAMBAH TEMAN > kirim KODE lewat chat.
   - Teman: LAN (HP HOST) > GABUNG KE HOST > tempel kode > BUAT JAWABAN > kirim JAWABAN ke host.
   - Host tempel jawaban > SAMBUNGKAN. Ulangi per teman (maks 4 pemain).
   - Jika gagal tersambung, isi kolom "IP HP ini" di layar TAMBAH TEMAN (mis. 192.168.43.1, alamat umum HP yang menyalakan hotspot).
   - Kode dikirim lewat chat (butuh kuota/koneksi chat sebentar). Setelah tersambung, data game lewat langsung antar HP.
2. **ONLINE (SERVER)**: lewat server Node.js yang di-deploy (lihat bagian deploy). LAN (PC) = server yang dijalankan di PC di WiFi yang sama.

Sambungan WebRTC antar HP BELUM DIUJI di perangkat asli.

## Voice chat (ON MIC)
Di lobby ada tombol ON MIC: ketuk pertama menyalakan mikrofon (minta izin), ketuk lagi = MUTE. Suara dikirim langsung antar pemain (WebRTC), sinyal lewat server atau lewat host (LAN HP). Tanda 🔊 muncul di samping nama pemain yang sedang bicara (berdasarkan suara asli yang diterima).
- Butuh izin mikrofon dan halaman https (atau aplikasi APK dengan izin mikrofon). Di halaman http (mis. server PC di LAN) browser memblokir mikrofon.
- Mode ONLINE memakai STUN Google (butuh internet); tanpa server TURN, sebagian jaringan seluler mungkin gagal tersambung. LAN HP tanpa STUN.
- Push-to-talk, volume per pemain, dan suara berbasis jarak BELUM DIIMPLEMENTASIKAN. Mic hanya muncul di mode KODE 5 HURUF (online); di dalam map: tombol MIC (HP) atau tombol V (PC).

## Multiplayer di dalam map (host = otoritas)
Semua pemain masuk ke map yang sama. HP/PC host menjalankan hantu, pintu, item, serangan, knock, dan revive; tamu mengirim posisi dan aksi, host memvalidasi lalu menyiarkan hasilnya. Mode online memakai server hanya sebagai penerus paket (`net`), bukan otoritas. Artinya host yang curang atau koneksinya buruk memengaruhi semua pemain, dan jika host keluar permainan berhenti.
- Gagal melawan hantu (15x serang dalam 5 detik) = KNOCKED 60 detik. Teman menahan REVIVE (R / tombol) 5 detik di dekatnya. Waktu habis = pemain menjadi HANTU (lihat bagian Hantu pemain). Semua pemain knock/hantu = GAME OVER. Semua misi selesai + ada pemain mencapai exit = menang.
- Diuji lewat simulasi 3 pemain tanpa grafis (25 skenario). BELUM DIUJI di HP asli (jaringan nyata, performa, sambungan WebRTC).

## Kode 5 huruf vs tanpa internet
Kode 5 huruf butuh server yang menyimpannya (mode KODE 5 HURUF, lewat server/internet, termasuk untuk teman satu hotspot jika HP punya kuota). Tanpa internet tidak ada server, jadi sambungan HP-ke-HP memerlukan kode panjang (batas teknis aplikasi web).

## LAN dan online dengan kode 5 huruf yang sama
Host membuat Room, muncul kode 5 huruf; teman cukup mengetik 5 huruf itu. Server (skliffy) hanya dipakai untuk mempertemukan HP. Begitu permainan dimulai, host membuka jalur WebRTC langsung ke tiap teman dan semua data game (posisi, pintu, item, serangan) lewat jalur itu. Jika jalur langsung gagal atau putus, game otomatis memakai server sebagai cadangan. Pojok kiri bawah menampilkan LANGSUNG atau VIA SERVER.
- Teman satu hotspot memakai kuota HP host; tidak perlu kuota sendiri. Pairing butuh koneksi ke server sekali di awal; jika semua HP benar-benar tanpa internet, pakai mode TANPA INTERNET (kode panjang) karena tanpa server tidak ada tempat menyimpan kode pendek.
- Sambungan langsung antar HP BELUM DIUJI di perangkat asli (diuji dengan WebRTC tiruan). Sebagian jaringan menyembunyikan alamat lokal; jika begitu game tetap jalan lewat server.

## Hantu pemain
Pemain yang KNOCKED 60 detik tanpa di-REVIVE menjadi hantu yang dimainkan. Tombol: SUARA (Q) memainkan suara seram acak yang terdengar semua pemain (makin jauh makin pelan, jeda 4 dtk), TIKAM (F / klik) menyerang teman yang terlihat di depan dalam 3,5 m (korban harus menekan SERANG 15x dalam 5 dtk; jeda 8 dtk; hantu terkunci selama menikam dan pingsan 6 dtk jika korban menang), TELEPORT (T) pindah ke titik acak di map (jeda 15 dtk). Di minimap hantu merah dan tidak melihat titik hijau teman. Semua knock/hantu = GAME OVER ("HANTU MENANG!" untuk hantu).
Suara seram bisa diganti: taruh `assets/audio/ghost1.mp3` ... `ghost6.mp3` (maks 6; jika tidak ada dipakai suara bawaan).

## Pilihan map di lobby
Map dipilih lewat tiga tombol (RUMAH SAKIT / SEKOLAH / RUMAH ANGKER); hanya host yang bisa menekannya.
