# GELAP BERSAMA - Server

## Jalankan lokal
    npm install
    cp .env.example .env   # opsional
    npm start              # http://localhost:3000/health
    npm test               # uji Room/Private/Quick Join/batas 4 pemain

## Deploy (skliffy atau hosting Node.js lain)
1. Unggah folder ini; perintah build: `npm install`, perintah start: `npm start`.
2. Set env `PORT` (jika tidak diberikan otomatis oleh hosting) dan `CORS_ORIGIN` ke domain client.
3. Pastikan hosting mendukung WebSocket dan HTTPS (WSS).
4. Cek `https://DOMAIN-ANDA/health` -> `{"ok":true}`.
5. Masukkan URL itu ke client (alamat server).

## Status
- BELUM DIUJI (tes ada di tests/, jalankan `npm test`): Room, Public/Private, Quick Join, batas 4, kode salah/penuh.
- Model: hantu Sunderbolong + karakter MC (low-poly dari kode), pratinjau di PENGATURAN. Karakter MC baru terlihat di multiplayer (BELUM DIIMPLEMENTASIKAN).
- Client: index.html (menu, nama, pengaturan, lobby multiplayer, Solo 3 map dengan menu PILIH MAP, 2-4 hantu, ambush/lunge, 15x serang, UI tanpa scroll: Rumah Sakit, Sekolah Angker, Rumah Angker; kontrol sentuh). BELUM DIUJI di browser. Three.js dimuat dari assets/three.min.js atau CDN cdnjs.
- BELUM DIIMPLEMENTASIKAN: basement dan lantai atas, sentuhan Android, gameplay multiplayer di client, AI hantu/pintu/item di server, knock/revive/spectator, reconnect, TURN.
- BELUM DIUJI: relay posisi, signaling suara, deploy di skliffy.

## Alamat server di client
- Tidak ada kolom alamat server di menu. Saat MULTIPLAYER dibuka, game menyambung otomatis.
- Jika game dibuka dari alamat server itu sendiri (https://domain-anda), alamat terdeteksi otomatis, tidak perlu setting.
- Jika game dibuka dari APK, alamat internal aplikasi (appassets.androidplatform.net) bukan server. Isi konstanta `DEFAULT_SERVER` di `index.html` satu kali dengan URL server, lalu bangun ulang APK.
- Di server, set `CORS_ORIGIN=*` untuk uji coba, atau `https://appassets.androidplatform.net` (+ domain web) untuk produksi. Tanpa ini koneksi dari APK ditolak.

## Latar menu
Gambar latar menu/lobby: `assets/images/lobby.jpg` (ganti file ini untuk mengubahnya, disarankan 1280x720 JPG di bawah 300 KB).

## Mengganti suara
Taruh file di `assets/audio/` (nama persis): `jumpscare.mp3` (suara jumpscare), `ambient.mp3` (musik latar, di-loop), `whisper.mp3` (bisikan acak). Jika file tidak ada, dipakai suara sintetis bawaan. Volume diatur di PENGATURAN.

## Map & misi
Denah tiap map dibuat prosedural dengan seed tetap (denah sama tiap main, lorong lebar 1 petak, ruangan besar, banyak pintu dan jalur alternatif). Misi acak tiap main: kunci 4, buku 5, kristal merah 8. Minimap hanya mengungkap area yang sudah dijelajahi.

## Mabar LAN (WiFi sama) dan Online (internet)
Menu MULTIPLAYER punya dua mode: ONLINE (INTERNET) dan LAN (WIFI SAMA). Keduanya memakai server yang sama (`server.js`); bedanya hanya di mana server dijalankan.
- **LAN:** jalankan server di satu PC/laptop di WiFi yang sama (`npm install` lalu `npm start`). Server menampilkan alamat seperti `http://192.168.1.5:3000`.
  - Cara paling andal: semua pemain membuka alamat itu di browser HP/PC. Game terbuka dan otomatis tersambung, tanpa setting.
  - Dari APK: pilih LAN, ketik IP server (mis. 192.168.1.5) lalu SAMBUNG, atau tekan CARI OTOMATIS.
  - Izinkan port 3000 di firewall PC (Windows biasanya menanyakan saat pertama jalan). HP dan PC harus di WiFi yang sama (hotspot HP host juga bisa).
- **Online:** deploy server ke hosting (lihat bagian deploy), isi `DEFAULT_SERVER` di `index.html`.
- Catatan: APK adalah halaman https, dan sebagian Android memblokir koneksi ke alamat http (LAN) dari halaman https. Jika terjadi, pakai cara browser di atas.
- Server tidak bisa dijalankan di dalam APK. Host LAN harus PC/laptop (atau HP yang menjalankan Node lewat Termux, belum diuji).

## Furnitur & tekstur
Dinding, lantai, pintu, dan furnitur memakai tekstur yang dibuat otomatis (tanpa file gambar). Rak berisi buku pajangan (buku misi ada di rak). Lemari bisa dibuka/ditutup (INTERAKSI), sebagian kunci/kristal tersembunyi di dalamnya. Ada juga kasur, meja, dan sofa sesuai tema map.
