'use strict';
// GELAP BERSAMA - server multiplayer (lobby/room). Gameplay otoritatif: BELUM DIIMPLEMENTASIKAN.
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Server } = require('socket.io');

const PORT = process.env.PORT || 3000;
const ORIGINS = (process.env.CORS_ORIGIN || '*').split(',').map(s => s.trim());
const MAX_PLAYERS = 4;
const MAPS = ['rumah_sakit', 'sekolah', 'rumah_angker'];
const NAME_RE = /^[A-Za-z0-9 _\-.]{3,16}$/;
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript', '.css': 'text/css', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav', '.json': 'application/json' };
const httpServer = http.createServer((req, res) => {
  let url = '/';
  try { url = decodeURIComponent((req.url || '/').split('?')[0]); } catch (e) { res.writeHead(400); return res.end(); }
  if (url === '/health') { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end('{"ok":true}'); }
  if (url === '/') url = '/index.html';
  url = path.posix.normalize(url); // selesaikan '..' dulu, baru periksa
  // hanya sajikan index.html dan folder assets/ (server.js, .env, dll tidak ikut terbuka)
  if (url !== '/index.html' && !url.startsWith('/assets/')) { res.writeHead(404); return res.end('Tidak ditemukan'); }
  const file = path.join(__dirname, path.normalize(url));
  if (!file.startsWith(path.join(__dirname, path.sep))) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (e, d) => {
    if (e) { res.writeHead(404); return res.end('Tidak ditemukan'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
    res.end(d);
  });
});
const io = new Server(httpServer, { cors: { origin: ORIGINS.includes('*') ? '*' : ORIGINS } });

const rooms = new Map(); // code -> room

function genCode() {
  let c;
  do { c = Array.from({ length: 5 }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join(''); } while (rooms.has(c));
  return c;
}
function cleanName(n) {
  if (typeof n !== 'string') return null;
  n = n.trim().replace(/\s+/g, ' ');
  return NAME_RE.test(n) ? n : null;
}
function uniqueName(room, name) {
  const taken = new Set([...room.players.values()].map(p => p.name.toLowerCase()));
  let n = name, i = 2;
  while (taken.has(n.toLowerCase())) n = (name.slice(0, 13) + '#' + i++);
  return n;
}
function roomView(r) {
  return {
    code: r.code, type: r.type, map: r.map, started: r.started, hostId: r.hostId,
    players: [...r.players.values()].map(p => ({ id: p.id, name: p.name, ready: p.ready }))
  };
}
function joinable(r) { return !r.started && r.players.size < MAX_PLAYERS; }
function broadcast(r) { io.to(r.code).emit('room:update', roomView(r)); }

function leave(socket) {
  const code = socket.data.room;
  if (!code) return;
  const r = rooms.get(code);
  socket.leave(code); socket.data.room = null;
  if (!r) return;
  r.players.delete(socket.id);
  if (r.players.size === 0) { rooms.delete(code); return; }
  if (r.hostId === socket.id) { r.hostId = r.players.keys().next().value; io.to(r.hostId).emit('room:host', { you: true }); }
  io.to(code).emit('player:left', { id: socket.id });
  broadcast(r);
}
function enter(socket, r, name) {
  r.players.set(socket.id, { id: socket.id, name: uniqueName(r, name), ready: false, lastMsg: 0, state: null });
  socket.join(r.code); socket.data.room = r.code;
  socket.emit('room:joined', { room: roomView(r), you: socket.id });
  broadcast(r);
}

// Pembatas laju sederhana per socket
function rate(socket, key, ms) {
  const now = Date.now(); socket.data.rl = socket.data.rl || {};
  if (now - (socket.data.rl[key] || 0) < ms) return false;
  socket.data.rl[key] = now; return true;
}

io.on('connection', socket => {
  const err = (code, msg) => socket.emit('error:msg', { code, msg });

  socket.on('room:create', ({ name, type } = {}, ack) => {
    if (!rate(socket, 'create', 1000)) return err('SPAM', 'Terlalu cepat.');
    name = cleanName(name); if (!name) return err('NAMA_INVALID', 'Nama harus 3-16 karakter (huruf, angka, spasi, _ - .).');
    if (socket.data.room) leave(socket);
    const r = { code: genCode(), type: type === 'private' ? 'private' : 'public', map: MAPS[0], started: false, hostId: socket.id, players: new Map(), last: Date.now() };
    rooms.set(r.code, r); enter(socket, r, name);
  });

  socket.on('room:join', ({ name, code } = {}) => {
    if (!rate(socket, 'join', 500)) return err('SPAM', 'Terlalu cepat.');
    name = cleanName(name); if (!name) return err('NAMA_INVALID', 'Nama tidak valid.');
    code = String(code || '').toUpperCase().trim();
    if (!/^[A-Z0-9]{5}$/.test(code)) return err('KODE_SALAH', 'KODE SALAH');
    const r = rooms.get(code);
    if (!r) return err('ROOM_TIDAK_DITEMUKAN', 'ROOM TIDAK DITEMUKAN');
    if (r.started) return err('SUDAH_MULAI', 'PERMAINAN SUDAH DIMULAI');
    if (r.players.size >= MAX_PLAYERS) return err('ROOM_PENUH', 'ROOM PENUH');
    if (socket.data.room) leave(socket);
    enter(socket, r, name);
  });

  socket.on('room:quick', ({ name } = {}) => {
    if (!rate(socket, 'quick', 500)) return err('SPAM', 'Terlalu cepat.');
    name = cleanName(name); if (!name) return err('NAMA_INVALID', 'Nama tidak valid.');
    const r = [...rooms.values()].filter(x => x.type === 'public' && joinable(x)).sort((a, b) => b.players.size - a.players.size)[0];
    if (!r) return err('TIDAK_ADA_ROOM', 'TIDAK ADA ROOM PUBLIK');
    if (socket.data.room) leave(socket);
    enter(socket, r, name); // sinkron di satu event-loop tick: aman dari race kapasitas
  });

  socket.on('room:map', ({ map } = {}) => {
    const r = rooms.get(socket.data.room); if (!r) return;
    if (r.hostId !== socket.id) return err('BUKAN_HOST', 'Hanya host.');
    if (r.started || !MAPS.includes(map)) return err('MAP_INVALID', 'Map tidak valid.');
    r.map = map; broadcast(r);
  });

  socket.on('room:ready', ({ ready } = {}) => {
    const r = rooms.get(socket.data.room); const p = r && r.players.get(socket.id); if (!p) return;
    p.ready = !!ready; broadcast(r);
  });

  socket.on('room:start', () => {
    const r = rooms.get(socket.data.room); if (!r) return;
    if (r.hostId !== socket.id) return err('BUKAN_HOST', 'Hanya host yang bisa memulai.');
    if (r.started) return;
    r.started = true;
    io.to(r.code).emit('game:start', { map: r.map, players: roomView(r).players }); // semua pakai map yang sama
    broadcast(r);
  });

  // Relay posisi pemain (validasi dasar saja; belum anti-cheat penuh)
  socket.on('player:state', s => {
    const r = rooms.get(socket.data.room); const p = r && r.players.get(socket.id);
    if (!p || !r.started || !s || !rate(socket, 'st', 40)) return;
    const n = v => (typeof v === 'number' && isFinite(v) && Math.abs(v) < 1e4) ? v : 0;
    p.state = { x: n(s.x), y: n(s.y), z: n(s.z), ry: n(s.ry), anim: String(s.anim || 'idle').slice(0, 12) };
    socket.to(r.code).emit('player:state', { id: socket.id, ...p.state });
  });

  // Signaling WebRTC (hanya antar anggota room yang sama)
  socket.on('voice:signal', ({ to, data } = {}) => {
    const r = rooms.get(socket.data.room);
    if (!r || !r.players.has(to) || !rate(socket, 'vs', 10)) return;
    io.to(to).emit('voice:signal', { from: socket.id, data });
  });

  socket.on('room:leave', () => leave(socket));
  socket.on('disconnect', () => leave(socket));
});

setInterval(() => { // bersihkan room kosong/usang
  for (const [c, r] of rooms) if (r.players.size === 0) rooms.delete(c);
}, 60000);

function lanIPs() {
  const r = [];
  for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) if (a.family === 'IPv4' && !a.internal) r.push(a.address);
  return r;
}
if (require.main === module) {
  httpServer.listen(PORT, () => {
    console.log(`GELAP BERSAMA server di port ${PORT}`);
    const ips = lanIPs();
    if (ips.length) {
      console.log('Mabar LAN (HP/PC di WiFi yang sama): buka salah satu alamat ini di browser, atau masukkan IP-nya di menu LAN:');
      ips.forEach(ip => console.log(`  http://${ip}:${PORT}`));
    }
  });
}
module.exports = { httpServer, io, rooms };
