'use strict';
/* ============ ابزارهای پایه ============ */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const toEn=s=>String(s??'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[٬,،\s]/g,'').replace(/[٫]/g,'.');
const num=n=>Number(n||0).toLocaleString('fa-IR');
const money=n=>num(Math.round(n||0))+' تومان';
const kgf=m=>((m||0)/1000).toLocaleString('fa-IR',{minimumFractionDigits:3,maximumFractionDigits:3});
const WU='کیلوگرم';
const qtyf=(m,u)=>u===WU?kgf(m)+' کیلو':((m||0)/1000).toLocaleString('fa-IR',{maximumFractionDigits:3})+' '+(u||'');
const pMoney=s=>{const v=Number(toEn(s));return Number.isFinite(v)?Math.round(v):NaN};
const pQty=s=>{const v=Number(toEn(s));return Number.isFinite(v)?Math.round(v*1000):NaN};
const E=(m,code)=>{const e=new Error(m);e.code=code;return e};
let _uid=0;const uid=()=>Date.now().toString(36)+(++_uid).toString(36)+Math.random().toString(36).slice(2,7);
const clone=o=>structuredClone(o);
const sum=(a,f)=>a.reduce((s,x)=>s+(f?f(x):x),0);

/* ============ تاریخ شمسی ============ */
const D=(()=>{
 const div=(a,b)=>~~(a/b),mod=(a,b)=>a-~~(a/b)*b;
 const br=[-61,9,38,199,426,686,756,818,1111,1181,1210,1635,2060,2097,2192,2262,2324,2394,2456,3178];
 function jalCal(jy,wl){const bl=br.length,gy=jy+621;let leapJ=-14,jp=br[0],jm,jump=0,leap,i;
  if(jy<jp||jy>=br[bl-1])throw E('سال خارج از محدوده');
  for(i=1;i<bl;i++){jm=br[i];jump=jm-jp;if(jy<jm)break;leapJ+=div(jump,33)*8+div(mod(jump,33),4);jp=jm}
  let n=jy-jp;leapJ+=div(n,33)*8+div(mod(n,33)+3,4);if(mod(jump,33)===4&&jump-n===4)leapJ++;
  const leapG=div(gy,4)-div((div(gy,100)+1)*3,4)-150,march=20+leapJ-leapG;
  if(wl)return{gy,march};
  if(jump-n<6)n=n-jump+div(jump+4,33)*33;
  leap=mod(mod(n+1,33)-1,4);if(leap===-1)leap=4;return{leap,gy,march}}
 const g2d=(gy,gm,gd)=>{let d=div((gy+div(gm-8,6)+100100)*1461,4)+div(153*mod(gm+9,12)+2,5)+gd-34840408;return d-div(div(gy+100100+div(gm-8,6),100)*3,4)+752};
 const d2g=jdn=>{let j=4*jdn+139361631;j+=div(div(4*jdn+183187720,146097)*3,4)*4-3908;const i=div(mod(j,1461),4)*5+308;const gd=div(mod(i,153),5)+1,gm=mod(div(i,153),12)+1;return{gy:div(j,1461)-100100+div(8-gm,6),gm,gd}};
 const j2d=(jy,jm,jd)=>{const r=jalCal(jy,true);return g2d(r.gy,3,r.march)+(jm-1)*31-div(jm,7)*(jm-7)+jd-1};
 const d2j=jdn=>{const gy=d2g(jdn).gy;let jy=gy-621;const r=jalCal(jy,false),f=g2d(gy,3,r.march);let k=jdn-f,jm,jd;
  if(k>=0){if(k<=185){return{jy,jm:1+div(k,31),jd:mod(k,31)+1}}k-=186}else{jy--;k+=179;if(r.leap===1)k++}
  jm=7+div(k,30);jd=mod(k,30)+1;return{jy,jm,jd}};
 const isLeap=y=>jalCal(y).leap===0;
 const mdays=(y,m)=>m<=6?31:m<=11?30:(isLeap(y)?30:29);
 const MN=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
 const WD=['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];
 const ok=(y,m,d)=>Number.isInteger(y)&&Number.isInteger(m)&&Number.isInteger(d)&&y>=1300&&y<=1500&&m>=1&&m<=12&&d>=1&&d<=mdays(y,m);
 const make=(y,m,d)=>{y=+y;m=+m;d=+d;if(!ok(y,m,d))throw E('تاریخ نامعتبر است: '+y+'/'+m+'/'+d);return{y,m,d,j:j2d(y,m,d)}};
 const fromJ=j=>{const r=d2j(j);return{y:r.jy,m:r.jm,d:r.jd,j}};
 const todayJ=()=>{const n=new Date();return g2d(n.getFullYear(),n.getMonth()+1,n.getDate())};
 const today=()=>fromJ(todayJ());
 const p2=n=>String(n).padStart(2,'0');
 const fmt=dt=>dt?num(dt.y).replace(/٬/g,'')+'/'+num(p2(dt.m)).replace(/٬/g,'')+'/'+num(p2(dt.d)).replace(/٬/g,''):'—';
 const fa2=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
 const fmtD=dt=>dt?fa2(dt.y)+'/'+fa2(p2(dt.m))+'/'+fa2(p2(dt.d)):'—';
 const en=dt=>dt?dt.y+'/'+p2(dt.m)+'/'+p2(dt.d):'';
 const toJS=(dt,h=0,mi=0)=>{const g=d2g(dt.j);return new Date(g.gy,g.gm-1,g.gd,h,mi,0,0)};
 const fromJS=t=>{const n=new Date(t);return fromJ(g2d(n.getFullYear(),n.getMonth()+1,n.getDate()))};
 const wd=j=>WD[mod(j+2,7)]; // JDN: شنبه
 const addM=(dt,k)=>{let t=dt.y*12+dt.m-1+k;const y=div(t,12),m=t%12+1;return make(y,m,Math.min(dt.d,mdays(y,m)))};
 const firstOfMonth=dt=>make(dt.y,dt.m,1);
 return{ok,make,fromJ,today,todayJ,fmt:fmtD,en,toJS,fromJS,mdays,isLeap,MN,wd,addM,j2d,d2j,g2d,d2g,firstOfMonth,fa2,p2,mn:m=>MN[m-1]}})();
const fd=D.fmt;

/* ============ SHA-256 (برای رمز عبور) ============ */
function sha256(str){
 const mp=Math.pow,mw=mp(2,32);let i,j,res='';const w=[];const asc=unescape(encodeURIComponent(str));const L=asc.length*8;
 const H=sha256.h=sha256.h||[],K=sha256.k=sha256.k||[];let pc=K.length;const ic={};
 for(let c=2;pc<64;c++){if(!ic[c]){for(i=0;i<313;i+=c)ic[i]=c;H[pc]=(mp(c,.5)*mw)|0;K[pc++]=(mp(c,1/3)*mw)|0}}
 let hh=H.slice(0,8);let s=asc+'\x80';while(s.length%64-56)s+='\x00';
 for(i=0;i<s.length;i++){j=s.charCodeAt(i);w[i>>2]|=j<<((3-i)%4)*8}
 w[w.length]=(L/mw)|0;w[w.length]=L;
 for(j=0;j<w.length;){const W=w.slice(j,j+=16),old=hh;hh=hh.slice(0,8);
  for(i=0;i<64;i++){const w15=W[i-15],w2=W[i-2],a=hh[0],e=hh[4];
   const t1=hh[7]+(((e>>>6)|(e<<26))^((e>>>11)|(e<<21))^((e>>>25)|(e<<7)))+((e&hh[5])^(~e&hh[6]))+K[i]+(W[i]=i<16?W[i]:(W[i-16]+(((w15>>>7)|(w15<<25))^((w15>>>18)|(w15<<14))^(w15>>>3))+W[i-7]+(((w2>>>17)|(w2<<15))^((w2>>>19)|(w2<<13))^(w2>>>10)))|0);
   const t2=(((a>>>2)|(a<<30))^((a>>>13)|(a<<19))^((a>>>22)|(a<<10)))+((a&hh[1])^(a&hh[2])^(hh[1]&hh[2]));
   hh=[(t1+t2)|0].concat(hh);hh[4]=(hh[4]+t1)|0}
  for(i=0;i<8;i++)hh[i]=(hh[i]+old[i])|0}
 for(i=0;i<8;i++)for(j=3;j+1;j--){const b=(hh[i]>>(j*8))&255;res+=(b<16?'0':'')+b.toString(16)}
 return res}
const hashPw=(pw,salt)=>{let h=pw+salt;for(let i=0;i<500;i++)h=sha256(h+salt);return h};

/* ============ پایگاه داده IndexedDB ============ */
const STORES=['customers','products','categories','sales','payments','loans','loanPayments','checks','checkReminders','inventory','suppliers','users','ledger','expenses','settings','audit','purchases','notifications'];
const DB={db:null,M:{},memo:{},
 open(){return new Promise((res,rej)=>{if(!window.indexedDB)return rej(E('مرورگر از IndexedDB پشتیبانی نمی‌کند'));
  const rq=indexedDB.open('hafez_meat_accounting',1);
  rq.onupgradeneeded=()=>{STORES.forEach(s=>{if(!rq.result.objectStoreNames.contains(s))rq.result.createObjectStore(s,{keyPath:'id'})})};
  rq.onsuccess=()=>{this.db=rq.result;res()};rq.onerror=()=>rej(rq.error)})},
 loadAll(){return new Promise((res,rej)=>{const tx=this.db.transaction(STORES,'readonly');STORES.forEach(s=>{this.M[s]=new Map();const r=tx.objectStore(s).getAll();r.onsuccess=()=>r.result.forEach(x=>this.M[s].set(x.id,x))});tx.oncomplete=()=>{this.memo={};res()};tx.onerror=()=>rej(tx.error)})},
 commit(ops){return new Promise((res,rej)=>{if(!ops.length)return res();
  const names=[...new Set(ops.map(o=>o.s))];const tx=this.db.transaction(names,'readwrite');
  ops.forEach(o=>{const st=tx.objectStore(o.s);if(o.del!==undefined)st.delete(o.del);else st.put(o.put)});
  tx.oncomplete=()=>{ops.forEach(o=>{if(o.del!==undefined)this.M[o.s].delete(o.del);else this.M[o.s].set(o.put.id,o.put)});this.memo={};res()};
  tx.onabort=tx.onerror=()=>rej(tx.error||E('خطا در ذخیره‌سازی اطلاعات'))})},
 replaceAll(data){return new Promise((res,rej)=>{const tx=this.db.transaction(STORES,'readwrite');
  STORES.forEach(s=>{const st=tx.objectStore(s);st.clear();(data[s]||[]).forEach(r=>st.put(r))});
  tx.oncomplete=()=>this.loadAll().then(res,rej);tx.onabort=tx.onerror=()=>rej(tx.error||E('بازیابی ناموفق بود'))})}};
const memo=(k,f)=>{if(!(k in DB.memo))DB.memo[k]=f();return DB.memo[k]};
const L=s=>memo('L:'+s,()=>[...DB.M[s].values()]);
const G=(s,id)=>DB.M[s]?.get(id);
const A={user:null};
const PERMS={dashboard:'داشبورد',daily:'فروش روزانه (مشتری گذری)',sale:'ثبت فروش',invoices:'فاکتورها',products:'مدیریت کالاها',inventory:'مدیریت انبار',customers:'مشتریان',ledger:'دفتر حساب',loans:'قرض و بدهی',payments:'پرداخت‌ها',checks:'چک‌ها',notifs:'یادآوری‌ها',suppliers:'تأمین‌کنندگان',reports:'گزارش‌های مالی',users:'کاربران',settings:'تنظیمات',backup:'پشتیبان‌گیری',edit_sale:'ویرایش فاکتور',cancel_sale:'ابطال فاکتور/اسناد',neg_stock:'مجوز موجودی منفی',price_edit:'تغییر قیمت کالا'};
const ROLES={admin:{n:'مدیر',p:Object.keys(PERMS)},seller:{n:'فروشنده',p:['dashboard','daily','sale','invoices','customers','ledger','payments','products','suppliers','inventory','notifs']},accountant:{n:'حسابدار',p:['dashboard','daily','sale','invoices','customers','ledger','loans','payments','checks','notifs','suppliers','reports','edit_sale','cancel_sale','products','inventory']}};
const can=p=>A.user&&(A.user.role==='admin'||(A.user.perms||[]).includes(p));
const need=p=>{if(!can(p))throw E('شما دسترسی لازم برای این عملیات را ندارید.')};

/* ============ تنظیمات و شمارنده‌ها ============ */
const DEF_SET={shop:'سوپر گوشت حافظ',phone:'',address:'',allowNegative:false,nearDays:7,notifyTime:'09:00',remEnabled:true,backupRemind:true,thermal:80,lastBackup:0,loanRemind:true,logo:''};
const SET=()=>({...DEF_SET,...(G('settings','main')?.v||{})});
function setOp(ops,patch){let o=ops.find(x=>x.s==='settings'&&x.put?.id==='main');if(!o){o={s:'settings',put:{id:'main',v:{...SET()}}};ops.push(o)}Object.assign(o.put.v,patch)}
const START={sale:1000,pay:1000,loan:1000,check:1000,purch:1000,cust:100,prod:100,exp:1000,doc:1000},PRE={sale:'F-',pay:'P-',loan:'L-',check:'C-',purch:'B-',cust:'M-',prod:'K-',exp:'E-',doc:'S-'};
function nextNo(ops,kind){let o=ops.find(x=>x.s==='settings'&&x.put?.id==='counters');if(!o){o={s:'settings',put:clone(G('settings','counters')||{id:'counters',v:{}})};ops.push(o)}
 const n=(o.put.v[kind]||START[kind])+1;o.put.v[kind]=n;return PRE[kind]+n}
function audit(ops,action,entity,eid,details){ops.push({s:'audit',put:{id:uid(),ts:Date.now(),userId:A.user?.id,userName:A.user?.name||'سیستم',action,entity,entityId:eid,details:details||''}})}
const getOp=(ops,s,id)=>{let o=ops.find(x=>x.s===s&&x.put?.id===id);if(!o){const r=G(s,id);if(!r)return null;o={s,put:clone(r)};ops.push(o)}return o.put};

/* ============ موتور انبار ============ */
const stockMap=()=>memo('stock',()=>{const m=new Map();for(const v of L('inventory'))m.set(v.productId,(m.get(v.productId)||0)+v.qty);return m});
const stockOf=pid=>stockMap().get(pid)||0;
const pendStock=(ops,pid)=>stockOf(pid)+sum(ops.filter(o=>o.s==='inventory'&&o.put?.productId===pid),o=>o.put.qty);
const OUT_TYPES={sale:'فروش',sale_edit:'اصلاح فاکتور',waste:'ضایعات',out:'خروج دستی',adjust:'اصلاح موجودی',sale_return:'برگشت از فروش',purchase:'خرید',initial:'موجودی اولیه','in':'ورود دستی'};
function moveOps(ops,m){ // m:{productId,type,qty(signed milli),unitCost,date,refType,refId,note}
 const p=getOp(ops,'products',m.productId);if(!p)throw E('کالا یافت نشد');
 const st=pendStock(ops,m.productId);
 let cost=m.unitCost;
 if(m.qty<0)cost=p.avgCost||0;
 else{ if(cost==null)cost=p.avgCost||0;
  p.avgCost=st>0?Math.round((st*(p.avgCost||0)+m.qty*cost)/(st+m.qty)):cost}
 ops.push({s:'inventory',put:{id:uid(),productId:m.productId,type:m.type,qty:m.qty,unitCost:cost,date:m.date,ts:Date.now(),refType:m.refType||null,refId:m.refId||null,note:m.note||'',userId:A.user?.id}});
 return cost}
const stockValue=()=>sum(L('products'),p=>Math.max(0,stockOf(p.id))*(p.avgCost||0)/1000);

/* ============ دفتر حساب ============ */
const ledgerIdx=()=>memo('ledgerIdx',()=>{const m=new Map();for(const e of L('ledger')){if(!m.has(e.customerId))m.set(e.customerId,[]);m.get(e.customerId).push(e)}
 m.forEach(a=>a.sort((x,y)=>x.date.j-y.date.j||x.ts-y.ts));return m});
const ledgerOf=cid=>ledgerIdx().get(cid)||[];
function custBal(cid){let R=0,P=0;const sub={sale:0,loan:0,gen:0};for(const e of ledgerOf(cid)){if(e.acct==='R'){const v=e.debit-e.credit;R+=v;sub[e.sub||'gen']+=v}else P+=e.credit-e.debit}return{R,P,sub}}
function ledgerAdd(ops,o){ops.push({s:'ledger',put:{id:uid(),ts:Date.now(),customerId:o.customerId,acct:o.acct,sub:o.sub||'gen',date:o.date,desc:o.desc,debit:o.debit||0,credit:o.credit||0,docNo:o.docNo,method:o.method||'',refType:o.refType,refId:o.refId,kind:o.kind||o.refType,reverses:o.reverses||null,userId:A.user?.id}})}
function ledgerReverse(ops,refType,refId,desc,date){
 const all=L('ledger').filter(e=>e.refType===refType&&e.refId===refId&&!e.reverses);
 const rev=new Set(L('ledger').filter(e=>e.reverses).map(e=>e.reverses));
 all.forEach(e=>{if(rev.has(e.id))return;ledgerAdd(ops,{customerId:e.customerId,acct:e.acct,sub:e.sub,date,desc,debit:e.credit,credit:e.debit,docNo:e.docNo,method:e.method,refType:e.refType,refId:e.refId,kind:'reversal',reverses:e.id})})}

/* ============ پرداخت‌ها و چک‌ها ============ */
const payIdx=()=>memo('payIdx',()=>{const m=new Map();for(const p of L('payments')){const k=p.refType+':'+p.refId;if(!m.has(k))m.set(k,[]);m.get(k).push(p)}return m});
const paysOf=(t,id)=>(payIdx().get(t+':'+id)||[]).filter(p=>!p.voided);
const paidOf=(t,id)=>sum(paysOf(t,id),p=>p.dir==='in'?p.amount:-p.amount);
const METHODS={cash:'نقدی',pos:'کارت‌خوان',card:'کارت‌به‌کارت',check:'چک',transfer:'انتقال بانکی',credit:'اعتباری'};
const mlabel=m=>METHODS[m]||m;
function cashInfo(p){ // آیا این پرداخت در جریان نقدی حساب می‌شود و در چه تاریخی
 if(p.voided)return null;
 if(p.method==='check'){const c=G('checks',p.checkId);if(c&&(c.status==='collected'||c.status==='paid')&&c.settleDate)return{j:c.settleDate.j};return null}
 return{j:p.date.j}}
function buildPayment(ops,o){
 const amount=o.amount;
 if(!Number.isInteger(amount)||amount<=0)throw E('مبلغ پرداخت باید عددی صحیح و بزرگ‌تر از صفر باشد.');
 if(!o.date||!D.ok(o.date.y,o.date.m,o.date.d))throw E('تاریخ پرداخت نامعتبر است.');
 if(!METHODS[o.method])throw E('روش پرداخت نامعتبر است.');
 const refType=o.refType||'general';const dir=o.dir;
 if(dir!=='in'&&dir!=='out')throw E('جهت پرداخت نامعتبر است.');
 let loan=null,sale=null;
 if(!o.trusted){
  if(refType==='sale'){sale=G('sales',o.refId);if(!sale||sale.status!=='active')throw E('فاکتور معتبر نیست.');
   if(dir==='in'&&amount>sale.total-paidOf('sale',sale.id))throw E('مبلغ بیشتر از مانده فاکتور است.');
   if(dir==='out'&&amount>paidOf('sale',sale.id))throw E('مبلغ بازپرداخت بیشتر از وجه دریافت‌شده است.')}
  if(refType==='loan'){loan=G('loans',o.refId);if(!loan||loan.status==='void')throw E('قرض معتبر نیست.');
   const li=loanInfo(loan);if(amount>li.remaining)throw E('مبلغ بیشتر از مانده قرض است.');
   if((loan.kind==='out')!==(dir==='in'))throw E('جهت پرداخت با نوع قرض سازگار نیست.')}}
 if(refType==='loan'&&!loan)loan=G('loans',o.refId);
 const cid=o.customerId||null,sid=o.supplierId||null;
 if(!cid&&!sid&&refType!=='sale')throw E('طرف حساب را انتخاب کنید.');
 const p={id:uid(),no:nextNo(ops,'pay'),ts:Date.now(),date:o.date,dir,customerId:cid,supplierId:sid,amount,method:o.method,tracking:o.tracking||'',note:o.note||'',refType,refId:o.refId||null,checkId:null,voided:false,userId:A.user?.id};
 if(o.method==='check'){const c=o.check||{};
  if(!c.number)throw E('شماره چک را وارد کنید.');if(!c.bank)throw E('نام بانک را وارد کنید.');
  if(!c.dueDate||!D.ok(c.dueDate.y,c.dueDate.m,c.dueDate.d))throw E('تاریخ سررسید چک نامعتبر است.');
  if(L('checks').some(k=>k.number===c.number&&k.bank===c.bank&&k.status!=='void'&&k.type===(dir==='in'?'in':'out')))throw E('چکی با این شماره و بانک قبلاً ثبت شده است.');
  const ck={id:uid(),no:nextNo(ops,'check'),ts:Date.now(),type:dir==='in'?'in':'out',customerId:cid,supplierId:sid,number:c.number,amount,bank:c.bank,owner:c.owner||'',account:c.account||'',sayad:c.sayad||'',issueDate:c.issueDate||o.date,dueDate:c.dueDate,note:c.note||'',image:c.image||'',refType,refId:o.refId||null,status:'pending',settleDate:null,paymentId:p.id,userId:A.user?.id,log:[{ts:Date.now(),a:'ثبت چک',u:A.user?.name}]};
  p.checkId=ck.id;ops.push({s:'checks',put:ck});audit(ops,'ثبت چک','check',ck.id,`${c.number} - ${money(amount)}`)}
 ops.push({s:'payments',put:p});
 if(cid){const base={customerId:cid,date:o.date,docNo:p.no,method:mlabel(o.method),refType:'payment',refId:p.id,kind:'payment'};
  const lab=refType==='sale'?'فاکتور '+(o.refNo||G('sales',o.refId)?.no||''):refType==='loan'?'قرض '+(loan?.no||''):'';
  if(refType==='loan'&&loan.kind==='in')ledgerAdd(ops,{...base,acct:'P',sub:'loan',debit:amount,desc:'بازپرداخت قرض به مشتری '+lab});
  else if(refType==='loan')ledgerAdd(ops,{...base,acct:'R',sub:'loan',credit:amount,desc:'دریافت بازپرداخت قرض '+lab});
  else if(dir==='in')ledgerAdd(ops,{...base,acct:'R',sub:refType==='sale'?'sale':'gen',credit:amount,desc:'دریافت وجه '+lab});
  else ledgerAdd(ops,{...base,acct:'R',sub:refType==='sale'?'sale':'gen',debit:amount,desc:'پرداخت/برگشت وجه به مشتری '+lab})}
 if(refType==='loan')ops.push({s:'loanPayments',put:{id:uid(),loanId:o.refId,paymentId:p.id,date:o.date}});
 audit(ops,dir==='in'?'دریافت وجه':'پرداخت وجه','payment',p.id,`${p.no} - ${money(amount)} - ${mlabel(o.method)}`);
 return p}
async function addPayment(o){const ops=[];const p=buildPayment(ops,o);await DB.commit(ops);return p}
function voidPaymentOps(ops,p0,reason){const p=getOp(ops,'payments',p0.id);if(p.voided)return;p.voided=true;p.voidReason=reason;ledgerReverse(ops,'payment',p.id,'ابطال '+p.no+' - '+reason,D.today());
 audit(ops,'ابطال پرداخت','payment',p.id,p.no+' '+reason)}
async function voidPayment(id,reason){need('cancel_sale');const p=G('payments',id);if(!p||p.voided)throw E('پرداخت معتبر نیست.');const ops=[];voidPaymentOps(ops,p,reason||'ابطال دستی');
 if(p.checkId){const c=getOp(ops,'checks',p.checkId);if(c.status==='pending'){c.status='void';c.log.push({ts:Date.now(),a:'ابطال همراه پرداخت',u:A.user?.name})}}
 await DB.commit(ops)}

/* ============ فروش ============ */
function calcSale(items,discount,extra){let sub=0;items.forEach(i=>{i.amount=Math.round(i.qty*i.unitPrice/1000);sub+=i.amount});return{subtotal:sub,total:sub-discount+extra}}
const saleInfo=s=>{const paid=paidOf('sale',s.id);return{paid,remain:s.status==='active'?s.total-paid:0}};
function validateItems(items,exclude){const need=new Map();
 const out=items.map(i=>{const p=G('products',i.productId);if(!p)throw E('کالا یافت نشد.');
  if(!(i.qty>0)||!Number.isInteger(i.qty))throw E(`مقدار کالای «${p.name}» باید بزرگ‌تر از صفر باشد.`);
  if(!Number.isInteger(i.unitPrice)||i.unitPrice<0)throw E(`قیمت واحد «${p.name}» نامعتبر است.`);
  need.set(p.id,(need.get(p.id)||0)+i.qty);return{productId:p.id,name:p.name,unit:p.unit,qty:i.qty,unitPrice:i.unitPrice}});
 return{out,need}}
function checkStock(need,old){const neg=SET().allowNegative&&can('neg_stock');
 need.forEach((q,pid)=>{const have=stockOf(pid)+(old?.get(pid)||0);if(have<q&&!neg){const p=G('products',pid);throw E(`موجودی «${p.name}» کافی نیست (موجودی: ${qtyf(have,p.unit)}، درخواست: ${qtyf(q,p.unit)}).`)}})}
async function createSale(o){
 const ops=[];if(!can('sale'))throw E('دسترسی ثبت فروش ندارید.');
 if(!o.items?.length)throw E('حداقل یک کالا به فاکتور اضافه کنید.');
 if(!o.date||!D.ok(o.date.y,o.date.m,o.date.d))throw E('تاریخ فاکتور نامعتبر است.');
 const{out,need}=validateItems(o.items);checkStock(need);
 const discount=o.discount||0,extra=o.extra||0;
 const c=calcSale(out,discount,extra);
 if(discount<0||discount>c.subtotal)throw E('تخفیف باید بین صفر و جمع فاکتور باشد.');
 if(extra<0)throw E('هزینه اضافی نمی‌تواند منفی باشد.');
 const pays=(o.pays||[]).filter(p=>p.amount>0);const paid=sum(pays,p=>p.amount);
 if(paid>c.total)throw E('مجموع پرداخت‌ها بیشتر از مبلغ نهایی فاکتور است.');
 const cust=o.customerId?G('customers',o.customerId):null;
 if(o.customerId&&(!cust||!cust.active))throw E('مشتری انتخاب‌شده معتبر یا فعال نیست.');
 if(!cust&&paid<c.total)throw E('برای مشتری متفرقه باید کل مبلغ پرداخت شود؛ برای نسیه مشتری انتخاب کنید.');
 if(cust&&cust.creditLimit>0&&!o.overrideCredit){const b=custBal(cust.id).R+(c.total-paid);if(b>cust.creditLimit)throw E(`با ثبت این فاکتور، بدهی مشتری (${money(b)}) از سقف اعتبار (${money(cust.creditLimit)}) بیشتر می‌شود.`,'CREDIT')}
 const sale={id:uid(),no:nextNo(ops,'sale'),ts:Date.now(),date:o.date,customerId:cust?.id||null,customerName:cust? '': (o.customerName||''),items:out,subtotal:c.subtotal,discount,extra,total:c.total,note:o.note||'',priceType:o.priceType||'sellPrice',status:'active',cogs:0,userId:A.user?.id,userName:A.user?.name,history:[{ts:Date.now(),u:A.user?.name,a:'ثبت فاکتور',total:c.total}]};
 for(const it of out){it.unitCost=moveOps(ops,{productId:it.productId,type:'sale',qty:-it.qty,date:o.date,refType:'sale',refId:sale.id});it.cogs=Math.round(it.qty*it.unitCost/1000);sale.cogs+=it.cogs}
 ops.push({s:'sales',put:sale});
 if(cust)ledgerAdd(ops,{customerId:cust.id,acct:'R',sub:'sale',date:o.date,desc:'فاکتور فروش '+sale.no,debit:c.total,docNo:sale.no,refType:'sale',refId:sale.id,kind:'sale'});
 for(const p of pays)buildPayment(ops,{dir:'in',customerId:cust?.id,amount:p.amount,method:p.method,date:o.date,tracking:p.tracking,note:p.note,refType:'sale',refId:sale.id,refNo:sale.no,check:p.check,trusted:true});
 audit(ops,'ثبت فاکتور','sale',sale.id,`${sale.no} - ${money(c.total)}`);
 await DB.commit(ops);return sale}
async function editSale(id,o){
 need('edit_sale');const ops=[];const old=G('sales',id);if(!old||old.status!=='active')throw E('فاکتور قابل ویرایش نیست.');
 if(!o.items?.length)throw E('حداقل یک کالا لازم است.');
 if(!o.date||!D.ok(o.date.y,o.date.m,o.date.d))throw E('تاریخ نامعتبر است.');
 const{out,need:nd}=validateItems(o.items);
 const oldQ=new Map();old.items.forEach(i=>oldQ.set(i.productId,(oldQ.get(i.productId)||0)+i.qty));
 checkStock(nd,oldQ);
 const discount=o.discount||0,extra=o.extra||0;const c=calcSale(out,discount,extra);
 if(discount<0||discount>c.subtotal)throw E('تخفیف باید بین صفر و جمع فاکتور باشد.');if(extra<0)throw E('هزینه اضافی نامعتبر است.');
 const paid=paidOf('sale',id);
 if(c.total<paid)throw E('مبلغ جدید فاکتور کمتر از مجموع پرداخت‌شده است. ابتدا پرداخت‌ها را اصلاح یا ابطال کنید.');
 const oldCost=new Map();old.items.forEach(i=>oldCost.set(i.productId,i.unitCost));
 let cogs=0;out.forEach(it=>{it.unitCost=oldCost.has(it.productId)?oldCost.get(it.productId):(G('products',it.productId).avgCost||0);it.cogs=Math.round(it.qty*it.unitCost/1000);cogs+=it.cogs});
 const s=clone(old);
 const pids=new Set([...oldQ.keys(),...nd.keys()]);
 pids.forEach(pid=>{const delta=(nd.get(pid)||0)-(oldQ.get(pid)||0);if(!delta)return;
  moveOps(ops,{productId:pid,type:'sale_edit',qty:-delta,unitCost:delta<0?(oldCost.get(pid)??0):undefined,date:D.today(),refType:'sale',refId:id,note:'اصلاح فاکتور '+old.no})});
 const diff=c.total-old.total;
 if(diff&&old.customerId)ledgerAdd(ops,{customerId:old.customerId,acct:'R',sub:'sale',date:D.today(),desc:'سند اصلاحی فاکتور '+old.no,debit:diff>0?diff:0,credit:diff<0?-diff:0,docNo:old.no,refType:'sale',refId:id,kind:'sale_adjust'});
 if(!old.customerId&&c.total!==paid)throw E('فاکتور مشتری متفرقه باید کاملاً پرداخت‌شده بماند.');
 Object.assign(s,{date:o.date,items:out,subtotal:c.subtotal,discount,extra,total:c.total,note:o.note||'',cogs,priceType:o.priceType||s.priceType,customerName:o.customerName??s.customerName});
 s.history.push({ts:Date.now(),u:A.user?.name,a:'ویرایش فاکتور',total:c.total,before:old.total});
 ops.push({s:'sales',put:s});audit(ops,'ویرایش فاکتور','sale',id,`${old.no}: ${money(old.total)} ← ${money(c.total)}`);
 await DB.commit(ops);return s}
async function cancelSale(id,reason){
 need('cancel_sale');const ops=[];const s0=G('sales',id);if(!s0||s0.status!=='active')throw E('فاکتور قابل ابطال نیست.');
 const s=getOp(ops,'sales',id);s.status='void';s.voidReason=reason||'';s.voidTs=Date.now();s.history.push({ts:Date.now(),u:A.user?.name,a:'ابطال فاکتور',total:0,before:s0.total});
 s0.items.forEach(i=>moveOps(ops,{productId:i.productId,type:'sale_return',qty:i.qty,unitCost:i.unitCost,date:D.today(),refType:'sale',refId:id,note:'ابطال فاکتور '+s0.no}));
 paysOf('sale',id).forEach(p=>{voidPaymentOps(ops,p,'ابطال فاکتور '+s0.no);if(p.checkId){const c=getOp(ops,'checks',p.checkId);if(c.status==='pending'){c.status='void';c.log.push({ts:Date.now(),a:'ابطال همراه فاکتور',u:A.user?.name})}}});
 ledgerReverse(ops,'sale',id,'ابطال فاکتور '+s0.no,D.today());
 audit(ops,'ابطال فاکتور','sale',id,s0.no+' '+(reason||''));await DB.commit(ops)}

/* ============ کالا، مشتری، تأمین‌کننده ============ */
async function saveProduct(o,id){
 const ops=[];if(!o.name?.trim())throw E('نام کالا الزامی است.');
 ['buyPrice','sellPrice','wholesale','retail','minStock'].forEach(k=>{if(!Number.isFinite(o[k])||o[k]<0)throw E('مقادیر عددی کالا نامعتبر است.')});
 if(L('products').some(p=>p.id!==id&&p.name.trim()===o.name.trim()))throw E('کالایی با این نام وجود دارد.');
 if(o.code&&L('products').some(p=>p.id!==id&&p.code===o.code))throw E('این کد کالا تکراری است.');
 if(o.barcode&&L('products').some(p=>p.id!==id&&p.barcode===o.barcode))throw E('این بارکد تکراری است.');
 let p;
 if(id){p=clone(G('products',id));const pc=[];
  ['buyPrice','sellPrice','wholesale','retail'].forEach(k=>{if(p[k]!==o[k]){if(!can('price_edit'))throw E('اجازه تغییر قیمت ندارید.');pc.push({ts:Date.now(),date:D.today(),field:k,old:p[k],new:o[k],userId:A.user?.id,userName:A.user?.name})}});
  p.priceHistory=[...(p.priceHistory||[]),...pc];Object.assign(p,{name:o.name.trim(),code:o.code||p.code,barcode:o.barcode||'',categoryId:o.categoryId,desc:o.desc||'',unit:o.unit,minStock:o.minStock,buyPrice:o.buyPrice,sellPrice:o.sellPrice,wholesale:o.wholesale,retail:o.retail,supplierId:o.supplierId||'',active:o.active,image:o.image??p.image,regDate:o.regDate||p.regDate});
  ops.push({s:'products',put:p});audit(ops,'ویرایش کالا','product',id,p.name)}
 else{p={id:uid(),code:o.code||nextNo(ops,'prod'),barcode:o.barcode||'',name:o.name.trim(),categoryId:o.categoryId,desc:o.desc||'',unit:o.unit,minStock:o.minStock,buyPrice:o.buyPrice,sellPrice:o.sellPrice,wholesale:o.wholesale,retail:o.retail,supplierId:o.supplierId||'',active:o.active!==false,image:o.image||'',regDate:o.regDate||D.today(),avgCost:o.buyPrice,priceHistory:[{ts:Date.now(),date:D.today(),field:'create',old:0,new:o.sellPrice,userId:A.user?.id,userName:A.user?.name}],ts:Date.now()};
  ops.push({s:'products',put:p});
  if(o.openQty>0)moveOps(ops,{productId:p.id,type:'initial',qty:o.openQty,unitCost:o.buyPrice,date:o.regDate||D.today(),note:'موجودی اولیه'});
  audit(ops,'افزودن کالا','product',p.id,p.name)}
 await DB.commit(ops);return p}
async function saveCustomer(o,id){
 const ops=[];if(!o.name?.trim())throw E('نام مشتری الزامی است.');
 if(o.phone&&!/^0?9\d{9}$/.test(o.phone)&&!/^0\d{10}$/.test(o.phone))throw E('شماره موبایل/تلفن نامعتبر است (مثال: 09123456789).');
 if(!Number.isFinite(o.creditLimit)||o.creditLimit<0)throw E('سقف اعتبار نامعتبر است.');
 if(o.phone&&L('customers').some(c=>c.id!==id&&c.phone===o.phone))throw E('مشتری دیگری با این شماره ثبت شده است.');
 let c;if(id){c=clone(G('customers',id));Object.assign(c,{name:o.name.trim(),phone:o.phone||'',address:o.address||'',note:o.note||'',creditLimit:o.creditLimit,active:o.active});audit(ops,'ویرایش مشتری','customer',id,c.name)}
 else{c={id:uid(),code:nextNo(ops,'cust'),name:o.name.trim(),phone:o.phone||'',address:o.address||'',note:o.note||'',creditLimit:o.creditLimit,active:true,regDate:D.today(),ts:Date.now()};audit(ops,'افزودن مشتری','customer',c.id,c.name)}
 ops.push({s:'customers',put:c});await DB.commit(ops);return c}
async function saveSimple(store,o,id,label){const ops=[];if(!o.name?.trim())throw E('نام الزامی است.');
 if(L(store).some(x=>x.id!==id&&x.name===o.name.trim()))throw E('این نام قبلاً ثبت شده است.');
 const r=id?Object.assign(clone(G(store,id)),o,{name:o.name.trim()}):{id:uid(),active:true,ts:Date.now(),...o,name:o.name.trim()};
 ops.push({s:store,put:r});audit(ops,id?'ویرایش '+label:'افزودن '+label,store,r.id,r.name);await DB.commit(ops);return r}

/* ============ انبار: خرید و اصلاحات ============ */
async function createPurchase(o){need('inventory');const ops=[];
 if(!o.supplierId||!G('suppliers',o.supplierId))throw E('تأمین‌کننده را انتخاب کنید.');
 if(!o.items?.length)throw E('حداقل یک کالا اضافه کنید.');if(!D.ok(o.date.y,o.date.m,o.date.d))throw E('تاریخ نامعتبر است.');
 let total=0;const items=o.items.map(i=>{if(!(i.qty>0))throw E('مقدار خرید نامعتبر است.');if(!Number.isInteger(i.unitCost)||i.unitCost<=0)throw E('قیمت خرید نامعتبر است.');const amount=Math.round(i.qty*i.unitCost/1000);total+=amount;return{productId:i.productId,qty:i.qty,unitCost:i.unitCost,amount}});
 if(o.paid<0||o.paid>total)throw E('مبلغ پرداختی باید بین صفر و جمع فاکتور خرید باشد.');
 const pu={id:uid(),no:nextNo(ops,'purch'),ts:Date.now(),date:o.date,supplierId:o.supplierId,items,total,note:o.note||'',userId:A.user?.id,status:'active'};
 for(const it of items){moveOps(ops,{productId:it.productId,type:'purchase',qty:it.qty,unitCost:it.unitCost,date:o.date,refType:'purchase',refId:pu.id,note:'خرید '+pu.no});
  const p=getOp(ops,'products',it.productId);if(p.buyPrice!==it.unitCost){p.priceHistory=[...(p.priceHistory||[]),{ts:Date.now(),date:o.date,field:'buyPrice',old:p.buyPrice,new:it.unitCost,userId:A.user?.id,userName:A.user?.name}];p.buyPrice=it.unitCost}}
 ops.push({s:'purchases',put:pu});
 if(o.paid>0)buildPayment(ops,{dir:'out',supplierId:o.supplierId,amount:o.paid,method:o.method||'cash',date:o.date,refType:'purchase',refId:pu.id,trusted:true,check:o.check});
 audit(ops,'خرید از تأمین‌کننده','purchase',pu.id,`${pu.no} - ${money(total)}`);await DB.commit(ops);return pu}
async function stockOp(o){need('inventory');const ops=[];const p=G('products',o.productId);if(!p)throw E('کالا را انتخاب کنید.');
 if(!(o.qty>0))throw E('مقدار باید بزرگ‌تر از صفر باشد.');if(!D.ok(o.date.y,o.date.m,o.date.d))throw E('تاریخ نامعتبر است.');
 const sign=['in','initial'].includes(o.type)||(o.type==='adjust'&&o.dir==='+')?1:-1;
 if(sign<0&&stockOf(p.id)<o.qty&&!(SET().allowNegative&&can('neg_stock')))throw E(`موجودی کافی نیست (موجودی: ${qtyf(stockOf(p.id),p.unit)}).`);
 if(sign>0&&o.type==='in'&&!(o.unitCost>0))throw E('قیمت خرید ورودی را وارد کنید.');
 moveOps(ops,{productId:p.id,type:o.type,qty:sign*o.qty,unitCost:sign>0?o.unitCost:undefined,date:o.date,note:o.note});
 audit(ops,'حرکت انبار','inventory',p.id,`${OUT_TYPES[o.type]} ${qtyf(o.qty,p.unit)} - ${p.name}`);await DB.commit(ops)}

/* ============ قرض ============ */
function loanInfo(l){const lp=L('loanPayments').filter(x=>x.loanId===l.id).map(x=>G('payments',x.paymentId)).filter(p=>p&&!p.voided);
 const paid=sum(lp,p=>p.amount);const remaining=l.status==='void'?0:l.amount-paid;
 const last=lp.sort((a,b)=>b.date.j-a.date.j)[0]?.date;
 const overdue=remaining>0&&l.dueDate&&l.dueDate.j<D.todayJ();
 return{paid,remaining,last,overdue,pays:lp,status:l.status==='void'?'void':remaining<=0?'settled':overdue?'overdue':'open'}}
async function createLoan(o){need('loans');const ops=[];const c=G('customers',o.customerId);if(!c)throw E('مشتری را انتخاب کنید.');
 if(!['in','out'].includes(o.kind))throw E('نوع قرض را مشخص کنید.');if(!Number.isInteger(o.amount)||o.amount<=0)throw E('مبلغ قرض نامعتبر است.');
 if(!o.title?.trim())throw E('عنوان یا علت قرض را وارد کنید.');if(!D.ok(o.date.y,o.date.m,o.date.d))throw E('تاریخ ثبت نامعتبر است.');
 if(o.dueDate&&o.dueDate.j<o.date.j)throw E('تاریخ سررسید نمی‌تواند قبل از تاریخ ثبت باشد.');
 const l={id:uid(),no:nextNo(ops,'loan'),ts:Date.now(),kind:o.kind,customerId:c.id,amount:o.amount,date:o.date,dueDate:o.dueDate||null,title:o.title.trim(),note:o.note||'',docNo:o.docNo||'',method:o.method||'cash',userId:A.user?.id,userName:A.user?.name,status:'active',image:o.image||''};
 ops.push({s:'loans',put:l});
 const base={customerId:c.id,sub:'loan',date:o.date,docNo:l.docNo||l.no,method:mlabel(l.method),refType:'loan',refId:l.id,kind:'loan'};
 if(o.kind==='out')ledgerAdd(ops,{...base,acct:'R',debit:o.amount,desc:'قرض فروشگاه به مشتری: '+l.title});else ledgerAdd(ops,{...base,acct:'P',credit:o.amount,desc:'قرض مشتری به فروشگاه: '+l.title});
 audit(ops,'ثبت قرض','loan',l.id,`${l.no} ${o.kind==='out'?'پرداختی':'دریافتی'} ${money(o.amount)}`);await DB.commit(ops);return l}
async function voidLoan(id){need('cancel_sale');const l0=G('loans',id);if(!l0||l0.status==='void')throw E('قرض معتبر نیست.');const ops=[];const l=getOp(ops,'loans',id);l.status='void';
 const li=loanInfo(l0);li.pays.forEach(p=>voidPaymentOps(ops,p,'ابطال قرض '+l0.no));ledgerReverse(ops,'loan',id,'ابطال قرض '+l0.no,D.today());audit(ops,'ابطال قرض','loan',id,l0.no);await DB.commit(ops)}

/* ============ چک ============ */
const checkOpen=c=>c.status==='pending';
function checkState(c){if(c.status==='void')return{k:'void',t:'باطل‌شده',c:'mu'};if(c.status==='bounced')return{k:'bounced',t:'برگشت‌خورده',c:'err'};
 if(c.status==='collected')return{k:'done',t:'وصول‌شده',c:'ok'};if(c.status==='paid')return{k:'done',t:'پرداخت‌شده',c:'ok'};
 const days=c.dueDate.j-D.todayJ();
 if(days<0)return{k:'overdue',t:'سررسیدشده',c:'err',days};
 if(days<=SET().nearDays)return{k:'near',t:'نزدیک به سررسید',c:'warn',days};
 return{k:'wait',t:'در انتظار سررسید',c:'gd',days}}
function remainText(c){const due=D.toJS(c.dueDate,23,59).getTime();const diff=due-Date.now();if(diff<0){const d=Math.ceil(-diff/864e5);return D.toJS(c.dueDate).getTime()+864e5<Date.now()?`${num(d)} روز گذشته`:'امروز'}
 const h=Math.floor(diff/36e5);if(h<24)return `${num(h)} ساعت مانده`;return `${num(Math.floor(h/24))} روز و ${num(h%24)} ساعت مانده`}
async function checkAction(id,act,date){need('checks');const c0=G('checks',id);if(!c0||c0.status!=='pending')throw E('این چک قابل تغییر وضعیت نیست.');const ops=[];const c=getOp(ops,'checks',id);
 const lab={collect:'وصول',pay:'پرداخت',bounce:'برگشت',void:'ابطال'}[act];
 if(act==='collect'){if(c.type!=='in')throw E('فقط چک دریافتی وصول می‌شود.');c.status='collected';c.settleDate=date||D.today()}
 else if(act==='pay'){if(c.type!=='out')throw E('فقط چک پرداختی پرداخت می‌شود.');c.status='paid';c.settleDate=date||D.today()}
 else{c.status=act==='bounce'?'bounced':'void';const p=G('payments',c.paymentId);if(p&&!p.voided)voidPaymentOps(ops,p,(act==='bounce'?'برگشت چک ':'ابطال چک ')+c.number)}
 c.log.push({ts:Date.now(),a:lab,u:A.user?.name});audit(ops,'چک: '+lab,'check',id,c.number);await DB.commit(ops)}
async function editCheck(id,o){need('checks');const ops=[];const c=getOp(ops,'checks',id);if(!c)throw E('چک یافت نشد.');if(!o.number||!o.bank)throw E('شماره چک و بانک الزامی است.');
 if(!o.dueDate||!D.ok(o.dueDate.y,o.dueDate.m,o.dueDate.d))throw E('تاریخ سررسید نامعتبر است.');
 Object.assign(c,{number:o.number,bank:o.bank,owner:o.owner||'',account:o.account||'',sayad:o.sayad||'',dueDate:o.dueDate,note:o.note||'',image:o.image??c.image});c.log.push({ts:Date.now(),a:'ویرایش مشخصات',u:A.user?.name});audit(ops,'ویرایش چک','check',id,c.number);await DB.commit(ops)}

/* ============ هزینه‌ها ============ */
async function addExpense(o){const ops=[];if(!o.title?.trim())throw E('عنوان هزینه را وارد کنید.');if(!Number.isInteger(o.amount)||o.amount<=0)throw E('مبلغ هزینه نامعتبر است.');if(!D.ok(o.date.y,o.date.m,o.date.d))throw E('تاریخ نامعتبر است.');
 const e={id:uid(),no:nextNo(ops,'exp'),ts:Date.now(),date:o.date,title:o.title.trim(),amount:o.amount,method:o.method||'cash',note:o.note||'',voided:false,userId:A.user?.id};ops.push({s:'expenses',put:e});audit(ops,'ثبت هزینه','expense',e.id,`${e.title} ${money(e.amount)}`);await DB.commit(ops)}
async function voidExpense(id){need('cancel_sale');const ops=[];const e=getOp(ops,'expenses',id);e.voided=true;audit(ops,'ابطال هزینه','expense',id,e.title);await DB.commit(ops)}

/* ============ محاسبات تجمیعی ============ */
const activeSales=()=>L('sales').filter(s=>s.status==='active');
const inR=(d,f,t)=>(!f||d.j>=f)&&(!t||d.j<=t);
function cashFlow(f,t){let inn=0,out=0;
 for(const p of L('payments')){const c=cashInfo(p);if(!c||!inR({j:c.j},f,t))continue;if(p.dir==='in')inn+=p.amount;else out+=p.amount}
 for(const l of L('loans')){if(l.status==='void'||!inR(l.date,f,t))continue;if(l.kind==='out')out+=l.amount;else inn+=l.amount}
 return{inn,out}}
const expenseSum=(f,t)=>sum(L('expenses').filter(e=>!e.voided&&inR(e.date,f,t)),e=>e.amount);
const wasteCost=(f,t)=>sum(L('inventory').filter(m=>m.type==='waste'&&inR(m.date,f,t)),m=>-m.qty*m.unitCost/1000);
function salesAgg(f,t){const s=activeSales().filter(x=>inR(x.date,f,t));return{count:s.length,total:sum(s,x=>x.total),cogs:sum(s,x=>x.cogs),profit:sum(s,x=>x.total-x.cogs),discount:sum(s,x=>x.discount)}}
function totals(){let rec=0,pay=0,credit=0;const cs=L('customers');cs.forEach(c=>{const b=custBal(c.id);if(b.R>0)rec+=b.R;else credit-=b.R;if(b.P>0)pay+=b.P});return{rec,pay,credit}}
const nameOfC=id=>id?(G('customers',id)?.name||'—'):'مشتری متفرقه';
const walkName=s=>{if(!s) return 'مشتری متفرقه'; if(s.customerId) return nameOfC(s.customerId); return (s.customerName||'مشتری روزانه');};
const saleCustName=s=>{if(!s) return 'مشتری متفرقه'; if(typeof s==='string') return nameOfC(s); if(s.customerId) return nameOfC(s.customerId); return (s.customerName||'مشتری روزانه');};
const nameOfP=id=>G('products',id)?.name||'—';
const catName=id=>G('categories',id)?.name||'—';
const lowStock=()=>L('products').filter(p=>p.active&&stockOf(p.id)<=p.minStock&&p.minStock>=0&&(p.minStock>0||stockOf(p.id)<=0));
const supBal=sid=>sum(L('purchases').filter(p=>p.supplierId===sid&&p.status==='active'),p=>p.total)-sum(L('payments').filter(p=>p.supplierId===sid&&!p.voided&&(p.refType==='purchase'||p.refType==='general')),p=>p.dir==='out'?p.amount:-p.amount);

/* ============ یادآوری‌ها ============ */
async function runReminders(){
 const s=SET();if(!s.remEnabled||!A.user)return[];const ops=[];const have=new Set(L('notifications').map(n=>n.key));const now=Date.now();const fresh=[];
 const mk=(key,kind,refId,title,level)=>{if(have.has(key))return;have.add(key);const n={id:uid(),key,kind,refId,title,level,ts:now,read:false,snoozeUntil:0,shown:false};ops.push({s:'notifications',put:n});fresh.push(n)};
 const [hh,mm]=s.notifyTime.split(':').map(Number);const rules=L('checkReminders').filter(r=>r.enabled);
 for(const c of L('checks')){if(!checkOpen(c))continue;const due=D.toJS(c.dueDate,hh||0,mm||0).getTime();
  if(c.dueDate.j<D.todayJ()-60)continue;
  for(const r of rules.filter(r=>r.kind===c.type)){const trig=due-r.offsetHours*36e5;if(now>=trig&&now<due+864e5)mk(`ck:${c.id}:${r.id}`,'check',c.id,`یادآوری چک ${c.type==='in'?'دریافتی':'پرداختی'} ${c.number}`,'warn')}
  if(D.toJS(c.dueDate,23,59).getTime()<now)mk(`ck:${c.id}:overdue`,'check',c.id,`چک ${c.number} سررسید شده است`,'err')}
 if(s.loanRemind)for(const l of L('loans')){const li=loanInfo(l);if(li.overdue)mk(`ln:${l.id}:due`,'loan',l.id,`قرض ${l.no} (${nameOfC(l.customerId)}) معوق شده است`,'err')}
 if(s.backupRemind&&D.fromJS(s.lastBackup||0).j<D.todayJ()&&(L('sales').length||L('customers').length))mk('bk:'+D.todayJ(),'backup',null,'پشتیبان‌گیری امروز انجام نشده است','warn');
 if(ops.length)await DB.commit(ops);return fresh}
const notifActive=()=>L('notifications').filter(n=>n.snoozeUntil<=Date.now());

/* ============ رابط کاربری: ابزارها ============ */
const IC={home:'<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
cart:'<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/>',
file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
box:'<path d="M21 16V8a2 2 0 0 0-1-1.7l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.7l7 4a2 2 0 0 0 2 0l7-4a2 2 0 0 0 1-1.7z"/><polyline points="3.3 7 12 12 20.7 7"/><line x1="12" y1="22" x2="12" y2="12"/>',
layers:'<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
users:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9"/><path d="M16 3.1a4 4 0 0 1 0 7.8"/>',
book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
dollar:'<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
card:'<rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/>',
check:'<polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
bell:'<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
truck:'<rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
chart:'<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
sliders:'<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
db:'<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.7-4 3-9 3s-9-1.3-9-3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/>',
plus:'<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
trash:'<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
printer:'<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
search:'<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
x:'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
menu:'<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
upload:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
eye:'<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
alert:'<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
more:'<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
inbox:'<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.5 5.1L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.7 4H7.3a2 2 0 0 0-1.8 1.1z"/>',
clock:'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',zap:'<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>',excel:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="13" x2="15" y2="19"/><line x1="15" y1="13" x2="9" y2="19"/>'};
const ic=n=>`<svg class="i" viewBox="0 0 24 24" aria-hidden="true">${IC[n]||''}</svg>`;
const ACT={},INP={},FORM={};
const badge=(t,c='mu')=>`<span class="bg ${c}">${esc(t)}</span>`;
const fld=(label,inner,cls='')=>`<label class="f ${cls}">${label}${inner}</label>`;
const inp=(name,val='',extra='')=>`<input name="${name}" value="${esc(val)}" ${extra}>`;
const minp=(name,val,extra='')=>`<input name="${name}" class="money" inputmode="numeric" autocomplete="off" value="${val?num(val).replace(/٬/g,'٬'):''}" ${extra}>`;
const qinp=(name,val,extra='')=>`<input name="${name}" inputmode="decimal" autocomplete="off" value="${val?(val/1000).toLocaleString('fa-IR',{minimumFractionDigits:3,maximumFractionDigits:3,useGrouping:false}):''}" ${extra}>`;
const sel=(name,opts,val='',extra='')=>`<select name="${name}" ${extra}>${opts.map(o=>{const[v,t]=Array.isArray(o)?o:[o,o];return `<option value="${esc(v)}" ${String(v)===String(val)?'selected':''}>${esc(t)}</option>`}).join('')}</select>`;
const emptyBox=(t='موردی برای نمایش وجود ندارد.',i='inbox')=>`<div class="empty">${ic(i)}<div>${esc(t)}</div></div>`;
const colorNum=n=>n>0?'pos':n<0?'neg':'mu';

/* اعلان */
function toast(msg,type='ok',ms=3800){let b=$('.toasts');if(!b){b=document.createElement('div');b.className='toasts';b.setAttribute('role','status');document.body.appendChild(b)}
 const t=document.createElement('div');t.className='toast '+type;t.textContent=msg;b.appendChild(t);setTimeout(()=>t.remove(),ms)}
/* مودال */
const MODALS=[];
function modal({title,body,footer='',size=''}){const w=document.createElement('div');w.className='mw';w.setAttribute('role','dialog');w.innerHTML=`<div class="md ${size}"><header><b>${esc(title)}</b><button class="ib" style="width:34px;height:34px" data-act="mclose" aria-label="بستن">${ic('x')}</button></header><div class="bdy">${body}</div>${footer?`<footer>${footer}</footer>`:''}</div>`;
 w.style.zIndex=100+MODALS.length*2;w.addEventListener('mousedown',e=>{if(e.target===w&&!w.dataset.lock)closeModal(w)});document.body.appendChild(w);MODALS.push(w);initDates(w);
 const f=w.querySelector('input:not([type=hidden]),select');if(f&&matchMedia('(min-width:900px)').matches)f.focus();return w}
function closeModal(w){w=w||MODALS[MODALS.length-1];if(!w)return;w.remove();const i=MODALS.indexOf(w);if(i>=0)MODALS.splice(i,1)}
ACT.mclose=el=>closeModal(el.closest('.mw'));
function confirmBox(msg,{ok='تأیید',danger=false,title='تأیید عملیات',input=null}={}){return new Promise(res=>{
 const w=modal({title,size:'sm',body:`<p style="margin-top:0;line-height:1.9">${msg}</p>${input?`<label class="f">${esc(input)}<input id="cbin"></label>`:''}`,footer:`<button class="btn ${danger?'d':'p'}" id="cby">${ok}</button><button class="btn" id="cbn">انصراف</button>`});
 const done=v=>{const val=$('#cbin',w)?.value||'';closeModal(w);res(input?(v?{ok:true,value:val}:false):v)};$('#cby',w).onclick=()=>done(true);$('#cbn',w).onclick=()=>done(false);w.querySelector('[data-act=mclose]').onclick=()=>done(false)})}
/* فرم */
function formData(f){const o={};$$('[name]',f).forEach(e=>{if(e.type==='checkbox')o[e.name]=e.checked;else if(e.type==='file')o[e.name]=e.files;else o[e.name]=e.value.trim?e.value.trim():e.value});return o}
function formErr(f,msg){let e=$('.ferr',f);if(!e){e=document.createElement('div');e.className='ferr';e.setAttribute('role','alert');f.prepend(e)}e.textContent=msg;e.scrollIntoView({block:'nearest'})}
async function guard(f,fn){const btn=$('button[type=submit]',f);if(btn)btn.disabled=true;try{$('.ferr',f)?.remove();await fn()}catch(e){console.error(e);formErr(f,e.message||'خطای نامشخص');if(!e.code||e.code!=='CREDIT')toast(e.message||'خطا','err')}finally{if(btn)btn.disabled=false}}
/* تاریخ: سه فیلد سال/ماه/روز */
function dateField(name,val,{optional=false,ch=''}={}){const v=val||(optional?null:D.today());const t=D.today().y;
 const ys=[];for(let y=t-12;y<=t+8;y++)ys.push(y);if(v&&!ys.includes(v.y))ys.push(v.y);ys.sort((a,b)=>a-b);
 const md=v?D.mdays(v.y,v.m):31;
 return `<div class="dfield" data-df="${name}" data-opt="${optional?1:0}" ${ch?`data-ch="${ch}"`:''}><select data-p="y" aria-label="سال">${optional?'<option value="">سال</option>':''}${ys.map(y=>`<option value="${y}" ${v&&v.y===y?'selected':''}>${D.fa2(y)}</option>`).join('')}</select><select data-p="m" aria-label="ماه">${optional?'<option value="">ماه</option>':''}${D.MN.map((n,i)=>`<option value="${i+1}" ${v&&v.m===i+1?'selected':''}>${D.fa2(D.p2(i+1))} - ${n}</option>`).join('')}</select><select data-p="d" aria-label="روز">${optional?'<option value="">روز</option>':''}${Array.from({length:md},(_,i)=>`<option value="${i+1}" ${v&&v.d===i+1?'selected':''}>${D.fa2(D.p2(i+1))}</option>`).join('')}</select></div>`}
function fixDays(df){const y=+df.querySelector('[data-p=y]').value,m=+df.querySelector('[data-p=m]').value,ds=df.querySelector('[data-p=d]');if(!y||!m)return;const mx=D.mdays(y,m);const cur=ds.value;
 const opt=df.dataset.opt==='1';ds.innerHTML=(opt?'<option value="">روز</option>':'')+Array.from({length:mx},(_,i)=>`<option value="${i+1}">${D.fa2(D.p2(i+1))}</option>`).join('');ds.value=cur&&+cur<=mx?cur:(opt&&!cur?'':String(mx))}
function initDates(root){$$('.dfield',root).forEach(fixDays)}
function readDate(root,name,{optional=false,label='تاریخ'}={}){const df=$(`[data-df="${name}"]`,root);const y=df.querySelector('[data-p=y]').value,m=df.querySelector('[data-p=m]').value,d=df.querySelector('[data-p=d]').value;
 if(!y&&!m&&!d&&optional)return null;if(!y||!m||!d)throw E(`${label} را کامل (سال، ماه و روز) انتخاب کنید.`);return D.make(y,m,d)}
function setDate(root,name,dt){const df=$(`[data-df="${name}"]`,root);df.querySelector('[data-p=y]').value=dt.y;df.querySelector('[data-p=m]').value=dt.m;fixDays(df);df.querySelector('[data-p=d]').value=dt.d}
/* جدول با صفحه‌بندی */
const PG={};
function tbl(cols,rows,{id='t',empty,foot='',size=40}={}){
 if(!rows.length)return emptyBox(empty);const pg=PG[id]||0;const pages=Math.ceil(rows.length/size);const p=Math.min(pg,pages-1);const part=rows.slice(p*size,p*size+size);
 return `<div class="tw"><table><thead><tr>${cols.map(c=>`<th class="${c.cls||''}">${c.h}</th>`).join('')}</tr></thead><tbody>${part.map((r,i)=>`<tr>${cols.map(c=>`<td class="${c.cls||''}">${c.f(r,p*size+i)}</td>`).join('')}</tr>`).join('')}</tbody>${foot?`<tfoot>${foot}</tfoot>`:''}</table></div>
 ${pages>1?`<div class="pg"><button class="btn s" data-act="pg" data-id="${id}" data-d="-1" ${p===0?'disabled':''}>قبلی</button><span>صفحه ${num(p+1)} از ${num(pages)} (${num(rows.length)} مورد)</span><button class="btn s" data-act="pg" data-id="${id}" data-d="1" ${p>=pages-1?'disabled':''}>بعدی</button></div>`:`<div class="pg">${num(rows.length)} مورد</div>`}`}
ACT.pg=el=>{PG[el.dataset.id]=Math.max(0,(PG[el.dataset.id]||0)+Number(el.dataset.d));if(window.CUR&&CUR.refresh)CUR.refresh()};
/* خروجی CSV و چاپ */
function download(name,content,type='text/plain'){const b=new Blob([content],{type:type+';charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{a.remove();URL.revokeObjectURL(a.href)},500)}
function csvDownload(name,head,rows){const q=v=>{v=v==null?'':String(v);return /[",\n\r]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v};
 download(name,'\ufeff'+[head,...rows].map(r=>r.map(q).join(',')).join('\r\n'),'text/csv')}
const faToLatin=s=>toEn(s).replace(/٫/g,'.');
function printCSS(thermal){const _st=$('style#main');const fonts=_st?_st.textContent.split(':root{')[0]:'';
 return fonts+`*{box-sizing:border-box}body{font-family:Vazirmatn,Tahoma;margin:0;color:#000;direction:rtl;font-size:${thermal?'11px':'12.5px'};line-height:1.6}
 @page{size:${thermal?SET().thermal+'mm auto':'A4'};margin:${thermal?'3mm':'12mm'}}
 .doc{padding:${thermal?'0':'4px'};${thermal?`width:${SET().thermal-8}mm`:''}}h1{font-size:${thermal?'14px':'20px'};margin:0}h2{font-size:${thermal?'12px':'15px'};margin:6px 0}
 .hd2{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #000;padding-bottom:6px;margin-bottom:8px;${thermal?'flex-direction:column;text-align:center;align-items:center':''}}
 table{width:100%;border-collapse:collapse;margin:6px 0}th,td{border:1px solid #888;padding:${thermal?'2px 3px':'4px 6px'};text-align:right}th{background:#eee}td.n,th.n{text-align:left}
 .tot{margin-top:6px;width:${thermal?'100%':'55%'};margin-inline-start:auto}.tot div{display:flex;justify-content:space-between;padding:2px 0}.tot .b{font-weight:700;border-top:1px solid #000;font-size:1.1em}
 .sig{display:flex;justify-content:space-around;margin-top:30px}.sm{color:#444;font-size:.9em}`}
function docHTML(title,body,thermal){return `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>${esc(title)}</title><style>${printCSS(thermal)}</style></head><body><div class="doc">${body}</div></body></html>`}
function printDoc(title,body,thermal=false){const f=document.createElement('iframe');f.style.cssText='position:fixed;width:0;height:0;border:0;right:0;bottom:0';document.body.appendChild(f);
 f.contentDocument.open();f.contentDocument.write(docHTML(title,body,thermal));f.contentDocument.close();
 const go=()=>{try{f.contentWindow.focus();f.contentWindow.print()}catch(e){toast('چاپ ناموفق بود؛ از دکمه «ذخیره نسخه چاپی» استفاده کنید.','err')}setTimeout(()=>f.remove(),60000)};
 (f.contentDocument.fonts?.ready||Promise.resolve()).then(()=>setTimeout(go,150))}
function saveDoc(title,body,thermal){download(title.replace(/[\\/:*?"<>|\s]+/g,'_')+'.html',docHTML(title,body,thermal),'text/html')}
const shopHead=sub=>{const s=SET();return `<div class="hd2">${s.logo?`<img src="${s.logo}" style="width:56px;height:56px;object-fit:contain;border-radius:10px;border:1px solid #888">`:''}<div><h1>${esc(s.shop)}</h1><div class="sm">${esc(s.address)} ${esc(s.phone)}</div></div><div style="text-align:left"><h2>${esc(sub)}</h2><div class="sm">تاریخ چاپ: ${D.fmt(D.today())}</div></div></div>`};
async function readImage(file,max=800){return new Promise((res,rej)=>{if(!file)return res('');if(!file.type.startsWith('image/'))return rej(E('فقط فایل تصویر مجاز است.'));const r=new FileReader();r.onerror=()=>rej(E('خواندن تصویر ناموفق بود'));
 r.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,max/Math.max(im.width,im.height));const c=document.createElement('canvas');c.width=im.width*k;c.height=im.height*k;c.getContext('2d').drawImage(im,0,0,c.width,c.height);res(c.toDataURL('image/jpeg',.8))};im.onerror=()=>rej(E('تصویر معتبر نیست'));im.src=r.result};r.readAsDataURL(file)})}
/* نمودار */
const CH={};
function mkChart(id,cfg){const el=document.getElementById(id);if(!el)return;if(CH[id])CH[id].destroy();
 if(!window.Chart){el.parentElement.innerHTML=emptyBox('کتابخانه نمودار بارگذاری نشد.');return}
 CH[id]=new Chart(el,cfg)}
function chartBase(){Chart.defaults.font.family='Vazirmatn';Chart.defaults.color='#A1A1A1';Chart.defaults.borderColor='#262626'}
const GOLD='#D4AF37',GOLD2='#F5D76E';
const chOpts=(o={})=>({responsive:true,maintainAspectRatio:false,locale:'fa-IR',plugins:{legend:{display:!!o.legend,rtl:true,labels:{font:{family:'Vazirmatn'}}},tooltip:{rtl:true,textDirection:'rtl',titleFont:{family:'Vazirmatn'},bodyFont:{family:'Vazirmatn'},callbacks:{label:c=>(c.dataset.label?c.dataset.label+': ':'')+(o.fmt?o.fmt(c.parsed.y??c.parsed.x??c.parsed):num(c.parsed.y??c.parsed))}}},scales:o.noScale?{}:{x:{reverse:!o.horizontal,grid:{display:false}},y:{position:'right',beginAtZero:true,ticks:{callback:v=>v>=1e6?num(v/1e6)+' م':num(v)}}},...(o.extra||{})});
function chartCard(id,title,has=true){return `<div class="card"><h3>${title}</h3><div class="chart">${has?`<canvas id="${id}"></canvas>`:emptyBox('داده‌ای برای نمایش وجود ندارد.','chart')}</div></div>`}
/* رویدادهای سراسری */
document.addEventListener('click',e=>{const el=e.target.closest('[data-act]');if(!el)return;const f=ACT[el.dataset.act];if(!f)return;e.preventDefault();Promise.resolve(f(el,e)).catch(err=>{console.error(err);toast(err.message||'خطا','err')})});
document.addEventListener('input',e=>{const el=e.target;if(el.classList?.contains('money')){const raw=toEn(el.value).replace(/[^\d]/g,'');el.value=raw?num(Number(raw)):''}
 const h=el.closest('[data-in]');if(h&&INP[h.dataset.in])INP[h.dataset.in](el,e)});
document.addEventListener('change',e=>{const el=e.target;const df=el.closest('.dfield');if(df&&el.dataset.p!=='d')fixDays(df);const h=el.closest('[data-ch]');if(h&&INP[h.dataset.ch])INP[h.dataset.ch](el,e)});
document.addEventListener('submit',e=>{const f=e.target.closest('form[data-form]');if(!f)return;e.preventDefault();const h=FORM[f.dataset.form];if(h)guard(f,()=>h(f,e))});

const PAGES={};const CUR={key:'',q:{},refresh(){render()}};

/* ============ داشبورد ============ */
const DS={mode:'30',from:null,to:null};
function dsRange(){const t=D.todayJ(),td=D.today();
 if(DS.mode==='7')return[t-6,t];if(DS.mode==='month')return[D.j2d(td.y,td.m,1),t];if(DS.mode==='year')return[D.j2d(td.y,1,1),t];
 if(DS.mode==='custom'&&DS.from&&DS.to)return[DS.from.j,DS.to.j];return[t-29,t]}
const statCard=(l,v,c='',sub='',go2='')=>`<div class="stat ${c}" ${go2?`data-act="gsgo" data-to="${go2}" style="cursor:pointer"`:''}><small>${l}</small><b>${v}</b>${sub?`<em>${sub}</em>`:''}</div>`;
PAGES.dashboard=(el)=>{
 const t=D.todayJ(),td=D.today(),m1=D.j2d(td.y,td.m,1);let[f,to]=dsRange();
 const tdS=salesAgg(t,t),mS=salesAgg(m1,t),cfT=cashFlow(t,t),tot=totals();
 const checks=L('checks'),open=checks.filter(checkOpen),stt=c=>checkState(c).k;
 const near=open.filter(c=>stt(c)==='near'),over=open.filter(c=>stt(c)==='overdue');
 const loans=L('loans').filter(l=>l.status!=='void').map(l=>({l,i:loanInfo(l)})).filter(x=>x.i.remaining>0);
 const loanOut=sum(loans.filter(x=>x.l.kind==='out'),x=>x.i.remaining),loanIn=sum(loans.filter(x=>x.l.kind==='in'),x=>x.i.remaining);
 const low=lowStock();
 const expMonth=expenseSum(m1,t);
 const alerts=[];
 over.forEach(c=>alerts.push(['err',`چک ${c.type==='in'?'دریافتی':'پرداختی'} ${c.number} (${money(c.amount)}) سررسید شده است`,'checks?q='+encodeURIComponent(c.number)]));
 near.forEach(c=>alerts.push(['warn',`چک ${c.number} (${money(c.amount)}) ${remainText(c)} - ${D.fmt(c.dueDate)}`,'checks?q='+encodeURIComponent(c.number)]));
 loans.filter(x=>x.i.overdue).forEach(x=>alerts.push(['err',`قرض معوق ${x.l.no}: ${nameOfC(x.l.customerId)} - مانده ${money(x.i.remaining)}`,'loans?q='+x.l.no]));
 if(low.length)alerts.push(['warn',`${num(low.length)} کالا کم‌موجود است: ${low.slice(0,4).map(p=>p.name).join('، ')}`,'products?low=1']);
 if(SET().backupRemind&&D.fromJS(SET().lastBackup||0).j<t&&(L('sales').length||L('customers').length))alerts.push(['warn','امروز پشتیبان‌گیری انجام نشده است.','backup']);
 const upcoming=[...open.filter(c=>c.dueDate.j>=t&&c.dueDate.j<=t+14).map(c=>({j:c.dueDate.j,t:`چک ${c.type==='in'?'دریافتی':'پرداختی'} ${c.number} - ${partyName(c)}`,a:c.amount,to:'checks?q='+encodeURIComponent(c.number)})),
  ...loans.filter(x=>x.l.dueDate&&x.l.dueDate.j>=t&&x.l.dueDate.j<=t+14).map(x=>({j:x.l.dueDate.j,t:`قرض ${x.l.kind==='out'?'پرداختی':'دریافتی'} ${x.l.no} - ${nameOfC(x.l.customerId)}`,a:x.i.remaining,to:'loans?q='+x.l.no}))].sort((a,b)=>a.j-b.j);
 const recent=L('audit').sort((a,b)=>b.ts-a.ts).slice(0,8);
 const has=L('sales').length||L('inventory').length||L('payments').length;
 el.innerHTML=`<div class="hd"><h2>مرکز کنترل ${esc(SET().shop)} <small class="mu">${D.wd(t)} ${D.fmt(td)}</small></h2>
 ${can('sale')?`<button class="btn p" data-act="goto" data-to="sale">${ic('cart')} ثبت فروش</button>`:''}
 ${can('products')?`<button class="btn" data-act="qprod">${ic('box')} افزودن کالا</button>`:''}
 ${can('customers')?`<button class="btn" data-act="qcust">${ic('users')} ثبت مشتری</button>`:''}
 ${can('loans')?`<button class="btn" data-act="qloan">${ic('dollar')} ثبت قرض</button>`:''}
 ${can('checks')?`<button class="btn" data-act="qcheck">${ic('check')} ثبت چک</button>`:''}
 ${can('payments')?`<button class="btn" data-act="qpay">${ic('card')} ثبت پرداخت</button>`:''}</div>
 <div class="stats">
 ${statCard('فروش امروز',money(tdS.total),'',`${num(tdS.count)} فاکتور`)}
 ${statCard('فروش این ماه',money(mS.total),'',`${num(mS.count)} فاکتور`)}
 ${statCard('مجموع دریافتی امروز',money(cfT.inn),'ok')}
 ${statCard('مجموع پرداختی امروز',money(cfT.out),'warn')}
 ${statCard('سود ناخالص امروز',money(tdS.profit),tdS.profit<0?'err':'ok')}
 ${statCard('سود ناخالص ماهانه',money(mS.profit),mS.profit<0?'err':'ok')}
 ${statCard('بدهی مشتریان به فروشگاه',money(tot.rec),'err','طلب فروشگاه (فاکتور و قرض)','customers?f=debtor')}
 ${statCard('بدهی فروشگاه به مشتریان',money(tot.pay),'warn',`اعتبار مشتریان: ${money(tot.credit)}`,'customers?f=creditor')}
 ${statCard('ارزش فعلی انبار',money(stockValue()),'','به بهای میانگین موزون','inventory')}
 ${statCard('کالاهای کم‌موجود',num(low.length),low.length?'warn':'','','products?low=1')}
 ${statCard('مشتریان فعال',num(L('customers').filter(c=>c.active).length),'','','customers')}
 ${statCard('چک‌های در انتظار',num(open.length),'',money(sum(open,c=>c.amount)),'checks')}
 ${statCard('چک‌های نزدیک به سررسید',num(near.length),near.length?'warn':'',money(sum(near,c=>c.amount)),'checks?s=near')}
 ${statCard('چک‌های سررسیدشده',num(over.length),over.length?'err':'',money(sum(over,c=>c.amount)),'checks?s=overdue')}
 ${statCard('قرض‌های باز',num(loans.length),'',`داده‌شده: ${money(loanOut)} | گرفته‌شده: ${money(loanIn)}`,'loans')}
 ${statCard('مجموع هزینه‌های ماه',money(expMonth),'warn',`کل ثبت‌شده: ${money(expenseSum())}`,'payments?tab=exp')}
 </div>
 <div class="card" style="margin-bottom:14px"><div class="tb" style="margin:0"><label class="f sm">بازه نمودارها${sel('mode',[['7','۷ روز اخیر'],['30','۳۰ روز اخیر'],['month','این ماه'],['year','امسال'],['custom','بازه دلخواه شمسی']],DS.mode,'data-ch="dsmode"')}</label>
 ${DS.mode==='custom'?`<div id="dsc" class="tb" style="margin:0">${fld('از تاریخ',dateField('dsf',DS.from||D.fromJ(t-29)),'sm')}${fld('تا تاریخ',dateField('dst',DS.to||td),'sm')}<button class="btn p" data-act="dsapply">اعمال</button></div>`:''}
 <span class="mu">بازه: ${D.fmt(D.fromJ(f))} تا ${D.fmt(D.fromJ(to))}</span></div></div>
 ${!has?`<div class="card" style="margin-bottom:14px">${emptyBox('هنوز تراکنشی ثبت نشده است. با افزودن کالا، مشتری و ثبت اولین فروش، نمودارها و آمار اینجا ساخته می‌شود.','chart')}</div>`:''}
 <div class="grid g2" style="margin-bottom:14px">${chartCard('c1','فروش روزانه')}${chartCard('c4','مقایسه فروش و دریافتی')}</div>
 <div class="grid g3" style="margin-bottom:14px">${chartCard('c2','فروش هفتگی (۸ هفته اخیر)')}${chartCard('c3','فروش ماهانه (۱۲ ماه اخیر)')}${chartCard('c5','سود ناخالص روزانه')}</div>
 <div class="grid g2" style="margin-bottom:14px">${chartCard('c6','روند طلب فروشگاه از مشتریان (مانده حساب)')}${chartCard('c7','محصولات پرفروش (بر اساس مبلغ)')}</div>
 <div class="grid g2" style="margin-bottom:14px">${chartCard('c8','وضعیت چک‌ها')}${chartCard('c9','ورود و خروج انبار (کیلو)')}</div>
 <div class="grid g3"><div class="card"><h3>${ic('alert')} هشدارهای مهم</h3>${alerts.length?alerts.slice(0,10).map(a=>`<div style="padding:6px 0;border-bottom:1px solid var(--line);cursor:pointer" data-act="gsgo" data-to="${esc(a[2])}">${badge(a[0]==='err'?'فوری':'توجه',a[0])} ${esc(a[1])}</div>`).join(''):emptyBox('هشدار فعالی وجود ندارد.','check')}</div>
 <div class="card"><h3>${ic('clock')} سررسیدهای نزدیک (۱۴ روز)</h3>${upcoming.length?upcoming.slice(0,10).map(u=>`<div style="padding:6px 0;border-bottom:1px solid var(--line);cursor:pointer" data-act="gsgo" data-to="${esc(u.to)}"><b>${D.fmt(D.fromJ(u.j))}</b> ${esc(u.t)} <span class="gold">${money(u.a)}</span></div>`).join(''):emptyBox('سررسید نزدیکی وجود ندارد.','clock')}</div>
 <div class="card"><h3>فعالیت‌های اخیر</h3>${recent.length?recent.map(a=>`<div style="padding:6px 0;border-bottom:1px solid var(--line)"><b>${esc(a.action)}</b> <span class="mu">${esc(a.details)}</span><br><small class="mu">${esc(a.userName||'')} · ${D.fmt(D.fromJS(a.ts))} ${new Date(a.ts).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'})}</small></div>`).join(''):emptyBox('فعالیتی ثبت نشده است.')}</div></div>`;
 dashCharts(f,to)};
INP.dsmode=el=>{DS.mode=el.value;CUR.refresh()};
ACT.dsapply=el=>{const r=$('#view');DS.from=readDate(r,'dsf');DS.to=readDate(r,'dst');if(DS.to.j<DS.from.j)throw E('تاریخ پایان نباید قبل از تاریخ شروع باشد.');CUR.refresh()};
ACT.goto=el=>go(el.dataset.to);
ACT.qprod=()=>openProductForm();ACT.qcust=()=>openCustomerForm();ACT.qloan=()=>openLoanForm();ACT.qcheck=()=>openCheckForm();ACT.qpay=()=>openPaymentForm();
function dashCharts(f,to){
 const lim=Math.max(f,to-119);const days=[];for(let j=lim;j<=to;j++)days.push(j);const lab=days.map(j=>{const d=D.fromJ(j);return D.fa2(d.d)+' '+D.mn(d.m)});
 const sMap=new Map(),pMap=new Map(),cMap=new Map();
 activeSales().forEach(s=>{if(s.date.j<lim||s.date.j>to)return;sMap.set(s.date.j,(sMap.get(s.date.j)||0)+s.total);pMap.set(s.date.j,(pMap.get(s.date.j)||0)+s.total-s.cogs)});
 L('payments').forEach(p=>{const c=cashInfo(p);if(c&&p.dir==='in'&&c.j>=lim&&c.j<=to)cMap.set(c.j,(cMap.get(c.j)||0)+p.amount)});
 const hasS=activeSales().length>0;
 const ds=(l,m,col)=>({label:l,data:days.map(j=>m.get(j)||0),backgroundColor:col,borderColor:col,borderRadius:4});
 mkChart('c1',{type:'line',data:{labels:lab,datasets:[{...ds('فروش',sMap,GOLD),fill:true,backgroundColor:'rgba(212,175,55,.15)',tension:.3,pointRadius:2}]},options:chOpts()});
 mkChart('c4',{type:'bar',data:{labels:lab,datasets:[ds('فروش',sMap,GOLD),ds('دریافتی',cMap,'#16A34A')]},options:chOpts({legend:true})});
 mkChart('c5',{type:'bar',data:{labels:lab,datasets:[ds('سود ناخالص',pMap,GOLD2)]},options:chOpts()});
 // هفتگی
 const wk=Math.floor((D.todayJ()+2)/7);const wl=[],wd=[];for(let i=7;i>=0;i--){const w=wk-i;const a=w*7-2,b=a+6;wl.push(D.fa2(D.fromJ(a).d)+' '+D.mn(D.fromJ(a).m));wd.push(salesAgg(a,b).total)}
 mkChart('c2',{type:'bar',data:{labels:wl,datasets:[{label:'فروش هفته',data:wd,backgroundColor:GOLD,borderRadius:4}]},options:chOpts()});
 const ml=[],md=[];const t0=D.firstOfMonth(D.today());for(let i=11;i>=0;i--){const d=D.addM(t0,-i);ml.push(D.mn(d.m));md.push(salesAgg(D.j2d(d.y,d.m,1),D.j2d(d.y,d.m,D.mdays(d.y,d.m))).total)}
 mkChart('c3',{type:'bar',data:{labels:ml,datasets:[{label:'فروش ماه',data:md,backgroundColor:GOLD2,borderRadius:4}]},options:chOpts()});
 // روند طلب
 const net=new Map();let base=0;L('ledger').forEach(e=>{if(e.acct!=='R')return;const v=e.debit-e.credit;if(e.date.j<lim)base+=v;else if(e.date.j<=to)net.set(e.date.j,(net.get(e.date.j)||0)+v)});
 let run=base;const trend=days.map(j=>(run+=net.get(j)||0));
 mkChart('c6',{type:'line',data:{labels:lab,datasets:[{label:'مانده طلب',data:trend,borderColor:'#DC2626',backgroundColor:'rgba(220,38,38,.12)',fill:true,tension:.25,pointRadius:1}]},options:chOpts()});
 // پرفروش
 const pm=new Map();activeSales().forEach(s=>{if(s.date.j<f||s.date.j>to)return;s.items.forEach(i=>pm.set(i.productId,(pm.get(i.productId)||0)+i.amount))});
 const top=[...pm].sort((a,b)=>b[1]-a[1]).slice(0,8);
 if(top.length)mkChart('c7',{type:'bar',data:{labels:top.map(x=>nameOfP(x[0])),datasets:[{label:'فروش',data:top.map(x=>x[1]),backgroundColor:GOLD,borderRadius:4}]},options:{...chOpts({horizontal:true}),indexAxis:'y',scales:{x:{reverse:true,beginAxisAtZero:true,ticks:{callback:v=>v>=1e6?num(v/1e6)+' م':num(v)}},y:{position:'right',grid:{display:false}}}}});
 else $('#c7').parentElement.innerHTML=emptyBox('در این بازه فروشی ثبت نشده است.','chart');
 // چک
 const cc={wait:0,near:0,overdue:0,done:0,bounced:0,void:0};L('checks').forEach(c=>cc[checkState(c).k]++);
 const cl=[['wait','در انتظار','#D4AF37'],['near','نزدیک سررسید','#F59E0B'],['overdue','سررسیدشده','#DC2626'],['done','وصول/پرداخت‌شده','#16A34A'],['bounced','برگشتی','#7f1d1d'],['void','باطل','#555']].filter(x=>cc[x[0]]);
 if(cl.length)mkChart('c8',{type:'doughnut',data:{labels:cl.map(x=>x[1]),datasets:[{data:cl.map(x=>cc[x[0]]),backgroundColor:cl.map(x=>x[2]),borderColor:'#141414'}]},options:{...chOpts({legend:true,noScale:true}),cutout:'60%'}});
 else $('#c8').parentElement.innerHTML=emptyBox('چکی ثبت نشده است.','check');
 // انبار
 const im=new Map(),om=new Map();L('inventory').forEach(m=>{if(m.date.j<lim||m.date.j>to)return;const w=m.qty/1000;if(m.qty>0)im.set(m.date.j,(im.get(m.date.j)||0)+w);else om.set(m.date.j,(om.get(m.date.j)||0)-w)});
 mkChart('c9',{type:'bar',data:{labels:lab,datasets:[ds('ورود',im,'#16A34A'),ds('خروج',om,'#DC2626')]},options:chOpts({legend:true,fmt:v=>v.toLocaleString('fa-IR',{maximumFractionDigits:3})+' کیلو'})})}

/* ============ ثبت فروش ============ */
let SALE_ROW=0;
const payRowHtml=(i)=>`<div class="prow" data-pr="${i}"><select name="pm" data-ch="pmsel" aria-label="روش پرداخت">${['cash','pos','card','check','transfer','credit'].map(k=>`<option value="${k}">${METHODS[k]}</option>`).join('')}</select><input name="pa" class="money" inputmode="numeric" placeholder="مبلغ" data-in="recalc"><input name="pt" placeholder="شماره پیگیری"><button type="button" class="btn s d" data-act="delprow" aria-label="حذف">${ic('x')}</button>
 <div class="ck">${fld('شماره چک',`<input name="ck_n">`)}${fld('بانک',`<input name="ck_b">`)}${fld('صاحب حساب',`<input name="ck_o">`)}${fld('شناسه صیادی',`<input name="ck_s">`)}${fld('سررسید',dateField('ckd'+i,D.fromJ(D.todayJ()+30)))}</div></div>`;
INP.pmsel=el=>{el.closest('.prow').classList.toggle('ischeck',el.value==='check');}
ACT.delprow=el=>{el.closest('.prow').remove();recalcSale()};
ACT.addprow=el=>{const box=$('#prows');box.insertAdjacentHTML('beforeend',payRowHtml(++SALE_ROW));initDates(box)};
const priceOf=(p,type)=>(type==='sellPrice'?p.sellPrice:p[type])||p.sellPrice;
function lineHtml(p,qty,price){return `<div class="line" data-pid="${p.id}"><div class="nm"><b>${esc(p.name)}</b><br><small class="mu">موجودی: <span class="stk">${qtyf(stockOf(p.id),p.unit)}</span> · ${esc(p.unit)}</small></div>
 <input name="q" inputmode="decimal" placeholder="مقدار (${p.unit===WU?'کیلو':p.unit})" value="${qty?(qty/1000).toLocaleString('fa-IR',{minimumFractionDigits:3,maximumFractionDigits:3,useGrouping:false}):''}" data-in="recalc" aria-label="مقدار">
 <input name="u" class="money" inputmode="numeric" value="${num(price)}" data-in="recalc" aria-label="قیمت واحد"><b class="gold amt" style="text-align:end">۰</b><button type="button" class="btn s d" data-act="delline" aria-label="حذف ردیف">${ic('trash')}</button></div>`}
ACT.delline=el=>{el.closest('.line').remove();recalcSale()};
ACT.pickp=el=>{const p=G('products',el.dataset.id);const box=$('#lines');const ex=$(`.line[data-pid="${p.id}"]`,box);if(ex){const q=$('[name=q]',ex);q.focus();q.select();return}
 box.insertAdjacentHTML('beforeend',lineHtml(p,0,priceOf(p,$('[name=ptype]').value)));const q=$('[name=q]',box.lastElementChild);q.focus();recalcSale()};
function saleState(root){const items=$$('.line',root).map(l=>({productId:l.dataset.pid,qty:pQty($('[name=q]',l).value),unitPrice:pMoney($('[name=u]',l).value)}));
 return{items,discount:pMoney($('[name=disc]',root).value)||0,extra:pMoney($('[name=extra]',root).value)||0}}
function recalcSale(){const root=$('#saleform');if(!root)return;const s=saleState(root);let sub=0;
 $$('.line',root).forEach((l,i)=>{const it=s.items[i];const a=(it.qty>0&&it.unitPrice>=0)?Math.round(it.qty*it.unitPrice/1000):0;sub+=a;$('.amt',l).textContent=num(a)});
 const total=sub-s.discount+s.extra;$('#o_sub').textContent=money(sub);$('#o_total').textContent=money(total);
 const edit=root.dataset.edit;let paid=edit?paidOf('sale',edit):sum($$('[name=pa]',root),e=>pMoney(e.value)||0);
 $('#o_paid').textContent=money(paid);const rem=total-paid;const r=$('#o_rem');r.textContent=money(rem);r.className=rem>0?'neg':rem<0?'neg':'pos';
 $('#o_method').textContent=!paid?'نسیه':paid>=total&&total>0?(root.dataset.edit?'':'تسویه'):'پرداخت جزئی / ترکیبی'}
INP.recalc=recalcSale;
PAGES.sale=(el,q)=>{
 const edit=q.edit?G('sales',q.edit):null;if(q.edit&&(!edit||edit.status!=='active')){el.innerHTML=emptyBox('فاکتور قابل ویرایش نیست.');return}
 if(edit&&!can('edit_sale')){el.innerHTML=emptyBox('دسترسی ویرایش فاکتور ندارید.');return}
 const custs=L('customers').filter(c=>c.active||(edit&&c.id===edit.customerId));
 const prods=L('products').filter(p=>p.active);
 el.innerHTML=`<div class="hd"><h2>${edit?'ویرایش فاکتور '+edit.no:'ثبت فروش جدید'}</h2>${edit?`<button class="btn" data-act="goto" data-to="invoices">بازگشت</button>`:`<button class="btn" data-act="newcust">${ic('plus')} مشتری جدید</button>`}</div>
 ${!prods.length?`<div class="warnbox">هنوز کالایی تعریف نشده است. ابتدا از «مدیریت کالاها» کالا اضافه کنید.</div>`:''}
 <form id="saleform" data-form="sale" data-edit="${edit?edit.id:''}" class="salegrid">
 <div class="card"><div class="form">
 ${fld('مشتری',edit?`<input value="${esc(saleCustName(edit))}" disabled><input type="hidden" name="cust" value="${edit.customerId||''}">`:`<select name="cust" data-ch="custchg"><option value="">— مشتری روزانه / متفرقه (پرداخت کامل نقدی) —</option>${custs.map(c=>`<option value="${c.id}">${esc(c.name)}${c.phone?' - '+c.phone:''}</option>`).join('')}</select>`,'w2')}${edit?'':fld('نام مشتری روزانه (اختیاری، وقتی مشتری انتخاب نشده)',`<input name="walkname" placeholder="مثلا: مشتری روزانه، آقای محمدی…">`,'w2')}
 ${fld('تاریخ فاکتور',dateField('sdate',edit?.date||D.today()))}
 ${fld('نوع قیمت',sel('ptype',[['sellPrice','قیمت فروش'],['wholesale','عمده‌فروشی'],['retail','خرده‌فروشی']],edit?.priceType||'sellPrice'),'sm')}
 <div class="full" id="custinfo"></div></div>
 <h3 style="margin:14px 0 6px">افزودن کالا</h3>
 <input id="psearch" placeholder="جستجوی کالا (نام، کد، بارکد)…" data-in="psearch" autocomplete="off"><div class="pick" id="pick"></div>
 <h3 style="margin:14px 0 0">اقلام فاکتور</h3><div id="lines"></div><div id="nolines" class="empty" style="padding:16px">کالایی انتخاب نشده است؛ از فهرست بالا کالا را لمس کنید.</div></div>
 <div class="card" style="position:sticky;top:70px"><div class="form">${fld('تخفیف (تومان)',minp('disc',edit?.discount,'data-in="recalc"'))}${fld('هزینه اضافی (تومان)',minp('extra',edit?.extra,'data-in="recalc"'))}</div>
 <div class="sum" style="margin:12px 0"><div><span>جمع اقلام</span><b id="o_sub">۰</b></div><div class="t"><span>مبلغ نهایی</span><b id="o_total">۰</b></div><div><span>پرداخت‌شده</span><b id="o_paid">۰</b></div><div><span>مانده</span><b id="o_rem">۰</b></div><div><span>وضعیت</span><b id="o_method">—</b></div></div>
 ${edit?`<div class="warnbox">پرداخت‌های این فاکتور در بخش «پرداخت‌ها» یا صفحه فاکتور مدیریت می‌شود؛ ویرایش فاکتور پرداخت جدیدی ثبت نمی‌کند.</div>`:
 `<h3>پرداخت</h3><div id="prows">${payRowHtml(0)}</div><div class="fl" style="margin-bottom:8px"><button type="button" class="btn s" data-act="addprow">${ic('plus')} روش پرداخت دیگر</button><button type="button" class="btn s" data-act="payfull">پرداخت کامل نقدی</button><button type="button" class="btn s" data-act="payclear">نسیه (بدون پرداخت)</button></div>`}
 ${fld('توضیحات',`<textarea name="note">${esc(edit?.note||'')}</textarea>`)}
 <button class="btn p" type="submit" style="width:100%;justify-content:center;margin-top:10px">${ic('check')} ${edit?'ذخیره ویرایش':'ثبت فاکتور'}</button></div></form>`;
 initDates(el);
 const draw=()=>{const s=toEn($('#psearch').value).toLowerCase();const r=prods.filter(p=>!s||(p.name+p.code+p.barcode).toLowerCase().includes(s)).slice(0,60);
  $('#pick').innerHTML=r.map(p=>`<button type="button" data-act="pickp" data-id="${p.id}"><b>${esc(p.name)}</b><small>${money(priceOf(p,$('[name=ptype]').value))}</small><small>موجودی: ${qtyf(stockOf(p.id),p.unit)}</small></button>`).join('')||'<div class="mu">کالایی یافت نشد</div>'};
 INP.psearch=draw;draw();INP.ptypechg=null;
 if(edit){edit.items.forEach(i=>{const p=G('products',i.productId);$('#lines').insertAdjacentHTML('beforeend',lineHtml(p,i.qty,i.unitPrice))});}
 $('[name=ptype]').dataset.ch='ptype';INP.ptype=el2=>{draw();$$('.line').forEach(l=>{const p=G('products',l.dataset.pid);$('[name=u]',l).value=num(priceOf(p,el2.value))});recalcSale()};
 INP.custchg=el2=>{const c=G('customers',el2.value);$('#custinfo').innerHTML=c?(()=>{const b=custBal(c.id);return `<div class="fl"><span class="chip">بدهی فعلی<b class="${b.R>0?'neg':''}">${money(b.R)}</b></span><span class="chip">سقف اعتبار<b>${c.creditLimit?money(c.creditLimit):'نامحدود'}</b></span></div>`})():''};
 const obs=new MutationObserver(()=>{$('#nolines').style.display=$$('.line').length?'none':''});obs.observe($('#lines'),{childList:true});$('#nolines').style.display=edit?'none':'';
 recalcSale()};
ACT.newcust=()=>openCustomerForm(null,c=>{CUR.refresh();setTimeout(()=>{const s=$('[name=cust]');if(s){s.value=c.id;INP.custchg(s)}},0)});
ACT.payfull=()=>{const r=$('#saleform');const t=pMoney($('#o_total').textContent.replace(/[^\d۰-۹٬]/g,''))||0;const first=$('.prow');$('[name=pm]',first).value='cash';first.classList.remove('ischeck');$('[name=pa]',first).value=num(t);recalcSale()};
ACT.payclear=()=>{$$('.prow').forEach((r,i)=>{if(i)r.remove();else{$('[name=pa]',r).value=''}});recalcSale()};
FORM.sale=async f=>{const edit=f.dataset.edit;const s=saleState(f);const date=readDate(f,'sdate',{label:'تاریخ فاکتور'});
 s.items.forEach(i=>{if(!(i.qty>0))throw E('مقدار همه اقلام باید بزرگ‌تر از صفر باشد.');if(!(i.unitPrice>=0))throw E('قیمت واحد نامعتبر است.')});
 const base={items:s.items,discount:s.discount,extra:s.extra,date,note:$('[name=note]',f).value,priceType:$('[name=ptype]',f).value,customerId:$('[name=cust]',f).value||null,customerName:($('[name=walkname]',f)?.value||'').trim()};
 if(edit){await editSale(edit,base);toast('فاکتور با موفقیت ویرایش شد.');go('invoices?id='+edit);return}
 base.pays=$$('.prow',f).map(r=>{const m=$('[name=pm]',r).value;const amount=pMoney($('[name=pa]',r).value)||0;if(!amount)return null;
  const o={method:m,amount,tracking:$('[name=pt]',r).value};if(m==='check'){const id=r.dataset.pr;o.check={number:$('[name=ck_n]',r).value.trim(),bank:$('[name=ck_b]',r).value.trim(),owner:$('[name=ck_o]',r).value,sayad:$('[name=ck_s]',r).value,dueDate:readDate(r,'ckd'+id,{label:'سررسید چک'})}}return o}).filter(Boolean);
 let sale;try{sale=await createSale(base)}catch(e){if(e.code==='CREDIT'){if(await confirmBox(esc(e.message)+'<br>با این وجود فاکتور ثبت شود؟',{ok:'ثبت با اجازه مدیر',danger:true})){if(!can('neg_stock')&&A.user.role!=='admin')throw E('فقط مدیر می‌تواند از سقف اعتبار عبور کند.');sale=await createSale({...base,overrideCredit:true})}else return}else throw e}
 toast(`فاکتور ${sale.no} ثبت شد.`);CUR.refresh();showInvoice(sale.id,true)};

/* ============ فاکتورها ============ */
const IV={q:'',st:'all',c:'',from:null,to:null};
PAGES.invoices=(el,q)=>{
 if(q.id){setTimeout(()=>{showInvoice(q.id);history.replaceState(null,'','#/invoices')},0)}
 const custs=L('customers');
 el.innerHTML=`<div class="hd"><h2>فاکتورها</h2>${can('sale')?`<button class="btn p" data-act="goto" data-to="sale">${ic('plus')} فاکتور جدید</button>`:''}<button class="btn" data-act="ivcsv">${ic('download')} CSV</button></div>
 <div class="tb">${fld('جستجو',`<input id="ivq" value="${esc(IV.q)}" placeholder="شماره فاکتور یا نام مشتری" data-in="ivf">`,'w2')}${fld('وضعیت',sel('ivs',[['all','همه'],['open','دارای مانده'],['paid','تسویه‌شده'],['void','ابطال‌شده']],IV.st,'data-ch="ivf"'),'sm')}${fld('مشتری',`<select id="ivc" data-ch="ivf"><option value="">همه</option>${custs.map(c=>`<option value="${c.id}" ${IV.c===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>`,'sm')}
 ${fld('از تاریخ',dateField('ivf',IV.from,{optional:true,ch:'ivf'}),'')}${fld('تا تاریخ',dateField('ivt',IV.to,{optional:true,ch:'ivf'}),'')}</div><div id="ivt2"></div>`;
 initDates(el);const draw=()=>{const rows=ivRows();$('#ivt2').innerHTML=tbl([
  {h:'شماره',f:s=>`<a href="#/invoices?id=${s.id}" data-act="showinv" data-id="${s.id}"><b>${s.no}</b></a>`},{h:'تاریخ',f:s=>D.fmt(s.date)},{h:'مشتری',f:s=>esc(saleCustName(s))},
  {h:'مبلغ نهایی',cls:'n',f:s=>num(s.total)},{h:'پرداختی',cls:'n',f:s=>num(saleInfo(s).paid)},{h:'مانده',cls:'n',f:s=>{const r=saleInfo(s).remain;return `<span class="${r>0?'neg':''}">${num(r)}</span>`}},
  {h:'وضعیت',f:s=>s.status==='void'?badge('ابطال‌شده','err'):saleInfo(s).remain>0?badge('دارای مانده','warn'):badge('تسویه','ok')},
  {h:'عملیات',f:s=>`<div class="act"><button class="btn s" data-act="showinv" data-id="${s.id}">${ic('eye')}</button><button class="btn s" data-act="prinv" data-id="${s.id}" data-m="a4">${ic('printer')}</button></div>`}],rows,
  {id:'iv',empty:'فاکتوری یافت نشد.',foot:`<tr><td colspan="3">جمع (${num(rows.length)} فاکتور فعال و ابطالی)</td><td class="n">${num(sum(rows.filter(s=>s.status==='active'),s=>s.total))}</td><td class="n">${num(sum(rows.filter(s=>s.status==='active'),s=>saleInfo(s).paid))}</td><td class="n">${num(sum(rows,s=>saleInfo(s).remain))}</td><td colspan="2"></td></tr>`})};
 CUR.draw=draw;draw()};
function ivRows(){const q=toEn($('#ivq')?.value??IV.q).toLowerCase();IV.q=$('#ivq')?.value??IV.q;IV.st=$('[name=ivs]')?.value||IV.st;IV.c=$('#ivc')?.value??IV.c;
 try{IV.from=readDate($('#view'),'ivf',{optional:true});IV.to=readDate($('#view'),'ivt',{optional:true})}catch(e){}
 return L('sales').filter(s=>{if(IV.st==='void'&&s.status!=='void')return false;if(IV.st!=='void'&&IV.st!=='all'&&s.status==='void')return false;const r=saleInfo(s).remain;if(IV.st==='open'&&r<=0)return false;if(IV.st==='paid'&&r>0)return false;
  if(IV.c&&s.customerId!==IV.c)return false;if(IV.from&&s.date.j<IV.from.j)return false;if(IV.to&&s.date.j>IV.to.j)return false;
  return !q||(s.no+saleCustName(s)).toLowerCase().includes(q)}).sort((a,b)=>b.date.j-a.date.j||b.ts-a.ts)}
INP.ivf=()=>{PG.iv=0;CUR.draw()};
ACT.ivcsv=()=>{const r=ivRows();csvDownload('invoices.csv',['شماره','تاریخ','مشتری','جمع','تخفیف','هزینه اضافی','مبلغ نهایی','پرداختی','مانده','بهای تمام‌شده','سود','وضعیت','فروشنده'],r.map(s=>{const i=saleInfo(s);return[s.no,D.en(s.date),nameOfC(s.customerId),s.subtotal,s.discount,s.extra,s.total,i.paid,i.remain,s.cogs,s.total-s.cogs,s.status==='void'?'ابطال':'فعال',s.userName]}))};
ACT.showinv=el=>showInvoice(el.dataset.id);
ACT.prinv=el=>{const s=G('sales',el.dataset.id);printDoc('فاکتور '+s.no,invoiceBody(s,el.dataset.m==='th'),el.dataset.m==='th')};
ACT.svinv=el=>{const s=G('sales',el.dataset.id);saveDoc('فاکتور '+s.no,invoiceBody(s,el.dataset.m==='th'),el.dataset.m==='th')};
function invoiceBody(s,th){const c=G('customers',s.customerId);const i=saleInfo(s);const pays=(payIdx().get('sale:'+s.id)||[]);
 const b=c?custBal(c.id):null;
 return shopHead('فاکتور فروش '+s.no)+`<div>مشتری: <b>${esc(saleCustName(s))}</b> ${c?.phone?'· '+esc(c.phone):''} · تاریخ: <b>${D.fmt(s.date)}</b>${s.status==='void'?' · <b>(ابطال شده)</b>':''}</div>
 <table><thead><tr><th>#</th><th>کالا</th><th>مقدار</th><th class="n">قیمت واحد</th><th class="n">مبلغ</th></tr></thead><tbody>${s.items.map((it,k)=>`<tr><td>${num(k+1)}</td><td>${esc(it.name)}</td><td>${qtyf(it.qty,it.unit)}</td><td class="n">${num(it.unitPrice)}</td><td class="n">${num(it.amount)}</td></tr>`).join('')}</tbody></table>
 <div class="tot"><div><span>جمع اقلام</span><span>${money(s.subtotal)}</span></div>${s.discount?`<div><span>تخفیف</span><span>${money(s.discount)}</span></div>`:''}${s.extra?`<div><span>هزینه اضافی</span><span>${money(s.extra)}</span></div>`:''}<div class="b"><span>مبلغ نهایی</span><span>${money(s.total)}</span></div><div><span>پرداخت‌شده</span><span>${money(i.paid)}</span></div><div class="b"><span>مانده این فاکتور</span><span>${money(i.remain)}</span></div>${b&&!th?`<div><span>مانده کل حساب مشتری</span><span>${money(b.R)}</span></div>`:''}</div>
 ${pays.length&&!th?`<h2>پرداخت‌ها</h2><table><tr><th>تاریخ</th><th>روش</th><th class="n">مبلغ</th><th>شماره</th></tr>${pays.map(p=>`<tr><td>${D.fmt(p.date)}</td><td>${mlabel(p.method)}${p.voided?' (باطل)':''}</td><td class="n">${num(p.amount)}</td><td>${p.no}</td></tr>`).join('')}</table>`:''}
 ${s.note?`<div class="sm">توضیحات: ${esc(s.note)}</div>`:''}${th?'':'<div class="sig"><span>امضای فروشنده</span><span>امضای مشتری</span></div>'}`}
function showInvoice(id,justSaved){const s=G('sales',id);if(!s)return;const i=saleInfo(s);const pays=(payIdx().get('sale:'+s.id)||[]).sort((a,b)=>a.ts-b.ts);
 const w=modal({title:'فاکتور '+s.no+(s.status==='void'?' (ابطال‌شده)':''),size:'lg',body:`<div class="grid g3" style="margin-bottom:12px"><div class="kv"><span>مشتری</span><b>${esc(saleCustName(s))}</b><span>تاریخ</span><b>${D.fmt(s.date)}</b><span>ثبت‌کننده</span><b>${esc(s.userName||'')}</b></div>
 <div class="kv"><span>جمع اقلام</span><b>${money(s.subtotal)}</b><span>تخفیف</span><b>${money(s.discount)}</b><span>هزینه اضافی</span><b>${money(s.extra)}</b></div>
 <div class="kv"><span>مبلغ نهایی</span><b class="gold">${money(s.total)}</b><span>پرداخت‌شده</span><b class="pos">${money(i.paid)}</b><span>مانده</span><b class="${i.remain>0?'neg':''}">${money(i.remain)}</b></div></div>
 ${tbl([{h:'کالا',f:x=>esc(x.name)},{h:'مقدار',f:x=>qtyf(x.qty,x.unit)},{h:'قیمت واحد',cls:'n',f:x=>num(x.unitPrice)},{h:'مبلغ',cls:'n',f:x=>num(x.amount)},{h:'بهای تمام‌شده',cls:'n',f:x=>num(x.cogs)},{h:'سود',cls:'n',f:x=>`<span class="${colorNum(x.amount-x.cogs)}">${num(x.amount-x.cogs)}</span>`}],s.items,{id:'ivi',size:100})}
 <p>سود ناخالص فاکتور: <b class="${colorNum(s.total-s.cogs)}">${money(s.total-s.cogs)}</b> ${s.note?` · توضیحات: ${esc(s.note)}`:''}</p>
 <h3>پرداخت‌ها</h3>${pays.length?tbl([{h:'شماره',f:p=>p.no},{h:'تاریخ',f:p=>D.fmt(p.date)},{h:'روش',f:p=>mlabel(p.method)},{h:'مبلغ',cls:'n',f:p=>num(p.amount)},{h:'وضعیت',f:p=>p.voided?badge('باطل','err'):badge('معتبر','ok')}],pays,{id:'ivp',size:100}):emptyBox('پرداختی ثبت نشده (نسیه).','card')}
 <h3>تاریخچه تغییرات</h3>${tbl([{h:'زمان',f:h=>D.fmt(D.fromJS(h.ts))+' '+new Date(h.ts).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'})},{h:'کاربر',f:h=>esc(h.u||'')},{h:'عملیات',f:h=>esc(h.a)},{h:'مبلغ',cls:'n',f:h=>(h.before!=null?num(h.before)+' ← ':'')+num(h.total)}],s.history,{id:'ivh',size:100})}`,
 footer:`${s.status==='active'&&i.remain>0&&can('payments')?`<button class="btn p" data-act="inv_pay" data-id="${s.id}">${ic('card')} ثبت پرداخت</button>`:''}${s.status==='active'&&can('edit_sale')?`<button class="btn" data-act="inv_edit" data-id="${s.id}">${ic('edit')} ویرایش</button>`:''}
 <button class="btn" data-act="prinv" data-id="${s.id}" data-m="a4">${ic('printer')} چاپ A4</button><button class="btn" data-act="prinv" data-id="${s.id}" data-m="th">${ic('printer')} چاپ حرارتی</button><button class="btn" data-act="svinv" data-id="${s.id}" data-m="a4">${ic('download')} ذخیره نسخه چاپی</button>
 ${s.status==='active'&&can('cancel_sale')?`<button class="btn d" data-act="inv_cancel" data-id="${s.id}">${ic('trash')} ابطال فاکتور</button>`:''}`});return w}
ACT.inv_edit=el=>{closeModal();go('sale?edit='+el.dataset.id)};
ACT.inv_pay=el=>{closeModal();openPaymentForm({refType:'sale',refId:el.dataset.id})};
ACT.inv_cancel=async el=>{const s=G('sales',el.dataset.id);const r=await confirmBox(`فاکتور <b>${s.no}</b> ابطال شود؟<br>موجودی کالاها به انبار برمی‌گردد، بدهی ایجادشده معکوس می‌شود و پرداخت‌های ثبت‌شده این فاکتور نیز ابطال (وجه مرجوع) می‌گردد. این عملیات قابل بازگشت نیست.`,{ok:'ابطال فاکتور',danger:true,input:'دلیل ابطال'});
 if(!r)return;await cancelSale(s.id,r.value);toast('فاکتور ابطال شد و انبار و حساب اصلاح گردید.');closeModal();CUR.refresh()};

const partyName=c=>c.customerId?nameOfC(c.customerId):(G('suppliers',c.supplierId)?.name||'—');
const UNITS=[WU,'عدد','بسته'];
const dtime=ts=>D.fmt(D.fromJS(ts))+' '+new Date(ts).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'});
/* ============ کالاها ============ */
const PF={q:'',cat:'',sort:'name',low:false,st:'1'};
PAGES.products=(el,q)=>{if(q.low){PF.low=true;history.replaceState(null,'','#/products')}if(q.q){PF.q=q.q;history.replaceState(null,'','#/products')}
 el.innerHTML=`<div class="hd"><h2>مدیریت کالاها</h2>${can('products')?`<button class="btn p" data-act="qprod">${ic('plus')} افزودن کالا</button>`:''}<button class="btn" data-act="cats">دسته‌بندی‌ها</button><button class="btn" data-act="prodprint">${ic('printer')} چاپ فهرست</button><button class="btn" data-act="prodcsv">${ic('download')} CSV</button></div>
 <div class="tb">${fld('جستجو',`<input id="pfq" value="${esc(PF.q)}" placeholder="نام، کد یا بارکد" data-in="pf">`,'w2')}${fld('دسته‌بندی',`<select id="pfc" data-ch="pf"><option value="">همه</option>${L('categories').map(c=>`<option value="${c.id}" ${PF.cat===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>`,'sm')}
 ${fld('مرتب‌سازی',sel('pfs',[['name','نام'],['sell_asc','قیمت فروش (کم به زیاد)'],['sell_desc','قیمت فروش (زیاد به کم)'],['stock','موجودی'],['profit','سود هر واحد']],PF.sort,'data-ch="pf"'),'sm')}
 ${fld('وضعیت',sel('pfa',[['1','فعال'],['0','غیرفعال'],['all','همه']],PF.st,'data-ch="pf"'),'sm')}
 <label class="f sm" style="flex-direction:row;align-items:center;gap:6px;padding-bottom:8px"><input type="checkbox" id="pfl" style="width:auto" ${PF.low?'checked':''} data-ch="pf"> فقط کم‌موجود</label></div><div id="pt"></div>`;
 CUR.draw=()=>{const r=prodRows();$('#pt').innerHTML=tbl([{h:'',f:p=>p.image?`<img class="thumb" alt="" src="${p.image}">`:''},{h:'کد',f:p=>esc(p.code)},{h:'نام کالا',f:p=>`<b>${esc(p.name)}</b>`},{h:'دسته',f:p=>esc(catName(p.categoryId))},
  {h:'موجودی',cls:'n',f:p=>{const s=stockOf(p.id);return `<span class="${s<=p.minStock?'neg':''}">${qtyf(s,p.unit)}</span>`}},{h:'بهای میانگین',cls:'n',f:p=>num(p.avgCost)},{h:'آخرین خرید',cls:'n',f:p=>num(p.buyPrice)},{h:'قیمت فروش',cls:'n',f:p=>num(p.sellPrice)},
  {h:'سود هر واحد',cls:'n',f:p=>{const u=p.sellPrice-(p.avgCost||0);return `<span class="${colorNum(u)}">${num(u)}</span>`}},{h:'ارزش موجودی',cls:'n',f:p=>num(Math.max(0,stockOf(p.id))*(p.avgCost||0)/1000)},{h:'وضعیت',f:p=>p.active?badge('فعال','ok'):badge('غیرفعال','mu')},
  {h:'عملیات',f:p=>`<div class="act"><button class="btn s" data-act="pview" data-id="${p.id}" title="سوابق">${ic('eye')}</button>${can('products')?`<button class="btn s" data-act="pedit" data-id="${p.id}" title="ویرایش">${ic('edit')}</button><button class="btn s" data-act="ptoggle" data-id="${p.id}">${p.active?'غیرفعال':'فعال'}</button>`:''}</div>`}],r,
  {id:'pr',empty:'کالایی یافت نشد. با دکمه «افزودن کالا» شروع کنید.',foot:`<tr><td colspan="9">جمع ارزش موجودی (${num(r.length)} کالا)</td><td class="n">${num(sum(r,p=>Math.max(0,stockOf(p.id))*(p.avgCost||0)/1000))}</td><td colspan="2"></td></tr>`})};
 CUR.draw()};
function prodRows(){PF.q=$('#pfq')?.value??PF.q;PF.cat=$('#pfc')?.value??PF.cat;PF.sort=$('[name=pfs]')?.value||PF.sort;PF.st=$('[name=pfa]')?.value||PF.st;PF.low=$('#pfl')?.checked??PF.low;const q=toEn(PF.q).toLowerCase();
 let r=L('products').filter(p=>(PF.st==='all'||(PF.st==='1')===p.active)&&(!PF.cat||p.categoryId===PF.cat)&&(!q||(p.name+p.code+p.barcode).toLowerCase().includes(q))&&(!PF.low||lowStock().includes(p)));
 const s=PF.sort;r.sort((a,b)=>s==='sell_asc'?a.sellPrice-b.sellPrice:s==='sell_desc'?b.sellPrice-a.sellPrice:s==='stock'?stockOf(a.id)-stockOf(b.id):s==='profit'?(b.sellPrice-b.avgCost)-(a.sellPrice-a.avgCost):a.name.localeCompare(b.name,'fa'));return r}
INP.pf=()=>{PG.pr=0;CUR.draw()};
ACT.pedit=el=>openProductForm(el.dataset.id);
ACT.ptoggle=async el=>{const p=G('products',el.dataset.id);if(p.active&&!(await confirmBox(`کالای «${esc(p.name)}» غیرفعال شود؟ (در فاکتور جدید نمایش داده نمی‌شود)`)))return;const c=clone(p);c.active=!c.active;const ops=[{s:'products',put:c}];audit(ops,c.active?'فعال‌سازی کالا':'غیرفعال‌سازی کالا','product',c.id,c.name);await DB.commit(ops);toast('وضعیت کالا تغییر کرد.');CUR.refresh()};
ACT.prodcsv=()=>csvDownload('products.csv',['کد','بارکد','نام','دسته','واحد','موجودی','حداقل موجودی','بهای میانگین','آخرین قیمت خرید','قیمت فروش','عمده','خرده','ارزش موجودی','وضعیت'],prodRows().map(p=>[p.code,p.barcode,p.name,catName(p.categoryId),p.unit,stockOf(p.id)/1000,p.minStock/1000,p.avgCost,p.buyPrice,p.sellPrice,p.wholesale,p.retail,Math.round(Math.max(0,stockOf(p.id))*p.avgCost/1000),p.active?'فعال':'غیرفعال']));
ACT.prodprint=()=>{const r=prodRows();printDoc('فهرست کالاها',shopHead('فهرست کالاها و قیمت‌ها')+`<table><tr><th>کد</th><th>نام کالا</th><th>دسته</th><th>موجودی</th><th class="n">قیمت فروش</th></tr>${r.map(p=>`<tr><td>${esc(p.code)}</td><td>${esc(p.name)}</td><td>${esc(catName(p.categoryId))}</td><td>${qtyf(stockOf(p.id),p.unit)}</td><td class="n">${num(p.sellPrice)}</td></tr>`).join('')}</table>`)};
function openProductForm(id,cb){const p=id?G('products',id):null;const canP=!p||can('price_edit');
 const w=modal({title:p?'ویرایش کالا: '+p.name:'افزودن کالای جدید',size:'lg',body:`<form data-form="prod" data-id="${id||''}" class="form">
 ${fld('نام کالا *',inp('name',p?.name,'required'),'w2')}${fld('کد کالا (خودکار در صورت خالی)',inp('code',p?.code||''))}${fld('بارکد (اختیاری)',inp('barcode',p?.barcode||''))}
 ${fld('دسته‌بندی',`<select name="cat">${L('categories').map(c=>`<option value="${c.id}" ${p?.categoryId===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>`)}${fld('واحد اندازه‌گیری',sel('unit',UNITS,p?.unit||WU))}
 ${fld('قیمت خرید (آخرین، تومان)',minp('buy',p?.buyPrice,canP?'':'disabled'))}${fld('قیمت فروش (تومان)',minp('sell',p?.sellPrice,canP?'':'disabled'))}${fld('قیمت عمده‌فروشی',minp('whole',p?.wholesale,canP?'':'disabled'))}${fld('قیمت خرده‌فروشی',minp('retail',p?.retail,canP?'':'disabled'))}
 ${p?'':fld('موجودی اولیه',`<input name="open" inputmode="decimal" placeholder="مثلاً ۱۲٫۵۰۰">`)}${fld('حداقل موجودی هشدار',`<input name="min" inputmode="decimal" value="${p?(p.minStock/1000):''}" placeholder="مثلاً ۵">`)}
 ${fld('تأمین‌کننده',`<select name="sup"><option value="">—</option>${L('suppliers').filter(s=>s.active!==false).map(s=>`<option value="${s.id}" ${p?.supplierId===s.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`)}${fld('تاریخ ثبت',dateField('rdate',p?.regDate||D.today()))}
 ${fld('تصویر (اختیاری)','<input type="file" name="img" accept="image/*">')}<label class="f" style="flex-direction:row;align-items:center;gap:8px;justify-content:flex-start;padding-top:20px"><input type="checkbox" name="active" style="width:auto" ${!p||p.active?'checked':''}> کالای فعال</label>
 ${fld('توضیحات',`<textarea name="desc">${esc(p?.desc||'')}</textarea>`,'full')}
 ${p?.priceHistory?.length>1?`<div class="full"><h3>سابقه تغییر قیمت</h3>${priceHist(p)}</div>`:''}
 <div class="full"><button class="btn p" type="submit">${ic('check')} ذخیره کالا</button> <small class="mu">تغییر قیمت روی فاکتورهای قبلی اثر نمی‌گذارد.</small></div></form>`});
 w._cb=cb;return w}
const PFN={buyPrice:'قیمت خرید',sellPrice:'قیمت فروش',wholesale:'عمده',retail:'خرده',create:'ثبت اولیه'};
const priceHist=p=>tbl([{h:'تاریخ',f:h=>D.fmt(h.date)},{h:'مورد',f:h=>PFN[h.field]||h.field},{h:'قیمت قبلی',cls:'n',f:h=>h.field==='create'?'—':num(h.old)},{h:'قیمت جدید',cls:'n',f:h=>num(h.new)},{h:'کاربر',f:h=>esc(h.userName||'')}],[...p.priceHistory].reverse(),{id:'ph'+p.id,size:50});
FORM.prod=async f=>{const o=formData(f);const id=f.dataset.id||null;const w=f.closest('.mw');const date=readDate(f,'rdate');
 const data={name:o.name,code:o.code,barcode:o.barcode,categoryId:o.cat,unit:o.unit,buyPrice:o.buy===undefined?0:(pMoney(o.buy)||0),sellPrice:pMoney(o.sell)||0,wholesale:pMoney(o.whole)||0,retail:pMoney(o.retail)||0,minStock:pQty(o.min||'0')||0,openQty:o.open?pQty(o.open):0,supplierId:o.sup,regDate:date,active:o.active,desc:o.desc};
 if(id){const p=G('products',id);['buyPrice','sellPrice','wholesale','retail'].forEach(k=>{if(!can('price_edit'))data[k]=p[k]})}
 if(!data.categoryId)throw E('ابتدا یک دسته‌بندی بسازید.');if(data.openQty<0||Number.isNaN(data.openQty))throw E('موجودی اولیه نامعتبر است.');
 if(o.img?.length)data.image=await readImage(o.img[0],400);
 const p=await saveProduct(data,id);toast('کالا ذخیره شد.');closeModal(w);w._cb?.(p);CUR.refresh()};
ACT.pview=el=>{const p=G('products',el.dataset.id);const mv=L('inventory').filter(m=>m.productId===p.id).sort((a,b)=>b.date.j-a.date.j||b.ts-a.ts);
 const sold=activeSales().flatMap(s=>s.items.filter(i=>i.productId===p.id).map(i=>({...i,s})));const rev=sum(sold,i=>i.amount),cg=sum(sold,i=>i.cogs),qs=sum(sold,i=>i.qty);
 modal({title:'سوابق کالا: '+p.name,size:'lg',body:`<div class="stats"><div class="stat"><small>موجودی</small><b>${qtyf(stockOf(p.id),p.unit)}</b></div><div class="stat"><small>ارزش موجودی</small><b>${money(Math.max(0,stockOf(p.id))*p.avgCost/1000)}</b></div><div class="stat ok"><small>سود کل فروش</small><b>${money(rev-cg)}</b></div><div class="stat"><small>مقدار فروخته‌شده</small><b>${qtyf(qs,p.unit)}</b></div></div>
 <h3>سابقه قیمت</h3>${priceHist(p)}<h3 style="margin-top:12px">سابقه خرید و فروش (گردش انبار)</h3>${movTable(mv,'pv')}`})};
function movTable(mv,id){return tbl([{h:'تاریخ',f:m=>D.fmt(m.date)},{h:'نوع',f:m=>OUT_TYPES[m.type]||m.type},{h:'کالا',f:m=>esc(nameOfP(m.productId))},{h:'ورود',cls:'n',f:m=>m.qty>0?kgf(m.qty):''},{h:'خروج',cls:'n',f:m=>m.qty<0?kgf(-m.qty):''},{h:'قیمت واحد',cls:'n',f:m=>num(m.unitCost)},{h:'ارزش',cls:'n',f:m=>num(Math.round(Math.abs(m.qty)*m.unitCost/1000))},{h:'توضیح',f:m=>esc(m.note||'')}],mv,{id,empty:'گردشی ثبت نشده است.',size:30})}
ACT.cats=()=>{const draw=()=>`<div class="fl" style="margin-bottom:10px">${L('categories').map(c=>`<span class="chip">${esc(c.name)} <small class="mu">(${num(L('products').filter(p=>p.categoryId===c.id).length)} کالا)</small></span>`).join('')}</div><form data-form="cat" class="tb">${fld('نام دسته‌بندی جدید',inp('name','','required'))}<button class="btn p">${ic('plus')} افزودن</button></form>`;
 modal({title:'دسته‌بندی‌ها',size:'sm',body:draw()})};
FORM.cat=async f=>{await saveSimple('categories',{name:f.name.value},null,'دسته‌بندی');toast('دسته‌بندی اضافه شد.');const w=f.closest('.mw');closeModal(w);ACT.cats();CUR.refresh()};

/* ============ انبار ============ */
let INV_TAB='stock';const IF={p:'',t:'',from:null,to:null};
PAGES.inventory=(el)=>{
 el.innerHTML=`<div class="hd"><h2>مدیریت انبار</h2>${can('inventory')?`<button class="btn p" data-act="purch">${ic('truck')} خرید از تأمین‌کننده</button><button class="btn" data-act="stk" data-t="in">ورود کالا</button><button class="btn" data-act="stk" data-t="out">خروج کالا</button><button class="btn" data-act="stk" data-t="waste">ثبت ضایعات</button><button class="btn" data-act="stk" data-t="adjust">اصلاح موجودی</button>`:''}</div>
 <div class="stats">${statCard('ارزش فعلی انبار',money(stockValue()))}${statCard('تعداد کالا',num(L('products').filter(p=>p.active).length))}${statCard('کم‌موجود',num(lowStock().length),lowStock().length?'warn':'')}${statCard('ضایعات (ماه جاری)',money(wasteCost(D.j2d(D.today().y,D.today().m,1),D.todayJ())),'err')}</div>
 <div class="tabs"><button class="${INV_TAB==='stock'?'on':''}" data-act="invtab" data-t="stock">موجودی کالاها</button><button class="${INV_TAB==='mov'?'on':''}" data-act="invtab" data-t="mov">گردش کالا</button><button class="${INV_TAB==='pur'?'on':''}" data-act="invtab" data-t="pur">خریدها</button></div><div id="invc"></div>`;
 const c=$('#invc');
 if(INV_TAB==='stock'){const r=L('products').filter(p=>p.active);c.innerHTML=tbl([{h:'کالا',f:p=>`<b>${esc(p.name)}</b>`},{h:'دسته',f:p=>esc(catName(p.categoryId))},{h:'موجودی',cls:'n',f:p=>qtyf(stockOf(p.id),p.unit)},{h:'حداقل',cls:'n',f:p=>qtyf(p.minStock,p.unit)},{h:'بهای میانگین',cls:'n',f:p=>num(p.avgCost)},{h:'ارزش',cls:'n',f:p=>num(Math.max(0,stockOf(p.id))*p.avgCost/1000)},{h:'وضعیت',f:p=>{const s=stockOf(p.id);return s<0?badge('منفی','err'):s<=p.minStock?badge('کم‌موجود','warn'):badge('کافی','ok')}}],r,{id:'is',empty:'کالایی ثبت نشده است.'})}
 else if(INV_TAB==='mov'){c.innerHTML=`<div class="tb">${fld('کالا',`<select id="ifp" data-ch="if"><option value="">همه</option>${L('products').map(p=>`<option value="${p.id}" ${IF.p===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}</select>`,'sm')}${fld('نوع',`<select id="ift" data-ch="if"><option value="">همه</option>${Object.entries(OUT_TYPES).map(([k,v])=>`<option value="${k}" ${IF.t===k?'selected':''}>${v}</option>`).join('')}</select>`,'sm')}</div><div id="mvt"></div>`;
  CUR.draw=()=>{IF.p=$('#ifp').value;IF.t=$('#ift').value;const mv=L('inventory').filter(m=>(!IF.p||m.productId===IF.p)&&(!IF.t||m.type===IF.t)).sort((a,b)=>b.date.j-a.date.j||b.ts-a.ts);$('#mvt').innerHTML=movTable(mv,'mv')};CUR.draw()}
 else{const r=L('purchases').sort((a,b)=>b.date.j-a.date.j);c.innerHTML=tbl([{h:'شماره',f:p=>p.no},{h:'تاریخ',f:p=>D.fmt(p.date)},{h:'تأمین‌کننده',f:p=>esc(G('suppliers',p.supplierId)?.name||'')},{h:'اقلام',f:p=>p.items.map(i=>esc(nameOfP(i.productId))+' '+kgf(i.qty)).join('، ')},{h:'مبلغ',cls:'n',f:p=>num(p.total)},{h:'پرداختی',cls:'n',f:p=>num(sum(paysOf('purchase',p.id),x=>x.amount))}],r,{id:'pu',empty:'خریدی ثبت نشده است.'})}};
INP.if=()=>{PG.mv=0;CUR.draw()};
ACT.invtab=el=>{INV_TAB=el.dataset.t;CUR.refresh()};
const STK={in:'ورود دستی کالا',out:'خروج دستی کالا',waste:'ثبت ضایعات',adjust:'اصلاح موجودی'};
ACT.stk=el=>{const t=el.dataset.t;modal({title:STK[t],size:'sm',body:`<form data-form="stk" data-t="${t}" class="form">${fld('کالا',`<select name="p">${L('products').filter(p=>p.active).map(p=>`<option value="${p.id}">${esc(p.name)} (${qtyf(stockOf(p.id),p.unit)})</option>`).join('')}</select>`,'full')}
 ${t==='adjust'?fld('جهت اصلاح',sel('dir',[['+','افزایش موجودی'],['-','کاهش موجودی']])):''}${fld('مقدار',`<input name="q" inputmode="decimal" required placeholder="مثلاً ۲٫۵۰۰">`)}${t==='in'?fld('قیمت خرید واحد (تومان)',minp('cost','')):''}${fld('تاریخ',dateField('d',D.today()))}${fld('توضیحات'+(t==='waste'||t==='adjust'?' (علت)':''),inp('note'),'full')}<button class="btn p full" type="submit">ثبت</button></form>`})};
FORM.stk=async f=>{const o=formData(f);const t=f.dataset.t;await stockOp({type:t,productId:o.p,qty:pQty(o.q),unitCost:o.cost?pMoney(o.cost):undefined,dir:o.dir,date:readDate(f,'d'),note:o.note});toast('حرکت انبار ثبت شد.');closeModal(f.closest('.mw'));CUR.refresh()};
ACT.purch=()=>{if(!L('suppliers').length){toast('ابتدا یک تأمین‌کننده تعریف کنید.','warn');return go('suppliers')}
 const w=modal({title:'خرید از تأمین‌کننده',size:'lg',body:`<form data-form="purch" class="form">${fld('تأمین‌کننده',`<select name="sup">${L('suppliers').filter(s=>s.active!==false).map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select>`)}${fld('تاریخ خرید',dateField('d',D.today()))}
 <div class="full" id="plines"></div><div class="full"><button type="button" class="btn s" data-act="paddline">${ic('plus')} افزودن ردیف کالا</button></div>
 ${fld('مبلغ پرداخت‌شده (تومان)',minp('paid',''))}${fld('روش پرداخت',sel('m',Object.entries(METHODS).filter(x=>x[0]!=='check')))}${fld('توضیحات',inp('note'),'w2')}<div class="full sum"><div class="t"><span>جمع فاکتور خرید</span><b id="ptot">۰</b></div></div><button class="btn p full" type="submit">ثبت خرید و ورود به انبار</button></form>`});ACT.paddline();w.dataset.lock=1};
ACT.paddline=()=>{const prods=L('products').filter(p=>p.active);if(!prods.length){toast('ابتدا کالا تعریف کنید.','warn');return}$('#plines').insertAdjacentHTML('beforeend',`<div class="line pl"><select name="pp" class="nm" data-in="ptot">${prods.map(p=>`<option value="${p.id}" data-c="${p.buyPrice}">${esc(p.name)}</option>`).join('')}</select><input name="pq" inputmode="decimal" placeholder="مقدار" data-in="ptot"><input name="pc" class="money" inputmode="numeric" placeholder="قیمت خرید واحد" data-in="ptot"><b class="gold pa" style="text-align:end">۰</b><button type="button" class="btn s d" data-act="delpl">${ic('x')}</button></div>`)};
ACT.delpl=el=>{el.closest('.pl').remove();INP.ptot()};
INP.ptot=()=>{let t=0;$$('.pl').forEach(l=>{const a=Math.round((pQty($('[name=pq]',l).value)||0)*(pMoney($('[name=pc]',l).value)||0)/1000);$('.pa',l).textContent=num(a);t+=a});$('#ptot').textContent=money(t)};
FORM.purch=async f=>{const o=formData(f);const items=$$('.pl',f).map(l=>({productId:$('[name=pp]',l).value,qty:pQty($('[name=pq]',l).value),unitCost:pMoney($('[name=pc]',l).value)}));
 await createPurchase({supplierId:o.sup,date:readDate(f,'d'),items,paid:pMoney(o.paid)||0,method:o.m,note:o.note});toast('خرید ثبت و به موجودی انبار اضافه شد.');closeModal(f.closest('.mw'));CUR.refresh()};

/* ============ مشتریان ============ */
const CF={q:'',f:'all'};
PAGES.customers=(el,q)=>{if(q.id)return customerProfile(el,q.id,q.tab);if(q.f){CF.f=q.f;history.replaceState(null,'','#/customers')}
 el.innerHTML=`<div class="hd"><h2>مشتریان</h2>${can('customers')?`<button class="btn p" data-act="qcust">${ic('plus')} مشتری جدید</button>`:''}<button class="btn" data-act="custcsv">${ic('download')} CSV</button></div>
 <div class="tb">${fld('جستجو',`<input id="cq" value="${esc(CF.q)}" placeholder="نام، موبایل یا شناسه" data-in="cf">`,'w2')}${fld('فیلتر',sel('cff',[['all','همه'],['debtor','بدهکاران'],['creditor','بستانکاران'],['settled','تسویه‌شده‌ها'],['check','دارای چک'],['loan','دارای قرض باز'],['inactive','غیرفعال']],CF.f,'data-ch="cf"'),'sm')}</div><div id="ct"></div>`;
 CUR.draw=()=>{const r=custRows();$('#ct').innerHTML=tbl([{h:'شناسه',f:c=>c.code},{h:'نام',f:c=>`<a href="#/customers?id=${c.id}"><b>${esc(c.name)}</b></a>`},{h:'موبایل',f:c=>esc(c.phone)},
  {h:'بدهی به فروشگاه',cls:'n',f:c=>{const b=custBal(c.id).R;return `<span class="${b>0?'neg':b<0?'pos':'mu'}">${b<0?num(-b)+' (اعتبار)':num(b)}</span>`}},{h:'طلب مشتری از فروشگاه',cls:'n',f:c=>num(custBal(c.id).P)},{h:'سقف اعتبار',cls:'n',f:c=>c.creditLimit?num(c.creditLimit):'—'},{h:'وضعیت',f:c=>c.active?badge('فعال','ok'):badge('غیرفعال','mu')},
  {h:'عملیات',f:c=>`<div class="act"><a class="btn s" href="#/customers?id=${c.id}">${ic('eye')} پرونده</a><button class="btn s" data-act="cedit" data-id="${c.id}">${ic('edit')}</button><button class="btn s" data-act="ctoggle" data-id="${c.id}">${c.active?'غیرفعال':'فعال'}</button><button class="btn s d" data-act="cdel" data-id="${c.id}" title="حذف">${ic('trash')}</button></div>`}],r,{id:'cu',empty:'مشتری یافت نشد.'})};CUR.draw()};
function custRows(){CF.q=$('#cq')?.value??CF.q;CF.f=$('[name=cff]')?.value||CF.f;const q=toEn(CF.q).toLowerCase();
 return L('customers').filter(c=>{if(q&&!(c.name+c.phone+c.code).toLowerCase().includes(q))return false;const b=custBal(c.id);
  switch(CF.f){case 'debtor':return b.R>0;case 'creditor':return b.P>0||b.R<0;case 'settled':return b.R===0&&b.P===0;case 'check':return L('checks').some(k=>k.customerId===c.id&&k.status==='pending');case 'loan':return L('loans').some(l=>l.customerId===c.id&&loanInfo(l).remaining>0);case 'inactive':return !c.active;default:return true}}).sort((a,b)=>a.name.localeCompare(b.name,'fa'))}
INP.cf=()=>{PG.cu=0;CUR.draw()};
ACT.cedit=el=>openCustomerForm(el.dataset.id);
ACT.ctoggle=async el=>{const c=clone(G('customers',el.dataset.id));if(c.active&&!(await confirmBox(`مشتری «${esc(c.name)}» غیرفعال شود؟ سوابق مالی حفظ می‌شود.`)))return;c.active=!c.active;const ops=[{s:'customers',put:c}];audit(ops,c.active?'فعال‌سازی مشتری':'غیرفعال‌سازی مشتری','customer',c.id,c.name);await DB.commit(ops);toast('وضعیت مشتری تغییر کرد.');CUR.refresh()};
ACT.custcsv=()=>csvDownload('customers.csv',['شناسه','نام','موبایل','آدرس','سقف اعتبار','بدهی به فروشگاه','اعتبار مشتری (بستانکاری از فاکتورها)','طلب مشتری از فروشگاه (قرض)','وضعیت','تاریخ ثبت'],custRows().map(c=>{const b=custBal(c.id);return[c.code,c.name,c.phone,c.address,c.creditLimit,Math.max(b.R,0),Math.max(-b.R,0),b.P,c.active?'فعال':'غیرفعال',D.en(c.regDate)]}));
function openCustomerForm(id,cb){const c=id?G('customers',id):null;
 const w=modal({title:c?'ویرایش مشتری':'مشتری جدید',body:`<form data-form="cust" data-id="${id||''}" class="form">${fld('نام و نام خانوادگی *',inp('name',c?.name,'required'),'w2')}${fld('شماره موبایل',inp('phone',c?.phone,'inputmode="tel" placeholder="09123456789"'))}${fld('سقف اعتبار (تومان، صفر = نامحدود)',minp('limit',c?.creditLimit))}
 ${fld('آدرس',inp('address',c?.address),'full')}${fld('توضیحات',`<textarea name="note">${esc(c?.note||'')}</textarea>`,'full')}${c?`<label class="f" style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" name="active" style="width:auto" ${c.active?'checked':''}> حساب فعال</label>`:''}<button class="btn p full" type="submit">${ic('check')} ذخیره</button></form>`});w._cb=cb}
FORM.cust=async f=>{const o=formData(f);const id=f.dataset.id||null;const w=f.closest('.mw');const c=await saveCustomer({name:o.name,phone:toEn(o.phone),address:o.address,note:o.note,creditLimit:pMoney(o.limit)||0,active:id?o.active:true},id);toast('اطلاعات مشتری ذخیره شد.');closeModal(w);w._cb?.(c);CUR.refresh()};
function customerProfile(el,id,tab='ledger'){const c=G('customers',id);if(!c){el.innerHTML=emptyBox('مشتری یافت نشد.');return}const b=custBal(id);
 const loans=L('loans').filter(l=>l.customerId===id&&l.status!=='void');
 el.innerHTML=`<div class="hd"><h2>${esc(c.name)} <small class="mu">${c.code}</small> ${c.active?badge('فعال','ok'):badge('غیرفعال','mu')}</h2><a class="btn" href="#/customers">بازگشت</a><button class="btn" data-act="cedit" data-id="${id}">${ic('edit')} ویرایش</button>${can('payments')?`<button class="btn p" data-act="qpayc" data-id="${id}">${ic('card')} ثبت پرداخت</button>`:''}${can('loans')?`<button class="btn" data-act="qloanc" data-id="${id}">ثبت قرض</button>`:''}<button class="btn" data-act="stmt" data-id="${id}">${ic('printer')} چاپ صورت‌حساب</button></div>
 <div class="stats">${statCard('بدهی به فروشگاه (مانده خالص)',money(Math.max(b.R,0)),b.R>0?'err':'ok',b.R<0?'اعتبار مشتری: '+money(-b.R):'')}${statCard('بابت فاکتورها',money(b.sub.sale),'','')}${statCard('بابت قرض داده‌شده به او',money(b.sub.loan),'warn','طلب فروشگاه')}${statCard('بدهی فروشگاه به مشتری (قرض گرفته‌شده)',money(b.P),b.P>0?'warn':'','حساب مستقل')}${statCard('سقف اعتبار',c.creditLimit?money(c.creditLimit):'نامحدود')}</div>
 <div class="kv card" style="margin-bottom:12px"><span>موبایل</span><b>${esc(c.phone||'—')}</b><span>آدرس</span><b>${esc(c.address||'—')}</b><span>تاریخ ثبت</span><b>${D.fmt(c.regDate)}</b><span>توضیحات</span><b>${esc(c.note||'—')}</b></div>
 <div class="tabs">${[['ledger','دفتر حساب'],['sales','فاکتورها'],['loans','قرض‌ها'],['checks','چک‌ها'],['pays','پرداخت‌ها']].map(t=>`<button class="${tab===t[0]?'on':''}" data-act="ctab" data-id="${id}" data-t="${t[0]}">${t[1]}</button>`).join('')}</div><div id="ctab"></div>`;
 const box=$('#ctab');
 if(tab==='ledger')box.innerHTML=ledgerHtml(id);
 else if(tab==='sales')box.innerHTML=tbl([{h:'شماره',f:s=>`<a data-act="showinv" data-id="${s.id}" href="#/customers?id=${id}&tab=sales">${s.no}</a>`},{h:'تاریخ',f:s=>D.fmt(s.date)},{h:'مبلغ',cls:'n',f:s=>num(s.total)},{h:'مانده',cls:'n',f:s=>num(saleInfo(s).remain)},{h:'وضعیت',f:s=>s.status==='void'?badge('ابطال','err'):saleInfo(s).remain>0?badge('دارای مانده','warn'):badge('تسویه','ok')}],L('sales').filter(s=>s.customerId===id).sort((a,b)=>b.date.j-a.date.j),{id:'cps',empty:'فاکتوری وجود ندارد.'});
 else if(tab==='loans')box.innerHTML=loansTable(loans.sort((a,b)=>b.date.j-a.date.j),'cpl');
 else if(tab==='checks')box.innerHTML=checksTable(L('checks').filter(k=>k.customerId===id).sort((a,b)=>b.dueDate.j-a.dueDate.j),'cpc');
 else box.innerHTML=paysTable(L('payments').filter(p=>p.customerId===id).sort((a,b)=>b.ts-a.ts),'cpp')}
ACT.ctab=el=>go('customers?id='+el.dataset.id+'&tab='+el.dataset.t);
ACT.qpayc=el=>openPaymentForm({customerId:el.dataset.id});ACT.qloanc=el=>openLoanForm({customerId:el.dataset.id});

/* ============ دفتر حساب ============ */
const LG={c:'',from:null,to:null};
function ledgerCalc(cid,f,t){const all=ledgerOf(cid);const out={};
 ['R','P'].forEach(a=>{let bal=0,open=0;const rows=[];all.filter(e=>e.acct===a).forEach(e=>{const v=a==='R'?e.debit-e.credit:e.credit-e.debit;bal+=v;if(f&&e.date.j<f)open=bal;else if(!t||e.date.j<=t)rows.push({...e,bal})});out[a]={rows,open,close:bal,td:sum(rows,r=>r.debit),tc:sum(rows,r=>r.credit)}});return out}
function ledgerHtml(cid,f,t){const r=ledgerCalc(cid,f,t);const mk=(a,title,hint)=>{const x=r[a];
 return `<div class="card" style="margin-bottom:12px"><h3>${title} <small class="mu">${hint}</small></h3>${x.rows.length||x.open?tbl([{h:'ردیف',f:(e,i)=>num(i+1)},{h:'تاریخ',f:e=>D.fmt(e.date)},{h:'شرح عملیات',f:e=>esc(e.desc)+(e.kind==='reversal'||e.kind==='sale_adjust'?' <span class="bg warn">اصلاحی</span>':'')},{h:'بدهکار',cls:'n',f:e=>e.debit?`<span class="neg">${num(e.debit)}</span>`:''},{h:'بستانکار',cls:'n',f:e=>e.credit?`<span class="pos">${num(e.credit)}</span>`:''},{h:'مانده',cls:'n',f:e=>`<b class="${e.bal>0?(a==='R'?'neg':'gold'):e.bal<0?'pos':'mu'}">${num(Math.abs(e.bal))}${e.bal<0?' (برعکس)':''}</b>`},{h:'روش پرداخت',f:e=>esc(e.method||'—')},{h:'شماره سند',f:e=>esc(e.docNo||'')}],x.rows,{id:'lg'+a,size:60,foot:`<tr><td colspan="3">${x.open?'مانده قبل از بازه: '+num(x.open)+' | ':''}جمع گردش</td><td class="n">${num(x.td)}</td><td class="n">${num(x.tc)}</td><td class="n">${num(x.close)}</td><td colspan="2">مانده پایان</td></tr>`}):emptyBox('تراکنشی در این حساب ثبت نشده است.','book')}</div>`};
 return mk('R','حساب طلب فروشگاه از مشتری','(فاکتورها و قرض‌های داده‌شده؛ مانده = بدهکار − بستانکار)')+mk('P','حساب بدهی فروشگاه به مشتری','(قرض‌های گرفته‌شده از مشتری؛ مانده = بستانکار − بدهکار)')}
PAGES.ledger=(el,q)=>{if(q.c){LG.c=q.c;history.replaceState(null,'','#/ledger')}
 el.innerHTML=`<div class="hd"><h2>دفتر حساب مشتریان</h2><button class="btn" data-act="lgprint">${ic('printer')} چاپ صورت‌حساب</button><button class="btn" data-act="lgcsv">${ic('download')} CSV</button></div>
 <div class="tb">${fld('مشتری',`<select id="lgc" data-ch="lg"><option value="">انتخاب مشتری…</option>${L('customers').map(c=>`<option value="${c.id}" ${LG.c===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>`,'w2')}${fld('از تاریخ',dateField('lgf',LG.from,{optional:true,ch:'lg'}))}${fld('تا تاریخ',dateField('lgt',LG.to,{optional:true,ch:'lg'}))}</div><div id="lgb"></div>`;initDates(el);
 CUR.draw=()=>{LG.c=$('#lgc').value;try{LG.from=readDate(el,'lgf',{optional:true});LG.to=readDate(el,'lgt',{optional:true})}catch(e){}
  if(!LG.c){$('#lgb').innerHTML=emptyBox('برای مشاهده دفتر حساب، مشتری را انتخاب کنید.','book');return}
  const b=custBal(LG.c);$('#lgb').innerHTML=`<div class="stats">${statCard('مانده طلب فروشگاه',money(b.R),b.R>0?'err':'ok')}${statCard('مانده بدهی فروشگاه',money(b.P),b.P>0?'warn':'')}</div>`+ledgerHtml(LG.c,LG.from?.j,LG.to?.j)};CUR.draw()};
INP.lg=()=>{PG.lgR=0;PG.lgP=0;CUR.draw()};
function stmtBody(cid,f,t){const c=G('customers',cid);const r=ledgerCalc(cid,f,t);const b=custBal(cid);
 const tb=(a,title)=>`<h2>${title}</h2><table><tr><th>ردیف</th><th>تاریخ</th><th>شرح</th><th class="n">بدهکار</th><th class="n">بستانکار</th><th class="n">مانده</th><th>سند</th></tr>${r[a].rows.map((e,i)=>`<tr><td>${num(i+1)}</td><td>${D.fmt(e.date)}</td><td>${esc(e.desc)}</td><td class="n">${e.debit?num(e.debit):''}</td><td class="n">${e.credit?num(e.credit):''}</td><td class="n">${num(e.bal)}</td><td>${esc(e.docNo||'')}</td></tr>`).join('')||'<tr><td colspan="7">بدون تراکنش</td></tr>'}</table>`;
 return shopHead('صورت‌حساب مشتری')+`<div>مشتری: <b>${esc(c.name)}</b> (${c.code}) ${c.phone?'· '+esc(c.phone):''}${f||t?` · بازه: ${f?D.fmt(D.fromJ(f)):'ابتدا'} تا ${t?D.fmt(D.fromJ(t)):'اکنون'}`:''}</div>`+tb('R','حساب طلب فروشگاه از مشتری (فاکتورها و قرض‌های داده‌شده)')+tb('P','حساب بدهی فروشگاه به مشتری (قرض‌های گرفته‌شده)')+`<div class="tot"><div class="b"><span>مانده بدهی مشتری به فروشگاه</span><span>${money(b.R)}</span></div><div class="b"><span>مانده بدهی فروشگاه به مشتری</span><span>${money(b.P)}</span></div></div><div class="sig"><span>مهر و امضای فروشگاه</span><span>امضای مشتری</span></div>`}
ACT.lgprint=()=>{if(!LG.c)throw E('ابتدا مشتری را انتخاب کنید.');printDoc('صورت‌حساب',stmtBody(LG.c,LG.from?.j,LG.to?.j))};
ACT.stmt=el=>printDoc('صورت‌حساب',stmtBody(el.dataset.id));
ACT.lgcsv=()=>{if(!LG.c)throw E('ابتدا مشتری را انتخاب کنید.');const r=ledgerCalc(LG.c,LG.from?.j,LG.to?.j);const rows=[];['R','P'].forEach(a=>r[a].rows.forEach((e,i)=>rows.push([a==='R'?'طلب فروشگاه':'بدهی فروشگاه',i+1,D.en(e.date),e.desc,e.debit,e.credit,e.bal,e.method,e.docNo])));csvDownload('ledger-'+nameOfC(LG.c)+'.csv',['حساب','ردیف','تاریخ','شرح','بدهکار','بستانکار','مانده','روش پرداخت','شماره سند'],rows)};

/* ============ تأمین‌کنندگان ============ */
PAGES.suppliers=(el)=>{el.innerHTML=`<div class="hd"><h2>تأمین‌کنندگان</h2><button class="btn p" data-act="supform">${ic('plus')} تأمین‌کننده جدید</button></div><div id="sp"></div>`;
 $('#sp').innerHTML=tbl([{h:'نام',f:s=>`<b>${esc(s.name)}</b>`},{h:'تلفن',f:s=>esc(s.phone||'')},{h:'آدرس',f:s=>esc(s.address||'')},{h:'جمع خریدها',cls:'n',f:s=>num(sum(L('purchases').filter(p=>p.supplierId===s.id&&p.status==='active'),p=>p.total))},{h:'مانده بدهی ما',cls:'n',f:s=>{const b=supBal(s.id);return `<span class="${b>0?'neg':''}">${num(b)}</span>`}},{h:'وضعیت',f:s=>s.active!==false?badge('فعال','ok'):badge('غیرفعال','mu')},
 {h:'عملیات',f:s=>`<div class="act"><button class="btn s" data-act="supform" data-id="${s.id}">${ic('edit')}</button><button class="btn s" data-act="suppay" data-id="${s.id}">پرداخت</button><button class="btn s" data-act="supview" data-id="${s.id}">${ic('eye')} سوابق</button></div>`}],L('suppliers'),{id:'sp',empty:'تأمین‌کننده‌ای ثبت نشده است.'})};
ACT.supform=el=>{const id=el.dataset.id;const s=id?G('suppliers',id):null;modal({title:s?'ویرایش تأمین‌کننده':'تأمین‌کننده جدید',size:'sm',body:`<form data-form="sup" data-id="${id||''}" class="form">${fld('نام *',inp('name',s?.name,'required'),'full')}${fld('تلفن',inp('phone',s?.phone),'full')}${fld('آدرس',inp('address',s?.address),'full')}${s?`<label class="f"><input type="checkbox" name="active" style="width:auto" ${s.active!==false?'checked':''}> فعال</label>`:''}<button class="btn p full">ذخیره</button></form>`})};
FORM.sup=async f=>{const o=formData(f);await saveSimple('suppliers',{name:o.name,phone:o.phone,address:o.address,...(f.dataset.id?{active:o.active}:{})},f.dataset.id||null,'تأمین‌کننده');toast('ذخیره شد.');closeModal(f.closest('.mw'));CUR.refresh()};
ACT.suppay=el=>openPaymentForm({supplierId:el.dataset.id});
ACT.supview=el=>{const s=G('suppliers',el.dataset.id);modal({title:'سوابق '+s.name,size:'lg',body:`<h3>خریدها</h3>${tbl([{h:'شماره',f:p=>p.no},{h:'تاریخ',f:p=>D.fmt(p.date)},{h:'اقلام',f:p=>p.items.map(i=>esc(nameOfP(i.productId))+' '+kgf(i.qty)).join('، ')},{h:'مبلغ',cls:'n',f:p=>num(p.total)}],L('purchases').filter(p=>p.supplierId===s.id),{id:'sv1',empty:'خریدی نیست.'})}<h3>پرداخت‌ها</h3>${paysTable(L('payments').filter(p=>p.supplierId===s.id),'sv2')}`})};

/* ============ پرداخت‌ها و هزینه‌ها ============ */
const refText=p=>p.refType==='sale'?'فاکتور '+(G('sales',p.refId)?.no||''):p.refType==='loan'?'قرض '+(G('loans',p.refId)?.no||''):p.refType==='purchase'?'خرید '+(G('purchases',p.refId)?.no||''):'عمومی';
function paysTable(rows,id,acts=false){return tbl([{h:'شماره',f:p=>p.no},{h:'تاریخ',f:p=>D.fmt(p.date)},{h:'نوع',f:p=>p.dir==='in'?badge('دریافت','ok'):badge('پرداخت','warn')},{h:'طرف حساب',f:p=>esc(p.customerId?nameOfC(p.customerId):G('suppliers',p.supplierId)?.name||'—')},{h:'بابت',f:p=>refText(p)},{h:'روش',f:p=>mlabel(p.method)+(p.checkId?` <small class="mu">(${esc(G('checks',p.checkId)?.number||'')})</small>`:'')},{h:'مبلغ',cls:'n',f:p=>num(p.amount)},{h:'پیگیری',f:p=>esc(p.tracking||'')},{h:'وضعیت',f:p=>p.voided?badge('باطل','err'):badge('معتبر','ok')}
 ,...(acts?[{h:'عملیات',f:p=>!p.voided&&can('cancel_sale')?`<button class="btn s d" data-act="paydel" data-id="${p.id}">ابطال</button>`:''}]:[])],rows,{id,empty:'پرداختی ثبت نشده است.',foot:rows.length?`<tr><td colspan="6">جمع معتبر: دریافتی ${num(sum(rows.filter(p=>!p.voided&&p.dir==='in'),p=>p.amount))} | پرداختی ${num(sum(rows.filter(p=>!p.voided&&p.dir==='out'),p=>p.amount))}</td><td colspan="4"></td></tr>`:''})}
const PYF={dir:'',m:'',c:'',from:null,to:null,tab:'pay'};
PAGES.payments=(el,q)=>{if(q.tab){PYF.tab=q.tab;history.replaceState(null,'','#/payments')}
 el.innerHTML=`<div class="hd"><h2>مدیریت پرداخت‌ها</h2><button class="btn p" data-act="qpay">${ic('plus')} ثبت دریافت / پرداخت</button><button class="btn" data-act="expform">ثبت هزینه</button></div>
 <div class="tabs"><button class="${PYF.tab==='pay'?'on':''}" data-act="paytab" data-t="pay">دریافت و پرداخت‌ها</button><button class="${PYF.tab==='exp'?'on':''}" data-act="paytab" data-t="exp">هزینه‌ها</button></div><div id="pyb"></div>`;
 const b=$('#pyb');
 if(PYF.tab==='exp'){const r=L('expenses').sort((a,c)=>c.date.j-a.date.j||c.ts-a.ts);b.innerHTML=tbl([{h:'شماره',f:e=>e.no},{h:'تاریخ',f:e=>D.fmt(e.date)},{h:'عنوان',f:e=>esc(e.title)},{h:'روش',f:e=>mlabel(e.method)},{h:'مبلغ',cls:'n',f:e=>num(e.amount)},{h:'توضیح',f:e=>esc(e.note)},{h:'وضعیت',f:e=>e.voided?badge('باطل','err'):badge('ثبت‌شده','ok')},{h:'',f:e=>!e.voided&&can('cancel_sale')?`<button class="btn s d" data-act="expdel" data-id="${e.id}">ابطال</button>`:''}],r,{id:'ex',empty:'هزینه‌ای ثبت نشده است.',foot:`<tr><td colspan="4">جمع هزینه‌های معتبر</td><td class="n">${num(sum(r.filter(e=>!e.voided),e=>e.amount))}</td><td colspan="3"></td></tr>`});return}
 b.innerHTML=`<div class="tb">${fld('جهت',sel('pyd',[['','همه'],['in','دریافت'],['out','پرداخت']],PYF.dir,'data-ch="pyf"'),'sm')}${fld('روش',sel('pym',[['','همه'],...Object.entries(METHODS)],PYF.m,'data-ch="pyf"'),'sm')}${fld('مشتری',`<select id="pyc" data-ch="pyf"><option value="">همه</option>${L('customers').map(c=>`<option value="${c.id}" ${PYF.c===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>`,'sm')}${fld('از تاریخ',dateField('pyf',PYF.from,{optional:true,ch:'pyf'}))}${fld('تا تاریخ',dateField('pyt',PYF.to,{optional:true,ch:'pyf'}))}</div><div id="pyt2"></div>`;initDates(el);
 CUR.draw=()=>{PYF.dir=$('[name=pyd]').value;PYF.m=$('[name=pym]').value;PYF.c=$('#pyc').value;try{PYF.from=readDate(el,'pyf',{optional:true});PYF.to=readDate(el,'pyt',{optional:true})}catch(e){}
  const r=L('payments').filter(p=>(!PYF.dir||p.dir===PYF.dir)&&(!PYF.m||p.method===PYF.m)&&(!PYF.c||p.customerId===PYF.c)&&(!PYF.from||p.date.j>=PYF.from.j)&&(!PYF.to||p.date.j<=PYF.to.j)).sort((a,c)=>c.date.j-a.date.j||c.ts-a.ts);$('#pyt2').innerHTML=paysTable(r,'py',true)};CUR.draw()};
INP.pyf=()=>{PG.py=0;CUR.draw()};
ACT.paytab=el=>{PYF.tab=el.dataset.t;CUR.refresh()};
ACT.paydel=async el=>{const r=await confirmBox('این پرداخت ابطال شود؟ اثر آن در دفتر حساب با سند اصلاحی معکوس می‌شود.',{ok:'ابطال',danger:true,input:'دلیل ابطال'});if(!r)return;await voidPayment(el.dataset.id,r.value);toast('پرداخت ابطال و حساب اصلاح شد.');CUR.refresh()};
ACT.expdel=async el=>{if(!(await confirmBox('هزینه ابطال شود؟',{danger:true,ok:'ابطال'})))return;await voidExpense(el.dataset.id);toast('هزینه ابطال شد.');CUR.refresh()};
ACT.expform=()=>modal({title:'ثبت هزینه',size:'sm',body:`<form data-form="exp" class="form">${fld('عنوان هزینه *',inp('title','','required placeholder="مثلاً قبض برق، حقوق، حمل"'),'full')}${fld('مبلغ (تومان)',minp('amount','','required'))}${fld('روش پرداخت',sel('m',Object.entries(METHODS)))}${fld('تاریخ',dateField('d',D.today()))}${fld('توضیحات',inp('note'),'full')}<button class="btn p full">ثبت هزینه</button></form>`});
FORM.exp=async f=>{const o=formData(f);await addExpense({title:o.title,amount:pMoney(o.amount),method:o.m,date:readDate(f,'d'),note:o.note});toast('هزینه ثبت شد.');closeModal(f.closest('.mw'));CUR.refresh()};
function openPaymentForm(pre={}){
 const cs=L('customers'),ss=L('suppliers');if(!cs.length&&!ss.length){toast('ابتدا یک مشتری یا تأمین‌کننده ثبت کنید.','warn');return}
 const who=pre.customerId?'c:'+pre.customerId:pre.supplierId?'s:'+pre.supplierId:pre.refType==='sale'?'c:'+(G('sales',pre.refId)?.customerId||''):pre.refType==='loan'?'c:'+G('loans',pre.refId)?.customerId:'';
 const loan=pre.refType==='loan'?G('loans',pre.refId):null;const dir=pre.dir||(loan?(loan.kind==='out'?'in':'out'):'in');
 const w=modal({title:'ثبت دریافت / پرداخت وجه',size:'lg',body:`<form data-form="pay" class="form">${fld('جهت',sel('dir',[['in','دریافت وجه'],['out','پرداخت وجه']],dir,'data-ch="payref"'),'sm')}
 ${fld('طرف حساب',`<select name="who" data-ch="payref"><option value="">انتخاب…</option><optgroup label="مشتریان">${cs.map(c=>`<option value="c:${c.id}" ${who==='c:'+c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</optgroup><optgroup label="تأمین‌کنندگان">${ss.map(c=>`<option value="s:${c.id}" ${who==='s:'+c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</optgroup></select>`)}
 ${fld('بابت',`<select name="ref" data-ch="payfill"></select>`,'w2')}${fld('مبلغ (تومان)',minp('amount','','required'))}${fld('روش پرداخت',sel('method',Object.entries(METHODS),'cash','data-ch="paymeth"'))}${fld('تاریخ',dateField('d',D.today()))}${fld('شماره پیگیری',inp('trk'))}
 <div class="full ck" id="payck" style="display:none"><div class="form">${fld('شماره چک *',inp('ck_n'))}${fld('بانک *',inp('ck_b'))}${fld('صاحب حساب',inp('ck_o'))}${fld('شناسه صیادی',inp('ck_s'))}${fld('تاریخ سررسید *',dateField('ckd',D.fromJ(D.todayJ()+30)))}</div></div>
 ${fld('توضیحات',inp('note'),'full')}<button class="btn p full" type="submit">${ic('check')} ثبت</button></form>`});
 INP.payref=()=>{const f=$('form[data-form=pay]');const[t,id]=($('[name=who]',f).value||':').split(':');const d=$('[name=dir]',f).value;const opts=[['general:','پرداخت عمومی (به حساب)']];
  if(t==='c'){L('sales').filter(s=>s.customerId===id&&s.status==='active'&&saleInfo(s).remain>0&&d==='in').forEach(s=>opts.push(['sale:'+s.id,`فاکتور ${s.no} - مانده ${num(saleInfo(s).remain)}`]));
   L('loans').filter(l=>l.customerId===id&&loanInfo(l).remaining>0&&((l.kind==='out')===(d==='in'))).forEach(l=>opts.push(['loan:'+l.id,`قرض ${l.no} (${l.kind==='out'?'داده‌شده':'گرفته‌شده'}) - مانده ${num(loanInfo(l).remaining)}`]))}
  if(t==='s')L('purchases').filter(p=>p.supplierId===id).forEach(p=>opts.push(['purchase:'+p.id,`خرید ${p.no} - ${num(p.total)}`]));
  const r=$('[name=ref]',f);const want=pre.refType?pre.refType+':'+pre.refId:r.value;r.innerHTML=opts.map(o=>`<option value="${o[0]}">${esc(o[1])}</option>`).join('');if([...r.options].some(o=>o.value===want))r.value=want;INP.payfill(r)};
 INP.payfill=r=>{const f=$('form[data-form=pay]');const[t,id]=(r.value||':').split(':');let rem=0;if(t==='sale')rem=saleInfo(G('sales',id)).remain;if(t==='loan')rem=loanInfo(G('loans',id)).remaining;if(rem)$('[name=amount]',f).value=num(rem)};
 INP.paymeth=el=>{$('#payck').style.display=el.value==='check'?'':'none'};
 INP.payref();w.dataset.lock=1}
FORM.pay=async f=>{const o=formData(f);const[t,wid]=(o.who||':').split(':');if(!wid)throw E('طرف حساب را انتخاب کنید.');const[rt,rid]=(o.ref||'general:').split(':');
 const p={dir:o.dir,customerId:t==='c'?wid:null,supplierId:t==='s'?wid:null,amount:pMoney(o.amount),method:o.method,date:readDate(f,'d'),tracking:o.trk,note:o.note,refType:rt||'general',refId:rid||null};
 if(o.method==='check')p.check={number:o.ck_n,bank:o.ck_b,owner:o.ck_o,sayad:o.ck_s,dueDate:readDate(f,'ckd',{label:'سررسید چک'})};
 const pay=await addPayment(p);toast(`پرداخت ${pay.no} ثبت شد.`);closeModal(f.closest('.mw'));CUR.refresh()};

/* ============ قرض و بدهی ============ */
const LF={q:'',k:'',s:'open',c:''};
const loanRow=l=>({l,i:loanInfo(l)});
function loansTable(ls,id,acts=false){return tbl([{h:'شماره',f:l=>`<a data-act="loanview" data-id="${l.id}" href="javascript:void 0">${l.no}</a>`},{h:'نوع',f:l=>l.kind==='out'?badge('فروشگاه به مشتری','warn'):badge('مشتری به فروشگاه','gd')},{h:'مشتری',f:l=>esc(nameOfC(l.customerId))},{h:'عنوان',f:l=>esc(l.title)},{h:'مبلغ اولیه',cls:'n',f:l=>num(l.amount)},{h:'پرداخت‌شده',cls:'n',f:l=>num(loanInfo(l).paid)},{h:'مانده',cls:'n',f:l=>`<b class="${loanInfo(l).remaining>0?'neg':'pos'}">${num(loanInfo(l).remaining)}</b>`},{h:'آخرین پرداخت',f:l=>D.fmt(loanInfo(l).last)},{h:'سررسید',f:l=>l.dueDate?D.fmt(l.dueDate):'—'},
 {h:'وضعیت',f:l=>{const s=loanInfo(l).status;return s==='settled'?badge('تسویه‌شده','ok'):s==='overdue'?badge('معوق','err'):s==='void'?badge('باطل','mu'):badge('باز','warn')}},
 {h:'عملیات',f:l=>{const i=loanInfo(l);return `<div class="act"><button class="btn s" data-act="loanview" data-id="${l.id}">${ic('eye')}</button>${i.remaining>0&&can('payments')?`<button class="btn s" data-act="loanpay" data-id="${l.id}">${l.kind==='out'?'دریافت':'پرداخت'}</button><button class="btn s p" data-act="loansettle" data-id="${l.id}">تسویه</button>`:''}</div>`}}],ls,{id,empty:'قرضی ثبت نشده است.'})}
PAGES.loans=(el,q)=>{if(q.q){LF.q=q.q;LF.s='all';history.replaceState(null,'','#/loans')}
 const all=L('loans').filter(l=>l.status!=='void').map(loanRow);const open=all.filter(x=>x.i.remaining>0);
 el.innerHTML=`<div class="hd"><h2>مدیریت قرض و بدهی</h2><button class="btn p" data-act="qloan">${ic('plus')} ثبت قرض جدید</button></div>
 <div class="stats">${statCard('طلب فروشگاه (قرض داده‌شده به مشتریان)',money(sum(open.filter(x=>x.l.kind==='out'),x=>x.i.remaining)),'warn',`${num(open.filter(x=>x.l.kind==='out').length)} قرض باز`)}${statCard('بدهی فروشگاه (قرض گرفته‌شده از مشتریان)',money(sum(open.filter(x=>x.l.kind==='in'),x=>x.i.remaining)),'err',`${num(open.filter(x=>x.l.kind==='in').length)} قرض باز`)}${statCard('قرض‌های معوق',num(open.filter(x=>x.i.overdue).length),open.some(x=>x.i.overdue)?'err':'')}${statCard('قرض‌های تسویه‌شده',num(all.length-open.length),'ok')}</div>
 <div class="tb">${fld('جستجو',`<input id="lq" value="${esc(LF.q)}" placeholder="شماره، عنوان یا مشتری" data-in="lf">`,'w2')}${fld('نوع قرض',sel('lk',[['','همه'],['out','فروشگاه به مشتری'],['in','مشتری به فروشگاه']],LF.k,'data-ch="lf"'),'sm')}${fld('وضعیت',sel('ls',[['open','باز (مانده‌دار)'],['overdue','معوق'],['settled','تسویه‌شده'],['all','همه']],LF.s,'data-ch="lf"'),'sm')}${fld('مشتری',`<select id="lc" data-ch="lf"><option value="">همه</option>${L('customers').map(c=>`<option value="${c.id}" ${LF.c===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>`,'sm')}</div><div id="lt"></div>`;
 CUR.draw=()=>{LF.q=$('#lq').value;LF.k=$('[name=lk]').value;LF.s=$('[name=ls]').value;LF.c=$('#lc').value;const q=toEn(LF.q).toLowerCase();
  const r=L('loans').filter(l=>{if(l.status==='void')return false;const s=loanInfo(l).status;if(LF.k&&l.kind!==LF.k)return false;if(LF.c&&l.customerId!==LF.c)return false;if(LF.s==='open'&&!(s==='open'||s==='overdue'))return false;if(LF.s==='overdue'&&s!=='overdue')return false;if(LF.s==='settled'&&s!=='settled')return false;return !q||(l.no+l.title+nameOfC(l.customerId)).toLowerCase().includes(q)}).sort((a,b)=>b.date.j-a.date.j);
  $('#lt').innerHTML=loansTable(r,'ln')};CUR.draw()};
INP.lf=()=>{PG.ln=0;CUR.draw()};
function openLoanForm(pre={}){if(!L('customers').length){toast('ابتدا مشتری ثبت کنید.','warn');return}
 const w=modal({title:'ثبت قرض جدید',size:'lg',body:`<form data-form="loan" class="form">${fld('مشتری *',`<select name="c"><option value="">انتخاب…</option>${L('customers').filter(c=>c.active).map(c=>`<option value="${c.id}" ${pre.customerId===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>`,'w2')}
 ${fld('نوع قرض *',sel('kind',[['out','قرض فروشگاه به مشتری (طلب فروشگاه)'],['in','قرض مشتری به فروشگاه (بدهی فروشگاه)']],pre.kind||'out'),'w2')}${fld('مبلغ اصلی (تومان) *',minp('amount','','required'))}${fld('تاریخ ثبت',dateField('d',D.today()))}${fld('تاریخ سررسید (اختیاری)',dateField('due',null,{optional:true}))}
 ${fld('علت یا عنوان *',inp('title','','required'),'w2')}${fld('شماره سند (خودکار در صورت خالی)',inp('doc'))}${fld('روش پرداخت',sel('m',Object.entries(METHODS).filter(x=>x[0]!=='check')))}${fld('ثبت‌کننده',`<input value="${esc(A.user.name)}" disabled>`)}
 ${fld('پیوست / تصویر رسید (اختیاری)','<input type="file" name="img" accept="image/*">')}${fld('توضیحات کامل',`<textarea name="note"></textarea>`,'full')}<button class="btn p full" type="submit">${ic('check')} ثبت قرض</button></form>`});w.dataset.lock=1}
FORM.loan=async f=>{const o=formData(f);const l=await createLoan({customerId:o.c,kind:o.kind,amount:pMoney(o.amount),date:readDate(f,'d'),dueDate:readDate(f,'due',{optional:true,label:'تاریخ سررسید'}),title:o.title,docNo:o.doc,method:o.m,note:o.note,image:o.img?.length?await readImage(o.img[0]):''});
 toast(`قرض ${l.no} ثبت شد.`);closeModal(f.closest('.mw'));CUR.refresh()};
ACT.loanpay=el=>{const l=G('loans',el.dataset.id);openPaymentForm({refType:'loan',refId:l.id,customerId:l.customerId})};
ACT.loansettle=async el=>{const l=G('loans',el.dataset.id);const i=loanInfo(l);if(!(await confirmBox(`قرض ${l.no} به مبلغ باقی‌مانده <b>${money(i.remaining)}</b> به‌صورت کامل تسویه شود؟ (روش: نقدی، تاریخ امروز)`)))return;
 await addPayment({dir:l.kind==='out'?'in':'out',customerId:l.customerId,amount:i.remaining,method:'cash',date:D.today(),refType:'loan',refId:l.id,note:'تسویه کامل'});toast('قرض تسویه شد.');closeModal();CUR.refresh()};
const loanBody=(l,ledger)=>{const i=loanInfo(l);return shopHead(ledger?'گردش حساب قرض '+l.no:'رسید قرض '+l.no)+`<div>مشتری: <b>${esc(nameOfC(l.customerId))}</b> · نوع: <b>${l.kind==='out'?'قرض فروشگاه به مشتری':'قرض مشتری به فروشگاه'}</b> · تاریخ: ${D.fmt(l.date)} · سررسید: ${l.dueDate?D.fmt(l.dueDate):'—'}</div><div>عنوان: ${esc(l.title)} ${l.note?'· '+esc(l.note):''} · سند: ${esc(l.docNo||l.no)}</div>
 <table><tr><th>تاریخ</th><th>شرح</th><th>روش</th><th class="n">مبلغ</th></tr><tr><td>${D.fmt(l.date)}</td><td>مبلغ اصلی قرض</td><td>${mlabel(l.method)}</td><td class="n">${num(l.amount)}</td></tr>${i.pays.sort((a,b)=>a.date.j-b.date.j).map(p=>`<tr><td>${D.fmt(p.date)}</td><td>${l.kind==='out'?'دریافت بازپرداخت':'پرداخت به مشتری'} (${p.no})</td><td>${mlabel(p.method)}</td><td class="n">${num(p.amount)}</td></tr>`).join('')}</table>
 <div class="tot"><div><span>مبلغ اصلی</span><span>${money(l.amount)}</span></div><div><span>مجموع پرداخت‌شده</span><span>${money(i.paid)}</span></div><div class="b"><span>مانده</span><span>${money(i.remaining)}</span></div></div><div class="sig"><span>امضای فروشگاه</span><span>امضای مشتری</span></div>`};
ACT.loanview=el=>{const l=G('loans',el.dataset.id);const i=loanInfo(l);modal({title:`قرض ${l.no} - ${nameOfC(l.customerId)}`,size:'lg',body:`<div class="stats">${statCard('نوع',l.kind==='out'?'فروشگاه به مشتری':'مشتری به فروشگاه')}${statCard('مبلغ اولیه',money(l.amount))}${statCard('پرداخت‌شده',money(i.paid),'ok')}${statCard('مانده فعلی',money(i.remaining),i.remaining?'err':'ok')}</div>
 <div class="kv" style="margin-bottom:10px"><span>عنوان</span><b>${esc(l.title)}</b><span>تاریخ ثبت</span><b>${D.fmt(l.date)}</b><span>سررسید</span><b>${l.dueDate?D.fmt(l.dueDate):'—'}</b><span>آخرین پرداخت</span><b>${D.fmt(i.last)}</b><span>شماره سند</span><b>${esc(l.docNo||l.no)}</b><span>ثبت‌کننده</span><b>${esc(l.userName||'')}</b><span>توضیحات</span><b>${esc(l.note||'—')}</b></div>${l.image?`<img src="${l.image}" alt="رسید" style="max-width:100%;max-height:260px;border-radius:10px;margin-bottom:10px">`:''}
 <h3>پرداخت‌های این قرض</h3>${paysTable(i.pays,'lvp')}`,
 footer:`${i.remaining>0&&can('payments')?`<button class="btn p" data-act="loanpay" data-id="${l.id}">${l.kind==='out'?'دریافت بازپرداخت':'پرداخت به مشتری'}</button><button class="btn" data-act="loansettle" data-id="${l.id}">تسویه کامل</button>`:''}<button class="btn" data-act="loanprint" data-id="${l.id}" data-m="r">${ic('printer')} چاپ رسید</button><button class="btn" data-act="loanprint" data-id="${l.id}" data-m="l">${ic('printer')} چاپ گردش حساب</button>${can('cancel_sale')?`<button class="btn d" data-act="loanvoid" data-id="${l.id}">ابطال قرض</button>`:''}`})};
ACT.loanprint=el=>{const l=G('loans',el.dataset.id);printDoc('قرض '+l.no,loanBody(l,el.dataset.m==='l'))};
ACT.loanvoid=async el=>{if(!(await confirmBox('قرض و تمام بازپرداخت‌های آن ابطال و اثر آن از دفتر حساب معکوس شود؟',{danger:true,ok:'ابطال قرض'})))return;await voidLoan(el.dataset.id);toast('قرض ابطال شد.');closeModal();CUR.refresh()};

/* ============ چک‌ها ============ */
const CKF={q:'',t:'',r:'all'};
function checksTable(rows,id,acts=false){return tbl([{h:'شماره چک',f:c=>`<b>${esc(c.number)}</b>`},{h:'مشتری / طرف حساب',f:c=>esc(partyName(c))},{h:'بانک',f:c=>esc(c.bank)},{h:'مبلغ',cls:'n',f:c=>num(c.amount)},{h:'نوع',f:c=>c.type==='in'?badge('دریافتی','ok'):badge('پرداختی','warn')},{h:'تاریخ ثبت',f:c=>D.fmt(c.issueDate)},{h:'تاریخ سررسید',f:c=>D.fmt(c.dueDate)},{h:'زمان باقی‌مانده',f:c=>checkOpen(c)?remainText(c):'—'},{h:'وضعیت',f:c=>{const s=checkState(c);return badge(s.t,s.c)}},
 {h:'عملیات',f:c=>`<div class="act"><button class="btn s" data-act="ckview" data-id="${c.id}">${ic('eye')}</button>${checkOpen(c)&&can('checks')?`<button class="btn s p" data-act="ckdo" data-id="${c.id}" data-a="${c.type==='in'?'collect':'pay'}">${c.type==='in'?'وصول':'پرداخت'}</button><button class="btn s" data-act="ckdo" data-id="${c.id}" data-a="bounce">برگشت</button><button class="btn s" data-act="ckedit" data-id="${c.id}">${ic('edit')}</button><button class="btn s d" data-act="ckdo" data-id="${c.id}" data-a="void">ابطال</button>`:''}</div>`}],rows,{id,empty:'چکی یافت نشد.',foot:rows.length?`<tr><td colspan="3">جمع (${num(rows.length)} چک)</td><td class="n">${num(sum(rows,c=>c.amount))}</td><td colspan="6"></td></tr>`:''})}
PAGES.checks=(el,q)=>{if(q.q){CKF.q=q.q;CKF.r='all';history.replaceState(null,'','#/checks')}if(q.s){CKF.r=q.s;history.replaceState(null,'','#/checks')}
 const open=L('checks').filter(checkOpen);
 el.innerHTML=`<div class="hd"><h2>مدیریت چک‌ها</h2><button class="btn p" data-act="qcheck">${ic('plus')} ثبت چک</button><button class="btn" data-act="goto" data-to="notifs">${ic('bell')} تنظیم یادآوری</button></div>
 <div class="stats">${statCard('چک‌های دریافتی در انتظار',num(open.filter(c=>c.type==='in').length),'ok',money(sum(open.filter(c=>c.type==='in'),c=>c.amount)))}${statCard('چک‌های پرداختی در انتظار',num(open.filter(c=>c.type==='out').length),'warn',money(sum(open.filter(c=>c.type==='out'),c=>c.amount)))}${statCard('نزدیک به سررسید',num(open.filter(c=>checkState(c).k==='near').length),'warn')}${statCard('سررسیدشده',num(open.filter(c=>checkState(c).k==='overdue').length),'err')}</div>
 <div class="tb">${fld('جستجو (شماره چک، مشتری، بانک)',`<input id="ckq" value="${esc(CKF.q)}" data-in="ckf">`,'w2')}${fld('نوع',sel('ckt',[['','همه'],['in','دریافتی'],['out','پرداختی']],CKF.t,'data-ch="ckf"'),'sm')}${fld('فیلتر',sel('ckr',[['all','همه'],['today','امروز'],['tomorrow','فردا'],['week','هفت روز آینده'],['near','نزدیک به سررسید'],['overdue','سررسیدشده'],['collected','وصول/پرداخت‌شده'],['bounced','برگشتی'],['void','باطل‌شده']],CKF.r,'data-ch="ckf"'),'sm')}</div><div id="ckt2"></div>`;
 CUR.draw=()=>{CKF.q=$('#ckq').value;CKF.t=$('[name=ckt]').value;CKF.r=$('[name=ckr]').value;const q=toEn(CKF.q).toLowerCase(),t=D.todayJ();
  const r=L('checks').filter(c=>{if(CKF.t&&c.type!==CKF.t)return false;const o=checkOpen(c),j=c.dueDate.j;
   switch(CKF.r){case 'today':if(!o||j!==t)return false;break;case 'tomorrow':if(!o||j!==t+1)return false;break;case 'week':if(!o||j<t||j>t+7)return false;break;case 'near':if(checkState(c).k!=='near')return false;break;case 'overdue':if(checkState(c).k!=='overdue')return false;break;case 'collected':if(!['collected','paid'].includes(c.status))return false;break;case 'bounced':if(c.status!=='bounced')return false;break;case 'void':if(c.status!=='void')return false}
   return !q||(c.number+partyName(c)+c.bank+c.no+c.sayad).toLowerCase().includes(q)}).sort((a,b)=>a.dueDate.j-b.dueDate.j);$('#ckt2').innerHTML=checksTable(r,'ck')};CUR.draw()};
INP.ckf=()=>{PG.ck=0;CUR.draw()};
function openCheckForm(pre={}){if(!L('customers').length&&!L('suppliers').length){toast('ابتدا مشتری یا تأمین‌کننده ثبت کنید.','warn');return}
 const w=modal({title:'ثبت چک جدید',size:'lg',body:`<form data-form="check" class="form">${fld('نوع چک',sel('type',[['in','دریافتی (از مشتری)'],['out','پرداختی (به مشتری/تأمین‌کننده)']],'in','data-ch="ckref"'))}
 ${fld('طرف حساب *',`<select name="who" data-ch="ckref"><option value="">انتخاب…</option><optgroup label="مشتریان">${L('customers').map(c=>`<option value="c:${c.id}" ${pre.customerId===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</optgroup><optgroup label="تأمین‌کنندگان">${L('suppliers').map(c=>`<option value="s:${c.id}">${esc(c.name)}</option>`).join('')}</optgroup></select>`)}
 ${fld('اتصال به فاکتور یا قرض',`<select name="ref"></select>`,'w2')}${fld('شماره چک *',inp('n','','required'))}${fld('مبلغ چک (تومان) *',minp('amount','','required'))}${fld('نام بانک *',inp('bank','','required'))}${fld('نام صاحب حساب',inp('owner'))}${fld('شماره حساب',inp('acc'))}${fld('شناسه صیادی',inp('sayad'))}
 ${fld('تاریخ دریافت / صدور',dateField('issue',D.today()))}${fld('تاریخ سررسید *',dateField('due',D.fromJ(D.todayJ()+30)))}${fld('ثبت‌کننده',`<input value="${esc(A.user.name)}" disabled>`)}${fld('تصویر چک (اختیاری)','<input type="file" name="img" accept="image/*">')}${fld('توضیحات',`<textarea name="note"></textarea>`,'full')}
 <div class="warnbox full">با ثبت چک، مبلغ آن به‌عنوان پرداخت (روش چک) به حساب طرف مقابل منظور می‌شود؛ در صورت برگشت چک، اثر آن به‌صورت خودکار معکوس می‌شود.</div><button class="btn p full" type="submit">${ic('check')} ثبت چک</button></form>`});
 INP.ckref=()=>{const f=$('form[data-form=check]');const[t,id]=($('[name=who]',f).value||':').split(':');const d=$('[name=type]',f).value;const o=[['general:','بدون اتصال (پرداخت عمومی)']];
  if(t==='c'){if(d==='in')L('sales').filter(s=>s.customerId===id&&s.status==='active'&&saleInfo(s).remain>0).forEach(s=>o.push(['sale:'+s.id,`فاکتور ${s.no} - مانده ${num(saleInfo(s).remain)}`]));L('loans').filter(l=>l.customerId===id&&loanInfo(l).remaining>0&&((l.kind==='out')===(d==='in'))).forEach(l=>o.push(['loan:'+l.id,`قرض ${l.no} - مانده ${num(loanInfo(l).remaining)}`]))}
  if(t==='s')L('purchases').filter(p=>p.supplierId===id).forEach(p=>o.push(['purchase:'+p.id,`خرید ${p.no} - ${num(p.total)}`]));
  $('[name=ref]',f).innerHTML=o.map(x=>`<option value="${x[0]}">${esc(x[1])}</option>`).join('')};INP.ckref();w.dataset.lock=1}
FORM.check=async f=>{const o=formData(f);const[t,id]=(o.who||':').split(':');if(!id)throw E('طرف حساب را انتخاب کنید.');const[rt,rid]=(o.ref||'general:').split(':');const amount=pMoney(o.amount);
 const p=await addPayment({dir:o.type,customerId:t==='c'?id:null,supplierId:t==='s'?id:null,amount,method:'check',date:readDate(f,'issue',{label:'تاریخ دریافت/صدور'}),refType:rt||'general',refId:rid||null,note:'چک '+o.n,
  check:{number:o.n,bank:o.bank,owner:o.owner,account:o.acc,sayad:o.sayad,issueDate:readDate(f,'issue'),dueDate:readDate(f,'due',{label:'تاریخ سررسید'}),note:o.note,image:o.img?.length?await readImage(o.img[0]):''}});
 await runReminders();toast('چک ثبت شد.');closeModal(f.closest('.mw'));CUR.refresh()};
ACT.ckdo=async el=>{const c=G('checks',el.dataset.id),a=el.dataset.a;const msg={collect:'چک وصول‌شده ثبت شود؟',pay:'چک پرداخت‌شده ثبت شود؟',bounce:'چک برگشت‌خورده ثبت شود؟ پرداخت مربوطه ابطال و بدهی/طلب به حالت قبل بازمی‌گردد.',void:'چک باطل شود؟ پرداخت مربوطه نیز معکوس می‌شود.'}[a];
 if(!(await confirmBox(`چک <b>${esc(c.number)}</b> به مبلغ ${money(c.amount)}<br>${msg}`,{danger:a==='bounce'||a==='void',ok:'تأیید'})))return;await checkAction(c.id,a);toast('وضعیت چک به‌روز شد.');closeModal();CUR.refresh()};
ACT.ckview=el=>{const c=G('checks',el.dataset.id);const s=checkState(c);modal({title:'چک '+c.number,body:`<div class="kv" style="margin-bottom:10px"><span>وضعیت</span><b>${badge(s.t,s.c)}</b><span>نوع</span><b>${c.type==='in'?'دریافتی':'پرداختی'}</b><span>طرف حساب</span><b>${esc(partyName(c))}</b><span>مبلغ</span><b class="gold">${money(c.amount)}</b><span>بانک</span><b>${esc(c.bank)}</b><span>صاحب حساب</span><b>${esc(c.owner||'—')}</b><span>شماره حساب</span><b>${esc(c.account||'—')}</b><span>شناسه صیادی</span><b>${esc(c.sayad||'—')}</b><span>تاریخ دریافت/صدور</span><b>${D.fmt(c.issueDate)}</b><span>سررسید</span><b>${D.fmt(c.dueDate)} ${checkOpen(c)?'('+remainText(c)+')':''}</b><span>اتصال</span><b>${c.refType==='sale'?'فاکتور '+(G('sales',c.refId)?.no||''):c.refType==='loan'?'قرض '+(G('loans',c.refId)?.no||''):'—'}</b><span>پرداخت مرتبط</span><b>${G('payments',c.paymentId)?.no||''}</b><span>توضیحات</span><b>${esc(c.note||'—')}</b></div>${c.image?`<img alt="تصویر چک" src="${c.image}" style="max-width:100%;border-radius:10px">`:''}<h3>تاریخچه</h3>${c.log.map(l=>`<div class="mu">${dtime(l.ts)} - ${esc(l.a)} (${esc(l.u||'')})</div>`).join('')}`})};
ACT.ckedit=el=>{const c=G('checks',el.dataset.id);modal({title:'ویرایش چک '+c.number,body:`<form data-form="ckedit" data-id="${c.id}" class="form">${fld('شماره چک',inp('n',c.number,'required'))}${fld('بانک',inp('bank',c.bank,'required'))}${fld('صاحب حساب',inp('owner',c.owner))}${fld('شماره حساب',inp('acc',c.account))}${fld('شناسه صیادی',inp('sayad',c.sayad))}${fld('سررسید',dateField('due',c.dueDate))}${fld('تصویر جدید','<input type="file" name="img" accept="image/*">')}${fld('توضیحات',`<textarea name="note">${esc(c.note)}</textarea>`,'full')}<div class="warnbox full">برای تغییر مبلغ، چک را ابطال و دوباره ثبت کنید.</div><button class="btn p full">ذخیره</button></form>`})};
FORM.ckedit=async f=>{const o=formData(f);await editCheck(f.dataset.id,{number:o.n,bank:o.bank,owner:o.owner,account:o.acc,sayad:o.sayad,dueDate:readDate(f,'due'),note:o.note,image:o.img?.length?await readImage(o.img[0]):undefined});await runReminders();toast('چک ویرایش شد.');closeModal(f.closest('.mw'));CUR.refresh()};

/* ============ یادآوری‌ها ============ */
const PRESETS=[[0,'روز سررسید'],[24,'۲۴ ساعت قبل'],[48,'۴۸ ساعت قبل'],[72,'۷۲ ساعت (۳ روز) قبل'],[120,'۵ روز قبل'],[168,'۷ روز قبل']];
const offLabel=h=>h===0?'روز سررسید':h%24===0?`${num(h/24)} روز قبل (${num(h)} ساعت)`:`${num(h)} ساعت قبل`;
let NF='all';
PAGES.notifs=(el)=>{const s=SET();const rules=L('checkReminders').sort((a,b)=>b.offsetHours-a.offsetHours);
 const rb=(k,t)=>`<div class="card"><h3>${t}</h3>${rules.filter(r=>r.kind===k).map(r=>`<div class="fl" style="justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line)"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" style="width:auto" data-ch="rtoggle" data-id="${r.id}" ${r.enabled?'checked':''}> ${offLabel(r.offsetHours)}</label><button class="btn s d" data-act="rdel" data-id="${r.id}">${ic('trash')}</button></div>`).join('')||'<div class="mu">یادآوری تعریف نشده است.</div>'}
  <form data-form="rule" data-k="${k}" class="tb" style="margin-top:10px">${fld('افزودن یادآوری',`<select name="p">${PRESETS.map(p=>`<option value="${p[0]}">${p[1]}</option>`).join('')}<option value="custom">زمان دلخواه…</option></select>`,'sm')}${fld('مقدار دلخواه',`<input name="v" inputmode="numeric" placeholder="عدد">`,'sm')}${fld('واحد',sel('u',[['h','ساعت'],['d','روز']]),'sm')}<button class="btn p">${ic('plus')}</button></form></div>`;
 const list=notifActive().sort((a,b)=>b.ts-a.ts).filter(n=>NF==='all'||(NF==='unread'&&!n.read));
 el.innerHTML=`<div class="hd"><h2>یادآوری‌ها و اعلان‌ها</h2><button class="btn" data-act="readall">علامت همه به‌عنوان خوانده‌شده</button></div>
 <div class="warnbox">توجه: این برنامه یک فایل محلی است؛ اعلان‌ها فقط وقتی برنامه در مرورگر باز باشد (یا تب در پس‌زمینه فعال بماند) بررسی و نمایش داده می‌شوند و نمی‌توان زمان دقیق اعلان سیستم‌عامل را هنگام بسته‌بودن برنامه تضمین کرد. با باز کردن برنامه، یادآوری‌های سررسیدشده بلافاصله ساخته می‌شوند و هر اعلان فقط یک‌بار نمایش داده می‌شود.</div>
 <div class="grid g2" style="margin-bottom:14px">${rb('in','یادآوری چک‌های دریافتی')}${rb('out','یادآوری چک‌های پرداختی')}</div>
 <div class="card" style="margin-bottom:14px"><h3>تنظیمات اعلان</h3><form data-form="notset" class="form"><label class="f" style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" name="en" style="width:auto" ${s.remEnabled?'checked':''}> یادآوری‌ها فعال باشد</label>${fld('ساعت نمایش اعلان',`<input type="time" name="t" value="${s.notifyTime}">`,'sm')}${fld('«نزدیک به سررسید» یعنی (روز)',`<input name="nd" inputmode="numeric" value="${s.nearDays}">`,'sm')}<label class="f" style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" name="lr" style="width:auto" ${s.loanRemind?'checked':''}> هشدار قرض‌های معوق</label><label class="f" style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" name="br" style="width:auto" ${s.backupRemind?'checked':''}> یادآوری پشتیبان‌گیری روزانه</label><button class="btn p">ذخیره</button><button type="button" class="btn" data-act="notperm">اجازه اعلان مرورگر (${window.Notification?({granted:'داده‌شده',denied:'رد شده',default:'درخواست نشده'})[Notification.permission]:'پشتیبانی نمی‌شود'})</button></form></div>
 <div class="tabs"><button class="${NF==='all'?'on':''}" data-act="nf" data-t="all">همه اعلان‌ها</button><button class="${NF==='unread'?'on':''}" data-act="nf" data-t="unread">خوانده‌نشده</button></div>
 ${tbl([{h:'زمان',f:n=>dtime(n.ts)},{h:'اعلان',f:n=>{const c=n.kind==='check'?G('checks',n.refId):null;return `${n.read?'':'<span class="bg gd">جدید</span> '}<b>${esc(n.title)}</b>${c?`<br><small class="mu">${esc(partyName(c))} · ${money(c.amount)} · سررسید ${D.fmt(c.dueDate)} · ${checkOpen(c)?remainText(c):checkState(c).t}</small>`:''}`}},
  {h:'عملیات',f:n=>`<div class="act">${n.read?'':`<button class="btn s" data-act="nread" data-id="${n.id}">خوانده شد</button>`}<button class="btn s" data-act="nsnooze" data-id="${n.id}" data-h="1">تعویق ۱ساعت</button><button class="btn s" data-act="nsnooze" data-id="${n.id}" data-h="24">تعویق ۱روز</button>${n.kind!=='backup'?`<button class="btn s" data-act="ngo" data-id="${n.id}">مشاهده</button>`:`<button class="btn s" data-act="goto" data-to="backup">پشتیبان</button>`}<button class="btn s d" data-act="ndel" data-id="${n.id}">${ic('x')}</button></div>`}],list,{id:'nt',empty:'اعلانی وجود ندارد.'})}`};
INP.rtoggle=async el=>{const r=clone(G('checkReminders',el.dataset.id));r.enabled=el.checked;await DB.commit([{s:'checkReminders',put:r}]);await runReminders();toast('ذخیره شد.')};
ACT.rdel=async el=>{await DB.commit([{s:'checkReminders',del:el.dataset.id}]);CUR.refresh()};
FORM.rule=async f=>{const k=f.dataset.k;let h=Number(f.p.value);if(f.p.value==='custom'){const v=Number(toEn(f.v.value));if(!(v>0))throw E('مقدار دلخواه را وارد کنید.');h=f.u.value==='d'?Math.round(v*24):Math.round(v)}
 if(L('checkReminders').some(r=>r.kind===k&&r.offsetHours===h))throw E('این زمان قبلاً تعریف شده است.');await DB.commit([{s:'checkReminders',put:{id:uid(),kind:k,offsetHours:h,enabled:true}}]);const fresh=await runReminders();announce(fresh);toast('یادآوری اضافه شد.');CUR.refresh()};
FORM.notset=async f=>{const ops=[];const nd=Number(toEn(f.nd.value));if(!(nd>=0&&nd<=365))throw E('تعداد روز نامعتبر است.');setOp(ops,{remEnabled:f.en.checked,notifyTime:f.t.value||'09:00',nearDays:nd,loanRemind:f.lr.checked,backupRemind:f.br.checked});audit(ops,'تغییر تنظیمات یادآوری','settings','main');await DB.commit(ops);toast('تنظیمات ذخیره شد.');CUR.refresh()};
ACT.notperm=async()=>{if(!window.Notification)throw E('مرورگر شما از اعلان پشتیبانی نمی‌کند؛ اعلان‌ها داخل برنامه نمایش داده می‌شوند.');const r=await Notification.requestPermission();toast(r==='granted'?'اجازه اعلان فعال شد.':'اجازه داده نشد.',r==='granted'?'ok':'warn');CUR.refresh()};
ACT.nf=el=>{NF=el.dataset.t;CUR.refresh()};
const upN=async(id,patch)=>{await DB.commit([{s:'notifications',put:{...G('notifications',id),...patch}}]);CUR.refresh()};
ACT.nread=el=>upN(el.dataset.id,{read:true});ACT.nsnooze=async el=>{await upN(el.dataset.id,{snoozeUntil:Date.now()+Number(el.dataset.h)*36e5,read:true});toast('اعلان به تعویق افتاد.')};
ACT.ndel=async el=>{await DB.commit([{s:'notifications',del:el.dataset.id}]);CUR.refresh()};
ACT.readall=async()=>{await DB.commit(L('notifications').filter(n=>!n.read).map(n=>({s:'notifications',put:{...n,read:true}})));CUR.refresh()};
ACT.ngo=async el=>{const n=G('notifications',el.dataset.id);await DB.commit([{s:'notifications',put:{...n,read:true}}]);if(n.kind==='check')go('checks?q='+encodeURIComponent(G('checks',n.refId)?.number||''));else if(n.kind==='loan')go('loans?q='+(G('loans',n.refId)?.no||''))};

/* ============ گزارش‌ها ============ */
const RF={k:'sales_daily',from:null,to:null,c:'',p:'',m:'',s:'',tt:''};
const cT=(h,t='t',s=false)=>({h,t,s});
const salesF=F=>activeSales().filter(s=>(!F.f||s.date.j>=F.f)&&(!F.t||s.date.j<=F.t)&&(!F.c||s.customerId===F.c));
function groupSales(F,keyf,labf){const m=new Map();salesF(F).forEach(s=>{const k=keyf(s.date);if(!m.has(k))m.set(k,{k,l:labf(s.date),n:0,sub:0,disc:0,ex:0,tot:0,cg:0});const g=m.get(k);g.n++;g.sub+=s.subtotal;g.disc+=s.discount;g.ex+=s.extra;g.tot+=s.total;g.cg+=s.cogs});
 return[...m.values()].sort((a,b)=>b.k-a.k).map(g=>[g.l,g.n,g.sub,g.disc,g.ex,g.tot,g.cg,g.tot-g.cg])}
const SC=[cT('دوره'),cT('تعداد فاکتور','n',true),cT('جمع اقلام','m',true),cT('تخفیف','m',true),cT('هزینه اضافی','m',true),cT('فروش نهایی','m',true),cT('بهای تمام‌شده','m',true),cT('سود ناخالص','m',true)];
const payF=(F,dir)=>L('payments').filter(p=>!p.voided&&p.dir===dir&&(!F.f||p.date.j>=F.f)&&(!F.t||p.date.j<=F.t)&&(!F.c||p.customerId===F.c)&&(!F.m||p.method===F.m));
const loanRep=(F,kind)=>({cols:[cT('شماره'),cT('مشتری'),cT('عنوان'),cT('تاریخ','d'),cT('سررسید','d'),cT('مبلغ اولیه','m',true),cT('پرداخت‌شده','m',true),cT('مانده','m',true),cT('وضعیت')],
 rows:L('loans').filter(l=>l.status!=='void'&&l.kind===kind&&(!F.f||l.date.j>=F.f)&&(!F.t||l.date.j<=F.t)&&(!F.c||l.customerId===F.c)&&(!F.s||loanInfo(l).status===F.s)).sort((a,b)=>b.date.j-a.date.j).map(l=>{const i=loanInfo(l);return[l.no,nameOfC(l.customerId),l.title,l.date,l.dueDate,l.amount,i.paid,i.remaining,{settled:'تسویه‌شده',open:'باز',overdue:'معوق'}[i.status]]})});
const chRep=(F,pred)=>({cols:[cT('شماره چک'),cT('طرف حساب'),cT('بانک'),cT('نوع'),cT('تاریخ ثبت','d'),cT('سررسید','d'),cT('مبلغ','m',true),cT('وضعیت')],rows:L('checks').filter(c=>pred(c)&&(!F.f||c.dueDate.j>=F.f)&&(!F.t||c.dueDate.j<=F.t)&&(!F.c||c.customerId===F.c)&&(!F.s||checkState(c).k===F.s)).sort((a,b)=>a.dueDate.j-b.dueDate.j).map(c=>[c.number,partyName(c),c.bank,c.type==='in'?'دریافتی':'پرداختی',c.issueDate,c.dueDate,c.amount,checkState(c).t])});
const soldItems=F=>salesF(F).flatMap(s=>s.items.map(i=>({...i,s}))).filter(i=>!F.p||i.productId===F.p);
function prodProfit(F){const m=new Map();soldItems(F).forEach(i=>{if(!m.has(i.productId))m.set(i.productId,{q:0,r:0,c:0});const g=m.get(i.productId);g.q+=i.qty;g.r+=i.amount;g.c+=i.cogs});return m}
const REPORTS=[
 {k:'sales_daily',t:'گزارش فروش روزانه',f:['date','customer'],run:F=>({cols:[cT('تاریخ'),...SC.slice(1)],rows:groupSales(F,d=>d.j,d=>D.fmt(d))})},
 {k:'sales_monthly',t:'گزارش فروش ماهانه',f:['date','customer'],run:F=>({cols:[cT('ماه'),...SC.slice(1)],rows:groupSales(F,d=>d.y*100+d.m,d=>D.fa2(d.y)+' '+D.mn(d.m))})},
 {k:'sales_yearly',t:'گزارش فروش سالانه',f:['date','customer'],run:F=>({cols:[cT('سال'),...SC.slice(1)],rows:groupSales(F,d=>d.y,d=>D.fa2(d.y))})},
 {k:'receipts',t:'گزارش دریافتی‌ها',f:['date','customer','method'],run:F=>({cols:[cT('تاریخ','d'),cT('شماره'),cT('مشتری'),cT('بابت'),cT('روش'),cT('مبلغ','m',true),cT('پیگیری')],rows:payF(F,'in').sort((a,b)=>b.date.j-a.date.j).map(p=>[p.date,p.no,p.customerId?nameOfC(p.customerId):'—',refText(p),mlabel(p.method)+(p.method==='check'&&!cashInfo(p)?' (وصول‌نشده)':''),p.amount,p.tracking])})},
 {k:'payouts',t:'گزارش پرداختی‌ها (و هزینه‌ها)',f:['date','customer','method'],run:F=>({cols:[cT('تاریخ','d'),cT('شماره'),cT('طرف حساب / عنوان'),cT('بابت'),cT('روش'),cT('مبلغ','m',true)],rows:[...payF(F,'out').map(p=>[p.date,p.no,p.customerId?nameOfC(p.customerId):G('suppliers',p.supplierId)?.name||'—',refText(p),mlabel(p.method),p.amount]),...L('expenses').filter(e=>!e.voided&&(!F.f||e.date.j>=F.f)&&(!F.t||e.date.j<=F.t)&&!F.c&&(!F.m||e.method===F.m)).map(e=>[e.date,e.no,e.title,'هزینه',mlabel(e.method),e.amount])].sort((a,b)=>b[0].j-a[0].j)})},
 {k:'debtors',t:'گزارش بدهکاران',f:[],run:()=>({cols:[cT('مشتری'),cT('موبایل'),cT('بابت فاکتورها','m',true),cT('بابت قرض','m',true),cT('مانده بدهی','m',true),cT('سقف اعتبار','m')],rows:L('customers').map(c=>({c,b:custBal(c.id)})).filter(x=>x.b.R>0).sort((a,b)=>b.b.R-a.b.R).map(x=>[x.c.name,x.c.phone,x.b.sub.sale,x.b.sub.loan,x.b.R,x.c.creditLimit])})},
 {k:'creditors',t:'گزارش بستانکاران',f:[],run:()=>({cols:[cT('مشتری'),cT('موبایل'),cT('قرض گرفته‌شده از او (بدهی فروشگاه)','m',true),cT('اعتبار نزد فروشگاه','m',true),cT('جمع طلب مشتری','m',true)],rows:L('customers').map(c=>({c,b:custBal(c.id)})).filter(x=>x.b.P>0||x.b.R<0).sort((a,b)=>b.b.P-b.b.R-(a.b.P-a.b.R)).map(x=>[x.c.name,x.c.phone,x.b.P,Math.max(-x.b.R,0),x.b.P+Math.max(-x.b.R,0)])})},
 {k:'loans_out',t:'گزارش قرض‌های پرداختی (فروشگاه به مشتری)',f:['date','customer','status'],so:[['open','باز'],['overdue','معوق'],['settled','تسویه‌شده']],run:F=>loanRep(F,'out')},
 {k:'loans_in',t:'گزارش قرض‌های دریافتی (مشتری به فروشگاه)',f:['date','customer','status'],so:[['open','باز'],['overdue','معوق'],['settled','تسویه‌شده']],run:F=>loanRep(F,'in')},
 {k:'checks_in',t:'گزارش چک‌های دریافتی',f:['date','customer','status'],so:'ck',run:F=>chRep(F,c=>c.type==='in')},
 {k:'checks_out',t:'گزارش چک‌های پرداختی',f:['date','customer','status'],so:'ck',run:F=>chRep(F,c=>c.type==='out')},
 {k:'checks_over',t:'گزارش چک‌های سررسیدشده',f:['customer'],run:F=>chRep({...F,f:null,t:null},c=>checkState(c).k==='overdue')},
 {k:'profit',t:'گزارش سود (صورت سود و زیان ماهانه)',f:['date'],run:F=>{const ms=new Map();const g=k=>{if(!ms.has(k))ms.set(k,{l:D.fa2(Math.floor(k/100))+' '+D.mn(k%100),r:0,c:0,e:0,w:0});return ms.get(k)};
  salesF({...F,c:''}).forEach(s=>{const x=g(s.date.y*100+s.date.m);x.r+=s.total;x.c+=s.cogs});L('expenses').filter(e=>!e.voided&&(!F.f||e.date.j>=F.f)&&(!F.t||e.date.j<=F.t)).forEach(e=>g(e.date.y*100+e.date.m).e+=e.amount);
  L('inventory').filter(m=>m.type==='waste'&&(!F.f||m.date.j>=F.f)&&(!F.t||m.date.j<=F.t)).forEach(m=>g(m.date.y*100+m.date.m).w+=-m.qty*m.unitCost/1000);
  return{cols:[cT('ماه'),cT('فروش','m',true),cT('بهای تمام‌شده','m',true),cT('سود ناخالص','m',true),cT('هزینه‌ها','m',true),cT('ضایعات','m',true),cT('سود خالص','m',true)],rows:[...ms.entries()].sort((a,b)=>b[0]-a[0]).map(([k,x])=>[x.l,x.r,x.c,x.r-x.c,x.e,Math.round(x.w),Math.round(x.r-x.c-x.e-x.w)])}}},
 {k:'profit_product',t:'سود هر محصول و میانگین سود هر کیلو',f:['date','product'],run:F=>({cols:[cT('کالا'),cT('مقدار فروش','q',true),cT('فروش','m',true),cT('بهای تمام‌شده','m',true),cT('سود','m',true),cT('سود هر کیلو/واحد','m'),cT('حاشیه سود %','p')],rows:[...prodProfit(F)].sort((a,b)=>(b[1].r-b[1].c)-(a[1].r-a[1].c)).map(([id,g])=>[nameOfP(id),g.q,g.r,g.c,g.r-g.c,g.q?Math.round((g.r-g.c)*1000/g.q):0,g.r?Math.round((g.r-g.c)*1000/g.r)/10:0])})},
 {k:'profit_invoice',t:'سود هر فاکتور',f:['date','customer'],run:F=>({cols:[cT('فاکتور'),cT('تاریخ','d'),cT('مشتری'),cT('مبلغ','m',true),cT('بهای تمام‌شده','m',true),cT('سود','m',true)],rows:salesF(F).sort((a,b)=>b.date.j-a.date.j).map(s=>[s.no,s.date,nameOfC(s.customerId),s.total,s.cogs,s.total-s.cogs])})},
 {k:'stock',t:'گزارش موجودی انبار',f:['product'],run:F=>({cols:[cT('کالا'),cT('دسته'),cT('موجودی','q',true),cT('حداقل','q'),cT('بهای میانگین','m'),cT('ارزش موجودی','m',true),cT('وضعیت')],rows:L('products').filter(p=>!F.p||p.id===F.p).map(p=>{const s=stockOf(p.id);return[p.name,catName(p.categoryId),s,p.minStock,p.avgCost,Math.round(Math.max(0,s)*p.avgCost/1000),s<0?'منفی':s<=p.minStock?'کم‌موجود':'کافی']})})},
 {k:'movements',t:'گزارش گردش کالا',f:['date','product','type'],run:F=>({cols:[cT('تاریخ','d'),cT('کالا'),cT('نوع'),cT('ورود','q',true),cT('خروج','q',true),cT('قیمت واحد','m'),cT('ارزش','m',true),cT('توضیح')],rows:L('inventory').filter(m=>(!F.f||m.date.j>=F.f)&&(!F.t||m.date.j<=F.t)&&(!F.p||m.productId===F.p)&&(!F.tt||m.type===F.tt)).sort((a,b)=>b.date.j-a.date.j||b.ts-a.ts).map(m=>[m.date,nameOfP(m.productId),OUT_TYPES[m.type]||m.type,m.qty>0?m.qty:0,m.qty<0?-m.qty:0,m.unitCost,Math.round(Math.abs(m.qty)*m.unitCost/1000),m.note])})},
 {k:'waste',t:'گزارش ضایعات',f:['date','product'],run:F=>({cols:[cT('تاریخ','d'),cT('کالا'),cT('مقدار','q',true),cT('بهای واحد','m'),cT('زیان','m',true),cT('علت')],rows:L('inventory').filter(m=>m.type==='waste'&&(!F.f||m.date.j>=F.f)&&(!F.t||m.date.j<=F.t)&&(!F.p||m.productId===F.p)).sort((a,b)=>b.date.j-a.date.j).map(m=>[m.date,nameOfP(m.productId),-m.qty,m.unitCost,Math.round(-m.qty*m.unitCost/1000),m.note])})},
 {k:'best',t:'کالاهای پرفروش',f:['date'],run:F=>({cols:[cT('کالا'),cT('مقدار فروش','q',true),cT('فروش','m',true),cT('سود','m',true)],rows:[...prodProfit(F)].sort((a,b)=>b[1].q-a[1].q).map(([id,g])=>[nameOfP(id),g.q,g.r,g.r-g.c])})},
 {k:'slow',t:'کالاهای کم‌فروش',f:['date'],run:F=>{const pm=prodProfit(F);return{cols:[cT('کالا'),cT('مقدار فروش','q',true),cT('فروش','m',true),cT('موجودی فعلی','q')],rows:L('products').filter(p=>p.active).map(p=>[p.name,pm.get(p.id)?.q||0,pm.get(p.id)?.r||0,stockOf(p.id)]).sort((a,b)=>a[1]-b[1])}}},
 {k:'cust_perf',t:'گزارش عملکرد مشتریان',f:['date'],run:F=>{const m=new Map();salesF({...F,c:''}).forEach(s=>{const k=s.customerId||'-';if(!m.has(k))m.set(k,{n:0,t:0,p:0,pr:0});const g=m.get(k);g.n++;g.t+=s.total;g.p+=saleInfo(s).paid;g.pr+=s.total-s.cogs});
  return{cols:[cT('مشتری'),cT('فاکتورها','n',true),cT('جمع خرید','m',true),cT('پرداخت‌شده','m',true),cT('سود فروشگاه','m',true),cT('مانده فعلی حساب','m')],rows:[...m].sort((a,b)=>b[1].t-a[1].t).map(([id,g])=>[id==='-'?'مشتری متفرقه':nameOfC(id),g.n,g.t,g.p,g.pr,id==='-'?0:custBal(id).R])}}},
 {k:'seller_perf',t:'گزارش عملکرد فروشندگان',f:['date'],run:F=>{const m=new Map();salesF({...F,c:''}).forEach(s=>{const k=s.userName||'—';if(!m.has(k))m.set(k,{n:0,t:0,pr:0});const g=m.get(k);g.n++;g.t+=s.total;g.pr+=s.total-s.cogs});return{cols:[cT('فروشنده'),cT('فاکتورها','n',true),cT('جمع فروش','m',true),cT('سود ناخالص','m',true)],rows:[...m].sort((a,b)=>b[1].t-a[1].t).map(([k,g])=>[k,g.n,g.t,g.pr])}}}];
const cellTxt=(v,t)=>t==='m'?num(v):t==='q'?kgf(v):t==='n'?num(v):t==='d'?D.fmt(v):t==='p'?num(v)+'٪':v==null?'':esc(v);
const cellRaw=(v,t)=>t==='q'?v/1000:t==='d'?D.en(v):v==null?'':v;
function runReport(){const R=REPORTS.find(r=>r.k===RF.k);const F={f:RF.from?.j,t:RF.to?.j,c:RF.c,p:RF.p,m:RF.m,s:RF.s,tt:RF.tt};return{R,...R.run(F)}}
PAGES.reports=(el)=>{const cur=REPORTS.find(r=>r.k===RF.k);const f=cur.f;
 el.innerHTML=`<div class="hd"><h2>گزارش‌های مالی</h2><button class="btn" data-act="rpprint">${ic('printer')} چاپ</button><button class="btn" data-act="rpcsv">${ic('download')} CSV</button><button class="btn" data-act="rpxls">${ic('download')} اکسل</button></div>
 <div class="tb">${fld('گزارش',`<select name="rk" data-ch="rpk">${REPORTS.map(r=>`<option value="${r.k}" ${r.k===RF.k?'selected':''}>${r.t}</option>`).join('')}</select>`,'w2')}
 ${f.includes('date')?fld('از تاریخ',dateField('rf',RF.from,{optional:true,ch:'rpf'}))+fld('تا تاریخ',dateField('rt',RF.to,{optional:true,ch:'rpf'})):''}
 ${f.includes('customer')?fld('مشتری',`<select name="rc" data-ch="rpf"><option value="">همه</option>${L('customers').map(c=>`<option value="${c.id}" ${RF.c===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>`,'sm'):''}
 ${f.includes('product')?fld('کالا',`<select name="rp" data-ch="rpf"><option value="">همه</option>${L('products').map(c=>`<option value="${c.id}" ${RF.p===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>`,'sm'):''}
 ${f.includes('method')?fld('روش پرداخت',sel('rm',[['','همه'],...Object.entries(METHODS)],RF.m,'data-ch="rpf"'),'sm'):''}
 ${f.includes('status')?fld('وضعیت',sel('rs',[['','همه'],...(cur.so==='ck'?[['wait','در انتظار سررسید'],['near','نزدیک به سررسید'],['overdue','سررسیدشده'],['done','وصول/پرداخت‌شده'],['bounced','برگشتی'],['void','باطل']]:cur.so)],RF.s,'data-ch="rpf"'),'sm'):''}
 ${f.includes('type')?fld('نوع تراکنش',sel('rtt',[['','همه'],...Object.entries(OUT_TYPES)],RF.tt,'data-ch="rpf"'),'sm'):''}</div><div id="rpb"></div>`;initDates(el);
 CUR.draw=()=>{const g=n=>$(`[name=${n}]`,el);try{if(g('rk'))RF.k=g('rk').value;RF.from=$('[data-df=rf]',el)?readDate(el,'rf',{optional:true}):null;RF.to=$('[data-df=rt]',el)?readDate(el,'rt',{optional:true}):null}catch(e){}
  RF.c=g('rc')?.value||'';RF.p=g('rp')?.value||'';RF.m=g('rm')?.value||'';RF.s=g('rs')?.value||'';RF.tt=g('rtt')?.value||'';
  const r=runReport();const foot=r.rows.length?`<tr><td>جمع کل (${num(r.rows.length)} رکورد)</td>${r.cols.slice(1).map((c,i)=>`<td class="n">${c.s?cellTxt(sum(r.rows,x=>x[i+1]||0),c.t):''}</td>`).join('')}</tr>`:'';
  $('#rpb').innerHTML=`<div class="mu" style="margin-bottom:6px">${esc(r.R.t)} — ${num(r.rows.length)} رکورد</div>`+tbl(r.cols.map((c,i)=>({h:c.h,cls:['m','q','n','p'].includes(c.t)?'n':'',f:x=>cellTxt(x[i],c.t)})),r.rows,{id:'rp',empty:'داده‌ای برای این گزارش و فیلترها یافت نشد.',foot,size:60})};CUR.draw()};
INP.rpk=()=>{RF.k=$('[name=rk]').value;RF.s='';PG.rp=0;CUR.refresh()};INP.rpf=()=>{PG.rp=0;CUR.draw()};
const rpHtml=r=>`<table><thead><tr>${r.cols.map(c=>`<th class="${['m','q','n','p'].includes(c.t)?'n':''}">${c.h}</th>`).join('')}</tr></thead><tbody>${r.rows.map(x=>`<tr>${r.cols.map((c,i)=>`<td class="${['m','q','n','p'].includes(c.t)?'n':''}">${cellTxt(x[i],c.t)}</td>`).join('')}</tr>`).join('')}</tbody><tfoot><tr><th>جمع (${num(r.rows.length)} رکورد)</th>${r.cols.slice(1).map((c,i)=>`<th class="n">${c.s?cellTxt(sum(r.rows,x=>x[i+1]||0),c.t):''}</th>`).join('')}</tr></tfoot></table>`;
ACT.rpprint=()=>{const r=runReport();printDoc(r.R.t,shopHead(r.R.t)+(RF.from||RF.to?`<div>بازه: ${RF.from?D.fmt(RF.from):'ابتدا'} تا ${RF.to?D.fmt(RF.to):'اکنون'}</div>`:'')+rpHtml(r))};
ACT.rpcsv=()=>{const r=runReport();const t=r.cols.map(c=>c.t);csvDownload(r.R.k+'.csv',r.cols.map(c=>c.h),[...r.rows.map(x=>x.map((v,i)=>cellRaw(v,t[i]))),['جمع کل ('+r.rows.length+' رکورد)',...r.cols.slice(1).map((c,i)=>c.s?cellRaw(sum(r.rows,x=>x[i+1]||0),c.t):'')]])};
ACT.rpxls=()=>{const r=runReport();download(r.R.k+'.xls','<html dir="rtl"><head><meta charset="utf-8"></head><body>'+`<table border="1"><tr>${r.cols.map(c=>`<th>${c.h}</th>`).join('')}</tr>${r.rows.map(x=>`<tr>${r.cols.map((c,i)=>`<td>${esc(cellRaw(x[i],c.t))}</td>`).join('')}</tr>`).join('')}</table></body></html>`,'application/vnd.ms-excel')};

/* ============ کاربران ============ */
PAGES.users=(el)=>{el.innerHTML=`<div class="hd"><h2>مدیریت کاربران</h2><button class="btn p" data-act="uform">${ic('plus')} کاربر جدید</button></div>
 <div class="warnbox">امنیت: رمزها به‌صورت هش‌شده در همین دستگاه ذخیره می‌شوند. چون برنامه یک فایل HTML محلی است، سطح دسترسی‌ها فقط کنترل رابط کاربری است و در برابر کسی که به مرورگر یا فایل‌های دستگاه دسترسی کامل دارد امنیت سازمانی ایجاد نمی‌کند.</div>
 ${tbl([{h:'نام',f:u=>`<b>${esc(u.name)}</b>`},{h:'نام کاربری',f:u=>esc(u.username)},{h:'نقش',f:u=>ROLES[u.role]?.n},{h:'دسترسی‌ها',f:u=>u.role==='admin'?'همه':u.perms.map(p=>PERMS[p]).filter(Boolean).slice(0,6).join('، ')+(u.perms.length>6?'…':'')},{h:'وضعیت',f:u=>u.active?badge('فعال','ok'):badge('غیرفعال','mu')},{h:'عملیات',f:u=>`<div class="act"><button class="btn s" data-act="uform" data-id="${u.id}">${ic('edit')}</button>${u.id!==A.user.id?`<button class="btn s" data-act="utoggle" data-id="${u.id}">${u.active?'غیرفعال':'فعال'}</button>`:''}</div>`}],L('users'),{id:'us'})}
 <h3 style="margin:16px 0 8px">سوابق فعالیت (آخرین ۳۰۰ مورد)</h3>${tbl([{h:'زمان',f:a=>dtime(a.ts)},{h:'کاربر',f:a=>esc(a.userName||'')},{h:'عملیات',f:a=>esc(a.action)},{h:'جزئیات',f:a=>esc(a.details||'')}],L('audit').sort((a,b)=>b.ts-a.ts).slice(0,300),{id:'au',size:30,empty:'سابقه‌ای ثبت نشده است.'})}`};
ACT.uform=el=>{const u=el.dataset.id?G('users',el.dataset.id):null;const w=modal({title:u?'ویرایش کاربر':'کاربر جدید',size:'lg',body:`<form data-form="user" data-id="${u?.id||''}" class="form">${fld('نام و نام خانوادگی *',inp('name',u?.name,'required'))}${fld('نام کاربری *',inp('username',u?.username,'required'))}${fld(u?'رمز جدید (خالی = بدون تغییر)':'رمز عبور *',`<input type="password" name="pw" autocomplete="new-password" ${u?'':'required'}>`)}${fld('نقش',sel('role',Object.entries(ROLES).map(([k,v])=>[k,v.n]),u?.role||'seller','data-ch="urole"'))}
 <div class="full"><b>سطح دسترسی</b><div class="fl" id="uperms" style="margin-top:6px">${Object.entries(PERMS).map(([k,v])=>`<label class="chip" style="display:flex;gap:6px;align-items:center"><input type="checkbox" name="perm_${k}" style="width:auto" ${(u?u.perms:ROLES.seller.p).includes(k)||u?.role==='admin'?'checked':''}> ${v}</label>`).join('')}</div></div>
 ${u?`<label class="f" style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" name="active" style="width:auto" ${u.active?'checked':''}> فعال</label>`:''}<button class="btn p full">ذخیره</button></form>`})};
INP.urole=el=>{const p=ROLES[el.value].p;$$('#uperms input').forEach(c=>c.checked=p.includes(c.name.slice(5)))};
FORM.user=async f=>{const o=formData(f);const id=f.dataset.id||null;const ops=[];if(!o.name||!o.username)throw E('نام و نام کاربری الزامی است.');if(!id&&o.pw.length<4)throw E('رمز عبور حداقل ۴ کاراکتر باشد.');if(o.pw&&o.pw.length<4)throw E('رمز عبور حداقل ۴ کاراکتر باشد.');
 if(L('users').some(u=>u.id!==id&&u.username===o.username.toLowerCase()))throw E('این نام کاربری قبلاً ثبت شده است.');
 const perms=Object.keys(PERMS).filter(k=>f.querySelector(`[name=perm_${k}]`)?.checked);const salt=uid();
 const u=id?clone(G('users',id)):{id:uid(),ts:Date.now(),active:true};
 if(id&&u.role==='admin'&&(o.role!=='admin'||o.active===false)&&L('users').filter(x=>x.role==='admin'&&x.active&&x.id!==id).length===0)throw E('حداقل یک مدیر فعال باید وجود داشته باشد.');
 Object.assign(u,{name:o.name,username:o.username.toLowerCase(),role:o.role,perms:o.role==='admin'?ROLES.admin.p:perms});if(id)u.active=o.active;
 if(o.pw){u.salt=salt;u.hash=hashPw(o.pw,salt)}ops.push({s:'users',put:u});audit(ops,id?'ویرایش کاربر':'افزودن کاربر','user',u.id,u.name);await DB.commit(ops);
 if(id===A.user.id)A.user=G('users',id);toast('کاربر ذخیره شد.');closeModal(f.closest('.mw'));CUR.refresh()};
ACT.utoggle=async el=>{const u=clone(G('users',el.dataset.id));if(u.active&&u.role==='admin'&&L('users').filter(x=>x.role==='admin'&&x.active&&x.id!==u.id).length===0)throw E('حداقل یک مدیر فعال باید وجود داشته باشد.');u.active=!u.active;const ops=[{s:'users',put:u}];audit(ops,u.active?'فعال‌سازی کاربر':'غیرفعال‌سازی کاربر','user',u.id,u.name);await DB.commit(ops);CUR.refresh()};

/* ============ تنظیمات ============ */
PAGES.settings=(el)=>{const s=SET();el.innerHTML=`<div class="hd"><h2>تنظیمات سیستم</h2></div><div class="grid g2">
 <div class="card"><h3>مشخصات فروشگاه و چاپ</h3><form data-form="setgen" class="form">${fld('نام فروشگاه',inp('shop',s.shop),'full')}${fld('تلفن',inp('phone',s.phone))}${fld('عرض کاغذ حرارتی (میلی‌متر)',sel('th',[['58','۵۸'],['80','۸۰']],String(s.thermal)))}${fld('آدرس',inp('address',s.address),'full')}${fld('لوگوی فروشگاه (اختیاری)',`<div class="logoPick">${s.logo?`<img src="${s.logo}" class="logoPrev" alt="لوگو">`:''}<input type="file" name="logo" accept="image/*"><small class="mu">لوگو در منو، صفحه ورود و سربرگ چاپ نمایش داده می‌شود. برای حذف، لوگو را خالی ذخیره کنید.</small><label style="display:flex;gap:6px;align-items:center;margin-top:6px;font-size:12px"><input type="checkbox" name="dellogo" style="width:auto"> حذف لوگوی فعلی</label></div>`,'full')}
 <label class="f full" style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" name="neg" style="width:auto" ${s.allowNegative?'checked':''}> اجازه فروش با موجودی منفی (فقط برای کاربران دارای مجوز)</label><button class="btn p full">ذخیره تنظیمات</button></form></div>
 <div class="card"><h3>تغییر رمز عبور من</h3><form data-form="mypw" class="form">${fld('رمز فعلی','<input type="password" name="old" required>','full')}${fld('رمز جدید','<input type="password" name="n1" required>','full')}${fld('تکرار رمز جدید','<input type="password" name="n2" required>','full')}<button class="btn p full">تغییر رمز</button></form></div>
 <div class="card"><h3>یادآوری چک‌ها</h3><p class="mu">زمان‌بندی یادآوری‌ها در صفحه «یادآوری‌ها و اعلان‌ها» تنظیم می‌شود.</p><button class="btn" data-act="goto" data-to="notifs">باز کردن تنظیمات یادآوری</button></div>
 ${A.user.role==='admin'?`<div class="card" style="border-color:var(--err)"><h3 style="color:#f87171">منطقه خطر</h3><p class="mu">پاک‌کردن تمام داده‌های مالی (مشتریان، کالاها، فاکتورها و …). حساب کاربران و تنظیمات باقی می‌ماند. ابتدا پشتیبان بگیرید.</p><button class="btn d" data-act="wipe">پاک‌سازی کامل داده‌ها</button></div>`:''}</div>`};
FORM.setgen=async f=>{const ops=[];let _logo=SET().logo||'';if(f.dellogo?.checked) _logo='';if(f.logo?.files?.[0]) _logo=await readImage(f.logo.files[0],400);setOp(ops,{shop:f.shop.value.trim()||DEF_SET.shop,phone:f.phone.value,address:f.address.value,thermal:Number(f.th.value),allowNegative:f.neg.checked,logo:_logo});audit(ops,'تغییر تنظیمات','settings','main');await DB.commit(ops);toast('تنظیمات ذخیره شد.');$('#side').innerHTML=sideHtml();CUR.refresh()};
FORM.mypw=async f=>{const u=A.user;if(hashPw(f.old.value,u.salt)!==u.hash)throw E('رمز فعلی اشتباه است.');if(f.n1.value.length<4)throw E('رمز جدید حداقل ۴ کاراکتر باشد.');if(f.n1.value!==f.n2.value)throw E('تکرار رمز جدید یکسان نیست.');
 const c=clone(u);c.salt=uid();c.hash=hashPw(f.n1.value,c.salt);const ops=[{s:'users',put:c}];audit(ops,'تغییر رمز عبور','user',u.id);await DB.commit(ops);A.user=c;f.reset();toast('رمز عبور تغییر کرد.')};
ACT.wipe=async()=>{const r=await confirmBox('تمام اطلاعات مشتریان، کالاها، فاکتورها، پرداخت‌ها، قرض‌ها، چک‌ها و انبار برای همیشه پاک می‌شود.<br>برای تأیید عبارت «پاک شود» را تایپ کنید.',{danger:true,ok:'پاک‌سازی',input:'عبارت تأیید'});if(!r||r.value!=='پاک شود')throw E('عبارت تأیید درست نیست؛ چیزی پاک نشد.');
 const keep={users:L('users').map(clone),settings:L('settings').filter(s=>s.id==='main').map(clone),categories:L('categories').map(clone),checkReminders:L('checkReminders').map(clone),audit:[{id:uid(),ts:Date.now(),userId:A.user.id,userName:A.user.name,action:'پاک‌سازی کامل داده‌ها',entity:'system',details:''}]};await DB.replaceAll(keep);toast('داده‌ها پاک شد.');CUR.refresh()};

/* ============ پشتیبان‌گیری ============ */
const APPID='HAFEZ_MEAT_ACCOUNTING';
PAGES.backup=(el)=>{const s=SET();const cnt=STORES.map(k=>[k,L(k).length]).filter(x=>x[1]);
 el.innerHTML=`<div class="hd"><h2>پشتیبان‌گیری و بازیابی</h2></div>
 <div class="stats">${statCard('آخرین پشتیبان',s.lastBackup?dtime(s.lastBackup):'هرگز',s.lastBackup&&D.fromJS(s.lastBackup).j===D.todayJ()?'ok':'warn')}${statCard('تعداد رکوردها',num(sum(cnt,x=>x[1])))}</div>
 <div class="grid g2"><div class="card"><h3>${ic('download')} ایجاد نسخه پشتیبان کامل</h3><p class="mu">تمام اطلاعات در یک فایل JSON ذخیره می‌شود. فایل را روی حافظه گوشی/فلش یا فضای ابری نگه‌دارید.</p><button class="btn p" data-act="bkmake">دانلود پشتیبان JSON</button></div>
 <div class="card"><h3>${ic('upload')} بازیابی اطلاعات</h3><p class="mu">فایل پشتیبان پس از اعتبارسنجی، <b>جایگزین</b> اطلاعات فعلی می‌شود (رکورد تکراری ایجاد نمی‌شود).</p><input type="file" id="bkfile" accept=".json,application/json"></div>
 <div class="card"><h3>خروجی CSV</h3><div class="fl"><button class="btn" data-act="bkcsv" data-t="cust">مشتریان</button><button class="btn" data-act="bkcsv" data-t="prod">کالاها</button><button class="btn" data-act="bkcsv" data-t="sales">فاکتورها</button><button class="btn" data-act="bkcsv" data-t="tx">تراکنش‌ها (دفتر حساب)</button></div></div>
 <div class="card"><h3>محدودیت‌ها</h3><p class="mu" style="margin:0">اطلاعات در حافظه IndexedDB مرورگر همین دستگاه ذخیره می‌شود. پاک‌کردن داده‌های سایت/مرورگر یا حذف برنامه می‌تواند آن‌ها را از بین ببرد؛ بنابراین به‌طور منظم پشتیبان بگیرید.</p></div></div>`;
 $('#bkfile').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{const data=validateBackup(JSON.parse(await file.text()));
  const info=Object.entries(data.data).filter(x=>x[1].length).map(x=>`${x[0]}: ${num(x[1].length)}`).join('، ');
  const ok=await confirmBox(`فایل معتبر است (تاریخ پشتیبان: ${dtime(new Date(data.exportedAt).getTime())}).<br><small>${info}</small><br><b>تمام اطلاعات فعلی جایگزین می‌شود.</b> ادامه می‌دهید؟`,{danger:true,ok:'بازیابی'});if(!ok){e.target.value='';return}
  if(await confirmBox('قبل از جایگزینی، یک نسخه پشتیبان از وضعیت فعلی دانلود شود؟',{ok:'بله، دانلود شود'}))ACT.bkmake();
  await DB.replaceAll(data.data);toast('اطلاعات با موفقیت بازیابی شد. برنامه دوباره بارگذاری می‌شود.');setTimeout(()=>{sessionStorage.removeItem('hafez_uid');location.reload()},1500)}catch(err){toast(err.message||'فایل نامعتبر است','err',6000);e.target.value=''}}};
function validateBackup(j){if(!j||j.app!==APPID)throw E('این فایل، پشتیبان این نرم‌افزار نیست.');if(!j.data||typeof j.data!=='object')throw E('ساختار فایل پشتیبان نامعتبر است.');
 const out={};for(const s of STORES){const a=j.data[s]||[];if(!Array.isArray(a))throw E(`بخش «${s}» نامعتبر است.`);const ids=new Set();for(const r of a){if(!r||typeof r.id!=='string')throw E(`رکورد نامعتبر در «${s}».`);if(ids.has(r.id))throw E(`شناسه تکراری در «${s}».`);ids.add(r.id)}out[s]=a}
 if(!out.users.some(u=>u.role==='admin'&&u.active&&u.hash))throw E('فایل پشتیبان هیچ مدیر فعالی ندارد.');
 for(const s of out.sales)if(!Array.isArray(s.items)||!Number.isInteger(s.total))throw E('اطلاعات فاکتورها در فایل نامعتبر است.');
 for(const p of out.payments)if(!Number.isInteger(p.amount))throw E('اطلاعات پرداخت‌ها در فایل نامعتبر است.');return{...j,data:out}}
ACT.bkmake=async()=>{const data={};STORES.forEach(s=>data[s]=L(s));const ops=[];setOp(ops,{lastBackup:Date.now()});audit(ops,'پشتیبان‌گیری','system','');await DB.commit(ops);
 const dump={app:APPID,version:1,exportedAt:new Date().toISOString(),counts:Object.fromEntries(STORES.map(s=>[s,data[s].length])),data};
 const d=D.today();download(`hafez-backup-${d.y}-${D.p2(d.m)}-${D.p2(d.d)}.json`,JSON.stringify(dump),'application/json');toast('نسخه پشتیبان ساخته شد.');if(CUR.key==='backup')CUR.refresh()};
ACT.bkcsv=el=>{const t=el.dataset.t;
 if(t==='cust')ACT.custcsvAll();else if(t==='prod')csvDownload('products.csv',['کد','نام','دسته','واحد','موجودی','بهای میانگین','قیمت فروش','وضعیت'],L('products').map(p=>[p.code,p.name,catName(p.categoryId),p.unit,stockOf(p.id)/1000,p.avgCost,p.sellPrice,p.active?'فعال':'غیرفعال']));
 else if(t==='sales')csvDownload('invoices.csv',['شماره','تاریخ','مشتری','جمع اقلام','تخفیف','هزینه اضافی','مبلغ نهایی','پرداختی','مانده','بهای تمام‌شده','سود','وضعیت'],L('sales').map(s=>{const i=saleInfo(s);return[s.no,D.en(s.date),nameOfC(s.customerId),s.subtotal,s.discount,s.extra,s.total,i.paid,i.remain,s.cogs,s.total-s.cogs,s.status==='void'?'ابطال':'فعال']}));
 else csvDownload('transactions.csv',['تاریخ','مشتری','حساب','شرح','بدهکار','بستانکار','روش','شماره سند','نوع'],L('ledger').sort((a,b)=>a.date.j-b.date.j||a.ts-b.ts).map(e=>[D.en(e.date),nameOfC(e.customerId),e.acct==='R'?'طلب فروشگاه':'بدهی فروشگاه',e.desc,e.debit,e.credit,e.method,e.docNo,e.kind]))};
ACT.custcsvAll=()=>csvDownload('customers.csv',['شناسه','نام','موبایل','آدرس','سقف اعتبار','بدهی به فروشگاه','طلب مشتری از فروشگاه','وضعیت'],L('customers').map(c=>{const b=custBal(c.id);return[c.code,c.name,c.phone,c.address,c.creditLimit,b.R,b.P,c.active?'فعال':'غیرفعال']}));

/* ============ پوسته برنامه و مسیریابی ============ */
const NAV=[['dashboard','داشبورد مدیریتی','home'],['daily','فروش روزانه','zap'],['sale','ثبت فروش','cart'],['invoices','فاکتورها','file'],['products','مدیریت کالاها','box'],['inventory','مدیریت انبار','layers'],['customers','مشتریان','users'],['ledger','دفتر حساب مشتریان','book'],['loans','مدیریت قرض و بدهی','dollar'],['payments','مدیریت پرداخت‌ها','card'],['checks','مدیریت چک‌ها','check'],['notifs','یادآوری‌ها و اعلان‌ها','bell'],['suppliers','تأمین‌کنندگان','truck'],['reports','گزارش‌های مالی','chart'],['users','مدیریت کاربران','shield'],['settings','تنظیمات سیستم','sliders'],['backup','پشتیبان‌گیری و بازیابی','db']];
const go=(to)=>{if(location.hash==='#/'+to)render();else location.hash='#/'+to};
function parseHash(){const h=(location.hash||'#/dashboard').slice(2);const[k,qs]=h.split('?');return{key:k||'dashboard',q:Object.fromEntries(new URLSearchParams(qs||''))}}
function render(){if(!A.user)return;while(MODALS.length)closeModal();const{key,q}=parseHash();const k=PAGES[key]?key:'dashboard';
 if(!can(k)){const f=NAV.find(n=>can(n[0]));if(f&&f[0]!==k)return go(f[0])}
 CUR.key=k;CUR.q=q;const el=$('#view');const nm=NAV.find(n=>n[0]===k);$('#ptitle').textContent=nm?nm[1]:'';
 $$('.nav a').forEach(a=>a.classList.toggle('on',a.dataset.k===k));$$('.bnav a').forEach(a=>a.classList.toggle('on',a.dataset.k===k));
 Object.values(CH).forEach(c=>c.destroy());for(const k2 in CH)delete CH[k2];
 try{PAGES[k](el,q)}catch(e){console.error(e);el.innerHTML=`<div class="card"><div class="ferr">خطا در نمایش صفحه: ${esc(e.message)}</div></div>`}
 $('#side').classList.remove('open');$('.scrim').classList.remove('on');updateBadges()}
window.addEventListener('hashchange',render);
function updateBadges(){const n=notifActive().filter(x=>!x.read).length;const b=$('#bellbd');if(b){b.textContent=num(n);b.style.display=n?'':'none'}
 const nb=$('.nav a[data-k=notifs] .bd');if(nb){nb.textContent=num(n);nb.style.display=n?'':'none'}}
const sideHtml=()=>{const _st=SET();const _lg=_st.logo?`<div class="logo hasimg"><img src="${_st.logo}" alt="لوگو"></div>`:`<div class="logo">ح</div>`;return `<div class="brand">${_lg}<div><b>${esc(_st.shop)}</b><small>نرم‌افزار حسابداری فروشگاهی</small></div></div><nav class="nav">${NAV.filter(n=>can(n[0])).map(n=>`<a href="#/${n[0]}" data-k="${n[0]}">${ic(n[2])}<span>${n[1]}</span>${n[0]==='notifs'?'<span class="bd"></span>':''}</a>`).join('')}</nav><div style="padding:10px;border-top:1px solid var(--line)"><div class="mu" style="font-size:12px;margin-bottom:6px">${esc(A.user.name)} · ${ROLES[A.user.role]?.n||''}</div><button class="btn" style="width:100%;justify-content:center" data-act="logout">${ic('logout')} خروج</button></div>`};
function shell(){document.body.innerHTML=`<div class="app"><aside class="side" id="side">${sideHtml()}</aside><div class="scrim" data-act="menu"></div><div class="main"><header class="top"><button class="ib" data-act="menu" aria-label="منو" style="display:none" id="mbtn">${ic('menu')}</button><h1 id="ptitle"></h1><div class="sbox">${ic('search')}<input id="gs" type="search" placeholder="جستجوی سراسری: مشتری، کالا، فاکتور، چک…" autocomplete="off" data-in="gs"><div class="sres" id="gsr" style="display:none"></div></div><button class="ib" data-act="gonotif" aria-label="اعلان‌ها">${ic('bell')}<span class="bd" id="bellbd"></span></button></header><main class="page" id="view"></main></div></div>
 <nav class="bnav">${[['dashboard','داشبورد','home'],['daily','روزانه','zap'],['sale','فروش','cart'],['invoices','فاکتورها','file'],['customers','مشتریان','users']].filter(n=>can(n[0])).map(n=>`<a href="#/${n[0]}" data-k="${n[0]}">${ic(n[2])}<span>${n[1]}</span></a>`).join('')}<a data-act="menu">${ic('more')}<span>بیشتر</span></a></nav>`;
 const mq=matchMedia('(max-width:900px)');const f=()=>{$('#mbtn').style.display=mq.matches?'':'none'};f();mq.addEventListener?.('change',f)}
ACT.menu=()=>{$('#side').classList.toggle('open');$('.scrim').classList.toggle('on')};
ACT.gonotif=()=>go('notifs');
ACT.logout=async()=>{if(!(await confirmBox('از حساب کاربری خارج می‌شوید؟')))return;sessionStorage.removeItem('hafez_uid');location.hash='';location.reload()};
/* جستجوی سراسری */
INP.gs=el=>{const q=el.value.trim().toLowerCase(),box=$('#gsr');if(q.length<1){box.style.display='none';return}
 const qe=toEn(q);const r=[];const has=(...a)=>a.some(x=>String(x||'').toLowerCase().includes(q)||String(x||'').toLowerCase().includes(qe));
 L('customers').filter(c=>has(c.name,c.phone,c.code)).slice(0,5).forEach(c=>r.push(['مشتری',c.name,c.phone,'ledger?c='+c.id]));
 L('products').filter(p=>has(p.name,p.code,p.barcode)).slice(0,5).forEach(p=>r.push(['کالا',p.name,p.code,'products?q='+encodeURIComponent(p.name)]));
 L('sales').filter(s=>has(s.no,saleCustName(s)+(s.customerName||''))).slice(0,5).forEach(s=>r.push(['فاکتور',s.no+' - '+nameOfC(s.customerId),money(s.total),'invoices?id='+s.id]));
 L('checks').filter(c=>has(c.number,c.bank,c.no)).slice(0,4).forEach(c=>r.push(['چک',c.number+' - '+c.bank,money(c.amount),'checks?q='+encodeURIComponent(c.number)]));
 L('loans').filter(l=>has(l.no,l.title)).slice(0,3).forEach(l=>r.push(['قرض',l.no+' - '+l.title,money(l.amount),'loans?q='+encodeURIComponent(l.no)]));
 box.innerHTML=r.length?r.map(x=>`<a data-act="gsgo" data-to="${esc(x[3])}"><span class="bg gd">${x[0]}</span><span>${esc(x[1])}</span><small>${esc(x[2])}</small></a>`).join(''):'<div class="empty" style="padding:14px">نتیجه‌ای یافت نشد</div>';box.style.display='block'};
ACT.gsgo=el=>{$('#gsr').style.display='none';$('#gs').value='';go(el.dataset.to)};
document.addEventListener('click',e=>{if(!e.target.closest('.sbox')){const b=$('#gsr');if(b)b.style.display='none'}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&MODALS.length)closeModal();if(e.altKey&&e.key==='n'){e.preventDefault();go('sale')}if(e.key==='/'&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)&&$('#gs')){e.preventDefault();$('#gs').focus()}});

/* ============ ورود و راه‌اندازی اولیه ============ */
function loginScreen(){const first=!L('users').length;
 document.body.innerHTML=`<div class="login"><div class="card"><div class="brand" style="border:0;padding:0 0 14px"><div class="logo">ح</div><div><b>سوپر گوشت حافظ</b><small>${first?'راه‌اندازی اولیه سیستم':'ورود به سیستم حسابداری'}</small></div></div>
 <form data-form="login" class="form">${first?`<p class="mu full" style="margin:0">برای شروع، حساب مدیر سیستم را بسازید. این اطلاعات فقط روی همین دستگاه ذخیره می‌شود.</p>${fld('نام و نام خانوادگی مدیر',inp('name','','required'),'full')}${fld('نام فروشگاه',inp('shop','سوپر گوشت حافظ'),'full')}`:''}
 ${fld('نام کاربری',inp('username','','required autocomplete="username"'),'full')}${fld('رمز عبور',`<input name="pw" type="password" required autocomplete="${first?'new-password':'current-password'}">`,'full')}
 ${first?fld('تکرار رمز عبور','<input name="pw2" type="password" required autocomplete="new-password">','full'):''}
 <button class="btn p full" type="submit" style="justify-content:center">${first?'ساخت حساب مدیر و شروع':'ورود'}</button></form>
 <p class="mu" style="font-size:12px;margin-bottom:0">نکته امنیتی: رمزها روی همین دستگاه به‌صورت هش ذخیره می‌شوند؛ اما چون برنامه یک فایل محلی است، هر کس به فایل و مرورگر شما دسترسی فیزیکی داشته باشد می‌تواند داده‌ها را بخواند. برای امنیت واقعی، دستگاه را قفل کنید و پشتیبان بگیرید.</p></div></div>`}
FORM.login=async f=>{const o=formData(f);const first=!L('users').length;
 if(first){if(!o.name)throw E('نام مدیر را وارد کنید.');if(o.pw.length<4)throw E('رمز عبور باید حداقل ۴ کاراکتر باشد.');if(o.pw!==o.pw2)throw E('تکرار رمز با رمز عبور یکسان نیست.');
  const ops=[];const salt=uid();const u={id:uid(),name:o.name,username:o.username.toLowerCase(),salt,hash:hashPw(o.pw,salt),role:'admin',perms:ROLES.admin.p,active:true,ts:Date.now()};ops.push({s:'users',put:u});
  ['گوشت گوسفندی','گوشت گوساله','گوشت چرخ‌کرده','مرغ','دنبه','جگر','قلوه','سایر محصولات'].forEach(n=>ops.push({s:'categories',put:{id:uid(),name:n,ts:Date.now()}}));
  [72,48,24,0].forEach(h=>['in','out'].forEach(k=>ops.push({s:'checkReminders',put:{id:uid(),kind:k,offsetHours:h,enabled:true}})));
  ops.push({s:'settings',put:{id:'main',v:{...DEF_SET,shop:o.shop||DEF_SET.shop}}});ops.push({s:'audit',put:{id:uid(),ts:Date.now(),userName:o.name,action:'راه‌اندازی سیستم',entity:'system',details:''}});
  await DB.commit(ops);sessionStorage.setItem('hafez_uid',u.id);return start()}
 const u=L('users').find(x=>x.username===o.username.toLowerCase());
 if(!u||hashPw(o.pw,u.salt)!==u.hash)throw E('نام کاربری یا رمز عبور اشتباه است.');if(!u.active)throw E('این حساب غیرفعال شده است.');
 sessionStorage.setItem('hafez_uid',u.id);const ops=[];A.user=u;audit(ops,'ورود به سیستم','user',u.id);await DB.commit(ops);start()};
async function start(){const u=G('users',sessionStorage.getItem('hafez_uid'));if(!u||!u.active)return loginScreen();A.user=u;
 if(window.Chart)chartBase();shell();document.title='حسابداری '+SET().shop;
 const fresh=await runReminders();announce(fresh);render();
 setInterval(async()=>{const f=await runReminders();announce(f);updateBadges()},60000)}
function announce(list){(list||[]).forEach(n=>{toast('🔔 '+n.title,n.level==='err'?'err':'warn',7000);
  if(window.Notification&&Notification.permission==='granted'){try{new Notification(n.title,{body:SET().shop,tag:n.key})}catch(e){}}});
 if(list?.length){const ops=list.map(n=>({s:'notifications',put:{...G('notifications',n.id),shown:true}}));DB.commit(ops)}}
(async function boot(){try{await DB.open();await DB.loadAll();if(navigator.storage?.persist)navigator.storage.persist().catch(()=>{});
  if(!L('users').length||!sessionStorage.getItem('hafez_uid'))loginScreen();else start()}
 catch(e){document.body.innerHTML=`<div class="login"><div class="card"><div class="ferr">خطا در راه‌اندازی پایگاه داده: ${esc(e.message)}<br>مرورگر را به‌روز کنید یا حالت ناشناس را خاموش کنید.</div></div></div>`}})();


/* ============================================================
   PATCH: فروش روزانه، حذف مشتری، اصلاح تامین‌کننده، لوگو، اکسل
   ============================================================ */

// ---------- ابزار اکسل (SheetJS) ----------
function needXLSX(){ if(window.XLSX) return true; toast('کتابخانه اکسل بارگذاری نشده است؛ اتصال اینترنت را بررسی کنید. از CSV استفاده کنید.','err',5000); return false; }
function xlsDownload(name, sheets){
  if(!needXLSX()) return;
  const wb = XLSX.utils.book_new();
  for(const [sname, aoa] of Object.entries(sheets)){
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!dir']='rtl';
    XLSX.utils.book_append_sheet(wb, ws, sname.slice(0,31));
  }
  XLSX.writeFile(wb, name);
}
function xlsRead(file){ return new Promise((res,rej)=>{
  if(!needXLSX()) return rej(new Error('کتابخانه اکسل در دسترس نیست'));
  const r=new FileReader();
  r.onerror=()=>rej(new Error('خواندن فایل ناموفق بود'));
  r.onload=()=>{ try{ const wb=XLSX.read(r.result,{type:'array'}); res(wb);}catch(e){rej(e)} };
  r.readAsArrayBuffer(file);
});}
function sheetToRows(wb, idx=0){
  const sn = wb.SheetNames[idx];
  const ws = wb.Sheets[sn];
  return XLSX.utils.sheet_to_json(ws,{header:1,defval:''});
}
// خروجی اکسل مشتریان
ACT.custxlsx=()=>{
  if(!needXLSX()) return ACT.custcsv();
  const rows=custRows().map(c=>{const b=custBal(c.id);return [c.code,c.name,c.phone,c.address,c.creditLimit,Math.max(b.R,0),Math.max(-b.R,0),b.P,c.active?'فعال':'غیرفعال',D.en(c.regDate)];});
  xlsDownload('customers.xlsx',{'مشتریان':[['شناسه','نام','موبایل','آدرس','سقف اعتبار','بدهی به فروشگاه','اعتبار مشتری','طلب مشتری از فروشگاه (قرض)','وضعیت','تاریخ ثبت'],...rows]});
  toast('فایل اکسل مشتریان دانلود شد.');
};
ACT.prodxlsx=()=>{
  if(!needXLSX()) return ACT.prodcsv();
  const rows=prodRows().map(p=>[p.code,p.barcode,p.name,catName(p.categoryId),p.unit,stockOf(p.id)/1000,p.minStock/1000,p.avgCost,p.buyPrice,p.sellPrice,p.wholesale,p.retail,Math.round(Math.max(0,stockOf(p.id))*p.avgCost/1000),p.active?'فعال':'غیرفعال']);
  xlsDownload('products.xlsx',{'کالاها':[['کد','بارکد','نام','دسته','واحد','موجودی','حداقل','بهای میانگین','آخرین خرید','فروش','عمده','خرده','ارزش موجودی','وضعیت'],...rows]});
  toast('فایل اکسل کالاها دانلود شد.');
};
ACT.invxlsx=()=>{
  if(!needXLSX()) return ACT.ivcsv();
  const rows=ivRows().map(s=>{const i=saleInfo(s);return [s.no,D.en(s.date),saleCustName(s),s.subtotal,s.discount,s.extra,s.total,i.paid,i.remain,s.cogs,s.total-s.cogs,s.status==='void'?'ابطال':'فعال',s.userName||''];});
  xlsDownload('invoices.xlsx',{'فاکتورها':[['شماره','تاریخ','مشتری','جمع','تخفیف','هزینه اضافی','مبلغ نهایی','پرداختی','مانده','بهای تمام‌شده','سود','وضعیت','فروشنده'],...rows]});
  toast('فایل اکسل فاکتورها دانلود شد.');
};
ACT.supxlsx=()=>{
  if(!needXLSX()) return;
  const rows=L('suppliers').map(s=>[s.name,s.phone||'',s.address||'',sum(L('purchases').filter(p=>p.supplierId===s.id&&p.status==='active'),p=>p.total),supBal(s.id),s.active!==false?'فعال':'غیرفعال']);
  xlsDownload('suppliers.xlsx',{'تامین‌کنندگان':[['نام','تلفن','آدرس','جمع خریدها','مانده بدهی ما','وضعیت'],...rows]});
  toast('فایل اکسل تامین‌کنندگان دانلود شد.');
};
// پشتیبان اکسل چندشیتی + بازیابی
ACT.bkexcel=()=>{
  if(!needXLSX()) return;
  const d=D.today();
  const sheets={
    'مشتریان':[['id','code','name','phone','address','note','creditLimit','active','regDate_ts',...[]],...L('customers').map(c=>[c.id,c.code,c.name,c.phone,c.address,c.note||'',c.creditLimit,c.active?1:0,JSON.stringify(c.regDate)])],
    'کالاها':[['id','code','barcode','name','categoryId','unit','buyPrice','sellPrice','wholesale','retail','minStock_gr','avgCost','active','supplierId','regDate','desc','image?',...[]],...L('products').map(p=>[p.id,p.code,p.barcode,p.name,p.categoryId,p.unit,p.buyPrice,p.sellPrice,p.wholesale,p.retail,p.minStock,p.avgCost,p.active?1:0,p.supplierId||'',JSON.stringify(p.regDate||null),(p.desc||'').slice(0,200),p.image?'دارد':''])],
    'فاکتورها':[['no','date','customer','customerName','total','paid','remain','status'],...L('sales').map(s=>{const i=saleInfo(s);return [s.no,D.en(s.date),saleCustName(s),s.customerName||'',s.total,i.paid,i.remain,s.status];})],
    'تامین‌کنندگان':[['id','name','phone','address','active','balance'],...L('suppliers').map(s=>[s.id,s.name,s.phone||'',s.address||'',s.active!==false?1:0,supBal(s.id)])],
    'پرداخت‌ها':[['no','date','dir','طرف','method','amount','ref','voided'],...L('payments').map(p=>[p.no,D.en(p.date),p.dir,p.customerId?nameOfC(p.customerId):(G('suppliers',p.supplierId)?.name||''),mlabel(p.method),p.amount,p.refType+':'+(p.refId||''),p.voided?1:0])],
  };
  xlsDownload(`hafez-backup-${d.y}-${D.p2(d.m)}-${D.p2(d.d)}.xlsx`, sheets);
  toast('پشتیبان اکسل دانلود شد. (این خروجی برای گزارش است؛ بازیابی کامل با JSON انجام می‌شود)');
};
ACT.bkexcelImp=async (el)=>{
  const f=$('#bkexcelFile')?.files?.[0];
  if(!f){ toast('ابتدا فایل اکسل را انتخاب کنید.','warn'); return; }
  try{
    const wb=await xlsRead(f);
    const info=wb.SheetNames.map(n=>{
      const r=sheetToRows(wb, wb.SheetNames.indexOf(n));
      return `${n}: ${Math.max(0,r.length-1)} ردیف`;
    }).join('، ');
    const ok=await confirmBox(`فایل اکسل خوانده شد:<br><small>${info}</small><br><b>وارد کردن مشتریان و کالاها از اکسل؟</b><br><small class="mu">فقط شیت‌های «مشتریان» و «کالاها» با ستون‌های استاندارد وارد می‌شوند. رکورد تکراری (هم‌نام) نادیده گرفته می‌شود.</small>`,{ok:'وارد کردن'});
    if(!ok) return;
    let addedC=0, addedP=0;
    // مشتریان: انتظار ستون‌ها: نام (col1) ، موبایل(col2) ... ساده: اگر هدر شامل شناسه/نام بود، ستون نام را پیدا کن
    for(const sn of wb.SheetNames){
      const rows=sheetToRows(wb, wb.SheetNames.indexOf(sn));
      if(!rows.length) continue;
      const head=rows[0].map(h=>String(h).trim());
      if(sn.includes('مشتری')||head.includes('نام')){
        // پیدا کردن ایندکس نام/موبایل/آدرس
        const iName=head.findIndex(h=>h.includes('نام'));
        const iPhone=head.findIndex(h=>h.includes('موبایل')||h.includes('تلفن')||h.includes('phone'));
        const iAddr=head.findIndex(h=>h.includes('آدرس'));
        const iLim=head.findIndex(h=>h.includes('سقف')||h.includes('اعتبار'));
        for(const r of rows.slice(1)){
          const nm=String(r[iName>=0?iName:1]||'').trim();
          if(!nm) continue;
          if(L('customers').some(c=>c.name===nm)) continue;
          const ops=[];const c={id:uid(),code:nextNo(ops,'cust'),name:nm,phone:iPhone>=0?String(r[iPhone]||'').trim():'',address:iAddr>=0?String(r[iAddr]||'').trim():'',note:'وارد شده از اکسل',creditLimit:iLim>=0?(Number(String(r[iLim]).replace(/[^\d]/g,''))||0):0,active:true,regDate:D.today(),ts:Date.now()};
          ops.push({s:'customers',put:c});audit(ops,'افزودن مشتری از اکسل','customer',c.id,c.name);await DB.commit(ops);addedC++;
        }
      }
      if(sn.includes('کالا')||head.includes('قیمت فروش')){
        const iName=head.findIndex(h=>h.includes('نام'));
        const iSell=head.findIndex(h=>h.includes('فروش'));
        const iBuy=head.findIndex(h=>h.includes('خرید'));
        const iUnit=head.findIndex(h=>h.includes('واحد'));
        const iCat=head.findIndex(h=>h.includes('دسته'));
        for(const r of rows.slice(1)){
          const nm=String(r[iName>=0?iName:2]||'').trim();
          if(!nm||L('products').some(p=>p.name===nm)) continue;
          const sell=iSell>=0?(Number(String(r[iSell]).replace(/[^\d]/g,''))||0):0;
          const buy=iBuy>=0?(Number(String(r[iBuy]).replace(/[^\d]/g,''))||0):0;
          let catId=L('categories')[0]?.id;
          if(iCat>=0&&r[iCat]){ const cn=String(r[iCat]).trim(); let cx=L('categories').find(x=>x.name===cn); if(!cx&&cn){const ops0=[];cx={id:uid(),name:cn,ts:Date.now()};ops0.push({s:'categories',put:cx});await DB.commit(ops0);} if(cx) catId=cx.id; }
          if(!catId){ const ops0=[];catId=uid();ops0.push({s:'categories',put:{id:catId,name:'متفرقه',ts:Date.now()}});await DB.commit(ops0);}
          const ops=[];const p={id:uid(),code:nextNo(ops,'prod'),barcode:'',name:nm,categoryId:catId,desc:'وارد شده از اکسل',unit:iUnit>=0&&r[iUnit]?String(r[iUnit]).trim():'کیلوگرم',minStock:0,buyPrice:buy,sellPrice:sell,wholesale:sell,retail:sell,supplierId:'',active:true,image:'',regDate:D.today(),avgCost:buy,priceHistory:[{ts:Date.now(),date:D.today(),field:'create',old:0,new:sell,userId:A.user?.id,userName:A.user?.name}],ts:Date.now()};
          ops.push({s:'products',put:p});audit(ops,'افزودن کالا از اکسل','product',p.id,p.name);await DB.commit(ops);addedP++;
        }
      }
    }
    toast(`وارد شد: ${addedC} مشتری، ${addedP} کالا.`);
    CUR.refresh();
  }catch(e){ console.error(e); toast(e.message||'فایل اکسل نامعتبر است','err',6000); }
};

// ---------- حذف مشتری با کنترل سوابق ----------
function custHasRecords(id){
  if(L('sales').some(s=>s.customerId===id)) return 'فاکتور';
  if(L('payments').some(p=>p.customerId===id&&!p.voided)) return 'پرداخت';
  if(L('loans').some(l=>l.customerId===id&&l.status!=='void')) return 'قرض';
  if(L('checks').some(k=>k.customerId===id&&k.status!=='void')) return 'چک';
  if(L('ledger').some(e=>e.customerId===id)) return 'سند حسابداری';
  return null;
}
ACT.cdel=async el=>{
  const id=el.dataset.id; const c=G('customers',id); if(!c) return;
  const rec=custHasRecords(id);
  if(rec){
    const ok=await confirmBox(`مشتری «${esc(c.name)}» دارای سوابق «${rec}» است و <b>قابل حذف نیست</b>.<br>برای حفظ سوابق مالی، مشتری را <b>غیرفعال</b> کنید.<br><small class="mu">فقط مشتریان بدون هیچ فاکتور/پرداخت/قرض/چک/سند قابل حذف کامل هستند.</small>`,{ok:'غیرفعال کن',title:'حذف ممکن نیست'});
    if(ok){ ACT.ctoggle(el); }
    return;
  }
  const ok2=await confirmBox(`مشتری «${esc(c.name)}» هیچ سابقه مالی ندارد.<br>برای همیشه <b>حذف</b> شود؟`,{danger:true,ok:'حذف کامل'});
  if(!ok2) return;
  const ops=[{s:'customers',del:id}];audit(ops,'حذف مشتری','customer',id,c.name);await DB.commit(ops);
  toast('مشتری حذف شد.');CUR.refresh();
};

// ---------- تامین‌کننده: جستجو، حذف، اکسل، تصویر ----------
const SUPF={q:'',st:'all'};
INP.supf=()=>{CUR.draw();};
ACT.supdel=async el=>{
  const id=el.dataset.id; const s=G('suppliers',id); if(!s) return;
  const hasPurch=L('purchases').some(p=>p.supplierId===id);
  const hasPay=L('payments').some(p=>p.supplierId===id&&!p.voided);
  if(hasPurch||hasPay){
    const ok=await confirmBox(`تامین‌کننده «${esc(s.name)}» دارای ${hasPurch?'خرید':''}${hasPurch&&hasPay?' و ':''}${hasPay?'پرداخت':''} است و قابل حذف نیست.<br>آن را <b>غیرفعال</b> کنید تا سوابق حفظ شود.`,{ok:'غیرفعال کن',title:'حذف ممکن نیست'});
    if(ok){ const c=JSON.parse(JSON.stringify(s)); c.active=false; const ops=[{s:'suppliers',put:c}];audit(ops,'غیرفعال‌سازی تامین‌کننده','supplier',id,s.name);await DB.commit(ops);CUR.refresh(); }
    return;
  }
  if(!(await confirmBox(`تامین‌کننده «${esc(s.name)}» حذف شود؟`,{danger:true,ok:'حذف'}))) return;
  const ops=[{s:'suppliers',del:id}];audit(ops,'حذف تامین‌کننده','supplier',id,s.name);await DB.commit(ops);toast('تامین‌کننده حذف شد.');CUR.refresh();
};
// بازنویسی کامل صفحه تامین‌کنندگان (اصلاح‌شده)
PAGES.suppliers=(el)=>{
  el.innerHTML=`<div class="hd"><h2>تأمین‌کنندگان کالا</h2><button class="btn p" data-act="supform">${ic('plus')} تأمین‌کننده جدید</button><button class="btn" data-act="supxlsx">${ic('excel')} اکسل</button></div>
  <div class="tb">${fld('جستجو',`<input id="supq" value="${esc(SUPF.q)}" placeholder="نام، تلفن" data-in="supf">`,'w2')}${fld('وضعیت',sel('supst',[['all','همه'],['active','فعال'],['inactive','غیرفعال'],['debt','دارای بدهی']],SUPF.st,'data-ch="supf"'),'sm')}</div>
  <div id="sp"></div>`;
  CUR.draw=()=>{
    SUPF.q=$('#supq')?.value??SUPF.q; SUPF.st=$('[name=supst]')?.value||SUPF.st;
    const q=SUPF.q.trim().toLowerCase();
    let rows=L('suppliers').slice();
    if(q) rows=rows.filter(s=>(s.name+(s.phone||'')).toLowerCase().includes(q));
    if(SUPF.st==='active') rows=rows.filter(s=>s.active!==false);
    if(SUPF.st==='inactive') rows=rows.filter(s=>s.active===false);
    if(SUPF.st==='debt') rows=rows.filter(s=>supBal(s.id)>0);
    rows.sort((a,b)=>a.name.localeCompare(b.name,'fa'));
    $('#sp').innerHTML=tbl([
      {h:'',f:s=>s.image?`<img class="thumb" src="${s.image}" alt="">`:`<span class="mu">—</span>`},
      {h:'نام',f:s=>`<b>${esc(s.name)}</b><br><small class="mu">${esc(s.phone||'')}</small>`},
      {h:'آدرس',f:s=>esc(s.address||'—')},
      {h:'جمع خریدها',cls:'n',f:s=>num(sum(L('purchases').filter(p=>p.supplierId===s.id&&p.status==='active'),p=>p.total))},
      {h:'مانده بدهی ما',cls:'n',f:s=>{const b=supBal(s.id);return `<span class="${b>0?'neg':''}">${num(b)}</span>`}},
      {h:'وضعیت',f:s=>s.active!==false?badge('فعال','ok'):badge('غیرفعال','mu')},
      {h:'عملیات',f:s=>`<div class="act"><button class="btn s" data-act="supform" data-id="${s.id}" title="ویرایش">${ic('edit')}</button><button class="btn s" data-act="suppay" data-id="${s.id}">پرداخت</button><button class="btn s" data-act="supview" data-id="${s.id}" title="سوابق">${ic('eye')}</button><button class="btn s ${s.active===false?'':'d'}" data-act="supdel" data-id="${s.id}" title="حذف">${ic('trash')}</button></div>`}
    ],rows,{id:'sp',empty:'تأمین‌کننده‌ای ثبت نشده است. روی «تأمین‌کننده جدید» بزنید.'});
  };
  CUR.draw();
};
ACT.supform=el=>{
  const id=el.dataset.id;const s=id?G('suppliers',id):null;
  modal({title:s?'ویرایش تأمین‌کننده':'تأمین‌کننده جدید',size:'sm',body:`<form data-form="sup" data-id="${id||''}" class="form">
  ${fld('نام *',inp('name',s?.name,'required'),'full')}
  ${fld('تلفن',inp('phone',s?.phone,'inputmode="tel" placeholder="09123456789"'),'full')}
  ${fld('آدرس',inp('address',s?.address),'full')}
  ${fld('تصویر / لوگو (اختیاری)','<input type="file" name="img" accept="image/*">')}
  ${s?.image?`<div class="full"><img src="${s.image}" class="logoPrev" alt=""></div>`:''}
  ${s?`<label class="f"><input type="checkbox" name="active" style="width:auto" ${s.active!==false?'checked':''}> فعال</label>`:''}
  <button class="btn p full">ذخیره</button></form>`});
};
FORM.sup=async f=>{
  const o=formData(f);
  let img=G('suppliers',f.dataset.id)?.image||'';
  if(o.img?.length) img=await readImage(o.img[0],300);
  await saveSimple('suppliers',{name:o.name,phone:toEn(o.phone||''),address:o.address,image:img,...(f.dataset.id?{active:o.active}:{})},f.dataset.id||null,'تأمین‌کننده');
  toast('ذخیره شد.');closeModal(f.closest('.mw'));CUR.refresh();
};
ACT.supview=el=>{
  const s=G('suppliers',el.dataset.id);if(!s) return;
  modal({title:'سوابق '+s.name,size:'lg',body:`
  ${s.image?`<img src="${s.image}" class="logoPrev" alt="">`:''}
  <div class="kv card" style="margin-bottom:10px"><span>تلفن</span><b>${esc(s.phone||'—')}</b><span>آدرس</span><b>${esc(s.address||'—')}</b><span>مانده بدهی ما</span><b class="${supBal(s.id)>0?'neg':''}">${num(supBal(s.id))}</b></div>
  <h3>خریدها از این تامین‌کننده</h3>${tbl([{h:'شماره',f:p=>p.no},{h:'تاریخ',f:p=>D.fmt(p.date)},{h:'اقلام',f:p=>p.items.map(i=>esc(nameOfP(i.productId))+' '+kgf(i.qty)).join('، ')},{h:'مبلغ',cls:'n',f:p=>num(p.total)}],L('purchases').filter(p=>p.supplierId===s.id).sort((a,b)=>b.date.j-a.date.j),{id:'sv1',empty:'خریدی نیست.'})}
  <h3 style="margin-top:10px">پرداخت‌ها</h3>${paysTable(L('payments').filter(p=>p.supplierId===s.id).sort((a,b)=>b.ts-a.ts),'sv2')}`});
};

// ---------- مشتری: افزودن تصویر ----------
(function(){
  const _open=openCustomerForm;
  window.__openCustomerForm=_open;
})();
function openCustomerForm(id,cb){
  const c=id?G('customers',id):null;
  const w=modal({title:c?'ویرایش مشتری':'مشتری جدید',body:`<form data-form="cust" data-id="${id||''}" class="form">
  ${fld('نام و نام خانوادگی *',inp('name',c?.name,'required'),'w2')}
  ${fld('شماره موبایل',inp('phone',c?.phone,'inputmode="tel" placeholder="09123456789"'))}
  ${fld('سقف اعتبار (تومان، صفر = نامحدود)',minp('limit',c?.creditLimit))}
  ${fld('آدرس',inp('address',c?.address),'full')}
  ${fld('توضیحات',`<textarea name="note">${esc(c?.note||'')}</textarea>`,'full')}
  ${fld('تصویر مشتری (اختیاری)','<input type="file" name="img" accept="image/*">')}
  ${c?.image?`<div class="full"><img src="${c.image}" class="logoPrev" alt=""></div>`:''}
  ${c?`<label class="f" style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" name="active" style="width:auto" ${c.active?'checked':''}> حساب فعال</label>`:''}
  <button class="btn p full" type="submit">${ic('check')} ذخیره</button></form>`});
  w._cb=cb;
}
FORM.cust=async f=>{
  const o=formData(f);const id=f.dataset.id||null;const w=f.closest('.mw');
  let img=G('customers',id)?.image||'';
  if(o.img?.length) img=await readImage(o.img[0],300);
  const c=await saveCustomer({name:o.name,phone:toEn(o.phone),address:o.address,note:o.note,creditLimit:pMoney(o.limit)||0,active:id?o.active:true},id);
  if(img){ const cc=G('customers',c.id); cc.image=img; const ops=[{s:'customers',put:cc}]; await DB.commit(ops); }
  toast('اطلاعات مشتری ذخیره شد.');closeModal(w);w._cb?.(c);CUR.refresh();
};
// نمایش تصویر در پروفایل مشتری (تکمیل)
(function(){
  const _prof=customerProfile;
  customerProfile=function(el,id,tab='ledger'){
    _prof(el,id,tab);
    try{
      const c=G('customers',id); if(!c?.image) return;
      const hd=el.querySelector('.hd h2');
      if(hd){ const im=document.createElement('img'); im.src=c.image; im.className='avatar'; im.style.width='40px'; im.style.height='40px'; hd.prepend(im); }
    }catch(e){}
  };
})();

// ---------- فروش روزانه (مشتری گذری) ----------
let DAILY={q:'',method:'cash'};
PAGES.daily=(el)=>{
  const t=D.todayJ();
  const todays=L('sales').filter(s=>s.status==='active'&&s.date.j===t);
  const walk=todays.filter(s=>!s.customerId);
  const cred=todays.filter(s=>s.customerId);
  const sumW=sum(walk,s=>s.total), sumC=sum(cred,s=>s.total);
  el.innerHTML=`<div class="hd"><h2>فروش روزانه (مشتری گذری)</h2><button class="btn" data-act="goto" data-to="sale">${ic('cart')} ثبت فروش کامل</button><button class="btn" data-act="invxlsx">${ic('excel')} اکسل امروز</button></div>
  <div class="dailyHero">مشتری‌های روزانه که خرید می‌کنند و می‌روند را <b>بدون تشکیل پرونده</b> ثبت کنید: فقط کالا + دریافت نقدی. برای نسیه حتما باید مشتری را از «ثبت فروش» انتخاب کنید.</div>
  <div class="stats">
    ${statCard('فروش امروز (گذری)',money(sumW),'ok',walk.length+' فاکتور')}
    ${statCard('فروش امروز (مشتری‌دار)',money(sumC),'',cred.length+' فاکتور')}
    ${statCard('جمع امروز',money(sumW+sumC),'',todays.length+' فاکتور')}
    ${statCard('میانگین فاکتور گذری',walk.length?money(Math.round(sumW/walk.length)):'—')}
  </div>
  <div class="grid g2">
    <div class="card"><h3>${ic('zap')} ثبت سریع فروش روزانه (نقدی)</h3>
      <form data-form="daily" class="form">
        ${fld('نام مشتری روزانه (اختیاری)',`<input name="dname" placeholder="مثلا: مشتری روزانه">`,'full')}
        ${fld('تاریخ',dateField('ddate',D.today()))}
        <div class="full"><h4 style="margin:6px 0">افزودن کالا</h4><input id="dq" placeholder="جستجوی کالا…" data-in="dq" autocomplete="off"><div class="pick" id="dpick"></div></div>
        <div class="full" id="dlines"></div>
        <div class="full sum"><div><span>جمع</span><b id="d_total">۰</b></div><div><span>روش دریافت</span><b>نقدی / کارت‌خوان (تسویه کامل)</b></div></div>
        ${fld('روش دریافت',sel('dmethod',[['cash','نقدی'],['pos','کارت‌خوان'],['card','کارت‌به‌کارت'],['transfer','انتقال بانکی']],DAILY.method),'sm')}
        ${fld('توضیحات',inp('dnote'),'full')}
        <button class="btn p full" type="submit" style="justify-content:center">${ic('check')} ثبت فروش روزانه</button>
      </form>
    </div>
    <div class="card"><h3>فاکتورهای گذری امروز (${walk.length})</h3><div id="dlist"></div></div>
  </div>
  <div class="card" style="margin-top:12px"><h3>همه فروش‌های امروز (${todays.length})</h3><div id="dall"></div></div>`;
  initDates(el);
  // انتخاب کالا
  const prods=L('products').filter(p=>p.active);
  const drawPick=()=>{
    const s=toEn($('#dq')?.value||'').toLowerCase();
    const r=prods.filter(p=>!s||(p.name+p.code+p.barcode).toLowerCase().includes(s)).slice(0,40);
    $('#dpick').innerHTML=r.map(p=>`<button type="button" data-act="dpick" data-id="${p.id}"><b>${esc(p.name)}</b><small>${money(p.sellPrice)}</small><small>موجودی: ${qtyf(stockOf(p.id),p.unit)}</small></button>`).join('')||'<div class="mu">کالایی یافت نشد</div>';
  };
  INP.dq=drawPick; drawPick();
  window._ditems=window._ditems||[];
  window._ditems=[];
  const recalc=()=>{
    let t=0; window._ditems.forEach(it=>{ t+=Math.round(it.qty*it.price/1000); });
    const e=$('#d_total'); if(e) e.textContent=num(t);
  };
  window._drecalc=recalc;
  const renderLines=()=>{
    const box=$('#dlines'); if(!box) return;
    box.innerHTML=window._ditems.length?window._ditems.map((it,i)=>`<div class="line" style="display:flex;gap:8px;align-items:center;border:1px solid var(--line);border-radius:10px;padding:6px 8px;margin-bottom:6px"><b style="flex:1">${esc(it.name)}<br><small class="mu">${num(it.price)} × ${qtyf(it.qty,it.unit)}</small></b><input data-di="${i}" data-f="qty" inputmode="decimal" value="${(it.qty/1000).toLocaleString('en-US')}" style="width:80px"><button type="button" class="btn s d" data-act="ddel" data-i="${i}">${ic('x')}</button></div>`).join(''):'<div class="mu">کالایی انتخاب نشده است.</div>';
    recalc();
  };
  window._drenderLines=renderLines;
  document.addEventListener('input',function _dqty(e){
    const inp2=e.target.closest?.('[data-di]'); if(!inp2) return;
    const i=+inp2.dataset.di; const v=parseFloat(String(inp2.value).replace(/,/g,''))||0;
    if(window._ditems[i]){ window._ditems[i].qty=Math.round(v*1000); window._drecalc(); }
  });
  // لیست امروز
  const rowCols=[
    {h:'شماره',f:s=>`<a href="#/invoices?id=${s.id}"><b>${s.no}</b></a>`},
    {h:'ساعت',f:s=>new Date(s.ts).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'})},
    {h:'مشتری',f:s=>esc(saleCustName(s))},
    {h:'مبلغ',cls:'n',f:s=>num(s.total)},
    {h:'',f:s=>`<button class="btn s" data-act="showinv" data-id="${s.id}">${ic('eye')}</button>`},
  ];
  $('#dlist').innerHTML=tbl(rowCols, walk.slice().sort((a,b)=>b.ts-a.ts),{id:'dl',empty:'امروز فروش گذری ثبت نشده است.'});
  $('#dall').innerHTML=tbl([{h:'شماره',f:s=>`<a href="#/invoices?id=${s.id}"><b>${s.no}</b></a>`},{h:'مشتری',f:s=>esc(saleCustName(s))},{h:'مبلغ',cls:'n',f:s=>num(s.total)},{h:'وضعیت',f:s=>s.status==='void'?badge('ابطال','err'):badge('تسویه','ok')}], todays.slice().sort((a,b)=>b.ts-a.ts),{id:'da',empty:'فروشی نیست.'});
};
ACT.dpick=el=>{
  const p=G('products',el.dataset.id); if(!p) return;
  const ex=window._ditems.find(x=>x.productId===p.id);
  if(ex) ex.qty+=1000;
  else window._ditems.push({productId:p.id,name:p.name,unit:p.unit,qty:1000,price:p.sellPrice});
  window._drenderLines();
};
ACT.ddel=el=>{ window._ditems.splice(+el.dataset.i,1); window._drenderLines(); };
FORM.daily=async f=>{
  if(!window._ditems?.length) throw new Error('حداقل یک کالا انتخاب کنید.');
  const date=readDate(f,'ddate',{label:'تاریخ'});
  const items=window._ditems.map(it=>{
    if(!(it.qty>0)) throw new Error('مقدار کالا نامعتبر است');
    return {productId:it.productId,qty:it.qty,unitPrice:it.price};
  });
  const dname=(f.dname.value||'').trim();
  const method=f.dmethod.value||'cash';
  // محاسبه جمع برای پرداخت کامل
  let sub=0; items.forEach(it=>{ it.amount=Math.round(it.qty*it.unitPrice/1000); sub+=it.amount; });
  const sale=await createSale({items:items.map(i=>({productId:i.productId,qty:i.qty,unitPrice:i.unitPrice})),discount:0,extra:0,date,note:(f.dnote.value||'')+(dname?'':'') ,priceType:'sellPrice',customerId:null,customerName:dname||'مشتری روزانه',pays:[{method,amount:sub,tracking:''}]});
  // اگر نام وارد شده، در یادداشت هم ذخیره شود
  toast('فروش روزانه ثبت شد: '+sale.no);
  window._ditems=[]; CUR.refresh();
};

// ---------- دکمه‌های اکسل در صفحات ----------
(function(){
  // افزودن دکمه اکسل به صفحات موجود بدون بازنویسی کامل (در اولین رندر)
  const _cust=PAGES.customers, _prod=PAGES.products, _inv=PAGES.invoices, _bk=PAGES.backup;
  PAGES.customers=function(el,q){
    _cust(el,q);
    try{
      const hd=el.querySelector('.hd');
      if(hd&&!hd.querySelector('[data-act=custxlsx]')){
        const b=document.createElement('button'); b.className='btn'; b.dataset.act='custxlsx'; b.innerHTML='اکسل';
        hd.appendChild(b);
      }
    }catch(e){}
  };
  PAGES.products=function(el,q){
    _prod(el,q);
    try{
      const hd=el.querySelector('.hd');
      if(hd&&!hd.querySelector('[data-act=prodxlsx]')){
        const b=document.createElement('button'); b.className='btn'; b.dataset.act='prodxlsx'; b.innerHTML='اکسل';
        hd.appendChild(b);
      }
    }catch(e){}
  };
  PAGES.invoices=function(el,q){
    _inv(el,q);
    try{
      const hd=el.querySelector('.hd');
      if(hd&&!hd.querySelector('[data-act=invxlsx]')){
        const b=document.createElement('button'); b.className='btn'; b.dataset.act='invxlsx'; b.innerHTML='اکسل';
        hd.appendChild(b);
      }
    }catch(e){}
  };
  PAGES.backup=function(el){
    _bk(el);
    try{
      const grid=el.querySelector('.grid');
      if(grid&&!el.querySelector('[data-act=bkexcel]')){
        const d=document.createElement('div'); d.className='card';
        d.innerHTML=`<h3>پشتیبانی و بازیابی با اکسل</h3><p class="mu">خروجی اکسل برای گزارش و انتقال به حسابداری. بازیابی کامل و مطمئن همچنان با JSON انجام می‌شود.</p><div class="excelBtns"><button class="btn p" data-act="bkexcel">${'دانلود پشتیبان اکسل'}</button><button class="btn" data-act="prodxlsx">اکسل کالاها</button><button class="btn" data-act="custxlsx">اکسل مشتریان</button><button class="btn" data-act="invxlsx">اکسل فاکتورها</button><button class="btn" data-act="supxlsx">اکسل تامین‌کنندگان</button></div><div class="fileline" style="margin-top:10px"><input type="file" id="bkexcelFile" accept=".xlsx,.xls"><button class="btn" data-act="bkexcelImp">وارد کردن از اکسل</button></div>`;
        grid.appendChild(d);
      }
    }catch(e){ console.error(e); }
  };
})();

// ---------- اصلاح جستجوی سراسری برای نام روزانه ----------
(function(){
  const _gs=INP.gs;
  INP.gs=function(el){
    // اجرای نسخه اصلی سپس اصلاح نمایش نام فروش گذری
    _gs(el);
    try{
      const box=$('#gsr'); if(!box) return;
      // نام‌ها از قبل با saleCustName اصلاح شده‌اند در بخش فروش؛ اگر نه، همین‌جا کافی است
    }catch(e){}
  };
})();

