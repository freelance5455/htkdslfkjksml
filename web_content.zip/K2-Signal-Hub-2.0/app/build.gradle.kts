plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ua.k2.signalhub"
    compileSdk = 35

    defaultConfig {
        applicationId = "ua.k2.signalhub"
        minSdk = 26
        targetSdk = 35
        versionCode = 20
        versionName = "2.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
