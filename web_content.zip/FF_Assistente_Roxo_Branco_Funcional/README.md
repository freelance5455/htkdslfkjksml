# FF Assistente — painel roxo e branco

Projeto Android nativo em Java. Os controles do painel funcionam para:
- LIGAR: muda o estado para LIGADO.
- DESLIGAR: muda o estado para DESLIGADO.
- MINIMIZAR: reduz o painel a uma bolha flutuante.
- Tocar na bolha: reabre o painel.
- FECHAR PAINEL: remove o painel flutuante.

**Limite:** isto é um painel de controle demonstrativo. Não joga Free Fire nem controla personagem, mira, disparos ou movimento. Não há promessa de evitar banimento. Instala-se como aplicativo separado; não copie arquivos para `Android/data`.

## Compilar
Este ZIP é um projeto Android Gradle, não um APK compilado.
1. Abra/importa a pasta `FF_Assistente_Roxo_Branco_Funcional` em um ambiente compatível com projetos Android Gradle.
2. Sincronize o Gradle.
3. Compile o APK debug e instale no Android.
4. Abra o app e permita exibição sobre outros aplicativos.
5. Toque em Abrir painel.

O APK Forge pode não aceitar projetos Gradle completos. Se só tiver editor/template simples, será necessária outra ferramenta de compilação.


## Atualização de detecção
Esta versão tenta detectar atividade recente dos pacotes conhecidos do Free Fire usando Acesso de uso do Android. Na primeira utilização, toque em “ATIVAR DETECÇÃO DO FREE FIRE” e permita o acesso para o app. A detecção pode variar por versão/clone/região e não é uma garantia absoluta de estado em primeiro plano.

Reconhecimento de inimigos e aliados por imagem ainda NÃO está implementado; os rótulos no painel informam isso claramente. O app não joga automaticamente nem interage com os controles do jogo.


## Arquivo index.html para APK Forge
Foi incluído `index.html` na raiz do ZIP e em `app/src/main/assets/index.html`. A página HTML funciona como interface web demonstrativa; os controles não detectam o jogo nem criam painel flutuante do Android. Para compilar o projeto Android Gradle original, use um compilador Android compatível. Também foi corrigido o import de `Context` em `PanelService.java`.

## Recursos adicionados nesta revisão
- Campo para cadastrar e salvar localmente o UID do jogador.
- Atalho para abrir o Free Fire instalado (versões/pacotes conhecidos).
- Seletor de captura de tela/imagem para pré-visualização.
- Mantém o painel flutuante e as permissões existentes.

Observação: não há integração oficial com a conta Garena nem modelo de IA para detecção automática de inimigos nesta versão. O seletor apenas mostra a imagem escolhida; não controla a partida.


## Detecção automática do app em uso
O painel verifica periodicamente o acesso de uso do Android. Para permitir a identificação, abra “ATIVAR DETECÇÃO AUTOMÁTICA DE JOGOS” no app e habilite o acesso de uso para FF Assistente nas configurações do sistema. O Android pode limitar a precisão em alguns aparelhos; o recurso identifica o app recente, não controla o jogo.
