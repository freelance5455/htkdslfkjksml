package com.example.ffassistant;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final int purple = Color.rgb(109, 40, 217);
    private final int pale = Color.rgb(247, 243, 255);
    private static final int PICK_IMAGE = 42;
    private TextView status;
    private ImageView preview;
    private EditText playerId;

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(0, 8, 0, 8); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 5, 0, 5); b.setLayoutParams(lp); return b;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(24, 30, 24, 24); root.setBackgroundColor(pale);
        scroll.addView(root);
        TextView title = text("FF ASSISTENTE", 28, purple); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView desc = text("Painel auxiliar • Roxo & branco\nCadastre seu ID, abra o jogo e selecione capturas de tela para visualizar.", 15, Color.DKGRAY);
        desc.setGravity(Gravity.CENTER); root.addView(desc);

        root.addView(text("ID DO JOGADOR FREE FIRE", 13, purple));
        playerId = new EditText(this); playerId.setSingleLine(true); playerId.setHint("Digite seu ID (UID)");
        SharedPreferences prefs = getSharedPreferences("ff_assistente", MODE_PRIVATE);
        playerId.setText(prefs.getString("player_id", "")); root.addView(playerId);
        Button save = button("SALVAR ID"); save.setOnClickListener(v -> {
            String id = playerId.getText().toString().trim();
            prefs.edit().putString("player_id", id).apply();
            status.setText(id.isEmpty() ? "Digite um ID antes de salvar." : "ID salvo neste aparelho: " + id);
        }); root.addView(save);

        Button launch = button("ABRIR FREE FIRE"); launch.setOnClickListener(v -> openGame()); root.addView(launch);
        Button permission = button("AUTORIZAR PAINEL FLUTUANTE"); permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            else startPanel();
        }); root.addView(permission);
        Button open = button("ABRIR PAINEL FLUTUANTE"); open.setOnClickListener(v -> { if (Settings.canDrawOverlays(this)) startPanel(); else permission.performClick(); }); root.addView(open);
        Button usage = button("ATIVAR DETECÇÃO AUTOMÁTICA DE JOGOS"); usage.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))); root.addView(usage);
        root.addView(text("A detecção atualiza o painel a cada 2 segundos. No Android, ative o acesso de uso para permitir identificar o app recente; a identificação de outros jogos depende das permissões e restrições do aparelho.", 12, Color.DKGRAY));

        root.addView(text("RECONHECIMENTO VISUAL — CAPTURA DE TELA", 13, purple));
        Button choose = button("SELECIONAR CAPTURA DE TELA"); choose.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_IMAGE);
        }); root.addView(choose);
        preview = new ImageView(this); preview.setAdjustViewBounds(true); preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(preview, new LinearLayout.LayoutParams(-1, 420));
        status = text("Pronto. O ID é apenas salvo localmente; não conecta à conta da Garena. A captura selecionada será exibida como prévia. Detecção automática de inimigos e controle do personagem não estão implementados.", 13, Color.DKGRAY);
        root.addView(status);
        setContentView(scroll);
    }
    private void openGame() {
        String[] packages = {"com.dts.freefireth", "com.dts.freefiremax", "com.dts.freefireindia"};
        for (String p : packages) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(p);
            if (launch != null) { startActivity(launch); status.setText("Free Fire aberto. O jogo continua sendo controlado por você."); return; }
        }
        status.setText("Não encontrei o Free Fire instalado. Instale/abra o jogo manualmente e tente novamente.");
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            preview.setImageURI(uri);
            status.setText("Captura carregada para visualização. Esta versão ainda não identifica inimigos automaticamente.");
        }
    }
    private void startPanel() {
        startService(new Intent(this, PanelService.class));
        status.setText("Painel flutuante iniciado.");
    }
}
