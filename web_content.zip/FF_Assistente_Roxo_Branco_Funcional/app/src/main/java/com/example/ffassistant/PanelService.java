package com.example.ffassistant;

import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.app.AppOpsManager;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import java.util.List;
import android.content.Intent;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PanelService extends Service {
    private WindowManager wm;
    private View panel;
    private View bubble;
    private TextView status;
    private boolean enabled = false;
    private TextView gameStatus;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable gameCheck = new Runnable() { public void run() { updateGameStatus(); handler.postDelayed(this, 2000); } };
    private final int purple = Color.rgb(109,40,217);
    private final int dark = Color.rgb(44,30,66);
    private WindowManager.LayoutParams panelParams, bubbleParams;

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); d.setStroke(2,stroke); return d;
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(8,7,8,7);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private Button button(String s, int color) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackground(shape(color,color,24)); return b;
    }
    @Override public void onCreate() { super.onCreate(); wm = (WindowManager)getSystemService(WINDOW_SERVICE); showPanel(); }
    private WindowManager.LayoutParams params() {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END; p.x = 18; p.y = 150; return p;
    }
    private void showPanel() {
        removeBubble();
        LinearLayout box = new LinearLayout(this); box.setOrientation(1); box.setPadding(14,12,14,14); box.setBackground(shape(Color.WHITE,purple,26));
        TextView header = label("◈  FF ASSISTENTE  ⋮", 15, purple, true); box.addView(header);
        status = label(enabled ? "● ESTADO: LIGADO" : "● ESTADO: DESLIGADO", 13, dark, true); box.addView(status);
        gameStatus = label("Jogo em execução: verificando acesso...", 12, dark, true); box.addView(gameStatus);
        box.addView(label("Inimigos/amigos: reconhecimento não implementado", 11, dark, false));
        Button on = button("LIGAR", purple);
        on.setOnClickListener(v -> { enabled = true; status.setText("● ESTADO: LIGADO"); status.setTextColor(purple); });
        box.addView(on);
        Button off = button("DESLIGAR", dark);
        off.setOnClickListener(v -> { enabled = false; status.setText("● ESTADO: DESLIGADO"); status.setTextColor(dark); });
        box.addView(off);
        Button min = button("MINIMIZAR", Color.rgb(125,110,145));
        min.setOnClickListener(v -> showBubble());
        box.addView(min);
        Button close = button("FECHAR PAINEL", Color.rgb(170,45,65));
        close.setOnClickListener(v -> stopSelf());
        box.addView(close);
        panelParams = params();
        header.setOnTouchListener(new View.OnTouchListener() {
            int sx,sy; float tx,ty;
            public boolean onTouch(View v, MotionEvent e) {
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=panelParams.x;sy=panelParams.y;tx=e.getRawX();ty=e.getRawY();return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){panelParams.x=sx+(int)(tx-e.getRawX());panelParams.y=sy+(int)(e.getRawY()-ty);try{wm.updateViewLayout(box,panelParams);}catch(Exception ignored){}return true;}
                return true;
            }
        });
        panel = box; wm.addView(panel,panelParams);
        handler.removeCallbacks(gameCheck); handler.post(gameCheck);
    }
    private void updateGameStatus() {
        if (gameStatus == null) return;
        try {
            AppOpsManager appOps = (AppOpsManager)getSystemService(Context.APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow("android:get_usage_stats", Process.myUid(), getPackageName());
            if (mode != AppOpsManager.MODE_ALLOWED) { gameStatus.setText("Jogo: autorize Acesso de uso nas configurações"); return; }
            UsageStatsManager usm = (UsageStatsManager)getSystemService(Context.USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            List<UsageStats> list = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 30000, now);
            UsageStats recent = null;
            if (list != null) for (UsageStats u : list) {
                String pkg = u.getPackageName();
                if (pkg.equals(getPackageName()) || pkg.startsWith("com.android.") || pkg.startsWith("com.google.android.")) continue;
                if (recent == null || u.getLastTimeUsed() > recent.getLastTimeUsed()) recent = u;
            }
            if (recent != null && now - recent.getLastTimeUsed() < 12000) {
                String pkg = recent.getPackageName();
                String appName = pkg;
                try { appName = getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)).toString(); } catch (Exception ignored) { }
                boolean ff = pkg.equals("com.dts.freefireth") || pkg.equals("com.dts.freefiremax") || pkg.equals("com.dts.freefireindia");
                gameStatus.setText(ff ? "Jogo detectado: Free Fire" : "App recente: " + appName);
            } else gameStatus.setText("Jogo: nenhum detectado recentemente");
        } catch (Exception e) { gameStatus.setText("Jogo: não foi possível verificar"); }
    }
    private void showBubble() {
        if(panel != null) { try { wm.removeView(panel); } catch(Exception ignored) {} panel = null; }
        TextView b = label("FF", 17, Color.WHITE, true); b.setGravity(Gravity.CENTER); b.setBackground(shape(purple,Color.WHITE,100));
        bubbleParams = params(); bubbleParams.width = dp(56); bubbleParams.height = dp(56);
        b.setOnClickListener(v -> showPanel());
        b.setOnTouchListener(new View.OnTouchListener() {
            int sx,sy; float tx,ty;
            public boolean onTouch(View v, MotionEvent e) {
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=bubbleParams.x;sy=bubbleParams.y;tx=e.getRawX();ty=e.getRawY();return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){bubbleParams.x=sx+(int)(tx-e.getRawX());bubbleParams.y=sy+(int)(e.getRawY()-ty);try{wm.updateViewLayout(b,bubbleParams);}catch(Exception ignored){}return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){ if(Math.abs(e.getRawX()-tx)<12 && Math.abs(e.getRawY()-ty)<12) showPanel(); return true; }
                return true;
            }
        });
        bubble=b; wm.addView(bubble,bubbleParams);
    }
    private int dp(int value) { return (int)(value*getResources().getDisplayMetrics().density+0.5f); }
    private void removeBubble() { if(bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;} }
    @Override public int onStartCommand(Intent intent,int flags,int id) { if(panel==null && bubble==null) showPanel(); return START_NOT_STICKY; }
    @Override public void onDestroy() {
        handler.removeCallbacks(gameCheck); gameStatus = null;
        if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}
        removeBubble(); super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
