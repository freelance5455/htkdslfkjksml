TEXT DESIGN STUDIO PRO — PHONE-FIRST PACKAGE

This ZIP includes:
1) Android Studio project source with native Android PNG save bridge.
2) Browser_Version folder containing index.html, style.css and app.js to test in a browser.

IMPORTANT:
- This ZIP is source code, not a prebuilt APK.
- For the save button to write directly into Pictures/Text Design Studio, the Android app must be rebuilt from the Android project and installed.
- In the browser version, PNG save uses Android/browser file sharing when supported, otherwise a normal download.
- On a phone, extract the ZIP with your file manager. To build an APK on-phone, you need a mobile Android build environment; merely opening the source files will not update an installed APK.
- The native Android bridge writes PNG files using MediaStore, and shows a toast/status message on success or failure.

Android project folder: open the root folder in Android Studio / a compatible mobile build environment.
Browser version: open Browser_Version/index.html in a browser or local HTML editor preview.
