AG MAKEUP - APLICACIÓN DE ADMINISTRACIÓN

Incluye:
- Catálogo de productos con foto, categoría, costo, precio, existencias y código.
- Cálculo de ganancia por pieza, margen sobre precio de venta y recargo sobre costo.
- Registro de clientes.
- Registro de ventas, descuentos, forma de pago e inventario actualizado.
- Reportes básicos de ventas, ganancias e inventario.
- Exportación de respaldos JSON e importación/restauración.
- Exportación CSV de productos y ventas.
- Manifest PWA y service worker para uso instalable/offline tras publicar por HTTPS.

IMPORTANTE:
- Los datos se guardan localmente en el navegador/dispositivo; no hay sincronización en la nube.
- Exporta respaldos con frecuencia y antes de actualizar, borrar datos o cambiar de dispositivo.
- La eliminación de datos del navegador, la limpieza del almacenamiento o la pérdida del dispositivo pueden causar pérdida de datos si no hay respaldo.
- Las fotos se comprimen a un máximo aproximado de 600 px antes de guardarse.
- Este paquete es una versión inicial funcional; antes de venderla, pruébala a fondo en varios dispositivos y define soporte, licencia, privacidad y actualizaciones.

PARA PROBAR:
Abre index.html en un navegador. Para instalar como PWA, publícala en una dirección HTTPS y usa el manifest. El modo offline requiere que el navegador haya cargado la aplicación y registrado el service worker al menos una vez.
