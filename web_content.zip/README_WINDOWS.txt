Abdul Samad Watches — POS & Inventory (Offline Windows Package v3)
=======================================================================

1. Extract all files from this ZIP into a folder on your Windows PC (for example: C:\Abdul_Samad_Watches_POS\).
2. Double-click "Run_Abdul_Samad_Watches_POS.bat" to launch the app offline in your browser.
