# إعداد TAKI-GO كتطبيق Android APK

تم تجهيز المشروع لإضافة Android عبر Capacitor مع الحفاظ على مصدر React/Vite الأصلي.

## المتطلبات
- Node.js 20 أو أحدث
- Android Studio حديث
- Android SDK وJDK (يتم تثبيتهما من Android Studio)
- اتصال إنترنت أثناء تثبيت الحزم أول مرة

## إنشاء مشروع Android
من مجلد المشروع نفّذ:

```bash
npm install
npx cap add android
npm run android:sync
npx cap open android
```

في Android Studio انتظر اكتمال Gradle Sync، ثم اختر:
Build > Build Bundle(s) / APK(s) > Build APK(s)

ملف APK التجريبي يظهر عادةً في:
`android/app/build/outputs/apk/debug/app-debug.apk`

لنسخة توزيع موقعة اختر Build > Generate Signed Bundle / APK.

## ملاحظات مهمة قبل النشر
1. هذا المصدر لا يتضمن ملف APK مبنياً. بيئة تجهيز الملفات الحالية لا تحتوي Android SDK/Gradle، كما تعذر تنزيل حزم npm بسبب عدم توفر اتصال registry.
2. ملف `.env.example` يطلب `GEMINI_API_KEY`. لا تضع مفتاح Gemini سرياً داخل تطبيق Android أو داخل ملفات الواجهة؛ استدعاءات الذكاء الاصطناعي يجب أن تمر عبر خادم آمن.
3. فحص المصدر الحالي لم يجد ربطاً فعلياً بـ Supabase أو Cloudflare Worker؛ لا يمكنني تأكيد أن تسجيل الدخول والحجوزات والبحث متصلة بهما قبل إضافة إعدادات الربط الصحيحة واختبارها.
4. بعد `npm run build` يجب التأكد من أن `dist/` يحتوي ملفات الواجهة، ثم تنفيذ `npx cap sync android`.

## هوية التطبيق
- الاسم: TAKI-GO
- المعرّف: `dz.tourismebytaki.takigo`
- الاتجاه الأساسي للواجهة: العربية RTL (كما في `index.html`).
