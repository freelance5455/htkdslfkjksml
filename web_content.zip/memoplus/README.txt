MemoPlus
========
PWA installable, plein écran (standalone) et conçue pour fonctionner hors ligne.

Fichiers principaux :
- index.html
- app.js
- sw.js
- manifest.webmanifest
- icons/icon-192.png
- icons/icon-512.png

Pour l'installation sur Android, servir le dossier en HTTPS (ou localhost pendant les tests), ouvrir index.html via le serveur, puis utiliser « Installer » / « Ajouter à l'écran d'accueil ».
