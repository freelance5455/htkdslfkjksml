const KEY="memoplus_notes_v1";
let notes=JSON.parse(localStorage.getItem(KEY)||"[]");
const $=id=>document.getElementById(id);
function save(){localStorage.setItem(KEY,JSON.stringify(notes));render();}
function render(){
  const q=$("search").value.toLowerCase();
  $("notes").innerHTML="";
  notes.filter(n=>n.text.toLowerCase().includes(q)).forEach(n=>{
    const d=document.createElement("div");d.className="note";
    d.innerHTML=`<h3>Mémo</h3><p></p><div class="meta">${new Date(n.date).toLocaleString("fr-FR")}</div>`;
    d.querySelector("p").textContent=n.text;
    const b=document.createElement("button");b.className="danger";b.textContent="Supprimer";
    b.style.marginTop="10px";b.onclick=()=>{notes=notes.filter(x=>x.id!==n.id);save()};
    d.appendChild(b);$("notes").appendChild(d);
  });
}
$("save").onclick=()=>{const text=$("text").value.trim();if(!text)return;notes.unshift({id:Date.now(),text,date:Date.now()});$("text").value="";save()};
$("clear").onclick=()=>{$("text").value=""};
$("search").oninput=render;
render();

if("serviceWorker" in navigator) navigator.serviceWorker.register("./sw.js");

let deferredPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("install").style.display="block"});
$("installBtn").onclick=async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("install").style.display="none"};
