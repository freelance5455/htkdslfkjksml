Saim Agro Science - Offline Stock Manager
Open index.html in a modern Android browser.
Data is stored locally in that browser/device.
This prototype is not yet a signed Android APK.
