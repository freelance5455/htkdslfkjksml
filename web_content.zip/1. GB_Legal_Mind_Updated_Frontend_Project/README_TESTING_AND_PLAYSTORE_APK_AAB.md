# GB LEGAL MIND — COMPLETE PROJECT, CHROME TESTING & APK/AAB GUIDE

## 1. Project Folder Structure
- `index.html` — Modular entry file (uses classic `<script>` & `<link>` tags so it works without ES-module CORS errors).
- `GB_Legal_Mind_Standalone_Chrome_Test.html` — **100% Self-Contained Single-File Build** (all CSS, JS, and images embedded as base64 data URIs). Open this file directly in Android Chrome from Downloads/WhatsApp/File Manager (`content://` or `file://`) and every image and screen will work immediately!
- `css/styles.css` — Full Dark Mode & Light Mode variables and responsive layout rules.
- `js/data.js` — Admin-CMS-ready structured legal database (BNS 2023, BNSS 2023, BSA 2023, Constitution, Public Law, Slides, PDF Quiz, Mind Maps, Handwritten Notes, Shabdawali, MCQ Test, Advocate Directory, Diary Cases).
- `js/app.js` — Complete interactive router, back navigation history stack, Audio/Video/Slide/PDF/MindMap/Handwriting players, and modals.
- `config/app-config.json` — Package configuration (`com.gblegalmind.app`, `versionName: "1.0.0"`, `versionCode: 1`) and explicit separation of Demo vs Production integrations.
- `assets/images/` — 21 optimized UI images extracted from the 33-page design specification (~750 KB total).
- `assets/media/` — Sample audio (`sample_audio.wav`) and sample downloadable PDF (`sample_legal_notes.pdf`).

## 2. Why Opening `index.html` Directly on Android Can Fail (And How We Solved It)
When you tap `index.html` inside an Android File Manager, Android opens it via a `content://` URI (`content://com.android.externalstorage.../index.html`):
1. **Android `content://` Sandbox Restriction**: Chrome on Android blocks a `content://` HTML file from loading external relative files (`css/styles.css`, `js/app.js`, `assets/images/*.jpg`) for security reasons.
2. **CORS Policy on `file://`**: Browser security blocks `fetch('data.json')` and `<script type="module">` when opened without an HTTP server.

### How to Test on Your Android Phone in Chrome (3 Easy Ways):
- **Method A (Easiest — 1-Tap Direct Open on Phone)**:
  Open `GB_Legal_Mind_Standalone_Chrome_Test.html` directly in Android Chrome! Because all CSS, JS, JSON data, and images are embedded inside that single HTML file, Android's `content://` blocker cannot block any asset.
- **Method B (Local Server on Phone via Termux or Spck Editor / Acode)**:
  Extract the ZIP folder, run `python3 start_mobile_server.py`, and open `http://localhost:8080` in Chrome.
- **Method C (PC + Phone on Same Wi-Fi / Hotspot)**:
  Run `python3 start_mobile_server.py` on your laptop/PC and open `http://<YOUR_PC_IP>:8080` in your Android phone's Chrome browser.

## 3. Building Android APK & Play Store AAB (Step-by-Step)
- **Package Name (Fixed)**: `com.gblegalmind.app`
- **Version Name**: `1.0.0` | **Version Code**: `1` (Increment `versionCode` by +1 for every Play Store update: `1 -> 2 -> 3`).

### Commands to Generate Debug APK & Signed Release AAB:
```bash
# 1. Copy project files into www/ folder and initialize Capacitor Android
mkdir -p www && cp -r index.html manifest.json css js assets config www/
npm install
npx cap add android
npx cap sync android

# 2. Build Debug APK for Phone Installation & Testing
cd android
./gradlew assembleDebug
# Output APK: android/app/build/outputs/apk/debug/app-debug.apk

# 3. Generate Upload Keystore (First Time Only — Keep Safe Forever!)
keytool -genkey -v -keystore release-key.keystore -alias gblegalmind_key -keyalg RSA -keysize 2048 -validity 10000

# 4. Build Signed Android App Bundle (AAB) for Google Play Store
./gradlew bundleRelease
# Output AAB: android/app/build/outputs/bundle/release/app-release.aab
```
