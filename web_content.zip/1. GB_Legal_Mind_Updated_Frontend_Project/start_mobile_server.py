#!/usr/bin/env python3
import http.server
import socketserver
import socket

PORT = 8080

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

Handler = http.server.SimpleHTTPRequestHandler
with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
    ip = get_local_ip()
    print("====================================================")
    print(" GB LEGAL MIND — MOBILE CHROME TEST SERVER RUNNING")
    print(f" Local URL (Same Device): http://localhost:{PORT}")
    print(f" Wi-Fi Mobile URL:        http://{ip}:{PORT}")
    print("====================================================")
    httpd.serve_forever()
