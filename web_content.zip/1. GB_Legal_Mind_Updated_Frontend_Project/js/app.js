// GB LEGAL MIND — Master Frontend Application Engine (v3.0.0)
// Implements 100% of the Final Master Development Command & all 3 PDF Design References.

(function () {
  const DATA = window.GB_DATA;
  const STORAGE_KEY = "gb_legal_mind_master_v2";
  const THEME_KEY = "gb_legal_theme_v2";

  const state = {
    theme: "dark",
    isLoggedIn: false,
    currentScreen: "auth", // Opens at Common Login first (Splash -> Welcome/Common Login -> OTP -> Terms -> Home)
    historyStack: [],
    fullscreenMode: false,

    // 1. Common Login Flow (NO role selector at login! One common login for everyone)
    authStep: "welcome", // welcome | mobile | otp | terms | google_notice | no_internet
    mobileInput: "9876543210",
    otpInput: "123456",
    authError: "",
    termsAccepted: true,
    privacyAccepted: true,

    // Account Identity vs Profile Type (Separate concepts per Requirement #2 & #9)
    userAccountName: "Gulab Badshah",
    userPhone: "8545963439",
    userEmail: "gulabbadshah@gmail.com",
    joinedDate: "13 Aug 2026",
    activeProfileType: "General", // General | Advocate | Student
    selectedUpgradePlan: "6_months",
    upgradeModalOpen: false,

    // Home & Core Navigation
    bannerIndex: 0,
    selectedActId: "bns",
    selectedMediaTab: "audio", // audio | video | pdf | mindmap | slides | handwriting
    selectedChapterId: "bns_ch1",
    selectedSectionId: "bns_s1",
    selectedPublicTopicId: "fir",
    publicLawMediaTab: "audio",

    // Bare Act Library (800+ Acts Scalable Structure + Dual Format Reader)
    librarySearch: "",
    libraryCategory: "All",
    favouriteActs: ["bns", "bnss", "bsa", "constitution", "ica_1872"],
    bookmarkedSections: ["bns_s1", "bnss_s173", "const_a21"],
    readSections: ["bns_s1", "bns_s2", "bnss_s173"],
    bareActFormatMode: "dual", // dual | original | saral
    bareActLang: "hi", // hi | en
    readerFontSize: 14,

    // Legal Shabdawali, Kanooni Line, Daily 10 Words & Audio Learning
    shabdawaliQuery: "",
    shabdawaliCategory: "all",
    shabdawaliRange: "1-500",
    shabdawaliViewMode: "short", // short | detailed
    shabdawaliSavedOnly: false,
    shabdawaliSortOrder: "num_asc", // num_asc | num_desc | alpha_asc | alpha_desc
    shabdawaliLetterFilter: "ALL",
    shabdawaliNewOnly: false,
    shabdawaliFilterModalOpen: false,
    favouriteWords: ["w1", "w2", "w5", "w9"],
    selectedWordId: "w9", // Default word detail e.g. Embarrassing / Authorised
    daily10LearnedIds: ["w9", "w10", "w11", "w12"],
    daily10StreakDays: 12,
    audioLearningTab: "range", // range | manual
    audioRangeFrom: 1,
    audioRangeTo: 50,
    audioSelectedWordIds: ["w1", "w2", "w3", "w4", "w5", "w6", "w7", "w8"],
    audioPlaylistDrawerOpen: false,
    activeAudioWordIdx: 0,
    autoPlayAudio: true,

    // Media Players & Viewers State
    isPlaying: false,
    currentTimeSec: 1125, // 18:45
    totalTimeSec: 4350,   // 1:12:30
    playbackSpeed: 1.0,
    sleepTimerMin: 30,
    videoLandscape: false,
    videoQuality: "1080p",
    videoSubtitles: "English / Hindi",
    videoBrightness: 80,
    videoVolume: 60,
    slideIndex: 4, // Slide 5 / 15 preview
    slideDrawerOpen: false,
    pdfPageIndex: 0,
    pdfDrawerOpen: false,
    pdfAnswers: {},
    mindMapZoom: 1.0,
    mindMapSelectedNode: "mm1",
    mindMapDrawerOpen: false,
    hwPageIndex: 0,
    hwHighlight: true,

    // MCQ & Mock Tests Complete Flow
    mcqScreenView: "hub", // hub | act_levels | set_list | test_settings | active_test | confirm_submit | times_up | results | analytics | right_wrong | weak_areas | my_tests | saved_bookmarks
    mcqSelectedActTitle: "Indian Evidence Act / BSA 2023",
    mcqFilterAct: "All",
    mcqFilterLevel: "Medium", // Easy | Medium | Hard | Expert
    mcqMode: "Practice", // Practice | Exam
    mcqCountLimit: 10,
    mcqTimerMinutes: 30,
    mcqTimerSec: 1785, // 00:29:45
    mcqCurrentIdx: 0,
    mcqAnswers: {},
    mcqReviewMarked: {},
    mcqShowHint: false,
    mcqShowExplanation: true,
    mcqRightWrongTab: "all", // all | correct | wrong | unattempted | review | smart
    mcqMyTestsTab: "all", // all | completed | in_progress | not_attempted | review
    mcqSavedTab: "tests", // tests | questions
    mcqSavedQuestions: ["mcq_1", "mcq_2", "mcq_4"],
    mcqSavedTests: [
      { id: "st_1", title: "All India Mock Test – 05", date: "18 May 2025 • 60 Min", score: "38/50 (76%)", pct: 76, status: "Completed" },
      { id: "st_2", title: "Constitution of India – 02", date: "16 May 2025 • 60 Min", score: "32/50 (64%)", pct: 64, status: "Completed" },
      { id: "st_3", title: "All Mix Test – 09", date: "15 May 2025 • 120 Min", score: "82/100 (82%)", pct: 82, status: "Completed" }
    ],

    // 3 Profile Types Data (General User, Advocate, Law Student)
    generalUserProfile: {
      fullName: "Gulab Badshah",
      phone: "8545963439",
      email: "gulabbadshah@gmail.com",
      state: "Uttar Pradesh",
      district: "Jalaun / Kalpi",
      address: "Civil Lines, Near District Court",
      city: "Kalpi",
      pincode: "285204",
      dob: "1998-08-15",
      gender: "Male",
      userCategory: "Law Aspirant / Citizen",
      profCourse: "BA LL.B / Judiciary Prep",
      college: "Bundelkhand University / Legal Mind Academy",
      photoDataUrl: ""
    },
    advocateProfile: {
      fullName: "Adv. Rahul Sharma",
      fatherName: "Mr. Suresh Sharma",
      dob: "1992-03-15",
      gender: "Male",
      phone: "9876543210",
      email: "adv.rahul.demo@gblegalmind.app",
      barCouncil: "Uttar Pradesh State Bar Council",
      barNo: "UP/12345/2016",
      enrollDate: "12 July 2016",
      enrollType: "Regular",
      barCouncilId: "BCUP201612345",
      experience: "8+ Years",
      primaryCourt: "Allahabad High Court, Prayagraj, UP",
      chamberName: "Rahul Sharma & Associates",
      chamberNo: "25, Lawyers Chamber, Near Gate No. 3, High Court",
      city: "Prayagraj, Uttar Pradesh",
      state: "Uttar Pradesh",
      practiceAreas: ["Civil Law", "Criminal Law", "Constitutional Law", "Family Law", "Property Law", "Bail Matters", "Legal Drafting"],
      courtsPracticing: ["Allahabad High Court", "District & Sessions Court", "Civil Court", "Family Court", "Criminal Court"],
      languages: ["Hindi", "English", "Hinglish"],
      education: "B.A. LL.B. (2010–2015), LL.M. Constitutional Law (2015–2016) — Allahabad University",
      certifications: "Diploma in Cyber Law – ILI (2018), Certificate Course in IPR – NALSAR (2019)",
      workingDays: "Monday to Saturday (10:30 AM – 5:30 PM)",
      freePlanFee: "0",
      standardPlanFee: "149",
      premiumPlanFee: "299",
      selectedPlanTier: "Standard",
      bio: "Dedicated to providing honest, practical and result-oriented legal advice with a focus on protecting clients' rights.",
      photoDataUrl: "",
      barIdFileName: "Bar_Council_ID_Demo.pdf",
      verificationStatus: "Pending / Demo Verification"
    },
    studentProfile: {
      fullName: "Neha Singh",
      gender: "Female",
      dob: "2003-06-12",
      phone: "9876501234",
      email: "neha.lawstudent@gblegalmind.app",
      state: "Uttar Pradesh",
      city: "Varanasi, Uttar Pradesh",
      course: "B.A. LL.B.",
      semester: "5th Semester",
      college: "LMN Law College, Varanasi",
      passingYear: "2027",
      interests: ["Criminal Law", "Constitutional Law", "Court Practice", "Legal Research", "Drafting", "Moot Court"],
      skills: ["Legal Research", "Case Analysis", "Drafting", "Judgment Reading", "MS Word", "Communication"],
      languages: ["Hindi (Native)", "English (Good)", "Hinglish (Fluent)"],
      hobbies: ["Reading", "Writing", "Moot Court", "Current Affairs"],
      achievements: "Participated in College Moot Court Competition (2024); Attended Workshop on Criminal Law (2024); Volunteered in Legal Aid Camp.",
      preferredLocations: "Varanasi, UP | Lucknow, UP | Delhi",
      preferredDuration: "1 – 6 Months",
      internMode: "Online / Offline / Both",
      stipendPref: "Free Internship (Willing to work without stipend for learning)",
      guidanceType: "Free", // Free | Paid (₹49)
      bio: "I am a dedicated law student with keen interest in Criminal Law, Constitutional Law and Court Practice. Eager to gain practical exposure under a senior advocate.",
      photoDataUrl: "",
      resumeFileName: "Resume_CV_Demo.pdf (1.2 MB)",
      collegeIdFileName: "College_ID_Card_Demo.pdf (0.8 MB)",
      verificationStatus: "Pending / Demo Verification"
    },

    // Find Advocate, Student, Internships, Appointments & Document Services
    directoryTab: "advocates", // advocates | students | internships_stu | internships_adv
    directorySearch: "",
    directoryLocationFilter: "All",
    directorySpecialty: "All",
    viewingProfileId: "adv_rahul",
    viewingProfileTab: "about", // about | professional | consulting (or guidance / internship for students)
    selectedInternshipStudentId: "stu_neha",
    selectedInternshipAdvId: "int_adv_1",

    // Appointment 3-Step Flow (Form -> Review -> Confirmed / My Appointments)
    appointmentStep: "form", // form | review | confirmed | my_appointments
    selectedConsultAdvId: "adv_rahul",
    myAppointmentsTab: "all", // all | pending | confirmed | completed
    appointmentForm: {
      fullName: "रोहित कुमार (Rohit Kumar)",
      phone: "9876543210",
      email: "rohit123@gmail.com",
      subject: "सिविल कानून (Civil Law)",
      matterType: "संपत्ति विवाद (Property Dispute)",
      problemDesc: "गांव की सरकारी जमीन और पैतृक भूमि पर कब्जे का मामला है, नोटिस मिला है, आगे क्या करें?",
      priorityType: "संक्षिप्त मार्गदर्शन (सामान्य सलाह)",
      date: "18 सितंबर 2026 (शुक्रवार)",
      slot: "11:00 AM - 11:30 AM",
      mode: "WhatsApp Video Call",
      photoFileName: "Property_Photo.jpg (3.2 MB)",
      pdfFileName: "Application.pdf (6.5 MB)"
    },
    appointmentsList: [
      {
        id: "apt_1",
        advName: "Adv. Rahul Sharma",
        advRole: "High Court Advocate • प्रयागराज, उत्तर प्रदेश",
        rating: "4.8 (256 Ratings)",
        date: "18 सितंबर 2026 (शुक्रवार)",
        slot: "11:00 AM - 11:30 AM",
        subject: "सिविल कानून",
        matter: "संपत्ति विवाद",
        mode: "WhatsApp Video Call",
        problem: "गांव की सरकारी जमीन पर कब्जे का मामला है, नोटिस मिला है, आगे क्या करें?",
        status: "Pending"
      },
      {
        id: "apt_2",
        advName: "Adv. Priya Singh",
        advRole: "High Court Advocate • लखनऊ, उत्तर प्रदेश",
        rating: "4.7 (189 Ratings)",
        date: "22 सितंबर 2026 (सोमवार)",
        slot: "02:00 PM - 02:30 PM",
        subject: "फैमिली कानून",
        matter: "तलाक / भरण पोषण",
        mode: "Google Meeting (Video Call)",
        meetLink: "https://meet.google.com/abc-defg-hij (Demo)",
        problem: "पारिवारिक विवाद और भरण-पोषण (Maintenance) के संबंध में कानूनी परामर्श।",
        status: "Confirmed"
      },
      {
        id: "apt_3",
        advName: "Adv. Amit Verma",
        advRole: "District Court Advocate • कानपुर, उत्तर प्रदेश",
        rating: "4.5 (98 Ratings)",
        date: "10 सितंबर 2026 (बुधवार)",
        slot: "04:00 PM - 04:30 PM",
        subject: "जमीन विवाद",
        matter: "दस्तावेज सत्यापन",
        mode: "Phone Call",
        problem: "रजिस्ट्री और दाखिल-खारिज के कागजात की जांच।",
        status: "Completed"
      }
    ],

    // Documents Banwane Ki Service 3-Step Flow (Form -> Review -> Advocate Panel My Documents)
    docServiceStep: "form", // form | review | advocate_panel | doc_detail
    myDocsFilterTab: "all", // all | pending | confirmed | completed
    selectedDocRequestId: "doc_req_1",
    docRequestForm: {
      applicantName: "राहुल कुमार (Rahul Kumar)",
      applicantPhone: "9876543210",
      applicantEmail: "rahul123@gmail.com",
      docCategory: "शपथ पत्र (Affidavit)",
      docName: "आय प्रमाण पत्र / भूमि विवाद शपथ पत्र",
      purpose: "सरकारी नौकरी / न्यायालय में प्रस्तुत करने के लिए",
      details: "मुझे सरकारी नौकरी के लिए आय प्रमाण पत्र एवं शपथ पत्र बनवाना है। नाम: राहुल कुमार, पिता का नाम: रामलाल।",
      photoFileName: "Document_Photo.jpg (3.2 MB)",
      pdfFileName: "Application.pdf (6.5 MB)",
      contactMode: "WhatsApp"
    },
    advocatePanelDocs: [
      {
        id: "doc_req_1",
        clientName: "Priya Singh",
        clientPhone: "9876543210",
        clientEmail: "priya123@gmail.com",
        docType: "Affidavit Drafting (शपथ पत्र)",
        date: "25 सितंबर 2026, 04:15 PM",
        purpose: "भूमि विवाद से संबंधित",
        summary: "ग्राम समाज की भूमि पर कब्जे के मामले में शपथ पत्र बनवाना है ताकि अदालत में प्रस्तुत किया जा सके।",
        extraNotes: "नोटिस मिला है, जवाब के लिए शपथ पत्र तैयार करवाना है।",
        photoCount: 1,
        pdfCount: 1,
        status: "Pending"
      },
      {
        id: "doc_req_2",
        clientName: "Amit Verma",
        clientPhone: "9876509876",
        clientEmail: "amit.v@gmail.com",
        docType: "Sale Deed Drafting (मकान बिक्री नामा)",
        date: "24 सितंबर 2026, 02:10 PM",
        purpose: "मकान बिक्री के लिए दस्तावेज बनवाना है।",
        summary: "कानपुर स्थित आवासीय प्लॉट के विक्रय हेतु सेल डीड प्रारूप।",
        extraNotes: "दोनों पक्षकारों के आधार और खतौनी संलग्न हैं।",
        photoCount: 2,
        pdfCount: 1,
        status: "Confirmed"
      },
      {
        id: "doc_req_3",
        clientName: "Rahul Kumar",
        clientPhone: "9876512340",
        clientEmail: "rahul123@gmail.com",
        docType: "Rent Agreement (किरायानामा)",
        date: "26 सितंबर 2026, 11:30 AM",
        purpose: "दुकान व मकान का 11 माह का किरायानामा बनवाना है।",
        summary: "11 महीने का रेंट एग्रीमेंट ड्राफ्ट।",
        extraNotes: "किराया ₹8,500 प्रति माह।",
        photoCount: 1,
        pdfCount: 1,
        status: "Pending"
      },
      {
        id: "doc_req_4",
        clientName: "Neha Gupta",
        clientPhone: "9876522211",
        clientEmail: "neha.g@gmail.com",
        docType: "Legal Notice (कानूनी नोटिस)",
        date: "22 सितंबर 2026, 12:00 PM",
        purpose: "किराया न देने के लिए कानूनी नोटिस बनवाना है।",
        summary: "किरायेदार द्वारा 6 माह से किराया न देने पर बेदखली व वसूली नोटिस।",
        extraNotes: "रेंट एग्रीमेंट की कॉपी संलग्न है।",
        photoCount: 0,
        pdfCount: 1,
        status: "Confirmed"
      },
      {
        id: "doc_req_5",
        clientName: "Sandeep Yadav",
        clientPhone: "9876533322",
        clientEmail: "sandeep.y@gmail.com",
        docType: "Court Application (कोर्ट प्रार्थना पत्र)",
        date: "20 सितंबर 2026, 03:45 PM",
        purpose: "कोर्ट में लगाने के लिए प्रार्थना पत्र बनवाना है।",
        summary: "BNSS धारा 175(3) के अंतर्गत प्रार्थना पत्र।",
        extraNotes: "ड्राफ्ट तैयार कर PDF भेज दिया गया है।",
        photoCount: 1,
        pdfCount: 2,
        status: "Completed"
      }
    ],

    // 11. Consulting = LIVE CHAT State (PDF 3 Page 26)
    consultingView: "list", // list | chat
    consultingSearch: "",
    consultingFilter: "All", // All | Advocate | Student | User
    activeConversationId: "conv_gulab",
    selectedChatMsgIds: [],
    chatQuickSheetOpen: true,
    conversations: JSON.parse(JSON.stringify(DATA.consultingConversations)),

    // Support Chat State (PDF 3 Page 27)
    supportStep: "category", // category | bot_chat | human_requested | human_joined | ended
    supportIssueCategory: "Payment Issue",
    supportScreenshotName: "",
    supportMessages: [
      { sender: "bot", text: "🙏 Namaste! Aapne Payment Issue select kiya hai. Kripya apna payment screenshot upload kijiye.", time: "10:30 AM" }
    ],

    // Advocate Diary, Student Notes & Reels State
    diarySearch: "",
    diaryEditingId: null,
    diaryViewingId: null,
    diaryCases: JSON.parse(JSON.stringify(DATA.diaryCases)),

    notesSearch: "",
    notesSubjectFilter: "All",
    noteEditingId: null,
    noteViewingId: null,
    studentNotes: JSON.parse(JSON.stringify(DATA.studentNotesList)),

    reelsCategory: "section_reels", // section_reels | public_law | all_reels | topic_list
    currentReelIndex: 0,
    reelsSectionModalOpen: false,
    reelsDrawerTab: "sections", // sections | chapters
    reelsSearchQuery: "",

    // Progress Tracking State (PDF 3 Pages 18–21)
    progressTab: "act", // act | public_law | all_acts_list | criminal_topics
    progressByAct: {
      constitution: { name: "Constitution of India", completed: 220, inProgress: 120, notStarted: 55, total: 395 },
      bns: { name: "Bharatiya Nyaya Sanhita (BNS)", completed: 161, inProgress: 118, notStarted: 79, total: 358 },
      bnss: { name: "Bharatiya Nagarik Suraksha Sanhita", completed: 149, inProgress: 171, notStarted: 211, total: 531 },
      bsa: { name: "Bharatiya Sakshya Adhiniyam", completed: 55, inProgress: 20, notStarted: 95, total: 170 },
      publicLaw: { name: "Criminal Law (Public Law)", completed: 93, inProgress: 42, notStarted: 15, total: 150 }
    },
    progressByType: {
      audio: { label: "Audio", icon: "🎧", completed: 336, total: 560, color: "#9333ea" },
      video: { label: "Video", icon: "▶️", completed: 192, total: 480, color: "#ef4444" },
      reels: { label: "Reels", icon: "🎬", completed: 96, total: 320, color: "#ec4899" },
      pdf: { label: "PDF", icon: "📄", completed: 280, total: 560, color: "#3b82f6" },
      handwriting: { label: "Handwritten Notes", icon: "✍️", completed: 140, total: 400, color: "#eab308" },
      mindmap: { label: "Mind Map", icon: "🕸️", completed: 144, total: 320, color: "#10b981" },
      slides: { label: "Legal Slides", icon: "🖼️", completed: 72, total: 160, color: "#06b6d4" }
    },

    // Referral 3-Tab State (PDF 3 Pages 22–23)
    referralTab: "invite", // invite | progress | activity
    referralActivityFilter: "all", // all | referral | share
    referralCouponInput: "",
    enteredReferCode: "REF12345",
    referralUsersCount: 3,
    referralSharesCount: 20,
    freeDaysEarned: 42,

    // Settings State (PDF 3 Page 17)
    settingsDaily10Reminder: true,
    settingsDaily10Time: "08:00 PM",
    settingsMockReminder: true,
    settingsMockTime: "07:00 PM",
    settingsFingerprint: false,
    settingsLanguage: "Hindi / English",

    // Folders, Saved, History, Notifications, Topic Requests
    folders: [
      { id: "f1", name: "BNS 2023 Exam Revision", itemsCount: 4, updated: "Today" },
      { id: "f2", name: "FIR & Bail Court Judgments", itemsCount: 3, updated: "Yesterday" },
      { id: "f3", name: "Judiciary & AIBE Important Notes", itemsCount: 5, updated: "2 days ago" }
    ],
    savedItems: [
      { id: "sv1", type: "Audio", title: "BNS धारा 1: संक्षिप्त नाम और लागू होना", refScreen: "audio_player" },
      { id: "sv2", type: "Slides", title: "धारा 13: पूर्व दोषसिद्धि के पश्चात् वर्धित दण्ड", refScreen: "slides_viewer" },
      { id: "sv3", type: "Public Law", title: "FIR कैसे होती है? Zero FIR प्रक्रिया", refScreen: "public_law_detail" },
      { id: "sv4", type: "Bare Act", title: "BNSS धारा 173: संज्ञेय मामलों में इत्तिला", refScreen: "bare_act_reader" }
    ],
    historyItems: [
      { id: "h1", title: "Opened BNS Section 1 Audio Lecture", time: "10 mins ago", screen: "audio_player" },
      { id: "h2", title: "Live Chat with Advocate Gulab Badshah", time: "25 mins ago", screen: "consulting" },
      { id: "h3", title: "Practiced All Mix Test – 09 (MCQ)", time: "Yesterday", screen: "mcq_test" }
    ],
    topicRequests: [
      { id: "trq1", topic: "साइबर फ्रॉड में बैंक अकाउंट अनफ्रीज करने की प्रक्रिया", category: "Cyber Law", status: "Submitted (Demo)" }
    ],
    notifications: JSON.parse(JSON.stringify(DATA.notificationsList)),
    toastMessage: null
  };

  let playerTimer = null;
  let mcqInterval = null;
  let audioCtx = null;

  function getStoredItem(key) {
    try {
      const v = localStorage.getItem(key);
      if (v !== null) return v;
    } catch (e) {}
    try {
      if (window.name && window.name.startsWith("{")) {
        const wn = JSON.parse(window.name);
        if (wn && wn[key] !== undefined) return wn[key];
      }
    } catch (e) {}
    return null;
  }

  function setStoredItem(key, val) {
    try {
      localStorage.setItem(key, val);
    } catch (e) {}
    try {
      let wn = {};
      if (window.name && window.name.startsWith("{")) {
        wn = JSON.parse(window.name) || {};
      }
      wn[key] = val;
      window.name = JSON.stringify(wn);
    } catch (e) {}
  }

  function loadPersistedState() {
    try {
      const savedTheme = getStoredItem(THEME_KEY);
      if (savedTheme === "light" || savedTheme === "dark") {
        state.theme = savedTheme;
      }
      const raw = getStoredItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (typeof parsed.isLoggedIn === "boolean") state.isLoggedIn = parsed.isLoggedIn;
        if (parsed.userAccountName) state.userAccountName = parsed.userAccountName;
        if (parsed.userPhone) state.userPhone = parsed.userPhone;
        if (parsed.activeProfileType) state.activeProfileType = parsed.activeProfileType;
        if (parsed.generalUserProfile) Object.assign(state.generalUserProfile, parsed.generalUserProfile);
        if (parsed.advocateProfile) Object.assign(state.advocateProfile, parsed.advocateProfile);
        if (parsed.studentProfile) Object.assign(state.studentProfile, parsed.studentProfile);
        if (Array.isArray(parsed.diaryCases)) state.diaryCases = parsed.diaryCases;
        if (Array.isArray(parsed.studentNotes)) state.studentNotes = parsed.studentNotes;
        if (Array.isArray(parsed.savedItems)) state.savedItems = parsed.savedItems;
        if (Array.isArray(parsed.folders)) state.folders = parsed.folders;
        if (Array.isArray(parsed.favouriteWords)) state.favouriteWords = parsed.favouriteWords;
        if (Array.isArray(parsed.favouriteActs)) state.favouriteActs = parsed.favouriteActs;
        if (Array.isArray(parsed.conversations)) state.conversations = parsed.conversations;
        if (Array.isArray(parsed.appointmentsList)) state.appointmentsList = parsed.appointmentsList;
        if (Array.isArray(parsed.advocatePanelDocs)) state.advocatePanelDocs = parsed.advocatePanelDocs;
        if (parsed.progressByAct) Object.assign(state.progressByAct, parsed.progressByAct);
        if (parsed.progressByType) Object.assign(state.progressByType, parsed.progressByType);
        if (state.isLoggedIn && parsed.currentScreen && parsed.currentScreen !== "auth") {
          state.currentScreen = parsed.currentScreen;
        } else if (!state.isLoggedIn) {
          state.currentScreen = "auth";
        }
      }
    } catch (e) {}
    applyTheme();
  }

  function savePersistedState() {
    try {
      const snapshot = {
        isLoggedIn: state.isLoggedIn,
        currentScreen: state.currentScreen,
        userAccountName: state.userAccountName,
        userPhone: state.userPhone,
        activeProfileType: state.activeProfileType,
        generalUserProfile: state.generalUserProfile,
        advocateProfile: state.advocateProfile,
        studentProfile: state.studentProfile,
        diaryCases: state.diaryCases,
        studentNotes: state.studentNotes,
        savedItems: state.savedItems,
        folders: state.folders,
        favouriteWords: state.favouriteWords,
        favouriteActs: state.favouriteActs,
        conversations: state.conversations,
        appointmentsList: state.appointmentsList,
        advocatePanelDocs: state.advocatePanelDocs,
        progressByAct: state.progressByAct,
        progressByType: state.progressByType
      };
      setStoredItem(STORAGE_KEY, JSON.stringify(snapshot));
    } catch (e) {}
  }

  function applyTheme() {
    document.documentElement.setAttribute("data-theme", state.theme);
    setStoredItem(THEME_KEY, state.theme);
  }

  function setTheme(mode) {
    state.theme = mode === "light" ? "light" : "dark";
    applyTheme();
    showToast(state.theme === "light" ? "☀️ Light Mode Activated" : "🌙 Dark Mode Activated");
    render();
  }

  function toggleTheme() {
    setTheme(state.theme === "dark" ? "light" : "dark");
  }

  function showToast(msg) {
    state.toastMessage = msg;
    renderToastOnly();
    if (window._gbToastTimer) clearTimeout(window._gbToastTimer);
    window._gbToastTimer = setTimeout(() => {
      state.toastMessage = null;
      renderToastOnly();
    }, 2800);
  }

  function renderToastOnly() {
    const el = document.getElementById("gb-toast-container");
    if (!el) return;
    if (!state.toastMessage) {
      el.innerHTML = "";
      return;
    }
    el.innerHTML = `
      <div class="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-full text-xs font-bold shadow-2xl border border-purple-400/60 bg-[#181034] text-white flex items-center gap-2 max-w-[92vw]">
        <span class="w-2 h-2 rounded-full bg-emerald-400 shrink-0"></span>
        <span class="truncate">${state.toastMessage}</span>
      </div>
    `;
  }

  function addHistoryEntry(title, screen) {
    state.historyItems.unshift({
      id: "h_" + Date.now(),
      title,
      time: "Just now",
      screen: screen || state.currentScreen
    });
    if (state.historyItems.length > 25) state.historyItems.pop();
  }

  function markContentCompleted(typeKey, actKey, label) {
    const tObj = state.progressByType[typeKey];
    if (tObj) {
      tObj.completed = Math.min(tObj.total, tObj.completed + 1);
    }
    const aObj = state.progressByAct[actKey || state.selectedActId || "bns"];
    if (aObj) {
      aObj.completed = Math.min(aObj.total, aObj.completed + 1);
    }
    addHistoryEntry(`Completed: ${label || typeKey.toUpperCase()}`, state.currentScreen);
    savePersistedState();
    showToast(`✓ Progress Updated! (${label || typeKey.toUpperCase()} Completed)`);
    render();
  }

  function speakText(text, lang = "hi-IN") {
    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        if (!audioCtx) audioCtx = new AudioContextClass();
        if (audioCtx.state === "suspended") audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(440, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(587.33, audioCtx.currentTime + 0.14);
        gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.2);
      }
      if ("speechSynthesis" in window && typeof window.SpeechSynthesisUtterance !== "undefined") {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.lang = lang;
        u.rate = state.playbackSpeed || 1.0;
        window.speechSynthesis.speak(u);
        showToast("🔊 Audio / TTS Speaking...");
      } else {
        showToast("🔊 Demo Audio Tone Played (Browser TTS not available)");
      }
    } catch (e) {
      showToast("🔊 Demo Audio Playback Active");
    }
  }

  function stopAudio() {
    state.isPlaying = false;
    if (playerTimer) {
      clearInterval(playerTimer);
      playerTimer = null;
    }
    if ("speechSynthesis" in window) {
      try { window.speechSynthesis.cancel(); } catch (e) {}
    }
  }

  function navigateTo(screen, opts = {}) {
    if (opts.actId) state.selectedActId = opts.actId;
    if (opts.mediaTab) state.selectedMediaTab = opts.mediaTab;
    if (opts.chapterId) state.selectedChapterId = opts.chapterId;
    if (opts.sectionId) state.selectedSectionId = opts.sectionId;
    if (opts.publicTopicId) state.selectedPublicTopicId = opts.publicTopicId;
    if (opts.publicLawMediaTab) state.publicLawMediaTab = opts.publicLawMediaTab;
    if (opts.authStep) state.authStep = opts.authStep;
    if (opts.directoryTab) state.directoryTab = opts.directoryTab;
    if (opts.viewingProfileId) state.viewingProfileId = opts.viewingProfileId;
    if (opts.viewingProfileTab) state.viewingProfileTab = opts.viewingProfileTab;
    if (opts.activeProfileType) state.activeProfileType = opts.activeProfileType;
    if (opts.selectedWordId) state.selectedWordId = opts.selectedWordId;
    if (opts.consultingView) state.consultingView = opts.consultingView;
    if (opts.activeConversationId) state.activeConversationId = opts.activeConversationId;
    if (opts.reelsCategory) state.reelsCategory = opts.reelsCategory;
    if (opts.progressTab) state.progressTab = opts.progressTab;
    if (opts.mcqScreenView) state.mcqScreenView = opts.mcqScreenView;
    if (opts.appointmentStep) state.appointmentStep = opts.appointmentStep;
    if (opts.docServiceStep) state.docServiceStep = opts.docServiceStep;

    if (state.currentScreen !== screen) {
      state.historyStack.push({
        screen: state.currentScreen,
        actId: state.selectedActId,
        mediaTab: state.selectedMediaTab,
        chapterId: state.selectedChapterId,
        sectionId: state.selectedSectionId,
        publicTopicId: state.selectedPublicTopicId,
        consultingView: state.consultingView,
        mcqScreenView: state.mcqScreenView
      });
    }
    state.currentScreen = screen;
    if (screen !== "video_player") state.videoLandscape = false;
    savePersistedState();
    window.scrollTo({ top: 0, behavior: "smooth" });
    render();
  }

  function goBack() {
    if (state.upgradeModalOpen) {
      state.upgradeModalOpen = false;
      render();
      return;
    }
    if (state.shabdawaliFilterModalOpen) {
      state.shabdawaliFilterModalOpen = false;
      render();
      return;
    }
    if (state.reelsSectionModalOpen) {
      state.reelsSectionModalOpen = false;
      render();
      return;
    }
    if (state.videoLandscape) {
      state.videoLandscape = false;
      render();
      return;
    }
    if (state.currentScreen === "consulting" && state.consultingView === "chat") {
      state.consultingView = "list";
      state.selectedChatMsgIds = [];
      render();
      return;
    }
    if (state.currentScreen === "mcq_test" && state.mcqScreenView !== "hub") {
      state.mcqScreenView = "hub";
      render();
      return;
    }
    if (state.historyStack.length > 0) {
      const prev = state.historyStack.pop();
      state.currentScreen = prev.screen;
      state.selectedActId = prev.actId;
      state.selectedMediaTab = prev.mediaTab;
      state.selectedChapterId = prev.chapterId;
      state.selectedSectionId = prev.sectionId;
      state.selectedPublicTopicId = prev.publicTopicId;
      if (prev.consultingView) state.consultingView = prev.consultingView;
      if (prev.mcqScreenView) state.mcqScreenView = prev.mcqScreenView;
      savePersistedState();
      render();
    } else if (state.isLoggedIn && state.currentScreen !== "home") {
      state.currentScreen = "home";
      savePersistedState();
      render();
    } else if (!state.isLoggedIn) {
      state.currentScreen = "auth";
      render();
    } else {
      showToast("आप Home Screen पर हैं");
    }
  }

  function getAllActsMap() {
    const map = Object.assign({}, DATA.acts);
    DATA.additionalBareActs.forEach((a) => {
      map[a.id] = a;
    });
    return map;
  }

  function getCurrentActObj() {
    const all = getAllActsMap();
    return all[state.selectedActId] || DATA.acts.bns;
  }

  function getCurrentChapterObj() {
    const act = getCurrentActObj();
    return act.chapters.find((c) => c.id === state.selectedChapterId) || act.chapters[0];
  }

  function getCurrentSectionObj() {
    const act = getCurrentActObj();
    for (const ch of act.chapters) {
      const found = ch.sections.find((s) => s.id === state.selectedSectionId);
      if (found) return found;
    }
    return act.chapters[0].sections[0];
  }

  function getCurrentPublicTopicObj() {
    return DATA.publicLawTopics.find((t) => t.id === state.selectedPublicTopicId) || DATA.publicLawTopics[0];
  }

  function openCategoryMedia(mediaTab, sectionId) {
    if (mediaTab) state.selectedMediaTab = mediaTab;
    if (sectionId) state.selectedSectionId = sectionId;
    const sec = getCurrentSectionObj();
    addHistoryEntry(`Viewed ${state.selectedMediaTab.toUpperCase()}: ${sec ? sec.code : "Legal Content"}`, state.currentScreen);
    if (state.selectedMediaTab === "audio") navigateTo("audio_player");
    else if (state.selectedMediaTab === "video") navigateTo("video_player");
    else if (state.selectedMediaTab === "pdf") navigateTo("pdf_viewer");
    else if (state.selectedMediaTab === "mindmap") navigateTo("mindmap_viewer");
    else if (state.selectedMediaTab === "slides") navigateTo("slides_viewer");
    else if (state.selectedMediaTab === "handwriting") navigateTo("handwriting_viewer");
    else navigateTo("audio_player");
  }

  function startMcqTimer() {
    if (mcqInterval) clearInterval(mcqInterval);
    if (state.mcqTimerMinutes === 0) return;
    mcqInterval = setInterval(() => {
      if (state.currentScreen === "mcq_test" && state.mcqScreenView === "active_test") {
        if (state.mcqTimerSec > 0) {
          state.mcqTimerSec--;
          const el = document.getElementById("mcq-timer-display");
          if (el) {
            const m = String(Math.floor(state.mcqTimerSec / 60)).padStart(2, "0");
            const s = String(state.mcqTimerSec % 60).padStart(2, "0");
            el.textContent = `00:${m}:${s}`;
          }
        } else {
          clearInterval(mcqInterval);
          state.mcqScreenView = "times_up";
          showToast("⏰ Time's Up! Test Auto-Submitted.");
          render();
        }
      }
    }, 1000);
  }

  function getFilteredMcqQuestions() {
    let list = DATA.mcqTestBank.filter((q) => {
      const matchAct = state.mcqFilterAct === "All" || q.act === state.mcqFilterAct;
      return matchAct;
    });
    if (list.length === 0) list = DATA.mcqTestBank;
    return list;
  }

  function handleFileSelection(inputEl, targetType) {
    if (!inputEl || !inputEl.files || inputEl.files.length === 0) {
      showToast("कोई फ़ाइल नहीं चुनी गई (No file selected)");
      return;
    }
    const file = inputEl.files[0];
    const fileName = `${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
    const isImage = file.type.startsWith("image/");

    if (isImage && typeof FileReader !== "undefined") {
      const reader = new FileReader();
      reader.onload = function (ev) {
        const dataUrl = ev.target.result;
        if (targetType === "gen_photo") {
          state.generalUserProfile.photoDataUrl = dataUrl;
          showToast(`✓ Profile Photo Updated: ${file.name}`);
        } else if (targetType === "adv_photo") {
          state.advocateProfile.photoDataUrl = dataUrl;
          showToast(`✓ Advocate Photo Updated: ${file.name}`);
        } else if (targetType === "stu_photo") {
          state.studentProfile.photoDataUrl = dataUrl;
          showToast(`✓ Student Photo Updated: ${file.name}`);
        } else if (targetType === "chat_file") {
          sendChatAttachment(file.name, "Image", `${(file.size / 1024).toFixed(1)} KB`);
          return;
        } else if (targetType === "support_img") {
          state.supportScreenshotName = fileName;
          state.supportMessages.push({ sender: "me", text: `📷 Uploaded Screenshot: ${fileName}`, time: "Just now" });
          state.supportMessages.push({ sender: "bot", text: "Thanks! Ham aapki problem check kar rahe hain. Agar problem solve nahi hoti hai to aap নিচে 'Talk to Support' par click karke human support se baat kar sakte hain.", time: "Just now" });
          showToast(`✓ Screenshot Uploaded: ${file.name}`);
        } else if (targetType === "apt_photo") {
          state.appointmentForm.photoFileName = fileName;
          showToast(`✓ Photo Attached: ${file.name}`);
        } else if (targetType === "doc_photo") {
          state.docRequestForm.photoFileName = fileName;
          showToast(`✓ Photo Attached: ${file.name}`);
        }
        savePersistedState();
        render();
      };
      reader.readAsDataURL(file);
    } else {
      if (targetType === "adv_bar_id") state.advocateProfile.barIdFileName = fileName;
      else if (targetType === "stu_resume") state.studentProfile.resumeFileName = fileName;
      else if (targetType === "stu_id") state.studentProfile.collegeIdFileName = fileName;
      else if (targetType === "apt_pdf") state.appointmentForm.pdfFileName = fileName;
      else if (targetType === "doc_pdf") state.docRequestForm.pdfFileName = fileName;
      else if (targetType === "chat_file") {
        sendChatAttachment(file.name, "PDF", `${(file.size / 1024).toFixed(1)} KB`);
        return;
      }
      savePersistedState();
      showToast(`✓ File Attached (Demo): ${file.name}`);
      render();
    }
  }

  function sendChatAttachment(fileName, fileType, fileSize) {
    const conv = state.conversations.find((c) => c.id === state.activeConversationId) || state.conversations[0];
    conv.messages.push({
      id: "m_" + Date.now(),
      sender: "me",
      text: fileName,
      isFile: true,
      fileType: fileType || "PDF",
      fileSize: fileSize || "1.4 MB",
      time: "Just now",
      status: "read"
    });
    savePersistedState();
    showToast(`📎 Sent ${fileName} in Demo Chat`);
    render();
  }
  // Expose Global Controller for all UI handlers
  window.GBApp = {
    navigateTo,
    goBack,
    setTheme,
    toggleTheme,
    showToast,
    openCategoryMedia,
    markContentCompleted,
    handleFileSelection,

    toggleFullscreenApp: () => {
      try {
        if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
          document.documentElement.requestFullscreen();
          state.fullscreenMode = true;
          showToast("📲 Fullscreen Mobile App Mode Activated!");
        } else if (document.exitFullscreen && document.fullscreenElement) {
          document.exitFullscreen();
          state.fullscreenMode = false;
          showToast("Exited Fullscreen Mode");
        } else {
          showToast("📲 Tip: Use Chrome Menu -> 'Add to Home screen' for Fullscreen App Mode!");
        }
      } catch (e) {
        showToast("📲 Use Chrome Menu -> 'Add to Home screen' to install!");
      }
      render();
    },

    // 1. Common Login Flow Actions (NO role selector at login! One common login for everyone)
    setAuthStep: (step) => {
      state.authStep = step;
      state.authError = "";
      render();
    },
    requestDemoOtp: () => {
      const mobEl = document.getElementById("login-mobile-input");
      const val = mobEl ? mobEl.value.replace(/\D/g, "") : state.mobileInput;
      if (val.length !== 10) {
        state.authError = "कृपया 10 अंकों का वैध मोबाइल नंबर दर्ज करें (Enter a valid 10-digit mobile number).";
        render();
        return;
      }
      state.mobileInput = val;
      state.userPhone = val;
      state.otpInput = "123456";
      state.authError = "";
      state.authStep = "otp";
      showToast("Demo Mode: कोई वास्तविक SMS नहीं भेजा गया। Demo OTP: 123456");
      render();
    },
    verifyDemoOtp: () => {
      const otpEl = document.getElementById("login-otp-input");
      const entered = otpEl ? otpEl.value.trim() : state.otpInput;
      if (entered !== "123456") {
        state.authError = "गलत OTP! यह फ्रंटएंड डेमो है, कृपया Demo OTP '123456' दर्ज करें।";
        render();
        return;
      }
      state.authError = "";
      state.authStep = "terms";
      render();
    },
    completeCommonLogin: () => {
      if (!state.termsAccepted || !state.privacyAccepted) {
        state.authError = "आगे बढ़ने के लिए कृपया Terms & Conditions और Privacy Policy दोनों स्वीकार करें।";
        render();
        return;
      }
      state.isLoggedIn = true;
      state.authError = "";
      state.currentScreen = "home";
      state.historyStack = [];
      savePersistedState();
      showToast("Common Demo Login Successful! Welcome to GB Legal Mind 🎉");
      render();
    },
    quickDemoLogin: () => {
      state.isLoggedIn = true;
      state.authError = "";
      state.currentScreen = "home";
      state.historyStack = [];
      savePersistedState();
      showToast("Common Demo Session Started! Opening Home Screen 🚀");
      render();
    },
    toggleTermsCheck: (field) => {
      state[field] = !state[field];
      render();
    },
    logout: (allDevices) => {
      stopAudio();
      state.isLoggedIn = false;
      state.currentScreen = "auth";
      state.authStep = "welcome";
      state.historyStack = [];
      savePersistedState();
      showToast(allDevices ? "🔒 Logged Out from All Devices — Returned to Common Login" : "🔒 Logged Out — Returned to Common Login Screen");
      render();
    },

    // Home & Banner Actions
    setBanner: (idx) => {
      state.bannerIndex = idx;
      render();
    },
    selectActTab: (tabId) => {
      state.selectedMediaTab = tabId;
      render();
    },
    selectPublicLawTab: (tabId) => {
      state.publicLawMediaTab = tabId;
      render();
    },

    // Bare Act Library & Dual Format Reader Actions
    setLibrarySearch: (val) => {
      state.librarySearch = val;
      render();
    },
    setLibraryCategory: (cat) => {
      state.libraryCategory = cat;
      render();
    },
    toggleFavouriteAct: (actId, ev) => {
      if (ev) ev.stopPropagation();
      const idx = state.favouriteActs.indexOf(actId);
      if (idx >= 0) {
        state.favouriteActs.splice(idx, 1);
        showToast("Removed from Favourite Acts");
      } else {
        state.favouriteActs.push(actId);
        showToast("⭐ Added to Favourite Acts");
      }
      savePersistedState();
      render();
    },
    openBareActDetail: (actId) => {
      state.selectedActId = actId;
      const act = getAllActsMap()[actId];
      if (act && act.chapters && act.chapters[0]) {
        state.selectedChapterId = act.chapters[0].id;
        if (act.chapters[0].sections && act.chapters[0].sections[0]) {
          state.selectedSectionId = act.chapters[0].sections[0].id;
        }
      }
      navigateTo("bare_act_chapters");
    },
    openBareActSectionList: (actId, chapterId) => {
      if (actId) state.selectedActId = actId;
      if (chapterId) state.selectedChapterId = chapterId;
      navigateTo("bare_act_sections");
    },
    openBareActReader: (actId, chapterId, sectionId) => {
      if (actId) state.selectedActId = actId;
      if (chapterId) state.selectedChapterId = chapterId;
      if (sectionId) state.selectedSectionId = sectionId;
      if (!state.readSections.includes(state.selectedSectionId)) {
        state.readSections.push(state.selectedSectionId);
      }
      addHistoryEntry(`Read Bare Act: ${state.selectedSectionId.toUpperCase()}`, "bare_act_reader");
      savePersistedState();
      navigateTo("bare_act_reader");
    },
    setBareActFormat: (mode) => {
      state.bareActFormatMode = mode;
      render();
    },
    setBareActLang: (lang) => {
      state.bareActLang = lang;
      render();
    },
    copyBareActSection: () => {
      const sec = getCurrentSectionObj();
      const txt = `${sec.code}: ${sec.titleHindi}\n${sec.bareActTextHindi || sec.summaryHindi}`;
      try { navigator.clipboard.writeText(txt); } catch (e) {}
      showToast("📋 Section Text Copied to Clipboard!");
    },
    speakBareActSection: () => {
      const sec = getCurrentSectionObj();
      const txt = state.bareActLang === "en"
        ? `${sec.code}. ${sec.title}. ${sec.saralTextEnglish || sec.bareActTextEnglish}`
        : `${sec.code}. ${sec.titleHindi}. ${sec.saralTextHindi || sec.bareActTextHindi}`;
      speakText(txt, state.bareActLang === "en" ? "en-IN" : "hi-IN");
    },
    toggleBookmarkSection: (secId) => {
      const idx = state.bookmarkedSections.indexOf(secId);
      if (idx >= 0) {
        state.bookmarkedSections.splice(idx, 1);
        showToast("Section Bookmark Removed");
      } else {
        state.bookmarkedSections.push(secId);
        const sec = getCurrentSectionObj();
        state.savedItems.unshift({
          id: "sv_" + Date.now(),
          type: "Bare Act",
          title: sec ? `${sec.code}: ${sec.titleHindi}` : secId,
          refScreen: "bare_act_reader"
        });
        showToast("🔖 Section Bookmarked & Saved!");
      }
      savePersistedState();
      render();
    },
    adjustReaderFont: (delta) => {
      state.readerFontSize = Math.max(12, Math.min(20, state.readerFontSize + delta));
      render();
    },
    navigateAdjacentSection: (dir) => {
      const act = getCurrentActObj();
      const allSecs = [];
      act.chapters.forEach((ch) => {
        ch.sections.forEach((s) => allSecs.push({ chId: ch.id, secId: s.id }));
      });
      const curIdx = allSecs.findIndex((x) => x.secId === state.selectedSectionId);
      const nextIdx = (curIdx + dir + allSecs.length) % allSecs.length;
      state.selectedChapterId = allSecs[nextIdx].chId;
      state.selectedSectionId = allSecs[nextIdx].secId;
      if (!state.readSections.includes(state.selectedSectionId)) {
        state.readSections.push(state.selectedSectionId);
      }
      savePersistedState();
      render();
    },

    // Shabdawali, Kanooni Line, Daily 10 Words & Audio Learning Actions
    setShabdawaliSearch: (val) => {
      state.shabdawaliQuery = val;
      render();
    },
    openShabdawaliCategoryList: (catId) => {
      state.shabdawaliCategory = catId;
      state.shabdawaliSavedOnly = false;
      navigateTo("shabdawali_list");
    },
    setShabdawaliRange: (rng) => {
      state.shabdawaliRange = rng;
      render();
    },
    setShabdawaliViewMode: (mode) => {
      state.shabdawaliViewMode = mode;
      render();
    },
    toggleShabdawaliFilterModal: (open) => {
      state.shabdawaliFilterModalOpen = open !== undefined ? open : !state.shabdawaliFilterModalOpen;
      render();
    },
    setShabdawaliSort: (ord) => {
      state.shabdawaliSortOrder = ord;
      render();
    },
    setShabdawaliLetter: (ltr) => {
      state.shabdawaliLetterFilter = state.shabdawaliLetterFilter === ltr ? "ALL" : ltr;
      render();
    },
    toggleShabdawaliNewOnly: () => {
      state.shabdawaliNewOnly = !state.shabdawaliNewOnly;
      render();
    },
    resetShabdawaliFilters: () => {
      state.shabdawaliSortOrder = "num_asc";
      state.shabdawaliLetterFilter = "ALL";
      state.shabdawaliNewOnly = false;
      state.shabdawaliFilterModalOpen = false;
      showToast("🔄 Filters Reset to Default Order");
      render();
    },
    openWordDetail: (wordId) => {
      state.selectedWordId = wordId;
      navigateTo("shabdawali_detail");
    },
    navigateAdjacentWord: (dir) => {
      const idx = DATA.shabdawali.findIndex((w) => w.id === state.selectedWordId);
      const nextIdx = (idx + dir + DATA.shabdawali.length) % DATA.shabdawali.length;
      state.selectedWordId = DATA.shabdawali[nextIdx].id;
      render();
    },
    toggleFavouriteWord: (wordId, ev) => {
      if (ev) ev.stopPropagation();
      const idx = state.favouriteWords.indexOf(wordId);
      if (idx >= 0) {
        state.favouriteWords.splice(idx, 1);
        showToast("Removed from Favourite Words");
      } else {
        state.favouriteWords.push(wordId);
        showToast("❤️ Saved to Favourite Words!");
      }
      savePersistedState();
      render();
    },
    speakWord: (wordId) => {
      const w = DATA.shabdawali.find((x) => x.id === wordId) || DATA.shabdawali[0];
      speakText(`${w.term}. ${w.hindiShort}. अर्थ: ${w.meaning}. उपयोग: ${w.example}`);
    },
    speakCustomText: (txt) => {
      speakText(txt);
    },
    stopSpeech: () => {
      stopAudio();
      showToast("⏹ Audio Playback Stopped");
      render();
    },
    markDailyWordLearned: (wordId) => {
      if (!state.daily10LearnedIds.includes(wordId)) {
        state.daily10LearnedIds.push(wordId);
        markContentCompleted("audio", "bns", "Daily Shabdawali Word");
      } else {
        state.selectedWordId = wordId;
        navigateTo("shabdawali_detail");
        return;
      }
      render();
    },
    completeAllDaily10Words: () => {
      state.daily10LearnedIds = DATA.shabdawali.slice(0, 10).map((w) => w.id);
      showToast("🏆 बधाई हो! आज के 10 शब्द का लक्ष्य (10/10) पूरा हुआ!");
      render();
    },
    setAudioLearningTab: (tab) => {
      state.audioLearningTab = tab;
      render();
    },
    setAudioRangePreset: (from, to) => {
      state.audioRangeFrom = from;
      state.audioRangeTo = to;
      state.audioSelectedWordIds = DATA.shabdawali.map((w) => w.id);
      showToast(`✓ Selected Words Range: ${from} to ${to}`);
      render();
    },
    toggleManualAudioWord: (wordId) => {
      const idx = state.audioSelectedWordIds.indexOf(wordId);
      if (idx >= 0) state.audioSelectedWordIds.splice(idx, 1);
      else state.audioSelectedWordIds.push(wordId);
      render();
    },
    selectAllAudioWords: () => {
      if (state.audioSelectedWordIds.length === DATA.shabdawali.length) {
        state.audioSelectedWordIds = [];
      } else {
        state.audioSelectedWordIds = DATA.shabdawali.map((w) => w.id);
      }
      render();
    },
    openAudioLearningPlayer: (wordIdx) => {
      if (wordIdx !== undefined) state.activeAudioWordIdx = wordIdx;
      state.isPlaying = true;
      const w = DATA.shabdawali[state.activeAudioWordIdx % DATA.shabdawali.length];
      speakText(`${w.term}. ${w.hindiShort}. अर्थ: ${w.meaning}. उदाहरण: ${w.example}`);
      navigateTo("audio_learning_player");
    },
    stepAudioLearningWord: (dir) => {
      const len = DATA.shabdawali.length;
      state.activeAudioWordIdx = (state.activeAudioWordIdx + dir + len) % len;
      const w = DATA.shabdawali[state.activeAudioWordIdx];
      if (state.autoPlayAudio) {
        speakText(`${w.term}. ${w.hindiShort}. अर्थ: ${w.meaning}`);
      }
      render();
    },
    toggleAutoPlayAudio: () => {
      state.autoPlayAudio = !state.autoPlayAudio;
      showToast(`Auto Play: ${state.autoPlayAudio ? "ON" : "OFF"}`);
      render();
    },
    toggleAudioPlaylistDrawer: () => {
      state.audioPlaylistDrawerOpen = !state.audioPlaylistDrawerOpen;
      render();
    },

    // Media Player Controls
    togglePlay: () => {
      state.isPlaying = !state.isPlaying;
      if (state.isPlaying) {
        const sec = getCurrentSectionObj();
        speakText(sec ? `${sec.titleHindi}. ${sec.summaryHindi}` : "जीबी लीगल माइंड ऑडियो लेक्चर चालू है।");
      } else {
        stopAudio();
      }
      render();
    },
    seekRelative: (delta) => {
      state.currentTimeSec = Math.max(0, Math.min(state.totalTimeSec, state.currentTimeSec + delta));
      showToast(delta > 0 ? `⏩ +${delta} sec` : `⏪ ${delta} sec`);
      render();
    },
    cycleSpeed: () => {
      const speeds = [0.75, 1.0, 1.25, 1.5, 2.0];
      state.playbackSpeed = speeds[(speeds.indexOf(state.playbackSpeed) + 1) % speeds.length];
      showToast(`⚡ Speed: ${state.playbackSpeed}x`);
      render();
    },
    cycleSleepTimer: () => {
      const timers = [0, 15, 30, 60];
      state.sleepTimerMin = timers[(timers.indexOf(state.sleepTimerMin) + 1) % timers.length];
      showToast(state.sleepTimerMin ? `🌙 Sleep Timer: ${state.sleepTimerMin}:00` : "Sleep Timer Off");
      render();
    },
    toggleVideoLandscape: () => {
      state.videoLandscape = !state.videoLandscape;
      render();
    },
    changeSlide: (delta) => {
      const len = DATA.slidesDeck.length;
      state.slideIndex = (state.slideIndex + delta + len) % len;
      render();
    },
    selectSlide: (idx) => {
      state.slideIndex = idx;
      state.slideDrawerOpen = false;
      render();
    },
    toggleSlideDrawer: () => {
      state.slideDrawerOpen = !state.slideDrawerOpen;
      render();
    },
    changePdfPage: (delta) => {
      const len = DATA.pdfQuizPages.length;
      state.pdfPageIndex = (state.pdfPageIndex + delta + len) % len;
      render();
    },
    togglePdfDrawer: () => {
      state.pdfDrawerOpen = !state.pdfDrawerOpen;
      render();
    },
    answerPdfQuestion: (qId, optIdx) => {
      state.pdfAnswers[qId] = optIdx;
      render();
    },
    zoomMindMap: (delta) => {
      state.mindMapZoom = Math.max(0.75, Math.min(1.5, +(state.mindMapZoom + delta).toFixed(2)));
      render();
    },
    selectMindMapNode: (nodeId) => {
      state.mindMapSelectedNode = nodeId;
      render();
    },
    setHwPage: (idx) => {
      state.hwPageIndex = idx;
      render();
    },
    toggleHwHighlight: () => {
      state.hwHighlight = !state.hwHighlight;
      render();
    }
  };
  Object.assign(window.GBApp, {
    // MCQ & Mock Tests Complete Actions
    setMcqView: (view, actTitle) => {
      if (actTitle) state.mcqSelectedActTitle = actTitle;
      state.mcqScreenView = view;
      render();
    },
    selectMcqLevel: (lvl) => {
      state.mcqFilterLevel = lvl;
      state.mcqScreenView = "set_list";
      render();
    },
    setMcqConfig: (field, val) => {
      state[field] = val;
      render();
    },
    startMcqTest: () => {
      state.mcqAnswers = {};
      state.mcqReviewMarked = {};
      state.mcqCurrentIdx = 0;
      state.mcqShowHint = false;
      state.mcqShowExplanation = state.mcqMode === "Practice";
      state.mcqTimerSec = (state.mcqTimerMinutes || 30) * 60;
      state.mcqScreenView = "active_test";
      startMcqTimer();
      render();
    },
    selectMcqOption: (qId, optIdx) => {
      state.mcqAnswers[qId] = optIdx;
      render();
    },
    jumpMcqQuestion: (idx) => {
      state.mcqCurrentIdx = idx;
      state.mcqShowHint = false;
      render();
    },
    toggleMcqHint: () => {
      state.mcqShowHint = !state.mcqShowHint;
      render();
    },
    toggleMcqExplanation: () => {
      state.mcqShowExplanation = !state.mcqShowExplanation;
      render();
    },
    toggleMcqReviewMark: (qId) => {
      state.mcqReviewMarked[qId] = !state.mcqReviewMarked[qId];
      showToast(state.mcqReviewMarked[qId] ? "🔖 Marked for Review Later" : "Review Mark Removed");
      render();
    },
    toggleSaveMcqQuestion: (qId) => {
      const idx = state.mcqSavedQuestions.indexOf(qId);
      if (idx >= 0) {
        state.mcqSavedQuestions.splice(idx, 1);
        showToast("Removed from Saved Questions");
      } else {
        state.mcqSavedQuestions.push(qId);
        showToast("🔖 Question Saved to Bookmarks!");
      }
      render();
    },
    triggerTimesUpScreen: () => {
      if (mcqInterval) clearInterval(mcqInterval);
      state.mcqTimerSec = 0;
      state.mcqScreenView = "times_up";
      render();
    },
    openMcqSubmitConfirm: () => {
      state.mcqScreenView = "confirm_submit";
      render();
    },
    confirmMcqSubmit: () => {
      if (mcqInterval) clearInterval(mcqInterval);
      const qs = getFilteredMcqQuestions();
      let correct = 0;
      qs.forEach((q) => {
        if (state.mcqAnswers[q.id] === q.correctIndex) correct++;
      });
      const pct = Math.round((correct / qs.length) * 100);
      state.mcqSavedTests.unshift({
        id: "st_" + Date.now(),
        title: `${state.mcqSelectedActTitle} (${state.mcqFilterLevel})`,
        date: `Today • ${state.mcqTimerMinutes || 30} Min`,
        score: `${correct}/${qs.length} (${pct}%)`,
        pct,
        status: "Completed"
      });
      markContentCompleted("pdf", "bns", `MCQ Test (${correct}/${qs.length})`);
      state.mcqScreenView = "results";
      render();
    },
    setMcqRightWrongTab: (tab) => {
      state.mcqRightWrongTab = tab;
      render();
    },
    setMcqMyTestsTab: (tab) => {
      state.mcqMyTestsTab = tab;
      render();
    },
    setMcqSavedTab: (tab) => {
      state.mcqSavedTab = tab;
      render();
    },

    // Profile System (General User, Advocate, Law Student) & Upgrade Plan
    toggleUpgradeModal: (open) => {
      state.upgradeModalOpen = open !== undefined ? open : !state.upgradeModalOpen;
      render();
    },
    selectUpgradePlan: (planId) => {
      state.selectedUpgradePlan = planId;
      render();
    },
    activateDemoPlan: () => {
      state.upgradeModalOpen = false;
      showToast("👑 Demo Plan Selected! (No real payment charged in Frontend Phase)");
      render();
    },
    openProfileCreator: (type) => {
      state.activeProfileType = type;
      if (type === "General") navigateTo("update_general_profile");
      else if (type === "Student") navigateTo("create_student_profile");
      else navigateTo("create_advocate_profile");
    },
    saveGeneralUserProfile: () => {
      const name = document.getElementById("gen-name")?.value.trim();
      const phone = document.getElementById("gen-phone")?.value.trim();
      const email = document.getElementById("gen-email")?.value.trim();
      if (!name || !phone) {
        showToast("⚠️ कृपया नाम और मोबाइल नंबर अवश्य भरें!");
        return;
      }
      state.generalUserProfile.fullName = name;
      state.generalUserProfile.phone = phone;
      if (email) state.generalUserProfile.email = email;
      state.generalUserProfile.state = document.getElementById("gen-state")?.value || state.generalUserProfile.state;
      state.generalUserProfile.district = document.getElementById("gen-district")?.value.trim() || state.generalUserProfile.district;
      state.generalUserProfile.address = document.getElementById("gen-address")?.value.trim() || state.generalUserProfile.address;
      state.generalUserProfile.city = document.getElementById("gen-city")?.value.trim() || state.generalUserProfile.city;
      state.generalUserProfile.pincode = document.getElementById("gen-pincode")?.value.trim() || state.generalUserProfile.pincode;
      state.generalUserProfile.dob = document.getElementById("gen-dob")?.value || state.generalUserProfile.dob;
      state.generalUserProfile.gender = document.getElementById("gen-gender")?.value || state.generalUserProfile.gender;
      state.generalUserProfile.userCategory = document.getElementById("gen-cat")?.value || state.generalUserProfile.userCategory;
      state.generalUserProfile.profCourse = document.getElementById("gen-course")?.value || state.generalUserProfile.profCourse;
      state.generalUserProfile.college = document.getElementById("gen-college")?.value.trim() || state.generalUserProfile.college;

      state.userAccountName = name;
      state.userPhone = phone;
      state.activeProfileType = "General";
      savePersistedState();
      showToast("✅ General User Profile Saved (Demo)!");
      navigateTo("profile");
    },
    toggleArrayItem: (profileKey, field, value) => {
      const arr = state[profileKey][field];
      const idx = arr.indexOf(value);
      if (idx >= 0) arr.splice(idx, 1);
      else arr.push(value);
      render();
    },
    saveAdvocateProfileForm: () => {
      const name = document.getElementById("adv-name")?.value.trim();
      const phone = document.getElementById("adv-phone")?.value.trim();
      const barNo = document.getElementById("adv-barno")?.value.trim();
      if (!name || !phone || !barNo) {
        showToast("⚠️ कृपया नाम, मोबाइल नंबर और बार काउंसिल नंबर अवश्य भरें!");
        return;
      }
      state.advocateProfile.fullName = name;
      state.advocateProfile.phone = phone;
      state.advocateProfile.barNo = barNo;
      state.advocateProfile.fatherName = document.getElementById("adv-father")?.value.trim() || state.advocateProfile.fatherName;
      state.advocateProfile.city = document.getElementById("adv-city")?.value.trim() || state.advocateProfile.city;
      state.advocateProfile.primaryCourt = document.getElementById("adv-court")?.value || state.advocateProfile.primaryCourt;
      state.advocateProfile.experience = document.getElementById("adv-exp")?.value || state.advocateProfile.experience;
      state.advocateProfile.chamberName = document.getElementById("adv-chamber")?.value.trim() || state.advocateProfile.chamberName;
      state.advocateProfile.education = document.getElementById("adv-edu")?.value.trim() || state.advocateProfile.education;
      state.advocateProfile.bio = document.getElementById("adv-bio")?.value.trim() || state.advocateProfile.bio;

      state.activeProfileType = "Advocate";
      savePersistedState();
      showToast("✅ Advocate Profile Saved (Verification: Pending/Demo)!");
      navigateTo("view_profile_detail", { viewingProfileId: "my_adv", viewingProfileTab: "about" });
    },
    saveStudentProfileForm: () => {
      const name = document.getElementById("stu-name")?.value.trim();
      const college = document.getElementById("stu-college")?.value.trim();
      if (!name || !college) {
        showToast("⚠️ कृपया छात्र का नाम और कॉलेज का नाम अवश्य भरें!");
        return;
      }
      state.studentProfile.fullName = name;
      state.studentProfile.college = college;
      state.studentProfile.course = document.getElementById("stu-course")?.value || state.studentProfile.course;
      state.studentProfile.semester = document.getElementById("stu-sem")?.value || state.studentProfile.semester;
      state.studentProfile.passingYear = document.getElementById("stu-passyr")?.value || state.studentProfile.passingYear;
      state.studentProfile.city = document.getElementById("stu-city")?.value.trim() || state.studentProfile.city;
      state.studentProfile.achievements = document.getElementById("stu-ach")?.value.trim() || state.studentProfile.achievements;
      state.studentProfile.bio = document.getElementById("stu-bio")?.value.trim() || state.studentProfile.bio;

      state.activeProfileType = "Student";
      savePersistedState();
      showToast("✅ Law Student Profile Saved (Demo)!");
      navigateTo("view_profile_detail", { viewingProfileId: "my_stu", viewingProfileTab: "about" });
    },
    openPublicProfileView: (id, tab) => {
      state.viewingProfileId = id;
      state.viewingProfileTab = tab || "about";
      navigateTo("view_profile_detail");
    },
    setViewingProfileTab: (tab) => {
      state.viewingProfileTab = tab;
      render();
    },
    selectAdvPlanTier: (tier) => {
      state.advocateProfile.selectedPlanTier = tier;
      render();
    },
    selectStuGuidanceType: (type) => {
      state.studentProfile.guidanceType = type;
      render();
    },

    // Find My Advocate, Student, Internships, Appointments & Documents Service
    setDirectoryTab: (tab) => {
      state.directoryTab = tab;
      render();
    },
    setDirectorySearch: (val) => {
      state.directorySearch = val;
      render();
    },
    setDirectoryLocation: (loc) => {
      state.directoryLocationFilter = loc;
      showToast(`📍 Location Filter: ${loc}`);
      render();
    },
    setDirectorySpecialty: (spec) => {
      state.directorySpecialty = spec;
      render();
    },
    openInternshipConsultingDetail: (stuId) => {
      if (stuId) state.selectedInternshipStudentId = stuId;
      navigateTo("internship_consulting_detail");
    },
    openApplyInternshipScreen: (intAdvId) => {
      if (intAdvId) state.selectedInternshipAdvId = intAdvId;
      navigateTo("apply_internship_detail");
    },
    submitInternshipApplicationDemo: () => {
      showToast("✅ Demo Internship Application Sent! Profile & Resume shared locally.");
      navigateTo("find_advocate", { directoryTab: "internships_adv" });
    },

    // Appointment 3-Step Flow
    openAppointmentFlow: (advId, step) => {
      if (advId) state.selectedConsultAdvId = advId;
      state.appointmentStep = step || "form";
      navigateTo("appointment_flow");
    },
    setAppointmentMode: (mode) => {
      state.appointmentForm.mode = mode;
      render();
    },
    setAppointmentSlot: (slot) => {
      state.appointmentForm.slot = slot;
      render();
    },
    setAppointmentPriority: (p) => {
      state.appointmentForm.priorityType = p;
      render();
    },
    proceedToAppointmentReview: () => {
      const name = document.getElementById("apt-name")?.value.trim();
      const phone = document.getElementById("apt-phone")?.value.trim();
      const prob = document.getElementById("apt-problem")?.value.trim();
      if (!name || !phone || phone.replace(/\D/g, "").length < 10) {
        showToast("⚠️ कृपया पूरा नाम और 10 अंकों का मोबाइल नंबर दर्ज करें!");
        return;
      }
      state.appointmentForm.fullName = name;
      state.appointmentForm.phone = phone;
      state.appointmentForm.email = document.getElementById("apt-email")?.value.trim() || state.appointmentForm.email;
      state.appointmentForm.subject = document.getElementById("apt-subject")?.value || state.appointmentForm.subject;
      state.appointmentForm.matterType = document.getElementById("apt-matter")?.value || state.appointmentForm.matterType;
      if (prob) state.appointmentForm.problemDesc = prob;
      state.appointmentStep = "review";
      render();
    },
    confirmAndSendAppointment: () => {
      const adv = DATA.advocatesDirectory.find((a) => a.id === state.selectedConsultAdvId) || DATA.advocatesDirectory[0];
      state.appointmentsList.unshift({
        id: "apt_" + Date.now(),
        advName: adv.name,
        advRole: `${adv.role} • ${adv.city}`,
        rating: `${adv.rating} (${adv.reviewsCount} Ratings)`,
        date: state.appointmentForm.date,
        slot: state.appointmentForm.slot,
        subject: state.appointmentForm.subject,
        matter: state.appointmentForm.matterType,
        mode: state.appointmentForm.mode,
        problem: state.appointmentForm.problemDesc,
        status: "Pending"
      });
      savePersistedState();
      state.appointmentStep = "confirmed";
      showToast("✅ आपका Appointment Request (Demo) भेज दिया गया है!");
      render();
    },
    setMyAppointmentsTab: (tab) => {
      state.myAppointmentsTab = tab;
      render();
    },
    cancelDemoAppointment: (aptId) => {
      state.appointmentsList = state.appointmentsList.filter((a) => a.id !== aptId);
      savePersistedState();
      showToast("🗑️ Appointment Request Cancelled");
      render();
    },

    // Documents Banwane Ki Service 3-Step Flow + Advocate Panel
    openDocumentServiceFlow: (step) => {
      state.docServiceStep = step || "form";
      navigateTo("document_service_flow");
    },
    setDocContactMode: (mode) => {
      state.docRequestForm.contactMode = mode;
      render();
    },
    proceedToDocReview: () => {
      const name = document.getElementById("doc-name")?.value.trim();
      const phone = document.getElementById("doc-phone")?.value.trim();
      const details = document.getElementById("doc-details")?.value.trim();
      if (!name || !phone || !details) {
        showToast("⚠️ कृपया नाम, मोबाइल नंबर और दस्तावेज की आवश्यकता भरें!");
        return;
      }
      state.docRequestForm.applicantName = name;
      state.docRequestForm.applicantPhone = phone;
      state.docRequestForm.applicantEmail = document.getElementById("doc-email")?.value.trim() || state.docRequestForm.applicantEmail;
      state.docRequestForm.docCategory = document.getElementById("doc-cat")?.value || state.docRequestForm.docCategory;
      state.docRequestForm.docName = document.getElementById("doc-subname")?.value || state.docRequestForm.docName;
      state.docRequestForm.purpose = document.getElementById("doc-purpose")?.value.trim() || state.docRequestForm.purpose;
      state.docRequestForm.details = details;
      state.docServiceStep = "review";
      render();
    },
    confirmAndSendDocRequest: () => {
      state.advocatePanelDocs.unshift({
        id: "doc_req_" + Date.now(),
        clientName: state.docRequestForm.applicantName,
        clientPhone: state.docRequestForm.applicantPhone,
        clientEmail: state.docRequestForm.applicantEmail,
        docType: `${state.docRequestForm.docCategory} — ${state.docRequestForm.docName}`,
        date: "Just now",
        purpose: state.docRequestForm.purpose,
        summary: state.docRequestForm.details,
        extraNotes: `Preferred Contact: ${state.docRequestForm.contactMode}`,
        photoCount: 1,
        pdfCount: 1,
        status: "Pending"
      });
      savePersistedState();
      state.docServiceStep = "advocate_panel";
      showToast("✅ Document Service Request (Demo) Submitted!");
      render();
    },
    setMyDocsFilterTab: (tab) => {
      state.myDocsFilterTab = tab;
      render();
    },
    openAdvocateDocDetail: (docId) => {
      state.selectedDocRequestId = docId;
      state.docServiceStep = "doc_detail";
      render();
    },
    updateAdvocateDocStatus: (docId, newStatus) => {
      const item = state.advocatePanelDocs.find((d) => d.id === docId);
      if (item) item.status = newStatus;
      savePersistedState();
      showToast(`✓ Document Request Marked as ${newStatus}!`);
      render();
    },

    // 11. Consulting = LIVE CHAT Actions (PDF 3 Page 26)
    openConversationWith: (convIdOrName, role, category) => {
      let conv = state.conversations.find((c) => c.id === convIdOrName || c.participantName === convIdOrName);
      if (!conv) {
        conv = {
          id: "conv_" + Date.now(),
          participantName: convIdOrName,
          participantRole: role || "Legal Community Member",
          participantCategory: category || "Advocate",
          online: true,
          avatar: category === "Student" ? "🎓" : "⚖️",
          unreadCount: 0,
          busyNotice: `${convIdOrName} के साथ आपका लोकल डेमो चैट सेशन सक्रिय है।`,
          replyTimeText: "Usually replies within 30 mins",
          messages: [
            { id: "m_init", sender: "them", text: `नमस्ते! मैं ${convIdOrName} हूँ। आप अपना कानूनी प्रश्न या संदेश यहाँ साझा कर सकते हैं (Demo Chat)।`, time: "Just now", status: "read" }
          ]
        };
        state.conversations.unshift(conv);
      }
      conv.unreadCount = 0;
      state.activeConversationId = conv.id;
      state.consultingView = "chat";
      state.selectedChatMsgIds = [];
      navigateTo("consulting", { consultingView: "chat", activeConversationId: conv.id });
    },
    setConsultingSearch: (val) => {
      state.consultingSearch = val;
      render();
    },
    setConsultingFilter: (flt) => {
      state.consultingFilter = flt;
      render();
    },
    backToChatList: () => {
      state.consultingView = "list";
      state.selectedChatMsgIds = [];
      render();
    },
    sendLiveChatMessage: (presetText) => {
      const inp = document.getElementById("live-chat-input");
      const text = presetText || (inp ? inp.value.trim() : "");
      if (!text) return;
      const conv = state.conversations.find((c) => c.id === state.activeConversationId) || state.conversations[0];
      const nowTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      conv.messages.push({
        id: "m_" + Date.now(),
        sender: "me",
        text,
        time: nowTime,
        status: "read"
      });
      if (inp) inp.value = "";
      // Simulated local demo reply
      setTimeout(() => {
        conv.messages.push({
          id: "m_rep_" + Date.now(),
          sender: "them",
          text: `[Demo Auto-Reply from ${conv.participantName}]: आपका संदेश प्राप्त हुआ। संबंधित धाराओं और दस्तावेजों की जांच के बाद आपको विस्तृत मार्गदर्शन दिया जाएगा।`,
          time: nowTime,
          status: "read"
        });
        savePersistedState();
        render();
      }, 450);
      savePersistedState();
      render();
    },
    toggleSelectChatMessage: (msgId) => {
      const idx = state.selectedChatMsgIds.indexOf(msgId);
      if (idx >= 0) state.selectedChatMsgIds.splice(idx, 1);
      else state.selectedChatMsgIds.push(msgId);
      render();
    },
    clearChatSelection: () => {
      state.selectedChatMsgIds = [];
      render();
    },
    deleteSelectedChatMessages: () => {
      const conv = state.conversations.find((c) => c.id === state.activeConversationId) || state.conversations[0];
      const count = state.selectedChatMsgIds.length;
      conv.messages = conv.messages.filter((m) => !state.selectedChatMsgIds.includes(m.id));
      state.selectedChatMsgIds = [];
      savePersistedState();
      showToast(`🗑️ ${count} Message(s) Deleted`);
      render();
    },
    copySelectedChatMessages: () => {
      const conv = state.conversations.find((c) => c.id === state.activeConversationId) || state.conversations[0];
      const texts = conv.messages.filter((m) => state.selectedChatMsgIds.includes(m.id)).map((m) => m.text).join("\n");
      try { navigator.clipboard.writeText(texts); } catch (e) {}
      state.selectedChatMsgIds = [];
      showToast("📋 Selected Message(s) Copied!");
      render();
    },
    clearEntireConversation: () => {
      const conv = state.conversations.find((c) => c.id === state.activeConversationId) || state.conversations[0];
      conv.messages = [];
      state.selectedChatMsgIds = [];
      savePersistedState();
      showToast("🧹 Chat Cleared");
      render();
    },
    toggleChatQuickSheet: () => {
      state.chatQuickSheetOpen = !state.chatQuickSheetOpen;
      render();
    },

    // Support Chat (Auto Bot & Human Support) Actions (PDF 3 Page 27)
    selectSupportIssue: (cat) => {
      state.supportIssueCategory = cat;
      state.supportStep = "bot_chat";
      state.supportMessages = [
        { sender: "bot", text: `🙏 Namaste! Aapne '${cat}' select kiya hai. Kripya apni samasya likhein ya screenshot upload kijiye.`, time: "10:30 AM" }
      ];
      render();
    },
    sendSupportBotMsg: (preset) => {
      const inp = document.getElementById("support-chat-input");
      const txt = preset || (inp ? inp.value.trim() : "");
      if (!txt) return;
      state.supportMessages.push({ sender: "me", text: txt, time: "Just now" });
      if (inp) inp.value = "";
      if (state.supportStep === "human_joined") {
        state.supportMessages.push({
          sender: "agent",
          text: "Thank you! Humne aapका विवरण वेरिफाई कर लिया है और आपकी समस्या का समाधान (Demo) कर दिया गया है।",
          time: "Just now"
        });
      } else {
        state.supportMessages.push({
          sender: "bot",
          text: "Theek hai! Aap human support se baat kar sakte hain. Niche 'Talk to Support' button dabayein.",
          time: "Just now"
        });
      }
      render();
    },
    setSupportStep: (step) => {
      state.supportStep = step;
      if (step === "human_joined") {
        state.supportMessages.push({
          sender: "agent",
          text: "👋 Support Agent Joined: Namaste! Main aapki help ke liye yahan hoon. Aapki kya problem hai?",
          time: "Just now"
        });
      }
      render();
    },

    // Advocate Diary CRUD Actions
    setDiarySearch: (val) => {
      state.diarySearch = val;
      render();
    },
    openDiaryEditor: (caseId) => {
      state.diaryEditingId = caseId || "NEW";
      render();
    },
    closeDiaryEditor: () => {
      state.diaryEditingId = null;
      render();
    },
    saveDiaryEntry: () => {
      const caseNo = document.getElementById("diary-caseno")?.value.trim();
      const title = document.getElementById("diary-title")?.value.trim();
      const court = document.getElementById("diary-court")?.value.trim();
      const section = document.getElementById("diary-section")?.value.trim();
      const nextDate = document.getElementById("diary-date")?.value || "2026-11-10";
      const reminderTime = document.getElementById("diary-remtime")?.value || "09:30 AM";
      const stage = document.getElementById("diary-stage")?.value.trim() || "Hearing / Argument";
      const notes = document.getElementById("diary-notes")?.value.trim() || "";

      if (!title || !court) {
        showToast("⚠️ कृपया केस का नाम (Case Title) और कोर्ट का नाम अवश्य भरें!");
        return;
      }

      if (state.diaryEditingId && state.diaryEditingId !== "NEW") {
        const item = state.diaryCases.find((c) => c.id === state.diaryEditingId);
        if (item) {
          item.caseNo = caseNo || item.caseNo;
          item.title = title;
          item.court = court;
          item.section = section || item.section;
          item.nextDate = nextDate;
          item.reminderTime = reminderTime;
          item.stage = stage;
          item.notes = notes;
        }
        showToast("✓ Diary Entry Updated!");
      } else {
        state.diaryCases.unshift({
          id: "c_" + Date.now(),
          caseNo: caseNo || "Case No. " + Math.floor(100 + Math.random() * 900) + "/2026",
          title,
          court,
          section: section || "BNS / BNSS",
          nextDate,
          reminderTime,
          stage,
          client: title.split("vs")[0].trim(),
          notes
        });
        showToast("✓ New Diary Entry Saved!");
      }
      state.diaryEditingId = null;
      savePersistedState();
      render();
    },
    deleteDiaryEntry: (caseId) => {
      state.diaryCases = state.diaryCases.filter((c) => c.id !== caseId);
      savePersistedState();
      showToast("🗑️ Diary Entry Deleted");
      render();
    },
    viewDiaryEntry: (caseId) => {
      state.diaryViewingId = state.diaryViewingId === caseId ? null : caseId;
      render();
    },

    // Student Notes CRUD Actions
    setNotesSearch: (val) => {
      state.notesSearch = val;
      render();
    },
    setNotesSubjectFilter: (subj) => {
      state.notesSubjectFilter = subj;
      render();
    },
    openNoteEditor: (noteId) => {
      state.noteEditingId = noteId || "NEW";
      render();
    },
    closeNoteEditor: () => {
      state.noteEditingId = null;
      render();
    },
    saveStudentNote: () => {
      const title = document.getElementById("note-title-inp")?.value.trim();
      const subject = document.getElementById("note-subj-inp")?.value || "BNS 2023";
      const content = document.getElementById("note-content-inp")?.value.trim();
      if (!title || !content) {
        showToast("⚠️ कृपया नोट का शीर्षक (Title) और विवरण (Content) लिखें!");
        return;
      }
      if (state.noteEditingId && state.noteEditingId !== "NEW") {
        const note = state.studentNotes.find((n) => n.id === state.noteEditingId);
        if (note) {
          note.title = title;
          note.subject = subject;
          note.content = content;
          note.updated = "Updated Today";
        }
        showToast("✓ Student Note Updated!");
      } else {
        state.studentNotes.unshift({
          id: "sn_" + Date.now(),
          title,
          subject,
          updated: "Just now",
          content
        });
        showToast("✓ New Student Note Saved!");
      }
      state.noteEditingId = null;
      savePersistedState();
      render();
    },
    deleteStudentNote: (noteId) => {
      state.studentNotes = state.studentNotes.filter((n) => n.id !== noteId);
      savePersistedState();
      showToast("🗑️ Student Note Deleted");
      render();
    },

    // Reels Actions
    setReelsCategory: (cat) => {
      state.reelsCategory = cat;
      render();
    },
    nextReel: () => {
      state.currentReelIndex = (state.currentReelIndex + 1) % DATA.reelsData.bnsReels.length;
      markContentCompleted("reels", "bns", `Reel #${state.currentReelIndex + 1}`);
    },
    toggleReelsSectionModal: (open) => {
      state.reelsSectionModalOpen = open !== undefined ? open : !state.reelsSectionModalOpen;
      render();
    },
    setReelsDrawerTab: (tab) => {
      state.reelsDrawerTab = tab;
      render();
    },
    selectReelIndex: (idx) => {
      state.currentReelIndex = idx % DATA.reelsData.bnsReels.length;
      state.reelsSectionModalOpen = false;
      render();
    },

    // Progress, Referral, Folders, Topic Request & Settings
    setProgressTab: (tab) => {
      state.progressTab = tab;
      render();
    },
    setReferralTab: (tab) => {
      state.referralTab = tab;
      render();
    },
    setReferralActivityFilter: (flt) => {
      state.referralActivityFilter = flt;
      render();
    },
    copyReferralCode: () => {
      try { navigator.clipboard.writeText("REF12345"); } catch (e) {}
      showToast("📋 Referral Code 'REF12345' Copied!");
    },
    simulateReferralShare: (platform) => {
      state.referralSharesCount = Math.min(150, state.referralSharesCount + 1);
      savePersistedState();
      showToast(`📤 Shared via ${platform} (Demo)! Shares Count: ${state.referralSharesCount}/50`);
      render();
    },
    applyDemoCoupon: () => {
      showToast("🎟️ Demo Coupon Applied! (Preview Mode)");
    },
    createNewFolder: () => {
      const inp = document.getElementById("new-folder-name-inp");
      const name = inp ? inp.value.trim() : "";
      if (!name) {
        showToast("⚠️ कृपया फोल्डर का नाम लिखें!");
        return;
      }
      state.folders.unshift({ id: "f_" + Date.now(), name, itemsCount: 0, updated: "Just now" });
      if (inp) inp.value = "";
      savePersistedState();
      showToast(`📁 Folder "${name}" Created!`);
      render();
    },
    deleteFolder: (fId) => {
      state.folders = state.folders.filter((f) => f.id !== fId);
      savePersistedState();
      showToast("🗑️ Folder Deleted");
      render();
    },
    submitTopicRequest: () => {
      const tEl = document.getElementById("req-topic-title");
      const cEl = document.getElementById("req-topic-cat");
      const title = tEl ? tEl.value.trim() : "";
      if (!title) {
        showToast("⚠️ कृपया विषय (Topic) का नाम लिखें!");
        return;
      }
      state.topicRequests.unshift({
        id: "trq_" + Date.now(),
        topic: title,
        category: cEl ? cEl.value : "Public Law",
        status: "Submitted (Demo)"
      });
      if (tEl) tEl.value = "";
      showToast("✅ Topic Request Submitted!");
      render();
    },
    markAllNotificationsRead: () => {
      state.notifications.forEach((n) => (n.unread = false));
      showToast("✓ All Notifications Marked as Read");
      render();
    },
    toggleSettingSwitch: (key) => {
      state[key] = !state[key];
      showToast("⚙️ Setting Updated (Demo)");
      render();
    }
  });
  // =========================================================================
  // SCREEN RENDERERS — PART A (Top Bar, Common Login, Splash, Home, Acts, Public Law, Media Viewers)
  // =========================================================================


  // v3.0.0 Commercial Upgrade State & Controller Extensions
  state.actSectionSearch = state.actSectionSearch || "";
  state.publicLawSearch = state.publicLawSearch || "";
  state.publicLawCategoryFilter = state.publicLawCategoryFilter || "All";
  state.diaryFilterTab = state.diaryFilterTab || "All";
  state.notesViewMode = state.notesViewMode || "cards"; // cards | flashcards
  state.notesColorFilter = state.notesColorFilter || "All";
  state.activeFolderId = state.activeFolderId || null;
  state.savedFilterType = state.savedFilterType || "All";
  state.findAdvCourtFilter = state.findAdvCourtFilter || "All";
  state.findAdvExpFilter = state.findAdvExpFilter || "All";
  state.chatSearchQuery = state.chatSearchQuery || "";
  state.isRecordingVoice = false;

  // Ensure folders have rich items array
  state.folders.forEach((f, idx) => {
    if (!f.color) f.color = ["#7c3aed", "#d97706", "#059669", "#2563eb"][idx % 4];
    if (!f.icon) f.icon = ["📁", "⚖️", "🏛️", "🎓"][idx % 4];
    if (!Array.isArray(f.items)) {
      f.items = [
        { id: "fi_1_" + f.id, type: "Bare Act", title: "BNS 2023 धारा 1 एवं धारा 2 (Definitions)", screen: "bare_act_reader", added: "Today" },
        { id: "fi_2_" + f.id, type: "Audio", title: "BNSS धारा 173: FIR एवं Zero FIR ऑडियो लेक्चर", screen: "audio_player", added: "Yesterday" },
        { id: "fi_3_" + f.id, type: "Slides", title: "धारा 13: पूर्व दोषसिद्धि पर वर्धित दण्ड स्लाइड्स", screen: "slides_viewer", added: "2 days ago" }
      ];
      f.itemsCount = f.items.length;
    }
  });

  // Ensure diary cases have rich fields
  state.diaryCases.forEach((c, idx) => {
    if (!c.status) c.status = idx === 0 ? "Today" : idx === 1 ? "Upcoming" : "Upcoming";
    if (!c.clientPhone) c.clientPhone = "98765012" + (10 + idx);
    if (!c.opponent) c.opponent = c.title.includes("vs.") ? c.title.split("vs.")[1].trim() : "State / Opposite Party";
    if (c.totalFee === undefined) c.totalFee = idx === 0 ? 25000 : idx === 1 ? 18000 : 15000;
    if (c.receivedFee === undefined) c.receivedFee = idx === 0 ? 15000 : idx === 1 ? 18000 : 8000;
    if (!Array.isArray(c.history)) {
      c.history = [
        { date: "2026-09-18", order: "Vakalatnama & objection filed", nextDate: c.nextDate },
        { date: "2026-10-05", order: "Copy of FIR / documents supplied", nextDate: c.nextDate }
      ];
    }
  });

  // Ensure student notes have rich fields
  state.studentNotes.forEach((n, idx) => {
    if (n.pinned === undefined) n.pinned = idx === 0;
    if (!n.color) n.color = ["purple", "gold", "emerald"][idx % 3];
    if (!n.examTag) n.examTag = ["Judiciary Mains", "AIBE XIX", "LL.B Semester"][idx % 3];
  });

  Object.assign(window.GBApp, {
    setActSectionSearch: (val) => {
      state.actSectionSearch = val;
      render();
    },
    setPublicLawSearch: (val) => {
      state.publicLawSearch = val;
      render();
    },
    setPublicLawCategoryFilter: (cat) => {
      state.publicLawCategoryFilter = cat;
      render();
    },
    setDiaryFilterTab: (tab) => {
      state.diaryFilterTab = tab;
      render();
    },
    markDiaryCaseDisposed: (caseId) => {
      const c = state.diaryCases.find((x) => x.id === caseId);
      if (c) {
        c.status = c.status === "Disposed" ? "Upcoming" : "Disposed";
        savePersistedState();
        showToast(c.status === "Disposed" ? "✅ Case Marked as Disposed!" : "🔄 Case Re-opened as Active!");
        render();
      }
    },
    addDiaryHearingLog: (caseId) => {
      const c = state.diaryCases.find((x) => x.id === caseId);
      const nextDt = document.getElementById("diary-quick-nextdate-" + caseId)?.value || "2026-11-25";
      const orderNote = document.getElementById("diary-quick-order-" + caseId)?.value.trim() || "Arguments heard, next date fixed";
      if (c) {
        if (!Array.isArray(c.history)) c.history = [];
        c.history.unshift({ date: c.nextDate, order: orderNote, nextDate: nextDt });
        c.nextDate = nextDt;
        c.stage = orderNote;
        savePersistedState();
        showToast("📅 Next Hearing Date & Order Updated!");
        render();
      }
    },
    setNotesViewMode: (mode) => {
      state.notesViewMode = mode;
      render();
    },
    toggleNotePin: (noteId) => {
      const n = state.studentNotes.find((x) => x.id === noteId);
      if (n) {
        n.pinned = !n.pinned;
        savePersistedState();
        showToast(n.pinned ? "📌 Note Pinned to Top!" : "Pin Removed");
        render();
      }
    },
    dictateStudentNoteDemo: () => {
      const el = document.getElementById("note-content-inp");
      const sample = "\n• [Voice Dictation]: BNSS धारा 173 के अंतर्गत संज्ञेय अपराध की सूचना किसी भी थाने में Zero FIR के रूप में दर्ज की जा सकती है।";
      if (el) {
        el.value = (el.value || "") + sample;
        showToast("🎙️ Hindi Voice Dictation Added to Note!");
      }
    },
    openFolderDetail: (folderId) => {
      state.activeFolderId = folderId;
      render();
    },
    closeFolderDetail: () => {
      state.activeFolderId = null;
      render();
    },
    addCurrentItemToFolder: (folderId, type, title, screen) => {
      const f = state.folders.find((x) => x.id === folderId) || state.folders[0];
      if (!f) return;
      if (!Array.isArray(f.items)) f.items = [];
      f.items.unshift({
        id: "fi_" + Date.now(),
        type: type || "Study Item",
        title: title || "BNS / Public Law Study Note",
        screen: screen || "act_detail",
        added: "Just now"
      });
      f.itemsCount = f.items.length;
      f.updated = "Just now";
      savePersistedState();
      showToast(`📁 Added to "${f.name}"!`);
      render();
    },
    removeItemFromFolder: (folderId, itemId) => {
      const f = state.folders.find((x) => x.id === folderId);
      if (f && Array.isArray(f.items)) {
        f.items = f.items.filter((x) => x.id !== itemId);
        f.itemsCount = f.items.length;
        savePersistedState();
        showToast("🗑️ Item Removed from Folder");
        render();
      }
    },
    setSavedFilterType: (t) => {
      state.savedFilterType = t;
      render();
    },
    removeSavedItem: (svId) => {
      state.savedItems = state.savedItems.filter((x) => x.id !== svId);
      savePersistedState();
      showToast("🗑️ Removed from Saved Items");
      render();
    },
    clearAllHistory: () => {
      state.historyItems = [];
      savePersistedState();
      showToast("🧹 History Cleared!");
      render();
    },
    setFindAdvCourtFilter: (c) => {
      state.findAdvCourtFilter = c;
      render();
    },
    setFindAdvExpFilter: (e) => {
      state.findAdvExpFilter = e;
      render();
    },
    setChatSearchQuery: (q) => {
      state.chatSearchQuery = q;
      render();
    },
    sendVoiceNoteInChat: () => {
      const conv = state.consultingConversations.find((c) => c.id === state.activeConsultChatId) || state.consultingConversations[0];
      if (!conv) return;
      conv.messages.push({
        id: "m_vn_" + Date.now(),
        sender: "me",
        text: "🎙️ [Voice Note • 00:18] वकील साहब, मेरी FIR और जमानत अर्जी के कागजात देख लीजिए।",
        time: "Just now",
        isVoiceNote: true
      });
      setTimeout(() => {
        conv.messages.push({
          id: "m_vn_rep_" + Date.now(),
          sender: "them",
          text: "जी, मैंने आपका वॉइस नोट सुन लिया है। BNSS धारा 482 के तहत अग्रिम जमानत का मजबूत आधार है, कृपया FIR की कॉपी अटैच करें।",
          time: "Just now"
        });
        render();
      }, 450);
      showToast("🎙️ Voice Note Sent in Live Chat!");
      render();
    }
  });

  function renderTopBar() {
    const isLight = state.theme === "light";
    return `
      <div class="sticky top-0 z-40 px-3 py-1.5 gb-header flex items-center justify-between gap-1.5 text-[11px]">
        <div class="flex items-center gap-1.5 min-w-0">
          <span class="px-2 py-0.5 rounded-full bg-purple-600 text-white font-extrabold text-[9px] tracking-wider shrink-0">DEMO</span>
          <span class="font-bold truncate gb-text-sub">${state.isLoggedIn ? state.userAccountName : "Common Login"}</span>
        </div>
        <div class="flex items-center gap-1 shrink-0">
          <button onclick="GBApp.toggleFullscreenApp()" class="px-2 py-1 rounded-full gb-surface text-[10px] font-bold" title="Fullscreen Mobile App Feel">
            📲 App View
          </button>
          <button onclick="GBApp.toggleTheme()" class="px-2 py-1 rounded-full gb-surface-alt font-bold text-[10px]" title="Switch Dark/Light Theme">
            ${isLight ? "🌙 Dark" : "☀️ Light"}
          </button>
          <button onclick="GBApp.navigateTo('settings')" class="px-2 py-1 rounded-full gb-surface font-bold text-[10px]" title="Settings">
            ⚙️
          </button>
          ${
            state.isLoggedIn
              ? `<button onclick="GBApp.logout(false)" class="px-2 py-1 rounded-full bg-rose-600/20 border border-rose-500/40 text-rose-400 font-bold text-[10px]">Logout</button>`
              : ""
          }
        </div>
      </div>
    `;
  }

  // Mandatory Requirement #2: ONE Common Login for Everyone (No User/Advocate/Student role selection at login!)
  function renderAuthScreen() {
    return `
      <div class="flex-1 flex flex-col justify-between p-4 pb-8">
        <div class="text-center pt-2 pb-2">
          <div class="w-24 h-24 mx-auto rounded-3xl overflow-hidden border-2 border-purple-500/60 shadow-xl bg-black mb-2">
            <img src="${DATA.assets.logo}" alt="GB Legal Mind Logo" class="w-full h-full object-cover" />
          </div>
          <div class="inline-block px-3 py-0.5 rounded-full gb-surface-alt text-[10px] font-extrabold tracking-widest gb-text-accent mb-1">
            GB LEGAL MIND • ONE COMMON LOGIN
          </div>
          <h1 class="text-2xl font-black tracking-tight">Welcome!</h1>
          <p class="text-xs gb-text-sub mt-0.5">Login or register to continue (All Users, Advocates & Law Students)</p>
        </div>

        <div class="gb-card p-4 space-y-3.5 my-auto border-purple-400/50">
          ${
            state.authError
              ? `<div class="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/50 text-xs font-bold text-rose-400">${state.authError}</div>`
              : ""
          }

          ${
            state.authStep === "welcome"
              ? `
            <div class="space-y-3">
              <div class="p-3 rounded-xl gb-surface text-xs space-y-1">
                <div class="font-extrabold gb-text-gold">✔ One Common Login Flow:</div>
                <p class="text-[11px] gb-text-sub leading-relaxed">
                  लॉगिन के समय आपको General User, Advocate या Law Student चुनने की आवश्यकता नहीं है। लॉगिन के बाद आप <strong>Profile</strong> सेक्शन में जाकर अपनी प्रोफाइल बना या बदल सकते हैं।
                </p>
              </div>

              <button onclick="GBApp.setAuthStep('mobile')" class="w-full py-3 gb-btn-primary text-sm flex items-center justify-center gap-2">
                <span>📞 Login with Mobile (Demo OTP)</span>
              </button>

              <button onclick="GBApp.setAuthStep('google_notice')" class="w-full py-2.5 gb-btn-outline text-xs flex items-center justify-center gap-2 bg-white text-slate-900 font-bold">
                <span class="font-black text-blue-600 text-sm">G</span>
                <span>Continue with Google</span>
              </button>

              <div class="relative flex py-1 items-center">
                <div class="flex-grow border-t border-purple-500/20"></div>
                <span class="flex-shrink mx-3 text-[10px] gb-text-muted">FAST DEMO TESTING</span>
                <div class="flex-grow border-t border-purple-500/20"></div>
              </div>

              <button onclick="GBApp.quickDemoLogin()" class="w-full py-2.5 gb-btn-gold text-xs flex items-center justify-center gap-1.5">
                <span>⚡ 1-Tap Instant Demo Login → Open Home</span>
              </button>

              <div class="flex items-center justify-between pt-1 text-[10px] gb-text-muted">
                <button onclick="GBApp.navigateTo('splash')" class="underline font-bold gb-text-accent">View Splash / Intro</button>
                <button onclick="GBApp.setAuthStep('no_internet')" class="underline font-bold">Preview Offline Screen</button>
              </div>
            </div>
          `
              : state.authStep === "mobile"
              ? `
            <div class="space-y-3">
              <button onclick="GBApp.setAuthStep('welcome')" class="text-xs font-bold gb-text-accent">← Back</button>
              <div>
                <h2 class="text-base font-extrabold">Enter Mobile Number</h2>
                <p class="text-xs gb-text-sub mt-0.5">We will generate a 6-digit Demo OTP (123456) to verify your number.</p>
              </div>
              <div class="flex items-center gap-2">
                <span class="px-3 py-2.5 rounded-xl gb-surface font-bold text-xs shrink-0">🇮🇳 +91</span>
                <input id="login-mobile-input" type="tel" maxlength="10" value="${state.mobileInput}" placeholder="Mobile Number" class="gb-input font-bold" />
              </div>
              <div class="text-[10px] gb-text-muted">
                🛡️ Demo Notice: कोई वास्तविक SMS नहीं भेजा जाता। अगले स्क्रीन पर Demo OTP <strong>123456</strong> दर्ज करें।
              </div>
              <button onclick="GBApp.requestDemoOtp()" class="w-full py-3 gb-btn-primary text-sm">
                Send OTP →
              </button>
            </div>
          `
              : state.authStep === "otp"
              ? `
            <div class="space-y-3">
              <button onclick="GBApp.setAuthStep('mobile')" class="text-xs font-bold gb-text-accent">← Change Number</button>
              <div class="text-center">
                <h2 class="text-base font-extrabold">Enter OTP</h2>
                <p class="text-xs gb-text-sub mt-0.5">Demo OTP generated for <strong>+91 ${state.mobileInput}</strong></p>
              </div>
              <div class="p-2.5 rounded-xl gb-surface-alt text-xs text-center">
                <span class="font-extrabold gb-text-gold">Demo OTP Code: 123456</span> (No real SMS sent)
              </div>
              <input id="login-otp-input" type="text" maxlength="6" value="123456" placeholder="123456" class="gb-input text-center text-lg font-black tracking-[0.4em]" />
              <div class="text-center text-[11px] gb-text-muted">Resend OTP in 00:45</div>
              <button onclick="GBApp.verifyDemoOtp()" class="w-full py-3 gb-btn-primary text-sm">
                Verify OTP →
              </button>
            </div>
          `
              : state.authStep === "terms"
              ? `
            <div class="space-y-3">
              <button onclick="GBApp.setAuthStep('otp')" class="text-xs font-bold gb-text-accent">← Back</button>
              <div class="text-center">
                <div class="w-12 h-12 rounded-2xl gb-surface-alt flex items-center justify-center text-2xl mx-auto mb-1">📜</div>
                <h2 class="text-base font-extrabold">Terms & Conditions</h2>
                <p class="text-xs gb-text-sub mt-0.5">Please read and accept our Terms & Conditions and Privacy Policy to continue.</p>
              </div>
              <div class="p-3 rounded-xl gb-surface space-y-2 text-xs">
                <label class="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" ${state.termsAccepted ? "checked" : ""} onchange="GBApp.toggleTermsCheck('termsAccepted')" class="accent-purple-600 w-4 h-4" />
                  <span>I agree to the Terms & Conditions</span>
                </label>
                <label class="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" ${state.privacyAccepted ? "checked" : ""} onchange="GBApp.toggleTermsCheck('privacyAccepted')" class="accent-purple-600 w-4 h-4" />
                  <span>I agree to the Privacy Policy</span>
                </label>
              </div>
              <button onclick="GBApp.completeCommonLogin()" class="w-full py-3 gb-btn-primary text-sm">
                Continue to Home →
              </button>
            </div>
          `
              : state.authStep === "no_internet"
              ? `
            <div class="space-y-3 text-center py-3">
              <div class="text-4xl">📡❌</div>
              <h3 class="text-base font-extrabold">No Internet Connection</h3>
              <p class="text-xs gb-text-sub">Please check your internet connection and try again. (PDF 1 Page 4 Step 7 Demo Screen)</p>
              <button onclick="GBApp.setAuthStep('welcome')" class="w-full py-2.5 gb-btn-outline text-xs">Try Again</button>
            </div>
          `
              : `
            <div class="space-y-3 text-center py-2">
              <div class="w-12 h-12 rounded-2xl gb-surface-alt flex items-center justify-center text-2xl mx-auto">🔒</div>
              <h3 class="text-base font-extrabold">Google Sign-In (Demo Notice)</h3>
              <p class="text-xs gb-text-sub leading-relaxed">
                इस फ्रंटएंड डेमो फेज में लाइव Google Authentication कॉन्फ़िगर नहीं है। नकली Google लॉगिन दिखाने के बजाय यह स्पष्ट डेमो संदेश दिया गया है।
              </p>
              <div class="flex gap-2 pt-1">
                <button onclick="GBApp.setAuthStep('welcome')" class="flex-1 py-2.5 gb-btn-outline text-xs">← Back</button>
                <button onclick="GBApp.quickDemoLogin()" class="flex-1 py-2.5 gb-btn-primary text-xs">Continue with Demo →</button>
              </div>
            </div>
          `
          }
        </div>

        <div class="text-center text-[10px] gb-text-muted mt-2">
          By continuing, you agree to our Terms & Conditions and Privacy Policy
        </div>
      </div>
    `;
  }

  // Splash & Welcome Intro Screen (PDF 1 Pages 1–3)
  function renderSplashScreen() {
    return `
      <div class="flex-1 flex flex-col justify-between p-4 pb-8 text-center">
        <div class="pt-1">
          <div class="text-xs font-extrabold tracking-widest gb-text-accent">✦ GB LEGAL MIND v2.0 ✦</div>
          <h1 class="text-2xl font-black mt-1">Think Like A Lawyer</h1>
          <p class="text-xs gb-text-gold font-bold mt-0.5">${DATA.appMeta.taglineHindi}</p>
        </div>

        <div class="rounded-2xl overflow-hidden border border-purple-500/40 shadow-xl my-2.5 relative">
          <img src="${DATA.assets.splashLawyers}" alt="GB Legal Mind" class="w-full h-44 object-cover" />
          <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-3 text-white">
            <div class="text-xs font-bold text-amber-300">Modern Smart Legal Learning Platform</div>
            <div class="text-[10px] opacity-85">GULAB BADSHAH LEGAL MIND OF INDIA</div>
          </div>
        </div>

        <!-- Find My Advocate & Student Search Bar Preview (PDF 1 Page 3) -->
        <button onclick="GBApp.navigateTo('${state.isLoggedIn ? "find_advocate" : "auth"}')" class="gb-card p-2.5 flex items-center justify-between text-left">
          <div class="flex items-center gap-2.5">
            <span class="text-xl">👨‍⚖️🎓</span>
            <div>
              <div class="text-xs font-extrabold">Find My Advocate & Student</div>
              <div class="text-[10px] gb-text-sub">Advocate खोजें | Law Student खोजें</div>
            </div>
          </div>
          <span class="text-sm">🔍</span>
        </button>

        <!-- What You Get 10-Icon Grid (PDF 1 Page 3) -->
        <div>
          <div class="text-xs font-extrabold mb-1.5">✦ What You Get ✦</div>
          <div class="grid grid-cols-5 gap-1.5 text-center">
            ${[
              { icon: "🎧", label: "Audio" },
              { icon: "▶️", label: "Video" },
              { icon: "🎬", label: "Reels" },
              { icon: "✍️", label: "Handwritten" },
              { icon: "🕸️", label: "Mind Map" },
              { icon: "📄", label: "PDF Notes" },
              { icon: "☑️", label: "MCQ Test" },
              { icon: "📖", label: "Shabdawali" },
              { icon: "💬", label: "Consulting" },
              { icon: "🎁", label: "Refer & Free" }
            ]
              .map(
                (it) => `
              <div class="gb-card p-1.5 flex flex-col items-center">
                <span class="text-base">${it.icon}</span>
                <span class="text-[9px] font-bold mt-0.5 leading-tight">${it.label}</span>
              </div>
            `
              )
              .join("")}
          </div>
        </div>

        <button onclick="GBApp.navigateTo('${state.isLoggedIn ? "home" : "auth"}')" class="w-full py-3 gb-btn-primary text-sm mt-2">
          ${state.isLoggedIn ? "Learning Start (Open Home) →" : "Learning Start (Open Common Login) →"}
        </button>
      </div>
    `;
  }

  // Requirement #4: Approved Home Screen (PDF 1 Page 5 & PDF 3 Page 1)
  function renderHomeScreen() {
    const banner = DATA.homeBanners[state.bannerIndex % DATA.homeBanners.length];
    const unreadNotifs = state.notifications.filter((n) => n.unread).length;

    const quickAccess = [
      { label: "Create Folder", icon: "📁", screen: "folders" },
      { label: "Saved", icon: "🔖", screen: "saved_items" },
      { label: "Chat Support", icon: "🎧", screen: "chat_support" },
      { label: "Progress Tracking", icon: "📊", screen: "progress_tracking" },
      { label: "History", icon: "🕒", screen: "history_screen" },
      { label: "Request Topic", icon: "💡", screen: "request_topic" },
      { label: "Favourite", icon: "💜", screen: "saved_items" },
      { label: "Categories", icon: "⊞", screen: "categories_hub" }
    ];

    return `
      <div class="flex-1 pb-24">
        <!-- Header: Branding, Profile Avatar, Notification & Referral -->
        <div class="px-3.5 pt-3 pb-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2.5">
            <button onclick="GBApp.navigateTo('profile')" class="w-12 h-12 rounded-full gb-surface-alt border-2 border-amber-400 flex items-center justify-center relative shrink-0 overflow-hidden shadow-md">
              ${
                state.generalUserProfile.photoDataUrl
                  ? `<img src="${state.generalUserProfile.photoDataUrl}" class="w-full h-full object-cover" />`
                  : `<span class="text-xl">👤</span>`
              }
              <span class="w-3 h-3 rounded-full bg-emerald-400 absolute bottom-0 right-0 border-2 border-black"></span>
            </button>
            <div>
              <div class="flex items-center gap-1">
                <span class="text-xl font-black tracking-tight">GB</span>
                <span class="text-xs font-extrabold gb-text-gold leading-tight">LEGAL<br/>MIND</span>
              </div>
              <div class="text-[10px] gb-text-sub">Your Trusted Legal Friend</div>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <button onclick="GBApp.navigateTo('notifications')" class="gb-card gb-card-interactive px-2.5 py-1.5 flex flex-col items-center relative">
              <span class="text-sm">🔔</span>
              <span class="text-[9px] font-bold mt-0.5">Notification</span>
              ${
                unreadNotifs > 0
                  ? `<span class="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white text-[9px] font-extrabold flex items-center justify-center">${unreadNotifs}</span>`
                  : ""
              }
            </button>
            <button onclick="GBApp.navigateTo('referral')" class="gb-card gb-card-interactive px-2.5 py-1.5 flex flex-col items-center">
              <span class="text-sm">🎁</span>
              <span class="text-[9px] font-bold mt-0.5">Referral</span>
            </button>
          </div>
        </div>

        <!-- Upper 5 Shortcuts Bar (Shabdawali | MCQ Test | Consulting | Advocate Diary | Student Notes) -->
        <div class="px-3 mt-2.5">
          <div class="gb-pill-nav p-2 grid grid-cols-5 gap-1 text-center">
            <button onclick="GBApp.navigateTo('shabdawali')" class="p-1.5 rounded-xl hover:bg-purple-500/15 flex flex-col items-center">
              <span class="text-lg">📖</span>
              <span class="text-[10px] font-bold mt-0.5 leading-tight">Shabdawali</span>
            </button>
            <button onclick="GBApp.navigateTo('mcq_test', { mcqScreenView: 'hub' })" class="p-1.5 rounded-xl hover:bg-purple-500/15 flex flex-col items-center">
              <span class="text-lg">☑️</span>
              <span class="text-[10px] font-bold mt-0.5 leading-tight">MCQ Test</span>
            </button>
            <button onclick="GBApp.navigateTo('consulting', { consultingView: 'list' })" class="p-1.5 rounded-xl hover:bg-purple-500/15 flex flex-col items-center">
              <span class="text-lg">⚖️</span>
              <span class="text-[10px] font-bold mt-0.5 leading-tight">Consulting</span>
            </button>
            <button onclick="GBApp.navigateTo('advocate_diary')" class="p-1.5 rounded-xl hover:bg-purple-500/15 flex flex-col items-center">
              <span class="text-lg">📓</span>
              <span class="text-[10px] font-bold mt-0.5 leading-tight">Advocate Diary</span>
            </button>
            <button onclick="GBApp.navigateTo('student_notes')" class="p-1.5 rounded-xl hover:bg-purple-500/15 flex flex-col items-center">
              <span class="text-lg">🎓</span>
              <span class="text-[10px] font-bold mt-0.5 leading-tight">Student Notes</span>
            </button>
          </div>
        </div>

        <!-- Approved Banner Slider -->
        <div class="px-3 mt-3">
          <div onclick="GBApp.navigateTo('${banner.targetScreen}', { actId: '${banner.targetAct || "bns"}', publicTopicId: '${banner.targetPublicTopic || "fir"}' })" class="dark-media-stage rounded-2xl overflow-hidden border border-purple-400/40 shadow-lg relative cursor-pointer">
            <img src="${banner.image}" alt="${banner.title}" class="w-full h-44 object-cover" />
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/25 to-transparent p-3.5 flex flex-col justify-between text-white">
              <div class="flex justify-between items-center">
                <span class="px-2 py-0.5 rounded-full text-[9px] font-bold bg-black/70 text-amber-300 border border-amber-400/40">${banner.badge}</span>
                <span class="px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-purple-700 text-white">GB Legal Mind</span>
              </div>
              <div>
                <h2 class="text-base font-extrabold text-amber-300 drop-shadow">${banner.title}</h2>
                <p class="text-[11px] text-gray-200 mt-0.5">${banner.subtitle}</p>
              </div>
            </div>
          </div>
          <div class="flex justify-center gap-1.5 mt-2">
            ${DATA.homeBanners
              .map(
                (b, idx) => `
              <button onclick="GBApp.setBanner(${idx})" class="h-1.5 rounded-full transition-all ${
                  idx === state.bannerIndex ? "w-5 bg-purple-500" : "w-2 bg-purple-500/30"
                }"></button>
            `
              )
              .join("")}
          </div>
        </div>

        <!-- Public Law Card + Demo Counts Bar (125 Audio | 320 Video | 240 PDF | 180 Slide from PDF 1 Page 5) -->
        <div class="px-3 mt-3 space-y-2">
          <div class="gb-card overflow-hidden border-purple-400/50">
            <div class="grid grid-cols-12 items-center">
              <div class="col-span-7 p-3.5 space-y-1.5">
                <h2 class="text-xl font-black leading-none">Public Law</h2>
                <div class="text-xs font-extrabold gb-text-accent leading-tight">Your Rights,<br/>Our Responsibility</div>
                <p class="text-[10px] gb-text-sub leading-relaxed">The Constitution gives you rights, using them is your responsibility.</p>
                <button onclick="GBApp.navigateTo('public_law_hub')" class="mt-1 px-4 py-1.5 gb-btn-primary text-xs inline-flex items-center gap-1">
                  <span>Explore Now</span>
                  <span>›</span>
                </button>
              </div>
              <div class="col-span-5 h-full">
                <img src="${DATA.assets.bannerPublicLaw}" alt="Public Law" class="w-full h-36 object-cover" />
              </div>
            </div>
          </div>

          <!-- Audio, Video, PDF and Slide Demo Counts Bar (PDF 1 Page 5) -->
          <div class="gb-card p-2 grid grid-cols-4 gap-1.5 text-center">
            <button onclick="GBApp.navigateTo('public_law_hub', { publicLawMediaTab: 'audio' })" class="p-1.5 rounded-xl gb-surface flex items-center justify-center gap-1.5">
              <span class="text-base">🎧</span>
              <div class="text-left">
                <div class="text-xs font-black leading-none">125</div>
                <div class="text-[9px] gb-text-muted">Audio</div>
              </div>
            </button>
            <button onclick="GBApp.navigateTo('public_law_hub', { publicLawMediaTab: 'video' })" class="p-1.5 rounded-xl gb-surface flex items-center justify-center gap-1.5">
              <span class="text-base">▶️</span>
              <div class="text-left">
                <div class="text-xs font-black leading-none">320</div>
                <div class="text-[9px] gb-text-muted">Video</div>
              </div>
            </button>
            <button onclick="GBApp.navigateTo('public_law_hub', { publicLawMediaTab: 'pdf' })" class="p-1.5 rounded-xl gb-surface flex items-center justify-center gap-1.5">
              <span class="text-base">📄</span>
              <div class="text-left">
                <div class="text-xs font-black leading-none">240</div>
                <div class="text-[9px] gb-text-muted">PDF</div>
              </div>
            </button>
            <button onclick="GBApp.navigateTo('public_law_hub', { publicLawMediaTab: 'slides' })" class="p-1.5 rounded-xl gb-surface flex items-center justify-center gap-1.5">
              <span class="text-base">🖼️</span>
              <div class="text-left">
                <div class="text-xs font-black leading-none">180</div>
                <div class="text-[9px] gb-text-muted">Slide</div>
              </div>
            </button>
          </div>
        </div>

        <!-- Quick Access 8-Item Grid (Create Folder, Saved, Chat Support, Progress Tracking, History, Request Topic, Favourite, Categories) -->
        <div class="px-3 mt-3.5">
          <h3 class="text-xs font-extrabold mb-2 flex items-center gap-1">⚡ Quick Access</h3>
          <div class="gb-card p-2.5 grid grid-cols-4 gap-2">
            ${quickAccess
              .map(
                (q) => `
              <button onclick="GBApp.navigateTo('${q.screen}')" class="p-2 rounded-xl gb-surface hover:border-purple-400 flex flex-col items-center justify-center text-center min-h-[58px]">
                <span class="text-base mb-1">${q.icon}</span>
                <span class="text-[10px] font-bold leading-tight">${q.label}</span>
              </button>
            `
              )
              .join("")}
          </div>
        </div>

        <!-- Explore Laws / Approved Act Cards (BNS, BNSS, BSA, Constitution of India) -->
        <div class="px-3 mt-4">
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-extrabold flex items-center gap-1.5">⚖️ Explore Laws</h3>
            <button onclick="GBApp.navigateTo('bare_act_library')" class="text-[11px] gb-text-accent font-bold">View All ›</button>
          </div>
          <div class="grid grid-cols-2 gap-2.5">
            ${Object.values(DATA.acts)
              .map(
                (act) => `
              <button onclick="GBApp.navigateTo('act_detail', { actId: '${act.id}' })" class="gb-card gb-card-interactive overflow-hidden text-left flex flex-col">
                <div class="relative">
                  <img src="${act.cardImage}" alt="${act.shortTitle}" class="w-full h-24 object-cover" />
                  <span class="absolute top-1.5 right-1.5 px-2 py-0.5 rounded bg-black/75 text-amber-300 text-[9px] font-bold">${act.year}</span>
                </div>
                <div class="p-2.5">
                  <div class="text-sm font-black truncate">${act.shortTitle}</div>
                  <div class="text-[10px] gb-text-sub truncate mt-0.5">${act.titleEnglish}</div>
                  <div class="text-[9px] gb-text-muted mt-1.5 font-semibold">
                    ${act.homeBadgeText || `${act.chaptersCount} Chapters • ${act.sectionsCount} Sections`}
                  </div>
                </div>
              </button>
            `
              )
              .join("")}
          </div>
        </div>
      </div>
    `;
  }

  // Categories Hub Screen (Opened from 'Categories' button in Quick Access)
  function renderCategoriesHubScreen() {
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center gap-2 border-b border-purple-500/20">
          <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
          <div>
            <div class="text-sm font-extrabold">⊞ All Legal & Learning Categories</div>
            <div class="text-[10px] gb-text-sub">Acts, Public Law, Study Formats & Services</div>
          </div>
        </div>
        <div class="p-3.5 space-y-3.5">
          <div>
            <h3 class="text-xs font-extrabold mb-2">1. 6 Learning Content Formats:</h3>
            <div class="grid grid-cols-3 gap-2">
              ${DATA.contentCategories
                .map(
                  (c) => `
                <button onclick="GBApp.openCategoryMedia('${c.id}')" class="gb-card gb-card-interactive p-3 text-center">
                  <div class="text-2xl">${c.icon}</div>
                  <div class="text-xs font-extrabold mt-1">${c.label}</div>
                  <div class="text-[9px] gb-text-gold font-bold">${c.demoCount} Demo Items</div>
                </button>
              `
                )
                .join("")}
            </div>
          </div>
          <div>
            <h3 class="text-xs font-extrabold mb-2">2. Platform Modules:</h3>
            <div class="grid grid-cols-2 gap-2 text-xs">
              <button onclick="GBApp.navigateTo('bare_act_library')" class="gb-card p-3 text-left font-bold">📚 Bare Act Library (800+ Structure)</button>
              <button onclick="GBApp.navigateTo('public_law_hub')" class="gb-card p-3 text-left font-bold">🏛️ Public Law Topics</button>
              <button onclick="GBApp.navigateTo('shabdawali')" class="gb-card p-3 text-left font-bold">📖 Legal Shabdawali (9 Categories)</button>
              <button onclick="GBApp.navigateTo('mcq_test', { mcqScreenView: 'hub' })" class="gb-card p-3 text-left font-bold">☑️ MCQ & Mock Tests</button>
              <button onclick="GBApp.navigateTo('consulting', { consultingView: 'list' })" class="gb-card p-3 text-left font-bold">💬 Consulting Live Chat</button>
              <button onclick="GBApp.navigateTo('find_advocate')" class="gb-card p-3 text-left font-bold">👨‍⚖️ Find Advocate & Student</button>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  // Requirement #5: Act Detail Screen & 6 Content Categories (PDF 1 Pages 6 & 22)
  function renderActDetailScreen() {
    const act = getCurrentActObj();
    const prog = state.progressByAct[act.id] || { completed: 14, total: 20 };
    const pct = Math.round((prog.completed / prog.total) * 100);
    const q = (state.actSectionSearch || "").trim().toLowerCase();

    const formatMeta = [
      { id: "audio", label: "Audio", labelHi: "ऑडियो लेक्चर", count: "48 Audio", icon: "🎧", badge: "HD Voice", grad: "from-purple-900/80 to-indigo-950/90" },
      { id: "video", label: "Video", labelHi: "वीडियो क्लास", count: "65 Video", icon: "🎬", badge: "1080p", grad: "from-amber-900/70 to-purple-950/90" },
      { id: "pdf", label: "PDF / Notes", labelHi: "लिखित नोट्स व प्रश्न", count: "42 PDF", icon: "📄", badge: "Downloadable", grad: "from-emerald-900/70 to-purple-950/90" },
      { id: "mindmap", label: "Mind Map", labelHi: "माइंड मैप चार्ट", count: "20 Maps", icon: "🧠", badge: "Visual Tree", grad: "from-blue-900/70 to-purple-950/90" },
      { id: "slides", label: "Legal Slides", labelHi: "इलस्ट्रेटेड स्लाइड्स", count: "55 Slides", icon: "📊", badge: " exam Revision", grad: "from-fuchsia-900/70 to-purple-950/90" },
      { id: "handwriting", label: "Handwriting Notes", labelHi: "हस्तलिखित नोट्स", count: "30 Pages", icon: "✍️", badge: "Toppers Notes", grad: "from-rose-900/70 to-purple-950/90" }
    ];

    return `
      <div class="flex-1 pb-24">
        <!-- PDF 1 Page 6 Style Top Bar -->
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/25 gb-header sticky top-9 z-30">
          <div class="flex items-center gap-2 min-w-0">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold shrink-0">←</button>
            <div class="min-w-0">
              <div class="text-sm font-black truncate text-amber-400">${act.titleHindi}</div>
              <div class="text-[10px] gb-text-sub truncate">${act.titleEnglish} • ${act.actNumber}</div>
            </div>
          </div>
          <button onclick="GBApp.openBareActDetail('${act.id}')" class="px-2.5 py-1 rounded-full bg-gradient-to-r from-amber-500 to-yellow-600 text-black text-[10px] font-black shrink-0 shadow">
            📖 मूल बेर एक्ट
          </button>
        </div>

        <div class="p-3 space-y-3.5">
          <!-- PDF 1 Page 6 3D Book Showcase & Gold Section Badge -->
          <div class="gb-card p-3.5 relative overflow-hidden border-amber-500/40" style="background: linear-gradient(135deg, rgba(38,18,78,0.96) 0%, rgba(15,9,35,0.98) 100%);">
            <div class="grid grid-cols-12 gap-3 items-center">
              <div class="col-span-4 relative">
                <img src="${act.coverImage || DATA.assets.bns3dBook}" alt="${act.shortTitle}" class="w-full h-36 object-cover rounded-xl border-2 border-amber-400/60 shadow-2xl" />
                <span class="absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-amber-500 text-black font-black text-[9px] whitespace-nowrap shadow">
                  ${act.year} नया कानून
                </span>
              </div>
              <div class="col-span-8 space-y-1.5 text-white">
                <div class="flex items-center justify-between">
                  <span class="px-2 py-0.5 rounded-full bg-purple-600/50 border border-purple-400/40 text-[9px] font-extrabold text-purple-200">${act.actNumber}</span>
                  <span class="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-[9px] font-extrabold text-amber-300">लागू: ${act.effectiveDate}</span>
                </div>
                <h1 class="text-base font-black text-amber-300 leading-tight">${act.titleHindi}</h1>
                <div class="text-[11px] text-purple-200 font-semibold">${act.tagline}</div>
                <div class="grid grid-cols-3 gap-1.5 pt-1 text-center">
                  <div class="p-1.5 rounded-lg bg-black/40 border border-purple-400/30">
                    <div class="text-xs font-black text-amber-400">${act.chaptersCount}</div>
                    <div class="text-[9px] text-gray-300">अध्याय (Ch)</div>
                  </div>
                  <div class="p-1.5 rounded-lg bg-black/40 border border-purple-400/30">
                    <div class="text-xs font-black text-emerald-400">${act.sectionsCount}</div>
                    <div class="text-[9px] text-gray-300">धाराएं (Sec)</div>
                  </div>
                  <div class="p-1.5 rounded-lg bg-black/40 border border-purple-400/30">
                    <div class="text-xs font-black text-purple-300">${pct}%</div>
                    <div class="text-[9px] text-gray-300">पूर्ण (Done)</div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Progress Bar -->
            <div class="mt-3 pt-2 border-t border-white/10">
              <div class="flex justify-between text-[10px] text-gray-200 font-bold mb-1">
                <span>📊 आपकी अध्ययन प्रगति (Study Progress)</span>
                <span class="text-amber-300">${prog.completed}/${prog.total} Modules (${pct}%)</span>
              </div>
              <div class="w-full h-2 bg-black/50 rounded-full overflow-hidden p-0.5 border border-purple-500/30">
                <div class="h-full bg-gradient-to-r from-amber-400 via-purple-500 to-emerald-400 rounded-full" style="width:${pct}%"></div>
              </div>
            </div>
          </div>

          <!-- New Reels & MCQ Quick Strip (PDF 1 Page 6) -->
          <div class="grid grid-cols-2 gap-2">
            <button onclick="GBApp.navigateTo('reels', { reelsCategory: 'bns' })" class="gb-card gb-card-interactive p-2.5 flex items-center gap-2.5 border-amber-500/40">
              <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-black flex items-center justify-center text-lg font-black shrink-0">🎬</div>
              <div class="text-left min-w-0">
                <div class="text-xs font-black truncate">${act.shortTitle} Legal Reels</div>
                <div class="text-[9px] gb-text-gold font-bold">60-Sec शॉर्ट वीडियो देखें ›</div>
              </div>
            </button>
            <button onclick="GBApp.navigateTo('mcq_test')" class="gb-card gb-card-interactive p-2.5 flex items-center gap-2.5 border-purple-500/40">
              <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 text-white flex items-center justify-center text-lg font-black shrink-0">☑️</div>
              <div class="text-left min-w-0">
                <div class="text-xs font-black truncate">${act.shortTitle} MCQ Test</div>
                <div class="text-[9px] gb-text-accent font-bold">प्रैक्टिस और रैंक टेस्ट ›</div>
              </div>
            </button>
          </div>

          <!-- 6 Distinct Content Format Cards (PDF 1 Page 6: Audio, Video, PDF, Mind Map, Legal Slides, Handwriting Notes) -->
          <div>
            <div class="flex items-center justify-between mb-2">
              <h3 class="text-xs font-black flex items-center gap-1.5">
                <span class="text-amber-400">✦</span> 1. अध्ययन माध्यम चुनें (6 Study Formats)
              </h3>
              <span class="text-[10px] font-bold gb-text-accent">Selected: ${state.selectedMediaTab.toUpperCase()}</span>
            </div>
            <div class="grid grid-cols-3 gap-2">
              ${formatMeta.map((f) => {
                const isSel = state.selectedMediaTab === f.id;
                return `
                  <button onclick="GBApp.selectActTab('${f.id}')" class="gb-card gb-card-interactive p-2.5 text-center relative overflow-hidden transition-all ${
                    isSel ? "gb-tab-active ring-2 ring-amber-400/70" : ""
                  }">
                    <span class="px-1.5 py-0.5 rounded bg-purple-500/20 text-[8px] font-extrabold gb-text-gold">${f.count}</span>
                    <div class="text-2xl my-1">${f.icon}</div>
                    <div class="text-[11px] font-black leading-tight">${f.label}</div>
                    <div class="text-[9px] gb-text-muted mt-0.5 truncate">${f.labelHi}</div>
                  </button>
                `;
              }).join("")}
            </div>
          </div>

          <!-- Instant Launch Bar for Selected Format -->
          <div class="gb-card p-3 border-amber-400/50 flex items-center justify-between gap-2" style="background: linear-gradient(135deg, rgba(124,58,237,0.22), rgba(245,158,11,0.14));">
            <div class="flex items-center gap-2.5 min-w-0">
              <span class="text-2xl shrink-0">${formatMeta.find((x) => x.id === state.selectedMediaTab)?.icon || "🎧"}</span>
              <div class="min-w-0">
                <div class="text-xs font-black truncate">${act.shortTitle} — ${formatMeta.find((x) => x.id === state.selectedMediaTab)?.labelHi || "अध्ययन"}</div>
                <div class="text-[10px] gb-text-sub truncate">नीचे किसी भी धारा पर टैप करें या सीधे प्लेयर खोलें</div>
              </div>
            </div>
            <button onclick="GBApp.openCategoryMedia('${state.selectedMediaTab}', '${act.chapters[0].sections[0].id}')" class="px-3.5 py-2 gb-btn-gold text-xs shrink-0">
              ▶ Open ${state.selectedMediaTab.toUpperCase()}
            </button>
          </div>

          <!-- Section & Chapter Search Bar inside Act -->
          <div class="flex items-center gap-2 px-3 py-2 rounded-xl gb-card border-purple-400/40">
            <span>🔍</span>
            <input type="text" value="${state.actSectionSearch || ""}" oninput="GBApp.setActSectionSearch(this.value)" placeholder="इस कानून में धारा या विषय खोजें (e.g. धारा 1, धारा 2, हत्या, दंड)..." class="bg-transparent flex-1 text-xs focus:outline-none" />
            ${state.actSectionSearch ? `<button onclick="GBApp.setActSectionSearch('')" class="text-xs font-bold gb-text-muted">✕</button>` : ""}
          </div>

          <!-- Chapter & Section Cards (PDF 1 Pages 7-21 Style) -->
          <div class="space-y-3">
            <div class="flex items-center justify-between">
              <h3 class="text-xs font-black">📚 2. अध्याय एवं धारा-वार सूची (Chapters & Sections)</h3>
              <button onclick="GBApp.openBareActDetail('${act.id}')" class="text-[10px] font-bold gb-text-gold underline">सभी ${act.sectionsCount} धाराएं ›</button>
            </div>
            ${act.chapters.map((ch) => {
              const secs = ch.sections.filter((s) => {
                if (!q) return true;
                return s.code.toLowerCase().includes(q) || s.title.toLowerCase().includes(q) || s.titleHindi.toLowerCase().includes(q) || (s.summaryHindi || "").toLowerCase().includes(q);
              });
              if (q && secs.length === 0) return "";
              return `
                <div class="gb-card p-3 space-y-2.5 border-purple-500/35">
                  <div class="flex items-center justify-between border-b border-purple-500/20 pb-2">
                    <div>
                      <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 text-[9px] font-black">${ch.sectionsRange}</span>
                      <div class="text-xs font-black mt-1">${ch.titleHindi}</div>
                      <div class="text-[10px] gb-text-muted">${ch.title}</div>
                    </div>
                    <button onclick="GBApp.navigateTo('chapter_sections', { chapterId: '${ch.id}' })" class="px-2.5 py-1.5 rounded-xl gb-surface-alt text-[10px] font-extrabold gb-text-accent shrink-0">
                      विस्तृत सूची ›
                    </button>
                  </div>

                  <div class="space-y-2">
                    ${secs.map((sec) => {
                      const isDone = state.readSections.includes(sec.id);
                      return `
                        <div class="p-2.5 rounded-xl gb-surface space-y-2 border border-purple-500/20">
                          <div class="flex items-start justify-between gap-2">
                            <div class="min-w-0 flex-1">
                              <div class="flex items-center gap-1.5 flex-wrap">
                                <span class="px-2 py-0.5 rounded-md bg-purple-600 text-white text-[10px] font-black">${sec.code}</span>
                                ${sec.oldRef ? `<span class="px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 text-[9px] font-bold">${sec.oldRef}</span>` : ""}
                                <span class="text-[9px] gb-text-muted">⏱ ${sec.duration}</span>
                              </div>
                              <div class="text-xs font-extrabold mt-1 leading-snug">${sec.titleHindi}</div>
                              <p class="text-[10px] gb-text-sub line-clamp-2 mt-0.5">${sec.summaryHindi}</p>
                            </div>
                            <button onclick="GBApp.addCurrentItemToFolder('${state.folders[0]?.id || "f1"}', '${act.shortTitle}', '${sec.code}: ${sec.titleHindi}', 'bare_act_reader')" class="px-2 py-1 rounded-lg gb-card text-[9px] font-bold shrink-0" title="Add to Folder">
                              📁 +Folder
                            </button>
                          </div>

                          <!-- 6-Format Quick Launch Pills for Each Section -->
                          <div class="grid grid-cols-6 gap-1 pt-1 border-t border-purple-500/15 text-center">
                            <button onclick="GBApp.openCategoryMedia('audio', '${sec.id}')" class="py-1 rounded-lg gb-card text-[9px] font-bold hover:border-purple-400">🎧 Audio</button>
                            <button onclick="GBApp.openCategoryMedia('video', '${sec.id}')" class="py-1 rounded-lg gb-card text-[9px] font-bold hover:border-purple-400">🎬 Video</button>
                            <button onclick="GBApp.openCategoryMedia('pdf', '${sec.id}')" class="py-1 rounded-lg gb-card text-[9px] font-bold hover:border-purple-400">📄 PDF</button>
                            <button onclick="GBApp.openCategoryMedia('mindmap', '${sec.id}')" class="py-1 rounded-lg gb-card text-[9px] font-bold hover:border-purple-400">🧠 Map</button>
                            <button onclick="GBApp.openCategoryMedia('slides', '${sec.id}')" class="py-1 rounded-lg gb-card text-[9px] font-bold hover:border-purple-400">📊 Slide</button>
                            <button onclick="GBApp.openCategoryMedia('handwriting', '${sec.id}')" class="py-1 rounded-lg gb-card text-[9px] font-bold hover:border-purple-400">✍️ Note</button>
                          </div>
                        </div>
                      `;
                    }).join("")}
                  </div>
                </div>
              `;
            }).join("")}
          </div>
        </div>
      </div>
    `;
  }

  function renderChapterSectionsScreen() {
    const act = getCurrentActObj();
    const ch = getCurrentChapterObj();
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-xs font-extrabold">${act.shortTitle} • ${ch.titleHindi}</div>
              <div class="text-[10px] gb-text-sub">${ch.sectionsRange} (Demo Content)</div>
            </div>
          </div>
        </div>
        <div class="p-3 space-y-2.5">
          ${ch.sections
            .map(
              (sec) => `
            <div class="gb-card p-3 space-y-2">
              <div class="flex justify-between items-center">
                <span class="px-2 py-0.5 rounded gb-surface-alt text-[10px] font-extrabold gb-text-accent">${sec.code} (${sec.oldRef || "Demo"})</span>
                <span class="text-[10px] gb-text-gold font-bold">${sec.duration}</span>
              </div>
              <h4 class="text-xs font-extrabold">${sec.titleHindi}</h4>
              <p class="text-[11px] gb-text-sub">${sec.summaryHindi}</p>
              <div class="flex flex-wrap gap-1.5 pt-1 border-t border-purple-500/20">
                <button onclick="GBApp.openCategoryMedia('audio', '${sec.id}')" class="px-2.5 py-1 rounded-lg gb-surface text-[10px] font-bold">🎧 Audio</button>
                <button onclick="GBApp.openCategoryMedia('video', '${sec.id}')" class="px-2.5 py-1 rounded-lg gb-surface text-[10px] font-bold">▶️ Video</button>
                <button onclick="GBApp.openCategoryMedia('pdf', '${sec.id}')" class="px-2.5 py-1 rounded-lg gb-surface text-[10px] font-bold">📄 PDF</button>
                <button onclick="GBApp.openCategoryMedia('mindmap', '${sec.id}')" class="px-2.5 py-1 rounded-lg gb-surface text-[10px] font-bold">🕸️ Mind Map</button>
                <button onclick="GBApp.openCategoryMedia('slides', '${sec.id}')" class="px-2.5 py-1 rounded-lg gb-surface text-[10px] font-bold">🖼️ Slides</button>
                <button onclick="GBApp.openCategoryMedia('handwriting', '${sec.id}')" class="px-2.5 py-1 rounded-lg gb-surface text-[10px] font-bold">✍️ Notes</button>
                <button onclick="GBApp.openBareActReader('${act.id}', '${ch.id}', '${sec.id}')" class="px-2.5 py-1 rounded-lg gb-surface-alt gb-text-accent text-[10px] font-bold">📖 Dual Text</button>
              </div>
            </div>
          `
            )
            .join("")}
        </div>
      </div>
    `;
  }

  // Public Law Hub & Topic Detail (PDF 1 Pages 26–32)
  function renderPublicLawHubScreen() {
    const q = (state.publicLawSearch || "").trim().toLowerCase();
    const catFilter = state.publicLawCategoryFilter || "All";
    const topics = DATA.publicLawTopics.filter((t) => {
      if (catFilter !== "All" && !t.category.toLowerCase().includes(catFilter.toLowerCase())) return false;
      if (!q) return true;
      return t.title.toLowerCase().includes(q) || t.subtitle.toLowerCase().includes(q) || (t.detailedGuide || "").toLowerCase().includes(q);
    });

    const continueWatching = DATA.publicLawTopics.slice(0, 2);

    return `
      <div class="flex-1 pb-24">
        <!-- PDF 1 Page 26 Distinct Public Law Header -->
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-amber-500/30 gb-header sticky top-9 z-30">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-black text-amber-400">Public Law (आम नागरिक कानून)</div>
              <div class="text-[10px] gb-text-sub">अपने अधिकार जानो • हर नागरिक के लिए सरल कानूनी गाइड</div>
            </div>
          </div>
          <button onclick="GBApp.navigateTo('reels', { reelsCategory: 'public_law' })" class="px-2.5 py-1 rounded-full bg-amber-500 text-black text-[10px] font-black shadow">
            🎬 Public Reels
          </button>
        </div>

        <!-- Hero Banner (PDF 1 Page 26) -->
        <div class="relative dark-media-stage overflow-hidden border-b border-amber-500/30">
          <img src="${DATA.assets.bannerPublicLaw}" alt="Public Law Banner" class="w-full h-40 object-cover" />
          <div class="absolute inset-0 bg-gradient-to-t from-[#090614] via-black/55 to-black/25 p-3.5 flex flex-col justify-between text-white">
            <div class="flex justify-between items-center">
              <span class="px-2.5 py-0.5 rounded-full bg-amber-500 text-black font-black text-[9px]">CITIZEN RIGHTS HUB</span>
              <span class="px-2.5 py-0.5 rounded-full bg-purple-700/90 text-white font-bold text-[9px]">125 Audio • 320 Video • 240 PDF</span>
            </div>
            <div>
              <h1 class="text-lg font-black text-amber-300 leading-tight">जागरूक नागरिक, सशक्त भारत!</h1>
              <p class="text-[11px] text-gray-200 mt-0.5">FIR, Zero FIR, जमानत (Bail), पुलिस अधिकार, जमीन विवाद और महिला सुरक्षा की पूरी जानकारी</p>
            </div>
          </div>
        </div>

        <div class="p-3 space-y-4">
          <!-- Search Bar + Category Filter Pills -->
          <div class="space-y-2">
            <div class="flex items-center gap-2 px-3 py-2 rounded-xl gb-card border-amber-500/35">
              <span>🔍</span>
              <input type="text" value="${state.publicLawSearch || ""}" oninput="GBApp.setPublicLawSearch(this.value)" placeholder="आम कानून खोजें (FIR, बेल, पुलिस, जमीन विवाद, घरेलू हिंसा)..." class="bg-transparent flex-1 text-xs focus:outline-none" />
              ${state.publicLawSearch ? `<button onclick="GBApp.setPublicLawSearch('')" class="text-xs font-bold gb-text-muted">✕</button>` : ""}
            </div>
            <div class="flex gap-1.5 overflow-x-auto no-scrollbar">
              ${["All", "Most Popular", "Important", "Continue Watching"].map((c) => `
                <button onclick="GBApp.setPublicLawCategoryFilter('${c}')" class="px-3 py-1 rounded-full text-[10px] font-extrabold whitespace-nowrap border ${
                  catFilter === c ? "bg-amber-500 text-black border-amber-400" : "gb-surface"
                }">${c === "All" ? "🔥 सभी विषय (All Topics)" : c}</button>
              `).join("")}
            </div>
          </div>

          <!-- Continue Watching Section (PDF 1 Page 26) -->
          <div>
            <div class="flex items-center justify-between mb-2">
              <h3 class="text-xs font-black flex items-center gap-1.5">▶️ Continue Watching (जहाँ छोड़ा था वहीं से शुरू करें)</h3>
              <span class="text-[10px] gb-text-gold font-bold">Auto-Saved</span>
            </div>
            <div class="grid grid-cols-2 gap-2.5">
              ${continueWatching.map((cw) => `
                <div onclick="GBApp.navigateTo('public_law_detail', { publicTopicId: '${cw.id}' })" class="gb-card gb-card-interactive overflow-hidden cursor-pointer border-amber-500/35">
                  <div class="relative dark-media-stage">
                    <img src="${cw.image}" alt="${cw.title}" class="w-full h-24 object-cover" />
                    <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/25 to-transparent p-2 flex flex-col justify-between">
                      <span class="self-end px-1.5 py-0.5 rounded bg-black/75 text-amber-300 text-[8px] font-bold">⏱ ${cw.duration}</span>
                      <div class="text-xs font-black text-white leading-tight">${cw.title}</div>
                    </div>
                  </div>
                  <div class="p-2 space-y-1">
                    <div class="flex justify-between text-[9px] font-bold">
                      <span class="gb-text-sub">Progress</span>
                      <span class="gb-text-gold">${cw.progress}% Completed</span>
                    </div>
                    <div class="w-full h-1.5 bg-purple-950 rounded-full overflow-hidden">
                      <div class="h-full bg-amber-500 rounded-full" style="width:${cw.progress}%"></div>
                    </div>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>

          <!-- 6 Media Formats Strip for Public Law (PDF 1 Page 28-32) -->
          <div>
            <h3 class="text-xs font-black mb-2">🎧 Public Law के 6 अध्ययन माध्यम (Tap Format):</h3>
            <div class="grid grid-cols-6 gap-1.5 text-center">
              ${DATA.contentCategories.map((cat) => `
                <button onclick="GBApp.selectPublicLawTab('${cat.id}'); GBApp.openCategoryMedia('${cat.id}')" class="gb-card gb-card-interactive p-2 flex flex-col items-center">
                  <span class="text-lg">${cat.icon}</span>
                  <span class="text-[9px] font-extrabold mt-1 leading-tight">${cat.label.split(" ")[0]}</span>
                </button>
              `).join("")}
            </div>
          </div>

          <!-- Most Popular & Important Citizen Topics Grid (PDF 1 Page 26-27) -->
          <div>
            <div class="flex items-center justify-between mb-2">
              <h3 class="text-xs font-black">🏛️ Most Popular & Important Citizen Topics (${topics.length})</h3>
              <button onclick="GBApp.navigateTo('request_topic')" class="text-[10px] font-bold gb-text-accent underline">+ नया विषय सुझाएं</button>
            </div>
            <div class="space-y-2.5">
              ${topics.map((t) => `
                <div onclick="GBApp.navigateTo('public_law_detail', { publicTopicId: '${t.id}' })" class="gb-card gb-card-interactive overflow-hidden cursor-pointer border-purple-500/35">
                  <div class="grid grid-cols-12 items-center">
                    <div class="col-span-4 h-full relative dark-media-stage">
                      <img src="${t.image}" alt="${t.title}" class="w-full h-28 object-cover" />
                      <span class="absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded bg-black/80 text-amber-300 text-[8px] font-bold">▶ ${t.duration}</span>
                    </div>
                    <div class="col-span-8 p-3 space-y-1.5">
                      <div class="flex items-center justify-between">
                        <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-[8px] font-black">${t.category}</span>
                        <span class="text-[9px] font-bold gb-text-accent">6 Formats ›</span>
                      </div>
                      <h4 class="text-sm font-black leading-snug">${t.title}</h4>
                      <p class="text-[10px] gb-text-sub line-clamp-2">${t.subtitle}</p>
                      <div class="flex items-center gap-1.5 pt-1">
                        <span class="px-2 py-0.5 rounded gb-surface text-[9px] font-bold">🎧 Audio</span>
                        <span class="px-2 py-0.5 rounded gb-surface text-[9px] font-bold">🎬 Video</span>
                        <span class="px-2 py-0.5 rounded gb-surface text-[9px] font-bold">📄 PDF</span>
                        <span class="px-2 py-0.5 rounded gb-surface text-[9px] font-bold">📊 Slides</span>
                      </div>
                    </div>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function renderPublicLawDetailScreen() {
    const topic = getCurrentPublicTopicObj();
    return `
      <div class="flex-1 pb-24">
        <div class="relative dark-media-stage">
          <img src="${topic.heroImage}" alt="${topic.title}" class="w-full h-52 object-cover" />
          <div class="absolute inset-0 bg-gradient-to-t from-[#090614] via-black/40 to-black/30"></div>
          <div class="absolute top-3 left-3 right-3 flex justify-between items-center">
            <button onclick="GBApp.goBack()" class="w-9 h-9 rounded-full bg-black/70 border border-white/25 text-white flex items-center justify-center font-bold">←</button>
            <span class="px-2.5 py-1 rounded-full bg-black/70 text-amber-300 text-[10px] font-bold border border-amber-400/40">PUBLIC LAW • DEMO</span>
          </div>
          <div class="absolute bottom-3 left-4 right-4 text-center">
            <h1 class="text-2xl font-black text-amber-300 drop-shadow">${topic.title}</h1>
            <p class="text-xs text-gray-200 mt-1">${topic.subtitle}</p>
          </div>
        </div>

        <div class="p-3.5 space-y-4">
          <div>
            <h3 class="text-xs font-extrabold mb-2">इस विषय को किस माध्यम में पढ़ना/सुनना चाहते हैं? (6 Categories):</h3>
            <div class="grid grid-cols-3 gap-2">
              <button onclick="GBApp.navigateTo('audio_player')" class="gb-card gb-card-interactive p-3 text-center space-y-1">
                <div class="text-2xl">🎧</div>
                <div class="text-xs font-extrabold">Audio</div>
                <div class="text-[9px] gb-text-muted">ऑडियो सुनें</div>
              </button>
              <button onclick="GBApp.navigateTo('video_player')" class="gb-card gb-card-interactive p-3 text-center space-y-1">
                <div class="text-2xl">▶️</div>
                <div class="text-xs font-extrabold">Video</div>
                <div class="text-[9px] gb-text-muted">वीडियो देखें</div>
              </button>
              <button onclick="GBApp.navigateTo('pdf_viewer')" class="gb-card gb-card-interactive p-3 text-center space-y-1">
                <div class="text-2xl">📄</div>
                <div class="text-xs font-extrabold">PDF / Notes</div>
                <div class="text-[9px] gb-text-muted">लिखित नोट्स</div>
              </button>
              <button onclick="GBApp.navigateTo('mindmap_viewer')" class="gb-card gb-card-interactive p-3 text-center space-y-1">
                <div class="text-2xl">🕸️</div>
                <div class="text-xs font-extrabold">Mind Map</div>
                <div class="text-[9px] gb-text-muted">माइंड मैप</div>
              </button>
              <button onclick="GBApp.navigateTo('slides_viewer')" class="gb-card gb-card-interactive p-3 text-center space-y-1">
                <div class="text-2xl">🖼️</div>
                <div class="text-xs font-extrabold">Legal Slides</div>
                <div class="text-[9px] gb-text-muted">स्लाइड देखें</div>
              </button>
              <button onclick="GBApp.navigateTo('handwriting_viewer')" class="gb-card gb-card-interactive p-3 text-center space-y-1">
                <div class="text-2xl">✍️</div>
                <div class="text-xs font-extrabold">Handwriting</div>
                <div class="text-[9px] gb-text-muted">हस्तलिखित नोट्स</div>
              </button>
            </div>
          </div>

          <div class="gb-card p-4 space-y-2.5">
            <h3 class="text-sm font-extrabold gb-text-gold border-b border-purple-500/20 pb-2">
              इस विषय में आप जानेंगे (Key Legal Points):
            </h3>
            <div class="space-y-1.5">
              ${topic.points
                .map(
                  (pt) => `
                <div class="flex items-start gap-2 text-xs">
                  <span class="gb-text-gold font-bold shrink-0">✔</span>
                  <span class="gb-text-sub leading-snug">${pt}</span>
                </div>
              `
                )
                .join("")}
            </div>
            <div class="p-3 rounded-xl gb-surface text-xs gb-text-sub leading-relaxed mt-2">
              ${topic.detailedGuide}
            </div>
            <button onclick="GBApp.markContentCompleted('audio', 'publicLaw', '${topic.title}')" class="w-full py-2.5 gb-btn-primary text-xs mt-2">
              ✓ Mark Topic Completed (Update Progress)
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // Media Players (Audio, Video, Slides, PDF, MindMap, Handwriting)
  function renderAudioPlayerScreen() {
    const act = getCurrentActObj();
    const sec = getCurrentSectionObj();
    const pct = Math.min(100, Math.round((state.currentTimeSec / state.totalTimeSec) * 100));
    const curMin = String(Math.floor(state.currentTimeSec / 60)).padStart(2, "0");
    const curSec = String(state.currentTimeSec % 60).padStart(2, "0");

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2 min-w-0">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold shrink-0">←</button>
            <div class="min-w-0">
              <div class="text-xs font-extrabold truncate">${act.shortTitle} — Audio Lecture</div>
              <div class="text-[10px] gb-text-accent truncate">${sec.code}: ${sec.titleHindi}</div>
            </div>
          </div>
          <button onclick="GBApp.openCategoryMedia('slides', '${sec.id}')" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-bold gb-text-accent shrink-0">🖼️ Legal Slide ›</button>
        </div>

        <div class="p-3.5 space-y-3.5">
          <div class="dark-media-stage rounded-2xl overflow-hidden border border-purple-400/40 relative bg-black shadow-xl">
            <img src="${DATA.assets.playerScene184}" alt="Audio Lecture" class="w-full h-48 object-cover" />
            <div class="absolute bottom-2 right-2 px-2.5 py-1 rounded-full bg-black/80 text-[10px] text-emerald-300 font-bold border border-emerald-400/40">
              ${state.isPlaying ? "🔊 Playing Audio..." : "⏸ Paused"}
            </div>
          </div>

          <div class="gb-card p-3 space-y-1.5">
            <div class="text-xs font-extrabold">${sec.code} — ${sec.titleHindi}</div>
            <p class="text-[11px] gb-text-sub leading-relaxed">${sec.summaryHindi}</p>
          </div>

          <div>
            <div class="flex justify-between text-[11px] font-bold mb-1">
              <span id="player-time-current">${curMin}:${curSec}</span>
              <span class="gb-text-accent">${pct}% Completed</span>
              <span>1:12:30</span>
            </div>
            <div onclick="GBApp.seekRelative(60)" class="w-full h-2 bg-purple-950 rounded-full overflow-hidden cursor-pointer">
              <div class="h-full bg-purple-500 rounded-full" style="width:${pct}%"></div>
            </div>
          </div>

          <div class="flex items-center justify-around py-1.5">
            <button onclick="GBApp.seekRelative(-10)" class="w-10 h-10 rounded-full gb-surface font-bold text-xs">-10s</button>
            <button onclick="GBApp.navigateAdjacentSection(-1)" class="w-10 h-10 rounded-full gb-surface font-bold text-sm">⏮</button>
            <button onclick="GBApp.togglePlay()" class="w-14 h-14 rounded-full gb-btn-primary text-xl flex items-center justify-center shadow-xl">
              ${state.isPlaying ? "⏸" : "▶"}
            </button>
            <button onclick="GBApp.navigateAdjacentSection(1)" class="w-10 h-10 rounded-full gb-surface font-bold text-sm">⏭</button>
            <button onclick="GBApp.seekRelative(10)" class="w-10 h-10 rounded-full gb-surface font-bold text-xs">+10s</button>
          </div>

          <div class="grid grid-cols-4 gap-2 text-center">
            <button onclick="GBApp.cycleSpeed()" class="gb-card p-2 text-[10px] font-bold">⏱️ ${state.playbackSpeed}x</button>
            <button onclick="GBApp.cycleSleepTimer()" class="gb-card p-2 text-[10px] font-bold">🌙 ${state.sleepTimerMin || "Off"}m</button>
            <button onclick="GBApp.toggleBookmarkSection('${sec.id}')" class="gb-card p-2 text-[10px] font-bold">🔖 Save</button>
            <button onclick="GBApp.markContentCompleted('audio', '${act.id}', '${sec.code} Audio')" class="gb-card p-2 text-[10px] font-bold gb-text-accent">✓ Done</button>
          </div>
        </div>
      </div>
    `;
  }

  function renderVideoPlayerScreen() {
    const act = getCurrentActObj();
    const sec = getCurrentSectionObj();
    const pct = Math.min(100, Math.round((state.currentTimeSec / state.totalTimeSec) * 100));

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2 min-w-0">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold shrink-0">←</button>
            <div class="min-w-0">
              <div class="text-xs font-extrabold truncate">${act.shortTitle} — Video Lecture</div>
              <div class="text-[10px] gb-text-accent truncate">${sec.code}: ${sec.titleHindi}</div>
            </div>
          </div>
          <button onclick="GBApp.toggleVideoLandscape()" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-bold">
            ${state.videoLandscape ? "📱 Portrait" : "🔄 Landscape"}
          </button>
        </div>

        <div class="p-3.5 space-y-3">
          <div class="dark-media-stage rounded-2xl overflow-hidden border border-purple-400/50 bg-black relative shadow-2xl">
            <img src="${DATA.assets.playerScene184}" alt="Video Frame" class="w-full ${state.videoLandscape ? "h-72" : "h-52"} object-cover" />
            <div class="absolute inset-0 bg-black/35 flex flex-col justify-between p-3 text-white">
              <div class="flex justify-between items-center text-[10px]">
                <span class="px-2 py-0.5 rounded bg-black/70 text-amber-300 font-bold">DEMO VIDEO • ${state.videoQuality}</span>
                <span class="px-2 py-0.5 rounded bg-black/70">CC: ${state.videoSubtitles}</span>
              </div>
              <div class="flex items-center justify-center gap-6 my-auto">
                <button onclick="GBApp.seekRelative(-10)" class="px-3 py-1.5 rounded-full bg-black/65 text-xs font-bold">« 10s</button>
                <button onclick="GBApp.togglePlay()" class="w-14 h-14 rounded-full bg-purple-600/90 border-2 border-white flex items-center justify-center text-2xl shadow-xl">
                  ${state.isPlaying ? "⏸" : "▶"}
                </button>
                <button onclick="GBApp.seekRelative(10)" class="px-3 py-1.5 rounded-full bg-black/65 text-xs font-bold">10s »</button>
              </div>
              <div class="text-center text-[11px] bg-black/75 py-1 px-2 rounded">
                💬 [Subtitle] ${sec.code}: ${sec.titleHindi}
              </div>
            </div>
          </div>

          <div class="gb-card p-3.5 space-y-2">
            <div class="flex items-center justify-between">
              <div class="text-xs font-extrabold">${sec.code} — ${sec.titleHindi}</div>
              <span class="text-[10px] gb-text-accent font-bold">${pct}% Watched</span>
            </div>
            <p class="text-xs gb-text-sub leading-relaxed">${sec.summaryHindi}</p>
            <div class="flex gap-2 pt-2">
              <button onclick="GBApp.markContentCompleted('video', '${act.id}', '${sec.code} Video')" class="flex-1 py-2 gb-btn-primary text-xs">
                ✓ Mark Video Completed
              </button>
              <button onclick="GBApp.openCategoryMedia('slides')" class="px-3 py-2 gb-btn-outline text-xs">
                🖼️ View Slides
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function renderSlidesViewerScreen() {
    const slide = DATA.slidesDeck[state.slideIndex % DATA.slidesDeck.length];
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-xs font-extrabold">🖼️ Legal Slides (Demo Presentation)</div>
              <div class="text-[10px] gb-text-sub">${slide.section}</div>
            </div>
          </div>
          <span class="px-2.5 py-1 rounded-full gb-surface-alt text-xs font-extrabold gb-text-accent">${slide.slidesCount}</span>
        </div>

        <div class="p-3 space-y-3">
          <div class="rounded-2xl overflow-hidden border-2 border-amber-600/50 shadow-xl bg-[#f7eed7]">
            <img src="${slide.image}" alt="${slide.heading}" class="w-full h-auto object-contain" />
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div class="text-xs font-extrabold gb-text-accent">${slide.section}</div>
            <h3 class="text-sm font-black">${slide.heading}</h3>
            <p class="text-xs gb-text-sub">${slide.subtitle}</p>
            <div class="grid grid-cols-2 gap-2 pt-1">
              ${slide.cards
                .map(
                  (c) => `
                <div class="p-2.5 rounded-xl gb-surface space-y-1">
                  <div class="text-[11px] font-extrabold gb-text-gold">${c.title}</div>
                  <div class="text-[10px] gb-text-sub leading-snug">${c.body}</div>
                </div>
              `
                )
                .join("")}
            </div>
          </div>

          <div class="flex items-center justify-between gap-2">
            <button onclick="GBApp.changeSlide(-1)" class="px-4 py-2.5 gb-btn-outline text-xs">← Prev</button>
            <button onclick="GBApp.markContentCompleted('slides', '${state.selectedActId}', 'Slide ${slide.num}')" class="px-3 py-2.5 gb-btn-primary text-xs">✓ Mark Slide Done</button>
            <button onclick="GBApp.changeSlide(1)" class="px-4 py-2.5 gb-btn-outline text-xs">Next →</button>
          </div>
        </div>
      </div>
    `;
  }

  function renderPdfViewerScreen() {
    const pageObj = DATA.pdfQuizPages[state.pdfPageIndex % DATA.pdfQuizPages.length];
    const sec = getCurrentSectionObj();
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-xs font-extrabold">📄 PDF / Written Notes (Demo)</div>
              <div class="text-[10px] gb-text-sub">${pageObj.title}</div>
            </div>
          </div>
          <a href="${DATA.assets.samplePdf}" download="GB_Legal_Mind_Demo_Notes.pdf" onclick="GBApp.showToast('📄 Downloading Demo PDF...')" class="px-2.5 py-1 rounded-full bg-emerald-600 text-white text-[10px] font-bold">
            ⬇ PDF
          </a>
        </div>

        <div class="p-3 space-y-3">
          <div class="gb-card p-3.5 space-y-2">
            <span class="px-2 py-0.5 rounded gb-surface-alt text-[10px] font-extrabold gb-text-accent">WRITTEN NOTES • PAGE ${pageObj.page}/${pageObj.totalPages}</span>
            <h3 class="text-sm font-black">${sec.code}: ${sec.titleHindi}</h3>
            <p class="text-xs gb-text-sub leading-relaxed whitespace-pre-line">${sec.saralTextHindi || sec.summaryHindi}</p>
          </div>

          <div class="gb-card p-3.5 space-y-3">
            <div class="text-xs font-extrabold gb-text-gold">📝 अभ्यास प्रश्न (Interactive PDF Quiz):</div>
            ${pageObj.questions
              .map((q) => {
                const chosen = state.pdfAnswers[q.id];
                return `
                  <div class="p-3 rounded-xl gb-surface space-y-2">
                    <div class="text-xs font-extrabold leading-snug">${q.q}</div>
                    <div class="space-y-1.5">
                      ${q.options
                        .map((opt, oIdx) => {
                          const isSelected = chosen === oIdx;
                          const isRight = oIdx === q.correctIndex;
                          let cls = "gb-card";
                          if (isSelected && isRight) cls = "bg-emerald-600 text-white font-bold border-emerald-400";
                          else if (isSelected && !isRight) cls = "bg-rose-600 text-white font-bold border-rose-400";
                          return `
                            <button onclick="GBApp.answerPdfQuestion('${q.id}', ${oIdx})" class="w-full p-2 rounded-lg border text-left text-xs flex justify-between ${cls}">
                              <span>${opt}</span>
                              <span>${isSelected ? (isRight ? "✓" : "✗") : ""}</span>
                            </button>
                          `;
                        })
                        .join("")}
                    </div>
                    <div class="text-[11px] gb-text-sub pt-1 border-t border-purple-500/20">
                      <strong class="gb-text-accent">व्याख्या:</strong> ${q.explanation}
                    </div>
                  </div>
                `;
              })
              .join("")}
          </div>

          <div class="rounded-2xl overflow-hidden border border-purple-400/40">
            <img src="${pageObj.image}" alt="PDF Page" class="w-full h-auto object-contain" />
          </div>

          <div class="flex items-center justify-between gap-2">
            <button onclick="GBApp.changePdfPage(-1)" class="px-4 py-2.5 gb-btn-outline text-xs">← Prev Page</button>
            <button onclick="GBApp.markContentCompleted('pdf', '${state.selectedActId}', 'PDF Notes')" class="px-3 py-2.5 gb-btn-primary text-xs">✓ Mark PDF Read</button>
            <button onclick="GBApp.changePdfPage(1)" class="px-4 py-2.5 gb-btn-outline text-xs">Next Page →</button>
          </div>
        </div>
      </div>
    `;
  }

  function renderMindMapViewerScreen() {
    const activeNode = DATA.mindMapNodes.find((n) => n.id === state.mindMapSelectedNode) || DATA.mindMapNodes[0];
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-xs font-extrabold">🕸️ Legal Mind Map (Demo)</div>
              <div class="text-[10px] gb-text-sub">Interactive Visual Hierarchy</div>
            </div>
          </div>
          <div class="flex items-center gap-1">
            <button onclick="GBApp.zoomMindMap(-0.15)" class="w-7 h-7 rounded gb-surface font-bold text-xs">−</button>
            <span class="text-[10px] font-bold px-1">${Math.round(state.mindMapZoom * 100)}%</span>
            <button onclick="GBApp.zoomMindMap(0.15)" class="w-7 h-7 rounded gb-surface font-bold text-xs">+</button>
          </div>
        </div>

        <div class="p-3 space-y-3">
          <div class="rounded-2xl overflow-auto border border-purple-400/40 bg-white p-1.5 shadow-lg">
            <img src="${DATA.assets.mindmapContract}" alt="Mind Map" class="w-full h-auto object-contain" style="transform: scale(${state.mindMapZoom}); transform-origin: top left;" />
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div class="text-xs font-extrabold gb-text-gold">शाखा चुनें (Select Mind Map Node):</div>
            <div class="grid grid-cols-2 gap-1.5">
              ${DATA.mindMapNodes
                .map(
                  (n) => `
                <button onclick="GBApp.selectMindMapNode('${n.id}')" class="p-2 rounded-xl text-left text-[11px] font-bold border ${
                    n.id === activeNode.id ? "gb-tab-active" : "gb-surface"
                  }">${n.num}</button>
              `
                )
                .join("")}
            </div>
            <div class="p-3 rounded-xl gb-surface space-y-1">
              <div class="text-xs font-extrabold gb-text-accent">${activeNode.num}</div>
              <ul class="list-disc list-inside text-xs gb-text-sub space-y-1">
                ${activeNode.points.map((pt) => `<li>${pt}</li>`).join("")}
              </ul>
            </div>
            <button onclick="GBApp.markContentCompleted('mindmap', '${state.selectedActId}', 'Mind Map')" class="w-full py-2.5 gb-btn-primary text-xs">
              ✓ Mark Mind Map Completed
            </button>
          </div>
        </div>
      </div>
    `;
  }

  function renderHandwritingViewerScreen() {
    const book = DATA.handwritingNotes[0];
    const page = book.pages[state.hwPageIndex % book.pages.length];

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-xs font-extrabold">✍️ Handwriting Notes (Demo)</div>
              <div class="text-[10px] gb-text-sub">${book.subject}</div>
            </div>
          </div>
          <button onclick="GBApp.toggleHwHighlight()" class="px-2.5 py-1 rounded-full text-[10px] font-bold ${
            state.hwHighlight ? "bg-amber-400 text-black" : "gb-surface"
          }">
            🖍️ Highlight ${state.hwHighlight ? "ON" : "OFF"}
          </button>
        </div>

        <div class="p-3 space-y-3">
          <div class="flex items-center justify-between">
            <div class="flex gap-2">
              ${book.pages
                .map(
                  (p, idx) => `
                <button onclick="GBApp.setHwPage(${idx})" class="px-3 py-1 rounded-full text-xs font-bold border ${
                    idx === state.hwPageIndex ? "gb-tab-active" : "gb-surface"
                  }">Page ${p.pageNum}</button>
              `
                )
                .join("")}
            </div>
            <span class="text-[11px] font-bold gb-text-gold">${page.date}</span>
          </div>

          <div class="handwriting-paper rounded-2xl p-4 pl-6 shadow-xl border-2 border-amber-700/40">
            <div class="border-b-2 border-red-700/40 pb-2 mb-3">
              <h2 class="text-sm font-black text-indigo-950">${page.heading}</h2>
            </div>
            <div class="space-y-1.5 text-[13px] font-medium text-slate-900">
              ${page.lines
                .map((line) => {
                  const isStar = line.startsWith("★");
                  return `<div class="${isStar && state.hwHighlight ? "bg-yellow-200/90 px-1.5 rounded font-bold text-indigo-950" : isStar ? "font-bold text-indigo-950" : "pl-2"}">${line}</div>`;
                })
                .join("")}
            </div>
          </div>

          <button onclick="GBApp.markContentCompleted('handwriting', '${state.selectedActId}', 'Handwritten Notes')" class="w-full py-2.5 gb-btn-primary text-xs">
            ✓ Mark Handwritten Notes Completed
          </button>
        </div>
      </div>
    `;
  }
  // =========================================================================
  // SCREEN RENDERERS — PART B (Legal Shabdawali, Audio Learning, MCQ & Bare Act Library)
  // =========================================================================

  // Requirement #6: Legal Shabdawali Hub (PDF 3 Pages 1–2)
  function renderShabdawaliScreen() {
    const mainCats = DATA.shabdawaliCategories.filter((c) => c.id !== "all");
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">⚖️ Dictionary & Shabdawali</div>
              <div class="text-[10px] gb-text-sub">Law Terms, English Speaking & Audio Learning</div>
            </div>
          </div>
          <button onclick="GBApp.openShabdawaliCategoryList('all')" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-extrabold gb-text-accent">
            All Words ›
          </button>
        </div>

        <div class="p-3 space-y-3.5">
          <!-- Search Bar with Mic -->
          <div class="flex items-center gap-2 px-3.5 py-2.5 rounded-2xl gb-card border-purple-400/40">
            <span>🔍</span>
            <input type="text" value="${state.shabdawaliQuery}" oninput="GBApp.setShabdawaliSearch(this.value); if(this.value.length>1) GBApp.navigateTo('shabdawali_list')" placeholder="Search words... embarrassing, affidavit, judgement" class="bg-transparent flex-1 text-xs focus:outline-none" />
            <button onclick="GBApp.showToast('🎙️ Voice Search Demo: Speak a word')" class="w-7 h-7 rounded-full gb-surface-alt flex items-center justify-center text-xs">🎙️</button>
          </div>

          <!-- Audio Learning Banner (PDF 3 Page 2) -->
          <div onclick="GBApp.navigateTo('audio_learning')" class="gb-card gb-card-interactive overflow-hidden border-purple-400/60 cursor-pointer">
            <img src="${DATA.assets.bannerAudioLearning || DATA.assets.bannerDhara2}" alt="Audio Learning" class="w-full h-28 object-cover" />
            <div class="p-2.5 flex items-center justify-between gb-surface-alt">
              <div>
                <div class="text-xs font-black">🎧 Audio Learning — शब्दावली सुनें, कहीं भी, कभी भी</div>
                <div class="text-[10px] gb-text-sub">Listen • Learn • Remember (Auto-Play & Playlist)</div>
              </div>
              <span class="px-3 py-1.5 gb-btn-primary text-[10px] shrink-0">▶ Tap to Listen ›</span>
            </div>
          </div>

          <!-- Daily Features: आज की कानूनी लाइन & आज के 10 शब्द (PDF 3 Page 5) -->
          <div class="grid grid-cols-2 gap-2.5">
            <button onclick="GBApp.navigateTo('kanooni_lines')" class="gb-card gb-card-interactive p-3 text-left border-amber-400/50">
              <div class="flex justify-between items-center">
                <span class="text-xl">⚖️</span>
                <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 text-[9px] font-bold">128 Lines</span>
              </div>
              <div class="text-xs font-extrabold mt-1.5">आज की कानूनी लाइन</div>
              <div class="text-[10px] gb-text-sub mt-0.5">Justice delayed is justice denied...</div>
            </button>

            <button onclick="GBApp.navigateTo('daily_10_words')" class="gb-card gb-card-interactive p-3 text-left border-emerald-400/50">
              <div class="flex justify-between items-center">
                <span class="text-xl">🔥</span>
                <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-bold">Day ${state.daily10StreakDays} Streak</span>
              </div>
              <div class="text-xs font-extrabold mt-1.5">आज के 10 शब्द</div>
              <div class="text-[10px] gb-text-sub mt-0.5">प्रगति: ${state.daily10LearnedIds.length} / 10 शब्द सीखे</div>
            </button>
          </div>

          <!-- Featured Legal Shabdawali Large Card (PDF 3 Page 2) -->
          <div onclick="GBApp.openShabdawaliCategoryList('legal')" class="gb-card gb-card-interactive p-4 border-amber-400/50 flex items-center justify-between gap-3 cursor-pointer">
            <div class="space-y-1">
              <span class="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-[10px] font-extrabold">5320 Words (Demo)</span>
              <h3 class="text-lg font-black gb-text-gold">Legal Shabdawali</h3>
              <p class="text-xs gb-text-sub">Law Terms | Meanings | Examples in Simple Language</p>
            </div>
            <span class="w-10 h-10 rounded-full gb-btn-gold flex items-center justify-center text-base shrink-0">›</span>
          </div>

          <!-- Remaining 8 Category Cards Grid (PDF 3 Page 2) -->
          <div>
            <h3 class="text-xs font-extrabold mb-2">Main Categories (सभी श्रेणियां):</h3>
            <div class="grid grid-cols-2 gap-2.5">
              ${mainCats
                .filter((c) => c.id !== "legal")
                .map(
                  (c) => `
                <button onclick="GBApp.openShabdawaliCategoryList('${c.id}')" class="gb-card gb-card-interactive p-3 text-left flex flex-col justify-between">
                  <div>
                    <div class="text-2xl mb-1">${c.icon}</div>
                    <div class="text-xs font-extrabold">${c.name}</div>
                    <div class="text-[10px] gb-text-sub mt-0.5">${c.subtitle}</div>
                  </div>
                  <div class="flex items-center justify-between mt-2.5 pt-1.5 border-t border-purple-500/20">
                    <span class="px-2 py-0.5 rounded-full gb-surface-alt text-[9px] font-bold gb-text-accent">${c.badgeWords}</span>
                    <span class="w-6 h-6 rounded-full gb-surface flex items-center justify-center text-xs font-bold">›</span>
                  </div>
                </button>
              `
                )
                .join("")}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // Shabdawali Word List + Range Tabs (1-500 | 501-1000 | 1001-1500 | More) + Short/Detailed View + Sort & Filter Modal (PDF 3 Pages 3 & 6)
  function renderShabdawaliListScreen() {
    const q = state.shabdawaliQuery.trim().toLowerCase();
    let list = DATA.shabdawali.filter((w) => {
      if (state.shabdawaliSavedOnly && !state.favouriteWords.includes(w.id)) return false;
      if (state.shabdawaliCategory !== "all" && w.category !== state.shabdawaliCategory) return false;
      if (state.shabdawaliNewOnly && !w.isNew) return false;
      if (state.shabdawaliLetterFilter !== "ALL" && !w.term.toUpperCase().startsWith(state.shabdawaliLetterFilter)) return false;
      if (!q) return true;
      return (
        w.term.toLowerCase().includes(q) ||
        w.hindiShort.toLowerCase().includes(q) ||
        w.meaning.toLowerCase().includes(q)
      );
    });

    if (state.shabdawaliSortOrder === "num_desc") list = list.slice().reverse();
    else if (state.shabdawaliSortOrder === "alpha_asc") list = list.slice().sort((a, b) => a.term.localeCompare(b.term));
    else if (state.shabdawaliSortOrder === "alpha_desc") list = list.slice().sort((a, b) => b.term.localeCompare(a.term));

    const catObj = DATA.shabdawaliCategories.find((c) => c.id === state.shabdawaliCategory) || DATA.shabdawaliCategories[0];
    const letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P"];

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">${catObj.name}</div>
              <div class="text-[10px] gb-text-sub">Total Words: ${catObj.badgeWords}</div>
            </div>
          </div>
          <button onclick="GBApp.toggleShabdawaliFilterModal(true)" class="px-3 py-1.5 rounded-xl gb-surface-alt text-xs font-extrabold gb-text-accent flex items-center gap-1">
            <span>⚙️ Sort & Filter</span>
          </button>
        </div>

        <div class="p-3 space-y-3">
          <!-- Range Tabs: 1-500 | 501-1000 | 1001-1500 | More (PDF 3 Page 3) -->
          <div class="grid grid-cols-4 gap-1.5">
            ${["1 - 500", "501 - 1000", "1001 - 1500", "More"]
              .map(
                (rng) => `
              <button onclick="GBApp.setShabdawaliRange('${rng}')" class="py-1.5 rounded-lg text-[11px] font-bold border ${
                  state.shabdawaliRange === rng ? "gb-tab-active" : "gb-surface"
                }">${rng}</button>
            `
              )
              .join("")}
          </div>

          <!-- Short View vs Detailed View Toggle (PDF 3 Page 3) -->
          <div class="grid grid-cols-2 gap-1.5 p-1 rounded-xl gb-surface">
            <button onclick="GBApp.setShabdawaliViewMode('short')" class="py-2 rounded-lg text-xs font-bold ${
              state.shabdawaliViewMode === "short" ? "gb-tab-active" : ""
            }">☰ Short View</button>
            <button onclick="GBApp.setShabdawaliViewMode('detailed')" class="py-2 rounded-lg text-xs font-bold ${
              state.shabdawaliViewMode === "detailed" ? "gb-tab-active" : ""
            }">☷ Detailed View</button>
          </div>

          <!-- Search Input -->
          <div class="flex items-center gap-2 px-3 py-2 rounded-xl gb-card">
            <span>🔍</span>
            <input type="text" value="${state.shabdawaliQuery}" oninput="GBApp.setShabdawaliSearch(this.value)" placeholder="Filter words in this list..." class="bg-transparent flex-1 text-xs focus:outline-none" />
          </div>

          <!-- Words List -->
          <div class="space-y-2">
            ${
              list.length === 0
                ? `<div class="gb-card p-6 text-center text-xs gb-text-muted">कोई शब्द नहीं मिला। <button onclick="GBApp.resetShabdawaliFilters()" class="underline gb-text-accent font-bold ml-1">Reset Filters</button></div>`
                : list
                    .map((w, idx) => {
                      const isFav = state.favouriteWords.includes(w.id);
                      return `
                        <div onclick="GBApp.openWordDetail('${w.id}')" class="gb-card gb-card-interactive p-3.5 cursor-pointer space-y-1.5">
                          <div class="flex items-center justify-between gap-2">
                            <div class="flex items-center gap-3 min-w-0">
                              <span class="text-sm font-black gb-text-gold w-6">${w.num || idx + 1}</span>
                              <div class="min-w-0">
                                <div class="text-sm font-extrabold flex items-center gap-1.5">
                                  <span>${w.term}</span>
                                  ${w.isNew ? `<span class="px-1.5 py-0.5 rounded bg-rose-600 text-white text-[8px] font-bold">NEW</span>` : ""}
                                </div>
                                <div class="text-xs gb-text-sub">${w.hindiShort}</div>
                              </div>
                            </div>
                            <div class="flex items-center gap-2 shrink-0">
                              <button onclick="GBApp.toggleFavouriteWord('${w.id}', event)" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center text-xs">
                                ${isFav ? "❤️" : "🤍"}
                              </button>
                              <button onclick="event.stopPropagation(); GBApp.speakWord('${w.id}')" class="w-8 h-8 rounded-full gb-surface-alt flex items-center justify-center text-xs">
                                🔊
                              </button>
                            </div>
                          </div>
                          ${
                            state.shabdawaliViewMode === "detailed"
                              ? `
                            <div class="pt-2 mt-1 border-t border-purple-500/20 text-xs space-y-1">
                              <div><strong class="gb-text-accent">अर्थ:</strong> <span class="gb-text-sub">${w.meaning}</span></div>
                              <div><strong class="gb-text-gold">उपयोग:</strong> <span class="gb-text-sub">${w.example}</span></div>
                              <div class="text-[10px] text-emerald-400 font-semibold">Synonyms: ${w.synonyms.join(", ")}</div>
                            </div>
                          `
                              : ""
                          }
                        </div>
                      `;
                    })
                    .join("")
            }
          </div>
        </div>

        <!-- Sort & Filter Modal (PDF 3 Page 6) -->
        ${
          state.shabdawaliFilterModalOpen
            ? `
          <div class="fixed inset-0 z-50 bg-black/80 flex items-end justify-center p-2">
            <div class="gb-card w-full max-w-[430px] p-4 space-y-3.5 border-purple-400 max-h-[88vh] overflow-y-auto">
              <div class="flex items-center justify-between border-b border-purple-500/20 pb-2">
                <div>
                  <h3 class="text-base font-black">⚙️ Sort & Filter</h3>
                  <div class="text-[10px] gb-text-sub">Set the order to view words</div>
                </div>
                <button onclick="GBApp.toggleShabdawaliFilterModal(false)" class="w-8 h-8 rounded-full gb-surface font-bold">✕</button>
              </div>

              <!-- 1. Numbering se Order -->
              <div class="p-3 rounded-xl gb-surface space-y-2">
                <div class="text-xs font-extrabold">1. Numbering se Order (View words in number order)</div>
                <div class="grid grid-cols-2 gap-2">
                  <button onclick="GBApp.setShabdawaliSort('num_asc')" class="p-2.5 rounded-xl border text-left text-xs ${
                    state.shabdawaliSortOrder === "num_asc" ? "gb-tab-active" : "gb-card"
                  }">
                    <div class="font-black">1 → 3000</div>
                    <div class="text-[10px] gb-text-muted">From first to last</div>
                  </button>
                  <button onclick="GBApp.setShabdawaliSort('num_desc')" class="p-2.5 rounded-xl border text-left text-xs ${
                    state.shabdawaliSortOrder === "num_desc" ? "gb-tab-active" : "gb-card"
                  }">
                    <div class="font-black">3000 → 1</div>
                    <div class="text-[10px] gb-text-muted">From last to first</div>
                  </button>
                </div>
              </div>

              <!-- 2. Akshar se Order -->
              <div class="p-3 rounded-xl gb-surface space-y-2">
                <div class="text-xs font-extrabold">2. Akshar se Order (Alphabetical order)</div>
                <div class="grid grid-cols-2 gap-2">
                  <button onclick="GBApp.setShabdawaliSort('alpha_asc')" class="p-2.5 rounded-xl border text-left text-xs ${
                    state.shabdawaliSortOrder === "alpha_asc" ? "gb-tab-active" : "gb-card"
                  }">
                    <div class="font-black">A → Z</div>
                    <div class="text-[10px] gb-text-muted">From A to Z</div>
                  </button>
                  <button onclick="GBApp.setShabdawaliSort('alpha_desc')" class="p-2.5 rounded-xl border text-left text-xs ${
                    state.shabdawaliSortOrder === "alpha_desc" ? "gb-tab-active" : "gb-card"
                  }">
                    <div class="font-black">Z → A</div>
                    <div class="text-[10px] gb-text-muted">From Z to A</div>
                  </button>
                </div>
              </div>

              <!-- 3. Kisi Akshar se Shabd Dikhayein -->
              <div class="p-3 rounded-xl gb-surface space-y-2">
                <div class="text-xs font-extrabold">3. Kisi Akshar se Shabd Dikhayein</div>
                <div class="flex flex-wrap gap-1.5">
                  ${letters
                    .map(
                      (l) => `
                    <button onclick="GBApp.setShabdawaliLetter('${l}')" class="w-8 h-8 rounded-lg text-xs font-bold border ${
                        state.shabdawaliLetterFilter === l ? "gb-tab-active" : "gb-card"
                      }">${l}</button>
                  `
                    )
                    .join("")}
                </div>
              </div>

              <!-- 4. Naye Shabd (Newly Added) -->
              <div class="p-3 rounded-xl gb-surface flex items-center justify-between">
                <div>
                  <div class="text-xs font-extrabold">4. Naye Shabd (Newly Added)</div>
                  <div class="text-[10px] gb-text-muted">Show recently added words</div>
                </div>
                <button onclick="GBApp.toggleShabdawaliNewOnly()" class="px-3 py-1 rounded-full text-xs font-extrabold ${
                  state.shabdawaliNewOnly ? "bg-purple-600 text-white" : "gb-card"
                }">
                  NEW ${state.shabdawaliNewOnly ? "ON" : "OFF"}
                </button>
              </div>

              <div class="flex gap-2 pt-1">
                <button onclick="GBApp.resetShabdawaliFilters()" class="flex-1 py-2.5 gb-btn-outline text-xs">🔄 Reset</button>
                <button onclick="GBApp.toggleShabdawaliFilterModal(false)" class="flex-1 py-2.5 gb-btn-primary text-xs">✓ Apply</button>
              </div>
            </div>
          </div>
        `
            : ""
        }
      </div>
    `;
  }

  // Word Detail Screen (PDF 3 Page 4)
  function renderShabdawaliDetailScreen() {
    const w = DATA.shabdawali.find((x) => x.id === state.selectedWordId) || DATA.shabdawali[0];
    const isFav = state.favouriteWords.includes(w.id);

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
          <span class="text-base font-black gb-text-gold">${w.num || 144}</span>
          <button onclick="GBApp.toggleFavouriteWord('${w.id}')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center text-sm">
            ${isFav ? "❤️" : "🤍"}
          </button>
        </div>

        <div class="p-3.5 space-y-3.5">
          <div class="gb-card p-5 space-y-4 border-purple-400/50">
            <div class="flex items-start justify-between gap-3">
              <div>
                <h1 class="text-2xl font-black">${w.term}</h1>
                <div class="text-sm font-extrabold gb-text-gold mt-1">{ ${w.hindiShort} }</div>
              </div>
              <button onclick="GBApp.speakWord('${w.id}')" class="w-12 h-12 rounded-full gb-surface-alt border border-purple-400 flex items-center justify-center text-xl shrink-0">
                🔊
              </button>
            </div>

            <div class="border-t border-purple-500/20 pt-3 space-y-1">
              <div class="text-xs font-extrabold text-sky-400">अर्थ (Meaning) :</div>
              <p class="text-sm gb-text-sub leading-relaxed">${w.meaning}</p>
            </div>

            <div class="border-t border-purple-500/20 pt-3 space-y-1">
              <div class="text-xs font-extrabold text-sky-400">उपयोग (Example) :</div>
              <p class="text-sm gb-text-sub leading-relaxed">${w.example}</p>
              ${w.exampleEng ? `<p class="text-xs gb-text-muted mt-1">${w.exampleEng}</p>` : ""}
            </div>

            <div class="border-t border-purple-500/20 pt-3 space-y-1">
              <div class="text-xs font-extrabold text-emerald-400">Synonyms :</div>
              <p class="text-xs font-semibold gb-text-sub">${w.synonyms.join(", ")}</p>
            </div>
          </div>

          <div class="grid grid-cols-3 gap-2">
            <button onclick="GBApp.navigateAdjacentWord(-1)" class="py-3 gb-btn-outline text-xs">‹ Previous</button>
            <button onclick="GBApp.showToast('📤 Word Card Shared!')" class="py-3 gb-btn-outline text-xs">🔗 Share</button>
            <button onclick="GBApp.navigateAdjacentWord(1)" class="py-3 gb-btn-primary text-xs">Next ›</button>
          </div>
        </div>
      </div>
    `;
  }

  // आज की कानूनी लाइन Screen (PDF 3 Page 5 Left)
  function renderKanooniLinesScreen() {
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div class="text-sm font-extrabold">⚖️ आज की कानूनी लाइन</div>
          </div>
          <span class="px-2.5 py-1 rounded-lg gb-surface-alt text-[10px] font-extrabold gb-text-gold">कुल लाइनें: 128</span>
        </div>

        <div class="p-3 space-y-2.5">
          ${DATA.kanooniLines
            .map(
              (kl) => `
            <div class="gb-card p-3.5 flex items-center justify-between gap-2.5">
              <div class="flex items-start gap-3 min-w-0">
                <span class="text-base font-black gb-text-gold mt-1">${kl.num}</span>
                <div class="space-y-0.5 min-w-0">
                  <div class="text-[10px] gb-text-muted">📅 ${kl.date}</div>
                  <div class="text-xs font-extrabold">${kl.eng}</div>
                  <div class="text-xs gb-text-sub">${kl.hin}</div>
                </div>
              </div>
              <div class="flex items-center gap-1.5 shrink-0">
                <button onclick="GBApp.speakCustomText('${kl.eng}. ${kl.hin}')" class="w-8 h-8 rounded-full gb-surface-alt flex items-center justify-center text-xs">🔊</button>
                <button onclick="GBApp.showToast('❤️ Saved Kanooni Line!')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center text-xs">🤍</button>
              </div>
            </div>
          `
            )
            .join("")}
        </div>
      </div>
    `;
  }

  // आज के 10 शब्द Screen with Streak & Celebration (PDF 3 Page 5 Right)
  function renderDaily10WordsScreen() {
    const dailyWords = DATA.shabdawali.slice(0, 10);
    const doneCount = state.daily10LearnedIds.length;
    const pct = Math.round((doneCount / 10) * 100);

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div class="text-sm font-extrabold">🔥 आज के 10 शब्द (Day ${state.daily10StreakDays})</div>
          </div>
          <button onclick="GBApp.completeAllDaily10Words()" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-bold gb-text-accent">Mark 10/10</button>
        </div>

        <div class="p-3.5 space-y-3.5">
          <!-- Progress Header Card -->
          <div class="gb-card p-3.5 space-y-2">
            <div class="flex justify-between text-xs">
              <div>
                <div class="font-extrabold">Day ${state.daily10StreakDays} • आज के 10 शब्द</div>
                <div class="text-[10px] gb-text-muted">आपका लक्ष्य: 10 शब्द</div>
              </div>
              <div class="text-right">
                <div class="font-black gb-text-gold">कुल सीखे: ${120 + doneCount} शब्द</div>
                <div class="text-[10px] text-emerald-400 font-bold">प्रगति: ${doneCount} / 10</div>
              </div>
            </div>
            <div class="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
              <div class="h-full bg-purple-500 rounded-full" style="width:${pct}%"></div>
            </div>
          </div>

          ${
            doneCount >= 10
              ? `
            <!-- Celebration Card (PDF 3 Page 5 Bottom Right) -->
            <div class="gb-card p-5 text-center space-y-3 border-amber-400/60">
              <div class="text-4xl">🏆</div>
              <h2 class="text-lg font-black gb-text-gold">बहुत बढ़िया!</h2>
              <p class="text-xs gb-text-sub">आपने आज के 10 शब्द सफलतापूर्वक सीख लिए।</p>
              <div class="w-20 h-20 rounded-full border-4 border-purple-500 flex flex-col items-center justify-center mx-auto">
                <span class="text-base font-black">10/10</span>
                <span class="text-[9px] gb-text-muted">लक्ष्य पूरा</span>
              </div>
              <div class="p-2.5 rounded-xl gb-surface text-xs font-extrabold text-amber-400">
                🔥 ${state.daily10StreakDays} Days Streak — बहुत बढ़िया! इसे बनाए रखें!
              </div>
              <button onclick="GBApp.navigateTo('home')" class="w-full py-2.5 gb-btn-primary text-xs">होम पर जाएं</button>
            </div>
          `
              : ""
          }

          <div class="space-y-2">
            ${dailyWords
              .map((w, idx) => {
                const learned = state.daily10LearnedIds.includes(w.id);
                return `
                  <div onclick="GBApp.markDailyWordLearned('${w.id}')" class="gb-card gb-card-interactive p-3 flex items-center justify-between cursor-pointer">
                    <div class="flex items-center gap-3">
                      <span class="text-xs font-bold gb-text-muted w-5">${idx + 1}</span>
                      <div>
                        <div class="text-xs font-extrabold">${w.term}</div>
                        <div class="text-[11px] gb-text-sub">${w.hindiShort}</div>
                      </div>
                    </div>
                    ${
                      learned
                        ? `<span class="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">✓</span>`
                        : `<span class="px-3 py-1 rounded-lg gb-surface-alt text-[10px] font-bold gb-text-accent">सीखें</span>`
                    }
                  </div>
                `;
              })
              .join("")}
          </div>
        </div>
      </div>
    `;
  }

  // Audio Learning Selector & Player (PDF 3 Pages 7–8)
  function renderAudioLearningScreen() {
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">🎧 Legal Shabdawali Audio</div>
              <div class="text-[10px] gb-text-sub">Select words for continuous audio playback</div>
            </div>
          </div>
        </div>

        <div class="p-3.5 space-y-3.5">
          <!-- Mode Tabs: By Number Range | Select Manually | All -->
          <div class="grid grid-cols-3 gap-1.5">
            <button onclick="GBApp.setAudioLearningTab('range')" class="py-2 rounded-xl text-xs font-bold border ${
              state.audioLearningTab === "range" ? "gb-tab-active" : "gb-surface"
            }">By Number Range</button>
            <button onclick="GBApp.setAudioLearningTab('manual')" class="py-2 rounded-xl text-xs font-bold border ${
              state.audioLearningTab === "manual" ? "gb-tab-active" : "gb-surface"
            }">Select Manually</button>
            <button onclick="GBApp.selectAllAudioWords(); GBApp.openAudioLearningPlayer(0)" class="py-2 rounded-xl text-xs font-bold gb-surface">Play All</button>
          </div>

          <!-- Range Selection Card (PDF 3 Page 7 Right) -->
          <div class="gb-card p-3.5 space-y-2.5">
            <div class="text-xs font-extrabold">Enter range (e.g. 1 to 50):</div>
            <div class="flex items-center gap-2">
              <input type="number" value="${state.audioRangeFrom}" class="gb-input text-center font-bold" />
              <span class="text-xs gb-text-muted">to</span>
              <input type="number" value="${state.audioRangeTo}" class="gb-input text-center font-bold" />
              <button onclick="GBApp.setAudioRangePreset(1, 50)" class="px-4 py-2.5 gb-btn-primary text-xs shrink-0">Add</button>
            </div>
            <div class="grid grid-cols-3 gap-1.5 pt-1">
              ${[
                [1, 50, "1-50"],
                [51, 100, "51-100"],
                [101, 200, "101-200"],
                [201, 500, "201-500"],
                [501, 1000, "501-1000"],
                [1, 5320, "All (5320)"]
              ]
                .map(
                  ([f, t, lbl]) => `
                <button onclick="GBApp.setAudioRangePreset(${f}, ${t})" class="py-1.5 rounded-lg text-[11px] font-bold border ${
                    state.audioRangeFrom === f && state.audioRangeTo === t ? "gb-tab-active" : "gb-surface"
                  }">${lbl}</button>
              `
                )
                .join("")}
            </div>
          </div>

          <!-- Manual Word Checklist -->
          <div class="space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-extrabold">Or Select Manually:</span>
              <button onclick="GBApp.selectAllAudioWords()" class="text-xs font-bold gb-text-accent">Select All (${state.audioSelectedWordIds.length})</button>
            </div>
            ${DATA.shabdawali
              .map((w, idx) => {
                const checked = state.audioSelectedWordIds.includes(w.id);
                return `
                  <div onclick="GBApp.toggleManualAudioWord('${w.id}')" class="gb-card p-3 flex items-center justify-between gap-2 cursor-pointer">
                    <div class="flex items-center gap-2.5">
                      <span class="w-5 h-5 rounded flex items-center justify-center text-xs font-bold ${
                        checked ? "bg-purple-600 text-white" : "gb-surface"
                      }">${checked ? "✓" : ""}</span>
                      <div>
                        <div class="text-xs font-extrabold">${idx + 1}. ${w.term}</div>
                        <div class="text-[11px] gb-text-sub">{${w.hindiShort}}</div>
                      </div>
                    </div>
                    <button onclick="event.stopPropagation(); GBApp.openAudioLearningPlayer(${idx})" class="px-2.5 py-1 rounded-lg gb-surface text-[10px] font-bold">▶ Play</button>
                  </div>
                `;
              })
              .join("")}
          </div>

          <button onclick="GBApp.openAudioLearningPlayer(0)" class="w-full py-3 gb-btn-primary text-sm flex items-center justify-center gap-2">
            <span>▶ Play Selected (${state.audioSelectedWordIds.length} Words)</span>
          </button>
        </div>
      </div>
    `;
  }

  // Full Audio Learning Player with Playlist Drawer (PDF 3 Page 8)
  function renderAudioLearningPlayerScreen() {
    const len = DATA.shabdawali.length;
    const idx = state.activeAudioWordIdx % len;
    const w = DATA.shabdawali[idx];
    const isFav = state.favouriteWords.includes(w.id);

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
          <div class="text-center">
            <div class="text-sm font-extrabold">Audio Learning</div>
            <div class="text-[10px] gb-text-sub">Legal Shabdawali | ${idx + 1} of ${len}</div>
          </div>
          <button onclick="GBApp.toggleFavouriteWord('${w.id}')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center">
            ${isFav ? "❤️" : "🤍"}
          </button>
        </div>

        <div class="p-3.5 space-y-3.5">
          <div class="gb-card p-4 space-y-3 border-purple-400/50">
            <div class="flex items-center justify-between">
              <span class="px-2.5 py-0.5 rounded-full bg-purple-600 text-white text-[10px] font-extrabold">${idx + 1} of ${len}</span>
              <button onclick="GBApp.speakWord('${w.id}')" class="w-11 h-11 rounded-full gb-surface-alt border border-purple-400 flex items-center justify-center text-lg">🔊</button>
            </div>
            <div>
              <h2 class="text-2xl font-black">${w.term}</h2>
              <div class="text-sm font-bold gb-text-gold mt-1">{ ${w.hindiShort} }</div>
            </div>
            <div class="space-y-1 text-xs border-t border-purple-500/20 pt-2.5">
              <div class="font-extrabold text-sky-400">Meaning :</div>
              <p class="gb-text-sub leading-relaxed">${w.meaning}</p>
            </div>
            <div class="space-y-1 text-xs border-t border-purple-500/20 pt-2.5">
              <div class="font-extrabold text-sky-400">Example :</div>
              <p class="gb-text-sub leading-relaxed">${w.example}</p>
            </div>
            <div class="space-y-1 text-xs border-t border-purple-500/20 pt-2.5">
              <div class="font-extrabold text-emerald-400">Synonyms :</div>
              <p class="gb-text-sub">${w.synonyms.join(", ")}</p>
            </div>
          </div>

          <!-- Scrubber -->
          <div>
            <div class="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
              <div class="h-full bg-purple-500 rounded-full" style="width: 45%"></div>
            </div>
            <div class="flex justify-between text-[10px] gb-text-muted mt-1">
              <span>0:03</span>
              <span>0:08</span>
            </div>
          </div>

          <!-- Prev / Play-Pause / Next -->
          <div class="flex items-center justify-center gap-6">
            <button onclick="GBApp.stepAudioLearningWord(-1)" class="w-12 h-12 rounded-full gb-surface flex items-center justify-center text-base font-bold">⏮</button>
            <button onclick="GBApp.speakWord('${w.id}')" class="w-16 h-16 rounded-full gb-btn-primary flex items-center justify-center text-2xl shadow-xl">⏸</button>
            <button onclick="GBApp.stepAudioLearningWord(1)" class="w-12 h-12 rounded-full gb-surface flex items-center justify-center text-base font-bold">⏭</button>
          </div>

          <!-- Bottom 4 Controls (Sleep Timer | Speed 1x | Auto Play On | Playlist) -->
          <div class="grid grid-cols-4 gap-2 text-center">
            <button onclick="GBApp.cycleSleepTimer()" class="gb-card p-2.5 text-[10px] font-bold">
              <div>🕒</div>
              <div class="mt-0.5">Sleep Timer</div>
              <div class="gb-text-muted">${state.sleepTimerMin ? state.sleepTimerMin + "m" : "Off"}</div>
            </button>
            <button onclick="GBApp.cycleSpeed()" class="gb-card p-2.5 text-[10px] font-bold">
              <div>⚡</div>
              <div class="mt-0.5">Speed</div>
              <div class="gb-text-accent">${state.playbackSpeed}x</div>
            </button>
            <button onclick="GBApp.toggleAutoPlayAudio()" class="gb-card p-2.5 text-[10px] font-bold">
              <div>🔄</div>
              <div class="mt-0.5">Auto Play</div>
              <div class="text-emerald-400">${state.autoPlayAudio ? "On" : "Off"}</div>
            </button>
            <button onclick="GBApp.toggleAudioPlaylistDrawer()" class="gb-card p-2.5 text-[10px] font-bold border-purple-400">
              <div>☰</div>
              <div class="mt-0.5">Playlist</div>
              <div class="gb-text-gold">(1 - ${len})</div>
            </button>
          </div>

          ${
            state.audioPlaylistDrawerOpen
              ? `
            <div class="gb-card p-3 space-y-1.5 border-purple-400">
              <div class="flex justify-between items-center pb-1 border-b border-purple-500/20">
                <span class="text-xs font-extrabold">Playlist (1 - ${len})</span>
                <button onclick="GBApp.toggleAudioPlaylistDrawer()" class="text-xs font-bold">✕</button>
              </div>
              ${DATA.shabdawali
                .map(
                  (item, i) => `
                <button onclick="GBApp.openAudioLearningPlayer(${i})" class="w-full p-2 rounded-lg flex items-center justify-between text-xs ${
                    i === idx ? "gb-tab-active" : "gb-surface"
                  }">
                  <span>${i + 1}. ${item.term} (${item.hindiShort.split(",")[0]})</span>
                  <span>${i === idx ? "ılı" : "▶"}</span>
                </button>
              `
                )
                .join("")}
            </div>
          `
              : ""
          }
        </div>
      </div>
    `;
  }
  // Requirement #7: Complete MCQ & Mock Tests Engine (PDF 3 Pages 9–13 & 28)
  function renderMcqTestScreen() {
    const questions = getFilteredMcqQuestions();

    // 1. MCQ Home Hub (PDF 3 Page 9)
    if (state.mcqScreenView === "hub") {
      const quickCards = [
        { id: "results", label: "Results", sub: "View Test Scores", icon: "🏆" },
        { id: "analytics", label: "Analysis", sub: "Detailed Report", icon: "📊" },
        { id: "right_wrong", label: "Right/Wrong", sub: "Check Answers", icon: "✅" },
        { id: "weak_areas", label: "Weak Areas", sub: "Improve Topics", icon: "⚠️" },
        { id: "saved_bookmarks", label: "Saved", sub: "Saved Questions", icon: "🔖" },
        { id: "my_tests", label: "My Test", sub: "Attempted Tests", icon: "📝" }
      ];
      const actWiseTests = [
        { act: "BNS 2023", title: "Bharatiya Nyaya Sanhita (BNS)", sets: "10+ Sets" },
        { act: "BNSS 2023", title: "Bharatiya Nagarik Suraksha Sanhita", sets: "10+ Sets" },
        { act: "BSA 2023", title: "Bharatiya Sakshya Adhiniyam (BSA)", sets: "10+ Sets" },
        { act: "Constitution", title: "Constitution of India", sets: "10+ Sets" }
      ];

      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
            <div class="flex items-center gap-2">
              <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
              <div>
                <div class="text-sm font-extrabold">☑️ MCQ & Mock Tests</div>
                <div class="text-[10px] gb-text-sub">Judiciary, BA LL.B. & Act-Wise Practice (Demo)</div>
              </div>
            </div>
            <button onclick="GBApp.setMcqView('test_settings')" class="px-2.5 py-1 rounded-full gb-btn-primary text-[10px]">Custom Test ›</button>
          </div>

          <div class="p-3 space-y-3.5">
            <div class="rounded-2xl overflow-hidden border border-purple-400/50">
              <img src="${DATA.assets.bannerMcqHero || DATA.assets.scHeroDay}" alt="MCQ Banner" class="w-full h-28 object-cover" />
            </div>

            <!-- Judiciary & BA LL.B. Exam Cards (PDF 3 Page 9) -->
            <div class="grid grid-cols-2 gap-2.5">
              <button onclick="GBApp.setMcqView('act_levels', 'Judiciary Exam Mock')" class="gb-card gb-card-interactive p-3 text-left border-amber-400/50">
                <div class="text-xl">⚖️</div>
                <div class="text-xs font-extrabold mt-1">Judiciary Exam</div>
                <div class="text-[10px] gb-text-sub mt-0.5">Prepare for Judicial Services with Expert Content</div>
                <div class="mt-2 text-[10px] font-bold gb-text-gold">Explore ›</div>
              </button>
              <button onclick="GBApp.setMcqView('act_levels', 'BA LL.B. Semester Exam')" class="gb-card gb-card-interactive p-3 text-left border-purple-400/50">
                <div class="text-xl">🎓</div>
                <div class="text-xs font-extrabold mt-1">BA LL.B. Exam</div>
                <div class="text-[10px] gb-text-sub mt-0.5">Subject-wise Tests for BA LL.B. Students</div>
                <div class="mt-2 text-[10px] font-bold gb-text-accent">Start Now ›</div>
              </button>
            </div>

            <!-- Quick Access 6-Card Grid (Results, Analysis, Right/Wrong, Weak Areas, Saved, My Test) -->
            <div>
              <h3 class="text-xs font-extrabold mb-2">Quick Access</h3>
              <div class="grid grid-cols-3 gap-2">
                ${quickCards
                  .map(
                    (qc) => `
                  <button onclick="GBApp.setMcqView('${qc.id}')" class="gb-card gb-card-interactive p-2.5 text-left">
                    <div class="text-lg">${qc.icon}</div>
                    <div class="text-[11px] font-extrabold mt-1">${qc.label}</div>
                    <div class="text-[9px] gb-text-muted">${qc.sub}</div>
                  </button>
                `
                  )
                  .join("")}
              </div>
            </div>

            <!-- Continue From Where You Left -->
            <div class="gb-card p-3.5 flex items-center justify-between gap-2 border-purple-400/40">
              <div>
                <div class="text-[10px] font-bold gb-text-accent">Continue From Where You Left</div>
                <div class="text-xs font-extrabold mt-0.5">Bharatiya Nyaya Sanhita (BNS)</div>
                <div class="text-[10px] gb-text-sub">Chapter 5 • Section 18 • 36% Completed</div>
              </div>
              <button onclick="GBApp.startMcqTest()" class="px-3.5 py-2 gb-btn-primary text-xs shrink-0">Continue ›</button>
            </div>

            <!-- Act Wise Tests -->
            <div>
              <h3 class="text-xs font-extrabold mb-2">Act Wise Tests</h3>
              <div class="space-y-2">
                ${actWiseTests
                  .map(
                    (at) => `
                  <div onclick="GBApp.setMcqConfig('mcqFilterAct', '${at.act}'); GBApp.setMcqView('act_levels', '${at.title}')" class="gb-card gb-card-interactive p-3 flex items-center justify-between cursor-pointer">
                    <div class="flex items-center gap-2.5">
                      <span class="text-lg">📘</span>
                      <div>
                        <div class="text-xs font-extrabold">${at.title}</div>
                        <div class="text-[10px] gb-text-muted">Practice Test • ${at.sets} (Demo)</div>
                      </div>
                    </div>
                    <span class="px-3 py-1 rounded-lg gb-surface-alt text-[10px] font-bold gb-text-accent">Start ›</span>
                  </div>
                `
                  )
                  .join("")}
              </div>
            </div>
          </div>
        </div>
      `;
    }

    // 2. Act Tests Level Selection (PDF 3 Page 10)
    if (state.mcqScreenView === "act_levels") {
      const levels = [
        { id: "Easy", hindi: "सरल", sets: "15 Sets • 300 Questions", done: "8/15 Sets Completed", pct: 53, color: "#10b981" },
        { id: "Medium", hindi: "मध्यम", sets: "15 Sets • 300 Questions", done: "6/15 Sets Completed", pct: 40, color: "#eab308" },
        { id: "Hard", hindi: "कठिन", sets: "10 Sets • 200 Questions", done: "3/10 Sets Completed", pct: 30, color: "#f97316" },
        { id: "Expert", hindi: "विशेषज्ञ", sets: "10 Sets • 200 Questions", done: "1/10 Sets Completed", pct: 10, color: "#ef4444" }
      ];
      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center gap-2 border-b border-purple-500/20">
            <button onclick="GBApp.setMcqView('hub')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">${state.mcqSelectedActTitle}</div>
              <div class="text-[10px] gb-text-sub">Act-wise MCQ Practice & Mock Tests</div>
            </div>
          </div>

          <div class="p-3.5 space-y-3.5">
            <!-- Top 4 Stats -->
            <div class="gb-card p-3 grid grid-cols-4 gap-1.5 text-center text-xs">
              <div><div class="font-black">1000</div><div class="text-[9px] gb-text-muted">Total Qs (Demo)</div></div>
              <div><div class="font-black">50</div><div class="text-[9px] gb-text-muted">Total Sets</div></div>
              <div><div class="font-black">18</div><div class="text-[9px] gb-text-muted">Completed</div></div>
              <div><div class="font-black text-emerald-400">64%</div><div class="text-[9px] gb-text-muted">Avg Score</div></div>
            </div>

            <!-- Custom Practice Card -->
            <div class="gb-card p-3.5 flex items-center justify-between gap-2 border-purple-400/50">
              <div>
                <div class="text-xs font-extrabold">⚙️ Custom Practice</div>
                <p class="text-[10px] gb-text-sub mt-0.5">अपनी पसंद के अनुसार Level, Questions की संख्या और Time चुनकर Practice करें</p>
              </div>
              <button onclick="GBApp.setMcqView('test_settings')" class="px-3.5 py-2 gb-btn-primary text-xs shrink-0">Start ›</button>
            </div>

            <h3 class="text-xs font-extrabold">Choose Level to Continue (कठिनाई स्तर चुनें):</h3>
            <div class="space-y-2.5">
              ${levels
                .map(
                  (lv) => `
                <div onclick="GBApp.selectMcqLevel('${lv.id}')" class="gb-card gb-card-interactive p-3.5 space-y-2 cursor-pointer">
                  <div class="flex items-center justify-between">
                    <div>
                      <div class="text-sm font-black">${lv.id} (${lv.hindi})</div>
                      <div class="text-[10px] gb-text-sub">${lv.sets} • ${lv.done}</div>
                    </div>
                    <span class="px-3 py-1.5 gb-btn-primary text-xs">Start ›</span>
                  </div>
                  <div class="w-full h-1.5 bg-purple-950 rounded-full overflow-hidden">
                    <div class="h-full rounded-full" style="width:${lv.pct}%; background:${lv.color}"></div>
                  </div>
                </div>
              `
                )
                .join("")}
            </div>
          </div>
        </div>
      `;
    }

    // 3. Set List Screen (PDF 3 Page 11)
    if (state.mcqScreenView === "set_list") {
      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
            <div class="flex items-center gap-2">
              <button onclick="GBApp.setMcqView('act_levels')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
              <div>
                <div class="text-sm font-extrabold">${state.mcqFilterLevel} Level Sets</div>
                <div class="text-[10px] gb-text-sub">${state.mcqSelectedActTitle}</div>
              </div>
            </div>
            <button onclick="GBApp.setMcqView('test_settings')" class="px-2.5 py-1 rounded-lg gb-surface-alt text-[10px] font-bold gb-text-accent">⚙️ Settings</button>
          </div>

          <div class="p-3.5 space-y-2.5">
            ${DATA.mcqSetsList
              .map(
                (st) => `
              <div class="gb-card p-3.5 flex items-center justify-between gap-3">
                <div class="space-y-1 flex-1">
                  <div class="flex items-center gap-2">
                    <span class="px-2.5 py-0.5 rounded-lg bg-purple-600 text-white text-xs font-black">SET ${st.num}</span>
                    <span class="text-xs font-extrabold">${st.title}</span>
                  </div>
                  <div class="grid grid-cols-2 gap-1 text-[10px] gb-text-sub pt-1">
                    <span>✔ Correct: <strong>${st.correct}</strong></span>
                    <span>✖ Wrong: <strong>${st.wrong}</strong></span>
                    <span>● Attempted: <strong>${st.attempted}/${st.totalQ}</strong></span>
                    <span>🕒 Time: <strong>${st.time}</strong></span>
                  </div>
                  <div class="flex gap-2 pt-2">
                    <button onclick="GBApp.startMcqTest()" class="px-3.5 py-1.5 gb-btn-primary text-[11px]">
                      ${st.status === "completed" ? "Re-attempt ›" : st.status === "in_progress" ? "Resume ›" : "Start Test ›"}
                    </button>
                    ${
                      st.status === "completed"
                        ? `<button onclick="GBApp.setMcqView('results')" class="px-3 py-1.5 gb-btn-outline text-[11px]">Result</button>`
                        : ""
                    }
                  </div>
                </div>
                <div class="w-14 h-14 rounded-full border-4 ${
                  st.scorePct >= 75 ? "border-emerald-400" : st.scorePct >= 40 ? "border-amber-400" : "border-purple-500/30"
                } flex flex-col items-center justify-center shrink-0">
                  <span class="text-xs font-black">${st.scorePct}%</span>
                  <span class="text-[8px] gb-text-muted">Score</span>
                </div>
              </div>
            `
              )
              .join("")}
          </div>
        </div>
      `;
    }

    // 4. Test Settings Screen (PDF 3 Page 12 Left)
    if (state.mcqScreenView === "test_settings") {
      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center gap-2 border-b border-purple-500/20">
            <button onclick="GBApp.setMcqView('hub')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div class="text-sm font-extrabold">⚙️ Test Settings (परीक्षा सेटिंग्स)</div>
          </div>

          <div class="p-3.5 space-y-3.5 text-xs">
            <!-- 1. परीक्षा मोड चुनें -->
            <div class="gb-card p-3.5 space-y-2.5">
              <div class="font-extrabold gb-text-accent">1. परीक्षा मोड चुनें (Select Mode):</div>
              <div class="grid grid-cols-2 gap-2">
                <button onclick="GBApp.setMcqConfig('mcqMode', 'Practice')" class="p-3 rounded-xl border text-left space-y-1 ${
                  state.mcqMode === "Practice" ? "gb-tab-active" : "gb-surface"
                }">
                  <div class="font-black text-sm">💡 Practice Mode</div>
                  <div class="text-[10px] gb-text-sub">✓ Hint और Explanation मिलेगा</div>
                  <div class="text-[10px] gb-text-sub">✓ सीखने के लिए बेहतर</div>
                </button>
                <button onclick="GBApp.setMcqConfig('mcqMode', 'Exam')" class="p-3 rounded-xl border text-left space-y-1 ${
                  state.mcqMode === "Exam" ? "gb-tab-active" : "gb-surface"
                }">
                  <div class="font-black text-sm">⏱️ Exam Mode</div>
                  <div class="text-[10px] gb-text-sub">✓ Real Exam जैसा अनुभव</div>
                  <div class="text-[10px] gb-text-sub">✓ अंत में विस्तृत रिजल्ट</div>
                </button>
              </div>
            </div>

            <!-- 2. कठिनाई स्तर चुनें -->
            <div class="gb-card p-3.5 space-y-2">
              <div class="font-extrabold gb-text-accent">2. कठिनाई स्तर चुनें (Difficulty Level):</div>
              <div class="grid grid-cols-4 gap-1.5">
                ${["Easy", "Medium", "Hard", "Expert"]
                  .map(
                    (lv) => `
                  <button onclick="GBApp.setMcqConfig('mcqFilterLevel', '${lv}')" class="py-2 rounded-xl font-bold border ${
                      state.mcqFilterLevel === lv ? "gb-tab-active" : "gb-surface"
                    }">${lv}</button>
                `
                  )
                  .join("")}
              </div>
            </div>

            <!-- 3. प्रश्नों की संख्या -->
            <div class="gb-card p-3.5 space-y-2">
              <div class="font-extrabold gb-text-accent">3. प्रश्नों की संख्या (Question Count):</div>
              <div class="grid grid-cols-4 gap-1.5">
                ${[10, 25, 50, 100]
                  .map(
                    (cnt) => `
                  <button onclick="GBApp.setMcqConfig('mcqCountLimit', ${cnt})" class="py-2 rounded-xl font-bold border ${
                      state.mcqCountLimit === cnt ? "gb-tab-active" : "gb-surface"
                    }">${cnt}</button>
                `
                  )
                  .join("")}
              </div>
            </div>

            <!-- 4. Timer -->
            <div class="gb-card p-3.5 space-y-2">
              <div class="font-extrabold gb-text-accent">4. Timer Settings:</div>
              <div class="grid grid-cols-5 gap-1">
                ${[
                  [0, "Off"],
                  [30, "30 Min"],
                  [60, "60 Min"],
                  [90, "90 Min"],
                  [120, "120m"]
                ]
                  .map(
                    ([m, lbl]) => `
                  <button onclick="GBApp.setMcqConfig('mcqTimerMinutes', ${m})" class="py-2 rounded-xl text-[11px] font-bold border ${
                      state.mcqTimerMinutes === m ? "gb-tab-active" : "gb-surface"
                    }">${lbl}</button>
                `
                  )
                  .join("")}
              </div>
            </div>

            <button onclick="GBApp.startMcqTest()" class="w-full py-3.5 gb-btn-primary text-sm">
              ▶ Start Test (${questions.length} Demo Questions)
            </button>
          </div>
        </div>
      `;
    }

    // 5. Time's Up! Auto-Submitted Screen (PDF 3 Page 28)
    if (state.mcqScreenView === "times_up") {
      return `
        <div class="flex-1 flex flex-col justify-center p-5 pb-24 text-center">
          <div class="gb-card p-6 space-y-4 border-amber-400/60">
            <div class="text-6xl">⏱️</div>
            <h2 class="text-2xl font-black gb-text-gold">Time's Up!</h2>
            <p class="text-xs gb-text-sub">Your test has been auto submitted.</p>
            <button onclick="GBApp.confirmMcqSubmit()" class="w-full py-3 gb-btn-primary text-sm">
              View Result →
            </button>
          </div>
        </div>
      `;
    }

    // 6. Submit Confirmation Screen
    if (state.mcqScreenView === "confirm_submit") {
      const answeredCount = questions.filter((q) => state.mcqAnswers[q.id] !== undefined).length;
      const reviewCount = questions.filter((q) => state.mcqReviewMarked[q.id]).length;
      const unansweredCount = questions.length - answeredCount;
      return `
        <div class="flex-1 flex flex-col justify-center p-4 pb-24">
          <div class="gb-card p-5 space-y-4 text-center border-purple-400">
            <div class="text-3xl">📋</div>
            <h3 class="text-base font-black">Submit Mock Test Confirmation</h3>
            <div class="grid grid-cols-3 gap-2 text-xs">
              <div class="p-2.5 rounded-xl gb-surface"><div class="text-base font-black text-emerald-400">${answeredCount}</div><div class="text-[10px] gb-text-muted">Answered</div></div>
              <div class="p-2.5 rounded-xl gb-surface"><div class="text-base font-black text-rose-400">${unansweredCount}</div><div class="text-[10px] gb-text-muted">Unattempted</div></div>
              <div class="p-2.5 rounded-xl gb-surface"><div class="text-base font-black text-amber-400">${reviewCount}</div><div class="text-[10px] gb-text-muted">Review Later</div></div>
            </div>
            <div class="flex gap-2">
              <button onclick="GBApp.setMcqView('active_test')" class="flex-1 py-2.5 gb-btn-outline text-xs">← Resume</button>
              <button onclick="GBApp.confirmMcqSubmit()" class="flex-1 py-2.5 gb-btn-primary text-xs">✓ Confirm Submit</button>
            </div>
          </div>
        </div>
      `;
    }

    // 7. Analytics, Results, Right/Wrong, Weak Areas, My Tests & Saved Screens (PDF 3 Page 13)
    if (["results", "analytics", "right_wrong", "weak_areas", "my_tests", "saved_bookmarks"].includes(state.mcqScreenView)) {
      let correct = 0;
      let wrong = 0;
      questions.forEach((q) => {
        if (state.mcqAnswers[q.id] === q.correctIndex) correct++;
        else if (state.mcqAnswers[q.id] !== undefined) wrong++;
      });
      if (correct === 0 && wrong === 0) {
        correct = 6;
        wrong = 1;
      }
      const unattempted = Math.max(0, questions.length - correct - wrong);
      const pct = Math.round((correct / questions.length) * 100);

      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
            <button onclick="GBApp.setMcqView('hub')" class="text-xs font-bold gb-text-accent">← Test Hub</button>
            <span class="text-xs font-extrabold uppercase">${state.mcqScreenView.replace("_", " ")}</span>
          </div>

          <!-- Sub-Navigation Pills across all 6 Analytics & Review Views -->
          <div class="px-3 pt-2.5 flex gap-1.5 overflow-x-auto no-scrollbar">
            ${[
              ["results", "🏆 Result & Rank"],
              ["analytics", "📊 Analytics"],
              ["right_wrong", "✅ Right/Wrong"],
              ["weak_areas", "⚠️ Weak Areas"],
              ["my_tests", "📝 My Tests"],
              ["saved_bookmarks", "🔖 Saved"]
            ]
              .map(
                ([v, lbl]) => `
              <button onclick="GBApp.setMcqView('${v}')" class="px-3 py-1.5 rounded-full text-[11px] font-bold whitespace-nowrap border ${
                  state.mcqScreenView === v ? "gb-tab-active" : "gb-surface"
                }">${lbl}</button>
            `
              )
              .join("")}
          </div>

          <div class="p-3.5 space-y-3.5 text-xs">
            ${
              state.mcqScreenView === "results"
                ? `
              <div class="gb-card p-4 text-center space-y-3 border-emerald-400/50">
                <div class="text-xs font-bold gb-text-accent">${state.mcqSelectedActTitle}</div>
                <div class="w-24 h-24 rounded-full border-4 border-emerald-400 flex flex-col items-center justify-center mx-auto">
                  <span class="text-xl font-black">${pct}%</span>
                  <span class="text-[9px] text-emerald-400 font-bold">Passed</span>
                </div>
                <div class="grid grid-cols-3 gap-2">
                  <div class="p-2 rounded-xl gb-surface"><strong class="text-emerald-400">${correct}</strong> Correct</div>
                  <div class="p-2 rounded-xl gb-surface"><strong class="text-rose-400">${wrong}</strong> Wrong</div>
                  <div class="p-2 rounded-xl gb-surface"><strong>${unattempted}</strong> Unattempted</div>
                </div>
                <div class="p-3 rounded-xl gb-surface flex justify-around">
                  <div><div class="text-[10px] gb-text-muted">All India Rank</div><div class="text-sm font-black gb-text-gold">#12 <span class="text-[10px]">/ 1250</span></div></div>
                  <div><div class="text-[10px] gb-text-muted">Percentile</div><div class="text-sm font-black text-emerald-400">88%</div></div>
                </div>
                <!-- Podium Leaderboard (PDF 3 Page 13) -->
                <div class="grid grid-cols-3 gap-2 pt-1">
                  <div class="p-2 rounded-xl gb-surface"><div class="text-[10px] gb-text-muted">#2</div><div class="font-bold truncate">Riya Sharma</div><div class="gb-text-accent font-extrabold">92%</div></div>
                  <div class="p-2 rounded-xl gb-surface-alt border border-amber-400/50"><div class="text-[10px] gb-text-gold font-bold">👑 #1</div><div class="font-extrabold truncate">Aman Verma</div><div class="gb-text-gold font-black">96%</div></div>
                  <div class="p-2 rounded-xl gb-surface"><div class="text-[10px] gb-text-muted">#12 (You)</div><div class="font-bold truncate">${state.userAccountName}</div><div class="text-emerald-400 font-extrabold">${pct}%</div></div>
                </div>
                <div class="flex gap-2 pt-1">
                  <button onclick="GBApp.setMcqView('right_wrong')" class="flex-1 py-2.5 gb-btn-primary text-xs">Review Answers</button>
                  <button onclick="GBApp.startMcqTest()" class="flex-1 py-2.5 gb-btn-outline text-xs">Re-attempt Test</button>
                </div>
              </div>
            `
                : state.mcqScreenView === "analytics"
                ? `
              <div class="gb-card p-4 space-y-3">
                <div class="font-extrabold gb-text-accent">📊 Analytics & Performance Overview</div>
                <div class="grid grid-cols-2 gap-2 text-center">
                  <div class="p-2.5 rounded-xl gb-surface"><div class="text-base font-black">18</div><div class="text-[10px] gb-text-muted">Tests Attempted</div></div>
                  <div class="p-2.5 rounded-xl gb-surface"><div class="text-base font-black text-emerald-400">68%</div><div class="text-[10px] gb-text-muted">Average Score</div></div>
                  <div class="p-2.5 rounded-xl gb-surface"><div class="text-base font-black gb-text-gold">92%</div><div class="text-[10px] gb-text-muted">Best Score</div></div>
                  <div class="p-2.5 rounded-xl gb-surface"><div class="text-base font-black text-sky-400">74%</div><div class="text-[10px] gb-text-muted">Accuracy</div></div>
                </div>
                <div class="space-y-2 pt-2">
                  <div class="font-bold">Subject-wise Accuracy:</div>
                  <div><div class="flex justify-between text-[11px] mb-1"><span>Constitution of India</span><span class="text-emerald-400 font-bold">82%</span></div><div class="w-full h-2 bg-purple-950 rounded-full"><div class="h-full bg-emerald-500 rounded-full" style="width:82%"></div></div></div>
                  <div><div class="flex justify-between text-[11px] mb-1"><span>BNS 2023</span><span class="text-amber-400 font-bold">74%</span></div><div class="w-full h-2 bg-purple-950 rounded-full"><div class="h-full bg-amber-500 rounded-full" style="width:74%"></div></div></div>
                  <div><div class="flex justify-between text-[11px] mb-1"><span>BSA 2023 (Evidence)</span><span class="text-rose-400 font-bold">52%</span></div><div class="w-full h-2 bg-purple-950 rounded-full"><div class="h-full bg-rose-500 rounded-full" style="width:52%"></div></div></div>
                </div>
              </div>
            `
                : state.mcqScreenView === "weak_areas"
                ? `
              <div class="gb-card p-4 space-y-3">
                <div class="flex items-center gap-4">
                  <div class="w-20 h-20 rounded-full border-4 border-rose-500 flex flex-col items-center justify-center shrink-0">
                    <span class="text-base font-black">45%</span>
                    <span class="text-[8px] gb-text-muted">Overall Weak</span>
                  </div>
                  <div>
                    <div class="font-extrabold text-sm">Weak Areas Detail</div>
                    <p class="text-[11px] gb-text-sub mt-0.5">Topics where your accuracy is below 60% in recent tests:</p>
                  </div>
                </div>
                <div class="space-y-2 pt-1">
                  <div class="p-2.5 rounded-xl gb-surface"><div class="flex justify-between font-bold"><span>1. Indian Evidence Act / BSA Sec 24–63</span><span class="text-rose-400">35%</span></div></div>
                  <div class="p-2.5 rounded-xl gb-surface"><div class="flex justify-between font-bold"><span>2. BNS Chapter 2 (Enhanced Punishment)</span><span class="text-amber-400">42%</span></div></div>
                  <div class="p-2.5 rounded-xl gb-surface"><div class="flex justify-between font-bold"><span>3. BNSS Anticipatory & Default Bail</span><span class="text-amber-400">48%</span></div></div>
                </div>
                <button onclick="GBApp.startMcqTest()" class="w-full py-2.5 gb-btn-primary text-xs">▶ Practice Weak Areas Now</button>
              </div>
            `
                : state.mcqScreenView === "my_tests" || state.mcqScreenView === "saved_bookmarks"
                ? `
              <div class="space-y-2.5">
                <div class="font-extrabold gb-text-gold">Saved & Attempted Mock Tests:</div>
                ${state.mcqSavedTests
                  .map(
                    (st) => `
                  <div class="gb-card p-3.5 flex items-center justify-between">
                    <div>
                      <div class="font-extrabold">${st.title}</div>
                      <div class="text-[10px] gb-text-muted">${st.date} • ${st.score}</div>
                    </div>
                    <button onclick="GBApp.startMcqTest()" class="px-3 py-1.5 gb-btn-primary text-[10px]">Re-attempt ›</button>
                  </div>
                `
                  )
                  .join("")}
              </div>
            `
                : ""
            }

            <!-- Detailed Question-by-Question Solution Review -->
            <div class="space-y-2.5">
              <div class="font-extrabold">Detailed Solutions & Explanations:</div>
              ${questions
                .map((q, i) => {
                  const uAns = state.mcqAnswers[q.id];
                  return `
                    <div class="gb-card p-3.5 space-y-1.5">
                      <div class="flex justify-between text-[10px]">
                        <span class="px-2 py-0.5 rounded gb-surface-alt font-bold gb-text-accent">${q.act} • ${q.topic}</span>
                        <span class="font-bold text-emerald-400">Ans: Option ${["A", "B", "C", "D"][q.correctIndex]}</span>
                      </div>
                      <div class="font-extrabold">Q.${i + 1}: ${q.q}</div>
                      ${uAns !== undefined ? `<div class="text-[11px] gb-text-gold">Your Answer: ${q.options[uAns]}</div>` : ""}
                      <div class="text-[11px] text-emerald-400 font-bold">Correct Answer: ${q.options[q.correctIndex]}</div>
                      <div class="p-2.5 rounded-xl gb-surface text-[11px] gb-text-sub"><strong>Explanation:</strong> ${q.explanation}</div>
                    </div>
                  `;
                })
                .join("")}
            </div>
          </div>
        </div>
      `;
    }

    // 8. Active Question Screen (PDF 3 Page 12 Right)
    const curQ = questions[state.mcqCurrentIdx % questions.length];
    const selectedOpt = state.mcqAnswers[curQ.id];
    const isReviewed = !!state.mcqReviewMarked[curQ.id];
    const isSavedQ = state.mcqSavedQuestions.includes(curQ.id);
    const m = String(Math.floor(state.mcqTimerSec / 60)).padStart(2, "0");
    const s = String(state.mcqTimerSec % 60).padStart(2, "0");

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2 min-w-0">
            <button onclick="GBApp.setMcqView('hub')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold shrink-0">←</button>
            <div class="min-w-0">
              <div class="text-xs font-extrabold truncate">${state.mcqSelectedActTitle}</div>
              <div class="text-[10px] gb-text-sub">${state.mcqMode} Mode • ${state.mcqFilterLevel}</div>
            </div>
          </div>
          <div class="flex items-center gap-1.5 shrink-0">
            <button onclick="GBApp.toggleSaveMcqQuestion('${curQ.id}')" class="px-2 py-1 rounded-lg gb-surface text-[10px] font-bold">
              ${isSavedQ ? "🔖 Saved" : "+ Saved"}
            </button>
            <button onclick="GBApp.openMcqSubmitConfirm()" class="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-bold">Submit</button>
          </div>
        </div>

        <div class="p-3.5 space-y-3">
          <!-- Timer & Question Counter Strip -->
          <div class="flex items-center justify-between px-3 py-2 rounded-xl gb-surface text-xs">
            <span class="font-extrabold">Q. ${state.mcqCurrentIdx + 1} / ${questions.length}</span>
            <span class="font-black gb-text-gold">⏱️ <span id="mcq-timer-display">00:${m}:${s}</span></span>
            <button onclick="GBApp.triggerTimesUpScreen()" class="text-[10px] underline text-rose-400 font-bold" title="Test Time's Up Screen">Test Time's Up</button>
          </div>

          <!-- Question Card -->
          <div class="gb-card p-4 space-y-3">
            <div class="text-sm font-extrabold leading-snug">Q.${state.mcqCurrentIdx + 1}: ${curQ.q}</div>

            <div class="space-y-2">
              ${curQ.options
                .map((opt, oIdx) => {
                  const isPicked = selectedOpt === oIdx;
                  let btnCls = "gb-surface hover:border-purple-400";
                  if (state.mcqMode === "Practice" && selectedOpt !== undefined) {
                    if (oIdx === curQ.correctIndex) btnCls = "bg-emerald-600 text-white border-emerald-400 font-bold";
                    else if (isPicked) btnCls = "bg-rose-600 text-white border-rose-400 font-bold";
                  } else if (isPicked) {
                    btnCls = "gb-tab-active";
                  }
                  return `
                    <button onclick="GBApp.selectMcqOption('${curQ.id}', ${oIdx})" class="w-full p-3 rounded-xl border text-left text-xs flex items-center justify-between ${btnCls}">
                      <span>${opt}</span>
                      <span>${isPicked ? "✓" : ""}</span>
                    </button>
                  `;
                })
                .join("")}
            </div>

            <!-- Hint & Explanation Toggles (PDF 3 Page 12 Right) -->
            <div class="flex gap-2 pt-1">
              <button onclick="GBApp.toggleMcqHint()" class="px-3 py-1 rounded-lg gb-surface text-[11px] font-bold gb-text-gold">
                💡 Hint ${state.mcqShowHint ? "▲" : "▼"}
              </button>
              <button onclick="GBApp.toggleMcqExplanation()" class="px-3 py-1 rounded-lg gb-surface text-[11px] font-bold gb-text-accent">
                📖 Explanation ${state.mcqShowExplanation ? "▲" : "▼"}
              </button>
            </div>

            ${
              state.mcqShowHint
                ? `<div class="p-2.5 rounded-xl gb-surface text-xs gb-text-gold"><strong>💡 Hint:</strong> ${curQ.hint || "संबंधित धारा के मुख्य उपबंधों पर ध्यान दें।"}</div>`
                : ""
            }

            ${
              state.mcqShowExplanation && (state.mcqMode === "Practice" || selectedOpt !== undefined)
                ? `<div class="p-3 rounded-xl gb-surface text-xs space-y-1 border border-emerald-500/30">
                    <div class="font-extrabold text-emerald-400">सही उत्तर: ${curQ.options[curQ.correctIndex]}</div>
                    <div class="gb-text-sub leading-relaxed"><strong>Explanation:</strong> ${curQ.explanation}</div>
                  </div>`
                : ""
            }
          </div>

          <!-- Previous | Review Later | Next Controls -->
          <div class="grid grid-cols-3 gap-2">
            <button onclick="GBApp.jumpMcqQuestion(${Math.max(0, state.mcqCurrentIdx - 1)})" class="py-2.5 gb-btn-outline text-xs">← Previous</button>
            <button onclick="GBApp.toggleMcqReviewMark('${curQ.id}')" class="py-2.5 rounded-full border text-xs font-bold ${
              isReviewed ? "bg-amber-500 text-black border-amber-400" : "gb-surface"
            }">🔖 Review Later</button>
            ${
              state.mcqCurrentIdx < questions.length - 1
                ? `<button onclick="GBApp.jumpMcqQuestion(${state.mcqCurrentIdx + 1})" class="py-2.5 gb-btn-primary text-xs">Next →</button>`
                : `<button onclick="GBApp.openMcqSubmitConfirm()" class="py-2.5 gb-btn-primary text-xs">Finish ✓</button>`
            }
          </div>

          <!-- Bottom Numbered Question Circles & Legend (PDF 3 Page 12 Right) -->
          <div class="gb-card p-3 space-y-2">
            <div class="flex flex-wrap gap-1.5">
              ${questions
                .map((q, idx) => {
                  const ans = state.mcqAnswers[q.id];
                  const rev = state.mcqReviewMarked[q.id];
                  let cls = "gb-surface";
                  if (idx === state.mcqCurrentIdx) cls = "border-2 border-purple-400 font-black gb-surface-alt";
                  else if (rev) cls = "bg-amber-500 text-black font-bold";
                  else if (ans !== undefined) cls = "bg-emerald-600 text-white font-bold";
                  return `<button onclick="GBApp.jumpMcqQuestion(${idx})" class="w-8 h-8 rounded-full text-xs flex items-center justify-center ${cls}">${idx + 1}</button>`;
                })
                .join("")}
            </div>
            <div class="flex justify-between text-[9px] gb-text-muted pt-1 border-t border-purple-500/20">
              <span>🟢 Answered</span>
              <span>🔴 Wrong</span>
              <span>🟡 Review Later</span>
              <span>⚪ Unattempted</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  // Requirement #8: Bare Act Library & Dual Format Reader (PDF 3 Pages 24–25)
  function renderBareActLibraryScreen() {
    const allActs = Object.values(getAllActsMap());
    const q = state.librarySearch.trim().toLowerCase();
    const filtered = allActs.filter((a) => {
      if (state.libraryCategory === "Favourites" && !state.favouriteActs.includes(a.id)) return false;
      if (state.libraryCategory !== "All" && state.libraryCategory !== "Favourites" && a.category !== state.libraryCategory) return false;
      if (!q) return true;
      return (
        a.shortTitle.toLowerCase().includes(q) ||
        a.titleHindi.toLowerCase().includes(q) ||
        a.titleEnglish.toLowerCase().includes(q)
      );
    });

    const popActs = Object.values(DATA.acts);

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">📚 Bare Act Library</div>
              <div class="text-[10px] gb-text-sub">800+ Acts Ready Architecture • Dual Format Reader</div>
            </div>
          </div>
        </div>

        <div class="p-3 space-y-3.5">
          <!-- Search Bar -->
          <div class="flex items-center gap-2 px-3.5 py-2 rounded-xl gb-card">
            <span>🔍</span>
            <input type="text" value="${state.librarySearch}" oninput="GBApp.setLibrarySearch(this.value)" placeholder="Search Acts..." class="bg-transparent flex-1 text-xs focus:outline-none" />
          </div>

          <!-- Popular Acts Horizontal Cards (PDF 3 Page 24) -->
          <div>
            <h3 class="text-xs font-extrabold mb-2">Popular Acts</h3>
            <div class="grid grid-cols-4 gap-2 text-center">
              ${popActs
                .map(
                  (pa) => `
                <button onclick="GBApp.openBareActDetail('${pa.id}')" class="gb-card ornate-act-card p-2 flex flex-col items-center">
                  <div class="text-sm font-black gb-text-gold">${pa.shortTitle}</div>
                  <div class="text-[9px] gb-text-sub truncate w-full mt-0.5">${pa.titleHindi}</div>
                </button>
              `
                )
                .join("")}
            </div>
          </div>

          <!-- FAVOURITE Bar (PDF 3 Page 24) -->
          <button onclick="GBApp.setLibraryCategory(state.libraryCategory === 'Favourites' ? 'All' : 'Favourites')" class="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-600/30 via-amber-500/20 to-amber-600/30 border border-amber-400/50 flex items-center justify-between text-xs font-black gb-text-gold">
            <span>⭐ FAVOURITE ACTS (${state.favouriteActs.length})</span>
            <span>${state.libraryCategory === "Favourites" ? "Show All ›" : "View Saved ›"}</span>
          </button>

          <!-- Honest 800+ Acts Scalability Notice -->
          <div class="px-3 py-2 rounded-xl gb-surface text-[10px] gb-text-sub">
            📌 <strong>Demo Dataset Notice:</strong> यह संरचना भविष्य में Admin Panel से 800+ Bare Acts अपलोड करने के लिए तैयार है। अभी टेस्टिंग हेतु ${allActs.length} प्रमुख डेमो अधिनियम उपलब्ध हैं।
          </div>

          <!-- ALL ACTS 2-Column Ornate Cards Grid (PDF 3 Page 24) -->
          <div>
            <h3 class="text-xs font-extrabold mb-2 uppercase tracking-wider">All Acts</h3>
            <div class="grid grid-cols-2 gap-2.5">
              ${filtered
                .map((act) => {
                  const isFav = state.favouriteActs.includes(act.id);
                  return `
                    <div onclick="GBApp.openBareActDetail('${act.id}')" class="gb-card ornate-act-card p-3 flex flex-col justify-between cursor-pointer relative">
                      <button onclick="GBApp.toggleFavouriteAct('${act.id}', event)" class="absolute top-2 right-2 text-xs">
                        ${isFav ? "⭐" : "☆"}
                      </button>
                      <div class="text-center pt-1 pb-2 border-b border-amber-500/20">
                        <div class="text-base font-black gb-text-gold">${act.shortTitle}</div>
                        <div class="text-[11px] font-extrabold mt-0.5 line-clamp-1">${act.titleHindi}</div>
                        <div class="text-[9px] gb-text-muted line-clamp-1">${act.titleEnglish}</div>
                      </div>
                      <div class="pt-2 flex items-center justify-between text-[10px] font-bold gb-text-accent">
                        <span>${act.sectionsCount} Sections</span>
                        <span>Read ›</span>
                      </div>
                    </div>
                  `;
                })
                .join("")}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // Bare Act Chapter List (PDF 3 Page 24 Right)
  function renderBareActChaptersScreen() {
    const act = getCurrentActObj();
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2 min-w-0">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold shrink-0">←</button>
            <div class="min-w-0">
              <div class="text-xs font-extrabold truncate">${act.titleHindi}</div>
              <div class="text-[10px] gb-text-sub truncate">${act.titleEnglish} (${act.sectionsCount} धाराएं)</div>
            </div>
          </div>
        </div>

        <div class="p-3.5 space-y-2.5">
          ${act.chapters
            .map(
              (ch, i) => `
            <div onclick="GBApp.openBareActSectionList('${act.id}', '${ch.id}')" class="gb-card gb-card-interactive p-3.5 flex items-center justify-between gap-3 cursor-pointer">
              <div class="flex items-center gap-3 min-w-0">
                <div class="w-10 h-10 rounded-xl gb-surface-alt border border-amber-400/40 flex items-center justify-center text-sm font-black gb-text-gold shrink-0">
                  ${ch.roman || i + 1}
                </div>
                <div class="min-w-0">
                  <div class="text-xs font-extrabold">${ch.titleHindi}</div>
                  <div class="text-[11px] gb-text-sub">${ch.title}</div>
                  <div class="text-[10px] gb-text-gold font-bold mt-0.5">${ch.sectionsRange}</div>
                </div>
              </div>
              <span class="text-sm font-bold gb-text-accent">›</span>
            </div>
          `
            )
            .join("")}
        </div>
      </div>
    `;
  }

  // Bare Act Section List (PDF 3 Page 25 Left)
  function renderBareActSectionsScreen() {
    const act = getCurrentActObj();
    const ch = getCurrentChapterObj();
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2 min-w-0">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold shrink-0">←</button>
            <div class="min-w-0">
              <div class="text-xs font-extrabold truncate">${ch.titleHindi}</div>
              <div class="text-[10px] gb-text-sub truncate">${act.titleHindi} • ${ch.sectionsRange}</div>
            </div>
          </div>
        </div>

        <div class="p-3.5 space-y-2">
          ${ch.sections
            .map(
              (sec) => `
            <button onclick="GBApp.openBareActReader('${act.id}', '${ch.id}', '${sec.id}')" class="w-full gb-card gb-card-interactive p-3.5 flex items-center justify-between gap-3 text-left">
              <div class="flex items-center gap-3 min-w-0">
                <span class="w-9 h-9 rounded-xl gb-surface-alt border border-amber-400/40 flex items-center justify-center text-xs font-black gb-text-gold shrink-0">
                  ${sec.num}
                </span>
                <div class="min-w-0">
                  <div class="text-xs font-extrabold">${sec.titleHindi}</div>
                  <div class="text-[10px] gb-text-muted truncate">${sec.title}</div>
                </div>
              </div>
              <span class="text-xs font-bold gb-text-accent shrink-0">Dual Text ›</span>
            </button>
          `
            )
            .join("")}
        </div>
      </div>
    `;
  }

  // Bare Act Section Reader — Dual Format: मूल पाठ (Original Text) + सरल भाषा (Saral Text) (PDF 3 Page 25 Right)
  function renderBareActReaderScreen() {
    const act = getCurrentActObj();
    const ch = getCurrentChapterObj();
    const sec = getCurrentSectionObj();
    const isBookmarked = state.bookmarkedSections.includes(sec.id);
    const isEn = state.bareActLang === "en";
    const origText = isEn ? sec.bareActTextEnglish || sec.title : sec.bareActTextHindi || sec.summaryHindi;
    const saralText = isEn ? sec.saralTextEnglish || sec.summaryHindi : sec.saralTextHindi || sec.summaryHindi;

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2 min-w-0">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold shrink-0">←</button>
            <div class="min-w-0">
              <div class="text-xs font-extrabold truncate">${act.shortTitle} — ${sec.code}</div>
              <div class="text-[10px] gb-text-sub truncate">${sec.titleHindi}</div>
            </div>
          </div>
          <button onclick="GBApp.toggleBookmarkSection('${sec.id}')" class="px-2.5 py-1 rounded-lg gb-surface text-xs font-bold">
            ${isBookmarked ? "🔖 Saved" : "📑 Save"}
          </button>
        </div>

        <!-- Reader Controls Toolbar (हिंदी | English | बोलकर सुनें | Copy | A- A+) -->
        <div class="px-3 pt-2.5 flex flex-wrap items-center justify-between gap-1.5">
          <div class="flex rounded-lg overflow-hidden border border-purple-500/30 text-[11px] font-bold">
            <button onclick="GBApp.setBareActLang('hi')" class="px-2.5 py-1 ${!isEn ? "bg-amber-500 text-black font-black" : "gb-surface"}">हिंदी</button>
            <button onclick="GBApp.setBareActLang('en')" class="px-2.5 py-1 ${isEn ? "bg-amber-500 text-black font-black" : "gb-surface"}">English</button>
          </div>

          <button onclick="GBApp.speakBareActSection()" class="px-2.5 py-1 rounded-lg gb-surface-alt text-[11px] font-bold gb-text-accent flex items-center gap-1">
            <span>🔊 बोलकर सुनें</span>
          </button>

          <button onclick="GBApp.copyBareActSection()" class="px-2.5 py-1 rounded-lg gb-surface text-[11px] font-bold">
            📋 Copy
          </button>

          <div class="flex gap-1">
            <button onclick="GBApp.adjustReaderFont(-1)" class="px-2 py-1 rounded gb-surface text-[10px] font-bold">A-</button>
            <button onclick="GBApp.adjustReaderFont(1)" class="px-2 py-1 rounded gb-surface text-[10px] font-bold">A+</button>
          </div>
        </div>

        <!-- Format View Switcher: Dual Side-by-Side | मूल पाठ | सरल भाषा -->
        <div class="px-3 pt-2">
          <div class="grid grid-cols-3 gap-1.5 p-1 rounded-xl gb-surface text-[11px] font-bold">
            <button onclick="GBApp.setBareActFormat('dual')" class="py-1.5 rounded-lg ${state.bareActFormatMode === "dual" ? "gb-tab-active" : ""}">Dual Format</button>
            <button onclick="GBApp.setBareActFormat('original')" class="py-1.5 rounded-lg ${state.bareActFormatMode === "original" ? "gb-tab-active" : ""}">मूल पाठ (Original)</button>
            <button onclick="GBApp.setBareActFormat('saral')" class="py-1.5 rounded-lg ${state.bareActFormatMode === "saral" ? "gb-tab-active" : ""}">सरल भाषा (Saral)</button>
          </div>
        </div>

        <div class="p-3 space-y-3" style="font-size: ${state.readerFontSize}px">
          ${
            state.bareActFormatMode === "dual"
              ? `
            <!-- Dual Format Side-by-Side Comparison (PDF 3 Page 25 Right) -->
            <div class="grid grid-cols-2 gap-2.5">
              <div class="gb-card p-3 space-y-2 border-amber-500/40">
                <div class="text-xs font-black gb-text-gold border-b border-amber-500/20 pb-1.5">
                  📜 मूल पाठ (Original Text)
                </div>
                <div class="text-xs font-extrabold">${sec.code}:</div>
                <p class="text-xs gb-text-sub leading-relaxed whitespace-pre-line">${origText}</p>
              </div>

              <div class="gb-card p-3 space-y-2 border-purple-400/50">
                <div class="text-xs font-black gb-text-accent border-b border-purple-500/20 pb-1.5">
                  💡 सरल भाषा (Saral Text)
                </div>
                <div class="text-xs font-extrabold">${sec.code} (सरल अर्थ):</div>
                <p class="text-xs gb-text-sub leading-relaxed whitespace-pre-line">${saralText}</p>
              </div>
            </div>
          `
              : state.bareActFormatMode === "original"
              ? `
            <div class="gb-card p-4 space-y-2.5 border-amber-500/40">
              <div class="text-xs font-black gb-text-gold">📜 मूल पाठ (Original Bare Act Text)</div>
              <h3 class="text-sm font-extrabold">${sec.code}: ${isEn ? sec.title : sec.titleHindi}</h3>
              <p class="gb-text-sub leading-relaxed whitespace-pre-line">${origText}</p>
            </div>
          `
              : `
            <div class="gb-card p-4 space-y-2.5 border-purple-400/50">
              <div class="text-xs font-black gb-text-accent">💡 सरल भाषा (Saral Text Explanation)</div>
              <h3 class="text-sm font-extrabold">${sec.code}: ${isEn ? sec.title : sec.titleHindi}</h3>
              <p class="gb-text-sub leading-relaxed whitespace-pre-line">${saralText}</p>
            </div>
          `
          }

          <!-- Key Points Box -->
          <div class="gb-card p-3.5 space-y-1.5">
            <div class="text-xs font-extrabold gb-text-gold">★ मुख्य कानूनी बिंदु (Key Points):</div>
            <ul class="list-disc list-inside text-xs gb-text-sub space-y-1">
              ${(sec.keyPoints || []).map((pt) => `<li>${pt}</li>`).join("")}
            </ul>
          </div>

          <!-- Bottom Section Navigation (< पिछला सेक्शन | अगला सेक्शन >) -->
          <div class="flex items-center justify-between gap-2 pt-1">
            <button onclick="GBApp.navigateAdjacentSection(-1)" class="flex-1 py-2.5 gb-btn-outline text-xs">‹ पिछला सेक्शन</button>
            <button onclick="GBApp.navigateAdjacentSection(1)" class="flex-1 py-2.5 gb-btn-primary text-xs">अगला सेक्शन ›</button>
          </div>
        </div>
      </div>
    `;
  }
  // =========================================================================
  // SCREEN RENDERERS — PART C (Profile System: General User, Advocate, Law Student + Upgrade Plan)
  // =========================================================================

  function renderProfileScreen() {
    const gen = state.generalUserProfile;
    const adv = state.advocateProfile;
    const stu = state.studentProfile;

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">👤 My Profile</div>
              <div class="text-[10px] gb-text-sub">Common Account & 3 Profile Types</div>
            </div>
          </div>
          <button onclick="GBApp.navigateTo('settings')" class="px-2.5 py-1 rounded-full gb-surface text-xs font-bold">⚙️ Settings</button>
        </div>

        <div class="p-3.5 space-y-4">
          <!-- Main Account Header Card (PDF 3 Page 14) -->
          <div class="gb-card p-4 space-y-3 border-amber-400/50 relative">
            <div class="flex items-start justify-between gap-3">
              <div class="flex items-center gap-3">
                <div class="w-16 h-16 rounded-full gb-surface-alt border-2 border-amber-400 flex items-center justify-center text-2xl overflow-hidden shrink-0">
                  ${
                    gen.photoDataUrl
                      ? `<img src="${gen.photoDataUrl}" class="w-full h-full object-cover" />`
                      : `<span>👤</span>`
                  }
                </div>
                <div>
                  <h2 class="text-base font-black">${gen.fullName}</h2>
                  <div class="text-[11px] gb-text-sub">📞 ${gen.phone}</div>
                  <div class="text-[11px] gb-text-sub">✉️ ${gen.email}</div>
                  <div class="text-[10px] gb-text-muted mt-0.5">📅 Joined ${state.joinedDate}</div>
                </div>
              </div>
              <button onclick="GBApp.openProfileCreator('General')" class="px-3 py-1.5 rounded-xl gb-surface-alt text-[11px] font-extrabold gb-text-gold shrink-0">
                ✏️ Edit Profile
              </button>
            </div>
            <div class="text-center text-xs font-extrabold gb-text-gold pt-1 border-t border-purple-500/20">
              "Law for Every Indian"
            </div>
          </div>

          <!-- 3 Profile Types Switcher & Creator/Editor (Requirement #9) -->
          <div>
            <h3 class="text-xs font-extrabold mb-2">Create or Edit Profile Type (तीनों प्रोफाइल प्रकार):</h3>
            <div class="grid grid-cols-3 gap-2">
              <!-- 1. General User Profile -->
              <div class="gb-card p-2.5 flex flex-col justify-between text-center border-purple-400/40">
                <div>
                  <div class="text-xl">👤</div>
                  <div class="text-[11px] font-extrabold mt-1">General User</div>
                  <div class="text-[9px] gb-text-muted truncate">${gen.fullName}</div>
                </div>
                <button onclick="GBApp.openProfileCreator('General')" class="w-full py-1.5 mt-2 gb-btn-primary text-[10px]">
                  ✏️ Edit User
                </button>
              </div>

              <!-- 2. Advocate Profile -->
              <div class="gb-card p-2.5 flex flex-col justify-between text-center border-amber-400/40">
                <div>
                  <div class="text-xl">👨‍⚖️</div>
                  <div class="text-[11px] font-extrabold mt-1">Advocate</div>
                  <div class="text-[9px] gb-text-muted truncate">${adv.fullName}</div>
                </div>
                <div class="space-y-1 mt-2">
                  <button onclick="GBApp.openProfileCreator('Advocate')" class="w-full py-1 gb-btn-primary text-[10px]">✏️ Edit</button>
                  <button onclick="GBApp.openPublicProfileView('my_adv', 'about')" class="w-full py-1 gb-btn-outline text-[9px]">👁️ View</button>
                </div>
              </div>

              <!-- 3. Law Student Profile -->
              <div class="gb-card p-2.5 flex flex-col justify-between text-center border-sky-400/40">
                <div>
                  <div class="text-xl">🎓</div>
                  <div class="text-[11px] font-extrabold mt-1">Law Student</div>
                  <div class="text-[9px] gb-text-muted truncate">${stu.fullName}</div>
                </div>
                <div class="space-y-1 mt-2">
                  <button onclick="GBApp.openProfileCreator('Student')" class="w-full py-1 gb-btn-primary text-[10px]">✏️ Edit</button>
                  <button onclick="GBApp.openPublicProfileView('my_stu', 'about')" class="w-full py-1 gb-btn-outline text-[9px]">👁️ View</button>
                </div>
              </div>
            </div>
          </div>

          <!-- Premium Membership Card (PDF 3 Pages 14–15 & 29) -->
          <div class="gb-card p-4 space-y-3 border-amber-400/60">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <span class="text-xl">👑</span>
                <span class="text-sm font-black gb-text-gold">Premium Membership</span>
              </div>
              <span class="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-extrabold">● Active Plan</span>
            </div>
            <div class="grid grid-cols-2 gap-2 text-center">
              <div class="p-2.5 rounded-xl gb-surface">
                <div class="text-base font-black gb-text-gold">0</div>
                <div class="text-[10px] gb-text-muted">Months Left</div>
              </div>
              <div class="p-2.5 rounded-xl gb-surface">
                <div class="text-base font-black gb-text-gold">29</div>
                <div class="text-[10px] gb-text-muted">Days Left</div>
              </div>
            </div>
            <div class="grid grid-cols-3 gap-1 text-[10px] gb-text-sub text-center">
              <div>Plan: <strong>30 Days</strong></div>
              <div>Start: <strong>10 Sep</strong></div>
              <div>Expiry: <strong>09 Oct</strong></div>
            </div>
            <button onclick="GBApp.toggleUpgradeModal(true)" class="w-full py-2.5 gb-btn-gold text-xs flex items-center justify-center gap-1.5">
              <span>👑 Upgrade Plan (View 4 Plans)</span>
            </button>
          </div>

          <!-- Continue Learning Card -->
          <div class="gb-card p-3.5 space-y-2">
            <div class="text-xs font-extrabold gb-text-accent">▶ Continue Learning</div>
            <div class="flex items-center justify-between gap-2">
              <div>
                <div class="text-xs font-bold">BNS – Section 103 (Punishment for Murder)</div>
                <div class="text-[10px] gb-text-muted">Video • 12:40 left • 65% Completed</div>
              </div>
              <button onclick="GBApp.openCategoryMedia('video', 'bns_s103')" class="px-3.5 py-1.5 gb-btn-primary text-xs shrink-0">Resume ›</button>
            </div>
          </div>

          <!-- Referral & Earn Summary Card (PDF 3 Page 14) -->
          <div class="gb-card p-3.5 space-y-2.5">
            <div class="flex items-center justify-between">
              <span class="text-xs font-extrabold gb-text-gold">🎁 Referral & Earn (Demo)</span>
              <button onclick="GBApp.navigateTo('referral')" class="text-[11px] font-bold gb-text-accent">Open Details ›</button>
            </div>
            <div class="grid grid-cols-3 gap-2 text-center text-xs">
              <div class="p-2 rounded-xl gb-surface"><div class="font-black">${state.referralUsersCount}</div><div class="text-[9px] gb-text-muted">Total Referrals</div></div>
              <div class="p-2 rounded-xl gb-surface"><div class="font-black text-emerald-400">${state.freeDaysEarned} Days</div><div class="text-[9px] gb-text-muted">Free Earned</div></div>
              <div class="p-2 rounded-xl gb-surface"><div class="font-black gb-text-gold">29 Days</div><div class="text-[9px] gb-text-muted">Premium Left</div></div>
            </div>
          </div>

          <!-- All Profile Shortcuts -->
          <div class="grid grid-cols-2 gap-2 text-xs">
            <button onclick="GBApp.navigateTo('progress_tracking')" class="gb-card p-3 text-left font-bold">📊 Progress Tracking</button>
            <button onclick="GBApp.navigateTo('saved_items')" class="gb-card p-3 text-left font-bold">🔖 Saved / Favourites</button>
            <button onclick="GBApp.navigateTo('folders')" class="gb-card p-3 text-left font-bold">📁 Create Folder</button>
            <button onclick="GBApp.navigateTo('history_screen')" class="gb-card p-3 text-left font-bold">🕒 History</button>
            <button onclick="GBApp.navigateTo('request_topic')" class="gb-card p-3 text-left font-bold">💡 Request Topic</button>
            <button onclick="GBApp.navigateTo('chat_support')" class="gb-card p-3 text-left font-bold">🎧 Support Chat</button>
          </div>

          <button onclick="GBApp.logout(false)" class="w-full py-3 rounded-full bg-rose-600 text-white font-extrabold text-xs">
            🔒 Logout (Return to Common Login)
          </button>
        </div>

        <!-- Upgrade Plan Modal (PDF 3 Page 29: ₹99, ₹199, ₹299, ₹499) -->
        ${
          state.upgradeModalOpen
            ? `
          <div class="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3">
            <div class="gb-card w-full max-w-[420px] p-4 space-y-3 border-amber-400 max-h-[90vh] overflow-y-auto">
              <div class="flex items-center justify-between border-b border-purple-500/20 pb-2">
                <div class="flex items-center gap-2">
                  <span class="text-xl">👑</span>
                  <h3 class="text-base font-black gb-text-gold">Upgrade Plan (Demo Preview)</h3>
                </div>
                <button onclick="GBApp.toggleUpgradeModal(false)" class="w-8 h-8 rounded-full gb-surface font-bold">✕</button>
              </div>

              <div class="grid grid-cols-2 gap-2.5 text-center">
                ${[
                  { id: "1_month", dur: "1 Month", oldP: "₹150", newP: "₹99", off: "33% OFF", tag: "" },
                  { id: "3_months", dur: "3 Months", oldP: "₹270", newP: "₹199", off: "26% OFF", tag: "" },
                  { id: "6_months", dur: "6 Months", oldP: "₹400", newP: "₹299", off: "25% OFF", tag: "Most Popular" },
                  { id: "12_months", dur: "12 Months", oldP: "₹625", newP: "₹499", off: "20% OFF", tag: "Best Value" }
                ]
                  .map(
                    (pl) => `
                  <div onclick="GBApp.selectUpgradePlan('${pl.id}')" class="p-3 rounded-2xl border cursor-pointer relative flex flex-col justify-between ${
                      state.selectedUpgradePlan === pl.id ? "gb-tab-active border-amber-400" : "gb-surface"
                    }">
                    ${
                      pl.tag
                        ? `<span class="px-2 py-0.5 rounded-full bg-amber-500 text-black text-[9px] font-black mx-auto mb-1">${pl.tag}</span>`
                        : `<div class="h-4"></div>`
                    }
                    <div class="text-xs font-extrabold">${pl.dur}</div>
                    <div class="text-[10px] gb-text-muted line-through mt-0.5">${pl.oldP}</div>
                    <div class="text-xl font-black gb-text-gold">${pl.newP}</div>
                    <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-bold mt-1 inline-block">${pl.off}</span>
                    <button onclick="event.stopPropagation(); GBApp.activateDemoPlan()" class="w-full py-1.5 mt-2 gb-btn-gold text-[10px]">Upgrade Now</button>
                  </div>
                `
                  )
                  .join("")}
              </div>
              <div class="text-[10px] gb-text-muted text-center">
                📌 Demo Notice: इस फेज में Razorpay पेमेंट गेटवे निष्क्रिय है; कोई वास्तविक शुल्क नहीं काटा जाएगा।
              </div>
            </div>
          </div>
        `
            : ""
        }
      </div>
    `;
  }

  // Update General User Profile Form (PDF 3 Page 16)
  function renderUpdateGeneralProfileScreen() {
    const g = state.generalUserProfile;
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center gap-2 border-b border-purple-500/20">
          <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
          <div>
            <div class="text-sm font-extrabold">Update Profile (General User)</div>
            <div class="text-[10px] gb-text-sub">Edit your personal & educational details</div>
          </div>
        </div>

        <div class="p-3.5 space-y-3.5 text-xs">
          <div class="gb-card p-4 text-center space-y-2">
            <div class="w-20 h-20 rounded-full gb-surface-alt border-2 border-amber-400 mx-auto overflow-hidden flex items-center justify-center text-3xl">
              ${g.photoDataUrl ? `<img src="${g.photoDataUrl}" class="w-full h-full object-cover" />` : `👤`}
            </div>
            <label for="gen-photo-inp" class="inline-block px-4 py-1.5 gb-btn-primary text-xs cursor-pointer">
              📷 Upload Profile Photo
            </label>
            <input id="gen-photo-inp" type="file" accept="image/*" class="hidden" onchange="GBApp.handleFileSelection(this, 'gen_photo')" />
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div>
              <label class="font-bold block mb-1">Full Name *</label>
              <input id="gen-name" type="text" value="${g.fullName}" class="gb-input" />
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="font-bold block mb-1">Mobile Number *</label>
                <input id="gen-phone" type="tel" value="${g.phone}" class="gb-input" />
              </div>
              <div>
                <label class="font-bold block mb-1">Email</label>
                <input id="gen-email" type="email" value="${g.email}" class="gb-input" />
              </div>
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="font-bold block mb-1">State</label>
                <select id="gen-state" class="gb-input">
                  ${["Uttar Pradesh", "Delhi", "Madhya Pradesh", "Bihar", "Rajasthan", "Maharashtra"]
                    .map((st) => `<option value="${st}" ${g.state === st ? "selected" : ""}>${st}</option>`)
                    .join("")}
                </select>
              </div>
              <div>
                <label class="font-bold block mb-1">District</label>
                <input id="gen-district" type="text" value="${g.district}" class="gb-input" />
              </div>
            </div>
            <div>
              <label class="font-bold block mb-1">Address</label>
              <input id="gen-address" type="text" value="${g.address}" class="gb-input" />
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="font-bold block mb-1">City</label>
                <input id="gen-city" type="text" value="${g.city}" class="gb-input" />
              </div>
              <div>
                <label class="font-bold block mb-1">Pincode</label>
                <input id="gen-pincode" type="text" value="${g.pincode}" class="gb-input" />
              </div>
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="font-bold block mb-1">Date of Birth</label>
                <input id="gen-dob" type="date" value="${g.dob}" class="gb-input" />
              </div>
              <div>
                <label class="font-bold block mb-1">Gender</label>
                <select id="gen-gender" class="gb-input">
                  <option value="Male" ${g.gender === "Male" ? "selected" : ""}>Male</option>
                  <option value="Female" ${g.gender === "Female" ? "selected" : ""}>Female</option>
                  <option value="Other" ${g.gender === "Other" ? "selected" : ""}>Other</option>
                </select>
              </div>
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="font-bold block mb-1">User Category</label>
                <select id="gen-cat" class="gb-input">
                  <option value="General Citizen">General Citizen</option>
                  <option value="Law Aspirant / Citizen" selected>Law Aspirant / Citizen</option>
                  <option value="Advocate">Advocate</option>
                  <option value="Law Student">Law Student</option>
                </select>
              </div>
              <div>
                <label class="font-bold block mb-1">Professional Course</label>
                <select id="gen-course" class="gb-input">
                  <option value="BA LL.B / Judiciary Prep">BA LL.B / Judiciary Prep</option>
                  <option value="LL.B">LL.B</option>
                  <option value="LL.M">LL.M</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>
            <div>
              <label class="font-bold block mb-1">Law University / College</label>
              <input id="gen-college" type="text" value="${g.college}" class="gb-input" />
            </div>

            <button onclick="GBApp.saveGeneralUserProfile()" class="w-full py-3 gb-btn-primary text-xs mt-2">
              💾 Save Profile
            </button>
          </div>
        </div>
      </div>
    `;
  }
  // Create / Edit Advocate Profile Form
  function renderCreateAdvocateProfileScreen() {
    const p = state.advocateProfile;
    const allAreas = ["Civil Law", "Criminal Law", "Constitutional Law", "Family Law", "Property Law", "Bail Matters", "Legal Drafting", "Cyber Law", "Corporate Law"];
    const allCourts = ["Allahabad High Court", "District & Sessions Court", "Civil Court", "Family Court", "Criminal Court", "Supreme Court"];

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">👨‍⚖️ Create / Edit Advocate Profile</div>
              <div class="text-[10px] gb-text-sub">Verification: Pending / Demo Status</div>
            </div>
          </div>
        </div>

        <div class="p-3.5 space-y-3.5 text-xs">
          <div class="gb-card p-4 text-center space-y-2">
            <div class="w-20 h-20 rounded-full gb-surface-alt border-2 border-amber-400 mx-auto overflow-hidden flex items-center justify-center text-3xl">
              ${p.photoDataUrl ? `<img src="${p.photoDataUrl}" class="w-full h-full object-cover" />` : `👨‍⚖️`}
            </div>
            <label for="adv-photo-inp" class="inline-block px-4 py-1.5 gb-btn-primary text-xs cursor-pointer">
              📷 Upload Advocate Photo
            </label>
            <input id="adv-photo-inp" type="file" accept="image/*" class="hidden" onchange="GBApp.handleFileSelection(this, 'adv_photo')" />
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div class="font-extrabold gb-text-accent">1. Personal & Bar Council Information</div>
            <div>
              <label class="font-bold block mb-1">Full Name (Required) *</label>
              <input id="adv-name" type="text" value="${p.fullName}" class="gb-input" />
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="font-bold block mb-1">Father's Name</label>
                <input id="adv-father" type="text" value="${p.fatherName}" class="gb-input" />
              </div>
              <div>
                <label class="font-bold block mb-1">Mobile Number *</label>
                <input id="adv-phone" type="tel" value="${p.phone}" class="gb-input" />
              </div>
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="font-bold block mb-1">Enrollment Number *</label>
                <input id="adv-barno" type="text" value="${p.barNo}" class="gb-input" />
              </div>
              <div>
                <label class="font-bold block mb-1">Experience</label>
                <select id="adv-exp" class="gb-input">
                  ${["3+ Years", "5+ Years", "8+ Years", "12+ Years", "16+ Years"].map((x) => `<option value="${x}" ${p.experience === x ? "selected" : ""}>${x}</option>`).join("")}
                </select>
              </div>
            </div>
            <div>
              <label class="font-bold block mb-1">Primary Court / Jurisdiction</label>
              <input id="adv-court" type="text" value="${p.primaryCourt}" class="gb-input" />
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="font-bold block mb-1">City / District</label>
                <input id="adv-city" type="text" value="${p.city}" class="gb-input" />
              </div>
              <div>
                <label class="font-bold block mb-1">Chamber / Office Name</label>
                <input id="adv-chamber" type="text" value="${p.chamberName}" class="gb-input" />
              </div>
            </div>
            <div>
              <label class="font-bold block mb-1">Education & Qualifications</label>
              <input id="adv-edu" type="text" value="${p.education}" class="gb-input" />
            </div>
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div class="font-extrabold gb-text-accent">2. Practice Areas & Courts</div>
            <div class="flex flex-wrap gap-1.5">
              ${allAreas.map((area) => {
                const active = p.practiceAreas.includes(area);
                return `<button onclick="GBApp.toggleArrayItem('advocateProfile', 'practiceAreas', '${area}')" class="px-2.5 py-1 rounded-full text-[11px] font-bold border ${active ? "gb-tab-active" : "gb-surface"}">${area} ${active ? "✓" : "+"}</button>`;
              }).join("")}
            </div>
            <div class="font-bold pt-1">Courts Practicing In:</div>
            <div class="flex flex-wrap gap-1.5">
              ${allCourts.map((c) => {
                const active = p.courtsPracticing.includes(c);
                return `<button onclick="GBApp.toggleArrayItem('advocateProfile', 'courtsPracticing', '${c}')" class="px-2.5 py-1 rounded-lg text-[11px] font-bold border ${active ? "gb-tab-active" : "gb-surface"}">${c} ${active ? "✓" : ""}</button>`;
              }).join("")}
            </div>
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div class="font-extrabold gb-text-accent">3. Bio & Bar ID Upload (Demo)</div>
            <textarea id="adv-bio" rows="2" class="gb-input">${p.bio}</textarea>
            <div class="p-2.5 rounded-xl gb-surface flex items-center justify-between">
              <div>
                <div class="font-bold">🪪 Bar Council ID (PDF/Image)</div>
                <div class="text-[10px] gb-text-muted">${p.barIdFileName}</div>
              </div>
              <label for="adv-barid-inp" class="px-3 py-1.5 rounded-lg gb-surface-alt font-bold text-[10px] cursor-pointer">Upload</label>
              <input id="adv-barid-inp" type="file" accept=".pdf,image/*" class="hidden" onchange="GBApp.handleFileSelection(this, 'adv_bar_id')" />
            </div>
          </div>

          <button onclick="GBApp.saveAdvocateProfileForm()" class="w-full py-3 gb-btn-primary text-xs">
            ✓ Save & View Advocate 3-Tab Profile
          </button>
        </div>
      </div>
    `;
  }

  // Create / Edit Law Student Profile Form
  function renderCreateStudentProfileScreen() {
    const s = state.studentProfile;
    const allSkills = ["Legal Research", "Case Analysis", "Drafting", "Judgment Reading", "MS Word", "Communication", "Moot Court"];
    const allInterests = ["Criminal Law", "Constitutional Law", "Court Practice", "Legal Research", "Drafting", "Moot Court", "Family Law"];

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">🎓 Create / Edit Law Student Profile</div>
              <div class="text-[10px] gb-text-sub">For Internships, Guidance & Research (Demo)</div>
            </div>
          </div>
        </div>

        <div class="p-3.5 space-y-3.5 text-xs">
          <div class="gb-card p-4 text-center space-y-2">
            <div class="w-20 h-20 rounded-full gb-surface-alt border-2 border-purple-400 mx-auto overflow-hidden flex items-center justify-center text-3xl">
              ${s.photoDataUrl ? `<img src="${s.photoDataUrl}" class="w-full h-full object-cover" />` : `🎓`}
            </div>
            <label for="stu-photo-inp" class="inline-block px-4 py-1.5 gb-btn-primary text-xs cursor-pointer">
              📷 Upload Student Photo
            </label>
            <input id="stu-photo-inp" type="file" accept="image/*" class="hidden" onchange="GBApp.handleFileSelection(this, 'stu_photo')" />
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div>
              <label class="font-bold block mb-1">Full Name (Required) *</label>
              <input id="stu-name" type="text" value="${s.fullName}" class="gb-input" />
            </div>
            <div>
              <label class="font-bold block mb-1">Law College / University *</label>
              <input id="stu-college" type="text" value="${s.college}" class="gb-input" />
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="font-bold block mb-1">Course</label>
                <select id="stu-course" class="gb-input">
                  ${["B.A. LL.B.", "LL.B (3 Years)", "BBA LL.B.", "LL.M."].map((c) => `<option value="${c}" ${s.course === c ? "selected" : ""}>${c}</option>`).join("")}
                </select>
              </div>
              <div>
                <label class="font-bold block mb-1">Semester / Year</label>
                <input id="stu-sem" type="text" value="${s.semester}" class="gb-input" />
              </div>
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="font-bold block mb-1">Passing Year</label>
                <input id="stu-passyr" type="text" value="${s.passingYear}" class="gb-input" />
              </div>
              <div>
                <label class="font-bold block mb-1">City / State</label>
                <input id="stu-city" type="text" value="${s.city}" class="gb-input" />
              </div>
            </div>
          </div>

          <div class="gb-card p-3.5 space-y-2">
            <div class="font-extrabold gb-text-accent">Skills & Interests</div>
            <div class="flex flex-wrap gap-1.5">
              ${allSkills.map((sk) => {
                const active = s.skills.includes(sk);
                return `<button onclick="GBApp.toggleArrayItem('studentProfile', 'skills', '${sk}')" class="px-2.5 py-1 rounded-full text-[11px] font-bold border ${active ? "gb-tab-active" : "gb-surface"}">${sk} ${active ? "✓" : "+"}</button>`;
              }).join("")}
            </div>
            <div class="font-bold pt-1">Areas of Interest:</div>
            <div class="flex flex-wrap gap-1.5">
              ${allInterests.map((intr) => {
                const active = s.interests.includes(intr);
                return `<button onclick="GBApp.toggleArrayItem('studentProfile', 'interests', '${intr}')" class="px-2.5 py-1 rounded-full text-[11px] font-bold border ${active ? "gb-tab-active" : "gb-surface"}">${intr} ${active ? "✓" : "+"}</button>`;
              }).join("")}
            </div>
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div>
              <label class="font-bold block mb-1">Achievements & Moot Courts</label>
              <input id="stu-ach" type="text" value="${s.achievements}" class="gb-input" />
            </div>
            <div>
              <label class="font-bold block mb-1">About Me</label>
              <textarea id="stu-bio" rows="2" class="gb-input">${s.bio}</textarea>
            </div>
            <div class="p-2.5 rounded-xl gb-surface flex items-center justify-between">
              <div>
                <div class="font-bold">📄 Resume / CV (PDF)</div>
                <div class="text-[10px] gb-text-muted">${s.resumeFileName}</div>
              </div>
              <label for="stu-res-inp" class="px-3 py-1.5 rounded-lg gb-surface-alt font-bold text-[10px] cursor-pointer">Upload</label>
              <input id="stu-res-inp" type="file" accept=".pdf,image/*" class="hidden" onchange="GBApp.handleFileSelection(this, 'stu_resume')" />
            </div>
          </div>

          <button onclick="GBApp.saveStudentProfileForm()" class="w-full py-3 gb-btn-primary text-xs">
            ✓ Save & View Law Student 3-Tab Profile
          </button>
        </div>
      </div>
    `;
  }

  // 3-Tab Advocate & Law Student Public Profile View (PDF 2 Pages 7–12)
  function renderViewProfileDetailScreen() {
    const isStudent = state.viewingProfileId === "my_stu" || state.viewingProfileId.startsWith("stu");
    const stu = DATA.studentsDirectory.find((x) => x.id === state.viewingProfileId) || {
      id: "my_stu",
      name: state.studentProfile.fullName,
      course: state.studentProfile.course,
      semester: state.studentProfile.semester,
      yearText: state.studentProfile.semester,
      college: state.studentProfile.college,
      passingYear: state.studentProfile.passingYear,
      city: state.studentProfile.city,
      rating: "4.8",
      reviewsCount: 120,
      verificationStatus: state.studentProfile.verificationStatus,
      openForInternship: true,
      preferredLocations: ["Varanasi, UP", "Lucknow, UP", "Delhi"],
      preferredDuration: state.studentProfile.preferredDuration,
      mode: state.studentProfile.internMode,
      stipendPref: state.studentProfile.stipendPref,
      langs: state.studentProfile.languages,
      skills: state.studentProfile.skills,
      interests: state.studentProfile.interests,
      hobbies: state.studentProfile.hobbies,
      achievements: [state.studentProfile.achievements],
      guidanceTopics: DATA.studentsDirectory[0].guidanceTopics,
      bio: state.studentProfile.bio
    };

    const adv = DATA.advocatesDirectory.find((x) => x.id === state.viewingProfileId) || {
      id: "my_adv",
      name: state.advocateProfile.fullName,
      fatherName: state.advocateProfile.fatherName,
      dob: state.advocateProfile.dob,
      gender: state.advocateProfile.gender,
      role: "Advocate (High Court)",
      city: state.advocateProfile.city,
      state: state.advocateProfile.state,
      district: "Prayagraj",
      court: state.advocateProfile.primaryCourt,
      barCouncil: state.advocateProfile.barCouncil,
      barNo: state.advocateProfile.barNo,
      enrollDate: state.advocateProfile.enrollDate,
      enrollType: state.advocateProfile.enrollType,
      barStatus: "Active (Demo)",
      advocateType: "Practicing Advocate",
      barCouncilId: state.advocateProfile.barCouncilId,
      chamberName: state.advocateProfile.chamberName,
      chamberNo: state.advocateProfile.chamberNo,
      workingDays: state.advocateProfile.workingDays,
      verificationStatus: state.advocateProfile.verificationStatus,
      exp: state.advocateProfile.experience,
      rating: "4.8",
      reviewsCount: 120,
      langs: state.advocateProfile.languages,
      education: [state.advocateProfile.education],
      certifications: [state.advocateProfile.certifications],
      practiceAreas: state.advocateProfile.practiceAreas,
      courtsPracticing: state.advocateProfile.courtsPracticing,
      servicesOffered: DATA.advocatesDirectory[0].servicesOffered,
      consultationModes: ["Phone Call", "Video Call", "Chat Consultation", "Office / Chamber Visit"],
      plans: DATA.advocatesDirectory[0].plans,
      achievements: DATA.advocatesDirectory[0].achievements,
      bio: state.advocateProfile.bio
    };

    const p = isStudent ? stu : adv;

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">${isStudent ? "🎓 Law Student Profile" : "👨‍⚖️ Advocate Profile"}</div>
              <div class="text-[10px] gb-text-sub">3-Tab Detailed Profile (Demo)</div>
            </div>
          </div>
          <button onclick="GBApp.openProfileCreator('${isStudent ? "Student" : "Advocate"}')" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-bold gb-text-accent">
            ✏️ Edit
          </button>
        </div>

        <div class="p-3.5 space-y-3.5">
          <!-- Profile Top Card (PDF 2 Pages 7 & 10) -->
          <div class="gb-card p-4 space-y-2.5 border-purple-400/50">
            <div class="flex items-start gap-3">
              <div class="w-16 h-16 rounded-2xl gb-surface-alt border-2 border-amber-400 flex items-center justify-center text-3xl shrink-0">
                ${isStudent ? "🎓" : "👨‍⚖️"}
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center justify-between">
                  <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-bold">✔ ${p.verificationStatus}</span>
                  <span class="text-xs font-black gb-text-gold">★ ${p.rating} (${p.reviewsCount})</span>
                </div>
                <h2 class="text-base font-black mt-1">${p.name}</h2>
                <div class="text-xs font-bold gb-text-accent">${isStudent ? `${p.course} (${p.semester}) • ${p.college}` : `${p.role} • ${p.exp}`}</div>
                <div class="text-[11px] gb-text-sub mt-0.5">📍 ${p.city} ${!isStudent ? `• 🏛️ ${p.court}` : ""}</div>
              </div>
            </div>

            <!-- 3 Tabs Bar -->
            <div class="grid grid-cols-3 gap-1.5 pt-2 border-t border-purple-500/20">
              <button onclick="GBApp.setViewingProfileTab('about')" class="py-2 px-1 rounded-xl text-[10px] font-bold border text-center ${
                state.viewingProfileTab === "about" ? "gb-tab-active" : "gb-surface"
              }">About Me</button>
              <button onclick="GBApp.setViewingProfileTab('professional')" class="py-2 px-1 rounded-xl text-[10px] font-bold border text-center ${
                state.viewingProfileTab === "professional" ? "gb-tab-active" : "gb-surface"
              }">${isStudent ? "Guidance & Advice" : "Professional Details"}</button>
              <button onclick="GBApp.setViewingProfileTab('consulting')" class="py-2 px-1 rounded-xl text-[10px] font-bold border text-center ${
                state.viewingProfileTab === "consulting" ? "gb-tab-active" : "gb-surface"
              }">${isStudent ? "Internship" : "Legal Advice & Consulting"}</button>
            </div>
          </div>

          <!-- TAB 1: ABOUT ME (PDF 2 Page 7 for Advocate, Page 10 for Student) -->
          ${
            state.viewingProfileTab === "about"
              ? `
            <div class="space-y-3 text-xs">
              <div class="gb-card p-3.5 space-y-2">
                <div class="font-extrabold gb-text-accent">📋 Key Information</div>
                ${
                  isStudent
                    ? `
                  <div>• <strong>Course:</strong> ${p.course} (${p.yearText || p.semester})</div>
                  <div>• <strong>College:</strong> ${p.college}</div>
                  <div>• <strong>Location:</strong> ${p.city}</div>
                  <div>• <strong>Internship Status:</strong> <span class="text-emerald-400 font-bold">Open for Internship</span></div>
                `
                    : `
                  <div class="grid grid-cols-2 gap-1.5">
                    <div><strong>Name:</strong> ${p.name}</div>
                    <div><strong>Father's Name:</strong> ${p.fatherName || "Mr. Suresh Sharma"}</div>
                    <div><strong>DOB:</strong> ${p.dob || "15 March 1992"}</div>
                    <div><strong>Gender:</strong> ${p.gender || "Male"}</div>
                    <div><strong>State:</strong> ${p.state}</div>
                    <div><strong>City:</strong> ${p.city}</div>
                  </div>
                `
                }
              </div>

              <div class="gb-card p-3.5 space-y-1.5">
                <div class="font-extrabold gb-text-accent">📝 About Me</div>
                <p class="gb-text-sub leading-relaxed">${p.bio}</p>
              </div>

              <div class="gb-card p-3.5 space-y-2">
                <div class="font-extrabold gb-text-accent">⚖️ ${isStudent ? "Areas of Interest & Skills" : "Education & Languages"}</div>
                ${
                  isStudent
                    ? `
                  <div class="flex flex-wrap gap-1.5">
                    ${(p.interests || []).map((it) => `<span class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-bold">${it}</span>`).join("")}
                  </div>
                  <div class="font-bold pt-1">Skills:</div>
                  <div class="flex flex-wrap gap-1.5">
                    ${(p.skills || []).map((sk) => `<span class="px-2.5 py-1 rounded-lg gb-surface text-[10px] font-bold">✔ ${sk}</span>`).join("")}
                  </div>
                `
                    : `
                  <ul class="list-disc list-inside gb-text-sub space-y-1">
                    ${(p.education || []).map((ed) => `<li>${ed}</li>`).join("")}
                    ${(p.certifications || []).map((cf) => `<li>${cf}</li>`).join("")}
                  </ul>
                `
                }
                <div class="pt-1"><strong>🗣️ Languages Spoken:</strong> ${(p.langs || []).join(", ")}</div>
              </div>

              <div class="gb-card p-3.5 space-y-1.5">
                <div class="font-extrabold gb-text-gold">🏆 Achievements & Social Media Links</div>
                <ul class="list-disc list-inside gb-text-sub space-y-1">
                  ${(Array.isArray(p.achievements) ? p.achievements : [p.achievements]).map((ac) => `<li>${ac}</li>`).join("")}
                </ul>
                <div class="flex flex-wrap gap-1.5 pt-2">
                  ${["Facebook", "Instagram", "LinkedIn", "X (Twitter)", "YouTube"]
                    .map((soc) => `<span class="px-2.5 py-1 rounded-lg gb-surface text-[10px] font-bold">🔗 ${soc}</span>`)
                    .join("")}
                </div>
              </div>
            </div>
          `
              : state.viewingProfileTab === "professional"
              ? isStudent
                ? `
              <!-- STUDENT TAB 2: GUIDANCE & ADVICE (PDF 2 Page 11) -->
              <div class="space-y-3 text-xs">
                <div class="gb-card p-3.5 space-y-2">
                  <div class="font-extrabold gb-text-accent">🎓 Guidance & Advice Offered by ${p.name}</div>
                  <div class="grid grid-cols-1 gap-1.5">
                    ${(p.guidanceTopics || DATA.studentsDirectory[0].guidanceTopics)
                      .map((gt) => `<div class="p-2 rounded-lg gb-surface font-semibold">✔ ${gt}</div>`)
                      .join("")}
                  </div>
                </div>

                <div class="gb-card p-3.5 space-y-2.5">
                  <div class="font-extrabold gb-text-gold">💰 Select Guidance Type:</div>
                  <div class="grid grid-cols-2 gap-2">
                    <button onclick="GBApp.selectStuGuidanceType('Free')" class="p-2.5 rounded-xl border text-left ${
                      state.studentProfile.guidanceType === "Free" ? "gb-tab-active" : "gb-surface"
                    }">
                      <div class="font-black">Free Guidance</div>
                      <div class="text-[10px] gb-text-muted">General help for students</div>
                    </button>
                    <button onclick="GBApp.selectStuGuidanceType('Paid')" class="p-2.5 rounded-xl border text-left ${
                      state.studentProfile.guidanceType === "Paid" ? "gb-tab-active" : "gb-surface"
                    }">
                      <div class="font-black gb-text-gold">Paid Guidance (₹49)</div>
                      <div class="text-[10px] gb-text-muted">1-on-1 Detailed Session (Demo)</div>
                    </button>
                  </div>

                  <div class="flex gap-2 pt-1">
                    <button onclick="GBApp.openConversationWith('${p.name}', '${p.course}', 'Student')" class="flex-1 py-2.5 gb-btn-primary text-xs">
                      💬 Start Live Chat with ${p.name}
                    </button>
                  </div>
                </div>
              </div>
            `
                : `
              <!-- ADVOCATE TAB 2: PROFESSIONAL DETAILS (PDF 2 Page 8) -->
              <div class="space-y-3 text-xs">
                <div class="gb-card p-3.5 space-y-1.5">
                  <div class="font-extrabold gb-text-accent">🪪 Bar Council & Registration Details</div>
                  <div>• <strong>State Bar Council:</strong> ${p.barCouncil}</div>
                  <div>• <strong>Enrollment No.:</strong> ${p.barNo}</div>
                  <div>• <strong>Enrollment Date:</strong> ${p.enrollDate} (${p.enrollType})</div>
                  <div>• <strong>Bar Status:</strong> <span class="text-amber-400 font-bold">Pending Govt Verification (Demo)</span></div>
                  <div>• <strong>Bar Council ID:</strong> ${p.barCouncilId}</div>
                </div>

                <div class="gb-card p-3.5 space-y-2">
                  <div class="font-extrabold gb-text-accent">⚖️ Practice Areas & Court Jurisdiction</div>
                  <div class="flex flex-wrap gap-1.5">
                    ${(p.practiceAreas || []).map((pa) => `<span class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-bold">${pa}</span>`).join("")}
                  </div>
                  <div class="pt-1"><strong>Primary Court:</strong> ${p.court}</div>
                  <div><strong>Courts Practicing In:</strong> ${(p.courtsPracticing || []).join(", ")}</div>
                </div>

                <div class="gb-card p-3.5 space-y-1.5">
                  <div class="font-extrabold gb-text-gold">🏢 Chamber / Office Details & Map</div>
                  <div><strong>Office Name:</strong> ${p.chamberName}</div>
                  <div><strong>Chamber No.:</strong> ${p.chamberNo}</div>
                  <div><strong>Working Hours:</strong> ${p.workingDays}</div>
                  <div class="p-3 rounded-xl gb-surface flex items-center justify-between mt-2">
                    <span>📍 Map Location: High Court Compound, ${p.city}</span>
                    <button onclick="GBApp.showToast('🗺️ Opening Chamber Location in Map - Demo')" class="px-2.5 py-1 rounded bg-purple-600 text-white text-[10px] font-bold">Open Map</button>
                  </div>
                </div>
              </div>
            `
              : isStudent
              ? `
            <!-- STUDENT TAB 3: INTERNSHIP CONSULTING PROFILE (PDF 2 Page 12) -->
            <div class="space-y-3 text-xs">
              <div class="gb-card p-3.5 space-y-2">
                <div class="font-extrabold gb-text-accent">💼 Internship Preferences & Availability</div>
                <div>📍 <strong>Preferred Locations:</strong> ${(p.preferredLocations || []).join(" | ")}</div>
                <div>⏳ <strong>Internship Duration:</strong> ${p.preferredDuration}</div>
                <div>💻 <strong>Mode:</strong> ${p.mode}</div>
                <div>💰 <strong>Stipend Preference:</strong> ${p.stipendPref}</div>
              </div>

              <div class="gb-card p-3.5 space-y-2">
                <div class="font-extrabold gb-text-gold">📎 Uploaded Documents (Demo)</div>
                <div class="p-2.5 rounded-xl gb-surface flex items-center justify-between">
                  <span>📄 Resume / CV (PDF • 1.2 MB)</span>
                  <a href="${DATA.assets.samplePdf}" download="Student_Resume_Demo.pdf" class="px-2.5 py-1 rounded gb-surface-alt text-[10px] font-bold gb-text-accent">Download</a>
                </div>
                <div class="p-2.5 rounded-xl gb-surface flex items-center justify-between">
                  <span>🪪 College ID Card (PDF • 0.8 MB)</span>
                  <button onclick="GBApp.showToast('🪪 Viewing Student ID Card - Demo')" class="px-2.5 py-1 rounded gb-surface-alt text-[10px] font-bold gb-text-accent">View</button>
                </div>
              </div>

              <button onclick="GBApp.openConversationWith('${p.name}', '${p.course}', 'Student')" class="w-full py-3 gb-btn-primary text-xs">
                💬 Send Message / Offer Internship via Live Chat
              </button>
            </div>
          `
              : `
            <!-- ADVOCATE TAB 3: LEGAL ADVICE & CONSULTING (PDF 2 Page 9) -->
            <div class="space-y-3 text-xs">
              <div class="gb-card p-3.5 space-y-2">
                <div class="font-extrabold gb-text-accent">⚖️ Legal Services Offered</div>
                <div class="grid grid-cols-2 gap-1.5">
                  ${(p.servicesOffered || DATA.advocatesDirectory[0].servicesOffered)
                    .map((srv) => `<div class="p-2 rounded-lg gb-surface text-[11px] font-semibold">✔ ${srv}</div>`)
                    .join("")}
                </div>
              </div>

              <!-- 3 Consultation Plans: Free ₹0 | Standard ₹149 | Premium ₹299 -->
              <div class="gb-card p-3.5 space-y-2.5">
                <div class="font-extrabold gb-text-gold">💳 Consultation Plans (Demo):</div>
                <div class="grid grid-cols-3 gap-2 text-center">
                  ${(p.plans || DATA.advocatesDirectory[0].plans)
                    .map(
                      (pl) => `
                    <button onclick="GBApp.selectAdvPlanTier('${pl.name}')" class="p-2.5 rounded-xl border flex flex-col justify-between ${
                        state.advocateProfile.selectedPlanTier === pl.name ? "gb-tab-active border-amber-400" : "gb-surface"
                      }">
                      <div class="text-[10px] font-extrabold">${pl.name}</div>
                      <div class="text-sm font-black gb-text-gold my-1">${pl.fee}</div>
                      <div class="text-[9px] gb-text-muted leading-tight">${pl.desc}</div>
                    </button>
                  `
                    )
                    .join("")}
                </div>
              </div>

              <!-- Direct Actions: Live Chat | Appointment Booking | Document Service -->
              <div class="space-y-2">
                <button onclick="GBApp.openConversationWith('${p.name}', '${p.role}', 'Advocate')" class="w-full py-3 gb-btn-primary text-xs flex items-center justify-center gap-2">
                  <span>💬 Start Live Chat Consultation with ${p.name}</span>
                </button>
                <div class="grid grid-cols-2 gap-2">
                  <button onclick="GBApp.openAppointmentFlow('${p.id}', 'form')" class="py-2.5 gb-btn-gold text-xs">
                    📅 Book Appointment
                  </button>
                  <button onclick="GBApp.openDocumentServiceFlow('form')" class="py-2.5 gb-btn-outline text-xs">
                    📄 Document Service
                  </button>
                </div>
              </div>
            </div>
          `
          }
        </div>
      </div>
    `;
  }
  // =========================================================================
  // SCREEN RENDERERS — PART D (Find Advocate/Student, Internships, Appointments, Documents & LIVE CHAT)
  // =========================================================================

  // Requirement #10: Find My Advocate, Find My Student & Internships (PDF 2 Pages 1–6)
  function renderFindAdvocateScreen() {
    const q = state.directorySearch.trim().toLowerCase();

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">Find My Advocate & Student</div>
              <div class="text-[10px] gb-text-sub">Advocates, Law Students & Internships (Demo)</div>
            </div>
          </div>
          <button onclick="GBApp.openProfileCreator('${state.directoryTab === "students" ? "Student" : "Advocate"}')" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-extrabold gb-text-accent">
            + Create Profile
          </button>
        </div>

        <div class="p-3 space-y-3">
          <!-- Top Switcher Pills: Advocate | Law Student | Stu Internships | Adv Internships -->
          <div class="grid grid-cols-4 gap-1 p-1 rounded-xl gb-surface text-[10px] font-bold">
            <button onclick="GBApp.setDirectoryTab('advocates')" class="py-2 rounded-lg ${state.directoryTab === "advocates" ? "gb-tab-active" : ""}">👨‍⚖️ Advocates</button>
            <button onclick="GBApp.setDirectoryTab('students')" class="py-2 rounded-lg ${state.directoryTab === "students" ? "gb-tab-active" : ""}">🎓 Students</button>
            <button onclick="GBApp.setDirectoryTab('internships_stu')" class="py-2 rounded-lg ${state.directoryTab === "internships_stu" ? "gb-tab-active" : ""}">📋 Hire Intern</button>
            <button onclick="GBApp.setDirectoryTab('internships_adv')" class="py-2 rounded-lg ${state.directoryTab === "internships_adv" ? "gb-tab-active" : ""}">💼 Find Intern</button>
          </div>

          <!-- Promotional Internship Banner (PDF 2 Pages 1 & 2) -->
          <div onclick="GBApp.setDirectoryTab('${state.directoryTab === "students" ? "internships_adv" : "internships_stu"}')" class="gb-card gb-card-interactive overflow-hidden border-amber-400/50 cursor-pointer">
            <img src="${state.directoryTab === "students" ? (DATA.assets.bannerInternshipStu || DATA.assets.scHeroDay) : (DATA.assets.bannerInternshipAdv || DATA.assets.scHeroDay)}" alt="Internship Banner" class="w-full h-24 object-cover" />
            <div class="px-3 py-2 flex items-center justify-between gb-surface-alt text-xs">
              <span class="font-extrabold gb-text-gold">
                ${state.directoryTab === "students" ? "🎓 Find Internship Opportunities (Apply Now)" : "👨‍⚖️ Students Looking for Internship (View Profiles)"}
              </span>
              <span class="font-bold gb-text-accent">Explore ›</span>
            </div>
          </div>

          <!-- Location & Search Controls (PDF 2 Pages 3–4) -->
          <div class="gb-card p-3 space-y-2">
            <div class="flex gap-1.5 overflow-x-auto no-scrollbar text-[10px] font-bold">
              ${["All", "📍 Nearby (2-5 km)", "Prayagraj", "Lucknow", "Varanasi", "Kanpur", "Hardoi", "Delhi"].map((loc) => `
                <button onclick="GBApp.setDirectoryLocation('${loc}')" class="px-2.5 py-1 rounded-full whitespace-nowrap border ${state.directoryLocationFilter === loc ? "gb-tab-active" : "gb-surface"}">${loc}</button>
              `).join("")}
            </div>
            <div class="flex items-center gap-2 px-3 py-1.5 rounded-xl gb-surface">
              <span>🔍</span>
              <input type="text" value="${state.directorySearch}" oninput="GBApp.setDirectorySearch(this.value)" placeholder="Search by Name, City, Court, Practice Area or College..." class="bg-transparent flex-1 text-xs focus:outline-none" />
            </div>
          </div>

          ${
            state.directoryTab === "advocates"
              ? `
            <div class="space-y-2.5">
              ${DATA.advocatesDirectory
                .filter((a) => {
                  const matchLoc = state.directoryLocationFilter === "All" || state.directoryLocationFilter.includes("Nearby") || a.city.toLowerCase().includes(state.directoryLocationFilter.toLowerCase());
                  const matchQ = !q || a.name.toLowerCase().includes(q) || a.city.toLowerCase().includes(q) || a.role.toLowerCase().includes(q);
                  return matchLoc && matchQ;
                })
                .map((adv) => `
                  <div class="gb-card p-3.5 space-y-2.5">
                    <div class="flex items-start justify-between gap-2">
                      <div>
                        <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-bold">✔ ${adv.verificationStatus}</span>
                        <div class="text-sm font-black mt-1">${adv.name}</div>
                        <div class="text-xs gb-text-accent font-bold">${adv.role} • ${adv.exp}</div>
                        <div class="text-[11px] gb-text-sub mt-0.5">📍 ${adv.city} (${adv.distance || "2.5 km"}) • 🏛️ ${adv.court}</div>
                      </div>
                      <div class="text-right shrink-0">
                        <div class="text-xs font-black gb-text-gold">★ ${adv.rating}</div>
                        <div class="text-[10px] font-bold text-emerald-400 mt-0.5">${adv.fee}</div>
                      </div>
                    </div>
                    <div class="flex flex-wrap gap-1">
                      ${adv.practiceAreas.slice(0, 4).map((pa) => `<span class="px-2 py-0.5 rounded gb-surface text-[10px] font-semibold">${pa}</span>`).join("")}
                    </div>
                    <div class="grid grid-cols-3 gap-1.5 pt-2 border-t border-purple-500/20">
                      <button onclick="GBApp.openPublicProfileView('${adv.id}', 'about')" class="py-2 gb-btn-outline text-[11px]">👁️ Profile</button>
                      <button onclick="GBApp.openConversationWith('${adv.name}', '${adv.role}', 'Advocate')" class="py-2 gb-btn-primary text-[11px]">💬 Live Chat</button>
                      <button onclick="GBApp.openAppointmentFlow('${adv.id}', 'form')" class="py-2 gb-btn-gold text-[11px]">📅 Book</button>
                    </div>
                  </div>
                `).join("")}
            </div>
          `
              : state.directoryTab === "students" || state.directoryTab === "internships_stu"
              ? `
            <!-- Students Looking for Internship / Find My Student (PDF 2 Pages 4 & 5) -->
            <div class="space-y-2.5">
              ${DATA.studentsDirectory
                .filter((s) => !q || s.name.toLowerCase().includes(q) || s.college.toLowerCase().includes(q) || s.city.toLowerCase().includes(q))
                .map((stu) => `
                  <div class="gb-card p-3.5 space-y-2.5">
                    <div class="flex items-start justify-between">
                      <div>
                        <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-bold">Open for Internship</span>
                        <div class="text-sm font-black mt-1">${stu.name}</div>
                        <div class="text-xs gb-text-accent font-bold">${stu.course} (${stu.semester}) • ${stu.college}</div>
                        <div class="text-[11px] gb-text-sub mt-0.5">📍 ${stu.city} (${stu.distance}) • Mode: ${stu.mode}</div>
                      </div>
                      <span class="text-xs font-black gb-text-gold">★ ${stu.rating}</span>
                    </div>
                    <div class="flex flex-wrap gap-1">
                      ${stu.skills.map((sk) => `<span class="px-2 py-0.5 rounded gb-surface text-[10px] font-semibold">✔ ${sk}</span>`).join("")}
                    </div>
                    <div class="grid grid-cols-3 gap-1.5 pt-2 border-t border-purple-500/20">
                      <button onclick="GBApp.openPublicProfileView('${stu.id}', 'about')" class="py-2 gb-btn-outline text-[11px]">👁️ Profile</button>
                      <button onclick="GBApp.openInternshipConsultingDetail('${stu.id}')" class="py-2 gb-btn-gold text-[11px]">📋 Internship</button>
                      <button onclick="GBApp.openConversationWith('${stu.name}', '${stu.course}', 'Student')" class="py-2 gb-btn-primary text-[11px]">💬 Chat</button>
                    </div>
                  </div>
                `).join("")}
            </div>
          `
              : `
            <!-- Advocates Offering Internship (PDF 2 Page 6) -->
            <div class="space-y-2.5">
              ${DATA.advocatesOfferingInternship.map((item) => `
                <div class="gb-card p-3.5 space-y-2.5">
                  <div class="flex items-start justify-between">
                    <div>
                      <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 text-[9px] font-bold">${item.slotsStatus}</span>
                      <div class="text-sm font-black mt-1">${item.advName}</div>
                      <div class="text-xs gb-text-accent font-bold">${item.role} • ${item.exp}</div>
                      <div class="text-[11px] gb-text-sub mt-0.5">📍 ${item.location} • ⏳ ${item.duration}</div>
                      <div class="text-[10px] text-emerald-400 font-bold mt-0.5">💰 ${item.stipend}</div>
                    </div>
                    <span class="text-xs font-black gb-text-gold">★ ${item.rating}</span>
                  </div>
                  <div class="flex flex-wrap gap-1">
                    ${item.practiceAreas.map((pa) => `<span class="px-2 py-0.5 rounded gb-surface text-[10px] font-semibold">${pa}</span>`).join("")}
                  </div>
                  <div class="flex gap-2 pt-2 border-t border-purple-500/20">
                    <button onclick="GBApp.openApplyInternshipScreen('${item.id}')" class="flex-1 py-2 gb-btn-primary text-xs">
                      📝 View Details & Apply for Internship ›
                    </button>
                  </div>
                </div>
              `).join("")}
            </div>
          `
          }
        </div>
      </div>
    `;
  }

  // Consulting for Internship Detail Screen (PDF 2 Page 12)
  function renderInternshipConsultingDetailScreen() {
    const stu = DATA.studentsDirectory.find((s) => s.id === state.selectedInternshipStudentId) || DATA.studentsDirectory[0];
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center gap-2 border-b border-purple-500/20">
          <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
          <div>
            <div class="text-sm font-extrabold">Consulting for Internship</div>
            <div class="text-[10px] gb-text-sub">${stu.name} • ${stu.course}</div>
          </div>
        </div>

        <div class="p-3.5 space-y-3.5 text-xs">
          <div class="gb-card p-4 space-y-2 border-purple-400/50">
            <div class="flex justify-between items-center">
              <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">Open for Internship</span>
              <span class="font-black gb-text-gold">★ ${stu.rating}</span>
            </div>
            <h2 class="text-base font-black">${stu.name}</h2>
            <div class="gb-text-accent font-bold">${stu.course} (${stu.semester}) • ${stu.college}</div>
            <div class="gb-text-sub">📍 Preferred Locations: ${(stu.preferredLocations || []).join(" | ")}</div>
            <div class="gb-text-sub">⏳ Duration: ${stu.preferredDuration} • Mode: ${stu.mode}</div>
            <div class="text-emerald-400 font-semibold">💰 Stipend: ${stu.stipendPref}</div>
          </div>

          <div class="gb-card p-3.5 space-y-2">
            <div class="font-extrabold gb-text-gold">📎 Uploaded Documents (Demo)</div>
            <div class="p-2.5 rounded-xl gb-surface flex items-center justify-between">
              <span>📄 Resume / CV (PDF • 1.2 MB)</span>
              <a href="${DATA.assets.samplePdf}" download="Student_Resume.pdf" class="px-3 py-1 rounded gb-surface-alt font-bold text-[10px] gb-text-accent">Download</a>
            </div>
            <div class="p-2.5 rounded-xl gb-surface flex items-center justify-between">
              <span>🪪 College ID Card (PDF • 0.8 MB)</span>
              <button onclick="GBApp.showToast('🪪 Viewing College ID Card - Demo')" class="px-3 py-1 rounded gb-surface-alt font-bold text-[10px] gb-text-accent">View</button>
            </div>
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div class="font-extrabold gb-text-accent">✉️ Send Message for Internship</div>
            <textarea rows="3" placeholder="Hi ${stu.name}, we have an internship opening at our legal chamber..." class="gb-input">Hi ${stu.name}, we have an internship opening at our High Court chamber for Legal Research & Drafting.</textarea>
            <div class="flex gap-2">
              <button onclick="GBApp.openConversationWith('${stu.name}', '${stu.course}', 'Student')" class="flex-1 py-2.5 gb-btn-primary text-xs">
                💬 Send Message & Open Chat
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // Apply for Internship Detail Screen (PDF 2 Page 13)
  function renderApplyInternshipDetailScreen() {
    const item = DATA.advocatesOfferingInternship.find((a) => a.id === state.selectedInternshipAdvId) || DATA.advocatesOfferingInternship[0];
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center gap-2 border-b border-purple-500/20">
          <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
          <div>
            <div class="text-sm font-extrabold">Apply for Internship</div>
            <div class="text-[10px] gb-text-sub">${item.advName} • ${item.location}</div>
          </div>
        </div>

        <div class="p-3.5 space-y-3.5 text-xs">
          <div class="gb-card p-4 space-y-2 border-amber-400/50">
            <div class="flex justify-between items-center">
              <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 text-[10px] font-bold">${item.slotsStatus}</span>
              <span class="font-black gb-text-gold">★ ${item.rating}</span>
            </div>
            <h2 class="text-base font-black">${item.advName}</h2>
            <div class="gb-text-accent font-bold">${item.role} • ${item.exp}</div>
            <div>📍 <strong>Locations:</strong> ${item.preferredLocations.join(" | ")}</div>
            <div>⏳ <strong>Duration:</strong> ${item.duration} • <strong>Mode:</strong> ${item.mode}</div>
            <div class="text-emerald-400 font-bold">💰 Stipend: ${item.stipend}</div>
          </div>

          <div class="gb-card p-3.5 space-y-2">
            <div class="font-extrabold gb-text-accent">📚 What You Will Learn (Activities):</div>
            <div class="flex flex-wrap gap-1.5">
              ${item.activities.map((ac) => `<span class="px-2.5 py-1 rounded-lg gb-surface text-[10px] font-semibold">✔ ${ac}</span>`).join("")}
            </div>
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div class="font-extrabold gb-text-gold">📎 Upload Documents & Application Message</div>
            <div class="p-2.5 rounded-xl gb-surface flex items-center justify-between">
              <div>
                <div class="font-bold">📄 Resume / CV (PDF)</div>
                <div class="text-[10px] gb-text-muted">${state.studentProfile.resumeFileName}</div>
              </div>
              <label for="apply-res-inp" class="px-3 py-1 rounded bg-purple-600 text-white text-[10px] font-bold cursor-pointer">Upload</label>
              <input id="apply-res-inp" type="file" accept=".pdf,image/*" class="hidden" onchange="GBApp.handleFileSelection(this, 'stu_resume')" />
            </div>
            <textarea rows="3" class="gb-input">Respected Sir, I am a 3rd-year B.A. LL.B. student interested in applying for an internship at your chamber.</textarea>
            <button onclick="GBApp.submitInternshipApplicationDemo()" class="w-full py-3 gb-btn-primary text-xs">
              ✓ Send Application (Share Student Profile & CV)
            </button>
          </div>
        </div>
      </div>
    `;
  }
  // Appointment Booking 3-Step Flow: Form -> Review -> Confirmation & My Appointments (PDF 2 Pages 14–15)
  function renderAppointmentFlowScreen() {
    const adv = DATA.advocatesDirectory.find((a) => a.id === state.selectedConsultAdvId) || DATA.advocatesDirectory[0];
    const f = state.appointmentForm;

    if (state.appointmentStep === "review") {
      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center gap-2 border-b border-purple-500/20">
            <button onclick="GBApp.openAppointmentFlow('${adv.id}', 'form')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">Review Appointment</div>
              <div class="text-[10px] gb-text-sub">अपॉइंटमेंट कन्फर्म करने से पहले जानकारी जांच लें</div>
            </div>
          </div>
          <div class="p-3.5 space-y-3 text-xs">
            <div class="gb-card p-3.5 space-y-2 border-purple-400/50">
              <div class="font-extrabold gb-text-gold">Advocate: ${adv.name} (${adv.role})</div>
              <div>👤 <strong>आपका नाम:</strong> ${f.fullName}</div>
              <div>📞 <strong>मोबाइल नंबर:</strong> ${f.phone}</div>
              <div>✉️ <strong>ईमेल:</strong> ${f.email}</div>
              <div>⚖️ <strong>कानूनी विषय:</strong> ${f.subject} (${f.matterType})</div>
              <div>📝 <strong>आपकी समस्या:</strong> ${f.problemDesc}</div>
              <div>📎 <strong>दस्तावेज:</strong> ${f.photoFileName}, ${f.pdfFileName}</div>
              <div>📅 <strong>तारीख व समय:</strong> ${f.date} • ${f.slot}</div>
              <div>📹 <strong>माध्यम:</strong> ${f.mode}</div>
            </div>
            <div class="flex gap-2">
              <button onclick="GBApp.openAppointmentFlow('${adv.id}', 'form')" class="flex-1 py-3 gb-btn-outline text-xs">← Back & Edit</button>
              <button onclick="GBApp.confirmAndSendAppointment()" class="flex-1 py-3 gb-btn-primary text-xs">✓ Confirm & Send</button>
            </div>
          </div>
        </div>
      `;
    }

    if (state.appointmentStep === "confirmed" || state.appointmentStep === "my_appointments") {
      const filteredApts = state.appointmentsList.filter((a) => {
        if (state.myAppointmentsTab === "all") return true;
        return a.status.toLowerCase() === state.myAppointmentsTab;
      });
      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
            <div class="flex items-center gap-2">
              <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
              <div>
                <div class="text-sm font-extrabold">📅 My Appointment</div>
                <div class="text-[10px] gb-text-sub">Track your demo appointment requests</div>
              </div>
            </div>
            <button onclick="GBApp.openAppointmentFlow('${adv.id}', 'form')" class="px-2.5 py-1 rounded-full gb-btn-primary text-[10px]">+ New</button>
          </div>

          <div class="p-3.5 space-y-3 text-xs">
            ${
              state.appointmentStep === "confirmed"
                ? `
              <div class="gb-card p-4 text-center space-y-2 border-emerald-400/60">
                <div class="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-2xl mx-auto">✔</div>
                <h3 class="text-base font-black text-emerald-400">आपका Appointment Request भेज दिया गया है</h3>
                <p class="text-[11px] gb-text-sub">वकील द्वारा स्वीकार किए जाने पर आपको नोटिफिकेशन और मीटिंग लिंक मिलेगा (Demo Mode)।</p>
              </div>
            `
                : ""
            }

            <!-- Status Filter Tabs: All | Pending | Confirmed | Completed -->
            <div class="grid grid-cols-4 gap-1.5">
              ${["all", "pending", "confirmed", "completed"].map((tb) => `
                <button onclick="GBApp.setMyAppointmentsTab('${tb}')" class="py-1.5 rounded-lg text-[11px] font-bold capitalize border ${state.myAppointmentsTab === tb ? "gb-tab-active" : "gb-surface"}">${tb}</button>
              `).join("")}
            </div>

            <div class="space-y-2.5">
              ${filteredApts.map((apt) => `
                <div class="gb-card p-3.5 space-y-2">
                  <div class="flex justify-between items-start">
                    <div>
                      <div class="text-sm font-black">${apt.advName}</div>
                      <div class="text-[10px] gb-text-sub">${apt.advRole}</div>
                    </div>
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold ${
                      apt.status === "Confirmed" ? "bg-emerald-500/20 text-emerald-400" : apt.status === "Pending" ? "bg-amber-500/20 text-amber-400" : "gb-surface-alt gb-text-accent"
                    }">${apt.status}</span>
                  </div>
                  <div class="p-2.5 rounded-xl gb-surface space-y-1 text-[11px]">
                    <div>📅 <strong>Date & Time:</strong> ${apt.date} | ${apt.slot}</div>
                    <div>⚖️ <strong>Subject:</strong> ${apt.subject} (${apt.matter})</div>
                    <div>📹 <strong>Mode:</strong> ${apt.mode}</div>
                    ${apt.meetLink ? `<div class="text-emerald-400 font-bold">🔗 Meet Link: ${apt.meetLink}</div>` : ""}
                  </div>
                  <div class="flex gap-2">
                    <button onclick="GBApp.openConversationWith('${apt.advName}', 'Advocate', 'Advocate')" class="flex-1 py-1.5 gb-btn-primary text-[11px]">💬 Open Live Chat</button>
                    <button onclick="GBApp.cancelDemoAppointment('${apt.id}')" class="px-3 py-1.5 rounded-full bg-rose-600/20 text-rose-400 font-bold text-[10px]">Cancel</button>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>
        </div>
      `;
    }

    // Step 1: Appointment Details Form (PDF 2 Page 14)
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">📅 Appointment Details</div>
              <div class="text-[10px] gb-text-sub">${adv.name} • ${adv.city}</div>
            </div>
          </div>
          <button onclick="GBApp.openAppointmentFlow('${adv.id}', 'my_appointments')" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-bold gb-text-accent">My Appointments ›</button>
        </div>

        <div class="p-3.5 space-y-3.5 text-xs">
          <!-- 1. आपकी जानकारी -->
          <div class="gb-card p-3.5 space-y-2.5">
            <div class="font-extrabold gb-text-accent">1. आपकी जानकारी (Your Details)</div>
            <input id="apt-name" type="text" value="${f.fullName}" placeholder="पूरा नाम *" class="gb-input" />
            <div class="grid grid-cols-2 gap-2">
              <input id="apt-phone" type="tel" maxlength="10" value="${f.phone}" placeholder="मोबाइल नंबर *" class="gb-input" />
              <input id="apt-email" type="email" value="${f.email}" placeholder="ईमेल" class="gb-input" />
            </div>
          </div>

          <!-- 2 & 3. विषय और मामला -->
          <div class="gb-card p-3.5 space-y-2.5">
            <div class="font-extrabold gb-text-accent">2. किस विषय व मामले पर सलाह चाहिए?</div>
            <div class="grid grid-cols-2 gap-2">
              <select id="apt-subject" class="gb-input">
                <option value="सिविल कानून (Civil Law)">सिविल कानून (Civil Law)</option>
                <option value="क्रिमिनल कानून (BNS/BNSS)">क्रिमिनल कानून (BNS/BNSS)</option>
                <option value="फैमिली कानून (Family Law)">फैमिली कानून (Family Law)</option>
                <option value="जमीन / संपत्ति विवाद">जमीन / संपत्ति विवाद</option>
              </select>
              <select id="apt-matter" class="gb-input">
                <option value="संपत्ति विवाद">संपत्ति विवाद</option>
                <option value="जमानत (Bail / Anticipatory Bail)">जमानत (Bail)</option>
                <option value="FIR / पुलिस शिकायत">FIR / पुलिस शिकायत</option>
                <option value="दस्तावेज / नोटिस">दस्तावेज / नोटिस</option>
              </select>
            </div>
            <textarea id="apt-problem" rows="2" placeholder="4. अपनी समस्या संक्षेप में लिखें..." class="gb-input">${f.problemDesc}</textarea>
          </div>

          <!-- 5. दस्तावेज अपलोड (Photo & PDF) -->
          <div class="gb-card p-3.5 space-y-2">
            <div class="font-extrabold gb-text-gold">5. संबंधित दस्तावेज अपलोड करें (Optional)</div>
            <div class="grid grid-cols-2 gap-2">
              <label for="apt-ph-inp" class="p-2.5 rounded-xl gb-surface text-center cursor-pointer font-bold">
                📷 फोटो जोड़ें<div class="text-[9px] gb-text-muted truncate mt-0.5">${f.photoFileName}</div>
              </label>
              <input id="apt-ph-inp" type="file" accept="image/*" class="hidden" onchange="GBApp.handleFileSelection(this, 'apt_photo')" />
              <label for="apt-pdf-inp" class="p-2.5 rounded-xl gb-surface text-center cursor-pointer font-bold">
                📄 PDF जोड़ें<div class="text-[9px] gb-text-muted truncate mt-0.5">${f.pdfFileName}</div>
              </label>
              <input id="apt-pdf-inp" type="file" accept=".pdf" class="hidden" onchange="GBApp.handleFileSelection(this, 'apt_pdf')" />
            </div>
          </div>

          <!-- 7, 8 & 9. तारीख, समय और माध्यम -->
          <div class="gb-card p-3.5 space-y-2.5">
            <div class="font-extrabold gb-text-accent">7 & 8. उपलब्ध समय स्लॉट चुनें (${f.date}):</div>
            <div class="grid grid-cols-2 gap-1.5">
              ${["10:00 AM - 10:30 AM", "11:00 AM - 11:30 AM", "02:00 PM - 02:30 PM", "04:00 PM - 04:30 PM"].map((sl) => `
                <button onclick="GBApp.setAppointmentSlot('${sl}')" class="p-2 rounded-xl text-[11px] font-bold border ${f.slot === sl ? "gb-tab-active" : "gb-surface"}">${sl}</button>
              `).join("")}
            </div>
            <div class="font-extrabold gb-text-accent pt-1">9. बातचीत / मुलाकात का माध्यम चुनें:</div>
            <div class="grid grid-cols-2 gap-1.5">
              ${["Phone Call", "WhatsApp Video Call", "Google Meeting", "Chamber / Office Visit"].map((md) => `
                <button onclick="GBApp.setAppointmentMode('${md}')" class="p-2 rounded-xl text-[11px] font-bold border ${f.mode === md ? "gb-tab-active" : "gb-surface"}">${md}</button>
              `).join("")}
            </div>
          </div>

          <button onclick="GBApp.proceedToAppointmentReview()" class="w-full py-3 gb-btn-primary text-xs">
            Review Appointment Details →
          </button>
        </div>
      </div>
    `;
  }

  // Documents Banwane Ki Service + Advocate Panel My Documents (PDF 2 Pages 16–17)
  function renderDocumentServiceFlowScreen() {
    const f = state.docRequestForm;

    if (state.docServiceStep === "review") {
      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center gap-2 border-b border-purple-500/20">
            <button onclick="GBApp.openDocumentServiceFlow('form')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div class="text-sm font-extrabold">Review Your Details (दस्तावेज समीक्षा)</div>
          </div>
          <div class="p-3.5 space-y-3 text-xs">
            <div class="gb-card p-4 space-y-2 border-purple-400/50">
              <div>👤 <strong>आवेदक का नाम:</strong> ${f.applicantName}</div>
              <div>📞 <strong>मोबाइल नंबर:</strong> ${f.applicantPhone}</div>
              <div>📄 <strong>दस्तावेज का प्रकार:</strong> ${f.docCategory}</div>
              <div>📋 <strong>दस्तावेज का नाम:</strong> ${f.docName}</div>
              <div>🎯 <strong>उद्देश्य:</strong> ${f.purpose}</div>
              <div>📝 <strong>विवरण:</strong> ${f.details}</div>
              <div>📎 <strong>संलग्नक:</strong> ${f.photoFileName}, ${f.pdfFileName}</div>
              <div>💬 <strong>संपर्क माध्यम:</strong> ${f.contactMode}</div>
            </div>
            <div class="flex gap-2">
              <button onclick="GBApp.openDocumentServiceFlow('form')" class="flex-1 py-3 gb-btn-outline text-xs">← Edit Details</button>
              <button onclick="GBApp.confirmAndSendDocRequest()" class="flex-1 py-3 gb-btn-primary text-xs">✓ Confirm & Send</button>
            </div>
          </div>
        </div>
      `;
    }

    if (state.docServiceStep === "doc_detail") {
      const doc = state.advocatePanelDocs.find((d) => d.id === state.selectedDocRequestId) || state.advocatePanelDocs[0];
      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center gap-2 border-b border-purple-500/20">
            <button onclick="GBApp.openDocumentServiceFlow('advocate_panel')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div class="text-sm font-extrabold">Document Details (Advocate Panel)</div>
          </div>
          <div class="p-3.5 space-y-3 text-xs">
            <div class="gb-card p-4 space-y-2 border-amber-400/50">
              <div class="flex justify-between">
                <span class="font-black text-sm">${doc.clientName}</span>
                <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold text-[10px]">${doc.status}</span>
              </div>
              <div>📞 ${doc.clientPhone} • ✉️ ${doc.clientEmail}</div>
              <div class="font-extrabold gb-text-gold pt-1">📄 ${doc.docType}</div>
              <div><strong>उद्देश्य:</strong> ${doc.purpose}</div>
              <div class="p-2.5 rounded-xl gb-surface">${doc.summary}</div>
              <div class="text-[11px] gb-text-muted">${doc.extraNotes}</div>
              <div class="flex gap-2 pt-2">
                <button onclick="GBApp.updateAdvocateDocStatus('${doc.id}', 'Rejected')" class="flex-1 py-2.5 rounded-full bg-rose-600 text-white font-bold">✕ Reject</button>
                <button onclick="GBApp.updateAdvocateDocStatus('${doc.id}', 'Confirmed')" class="flex-1 py-2.5 rounded-full bg-emerald-600 text-white font-bold">✓ Accept</button>
                <button onclick="GBApp.updateAdvocateDocStatus('${doc.id}', 'Completed')" class="flex-1 py-2.5 gb-btn-gold">★ Complete</button>
              </div>
            </div>
          </div>
        </div>
      `;
    }

    if (state.docServiceStep === "advocate_panel") {
      const list = state.advocatePanelDocs.filter((d) => {
        if (state.myDocsFilterTab === "all") return true;
        return d.status.toLowerCase() === state.myDocsFilterTab;
      });
      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
            <div class="flex items-center gap-2">
              <button onclick="GBApp.openDocumentServiceFlow('form')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
              <div>
                <div class="text-sm font-extrabold">Advocate Panel — My Documents</div>
                <div class="text-[10px] gb-text-sub">Client Document Drafting Requests (Demo)</div>
              </div>
            </div>
            <button onclick="GBApp.openDocumentServiceFlow('form')" class="px-2.5 py-1 rounded-full gb-btn-primary text-[10px]">+ New Request</button>
          </div>

          <div class="p-3.5 space-y-3 text-xs">
            <div class="grid grid-cols-4 gap-1.5">
              ${["all", "pending", "confirmed", "completed"].map((tb) => `
                <button onclick="GBApp.setMyDocsFilterTab('${tb}')" class="py-1.5 rounded-lg text-[11px] font-bold capitalize border ${state.myDocsFilterTab === tb ? "gb-tab-active" : "gb-surface"}">${tb}</button>
              `).join("")}
            </div>

            <div class="space-y-2.5">
              ${list.map((d) => `
                <div class="gb-card p-3.5 space-y-2">
                  <div class="flex justify-between items-start">
                    <div>
                      <div class="text-sm font-black">${d.clientName}</div>
                      <div class="text-xs gb-text-gold font-bold">${d.docType}</div>
                      <div class="text-[10px] gb-text-muted">${d.date}</div>
                    </div>
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold ${
                      d.status === "Confirmed" ? "bg-emerald-500/20 text-emerald-400" : d.status === "Pending" ? "bg-amber-500/20 text-amber-400" : "gb-surface-alt"
                    }">${d.status}</span>
                  </div>
                  <p class="text-[11px] gb-text-sub">${d.purpose}</p>
                  <div class="flex gap-2 pt-1">
                    <button onclick="GBApp.openAdvocateDocDetail('${d.id}')" class="flex-1 py-1.5 gb-btn-outline text-[11px]">👁️ Details</button>
                    <button onclick="GBApp.updateAdvocateDocStatus('${d.id}', 'Confirmed')" class="flex-1 py-1.5 rounded-full bg-emerald-600 text-white font-bold text-[11px]">✓ Accept</button>
                    <button onclick="GBApp.updateAdvocateDocStatus('${d.id}', 'Rejected')" class="px-3 py-1.5 rounded-full bg-rose-600/20 text-rose-400 font-bold text-[11px]">Reject</button>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>
        </div>
      `;
    }

    // Step 1: Documents Banwane Ki Service Form (PDF 2 Page 16)
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">📄 Documents Banwane Ki Service</div>
              <div class="text-[10px] gb-text-sub">Affidavit, Notice, Rent Agreement & Application</div>
            </div>
          </div>
          <button onclick="GBApp.openDocumentServiceFlow('advocate_panel')" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-bold gb-text-gold">Advocate Panel ›</button>
        </div>

        <div class="p-3.5 space-y-3.5 text-xs">
          <div class="gb-card p-3.5 space-y-2.5">
            <div class="font-extrabold gb-text-accent">आपकी जानकारी (Applicant Info):</div>
            <input id="doc-name" type="text" value="${f.applicantName}" placeholder="पूरा नाम *" class="gb-input" />
            <div class="grid grid-cols-2 gap-2">
              <input id="doc-phone" type="tel" value="${f.applicantPhone}" placeholder="मोबाइल नंबर *" class="gb-input" />
              <input id="doc-email" type="email" value="${f.applicantEmail}" placeholder="ईमेल" class="gb-input" />
            </div>
          </div>

          <div class="gb-card p-3.5 space-y-2.5">
            <div class="font-extrabold gb-text-accent">1 & 2. दस्तावेज का प्रकार और नाम चुनें:</div>
            <div class="grid grid-cols-2 gap-2">
              <select id="doc-cat" class="gb-input">
                <option value="शपथ पत्र (Affidavit)">शपथ पत्र (Affidavit)</option>
                <option value="लीगल नोटिस (Legal Notice)">लीगल नोटिस (Legal Notice)</option>
                <option value="किरायानामा (Rent Agreement)">किरायानामा (Rent Agreement)</option>
                <option value="आवेदन / प्रार्थना पत्र">आवेदन / प्रार्थना पत्र</option>
              </select>
              <select id="doc-subname" class="gb-input">
                <option value="आय / निवास / भूमि शपथ पत्र">आय / निवास / भूमि शपथ पत्र</option>
                <option value="चेक बाउंस / वसूली नोटिस">चेक बाउंस / वसूली नोटिस</option>
                <option value="11 माह रेंट एग्रीमेंट">11 माह रेंट एग्रीमेंट</option>
                <option value="कोर्ट / थाना प्रार्थना पत्र">कोर्ट / थाना प्रार्थना पत्र</option>
              </select>
            </div>
            <input id="doc-purpose" type="text" value="${f.purpose}" placeholder="3. दस्तावेज किस काम के लिए चाहिए?" class="gb-input" />
            <textarea id="doc-details" rows="3" placeholder="4. अपनी आवश्यकता संक्षेप में बताएं..." class="gb-input">${f.details}</textarea>
          </div>

          <div class="gb-card p-3.5 space-y-2">
            <div class="font-extrabold gb-text-gold">संबंधित दस्तावेज अपलोड करें (Photo / PDF):</div>
            <div class="grid grid-cols-2 gap-2">
              <label for="doc-ph-inp" class="p-2.5 rounded-xl gb-surface text-center cursor-pointer font-bold">
                📷 फोटो जोड़ें<div class="text-[9px] gb-text-muted truncate mt-0.5">${f.photoFileName}</div>
              </label>
              <input id="doc-ph-inp" type="file" accept="image/*" class="hidden" onchange="GBApp.handleFileSelection(this, 'doc_photo')" />
              <label for="doc-pdf-inp" class="p-2.5 rounded-xl gb-surface text-center cursor-pointer font-bold">
                📄 PDF जोड़ें<div class="text-[9px] gb-text-muted truncate mt-0.5">${f.pdfFileName}</div>
              </label>
              <input id="doc-pdf-inp" type="file" accept=".pdf" class="hidden" onchange="GBApp.handleFileSelection(this, 'doc_pdf')" />
            </div>
          </div>

          <button onclick="GBApp.proceedToDocReview()" class="w-full py-3 gb-btn-primary text-xs">
            Review Document Request →
          </button>
        </div>
      </div>
    `;
  }
  // Requirement #11: Consulting = LIVE CHAT (User-to-User / Advocate / Student Live Chat — PDF 3 Page 26)
  function renderConsultingScreen() {
    if (state.consultingView === "list") {
      const q = state.consultingSearch.trim().toLowerCase();
      const filtered = state.conversations.filter((c) => {
        if (state.consultingFilter !== "All" && c.participantCategory !== state.consultingFilter) return false;
        if (!q) return true;
        return c.participantName.toLowerCase().includes(q) || c.participantRole.toLowerCase().includes(q);
      });

      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
            <div class="flex items-center gap-2">
              <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
              <div>
                <div class="text-sm font-extrabold">💬 Consulting — Live Chat</div>
                <div class="text-[10px] gb-text-sub">Chat with Advocates, Law Students & Users (Demo)</div>
              </div>
            </div>
            <button onclick="GBApp.navigateTo('find_advocate')" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-extrabold gb-text-accent">
              + New Chat
            </button>
          </div>

          <div class="p-3 space-y-3">
            <!-- Privacy & Demo Mode Notice -->
            <div class="p-2.5 rounded-xl gb-surface-alt text-[11px] gb-text-sub">
              🔒 <strong class="gb-text-accent">Live Chat Demo Mode:</strong> किसी भी Advocate, Law Student या User पर टैप करके लाइव चैट शुरू करें, PDF/फोटो भेजें या मैसेज सलेक्ट करके डिलीट करें। (Appointment और Document Services अलग से उपलब्ध हैं)।
            </div>

            <!-- Search People or Conversations -->
            <div class="flex items-center gap-2 px-3 py-2 rounded-xl gb-card">
              <span>🔍</span>
              <input type="text" value="${state.consultingSearch}" oninput="GBApp.setConsultingSearch(this.value)" placeholder="Search people or conversations (Gulab Badshah, Rahul, Neha)..." class="bg-transparent flex-1 text-xs focus:outline-none" />
            </div>

            <!-- Filter Pills -->
            <div class="grid grid-cols-4 gap-1.5 text-[11px] font-bold">
              ${["All", "Advocate", "Student", "User"].map((flt) => `
                <button onclick="GBApp.setConsultingFilter('${flt}')" class="py-1.5 rounded-lg border ${state.consultingFilter === flt ? "gb-tab-active" : "gb-surface"}">${flt === "All" ? "All Chats" : flt + "s"}</button>
              `).join("")}
            </div>

            <!-- Conversation List -->
            <div class="space-y-2">
              ${
                filtered.length === 0
                  ? `<div class="gb-card p-6 text-center text-xs gb-text-muted">कोई बातचीत नहीं मिली।</div>`
                  : filtered
                      .map((c) => {
                        const lastMsg = c.messages[c.messages.length - 1];
                        return `
                          <div onclick="GBApp.openConversationWith('${c.id}')" class="gb-card gb-card-interactive p-3.5 flex items-center justify-between gap-3 cursor-pointer">
                            <div class="flex items-center gap-3 min-w-0 flex-1">
                              <div class="w-12 h-12 rounded-full gb-surface-alt border border-purple-400 flex items-center justify-center text-2xl relative shrink-0">
                                <span>${c.avatar}</span>
                                <span class="w-3 h-3 rounded-full ${c.online ? "bg-emerald-400" : "bg-gray-400"} absolute bottom-0 right-0 border-2 border-black"></span>
                              </div>
                              <div class="min-w-0 flex-1">
                                <div class="flex items-center justify-between">
                                  <span class="text-sm font-black truncate">${c.participantName}</span>
                                  <span class="text-[10px] gb-text-muted shrink-0">${lastMsg ? lastMsg.time : ""}</span>
                                </div>
                                <div class="text-[10px] font-bold gb-text-accent truncate">${c.participantRole}</div>
                                <div class="text-xs gb-text-sub truncate mt-0.5">
                                  ${lastMsg ? (lastMsg.isFile ? `📎 ${lastMsg.text}` : lastMsg.text) : "Tap to start chatting..."}
                                </div>
                              </div>
                            </div>
                            ${
                              c.unreadCount > 0
                                ? `<span class="w-5 h-5 rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">${c.unreadCount}</span>`
                                : `<span class="text-xs gb-text-accent font-bold">›</span>`
                            }
                          </div>
                        `;
                      })
                      .join("")
              }
            </div>

            <!-- Separate Links to Appointment & Document Services (Not mixed with Live Chat!) -->
            <div class="pt-2 border-t border-purple-500/20">
              <div class="text-[10px] font-bold gb-text-muted mb-1.5">Separate Legal Services (अलग सेवाएं):</div>
              <div class="grid grid-cols-2 gap-2">
                <button onclick="GBApp.openAppointmentFlow('adv_rahul', 'form')" class="gb-card p-2.5 text-left text-xs font-bold flex items-center gap-2">
                  <span>📅</span><span>Appointment Booking</span>
                </button>
                <button onclick="GBApp.openDocumentServiceFlow('form')" class="gb-card p-2.5 text-left text-xs font-bold flex items-center gap-2">
                  <span>📄</span><span>Document Service</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
    }

    // Active Live Chat Conversation Screen (PDF 3 Page 26)
    const conv = state.conversations.find((c) => c.id === state.activeConversationId) || state.conversations[0];
    const selCount = state.selectedChatMsgIds.length;

    return `
      <div class="flex-1 flex flex-col pb-24">
        <!-- Chat Header -->
        <div class="px-3 py-2 flex items-center justify-between border-b border-purple-500/25 gb-header">
          <div class="flex items-center gap-2 min-w-0">
            <button onclick="GBApp.backToChatList()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold shrink-0">←</button>
            <div class="w-9 h-9 rounded-full gb-surface-alt border border-amber-400 flex items-center justify-center text-lg relative shrink-0">
              <span>${conv.avatar}</span>
              <span class="w-2.5 h-2.5 rounded-full ${conv.online ? "bg-emerald-400" : "bg-gray-400"} absolute bottom-0 right-0 border border-black"></span>
            </div>
            <div class="min-w-0">
              <div class="text-xs font-black truncate">${conv.participantName}</div>
              <div class="text-[10px] text-emerald-400 font-bold">${conv.online ? "● Online" : "● Offline"}</div>
            </div>
          </div>
          <div class="flex items-center gap-1.5 shrink-0">
            <button onclick="GBApp.clearEntireConversation()" class="px-2 py-1 rounded-lg gb-surface text-[10px] font-bold" title="Clear Chat">🧹 Clear</button>
          </div>
        </div>

        <!-- Multi-Select Message Deletion Bar (PDF 3 Page 26: '2 selected | Delete | Copy | Clear chat') -->
        ${
          selCount > 0
            ? `
          <div class="px-3 py-2 bg-purple-900/90 text-white flex items-center justify-between text-xs font-bold border-b border-purple-400">
            <div class="flex items-center gap-2">
              <button onclick="GBApp.clearChatSelection()" class="text-sm">✕</button>
              <span>${selCount} selected</span>
            </div>
            <div class="flex items-center gap-2">
              <button onclick="GBApp.deleteSelectedChatMessages()" class="px-2.5 py-1 rounded bg-rose-600 text-white text-[11px]">🗑️ Delete</button>
              <button onclick="GBApp.copySelectedChatMessages()" class="px-2.5 py-1 rounded bg-black/40 text-white text-[11px]">📋 Copy</button>
              <button onclick="GBApp.clearEntireConversation()" class="px-2.5 py-1 rounded bg-black/40 text-white text-[11px]">🧹 Clear chat</button>
            </div>
          </div>
        `
            : ""
        }

        <div class="p-3 space-y-3 flex-1 overflow-y-auto">
          <!-- Your Privacy, Our Responsibility Banner (PDF 3 Page 26) -->
          <div class="gb-card p-3 space-y-1 border-amber-400/40 text-[11px]">
            <div class="font-extrabold gb-text-gold flex items-center gap-1.5">
              <span>🛡️</span><span>Your Privacy, Our Responsibility</span>
            </div>
            <div class="gb-text-sub">🔒 Aapki chat, documents aur personal jankari poori tarah surakshit aur confidential rahegi.</div>
            <div class="gb-text-sub">💬 Aap bina kisi jhijhak ke legal guidance, consultation aur apni baat share kar sakte hain.</div>
          </div>

          <!-- Busy / Response Time Notice Card (PDF 3 Page 26) -->
          <div class="gb-card p-3 space-y-1 border-purple-400/40 text-[11px]">
            <div class="gb-text-sub">⚖️ ${conv.busyNotice}</div>
            <div class="gb-text-gold font-bold">🕒 ${conv.replyTimeText}</div>
          </div>

          <!-- Messages List -->
          <div class="space-y-2.5">
            ${
              conv.messages.length === 0
                ? `<div class="p-6 text-center text-xs gb-text-muted">No messages yet. Type a message below to start the conversation!</div>`
                : conv.messages
                    .map((m) => {
                      const isMe = m.sender === "me";
                      const isSel = state.selectedChatMsgIds.includes(m.id);
                      return `
                        <div onclick="GBApp.toggleSelectChatMessage('${m.id}')" class="flex items-center gap-2 ${isMe ? "justify-end" : "justify-start"} cursor-pointer">
                          <span class="w-4 h-4 rounded flex items-center justify-center text-[10px] border ${
                            isSel ? "bg-purple-600 text-white border-purple-400" : "border-purple-400/40 opacity-60"
                          }">${isSel ? "✓" : ""}</span>
                          <div class="max-w-[80%] p-3 text-xs shadow-md ${isMe ? "chat-bubble-out" : "chat-bubble-in"} ${isSel ? "ring-2 ring-amber-400" : ""}">
                            ${
                              m.isFile
                                ? `
                              <div class="flex items-center gap-2.5 p-2 rounded-xl bg-black/25">
                                <span class="px-2 py-1 rounded bg-rose-600 text-white font-black text-[10px]">${m.fileType || "PDF"}</span>
                                <div>
                                  <div class="font-extrabold">${m.text}</div>
                                  <div class="text-[10px] opacity-80">${m.fileSize || "2.4 MB"} • ${m.fileType || "PDF"}</div>
                                </div>
                              </div>
                            `
                                : `<div class="leading-relaxed">${m.text}</div>`
                            }
                            <div class="text-[9px] opacity-75 mt-1 text-right flex items-center justify-end gap-1">
                              <span>${m.time}</span>
                              ${isMe ? `<span class="text-sky-300 font-bold">✓✓</span>` : ""}
                            </div>
                          </div>
                        </div>
                      `;
                    })
                    .join("")
            }
          </div>
        </div>

        <!-- Quick Action Bottom Sheet (Consult & Advice | Get Guidance | Share from App — PDF 3 Page 26) -->
        ${
          state.chatQuickSheetOpen
            ? `
          <div class="px-3 pt-2 pb-1 border-t border-purple-500/20 gb-header">
            <div class="grid grid-cols-3 gap-1.5 text-center text-[10px]">
              <button onclick="GBApp.sendLiveChatMessage('Sir, I need Legal Consultation & Advice regarding my case.')" class="p-2 rounded-xl gb-surface hover:border-purple-400">
                <div class="text-base">⚖️</div>
                <div class="font-extrabold mt-0.5">Consult & Advice</div>
                <div class="text-[8px] gb-text-muted">Legal Help</div>
              </button>
              <button onclick="GBApp.sendLiveChatMessage('Hello, I need Career & Exam Guidance for Law / Judiciary.')" class="p-2 rounded-xl gb-surface hover:border-purple-400">
                <div class="text-base">🎓</div>
                <div class="font-extrabold mt-0.5">Get Guidance</div>
                <div class="text-[8px] gb-text-muted">Study & Career</div>
              </button>
              <button onclick="GBApp.sendLiveChatMessage('Sharing BNS Section 103 & BNSS Section 173 Notes from GB Legal Mind App.')" class="p-2 rounded-xl gb-surface hover:border-purple-400">
                <div class="text-base">📤</div>
                <div class="font-extrabold mt-0.5">Share from App</div>
                <div class="text-[8px] gb-text-muted">Sections & Notes</div>
              </button>
            </div>
          </div>
        `
            : ""
        }

        <!-- Message Input Bar -->
        <div class="p-2.5 border-t border-purple-500/25 gb-header flex items-center gap-1.5">
          <button onclick="GBApp.toggleChatQuickSheet()" class="w-8 h-8 rounded-full gb-surface-alt font-black text-sm shrink-0" title="Quick Actions">+</button>
          <input id="live-chat-input" type="text" placeholder="Type a message..." class="gb-input py-2 text-xs flex-1" onkeydown="if(event.key==='Enter') GBApp.sendLiveChatMessage()" />
          <label for="chat-attach-inp" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center text-xs cursor-pointer shrink-0" title="Attach PDF/Image">📎</label>
          <input id="chat-attach-inp" type="file" accept=".pdf,image/*" class="hidden" onchange="GBApp.handleFileSelection(this, 'chat_file')" />
          <button onclick="GBApp.sendLiveChatMessage()" class="px-3.5 py-2 gb-btn-primary text-xs shrink-0">➤</button>
        </div>
      </div>
    `;
  }

  // Support Chat Screen (Auto Bot & Human Support Escalation — PDF 3 Page 27)
  function renderChatSupportScreen() {
    const categories = [
      { id: "Payment Issue", icon: "💳", sub: "पेमेंट कट गया लेकिन अपडेट नहीं हुआ" },
      { id: "Premium Access", icon: "👑", sub: "प्रीमियम प्लान एक्टिव नहीं हुआ" },
      { id: "Login Problem", icon: "🔑", sub: "लॉगिन या OTP में समस्या" },
      { id: "Mock Test Issue", icon: "📝", sub: "टेस्ट खुल नहीं रहा या एरर आ रहा है" },
      { id: "Other Problem", icon: "💬", sub: "अन्य किसी समस्या के लिए" }
    ];

    return `
      <div class="flex-1 flex flex-col pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">🎧 Support Chat</div>
              <div class="text-[10px] text-emerald-400">● Auto Support Bot & Human Escalation</div>
            </div>
          </div>
          <button onclick="GBApp.setSupportStep('category')" class="px-2.5 py-1 rounded-full gb-surface text-[10px] font-bold">New Chat</button>
        </div>

        <div class="p-3.5 flex-1 space-y-3 overflow-y-auto text-xs">
          ${
            state.supportStep === "category"
              ? `
            <div class="gb-card p-3.5 space-y-2.5">
              <div class="font-extrabold gb-text-accent">👋 अपनी समस्या चुनें (Select Issue Category):</div>
              <div class="space-y-2">
                ${categories.map((c) => `
                  <button onclick="GBApp.selectSupportIssue('${c.id}')" class="w-full p-3 rounded-xl gb-surface hover:border-purple-400 flex items-center justify-between text-left">
                    <div class="flex items-center gap-2.5">
                      <span class="text-lg">${c.icon}</span>
                      <div>
                        <div class="font-extrabold">${c.id}</div>
                        <div class="text-[10px] gb-text-muted">${c.sub}</div>
                      </div>
                    </div>
                    <span>›</span>
                  </button>
                `).join("")}
              </div>
            </div>
          `
              : `
            <div class="space-y-2.5">
              ${state.supportMessages.map((m) => `
                <div class="flex ${m.sender === "me" ? "justify-end" : "justify-start"}">
                  <div class="max-w-[85%] p-3 rounded-2xl ${m.sender === "me" ? "chat-bubble-out" : "gb-card"}">
                    <div class="text-[10px] font-bold gb-text-gold mb-0.5">${m.sender === "me" ? "You" : m.sender === "agent" ? "👨‍💼 Support Agent" : "🤖 Auto Support Bot"}</div>
                    <div>${m.text}</div>
                    <div class="text-[9px] opacity-70 mt-1 text-right">${m.time}</div>
                  </div>
                </div>
              `).join("")}
            </div>

            <!-- Screenshot Upload & Escalation Controls (PDF 3 Page 27) -->
            <div class="gb-card p-3.5 space-y-2.5 border-purple-400/40">
              <div class="flex items-center justify-between">
                <span class="font-bold">📷 Upload Payment/Issue Screenshot:</span>
                <label for="sup-img-inp" class="px-3 py-1.5 rounded-lg gb-btn-primary text-[10px] cursor-pointer">Upload Image</label>
                <input id="sup-img-inp" type="file" accept="image/*" class="hidden" onchange="GBApp.handleFileSelection(this, 'support_img')" />
              </div>

              ${
                state.supportStep === "bot_chat"
                  ? `
                <div class="flex gap-2 pt-1">
                  <button onclick="GBApp.setSupportStep('ended')" class="flex-1 py-2 gb-btn-outline text-[11px]">✓ Problem Solved</button>
                  <button onclick="GBApp.setSupportStep('human_requested')" class="flex-1 py-2 gb-btn-gold text-[11px]">👨‍💼 Talk to Support</button>
                </div>
              `
                  : state.supportStep === "human_requested"
                  ? `
                <div class="p-3 rounded-xl gb-surface space-y-1.5 text-center">
                  <div class="font-extrabold gb-text-gold">⏳ Human Support Requested</div>
                  <p class="text-[11px] gb-text-sub">Aapki request support team ko bhej di gayi hai. Expected Wait Time: 1–4 Ghante (Demo).</p>
                  <button onclick="GBApp.setSupportStep('human_joined')" class="w-full py-2 gb-btn-primary text-[11px] mt-1">Simulate Support Agent Joining Now ›</button>
                </div>
              `
                  : state.supportStep === "ended"
                  ? `
                <div class="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-center space-y-2">
                  <div class="font-extrabold text-emerald-400">✔ Issue Resolved / Chat Ended</div>
                  <button onclick="GBApp.setSupportStep('category')" class="w-full py-2 gb-btn-primary text-[11px]">Start New Chat</button>
                </div>
              `
                  : ""
              }
            </div>
          `
          }
        </div>

        <div class="p-2.5 border-t border-purple-500/20 gb-header flex gap-2">
          <input id="support-chat-input" type="text" placeholder="Apni problem likhiye..." class="gb-input py-2 text-xs flex-1" onkeydown="if(event.key==='Enter') GBApp.sendSupportBotMsg()" />
          <button onclick="GBApp.sendSupportBotMsg()" class="px-4 py-2 gb-btn-primary text-xs">Send</button>
        </div>
      </div>
    `;
  }
  // Requirement #12: Advocate Diary, Student Notes & Reels
  function renderAdvocateDiaryScreen() {
    const q = (state.diarySearch || "").trim().toLowerCase();
    const tab = state.diaryFilterTab || "All";
    const allCases = state.diaryCases || [];

    const totalCases = allCases.length;
    const todayCount = allCases.filter((c) => c.status === "Today" || c.nextDate === "2026-10-24").length;
    const disposedCount = allCases.filter((c) => c.status === "Disposed").length;
    const totalPendingFee = allCases.reduce((sum, c) => sum + Math.max(0, (Number(c.totalFee) || 0) - (Number(c.receivedFee) || 0)), 0);

    const filtered = allCases.filter((c) => {
      if (tab === "Today" && c.status !== "Today" && c.nextDate !== "2026-10-24") return false;
      if (tab === "Upcoming" && c.status === "Disposed") return false;
      if (tab === "Disposed" && c.status !== "Disposed") return false;
      if (tab === "Fee Pending" && ((Number(c.totalFee) || 0) - (Number(c.receivedFee) || 0) <= 0)) return false;
      if (!q) return true;
      return (
        c.title.toLowerCase().includes(q) ||
        c.caseNo.toLowerCase().includes(q) ||
        c.court.toLowerCase().includes(q) ||
        c.section.toLowerCase().includes(q) ||
        (c.client || "").toLowerCase().includes(q)
      );
    });

    const editingCase =
      state.diaryEditingId && state.diaryEditingId !== "NEW"
        ? allCases.find((c) => c.id === state.diaryEditingId)
        : null;

    return `
      <div class="flex-1 pb-24">
        <!-- Header -->
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/25 gb-header sticky top-9 z-30">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-black text-amber-400">📓 Advocate Case Diary (वकील केस डायरी)</div>
              <div class="text-[10px] gb-text-sub">Court Dates, Client Fee Tracker & Hearing History</div>
            </div>
          </div>
          <button onclick="GBApp.openDiaryEditor('NEW')" class="px-3 py-1.5 gb-btn-gold text-xs font-black shadow">
            + नया केस जोड़ें
          </button>
        </div>

        <div class="p-3.5 space-y-3.5">
          <!-- Dashboard Summary Counters -->
          <div class="grid grid-cols-4 gap-2 text-center">
            <div class="gb-card p-2.5 border-purple-400/40">
              <div class="text-base font-black gb-text-accent">${totalCases}</div>
              <div class="text-[9px] gb-text-muted font-bold">कुल केस (Total)</div>
            </div>
            <div class="gb-card p-2.5 border-amber-400/40">
              <div class="text-base font-black text-amber-400">${todayCount}</div>
              <div class="text-[9px] gb-text-muted font-bold">आज/निकट सुनवाई</div>
            </div>
            <div class="gb-card p-2.5 border-emerald-400/40">
              <div class="text-base font-black text-emerald-400">${disposedCount}</div>
              <div class="text-[9px] gb-text-muted font-bold">निस्तारित (Disposed)</div>
            </div>
            <div class="gb-card p-2.5 border-rose-400/40">
              <div class="text-xs font-black text-rose-400">₹${totalPendingFee.toLocaleString("en-IN")}</div>
              <div class="text-[9px] gb-text-muted font-bold">बकाया फीस (Due)</div>
            </div>
          </div>

          ${
            state.diaryEditingId
              ? `
            <!-- Full Create / Edit Case Modal Card -->
            <div class="gb-card p-4 space-y-2.5 border-2 border-amber-400 text-xs shadow-2xl">
              <div class="flex justify-between items-center border-b border-purple-500/20 pb-2">
                <h3 class="text-sm font-black text-amber-400">${editingCase ? "✏️ केस डायरी अपडेट करें (Edit Case)" : "➕ नया केस दर्ज करें (Add New Case)"}</h3>
                <button onclick="GBApp.closeDiaryEditor()" class="w-7 h-7 rounded-full gb-surface font-bold">✕</button>
              </div>
              <div class="grid grid-cols-2 gap-2">
                <div>
                  <label class="text-[10px] font-bold gb-text-sub block mb-1">केस नंबर (Case No.) *</label>
                  <input id="diary-caseno" type="text" value="${editingCase ? editingCase.caseNo : ""}" placeholder="e.g. ST No. 502/2026" class="gb-input" />
                </div>
                <div>
                  <label class="text-[10px] font-bold gb-text-sub block mb-1">धारा / कानून (Section)</label>
                  <input id="diary-section" type="text" value="${editingCase ? editingCase.section : ""}" placeholder="BNS 103 / BNSS 482" class="gb-input" />
                </div>
              </div>
              <div>
                <label class="text-[10px] font-bold gb-text-sub block mb-1">केस का नाम (Party Name: वादी बनाम प्रतिवादी) *</label>
                <input id="diary-title" type="text" value="${editingCase ? editingCase.title : ""}" placeholder="e.g. रमेश कुमार बनाम उत्तर प्रदेश राज्य" class="gb-input" />
              </div>
              <div class="grid grid-cols-2 gap-2">
                <div>
                  <label class="text-[10px] font-bold gb-text-sub block mb-1">न्यायालय (Court Name) *</label>
                  <input id="diary-court" type="text" value="${editingCase ? editingCase.court : ""}" placeholder="District & Sessions Court" class="gb-input" />
                </div>
                <div>
                  <label class="text-[10px] font-bold gb-text-sub block mb-1">अगली तारीख (Next Date) *</label>
                  <input id="diary-date" type="date" value="${editingCase ? editingCase.nextDate : "2026-11-12"}" class="gb-input" />
                </div>
                <div>
                  <label class="text-[11px] font-bold block mb-1">Reminder Time</label>
                  <input id="diary-remtime" type="time" value="${editingCase ? editingCase.reminderTime || "09:00" : "09:00"}" class="gb-input" />
                </div>
              </div>
              <div class="grid grid-cols-3 gap-2">
                <div>
                  <label class="text-[10px] font-bold gb-text-sub block mb-1">सुनवाई स्तर (Stage)</label>
                  <input id="diary-stage" type="text" value="${editingCase ? editingCase.stage : ""}" placeholder="Bail / Evidence" class="gb-input" />
                </div>
                <div>
                  <label class="text-[10px] font-bold gb-text-sub block mb-1">कुल फीस (Total ₹)</label>
                  <input id="diary-totalfee" type="number" value="${editingCase ? editingCase.totalFee || 15000 : 15000}" class="gb-input" />
                </div>
                <div>
                  <label class="text-[10px] font-bold gb-text-sub block mb-1">प्राप्त फीस (Paid ₹)</label>
                  <input id="diary-paidfee" type="number" value="${editingCase ? editingCase.receivedFee || 5000 : 5000}" class="gb-input" />
                </div>
              </div>
              <div>
                <label class="text-[10px] font-bold gb-text-sub block mb-1">केस नोट्स व अगली तारीख की तैयारी (Case Notes)</label>
                <textarea id="diary-notes" rows="2" placeholder="गवाह, दस्तावेज या बहस के मुख्य बिंदु लिखें..." class="gb-input">${editingCase ? editingCase.notes || "" : ""}</textarea>
              </div>
              <div class="flex gap-2 pt-1">
                <button onclick="GBApp.closeDiaryEditor()" class="flex-1 py-2.5 gb-btn-outline text-xs">रद्द करें (Cancel)</button>
                <button onclick="GBApp.saveDiaryEntry()" class="flex-1 py-2.5 gb-btn-primary text-xs">💾 डायरी में सेव करें</button>
              </div>
            </div>
          `
              : ""
          }

          <!-- Search & Filter Tabs -->
          <div class="flex items-center gap-2 px-3 py-2 rounded-xl gb-card">
            <span>🔍</span>
            <input type="text" value="${state.diarySearch || ""}" oninput="GBApp.setDiarySearch(this.value)" placeholder="केस नंबर, मुवक्किल का नाम, धारा या कोर्ट खोजें..." class="bg-transparent flex-1 text-xs focus:outline-none" />
          </div>

          <div class="flex gap-1.5 overflow-x-auto no-scrollbar">
            ${["All", "Today", "Upcoming", "Fee Pending", "Disposed"].map((t) => `
              <button onclick="GBApp.setDiaryFilterTab('${t}')" class="px-3 py-1.5 rounded-full text-[11px] font-extrabold whitespace-nowrap border ${
                tab === t ? "gb-tab-active" : "gb-surface"
              }">${t === "All" ? "📋 सभी केस (" + allCases.length + ")" : t}</button>
            `).join("")}
          </div>

          <!-- Case Cards List -->
          <div class="space-y-3">
            ${
              filtered.length === 0
                ? `<div class="gb-card p-6 text-center space-y-2">
                    <div class="text-3xl">📓</div>
                    <div class="text-xs font-extrabold">इस श्रेणी में कोई केस नहीं मिला</div>
                    <button onclick="GBApp.openDiaryEditor('NEW')" class="px-4 py-2 gb-btn-primary text-xs">+ नया केस जोड़ें</button>
                  </div>`
                : filtered.map((c) => {
                    const tot = Number(c.totalFee) || 15000;
                    const rec = Number(c.receivedFee) || 10000;
                    const due = Math.max(0, tot - rec);
                    const isExpanded = state.diaryViewingId === c.id;
                    return `
                      <div class="gb-card p-3.5 space-y-2.5 border-l-4 ${c.status === "Disposed" ? "border-l-emerald-500" : "border-l-amber-500"}">
                        <div class="flex items-center justify-between gap-2">
                          <div class="flex items-center gap-1.5">
                            <span class="px-2 py-0.5 rounded bg-purple-600 text-white text-[10px] font-black">${c.caseNo}</span>
                            <span class="px-2 py-0.5 rounded ${c.status === "Disposed" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-500/20 text-amber-400"} text-[9px] font-extrabold">
                              ${c.status === "Disposed" ? "✓ Disposed" : "📅 Next: " + c.nextDate}
                            </span>
                          </div>
                          <span class="text-[10px] font-extrabold ${due > 0 ? "text-rose-400" : "text-emerald-400"}">
                            ${due > 0 ? `बकाया: ₹${due.toLocaleString("en-IN")}` : "✓ Full Fee Paid"}
                          </span>
                        </div>

                        <div>
                          <h4 class="text-sm font-black leading-snug">${c.title}</h4>
                          <div class="text-[11px] gb-text-sub mt-0.5">🏛️ ${c.court} • ⚖️ <strong class="gb-text-accent">${c.section}</strong></div>
                        </div>

                        <div class="grid grid-cols-2 gap-2 p-2 rounded-xl gb-surface text-[10px]">
                          <div><span class="gb-text-muted">मुवक्किल (Client):</span> <strong>${c.client || "Client"}</strong></div>
                          <div><span class="gb-text-muted">स्टेज (Stage):</span> <strong class="text-emerald-400">${c.stage}</strong></div>
                        </div>

                        <div class="p-2.5 rounded-xl gb-surface-alt text-[11px] gb-text-sub">
                          <strong class="gb-text-gold">📝 केस नोट्स:</strong> ${c.notes || "कोई अतिरिक्त नोट नहीं।"}
                        </div>

                        ${
                          isExpanded
                            ? `
                          <!-- Expanded Case History & Next Date Updater -->
                          <div class="p-3 rounded-xl gb-surface space-y-2.5 border border-purple-500/30 text-xs">
                            <div class="font-extrabold gb-text-accent">📜 सुनवाई इतिहास (Hearing History & Orders):</div>
                            <div class="space-y-1.5">
                              ${(c.history || []).map((h) => `
                                <div class="p-2 rounded-lg gb-card flex justify-between items-center text-[10px]">
                                  <span><strong>${h.date}:</strong> ${h.order}</span>
                                  <span class="gb-text-gold font-bold shrink-0">→ ${h.nextDate}</span>
                                </div>
                              `).join("")}
                            </div>
                            <div class="pt-2 border-t border-purple-500/20 space-y-1.5">
                              <div class="text-[10px] font-bold gb-text-gold">⚡ अगली तारीख और ऑर्डर जोड़ें (Quick Next Date Update):</div>
                              <div class="grid grid-cols-2 gap-1.5">
                                <input id="diary-quick-nextdate-${c.id}" type="date" value="2026-11-28" class="gb-input text-xs py-1.5" />
                                <input id="diary-quick-order-${c.id}" type="text" placeholder="Order / अगली कार्यवाही..." class="gb-input text-xs py-1.5" />
                              </div>
                              <button onclick="GBApp.addDiaryHearingLog('${c.id}')" class="w-full py-1.5 gb-btn-primary text-[11px]">
                                ✓ अगली तारीख अपडेट करें
                              </button>
                            </div>
                          </div>
                        `
                            : ""
                        }

                        <!-- Action Buttons -->
                        <div class="flex items-center justify-between gap-1.5 pt-1 border-t border-purple-500/20 text-[11px]">
                          <button onclick="GBApp.viewDiaryEntry('${c.id}')" class="px-2.5 py-1.5 rounded-lg gb-surface font-bold">
                            ${isExpanded ? "🔼 छुपाएं" : "📜 तारीख इतिहास"}
                          </button>
                          <button onclick="GBApp.markDiaryCaseDisposed('${c.id}')" class="px-2.5 py-1.5 rounded-lg gb-surface font-bold text-emerald-400">
                            ${c.status === "Disposed" ? "🔄 Reopen" : "✓ Dispose"}
                          </button>
                          <button onclick="GBApp.openDiaryEditor('${c.id}')" class="px-2.5 py-1.5 rounded-lg gb-surface-alt gb-text-accent font-bold">
                            ✏️ Edit
                          </button>
                          <button onclick="GBApp.deleteDiaryEntry('${c.id}')" class="px-2.5 py-1.5 rounded-lg bg-rose-600/20 text-rose-400 font-bold">
                            🗑️
                          </button>
                        </div>
                      </div>
                    `;
                  }).join("")
            }
          </div>
        </div>
      </div>
    `;
  }

  function renderStudentNotesScreen() {
    const q = (state.notesSearch || "").trim().toLowerCase();
    const notesList = (state.studentNotes || []).slice().sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));
    const filtered = notesList.filter((n) => {
      if (state.notesSubjectFilter !== "All" && n.subject !== state.notesSubjectFilter) return false;
      if (!q) return true;
      return n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q) || n.subject.toLowerCase().includes(q);
    });
    const editingNote =
      state.noteEditingId && state.noteEditingId !== "NEW"
        ? state.studentNotes.find((n) => n.id === state.noteEditingId)
        : null;

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/25 gb-header sticky top-9 z-30">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-black text-amber-400">🎓 Student Smart Notes (लॉ स्टूडेंट नोट्स)</div>
              <div class="text-[10px] gb-text-sub">Subject Folders, Voice Dictation & Flashcard Revision</div>
            </div>
          </div>
          <button onclick="GBApp.openNoteEditor('NEW')" class="px-3 py-1.5 gb-btn-gold text-xs font-black shadow">
            + नया नोट बनाएं
          </button>
        </div>

        <div class="p-3.5 space-y-3.5">
          <!-- Stats & Mode Switcher Bar -->
          <div class="gb-card p-3 flex items-center justify-between gap-2 border-purple-400/40">
            <div class="flex items-center gap-3 text-xs">
              <div><span class="gb-text-muted">कुल नोट्स:</span> <strong class="gb-text-accent">${state.studentNotes.length}</strong></div>
              <div><span class="gb-text-muted">Pinned:</span> <strong class="gb-text-gold">${state.studentNotes.filter((x) => x.pinned).length} 📌</strong></div>
            </div>
            <div class="flex gap-1.5">
              <button onclick="GBApp.setNotesViewMode('cards')" class="px-2.5 py-1 rounded-lg text-[10px] font-extrabold border ${
                state.notesViewMode !== "flashcards" ? "gb-tab-active" : "gb-surface"
              }">📝 Notes View</button>
              <button onclick="GBApp.setNotesViewMode('flashcards')" class="px-2.5 py-1 rounded-lg text-[10px] font-extrabold border ${
                state.notesViewMode === "flashcards" ? "gb-tab-active" : "gb-surface"
              }">⚡ Flashcards</button>
            </div>
          </div>

          ${
            state.noteEditingId
              ? `
            <!-- Create / Edit Student Note Modal Card -->
            <div class="gb-card p-4 space-y-2.5 border-2 border-amber-400 text-xs shadow-2xl">
              <div class="flex justify-between items-center border-b border-purple-500/20 pb-2">
                <h3 class="text-sm font-black text-amber-400">${editingNote ? "✏️ नोट संपादित करें (Edit Study Note)" : "➕ नया लॉ नोट बनाएं (Create Study Note)"}</h3>
                <button onclick="GBApp.closeNoteEditor()" class="w-7 h-7 rounded-full gb-surface font-bold">✕</button>
              </div>
              <div>
                <label class="text-[10px] font-bold gb-text-sub block mb-1">नोट का शीर्षक (Note Title) *</label>
                <input id="note-title-inp" type="text" value="${editingNote ? editingNote.title : ""}" placeholder="e.g. BNS धारा 103 एवं मॉब लिंचिंग के मुख्य बिंदु" class="gb-input font-bold" />
              </div>
              <div class="grid grid-cols-2 gap-2">
                <div>
                  <label class="text-[10px] font-bold gb-text-sub block mb-1">विषय / कानून (Subject Folder)</label>
                  <select id="note-subj-inp" class="gb-input">
                    ${["BNS 2023", "BNSS 2023", "BSA 2023", "Constitution", "Case Briefs", "Public Law"]
                      .map((s) => `<option value="${s}" ${editingNote && editingNote.subject === s ? "selected" : ""}>${s}</option>`)
                      .join("")}
                  </select>
                </div>
                <div>
                  <label class="text-[10px] font-bold gb-text-sub block mb-1">Voice-to-Text Dictation</label>
                  <button type="button" onclick="GBApp.dictateStudentNoteDemo()" class="w-full py-2 rounded-xl gb-surface-alt gb-text-accent font-extrabold text-[11px] border border-purple-400/40">
                    🎙️ बोलकर हिंदी में लिखें
                  </button>
                </div>
              </div>
              <div>
                <label class="text-[10px] font-bold gb-text-sub block mb-1">विस्तृत नोट्स, धाराएं व केस लॉ (Note Content) *</label>
                <textarea id="note-content-inp" rows="5" placeholder="अपने परीक्षा नोट्स, बुलेट पॉइंट्स या केस सारांश यहाँ लिखें..." class="gb-input">${editingNote ? editingNote.content : ""}</textarea>
              </div>
              <div class="flex gap-2 pt-1">
                <button onclick="GBApp.closeNoteEditor()" class="flex-1 py-2.5 gb-btn-outline text-xs">रद्द करें</button>
                <button onclick="GBApp.saveStudentNote()" class="flex-1 py-2.5 gb-btn-primary text-xs">💾 नोट सेव करें</button>
              </div>
            </div>
          `
              : ""
          }

          <!-- Search & Subject Filter Pills -->
          <div class="flex items-center gap-2 px-3 py-2 rounded-xl gb-card">
            <span>🔍</span>
            <input type="text" value="${state.notesSearch || ""}" oninput="GBApp.setNotesSearch(this.value)" placeholder="नोट्स में धारा, केस या टॉपिक खोजें..." class="bg-transparent flex-1 text-xs focus:outline-none" />
          </div>

          <div class="flex gap-1.5 overflow-x-auto no-scrollbar">
            ${["All", "BNS 2023", "BNSS 2023", "BSA 2023", "Constitution", "Case Briefs"].map((subj) => `
              <button onclick="GBApp.setNotesSubjectFilter('${subj}')" class="px-3 py-1.5 rounded-full text-[11px] font-extrabold whitespace-nowrap border ${
                state.notesSubjectFilter === subj ? "gb-tab-active" : "gb-surface"
              }">${subj === "All" ? "📚 All Subjects (" + state.studentNotes.length + ")" : subj}</button>
            `).join("")}
          </div>

          <!-- Notes Cards or Flashcard Revision Mode -->
          <div class="space-y-3">
            ${
              filtered.length === 0
                ? `<div class="gb-card p-6 text-center space-y-2">
                    <div class="text-3xl">📝</div>
                    <div class="text-xs font-extrabold">इस विषय में कोई नोट नहीं मिला</div>
                    <button onclick="GBApp.openNoteEditor('NEW')" class="px-4 py-2 gb-btn-primary text-xs">+ पहला नोट बनाएं</button>
                  </div>`
                : state.notesViewMode === "flashcards"
                ? filtered.map((n, idx) => `
                    <div class="gb-card p-4 space-y-2.5 border-2 border-amber-500/40 relative">
                      <div class="flex justify-between items-center">
                        <span class="px-2 py-0.5 rounded bg-amber-500 text-black text-[9px] font-black">FLASHCARD #${idx + 1} • ${n.subject}</span>
                        <button onclick="GBApp.speakWord('w1')" class="text-xs font-bold gb-text-accent">🔊 सुनें</button>
                      </div>
                      <h4 class="text-sm font-black gb-text-gold">Q: ${n.title}</h4>
                      <div class="p-3 rounded-xl gb-surface text-xs gb-text-sub whitespace-pre-wrap leading-relaxed border-l-4 border-purple-500">${n.content}</div>
                    </div>
                  `).join("")
                : filtered.map((n) => `
                    <div class="gb-card p-3.5 space-y-2.5 border-l-4 ${n.pinned ? "border-l-amber-400" : "border-l-purple-500"}">
                      <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center gap-1.5">
                          <span class="px-2 py-0.5 rounded bg-purple-600 text-white text-[10px] font-black">${n.subject}</span>
                          <span class="px-2 py-0.5 rounded gb-surface-alt text-[9px] font-bold gb-text-gold">${n.examTag || "Exam Note"}</span>
                          ${n.pinned ? `<span class="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 text-[9px] font-extrabold">📌 Pinned</span>` : ""}
                        </div>
                        <span class="text-[10px] gb-text-muted">${n.updated}</span>
                      </div>

                      <div class="text-sm font-black leading-snug">${n.title}</div>
                      <pre class="text-xs gb-text-sub whitespace-pre-wrap font-sans leading-relaxed p-3 rounded-xl gb-surface border border-purple-500/20">${n.content}</pre>

                      <div class="flex items-center justify-between gap-1.5 pt-1 border-t border-purple-500/20 text-[11px]">
                        <button onclick="GBApp.toggleNotePin('${n.id}')" class="px-2.5 py-1 rounded-lg gb-surface font-bold">
                          ${n.pinned ? "📌 Unpin" : "📌 Pin Top"}
                        </button>
                        <button onclick="GBApp.addCurrentItemToFolder('${state.folders[0]?.id || "f1"}', 'Student Note', '${n.title}', 'student_notes')" class="px-2.5 py-1 rounded-lg gb-surface font-bold">
                          📁 +Folder
                        </button>
                        <button onclick="GBApp.openNoteEditor('${n.id}')" class="px-2.5 py-1 rounded-lg gb-surface-alt gb-text-accent font-bold">
                          ✏️ Edit
                        </button>
                        <button onclick="GBApp.deleteStudentNote('${n.id}')" class="px-2.5 py-1 rounded-lg bg-rose-600/20 text-rose-400 font-bold">
                          🗑️
                        </button>
                      </div>
                    </div>
                  `).join("")
            }
          </div>
        </div>
      </div>
    `;
  }

  function renderReelsScreen() {
    const reel = DATA.reelsData.bnsReels[state.currentReelIndex % DATA.reelsData.bnsReels.length];
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">🎬 Legal Reels (Demo Short Videos)</div>
              <div class="text-[10px] gb-text-sub">Section Reels & Public Law Reels</div>
            </div>
          </div>
          <button onclick="GBApp.toggleReelsSectionModal(true)" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-extrabold gb-text-accent">
            📑 Sections (${reel.sectionNum}/${reel.totalSections})
          </button>
        </div>

        <div class="p-3 space-y-3">
          <div class="grid grid-cols-3 gap-1.5 text-xs font-bold">
            <button onclick="GBApp.setReelsCategory('section_reels')" class="py-1.5 rounded-xl border ${state.reelsCategory === "section_reels" ? "gb-tab-active" : "gb-surface"}">📑 Section Reels</button>
            <button onclick="GBApp.setReelsCategory('public_law')" class="py-1.5 rounded-xl border ${state.reelsCategory === "public_law" ? "gb-tab-active" : "gb-surface"}">🏛️ Public Law</button>
            <button onclick="GBApp.setReelsCategory('topic_list')" class="py-1.5 rounded-xl border ${state.reelsCategory === "topic_list" ? "gb-tab-active" : "gb-surface"}">📋 Topics List</button>
          </div>

          ${
            state.reelsCategory === "topic_list"
              ? `
            <div class="space-y-2">
              ${DATA.reelsData.publicLawTopics.map((t, i) => `
                <button onclick="GBApp.setReelsCategory('public_law'); GBApp.selectReelIndex(${i})" class="w-full gb-card p-3 flex items-center justify-between text-left text-xs">
                  <div>
                    <div class="font-extrabold">${i + 1}. ${t.title}</div>
                    <div class="text-[10px] gb-text-gold">${t.headline}</div>
                  </div>
                  <span class="px-2.5 py-1 rounded gb-btn-primary text-[10px]">▶ Watch</span>
                </button>
              `).join("")}
            </div>
          `
              : `
            <div class="dark-media-stage relative rounded-2xl overflow-hidden border border-purple-400/50 bg-black shadow-2xl">
              <img src="${reel.image}" alt="Legal Reel" class="w-full h-96 object-cover" />
              <div class="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-black/30 p-4 flex flex-col justify-between text-white">
                <div class="flex justify-between items-start">
                  <span class="px-2.5 py-1 rounded-xl bg-black/75 border border-amber-400/50 text-xs font-extrabold text-amber-300">
                    ${state.reelsCategory === "public_law" ? "Public Law Reel" : `Section ${reel.sectionNum} / ${reel.totalSections}`}
                  </span>
                  <span class="px-2 py-0.5 rounded bg-purple-700 text-[10px] font-bold">DEMO REEL</span>
                </div>

                <div class="my-auto text-center">
                  <h2 class="text-2xl font-black text-amber-300 drop-shadow">${reel.headline}</h2>
                  <p class="text-xs text-white mt-1 bg-black/70 inline-block px-3 py-1 rounded-full">${reel.subheadline}</p>
                </div>

                <div class="space-y-2">
                  <div class="text-xs font-bold">${reel.speaker} ✔ • <span class="text-gray-300 text-[10px]">${reel.speakerRole}</span></div>
                  <p class="text-[11px] text-gray-200">${reel.caption}</p>
                  <div class="flex items-center justify-between pt-2 border-t border-white/15">
                    <button onclick="GBApp.togglePlay()" class="px-4 py-1.5 rounded-full bg-purple-600 text-white text-xs font-bold">
                      ${state.isPlaying ? "⏸ Pause" : "▶ Play Audio"}
                    </button>
                    <button onclick="GBApp.nextReel()" class="px-4 py-1.5 rounded-full bg-amber-500 text-black text-xs font-extrabold">
                      Next Reel ⏭
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Bottom Media Switcher (Audio | Video | Reels | Notes | Mind Map) -->
            <div class="gb-card p-2 grid grid-cols-5 gap-1 text-center text-[10px] font-bold">
              <button onclick="GBApp.openCategoryMedia('audio')" class="p-1.5 rounded-lg gb-surface">🎧 Audio</button>
              <button onclick="GBApp.openCategoryMedia('video')" class="p-1.5 rounded-lg gb-surface">▶️ Video</button>
              <button class="p-1.5 rounded-lg gb-tab-active">🎬 Reels</button>
              <button onclick="GBApp.openCategoryMedia('pdf')" class="p-1.5 rounded-lg gb-surface">📄 Notes</button>
              <button onclick="GBApp.openCategoryMedia('mindmap')" class="p-1.5 rounded-lg gb-surface">🕸️ Map</button>
            </div>
          `
          }
        </div>

        ${
          state.reelsSectionModalOpen
            ? `
          <div class="fixed inset-0 z-50 bg-black/80 flex items-end justify-center p-2">
            <div class="gb-card w-full max-w-[430px] p-4 space-y-3 border-purple-400">
              <div class="flex justify-between items-center border-b border-purple-500/20 pb-2">
                <span class="text-sm font-black">Select Section Reel (BNS 2023)</span>
                <button onclick="GBApp.toggleReelsSectionModal(false)" class="font-bold">✕</button>
              </div>
              <div class="space-y-1.5">
                ${DATA.reelsData.bnsReels.map((r, idx) => `
                  <button onclick="GBApp.selectReelIndex(${idx})" class="w-full p-2.5 rounded-xl flex justify-between items-center text-xs ${idx === state.currentReelIndex ? "gb-tab-active" : "gb-surface"}">
                    <span>Section ${r.sectionNum}: ${r.headline}</span>
                    <span>▶ Watch</span>
                  </button>
                `).join("")}
              </div>
            </div>
          </div>
        `
            : ""
        }
      </div>
    `;
  }

  // Requirement #13: Dynamic Progress Tracking (Act vs Public Law Tabs + All 67 Acts + Criminal Law 150 Topics — PDF 3 Pages 18–21)
  function renderProgressTrackingScreen() {
    const typesArr = Object.entries(state.progressByType);

    if (state.progressTab === "all_acts_list") {
      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
            <div class="flex items-center gap-2">
              <button onclick="GBApp.setProgressTab('act')" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
              <div class="text-sm font-extrabold">All Act (67) — Progress Breakdown</div>
            </div>
          </div>
          <div class="p-3.5 space-y-2.5">
            ${DATA.allActsProgressList.map((a) => `
              <div onclick="GBApp.navigateTo('act_detail', { actId: '${a.actId}' })" class="gb-card gb-card-interactive p-3.5 space-y-1.5 cursor-pointer">
                <div class="flex items-center justify-between text-xs">
                  <div class="font-extrabold">${a.num}. ${a.titleHindi} <span class="text-[10px] gb-text-muted">(${a.titleEng})</span></div>
                  <span class="font-black gb-text-gold">${a.pct}%</span>
                </div>
                <div class="text-[10px] gb-text-sub">${a.done} / ${a.total} Sections Completed</div>
                <div class="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
                  <div class="h-full rounded-full" style="width:${a.pct}%; background:${a.color}"></div>
                </div>
              </div>
            `).join("")}
          </div>
        </div>
      `;
    }

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">📊 Progress Tracking</div>
              <div class="text-[10px] gb-text-sub">Act & Public Law Dynamic Progress</div>
            </div>
          </div>
        </div>

        <div class="p-3.5 space-y-3.5">
          <!-- Top Switcher: Act | Public Law (PDF 3 Pages 18 & 19) -->
          <div class="grid grid-cols-2 gap-2 p-1 rounded-xl gb-surface text-xs font-bold">
            <button onclick="GBApp.setProgressTab('act')" class="py-2 rounded-lg ${state.progressTab === "act" ? "gb-tab-active" : ""}">📖 Act</button>
            <button onclick="GBApp.setProgressTab('public_law')" class="py-2 rounded-lg ${state.progressTab === "public_law" ? "gb-tab-active" : ""}">⚖️ Public Law</button>
          </div>

          <!-- Overall Progress Ring Card -->
          <div class="gb-card p-4 flex items-center gap-4 border-purple-400/50">
            <div class="w-24 h-24 rounded-full border-4 border-amber-400 flex flex-col items-center justify-center shrink-0">
              <span class="text-xl font-black">${state.progressTab === "public_law" ? "62%" : "56%"}</span>
              <span class="text-[9px] gb-text-muted">Completed</span>
            </div>
            <div class="flex-1 space-y-1.5 text-xs">
              <div class="flex justify-between"><span>🟢 Completed</span><strong>${state.progressTab === "public_law" ? "62%" : "56%"}</strong></div>
              <div class="flex justify-between"><span>🟣 In Progress</span><strong>${state.progressTab === "public_law" ? "28%" : "29%"}</strong></div>
              <div class="flex justify-between"><span>⚪ Not Started</span><strong>${state.progressTab === "public_law" ? "10%" : "15%"}</strong></div>
              <button onclick="GBApp.markContentCompleted('audio', 'bns', 'Study Session')" class="w-full py-1.5 mt-1 gb-btn-primary text-[10px]">
                + Complete 1 Demo Session (Live Update)
              </button>
            </div>
          </div>

          <!-- Progress by Content Type (7 Formats) -->
          <div class="gb-card p-3.5 space-y-2.5">
            <h3 class="text-xs font-extrabold gb-text-gold">Progress by Content Type:</h3>
            ${typesArr.map(([key, item]) => {
              const pct = Math.round((item.completed / item.total) * 100);
              return `
                <div class="space-y-1 text-xs">
                  <div class="flex justify-between font-bold">
                    <span>${item.icon} ${item.label} <span class="text-[10px] gb-text-muted">(${item.completed}/${item.total})</span></span>
                    <span>${pct}%</span>
                  </div>
                  <div class="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
                    <div class="h-full rounded-full" style="width:${pct}%; background:${item.color}"></div>
                  </div>
                </div>
              `;
            }).join("")}
          </div>

          ${
            state.progressTab === "act"
              ? `
            <div class="gb-card p-3.5 space-y-2.5">
              <div class="flex items-center justify-between">
                <h3 class="text-xs font-extrabold gb-text-accent">All Recently Studied Acts</h3>
                <button onclick="GBApp.setProgressTab('all_acts_list')" class="text-[11px] font-bold gb-text-gold">All Act (67) ›</button>
              </div>
              ${DATA.allActsProgressList.slice(0, 4).map((a) => `
                <div onclick="GBApp.navigateTo('act_detail', { actId: '${a.actId}' })" class="p-2.5 rounded-xl gb-surface space-y-1 cursor-pointer">
                  <div class="flex justify-between text-xs font-bold">
                    <span>${a.icon} ${a.titleEng}</span>
                    <span class="gb-text-gold">${a.pct}%</span>
                  </div>
                  <div class="text-[10px] gb-text-muted">${a.done} / ${a.total} Sections Completed</div>
                  <div class="w-full h-1.5 bg-purple-950 rounded-full overflow-hidden">
                    <div class="h-full rounded-full" style="width:${a.pct}%; background:${a.color}"></div>
                  </div>
                </div>
              `).join("")}
            </div>
          `
              : `
            <!-- Public Law Criminal Law (150 Topics) Breakdown (PDF 3 Page 20) -->
            <div class="gb-card p-3.5 space-y-2.5">
              <h3 class="text-xs font-extrabold gb-text-accent">Criminal Law & Public Law (150 Topics):</h3>
              ${DATA.publicLawCriminalTopics.map((t) => `
                <div onclick="GBApp.navigateTo('public_law_detail', { publicTopicId: '${t.topicId}' })" class="p-2.5 rounded-xl gb-surface space-y-1 cursor-pointer">
                  <div class="flex justify-between text-xs font-bold">
                    <span>${t.num}. ${t.title}</span>
                    <span class="gb-text-gold">${t.pct}%</span>
                  </div>
                  <div class="text-[10px] gb-text-muted">${t.done} / ${t.total} Topics Completed</div>
                  <div class="w-full h-1.5 bg-purple-950 rounded-full overflow-hidden">
                    <div class="h-full bg-purple-500 rounded-full" style="width:${t.pct}%"></div>
                  </div>
                </div>
              `).join("")}
            </div>
          `
          }
        </div>
      </div>
    `;
  }
  // Requirement #14: Referral 3-Tab Screen (PDF 3 Pages 22–23), Notifications, Saved, History, Folders, Request Topic & Settings
  function renderReferralScreen() {
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">🎁 Refer & Earn (Demo Rewards)</div>
              <div class="text-[10px] gb-text-sub">Invite Friends, Progress & Rules</div>
            </div>
          </div>
        </div>

        <div class="p-3.5 space-y-3.5 text-xs">
          <!-- 3 Referral Tabs: 01 Invite & Earn | 02 Progress & Rewards | 03 Activity & Rules -->
          <div class="grid grid-cols-3 gap-1.5 p-1 rounded-xl gb-surface font-bold text-[10px]">
            <button onclick="GBApp.setReferralTab('invite')" class="py-2 rounded-lg ${state.referralTab === "invite" ? "gb-tab-active" : ""}">01 Invite & Earn</button>
            <button onclick="GBApp.setReferralTab('progress')" class="py-2 rounded-lg ${state.referralTab === "progress" ? "gb-tab-active" : ""}">02 Progress & Rewards</button>
            <button onclick="GBApp.setReferralTab('activity')" class="py-2 rounded-lg ${state.referralTab === "activity" ? "gb-tab-active" : ""}">03 Activity & Rules</button>
          </div>

          ${
            state.referralTab === "invite"
              ? `
            <div class="gb-card p-4 space-y-3 border-amber-400/50 text-center">
              <div class="text-2xl">🎁</div>
              <h3 class="text-base font-black gb-text-gold">Share App & Unlock Free Demo Days</h3>
              <p class="text-[11px] gb-text-sub">⚠️ Demo Notice: ये रिवॉर्ड पॉइंट्स और फ्री प्रीमियम दिन केवल फ्रंटएंड डेमो परीक्षण के लिए हैं।</p>

              <!-- Social Share Buttons -->
              <div class="grid grid-cols-4 gap-2 pt-1">
                ${["WhatsApp", "Instagram", "Telegram", "Copy Link"].map((pl) => `
                  <button onclick="GBApp.simulateReferralShare('${pl}')" class="p-2 rounded-xl gb-surface font-bold text-[10px] hover:border-purple-400">
                    <div>📤</div>
                    <div class="mt-0.5">${pl}</div>
                  </button>
                `).join("")}
              </div>

              <!-- Referral Code Box -->
              <div class="p-3 rounded-xl gb-surface flex items-center justify-between">
                <div class="text-left">
                  <div class="text-[10px] gb-text-muted">Your Referral Code</div>
                  <div class="text-sm font-black tracking-widest gb-text-accent">REF12345</div>
                </div>
                <button onclick="GBApp.copyReferralCode()" class="px-3.5 py-1.5 gb-btn-primary text-xs">📋 Copy</button>
              </div>
            </div>

            <!-- Milestones (PDF 3 Page 22) -->
            <div class="gb-card p-3.5 space-y-2">
              <div class="font-extrabold gb-text-accent">1. Referral Milestones (Demo):</div>
              <div class="p-2 rounded-lg gb-surface flex justify-between"><span>5 Users Install & Login</span><strong class="gb-text-gold">12 Din FREE</strong></div>
              <div class="p-2 rounded-lg gb-surface flex justify-between"><span>10 Users Install & Login</span><strong class="gb-text-gold">1 Mahina FREE</strong></div>
              <div class="p-2 rounded-lg gb-surface flex justify-between"><span>15 Users Install & Login</span><strong class="gb-text-gold">2 Mahine FREE</strong></div>
            </div>
          `
              : state.referralTab === "progress"
              ? `
            <div class="gb-card p-4 text-center space-y-3 border-purple-400/50">
              <div class="font-extrabold gb-text-gold">Total Demo Premium Earned</div>
              <div class="w-24 h-24 rounded-full border-4 border-amber-400 flex flex-col items-center justify-center mx-auto">
                <span class="text-lg font-black">${state.freeDaysEarned} Din</span>
                <span class="text-[9px] gb-text-muted">Earned (Demo)</span>
              </div>
              <div class="space-y-2 text-left pt-2">
                <div>
                  <div class="flex justify-between font-bold mb-1"><span>Referral Progress</span><span class="gb-text-accent">${state.referralUsersCount} / 5 Users</span></div>
                  <div class="w-full h-2 bg-purple-950 rounded-full overflow-hidden"><div class="h-full bg-purple-500 rounded-full" style="width:${(state.referralUsersCount / 5) * 100}%"></div></div>
                </div>
                <div>
                  <div class="flex justify-between font-bold mb-1"><span>Share Progress</span><span class="gb-text-gold">${state.referralSharesCount} / 50 Shares</span></div>
                  <div class="w-full h-2 bg-purple-950 rounded-full overflow-hidden"><div class="h-full bg-amber-500 rounded-full" style="width:${Math.min(100, (state.referralSharesCount / 50) * 100)}%"></div></div>
                </div>
              </div>
            </div>
          `
              : `
            <div class="gb-card p-3.5 space-y-2.5">
              <div class="font-extrabold gb-text-accent">Recent Referral Activity (Demo):</div>
              <div class="p-2.5 rounded-xl gb-surface flex justify-between items-center">
                <div><div class="font-bold">Rohit Kumar</div><div class="text-[10px] gb-text-muted">Installed & Opened App • 12 Mar</div></div>
                <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">✔ Valid User</span>
              </div>
              <div class="p-2.5 rounded-xl gb-surface flex justify-between items-center">
                <div><div class="font-bold">Aman Verma</div><div class="text-[10px] gb-text-muted">Installed & Opened App • 10 Mar</div></div>
                <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">✔ Valid User</span>
              </div>
              <div class="p-2.5 rounded-xl gb-surface flex justify-between items-center">
                <div><div class="font-bold">Neha Sharma</div><div class="text-[10px] gb-text-muted">App Installed (Login Pending)</div></div>
                <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 text-[10px] font-bold">⏳ Pending</span>
              </div>
            </div>
          `
          }
        </div>
      </div>
    `;
  }

  function renderNotificationsScreen() {
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div class="text-sm font-extrabold">🔔 Notifications</div>
          </div>
          <button onclick="GBApp.markAllNotificationsRead()" class="text-xs font-bold gb-text-accent">Mark All Read</button>
        </div>
        <div class="p-3.5 space-y-2.5">
          ${state.notifications.map((n) => `
            <div class="gb-card p-3.5 flex items-start justify-between gap-2 ${n.unread ? "border-purple-400" : "opacity-80"}">
              <div>
                <span class="px-2 py-0.5 rounded gb-surface-alt text-[9px] font-bold gb-text-accent">${n.type}</span>
                <div class="text-xs font-extrabold mt-1">${n.title}</div>
                <div class="text-[10px] gb-text-muted mt-0.5">${n.time}</div>
              </div>
              ${n.unread ? `<span class="w-2.5 h-2.5 rounded-full bg-purple-500 shrink-0 mt-1"></span>` : ""}
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }

  function renderSavedItemsScreen() {
    const filter = state.savedFilterType || "All";
    const items = (state.savedItems || []).filter((sv) => filter === "All" || sv.type.toLowerCase().includes(filter.toLowerCase()));

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/25 gb-header sticky top-9 z-30">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-black text-amber-400">🔖 Saved & Favourite Collection</div>
              <div class="text-[10px] gb-text-sub">${state.savedItems.length} Bookmarked Lectures, Slides, Acts & Words</div>
            </div>
          </div>
          <button onclick="GBApp.navigateTo('folders')" class="px-2.5 py-1 rounded-full gb-surface-alt text-[10px] font-extrabold gb-text-accent">
            📁 My Folders ›
          </button>
        </div>

        <div class="p-3.5 space-y-3">
          <div class="flex gap-1.5 overflow-x-auto no-scrollbar">
            ${["All", "Bare Act", "Audio", "Slides", "Public Law"].map((t) => `
              <button onclick="GBApp.setSavedFilterType('${t}')" class="px-3 py-1.5 rounded-full text-[11px] font-extrabold whitespace-nowrap border ${
                filter === t ? "gb-tab-active" : "gb-surface"
              }">${t === "All" ? "💜 All Saved (" + state.savedItems.length + ")" : t}</button>
            `).join("")}
          </div>

          <div class="space-y-2.5">
            ${
              items.length === 0
                ? `<div class="gb-card p-6 text-center text-xs gb-text-muted">कोई सेव किया गया आइटम नहीं मिला।</div>`
                : items.map((sv) => `
                  <div class="gb-card p-3.5 flex items-center justify-between gap-2 border-purple-500/30">
                    <div onclick="GBApp.navigateTo('${sv.refScreen || "act_detail"}')" class="flex-1 cursor-pointer min-w-0">
                      <span class="px-2 py-0.5 rounded gb-surface-alt text-[9px] font-black gb-text-accent">${sv.type}</span>
                      <div class="text-xs font-extrabold mt-1 truncate">${sv.title}</div>
                    </div>
                    <div class="flex items-center gap-1.5 shrink-0">
                      <button onclick="GBApp.addCurrentItemToFolder('${state.folders[0]?.id || "f1"}', '${sv.type}', '${sv.title}', '${sv.refScreen || "act_detail"}')" class="px-2 py-1 rounded-lg gb-surface text-[10px] font-bold" title="Add to Folder">📁+</button>
                      <button onclick="GBApp.navigateTo('${sv.refScreen || "act_detail"}')" class="px-2.5 py-1 rounded-lg gb-btn-primary text-[10px]">Open ›</button>
                      <button onclick="GBApp.removeSavedItem('${sv.id}')" class="px-2 py-1 rounded-lg bg-rose-600/20 text-rose-400 text-[10px] font-bold">✕</button>
                    </div>
                  </div>
                `).join("")
            }
          </div>
        </div>
      </div>
    `;
  }

  function renderHistoryScreen() {
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/25 gb-header sticky top-9 z-30">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-black text-amber-400">🕒 Recent Learning History</div>
              <div class="text-[10px] gb-text-sub">आपके द्वारा हाल ही में पढ़े और सुने गए विषय</div>
            </div>
          </div>
          ${
            state.historyItems.length > 0
              ? `<button onclick="GBApp.clearAllHistory()" class="px-2.5 py-1 rounded-full bg-rose-600/20 text-rose-400 text-[10px] font-bold">🧹 Clear</button>`
              : ""
          }
        </div>
        <div class="p-3.5 space-y-2">
          ${
            state.historyItems.length === 0
              ? `<div class="gb-card p-6 text-center text-xs gb-text-muted">आपकी हिस्ट्री खाली है।</div>`
              : state.historyItems.map((h) => `
                  <button onclick="GBApp.navigateTo('${h.screen || "home"}')" class="w-full gb-card gb-card-interactive p-3 flex items-center justify-between text-left">
                    <div class="flex items-center gap-2.5 min-w-0">
                      <span class="w-8 h-8 rounded-xl gb-surface-alt flex items-center justify-center text-sm shrink-0">🕒</span>
                      <div class="min-w-0">
                        <div class="text-xs font-extrabold truncate">${h.title}</div>
                        <div class="text-[10px] gb-text-muted">${h.time}</div>
                      </div>
                    </div>
                    <span class="text-xs font-bold gb-text-accent shrink-0">Resume ›</span>
                  </button>
                `).join("")
          }
        </div>
      </div>
    `;
  }

  function renderFoldersScreen() {
    const activeFolder = state.activeFolderId ? state.folders.find((f) => f.id === state.activeFolderId) : null;

    if (activeFolder) {
      const items = activeFolder.items || [];
      return `
        <div class="flex-1 pb-24">
          <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/25 gb-header sticky top-9 z-30">
            <div class="flex items-center gap-2">
              <button onclick="GBApp.closeFolderDetail()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
              <div>
                <div class="text-sm font-black text-amber-400">${activeFolder.icon || "📁"} ${activeFolder.name}</div>
                <div class="text-[10px] gb-text-sub">${items.length} Saved Study Materials inside Folder</div>
              </div>
            </div>
            <button onclick="GBApp.addCurrentItemToFolder('${activeFolder.id}', 'Bare Act', 'BNS धारा 103: हत्या के लिए दंड नोट्स', 'bare_act_reader')" class="px-2.5 py-1 gb-btn-gold text-[10px]">
              + Add Demo Item
            </button>
          </div>

          <div class="p-3.5 space-y-2.5">
            ${
              items.length === 0
                ? `<div class="gb-card p-6 text-center space-y-2">
                    <div class="text-3xl">📂</div>
                    <div class="text-xs font-bold">यह फोल्डर अभी खाली है</div>
                    <button onclick="GBApp.addCurrentItemToFolder('${activeFolder.id}', 'Audio Lecture', 'BNS धारा 2: परिभाषाएं ऑडियो', 'audio_player')" class="px-4 py-2 gb-btn-primary text-xs">+ लेक्चर या नोट जोड़ें</button>
                  </div>`
                : items.map((it) => `
                    <div class="gb-card p-3.5 flex items-center justify-between gap-2">
                      <div onclick="GBApp.navigateTo('${it.screen || "act_detail"}')" class="flex-1 cursor-pointer min-w-0">
                        <span class="px-2 py-0.5 rounded gb-surface-alt text-[9px] font-black gb-text-accent">${it.type}</span>
                        <div class="text-xs font-extrabold mt-1 truncate">${it.title}</div>
                        <div class="text-[9px] gb-text-muted mt-0.5">Added: ${it.added || "Recently"}</div>
                      </div>
                      <div class="flex items-center gap-1.5 shrink-0">
                        <button onclick="GBApp.navigateTo('${it.screen || "act_detail"}')" class="px-3 py-1.5 gb-btn-primary text-[10px]">Open ›</button>
                        <button onclick="GBApp.removeItemFromFolder('${activeFolder.id}', '${it.id}')" class="px-2 py-1.5 rounded-lg bg-rose-600/20 text-rose-400 text-[10px] font-bold">🗑️</button>
                      </div>
                    </div>
                  `).join("")
            }
          </div>
        </div>
      `;
    }

    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/25 gb-header sticky top-9 z-30">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-black text-amber-400">📁 Create & Manage Study Folders</div>
              <div class="text-[10px] gb-text-sub">अपने विषय, केस और परीक्षा के अनुसार कस्टम फोल्डर बनाएं</div>
            </div>
          </div>
        </div>

        <div class="p-3.5 space-y-3.5">
          <!-- Create Folder Card -->
          <div class="gb-card p-4 space-y-2.5 border-purple-400/50">
            <label class="text-xs font-black gb-text-gold block">➕ नया स्टडी फोल्डर बनाएं (Create Custom Folder):</label>
            <div class="flex gap-2">
              <input id="new-folder-name-inp" type="text" placeholder="फोल्डर का नाम लिखें (e.g. UP Judiciary Mains, Bail Cases)..." class="gb-input flex-1" />
              <button onclick="GBApp.createNewFolder()" class="px-4 py-2 gb-btn-primary text-xs shrink-0">+ Create</button>
            </div>
            <div class="text-[10px] gb-text-muted">फोल्डर पर टैप करके उसके अंदर रखे सभी ऑडियो, वीडियो, PDF और नोट्स देखें।</div>
          </div>

          <!-- Folders Grid -->
          <div class="space-y-2.5">
            ${state.folders.map((f) => `
              <div class="gb-card gb-card-interactive p-3.5 flex items-center justify-between gap-3 border-l-4" style="border-left-color: ${f.color || "#7c3aed"}">
                <div onclick="GBApp.openFolderDetail('${f.id}')" class="flex items-center gap-3 cursor-pointer flex-1 min-w-0">
                  <div class="w-11 h-11 rounded-2xl gb-surface-alt flex items-center justify-center text-2xl shrink-0">
                    ${f.icon || "📁"}
                  </div>
                  <div class="min-w-0">
                    <div class="text-sm font-black truncate">${f.name}</div>
                    <div class="text-[11px] gb-text-sub">${(f.items ? f.items.length : f.itemsCount)} Saved Items • Updated ${f.updated}</div>
                  </div>
                </div>
                <div class="flex items-center gap-1.5 shrink-0">
                  <button onclick="GBApp.openFolderDetail('${f.id}')" class="px-3 py-1.5 rounded-xl gb-surface-alt gb-text-accent text-xs font-extrabold">Open ›</button>
                  <button onclick="GBApp.deleteFolder('${f.id}')" class="px-2.5 py-1.5 rounded-xl bg-rose-600/20 text-rose-400 text-xs font-bold">🗑️</button>
                </div>
              </div>
            `).join("")}
          </div>
        </div>
      </div>
    `;
  }

  function renderRequestTopicScreen() {
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center gap-2 border-b border-purple-500/20">
          <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
          <div class="text-sm font-extrabold">💡 Request Topic</div>
        </div>
        <div class="p-3.5 space-y-3.5 text-xs">
          <div class="gb-card p-4 space-y-2.5">
            <label class="font-bold block">Topic Title / Legal Question *</label>
            <input id="req-topic-title" type="text" placeholder="आप किस कानून या विषय पर वीडियो/नोट्स चाहते हैं?" class="gb-input" />
            <label class="font-bold block">Category</label>
            <select id="req-topic-cat" class="gb-input">
              <option value="BNS / Criminal Law">BNS / Criminal Law</option>
              <option value="Public Law / Citizen Rights">Public Law / Citizen Rights</option>
              <option value="Property & Civil Law">Property & Civil Law</option>
            </select>
            <button onclick="GBApp.submitTopicRequest()" class="w-full py-2.5 gb-btn-primary text-xs">Submit Topic Request</button>
          </div>
          <div class="space-y-2">
            ${state.topicRequests.map((tr) => `
              <div class="gb-card p-3 flex justify-between items-center">
                <div><div class="font-bold">${tr.topic}</div><div class="text-[10px] gb-text-muted">${tr.category}</div></div>
                <span class="px-2 py-0.5 rounded gb-surface-alt text-[9px] font-bold gb-text-accent">${tr.status}</span>
              </div>
            `).join("")}
          </div>
        </div>
      </div>
    `;
  }

  // Settings Screen (PDF 3 Page 17: Dark/Light Mode, Auto Play, Reminders, Fingerprint, Language, Backup, Logout All / My Device)
  function renderSettingsScreen() {
    return `
      <div class="flex-1 pb-24">
        <div class="px-3.5 py-2.5 flex items-center justify-between border-b border-purple-500/20">
          <div class="flex items-center gap-2">
            <button onclick="GBApp.goBack()" class="w-8 h-8 rounded-full gb-surface flex items-center justify-center font-bold">←</button>
            <div>
              <div class="text-sm font-extrabold">⚙️ Settings</div>
              <div class="text-[10px] gb-text-sub">Theme, Reminders, Backup & Session Controls</div>
            </div>
          </div>
        </div>

        <div class="p-3.5 space-y-3.5 text-xs">
          <!-- Dark Mode & Light Mode Separate Cards (Requirement #3) -->
          <div class="gb-card p-4 space-y-2.5">
            <div class="font-extrabold gb-text-accent">1. Theme Selection (Dark Mode / Light Mode):</div>
            <div class="grid grid-cols-2 gap-2.5">
              <button onclick="GBApp.setTheme('dark')" class="p-3 rounded-2xl border text-left space-y-1 ${
                state.theme === "dark" ? "gb-tab-active" : "gb-surface"
              }">
                <div class="flex justify-between"><span>🌙</span><span class="text-[10px] font-bold">${state.theme === "dark" ? "✓ ACTIVE" : "Select"}</span></div>
                <div class="font-extrabold">Dark Mode</div>
                <div class="text-[10px] gb-text-muted">Premium Dark Navy & Gold</div>
              </button>
              <button onclick="GBApp.setTheme('light')" class="p-3 rounded-2xl border text-left space-y-1 ${
                state.theme === "light" ? "gb-tab-active" : "gb-surface"
              }">
                <div class="flex justify-between"><span>☀️</span><span class="text-[10px] font-bold">${state.theme === "light" ? "✓ ACTIVE" : "Select"}</span></div>
                <div class="font-extrabold">Light Mode</div>
                <div class="text-[10px] gb-text-muted">Clean Light & High Contrast</div>
              </button>
            </div>
          </div>

          <!-- App Toggles from PDF 3 Page 17 -->
          <div class="gb-card p-3.5 space-y-2.5">
            <div class="flex items-center justify-between p-2 rounded-xl gb-surface">
              <div><div class="font-extrabold">🔊 Audio Auto Play</div><div class="text-[10px] gb-text-muted">Play next word/section automatically</div></div>
              <button onclick="GBApp.toggleAutoPlayAudio()" class="px-3 py-1 rounded-full font-bold text-[10px] ${state.autoPlayAudio ? "bg-emerald-600 text-white" : "gb-card"}">${state.autoPlayAudio ? "ON" : "OFF"}</button>
            </div>
            <div class="flex items-center justify-between p-2 rounded-xl gb-surface">
              <div><div class="font-extrabold">📖 Daily 10 Words Reminder</div><div class="text-[10px] gb-text-muted">Reminder Time: ${state.settingsDaily10Time}</div></div>
              <button onclick="GBApp.toggleSettingSwitch('settingsDaily10Reminder')" class="px-3 py-1 rounded-full font-bold text-[10px] ${state.settingsDaily10Reminder ? "bg-emerald-600 text-white" : "gb-card"}">${state.settingsDaily10Reminder ? "ON" : "OFF"}</button>
            </div>
            <div class="flex items-center justify-between p-2 rounded-xl gb-surface">
              <div><div class="font-extrabold">📝 Mock Test Reminder</div><div class="text-[10px] gb-text-muted">Reminder Time: ${state.settingsMockTime}</div></div>
              <button onclick="GBApp.toggleSettingSwitch('settingsMockReminder')" class="px-3 py-1 rounded-full font-bold text-[10px] ${state.settingsMockReminder ? "bg-emerald-600 text-white" : "gb-card"}">${state.settingsMockReminder ? "ON" : "OFF"}</button>
            </div>
            <div class="flex items-center justify-between p-2 rounded-xl gb-surface">
              <div><div class="font-extrabold">🔒 Fingerprint Lock (Demo)</div><div class="text-[10px] gb-text-muted">App security lock</div></div>
              <button onclick="GBApp.toggleSettingSwitch('settingsFingerprint')" class="px-3 py-1 rounded-full font-bold text-[10px] ${state.settingsFingerprint ? "bg-emerald-600 text-white" : "gb-card"}">${state.settingsFingerprint ? "ON" : "OFF"}</button>
            </div>
            <div class="flex items-center justify-between p-2 rounded-xl gb-surface">
              <div><div class="font-extrabold">🌐 Language Setting</div><div class="text-[10px] gb-text-muted">Bilingual Content</div></div>
              <span class="px-3 py-1 rounded-lg gb-surface-alt font-bold text-[10px] gb-text-accent">${state.settingsLanguage}</span>
            </div>
          </div>

          <!-- Backup & Restore (PDF 3 Page 17) -->
          <div class="gb-card p-3.5 space-y-2">
            <div class="font-extrabold gb-text-gold">☁️ Backup & Restore (Local Demo State)</div>
            <p class="text-[10px] gb-text-sub">Includes: Saved Words, Favourites, Mock Test Progress, Referral Progress, Continue Learning & History.</p>
            <div class="flex gap-2">
              <button onclick="GBApp.showToast('💾 Local Demo Backup Saved Successfully!')" class="flex-1 py-2 gb-btn-primary text-[11px]">Backup Now</button>
              <button onclick="GBApp.showToast('🔄 Local Demo State Restored!')" class="flex-1 py-2 gb-btn-outline text-[11px]">Restore</button>
            </div>
          </div>

          <!-- Logout Buttons (PDF 3 Page 17) -->
          <div class="space-y-2 pt-1">
            <button onclick="GBApp.logout(true)" class="w-full py-2.5 rounded-full bg-rose-900/50 border border-rose-500/50 text-rose-300 font-extrabold text-xs">
              Logout All Devices
            </button>
            <button onclick="GBApp.logout(false)" class="w-full py-3 rounded-full bg-rose-600 text-white font-extrabold text-xs shadow-lg">
              🔒 Logout My Device (Return to Common Login)
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // Mandatory Requirement #4: Strictly 5 Bottom Navigation Items (1. Home, 2. Library, 3. Reels, 4. Find Advocate, 5. Profile)
  function renderBottomNav() {
    if (!state.isLoggedIn || state.currentScreen === "auth" || state.currentScreen === "splash") return "";
    const navItems = [
      { id: "home", label: "Home", icon: "🏠", match: ["home", "public_law_hub", "public_law_detail", "categories_hub"] },
      { id: "bare_act_library", label: "Library", icon: "📚", match: ["bare_act_library", "bare_act_chapters", "bare_act_sections", "bare_act_reader", "act_detail", "chapter_sections"] },
      { id: "reels", label: "Reels", icon: "🎬", match: ["reels"] },
      { id: "find_advocate", label: "Find Advocate", icon: "👨‍⚖️", match: ["find_advocate", "internship_consulting_detail", "apply_internship_detail", "appointment_flow", "document_service_flow", "consulting"] },
      { id: "profile", label: "Profile", icon: "👤", match: ["profile", "update_general_profile", "create_advocate_profile", "create_student_profile", "view_profile_detail", "settings", "progress_tracking", "referral"] }
    ];

    return `
      <nav class="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[440px] z-30 px-2 py-1.5 border-t border-purple-500/30" style="background: var(--nav-bg); backdrop-filter: blur(12px);">
        <div class="grid grid-cols-5 gap-1">
          ${navItems
            .map((item) => {
              const isActive = item.match.includes(state.currentScreen);
              return `
                <button onclick="GBApp.navigateTo('${item.id}')" class="py-1.5 rounded-xl flex flex-col items-center justify-center transition-all ${
                  isActive ? "gb-tab-active" : "opacity-75 hover:opacity-100"
                }">
                  <span class="text-base leading-none">${item.icon}</span>
                  <span class="text-[10px] mt-1 leading-none">${item.label}</span>
                </button>
              `;
            })
            .join("")}
        </div>
      </nav>
    `;
  }

  function render() {
    const root = document.getElementById("app-root");
    if (!root) return;

    // Enforce Common Login Gate if not logged in
    if (!state.isLoggedIn && state.currentScreen !== "auth" && state.currentScreen !== "splash" && state.currentScreen !== "settings") {
      state.currentScreen = "auth";
    }

    let screenHtml = "";
    switch (state.currentScreen) {
      case "auth":
        screenHtml = renderAuthScreen();
        break;
      case "splash":
        screenHtml = renderSplashScreen();
        break;
      case "home":
        screenHtml = renderHomeScreen();
        break;
      case "categories_hub":
        screenHtml = renderCategoriesHubScreen();
        break;
      case "act_detail":
        screenHtml = renderActDetailScreen();
        break;
      case "chapter_sections":
        screenHtml = renderChapterSectionsScreen();
        break;
      case "public_law_hub":
        screenHtml = renderPublicLawHubScreen();
        break;
      case "public_law_detail":
        screenHtml = renderPublicLawDetailScreen();
        break;
      case "audio_player":
        screenHtml = renderAudioPlayerScreen();
        break;
      case "video_player":
        screenHtml = renderVideoPlayerScreen();
        break;
      case "slides_viewer":
        screenHtml = renderSlidesViewerScreen();
        break;
      case "pdf_viewer":
        screenHtml = renderPdfViewerScreen();
        break;
      case "mindmap_viewer":
        screenHtml = renderMindMapViewerScreen();
        break;
      case "handwriting_viewer":
        screenHtml = renderHandwritingViewerScreen();
        break;
      case "shabdawali":
        screenHtml = renderShabdawaliScreen();
        break;
      case "shabdawali_list":
        screenHtml = renderShabdawaliListScreen();
        break;
      case "shabdawali_detail":
        screenHtml = renderShabdawaliDetailScreen();
        break;
      case "kanooni_lines":
        screenHtml = renderKanooniLinesScreen();
        break;
      case "daily_10_words":
        screenHtml = renderDaily10WordsScreen();
        break;
      case "audio_learning":
        screenHtml = renderAudioLearningScreen();
        break;
      case "audio_learning_player":
        screenHtml = renderAudioLearningPlayerScreen();
        break;
      case "mcq_test":
        screenHtml = renderMcqTestScreen();
        break;
      case "bare_act_library":
        screenHtml = renderBareActLibraryScreen();
        break;
      case "bare_act_chapters":
        screenHtml = renderBareActChaptersScreen();
        break;
      case "bare_act_sections":
        screenHtml = renderBareActSectionsScreen();
        break;
      case "bare_act_reader":
        screenHtml = renderBareActReaderScreen();
        break;
      case "profile":
        screenHtml = renderProfileScreen();
        break;
      case "update_general_profile":
        screenHtml = renderUpdateGeneralProfileScreen();
        break;
      case "create_advocate_profile":
        screenHtml = renderCreateAdvocateProfileScreen();
        break;
      case "create_student_profile":
        screenHtml = renderCreateStudentProfileScreen();
        break;
      case "view_profile_detail":
        screenHtml = renderViewProfileDetailScreen();
        break;
      case "find_advocate":
        screenHtml = renderFindAdvocateScreen();
        break;
      case "internship_consulting_detail":
        screenHtml = renderInternshipConsultingDetailScreen();
        break;
      case "apply_internship_detail":
        screenHtml = renderApplyInternshipDetailScreen();
        break;
      case "appointment_flow":
        screenHtml = renderAppointmentFlowScreen();
        break;
      case "document_service_flow":
        screenHtml = renderDocumentServiceFlowScreen();
        break;
      case "consulting":
        screenHtml = renderConsultingScreen();
        break;
      case "advocate_diary":
        screenHtml = renderAdvocateDiaryScreen();
        break;
      case "student_notes":
        screenHtml = renderStudentNotesScreen();
        break;
      case "reels":
        screenHtml = renderReelsScreen();
        break;
      case "progress_tracking":
        screenHtml = renderProgressTrackingScreen();
        break;
      case "referral":
        screenHtml = renderReferralScreen();
        break;
      case "notifications":
        screenHtml = renderNotificationsScreen();
        break;
      case "saved_items":
        screenHtml = renderSavedItemsScreen();
        break;
      case "history_screen":
        screenHtml = renderHistoryScreen();
        break;
      case "folders":
        screenHtml = renderFoldersScreen();
        break;
      case "request_topic":
        screenHtml = renderRequestTopicScreen();
        break;
      case "chat_support":
        screenHtml = renderChatSupportScreen();
        break;
      case "settings":
        screenHtml = renderSettingsScreen();
        break;
      default:
        screenHtml = state.isLoggedIn ? renderHomeScreen() : renderAuthScreen();
    }

    root.className = "app-shell" + (state.videoLandscape ? " landscape-mode" : "");
    root.innerHTML = `
      ${renderTopBar()}
      ${screenHtml}
      ${renderBottomNav()}
      <div id="gb-toast-container"></div>
    `;
    renderToastOnly();
  }

  function initApp() {
    loadPersistedState();
    render();
  }

  if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", initApp);
  } else {
    initApp();
  }
})();
