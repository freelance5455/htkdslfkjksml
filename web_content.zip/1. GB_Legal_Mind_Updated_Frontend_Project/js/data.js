// GB LEGAL MIND — Complete Structured Demo Data & Scalable Content Schema (v2.0.0)
// NOTE: All legal texts, profiles, questions, chat messages, and media items below are clearly labelled DEMO CONTENT for frontend verification.

window.GB_DATA = {
  appMeta: {
    name: "GB LEGAL MIND",
    version: "v2.0.0 (Final Master Frontend)",
    packageId: "com.gblegalmind.app",
    subtitle: "Modern Smart Legal Learning Platform",
    founder: "Gulab Badshah — Legal Mind of India",
    taglineHindi: "अपने अधिकार जानो, हर इंसान के लिए आसान कानूनी जानकारी",
    modeNotice: "DEMO FRONTEND MODE — Common Login, Live Chat Demo, MCQ, Shabdawali, Bare Act Library & Profiles operate locally. Live SMS OTP, Google OAuth, Razorpay, Cloud Sync & Govt Verification are pending backend integration."
  },

  productionIntegrations: [
    { name: "Common Mobile OTP Login", status: "Demo Flow Active (OTP: 123456)", ready: false, note: "One common login for everyone. No real SMS sent; requires SMS Gateway / Firebase Auth in backend phase." },
    { name: "Google OAuth Sign-In", status: "Demo / Unavailable State", ready: false, note: "Honest demo notice shown; requires Google Cloud OAuth Client ID & SHA-1 fingerprint." },
    { name: "Consulting Live User-to-User Chat", status: "Local Demo Chat Active", ready: false, note: "Full chat UI, message send/receive, attachments & delete work locally; cross-device messaging requires WebSocket/Firebase backend." },
    { name: "Razorpay / Membership & Service Payments", status: "Demo Preview Only", ready: false, note: "No real money charged; requires Razorpay Order API & Webhook." },
    { name: "Bar Council / Govt Verification", status: "Pending / Demo Status", ready: false, note: "Profiles clearly show 'Verification Pending (Demo)' until backend verification is connected." },
    { name: "800+ Bare Acts & Admin Panel CMS", status: "Frontend Structure Ready (Demo Dataset)", ready: false, note: "Full 800+ Acts upload will be managed via future Admin Panel." }
  ],

  assets: {
    logo: "assets/images/logo_shield.jpg",
    splashLawyers: "assets/images/splash_lawyers.jpg",
    scHeroDay: "assets/images/sc_hero_day.jpg",
    bannerDhara2: "assets/images/banner_dhara2.jpg",
    bannerDhara3: "assets/images/banner_dhara3.jpg",
    bannerAudioLearning: "assets/images/banner_audio_learning.jpg",
    bannerMcqHero: "assets/images/banner_mcq_hero.jpg",
    bannerInternshipAdv: "assets/images/banner_internship_adv.jpg",
    bannerInternshipStu: "assets/images/banner_internship_stu.jpg",
    bannerPublicLaw: "assets/images/banner_public_law.jpg",
    cardBns: "assets/images/card_bns.jpg",
    cardBnss: "assets/images/card_bnss.jpg",
    cardBsa: "assets/images/card_bsa.jpg",
    cardConstitution: "assets/images/card_constitution.jpg",
    bns3dBook: "assets/images/bns_3d_book.jpg",
    playerScene184: "assets/images/player_scene_184.jpg",
    mindmapContract: "assets/images/mindmap_contract.jpg",
    reelSpeaker: "assets/images/reel_speaker.jpg",
    topicFir: "assets/images/topic_fir.jpg",
    topicBail: "assets/images/topic_bail.jpg",
    topicPolice: "assets/images/topic_police.jpg",
    topicSc: "assets/images/topic_sc.jpg",
    firHeroBanner: "assets/images/fir_hero_banner.jpg",
    slideDhara13Full: "assets/images/slide_dhara13_full.jpg",
    pdfQuizPage: "assets/images/pdf_quiz_page.jpg",
    premiumCrown: "assets/images/premium_crown.jpg",
    samplePdf: "assets/media/sample_legal_notes.pdf"
  },

  homeBanners: [
    {
      id: "banner_1",
      badge: "Bharatiya Nyaya Sanhita, 2023",
      title: "धारा 2: परिभाषाएं (Definitions)",
      subtitle: "कहानी और चित्रों के माध्यम से हर कानूनी शब्द का आसान अर्थ समझें",
      image: "assets/images/banner_dhara2.jpg",
      targetScreen: "act_detail",
      targetAct: "bns"
    },
    {
      id: "banner_2",
      badge: "Bharatiya Nyaya Sanhita, 2023",
      title: "धारा 3: सामान्य स्पष्टीकरण (General Explanations)",
      subtitle: "सामान्य आशय (Common Intention - धारा 3(5)) और संयुक्त दायित्व को उदाहरण से समझें",
      image: "assets/images/banner_dhara3.jpg",
      targetScreen: "act_detail",
      targetAct: "bns"
    },
    {
      id: "banner_3",
      badge: "Learn Law • Build a Better Tomorrow",
      title: "कानून को समझो, अधिकार को जानो",
      subtitle: "Students • Advocates • Common Citizens — सही ज्ञान, सही दिशा!",
      image: "assets/images/sc_hero_day.jpg",
      targetScreen: "bare_act_library"
    },
    {
      id: "banner_4",
      badge: "Public Law • नागरिक अधिकार",
      title: "FIR कैसे होती है? Zero FIR क्या है?",
      subtitle: "पुलिस स्टेशन में अपने कानूनी अधिकार और पूरी प्रक्रिया जानें (Demo)",
      image: "assets/images/fir_hero_banner.jpg",
      targetScreen: "public_law_hub",
      targetPublicTopic: "fir"
    }
  ],

  contentCategories: [
    { id: "audio", label: "Audio", labelHindi: "ऑडियो लेक्चर", icon: "🎧", demoCount: 125, desc: "सरल हिंदी और अंग्रेजी में ऑडियो स्पष्टीकरण (Demo)" },
    { id: "video", label: "Video", labelHindi: "वीडियो लेक्चर", icon: "▶️", demoCount: 320, desc: "विजुअल उदाहरण और केस स्टडी वीडियो (Demo)" },
    { id: "pdf", label: "PDF / Written Notes", labelHindi: "PDF / लिखित नोट्स", icon: "📄", demoCount: 240, desc: "पढ़ने और डाउनलोड करने योग्य लिखित नोट्स व प्रश्न (Demo)" },
    { id: "mindmap", label: "Mind Map", labelHindi: "माइंड मैप", icon: "🕸️", demoCount: 95, desc: "पूरी धारा और अध्याय का डायग्राम सारांश (Demo)" },
    { id: "slides", label: "Legal Slides", labelHindi: "लीगल स्लाइड्स", icon: "🖼️", demoCount: 180, desc: "पॉइंट-वाइज इलस्ट्रेटेड रिवीजन स्लाइड्स (Demo)" },
    { id: "handwriting", label: "Handwriting Notes", labelHindi: "हस्तलिखित नोट्स", icon: "✍️", demoCount: 110, desc: "क्लासरूम स्टाइल हस्तलिखित शॉर्ट नोट्स (Demo)" }
  ],

  acts: {
    bns: {
      id: "bns",
      shortTitle: "BNS",
      fullShortTitle: "BNS 2023",
      titleHindi: "भारतीय न्याय संहिता (BNS)",
      titleEnglish: "Bharatiya Nyaya Sanhita, 2023",
      actNumber: "Act No. 45 of 2023",
      enactedDate: "25 December 2023",
      effectiveDate: "1 July 2024",
      category: "Criminal Laws",
      popular: true,
      year: "2023",
      tagline: "Ek Surakshit, Nyayapurn aur Vikasit Bharat ke liye — [DEMO DATASET]",
      description: "BNS भारत का नया आपराधिक कानून है जो IPC की जगह लागू हुआ है। इसमें अपराधों और दंड का विस्तृत वर्णन है।",
      chaptersCount: 20,
      sectionsCount: 358,
      homeBadgeText: "20 Chapters • 358 Sections",
      coverImage: "assets/images/bns_3d_book.jpg",
      cardImage: "assets/images/card_bns.jpg",
      chapters: [
        {
          id: "bns_ch1",
          roman: "I",
          number: 1,
          title: "Chapter 1: Preliminary",
          titleHindi: "अध्याय 1: प्रारंभिक (Preliminary)",
          sectionsRange: "Sections 1 – 3",
          sections: [
            {
              id: "bns_s1",
              num: 1,
              code: "Section 1",
              oldRef: "Old IPC Sec. 1–5",
              title: "Short title, commencement and application",
              titleHindi: "धारा 1: संक्षिप्त नाम, प्रारंभ और लागू होना",
              duration: "15:30 / 20:00",
              progressPct: 75,
              statusBadge: "Current",
              thumbnail: "assets/images/card_bns.jpg",
              mediaAvailable: true,
              bareActTextHindi: "1. संक्षिप्त नाम, प्रारंभ और लागू होना.—\n(1) इस अधिनियम का नाम भारतीय न्याय संहिता, 2023 है।\n(2) यह उस तारीख को प्रवृत्त होगी जो केंद्रीय सरकार राजपत्र में अधिसूचना द्वारा नियत करे (1 जुलाई 2024)।\n(3) प्रत्येक व्यक्ति इस संहिता के उपबंधों के प्रतिकूल प्रत्येक कार्य या लोप के लिए, जिसका वह भारत के भीतर दोषी होगा, इसी संहिता के अधीन दंडनीय होगा।",
              saralTextHindi: "1. संक्षिप्त नाम और विस्तार (सरल भाषा).—\n(1) इस कानून का नाम भारतीय न्याय संहिता, 2023 (BNS) है।\n(2) यह कानून 1 जुलाई 2024 से पूरे भारत में लागू है।\n(3) भारत के अंदर अपराध करने वाले हर व्यक्ति पर यह कानून लागू होगा। यदि कोई भारतीय नागरिक विदेश में भी अपराध करता है, तो उस पर भी BNS लागू होगी।",
              bareActTextEnglish: "1. Short title, commencement and application.—\n(1) This Act may be called the Bharatiya Nyaya Sanhita, 2023.\n(2) It shall come into force on such date as the Central Government may appoint (1st July 2024).\n(3) Every person shall be liable to punishment under this Sanhita and not otherwise for every act or omission contrary to the provisions thereof, of which he shall be guilty within India.",
              saralTextEnglish: "1. Simple Explanation.—\n(1) This new criminal code is called Bharatiya Nyaya Sanhita (BNS), 2023, replacing IPC 1860.\n(2) It applies across the whole of India from 1 July 2024.\n(3) It also applies to Indian citizens committing offences outside India and offences on ships/aircraft registered in India.",
              summaryHindi: "भारतीय न्याय संहिता (BNS) 2023 पूरे भारत पर लागू होती है। यदि कोई भारतीय नागरिक भारत के बाहर भी अपराध करता है, तो उस पर भी BNS के प्रावधान लागू होंगे।",
              keyPoints: [
                "पूरे भारत के क्षेत्र में किए गए अपराधों पर लागू (Intra-territorial jurisdiction)।",
                "भारत के बाहर भारतीय नागरिक द्वारा या भारत में पंजीकृत जहाज/विमान पर किए गए अपराध पर भी लागू (Extra-territorial)।",
                "1 जुलाई 2024 से सम्पूर्ण भारत में प्रभावी (Demo Study Note)।"
              ]
            },
            {
              id: "bns_s2",
              num: 2,
              code: "Section 2",
              oldRef: "Old IPC Sec. 6–52A",
              title: "Definitions (परिभाषाएं)",
              titleHindi: "धारा 2: प्रमुख कानूनी परिभाषाएं (Historical & Core Definitions)",
              duration: "18:45 / 18:45",
              progressPct: 100,
              statusBadge: "Viewed",
              thumbnail: "assets/images/banner_dhara2.jpg",
              mediaAvailable: true,
              bareActTextHindi: "2. परिभाषाएं.— इस संहिता में, जब तक कि संदर्भ से अन्यथा अपेक्षित न हो,—\n(3) 'बालक' (Child) से अठारह वर्ष से कम आयु का कोई व्यक्ति अभिप्रेत है;\n(8) 'न्यायालय' (Court) से वह न्यायाधीश जो अकेले ही न्यायिकत: कार्य करने के लिए विधि द्वारा सशक्त किया गया है, अभिप्रेत है;\n(9) 'बेईमानी से' (Dishonestly) से किसी व्यक्ति को सदोष लाभ या अन्य व्यक्ति को सदोष हानि कारित करने का आशय अभिप्रेत है।",
              saralTextHindi: "2. परिभाषाएं (सरल भाषा).—\n• धारा 2(3) बालक: 18 साल से कम उम्र का कोई भी लड़का या लड़की 'बालक' माना जाएगा।\n• धारा 2(8) न्यायालय: फैसला सुनाने का कानूनी अधिकार रखने वाले जज या जजों की बेंच को कोर्ट कहते हैं।\n• धारा 2(9) बेईमानी: किसी को गलत तरीके से फायदा या नुकसान पहुंचाने के इरादे से काम करना।",
              bareActTextEnglish: "2. Definitions.— In this Sanhita, unless the context otherwise requires:\n(3) 'child' means any person below the age of eighteen years;\n(8) 'Court' means a Judge who is empowered by law to act judicially alone, or a body of Judges;\n(9) 'dishonestly' means doing anything with the intention of causing wrongful gain to one person or wrongful loss to another person.",
              saralTextEnglish: "2. Simple Explanation.—\nSection 2 consolidates 39 key legal definitions in alphabetical order (such as Child, Court, Consent, Dishonestly, Document, Electronic Record, Fraudulently, Gender, Good Faith, Injury, Offence) so citizens and lawyers can find all definitions in one place.",
              summaryHindi: "धारा 2 में वर्णमाला क्रम (Alphabetical Order) में 39 महत्वपूर्ण परिभाषाएं एकत्र की गई हैं ताकि कानून पढ़ना और खोजना आसान हो सके।",
              keyPoints: [
                "धारा 2(3): 'बालक' (Child) = 18 वर्ष से कम आयु का कोई भी व्यक्ति।",
                "धारा 2(8): 'न्यायालय' (Court) और धारा 2(9) 'बेईमानी से' (Dishonestly)।",
                "धारा 2(10): 'दस्तावेज' (Document) में इलेक्ट्रॉनिक और डिजिटल रिकॉर्ड भी शामिल।"
              ]
            },
            {
              id: "bns_s3",
              num: 3,
              code: "Section 3",
              oldRef: "Old IPC Sec. 34–38",
              title: "General Explanations & Common Intention (Sec 3(5))",
              titleHindi: "धारा 3: सामान्य स्पष्टीकरण एवं सामान्य आशय (धारा 3(5))",
              duration: "13:20 / 29:40",
              progressPct: 45,
              statusBadge: "Viewed",
              thumbnail: "assets/images/player_scene_184.jpg",
              mediaAvailable: true,
              bareActTextHindi: "3. सामान्य स्पष्टीकरण.—\nधारा 3(5): जब कोई आपराधिक कार्य कई व्यक्तियों द्वारा अपने सबके सामान्य आशय (Common Intention) को अग्रसर करने में किया जाता है, तब ऐसे व्यक्तियों में से प्रत्येक उस कार्य के लिए उसी प्रकार दायित्व के अधीन है, मानो वह कार्य अकेले उसी ने किया हो।",
              saralTextHindi: "3. सामान्य स्पष्टीकरण (सरल भाषा).—\nधारा 3(5) (पूर्व IPC धारा 34): जब 2 या अधिक लोग मिलकर एक ही इरादे (Common Intention) से कोई अपराध करते हैं, तो हर साथी बराबर का दोषी माना जाएगा—भले ही मुख्य वार किसी एक ने किया हो और दूसरा दरवाजे पर पहरा दे रहा हो।",
              bareActTextEnglish: "3. General Explanations.—\nSection 3(5): When a criminal act is done by several persons in furtherance of the common intention of all, each of such persons is liable for that act in the same manner as if it were done by him alone.",
              saralTextEnglish: "3. Simple Explanation.—\nSection 3(5) replaces the famous Section 34 of the old IPC. If multiple people act with a pre-arranged plan (common intention), every member of the group is equally guilty of the offence.",
              summaryHindi: "पहले जो IPC की धारा 34 (Common Intention) थी, वह अब BNS की धारा 3(5) में शामिल है।",
              keyPoints: [
                "सामान्य आशय (Common Intention) के लिए पूर्व सहमति (Meeting of Minds) आवश्यक।",
                "प्रत्येक सह-अभियुक्त मूल अपराध के लिए समान रूप से उत्तरदायी होगा।"
              ]
            }
          ]
        },
        {
          id: "bns_ch2",
          roman: "II",
          number: 2,
          title: "Chapter 2: Of Punishments",
          titleHindi: "अध्याय 2: दंडों के विषय में (Of Punishments)",
          sectionsRange: "Sections 4 – 13",
          sections: [
            {
              id: "bns_s4",
              num: 4,
              code: "Section 4",
              oldRef: "Old IPC Sec. 53",
              title: "Punishments (Including Community Service)",
              titleHindi: "धारा 4: दंड के 6 प्रकार (सामुदायिक सेवा सहित)",
              duration: "27:10 / 30:00",
              progressPct: 90,
              statusBadge: "Viewed",
              thumbnail: "assets/images/card_constitution.jpg",
              mediaAvailable: true,
              bareActTextHindi: "4. दंड.— वे दंड जिनके अधीन अपराधी इस संहिता के उपबंधों के अधीन हैं, ये हैं:—\n(क) मृत्यु;\n(ख) आजीवन कारावास;\n(ग) कारावास, जो दो भाँति का है, अर्थात्:— (1) कठिन, अर्थात् श्रम के साथ; (2) सादा;\n(घ) संपत्ति का समपहरण;\n(ङ) जुर्माना;\n(च) सामुदायिक सेवा (Community Service)।",
              saralTextHindi: "4. दंड के प्रकार (सरल भाषा).—\nBNS में अपराधियों के लिए 6 प्रकार की सजाएं तय हैं:\n1. फांसी (मृत्युदंड)\n2. उम्रकैद (आजीवन कारावास)\n3. जेल (कठोर या सादा कारावास)\n4. संपत्ति जब्त करना\n5. जुर्माना (Fine)\n6. सामुदायिक सेवा (Community Service - छोटे अपराधों में समाज सेवा का नया प्रावधान)।",
              bareActTextEnglish: "4. Punishments.— The punishments to which offenders are liable under the provisions of this Sanhita are:\n(a) Death;\n(b) Imprisonment for life;\n(c) Imprisonment, which is of two descriptions, namely: (1) Rigorous, that is, with hard labour; (2) Simple;\n(d) Forfeiture of property;\n(e) Fine;\n(f) Community Service.",
              saralTextEnglish: "4. Simple Explanation.—\nFor the first time in Indian criminal law, 'Community Service' has been introduced as a 6th statutory punishment for minor offences (like petty theft, public nuisance, defamation) to promote reformative justice.",
              summaryHindi: "BNS की धारा 4 में पहली बार छोटे अपराधों में सुधार के उद्देश्य से 'सामुदायिक सेवा' (Community Service) को छठे वैधानिक दंड के रूप में जोड़ा गया है।",
              keyPoints: [
                "कुल 6 प्रकार के दंड निर्धारित।",
                "सामुदायिक सेवा (Community Service) छोटे अपराधों में जेल की भीड़ कम करने और सुधार हेतु नया प्रावधान।"
              ]
            },
            {
              id: "bns_s13",
              num: 13,
              code: "Section 13",
              oldRef: "Old IPC Sec. 75",
              title: "Enhanced Punishment After Previous Conviction",
              titleHindi: "धारा 13: पूर्व दोषसिद्धि के पश्चात् वर्धित दण्ड",
              duration: "14:00 / 20:00",
              progressPct: 60,
              statusBadge: "Not Viewed",
              thumbnail: "assets/images/slide_dhara13_full.jpg",
              mediaAvailable: true,
              bareActTextHindi: "13. कतिपय अपराधों के लिए पूर्व दोषसिद्धि के पश्चात् वर्धित दंड.— जो कोई अध्याय 10 या अध्याय 17 के अधीन तीन वर्ष या अधिक के कारावास से दंडनीय किसी अपराध के लिए भारत में किसी न्यायालय द्वारा दोषसिद्ध किए जाने के पश्चात्, उन्हीं अध्यायों में से किसी के अधीन उतनी ही अवधि के कारावास से दंडनीय किसी अपराध का दोषी होगा, वह आजीवन कारावास से या दोनों में से किसी भाँति के कारावास से, जिसकी अवधि दस वर्ष तक की हो सकेगी, दंडित किया जाएगा।",
              saralTextHindi: "13. दोबारा अपराध पर बढ़ी हुई सजा (सरल भाषा).—\nयदि कोई व्यक्ति पहले चोरी, लूट या नकली नोट/सिक्के (अध्याय 10 या 17) के अपराध में 3 साल या अधिक की सजा पा चुका है और दोबारा वैसा ही अपराध करता है, तो कोर्ट उसे उम्रकैद या 10 साल तक की कड़ी सजा दे सकता है।",
              bareActTextEnglish: "13. Enhanced punishment for certain offences after previous conviction.— Whoever, having been convicted by a Court in India, of an offence punishable under Chapter X or Chapter XVII of this Sanhita with imprisonment of either description for a term of three years or upwards, shall be guilty of any offence punishable under either of those Chapters with like imprisonment for the like term, shall be subject for every such subsequent offence to imprisonment for life, or imprisonment of either description for a term which may extend to ten years.",
              saralTextEnglish: "13. Simple Explanation.—\nHabitual offenders who repeat serious property or currency offences (carrying 3+ years imprisonment) face enhanced punishment up to Life Imprisonment or 10 years rigorous imprisonment.",
              summaryHindi: "आदतन अपराधियों (Habitual Offenders) पर रोक लगाने के लिए धारा 13 में दोबारा अपराध करने पर उम्रकैद या 10 वर्ष तक कठोर कारावास का प्रावधान है।",
              keyPoints: [
                "अध्याय 10 (सिक्के/नोट/स्टाम्प) या अध्याय 17 (संपत्ति के विरुद्ध अपराध जैसे चोरी, लूट) पर लागू।",
                "दोबारा दोषी पाए जाने पर आजीवन कारावास या 10 वर्ष तक कारावास।"
              ]
            }
          ]
        },
        {
          id: "bns_ch3",
          roman: "III",
          number: 3,
          title: "Chapter 3: General Exceptions & Private Defence",
          titleHindi: "अध्याय 3: साधारण अपवाद एवं आत्मरक्षा का अधिकार",
          sectionsRange: "Sections 14 – 44",
          sections: [
            {
              id: "bns_s34",
              num: 34,
              code: "Section 34",
              oldRef: "Old IPC Sec. 96",
              title: "Things done in private defence",
              titleHindi: "धारा 34: प्राइवेट प्रतिरक्षा (आत्मरक्षा) में किए गए कार्य",
              duration: "16:00 / 20:00",
              progressPct: 50,
              statusBadge: "Not Viewed",
              thumbnail: "assets/images/card_bns.jpg",
              mediaAvailable: true,
              bareActTextHindi: "34. प्राइवेट प्रतिरक्षा में किए गए कार्य.— कोई बात अपराध नहीं है, जो प्राइवेट प्रतिरक्षा के अधिकार के प्रयोग में की जाती है।",
              saralTextHindi: "34. आत्मरक्षा का अधिकार (सरल भाषा).—\nअपनी या किसी दूसरे व्यक्ति की जान और संपत्ति बचाने के लिए आत्मरक्षा (Self-Defence) में किया गया आवश्यक कार्य कोई अपराध नहीं माना जाता।",
              bareActTextEnglish: "34. Things done in private defence.— Nothing is an offence which is done in the exercise of the right of private defence.",
              saralTextEnglish: "34. Simple Explanation.—\nActs done reasonably and proportionally to protect one's own body/property or another's from unlawful aggression are completely exempt from criminal liability.",
              summaryHindi: "धारा 34 से 44 तक शरीर और संपत्ति की आत्मरक्षा (Right of Private Defence) के नियम दिए गए हैं।",
              keyPoints: [
                "धारा 34: आत्मरक्षा में किया गया कार्य अपराध नहीं है।",
                "आत्मरक्षा में उतना ही बल प्रयोग वैध है जितना हमले को रोकने के लिए आवश्यक हो।"
              ]
            }
          ]
        },
        {
          id: "bns_ch6",
          roman: "VI",
          number: 6,
          title: "Chapter 6: Offences Affecting the Human Body",
          titleHindi: "अध्याय 6: मानव शरीर पर प्रभाव डालने वाले अपराध",
          sectionsRange: "Sections 100 – 146",
          sections: [
            {
              id: "bns_s103",
              num: 103,
              code: "Section 103",
              oldRef: "Old IPC Sec. 302",
              title: "Punishment for Murder & Mob Lynching",
              titleHindi: "धारा 103: हत्या के लिए दंड एवं मॉब लिंचिंग उपबंध",
              duration: "24:10 / 28:00",
              progressPct: 80,
              statusBadge: "Viewed",
              thumbnail: "assets/images/player_scene_184.jpg",
              mediaAvailable: true,
              bareActTextHindi: "103. हत्या के लिए दंड.—\n(1) जो कोई हत्या करेगा, वह मृत्यु से या आजीवन कारावास से दंडित किया जाएगा और जुर्माने के भी दायित्व के अधीन होगा।\n(2) जब पांच या अधिक व्यक्तियों का कोई समूह मिलकर मूलवंश, जाति या समुदाय, लिंग, जन्मस्थान, भाषा, वैयक्तिक विश्वास या किसी अन्य समान आधार पर हत्या कारित करता है, तो ऐसे समूह के प्रत्येक सदस्य को मृत्यु या आजीवन कारावास से दंडित किया जाएगा और जुर्माने के भी दायित्व के अधीन होगा।",
              saralTextHindi: "103. हत्या की सजा (सरल भाषा).—\n• धारा 103(1): जो पहले IPC की धारा 302 थी, वह अब BNS की धारा 103 है। हत्या करने पर फांसी या उम्रकैद और जुर्माने की सजा होगी।\n• धारा 103(2): यदि 5 या अधिक लोगों की भीड़ (Mob Lynching) मिलकर जाति, धर्म, भाषा आदि के आधार पर हत्या करती है, तो भीड़ के हर सदस्य को फांसी या उम्रकैद होगी।",
              bareActTextEnglish: "103. Punishment for murder.—\n(1) Whoever commits murder shall be punished with death or imprisonment for life, and shall also be liable to fine.\n(2) When a group of five or more persons acting in concert commits murder on the ground of race, caste or community, sex, place of birth, language, personal belief or any other similar ground each member of such group shall be punished with death or with imprisonment for life, and shall also be liable to fine.",
              saralTextEnglish: "103. Simple Explanation.—\nSection 103(1) replaces IPC Section 302 for Murder. Section 103(2) specifically codifies Mob Lynching by 5 or more persons as a distinct capital offence.",
              summaryHindi: "पूर्व IPC की धारा 302 अब BNS की धारा 103 है। इसमें उप-धारा (2) जोड़कर मॉब लिंचिंग के लिए सख्त दंड तय किया गया है।",
              keyPoints: [
                "धारा 103(1): हत्या के लिए मृत्युदंड या आजीवन कारावास + जुर्माना।",
                "धारा 103(2): 5 या अधिक व्यक्तियों के समूह द्वारा हत्या (Mob Lynching) पर अलग से स्पष्ट दंड।"
              ]
            }
          ]
        }
      ]
    },

    bnss: {
      id: "bnss",
      shortTitle: "BNSS",
      fullShortTitle: "BNSS 2023",
      titleHindi: "भारतीय नागरिक सुरक्षा संहिता (BNSS)",
      titleEnglish: "Bharatiya Nagarik Suraksha Sanhita, 2023",
      actNumber: "Act No. 46 of 2023",
      enactedDate: "25 December 2023",
      effectiveDate: "1 July 2024",
      category: "Criminal Laws",
      popular: true,
      year: "2023",
      tagline: "CrPC 1973 के स्थान पर नई प्रक्रिया संहिता — [DEMO DATASET]",
      description: "BNSS 2023 में FIR, Zero FIR, e-FIR, गिरफ्तारी, जमानत (Bail) और समयबद्ध ट्रायल की प्रक्रिया दी गई है।",
      chaptersCount: 39,
      sectionsCount: 531,
      homeBadgeText: "39 Chapters • 531 Sections",
      coverImage: "assets/images/card_bnss.jpg",
      cardImage: "assets/images/card_bnss.jpg",
      chapters: [
        {
          id: "bnss_ch13",
          roman: "XIII",
          number: 13,
          title: "Chapter 13: Information to Police & Investigation",
          titleHindi: "अध्याय 13: पुलिस को इत्तिला और अन्वेषण करने की उनकी शक्तियां",
          sectionsRange: "Sections 173 – 196",
          sections: [
            {
              id: "bnss_s173",
              num: 173,
              code: "Section 173",
              oldRef: "Old CrPC Sec. 154",
              title: "Information in Cognizable Cases (FIR, Zero FIR & e-FIR)",
              titleHindi: "धारा 173: संज्ञेय मामलों में इत्तिला (FIR, Zero FIR एवं e-FIR)",
              duration: "19:30 / 22:00",
              progressPct: 85,
              statusBadge: "Current",
              thumbnail: "assets/images/fir_hero_banner.jpg",
              mediaAvailable: true,
              bareActTextHindi: "173. संज्ञेय मामलों में इत्तिला.—\n(1) संज्ञेय अपराध के किए जाने से संबंधित प्रत्येक इत्तिला, उस क्षेत्र के होने के विचार के बिना जहाँ अपराध किया गया है (Zero FIR), मौखिक या इलेक्ट्रॉनिक संसूचना द्वारा दिए जाने पर पुलिस थाने के भारसाधक अधिकारी द्वारा लेखबद्ध की जाएगी। इलेक्ट्रॉनिक सूचना देने वाले व्यक्ति द्वारा 3 दिन के भीतर हस्ताक्षर किए जाने पर उसे अभिलेख पर लिया जाएगा।\n(2) इत्तिला की एक प्रति सूचना देने वाले को तत्काल निःशुल्क दी जाएगी।",
              saralTextHindi: "173. FIR, Zero FIR और e-FIR (सरल भाषा).—\n• अब अपराध किसी भी क्षेत्र में हुआ हो, आप किसी भी पुलिस थाने में 'Zero FIR' दर्ज करा सकते हैं।\n• आप ऑनलाइन / इलेक्ट्रॉनिक तरीके से भी 'e-FIR' भेज सकते हैं और 3 दिन के अंदर थाने में हस्ताक्षर कर उसे पक्का करा सकते हैं।\n• FIR की कॉपी पाना शिकायतकर्ता का मुफ्त कानूनी अधिकार है।",
              bareActTextEnglish: "173. Information in cognizable cases.—\n(1) Every information relating to the commission of a cognizable offence, irrespective of the area where the offence is committed, may be given orally or by electronic communication to an officer in charge of a police station (Zero FIR & e-FIR signed within 3 days).\n(2) A copy of the information as recorded shall be given forthwith, free of cost, to the informant or the victim.",
              saralTextEnglish: "173. Simple Explanation.—\nBNSS Section 173 replaces CrPC Section 154 and gives statutory recognition to Zero FIR (filing at any police station regardless of jurisdiction) and e-FIR (electronic filing signed within 3 days).",
              summaryHindi: "BNSS धारा 173 में Zero FIR और e-FIR को स्पष्ट वैधानिक दर्जा दिया गया है तथा पीड़ित को निःशुल्क FIR कॉपी का अधिकार है।",
              keyPoints: [
                "Zero FIR: किसी भी पुलिस स्टेशन में FIR दर्ज कराने का अधिकार।",
                "e-FIR: इलेक्ट्रॉनिक माध्यम से भेजी गई शिकायत पर 3 दिन में हस्ताक्षर करने पर FIR दर्ज।",
                "FIR दर्ज न होने पर धारा 173(4) के तहत SP और मजिस्ट्रेट के पास आवेदन।"
              ]
            },
            {
              id: "bnss_s482",
              num: 482,
              code: "Section 482",
              oldRef: "Old CrPC Sec. 438",
              title: "Direction for Grant of Bail to Person Apprehending Arrest",
              titleHindi: "धारा 482: गिरफ्तारी की आशंका वाले व्यक्ति को अग्रिम जमानत (Anticipatory Bail)",
              duration: "16:45 / 20:00",
              progressPct: 60,
              statusBadge: "Viewed",
              thumbnail: "assets/images/topic_bail.jpg",
              mediaAvailable: true,
              bareActTextHindi: "482. गिरफ्तारी की आशंका करने वाले व्यक्ति की जमानत के लिए निदेश.—\n(1) जब किसी व्यक्ति को यह विश्वास करने का कारण है कि उसको किसी अजमानतीय अपराध के किए जाने के अभियोग में गिरफ्तार किया जा सकता है, तो वह इस धारा के अधीन उच्च न्यायालय या सेशन न्यायालय में आवेदन कर सकता है कि ऐसी गिरफ्तारी की स्थिति में उसको जमानत पर छोड़ दिया जाए।",
              saralTextHindi: "482. अग्रिम जमानत / Anticipatory Bail (सरल भाषा).—\nयदि किसी व्यक्ति को आशंका है कि किसी गैर-जमानती केस में पुलिस उसे गिरफ्तार कर सकती है, तो वह गिरफ्तारी से बचने के लिए पहले ही सेशन कोर्ट (Sessions Court) या हाई कोर्ट (High Court) से धारा 482 के तहत अग्रिम जमानत ले सकता है।",
              bareActTextEnglish: "482. Direction for grant of bail to person apprehending arrest.—\n(1) When any person has reason to believe that he may be arrested on an accusation of having committed a non-bailable offence, he may apply to the High Court or the Court of Session for a direction under this section; and that Court may, if it thinks fit, direct that in the event of such arrest, he shall be released on bail.",
              saralTextEnglish: "482. Simple Explanation.—\nReplaces old CrPC Section 438. Allows a person fearing arrest in a non-bailable case to seek pre-arrest (anticipatory) bail from the Sessions Court or High Court.",
              summaryHindi: "गिरफ्तारी से पहले सेशन कोर्ट या हाई कोर्ट से अग्रिम जमानत (Anticipatory Bail) प्राप्त करने की प्रक्रिया अब BNSS की धारा 482 में है।",
              keyPoints: [
                "पूर्व CrPC धारा 438 अब BNSS धारा 482 है।",
                "सेशन कोर्ट या हाई कोर्ट शर्तों के साथ अग्रिम जमानत दे सकता है।"
              ]
            }
          ]
        }
      ]
    },

    bsa: {
      id: "bsa",
      shortTitle: "BSA",
      fullShortTitle: "BSA 2023",
      titleHindi: "भारतीय साक्ष्य अधिनियम (BSA)",
      titleEnglish: "Bharatiya Sakshya Adhiniyam, 2023",
      actNumber: "Act No. 47 of 2023",
      enactedDate: "25 December 2023",
      effectiveDate: "1 July 2024",
      category: "Criminal Laws",
      popular: true,
      year: "2023",
      tagline: "डिजिटल और इलेक्ट्रॉनिक साक्ष्य कानून — [DEMO DATASET]",
      description: "Indian Evidence Act 1872 के स्थान पर लागू नया कानून जिसमें डिजिटल रिकॉर्ड को प्राथमिक साक्ष्य माना गया है।",
      chaptersCount: 12,
      sectionsCount: 170,
      homeBadgeText: "12 Chapters • 170 Sections",
      coverImage: "assets/images/card_bsa.jpg",
      cardImage: "assets/images/card_bsa.jpg",
      chapters: [
        {
          id: "bsa_ch2",
          roman: "II",
          number: 2,
          title: "Chapter 2: Closely Connected Facts, Confessions & Electronic Evidence",
          titleHindi: "अध्याय 2: तथ्यों की सुसंगति, संस्वीकृति (धारा 22–24) एवं इलेक्ट्रॉनिक साक्ष्य (धारा 63)",
          sectionsRange: "Sections 3 – 63",
          sections: [
            {
              id: "bsa_s22",
              num: 22,
              code: "Section 22 – 24",
              oldRef: "Old Evidence Act Sec. 24–30",
              title: "Confessions (संस्वीकृति / स्वीकारोक्ति के नियम)",
              titleHindi: "धारा 22–24: संस्वीकृति (Confession) कब मान्य और कब अमान्य होती है",
              duration: "15:00 / 18:00",
              progressPct: 70,
              statusBadge: "Viewed",
              thumbnail: "assets/images/card_bsa.jpg",
              mediaAvailable: true,
              bareActTextHindi: "धारा 22–24 (संस्वीकृति / Confession): अभियुक्त द्वारा की गई कोई संस्वीकृति यदि धमकी, उत्प्रेरणा या प्रपीड़न द्वारा कराई गई है तो वह विसंगत है। पुलिस अधिकारी के समक्ष की गई संस्वीकृति अभियुक्त के विरुद्ध साबित नहीं की जाएगी, सिवाय उस भाग के जिससे किसी तथ्य का पता चलता है (Discovery of Fact)।",
              saralTextHindi: "सरल भाषा में संस्वीकृति (Confession): पुलिस हिरासत या डर/दबाव में लिया गया जुर्म का इकबालिया बयान कोर्ट में सबूत नहीं माना जाता। केवल मजिस्ट्रेट के सामने बिना किसी दबाव के दी गई स्वीकारोक्ति या जिस बयान से कोई वस्तु/हथियार बरामद हो, वही मान्य होता है।",
              bareActTextEnglish: "Sections 22–24 (Confessions): A confession caused by inducement, threat, coercion or promise is irrelevant. No confession made to a police officer shall be proved as against a person accused of any offence, except to the extent it leads to the discovery of a fact.",
              saralTextEnglish: "Simple Explanation: Confessions made under coercion or directly to police officers are inadmissible, protecting citizens from forced confessions.",
              summaryHindi: "भारतीय साक्ष्य अधिनियम में स्वीकारोक्ति (Confession) से जुड़े नियम बताते हैं कि कौन सी स्वीकारोक्ति कानूनी रूप से मान्य होगी।",
              keyPoints: [
                "धमकी या दबाव में की गई स्वीकारोक्ति अमान्य है।",
                "मजिस्ट्रेट के समक्ष दर्ज स्वैच्छिक संस्वीकृति मान्य होती है।"
              ]
            },
            {
              id: "bsa_s63",
              num: 63,
              code: "Section 63",
              oldRef: "Old Evidence Act Sec. 65B",
              title: "Admissibility of Electronic Records",
              titleHindi: "धारा 63: इलेक्ट्रॉनिक अभिलेखों की ग्राह्यता (Electronic Evidence Certificate)",
              duration: "17:10 / 20:00",
              progressPct: 65,
              statusBadge: "Current",
              thumbnail: "assets/images/card_bsa.jpg",
              mediaAvailable: true,
              bareActTextHindi: "63. इलेक्ट्रॉनिक अभिलेखों की ग्राह्यता.— किसी इलेक्ट्रॉनिक अभिलेख में अंतर्विष्ट कोई सूचना, जो कागज पर मुद्रित है या किसी ऑप्टिकल या चुंबकीय मीडिया या सेमीकंडक्टर मेमोरी में संग्रहीत, रिकॉर्ड या नकल की गई है, धारा 63(4) के प्रमाणपत्र के साथ न्यायालय में दस्तावेज और साक्ष्य के रूप में ग्राह्य होगी।",
              saralTextHindi: "63. डिजिटल सबूत (सरल भाषा).—\nमोबाइल चैट, कॉल रिकॉर्डिंग, ईमेल, CCTV फुटेज और पेनड्राइव डेटा को कोर्ट में सबूत के तौर पर पेश करने के लिए BSA की धारा 63 (जो पहले धारा 65B थी) का सर्टिफिकेट लगाना जरूरी है।",
              bareActTextEnglish: "63. Admissibility of electronic records.— Any information contained in an electronic record which is printed on paper, stored, recorded or copied in optical or magnetic media or semiconductor memory shall be deemed to be a document and admissible in evidence subject to the certificate under Section 63(4).",
              saralTextEnglish: "63. Simple Explanation.—\nReplaces Section 65B of the old Evidence Act. Electronic records (WhatsApp, emails, CCTV, server logs) are admissible when accompanied by the Section 63(4) integrity certificate.",
              summaryHindi: "मोबाइल, कंप्यूटर, सीसीटीवी, ईमेल और डिजिटल रिकॉर्ड को कोर्ट में साबित करने के लिए BSA की धारा 63 (पूर्व धारा 65B) का प्रमाणपत्र अनिवार्य है।",
              keyPoints: [
                "धारा 57 के तहत इलेक्ट्रॉनिक व डिजिटल रिकॉर्ड प्राथमिक साक्ष्य (Primary Evidence) हैं।",
                "धारा 63(4) के तहत डिवाइस के प्रभारी और विशेषज्ञ का प्रमाणपत्र लगता है।"
              ]
            }
          ]
        }
      ]
    },

    constitution: {
      id: "constitution",
      shortTitle: "Constitution",
      fullShortTitle: "Constitution of India",
      titleHindi: "भारत का संविधान",
      titleEnglish: "Constitution of India, 1950",
      actNumber: "Supreme Law of India",
      enactedDate: "26 November 1949",
      effectiveDate: "26 January 1950",
      category: "Constitutional",
      popular: true,
      year: "1950",
      tagline: "मौलिक अधिकार, कर्तव्य और संवैधानिक उपचार — [DEMO DATASET]",
      description: "भारत का सर्वोच्च कानून जो नागरिकों को मौलिक अधिकार (अनुच्छेद 12-35) और रिट अधिकारिता प्रदान करता है।",
      chaptersCount: 25,
      sectionsCount: 448,
      homeBadgeText: "25 Parts • 448 Articles",
      coverImage: "assets/images/card_constitution.jpg",
      cardImage: "assets/images/card_constitution.jpg",
      chapters: [
        {
          id: "const_p3",
          roman: "III",
          number: 3,
          title: "Part III: Fundamental Rights",
          titleHindi: "भाग 3: मौलिक अधिकार (Articles 12 – 35)",
          sectionsRange: "Articles 12 – 35",
          sections: [
            {
              id: "const_a21",
              num: 21,
              code: "Article 21 & 22",
              oldRef: "Part III Fundamental Rights",
              title: "Protection of Life, Personal Liberty & Rights on Arrest",
              titleHindi: "अनुच्छेद 21 व 22: प्राण और दैहिक स्वतंत्रता तथा गिरफ्तारी से संरक्षण",
              duration: "21:00 / 25:00",
              progressPct: 100,
              statusBadge: "Viewed",
              thumbnail: "assets/images/sc_hero_day.jpg",
              mediaAvailable: true,
              bareActTextHindi: "अनुच्छेद 21. प्राण और दैहिक स्वतंत्रता का संरक्षण.— किसी व्यक्ति को उसके प्राण या दैहिक स्वतंत्रता से विधि द्वारा स्थापित प्रक्रिया के अनुसार ही वंचित किया जाएगा, अन्यथा नहीं।\nअनुच्छेद 22. कुछ दशाओं में गिरफ्तारी और निरोध से संरक्षण.— (1) गिरफ्तार किए गए व्यक्ति को गिरफ्तारी के कारणों से अवगत कराया जाएगा और अपनी रुचि के विधि व्यवसायी से परामर्श का अधिकार होगा। (2) 24 घंटे के भीतर निकटतम मजिस्ट्रेट के समक्ष पेश किया जाएगा।",
              saralTextHindi: "अनुच्छेद 21 और 22 (सरल भाषा).—\n• अनुच्छेद 21 हर व्यक्ति को सम्मान के साथ जीने, निजता और आजादी का मौलिक अधिकार देता है।\n• अनुच्छेद 22 के अनुसार पुलिस बिना कारण बताए किसी को गिरफ्तार नहीं कर सकती, गिरफ्तार व्यक्ति को अपने वकील से मिलने का हक है और 24 घंटे में मजिस्ट्रेट के सामने पेश करना अनिवार्य है।",
              bareActTextEnglish: "Article 21: No person shall be deprived of his life or personal liberty except according to procedure established by law.\nArticle 22: Guarantees the right to be informed of grounds of arrest, right to consult and be defended by a legal practitioner of choice, and production before the nearest Magistrate within 24 hours.",
              saralTextEnglish: "Simple Explanation: Article 21 is the heart of Fundamental Rights (Right to Life with Dignity, Privacy, Speedy Trial, Legal Aid), and Article 22 protects against arbitrary arrest.",
              summaryHindi: "अनुच्छेद 21 सम्मानपूर्वक जीवन जीने का अधिकार देता है और अनुच्छेद 22 मनमानी गिरफ्तारी से प्रत्येक व्यक्ति की रक्षा करता है।",
              keyPoints: [
                "गिरफ्तारी के 24 घंटे के भीतर मजिस्ट्रेट के सामने पेश करना संवैधानिक बाध्यता है।",
                "अनुच्छेद 32 (सुप्रीम कोर्ट) और अनुच्छेद 226 (हाई कोर्ट) के तहत 5 प्रकार की रिट याचिकाएं।"
              ]
            }
          ]
        }
      ]
    }
  },

  additionalBareActs: [
    {
      id: "ipc_1860",
      shortTitle: "IPC 1860",
      titleHindi: "भारतीय दंड संहिता, 1860 (पूर्व कानून)",
      titleEnglish: "Indian Penal Code, 1860",
      actNumber: "Act No. 45 of 1860",
      year: "1860",
      category: "Criminal Laws",
      popular: true,
      chaptersCount: 23,
      sectionsCount: 511,
      chapters: [
        {
          id: "ipc_ch16",
          roman: "XVI",
          number: 16,
          title: "Chapter XVI: Of Offences Affecting the Human Body",
          titleHindi: "अध्याय 16: मानव शरीर पर प्रभाव डालने वाले अपराध (धारा 299 – 377)",
          sectionsRange: "Sections 299 – 377",
          sections: [
            {
              id: "ipc_s302",
              num: 302,
              code: "Section 302",
              oldRef: "Now BNS Section 103",
              title: "Punishment for Murder (Old IPC)",
              titleHindi: "धारा 302: हत्या के लिए दंड (अब BNS धारा 103)",
              duration: "18:45",
              bareActTextHindi: "धारा 302. हत्या के लिए दंड.— जो कोई हत्या करेगा, वह मृत्यु से, या आजीवन कारावास से दंडित किया जाएगा, और जुर्माने से भी दंडनीय होगा।",
              saralTextHindi: "सरल भाषा: पुरानी आईपीसी की धारा 302 में हत्या की सजा फांसी या उम्रकैद थी। 1 जुलाई 2024 से नए कानून BNS में यह धारा 103 बन गई है।",
              bareActTextEnglish: "Section 302: Whoever commits murder shall be punished with death, or imprisonment for life, and shall also be liable to fine.",
              saralTextEnglish: "Simple Explanation: Old IPC Section 302 corresponds to Section 103 of the Bharatiya Nyaya Sanhita (BNS), 2023.",
              summaryHindi: "पुराने मामलों के तुलनात्मक अध्ययन हेतु IPC 1860 की धारा 302 (अब BNS धारा 103) दी गई है।",
              keyPoints: ["1 जुलाई 2024 से पहले के अपराधों पर पुरानी IPC लागू रहती है।", "नए अपराधों पर BNS धारा 103 लागू होती है।"]
            }
          ]
        }
      ]
    },
    {
      id: "ica_1872",
      shortTitle: "Contract Act 1872",
      titleHindi: "भारतीय संविदा अधिनियम, 1872",
      titleEnglish: "Indian Contract Act, 1872",
      actNumber: "Act No. 9 of 1872",
      year: "1872",
      category: "Civil & Contract",
      popular: true,
      chaptersCount: 11,
      sectionsCount: 266,
      chapters: [
        {
          id: "ica_ch1",
          roman: "I",
          number: 1,
          title: "Chapter I & II: Of Contracts, Voidable Contracts and Void Agreements",
          titleHindi: "अध्याय 1 व 2: प्रस्ताव, स्वीकृति और वैध संविदा (धारा 1 – 30)",
          sectionsRange: "Sections 1 – 30",
          sections: [
            {
              id: "ica_s10",
              num: 10,
              code: "Section 10",
              oldRef: "Core Contract Provision",
              title: "What agreements are contracts (वैध संविदा की शर्तें)",
              titleHindi: "धारा 10: कौन से करार संविदा (Contract) हैं",
              duration: "14:30",
              bareActTextHindi: "धारा 10: सब करार संविदा हैं यदि वे संविदा करने के लिए सक्षम पक्षकारों की स्वतंत्र सम्मति (Free Consent) से, विधिपूर्ण प्रतिफल (Lawful Consideration) के लिए और विधिपूर्ण उद्देश्य से किए गए हैं और एतद्द्वारा अभिव्यक्त रूप से शून्य घोषित नहीं किए गए हैं।",
              saralTextHindi: "धारा 10 (सरल भाषा): कोई भी समझौता (Agreement) तभी कानूनी कॉन्ट्रैक्ट बनता है जब: (1) दोनों पक्ष बालिग (18+) और समझदार हों, (2) सहमति बिना किसी दबाव या धोखे के हो, और (3) लेन-देन व उद्देश्य कानूनी हो।",
              bareActTextEnglish: "Section 10: All agreements are contracts if they are made by the free consent of parties competent to contract, for a lawful consideration and with a lawful object, and are not hereby expressly declared to be void.",
              saralTextEnglish: "Simple Explanation: An agreement becomes a legally enforceable contract only when made by competent parties (18+, sound mind) with free consent, lawful consideration, and lawful object.",
              summaryHindi: "किसी भी समझौते (Agreement) को कानूनन लागू करवाने के लिए धारा 10 की शर्तें पूरी होनी चाहिए।",
              keyPoints: ["पक्षकार वयस्क (18+) और स्वस्थ चित्त का हो (धारा 11)।", "सहमति प्रपीड़न, कपट या भूल से मुक्त हो (धारा 14)।"]
            }
          ]
        }
      ]
    },
    {
      id: "ni_1881",
      shortTitle: "NI Act 1881",
      titleHindi: "परक्राम्य लिखत अधिनियम, 1881 (Cheque Bounce)",
      titleEnglish: "Negotiable Instruments Act, 1881",
      actNumber: "Act No. 26 of 1881",
      year: "1881",
      category: "Civil & Contract",
      popular: true,
      chaptersCount: 17,
      sectionsCount: 148,
      chapters: [
        {
          id: "ni_ch17",
          roman: "XVII",
          number: 17,
          title: "Chapter XVII: Dishonour of Cheques (Section 138)",
          titleHindi: "अध्याय 17: चेक अनादरण / चेक बाउंस (धारा 138 – 148)",
          sectionsRange: "Sections 138 – 148",
          sections: [
            {
              id: "ni_s138",
              num: 138,
              code: "Section 138",
              oldRef: "Cheque Bounce Law",
              title: "Dishonour of cheque for insufficiency of funds",
              titleHindi: "धारा 138: खाते में अपर्याप्त राशि के कारण चेक बाउंस होना",
              duration: "16:00",
              bareActTextHindi: "धारा 138: जब किसी वैध ऋण या दायित्व के भुगतान हेतु जारी किया गया चेक अपर्याप्त फंड के कारण बैंक द्वारा वापस कर दिया जाता है, तो बैंक मेमो मिलने के 30 दिन के भीतर कानूनी नोटिस देना होता है। नोटिस मिलने के 15 दिन में भुगतान न होने पर 1 माह के भीतर मजिस्ट्रेट कोर्ट में परिवाद दायर किया जा सकता है।",
              saralTextHindi: "धारा 138 (सरल भाषा): चेक बाउंस होने पर बैंक रिटर्न मेमो मिलने के 30 दिन के अंदर वकील के माध्यम से डिमांड नोटिस भेजें। यदि सामने वाला 15 दिन में पैसा न दे, तो अगले 30 दिन में कोर्ट में धारा 138 का केस दायर करें। इसमें 2 साल तक की सजा या चेक राशि के दोगुने तक जुर्माने का प्रावधान है।",
              bareActTextEnglish: "Section 138: Dishonour of cheque for insufficiency of funds is punishable with imprisonment up to 2 years, or fine up to twice the cheque amount, or both. Requires Legal Notice within 30 days of return memo and 15 days waiting period.",
              saralTextEnglish: "Simple Explanation: Follow the 30-15-30 day timeline for Cheque Bounce cases: 30 days to send legal notice, 15 days waiting time for payment, and 30 days to file the complaint in Court.",
              summaryHindi: "चेक बाउंस होने पर 30 दिन में लीगल नोटिस भेजें, 15 दिन इंतजार करें और भुगतान न मिलने पर अगले 30 दिन में कोर्ट में धारा 138 का केस फाइल करें।",
              keyPoints: ["2 वर्ष तक कारावास या चेक राशि के दोगुने तक जुर्माना।", "धारा 143A के तहत 20% अंतरिम मुआवजा (Interim Compensation)।"]
            }
          ]
        }
      ]
    },
    {
      id: "dv_2005",
      shortTitle: "DV Act 2005",
      titleHindi: "घरेलू हिंसा से महिला संरक्षण अधिनियम, 2005",
      titleEnglish: "Protection of Women from Domestic Violence Act, 2005",
      actNumber: "Act No. 43 of 2005",
      year: "2005",
      category: "Family & Personal",
      popular: true,
      chaptersCount: 5,
      sectionsCount: 37,
      chapters: [
        {
          id: "dv_ch4",
          roman: "IV",
          number: 4,
          title: "Chapter IV: Procedure for Obtaining Orders of Relief",
          titleHindi: "अध्याय 4: संरक्षण, निवास एवं भरण-पोषण आदेश (धारा 12 – 23)",
          sectionsRange: "Sections 12 – 23",
          sections: [
            {
              id: "dv_s12",
              num: 12,
              code: "Section 12 & 17",
              oldRef: "Domestic Violence Reliefs",
              title: "Application to Magistrate & Right to Reside in Shared Household",
              titleHindi: "धारा 12 एवं 17: मजिस्ट्रेट को आवेदन तथा साझा गृहस्थी में निवास का अधिकार",
              duration: "15:10",
              bareActTextHindi: "धारा 12: व्यथित महिला या संरक्षण अधिकारी मजिस्ट्रेट को संरक्षण आदेश, निवास आदेश (धारा 19) और आर्थिक अनुतोष (धारा 20) के लिए आवेदन प्रस्तुत कर सकता है। धारा 17 प्रत्येक महिला को साझा घर (Shared Household) में रहने का कानूनी अधिकार देती है।",
              saralTextHindi: "सरल भाषा: घरेलू हिंसा (शारीरिक, मानसिक या आर्थिक प्रताड़ना) होने पर महिला को ससुराल या साझा घर से निकाला नहीं जा सकता (धारा 17) और मजिस्ट्रेट कोर्ट से तुरंत सुरक्षा व मासिक खर्चे का आदेश मिल सकता है।",
              bareActTextEnglish: "Section 12 empowers an aggrieved woman or Protection Officer to apply to the Magistrate for Protection Orders (Sec 18), Residence Orders (Sec 19), Monetary Relief (Sec 20) and Custody Orders (Sec 21).",
              saralTextEnglish: "Simple Explanation: Guarantees every woman the right to reside in the shared household and obtain immediate protection and maintenance orders from a Magistrate.",
              summaryHindi: "घरेलू हिंसा होने पर महिला को घर से निकाला नहीं जा सकता (धारा 17) और कोर्ट तुरंत अंतरिम सुरक्षा व भरण-पोषण आदेश दे सकता है।",
              keyPoints: ["धारा 17: साझा घर में रहने का अधिकार।", "धारा 18-22: सुरक्षा, निवास, मासिक भत्ता और मुआवजा आदेश।"]
            }
          ]
        }
      ]
    },
    {
      id: "cpa_2019",
      shortTitle: "Consumer Act 2019",
      titleHindi: "उपभोक्ता संरक्षण अधिनियम, 2019",
      titleEnglish: "Consumer Protection Act, 2019",
      actNumber: "Act No. 35 of 2019",
      year: "2019",
      category: "Civil & Contract",
      popular: false,
      chaptersCount: 8,
      sectionsCount: 107,
      chapters: [
        {
          id: "cpa_ch4",
          roman: "IV",
          number: 4,
          title: "Chapter IV: Consumer Disputes Redressal Commission",
          titleHindi: "अध्याय 4: जिला, राज्य एवं राष्ट्रीय उपभोक्ता आयोग (धारा 28 – 73)",
          sectionsRange: "Sections 28 – 73",
          sections: [
            {
              id: "cpa_s34",
              num: 34,
              code: "Section 34 & 35",
              oldRef: "E-Commerce & Online Filing",
              title: "Jurisdiction of District Commission & E-Filing",
              titleHindi: "धारा 34 व 35: उपभोक्ता शिकायत और ई-कॉमर्स नियम",
              duration: "13:00",
              bareActTextHindi: "धारा 34 एवं 35: उपभोक्ता अब अपने निवास या कार्यस्थल के जिला उपभोक्ता आयोग में ऑनलाइन (E-Daakhil) शिकायत दर्ज कर सकता है। ई-कॉमर्स कंपनियों और भ्रामक विज्ञापनों पर भी यह अधिनियम लागू होता है।",
              saralTextHindi: "सरल भाषा: दुकानदार या ऑनलाइन शॉपिंग कंपनी द्वारा धोखा देने या खराब सामान देने पर ग्राहक अपने ही जिले के उपभोक्ता फोरम में या घर बैठे ऑनलाइन शिकायत कर मुआवजा पा सकता है।",
              bareActTextEnglish: "Consumers can file complaints online from their place of residence or work. Covers e-commerce platforms, unfair trade practices, and product liability.",
              saralTextEnglish: "Simple Explanation: Enables consumers to file complaints at their own place of residence and holds e-commerce platforms accountable.",
              summaryHindi: "दुकानदार या ऑनलाइन शॉपिंग कंपनी द्वारा धोखा देने या खराब सामान देने पर उपभोक्ता घर बैठे केस दर्ज कर मुआवजा पा सकता है।",
              keyPoints: ["ग्राहक अपने जिले के आयोग में शिकायत कर सकता है।", "ई-कॉमर्स कंपनियों की जवाबदेही तय।"]
            }
          ]
        }
      ]
    },
    {
      id: "rti_2005",
      shortTitle: "RTI Act 2005",
      titleHindi: "सूचना का अधिकार अधिनियम, 2005",
      titleEnglish: "Right to Information Act, 2005",
      actNumber: "Act No. 22 of 2005",
      year: "2005",
      category: "Constitutional",
      popular: false,
      chaptersCount: 6,
      sectionsCount: 31,
      chapters: [
        {
          id: "rti_ch2",
          roman: "II",
          number: 2,
          title: "Chapter II: Right to Information & Obligations of Public Authorities",
          titleHindi: "अध्याय 2: सूचना का अधिकार और 30 दिन की समय-सीमा (धारा 6 व 7)",
          sectionsRange: "Sections 3 – 11",
          sections: [
            {
              id: "rti_s6",
              num: 6,
              code: "Section 6 & 7",
              oldRef: "RTI Filing & 30-Day Limit",
              title: "Request for obtaining information & Disposal within 30 days",
              titleHindi: "धारा 6 एवं 7: RTI आवेदन और 30 दिन (जीवन/स्वतंत्रता में 48 घंटे) में जवाब",
              duration: "11:40",
              bareActTextHindi: "धारा 6 के तहत कोई भी नागरिक जन सूचना अधिकारी (PIO) से लिखित या ऑनलाइन सूचना मांग सकता है। धारा 7 के अनुसार सामान्य मामलों में 30 दिन के भीतर और किसी व्यक्ति के जीवन या स्वतंत्रता से जुड़े मामलों में 48 घंटे के भीतर सूचना देना अनिवार्य है।",
              saralTextHindi: "सरल भाषा: किसी भी सरकारी विभाग के काम, सड़क, राशन या फंड की जानकारी लेने के लिए ₹10 शुल्क के साथ RTI लगाई जा सकती है, जिसका जवाब 30 दिन में देना अधिकारी की कानूनी जिम्मेदारी है।",
              bareActTextEnglish: "Section 6 & 7: Every citizen has the right to seek information from a Public Authority. The PIO must reply within 30 days, or within 48 hours if the information concerns the life or liberty of a person.",
              saralTextEnglish: "Simple Explanation: Citizens can request government records without giving any reason; reply is mandatory within 30 days.",
              summaryHindi: "सरकारी विभागों में पारदर्शिता के लिए ₹10 शुल्क के साथ RTI लगाई जा सकती है जिसका जवाब 30 दिन में मिलना कानूनी रूप से अनिवार्य है।",
              keyPoints: ["सामान्य समय सीमा: 30 दिन।", "जीवन व स्वतंत्रता से संबंधित मामले: 48 घंटे।"]
            }
          ]
        }
      ]
    }
  ],

  allActsProgressList: [
    { num: 1, titleHindi: "भारत का संविधान", titleEng: "Constitution of India", done: 448, total: 448, pct: 100, icon: "🏛️", color: "#ef4444", actId: "constitution" },
    { num: 2, titleHindi: "भारतीय न्याय संहिता, 2023", titleEng: "Bharatiya Nyaya Sanhita (BNS)", done: 279, total: 358, pct: 78, icon: "⚖️", color: "#3b82f6", actId: "bns" },
    { num: 3, titleHindi: "भारतीय नागरिक सुरक्षा संहिता, 2023", titleEng: "Bharatiya Nagarik Suraksha Sanhita (BNSS)", done: 320, total: 531, pct: 60, icon: "🛡️", color: "#eab308", actId: "bnss" },
    { num: 4, titleHindi: "भारतीय साक्ष्य अधिनियम, 2023", titleEng: "Bharatiya Sakshya Adhiniyam (BSA)", done: 75, total: 170, pct: 44, icon: "🔍", color: "#ec4899", actId: "bsa" },
    { num: 5, titleHindi: "उपभोक्ता संरक्षण अधिनियम, 2019", titleEng: "Consumer Protection Act, 2019", done: 63, total: 107, pct: 59, icon: "🛒", color: "#10b981", actId: "cpa_2019" },
    { num: 6, titleHindi: "भारतीय संविदा अधिनियम, 1872", titleEng: "Indian Contract Act, 1872", done: 128, total: 266, pct: 48, icon: "📜", color: "#f97316", actId: "ica_1872" },
    { num: 7, titleHindi: "परक्राम्य लिखत अधिनियम, 1881", titleEng: "Negotiable Instruments Act, 1881", done: 98, total: 148, pct: 66, icon: "💳", color: "#8b5cf6", actId: "ni_1881" },
    { num: 8, titleHindi: "घरेलू हिंसा से महिला संरक्षण अधिनियम, 2005", titleEng: "Domestic Violence Act, 2005", done: 18, total: 37, pct: 49, icon: "🏠", color: "#06b6d4", actId: "dv_2005" },
    { num: 9, titleHindi: "सूचना का अधिकार अधिनियम, 2005", titleEng: "Right to Information Act, 2005", done: 20, total: 31, pct: 65, icon: "ℹ️", color: "#f43f5e", actId: "rti_2005" },
    { num: 10, titleHindi: "भारतीय दंड संहिता, 1860", titleEng: "Indian Penal Code, 1860", done: 128, total: 511, pct: 25, icon: "📕", color: "#22c55e", actId: "ipc_1860" }
  ],

  publicLawCriminalTopics: [
    { num: 1, title: "General Principles (सामान्य सिद्धांत)", done: 12, total: 12, pct: 100, icon: "📄", topicId: "fir" },
    { num: 2, title: "Offences Against Body (शरीर के विरुद्ध अपराध)", done: 8, total: 12, pct: 67, icon: "🤺", topicId: "police" },
    { num: 3, title: "Offences Against Property (संपत्ति विवाद व अपराध)", done: 14, total: 16, pct: 88, icon: "🏠", topicId: "land" },
    { num: 4, title: "Offences Against Women (महिला संरक्षण व घरेलू हिंसा)", done: 6, total: 14, pct: 43, icon: "♀️", topicId: "dv" },
    { num: 5, title: "Offences Against Children (बाल संरक्षण कानून)", done: 3, total: 10, pct: 30, icon: "🧒", topicId: "fir" },
    { num: 6, title: "FIR, Zero FIR & Police Investigation", done: 5, total: 8, pct: 62, icon: "🏛️", topicId: "no_fir" },
    { num: 7, title: "Bail & Anticipatory Bail (जमानत के नियम)", done: 9, total: 10, pct: 90, icon: "⚖️", topicId: "bail" },
    { num: 8, title: "Cyber Offences (साइबर अपराध व ठगी)", done: 4, total: 10, pct: 40, icon: "💻", topicId: "fir" },
    { num: 9, title: "Attempt, Abetment and Conspiracy", done: 6, total: 10, pct: 60, icon: "👥", topicId: "sc" },
    { num: 10, title: "Defences and Exceptions (आत्मरक्षा व अपवाद)", done: 4, total: 8, pct: 50, icon: "🛡️", topicId: "sc" }
  ],

  publicLawTopics: [
    {
      id: "fir",
      category: "Continue Watching",
      title: "FIR कैसे होती है?",
      subtitle: "जानिए FIR दर्ज करने की पूरी प्रक्रिया और आपके अधिकार (Demo)",
      duration: "24 मिनट",
      progress: 60,
      image: "assets/images/topic_fir.jpg",
      heroImage: "assets/images/fir_hero_banner.jpg",
      mediaAvailable: true,
      points: [
        "FIR क्या होती है और क्यों जरूरी है (BNSS धारा 173)",
        "FIR दर्ज करने की स्टेप बाय स्टेप प्रक्रिया",
        "किन मामलों में पुलिस FIR दर्ज करने से मना नहीं कर सकती (संज्ञेय अपराध)",
        "Zero FIR और e-FIR क्या है?",
        "FIR की निःशुल्क कॉपी कैसे प्राप्त करें?"
      ],
      detailedGuide: "[DEMO CONTENT] संज्ञेय अपराध (Cognizable Offence) होने पर पुलिस स्टेशन के भारसाधक अधिकारी (SHO) को तुरंत FIR दर्ज करनी होती है। सूचना देने वाले को FIR पढ़कर सुनाई जाती है और उसकी एक प्रति (Copy) बिल्कुल मुफ्त दी जाती है। यदि अपराध दूसरे थाने के क्षेत्र में हुआ हो, तब भी पुलिस को 'Zero FIR' दर्ज कर संबंधित थाने को भेजना अनिवार्य है।"
    },
    {
      id: "bail",
      category: "Continue Watching",
      title: "बेल (Bail) कैसे लें?",
      subtitle: "जमानती और गैर-जमानती अपराधों में जमानत की पूरी प्रक्रिया (Demo)",
      duration: "21 मिनट",
      progress: 30,
      image: "assets/images/topic_bail.jpg",
      heroImage: "assets/images/topic_bail.jpg",
      mediaAvailable: true,
      points: [
        "जमानती (Bailable) और गैर-जमानती (Non-Bailable) अपराध में अंतर",
        "अग्रिम जमानत (Anticipatory Bail - BNSS धारा 482) कैसे मिलती है?",
        "रेगुलर बेल (धारा 480) और डिफॉल्ट बेल (Default Bail - धारा 187) के नियम",
        "जमानत बॉन्ड और जमानतदार (Surety) की प्रक्रिया"
      ],
      detailedGuide: "[DEMO CONTENT] जमानती अपराधों में बेल पाना अभियुक्त का कानूनी अधिकार है। गैर-जमानती अपराधों में न्यायालय अपराध की गंभीरता, साक्ष्य और अभियुक्त के आचरण को देखकर जमानत देता है। गिरफ्तारी की आशंका होने पर सेशन कोर्ट या हाई कोर्ट से अग्रिम जमानत (Anticipatory Bail) ली जा सकती है।"
    },
    {
      id: "police",
      category: "Most Popular",
      title: "पुलिस गाली दे तो क्या करें?",
      subtitle: "नागरिक सम्मान और पुलिस शिकायत प्राधिकरण (PCA) के नियम (Demo)",
      duration: "18 मिनट",
      progress: 40,
      image: "assets/images/topic_police.jpg",
      heroImage: "assets/images/topic_police.jpg",
      mediaAvailable: true,
      points: [
        "पुलिस को किसी भी नागरिक से गाली-गलौज या मारपीट का अधिकार नहीं है",
        "वरिष्ठ पुलिस अधीक्षक (SSP/SP) और पुलिस शिकायत प्राधिकरण (PCA) में शिकायत",
        "महिलाओं से पूछताछ और गिरफ्तारी के विशेष नियम (सूर्यास्त के बाद गिरफ्तारी नहीं)",
        "मानवाधिकार आयोग और न्यायालय में परिवाद प्रक्रिया"
      ],
      detailedGuide: "[DEMO CONTENT] भारतीय संविधान का अनुच्छेद 21 प्रत्येक नागरिक को गरिमापूर्ण जीवन का अधिकार देता है। पुलिस द्वारा दुर्व्यवहार किए जाने पर आप तुरंत जिले के SP/SSP, राज्य पुलिस शिकायत प्राधिकरण (Police Complaints Authority) या मजिस्ट्रेट के समक्ष शिकायत दर्ज करा सकते हैं।"
    },
    {
      id: "sc",
      category: "Most Popular",
      title: "आम इंसान Supreme Court कैसे जा सकता है?",
      subtitle: "अनुच्छेद 32, जनहित याचिका (PIL) और निःशुल्क विधिक सहायता (NALSA)",
      duration: "23 मिनट",
      progress: 65,
      image: "assets/images/topic_sc.jpg",
      heroImage: "assets/images/sc_hero_day.jpg",
      mediaAvailable: true,
      points: [
        "मौलिक अधिकारों के हनन पर अनुच्छेद 32 के तहत सीधे सुप्रीम कोर्ट में रिट याचिका",
        "हाई कोर्ट के फैसले के खिलाफ विशेष अनुमति याचिका (SLP - Article 136)",
        "गरीब और जरूरतमंद नागरिकों के लिए मुफ्त सरकारी वकील (Legal Aid / NALSA)",
        "जनहित याचिका (PIL) और ई-फाइलिंग की सुविधा"
      ],
      detailedGuide: "[DEMO CONTENT] मौलिक अधिकार छिनने पर कोई भी नागरिक अनुच्छेद 32 के तहत सीधे सुप्रीम कोर्ट जा सकता है। यदि आपके पास वकील की फीस नहीं है, तो विधिक सेवा प्राधिकरण (NALSA / SCLSC) आपको निःशुल्क वकील उपलब्ध कराता है।"
    },
    {
      id: "no_fir",
      category: "Important Topics",
      title: "पुलिस FIR ना लिखे तो क्या करें?",
      subtitle: "SP को डाक से शिकायत और मजिस्ट्रेट कोर्ट (BNSS 175(3)) का रास्ता",
      duration: "20 मिनट",
      progress: 25,
      image: "assets/images/topic_fir.jpg",
      heroImage: "assets/images/fir_hero_banner.jpg",
      mediaAvailable: true,
      points: [
        "स्टेप 1: जिले के SP/DCP को रजिस्टर्ड डाक या ऑनलाइन पोर्टल से लिखित शिकायत भेजें",
        "स्टेप 2: BNSS की धारा 175(3) (पूर्व CrPC 156(3)) के तहत मजिस्ट्रेट के समक्ष प्रार्थना पत्र",
        "स्टेप 3: संज्ञेय अपराध की FIR न लिखने वाले अधिकारी की जवाबदेही (ललिता कुमारी केस)"
      ],
      detailedGuide: "[DEMO CONTENT] सुप्रीम कोर्ट के 'ललिता कुमारी बनाम उत्तर प्रदेश राज्य' फैसले के अनुसार संज्ञेय अपराध में FIR लिखना अनिवार्य है। यदि थाना प्रभारी मना करे, तो SP को शिकायत भेजें और इसके बाद मजिस्ट्रेट कोर्ट से सीधे FIR दर्ज करने का आदेश प्राप्त करें।"
    },
    {
      id: "land",
      category: "Important Topics",
      title: "जमीन विवाद कैसे सुलझाएं?",
      subtitle: "दाखिल-खारिज, पैमाइश (हदबंदी), स्टे ऑर्डर और सिविल कोर्ट प्रक्रिया",
      duration: "25 मिनट",
      progress: 60,
      image: "assets/images/sc_hero_day.jpg",
      heroImage: "assets/images/sc_hero_day.jpg",
      mediaAvailable: true,
      points: [
        "खसरा, खतौनी और रजिस्ट्री के कागजात की जांच कैसे करें?",
        "अवैध कब्जे पर SDM कोर्ट और सिविल कोर्ट से स्टे ऑर्डर (Temporary Injunction)",
        "तहसीलदार और राजस्व न्यायालय में सीमांकन (हदबंदी) की प्रक्रिया",
        "पुश्तैनी संपत्ति में बेटियों और वारिसों का बराबर अधिकार"
      ],
      detailedGuide: "[DEMO CONTENT] जमीन विवाद में पहले राजस्व रिकॉर्ड (खतौनी/नक्शा) प्रमाणित कराएं, सीमा विवाद होने पर SDM कोर्ट में हदबंदी का आवेदन दें और मालिकाना हक या अवैध निर्माण रोकने के लिए सिविल कोर्ट से स्टे (Injunction) प्राप्त करें।"
    },
    {
      id: "dv",
      category: "Important Topics",
      title: "घरेलू हिंसा (Domestic Violence) में क्या करें?",
      subtitle: "घरेलू हिंसा से महिला संरक्षण अधिनियम 2005 और भरण-पोषण अधिकार",
      duration: "20 मिनट",
      progress: 35,
      image: "assets/images/banner_public_law.jpg",
      heroImage: "assets/images/banner_public_law.jpg",
      mediaAvailable: true,
      points: [
        "शारीरिक, मानसिक, भावनात्मक और आर्थिक प्रताड़ना सभी घरेलू हिंसा हैं",
        "महिला हेल्पलाइन 181 / 1090 और संरक्षण अधिकारी (Protection Officer) की भूमिका",
        "ससुराल या साझा घर में रहने का अधिकार (Right to Residence)",
        "आपातकालीन आर्थिक सहायता, भरण-पोषण और बच्चों की कस्टडी"
      ],
      detailedGuide: "[DEMO CONTENT] घरेलू हिंसा अधिनियम 2005 के तहत पीड़ित महिला संरक्षण अधिकारी (Protection Officer), पुलिस या सीधे मजिस्ट्रेट को शिकायत कर सकती है।"
    }
  ],

  shabdawaliCategories: [
    { id: "all", name: "All Categories", nameHindi: "सभी शब्द", subtitle: "All Legal & General Words", icon: "📚", badgeWords: "All Demo Words", color: "#7c3aed" },
    { id: "legal", name: "Legal Shabdawali", nameHindi: "कानूनी शब्दावली", subtitle: "Law Terms | Meanings | Examples in Simple Language", icon: "⚖️", badgeWords: "5320 Words (Demo)", color: "#d97706" },
    { id: "english", name: "English Speaking", nameHindi: "इंग्लिश स्पीकिंग", subtitle: "Daily Use | Conversation | Fluency", icon: "💬", badgeWords: "2100 Words (Demo)", color: "#9333ea" },
    { id: "general", name: "General words", nameHindi: "सामान्य शब्द", subtitle: "Common | Daily Life | Useful Terms", icon: "📗", badgeWords: "1850 Words (Demo)", color: "#10b981" },
    { id: "medical", name: "Medical & Health", nameHindi: "मेडिकल व स्वास्थ्य", subtitle: "Health Terms | Diseases | Treatment", icon: "🩺", badgeWords: "1200 Words (Demo)", color: "#ef4444" },
    { id: "technical", name: "Technical", nameHindi: "टेक्निकल शब्द", subtitle: "Technical Terms | Professional Use", icon: "⚙️", badgeWords: "1450 Words (Demo)", color: "#ec4899" },
    { id: "grammar", name: "Grammar shabdawali", nameHindi: "व्याकरण शब्दावली", subtitle: "Rules | Structure | Examples", icon: "🅰️", badgeWords: "980 Words (Demo)", color: "#3b82f6" },
    { id: "government", name: "Government & Administration", nameHindi: "सरकार व प्रशासन", subtitle: "Government Terms | Policies | Schemes", icon: "🏛️", badgeWords: "750 Words (Demo)", color: "#f59e0b" },
    { id: "agriculture", name: "Agriculture & Food", nameHindi: "कृषि व खाद्य", subtitle: "Farming Terms | Crops | Food Items", icon: "🌱", badgeWords: "650 Words (Demo)", color: "#22c55e" },
    { id: "nature", name: "Nature & Environment", nameHindi: "प्रकृति व पर्यावरण", subtitle: "Plants | Animals | Climate | Pollution", icon: "🌍", badgeWords: "620 Words (Demo)", color: "#06b6d4" }
  ],

  kanooniLines: [
    { id: "kl1", num: 1, date: "21 May 2024 • मंगलवार", eng: "Justice delayed is justice denied.", hin: "देर से मिला न्याय, न्याय से वंचित होना है।" },
    { id: "kl2", num: 2, date: "20 May 2024 • सोमवार", eng: "Bail is a rule, jail is an exception.", hin: "जमानत नियम है, जेल अपवाद है।" },
    { id: "kl3", num: 3, date: "19 May 2024 • रविवार", eng: "Ignorance of law is no excuse.", hin: "कानून की जानकारी न होना कोई बहाना नहीं है।" },
    { id: "kl4", num: 4, date: "18 May 2024 • शनिवार", eng: "Every right has a corresponding duty.", hin: "हर अधिकार के साथ एक कर्तव्य होता है।" },
    { id: "kl5", num: 5, date: "17 May 2024 • शुक्रवार", eng: "Power without responsibility is dangerous.", hin: "जिम्मेदारी के बिना शक्ति खतरनाक होती है।" },
    { id: "kl6", num: 6, date: "16 May 2024 • गुरुवार", eng: "Better a rough justice than no justice.", hin: "अन्याय से बेहतर है कि थोड़ा सा ही सही, पर न्याय हो।" },
    { id: "kl7", num: 7, date: "15 May 2024 • बुधवार", eng: "Law protects those who protect others.", hin: "कानून उनकी रक्षा करता है जो दूसरों की रक्षा करते हैं।" },
    { id: "kl8", num: 8, date: "14 May 2024 • मंगलवार", eng: "Equality before law is the foundation of justice.", hin: "कानून के समक्ष समानता न्याय की नींव है।" },
    { id: "kl9", num: 9, date: "13 May 2024 • सोमवार", eng: "Delay in justice makes justice injustice.", hin: "न्याय में देरी, न्याय के साथ अन्याय है।" },
    { id: "kl10", num: 10, date: "12 May 2024 • रविवार", eng: "No one is above the law.", hin: "कानून से ऊपर कोई नहीं है।" }
  ],

  shabdawali: [
    {
      id: "w1",
      num: 1,
      category: "legal",
      isNew: true,
      term: "Authorised",
      hindiShort: "अधिकृत, मान्य, स्वीकृत, अधिकृतकृत",
      english: "Authorised (Legal Term)",
      pronunciation: "ऑथोराइज्ड (Adhikrit)",
      meaning: "जिसे कानून या सक्षम अधिकारी द्वारा अनुमति दी गई हो, वह Authorised कहलाता है।",
      explanation: "न्यायालय या सरकारी कार्य में केवल अधिकृत (Authorised) व्यक्ति या अधिकारी के हस्ताक्षर ही वैध माने जाते हैं।",
      example: "केवल Authorised व्यक्ति ही इस दस्तावेज़ पर हस्ताक्षर कर सकता है।",
      exampleEng: "Only an authorised signatory can sign this legal document.",
      synonyms: ["Approved", "Accredited", "Licensed", "Permitted"]
    },
    {
      id: "w2",
      num: 2,
      category: "legal",
      isNew: true,
      term: "Objection",
      hindiShort: "आपत्ति, विरोध, एतराज, असहमति",
      english: "Objection (Court Procedure)",
      pronunciation: "ऑब्जेक्शन (Aapatti)",
      meaning: "न्यायालय में कार्यवाही या गवाही के दौरान किसी गलत या गैर-कानूनी प्रश्न या तथ्य पर औपचारिक विरोध दर्ज करना।",
      explanation: "जब विरोधी वकील कोई अनुचित या अप्रासंगिक सवाल पूछता है, तो अधिवक्ता 'Objection My Lord' कहकर आपत्ति दर्ज करते हैं।",
      example: "बचाव पक्ष के वकील ने गवाह से पूछे गए भ्रामक प्रश्न पर तुरंत Objection किया।",
      exampleEng: "The defence counsel raised a strong objection to the leading question.",
      synonyms: ["Protest", "Challenge", "Exception", "Dissent"]
    },
    {
      id: "w3",
      num: 3,
      category: "legal",
      isNew: false,
      term: "Hearing",
      hindiShort: "सुनवाई, श्रवण, विचारण, सुनना",
      english: "Court Hearing",
      pronunciation: "हियरिंग (Sunwai)",
      meaning: "न्यायाधीश के सामने दोनों पक्षों की दलीलें और साक्ष्य सुने जाने की न्यायिक प्रक्रिया।",
      explanation: "प्रत्येक मुकदमे में कोर्ट तारीख तय करता है जिसे 'Date of Hearing' (सुनवाई की तिथि) कहा जाता है।",
      example: "जमानत याचिका पर अगली Hearing सोमवार को हाई कोर्ट में होगी।",
      exampleEng: "The next hearing of the bail application is scheduled for Monday.",
      synonyms: ["Trial", "Proceeding", "Session", "Audience"]
    },
    {
      id: "w4",
      num: 4,
      category: "legal",
      isNew: false,
      term: "Plaintiff",
      hindiShort: "वादी, मुकदमा करने वाला, दावा करने वाला",
      english: "Plaintiff / Claimant (Civil Suit)",
      pronunciation: "प्लेनटिफ (Vaadi)",
      meaning: "वह व्यक्ति जो सिविल न्यायालय में अपने अधिकार या मुआवजे के लिए मुकदमा (Suit) दायर करता है।",
      explanation: "सिविल मुकदमों में केस शुरू करने वाले को Plaintiff (वादी) और जिस पर केस किया गया हो उसे Defendant (प्रतिवादी) कहते हैं।",
      example: "जमीन पर अवैध कब्जे के खिलाफ Plaintiff ने सिविल कोर्ट में वाद दायर किया।",
      exampleEng: "The plaintiff filed a civil suit for permanent injunction.",
      synonyms: ["Claimant", "Petitioner", "Complainant", "Litigant"]
    },
    {
      id: "w5",
      num: 5,
      category: "legal",
      isNew: false,
      term: "Defendant",
      hindiShort: "प्रतिवादी, जिस व्यक्ति के खिलाफ मुकदमा किया गया हो",
      english: "Defendant / Respondent",
      pronunciation: "डिफेंडेंट (Prativaadi)",
      meaning: "वह व्यक्ति जिसके विरुद्ध सिविल कोर्ट में मुकदमा या दावा दायर किया गया हो।",
      explanation: "कोर्ट प्रतिवादी (Defendant) को समन भेजकर अपना लिखित जवाब (Written Statement) दाखिल करने का अवसर देता है।",
      example: "कोर्ट ने Defendant को 30 दिनों के भीतर अपना जवाब दाखिल करने का आदेश दिया।",
      exampleEng: "The Court issued summons to the defendant to file a written statement.",
      synonyms: ["Respondent", "Accused", "Opposing Party"]
    },
    {
      id: "w6",
      num: 6,
      category: "government",
      isNew: false,
      term: "Legislature",
      hindiShort: "विधायिका, कानून बनाने वाली संस्था",
      english: "Legislature (Parliament & State Assembly)",
      pronunciation: "लेजिस्लेचर (Vidhayika)",
      meaning: "देश या राज्य के लिए कानून बनाने वाली संवैधानिक संस्था (संसद और विधानसभा)।",
      explanation: "लोकतंत्र के तीन मुख्य स्तंभ हैं: विधायिका (Legislature), कार्यपालिका (Executive) और न्यायपालिका (Judiciary)।",
      example: "भारतीय न्याय संहिता (BNS) को संसद (Legislature) द्वारा पारित किया गया है।",
      exampleEng: "The Legislature enacted the new criminal laws in December 2023.",
      synonyms: ["Parliament", "Law-making Body", "Assembly"]
    },
    {
      id: "w7",
      num: 7,
      category: "english",
      isNew: true,
      term: "Embarrassing",
      hindiShort: "शर्मनाक, लज्जाजनक, अपमानजनक, असहज",
      english: "Embarrassing (Daily & Court Use)",
      pronunciation: "एम्बैरेसिंग (Sharmnaak)",
      meaning: "ऐसी स्थिति या व्यवहार जिससे व्यक्ति को शर्म या असहज महसूस हो।",
      explanation: "उपयोग : — Court में गलत बयान देना आपके लिए embarrassing हो सकता है।",
      example: "Court में गलत बयान देना आपके लिए embarrassing हो सकता है।",
      exampleEng: "It was embarrassing for him to forget the answer in the court.",
      synonyms: ["Shameful", "Awkward", "Humiliating", "Uncomfortable"]
    },
    {
      id: "w8",
      num: 8,
      category: "legal",
      isNew: true,
      term: "Embargo",
      hindiShort: "प्रतिबंध, सरकारी रोक",
      english: "Embargo (Official Ban / Restriction)",
      pronunciation: "एम्बार्गो (Pratibandh)",
      meaning: "किसी चीज़ के व्यापार या गतिविधि पर लगाया गया आधिकारिक या कानूनी रोक।",
      explanation: "उपयोग : — सरकार ने आयात पर embargo लगा दिया।",
      example: "सरकार ने आयात पर embargo लगा दिया।",
      exampleEng: "The government imposed an embargo on the import of that item.",
      synonyms: ["Ban", "Restriction", "Prohibition", "Moratorium"]
    },
    {
      id: "w9",
      num: 9,
      category: "english",
      isNew: false,
      term: "Abandon",
      hindiShort: "त्यागना, छोड़ देना",
      english: "Abandon (Verb)",
      pronunciation: "अबैंडन (Tyagna)",
      meaning: "किसी दावे, संपत्ति या अधिकार को स्वेच्छा से हमेशा के लिए छोड़ देना।",
      explanation: "कानून में जब कोई पक्षकार अपना दावा छोड़ देता है तो उसे 'Abandonment of Claim' कहते हैं।",
      example: "वादी ने अपने पुराने दावे को Abandon कर दिया।",
      exampleEng: "He decided to abandon his claim over the disputed plot.",
      synonyms: ["Leave", "Give up", "Renounce", "Forsake"]
    },
    {
      id: "w10",
      num: 10,
      category: "english",
      isNew: false,
      term: "Ability",
      hindiShort: "योग्यता, क्षमता",
      english: "Ability / Legal Capacity",
      pronunciation: "एबिलिटी (Yogyata)",
      meaning: "किसी कार्य को करने की मानसिक, शारीरिक या कानूनी क्षमता।",
      explanation: "संविदा करने या गवाही देने के लिए व्यक्ति में समझने की क्षमता (Ability) होनी चाहिए।",
      example: "अधिवक्ता की बहस करने की Ability ने केस जिता दिया।",
      exampleEng: "A lawyer's ability to cross-examine is crucial in trial.",
      synonyms: ["Capability", "Competence", "Skill", "Capacity"]
    },
    {
      id: "w11",
      num: 11,
      category: "legal",
      isNew: true,
      term: "Affidavit",
      hindiShort: "शपथ-पत्र, हलफनामा",
      english: "Affidavit (Sworn Statement)",
      pronunciation: "एफिडेविट (Shapath-Patra)",
      meaning: "नोटरी या मजिस्ट्रेट के समक्ष शपथ लेकर दिया गया लिखित बयान कि उसमें लिखे तथ्य सत्य हैं।",
      explanation: "न्यायालय में याचिका या जमानत अर्जी के साथ शपथ-पत्र (Affidavit) लगाया जाता है। झूठा शपथ-पत्र देना अपराध है।",
      example: "अग्रिम जमानत याचिका के समर्थन में आवेदक ने अपना Affidavit दाखिल किया।",
      exampleEng: "The petitioner filed a sworn affidavit before the High Court.",
      synonyms: ["Sworn Statement", "Declaration on Oath", "हलफनामा"]
    },
    {
      id: "w12",
      num: 12,
      category: "legal",
      isNew: true,
      term: "Cognizable",
      hindiShort: "संज्ञेय अपराध (बिना वारंट गिरफ्तारी योग्य)",
      english: "Cognizable Offence (BNSS Sec 2(1)(g))",
      pronunciation: "कॉग्निजेबल (Sangyeya)",
      meaning: "ऐसे गंभीर अपराध जिनमें पुलिस बिना मजिस्ट्रेट के वारंट के गिरफ्तार कर सकती है और तुरंत FIR दर्ज करती है।",
      explanation: "हत्या, डकैती, अपहरण जैसे गंभीर अपराध संज्ञेय (Cognizable) अपराध होते हैं।",
      example: "संज्ञेय (Cognizable) अपराध में पुलिस FIR लिखने से मना नहीं कर सकती।",
      exampleEng: "Police must register an FIR in every cognizable offence under BNSS Section 173.",
      synonyms: ["Serious Offence", "Warrantless Arrest Case", "संज्ञेय मामला"]
    },
    {
      id: "w13",
      num: 13,
      category: "medical",
      isNew: false,
      term: "Post-Mortem / Autopsy",
      hindiShort: "शव-परीक्षण, मृत्यु के कारण की मेडिकल जांच",
      english: "Post-Mortem Examination (Forensic Medicine)",
      pronunciation: "पोस्टमार्टम (Shav-Parikshan)",
      meaning: "संदिग्ध मृत्यु के मामले में मौत का सही कारण जानने के लिए डॉक्टर द्वारा किया जाने वाला शव-परीक्षण।",
      explanation: "आपराधिक मामलों (BNS धारा 103) में पोस्टमार्टम रिपोर्ट (PMR) एक अत्यंत महत्वपूर्ण मेडिकल साक्ष्य होती है।",
      example: "पुलिस ने मृत्यु का कारण जानने के लिए शव को Post-Mortem के लिए भेजा।",
      exampleEng: "The post-mortem report confirmed the time and cause of death.",
      synonyms: ["Autopsy", "Necropsy", "Medico-Legal Examination"]
    },
    {
      id: "w14",
      num: 14,
      category: "technical",
      isNew: true,
      term: "Encryption & Digital Signature",
      hindiShort: "डेटा सुरक्षा कूटलेखन एवं डिजिटल हस्ताक्षर",
      english: "Digital Signature (IT Act & BSA Sec 63)",
      pronunciation: "डिजिटल सिग्नेचर",
      meaning: "इलेक्ट्रॉनिक दस्तावेजों की प्रामाणिकता और सुरक्षा प्रमाणित करने की डिजिटल तकनीक।",
      explanation: "IT Act 2000 और भारतीय साक्ष्य अधिनियम (BSA) 2023 के तहत डिजिटल हस्ताक्षर को कानूनी मान्यता प्राप्त है।",
      example: "ई-फाइलिंग में याचिका पर अधिवक्ता के Digital Signature लगाए जाते हैं।",
      exampleEng: "The e-filing portal requires a valid Digital Signature Certificate (DSC).",
      synonyms: ["Electronic Signature", "Cryptographic Auth", "DSC"]
    },
    {
      id: "w15",
      num: 15,
      category: "grammar",
      isNew: false,
      term: "Passive Voice in Legal Drafting",
      hindiShort: "कर्मवाच्य वाक्य रचना (कानूनी ड्राफ्टिंग नियम)",
      english: "Legal Grammar & Clause Structure",
      pronunciation: "लीगल ग्रामर",
      meaning: "कानूनी धाराओं और आदेशों में निष्पक्षता दिखाने के लिए प्रयुक्त वाक्य संरचना (जैसे 'shall be punished')।",
      explanation: "बेर एक्ट की भाषा में 'Shall' का प्रयोग बाध्यकारी (Mandatory) और 'May' का प्रयोग विवेकाधीन (Discretionary) अर्थ में होता है।",
      example: "कानून में 'Shall' का अर्थ अनिवार्य बाध्यता होता है।",
      exampleEng: "In statutory interpretation, 'shall' generally denotes a mandatory duty.",
      synonyms: ["Statutory Syntax", "Mandatory Clause", "Drafting Rule"]
    },
    {
      id: "w16",
      num: 16,
      category: "agriculture",
      isNew: false,
      term: "Khasra & Khatauni (खसरा और खतौनी)",
      hindiShort: "कृषि भूमि का राजस्व अधिकार अभिलेख",
      english: "Record of Rights (Land Revenue Law)",
      pronunciation: "खसरा-खतौनी",
      meaning: "कृषि भूमि के मालिक, क्षेत्रफल और फसल का सरकारी तहसील रिकॉर्ड।",
      explanation: "जमीन विवाद और खेती की जमीन की खरीद-बिक्री में खतौनी (Record of Rights) की जांच सबसे जरूरी होती है।",
      example: "जमीन खरीदने से पहले तहसील से पिछले 12 साल की Khatauni जरूर जांचें।",
      exampleEng: "Always verify the Khatauni and mutation records before purchasing agricultural land.",
      synonyms: ["Land Record", "RoR", "भू-अभिलेख"]
    },
    {
      id: "w17",
      num: 17,
      category: "nature",
      isNew: false,
      term: "Environmental Clearance & NGT",
      hindiShort: "पर्यावरण मंजूरी एवं राष्ट्रीय हरित अधिकरण",
      english: "National Green Tribunal (Environment Law)",
      pronunciation: "एन.जी.टी. (Paryavaran Nyayadhikaran)",
      meaning: "पर्यावरण संरक्षण, वनों की रक्षा और प्रदूषण रोकने के लिए गठित विशेष न्यायालय।",
      explanation: "अवैध खनन या औद्योगिक प्रदूषण के विरुद्ध कोई भी नागरिक NGT में याचिका दायर कर सकता है।",
      example: "नदी में प्रदूषण फैलाने वाली फैक्ट्री पर NGT ने भारी जुर्माना लगाया।",
      exampleEng: "The National Green Tribunal imposed a penalty on the polluting industry.",
      synonyms: ["Green Court", "Eco-Tribunal", "पर्यावरण न्यायालय"]
    },
    {
      id: "w18",
      num: 18,
      category: "general",
      isNew: false,
      term: "Bona Fide",
      hindiShort: "सद्भावपूर्वक, नेकनीयती से, सच्चा",
      english: "In Good Faith (Bona Fide)",
      pronunciation: "बोना फाइड (Sadbhavpurvak)",
      meaning: "बिना किसी छल-कपट के, ईमानदारी और सही इरादे से किया गया कार्य।",
      explanation: "यदि कोई व्यक्ति पूरी सावधानी और नेकनीयती (Bona Fide) से कार्य करता है, तो कानून उसे संरक्षण देता है।",
      example: "वह उस प्रॉपर्टी का Bona Fide खरीदार (Purchaser) है।",
      exampleEng: "The court protected the rights of the bona fide purchaser.",
      synonyms: ["Genuine", "In Good Faith", "Authentic", "Honest"]
    }
  ],

  audioLearningCategories: [
    {
      id: "al_legal",
      title: "Legal Shabdawali",
      titleHindi: "कानूनी शब्दावली ऑडियो पैक (5320 Words Demo)",
      tracksCount: 20,
      duration: "45 Mins",
      icon: "⚖️",
      tracks: [
        { id: "tr_1", num: 1, title: "Authorised", hindi: "अधिकृत, मान्य, स्वीकृत, अधिकृतकृत", meaning: "जिसे कानून या सक्षम अधिकारी द्वारा अनुमति दी गई हो, वह Authorised कहलाता है।", example: "केवल Authorised व्यक्ति ही इस दस्तावेज़ पर हस्ताक्षर कर सकता है।", synonyms: "Approved, Accredited, Licensed, Permitted", duration: "0:08", actId: "bns" },
        { id: "tr_2", num: 2, title: "Objection", hindi: "आपत्ति, विरोध, एतराज, असहमति", meaning: "न्यायालय में किसी अनुचित प्रश्न या तथ्य पर औपचारिक विरोध दर्ज करना।", example: "वकील ने भ्रामक प्रश्न पर तुरंत Objection किया।", synonyms: "Protest, Challenge, Exception", duration: "0:09", actId: "bns" },
        { id: "tr_3", num: 3, title: "Hearing", hindi: "सुनवाई, श्रवण, विचारण, सुनना", meaning: "न्यायाधीश के सामने दोनों पक्षों की दलीलें सुने जाने की प्रक्रिया।", example: "जमानत याचिका पर अगली Hearing सोमवार को होगी।", synonyms: "Trial, Proceeding, Session", duration: "0:08", actId: "bnss" },
        { id: "tr_4", num: 4, title: "Plaintiff", hindi: "वादी, मुकदमा करने वाला, दावा करने वाला", meaning: "वह व्यक्ति जो सिविल कोर्ट में अपने अधिकार के लिए मुकदमा दायर करता है।", example: "Plaintiff ने सिविल कोर्ट में संपत्ति का दावा किया।", synonyms: "Claimant, Petitioner", duration: "0:08", actId: "bns" },
        { id: "tr_5", num: 5, title: "Defendant", hindi: "प्रतिवादी, जिस व्यक्ति के खिलाफ मुकदमा किया गया हो", meaning: "वह व्यक्ति जिसके विरुद्ध सिविल कोर्ट में मुकदमा दायर किया गया हो।", example: "कोर्ट ने Defendant को समन जारी किया।", synonyms: "Respondent, Accused", duration: "0:08", actId: "bns" },
        { id: "tr_6", num: 6, title: "Legislature", hindi: "विधायिका, कानून बनाने वाली संस्था", meaning: "देश या राज्य के लिए कानून बनाने वाली संस्था (संसद और विधानसभा)।", example: "संसद (Legislature) ने नया कानून पारित किया।", synonyms: "Parliament, Assembly", duration: "0:08", actId: "constitution" },
        { id: "tr_7", num: 7, title: "Executive", hindi: "कार्यपालिका, कानून लागू करने वाली संस्था", meaning: "विधायिका द्वारा बनाए गए कानूनों को लागू करने वाली सरकारी संस्था।", example: "प्रशासन और पुलिस कार्यपालिका (Executive) का हिस्सा हैं।", synonyms: "Administration, Government", duration: "0:08", actId: "constitution" },
        { id: "tr_8", num: 8, title: "Judiciary", hindi: "न्यायपालिका, न्याय करने वाली संस्था", meaning: "संविधान की रक्षा करने और कानून के अनुसार न्याय देने वाली अदालतों की व्यवस्था।", example: "स्वतंत्र Judiciary लोकतंत्र की सबसे बड़ी ताकत है।", synonyms: "Courts, Justice System", duration: "0:08", actId: "constitution" },
        { id: "tr_9", num: 9, title: "Jurisdiction", hindi: "क्षेत्राधिकार, न्यायिक अधिकार क्षेत्र", meaning: "किसी न्यायालय या पुलिस थाने का वह भौगोलिक या कानूनी दायरा जिसमें वह कार्रवाई कर सकता है।", example: "Zero FIR में Jurisdiction की बाधा नहीं होती।", synonyms: "Authority, Territorial Limit", duration: "0:09", actId: "bnss" },
        { id: "tr_10", num: 10, title: "Evidence", hindi: "साक्ष्य, सबूत, गवाही", meaning: "न्यायालय में किसी तथ्य को सच या झूठ साबित करने वाले दस्तावेज, गवाह या डिजिटल रिकॉर्ड।", example: "BSA 2023 में इलेक्ट्रॉनिक रिकॉर्ड को प्राथमिक Evidence माना गया है।", synonyms: "Proof, Testimony", duration: "0:08", actId: "bsa" }
      ]
    },
    {
      id: "al_bns",
      title: "BNS 2023 Audio Series",
      titleHindi: "भारतीय न्याय संहिता ऑडियो लेक्चर (Demo)",
      tracksCount: 4,
      duration: "65 Mins",
      icon: "🎧",
      tracks: [
        { id: "tr_bns_1", num: 1, title: "धारा 1: संक्षिप्त नाम, प्रारंभ और विस्तार", hindi: "Short title, commencement and application", meaning: "भारतीय न्याय संहिता 2023 एक जुलाई 2024 से पूरे भारत में लागू हुई है।", example: "BNS पूरे भारत और विदेश में भारतीय नागरिकों पर लागू है।", synonyms: "BNS Section 1", duration: "12:30", actId: "bns" },
        { id: "tr_bns_2", num: 2, title: "धारा 2: प्रमुख कानूनी परिभाषाएं (1 से 39)", hindi: "Key Legal Definitions under BNS", meaning: "धारा 2 में बालक, न्यायालय, दस्तावेज, इलेक्ट्रॉनिक रिकॉर्ड और बेईमानी जैसे 39 महत्वपूर्ण कानूनी शब्दों को परिभाषित किया गया है।", example: "धारा 2(3) के अनुसार 18 वर्ष से कम आयु का व्यक्ति बालक है।", synonyms: "BNS Section 2", duration: "18:45", actId: "bns" },
        { id: "tr_bns_3", num: 3, title: "धारा 4: दंड के 6 प्रकार और सामुदायिक सेवा", hindi: "6 Types of Punishments & Community Service", meaning: "धारा 4 में पहली बार सामुदायिक सेवा को दंड के रूप में शामिल किया गया है।", example: "छोटे अपराधों में सुधार हेतु सामुदायिक सेवा दी जा सकती है।", synonyms: "BNS Section 4", duration: "15:20", actId: "bns" },
        { id: "tr_bns_4", num: 4, title: "धारा 103: हत्या के लिए दंड एवं मॉब लिंचिंग", hindi: "Punishment for Murder (Old IPC 302)", meaning: "पूर्व आईपीसी की धारा 302 अब बीएनएस की धारा 103 है।", example: "मॉब लिंचिंग के लिए धारा 103(2) में सख्त सजा है।", synonyms: "BNS Section 103", duration: "18:25", actId: "bns" }
      ]
    }
  ],

  mcqSetsList: [
    { id: "set_1", num: "01", title: "All Mix Test – 01 (BNS, BNSS & BSA)", totalQ: 20, correct: 18, wrong: 2, attempted: 20, time: "18:40", scorePct: 90, status: "completed" },
    { id: "set_2", num: "02", title: "All Mix Test – 02 (Criminal Law & FIR)", totalQ: 20, correct: 16, wrong: 4, attempted: 20, time: "21:30", scorePct: 80, status: "completed" },
    { id: "set_3", num: "03", title: "All Mix Test – 03 (Evidence & Confessions)", totalQ: 20, correct: 10, wrong: 3, attempted: 13, time: "12:10", scorePct: 50, status: "in_progress" },
    { id: "set_4", num: "04", title: "All Mix Test – 04 (Constitution & Writs)", totalQ: 20, correct: 0, wrong: 0, attempted: 0, time: "--:--", scorePct: 0, status: "not_started" }
  ],

  mcqTestBank: [
    {
      id: "mcq_1",
      act: "BSA 2023",
      level: "Medium",
      topic: "Confession (Section 22-24)",
      q: "भारतीय साक्ष्य विधेयक / अधिनियम, 2023 की धारा 24 (पूर्व साक्ष्य अधिनियम धारा 24-30) मुख्य रूप से किससे संबंधित है?",
      options: ["A. गिरफ्तारी (Arrest)", "B. स्वीकारोक्ति (Confession)", "C. जमानत (Bail)", "D. तलाशी (Search)"],
      correctIndex: 1,
      hint: "यह धारा अभियुक्त द्वारा जुर्म स्वीकार करने (Confession) से संबंधित है।",
      explanation: "भारतीय साक्ष्य विधेयक/अधिनियम, 2023 में यह स्वीकारोक्ति (Confession) से संबंधित है। इसमें यह बताया गया है कि कौन सी स्वीकारोक्ति कानूनी रूप से मान्य होगी और कौन सी अमान्य।"
    },
    {
      id: "mcq_2",
      act: "BNS 2023",
      level: "Easy",
      topic: "Punishments (Section 4)",
      q: "भारतीय न्याय संहिता (BNS) 2023 की किस धारा में पहली बार 'सामुदायिक सेवा' (Community Service) को दंड के रूप में शामिल किया गया है?",
      options: ["A. धारा 2", "B. धारा 4", "C. धारा 13", "D. धारा 34"],
      correctIndex: 1,
      hint: "अध्याय 2 (दंडों के विषय में) की पहली ही धारा देखें।",
      explanation: "BNS 2023 की धारा 4 में दंड के 6 प्रकार बताए गए हैं, जिनमें छठा प्रकार 'सामुदायिक सेवा' (Community Service) है।"
    },
    {
      id: "mcq_3",
      act: "BNSS 2023",
      level: "Easy",
      topic: "FIR & Zero FIR (Section 173)",
      q: "भारतीय नागरिक सुरक्षा संहिता (BNSS) 2023 की किस धारा के अंतर्गत 'Zero FIR' और 'e-FIR' दर्ज करने का प्रावधान किया गया है?",
      options: ["A. धारा 154", "B. धारा 173", "C. धारा 175", "D. धारा 482"],
      correctIndex: 1,
      hint: "पूर्व CrPC की धारा 154 अब BNSS के अध्याय 13 में किस नंबर पर है?",
      explanation: "BNSS 2023 की धारा 173 (पूर्व CrPC धारा 154) संज्ञेय अपराधों में Zero FIR और e-FIR को कानूनी मान्यता देती है।"
    },
    {
      id: "mcq_4",
      act: "BNS 2023",
      level: "Medium",
      topic: "Common Intention (Section 3(5))",
      q: "पूर्व IPC की धारा 34 'सामान्य आशय' (Common Intention) अब भारतीय न्याय संहिता (BNS) 2023 की किस धारा में उपबंधित है?",
      options: ["A. धारा 2(5)", "B. धारा 3(5)", "C. धारा 14", "D. धारा 34"],
      correctIndex: 1,
      hint: "यह धारा 3 (सामान्य स्पष्टीकरण) की उप-धारा 5 में है।",
      explanation: "पूर्व IPC की धारा 34 (सामान्य आशय को अग्रसर करने में कई व्यक्तियों द्वारा किया गया कार्य) अब BNS 2023 की धारा 3(5) में शामिल है।"
    },
    {
      id: "mcq_5",
      act: "BNS 2023",
      level: "Medium",
      topic: "Offences Against Body (Section 103)",
      q: "भारतीय न्याय संहिता (BNS) 2023 में 'हत्या के लिए दंड' (जो पहले IPC की धारा 302 थी) अब किस धारा में दिया गया है?",
      options: ["A. धारा 100", "B. धारा 101", "C. धारा 103", "D. धारा 105"],
      correctIndex: 2,
      hint: "मानव शरीर के विरुद्ध अपराध अध्याय 6 में धारा 100 से शुरू होते हैं।",
      explanation: "BNS 2023 की धारा 103(1) में हत्या के लिए दंड और धारा 103(2) में मॉब लिंचिंग के लिए मृत्युदंड या आजीवन कारावास का प्रावधान है।"
    },
    {
      id: "mcq_6",
      act: "BSA 2023",
      level: "Medium",
      topic: "Electronic Evidence (Section 63)",
      q: "भारतीय साक्ष्य अधिनियम (BSA) 2023 की किस धारा के तहत इलेक्ट्रॉनिक और डिजिटल रिकॉर्ड (पूर्व धारा 65B) की ग्राह्यता के लिए प्रमाणपत्र आवश्यक है?",
      options: ["A. धारा 57", "B. धारा 61", "C. धारा 63", "D. धारा 65"],
      correctIndex: 2,
      hint: "पूर्व साक्ष्य अधिनियम की धारा 65B के स्थान पर नई धारा 63 है।",
      explanation: "BSA 2023 की धारा 63 इलेक्ट्रॉनिक अभिलेखों (मोबाइल, कंप्यूटर, सीसीटीवी आदि) की ग्राह्यता और प्रमाणपत्र से संबंधित है।"
    },
    {
      id: "mcq_7",
      act: "BNSS 2023",
      level: "Hard",
      topic: "Anticipatory Bail (Section 482)",
      q: "BNSS 2023 में गिरफ्तारी की आशंका होने पर 'अग्रिम जमानत' (Anticipatory Bail) के लिए किस धारा में आवेदन किया जाता है?",
      options: ["A. धारा 438", "B. धारा 480", "C. धारा 482", "D. धारा 483"],
      correctIndex: 2,
      hint: "पूर्व CrPC की धारा 438 अब BNSS में 482 बन गई है।",
      explanation: "पूर्व CrPC की धारा 438 (Anticipatory Bail) अब BNSS 2023 की धारा 482 में उपबंधित है।"
    },
    {
      id: "mcq_8",
      act: "Constitution",
      level: "Easy",
      topic: "Fundamental Rights (Article 22)",
      q: "संविधान के अनुच्छेद 22(2) के अनुसार गिरफ्तार किए गए व्यक्ति को यात्रा के समय को छोड़कर कितने घंटे के भीतर मजिस्ट्रेट के समक्ष पेश करना अनिवार्य है?",
      options: ["A. 12 घंटे", "B. 24 घंटे", "C. 48 घंटे", "D. 72 घंटे"],
      correctIndex: 1,
      hint: "एक दिन-रात की अवधि (24 घंटे)।",
      explanation: "संविधान के अनुच्छेद 22(2) और BNSS की धारा 58 के अनुसार गिरफ्तार व्यक्ति को 24 घंटे के भीतर निकटतम मजिस्ट्रेट के समक्ष पेश करना अनिवार्य है।"
    },
    {
      id: "mcq_9",
      act: "BNS 2023",
      level: "Hard",
      topic: "Enhanced Punishment (Section 13)",
      q: "BNS 2023 की धारा 13 के तहत अध्याय 10 या 17 में 3+ वर्ष की पूर्व दोषसिद्धि के बाद पुनः अपराध करने पर अधिकतम क्या दंड दिया जा सकता है?",
      options: ["A. केवल 5 वर्ष कारावास", "B. आजीवन कारावास या 10 वर्ष तक का कारावास", "C. केवल जुर्माना", "D. केवल सामुदायिक सेवा"],
      correctIndex: 1,
      hint: "आदतन अपराधियों के लिए उम्रकैद या 10 वर्ष तक का कठोर कारावास।",
      explanation: "BNS की धारा 13 के अंतर्गत पूर्व दोषसिद्धि के पश्चात् पुनः उन्हीं अध्यायों में अपराध करने पर आजीवन कारावास या 10 वर्ष तक का कारावास हो सकता है।"
    },
    {
      id: "mcq_10",
      act: "Constitution",
      level: "Easy",
      topic: "Constitutional Remedies (Article 32)",
      q: "मौलिक अधिकारों के हनन पर कोई भी नागरिक संविधान के किस अनुच्छेद के तहत सीधे सुप्रीम कोर्ट में रिट याचिका दायर कर सकता है?",
      options: ["A. अनुच्छेद 14", "B. अनुच्छेद 19", "C. अनुच्छेद 32", "D. अनुच्छेद 226"],
      correctIndex: 2,
      hint: "डॉ. अम्बेडकर ने इसे संविधान की आत्मा कहा था।",
      explanation: "अनुच्छेद 32 के तहत सीधे सुप्रीम कोर्ट में और अनुच्छेद 226 के तहत हाई कोर्ट में मौलिक अधिकारों की रक्षा हेतु रिट दायर की जा सकती है।"
    }
  ],

  slidesDeck: [
    {
      num: 1,
      title: "Chapter Preliminary (प्रारंभिक)",
      section: "BNS 2023 — धारा 1 से 4 (Demo Slide)",
      slidesCount: "Slide 1 / 5",
      heading: "धारा 1: संक्षिप्त नाम, प्रारंभ और लागू होना",
      subtitle: "भारतीय न्याय संहिता (BNS) 2023 का परिचय",
      image: "assets/images/slide_dhara13_full.jpg",
      cards: [
        { title: "लागू होने की तिथि", body: "1 जुलाई 2024 से पूरे भारत में भारतीय दंड संहिता (IPC 1860) के स्थान पर लागू।" },
        { title: "क्षेत्रीय विस्तार", body: "सम्पूर्ण भारत के भीतर और भारत के बाहर भारतीय नागरिकों द्वारा किए गए अपराधों पर लागू।" },
        { title: "मुख्य बदलाव", body: "511 धाराओं के स्थान पर अब 358 सुव्यवस्थित धाराएं और 20 अध्याय।" },
        { title: "न्याय केंद्रित दृष्टिकोण", body: "दंड (Penal) के स्थान पर न्याय (Nyaya), पीड़ित अधिकार और समयबद्ध प्रक्रिया को प्राथमिकता।" }
      ]
    },
    {
      num: 2,
      title: "मुख्य कानूनी परिभाषाएं (धारा 2)",
      section: "BNS 2023 — धारा 2 (Demo Slide)",
      slidesCount: "Slide 2 / 5",
      heading: "धारा 2: प्रमुख कानूनी परिभाषाएं",
      subtitle: "वर्णमाला क्रम में सरल और स्पष्ट परिभाषाएं",
      image: "assets/images/banner_dhara2.jpg",
      cards: [
        { title: "बालक (Child) - धारा 2(3)", body: "18 वर्ष से कम आयु का कोई भी व्यक्ति 'बालक' कहलाएगा।" },
        { title: "इलेक्ट्रॉनिक रिकॉर्ड - धारा 2(8)", body: "डिजिटल साक्ष्य, ईमेल, मोबाइल मैसेज और सर्वर डेटा को कानूनी मान्यता।" },
        { title: "बेईमानी से (Dishonestly)", body: "किसी एक व्यक्ति को सदोष लाभ और दूसरे को सदोष हानि पहुंचाने के आशय से कार्य करना।" },
        { title: "कपटपूर्वक (Fraudulently)", body: "धोखा देने के आशय से किया गया कोई भी कार्य।" }
      ]
    },
    {
      num: 3,
      title: "सामान्य आशय (धारा 3(5))",
      section: "BNS 2023 — धारा 3(5) (Demo Slide)",
      slidesCount: "Slide 3 / 5",
      heading: "धारा 3(5): सामान्य आशय (Common Intention)",
      subtitle: "पूर्व IPC धारा 34 का नया और स्पष्ट रूप",
      image: "assets/images/player_scene_184.jpg",
      cards: [
        { title: "संयुक्त दायित्व", body: "जब कई व्यक्ति सामान्य आशय (Common Intention) से अपराध करते हैं, तो हर व्यक्ति समान रूप से दोषी है।" },
        { title: "पूर्व सहमति", body: "अपराध से पहले मस्तिष्क का मिलन (Meeting of Minds) आवश्यक है।" },
        { title: "सक्रिय भागीदारी", body: "भले ही वार एक ने किया हो, पहरा देने वाला सह-अभियुक्त भी बराबर का जिम्मेदार होगा।" },
        { title: "प्रमुख केस लॉ", body: "बारिन्द्र कुमार घोष बनाम किंग एम्परर (पोस्ट ऑफिस केस) एवं महबूब शाह केस।" }
      ]
    },
    {
      num: 4,
      title: "दंड के 6 प्रकार (धारा 4)",
      section: "BNS 2023 — धारा 4 (Demo Slide)",
      slidesCount: "Slide 4 / 5",
      heading: "धारा 4: दंड के 6 प्रकार (सामुदायिक सेवा सहित)",
      subtitle: "सुधारात्मक न्याय की दिशा में ऐतिहासिक कदम",
      image: "assets/images/slide_dhara13_full.jpg",
      cards: [
        { title: "गंभीर दंड", body: "मृत्युदंड (Death Penalty) तथा आजीवन कारावास (Imprisonment for Life)।" },
        { title: "कारावास के प्रकार", body: "कठोर कारावास (श्रम के साथ) और सादा कारावास।" },
        { title: "सामुदायिक सेवा (Community Service)", body: "छोटे अपराधों में पहली बार समाज सेवा को वैधानिक दंड के रूप में शामिल किया गया।" },
        { title: "जुर्माना व संपत्ति जब्ती", body: "आर्थिक दंड एवं अपराध से अर्जित संपत्ति की कुर्की/समपहरण।" }
      ]
    },
    {
      num: 5,
      title: "पूर्व दोषसिद्धि पर वर्धित दण्ड (धारा 13)",
      section: "BNS 2023 — धारा 13 (Demo Slide)",
      slidesCount: "Slide 5 / 5",
      heading: "धारा 13: पूर्व दोषसिद्धि के पश्चात् कतिपय अपराधों के लिए वर्धित दण्ड",
      subtitle: "दोषसिद्धि और अपराध की शर्तें — आदतन अपराधियों पर प्रहार",
      image: "assets/images/slide_dhara13_full.jpg",
      cards: [
        { title: "पहला अपराध और सजा", body: "व्यक्ति पहले भारत की किसी अदालत द्वारा अध्याय 10 या 17 के तहत दोषी पाया गया हो।" },
        { title: "दोबारा अपराध", body: "सजा काटने के बाद दोबारा उन्हीं अध्यायों (10 या 17) के तहत अपराध करना।" },
        { title: "3 वर्ष या उससे अधिक की सजा", body: "पिछला अपराध ऐसा होना चाहिए जिसमें कानूनन 3 साल या उससे ज्यादा की जेल का प्रावधान हो।" },
        { title: "वर्धित दण्ड: उम्रकैद या 10 वर्ष जेल", body: "दोबारा दोषी पाए जाने पर कोर्ट अपराधी को आजीवन कारावास या 10 वर्ष तक का कठोर कारावास सुना सकता है।" }
      ]
    }
  ],

  pdfQuizPages: [
    {
      page: 1,
      totalPages: 2,
      title: "1. भारतीय न्याय संहिता (BNS) एवं BNSS लिखित नोट्स व अभ्यास",
      subtitle: "Chapter Preliminary & FIR Rights — [DEMO STUDY SHEET]",
      image: "assets/images/pdf_quiz_page.jpg",
      questions: [
        {
          id: "pq1",
          q: "प्रश्न 1: भारतीय न्याय संहिता (BNS) 2023 की किस धारा में पहली बार 'सामुदायिक सेवा' (Community Service) को दंड के रूप में शामिल किया गया है?",
          options: ["(A) धारा 2", "(B) धारा 4", "(C) धारा 13", "(D) धारा 34"],
          correctIndex: 1,
          explanation: "BNS 2023 की धारा 4 में दंड के 6 प्रकार बताए गए हैं, जिनमें छठा प्रकार 'सामुदायिक सेवा' (Community Service) है।",
          extraInfo: "छोटे अपराधों में सुधारात्मक न्याय के लिए सामुदायिक सेवा का प्रावधान किया गया है।"
        },
        {
          id: "pq2",
          q: "प्रश्न 2: BNSS 2023 की किस धारा के अंतर्गत 'Zero FIR' और 'e-FIR' दर्ज करने का प्रावधान किया गया है?",
          options: ["(A) धारा 154", "(B) धारा 173", "(C) धारा 175", "(D) धारा 482"],
          correctIndex: 1,
          explanation: "भारतीय नागरिक सुरक्षा संहिता (BNSS) 2023 की धारा 173 संज्ञेय अपराधों में Zero FIR और e-FIR को कानूनी मान्यता देती है।",
          extraInfo: "e-FIR दर्ज कराने के बाद सूचनादाता को 3 दिनों के भीतर हस्ताक्षर करना आवश्यक होता है।"
        }
      ]
    },
    {
      page: 2,
      totalPages: 2,
      title: "2. विधिक करंट अफेयर्स एवं न्यायिक पहल (Demo PDF Page)",
      subtitle: "Supreme Court AI & Digital Justice Initiatives",
      image: "assets/images/pdf_quiz_page.jpg",
      questions: [
        {
          id: "pq3",
          q: "प्रश्न 3: न्यायिक डेटा प्रबंधन और नागरिकों की कानूनी सहायता हेतु AI पहल किस संस्था से जुड़ी है?",
          options: ["(A) सर्वोच्च न्यायालय (Supreme Court)", "(B) नीति आयोग", "(C) गृह मंत्रालय", "(D) वित्त मंत्रालय"],
          correctIndex: 0,
          explanation: "न्याय प्रणाली को तकनीक के माध्यम से अधिक पारदर्शी और सुलभ बनाने के लिए सुप्रीम कोर्ट द्वारा डिजिटल और AI पहल शुरू की गई है।",
          extraInfo: "ई-कोर्ट परियोजना और डिजिटल केस मैनेजमेंट से त्वरित न्याय में सहायता मिलती है।"
        }
      ]
    }
  ],

  mindMapNodes: [
    {
      id: "mm1",
      num: "1. प्रस्तावना एवं प्रारंभ (Preliminary)",
      color: "#7c3aed",
      points: ["BNS/BNSS/BSA: 1 जुलाई 2024 से लागू", "Contract Act: 1 सितंबर 1872 से लागू", "पूरे भारत और बाह्य क्षेत्राधिकार पर स्पष्ट नियम"]
    },
    {
      id: "mm2",
      num: "2. अपराध व अनुबंध के आवश्यक तत्त्व",
      color: "#2563eb",
      points: ["आपराधिक कार्य (Actus Reus) + दुराशय (Mens Rea)", "अनुबंध में: प्रस्ताव (Offer) + स्वीकृति (Acceptance)", "वैध प्रतिफल (Consideration) व स्वतंत्र सहमति"]
    },
    {
      id: "mm3",
      num: "3. दंड के 6 प्रकार (BNS धारा 4)",
      color: "#d97706",
      points: ["1. मृत्युदंड  2. आजीवन कारावास", "3. कठोर व सादा कारावास  4. संपत्ति समपहरण", "5. जुर्माना  6. सामुदायिक सेवा (Community Service)"]
    },
    {
      id: "mm4",
      num: "4. साधारण अपवाद व आत्मरक्षा (धारा 14–44)",
      color: "#16a34a",
      points: ["7 वर्ष से कम आयु के बालक का कार्य (धारा 20)", "विकृतचित्त व्यक्ति का कार्य (धारा 22)", "शरीर और संपत्ति की निजी प्रतिरक्षा (धारा 34–44)"]
    },
    {
      id: "mm5",
      num: "5. FIR एवं अन्वेषण प्रक्रिया (BNSS धारा 173)",
      color: "#9333ea",
      points: ["Zero FIR किसी भी थाने में दर्ज", "e-FIR (3 दिन में हस्ताक्षर)", "पीड़ित को निःशुल्क FIR प्रति का अधिकार"]
    },
    {
      id: "mm6",
      num: "6. जमानत एवं संवैधानिक उपचार",
      color: "#dc2626",
      points: ["रेगुलर बेल (धारा 480) व अग्रिम जमानत (धारा 482)", "24 घंटे में मजिस्ट्रेट के समक्ष पेशी (अनुच्छेद 22)", "सुप्रीम कोर्ट रिट (अनुच्छेद 32) व हाई कोर्ट (अनुच्छेद 226)"]
    }
  ],

  handwritingNotes: [
    {
      id: "hw1",
      title: "हस्तलिखित नोट्स: BNS 2023, BNSS एवं Public Law [DEMO]",
      subject: "भारतीय न्याय संहिता (BNS) 2023 — Classroom Handwritten Demo Notes",
      author: "GB Legal Mind Editorial Team",
      pages: [
        {
          pageNum: 1,
          heading: "पृष्ठ 1: भारतीय न्याय संहिता (BNS), 2023 — अध्याय 1 व 2 (शॉर्ट नोट्स)",
          date: "Demo Study Sheet — Page 1 / 2",
          lines: [
            "★ लागू होने की तिथि: 1 जुलाई 2024 (IPC 1860 की 511 धाराओं के स्थान पर अब 20 अध्याय और 358 धाराएं)।",
            "★ धारा 1 (संक्षिप्त नाम व विस्तार): यह संहिता सम्पूर्ण भारत पर लागू है। भारत से बाहर भारतीय नागरिक द्वारा किए गए अपराध पर भी BNS लागू होगी।",
            "★ धारा 2 (परिभाषाएं - Alphabetical Order में 1 से 39 तक):",
            "   • धारा 2(3) 'बालक' (Child): 18 वर्ष से कम आयु का कोई भी व्यक्ति।",
            "   • धारा 2(8) 'न्यायालय' (Court): न्यायिक कार्य करने वाले सभी न्यायाधीश व मजिस्ट्रेट।",
            "   • धारा 2(9) 'बेईमानी से' (Dishonestly): सदोष लाभ (Wrongful Gain) या सदोष हानि (Wrongful Loss) के आशय से कार्य।",
            "★ धारा 3(5) सामान्य आशय (Common Intention - Old IPC Sec 34):",
            "   जब कई व्यक्ति अपने सभी के सामान्य आशय को अग्रसर करने में कोई आपराधिक कार्य करते हैं, तो प्रत्येक व्यक्ति ऐसे दायित्व के अधीन होगा मानो वह कार्य उसने अकेले किया हो।",
            "★ धारा 4 (दंड के 6 प्रकार):",
            "   (1) मृत्युदंड  (2) आजीवन कारावास  (3) कारावास (कठोर/सादा)  (4) संपत्ति का समपहरण  (5) जुर्माना  (6) सामुदायिक सेवा (Community Service - नया दंड)।"
          ]
        },
        {
          pageNum: 2,
          heading: "पृष्ठ 2: धारा 13 (वर्धित दण्ड) एवं BNSS धारा 173 (FIR व Zero FIR)",
          date: "Demo Study Sheet — Page 2 / 2",
          lines: [
            "★ धारा 13 (Enhanced Punishment after Previous Conviction):",
            "   • शर्त 1: अभियुक्त पहले अध्याय 10 या अध्याय 17 (संपत्ति के विरुद्ध अपराध - चोरी, लूट) में 3 वर्ष या अधिक की सजा पा चुका हो।",
            "   • शर्त 2: सजा काटने के बाद दोबारा उन्हीं अध्यायों (10 या 17) में 3+ वर्ष की सजा वाला अपराध करे।",
            "   • वर्धित दंड: आजीवन कारावास (Life Imprisonment) या 10 वर्ष तक का कठोर कारावास।",
            "★ BNSS 2023 धारा 173 (FIR, Zero FIR एवं e-FIR):",
            "   • संज्ञेय अपराध (Cognizable Offence) की सूचना मौखिक या इलेक्ट्रॉनिक रूप से दी जा सकती है।",
            "   • Zero FIR: अपराध किसी भी थाना क्षेत्र में हुआ हो, पुलिस FIR दर्ज करने से मना नहीं कर सकती।",
            "   • e-FIR: इलेक्ट्रॉनिक सूचना देने के 3 दिन के भीतर सूचनादाता के हस्ताक्षर होने पर FIR प्रभावी।"
          ]
        }
      ]
    }
  ],

  reelsData: {
    bnsReels: [
      {
        id: "r_bns_1",
        sectionNum: 1,
        totalSections: 358,
        badge: "Section 1 (Demo Reel)",
        actName: "BNS 2023",
        headline: "BNS 2023 क्या है?",
        subheadline: "पूरी जानकारी आसान भाषा में — धारा 1",
        speaker: "Gulab Badshah",
        speakerRole: "Legal Mind of India (Demo Media)",
        caption: "BNS 2023 | Section 1 | इस Section में क्या है ? जानें आसान भाषा में #BNS #Section1 #Law #LegalAwareness",
        likes: "12.5K",
        comments: 320,
        duration: "01:08",
        currentTime: "00:12",
        image: "assets/images/reel_speaker.jpg"
      },
      {
        id: "r_bns_12",
        sectionNum: 12,
        totalSections: 358,
        badge: "Section 12 (Demo Reel)",
        actName: "BNS 2023",
        headline: "BNS 2023 धारा 12 क्या है?",
        subheadline: "पूरी जानकारी आसान भाषा में — एकांत परिरोध की सीमा",
        speaker: "Gulab Badshah",
        speakerRole: "Legal Mind of India (Demo Media)",
        caption: "BNS 2023 Section 12 | Is section ka simple explanation. #BNS #Section12 #LegalAwareness",
        likes: "15.2K",
        comments: 410,
        duration: "01:08",
        currentTime: "00:18",
        image: "assets/images/reel_speaker.jpg"
      },
      {
        id: "r_bns_13",
        sectionNum: 13,
        totalSections: 358,
        badge: "Section 13 (Demo Reel)",
        actName: "BNS 2023",
        headline: "धारा 13: आदतन अपराधियों को कड़ी सजा",
        subheadline: "दोबारा अपराध करने पर आजीवन कारावास या 10 वर्ष जेल",
        speaker: "Gulab Badshah",
        speakerRole: "Legal Mind of India (Demo Media)",
        caption: "BNS 2023 Section 13 | पूर्व दोषसिद्धि के बाद अपराध करने पर वर्धित दंड #BNS #Section13",
        likes: "18.4K",
        comments: 512,
        duration: "01:05",
        currentTime: "00:22",
        image: "assets/images/reel_speaker.jpg"
      }
    ],
    publicLawTopics: [
      { id: "pl_1", title: "अपराध की परिभाषा", headline: "अपराध क्या है?" },
      { id: "pl_2", title: "अपराध के प्रकार", headline: "संज्ञेय व असंज्ञेय अपराध" },
      { id: "pl_3", title: "अपराध का प्रयास", headline: "अपराध का प्रयास (Attempt)" },
      { id: "pl_4", title: "सामान्य आशय", headline: "सामान्य आशय (धारा 3(5))" },
      { id: "pl_5", title: "साजिश (Conspiracy)", headline: "आपराधिक षड्यंत्र क्या है?" },
      { id: "pl_6", title: "उकसावा (Abetment)", headline: "अपराध के लिए उकसाना" },
      { id: "pl_7", title: "आत्मरक्षा का अधिकार", headline: "आत्मरक्षा में कब सजा नहीं होती?" },
      { id: "pl_8", title: "राज्य के विरुद्ध अपराध", headline: "देश की संप्रभुता के विरुद्ध अपराध" },
      { id: "pl_9", title: "लोक सेवक से जुड़े अपराध", headline: "लोक सेवक के कर्तव्य और अपराध" },
      { id: "pl_10", title: "साइबर अपराध", headline: "ऑनलाइन ठगी पर तुरंत क्या करें?" },
      { id: "pl_11", title: "महिला एवं बच्चों के विरुद्ध अपराध", headline: "महिला एवं बाल संरक्षण कानून" },
      { id: "pl_12", title: "आर्थिक अपराध", headline: "धोखाधड़ी और आर्थिक अपराध" }
    ]
  },

  advocatesDirectory: [
    {
      id: "adv_rahul",
      name: "Adv. Rahul Sharma",
      fatherName: "Mr. Suresh Sharma",
      dob: "15 March 1992",
      gender: "Male",
      role: "Advocate (High Court)",
      type: "Advocate",
      city: "Prayagraj, Uttar Pradesh",
      state: "Uttar Pradesh",
      district: "Prayagraj",
      court: "Allahabad High Court, Prayagraj, UP",
      barCouncil: "Uttar Pradesh State Bar Council",
      barNo: "UP/12345/2016",
      enrollDate: "12 July 2016",
      enrollType: "Regular",
      barStatus: "Active (Demo)",
      advocateType: "Practicing Advocate",
      barCouncilId: "BCUP201612345",
      verificationStatus: "Verified Advocate (Demo Preview)",
      exp: "8+ Years Experience",
      practiceSince: "2016",
      natureOfPractice: "Independent Practice",
      rating: "4.8",
      reviewsCount: 256,
      distance: "1.5 km",
      fee: "₹149",
      langs: ["Hindi", "English", "Hinglish"],
      educationList: [
        { degree: "B.A. LL.B.", inst: "Allahabad University, Prayagraj", year: "2010 – 2015" },
        { degree: "LL.M. (Constitutional Law)", inst: "Allahabad University, Prayagraj", year: "2015 – 2016" }
      ],
      certifications: [
        "Diploma in Cyber Law – ILI (2018)",
        "Certificate Course in IPR – NALSAR (2019)",
        "Mediation & Conciliation Training (2020)",
        "Drafting & Pleading Workshop (2021)"
      ],
      practiceAreas: ["Civil Law", "Criminal Law", "Constitutional Law", "Family Law", "Property Law", "Consumer Law", "Labour & Service Law", "Motor Vehicle Law", "Banking & Finance Law", "Cyber Law", "RERA", "NCLT Matters", "Legal Drafting", "Court Representation", "Bail Matters"],
      courtsPracticing: ["Allahabad High Court", "District & Sessions Court", "Civil Court", "Criminal Court", "Family Court", "Labour Court", "Consumer Court", "NCLT", "Special Court (NDPS)"],
      officeDetails: {
        officeName: "Rahul Sharma & Associates",
        chamberNo: "25, Lawyers Chamber",
        address: "Allahabad High Court, Prayagraj, Uttar Pradesh – 211001",
        landmark: "Near Gate No. 3, High Court"
      },
      achievements: [
        "Regularly representing clients in Allahabad High Court",
        "Handled 500+ cases in Civil, Criminal and Constitutional matters",
        "Successfully argued several important bail matters",
        "Active participation in legal aid and social awareness programs",
        "Known for ethical practice and client-centric approach"
      ],
      consultationModes: ["Online Consultation (Google Meet / Zoom)", "Phone Call (Direct Call)", "In-Person (At Chamber / Office)", "Chat Support (Live Chat / WhatsApp)"],
      workingDays: "Monday to Saturday",
      availableTime: "10:30 AM – 5:30 PM",
      responseTime: "Usually within 24 hours",
      bio: "Dedicated to providing honest, practical and result-oriented legal advice with a focus on protecting clients' rights.",
      aboutLong: "Adv. Rahul Sharma is a practicing advocate with more than 8 years of experience in handling Civil, Criminal, Constitutional and other legal matters. He has been actively appearing before the Allahabad High Court and various District Courts in Uttar Pradesh."
    },
    {
      id: "adv_tejas",
      name: "Adv. Tejas Kapoor",
      fatherName: "Mr. R.K. Kapoor",
      dob: "10 June 1990",
      gender: "Male",
      role: "High Court Advocate",
      type: "Advocate",
      city: "North West Delhi",
      state: "Delhi",
      district: "North West Delhi",
      court: "Delhi High Court & Rohini District Court",
      barCouncil: "Bar Council of Delhi",
      barNo: "D/4512/2016",
      enrollDate: "20 August 2016",
      enrollType: "Regular",
      barStatus: "Active (Demo)",
      advocateType: "Practicing Advocate",
      barCouncilId: "BCD20164512",
      verificationStatus: "Verified Advocate (Demo Preview)",
      exp: "8+ years experience",
      practiceSince: "2016",
      natureOfPractice: "Independent Practice",
      rating: "4.8",
      reviewsCount: 120,
      distance: "3.2 km",
      fee: "₹299",
      langs: ["Hindi", "English"],
      educationList: [{ degree: "B.A. LL.B. (Hons.)", inst: "Faculty of Law, Delhi University", year: "2011 – 2016" }],
      certifications: ["Criminal Trial Advocacy Certificate"],
      practiceAreas: ["Criminal Law", "Bail Matter", "Court Practice", "Legal Research", "NDPS Act"],
      courtsPracticing: ["Delhi High Court", "District & Sessions Court"],
      officeDetails: { officeName: "Kapoor Law Chambers", chamberNo: "Chamber 108", address: "Rohini Court Complex, North West Delhi", landmark: "Gate No. 2" },
      achievements: ["Argued 300+ Bail & Criminal Revision petitions"],
      consultationModes: ["Online Consultation", "Phone Call", "In-Person", "Chat Support"],
      workingDays: "Monday to Saturday",
      availableTime: "10:00 AM – 6:00 PM",
      responseTime: "Within 2 hours",
      bio: "Experienced High Court Advocate specializing in Criminal Law, Bail Matters, and Trial Court Practice.",
      aboutLong: "Adv. Tejas Kapoor practices before the Delhi High Court and District Courts with a strong track record in criminal defense and bail matters."
    },
    {
      id: "adv_rajesh",
      name: "Adv. Rajesh Sharma",
      fatherName: "Mr. मोहन लाल शर्मा",
      dob: "04 April 1993",
      gender: "Male",
      role: "Criminal & Cheque Bounce Advocate",
      type: "Advocate",
      city: "Kakadeo, Kanpur, Uttar Pradesh",
      state: "Uttar Pradesh",
      district: "Kanpur Nagar",
      court: "Kanpur District & Sessions Court",
      barCouncil: "Uttar Pradesh State Bar Council",
      barNo: "UP/09821/2019",
      enrollDate: "15 May 2019",
      enrollType: "Regular",
      barStatus: "Active (Demo)",
      advocateType: "Practicing Advocate",
      barCouncilId: "BCUP20199821",
      verificationStatus: "Verified Advocate (Demo Preview)",
      exp: "5+ Years Experience",
      practiceSince: "2019",
      natureOfPractice: "Independent Practice",
      rating: "4.8",
      reviewsCount: 120,
      distance: "1.2 km",
      fee: "₹149",
      langs: ["Hindi", "English", "Hinglish"],
      educationList: [{ degree: "LL.B.", inst: "CSJM University, Kanpur", year: "2016 – 2019" }],
      certifications: ["NI Act & Commercial Litigation Workshop"],
      practiceAreas: ["Criminal Law", "Bail", "Cheque Bounce", "NDPS Act", "Court Practice"],
      courtsPracticing: ["District & Sessions Court Kanpur", "Civil Court"],
      officeDetails: { officeName: "Sharma Legal Associates", chamberNo: "14, Civil Lines", address: "Kakadeo, Kanpur, Uttar Pradesh", landmark: "Near District Court" },
      achievements: ["Handled 200+ Cheque Bounce (NI Act 138) and Bail cases"],
      consultationModes: ["Online Consultation", "Phone Call", "In-Person", "Chat Support"],
      workingDays: "Monday to Saturday",
      availableTime: "10:00 AM – 5:00 PM",
      responseTime: "Within 1 hour",
      bio: "Criminal Law, Bail, Cheque Bounce (NI Act Sec 138) & NDPS specialist in Kanpur, UP.",
      aboutLong: "Adv. Rajesh Sharma provides quick and practical legal representation in Kanpur District Court for bail, FIR, and cheque bounce matters."
    },
    {
      id: "adv_priya",
      name: "Adv. Priya Singh",
      fatherName: "Mr. Virendra Singh",
      dob: "22 August 1991",
      gender: "Female",
      role: "Family & Matrimonial Advocate",
      type: "Advocate",
      city: "Civil Lines, Kanpur / Lucknow, UP",
      state: "Uttar Pradesh",
      district: "Lucknow",
      court: "Family Court & High Court Lucknow Bench",
      barCouncil: "Uttar Pradesh State Bar Council",
      barNo: "UP/07412/2018",
      enrollDate: "10 July 2018",
      enrollType: "Regular",
      barStatus: "Active (Demo)",
      advocateType: "Practicing Advocate",
      barCouncilId: "BCUP20187412",
      verificationStatus: "Verified Advocate (Demo Preview)",
      exp: "6+ Years Experience",
      practiceSince: "2018",
      natureOfPractice: "Independent Practice",
      rating: "4.7",
      reviewsCount: 98,
      distance: "2.4 km",
      fee: "₹149",
      langs: ["Hindi", "English"],
      educationList: [{ degree: "B.A. LL.B.", inst: "Lucknow University", year: "2013 – 2018" }],
      certifications: ["Certified Family Mediator"],
      practiceAreas: ["Family Law", "Divorce", "Maintenance", "Domestic Violence", "Child Custody"],
      courtsPracticing: ["Family Court", "High Court Lucknow Bench", "District Court"],
      officeDetails: { officeName: "Priya Singh Law Chamber", chamberNo: "B-12, Family Court Block", address: "Civil Lines, Kanpur / Lucknow, UP", landmark: "Near Family Court" },
      achievements: ["Resolved 150+ matrimonial & domestic violence cases"],
      consultationModes: ["Online Consultation", "Phone Call", "In-Person", "Chat Support"],
      workingDays: "Monday to Saturday",
      availableTime: "11:00 AM – 6:00 PM",
      responseTime: "Within 2 hours",
      bio: "Specialist in Family Law, Divorce, Maintenance (BNSS 144), and Domestic Violence Act cases.",
      aboutLong: "Adv. Priya Singh is dedicated to empathetic and effective legal representation in family, matrimonial, and women's rights cases."
    },
    {
      id: "adv_rudra",
      name: "Adv. Rudra Thanapati",
      fatherName: "Mr. B. Thanapati",
      dob: "12 Jan 1986",
      gender: "Male",
      role: "District Court Advocate",
      type: "Advocate",
      city: "Balangir, Odisha",
      state: "Odisha",
      district: "Balangir",
      court: "District & Civil Court, Balangir",
      barCouncil: "Odisha State Bar Council",
      barNo: "OR/3310/2012",
      enrollDate: "14 Aug 2012",
      enrollType: "Regular",
      barStatus: "Active (Demo)",
      advocateType: "Practicing Advocate",
      barCouncilId: "BCOR20123310",
      verificationStatus: "Verified Advocate (Demo Preview)",
      exp: "12+ years experience",
      practiceSince: "2012",
      natureOfPractice: "Independent Practice",
      rating: "4.7",
      reviewsCount: 98,
      distance: "4.0 km",
      fee: "₹199",
      langs: ["Hindi", "English", "Odia"],
      educationList: [{ degree: "LL.B.", inst: "Utkal University", year: "2009 – 2012" }],
      certifications: ["Property & Revenue Law Specialist"],
      practiceAreas: ["Civil Law", "Property Law", "Documentation", "Court Practice"],
      courtsPracticing: ["District Court", "Civil Court", "Revenue Court"],
      officeDetails: { officeName: "Thanapati Law Office", chamberNo: "09", address: "Court Road, Balangir, Odisha", landmark: "Main District Court" },
      achievements: ["12+ years in Civil & Property Title Disputes"],
      consultationModes: ["Online Consultation", "Phone Call", "In-Person", "Chat Support"],
      workingDays: "Monday to Saturday",
      availableTime: "10:00 AM – 5:00 PM",
      responseTime: "Within 3 hours",
      bio: "Senior District Court Advocate for Civil Law, Property Disputes, Sale Deeds & Documentation.",
      aboutLong: "Adv. Rudra Thanapati has over 12 years of experience in civil litigation, land revenue matters, and legal documentation."
    }
  ],

  studentsDirectory: [
    {
      id: "stu_neha",
      name: "Neha Singh",
      course: "B.A. LL.B.",
      semester: "5th Semester",
      yearText: "3rd Year (5th Semester)",
      college: "LMN Law College",
      passingYear: "2027",
      city: "Varanasi, Uttar Pradesh",
      state: "Uttar Pradesh",
      distance: "2.1 km",
      rating: "4.8",
      reviewsCount: 120,
      verificationStatus: "Verified Student",
      openForInternship: true,
      preferredLocations: ["Varanasi, UP", "Lucknow, UP", "Delhi, Delhi"],
      preferredDuration: "1 – 6 Months",
      mode: "Online / Offline / Both",
      stipendPref: "Free Internship (I am willing to work without stipend)",
      langs: [
        { name: "Hindi", level: "Native" },
        { name: "English", level: "Good" },
        { name: "Hinglish", level: "Fluent" }
      ],
      skills: ["Legal Research", "Case Analysis", "Drafting", "Judgment Reading", "MS Word", "Communication", "Court Assistance"],
      interests: ["Criminal Law", "Constitutional Law", "Court Practice", "Legal Research", "Drafting", "Moot Court"],
      hobbies: ["Reading", "Writing", "Moot Court", "Music", "Travel", "Sports", "Current Affairs"],
      achievements: [
        "Participated in College Moot Court Competition (2024)",
        "Attended Workshop on Criminal Law (2024)",
        "Volunteered in Legal Aid Camp",
        "Published an article in College Legal Magazine"
      ],
      socialLinks: {
        youtube: "https://youtube.com/@nehasingh",
        instagram: "https://instagram.com/nehasingh",
        facebook: "https://facebook.com/nehasingh",
        website: "https://nehasinghportfolio.com"
      },
      resumeFile: "Resume.pdf (1.2 MB)",
      collegeIdFile: "College_ID.pdf (0.8 MB)",
      bio: "I am a dedicated law student with keen interest in Criminal Law, Constitutional Law and Court Practice. I am hardworking, quick learner and eager to gain practical exposure under a senior advocate.",
      aboutLong: "I am Neha Singh, currently pursuing B.A. LL.B. and I am in my 5th semester at LMN Law College, Varanasi. I have a strong interest in Criminal Law, Constitutional Law and Court Practice. I enjoy legal research, case analysis and developing my drafting skills."
    },
    {
      id: "stu_rohit",
      name: "Rohit Kumar",
      course: "B.A. LL.B.",
      semester: "5th Semester",
      yearText: "3rd Year (5th Semester)",
      college: "XYZ Law College",
      passingYear: "2027",
      city: "Kanpur, UP",
      state: "Uttar Pradesh",
      distance: "1.8 km",
      rating: "4.8",
      reviewsCount: 120,
      verificationStatus: "Verified Student",
      openForInternship: true,
      preferredLocations: ["Kanpur, UP", "Lucknow, UP", "Prayagraj, UP"],
      preferredDuration: "1 – 3 Months",
      mode: "Online / Offline / Both",
      stipendPref: "Free / Stipend Optional",
      langs: [
        { name: "Hindi", level: "Native" },
        { name: "English", level: "Fluent" }
      ],
      skills: ["Criminal Law", "Legal Research", "Drafting", "Moot Court", "Answer Writing"],
      interests: ["Criminal Law", "Moot Court", "Legal Research", "Answer Writing"],
      hobbies: ["Reading Judgments", "Debating", "Moot Court"],
      achievements: ["Winner - Intra-College Moot Court 2025", "Active Student Mentor for LL.B Entrance"],
      socialLinks: { youtube: "https://youtube.com/@rohitlaw", instagram: "https://instagram.com/rohitlaw" },
      resumeFile: "Rohit_Resume.pdf (1.1 MB)",
      collegeIdFile: "Rohit_ID.pdf (0.6 MB)",
      bio: "3rd Year B.A. LL.B. student at XYZ Law College, Kanpur. Passionate about Criminal Trial Research, BNS/BNSS Case Briefs, and Moot Courts.",
      aboutLong: "I am Rohit Kumar, pursuing B.A. LL.B. (5th Sem) in Kanpur. I assist junior students with study plans, notes, and exam preparation, and I am eager to intern with litigating advocates."
    },
    {
      id: "stu_priya",
      name: "Priya Singh",
      course: "LL.B.",
      semester: "3rd Semester",
      yearText: "2nd Year (3rd Semester)",
      college: "ABC University",
      passingYear: "2027",
      city: "Lucknow, UP",
      state: "Uttar Pradesh",
      distance: "2.3 km",
      rating: "4.7",
      reviewsCount: 98,
      verificationStatus: "Verified Student",
      openForInternship: true,
      preferredLocations: ["Lucknow, UP", "Delhi"],
      preferredDuration: "1 – 2 Months",
      mode: "Offline / Online",
      stipendPref: "Free Internship",
      langs: [
        { name: "Hindi", level: "Native" },
        { name: "English", level: "Good" }
      ],
      skills: ["Family Law", "Moot Court", "Legal Research", "Answer Writing", "Case Analysis"],
      interests: ["Family Law", "Civil Law", "Legal Research", "Drafting"],
      hobbies: ["Legal Writing", "Reading"],
      achievements: ["Published research note on Family Court Mediation"],
      socialLinks: { youtube: "", instagram: "" },
      resumeFile: "Priya_CV.pdf (0.9 MB)",
      collegeIdFile: "Priya_ID.pdf (0.7 MB)",
      bio: "Dedicated LL.B. student at ABC University, Lucknow with strong skills in Family Law research, case analysis, and Hindi-English drafting.",
      aboutLong: "Pursuing LL.B. at ABC University, Lucknow. Available for legal research, chamber internships, and student guidance."
    },
    {
      id: "stu_amit",
      name: "Amit Yadav",
      course: "B.A. LL.B.",
      semester: "4th Semester",
      yearText: "2nd Year (4th Semester)",
      college: "DEF Law College",
      passingYear: "2028",
      city: "Varanasi / Delhi",
      state: "Uttar Pradesh",
      distance: "3.0 km",
      rating: "4.6",
      reviewsCount: 86,
      verificationStatus: "Verified Student",
      openForInternship: true,
      preferredLocations: ["Varanasi, UP", "Delhi"],
      preferredDuration: "1 – 3 Months",
      mode: "Online / Offline",
      stipendPref: "Free Internship",
      langs: [
        { name: "Hindi", level: "Native" },
        { name: "English", level: "Good" }
      ],
      skills: ["Constitutional Law", "Legal Research", "Case Drafting", "Moot Court"],
      interests: ["Constitutional Law", "Moot Court", "Legal Research", "Answer Writing"],
      hobbies: ["Constitutional History", "Debate"],
      achievements: ["Semi-finalist in National Constitutional Law Quiz"],
      socialLinks: {},
      resumeFile: "Amit_Resume.pdf (1.0 MB)",
      collegeIdFile: "Amit_ID.pdf (0.5 MB)",
      bio: "B.A. LL.B. student focusing on Constitutional Writs, Fundamental Rights research, and Moot Court drafting.",
      aboutLong: "Enthusiastic law student open for chamber assistance and constitutional research internships."
    }
  ],

  advocatesOfferingInternship: [
    {
      id: "int_adv_1",
      advName: "Adv. Rajesh Kumar",
      role: "High Court Advocate",
      exp: "8+ Years Experience",
      location: "Lucknow, UP",
      rating: "4.8",
      reviews: 120,
      practiceAreas: ["Criminal Law", "Constitutional Law", "Civil Law", "Legal Research", "Case Drafting"],
      activities: ["Legal Research", "Drafting (Petitions, Applications)", "Case Preparation", "Court Proceedings", "Client Consultation", "Judgment Analysis"],
      preferredLocations: ["Lucknow (Main Office)", "Allahabad High Court", "Delhi (On Requirement)"],
      mode: "Both (Offline at Office/Court & Online Work from Home)",
      duration: "1 – 6 Months (Flexible)",
      seats: "2 – 5 (Seats Available)",
      stipend: "Paid Internship: ₹3,000 – ₹8,000 per month (As per work and performance)",
      eligibility: ["B.A. LL.B. / LL.B. Students", "3rd Semester onwards", "Sincere, hardworking and disciplined", "Interest in litigation and legal research"],
      preferredSkills: ["Basic Legal Research", "Court Procedure Knowledge", "Good Drafting Skills", "Communication Skills", "MS Word (Basic)", "Hindi / English (Preferred)"]
    },
    {
      id: "int_adv_2",
      advName: "Adv. Shalini Mishra",
      role: "District Court Advocate",
      exp: "5+ Years Experience",
      location: "Kanpur, UP",
      rating: "4.7",
      reviews: 98,
      practiceAreas: ["Family Law", "Civil Law", "Documentation", "Court Practice"],
      activities: ["Family Petition Drafting", "Mediation Briefs", "Client Counseling", "Court Visit"],
      preferredLocations: ["Kanpur District Court"],
      mode: "Offline / Hybrid",
      duration: "1 – 3 Months",
      seats: "2 – 3 Seats",
      stipend: "Paid Internship: ₹2,500 – ₹5,000 / month (Demo)",
      eligibility: ["LL.B. / B.A. LL.B. Students", "Good Hindi & English Drafting"],
      preferredSkills: ["Drafting", "Legal Research", "MS Word"]
    },
    {
      id: "int_adv_3",
      advName: "Adv. Vikram Singh",
      role: "High Court Advocate",
      exp: "10+ Years Experience",
      location: "Delhi, Delhi",
      rating: "4.6",
      reviews: 86,
      practiceAreas: ["Constitutional Law", "Legal Research", "Case Drafting", "Moot Court"],
      activities: ["Writ Petition Research", "Case Law Compilation", "Brief Preparation"],
      preferredLocations: ["Delhi High Court", "Online Remote"],
      mode: "Both (Online & Offline)",
      duration: "1 – 4 Months",
      seats: "4 Seats",
      stipend: "Paid Internship: ₹4,000 – ₹7,000 / month (Demo)",
      eligibility: ["B.A. LL.B. / LL.B. Students"],
      preferredSkills: ["Constitutional Research", "Judgment Reading", "English Drafting"]
    },
    {
      id: "int_adv_4",
      advName: "Adv. Aakash Verma",
      role: "Supreme Court Advocate",
      exp: "12+ Years Experience",
      location: "Noida, UP / New Delhi",
      rating: "4.5",
      reviews: 74,
      practiceAreas: ["Corporate Law", "Tax Law", "Research Work", "Drafting"],
      activities: ["SLPSynopsis Drafting", "Corporate Contract Review", "Legal Research"],
      preferredLocations: ["Noida / Supreme Court Chamber"],
      mode: "Hybrid",
      duration: "2 – 6 Months",
      seats: "3 Seats",
      stipend: "Paid Internship: ₹5,000 – ₹10,000 / month (Demo)",
      eligibility: ["Final / Pre-final Year Law Students"],
      preferredSkills: ["Corporate Law", "Legal Research", "Drafting"]
    }
  ],

  // Requirement 11: Consulting means LIVE USER-TO-USER CHAT (Local Demo Conversations)
  consultingConversations: [
    {
      id: "conv_gulab",
      participantName: "Advocate Gulab Badshah",
      participantRole: "Advocate • Founder GB Legal Mind",
      participantCategory: "Advocate",
      online: true,
      avatar: "👨‍⚖️",
      unreadCount: 0,
      busyNotice: "Gulab Badshah Sir abhi legal consultation, court work ya important meeting mein busy ho sakte hain. Aapka message successfullyreceive ho gaya hai. Jald hi aapko reply diya jayega.",
      replyTimeText: "Usually replies within 30 min – 2 hrs",
      messages: [
        { id: "m1", sender: "me", text: "Hello Sir, I need your guidance regarding a property dispute.", time: "10:20 AM", status: "read" },
        { id: "m2", sender: "them", text: "Hello Aman, please share the details of your case. I'll help you with the best possible advice.", time: "10:21 AM", status: "read" },
        { id: "m3", sender: "me", text: "Here is the sale deed and agreement related to the property.", time: "10:22 AM", status: "read" },
        { id: "m4", sender: "me", text: "Sale_Deed.pdf", isFile: true, fileType: "PDF", fileSize: "2.4 MB", time: "10:22 AM", status: "read" }
      ]
    },
    {
      id: "conv_rahul",
      participantName: "Adv. Rahul Sharma",
      participantRole: "High Court Advocate • Prayagraj",
      participantCategory: "Advocate",
      online: true,
      avatar: "⚖️",
      unreadCount: 1,
      busyNotice: "Adv. Rahul Sharma is available for live chat consultation and case guidance (Demo).",
      replyTimeText: "Usually replies within 15 – 45 mins",
      messages: [
        { id: "rm1", sender: "me", text: "नमस्ते सर, BNSS की धारा 482 के तहत अग्रिम जमानत (Anticipatory Bail) के लिए क्या दस्तावेज लगेंगे?", time: "Yesterday", status: "read" },
        { id: "rm2", sender: "them", text: "नमस्ते! अग्रिम जमानत के लिए FIR की कॉपी, आधार कार्ड, निवास प्रमाण और शपथ-पत्र (Affidavit) की आवश्यकता होगी। आप यहाँ PDF भी शेयर कर सकते हैं।", time: "09:15 AM", status: "read" }
      ]
    },
    {
      id: "conv_neha",
      participantName: "Neha Singh (Law Student)",
      participantRole: "B.A. LL.B. (5th Sem) • LMN Law College",
      participantCategory: "Student",
      online: true,
      avatar: "🎓",
      unreadCount: 0,
      busyNotice: "Neha Singh is available for Law Study, Moot Court & Internship discussions (Demo).",
      replyTimeText: "Active Now",
      messages: [
        { id: "nm1", sender: "me", text: "Hi Neha, BNS 2023 और IPC के मुख्य बदलावों के नोट्स पर चर्चा कर सकते हैं?", time: "11:05 AM", status: "read" },
        { id: "nm2", sender: "them", text: "हाँ बिल्कुल! मैंने BNS धारा 1 से 103 तक के शॉर्ट नोट्स और केस ब्रीफ तैयार किए हैं। आप अपना सवाल पूछ सकते हैं।", time: "11:06 AM", status: "read" }
      ]
    },
    {
      id: "conv_aman",
      participantName: "Aman Verma (General User)",
      participantRole: "General User • Citizen Member",
      participantCategory: "User",
      online: false,
      avatar: "👤",
      unreadCount: 0,
      busyNotice: "User-to-User Community Legal Discussion (Demo Mode).",
      replyTimeText: "Last seen 20 mins ago",
      messages: [
        { id: "am1", sender: "them", text: "भाई, इस ऐप में Zero FIR वाला वीडियो और PDF नोट्स बहुत काम के हैं!", time: "Yesterday", status: "read" },
        { id: "am2", sender: "me", text: "हाँ, Public Law सेक्शन में स्टेप-बाय-स्टेप पूरी प्रक्रिया आसान हिंदी में दी गई है।", time: "Yesterday", status: "read" }
      ]
    }
  ],

  diaryCases: [
    {
      id: "c1",
      caseNo: "ST No. 412/2026",
      title: "State of UP vs. Ramesh Kumar",
      court: "District & Sessions Court, Lucknow",
      section: "BNS Sec 103 & 3(5)",
      nextDate: "2026-10-24",
      reminderTime: "09:00 AM",
      stage: "Cross-Examination (PW-2)",
      client: "Ramesh Kumar",
      notes: "Prepare contradiction points from FIR (BNSS Sec 173) and medical report."
    },
    {
      id: "c2",
      caseNo: "Civil Suit 89/2026",
      title: "Smt. Kavita Devi vs. Mohan Lal",
      court: "Civil Judge (Senior Division)",
      section: "Specific Relief & Temporary Injunction",
      nextDate: "2026-10-28",
      reminderTime: "10:00 AM",
      stage: "Interim Stay Argument (Order 39 Rule 1 & 2)",
      client: "Smt. Kavita Devi",
      notes: "File certified copy of Khatauni and boundary map."
    },
    {
      id: "c3",
      caseNo: "Misc Bail 1104/2026",
      title: "Arjun Singh vs. State",
      court: "High Court Bench",
      section: "BNSS Sec 482 (Anticipatory Bail)",
      nextDate: "2026-11-04",
      reminderTime: "10:30 AM",
      stage: "Case Diary Awaited",
      client: "Arjun Singh",
      notes: "Affidavit and no-criminal-history annexure filed."
    }
  ],

  studentNotesList: [
    {
      id: "sn1",
      title: "BNS 2023 vs IPC 1860 — Top 10 Section Changes",
      subject: "BNS 2023",
      updated: "2026-10-16",
      content: "1. IPC 302 (Murder) -> BNS Section 103\n2. IPC 307 (Attempt to Murder) -> BNS Section 109\n3. IPC 420 (Cheating) -> BNS Section 318(4)\n4. IPC 376 (Rape) -> BNS Section 64\n5. IPC 34 (Common Intention) -> BNS Section 3(5)\n6. IPC 124A (Sedition repealed) -> BNS Section 152\n7. Community Service added under BNS Section 4."
    },
    {
      id: "sn2",
      title: "FIR, Zero FIR & e-FIR Procedure under BNSS Section 173",
      subject: "BNSS 2023",
      updated: "2026-10-15",
      content: "• BNSS Section 173 replaces CrPC Section 154.\n• Zero FIR: Police must register cognizable offence regardless of territorial jurisdiction.\n• e-FIR: Information sent electronically must be taken on record after signature within 3 days.\n• Refusal Remedy: Send application to SP under Sec 173(4), then Magistrate under Sec 175(3)."
    },
    {
      id: "sn3",
      title: "Electronic Evidence Certificate — BSA Section 63",
      subject: "BSA 2023",
      updated: "2026-10-14",
      content: "• Replaces Section 65B of the old Indian Evidence Act 1872.\n• Digital records (WhatsApp chats, emails, CCTV footage, server logs) are recognized as Primary Evidence under Section 57.\n• Requires Part A (User/In-charge) and Part B (Expert) certificate under Section 63(4) Schedule."
    }
  ],

  notificationsList: [
    { id: "n1", title: "नया लेक्चर: BNS धारा 13 (वर्धित दण्ड) स्लाइड और ऑडियो जोड़ा गया", time: "2 hours ago", type: "Study Update", unread: true },
    { id: "n2", title: "Consulting Live Chat: Advocate Gulab Badshah ने आपके संदेश का उत्तर दिया", time: "3 hours ago", type: "Live Chat", unread: true },
    { id: "n3", title: "MCQ Mock Test: All Mix Test - 09 के नए अभ्यास प्रश्न उपलब्ध हैं", time: "Yesterday", type: "Quiz Alert", unread: true }
  ]
};

// Automatic Base64 Asset Resolver for Standalone Chrome / Offline Mode
(function resolveInlineAssets(obj) {
  if (!window.__GB_B64 || !obj || typeof obj !== "object") return;
  Object.keys(obj).forEach(function (k) {
    var v = obj[k];
    if (typeof v === "string" && window.__GB_B64[v]) {
      obj[k] = window.__GB_B64[v];
    } else if (v && typeof v === "object") {
      resolveInlineAssets(v);
    }
  });
})(window.GB_DATA);

