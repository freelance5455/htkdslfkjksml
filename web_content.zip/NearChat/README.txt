NearChat — Offline Messenger Demo

HOW TO USE
1. Extract the ZIP file.
2. Open index.html in a browser (Chrome recommended).
3. Add contacts, create groups, and send demo messages.
4. Your chats are stored locally in this browser on this device.

IMPORTANT LIMITATION
This is an offline UI/demo, not a real WhatsApp replacement. Texts typed here are stored on this device only and do not reach another phone. Real phone-to-phone messaging, voice calls, and video calls cannot work with no connection at all. To communicate between nearby devices without internet, both devices would need a shared local connection (such as Wi-Fi Direct/Bluetooth) and a native app/backend implementation. Internet-based calls/messages require network access.

To reset demo data, clear this site's browser storage.
