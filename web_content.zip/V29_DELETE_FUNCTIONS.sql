-- V29: secure deletion functions. Run once in Supabase SQL Editor.

create or replace function public.delete_teacher_recitation(p_recitation_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare v_ok boolean;
begin
  select exists(
    select 1 from public.recitations r
    join public.students s on s.id=r.student_id
    join public.circles c on c.id=s.circle_id
    where r.id=p_recitation_id and c.teacher_id=auth.uid()
  ) into v_ok;
  if not v_ok then raise exception 'غير مسموح بحذف هذا السجل'; end if;
  delete from public.recitations where id=p_recitation_id;
  return true;
end; $$;

create or replace function public.delete_teacher_circle(p_circle_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare v_ok boolean;
begin
  select exists(select 1 from public.circles where id=p_circle_id and teacher_id=auth.uid()) into v_ok;
  if not v_ok then raise exception 'غير مسموح بحذف هذه الحلقة'; end if;

  delete from public.recitations r
  using public.students s
  where r.student_id=s.id and s.circle_id=p_circle_id;
  delete from public.attendance where circle_id=p_circle_id;
  delete from public.daily_reports where circle_id=p_circle_id;
  delete from public.students where circle_id=p_circle_id;
  delete from public.circles where id=p_circle_id and teacher_id=auth.uid();
  return true;
end; $$;

create or replace function public.delete_all_teacher_data()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  delete from public.recitations r
  using public.students s, public.circles c
  where r.student_id=s.id and s.circle_id=c.id and c.teacher_id=auth.uid();
  delete from public.attendance a using public.circles c where a.circle_id=c.id and c.teacher_id=auth.uid();
  delete from public.daily_reports d using public.circles c where d.circle_id=c.id and c.teacher_id=auth.uid();
  delete from public.students s using public.circles c where s.circle_id=c.id and c.teacher_id=auth.uid();
  delete from public.circles where teacher_id=auth.uid();
  return true;
end; $$;

revoke all on function public.delete_teacher_recitation(uuid) from public;
revoke all on function public.delete_teacher_circle(uuid) from public;
revoke all on function public.delete_all_teacher_data() from public;
grant execute on function public.delete_teacher_recitation(uuid) to authenticated;
grant execute on function public.delete_teacher_circle(uuid) to authenticated;
grant execute on function public.delete_all_teacher_data() to authenticated;

notify pgrst, 'reload schema';
