package com.example.volleyballlan;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private WebView web;
    private LanBridge bridge;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512 | 4096);
        web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        bridge = new LanBridge(this, web);
        web.addJavascriptInterface(bridge, "LanBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onDestroy() {
        if (bridge != null) bridge.shutdown();
        if (web != null) { web.removeJavascriptInterface("LanBridge"); web.destroy(); }
        super.onDestroy();
    }

    public static class LanBridge {
        private static final String TAG = "LanBridge";
        private static final String TYPE = "_volleylan._tcp.";
        private static final int PORT = 38765;
        private final Activity activity;
        private final WebView web;
        private final NsdManager nsd;
        private final ExecutorService io = Executors.newCachedThreadPool();
        private final Map<String, Peer> peers = new ConcurrentHashMap<>();
        private volatile ServerSocket server;
        private volatile Socket client;
        private volatile NsdManager.RegistrationListener registration;
        private volatile NsdManager.DiscoveryListener discovery;
        private volatile String roomCode = "";
        private volatile boolean hosting = false;
        private final AtomicBoolean closed = new AtomicBoolean(false);

        LanBridge(Activity a, WebView w) { activity=a; web=w; nsd=(NsdManager)a.getSystemService(Context.NSD_SERVICE); }

        @JavascriptInterface public boolean startHost(String code) {
            stopAll(); roomCode = cleanCode(code); if (!roomCode.matches("\\d{6}")) return false;
            hosting = true; closed.set(false);
            try {
                server = new ServerSocket(PORT);
                io.execute(() -> acceptLoop());
                NsdServiceInfo info = new NsdServiceInfo();
                info.setServiceName("VB-" + roomCode); info.setServiceType(TYPE); info.setPort(PORT);
                registration = new NsdManager.RegistrationListener() {
                    public void onServiceRegistered(NsdServiceInfo s) { roomCode = s.getServiceName().replace("VB-", ""); }
                    public void onRegistrationFailed(NsdServiceInfo s, int e) { callback("onError", "register"); }
                    public void onServiceUnregistered(NsdServiceInfo s) {}
                    public void onUnregistrationFailed(NsdServiceInfo s, int e) {}
                };
                nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, registration);
                return true;
            } catch (Exception e) { Log.e(TAG,"startHost",e); stopAll(); return false; }
        }

        @JavascriptInterface public void join(String code) {
            roomCode = cleanCode(code);
            if (!roomCode.matches("\\d{6}")) { callback("onError","notfound"); return; }
            stopDiscovery();
            discovery = new NsdManager.DiscoveryListener() {
                public void onDiscoveryStarted(String t) {}
                public void onServiceFound(NsdServiceInfo s) {
                    if (!s.getServiceName().equals("VB-" + roomCode)) return;
                    try { nsd.resolveService(s, new NsdManager.ResolveListener() {
                        public void onResolveFailed(NsdServiceInfo x, int e) { callback("onError","notfound"); }
                        public void onServiceResolved(NsdServiceInfo x) { stopDiscovery(); connect(x.getHost(), x.getPort()); }
                    }); } catch (Exception e) { callback("onError","resolve"); }
                }
                public void onServiceLost(NsdServiceInfo s) {}
                public void onDiscoveryStopped(String t) {}
                public void onStartDiscoveryFailed(String t,int e) { stopDiscovery(); callback("onError","notfound"); }
                public void onStopDiscoveryFailed(String t,int e) { stopDiscovery(); }
            };
            try { nsd.discoverServices(TYPE, NsdManager.PROTOCOL_DNS_SD, discovery); }
            catch (Exception e) { callback("onError","notfound"); }
        }

        private void connect(InetAddress host, int port) {
            io.execute(() -> {
                try {
                    Socket s = new Socket(host, port); client=s;
                    Peer p = new Peer("host", s); peers.put("host",p);
                    callback("onPeer", "host"); readLoop(p);
                } catch (Exception e) { Log.e(TAG,"connect",e); callback("onError","notfound"); }
            });
        }

        private void acceptLoop() {
            while (hosting && server != null && !server.isClosed()) {
                try {
                    Socket s = server.accept();
                    String id = "peer-" + System.nanoTime(); Peer p = new Peer(id,s); peers.put(id,p);
                    callback("onPeer",id); io.execute(() -> readLoop(p));
                } catch (Exception e) { if (hosting) Log.e(TAG,"accept",e); break; }
            }
        }

        private void readLoop(Peer p) {
            try {
                String line; while ((line=p.in.readLine()) != null) callback("onMsg", p.id, line);
            } catch (Exception ignored) {}
            finally { peers.remove(p.id); try { p.socket.close(); } catch(Exception ignored){} callback("onClose",p.id); }
        }

        @JavascriptInterface public void send(String id, String message) {
            if (message == null) return;
            if (hosting) {
                Peer p = peers.get(id); if (p != null) p.write(message);
            } else {
                Peer p = peers.get("host"); if (p != null) p.write(message);
            }
        }
        @JavascriptInterface public void close(String id) { Peer p=peers.remove(id); if(p!=null)p.close(); }
        @JavascriptInterface public void leave() { if (!hosting) { for(Peer p:peers.values())p.close(); peers.clear(); stopDiscovery(); } }
        @JavascriptInterface public void stopHost() { hosting=false; if(server!=null)try{server.close();}catch(Exception ignored){}; if(registration!=null)try{nsd.unregisterService(registration);}catch(Exception ignored){}; for(Peer p:peers.values())p.close(); peers.clear(); }
        @JavascriptInterface public void shutdown() { stopAll(); io.shutdownNow(); }

        private void stopAll() { stopHost(); stopDiscovery(); if(client!=null)try{client.close();}catch(Exception ignored){} }
        private void stopDiscovery() { if(discovery!=null)try{nsd.stopServiceDiscovery(discovery);}catch(Exception ignored){} discovery=null; }
        private String cleanCode(String c) { return c==null?"":c.replaceAll("[^0-9]",""); }
        private void callback(String name, String... args) {
            StringBuilder js=new StringBuilder("(function(){var h=window.__lan;if(!h||!h['").append(name).append("'])return;h['").append(name).append("'](");
            for(int i=0;i<args.length;i++){ if(i>0)js.append(','); js.append('"').append(escape(args[i])).append('"'); }
            js.append(");})();"); activity.runOnUiThread(() -> { if(web!=null) web.evaluateJavascript(js.toString(),null); });
        }
        private String escape(String s) { return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r"); }
        private class Peer {
            final String id; final Socket socket; final BufferedReader in; final BufferedWriter out;
            Peer(String i,Socket s)throws Exception{id=i;socket=s;in=new BufferedReader(new InputStreamReader(s.getInputStream(),"UTF-8"));out=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(),"UTF-8"));}
            synchronized void write(String m){try{out.write(m.replace("\n", " "));out.write("\n");out.flush();}catch(Exception e){close();}}
            void close(){try{socket.close();}catch(Exception ignored){}}
        }
    }
}
