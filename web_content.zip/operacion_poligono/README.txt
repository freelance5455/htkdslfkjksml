OPERACIÓN: POLÍGONO — PROTOTIPO FPS MÓVIL
========================================

Qué incluye
-----------
- Juego HTML5 autocontenido (sin descargas ni conexión a Internet).
- Cámara en primera persona y escenario 2.5D de entrenamiento.
- Complejo urbano pequeño con edificios, pasillos y coberturas.
- Figuras ficticias y blancos de práctica.
- Joystick táctil, giro de cámara, disparo, recarga, salto y carrera.
- Minimapa, puntuación y munición.
- Controles de teclado para probarlo en PC.

Cómo probarlo
-------------
1. Extrae el ZIP.
2. Abre app/src/main/assets/index.html en un navegador moderno.
3. En celular, gira la pantalla a horizontal. En algunos Android, para abrir
   archivos locales puede ser más sencillo usar el proyecto Android incluido.

Cómo generar un APK con Android Studio
---------------------------------------
1. Abre la carpeta del proyecto en Android Studio.
2. Espera a que Android Studio sincronice Gradle y descargue el plugin de Android
   si hace falta conexión a Internet.
3. Usa Build > Build Bundle(s) / APK(s) > Build APK(s).
4. El APK de depuración suele quedar en app/build/outputs/apk/debug/.

Limitaciones honestas
---------------------
Esto es un prototipo original y ligero, no el juego Warzone Mobile ni una copia
exacta de sus mapas, personajes, modelos, sonidos o código. Es una demo HTML5
2.5D que sirve como base para ampliar. No contiene assets oficiales ni requiere
un paquete de 1 GB: inflar el tamaño no añade calidad.

Controles
---------
Celular: joystick izquierdo para moverte; desliza el lado derecho para mirar;
FUEGO para disparar; RECARGA para recargar; SALTO y CORRER para moverte.
PC: WASD para moverte, mouse/arrastre para mirar, clic o espacio para disparar,
R para recargar y Shift para correr.
