CardLedger v9.1 - installable app with cloud sync
Based on the frozen v9.0 design (CardLedger_v9_FROZEN.html). No v10.

STATUS (honest)
- Sync logic tested only against a simulated Supabase server (14 checks), NOT against a real Supabase project.
- Install on phone/laptop, offline use and phone layout are NOT yet tested on real devices.
- Not included from v8: statement reconciliation, CSV import, statement file registration.

FIXES IN THIS BUILD (found in your testing)
- People, Transactions filters and Cards & bills now show only what belongs to the selected ledger. 'Show all cards' reveals the rest.
- Overview: months can be deselected one by one, or all at once with Clear all. No selection shows zeros.
- Names match ignoring capitals and extra spaces (Suma = SUMA = ' suma ').
- v8 data in the same browser is now picked up automatically on first load (it silently failed before).

TIDY-UP IN THIS BUILD
- Ledgers can be renamed (ledger page and Settings). Month names are rewritten to 'October 2026' from 'oct 26', 'Oct-26', '10/2026', '2026-10'. Duplicates of the same month are refused.
- Ledger lists are newest month first everywhere; custom-named ledgers follow, in creation order.
- Names tidied: people (suma, SUMA -> Suma) and all-lowercase merchants (myntra -> Myntra). Acronyms like HPCL are kept.
- New transactions default to a date inside the ledger's month; a date outside it asks first.
- Forms put the cursor in the first field. People with no activity can be removed. Duplicate cards are refused.

ADDED LATER
- Other people box: a name alone ('Daddy') gets everything left after your personal portion. One person may be left without an amount; the rest need amounts.
- Savings / bank accounts: a 'Savings / Personal' account is provided and shows in the card dropdown. Add or edit more via Cards & bills > Add card / account. Accounts have no credit limit, billing date or repayments and are left out of utilization and liability.
- Log refund: a button on Transactions and the ledger page. Pick the purchase, whose items, amount (or full remaining), date and a note. A Refund log table lists them with Edit and Delete.

SPLITTING AND LABEL
- Other people box: names alone share what is left equally (to the paisa). Amounts can follow the name with any separator or none: Daddy 856, daddy... 9875, Daddy, 09754, Daddy: 856.
- 'My portion' choice: a specific amount, full purchase is mine, or equal share with the people listed (you count as one of them).
- Your own share label ('Mine') can be renamed from the Overview panel (pencil link) or Settings > Your label. The Overview right-hand panel now shows your personal expenses above who owes you.

WHATSAPP
- People tab: four ready-made templates (Friendly, Short & sweet, Gentle nudge, Formal) under 'Edit message template'. 'Open in WhatsApp' sends the text to WhatsApp; pick the chat there.
- 'Message to myself' panel (People tab, also via 'Message myself' on the ledger page) gives a summary of the ledger for your own WhatsApp.
- Refunds appear in the person's message on their own lines, in 'Refunds applied', and reduce 'Total outstanding'.

PHONE
- Tables become readable cards on phones; People buttons sit under each name.

PEOPLE, CARDS, PURCHASE FORM (latest)
- People tab: your own row (tagged Me) and 'Mine (Me)' in the WhatsApp dropdown give your own statement.
- Card dropdown is ordered by how often each card or account is used.
- Add transaction: choose Just me / Someone else / Shared with me, tap people, split equally or enter amounts. 'Prefer typing?' keeps the manual box.

LATEST ADDITIONS
- WhatsApp messages and Transactions tab follow the order you logged purchases (selector for newest date first).
- Merchant box: chips (5 most-used merchants, then latest) and type-ahead. Learned only from your own purchases.
- Settings > Payment QR code: save your QR; People > 'Share with QR image' sends it with the message. {qr} placeholder in templates.
- People > 'Record payment received' (or Collect on a person's row): type an amount (applied oldest first) or tick purchases. Payments received log below.
- Refunds: choose the card or account the refund went to (most used first) and add comments.

SYNC FIX
- A change made during an upload is no longer lost; overlapping 'Sync now' requests are queued.

SET-UP (about 15 minutes)
1. Create a free project at supabase.com. Open SQL Editor, paste supabase_setup.sql, Run.
2. Project Settings > API: copy the Project URL and the anon public key. Never use the service_role key.
3. (Optional) Authentication > Providers > Email: turn off "Confirm email" if you want instant sign-up.
4. Host this whole folder over HTTPS (needed for installing as an app and offline use). Easiest: drag the folder onto app.netlify.com/drop, or use Cloudflare Pages / GitHub Pages. Open the https address it gives you.
5. First device: in your current v9 file, Settings > Download backup. In the hosted app, Settings > Restore backup. Then Settings > Cloud sync: paste URL and key, enter email and a password, press Create account (or Sign in).
6. Other devices: open the same address, enter the same URL, key, email, password, Sign in. Local empty data is replaced by the cloud copy.

INSTALL AS AN APP
- Android Chrome: menu > Install app. iPhone Safari: Share > Add to Home Screen. Laptop Chrome: install icon in the address bar.

HOW SYNC BEHAVES
- Each save uploads after about 1.5 seconds, when online and signed in. Offline changes wait and upload when you are back online.
- The cloud copy has a version number. If two devices changed the same data, a dialog lets you pick the cloud copy or this device. Nothing is overwritten silently.
- Data is stored in your Supabase project, protected by row-level security, but not end-to-end encrypted.
- Keep downloading backups now and then.
