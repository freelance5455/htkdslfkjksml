-- Run once in Supabase: SQL Editor > New query > paste > Run
create table if not exists public.cardledger_state (
  user_id uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  data jsonb not null,
  version integer not null default 1,
  updated_at timestamptz not null default now()
);
alter table public.cardledger_state enable row level security;
create policy "own row read"   on public.cardledger_state for select using (user_id = auth.uid());
create policy "own row insert" on public.cardledger_state for insert with check (user_id = auth.uid());
create policy "own row update" on public.cardledger_state for update using (user_id = auth.uid()) with check (user_id = auth.uid());
