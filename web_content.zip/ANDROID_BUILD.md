# World Conquest — Android APK hazırlığı

Bu paket, mevcut web oyununu Android uygulamasına dönüştürmek için Capacitor projesi olarak hazırlandı. Oyun dosyaları `www/` klasöründe korunmuştur.

## Gereksinimler
- Node.js 20 veya üzeri ve npm
- Android Studio (Android SDK ve Build Tools dahil)
- Android Studio'nun önerdiği uyumlu JDK (genellikle JDK 21)

## İlk kurulum
Proje klasöründe terminal açın:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio açıldığında Gradle senkronizasyonunun tamamlanmasını bekleyin. APK oluşturmak için **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin. Oluşan APK yolunu Android Studio bildirecektir.

Komut satırından debug APK almak için (Android SDK/JDK ayarlandıktan sonra):

```bash
npm run cap:sync
cd android
./gradlew assembleDebug
```
Windows'ta son komut `gradlew.bat assembleDebug` şeklindedir. Debug APK genellikle `android/app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

## Önemli notlar
- Bu çalışma ortamında Android SDK/Gradle kurulumu bulunmadığından derlenmiş `.apk` dosyası üretilemedi; proje APK derlemesine hazır bir başlangıç paketidir.
- `android/` klasörü ilk kurulumda `npx cap add android` komutuyla üretilir. Bu nedenle Android Studio ve SDK gereklidir.
- Uygulama kimliği `com.worldconquest.game` olarak ayarlandı. Yayın öncesi isterseniz kendi benzersiz paket kimliğinizle değiştirin.
- Bu paket, oyunun performans sorunlarını kendiliğinden çözmez; yalnızca Android uygulama kabuğu ve derleme yapılandırmasını sağlar.
- Yayın (Google Play) için imzalı release AAB/APK, uygulama ikonu, sürümleme ve gerçek cihaz testleri ayrıca yapılmalıdır.
