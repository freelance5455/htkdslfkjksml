# Android build

## Option A — Android Studio
1. Install Android Studio.
2. Open the `android` folder.
3. Let Gradle sync.
4. Choose `app` and build APK from Build > Build APK(s).

The Android shell loads the bundled web app from `app/src/main/assets/public`.

## Option B — Capacitor workflow
Install Node.js, then from the project root:
`npm install`
`npx cap sync android`
`npx cap open android`

For a normal Capacitor-generated project, Android Studio can then build the APK.

## Important
The bundled chart data is demo data, not real NIFTY historical data. A real 2016–2026 dataset must be supplied from a properly licensed source.
