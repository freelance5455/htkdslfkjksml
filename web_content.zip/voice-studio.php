<?php
declare(strict_types=1);
require_once __DIR__.'/app/bootstrap.php';
workspace_legacy_redirect('voice/');
require_once __DIR__.'/app/voice.php';
$user=auth_require_user();
$pageTitle='Voice Cloning Studio';
require __DIR__.'/app/platform_header.php';
?>
<link rel="stylesheet" href="assets/voice-studio.css?v=2.2.2">

<section class="voice-hero">
 <div><span class="page-kicker">ANONYMOUX VOICE WORKSPACE</span><h1>Voice Cloning Studio<span class="neon-dot">.</span></h1><p>Create authorized private voice models, explore the Fish Audio library and generate speech.</p></div>
 <div class="voice-hero-meta"><span class="voice-provider-pill"><i></i> FISH AUDIO</span><span class="voice-model-label">S2.1 PRO FREE · TTS</span><span class="voice-model-label" id="voiceCredits">Credits: loading…</span><a class="voice-model-label" href="agents/">Open AI Agent Studio ↗</a></div>
</section>
<div class="voice-workspace">
 <main class="voice-main-panel">
  <section class="voice-clone-panel" aria-labelledby="cloneHeading">
   <div class="voice-section-heading"><div><span class="page-kicker">PRIVATE VOICE MODEL</span><h2 id="cloneHeading">Create your voice</h2><p>Build a reusable private voice model from audio you own or are authorized to use.</p></div><span class="voice-model-label">POST /model</span></div>
   <form id="voiceCloneForm" class="voice-clone-form" enctype="multipart/form-data">
    <div class="voice-clone-fields"><label>Voice name<input type="text" name="voice_name" maxlength="120" required placeholder="e.g. My Narration Voice"></label><label>Description <span class="muted-copy">(optional)</span><input type="text" name="description" maxlength="500" placeholder="Describe the voice for your library"></label></div>
    <label class="voice-upload-label">Reference audio <input id="voiceCloneSample" type="file" name="sample" accept=".wav,.mp3,.m4a,.opus,audio/wav,audio/mpeg,audio/mp4,audio/ogg" required><small>WAV, MP3, M4A or OPUS · 1 KB–15 MB. Aim for at least 10 seconds of clean, single-speaker audio; a minute or two can improve fidelity.</small></label><div class="voice-record-controls" id="voiceRecordControls" hidden><button type="button" class="voice-secondary" id="voiceRecordStart">● Record sample</button><button type="button" class="voice-secondary" id="voiceRecordStop" disabled>■ Stop recording</button><span id="voiceRecordStatus" class="voice-draft-status">Browser recording available</span></div>
    <audio id="voiceClonePreview" controls preload="metadata" hidden></audio>
    <label class="voice-consent"><input type="checkbox" name="consent" value="1" required><span>I own this voice sample or have explicit permission to create this voice model. I will not use it to impersonate or deceive anyone.</span></label>
    <div class="voice-clone-actions"><button class="voice-generate" id="voiceCloneSubmit" type="submit">＋ Create private voice</button><span id="voiceCloneCost" class="voice-draft-status">Clone credits: loading…</span><span id="voiceCloneMessage" role="status" aria-live="polite"></span></div>
   </form>
   <div class="voice-owned-head"><div><b>My private voices</b><small>Only voices created by your account are shown here.</small></div><button type="button" class="voice-text-button" id="voiceOwnedRefresh">Refresh</button></div>
   <div id="voiceOwnedList" class="voice-owned-list"><p class="voice-library-empty">Loading your private voices…</p></div>
  </section>
  <section class="voice-library" aria-labelledby="voiceLibraryTitle">
   <div class="voice-section-heading"><div><span class="page-kicker">02 / VOICE LIBRARY</span><h2 id="voiceLibraryTitle">Choose a voice</h2><p>Browse the voices available to your Fish Audio account.</p></div><span class="voice-library-count" id="voiceLibraryCount">Loading…</span></div>
   <div class="voice-library-tools">
    <label class="voice-search-wrap"><span aria-hidden="true">⌕</span><input id="voiceSearch" type="search" autocomplete="off" placeholder="Search loaded voices…" aria-label="Search voices"></label>
    <select id="voiceFilter" aria-label="Filter voices"><option value="all">All voices</option><option value="favorites">Favorites</option></select>
    <button class="voice-icon-button" id="voiceRefresh" type="button" title="Refresh voice library" aria-label="Refresh voice library">↻</button>
   </div>
   <div class="voice-library-toolbar"><span id="voiceLibraryStatus" role="status">Connecting to Fish Audio…</span><button class="voice-text-button" id="voiceLoadMore" type="button" hidden>Load more</button></div>
   <div class="voice-grid" id="voiceGrid" aria-live="polite"><div class="voice-library-empty">Loading voice library…</div></div>
   <audio id="voicePreviewAudio" preload="none" hidden></audio><div class="voice-selected-bar"><span class="selected-indicator"></span><div><small>SELECTED VOICE</small><strong id="voiceSelectedName">Provider default voice</strong><span id="voiceSelectedId">No reference ID selected</span></div><button id="voiceUseDefault" class="voice-text-button" type="button">Use default</button></div>
  </section>

  <section class="voice-composer" aria-labelledby="scriptTitle">
   <div class="voice-section-heading"><div><span class="page-kicker">03 / SCRIPT EDITOR</span><h2 id="scriptTitle">Your script</h2><p>Write, paste or dictate what you want your voice to say.</p></div><span class="voice-char-count" id="voiceCharCount">0 / 5,000</span></div>
   <textarea id="voiceText" maxlength="5000" spellcheck="true" placeholder="Start writing your narration here…&#10;&#10;Tip: use punctuation and paragraph breaks to shape the delivery."></textarea>
   <div class="voice-editor-toolbar">
    <div class="voice-editor-actions"><button class="voice-secondary" id="voiceDictate" type="button">🎙 Dictate</button><button class="voice-secondary" id="voiceClear" type="button">Clear</button><span id="voiceDraftStatus" class="voice-draft-status">Draft autosave is on</span></div>
    <div class="voice-speed-control"><label for="voiceSpeed">Playback speed</label><input id="voiceSpeed" type="range" min="0.7" max="1.3" step="0.05" value="1"><b id="voiceSpeedValue">1.00×</b></div>
   </div>
   <div class="voice-generate-row"><div class="voice-status-inline"><span class="voice-status-dot" id="voiceStatusDot"></span><div><strong id="voiceStatusTitle">Checking provider…</strong><small id="voiceStatusDescription">Connecting to secure voice endpoint.</small></div></div><button class="voice-generate" id="voiceGenerate" type="button" disabled><span>▶</span> Generate speech</button></div>
   <div class="voice-error" id="voiceError" role="alert" hidden></div>
  </section>

  <section class="voice-output" id="voiceHistory" aria-label="Generated audio history"><div class="voice-output-head"><div><span class="page-kicker">05 / SAVED GENERATIONS</span><h2>Recent audio history</h2></div><button class="voice-text-button" id="voiceHistoryRefresh" type="button">Refresh</button></div><div id="voiceHistoryList" class="voice-history-list"><p class="voice-library-empty">Loading your saved audio…</p></div></section>

 <section class="voice-output" id="voicePlayer" hidden aria-label="Generated audio">
   <div class="voice-output-head"><div><span class="page-kicker">04 / YOUR OUTPUT</span><h2>Generated audio</h2></div><span class="voice-output-format">MP3</span></div>
   <audio id="voiceAudio" controls preload="metadata"></audio>
   <div class="voice-output-actions"><span id="voiceAudioMeta">Fish Audio · S2.1 Pro</span><a id="voiceDownload" class="voice-download" download="anonymoux-voice.mp3">Download MP3 ↓</a></div>
  </section>
 </main>

 <aside class="voice-side-panel">
  <section class="voice-side-card"><span class="page-kicker">WORKSPACE STATUS</span><div class="voice-status-card"><span class="voice-status-dot" id="voiceStatusDotSide"></span><div><b id="voiceStatusTitleSide">Checking connection</b><p id="voiceStatusDescriptionSide">Your provider status will appear here.</p></div></div></section>
  <section class="voice-side-card"><span class="page-kicker">VOICE SETTINGS</span><h3>Manual voice ID</h3><label class="voice-field"><input id="voiceReference" type="text" maxlength="120" placeholder="Paste a Fish Audio voice ID"><small>Optional. Selecting a library voice fills this automatically.</small></label><div class="voice-info-note"><b>Expressive delivery</b><p>Try natural punctuation and short delivery cues where supported by your selected voice model.</p></div></section>
  <section class="voice-side-card voice-tips-card"><span class="page-kicker">QUICK TIPS</span><h3>Better narration</h3><ul><li>Use short paragraphs for natural pauses.</li><li>Use commas and full stops to control pacing.</li><li>Generate a short sample before a long script.</li><li>Preview the result before downloading.</li></ul></section>
  <p class="voice-privacy-note">Your provider API key stays on the server. Script text is sent to Fish Audio when you generate speech. Draft autosave stays in this browser.</p>
 </aside>
</div>

<script src="assets/voice-studio.js?v=2.2.3" defer></script>

<?php require __DIR__.'/app/platform_footer.php'; ?>
