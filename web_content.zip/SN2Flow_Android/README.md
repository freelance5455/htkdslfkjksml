# SN2Flow Android

Android Studio project wrapping the SN2Flow interface as a native Android app shell.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone or choose an emulator.
4. Run `app`.
5. For an APK: Build > Build APK(s).

Package: com.sn2flow.app
Version: 1.0

The current app stores the prototype's local data in the device WebView storage. A production release should add a real backend/database, authentication, encrypted backup/sync, and Play Store release configuration.
