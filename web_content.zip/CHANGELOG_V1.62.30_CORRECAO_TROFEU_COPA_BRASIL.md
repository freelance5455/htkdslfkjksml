# v1.62.30 — Correção do troféu da Copa do Brasil

- Removidos os pequenos fragmentos dourados soltos à direita do PNG do troféu da Copa do Brasil.
- Mantido o troféu principal, sem alterar tamanho, posição nos cards ou demais imagens.
- Nenhuma alteração em partidas, tabelas, clubes ou dados salvos.
