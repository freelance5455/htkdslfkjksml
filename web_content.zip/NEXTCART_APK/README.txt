NEXTCART Android wrapper

1. Open this folder in Android Studio.
2. Let Gradle sync/download dependencies.
3. Run on an Android phone/emulator, or Build > Generate App Bundle/APK > Generate APK.

The existing NEXTCART HTML is bundled as app/src/main/assets/index.html.
Note: the current owner password is stored in the HTML and is not secure for a real production store. A backend/auth system is needed for real owner security, payments, orders, and AI APIs.
