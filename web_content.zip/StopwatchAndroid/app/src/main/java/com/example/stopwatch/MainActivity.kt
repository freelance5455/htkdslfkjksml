package com.example.stopwatch

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17, 24, 39)
        window.navigationBarColor = Color.rgb(17, 24, 39)
        val webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(17, 24, 39))
        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()
        webView.isVerticalScrollBarEnabled = false
        webView.isHorizontalScrollBarEnabled = false
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }
}
