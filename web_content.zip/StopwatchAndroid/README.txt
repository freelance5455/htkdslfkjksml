STOPWATCH ANDROID APP PROJECT

This is an Android Studio source project, not a compiled APK.
The app screen contains only the stopwatch display and one button. The button runs a five-second countdown, then starts timing; tap to stop, and tap again to restart.

To build using only an Android phone, use a browser-based Android build service that can import a Gradle Android project and export an APK. You may need to upload this ZIP and wait for its cloud build. Review the service before uploading files.
