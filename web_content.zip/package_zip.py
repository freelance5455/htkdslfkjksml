import os
import zipfile

def create_suesa_zip():
    source_root = os.getcwd()
    zip_filename = os.path.join(source_root, "SuesaAI.zip")
    prefix = "SuesaAI"

    # Folders and files to include
    include_patterns = [
        "app/build.gradle.kts",
        "app/proguard-rules.pro",
        "app/src",
        "gradle",
        "build.gradle.kts",
        "settings.gradle.kts",
        "gradle.properties",
        ".gitignore",
        "README.md",
        "metadata.json"
    ]

    # Patterns to exclude (build artifacts, caches)
    exclude_dirs = {
        ".git", ".gradle", "build", ".build-outputs", ".cxx", ".idea"
    }

    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_root):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
            
            rel_dir = os.path.relpath(root, source_root)
            if rel_dir == ".":
                rel_dir = ""

            for file in files:
                rel_file_path = os.path.normpath(os.path.join(rel_dir, file))
                
                # Check if file should be included
                should_include = False
                for pattern in include_patterns:
                    if rel_file_path == pattern or rel_file_path.startswith(pattern + "/"):
                        should_include = True
                        break
                
                if should_include:
                    # Skip .class, intermediate build files
                    if any(part in exclude_dirs for part in rel_file_path.split(os.sep)):
                        continue
                    if rel_file_path.endswith(".class") or rel_file_path.endswith(".hprof"):
                        continue

                    arcname = os.path.join(prefix, rel_file_path)
                    abs_path = os.path.join(source_root, rel_file_path)
                    zipf.write(abs_path, arcname)

    print(f"Zip created successfully at {zip_filename} (Size: {os.path.getsize(zip_filename)} bytes)")

if __name__ == "__main__":
    create_suesa_zip()
