/* Replace every placeholder below with values from Firebase Console > Project settings > Your apps > Web app.
   This is public web configuration, not a private server key. Never place service-account credentials here. */
window.CLASSIC_SLOT_FIREBASE_CONFIG = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "PASTE_PROJECT_ID_HERE.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID_HERE",
  storageBucket: "PASTE_PROJECT_ID_HERE.appspot.com",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID_HERE",
  appId: "PASTE_APP_ID_HERE"
};
