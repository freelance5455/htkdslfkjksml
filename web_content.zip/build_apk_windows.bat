@echo off
echo VIBA Artes - compilacion APK
where gradle >nul 2>nul
if %errorlevel% neq 0 (
  echo Gradle no esta instalado. Abre el proyecto en Android Studio y usa Build > Build APK(s).
  pause
  exit /b 1
)
gradle assembleDebug
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
