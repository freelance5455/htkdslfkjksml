/* JOSTECH — COURS 10 : ANGLAIS INFORMATIQUE (IT ENGLISH) */
registerDisciplineLevels(10, {
  1: {
    label: "Niveau 1 — Fondamental",
    subtitle: "Vocabulaire matériel/logiciel fondamental et faux-amis courants.",
    chapters: [{
      id: "eng-1-1", title: "Chapitre 1 : Essential IT Vocabulary",
      lessons: [{
        id: "eng-1-1-1", title: "Leçon 1 : Hardware, Software et Faux-Amis Techniques", duration: "25 min",
        objectives: ["Maîtriser les termes de base Hardware/Software.", "Éviter les faux-amis anglais les plus fréquents en informatique."],
        prerequisites: ["Notions d'anglais général."],
        sections: [
          { type: "table", title: "Lexique IT fondamental", headers: ["Terme anglais", "Traduction exacte", "Contexte"], rows: [
            ["Hardware / Software", "Matériel / Logiciel", "CPU is hardware; OS is software."],
            ["Database / Query", "Base de données / Requête", "Run a SQL query on the database."],
            ["Bug / Troubleshooting", "Anomalie / Dépannage", "Debug and fix the issue."],
            ["Backup / Restore", "Sauvegarde / Restaurer", "Always keep an offline backup."]
          ]},
          { type: "warning", title: "Attention aux Faux-Amis (False Friends) !", text: "• « Library » signifie Bibliothèque logicielle (ensemble de fonctions), PAS librairie.\n• « Directory » signifie Dossier/Répertoire, PAS directoire.\n• « Actually » signifie En fait / En réalité, PAS actuellement (currently).\n• « Eventually » signifie Finalement, PAS éventuellement (possibly)." }
        ],
        exercise: {
          question: "Traduisez proprement en français technique : « Check your directory for the backup file before deploying the library. »",
          solution: "« Vérifiez votre dossier (répertoire) pour trouver le fichier de sauvegarde avant de déployer la bibliothèque logicielle. »"
        },
        summary: "L'anglais est la langue de travail universelle de l'informatique : maîtriser les termes exacts et éviter les faux-amis évite bien des erreurs.",
        references: ["Glendinning, E. — Oxford English for Information Technology."]
      }]
    }]
  },
  2: {
    label: "Niveau 2 — Intermédiaire",
    subtitle: "Lecture de documentations techniques et compréhension des messages d'erreur.",
    chapters: [{
      id: "eng-2-1", title: "Chapitre 2 : Reading Docs & Error Messages",
      lessons: [{
        id: "eng-2-1-1", title: "Leçon 1 : Décoder les Erreurs et la Documentation API", duration: "25 min",
        objectives: ["Comprendre instantanément les erreurs console en anglais.", "Lire une documentation officielle (Deprecated, Required, Returns)."],
        prerequisites: ["Niveau 1 — Anglais IT."],
        sections: [
          { type: "table", title: "Messages d'erreur fréquents", headers: ["Message anglais", "Signification exacte"], rows: [
            ["Unexpected end of input", "Fin de fichier inattendue (code coupé, accolade manquante)."],
            ["X is not defined", "Variable ou fonction X inconnue ou non chargée."],
            ["Permission denied (403)", "Accès refusé par manque de droits."],
            ["Deprecated feature", "Fonction obsolète à ne plus utiliser (sera supprimée)."]
          ]},
          { type: "theory", title: "Structure d'une documentation", text: "Une documentation API indique toujours : Parameters (paramètres attendus, marqués Required = obligatoire ou Optional), Return value (valeur renvoyée), et Exceptions/Errors (cas d'échec)." }
        ],
        exercise: {
          question: "Que signifie la mention « This method is deprecated since v2.0; use fetchAsync() instead » ?",
          solution: "« Cette méthode est obsolète depuis la version 2.0 ; utilisez fetchAsync() à la place. »"
        },
        summary: "Savoir lire les erreurs et documentations en anglais rend tout développeur autonome face aux nouveaux outils.",
        references: ["MDN Web Docs & Python Official Documentation."]
      }]
    }]
  },
  3: {
    label: "Niveau 3 — Avancé & Universitaire",
    subtitle: "Communication professionnelle, rédaction technique (README, Bug Reports) et IT spécialisé.",
    chapters: [{
      id: "eng-3-1", title: "Chapitre 3 : Technical Writing & Specialized IT",
      lessons: [{
        id: "eng-3-1-1", title: "Leçon 1 : Rédiger un Bug Report, README et Termes IA/Cyber", duration: "30 min",
        objectives: ["Rédiger un rapport de bug professionnel en anglais.", "Maîtriser les termes clés Réseaux, Cybersécurité et IA."],
        prerequisites: ["Niveau 2 — Documentation."],
        sections: [
          { type: "code", lang: "Modèle professionnel de Bug Report (GitHub / Jira)", code: "Title: [BUG] Login button unresponsive on Android\nSteps to reproduce: 1. Open app 2. Tap 'Login'\nExpected behavior: Redirect to dashboard.\nActual behavior: Screen freezes (ReferenceError in app.js)." },
          { type: "theory", title: "Vocabulaire spécialisé avancé", text: "• Réseaux : Bandwidth (bande passante), Latency (latence), Packet loss, Gateway.\n• Cybersécurité : Vulnerability, Patch (correctif), Breach (fuite), Encryption (chiffrement).\n• IA : Training dataset, Inference, Overfitting, Prompt engineering." }
        ],
        exercise: {
          question: "Complétez avec le bon terme anglais : « We must release a security ___ to fix this critical ___ before hackers exploit it. »",
          solution: "« patch » (correctif) et « vulnerability » (vulnérabilité)."
        },
        summary: "La rédaction technique concise (Expected vs Actual behavior) et la maîtrise du vocabulaire spécialisé ouvrent les portes des équipes internationales.",
        references: ["Google Technical Writing Courses."]
      }]
    }]
  }
});