One Shot MCQ — MP4 Export Edition

1. Extract this ZIP on your Android phone.
2. Open one_shot_mcq_quiz.html in your HTML-to-APK app and rebuild the APK.
3. Open the app and tap “1080p MP4 ভিডিও এক্সপোর্ট”.
4. Keep internet on while exporting. The app records the quiz at 1080x1920 with timer beeps and answer chimes, then uses FFmpeg.wasm to convert the recording to MP4.

Important:
- Export requires an Android WebView/HTML-to-APK wrapper that supports canvas captureStream and MediaRecorder, internet access, and enough free RAM/storage.
- Long quizzes can take several minutes and may fail on low-memory phones. Try a short quiz first.
- Questions are rendered as text; externally linked question images are not included in exported video.
