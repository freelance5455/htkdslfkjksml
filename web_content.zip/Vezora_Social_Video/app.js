import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import {
  getAuth, GoogleAuthProvider, signInWithPopup, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, signOut, onAuthStateChanged, sendEmailVerification
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import {
  getFirestore, collection, addDoc, getDocs, query, orderBy, limit,
  doc, updateDoc, increment, serverTimestamp, where
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import {
  getStorage, ref, uploadBytesResumable, getDownloadURL
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

const $ = id => document.getElementById(id);
const appEl = $("app");
let currentUser = null;
let signupMode = false;

function esc(v=""){return v.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function openModal(id){$(id).classList.remove("hidden")}
function closeModal(id){$(id).classList.add("hidden")}
function avatar(user){return user?.photoURL || "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='80' height='80'><rect width='100%' height='100%' fill='%23ddd'/><text x='50%' y='58%' text-anchor='middle' font-size='35'>◉</text></svg>"}

async function loadHome(searchTerm=""){
  appEl.innerHTML=`<div class="chips"><button class="chip active">All</button><button class="chip">Music</button><button class="chip">Gaming</button><button class="chip">Comedy</button><button class="chip">Education</button><button class="chip">Shorts</button></div><div class="grid" id="videoGrid"></div>`;
  const grid=$("videoGrid");
  try{
    const q=query(collection(db,"videos"),orderBy("createdAt","desc"),limit(40));
    const snap=await getDocs(q);
    let videos=snap.docs.map(d=>({id:d.id,...d.data()}));
    if(searchTerm) videos=videos.filter(v=>(v.title||"").toLowerCase().includes(searchTerm.toLowerCase()));
    if(!videos.length){grid.innerHTML=`<div class="empty">No videos yet. Sign in and upload your first video.</div>`;return}
    grid.innerHTML=videos.map(v=>`
      <article class="card" data-video="${v.id}">
        <img class="thumb" src="${esc(v.thumbnail||"")}" onerror="this.style.display='none'">
        <div class="row" style="margin-top:9px">
          <img class="avatar" src="${avatar({photoURL:v.ownerPhoto})}">
          <div><h3>${esc(v.title||"Untitled")}</h3><div class="meta">${esc(v.ownerName||"Creator")}</div><div class="meta">${v.views||0} views</div></div>
        </div>
      </article>`).join("");
    grid.querySelectorAll("[data-video]").forEach(x=>x.onclick=()=>openVideo(x.dataset.video));
  }catch(e){grid.innerHTML=`<div class="empty">Firebase setup is incomplete. Add your Firebase config first.</div>`}
}

async function openVideo(id){
  const d=await importDoc(id); if(!d)return;
  appEl.innerHTML=`<div class="video-page">
    <video class="video-player" controls src="${esc(d.videoUrl)}"></video>
    <h1>${esc(d.title)}</h1>
    <div class="meta">${esc(d.ownerName||"Creator")} · ${d.views||0} views</div>
    <div class="video-actions">
      <button id="likeBtn">♥ ${d.likes||0}</button>
      <button id="shareBtn">↗ Share</button>
    </div>
    <p>${esc(d.description||"")}</p>
    <hr><h3>Comments</h3>
    <div class="comment-box"><input id="commentInput" placeholder="Add a comment"><button id="commentBtn" class="pill dark">Post</button></div>
    <div id="comments"></div>
  </div>`;
  $("likeBtn").onclick=async()=>{await updateDoc(doc(db,"videos",id),{likes:increment(1)});openVideo(id)}
  $("shareBtn").onclick=async()=>{await navigator.clipboard?.writeText(location.href);alert("Link copied")}
  $("commentBtn").onclick=async()=>{if(!currentUser)return openModal("authModal");const text=$("commentInput").value.trim();if(!text)return;await addDoc(collection(db,"videos",id,"comments"),{text,userId:currentUser.uid,userName:currentUser.displayName||currentUser.email,createdAt:serverTimestamp()});$("commentInput").value="";alert("Comment posted")}
}
async function importDoc(id){const {getDoc}=await import("https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js");const s=await getDoc(doc(db,"videos",id));return s.exists()?{id:s.id,...s.data()}:null}

function renderProfile(){
  if(!currentUser){appEl.innerHTML=`<div class="empty"><h2>Sign in to see your profile</h2><button id="pLogin" class="pill dark">Sign in</button></div>`;$("pLogin").onclick=()=>openModal("authModal");return}
  appEl.innerHTML=`<div class="profile-head"><img class="profile-avatar" src="${avatar(currentUser)}"><div><h1>${esc(currentUser.displayName||"Vezora user")}</h1><div class="meta">${esc(currentUser.email||"")}</div></div></div><div class="grid" id="myVideos"></div>`;
  loadMyVideos();
}
async function loadMyVideos(){
  const grid=$("myVideos");const q=query(collection(db,"videos"),where("ownerId","==",currentUser.uid),limit(40));const snap=await getDocs(q);
  grid.innerHTML=snap.docs.map(d=>{const v=d.data();return `<article class="card" data-video="${d.id}"><video class="thumb" src="${esc(v.videoUrl)}"></video><h3>${esc(v.title)}</h3><div class="meta">${v.views||0} views</div></article>`}).join("")||`<div class="empty">You have not uploaded a video yet.</div>`;
  grid.querySelectorAll("[data-video]").forEach(x=>x.onclick=()=>openVideo(x.dataset.video));
}

async function uploadVideo(){
  if(!currentUser)return openModal("authModal");
  const file=$("videoFile").files[0], title=$("videoTitle").value.trim(), desc=$("videoDesc").value.trim();
  if(!file||!title){$("uploadMsg").textContent="Title and video are required.";return}
  if(file.size>200*1024*1024){$("uploadMsg").textContent="Demo limit: 200 MB.";return}
  $("uploadMsg").textContent="Uploading...";
  const fileRef=ref(storage,`videos/${currentUser.uid}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`);
  const task=uploadBytesResumable(fileRef,file);
  task.on("state_changed",s=>{$("uploadMsg").textContent=`Uploading ${Math.round(s.bytesTransferred/s.totalBytes*100)}%`},e=>{$("uploadMsg").textContent=e.message},async()=>{
    const url=await getDownloadURL(task.snapshot.ref);
    await addDoc(collection(db,"videos"),{title,description:desc,videoUrl:url,ownerId:currentUser.uid,ownerName:currentUser.displayName||currentUser.email,ownerPhoto:currentUser.photoURL||"",views:0,likes:0,createdAt:serverTimestamp()});
    $("uploadMsg").textContent="Published!";
    setTimeout(()=>{closeModal("uploadModal");loadHome()},700);
  });
}

$("loginBtn").onclick=()=>openModal("authModal");
$("uploadBtn").onclick=()=>currentUser?openModal("uploadModal"):openModal("authModal");
$("googleBtn").onclick=async()=>{try{await signInWithPopup(auth,new GoogleAuthProvider());closeModal("authModal")}catch(e){$("authMsg").textContent=e.message}};
$("switchAuth").onclick=()=>{signupMode=!signupMode;$("authTitle").textContent=signupMode?"Create Vezora account":"Sign in to Vezora";$("emailAuthBtn").textContent=signupMode?"Create account":"Sign in";};
$("emailAuthBtn").onclick=async()=>{
  const email=$("email").value.trim(), pass=$("password").value;
  try{
    if(signupMode){const c=await createUserWithEmailAndPassword(auth,email,pass);await sendEmailVerification(c.user);$("authMsg").textContent="Account created. Check your email to verify it."}
    else await signInWithEmailAndPassword(auth,email,pass);
    closeModal("authModal");
  }catch(e){$("authMsg").textContent=e.message}
};
$("publishBtn").onclick=uploadVideo;
$("searchBtn").onclick=()=>loadHome($("searchInput").value);
$("searchInput").addEventListener("keydown",e=>{if(e.key==="Enter")loadHome(e.target.value)});
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>closeModal(b.dataset.close));
document.querySelectorAll("[data-route]").forEach(a=>a.onclick=e=>{e.preventDefault();const r=a.dataset.route;if(r==="profile")renderProfile();else loadHome()});
onAuthStateChanged(auth,user=>{currentUser=user;const lb=$("loginBtn");if(user){lb.textContent="Sign out";lb.onclick=()=>signOut(auth);$("userBox").classList.remove("hidden");$("userBox").textContent=user.displayName||user.email}else{lb.textContent="Sign in";lb.onclick=()=>openModal("authModal");$("userBox").classList.add("hidden")}});
loadHome();
