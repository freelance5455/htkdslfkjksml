// 1) Create a Firebase project at https://console.firebase.google.com/
// 2) Add a Web App.
// 3) Copy its config here.
// IMPORTANT: Firebase web config is not a password. Security comes from Authentication + Rules.
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_STORAGE_BUCKET",
  messagingSenderId: "PASTE_YOUR_MESSAGING_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};
