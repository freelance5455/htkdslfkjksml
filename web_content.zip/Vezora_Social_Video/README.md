# Vezora — Social Video Starter

This is a working starter for a YouTube/Instagram-style video platform.

## Included
- Responsive video home feed
- Search
- Video upload to Firebase Storage
- Video metadata in Firestore
- Likes
- Comments
- Creator profile
- Google sign-in
- Email/password sign-up + email verification
- Mobile-friendly layout

## Important
This is NOT a literal copy of YouTube or Instagram. It uses an original Vezora design with familiar social-video features.

## Firebase setup
1. Open Firebase Console.
2. Create a project and add a Web App.
3. Enable Authentication:
   - Google
   - Email/Password
4. Create Firestore Database.
5. Create Storage.
6. Put your Web App config into `firebase-config.js`.
7. Replace Firestore and Storage rules with the supplied rules.
8. Deploy these files on a static host.

## Local testing
Because browser modules and Firebase need a web origin, use a local server rather than opening index.html directly.

For example with VS Code Live Server, or:
`python -m http.server 5500`

Then open:
`http://localhost:5500`

## Production upgrades
For a real public-scale platform you still need moderation, abuse reporting, rate limits, video transcoding/HLS, thumbnails, CDN, pagination, notifications, creator subscriptions, admin tools, privacy policy/terms, backups, analytics and stronger security rules.
