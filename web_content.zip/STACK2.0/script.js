
/* =================================
   STACK 2.0 — CORE ENGINE
================================= */

const STORAGE_KEY = "stack2_transactions";
const GOALS_KEY = "stack2_goals";

// APPLICATION DATA

let transactions = loadData(STORAGE_KEY);
let goals = loadData(GOALS_KEY);

function loadData(key) {
  try {
    const data = JSON.parse(localStorage.getItem(key));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
  localStorage.setItem(GOALS_KEY, JSON.stringify(goals));
}

// HELPERS

const money = amount =>
  "KSh " + Number(amount).toLocaleString("en-KE", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

function getBalance() {
  return transactions.reduce((total, transaction) => {
    return total +
      (transaction.type === "deposit"
        ? transaction.amount
        : -transaction.amount);
  }, 0);
}

// STACK CUSTOM NOTIFICATIONS

function showToast(message, type = "success") {
  const oldToast = document.querySelector(".stack-toast");
  if (oldToast) oldToast.remove();

  const toast = document.createElement("div");
  toast.className = `stack-toast ${type}`;

  const icon = type === "success" ? "✓" : "!";

  toast.innerHTML = `
    <span class="toast-icon">${icon}</span>
    <span class="toast-message">${escapeHTML(message)}</span>
  `;

  document.body.appendChild(toast);

  requestAnimationFrame(() => {
    toast.classList.add("show");
  });

  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// DASHBOARD

function updateDashboard() {
  const balance = getBalance();

  document.getElementById("totalBalance").textContent =
    money(balance);

  renderTransactions();
  drawChart();
  renderGoals();
}

// DEPOSIT

function deposit() {
  const amountInput = document.getElementById("amountInput");
  const noteInput = document.getElementById("transactionNote");

  const amount = Number(amountInput.value);

  if (!Number.isFinite(amount) || amount <= 0) {
    showToast("Enter a valid deposit amount.", "error");
    return;
  }

  transactions.push({
    id: Date.now(),
    type: "deposit",
    amount,
    note: noteInput.value.trim() || "Savings deposit",
    date: new Date().toISOString()
  });

  saveData();
  updateDashboard();

  amountInput.value = "";
  noteInput.value = "";

  showToast("Deposit recorded successfully.");
}

// WITHDRAW

function withdraw() {
  const amountInput = document.getElementById("amountInput");
  const noteInput = document.getElementById("transactionNote");

  const amount = Number(amountInput.value);

  if (!Number.isFinite(amount) || amount <= 0) {
    showToast("Enter a valid withdrawal amount.", "error");
    return;
  }

  if (amount > getBalance()) {
    showToast("Insufficient savings balance.", "error");
    return;
  }

  transactions.push({
    id: Date.now(),
    type: "withdraw",
    amount,
    note: noteInput.value.trim() || "Savings withdrawal",
    date: new Date().toISOString()
  });

  saveData();
  updateDashboard();

  amountInput.value = "";
  noteInput.value = "";

  showToast("Withdrawal recorded successfully.");
}

// TRANSACTION LEDGER

function renderTransactions() {
  const container = document.getElementById("transactionList");

  if (!container) return;

  if (!transactions.length) {
    container.innerHTML =
      '<div class="empty-state">No transactions yet.</div>';
    return;
  }

  const sorted = [...transactions].sort(
    (a, b) => new Date(b.date) - new Date(a.date)
  );

  container.innerHTML = sorted.map(transaction => {
    const isDeposit = transaction.type === "deposit";

    const date = new Date(transaction.date).toLocaleDateString(
      "en-KE",
      {
        day: "2-digit",
        month: "short"
      }
    );

    return `
      <div class="transaction-row">
        <div class="transaction-info">
          <strong>${escapeHTML(transaction.note)}</strong>
          <small>${date}</small>
        </div>

        <span class="transaction-amount ${isDeposit ? "deposit" : "withdraw"}">
          ${isDeposit ? "+" : "−"} ${money(transaction.amount)}
        </span>
      </div>
    `;
  }).join("");
}

// SAVINGS GROWTH GRAPH

function drawChart() {
  const canvas = document.getElementById("growthChart");

  if (!canvas) return;

  const ctx = canvas.getContext("2d");
  const rect = canvas.getBoundingClientRect();

  if (!rect.width || !rect.height) return;

  const width = rect.width;
  const height = rect.height;
  const dpr = window.devicePixelRatio || 1;

  canvas.width = Math.round(width * dpr);
  canvas.height = Math.round(height * dpr);

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, height);

  const months = [];

  for (let i = 5; i >= 0; i--) {
    const date = new Date();
    date.setDate(1);
    date.setMonth(date.getMonth() - i);

    months.push({
      year: date.getFullYear(),
      month: date.getMonth(),
      label: date.toLocaleDateString("en", {
        month: "short"
      }),
      balance: 0
    });
  }

  const sorted = [...transactions].sort(
    (a, b) => new Date(a.date) - new Date(b.date)
  );

  let runningBalance = 0;

  const currentMonthStart = new Date(
    months[0].year,
    months[0].month,
    1
  );

  sorted.forEach(transaction => {
    const transactionDate = new Date(transaction.date);

    const change = transaction.type === "deposit"
      ? transaction.amount
      : -transaction.amount;

    if (transactionDate < currentMonthStart) {
      runningBalance += change;
    }
  });

  months.forEach(month => {
    const start = new Date(month.year, month.month, 1);
    const end = new Date(month.year, month.month + 1, 1);

    sorted.forEach(transaction => {
      const date = new Date(transaction.date);

      if (date >= start && date < end) {
        runningBalance += transaction.type === "deposit"
          ? transaction.amount
          : -transaction.amount;
      }
    });

    month.balance = runningBalance;
  });

  const left = 42;
  const right = 12;
  const top = 12;
  const bottom = 29;

  const chartWidth = width - left - right;
  const chartHeight = height - top - bottom;

  const maxValue = Math.max(
    100,
    ...months.map(month => month.balance)
  );

  const scaleMax = maxValue * 1.2;

  const points = months.map((month, index) => ({
    x: left + index * (chartWidth / 5),
    y: top + chartHeight -
      (Math.max(0, month.balance) / scaleMax) * chartHeight,
    value: month.balance
  }));

  // GRID

  ctx.font = "9px Inter, sans-serif";
  ctx.textAlign = "right";
  ctx.fillStyle = "#91a99b";
  ctx.strokeStyle = "rgba(145,169,155,0.15)";
  ctx.lineWidth = 1;

  for (let i = 0; i <= 3; i++) {
    const y = top + (chartHeight / 3) * i;

    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(width - right, y);
    ctx.stroke();

    const value = scaleMax * (1 - i / 3);

    ctx.fillText(
      value >= 1000
        ? (value / 1000).toFixed(1) + "k"
        : Math.round(value),
      left - 7,
      y + 3
    );
  }

  // AREA FILL

  const gradient = ctx.createLinearGradient(
    0, top, 0, height - bottom
  );

  gradient.addColorStop(0, "rgba(32,230,154,0.30)");
  gradient.addColorStop(1, "rgba(32,230,154,0.01)");

  ctx.beginPath();
  ctx.moveTo(points[0].x, height - bottom);

  points.forEach(point => {
    ctx.lineTo(point.x, point.y);
  });

  ctx.lineTo(points[points.length - 1].x, height - bottom);
  ctx.closePath();

  ctx.fillStyle = gradient;
  ctx.fill();

  // LINE

  ctx.beginPath();

  points.forEach((point, index) => {
    if (index === 0) {
      ctx.moveTo(point.x, point.y);
    } else {
      ctx.lineTo(point.x, point.y);
    }
  });

  ctx.strokeStyle = "#20e69a";
  ctx.lineWidth = 2.5;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.shadowColor = "#20e69a";
  ctx.shadowBlur = 10;
  ctx.stroke();
  ctx.shadowBlur = 0;

  // DATA POINTS

  points.forEach(point => {
    ctx.beginPath();
    ctx.arc(point.x, point.y, 3, 0, Math.PI * 2);
    ctx.fillStyle = "#20e69a";
    ctx.fill();

    ctx.beginPath();
    ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
    ctx.strokeStyle = "#20e69a";
    ctx.lineWidth = 1;
    ctx.stroke();
  });

  // MONTH LABELS

  ctx.fillStyle = "#91a99b";
  ctx.font = "10px Inter, sans-serif";
  ctx.textAlign = "center";

  months.forEach((month, index) => {
    ctx.fillText(
      month.label,
      points[index].x,
      height - 8
    );
  });
}

// SAVINGS GOALS

function addGoal() {
  const nameInput = document.getElementById("goalName");
  const targetInput = document.getElementById("goalTarget");

  const name = nameInput.value.trim();
  const target = Number(targetInput.value);

  if (!name || !Number.isFinite(target) || target <= 0) {
    showToast("Enter a goal name and valid target amount.", "error");
    return;
  }

  goals.push({
    id: Date.now(),
    name,
    target,
    created: new Date().toISOString()
  });

  saveData();
  renderGoals();

  nameInput.value = "";
  targetInput.value = "";

  showToast("Savings goal created successfully.");
}

function renderGoals() {
  const container = document.getElementById("goalsList");

  if (!container) return;

  if (!goals.length) {
    container.innerHTML =
      '<div class="empty-state">No savings goals created yet.</div>';
    return;
  }

  container.innerHTML = goals.map(goal => {
    const progress = goal.target > 0
      ? Math.min(100, Math.max(0, getBalance() / goal.target * 100))
      : 0;

    return `
      <div style="padding:15px 0;border-bottom:1px solid #ffffff15">
        <strong>${escapeHTML(goal.name)}</strong>
        <p style="color:#91a99b;font-size:11px;margin:8px 0">
          ${money(getBalance())} / ${money(goal.target)}
        </p>
        <div style="height:7px;background:#163527;border-radius:10px;overflow:hidden">
          <div style="height:100%;width:${progress}%;background:#20e69a;border-radius:10px"></div>
        </div>
        <small style="color:#20e69a">${progress.toFixed(1)}% complete</small>
      </div>
    `;
  }).join("");
}

// CUSTOM RESET CONFIRMATION

function resetStack() {
  if (document.getElementById("resetModal")) return;

  const modal = document.createElement("div");
  modal.id = "resetModal";
  modal.className = "reset-modal";

  modal.innerHTML = `
    <div class="reset-dialog" role="dialog" aria-modal="true">
      <div class="reset-icon">⚠</div>

      <h2>Reset STACK?</h2>

      <p>
        This action will permanently clear all your
        saved transactions and savings goals.
      </p>

      <div class="reset-actions">
        <button type="button" id="cancelReset" class="cancel-reset">
          CANCEL
        </button>

        <button type="button" id="confirmReset" class="confirm-reset">
          RESET
        </button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  document.getElementById("cancelReset").addEventListener("click", () => {
    modal.remove();
  });

  document.getElementById("confirmReset").addEventListener("click", () => {
    transactions = [];
    goals = [];

    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(GOALS_KEY);

    updateDashboard();

    modal.remove();

    showToast("STACK has been successfully reset.");
  });

  modal.addEventListener("click", event => {
    if (event.target === modal) {
      modal.remove();
    }
  });
}

// NAVIGATION

function showPage(pageName) {
  document.querySelectorAll(".page").forEach(page => {
    page.classList.remove("active");
  });

  document.querySelectorAll(".nav-item").forEach(button => {
    button.classList.remove("active");
  });

  const page = document.getElementById(pageName);
  const nav = document.querySelector(
    `.nav-item[data-page="${pageName}"]`
  );

  if (page) page.classList.add("active");
  if (nav) nav.classList.add("active");

  if (pageName === "dashboard") {
    requestAnimationFrame(drawChart);
  }

  if (pageName === "goals") {
    renderGoals();
  }
}

// DATA EXPORT

function exportData() {
  const data = {
    application: "STACK 2.0",
    exportedAt: new Date().toISOString(),
    balance: getBalance(),
    transactions,
    goals
  };

  const blob = new Blob(
    [JSON.stringify(data, null, 2)],
    { type: "application/json" }
  );

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = "STACK2-backup.json";
  link.click();

  URL.revokeObjectURL(url);

  showToast("Backup exported successfully.");
}

// BUTTON EVENTS

document.getElementById("depositBtn")
  .addEventListener("click", deposit);

document.getElementById("withdrawBtn")
  .addEventListener("click", withdraw);

document.getElementById("addGoalBtn")
  .addEventListener("click", addGoal);

document.getElementById("exportBtn")
  .addEventListener("click", exportData);

const resetButton = document.getElementById("resetBtn");

if (resetButton) {
  resetButton.addEventListener("click", resetStack);
}

document.querySelectorAll(".nav-item").forEach(button => {
  button.addEventListener("click", () => {
    showPage(button.dataset.page);
  });
});

document.getElementById("profileBtn")
  .addEventListener("click", () => showPage("profile"));

window.addEventListener("resize", () => {
  requestAnimationFrame(drawChart);
});

// INITIALIZE APPLICATION

saveData();
updateDashboard();
renderGoals();

const investmentContent = document.getElementById("investmentContent");

if (investmentContent) {
  investmentContent.innerHTML = `
    <div class="empty-state">
      Investment tracking tools will be added in a later development stage.
    </div>
  `;
}

console.log("STACK 2.0 initialized successfully.");

// STACK Service Worker Registration
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("./sw.js")
      .then(() => {
        console.log("STACK service worker connected");
      })
      .catch(error => {
        console.error("Service worker error:", error);
      });
  });
}