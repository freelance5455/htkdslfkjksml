# ANONYMOUX STUDIOS 2.6.4 — Workspace Folder Routing Audit & Repair

## Objective

Give each active workspace a dedicated directory URL while retaining existing application behavior, private configuration, shared APIs, common assets, and database ownership logic.

## Routing changes

| Workspace | Canonical URL | Entry point |
|---|---|---|
| Image Studio | `/image/` | `image/index.php` |
| Video Edit Studio | `/video/` | `video/index.php` |
| Realtime Studio | `/realtime/` | `realtime/index.php` |
| Lip Sync Studio | `/lip-sync/` | `lip-sync/index.php` |
| Voice Studio | `/voice/` | `voice/index.php` |
| AI Agent Studio | `/agents/` | `agents/index.php` |
| Agent conversation | `/agents/chat.php?id=...` | `agents/chat.php` |

The folder entry points include the existing root-level workspace implementations. This avoids duplicating provider logic, credit accounting, authentication, database access, API endpoints, and shared media code. Shared `assets/`, `api/`, `app/`, migrations, and private configuration remain centralized at the application root.

## Repairs included

- Added one controlled workspace entry helper that calculates the application base path for root and subdirectory deployments.
- Added dedicated directory entry points for all active workspaces, including a separate Agent conversation URL.
- Added canonical 301 redirects from the previous root-level `.php` workspace URLs. Query strings are retained.
- Updated dashboard shortcuts, workspace sidebars, onboarding destinations, retries, agent launch links, and generated notification destinations to use folder URLs.
- Added a root-aware `<base>` element to the Realtime shell and used the existing platform shell base element for the other workspaces. This keeps CSS, JavaScript, API requests, images, and form destinations resolving to the application root.
- Updated unauthenticated workspace redirects to send users to the application-root login page and preserve the requested folder URL.
- Corrected the Lip Sync entry point to select the integrated Lip Sync mode rather than defaulting to Video Transform.
- Kept existing root workspace implementation files and shared assets in place as the compatibility/source layer; old public URLs redirect to their canonical folders.
- Kept the existing `config.local.php` location, credentials loading, storage directories, database schema, and provider integrations unchanged.

## Verification

- PHP syntax sweep: **PASS** for all PHP files, including the seven new entry points.
- Existing Python regression suite: **PASS** for all 15 pre-existing Python test scripts.
- New `tests/workspace_folder_routes_check.py`: **PASS** (16 Python test scripts pass in total).
- JavaScript syntax sweep: **PASS** for all 13 JavaScript files.
- Legacy redirect HTTP check: **PASS** for all seven old workspace URLs through the PHP fallback; all returned HTTP 301 and retained their query strings. Direct `/folder/index.php` requests and folder URLs missing the trailing slash also canonicalized to `/folder/` in local HTTP checks.
- Application base-path checks: **PASS** for root and subdirectory path cases; an HTTP redirect under a simulated `/anonymoux_audit/` deployment also retained the subdirectory prefix.
- ZIP integrity check: run on the rebuilt archive.
- PHP runtime smoke test: **BLOCKED** in this build environment because PHP has PDO but does not have the `pdo_sqlite` driver installed. The app is configured for PDO SQLite, so authenticated database-backed page execution and live provider calls cannot be proven in this environment. A local request to a workspace folder reached the application, then returned the expected environment-related database failure. This is an environment limitation, not a passing runtime test.

## Configuration preservation

The supplied ZIP contains `config.local.example.php` but does not contain `config.local.php`, `.env`, or a private storage/database directory. No live secret values were available in this upload to migrate or overwrite. The configuration loader and documented private configuration location were left unchanged. Preserve the live server copy of `config.local.php` and its private storage directory when deploying this build.

## Deployment notes

Upload and extract the ZIP so that `dashboard.php`, `app/`, `api/`, `assets/`, `.htaccess`, and the workspace folders are all directly inside the application root. Keep the existing server-side `config.local.php` and private storage contents in place when updating a live installation. Apache `mod_rewrite` is recommended for early redirects, but legacy PHP entry points also redirect when that module is unavailable. The new folder URLs are direct PHP directory entry points.
