# IPA2Droid local test engine

This prototype can inspect IPA ZIP archives and export a basic Android Studio project scaffold based on metadata. It **cannot convert compiled iOS apps to functioning Android APKs**.

## Run
- Install Python 3.10+ (no third-party dependencies).
- Run `python server.py` (Windows: `start_windows.bat`).
- Open `http://127.0.0.1:8765` in a browser on the same device.
- Select an IPA and choose **Analyze IPA** or **Export Android scaffold**.

Max upload: 1 GB. Files are processed locally and are not saved to disk by the server.
