# TODO

## Capture a selected display and audio sources — Complete
- The app lets the user choose a screen, application window, or browser tab using the browser’s native sharing picker.
- The app captures microphone audio with a selectable input device and clear permission handling.
- The app captures system/internal audio when supported by the selected browser and operating system, and gives guidance when it is unavailable.
- The app mixes microphone and internal audio into the screen recording while preventing avoidable echo.
- The pre-recording setup view shows screen-share, microphone, and system-audio readiness indicators.

## Operate a recording session — Complete
- The user can start, pause, resume, and stop recording, and can see elapsed time and recording status.

## Review and save a recording — Complete
- The user can preview the completed recording with playback controls before saving it.
- The user can download the finished recording as a local video file and start a new recording without reloading the app.

## Apply the approved interface direction — Complete
- Use the approved Softwave Studio direction: muted violet, rounded glass-like panels, and gentle gradients for a polished, reassuring recording utility.
