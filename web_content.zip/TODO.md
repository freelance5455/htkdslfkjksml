# Sohbetly — Ürün kriterleri

- Kullanıcı kaydı, Manus OAuth ile giriş, çıkış ve güvenli oturum yönetimi çalışmalıdır.
- Profil fotoğrafı, kullanıcı adı, bio ve temel profil bilgileri görüntülenebilmeli ve düzenlenebilmelidir.
- Kullanıcı adına göre arama, profil görüntüleme ve arkadaşlık/iletişim isteği gönderme, kabul etme veya reddetme akışı bulunmalıdır.
- Kabul edilmiş kişilerle bire bir metin sohbeti ve sohbet geçmişi bulunmalıdır.
- Sesli mesaj kaydetme, gönderme ve sohbet içinde oynatma arayüzü bulunmalıdır.
- Kamera veya cihazdan fotoğraf ve video çekme/yükleme, gönderme ve sohbet içinde görüntüleme akışı bulunmalıdır.
- Grup oluşturma, katılımcı yönetimi ve grup sohbeti bulunmalıdır.
- Her bire bir veya grup sohbeti için özel tema seçimi yapılabilmeli ve tercih saklanabilmelidir.
- Sohbet listesi, okunmamış mesaj göstergeleri, son mesaj önizlemesi ve mobil uyumlu sohbet ekranı bulunmalıdır.
- İstemci arayüzü mümkün olduğunca tek HTML çıktısında modern sosyal medya hissi vermeli; gerçek kullanıcı etkileşimleri sunucu bağlantısıyla desteklenmelidir.
