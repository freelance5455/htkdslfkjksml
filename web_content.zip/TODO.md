# Petit Français – Umsetzung

- Die bestehende Petit-Français-App wird als mobile, installierbare und offline nutzbare Lernapp mit lokal verfügbaren Lerninhalten ausgeliefert.
- Der Kawaii-Katzenstil mit White Mode, Pastellfarben #ffd9df, #d5f1e4 und #e6defa sowie handgezeichnetem SVG-Katzenmotiv bleibt erhalten.
- Die bestehenden Modi Üben, Flashcards, Memory und Zuordnen bleiben verfügbar und funktionieren touchfreundlich auf Smartphone, Tablet und Desktop.
- Die bestehende localStorage-Struktur mit ok/err/streak/badges und die Migration alter petitfr1-Daten bleiben erhalten; es gibt keinen Fortschrittsreset.
- Wortschatz und Sprachthemen bleiben nach Units/Themen strukturiert; die vorhandenen Band-1-bis-3-Inhalte und wichtigen Grammatik-/Verbthemen werden weiterverwendet.
- Die Startseite erhält schnellen Zugriff auf Wiederholen, Alles mischen, Lernplan, Abzeichen, Einstellungen und eine Vokabelsuche.
- Lernfortschritt kann lokal exportiert und wieder importiert werden, ohne fremde Daten oder Serverkonto.
- Die App enthält sichtbare Offline-/Installationshinweise und passende mobile Metadaten.
- Die Startseite wird über den Webdev-Preview-Server ausgeliefert, der Routenmanifest ist vorhanden und der Build bleibt statisch ohne Backend-Abhängigkeit.
