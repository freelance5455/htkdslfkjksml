# BarrelCount Peshawar — TODO

## 1. Persistent customer records

- [x] Create, view, edit, and maintain customer records.
- [x] Store customer records in the managed database so they remain available across phones and future reporting periods.
- [x] Prevent deleting a customer who already has barrel history, so the payment record remains intact.

## 2. Daily barrel receiving

- [x] Record each daily barrel receipt against a selected customer and receipt date.
- [x] Allow the staff member to enter a barrel quantity and optional note for a receipt.
- [x] Provide a clear success state after saving a receipt and refresh the visible totals/activity.

## 3. Date-based review and correction

- [x] Review daily barrel entries in a clear chronological list.
- [x] Edit or delete incorrect barrel entries.
- [x] Filter barrel records and totals by a selected start and end date.

## 4. Customer-wise payment summary

- [x] Calculate and display the total barrel count for each customer within the selected period.
- [x] Show a clear phone-friendly payment summary with each customer’s name and barrel count.
- [x] Provide a print-friendly summary action so the shop can share or use the counts for payment collection.
