# PC Builder outcomes

- Create a complete mobile-first web application called PC Builder that can later be converted into an Android APK; everything works directly in the browser without a backend or paid APIs; use HTML, CSS and JavaScript; optimize for Android phones and low-end devices; work correctly in portrait mode; prevent horizontal scrolling.
- Provide a dark futuristic gaming-style home screen with the title PC Builder, the subtitle “Build your dream PC”, working Build PC, Saved Builds, Parts, and Settings actions, purple/cyan accents, smooth restrained animations, and large touch-friendly buttons.
- Provide a builder and parts browser for CPU, GPU, Motherboard, RAM, SSD, HDD, PSU, CPU Cooler, and Case. Each component card shows the component name, image placeholder/glyph, example price, main specifications, and a working Select action.
- Recalculate total price in euros, estimated gaming performance, estimated power consumption, and overall compatibility immediately after each selection.
- Check CPU socket with motherboard, RAM type with motherboard, motherboard size with case, PSU wattage with estimated system consumption, GPU length with case, and CPU cooler compatibility; display Compatible, Warning, or Incompatible with simple explanations.
- Show approximate estimated FPS for Minecraft, Trackmania, Valheim, Cities: Skylines, Fortnite, and GTA V at 1080p and 1440p.
- Allow budgets €500, €750, €1000, €1500, €2000, €3000, and €5000; show a progress bar and the exact “Over budget by €XXX” style warning when the build exceeds the selected budget.
- Include an editable local JavaScript parts database with realistic example prices, clearly marked as example prices and not live prices, with at least 10 CPUs, 10 GPUs, 8 motherboards, 6 RAM kits, 6 SSDs, 6 PSUs, 6 cases, and 4 CPU coolers, plus HDD entries.
- Save, name, load, list, and delete builds using localStorage with no account or backend.
- Provide a bottom navigation bar for Home, Builder, Parts, and Saved, with large touch targets and working navigation.
- Provide Settings for English/German/Russian language selection, euro currency, dark mode, reset application data, and About information, with settings saved through localStorage.
- Ensure the application can be opened from index.html through a static file server and leave no unfinished or dead major buttons.
