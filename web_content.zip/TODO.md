# TODO — Desejos PT

## Site map-first para desejos em Portugal

- [x] Exibir uma lista de desejos de brasileiros em Portugal com item, categoria, cidade/zona aproximada, local encontrado e status de disponibilidade.
- [x] Mostrar no mapa de Portugal onde existe o que foi desejado, com pins selecionáveis e sincronização visual entre lista e mapa.
- [x] Permitir pesquisa textual, filtro por categoria e filtro por cidade.
- [x] Exibir estado de atualização em tempo real, com conexão SSE e entrada de novos itens sem recarregar a página.
- [x] Permitir registrar um novo desejo por formulário com consentimento explícito e localização aproximada.
- [x] Deixar claro que dados pessoais e localizações exatas não são expostos.
- [x] Entregar layout responsivo para desktop e celular em português do Brasil.
- [x] Incluir dados demonstrativos para o site iniciar com conteúdo útil e um modo demo que simula novas descobertas.

## Operação local

- [x] Disponibilizar servidor Node sem dependências externas obrigatórias.
- [x] Disponibilizar `npm run check` para verificar a sintaxe dos arquivos JavaScript.
- [x] Disponibilizar manifesto `public/manus-routes.json`.
