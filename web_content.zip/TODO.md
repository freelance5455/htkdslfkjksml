# VIP GENERADOR — estado de entrega

## Navegación y secciones
- [x] Navegación funcional entre Inicio, Calibrador, Guía y Ajustes, con tarjetas del menú, botón `ABRIR CALIBRADOR` y navegación inferior.
- [x] Acciones centralizadas equivalentes a `data-act` y `data-go`, identificadores de sección, visibilidad accesible y una única delegación de eventos para evitar conflictos.
- [x] Calibración rápida conectada al calibrador y capaz de iniciar el cálculo correspondiente.
- [x] Guía de ajuste fino completada coherentemente a partir del adjunto truncado; Ajustes añadido de forma coherente.

## Calibrador
- [x] Selectores de dispositivo y estilo operativos.
- [x] `CALCULAR SENSIBILIDAD` muestra resultados visibles.
- [x] `RE-CALCULAR` genera un nuevo conjunto de valores.
- [x] `COPIAR` copia todos los valores calculados y muestra confirmación.

## Calidad de interacción y diseño
- [x] Se conserva el nombre VIP GENERADOR, la estética futurista, los colores cian/magenta/amarillo y el enfoque táctil para pantallas pequeñas.
- [x] Temas y animaciones son funcionales y mantienen su estado durante la sesión.
- [x] La aplicación Expo/React Native usa el mismo flujo reparado y tiene copia mediante `expo-clipboard`.
- [x] TypeScript y lint pasan sin errores del proyecto.

## Evidencia y límites
- [x] HTML probado en navegador: menú, dock, calibración rápida, cálculo, cambio de dispositivo/estilo, recalculado, copiar, guía, ajustes, tema, animaciones y consola limpia.
- [x] Vista previa móvil renderizada a 375×812 para comprobar Android-like responsive layout.
- [ ] Prueba en Android físico/Expo Go: no había un dispositivo físico conectado en esta sesión; debe validarse al abrir el proyecto desde Expo Go o un build Android.
