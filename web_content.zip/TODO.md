# TODO — Xerxes AI Official

## Database persisten untuk seluruh data aplikasi
- [ ] Aplikasi menyimpan akun pengguna, role, status ban, alasan ban, profil, reset kuota, log penggunaan, banding, pesan komunitas, sinyal per pengguna, dan preferensi ke database terkelola MySQL.
- [ ] Migrasi database bersifat idempotent dan additive; restart/deploy tidak menghapus data pengguna.
- [ ] Endpoint sinkronisasi mengembalikan snapshot bersama dan tetap memiliki cache offline browser bila server/database sementara tidak tersedia.

## Backend aman dan koneksi AI
- [ ] Seluruh pemanggilan AI dari browser melewati endpoint server `/api/ai/chat/completions`.
- [ ] API key/provider credential tidak ditulis ke HTML, localStorage, bundle, Docker image, atau log.
- [ ] Model fallback server menggunakan model AI bawaan yang tersedia, dengan error upstream diteruskan sebagai pesan yang dapat dipahami UI.
- [ ] Settings browser tidak dapat mengubah target upstream arbitrer atau menyebabkan SSRF.

## Fitur aplikasi dan kompatibilitas UI
- [ ] Dashboard market, multi-source ticker/candle, chart TradingView/Xerxes, analisis kekuatan market, sinyal, chat AI, berita, kalender, akun, role, kuota, log, moderasi, banding, dan komunitas tetap dapat diakses dari UI existing.
- [ ] Endpoint health unauthenticated mengembalikan 2xx untuk readiness deployment.
- [ ] Route manifest tersedia dan mencerminkan halaman `/` pada SPA.

## Build, validasi, dan publikasi
- [ ] Server listen pada `PORT` dengan default 3000 dan memiliki Dockerfile production self-contained.
- [ ] Check syntax, migrasi database, health, sync GET/POST, proxy AI, dan static serving berhasil di environment development.
- [ ] Checkpoint canonical tersimpan di `main` dan publish berhasil; URL production hanya dicantumkan setelah status publish terkonfirmasi.
