# TODO — Gatos & Sapatos: Gerador de Ficha

## Formulário e organização da ficha
- [x] A aplicação deve permitir preencher e editar uma ficha de personagem animal, incluindo nome, jogador, espécie/gato, sapato, conceito, descrição e demais informações úteis do sistema.
- [x] A aplicação deve oferecer uma seção dedicada aos cinco sentidos, com valores editáveis e apresentação visual clara.
- [x] A aplicação deve oferecer gerenciamento de habilidades e pontos de perigo, com controles adequados e cálculo visual dos valores.
- [x] A aplicação deve oferecer inventário e anotações livres para registrar itens, detalhes da aventura e informações complementares.

## Rolagens, validação e persistência
- [x] A aplicação deve oferecer rolagens de dados d6 associadas aos sentidos, exibindo de forma compreensível os dados e o resultado obtido.
- [x] A aplicação deve validar os campos e valores de forma amigável, exibindo mensagens claras sem interromper o preenchimento.
- [x] A aplicação deve salvar automaticamente a ficha no navegador e restaurá-la ao reabrir a aplicação.
- [x] A aplicação deve permitir limpar os dados e criar uma nova ficha, com confirmação para evitar perda acidental.

## Saída e responsividade
- [x] A aplicação deve oferecer modo de impressão e exportação em formato amigável, com diagramação limpa da ficha.
- [x] A interface deve ser responsiva para celular e desktop, em português do Brasil, com estética lúdica, clara e temática de animais e calçados.
