JARYAN CAPTURE WORKBENCH — ZIP→APK BUILD BUNDLE

PURPOSE
This ZIP is intentionally prepared for services/tools that accept a ZIP containing a web app and build an Android APK around it.

ENTRY POINT
index.html  <-- PRIMARY APPLICATION ENTRY POINT

IMPORTANT
1. Keep index.html at the ZIP ROOT.
2. Preserve the assets/ and config/ relative paths.
3. Do not require Android Studio, Gradle, Kotlin, or an Android SDK to interpret this bundle.
4. The APK wrapper should load index.html inside its local application origin/WebView.
5. Camera and microphone permissions should be requested at runtime only after the user taps START or CHECK / REQUEST.
6. Do not claim RAW/DNG, manual ISO/shutter/WB, IMU, depth, or external hardware unless the host exposes them.
7. Prefer a secure/local app origin rather than file:// because browser camera APIs may be blocked on file URLs.
8. Recommended Android wrapper settings: portrait, fullscreen/edge-to-edge, JavaScript enabled, DOM storage enabled, media playback allowed inline, camera/microphone permission bridge enabled.
9. If the builder has a field called Start File / Entry File / Homepage, use: index.html
10. If it asks for app name: JARYAN Capture Workbench
11. If it asks for package/application ID: com.jaryan.captureworkbench
12. If it asks for orientation: portrait
13. If it asks for permissions: CAMERA and RECORD_AUDIO

FILES
- index.html              Main application
- manifest.json           PWA/app metadata
- sw.js                   Offline cache helper
- assets/icons/icon.svg   Application icon
- config/ZIP2APK_CONFIG.json  Machine-readable build hints

CAPABILITY BOUNDARY
This ZIP is a WebView/browser-capable build of JARYAN Capture Workbench. It is not a native CameraX APK. Native-only features such as RAW/DNG capture, Camera2 manual controls, IMU/depth pipelines, and external hardware drivers require a native Android implementation.
