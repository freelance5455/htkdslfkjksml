const providers=[['أحمد للصيانة','سباكة','250 جنيه','4.8'],['محمد للكهرباء','كهرباء','300 جنيه','4.7'],['محمود للنجارة','نجارة','400 جنيه','4.9'],['خالد للتكييف','تكييف','350 جنيه','4.6'],['شركة النظافة السريعة','تنظيف','200 جنيه','4.8']];
const services=['سباكة','كهرباء','نجارة','دهانات','تكييف','تنظيف'];
const s=document.getElementById('services'),p=document.getElementById('providers');
function render(filter=''){s.innerHTML=services.map(x=>`<button class="service" onclick="render('${x}')">🛠️ ${x}</button>`).join('');let list=providers.filter(x=>!filter||x[1]===filter);p.innerHTML=list.map(x=>`<div class="provider"><b>${x[0]}</b><div>${x[1]} • ${x[2]}</div><div class="rating">★★★★★ ${x[3]}</div><button class="request" onclick="alert('تم إرسال طلب الخدمة إلى ${x[0]}')">اطلب الخدمة</button></div>`).join('')||'<p>لا يوجد مقدم خدمة حاليًا لهذه المهنة.</p>'}
function show(){render()}render();
