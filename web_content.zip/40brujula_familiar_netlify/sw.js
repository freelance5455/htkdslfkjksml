const CACHE_NAME = "brujula-familiar-v3";
const PRECACHE = ["/", "/index.html", "/manifest.webmanifest", "/icon-192.png", "/icon-512.png"];
const CDN_HOSTS = ["cdn.tailwindcss.com", "unpkg.com", "cdn.jsdelivr.net"];
self.addEventListener("install", e => { self.skipWaiting(); e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(PRECACHE).catch(() => {}))); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  const u = new URL(e.request.url);
  if (u.origin !== self.location.origin && !CDN_HOSTS.includes(u.hostname)) return;
  e.respondWith(fetch(e.request).then(r => {
    if (r && (r.status === 200 || r.type === "opaque")) { const cl = r.clone(); caches.open(CACHE_NAME).then(c => c.put(e.request, cl)); }
    return r;
  }).catch(() => caches.match(e.request).then(c => c || (u.origin === self.location.origin ? caches.match("/index.html") : undefined))));
});
