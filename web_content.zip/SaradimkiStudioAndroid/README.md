# Saradimki Studio Android wrapper (starter project)

This Android Studio project packages the current Saradimki Studio HTML editor into a simple Android WebView app shell.

## Build an APK
1. Open this folder in Android Studio (Giraffe or newer; recent stable recommended).
2. Allow Gradle to sync and install Android SDK Platform 35 if prompted.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. For a phone install, use the generated debug APK from `app/build/outputs/apk/debug/`.

## Current status
- HTML editor bundled locally at `app/src/main/assets/index.html`.
- WebView enables JavaScript and DOM storage.
- File chooser support is wired for importing media.
- Camera/microphone WebView permissions are wired for browser media capture.
- This is a starter project, not a tested or signed release APK. It has not been built here because this environment has Java but no Android SDK/Gradle installation.

## Important limitations to test
- HTML export APIs and WebAudio behaviour vary by Android System WebView version.
- Local project JSON persistence and media re-linking need device testing.
- Do not distribute as a production release until APK build, install, import, recording, export and playback tests pass.
