ONTIME — Luxury Travel Planner
================================

START
1. Extract this ZIP.
2. Open index.html in Chrome, Edge, Firefox or Safari.
3. Internet is needed for route estimation and Google Maps links.
4. For GPS, allow location access when the browser asks.

FEATURES
- Separate Overview, Plan a trip, Journey log and Preferences screens
- Source/destination text inputs, including house numbers and coordinates
- Open Google Maps to search/drop pins; paste the copied address or coordinates back
- Optional GPS capture for source coordinates
- Optional route estimate using OpenStreetMap Nominatim + OSRM public services
- Manual travel-time fallback
- Leave-by time calculation, buffer and extra-time allowance
- Local journey history and preferences
- Direct Google Maps directions link for live traffic and navigation

IMPORTANT LIMITATIONS
- No website can guarantee 100% coverage of every house number or road. Map data varies by location.
- Public routing/geocoding services can have rate limits, outages, and route-coverage gaps.
- The automatic route estimate is not live traffic. Open Google Maps for live traffic and navigation.
- For live traffic inside the app, background reminders, SMS/calls, or production-grade reliability, deploy a backend and integrate a paid Google Maps Platform API key (and configure billing/restrictions). Never expose a private API key in public frontend code.
- The app uses localStorage on this browser; history does not sync across devices.
- GPS works only when supported and permitted by the browser. HTTPS or localhost may be required on some devices.
