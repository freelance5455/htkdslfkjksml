# HanDesk **v9.7** — Fokus Laporan

## Fokus fitur
1. **Laporan Kegiatan** (harian/mingguan + acuan kurikulum)
2. **Laporan Persiapan Bulanan** (tema, tujuan, APE)
3. **Laporan Perkembangan per Anak** (pilih dari roster)

## Data anak
- **Bukan** input satu-satu oleh guru
- Admin upload **DOCX / CSV / TXT** di tab **Data Anak (DOCX)**
- Format: `Nama | Kelas | Catatan` atau `Nama (Kelas)`

## Halaman guru
- `dashboard.html` Ringkasan
- `kegiatan.html` Laporan Kegiatan
- `persiapan.html` Persiapan Bulanan
- `perkembangan.html` Perkembangan Anak
- `kurikulum.html` Acuan

Password admin: `handesk-admin`
v9.7.1 — fix admin JS crash (duplicate esc/load), loader, roster bind
