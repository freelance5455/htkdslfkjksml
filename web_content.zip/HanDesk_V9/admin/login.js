const PASSWORD = "handesk-admin";
const form = document.getElementById("admin-login");
form.onsubmit = e => {
  e.preventDefault();
  if (document.getElementById("password").value !== PASSWORD) {
    alert("Password admin salah.");
    return;
  }
  sessionStorage.setItem("handesk_admin", "1");
  location.href = "dashboard.html";
};
