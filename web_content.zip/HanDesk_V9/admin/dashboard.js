const APP_VERSION = "v9.7.1";
const KEY = "handesk_v1";
if (sessionStorage.getItem("handesk_admin") !== "1") location.replace("login.html");

const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

/* Load + migrate old V8 flat structure → V9 nested structure */
function load() {
  let d;
  try {
    d = JSON.parse(localStorage.getItem(KEY));
  } catch {
    d = null;
  }
  if (!d || typeof d !== "object") {
    d = { users: [], data: {}, curriculum: { prota: [], rppm: [], rpph: [], other: [] } };
  }

  // Ensure base shape
  if (!Array.isArray(d.roster)) d.roster = [];
  d.users = Array.isArray(d.users) ? d.users : [];
  d.data = d.data && typeof d.data === "object" ? d.data : {};
  d.curriculum = d.curriculum || { prota: [], rppm: [], rpph: [], other: [] };
  ["prota", "rppm", "rpph", "other"].forEach(t => {
    if (!Array.isArray(d.curriculum[t])) d.curriculum[t] = [];
  });

  // Migrate: if old V8 stored data at root (students/evaluations/reports...) 
  // and we have users but empty data[user], push root arrays into first user
  const hasRootData =
    (Array.isArray(d.students) && d.students.length) ||
    (Array.isArray(d.evaluations) && d.evaluations.length) ||
    (Array.isArray(d.reports) && d.reports.length) ||
    (Array.isArray(d.activities) && d.activities.length) ||
    (Array.isArray(d.performance) && d.performance.length) ||
    (Array.isArray(d.ideas) && d.ideas.length);

  if (hasRootData && d.users.length) {
    const firstUser = d.users[0].user;
    if (!d.data[firstUser] || (
      !(d.data[firstUser].students || []).length &&
      !(d.data[firstUser].evaluations || []).length &&
      !(d.data[firstUser].activities || d.data[firstUser].reports || []).length
    )) {
      d.data[firstUser] = {
        students: d.students || [],
        evaluations: d.evaluations || [],
        activities: d.activities || d.reports || [],
        raports: d.raports || [],
        performance: d.performance || [],
        ideas: d.ideas || []
      };
    }
    // Clean root-level leftovers so JSON view is clean
    delete d.students;
    delete d.evaluations;
    delete d.reports;
    delete d.activities;
    delete d.performance;
    delete d.ideas;
    delete d.current;
    save(d);
  }

  // Ensure every user has a data slot
  d.users.forEach(u => {
    if (!d.data[u.user]) {
      d.data[u.user] = { students: [], evaluations: [], activities: [], raports: [] };
    }
  });

  return d;
}

const save = d => localStorage.setItem(KEY, JSON.stringify(d));

/* ensure curriculum shape (kept for callers) */
function ensureCur(d) {
  d.curriculum = d.curriculum || { prota: [], rppm: [], rpph: [], other: [] };
  ["prota", "rppm", "rpph", "other"].forEach(t => {
    if (!Array.isArray(d.curriculum[t])) d.curriculum[t] = [];
  });
  return d;
}

/* ---------- stats ---------- */
function renderStats() {
  const d = load();
  const users = d.users || [];
  let activities = 0, monthly = 0, developments = 0;
  Object.values(d.data || {}).forEach(ud => {
    activities += (ud.activities || ud.reports || []).length;
    monthly += (ud.monthly || []).length;
    developments += (ud.developments || ud.raports || []).length;
  });
  const cur = d.curriculum || {};
  const curCount = ["prota","rppm","rpph","other"].reduce((n,t)=>n+((cur[t]||[]).length),0);
  if ($("stat-users")) $("stat-users").textContent = users.length;
  if ($("stat-students")) $("stat-students").textContent = (d.roster || []).length;
  if ($("stat-activities")) $("stat-activities").textContent = activities;
  if ($("stat-raports")) $("stat-raports").textContent = monthly + developments;
  if ($("stat-curriculum")) $("stat-curriculum").textContent = curCount;
  // legacy ids if present
  if ($("stat-evaluations")) $("stat-evaluations").textContent = developments;
}

/* ---------- teachers list ---------- */
let activeTeacher = null;
let detailTab = "students";

function renderTeachers() {
  const d = ensureCur(load());
  const users = d.users || [];
  const data = d.data || {};

  $("teacher-list").innerHTML = users.length
    ? `<table>
        <thead><tr><th>Guru</th><th>Siswa</th><th>Evaluasi</th><th>Laporan</th><th>Rapot</th><th>Aksi</th></tr></thead>
        <tbody>
        ${users.map(u => {
          const x = data[u.user] || {};
          const acts = (x.activities || x.reports || []).length;
          return `<tr>
            <td><strong>${esc(u.name)}</strong><br><small>@${esc(u.user)}</small></td>
            <td>${(x.students || []).length}</td>
            <td>${(x.evaluations || []).length}</td>
            <td>${acts}</td>
            <td>${(x.raports || []).length}</td>
            <td class="actions">
              <button class="outline small" data-view="${esc(u.user)}">Lihat/Edit</button>
              <button class="outline small" data-reset="${esc(u.user)}">Reset</button>
              <button class="danger" data-delete="${esc(u.user)}">Hapus</button>
            </td>
          </tr>`;
        }).join("")}
        </tbody>
      </table>`
    : `<div class="empty">Belum ada profil guru.</div>`;

  document.querySelectorAll("[data-view]").forEach(b => b.onclick = () => openTeacher(b.dataset.view));
  document.querySelectorAll("[data-reset]").forEach(b => b.onclick = () => resetUser(b.dataset.reset));
  document.querySelectorAll("[data-delete]").forEach(b => b.onclick = () => deleteUser(b.dataset.delete));
}

function openTeacher(user) {
  activeTeacher = user;
  detailTab = "students";
  const d = load();
  const u = (d.users || []).find(x => x.user === user);
  $("detail-name").textContent = u ? `${u.name} (@${u.user})` : user;
  $("teacher-detail").classList.remove("hidden");
  document.querySelectorAll(".dtab").forEach(t => t.classList.toggle("active", t.dataset.d === detailTab));
  renderDetail();
}

function renderDetail() {
  if (!activeTeacher) return;
  const d = load();
  const x = (d.data || {})[activeTeacher] || {};
  const box = $("detail-content");

  if (detailTab === "students") {
    const list = x.students || [];
    box.innerHTML = list.length
      ? `<table>
          <thead><tr><th>Nama</th><th>Kelas</th><th>Catatan</th><th>Aksi</th></tr></thead>
          <tbody>${list.map(s => `
            <tr>
              <td>${esc(s.name)}</td><td>${esc(s.class)}</td><td>${esc(s.note || "—")}</td>
              <td>
                <button class="outline small" onclick="adminEditStudent('${activeTeacher}','${s.id}')">Edit</button>
                <button class="danger" onclick="adminDelStudent('${activeTeacher}','${s.id}')">Hapus</button>
              </td>
            </tr>`).join("")}
          </tbody></table>
          <button class="gold small" style="margin-top:.8rem" onclick="adminAddStudent('${activeTeacher}')">+ Tambah siswa</button>`
      : `<div class="empty">Belum ada siswa. <button class="gold small" onclick="adminAddStudent('${activeTeacher}')">+ Tambah</button></div>`;
  }

  if (detailTab === "evaluations") {
    const list = x.evaluations || [];
    const students = x.students || [];
    box.innerHTML = list.length
      ? `<table>
          <thead><tr><th>Siswa</th><th>Aspek</th><th>Nilai</th><th>Catatan</th><th>Aksi</th></tr></thead>
          <tbody>${list.map(e => {
            const s = students.find(st => st.id === e.student);
            return `<tr>
              <td>${esc(s?.name || "—")}</td><td>${esc(e.subject)}</td><td><b>${e.score}</b></td><td>${esc(e.comment || "—")}</td>
              <td><button class="danger" onclick="adminDelEval('${activeTeacher}','${e.id}')">Hapus</button></td>
            </tr>`;
          }).join("")}
          </tbody></table>`
      : `<div class="empty">Belum ada evaluasi.</div>`;
  }

  if (detailTab === "activities") {
    const list = x.activities || x.reports || [];
    box.innerHTML = list.length
      ? list.map(a => `
          <article class="item-card">
            <div class="item-meta">
              <span>${esc(a.period || "—")}${a.refTitle ? " · " + esc(a.refTitle) : ""}</span>
              <button class="danger" onclick="adminDelActivity('${activeTeacher}','${a.id}')">Hapus</button>
            </div>
            <strong>${esc(a.title)}</strong>
            <p>${esc(a.body)}</p>
          </article>`).join("")
      : `<div class="empty">Belum ada laporan kegiatan.</div>`;
  }

  if (detailTab === "raports") {
    const list = x.raports || [];
    box.innerHTML = list.length
      ? list.map(r => `
          <article class="item-card">
            <div class="item-meta">
              <span>${esc(r.period)} · ${esc(r.studentName)} · avg ${r.avg ?? "—"}</span>
              <button class="danger" onclick="adminDelRapot('${activeTeacher}','${r.id}')">Hapus</button>
            </div>
            <pre class="rapot-pre">${esc(r.body)}</pre>
          </article>`).join("")
      : `<div class="empty">Belum ada rapot.</div>`;
  }
}

/* detail tab clicks */
document.querySelectorAll(".dtab").forEach(btn => {
  btn.onclick = () => {
    detailTab = btn.dataset.d;
    document.querySelectorAll(".dtab").forEach(t => t.classList.toggle("active", t === btn));
    renderDetail();
  };
});
$("detail-close").onclick = () => {
  activeTeacher = null;
  $("teacher-detail").classList.add("hidden");
};

/* admin CRUD helpers */
window.adminDelStudent = (user, id) => {
  if (!confirm("Hapus siswa ini?")) return;
  const d = load();
  const x = d.data[user] || {};
  x.students = (x.students || []).filter(s => s.id !== id);
  x.evaluations = (x.evaluations || []).filter(e => e.student !== id);
  x.raports = (x.raports || []).filter(r => r.student !== id);
  d.data[user] = x;
  save(d);
  renderAll();
  renderDetail();
};

window.adminDelEval = (user, id) => {
  const d = load();
  const x = d.data[user] || {};
  x.evaluations = (x.evaluations || []).filter(e => e.id !== id);
  d.data[user] = x;
  save(d);
  renderAll();
  renderDetail();
};

window.adminDelActivity = (user, id) => {
  const d = load();
  const x = d.data[user] || {};
  x.activities = (x.activities || []).filter(a => a.id !== id);
  if (x.reports) x.reports = x.reports.filter(a => a.id !== id);
  d.data[user] = x;
  save(d);
  renderAll();
  renderDetail();
};

window.adminDelRapot = (user, id) => {
  const d = load();
  const x = d.data[user] || {};
  x.raports = (x.raports || []).filter(r => r.id !== id);
  d.data[user] = x;
  save(d);
  renderAll();
  renderDetail();
};

window.adminAddStudent = (user) => {
  openEditModal("Tambah Siswa", `
    <label>Nama<input id="m-name" required></label>
    <label>Kelas<input id="m-class" required></label>
    <label>Catatan<textarea id="m-note" rows="3"></textarea></label>
  `, () => {
    const d = load();
    d.data = d.data || {};
    d.data[user] = d.data[user] || { students: [], evaluations: [], activities: [], raports: [] };
    d.data[user].students = d.data[user].students || [];
    d.data[user].students.push({
      id: uid(),
      name: $("m-name").value.trim(),
      class: $("m-class").value.trim(),
      note: $("m-note").value.trim()
    });
    save(d);
    renderAll();
    renderDetail();
    closeEditModal();
  });
};

window.adminEditStudent = (user, id) => {
  const d = load();
  const s = ((d.data[user] || {}).students || []).find(x => x.id === id);
  if (!s) return;
  openEditModal("Edit Siswa", `
    <label>Nama<input id="m-name" value="${esc(s.name)}" required></label>
    <label>Kelas<input id="m-class" value="${esc(s.class)}" required></label>
    <label>Catatan<textarea id="m-note" rows="3">${esc(s.note || "")}</textarea></label>
  `, () => {
    const d2 = load();
    const list = d2.data[user].students;
    const idx = list.findIndex(x => x.id === id);
    if (idx >= 0) {
      list[idx] = { ...list[idx], name: $("m-name").value.trim(), class: $("m-class").value.trim(), note: $("m-note").value.trim() };
      save(d2);
      renderAll();
      renderDetail();
    }
    closeEditModal();
  });
};

function resetUser(user) {
  if (!confirm("Reset seluruh data guru ini? Profil tetap ada.")) return;
  const d = load();
  d.data = d.data || {};
  d.data[user] = { students: [], evaluations: [], activities: [], raports: [] };
  save(d);
  renderAll();
  if (activeTeacher === user) renderDetail();
}

function deleteUser(user) {
  if (!confirm("Hapus profil guru beserta seluruh datanya?")) return;
  const d = load();
  d.users = (d.users || []).filter(x => x.user !== user);
  if (d.data) delete d.data[user];
  save(d);
  if (activeTeacher === user) {
    activeTeacher = null;
    $("teacher-detail").classList.add("hidden");
  }
  renderAll();
}

/* ---------- curriculum ---------- */
let curFilter = "all";
let lastParsedWeeks = null;

/** Parse teks Sentra/Prota yang berisi baris M1, M2, ... menjadi array minggu terstruktur */
function parseCurriculumText(raw) {
  if (!raw || !raw.trim()) return [];
  const text = raw.replace(/\r\n/g, "\n");
  // Split by week markers M1–M12 (or Minggu 1)
  const weekRe = /(?:^|\n)\s*(M(?:1[0-2]|[1-9])|Minggu\s*(1[0-2]|[1-9]))\s*[:.\-]?\s*/gi;
  const parts = [];
  let lastIndex = 0;
  let lastLabel = null;
  let m;
  const re = new RegExp(weekRe.source, "gi");
  while ((m = re.exec(text)) !== null) {
    if (lastLabel !== null) {
      parts.push({ label: lastLabel, body: text.slice(lastIndex, m.index).trim() });
    }
    lastLabel = m[1].replace(/\s+/g, " ").trim();
    // normalize Minggu N → MN
    if (/^minggu/i.test(lastLabel)) {
      const n = lastLabel.replace(/\D/g, "");
      lastLabel = "M" + n;
    } else {
      lastLabel = lastLabel.toUpperCase().replace(/\s/g, "");
    }
    lastIndex = m.index + m[0].length;
  }
  if (lastLabel !== null) {
    parts.push({ label: lastLabel, body: text.slice(lastIndex).trim() });
  }

  // If no M-markers found, treat whole text as one block
  if (!parts.length) {
    return [{
      code: "DOC",
      tema: "Dokumen penuh",
      kognitif: "",
      bahasa: "",
      aktivitas: text.trim().slice(0, 500),
      ape: "",
      raw: text.trim()
    }];
  }

  function pickField(body, keys) {
    for (const k of keys) {
      const rx = new RegExp("(?:^|\\n)\\s*" + k + "\\s*[:.\\-]?\\s*([^\\n]+(?:\\n(?!\\s*(?:Target|Aktivitas|APE|Alat|Bahan|Kognitif|Bahasa|Literasi|Indikator)[^\\n]*[:.\\-])[^\\n]+)*)", "i");
      const mm = body.match(rx);
      if (mm) return mm[1].replace(/\s+/g, " ").trim();
    }
    return "";
  }

  return parts.map(p => {
    const body = p.body;
    // First line often is theme name
    const firstLine = (body.split("\n")[0] || "").replace(/^[:.\-\s]+/, "").trim();
    let tema = firstLine;
    // Prefer explicit "Tema:"
    const temaPick = pickField(body, ["Tema", "Subtema"]);
    if (temaPick) tema = temaPick;
    // Clean tema if it looks like a field label
    if (/^(target|aktivitas|ape|alat)/i.test(tema)) tema = p.label;

    const kognitif = pickField(body, [
      "Target Kognitif\\s*\\(Matematika\\)",
      "Target Kognitif",
      "Kognitif\\s*\\(Numerasi\\)",
      "Indikator Akademik Kognitif",
      "Kognitif",
      "Numerasi"
    ]);
    const bahasa = pickField(body, [
      "Target Bahasa\\s*\\(Literasi\\)",
      "Target Bahasa",
      "Bahasa\\s*\\(Literasi\\)",
      "Indikator Akademik Bahasa",
      "Literasi",
      "Bahasa"
    ]);
    const aktivitas = pickField(body, [
      "Aktivitas Meja Persiapan",
      "Aktivitas Meja",
      "Aktivitas",
      "Kegiatan"
    ]);
    const ape = pickField(body, [
      "Alat & Bahan\\s*\\(APE\\)",
      "Alat & Bahan",
      "Alat dan Bahan",
      "APE",
      "Bahan"
    ]);

    // Fallback: if fields empty, use body as aktivitas
    return {
      code: p.label,
      tema: tema || p.label,
      kognitif: kognitif || "",
      bahasa: bahasa || "",
      aktivitas: aktivitas || (kognitif || bahasa ? "" : body.slice(0, 400)),
      ape: ape || "",
      raw: body
    };
  });
}

function weeksToContent(weeks) {
  return weeks.map(w => {
    let s = `${w.code}: ${w.tema}\n`;
    if (w.kognitif) s += `Target Kognitif: ${w.kognitif}\n`;
    if (w.bahasa) s += `Target Bahasa: ${w.bahasa}\n`;
    if (w.aktivitas) s += `Aktivitas: ${w.aktivitas}\n`;
    if (w.ape) s += `APE: ${w.ape}\n`;
    return s;
  }).join("\n");
}

function renderCurriculumAdmin() {
  const d = ensureCur(load());
  const types = curFilter === "all" ? ["prota", "rppm", "rpph", "other"] : [curFilter];
  let items = [];
  types.forEach(t => (d.curriculum[t] || []).forEach(item => items.push({ ...item, type: t })));
  items.sort((a, b) => (b.uploadedAt || "").localeCompare(a.uploadedAt || ""));

  $("cur-admin-list").innerHTML = items.length
    ? `<table>
        <thead><tr><th>Jenis</th><th>Judul</th><th>Meta</th><th>Minggu</th><th>Aksi</th></tr></thead>
        <tbody>
        ${items.map(item => {
          const nWeeks = (item.weeks || []).length;
          return `<tr>
            <td><span class="badge">${item.type.toUpperCase()}</span></td>
            <td><strong>${esc(item.title)}</strong></td>
            <td>${esc(item.meta || "—")}</td>
            <td>${nWeeks ? nWeeks + " minggu terstruktur" : "teks penuh"}</td>
            <td class="actions">
              <button class="outline small" onclick="adminEditCur('${item.type}','${item.id}')">Edit</button>
              <button class="danger" onclick="adminDelCur('${item.type}','${item.id}')">Hapus</button>
            </td>
          </tr>`;
        }).join("")}
        </tbody></table>`
    : `<div class="empty">Belum ada dokumen kurikulum. Upload di form di atas atau muat contoh Sentra.</div>`;
}

$("cur-parse").onclick = () => {
  const raw = $("cur-content").value;
  const weeks = parseCurriculumText(raw);
  lastParsedWeeks = weeks;
  const box = $("parse-preview");
  if (!weeks.length) {
    box.classList.remove("hidden");
    box.innerHTML = `<p style="color:#c75c4d">Tidak ada pola minggu (M1, M2…) yang terdeteksi. Simpan sebagai teks penuh, atau format ulang.</p>`;
    return;
  }
  box.classList.remove("hidden");
  box.innerHTML = `
    <p style="color:#e7c75d;font-size:.85rem;margin-bottom:.5rem">✓ Terdeteksi <strong>${weeks.length}</strong> minggu. Preview:</p>
    <div style="max-height:220px;overflow:auto;font-size:.78rem;color:#c9c0ae">
      ${weeks.map(w => `<div style="border-bottom:1px solid rgba(201,162,39,.12);padding:.45rem 0">
        <strong style="color:#e7c75d">${esc(w.code)}</strong> — ${esc(w.tema)}
        ${w.kognitif ? `<br><span style="color:#918b7e">Kog:</span> ${esc(w.kognitif.slice(0, 80))}${w.kognitif.length > 80 ? "…" : ""}` : ""}
        ${w.aktivitas ? `<br><span style="color:#918b7e">Akt:</span> ${esc(w.aktivitas.slice(0, 80))}${w.aktivitas.length > 80 ? "…" : ""}` : ""}
      </div>`).join("")}
    </div>`;
};

$("cur-form").onsubmit = e => {
  e.preventDefault();
  const d = ensureCur(load());
  const type = $("cur-type").value;
  const content = $("cur-content").value.trim();
  const weeks = lastParsedWeeks && lastParsedWeeks.length
    ? lastParsedWeeks
    : parseCurriculumText(content);
  d.curriculum[type].push({
    id: uid(),
    title: $("cur-title").value.trim(),
    meta: $("cur-meta").value.trim(),
    content: content || weeksToContent(weeks),
    weeks: weeks,
    uploadedAt: new Date().toISOString()
  });
  save(d);
  e.target.reset();
  lastParsedWeeks = null;
  $("parse-preview").classList.add("hidden");
  $("parse-preview").innerHTML = "";
  renderAll();
  alert("Dokumen kurikulum disimpan" + (weeks.length ? ` (${weeks.length} minggu terstruktur).` : ".") + " Guru bisa ambil acuan di tab Kurikulum / Laporan Kegiatan.");
};

$("cur-clear").onclick = () => {
  $("cur-form").reset();
  lastParsedWeeks = null;
  $("parse-preview").classList.add("hidden");
};

document.querySelectorAll(".ftab").forEach(btn => {
  btn.onclick = () => {
    curFilter = btn.dataset.f;
    document.querySelectorAll(".ftab").forEach(b => b.classList.toggle("active", b === btn));
    renderCurriculumAdmin();
  };
});

window.adminDelCur = (type, id) => {
  if (!confirm("Hapus dokumen ini?")) return;
  const d = ensureCur(load());
  d.curriculum[type] = (d.curriculum[type] || []).filter(x => x.id !== id);
  save(d);
  renderAll();
};

window.adminEditCur = (type, id) => {
  const d = ensureCur(load());
  const item = (d.curriculum[type] || []).find(x => x.id === id);
  if (!item) return;
  openEditModal("Edit Dokumen Kurikulum", `
    <label>Judul<input id="m-title" value="${esc(item.title)}" required></label>
    <label>Meta<input id="m-meta" value="${esc(item.meta || "")}"></label>
    <label>Isi<textarea id="m-content" rows="14">${esc(item.content || "")}</textarea></label>
  `, () => {
    const d2 = ensureCur(load());
    const list = d2.curriculum[type];
    const idx = list.findIndex(x => x.id === id);
    if (idx >= 0) {
      const newContent = $("m-content").value.trim();
      list[idx] = {
        ...list[idx],
        title: $("m-title").value.trim(),
        meta: $("m-meta").value.trim(),
        content: newContent,
        weeks: parseCurriculumText(newContent)
      };
      save(d2);
      renderAll();
    }
    closeEditModal();
  });
};

/* Seed data from uploaded Sentra PDFs (Kuartal 1) */
const SEED_SENTRA_34 = {
  title: "Sentra Persiapan Q1 — Playgroup 3–4 Tahun",
  meta: "2026/2027 · Kuartal 1 · Usia 3–4 tahun · Diri Sendiri & Lingkungan Terdekat",
  weeks: [
    { code: "M1", tema: "Aku & Tubuhku", kognitif: "Mengenali warna kontras cerah (Merah).", bahasa: "Meniru bunyi awal kata \"M-e-r-a-h\".", aktivitas: "Memasukkan mainan bola-bola kecil yang hanya berwarna merah ke dalam keranjang kain besar bermulut lebar.", ape: "Bola plastik merah, keranjang kain." },
    { code: "M2", tema: "Kesukaanku", kognitif: "Mengenali warna kontras cerah (Kuning).", bahasa: "Meniru bunyi awal kata \"K-u-n-i-n-g\".", aktivitas: "Membuka penjepit makanan ukuran besar untuk memindahkan bebek karet kuning ke mangkuk warna kuning.", ape: "Bebek karet kuning, capitan makanan besar." },
    { code: "M3", tema: "Keluargaku", kognitif: "Memasangkan dua objek yang warnanya sama (Merah/Kuning).", bahasa: "Mengucapkan kata nama warna kesukaan secara lisan.", aktivitas: "Memasangkan tutup botol merah ke botol merah, dan tutup botol kuning ke botol kuning yang sudah disediakan di atas meja.", ape: "Botol plastik dan tutupnya (Merah & Kuning)." },
    { code: "M4", tema: "Rumahku", kognitif: "Membedakan ukuran benda yang sangat kontras (Besar vs Kecil).", bahasa: "Mengucapkan kata \"Besar\" dan \"Kecil\" secara lisan.", aktivitas: "Memasukkan boneka beruang yang sangat besar ke kotak besar, dan boneka mini ke mangkuk kecil yang ada di karpet sentra.", ape: "Boneka beruang besar dan kecil, 2 wadah." },
    { code: "M5", tema: "Ruang Tamu", kognitif: "Meraba ciri bentuk lingkaran (Bulat, halus, tidak tajam).", bahasa: "Mengenal kosa kata benda berbentuk bulat di dalam rumah.", aktivitas: "Meraba tepi piring plastik dan koin besar menggunakan ujung jari, lalu menggelindingkannya di atas meja persiapan.", ape: "Piring plastik kecil, koin besar/tutup stoples." },
    { code: "M6", tema: "Kamar Tidur", kognitif: "Meraba ciri bentuk persegi (Kotak, memiliki ujung tajam).", bahasa: "Meniru kata benda \"Kotak\" secara lisan.", aktivitas: "Meraba sudut-sudut bantal kotak mini atau biskuit crackers kotak, lalu menatanya menjadi barisan lurus di atas nampan.", ape: "Bantal kotak mini atau biskuit crackers kotak." },
    { code: "M7", tema: "Dapur Ibu", kognitif: "Memasangkan bentuk lingkaran dan persegi ke bayangannya.", bahasa: "Mengikuti instruksi lisan sangat sederhana 1 langkah.", aktivitas: "Meletakkan tutup stoples bulat di atas kertas yang sudah digambar pola lingkaran hitam besar oleh guru (Shape Matching dasar).", ape: "Tutup stoples bulat, lembar pola lingkaran." },
    { code: "M8", tema: "Sekolahku", kognitif: "Mengelompokkan benda berdasarkan 1 atribut (Warna saja).", bahasa: "Mengucapkan nama mainan sekolah yang dipegang.", aktivitas: "Memisahkan balok kayu di meja: kumpulkan semua balok yang berwarna merah saja ke dalam kotak (abaikan bentuk baloknya).", ape: "Balok kayu aneka warna dan bentuk, kotak." },
    { code: "M9", tema: "Anggota Tubuh", kognitif: "Memahami konsep kuantitas \"1\" (Ada vs Tidak Ada).", bahasa: "Menggunakan jari tangan untuk menunjuk objek tunggal.", aktivitas: "Menunjuk hidungnya sendiri di cermin sambil memegang 1 buah replika jeruk di tangan dan berkata: \"Satu jeruk.\"", ape: "Cermin meja, replika buah jeruk plastik." },
    { code: "M10", tema: "Panca Indra", kognitif: "Memahami konsep kuantitas \"2\" (Satu lagi / Sepasang).", bahasa: "Meniru ucapan kata bilangan dasar (Satu, Dua).", aktivitas: "Mengambil 2 buah sendok mainan dari mangkuk menggunakan tangan kanan dan kiri secara bersamaan, lalu menaruhnya di meja.", ape: "Sendok plastik mainan, mangkuk plastik." },
    { code: "M11", tema: "Mainan Outdoor", kognitif: "Membilang kuantitas benda kecil rentang angka 1–2.", bahasa: "Melatih koordinasi mata-tangan (memasukkan objek ke lubang).", aktivitas: "Memasukkan 2 butir kelereng besar satu per satu ke dalam botol transparan sambil mendengarkan bunyi jatuhnya: Plung (satu), Plung (dua).", ape: "Kelereng besar, botol plastik bening." },
    { code: "M12", tema: "Review Q1", kognitif: "Penguatan ingatan warna merah/kuning dan jumlah benda 1–2.", bahasa: "Memberikan respon anggukan/gelengan kepala saat ditanya guru.", aktivitas: "Bermain tebak warna dan jumlah bersama guru menggunakan media kantong rahasia berisi bola merah dan kuning (maksimal 2 bola).", ape: "Kantong kain rahasia, bola warna." }
  ]
};

const SEED_SENTRA_45 = {
  title: "Sentra Persiapan Q1 — TK A 4–5 Tahun",
  meta: "2026/2027 · Kuartal 1 · Usia 4–5 tahun · Diri Sendiri & Lingkungan Terdekat",
  weeks: [
    { code: "M1", tema: "Aku & Tubuhku", kognitif: "Membedakan dua warna kontras secara visual (Merah & Kuning).", bahasa: "Mengenali bunyi fonem awal kata warna (/m/ pada merah, /k/ pada kuning).", aktivitas: "Menyortir jepit baju ke papan flanel berlabel huruf besar M (merah) dan K (kuning) sembari meniru bunyi hurufnya.", ape: "Jepit baju warna, papan huruf flanel M dan K." },
    { code: "M2", tema: "Kesukaanku", kognitif: "Mengelompokkan benda konkret berdasarkan kesamaan warna (Biru & Hijau).", bahasa: "Melatih kemampuan bahasa ekspresif (menyebutkan nama objek kesukaan).", aktivitas: "Berburu kancing di sensory bin, mengelompokkannya ke mangkuk biru/hijau, lalu menyebutkan namanya: \"Ini mainan hijau.\"", ape: "Kotak sensorik, kancing warna, mangkuk sortir." },
    { code: "M3", tema: "Keluargaku", kognitif: "Membedakan ukuran dimensi objek secara visual (Besar vs Kecil).", bahasa: "Menggunakan kata sifat perbandingan (\"besar\" / \"kecil\") dalam frasa.", aktivitas: "Memisahkan kartu gambar pakaian Ayah vs anak ke dua wadah yang diberi simbol visual baju BESAR dan baju KECIL.", ape: "Kartu gambar pakaian, 2 kotak label ukuran." },
    { code: "M4", tema: "Rumahku", kognitif: "Mengidentifikasi objek yang berbeda sendiri dalam kelompok (odd-one-out).", bahasa: "Menjelaskan alasan perbedaan objek menggunakan kalimat sederhana.", aktivitas: "Menemukan 1 kartu gambar mobil di antara 3 kartu peralatan dapur, lalu menyisihkannya sambil berkata: \"Mobil bukan di dapur.\"", ape: "Kartu kategori dapur, kartu mainan mobil." },
    { code: "M5", tema: "Ruang Tamu", kognitif: "Mengenali karakteristik lingkaran (bentuk bulat, tidak memiliki sudut).", bahasa: "Melatih kontrol motorik halus (menjiplak bentuk/form drawing).", aktivitas: "Menjiplak koin atau tutup botol di atas kertas menggunakan krayon warna, lalu mewarnai bagian dalam lingkaran tersebut.", ape: "Koin, tutup botol, kertas, krayon." },
    { code: "M6", tema: "Kamar Tidur", kognitif: "Mengenali ciri persegi (bentuk kotak dengan 4 ujung tajam).", bahasa: "Memahami konsep posisi ruang/spasial (\"di dalam\" / \"di luar\").", aktivitas: "Menyusun 4 stik es krim menjadi persegi, lalu menaruh balok huruf mainan di dalam kotak stik dan sisa stik di luar kotak.", ape: "Stik es krim, balok huruf kayu." },
    { code: "M7", tema: "Dapur Ibu", kognitif: "Mengenali ciri segitiga (memiliki 3 ujung/sudut tajam).", bahasa: "Membaca petunjuk visual gambar langkah demi langkah secara runtut.", aktivitas: "Memotong playdough menjadi segitiga sesuai kartu instruksi bergambar (Langkah 1, 2, 3), lalu menyentuh dan menghitung 3 sudutnya.", ape: "Playdough, pisau plastik, kartu panduan visual." },
    { code: "M8", tema: "Sekolahku", kognitif: "Memasukkan bentuk geometri ke cetakan yang sesuai (Shape Matching).", bahasa: "Mencocokkan bentuk geometri konkrit dengan lambang bayangannya.", aktivitas: "Memasukkan balok kayu geometri (lingkaran, persegi, segitiga) ke lubang papan pasak kotak yang sesuai bentuknya.", ape: "Papan pasak geometri kayu tiga bentuk utama." },
    { code: "M9", tema: "Anggota Tubuh", kognitif: "Memahami konsep kuantitas \"1\" dengan menunjuk satu benda nyata.", bahasa: "Meniru bentuk garis tegak lurus (pra-menulis angka 1) pada media taktil.", aktivitas: "Menaruh tepat 1 kancing di atas gambar \"1 Hidung\", lalu menggoreskan jari membuat garis tegak (angka 1) di atas nampan pasir halus.", ape: "Kartu gambar hidung, kancing, nampan pasir." },
    { code: "M10", tema: "Panca Indra", kognitif: "Memahami jumlah \"2\" sebagai konsep sepasang objek terpisah.", bahasa: "Mengenal kosakata organ tubuh yang memiliki pasangan.", aktivitas: "Memasangkan gambar 2 mata dan 2 telinga, lalu menjepitkan jepitan baju bertuliskan simbol angka 2 pada kartu gambar yang pas.", ape: "Kartu panca indra, jepit kayu angka 2." },
    { code: "M11", tema: "Mainan Outdoor", kognitif: "Membilang secara runtut dan konsisten untuk jumlah benda 1–3.", bahasa: "Melatih artikulasi fonem saat membilang (Satu, Dua, Tiga).", aktivitas: "Menjatuhkan 3 kelereng satu per satu ke dalam corong matematika berlabel angka 3 sambil berhitung dengan suara lantang dan jelas.", ape: "Kelereng, corong matematika angka 3." },
    { code: "M12", tema: "Review Q1", kognitif: "Penguatan klasifikasi warna, bentuk dasar, dan kuantitas angka 1–3.", bahasa: "Mengikuti instruksi lisan sederhana satu langkah dari guru.", aktivitas: "Bermain mencocokkan kartu: menghitung jumlah gambar benda konkrit (1-3) lalu meletakkan kartu simbol angka yang tepat di sampingnya.", ape: "Kartu pasangan angka dan gambar konkret." }
  ]
};

function seedCurriculum(seed) {
  const d = ensureCur(load());
  const exists = (d.curriculum.rppm || []).some(x => x.title === seed.title);
  if (exists) {
    alert("Dokumen ini sudah ada di kurikulum.");
    return;
  }
  d.curriculum.rppm.push({
    id: uid(),
    title: seed.title,
    meta: seed.meta,
    content: weeksToContent(seed.weeks),
    weeks: seed.weeks,
    uploadedAt: new Date().toISOString()
  });
  save(d);
  renderAll();
  alert(`Berhasil memuat ${seed.weeks.length} minggu: ${seed.title}`);
}

$("seed-sentra-34").onclick = () => seedCurriculum(SEED_SENTRA_34);
$("seed-sentra-45").onclick = () => seedCurriculum(SEED_SENTRA_45);

/* ---------- raw JSON ---------- */
function renderRaw() {
  const d = load();
  $("raw-json").value = JSON.stringify(d, null, 2);
}

$("save-raw").onclick = () => {
  try {
    const parsed = JSON.parse($("raw-json").value);
    save(parsed);
    alert("JSON berhasil disimpan.");
    renderAll();
  } catch (err) {
    alert("JSON tidak valid: " + err.message);
  }
};

$("export-json").onclick = () => {
  const blob = new Blob([JSON.stringify(load(), null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `handesk-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
};

$("import-json").onclick = () => $("import-file").click();
$("import-file").onchange = e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const parsed = JSON.parse(reader.result);
      if (!confirm("Import akan menimpa data saat ini. Lanjutkan?")) return;
      save(parsed);
      renderAll();
      alert("Import berhasil.");
    } catch (err) {
      alert("File JSON tidak valid.");
    }
  };
  reader.readAsText(file);
};

/* ---------- modal helper ---------- */
let modalSaveFn = null;
function openEditModal(title, html, onSave) {
  $("edit-modal-title").textContent = title;
  $("edit-modal-body").innerHTML = html;
  modalSaveFn = onSave;
  $("edit-modal").classList.remove("hidden");
}
function closeEditModal() {
  $("edit-modal").classList.add("hidden");
  modalSaveFn = null;
}
$("edit-modal-close").onclick = closeEditModal;
$("edit-modal-cancel").onclick = closeEditModal;
$("edit-modal-save").onclick = () => { if (modalSaveFn) modalSaveFn(); };
$("edit-modal").onclick = e => { if (e.target.id === "edit-modal") closeEditModal(); };

/* ---------- tabs ---------- */
document.querySelectorAll(".tabs .tab").forEach(btn => {
  btn.onclick = () => {
    document.querySelectorAll(".tabs .tab").forEach(t => t.classList.toggle("active", t === btn));
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.toggle("active", p.id === "tab-" + btn.dataset.tab));
    if (btn.dataset.tab === "alldata") renderRaw();
  };
});

/* ---------- main render ---------- */

/* ---------- roster (data anak dari DOCX/CSV) ---------- */
function parseRosterText(text) {
  const lines = String(text || "").split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const out = [];
  const seen = new Set();
  lines.forEach(line => {
    // skip header-ish
    if (/^(nama|name|no\.?|siswa)/i.test(line) && line.length < 40) return;
    let name = "", cls = "", note = "";
    if (line.includes("|")) {
      const p = line.split("|").map(x => x.trim());
      name = p[0] || ""; cls = p[1] || ""; note = p[2] || "";
    } else if (line.includes(";")) {
      const p = line.split(";").map(x => x.trim());
      name = p[0] || ""; cls = p[1] || ""; note = p[2] || "";
    } else if (line.includes(",")) {
      const p = line.split(",").map(x => x.trim());
      name = p[0] || ""; cls = p[1] || ""; note = p.slice(2).join(", ") || "";
    } else if (/\(([^)]+)\)\s*$/.test(line)) {
      const m = line.match(/^(.*?)\s*\(([^)]+)\)\s*$/);
      name = (m[1] || "").trim(); cls = (m[2] || "").trim();
    } else if (/\t/.test(line)) {
      const p = line.split(/\t/).map(x => x.trim());
      name = p[0] || ""; cls = p[1] || ""; note = p[2] || "";
    } else {
      name = line.replace(/^\d+[\.\)]\s*/, "").trim();
    }
    if (!name || name.length < 2) return;
    const key = (name + "|" + cls).toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ id: uid(), name, class: cls, note });
  });
  return out;
}

async function extractDocxText(file) {
  if (typeof JSZip === "undefined") throw new Error("JSZip belum termuat (perlu internet untuk CDN). Pakai CSV/TXT atau tempel teks.");
  const zip = await JSZip.loadAsync(file);
  const entry = zip.file("word/document.xml");
  if (!entry) throw new Error("File DOCX tidak valid (document.xml tidak ada).");
  const xml = await entry.async("string");
  // paragraphs to newlines
  let text = xml
    .replace(/<\/w:p>/g, "\n")
    .replace(/<w:tab\/>/g, "\t")
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
  return text;
}

function saveRoster(list, mode) {
  const d = load();
  if (mode === "replace") d.roster = list;
  else {
    // merge
    d.roster = d.roster || [];
    const seen = new Set(d.roster.map(s => (s.name + "|" + (s.class||"")).toLowerCase()));
    list.forEach(s => {
      const k = (s.name + "|" + (s.class||"")).toLowerCase();
      if (!seen.has(k)) { seen.add(k); d.roster.push(s); }
    });
  }
  localStorage.setItem(KEY, JSON.stringify(d));
  renderRoster();
  renderStats();
}

function renderRoster() {
  const d = load();
  const list = d.roster || [];
  const count = $("roster-count");
  if (count) count.textContent = list.length;
  const box = $("roster-list");
  if (!box) return;
  box.innerHTML = list.length
    ? `<table class="table"><tr><th>Nama</th><th>Kelas</th><th>Catatan</th><th></th></tr>
      ${list.map(s => `<tr>
        <td><strong>${esc(s.name)}</strong></td>
        <td>${esc(s.class||"—")}</td>
        <td>${esc(s.note||"—")}</td>
        <td><button class="danger" data-del-roster="${s.id}">hapus</button></td>
      </tr>`).join("")}
    </table>`
    : `<div class="empty">Belum ada data anak. Upload DOCX/CSV atau tempel daftar.</div>`;
  box.querySelectorAll("[data-del-roster]").forEach(btn => {
    btn.onclick = () => {
      const d = load();
      d.roster = (d.roster || []).filter(x => x.id !== btn.dataset.delRoster);
      localStorage.setItem(KEY, JSON.stringify(d));
      renderRoster();
      renderStats();
    };
  });
}

function bindRoster() {
  const status = (msg) => { const el = $("roster-status"); if (el) el.textContent = msg; };
  const parseBtn = $("roster-parse");
  if (parseBtn) {
    parseBtn.onclick = async () => {
      const inp = $("roster-file");
      if (!inp || !inp.files || !inp.files[0]) { status("Pilih file dulu."); return; }
      const file = inp.files[0];
      const name = file.name.toLowerCase();
      try {
        let text = "";
        if (name.endsWith(".docx")) {
          status("Membaca DOCX…");
          text = await extractDocxText(file);
        } else {
          text = await file.text();
        }
        const parsed = parseRosterText(text);
        if (!parsed.length) { status("Tidak ada baris nama yang terbaca. Cek format file."); return; }
        saveRoster(parsed, "replace");
        status("Berhasil memuat " + parsed.length + " anak dari " + file.name);
      } catch (err) {
        status("Gagal: " + (err.message || err));
      }
    };
  }
  const pasteBtn = $("roster-paste-btn");
  if (pasteBtn) {
    pasteBtn.onclick = () => {
      const text = ($("roster-paste") && $("roster-paste").value) || "";
      const parsed = parseRosterText(text);
      if (!parsed.length) { status("Teks kosong / format tidak terbaca."); return; }
      saveRoster(parsed, "replace");
      status("Berhasil memuat " + parsed.length + " anak dari teks.");
    };
  }
  const clearBtn = $("roster-clear");
  if (clearBtn) {
    clearBtn.onclick = () => {
      if (!confirm("Kosongkan seluruh roster anak?")) return;
      saveRoster([], "replace");
      status("Roster dikosongkan.");
    };
  }
}

function renderAll() {
  renderRoster();
  renderStats();
  renderTeachers();
  renderCurriculumAdmin();
  if (!$("tab-alldata").classList.contains("active") === false) renderRaw();
}

$("logout").onclick = () => {
  sessionStorage.removeItem("handesk_admin");
  location.href = "login.html";
};

function hideLoader() {
  const v = document.getElementById("app-version");
  if (v) v.textContent = APP_VERSION;
  const el = document.getElementById("app-loader");
  if (!el) return;
  el.classList.add("is-done");
  setTimeout(() => { try { el.remove(); } catch (_) {} }, 500);
}

function bootAdmin() {
  try { bindRoster(); } catch (e) { console.error("bindRoster", e); }
  try { renderAll(); } catch (e) { console.error("renderAll", e); }
  requestAnimationFrame(function () { setTimeout(hideLoader, 800); });
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bootAdmin);
} else {
  bootAdmin();
}

