const KEY = "handesk_v1";
const APP_VERSION = "v9.7";
const SESSION_KEY = "handesk_session";

let state = {
  users: [],
  current: null,
  // roster global dari admin (bukan input satu-satu guru)
  roster: [],
  activities: [],
  monthly: [],
  developments: [],
  curriculum: { prota: [], rppm: [], rpph: [], other: [] }
};

function load() {
  let d;
  try { d = JSON.parse(localStorage.getItem(KEY)); } catch { d = null; }
  if (!d || typeof d !== "object") {
    return { users: [], data: {}, roster: [], curriculum: { prota: [], rppm: [], rpph: [], other: [] } };
  }
  d.users = Array.isArray(d.users) ? d.users : [];
  d.data = d.data && typeof d.data === "object" ? d.data : {};
  d.roster = Array.isArray(d.roster) ? d.roster : [];
  // migrate old per-teacher students into roster once
  if (!d.roster.length && d.data) {
    const seen = new Set();
    Object.values(d.data).forEach(ud => {
      (ud.students || []).forEach(s => {
        const k = (s.name + "|" + (s.class || "")).toLowerCase();
        if (!seen.has(k)) {
          seen.add(k);
          d.roster.push({
            id: s.id || uid(),
            name: s.name,
            class: s.class || "",
            note: s.note || ""
          });
        }
      });
    });
  }
  d.curriculum = d.curriculum || { prota: [], rppm: [], rpph: [], other: [] };
  ["prota", "rppm", "rpph", "other"].forEach(t => {
    if (!Array.isArray(d.curriculum[t])) d.curriculum[t] = [];
  });
  return d;
}

function saveUser() {
  const d = load();
  d.data = d.data || {};
  d.data[state.current] = {
    activities: state.activities,
    monthly: state.monthly,
    developments: state.developments,
    // keep legacy keys empty-ish for admin stats
    students: [],
    evaluations: [],
    raports: state.developments
  };
  d.users = state.users;
  d.roster = state.roster;
  if (state.curriculum) d.curriculum = state.curriculum;
  localStorage.setItem(KEY, JSON.stringify(d));
}

function userData() {
  const d = load();
  const ud = d.data?.[state.current] || {};
  state.activities = ud.activities || ud.reports || [];
  state.monthly = ud.monthly || [];
  state.developments = ud.developments || ud.raports || [];
  state.roster = d.roster || [];
  state.curriculum = d.curriculum || { prota: [], rppm: [], rpph: [], other: [] };
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
}
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function getSession() {
  try { return sessionStorage.getItem(SESSION_KEY); } catch { return null; }
}
function setSession(user) {
  try { sessionStorage.setItem(SESSION_KEY, user); } catch {}
}
function clearSession() {
  try { sessionStorage.removeItem(SESSION_KEY); } catch {}
}
function currentPage() {
  return document.body.dataset.page || "login";
}

function requireAuth() {
  const user = getSession();
  if (!user) { location.href = "login.html"; return false; }
  const d = load();
  if (!(d.users || []).some(u => u.user === user)) {
    clearSession();
    location.href = "login.html";
    return false;
  }
  state.current = user;
  state.users = d.users || [];
  userData();
  const name = d.users.find(x => x.user === user)?.name || user;
  const navUser = document.getElementById("nav-user");
  if (navUser) navUser.textContent = name;
  const dashName = document.getElementById("dash-name");
  if (dashName) dashName.textContent = name;
  const ver = document.getElementById("app-version");
  if (ver) ver.textContent = APP_VERSION;
  document.querySelectorAll("a.nav-btn").forEach(a => {
    a.classList.toggle("active", a.dataset.page === currentPage());
  });
  return true;
}

function hideLoader() {
  const el = document.getElementById("app-loader");
  const v = document.getElementById("app-version");
  if (v) v.textContent = APP_VERSION;
  if (!el) return;
  el.classList.add("is-done");
  setTimeout(() => { try { el.remove(); } catch (_) {} }, 550);
}

/* ---------- login ---------- */
function renderUsers() {
  const box = document.getElementById("existing-users");
  if (!box) return;
  const d = load();
  state.users = d.users || [];
  box.innerHTML = state.users.length
    ? state.users.map(u =>
        `<div class="user-item" data-u="${esc(u.user)}">
          <span><strong>${esc(u.name)}</strong><br><small>@${esc(u.user)}</small></span>
          <button class="danger" data-del="${esc(u.user)}">×</button>
        </div>`
      ).join("")
    : `<div class="empty">Belum ada profil guru.</div>`;
  box.querySelectorAll(".user-item").forEach(e => {
    e.onclick = () => {
      if (e.target.dataset.del) {
        state.users = state.users.filter(x => x.user !== e.target.dataset.del);
        const d = load();
        d.users = state.users;
        if (d.data) delete d.data[e.target.dataset.del];
        localStorage.setItem(KEY, JSON.stringify(d));
        renderUsers();
        return;
      }
      doLogin(e.dataset.u);
    };
  });
}
function doLogin(user) {
  setSession(user);
  location.href = "dashboard.html";
}

/* ---------- dashboard ---------- */
function renderDashboard() {
  const el = (id, v) => { const n = document.getElementById(id); if (n) n.textContent = v; };
  el("stat-roster", state.roster.length);
  el("stat-activities", state.activities.length);
  el("stat-monthly", state.monthly.length);
  el("stat-dev", state.developments.length);
  const classes = {};
  state.roster.forEach(s => { classes[s.class || "—"] = (classes[s.class || "—"] || 0) + 1; });
  const box = document.getElementById("class-summary");
  if (!box) return;
  box.innerHTML = Object.keys(classes).length
    ? Object.entries(classes).map(([k, v]) =>
        `<div class="list-item"><strong>${esc(k)}</strong><span class="muted">${v} anak</span></div>`
      ).join("")
    : `<div class="empty">Belum ada data anak. Minta admin upload DOCX daftar anak.</div>`;
}

/* ---------- shared: child select from roster ---------- */
function rosterOptions(selected) {
  if (!state.roster.length) {
    return `<option value="">— Belum ada data anak (admin upload DOCX) —</option>`;
  }
  return `<option value="">— Pilih anak —</option>` + state.roster.map(s =>
    `<option value="${s.id}" ${selected === s.id ? "selected" : ""}>${esc(s.name)} — ${esc(s.class || "")}</option>`
  ).join("");
}
function fillChildSelects() {
  document.querySelectorAll("select.child-select").forEach(sel => {
    const cur = sel.value;
    sel.innerHTML = rosterOptions(cur);
  });
}
function getChild(id) {
  return state.roster.find(s => s.id === id) || null;
}

/* ---------- kurikulum ref helpers ---------- */
function getRef(val) {
  if (!val) return null;
  const parts = val.split("|");
  const type = parts[0], id = parts[1];
  const weekIdx = parts[2] !== undefined ? Number(parts[2]) : null;
  const items = (state.curriculum && state.curriculum[type]) || [];
  const doc = items.find(x => x.id === id);
  if (!doc) return null;
  if (weekIdx !== null && !isNaN(weekIdx) && doc.weeks && doc.weeks[weekIdx]) {
    return { ...doc, week: doc.weeks[weekIdx], weekIndex: weekIdx, docTitle: doc.title, title: `${doc.weeks[weekIdx].code || ""} — ${doc.weeks[weekIdx].tema || doc.title}` };
  }
  return doc;
}
function fillRefSelect() {
  const sel = document.getElementById("act-ref");
  if (!sel) return;
  const cur = state.curriculum || {};
  let html = `<option value="">— Pilih acuan (opsional) —</option>`;
  ["rppm", "rpph", "prota", "other"].forEach(type => {
    (cur[type] || []).forEach(item => {
      const weeks = item.weeks || [];
      if (weeks.length) {
        html += `<optgroup label="${esc(item.title)}">`;
        weeks.forEach((w, i) => {
          html += `<option value="${type}|${item.id}|${i}">${esc(w.code || "M"+(i+1))} — ${esc(w.tema || "")}</option>`;
        });
        html += `</optgroup>`;
      } else {
        html += `<option value="${type}|${item.id}">${esc(item.title)}</option>`;
      }
    });
  });
  sel.innerHTML = html;
}

/* ---------- laporan kegiatan ---------- */
function bindActivityForm() {
  const form = document.getElementById("activity-form");
  if (!form) return;
  const refEl = document.getElementById("act-ref");
  if (refEl) {
    refEl.onchange = () => {
      const ref = getRef(refEl.value);
      const box = document.getElementById("act-ref-preview");
      if (!box) return;
      if (!ref) { box.style.display = "none"; return; }
      box.style.display = "block";
      if (ref.week) {
        const w = ref.week;
        box.innerHTML = `<div class="ref-card"><strong>${esc(w.code||"")} — ${esc(w.tema||"")}</strong>
          <small>${esc(ref.docTitle||"")}</small>
          ${w.kognitif?`<p><b>Kognitif:</b> ${esc(w.kognitif)}</p>`:""}
          ${w.aktivitas?`<p><b>Aktivitas:</b> ${esc(w.aktivitas)}</p>`:""}</div>`;
      } else {
        box.innerHTML = `<div class="ref-card"><strong>${esc(ref.title)}</strong><p>${esc((ref.content||"").slice(0,200))}</p></div>`;
      }
    };
  }
  const fillBtn = document.getElementById("act-fill-ref");
  if (fillBtn) {
    fillBtn.onclick = () => {
      const ref = getRef(document.getElementById("act-ref").value);
      if (!ref) { alert("Pilih acuan kurikulum dulu."); return; }
      if (!document.getElementById("act-title").value) document.getElementById("act-title").value = ref.title;
      let body = "";
      if (ref.week) {
        const w = ref.week;
        body = `Acuan: ${ref.docTitle||""}\n${w.code} — ${w.tema}\n`;
        if (w.kognitif) body += `\nTarget Kognitif:\n${w.kognitif}\n`;
        if (w.bahasa) body += `\nTarget Bahasa:\n${w.bahasa}\n`;
        if (w.aktivitas) body += `\nAktivitas:\n${w.aktivitas}\n`;
        if (w.ape) body += `\nAPE:\n${w.ape}\n`;
        body += `\n---\nObservasi / catatan guru:\n`;
      } else {
        body = `Acuan: ${ref.title}\n\n${ref.content||""}\n\nObservasi:\n`;
      }
      const cur = document.getElementById("act-body").value.trim();
      document.getElementById("act-body").value = cur ? cur + "\n\n" + body : body;
    };
  }
  form.onsubmit = e => {
    e.preventDefault();
    const title = document.getElementById("act-title").value.trim();
    const period = document.getElementById("act-period").value.trim();
    const body = document.getElementById("act-body").value.trim();
    if (!title || !body) return;
    const refVal = document.getElementById("act-ref")?.value || "";
    const ref = getRef(refVal);
    state.activities.push({
      id: uid(), title, period, body,
      refTitle: ref ? ref.title : null,
      createdAt: new Date().toISOString()
    });
    e.target.reset();
    const prev = document.getElementById("act-ref-preview");
    if (prev) prev.style.display = "none";
    saveUser();
    renderActivities();
  };
}
function renderActivities() {
  const list = document.getElementById("activity-list");
  if (!list) return;
  list.innerHTML = state.activities.length
    ? state.activities.slice().reverse().map(a =>
        `<article class="report-card">
          <div class="idea-meta">
            <span>${esc(a.period||"")}${a.refTitle?" · "+esc(a.refTitle):""}</span>
            <button class="danger" onclick="delActivity('${a.id}')">hapus</button>
          </div>
          <strong>${esc(a.title)}</strong>
          <p>${esc(a.body)}</p>
        </article>`
      ).join("")
    : `<div class="empty">Belum ada laporan kegiatan.</div>`;
}
window.delActivity = function (id) {
  state.activities = state.activities.filter(x => x.id !== id);
  saveUser();
  renderActivities();
};

/* ---------- laporan persiapan bulanan ---------- */
function bindMonthlyForm() {
  const form = document.getElementById("monthly-form");
  if (!form) return;
  form.onsubmit = e => {
    e.preventDefault();
    const month = document.getElementById("mon-month").value.trim();
    const theme = document.getElementById("mon-theme").value.trim();
    const goals = document.getElementById("mon-goals").value.trim();
    const activities = document.getElementById("mon-activities").value.trim();
    const tools = document.getElementById("mon-tools").value.trim();
    const notes = document.getElementById("mon-notes").value.trim();
    if (!month || !theme) return;
    state.monthly.push({
      id: uid(), month, theme, goals, activities, tools, notes,
      createdAt: new Date().toISOString()
    });
    e.target.reset();
    saveUser();
    renderMonthly();
  };
}
function renderMonthly() {
  const list = document.getElementById("monthly-list");
  if (!list) return;
  list.innerHTML = state.monthly.length
    ? state.monthly.slice().reverse().map(m =>
        `<article class="report-card">
          <div class="idea-meta">
            <span>${esc(m.month)}</span>
            <button class="danger" onclick="delMonthly('${m.id}')">hapus</button>
          </div>
          <strong>${esc(m.theme)}</strong>
          ${m.goals?`<p><b>Tujuan:</b> ${esc(m.goals)}</p>`:""}
          ${m.activities?`<p><b>Kegiatan:</b> ${esc(m.activities)}</p>`:""}
          ${m.tools?`<p><b>Alat/Bahan:</b> ${esc(m.tools)}</p>`:""}
          ${m.notes?`<p>${esc(m.notes)}</p>`:""}
        </article>`
      ).join("")
    : `<div class="empty">Belum ada laporan persiapan bulanan.</div>`;
}
window.delMonthly = function (id) {
  state.monthly = state.monthly.filter(x => x.id !== id);
  saveUser();
  renderMonthly();
};

/* ---------- laporan perkembangan per anak ---------- */
function bindDevForm() {
  const form = document.getElementById("dev-form");
  if (!form) return;
  form.onsubmit = e => {
    e.preventDefault();
    const childId = document.getElementById("dev-child").value;
    const period = document.getElementById("dev-period").value.trim();
    const aspects = document.getElementById("dev-aspects").value.trim();
    const progress = document.getElementById("dev-progress").value.trim();
    const followup = document.getElementById("dev-followup").value.trim();
    const child = getChild(childId);
    if (!child || !period || !progress) {
      alert("Pilih anak dari daftar (upload admin) dan isi perkembangan.");
      return;
    }
    state.developments.push({
      id: uid(),
      childId: child.id,
      childName: child.name,
      className: child.class || "",
      period, aspects, progress, followup,
      createdAt: new Date().toISOString()
    });
    e.target.reset();
    fillChildSelects();
    saveUser();
    renderDev();
  };
}
function renderDev() {
  const list = document.getElementById("dev-list");
  if (!list) return;
  // orphan cleanup
  const ids = new Set(state.roster.map(s => s.id));
  const before = state.developments.length;
  state.developments = state.developments.filter(d => ids.has(d.childId));
  if (state.developments.length !== before) saveUser();

  list.innerHTML = state.developments.length
    ? state.developments.slice().reverse().map(d =>
        `<article class="report-card">
          <div class="idea-meta">
            <span>${esc(d.period)} · ${esc(d.childName)} (${esc(d.className)})</span>
            <button class="danger" onclick="delDev('${d.id}')">hapus</button>
          </div>
          <strong>Perkembangan — ${esc(d.childName)}</strong>
          ${d.aspects?`<p><b>Aspek:</b> ${esc(d.aspects)}</p>`:""}
          <p>${esc(d.progress)}</p>
          ${d.followup?`<p><b>Tindak lanjut:</b> ${esc(d.followup)}</p>`:""}
        </article>`
      ).join("")
    : `<div class="empty">Belum ada laporan perkembangan. Pilih anak dari daftar admin.</div>`;
}
window.delDev = function (id) {
  state.developments = state.developments.filter(x => x.id !== id);
  saveUser();
  renderDev();
};

/* ---------- kurikulum read-only ---------- */
function renderCurriculum() {
  const list = document.getElementById("cur-list");
  if (!list) return;
  const type = document.querySelector("#cur-tabs .tab-btn.active")?.dataset.type || "rppm";
  const items = (state.curriculum && state.curriculum[type]) || [];
  list.innerHTML = items.length
    ? items.map(item => {
        const weeks = item.weeks || [];
        return `<article class="panel cur-card">
          <div class="panel-title"><h3>${esc(item.title)}</h3><span class="stamp">${esc(type.toUpperCase())}</span></div>
          <p class="muted">${esc(item.meta||"")}</p>
          ${weeks.length?`<div class="week-chips">${weeks.map(w=>`<span class="chip">${esc(w.code||"")} ${esc((w.tema||"").slice(0,24))}</span>`).join("")}</div>`:""}
          <button class="btn small" onclick="viewCur('${type}','${item.id}')">Lihat detail</button>
        </article>`;
      }).join("")
    : `<div class="empty">Belum ada dokumen. Minta admin upload di Panel Admin.</div>`;
}
window.viewCur = function (type, id) {
  const item = (state.curriculum[type]||[]).find(x => x.id === id);
  if (!item) return;
  document.getElementById("modal-title").textContent = item.title;
  let body = (item.meta||"") + "\n\n";
  if (item.weeks && item.weeks.length) {
    item.weeks.forEach(w => {
      body += `${w.code||""} — ${w.tema||""}\n`;
      if (w.kognitif) body += `Kognitif: ${w.kognitif}\n`;
      if (w.bahasa) body += `Bahasa: ${w.bahasa}\n`;
      if (w.aktivitas) body += `Aktivitas: ${w.aktivitas}\n`;
      body += "\n";
    });
  } else body += item.content || "";
  document.getElementById("modal-body").textContent = body;
  document.getElementById("modal").classList.remove("hidden");
};
function bindCurriculum() {
  document.querySelectorAll("#cur-tabs .tab-btn").forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll("#cur-tabs .tab-btn").forEach(b => b.classList.toggle("active", b === btn));
      renderCurriculum();
    };
  });
  const close = document.getElementById("modal-close");
  if (close) close.onclick = () => document.getElementById("modal").classList.add("hidden");
}

function bindLogout() {
  const btn = document.getElementById("logout");
  if (!btn) return;
  btn.onclick = () => { clearSession(); location.href = "login.html"; };
}

/* ---------- init ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const page = currentPage();
  if (page === "login") {
    if (getSession()) { location.href = "dashboard.html"; return; }
    renderUsers();
    const form = document.getElementById("login-form");
    if (form) {
      form.onsubmit = e => {
        e.preventDefault();
        const name = document.getElementById("login-name").value.trim();
        let user = document.getElementById("login-user").value.trim().toLowerCase().replace(/\s+/g, "_");
        if (!name || !user) return;
        const d = load();
        d.users = d.users || [];
        if (!d.users.some(u => u.user === user)) {
          d.users.push({ name, user });
          d.data = d.data || {};
          d.data[user] = { activities: [], monthly: [], developments: [] };
          localStorage.setItem(KEY, JSON.stringify(d));
        }
        doLogin(user);
      };
    }
    requestAnimationFrame(() => setTimeout(hideLoader, 1200));
    return;
  }
  if (!requireAuth()) return;
  bindLogout();
  if (page === "dashboard") renderDashboard();
  else if (page === "kegiatan") { fillRefSelect(); bindActivityForm(); renderActivities(); }
  else if (page === "persiapan") { bindMonthlyForm(); renderMonthly(); }
  else if (page === "perkembangan") { fillChildSelects(); bindDevForm(); renderDev(); }
  else if (page === "kurikulum") { bindCurriculum(); renderCurriculum(); }
  requestAnimationFrame(() => setTimeout(hideLoader, 1200));
});
