package com.app.schoolattendance;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean handleUrl(String url) {
        if (url == null) return false;

        // Keep local app pages inside WebView.
        if (url.startsWith("file://") || url.startsWith("about:blank")) {
            return false;
        }

        try {
            if (url.startsWith("whatsapp://")) {
                // Opens the installed WhatsApp app with the pre-filled message.
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                intent.setPackage("com.whatsapp");
                startActivity(intent);
                return true;
            }

            if (url.startsWith("smsto:") || url.startsWith("sms:")) {
                // Opens the default SMS app with recipient + pre-filled message.
                Uri uri = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                startActivity(intent);
                return true;
            }

            if (url.startsWith("https://") || url.startsWith("http://")) {
                // External web links open in the normal browser.
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
                return true;
            }

            // Generic fallback for other installed apps.
            Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
            startActivity(intent);
            return true;

        } catch (ActivityNotFoundException e) {
            if (url.startsWith("whatsapp://")) {
                // If WhatsApp is not installed, open the official web URL.
                try {
                    Uri uri = Uri.parse(url);
                    String phone = uri.getQueryParameter("phone");
                    String text = uri.getQueryParameter("text");
                    String web = "https://wa.me/" + (phone == null ? "" : phone)
                            + "?text=" + Uri.encode(text == null ? "" : text);
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(web)));
                    return true;
                } catch (Exception ignored) {
                }
            }
            Toast.makeText(this, "આ એપ ઉપલબ્ધ નથી.", Toast.LENGTH_SHORT).show();
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "લિંક ખોલી શકાઈ નથી.", Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
