SCHOOL ATTENDANCE - WhatsApp/SMS FIX

આ versionમાં મુખ્ય fix Android WebView માટે છે.

સમस्या:
WebView "intent://..." અથવા "whatsapp://..." ને સામાન્ય HTTPS page તરીકે load કરવાનો પ્રયાસ કરે ત્યારે
net::ERR_HTTP_RESPONSE_CODE_FAILURE / Web page not available દેખાઈ શકે છે.

Fix:
- MainActivity.java માં WebViewClient non-http schemes intercept કરે છે.
- whatsapp:// -> installed WhatsApp app
- smsto:/sms: -> default SMS app
- Message પહેલેથી લખાયેલો રહેશે; userએ ફક્ત Send દબાવવાનું રહેશે.
- WhatsApp installed ન હોય તો wa.me web fallback.
- HTTP/HTTPS links external browserમાં ખૂલે છે.
- Android Back button WebView history handle કરે છે.

Android Studio:
1. આ folder Android Studioમાં open કરો.
2. Gradle sync કરો.
3. Device connect કરીને Run કરો.
4. Existing app package com.app.schoolattendance હોય તો આ source તેના બદલે build કરી શકાય છે.

નોંધ:
ફક્ત HTML file બદલવાથી દરેક Android WebView wrapperમાં external apps launch થવાની ગેરંટી નથી.
આ ZIPમાં native Android WebView handler ઉમેરેલો છે, એટલે આ fix માટે HTML + Android code બંને આપવામાં આવ્યા છે.
