# Notas técnicas — Aldeia do Reino v3.0

## Otimização mobile
- Resolução interna limitada por modo de qualidade.
- Antialiasing desativado em telas pequenas para reduzir custo de GPU.
- Sombras desativadas no modo Suave e em telas estreitas.
- Geometria de personagens reduzida no modo Suave.
- Renderização alternada no modo Suave para diminuir carga.

## Mundo vivo
- NPCs armazenam confiança, medo, humor, lembranças recentes, segredos revelados e última ação do jogador.
- Monstros alternam entre patrulha, investigação, caça e recuo. A agressão e o alimento alteram suas respostas futuras.
- O salvamento local guarda memória social e estado dos monstros.

## Limitações honestas
- O comportamento atual é uma IA de jogo baseada em regras e estado, não um modelo neural local.
- Respostas generativas reais exigem configurar um servidor com uma chave de API privada; não há chave gratuita universal para inserir no código.
- Este pacote contém fonte e configuração Capacitor, não um APK compilado.
- Verifique a licença dos assets Craftpix antes de redistribuir/comercializar.
