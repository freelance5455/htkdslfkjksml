/* OPERATION — núcleo de dados: modelo, validação estrita, persistência verificada, migração do Operation: Discipline e backup. Sem DOM. */
(function(G){'use strict';
var OP=G.OP={},K='op-v1',BK='op-v1-bak',PV='op-prev',OLD='od-v1',st=null,S=null;try{st=G.localStorage}catch(e){}
var E=function(m){throw new Error(m)},isO=function(x){return !!x&&typeof x==='object'&&!Array.isArray(x)};
var iso=function(d){return new Date(d.getTime()-d.getTimezoneOffset()*6e4).toISOString().slice(0,10)};
var add=function(s,n){var d=new Date(s+'T12:00:00');d.setDate(d.getDate()+n);return iso(d)};
var vd=function(d){if(typeof d!=='string'||!/^\d{4}-\d\d-\d\d$/.test(d)||d<'2000-01-01'||d>'2100-12-31')return false;var t=new Date(d+'T12:00:00');return !isNaN(t)&&iso(t)===d};
var vt=function(t){return typeof t==='string'&&/^([01]\d|2[0-3]):[0-5]\d$/.test(t)};
var s=function(x,n){return x==null?'':String(x).slice(0,n)};
var esc=function(t){return String(t).replace(/[&<>"'`\/]/g,function(c){return'&#'+c.charCodeAt(0)+';'})};
/* Checksums compatíveis com os backups do Operation: Discipline (djb2 v1/v2, djb2+FNV v3). Detectam corrupção, não são assinatura. */
var h1=function(t){var h=5381;for(var i=0;i<t.length;i++)h=(h*33^t.charCodeAt(i))>>>0;return h};
var h2=function(t){var a=5381,b=0x811c9dc5;for(var i=0;i<t.length;i++){var c=t.charCodeAt(i);a=(a*33^c)>>>0;b=Math.imul(b^c,16777619)>>>0}return 'h2:'+a.toString(16).padStart(8,'0')+b.toString(16).padStart(8,'0')};
var CV=['solid','lines','dots','grid'];
var HX=function(v,d){return /^#[0-9a-f]{6}$/i.test(v)?v:d};
var SKE={mat:['leather','cloth','canvas','kraft','metal'],fin:['matte','satin','gloss'],spine:['band','stitch','metal'],deco:['none','corners','frame','monogram'],style:['classic','modern','minimal'],paper:['white','aged','cream','dots','grid','ruled','plain'],margin:['line','double','dotted','none'],font:['serif','hand','sans','mono'],hs:['bold','caps','underline','accent'],sub:['italic','plain','caps'],tab:['folder','flag','pill'],mark:['ribbon','clip','none'],num:['foot','corner','none'],note:['sticky','boxed','plain'],hl:['marker','underline','box'],open:['anim','instant']};
var SKD={cv:'#5b3a29',mat:'leather',fin:'satin',tex:55,spine:'stitch',deco:'corners',style:'classic',title:'Operation Discipline',paper:'cream',margin:'line',font:'serif',size:17,lh:17,ink:'#2b2620',hs:'bold',sub:'italic',tab:'folder',tc:['#8a6f4e','#b5523b','#3f7d5a','#3d6aa8','#8a5aa8','#b08a2e'],mark:'ribbon',num:'foot',note:'sticky',hl:'marker',spd:100,fx:70,snd:false,open:'anim',swipe:true};
var SKR={tex:[0,100],size:[14,22],lh:[13,22],spd:[50,200],fx:[0,100]};
function skinNorm(o){o=isO(o)?o:{};var R={};Object.keys(SKD).forEach(function(k){var d=SKD[k],v=o[k];if(SKE[k])R[k]=SKE[k].indexOf(v)>=0?v:d;else if(k==='cv'||k==='ink')R[k]=HX(v,d);else if(k==='title')R[k]=typeof v==='string'?v.slice(0,24):d;else if(k==='tc')R[k]=d.map(function(x,i){return Array.isArray(v)?HX(v[i],x):x});else if(typeof d==='boolean')R[k]=typeof v==='boolean'?v:d;else{var n=Math.round(+v),l=SKR[k];R[k]=isFinite(n)&&n>=l[0]&&n<=l[1]?n:d}});return R}
function empty(){return{v:5,rev:0,n:2,nb:[{id:1,name:'Caixa de entrada',desc:'Escreva primeiro, organize depois.',color:'#8a8f98',arch:false,cv:'solid',sec:[]}],notes:[],tasks:[],events:[],diary:{},days:{},mem:[],goals:[],routines:[],me:{name:'',about:'',routine:'',resp:'',prefs:'',a1:'',a2:''},rfb:{},rhist:[],recent:[],cfg:{accent:'#7c9cff',fs:16,theme:'black',df:'br',ws:0,hide:[],plan:19,unl:'',mat:'',ai:{on:false,url:'',model:''},skin:skinNorm({})}}}
function norm(o){if(!isO(o))E('Estrutura inválida');var R=empty(),ids=new Set(),mx=1;
 var lst=function(k,f,max){var a=o[k];if(a==null)return[];if(!Array.isArray(a)||a.length>max)E('Lista inválida ou grande demais: '+k);return a.map(function(x){if(!isO(x)||!Number.isInteger(x.id)||x.id<1||ids.has(x.id))E('Item inválido em '+k);ids.add(x.id);mx=Math.max(mx,x.id);return f(x)})};
 var sc={};
 var nb=lst('nb',function(x){var ss=[];if(Array.isArray(x.sec))x.sec.slice(0,20).forEach(function(q){if(isO(q)&&Number.isInteger(q.id)&&q.id>0&&!ids.has(q.id)){ids.add(q.id);mx=Math.max(mx,q.id);sc[q.id]=x.id;ss.push({id:q.id,name:s(q.name,40).trim()||'Seção'})}});return{id:x.id,name:s(x.name,40).trim()||'Sem nome',desc:s(x.desc,200),color:/^#[0-9a-f]{6}$/i.test(x.color)?x.color:'#7c9cff',arch:!!x.arch,cv:CV.indexOf(x.cv)>=0?x.cv:'solid',sec:ss}},500);
 if(!nb.some(function(x){return x.id===1})){if(ids.has(1))E('Conflito de identificadores');nb.unshift(R.nb[0]);ids.add(1)}
 var nbi=new Set(nb.map(function(x){return x.id})),ni=function(v){return Number.isInteger(v)&&v>0?v:0};
 R.nb=nb;
 var idf=function(x){return x.id};
 R.goals=lst('goals',function(x){var st=Array.isArray(x.steps)?x.steps.slice(0,30).filter(isO).map(function(q){return{t:s(q.t,120).trim()||'Etapa',done:!!q.done}}):[],lg=Array.isArray(x.log)?x.log.slice(-200).filter(function(q){return isO(q)&&vd(q.d)}).map(function(q){return{d:q.d,p:Math.min(100,Math.max(0,Math.round(+q.p||0))),n:s(q.n,200)}}):[];return{id:x.id,t:s(x.t,120).trim()||'Meta',d:s(x.d,2000),cat:s(x.cat,30),term:['c','m','l'].indexOf(x.term)>=0?x.term:'m',due:vd(x.due)?x.due:'',pr:['L','M','H'].indexOf(x.pr)>=0?x.pr:'M',steps:st,log:lg,kw:Array.isArray(x.kw)?x.kw.slice(0,12).map(function(k){return s(k,30).toLowerCase().trim()}).filter(Boolean):[],done:ni(x.done),c:ni(x.c)}},500);
 var gs=new Set(R.goals.map(idf));
 R.routines=lst('routines',function(x){var dy=Array.isArray(x.days)?x.days.filter(function(d,i,a){return Number.isInteger(d)&&d>=0&&d<=6&&a.indexOf(d)===i}):[];return{id:x.id,t:s(x.t,80).trim()||'Rotina',days:dy,time:vt(x.time)?x.time:'',cat:s(x.cat,30),obs:s(x.obs,500),req:x.req!==false,min:Math.min(1440,ni(x.min)),goal:gs.has(x.goal)?x.goal:0,on:x.on!==false}},500);
 var rs=new Set(R.routines.map(idf));
 R.notes=lst('notes',function(x){var tg=Array.isArray(x.tags)?x.tags.slice(0,20).map(function(t){return s(t,30).trim()}).filter(Boolean):[];return{id:x.id,t:s(x.t,200),b:s(x.b,2e5),nb:nbi.has(x.nb)?x.nb:1,sec:sc[x.sec]===(nbi.has(x.nb)?x.nb:1)?x.sec:0,tags:tg,pin:!!x.pin,fav:!!x.fav,arch:!!x.arch,del:ni(x.del),c:ni(x.c),u:ni(x.u),h:Array.isArray(x.h)?x.h.slice(-5).filter(isO).map(function(v){return{t:s(v.t,200),b:s(v.b,2e5),u:ni(v.u)}}):[]}},50000);
 R.tasks=lst('tasks',function(x){return{id:x.id,t:s(x.t,200).trim()||'Sem título',d:s(x.d,2000),due:vd(x.due)?x.due:'',pr:['L','M','H'].indexOf(x.pr)>=0?x.pr:'M',s:x.s==='done'?'done':x.s==='cancel'?'cancel':'open',per:['m','t','n'].indexOf(x.per)>=0?x.per:'',nb:nbi.has(x.nb)?x.nb:0,note:ni(x.note),cat:s(x.cat,30),time:vt(x.time)?x.time:'',min:Math.min(1440,ni(x.min)),rt:rs.has(x.rt)?x.rt:0,goal:gs.has(x.goal)?x.goal:0,pp:Math.min(999,ni(x.pp)),c:ni(x.c),done:ni(x.done)}},50000);
 R.events=lst('events',function(x){if(!vd(x.date))E('Data inválida em compromisso');return{id:x.id,t:s(x.t,200).trim()||'Sem título',date:x.date,time:vt(x.time)?x.time:'',per:['m','t','n'].indexOf(x.per)>=0?x.per:'',note:ni(x.note),c:ni(x.c)}},50000);
 if(o.diary!=null){if(!isO(o.diary))E('Diário inválido');Object.keys(o.diary).forEach(function(d){if(!vd(d))E('Data inválida no diário');var t=s(o.diary[d],2e5);if(t.trim())R.diary[d]=t})}
 R.mem=lst('mem',function(x){return{id:x.id,k:x.k==='conf'?'conf':'decl',t:s(x.t,300).trim(),src:s(x.src,30),d:vd(x.d)?x.d:''}},300).filter(function(m){return m.t});
 if(o.days!=null){if(!isO(o.days))E('Páginas inválidas');Object.keys(o.days).forEach(function(d){if(!vd(d))E('Data inválida nas páginas');var q=o.days[d];if(!isO(q))return;var r={mood:Math.min(5,ni(q.mood)),closed:ni(q.closed),rd:Math.min(999,ni(q.rd)),rtd:Array.isArray(q.rtd)?q.rtd.slice(0,200).filter(Number.isInteger):[]};['obj','evn','sum','ok','learn','imp','obs'].forEach(function(f){r[f]=s(q[f],2e4)});R.days[d]=r})}
 var m=isO(o.me)?o.me:{};R.me={name:s(m.name,60),about:s(m.about,2000),routine:s(m.routine,2000),resp:s(m.resp,2000),prefs:s(m.prefs,2000),a1:vt(m.a1)?m.a1:'',a2:vt(m.a2)?m.a2:''};
 if(isO(o.rfb))Object.keys(o.rfb).slice(0,300).forEach(function(k){var q=o.rfb[k];if(isO(q)&&(q.v==='u'||q.v==='n'||q.v==='l')&&vd(q.d))R.rfb[s(k,60)]={v:q.v,d:q.d}});
 R.rhist=Array.isArray(o.rhist)?o.rhist.slice(-120).filter(function(q){return isO(q)&&vd(q.d)}).map(function(q){return{id:s(q.id,60),d:q.d,t:s(q.t,200)}}):[];
 R.recent=Array.isArray(o.recent)?o.recent.slice(0,8).map(function(x){return s(x,60)}).filter(Boolean):[];
 var c=isO(o.cfg)?o.cfg:{};R.cfg={accent:/^#[0-9a-f]{6}$/i.test(c.accent)?c.accent:'#7c9cff',fs:Number.isInteger(c.fs)?Math.min(20,Math.max(14,c.fs)):16,theme:c.theme==='graphite'?'graphite':'black',df:c.df==='iso'?'iso':'br',ws:c.ws===1?1:0,hide:Array.isArray(c.hide)?c.hide.slice(0,10).map(function(x){return s(x,10)}):[],plan:Number.isInteger(c.plan)&&c.plan>=0&&c.plan<=23?c.plan:19,unl:vd(c.unl)?c.unl:'',mat:vd(c.mat)?c.mat:'',ai:{on:!!(isO(c.ai)&&c.ai.on),url:isO(c.ai)?s(c.ai.url,200):'',model:isO(c.ai)?s(c.ai.model,60):''},skin:skinNorm(c.skin)};
 R.n=Math.max(Number.isInteger(o.n)?o.n:2,mx+1);R.rev=Number.isInteger(o.rev)&&o.rev>=0&&o.rev<1e12?o.rev:0;return R}
/* Migração: missões do Operation: Discipline viram tarefas (pendentes/falhas → abertas; concluídas → concluídas; categorias preservadas como rótulo).
   Canceladas/reagendadas e o extrato de XP não têm equivalente: ficam intactos na chave original "od-v1", que NUNCA é alterada ou apagada. */
function migrateOld(o){if(!isO(o)||!Array.isArray(o.m))E('Dados antigos inválidos');var R=empty(),cat={};(Array.isArray(o.c)?o.c:[]).forEach(function(c){if(isO(c))cat[c.id]=s(c.name,30)});
 o.m.forEach(function(m){if(!isO(m)||m.s==='X'||m.s==='R'||typeof m.title!=='string'||!m.title.trim())return;var dn=m.s==='C';
  R.tasks.push({id:R.n++,t:s(m.title,200),d:s(m.desc,2000),due:vd(m.due)?m.due:(vd(m.date)?m.date:''),pr:m.pr&&'LMH'.indexOf(m.pr)>=0?m.pr:'M',s:dn?'done':'open',nb:0,note:0,time:vt(m.time)?m.time:'',cat:cat[m.cat]||'',c:Number.isInteger(m.created)?m.created:0,done:dn?1:0})});
 return norm(R)}
function persist(V){var j=JSON.stringify(V);try{var old=st.getItem(K);if(old!=null)st.setItem(BK,old);st.setItem(K,j);if(st.getItem(K)!==j)throw new Error('gravação não confirmada')}catch(x){var e=new Error('NÃO SALVO: '+(x.message||x));e.storage=true;throw e}}
var revOf=function(r){try{var o=JSON.parse(r);return o&&Number.isInteger(o.rev)?o.rev:0}catch(e){return -1}};
function load(){if(!st){S=empty();return{blocked:true,warn:'Armazenamento local indisponível: nada será salvo.'}}
 var raw;try{raw=st.getItem(K)}catch(e){S=empty();return{blocked:true,warn:'Não foi possível ler o armazenamento local.'}}
 if(raw==null){var old=null;try{old=st.getItem(OLD)}catch(e){}
  if(old!=null){try{S=migrateOld(JSON.parse(old));persist(S);return{warn:'Dados do Operation: Discipline migrados para tarefas. Os originais continuam guardados e intactos.'}}catch(e){S=empty();return{warn:'Não foi possível migrar os dados antigos ('+e.message+'). Eles continuam intactos; tentaremos de novo na próxima abertura.'}}}
  S=empty();return{}}
 try{S=norm(JSON.parse(raw));return{}}catch(err){
  var ck='op-corrupt-'+Date.now(),kept=false;try{st.setItem(ck,raw);kept=st.getItem(ck)===raw}catch(e){}
  if(!kept){S=empty();return{blocked:true,warn:'Dados ilegíveis e não foi possível preservá-los: alterações bloqueadas.'}}
  try{var b=st.getItem(BK);if(b!=null){S=norm(JSON.parse(b));persist(S);return{warn:'Dados principais ilegíveis. Recuperado da última cópia automática verificada; a última alteração pode ter sido perdida. Original preservado em "'+ck+'".'}}}catch(e){}
  S=empty();return{blocked:true,warn:'Dados ilegíveis ('+err.message+') e sem cópia válida. Original preservado em "'+ck+'". Importe um backup.'}}}
/* Transação: opera numa cópia, valida, grava e confere por leitura. Só depois o estado muda. Recusa se outra janela alterou os dados. */
function commit(fn){if(!st)E('Armazenamento local indisponível');var raw=st.getItem(K);if(raw!=null&&revOf(raw)!==S.rev)E('Os dados mudaram em outra janela. Reinicie o aplicativo. Nada foi alterado.');
 var W=JSON.parse(JSON.stringify(S));fn(W);var V=norm(W);V.rev=S.rev+1;persist(V);S=V;return V}
function exportJson(){var p=JSON.stringify(S);return JSON.stringify({app:'op',v:5,sum:h2(p),p:p,exported:new Date().toISOString()})}
function parse(t){if(typeof t!=='string')E('Conteúdo inválido');if(t.length>4194304)E('Arquivo grande demais (máx. 4 MB)');t=t.replace(/^\uFEFF/,'');var o;try{o=JSON.parse(t)}catch(e){E('Não é um JSON válido')}
 if(!isO(o)||(o.app!=='op'&&o.app!=='od'))E('Não é um backup do Operation');if(typeof o.p!=='string')E('Backup incompleto');
 var ok=o.app==='op'?((o.v===4||o.v===5)&&h2(o.p)===o.sum):((o.v===3&&h2(o.p)===o.sum)||((o.v===1||o.v===2)&&h1(o.p)===o.sum));if(!ok)E('Checksum inválido ou versão não suportada: arquivo corrompido ou alterado');
 var n;try{n=JSON.parse(o.p)}catch(e){E('Dados internos ilegíveis')}return o.app==='op'?norm(n):migrateOld(n)}
function restore(n){if(!st)E('Armazenamento local indisponível');var old=S?JSON.stringify(S):null,V=Object.assign({},n,{rev:(S?S.rev:0)+1}),j=JSON.stringify(V);
 try{if(old!=null)st.setItem(PV,old);st.setItem(K,j);if(st.getItem(K)!==j)throw new Error('gravação não confirmada')}catch(e){try{if(old!=null)st.setItem(K,old)}catch(_){}E('Falha ao gravar: restauração cancelada, estado anterior preservado ('+(e.message||e)+')')}
 S=V;return V}
function undo(){var p=st&&st.getItem(PV);if(p==null)E('Não há restauração para desfazer');var V=norm(JSON.parse(p));V.rev=S.rev+1;persist(V);S=V;try{st.removeItem(PV)}catch(e){}return V}
OP.SKE=SKE;OP.SKD=SKD;OP.SKR=SKR;OP.skinNorm=skinNorm;OP.U={iso:iso,add:add,vd:vd,esc:esc};OP.load=load;OP.get=function(){return S};OP.commit=commit;OP.exportJson=exportJson;OP.parse=parse;OP.restore=restore;OP.undo=undo;OP.hasUndo=function(){try{return !!st&&st.getItem(PV)!=null}catch(e){return false}};OP.hasOld=function(){try{return !!st&&st.getItem(OLD)!=null}catch(e){return false}};OP._migrate=migrateOld;OP.blocked=false;
})(typeof window!=='undefined'?window:globalThis);
