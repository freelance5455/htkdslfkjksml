/* OPERATION DISCIPLINE — interpretação de linguagem natural (pt-BR), 100% local e sem dependências. Só extrai estrutura; quem decide o que executar é o assistente. */
(function(G){'use strict';var OP=G.OP=G.OP||{},NL=OP.NL={};
var nz=function(t){return String(t).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()};
var NUM={um:1,uma:1,dois:2,duas:2,tres:3,quatro:4,cinco:5,seis:6,sete:7,oito:8,nove:9,dez:10},WD={domingo:0,segunda:1,terca:2,quarta:3,quinta:4,sexta:5,sabado:6};
var WDR='(?:segunda|terca|quarta|quinta|sexta|sabado|domingo)',WDT=WDR+'s?(?:-feiras?)?',NR='(?:\\d+|um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove|dez)';
var num=function(s){return NUM[s]!=null?NUM[s]:parseFloat(String(s).replace(',','.'))};
var cap=function(s){s=String(s).replace(/\s+/g,' ').trim().replace(/^[,.:;\-\s]+|[,.:;\-\s]+$/g,'');return s?s[0].toUpperCase()+s.slice(1):''};
var iso=function(d){return new Date(d.getTime()-d.getTimezoneOffset()*6e4).toISOString().slice(0,10)};
var add=function(s,n){var d=new Date(s+'T12:00:00');d.setDate(d.getDate()+n);return iso(d)};
var CATS=[['Descanso',/\b(descans\w*|relax\w*|lazer|meditar|meditac\w*|dormir|sono|folga|familia|passear)\b/],['Exercício',/\b(academia|trein\w*|musculacao|corrida|correr|kickboxing|caminhada|caminhar|natacao|yoga|peito|triceps|biceps|costas|ombro|perna|pernas|cardio|crossfit|exercicio\w*)\b/],['Estudos',/\b(estud\w*|prova|aula|curso|leitura|ler|revisar|revisao|simulado|concurso|faculdade|escola|legislacao|direito|portugues|matematica|quimica|fisica|biologia|historia|geografia|ingles|espanhol|redacao|apostila|resumo|trabalho (?:de|da|do)\b)/],['Trabalho',/\b(trabalho|reuniao|cliente|relatorio|projeto|expediente|email|proposta|apresentacao)\b/],['Saúde',/\b(medic\w*|consulta|dentista|exame|remedio|fisioterapia|psicolog\w*)\b/],['Finanças',/\b(pagar|conta|boleto|banco|reserva|investir|investimento|fatura|orcamento)\b/],['Casa',/\b(limpar|limpeza|mercado|compras|lavar|cozinhar|arrumar|faxina|roupa)\b/]];
NL.cat=function(t){var n=nz(t);for(var i=0;i<CATS.length;i++)if(CATS[i][1].test(n))return CATS[i][0];return''};
var SW='comecar antes depois para com que uma mais como isso esta esse pelo pela dos das nao mas foi ser tem por seu sua nos tarefa atividade minha meu hoje amanha'.split(' ');
NL.tok=function(t){return nz(t).split(/[^a-z0-9]+/).filter(function(w){return w.length>=4&&SW.indexOf(w)<0})};
function nextWd(wd,today){for(var i=1;i<=7;i++){var d=add(today,i);if(new Date(d+'T12:00:00').getDay()===wd)return d}}
var EVN=/^(consulta|reuniao|aula|prova|jantar|almoco|escola|faculdade|show|evento|encontro|exame|entrevista|casamento|aniversario|cinema|viagem)\b/;
var GV=/\b(passar|aprovad[oa]|aprender|melhorar|juntar|economizar|construir|emagrecer|engordar|ganhar|desenvolver|comecar a|manter|conquistar|abrir|comprar|viajar|fluente|dormir|reduzir|parar de|deixar de|ser |tornar)/;
function splitClauses(o,n){var prot=[],re=new RegExp('(?:\\b'+WDT+'\\b(?:\\s*,\\s*|\\s+e\\s+|\\s+a\\s+))+\\b'+WDT+'\\b','g'),m;while((m=re.exec(n)))prot.push([m.index,m.index+m[0].length]);
 var sp=new RegExp('\\s*,\\s*|\\s+e\\s+(?=(?:preciso|precisa|tenho|vou|quero|devo|pretendo|nao|ir|fazer|\\w{3,}(?:ar|er|ir|or))\\b)','g'),out=[],last=0;
 while((m=sp.exec(n))){var s=m.index,e=s+m[0].length;if(prot.some(function(p){return s>=p[0]&&e<=p[1]})||/\bprioridade\b/.test(n.slice(last,s)))continue;out.push([last,s]);last=e}out.push([last,n.length]);
 return out.map(function(p){return[o.slice(p[0],p[1]),n.slice(p[0],p[1])]})}
function clause(o,n,ctx,st){o=o.trim();n=n.trim();if(!o)return null;var X={raw:o},m,q=/\?\s*$/.test(o);
 if(q||/^(como|por que|porque|qual|quais|quanto|quantas|quantos|quando|o que|estou|ainda)\b/.test(n)){X.k='ask';return X}
 var cut=function(re){var mm=re.exec(n);if(!mm)return null;var s=mm.index,e=s+mm[0].length,pad=function(x){return x.slice(0,s)+' '.repeat(e-s)+x.slice(e)};n=pad(n);o=pad(o);return mm};
 var cmd=/^\s*(?:adicione|adiciona|cadastre|cadastra|crie|cria|coloque|coloca|inclua|inclui|programe|agende|marque|marca|lembre|lembra)\b/.test(n);
 if(m=/^(?:quero registrar|queria registrar|registre|registrar|anote|anota|escreva)(?:\s+no diario)?\s*(?:que)?\s+(.+)$/.exec(n)){X.k='diary';X.text=cap(o.slice(n.length-m[1].length));return X}
 if(/^(?:hoje\s+)?(?:consegui|fui|senti|aprendi|percebi|me senti|estive|tive|estava)\b/.test(n)){X.k='diary';X.text=cap(o);return X}
 if(m=/\b(?:meu|minha)\s+horarios?(?:\s+(?:disponivel|livre|disponiveis))?\s+(?:e|eh|sao)?\s*(?:das?|de)?\s*(\d{1,2})\s*(?:h|:)?\s*(\d{2})?\s*(?:as|a|ate)\s*(?:as)?\s*(\d{1,2})\s*(?:h|:)?\s*(\d{2})?/.exec(n)){var hm=function(h,mi){return String(h).padStart(2,'0')+':'+(mi||'00')};X.k='memory';X.a1=hm(m[1],m[2]);X.a2=hm(m[3],m[4]);X.text='Horário disponível: das '+X.a1+' às '+X.a2;return X}
 if(/\b(prefiro|costumo|gosto de|sou mais produtiv[oa]|rendo mais)\b/.test(n)||/^(?:eu\s+)?(?:moro|sou)\b/.test(n)){X.k='memory';X.text=cap(o);return X}
 if((m=/\b(conclui|terminei|finalizei|acabei(?: de)?|completei|cumpri|fiz|realizei)\b/.exec(n))&&!/\b(preciso|quero|vou|tenho que|devo)\b/.test(n.slice(0,m.index))){X.k='done';var rest=n.slice(m.index+m[0].length);X.target=rest.replace(/[^a-z0-9 ]/g,' ').replace(/\b(hoje|ontem|o|a|os|as|minha|meu|de|da|do)\b/g,' ').replace(/\s+/g,' ').trim();return X}
 if((m=/\b(adiei|adiar|remarquei|remarcar|reagende|reagendar|transferi|transferir|passei)\b/.exec(n))){X.k='postpone';var r2=n.slice(m.index+m[0].length),pi=r2.search(/\bpara\b/);X.target=(pi>=0?r2.slice(0,pi):r2).replace(/\b(o|a|os|as|minha|meu|de|da|do|atividade|tarefa)\b/g,' ').replace(/\s+/g,' ').trim();n=n.slice(0,m.index+m[0].length+Math.max(pi,0))+' '.repeat(Math.max(0,n.length-(m.index+m[0].length+Math.max(pi,0))));var rem=n.slice(m.index+m[0].length+Math.max(pi,0));n=n.slice(0,m.index+m[0].length)+(pi>=0?r2.slice(pi):'');X.k='postpone'}
 var pri=/\bprioridade\b/.test(n)&&/\b(?:e|eh|sera)\b|:/.test(n);
 var gtitle=null;if(/\b(quero|pretendo|meta|objetivo|sonho|desejo)\b/.test(n)){gtitle=o.replace(/^\s*(?:eu\s+)?(?:quero|pretendo|desejo)\s+(?:come[cç]ar a\s+)?/i,'').replace(/^\s*(?:meu objetivo|minha meta)\s+(?:e|é)\s+/i,'')}
 var areas=/\b(melhorar|desenvolver|reforcar|focar|evoluir)\b.*?\b(?:principalmente|especialmente)?\s*em\s+(.+)$/.exec(n);
 if(areas&&/\b(principalmente|especialmente|preciso)\b/.test(n)){X.k='areas';X.areas=cap(o.slice(n.length-areas[2].length)).split(/\s*,\s*|\s+e\s+/).map(cap).filter(Boolean);return X}
 /* datas */
 var d=null,rec=null,freq=null;
 if(m=cut(new RegExp('\\b(?:as|aos|nas|nos|toda[s]?|todo[s]?|de)?\\s*\\b('+WDT+')(?:\\s*(?:,|e|a)\\s*'+WDT+')*\\b','g'))){var toks=m[0].match(new RegExp(WDR,'g'))||[],plural=/(?:segunda|terca|quarta|quinta|sexta|sabado|domingo)s\b/.test(m[0])||/\btoda?s?\b/.test(m[0])||/\bde\s+\w+\s+a\s+\w+/.test(m[0]);
  if(plural||toks.length>1){var rng=/\bde\s+(\w+?)s?(?:-feiras?)?\s+a\s+(\w+?)s?(?:-feiras?)?\b/.exec(m[0]);rec=[];if(rng&&WD[rng[1]]!=null&&WD[rng[2]]!=null){var a=WD[rng[1]],b=WD[rng[2]];for(var i=a;;i=(i+1)%7){rec.push(i);if(i===b)break}}else rec=toks.map(function(t){return WD[t]})}
  else d=nextWd(WD[toks[0]],ctx.today)}
 if(!rec&&cut(/\b(todos os dias|diariamente|todo dia)\b/))rec=[0,1,2,3,4,5,6];
 if(m=cut(new RegExp('(?:pelo menos|no minimo|umas?)?\\s*('+NR+')\\s+vez(?:es)?\\s+(?:por|na|em)\\s+semana\\b'))){freq=num(m[1]);X.min=/pelo menos|no minimo/.test(m[0])}
 if(m=cut(/\bdepois de amanha\b/))d=add(ctx.today,2);else if(cut(/\bamanha\b/))d=add(ctx.today,1);else if(cut(/\bhoje\b/))d=ctx.today;else if(cut(/\bontem\b/))d=add(ctx.today,-1);
 else if(m=cut(/\bdia (\d{1,2})\b(?!\s*\/)/)){var dn=+m[1],t0=new Date(ctx.today+'T12:00:00'),y=t0.getFullYear(),mo=t0.getMonth();if(dn<t0.getDate())mo++;var dd=new Date(y,mo,dn,12);d=iso(dd)}
 else if(m=cut(/\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/)){var yy=m[3]?(+m[3]<100?2000+ +m[3]:+m[3]):new Date(ctx.today+'T12:00:00').getFullYear();d=iso(new Date(yy,+m[2]-1,+m[1],12))}
 /* horários, durações, períodos */
 var time=null,per='',dur=0,by='',h;
 if(cut(/\bmeio[- ]dia\b/))time='12:00';else if(cut(/\bmeia[- ]noite\b/))time='00:00';
 else if(m=cut(/\b(as|a partir das|ate as|antes das|depois das)\s*(\d{1,2})(?:\s*(?:h|:)\s*(\d{2})?)?(?:\s*horas?)?(?:\s*da\s*(manha|tarde|noite))?\b/)){h=+m[2];if(m[4]&&m[4]!=='manha'&&h<12)h+=12;if(h<24){var hs=String(h).padStart(2,'0')+':'+(m[3]||'00');if(/antes|ate/.test(m[1]))by=hs;else time=hs}}
 else if(m=cut(/\b(\d{1,2})h(\d{2})?\b/)){h=+m[1];if(h>=6&&h<24)time=String(h).padStart(2,'0')+':'+(m[2]||'00');else dur=h*60+(m[2]?+m[2]:0)}
 if(!dur){if(m=cut(new RegExp('\\b(?:por|durante|de|uns|umas)?\\s*('+NR+')\\s+horas?\\s+e\\s+meia\\b')))dur=Math.round((num(m[1])+.5)*60);else if(cut(/\b(?:por\s+)?meia hora\b/))dur=30;
  else if(m=cut(new RegExp('\\b(?:por|durante|de|uns|umas)?\\s*(\\d+(?:[.,]\\d+)?|um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito)\\s*(?:horas?|hrs?)\\b')))dur=Math.round(num(m[1])*60);
  else if(m=cut(/\b(?:por|durante|de)?\s*(\d+)\s*(?:minutos?|mins?)\b/))dur=+m[1]}
 if(m=cut(/\b(?:de|pela|na|a|durante a)?\s*(manha|tarde|noite|madrugada)\b/))per={manha:'m',tarde:'t',noite:'n',madrugada:'n'}[m[1]];
 var pr='';if(cut(/\b(prioridade|urgente|urgencia|importante|essencial|inadiavel|fundamental)\b/))pr='H';else if(cut(/\b(se der tempo|opcional|sem pressa)\b/))pr='L';
 var base=function(){var s=o.replace(/\s+/g,' ').trim(),t=nz(s),k;if(cmd)s=s.replace(/^\s*(?:adicione|adiciona|cadastre|cadastra|crie|cria|coloque|coloca|inclua|inclui|programe|agende|marque|marca|lembre|lembra)\s+/i,'');
  s=s.replace(/^\s*(?:e\s+|tambem\s+)?(?:(?:eu\s+)?(?:preciso|precisa|tenho que|tenho de|devo|vou|quero|pretendo|gostaria de|nao posso esquecer de|lembrar de|prioridade\s+(?:e|é|sera|será)|minha prioridade\s+(?:e|é|sera|será))\s+)+/i,'');
  s=s.replace(/^\s*ir\s+(?:a|à|ao|as|às)\s+(?=academia)/i,'').replace(/^\s*(?:o|a|os|as)\s+(?=[a-z])/i,function(x){return/^\s*(a|o)\s+/i.test(x)?'':x}).replace(/^\s*(?:a|à|ao|as|às)\s+(?=academia)/i,'');
  s=s.replace(/^\s*separar\s+(?:um\s+)?(?:tempo|momento|um tempinho)\s+para\s+/i,'').replace(/\s+(?:por|durante|de|em|na|no|as|às|a|à|pelo menos)\s*$/i,'').replace(/^\s*(?:que|de)\s+/i,'');
  var am=/^academia\b\s*(.*)$/i.exec(s);if(am){var f=/\b(?:fazer|treinar)\s+(.+)$/i.exec(am[1]);return f?'Academia: treino de '+f[1].trim():'Academia'}return cap(s)};
 X.date=d;X.time=time;X.per=per;X.dur=dur;X.pr=pr;X.by=by;X.cmd=cmd;
 if(X.k==='postpone'){X.date=d;return X}
 if(pri){X.k='task';X.pr='H';X.obj=true;X.title=cap(base().replace(/^(?:minha\s+)?(?:é|e|será|sera)\s+/i,'').replace(/^minha\s+(?:é|e|será|sera)\s+/i,''));X.cat=NL.cat(X.title);return X}
 if(rec||freq){X.k='routine';X.days=rec||[];X.freq=freq;X.title=base();X.cat=NL.cat(X.title);return X}
 if(gtitle!=null&&!d&&!time&&GV.test(nz(gtitle))){X.k='goal';X.title=cap(gtitle);X.cat=NL.cat(gtitle);X.kw=NL.tok(gtitle);return X}
 if(/\b(treinar|estudar|ler|dormir|correr|meditar|caminhar|praticar|me exercitar)\s+mais\b/.test(n)){X.k='vague';X.title=cap(o.replace(/^\s*(?:quero|preciso|pretendo|gostaria de)\s+/i,''));X.cat=NL.cat(X.title);return X}
 if(m=/^\s*(?:tenho|tem|vou ter)\s+(?!que\b|de\b)(.+)$/.exec(n)){X.k='event';var s0=o.replace(/\s+/g,' ').trim();X.title=cap(s0.slice(s0.length-m[1].trim().length));X.cat=NL.cat(X.title);return X}
 if(EVN.test(n.trim())&&(time||per||d)){X.k='event';X.title=base();X.cat=NL.cat(X.title);return X}
 var title=base();if(!title||title.length<3){return null}var tn=nz(title),cc=NL.cat(title);if(!cc&&!/\b\w{3,}(?:ar|er|ir|or)\b/.test(tn)&&!/\b(preciso|tenho que|devo)\b/.test(nz(X.raw))){X.k='unknown';return X}X.k='task';X.title=title;X.cat=NL.cat(title);return X}
NL.parse=function(text,ctx){var o0=String(text).normalize('NFC'),out=[],sents=o0.match(/[^.!?;\n]+[.!?]*/g)||[];
 sents.forEach(function(s){var n=nz(s);if(n.length!==s.length){n=s.toLowerCase()}var cl=splitClauses(s,n),sd=null,first=true;
  cl.forEach(function(c){var X=clause(c[0],c[1],ctx);if(!X)return;if(first&&X.date)sd=X.date;else if(sd&&!X.date&&(X.k==='task'||X.k==='event'||X.k==='priority'))X.date=sd;first=false;
   if(X.k==='areas'){var pg=out[out.length-1];if(pg&&pg.k==='goal'){pg.areas=X.areas;pg.kw=pg.kw.concat(X.areas.map(function(a){return NL.tok(a)}).reduce(function(a,b){return a.concat(b)},[]));return}X.k='goal';X.title='Melhorar em '+X.areas.join(' e ');X.kw=[].concat.apply([],X.areas.map(NL.tok));X.cat='Estudos'}
   if(!X.k)X.k='unknown';out.push(X)});
  if(!cl.length&&s.trim())out.push({k:'unknown',raw:s.trim()})});
 return out};
})(typeof window!=='undefined'?window:globalThis);
