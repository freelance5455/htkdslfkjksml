/* OPERATION DISCIPLINE — o objeto físico: capa, abas laterais, marcador, índice, numeração, virada de página e personalização completa. */
(function(){'use strict';var OP=window.OP,X=OP.X,A=X.A,C=X.C,V=X.V,ui=X.ui,esc=X.esc,$=X.$,S=function(){return OP.get()};
var SECT=[['ix','Índice'],['di','Diário'],['gl','Metas'],['rt','Rotinas'],['st','Análises'],['pf','Perfil']];
var SEC={ix:'ix',notes:'ix',nb:'ix',se:'ix',home:'ix',edit:'ix',di:'di',ag:'di',tk:'di',gl:'gl',gd:'gl',rt:'rt',st:'st',pf:'pf',mem:'pf',cfg:'pf',sk:'pf'};
var idx=function(t){var s=SEC[t]||'ix';for(var i=0;i<SECT.length;i++)if(SECT[i][0]===s)return i;return 0};
OP.turnDir=function(a,b){var d=idx(b)-idx(a);return d>0?1:d<0?-1:0};
var sk=function(){return S().cfg.skin},cur=null;
/* ---------- aplicar aparência ---------- */
var PAPER={white:['#fdfcf8','#e4e1d6'],aged:['#f0e3bd','#d6c595'],cream:['#f4ecd8','#d9cdb0'],dots:['#f8f5ec','#d8d3c4'],grid:['#f8f5ec','#cfd8d6'],ruled:['#f6f0df','#cdd3dc'],plain:['#f5f0e3','#d9cdb0']};
var FONT={serif:'ui-serif,Georgia,"Times New Roman",serif',hand:'"Segoe Print","Bradley Hand","Chalkboard SE","Comic Sans MS",cursive',sans:'system-ui,-apple-system,"Segoe UI",Roboto,sans-serif',mono:'ui-monospace,"SF Mono",Menlo,Consolas,monospace'};
function dark(h,f){return'#'+[1,3,5].map(function(i){return('0'+Math.round(parseInt(h.substr(i,2),16)*f).toString(16)).slice(-2)}).join('')}
function applySkin(k){var r=document.documentElement,P=PAPER[k.paper]||PAPER.cream,st=r.style,set=function(a,b){st.setProperty(a,b)};
 set('--pp',P[0]);set('--rule',P[1]);set('--ink',k.ink);set('--ink2','color-mix(in srgb,'+k.ink+' 55%,'+P[0]+')');set('--font',FONT[k.font]);set('--fs',k.size+'px');set('--lh',k.lh/10);set('--cv',k.cv);set('--cv2',dark(k.cv,.55));set('--tex',k.tex/100);set('--sp',(100/k.spd).toFixed(2));set('--fxk',(k.fx/100).toFixed(2));
 var rl='repeating-linear-gradient(transparent 0 27px,'+P[1]+' 27px 28px)';
 set('--pbg',{ruled:rl,dots:'radial-gradient('+P[1]+' 1.1px,transparent 1.3px) 0 0/20px 20px',grid:'linear-gradient('+P[1]+' 1px,transparent 1px) 0 0/22px 22px,linear-gradient(90deg,'+P[1]+' 1px,transparent 1px) 0 0/22px 22px'}[k.paper]||'none');
 set('--lnimg',{white:rl,aged:rl,cream:rl,ruled:rl}[k.paper]||'none');
 ['mat','fin','spine','deco','style','paper','margin','font','hs','sub','tab','mark','num','note','hl','open'].forEach(function(a){r.dataset[a]=k[a]});cur=k}
OP.skinApply=applySkin;
/* ---------- capa e cena do livro ---------- */
function coverHtml(cls,date){var k=cur||sk(),t=k.title.trim()||'Caderno',w=t.split(' '),a=w[0],b=w.slice(1).join(' ');
 return'<div class="'+cls+'"><i class="cr c1"></i><i class="cr c2"></i><i class="cr c3"></i><i class="cr c4"></i><i class="cvband"></i><i class="cvmono">'+esc(t[0].toUpperCase())+'</i><div class="cvt"><b>'+esc(a)+'</b>'+(b?'<span>'+esc(b)+'</span>':'')+'</div>'+(date?'<small>'+esc(date)+'</small>':'')+'</div>'}
OP.bookScene=function(date){return'<div class="bk"><div class="bpg"></div>'+coverHtml('bcv cvr2',date)+'</div>'};
function openCover(){var k=sk();if(k.open!=='anim'||(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches))return;var o=document.createElement('div');o.className='cvr';o.innerHTML=coverHtml('cvf cvr2');document.body.appendChild(o);if(OP.snd)OP.snd('open');
 var done=function(){if(o.parentNode)o.remove()};o.addEventListener('click',done);o.addEventListener('animationend',function(e){if(e.animationName==='coveropen')done()});setTimeout(done,3200)}
/* ---------- som opcional ---------- */
var ac=null;OP.snd=function(kind){if(!sk().snd)return;try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();var n=ac.currentTime,len=kind==='tap'?.03:kind==='close'?.35:.16,b=ac.createBuffer(1,Math.ceil(ac.sampleRate*len),ac.sampleRate),d=b.getChannelData(0);for(var i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,kind==='close'?1.2:2);
 var s=ac.createBufferSource(),f=ac.createBiquadFilter(),g=ac.createGain();f.type='lowpass';f.frequency.value=kind==='open'||kind==='close'?500:2200;g.gain.value=.25;s.buffer=b;s.connect(f);f.connect(g);g.connect(ac.destination);s.start(n)}catch(e){}};
/* ---------- abas, marcador, numeração ---------- */
OP.tabsHtml=function(tab){var k=sk(),on=SEC[tab]||'ix';return'<div class="tabs">'+SECT.map(function(s,i){var a=s[0]===on;return'<button type="button" data-a="tab" data-t="'+s[0]+'" class="tb2'+(a?' on':'')+'" style="--tc:'+k.tc[i]+'"'+(a?' aria-current="page"':'')+'><span>'+s[1]+'</span></button>'}).join('')+'</div>'};
function firstDay(){var s=S(),a=Object.keys(s.days).concat(s.tasks.map(function(t){return t.due}).filter(Boolean));return a.length?a.reduce(function(m,x){return x<m?x:m},a[0]):X.td()}
var prevAfter=OP.after;OP.after=function(){if(prevAfter)prevAfter();var sh=$('.sheet'),k=sk();if(!sh)return;
 if(k.num!=='none'){var tab=X.tab(),lbl=tab==='di'?'pág. '+(Math.round((new Date(ui.ds+'T12:00:00')-new Date(firstDay()+'T12:00:00'))/864e5)+1):SECT[idx(tab)][1].toLowerCase(),e=document.createElement('div');e.className='pgn';e.textContent=lbl;sh.appendChild(e)}
 if(k.mark!=='none'&&X.tab()!=='ix'&&X.tab()!=='edit'){var rb=document.createElement('button');rb.type='button';rb.className='rib';rb.dataset.a='tab';rb.dataset.t='ix';rb.style.setProperty('--tc',k.tc[idx(X.tab())]);rb.setAttribute('aria-label','Marcador: abrir o índice');sh.appendChild(rb)}
 ui.turn=0;var dpk=document.querySelector('.dp');if(dpk)dpk.max=OP.maxDay()};
/* ---------- índice ---------- */
V.ix=function(){var row=function(t,l,s){return'<button class="ixr" data-a="tab" data-t="'+t+'"><span>'+l+'</span><i></i><em>'+s+'</em></button>'},k=sk(),dv=function(n,i,t){return'<div class="dv" style="--tc:'+k.tc[i]+'"><b>'+n+'</b><span>'+t+'</span></div>'};
 return X.head('Índice',0,X.top())+'<p class="mu">Seu caderno, de ponta a ponta. As abas laterais levam às grandes partes; este índice leva a qualquer página.</p>'
 +dv('I',1,'Dia a dia')+row('di','Hoje e as páginas do diário','Diário')+row('ag','Agenda','Diário')+row('tk','Tarefas','Diário')
 +dv('II',2,'Rumo')+row('gl','Metas','Metas')+row('rt','Rotinas','Rotinas')
 +dv('III',4,'Compreender')+row('st','Análises e recomendações','Análises')+row('pf','Perfil e evolução','Perfil')+row('mem','Memória do caderno','Perfil')
 +dv('IV',5,'Guardados')+row('notes','Notas','Índice')+row('nb','Cadernos temáticos','Índice')+row('se','Busca','Índice')+row('home','Visão geral','Índice')
 +dv('V',3,'Meu caderno')+row('sk','Personalizar meu caderno','Perfil')+row('cfg','Ajustes e backup','Perfil')};
/* ---------- personalizar ---------- */
var LBL={mat:{leather:'Couro',cloth:'Tecido',canvas:'Lona',kraft:'Kraft',metal:'Metal escovado'},fin:{matte:'Fosco',satin:'Acetinado',gloss:'Brilhante'},spine:{band:'Elástico',stitch:'Costura',metal:'Faixa metálica'},deco:{none:'Nenhum',corners:'Cantoneiras',frame:'Moldura',monogram:'Monograma'},style:{classic:'Clássico',modern:'Moderno',minimal:'Minimalista'},paper:{white:'Branco',aged:'Amarelado',cream:'Creme',dots:'Pontilhado',grid:'Quadriculado',ruled:'Pautado',plain:'Liso'},margin:{line:'Linha simples',double:'Linha dupla',dotted:'Pontilhada',none:'Sem margem'},font:{serif:'Serifada',hand:'Manuscrita',sans:'Sem serifa',mono:'Monoespaçada'},hs:{bold:'Negrito',caps:'Caixa-alta',underline:'Sublinhado',accent:'Cor de destaque'},sub:{italic:'Itálico',plain:'Normal',caps:'Caixa-alta'},tab:{folder:'Divisória',flag:'Bandeira',pill:'Pílula'},mark:{ribbon:'Fita',clip:'Clipe',none:'Nenhum'},num:{foot:'Rodapé',corner:'Canto',none:'Sem numeração'},note:{sticky:'Papel adesivo',boxed:'Caixa',plain:'Margem simples'},hl:{marker:'Marca-texto',underline:'Sublinhado',box:'Caixa'},open:{anim:'Abertura animada',instant:'Direto'}};
var THEMES=[['Clássico couro',{}],['Noite de estudo',{cv:'#23262d',mat:'cloth',fin:'matte',deco:'none',paper:'aged',font:'serif',tc:['#5a6270','#7d6aa8','#4f8a7a','#5a7fb0','#a0628a','#a58a45'],ink:'#26231e',note:'boxed'}],['Marfim minimalista',{cv:'#d8d2c4',mat:'kraft',fin:'matte',deco:'none',style:'minimal',paper:'white',font:'sans',ink:'#1d1d1f',tab:'pill',hs:'bold',note:'plain',hl:'underline',tc:['#9a9a9a','#7a8fa6','#7fa38a','#a69a7a','#a68a9a','#8a9aa6']}],['Oceano',{cv:'#1f4a6e',mat:'cloth',fin:'satin',deco:'frame',paper:'grid',font:'sans',ink:'#17324a',tab:'flag',style:'modern',tc:['#2f6f9f','#1f8a8a','#3f7d5a','#6a5fb0','#2f4f9f','#b08a2e']}],['Floresta',{cv:'#2f4a35',mat:'canvas',fin:'matte',deco:'corners',paper:'ruled',font:'serif',ink:'#27302a',spine:'band',tc:['#5a7a4a','#a0743a','#3f7d5a','#4a7a8a','#7a5a8a','#a08a3a']}],['Executivo',{cv:'#101114',mat:'leather',fin:'gloss',deco:'monogram',style:'modern',paper:'white',font:'sans',ink:'#18181b',spine:'metal',tab:'folder',hs:'caps',tc:['#3a3a40','#8a7a4a','#4a6a5a','#4a5a7a','#6a4a6a','#9a8040']}],['Bullet journal',{cv:'#a8814f',mat:'kraft',fin:'matte',deco:'none',style:'minimal',paper:'dots',font:'hand',ink:'#2d2a26',tab:'flag',note:'sticky',hl:'marker',size:18}],['Quadriculado técnico',{cv:'#4b5058',mat:'metal',fin:'satin',deco:'frame',style:'modern',paper:'grid',font:'mono',ink:'#1c2128',size:15,hs:'caps',spine:'metal',tab:'folder'}]];
var draft=null,dirty=false;
function ctl(k,l,t,extra){var v=draft[k],c='data-c="'+(t==='sel'||t==='chk'?'skc':'sk')+'" data-k="'+k+'"';
 if(t==='sel')return'<div class="set"><span>'+l+'</span><select '+c+'>'+OP.SKE[k].map(function(o){return'<option value="'+o+'"'+(o===v?' selected':'')+'>'+LBL[k][o]+'</option>'}).join('')+'</select></div>';
 if(t==='rng'){var r=OP.SKR[k];return'<div class="set"><span>'+l+' <small>'+v+'</small></span><input type="range" min="'+r[0]+'" max="'+r[1]+'" value="'+v+'" '+c+'></div>'}
 if(t==='col')return'<div class="set"><span>'+l+'</span><input type="color" value="'+v+'" '+c+'></div>';
 if(t==='txt')return'<div class="set"><span>'+l+'</span><input type="text" maxlength="24" value="'+esc(v)+'" '+c+'></div>';
 return'<div class="set"><span>'+l+'</span><input type="checkbox" '+(v?'checked ':'')+c+'></div>'}
var grp=function(t,b,o){return'<details class="sg"'+(o?' open':'')+'><summary>'+t+'</summary>'+b+'</details>'};
V.sk=function(){if(!draft)draft=JSON.parse(JSON.stringify(sk()));var k=draft;
 return X.head('Personalizar meu caderno',1,'')+'<p class="mu">Tudo o que você muda aparece na hora, neste mesmo caderno. Só vale depois de Aplicar.</p><div class="skb"><div id="skp" class="skp">'+coverHtml('cvmini cvr2')+'</div><div class="skbt"><button class="b p" data-a="ska">Aplicar</button><button class="b" data-a="skd">Descartar</button><button class="b" data-a="skr">Padrão</button><small id="skst" class="mu">'+(dirty?'Alterações não aplicadas':'Sem alterações')+'</small></div></div>'
 +grp('Temas completos','<div class="chips" style="flex-wrap:wrap">'+THEMES.map(function(t,i){return'<button class="chip" data-a="skt" data-i="'+i+'">'+t[0]+'</button>'}).join('')+'</div>',1)
 +grp('Capa',ctl('cv','Cor da capa','col')+ctl('mat','Material','sel')+ctl('tex','Textura','rng')+ctl('fin','Acabamento','sel')+ctl('spine','Lombada','sel')+ctl('deco','Detalhes decorativos','sel')+ctl('style','Estilo','sel')+ctl('title','Título na capa','txt'))
 +grp('Páginas',ctl('paper','Papel','sel')+ctl('margin','Margem','sel')+ctl('num','Numeração','sel'))
 +grp('Escrita',ctl('font','Tipografia','sel')+ctl('size','Tamanho das letras','rng')+ctl('lh','Espaçamento entre linhas','rng')+ctl('ink','Cor da escrita','col')+ctl('hs','Estilo dos títulos','sel')+ctl('sub','Estilo dos subtítulos','sel'))
 +grp('Elementos internos',ctl('tab','Abas e divisórias','sel')+SECT.map(function(s,i){return'<div class="set"><span>Cor: '+s[1]+'</span><input type="color" value="'+k.tc[i]+'" data-c="sk" data-k="tc" data-i="'+i+'"></div>'}).join('')+ctl('mark','Marcador de página','sel')+ctl('note','Anotações do caderno','sel')+ctl('hl','Destaques','sel'))
 +grp('Experiência',ctl('spd','Velocidade das animações (%)','rng')+ctl('fx','Intensidade dos efeitos','rng')+ctl('snd','Sons de interação','chk')+ctl('open','Modo de abertura','sel')+ctl('swipe','Deslizar o dedo vira a página do diário','chk'))};
function skChange(el){if(!draft)return;var k=el.dataset.k,v=el.type==='checkbox'?el.checked:el.type==='range'?+el.value:el.value;if(k==='tc')draft.tc[+el.dataset.i]=v;else draft[k]=v;draft=OP.skinNorm(draft);dirty=true;applySkin(draft);var p=$('#skp');if(p)p.innerHTML=coverHtml('cvmini cvr2');var s=$('#skst');if(s)s.textContent='Alterações não aplicadas';if(el.type==='range'){var sm=el.parentNode.querySelector('small');if(sm)sm.textContent=v}if(el.dataset.c==='skc'&&el.type!=='checkbox')OP.snd&&OP.snd('tap')}
C.sk={ev:'input',fn:skChange};C.skc={ev:'change',fn:skChange};
A.skt=function(el){draft=OP.skinNorm(Object.assign({},draft,THEMES[+el.dataset.i][1]));if(+el.dataset.i===0)draft=OP.skinNorm(OP.SKD);dirty=true;applySkin(draft);X.draw()};
A.skr=function(){draft=OP.skinNorm(OP.SKD);dirty=true;applySkin(draft);X.draw()};
A.ska=function(){var d=OP.skinNorm(draft);if(X.run(function(W){W.cfg.skin=d},null,true)){dirty=false;draft=JSON.parse(JSON.stringify(d));X.toast('Aparência aplicada ao caderno.',1);var s=$('#skst');if(s)s.textContent='Sem alterações'}};
A.skd=function(){OP.skinLeave();X.go('pf')};
OP.skinLeave=function(){if(dirty)applySkin(sk());draft=null;dirty=false};
/* ---------- deslizar para virar a página do diário ---------- */
var tx=null;document.addEventListener('touchstart',function(e){tx=e.touches.length===1&&X.tab()==='di'&&sk().swipe&&!e.target.closest('textarea,input,select,.ov,.cl')?[e.touches[0].clientX,e.touches[0].clientY]:null},{passive:true});
document.addEventListener('touchend',function(e){if(!tx)return;var t=e.changedTouches[0],dx=t.clientX-tx[0],dy=t.clientY-tx[1];tx=null;if(Math.abs(dx)>80&&Math.abs(dy)<45)A.dnav({dataset:{n:dx<0?'1':'-1'}})},{passive:true});
document.addEventListener('click',function(e){if(e.target.closest('.tb2,.rib,.chip,.b')&&OP.snd)OP.snd('tap')});
applySkin(sk());openCover();X.start();
})();
