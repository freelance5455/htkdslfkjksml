/* OPERATION — interface: navegação, telas, editor com salvamento automático, busca local, configurações e backup. */
(function(){'use strict';
var OP=window.OP,U=OP.U,esc=U.esc,iso=U.iso,add=U.add,$=function(s,r){return(r||document).querySelector(s)};
var td=function(){return iso(new Date())},G=function(){return OP.get()};
var L0=OP.load();OP.blocked=!!L0.blocked;
var tab='di',ed=null,ui={tf:'hoje',nf:'all',nb:0,sc:0,turn:0,cal:td(),mode:'m',q:'',qt:'all',qn:'',qd:'',ds:td()},A={},C={},V={},warn=L0.warn||'',tmr=null,mods=[],prev='di',from='di',armed=false;
var pl=function(n,a,b){return n+' '+(n===1?a:b)},p2=function(n){return String(n).padStart(2,'0')};
var nz=function(t){return String(t).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()};
var fmtD=function(d){return G().cfg.df==='iso'?d:d.slice(8)+'/'+d.slice(5,7)+'/'+d.slice(0,4)};
var dname=function(d){return new Date(d+'T12:00:00').toLocaleDateString('pt-BR',{weekday:'short',day:'numeric',month:'short'})};
var ic=function(p){return'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+p+'</svg>'};
var IC={home:'<path d="M3 11l9-8 9 8M5 10v10h14V10"/>',nb:'<path d="M6 3h12v18H6zM6 7H4M6 12H4M6 17H4"/>',notes:'<path d="M5 4h14v16H5zM9 9h6M9 13h6M9 17h3"/>',ag:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',tk:'<path d="M9 6h11M9 12h11M9 18h11M4 6l1 1 2-2M4 12l1 1 2-2M4 18l1 1 2-2"/>',di:'<path d="M5 4h12a2 2 0 012 2v14H7a2 2 0 01-2-2zM9 8h6"/>',se:'<circle cx="11" cy="11" r="6"/><path d="M20 20l-4-4"/>',cfg:'<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/>',back:'<path d="M15 5l-7 7 7 7"/>',more:'<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>',plus:'<path d="M12 5v14M5 12h14"/>',gl:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>',st:'<path d="M5 20V10M12 20V4M19 20v-7"/>',pf:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>'};
/* ---------- feedback, transações, modais ---------- */
function toast(m,ok){var h=$('#toasts');if(!h){h=document.createElement('div');h.id='toasts';h.setAttribute('role','status');document.body.appendChild(h)}var e=document.createElement('div');e.className='ts'+(ok?' ok':'');e.textContent=m;h.appendChild(e);setTimeout(function(){e.remove()},ok?2200:5500)}
function banner(){var w=$('#warn');if(w)w.textContent=warn}
function run(fn,msg,quiet){if(OP.blocked){toast('Alterações bloqueadas: a integridade dos dados não foi confirmada. Importe um backup.');return false}
 try{OP.commit(fn);if(!quiet)draw();if(msg)toast(msg,1);return true}catch(e){if(e.storage){warn=e.message+' A última alteração foi descartada.';banner()}toast(e.message);return false}}
function arm(){if(!armed){try{history.pushState({a:1},'')}catch(e){}armed=true}}
function modal(t,body,btns){var o=document.createElement('div');o.className='ov';o.innerHTML='<div class="md" role="dialog" aria-modal="true"><h2>'+esc(t)+'</h2><div class="mb">'+body+'</div><div class="mf"></div></div>';var f=$('.mf',o);
 (btns||[]).forEach(function(b){var e=document.createElement('button');e.type='button';e.className='b '+(b[2]||'');e.textContent=b[0];e.addEventListener('click',function(){if(b[1]&&b[1](o)===false)return;close(o)});f.appendChild(e)});
 o.addEventListener('mousedown',function(e){if(e.target===o)close(o)});document.body.appendChild(o);mods.push(o);arm();var i=$('input:not([type=file]),textarea,select',o);if(i&&!/mn/.test(i.className))try{i.focus({preventScroll:true})}catch(e){}return o}
function close(o){var i=mods.indexOf(o);if(i>=0){mods.splice(i,1);o.remove()}}
function ask(t,body,ok,cb,extra){return modal(t,body,(extra||[]).concat([['Cancelar'],[ok,function(o){var v={};o.querySelectorAll('[name]').forEach(function(e){v[e.name]=e.type==='checkbox'?e.checked:e.value});try{return cb(v,o)}catch(x){toast(x.message);return false}},'p']]))}
function sure(msg,fn,label){modal('Confirmar','<p>'+msg+'</p>',[['Cancelar'],[label||'Confirmar',function(){fn()},'p']])}
var fl=function(l,c){return'<label class="fl"><span>'+esc(l)+'</span>'+c+'</label>'};
var inp=function(n,l,t,v,x){return fl(l,'<input name="'+n+'" type="'+t+'" value="'+esc(v==null?'':v)+'" '+(x||'')+'>')};
var txa=function(n,l,v){return fl(l,'<textarea name="'+n+'">'+esc(v||'')+'</textarea>')};
var sel=function(n,l,o,v){return fl(l,'<select name="'+n+'">'+o.map(function(x){return'<option value="'+esc(x[0])+'"'+(String(x[0])===String(v)?' selected':'')+'>'+esc(x[1])+'</option>'}).join('')+'</select>')};
var nbOpts=function(none){return(none?[[0,'Nenhum']]:[]).concat(G().nb.filter(function(b){return !b.arch}).map(function(b){return[b.id,b.name]}))};
/* ---------- inteligência local ---------- */
var STOP='para com que uma mais como isso esta esse pelo pela dos das nao mas foi ser tem por seu sua nos'.split(' ');
function words(n){var m={};nz(n.t+' '+n.b+' '+n.tags.join(' ')).split(/[^a-z0-9]+/).forEach(function(w){if(w.length>3&&STOP.indexOf(w)<0)m[w]=1});return m}
function related(n){var w=words(n);return G().notes.filter(function(x){return x.id!==n.id&&!x.del}).map(function(x){var v=words(x),sc=0;Object.keys(w).forEach(function(k){if(v[k])sc++});x.tags.forEach(function(t){if(n.tags.indexOf(t)>=0)sc+=3});return{n:x,sc:sc}}).filter(function(r){return r.sc>=3}).sort(function(a,b){return b.sc-a.sc}).slice(0,3).map(function(r){return r.n})}
function suggestNb(n){var w=words(n),best=0,id=0;G().nb.forEach(function(b){if(b.id===n.nb||b.arch)return;var sc=0;G().notes.forEach(function(x){if(x.nb!==b.id||x.id===n.id||x.del)return;var v=words(x);Object.keys(w).forEach(function(k){if(v[k])sc++})});if(sc>best){best=sc;id=b.id}});return best>=3?id:0}
function parseDue(t){var n=nz(t);return /\bamanha\b/.test(n)?add(td(),1):/\bhoje\b/.test(n)?td():''}
/* ---------- renderização de notas ---------- */
var il=function(t){return t.replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/\*(.+?)\*/g,'<i>$1</i>').replace(/==(.+?)==/g,'<mark>$1</mark>')};
function md(t){return esc(t).split('\n').map(function(l,i){var m;
 if(m=/^(#{1,3}) (.*)$/.exec(l)){var h=m[1].length+1;return'<h'+h+'>'+il(m[2])+'</h'+h+'>'}
 if(m=/^- \[( |x)\] (.*)$/.exec(l)){var x=m[1]==='x';return'<p class="ck"><button class="bx'+(x?' on':'')+'" data-a="tg" data-i="'+i+'" aria-label="Alternar"></button><span class="'+(x?'dn':'')+'">'+il(m[2])+'</span><button class="l2t" data-a="l2t" data-i="'+i+'">Criar tarefa</button></p>'}
 if(m=/^[-*] (.*)$/.exec(l))return'<p class="li">'+il(m[1])+'</p>';if(l==='---')return'<hr>';return'<p>'+il(l)+'</p>'}).join('')}
var ttl=function(n){return n.t||(n.b.split('\n').filter(function(l){return l.trim()})[0]||'').replace(/^[#\-\s\[\]x*=]+/,'').slice(0,70)||'Sem título'};
var nbOf=function(id){return G().nb.filter(function(b){return b.id===id})[0]||G().nb[0]};
var live=function(){return G().notes.filter(function(n){return !n.del&&!n.arch})};
var byU=function(a,b){return(b.pin-a.pin)||(b.u-a.u)};
function nrow(n){return'<button class="row" data-a="open" data-id="'+n.id+'"><i class="dot" style="background:'+nbOf(n.nb).color+'"></i><span class="rt">'+esc(ttl(n))+(n.pin?'<em>fixada</em>':'')+'</span><span class="rs">'+esc(n.b.replace(/\s+/g,' ').slice(0,90))+'</span></button>'}
function trow(t,pg){var o=t.due&&t.due<td()&&t.s==='open',m=[];if(!pg)m.push(t.due?fmtD(t.due):'Sem prazo');if(t.time)m.push(t.time);else if(t.per)m.push({m:'manhã',t:'tarde',n:'noite'}[t.per]);if(t.min)m.push(t.min+' min');if(t.pr==='H')m.push('prioridade alta');if(t.cat)m.push(esc(t.cat));return'<div class="row tk"><button class="bx'+(t.s==='done'?' on':'')+'" data-a="tkt" data-id="'+t.id+'" aria-label="Concluir"></button><button class="tt" data-a="tke" data-id="'+t.id+'"><span class="'+(t.s==='done'?'dn':'')+'">'+esc(t.t)+'</span>'+(m.length?'<small class="'+(o?'od':'')+'">'+m.join(', ')+'</small>':'')+'</button></div>'}
var evSort=function(a,b){return(a.date+(a.time||'99')).localeCompare(b.date+(b.time||'99'))};
function erow(e){return'<button class="row" data-a="eve" data-id="'+e.id+'"><span class="rt">'+esc(e.t)+'</span><small>'+fmtD(e.date)+(e.time?' às '+e.time:'')+'</small></button>'}
/* ---------- telas ---------- */
function head(t,back,right){return'<header class="hd">'+(back?'<button class="ib" data-a="back" aria-label="Voltar">'+ic(IC.back)+'</button>':'')+'<h1>'+esc(t)+'</h1><div class="hr">'+(right||'')+'</div></header>'}
var ib=function(a,i,l){return'<button class="ib" data-a="'+a+'" aria-label="'+l+'">'+ic(IC[i])+'</button>'};
var top=function(){return ib('go-se','se','Buscar')+ib('go-cfg','cfg','Ajustes')};
var sec=function(t,btn,body){return body?'<section class="sec"><h2><span>'+t+'</span>'+(btn||'')+'</h2>'+body+'</section>':''};
V.home=function(){var S=G(),t=td(),hr=new Date().getHours(),g=hr<5?'Boa madrugada':hr<12?'Bom dia':hr<18?'Boa tarde':'Boa noite';
 var od=S.tasks.filter(function(x){return x.s==='open'&&x.due&&x.due<t}),tt=S.tasks.filter(function(x){return x.s==='open'&&x.due===t}),evT=S.events.filter(function(e){return e.date===t}),evs=S.events.filter(function(e){return e.date>=t}).sort(evSort).slice(0,3),inb=live().filter(function(n){return n.nb===1}).length;
 var P={sum:'<p class="lead">Hoje: '+pl(tt.length,'tarefa','tarefas')+', '+pl(od.length,'atrasada','atrasadas')+' e '+pl(evT.length,'compromisso','compromissos')+'.'+(inb?' '+pl(inb,'nota aguarda','notas aguardam')+' organização na caixa de entrada.':'')+(S.diary[t]?'':' O diário de hoje está em branco.')+'</p>',
  tk:sec('Tarefas pendentes','<button data-a="tab" data-t="tk">Ver todas</button>',od.concat(tt).slice(0,4).map(trow).join('')),
  ev:sec('Próximos compromissos','<button data-a="tab" data-t="ag">Agenda</button>',evs.map(erow).join('')),
  nt:sec('Notas recentes','<button data-a="tab" data-t="notes">Ver todas</button>',live().sort(byU).slice(0,4).map(nrow).join('')),
  nb:sec('Cadernos','',S.nb.filter(function(b){return !b.arch}).map(function(b){return'<button class="chip" data-a="nbopen" data-id="'+b.id+'" style="border-color:'+b.color+'">'+esc(b.name)+'</button>'}).join(' '))};
 return head(g,0,top())+'<p class="mu" style="margin:-8px 0 14px;text-transform:capitalize">'+new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long'})+'</p>'
 +'<div class="cap"><textarea id="qc" placeholder="Escreva o que vier à cabeça…"></textarea><div class="acts"><button class="b p" data-a="cap" data-k="n">Guardar nota</button><button class="b" data-a="cap" data-k="t">Tarefa</button><button class="b" data-a="cap" data-k="d">Diário</button></div></div>'
 +['sum','tk','ev','nt','nb'].filter(function(k){return S.cfg.hide.indexOf(k)<0}).map(function(k){return P[k]}).join('')};
V.nb=function(){var S=G();return head('Cadernos',0,'<button class="b p" data-a="nbn">Novo</button>'+top())+(S.nb.map(function(b,i){var n=S.notes.filter(function(x){return x.nb===b.id&&!x.del&&!x.arch}).length;return'<div class="row tk"><i class="dot" style="background:'+b.color+'"></i><button class="tt" data-a="nbopen" data-id="'+b.id+'"><span>'+esc(b.name)+(b.arch?' (arquivado)':'')+'</span><small>'+pl(n,'página','páginas')+(b.desc?', '+esc(b.desc):'')+'</small></button>'+(i>1?'<button class="ib" data-a="nbup" data-id="'+b.id+'" aria-label="Subir">'+ic('<path d="M6 15l6-6 6 6"/>')+'</button>':'')+'<button class="b" data-a="nbe" data-id="'+b.id+'">Editar</button></div>'}).join(''))};
V.notes=function(){var S=G(),f=ui.nf,L;var F={all:function(n){return !n.del&&!n.arch},pin:function(n){return !n.del&&!n.arch&&n.pin},fav:function(n){return !n.del&&n.fav},arq:function(n){return !n.del&&n.arch},lix:function(n){return n.del}};
 var nbb=ui.nb?nbOf(ui.nb):null;if(nbb&&!nbb.sec.some(function(q){return q.id===ui.sc}))ui.sc=0;
 L=S.notes.filter(F[f]).filter(function(n){return !ui.nb||(n.nb===ui.nb&&(!ui.sc||n.sec===ui.sc))}).sort(byU);
 var cover=nbb?'<div class="cover cv-'+nbb.cv+'" style="--c:'+nbb.color+'"><strong>'+esc(nbb.name)+'</strong>'+(nbb.desc?'<span>'+esc(nbb.desc)+'</span>':'')+'</div><div class="chips"><button class="chip'+(!ui.sc?' on':'')+'" data-a="secf" data-id="0">Tudo</button>'+nbb.sec.map(function(q){return'<button class="chip'+(ui.sc===q.id?' on':'')+'" data-a="secf" data-id="'+q.id+'">'+esc(q.name)+'</button>'}).join('')+'<button class="chip" data-a="secm">Gerenciar seções</button></div>':'';var nm=[['all','Todas'],['pin','Fixadas'],['fav','Favoritas'],['arq','Arquivadas'],['lix','Lixeira']];
 return head(ui.nb?nbOf(ui.nb).name:'Notas',ui.nb,'<button class="b p" data-a="nn">Nova nota</button>'+(ui.nb?'':top()))+cover+'<div class="chips">'+nm.map(function(x){return'<button class="chip'+(f===x[0]?' on':'')+'" data-a="nf" data-k="'+x[0]+'">'+x[1]+'</button>'}).join('')+'<button class="chip" data-a="ntp">Modelo de página</button></div>'
 +(L.length?L.map(function(n){return f==='lix'?'<div class="row tk"><span class="tt">'+esc(ttl(n))+'</span><button class="b" data-a="nrs" data-id="'+n.id+'">Restaurar</button><button class="b d" data-a="nrm" data-id="'+n.id+'">Excluir</button></div>':nrow(n)}).join(''):'<p class="mu">'+(f==='lix'?'A lixeira está vazia.':'Nenhuma nota aqui. Toque em Nova nota para começar a escrever.')+'</p>')};
V.edit=function(){var S=G(),n=S.notes.filter(function(x){return x.id===ed.id})[0];if(!n)return V.home();
 var h=head('',1,'<span id="sv" class="sv">'+esc(ed.sv||'Salvo')+'</span><button class="b" data-a="rd">'+(ed.read?'Editar':'Ler')+'</button>'+ib('nm','more','Mais ações'));
 var sg=suggestNb(n),rl=related(n),lk=S.tasks.filter(function(t){return t.note===n.id}).length+S.events.filter(function(e){return e.note===n.id}).length;
 return h+'<input id="et" data-c="sv" class="ti" placeholder="Título" value="'+esc(n.t)+'" maxlength="200"><div class="meta"><select data-c="enb">'+nbOpts().map(function(o){return'<option value="'+o[0]+'"'+(o[0]===n.nb?' selected':'')+'>'+esc(o[1])+'</option>'}).join('')+'</select><input id="etg" data-c="sv" placeholder="etiquetas, separadas por vírgula" value="'+esc(n.tags.join(', '))+'"></div>'+(nbOf(n.nb).sec.length?'<div class="meta"><select data-c="esec"><option value="0">Sem seção</option>'+nbOf(n.nb).sec.map(function(q){return'<option value="'+q.id+'"'+(q.id===n.sec?' selected':'')+'>'+esc(q.name)+'</option>'}).join('')+'</select></div>':'')
 +(ed.read?'<div class="rd">'+md(n.b)+'</div>':'<textarea id="eb" data-c="sv" placeholder="Comece a escrever…" spellcheck="true">'+esc(n.b)+'</textarea>')
 +(sg?'<p class="hint">Parece combinar com o caderno '+esc(nbOf(sg).name)+'.<br><button data-a="mvnb" data-id="'+sg+'">Mover para lá</button></p>':'')
 +(lk?'<p class="hint">'+pl(lk,'item ligado','itens ligados')+' a esta nota (tarefas ou compromissos).</p>':'')
 +(rl.length?sec('Notas relacionadas','',rl.map(nrow).join('')):'')
 +(ed.read?'':'<div class="tb">'+[['h','Título'],['ul','Lista'],['ck','Checklist'],['b','Negrito'],['i','Itálico'],['hl','Destaque'],['hr','Separador']].map(function(x){return'<button data-a="fmt" data-k="'+x[0]+'">'+x[1]+'</button>'}).join('')+'</div>')};
V.tk=function(){var S=G(),t=td(),f=ui.tf,F={hoje:function(x){return x.s==='open'&&x.due===t},prox:function(x){return x.s==='open'&&(!x.due||x.due>t)},atr:function(x){return x.s==='open'&&x.due&&x.due<t},conc:function(x){return x.s==='done'}};
 var srt=function(a,b){return f==='conc'?b.done-a.done:((a.due||'9').localeCompare(b.due||'9'))||('HML'.indexOf(a.pr)-'HML'.indexOf(b.pr))};
 var nm=[['hoje','Hoje'],['prox','Próximas'],['atr','Atrasadas'],['conc','Concluídas']];
 return head('Tarefas',0,top())+'<div class="chips">'+nm.map(function(x){var n=S.tasks.filter(F[x[0]]).length;return'<button class="chip'+(f===x[0]?' on':'')+'" data-a="tf" data-k="'+x[0]+'">'+x[1]+(n?' '+n:'')+'</button>'}).join('')+'</div>'
 +'<div class="qa"><input id="tq" placeholder="Nova tarefa (aceita hoje ou amanhã no texto)" maxlength="200"><button class="b p" data-a="tqa">Adicionar</button></div>'
 +(S.tasks.filter(F[f]).sort(srt).map(trow).join('')||'<p class="mu">Nada por aqui.</p>')};
function grid(){var S=G(),c=ui.cal,y=+c.slice(0,4),m=+c.slice(5,7)-1,ws=S.cfg.ws,off=(new Date(y,m,1).getDay()-ws+7)%7,dn=new Date(y,m+1,0).getDate(),mk={},h='',i,N='DSTQQSS';
 S.events.forEach(function(e){mk[e.date]=1});S.tasks.forEach(function(t){if(t.s==='open'&&t.due)mk[t.due]=1});Object.keys(S.diary).forEach(function(d){mk[d]=1});
 for(i=0;i<7;i++)h+='<b>'+N[(i+ws)%7]+'</b>';for(i=0;i<off;i++)h+='<i></i>';
 for(i=1;i<=dn;i++){var d=y+'-'+p2(m+1)+'-'+p2(i);h+='<button data-a="cday" data-d="'+d+'" class="'+(d===c?'on ':'')+(d===td()?'t ':'')+(mk[d]?'m':'')+'">'+i+'</button>'}return'<div class="cal">'+h+'</div>'}
function dayBlock(d,nodi){var S=G(),ev=S.events.filter(function(e){return e.date===d}).sort(evSort),tk=S.tasks.filter(function(t){return t.due===d&&t.s==='open'}),nn=S.notes.filter(function(n){return !n.del&&n.c&&iso(new Date(n.c))===d});
 var b=ev.map(function(e){return'<button class="row" data-a="eve" data-id="'+e.id+'"><span class="rt">'+(e.time?e.time+'  ':'')+esc(e.t)+'</span></button>'}).join('')+tk.map(trow).join('')+(nn.length?'<h2>Notas do dia</h2>'+nn.map(nrow).join(''):'')+(!nodi&&S.diary[d]?'<button class="row" data-a="dopen" data-d="'+d+'"><span class="rt">Diário deste dia</span><span class="rs">'+esc(S.diary[d].replace(/\s+/g,' ').slice(0,80))+'</span></button>':'');
 return'<div class="db"><h3>'+dname(d)+'</h3><button class="b" data-a="evn" data-d="'+d+'">Compromisso</button></div>'+(b||'<p class="mu">Nada neste dia.</p>')}
V.ag=function(){var c=ui.cal,m=ui.mode,lbl=m==='m'?new Date(c+'T12:00:00').toLocaleDateString('pt-BR',{month:'long',year:'numeric'}):m==='w'?'Semana de '+dname(add(c,-((new Date(c+'T12:00:00').getDay()-G().cfg.ws+7)%7))):dname(c);
 var body=m==='m'?grid()+dayBlock(c):m==='d'?dayBlock(c):[0,1,2,3,4,5,6].map(function(i){return dayBlock(add(add(c,-((new Date(c+'T12:00:00').getDay()-G().cfg.ws+7)%7)),i))}).join('');
 return head('Agenda',0,top())+'<div class="chips">'+[['m','Mês'],['w','Semana'],['d','Dia']].map(function(x){return'<button class="chip'+(m===x[0]?' on':'')+'" data-a="amode" data-k="'+x[0]+'">'+x[1]+'</button>'}).join('')+'<button class="chip" data-a="cday" data-d="'+td()+'">Hoje</button></div>'
 +'<div class="cn"><button class="ib" data-a="cnav" data-n="-1" aria-label="Anterior">'+ic(IC.back)+'</button><span>'+esc(lbl)+'</span><button class="ib" data-a="cnav" data-n="1" aria-label="Próximo" style="transform:scaleX(-1)">'+ic(IC.back)+'</button></div>'+body};
V.di=function(){var S=G(),d=ui.ds,ks=Object.keys(S.diary).sort().reverse().slice(0,60);
 return head('Diário',1,'<span id="sv" class="sv">Salvo</span>')+'<div class="cn"><button class="ib" data-a="dnav" data-n="-1" aria-label="Dia anterior">'+ic(IC.back)+'</button><span>'+dname(d)+'</span><button class="ib" data-a="dnav" data-n="1" aria-label="Próximo dia" style="transform:scaleX(-1)">'+ic(IC.back)+'</button></div>'
 +'<textarea id="dd" data-c="ddi" style="min-height:38vh;margin-top:6px" placeholder="O que aconteceu hoje? O que você pensou, aprendeu ou conquistou?">'+esc(S.diary[d]||'')+'</textarea>'
 +'<div class="chips">'+['Aconteceu:','Pensei:','Aprendi:','Reflexão:','Meta alcançada:'].map(function(x){return'<button class="chip" data-a="dins" data-k="'+x+'">'+x+'</button>'}).join('')+'<button class="chip" data-a="dhoje">Hoje</button></div>'
 +dayBlock(d,1)+sec('Linha do tempo','',ks.map(function(k){return'<button class="row" data-a="dopen" data-d="'+k+'"><span class="rt">'+dname(k)+'</span><span class="rs">'+esc(S.diary[k].replace(/\s+/g,' ').slice(0,90))+'</span></button>'}).join(''))};
function results(){var S=G(),raw=ui.q.trim(),q=nz(raw),tg=q[0]==='#'?q.slice(1):null,t=ui.qt,out='';
 if(!q&&!ui.qn&&!ui.qd)return S.recent.length?sec('Buscas recentes','',S.recent.map(function(r){return'<button class="chip" data-a="rq" data-k="'+esc(r)+'">'+esc(r)+'</button>'}).join(' ')):'<p class="mu">Busque em notas, tarefas, diário e cadernos. Use #etiqueta para filtrar por etiqueta.</p>';
 var hit=function(x){return tg!=null?false:nz(x).indexOf(q)>=0};
 var ns=t==='all'||t==='n'?S.notes.filter(function(n){return !n.del&&(!ui.qn||n.nb===+ui.qn)&&(!ui.qd||(n.u&&iso(new Date(n.u))>=ui.qd))&&(!q||(tg!=null?n.tags.some(function(x){return nz(x)===tg}):hit(n.t)||hit(n.b)||n.tags.some(hit)))}).sort(byU).slice(0,30):[];
 var ts=(t==='all'||t==='t')&&!ui.qn&&!ui.qd?S.tasks.filter(function(x){return q&&tg==null&&(hit(x.t)||hit(x.d)||hit(x.cat))}).slice(0,30):[];
 var ds=(t==='all'||t==='d')&&!ui.qn?Object.keys(S.diary).sort().reverse().filter(function(d){return (!ui.qd||d>=ui.qd)&&q&&tg==null&&hit(S.diary[d])}).slice(0,30):[];
 var bs=(t==='all'||t==='b')&&!ui.qn&&!ui.qd?S.nb.filter(function(b){return q&&tg==null&&(hit(b.name)||hit(b.desc))}):[];
 out+=sec('Notas '+ns.length,'',ns.map(nrow).join(''))+sec('Tarefas '+ts.length,'',ts.map(trow).join(''))+sec('Diário '+ds.length,'',ds.map(function(d){return'<button class="row" data-a="dopen" data-d="'+d+'"><span class="rt">'+dname(d)+'</span><span class="rs">'+esc(S.diary[d].replace(/\s+/g,' ').slice(0,90))+'</span></button>'}).join(''))+sec('Cadernos '+bs.length,'',bs.map(function(b){return'<button class="row" data-a="nbopen" data-id="'+b.id+'"><span class="rt">'+esc(b.name)+'</span></button>'}).join(''));
 return out||'<p class="mu">Nada encontrado.</p>'}
V.se=function(){return head('Buscar',1)+'<input id="qs" data-c="qs" type="search" placeholder="Buscar em tudo…" value="'+esc(ui.q)+'"><div class="chips">'+[['all','Tudo'],['n','Notas'],['t','Tarefas'],['d','Diário'],['b','Cadernos']].map(function(x){return'<button class="chip'+(ui.qt===x[0]?' on':'')+'" data-a="qt" data-k="'+x[0]+'">'+x[1]+'</button>'}).join('')+'</div><div class="meta"><select data-c="qf" id="qn"><option value="">Qualquer caderno</option>'+nbOpts().map(function(o){return'<option value="'+o[0]+'"'+(String(o[0])===ui.qn?' selected':'')+'>'+esc(o[1])+'</option>'}).join('')+'</select><input type="date" id="qd" data-c="qf" value="'+esc(ui.qd)+'" aria-label="A partir de"></div><div id="sr">'+results()+'</div>'};
V.cfg=function(){var S=G(),c=S.cfg,hd={sum:'Resumo do dia',tk:'Tarefas pendentes',ev:'Próximos compromissos',nt:'Notas recentes',nb:'Atalhos de cadernos'},done=S.tasks.filter(function(t){return t.s==='done'}).length;
 var set=function(l,ctl){return'<div class="set"><span>'+l+'</span>'+ctl+'</div>'},so=function(k,o){return'<select data-c="cfg" data-k="'+k+'">'+o.map(function(x){return'<option value="'+x[0]+'"'+(String(c[k])===String(x[0])?' selected':'')+'>'+x[1]+'</option>'}).join('')+'</select>'};
 return head('Ajustes',1)+'<h2>Aparência</h2>'+set('Tema',so('theme',[['black','Preto profundo'],['graphite','Grafite']]))+set('Cor de destaque','<input type="color" data-c="cfg" data-k="accent" value="'+c.accent+'">')+set('Formato de data',so('df',[['br','dd/mm/aaaa'],['iso','aaaa-mm-dd']]))+set('Semana começa em',so('ws',[[0,'Domingo'],[1,'Segunda']]))+set('Planejar o dia seguinte a partir de',so('plan',Array.from({length:24},function(_,i){return[i,p2(i)+'h']})))
 +'<h2>Tela inicial</h2>'+Object.keys(hd).map(function(k){return set(hd[k],'<input type="checkbox" data-c="hid" data-k="'+k+'"'+(c.hide.indexOf(k)<0?' checked':'')+'>')}).join('')
 +'<h2>Estatísticas</h2>'+statsHtml()+(OP.aiHtml?OP.aiHtml():'')+'<h2>Dados</h2><p class="mu">'+pl(S.notes.filter(function(n){return !n.del}).length,'nota','notas')+', '+pl(S.tasks.length,'tarefa','tarefas')+' ('+done+' concluídas), '+pl(Object.keys(S.diary).length,'dia no diário','dias no diário')+'.</p>'
 +'<div class="mf" style="justify-content:flex-start"><button class="b p" data-a="bxp">Exportar backup</button><button class="b" data-a="bim">Importar backup</button>'+(OP.hasUndo()?'<button class="b" data-a="bun">Desfazer última restauração</button>':'')+'</div>'
 +(OP.hasOld()?'<p class="hint">Os dados do Operation: Discipline continuam guardados no aparelho, sem alteração. As missões foram convertidas em tarefas.</p>':'')+'<p class="mu" style="margin-top:18px">Operation, Smart Notebook. Tudo é salvo neste aparelho, sem internet.</p>'};
function statsHtml(){var S=G(),t=td(),w7=Date.now()-7*864e5,ns=S.notes.filter(function(n){return !n.del}),words=ns.reduce(function(a,n){return a+(n.b.trim()?n.b.trim().split(/\s+/).length:0)},0),
 done=S.tasks.filter(function(x){return x.s==='done'}),st=0,d=S.diary[t]?t:add(t,-1),cnt={};while(S.diary[d]){st++;d=add(d,-1)}ns.forEach(function(n){cnt[n.nb]=(cnt[n.nb]||0)+1});
 var top=Object.keys(cnt).sort(function(a,b){return cnt[b]-cnt[a]})[0];
 return[['Notas',ns.length],['Palavras escritas',words],['Notas criadas nos últimos 7 dias',ns.filter(function(n){return n.c>=w7}).length],['Tarefas concluídas nos últimos 7 dias',done.filter(function(x){return x.done>=w7}).length],['Taxa de conclusão',(S.tasks.length?Math.round(done.length/S.tasks.length*100):0)+'%'],['Tarefas atrasadas',S.tasks.filter(function(x){return x.s==='open'&&x.due&&x.due<t}).length],['Dias seguidos no diário',st],['Caderno mais usado',top?nbOf(+top).name:'Nenhum']].map(function(r){return'<div class="set"><span>'+r[0]+'</span><b style="flex:0 0 auto">'+esc(r[1])+'</b></div>'}).join('')}
/* ---------- desenho e navegação ---------- */
var NAV=[['ix'],['di'],['gl'],['rt'],['st'],['pf']];
function draw(){var y=window.scrollY,v;try{v=V[tab]()}catch(e){v='<p>Erro ao desenhar a tela: '+esc(e.message)+'</p>'}
 var m=$('#v');m.innerHTML='<div class="paper sheet'+(ui.dir>0||ui.turn>0?' fn':ui.dir<0||ui.turn<0?' fp':'')+'">'+v+'</div>';m.className=tab==='edit'&&!ed.read?'ed':'';banner();var n=$('#nav');n.hidden=tab==='edit';
 n.innerHTML=OP.tabsHtml?OP.tabsHtml(tab):'';if(OP.after)OP.after();window.scrollTo(0,y)}
function go(t){if(tab==='edit')leave();if(tab==='sk'&&OP.skinLeave)OP.skinLeave();if(tab==='se')rec();if(NAV.some(function(n){return n[0]===tab}))from=tab;var ot=tab;tab=t;ui.turn=OP.turnDir?OP.turnDir(ot,t):0;if(OP.snd&&ot!==t)OP.snd('page');if(t!=='notes')ui.nb=t==='notes'?ui.nb:0;if(t!=='di')arm();draw();window.scrollTo(0,0)}
window.addEventListener('popstate',function(){armed=false;if(mods.length){close(mods[mods.length-1])}else if(tab==='edit'){A.back()}else if(tab!=='di'){go('di')}if(mods.length||tab!=='di')arm()});
function rec(){var q=ui.q.trim();if(q.length<2||G().recent[0]===q)return;run(function(W){W.recent=[q].concat(W.recent.filter(function(x){return x!==q})).slice(0,8)},null,true)}
/* ---------- editor ---------- */
var tags=function(v){return v.split(/[,;]+/).map(function(x){return x.trim().replace(/^#/,'')}).filter(Boolean).filter(function(x,i,a){return a.indexOf(x)===i}).slice(0,20)};
function setSv(m){var e=$('#sv');if(e)e.textContent=m}
/* histórico: guarda o conteúdo anterior (máx. 5 versões; no mínimo 10 min entre versões automáticas) */
function snap(n,force){if(!n.b.trim())return;var h=n.h||(n.h=[]),l=h[h.length-1];if(force||!l||n.u-l.u>6e5){h.push({t:n.t,b:n.b,u:n.u||Date.now()});if(h.length>5)h.shift()}}
function save(){clearTimeout(tmr);tmr=null;var t=$('#et');if(!ed||!t)return true;var b=$('#eb'),g=$('#etg'),id=ed.id;
 var ok=run(function(W){var n=W.notes.filter(function(x){return x.id===id})[0];if(!n)return;n.t=t.value;if(b&&b.value!==n.b){snap(n);n.b=b.value}if(g)n.tags=tags(g.value);n.u=Date.now()},null,true);
 ed.sv=ok?'Salvo '+new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}):'Não salvo';setSv(ed.sv);return ok}
function leave(){if(!ed)return;if(save()){var id=ed.id,n=G().notes.filter(function(x){return x.id===id})[0];if(n&&!n.t.trim()&&!n.b.trim()&&!n.tags.length)run(function(W){W.notes=W.notes.filter(function(x){return x.id!==id})},null,true)}ed=null}
function openNote(id){if(tab==='se')rec();if(tab!=='edit')prev=tab;ed={id:id,read:false,sv:'Salvo'};tab='edit';arm();draw();window.scrollTo(0,0)}
function newNote(body,nb){var id=0;if(run(function(W){id=W.n++;W.notes.push({id:id,t:'',b:body||'',nb:nb||1,sec:(nb&&nb===ui.nb)?ui.sc:0,tags:[],pin:false,fav:false,arch:false,del:0,c:Date.now(),u:Date.now()})},null,true))return id;return 0}
function noteMut(fn,msg){var id=ed.id;if(!save())return;run(function(W){fn(W.notes.filter(function(x){return x.id===id})[0],W);},msg)}
function mkTask(W,title,note,due,desc,o){o=o||{};if(due&&due>OP.maxDay())throw new Error('A página de '+fmtD(due)+' ainda não está liberada para planejamento.');W.tasks.push({id:W.n++,t:title.slice(0,200),d:desc||'',due:due||'',pr:o.pr||'M',s:'open',nb:0,note:note||0,cat:o.cat||'',time:o.time||'',min:o.min||0,rt:o.rt||0,goal:o.goal||(OP.autoGoal?OP.autoGoal(title,W):0),per:o.per||'',pp:0,c:Date.now(),done:0})}
/* ---------- modelos de página ---------- */
function wkTpl(){var s=add(td(),-((new Date(td()+'T12:00:00').getDay()+6)%7)),h='# Semana de '+fmtD(s)+'\n\n## Foco da semana\n- [ ] \n- [ ] \n\n';for(var i=0;i<7;i++)h+='## '+dname(add(s,i))+'\n- [ ] \n\n';return h+'## Revisão\nO que funcionou? O que ajustar na próxima semana?\n'}
var TPL=[['Planejamento semanal',wkTpl],['Estudo',function(){return'# Estudo\n\n## Objetivo\n\n## Resumo\n\n## Dúvidas\n- [ ] \n\n## Revisar\n- [ ] \n'}],['Reunião',function(){return'# Reunião\n\n## Participantes\n\n## Pauta\n- \n\n## Decisões\n\n## Próximos passos\n- [ ] \n'}],['Painel de objetivos',function(){return'# Objetivos\n\n## Meta principal\n\n## Marcos\n- [ ] \n- [ ] \n- [ ] \n\n## Prazo e revisão\n'}],['Referência',function(){return'# Referência\n\n## Fonte\n\n## Pontos-chave\n- \n\n## Citações e trechos\n\n## Relação com outras notas\n'}]];
/* ---------- ações ---------- */
A.tab=function(el){go(el.dataset.t)};A['go-di']=function(){go('di')};A['go-se']=function(){go('se')};A['go-cfg']=function(){go('cfg')};
A.back=function(){if(tab==='edit'){var p=prev;leave();tab=p;ui.nb=p==='notes'?ui.nb:0;draw()}else go(from)};
A.open=function(el){openNote(+el.dataset.id)};
A.nn=function(){var id=newNote('',ui.nb||1);if(id)openNote(id)};
A.nf=function(el){ui.nf=el.dataset.k;draw()};
A.nrs=function(el){run(function(W){W.notes.forEach(function(n){if(n.id===+el.dataset.id)n.del=0})},'Nota restaurada')};
A.nrm=function(el){sure('Excluir esta nota definitivamente? Não será possível recuperá-la.',function(){run(function(W){W.notes=W.notes.filter(function(n){return n.id!==+el.dataset.id})},'Nota excluída')},'Excluir')};
A.ntp=function(){modal('Modelo de página',TPL.map(function(x,i){return'<button class="mn" data-a="tpl" data-i="'+i+'">'+x[0]+'</button>'}).join(''),[['Fechar']])};
A.tpl=function(el){var t=TPL[+el.dataset.i][1](),m=mods[mods.length-1];if(m)close(m);
 if(tab==='edit')noteMut(function(n){n.b=n.b+(n.b?'\n\n':'')+t;n.u=Date.now()},'Modelo inserido');else{var id=newNote(t,ui.nb||1);if(id)openNote(id)}};
A.hist=function(){var n=G().notes.filter(function(x){return x.id===ed.id})[0],h=(n.h||[]).slice().reverse();
 modal('Histórico de edição',h.length?'<p class="mu">Toque em uma versão para restaurá-la. A versão atual é guardada antes.</p>'+h.map(function(v){return'<button class="mn" data-a="hrs" data-u="'+v.u+'"><b>'+new Date(v.u).toLocaleString('pt-BR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})+'</b><br><small>'+esc(v.b.replace(/\s+/g,' ').slice(0,90))+'</small></button>'}).join(''):'<p class="mu">Ainda não há versões anteriores. Elas aparecem conforme você edita.</p>',[['Fechar']])};
A.hrs=function(el){var u=+el.dataset.u;close(mods[mods.length-1]);sure('Restaurar esta versão? O texto atual fica guardado no histórico.',function(){noteMut(function(n){var v=(n.h||[]).filter(function(x){return x.u===u})[0];if(!v)return;snap(n,true);n.b=v.b;n.t=v.t;n.u=Date.now()},'Versão restaurada')},'Restaurar')};
A.secf=function(el){ui.sc=+el.dataset.id;draw()};
A.secm=function(){var b=nbOf(ui.nb);modal('Seções: '+b.name,(b.sec.map(function(q){return'<div class="row tk"><span class="tt">'+esc(q.name)+'</span><button class="b d" data-a="secdel" data-id="'+q.id+'">Excluir</button></div>'}).join('')||'<p class="mu">Nenhuma seção ainda. Seções organizam as páginas dentro do caderno.</p>')+'<div class="qa"><input id="sn" maxlength="40" placeholder="Nova seção"><button class="b p" data-a="secadd">Adicionar</button></div>',[['Fechar']])};
A.secadd=function(){var v=$('#sn').value.trim(),id=ui.nb;if(!v){toast('Digite o nome da seção.');return}if(nbOf(id).sec.length>=20){toast('Limite de 20 seções por caderno.');return}
 if(run(function(W){W.nb.filter(function(b){return b.id===id})[0].sec.push({id:W.n++,name:v.slice(0,40)})},null,true)){close(mods[mods.length-1]);draw();A.secm()}};
A.secdel=function(el){var sid=+el.dataset.id,id=ui.nb;close(mods[mods.length-1]);sure('Excluir esta seção? As páginas continuam no caderno, sem seção.',function(){run(function(W){var b=W.nb.filter(function(x){return x.id===id})[0];b.sec=b.sec.filter(function(q){return q.id!==sid});W.notes.forEach(function(n){if(n.sec===sid)n.sec=0})},'Seção excluída');A.secm()},'Excluir')};
A.rd=function(){if(!save())return;ed.read=!ed.read;draw()};
A.tg=function(el){var i=+el.dataset.i;noteMut(function(n){var L=n.b.split('\n');L[i]=/^- \[x\]/.test(L[i])?L[i].replace('- [x]','- [ ]'):L[i].replace('- [ ]','- [x]');n.b=L.join('\n');n.u=Date.now()})};
A.l2t=function(el){var i=+el.dataset.i,id=ed.id,L=G().notes.filter(function(n){return n.id===id})[0].b.split('\n'),t=L[i].replace(/^- \[[ x]\] /,'').trim();if(!t)return;
 if(G().tasks.some(function(x){return x.note===id&&x.t===t.slice(0,200)})){toast('Esta linha já virou tarefa.');return}run(function(W){mkTask(W,t,id,parseDue(t))},'Tarefa criada a partir da checklist')};
A.fmt=function(el){var t=$('#eb');if(!t)return;var k=el.dataset.k,v=t.value,a=t.selectionStart,b=t.selectionEnd,pre={h:'# ',ul:'- ',ck:'- [ ] '},wr={b:'**',i:'*',hl:'=='};
 if(pre[k]){var ls=a?v.lastIndexOf('\n',a-1)+1:0;t.setRangeText(pre[k],ls,ls,'end')}else if(wr[k]){var w=wr[k];t.setRangeText(w+v.slice(a,b)+w,a,b,'end');if(a===b)t.selectionStart=t.selectionEnd=a+w.length}else t.setRangeText('\n---\n',a,b,'end');
 t.focus();t.dispatchEvent(new Event('input',{bubbles:true}))};
A.mvnb=function(el){noteMut(function(n){n.nb=+el.dataset.id},'Nota movida')};
A.nm=function(){if(!save())return;var n=G().notes.filter(function(x){return x.id===ed.id})[0],it=[['pin',n.pin?'Desafixar':'Fixar nota'],['fav',n.fav?'Remover dos favoritos':'Favoritar'],['task','Criar tarefa a partir da nota'],['ev','Transformar em compromisso'],['tpl','Inserir modelo de página'],['hist','Histórico de edição'],['dia','Enviar ao diário de hoje'],['arq',n.arch?'Desarquivar':'Arquivar'],['del','Mover para a lixeira']];
 modal('Nota',it.map(function(x){return'<button class="mn" data-a="nact" data-k="'+x[0]+'">'+x[1]+'</button>'}).join(''),[['Fechar']])};
A.nact=function(el){var k=el.dataset.k,id=ed.id,n=G().notes.filter(function(x){return x.id===id})[0];close(mods[mods.length-1]);
 if(k==='pin')noteMut(function(x){x.pin=!x.pin},n.pin?'Nota desafixada':'Nota fixada');
 else if(k==='fav')noteMut(function(x){x.fav=!x.fav},n.fav?'Removida dos favoritos':'Favoritada');
 else if(k==='task')run(function(W){mkTask(W,ttl(n),id,'',n.b.slice(0,2000))},'Tarefa criada e ligada a esta nota');
 else if(k==='ev')ask('Novo compromisso',inp('t','Título','text',ttl(n))+inp('date','Data','date',td())+inp('time','Horário (opcional)','time',''),'Agendar',function(v){if(!v.t.trim())throw new Error('Informe um título');if(!U.vd(v.date))throw new Error('Data inválida');return run(function(W){W.events.push({id:W.n++,t:v.t.trim(),date:v.date,time:v.time,note:id,c:Date.now()})},'Compromisso criado')});
 else if(k==='tpl')A.ntp();
 else if(k==='hist')A.hist();
 else if(k==='dia')run(function(W){var d=td();W.diary[d]=(W.diary[d]?W.diary[d]+'\n\n':'')+ttl(n)+(n.b?'\n'+n.b:'')},'Adicionado ao diário de hoje');
 else if(k==='arq')noteMut(function(x){x.arch=!x.arch},n.arch?'Nota desarquivada':'Nota arquivada');
 else if(k==='del')sure('Mover esta nota para a lixeira? Você poderá restaurá-la.',function(){var i=ed.id;if(!save())return;if(run(function(W){W.notes.forEach(function(x){if(x.id===i)x.del=Date.now()})},'Nota na lixeira')){var p=prev;ed=null;tab=p;draw()}},'Mover')};
A.cap=function(el){var t=$('#qc'),v=t.value.trim();if(!v){toast('Escreva algo antes de guardar.');return}var k=el.dataset.k,L=v.split('\n'),ok;
 if(k==='n')ok=run(function(W){W.notes.push({id:W.n++,t:'',b:v,nb:1,tags:[],pin:false,fav:false,arch:false,del:0,c:Date.now(),u:Date.now()})},'Guardado na caixa de entrada');
 else if(k==='t')ok=run(function(W){mkTask(W,L[0],0,parseDue(L[0]),L.slice(1).join('\n'))},'Tarefa criada');
 else ok=run(function(W){var d=td();W.diary[d]=(W.diary[d]?W.diary[d]+'\n\n':'')+v},'Adicionado ao diário de hoje');
 if(ok){var n=$('#qc');if(n)n.value=''}};
A.nbopen=function(el){ui.nb=+el.dataset.id;ui.nf='all';if(tab==='se')rec();tab='notes';arm();draw();window.scrollTo(0,0)};
A.nbup=function(el){var id=+el.dataset.id;run(function(W){var i=W.nb.findIndex(function(b){return b.id===id});if(i>1){var x=W.nb[i];W.nb[i]=W.nb[i-1];W.nb[i-1]=x}})};
function nbForm(b){return inp('name','Nome','text',b?b.name:'','maxlength="40"')+inp('desc','Descrição','text',b?b.desc:'','maxlength="200"')+inp('color','Cor de identificação','color',b?b.color:'#7c9cff')+sel('cv','Capa',[['solid','Lisa'],['lines','Linhas'],['dots','Pontos'],['grid','Grade']],b?b.cv:'solid')+(b&&b.id!==1?fl('Arquivado','<input type="checkbox" name="arch"'+(b.arch?' checked':'')+'>'):'')}
A.nbn=function(){ask('Novo caderno',nbForm(),'Criar',function(v){if(!v.name.trim())throw new Error('Informe um nome');return run(function(W){W.nb.push({id:W.n++,name:v.name.trim(),desc:v.desc,color:v.color,arch:false,cv:v.cv,sec:[]})},'Caderno criado')})};
A.nbe=function(el){var id=+el.dataset.id,b=nbOf(id);ask('Editar caderno',nbForm(b),'Salvar',function(v){if(!v.name.trim())throw new Error('Informe um nome');return run(function(W){var x=W.nb.filter(function(y){return y.id===id})[0];x.name=v.name.trim();x.desc=v.desc;x.color=v.color;x.cv=v.cv;if(id!==1)x.arch=!!v.arch},'Caderno salvo')},id===1?[]:[['Excluir',function(){sure('Excluir o caderno "'+esc(b.name)+'"? As notas dele vão para a Caixa de entrada.',function(){run(function(W){W.nb=W.nb.filter(function(y){return y.id!==id});W.notes.forEach(function(n){if(n.nb===id)n.nb=1});W.tasks.forEach(function(t){if(t.nb===id)t.nb=0})},'Caderno excluído')},'Excluir')},'d']])};
A.tf=function(el){ui.tf=el.dataset.k;draw()};
A.tqa=function(){var i=$('#tq'),v=i.value.trim();if(!v){toast('Digite o título da tarefa.');return}if(run(function(W){mkTask(W,v,0,parseDue(v)||(ui.tf==='hoje'?td():''))},'Tarefa adicionada')){var n=$('#tq');if(n)n.focus()}};
A.tkt=function(el){var id=+el.dataset.id;run(function(W){W.tasks.forEach(function(t){if(t.id===id){t.s=t.s==='done'?'open':'done';t.done=t.s==='done'?Date.now():0}})})};
A.tke=function(el){var id=+el.dataset.id,t=G().tasks.filter(function(x){return x.id===id})[0];
 ask('Tarefa',inp('t','Título','text',t.t,'maxlength="200"')+txa('d','Descrição',t.d)+inp('due','Prazo','date',t.due)+sel('pr','Prioridade',[['L','Baixa'],['M','Média'],['H','Alta']],t.pr)+sel('nb','Caderno',nbOpts(1),t.nb)+inp('cat','Categoria','text',t.cat,'maxlength="30"')+inp('min','Minutos estimados','number',t.min||'','min="0" max="1440"')+sel('goal','Meta',OP.goalOpts?OP.goalOpts():[[0,'Nenhuma']],t.goal),'Salvar',function(v){if(!v.t.trim())throw new Error('Informe um título');if(v.due&&!U.vd(v.due))throw new Error('Prazo inválido');if(v.due&&v.due!==t.due&&v.due>OP.maxDay())throw new Error('A página de '+fmtD(v.due)+' ainda não está liberada para planejamento.');
  return run(function(W){var x=W.tasks.filter(function(y){return y.id===id})[0];x.t=v.t.trim();x.d=v.d;if(v.due>x.due&&x.due)x.pp=(x.pp||0)+1;x.due=v.due;x.min=parseInt(v.min,10)||0;x.goal=+v.goal||0;x.pr=v.pr;x.nb=+v.nb;x.cat=v.cat.trim()},'Tarefa salva')},
  (t.note?[['Abrir nota',function(){setTimeout(function(){openNote(t.note)},0)}]]:[]).concat([['Excluir',function(){sure('Excluir esta tarefa?',function(){run(function(W){W.tasks=W.tasks.filter(function(y){return y.id!==id})},'Tarefa excluída')},'Excluir')},'d']]))};
A.amode=function(el){ui.mode=el.dataset.k;draw()};
A.cday=function(el){ui.cal=el.dataset.d;draw()};
A.cnav=function(el){var n=+el.dataset.n,c=ui.cal;ui.cal=ui.mode==='m'?iso(new Date(+c.slice(0,4),+c.slice(5,7)-1+n,1)):add(c,n*(ui.mode==='w'?7:1));draw()};
function evForm(e,d){return inp('t','Título','text',e?e.t:'','maxlength="200"')+inp('date','Data','date',e?e.date:d)+inp('time','Horário (opcional)','time',e?e.time:'')}
A.evn=function(el){ask('Novo compromisso',evForm(null,el.dataset.d),'Criar',function(v){if(!v.t.trim())throw new Error('Informe um título');if(!U.vd(v.date))throw new Error('Data inválida');return run(function(W){W.events.push({id:W.n++,t:v.t.trim(),date:v.date,time:v.time,note:0,c:Date.now()})},'Compromisso criado')})};
A.eve=function(el){var id=+el.dataset.id,e=G().events.filter(function(x){return x.id===id})[0];
 ask('Compromisso',evForm(e),'Salvar',function(v){if(!v.t.trim())throw new Error('Informe um título');if(!U.vd(v.date))throw new Error('Data inválida');return run(function(W){var x=W.events.filter(function(y){return y.id===id})[0];x.t=v.t.trim();x.date=v.date;x.time=v.time},'Compromisso salvo')},
  (e.note?[['Abrir nota',function(){setTimeout(function(){openNote(e.note)},0)}]]:[]).concat([['Excluir',function(){sure('Excluir este compromisso?',function(){run(function(W){W.events=W.events.filter(function(y){return y.id!==id})},'Compromisso excluído')},'Excluir')},'d']]))};
A.dnav=function(el){flushD();ui.ds=add(ui.ds,+el.dataset.n);draw()};
A.dhoje=function(){flushD();ui.ds=td();draw()};
A.dopen=function(el){if(tab==='di')flushD();if(tab==='se')rec();ui.ds=el.dataset.d;tab='di';arm();draw();window.scrollTo(0,0)};
A.dins=function(el){var t=$('#dd');if(!t)return;var v=t.value;t.setRangeText((v&&!/\n$/.test(v)?'\n':'')+el.dataset.k+' ',v.length,v.length,'end');t.focus();t.dispatchEvent(new Event('input',{bubbles:true}))};
function flushD(){if(!tmr||tab!=='di')return;clearTimeout(tmr);tmr=null;saveD()}
function saveD(){var t=$('#dd');if(!t)return;var d=ui.ds;if(OP.access(d)==='locked'){toast('Esta página ainda não está liberada.');return}var v=t.value,ok=run(function(W){if(v.trim())W.diary[d]=v;else delete W.diary[d]},null,true);setSv(ok?'Salvo':'Não salvo')}
A.qt=function(el){ui.qt=el.dataset.k;draw()};
A.rq=function(el){ui.q=el.dataset.k;draw()};
A.bxp=function(){var j=OP.exportJson();modal('Exportar backup','<p class="mu">Inclui notas, cadernos, tarefas, agenda, diário e ajustes, com checksum para validar na importação. Se o download não funcionar no aplicativo, copie o texto e guarde em um arquivo.</p><textarea readonly style="min-height:120px;font-size:.75em" id="bj">'+esc(j)+'</textarea>',
 [['Baixar',function(){try{var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([j],{type:'application/json'}));a.download='operation-backup-'+td()+'.json';document.body.appendChild(a);a.click();a.remove();toast('Backup gerado.',1)}catch(e){toast('Download indisponível: use Copiar.')}return false}],
  ['Copiar',function(){var t=$('#bj');t.select();var done=function(){toast('Backup copiado.',1)};if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(j).then(done,function(){document.execCommand&&document.execCommand('copy');done()});else{try{document.execCommand('copy')}catch(e){}done()}return false}],['Fechar','','p']])};
A.bim=function(){ask('Importar backup','<p class="mu">Cole o conteúdo ou escolha o arquivo .json. Nada é alterado antes da sua confirmação. Aceita backups do Operation e do Operation: Discipline.</p><input type="file" accept=".json,application/json" data-c="imf">'+txa('txt','Conteúdo do backup',''),'Validar',function(v){var s;try{s=OP.parse(v.txt)}catch(e){toast(e.message);return false}
 sure('Backup válido: '+pl(s.notes.length,'nota','notas')+', '+pl(s.tasks.length,'tarefa','tarefas')+', '+pl(s.events.length,'compromisso','compromissos')+'. Substituir TODOS os dados atuais? Uma cópia dos dados atuais fica guardada e a restauração pode ser desfeita.',function(){try{OP.restore(s);OP.blocked=false;warn='';ed=null;tab='cfg';applyCfg();draw();toast('Backup restaurado.',1)}catch(e){toast(e.message)}},'Substituir');return true})};
A.bun=function(){sure('Desfazer a última restauração e voltar aos dados anteriores?',function(){try{OP.undo();applyCfg();draw();toast('Restauração desfeita.',1)}catch(e){toast(e.message)}},'Desfazer')};
/* ---------- entrada de dados ---------- */
C.sv={ev:'input',fn:function(){setSv('Salvando…');clearTimeout(tmr);tmr=setTimeout(save,500)}};
C.ddi={ev:'input',fn:function(){setSv('Salvando…');clearTimeout(tmr);tmr=setTimeout(function(){tmr=null;saveD()},500)}};
C.enb={ev:'change',fn:function(el){var v=+el.value;noteMut(function(n){n.nb=v;n.sec=0})}};
C.esec={ev:'change',fn:function(el){var v=+el.value;noteMut(function(n){n.sec=v})}};
C.qs={ev:'input',fn:function(el){ui.q=el.value;$('#sr').innerHTML=results()}};
C.qf={ev:'change',fn:function(el){if(el.id==='qn')ui.qn=el.value;else ui.qd=el.value;$('#sr').innerHTML=results()}};
C.imf={ev:'change',fn:function(el){var f=el.files[0];if(!f)return;if(f.size>4194304){toast('Arquivo grande demais (máx. 4 MB).');return}var r=new FileReader();r.onload=function(){var t=$('[name=txt]');if(t)t.value=String(r.result)};r.onerror=function(){toast('Não foi possível ler o arquivo.')};r.readAsText(f)}};
function applyCfg(){var c=G().cfg,r=document.documentElement;r.style.setProperty('--ac',c.accent);r.style.setProperty('--acd','#'+[1,3,5].map(function(i){return p2(Math.round(parseInt(c.accent.substr(i,2),16)*.62).toString(16))}).join(''));r.style.setProperty('--fs',c.fs+'px');r.dataset.theme=c.theme}
C.cfg={ev:'change',fn:function(el){var k=el.dataset.k,v=el.value;if(k==='fs'||k==='ws'||k==='plan')v=+v;if(run(function(W){W.cfg[k]=v},null,true)){applyCfg();if(k!=='accent'&&k!=='fs')draw()}}};
C.hid={ev:'change',fn:function(el){var k=el.dataset.k,on=el.checked;run(function(W){var h=W.cfg.hide.filter(function(x){return x!==k});if(!on)h.push(k);W.cfg.hide=h},null,true)}};
document.addEventListener('click',function(e){var el=e.target.closest('[data-a]');if(!el||el.disabled)return;var f=A[el.dataset.a];if(f)try{f(el,e)}catch(x){toast(x.message)}});
['change','input'].forEach(function(ev){document.addEventListener(ev,function(e){var el=e.target.closest('[data-c]');if(!el)return;var h=C[el.dataset.c];if(h&&h.ev===ev)try{h.fn(el,e)}catch(x){toast(x.message)}})});
document.addEventListener('keydown',function(e){var t=e.target;if(e.key!=='Enter')return;if(t.id==='tq'){e.preventDefault();A.tqa()}
 else if(t.id==='eb'){var v=t.value,a=t.selectionStart,ls=a?v.lastIndexOf('\n',a-1)+1:0,l=v.slice(ls,a),m=/^(- \[[ x]\] |- )/.exec(l);if(!m)return;e.preventDefault();if(l===m[1])t.setRangeText('',ls,a,'end');else t.setRangeText('\n'+(m[1].indexOf('[')>0?'- [ ] ':m[1]),a,a,'end');t.dispatchEvent(new Event('input',{bubbles:true}))}});
document.addEventListener('visibilitychange',function(){if(document.hidden){if(tab==='edit')save();else flushD()}});
window.addEventListener('pagehide',function(){if(tab==='edit')save();else flushD()});
window.addEventListener('error',function(e){toast('Erro inesperado: '+(e.message||e))});
window.addEventListener('unhandledrejection',function(e){toast('Erro inesperado: '+((e.reason&&e.reason.message)||e.reason))});
OP.X={V:V,A:A,C:C,ui:ui,run:run,modal:modal,ask:ask,sure:sure,toast:toast,draw:draw,go:go,close:close,mods:mods,esc:esc,fl:fl,inp:inp,txa:txa,sel:sel,head:head,sec:sec,ic:ic,IC:IC,ib:ib,top:top,trow:trow,nrow:nrow,td:td,fmtD:fmtD,dname:dname,pl:pl,nbOf:nbOf,applyCfg:applyCfg,tab:function(){return tab},arm:arm,$:$,p2:p2,mkTask:mkTask,flushD:flushD,start:function(){applyCfg();draw()}};
})();
