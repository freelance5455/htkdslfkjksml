/* OPERATION DISCIPLINE — o caderno: páginas diárias, regras de tempo, rotinas, metas, fechamento do dia. */
(function(){'use strict';var OP=window.OP,X=OP.X,A=X.A,C=X.C,V=X.V,ui=X.ui,esc=X.esc,iso=OP.U.iso,add=OP.U.add,$=X.$,I=OP.I;
var S=function(){return OP.get()},td=function(){return X.td()},p2=X.p2,toast=X.toast;
var DN7=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'],MOOD=['','Difícil','Fraco','Regular','Bom','Excelente'];
var blank=function(){return{obj:'',evn:'',sum:'',ok:'',learn:'',imp:'',obs:'',mood:0,closed:0,rd:0,rtd:[]}};
var dow=function(d){return new Date(d+'T12:00:00').getDay()};
/* ---------- controle temporal ---------- */
OP.maxDay=function(){var n=new Date(),t=iso(n);return n.getHours()>=S().cfg.plan?add(t,1):t};
function access(d){var t=td(),m=OP.maxDay();return d<t?'past':d===t?'today':d<=m?'plan':'locked'}
OP.access=access;
var hh=function(){return p2(S().cfg.plan)+'h'};
function goDay(d,dir){if(!OP.U.vd(d))return false;if(access(d)==='locked'){toast(d===add(td(),1)?'A página de amanhã será liberada às '+hh()+', conforme suas configurações.':'Esta página ainda não está disponível. Só o dia seguinte pode ser planejado, e apenas a partir das '+hh()+'.');return false}
 flushPage();X.flushD();ui.ds=d;ui.dir=dir||0;if(X.tab()!=='di')X.go('di');else{X.draw();window.scrollTo(0,0)}return true}
/* ---------- rotinas: escrevem só no dia que chegou ---------- */
function materialize(force){var t=td(),c=S().cfg;if(!force&&c.mat===t)return;var from=force?t:(c.mat&&c.mat<t?add(c.mat,1):t),lo=add(t,-7);if(from<lo)from=lo;var days=[];for(var d=from;d<=t;d=add(d,1))days.push(d);
 var has=days.some(function(d){var D=S().days[d];return S().routines.some(function(r){return r.on&&r.days.indexOf(dow(d))>=0&&!(D&&D.rtd.indexOf(r.id)>=0)})});
 if(!has&&c.mat===t)return;
 X.run(function(W){days.forEach(function(d){var w=dow(d),D=W.days[d]||(W.days[d]=blank());W.routines.forEach(function(r){if(!r.on||r.days.indexOf(w)<0||D.rtd.indexOf(r.id)>=0)return;D.rtd.push(r.id);
  var key=r.t.toLowerCase().trim();if(W.tasks.some(function(x){return x.due===d&&(x.rt===r.id||x.t.toLowerCase().trim()===key)}))return;
  W.tasks.push({id:W.n++,t:r.t,d:r.obs,due:d,pr:r.req?'H':'M',s:'open',nb:0,note:0,cat:r.cat,time:r.time,min:r.min,rt:r.id,goal:r.goal,pp:0,c:Date.now(),done:0})})});W.cfg.mat=t},null,true)}
OP.materialize=materialize;
/* ---------- salvamento dos campos da página ---------- */
var pend={},pt=null;
var sv=function(m){var e=$('#sv');if(e)e.textContent=m};
function grow(t){t.style.height='auto';t.style.height=Math.max(t.scrollHeight,56)+'px'}
function flushPage(){clearTimeout(pt);pt=null;var ks=Object.keys(pend);if(!ks.length)return true;var P=pend;pend={};
 var ok=X.run(function(W){ks.forEach(function(k){var a=k.split('|');if(access(a[0])==='locked')throw new Error('Página ainda não liberada');var D=W.days[a[0]]||(W.days[a[0]]=blank());if(D.closed)throw new Error('Página fechada: reabra para corrigir');D[a[1]]=P[k]})},null,true);
 if(!ok)ks.forEach(function(k){if(!(k in pend))pend[k]=P[k]});sv(ok?'Salvo':'Não salvo');return ok}
C.dpf={ev:'input',fn:function(el){grow(el);pend[ui.ds+'|'+el.dataset.f]=el.value;sv('Salvando…');clearTimeout(pt);pt=setTimeout(flushPage,500)}};
C.dpick={ev:'change',fn:function(el){if(el.value&&!goDay(el.value))el.value=ui.ds}};
OP.after=function(){document.querySelectorAll('textarea.ln').forEach(grow);ui.dir=0};
['visibilitychange','pagehide'].forEach(function(e){(e==='pagehide'?window:document).addEventListener(e,function(){if(e==='pagehide'||document.hidden)flushPage()})});
/* ---------- a página ---------- */
var psort=function(a,b){return((a.s==='done')-(b.s==='done'))||('HML'.indexOf(a.pr)-'HML'.indexOf(b.pr))||((a.time||'99').localeCompare(b.time||'99'))};
var blk=function(t,b){return'<h3>'+t+'</h3>'+b};
V.di=function(){var s=S(),t=td(),d=ui.ds;if(access(d)==='locked')d=ui.ds=t;
 var a=access(d),D=s.days[d]||blank(),ro=!!D.closed,nx=add(d,1),nxa=access(nx);
 var tk=s.tasks.filter(function(x){return x.due===d&&x.s!=='cancel'}).sort(psort),cr=a==='today'?s.tasks.filter(function(x){return x.s==='open'&&x.due&&x.due<t}).sort(function(x,y){return x.due.localeCompare(y.due)}):[];
 var ev=s.events.filter(function(e){return e.date===d}).sort(function(x,y){return(x.time||'99').localeCompare(y.time||'99')}),rp=a==='plan'?s.routines.filter(function(r){return r.on&&r.days.indexOf(dow(d))>=0}):[];
 var lab=d===t?'Hoje':d===add(t,-1)?'Ontem':d===nx&&d===add(t,1)?'Amanhã':'';
 var ta=function(f,ph,v,r){return'<textarea class="ln" data-c="dpf" data-f="'+f+'" rows="'+r+'" placeholder="'+ph+'"'+(ro?' readonly':'')+'>'+esc(v)+'</textarea>'};
 var dt=new Date(d+'T12:00:00'),nav='<div class="dnv"><button class="ib" data-a="dnav" data-n="-1" aria-label="Dia anterior">'+X.ic(X.IC.back)+'</button><div class="dl"><b>'+(lab||X.dname(d))+'</b></div><button class="ib'+(nxa==='locked'?' lk':'')+(ui.unl&&nxa==='plan'?' unl':'')+'" data-a="dnav" data-n="1" aria-label="'+(nxa==='locked'?'Próximo dia (bloqueado)':'Próximo dia')+'">'+(nxa==='locked'?X.ic('<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>'):'<span style="display:inline-block;transform:scaleX(-1)">'+X.ic(X.IC.back)+'</span>')+'</button></div><div class="chips">'+(d!==t?'<button class="chip" data-a="dhoje">Voltar a hoje</button>':'')+'<button class="chip" data-a="dpk">Escolher data</button><input type="date" class="dp" data-c="dpick" value="'+d+'" max="'+OP.maxDay()+'" aria-label="Ir para a data" tabindex="-1"></div>';
 var evh=ev.map(function(e){return'<button class="row" data-a="eve" data-id="'+e.id+'"><span class="rt">'+(e.time?e.time+'  ':'')+esc(e.t)+'</span></button>'}).join('')+rp.map(function(r){return'<div class="row"><span class="rt">'+(r.time?r.time+'  ':'')+esc(r.t)+'</span><small>rotina prevista: entra na página quando o dia chegar</small></div>'}).join('');
 var fin;if(a==='plan')fin='<p class="mu">Você está planejando esta página. Ela só pode ser fechada depois que o dia passar.</p>';
 else if(D.closed)fin='<div class="sumr">'+(D.mood?'<small>Como foi o dia</small><p>'+MOOD[D.mood]+'</p>':'')+[['sum','Resumo'],['ok','Realizado'],['learn','Aprendizados'],['imp','Melhorar'],['obs','Observações']].filter(function(x){return D[x[0]]}).map(function(x){return'<small>'+x[1]+'</small><p>'+esc(D[x[0]])+'</p>'}).join('')+'</div><button class="b" data-a="fre">Reabrir para corrigir</button>';
 else fin='<button class="b p" data-a="fch">Fechar o dia</button>';
 var rc=a==='today'?I.recs().slice(0,2):[];
 var paper='<div class="ph"><span class="pd">'+dt.toLocaleDateString('pt-BR',{weekday:'long'})+'</span><span class="pn">'+dt.toLocaleDateString('pt-BR',{day:'numeric',month:'long',year:'numeric'})+'</span>'+(D.closed?'<span class="stamp">Dia fechado</span>':a==='plan'?'<span class="stamp pl">Planejamento</span>':'')+'</div>'
 +(OP.writeBox?OP.writeBox(ro):'')+blk('Objetivos do dia',ta('obj','O que faria deste dia um dia bem vivido?',D.obj,2))
 +blk('Tarefas',(tk.map(function(x){return X.trow(x,true)}).join('')||'<p class="mu">Nenhuma tarefa neste dia.</p>')+(ro?'':'<div class="qa"><input id="tq" placeholder="Nova tarefa (! = prioridade alta)" maxlength="200"><button class="b p" data-a="tqa">Adicionar</button></div>'))
 +(cr.length?blk('Pendentes de dias anteriores',cr.map(function(x){return X.trow(x)+'<div class="mf" style="justify-content:flex-start;margin:-4px 0 6px 36px"><button class="b lk" data-a="pdec" data-id="'+x.id+'">Decidir o que fazer</button></div>'}).join('')):'')
 +blk('Compromissos',(evh||'<p class="mu">Nenhum compromisso.</p>')+(ro?'':'<button class="b lk" data-a="evn" data-d="'+d+'">Novo compromisso</button>'))
 +blk('Anotações livres','<textarea class="ln" id="dd" data-c="ddi" rows="3" placeholder="Escreva à vontade…"'+(ro?' readonly':'')+'>'+esc(s.diary[d]||'')+'</textarea>')
 +blk('Acontecimentos importantes',ta('evn','O que marcou o dia?',D.evn,2))+blk('Fechamento',fin);
 var recs=rc.length?X.sec('Recomendações','<button data-a="tab" data-t="st">Ver análises</button>',rc.map(I.recHtml).join('')):'';
 return X.head('Caderno',0,'<span id="sv" class="sv">Salvo</span>'+X.top())+nav+paper+recs};
A.dnav=function(el){var n=+el.dataset.n;goDay(add(ui.ds,n),n)};
A.dpk=function(){var i=$('.dp');if(!i)return;try{i.showPicker()}catch(e){i.focus();i.click()}};
A.dhoje=function(){goDay(td(),ui.ds<td()?1:-1)};
A.dopen=function(el){goDay(el.dataset.d,0)};
var oTqa=A.tqa;A.tqa=function(){if(X.tab()!=='di')return oTqa();var i=$('#tq'),v=i.value.trim(),h=v[0]==='!';if(h)v=v.slice(1).trim();if(!v){toast('Digite o título da tarefa.');return}var d=ui.ds;if(X.run(function(W){X.mkTask(W,v,0,d,'',{pr:h?'H':'M'})},'Tarefa adicionada')){var n=$('#tq');if(n)n.focus()}};
var oTkt=A.tkt;A.tkt=function(el){var t=S().tasks.filter(function(x){return x.id===+el.dataset.id})[0],D=t&&t.due&&S().days[t.due];if(D&&D.closed){toast('Esta página está fechada. Reabra-a para corrigir.');return}oTkt(el)};
A.fre=function(){var d=ui.ds;X.sure('Reabrir a página para corrigir? O fechamento será refeito depois.',function(){X.run(function(W){var D=W.days[d];D.closed=0;D.rd=(D.rd||0)+1},'Página reaberta')},'Reabrir')};
/* ---------- fechamento do dia ---------- */
var cs=null,STEPS=[['sum','Como foi seu dia?'],['ok','O que você conseguiu realizar?'],['learn','O que você aprendeu?'],['imp','O que poderia melhorar amanhã?'],['obs','Alguma observação importante?']];
A.fch=function(){var d=ui.ds,a=access(d);if(a==='plan'||a==='locked')return;flushPage();X.flushD();var D=S().days[d]||blank();
 cs={d:d,i:0,v:{mood:D.mood||0,sum:D.sum,ok:D.ok,learn:D.learn,imp:D.imp,obs:D.obs}};var tk=S().tasks.filter(function(x){return x.due===d&&x.s==='done'});if(!cs.v.ok&&tk.length)cs.v.ok=tk.map(function(x){return'- '+x.t}).join('\n');
 var o=document.createElement('div');o.className='cl';o.id='cl';document.body.appendChild(o);rcl()};
function rcl(){var o=$('#cl'),q=STEPS[cs.i],last=cs.i===STEPS.length-1,pend2=S().tasks.filter(function(x){return x.due===cs.d&&x.s==='open'});
 o.innerHTML='<div class="dots">'+STEPS.map(function(_,i){return'<i class="'+(i<=cs.i?'on':'')+'"></i>'}).join('')+'</div><h2>'+q[1]+'</h2>'
 +(q[0]==='sum'?'<div class="chips">'+[1,2,3,4,5].map(function(n){return'<button class="chip'+(cs.v.mood===n?' on':'')+'" data-a="clm" data-n="'+n+'">'+MOOD[n]+'</button>'}).join('')+'</div>':'')
 +(q[0]==='ok'&&pend2.length?'<p class="mu">Ficaram pendentes: '+pend2.map(function(x){return esc(x.t)}).join('; ')+'. Elas continuam como pendências no próximo dia.</p>':'')
 +'<textarea data-c="clv" data-f="'+q[0]+'" placeholder="Escreva as últimas linhas do dia…">'+esc(cs.v[q[0]])+'</textarea><div class="mf"><button class="b" data-a="'+(cs.i?'clb':'clx')+'">'+(cs.i?'Voltar':'Cancelar')+'</button><button class="b p" data-a="cln">'+(last?'Fechar o caderno':'Continuar')+'</button></div>';var t=o.querySelector('textarea');if(t)try{t.focus({preventScroll:true})}catch(e){}}
C.clv={ev:'input',fn:function(el){if(cs)cs.v[el.dataset.f]=el.value}};
A.clm=function(el){cs.v.mood=+el.dataset.n;rcl()};A.clb=function(){cs.i--;rcl()};A.clx=function(){var o=$('#cl');if(o)o.remove();cs=null};
A.cln=function(){if(cs.i<STEPS.length-1){cs.i++;rcl();return}var d=cs.d,v=cs.v;
 if(!X.run(function(W){var D=W.days[d]||(W.days[d]=blank());['sum','ok','learn','imp','obs'].forEach(function(f){D[f]=v[f]});D.mood=v.mood;D.closed=Date.now()},null,true))return;
 var o=$('#cl'),rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;cs=null;
 o.innerHTML=(OP.bookScene?OP.bookScene(X.fmtD(d)):'')+'<p class="bt">Dia fechado. Boa noite.</p>';if(OP.snd)OP.snd('close');
 setTimeout(function(){o.remove();X.draw()},rm?500:2700)};
/* ---------- rotinas ---------- */
function dlab(ds){var s=ds.slice().sort(function(a,b){return((a+6)%7)-((b+6)%7)}),k=s.join();if(s.length===7)return'Todos os dias';if(k==='1,2,3,4,5,6')return'Segunda a sábado';if(k==='1,2,3,4,5')return'Segunda a sexta';return s.map(function(i){return DN7[i]}).join(', ')||'Sem dias'}
OP.goalOpts=function(){return[[0,'Nenhuma']].concat(S().goals.filter(function(g){return !g.done}).map(function(g){return[g.id,g.t]}))};
V.rt=function(){var s=S();return X.head('Rotinas',1,'<button class="b p" data-a="rtn">Nova</button>')+'<p class="mu">As rotinas entram sozinhas na página do dia, somente quando o dia chega. Nada é escrito antes. O caderno registra a atividade (por exemplo "Treino de peito e tríceps"); o detalhe fica no seu app de treino.</p>'+(s.routines.map(function(r){return'<div class="row tk"><button class="tt" data-a="rte" data-id="'+r.id+'"><span class="'+(r.on?'':'dn')+'">'+esc(r.t)+'</span><small>'+dlab(r.days)+(r.time?', '+r.time:'')+', '+(r.req?'obrigatória':'flexível')+(r.cat?', '+esc(r.cat):'')+'</small></button><button class="b" data-a="rtt" data-id="'+r.id+'">'+(r.on?'Pausar':'Ativar')+'</button></div>'}).join('')||'<p class="mu">Nenhuma rotina ainda.</p>')};
function rtForm(r){return X.inp('t','Nome da atividade','text',r?r.t:'','maxlength="80"')+'<div class="fl"><span>Dias da semana</span><div class="dchk">'+[1,2,3,4,5,6,0].map(function(i){return'<label><input type="checkbox" name="d'+i+'"'+(r&&r.days.indexOf(i)>=0?' checked':'')+'>'+DN7[i]+'</label>'}).join('')+'</div></div>'+X.inp('time','Horário (opcional)','time',r?r.time:'')+X.inp('cat','Categoria','text',r?r.cat:'','maxlength="30"')+X.inp('min','Minutos estimados (opcional)','number',r&&r.min?r.min:'','min="0" max="1440"')+X.sel('req','Tipo',[['1','Obrigatória'],['0','Flexível']],r&&!r.req?'0':'1')+X.sel('goal','Meta relacionada',OP.goalOpts(),r?r.goal:0)+X.txa('obs','Observações',r?r.obs:'')}
function rtVal(v){var days=[0,1,2,3,4,5,6].filter(function(i){return v['d'+i]});if(!v.t.trim())throw new Error('Informe o nome da atividade');if(!days.length)throw new Error('Escolha ao menos um dia da semana');return{t:v.t.trim(),days:days,time:v.time,cat:v.cat.trim(),min:parseInt(v.min,10)||0,req:v.req==='1',goal:+v.goal||0,obs:v.obs}}
A.rtn=function(){X.ask('Nova rotina',rtForm(),'Criar',function(v){var r=rtVal(v),ok=X.run(function(W){r.id=W.n++;r.on=true;W.routines.push(r)},'Rotina criada');if(ok){materialize(true);X.draw()}return ok})};
A.rte=function(el){var id=+el.dataset.id,r0=S().routines.filter(function(r){return r.id===id})[0];X.ask('Editar rotina',rtForm(r0),'Salvar',function(v){var r=rtVal(v),ok=X.run(function(W){Object.assign(W.routines.filter(function(x){return x.id===id})[0],r)},'Rotina salva');if(ok){materialize(true);X.draw()}return ok},[['Excluir',function(){X.sure('Excluir a rotina? As tarefas já geradas continuam, mas deixam de contar como adesão à rotina.',function(){X.run(function(W){W.routines=W.routines.filter(function(x){return x.id!==id})},'Rotina excluída')},'Excluir')},'d']])};
A.rtt=function(el){var id=+el.dataset.id;if(X.run(function(W){var r=W.routines.filter(function(x){return x.id===id})[0];r.on=!r.on}))materialize(true),X.draw()};
/* ---------- metas ---------- */
var TL={c:'Curto prazo',m:'Médio prazo',l:'Longo prazo'};
var today=function(){return td()};
function prog(g){return g.done?100:g.steps.length?Math.round(g.steps.filter(function(x){return x.done}).length/g.steps.length*100):(g.log.length?g.log[g.log.length-1].p:0)}
function ded(id,a,b){var m=0,n=0;S().tasks.forEach(function(t){if(t.goal===id&&t.s==='done'&&t.due>=a&&t.due<=b){n++;m+=t.min||0}});return{n:n,m:m}}
function logP(g){var p=prog(g),t=today();g.log=g.log.filter(function(l){return l.d!==t});g.log.push({d:t,p:p,n:''})}
V.gl=function(){var s=S(),ac=s.goals.filter(function(g){return !g.done}),dn=s.goals.filter(function(g){return g.done});
 var row=function(g){var d7=ded(g.id,add(today(),-6),today());return'<button class="row" data-a="gopen" data-id="'+g.id+'"><span class="rt">'+esc(g.t)+(g.pr==='H'?'<em>prioridade alta</em>':'')+'</span><div class="pb" style="flex-basis:100%"><i style="width:'+prog(g)+'%"></i></div><span class="rs" style="padding-left:0">'+prog(g)+'%'+(g.due?', prazo '+X.fmtD(g.due):'')+(g.steps.length?', '+g.steps.filter(function(x){return x.done}).length+'/'+g.steps.length+' etapas':'')+(d7.m?', '+d7.m+' min nos últimos 7 dias':d7.n?', '+X.pl(d7.n,'atividade','atividades')+' nos últimos 7 dias':'')+'</span></button>'};
 return X.head('Metas',0,'<button class="b p" data-a="gn">Nova meta</button>'+X.top())+(['c','m','l'].map(function(k){var L=ac.filter(function(g){return g.term===k});return L.length?'<h2>'+TL[k]+'</h2>'+L.map(row).join(''):''}).join('')||'<p class="mu">Defina suas metas de curto, médio e longo prazo. Vincule rotinas e tarefas a elas para o caderno medir a dedicação real.</p>')+(dn.length?'<h2>Concluídas</h2>'+dn.map(row).join(''):'')};
function gForm(g){return X.inp('t','Meta','text',g?g.t:'','maxlength="120"')+X.txa('d','Descrição',g?g.d:'')+X.sel('term','Prazo',[['c','Curto prazo'],['m','Médio prazo'],['l','Longo prazo']],g?g.term:'m')+X.inp('due','Data-alvo (opcional)','date',g?g.due:'')+X.sel('pr','Prioridade',[['L','Baixa'],['M','Média'],['H','Alta']],g?g.pr:'M')+X.inp('cat','Categoria','text',g?g.cat:'','maxlength="30"')}
A.gn=function(){X.ask('Nova meta',gForm(),'Criar',function(v){if(!v.t.trim())throw new Error('Informe a meta');return X.run(function(W){W.goals.push({id:W.n++,t:v.t.trim(),d:v.d,cat:v.cat.trim(),term:v.term,due:v.due,pr:v.pr,steps:[],log:[],done:0,c:Date.now()})},'Meta criada')})};
A.gopen=function(el){ui.gid=+el.dataset.id;X.go('gd')};
V.gd=function(){var g=S().goals.filter(function(x){return x.id===ui.gid})[0];if(!g)return V.gl();var t=today(),wk=[3,2,1,0].map(function(i){var b=add(t,-7*i),r=ded(g.id,add(b,-6),b);return{l:X.fmtD(add(b,-6)).slice(0,5),m:r.m,n:r.n}}),hm=wk.some(function(w){return w.m}),mx=Math.max.apply(null,wk.map(function(w){return hm?w.m:w.n}).concat([1])),rts=S().routines.filter(function(r){return r.goal===g.id});
 return X.head(g.t,1,'<button class="b" data-a="gedit">Editar</button>')+'<p class="mu">'+TL[g.term]+(g.cat?', '+esc(g.cat):'')+(g.due?', prazo '+X.fmtD(g.due):'')+'</p>'+(g.d?'<p>'+esc(g.d)+'</p>':'')+'<div class="pb"><i style="width:'+prog(g)+'%"></i></div><p class="lead">'+prog(g)+'% concluída'+(g.done?' (meta concluída)':'')+'</p>'
 +X.sec('Etapas','',g.steps.map(function(x,i){return'<div class="row tk"><button class="bx'+(x.done?' on':'')+'" data-a="gst" data-i="'+i+'" aria-label="Alternar etapa"></button><span class="tt"><span class="'+(x.done?'dn':'')+'">'+esc(x.t)+'</span></span><button class="b d" data-a="gsd" data-i="'+i+'">Remover</button></div>'}).join('')+'<div class="qa"><input id="gsi" placeholder="Nova etapa" maxlength="120"><button class="b p" data-a="gsa">Adicionar</button></div>'+(g.steps.length?'':'<button class="b" data-a="glg">Registrar progresso manual</button>'))
 +X.sec('Dedicação nas últimas 4 semanas ('+(hm?'minutos':'atividades concluídas')+')','','<div style="display:flex;gap:10px;align-items:flex-end;height:90px">'+wk.map(function(w){var v=hm?w.m:w.n;return'<div style="flex:1;text-align:center"><div style="height:'+Math.round(v/mx*64)+'px;min-height:2px;background:var(--ac);border-radius:4px"></div><small>'+v+'</small><br><small class="mu">'+w.l+'</small></div>'}).join('')+'</div>'+(S().tasks.some(function(x){return x.goal===g.id})?'':'<p class="mu">Nenhuma tarefa ou rotina está ligada a esta meta ainda. Ligue pela rotina ou pela tarefa para medir a dedicação.</p>'))
 +(rts.length?X.sec('Rotinas ligadas','',rts.map(function(r){return'<p>'+esc(r.t)+' <small class="mu">'+dlab(r.days)+'</small></p>'}).join('')):'')
 +X.sec('Histórico de evolução','',g.log.slice(-12).reverse().map(function(l){return'<div class="set"><span>'+X.fmtD(l.d)+(l.n?'<br><small>'+esc(l.n)+'</small>':'')+'</span><b style="flex:0 0 auto">'+l.p+'%</b></div>'}).join('')||'<p class="mu">O histórico começa quando você marca uma etapa ou registra progresso.</p>')
 +'<div class="mf" style="justify-content:flex-start"><button class="b p" data-a="gdn">'+(g.done?'Reabrir meta':'Concluir meta')+'</button></div>'};
function gm(fn,msg){var id=ui.gid;return X.run(function(W){fn(W.goals.filter(function(x){return x.id===id})[0],W)},msg)}
A.gst=function(el){var i=+el.dataset.i;gm(function(g){g.steps[i].done=!g.steps[i].done;logP(g)})};
A.gsd=function(el){var i=+el.dataset.i;gm(function(g){g.steps.splice(i,1);logP(g)})};
A.gsa=function(){var v=$('#gsi').value.trim();if(!v){toast('Digite a etapa.');return}if(gm(function(g){if(g.steps.length>=30)throw new Error('Limite de 30 etapas');g.steps.push({t:v,done:false});logP(g)})){var n=$('#gsi');if(n)n.focus()}};
A.glg=function(){var g=S().goals.filter(function(x){return x.id===ui.gid})[0];X.ask('Registrar progresso',X.inp('p','Progresso atual (%)','number',prog(g),'min="0" max="100"')+X.inp('n','Observação (opcional)','text','','maxlength="200"'),'Registrar',function(v){var p=Math.min(100,Math.max(0,parseInt(v.p,10)||0));return gm(function(x){x.log=x.log.filter(function(l){return l.d!==today()});x.log.push({d:today(),p:p,n:v.n})},'Progresso registrado')})};
A.gdn=function(){gm(function(g){g.done=g.done?0:Date.now();if(g.done){g.log=g.log.filter(function(l){return l.d!==today()});g.log.push({d:today(),p:100,n:'Meta concluída'})}},'Pronto')};
A.gedit=function(){var id=ui.gid,g0=S().goals.filter(function(x){return x.id===id})[0];X.ask('Editar meta',gForm(g0),'Salvar',function(v){if(!v.t.trim())throw new Error('Informe a meta');return gm(function(g){g.t=v.t.trim();g.d=v.d;g.term=v.term;g.due=v.due;g.pr=v.pr;g.cat=v.cat.trim()},'Meta salva')},[['Excluir',function(){X.sure('Excluir esta meta e o histórico dela?',function(){if(X.run(function(W){W.goals=W.goals.filter(function(x){return x.id!==id})},'Meta excluída'))X.go('gl')},'Excluir')},'d']])};
document.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target.id==='gsi'){e.preventDefault();A.gsa()}});
/* ---------- relógio: liberar o próximo dia, virada de dia ---------- */
var lastOpen=null,lastDay=null;
function tick(){var t=td(),op=OP.maxDay()>t;materialize();
 if(op&&S().cfg.unl!==add(t,1)){ui.unl=true;setTimeout(function(){ui.unl=false},4500);toast('A página de amanhã foi liberada para planejamento.',1);X.run(function(W){W.cfg.unl=add(t,1)},null,true)}
 if(lastOpen!==null&&(lastOpen!==op||lastDay!==t)&&X.tab()==='di'&&!$('#cl')&&!document.querySelector('.ov'))X.draw();lastOpen=op;lastDay=t}
setInterval(tick,30000);
document.addEventListener('visibilitychange',function(){if(!document.hidden)tick()});
tick();
})();
