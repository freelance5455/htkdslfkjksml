const quranData = {};

async function loadQuranPage(page) {

    if (quranData[page]) {
        return quranData[page];
    }

    try {

        const response = await fetch(
            `https://api.alquran.cloud/v1/page/${page}/quran-uthmani`
        );

        if (!response.ok) {
            throw new Error("فشل تحميل الصفحة");
        }

        const result = await response.json();

        const ayahs = result.data.ayahs;

        const data = {
            page: page,

            ayahs: ayahs.map(ayah => ({
                text: ayah.text,
                number: ayah.numberInSurah,
                globalNumber: ayah.number,
                surah: ayah.surah.name,
                surahNumber: ayah.surah.number
            }))
        };

        quranData[page] = data;

        return data;

    } catch (error) {

        console.error(
            "خطأ في تحميل القرآن:",
            error
        );

        return null;
    }
}


/*
=================================
الحصول على صفحة بداية السورة
=================================
*/

async function getSurahStartPage(surahNumber) {

    try {

        const response = await fetch(
            `https://api.alquran.cloud/v1/surah/${surahNumber}/quran-uthmani`
        );

        if (!response.ok) {
            throw new Error("فشل تحميل السورة");
        }

        const result = await response.json();

        const firstAyah =
            result.data.ayahs[0];

        return firstAyah.page;

    } catch (error) {

        console.error(
            "خطأ في تحديد صفحة السورة:",
            error
        );

        return null;
    }
}