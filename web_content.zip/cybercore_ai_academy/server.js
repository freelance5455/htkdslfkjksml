'use strict';
// CyberCore AI Academy — сервер без внешних зависимостей (Node 18+).
const http = require('http'), fs = require('fs'), path = require('path');
try { // минимальный загрузчик .env
  for (const l of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n')) {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
} catch {}
const env = (k, d = '') => process.env[k] || d;
const PORT = +env('PORT', 3000), PUB = path.join(__dirname, 'public');
const SYSTEM = `Ты — CyberCore AI, наставник платформы CyberCore AI Academy. Отвечай на языке пользователя, просто и по делу.
Умеешь: объяснять программирование (HTML, CSS, JavaScript, Python и др.), разбирать код, находить ошибки и объяснять их причину, давать исправленный код, придумывать практические задания и проверять решения, объяснять основы Linux и сетей.
Код всегда оформляй в блоках тройных кавычек с указанием языка.
Кибербезопасность — только защитная и учебная: помогай с основами, защитой, разрешёнными CTF и собственными лабораториями. Не пиши вредоносный код, эксплойты для чужих систем, не помогай со взломом, слежкой и обходом защиты. Если просят такое — вежливо откажись и предложи безопасную альтернативу.
Не проси и не повторяй пароли, ключи и личные данные.`;

const SEC = {
  'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'geolocation=(), camera=(), microphone=()',
  'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'"
};
const send = (res, code, obj) => { res.writeHead(code, { ...SEC, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };

// Ограничение запросов: N в минуту с одного IP (в памяти).
const hits = new Map();
const limited = ip => {
  const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 60000);
  a.push(now); hits.set(ip, a); return a.length > +env('RATE_LIMIT_PER_MIN', 12);
};
setInterval(() => { const n = Date.now(); for (const [k, v] of hits) if (!v.some(t => n - t < 60000)) hits.delete(k); }, 60000).unref();
const clientIp = req => (env('TRUST_PROXY') && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress;

async function chat(req, res) {
  if (limited(clientIp(req))) return send(res, 429, { error: 'Слишком много запросов. Подожди минуту.' });
  const key = env('GEMINI_API_KEY');
  if (!key) return send(res, 503, { error: 'AI не настроен: администратору нужно задать GEMINI_API_KEY в настройках сервера.' });
  let body = '', size = 0;
  for await (const c of req) { size += c.length; if (size > 32768) return send(res, 413, { error: 'Слишком большой запрос.' }); body += c; }
  let d; try { d = JSON.parse(body); } catch { return send(res, 400, { error: 'Неверный формат запроса.' }); }
  const contents = (Array.isArray(d.messages) ? d.messages.slice(-20) : [])
    .filter(m => m && (m.role === 'user' || m.role === 'model') && typeof m.text === 'string' && m.text.trim())
    .map(m => ({ role: m.role, parts: [{ text: m.text.slice(0, 6000) }] }));
  if (!contents.length || contents[contents.length - 1].role !== 'user') return send(res, 400, { error: 'Пустое сообщение.' });
  const topic = typeof d.topic === 'string' ? d.topic.replace(/[\r\n]+/g, ' ').slice(0, 120) : '';
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 30000);
  try {
    const r = await fetch(`${env('GEMINI_API_BASE', 'https://generativelanguage.googleapis.com/v1beta')}/models/${env('GEMINI_MODEL', 'gemini-2.5-flash')}:generateContent`, {
      method: 'POST', signal: ctl.signal,
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, // ключ только в заголовке, не в URL
      body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM + (topic ? `\nТема урока: ${topic}` : '') }] }, contents, generationConfig: { maxOutputTokens: 1500, temperature: 0.5 } })
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { console.error('Gemini error', r.status, j.error && j.error.message); return send(res, r.status === 429 ? 429 : 502, { error: r.status === 429 ? 'Лимит Gemini исчерпан, попробуй позже.' : 'Сервис ИИ временно недоступен или ключ неверный.' }); }
    const text = ((j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []).map(p => p.text || '').join('').trim();
    if (!text) return send(res, 502, { error: 'ИИ не вернул ответ (мог сработать фильтр). Переформулируй вопрос.' });
    send(res, 200, { text });
  } catch (e) { send(res, 504, { error: e.name === 'AbortError' ? 'ИИ отвечает слишком долго.' : 'Не удалось связаться с ИИ.' }); }
  finally { clearTimeout(timer); }
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };
function serveStatic(req, res) {
  let p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html';
  const f = path.normalize(path.join(PUB, p));
  if (!f.startsWith(PUB + path.sep)) { res.writeHead(403, SEC); return res.end('Forbidden'); }
  fs.readFile(f, (e, b) => {
    if (e) { res.writeHead(404, SEC); return res.end('Not found'); }
    res.writeHead(200, { ...SEC, 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); res.end(req.method === 'HEAD' ? undefined : b);
  });
}

http.createServer(async (req, res) => {
  try {
    const u = req.url.split('?')[0];
    if (u === '/api/chat' && req.method === 'POST') return await chat(req, res);
    if (u === '/api/config') { const ph = env('SUPPORT_PHONE'); return send(res, 200, { aiEnabled: !!env('GEMINI_API_KEY'), supportPhone: /^\+\d{8,15}$/.test(ph) ? ph : '' }); }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, SEC); return res.end(); }
    serveStatic(req, res);
  } catch { res.writeHead(500, SEC); res.end('Server error'); }
}).listen(PORT, () => console.log(`CyberCore AI Academy: http://localhost:${PORT}  (Gemini: ${env('GEMINI_API_KEY') ? 'ключ задан' : 'ключ НЕ задан'})`));
