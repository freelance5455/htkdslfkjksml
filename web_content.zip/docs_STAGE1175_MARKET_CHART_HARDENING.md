# CryptoPulse Stage 1175 — Market Chart + Home Hardening

- Trade chart: shared LBank WebSocket -> direct `candles()` REST -> Android native REST -> native WebSocket.
- Native K-Line diagnostics now capture explicit LBank `result=false`, `error_code`, and `msg`.
- Home secondary CoinPaprika request now asks for up to 2000 tickers; existing Binance/CoinCap fallbacks remain active.
- Futures: official public Futures docs expose contract market data/order book but do not document a public historical K-line endpoint in the current contract document. If real Futures samples are not yet sufficient, the app now uses real LBank Spot history for chart geometry, labels it as reference history, and synchronizes the latest candle to the real Futures last price. No fabricated market prices are introduced.
- Wallet/contracts/Mainnet remain untouched.
