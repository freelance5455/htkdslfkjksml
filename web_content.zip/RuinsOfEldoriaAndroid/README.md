# Ruins of Eldoria — Android

Projeto Android que empacota o protótipo HTML em um WebView local.

## Como gerar o APK
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Use **Build > Build APK(s)**.
4. O APK de debug será gerado em `app/build/outputs/apk/debug/`.

O jogo não precisa de internet para carregar o HTML: ele fica dentro de `app/src/main/assets/index.html`.
