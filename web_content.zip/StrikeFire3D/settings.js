(() => {
"use strict";
const $=id=>document.getElementById(id);
const key="strikefire_global_settings";
const defaults={sensitivity:1,joystick:"normal",invertY:false,leftHanded:false,graphics:"medium"};
let cfg={...defaults};
try{cfg={...defaults,...JSON.parse(localStorage.getItem(key)||"{}")};}catch(_){}
const panel=$("settingsPanel");
function apply(){
 const pad=$("movePad");
 pad.classList.remove("small","large");
 if(cfg.joystick!=="normal")pad.classList.add(cfg.joystick);
 document.body.classList.toggle("left-handed",!!cfg.leftHanded);
 if(window.applyStrikeFireGraphics)window.applyStrikeFireGraphics(cfg.graphics);
}
function show(){
 $("lookSensitivity").value=cfg.sensitivity;
 $("sensitivityValue").textContent=Number(cfg.sensitivity).toFixed(1)+"x";
 $("joystickSize").value=cfg.joystick;
 $("joystickValue").textContent=cfg.joystick==="small"?"Pequeño":cfg.joystick==="large"?"Grande":"Normal";
 $("invertY").checked=cfg.invertY;
 $("leftHanded").checked=cfg.leftHanded;
 $("graphicsQuality").value=cfg.graphics;
 panel.classList.remove("hidden");
}
$("openSettings").addEventListener("click",show);
$("closeSettings").addEventListener("click",()=>panel.classList.add("hidden"));
$("lookSensitivity").addEventListener("input",e=>{$("sensitivityValue").textContent=Number(e.target.value).toFixed(1)+"x";});
$("joystickSize").addEventListener("change",e=>{$("joystickValue").textContent=e.target.value==="small"?"Pequeño":e.target.value==="large"?"Grande":"Normal";});
$("saveSettings").addEventListener("click",()=>{
 cfg={sensitivity:Number($("lookSensitivity").value),joystick:$("joystickSize").value,
 invertY:$("invertY").checked,leftHanded:$("leftHanded").checked,graphics:$("graphicsQuality").value};
 localStorage.setItem(key,JSON.stringify(cfg));apply();panel.classList.add("hidden");
 const msg=document.createElement("div");msg.textContent="AJUSTES GUARDADOS";msg.style.cssText="position:fixed;z-index:100;top:15%;left:50%;transform:translateX(-50%);background:#183c27;color:white;padding:12px 18px;border-radius:10px;font-weight:bold";
 document.body.appendChild(msg);setTimeout(()=>msg.remove(),1300);
});
window.getStrikeFireSettings=()=>({...cfg});
apply();
})();