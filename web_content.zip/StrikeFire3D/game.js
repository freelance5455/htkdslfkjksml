(() => {
"use strict";

const $ = id => document.getElementById(id);
document.addEventListener("contextmenu",e=>e.preventDefault());
document.addEventListener("touchmove",e=>e.preventDefault(),{passive:false});
const menu = $("menu"), gameover = $("gameover");
let scene, camera, renderer, clock;
let player, enemies = [], bullets = [];
let running = false, kills = 0, hp = 100, ammo = 30, reloading = false;
let moveX = 0, moveY = 0, firing = false, fireCooldown = 0;
let yaw = 0, pitch = 0, lastLook = null;
const raycaster = new THREE.Raycaster();
const enemyGeo = new THREE.BoxGeometry(0.8, 1.65, 0.65);
const bulletGeo = new THREE.SphereGeometry(0.07, 6, 5);
const mats = {
  floor: new THREE.MeshLambertMaterial({color:0x465442}),
  wall: new THREE.MeshLambertMaterial({color:0x555b50}),
  enemy: new THREE.MeshLambertMaterial({color:0xb52d22}),
  enemyHead: new THREE.MeshLambertMaterial({color:0xd7a47a}),
  bullet: new THREE.MeshBasicMaterial({color:0xffd45b}),
  playerGun: new THREE.MeshLambertMaterial({color:0x20252a})
};

function init3D() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x8da3a0);
  scene.fog = new THREE.Fog(0x8da3a0, 17, 48);

  camera = new THREE.PerspectiveCamera(74, innerWidth/innerHeight, 0.1, 70);
  camera.position.set(0, 1.65, 5);

  renderer = new THREE.WebGLRenderer({antialias:false, powerPreference:"low-power"});
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1));
  renderer.setSize(innerWidth, innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  document.body.insertBefore(renderer.domElement, document.body.firstChild);

  scene.add(new THREE.HemisphereLight(0xffffff, 0x46513b, 2));
  const sun = new THREE.DirectionalLight(0xffffff, 1.25);
  sun.position.set(-5, 10, 7);
  scene.add(sun);

  const floor = new THREE.Mesh(new THREE.PlaneGeometry(60,60), mats.floor);
  floor.rotation.x = -Math.PI/2;
  floor.position.y = -0.04;
  scene.add(floor);

  // Arena sencilla de bajo poligonaje
  addWall(0, 1.5, -18, 38, 3, 1);
  addWall(0, 1.5, 18, 38, 3, 1);
  addWall(-19, 1.5, 0, 1, 3, 36);
  addWall(19, 1.5, 0, 1, 3, 36);
  for (let i=0;i<10;i++) {
    const x = (Math.random()-0.5)*28;
    const z = (Math.random()-0.5)*25;
    if (Math.abs(x)<3 && Math.abs(z)<4) continue;
    const crate = new THREE.Mesh(new THREE.BoxGeometry(1.7,1.2,1.7), mats.wall);
    crate.position.set(x,0.6,z);
    scene.add(crate);
  }

  // Arma sencilla visible en primera persona
  const gun = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.22,0.2,0.75), mats.playerGun);
  body.position.set(0.34,-0.28,-0.65);
  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.045,0.045,0.48,6), mats.playerGun);
  barrel.rotation.x = Math.PI/2;
  barrel.position.set(0.34,-0.22,-1.15);
  gun.add(body,barrel);
  camera.add(gun);
  scene.add(camera);

  clock = new THREE.Clock();
  for(let i=0;i<4;i++) spawnEnemy();
  window.addEventListener("resize", resize);
}

function addWall(x,y,z,w,h,d) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), mats.wall);
  mesh.position.set(x,y,z); scene.add(mesh);
}

function resize() {
  if(!renderer) return;
  camera.aspect = innerWidth/innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1,1.65));
}

function spawnEnemy() {
  if(enemies.length >= 9) return;
  let x,z;
  do { x=(Math.random()-0.5)*30; z=(Math.random()-0.5)*28; }
  while(Math.hypot(x-camera.position.x,z-camera.position.z)<7);
  const group = new THREE.Group();
  const body = new THREE.Mesh(enemyGeo,mats.enemy);
  body.position.y=0.85;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.25,7,6),mats.enemyHead);
  head.position.y=1.85;
  group.add(body,head);
  group.position.set(x,0,z);
  group.userData.hp=3;
  group.userData.cooldown=1+Math.random()*2;
  scene.add(group);
  enemies.push(group);
}

function updateHUD() {
  $("health").textContent = "♥ " + Math.max(0,Math.ceil(hp));
  $("ammo").textContent = ammo + " / 30" + (reloading ? " · RECARGANDO" : "");
  $("score").textContent = "BAJAS: " + kills;
}

function reload() {
  if(!running || reloading || ammo===30) return;
  reloading=true; updateHUD();
  setTimeout(() => {
    if(!running) return;
    ammo=30; reloading=false; updateHUD();
    showMessage("¡RECARGADO!");
  },1100);
}
$("reload").addEventListener("pointerdown",e=>{e.preventDefault();reload();});

function shoot() {
  if(!running || reloading || ammo<=0) {
    if(ammo<=0) showMessage("¡RECARGA!");
    return;
  }
  ammo--; updateHUD();
  // Disparo al centro de la pantalla
  raycaster.setFromCamera(new THREE.Vector2(0,0),camera);
  const hits=raycaster.intersectObjects(enemies,true);
  if(hits.length) {
    let target=hits[0].object;
    while(target.parent && !target.userData.hp) target=target.parent;
    if(target.userData.hp) {
      target.userData.hp--;
      target.position.y=0.04;
      if(target.userData.hp<=0) {
        scene.remove(target);
        enemies=enemies.filter(e=>e!==target);
        kills++; updateHUD();
        showMessage("¡ELIMINACIÓN!");
      }
    }
  }
}

function showMessage(msg) {
  $("message").textContent=msg;
  clearTimeout(showMessage.timer);
  showMessage.timer=setTimeout(()=>$("message").textContent="",850);
}

function update(dt) {
  if(!running) return;
  // Dirección relativa a la cámara
  const forward = new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
  const right = new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));
  const move = new THREE.Vector3();
  move.addScaledVector(forward,moveY);
  move.addScaledVector(right,moveX);
  if(move.lengthSq()>1) move.normalize();
  camera.position.addScaledVector(move,4.2*dt);
  camera.position.x=THREE.MathUtils.clamp(camera.position.x,-17.5,17.5);
  camera.position.z=THREE.MathUtils.clamp(camera.position.z,-17,17);
  camera.rotation.order="YXZ";
  camera.rotation.y=yaw;
  camera.rotation.x=pitch;

  fireCooldown-=dt;
  if(firing && fireCooldown<=0) { shoot(); fireCooldown=0.23; }

  for(const e of enemies) {
    const dx=camera.position.x-e.position.x;
    const dz=camera.position.z-e.position.z;
    const dist=Math.hypot(dx,dz);
    if(dist>1.65) {
      e.position.x += dx/dist*1.05*dt;
      e.position.z += dz/dist*1.05*dt;
      e.rotation.y=Math.atan2(dx,dz);
    } else {
      e.userData.cooldown-=dt;
      if(e.userData.cooldown<=0) {
        hp-=8; e.userData.cooldown=1.3; updateHUD();
        if(hp<=0) endGame();
      }
    }
  }
  if(enemies.length<4 && Math.random()<dt*0.8) spawnEnemy();
}

function animate() {
  if(!running) return;
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),0.04);
  update(dt);
  renderer.render(scene,camera);
}

function start() {
  if(!renderer) init3D();
  // Reiniciar arena y estado
  enemies.forEach(e=>scene.remove(e));
  enemies=[]; bullets=[];
  kills=0; hp=100; ammo=30; reloading=false;
  camera.position.set(0,1.65,5); yaw=0; pitch=0;
  for(let i=0;i<4;i++) spawnEnemy();
  running=true; menu.classList.add("hidden"); gameover.classList.add("hidden");
  updateHUD(); clock.start(); animate();
}
function endGame() {
  running=false; firing=false;
  $("result").textContent="Bajas: "+kills;
  gameover.classList.remove("hidden");
}
$("play").addEventListener("click",start);
$("again").addEventListener("click",start);

// Joystick de movimiento
const pad=$("movePad"), stick=$("moveStick");
let padId=null;
pad.addEventListener("pointerdown",e=>{
  e.preventDefault(); padId=e.pointerId; pad.setPointerCapture(padId); movePad(e);
});
pad.addEventListener("pointermove",e=>{if(e.pointerId===padId)movePad(e);});
function movePad(e) {
  const r=pad.getBoundingClientRect(), cx=r.left+r.width/2, cy=r.top+r.height/2;
  let dx=e.clientX-cx,dy=e.clientY-cy, max=34, len=Math.hypot(dx,dy);
  if(len>max){dx=dx/len*max;dy=dy/len*max;}
  moveX=dx/max; moveY=-dy/max;
  stick.style.transform=`translate(${dx}px,${dy}px)`;
}
function resetPad(e) {
  if(e.pointerId!==padId)return;
  padId=null;moveX=0;moveY=0;stick.style.transform="translate(0,0)";
}
pad.addEventListener("pointerup",resetPad);
pad.addEventListener("pointercancel",resetPad);

// Arrastrar en el lado derecho para mirar alrededor
const look=$("lookZone");
look.addEventListener("pointerdown",e=>{e.preventDefault();lastLook={x:e.clientX,y:e.clientY,id:e.pointerId};try{look.setPointerCapture(e.pointerId);}catch(_){}});
look.addEventListener("pointermove",e=>{
  if(!lastLook || e.pointerId!==lastLook.id)return;
  e.preventDefault();
  const dx=e.clientX-lastLook.x,dy=e.clientY-lastLook.y;
  yaw-=dx*0.006; pitch-=dy*0.005;
  pitch=THREE.MathUtils.clamp(pitch,-1.15,1.15);
  lastLook={x:e.clientX,y:e.clientY,id:e.pointerId};
});
function stopLook(e){if(lastLook && e.pointerId===lastLook.id){e.preventDefault();lastLook=null;}}
look.addEventListener("pointerup",stopLook);
look.addEventListener("pointercancel",stopLook);

// Botón de disparo mantenido
$("fire").addEventListener("pointerdown",e=>{e.preventDefault();firing=true;shoot();});
window.addEventListener("pointerup",()=>firing=false);
window.addEventListener("pointercancel",()=>firing=false);

// Teclado para pruebas en ordenador
const pressed={};
window.addEventListener("keydown",e=>{if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"," "].includes(e.key))e.preventDefault();pressed[e.key.toLowerCase()]=true;if(e.code==="Space")shoot();},{passive:false});
window.addEventListener("keyup",e=>pressed[e.key.toLowerCase()]=false);
function keyboardLoop(){
  if(pressed.w||pressed.arrowup)moveY=1;
  else if(pressed.s||pressed.arrowdown)moveY=-1;
  else if(!padId)moveY=0;
  if(pressed.a||pressed.arrowleft)moveX=-1;
  else if(pressed.d||pressed.arrowright)moveX=1;
  else if(!padId)moveX=0;
  requestAnimationFrame(keyboardLoop);
}
keyboardLoop();
})();
