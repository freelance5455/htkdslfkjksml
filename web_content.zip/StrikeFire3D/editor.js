(() => {
"use strict";
const CREATOR_EMAIL = "angelmio2026@gmail.com";
const $ = id => document.getElementById(id);
const login=$("creatorLogin"), editor=$("mapEditor");
let scene,camera,renderer,raycaster,ground,objects=[],selected=null,dragging=false;
let pointer={x:0,y:0};
const savedKey="strikefire_v35_custom_map";
const palette={
 house:{name:"Casa",color:0xaaa18b,geometry:()=>new THREE.BoxGeometry(5,3.2,4)},
 tower:{name:"Torre",color:0x566d50,geometry:()=>new THREE.BoxGeometry(2,7,2)},
 container:{name:"Contenedor",color:0x285a78,geometry:()=>new THREE.BoxGeometry(6,2.4,2.5)},
 barrel:{name:"Barril",color:0x9c3c2c,geometry:()=>new THREE.CylinderGeometry(.65,.65,1.4,8)},
 tree:{name:"Árbol",color:0x315b35,geometry:()=>new THREE.ConeGeometry(1.5,4,7)},
 mountain:{name:"Montaña",color:0x53634b,geometry:()=>new THREE.ConeGeometry(4,7,6)},
 road:{name:"Tramo de calle",color:0x343a39,geometry:()=>new THREE.BoxGeometry(8,.12,3)}
};
function openLogin(){login.classList.remove("hidden");$("creatorEmail").value="";$("loginError").textContent="";}
$("openEditor").addEventListener("click",openLogin);
$("creatorCancel").addEventListener("click",()=>login.classList.add("hidden"));
$("creatorEnter").addEventListener("click",()=>{
 const email=$("creatorEmail").value.trim().toLowerCase();
 if(email!==CREATOR_EMAIL){$("loginError").textContent="Este correo no tiene permisos de creador.";return;}
 login.classList.add("hidden");editor.classList.remove("hidden");initEditor();
});
$("creatorEmail").addEventListener("keydown",e=>{if(e.key==="Enter")$("creatorEnter").click();});
$("closeEditor").addEventListener("click",()=>{editor.classList.add("hidden");});
function initEditor(){
 if(renderer){resize();return;}
 const host=$("editorStage");
 scene=new THREE.Scene();scene.background=new THREE.Color(0x87958b);
 camera=new THREE.PerspectiveCamera(55,host.clientWidth/host.clientHeight,.1,200);
 camera.position.set(19,22,25);camera.lookAt(0,0,0);
 renderer=new THREE.WebGLRenderer({antialias:false, powerPreference:"low-power"});
 renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.3));renderer.setSize(host.clientWidth,host.clientHeight);
 host.appendChild(renderer.domElement);
 scene.add(new THREE.HemisphereLight(0xffffff,0x52604a,2));
 const sun=new THREE.DirectionalLight(0xffffff,1.5);sun.position.set(-10,20,10);scene.add(sun);
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(60,60),new THREE.MeshLambertMaterial({color:0x68745f}));
 floor.rotation.x=-Math.PI/2;floor.name="editorGround";scene.add(floor);ground=floor;
 const grid=new THREE.GridHelper(60,30,0x344b3a,0x9aa493);grid.position.y=.015;scene.add(grid);
 raycaster=new THREE.Raycaster();
 loadSaved();renderer.domElement.addEventListener("pointerdown",onDown);
 renderer.domElement.addEventListener("pointermove",onMove);
 renderer.domElement.addEventListener("pointerup",()=>dragging=false);
 window.addEventListener("resize",resize);
 animate();
}
function resize(){if(!renderer)return;const h=$("editorStage");camera.aspect=h.clientWidth/h.clientHeight;camera.updateProjectionMatrix();renderer.setSize(h.clientWidth,h.clientHeight);}
function makeObject(type,x=0,z=0,rot=0,scale=1){
 const p=palette[type];if(!p)return;
 const material=new THREE.MeshLambertMaterial({color:p.color});
 const mesh=new THREE.Mesh(p.geometry(),material);mesh.position.set(x,0,z);mesh.rotation.y=rot;mesh.scale.setScalar(scale);
 mesh.userData={type};scene.add(mesh);objects.push(mesh);select(mesh);return mesh;
}
function select(obj){selected=obj;$("selectedName").textContent=obj?palette[obj.userData.type].name:"Ninguno";objects.forEach(o=>{o.material.emissive.setHex(o===obj?0x333322:0x000000);});}
function coords(e){const r=renderer.domElement.getBoundingClientRect();return new THREE.Vector2((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1);}
function hit(e){raycaster.setFromCamera(coords(e),camera);return raycaster.intersectObjects(objects,false)[0];}
function planePoint(e){raycaster.setFromCamera(coords(e),camera);const plane=new THREE.Plane(new THREE.Vector3(0,1,0),0);const v=new THREE.Vector3();return raycaster.ray.intersectPlane(plane,v)?v:null;}
function onDown(e){e.preventDefault();const h=hit(e);if(h){select(h.object);dragging=true;renderer.domElement.setPointerCapture(e.pointerId);}else{const p=planePoint(e);if(p&&selected){selected.position.x=p.x;selected.position.z=p.z;}}}
function onMove(e){if(!dragging||!selected)return;const p=planePoint(e);if(p){selected.position.x=THREE.MathUtils.clamp(p.x,-28,28);selected.position.z=THREE.MathUtils.clamp(p.z,-28,28);}}
document.querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>{if(!scene)initEditor();makeObject(b.dataset.add,(Math.random()-.5)*12,(Math.random()-.5)*12);}));
$("rotateObject").addEventListener("click",()=>{if(selected)selected.rotation.y+=Math.PI/4;});
$("scaleObject").addEventListener("click",()=>{if(selected)selected.scale.multiplyScalar(1.2);});
$("deleteObject").addEventListener("click",()=>{if(!selected)return;scene.remove(selected);objects=objects.filter(o=>o!==selected);select(null);});
function serialize(){return objects.map(o=>({type:o.userData.type,x:o.position.x,z:o.position.z,rot:o.rotation.y,scale:o.scale.x}));}
$("saveMap").addEventListener("click",()=>{localStorage.setItem(savedKey,JSON.stringify(serialize()));$("editorStatus").textContent="¡Mapa guardado en este dispositivo! Objetos: "+objects.length;});
$("clearMap").addEventListener("click",()=>{objects.forEach(o=>scene.remove(o));objects=[];select(null);$("editorStatus").textContent="Escena vacía. Añade nuevos objetos." ;});
function loadSaved(){try{const data=JSON.parse(localStorage.getItem(savedKey)||"[]");data.forEach(o=>makeObject(o.type,o.x,o.z,o.rot,o.scale));select(null);}catch(e){console.warn("No se pudo cargar el mapa guardado",e);}}
function animate(){if(!renderer)return;requestAnimationFrame(animate);renderer.render(scene,camera);}
window.getStrikeFireCustomMap=()=>{try{return JSON.parse(localStorage.getItem(savedKey)||"[]");}catch(e){return [];}};
})();