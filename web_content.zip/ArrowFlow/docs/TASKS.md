# TASKS — ArrowFlow

## Milestone 1 — playable prototype
- [x] Define formal ray-blocking rules.
- [x] Create responsive board and directional arrow input.
- [x] Implement legal move, blocked feedback, and victory state.
- [x] Add six deterministic level definitions and solver.
- [x] Execute validation script in Node.js; all six levels pass solver validation.
- [ ] Manually verify touch behavior in an actual mobile browser.

## Milestone 2 — core game loop
- [x] Undo and restart.
- [x] Hint via solver.
- [x] Level select and progression.
- [x] Local progress persistence.
- [ ] Add scoring/stars after par values are playtested.

## Milestone 3 — polish
- [x] Basic exit animation, sound toggle, optional vibration toggle, theme setting.
- [ ] Tune animation and accessibility with device testing.
- [x] Add service worker cache shell; cold-start offline behavior still requires browser/device verification.

## Milestone 4 — QA
- [x] Automated level validation script authored.
- [ ] Run automated tests in supported runtime.
- [ ] Add focused engine unit tests for blocked move, undo, restart and persistence.
- [ ] Test performance on ordinary Android hardware.

## Milestone 5 — packaging
- [x] Choose Capacitor packaging route and add package/config/scripts.
- [ ] Build APK using an available Android toolchain.
- [ ] Install and verify APK on a real device.
