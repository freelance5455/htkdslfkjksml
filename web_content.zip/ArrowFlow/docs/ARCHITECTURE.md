# ARCHITECTURE — ArrowFlow

## Principles
- Keep puzzle rules independent of DOM/UI code.
- Use deterministic content.
- Avoid runtime network dependencies.
- Fail closed when a level is invalid or unsolvable.
- Keep state mutations small and explicit.

## State
`{ moves: number, arrows: Arrow[] }`, where `Arrow = { id, x, y, dir }`. Level geometry is immutable. Undo history stores cloned prior states.

## Main flow
Input → `isMoveLegal` → feedback or animation → `removeArrow` → render → win check. Hint uses `solveLevel` on the current remaining arrows.

## Solver
Depth-first search tries each currently unblocked arrow. A memoized key contains the sorted IDs of remaining arrows. For this rule, positions/directions are fixed per level, so remaining IDs fully determine the board state. Search has a visit limit.

## Persistence
Small JSON records are stored locally. Storage exceptions are caught. No server-side components exist.

## Evolution path
Once content and rule tests are stable, TypeScript types and Phaser scenes can replace the DOM renderer without changing the engine's formal rules.
