# LEVEL_DESIGN — ArrowFlow

## Content rules
- Use handcrafted deterministic layouts in the MVP.
- Every level must pass structural validation and `solveLevel`.
- A level is not considered shipped if solver validation fails.
- `par` is an optional move-count target, not yet used for scoring.

## Initial pack
Six original levels are defined in `src/levels.js`: First Flow, Crosswind, Traffic, Side Street, Green Lights, and Quiet Corner. Their intended difficulty labels are content metadata only and may be adjusted after playtesting.

## Validation command
`node tests/validate-levels.mjs`

## Future content workflow
1. Draft a level with unique arrow IDs and in-bounds coordinates.
2. Run structural validation.
3. Run solver validation under the node visit limit.
4. Manually play the solution on a mobile viewport.
5. Add it to the pack only after both automated and manual verification.
