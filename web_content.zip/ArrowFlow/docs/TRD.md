# TRD — ArrowFlow

## Current implementation
Plain HTML/CSS/ES modules, no external dependencies. This is an intentional first milestone trade-off against the preferred TypeScript/Phaser/Vite stack: it reduces setup and lets the playable prototype run in simple static hosts. Phaser can be introduced after the rules and content are stable.

## Runtime modules
- `src/main.js`: screens, input wiring, animation timing, persistence, audio feedback.
- `src/engine.js`: pure rule engine, validation, move legality, undo-state cloning, solver and hint selection.
- `src/levels.js`: deterministic handcrafted level data.
- `styles.css`: responsive interface and themes.

## Coordinates
Grid origin is top-left. `x` increases east/right; `y` increases south/down. Directions are `N`, `E`, `S`, `W`.

## Formal move rule
For an arrow at `(x,y)` with vector `(dx,dy)`, inspect `(x+dx,y+dy)` and each subsequent in-bounds cell. If any remaining arrow occupies one of those cells, the move is illegal. If the ray reaches the edge without another arrow, the arrow exits and is removed.

## Persistence
`localStorage` keys `arrowflow.save.v1` and `arrowflow.settings.v1`. Parsing failures fall back to safe defaults. Data is local and contains no personal information.

## Build/deploy
Static files can be hosted as-is. ES modules require HTTP(S) origin; `file://` is not supported. There is no compile step.

## Future Android packaging
Use a WebView wrapper or Capacitor only after mobile web QA. Test the actual generated APK on a device before claiming readiness.
