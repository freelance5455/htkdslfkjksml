# PRD — ArrowFlow

## Vision
A calm, readable, mobile-first logic puzzle in which players clear a grid by removing arrows whose straight exit ray is unobstructed.

## Audience
Casual puzzle players looking for short, thoughtful sessions on mobile.

## MVP scope
- Tap-based directional arrow board.
- Formal ray-blocking rules and error feedback.
- Win state, restart, undo, hint, progression and level select.
- Local persistence for unlocked/completed levels and best move counts.
- Sound, vibration and theme preferences.
- Responsive interface and keyboard/screen-reader labels.

## Out of scope for first prototype
Accounts, cloud saves, ads, analytics, leaderboards, rewarded ads, user-generated levels, daily events, native APK.

## Success criteria
1. Every shipped level passes structural validation and solver search.
2. Illegal moves do not mutate puzzle state.
3. Undo restores the exact previous logical state.
4. Restart restores the initial level state.
5. Progress/settings survive reload in the same browser profile.
6. Game remains usable on narrow mobile screens.

## Product risks
- The exact arrow puzzle rule can vary by game. ArrowFlow uses a documented straight-ray rule and original level layouts.
- Browser storage can be cleared by the user or browser.
- Haptics and audio may be restricted by browser/device policy.
