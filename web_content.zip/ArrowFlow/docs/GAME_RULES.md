# GAME_RULES — ArrowFlow

1. Each arrow occupies exactly one grid cell and points north, east, south, or west.
2. An arrow's exit path is a straight ray in its indicated direction.
3. Any other arrow in that ray blocks the move, even if that blocking arrow points elsewhere.
4. A blocked tap shows an explanation and feedback; it does not change arrows, move count, or undo history.
5. A legal tap removes the arrow after a short animation and increments the move count.
6. When no arrows remain, the level is complete.
7. Undo restores the exact state before the last successful move. Failed moves are not added to history.
8. Restart restores the initial arrow layout and resets the move count.
9. A hint identifies a legal first move from a solver-found solution of the current board.
10. Only unlocked levels can be opened. Completing a level unlocks the next one.

## Terminology
- **Ray:** cells from an arrow's adjacent cell in its direction through the board edge.
- **Blocker:** the first remaining arrow found along that ray.
- **Legal move:** a move with no blocker.
