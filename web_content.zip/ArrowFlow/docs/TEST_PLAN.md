# TEST_PLAN — ArrowFlow

## Automated checks
Run `node tests/validate-levels.mjs` in a Node.js environment.
- Each level has valid dimensions, coordinates, directions, and unique cells.
- Each level is solver-verifiable within the search limit.

## Manual gameplay checks
- Tap an unblocked arrow: it exits and move count increments.
- Tap a blocked arrow: error feedback appears and board/move count stay unchanged.
- Undo after a legal move: exact prior arrows and move count return.
- Restart: initial layout and zero moves return.
- Hint: highlighted arrow is legal and begins a verified solution.
- Complete a level: completion screen appears and next level unlocks.
- Reload: progress and settings remain in local storage.
- Try narrow mobile viewport and portrait orientation.
- Toggle sound, vibration, and theme.
- Test while offline after files have been loaded; full offline cold-start requires a service worker and is not implemented yet.

## Status discipline
Do not label manual checks as passed without actually performing them on a device/browser. Automated validation status must come from the executed command output.
