import assert from "node:assert/strict";
import { validateLevel, blockerFor, isMoveLegal, removeArrow, cloneState, solveLevel, findHint } from "../src/engine.js";
const level = {id:99,width:4,height:4,arrows:[
 {id:"a",x:0,y:1,dir:"E"}, {id:"b",x:2,y:1,dir:"N"}, {id:"c",x:3,y:3,dir:"S"}
]};
assert.equal(validateLevel(level).valid,true,"valid level accepted");
assert.equal(validateLevel({...level,arrows:[...level.arrows,{id:"dup",x:0,y:1,dir:"W"}]}).valid,false,"duplicate cells rejected");
assert.equal(validateLevel({...level,arrows:[...level.arrows,{id:"bad",x:9,y:1,dir:"W"}]}).valid,false,"out-of-bounds arrows rejected");
let state={moves:0,arrows:level.arrows.map(a=>({...a}))};
assert.equal(blockerFor(state.arrows,"a",4,4).id,"b","ray detects blocker");
assert.equal(isMoveLegal(state,"a",level).legal,false,"blocked move illegal");
const blockedResult=removeArrow(state,"a",level);
assert.equal(blockedResult.state,state,"blocked move does not mutate state");
assert.equal(state.moves,0,"blocked move does not increment moves");
const legal=removeArrow(state,"b",level);
assert.equal(legal.legal,true,"unblocked arrow can exit");
assert.equal(legal.state.moves,1,"legal move increments moves");
assert.equal(state.arrows.length,3,"immutable move keeps old state intact");
const before=cloneState(state);
const moved=removeArrow(state,"b",level).state;
assert.deepEqual(before.arrows.length,3);
assert.equal(moved.arrows.length,2);
assert.equal(solveLevel(level).solvable,true,"sample level solvable");
assert.ok(findHint(state,level),"hint returns a valid first move");
const impossible = {id:100,width:3,height:3,arrows:[
 {id:"a",x:0,y:1,dir:"E"},{id:"b",x:1,y:1,dir:"W"}
]};
assert.equal(solveLevel(impossible).solvable,false,"mutually blocking arrows detected");
console.log("PASS: engine unit tests (validation, blocking, immutable moves, solver, hints).");
