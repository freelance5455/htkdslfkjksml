import { LEVELS } from "../src/levels.js";
import { validateLevel, solveLevel } from "../src/engine.js";
let failures = 0;
for (const level of LEVELS) {
  const validation = validateLevel(level);
  const solution = solveLevel(level);
  console.log(`Level ${level.id}: valid=${validation.valid}, solvable=${solution.solvable}, visited=${solution.visited ?? 0}`);
  if (!validation.valid || !solution.solvable) {
    failures++;
    console.error(`  FAIL: ${validation.reason || solution.reason || "not solvable"}`);
  }
}
if (failures) process.exitCode = 1;
else console.log(`PASS: all ${LEVELS.length} levels are structurally valid and solvable.`);
