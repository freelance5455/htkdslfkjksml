import fs from "node:fs";
import path from "node:path";
const root = process.cwd();
const out = path.join(root, "www");
const include = ["index.html", "styles.css", "manifest.webmanifest", "sw.js", "src", "assets"];
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const entry of include) {
  const from = path.join(root, entry);
  if (!fs.existsSync(from)) throw new Error(`Required web asset missing: ${entry}`);
  fs.cpSync(from, path.join(out, entry), { recursive: true });
}
console.log(`Prepared ${out} for Capacitor.`);
