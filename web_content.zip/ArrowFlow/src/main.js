import { LEVELS } from "./levels.js";
import { cloneState, validateLevel, solveLevel, isMoveLegal, removeArrow, findHint } from "./engine.js";

const $ = id => document.getElementById(id);
const screens = ["menuScreen", "gameScreen", "levelsScreen", "completeScreen"];
const storageKey = "arrowflow.save.v1";
const settingsKey = "arrowflow.settings.v1";
let save = loadSave();
let settings = loadSettings();
let currentLevelIndex = Math.min(Math.max(0, save.currentLevel || 0), LEVELS.length - 1);
let level = LEVELS[currentLevelIndex];
let state = initialState(level);
let history = [];
let hintArrow = null;
let busy = false;
let audioContext = null;

function initialState(lvl) { return { moves: 0, arrows: lvl.arrows.map(a => ({ ...a })) }; }
function loadSave() {
  try {
    const parsed = JSON.parse(localStorage.getItem(storageKey) || "{}");
    return { unlocked: Math.min(Math.max(1, parsed.unlocked || 1), LEVELS.length), completed: Array.isArray(parsed.completed) ? parsed.completed.filter(n => Number.isInteger(n) && n >= 1 && n <= LEVELS.length) : [], best: parsed.best && typeof parsed.best === "object" ? parsed.best : {}, currentLevel: Number.isInteger(parsed.currentLevel) ? parsed.currentLevel : 0 };
  } catch { return { unlocked: 1, completed: [], best: {}, currentLevel: 0 }; }
}
function loadSettings() {
  try { return { sound: true, vibration: false, dark: true, ...JSON.parse(localStorage.getItem(settingsKey) || "{}") }; }
  catch { return { sound: true, vibration: false, dark: true }; }
}
function persist() {
  try { localStorage.setItem(storageKey, JSON.stringify(save)); } catch { setMessage("Progress could not be saved in this browser.", "error"); }
}
function persistSettings() { try { localStorage.setItem(settingsKey, JSON.stringify(settings)); } catch {} }
function showScreen(id) { screens.forEach(s => $(s).classList.toggle("hidden", s !== id)); }
function say(text, type = "") { const el = $("message"); el.textContent = text; el.className = `message ${type}`.trim(); }
function tone(freq = 520, duration = .06) {
  if (!settings.sound) return;
  try {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioContext.createOscillator(), gain = audioContext.createGain();
    osc.frequency.value = freq; osc.type = "sine"; gain.gain.value = .035;
    osc.connect(gain); gain.connect(audioContext.destination); osc.start();
    gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + duration);
    osc.stop(audioContext.currentTime + duration);
  } catch {}
}
function vibrate(ms = 18) { if (settings.vibration && navigator.vibrate) navigator.vibrate(ms); }
function applyTheme() { document.documentElement.classList.toggle("light", !settings.dark); $("soundToggle").checked = settings.sound; $("vibrationToggle").checked = settings.vibration; $("themeToggle").checked = settings.dark; }
function updateMenu() {
  $("progressText").textContent = `${save.unlocked} of ${LEVELS.length} levels unlocked`;
  $("progressBar").style.width = `${(save.completed.length / LEVELS.length) * 100}%`;
  $("playBtn").querySelector("span").textContent = save.completed.includes(save.unlocked) && save.unlocked < LEVELS.length ? "Continue" : `Play level ${Math.min(save.unlocked, LEVELS.length)}`;
}
function startLevel(index) {
  if (index < 0 || index >= LEVELS.length || index + 1 > save.unlocked) return;
  currentLevelIndex = index; level = LEVELS[index]; save.currentLevel = index; persist();
  const validation = validateLevel(level);
  const solution = solveLevel(level);
  if (!validation.valid || !solution.solvable) {
    showScreen("gameScreen"); $("levelTitle").textContent = `Level ${level.id}`;
    $("board").innerHTML = `<p class="message error">This level failed validation and cannot be played.</p>`;
    say("Level validation failed. Please choose another level.", "error"); return;
  }
  state = initialState(level); history = []; hintArrow = null; busy = false;
  $("levelTitle").textContent = `Level ${level.id}`;
  showScreen("gameScreen"); renderBoard(); updateGameUI(); say("Tap an arrow with a clear exit path.");
}
function renderBoard() {
  const board = $("board"); board.style.gridTemplateColumns = `repeat(${level.width}, minmax(0, 1fr))`; board.style.gridTemplateRows = `repeat(${level.height}, minmax(0, 1fr))`; board.innerHTML = "";
  const byCell = new Map(state.arrows.map(a => [`${a.x},${a.y}`, a]));
  for (let y = 0; y < level.height; y++) for (let x = 0; x < level.width; x++) {
    const a = byCell.get(`${x},${y}`), cell = document.createElement("button");
    cell.type = "button"; cell.className = `cell ${a ? "arrow" : "empty"}`;
    if (a) {
      cell.textContent = ({N:"↑",E:"→",S:"↓",W:"←"})[a.dir];
      cell.setAttribute("aria-label", `Arrow pointing ${{N:"up",E:"right",S:"down",W:"left"}[a.dir]}, row ${y+1}, column ${x+1}`);
      cell.dataset.arrowId = a.id;
      if (a.id === hintArrow) { cell.style.borderColor = "var(--accent2)"; cell.style.boxShadow = "inset 0 0 0 2px var(--accent2)"; }
      cell.addEventListener("click", () => onArrowTap(a.id, cell));
    } else { cell.disabled = true; cell.setAttribute("aria-label", "Empty cell"); }
    board.appendChild(cell);
  }
}
function updateGameUI() {
  $("movesCount").textContent = state.moves;
  $("levelProgress").style.width = `${(1 - state.arrows.length / level.arrows.length) * 100}%`;
  $("undoBtn").disabled = !history.length || busy;
  $("hintBtn").disabled = !state.arrows.length || busy;
  $("restartBtn").disabled = busy;
}
function setMessage(text, type) { say(text, type); }
function onArrowTap(id, cell) {
  if (busy) return;
  const check = isMoveLegal(state, id, level);
  if (!check.legal) {
    cell.classList.remove("blocked"); void cell.offsetWidth; cell.classList.add("blocked");
    setMessage(check.reason, "error"); tone(180, .09); vibrate(28);
    setTimeout(() => cell.classList.remove("blocked"), 280);
    return;
  }
  history.push(cloneState(state));
  const arrow = state.arrows.find(a => a.id === id);
  cell.classList.add("exiting");
  const vector = {N:[0,-1],E:[1,0],S:[0,1],W:[-1,0]}[arrow.dir];
  cell.style.setProperty("--dx", `${vector[0] * 44}px`); cell.style.setProperty("--dy", `${vector[1] * 44}px`);
  busy = true; updateGameUI(); tone(660, .08); vibrate(12);
  setTimeout(() => {
    const result = removeArrow(state, id, level);
    state = result.state; hintArrow = null; busy = false;
    if (state.arrows.length === 0) { completeLevel(); return; }
    renderBoard(); updateGameUI(); setMessage("Good move. Find the next clear path.", "good");
  }, 190);
}
function completeLevel() {
  save.completed = [...new Set([...save.completed, level.id])].sort((a,b)=>a-b);
  save.best[level.id] = Math.min(save.best[level.id] || Infinity, state.moves);
  if (level.id < LEVELS.length) save.unlocked = Math.max(save.unlocked, level.id + 1);
  persist(); tone(820,.12); setTimeout(() => tone(1040,.16), 90);
  $("completeSummary").textContent = `You cleared all ${level.arrows.length} arrows in ${state.moves} moves.`;
  $("finalMoves").textContent = state.moves; $("finalBest").textContent = save.best[level.id];
  $("nextBtn").textContent = level.id < LEVELS.length ? "Next puzzle →" : "Play from level 1 →";
  showScreen("completeScreen"); updateMenu();
}
function undo() {
  if (!history.length || busy) return;
  state = history.pop(); hintArrow = null; renderBoard(); updateGameUI(); setMessage("Last move undone."); tone(430,.05);
}
function restart() { if (busy) return; state = initialState(level); history = []; hintArrow = null; renderBoard(); updateGameUI(); setMessage("Fresh board. Take your time."); }
function hint() {
  if (busy || !state.arrows.length) return;
  const id = findHint(state, level);
  if (!id) { setMessage("No solution found for this board state.", "error"); return; }
  hintArrow = id; renderBoard(); updateGameUI(); setMessage("Hint: try the arrow highlighted in gold.", "good"); tone(760,.08);
}
function openLevels() {
  const grid = $("levelGrid"); grid.innerHTML = "";
  LEVELS.forEach((l, i) => {
    const b = document.createElement("button"), unlocked = i + 1 <= save.unlocked;
    b.className = `level-tile ${save.completed.includes(l.id) ? "done" : ""} ${unlocked ? "" : "locked"}`;
    b.textContent = unlocked ? (save.completed.includes(l.id) ? `✓ ${l.id}` : l.id) : "🔒";
    b.disabled = !unlocked; b.setAttribute("aria-label", unlocked ? `Level ${l.id}${save.completed.includes(l.id) ? ", completed" : ""}` : `Level ${l.id}, locked`);
    b.addEventListener("click", () => startLevel(i)); grid.appendChild(b);
  });
  showScreen("levelsScreen");
}
$("playBtn").addEventListener("click", () => startLevel(Math.min(save.unlocked - 1, LEVELS.length - 1)));
$("levelsBtn").addEventListener("click", openLevels);
$("homeBtn").addEventListener("click", () => { updateMenu(); showScreen("menuScreen"); });
$("levelsBackBtn").addEventListener("click", () => showScreen("menuScreen"));
$("undoBtn").addEventListener("click", undo);
$("hintBtn").addEventListener("click", hint);
$("restartBtn").addEventListener("click", restart);
$("nextBtn").addEventListener("click", () => startLevel(level.id < LEVELS.length ? currentLevelIndex + 1 : 0));
$("replayBtn").addEventListener("click", () => startLevel(currentLevelIndex));
$("completeLevelsBtn").addEventListener("click", openLevels);
$("settingsBtn").addEventListener("click", () => $("settingsDialog").showModal());
$("closeSettings").addEventListener("click", () => $("settingsDialog").close());
$("soundToggle").addEventListener("change", e => { settings.sound = e.target.checked; persistSettings(); });
$("vibrationToggle").addEventListener("change", e => { settings.vibration = e.target.checked; persistSettings(); });
$("themeToggle").addEventListener("change", e => { settings.dark = e.target.checked; applyTheme(); persistSettings(); });
document.addEventListener("visibilitychange", () => { if (document.hidden && audioContext?.state === "running") audioContext.suspend(); else if (!document.hidden && audioContext?.state === "suspended") audioContext.resume(); });
applyTheme(); updateMenu();


// Cache the static game shell for repeat/offline launches in supported browsers.
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {
      // The game remains playable if service-worker registration is unavailable.
    });
  });
}
