// ArrowFlow rules engine: pure puzzle logic, independent from the UI.
// Rule: an arrow exits in a straight cardinal ray. Any remaining arrow in that ray blocks it.
export const DIRS = Object.freeze({
  N: { dx: 0, dy: -1, glyph: "↑", label: "up" },
  E: { dx: 1, dy: 0, glyph: "→", label: "right" },
  S: { dx: 0, dy: 1, glyph: "↓", label: "down" },
  W: { dx: -1, dy: 0, glyph: "←", label: "left" }
});

export function validateLevel(level) {
  if (!level || !Number.isInteger(level.width) || !Number.isInteger(level.height) ||
      level.width < 2 || level.height < 2 || !Array.isArray(level.arrows)) {
    return { valid: false, reason: "Invalid dimensions or arrows list." };
  }
  const seen = new Set();
  for (const a of level.arrows) {
    if (!Number.isInteger(a.x) || !Number.isInteger(a.y) ||
        a.x < 0 || a.y < 0 || a.x >= level.width || a.y >= level.height ||
        !DIRS[a.dir]) return { valid: false, reason: "Arrow has an invalid coordinate or direction." };
    const key = `${a.x},${a.y}`;
    if (seen.has(key)) return { valid: false, reason: "Two arrows occupy the same cell." };
    seen.add(key);
  }
  if (!level.arrows.length) return { valid: false, reason: "A level must contain at least one arrow." };
  return { valid: true };
}

export function blockerFor(arrows, arrowId, width, height) {
  const arrow = arrows.find(a => a.id === arrowId);
  if (!arrow) return null;
  const { dx, dy } = DIRS[arrow.dir];
  let x = arrow.x + dx, y = arrow.y + dy;
  while (x >= 0 && x < width && y >= 0 && y < height) {
    const blocker = arrows.find(a => a.id !== arrowId && a.x === x && a.y === y);
    if (blocker) return blocker;
    x += dx; y += dy;
  }
  return null;
}

export function isMoveLegal(state, arrowId, level) {
  const arrow = state.arrows.find(a => a.id === arrowId);
  if (!arrow) return { legal: false, reason: "That arrow is no longer on the board." };
  const blocker = blockerFor(state.arrows, arrowId, level.width, level.height);
  return blocker
    ? { legal: false, reason: `Blocked by the arrow at row ${blocker.y + 1}, column ${blocker.x + 1}.`, blockerId: blocker.id }
    : { legal: true };
}

export function removeArrow(state, arrowId, level) {
  const result = isMoveLegal(state, arrowId, level);
  if (!result.legal) return { state, ...result };
  return { state: { ...state, arrows: state.arrows.filter(a => a.id !== arrowId), moves: state.moves + 1 }, legal: true };
}

export function cloneState(state) {
  return { moves: state.moves, arrows: state.arrows.map(a => ({ ...a })) };
}

export function solveLevel(level, maxVisited = 150000) {
  const validation = validateLevel(level);
  if (!validation.valid) return { solvable: false, reason: validation.reason, sequence: [] };
  const initial = level.arrows.map((a, i) => ({ ...a, id: a.id ?? `a${i}` }));
  const memo = new Set();
  let visited = 0;
  function search(arrows, path) {
    if (!arrows.length) return path;
    if (++visited > maxVisited) return null;
    const key = arrows.map(a => a.id).sort().join("|");
    if (memo.has(key)) return null;
    memo.add(key);
    for (const a of arrows) {
      if (!blockerFor(arrows, a.id, level.width, level.height)) {
        const result = search(arrows.filter(x => x.id !== a.id), [...path, a.id]);
        if (result) return result;
      }
    }
    return null;
  }
  const sequence = search(initial, []);
  return { solvable: Boolean(sequence), sequence: sequence || [], visited, exhausted: visited > maxVisited };
}

export function findHint(state, level) {
  const solved = solveLevel({ ...level, arrows: state.arrows }, 50000);
  return solved.solvable ? solved.sequence[0] : null;
}
