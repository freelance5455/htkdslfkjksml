// Handcrafted levels. IDs and positions are deterministic.
export const LEVELS = [
  { id: 1, name: "First Flow", difficulty: "Easy", width: 4, height: 4, par: 4, arrows: [
    { id: "a", x: 0, y: 0, dir: "N" }, { id: "b", x: 0, y: 2, dir: "W" },
    { id: "c", x: 2, y: 2, dir: "E" }, { id: "d", x: 3, y: 3, dir: "S" }
  ]},
  { id: 2, name: "Crosswind", difficulty: "Easy", width: 4, height: 4, par: 5, arrows: [
    { id: "a", x: 1, y: 0, dir: "N" }, { id: "b", x: 1, y: 2, dir: "S" },
    { id: "c", x: 3, y: 2, dir: "E" }, { id: "d", x: 0, y: 3, dir: "W" },
    { id: "e", x: 3, y: 0, dir: "N" }
  ]},
  { id: 3, name: "Traffic", difficulty: "Easy", width: 5, height: 5, par: 6, arrows: [
    { id: "a", x: 0, y: 1, dir: "E" }, { id: "b", x: 2, y: 1, dir: "N" },
    { id: "c", x: 2, y: 3, dir: "S" }, { id: "d", x: 4, y: 3, dir: "E" },
    { id: "e", x: 1, y: 4, dir: "W" }, { id: "f", x: 4, y: 0, dir: "N" }
  ]},
  { id: 4, name: "Side Street", difficulty: "Medium", width: 5, height: 5, par: 7, arrows: [
    { id: "a", x: 0, y: 0, dir: "N" }, { id: "b", x: 0, y: 3, dir: "N" },
    { id: "c", x: 2, y: 3, dir: "N" }, { id: "d", x: 4, y: 3, dir: "W" },
    { id: "e", x: 3, y: 1, dir: "N" }, { id: "f", x: 3, y: 4, dir: "N" },
    { id: "g", x: 1, y: 1, dir: "E" }
  ]},
  { id: 5, name: "Green Lights", difficulty: "Medium", width: 5, height: 5, par: 8, arrows: [
    { id: "a", x: 0, y: 2, dir: "E" }, { id: "b", x: 2, y: 2, dir: "S" },
    { id: "c", x: 2, y: 4, dir: "W" }, { id: "d", x: 4, y: 4, dir: "S" },
    { id: "e", x: 4, y: 1, dir: "N" }, { id: "f", x: 1, y: 0, dir: "N" },
    { id: "g", x: 1, y: 3, dir: "W" }, { id: "h", x: 3, y: 0, dir: "N" }
  ]},
  { id: 6, name: "Quiet Corner", difficulty: "Medium", width: 5, height: 5, par: 8, arrows: [
    { id: "a", x: 0, y: 4, dir: "S" }, { id: "b", x: 0, y: 1, dir: "N" },
    { id: "c", x: 2, y: 1, dir: "E" }, { id: "d", x: 4, y: 1, dir: "N" },
    { id: "e", x: 4, y: 3, dir: "S" }, { id: "f", x: 2, y: 3, dir: "W" },
    { id: "g", x: 1, y: 2, dir: "W" }, { id: "h", x: 3, y: 4, dir: "S" }
  ]}
];
