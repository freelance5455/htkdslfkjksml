# মাসিক হিসাবের খাতা — Android APK Project

এটি আপনার দেওয়া বাংলা HTML মাসিক আয়-ব্যয় ট্র্যাকারকে Android WebView অ্যাপে প্যাকেজ করা প্রজেক্ট।

## ফিচার
- বাংলা UI
- আয় ও খরচ যোগ করা
- ক্যাটাগরি অনুযায়ী হিসাব
- মাস পরিবর্তন করে দেখা
- ব্যালেন্স গণনা
- এন্ট্রি মুছে ফেলা
- ফোনের localStorage-এ ডেটা সংরক্ষণ
- Professional app icon ও launch/splash screen
- Portrait orientation

## APK বানানো
Android Studio-তে `MonthlyHisabApp` ফোল্ডারটি Open করুন। Gradle sync শেষ হলে:
`Build > Build APK(s)`

APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ পাওয়া যাবে।
