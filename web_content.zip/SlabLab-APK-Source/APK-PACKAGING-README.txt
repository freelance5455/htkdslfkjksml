SlabLab APK Source Package
==========================

This ZIP is a prepared LOCAL WEB APP source package for an Android WebView/APK builder.
It is NOT a compiled APK.

Entry page: index.html
Core application files: app.js, engine.js, engine2.js, style.css
Local assets: fonts/ and icons/

Important:
- Choose a builder that imports a ZIP/folder of HTML, CSS, and JavaScript files and packages them as LOCAL assets inside the Android app.
- Do NOT choose a website-wrapper mode that simply opens the GitHub Pages URL.
- The service worker registration and PWA manifest link were removed from this local package because the APK should load its files locally.
- The calculation engines engine.js and engine2.js were not edited.
- Test the generated APK in airplane mode from the first launch before sharing it.
