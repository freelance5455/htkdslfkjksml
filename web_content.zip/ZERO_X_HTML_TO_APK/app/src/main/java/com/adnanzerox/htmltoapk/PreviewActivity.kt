package com.adnanzerox.htmltoapk
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
class PreviewActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val path=intent.getStringExtra("path") ?: run { finish(); return }
  val file=File(path)
  if(!file.exists()){ finish(); return }
  val web=WebView(this)
  web.settings.javaScriptEnabled=true
  web.settings.domStorageEnabled=true
  web.webViewClient=WebViewClient()
  setContentView(web)
  web.loadUrl("file://${file.absolutePath}")
 }
}
