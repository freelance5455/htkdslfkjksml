package com.adnanzerox.htmltoapk

import android.app.*
import androidx.appcompat.app.AppCompatActivity
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import org.json.JSONArray
import java.io.*
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {
    private val teal = 0xFF13A995.toInt()
    private val prefs by lazy { getSharedPreferences("zerox", MODE_PRIVATE) }
    private var selectedHtml: Uri? = null
    private var selectedZip: Uri? = null
    private var projectName = "MyWebApp"
    private var projectDir: File? = null
    private lateinit var root: LinearLayout
    private val htmlPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { selectedHtml = it; contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION); createFromHtml(it) }
    }
    private val zipPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { selectedZip = it; contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION); createFromZip(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        val outer = LinearLayout(this).apply { orientation = 1; setBackgroundColor(0xFFF1F5F4.toInt()) }
        val bar = LinearLayout(this).apply {
            orientation = 0; gravity = Gravity.CENTER_VERTICAL; setPadding(16, 14, 16, 14)
            setBackgroundColor(teal)
        }
        bar.addView(label("ZERO X", 21, 0xFFFFFFFF.toInt(), true), LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(button("Pro") { showPro() })
        bar.addView(button("⚙") { showSettings() })
        bar.addView(button("☰") { showMenu() })
        outer.addView(bar)
        val sc = ScrollView(this)
        root = LinearLayout(this).apply { orientation = 1; setPadding(16, 18, 16, 24) }
        sc.addView(root); outer.addView(sc)
        root.addView(label(title, 23, 0xFF173B36.toInt(), true))
        root.addView(label("تصميم وتطوير: عدنان زيرو إكس  •  Adnan Zero X", 12, 0xFF60736F.toInt()))
        return outer
    }

    private fun showHome() {
        val v = base("HTML to APK")
        root.addView(label("حوّل موقعك إلى تطبيق Android", 15, 0xFF55716B.toInt()))
        root.addView(card("🌐  ملف HTML إلى APK", "اختر ملف HTML وأرفق ملفات الموقع ثم جهّز مشروع Android") { htmlPicker.launch(arrayOf("text/html", "text/*", "application/octet-stream")) })
        root.addView(card("📦  ملف ZIP إلى APK", "استيراد مشروع كامل وفحص وجود index.html") { showZipPage() })
        root.addView(label("المزيد", 20, 0xFF173B36.toInt(), true))
        root.addView(card("📱  تطبيقاتي", "مشاريعك المحفوظة") { showProjects() })
        root.addView(card("⬇  التنزيلات", "ملفات المشاريع المصدّرة") { showDownloads() })
        root.addView(card("📘  طريقة الاستخدام", "خطوات التحويل ومتطلبات بناء APK") { showGuide() })
        root.addView(card("⭐  قيّمنا", "يسعدنا رأيك") { showRate() })
        root.addView(card("✉  تواصل مع المطور", "Adnan Zero X") { showContact() })
        root.addView(label("جميع الحقوق محفوظة © Adnan Zero X", 12, 0xFF6D817C.toInt()))
        setContentView(v)
    }

    private fun card(title: String, desc: String, action: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = 1; setPadding(18, 18, 18, 18); setBackgroundColor(0xFFE7F4F0.toInt())
            elevation = 3f
        }
        box.addView(label(title, 18, 0xFF087F73.toInt(), true))
        box.addView(label(desc, 13, 0xFF4F6862.toInt()))
        box.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 10, 0, 10)
        box.layoutParams = lp
        return box
    }
    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, 1); setPadding(2, 6, 2, 6); textDirection = View.TEXT_DIRECTION_FIRST_STRONG_RTL }
    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; textSize = 12f; setTextColor(0xFFFFFFFF.toInt()); setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF087F73.toInt()))
        setOnClickListener { action() }
    }
    private fun heading(s: String) { root.addView(label(s, 19, 0xFF087F73.toInt(), true)) }
    private fun showMenu() {
        AlertDialog.Builder(this).setTitle("القائمة").setItems(arrayOf("الرئيسية","تطبيقاتي","التنزيلات","طريقة الاستخدام","Pro","الإعدادات","تواصل مع المطور","حول التطبيق")) { _, n ->
            when(n){0->showHome();1->showProjects();2->showDownloads();3->showGuide();4->showPro();5->showSettings();6->showContact();7->showAbout()}
        }.show()
    }
    private fun showZipPage() {
        val v = base("ZIP إلى APK")
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(label("▣", 88, 0xFF176B3A.toInt(), true))
        root.addView(label("تحديد ملف ZIP", 23, 0xFF17212B.toInt(), true))
        root.addView(label("اختر ملف ZIP (موقع ويب) من وحدة التخزين", 15, 0xFF68736F.toInt()))
        root.addView(label("الحد الأقصى 5 ميغابايت", 15, 0xFF43534F.toInt(), true))
        root.addView(label("تتوفر سعة أكبر ضمن Pro عند تفعيلها في إصدار مدفوع فعلي.", 13, 0xFFB17A32.toInt()))
        root.addView(card("اختيار ملف ZIP", "تصفح ملفات الجهاز وحدد أرشيف المشروع") {
            zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*"))
        })
        root.addView(card("ما الذي يجب أن يحتويه الملف؟", "يجب أن يتضمن index.html في الجذر أو داخل مجلد واحد") {
            AlertDialog.Builder(this).setTitle("مساعدة ملفات ZIP")
                .setMessage("ضع index.html مع ملفات CSS وJavaScript والصور والخطوط في مجلد المشروع، ثم اضغط اختيار ملف ZIP. سيتم استخراج الملفات وفحص الصفحة الرئيسية.")
                .setPositiveButton("حسناً", null).show()
        })
        setContentView(v)
    }

    private fun createFromHtml(uri: Uri) {
        val dir = newProject()
        val name = queryName(uri) ?: "index.html"
        val target = File(dir, safeName(name))
        contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { input.copyTo(it) } }
        finishImport(dir)
    }
    private fun createFromZip(uri: Uri) {
        val dir = newProject()
        try {
            contentResolver.openInputStream(uri)?.use { raw ->
                ZipInputStream(BufferedInputStream(raw)).use { zip ->
                    var entry = zip.nextEntry
                    var count = 0
                    while (entry != null) {
                        if (++count > 3000) throw IOException("عدد الملفات يتجاوز الحد المسموح")
                        val out = File(dir, entry.name).canonicalFile
                        if (!out.path.startsWith(dir.canonicalPath + File.separator) && out != dir) throw IOException("مسار ZIP غير آمن")
                        if (entry.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            out.outputStream().use { zip.copyTo(it) }
                        }
                        zip.closeEntry(); entry = zip.nextEntry
                    }
                }
            }
            finishImport(dir)
        } catch (e: Exception) {
            dir.deleteRecursively()
            AlertDialog.Builder(this).setMessage("تعذّر استخراج الملف: ${e.message}").setPositiveButton("حسناً", null).show()
        }
    }
    private fun newProject(): File {
        val d = File(filesDir, "projects/${System.currentTimeMillis()}")
        d.mkdirs(); projectDir = d; return d
    }
    private fun finishImport(dir: File) {
        val html = findIndex(dir)
        if (html == null) {
            AlertDialog.Builder(this).setTitle("تحديد ملف ZIP")
                .setMessage("لم يتم العثور على index.html في ملف ZIP هذا. أضف index.html في جذر الأرشيف (أو داخل مجلد واحد بالمستوى الأعلى) ثم حاول مرة أخرى.")
                .setPositiveButton("حسناً", null).show()
            return
        }
        projectName = "MyWebApp"
        prefs.edit().putString("lastProject", dir.absolutePath).putString("lastName", projectName).apply()
        showProjectDetails(dir, html)
    }
    private fun findIndex(dir: File): File? = dir.walkTopDown().firstOrNull { it.isFile && it.name.equals("index.html", true) }
    private fun showProjectDetails(dir: File, html: File) {
        val v = base("إعداد المشروع")
        root.addView(label("تم استيراد المشروع وفحص ملف index.html.", 15, 0xFF315D54.toInt()))
        val name = EditText(this).apply { hint = "اسم التطبيق"; setText(projectName) }
        root.addView(name)
        val pkg = EditText(this).apply { hint = "Package Name"; setText("com.adnanzerox.mywebapp") }
        root.addView(pkg)
        root.addView(card("معاينة الموقع", "فتح الصفحة داخل WebView") {
            startActivity(Intent(this, PreviewActivity::class.java).putExtra("path", html.absolutePath))
        })
        root.addView(label("الملفات: ${dir.walkTopDown().count { it.isFile }}", 14, 0xFF315D54.toInt()))
        root.addView(button("تجهيز مشروع Android وتصديره") {
            val appName = name.text.toString().trim().ifBlank { "MyWebApp" }
            val packageName = pkg.text.toString().trim()
            if (!packageName.matches(Regex("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+"))) {
                Toast.makeText(this, "اسم الحزمة غير صالح", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit().putString("lastName", appName).putString("lastPackage", packageName).apply()
                exportAndroidProject(dir, html, appName, packageName)
            }
        })
        setContentView(v)
    }
    private fun exportAndroidProject(source: File, html: File, appName: String, packageName: String) {
        val out = File(getExternalFilesDir(null), "ZEROX_${System.currentTimeMillis()}")
        val assets = File(out, "app/src/main/assets/site"); assets.mkdirs()
        source.copyRecursively(assets, overwrite = true)
        val pkgPath = packageName.replace('.', '/')
        val javaDir = File(out, "app/src/main/java/$pkgPath"); javaDir.mkdirs()
        File(javaDir, "MainActivity.kt").writeText(generatedActivity(packageName, appName, html.relativeTo(source).invariantSeparatorsPath))
        File(out, "settings.gradle.kts").writeText("pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }; dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }; rootProject.name = \"${appName.replace("\"","")}\"; include(\":app\")")
        File(out, "build.gradle.kts").writeText("plugins { id(\"com.android.application\") version \"8.7.3\" apply false; id(\"org.jetbrains.kotlin.android\") version \"2.0.21\" apply false }")
        File(out, "gradle.properties").writeText("org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8\\nandroid.useAndroidX=true\\nkotlin.code.style=official")
        File(out, "app/build.gradle.kts").writeText("""
plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "$packageName"; compileSdk = 35
 defaultConfig { applicationId = "$packageName"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0.0" }
}
""".trimIndent())
        File(out, "app/src/main/AndroidManifest.xml").writeText("""<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:label="${appName.replace("&","&amp;").replace("\"","&quot;")}" android:theme="@android:style/Theme.Material.Light.NoActionBar" android:usesCleartextTraffic="true"><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>""")
        val zip = File(getExternalFilesDir(null), "${safeName(appName)}_Android_Project.zip")
        zipDirectory(out, zip)
        val downloads = File(filesDir, "downloads"); downloads.mkdirs()
        zip.copyTo(File(downloads, zip.name), true)
        val share = Intent(Intent.ACTION_SEND).apply { type = "application/zip"; putExtra(Intent.EXTRA_STREAM, uriFor(zip)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        AlertDialog.Builder(this).setTitle("تم تجهيز المصدر").setMessage("تم حفظ مشروع Android في:\n${zip.absolutePath}\n\nافتحه باستخدام Android Studio ثم نفّذ Build > Build APK(s). يتطلب البناء Android SDK وGradle واتصالاً لتنزيل الاعتماديات أول مرة.").setPositiveButton("مشاركة ZIP") { _, _ -> startActivity(Intent.createChooser(share, "مشاركة المشروع")) }.setNegativeButton("إغلاق", null).show()
    }
    private fun generatedActivity(pkg: String, app: String, htmlPath: String) = """
package $pkg
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
class MainActivity : AppCompatActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val web = WebView(this); web.settings.javaScriptEnabled = true; web.settings.domStorageEnabled = true
  web.webViewClient = WebViewClient(); setContentView(web); web.loadUrl("file:///android_asset/site/$htmlPath")
 }
}
""".trimIndent()
    private fun zipDirectory(dir: File, zip: File) {
        java.util.zip.ZipOutputStream(BufferedOutputStream(zip.outputStream())).use { out ->
            dir.walkTopDown().filter { it.isFile }.forEach { f ->
                val rel = f.relativeTo(dir).invariantSeparatorsPath
                out.putNextEntry(java.util.zip.ZipEntry(rel)); f.inputStream().use { it.copyTo(out) }; out.closeEntry()
            }
        }
    }
    private fun uriFor(f: File): Uri = FileProvider.getUriForFile(this, "$packageName.provider", f)
    private fun safeName(s: String) = s.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "file" }
    private fun queryName(uri: Uri): String? = uri.lastPathSegment?.substringAfterLast(':')
    private fun showProjects() {
        val v=base("تطبيقاتي")
        val d=File(filesDir,"projects")
        val projects=d.listFiles()?.sortedByDescending{it.lastModified()}.orEmpty()
        if(projects.isEmpty()) root.addView(label("لا توجد مشاريع محفوظة بعد.",15,0xFF55716B.toInt()))
        projects.forEach { p -> root.addView(card(p.name,"عدد الملفات: ${p.walkTopDown().count{it.isFile}}") {
            val index=findIndex(p)
            if(index!=null) showProjectDetails(p,index) else Toast.makeText(this,"لم يتم العثور على index.html",Toast.LENGTH_SHORT).show()
        }) }
        setContentView(v)
    }
    private fun showDownloads() {
        val v=base("التنزيلات")
        val d=File(filesDir,"downloads"); val list=d.listFiles().orEmpty()
        if(list.isEmpty()) root.addView(label("لا توجد ملفات تنزيل.",15,0xFF55716B.toInt()))
        list.forEach { f -> root.addView(card(f.name,"${f.length()/1024} KB") {
            val send=Intent(Intent.ACTION_SEND).apply { type="application/zip"; putExtra(Intent.EXTRA_STREAM,uriFor(f)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(Intent.createChooser(send,"مشاركة الملف"))
        }) }
        setContentView(v)
    }
    private fun showGuide(){ val v=base("طريقة الاستخدام"); listOf("1. اختر ملف HTML أو مشروع ZIP.","2. في ZIP يجب وجود index.html ضمن الملفات.","3. راجع اسم التطبيق واسم الحزمة ثم عاين الموقع.","4. صدّر مشروع Android بصيغة ZIP.","5. افتح المصدر في Android Studio وابنِ APK من Build > Build APK(s).","ملاحظة: التطبيق يجهّز مشروعاً حقيقياً؛ لا يدّعي تجميع APK على الهاتف. يتطلب إخراج APK وجود Android SDK وGradle.").forEach{root.addView(label(it,15,0xFF315D54.toInt()))}; setContentView(v) }
    private fun showPro(){ val v=base("ZERO X Pro"); root.addView(label("مزايا قيد التطوير — لا يوجد دفع أو اشتراك وهمي.",15,0xFF315D54.toInt())); listOf("قوالب إضافية","تخصيص متقدم لشاشة البداية","إعدادات متقدمة للتطبيقات","إدارة مشاريع متعددة").forEach{root.addView(card("✦ $it","ميزة مخطط لها"){})}; setContentView(v) }
    private fun showSettings(){ val v=base("الإعدادات"); root.addView(card("اللغة","العربية (واجهة RTL)"){}); root.addView(card("المظهر","الوضع الفاتح حالياً"){}); root.addView(label("تصميم وتطوير: عدنان زيرو إكس\nDesigned & Developed by Adnan Zero X\nجميع الحقوق محفوظة © Adnan Zero X",14,0xFF315D54.toInt())); setContentView(v) }
    private fun showContact(){ val v=base("تواصل مع المطور"); root.addView(label("عدنان زيرو إكس\nAdnan Zero X\n+967782639459",17,0xFF315D54.toInt())); root.addView(button("واتساب"){ open("https://wa.me/967782639459") }); root.addView(button("اتصال"){ startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:+967782639459"))) }); setContentView(v) }
    private fun showRate(){ AlertDialog.Builder(this).setMessage("شكراً لدعمك! ستتوفر صفحة المتجر بعد نشر التطبيق.").setPositiveButton("حسناً",null).show() }
    private fun showAbout(){ val v=base("حول التطبيق"); root.addView(label("ZERO X – HTML TO APK\nتصميم وتطوير: عدنان زيرو إكس\nDesigned & Developed by Adnan Zero X\nجميع الحقوق محفوظة © Adnan Zero X",16,0xFF315D54.toInt())); setContentView(v) }
    private fun open(url:String){ startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url))) }
}
