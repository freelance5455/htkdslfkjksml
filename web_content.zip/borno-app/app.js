const V=[["অ","অজগর","🐍"],["আ","আম","🥭"],["ই","ইঁদুর","🐭"],["ঈ","ঈগল","🦅"],["উ","উট","🐪"],["ঊ","ঊষা","🌅"],["ঋ","ঋষি","🧘"],["এ","একতারা","🪕"],["ঐ","ঐরাবত","🐘"],["ও","ওড়না","🧣"],["ঔ","ঔষধ","💊"]];
const C=[["ক","কলা","🍌"],["খ","খরগোশ","🐰"],["গ","গরু","🐄"],["ঘ","ঘড়ি","⏰"],["ঙ","ব্যাঙ","🐸"],
["চ","চাঁদ","🌙"],["ছ","ছাতা","☂️"],["জ","জাহাজ","🚢"],["ঝ","ঝিনুক","🐚"],["ঞ","মিঞা","🧔"],
["ট","টাকা","💵"],["ঠ","ঠোঁট","👄"],["ড","ডিম","🥚"],["ঢ","ঢাক","🥁"],["ণ","ঘণ্টা","🔔"],
["ত","তারা","⭐"],["থ","থালা","🍽️"],["দ","দাঁত","🦷"],["ধ","ধান","🌾"],["ন","নৌকা","⛵"],
["প","পাখি","🐦"],["ফ","ফুল","🌸"],["ব","বই","📖"],["ভ","ভাত","🍚"],["ম","মাছ","🐟"],
["য","যমুনা","🌊"],["র","রাজা","👑"],["ল","লেবু","🍋"],["শ","শাপলা","🪷"],["ষ","ষাঁড়","🐂"],
["স","সূর্য","☀️"],["হ","হাতি","🐘"],["ড়","ঘুড়ি","🪁"],["ঢ়","আষাঢ়","🌧️"],["য়","ময়ূর","🦚"],
["ৎ","উৎসব","🎉"],["ং","বাংলা","🇧🇩"],["ঃ","দুঃখ","😢"],["ঁ","চাঁদ","🌙"]];
const MARKS="ংঃঁ";
const show=l=>MARKS.includes(l)?"\u25CC"+l:l;
const $=s=>document.querySelector(s), main=$("#main"), dlg=$("#card"), pad=$("#pad"), ctx=pad.getContext("2d");
let tab="v", list=V, idx=0, seen=new Set(JSON.parse(localStorage.getItem("seen")||"[]"));
const bn=n=>n.toLocaleString("bn-BD");

function say(t){
  try{
    const s=window.speechSynthesis; if(!s) return; s.cancel();
    const u=new SpeechSynthesisUtterance(t); u.lang="bn-BD"; u.rate=.8;
    const v=s.getVoices().find(v=>v.lang.toLowerCase().startsWith("bn")); if(v) u.voice=v;
    s.speak(u);
  }catch(e){}
}
function progress(){ $("#progress").textContent=bn(seen.size)+"/"+bn(V.length+C.length)+" অক্ষর শেখা হয়েছে"; }

function setTab(t){
  tab=t; list=t==="v"?V:C;
  document.querySelectorAll("nav button").forEach(b=>b.setAttribute("aria-selected",b.dataset.tab===t));
  t==="q"?startQuiz():renderGrid();
}
function renderGrid(){
  main.innerHTML='<div class="grid"></div>';
  const g=main.firstChild;
  list.forEach((it,i)=>{
    const b=document.createElement("button");
    b.className="tile"+(seen.has(it[0])?" seen":"");
    b.textContent=show(it[0]); b.setAttribute("aria-label",it[0]+", "+it[1]);
    b.onclick=()=>openCard(i); g.appendChild(b);
  });
}

/* ---- letter card + tracing ---- */
function openCard(i){
  idx=(i+list.length)%list.length;
  const [l,w,e]=list[idx];
  $("#cLetter").textContent=show(l); $("#cWord").textContent=w; $("#cEmoji").textContent=e;
  if(!dlg.open) dlg.showModal();
  sizePad(); say(l+". "+w);
  if(!seen.has(l)){ seen.add(l); localStorage.setItem("seen",JSON.stringify([...seen])); progress(); if(tab!=="q") renderGrid(); }
}
function sizePad(){
  const r=pad.getBoundingClientRect(), d=window.devicePixelRatio||1;
  pad.width=r.width*d; pad.height=r.height*d; ctx.setTransform(d,0,0,d,0,0); guide();
}
function guide(){
  const s=pad.getBoundingClientRect().width;
  ctx.clearRect(0,0,s,s); ctx.fillStyle="#d8ece9"; ctx.textAlign="center"; ctx.textBaseline="middle";
  ctx.font="800 "+(s*.7)+"px "+getComputedStyle(document.body).fontFamily;
  ctx.fillText(show(list[idx][0]),s/2,s/2+s*.04);
}
let drawing=false;
const pos=e=>{const r=pad.getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top]};
pad.addEventListener("pointerdown",e=>{drawing=true;pad.setPointerCapture(e.pointerId);const[x,y]=pos(e);
  ctx.strokeStyle="#E63E8B";ctx.lineWidth=14;ctx.lineCap=ctx.lineJoin="round";ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+.01,y);ctx.stroke();});
pad.addEventListener("pointermove",e=>{if(!drawing)return;const[x,y]=pos(e);ctx.lineTo(x,y);ctx.stroke();});
["pointerup","pointercancel"].forEach(t=>pad.addEventListener(t,()=>drawing=false));
$("#clear").onclick=guide;
$("#listen").onclick=()=>say(list[idx][0]+". "+list[idx][1]);
$("#prev").onclick=()=>openCard(idx-1);
$("#next").onclick=()=>openCard(idx+1);
$("#closeCard").onclick=()=>dlg.close();
dlg.addEventListener("click",e=>{if(e.target===dlg)dlg.close()});

/* ---- quiz ---- */
let q;
function startQuiz(){ q={n:0,score:0,pool:[...V,...C].sort(()=>Math.random()-.5).slice(0,10)}; nextQ(); }
function nextQ(){
  if(q.n>=q.pool.length){
    const best=Math.max(q.score,+localStorage.getItem("best")||0); localStorage.setItem("best",best);
    const msg=q.score>=8?"চমৎকার! 🎉":q.score>=5?"খুব ভালো! 👏":"আবার চেষ্টা করি 💪";
    main.innerHTML='<div class="quiz"><div class="big">'+msg+'</div><div class="qletter">'+"⭐".repeat(Math.max(1,Math.round(q.score/2)))+
      '</div><p class="big">'+bn(q.score)+'/'+bn(q.pool.length)+' সঠিক</p><button class="again">আবার খেলি</button></div>';
    main.querySelector(".again").onclick=startQuiz; return;
  }
  const [l,w,e]=q.pool[q.n]; q.tries=0;
  const wrong=[...V,...C].filter(x=>!x[1].includes(l)&&x[2]!==e).sort(()=>Math.random()-.5).slice(0,3);
  const opts=[[l,w,e],...wrong].sort(()=>Math.random()-.5);
  main.innerHTML='<div class="quiz"><div class="qstat">প্রশ্ন '+bn(q.n+1)+'/'+bn(q.pool.length)+' · ⭐ '+bn(q.score)+
    '</div><div class="qletter">'+show(l)+'</div><p class="qask">কোন ছবির নামে এই অক্ষর আছে?</p><div class="opts"></div></div>';
  const box=main.querySelector(".opts");
  opts.forEach(o=>{
    const b=document.createElement("button"); b.className="opt"; b.textContent=o[2]; b.setAttribute("aria-label",o[1]);
    b.onclick=()=>{
      if(o[2]===e){ b.classList.add("ok"); if(!q.tries) q.score++; say(l+". "+w); box.querySelectorAll("button").forEach(x=>x.disabled=true); q.n++; setTimeout(nextQ,1200); }
      else { b.classList.add("no"); q.tries++; b.disabled=true; }
    };
    box.appendChild(b);
  });
}

document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
window.addEventListener("resize",()=>{if(dlg.open)sizePad()});
if("speechSynthesis" in window) speechSynthesis.getVoices();
progress(); setTab("v");
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("sw.js");
