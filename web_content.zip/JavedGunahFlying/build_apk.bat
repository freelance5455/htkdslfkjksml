@echo off
echo Building Javed Gunah Flying APK...
call gradlew.bat assembleDebug
if %ERRORLEVEL% EQU 0 (
    echo ================================================
    echo SUCCESS! APK built at: app\build\outputs\apk\debug\app-debug.apk
    echo ================================================
) else (
    echo Build failed. Please verify Android SDK is configured.
)
pause
