# Javed Gunah Flying - Android Studio Project

Official offline Android game inspired by Flappy Bird, featuring Javed Gunah and custom flying characters.

## Features
- **Target OS**: Android 8.0 (API 26) through Android 14+ (API 34)
- **Zero Permissions**: 100% Offline, no internet or accounts required
- **Icon**: Official Gunah 9999+ logo in all mipmap densities
- **Characters**: 4 high-res transparent right-facing characters
- **Engine**: Accelerated hardware canvas with smooth physics and score tracking

## Building the APK (Direct & Simple)

### Option 1: Using Android Studio (Recommended)
1. Open **Android Studio**.
2. Select **File > Open** and choose this unzipped folder (`JavedGunahFlying`).
3. Wait for Gradle sync to finish (all dependencies are standard AndroidX).
4. Connect your Android phone (or start an emulator) and click the green **Run (▶)** button!
5. To generate a shareable APK: Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

### Option 2: Command Line (Linux / Mac / Windows)
```bash
# On Mac/Linux:
./gradlew assembleDebug

# On Windows:
gradlew.bat assembleDebug
```
Your installable APK will be created at:
`app/build/outputs/apk/debug/app-debug.apk`
