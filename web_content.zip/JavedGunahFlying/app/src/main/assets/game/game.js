// Javed Gunah Flying - Offline Android Canvas Engine
(function() {
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    
    let width = 360;
    let height = 640;
    
    function resize() {
        const dpr = window.devicePixelRatio || 1;
        canvas.width = window.innerWidth * dpr;
        canvas.height = window.innerHeight * dpr;
        ctx.scale(dpr, dpr);
        width = window.innerWidth;
        height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();

    // Characters
    const characters = [
        { id: 'char1', name: 'Speedy Javed', src: 'characters/character_1.png' },
        { id: 'char2', name: 'Classic Javed', src: 'characters/character_2.png' },
        { id: 'char3', name: 'Golden Scarf Javed', src: 'characters/character_3.png' },
        { id: 'char_king', name: 'King Gunah 9999+', src: 'characters/character_king.png' }
    ];

    let selectedCharIndex = 0;
    let images = {};
    characters.forEach(c => {
        const img = new Image();
        img.src = c.src;
        images[c.id] = img;
    });

    const logoImg = new Image();
    logoImg.src = 'characters/logo.png';

    // Game state
    let state = 'menu'; // menu, playing, gameover
    let score = 0;
    let highScore = 0;
    try {
        highScore = parseInt(localStorage.getItem('javed_high_score') || '0', 10);
    } catch(e) {}

    let bird = { x: 80, y: 250, v: 0, r: 20, rot: 0 };
    let pipes = [];
    let pipeSpawnTimer = 0;
    const gravity = 0.38;
    const jump = -7.2;

    function reset() {
        bird = { x: width * 0.25, y: height * 0.4, v: 0, r: 22, rot: 0 };
        pipes = [];
        score = 0;
        pipeSpawnTimer = 0;
    }

    function flap() {
        if (state === 'menu') {
            state = 'playing';
            reset();
            bird.v = jump;
        } else if (state === 'playing') {
            bird.v = jump;
        } else if (state === 'gameover') {
            state = 'menu';
        }
    }

    window.addEventListener('pointerdown', (e) => {
        // If on menu, check character selection taps
        if (state === 'menu') {
            const tapY = e.clientY;
            if (tapY > height * 0.65 && tapY < height * 0.85) {
                const tapX = e.clientX;
                const slotWidth = width / characters.length;
                selectedCharIndex = Math.floor(tapX / slotWidth);
                selectedCharIndex = Math.max(0, Math.min(characters.length - 1, selectedCharIndex));
                return;
            }
        }
        flap();
    });

    function loop() {
        update();
        render();
        requestAnimationFrame(loop);
    }

    function update() {
        if (state === 'playing') {
            bird.v += gravity;
            bird.y += bird.v;
            bird.rot = Math.min(Math.PI / 3, Math.max(-Math.PI / 4, bird.v * 0.08));

            // Pipe spawning
            pipeSpawnTimer++;
            if (pipeSpawnTimer > 95) {
                pipeSpawnTimer = 0;
                const gap = 150;
                const minH = 80;
                const groundH = 90;
                const maxH = height - groundH - gap - minH;
                const topH = minH + Math.random() * (maxH - minH);
                pipes.push({
                    x: width,
                    top: topH,
                    bottom: height - groundH - (topH + gap),
                    gap: gap,
                    passed: false
                });
            }

            // Move pipes
            for (let i = pipes.length - 1; i >= 0; i--) {
                const p = pipes[i];
                p.x -= 2.6;

                // Score check
                if (!p.passed && bird.x > p.x + 60) {
                    p.passed = true;
                    score++;
                    if (score > highScore) {
                        highScore = score;
                        try { localStorage.setItem('javed_high_score', highScore.toString()); } catch(e){}
                    }
                }

                // Collision
                const pipeW = 60;
                const groundY = height - 90;
                if (bird.x + bird.r > p.x && bird.x - bird.r < p.x + pipeW) {
                    if (bird.y - bird.r < p.top || bird.y + bird.r > p.top + p.gap) {
                        state = 'gameover';
                    }
                }

                if (p.x < -80) {
                    pipes.splice(i, 1);
                }
            }

            // Ground collision
            if (bird.y + bird.r >= height - 90) {
                bird.y = height - 90 - bird.r;
                state = 'gameover';
            }
        }
    }

    function render() {
        ctx.clearRect(0, 0, width, height);

        // Sky gradient
        const sky = ctx.createLinearGradient(0, 0, 0, height);
        sky.addColorStop(0, '#38bdf8');
        sky.addColorStop(0.7, '#bae6fd');
        sky.addColorStop(1, '#fef08a');
        ctx.fillStyle = sky;
        ctx.fillRect(0, 0, width, height);

        // Clouds & Hills
        ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
        ctx.beginPath();
        ctx.arc(60, 100, 35, 0, Math.PI * 2);
        ctx.arc(100, 95, 45, 0, Math.PI * 2);
        ctx.arc(140, 100, 35, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#86efac';
        ctx.beginPath();
        ctx.ellipse(width * 0.3, height - 90, width * 0.4, 70, 0, 0, Math.PI * 2);
        ctx.fill();

        // Pipes
        pipes.forEach(p => {
            const pipeW = 60;
            // Top pipe
            const topGrad = ctx.createLinearGradient(p.x, 0, p.x + pipeW, 0);
            topGrad.addColorStop(0, '#22c55e');
            topGrad.addColorStop(0.5, '#4ade80');
            topGrad.addColorStop(1, '#15803d');
            ctx.fillStyle = topGrad;
            ctx.fillRect(p.x, 0, pipeW, p.top);
            // Cap
            ctx.fillStyle = '#16a34a';
            ctx.fillRect(p.x - 4, p.top - 24, pipeW + 8, 24);

            // Bottom pipe
            const bottomY = p.top + p.gap;
            const bottomH = height - 90 - bottomY;
            ctx.fillStyle = topGrad;
            ctx.fillRect(p.x, bottomY, pipeW, bottomH);
            ctx.fillStyle = '#16a34a';
            ctx.fillRect(p.x - 4, bottomY, pipeW + 8, 24);
        });

        // Ground
        ctx.fillStyle = '#d97706';
        ctx.fillRect(0, height - 90, width, 90);
        ctx.fillStyle = '#65a30d';
        ctx.fillRect(0, height - 90, width, 16);

        // Bird
        const char = characters[selectedCharIndex];
        const img = images[char.id];
        ctx.save();
        ctx.translate(bird.x, bird.y);
        ctx.rotate(bird.rot);
        if (img && img.complete) {
            ctx.drawImage(img, -28, -28, 56, 56);
        } else {
            ctx.fillStyle = '#eab308';
            ctx.beginPath();
            ctx.arc(0, 0, bird.r, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();

        // HUD / Screens
        if (state === 'menu') {
            if (logoImg.complete) {
                ctx.drawImage(logoImg, width / 2 - 70, height * 0.12, 140, 140);
            }
            ctx.fillStyle = '#0f172a';
            ctx.font = 'bold 26px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('JAVED GUNAH FLYING', width / 2, height * 0.40);

            ctx.fillStyle = '#0369a1';
            ctx.font = 'bold 16px sans-serif';
            ctx.fillText('TAP TO PLAY', width / 2, height * 0.46);

            // Character picker preview
            ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
            ctx.font = '13px sans-serif';
            ctx.fillText('SELECT CHARACTER:', width / 2, height * 0.64);

            characters.forEach((c, idx) => {
                const slotW = width / characters.length;
                const cx = slotW * (idx + 0.5);
                const cy = height * 0.74;
                if (idx === selectedCharIndex) {
                    ctx.fillStyle = '#facc15';
                    ctx.beginPath();
                    ctx.arc(cx, cy, 32, 0, Math.PI * 2);
                    ctx.fill();
                }
                const cImg = images[c.id];
                if (cImg && cImg.complete) {
                    ctx.drawImage(cImg, cx - 24, cy - 24, 48, 48);
                }
            });
        } else if (state === 'playing') {
            ctx.fillStyle = '#ffffff';
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 4;
            ctx.font = 'bold 44px sans-serif';
            ctx.textAlign = 'center';
            ctx.strokeText(score.toString(), width / 2, 70);
            ctx.fillText(score.toString(), width / 2, 70);
        } else if (state === 'gameover') {
            ctx.fillStyle = 'rgba(0,0,0,0.45)';
            ctx.fillRect(0, 0, width, height);

            ctx.fillStyle = '#ef4444';
            ctx.font = 'bold 36px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('GAME OVER', width / 2, height * 0.35);

            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 22px sans-serif';
            ctx.fillText('SCORE: ' + score, width / 2, height * 0.44);
            ctx.fillText('BEST: ' + highScore, width / 2, height * 0.50);

            ctx.fillStyle = '#fbbf24';
            ctx.font = 'bold 18px sans-serif';
            ctx.fillText('TAP TO RESTART', width / 2, height * 0.62);
        }
    }

    loop();
})();
