#!/bin/bash
echo "Building Javed Gunah Flying APK..."
./gradlew assembleDebug
if [ $? -eq 0 ]; then
    echo "================================================"
    echo "SUCCESS! APK built at: app/build/outputs/apk/debug/app-debug.apk"
    echo "================================================"
else
    echo "Build failed. Please verify Android SDK is configured in ANDROID_HOME."
fi
