plugins { id("com.android.application") }

android { namespace = "com.repairshop.web"; compileSdk = 35
    defaultConfig { applicationId = "com.repairshop.web"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
