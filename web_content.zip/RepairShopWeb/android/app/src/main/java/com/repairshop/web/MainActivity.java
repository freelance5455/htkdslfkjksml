package com.repairshop.web;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 42;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.setBackgroundColor(0xFF070707);
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                if(fileCallback!=null) fileCallback.onReceiveValue(null); fileCallback=cb;
                try { startActivityForResult(p.createIntent(), FILE_REQUEST); } catch(Exception e){ fileCallback=null; return false; } return true;
            }
        });
        web.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{
            Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(url)); try{startActivity(i);}catch(Exception e){Toast.makeText(this,"تعذر فتح الملف",Toast.LENGTH_SHORT).show();}
        });
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        if(req==FILE_REQUEST){ if(fileCallback!=null){ Uri[] r=null; if(result==RESULT_OK&&data!=null){ if(data.getData()!=null) r=new Uri[]{data.getData()}; else if(data.getClipData()!=null){int n=data.getClipData().getItemCount();r=new Uri[n];for(int i=0;i<n;i++)r[i]=data.getClipData().getItemAt(i).getUri();}} fileCallback.onReceiveValue(r); fileCallback=null;} return; }
        super.onActivityResult(req,result,data);
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
