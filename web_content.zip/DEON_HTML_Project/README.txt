DEON HTML PROJECT
=================

Contents
- index.html: single-page DEON mobile interface
- assets/deon-icon.svg: simple gold-bar icon concept

How to make an APK
1. Extract this ZIP on your Android phone.
2. Open your HTML-to-APK app.
3. Choose the extracted index.html as the start page / local HTML file.
4. Set the app name to DEON and, if supported, use assets/deon-icon.svg as the icon.
5. Build the APK.

Passkey: ALDRINE

Important limitations
This is the HTML mobile shell/prototype: passkey screen, DEON branding, XAUUSD layout,
and buy/sell/both mode selector. It does NOT connect to Exness or MetaTrader 5 and
does not execute trades. An HTML-to-APK wrapper cannot directly run an MT5 Expert
Advisor. Real market data and trading require a secure bridge/service connected to
your Exness MT5 terminal, plus proper testing and risk controls.

Security note
The passkey is stored in the HTML/JavaScript and can be inspected by someone who
extracts the APK. Do not use this client-side passkey as strong authentication for
real trading or store broker credentials in this project.
