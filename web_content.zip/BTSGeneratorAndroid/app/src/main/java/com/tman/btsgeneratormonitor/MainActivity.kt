package com.tman.btsgeneratormonitor

import android.app.Activity
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.content.ContentValues
import android.webkit.DownloadListener
import android.widget.Toast
import android.graphics.Bitmap
import android.util.Base64
import java.io.OutputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.setSupportZoom(false)
        CookieManager.getInstance().setAcceptCookie(true)
        webView.addJavascriptInterface(AppBridge(), "AndroidApp")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                return try { startActivityForResult(intent, fileRequest); true } catch (_: Exception) { fileCallback = null; false }
            }
        }
        webView.setDownloadListener(DownloadListener { url, _, contentDisposition, mimeType, _ ->
            try {
                val name = if (contentDisposition?.contains(".csv") == true) "bts-generator-sites.csv" else "bts-generator-backup.json"
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = mimeType ?: "application/octet-stream"
                    putExtra(Intent.EXTRA_TITLE, name)
                }
                pendingDownload = url
                startActivityForResult(intent, 1002)
            } catch (_: Exception) { Toast.makeText(this, "تعذر حفظ الملف", Toast.LENGTH_LONG).show() }
        })
        webView.loadUrl("file:///android_asset/index.html")
    }

    private var pendingDownload: String? = null
    private var pendingBackupJson: String? = null
    private val backupRequest = 1003

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequest) {
            val result = if (resultCode == Activity.RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        } else if (requestCode == 1002 && resultCode == Activity.RESULT_OK && data?.data != null) {
            val url = pendingDownload
            if (url != null) {
                try {
                    val base64 = url.substringAfter("base64,", "")
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    contentResolver.openOutputStream(data.data!!)?.use { it.write(bytes) }
                    Toast.makeText(this, "تم حفظ الملف", Toast.LENGTH_LONG).show()
                } catch (_: Exception) { Toast.makeText(this, "تعذر حفظ الملف", Toast.LENGTH_LONG).show() }
            }
            pendingDownload = null
        } else if (requestCode == backupRequest) {
            val json = pendingBackupJson
            if (resultCode == Activity.RESULT_OK && data?.data != null && json != null) {
                try {
                    contentResolver.openOutputStream(data.data!!)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(json) }
                    Toast.makeText(this, "تم حفظ النسخة الاحتياطية بنجاح", Toast.LENGTH_LONG).show()
                } catch (_: Exception) { Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show() }
            }
            pendingBackupJson = null
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    inner class AppBridge {
        @JavascriptInterface fun appName(): String = "BTS Generator Monitor"

        @JavascriptInterface fun saveBackup(json: String) {
            runOnUiThread {
                try {
                    pendingBackupJson = json
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, "bts-generator-backup.json")
                    }
                    startActivityForResult(intent, backupRequest)
                } catch (_: Exception) {
                    pendingBackupJson = null
                    Toast.makeText(this@MainActivity, "تعذر فتح نافذة حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
