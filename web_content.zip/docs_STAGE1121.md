# Stage 1121 — Futures WebSocket Diagnostic UI

Built from Stage 1120. Adds an in-page diagnostic indicator for the official LBank Futures WebSocket connection. No guessed subscription payload is sent. REST Futures feed remains the source of live market/depth data.

Official endpoint: wss://lbkperpws.lbank.com/ws.
