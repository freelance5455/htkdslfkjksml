/*
 * Redesign prototype for Al-Dhalea Modern Hospital Healthcare app.
 * This layer changes the on-screen navigation and visual presentation only.
 * The original clinical form IDs, app.js actions, records, and print logic remain in place.
 */
(function () {
  const NAV_LABELS = {
    patient: 'بيانات المريض', screening: 'الفحص الصحي الأولي', otherDiseases: 'الأمراض الإضافية',
    cvd: 'القلب والأوعية', stroke: 'الجلطات الدماغية', htn: 'ارتفاع ضغط الدم', dm: 'السكري ومضاعفاته',
    labs: 'الفحوصات المخبرية', diagnostics: 'الفحوصات التشخيصية', diagnosis: 'التشخيص',
    prescription: 'الوصفة الطبية', plan: 'الخطة العلاجية', recommendations: 'التوصيات والإحالة',
    followup: 'المتابعة والزيارات', notes: 'ملاحظات الطبيب', nutrition: 'التغذية العلاجية',
    assistant: 'المساعد السريري', reports: 'التقارير الطبية'
  };
  const NAV_ICONS = {
    patient: '👤', screening: '♥', otherDiseases: '✚', cvd: '♡', stroke: '🧠', htn: '↕', dm: '◉',
    labs: '⚗', diagnostics: '🔬', diagnosis: '✓', prescription: '💊', plan: '▤',
    recommendations: '↗', followup: '↻', notes: '✎', nutrition: '🥗', assistant: '🧠', reports: '▥'
  };
  const QUICK_TILES = [
    { title: 'مريض جديد', desc: 'بدء سجل طبي جديد', icon: '＋', tone: 'teal', action: () => window.redesignNewPatient() },
    { title: 'سجل المرضى', desc: 'البحث والتعديل والنسخ الاحتياطي', icon: '♙', tone: 'blue', action: () => window.redesignOpenRecords() },
    { title: 'متابعة المرضى', desc: 'المراجعات والفحوصات اللاحقة', icon: '▣', tone: 'violet', action: () => window.redesignNavigate('followup') },
    { title: 'المواعيد والتذكير', desc: 'مواعيد المراجعة والتنبيه', icon: '▦', tone: 'rose', action: () => window.openCareTool('reminder') },
    { title: 'الوصفة والأدوية', desc: 'الأدوية والجرعات وخطة العلاج', icon: '✚', tone: 'orange', action: () => window.redesignNavigate('prescription') },
    { title: 'الفحوصات المخبرية', desc: 'طلب الفحوصات وإدخال النتائج', icon: '⚗', tone: 'cyan', action: () => window.redesignNavigate('labs') },
    { title: 'التقارير والطباعة', desc: 'ملخص المريض والنماذج وPDF', icon: '▤', tone: 'navy', action: () => window.openPrintCenter() },
    { title: 'أدوات الرعاية', desc: 'الحاسبة والخطة والمساعد السريري', icon: '⚙', tone: 'slate', action: () => window.openHeaderActionDialog('care') }
  ];
  let currentView = 'dashboard';
  let currentSection = 'patient';
  let overlayReturn = null;
  let dashboardNode = null;
  let dashboardRefreshTimer = null;

  const safe = (value) => String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[ch]);
  const byId = (id) => document.getElementById(id);
  const readValue = (id, fallback = '—') => {
    const node = byId(id);
    return node && String(node.value || '').trim() ? String(node.value).trim() : fallback;
  };
  const dateLabel = () => {
    const now = new Date();
    try { return new Intl.DateTimeFormat('ar-YE', { timeZone: 'Asia/Aden', weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(now); }
    catch { return now.toLocaleDateString(); }
  };

  function makeDashboard() {
    const section = document.createElement('section');
    section.id = 'redesignDashboard';
    section.className = 'redesign-dashboard no-print';
    section.setAttribute('aria-label', 'الرئيسية');
    section.innerHTML = `
      <div class="prototype-banner"><span class="prototype-dot"></span><div><strong>واجهة تجريبية للمراجعة</strong><small>هذا إصدار مستقل للتقييم؛ لم يستبدل النسخة السابقة ويمكن الرجوع إليها من مجلد rollback-original.</small></div><span class="prototype-tag">P6 · UI Preview</span></div>
      <div class="dashboard-welcome-row">
        <section class="welcome-card">
          <div class="welcome-copy"><span class="welcome-eyebrow">مستشفى الضالع الحديث</span><h1>أهلًا بك في برنامج الرعاية الصحية</h1><p>منصة موحدة لتنظيم ملف المريض والفحص والتشخيص والعلاج والمتابعة.</p><div class="welcome-date"><span>◷</span><span id="redesignToday">${safe(dateLabel())}</span></div></div>
          <div class="welcome-logo"><img src="hospital-logo.png" alt="شعار مستشفى الضالع الحديث"><span>رعاية · متابعة · توثيق</span></div>
        </section>
        <section class="dashboard-search-card" aria-label="البحث عن مريض"><div class="card-heading"><div><span class="mini-kicker">الوصول السريع</span><h2>البحث عن مريض</h2></div><span class="search-symbol">⌕</span></div><p>ابحث بالاسم أو رقم الملف لفتح السجل المحفوظ.</p><div class="dashboard-search-control"><input id="redesignPatientSearch" type="search" placeholder="اكتب اسم المريض أو رقم الملف…" aria-label="البحث عن مريض"><button id="redesignSearchBtn" type="button" aria-label="بحث">⌕</button></div><button type="button" class="text-action" id="redesignFullRecordsBtn">فتح سجل المرضى ←</button></section>
      </div>
      <div class="dashboard-metrics" aria-label="مؤشرات البرنامج">
        <article class="metric-card metric-blue"><span class="metric-icon">♙</span><div><small>السجلات المحفوظة</small><strong id="redesignTotalPatients">0</strong><span>مريض في الجهاز</span></div></article>
        <article class="metric-card metric-teal"><span class="metric-icon">♥</span><div><small>السجل المفتوح</small><strong id="redesignCurrentPatient">مريض جديد</strong><span id="redesignCurrentFile">لم يُحفظ بعد</span></div></article>
        <article class="metric-card metric-violet"><span class="metric-icon">◷</span><div><small>تذكيرات المتابعة</small><strong id="redesignReminderCount">0</strong><span>مواعيد غير مكتملة</span></div></article>
        <article class="metric-card metric-orange"><span class="metric-icon">✓</span><div><small>الأقسام المفعّلة</small><strong id="redesignActiveSections">0</strong><span>يمكن تخصيصها من الشريط الجانبي</span></div></article>
      </div>
      <div class="dashboard-section-heading"><div><span class="mini-kicker">اختصارات العمل</span><h2>ماذا تريد أن تنجز الآن؟</h2></div><span class="heading-hint">اختر إجراءً للانتقال مباشرةً إلى القسم المطلوب</span></div>
      <div class="dashboard-quick-grid" id="redesignQuickGrid"></div>
      <div class="dashboard-lower-grid">
        <section class="dashboard-panel vitals-panel"><div class="panel-heading"><div><span class="mini-kicker">ملخص الزيارة</span><h2>المؤشرات السريرية الحالية</h2></div><button type="button" class="panel-link" id="redesignOpenScreening">فتح الفحص الأولي ←</button></div><div class="vitals-grid"><article class="vital-tile vital-bp"><span>ضغط الدم</span><strong id="redesignBP">—</strong><small>mmHg</small></article><article class="vital-tile vital-pulse"><span>النبض</span><strong id="redesignPulse">—</strong><small>نبضة/دقيقة</small></article><article class="vital-tile vital-temp"><span>الحرارة</span><strong id="redesignTemp">—</strong><small>°C</small></article><article class="vital-tile vital-spo"><span>الأكسجين</span><strong id="redesignSpO2">—</strong><small>SpO₂</small></article></div><div class="panel-note"><span>ⓘ</span><span>تُعرض هنا القيم المدخلة حاليًا فقط؛ لا تُنشئ هذه اللوحة قياسات أو تشخيصات تلقائيًا.</span></div></section>
        <section class="dashboard-panel reminders-panel"><div class="panel-heading"><div><span class="mini-kicker">المهام والتنبيهات</span><h2>متابعة العمل</h2></div><span class="notification-bell">♧</span></div><div class="task-list" id="redesignTaskList"></div><button type="button" class="panel-wide-button" id="redesignOpenReminders">عرض التذكيرات والمواعيد</button></section>
      </div>
      <section class="dashboard-panel recent-panel"><div class="panel-heading"><div><span class="mini-kicker">الوصول إلى آخر الملفات</span><h2>أحدث سجلات المرضى</h2></div><button type="button" class="panel-link" id="redesignRecentAll">عرض كل المرضى ←</button></div><div class="recent-patients-grid" id="redesignRecentPatients"><div class="empty-recent">ستظهر هنا السجلات التي تم حفظها على هذا الجهاز.</div></div></section>
      <div class="dashboard-footer-note"><span>◆</span><span>البيانات محفوظة محليًا على هذا الجهاز في هذه النسخة. احفظ نسخة احتياطية منتظمة، واستخدم بيئة آمنة ومعتمدة قبل إدخال بيانات مرضى حقيقية.</span></div>
    `;
    const shell = document.querySelector('.document-shell');
    document.body.insertBefore(section, shell || null);
    dashboardNode = section;
    const quickGrid = byId('redesignQuickGrid');
    QUICK_TILES.forEach((tile, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `quick-tile tile-${tile.tone}`;
      button.innerHTML = `<span class="quick-tile-icon">${safe(tile.icon)}</span><span class="quick-tile-copy"><strong>${safe(tile.title)}</strong><small>${safe(tile.desc)}</small></span><span class="quick-tile-arrow">‹</span>`;
      button.addEventListener('click', tile.action);
      button.setAttribute('aria-label', tile.title);
      quickGrid.appendChild(button);
    });
    byId('redesignSearchBtn').addEventListener('click', runPatientSearch);
    byId('redesignPatientSearch').addEventListener('keydown', (event) => { if (event.key === 'Enter') runPatientSearch(); });
    ['redesignFullRecordsBtn', 'redesignRecentAll'].forEach(id => byId(id).addEventListener('click', window.redesignOpenRecords));
    byId('redesignOpenScreening').addEventListener('click', () => window.redesignNavigate('screening'));
    byId('redesignOpenReminders').addEventListener('click', () => window.openCareTool('reminder'));
    refreshDashboard();
  }

  function runPatientSearch() {
    const q = String(byId('redesignPatientSearch')?.value || '').trim();
    window.toggleManager(true);
    const box = byId('searchPatients');
    if (box) {
      box.value = q;
      if (typeof window.renderPatients === 'function') window.renderPatients();
      setTimeout(() => box.focus({ preventScroll: true }), 80);
    }
  }

  function addRailBrandAndHome(nav) {
    const head = document.createElement('div');
    head.className = 'redesign-rail-head';
    head.innerHTML = `<img src="hospital-logo.png" alt="شعار المستشفى"><strong>الرعاية الصحية</strong><small>مستشفى الضالع الحديث</small>`;
    const mobileClose = document.createElement('button');
    mobileClose.type = 'button'; mobileClose.className = 'redesign-mobile-close'; mobileClose.textContent = '×';
    mobileClose.setAttribute('aria-label', 'إغلاق قائمة الأقسام');
    mobileClose.addEventListener('click', closeMobileSections);
    head.appendChild(mobileClose);
    nav.insertBefore(head, nav.firstChild);
    const home = document.createElement('button');
    home.type = 'button';
    home.className = 'redesign-nav-home';
    home.innerHTML = '<span>⌂</span><strong>الرئيسية</strong>';
    home.addEventListener('click', () => { closeMobileSections(); showDashboard(); });
    nav.insertBefore(home, head.nextSibling);
    Object.entries(NAV_LABELS).forEach(([key, label]) => {
      const button = nav.querySelector(`.nav-tab[data-target="${key}"]`);
      if (!button) return;
      button.textContent = `${NAV_ICONS[key] || '•'} ${label}`;
      button.title = label;
      button.setAttribute('aria-label', label);
    });
  }

  function setupSectionNavAutoClose() {
    document.querySelectorAll('.section-nav .nav-tab').forEach(button => {
      if (button.dataset.redesignMobileCloseHook) return;
      button.dataset.redesignMobileCloseHook = '1';
      button.addEventListener('click', () => setTimeout(closeMobileSections, 0));
    });
  }

  function addReturnButtons() {
    document.querySelectorAll('.document-shell .page').forEach(page => {
      if (page.classList.contains('cover-page')) return;
      const head = page.querySelector('.page-header');
      if (!head || head.querySelector('.redesign-return-home')) return;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'redesign-return-home no-print';
      button.textContent = '⌂ الرئيسية';
      button.addEventListener('click', showDashboard);
      head.appendChild(button);
    });
  }

  function setSectionView(key) {
    const page = document.querySelector(`[data-section="${key}"]`) || document.getElementById(key);
    if (!page) return false;
    if (dashboardNode) dashboardNode.hidden = true;
    document.body.classList.remove('home-dashboard-active');
    document.body.classList.add('ui-redesign-enabled');
    document.querySelectorAll('.document-shell .page.ui-section-active').forEach(node => node.classList.remove('ui-section-active'));
    page.classList.add('ui-section-active');
    currentSection = key;
    currentView = 'section';
    updateRailActive(key);
    refreshDashboard();
    return true;
  }

  function updateRailActive(key) {
    document.querySelectorAll('.section-nav .nav-tab').forEach(button => {
      button.classList.toggle('active', button.dataset.target === key);
    });
    const home = document.querySelector('.redesign-nav-home');
    if (home) home.classList.toggle('active', key === 'dashboard');
  }

  function showDashboard() {
    try { if (document.body.classList.contains('header-overlaying')) window.closeHeaderSectionOverlay(); } catch (_) {}
    overlayReturn = null;
    closeMobileSections();
    try { if (typeof window.closeHeaderActionDialog === 'function') window.closeHeaderActionDialog(); } catch (_) {}
    try { if (typeof window.closePrintCenter === 'function') window.closePrintCenter(); } catch (_) {}
    if (dashboardNode) dashboardNode.hidden = false;
    document.body.classList.add('ui-redesign-enabled', 'home-dashboard-active');
    document.querySelectorAll('.document-shell .page.ui-section-active').forEach(node => node.classList.remove('ui-section-active'));
    currentView = 'dashboard';
    updateRailActive('dashboard');
    refreshDashboard();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return true;
  }

  function refreshDashboard() {
    if (!dashboardNode) return;
    let patients = [];
    try { patients = typeof window.getDB === 'function' ? window.getDB() : []; } catch (_) { patients = []; }
    if (!Array.isArray(patients)) patients = [];
    const count = byId('redesignTotalPatients');
    if (count) count.textContent = String(patients.length);
    const patientName = readValue('patientName', 'مريض جديد');
    const currentName = byId('redesignCurrentPatient');
    if (currentName) currentName.textContent = patientName.length > 20 ? `${patientName.slice(0, 19)}…` : patientName;
    const file = readValue('fileNo', 'لم يُحفظ بعد');
    if (byId('redesignCurrentFile')) byId('redesignCurrentFile').textContent = file === 'لم يُحفظ بعد' ? file : `رقم الملف: ${file}`;
    let reminders = [];
    try { reminders = typeof window.getCareReminders === 'function' ? window.getCareReminders() : []; } catch (_) { reminders = []; }
    const dueCount = Array.isArray(reminders) ? reminders.filter(item => item.status === 'pending' || item.status === 'alerted').length : 0;
    if (byId('redesignReminderCount')) byId('redesignReminderCount').textContent = String(dueCount);
    const sectionsCount = document.querySelectorAll('.section-toggle:checked').length;
    if (byId('redesignActiveSections')) byId('redesignActiveSections').textContent = String(sectionsCount);
    const metrics = [
      ['redesignBP', 'bpScreen', '—'], ['redesignPulse', 'pulseScreen', '—'],
      ['redesignTemp', 'tempScreen', '—'], ['redesignSpO2', 'spo2Screen', '—']
    ];
    metrics.forEach(([target, source, fallback]) => { if (byId(target)) byId(target).textContent = readValue(source, fallback); });
    const taskRoot = byId('redesignTaskList');
    if (taskRoot) {
      const statusText = (byId('recordStatus')?.textContent || 'مسودة جديدة').trim();
      const remindersText = dueCount ? `${dueCount} موعد يحتاج إلى متابعة` : 'لا توجد تذكيرات غير مكتملة مسجلة';
      const name = patientName === 'مريض جديد' ? 'لم يُفتح سجل مريض بعد' : `السجل الحالي: ${patientName}`;
      taskRoot.innerHTML = `
        <div class="task-row"><span class="task-icon task-blue">♙</span><div><strong>ملف المريض</strong><small>${safe(name)}</small></div><span class="task-state">${safe(statusText)}</span></div>
        <div class="task-row"><span class="task-icon task-purple">◷</span><div><strong>مواعيد المتابعة</strong><small>${safe(remindersText)}</small></div><span class="task-state ${dueCount ? 'task-state-alert' : ''}">${dueCount ? 'تنبيه' : 'محدّث'}</span></div>
        <div class="task-row"><span class="task-icon task-teal">⚗</span><div><strong>الفحوصات</strong><small>أدخل النتائج في قسم الفحوصات المخبرية والتشخيصية</small></div><button type="button" class="task-action" id="redesignTaskLabs">فتح</button></div>`;
      byId('redesignTaskLabs')?.addEventListener('click', () => window.redesignNavigate('labs'));
    }
    const recentRoot = byId('redesignRecentPatients');
    if (recentRoot) {
      recentRoot.replaceChildren();
      const recent = [...patients].sort((a, b) => String(b.updatedAt || b.visitDate || '').localeCompare(String(a.updatedAt || a.visitDate || ''))).slice(0, 4);
      if (!recent.length) {
        const empty = document.createElement('div'); empty.className = 'empty-recent'; empty.textContent = 'لا توجد سجلات محفوظة بعد. استخدم «مريض جديد» لبدء سجل.'; recentRoot.appendChild(empty);
      } else {
        recent.forEach(patient => {
          const card = document.createElement('button'); card.type = 'button'; card.className = 'recent-patient-card';
          const initials = (patient.patientName || 'م').trim().slice(0, 1);
          const avatar = document.createElement('span'); avatar.className = 'recent-avatar'; avatar.textContent = initials;
          const copy = document.createElement('span'); copy.className = 'recent-patient-copy';
          const name = document.createElement('strong'); name.textContent = patient.patientName || 'بدون اسم';
          const no = document.createElement('small'); no.textContent = `الملف: ${patient.fileNo || '—'}`;
          const when = document.createElement('small'); when.textContent = patient.visitDate || 'تاريخ غير محدد';
          copy.append(name, no, when); const arrow = document.createElement('span'); arrow.className = 'recent-arrow'; arrow.textContent = '‹';
          card.append(avatar, copy, arrow); card.addEventListener('click', () => window.loadPatient(patient.id)); recentRoot.appendChild(card);
        });
      }
    }
    const today = byId('redesignToday'); if (today) today.textContent = dateLabel();
  }

  function installFunctionBridges() {
    const originalGoToSection = window.goToSection;
    window.redesignNavigate = function (key) {
      if (key === 'dashboard') return showDashboard();
      if (key === 'reports') return originalGoToSection ? originalGoToSection('reports') : false;
      setSectionView(key);
      return originalGoToSection ? originalGoToSection(key) : false;
    };
    window.goToSection = function (key, button) {
      if (key === 'dashboard') return showDashboard();
      if (key === 'reports') return originalGoToSection ? originalGoToSection(key, button) : false;
      setSectionView(key);
      return originalGoToSection ? originalGoToSection(key, button) : false;
    };
    const originalNewPatient = window.newPatient;
    window.redesignNewPatient = function () {
      if (typeof originalNewPatient === 'function') originalNewPatient(true);
      return window.redesignNavigate('patient');
    };
    window.newPatient = function () {
      const result = originalNewPatient ? originalNewPatient.apply(this, arguments) : undefined;
      window.redesignNavigate('patient');
      return result;
    };
    const originalToggleManager = window.toggleManager;
    window.redesignOpenRecords = function () {
      const opened = originalToggleManager ? originalToggleManager(true) : false;
      setTimeout(() => byId('searchPatients')?.focus({ preventScroll: true }), 80);
      return opened;
    };
    const originalOpenSectionOverlay = window.openHeaderSectionOverlay;
    window.openHeaderSectionOverlay = function (key) {
      overlayReturn = { view: currentView, section: currentSection };
      setSectionView(key);
      return originalOpenSectionOverlay ? originalOpenSectionOverlay(key) : false;
    };
    // When an overlay's own X button closes it, restore the screen that was underneath it.
    const watchCloseButtons = new MutationObserver((mutations) => {
      mutations.forEach(mutation => mutation.addedNodes.forEach(node => {
        if (!(node instanceof Element)) return;
        const candidates = [];
        if (node.matches?.('.header-overlay-close')) candidates.push(node);
        node.querySelectorAll?.('.header-overlay-close').forEach(item => candidates.push(item));
        candidates.forEach(button => {
          if (button.dataset.redesignReturnHook) return;
          button.dataset.redesignReturnHook = '1';
          button.addEventListener('click', () => setTimeout(restoreOverlayView, 0));
        });
      }));
    });
    watchCloseButtons.observe(document.body, { childList: true, subtree: true });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') closeMobileSections();
      if (event.key === 'Escape' && overlayReturn) setTimeout(restoreOverlayView, 0);
    });
    const originalSavePatient = window.savePatient;
    window.savePatient = function () {
      const result = originalSavePatient ? originalSavePatient.apply(this, arguments) : false;
      setTimeout(refreshDashboard, 0);
      return result;
    };
    if (typeof window.renderPatients === 'function') {
      const originalRenderPatients = window.renderPatients;
      window.renderPatients = function () {
        const result = originalRenderPatients.apply(this, arguments);
        setTimeout(refreshDashboard, 0);
        return result;
      };
    }
  }

  function restoreOverlayView() {
    if (!overlayReturn) return;
    if (document.querySelector('.header-overlay-open')) return;
    const target = overlayReturn;
    overlayReturn = null;
    if (target.view === 'dashboard') showDashboard();
    else window.redesignNavigate(target.section || currentSection || 'patient');
  }

  function setupMobileNav() {
    const nav = document.querySelector('.mobile-bottom-nav');
    if (!nav) return;
    nav.replaceChildren();
    const items = [
      ['⌂', 'الرئيسية', showDashboard],
      ['♙', 'بيانات المريض', () => window.redesignNavigate('patient')],
      ['♥', 'الفحص', () => window.redesignNavigate('screening')],
      ['⚗', 'المختبر', () => window.redesignNavigate('labs')],
      ['▤', 'التقارير', () => window.redesignNavigate('reports')],
      ['☷', 'الأقسام', toggleMobileSections]
    ];
    items.forEach(([icon, label, action]) => {
      const button = document.createElement('button'); button.type = 'button';
      button.innerHTML = `<span>${icon}</span><small>${label}</small>`; button.setAttribute('aria-label', label); button.addEventListener('click', action); nav.appendChild(button);
    });
  }

  function toggleMobileSections() {
    const nav = document.querySelector('.section-nav');
    if (!nav) return;
    const opening = !nav.classList.contains('mobile-nav-open');
    nav.classList.toggle('mobile-nav-open', opening);
    let backdrop = document.getElementById('redesignMobileNavBackdrop');
    if (opening) {
      if (!backdrop) { backdrop = document.createElement('div'); backdrop.id = 'redesignMobileNavBackdrop'; backdrop.className = 'redesign-mobile-nav-backdrop no-print'; backdrop.addEventListener('click', closeMobileSections); document.body.appendChild(backdrop); }
      document.body.classList.add('mobile-section-list-open');
    } else closeMobileSections();
  }

  function closeMobileSections() {
    document.querySelector('.section-nav')?.classList.remove('mobile-nav-open');
    document.getElementById('redesignMobileNavBackdrop')?.remove();
    document.body.classList.remove('mobile-section-list-open');
  }

  function setupLiveRefresh() {
    const watchedIds = ['patientName', 'fileNo', 'bpScreen', 'pulseScreen', 'tempScreen', 'spo2Screen', 'visitDate'];
    watchedIds.forEach(id => byId(id)?.addEventListener('input', refreshDashboard));
    watchedIds.forEach(id => byId(id)?.addEventListener('change', refreshDashboard));
    const patientBody = byId('patientsBody');
    if (patientBody) new MutationObserver(() => refreshDashboard()).observe(patientBody, { childList: true, subtree: true });
    if (dashboardRefreshTimer) clearInterval(dashboardRefreshTimer);
    dashboardRefreshTimer = setInterval(() => { if (currentView === 'dashboard') refreshDashboard(); }, 4000);
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.body.classList.add('ui-redesign-enabled');
    const title = document.querySelector('.brand-copy strong');
    const subtitle = document.querySelector('.brand-copy span');
    if (title) title.textContent = 'الرعاية الصحية';
    if (subtitle) subtitle.textContent = 'مستشفى الضالع الحديث';
    document.title = 'الرعاية الصحية | مستشفى الضالع الحديث';
    const nav = document.querySelector('.section-nav');
    if (nav) addRailBrandAndHome(nav);
    setupSectionNavAutoClose();
    makeDashboard();
    addReturnButtons();
    installFunctionBridges();
    setupLiveRefresh();
    setupMobileNav();
    showDashboard();
  });
})();
