# Zindagi Mehfooz EPI — file map (kya badalna ho to kis file mein)

Open `index.html` = the app. Everything else is loaded from it (scripts run in the order listed at the bottom of index.html).

## Screens & markup
| File | What is in it |
|---|---|
| `index.html` | All screens' HTML (menus, buttons, tables) + the list of scripts |
| `css/base.css` | Colours, fonts, buttons, page headers, upload screen |
| `css/screens.css` | Hub tiles, dashboards (By Age / EPI result cards `.stat-card`), result cards, Search card share button |
| `css/overlays.css` | Toast message, Share/Download dialogs, spinner |
| `css/print-responsive.css` | Print layout, very small phones |

## Login flow (Name/Center → District/Tehsil/UC → app)
| File | What is in it |
|---|---|
| `login.html` | **Page 1**: Name + Center. "Next" only appears once both are filled. Goes to `location-select-test-1.html`. |
| `location-select-test-1.html` | **Page 2**: District → Tehsil → Union Council. "Login" only appears once all three are selected. Goes to `index.html`. Redirects back to `login.html` if Name/Center aren't set yet. |
| `js/data/sindh-locations.js` | The Sindh District ➜ Tehsil ➜ UC data, shared by the login page AND the main app (single source of truth). |
| `js/core/location-context.js` | Reads the saved login selection from `localStorage` and turns it into a UC/Tehsil/District matcher used by `registry-parser.js`. Loads *before* `registry-parser.js`. |

`registry-parser.js` now classifies every Daily Immunization Report record using whichever District/Tehsil/UC was selected at login (not hard-coded to one tehsil anymore): a record's address is matched against that Tehsil's own UC list (**In UC** / **Out of UC**, per the Identifier column), a different Tehsil of the same District (**Out From Taluka**), or anything else (**Out From District**). If the app is opened without logging in first, it falls back to the original Ghotki ➜ Mirpur Mathelo word list so nothing breaks.

`index.html` now requires a completed login (redirects to `login.html` otherwise), shows who is logged in with a Logout button, and `js/screens/results.js` / `js/export/csv-print.js` / `js/export/pdf-records.js` all understand the new "Out From District" category alongside the existing "In UC" / "Out of UC" / "Out From Taluka".


| File | What is in it |
|---|---|
| `pdf-reader.js` | Opens the PDF and pulls out text with positions |
| `registry-parser.js` | Daily Immunization Report → children/women (incl. **EPI No** from the Identifier column, UC detection) |
| `defaulter-parser.js` | Children Defaulter Report → defaulters (incl. EPI No) |

## Core (js/core)
| File | What is in it |
|---|---|
| `epi-rules.js` | Which dose = BCG / Penta1 / Measles1 / TT1…; age; merging visits |
| `app-shell.js` | Main DOM handles, "back to main menu" |
| `dialogs-utils.js` | Dialog boxes, escapeHtml, label helpers |
| `storage.js` | Saving to the phone (records, defaulters, QR codes), EPI No lookup fallback |

## Phone / wrapper features (js/platform)
| File | What is in it |
|---|---|
| `native-bridge.js` | Download notification, exit app, wrapper back-key |
| `downloads.js` | The ONE download function every file goes through |
| `navigation.js` | **Back button** behaviour (never exits by accident — keeps a stack of history traps, refilled on every tap) |

## Screens (js/screens)
| File | What is in it |
|---|---|
| `upload-queue.js` | Picking files, the queue lists |
| `file-manager.js` | "Continue" processing, saved files, delete, QR panels |
| `dashboard.js` | **By Age (first) + All TT**, EPI/TT **result cards** (`statCardHtml`), Download/Share All Category Work (not shown on Results by Date) |
| `results.js` | In UC / Out of UC / All results, **record card (EPI No + QR)**, vaccine drill-down |
| `date-stock.js` | Results by Date, **Stock (date-by-date / running total / cumulative From–To total)**, QR results |
| `defaulters.js` | Defaulter Children screens |
| `search-hub.js` | Search Records (**per-card Share/Download**), hub buttons |

## Exports (js/export)
| File | What is in it |
|---|---|
| `csv-print.js` | Excel (.csv) export, print fallback |
| `pdf-assets.js` | Logo + boy/girl/**woman** pictures used in PDFs (replace `WOMAN_AVATAR_B64` for your own picture) |
| `pdf-writer.js` | Low-level PDF writer |
| `pdf-records.js` | Children/women PDFs — Print Style table + **Card Style (EPI No / QR Code)** |
| `pdf-defaulters.js` | Defaulter PDFs |
| `export-flow.js` | Share/Download → Card/Print question, single-card flow |

`js/main.js` starts everything (runs last). `sw.js` only helps show the download notification.
