const GEMINI_API_KEY =
    "AQ.Ab8RN6LnGtnye6yVxUnwuxO8rBR7vmimu1U7p58VFrn9U025MA";


const GEMINI_MODELS = [
    "gemini-3.6-flash",
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite"
];


async function callGemini(model, systemPrompt, contents) {

    const API_URL =
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;


    const response = await fetch(API_URL, {

        method: "POST",

        headers: {
            "Content-Type": "application/json",
            "x-goog-api-key": GEMINI_API_KEY
        },

        body: JSON.stringify({

            systemInstruction: {
                parts: [
                    {
                        text: systemPrompt
                    }
                ]
            },

            contents: contents,

            generationConfig: {
                temperature: 0.35,
                topP: 0.9,
                maxOutputTokens: 2048
            }

        })

    });


    let data = null;


    try {
        data = await response.json();
    }

    catch {
        data = null;
    }


    if (!response.ok) {

        const message =
            data?.error?.message ||
            `Gemini request failed with HTTP ${response.status}.`;


        const error =
            new Error(message);


        error.status =
            response.status;


        error.data =
            data;


        throw error;
    }


    const reply =
        data?.candidates?.[0]?.content?.parts
            ?.map(part => part.text || "")
            .join("")
            .trim();


    if (!reply) {
        throw new Error(
            "Gemini returned an empty response."
        );
    }


    return reply;
}