// ============================================
// DATA GAME
// ============================================

const FISH_TYPES = [
  { emoji: '🐟', name: 'Ikan Kecil',  value: 10,  chance: 40 },
  { emoji: '🐠', name: 'Ikan Tropis', value: 25,  chance: 30 },
  { emoji: '🐡', name: 'Ikan Buntal', value: 50,  chance: 15 },
  { emoji: '🦈', name: 'Hiu Kecil',   value: 100, chance: 10 },
  { emoji: '🐋', name: 'Paus Biru',   value: 300, chance: 5 }
];

const RODS = [
  { id: 'wood',   name: 'Rod Kayu',   emoji: '🎣',   price: 0,    catchBonus: 0,  pullWindow: 1100, desc: 'Rod pemula, cukup buat mulai' },
  { id: 'fiber',  name: 'Rod Fiber',  emoji: '🎣',   price: 200,  catchBonus: 10, pullWindow: 1400, desc: '+10% ikan langka, waktu tarik lebih longgar' },
  { id: 'carbon', name: 'Rod Carbon', emoji: '🎣',   price: 600,  catchBonus: 20, pullWindow: 1800, desc: '+20% ikan langka, waktu tarik lebih longgar' },
  { id: 'gold',   name: 'Rod Emas',   emoji: '✨🎣', price: 1500, catchBonus: 35, pullWindow: 2300, desc: 'Rod terbaik! +35% ikan langka' }
];

// ============================================
// STATE GAME
// ============================================

const state = {
  coins: 0,
  fishInventory: [],       // array of {emoji, name, value, uid}
  ownedRods: ['wood'],
  equippedRod: 'wood',
  isFishing: false,
  isWaitingBite: false,
  isBiting: false,
  currentFish: null,
  biteTimeout: null,
  escapeTimeout: null,
  soundEnabled: true,
  uidCounter: 0
};

// ============================================
// ELEMENT REFS
// ============================================

const el = {
  coinDisplay: document.getElementById('coinDisplay'),
  rodDisplay: document.getElementById('rodDisplay'),
  fishCount: document.getElementById('fishCount'),
  backpackOpenBtn: document.getElementById('backpackOpenBtn'),
  arm: document.getElementById('arm'),
  rodGroup: document.getElementById('rodGroup'),
  fishingLine: document.getElementById('fishingLine'),
  bobber: document.getElementById('bobber'),
  fish: document.getElementById('fish'),
  catchEffect: document.getElementById('catchEffect'),
  status: document.getElementById('status'),
  castBtn: document.getElementById('castBtn'),
  pullBtn: document.getElementById('pullBtn'),
  rodList: document.getElementById('rodList'),
  // Backpack modal
  backpackModal: document.getElementById('backpackModal'),
  closeBackpack: document.getElementById('closeBackpack'),
  backpackList: document.getElementById('backpackList'),
  bpTotal: document.getElementById('bpTotal'),
  sellAllBtn: document.getElementById('sellAllBtn')
};

// ============================================
// AUDIO ENGINE (Web Audio API)
// ============================================

const audioCtx = (() => {
  try {
    return new (window.AudioContext || window.webkitAudioContext)();
  } catch (e) {
    console.warn('Web Audio tidak didukung');
    return null;
  }
})();

// Resume audio context (wajib di mobile setelah interaksi user)
function unlockAudio() {
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
}

// Fungsi dasar untuk memainkan nada
function playTone({ freq, type = 'sine', duration = 0.15, volume = 0.15, delay = 0, slideTo = null }) {
  if (!audioCtx) return;
  unlockAudio();

  const t0 = audioCtx.currentTime + delay;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);

  if (slideTo !== null) {
    osc.frequency.linearRampToValueAtTime(slideTo, t0 + duration);
  }

  gain.gain.setValueAtTime(volume, t0);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);

  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.start(t0);
  osc.stop(t0 + duration + 0.02);
}

// Fungsi noise untuk splash / whoosh
function playNoise({ duration = 0.3, volume = 0.15, delay = 0, filterFreq = 1000 }) {
  if (!audioCtx) return;
  unlockAudio();

  const bufferSize = Math.floor(audioCtx.sampleRate * duration);
  const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  const data = buffer.getChannelData(0);

  for (let i = 0; i < bufferSize; i++) {
    data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
  }

  const source = audioCtx.createBufferSource();
  source.buffer = buffer;

  const filter = audioCtx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = filterFreq;

  const gain = audioCtx.createGain();
  gain.gain.setValueAtTime(volume, audioCtx.currentTime + delay);
  gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + delay + duration);

  source.connect(filter);
  filter.connect(gain);
  gain.connect(audioCtx.destination);

  source.start(audioCtx.currentTime + delay);
}

// === Kumpulan SFX ===
const SFX = {
  cast() {
    playNoise({ duration: 0.25, volume: 0.12, filterFreq: 2500 });
    playTone({ freq: 800, type: 'sine', duration: 0.15, volume: 0.08, slideTo: 400 });
  },
  splash() {
    playNoise({ duration: 0.35, volume: 0.18, filterFreq: 800 });
    playTone({ freq: 200, type: 'sine', duration: 0.2, volume: 0.1, slideTo: 120 });
  },
  nibble() {
    playTone({ freq: 500, type: 'triangle', duration: 0.08, volume: 0.12 });
    playTone({ freq: 650, type: 'triangle', duration: 0.08, volume: 0.12, delay: 0.12 });
  },
  bite() {
    playTone({ freq: 880, type: 'square', duration: 0.1, volume: 0.12 });
    playTone({ freq: 1100, type: 'square', duration: 0.1, volume: 0.12, delay: 0.1 });
    playTone({ freq: 1320, type: 'square', duration: 0.12, volume: 0.12, delay: 0.2 });
  },
  pull() {
    playTone({ freq: 600, type: 'sawtooth', duration: 0.2, volume: 0.1, slideTo: 900 });
  },
  catchSuccess() {
    // Arpeggio kemenangan
    const notes = [523, 659, 784, 1047];
    notes.forEach((f, i) => {
      playTone({ freq: f, type: 'sine', duration: 0.2, volume: 0.15, delay: i * 0.08 });
    });
  },
  escape() {
    playTone({ freq: 400, type: 'sawtooth', duration: 0.15, volume: 0.12, slideTo: 200 });
    playTone({ freq: 300, type: 'sawtooth', duration: 0.2, volume: 0.12, slideTo: 100, delay: 0.15 });
  },
  coin() {
    playTone({ freq: 1047, type: 'sine', duration: 0.08, volume: 0.15 });
    playTone({ freq: 1319, type: 'sine', duration: 0.12, volume: 0.15, delay: 0.08 });
  },
  buy() {
    playTone({ freq: 523, type: 'triangle', duration: 0.1, volume: 0.15 });
    playTone({ freq: 784, type: 'triangle', duration: 0.1, volume: 0.15, delay: 0.1 });
    playTone({ freq: 1047, type: 'triangle', duration: 0.15, volume: 0.15, delay: 0.2 });
  },
  click() {
    playTone({ freq: 700, type: 'sine', duration: 0.05, volume: 0.08 });
  }
};

// ============================================
// FUNGSI UTILITAS
// ============================================

function getEquippedRod() {
  return RODS.find(r => r.id === state.equippedRod) || RODS[0];
}

function getTotalFishValue() {
  return state.fishInventory.reduce((sum, f) => sum + f.value, 0);
}

function setStatus(text, type = '') {
  el.status.textContent = text;
  el.status.className = 'status' + (type ? ' ' + type : '');
}

function updateUI() {
  el.coinDisplay.textContent = state.coins;
  el.fishCount.textContent = state.fishInventory.length;
  el.rodDisplay.textContent = getEquippedRod().name;
  renderRodShop();
  renderBackpack();
}

// ============================================
// LOGIKA MEMANCING
// ============================================

function castLine() {
  if (state.isFishing) return;

  unlockAudio();
  SFX.cast();

  state.isFishing = true;
  state.isWaitingBite = true;

  el.castBtn.disabled = true;
  el.pullBtn.disabled = true;
  el.pullBtn.classList.remove('ready');

  // Reset animasi
  el.rodGroup.classList.remove('pulling');
  el.arm.classList.remove('pulling');
  el.fishingLine.classList.add('cast');

  // Pelampung muncul setelah delay
  setTimeout(() => {
    el.bobber.classList.add('visible', 'float');
    SFX.splash();
    setStatus('Menunggu ikan menggigit... 🎣');
  }, 400);

  const waitTime = 1500 + Math.random() * 2500;
  state.biteTimeout = setTimeout(startBite, waitTime + 400);
}

function startBite() {
  if (!state.isFishing) return;

  state.isWaitingBite = false;
  state.isBiting = true;

  const rod = getEquippedRod();
  state.currentFish = pickRandomFish(rod.catchBonus);

  // Bunyi "gigit-gigit"
  SFX.nibble();
  setTimeout(() => SFX.nibble(), 300);

  el.fish.textContent = state.currentFish.emoji;
  el.fish.classList.add('approach');

  setTimeout(() => {
    el.fish.classList.add('bite');
    SFX.bite();
  }, 350);

  setStatus('⚠️ Ikan menggigit! TARIK SEKARANG!', 'warning');

  el.pullBtn.disabled = false;
  el.pullBtn.classList.add('ready');
  el.castBtn.disabled = true;

  state.escapeTimeout = setTimeout(() => {
    if (state.isBiting) fishEscaped();
  }, rod.pullWindow);
}

function pickRandomFish(bonus) {
  const weights = FISH_TYPES.map((fish, i) => {
    const bonusWeight = (i / (FISH_TYPES.length - 1)) * bonus;
    return fish.chance + bonusWeight;
  });
  const totalWeight = weights.reduce((a, b) => a + b, 0);
  let random = Math.random() * totalWeight;
  for (let i = 0; i < FISH_TYPES.length; i++) {
    random -= weights[i];
    if (random <= 0) return FISH_TYPES[i];
  }
  return FISH_TYPES[0];
}

function pullLine() {
  if (!state.isBiting) return;

  clearTimeout(state.escapeTimeout);
  state.isBiting = false;

  SFX.pull();

  el.arm.classList.add('pulling');
  el.rodGroup.classList.add('pulling');
  el.pullBtn.disabled = true;
  el.pullBtn.classList.remove('ready');

  setStatus('Menarik... 🎣');

  setTimeout(() => {
    const caught = state.currentFish;
    if (!caught) return;

    // Simpan dengan uid unik
    state.fishInventory.push({ ...caught, uid: ++state.uidCounter });

    el.catchEffect.textContent = caught.emoji;
    el.catchEffect.classList.add('show');
    SFX.catchSuccess();

    setStatus(`🎉 Dapat ${caught.name}! (${caught.value} coin)`, 'success');

    setTimeout(resetFishing, 900);
  }, 500);
}

function fishEscaped() {
  clearTimeout(state.escapeTimeout);
  state.isBiting = false;
  state.currentFish = null;

  SFX.escape();

  el.pullBtn.disabled = true;
  el.pullBtn.classList.remove('ready');
  el.fish.classList.remove('bite', 'approach');
  el.fish.style.right = '-60px';

  setStatus('💨 Ikan kabur! Coba lagi.', 'fail');

  setTimeout(resetFishing, 1200);
}

function resetFishing() {
  state.isFishing = false;
  state.isWaitingBite = false;
  state.isBiting = false;
  state.currentFish = null;

  clearTimeout(state.biteTimeout);
  clearTimeout(state.escapeTimeout);

  el.fishingLine.classList.remove('cast');
  el.bobber.classList.remove('visible', 'float');
  el.arm.classList.remove('pulling');
  el.rodGroup.classList.remove('pulling');
  el.fish.classList.remove('approach', 'bite');
  el.fish.style.right = '-60px';
  el.catchEffect.classList.remove('show');

  el.castBtn.disabled = false;
  el.pullBtn.disabled = true;
  el.pullBtn.classList.remove('ready');

  updateUI();
}

// ============================================
// LOGIKA TOKO ROD
// ============================================

function renderRodShop() {
  el.rodList.innerHTML = '';
  RODS.forEach(rod => {
    const owned = state.ownedRods.includes(rod.id);
    const equipped = state.equippedRod === rod.id;

    const div = document.createElement('div');
    div.className = 'rod-item' +
      (equipped ? ' equipped' : '') +
      (owned && !equipped ? ' owned' : '');

    let buttonHtml;
    if (equipped) {
      buttonHtml = `<button class="btn-buy" type="button" disabled>✅ Dipakai</button>`;
    } else if (owned) {
      buttonHtml = `<button class="btn-buy" type="button" data-action="equip" data-rod="${rod.id}">Pakai</button>`;
    } else {
      const canAfford = state.coins >= rod.price;
      buttonHtml = `<button class="btn-buy" type="button" data-action="buy" data-rod="${rod.id}" ${canAfford ? '' : 'disabled'}>Beli (${rod.price} 💰)</button>`;
    }

    div.innerHTML = `
      <div class="rod-info">
        ${rod.emoji} ${rod.name}
        <small>${rod.desc}</small>
      </div>
      ${buttonHtml}
    `;
    el.rodList.appendChild(div);
  });
}

function buyRod(rodId) {
  const rod = RODS.find(r => r.id === rodId);
  if (!rod || state.ownedRods.includes(rodId)) return;
  if (state.coins < rod.price) return;

  state.coins -= rod.price;
  state.ownedRods.push(rodId);
  state.equippedRod = rodId;

  SFX.buy();
  setStatus(`🛒 Berhasil beli ${rod.name}!`, 'success');
  updateUI();
}

function equipRod(rodId) {
  if (!state.ownedRods.includes(rodId)) return;
  state.equippedRod = rodId;
  SFX.click();
  setStatus(`🎣 ${RODS.find(r => r.id === rodId).name} dipakai!`);
  updateUI();
}

// ============================================
// BACKPACK
// ============================================

function openBackpack() {
  unlockAudio();
  SFX.click();
  renderBackpack();
  el.backpackModal.classList.add('open');
}

function closeBackpack() {
  SFX.click();
  el.backpackModal.classList.remove('open');
}

function renderBackpack() {
  const total = getTotalFishValue();
  el.bpTotal.textContent = total;
  el.sellAllBtn.disabled = state.fishInventory.length === 0;

  if (state.fishInventory.length === 0) {
    el.backpackList.innerHTML = '<p class="empty-msg">Backpack kosong. Ayo mancing!</p>';
    return;
  }

  el.backpackList.innerHTML = '';
  state.fishInventory.forEach((fish) => {
    const div = document.createElement('div');
    div.className = 'bp-item';
    div.innerHTML = `
      <div class="bp-emoji">${fish.emoji}</div>
      <div class="bp-info">
        <div class="bp-name">${fish.name}</div>
        <div class="bp-value">${fish.value} 💰</div>
      </div>
      <button class="bp-sell" type="button" data-uid="${fish.uid}">Jual</button>
    `;
    el.backpackList.appendChild(div);
  });
}

function sellSingleFish(uid) {
  const idx = state.fishInventory.findIndex(f => f.uid === uid);
  if (idx === -1) return;

  const fish = state.fishInventory[idx];
  state.coins += fish.value;
  state.fishInventory.splice(idx, 1);

  SFX.coin();
  setStatus(`💰 ${fish.name} terjual! +${fish.value} coin`, 'success');
  updateUI();
}

function sellAllFish() {
  if (state.fishInventory.length === 0) return;

  const total = getTotalFishValue();
  const count = state.fishInventory.length;
  state.coins += total;
  state.fishInventory = [];

  SFX.coin();
  setStatus(`💰 ${count} ikan terjual! +${total} coin`, 'success');
  updateUI();
}

// ============================================
// EVENT LISTENERS (SUPPORT TOUCH + CLICK)
// ============================================

function onTap(element, handler) {
  let touched = false;
  element.addEventListener('touchstart', (e) => {
    touched = true;
    e.preventDefault();
    handler(e);
  }, { passive: false });
  element.addEventListener('click', (e) => {
    if (touched) { touched = false; return; }
    handler(e);
  });
}

onTap(el.castBtn, castLine);
onTap(el.pullBtn, pullLine);
onTap(el.backpackOpenBtn, openBackpack);
onTap(el.closeBackpack, closeBackpack);
onTap(el.sellAllBtn, sellAllFish);

// Klik backdrop modal untuk close
el.backpackModal.addEventListener('click', (e) => {
  if (e.target === el.backpackModal) closeBackpack();
});

// Delegation untuk toko rod
el.rodList.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-action]');
  if (!btn || btn.disabled) return;
  const rodId = btn.dataset.rod;
  if (btn.dataset.action === 'buy') buyRod(rodId);
  else if (btn.dataset.action === 'equip') equipRod(rodId);
});

// Delegation untuk jual ikan satu-satu
el.backpackList.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-uid]');
  if (!btn) return;
  sellSingleFish(parseInt(btn.dataset.uid));
});

// Keyboard support
document.addEventListener('keydown', (e) => {
  if (e.code === 'Space') {
    e.preventDefault();
    if (!el.pullBtn.disabled) pullLine();
  }
  if (e.code === 'Escape') {
    if (el.backpackModal.classList.contains('open')) closeBackpack();
  }
});

// ============================================
// INIT
// ============================================

updateUI();
setStatus('Tekan "Lempar" untuk mulai! 🎣');