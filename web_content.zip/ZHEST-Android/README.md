# ЖЕСТ — Android project (latest UI prototype 1.5)

This is an Android Studio source project, not an installable APK.

## Included
- WebView-based Android shell
- UI prototype 1.5 with separate app and gesture selection menus
- Local WebView storage enabled

## Build
Open this folder in Android Studio with Android SDK installed, allow Gradle sync, then use Build > Build APK(s).

## Limitations
- This archive does not contain a built APK or Gradle wrapper.
- Camera-based gesture recognition is not implemented.
- The project has not been compiled or device-tested in this environment.
