Email Manager Android wrapper

To build the APK:
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk.

The original HTML app is bundled locally in app/src/main/assets/index.html. Email data is stored in the WebView's local storage on the device.
