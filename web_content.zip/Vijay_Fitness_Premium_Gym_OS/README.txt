VIJAY FITNESS CENTRE — PREMIUM GYM OS
====================================

FILES
- index.html: complete standalone HTML/CSS/JavaScript gym management app.
- README.txt: this guide.

RUN
1. Extract the ZIP.
2. Open index.html in Chrome, Edge, or another modern browser.
3. Use the sidebar to access members, attendance, payments, workout plans, diet plans, trainers, reminders, reports and settings.

FEATURES
- Premium black/red responsive dashboard
- Member records, membership dates and renewal status
- Attendance check-in tracking
- Payment logging and outstanding dues
- Workout and diet plan libraries
- Trainer directory
- Due/renewal reminder message builder
- WhatsApp message handoff (requires a phone number and user confirmation in WhatsApp)
- CSV exports and JSON backup/restore
- Browser localStorage persistence

IMPORTANT LIMITATIONS
This is a front-end prototype. Records are saved in the current browser on the current device; there is no cloud sync, secure staff login, or multi-device database. The reminder centre detects due/expiry situations and prepares messages, but does NOT send SMS/WhatsApp automatically in the background. Actual scheduled automatic messaging requires a backend, database, scheduler and approved SMS/WhatsApp provider credentials. Payment recording is not a payment gateway and does not collect money online.
