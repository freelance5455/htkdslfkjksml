/* J.A.R.V.I.S BR — motor de xadrez e damas (tradução fiel de plugins/_xadrez_motor.py e plugins/xadrez.py).
   Regras completas do xadrez (roque, en passant, promoção, xeque, mate, afogamento) com busca alfa-beta;
   damas com as regras brasileiras (captura obrigatória, lei da maioria, dama que anda várias casas).
   A partida fica no aparelho: clicar no Arcade e falar "cavalo f3" mexem no mesmo jogo. */
"use strict";
const Motor = (() => {
  const INICIAL = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
  const VALOR = { P: 100, N: 320, B: 330, R: 500, Q: 900, K: 0 };
  const NOMES = { K: "rei", Q: "dama", R: "torre", B: "bispo", N: "cavalo", P: "peão" };
  const PECAS_PT = { rei: "K", dama: "Q", rainha: "Q", torre: "R", bispo: "B", cavalo: "N", peao: "P" };
  const _N = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]];
  const _K = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
  const _B = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
  const _R = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  const rep = (a, n) => [].concat(...Array(n).fill(a));
  const PST = {
    P: [...rep([0], 8), 5, 10, 10, -20, -20, 10, 10, 5, 5, -5, -10, 0, 0, -10, -5, 5, 0, 0, 0, 20, 20, 0, 0, 0,
      5, 5, 10, 25, 25, 10, 5, 5, 10, 10, 20, 30, 30, 20, 10, 10, ...rep([50], 8), ...rep([0], 8)],
    N: [-50, -40, -30, -30, -30, -30, -40, -50, -40, -20, 0, 5, 5, 0, -20, -40, -30, 5, 10, 15, 15, 10, 5, -30,
      ...rep([-30, 0, 15, 20, 20, 15, 0, -30], 2), -30, 5, 10, 15, 15, 10, 5, -30, -40, -20, 0, 0, 0, 0, -20, -40,
      -50, -40, -30, -30, -30, -30, -40, -50],
    B: [-20, -10, -10, -10, -10, -10, -10, -20, -10, 5, 0, 0, 0, 0, 5, -10, -10, 10, 10, 10, 10, 10, 10, -10,
      ...rep([-10, 0, 10, 10, 10, 10, 0, -10], 2), -10, 0, 5, 10, 10, 5, 0, -10, -10, 0, 0, 0, 0, 0, 0, -10,
      -20, -10, -10, -10, -10, -10, -10, -20],
    R: [0, 0, 0, 5, 5, 0, 0, 0, ...rep([-5, 0, 0, 0, 0, 0, 0, -5], 5), 5, 10, 10, 10, 10, 10, 10, 5, ...rep([0], 8)],
    Q: [-20, -10, -10, -5, -5, -10, -10, -20, -10, 0, 5, 0, 0, 0, 0, -10, -10, 5, 5, 5, 5, 5, 0, -10,
      0, 0, 5, 5, 5, 5, 0, -5, -5, 0, 5, 5, 5, 5, 0, -5, -10, 0, 5, 5, 5, 5, 0, -10,
      -10, 0, 0, 0, 0, 0, 0, -10, -20, -10, -10, -5, -5, -10, -10, -20],
    K: [20, 30, 10, 0, 0, 10, 30, 20, 20, 20, 0, 0, 0, 0, 20, 20, -10, -20, -20, -20, -20, -20, -20, -10,
      -20, -30, -30, -40, -40, -30, -30, -20, ...rep([-30, -40, -40, -50, -50, -40, -40, -30], 4)],
  };
  const nomeCasa = i => "abcdefgh"[i % 8] + (Math.floor(i / 8) + 1);
  const casa = n => (+n[1] - 1) * 8 + "abcdefgh".indexOf(n[0]);
  const branca = p => !!p && p === p.toUpperCase();
  const escolher = a => a[Math.floor(Math.random() * a.length)];
  const dobrar = t => String(t || "").normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase();

  class Posicao {
    constructor(fen = INICIAL) {
      if (fen === null) return;
      const p = fen.split(" ");
      this.tab = Array(64).fill("");
      p[0].split("/").forEach((linha, r) => { let f = 0; for (const ch of linha) { if (/\d/.test(ch)) f += +ch; else { this.tab[(7 - r) * 8 + f] = ch; f++; } } });
      this.vez = p[1] || "w";
      this.roques = p[2] && p[2] !== "-" ? p[2] : "";
      this.ep = p[3] && p[3] !== "-" ? casa(p[3]) : -1;
      this.meio = p.length > 4 ? +p[4] : 0;
      this.lance = p.length > 5 ? +p[5] : 1;
    }
    fen() {
      const linhas = [];
      for (let r = 7; r >= 0; r--) {
        let s = "", v = 0;
        for (let f = 0; f < 8; f++) { const q = this.tab[r * 8 + f]; if (q) { s += (v ? v : "") + q; v = 0; } else v++; }
        linhas.push(s + (v ? v : ""));
      }
      return `${linhas.join("/")} ${this.vez} ${this.roques || "-"} ${this.ep >= 0 ? nomeCasa(this.ep) : "-"} ${this.meio} ${this.lance}`;
    }
    copia() { const n = new Posicao(null); n.tab = this.tab.slice(); n.vez = this.vez; n.roques = this.roques; n.ep = this.ep; n.meio = this.meio; n.lance = this.lance; return n; }
    atacada(sq, porBrancas) {
      const r = sq >> 3, f = sq & 7, d = porBrancas ? -1 : 1, T = this.tab;
      for (const df of [-1, 1]) { const rr = r + d, ff = f + df; if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && T[rr * 8 + ff] === (porBrancas ? "P" : "p")) return true; }
      for (const [dr, df] of _N) { const rr = r + dr, ff = f + df; if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && T[rr * 8 + ff] === (porBrancas ? "N" : "n")) return true; }
      for (const [dr, df] of _K) { const rr = r + dr, ff = f + df; if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && T[rr * 8 + ff] === (porBrancas ? "K" : "k")) return true; }
      for (const [dirs, a0] of [[_B, "BQ"], [_R, "RQ"]]) {
        const alvos = porBrancas ? a0 : a0.toLowerCase();
        for (const [dr, df] of dirs) {
          let rr = r + dr, ff = f + df;
          while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) { const q = T[rr * 8 + ff]; if (q) { if (alvos.includes(q)) return true; break; } rr += dr; ff += df; }
        }
      }
      return false;
    }
    emXeque(brancas) {
      if (brancas === undefined) brancas = this.vez === "w";
      const i = this.tab.indexOf(brancas ? "K" : "k");
      return i < 0 ? true : this.atacada(i, !brancas);
    }
    pseudo() {
      const brancas = this.vez === "w", L = [], T = this.tab;
      for (let sq = 0; sq < 64; sq++) {
        const p = T[sq]; if (!p || branca(p) !== brancas) continue;
        const r = sq >> 3, f = sq & 7, t = p.toUpperCase();
        if (t === "P") {
          const [d, inicio, ultima] = brancas ? [1, 1, 7] : [-1, 6, 0], um = sq + 8 * d;
          if (um >= 0 && um < 64 && !T[um]) { Posicao._peao(L, sq, um, ultima); const dois = sq + 16 * d; if (r === inicio && !T[dois]) L.push([sq, dois, ""]); }
          for (const df of [-1, 1]) {
            const ff = f + df, rr = r + d;
            if (ff >= 0 && ff < 8 && rr >= 0 && rr < 8) { const alvo = rr * 8 + ff, q = T[alvo]; if ((q && branca(q) !== brancas) || alvo === this.ep) Posicao._peao(L, sq, alvo, ultima); }
          }
        } else if (t === "N" || t === "K") {
          for (const [dr, df] of (t === "N" ? _N : _K)) {
            const rr = r + dr, ff = f + df;
            if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) { const q = T[rr * 8 + ff]; if (!q || branca(q) !== brancas) L.push([sq, rr * 8 + ff, ""]); }
          }
          if (t === "K") this._roques(L, sq, brancas);
        } else {
          const dirs = t === "B" ? _B : t === "R" ? _R : _B.concat(_R);
          for (const [dr, df] of dirs) {
            let rr = r + dr, ff = f + df;
            while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
              const q = T[rr * 8 + ff];
              if (q) { if (branca(q) !== brancas) L.push([sq, rr * 8 + ff, ""]); break; }
              L.push([sq, rr * 8 + ff, ""]); rr += dr; ff += df;
            }
          }
        }
      }
      return L;
    }
    static _peao(L, de, para, ultima) { if ((para >> 3) === ultima) for (const x of "QRBN") L.push([de, para, x]); else L.push([de, para, ""]); }
    _roques(L, sq, brancas) {
      const base = brancas ? 0 : 56; if (sq !== base + 4 || this.emXeque(brancas)) return;
      const [k, q] = brancas ? ["K", "Q"] : ["k", "q"], torre = brancas ? "R" : "r", T = this.tab;
      if (this.roques.includes(k) && T[base + 7] === torre && !T[base + 5] && !T[base + 6] && !this.atacada(base + 5, !brancas) && !this.atacada(base + 6, !brancas)) L.push([sq, base + 6, ""]);
      if (this.roques.includes(q) && T[base] === torre && !T[base + 1] && !T[base + 2] && !T[base + 3] && !this.atacada(base + 3, !brancas) && !this.atacada(base + 2, !brancas)) L.push([sq, base + 2, ""]);
    }
    jogar([de, para, promo]) {
      const n = this.copia(), p = n.tab[de], brancas = branca(p);
      let capturou = !!n.tab[para];
      n.tab[para] = p; n.tab[de] = "";
      const t = p.toUpperCase();
      if (t === "P") {
        if (para === this.ep) { n.tab[brancas ? para - 8 : para + 8] = ""; capturou = true; }
        if (promo) n.tab[para] = brancas ? promo : promo.toLowerCase();
      }
      if (t === "K" && Math.abs(para - de) === 2) {
        if (para % 8 === 6) { n.tab[para - 1] = n.tab[para + 1]; n.tab[para + 1] = ""; }
        else { n.tab[para + 1] = n.tab[para - 2]; n.tab[para - 2] = ""; }
      }
      n.ep = t === "P" && Math.abs(para - de) === 16 ? (de + para) / 2 : -1;
      const tira = { 4: "KQ", 0: "Q", 7: "K", 60: "kq", 56: "q", 63: "k" };
      for (const sq of [de, para]) for (const c of (tira[sq] || "")) n.roques = n.roques.replace(c, "");
      n.meio = capturou || t === "P" ? 0 : n.meio + 1;
      if (!brancas) n.lance += 1;
      n.vez = brancas ? "b" : "w";
      return n;
    }
    legais() { const b = this.vez === "w"; return this.pseudo().filter(m => !this.jogar(m).emXeque(b)); }
    captura(l) { return !!this.tab[l[1]] || (this.tab[l[0]].toUpperCase() === "P" && l[1] === this.ep); }
    resultado() {
      if (!this.legais().length) return this.emXeque() ? (this.vez === "w" ? "mate_pretas" : "mate_brancas") : "afogado";
      const pecas = this.tab.filter(p => p && p.toUpperCase() !== "K");
      if (!pecas.length || (pecas.length === 1 && "NB".includes(pecas[0].toUpperCase())) || this.meio >= 100) return "empate";
      return "";
    }
  }

  function avaliar(pos) {
    let total = 0;
    for (let sq = 0; sq < 64; sq++) {
      const p = pos.tab[sq]; if (!p) continue; const t = p.toUpperCase();
      if (branca(p)) total += VALOR[t] + PST[t][sq]; else total -= VALOR[t] + PST[t][(7 - (sq >> 3)) * 8 + (sq & 7)];
    }
    return pos.vez === "w" ? total : -total;
  }
  const ordem = (pos, L) => L.slice().sort((a, b) => nota(pos, b) - nota(pos, a));
  const nota = (pos, m) => (pos.tab[m[1]] ? VALOR[pos.tab[m[1]].toUpperCase()] || 0 : 0) + (m[2] === "Q" ? 800 : 0);
  function busca(pos, prof, alfa, beta) {
    if (prof === 0) return quieta(pos, alfa, beta, 3);
    const L = pos.legais();
    if (!L.length) return pos.emXeque() ? -100000 - prof : 0;
    for (const m of ordem(pos, L)) { const v = -busca(pos.jogar(m), prof - 1, -beta, -alfa); if (v >= beta) return v; alfa = Math.max(alfa, v); }
    return alfa;
  }
  function quieta(pos, alfa, beta, limite) {
    const parado = avaliar(pos);
    if (parado >= beta || limite === 0) return parado;
    alfa = Math.max(alfa, parado);
    for (const m of ordem(pos, pos.pseudo().filter(m => pos.captura(m)))) {
      const nova = pos.jogar(m); if (nova.emXeque(pos.vez === "w")) continue;
      const v = -quieta(nova, -beta, -alfa, limite - 1); if (v >= beta) return v; alfa = Math.max(alfa, v);
    }
    return alfa;
  }
  function melhorLance(pos, nivel = "medio") {
    const L = pos.legais(); if (!L.length) return null;
    if (nivel === "facil") { const cap = L.filter(m => pos.captura(m)); return escolher(cap.length && Math.random() < 0.6 ? cap : L); }
    const [prof, folga] = nivel === "medio" ? [2, 5] : [4, 0];
    const notas = []; let alfa = -1e9;
    for (const m of ordem(pos, L)) { const v = -busca(pos.jogar(m), prof - 1, -1e9, -(alfa - folga - 1)); notas.push([v, m]); alfa = Math.max(alfa, v); }
    const melhor = Math.max(...notas.map(x => x[0]));
    return escolher(notas.filter(x => x[0] >= melhor - folga).map(x => x[1]));
  }
  function lerLance(pos, fala) {
    const t = dobrar(fala), L = pos.legais();
    if (t.includes("roque")) {
      const base = pos.vez === "w" ? 0 : 56, alvo = base + (/grande|longo/.test(t) ? 2 : 6);
      const m = L.find(x => x[0] === base + 4 && x[1] === alvo && pos.tab[x[0]].toUpperCase() === "K");
      return m ? [m, ""] : [null, "O roque não é possível agora."];
    }
    const casas = [...t.matchAll(/\b([a-h])\s*([1-8])\b/g)].map(x => casa(x[1] + x[2]));
    if (!casas.length) return [null, "Não entendi o lance. Diga a peça e a casa, como 'cavalo para f3' ou 'e2 e4'."];
    const destino = casas[casas.length - 1], origem = casas.length >= 2 ? casas[0] : null;
    const padrao = /(vira|promov\w*|coroa\w*|=)\s*(a |em |um |uma )?(dama|rainha|torre|bispo|cavalo)/;
    const achou = t.match(padrao), promo = achou ? PECAS_PT[achou[3]] : "Q", sem = t.replace(padrao, " ");
    const tipo = (Object.entries(PECAS_PT).find(([k]) => new RegExp(`\\b${k}\\b`).test(sem)) || [])[1];
    let c = L.filter(m => m[1] === destino && (origem === null || m[0] === origem));
    if (tipo) c = c.filter(m => pos.tab[m[0]].toUpperCase() === tipo);
    else if (origem === null) { const pe = c.filter(m => pos.tab[m[0]].toUpperCase() === "P"); if (pe.length) c = pe; }
    if (c.some(m => m[2])) c = c.filter(m => m[2] === promo);
    if (c.length === 1) return [c[0], ""];
    if (!c.length) return [null, "Esse lance não é permitido agora."];
    return [null, "Qual deles: de " + [...new Set(c.map(m => nomeCasa(m[0])))].sort().join(" ou ") + "?"];
  }
  function falarLance(pos, l) {
    const [de, para, promo] = l, p = pos.tab[de].toUpperCase();
    let t;
    if (p === "K" && Math.abs(para - de) === 2) t = para % 8 === 6 ? "roque pequeno" : "roque grande";
    else { t = `${NOMES[p]} ${pos.captura(l) ? "captura em" : "para"} ${nomeCasa(para)}`; if (promo) t += `, vira ${NOMES[promo]}`; }
    const depois = pos.jogar(l), r = depois.resultado();
    if (r.startsWith("mate")) t += ", xeque-mate"; else if (depois.emXeque()) t += ", xeque";
    return t;
  }
  const SIMB = { K: "♔", Q: "♕", R: "♖", B: "♗", N: "♘", P: "♙", k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟" };
  function desenho(pos, brancasEmbaixo = true) {
    const linhas = [], rs = brancasEmbaixo ? [7, 6, 5, 4, 3, 2, 1, 0] : [0, 1, 2, 3, 4, 5, 6, 7], fs = brancasEmbaixo ? [0, 1, 2, 3, 4, 5, 6, 7] : [7, 6, 5, 4, 3, 2, 1, 0];
    for (const r of rs) linhas.push(`${r + 1} ` + fs.map(f => { const p = pos.tab[r * 8 + f]; return p ? SIMB[p] : ((r + f) % 2 ? "·" : "▪"); }).join(" "));
    linhas.push("  " + (brancasEmbaixo ? "a b c d e f g h" : "h g f e d c b a"));
    return linhas.join("\n");
  }

  // ═══ DAMAS (regras brasileiras) ═══
  const DIAG = [[1, 1], [-1, 1], [1, -1], [-1, -1]];
  const k = c => c[0] + "," + c[1];
  const dentro = c => c[0] >= 0 && c[0] < 8 && c[1] >= 0 && c[1] < 8;
  const pecaEm = (tab, c) => tab[k(c)] ?? null;
  const inimiga = (p, q) => q !== null && p.toLowerCase() !== q.toLowerCase();
  const igual = (a, b) => a[0] === b[0] && a[1] === b[1];
  const nomeD = c => String.fromCharCode(97 + c[0]) + (c[1] + 1);
  const casaD = n => [n.charCodeAt(0) - 97, +n[1] - 1];
  function damasInicial() { const t = {}; for (let l = 0; l < 8; l++) for (let c = 0; c < 8; c++) if ((c + l) % 2 === 0) { if (l <= 2) t[c + "," + l] = "b"; else if (l >= 5) t[c + "," + l] = "p"; } return t; }
  function capturasDe(tab, o, peca, capt, visit) {
    const seqs = [], dama = peca === peca.toUpperCase();
    for (const [dc, dl] of DIAG) {
      let c = [o[0] + dc, o[1] + dl];
      if (dama) while (dentro(c) && pecaEm(tab, c) === null) c = [c[0] + dc, c[1] + dl];
      if (!dentro(c) || !inimiga(peca, pecaEm(tab, c)) || capt.has(k(c))) continue;
      const alvo = c; let dest = [alvo[0] + dc, alvo[1] + dl];
      while (dentro(dest) && (pecaEm(tab, dest) === null || visit.has(k(dest)))) {
        const cont = capturasDe(tab, dest, peca, new Set([...capt, k(alvo)]), new Set([...visit, k(dest)]));
        if (cont.length) for (const [s, com] of cont) seqs.push([[o, ...s], [alvo, ...com]]);
        else seqs.push([[o, dest], [alvo]]);
        if (!dama) break;
        dest = [dest[0] + dc, dest[1] + dl];
      }
    }
    return seqs;
  }
  function damasLances(tab, cor) {
    let capturas = []; const simples = [];
    for (const [chave, peca] of Object.entries(tab)) {
      if (peca.toLowerCase() !== cor) continue;
      const o = chave.split(",").map(Number), sem = { ...tab }; delete sem[chave];
      capturas = capturas.concat(capturasDe(sem, o, peca, new Set(), new Set([k(o)])));
      const frente = cor === "b" ? 1 : -1, dama = peca === peca.toUpperCase();
      for (const [dc, dl] of (dama ? DIAG : [[1, frente], [-1, frente]])) {
        let c = [o[0] + dc, o[1] + dl];
        while (dentro(c) && pecaEm(tab, c) === null) { simples.push([[o, c], []]); if (!dama) break; c = [c[0] + dc, c[1] + dl]; }
      }
    }
    if (capturas.length) { const mx = Math.max(...capturas.map(x => x[1].length)); return capturas.filter(x => x[1].length === mx); }
    return simples;
  }
  function damasJogar(tab, [casas, comidas]) {
    const n = { ...tab }; let peca = n[k(casas[0])]; delete n[k(casas[0])];
    for (const c of comidas) delete n[k(c)];
    const fim = casas[casas.length - 1];
    if ((peca === "b" && fim[1] === 7) || (peca === "p" && fim[1] === 0)) peca = peca.toUpperCase();
    n[k(fim)] = peca; return n;
  }
  const damasValor = tab => Object.values(tab).reduce((s, p) => s + (p === p.toUpperCase() ? 3 : 1) * (p.toLowerCase() === "b" ? 1 : -1), 0);
  function damasEscolher(tab, cor, nivel) {
    const L = damasLances(tab, cor); if (!L.length) return null;
    if (nivel === "facil") return escolher(L);
    const sinal = cor === "b" ? 1 : -1, outra = cor === "b" ? "p" : "b";
    const notaD = l => { const d = damasJogar(tab, l), resp = damasLances(d, outra); return resp.length ? Math.min(...resp.map(r => sinal * damasValor(damasJogar(d, r)))) : sinal * damasValor(d) + 50; };
    const ns = L.map(x => [notaD(x), x]), mx = Math.max(...ns.map(x => x[0]));
    return escolher(ns.filter(x => x[0] === mx).map(x => x[1]));
  }
  function damasLerLance(tab, cor, fala) {
    const casas = [...dobrar(fala).matchAll(/\b([a-h])\s*([1-8])\b/g)].map(x => casaD(x[1] + x[2])), L = damasLances(tab, cor);
    if (!casas.length) return [null, "Diga as casas, como 'c3 d4'."];
    const ult = casas[casas.length - 1];
    const c = L.filter(x => igual(x[0][x[0].length - 1], ult) && (casas.length < 2 || igual(x[0][0], casas[0])) && casas.every(cc => x[0].some(y => igual(y, cc))));
    if (c.length === 1) return [c[0], ""];
    if (!c.length) return [null, "Esse lance não vale" + (L.length && L[0][1].length ? " (a captura é obrigatória e tem que comer o máximo de peças)" : "") + ". Lances possíveis: " + L.slice(0, 6).map(x => x[0].map(nomeD).join(" ")).join(", ") + "."];
    return [null, "Qual deles: " + c.map(x => x[0].map(nomeD).join(" ")).join(" ou ") + "?"];
  }
  function desenhoDamas(tab) {
    const s = { b: "○", B: "◎", p: "●", P: "◉" }, linhas = [];
    for (let l = 7; l >= 0; l--) { let t = `${l + 1} `; for (let c = 0; c < 8; c++) t += (s[tab[c + "," + l]] || ((c + l) % 2 === 0 ? "·" : " ")) + " "; linhas.push(t.trimEnd()); }
    return linhas.concat(["  a b c d e f g h", "", "○ suas  ◎ sua dama   ● minhas  ◉ minha dama"]).join("\n");
  }

  // ═══ partida salva (a mesma para o Arcade e para a voz) ═══
  const ARQ = "j_xadrez";
  const lerD = () => { try { return JSON.parse(localStorage.getItem(ARQ) || "{}") || {}; } catch (e) { return {}; } };
  const gravarD = d => { try { localStorage.setItem(ARQ, JSON.stringify(d)); } catch (e) {} };
  function fimXadrez(pos, voceBrancas) {
    const r = pos.resultado(); if (!r) return "";
    if (r.startsWith("mate")) return (r === "mate_brancas") === voceBrancas ? "Xeque-mate: você venceu! Parabéns." : "Xeque-mate: eu venci desta vez!";
    return r === "afogado" ? "Afogado: empate." : "Empate.";
  }
  function novoXadrez(nivel = "medio", voce = "brancas") {
    let pos = new Posicao();
    const d = { jogo: "xadrez", nivel, voce, fen: pos.fen(), lances: [], ultimo: null };
    if (voce === "pretas") { const m = melhorLance(pos, nivel), f = falarLance(pos, m); pos = pos.jogar(m); Object.assign(d, { fen: pos.fen(), lances: [f], ultimo: [m[0], m[1]] }); return [d, `Você joga de pretas. Meu primeiro lance: ${f}. Sua vez.`]; }
    return [d, `Xadrez, nível ${nivel}. Você joga de brancas: diga seu lance, como 'peão e4' ou 'cavalo f3'.`];
  }
  function jogadaXadrez(d, l) {
    let pos = new Posicao(d.fen); const vb = (d.voce || "brancas") === "brancas", seu = falarLance(pos, l);
    pos = pos.jogar(l); d.ultimo = [l[0], l[1]];
    let fim = fimXadrez(pos, vb);
    if (fim) { Object.assign(d, { fen: pos.fen(), jogo: null, lances: (d.lances || []).concat([seu]).slice(-200) }); return `Você jogou ${seu}. ${fim}`; }
    const ml = melhorLance(pos, d.nivel || "medio"), meu = falarLance(pos, ml); pos = pos.jogar(ml);
    Object.assign(d, { fen: pos.fen(), ultimo: [ml[0], ml[1]], lances: (d.lances || []).concat([seu, meu]).slice(-200) });
    fim = fimXadrez(pos, vb); if (fim) d.jogo = null;
    return `Você: ${seu}. Eu: ${meu}.` + (fim ? " " + fim : "");
  }
  const novoDamas = (nivel = "medio") => [{ jogo: "damas", nivel, tab: damasInicial(), lances: [] }, "Damas, regras brasileiras. Você joga com as brancas, de baixo: diga as casas, como 'c3 d4'."];
  function jogadaDamas(d, l) {
    let tab = damasJogar(d.tab, l);
    const seu = l[0].map(nomeD).join(" ") + (l[1].length ? `, comeu ${l[1].length}` : "");
    const ml = damasEscolher(tab, "p", d.nivel || "medio");
    if (!ml) { Object.assign(d, { tab, jogo: null }); return `Você: ${seu}. Fiquei sem lances: você venceu!`; }
    tab = damasJogar(tab, ml);
    const meu = ml[0].map(nomeD).join(" ") + (ml[1].length ? `, comi ${ml[1].length}` : "");
    const fim = damasLances(tab, "b").length ? "" : " Você ficou sem lances: eu venci!";
    Object.assign(d, { tab, jogo: fim ? null : "damas", ultimo_damas: ml[0].map(c => [...c]) });
    return `Você: ${seu}. Eu: ${meu}.${fim}`;
  }
  function estadoXadrez() {
    const d = lerD();
    if (d.fen) {
      const pos = new Posicao(d.fen);
      return { fen: d.fen, tab: pos.tab, vez: pos.vez, voce: d.voce || "brancas", nivel: d.nivel || "medio", ativo: d.jogo === "xadrez",
        legais: pos.legais(), ultimo: d.ultimo || null, xeque: pos.emXeque(), resultado: pos.resultado(), lances: (d.lances || []).slice(-12), outro: d.jogo === "damas" };
    }
    return { fen: "", ativo: false, outro: d.jogo === "damas" };
  }
  function estadoDamas() {
    const d = lerD();
    if (d.tab && d.jogo !== "xadrez") {
      const L = d.jogo === "damas" ? damasLances(d.tab, "b") : [];
      return { tab: d.tab, ativo: d.jogo === "damas", nivel: d.nivel || "medio", legais: L.map(x => x[0].map(c => [...c])), ultimo: d.ultimo_damas || null, fim: !L.length };
    }
    return { tab: {}, ativo: false };
  }
  const nv = n => ["facil", "medio", "dificil"].includes(n) ? n : "medio";
  // as mesmas rotas que o servidor do Arcade no PC tinha (plugins/_arcade.py)
  function api(caminho, b) {
    if (caminho === "/api/xadrez") return estadoXadrez();
    if (caminho === "/api/damas") return estadoDamas();
    if (caminho === "/api/placar") { try { return JSON.parse(localStorage.getItem("arcade_placar") || "{}"); } catch (e) { return {}; } }
    if (caminho === "/api/xadrez/novo") { const [d, fala] = novoXadrez(nv(b.nivel), b.voce === "pretas" ? "pretas" : "brancas"); gravarD(d); return { ...estadoXadrez(), fala }; }
    if (caminho === "/api/xadrez/lance") {
      const d = lerD(); if (d.jogo !== "xadrez") return { ...estadoXadrez(), erro: "Não há partida de xadrez. Comece uma nova." };
      const pos = new Posicao(d.fen); if ((pos.vez === "w") !== ((d.voce || "brancas") === "brancas")) return { ...estadoXadrez(), erro: "Não é a sua vez." };
      const l = pos.legais().find(m => m[0] === +b.de && m[1] === +b.para && (m[2] === (b.promo || "Q") || !m[2]));
      if (!l) return { ...estadoXadrez(), erro: "Esse lance não vale." };
      const fala = jogadaXadrez(d, l); gravarD(d); return { ...estadoXadrez(), fala };
    }
    if (caminho === "/api/damas/novo") { const [d, fala] = novoDamas(nv(b.nivel)); gravarD(d); return { ...estadoDamas(), fala }; }
    if (caminho === "/api/damas/lance") {
      const d = lerD(); if (d.jogo !== "damas") return { ...estadoDamas(), erro: "Não há partida de damas. Comece uma nova." };
      const l = damasLances(d.tab, "b").find(x => x[0].length === b.casas.length && x[0].every((c, i) => igual(c, b.casas[i])));
      if (!l) return { ...estadoDamas(), erro: "Esse lance não vale (a captura é obrigatória, e a maior)." };
      const fala = jogadaDamas(d, l); gravarD(d); return { ...estadoDamas(), fala };
    }
    return { erro: "rota" };
  }
  // a ferramenta de voz (plugins/xadrez.py → run)
  function porVoz(p = {}) {
    const acao = String(p.action || "tabuleiro").toLowerCase();
    let d = lerD();
    if (acao === "novo") {
      const jt = dobrar(p.jogo), jogo = jt.includes("dama") && !jt.includes("xadrez") ? "damas" : "xadrez";
      const nivel = ["facil", "medio", "dificil"].find(n => dobrar(p.nivel).includes(n)) || "medio";
      if (jogo === "xadrez") { const voce = dobrar(p.cor).includes("pret") ? "pretas" : "brancas"; const [dd, fala] = novoXadrez(nivel, voce); gravarD(dd); return { fala, tabuleiro: desenho(new Posicao(dd.fen), voce === "brancas") }; }
      const [dd, fala] = novoDamas(nivel); gravarD(dd); return { fala, tabuleiro: desenhoDamas(dd.tab) };
    }
    if (!d.jogo) return { fala: "Não há partida. Diga 'vamos jogar xadrez' ou 'vamos jogar damas'." };
    if (acao === "desistir") { d.jogo = null; gravarD(d); return { fala: "Partida encerrada. Boa partida! Quando quiser, a revanche." }; }
    if (d.jogo === "xadrez") {
      const pos = new Posicao(d.fen), emb = (d.voce || "brancas") === "brancas";
      if (acao === "tabuleiro") return { fala: "O tabuleiro está na tela.", tabuleiro: desenho(pos, emb) };
      if ((pos.vez === "w") !== emb) return { fala: "Agora é a minha vez; um instante." };
      const [l, erro] = lerLance(pos, p.lance); if (!l) return { fala: erro };
      const fala = jogadaXadrez(d, l); gravarD(d); return { fala, tabuleiro: desenho(new Posicao(d.fen), emb) };
    }
    if (acao === "tabuleiro") return { fala: "O tabuleiro está na tela.", tabuleiro: desenhoDamas(d.tab) };
    const [l, erro] = damasLerLance(d.tab, "b", p.lance); if (!l) return { fala: erro };
    const fala = jogadaDamas(d, l); gravarD(d); return { fala, tabuleiro: desenhoDamas(d.tab) };
  }
  function perft(pos, prof) { if (!prof) return 1; let n = 0; for (const m of pos.legais()) n += perft(pos.jogar(m), prof - 1); return n; }
  return { Posicao, melhorLance, lerLance, falarLance, desenho, damasLances, damasJogar, damasInicial, api, porVoz, perft };
})();
if (typeof module !== "undefined") module.exports = Motor;
