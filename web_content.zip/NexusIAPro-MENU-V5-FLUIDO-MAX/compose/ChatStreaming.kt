package com.nexus.ia.pro.ui.chat

import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Junta los tokens de una respuesta de IA y publica el texto acumulado como máximo cada [intervalMs] ms
 * (≈ 1 vez por frame a 30 Hz; usa 16 para 60 Hz). Un modelo puede emitir 50–100 tokens/s: redibujar la burbuja
 * por cada token satura el hilo principal; agrupándolos el texto sale igual de rápido a la vista pero sin tirones.
 *
 * Siempre publica el texto final completo al terminar el flujo.
 *
 * Llamar desde un dispatcher de un solo hilo (p. ej. `viewModelScope` / `Dispatchers.Main`): el acumulador y el
 * "ticker" comparten estado sin locks.
 *
 * Uso:
 * ```
 * val reply = ChatMessage(text = "", isUser = false)
 * messages += reply
 * tokens.collectBatched { full -> messages.updateText(reply.id, full) }
 * ```
 */
suspend fun Flow<String>.collectBatched(intervalMs: Long = 32L, onText: (String) -> Unit) {
    val acc = StringBuilder()
    var dirty = false
    coroutineScope {
        val ticker = launch {
            while (isActive) {
                delay(intervalMs)
                if (dirty) {
                    dirty = false
                    onText(acc.toString())
                }
            }
        }
        try {
            collect { token ->
                acc.append(token)
                dirty = true
            }
        } finally {
            ticker.cancel()
        }
        if (dirty) onText(acc.toString())
    }
}
