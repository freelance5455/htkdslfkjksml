package com.nexus.ia.pro.ui.chat

import android.net.Uri
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

// ── Constantes hoisteadas: se crean UNA vez en vez de en cada recomposición de cada burbuja ──
private val BubbleShape = RoundedCornerShape(24.dp)
private val ImageShape = RoundedCornerShape(24.dp)
private val RowPadding = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
private val TextPadding = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
private val HideButtonColor = Color(0x941B1A16)

// `background(color, shape)` pinta la forma sin crear una capa de recorte (clip) por burbuja → menos trabajo de GPU al hacer scroll.
private val UserBubbleModifier = Modifier
    .widthIn(max = 320.dp)
    .nexusInkBubble(BubbleShape, elevation = 3.dp)
    .padding(10.dp)
private val AiBubbleModifier = Modifier
    .widthIn(max = 320.dp)
    .nexusBubble(BubbleShape, elevation = 3.dp, fill = NexusColors.Surface)
    .padding(10.dp)

/**
 * Burbuja de un mensaje del historial.
 * Si el mensaje trae imágenes se muestran GRANDES; al tocarlas se abre el visor a pantalla completa
 * (lo gestiona [ChatMessageList] con UN solo diálogo), y cada imagen tiene un botón (ojo) para ocultarla/mostrarla.
 *
 * Skippable: todos sus parámetros son estables ([ChatMessage] es @Immutable, `onImageClick` es una lambda
 * recordada por la lista) → si el mensaje no cambió, Compose NO la recompone al llegar mensajes nuevos.
 */
@Composable
fun ChatMessageBubble(
    message: ChatMessage,
    onImageClick: (Uri) -> Unit,
    modifier: Modifier = Modifier,
) {
    val isUser = message.isUser
    val textColor = if (isUser) NexusColors.Bg else NexusColors.Ink

    Column(
        modifier = modifier.then(RowPadding),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
    ) {
        Column(
            modifier = if (isUser) UserBubbleModifier else AiBubbleModifier,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            message.attachments.forEach { attachment ->
                when (attachment.kind) {
                    AttachmentKind.IMAGE -> ChatImageAttachment(
                        attachment = attachment,
                        onOpenFullscreen = { onImageClick(attachment.uri) },
                    )
                    AttachmentKind.FILE -> ChatFileAttachment(attachment, textColor)
                }
            }
            if (message.text.isNotBlank()) {
                Text(
                    text = message.text,
                    color = textColor,
                    fontSize = 16.sp,
                    modifier = TextPadding,
                )
            }
        }
    }
}

/**
 * Imagen grande dentro de la burbuja, con interruptor Ocultar / Mostrar.
 *  - Visible: foto grande + botón "ojo tachado" arriba a la izquierda. Tocar la foto → pantalla completa.
 *  - Oculta: se contrae a una pastilla "Imagen oculta · Toca para mostrar"; un toque la vuelve a mostrar.
 *
 * La imagen tiene proporción FIJA (1:1): el hueco se reserva desde el primer frame, así cuando Coil termina de
 * cargar la foto la burbuja NO cambia de tamaño (antes saltaba de alto → tirón del scroll).
 */
@Composable
private fun ChatImageAttachment(attachment: ChatAttachment, onOpenFullscreen: () -> Unit) {
    // rememberSaveable con la id del adjunto: cada imagen recuerda su propio estado (también al rotar)
    var hidden by rememberSaveable(attachment.id) { mutableStateOf(false) }

    // animateContentSize → transición suave al contraer/expandir (spec compartido, sin asignaciones)
    Column(Modifier.animateContentSize(NexusMotion.ContentSize)) {
        if (hidden) {
            HiddenImagePill(onClick = { hidden = false })
        } else {
            Box {
                AsyncImage(
                    model = rememberImageRequest(attachment.uri, NexusImageSize.Bubble),
                    contentDescription = "Imagen adjunta: ${attachment.name}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(ImageShape)
                        .clickable(role = Role.Image, onClick = onOpenFullscreen),
                )
                // Botón discreto para ocultar (respuesta táctil inmediata)
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .nexusPressable(pressedScale = 0.85f) { hidden = true }
                        .size(34.dp)
                        .background(HideButtonColor, CircleShape)
                        .border(1.dp, NexusColors.InkEdge, CircleShape)
                        .semantics { contentDescription = "Ocultar imagen" },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Outlined.VisibilityOff, null, tint = NexusColors.Bg, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

/** Pastilla que reemplaza a la imagen cuando está oculta. */
@Composable
private fun HiddenImagePill(onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .nexusPressable(pressedScale = 0.98f, onTap = onClick)
            .defaultMinSize(minHeight = 46.dp)
            .nexusBubble(NexusShapes.Capsule, elevation = 3.dp, fill = NexusColors.Card)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(Icons.Outlined.Visibility, null, tint = NexusColors.Ink2, modifier = Modifier.size(18.dp))
        Text("Imagen oculta", color = NexusColors.Ink2, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Text("Toca para mostrar", color = NexusColors.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1)
    }
}

/** Archivo no-imagen dentro de la burbuja (nombre con ícono). */
@Composable
private fun ChatFileAttachment(attachment: ChatAttachment, textColor: Color) {
    Row(
        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(Icons.Outlined.Description, null, tint = textColor, modifier = Modifier.size(20.dp))
        Text(attachment.name, color = textColor, fontSize = 14.sp, maxLines = 1)
    }
}
