package com.nexus.ia.pro.ui.chat

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties

/**
 * Botón de estrellas + menú flotante con "Cámara" y "Archivos".
 *
 * Rendimiento (60/120 FPS):
 *  • El menú es un [Popup] propio (más ligero que DropdownMenu) animado con UN solo [Animatable] `progress`.
 *  • `progress` se lee ÚNICAMENTE dentro de lambdas `graphicsLayer { }` → las animaciones ocurren en la fase
 *    de dibujo del GPU: cero recomposiciones durante la animación y nada de trabajo en el hilo principal.
 *  • `derivedStateOf` decide si el popup sigue en pantalla (mientras anima el cierre) y solo notifica cuando
 *    el booleano cambia, no en cada frame.
 *  • Cada opción entra escalonada (stagger) leyendo el mismo `progress` con un pequeño desfase.
 */
@Composable
fun NexusComposerMenu(
    onCameraClick: () -> Unit,
    onFilesClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // Estado lógico (sobrevive a rotación)
    var expanded by rememberSaveable { mutableStateOf(false) }

    // 0f = cerrado, 1f = abierto (con spring puede pasar de 1f un instante: es el "rebote")
    val progress = remember { Animatable(0f) }
    LaunchedEffect(expanded) {
        progress.animateTo(
            targetValue = if (expanded) 1f else 0f,
            animationSpec = if (expanded) NexusMotion.MenuOpen else NexusMotion.MenuClose,
        )
    }

    // El popup debe seguir compuesto mientras se anima el cierre. derivedStateOf → notifica solo al cambiar el booleano.
    val popupVisible by remember { derivedStateOf { expanded || progress.value > 0.001f } }

    Box(modifier) {
        // ── Botón circular de estrellas ──
        Box(
            modifier = Modifier
                .nexusPressable(pressedScale = 0.9f) { expanded = !expanded }   // primero: así el fondo también escala
                .size(50.dp)
                .graphicsLayer { rotationZ = 18f * progress.value }              // giro sincronizado con el menú
                .nexusBubble(NexusShapes.Circle, elevation = 5.dp, brush = NexusColors.StarBg)
                .semantics { contentDescription = "Más opciones" },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Outlined.AutoAwesome, null, tint = NexusColors.Ink2, modifier = Modifier.size(24.dp))
        }

        if (popupVisible) {
            val density = LocalDensity.current
            val positionProvider = remember(density) {
                AboveAnchorPositionProvider(
                    marginPx = with(density) { 12.dp.roundToPx() },
                    gapPx = with(density) { 10.dp.roundToPx() },
                )
            }
            Popup(
                popupPositionProvider = positionProvider,
                onDismissRequest = { expanded = false },       // tocar fuera o botón Atrás
                properties = PopupProperties(focusable = true),
            ) {
                MenuPanel(
                    progress = progress,
                    onCamera = { expanded = false; onCameraClick() },
                    onFiles = { expanded = false; onFilesClick() },
                )
            }
        }
    }
}

/** Panel flotante: escala + sube + aparece, todo en la capa gráfica. */
@Composable
private fun MenuPanel(progress: Animatable<Float, *>, onCamera: () -> Unit, onFiles: () -> Unit) {
    val shape = NexusShapes.Bubble
    Column(
        modifier = Modifier
            .graphicsLayer {
                val p = progress.value.coerceAtLeast(0f)
                val scale = 0.82f + 0.18f * p                      // puede pasar de 1 → rebote suave
                scaleX = scale
                scaleY = scale
                alpha = (p * 1.6f).coerceIn(0f, 1f)
                translationY = (1f - p.coerceAtMost(1f)) * 14.dp.toPx()
                transformOrigin = TransformOrigin(0.15f, 1f)       // crece desde el botón (abajo-izquierda)
            }
            .nexusBubble(shape, elevation = 18.dp, fill = NexusColors.BubbleFillStrong)
            .padding(8.dp),
    ) {
        MenuItem(Icons.Outlined.CameraAlt, "Cámara", index = 0, progress = progress, onClick = onCamera)
        MenuItem(Icons.Outlined.Description, "Archivos", index = 1, progress = progress, onClick = onFiles)
    }
}

/** Una opción: ícono en cuadro crema + texto. Entra escalonada y responde al instante al toque. */
@Composable
private fun MenuItem(
    icon: ImageVector,
    label: String,
    index: Int,
    progress: Animatable<Float, *>,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .nexusPressable(pressedScale = 0.96f, pressedAlpha = 0.8f, onTap = onClick)
            .graphicsLayer {
                // Cada opción empieza un poco después de la anterior (stagger de 10 % del recorrido)
                val p = ((progress.value - index * 0.10f) / 0.80f).coerceIn(0f, 1f)
                alpha = p
                translationY = (1f - p) * 10.dp.toPx()
            }
            .clip(NexusShapes.Option)
            .defaultMinSize(minWidth = 196.dp, minHeight = 52.dp)
            .padding(end = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier.size(38.dp).background(NexusColors.Card2, NexusShapes.Circle).border(1.dp, NexusColors.BubbleEdge, NexusShapes.Circle),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = NexusColors.Ink2, modifier = Modifier.size(22.dp))
        }
        Text(
            text = label,
            color = NexusColors.Ink,
            fontWeight = FontWeight.Medium,
            style = MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp),   // tipografía del chat
            modifier = Modifier.padding(start = 12.dp),
        )
    }
}

/** Coloca el popup encima del botón (o debajo si no cabe) y lo mantiene dentro de la pantalla. */
@Stable
private class AboveAnchorPositionProvider(
    private val marginPx: Int,
    private val gapPx: Int,
) : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize,
    ): IntOffset {
        val maxX = (windowSize.width - popupContentSize.width - marginPx).coerceAtLeast(marginPx)
        val x = anchorBounds.left.coerceIn(marginPx, maxX)
        val above = anchorBounds.top - popupContentSize.height - gapPx
        val y = if (above >= marginPx) above else anchorBounds.bottom + gapPx
        return IntOffset(x, y)
    }
}
