package com.nexus.ia.pro.ui.chat

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val ThumbCardShape = NexusShapes.Card
private val ThumbImageShape = RoundedCornerShape(19.dp)

/**
 * Fila de adjuntos pendientes sobre la caja de texto (miniatura + "X" para cancelar).
 *
 * Rendimiento:
 *  • Recibe la [SnapshotStateList] directamente (tipo estable): el padre NO se recompone cuando cambia la lista,
 *    solo esta fila.
 *  • `key` estable (id) + `contentType` → Compose reutiliza y mueve items en vez de recrearlos.
 *  • Las miniaturas se decodifican a 256 px en segundo plano (Coil) → la UI nunca espera a la foto.
 *  • Entrada con "pop" (spring en capa gráfica) y `animateItem()` para que al quitar uno los demás se deslicen.
 *  • `animateContentSize` con spring: la barra crece/se contrae suavemente al añadir/quitar. Sin adjuntos mide 0 dp
 *    (el padding vertical vive en cada item, no en la fila).
 */
@Composable
fun AttachmentPreviewRow(
    attachments: SnapshotStateList<ChatAttachment>,
    onRemove: (ChatAttachment) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyRow(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(NexusMotion.ContentSize),
        contentPadding = PaddingValues(start = 6.dp, end = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(attachments, key = { it.id }, contentType = { it.kind }) { attachment ->
            AttachmentPreviewItem(
                attachment = attachment,
                onRemove = { onRemove(attachment) },
                modifier = Modifier.animateItem(
                    fadeInSpec = NexusMotion.ItemFade,
                    placementSpec = NexusMotion.ItemPlacement,
                    fadeOutSpec = NexusMotion.ItemFade,
                ),
            )
        }
    }
}

@Composable
private fun AttachmentPreviewItem(
    attachment: ChatAttachment,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // "Pop" de entrada: el valor se lee solo en graphicsLayer → sin recomposiciones durante la animación
    val pop = remember { Animatable(0.7f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, NexusMotion.Pop) }

    Box(
        modifier = modifier
            .padding(top = 12.dp, bottom = 8.dp)          // espacio para que la "X" que sobresale no se recorte
            .graphicsLayer {
                val p = pop.value
                scaleX = p
                scaleY = p
                alpha = ((p - 0.7f) / 0.3f).coerceIn(0f, 1f)
            },
    ) {
        Box(
            modifier = Modifier
                .nexusBubble(ThumbCardShape, elevation = 4.dp, fill = NexusColors.BubbleFill)
                .padding(5.dp),
        ) {
            when (attachment.kind) {
                AttachmentKind.IMAGE -> AsyncImage(
                    model = rememberImageRequest(attachment.uri, NexusImageSize.Thumbnail),
                    contentDescription = "Vista previa de ${attachment.name}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(76.dp).clip(ThumbImageShape),
                )
                AttachmentKind.FILE -> Row(
                    modifier = Modifier.size(width = 150.dp, height = 76.dp).padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Outlined.Description, null, tint = NexusColors.Ink2, modifier = Modifier.size(24.dp))
                    Text(
                        text = attachment.name,
                        color = NexusColors.Ink,
                        fontSize = 13.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 8.dp).widthIn(max = 100.dp),
                    )
                }
            }
        }

        // Botón "X" para cancelar (esquina superior derecha) con respuesta táctil inmediata
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = 8.dp, y = (-8).dp)
                .nexusPressable(pressedScale = 0.82f, onTap = onRemove)
                .size(26.dp)
                .nexusInkBubble(NexusShapes.Circle, elevation = 3.dp)
                .border(2.dp, NexusColors.Bg, NexusShapes.Circle)
                .semantics { contentDescription = "Quitar adjunto" },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Outlined.Close, null, tint = NexusColors.Bg, modifier = Modifier.size(14.dp))
        }
    }
}
