package com.nexus.ia.pro.ui.chat

import android.net.Uri
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop

/**
 * Lista del chat optimizada.
 *
 *  • `reverseLayout = true` (mensaje más nuevo = índice 0, anclado ABAJO): al insertar un mensaje o al crecer el
 *    texto de la IA en streaming, el borde inferior no se mueve → no hace falta calcular "último índice" ni
 *    forzar scrolls en cada token. Es el patrón nativo de las apps de chat.
 *  • `key = id` → Compose mueve/reutiliza items en vez de recrearlos al insertar.
 *  • `contentType` (usuario / IA) → se reciclan composiciones entre burbujas del mismo tipo.
 *  • Esta función NO lee el contenido de la lista al componerse: no se recompone al llegar un mensaje ni por token.
 *  • El auto-scroll corre en un `snapshotFlow` (fuera de la composición): cero recomposiciones extra.
 *  • UN solo visor a pantalla completa para toda la lista (en vez de un estado + Dialog por burbuja).
 *
 * `isThinking = true` muestra [NexusThinkingIndicator] justo debajo del último mensaje (hasta que llegue el primer token).
 *
 * Auto-scroll: baja al mensaje nuevo si es tuyo, o si ya estabas al final. Si subiste a leer el historial
 * y llega una respuesta, NO te arrastra hacia abajo.
 */
@Composable
fun ChatMessageList(
    messages: SnapshotStateList<ChatMessage>,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
    contentPadding: PaddingValues = PaddingValues(vertical = 8.dp),
    isThinking: Boolean = false,
) {
    // Estado del visor, hoisteado fuera de los items
    var fullscreenUri by remember { mutableStateOf<Uri?>(null) }
    val onImageClick = remember<(Uri) -> Unit> { { uri -> fullscreenUri = uri } }
    val onDismissViewer = remember<() -> Unit> { { fullscreenUri = null } }

    // Vista invertida (sin copiar): índice 0 = mensaje más nuevo. Las lecturas siguen siendo observables.
    val newestFirst = remember(messages) { messages.asReversed() }

    // Auto-scroll nativo: animateScrollToItem(0) es corto (el mensaje nuevo ya está pegado al borde inferior).
    // collectLatest: si llega otro mensaje a mitad de la animación, se cancela y arranca la nueva (sin cola ni tirones).
    LaunchedEffect(listState, messages) {
        snapshotFlow { messages.lastOrNull()?.id }
            .distinctUntilChanged()
            .drop(1)                                   // ignora el valor inicial (el historial ya empieza abajo)
            .collectLatest {
                val last = messages.lastOrNull() ?: return@collectLatest
                // índice ≤ 1 = el usuario estaba pegado al final (el mensaje nuevo ocupa el 0)
                if (last.isUser || listState.firstVisibleItemIndex <= 1) {
                    listState.animateScrollToItem(0)
                }
            }
    }

    // Al aparecer "Nexus pensando" (ocupa el índice 0, bajo el último mensaje) lo traemos a la vista si estabas al final
    LaunchedEffect(isThinking, listState) {
        if (isThinking && listState.firstVisibleItemIndex <= 1) listState.animateScrollToItem(0)
    }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize(),
        reverseLayout = true,
        contentPadding = contentPadding,
    ) {
        if (isThinking) {
            item(key = "nx-thinking", contentType = "thinking") {
                NexusThinkingIndicator(
                    Modifier.animateItem(
                        fadeInSpec = NexusMotion.ItemFade,
                        placementSpec = NexusMotion.ItemPlacement,
                        fadeOutSpec = NexusMotion.ItemFade,
                    ),
                )
            }
        }
        items(
            items = newestFirst,
            key = { it.id },
            contentType = { it.isUser },
        ) { message ->
            ChatMessageBubble(
                message = message,
                onImageClick = onImageClick,
                modifier = Modifier.animateItem(
                    fadeInSpec = NexusMotion.ItemFade,
                    placementSpec = NexusMotion.ItemPlacement,
                    fadeOutSpec = NexusMotion.ItemFade,
                ),
            )
        }
    }

    // Visor a pantalla completa (solo existe mientras haya una imagen seleccionada)
    fullscreenUri?.let { uri -> FullscreenImageDialog(uri = uri, onDismiss = onDismissViewer) }
}
