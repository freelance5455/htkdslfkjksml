package com.nexus.ia.pro.ui.chat

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage

/**
 * Visor de imagen a pantalla completa.
 *  - "X" clara arriba a la derecha (también cierra el botón Atrás del sistema).
 *  - Pellizcar para hacer zoom (1x–5x), arrastrar para mover, doble toque para alternar zoom.
 */
@Composable
fun FullscreenImageDialog(uri: Uri, onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        // usePlatformDefaultWidth = false → el diálogo ocupa toda la pantalla
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        var scale by remember { mutableFloatStateOf(1f) }
        var offset by remember { mutableStateOf(Offset.Zero) }

        Box(Modifier.fillMaxSize().background(NexusColors.Scrim)) {
            AsyncImage(
                model = rememberImageRequest(uri, NexusImageSize.Fullscreen, crossfadeMs = 160),
                contentDescription = "Imagen a pantalla completa",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(onDoubleTap = {
                            if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                        })
                    }
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            offset = if (scale == 1f) Offset.Zero else offset + pan
                        }
                    }
                    // Forma con lambda: scale/offset se leen en la fase de capa → pellizcar NO recompone en cada frame
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offset.x
                        translationY = offset.y
                    },
            )

            // Botón X para volver al chat
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
                    .nexusPressable(pressedScale = 0.9f, onTap = onDismiss)
                    .size(50.dp)
                    .nexusBubble(NexusShapes.Circle, elevation = 8.dp, fill = NexusColors.Bg)
                    .semantics { contentDescription = "Cerrar imagen" },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Outlined.Close, null, tint = NexusColors.Ink, modifier = Modifier.size(24.dp))
            }
        }
    }
}
