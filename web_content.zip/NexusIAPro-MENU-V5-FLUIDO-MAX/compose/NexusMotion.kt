package com.nexus.ia.pro.ui.chat

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize

/**
 * Resortes (springs) compartidos por toda la UI del chat.
 * Tenerlos en un solo sitio garantiza que todo "se sienta" igual y evita crear specs nuevos en cada recomposición
 * (cada `spring(...)` inline en un composable es una asignación por recomposición).
 * Los springs son físicos (no dependen de una duración fija) → se interrumpen y revierten sin saltos.
 */
internal object NexusMotion {
    /** Apertura del menú: rápido con un rebote casi imperceptible. */
    val MenuOpen = spring<Float>(dampingRatio = 0.72f, stiffness = 520f)

    /** Cierre del menú: sin rebote y muy rápido, para que se sienta instantáneo. */
    val MenuClose = spring<Float>(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessHigh)

    /** Al presionar: baja inmediatamente (respuesta táctil al instante). */
    val PressDown = spring<Float>(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessHigh)

    /** Al soltar: vuelve con un pequeño rebote elástico. */
    val PressUp = spring<Float>(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium)

    /** Aparición de miniaturas ("pop"). */
    val Pop = spring<Float>(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow)

    /** Contraer/expandir contenido (imagen oculta, fila de adjuntos). */
    val ContentSize = spring<IntSize>(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)

    /** Desplazamiento de elementos de lista al insertar/quitar (animateItem). Sin rebote → cero "temblor". */
    val ItemPlacement = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = Spring.StiffnessMedium,
        visibilityThreshold = IntOffset.VisibilityThreshold,
    )

    /** Fundido de entrada/salida de elementos de lista. */
    val ItemFade = spring<Float>(stiffness = Spring.StiffnessMedium)
}

/** Tamaños máximos (px) a los que Coil decodifica cada imagen → menos memoria, menos trabajo, scroll fluido. */
internal object NexusImageSize {
    const val Thumbnail = 256     // miniatura 76 dp del compositor
    const val Bubble = 1080       // foto grande dentro del chat
    const val Fullscreen = 2048   // visor a pantalla completa (tope para no reventar la RAM con fotos de 12+ MP)
}
