package com.nexus.ia.pro.ui.chat

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val ThinkShape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp, bottomEnd = 22.dp, bottomStart = 8.dp)
private val ThinkTextGray = Color(0xFF8A8678)
private val ThinkShadow = Color(0x403A321C)
private val ThinkAccent = Color(0xFF6E5C28)
private val ThinkPhases = listOf("Nexus pensando", "Nexus analizando", "Nexus redactando")

/**
 * "Nexus pensando" premium: tarjeta vainilla + núcleo de tinta que respira, onda sonar y cometa orbital +
 * texto con brillo deslizante y frases que se relevan solas (misma identidad que la versión web).
 *
 * Rendimiento: TODA la animación vive en `InfiniteTransition` y se lee solo en fase de dibujo
 * (`drawWithCache` / `drawWithContent` / `graphicsLayer`) → cero recomposiciones por frame. Lo único que
 * recompone (una vez cada ~4 s) es el cambio de frase, y es un composable minúsculo.
 * Si el usuario desactiva animaciones del sistema (escala 0), las transiciones infinitas se quedan quietas solas.
 */
@Composable
fun NexusThinkingIndicator(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "nxThink")
    // Se guardan como State (sin `by`): se leen dentro de lambdas de dibujo
    val spin = infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(1900, easing = LinearEasing)), label = "spin")
    val ripple = infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(3400, easing = LinearEasing)), label = "ripple")
    val breath = infinite.animateFloat(0.9f, 1.08f, infiniteRepeatable(tween(1700), RepeatMode.Reverse), label = "breath")
    val shimmer = infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "shimmer")

    // Entrada con resorte (escala + sube + aparece), en capa gráfica
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow)) }

    var phase by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(4000)
            phase = (phase + 1) % ThinkPhases.size
        }
    }

    Row(modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
        Row(
            modifier = Modifier
                .graphicsLayer {
                    val e = enter.value
                    alpha = e.coerceIn(0f, 1f)
                    val s = 0.9f + 0.1f * e
                    scaleX = s
                    scaleY = s
                    translationY = (1f - e) * 12.dp.toPx()
                    transformOrigin = TransformOrigin(0f, 1f)
                }
                .shadow(10.dp, ThinkShape, clip = false, ambientColor = ThinkShadow, spotColor = ThinkShadow)
                .background(NexusColors.Surface, ThinkShape)
                .border(1.dp, NexusColors.BubbleEdge, ThinkShape)
                .padding(start = 12.dp, end = 20.dp, top = 11.dp, bottom = 11.dp)
                .semantics { contentDescription = "Nexus pensando" },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ThinkingOrb(spin = spin, ripple = ripple, breath = breath)

            AnimatedContent(
                targetState = phase,
                transitionSpec = {
                    (fadeIn(tween(260)) + slideInVertically(tween(260)) { it / 3 }) togetherWith
                        (fadeOut(tween(160)) + slideOutVertically(tween(160)) { -it / 3 })
                },
                // Offscreen + SrcAtop: el brillo solo "pinta" donde hay letras
                modifier = Modifier
                    .padding(start = 11.dp)
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithCache {
                        val w = size.width
                        onDrawWithContent {
                            drawContent()
                            val x = -0.35f * w + 1.7f * w * shimmer.value
                            drawRect(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(Color.Transparent, NexusColors.Ink, Color.Transparent),
                                    startX = x - 0.3f * w,
                                    endX = x + 0.3f * w,
                                ),
                                blendMode = BlendMode.SrcAtop,
                            )
                        }
                    },
                label = "nxThinkPhase",
            ) { index ->
                Text(
                    text = ThinkPhases[index],
                    color = ThinkTextGray,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                )
            }
        }
    }
}

/** Esfera de tinta + onda sonar + cometa orbital, todo dibujado en un solo Canvas sin recomposiciones. */
@Composable
private fun ThinkingOrb(
    spin: androidx.compose.runtime.State<Float>,
    ripple: androidx.compose.runtime.State<Float>,
    breath: androidx.compose.runtime.State<Float>,
) {
    Box(
        Modifier
            .size(28.dp)
            .drawWithCache {
                val c = center
                val r = size.minDimension / 2f
                val ringW = 2.2.dp.toPx()
                val ringR = r - ringW / 2f
                val sphere = Brush.radialGradient(
                    colors = listOf(Color(0xFF68644F), Color(0xFF2B2920), Color(0xFF12110E)),
                    center = Offset(c.x - r * 0.18f, c.y - r * 0.24f),
                    radius = r * 0.72f,
                )
                val tail = Brush.sweepGradient(
                    0.00f to Color.Transparent,
                    0.42f to Color.Transparent,
                    0.64f to NexusColors.Ink.copy(alpha = 0.10f),
                    0.89f to NexusColors.Ink.copy(alpha = 0.45f),
                    1.00f to NexusColors.Ink.copy(alpha = 0.92f),
                    center = c,
                )
                onDrawBehind {
                    val rp = ripple.value
                    val b = breath.value
                    // onda sonar: nace de la esfera y se desvanece
                    drawCircle(
                        color = ThinkAccent.copy(alpha = 0.55f * (1f - (rp / 0.65f).coerceAtMost(1f))),
                        radius = r * 0.5f * (1f + 1.05f * rp),
                        style = Stroke(1.5.dp.toPx()),
                    )
                    // esfera que respira
                    drawCircle(brush = sphere, radius = r * 0.5f * b, center = c)
                    // cometa orbital: arco con cola + punto satélite
                    rotate(spin.value, pivot = c) {
                        drawArc(
                            brush = tail,
                            startAngle = 0f,
                            sweepAngle = 360f,
                            useCenter = false,
                            topLeft = Offset(c.x - ringR, c.y - ringR),
                            size = Size(ringR * 2f, ringR * 2f),
                            style = Stroke(ringW, cap = StrokeCap.Round),
                        )
                        drawCircle(NexusColors.Ink, radius = 3.dp.toPx(), center = Offset(c.x + ringR, c.y))
                    }
                }
            },
    )
}
