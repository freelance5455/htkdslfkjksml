package com.nexus.ia.pro.ui.chat

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * Paleta crema / tinta de Nexus IA (misma que el tema web).
 * Si tu app ya tiene un MaterialTheme propio, reemplaza estos valores por tus tokens.
 */
internal object NexusColors {
    val Bg = Color(0xFFFFFCF4)        // fondo de pantalla
    val Surface = Color(0xFFFFFEFA)   // tarjetas, menú, input
    val Card = Color(0xFFFBF7EB)
    val Card2 = Color(0xFFF5F0E1)     // fondo de íconos
    val Ink = Color(0xFF1B1A16)       // texto principal / burbuja del usuario
    val Ink2 = Color(0xFF3B392F)
    val Muted = Color(0xFF726F60)
    val Line = Color(0x1A3A321C)      // bordes finos
    val Press = Color(0x1A6E5C28)     // estado presionado
    val Scrim = Color(0xF2161510)     // fondo del visor a pantalla completa
    val StarBg = Brush.linearGradient(listOf(Color(0xFFFBF5E2), Color(0xFFEDE3C5)))

    // ── Estilo burbuja iOS ──
    val BubbleFill = Color(0xF0FFFEFA)          // crema casi opaco (94 %): se siente flotante pero legible
    val BubbleFillStrong = Color(0xF7FFFEFA)    // menús desplegables (97 %)
    val BubbleShadow = Color(0x403A321C)        // sombra cálida, nunca gris frío
    val BubbleEdge = Brush.verticalGradient(    // brillo arriba → línea fina más oscura abajo
        listOf(Color(0xE6FFFFFF), Color(0x1F3A321C))
    )
    val InkGradient = Brush.linearGradient(listOf(Color(0xFF3A382D), Color(0xFF1B1A16)))
    val InkShadow = Color(0x661B1A16)
    val InkEdge = Brush.verticalGradient(listOf(Color(0x38FFFFFF), Color(0x0DFFFFFF)))
}
