package com.nexus.ia.pro.ui.chat

import android.widget.Toast
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

/**
 * Pantalla de ejemplo que conecta TODAS las piezas. Úsala como guía para tu pantalla real:
 *
 *   menú ✦ ──► Cámara  → launchers.launchCamera → TakePicture   ─┐
 *            ► Archivos → launchers.launchFiles  → GetContent    ─┼─► ComposerState.attachments (miniatura + X)
 *   Enviar ──► ChatMessage(text + attachments) ──► historial ──► ChatMessageList ──► ChatMessageBubble
 *
 * Reglas para mantenerlo fluido:
 *  • El estado (`messages`, `composer`) es estable y sus lambdas solo capturan valores estables → esta pantalla
 *    no se recompone al teclear ni al llegar mensajes: solo las piezas que leen ese estado.
 *  • El auto-scroll vive DENTRO de [ChatMessageList] (snapshotFlow): no hace falta LaunchedEffect aquí.
 *  • Mientras esperas el primer token pasa `isThinking = true` a [ChatMessageList] (animación "Nexus pensando").
 *  • Para respuestas de IA en streaming, añade un mensaje vacío y actualízalo con `updateText` (ver TODO).
 */
@Composable
fun NexusChatScreenExample() {
    val composer = rememberComposerState()
    val messages = remember { mutableStateListOf<ChatMessage>() }

    // Cámara + selector de archivos: al terminar, el adjunto queda en el compositor (sin enviar)
    val context = LocalContext.current
    val launchers = rememberAttachmentLaunchers(
        onAttachment = composer::addAttachment,
        // Mensajes como "Sin permiso de cámara…" → Toast (o Snackbar si prefieres)
        onMessage = { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() },
        // config = AttachmentConfig(requestStoragePermission = true),  // solo si lees la galería con MediaStore
    )

    // Lambda recordada: misma instancia entre recomposiciones → ChatInputBar se puede saltar
    val onSend = remember(composer, messages) {
        {
            messages += composer.buildMessageAndClear()
            /* TODO: llamar a la IA. Streaming fluido:
             *   val reply = ChatMessage(text = "", isUser = false)
             *   messages += reply
             *   viewModel.tokens(prompt).collectBatched { full -> messages.updateText(reply.id, full) }
             */
        }
    }

    Scaffold(
        containerColor = NexusColors.Bg,
        bottomBar = {
            ChatInputBar(
                state = composer,
                onCameraClick = launchers.launchCamera,
                onFilesClick = launchers.launchFiles,
                onSend = onSend,
            )
        },
    ) { padding ->
        ChatMessageList(
            messages = messages,
            modifier = Modifier.padding(padding),
        )
    }
}
