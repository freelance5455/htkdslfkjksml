# Nexus IA · Cámara / Archivos con permisos y animaciones premium (Jetpack Compose)

Copia los `.kt` a `app/src/main/java/com/nexus/ia/pro/ui/chat/`, `res/xml/file_paths.xml` a `app/src/main/res/xml/`
y aplica `AndroidManifest_snippet.xml` a tu manifest.

## 1) Dependencias (build.gradle.kts del módulo app)
```kotlin
implementation(platform("androidx.compose:compose-bom:2024.10.01"))   // o más reciente (animateItem requiere foundation 1.7+)
implementation("androidx.activity:activity-compose:1.9.3")
implementation("androidx.compose.material3:material3")
implementation("androidx.compose.material:material-icons-extended")
implementation("io.coil-kt:coil-compose:2.7.0")                       // imágenes (decodifica fuera del main thread)
implementation("com.google.accompanist:accompanist-permissions:0.36.0") // rememberPermissionState
```

## 2) Permisos
**Cámara** (siempre): pulsar *Cámara* →
1. Si CAMERA ya está concedido → abre la cámara directo.
2. Primera vez → aparece la **ventana nativa del sistema** pidiendo `Manifest.permission.CAMERA`.
3. Si lo rechazó una vez → diálogo Nexus explicando el motivo y luego la ventana nativa otra vez.
4. Si marcó "No volver a preguntar" → diálogo Nexus con botón **Abrir ajustes**.
5. Al conceder, la cámara se abre sola (sin tener que pulsar de nuevo).

**Archivos**: el selector del sistema (`GetContent`, Storage Access Framework) **no necesita permiso**: el usuario
concede acceso al elegir el archivo. Por eso `AttachmentConfig.requestStoragePermission` es `false` por defecto.
Si lo activas (`true`), se pide el permiso correcto según la versión (`storageReadPermissions()`):

| Android | Permisos |
|---|---|
| 14+ (API 34) | `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_VISUAL_USER_SELECTED` (acceso parcial permitido) |
| 13 (API 33) | `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO` |
| 12L o menos | `READ_EXTERNAL_STORAGE` |

Aun así el selector se abre siempre, conceda o no el permiso. Nota: no existe permiso READ_MEDIA para PDF/documentos.

## 3) Qué se hizo para que vaya fluido (60/120 FPS)
- **Menú propio con `Popup`** y un único `Animatable progress`; se lee solo dentro de `graphicsLayer { }` → la animación
  corre en la capa gráfica, **cero recomposiciones por frame**. Entrada escalonada de las opciones y spring con rebote suave.
- **`derivedStateOf`**: visibilidad del popup (mientras anima el cierre) y `canSend` del botón enviar → solo recomponen
  cuando el booleano cambia, no en cada letra o frame.
- **`Modifier.nexusPressable`**: escala con spring + vibración suave; el valor vive en un `Animatable` leído en
  `graphicsLayer` → respuesta táctil inmediata sin recomponer.
- **`ChatInputBar` no lee estado**: el texto, los adjuntos y `canSend` los leen solo sus hijos (`ComposerTextField`,
  `AttachmentPreviewRow`, `SendButton`).
- **Miniaturas**: `LazyRow` con `key` estable (id) + `contentType`, `animateItem()` y "pop" en capa gráfica; Coil
  decodifica a 256 px en segundo plano; chat 1080 px; pantalla completa 2048 px.
- **Sin bloqueos del main thread**: crear el archivo temporal de la cámara y consultar el nombre/tipo del archivo
  elegido corren en `Dispatchers.IO`.
- **Estabilidad**: `ChatAttachment`/`ChatMessage` son `@Immutable`, `AttachmentLaunchers` es `@Stable` y su instancia
  no cambia entre recomposiciones. Con Kotlin 2.0.20+ (strong skipping) las lambdas se recuerdan solas.

Consejos extra para producción: genera un **Baseline Profile** y prueba siempre en build `release` (el modo debug de
Compose es mucho más lento); revisa con Layout Inspector → "Recomposition counts".

## 4) Optimización de fluidez del chat (V5)

**LazyColumn (`ChatMessageList`)**
- `reverseLayout = true`: el mensaje nuevo (y el texto de la IA creciendo en streaming) queda anclado abajo; no hay que
  calcular índices ni forzar scroll por token.
- `key = { it.id }` + `contentType = { it.isUser }`; ids únicos con `AtomicLong` (antes `System.nanoTime()` podía repetirse
  y una key repetida crashea la lista).
- La función de la lista no lee el contenido al componerse → no se recompone al llegar mensajes ni por token.
- Auto-scroll con `snapshotFlow` + `collectLatest` + `animateScrollToItem(0)` (nativo, corto, cancelable). Baja si el mensaje
  nuevo es tuyo o ya estabas al final; si estás leyendo arriba, no te arrastra.
- `animateItem()` con springs compartidos y sin rebote (inserción suave, sin temblor).
- UN solo `FullscreenImageDialog` para toda la lista (antes: un estado + un Dialog por burbuja).

**Estabilidad**
- `ComposerState` ahora es `@Stable`; `canSend` es un `derivedStateOf` dentro de la clase (solo notifica al cambiar el booleano).
- `ChatMessage`/`ChatAttachment` siguen `@Immutable` (data class → la burbuja se salta si el mensaje no cambió).
- `ChatMessageBubble` recibe `onImageClick: (Uri) -> Unit` (lambda recordada por la lista) en vez de guardar estado propio.
  **Cambio de API:** si la llamabas como `ChatMessageBubble(msg)`, usa `ChatMessageList` o pasa `onImageClick`.

**Menos trabajo por frame**
- Formas, modificadores y springs hoisteados a constantes (cero asignaciones por recomposición).
- `background(color, shape)` en lugar de `clip + background` en burbujas, barra, botones y miniaturas (sin capa de recorte).
- Imágenes del chat con proporción fija 1:1: el alto se reserva desde el primer frame y no hay salto de layout cuando Coil
  termina de cargar (era una causa clásica de tirón al hacer scroll). Cámbialo en `ChatImageAttachment` si prefieres otra proporción.
- Caja de texto con `BasicTextField` (sin la decoración pesada de Material `TextField`).

**Streaming de la IA**
```kotlin
val reply = ChatMessage(text = "", isUser = false)
messages += reply
tokens.collectBatched { full -> messages.updateText(reply.id, full) }   // ≤ 1 actualización cada 32 ms
```

## 5) "Nexus pensando" premium (V5.1)
- **HTML (`rebuild_nexus/zoe-nova-ia.html` y `original.html`):** nuevo bloque `<style id="nexus-thinking-v2">` + marcado de `showTyping()`.
  Tarjeta vainilla con rayo de luz que recorre el borde, núcleo de tinta que respira con onda sonar y cometa orbital, texto con
  brillo deslizante y frases que se relevan solas (Nexus pensando → analizando → redactando) en CSS puro, sin timers.
  Solo `transform`/`opacity`; se pausa en segundo plano; con `prefers-reduced-motion` queda estático.
- **Compose:** `NexusThinkingIndicator` (misma identidad). Úsalo con `ChatMessageList(isThinking = true)`.
- La lógica (`typing.remove()`, clases `.typing-row`/`.bubble-row.ai`) no se tocó.

| Archivo | Responsabilidad |
|---|---|
| `NexusColors.kt` | Paleta crema/tinta |
| `NexusMotion.kt` | Springs y tamaños de imagen compartidos |
| `NexusPressable.kt` | Toque premium (escala + vibración) sin recomposiciones |
| `NexusImage.kt` | `ImageRequest` de Coil con tamaño máximo |
| `ChatModels.kt` | `ChatAttachment`, `ChatMessage`, `ComposerState` |
| `AttachmentPermissions.kt` | Permisos por versión + diálogos Nexus |
| `AttachmentLaunchers.kt` | Permiso CAMERA (Accompanist) + `TakePicture` + `GetContent` |
| `NexusComposerMenu.kt` | Botón ✦ + menú Cámara / Archivos |
| `AttachmentPreviewRow.kt` | Miniaturas con ✕ |
| `ChatInputBar.kt` | Barra de entrada |
| `ChatMessageList.kt` | **NUEVO** · LazyColumn optimizado (reverseLayout, key, contentType, auto-scroll, visor único) |
| `NexusThinkingIndicator.kt` | **NUEVO** · "Nexus pensando" premium (núcleo orbital + brillo + frases), 0 recomposiciones por frame |
| `ChatStreaming.kt` | **NUEVO** · `collectBatched`: agrupa tokens de la IA a ≤1 actualización por frame |
| `ChatMessageBubble.kt` | Foto grande, ocultar/mostrar, abrir visor |
| `FullscreenImageDialog.kt` | Pantalla completa con ✕, zoom y arrastre |
| `NexusChatScreenExample.kt` | Ejemplo que une todo |

Nota: no se pudo compilar aquí (sin SDK de Android). Si Gradle marca algún import o versión, pégame el error y lo ajusto.

## 6) Estilo burbuja iOS (V5.4)
Todos los botones, campos y contenedores interactivos comparten ahora la misma estética Cupertino.
- **Formas** (`NexusShapes.kt`): `Capsule` (barra de texto, botones anchos), `Circle` (enviar, ✦, cerrar), `Bubble` 28 dp (menús, diálogos), `Card` 24 dp (miniaturas), `Option` 26 dp (opciones de menú). Declaradas una sola vez.
- **Burbuja flotante** (`NexusBubble.kt`): `nexusBubble(...)` = sombra cálida suave + fondo casi opaco + borde fino con brillo superior; `nexusInkBubble(...)` para el botón enviar y la burbuja del usuario (degradado de tinta + brillo).
- **Feedback táctil** (`NexusPressable.kt`): al presionar escala con resorte **y** baja la opacidad (`pressedAlpha`, por defecto 0.88), sincronizadas desde un solo `Animatable`; se leen en `graphicsLayer` → 0 recomposiciones.
- **Aplicado en:** barra de entrada (cápsula), botón enviar (ahora flecha ↑ estilo iPhone), botón ✦ flotante, menú desplegable y sus opciones, miniaturas y su ✕, burbujas del chat, indicador "Nexus pensando", botón cerrar del visor y diálogo de permisos.
- **HTML** (`original.html` y `rebuild_nexus/zoe-nova-ia.html`): bloque `<style id="nexus-ios-bubble">` al final del documento con las mismas reglas (cápsulas, sombras, bordes con brillo, `:active` con escala + opacidad, respeta `prefers-reduced-motion`). No se tocó ninguna lógica ni los colores del tema.

| Archivo | Responsabilidad |
|---|---|
| `NexusShapes.kt` | **NUEVO** · Formas cápsula/burbuja compartidas |
| `NexusBubble.kt` | **NUEVO** · `nexusBubble` / `nexusInkBubble` (sombra + fondo + borde con brillo) |
