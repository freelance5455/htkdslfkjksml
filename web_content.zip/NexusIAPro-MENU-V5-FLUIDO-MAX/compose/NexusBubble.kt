package com.nexus.ia.pro.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Efecto "burbuja flotante" (iOS):
 *   sombra suave  →  fondo sólido/semitransparente  →  borde fino con brillo superior.
 *
 * Solo usa `shadow`, `background` y `border` (todo en la fase de dibujo): no añade capas de recorte
 * ni recomposiciones. Colócalo DESPUÉS de `nexusPressable` / `size` para que la burbuja entera escale al tocar.
 */
internal fun Modifier.nexusBubble(
    shape: Shape = NexusShapes.Capsule,
    elevation: Dp = 8.dp,
    fill: Color = NexusColors.BubbleFill,
    borderWidth: Dp = 1.dp,
): Modifier = this
    .shadow(elevation, shape, clip = false, ambientColor = NexusColors.BubbleShadow, spotColor = NexusColors.BubbleShadow)
    .background(fill, shape)
    .border(borderWidth, NexusColors.BubbleEdge, shape)

/** Igual que [nexusBubble] pero con un degradado de relleno (por ejemplo el botón ✦ crema). */
internal fun Modifier.nexusBubble(
    shape: Shape,
    elevation: Dp,
    brush: Brush,
    borderWidth: Dp = 1.dp,
): Modifier = this
    .shadow(elevation, shape, clip = false, ambientColor = NexusColors.BubbleShadow, spotColor = NexusColors.BubbleShadow)
    .background(brush, shape)
    .border(borderWidth, NexusColors.BubbleEdge, shape)

/** Burbuja de tinta (botón enviar, burbuja del usuario): degradado oscuro + brillo fino arriba. */
internal fun Modifier.nexusInkBubble(
    shape: Shape = NexusShapes.Circle,
    elevation: Dp = 6.dp,
): Modifier = this
    .shadow(elevation, shape, clip = false, ambientColor = NexusColors.InkShadow, spotColor = NexusColors.InkShadow)
    .background(NexusColors.InkGradient, shape)
    .border(1.dp, NexusColors.InkEdge, shape)
