package com.nexus.ia.pro.ui.chat

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Opciones de comportamiento de los adjuntos.
 *
 * @param requestStoragePermission Si es `true`, antes de abrir el selector de archivos se pide el permiso de
 *   lectura de almacenamiento que corresponda a la versión de Android (ver [storageReadPermissions]).
 *   Por defecto `false`: el selector del sistema (GetContent) NO lo necesita y pedirlo sin necesidad
 *   empeora la experiencia y complica la política de Google Play. El selector se abre SIEMPRE,
 *   aunque el usuario rechace ese permiso.
 */
data class AttachmentConfig(val requestStoragePermission: Boolean = false)

/** Acciones estables para conectar al menú (la instancia no cambia entre recomposiciones). */
@Stable
class AttachmentLaunchers(
    val launchCamera: () -> Unit,
    val launchFiles: () -> Unit,
)

/**
 * Une permisos + contratos de Android y devuelve las acciones para el menú.
 *
 *  Cámara   → verifica CAMERA → (explicación si hace falta) → ventana nativa del sistema → TakePicture.
 *  Archivos → (opcional) permiso de almacenamiento según la versión → GetContent.
 *
 * Esta función también muestra, cuando corresponde, los diálogos informativos de permisos (son ventanas
 * propias que no afectan al layout), así que solo tienes que llamarla una vez en tu pantalla.
 *
 * Todo el trabajo de disco (crear archivo temporal, consultar el nombre) corre en `Dispatchers.IO`:
 * el hilo principal nunca se bloquea.
 *
 * @param onAttachment se llama con el adjunto listo (solo se añade al compositor; NO se envía).
 * @param onMessage    mensajes cortos para el usuario (p. ej. permiso denegado) → muéstralos en Toast/Snackbar.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun rememberAttachmentLaunchers(
    onAttachment: (ChatAttachment) -> Unit,
    onMessage: (String) -> Unit = {},
    config: AttachmentConfig = AttachmentConfig(),
): AttachmentLaunchers {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentOnAttachment by rememberUpdatedState(onAttachment)
    val currentOnMessage by rememberUpdatedState(onMessage)

    // ── Estado (sobrevive a rotación y a que Android recree la Activity) ──
    var pendingPhotoUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    var cameraAsked by rememberSaveable { mutableStateOf(false) }          // ya pedimos CAMERA alguna vez
    var prompt by rememberSaveable { mutableStateOf<PermissionPrompt?>(null) }

    // ── Contratos de Android ──
    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
        val uri = pendingPhotoUri
        pendingPhotoUri = null
        if (uri != null) {
            if (saved) currentOnAttachment(ChatAttachment(uri = uri, kind = AttachmentKind.IMAGE, name = "Foto"))
            else scope.launch(Dispatchers.IO) { runCatching { context.contentResolver.delete(uri, null, null) } } // limpia el temporal
        }
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            // Consultar nombre/tipo es I/O → fuera del hilo principal
            currentOnAttachment(withContext(Dispatchers.IO) { context.toAttachment(uri) })
        }
    }

    /** Crea el Uri temporal en IO y abre la app de cámara. */
    fun openCamera() {
        scope.launch {
            val uri = withContext(Dispatchers.IO) { context.newCameraUri() }
            pendingPhotoUri = uri
            try {
                takePicture.launch(uri)
            } catch (e: ActivityNotFoundException) {
                pendingPhotoUri = null
                currentOnMessage("No hay una app de cámara disponible")
            }
        }
    }

    // ── Permiso de CÁMARA (Accompanist) ──
    val cameraPermission = rememberPermissionState(Manifest.permission.CAMERA) { granted ->
        // Se ejecuta justo después de que el usuario responde en la ventana nativa del sistema
        if (granted) openCamera() else currentOnMessage("Sin permiso de cámara no se puede tomar la foto")
    }

    // ── Permisos de ALMACENAMIENTO (solo si se activó en la config) ──
    val storagePermissions = remember(config.requestStoragePermission) {
        if (config.requestStoragePermission) storageReadPermissions() else emptyList()
    }
    val storagePermission = rememberMultiplePermissionsState(storagePermissions) {
        // Conceda o no el permiso, el selector del sistema funciona igual → siempre se abre
        pickFile.launch("*/*")
    }

    // ── Acciones estables que usa el menú ──
    val launchers = remember(storagePermissions) {
        AttachmentLaunchers(
            launchCamera = {
                val status = cameraPermission.status
                when {
                    status.isGranted -> openCamera()                       // ya concedido → directo
                    status.shouldShowRationale -> prompt = PermissionPrompt.CameraRationale
                    cameraAsked -> prompt = PermissionPrompt.CameraSettings // bloqueado → Ajustes
                    else -> { cameraAsked = true; cameraPermission.launchPermissionRequest() } // 1ª vez → ventana nativa
                }
            },
            launchFiles = {
                val hasAccess = storagePermissions.isEmpty() || storagePermission.permissions.any { it.status.isGranted }
                // "any": en Android 14+ el acceso parcial (fotos elegidas) ya es suficiente
                if (hasAccess) pickFile.launch("*/*") else storagePermission.launchMultiplePermissionRequest()
            },
        )
    }

    // ── Diálogos informativos (antes de la ventana nativa / para ir a Ajustes) ──
    prompt?.let { current ->
        NexusPermissionDialog(
            prompt = current,
            onDismiss = { prompt = null },
            onConfirm = {
                prompt = null
                when (current) {
                    PermissionPrompt.CameraRationale -> { cameraAsked = true; cameraPermission.launchPermissionRequest() }
                    PermissionPrompt.CameraSettings -> context.openAppSettings()
                }
            },
        )
    }

    return launchers
}

/** Crea un archivo temporal en cache/camera y devuelve su Uri seguro (FileProvider). Llamar desde IO. */
private fun Context.newCameraUri(): Uri {
    val dir = File(cacheDir, "camera").apply { mkdirs() }
    val file = File.createTempFile("nexus_", ".jpg", dir)
    return FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
}
