package com.nexus.ia.pro.ui.chat

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import kotlinx.coroutines.launch

/**
 * Toque "premium" estilo iOS: escala con resorte + leve bajada de opacidad al presionar + vibración suave al soltar.
 *
 * Por qué es rápido:
 *  • La escala vive en un [Animatable] y se lee SOLO dentro de `graphicsLayer { }` → se aplica en la fase de
 *    dibujo. El composable NO se recompone mientras el dedo está presionando (0 recomposiciones por frame).
 *  • `pointerInput` va ANTES de `graphicsLayer`: el área táctil no se encoge al escalar (no se "pierde" el toque).
 *  • `onTap` se envuelve con rememberUpdatedState: la lambda puede cambiar sin reiniciar el detector de gestos.
 *
 * IMPORTANTE: colócalo ANTES de clip/background en la cadena, para que el fondo también escale.
 */
@Composable
internal fun Modifier.nexusPressable(
    enabled: Boolean = true,
    pressedScale: Float = 0.92f,
    pressedAlpha: Float = 0.88f,
    role: Role = Role.Button,
    onTap: () -> Unit,
): Modifier {
    // press: 0f = reposo, 1f = presionado. Escala y opacidad salen del mismo progreso → siempre sincronizadas.
    val press = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current
    val currentOnTap by rememberUpdatedState(onTap)

    return this
        .semantics(mergeDescendants = true) {
            this.role = role
            if (enabled) onClick { currentOnTap(); true }   // TalkBack / accesibilidad
        }
        .pointerInput(enabled, pressedScale) {
            if (!enabled) return@pointerInput
            detectTapGestures(
                onPress = {
                    scope.launch { press.animateTo(1f, NexusMotion.PressDown) }
                    tryAwaitRelease()
                    scope.launch { press.animateTo(0f, NexusMotion.PressUp) }
                },
                onTap = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    currentOnTap()
                },
            )
        }
        .graphicsLayer {
            val p = press.value      // lectura diferida: solo invalida la capa, no recompone
            val s = 1f - (1f - pressedScale) * p        // p<0 un instante (rebote) → escala >1, como iOS
            scaleX = s
            scaleY = s
            alpha = (1f - (1f - pressedAlpha) * p).coerceIn(0f, 1f)
        }
}
