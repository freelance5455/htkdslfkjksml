package com.nexus.ia.pro.ui.chat

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import java.util.concurrent.atomic.AtomicLong

/** Tipo de adjunto. Por ahora solo imágenes (foto/galería) y archivos genéricos. */
enum class AttachmentKind { IMAGE, FILE }

/**
 * Generador de ids únicos y baratos. Los ids se usan como `key` del LazyColumn/LazyRow:
 * una key repetida CRASHEA la lista, y `System.nanoTime()` no garantiza unicidad.
 */
internal object ChatIds {
    private val counter = AtomicLong(System.currentTimeMillis())
    fun next(): Long = counter.incrementAndGet()
}

/** Un adjunto pendiente de enviar (o ya enviado dentro de un mensaje). */
@Immutable
data class ChatAttachment(
    val id: Long = ChatIds.next(),
    val uri: Uri,
    val kind: AttachmentKind,
    val name: String,
)

/**
 * Un mensaje del historial del chat.
 * `@Immutable` + `data class`: Compose se salta la burbuja si el mensaje es igual al anterior (equals),
 * así que al llegar un mensaje nuevo o al "streamear" texto solo se redibuja la burbuja que cambió.
 */
@Immutable
data class ChatMessage(
    val id: Long = ChatIds.next(),
    val text: String,
    val isUser: Boolean,
    val attachments: List<ChatAttachment> = emptyList(),
)

/**
 * Estado del compositor (caja de texto + adjuntos pendientes).
 * Si usas ViewModel, mueve esta clase allí; la UI no cambia.
 *
 * `@Stable`: el compilador de Compose sabe que sus propiedades notifican cambios, así que los composables
 * que la reciben se pueden saltar y las lambdas que la capturan se recuerdan solas.
 */
@Stable
class ComposerState {
    var text by mutableStateOf("")
    val attachments = mutableStateListOf<ChatAttachment>()

    /**
     * Derivado y cacheado: se recalcula al teclear pero SOLO notifica a quien lo lee cuando el booleano cambia
     * (`isNotBlank` corta en el primer carácter útil → O(1) en la práctica).
     */
    val canSend: Boolean by derivedStateOf { text.isNotBlank() || attachments.isNotEmpty() }

    fun addAttachment(attachment: ChatAttachment) { attachments += attachment }
    fun removeAttachment(attachment: ChatAttachment) { attachments.remove(attachment) }

    /** Crea el mensaje a enviar y deja el compositor limpio. */
    fun buildMessageAndClear(): ChatMessage {
        val msg = ChatMessage(text = text.trim(), isUser = true, attachments = attachments.toList())
        text = ""
        attachments.clear()
        return msg
    }
}

@Composable
fun rememberComposerState(): ComposerState = remember { ComposerState() }

/**
 * Actualiza el texto de un mensaje existente (ideal para respuestas de IA en streaming).
 * Busca desde el final (el mensaje en streaming casi siempre es el último → O(1)) y reemplaza SOLO ese
 * elemento: Compose redibuja únicamente esa burbuja.
 */
fun SnapshotStateList<ChatMessage>.updateText(id: Long, text: String) {
    for (i in lastIndex downTo 0) {
        if (this[i].id == id) {
            if (this[i].text != text) this[i] = this[i].copy(text = text)
            return
        }
    }
}

/** Convierte un Uri elegido en el selector del sistema en un [ChatAttachment] (detecta imagen vs archivo). */
internal fun Context.toAttachment(uri: Uri): ChatAttachment {
    val mime = contentResolver.getType(uri).orEmpty()
    var name = "Archivo"
    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0)?.let { name = it }
    }
    val kind = if (mime.startsWith("image/")) AttachmentKind.IMAGE else AttachmentKind.FILE
    return ChatAttachment(uri = uri, kind = kind, name = name)
}
