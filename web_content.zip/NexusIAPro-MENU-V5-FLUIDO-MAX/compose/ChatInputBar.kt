package com.nexus.ia.pro.ui.chat

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val CursorBrush = SolidColor(NexusColors.Ink)
private val SendSpring = spring<Float>(dampingRatio = 0.7f, stiffness = 500f)

/**
 * Barra de entrada completa:  [miniaturas]  ( ✦ menú | texto | enviar )
 *
 * Optimización de recomposiciones:
 *  • Esta función NO lee `state.text` ni el contenido de `state.attachments` → no se recompone al teclear
 *    ni al añadir/quitar adjuntos. Cada hijo lee solo lo que necesita:
 *      - [ComposerTextField] lee el texto.
 *      - [AttachmentPreviewRow] lee la lista.
 *      - [SendButton] lee `state.canSend` (derivado dentro de [ComposerState]) → solo se recompone cuando el
 *        booleano CAMBIA (no en cada letra).
 *  • Estilo burbuja iOS: cápsula con sombra suave + borde fino con brillo (nexusBubble), sin capa de recorte.
 */
@Composable
fun ChatInputBar(
    state: ComposerState,
    onCameraClick: () -> Unit,
    onFilesClick: () -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
        AttachmentPreviewRow(attachments = state.attachments, onRemove = state::removeAttachment)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .nexusBubble(NexusShapes.Capsule, elevation = 10.dp)   // cápsula flotante con brillo fino
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NexusComposerMenu(onCameraClick = onCameraClick, onFilesClick = onFilesClick)
            ComposerTextField(state = state, modifier = Modifier.weight(1f))
            SendButton(state = state, onSend = onSend)
        }
    }
}

/**
 * Campo de texto aislado: solo él se recompone al teclear.
 * Usa `BasicTextField` (sin la decoración pesada de Material TextField: etiqueta animada, indicador, alto mínimo 56 dp)
 * → menos nodos que medir/dibujar por pulsación = escritura más ligera, especialmente en gama media/baja.
 */
@Composable
private fun ComposerTextField(state: ComposerState, modifier: Modifier = Modifier) {
    // Mismo estilo tipográfico que el tema, calculado una vez (no en cada letra)
    val base = MaterialTheme.typography.bodyLarge
    val textStyle = remember(base) { base.copy(color = NexusColors.Ink, fontSize = 16.sp) }
    val placeholderStyle = remember(base) { base.copy(color = NexusColors.Muted, fontSize = 16.sp) }

    BasicTextField(
        value = state.text,
        onValueChange = { state.text = it },
        modifier = modifier.padding(horizontal = 12.dp, vertical = 10.dp),
        textStyle = textStyle,
        cursorBrush = CursorBrush,
        maxLines = 5,
        decorationBox = { innerTextField ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (state.text.isEmpty()) Text("Pregúntale a Nexus IA", style = placeholderStyle)
                innerTextField()
            }
        },
    )
}

/** Botón enviar: se "enciende" con un spring cuando hay algo que enviar. */
@Composable
private fun SendButton(state: ComposerState, onSend: () -> Unit) {
    // Lectura del booleano derivado: invalida solo cuando CAMBIA, no en cada letra
    val canSend = state.canSend

    // Se guarda como State (sin `by`) y se lee dentro de graphicsLayer → la animación no recompone
    val enabledAnim = animateFloatAsState(
        targetValue = if (canSend) 1f else 0f,
        animationSpec = SendSpring,
        label = "nxSendEnabled",
    )

    Box(
        modifier = Modifier
            .nexusPressable(enabled = canSend, pressedScale = 0.88f, pressedAlpha = 0.85f, onTap = onSend)
            .size(48.dp)
            .graphicsLayer {
                val e = enabledAnim.value
                alpha = 0.4f + 0.6f * e
                val s = 0.92f + 0.08f * e
                scaleX = s
                scaleY = s
            }
            .nexusInkBubble(NexusShapes.Circle, elevation = 6.dp)
            .semantics { contentDescription = "Enviar" },
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Outlined.ArrowUpward, null, tint = NexusColors.Bg, modifier = Modifier.size(22.dp))
    }
}
