package com.nexus.ia.pro.ui.chat

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import coil.request.ImageRequest

/**
 * Crea (y recuerda) un [ImageRequest] de Coil con tamaño máximo explícito.
 *
 *  • Coil decodifica en hilos de fondo (nunca en el main thread).
 *  • `size(maxSizePx)` hace que se decodifique ya reducida (muestreo) → mucha menos RAM y CPU que cargar la
 *    foto completa de la cámara.
 *  • El `remember` evita reconstruir el request en cada recomposición (la clave es estable: uri + tamaño).
 *  • `crossfade` corto: la miniatura aparece con un fundido suave de 120 ms en lugar de "saltar".
 */
@Composable
internal fun rememberImageRequest(data: Any?, maxSizePx: Int, crossfadeMs: Int = 120): ImageRequest {
    val context = LocalContext.current
    return remember(data, maxSizePx, crossfadeMs) {
        ImageRequest.Builder(context)
            .data(data)
            .size(maxSizePx)
            .crossfade(crossfadeMs)
            .memoryCacheKey("$data@$maxSizePx")
            .build()
    }
}
