package com.nexus.ia.pro.ui.chat

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

/**
 * Permisos de lectura de almacenamiento según la versión de Android.
 *
 *  • Android 14+ (API 34): READ_MEDIA_IMAGES + READ_MEDIA_VIDEO + READ_MEDIA_VISUAL_USER_SELECTED
 *                          (el usuario puede dar acceso parcial: "Elegir fotos y videos").
 *  • Android 13  (API 33): READ_MEDIA_IMAGES + READ_MEDIA_VIDEO.
 *  • Android 12L- (≤ 32):  READ_EXTERNAL_STORAGE.
 *
 * ⚠ Los permisos READ_MEDIA_* cubren SOLO fotos y videos; no existe uno para PDF/documentos.
 *    Y el selector del sistema (GetContent / Storage Access Framework) NO necesita ninguno: el usuario
 *    concede acceso al elegir el archivo. Por eso [AttachmentConfig.requestStoragePermission] está en `false`
 *    por defecto. Actívalo solo si además lees la galería directamente (MediaStore).
 */
internal fun storageReadPermissions(sdk: Int = Build.VERSION.SDK_INT): List<String> = when {
    sdk >= 34 -> listOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
    )
    sdk >= 33 -> listOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
    )
    else -> listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

/** Ventanas informativas propias (antes/después de la ventana nativa del sistema). */
internal enum class PermissionPrompt {
    /** El usuario ya rechazó una vez: explicamos por qué hace falta antes de volver a pedir. */
    CameraRationale,

    /** Rechazó con "No volver a preguntar": solo se puede activar desde Ajustes. */
    CameraSettings,
}

/** Diálogo con la estética Nexus (crema/tinta, esquinas grandes). */
@Composable
internal fun NexusPermissionDialog(
    prompt: PermissionPrompt,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val (title, message, confirm) = when (prompt) {
        PermissionPrompt.CameraRationale -> Triple(
            "Permiso de cámara",
            "Nexus necesita la cámara para tomar la foto y adjuntarla a tu mensaje. Solo se usa cuando tú lo pides.",
            "Continuar",
        )
        PermissionPrompt.CameraSettings -> Triple(
            "Cámara desactivada",
            "Para tomar fotos, activa el permiso de Cámara en los Ajustes de la app.",
            "Abrir ajustes",
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NexusColors.Surface,
        titleContentColor = NexusColors.Ink,
        textContentColor = NexusColors.Ink2,
        shape = NexusShapes.Bubble,   // 28 dp, misma curva que los menús burbuja
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onConfirm, shape = NexusShapes.Capsule) { Text(confirm, color = NexusColors.Ink) } },
        dismissButton = { TextButton(onClick = onDismiss, shape = NexusShapes.Capsule) { Text("Ahora no", color = NexusColors.Muted) } },
    )
}

/** Abre la pantalla de ajustes de ESTA app (para activar un permiso bloqueado). */
internal fun Context.openAppSettings() {
    startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}
