package com.nexus.ia.pro.ui.chat

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * Formas "burbuja" estilo iOS (Cupertino) compartidas por TODA la UI.
 * Se declaran una sola vez (hoisted) → ninguna recomposición crea formas nuevas.
 */
internal object NexusShapes {
    /** Cápsula completa: barra de texto, botones anchos, chips, selectores. */
    val Capsule: Shape = RoundedCornerShape(percent = 50)

    /** Botones redondos (enviar, ✦ menú, cerrar). */
    val Circle: Shape = CircleShape

    /** Contenedores grandes y menús flotantes. */
    val Bubble: Shape = RoundedCornerShape(28.dp)

    /** Tarjetas y miniaturas. */
    val Card: Shape = RoundedCornerShape(24.dp)

    /** Opciones dentro de menús desplegables (casi cápsula, para que respiren dentro del panel de 28 dp). */
    val Option: Shape = RoundedCornerShape(26.dp)

    /** Chips / etiquetas pequeñas. */
    val Chip: Shape = RoundedCornerShape(20.dp)
}
