@echo off
set "PATH=%PATH%;%ProgramFiles%\nodejs;%LocalAppData%\Programs\Python\Python312;%LocalAppData%\Programs\Python\Python312\Scripts;%ProgramFiles%\Python312;%ProgramFiles%\Python312\Scripts;%ProgramFiles%\FFmpeg\bin;%ProgramFiles%\Git\cmd"
if not exist "%~dp0.prep-ok" call "%~dp0preparar.bat"
cd /d "%~dp0app"
set "D=%~dp0app\index.html"
start "" msedge --app="file:///%D:\=/%" || start "" "%D%"