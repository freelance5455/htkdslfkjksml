
const $ = (id) => document.getElementById(id);

const form = $("chatForm");
const input = $("messageInput");
const messages = $("messages");

const storageKey = "aylin_stark_memory_v1";

let memory = [];
let recognition = null;
let listening = false;

try {
  const saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
  if (Array.isArray(saved)) memory = saved.slice(-30);
} catch {
  memory = [];
}

function saveMemory() {
  try {
    localStorage.setItem(storageKey, JSON.stringify(memory));
  } catch (error) {
    console.warn("No se pudo guardar la memoria local.", error);
  }
}

function remember(role, text) {
  memory.push({
    role,
    text,
    time: new Date().toLocaleString()
  });

  memory = memory.slice(-30);
  saveMemory();
}

function addMessage(text, role) {
  const message = document.createElement("div");
  message.className = "message " + role;

  if (role === "ai") {
    const label = document.createElement("span");
    label.className = "message-label";
    label.textContent = "AYL-IN / SISTEMA";
    message.appendChild(label);
  }

  message.appendChild(document.createTextNode(text));
  messages.appendChild(message);
  messages.scrollTop = messages.scrollHeight;
}

function respond(text) {
  const t = text.toLowerCase();

  if (/hola|buenas|hey/.test(t)) {
    return "¡Hola! Sistemas preparados. ¿Qué hacemos hoy?";
  }

  if (/cómo estás|como estas/.test(t)) {
    return "Todos mis sistemas están listos. ¿Y tú qué tal?";
  }

  if (/quién eres|quien eres|tu nombre/.test(t)) {
    return "Soy AYL-IN, tu asistente personal del proyecto STARK LABS INC.";
  }

  if (/hora|fecha/.test(t)) {
    return "Fecha y hora del dispositivo: " + new Date().toLocaleString();
  }

  if (/recuerda|recuerda que|memoriza/.test(t)) {
    return "He guardado tu mensaje en la memoria local de este dispositivo.";
  }

  if (/memoria/.test(t)) {
    return "Tengo " + memory.length +
      " registros locales disponibles. Abre la sección Memoria para consultarlos.";
  }

  return "He recibido tu mensaje. Esta es la versión de interfaz de AYL-IN; conecta tu backend de IA para obtener respuestas inteligentes reales.";
}

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const text = input.value.trim();
  if (!text) return;

  addMessage(text, "user");
  remember("user", text);

  input.value = "";

  const reply = respond(text);
  addMessage(reply, "ai");
  remember("ai", reply);

  input.focus();
});

const views = {
  chat: {
    title: "A tu servicio.",
    subtitle: "El futuro comienza con una idea.",
    panel: "TERMINAL DE COMUNICACIÓN",
    target: "chatPanel"
  },
  voice: {
    title: "Te escucho.",
    subtitle: "Interfaz de comunicación por voz.",
    panel: "INTERFAZ DE VOZ",
    target: "voicePanel"
  },
  memory: {
    title: "Nada se pierde.",
    subtitle: "Consulta los registros de esta sesión.",
    panel: "MEMORIA DEL SISTEMA",
    target: "memoryPanel"
  },
  settings: {
    title: "Tu sistema.",
    subtitle: "Personaliza tu experiencia.",
    panel: "CONFIGURACIÓN",
    target: "settingsPanel"
  }
};

function showView(name) {
  const view = views[name];
  if (!view) return;

  document.querySelectorAll(".control").forEach((button) => {
    button.classList.toggle("selected", button.dataset.view === name);
  });

  ["chatPanel", "voicePanel", "memoryPanel", "settingsPanel"]
    .forEach((id) => $(id).hidden = id !== view.target);

  $("viewTitle").textContent = view.title;
  $("viewSubtitle").textContent = view.subtitle;
  $("panelTitle").textContent = view.panel;

  if (name === "memory") renderMemory();
}

document.querySelectorAll(".control").forEach((button) => {
  button.addEventListener("click", () => showView(button.dataset.view));
});

function renderMemory() {
  const list = $("memoryList");
  list.replaceChildren();

  if (!memory.length) {
    const empty = document.createElement("p");
    empty.textContent = "No hay registros guardados.";
    list.appendChild(empty);
    return;
  }

  memory.slice().reverse().forEach((item) => {
    const row = document.createElement("div");
    row.className = "memory-item";

    const label = document.createElement("strong");
    label.textContent = item.role.toUpperCase() + " · ";

    row.appendChild(label);
    row.appendChild(document.createTextNode(item.text));

    const time = document.createElement("div");
    time.style.color = "#7895ad";
    time.style.marginTop = "5px";
    time.textContent = item.time;

    row.appendChild(time);
    list.appendChild(row);
  });
}

$("clearMemory").addEventListener("click", () => {
  if (!confirm("¿Borrar todos los registros locales?")) return;

  memory = [];
  saveMemory();
  renderMemory();
});

$("animationsToggle").addEventListener("change", (event) => {
  document.body.classList.toggle("no-motion", !event.target.checked);
});

$("soundToggle").addEventListener("change", (event) => {
  if (event.target.checked) {
    alert("Los efectos de sonido aún no están implementados.");
    event.target.checked = false;
  }
});

function setVoiceStatus(text) {
  $("voiceStatus").textContent = text;
}

const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition;

if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = "es-MX";
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onstart = () => {
    listening = true;
    $("waveform").classList.add("running");
    $("voiceAction").textContent = "ESCUCHANDO...";
    setVoiceStatus("ESCUCHANDO TU VOZ");
    $("status").textContent = "LISTENING";
  };

  recognition.onresult = (event) => {
    const spoken = event.results[0][0].transcript;
    input.value = spoken;
    showView("chat");
    input.focus();
  };

  recognition.onerror = (event) => {
    setVoiceStatus("ERROR DE VOZ: " + event.error);
  };

  recognition.onend = () => {
    listening = false;
    $("waveform").classList.remove("running");
    $("voiceAction").textContent = "ACTIVAR MICRÓFONO";
    $("status").textContent = "ONLINE";
  };
} else {
  $("voiceAction").textContent = "VOZ NO DISPONIBLE";
  setVoiceStatus("Este navegador no admite reconocimiento de voz.");
}

$("voiceAction").addEventListener("click", () => {
  if (!recognition) {
    setVoiceStatus("Prueba un navegador compatible y permite el micrófono.");
    return;
  }

  if (listening) {
    recognition.stop();
  } else {
    try {
      recognition.start();
    } catch {
      setVoiceStatus("Espera un momento e inténtalo otra vez.");
    }
  }
});

renderMemory();
showView("chat");
