Aman Photo Frame - Final Prototype

App name: Aman Photo Frame
Size: A4 (21 x 29.7 cm)
WhatsApp: 7599997682

Fixed demo prices:
1. Black Classic — ₹249
2. Royal Brown Gold — ₹299
3. Basket Weave — ₹249
4. Golden Wave — ₹299
5. Black Gold — ₹299

The customer can preview a frame, upload a photo, enter details, and send the order to the configured WhatsApp number.

These prices are demo assignments and can be changed later.
