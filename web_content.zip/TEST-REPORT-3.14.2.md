# RISEUP 3.14.2 — Rank artwork loading fix

- Fixed rank artwork loading in Android WebView / APK wrappers by embedding all six WebP rank images directly in `index.html` as data URIs.
- Rank display no longer depends on relative `./assets/ranks/...` paths, which may not resolve under `content://` origins.
- Updated PWA cache name to `riseup-3.14.2-shell`.
- Rank unlock thresholds and player data logic are unchanged.
- Automated checks: static, PWA, gameplay.
- Device-level Android verification has not been performed.
