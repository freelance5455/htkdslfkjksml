const FALAS={
"P01": [
"Mara",
"O vento mudou de lado, Nilo. Faz tempo que ele não faz isso."
],
"P02": [
"Nilo",
"Mudou? Meu mapa ainda mostra as ilhas onde sempre estiveram."
],
"P03": [
"Mara",
"Mapas guardam o que foi. O vento conta o que está sendo."
],
"P04": [
"Nilo",
"E o que ele está contando?"
],
"P05": [
"Mara",
"Que os faróis estão acordando. Vá até os Campos de Vento."
],
"P06": [
"Mara",
"Siga a ponte que canta. Ela ainda lembra o caminho."
],
"P07": [
"Pipa",
"Piu!"
],
"P08": [
"Nilo",
"Tá bom, tá bom. Você vai na frente."
],
"T01": [
"Pipa",
"Piu! Piu!"
],
"T02": [
"Nilo",
"Um fragmento de Ressonância. Está quente."
],
"T03": [
"Pipa",
"Piu-piu!"
],
"T04": [
"Nilo",
"Isso, vamos juntando. Cada um é um pedaço de memória."
],
"T05": [
"Nilo",
"Uma corrente de vento! Pipa, segura firme!"
],
"T06": [
"Nilo",
"Essas criaturas de pedra sempre patrulham o mesmo caminho."
],
"T07": [
"Nilo",
"Dá para pular por cima. Se eu bater de frente, dói."
],
"T08": [
"Nilo",
"Se eu cair, volto ao último ponto de luz."
],
"T09": [
"Pipa",
"Piu."
],
"T10": [
"Nilo",
"Ponto de luz marcado. Obrigado, Pipa."
],
"T11": [
"Nilo",
"Cinco fragmentos. Parece que eles querem se juntar."
],
"B01": [
"Nilo",
"A ponte está partida. Só sobraram as pontas."
],
"B02": [
"Pipa",
"Piu! Piu!"
],
"B03": [
"Nilo",
"Uma pedra gravada. Está zumbindo baixinho."
],
"B04": [
"Nilo",
"As tábuas estão... cantando?"
],
"B05": [
"Nilo",
"Cada tábua volta com uma nota. Isso não é madeira, é memória."
],
"B06": [
"Mara",
"Atravesse sem pressa, Nilo. A ponte toca no ritmo de quem a pisa."
],
"B07": [
"Nilo",
"Se eu corro, ela canta mais rápido!"
],
"G01": [
"Nilo",
"Uma turbina gigante. E está virada para mim."
],
"G02": [
"Guardião",
"Área preservada. Nenhuma alteração permitida."
],
"G03": [
"Nilo",
"Eu só quero atravessar! Não vou mudar nada!"
],
"G04": [
"Guardião",
"Atravessar é mudar. Mudar é perder."
],
"G05": [
"Nilo",
"Funcionou! O vento dele mesmo o empurra para trás!"
],
"G06": [
"Guardião",
"Registro corrompido. Reiniciando proteção."
],
"G07": [
"Nilo",
"Ele ficou mais rápido. Preciso me manter em movimento."
],
"G08": [
"Guardião",
"Preservação... falhou. Quem... autorizou?"
],
"G09": [
"Nilo",
"Quem autorizou? Ele só seguia ordens."
],
"G10": [
"Pipa",
"Piu..."
],
"F01": [
"Nilo",
"O farol está apagado, mas as marcas na pedra formam um mapa."
],
"F02": [
"Nilo",
"Pipa, me empresta a sua luz?"
],
"F03": [
"Pipa",
"Piiiiu!"
],
"F04": [
"O Curador",
"Cartógrafo. Você desenha o que muda. Eu guardo o que importa."
],
"F05": [
"Nilo",
"Quem é você?"
],
"F06": [
"O Curador",
"Alguém que prefere um mundo inteiro e parado a um mundo vivo e perdido."
],
"F07": [
"O Curador",
"Os faróis são meus. As ilhas ficarão como eram. Não me siga."
],
"F08": [
"Nilo",
"Ele fala em guardar, mas tudo que vi hoje estava preso."
],
"F09": [
"Mara",
"Então você começou a entender. Vem, Nilo. A próxima ilha espera."
],
"N01": [
"Nota de Mara",
"Pise com cuidado. A Ressonância responde ao peso do passo."
],
"N02": [
"Marco antigo",
"Aqui terminava o mapa dos primeiros cartógrafos."
],
"N03": [
"Rabisco",
"A ponte canta quando alguém se lembra dela."
],
"N04": [
"Placa gasta",
"ZONA PRESERVADA. NÃO ALTERAR. — O Curador"
],
"N06":["Placa antiga","Quem sobe sem pressa, chega."],
"R01":["Nilo","Ruínas flutuando sobre o vento. Alguém construiu isso para durar."],
"R02":["Pipa","Piu piu!"],
"N05": [
"Nilo",
"Mapas não são o mundo. São uma conversa com ele."
],
"S01": [
"Nilo",
"Ainda não..."
],
"S02": [
"Pipa",
"Piu!"
],
"S03": [
"Sistema",
"PAUSADO"
],
"S04": [
"Sistema",
"Obrigado por jogar! A próxima ilha espera."
],
"U01": [
"Sistema",
"[SETAS] PARA MOVER"
],
"U02": [
"Sistema",
"[Z] PARA PULAR"
],
"U03": [
"Sistema",
"[CIMA] PARA ENTRAR"
],
"U04": [
"Sistema",
"FRAGMENTOS"
],
"U05": [
"Sistema",
"FASE COMPLETA!"
],
"SC01": [
"Guardião Ancião",
"Viajante... se quiser a lâmina da Herdeira, ouça o código: AUR-7K9-ESPADA."
],
"SC02": [
"Guardião Ancião",
"Digite-o quando o vento soprar. A porta secreta se abrirá em seu coração."
]
};
