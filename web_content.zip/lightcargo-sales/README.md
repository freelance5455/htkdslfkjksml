# 軽貨物 売上管理

Android向けの軽貨物売上管理アプリです。

- 日別の配送件数・売上を登録
- 月間カレンダー表示
- 単価をアプリ内で変更可能
- ロイヤリティをアプリ内で変更可能
- 登録済みデータは登録時の単価を保持
- データは端末内のWebView localStorageに保存

## APK作成
GitHub Actions の `Build APK` を手動実行すると、Debug APKがArtifactとして生成されます。
