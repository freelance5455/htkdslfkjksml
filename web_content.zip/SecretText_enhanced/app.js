"use strict";

function initSecretText() {
  const $ = (id) => document.getElementById(id);

  // ========== TEXT ENCRYPTION (original + improvements) ==========
  const message = $("message");
  const password = $("password");
  const encryptedOutput = $("encryptedOutput");
  const encryptedInput = $("encryptedInput");
  const decryptPassword = $("decryptPassword");
  const decryptedOutput = $("decryptedOutput");
  const encryptBtn = $("encryptBtn");
  const decryptBtn = $("decryptBtn");

  const ITERATIONS = 600000;
  const MIN_PASSWORD_LENGTH = 12;

  function showStatus(id, text, type = "info") {
    const el = $(id);
    if (!el) return;
    el.textContent = text;
    el.className = "status show " + type;
  }

  function clearStatus(id) {
    const el = $(id);
    if (!el) return;
    el.textContent = "";
    el.className = "status";
  }

  const CRYPTO_ERROR = "التشفير غير متاح في هذا الرابط. افتح الموقع عبر HTTPS (أو localhost).";
  function cryptoAvailable() {
    return !!(globalThis.crypto && globalThis.crypto.subtle && globalThis.isSecureContext !== false);
  }

  // Clean pasted payloads: remove whitespace/line breaks and invisible characters added by chat apps
  function cleanPayload(value) {
    return value.replace(/[\s\u200B-\u200F\u202A-\u202E\u2060\uFEFF]+/g, "").replace(/[.,;:،]+$/, "");
  }

  function randomBytes(length) {
    const bytes = new Uint8Array(length);
    crypto.getRandomValues(bytes);
    return bytes;
  }

  function toBase64Url(bytes) {
    let binary = "";
    for (let i = 0; i < bytes.length; i += 0x8000) {
      binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    }
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  }

  function fromBase64Url(value) {
    if (!/^[A-Za-z0-9_-]+$/.test(value)) throw new Error("تنسيق غير صحيح");
    const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
    const padded = base64 + "=".repeat((4 - base64.length % 4) % 4);
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  async function deriveKey(secret, salt) {
    const material = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey(
      { name: "PBKDF2", salt, iterations: ITERATIONS, hash: "SHA-256" },
      material,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
  }

  async function encryptMessage(plainText, secret) {
    const salt = randomBytes(16);
    const iv = randomBytes(12);
    const key = await deriveKey(secret, salt);
    const ciphertext = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv, tagLength: 128 },
      key,
      new TextEncoder().encode(plainText)
    );
    return ["ST1", toBase64Url(salt), toBase64Url(iv), toBase64Url(new Uint8Array(ciphertext))].join(".");
  }

  async function decryptMessage(payload, secret) {
    const parts = cleanPayload(payload).split(".");
    if (parts.length !== 4 || parts[0] !== "ST1") throw new Error("صيغة غير صحيحة");
    const salt = fromBase64Url(parts[1]);
    const iv = fromBase64Url(parts[2]);
    const ciphertext = fromBase64Url(parts[3]);
    if (salt.length !== 16 || iv.length !== 12 || ciphertext.length < 16) throw new Error("بيانات غير صالحة");
    const key = await deriveKey(secret, salt);
    const plaintext = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv, tagLength: 128 },
      key,
      ciphertext
    );
    return new TextDecoder("utf-8", { fatal: true }).decode(plaintext);
  }

  function copyText(text, statusId) {
    if (!text) {
      showStatus(statusId, "مفيش نص لنسخه لسه.", "error");
      return;
    }
    if (!navigator.clipboard?.writeText) {
      showStatus(statusId, "النسخ التلقائي غير متاح. حدد النص وانسخه يدويًا.", "info");
      return;
    }
    navigator.clipboard.writeText(text)
      .then(() => showStatus(statusId, "تم نسخ النص بنجاح. ✅", "success"))
      .catch(() => showStatus(statusId, "حدد النص وانسخه يدويًا.", "info"));
  }

  function setBusy(button, busy, busyText, normalText) {
    if (!button) return;
    button.disabled = busy;
    button.innerHTML = busy ? busyText : normalText;
  }

  function updatePasswordStrength(input, strengthEl) {
    const val = input.value;
    let strength = "";
    if (val.length >= 12 && /[A-Z]/.test(val) && /[0-9]/.test(val) && /[^A-Za-z0-9]/.test(val)) {
      strength = "strong";
    } else if (val.length >= 8) {
      strength = "medium";
    } else if (val.length > 0) {
      strength = "weak";
    }
    strengthEl.className = "password-strength " + strength;
  }

  // Text encrypt (only if on text page)
  if (encryptBtn && message && password) {
  encryptBtn.addEventListener("click", async () => {
    clearStatus("encryptStatus");
    const text = message.value;
    const secret = password.value;
    if (!text.trim()) {
      showStatus("encryptStatus", "اكتب الرسالة الأول.", "error");
      message.focus();
      return;
    }
    if (secret.length < MIN_PASSWORD_LENGTH) {
      showStatus("encryptStatus", "كلمة المرور لازم تكون 12 حرفًا على الأقل.", "error");
      password.focus();
      return;
    }
    if (!cryptoAvailable()) {
      showStatus("encryptStatus", CRYPTO_ERROR, "error");
      return;
    }
    setBusy(encryptBtn, true, "جارٍ التشفير...", '<span>🔒</span> تشفير الرسالة');
    try {
      encryptedOutput.value = await encryptMessage(text, secret);
      showStatus("encryptStatus", "تم التشفير بنجاح. شارك النص المشفر فقط، وكلمة المرور بطريقة منفصلة.", "success");
    } catch (error) {
      console.error(error);
      showStatus("encryptStatus", "فشل التشفير.", "error");
    } finally {
      setBusy(encryptBtn, false, "", '<span>🔒</span> تشفير الرسالة');
    }
  });

  decryptBtn.addEventListener("click", async () => {
    clearStatus("decryptStatus");
    const payload = encryptedInput.value.trim();
    const secret = decryptPassword.value;
    if (!payload) {
      showStatus("decryptStatus", "الصق النص المشفر الأول.", "error");
      return;
    }
    if (!secret) {
      showStatus("decryptStatus", "اكتب كلمة المرور.", "error");
      return;
    }
    if (!cryptoAvailable()) {
      showStatus("decryptStatus", CRYPTO_ERROR, "error");
      return;
    }
    setBusy(decryptBtn, true, "جارٍ فك التشفير...", '<span>🔓</span> فك تشفير الرسالة');
    try {
      decryptedOutput.value = await decryptMessage(payload, secret);
      showStatus("decryptStatus", "تم فك التشفير بنجاح. ✅", "success");
    } catch (error) {
      decryptedOutput.value = "";
      const isFormat = error instanceof Error && error.name !== "OperationError";
      showStatus("decryptStatus", isFormat
        ? "النص المشفّر غير مكتمل أو تالف. انسخه كاملًا (يبدأ بـ ST1.)."
        : "كلمة المرور غير صحيحة أو النص معدّل.", "error");
    } finally {
      setBusy(decryptBtn, false, "", '<span>🔓</span> فك تشفير الرسالة');
    }
  });

  $("copyBtn").addEventListener("click", () => copyText(encryptedOutput.value, "encryptStatus"));
  $("copyPlainBtn").addEventListener("click", () => copyText(decryptedOutput.value, "decryptStatus"));

  $("togglePassword").addEventListener("click", () => {
    const hidden = password.type === "password";
    password.type = hidden ? "text" : "password";
    $("togglePassword").textContent = hidden ? "إخفاء" : "إظهار";
  });

  password.addEventListener("input", () => {
    updatePasswordStrength(password, $("passwordStrength"));
    clearStatus("encryptStatus");
  });
  message.addEventListener("input", () => clearStatus("encryptStatus"));
  encryptedInput.addEventListener("input", () => clearStatus("decryptStatus"));
  decryptPassword.addEventListener("input", () => clearStatus("decryptStatus"));
  } // end text page

  // ========== FILE / IMAGE ENCRYPTION ==========
  const MAGIC = new TextEncoder().encode("STENC1"); // 6 bytes

  async function encryptFile(file, secret) {
    const salt = randomBytes(16);
    const iv = randomBytes(12);
    const key = await deriveKey(secret, salt);

    const arrayBuffer = await file.arrayBuffer();
    const ciphertext = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv, tagLength: 128 },
      key,
      arrayBuffer
    );

    const filenameBytes = new TextEncoder().encode(file.name).slice(0, 1024);
    const nameLen = new Uint8Array(2);
    new DataView(nameLen.buffer).setUint16(0, filenameBytes.length, false);

    const result = new Uint8Array(
      MAGIC.length + salt.length + iv.length + 2 + filenameBytes.length + ciphertext.byteLength
    );
    let offset = 0;
    result.set(MAGIC, offset); offset += MAGIC.length;
    result.set(salt, offset); offset += salt.length;
    result.set(iv, offset); offset += iv.length;
    result.set(nameLen, offset); offset += 2;
    result.set(filenameBytes, offset); offset += filenameBytes.length;
    result.set(new Uint8Array(ciphertext), offset);

    return result;
  }

  async function decryptFile(encryptedBuffer, secret) {
    const data = new Uint8Array(encryptedBuffer);
    if (data.length < MAGIC.length + 16 + 12 + 2) throw new Error("ملف غير صالح");

    let offset = 0;
    const magic = data.slice(offset, offset + MAGIC.length); offset += MAGIC.length;
    if (new TextDecoder().decode(magic) !== "STENC1") throw new Error("تنسيق الملف غير مدعوم");

    const salt = data.slice(offset, offset + 16); offset += 16;
    const iv = data.slice(offset, offset + 12); offset += 12;
    const nameLen = new DataView(data.buffer, data.byteOffset + offset, 2).getUint16(0, false); offset += 2;
    if (offset + nameLen > data.length) throw new Error("ملف غير صالح");
    const filenameBytes = data.slice(offset, offset + nameLen); offset += nameLen;
    const filename = new TextDecoder().decode(filenameBytes);
    const ciphertext = data.slice(offset);

    const key = await deriveKey(secret, salt);
    const plaintext = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv, tagLength: 128 },
      key,
      ciphertext
    );

    return { filename, data: plaintext };
  }

  function downloadBlob(data, filename, mime = "application/octet-stream") {
    const blob = new Blob([data], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  // File encrypt UI (only if on files page)
  const fileInput = $("fileInput");
  if (fileInput) {
  const filePassword = $("filePassword");
  const encryptFileBtn = $("encryptFileBtn");
  const filePreview = $("filePreview");

  // Friendly file pickers: show chosen name, keyboard + drag & drop support
  function wirePicker(input, labelId, textId, emptyText) {
    const label = $(labelId), text = $(textId);
    const refresh = () => {
      const f = input.files[0];
      text.textContent = f ? `${f.name} (${(f.size / 1024).toFixed(1)} KB)` : emptyText;
      label.classList.toggle("has-file", !!f);
    };
    input.addEventListener("change", refresh);
    label.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); }
    });
    label.addEventListener("dragover", (e) => { e.preventDefault(); label.classList.add("dragover"); });
    label.addEventListener("dragleave", () => label.classList.remove("dragover"));
    label.addEventListener("drop", (e) => {
      e.preventDefault();
      label.classList.remove("dragover");
      if (e.dataTransfer?.files?.length) {
        input.files = e.dataTransfer.files;
        input.dispatchEvent(new Event("change", { bubbles: true }));
      }
    });
  }
  wirePicker(fileInput, "filePickerLabel", "filePickerText", "اضغط هنا لاختيار صورة أو ملف");
  wirePicker($("encryptedFileInput"), "encPickerLabel", "encPickerText", "اضغط هنا لاختيار ملف .stenc");

  fileInput.addEventListener("change", () => {
    filePreview.innerHTML = "";
    const file = fileInput.files[0];
    if (!file) return;
    const info = document.createElement("div");
    info.className = "file-info";
    info.textContent = `${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
    filePreview.appendChild(info);

    if (file.type.startsWith("image/")) {
      const img = document.createElement("img");
      img.src = URL.createObjectURL(file);
      filePreview.appendChild(img);
    }
  });

  $("toggleFilePassword").addEventListener("click", () => {
    const hidden = filePassword.type === "password";
    filePassword.type = hidden ? "text" : "password";
    $("toggleFilePassword").textContent = hidden ? "إخفاء" : "إظهار";
  });

  filePassword.addEventListener("input", () => {
    updatePasswordStrength(filePassword, $("filePasswordStrength"));
    clearStatus("fileEncryptStatus");
  });

  encryptFileBtn.addEventListener("click", async () => {
    clearStatus("fileEncryptStatus");
    const file = fileInput.files[0];
    const secret = filePassword.value;
    if (!file) {
      showStatus("fileEncryptStatus", "اختر ملفًا أو صورة أولًا.", "error");
      return;
    }
    if (secret.length < MIN_PASSWORD_LENGTH) {
      showStatus("fileEncryptStatus", "كلمة المرور لازم تكون 12 حرفًا على الأقل.", "error");
      return;
    }
    if (!cryptoAvailable()) {
      showStatus("fileEncryptStatus", CRYPTO_ERROR, "error");
      return;
    }
    setBusy(encryptFileBtn, true, "جارٍ التشفير...", '<span>🔒</span> تشفير الملف / الصورة');
    try {
      const encrypted = await encryptFile(file, secret);
      const outName = file.name + ".stenc";
      downloadBlob(encrypted, outName);
      showStatus("fileEncryptStatus", `تم التشفير بنجاح. تم تنزيل: ${outName}`, "success");
    } catch (err) {
      console.error(err);
      showStatus("fileEncryptStatus", "فشل التشفير.", "error");
    } finally {
      setBusy(encryptFileBtn, false, "", '<span>🔒</span> تشفير الملف / الصورة');
    }
  });

  // File decrypt
  const encryptedFileInput = $("encryptedFileInput");
  const fileDecryptPassword = $("fileDecryptPassword");
  const decryptFileBtn = $("decryptFileBtn");
  const decryptedPreview = $("decryptedPreview");

  decryptFileBtn.addEventListener("click", async () => {
    clearStatus("fileDecryptStatus");
    decryptedPreview.innerHTML = "";
    const file = encryptedFileInput.files[0];
    const secret = fileDecryptPassword.value;
    if (!file) {
      showStatus("fileDecryptStatus", "اختر الملف المشفر (.stenc).", "error");
      return;
    }
    if (!secret) {
      showStatus("fileDecryptStatus", "اكتب كلمة المرور.", "error");
      return;
    }
    if (!cryptoAvailable()) {
      showStatus("fileDecryptStatus", CRYPTO_ERROR, "error");
      return;
    }
    setBusy(decryptFileBtn, true, "جارٍ فك التشفير...", '<span>🔓</span> فك التشفير والتنزيل');
    try {
      const buffer = await file.arrayBuffer();
      const { filename, data } = await decryptFile(buffer, secret);
      downloadBlob(data, filename);

      // Preview if image
      const ext = filename.split(".").pop()?.toLowerCase();
      if (["jpg","jpeg","png","gif","webp","bmp"].includes(ext)) {
        const img = document.createElement("img");
        img.src = URL.createObjectURL(new Blob([data]));
        decryptedPreview.appendChild(img);
      }
      showStatus("fileDecryptStatus", `تم فك التشفير بنجاح. تم تنزيل: ${filename}`, "success");
    } catch (err) {
      console.error(err);
      showStatus("fileDecryptStatus", err && err.name === "OperationError"
        ? "كلمة المرور غير صحيحة أو الملف معدّل."
        : "الملف غير صالح أو ليس ملف .stenc.", "error");
    } finally {
      setBusy(decryptFileBtn, false, "", '<span>🔓</span> فك التشفير والتنزيل');
    }
  });

  } // end files page

  console.info("SecretText Enhanced initialized.");
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initSecretText, { once: true });
} else {
  initSecretText();
}
