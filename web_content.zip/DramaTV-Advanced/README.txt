DRAMA TV ADVANCED
1. Upload all files to Replit or your web host, keeping the folder structure.
2. Open index.html through the host preview.
3. Open KissKH using its button; it opens in a separate tab because third-party sites may block embedding.
4. Select a local video or paste a direct authorized MP4/HLS URL.
5. Upload one or more .vtt files and choose a subtitle track.

AI translation note: this player displays a VTT file that has already been translated. It does not itself call an AI translation service. A secure backend and authorized translation API are needed for automatic translation.
Third-party stream note: it does not extract protected streams or bypass website restrictions. Remote sources may require CORS permission. Video.js and HLS.js are loaded from CDNs and need internet access.
