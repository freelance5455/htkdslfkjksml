const player=videojs('player',{controls:true,fluid:true,responsive:true,playbackRates:[0.5,1,1.5,2],controlBar:{children:['playToggle','volumePanel','currentTimeDisplay','timeDivider','durationDisplay','progressControl','playbackRateMenuButton','subsCapsButton','fullscreenToggle']}});
const status=document.getElementById('status'),select=document.getElementById('subtitleSelect');let tracks=[],videoObjectUrl=null;
function say(t){status.textContent=t}
function loadSource(url){player.src({src:url,type:/\\.m3u8($|\\?)/i.test(url)?'application/x-mpegURL':'video/mp4'});say('Video source loaded. Press Play.')}
document.getElementById('loadUrl').onclick=()=>{let u=document.getElementById('videoUrl').value.trim();if(!/^https?:\\/\\//i.test(u)){say('Enter a valid direct HTTP/HTTPS video URL.');return}loadSource(u)};
document.getElementById('videoFile').onchange=e=>{let f=e.target.files[0];if(!f)return;if(videoObjectUrl)URL.revokeObjectURL(videoObjectUrl);videoObjectUrl=URL.createObjectURL(f);player.src({src:videoObjectUrl,type:f.type||'video/mp4'});say('Local video loaded.')};
function refresh(){select.innerHTML='<option value="-1">Subtitles Off</option>';tracks.forEach((t,i)=>{let o=document.createElement('option');o.value=i;o.textContent=t.label;select.appendChild(o)})}
document.getElementById('subtitleFiles').onchange=e=>{let fs=[...e.target.files].filter(f=>f.name.toLowerCase().endsWith('.vtt'));if(!fs.length){say('Choose .vtt files only.');return}fs.forEach(f=>{let u=URL.createObjectURL(f),r=player.addRemoteTextTrack({kind:'subtitles',src:u,srclang:'und',label:f.name.replace(/\\.vtt$/i,'')},false);tracks.push({label:f.name,track:r.track,url:u})});refresh();say(fs.length+' subtitle file(s) added. Select a track below.');e.target.value=''};
select.onchange=()=>{let n=Number(select.value),tt=player.textTracks();for(let i=0;i<tt.length;i++)tt[i].mode='disabled';if(n>=0&&tracks[n]){tracks[n].track.mode='showing';say('Showing '+tracks[n].label)}else say('Subtitles off.')};
document.getElementById('subtitleSize').onchange=e=>{player.el().querySelectorAll('.vjs-text-track-cue div').forEach(c=>c.style.fontSize=e.target.value+'px')};
document.getElementById('themeBtn').onclick=()=>document.body.classList.toggle('light');
player.ready(()=>say('Player ready. Select a video and add VTT subtitle files.'));
player.on('error',()=>say('Could not play this source. Check format, CORS and access permissions.'));
window.addEventListener('beforeunload',()=>{if(videoObjectUrl)URL.revokeObjectURL(videoObjectUrl);tracks.forEach(t=>URL.revokeObjectURL(t.url))});