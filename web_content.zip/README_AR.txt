MRROOT MOBILE SECURITY - مشروع Android جاهز للبناء

المحتويات:
- واجهة عربية RTL تعمل داخل Android WebView.
- محرك Kotlin محلي.
- DNS lookup.
- اختبار TCP محدود للمنافذ 80 و443 و8080 و8443.
- قراءة شهادة TLS على المنفذ 443.

طريقة إنشاء APK:
1) ثبّت Android Studio على كمبيوتر.
2) افتح مجلد MRROOT_Mobile_Security من Android Studio.
3) اسمح بمزامنة Gradle وتنزيل Android SDK/Gradle عند الطلب.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد APK غالباً في app/build/outputs/apk/debug/app-debug.apk.

ملاحظات:
- هذا الملف مشروع مصدر، وليس APK مبنياً.
- يتطلب بناء APK اتصالاً بالإنترنت أول مرة لتنزيل أدوات Gradle/SDK.
- لا يحتوي على استغلال ثغرات أو backdoor أو تخمين كلمات مرور.
- استخدم الفحوصات فقط على أهداف تملكها أو لديك تصريح صريح باختبارها.
- فحص المنافذ محدود بأربعة منافذ شائعة، ولا يمثل مسحاً شاملاً.


تحديث الإصدار 1.1:
- تم تغيير واجهة التطبيق إلى تصميم مستوحى من Linux Desktop/Terminal.
- أضيفت قائمة جانبية وأقسام Workspace وSecurity Modules.


الإصدار 1.2 - واجهات مستوحاة من الصورة المرفقة:
- شاشة رئيسية Security Dashboard.
- شاشة Real-time Monitoring.
- شاشة Check Link / Message مع تحليل محلي أساسي للرابط.
- شريط تنقل سفلي مناسب للجوال.
- التصميم داكن مع لمسات أخضر Mint.
