طريقة الحصول على ملف APK:

1) Android Studio: افتح هذا المجلد (Open) ثم Build > Build APK(s).
2) بدون كمبيوتر: ارفع محتويات الـ ZIP على مستودع GitHub، ثم من تبويب Actions شغّل Build APK، ونزّل app-apk من الـ Artifacts.
