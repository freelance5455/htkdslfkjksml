Raven Level - Android APK Project

هذا المشروع يحول ملف raven-level.html إلى تطبيق Android باستخدام WebView.
الملف الرئيسي للعبة موجود هنا:
app/src/main/assets/index.html

لبناء APK:
1) افتح المشروع في Android Studio أو AndroidIDE.
2) انتظر مزامنة Gradle.
3) نفّذ Build > Build APK(s).
4) ملف APK التجريبي سيكون داخل:
app/build/outputs/apk/debug/

ملاحظة:
اللعبة تعتمد على HTML/JavaScript، لذلك لا تحتاج إلى إعادة بنائها في Godot.
