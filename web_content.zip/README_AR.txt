مشروع بكالوريا ABK - نسخة أولية كاملة

محتويات المشروع:
- تطبيق Android Studio بلغة Java.
- صفحة التطبيق داخل app/src/main/assets/index.html.
- استقبال رابط تأكيد البريد: abk://auth/callback.
- ملف supabase_setup.sql لإنشاء جدول الدردشة وسياسات الحماية.

إعداد Supabase:
1) افتح Authentication > URL Configuration.
2) اترك Site URL كما هو مؤقتًا.
3) أضف abk://auth/callback إلى Redirect URLs ثم احفظ.
4) افتح SQL Editor > New query.
5) انسخ محتوى supabase_setup.sql وشغّله مرة واحدة.
6) في Authentication > Email تأكد من إعداد رسائل التأكيد.

بناء APK:
1) افتح Android Studio على جهاز كمبيوتر.
2) اختر Open ثم اختر مجلد BakaloriaABK بعد فك ضغط ZIP.
3) انتظر Gradle Sync.
4) من Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ثبّت APK الناتج على الهاتف.

ملاحظات مهمة:
- كود شاشة الدخول الأولية هو 2026.
- التطبيق يحتاج إنترنت لتحميل مكتبة Supabase والاتصال بالخادم.
- هذا مشروع مصدر (Source Project) وليس APK جاهزًا.
- لا تشارك روابط تأكيد البريد أو access tokens مع أي شخص.
- لو كان الحساب قد أُنشئ بالفعل، اطلب رسالة تأكيد جديدة بعد تثبيت النسخة الجديدة.
- لا تضع Supabase service_role key داخل التطبيق. المفتاح الموجود في index.html هو publishable key.
