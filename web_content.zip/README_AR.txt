SIDETOUCH MANAGER

هذه حزمة ملفات اللعبة. ليست APK جاهزاً.
ارفع index.html أو ملف ZIP إلى خدمة موثوقة لتحويل HTML إلى Android APK، واجعل index.html صفحة البداية.
اختبر حفظ البيانات بعد التثبيت.
