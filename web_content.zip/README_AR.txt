مشروع Android جاهز لتطبيق إدارة محل المبيدات.
البرنامج يعمل محلياً بدون إنترنت ويحفظ البيانات داخل التطبيق.
لفتحه في Android Studio: افتح المجلد PesticideShopAndroid ثم Build > Build APK(s).
ملف APK الناتج يكون داخل app/build/outputs/apk/debug/.
