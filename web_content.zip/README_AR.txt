مغامرة البطل – مشروع Android

ملاحظة: هذا ملف مشروع Android جاهز للبناء، وليس APK مُجمّعاً. لا تتوفر في بيئة إعداد الملف أدوات Android اللازمة لإنتاج APK مباشرة.

البناء عبر Android Studio:
1) فك ضغط الملف وافتح مجلد HeroAdventure في Android Studio.
2) ثبّت Android SDK Platform 35 إذا طُلب.
3) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
4) ملف APK يظهر في app/build/outputs/apk/debug/app-debug.apk.

البناء من الهاتف عبر GitHub Actions:
1) أنشئ مستودعاً جديداً على GitHub.
2) ارفع جميع محتويات هذا المجلد إلى المستودع (بما فيها مجلد .github).
3) افتح تبويب Actions ثم اختر Build Android APK ثم Run workflow.
4) بعد نجاح البناء افتح نتيجة التشغيل ونزّل Artifact باسم HeroAdventure-debug-apk.
5) فك ضغط Artifact لتحصل على app-debug.apk.

اللعبة أفقية، تعمل دون إنترنت، وتحتوي على حركة وقفز وعملات وأعداء وثلاث مراحل وأزرار لمس.
