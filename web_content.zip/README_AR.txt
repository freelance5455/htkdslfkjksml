# Shift38 Android Project

هذا مشروع Android لتطبيق "جدول المناوبة 3/8".

## فتحه في AndroidIDE
1. فك ضغط الملف.
2. افتح AndroidIDE.
3. اختر Open / Import Project.
4. اختر مجلد Shift38-Android.
5. انتظر مزامنة Gradle.
6. اضغط Run لبناء التطبيق أو Build APK.
7. ملف APK سيكون عادة داخل:
   app/build/outputs/apk/debug/app-debug.apk

المشروع يستخدم WebView لتحميل index.html من مجلد assets، ويحتفظ ببيانات التطبيق عبر localStorage.
