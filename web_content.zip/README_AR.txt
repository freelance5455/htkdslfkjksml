Osama Chat - ZIP مخصص لتطبيق HTML & ZIP File to APK Builder

المحتويات:
- index.html: واجهة دردشة عربية تعمل داخل WebView وتتصل بـ Cloudflare Worker.

طريقة التحويل:
1) افتح تطبيق HTML & ZIP File to APK Builder.
2) اختر استيراد ZIP / Import ZIP.
3) اختر هذا الملف ZIP.
4) اسم التطبيق: Osama Chat
5) اختر أيقونة إذا رغبت، ثم Build APK.

بعد تثبيت التطبيق:
1) افتح Osama Chat.
2) أدخل رابط Worker كاملاً، مثال: https://osama-chat-api.example.workers.dev
3) اضغط حفظ والاتصال.
4) سجّل الدخول.

مهم:
- هذا ZIP هو واجهة التطبيق فقط، وليس نسخة Worker للنشر.
- يجب أن يكون Worker منشوراً ويحتوي على API routes المطلوبة، مع ربط D1 باسم DB وSecret باسم ADMIN_PASSWORD.
- التطبيق يحتاج الإنترنت لأن الرسائل محفوظة في Cloudflare D1.
- لا تضع كلمة مرور المدير داخل ZIP. كلمة المرور تبقى محفوظة كـ Secret في Cloudflare.
