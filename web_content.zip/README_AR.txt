مشروع تحويل لعبة «قفزة المغامر» إلى تطبيق Android

المحتويات:
- ملفات اللعبة الأصلية داخل app/src/main/assets
- غلاف Android يستخدم WebView لعرض اللعبة بملء الشاشة

طريقة إنشاء APK:
1. فك ضغط GameJumpAndroid.zip على كمبيوتر.
2. افتح مجلد GameJumpAndroid باستخدام Android Studio.
3. انتظر انتهاء مزامنة Gradle وتنزيل مكونات Android المطلوبة.
4. من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5. ستجد ملف APK في app/build/outputs/apk/debug/app-debug.apk

ملاحظة: هذا مشروع المصدر وليس ملف APK مبنيًا. يحتاج Android Studio/Android SDK لبناء APK.
