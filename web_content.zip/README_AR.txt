أبناء أبو بهاء - إصدار 1.8 (إعداد Firebase الخاص بالمشروع)

تم تضمين إعدادات Firebase Web App التي أرسلها صاحب المشروع:
- Project ID: abnaa-abu-bahaa
- Authentication domain: abnaa-abu-bahaa.firebaseapp.com
- Storage bucket: abnaa-abu-bahaa.firebasestorage.app

مكونات الإصدار:
- واجهة التطبيق العربية وصور الشيخ.
- تسجيل الدخول وإنشاء حساب عضو واستعادة كلمة المرور عبر Firebase Authentication.
- قراءة ونشر محتوى أقسام Firestore التي يدعمها النموذج الحالي.
- قواعد Firestore تمنع العضو من منح نفسه صلاحية مشرف، وتجعل إنشاء منشورات «الموجز» للمشرفين فقط.
- قواعد Storage مقيدة بمجلد العضو، مع حد 50 ميجابايت للملف.

خطوات الإكمال في Firebase Console:
1) Authentication > Sign-in method: فعّل Email/Password.
2) Firestore Database: تأكد من إنشاء قاعدة البيانات.
3) Firestore > Rules: انشر ملف firestore.rules.
4) Storage: فعّل التخزين إن كان متاحًا في خطة مشروعك، ثم انشر storage.rules.
5) أنشئ حساب المدير الأعلى من شاشة التطبيق، ثم خذ UID من Authentication، وأنشئ/عدّل users/{UID} من Firestore Console واجعل role = super_admin. نفّذ ذلك يدويًا من حساب مالك المشروع فقط.

تنبيهات:
- تضمين إعدادات Web App لا يثبت وحده أن الاتصال بالخدمات نجح؛ يلزم اختبار تسجيل الدخول وقاعدة البيانات بعد نشر القواعد.
- لا تشارك Service Account private keys أو كلمات المرور.
- هذا إصدار ويب قابل للتغليف كتطبيق Android، وليس APK جاهزًا.
- المحادثات الخاصة والمكالمات والإشعارات وإدارة المشرفين الكاملة ليست مفعلة في هذا الإصدار.


إضافات الإصدار 2.0 لتجهيز PWA قبل تغليف Android:
- manifest.webmanifest و service-worker.js
- أيقونات 192 و512 بكسل
- تسجيل Service Worker وبيانات تثبيت الهاتف

مهم: بعد رفع هذه الملفات إلى نفس عنوان HTTPS، اختبر:
https://YOUR-DOMAIN/manifest.webmanifest
https://YOUR-DOMAIN/service-worker.js
ثم استخدم PWABuilder لإنشاء حزمة Android. يلزم إعداد Digital Asset Links (assetlinks.json) بعد إنشاء الحزمة لتعمل كتطبيق ملء الشاشة دون شريط المتصفح.
