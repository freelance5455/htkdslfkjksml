CartoonBox 0.10.0 - HTML/ZIP Ready
================================
هذه نسخة Web/HTML من واجهة CartoonBox، معدة لتطبيقات تحويل HTML/ZIP إلى APK.

الملف الرئيسي: index.html
الأصول: assets/cartoonbox_logo.png

طريقة الاستخدام:
1) اختر هذا الملف ZIP في تطبيق HTML & ZIP to APK.
2) اجعل index.html هو صفحة البداية إذا طلب التطبيق ذلك.
3) أنشئ APK.

ملاحظة:
هذه النسخة ليست مشروع Gradle الأصلي. تم تحويل الواجهة والوظائف المحلية الأساسية إلى HTML/JavaScript حتى تناسب محولات HTML/ZIP.
المصادر الخارجية يجب أن تكون HTTPS وتعيد JSON مسموحًا الوصول إليه.
