مشروع Paper Plane لتحويل اللعبة إلى تطبيق Android APK

مهم: هذا الملف هو مشروع Android Studio جاهز للبناء، وليس APK مبنياً بالفعل.

طريقة إنشاء APK:
1) فك ضغط PaperPlaneAndroid.zip.
2) افتح Android Studio واختر Open ثم اختر مجلد PaperPlaneAndroid.
3) انتظر Gradle Sync، واسمح بتثبيت Android SDK Platform 35 إذا طُلب ذلك.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) بعد انتهاء البناء ستجد الملف غالباً في:
   app/build/outputs/apk/debug/app-debug.apk

يمكن تثبيت app-debug.apk على هاتف Android.
