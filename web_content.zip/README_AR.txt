MOUH MICANIC — مشروع Online قابل للربط بـ Firebase
=================================================

محتويات المشروع:
- public/index.html, styles.css, app.js: واجهة ويب عربية/فرنسية متجاوبة.
- public/firebase-config.js: ضع إعدادات تطبيق Firebase Web هنا.
- firestore.rules: قواعد بداية لعزل بيانات الورش وحصر المالية بالمدير.
- functions/: وظائف خادمية لإنشاء الورشة وحسابات العمال ورمز دعوة.
- firebase.json: إعداد Hosting وFirestore وCloud Functions.

مهم: هذا مشروع أساس برمجي يحتاج إعداد Firebase ونشره واختباره، وليس خدمة منشورة ولا APK جاهزاً. لا تستخدمه مع بيانات حقيقية قبل مراجعة قواعد الأمان واختبارها.

إعداد من الهاتف:
1) أنشئ مشروعاً في https://console.firebase.google.com/
2) فعّل Authentication > Sign-in method > Email/Password.
3) أنشئ Firestore Database.
4) أضف Web App من Project settings، وانسخ إعدادات firebaseConfig إلى public/firebase-config.js.
5) انشر المشروع من بيئة تدعم Firebase CLI: firebase login ثم firebase use --add ثم firebase deploy.
   النشر الكامل لـ Cloud Functions قد يتطلب تفعيل Billing (Blaze) حسب إعدادات Firebase والمنطقة.
6) اختبر بحساب مدير، أنشئ الورشة، ثم أنشئ حساب عامل من شاشة إدارة العمال.
7) اختبر بحساب العامل في متصفح/جهاز آخر وتأكد أنه لا يرى صفحات المدير.

تنبيه تقني مهم:
- إنشاء المدير يتم عبر Email/Password ثم Cloud Function createGarage.
- إنشاء العامل يتم عبر Cloud Function createEmployee؛ كلمة المرور المؤقتة يحددها المدير، ويلزم إضافة تدفق تغيير كلمة المرور الإجباري قبل الإنتاج.
- أمان بيانات العامل يجب تحسينه حسب نموذج إسناد المهام. قواعد jobs الحالية تقيد قراءة العامل بالمهام assignedTo الخاصة به.
- الواجهة المالية هنا نقطة بداية فقط؛ لا يوجد بعد نموذج قيود مالية/حساب أرباح كامل أو إشعارات FCM أو نسخ احتياطي مجدول أو نظام ترخيص تجاري.
- لا تضع مفاتيح Admin أو service-account داخل public أو JavaScript. إعدادات Firebase Web ليست كلمة مرور Admin، لكن يجب تطبيق قواعد Firestore الصارمة.
- العربية والفرنسية موجودتان كواجهة أولية، ويلزم استكمال مراجعة كل النصوص قبل الإصدار.
