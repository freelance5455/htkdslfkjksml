Chicken Claxy War - Android Studio project
هذا المشروع يعرض الصور الثلاث التي أرسلتها داخل واجهة أندرويد بأزرار للتبديل بينها.
مهم: هذه نسخة عرض للتصميم وليست لعبة مكتملة بمحرك قتال، وليست APK جاهزة.
لإنشاء APK: افتح المجلد في Android Studio مع تثبيت Android SDK، ثم Build > Build APK(s).
