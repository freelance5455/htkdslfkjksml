الرسيم السوداني — نسخة Pro القديمة مع ربط Supabase

هذه النسخة تحتفظ بتصميم Pro الأصلي، وتربط عرض الأعمال وتسجيل الحسابات ورفع الصور والتعليقات بمشروع Supabase الحالي.

إعدادات الربط:
- Project URL: https://zzvhrhnnosptqmsygzpp.supabase.co
- المفتاح المستخدم: Publishable key (مفتاح عام للواجهة فقط).
- Storage bucket المطلوب: artworks (Public read مع سياسات الرفع المناسبة).
- الجداول المستخدمة: profiles, artworks, comments.
- لا تضع service_role key في ملفات الواجهة.

ملاحظات التوافق:
1) يفترض الكود وجود الأعمدة:
   artworks: id, user_id, title, description, image_url, created_at
   profiles: id, display_name أو username
   comments: id, user_id, artwork_id, content, created_at
2) يستخدم الكود bucket باسم artworks.
3) يجب أن تسمح سياسات RLS للمستخدم المسجل بإدراج عمله وتعليقاته، وللزوار بقراءة الأعمال والتعليقات.
4) لا يمكن تأكيد نجاح الربط حتى يُختبر تسجيل الدخول والرفع والتعليق على قاعدة البيانات الحقيقية.
5) النسخة الحالية لا تشمل بعد لوحة إدارة متكاملة أو تسجيلات صوتية أو إشعارات أو مسابقات أو نظام متابعة.
6) افتح index.html من خلال استضافة HTTPS أو بيئة تطوير مثل StackBlitz. بعض المتصفحات تمنع استيراد مكتبات JavaScript من ملف محلي file://.

هذه نسخة تطوير أولية، وليست APK جاهزاً.
