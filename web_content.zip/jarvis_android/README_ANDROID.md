# J.A.R.V.I.S. AI — Android-ready project

This project wraps the original HTML/CSS/JavaScript JARVIS dashboard in an Android WebView app.

## Build APK in Android Studio
1. Open Android Studio.
2. Choose **Open** and select this folder (`JARVISAndroid`).
3. Let Gradle sync and install any requested Android SDK components.
4. Select **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location. Transfer the APK to your tablet and install it.

The app loads the dashboard offline from `app/src/main/assets/`. The original `server.py` is kept as a reference but is not required for the Android app.
