const $=id=>document.getElementById(id);
const tasksKey="jarvis_tasks";
let tasks=JSON.parse(localStorage.getItem(tasksKey)||'["Finish project documentation","Study / school work","Work on personal project","Read a book"]');
let wakeOn=true;

function renderTasks(){ $("taskList").innerHTML=tasks.map((t,i)=>`<div class="task ${t.done?"done":""}"><input type="checkbox" ${t.done?"checked":""} onchange="toggleTask(${i})"><span>${escapeHtml(typeof t==="string"?t:t.text)}</span><button onclick="deleteTask(${i})">×</button></div>`).join(""); localStorage.setItem(tasksKey,JSON.stringify(tasks));}
function normalize(){tasks=tasks.map(t=>typeof t==="string"?{text:t,done:false}:t)}
function toggleTask(i){normalize();tasks[i].done=!tasks[i].done;renderTasks()}
function deleteTask(i){tasks.splice(i,1);renderTasks()}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
normalize();renderTasks();

function updateClock(){let d=new Date();let s=d.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"});$("clock").textContent=s;$("bigTime").textContent=d.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});if(wakeOn&&$("wakeTime").value===d.toTimeString().slice(0,5)) speak("Good morning. It is time to wake up.");}
setInterval(updateClock,1000);updateClock();

$("wakeToggle").onclick=()=>{wakeOn=!wakeOn;$("wakeToggle").textContent=wakeOn?"ON":"OFF";$("wakeStatus").textContent=wakeOn?"Wake-up alarm enabled":"Wake-up alarm disabled"};
$("addTask").onclick=()=>{let t=prompt("New task:");if(t){tasks.push({text:t,done:false});renderTasks()}};

function addMsg(who,text){let d=document.createElement("div");d.className="msg "+(who==="You"?"user":"jarvis");d.textContent=who+": "+text;$("chat").appendChild(d);$("chat").scrollTop=$("chat").scrollHeight}
async function ask(cmd){
 addMsg("You",cmd);
 const low=cmd.toLowerCase();
 if(low.includes("time")) return reply("The current time is "+$("bigTime").textContent+".");
 if(low.includes("task")) return reply("You have "+tasks.filter(t=>!t.done).length+" unfinished tasks.");
 if(low.includes("weather")) return reply("The dashboard currently shows 18°C and partly cloudy in Addis Ababa. This is demo data until you connect a weather API.");
 if(low.includes("wake")) return reply("Your wake-up time is "+$("wakeTime").value+" and it is "+(wakeOn?"enabled.":"disabled."));
 try{
   const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:cmd})});
   if(r.ok){const data=await r.json();return reply(data.reply||"I received your command.");}
 }catch(e){}
 reply("I can handle dashboard commands now. Connect Ollama or another AI backend in server.py for full AI conversation.");
}
function reply(t){addMsg("JARVIS",t);speak(t)}
function speak(t){if("speechSynthesis" in window){speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(t);u.rate=.95;speechSynthesis.speak(u)}}
$("send").onclick=()=>{let v=$("command").value.trim();if(v){$("command").value="";ask(v)}};
$("command").addEventListener("keydown",e=>{if(e.key==="Enter")$("send").click()});
document.querySelectorAll(".quick button").forEach(b=>b.onclick=()=>ask(b.dataset.cmd));

$("mic").onclick=()=>{
 const R=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!R){return reply("Voice recognition is not supported in this browser. Try Chrome or Edge.")}
 const r=new R();r.lang="en-US";r.interimResults=false;
 $("listening").textContent="LISTENING...";
 r.onresult=e=>{let t=e.results[0][0].transcript;$("command").value=t;ask(t)};
 r.onend=()=>$("listening").textContent="MIC READY · SAY A COMMAND";
 r.start();
};
