exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405,{error:"Método não permitido."});
  const token=process.env.MP_ACCESS_TOKEN;
  if(!token)return json(503,{error:"Configure MP_ACCESS_TOKEN nas variáveis do Netlify."});
  try{
    const body=JSON.parse(event.body||"{}");
    if(body.plan!=="VENOM Premium"||Number(body.amount)!==19.90)return json(400,{error:"Plano inválido."});
    const site=process.env.URL;
    if(!site)return json(500,{error:"URL do site não definida pelo Netlify."});
    const resp=await fetch("https://api.mercadopago.com/checkout/preferences",{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify({
      items:[{title:"VENOM MUSIC Premium",quantity:1,currency_id:"BRL",unit_price:19.90}],
      payment_methods:{excluded_payment_types:[],installments:12},
      back_urls:{success:`${site}/?payment=success`,pending:`${site}/?payment=pending`,failure:`${site}/?payment=failure`},
      auto_return:"approved",notification_url:`${site}/.netlify/functions/mercadopago-webhook`,
      statement_descriptor:"VENOM MUSIC"
    })});
    const data=await resp.json();
    if(!resp.ok)return json(502,{error:data.message||"Mercado Pago recusou a preferência."});
    return json(200,{init_point:data.init_point});
  }catch(e){return json(500,{error:"Não foi possível iniciar o checkout."});}
};
function json(statusCode,obj){return{statusCode,headers:{"Content-Type":"application/json","Cache-Control":"no-store"},body:JSON.stringify(obj)};}