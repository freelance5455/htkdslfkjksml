exports.handler=async(event)=>{
 if(event.httpMethod!=="POST")return{statusCode:405,body:"Method not allowed"};
 // Endpoint de recepção inicial. NÃO libera Premium: valide assinatura e consulte o pagamento
 // diretamente na API do Mercado Pago antes de conceder acesso.
 try{const p=JSON.parse(event.body||"{}");console.log("MP webhook",p.type,p.action,p.data?.id);return{statusCode:200,body:"OK"}}
 catch{return{statusCode:400,body:"Invalid payload"}}
};