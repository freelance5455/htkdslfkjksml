const crypto=require("crypto");
exports.handler=async(event)=>{
 if(event.httpMethod!=="POST")return reply(405,{error:"Método não permitido."});
 const expected=process.env.ADMIN_PASSWORD;
 if(!expected)return reply(503,{error:"ADMIN_PASSWORD não está configurada no Netlify."});
 let supplied="";try{supplied=JSON.parse(event.body||"{}").password||""}catch{}
 const a=Buffer.from(String(supplied)),b=Buffer.from(String(expected));
 if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return reply(401,{error:"Senha administrativa incorreta."});
 return reply(200,{ok:true,message:"Senha validada. Para gerenciar catálogo com segurança, conecte banco de dados e sessão administrativa."});
};
function reply(statusCode,data){return{statusCode,headers:{"Content-Type":"application/json","Cache-Control":"no-store"},body:JSON.stringify(data)};}