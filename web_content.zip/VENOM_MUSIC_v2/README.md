# VENOM MUSIC — versão 2

## Visualização local
Extraia o ZIP e abra `index.html` no navegador. A interface, navegação, busca e player de faixas demonstrativas funcionam no navegador. É necessária conexão com a internet para carregar os áudios de demonstração e a fonte web.

**Atenção:** abrir o HTML diretamente (`file://`) não executa Netlify Functions. Por isso, checkout real e autenticação administrativa no servidor só funcionam depois de publicar no Netlify (ou rodar Netlify CLI localmente).

## Publicar
1. Extraia o ZIP e publique a pasta `VENOM_MUSIC_v2` no Netlify.
2. Em Site configuration → Environment variables, adicione:
   - `MP_ACCESS_TOKEN`: Access Token da sua aplicação Mercado Pago.
   - `ADMIN_PASSWORD`: senha forte para o acesso administrativo.
3. Faça novo deploy após configurar as variáveis.
4. O botão de checkout abre o Checkout Pro do Mercado Pago. Pix e cartão aparecem conforme os meios habilitados para sua conta e a disponibilidade para o comprador.

## Música e artistas reais — importante
As faixas incluídas são apenas áudios demonstrativos de teste (SoundHelix), com nomes de artistas fictícios da demonstração. Não são músicas de funkeiros, sertanejos ou artistas comerciais conhecidos. Não é legal nem tecnicamente possível incluir todas as gravações comerciais sem licenças e autorização dos titulares.

Para tocar o catálogo real, você precisa ter autorização/licença e hospedar os arquivos de áudio (ou integrar um fornecedor/licenciador que permita streaming). Depois substitua os objetos do array `tracks` em `app.js` pelos metadados e URLs autorizadas:
`id`, `title`, `artist`, `album`, `genre`, `url`, `length`, `a`, `b`.

## O que esta versão implementa
- Interface responsiva inspirada em serviços de streaming, com sidebar, busca, gêneros, lançamentos, fila e player.
- Player de áudio HTML com play/pause, próximo/anterior, aleatório, repetir, progresso e volume.
- Curtidas e playlists salvas localmente no navegador.
- Tela de planos e criação de preferência de checkout do Mercado Pago.
- Função de autenticação de senha administrativa via variável de ambiente.
- Endpoint inicial para webhook do Mercado Pago.

## O que ainda precisa de backend para produção
- Banco de dados multiusuário para biblioteca, artistas, álbuns, playlists e assinaturas.
- Login/cadastro e sessões seguras.
- Painel administrativo completo com upload de mídia e gestão persistente.
- Validação de assinatura de webhook + consulta de pagamento antes de liberar Premium.
- Para cobrança mensal automática, criar assinatura recorrente/preapproval no Mercado Pago. O checkout atual é pagamento único de R$ 19,90, não renovação automática.
- Licenças para catálogo comercial, direitos autorais e direitos de execução pública.
