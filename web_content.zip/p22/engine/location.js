/* ============================================================
   PENGGILAS BaZi
   ENGINE / location.js

   
   RESPONSIBILITY
   ------------------------------------------------------------
   Birth Location
   Latitude
   Longitude
   IANA Time Zone
   Historical UTC Offset
   Reference Meridian
   Location / Coordinate Source
   DST / Offset Status

   INPUT
   ------------------------------------------------------------
   Birth Place
   Birth Civil Date & Time

   IMPORTANT
   ------------------------------------------------------------
   - UTC Offset is NOT required from UI.
   - UTC Offset is resolved from IANA Time Zone.
   - No BaZi calculation.
   - No Solar Time calculation.
   - No Calendar calculation.
   - No Jie Qi calculation.
   - No interpretation.

   ONLINE
   ------------------------------------------------------------
   Open-Meteo Geocoding API

   TIME ZONE
   ------------------------------------------------------------
   Browser/runtime IANA timezone database through
   Intl.DateTimeFormat.

   SEARCH STRATEGY
   ------------------------------------------------------------
   The user may enter:

       Banyuwangi
       Banyuwangi Jawa Timur Indonesia
       Banyuwangi, Jawa Timur, Indonesia
       Banyuwangi, Indonesia

   The resolver progressively tries normalized variants.

============================================================ */


(function (global) {

    "use strict";


    const LOCATION_VERSION =
        "2.2.0";


    const OPEN_METEO_URL =
        "https://geocoding-api.open-meteo.com/v1/search";


    /* ========================================================
       PUBLIC LOCATION ENGINE
    ======================================================== */

    const PenggilasLocation = {


        version:
            LOCATION_VERSION,


        OPEN_METEO_URL:
            OPEN_METEO_URL,


        /* ====================================================
           RESOLVE LOCATION
        ==================================================== */

        async resolve(
            birthPlace,
            utcOffsetIgnored,
            birthDateTime
        ) {


            /*
             * ------------------------------------------------
             * Compatibility
             * ------------------------------------------------
             *
             * Older app.js versions may still send a second
             * argument containing UTC offset.
             *
             * It is intentionally ignored.
             *
             * Authoritative flow:
             *
             * Birth Place
             *      ↓
             * Geocoding
             *      ↓
             * IANA Time Zone
             *      ↓
             * Historical UTC Offset
             *      ↓
             * Reference Meridian
             *
             * ------------------------------------------------
             */


            /* =================================================
               INPUT VALIDATION
            ================================================= */

            /*
             * V1.23 UI may submit an authoritative candidate selected
             * from the location picker.  Keep the legacy string contract
             * fully intact, but when a selected candidate is supplied,
             * use its coordinates/timezone directly instead of geocoding
             * the display query again.  This is a location-input bridge
             * change only; the downstream UTC-offset, meridian and DST
             * calculations remain exactly the same.
             */
            const selectedCandidate =
                birthPlace &&
                typeof birthPlace === "object" &&
                !Array.isArray(birthPlace)
                    ? birthPlace
                    : null;

            if (
                typeof birthPlace !== "string" &&
                !selectedCandidate
            ) {

                throw new Error(
                    "Birth Place is required."
                );

            }


            const originalQuery =
                selectedCandidate
                    ? [
                        selectedCandidate.name,
                        selectedCandidate.admin1,
                        selectedCandidate.country
                    ]
                        .filter(function (value) {
                            return typeof value === "string" && value.trim();
                        })
                        .join(", ")
                        .replace(/\s+/g, " ")
                        .trim()
                    : birthPlace
                        .replace(
                            /\s+/g,
                            " "
                        )
                        .trim();


            if (
                !originalQuery
            ) {

                throw new Error(
                    "Birth Place is empty."
                );

            }


            if (
                !birthDateTime ||
                !(
                    birthDateTime instanceof Date
                ) ||
                Number.isNaN(
                    birthDateTime.getTime()
                )
            ) {

                throw new Error(
                    "Birth date/time is required for timezone resolution."
                );

            }


            /* =================================================
               BUILD QUERY VARIANTS / AUTHORITATIVE SELECTION
            ================================================= */

            const queries =
                selectedCandidate
                    ? []
                    : this.buildQueries(
                        originalQuery
                    );


            if (!selectedCandidate) {
                console.log(
                    "[PenggilasLocation] Search queries:",
                    queries
                );
            }


            let match =
                selectedCandidate ||
                null;


            let usedQuery =
                selectedCandidate
                    ? "UI_SELECTED_CANDIDATE"
                    : null;


            let lastApiError =
                null;

            let selectionBlocked =
                false;


            /* =================================================
               SEARCH
               Legacy string-input path is unchanged.
            ================================================= */

            for (
                const query
                of queries
            ) {

                try {

                    const results =
                        await this.searchOpenMeteo(
                            query
                        );


                    if (
                        !Array.isArray(
                            results
                        ) ||
                        !results.length
                    ) {

                        continue;

                    }


                    const selection =
                        this.selectBestMatch(
                            originalQuery,
                            query,
                            results
                        );

                    if (selection && selection.status === "AMBIGUOUS") {
                        selectionBlocked = true;
                        break;
                    }

                    const selected =
                        selection && selection.result
                            ? selection.result
                            : null;

                    if (selected) {
                        match = selected;
                        usedQuery = query;
                        break;
                    }

                }
                catch (
                    error
                ) {

                    lastApiError =
                        error;

                }

            }


            /* =================================================
               LOCATION NOT FOUND
            ================================================= */

            if (
                !match
            ) {

                if (selectionBlocked) {
                    throw new Error(
                        `Location is ambiguous or low-confidence and requires a more specific birth-place query: ${originalQuery}`
                    );
                }

                if (
                    lastApiError
                ) {

                    throw new Error(
                        `Location service error: ${lastApiError.message}`
                    );

                }


                throw new Error(
                    `Location not found or could not be confidently resolved: ${originalQuery}`
                );

            }


            /* =================================================
               BASIC LOCATION DATA
            ================================================= */

            const latitude =
                Number(
                    match.latitude
                );


            const longitude =
                Number(
                    match.longitude
                );


            const timezone =
                typeof match.timezone === "string"
                    ? match.timezone.trim()
                    : null;


            if (
                !Number.isFinite(
                    latitude
                )
            ) {

                throw new Error(
                    `Location latitude is unavailable: ${originalQuery}`
                );

            }


            if (
                !Number.isFinite(
                    longitude
                )
            ) {

                throw new Error(
                    `Location longitude is unavailable: ${originalQuery}`
                );

            }


            if (
                !timezone
            ) {

                throw new Error(
                    `IANA Time Zone is unavailable for: ${originalQuery}`
                );

            }


            /* =================================================
               UTC OFFSET
            ================================================= */

            const resolvedOffsetMinutes =
                getTimeZoneOffsetMinutes(
                    timezone,
                    birthDateTime
                );


            if (
                resolvedOffsetMinutes === null
            ) {

                throw new Error(
                    `UTC Offset could not be resolved for timezone ${timezone}.`
                );

            }


            const resolvedUtcOffset =
                resolvedOffsetMinutes / 60;


            /* =================================================
               REFERENCE MERIDIAN
            ================================================= */

            const referenceMeridian =
                calculateReferenceMeridian(
                    resolvedUtcOffset
                );


            /* =================================================
               DST / OFFSET STATUS
            ================================================= */

            const dstResult =
                resolveDSTStatus(
                    timezone,
                    birthDateTime,
                    resolvedOffsetMinutes
                );


            /* =================================================
               FINAL FOUNDATION
            ================================================= */

            const finalResult = {


                query:
                    originalQuery,


                searchQuery:
                    usedQuery,


                status:
                    "RESOLVED",


                location: {

                    name:
                        match.name ??
                        null,


                    country:
                        match.country ??
                        null,


                    countryCode:
                        match.country_code ??
                        null,


                    admin1:
                        match.admin1 ??
                        null,


                    admin2:
                        match.admin2 ??
                        null

                },


                coordinates: {

                    latitude:
                        latitude,


                    longitude:
                        longitude

                },


                timeZone: {

                    iana:
                        timezone,


                    utcOffset:
                        resolvedUtcOffset,


                    utcOffsetMinutes:
                        resolvedOffsetMinutes,


                    source:
                        "Open-Meteo IANA Time Zone + Intl.DateTimeFormat"

                },


                referenceMeridian: {

                    degrees:
                        referenceMeridian,


                    unit:
                        "degrees",


                    formula:
                        "UTC Offset × 15°"

                },


                coordinateSource: {

                    provider:
                        "Open-Meteo Geocoding API",


                    status:
                        "RESOLVED"

                },


                dst:
                    dstResult

            };


            console.log(
                "[PenggilasLocation] RESOLVED:",
                finalResult
            );


            return finalResult;

        },


        /* ====================================================
           BUILD SEARCH QUERIES
        ==================================================== */

        buildQueries(
            input
        ) {


            const cleaned =
                normalizeWhitespace(
                    input
                );


            const queries = [];


            /*
             * ------------------------------------------------
             * 1. Original normalized query
             * ------------------------------------------------
             */

            addUniqueQuery(
                queries,
                cleaned
            );


            /*
             * ------------------------------------------------
             * Canonical geographic aliases
             *
             * Open-Meteo returns English administrative names.
             * Indonesian users commonly enter local province
             * names (e.g. Jawa Tengah). Add a canonical query
             * variant without discarding the user's original.
             * ------------------------------------------------
             */

            const canonicalQuery =
                buildCanonicalLocationQuery(
                    cleaned
                );

            if (
                canonicalQuery &&
                normalizeText(canonicalQuery) !== normalizeText(cleaned)
            ) {
                addUniqueQuery(
                    queries,
                    canonicalQuery
                );
            }


            /*
             * ------------------------------------------------
             * Split by comma
             * ------------------------------------------------
             */

            const commaParts =
                cleaned
                    .split(",")
                    .map(
                        value =>
                            value.trim()
                    )
                    .filter(
                        Boolean
                    );


            /*
             * ------------------------------------------------
             * 2. First two comma components
             * ------------------------------------------------
             */

            if (
                commaParts.length >= 2
            ) {

                addUniqueQuery(
                    queries,
                    commaParts
                        .slice(
                            0,
                            2
                        )
                        .join(", ")
                );

            }


            /*
             * ------------------------------------------------
             * 3. First comma component
             * ------------------------------------------------
             */

            if (
                commaParts.length >= 1
            ) {

                addUniqueQuery(
                    queries,
                    commaParts[0]
                );

            }


            /*
             * ------------------------------------------------
             * Space-separated fallback
             *
             * Example:
             *
             * Banyuwangi Jawa Timur Indonesia
             *
             * becomes:
             *
             * Banyuwangi Jawa Timur
             * Banyuwangi Indonesia
             * Banyuwangi
             *
             * ------------------------------------------------
             */

            const words =
                cleaned
                    .split(" ")
                    .filter(
                        Boolean
                    );


            const hasGeographicQualifier =
                hasKnownGeographicQualifier(cleaned);

            /*
             * ------------------------------------------------
             * Space-separated fallback
             *
             * IMPORTANT: Do not collapse a qualified birth-place
             * into a bare city name. That turns a constrained
             * location request such as
             * "Solo Jawa Tengah Indonesia" into "Solo", which
             * can resolve to unrelated places in other countries.
             * ------------------------------------------------
             */

            if (
                !hasGeographicQualifier &&
                words.length >= 3
            ) {

                addUniqueQuery(
                    queries,
                    words
                        .slice(
                            0,
                            words.length - 1
                        )
                        .join(" ")
                );


                addUniqueQuery(
                    queries,
                    `${words[0]} ${words[words.length - 1]}`
                );

            }


            if (
                !hasGeographicQualifier &&
                words.length >= 2
            ) {

                addUniqueQuery(
                    queries,
                    words[0]
                );

            }


            /*
             * ------------------------------------------------
             * 4. First token
             * ------------------------------------------------
             */

            if (
                !hasGeographicQualifier &&
                words.length >= 1
            ) {

                addUniqueQuery(
                    queries,
                    words[0]
                );

            }


            return queries;

        },


        /* ====================================================
           SELECT BEST GEOCODING MATCH
        ==================================================== */

        selectBestMatch(
            originalQuery,
            searchQuery,
            results
        ) {


            if (
                !Array.isArray(
                    results
                ) ||
                !results.length
            ) {

                return null;

            }


            const normalizedOriginal =
                normalizeText(
                    originalQuery
                );


            const normalizedSearch =
                normalizeText(
                    searchQuery
                );


            /* =================================================
               MINIMUM FOUNDATION REQUIREMENTS
            ================================================= */

            const candidates =
                results.filter(
                    result => {

                        return (

                            Number.isFinite(
                                Number(
                                    result.latitude
                                )
                            )

                            &&

                            Number.isFinite(
                                Number(
                                    result.longitude
                                )
                            )

                            &&

                            typeof
                                result.timezone ===
                                "string"

                            &&

                            result.timezone.trim()
                                .length > 0

                        );

                    }
                );


            if (
                !candidates.length
            ) {

                return { status: "NO_MATCH", result: null };

            }


            const normalizedOriginalForAmbiguity =
                normalizeText(originalQuery);

            if (
                normalizedOriginalForAmbiguity.split(" ").filter(Boolean).length === 1
            ) {
                const exactNameCandidates =
                    candidates.filter(
                        result =>
                            normalizeText(result.name ?? "") ===
                            normalizedOriginalForAmbiguity
                    );

                const distinctPlaces =
                    new Set(
                        exactNameCandidates.map(
                            result =>
                                [
                                    normalizeText(result.country ?? ""),
                                    normalizeText(result.admin1 ?? ""),
                                    normalizeText(result.admin2 ?? "")
                                ].join("|")
                        )
                    );

                if (distinctPlaces.size > 1) {
                    return { status: "AMBIGUOUS", result: null };
                }
            }


            /* =================================================
               SCORE
            ================================================= */

            const constraints =
                deriveLocationConstraints(
                    originalQuery
                );

            const constrainedCandidates =
                candidates.filter(
                    result =>
                        matchesLocationConstraints(
                            result,
                            constraints
                        )
                );

            if (
                !constrainedCandidates.length
            ) {
                return { status: "NO_MATCH", result: null };
            }

            const scored =
                constrainedCandidates.map(
                    result => {


                        const name =
                            normalizeText(
                                result.name ??
                                ""
                            );


                        const country =
                            normalizeText(
                                result.country ??
                                ""
                            );


                        const admin1 =
                            normalizeText(
                                result.admin1 ??
                                ""
                            );


                        const admin2 =
                            normalizeText(
                                result.admin2 ??
                                ""
                            );


                        let score =
                            0;


                        /* -------------------------------------
                           Exact name
                        ------------------------------------- */

                        if (
                            normalizedOriginal ===
                            name
                        ) {

                            score += 100;

                        }


                        if (
                            normalizedSearch ===
                            name
                        ) {

                            score += 90;

                        }


                        /* -------------------------------------
                           Original contains name
                        ------------------------------------- */

                        if (
                            name &&
                            normalizedOriginal.includes(
                                name
                            )
                        ) {

                            score += 50;

                        }


                        /* -------------------------------------
                           Search contains name
                        ------------------------------------- */

                        if (
                            name &&
                            normalizedSearch.includes(
                                name
                            )
                        ) {

                            score += 40;

                        }


                        /* -------------------------------------
                           Name contains search
                        ------------------------------------- */

                        if (
                            name &&
                            name.includes(
                                normalizedSearch
                            )
                        ) {

                            score += 30;

                        }


                        /* -------------------------------------
                           Admin region
                        ------------------------------------- */

                        if (
                            admin1 &&
                            normalizedOriginal.includes(
                                admin1
                            )
                        ) {

                            score += 25;

                        }


                        if (
                            admin2 &&
                            normalizedOriginal.includes(
                                admin2
                            )
                        ) {

                            score += 15;

                        }


                        /* -------------------------------------
                           Country
                        ------------------------------------- */

                        if (
                            country &&
                            normalizedOriginal.includes(
                                country
                            )
                        ) {

                            score += 25;

                        }


                        /* -------------------------------------
                           Population
                        ------------------------------------- */

                        const population =
                            Number(
                                result.population
                            );


                        if (
                            Number.isFinite(
                                population
                            )
                        ) {

                            score +=
                                Math.min(
                                    population /
                                    1000000,
                                    10
                                );

                        }


                        return {

                            result:
                                result,

                            score:
                                score

                        };

                    }
                );


            /* =================================================
               SORT
            ================================================= */

            scored.sort(
                (
                    a,
                    b
                ) =>
                    b.score -
                    a.score
            );


            const best = scored[0] || null;
            const second = scored[1] || null;
            const minimumScore = 100;
            const minimumMargin = 8;
            const scoreMargin = second ? best.score - second.score : Infinity;

            // A location is authoritative only when the semantic match is
            // sufficiently strong and not materially tied with another result.
            // Population is only a tie-breaker component; it cannot override
            // an unresolved semantic ambiguity.
            const accepted =
                !!best &&
                best.score >= minimumScore &&
                scoreMargin >= minimumMargin;

            if (!accepted) {
                console.warn(
                    "[PenggilasLocation] Ambiguous/low-confidence location match:",
                    {
                        originalQuery: originalQuery,
                        searchQuery: searchQuery,
                        bestScore: best ? best.score : null,
                        secondScore: second ? second.score : null,
                        scoreMargin: Number.isFinite(scoreMargin) ? scoreMargin : null
                    }
                );
                return { status: "AMBIGUOUS", result: null };
            }

            const selected = best.result;

            console.log(
                "[PenggilasLocation] Candidate accepted:",
                selected.name,
                selected.country,
                selected.admin1,
                selected.timezone,
                "score=", best.score,
                "margin=", scoreMargin
            );

            return { status: "ACCEPTED", result: selected };

        },


        /* ====================================================
           OPEN-METEO SEARCH
        ==================================================== */

        async searchOpenMeteo(
            query
        ) {


            const url =
                new URL(
                    this.OPEN_METEO_URL
                );


            url.searchParams.set(
                "name",
                query
            );


            url.searchParams.set(
                "count",
                "10"
            );


            url.searchParams.set(
                "language",
                "en"
            );


            url.searchParams.set(
                "format",
                "json"
            );


            let response;


            try {

                response =
                    await fetch(
                        url.toString(),
                        {
                            method:
                                "GET",

                            headers: {
                                "Accept":
                                    "application/json"
                            },

                            cache:
                                "no-store"
                        }
                    );

            }
            catch (
                error
            ) {

                console.error(
                    "[PenggilasLocation] Network error:",
                    error
                );


                throw new Error(
                    "Open-Meteo Geocoding API could not be reached."
                );

            }


            if (
                !response.ok
            ) {

                throw new Error(
                    `Open-Meteo HTTP ${response.status}`
                );

            }


            let data;


            try {

                data =
                    await response.json();

            }
            catch (
                error
            ) {

                throw new Error(
                    "Open-Meteo returned invalid JSON."
                );

            }


            return (
                Array.isArray(
                    data.results
                )

                    ? data.results

                    : []
            );

        }

    };


    /* ========================================================
       HELPERS
    ======================================================== */


    const LOCATION_ALIASES = Object.freeze({
        "jawa tengah": "central java",
        "jawa timur": "east java",
        "jawa barat": "west java",
        "daerah istimewa yogyakarta": "special region of yogyakarta",
        "yogyakarta": "yogyakarta",
        "sulawesi selatan": "south sulawesi",
        "sulawesi tengah": "central sulawesi",
        "sulawesi utara": "north sulawesi",
        "sulawesi tenggara": "southeast sulawesi",
        "kalimantan timur": "east kalimantan",
        "kalimantan barat": "west kalimantan",
        "kalimantan tengah": "central kalimantan",
        "kalimantan selatan": "south kalimantan",
        "sumatera utara": "north sumatra",
        "sumatera barat": "west sumatra",
        "sumatera selatan": "south sumatra",
        "kepulauan riau": "riau islands",
        "riau": "riau",
        "bali": "bali",
        "nusa tenggara barat": "west nusa tenggara",
        "nusa tenggara timur": "east nusa tenggara",
        "maluku": "maluku",
        "maluku utara": "north maluku",
        "papua": "papua",
        "papua barat": "west papua",
        "indonesia": "indonesia"
    });


    function buildCanonicalLocationQuery(
        input
    ) {
        const normalized = normalizeText(input);
        let canonical = normalized;

        Object.keys(LOCATION_ALIASES)
            .sort((a, b) => b.length - a.length)
            .forEach(alias => {
                const replacement = LOCATION_ALIASES[alias];
                canonical = canonical.replace(
                    new RegExp(`\\b${escapeRegExp(alias)}\\b`, "g"),
                    replacement
                );
            });

        return normalizeWhitespace(canonical);
    }


    function deriveLocationConstraints(
        originalQuery
    ) {
        const normalized = normalizeText(originalQuery);
        const constraints = {
            country: null,
            admin1: null
        };

        const countryAliases = [
            ["indonesia", "indonesia"]
        ];

        for (const [alias, canonical] of countryAliases) {
            if (hasPhrase(normalized, alias)) {
                constraints.country = canonical;
                break;
            }
        }

        const adminAliases = [
            ["jawa tengah", "central java"],
            ["jawa timur", "east java"],
            ["jawa barat", "west java"],
            ["daerah istimewa yogyakarta", "special region of yogyakarta"],
            ["sulawesi selatan", "south sulawesi"],
            ["sulawesi tengah", "central sulawesi"],
            ["sulawesi utara", "north sulawesi"],
            ["sulawesi tenggara", "southeast sulawesi"],
            ["kalimantan timur", "east kalimantan"],
            ["kalimantan barat", "west kalimantan"],
            ["kalimantan tengah", "central kalimantan"],
            ["kalimantan selatan", "south kalimantan"],
            ["sumatera utara", "north sumatra"],
            ["sumatera barat", "west sumatra"],
            ["sumatera selatan", "south sumatra"],
            ["kepulauan riau", "riau islands"],
            ["nusa tenggara barat", "west nusa tenggara"],
            ["nusa tenggara timur", "east nusa tenggara"],
            ["maluku utara", "north maluku"],
            ["papua barat", "west papua"]
        ];

        for (const [alias, canonical] of adminAliases) {
            if (hasPhrase(normalized, alias)) {
                constraints.admin1 = canonical;
                break;
            }
        }

        return constraints;
    }


    function matchesLocationConstraints(
        result,
        constraints
    ) {
        const country = normalizeText(result.country ?? "");
        const admin1 = normalizeText(result.admin1 ?? "");

        if (
            constraints.country &&
            !semanticLocationMatch(country, constraints.country)
        ) {
            return false;
        }

        if (
            constraints.admin1 &&
            !semanticLocationMatch(admin1, constraints.admin1)
        ) {
            return false;
        }

        return true;
    }


    function semanticLocationMatch(
        actual,
        expected
    ) {
        if (actual === expected) return true;
        if (actual.includes(expected)) return true;
        if (expected.includes(actual) && actual.length >= 4) return true;
        return false;
    }


    function hasKnownGeographicQualifier(
        input
    ) {
        const normalized = normalizeText(input);
        return Object.keys(LOCATION_ALIASES).some(
            alias => hasPhrase(normalized, alias)
        );
    }


    function hasPhrase(
        normalizedText,
        phrase
    ) {
        return new RegExp(`\\b${escapeRegExp(phrase)}\\b`).test(normalizedText);
    }


    function escapeRegExp(
        value
    ) {
        return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }


    function addUniqueQuery(
        array,
        value
    ) {


        const normalized =
            normalizeWhitespace(
                value
            );


        if (
            !normalized
        ) {

            return;

        }


        const exists =
            array.some(
                item =>
                    normalizeText(item) ===
                    normalizeText(normalized)
            );


        if (
            !exists
        ) {

            array.push(
                normalized
            );

        }

    }


    /* ========================================================
       NORMALIZE WHITESPACE
    ======================================================== */

    function normalizeWhitespace(
        value
    ) {


        return String(
            value ??
            ""
        )
        .replace(
            /\s+/g,
            " "
        )
        .trim();

    }


    /* ========================================================
       NORMALIZE TEXT
    ======================================================== */

    function normalizeText(
        value
    ) {


        return String(
            value ??
            ""
        )
        .normalize(
            "NFD"
        )
        .replace(
            /[\u0300-\u036f]/g,
            ""
        )
        .toLowerCase()
        .replace(
            /[^a-z0-9]+/g,
            " "
        )
        .trim();

    }


    /* ========================================================
       REFERENCE MERIDIAN
    ======================================================== */

    function calculateReferenceMeridian(
        utcOffset
    ) {


        if (
            !Number.isFinite(
                utcOffset
            )
        ) {

            return null;

        }


        return (
            utcOffset * 15
        );

    }


    /* ========================================================
       DST / OFFSET STATUS
    ======================================================== */

    function resolveDSTStatus(
        timezone,
        birthDateTime,
        resolvedOffsetMinutes
    ) {


        if (
            !timezone
        ) {

            return {

                status:
                    "UNRESOLVED",

                reason:
                    "IANA time zone is unavailable."

            };

        }


        if (
            !birthDateTime
        ) {

            return {

                status:
                    "UNRESOLVED",

                reason:
                    "Birth date/time is required."

            };

        }


        if (
            resolvedOffsetMinutes === null ||
            !Number.isFinite(
                resolvedOffsetMinutes
            )
        ) {

            return {

                status:
                    "UNRESOLVED",

                reason:
                    "Timezone offset could not be resolved."

            };

        }


        try {


            new Intl.DateTimeFormat(
                "en-US",
                {
                    timeZone:
                        timezone
                }
            );


            return {

                status:
                    "RESOLVED",


                iana:
                    timezone,


                offsetMinutes:
                    resolvedOffsetMinutes,


                offsetHours:
                    resolvedOffsetMinutes /
                    60,


                determination:
                    "TIMEZONE_OFFSET_RESOLVED",


                note:
                    "Historical timezone offset resolved from IANA timezone data. DST activation is not independently classified by this resolver."

            };

        }


        catch (
            error
        ) {


            return {

                status:
                    "UNRESOLVED",


                reason:
                    error.message

            };

        }

    }


    /* ========================================================
       GET TIMEZONE OFFSET
    ======================================================== */

    function getTimeZoneOffsetMinutes(
        timezone,
        date
    ) {


        try {


            const formatter =
                new Intl.DateTimeFormat(
                    "en-US",
                    {

                        timeZone:
                            timezone,


                        year:
                            "numeric",


                        month:
                            "2-digit",


                        day:
                            "2-digit",


                        hour:
                            "2-digit",


                        minute:
                            "2-digit",


                        second:
                            "2-digit",


                        hourCycle:
                            "h23"

                    }
                );


            const parts =
                formatter.formatToParts(
                    date
                );


            const values = {};


            for (
                const part
                of parts
            ) {


                if (
                    part.type !==
                    "literal"
                ) {

                    values[
                        part.type
                    ] =
                        part.value;

                }

            }


            if (
                !values.year ||
                !values.month ||
                !values.day ||
                !values.hour ||
                !values.minute ||
                !values.second
            ) {

                return null;

            }


            const asUTC =
                Date.UTC(

                    Number(
                        values.year
                    ),

                    Number(
                        values.month
                    ) - 1,

                    Number(
                        values.day
                    ),

                    Number(
                        values.hour
                    ),

                    Number(
                        values.minute
                    ),

                    Number(
                        values.second
                    )

                );


            const original =
                date.getTime();


            return (

                (
                    asUTC -
                    original
                ) /
                60000

            );

        }


        catch (
            error
        ) {


            console.error(
                "[PenggilasLocation] Timezone offset error:",
                error
            );


            return null;

        }

    }


    /* ========================================================
       PUBLIC API
    ======================================================== */

    global.PenggilasLocation =
        Object.freeze(
            PenggilasLocation
        );


})(window);