# TEMPLATE — Output Contracts & Human Presentation

## 1. Fungsi
Folder `template/` mendefinisikan bentuk output yang harus dipenuhi oleh presentation layer.

Template **bukan engine BaZi** dan bukan sumber kebenaran analitis. Sumber kebenaran tetap:

```text
FINAL window.masterResult
```

## 2. Isi folder

| File | Fungsi |
|---|---|
| `result-template.html` | Struktur dokumen/report HTML yang menjadi human-facing output contract. |
| `result-template.js` | Membaca `MasterResult` dan mengisi/bind data ke struktur HTML. |
| `result-template.css` | Styling untuk human-facing result. |
| `ai-result-template.json` | Structural template yang digunakan mapper untuk membentuk AI-facing JSON. Bukan hasil AI yang tersimpan. |
| `SEMANTIC_CONTRACT.md` | Aturan semantic presentation, status, field roles, null boundary, dan AI hygiene. |

## 3. Dokumentasi dan contract hierarchy

README ini adalah entry point `template/`. Detail semantic rules sengaja tetap berada di `SEMANTIC_CONTRACT.md` karena dokumen tersebut menjadi kontrak khusus untuk status, evidence, null boundary, dan AI hygiene.

```text
PRODUCTION_ARCHITECTURE.md
        ↓
template/README.md          ← operational map
        ↓
SEMANTIC_CONTRACT.md        ← semantic detail
        ↓
result-template.* / ai-result-template.json
```

`../DRAFT_TEMPLATE_BAZI_CONTRACT.md` adalah referensi struktur A/B/C; ia bukan engine dan bukan pengganti semantic contract.

## 4. Siapa yang memanggil

Human result:

```text
FINAL MasterResult
 ↓
app.js / result event
 ↓
template/result-template.js
 ↓
template/result-template.html
```

AI result:

```text
FINAL MasterResult
 ↓
ui/report/report.js
 ↓
core/json-mapper.js
 ↓
template/ai-result-template.json
 ↓
AI JSON
```

## 5. Input

Input utama presentation adalah `MasterResult` final.

Template tidak boleh membutuhkan perhitungan BaZi baru untuk mengisi field yang sudah seharusnya tersedia di MasterResult.

## 6. Output

Ada dua output berbeda:

- **Human HTML** — untuk pembacaan/rendering pengguna.
- **AI JSON** — projection terstruktur untuk konsumsi LLM.

Keduanya harus merepresentasikan data dari MasterResult yang sama.

## 7. Batas kewenangan

### Boleh
- menentukan urutan dan bentuk penyajian;
- melakukan formatting/presentation binding;
- memetakan field MasterResult ke field output;
- mempertahankan semantic distinctions seperti Result, Evidence, Source/Basis, Condition, Qualification, Status, Verification.

### Tidak boleh
- menghitung ulang BaZi;
- membuat determination baru;
- mengubah status `FINAL`, `PROVISIONAL`, `CANDIDATE`, `UNRESOLVED`, `MULTI_METHOD`, atau `CONFLICT` demi tampilan;
- mengubah null menjadi false/UNRESOLVED/VERIFIED secara diam-diam;
- menganggap `ai-result-template.json` sebagai AI result final.

## 8. Hubungan dengan UI chart

Chart UI bukan bagian dari folder `template/`. Chart berada di `ui/chart/` karena chart adalah presentation component.

```text
MasterResult → ui/chart/chart.js → local chart view-model → Chart UI
```

Projection chart tidak boleh ditulis kembali ke MasterResult.
