"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const inputJs = fs.readFileSync(path.join(root, "ui/input/input.js"), "utf8");

// Reproduce the formatter logic with the same select-value types (strings).
const sandbox = { document: { addEventListener: function () {} } };
vm.runInNewContext(`
  ${inputJs}
  this.__formatDate = (function () {
    function pad2(value) { return String(value).padStart(2, "0"); }
    function isValidDateParts(day, monthIndex, year) {
      if (day === "" || monthIndex === "" || year === "" || day == null || monthIndex == null || year == null) return false;
      var numericDay = Number(day), numericMonth = Number(monthIndex), numericYear = Number(year);
      if (!numericDay || numericMonth < 0 || !numericYear) return false;
      if (numericYear < 1900 || numericMonth > 11) return false;
      var daysInMonth = new Date(numericYear, numericMonth + 1, 0).getDate();
      return numericDay >= 1 && numericDay <= daysInMonth;
    }
    return function(day, monthIndex, year) {
      if (!isValidDateParts(day, monthIndex, year)) return "";
      var numericDay = Number(day);
      var numericMonth = Number(monthIndex);
      var numericYear = Number(year);
      return String(numericYear) + "-" + pad2(numericMonth + 1) + "-" + pad2(numericDay);
    };
  })();
`, sandbox);

assert.strictEqual(sandbox.__formatDate("17", "5", "1983"), "1983-06-17");
assert.strictEqual(sandbox.__formatDate("29", "1", "1984"), "1984-02-29");
assert.strictEqual(sandbox.__formatDate("31", "1", "1983"), "");

// The production source must explicitly convert the select values before month arithmetic.
assert.match(inputJs, /var numericMonth = Number\(monthIndex\);/);
assert.match(inputJs, /pad2\(numericMonth \+ 1\)/);

console.log("V1.23 input date formatter regression passed.");
