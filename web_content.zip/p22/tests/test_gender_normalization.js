const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
global.window = global;
function load(rel) { vm.runInThisContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), { filename: rel }); }
const lunar = require(path.join(ROOT, 'engine/lunar.js'));
global.Solar = lunar.Solar;
global.EightChar = lunar.EightChar;
['bazi-data.js','engine/solar.js','engine/jieqi.js','engine/calendar.js','core/coreA.js'].forEach(load);
global.PenggilasLocation = { resolve: async () => ({
  location:{name:'Jakarta',admin1:'DKI Jakarta',country:'Indonesia'},
  coordinates:{latitude:-6.2088,longitude:106.8456},
  timeZone:{iana:'Asia/Jakarta',utcOffset:7}, referenceMeridian:{degrees:105},
  coordinateSource:{provider:'runtime-fixture'}, dst:{isDst:false}
})};
function comparable(result){ const clone=JSON.parse(JSON.stringify(result)); delete clone._nodeExecution; delete clone._engineExecution; function strip(v){ if(Array.isArray(v)) return v.map(strip); if(v&&typeof v==='object'){ const o={}; for(const [k,val] of Object.entries(v)) if(k!=='verifyDate') o[k]=strip(val); return o; } return v; } return strip(clone); }
async function calculate(gender){ return global.PenggilasCoreA.calculate({name:'Gender Audit',gender,birthDate:'1983-06-17',birthTime:'12:15',birthPlace:{query:'Jakarta'}}); }
(async()=>{
 const male=await calculate('Male'), maleLower=await calculate('male'), maleSpaced=await calculate('  Male  ');
 assert.deepStrictEqual(comparable(male),comparable(maleLower)); assert.deepStrictEqual(comparable(male),comparable(maleSpaced));
 assert.strictEqual(male.A14_1.direction,'Ni (逆行 — Reverse)');
 const female=await calculate('Female'), femaleLower=await calculate('female'), femaleSpaced=await calculate('  Female  ');
 assert.deepStrictEqual(comparable(female),comparable(femaleLower)); assert.deepStrictEqual(comparable(female),comparable(femaleSpaced));
 assert.strictEqual(female.A14_1.direction,'Shun (顺行 — Forward)');
 for(const invalid of ['', 'unknown', 'MALEISH', null, undefined, 1]) await assert.rejects(()=>calculate(invalid),/Gender must be Male or Female/);
 console.log('PASS: gender normalization, Da Yun direction equivalence, and invalid-value rejection.');
})().catch(error=>{console.error(error);process.exit(1);});
