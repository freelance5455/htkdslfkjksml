const assert = require('assert');
const fs = require('fs');
const vm = require('vm');

const source = fs.readFileSync(require('path').join(__dirname, '..', 'engine', 'location.js'), 'utf8');
const context = { window: {}, console };
vm.createContext(context);
vm.runInContext(source, context);
const location = context.window.PenggilasLocation;

function candidate(name, country, admin1, admin2, population = 100000) {
  return {
    name, country, country_code: country === 'Indonesia' ? 'ID' : 'XX', admin1, admin2,
    latitude: 0, longitude: 0, timezone: country === 'Indonesia' ? 'Asia/Jakarta' : 'Asia/Manila', population
  };
}

const soloIndonesia = candidate('Solo', 'Indonesia', 'Central Java', 'Surakarta', 500000);
const soloSulawesi = candidate('Solo', 'Indonesia', 'South Sulawesi', 'Some Regency', 900000);
const soloPhilippines = candidate('Solo', 'Philippines', 'Calabarzon', 'Some Province', 1200000);

// Qualified Indonesian input must never degrade to a bare "Solo" search.
const queries = location.buildQueries('SOLO JAWA TENGAH INDONESIA');
assert(queries.some(q => q.toLowerCase().includes('solo central java indonesia')),
  'canonical English query for Jawa Tengah was not generated');
assert(!queries.some(q => q.toLowerCase() === 'solo'),
  'qualified location must not fall back to bare city name');

const qualified = location.selectBestMatch(
  'SOLO JAWA TENGAH INDONESIA',
  'SOLO CENTRAL JAVA INDONESIA',
  [soloIndonesia, soloSulawesi, soloPhilippines]
);
assert.strictEqual(qualified.status, 'ACCEPTED');
assert.strictEqual(qualified.result.admin1, 'Central Java');
assert.strictEqual(qualified.result.country, 'Indonesia');

// A bare ambiguous name must fail closed rather than choosing by population.
const ambiguous = location.selectBestMatch(
  'Solo',
  'Solo',
  [soloIndonesia, soloSulawesi, soloPhilippines]
);
assert.strictEqual(ambiguous.status, 'AMBIGUOUS');

// A qualified query must reject a result from another country even if its name is exact.
const wrongCountry = location.selectBestMatch(
  'Solo Jawa Tengah Indonesia',
  'Solo',
  [soloPhilippines]
);
assert.strictEqual(wrongCountry.status, 'NO_MATCH');

console.log('Location qualified-resolution tests passed.');
