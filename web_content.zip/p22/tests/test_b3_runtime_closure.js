const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const ROOT = path.resolve(__dirname, '..');
global.window = global;
function load(rel) { vm.runInThisContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), { filename: rel }); }
const lunar = require(path.join(ROOT, 'engine/lunar.js'));
global.Solar = lunar.Solar;
global.EightChar = lunar.EightChar;
[
  'bazi-data.js','engine/solar.js','engine/jieqi.js','engine/calendar.js',
  'data/sources/classical_sources_B_C.js','data/rules/classical_rules_B_C.js',
  'data/rules/classical_rule_evaluator.js','data/evidence/closure_signal_contract.js',
  'data/evidence/runtime_evidence_normalizer.js','core/coreA.js','core/coreB.js'
].forEach(load);
global.PenggilasLocation = { resolve: async () => ({
  location: { name: 'Jakarta', admin1: 'DKI Jakarta', country: 'Indonesia' },
  coordinates: { latitude: -6.2088, longitude: 106.8456 },
  timeZone: { iana: 'Asia/Jakarta', utcOffset: 7 }, referenceMeridian: { degrees: 105 },
  coordinateSource: { provider: 'runtime-fixture' }, dst: { isDst: false }
}) };

async function run(date, time) {
  global.masterResult = null; global.PENGGILAS_RAW_CHART = null;
  await global.PenggilasCoreA.calculate({ birthDate: date, birthTime: time, birthPlace: { query: 'Jakarta' }, gender: 'male' });
  global.PenggilasCoreB.calculate();
  return global.masterResult;
}

(async () => {
  const N = global.PENGGILAS_CLASSICAL_RUNTIME_EVIDENCE_NORMALIZER;
  const cases = [
    ['Direct Officer Pattern (正官格)', '1850-09-01', '01:00', 'CS-B3-GEJU-OFFICER'],
    ['Resource Pattern (印格)', '1850-01-19', '01:00', 'CS-B3-GEJU-RESOURCE'],
    ['Eating God Pattern (食神格)', '1850-11-01', '01:00', 'CS-B3-GEJU-EATING-GOD'],
    ['Hurting Officer Pattern (伤官格)', '1850-01-25', '01:00', 'CS-B3-GEJU-HURTING-OFFICER'],
    ['Seven Killings Pattern (七杀格)', '1850-03-19', '07:00', 'CS-B3-GEJU-SEVEN-KILLINGS'],
    ['Establishing Prosperity / Month Rob Pattern (建禄月劫格)', '1850-01-01', '01:00', 'CS-B3-GEJU-JIAN-LU']
  ];
  for (const [label, date, time, family] of cases) {
    const master = await run(date, time);
    const branch = N.normalize(master, family);
    assert.ok(branch.length > 0, `${label}: runtime source-path closure evidence missing`);
  }

  // Reproducible runtime stability matrix: 16 varied birth dates × 4 times.
  // This is a fresh packaged smoke set, not a reconstruction of any historical
  // regression corpus that is not present in the package.
  const stabilityDates = [
    '1850-01-01','1850-03-19','1850-05-07','1850-07-23',
    '1880-02-11','1880-06-17','1880-10-29','1880-12-08',
    '1903-01-14','1903-04-26','1903-08-09','1903-11-19',
    '1945-02-03','1945-05-21','1981-09-13','2001-12-02'
  ];
  const stabilityTimes = ['01:00','07:00','13:00','19:00'];
  let stabilityCount = 0;
  for (const date of stabilityDates) {
    for (const time of stabilityTimes) {
      const master = await run(date, time);
      assert.ok(master && master.A1 && master.B3, `${date} ${time}: Foundation/Structure result missing`);
      stabilityCount += 1;
    }
  }
  assert.strictEqual(stabilityCount, 64, 'runtime stability matrix must contain 64 charts');
  console.log('PASS: B3 source-path fixtures and 64-chart runtime stability matrix.');
})();
