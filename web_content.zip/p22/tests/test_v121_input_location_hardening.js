"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const indexHtml = fs.readFileSync(path.join(root, "index.html"), "utf8");
const inputHtml = fs.readFileSync(path.join(root, "ui/input/input.html"), "utf8");
const inputCss = fs.readFileSync(path.join(root, "ui/input/input.css"), "utf8");
const inputJs = fs.readFileSync(path.join(root, "ui/input/input.js"), "utf8");
const appJs = fs.readFileSync(path.join(root, "app.js"), "utf8");

const versionToken = "20261007-v123";

// Cache-busted input module assets prevent stale HTML/CSS/JS combinations.
assert.match(indexHtml, new RegExp("ui/input/input\\.html\\?v=" + versionToken));
assert.match(inputHtml, new RegExp("input\\.css\\?v=" + versionToken));
assert.match(inputHtml, new RegExp("input\\.js\\?v=" + versionToken));

// Visible controls remain selectors; native controls stay programmatic picker targets.
assert.match(inputHtml, /id="birth-day"/);
assert.match(inputHtml, /id="birth-month"/);
assert.match(inputHtml, /id="birth-year"/);
assert.match(inputHtml, /id="birth-date-picker"[\s\S]*type="date"/);
assert.match(inputHtml, /id="birth-hour"/);
assert.match(inputHtml, /id="birth-minute"/);
assert.match(inputHtml, /id="birth-time-picker"[\s\S]*type="time"/);
assert.match(inputHtml, /data-native-picker="date"/);
assert.match(inputHtml, /data-native-picker="time"/);
assert.match(inputJs, /showPicker/);

// Native date/time fields must not occupy a visible form-sized box.
assert.match(inputCss, /\.native-picker-input\s*\{[\s\S]*width:\s*1px\s*!important/);
assert.match(inputCss, /\.native-picker-input\s*\{[\s\S]*height:\s*1px\s*!important/);
assert.match(inputCss, /\.native-picker-input\s*\{[\s\S]*opacity:\s*0\s*!important/);
assert.match(inputCss, /\.native-picker-input\s*\{[\s\S]*clip-path:\s*inset\(50%\)\s*!important/);

// Candidate list is in normal document flow so iframe height can include it.
assert.match(inputCss, /\.location-suggestions\s*\{[\s\S]*position:\s*relative/);
assert.doesNotMatch(inputCss, /\.location-suggestions\s*\{[\s\S]*position:\s*absolute/);
assert.match(inputJs, /renderLocationState\("Searching locations…"\)/);
assert.match(inputJs, /normalizeLocationResults/);
assert.match(inputJs, /count=10/);

// Raw place text must not reach the engine without an explicitly selected candidate.
assert.match(inputJs, /if \(!selectedLocation\) \{/);
assert.match(inputJs, /Choose a location candidate before calculating/);
assert.match(inputJs, /selected:\s*selectedLocation \?/);

// Calendar validity is checked before submission.
assert.match(inputJs, /isValidDateParts/);
assert.match(inputJs, /daysInMonth/);

// Parent shell receives an explicit resize signal when the candidate list changes.
assert.match(inputJs, /type: "BAZI_INPUT_RESIZE"/);
assert.match(appJs, /data\.type === "BAZI_INPUT_RESIZE"/);
assert.match(appJs, /syncModuleFrameHeight\(inputFrame\)/);

console.log("V1.21 input/location hardening tests passed.");
