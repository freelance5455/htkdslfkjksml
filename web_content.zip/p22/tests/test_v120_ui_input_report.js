"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const inputHtml = fs.readFileSync(path.join(root, "ui/input/input.html"), "utf8");
const inputJs = fs.readFileSync(path.join(root, "ui/input/input.js"), "utf8");
const appJs = fs.readFileSync(path.join(root, "app.js"), "utf8");
const reportHtml = fs.readFileSync(path.join(root, "ui/report/report.html"), "utf8");
const resultTemplate = fs.readFileSync(path.join(root, "template/result-template.html"), "utf8");

// Date/time UI contract.
assert.match(inputHtml, /id="birth-day"/);
assert.match(inputHtml, /id="birth-month"/);
assert.match(inputHtml, /id="birth-year"/);
assert.match(inputHtml, /id="birth-date-picker"[^>]*type="date"/);
assert.match(inputHtml, /id="birth-hour"/);
assert.match(inputHtml, /id="birth-minute"/);
assert.match(inputHtml, /id="birth-time-picker"[^>]*type="time"/);
assert.match(inputJs, /showPicker/);
assert.match(inputJs, /formatDate/);
assert.match(inputJs, /formatTime/);

// Online location candidates must be qualified before submission.
assert.match(inputJs, /geocoding-api\.open-meteo\.com\/v1\/search/);
assert.match(inputJs, /formatLocationQuery/);
assert.match(inputJs, /item\.name, item\.admin1, item\.country/);
assert.match(inputJs, /birthPlace:\s*\{\s*query:\s*place/);

// Report screen must restore the iframe after returning from the standalone template.
assert.match(appJs, /function restoreReportFrame\(\)/);
assert.match(appJs, /screenId === "screen-report"/);
assert.match(appJs, /reportFrame\.src = reportSrc/);
assert.match(reportHtml, /href="\.\.\/\.\.\/template\/result-template\.html"/);
assert.match(resultTemplate, /Back to Report/);
assert.match(resultTemplate, /id="back-to-report-button"/);

console.log("V1.20 UI input/location/report routing tests passed.");
