const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const ROOT = path.resolve(__dirname, '..');
global.window = global;
function load(rel) {
  vm.runInThisContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), { filename: rel });
}

const lunar = require(path.join(ROOT, 'engine/lunar.js'));
global.Solar = lunar.Solar;
global.EightChar = lunar.EightChar;
[
  'bazi-data.js', 'engine/solar.js', 'engine/jieqi.js', 'engine/calendar.js',
  'data/sources/classical_sources_B_C.js', 'data/rules/classical_rules_B_C.js',
  'data/rules/classical_rule_evaluator.js', 'data/evidence/closure_signal_contract.js',
  'data/evidence/runtime_evidence_normalizer.js', 'core/coreA.js', 'core/coreB.js',
  'data/determination-rules.js', 'core/determination.js', 'core/coreC.js',
  'core/json-mapper.js'
].forEach(load);

global.PenggilasLocation = { resolve: async () => ({
  location: { name: 'Jakarta', admin1: 'DKI Jakarta', country: 'Indonesia' },
  coordinates: { latitude: -6.2088, longitude: 106.8456 },
  timeZone: { iana: 'Asia/Jakarta', utcOffset: 7 },
  referenceMeridian: { degrees: 105 },
  coordinateSource: { provider: 'runtime-fixture' },
  dst: { isDst: false }
}) };

(async () => {
  global.masterResult = null;
  global.PENGGILAS_RAW_CHART = null;
  await global.PenggilasCoreA.calculate({
    birthDate: '1850-09-01',
    birthTime: '19:00',
    birthPlace: { query: 'Jakarta' },
    gender: 'male'
  });
  global.PenggilasCoreB.calculate();
  global.PenggilasDetermination.calculate();

  const contract = global.masterResult._determinationContract;
  assert.strictEqual(contract.authority.owner, 'DETERMINATION_CHAIN');

  Object.values(contract.claims).forEach(claim => {
    assert.ok(Array.isArray(claim.evidenceIds), `${claim.claimId}: evidenceIds missing`);
    assert.ok(Array.isArray(claim.ruleLinks), `${claim.claimId}: ruleLinks missing`);
    assert.ok(claim.ruleLinks.length > 0, `${claim.claimId}: no supporting rule link`);
    assert.ok(claim.authorityReconciliation, `${claim.claimId}: authority reconciliation missing`);
    assert.strictEqual(claim.authorityReconciliation.status, 'RECONCILED', `${claim.claimId}: authority mismatch`);
    if (claim.status === 'FINAL') {
      assert.ok(claim.evidenceIds.length > 0, `${claim.claimId}: FINAL without evidence IDs`);
      assert.notStrictEqual(claim.confidence, 'HIGH', `${claim.claimId}: HIGH must be independently gated by traceable evidence`);
    }
  });

  const mapper = global.PenggilasJSONMapper;
  const template = JSON.parse(fs.readFileSync(path.join(ROOT, 'template/ai-result-template.json'), 'utf8'));
  const ai = mapper.buildAIPresentationJSON(global.masterResult, template);
  const text = JSON.stringify(ai);

  const claims = ai.determination_chain.claims;
  assert.ok(Array.isArray(claims) && claims.length > 0, 'Determination chain must expose semantic claims');
  assert.ok(claims.every(c => c.supported_by_rules.length > 0), 'Every AI claim must list supporting rules');
  assert.ok(claims.every(c => c.verification_status), 'Every AI claim must carry verification status');
  assert.ok(claims.every(c => c.status_detail && c.status_detail.determination), 'Every AI claim must separate determination state');
  assert.ok(claims.every(c => c.status_detail && Object.prototype.hasOwnProperty.call(c.status_detail, 'computation')), 'Every AI claim must expose computation state separately');
  assert.ok(claims.every(c => c.status_detail && c.status_detail.verification), 'Every AI claim must expose verification state separately');
  assert.ok(claims.every(c => c.evidence_count === c.evidence_refs.length), 'Evidence count must equal resolved claim evidence references');
  assert.ok(ai.determination_chain.synthesis && ai.determination_chain.synthesis.state_buckets, 'Synthesis state buckets must exist');
  assert.ok(Array.isArray(ai.determination_chain.classical_rule_context), 'Classical rule context must remain available as a compact index');
  assert.ok(ai.determination_chain.classical_rule_context.every(r => !Object.prototype.hasOwnProperty.call(r, 'assessments')), 'Classical rule context must not duplicate claim evidence assessments');
  assert.ok(ai.determinations.useful_element && ai.determinations.useful_element.candidate_relations, 'Candidate Xi/Ji envelope must be preserved');
  assert.ok(ai.determinations.day_master_strength.status && typeof ai.determinations.day_master_strength.status === 'object', 'Determination status must be dimensional, not a raw computation label');
  assert.ok(!Object.values(ai.determinations).some(d => d && d.status === 'CALCULATED'), 'Raw CALCULATED must not masquerade as determination status');
  assert.ok(ai.determinations.useful_element.candidate_relations.candidates.every(c => c.status === 'CANDIDATE'), 'Candidate relations must remain CANDIDATE');
  assert.ok(ai.determinations.useful_element.status.yong_shen !== 'FINAL' || ai.determinations.useful_element.candidate_relations.status !== 'CANDIDATE', 'Candidate envelope must not upgrade Useful Element status');
  assert.ok(!/https?:\/\//i.test(text), 'URLs must not enter semantic AI output');
  assert.ok(!/\b(?:BC-[A-Z0-9_-]+|ZPZQ(?:-[A-Z0-9_-]+)?|QTBJ(?:-[A-Z0-9_-]+)?|DTT(?:-[A-Z0-9_-]+)?)\b/i.test(text), 'Internal source/rule identifiers leaked');
  assert.ok(!/\b(?:A\d{1,2}|B\d{1,2}|C\d)\b/.test(text), 'Internal section identifiers leaked');
  assert.strictEqual(mapper.validateMachineReadableJSON(ai).pass, true);


  console.log('PASS: claim authority, evidence/rule traceability, verification vocabulary, synthesis bucket, and semantic output hygiene.');
})();
