const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(__dirname, '..');
global.window = global;
function load(rel) { vm.runInThisContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), { filename: rel }); }
const lunar = require(path.join(ROOT, 'engine/lunar.js')); global.Solar = lunar.Solar; global.EightChar = lunar.EightChar;
[
  'bazi-data.js','engine/solar.js','engine/jieqi.js','engine/calendar.js',
  'data/sources/classical_sources_B_C.js','data/rules/classical_rules_B_C.js',
  'data/rules/classical_rule_evaluator.js','data/evidence/closure_signal_contract.js',
  'data/evidence/runtime_evidence_normalizer.js','core/coreA.js','core/coreB.js',
  'data/determination-rules.js','core/determination.js','core/coreC.js'
].forEach(load);
global.PenggilasLocation = { resolve: async () => ({
  location: { name: 'Jakarta', admin1: 'DKI Jakarta', country: 'Indonesia' }, coordinates: { latitude: -6.2088, longitude: 106.8456 },
  timeZone: { iana: 'Asia/Jakarta', utcOffset: 7 }, referenceMeridian: { degrees: 105 }, coordinateSource: { provider: 'runtime-fixture' }, dst: { isDst: false }
}) };
async function natal(date, time) {
  global.masterResult = null; global.PENGGILAS_RAW_CHART = null;
  await global.PenggilasCoreA.calculate({ birthDate: date, birthTime: time, birthPlace: { query: 'Jakarta' }, gender: 'male' });
  global.PenggilasCoreB.calculate();
  return global.masterResult;
}
(async () => {
  const N = global.PENGGILAS_CLASSICAL_RUNTIME_EVIDENCE_NORMALIZER;
  const heOnly = await natal('1850-01-01', '07:00');
  const huaBranch = N.normalize(heOnly, 'CS-B8-HUA');
  assert.ok(huaBranch.includes('HE_WITHOUT_HUA_CLOSURE') || huaBranch.includes('HUA_CONFIRMED'), 'B8 runtime state must be explicit');
  if (huaBranch.includes('HE_WITHOUT_HUA_CLOSURE')) assert.ok(!huaBranch.includes('HUA_CONFIRMED'), 'He-only must not be upgraded to Hua');

  const huaConfirmed = await natal('1850-09-01', '19:00');
  assert.ok(/confirmed under selected source profile/i.test(huaConfirmed.B8.status.result), 'A source-complete Hua fixture must remain confirmed at B8');

  const temporal = await natal('1880-11-01', '01:00');
  global.PenggilasDetermination.calculate();
  global.PenggilasCoreC.calculate('1920-06-01T12:00:00.000Z');
  const c4 = global.masterResult.C4;
  const cBranch = N.normalize(global.masterResult, 'CS-C-TEMPORAL');
  if (c4.evidence.temporalDisruptionEvidence) assert.deepStrictEqual(cBranch, [], 'Month-Command clash alone must remain open for Bian Ge');

  // Open method space is not the same state as multiple valid candidates.
  // The runtime fixture has open Disease-Medicine / Bridging / Following routes.
  assert.notStrictEqual(global.masterResult.B13_2.reconciliation.status, 'MULTI_METHOD', 'Open method space must not be mislabeled MULTI_METHOD');
  assert.strictEqual(global.masterResult._determinationContract.claims.USEFUL_ELEMENT.status, 'UNRESOLVED');
  console.log('PASS: B8 fail-closed guard, temporal disruption guard, and multi-method state distinction.');
})();
