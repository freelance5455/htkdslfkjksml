const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'engine', 'location.js'), 'utf8');
const context = { window: {}, console };
vm.createContext(context);
vm.runInContext(source, context);
const location = context.window.PenggilasLocation;

const selected = {
  name: 'Banyuwangi',
  admin1: 'East Java',
  country: 'Indonesia',
  latitude: -8.2192,
  longitude: 114.3691,
  timezone: 'Asia/Jakarta'
};

(async () => {
  const birthDateTime = vm.runInContext('new Date(1983, 5, 17, 12, 15, 0)', context);
  const result = await location.resolve(selected, null, birthDateTime);
  assert.strictEqual(result.status, 'RESOLVED');
  assert.strictEqual(result.location.name, 'Banyuwangi');
  assert.strictEqual(result.location.admin1, 'East Java');
  assert.strictEqual(result.location.country, 'Indonesia');
  assert.strictEqual(result.coordinates.latitude, selected.latitude);
  assert.strictEqual(result.coordinates.longitude, selected.longitude);
  assert.strictEqual(result.timeZone.iana, selected.timezone);
  assert.strictEqual(result.searchQuery, 'UI_SELECTED_CANDIDATE');
  console.log('Selected-location bridge test passed.');
})().catch(error => {
  console.error(error);
  process.exit(1);
});
