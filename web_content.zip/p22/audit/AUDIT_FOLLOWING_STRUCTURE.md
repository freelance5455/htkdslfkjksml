# Following Structure Audit — Runtime Closure Repair

## Status
🟡 NOT FINAL

## CLAIM
The Following-pattern runtime gate must distinguish the Day Master's own stem from additional Companion Stars (比劫), and Follow-the-Trend Pattern (从势) must be able to close when the Day Master is rootless, has no Resource/Companion rescue, and all three Wealth/Officer/Output sides are present.

## EVIDENCE
- V1.20 used `rawPresent(dmElem)` as a proxy for Companion presence.
- The Day Master is necessarily present as the Day Stem, so `rawPresent(dmElem)` is always true.
- Therefore the old Follow-the-Trend gate requiring `!rawPresent(dmElem)` was structurally unreachable.
- The same proxy could allow Follow-Dominant / Follow-Strength screens to treat the Day Master's own stem as additional Companion evidence.

## AUDIT
Patched `core/coreB.js` to derive `companionPresent` from additional same-element evidence only:
- additional visible Day-Master element beyond the Day Stem, or
- hidden Day-Master element.

Following screens now consume `companionPresent` rather than `rawPresent(dmElem)`.
`dmMeaningfulSupport` and `effectiveResourceCompanion` also use Resource OR additional Companion evidence.

## CROSS-CHECK
Dedicated real runtime chart fixture:
- Birth: `1981-09-13 12:17`
- Runtime subtype: `FOLLOW-THE-TREND / 从势`
- Day Master present as own stem: YES
- Additional Companion Stars: NO
- Root: NO
- Resource: NO
- Wealth/Officer/Output sides: 3/3
- `TRUE_FOLLOWING_CONDITIONS_SATISFIED`: observed
- `FOLLOWING_CLOSURE_COMPLETE`: observed
- Execution signature: `BOUND`, `CLOSED`, outcome `CONFIRMED`

Dedicated test: `tests/test_following_runtime_fixture.js` — 10/10 PASS.

## CHALLENGE
This does not establish that every Following subtype is source-complete. Follow-Dominant Pattern (从旺), Follow-Strength Pattern (从强), and unsupported `从财 / 从官(从杀)` still require their own source-valid runtime fixtures or explicit fail-closed evidence.

The 64-chart regression baseline remains unchanged at 64 charts / 0 failures. Its B13 Following family remains `BOUND=0` because the dedicated fixture is not part of that historical sample set.

## SYNTHESIS
The repair fixes an unreachable gate rather than weakening the closure contract. The distinction is now:
- Day Master's own stem ≠ additional Companion Stars.
- Rootlessness is audited separately.
- Resource/Companion rescue is audited separately.
- Follow-the-Trend requires all three Wealth/Officer/Output sides.

## CONFIDENCE
High for the identified wiring bug and the tested Follow-the-Trend runtime path.
Medium for the broader Following framework until dedicated runtime fixtures exist for the remaining supported subtypes.
