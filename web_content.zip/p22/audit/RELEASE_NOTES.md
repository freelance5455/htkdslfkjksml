# PENGGILAS V1.18 — Report Runtime Asset Integrity

## Scope
- Rebased on V1.17 to isolate the Report download path; no BaZi rule or determination logic changed.
- Versioned the runtime `json-mapper.js` and `report.js` script URLs so browser caches cannot silently retain older report assets.
- Versioned the AI template fetch URL and added a static `ai-result-template.js` fallback using the exact current JSON template.
- Kept the existing JSON fetch path as a fallback when the static template global is unavailable.
- Added a report download wiring regression that checks asset order, cache-bust version consistency, and JSON/fallback template identity.

## Validation
- Report download wiring: PASS
- AI template JSON/fallback equivalence: PASS
- JavaScript syntax: PASS
- Existing V1.17 regression suite: PASS

## Status
**NOT FINAL.** This release isolates and hardens the Report runtime asset path; semantic status/evidence hardening remains separate from the download-path fix.
# PENGGILAS V1.16 — Thin AI Interpreter Contract

## Scope
- Reduced AI-facing static instruction text to the minimum semantic contract required for interpretation.
- Preserved the authoritative `MasterResult` boundary and status semantics.
- Made the A → B → C semantic model explicit: A = WHAT IS THE CHART; B = WHAT DOES THE CHART MEAN STRUCTURALLY; C = WHAT HAPPENS WHEN TIME MOVES.
- Removed mapper/document-layout/implementation instructions from the AI Interpreter contract.
- No BaZi adjudication rule, candidate generator, determination layer, or temporal engine logic was changed.

## AI boundary
- AI explains supplied engine results; AI does not adjudicate them.
- Supplied candidates remain candidates; unresolved determinations remain unresolved.
- The Interpreter may synthesize supplied evidence but may not invent evidence, recalculate, promote status, or choose an unresolved winner.

## Validation
- AI Interpreter contract regression: PASS.
- Existing engine/rule tests preserved.
- No production engine imports from tests/audit.

## Status
**NOT FINAL.** External LLM/adversarial evaluation remains intentionally parked for later collection.


# PENGGILAS V1.15 — AI Payload Candidate & Context Compression

- Restored source-derived Xi/Ji candidate branches as explicit conditional `CANDIDATE` projections when Day-Master strength remains unresolved.
- Preserved the existing Climate Regulation candidate (for example Ren Water / 壬) without selecting a winner.
- Reduced `classical_rule_context` to a rule → source → claim index; detailed evidence remains in the claim/evidence chain.
- DQ end-to-end payload comparison: 326,788 bytes → 177,610 bytes (~45.7% reduction).
- Validation and regression suite remain PASS.
- No new adjudication rule and no status upgrade introduced.

# V1.13 — Claim Authority & Traceability

- Determination chain is the single adjudication authority for B/C claims.
- Section B/C state is reconciled explicitly with the determination chain; closure gates cannot strengthen open states.
- Claim evidence is now required to contain non-empty chart evidence before closure/high confidence.
- Supporting rule linkage is mandatory for claim closure/high confidence.
- Claim-level verification status is explicit and reconciled with overall verification.
- Synthesis preserves distinct determination states and exposes the final-state bucket when populated.
- Semantic AI output removes URLs, provenance identifiers, null/empty placeholders, and internal engine names from interpretation language.
- Added runtime regression for claim/evidence/rule/verification/synthesis traceability.

# PENGGILAS V1.12 — Penguatan 财格, Hua, dan Regresi Runtime

- Jalur Pattern Wealth (财格) pada normalisasi bukti runtime dipisahkan menurut tiga jalur pembentukan yang memang tercantum dalam aturan: Wealth menuju Officer, Wealth bersama Food/Output dengan Day Master kuat, dan Wealth membawa Resource dalam posisi yang tidak bertentangan.
- Syarat Day Master yang hanya berlaku pada jalur tertentu tidak lagi dipakai sebagai penolak global terhadap jalur pembentukan lain.
- Penutupan tetap fail-closed bila Seven Killings contamination, tekanan Companion yang belum terselesaikan, atau syarat jalur tertentu belum lengkap.
- Ditambahkan fixture Hua positif dari sumber yang sudah tertutup, sementara He-only tetap diuji tidak berubah menjadi Hua.
- Ditambahkan matriks stabilitas runtime 64 bagan yang tersimpan di test yang sudah ada: 16 tanggal kelahiran × 4 waktu, 64/64 berhasil menghasilkan A dan B tanpa kegagalan runtime. Matriks ini adalah regresi stabilitas yang dapat direproduksi dari paket, bukan rekonstruksi korpus historis yang tidak tersimpan di paket.
- Cheng Ge dan Bian Ge tetap fail-closed: tidak ada kondisi sumber yang boleh diciptakan hanya untuk menutup celah temporal.

# PENGGILAS V1.11 — B3 Closure, Temporal Guard & Package Boundary

## Scope
- Connected runtime B3 source-path evidence to six declared formation-family closure fixtures without introducing a new numeric formula.
- Corrected Day-Master capacity evidence to use existing root evidence when B1 strength remains unresolved.
- Distinguished unresolved/open Yong Shen method space from true multi-method candidate coexistence.
- Prevented temporal Month-Command clash from being promoted to a closed Bian Ge branch without resulting-structure/stability evidence.
- Added production-boundary documentation and production-package exclusion rules.

## Runtime validation
- B3 runtime source-path closure fixtures: 6/6 PASS.
- B8 fail-closed guard: PASS.
- Temporal disruption guard: PASS.
- Multi-method state distinction: PASS.

## Status
B3 coverage is materially expanded but Wealth Pattern (财格) still remains open where no source-clean runtime path was found in the inspected corpus. B8 full confirmation coverage and C source-complete Cheng/Bian closure remain conservative.

# PENGGILAS reborn V1.14 — Evidence Coverage Hardening

## Scope
- Strengthened runtime evidence auditing so EVIDENCE_OBSERVED_NO_CLOSURE is counted explicitly rather than hidden by the regression summary.
- Added conservative ordinary Ge Ju closure binding only when all matrix-declared primary evidence is present and no declared counter-evidence is observed. No numeric formula or school precedence is introduced.
- Added explicit Mixed Ge Ju unresolved branch: NO_SOURCE_RANKING → UNRESOLVED.
- Added real Climate Regulation runtime fixtures for blocked/open and complete/closed closure signatures.
- Added Following closure-to-matrix binding fixtures.
- Added ordinary Ge Ju closure fixtures for Officer, Wealth, Resource, Eating God, Hurting Officer, Seven Killings, Jian Lu/Month Rob, plus Mixed Ge Ju unresolved state.

## Validation
- B1–B17 / C1–C7 contract: 56/56 PASS
- MasterResult gate: 15/15 PASS
- Rule wiring: 15/15 PASS
- Semantic alignment: 11/11 PASS
- C6/C7 provenance: 5/5 PASS
- Evidence coverage fixtures: 5/5 PASS
- B3 Ge Ju closure fixtures: 8/8 PASS
- Engine regression: 64 charts / 0 failures
- ENGINE_RULE_GAP: 0

## Important status
This release is **not FINAL**. Remaining EVIDENCE_OBSERVED_NO_CLOSURE states are intentionally surfaced for further closure-coverage audit; they are not silently promoted to PASS and no unsupported Classical formula is invented to close them.


## V1.15 — Evidence Closure & Source Equivalence Audit
- Added test-only closure coverage for B3 Officer/Wealth/Resource/Eating God/Hurting Officer/Seven Killings, B8 Hua, and C temporal activation/disruption/open states.
- Added explicit classical source-equivalence claim map and canonical source URLs.
- No new calculation formula or silent school precedence introduced.
- Full test suite: PASS; 64-chart engine regression: 0 failures.


# PENGGILAS reborn V1.16 — Classical B3 Doctrinal Audit

## Scope
- Reworked B3 ordinary Ge Ju formation profiles to preserve source-stated alternative paths instead of conjunctive over-constraints.
- Corrected Wealth, Resource, Eating God, Hurting Officer, Seven Killings, and Jian Lu/Month Rob source-path handling; Officer remains source-aligned with Wealth/Resource support plus integrity checks.
- Added direct source-equivalence claims for major B3 formation families.
- Aligned the global classical state matrix vocabulary with the revised source-path evidence.

## Critical audit finding
- Synthetic closure fixtures pass, but production 64-chart regression still shows `EVIDENCE_OBSERVED_NO_CLOSURE` for some B3 families, especially Officer and Wealth.
- This is intentionally retained as OPEN evidence coverage, not converted into false closure.

## Validation
- B1–B17 / C1–C7 contract: 56/56 PASS
- MasterResult gate: 15/15 PASS
- B3 closure fixtures: 8/8 PASS
- Source equivalence: 29/29 PASS
- Evidence closure matrix: 19/19 PASS
- Engine regression: 64 charts / 0 failures
- ENGINE_RULE_GAP: 0

## Status
**NOT FINAL.**

# PENGGILAS reborn V1.17 — Following Doctrine Guard

## Scope
- Strengthened the source-locked Following / 从势 candidate screen.
- `从势/从弱` is no longer inferred from a single 财/官/食伤 side; the candidate screen now requires multiple active sides and explicit contrary-force audit.
- Added machine-readable `FOLLOWING_MULTI_SIDE_STRUCTURE` evidence.
- Synchronized `test_rule_wiring.js` with the current `BC-RULES-2.2` registry contract.

## Validation
- Following multi-side guard: 2/2 PASS
- B1–B17 / C1–C7 contract: 56/56 PASS
- MasterResult gate: 15/15 PASS
- B3 closure fixtures: 8/8 PASS
- C6/C7 provenance: 5/5 PASS
- Source equivalence: 29/29 PASS
- Evidence closure matrix: 19/19 PASS
- Evidence coverage fixtures: PASS
- Rule logic alignment: 11/11 PASS
- Rule wiring: 15/15 PASS
- Engine regression: 64 charts / 0 failures
- ENGINE_RULE_GAP: 0

## Status
**NOT FINAL.** B8 Hua, B13 Climate/Following, and C temporal remain conservatively open where source-complete runtime closure is not exposed.



## V1.20 — Input & Report UX Hardening

- Added Day / Month / Year and Hour / Minutes selectors with native date/time picker access.
- Added online birth-place candidate dropdown using Open-Meteo Geocoding; selected candidates become qualified location queries.
- Restored Report iframe routing whenever the Report screen is opened.
- Added Back to Report navigation from the standalone result template.
- No BaZi adjudication rules changed.


# PENGGILAS V1.21 — Input & Location UX Hardening

- Hardened native date/time picker inputs so the hidden device controls cannot render as large empty form fields.
- Added cache-busted input module HTML/CSS/JS assets.
- Kept Day / Month / Year and Hour / Minutes selectors as the visible controls; calendar/clock buttons still open the device picker.
- Added real calendar-date validation before submission.
- Changed location candidates to normal document flow so the iframe can measure their height without clipping.
- Added visible loading/error states, candidate deduplication, and up to 10 results.
- Calculation now requires an explicitly selected geocoding candidate, preventing a raw ambiguous place string from reaching the engine.
- Added an explicit parent resize bridge for the location candidate list.
- No BaZi A/B/C adjudication rules changed.
