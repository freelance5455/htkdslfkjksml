# Production Boundary

## Current package policy

The workspace ZIP may contain production, audit, and test material for reproducibility. The production payload is defined separately and excludes:

- `audit/`
- `tests/`
- contract/documentation files used only for audit and review

Runtime code must not import from `audit/` or `tests/`.

## Archive policy

Historical audit records remain preserved under `audit/`. They are evidence/history, not current executable rule authority.

## Test policy

Runtime fixtures and regression tests belong under `tests/`. They are not production dependencies.
