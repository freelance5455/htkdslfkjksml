# PENGGILAS V1.20 — INPUT, LOCATION PICKER, REPORT ROUTING

## Scope

V1.20 is a presentation/input hardening patch. It does not add or alter BaZi adjudication rules and does not change the A → B → Determination → C analytical contract.

## Changes

- Birth date uses Day / Month / Year selectors and retains a native device date picker.
- Birth time uses Hour / Minutes selectors and retains a native device time picker.
- Birth-place input offers online Open-Meteo geocoding candidates after a short debounce. Selecting a candidate writes a qualified city, administrative area, and country query.
- The shell restores `ui/report/report.html` whenever the Report screen is activated, so returning from the standalone result template cannot strand the Report iframe on `template/result-template.html`.
- The standalone result template includes an explicit Back to Report control.

## Verification boundary

The online location service is not live-verified by this package audit. Browser integration is verified structurally and through the local regression fixtures; live candidate quality remains dependent on the geocoding service response.


## V1.21 Follow-up — Input / Location Hardening

### Claim
The V1.20 input module needed presentation hardening: native date/time controls could leak visually, and location candidates could fail to appear or be clipped without a selected geocoding state.

### Evidence
- `ui/input/input.html` contains separate visible selectors plus native date/time picker controls.
- `ui/input/input.css` previously used a minimal hidden-input rule without cache-busting.
- `ui/input/input.js` previously allowed calculation with `birthPlace.query` even when no location candidate had been selected.
- The location suggestion list was absolutely positioned inside the iframe.

### Repair
V1.21 hardens the existing files only: cache-busted input assets, robust visually-hidden picker controls, in-flow location candidates, explicit selected-location gating, date validity, candidate deduplication, and iframe resize notification.

### Boundary
The online Open-Meteo service is not live-verified by this package audit. The patch verifies local UI/wiring contracts and fails closed when a candidate cannot be selected.

### Status
**NOT FINAL.**
