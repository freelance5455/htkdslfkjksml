# Following Contract Cleanup & Runtime Closure Audit

## Scope

Current production Following contract only. Historical audit documents remain unchanged and are archival evidence, not current executable authority.

## Contract

Supported executable Following subtypes:

- Follow-Dominant Pattern (从旺)
- Follow-Strength Pattern (从强)
- Follow-the-Trend Pattern (从势)

Unsupported and fail-closed:

- Follow-Weakness Pattern (从弱)
- Follow-Wealth (从财)
- Follow-Officer / Follow-Killing (从官/从杀)

Unsupported subtypes must never be normalized into Follow-the-Trend Pattern (从势).

## Patch

1. Removed the stale `从弱 / Follow-Weakness Pattern` statement from the current audit matrix in `bazi-data.js`.
2. Added the supported/unsupported Following boundary to `DRAFT_TEMPLATE_BAZI_CONTRACT.md`.
3. Follow-Strength no longer depends on the generic B1 `STRONG` label. Its own source-locked gate controls the subtype: Resource + additional Companion evidence, Month Command support, and no Wealth/Officer counter-force.
4. Following closure disqualifiers are now subtype-specific. Resource/Companion and Day-Master root/support are constitutive for Follow-Dominant / Follow-Strength and remain disqualifying only for Follow-the-Trend.

## Runtime Evidence

### Follow-Dominant Pattern (从旺)

Fixture: `1903-12-02 21:00`, Jakarta runtime location.

Observed:

- Runtime subtype: Follow-Dominant Pattern (从旺)
- Additional Companion evidence: present
- Resource evidence: present
- Wealth/Officer counter-force: absent
- `FOLLOWING_CLOSURE_COMPLETE`: observed

### Follow-Strength Pattern (从强)

Fixture: `1850-10-14 12:00`, Jakarta runtime location.

Observed:

- Runtime subtype: Follow-Strength Pattern (从强)
- Additional Companion evidence: present
- Resource evidence: present
- Month Command support: present
- Wealth/Officer counter-force: absent
- Output evidence may be present without converting the case to Follow-Dominant
- `FOLLOWING_CLOSURE_COMPLETE`: observed

### Follow-the-Trend Pattern (从势) regression

Fixture: `1981-09-13 12:17`, Jakarta runtime location.

Observed:

- Day-Master root: absent
- Resource/Companion rescue: absent
- Wealth/Officer/Output sides: 3/3
- Runtime subtype: Follow-the-Trend Pattern (从势)
- `FOLLOWING_CLOSURE_COMPLETE`: observed

### Unsupported Wealth-side case

Fixture: `1903-11-19 23:00`, Jakarta runtime location.

Observed:

- Wealth evidence: present
- Resource evidence: absent
- Officer evidence: absent
- Three-side Following condition: not satisfied
- Runtime does not promote the case to Follow-the-Trend Pattern (从势)
- No Following closure

### Unsupported Officer-side case

Fixture: `1945-09-13 17:00`, Jakarta runtime location.

Observed:

- Officer evidence: present
- Resource/Companion rescue: absent
- Wealth evidence: absent
- Three-side Following condition: not satisfied
- Runtime does not promote the case to Follow-the-Trend Pattern (从势)
- No Following closure

## Verification

Test: `tests/test_following_runtime_fixture.js`

Result: PASS.

## Confidence

High for the current registry boundary, the two dedicated runtime closures, and the tested fail-closed Wealth-side path.
