# PENGGILAS V1.15 — AI Payload Candidate & Context Audit

## Scope

This audit covers three bounded changes requested after V1.14 review:

1. Preserve concrete Xi/Ji candidate branches when the upstream strength determination remains open.
2. Compress `classical_rule_context` so it acts as a rule-to-claim index rather than a duplicate evidence store.
3. Keep all restored candidates explicitly `CANDIDATE` and conditional; the mapper does not adjudicate or select a winner.

The change does not alter Core A/B/C adjudication rules, the determination authority, or the final status of Yong/Xi/Ji.

## Candidate provenance

The mapper reads existing MasterResult candidate branches only.

For an unresolved Day-Master strength branch, the existing Support-Suppress relationships are projected as two conditional candidate branches:

- If strength closes as STRONG: Yong = Wealth element; Xi = Wealth element; Ji = Resource + Day Master elements.
- If strength closes as WEAK: Yong = Resource element; Xi = Day Master element; Ji = Output + Wealth + Officer elements.

These are labeled `CANDIDATE` with explicit conditions. They are not promoted to `FINAL`, and the main Useful Element status remains unchanged.

The existing source-specific Climate Regulation candidate is also preserved when present (for the DQ chart this is Ren Water / 壬 as a candidate Yong Shen under its own method).

## Payload compression

V1.14 stored full rule assessments inside `classical_rule_context` even though claim-level evidence was already present in `evidence_records`.

V1.15 changes this field to a compact index containing only:

- rule name
- classical sources
- semantic claims supported by the rule

Detailed evidence remains available through the claim/evidence chain and is not duplicated inside the rule context.

Observed DQ JSON size in the local end-to-end comparison:

- V1.14: 326,788 bytes
- V1.15: 177,610 bytes
- reduction: 149,178 bytes (~45.7%)

## Verification

- Claim traceability test: PASS
- B3 64-chart runtime stability: PASS
- B8/temporal multi-method guards: PASS
- Following runtime fixtures: PASS
- Matrix runtime wiring audit: PASS
- AI JSON validation: PASS
- No URL/internal rule identifiers in semantic output: PASS
- `classical_rule_context` contains no duplicated assessment arrays: PASS
- Candidate relations remain `CANDIDATE`: PASS

## Explicit non-goals

- No enum redesign.
- No internal-token cleanup beyond existing mapper validation.
- No LLM adversarial test.
- No new Classical adjudication rule.
- No automatic Xi/Ji winner selection.
