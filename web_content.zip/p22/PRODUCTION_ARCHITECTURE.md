# PENGGILAS — Production Architecture

## Authority
ONE authoritative `window.masterResult`.

## Production pipeline
INPUT → single calculation request → Core A → Rule Registry → Core B → Determination → Rule Registry → Core C → FINAL `window.masterResult`

The runtime must guarantee one active calculation pipeline per submitted input. Input navigation is a routing concern and must not create a second calculation request for the same submission. A calculation is serialized at the application bridge so asynchronous geocoding cannot produce overlapping or stale A→B→Determination→C pipelines.

Core C receives an explicit calculation `asOf` timestamp from the application bridge. This timestamp is the authoritative temporal reference for Da Yun/Liu Nian during that calculation; Core C does not silently choose a separate wall-clock instant.

After engine completion, presentation consumers read/project the result:
- Human HTML: `result-template.js` → `result-template.html`
- AI JSON: `ui/report/report.js` + `core/json-mapper.js` + `template/ai-result-template.json`
- Chart UI: `ui/chart/chart.js` (presentation projection + rendering; no BaZi authority)
  - `chart.js` receives authoritative `MasterResult`, creates a local chart view-model, and renders it.
  - It never writes derived chart fields back into `MasterResult`.

## Ownership
- Core A: A1–A17
- Rule Registry: authoritative declarative B/C rule contract consumed before Core B/C execution
- Core B: B1–B17 and authoritative A12.9 projection from B3
- Determination: B/C adjudication contract and authoritative A12.8 projection
- Core C: C1–C7
- Rule Evaluator: post-execution rule/evidence trace; not the sole rule connection
- `app.js`: orchestration/runtime bridge only
- Presentation adapters/templates: projection only; no independent BaZi adjudication

## Production hygiene
Production/runtime authority remains outside the audit layer. All audit evidence, release history, and audit-status notes belong under `audit/`; they are documentation/evidence only and are not runtime calculation dependencies. The architecture document does not treat audit notes as executable production logic.

## Important
No new BaZi formula, classical rule, determination rule, or closure rule is introduced by this architecture cleanup.


## Documentation map

Use the nearest README as the folder entry point; detailed contracts remain separate where they carry a distinct authority.

```text
ROOT
├── PRODUCTION_ARCHITECTURE.md          ← production-wide wiring/authority
├── DRAFT_TEMPLATE_BAZI_CONTRACT.md     ← A/B/C output-contract reference
├── core/README.md                      ← Core entry point
│   ├── MASTER_RESULT_ARCHITECTURE.md   ← detailed MasterResult ownership
│   └── AI_JSON_CONTRACT.md             ← detailed AI projection boundary
├── data/README.md                      ← data/support entry point
├── engine/README.md                    ← calculation-support entry point
├── audit/                               ← audit evidence/release history; non-runtime
└── template/README.md                  ← template/output entry point
    └── SEMANTIC_CONTRACT.md            ← detailed semantic presentation contract
```

README files are maps and operational summaries. Specialized contract documents remain authoritative for their named scope; they are not silently merged into README text.


## Production Boundary

The production runtime consists of the application entry point, UI, engine, Core A/B/C, determination, data/rule registries, assets, and result templates. `audit/` and `tests/` are non-production evidence/history and must not be runtime dependencies. The workspace archive may retain them for reproducibility; a production distribution excludes them.


## Claim Authority and Traceability

The determination chain is the single adjudication authority for B/C determinations. Section B/C results supply the source state; the determination closure gate may preserve or weaken that state, but must never strengthen an open state into FINAL.

Every determination claim must remain traceable through: **claim → evidence → supporting rule → audit → cross-check → verification → synthesis → overall answer**. A claim without non-empty evidence or an executed supporting rule is not eligible for FINAL or HIGH confidence.

Claim/evidence identifiers and source URLs are provenance metadata only. They are not BaZi terminology and must not enter terminology normalization or user-facing semantic language. Empty/null values and internal engine names are omitted from the semantic projection.
