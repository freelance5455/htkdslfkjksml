# DRAFT_TEMPLATE_BAZI_CONTRACT

## Executive Architecture Contract — PENGGILAS BaZi Engine

**Reference source:** `draft_template_bazi.docx`  
**Architecture:** **RULE REGISTRY → CORE B/C → ONE AUTHORITATIVE MASTER RESULT**  
**Scope:** analytical contract for A1–A17, B1–B17, C1–C7; rule/data wiring; determination boundary; MasterResult authority.

---

# 1. Executive Summary

The BaZi engine is organized as one progressive analytical pipeline:

```text
INPUT
  ↓
CORE A — FOUNDATION
  ↓
A1–A17
  ↓
ONE MASTER RESULT
  ↓
AUTHORITATIVE RULE REGISTRY
  ↓
CORE B — PROFILE / STRUCTURE / GE JU
  ↓
B1–B17
  ↓
SAME MASTER RESULT
  ↓
DETERMINATION / ADJUDICATION CONTRACT
  ↓
SAME MASTER RESULT
  ↓
AUTHORITATIVE RULE REGISTRY
  ↓
CORE C — TEMPORAL DYNAMICS
  ↓
C1–C7
  ↓
FINAL MASTER RESULT
  ├───────────────┐
  ↓               ↓
HUMAN REPORT    AI JSON
```

The governing principle is:

> **B and C do not run as independent BaZi engines. They explain and interpret the structure established by A.**

A establishes **what the chart is**.  
B establishes **what that chart means structurally**.  
C establishes **what happens when time moves against that established foundation and structure**.

Therefore:

- **A is the factual foundation.**
- **B is the structural interpretation of A.**
- **C is the temporal interpretation of A + B.**
- **The rule layer is authoritative input to B/C execution, not merely an after-the-fact audit report.**
- **MasterResult is the single analytical authority.**
- Human and AI outputs are projections of MasterResult, not second calculation engines.

This contract does not authorize a second or parallel BaZi calculation path.

---

# 2. Source Contract: What the Template Defines

The supplied `draft_template_bazi.docx` explicitly defines three analytical sections:

- **A. FOUNDATION MASTER** — A1–A17
- **B. PROFILE & STRUCTURE / GE JU** — B1–B17
- **C. TEMPORAL DYNAMICS** — C1–C7

The template is therefore treated as the **semantic output contract**. It defines what the engine must explain and preserve; it does not itself become executable calculation logic.

The production engine must respect the template's order and semantic separation.

---

# 3. The Fundamental A / B / C Meaning

## A — WHAT IS THE CHART

A answers:

> **What is present in this chart, and how was it established?**

A is the permanent natal foundation. It establishes the calculation facts from which B and C must reason.

A includes, among others:

- birth/client and calculation parameters;
- calendar and time foundation;
- solar correction and calculation time;
- Four Pillars;
- Hidden Stems;
- Day Master;
- Month Command;
- Five Elements foundation;
- Yin-Yang foundation;
- Ten Gods map;
- roots;
- Na Yin;
- Twelve Life Stages;
- Kong Wang;
- Shen Sha registry;
- natal stem and branch interactions;
- Hua / transformation foundation;
- Useful / Favorable / Unfavorable God foundation slot;
- Pattern Foundation / Candidate;
- Ming Gong / Tai Yuan;
- Da Yun foundation and sequence;
- chart integrity and verification notes.

A therefore establishes the **raw and derived facts** that B is allowed to interpret.

---

# 4. B — WHAT DOES THE CHART MEAN STRUCTURALLY

B does not recalculate the chart as a separate chart.

B reads the authoritative A foundation and asks:

> **Given these established chart facts, what structural configuration does the chart form?**

The B sequence is:

```text
A foundation
   ↓
B1  Day Master Strength
B2  Month Command
B3  Ge Ju / Pattern
B4  Ten Gods
B5  Root
B6  Heavenly Stem Relations
B7  Earthly Branch Relations
B8  Hua / Transformation
B9  Structural Configuration
B10 Five Elements — Structural Roles
B11 Qi Flow
B12 Five Elements — Structural Balance
B13 Yong Shen / Useful God
B14 Structural Dependency
B15 Structural Priority
B16 Structural Synthesis
B17 Classical Structural Verification
```

### B1–B17 are therefore interpretations of A evidence.

Examples:

- B1 reads A7 Month Command, A8 Five Elements, and A11 Root evidence.
- B2 reads A7 Month Command foundation.
- B3 reads A7, A12.9, A12.6 and related A evidence to establish Ge Ju.
- B6/B7 read A12.5/A12.6 natal interaction registries.
- B8 reads A12.7 transformation evidence.
- B10/B12 interpret the A8 elemental foundation structurally.
- B13 reconciles structural evidence into Yong Shen determination.
- B16 synthesizes the preceding structural findings.
- B17 verifies the structural result and preserves unresolved items.

B must not silently replace A facts with an alternative chart calculation.

---

# 5. C — WHAT HAPPENS WHEN TIME MOVES

C is not a third independent chart engine.

C asks:

> **When temporal input moves against the established natal foundation and structural configuration, how does that structure respond?**

The C sequence is:

```text
A foundation + established B structure
                 ↓
C1 Temporal Interaction
                 ↓
C2 Combination & Conflict
                 ↓
C3 Qi & Structural Response
          ↙             ↘
C4 Structural Change   C5 Temporal Balance
          \             /
           C6 Temporal Determination
                 ↓
C7 Evidence & Verification
```

C therefore depends on B, while remaining grounded in A.

Examples:

- C1 evaluates temporal stems/branches against the established chart.
- C2 evaluates temporal combination/conflict using natal interaction foundations from A.
- C3 evaluates Qi and structural response using the established structure.
- C4 evaluates whether the established structure is activated, formed, transformed, or shifted.
- C5 evaluates temporal balance shift rather than recalculating natal balance as a new chart.
- C6 determines the temporal state from C4/C5 and the authoritative structural baseline.
- C7 records evidence and verification for the temporal conclusion.

C must not silently overwrite the natal structural truth established by B.

---

# 6. Rule Registry → Core B/C → MasterResult

The current architecture is explicitly **Rule Registry → Core B/C → One Authoritative MasterResult**.

```text
                    DATA / RULES
                         │
             ┌───────────┴───────────┐
             │                       │
       B RULE REGISTRY         C RULE REGISTRY
             │                       │
             └───────────┬───────────┘
                         ↓
             AUTHORITATIVE RULE REGISTRY
                         │
              exposes the executable
              section contract (keys,
              aliases, preparation and
              required-rule checks)
                         │
             ┌───────────┴───────────┐
             ↓                       ↓
        CORE B                    CORE C
     reads A + B rules         reads A+B + C rules
             │                       │
             ↓                       ↓
          B1–B17                  C1–C7
             │                       │
             └───────────┬───────────┘
                         ↓
                 MASTER RESULT
```

The critical correction from the previous wiring model is:

> **The rule layer is consumed before B/C execution, not only after B/C execution as a trace.**

The evaluator/audit trace may still run after execution, but it is no longer the only connection between `data/rules/*` and Core B/C.

The authoritative rule registry performs the wiring contract:

1. expose the declarative rule registry;
2. resolve the authoritative rule definition for each B/C section;
3. preserve rule ID, source, condition, logic, evidence and variant information in the registry;
4. prepare the section execution contract for Core B or Core C;
5. fail closed if an authoritative section rule definition is missing;
6. allow Core B/C to execute their existing mechanical calculations under that rule contract;
7. preserve the rule-plan provenance inside the section's MasterResult.

No second translation layer owns rule meaning, aliases, or matrix projection.

---

# 7. Role of `data/*`

The production data layer already contains distinct responsibilities. They must not be collapsed.

```text
data/
├── determination-rules.js
├── global_classical_state_matrix.js
├── classical_rule_coverage.js
├── rules/
│   ├── classical_rules_B_C.js
│   └── classical_rule_evaluator.js
├── evidence/
│   ├── closure_signal_contract.js
│   ├── runtime_evidence_normalizer.js
│   └── execution_signature.js
└── sources/
    └── classical_sources_B_C.js
```

### `data/rules/classical_rules_B_C.js`

The declarative registry for B1–B17 and C1–C7 and their configured variants/screens.

It describes rule identity, source references, conditions, evidence expectations, logic statements and status policy.

It is **not** a second calculator.

### `data/rules/classical_rules_B_C.js`

The authoritative B/C rule registry **and execution-contract layer**.

It exposes the B1–B17 and C1–C7 definitions plus the section keys, explicit aliases, preparation gate and required-rule check consumed by Core B/C. It does not reimplement BaZi mechanics and does not project the multi-entry state matrix into one synthetic entry.

### `data/rules/classical_rule_evaluator.js`

The post-execution evidence/trace layer.

It records which configured rule was represented by the resulting B/C output and what evidence/status the Core reported.

It does not replace the authoritative rule registry; it remains downstream and audit-only.

### `global_classical_state_matrix.js`

A declarative state-space and branch-coverage matrix for defined classical adjudication families.

It is supporting state evidence, not an independent calculation engine.

### `determination-rules.js`

Explicit determination/adjudication contracts for claims such as Day-Master Strength, Chart Pattern, Transformation/Following, and Useful Element.

The determination layer reconciles existing evidence. It does not create a second Four Pillars engine.

### `evidence/*`

Evidence normalization, closure contracts and execution signatures. These preserve auditability and closure state.

### `sources/*`

Classical source registry and provenance.

---

# 8. MasterResult — ONE Authoritative Analytical Result

There is only one analytical authority:

```text
window.masterResult
```

It is progressively populated:

```text
Core A
  ↓
A1–A17
  ↓
masterResult
  ↓
Rule Registry → Core B
  ↓
B1–B17
  ↓
masterResult
  ↓
Determination / adjudication contract
  ↓
masterResult
  ↓
Rule Registry → Core C
  ↓
C1–C7
  ↓
FINAL masterResult
```

No layer is permitted to create an independent competing analytical result.

In particular:

- app/orchestration code must not adjudicate BaZi;
- Human Template must not calculate BaZi;
- AI mapper must not calculate BaZi;
- support/data files must not become a second BaZi engine;
- UI projections must not become analytical authority.

---

# 9. A → B → C Dependency Contract

## 9.1 A is upstream of B

B must not execute against an empty or partial chart foundation.

Required relationship:

```text
A1–A17
   ↓
B1–B17
```

B consumes A facts as its structural evidence base.

## 9.2 B is upstream of C

C must not execute as an independent natal interpretation.

Required relationship:

```text
A1–A17
   ↓
B1–B17
   ↓
C1–C7
```

C may read A directly where a temporal operation requires a natal fact, but its structural interpretation must use the established B baseline.

## 9.3 C does not rewrite A/B

Temporal analysis can report:

- activation;
- support;
- obstruction;
- balance shift;
- formation/change;
- temporal determination;

but it must not silently rewrite the permanent natal foundation or convert an unresolved B conclusion into a final natal conclusion.

---

# 10. Cross-Section Semantic Boundaries

## 10.1 Month Command

- **A7:** records the Month Command foundation.
- **B2:** interprets its structural priority and role.
- **C:** evaluates temporal interaction/activation involving the established Month Command.

## 10.2 Pattern / Ge Ju

- **A12.9:** Pattern Foundation / Candidate.
- **B3:** structural Ge Ju determination.
- **C4/C6:** temporal formation/change/response involving the established structure.

A candidate is not automatically a final structural determination.

## 10.3 Element Balance

- **A8:** elemental inventory, presence, seasonal state and foundation data.
- **B10:** structural role of each element.
- **B12:** structural balance.
- **C5:** temporal balance shift.

These are related but are not interchangeable.

## 10.4 Natal vs Temporal Interaction

- **A12.5/A12.6:** natal interaction registry.
- **B6/B7:** structural interpretation of natal relations.
- **C1/C2:** temporal interaction and conflict.

Temporal interaction must not be mislabeled as natal foundation.

## 10.5 Useful God

- **A12.8:** Useful/Favorable/Unfavorable God foundation slot.
- **B13:** structural Yong Shen determination boundary.
- **C4/C6:** temporal response to the established B determination.

If B13 remains unresolved, C must preserve that unresolved state rather than manufacture a definitive temporal Useful-God conclusion.

### Following subtype boundary

The current executable Following domain supports only:

- Follow-Dominant Pattern (从旺);
- Follow-Strength Pattern (从强);
- Follow-the-Trend Pattern (从势).

Follow-Weakness Pattern (从弱), Follow-Wealth (从财), and Follow-Officer / Follow-Killing (从官/从杀) are not executable subtypes. They must not be normalized into Follow-the-Trend Pattern (从势); unsupported subtype evidence remains unresolved / fail-closed.

---

# 11. Determination Boundary

The determination layer is an **adjudication layer**, not a second independent BaZi engine.

Its responsibility is to reconcile existing evidence and publish explicit claim status.

Current major claims include:

- Day-Master Strength;
- Chart Pattern / Ge Ju;
- Transformation / Following;
- Useful Element / Yong Shen.

The determination layer may publish authoritative claim projections into MasterResult where the contract assigns it ownership, but it may not calculate a competing chart.

### Authority examples

- **Core B owns structural B results and the B3-derived A12.9 projection.**
- **Determination owns the adjudicated A12.8 projection where its contract explicitly closes that claim.**
- **Core C consumes the established B/determination state for temporal analysis.**

---

# 12. Result / Evidence / Condition / Source / Status / Verification

The template deliberately separates semantic roles.

### Result / Finding

The conclusion or value reported by the section.

### Evidence

The mechanical, structural, or temporal evidence supporting that conclusion.

### Source / Basis

The source, rule, method, or derivation basis.

### Condition

A prerequisite, formation requirement, dependency, or blocker.

### Status

The state of the determination. It must not be upgraded merely to make presentation cleaner.

### Verification

A verification statement whose scope remains explicit.

Calculation status and verification status are not interchangeable.

---

# 13. Open-State Contract

The engine must preserve explicit analytical states such as:

- `FINAL`
- `PROVISIONAL`
- `CANDIDATE`
- `UNRESOLVED`
- `MULTI_METHOD`
- `CONFLICT`
- `REJECTED`
- `CLOSED`
- `OPEN`

An open state is not automatically an engine failure.

It may mean that the applicable rule, source tradition, evidence or precedence is insufficient to close the claim.

The presentation layers must preserve that state.

---

# 14. Rule Wiring Contract

For every B/C section:

```text
Rule Registry
    ↓
Section Rule Plan
    ↓
Core Section Calculation
    ↓
Section Result
    ↓
MasterResult
    ↓
Rule Evaluator / Evidence Trace
```

The minimum invariant is:

> **A B/C section cannot be considered correctly wired if its authoritative rule definition is absent from the rule registry execution contract.**

Therefore the rule registry fails closed on missing section rule definitions.

This is intentionally different from an unresolved **analytical result**. A rule may exist while its result remains unresolved. Those are two different states:

```text
RULE MISSING        → wiring failure
RULE PRESENT + OPEN → valid analytical open state
RULE PRESENT + FINAL → resolved analytical state
```

---

# 15. Core B Wiring Contract

Core B must:

1. require a complete A MasterResult foundation;
2. prepare the B rule plan through the Rule Registry;
3. require the configured rule contract before each B execution node;
4. execute B1–B17 against A evidence and prior B dependencies;
5. publish B results into the same MasterResult;
6. retain the interpreted B rule plan in the B result for provenance;
7. run the Rule Evaluator as an audit/trace layer after the B result exists;
8. never create a second chart authority.

The existing B node graph remains dependency-driven. The rule registry is the upstream contract, not a replacement for the node graph.

---

# 16. Core C Wiring Contract

Core C must:

1. require the established A + B MasterResult state;
2. prepare the C rule plan through the Rule Registry;
3. require the configured rule contract before each C execution node;
4. use temporal input against the established natal/structural baseline;
5. execute C1–C7;
6. publish C results into the same MasterResult;
7. retain the interpreted C rule plan for provenance;
8. run the Rule Evaluator as post-execution trace;
9. never recalculate a competing natal chart.

---

# 17. Production Orchestration Contract

`app.js` is orchestration only.

The intended sequence is:

```text
receiveInputData
      ↓
Core A
      ↓
Core B
      ↓
Determination
      ↓
Core C
      ↓
BAZI_MASTER_RESULT_READY
```

`app.js` must not:

- calculate B1–B17;
- calculate C1–C7;
- adjudicate Ge Ju;
- adjudicate Yong Shen;
- patch A12.8/A12.9 from unrelated fields;
- create a second MasterResult.

Its job is to call the authoritative analytical layers in the correct order and publish the final MasterResult event.

---

# 18. Human / AI Output Boundary

Both production outputs consume the same final MasterResult:

```text
FINAL MASTER RESULT
      ├───────────────┐
      ↓               ↓
Human Template     AI Mapper
      ↓               ↓
HTML Report        AI JSON
```

Neither output is allowed to become an independent calculation authority.

They must not:

- invent missing values;
- convert candidate into final;
- replace a source/rule decision;
- calculate another BaZi answer;
- collapse distinct A/B/C semantic roles.

---

# 19. What This Contract Explicitly Forbids

The following architectures are **not** permitted under this architecture:

### Forbidden A — independent B engine

```text
Input → Core B
```

B must explain A.

### Forbidden B — independent C natal engine

```text
Input → Core C
```

C must explain temporal response of A+B.

### Forbidden C — rule layer as decorative metadata only

```text
Core B/C calculation
        ↓
Rule Evaluator only
```

This was the previous weak wiring pattern. The rule registry must now participate before B/C execution.

### Forbidden D — support-layer duplicate calculator

```text
Core B formula
        +
Data rule formula
        ↓
Two competing answers
```

The data rule layer describes and constrains the analytical contract; it does not become a competing BaZi calculator.

### Forbidden E — presentation authority

```text
MasterResult
   ↓
UI/AI decides a different answer
```

Presentation is downstream only.

---

# 20. Verification Contract

A release must separately verify:

### Architecture

- [ ] A is upstream of B.
- [ ] B is upstream of C.
- [ ] C does not replace natal A/B conclusions.
- [ ] One MasterResult remains authoritative.

### Rule wiring

- [ ] B rule registry is loaded before Core B.
- [ ] Rule Registry is loaded before Core B/C.
- [ ] Core B prepares the B rule plan before B execution.
- [ ] Core C prepares the C rule plan before C execution.
- [ ] B1–B17 have authoritative rule contracts or explicit aliases.
- [ ] C1–C7 have authoritative rule contracts or explicit aliases.
- [ ] Missing rule definitions fail closed.
- [ ] Rule Evaluator remains an audit/trace layer rather than the only rule connection.

### Analytical semantics

- [ ] A1–A17 remain the foundation contract.
- [ ] B1–B17 remain structural interpretation.
- [ ] C1–C7 remain temporal dynamics.
- [ ] Candidate, provisional, unresolved and final states remain explicit.
- [ ] Natal and temporal interactions remain distinct.
- [ ] Structural balance and temporal balance remain distinct.

### Output authority

- [ ] Human output consumes MasterResult.
- [ ] AI output consumes MasterResult.
- [ ] Neither presentation path calculates BaZi.
- [ ] `app.js` remains orchestration-only.

---

# 21. Current Verified Wiring Result

The Rule-registry repair establishes the following production relationship:

```text
A FOUNDATION
    ↓
MASTER RESULT
    ↓
AUTHORITATIVE B/C RULE REGISTRY
    ↓
CORE B — B1..B17
    ↓
MASTER RESULT
    ↓
DETERMINATION CONTRACT
    ↓
MASTER RESULT
    ↓
AUTHORITATIVE B/C RULE REGISTRY
    ↓
CORE C — C1..C7
    ↓
FINAL MASTER RESULT
```

The rule registry is intentionally **contractual rather than formula-duplicating**. The existing Core B/C mechanical functions remain the calculation implementations; the registry execution contract establishes that they execute only under the configured declarative B/C rule space.

Runtime regression on the repaired engine path remains free of calculation failures across the existing 64-chart regression set, with 29 classical evidence families observed and no `ENGINE_RULE_GAP` in that run.

The wiring audit additionally verifies:

- authoritative B/C rule registry loaded before Core B;
- B rule plan prepared before B execution;
- B1 and B17 explicitly consumed through the registry contract;
- C rule plan prepared before C execution;
- C1 and C7 explicitly consumed through the registry contract;
- rule plans retained in section output;
- post-execution evaluator retained as audit trace;
- `app.js` remains free of A12.8/A12.9 analytical patching.

---

# 22. Final Executive Principle

The entire architecture can be reduced to one sentence:

> **A establishes the chart, the rules explain how B and C are allowed to interpret that chart, B explains the natal structure, C explains how that structure responds to time, and everything remains inside one authoritative MasterResult.**

That is the governing contract for future CORE / ENGINE / WIRING work.
