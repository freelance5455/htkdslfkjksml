/*
 * PENGGILAS — AI JSON MAPPER (REBORN)
 *
 * Contract:
 *   MASTER RESULT (read-only)
 *        -> template-shaped semantic JSON
 *
 * The HTML report and the JSON template share one binding idea:
 * every displayed value is owned by a masterResult path. This mapper uses
 * those same bindings as a projection whitelist. It never calculates,
 * adjudicates, selects a winner, or mutates masterResult.
 *
 * Output deliberately does NOT expose A1/B13_1/T01/etc. as AI vocabulary.
 * Those identifiers exist only inside this mapper's binding table.
 */
(function (root) {
  'use strict';

  const STATUS_CONTRACT = {
    purpose: 'Defines how AI must interpret determination, computation, and verification states supplied by the engine.',
    rule: 'Status describes the state supplied by the engine. AI must preserve that state and must not upgrade, downgrade, resolve, or replace it.',
    dimensions: {
      determination_state: {
        purpose: 'Describes whether an analytical determination is established, provisional, candidate, unresolved, multi-method, or in conflict.',
        statuses: ['FINAL', 'PROVISIONAL', 'CANDIDATE', 'UNRESOLVED', 'MULTI_METHOD', 'CONFLICT']
      },
      computation_state: {
        purpose: 'Describes whether a value is an engine calculation. CALCULATED does not by itself mean Classical verification.',
        statuses: ['CALCULATED']
      },
      verification_state: {
        purpose: 'Describes explicit verification supplied by the source record. Verification must not be interpreted as independent Classical verification unless that scope is explicitly supplied.',
        statuses: ['INTERNALLY_CROSS_CHECKED', 'EXTERNALLY_VERIFIED', 'NOT_VERIFIED', 'EXTERNAL_INDEPENDENT_VERIFICATION_NOT_ESTABLISHED']
      }
    },
    statuses: {
      FINAL: { meaning: 'The result is established by the authoritative engine/source for this field.', ai_handling: 'Explain the result as established, while remaining within the supplied evidence and scope.' },
      PROVISIONAL: { meaning: 'The result is provisional and not fully closed.', ai_handling: 'Present it as provisional; do not state it as certain.' },
      CANDIDATE: { meaning: 'The result is a candidate and has not been selected as the final determination.', ai_handling: 'Present it only as a candidate; never select it as the winner.' },
      UNRESOLVED: { meaning: 'The determination remains open or has not been resolved.', ai_handling: 'Preserve it as unresolved; do not infer a missing conclusion.' },
      MULTI_METHOD: { meaning: 'More than one method or methodological outcome remains relevant and has not been collapsed into one result.', ai_handling: 'Preserve the multiple methods/outcomes; do not collapse them into one.' },
      CONFLICT: { meaning: 'Supplied determinations or evidence contain an unresolved conflict.', ai_handling: 'State the conflict and preserve the alternatives; do not choose a winner.' },
      INTERNALLY_CROSS_CHECKED: { meaning: 'The claim is cross-checked against the configured source profile inside the calculation chain; this is not independent external verification.', ai_handling: 'Describe the cross-check only within that scope.' },
      EXTERNALLY_VERIFIED: { meaning: 'The supplied record explicitly indicates independent external verification for the claim.', ai_handling: 'Describe it as externally verified only within the supplied scope.' },
      NOT_VERIFIED: { meaning: 'No claim-level verification is established.', ai_handling: 'Do not describe the claim as verified.' },
      EXTERNAL_INDEPENDENT_VERIFICATION_NOT_ESTABLISHED: { meaning: 'Independent external verification has not been established.', ai_handling: 'Preserve the limitation explicitly.' },
      CALCULATED: { meaning: 'The value is a calculation produced by the engine.', ai_handling: 'Treat it as an engine calculation; do not describe it as independent Classical verification unless a separate supplied verification record says so.' }
    },
    priority_rule: [
      'Preserve the supplied status exactly.',
      'Do not infer a stronger status from the presence of a value.',
      'Keep determination state, computation state, and verification state conceptually separate.',
      'Do not treat CALCULATED as independent Classical verification.',
      'Do not turn CANDIDATE, PROVISIONAL, UNRESOLVED, MULTI_METHOD, or CONFLICT into FINAL.',
      'Do not select a winner when multiple methods or candidates remain.'
    ],
    null_rule: 'Null or omitted values mean that the source did not supply a value in that field. Null does not automatically mean unresolved, not applicable, false, or verified.'
  };

  const AI_INSTRUCTION = {
    role: 'Interpret the supplied PENGGILAS result for the user.',
    language: 'Use clear, natural, empathetic language that is easy for the user to understand.',
    presentation: 'Explain the result in practical human terms using standard BaZi terminology. Do not expose internal engine identifiers, audit identifiers, evidence IDs, source-record IDs, binding labels, or internal check labels.',
    data_model: {
      principle: 'The payload follows one ordered analytical flow: Foundation → Structure → Temporal Dynamics.',
      foundation: 'Foundation establishes what is present in the natal chart: identity, calculation basis, calendar/time foundation, Four Pillars, Day Master, Month Command, elemental and Yin-Yang foundations, Ten Gods, classical references, and Luck Pillars.',
      structure: 'Structure interprets what configuration or pattern is formed from the established foundation, including Day Master strength, Ge Ju, roots, stem/branch relations, Hua, structural configuration, Qi flow, elemental balance, Useful God, dependencies, priorities, synthesis, and Classical structural verification.',
      temporal: 'Temporal Dynamics describes how the established structure responds, changes, or is activated through time. Temporal findings do not automatically replace or rewrite the natal structural findings.',
      relationship: 'A builds foundational facts → B builds structural interpretation from those facts → C applies temporal dynamics to that established structure.',
      scope_rule: 'Treat section placement as analytical context. A structural determination and a temporal determination may both exist without being competing claims, provided their scopes differ.'
    },
    interpretation_boundary: 'Do not override the supplied data, evidence, contract, qualifications, conditions, conflicts, or verification limits.',
    no_recalculation: 'Interpret supplied calculations and determinations as given. Do not recalculate BaZi, Four Pillars, Day Master strength, element balance, Chart Pattern, Transformation/Following Pattern, or Useful Element to replace the supplied result.',
    interpretation_vs_adjudication: 'Interpret and explain supplied results; do not adjudicate, choose winners, reconcile conflicts, invent precedence, or close open determinations.',
    uncertainty: 'Do not convert unresolved, provisional, conflicting, blocked, or condition-dependent results into certainty.',
    evidence: 'Use only information supplied in this result. Evidence should be treated as chart, interaction, calculation, or temporal evidence actually supplied by the calculation record. Do not treat processing notes, calculated indicators, rule-coverage notes, or mapper explanations as independent Classical evidence.',
    source_and_basis: 'Source / Basis identifies where a supplied finding comes from. Do not treat a source label, registry reference, or processing note as stronger evidence than the supplied record warrants.',
    claim_binding: 'Keep each claim tied to its supplied evidence, source, qualification, condition, scope, and status. Do not merge evidence from separate claims as if it belonged to one.',
    missing_data: 'Missing, null, empty, or omitted fields are not permission to infer, calculate, assume, or complete evidence, conditions, qualifications, relationships, or conclusions.',
    null_semantics: 'A null value means the source did not supply a value for that field. Do not automatically translate null into unresolved, not applicable, false, or verified.',
    conflict: 'When multiple candidates or interpretations remain, explain the situation without arbitrarily selecting one.',
    verification: 'Do not describe internally calculated, screened, or cross-checked information as independently verified unless the result explicitly states that verification scope.',
    status_translation: 'Use natural user-facing explanations for technical states. Keep determination state, computation state, and verification state distinct. System and provenance identifiers are interpretation controls only and must not be presented as BaZi concepts or user-facing terminology.',
    project_metrics: 'Do not present calculated indicators as definitive Classical determinations. If an indicator is relevant, label it as a calculated indicator and preserve the Classical qualification supplied with it.',
    practical_guidance: 'When supported, give practical guidance as interpretation only. Do not turn model-generated guidance into a determination or use it to fill an open condition.',
    llm_input_boundary: 'The model receives this JSON and this instruction only. The payload is a cleaned semantic handoff: system and provenance identifiers are not part of the interpretation language.',
    semantic_state_preservation: 'Preserve the distinction between UNRESOLVED, MULTI_METHOD, CONFLICT, PROVISIONAL, and CANDIDATE. Do not collapse them into a generic uncertainty label when the distinction affects the answer.',
    open_determination: 'If a determination is open, explain what remains open and why from supplied evidence/conditions; do not close it by model reasoning alone.',
    determination_chain: 'When determination_chain is present, use it as the evidence-to-confidence trace. Explain the supplied chain without exposing internal IDs or paths.'
  };

  // Generated from result-template.html data-field bindings.
  // Each item is: [sectionCode, subsectionCode, headers, rows]
  // rows: { labels: [...], fields: [...], templateValues: [...] }
  const BINDINGS = [{"section":"A","subsection":"A1","headers":["Category","Description"],"rows":[{"labels":["Analysis Version","-"],"fields":[null,"A1.analysisVersion"],"templateValues":["Analysis Version",null]},{"labels":["Chart ID","-"],"fields":[null,"A1.chartId"],"templateValues":["Chart ID",null]},{"labels":["Subject ID (Client)","-"],"fields":[null,"A1.subjectId"],"templateValues":["Subject ID (Client)",null]},{"labels":["Methodology","-"],"fields":[null,"A1.methodology"],"templateValues":["Methodology",null]},{"labels":["Foundation Data Source","-"],"fields":[null,"A1.dataSource"],"templateValues":["Foundation Data Source",null]},{"labels":["Calculation System / School","-"],"fields":[null,"A1.calcSystem"],"templateValues":["Calculation System / School",null]},{"labels":["Verification Method","-"],"fields":[null,"A1.verifyMethod"],"templateValues":["Verification Method",null]},{"labels":["Verification Date","-"],"fields":[null,"A1.verifyDate"],"templateValues":["Verification Date",null]},{"labels":["Compilation Status","-"],"fields":[null,"A1.compilationStatus"],"templateValues":["Compilation Status",null]},{"labels":["Data Validity Status","-"],"fields":[null,"A1.validityStatus"],"templateValues":["Data Validity Status",null]},{"labels":["Chart Completeness Status","-"],"fields":[null,"A1.completenessStatus"],"templateValues":["Chart Completeness Status",null]}]},{"section":"A","subsection":"A2","headers":["Category","Description"],"rows":[{"labels":["Name / Initial","-"],"fields":[null,"A2.name"],"templateValues":["Name / Initial",null]},{"labels":["Biological Sex","-"],"fields":[null,"A2.sex"],"templateValues":["Biological Sex",null]},{"labels":["Gender Rule Code","-"],"fields":[null,"A2.genderCode"],"templateValues":["Gender Rule Code",null]},{"labels":["Yin / Yang Classification (Yin Yang / 阴阳)","-"],"fields":[null,"A2.yinYang"],"templateValues":["Yin / Yang Classification (Yin Yang / 阴阳)",null]},{"labels":["Civil Date of Birth","-"],"fields":[null,"A2.civilDate"],"templateValues":["Civil Date of Birth",null]},{"labels":["Civil Time of Birth","-"],"fields":[null,"A2.civilTime"],"templateValues":["Civil Time of Birth",null]},{"labels":["Actual Date & Time of Birth","-"],"fields":[null,"A2.actualDateTime"],"templateValues":["Actual Date & Time of Birth",null]},{"labels":["Birth Location","-"],"fields":[null,"A2.location"],"templateValues":["Birth Location",null]},{"labels":["Latitude","-"],"fields":[null,"A2.latitude"],"templateValues":["Latitude",null]},{"labels":["Longitude","-"],"fields":[null,"A2.longitude"],"templateValues":["Longitude",null]},{"labels":["Time Zone","-"],"fields":[null,"A2.timeZone"],"templateValues":["Time Zone",null]},{"labels":["Reference Meridian","-"],"fields":[null,"A2.meridian"],"templateValues":["Reference Meridian",null]},{"labels":["Location / Coordinate Source","-"],"fields":[null,"A2.coordSource"],"templateValues":["Location / Coordinate Source",null]},{"labels":["DST Status","-"],"fields":[null,"A2.dstStatus"],"templateValues":["DST Status",null]},{"labels":["Calendar Convention","-"],"fields":[null,"A2.calendarConv"],"templateValues":["Calendar Convention",null]}]},{"section":"A","subsection":"A3","headers":["Category","Description"],"rows":[{"labels":["Civil Date & Time","-"],"fields":[null,"A3.civilDateTime"],"templateValues":["Civil Date & Time",null]},{"labels":["Local Date & Time","-"],"fields":[null,"A3.localDateTime"],"templateValues":["Local Date & Time",null]},{"labels":["Longitude","-"],"fields":[null,"A3.longitude"],"templateValues":["Longitude",null]},{"labels":["Meridian Correction","-"],"fields":[null,"A3.meridianCorr"],"templateValues":["Meridian Correction",null]},{"labels":["Local Mean Solar Time (LMST/LMT)","-"],"fields":[null,"A3.lmst"],"templateValues":["Local Mean Solar Time (LMST/LMT)",null]},{"labels":["Equation of Time (EoT)","-"],"fields":[null,"A3.eot"],"templateValues":["Equation of Time (EoT)",null]},{"labels":["True Solar Time","-"],"fields":[null,"A3.trueSolarTime"],"templateValues":["True Solar Time",null]},{"labels":["Time Used for BaZi Calculation","-"],"fields":[null,"A3.baziTime"],"templateValues":["Time Used for BaZi Calculation",null]},{"labels":["Date Boundary Status","-"],"fields":[null,"A3.dateBoundary"],"templateValues":["Date Boundary Status",null]},{"labels":["Calendar System","-"],"fields":[null,"A3.calendarSystem"],"templateValues":["Calendar System",null]},{"labels":["Solar Calendar Date","-"],"fields":[null,"A3.solarDate"],"templateValues":["Solar Calendar Date",null]},{"labels":["Lunar Calendar Date","-"],"fields":[null,"A3.lunarDate"],"templateValues":["Lunar Calendar Date",null]},{"labels":["Previous Solar Term (Jie Qi / 节气)","-"],"fields":[null,"A3.prevJieQi"],"templateValues":["Previous Solar Term (Jie Qi / 节气)",null]},{"labels":["Date & Time of Previous Jie Qi","-"],"fields":[null,"A3.prevJieQiTime"],"templateValues":["Date & Time of Previous Jie Qi",null]},{"labels":["Current Solar Term (Zhong Qi / 中气)","-"],"fields":[null,"A3.currZhongQi"],"templateValues":["Current Solar Term (Zhong Qi / 中气)",null]},{"labels":["Date & Time of Current Jie Qi","-"],"fields":[null,"A3.currZhongQiTime"],"templateValues":["Date & Time of Current Jie Qi",null]},{"labels":["Next Solar Term (Jie Qi / 节气)","-"],"fields":[null,"A3.nextJieQi"],"templateValues":["Next Solar Term (Jie Qi / 节气)",null]},{"labels":["Date & Time of Next Jie Qi","-"],"fields":[null,"A3.nextJieQiTime"],"templateValues":["Date & Time of Next Jie Qi",null]},{"labels":["Solar Month","-"],"fields":[null,"A3.solarMonth"],"templateValues":["Solar Month",null]},{"labels":["Solar Month Boundary","-"],"fields":[null,"A3.solarMonthBoundary"],"templateValues":["Solar Month Boundary",null]},{"labels":["Calendar Conversion Status","-"],"fields":[null,"A3.calConvStatus"],"templateValues":["Calendar Conversion Status",null]}]},{"section":"A","subsection":"A4","headers":["Pillar","Gan-Zhi","Heavenly Stem (Tian Gan / 天干)","Stem Element","Stem Polarity","Earthly Branch (Di Zhi / 地支)","Branch Element","Branch Polarity"],"rows":[{"labels":["Year (Nian / 年)","-","-","-","-","-","-","-"],"fields":[null,"A4.year.ganZhi","A4.year.stem","A4.year.stemElem","A4.year.stemPol","A4.year.branch","A4.year.branchElem","A4.year.branchPol"],"templateValues":["Year (Nian / 年)",null,null,null,null,null,null,null]},{"labels":["Month (Yue / 月)","-","-","-","-","-","-","-"],"fields":[null,"A4.month.ganZhi","A4.month.stem","A4.month.stemElem","A4.month.stemPol","A4.month.branch","A4.month.branchElem","A4.month.branchPol"],"templateValues":["Month (Yue / 月)",null,null,null,null,null,null,null]},{"labels":["Day (Ri / 日)","-","-","-","-","-","-","-"],"fields":[null,"A4.day.ganZhi","A4.day.stem","A4.day.stemElem","A4.day.stemPol","A4.day.branch","A4.day.branchElem","A4.day.branchPol"],"templateValues":["Day (Ri / 日)",null,null,null,null,null,null,null]},{"labels":["Hour (Shi / 时)","-","-","-","-","-","-","-"],"fields":[null,"A4.hour.ganZhi","A4.hour.stem","A4.hour.stemElem","A4.hour.stemPol","A4.hour.branch","A4.hour.branchElem","A4.hour.branchPol"],"templateValues":["Hour (Shi / 时)",null,null,null,null,null,null,null]}]},{"section":"A","subsection":"A5","headers":["Pillar","Earthly Branch (Di Zhi / 地支)","Hidden Stem (Cang Gan / 藏干)","Qi Position","Element","Polarity","Ten Gods (Shi Shen / 十神)"],"rows":[{"labels":["Year","-","-","Main (Ben Qi / 本气)","-","-","-"],"fields":[null,"A5.year.branch","A5.year.mainStem",null,"A5.year.mainElem","A5.year.mainPol","A5.year.mainGod"],"templateValues":["Year",null,null,"Main (Ben Qi / 本气)",null,null,null]},{"labels":["Year","-","-","Middle (Zhong Qi / 中气)","-","-","-"],"fields":[null,"A5.year.branch","A5.year.midStem",null,"A5.year.midElem","A5.year.midPol","A5.year.midGod"],"templateValues":["Year",null,null,"Middle (Zhong Qi / 中气)",null,null,null]},{"labels":["Year","-","-","Residual (Yu Qi / 余气)","-","-","-"],"fields":[null,"A5.year.branch","A5.year.resStem",null,"A5.year.resElem","A5.year.resPol","A5.year.resGod"],"templateValues":["Year",null,null,"Residual (Yu Qi / 余气)",null,null,null]},{"labels":["Month","-","-","Main (Ben Qi / 本气)","-","-","-"],"fields":[null,"A5.month.branch","A5.month.mainStem",null,"A5.month.mainElem","A5.month.mainPol","A5.month.mainGod"],"templateValues":["Month",null,null,"Main (Ben Qi / 本气)",null,null,null]},{"labels":["Month","-","-","Middle (Zhong Qi / 中气)","-","-","-"],"fields":[null,"A5.month.branch","A5.month.midStem",null,"A5.month.midElem","A5.month.midPol","A5.month.midGod"],"templateValues":["Month",null,null,"Middle (Zhong Qi / 中气)",null,null,null]},{"labels":["Month","-","-","Residual (Yu Qi / 余气)","-","-","-"],"fields":[null,"A5.month.branch","A5.month.resStem",null,"A5.month.resElem","A5.month.resPol","A5.month.resGod"],"templateValues":["Month",null,null,"Residual (Yu Qi / 余气)",null,null,null]},{"labels":["Day","-","-","Main (Ben Qi / 本气)","-","-","-"],"fields":[null,"A5.day.branch","A5.day.mainStem",null,"A5.day.mainElem","A5.day.mainPol","A5.day.mainGod"],"templateValues":["Day",null,null,"Main (Ben Qi / 本气)",null,null,null]},{"labels":["Day","-","-","Middle (Zhong Qi / 中气)","-","-","-"],"fields":[null,"A5.day.branch","A5.day.midStem",null,"A5.day.midElem","A5.day.midPol","A5.day.midGod"],"templateValues":["Day",null,null,"Middle (Zhong Qi / 中气)",null,null,null]},{"labels":["Day","-","-","Residual (Yu Qi / 余气)","-","-","-"],"fields":[null,"A5.day.branch","A5.day.resStem",null,"A5.day.resElem","A5.day.resPol","A5.day.resGod"],"templateValues":["Day",null,null,"Residual (Yu Qi / 余气)",null,null,null]},{"labels":["Hour","-","-","Main (Ben Qi / 本气)","-","-","-"],"fields":[null,"A5.hour.branch","A5.hour.mainStem",null,"A5.hour.mainElem","A5.hour.mainPol","A5.hour.mainGod"],"templateValues":["Hour",null,null,"Main (Ben Qi / 本气)",null,null,null]},{"labels":["Hour","-","-","Middle (Zhong Qi / 中气)","-","-","-"],"fields":[null,"A5.hour.branch","A5.hour.midStem",null,"A5.hour.midElem","A5.hour.midPol","A5.hour.midGod"],"templateValues":["Hour",null,null,"Middle (Zhong Qi / 中气)",null,null,null]},{"labels":["Hour","-","-","Residual (Yu Qi / 余气)","-","-","-"],"fields":[null,"A5.hour.branch","A5.hour.resStem",null,"A5.hour.resElem","A5.hour.resPol","A5.hour.resGod"],"templateValues":["Hour",null,null,"Residual (Yu Qi / 余气)",null,null,null]}]},{"section":"A","subsection":"A6","headers":["Category","Description"],"rows":[{"labels":["Day Stem (Day Master)","-"],"fields":[null,"A6.dayStem"],"templateValues":["Day Stem (Day Master)",null]},{"labels":["Element","-"],"fields":[null,"A6.element"],"templateValues":["Element",null]},{"labels":["Polarity","-"],"fields":[null,"A6.polarity"],"templateValues":["Polarity",null]},{"labels":["Mandarin Name (Hanzi / Pinyin)","-"],"fields":[null,"A6.mandarinName"],"templateValues":["Mandarin Name (Hanzi / Pinyin)",null]},{"labels":["Day Pillar (Gan-Zhi)","-"],"fields":[null,"A6.dayPillar"],"templateValues":["Day Pillar (Gan-Zhi)",null]},{"labels":["Calculation Status","-"],"fields":[null,"A6.calcStatus"],"templateValues":["Calculation Status",null]},{"labels":["Verification Status","-"],"fields":[null,"A6.verifyStatus"],"templateValues":["Verification Status",null]}]},{"section":"A","subsection":"A7","headers":["Category","Description"],"rows":[{"labels":["Month Branch (Di Zhi / 地支)","-"],"fields":[null,"A7.monthBranch"],"templateValues":["Month Branch (Di Zhi / 地支)",null]},{"labels":["Branch Element","-"],"fields":[null,"A7.branchElement"],"templateValues":["Branch Element",null]},{"labels":["Branch Polarity","-"],"fields":[null,"A7.branchPolarity"],"templateValues":["Branch Polarity",null]},{"labels":["Solar Month","-"],"fields":[null,"A7.solarMonth"],"templateValues":["Solar Month",null]},{"labels":["Determining Solar Term (Jie Qi / 节气)","-"],"fields":[null,"A7.detSolarTerm"],"templateValues":["Determining Solar Term (Jie Qi / 节气)",null]},{"labels":["Date & Time of Solar Term","-"],"fields":[null,"A7.solarTermTime"],"templateValues":["Date & Time of Solar Term",null]},{"labels":["Main Qi (Ben Qi / 本气)","-"],"fields":[null,"A7.mainQi"],"templateValues":["Main Qi (Ben Qi / 本气)",null]},{"labels":["Middle Qi (Zhong Qi / 中气)","-"],"fields":[null,"A7.midQi"],"templateValues":["Middle Qi (Zhong Qi / 中气)",null]},{"labels":["Residual Qi (Yu Qi / 余气)","-"],"fields":[null,"A7.resQi"],"templateValues":["Residual Qi (Yu Qi / 余气)",null]},{"labels":["Hidden Stems Composition (Cang Gan / 藏干)","-"],"fields":[null,"A7.hiddenStemsComp"],"templateValues":["Hidden Stems Composition (Cang Gan / 藏干)",null]},{"labels":["Season Position","-"],"fields":[null,"A7.seasonPos"],"templateValues":["Season Position",null]},{"labels":["Month Command Identification Status","-"],"fields":[null,"A7.monthCmdStatus"],"templateValues":["Month Command Identification Status",null]},{"labels":["Verification Status","-"],"fields":[null,"A7.verifyStatus"],"templateValues":["Verification Status",null]}]},{"section":"A","subsection":"A8","headers":["Element","Visible Stems","Hidden Stems","Branch Presence","Raw Count","Seasonal State (Wang / 旺 — Xiang / 相 — Xiu / 休 — Qiu / 囚 — Si / 死)","Adjusted Weight (Post-Season)"],"rows":[{"labels":["Wood (Mu / 木)","-","-","-","-","-","-"],"fields":[null,"A8.wood.visible","A8.wood.hidden","A8.wood.branch","A8.wood.raw","A8.wood.seasonal","A8.wood.weight"],"templateValues":["Wood (Mu / 木)",null,null,null,null,null,null]},{"labels":["Fire (Huo / 火)","-","-","-","-","-","-"],"fields":[null,"A8.fire.visible","A8.fire.hidden","A8.fire.branch","A8.fire.raw","A8.fire.seasonal","A8.fire.weight"],"templateValues":["Fire (Huo / 火)",null,null,null,null,null,null]},{"labels":["Earth (Tu / 土)","-","-","-","-","-","-"],"fields":[null,"A8.earth.visible","A8.earth.hidden","A8.earth.branch","A8.earth.raw","A8.earth.seasonal","A8.earth.weight"],"templateValues":["Earth (Tu / 土)",null,null,null,null,null,null]},{"labels":["Metal (Jin / 金)","-","-","-","-","-","-"],"fields":[null,"A8.metal.visible","A8.metal.hidden","A8.metal.branch","A8.metal.raw","A8.metal.seasonal","A8.metal.weight"],"templateValues":["Metal (Jin / 金)",null,null,null,null,null,null]},{"labels":["Water (Shui / 水)","-","-","-","-","-","-"],"fields":[null,"A8.water.visible","A8.water.hidden","A8.water.branch","A8.water.raw","A8.water.seasonal","A8.water.weight"],"templateValues":["Water (Shui / 水)",null,null,null,null,null,null]}]},{"section":"A","subsection":"A9","headers":["Category","Description"],"rows":[{"labels":["Visible Yang","-"],"fields":[null,"A9.visYang"],"templateValues":["Visible Yang",null]},{"labels":["Visible Yin","-"],"fields":[null,"A9.visYin"],"templateValues":["Visible Yin",null]},{"labels":["Hidden Yang","-"],"fields":[null,"A9.hidYang"],"templateValues":["Hidden Yang",null]},{"labels":["Hidden Yin","-"],"fields":[null,"A9.hidYin"],"templateValues":["Hidden Yin",null]},{"labels":["Total Yang","-"],"fields":[null,"A9.totalYang"],"templateValues":["Total Yang",null]},{"labels":["Total Yin","-"],"fields":[null,"A9.totalYin"],"templateValues":["Total Yin",null]},{"labels":["Yang / Yin Ratio","-"],"fields":[null,"A9.ratio"],"templateValues":["Yang / Yin Ratio",null]},{"labels":["Calculation Method","-"],"fields":[null,"A9.method"],"templateValues":["Calculation Method",null]},{"labels":["Status","-"],"fields":[null,"A9.status"],"templateValues":["Status",null]}]},{"section":"A","subsection":"A10.1","headers":["Heavenly Stem (Tian Gan / 天干)","Element","Polarity","Ten Gods (Shi Shen / 十神)"],"rows":[{"labels":["Jia (甲)","-","-","-"],"fields":[null,"A10_1.jia.elem","A10_1.jia.pol","A10_1.jia.god"],"templateValues":["Jia (甲)",null,null,null]},{"labels":["Yi (乙)","-","-","-"],"fields":[null,"A10_1.yi.elem","A10_1.yi.pol","A10_1.yi.god"],"templateValues":["Yi (乙)",null,null,null]},{"labels":["Bing (丙)","-","-","-"],"fields":[null,"A10_1.bing.elem","A10_1.bing.pol","A10_1.bing.god"],"templateValues":["Bing (丙)",null,null,null]},{"labels":["Ding (丁)","-","-","-"],"fields":[null,"A10_1.ding.elem","A10_1.ding.pol","A10_1.ding.god"],"templateValues":["Ding (丁)",null,null,null]},{"labels":["Wu (戊)","-","-","-"],"fields":[null,"A10_1.wu.elem","A10_1.wu.pol","A10_1.wu.god"],"templateValues":["Wu (戊)",null,null,null]},{"labels":["Ji (己)","-","-","-"],"fields":[null,"A10_1.ji.elem","A10_1.ji.pol","A10_1.ji.god"],"templateValues":["Ji (己)",null,null,null]},{"labels":["Geng (庚)","-","-","-"],"fields":[null,"A10_1.geng.elem","A10_1.geng.pol","A10_1.geng.god"],"templateValues":["Geng (庚)",null,null,null]},{"labels":["Xin (辛)","-","-","-"],"fields":[null,"A10_1.xin.elem","A10_1.xin.pol","A10_1.xin.god"],"templateValues":["Xin (辛)",null,null,null]},{"labels":["Ren (壬)","-","-","-"],"fields":[null,"A10_1.ren.elem","A10_1.ren.pol","A10_1.ren.god"],"templateValues":["Ren (壬)",null,null,null]},{"labels":["Gui (癸)","-","-","-"],"fields":[null,"A10_1.gui.elem","A10_1.gui.pol","A10_1.gui.god"],"templateValues":["Gui (癸)",null,null,null]}]},{"section":"A","subsection":"A10.2","headers":["Position","Stem (Tian Gan / 天干)","Ten Gods (Shi Shen / 十神)"],"rows":[{"labels":["Year (Nian / 年)","-","-"],"fields":[null,"A10_2.year.stem","A10_2.year.god"],"templateValues":["Year (Nian / 年)",null,null]},{"labels":["Month (Yue / 月)","-","-"],"fields":[null,"A10_2.month.stem","A10_2.month.god"],"templateValues":["Month (Yue / 月)",null,null]},{"labels":["Day (Ri / 日)","Day Master","-"],"fields":[null,null,"A10_2.day.god"],"templateValues":["Day (Ri / 日)","Day Master",null]},{"labels":["Hour (Shi / 时)","-","-"],"fields":[null,"A10_2.hour.stem","A10_2.hour.god"],"templateValues":["Hour (Shi / 时)",null,null]}]},{"section":"A","subsection":"A10.3","headers":["Pillar","Earthly Branch (Di Zhi / 地支)","Hidden Stem (Cang Gan / 藏干)","Ten Gods (Shi Shen / 十神)"],"rows":[{"labels":["Year","-","-","-"],"fields":[null,"A10_3.year.branch","A10_3.year.mainStem","A10_3.year.mainGod"],"templateValues":["Year",null,null,null]},{"labels":["Year","-","-","-"],"fields":[null,"A10_3.year.branch","A10_3.year.midStem","A10_3.year.midGod"],"templateValues":["Year",null,null,null]},{"labels":["Year","-","-","-"],"fields":[null,"A10_3.year.branch","A10_3.year.resStem","A10_3.year.resGod"],"templateValues":["Year",null,null,null]},{"labels":["Month","-","-","-"],"fields":[null,"A10_3.month.branch","A10_3.month.mainStem","A10_3.month.mainGod"],"templateValues":["Month",null,null,null]},{"labels":["Month","-","-","-"],"fields":[null,"A10_3.month.branch","A10_3.month.midStem","A10_3.month.midGod"],"templateValues":["Month",null,null,null]},{"labels":["Month","-","-","-"],"fields":[null,"A10_3.month.branch","A10_3.month.resStem","A10_3.month.resGod"],"templateValues":["Month",null,null,null]},{"labels":["Day","-","-","-"],"fields":[null,"A10_3.day.branch","A10_3.day.mainStem","A10_3.day.mainGod"],"templateValues":["Day",null,null,null]},{"labels":["Day","-","-","-"],"fields":[null,"A10_3.day.branch","A10_3.day.midStem","A10_3.day.midGod"],"templateValues":["Day",null,null,null]},{"labels":["Day","-","-","-"],"fields":[null,"A10_3.day.branch","A10_3.day.resStem","A10_3.day.resGod"],"templateValues":["Day",null,null,null]},{"labels":["Hour","-","-","-"],"fields":[null,"A10_3.hour.branch","A10_3.hour.mainStem","A10_3.hour.mainGod"],"templateValues":["Hour",null,null,null]},{"labels":["Hour","-","-","-"],"fields":[null,"A10_3.hour.branch","A10_3.hour.midStem","A10_3.hour.midGod"],"templateValues":["Hour",null,null,null]},{"labels":["Hour","-","-","-"],"fields":[null,"A10_3.hour.branch","A10_3.hour.resStem","A10_3.hour.resGod"],"templateValues":["Hour",null,null,null]}]},{"section":"A","subsection":"A10.4","headers":["Ten Gods (Shi Shen / 十神)","Appearance Frequency","Presence Status"],"rows":[{"labels":["Companion / Friend (Bi Jian / 比肩)","-","-"],"fields":[null,"A10_4.biJian.freq","A10_4.biJian.status"],"templateValues":["Companion / Friend (Bi Jian / 比肩)",null,null]},{"labels":["Rob Wealth (Jie Cai / 劫财)","-","-"],"fields":[null,"A10_4.jieCai.freq","A10_4.jieCai.status"],"templateValues":["Rob Wealth (Jie Cai / 劫财)",null,null]},{"labels":["Eating God (Shi Shen / 食神)","-","-"],"fields":[null,"A10_4.shiShen.freq","A10_4.shiShen.status"],"templateValues":["Eating God (Shi Shen / 食神)",null,null]},{"labels":["Hurting Officer (Shang Guan / 伤官)","-","-"],"fields":[null,"A10_4.shangGuan.freq","A10_4.shangGuan.status"],"templateValues":["Hurting Officer (Shang Guan / 伤官)",null,null]},{"labels":["Indirect Wealth (Pian Cai / 偏财)","-","-"],"fields":[null,"A10_4.pianCai.freq","A10_4.pianCai.status"],"templateValues":["Indirect Wealth (Pian Cai / 偏财)",null,null]},{"labels":["Direct Wealth (Zheng Cai / 正财)","-","-"],"fields":[null,"A10_4.zhengCai.freq","A10_4.zhengCai.status"],"templateValues":["Direct Wealth (Zheng Cai / 正财)",null,null]},{"labels":["Seven Killings (Qi Sha / 七杀)","-","-"],"fields":[null,"A10_4.qiSha.freq","A10_4.qiSha.status"],"templateValues":["Seven Killings (Qi Sha / 七杀)",null,null]},{"labels":["Direct Officer (Zheng Guan / 正官)","-","-"],"fields":[null,"A10_4.zhengGuan.freq","A10_4.zhengGuan.status"],"templateValues":["Direct Officer (Zheng Guan / 正官)",null,null]},{"labels":["Indirect Resource (Pian Yin / 偏印)","-","-"],"fields":[null,"A10_4.pianYin.freq","A10_4.pianYin.status"],"templateValues":["Indirect Resource (Pian Yin / 偏印)",null,null]},{"labels":["Direct Resource (Zheng Yin / 正印)","-","-"],"fields":[null,"A10_4.zhengYin.freq","A10_4.zhengYin.status"],"templateValues":["Direct Resource (Zheng Yin / 正印)",null,null]}]},{"section":"A","subsection":"A10.5","headers":["Position","Stem (Tian Gan / 天干)","Stem's Ten God","Earthly Branch (Di Zhi / 地支)","Main Qi (Ben Qi / 本气)","Main Qi's Ten God"],"rows":[{"labels":["Year","-","-","-","-","-"],"fields":[null,"A10_5.year.stem","A10_5.year.stemGod","A10_5.year.branch","A10_5.year.mainQi","A10_5.year.mainGod"],"templateValues":["Year",null,null,null,null,null]},{"labels":["Month","-","-","-","-","-"],"fields":[null,"A10_5.month.stem","A10_5.month.stemGod","A10_5.month.branch","A10_5.month.mainQi","A10_5.month.mainGod"],"templateValues":["Month",null,null,null,null,null]},{"labels":["Day","-","-","-","-","-"],"fields":[null,"A10_5.day.stem","A10_5.day.stemGod","A10_5.day.branch","A10_5.day.mainQi","A10_5.day.mainGod"],"templateValues":["Day",null,null,null,null,null]},{"labels":["Hour","-","-","-","-","-"],"fields":[null,"A10_5.hour.stem","A10_5.hour.stemGod","A10_5.hour.branch","A10_5.hour.mainQi","A10_5.hour.mainGod"],"templateValues":["Hour",null,null,null,null,null]}]},{"section":"A","subsection":"A11","headers":["Category","Description"],"rows":[{"labels":["Root Presence","-"],"fields":[null,"A11.rootPresence"],"templateValues":["Root Presence",null]},{"labels":["Root-Providing Branches","-"],"fields":[null,"A11.branches"],"templateValues":["Root-Providing Branches",null]},{"labels":["Root-Providing Hidden Stems","-"],"fields":[null,"A11.hiddenStems"],"templateValues":["Root-Providing Hidden Stems",null]},{"labels":["Root Type / Source","-"],"fields":[null,"A11.type"],"templateValues":["Root Type / Source",null]},{"labels":["Primary Roots (Main Qi)","-"],"fields":[null,"A11.primary"],"templateValues":["Primary Roots (Main Qi)",null]},{"labels":["Secondary Roots (Middle / Residual Qi)","-"],"fields":[null,"A11.secondary"],"templateValues":["Secondary Roots (Middle / Residual Qi)",null]},{"labels":["Resource Element Support (Sheng / 生)","-"],"fields":[null,"A11.resSupport"],"templateValues":["Resource Element Support (Sheng / 生)",null]},{"labels":["Companion Element Support (Bi / 比)","-"],"fields":[null,"A11.compSupport"],"templateValues":["Companion Element Support (Bi / 比)",null]},{"labels":["Output Element Drain (Xie / 泄)","-"],"fields":[null,"A11.outDrain"],"templateValues":["Output Element Drain (Xie / 泄)",null]},{"labels":["Wealth Element Presence (Cai / 财)","-"],"fields":[null,"A11.wealthPres"],"templateValues":["Wealth Element Presence (Cai / 财)",null]},{"labels":["Officer/Control Element Presence (Guan / 官 / Sha / 杀)","-"],"fields":[null,"A11.officerPres"],"templateValues":["Officer/Control Element Presence (Guan / 官 / Sha / 杀)",null]},{"labels":["Root Data Status","-"],"fields":[null,"A11.dataStatus"],"templateValues":["Root Data Status",null]},{"labels":["Verification Status","-"],"fields":[null,"A11.verifyStatus"],"templateValues":["Verification Status",null]}]},{"section":"A","subsection":"A12.1","headers":["Pillar","Gan-Zhi","Na Yin","Na Yin Element"],"rows":[{"labels":["Year","-","-","-"],"fields":[null,"A12_1.year.ganZhi","A12_1.year.naYin","A12_1.year.naYinElem"],"templateValues":["Year",null,null,null]},{"labels":["Month","-","-","-"],"fields":[null,"A12_1.month.ganZhi","A12_1.month.naYin","A12_1.month.naYinElem"],"templateValues":["Month",null,null,null]},{"labels":["Day","-","-","-"],"fields":[null,"A12_1.day.ganZhi","A12_1.day.naYin","A12_1.day.naYinElem"],"templateValues":["Day",null,null,null]},{"labels":["Hour","-","-","-"],"fields":[null,"A12_1.hour.ganZhi","A12_1.hour.naYin","A12_1.hour.naYinElem"],"templateValues":["Hour",null,null,null]}]},{"section":"A","subsection":"A12.2","headers":["Reference Target","Pillar","Earthly Branch (Di Zhi / 地支)","Phase (Stage)","Calculation Basis"],"rows":[{"labels":["Day Master","Year","-","-","-"],"fields":[null,null,"A12_2.dm.year.branch","A12_2.dm.year.phase","A12_2.dm.year.basis"],"templateValues":["Day Master","Year",null,null,null]},{"labels":["Day Master","Month","-","-","-"],"fields":[null,null,"A12_2.dm.month.branch","A12_2.dm.month.phase","A12_2.dm.month.basis"],"templateValues":["Day Master","Month",null,null,null]},{"labels":["Day Master","Day","-","-","-"],"fields":[null,null,"A12_2.dm.day.branch","A12_2.dm.day.phase","A12_2.dm.day.basis"],"templateValues":["Day Master","Day",null,null,null]},{"labels":["Day Master","Hour","-","-","-"],"fields":[null,null,"A12_2.dm.hour.branch","A12_2.dm.hour.phase","A12_2.dm.hour.basis"],"templateValues":["Day Master","Hour",null,null,null]},{"labels":["Year Stem","Month","-","-","-"],"fields":[null,null,"A12_2.ys.month.branch","A12_2.ys.month.phase","A12_2.ys.month.basis"],"templateValues":["Year Stem","Month",null,null,null]},{"labels":["Year Stem","Day","-","-","-"],"fields":[null,null,"A12_2.ys.day.branch","A12_2.ys.day.phase","A12_2.ys.day.basis"],"templateValues":["Year Stem","Day",null,null,null]},{"labels":["Year Stem","Hour","-","-","-"],"fields":[null,null,"A12_2.ys.hour.branch","A12_2.ys.hour.phase","A12_2.ys.hour.basis"],"templateValues":["Year Stem","Hour",null,null,null]},{"labels":["Month Stem","Year","-","-","-"],"fields":[null,null,"A12_2.ms.year.branch","A12_2.ms.year.phase","A12_2.ms.year.basis"],"templateValues":["Month Stem","Year",null,null,null]},{"labels":["Month Stem","Day","-","-","-"],"fields":[null,null,"A12_2.ms.day.branch","A12_2.ms.day.phase","A12_2.ms.day.basis"],"templateValues":["Month Stem","Day",null,null,null]},{"labels":["Month Stem","Hour","-","-","-"],"fields":[null,null,"A12_2.ms.hour.branch","A12_2.ms.hour.phase","A12_2.ms.hour.basis"],"templateValues":["Month Stem","Hour",null,null,null]},{"labels":["Hour Stem","Year","-","-","-"],"fields":[null,null,"A12_2.hs.year.branch","A12_2.hs.year.phase","A12_2.hs.year.basis"],"templateValues":["Hour Stem","Year",null,null,null]},{"labels":["Hour Stem","Month","-","-","-"],"fields":[null,null,"A12_2.hs.month.branch","A12_2.hs.month.phase","A12_2.hs.month.basis"],"templateValues":["Hour Stem","Month",null,null,null]},{"labels":["Hour Stem","Day","-","-","-"],"fields":[null,null,"A12_2.hs.day.branch","A12_2.hs.day.phase","A12_2.hs.day.basis"],"templateValues":["Hour Stem","Day",null,null,null]}]},{"section":"A","subsection":"A12.3","headers":["Category","Description"],"rows":[{"labels":["Day Stem-Branch Pair","-"],"fields":[null,"A12_3.dayPair"],"templateValues":["Day Stem-Branch Pair",null]},{"labels":["Xun Number / Xun Cycle","-"],"fields":[null,"A12_3.xunCycle"],"templateValues":["Xun Number / Xun Cycle",null]},{"labels":["Two Empty Branches (Kong Wang / 空亡)","-"],"fields":[null,"A12_3.emptyBranches"],"templateValues":["Two Empty Branches (Kong Wang / 空亡)",null]},{"labels":["Application Scope","-"],"fields":[null,"A12_3.scope"],"templateValues":["Application Scope",null]},{"labels":["Calculation Status","-"],"fields":[null,"A12_3.calcStatus"],"templateValues":["Calculation Status",null]},{"labels":["Verification Status","-"],"fields":[null,"A12_3.verifyStatus"],"templateValues":["Verification Status",null]}]},{"section":"A","subsection":"A12.4","headers":["Shen Sha ID","Definition","Calculation Rule","Reference Type","Reference Point","Required Condition","Result","Location","Rule Source"],"rows":[{"labels":["Yi Ma (Yi Ma / 驿马)","Movement","Branch Triplet","Branch","Day / Year","-","-","-","-"],"fields":[null,null,null,null,null,"A12_4.yima.req","A12_4.yima.result","A12_4.yima.location","A12_4.yima.source"],"templateValues":["Yi Ma (Yi Ma / 驿马)","Movement","Branch Triplet","Branch","Day / Year",null,null,null,null]},{"labels":["Tao Hua (Tao Hua / 桃花)","Romance","Branch Triplet","Branch","Day / Year","-","-","-","-"],"fields":[null,null,null,null,null,"A12_4.taohua.req","A12_4.taohua.result","A12_4.taohua.location","A12_4.taohua.source"],"templateValues":["Tao Hua (Tao Hua / 桃花)","Romance","Branch Triplet","Branch","Day / Year",null,null,null,null]},{"labels":["Tian Yi Gui Ren (Tian Yi Gui Ren / 天乙贵人)","Divine Help","Day Master Rule","Stem","Day Master","-","-","-","-"],"fields":[null,null,null,null,null,"A12_4.tianyi.req","A12_4.tianyi.result","A12_4.tianyi.location","A12_4.tianyi.source"],"templateValues":["Tian Yi Gui Ren (Tian Yi Gui Ren / 天乙贵人)","Divine Help","Day Master Rule","Stem","Day Master",null,null,null,null]},{"labels":["Hua Gai (Hua Gai / 华盖)","Arts / Solitude","Branch Triplet","Branch","Day / Year","-","-","-","-"],"fields":[null,null,null,null,null,"A12_4.huagai.req","A12_4.huagai.result","A12_4.huagai.location","A12_4.huagai.source"],"templateValues":["Hua Gai (Hua Gai / 华盖)","Arts / Solitude","Branch Triplet","Branch","Day / Year",null,null,null,null]},{"labels":["Lu Shen (Lu Shen / 禄神)","Core Strength","Day Master Rule","Stem","Day Master","-","-","-","-"],"fields":[null,null,null,null,null,"A12_4.lushen.req","A12_4.lushen.result","A12_4.lushen.location","A12_4.lushen.source"],"templateValues":["Lu Shen (Lu Shen / 禄神)","Core Strength","Day Master Rule","Stem","Day Master",null,null,null,null]},{"labels":["Yang Ren (Yang Ren / 羊刃)","Extreme","Day Master Rule","Stem","Day Master","-","-","-","-"],"fields":[null,null,null,null,null,"A12_4.yangren.req","A12_4.yangren.result","A12_4.yangren.location","A12_4.yangren.source"],"templateValues":["Yang Ren (Yang Ren / 羊刃)","Extreme","Day Master Rule","Stem","Day Master",null,null,null,null]}]},{"section":"A","subsection":"A12.5","headers":["Interaction Rule Registry","Participating Stems","Position","Structural Fact"],"rows":[{"labels":["Combination (He / 合)","-","-","-"],"fields":[null,"A12_5.he.stems","A12_5.he.position","A12_5.he.fact"],"templateValues":["Combination (He / 合)",null,null,null]},{"labels":["Clash (Chong / 冲)","-","-","-"],"fields":[null,"A12_5.chong.stems","A12_5.chong.position","A12_5.chong.fact"],"templateValues":["Clash (Chong / 冲)",null,null,null]}]},{"section":"A","subsection":"A12.6","headers":["Interaction Rule Registry","Participating Branches","Position","Structural Fact"],"rows":[{"labels":["Six Harmonies (Liu He / 六合)","-","-","-"],"fields":[null,"A12_6.liuhe.branches","A12_6.liuhe.position","A12_6.liuhe.fact"],"templateValues":["Six Harmonies (Liu He / 六合)",null,null,null]},{"labels":["Three Harmonies (San He / 三合)","-","-","-"],"fields":[null,"A12_6.sanhe.branches","A12_6.sanhe.position","A12_6.sanhe.fact"],"templateValues":["Three Harmonies (San He / 三合)",null,null,null]},{"labels":["Seasonal Direction (San Hui / 三会)","-","-","-"],"fields":[null,"A12_6.sanhui.branches","A12_6.sanhui.position","A12_6.sanhui.fact"],"templateValues":["Seasonal Direction (San Hui / 三会)",null,null,null]},{"labels":["Half Combination (Ban He / 半合)","-","-","-"],"fields":[null,"A12_6.banhe.branches","A12_6.banhe.position","A12_6.banhe.fact"],"templateValues":["Half Combination (Ban He / 半合)",null,null,null]},{"labels":["Clash (Chong / 冲)","-","-","-"],"fields":[null,"A12_6.chong.branches","A12_6.chong.position","A12_6.chong.fact"],"templateValues":["Clash (Chong / 冲)",null,null,null]},{"labels":["Punishment (Xing / 刑)","-","-","-"],"fields":[null,"A12_6.xing.branches","A12_6.xing.position","A12_6.xing.fact"],"templateValues":["Punishment (Xing / 刑)",null,null,null]},{"labels":["Harm (Hai / 害)","-","-","-"],"fields":[null,"A12_6.hai.branches","A12_6.hai.position","A12_6.hai.fact"],"templateValues":["Harm (Hai / 害)",null,null,null]},{"labels":["Destruction (Po / 破)","-","-","-"],"fields":[null,"A12_6.po.branches","A12_6.po.position","A12_6.po.fact"],"templateValues":["Destruction (Po / 破)",null,null,null]}]},{"section":"A","subsection":"A12.7","headers":["Participating Elements","Interaction Type","Transformation Status"],"rows":[{"labels":["-","-","-"],"fields":["A12_7.row1.elements","A12_7.row1.type","A12_7.row1.status"],"templateValues":[null,null,null]}]},{"section":"A","subsection":"A12.8","headers":["Category","Element"],"rows":[{"labels":["Useful God (Yong Shen / 用神)","-"],"fields":[null,"A12_8.yongshen"],"templateValues":["Useful God (Yong Shen / 用神)",null]},{"labels":["Favorable God (Xi Shen / 喜神)","-"],"fields":[null,"A12_8.xishen"],"templateValues":["Favorable God (Xi Shen / 喜神)",null]},{"labels":["Unfavorable God (Ji Shen / 忌神)","-"],"fields":[null,"A12_8.jishen"],"templateValues":["Unfavorable God (Ji Shen / 忌神)",null]}]},{"section":"A","subsection":"A12.9","headers":["Category","Element / Ten God","Evidence"],"rows":[{"labels":["Primary Pattern Candidate","-","Main Qi → Ten God · Mechanical · not Tou Gan/penetration"],"fields":[null,"A12_9.primary.elem",null],"templateValues":["Primary Pattern Candidate",null,null]},{"labels":["Alternative Candidates","-","Middle / Residual → Ten God · Mechanical · not penetration"],"fields":[null,"A12_9.alt.elem",null],"templateValues":["Alternative Candidates",null,null]}]},{"section":"A","subsection":"A13","headers":["Category","Description"],"rows":[{"labels":["Life Palace (Ming Gong / 命宫)","-"],"fields":[null,"A13.mingGong.value"],"templateValues":["Life Palace (Ming Gong / 命宫)",null]},{"labels":["Ming Gong Calculation Basis","-"],"fields":[null,"A13.mingGong.basis"],"templateValues":["Ming Gong Calculation Basis",null]},{"labels":["Ming Gong Verification Status","-"],"fields":[null,"A13.mingGong.verify"],"templateValues":["Ming Gong Verification Status",null]},{"labels":["Conception Palace (Tai Yuan / 胎元)","-"],"fields":[null,"A13.taiYuan.value"],"templateValues":["Conception Palace (Tai Yuan / 胎元)",null]},{"labels":["Tai Yuan Calculation Basis","-"],"fields":[null,"A13.taiYuan.basis"],"templateValues":["Tai Yuan Calculation Basis",null]},{"labels":["Tai Yuan Verification Status","-"],"fields":[null,"A13.taiYuan.verify"],"templateValues":["Tai Yuan Verification Status",null]},{"labels":["Classification","Auxiliary Foundation"],"fields":[null,null],"templateValues":["Classification","Auxiliary Foundation"]}]},{"section":"A","subsection":"A14.1","headers":["Category","Description"],"rows":[{"labels":["Direction of Travel","-"],"fields":[null,"A14_1.direction"],"templateValues":["Direction of Travel",null]},{"labels":["Da Yun Rule Set / Direction Rule","Gender + Year Stem Polarity + Direction Rule = Shun / Ni"],"fields":[null,null],"templateValues":["Da Yun Rule Set / Direction Rule","Gender + Year Stem Polarity + Direction Rule = Shun / Ni"]},{"labels":["Starting Age","-"],"fields":[null,"A14_1.startAge"],"templateValues":["Starting Age (Starting Age)",null]},{"labels":["Starting Date & Time","-"],"fields":[null,"A14_1.startDateTime"],"templateValues":["Starting Date & Time",null]},{"labels":["Starting Point","-"],"fields":[null,"A14_1.startPoint"],"templateValues":["Starting Point",null]},{"labels":["Reference Solar Term (Jie Qi / 节气)","-"],"fields":[null,"A14_1.refJieQi"],"templateValues":["Reference Solar Term (Jie Qi / 节气)",null]},{"labels":["Calculation Basis","3 Days = 1 Year"],"fields":[null,null],"templateValues":["Calculation Basis","3 Days = 1 Year"]},{"labels":["Transition Rule","-"],"fields":[null,"A14_1.transRule"],"templateValues":["Transition Rule",null]},{"labels":["Calculation Method","-"],"fields":[null,"A14_1.calcMethod"],"templateValues":["Calculation Method",null]},{"labels":["Sequence Verification","-"],"fields":[null,"A14_1.seqVerify"],"templateValues":["Sequence Verification",null]},{"labels":["Status","-"],"fields":[null,"A14_1.status"],"templateValues":["Status",null]}]},{"section":"A","subsection":"A14.2","headers":["No.","Gan-Zhi","Heavenly Stem (Tian Gan / 天干)","Stem Element","Stem Polarity","Earthly Branch (Di Zhi / 地支)","Branch Element","Branch Polarity","Starting Age (周岁 / Actual / Precise)","Ending Age (周岁 / Actual / Precise)","Starting Year","Ending Year","Duration","Verification Status"],"rows":[{"labels":["1","-","-","-","-","-","-","-","-","-","-","-","-","-"],"fields":[null,"A14_2.1.ganZhi","A14_2.1.stem","A14_2.1.stemElem","A14_2.1.stemPol","A14_2.1.branch","A14_2.1.branchElem","A14_2.1.branchPol","A14_2.1.startAge","A14_2.1.endAge","A14_2.1.startYear","A14_2.1.endYear","A14_2.1.duration","A14_2.1.status"],"templateValues":["1",null,null,null,null,null,null,null,null,null,null,null,null,null]},{"labels":["2","-","-","-","-","-","-","-","-","-","-","-","-","-"],"fields":[null,"A14_2.2.ganZhi","A14_2.2.stem","A14_2.2.stemElem","A14_2.2.stemPol","A14_2.2.branch","A14_2.2.branchElem","A14_2.2.branchPol","A14_2.2.startAge","A14_2.2.endAge","A14_2.2.startYear","A14_2.2.endYear","A14_2.2.duration","A14_2.2.status"],"templateValues":["2",null,null,null,null,null,null,null,null,null,null,null,null,null]},{"labels":["3","-","-","-","-","-","-","-","-","-","-","-","-","-"],"fields":[null,"A14_2.3.ganZhi","A14_2.3.stem","A14_2.3.stemElem","A14_2.3.stemPol","A14_2.3.branch","A14_2.3.branchElem","A14_2.3.branchPol","A14_2.3.startAge","A14_2.3.endAge","A14_2.3.startYear","A14_2.3.endYear","A14_2.3.duration","A14_2.3.status"],"templateValues":["3",null,null,null,null,null,null,null,null,null,null,null,null,null]},{"labels":["4","-","-","-","-","-","-","-","-","-","-","-","-","-"],"fields":[null,"A14_2.4.ganZhi","A14_2.4.stem","A14_2.4.stemElem","A14_2.4.stemPol","A14_2.4.branch","A14_2.4.branchElem","A14_2.4.branchPol","A14_2.4.startAge","A14_2.4.endAge","A14_2.4.startYear","A14_2.4.endYear","A14_2.4.duration","A14_2.4.status"],"templateValues":["4",null,null,null,null,null,null,null,null,null,null,null,null,null]},{"labels":["5","-","-","-","-","-","-","-","-","-","-","-","-","-"],"fields":[null,"A14_2.5.ganZhi","A14_2.5.stem","A14_2.5.stemElem","A14_2.5.stemPol","A14_2.5.branch","A14_2.5.branchElem","A14_2.5.branchPol","A14_2.5.startAge","A14_2.5.endAge","A14_2.5.startYear","A14_2.5.endYear","A14_2.5.duration","A14_2.5.status"],"templateValues":["5",null,null,null,null,null,null,null,null,null,null,null,null,null]},{"labels":["6","-","-","-","-","-","-","-","-","-","-","-","-","-"],"fields":[null,"A14_2.6.ganZhi","A14_2.6.stem","A14_2.6.stemElem","A14_2.6.stemPol","A14_2.6.branch","A14_2.6.branchElem","A14_2.6.branchPol","A14_2.6.startAge","A14_2.6.endAge","A14_2.6.startYear","A14_2.6.endYear","A14_2.6.duration","A14_2.6.status"],"templateValues":["6",null,null,null,null,null,null,null,null,null,null,null,null,null]},{"labels":["7","-","-","-","-","-","-","-","-","-","-","-","-","-"],"fields":[null,"A14_2.7.ganZhi","A14_2.7.stem","A14_2.7.stemElem","A14_2.7.stemPol","A14_2.7.branch","A14_2.7.branchElem","A14_2.7.branchPol","A14_2.7.startAge","A14_2.7.endAge","A14_2.7.startYear","A14_2.7.endYear","A14_2.7.duration","A14_2.7.status"],"templateValues":["7",null,null,null,null,null,null,null,null,null,null,null,null,null]},{"labels":["8","-","-","-","-","-","-","-","-","-","-","-","-","-"],"fields":[null,"A14_2.8.ganZhi","A14_2.8.stem","A14_2.8.stemElem","A14_2.8.stemPol","A14_2.8.branch","A14_2.8.branchElem","A14_2.8.branchPol","A14_2.8.startAge","A14_2.8.endAge","A14_2.8.startYear","A14_2.8.endYear","A14_2.8.duration","A14_2.8.status"],"templateValues":["8",null,null,null,null,null,null,null,null,null,null,null,null,null]}]},{"section":"A","subsection":"A14.3","headers":["Da Yun Pillar","Interactions with Natal Chart (Stem He / Chong, Branch He / Chong / Xing / Hai)"],"rows":[{"labels":["Pillar 1","-"],"fields":[null,"A14_3.1.interactions"],"templateValues":["Pillar 1",null]},{"labels":["Pillar 2","-"],"fields":[null,"A14_3.2.interactions"],"templateValues":["Pillar 2",null]},{"labels":["Pillar 3","-"],"fields":[null,"A14_3.3.interactions"],"templateValues":["Pillar 3",null]},{"labels":["Pillar 4","-"],"fields":[null,"A14_3.4.interactions"],"templateValues":["Pillar 4",null]},{"labels":["Pillar 5","-"],"fields":[null,"A14_3.5.interactions"],"templateValues":["Pillar 5",null]},{"labels":["Pillar 6","-"],"fields":[null,"A14_3.6.interactions"],"templateValues":["Pillar 6",null]},{"labels":["Pillar 7","-"],"fields":[null,"A14_3.7.interactions"],"templateValues":["Pillar 7",null]},{"labels":["Pillar 8","-"],"fields":[null,"A14_3.8.interactions"],"templateValues":["Pillar 8",null]}]},{"section":"A","subsection":"A14.4","headers":["Verification ID","Issue Type","Resolution"],"rows":[{"labels":["-","-","-"],"fields":["A14_4.row1.id","A14_4.row1.issue","A14_4.row1.resolution"],"templateValues":[null,null,null]}]},{"section":"A","subsection":"A15","headers":["Category","Description"],"rows":[{"labels":["Permanent Birth Data","-"],"fields":[null,"A15.birthData"],"templateValues":["Permanent Birth Data",null]},{"labels":["Permanent Four Pillars","-"],"fields":[null,"A15.fourPillars"],"templateValues":["Permanent Four Pillars",null]},{"labels":["Permanent Day Master","-"],"fields":[null,"A15.dayMaster"],"templateValues":["Permanent Day Master",null]},{"labels":["Permanent Month Branch","-"],"fields":[null,"A15.monthBranch"],"templateValues":["Permanent Month Branch",null]},{"labels":["Core Chart Source","-"],"fields":[null,"A15.source"],"templateValues":["Core Chart Source",null]},{"labels":["Core Chart Lock Status","-"],"fields":[null,"A15.lockStatus"],"templateValues":["Core Chart Lock Status",null]},{"labels":["Core Chart Verification Status","-"],"fields":[null,"A15.verifyStatus"],"templateValues":["Core Chart Verification Status",null]}]},{"section":"A","subsection":"A16","headers":["Verification ID","Affected Section","Affected Field","Source Value","Derived Value","Issue Type","Severity","Status","Required Action","Resolution","Resolution Date","Verifier"],"rows":[{"labels":["-","-","-","-","-","-","-","-","-","-","-","-"],"fields":["A16.row1.id","A16.row1.section","A16.row1.field","A16.row1.source","A16.row1.derived","A16.row1.issue","A16.row1.severity","A16.row1.status","A16.row1.action","A16.row1.resolution","A16.row1.resDate","A16.row1.verifier"],"templateValues":[null,null,null,null,null,null,null,null,null,null,null,null]},{"labels":["-","-","-","-","-","-","-","-","-","-","-","-"],"fields":["A16.row2.id","A16.row2.section","A16.row2.field","A16.row2.source","A16.row2.derived","A16.row2.issue","A16.row2.severity","A16.row2.status","A16.row2.action","A16.row2.resolution","A16.row2.resDate","A16.row2.verifier"],"templateValues":[null,null,null,null,null,null,null,null,null,null,null,null]},{"labels":["-","-","-","-","-","-","-","-","-","-","-","-"],"fields":["A16.row3.id","A16.row3.section","A16.row3.field","A16.row3.source","A16.row3.derived","A16.row3.issue","A16.row3.severity","A16.row3.status","A16.row3.action","A16.row3.resolution","A16.row3.resDate","A16.row3.verifier"],"templateValues":[null,null,null,null,null,null,null,null,null,null,null,null]},{"labels":["-","-","-","-","-","-","-","-","-","-","-","-"],"fields":["A16.row4.id","A16.row4.section","A16.row4.field","A16.row4.source","A16.row4.derived","A16.row4.issue","A16.row4.severity","A16.row4.status","A16.row4.action","A16.row4.resolution","A16.row4.resDate","A16.row4.verifier"],"templateValues":[null,null,null,null,null,null,null,null,null,null,null,null]}]},{"section":"A","subsection":"A17","headers":["Note ID","Note Type","Related Section / Field","Note","Status"],"rows":[{"labels":["-","-","-","-","-"],"fields":["A17.row1.id","A17.row1.type","A17.row1.field","A17.row1.note","A17.row1.status"],"templateValues":[null,null,null,null,null]},{"labels":["-","-","-","-","-"],"fields":["A17.row2.id","A17.row2.type","A17.row2.field","A17.row2.note","A17.row2.status"],"templateValues":[null,null,null,null,null]},{"labels":["-","-","-","-","-"],"fields":["A17.row3.id","A17.row3.type","A17.row3.field","A17.row3.note","A17.row3.status"],"templateValues":[null,null,null,null,null]},{"labels":["-","-","-","-","-"],"fields":["A17.row4.id","A17.row4.type","A17.row4.field","A17.row4.note","A17.row4.status"],"templateValues":[null,null,null,null,null]}]},{"section":"B","subsection":"B1","headers":["Finding","Result","Evidence"],"rows":[{"labels":["Day Master Strength","-","-"],"fields":[null,"B1.strength.result","B1.strength.evidence"],"templateValues":["Day Master Strength",null,null]},{"labels":["Yue Ling Support","-","-"],"fields":[null,"B1.yueLing.result","B1.yueLing.evidence"],"templateValues":["Yue Ling Support",null,null]},{"labels":["Root Support","-","-"],"fields":[null,"B1.root.result","B1.root.evidence"],"templateValues":["Root Support",null,null]},{"labels":["Resource Support","-","-"],"fields":[null,"B1.resource.result","B1.resource.evidence"],"templateValues":["Resource Support",null,null]},{"labels":["Companion Support","-","-"],"fields":[null,"B1.companion.result","B1.companion.evidence"],"templateValues":["Companion Support",null,null]},{"labels":["Output Drain","-","-"],"fields":[null,"B1.output.result","B1.output.evidence"],"templateValues":["Output Drain",null,null]},{"labels":["Wealth Drain","-","-"],"fields":[null,"B1.wealth.result","B1.wealth.evidence"],"templateValues":["Wealth Drain",null,null]},{"labels":["Officer Pressure","-","-"],"fields":[null,"B1.officer.result","B1.officer.evidence"],"templateValues":["Officer Pressure",null,null]},{"labels":["Dominant Structural Side","-","-"],"fields":[null,"B1.dominant.result","B1.dominant.evidence"],"templateValues":["Dominant Structural Side",null,null]},{"labels":["Strength Determination","-","-"],"fields":[null,"B1.determination.result","B1.determination.evidence"],"templateValues":["Strength Determination",null,null]}]},{"section":"B","subsection":"B2","headers":["Finding","Result","Evidence"],"rows":[{"labels":["Month Command","-","-"],"fields":[null,"B2.monthCommand.result","B2.monthCommand.evidence"],"templateValues":["Month Command",null,null]},{"labels":["Main Qi (Ben Qi / 本气)","-","-"],"fields":[null,"B2.mainQi.result","B2.mainQi.evidence"],"templateValues":["Main Qi (Ben Qi / 本气)",null,null]},{"labels":["Middle Qi (Zhong Qi / 中气)","-","-"],"fields":[null,"B2.midQi.result","B2.midQi.evidence"],"templateValues":["Middle Qi (Zhong Qi / 中气)",null,null]},{"labels":["Residual Qi (Yu Qi / 余气)","-","-"],"fields":[null,"B2.resQi.result","B2.resQi.evidence"],"templateValues":["Residual Qi (Yu Qi / 余气)",null,null]},{"labels":["Relation to Day Master","-","-"],"fields":[null,"B2.relationDm.result","B2.relationDm.evidence"],"templateValues":["Relation to Day Master",null,null]},{"labels":["Seasonal Influence","-","-"],"fields":[null,"B2.seasonalInf.result","B2.seasonalInf.evidence"],"templateValues":["Seasonal Influence",null,null]},{"labels":["Structural Priority","-","-"],"fields":[null,"B2.priority.result","B2.priority.evidence"],"templateValues":["Structural Priority",null,null]},{"labels":["Structural Role","-","-"],"fields":[null,"B2.role.result","B2.role.evidence"],"templateValues":["Structural Role",null,null]}]},{"section":"B","subsection":"B3","headers":["Finding","Result","Evidence"],"rows":[{"labels":["Pattern Candidate","-","-"],"fields":[null,"B3.candidate.result","B3.candidate.evidence"],"templateValues":["Pattern Candidate",null,null]},{"labels":["Primary Ge Ju","-","-"],"fields":[null,"B3.primary.result","B3.primary.evidence"],"templateValues":["Primary Ge Ju",null,null]},{"labels":["Pattern Type","-","-"],"fields":[null,"B3.type.result","B3.type.evidence"],"templateValues":["Pattern Type",null,null]},{"labels":["Formation Conditions","-","-"],"fields":[null,"B3.formation.result","B3.formation.evidence"],"templateValues":["Formation Conditions",null,null]},{"labels":["Supporting Conditions","-","-"],"fields":[null,"B3.supporting.result","B3.supporting.evidence"],"templateValues":["Supporting Conditions",null,null]},{"labels":["Breaking Conditions","-","-"],"fields":[null,"B3.breaking.result","B3.breaking.evidence"],"templateValues":["Breaking Conditions",null,null]},{"labels":["Alternative Pattern","-","-"],"fields":[null,"B3.alt.result","B3.alt.evidence"],"templateValues":["Alternative Pattern",null,null]},{"labels":["Competing Pattern","-","-"],"fields":[null,"B3.competing.result","B3.competing.evidence"],"templateValues":["Competing Pattern",null,null]},{"labels":["Pattern Integrity","-","-"],"fields":[null,"B3.integrity.result","B3.integrity.evidence"],"templateValues":["Pattern Integrity",null,null]},{"labels":["Final Determination","-","-"],"fields":[null,"B3.final.result","B3.final.evidence"],"templateValues":["Final Determination",null,null]}]},{"section":"B","subsection":"B4","headers":["Ten God","Position","Visibility","Root Status","Relation to Yue Ling","Structural Role"],"rows":[{"labels":["-","-","-","-","-","-"],"fields":["B4.row1.god","B4.row1.pos","B4.row1.vis","B4.row1.root","B4.row1.yueLing","B4.row1.role"],"templateValues":[null,null,null,null,null,null]}]},{"section":"B","subsection":"B5","headers":["Finding","Result","Evidence"],"rows":[{"labels":["Root Presence","-","-"],"fields":[null,"B5.presence.result","B5.presence.evidence"],"templateValues":["Root Presence",null,null]},{"labels":["Primary Root","-","-"],"fields":[null,"B5.primary.result","B5.primary.evidence"],"templateValues":["Primary Root",null,null]},{"labels":["Secondary Root","-","-"],"fields":[null,"B5.secondary.result","B5.secondary.evidence"],"templateValues":["Secondary Root",null,null]},{"labels":["Root Strength","-","-"],"fields":[null,"B5.strength.result","B5.strength.evidence"],"templateValues":["Root Strength",null,null]},{"labels":["Structural Contribution","-","-"],"fields":[null,"B5.contrib.result","B5.contrib.evidence"],"templateValues":["Structural Contribution",null,null]},{"labels":["Structural Importance","-","-"],"fields":[null,"B5.importance.result","B5.importance.evidence"],"templateValues":["Structural Importance",null,null]}]},{"section":"B","subsection":"B6","headers":["Relation","Participating Stems","Condition","Structural Effect"],"rows":[{"labels":["-","-","-","-"],"fields":["B6.row1.rel","B6.row1.stems","B6.row1.cond","B6.row1.effect"],"templateValues":[null,null,null,null]}]},{"section":"B","subsection":"B7","headers":["Relation","Participating Branches","Condition","Structural Effect"],"rows":[{"labels":["-","-","-","-"],"fields":["B7.row1.rel","B7.row1.branches","B7.row1.cond","B7.row1.effect"],"templateValues":[null,null,null,null]}]},{"section":"B","subsection":"B8","headers":["Finding","Result","Conditions","Evidence"],"rows":[{"labels":["Combination Candidate","-","-","-"],"fields":[null,"B8.candidate.result","B8.candidate.cond","B8.candidate.evidence"],"templateValues":["Combination Candidate",null,null,null]},{"labels":["Transformation Condition","-","-","-"],"fields":[null,"B8.condition.result","B8.condition.cond","B8.condition.evidence"],"templateValues":["Transformation Condition",null,null,null]},{"labels":["Seasonal Support","-","-","-"],"fields":[null,"B8.seasonal.result","B8.seasonal.cond","B8.seasonal.evidence"],"templateValues":["Seasonal Support",null,null,null]},{"labels":["Obstruction","-","-","-"],"fields":[null,"B8.obstruct.result","B8.obstruct.cond","B8.obstruct.evidence"],"templateValues":["Obstruction",null,null,null]},{"labels":["Transformation Status","-","-","-"],"fields":[null,"B8.status.result","B8.status.cond","B8.status.evidence"],"templateValues":["Transformation Status",null,null,null]}]},{"section":"B","subsection":"B9","headers":["Finding","Result","Evidence"],"rows":[{"labels":["Configuration","-","-"],"fields":[null,"B9.config.result","B9.config.evidence"],"templateValues":["Configuration",null,null]},{"labels":["Participating Factors","-","-"],"fields":[null,"B9.factors.result","B9.factors.evidence"],"templateValues":["Participating Factors",null,null]},{"labels":["Formation Condition","-","-"],"fields":[null,"B9.formation.result","B9.formation.evidence"],"templateValues":["Formation Condition",null,null]},{"labels":["Breaking Condition","-","-"],"fields":[null,"B9.breaking.result","B9.breaking.evidence"],"templateValues":["Breaking Condition",null,null]},{"labels":["Configuration Status","-","-"],"fields":[null,"B9.status.result","B9.status.evidence"],"templateValues":["Configuration Status",null,null]}]},{"section":"B","subsection":"B10","headers":["Element","Structural Role","Supporting Role","Draining Role","Controlling Role","Status"],"rows":[{"labels":["Wood (Mu / 木)","-","-","-","-","-"],"fields":[null,"B10.wood.role","B10.wood.sup","B10.wood.drain","B10.wood.control","B10.wood.status"],"templateValues":["Wood (Mu / 木)",null,null,null,null,null]},{"labels":["Fire (Huo / 火)","-","-","-","-","-"],"fields":[null,"B10.fire.role","B10.fire.sup","B10.fire.drain","B10.fire.control","B10.fire.status"],"templateValues":["Fire (Huo / 火)",null,null,null,null,null]},{"labels":["Earth (Tu / 土)","-","-","-","-","-"],"fields":[null,"B10.earth.role","B10.earth.sup","B10.earth.drain","B10.earth.control","B10.earth.status"],"templateValues":["Earth (Tu / 土)",null,null,null,null,null]},{"labels":["Metal (Jin / 金)","-","-","-","-","-"],"fields":[null,"B10.metal.role","B10.metal.sup","B10.metal.drain","B10.metal.control","B10.metal.status"],"templateValues":["Metal (Jin / 金)",null,null,null,null,null]},{"labels":["Water (Shui / 水)","-","-","-","-","-"],"fields":[null,"B10.water.role","B10.water.sup","B10.water.drain","B10.water.control","B10.water.status"],"templateValues":["Water (Shui / 水)",null,null,null,null,null]}]},{"section":"B","subsection":"B11","headers":["Finding","Source","Channel","Receiver","Continuity / Breakpoint","Status"],"rows":[{"labels":["-","-","-","-","-","-"],"fields":["B11.row1.finding","B11.row1.source","B11.row1.channel","B11.row1.receiver","B11.row1.break","B11.row1.status"],"templateValues":[null,null,null,null,null,null]}]},{"section":"B","subsection":"B12","headers":["Finding","Result","Evidence","Status"],"rows":[{"labels":["Structural Support","-","-","-"],"fields":[null,"B12.support.result","B12.support.evidence","B12.support.status"],"templateValues":["Structural Support",null,null,null]},{"labels":["Structural Drain","-","-","-"],"fields":[null,"B12.drain.result","B12.drain.evidence","B12.drain.status"],"templateValues":["Structural Drain",null,null,null]},{"labels":["Structural Control","-","-","-"],"fields":[null,"B12.control.result","B12.control.evidence","B12.control.status"],"templateValues":["Structural Control",null,null,null]},{"labels":["Element Deficit","-","-","-"],"fields":[null,"B12.deficit.result","B12.deficit.evidence","B12.deficit.status"],"templateValues":["Element Deficit",null,null,null]},{"labels":["Element Excess","-","-","-"],"fields":[null,"B12.excess.result","B12.excess.evidence","B12.excess.status"],"templateValues":["Element Excess",null,null,null]},{"labels":["Overall Structural Balance","-","-","-"],"fields":[null,"B12.overall.result","B12.overall.evidence","B12.overall.status"],"templateValues":["Overall Structural Balance",null,null,null]}]},{"section":"B","subsection":"B13.1","headers":["Requirement","Result","Status"],"rows":[{"labels":["Day Master Strength Resolved","-","-"],"fields":[null,"B13_1.dmStrength.result","B13_1.dmStrength.status"],"templateValues":["Day Master Strength Resolved",null,null]},{"labels":["Ge Ju Resolved","-","-"],"fields":[null,"B13_1.geJu.result","B13_1.geJu.status"],"templateValues":["Ge Ju Resolved",null,null]},{"labels":["Seasonal Condition Resolved","-","-"],"fields":[null,"B13_1.seasonal.result","B13_1.seasonal.status"],"templateValues":["Seasonal Condition Resolved",null,null]},{"labels":["Structural Conflict Resolved","-","-"],"fields":[null,"B13_1.conflict.result","B13_1.conflict.status"],"templateValues":["Structural Conflict Resolved",null,null]},{"labels":["Special Structure Resolved","-","-"],"fields":[null,"B13_1.special.result","B13_1.special.status"],"templateValues":["Special Structure Resolved",null,null]},{"labels":["Methodology Resolved","-","-"],"fields":[null,"B13_1.method.result","B13_1.method.status"],"templateValues":["Methodology Resolved",null,null]},{"labels":["Determination Gate","-","-"],"fields":[null,"B13_1.determinationStatus.result","B13_1.determinationStatus.status"],"templateValues":["Determination Gate",null,null]}]},{"section":"B","subsection":"B13.2","headers":["Finding","Result","Evidence","Status"],"rows":[{"labels":["Determination Method","-","-","-"],"fields":[null,"B13_2.method.result","B13_2.method.evidence","B13_2.method.status"],"templateValues":["Determination Method",null,null,null]},{"labels":["Yong Shen (Yong Shen / 用神)","-","-","-"],"fields":[null,"B13_2.yongShen.result","B13_2.yongShen.evidence","B13_2.yongShen.status"],"templateValues":["Yong Shen (Yong Shen / 用神)",null,null,null]},{"labels":["Xi Shen (Xi Shen / 喜神)","-","-","-"],"fields":[null,"B13_2.xiShen.result","B13_2.xiShen.evidence","B13_2.xiShen.status"],"templateValues":["Xi Shen (Xi Shen / 喜神)",null,null,null]},{"labels":["Ji Shen (Ji Shen / 忌神)","-","-","-"],"fields":[null,"B13_2.jiShen.result","B13_2.jiShen.evidence","B13_2.jiShen.status"],"templateValues":["Ji Shen (Ji Shen / 忌神)",null,null,null]}]},{"section":"B","subsection":"B14","headers":["Finding","Required Element / Condition","Dependency Type","Status"],"rows":[{"labels":["Primary Dependency","-","-","-"],"fields":[null,"B14.primary.req","B14.primary.type","B14.primary.status"],"templateValues":["Primary Dependency",null,null,null]},{"labels":["Secondary Dependency","-","-","-"],"fields":[null,"B14.secondary.req","B14.secondary.type","B14.secondary.status"],"templateValues":["Secondary Dependency",null,null,null]},{"labels":["Structural Vulnerability","-","-","-"],"fields":[null,"B14.vuln.req","B14.vuln.type","B14.vuln.status"],"templateValues":["Structural Vulnerability",null,null,null]}]},{"section":"B","subsection":"B15","headers":["Priority","Structural Factor","Reason","Status"],"rows":[{"labels":["1","-","-","-"],"fields":[null,"B15.1.factor","B15.1.reason","B15.1.status"],"templateValues":["1",null,null,null]},{"labels":["2","-","-","-"],"fields":[null,"B15.2.factor","B15.2.reason","B15.2.status"],"templateValues":["2",null,null,null]},{"labels":["3","-","-","-"],"fields":[null,"B15.3.factor","B15.3.reason","B15.3.status"],"templateValues":["3",null,null,null]},{"labels":["4","-","-","-"],"fields":[null,"B15.4.factor","B15.4.reason","B15.4.status"],"templateValues":["4",null,null,null]}]},{"section":"B","subsection":"B16","headers":["Finding","Result","Status"],"rows":[{"labels":["Primary Structural Finding","-","-"],"fields":[null,"B16.primary.result","B16.primary.status"],"templateValues":["Primary Structural Finding",null,null]},{"labels":["Secondary Structural Finding","-","-"],"fields":[null,"B16.secondary.result","B16.secondary.status"],"templateValues":["Secondary Structural Finding",null,null]},{"labels":["Structural Strength","-","-"],"fields":[null,"B16.strength.result","B16.strength.status"],"templateValues":["Structural Strength",null,null]},{"labels":["Structural Weakness","-","-"],"fields":[null,"B16.weakness.result","B16.weakness.status"],"templateValues":["Structural Weakness",null,null]},{"labels":["Key Ge Ju Configuration","-","-"],"fields":[null,"B16.geJu.result","B16.geJu.status"],"templateValues":["Key Ge Ju Configuration",null,null]},{"labels":["Main Structural Dependency","-","-"],"fields":[null,"B16.dependency.result","B16.dependency.status"],"templateValues":["Main Structural Dependency",null,null]},{"labels":["Yong Shen Result","-","-"],"fields":[null,"B16.yongShen.result","B16.yongShen.status"],"templateValues":["Yong Shen Result",null,null]},{"labels":["Overall Structural Determination","-","-"],"fields":[null,"B16.overall.result","B16.overall.status"],"templateValues":["Overall Structural Determination",null,null]}]},{"section":"B","subsection":"B17","headers":["Finding","Result","Status"],"rows":[{"labels":["Structural Consistency","-","-"],"fields":[null,"B17.consistency.result","B17.consistency.status"],"templateValues":["Structural Consistency",null,null]},{"labels":["Ge Ju Verification","-","-"],"fields":[null,"B17.geJu.result","B17.geJu.status"],"templateValues":["Ge Ju Verification",null,null]},{"labels":["Shen Qiang / Shen Ruo Verification","-","-"],"fields":[null,"B17.strength.result","B17.strength.status"],"templateValues":["Shen Qiang / Shen Ruo Verification",null,null]},{"labels":["Yong Shen Verification","-","-"],"fields":[null,"B17.yongShen.result","B17.yongShen.status"],"templateValues":["Yong Shen Verification",null,null]},{"labels":["Unresolved Items","-","-"],"fields":[null,"B17.unresolved.result","B17.unresolved.status"],"templateValues":["Unresolved Items",null,null]}]},{"section":"C","subsection":"C1","headers":["Analysis","Result"],"rows":[{"labels":["Heavenly Stem Dynamics (Tian Gan / 天干)","-"],"fields":[null,"C1.stemDynamics"],"templateValues":["Heavenly Stem Dynamics (Tian Gan / 天干)",null]},{"labels":["Earthly Branch Dynamics (Di Zhi / 地支)","-"],"fields":[null,"C1.branchDynamics"],"templateValues":["Earthly Branch Dynamics (Di Zhi / 地支)",null]},{"labels":["Ten Gods Dynamics (Shi Shen / 十神)","-"],"fields":[null,"C1.godDynamics"],"templateValues":["Ten Gods Dynamics (Shi Shen / 十神)",null]},{"labels":["Temporal Manifestation / Tou Qing (Tou Qing / 透清)","-"],"fields":[null,"C1.touQing"],"templateValues":["Temporal Manifestation / Tou Qing (Tou Qing / 透清)",null]}]},{"section":"C","subsection":"C2","headers":["Analysis","Result"],"rows":[{"labels":["Combination / Assembly (He / Hui / 合 / 会)","-"],"fields":[null,"C2.combination"],"templateValues":["Combination / Assembly (He / Hui / 合 / 会)",null]},{"labels":["Transformation (Hua / 化)","-"],"fields":[null,"C2.transformation"],"templateValues":["Transformation (Hua / 化)",null]},{"labels":["Clash (Chong / 冲)","-"],"fields":[null,"C2.clash"],"templateValues":["Clash (Chong / 冲)",null]},{"labels":["Punishment / Harm / Break (Xing / Hai / Po / 刑 / 害 / 破)","-"],"fields":[null,"C2.punishHarm"],"templateValues":["Punishment / Harm / Break (Xing / Hai / Po / 刑 / 害 / 破)",null]},{"labels":["Conflict / Competition","-"],"fields":[null,"C2.conflict"],"templateValues":["Conflict / Competition",null]}]},{"section":"C","subsection":"C3","headers":["Analysis","Result"],"rows":[{"labels":["Generating / Draining / Controlling Response (Sheng / Xie / Ke / 生 / 泄 / 克)","-"],"fields":[null,"C3.shengXieKe"],"templateValues":["Generating / Draining / Controlling Response (Sheng / Xie / Ke / 生 / 泄 / 克)",null]},{"labels":["Root Activation & Support (Gen Qi / 根气)","-"],"fields":[null,"C3.genQi"],"templateValues":["Root Activation & Support (Gen Qi / 根气)",null]},{"labels":["Qi Flow Response (Qi Liu / 气流)","-"],"fields":[null,"C3.qiLiu"],"templateValues":["Qi Flow Response (Qi Liu / 气流)",null]},{"labels":["Structural Dependency Response","-"],"fields":[null,"C3.dependency"],"templateValues":["Structural Dependency Response",null]},{"labels":["Activation Response","-"],"fields":[null,"C3.activation"],"templateValues":["Activation Response",null]}]},{"section":"C","subsection":"C4","headers":["Analysis","Result"],"rows":[{"labels":["Structural Activation","-"],"fields":[null,"C4.activation"],"templateValues":["Structural Activation",null]},{"labels":["Structure Formation (Cheng Ge / 成格)","-"],"fields":[null,"C4.chengGe"],"templateValues":["Structure Formation (Cheng Ge / 成格)",null]},{"labels":["Structure Transformation / Change (Bian Ge / 变格)","-"],"fields":[null,"C4.bianGe"],"templateValues":["Structure Transformation / Change (Bian Ge / 变格)",null]},{"labels":["Structural Shift","-"],"fields":[null,"C4.shift"],"templateValues":["Structural Shift",null]},{"labels":["Useful God Response (Yong Shen / 用神)","-"],"fields":[null,"C4.yongShen"],"templateValues":["Useful God Response (Yong Shen / 用神)",null]},{"labels":["Favorable / Unfavorable God Response (Xi Shen / Ji Shen / 喜神 / 忌神)","-"],"fields":[null,"C4.xiJiShen"],"templateValues":["Favorable / Unfavorable God Response (Xi Shen / Ji Shen / 喜神 / 忌神)",null]}]},{"section":"C","subsection":"C5","headers":["Analysis","Result"],"rows":[{"labels":["Support / Obstruction","-"],"fields":[null,"C5.support"],"templateValues":["Support / Obstruction",null]},{"labels":["Balance Shift","-"],"fields":[null,"C5.balance"],"templateValues":["Balance Shift",null]},{"labels":["Dominant Temporal Influence","-"],"fields":[null,"C5.dominant"],"templateValues":["Dominant Temporal Influence",null]},{"labels":["Repeated Temporal Factor","-"],"fields":[null,"C5.repeated"],"templateValues":["Repeated Temporal Factor",null]}]},{"section":"C","subsection":"C6","headers":["Analysis","Result"],"rows":[{"labels":["Favorable / Unfavorable Response (Xi / Ji / 喜 / 忌)","-"],"fields":[null,"C6.xiJi"],"templateValues":["Favorable / Unfavorable Response (Xi / Ji / 喜 / 忌)",null]},{"labels":["Structure Formation (Cheng Ge / 成格)","-"],"fields":[null,"C6.chengGe"],"templateValues":["Structure Formation (Cheng Ge / 成格)",null]},{"labels":["Structure Transformation / Change (Bian Ge / 变格)","-"],"fields":[null,"C6.bianGe"],"templateValues":["Structure Transformation / Change (Bian Ge / 变格)",null]},{"labels":["Overall Temporal State","-"],"fields":[null,"C6.overall"],"templateValues":["Overall Temporal State",null]}]},{"section":"C","subsection":"C7","headers":["Evidence","Finding","Source / Basis"],"rows":[{"labels":["-","-","-"],"fields":["C7.row1.evidence","C7.row1.finding","C7.row1.source"],"templateValues":[null,null,null]},{"labels":["-","-","-"],"fields":["C7.row2.evidence","C7.row2.finding","C7.row2.source"],"templateValues":[null,null,null]},{"labels":["-","-","-"],"fields":["C7.row3.evidence","C7.row3.finding","C7.row3.source"],"templateValues":[null,null,null]},{"labels":["-","-","-"],"fields":["C7.row4.evidence","C7.row4.finding","C7.row4.source"],"templateValues":[null,null,null]},{"labels":["-","-","-"],"fields":["C7.row5.evidence","C7.row5.finding","C7.row5.source"],"templateValues":[null,null,null]}]}];

  function clone(v) {
    if (v === undefined) return null;
    if (v === null || typeof v !== 'object') return v;
    if (Array.isArray(v)) return v.map(clone);
    const o = {};
    Object.keys(v).forEach(k => { if (!k.startsWith('_')) o[k] = clone(v[k]); });
    return o;
  }

  function getByPath(obj, path) {
    if (!path || !obj) return undefined;
    const parts = String(path).replace(/\[(\d+)\]/g, '.$1').split('.').filter(Boolean);
    let cur = obj;
    for (const p of parts) {
      if (cur === null || cur === undefined) return undefined;
      if (!Object.prototype.hasOwnProperty.call(Object(cur), p)) return undefined;
      cur = cur[p];
    }
    return cur;
  }

  function normKey(s) {
    return String(s || '').toLowerCase()
      .replace(/[\/()]/g, ' ')
      .replace(/[^a-z0-9\u00C0-\uFFFF]+/g, ' ')
      .trim().replace(/\s+/g, '_');
  }

  const AI_NODE_LABELS = {
    A1: 'Client Profile & Calculation Parameters',
    A2: 'Subject Identification',
    A3: 'Calendar & Time Foundation',
    A4: 'Four Pillars',
    A5: 'Hidden Stems',
    A6: 'Day Master',
    A7: 'Month Command',
    A8: 'Five Elements Foundation',
    A9: 'Yin-Yang Balance',
    A10: 'Ten Gods Map',
    'A10.1': 'Ten Gods Mapping',
    'A10.2': 'Visible Ten Gods',
    'A10.3': 'Hidden Ten Gods',
    'A10.4': 'Ten Gods Presence Distribution',
    'A10.5': 'Ten Gods Position Matrix',
    A11: 'Core Root Foundation',
    A12: 'Classical & Derived References',
    'A12.1': 'Na Yin',
    'A12.2': 'Twelve Life Stages',
    'A12.3': 'Branch Emptiness',
    'A12.4': 'Shen Sha Registry',
    'A12.5': 'Natal Stem Interaction Registry',
    'A12.6': 'Natal Branch Interaction Registry',
    'A12.7': 'Transformation / Hua',
    'A12.8': 'Useful / Favorable / Unfavorable Gods',
    'A12.9': 'Pattern Foundation / Candidate',
    A13: 'Ming Gong & Tai Yuan',
    A14: 'Luck Pillars',
    'A14.1': 'Da Yun Foundation',
    'A14.2': 'Da Yun Sequence',
    'A14.3': 'Da Yun Derived Matrix',
    'A14.4': 'Da Yun Calculation Audit',
    A15: 'Core Chart Integrity',
    A16: 'Foundation Verification Notes',
    A17: 'Foundation Additional Notes',
    B1: 'Day Master Strength',
    B2: 'Yue Ling — Month Command',
    B3: 'Ge Ju — Structure / Pattern',
    B4: 'Ten Gods',
    B5: 'Root',
    B6: 'Heavenly Stem Relations',
    B7: 'Earthly Branch Relations',
    B8: 'Hua — Transformation',
    B9: 'Structural Configuration',
    B10: 'Five Elements',
    B11: 'Qi Flow',
    B12: 'Five Element Balance',
    B13: 'Yong Shen — Useful God',
    'B13.1': 'Determination Prerequisites',
    'B13.2': 'Determination',
    B14: 'Structural Dependency',
    B15: 'Structural Priority',
    B16: 'Structural Synthesis',
    B17: 'Classical Structural Verification',
    C1: 'Temporal Interaction',
    C2: 'Combination & Conflict',
    C3: 'Qi & Structural Response',
    C4: 'Structural Change',
    C5: 'Temporal Balance',
    C6: 'Temporal Determination',
    C7: 'Evidence & Verification'
  };

  function semanticSectionName(code) {
    return ({
      A: 'Foundation Master',
      B: 'Profile & Structure / Ge Ju',
      C: 'Temporal Dynamics'
    })[code] || code;
  }

  function internalIdentifier(value) {
    if (typeof value !== 'string') return false;
    return /^(?:BC-[A-Z0-9_-]+|QTBJ-[A-Z0-9_-]+|ZPZQ-[A-Z0-9_-]+|VER-[A-Z0-9_-]+|NOTE-[A-Z0-9_-]+|DY-AUDIT-[A-Z0-9_-]+|ZP-ROOT-HIER-[A-Z0-9_-]+|USEFUL_[A-Z0-9_-]+|DAY_MASTER_[A-Z0-9_-]+|CHART_PATTERN_[A-Z0-9_-]+|TRANSFORMATION_[A-Z0-9_-]+|FINAL-INTERNAL|INTERNAL_[A-Z0-9_-]+)$/i.test(value.trim());
  }

  function semanticCodeReplacement(code) {
    return AI_NODE_LABELS[code] || (code[0] === 'A' ? 'Foundation Master' : code[0] === 'B' ? 'Profile & Structure / Ge Ju' : 'Temporal Dynamics');
  }

  function replaceSemanticHandles(s) {
    // Replace already-scrubbed legacy phrases first so the AI-facing text never
    // accumulates labels such as "Foundation section.7".
    s = s.replace(/\bFoundation section\.(\d+(?:\.\d+)?)\b/gi, function (_, n) {
      return semanticCodeReplacement('A' + n);
    });
    s = s.replace(/\bStructure section\.(\d+(?:\.\d+)?)\b/gi, function (_, n) {
      return semanticCodeReplacement('B' + n);
    });
    s = s.replace(/\bTemporal section\.(\d+(?:\.\d+)?)\b/gi, function (_, n) {
      return semanticCodeReplacement('C' + n);
    });

    s = s.replace(/\bA1[–-]A17\b/gi, 'Foundation Master');
    s = s.replace(/\bB1[–-]B17\b/gi, 'Profile & Structure / Ge Ju');
    s = s.replace(/\bC1[–-]C7\b/gi, 'Temporal Dynamics');

    const codes = Object.keys(AI_NODE_LABELS).sort((a, b) => b.length - a.length);
    codes.forEach(code => {
      const escaped = code.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const pattern = new RegExp('(?<![A-Za-z0-9_])' + escaped + '(?![A-Za-z0-9_])', 'g');
      s = s.replace(pattern, semanticCodeReplacement(code));
    });

    s = s.replace(/\bA(?:1[0-7]|[1-9])(?:_\d+)?\b/gi, 'Foundation Master');
    s = s.replace(/\bB(?:1[0-7]|[1-9])(?:_\d+)?\b/gi, 'Profile & Structure / Ge Ju');
    s = s.replace(/\bC[1-7](?:_\d+)?\b/gi, 'Temporal Dynamics');
    s = s.replace(/\bT(?:0[1-9]|[1-5]\d)\b/gi, 'template table');
    return s;
  }

  function normalizeBilingualTerminology(text) {
    let s = String(text);
    const replacements = [
      [/\bYong Shen\s*\/\s*Useful God\s*\(用神\)/gi, 'Yong Shen / Useful God (用神)'],
      [/\bXi Shen\s*\/\s*Favorable God\s*\(喜神\)/gi, 'Xi Shen / Favorable God (喜神)'],
      [/\bJi Shen\s*\/\s*Unfavorable God\s*\(忌神\)/gi, 'Ji Shen / Unfavorable God (忌神)'],
      [/\bSupport-Suppress\b(?! \(扶抑\))/gi, 'Support & Suppression (扶抑)'],
      [/\bSupport & Suppression\b(?! \(扶抑\))/gi, 'Support & Suppression (扶抑)'],
      [/\bClimate Regulation\b(?! \(调候\))/gi, 'Climate Regulation (调候)'],
      [/\bDisease(?:\/| &)Medicine\b(?! \(病药\))/gi, 'Disease & Medicine (病药)'],
      [/\bCommunication(?: \/|\/)Bridging\b(?! \(通关\))/gi, 'Communication / Bridging (通关)'],
      [/\bFollowing the Dominant Qi\b(?! \(专旺\))/gi, 'Following the Dominant Qi (专旺)'],
      [/\bStrength & Weakness\b(?! \(旺衰\))/gi, 'Strength & Weakness (旺衰)'],
      [/\bYong Shen\b(?!\s*(?:\/|\(用神\)))/gi, 'Yong Shen / Useful God (用神)'],
      [/\bXi Shen\b(?! \(喜神\))/gi, 'Xi Shen / Favorable God (喜神)'],
      [/\bJi Shen\b(?! \(忌神\))/gi, 'Ji Shen / Unfavorable God (忌神)'],
      [/\bYang Ren Ge\b(?! \(阳刃格\))/gi, 'Yang Ren Pattern (阳刃格)'],
      [/\bYang Ren\b(?! \(阳刃\))/gi, 'Yang Ren (阳刃)'],
      [/\bFormation \/ Breaking \/ Rescue\b(?! \(成格\/败格\/救应\))/gi, 'Formation / Breaking / Rescue (成格/败格/救应)'],
      [/\bDay-Precise Seasonal Qi\b(?! \(人元司令分野\))/gi, 'Day-Precise Seasonal Qi (人元司令分野)'],
      [/\bMonth Command\b(?! \(月令\))/gi, 'Month Command (月令)'],
      [/\bMain Qi\b(?! \(本气\))/gi, 'Main Qi (本气)'],
      [/\bMiddle Qi\b(?! \(中气\))/gi, 'Middle Qi (中气)'],
      [/\bResidual Qi\b(?! \(余气\))/gi, 'Residual Qi (余气)'],
      [/\bStem Exposure\b(?! \(透干\))/gi, 'Stem Exposure (透干)']
    ];
    replacements.forEach(function ([pattern, replacement]) { s = s.replace(pattern, replacement); });
    return s;
  }

  function classicalRuleMeaning(id) {
    const reg = (typeof window !== 'undefined' && window.PENGGILAS_BC_RULES) ? window.PENGGILAS_BC_RULES : null;
    if (!reg) return null;
    const all = Object.keys(reg.B || {}).concat(Object.keys(reg.C || {}));
    for (const key of all) {
      const r = reg.B[key] || reg.C[key];
      if (r && r.id === id) {
        const label = r.english || r.hanzi || r.pinyin || null;
        return label ? (r.hanzi ? label + ' (' + r.hanzi + ')' : label) : null;
      }
    }
    return null;
  }

  function classicalSourceMeaning(id) {
    const srcs = (typeof window !== 'undefined' && window.PENGGILAS_BC_SOURCES && Array.isArray(window.PENGGILAS_BC_SOURCES.sources))
      ? window.PENGGILAS_BC_SOURCES.sources : [];
    const direct = srcs.find(s => s && s.id === id);
    if (direct) return direct.hanzi ? direct.english + ' (' + direct.hanzi + ')' : direct.english;
    const fallback = {
      ZPZQ: 'Zi Ping Zhen Quan (子平真诠)',
      QTBJ: 'Qiong Tong Bao Jian (穷通宝鉴)',
      DTT: 'Di Tian Sui (滴天髓)',
      SMTH: 'San Ming Tong Hui (三命通会)',
      YHZP: 'Yuan Hai Zi Ping (渊海子平)'
    };
    return fallback[id] || null;
  }

  function replaceInternalIdentifiers(s) {
    s = s.replace(/\bBC-[A-Z0-9_-]+\b/gi, function(id) {
      return classicalRuleMeaning(id) || 'Classical rule reference';
    });
    s = s.replace(/\b(?:ZPZQ|QTBJ|DTT|SMTH|YHZP)(?:-[A-Z0-9_-]+)?\b/gi, function(id) {
      const base = id.split('-')[0].toUpperCase();
      return classicalSourceMeaning(base) || 'Classical source';
    });
    s = s.replace(/\bN-[TBC][0-9]+\b/gi, '');
    return s.replace(/\s{2,}/g, ' ').trim();
  }

  function cleanForAI(value) {
    if (Array.isArray(value)) return value.map(cleanForAI);
    if (!value || typeof value !== 'object') {
      if (typeof value !== 'string') return value;
      let s = value;
      s = s.replace(/https?:\/\/\S+/gi, '');
      s = s.replace(/\bPENGGILAS\s+BaZi\s+Engine\s+V[0-9.]+-NODE-FIELD-SEPARATED\b/gi, 'PENGGILAS BaZi Engine');
      s = s.replace(/\bINTERNAL_PASS\b/g, 'internal consistency check');
      s = s.replace(/\bSOURCE_DERIVED\b/g, 'derived from a Classical source');
      s = s.replace(/\bSOURCE_SCREENED\b/g, 'screened against a Classical source');
      s = s.replace(/\bSUPERSEDED_BY_SOURCE_RULE\b/g, 'superseded by the applicable Classical source rule');
      s = s.replace(/\bCONFIGURED\b/g, 'specified by the applicable rule set');
      s = s.replace(/\bQTBJ(?:-[A-Z0-9_-]+)?\b/gi, 'Classical seasonal source');
      s = s.replace(/\bDTT(?:-[A-Z0-9_-]+)?\b/gi, 'Classical elemental source');
      s = s.replace(/\bZPZQ(?:-[A-Z0-9_-]+)?\b/gi, 'Classical Zi Ping source');
      s = s.replace(/\bBC-YONG-[A-Z0-9_-]+\b/gi, 'Classical method reference');
      s = s.replace(/\b(?:VER|NOTE)-[A-Z]-\d+\b/gi, '');
      s = s.replace(/\b(?:DY-AUDIT|ZP-ROOT-HIER)-\d+\b/gi, '');
      s = s.replace(/\b(?:F-0[1-4]|V-0\d|E-F0[1-4](?:-[A-Z0-9_-]+)?)\b/gi, '');
      s = s.replace(/\b(?:DET-CONTRACT-[0-9]+|FINAL-INTERNAL)\b/gi, '');
      s = s.replace(/\bHUA_BLOCKED_BY_CONFIGURED_OBSTRUCTION\b/g, 'Hua transformation blocked by a specified obstruction');
      s = s.replace(/\bINTERNAL VERIFIED\b/gi, 'engine consistency check; independent verification not performed');
      s = s.replace(/\bVERIFIED INTERNAL\b/gi, 'engine consistency check; independent verification not performed');
      s = s.replace(/\bRULE GAP\b/gi, 'rule coverage note');
      s = s.replace(/\bBAZI_DATA\b/gi, 'stem-and-branch reference data');
      s = s.replace(/\bCore A\b/gi, 'foundation calculation layer');
      s = s.replace(/\bCore B\b/gi, 'structural calculation layer');
      s = s.replace(/\bCore C\b/gi, 'temporal calculation layer');
      s = s.replace(/\bexternal rule layer\b/gi, 'applicable Classical rule set');
      s = s.replace(/\bproject Support-Suppress\b/gi, 'engine Support-Suppress');
      s = s.replace(/\bproject metric\b/gi, 'calculated indicator');
      s = s.replace(/\bproject-rule\b/gi, 'engine-rule');
      s = s.replace(/\bproject rules\b/gi, 'engine rules');
      s = s.replace(/\bproject owner\b/gi, 'engine convention');
      s = s.replace(/\bsystem clock\b/gi, 'calculation time reference');
      s = s.replace(/\bsource-status dependent\b/gi, 'final status depends on the applicable Classical source/rule');
      s = s.replace(/\bremains rule-status dependent\b/gi, 'remains dependent on the applicable Classical source/rule');
      s = s.replace(/\brule-status dependent\b/gi, 'depends on the applicable Classical source/rule');
      s = s.replace(/\bremains final status depends on the applicable Classical source\/rule\b/gi, 'remains dependent on the applicable Classical source/rule');
      s = s.replace(/\bconfigured\b/gi, 'specified');
      s = s.replace(/\bsource-screened\b/gi, 'screened against a Classical source');
      s = normalizeBilingualTerminology(s);
      s = replaceSemanticHandles(s);
      s = replaceInternalIdentifiers(s);
      return s.replace(/\bDERIVED METRIC\b/gi, 'calculated indicator').replace(/\bPROJECT METRIC\b/gi, 'calculated indicator').replace(/\ba engine metric\b/gi, 'a calculated indicator').replace(/\s{2,}/g, ' ').replace(/\s+([.;,])/g, '$1').trim();
    }
    const out = {};
    Object.keys(value).forEach(k => {
      const v = value[k];
      if (k.startsWith('_')) return;
      if (['claimId', 'evidenceIds', 'bindingId', 'ruleId', 'sourceId', 'auditId', 'id'].includes(k)) return;
      if (/^(?:verification\s+id|audit\s+id|evidence\s+id|source\s+id)$/i.test(k)) return;
      if (k === 'verifier' && typeof v === 'string' && /PenggilasCore|Core[A-C]/i.test(v)) return;
      const cleaned = cleanForAI(v);
      if (cleaned === null || cleaned === undefined) return;
      if (typeof cleaned === 'string' && !cleaned.trim()) return;
      if (Array.isArray(cleaned)) {
        const seen = new Set();
        const unique = cleaned.filter(item => {
          const key = typeof item === 'string' ? item.trim().toLowerCase() : JSON.stringify(item);
          if (!key || seen.has(key)) return false;
          seen.add(key);
          return true;
        });
        if (unique.length) out[k] = unique;
        return;
      }
      out[k] = cleaned;
    });
    return out;
  }

  function cellValue(masterResult, field, fallback) {
    if (field) {
      const v = getByPath(masterResult, field);
      return v === undefined ? null : cleanForAI(clone(v));
    }
    return fallback === undefined ? null : cleanForAI(clone(fallback));
  }

  function buildRows(masterResult, binding) {
    return binding.rows.map(row => {
      const out = {};
      row.labels.forEach((label, i) => {
        const header = binding.headers[i] || ('column_' + (i + 1));
        const field = row.fields[i] || null;
        const fallback = row.templateValues[i];
        const value = cellValue(masterResult, field, fallback);
        if (value === null || value === undefined) return;
        if (typeof value === 'string' && !value.trim()) return;
        out[header] = value;
      });
      return out;
    });
  }

  function buildSections(masterResult, template) {
    const sections = [];
    const templateSections = Array.isArray(template && template.sections) ? template.sections : [];
    const byCode = new Map(templateSections.map(s => [s.section_code, s]));
    const bySub = new Map(BINDINGS.map(b => [b.subsection, b]));

    function renderSubsections(master, subs) {
      return (subs || []).map(tsub => {
        const b = bySub.get(tsub.subsection_code);
        const node = { title: tsub.subsection_title || tsub.subsection_code };
        if (b) {
          node.table = { headers: b.headers.slice(), rows: buildRows(master, b) };
        }
        if (Array.isArray(tsub.subsections) && tsub.subsections.length) {
          node.subsections = renderSubsections(master, tsub.subsections);
        }
        return node;
      });
    }

    ['A', 'B', 'C'].forEach(sectionCode => {
      const ts = byCode.get(sectionCode) || {};
      sections.push({
        title: ts.section_title || semanticSectionName(sectionCode),
        subsections: renderSubsections(masterResult, ts.subsections || [])
      });
    });
    return sections;
  }

  function findFirst(masterResult, paths) {
    for (const p of paths) {
      const v = getByPath(masterResult, p);
      if (v !== undefined && v !== null) return clone(v);
    }
    return null;
  }

  function qualificationCodesFromText(value) {
    const text = value == null ? '' : String(value);
    const out = [];
    const add = code => { if (out.indexOf(code) === -1) out.push(code); };
    if (/project[- ]?(?:defined|specific)|calculated indicator|project metric/i.test(text)) add('PROJECT_DEFINED_METRIC');
    if (/no final Classical|no final .* determination|final .* not established|not a final Classical/i.test(text)) add('NO_FINAL_CLASSICAL_DETERMINATION');
    if (/source[- ]screened|screened against a Classical source/i.test(text)) add('SOURCE_SCREENED');
    if (/school[- ]specific|school-specific variants|school dependent/i.test(text)) add('SCHOOL_DEPENDENT');
    if (/rule (?:gap|coverage note)|rule-status dependent|depends on the applicable Classical source\/rule/i.test(text)) add('RULE_GAP_PRESENT');
    if (/no unique .*determination|no unique .* selected|multiple method|multi-method|conflicting method candidates/i.test(text)) add('NO_UNIQUE_DETERMINATION');
    if (/independent (?:external |Classical )?(?:cross-source )?verification (?:not performed|not established|remains incomplete)|external .*verification: not performed/i.test(text)) add('INDEPENDENT_VERIFICATION_NOT_PERFORMED');
    return out;
  }

  function qualificationFromClaim(claim, evidence, confidence) {
    const values = [];
    const collect = v => { if (v !== undefined && v !== null) values.push(v); };
    collect(claim && claim.outcome);
    collect(claim && claim.scope);
    collect(claim && claim.status);
    collect(claim && claim.blockingConditions && claim.blockingConditions.join(' '));
    (evidence || []).forEach(e => { collect(e && e.detail); collect(e && e.status); });
    collect(confidence && confidence.basis);
    const codes = [];
    values.forEach(v => qualificationCodesFromText(v).forEach(c => { if (codes.indexOf(c) === -1) codes.push(c); }));
    if (claim && claim.status === 'MULTI_METHOD' && codes.indexOf('NO_UNIQUE_DETERMINATION') === -1) codes.push('NO_UNIQUE_DETERMINATION');
    if (claim && claim.status === 'CONFLICT' && codes.indexOf('NO_UNIQUE_DETERMINATION') === -1) codes.push('NO_UNIQUE_DETERMINATION');
    return codes;
  }

  function buildDeterminationChain(masterResult) {
    const contract = masterResult && masterResult._determinationContract;
    if (!contract || !contract.claims) return null;

    const sourceRegistry = root.PENGGILAS_BC_SOURCES && Array.isArray(root.PENGGILAS_BC_SOURCES.sources)
      ? root.PENGGILAS_BC_SOURCES.sources
      : [];
    const sourceName = function (id) {
      const found = sourceRegistry.find(function (source) { return source.id === id; });
      return found ? (found.english + ' (' + found.hanzi + ')') : null;
    };
    const semanticSection = function (value) {
      const s = String(value == null ? '' : value);
      if (/^A(?:1[0-7]|[1-9])(?:\.|$)/.test(s)) return 'Foundation Master';
      if (/^B(?:1[0-7]|[1-9])(?:\.|$)/.test(s)) return 'Profile & Structure / Ge Ju';
      if (/^C[1-7](?:\.|$)/.test(s)) return 'Temporal Dynamics';
      return s || null;
    };
    const semanticClaim = function (claimId, claim) {
      return claim && claim.claim ? claim.claim : String(claimId || 'Determination');
    };
    const ruleKey = function (link) {
      return String(link && (link.ruleKey || link.semanticName || link.hanzi || 'Classical Rule'));
    };
    const ruleName = function (link) {
      return link && (link.semanticName || link.hanzi) ? (link.semanticName || link.hanzi) : 'Classical Rule';
    };
    const evidenceKey = function (item) {
      return [semanticSection(item && item.source), item && item.field, item && item.detail, item && item.status].map(function (v) {
        return v == null ? '' : String(v);
      }).join('|');
    };
    const namesById = {};
    Object.keys(contract.claims).forEach(function (claimId) {
      namesById[claimId] = semanticClaim(claimId, contract.claims[claimId]);
    });
    const semanticClaimList = function (ids) {
      return (Array.isArray(ids) ? ids : []).map(function (id) { return namesById[id] || id; });
    };
    const semanticBuckets = function (buckets) {
      const out = {};
      Object.keys(buckets || {}).forEach(function (key) {
        out[key] = semanticClaimList(buckets[key]);
      });
      return out;
    };
    const replaceClaimIds = function (text) {
      let out = String(text == null ? '' : text);
      Object.keys(namesById).forEach(function (id) {
        out = out.split(id).join(namesById[id]);
      });
      return out;
    };

    const claims = [];
    const rules = [];
    const evidenceRecords = [];
    const ruleMap = new Map();
    const evidenceMap = new Map();

    Object.keys(contract.claims).forEach(function (claimId) {
      const claim = contract.claims[claimId] || {};
      const claimName = semanticClaim(claimId, claim);
      const chain = Array.isArray(claim.ruleChain) ? claim.ruleChain : [];
      const supportedRules = [];
      const claimEvidenceKeys = new Set();

      chain.forEach(function (link) {
        const key = ruleKey(link);
        const name = ruleName(link);
        if (supportedRules.indexOf(name) === -1) supportedRules.push(name);

        let rule = ruleMap.get(key);
        if (!rule) {
          rule = {
            rule: name,
            classical_sources: Array.isArray(link.sourceIds) ? link.sourceIds.map(sourceName).filter(Boolean) : [],
            supports_claims: [claimName],
            assessments: []
          };
          ruleMap.set(key, rule);
          rules.push(rule);
        } else {
          if (rule.supports_claims.indexOf(claimName) === -1) rule.supports_claims.push(claimName);
          const sources = Array.isArray(link.sourceIds) ? link.sourceIds.map(sourceName).filter(Boolean) : [];
          sources.forEach(function (src) {
            if (rule.classical_sources.indexOf(src) === -1) rule.classical_sources.push(src);
          });
        }

        const checks = link.conditionEvaluation && Array.isArray(link.conditionEvaluation.checks)
          ? link.conditionEvaluation.checks.map(function (check) {
              return {
                condition: check.name || null,
                status: check.status || null,
                observed: check.observed === undefined ? null : check.observed
              };
            })
          : [];
        const evidence = Array.isArray(link.actualChartEvidence)
          ? link.actualChartEvidence.map(function (item) {
              const normalized = {
                source: semanticSection(item.source),
                field: item.field || null,
                detail: item.detail === undefined ? null : item.detail,
                status: item.status || null
              };
              const detail = normalized.detail;
              const usable = detail !== null && detail !== undefined && (typeof detail !== 'string' || detail.trim() !== '') && !(typeof detail === 'string' && /^(NOT DETERMINED|NOT AVAILABLE|UNRESOLVED|NOT EXECUTED|null|undefined)$/i.test(detail.trim()));
              if (!usable) return null;
              const eKey = evidenceKey(normalized);
              claimEvidenceKeys.add(eKey);
              let record = evidenceMap.get(eKey);
              if (!record) {
                record = Object.assign({}, normalized, {
                  supports_claims: [claimName],
                  used_by_rules: [name]
                });
                evidenceMap.set(eKey, record);
                evidenceRecords.push(record);
              } else {
                if (record.supports_claims.indexOf(claimName) === -1) record.supports_claims.push(claimName);
                if (record.used_by_rules.indexOf(name) === -1) record.used_by_rules.push(name);
              }
              return normalized;
            }).filter(Boolean)
          : [];

        rule.assessments.push({
          claim: claimName,
          condition: link.condition || null,
          condition_evaluation: {
            status: link.conditionEvaluation && link.conditionEvaluation.status || 'NOT_EVALUATED',
            basis: link.conditionEvaluation && link.conditionEvaluation.basis || null,
            checks: checks
          },
          actual_chart_evidence: evidence,
          rule_result: link.ruleResult || null,
          challenge: link.challenge || null,
          adjudication: link.adjudication || null,
          cross_check: link.crossCheck || null,
          confidence: link.confidence || null
        });
      });

      const closure = contract.determination_state && contract.determination_state.closureRecords
        ? contract.determination_state.closureRecords[claimId]
        : null;
      const audit = contract.audits && contract.audits[claimId] ? contract.audits[claimId] : null;
      const crossCheck = contract.crossCheck && contract.crossCheck[claimId] ? contract.crossCheck[claimId] : null;
      const confidence = contract.confidence && contract.confidence[claimId] ? contract.confidence[claimId] : null;
      const open = claim.status !== 'FINAL';

      const directEvidenceIds = Array.isArray(claim.evidenceIds) ? claim.evidenceIds.filter(Boolean) : [];
      const directEvidence = Array.isArray(contract.evidence)
        ? contract.evidence.filter(function (record) { return record && directEvidenceIds.indexOf(record.id) !== -1; })
        : [];
      const resolvedEvidenceIds = directEvidence.map(function (record) { return record.id; }).filter(Boolean);
      const determinationStatus = claim.status || null;
      const verificationStatus = claim.verificationStatus || 'NOT_VERIFIED';
      claims.push({
        claim: claimName,
        status: determinationStatus,
        status_detail: {
          determination: determinationStatus,
          computation: claim.computationStatus || 'NOT_SUPPLIED',
          verification: verificationStatus
        },
        outcome: claim.outcome || null,
        supported_by_rules: supportedRules,
        verification_status: verificationStatus,
        authority_reconciliation: claim.authorityReconciliation || null,
        evidence_refs: resolvedEvidenceIds,
        evidence_count: resolvedEvidenceIds.length,
        open_state: open ? {
          status: claim.status || null,
          reason: closure ? closure.reason : 'The supplied determination remains open.',
          blocking_conditions: closure && Array.isArray(closure.blocking_conditions) ? closure.blocking_conditions : (claim.blockingConditions || []),
          source_basis: 'Authoritative source and determination contract; the interpreter may explain the open state but may not close it.'
        } : null,
        audit: audit ? {
          status: audit.status || null,
          detail: audit.detail || null,
          checks: audit.checks || []
        } : null,
        cross_check: crossCheck ? {
          status: crossCheck.status || null,
          detail: crossCheck.detail || null
        } : null,
        challenge: claim.challenge || null,
        confidence: confidence || null,
        qualification: qualificationFromClaim(claim, evidenceRecords.filter(function (e) { return e.supports_claims.indexOf(claimName) !== -1; }), confidence)
      });
    });

    const synthesis = contract.synthesis || {};
    const answer = contract.answer || {};
    const overallChallenge = contract.challenge || {};
    // Classical rule context is an index, not a second evidence store.
    // Detailed chart evidence already lives in evidence_records and is linked
    // to claims. Keeping only rule -> claim/source references prevents the
    // AI payload from duplicating the same conditions/evidence many times.
    const compactRuleContext = rules.map(function (rule) {
      return {
        rule: rule.rule,
        classical_sources: rule.classical_sources || [],
        supports_claims: rule.supports_claims || []
      };
    });

    return {
      pipeline: [
        'CLAIM', 'EVIDENCE', 'AUDIT', 'CROSS-CHECK',
        'CHALLENGE', 'SYNTHESIS', 'CONFIDENCE', 'ANSWER'
      ],
      purpose: 'Evidence-to-answer handoff for AI interpretation. Open B/C interpretation remains open when its source-owned determination is not closed.',
      claims: claims,
      evidence_records: evidenceRecords,
      classical_rule_context: compactRuleContext,
      audit: {
        status: Object.keys(contract.audits || {}).every(function (id) { return contract.audits[id] && contract.audits[id].status === 'PASS'; }) ? 'PASS' : 'OPEN',
        claim_audits: claims.map(function (c) { return { claim: c.claim, audit: c.audit }; })
      },
      cross_check: {
        claims: claims.map(function (c) { return { claim: c.claim, cross_check: c.cross_check }; }),
        overall: contract.verification ? {
          status: contract.verification.status || 'NOT_VERIFIED',
          scope: contract.verification.scope || null,
          note: contract.verification.note || null,
          sources: contract.verification.sources || [],
          meaning: contract.verification.status === 'NOT_VERIFIED'
            ? 'The overall independent external Classical verification gate is not fully closed; claim-specific cross-checks may still exist and remain scope-bound.'
            : 'Overall verification status applies only to the explicitly stated scope.'
        } : null
      },
      challenge: {
        status: overallChallenge.status || 'CLEAR',
        count: overallChallenge.count || 0,
        claims: claims.map(function (c) { return { claim: c.claim, challenge: c.challenge }; })
      },
      synthesis: {
        status: synthesis.status || null,
        final_claims: semanticClaimList(synthesis.finalClaimIds || (synthesis.stateBuckets && synthesis.stateBuckets.FINAL) || []),
        open_claims: semanticClaimList(synthesis.openDeterminationIds || []),
        unresolved_claims: semanticClaimList(synthesis.unresolvedClaimIds || []),
        multi_method_claims: semanticClaimList((synthesis.multiMethodClaimIds || (synthesis.stateBuckets && synthesis.stateBuckets.MULTI_METHOD) || [])),
        conflict_claims: semanticClaimList((synthesis.conflictClaimIds || (synthesis.stateBuckets && synthesis.stateBuckets.CONFLICT) || [])),
        provisional_claims: semanticClaimList((synthesis.provisionalClaimIds || (synthesis.stateBuckets && synthesis.stateBuckets.PROVISIONAL) || [])),
        candidate_claims: semanticClaimList((synthesis.candidateClaimIds || (synthesis.stateBuckets && synthesis.stateBuckets.CANDIDATE) || [])),
        state_buckets: semanticBuckets(synthesis.stateBuckets || {}),
        rule: synthesis.rule || null
      },
      confidence: {
        claims: claims.map(function (c) { return { claim: c.claim, confidence: c.confidence }; }),
        overall: answer.confidence || null
      },
      answer: {
        status: answer.status || null,
        confidence: answer.confidence || null,
        text: replaceClaimIds(answer.text || '')
      }
    };
  }

  function buildCandidateRelations(masterResult) {
    const B13 = masterResult && masterResult.B13_2 ? masterResult.B13_2 : null;
    const B1 = masterResult && masterResult.B1 ? masterResult.B1 : null;
    if (!B13) return { status: 'NOT DETERMINED', candidates: [], source: null };

    const candidates = [];
    const candidateXi = Array.isArray(B13._candidateXiShenElements) ? B13._candidateXiShenElements.filter(Boolean) : [];
    const candidateJi = Array.isArray(B13._candidateJiShenElements) ? B13._candidateJiShenElements.filter(Boolean) : [];
    const candidateYong = Array.isArray(B13._candidateYongShenElements) ? B13._candidateYongShenElements.filter(Boolean) : [];

    if (candidateYong.length || candidateXi.length || candidateJi.length) {
      candidates.push({
        method: 'Support-Suppress (扶抑)',
        status: 'CANDIDATE',
        condition: 'Upstream Day-Master strength branch is source-closed for this candidate set.',
        yong_shen: candidateYong,
        xi_shen: candidateXi,
        ji_shen: candidateJi
      });
    }

    // Preserve the concrete Support-Suppress branches even when strength is
    // still unresolved. These are conditional candidates, not a determination.
    // They are generated from the same element relationships already used by
    // Core B; no new adjudication rule is introduced here.
    if (B1 && B1._strengthClass === 'UNRESOLVED') {
      const dm = B1.dayMasterElement || (B1.dayMaster && B1.dayMaster.element) || null;
      const wealth = B1._wealthElem || null;
      const resource = B1._resourceElem || null;
      const output = B1._outputElem || null;
      const officer = B1._officerElem || null;
      if (wealth && resource && dm) {
        candidates.push({
          method: 'Support-Suppress (扶抑)',
          status: 'CANDIDATE',
          condition: 'If the unresolved Day-Master strength branch closes as STRONG.',
          yong_shen: [wealth],
          xi_shen: [wealth],
          ji_shen: [resource, dm]
        });
      }
      if (output && wealth && officer && dm) {
        candidates.push({
          method: 'Support-Suppress (扶抑)',
          status: 'CANDIDATE',
          condition: 'If the unresolved Day-Master strength branch closes as WEAK.',
          yong_shen: [dm],
          xi_shen: [dm],
          ji_shen: [output, wealth, officer]
        });
      }
    }

    const methodCandidates = B13.methodCandidates && Array.isArray(B13.methodCandidates.result)
      ? B13.methodCandidates.result
      : [];
    methodCandidates.forEach(function (item) {
      if (!item || item.status !== 'CANDIDATE' || !item.candidate) return;
      const c = item.candidate;
      candidates.push({
        method: item.method || 'Classical method candidate',
        status: 'CANDIDATE',
        condition: item.basis || null,
        yong_shen: c.element ? [c.element] : [],
        stem_candidate: c.stem || null,
        hanzi: c.hanzi || null
      });
    });

    return {
      status: candidates.length ? 'CANDIDATE' : 'NOT DETERMINED',
      candidates: candidates,
      source: 'Existing MasterResult candidate branches only; candidates remain conditional and are never selected by the mapper.'
    };
  }

  function determinationStatusEnvelope(masterResult, claimId, computationPaths) {
    const contract = masterResult && masterResult._determinationContract;
    const claim = contract && contract.claims ? contract.claims[claimId] : null;
    const determination = claim && claim.status ? claim.status : null;
    const raw = findFirst(masterResult, computationPaths || []);
    const computation = ['CALCULATED', 'DERIVED', 'SCREENED'].indexOf(String(raw || '').toUpperCase()) !== -1 ? raw : 'NOT_SUPPLIED';
    const verification = claim && claim.verificationStatus ? claim.verificationStatus : 'NOT_VERIFIED';
    return {
      determination: determination,
      computation: computation,
      verification: verification
    };
  }

  function buildDeterminations(masterResult) {
    return cleanForAI({
      day_master_strength: {
        analytical_context: 'Natal structural assessment',
        result: findFirst(masterResult, ['B13_1.dmStrength.result', 'B1.strength']),
        status: determinationStatusEnvelope(masterResult, 'DAY_MASTER_STRENGTH', ['B13_1.dmStrength.status', 'B1.status']),
        evidence: findFirst(masterResult, ['B1.strengthEvidence', 'B1.evidence'])
      },
      chart_pattern: {
        analytical_context: 'Natal structural assessment',
        result: findFirst(masterResult, ['B3.primary.result', 'B3.primaryPattern', 'B3.result']),
        status: determinationStatusEnvelope(masterResult, 'CHART_PATTERN', ['B3.primary.status', 'B3.status']),
        evidence: findFirst(masterResult, ['B3.primary.evidence', 'B3.evidence'])
      },
      transformation_following: {
        analytical_context: 'Natal chart transformation / following assessment',
        result: findFirst(masterResult, ['A12_7.row1.result', 'A12_7.row1.finding', 'B8.result']),
        status: determinationStatusEnvelope(masterResult, 'TRANSFORMATION_FOLLOWING', ['A12_7.row1.status', 'B8.status']),
        evidence: findFirst(masterResult, ['A12_7.row1.evidence', 'B8.evidence'])
      },
      useful_element: {
        analytical_context: 'Natal structural determination',
        yong_shen: findFirst(masterResult, ['B13_2.yongShen.result']),
        xi_shen: findFirst(masterResult, ['B13_2.xiShen.result']),
        ji_shen: findFirst(masterResult, ['B13_2.jiShen.result']),
        method: findFirst(masterResult, ['B13_2.method.result']),
        candidate_relations: buildCandidateRelations(masterResult),
        status: {
          yong_shen: determinationStatusEnvelope(masterResult, 'USEFUL_ELEMENT', ['B13_2.yongShen.status']),
          xi_shen: determinationStatusEnvelope(masterResult, 'USEFUL_ELEMENT', ['B13_2.xiShen.status']),
          ji_shen: determinationStatusEnvelope(masterResult, 'USEFUL_ELEMENT', ['B13_2.jiShen.status'])
        },
        evidence: {
          yong_shen: findFirst(masterResult, ['B13_2.yongShen.evidence']),
          xi_shen: findFirst(masterResult, ['B13_2.xiShen.evidence']),
          ji_shen: findFirst(masterResult, ['B13_2.jiShen.evidence'])
        }
      }
    });
  }

  function buildSubject(masterResult) {
    return cleanForAI({
      name: findFirst(masterResult, ['A2.name']),
      chart_id: findFirst(masterResult, ['A1.chartId']),
      sex: findFirst(masterResult, ['A2.sex']),
      civil_date: findFirst(masterResult, ['A2.civilDate']),
      civil_time: findFirst(masterResult, ['A2.civilTime']),
      location: findFirst(masterResult, ['A2.location'])
    });
  }

  function countCoverage(masterResult) {
    let total = 0, supplied = 0;
    BINDINGS.forEach(b => b.rows.forEach(r => r.fields.forEach(f => {
      if (!f) return;
      total++;
      if (getByPath(masterResult, f) !== undefined) supplied++;
    })));
    return { template_fields: total, supplied_fields: supplied, missing_fields: total - supplied };
  }

  function buildAIPresentationJSON(masterResult, aiTemplate) {
    if (!masterResult || typeof masterResult !== 'object') throw new Error('masterResult is required');

    const template = aiTemplate && typeof aiTemplate === 'object' ? aiTemplate : {};
    const output = {
      metadata: {
        document_type: 'BaZi_AI_Input',
        schema_version: template.schema_version || '1.0.0',
        source_of_truth: 'MasterResult',
        projection: 'TEMPLATE_BOUND_SEMANTIC_PROJECTION',
        standalone: true,
        rules: 'Values are projected from the supplied MasterResult. This JSON does not perform BaZi calculation or determination.',
        analytical_flow: 'Foundation establishes facts → Structure establishes the natal configuration → Temporal Dynamics applies time-based interactions to that established structure.',
        coverage: countCoverage(masterResult)
      },
      ai_instruction: clone(AI_INSTRUCTION),
      status_contract: clone(template.ai_status_contract || STATUS_CONTRACT),
      subject: buildSubject(masterResult),
      determinations: buildDeterminations(masterResult),
      determination_chain: cleanForAI(buildDeterminationChain(masterResult)),
      sections: buildSections(masterResult, template)
    };

    return output;
  }

  // Compatibility name for existing callers.
  function buildMachineReadableJSON(masterResult, options) {
    const template = options && options.aiTemplate ? options.aiTemplate : null;
    return buildAIPresentationJSON(masterResult, template);
  }

  function validateMachineReadableJSON(doc) {
    const violations = [];
    if (!doc || typeof doc !== 'object') violations.push('document is not an object');
    if (!doc.sections || !Array.isArray(doc.sections) || doc.sections.length !== 3) violations.push('sections must contain Foundation, Structure, Temporal');
    const text = JSON.stringify(doc || {});
    if (/\b(?:F-0[1-4]|V-0\d|E-F0\d|QTBJ|DTT|ZPZQ|SMTH|YHZP|BC-[A-Z0-9_-]+)\b/i.test(text)) violations.push('internal audit/source/rule identifier leaked');
    if (/\b(?:N-[TBC][0-9]+|VER-[A-Z0-9_-]+|NOTE-[A-Z0-9_-]+|DY-AUDIT-[A-Z0-9_-]+)\b/i.test(text)) violations.push('internal engine/audit identifier leaked');
    if (/\b(?:A(?:1[0-7]|[1-9])(?:_\d+)?|B(?:1[0-7]|[1-9])(?:_\d+)?|C[1-7](?:_\d+)?)\b/.test(text)) violations.push('internal A/B/C binding identifier leaked');
    if (/\bT-?(?:0[1-9]|[1-5]\d)\b/i.test(text)) violations.push('internal table identifier leaked');
    return { pass: violations.length === 0, violations };
  }

  const api = { buildAIPresentationJSON, buildMachineReadableJSON, validateMachineReadableJSON };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.PenggilasJSONMapper = api;
})(typeof window !== 'undefined' ? window : globalThis);
