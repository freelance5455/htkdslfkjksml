# PENGGILAS — MASTER RESULT PRODUCTION ARCHITECTURE
## ONE AUTHORITATIVE MASTER RESULT

**Status:** Production architecture contract  
**Scope:** Wiring/data-flow only. This document does not introduce or redefine any BaZi formula, Classical rule, precedence, or calculation method.

---

## 1. Authoritative architecture

The production architecture is:

```text
INPUT
  │
  ▼
┌───────────────────────────────────────────────────────────────┐
│                         ENGINE PIPELINE                       │
│                                                               │
│  Core A        → Foundation / A1–A17                          │
│  Rule Registry → declarative B/C rule contract
  Core B        → Structure / B1–B17                           │
│  Determination → B/C adjudication contract + A12.8 projection │
│  Rule Registry → C rule contract
  Core C        → Temporal Dynamics / C1–C7                    │
│                                                               │
│  data/*        → rules, evidence, sources, state matrices     │
│  engine/*      → calendar/time/location calculation support   │
└──────────────────────────────┬────────────────────────────────┘
                               │
                               ▼
                ╔══════════════════════════════╗
                ║  ONE AUTHORITATIVE          ║
                ║      window.masterResult    ║
                ║                              ║
                ║  A1–A17                     ║
                ║  B1–B17                     ║
                ║  _determinationContract    ║
                ║  C1–C7                     ║
                ║  runtime provenance        ║
                ╚══════════════════════════════╝
                               │
                  final result event / read-only handoff
                               │
              ┌────────────────┴─────────────────┐
              │                                  │
              ▼                                  ▼
      HUMAN RESULT PATH                    AI RESULT PATH
              │                                  │
              ▼                                  ▼
   app.js → BAZI_MASTER_RESULT        ui/report/report.js
              │                                  │
              ▼                                  ├── loads template/ai-result-template.json
   template/result-template.js        │
              │                        ▼
              ▼                 core/json-mapper.js
   template/result-template.html        │
                                       ▼
                                  AI JSON output
                                       │
                                       ▼
                                  External LLM
```

### Core rule

> **There is exactly one authoritative runtime result object: `window.masterResult`.**
>
> Core A, Core B, Determination, and Core C progressively populate the **same object**. They do not create independent competing result authorities.

The word **progressively** is important: `MasterResult` is not four separate snapshots. It is one object whose authoritative contents are completed in engine order and then handed to presentation consumers.

---

## 2. Correct interpretation of the two diagrams

The following simplified model is valid as a conceptual summary:

```text
INPUT
  ↓
ENGINE
  ├── A1–A17
  ├── B1–B17
  ├── interpretation / determination
  └── C1–C7
  ↓
ONE AUTHORITATIVE MasterResult
  ↓
  ├── Human presentation
  └── AI presentation
```

The following is the **more accurate implementation model**:

```text
INPUT
  ↓
Core A
  ↓
SAME window.masterResult
  ↓
Core B
  ├── reads A from same masterResult
  ├── consumes B rule plan from data/rules/classical_rules_B_C.js
  └── publishes B + authoritative A12.9 projection
  ↓
SAME window.masterResult
  ↓
Determination
  ├── reads A/B evidence
  ├── builds _determinationContract
  └── publishes authoritative A12.8 projection
  ↓
SAME window.masterResult
  ↓
Core C
  ├── reads authoritative A/B/determination state
  ├── consumes C rule plan from data/rules/classical_rules_B_C.js
  └── publishes C1–C7
  ↓
FINAL ENGINE-PASS MASTER RESULT
  ↓
       ┌───────────────────────────────┐
       │                               │
       ▼                               ▼
Human result path                  AI result path
       │                               │
       ▼                               ▼
app.js event handoff             report.js
       │                               │
       ▼                         mapper + template JSON
result-template.js                     │
       │                               ▼
       ▼                            AI JSON
HTML
```

This is the architecture to preserve in production.

---

## 3. Rule execution boundary

The B/C declarative rule registry is consumed through `data/rules/classical_rules_B_C.js` before the corresponding Core section executes. The registry itself owns the section contract, explicit aliases, preparation gate and required-rule check; no separate interpreter owns rule meaning or matrix projection.

`data/rules/classical_rule_evaluator.js` remains a post-execution evidence/trace layer. It is not the only connection between the rule registry and Core B/C.

The production invariant is:

```text
Rule Registry → Core B/C → MasterResult → Rule Evaluator
```

## 3. MasterResult ownership

### 3.1 Core A

Production file:

```text
core/coreA.js
```

Responsibilities:

- calculate Foundation A1–A17;
- initialize/populate `window.masterResult`;
- preserve engine execution/provenance metadata;
- establish the A-side inputs consumed by later stages.

Core A does **not** wait for or call Core B to construct its own foundation result.

### 3.2 Core B

Production file:

```text
core/coreB.js
```

Responsibilities:

- consume the A result already present in `window.masterResult`;
- calculate Structure B1–B17;
- use configured rule/evidence/classical state data from `data/*`;
- own the authoritative projection:

```text
B3 Ge Ju
  ↓
A12.9 authoritative projection
```

The projection is written into the **same** `window.masterResult`.

`app.js` must not patch A12.9 after Core B.

### 3.3 Determination

Production file:

```text
core/determination.js
```

Responsibilities:

- consume available A/B evidence;
- construct `_determinationContract`;
- preserve explicit determination states such as `FINAL`, `PROVISIONAL`, `CANDIDATE`, `UNRESOLVED`, `MULTI_METHOD`, and `CONFLICT`;
- own the authoritative projection:

```text
USEFUL_ELEMENT determination
  ↓
A12.8 authoritative projection
```

Again, this is written into the **same** `window.masterResult`.

The determination layer must never close an open gate merely to satisfy presentation.

### 3.4 Core C

Production file:

```text
core/coreC.js
```

Responsibilities:

- consume the already-established A/B/determination result;
- calculate Temporal Dynamics C1–C7;
- preserve determination state and provenance;
- write C into the same `window.masterResult`.

Core C does not create a competing B or A authority.

---

## 4. Engine support files are inside the architecture

### `engine/*`

These are calculation-support modules used by the engine pipeline:

```text
engine/calendar.js
engine/jieqi.js
engine/location.js
engine/lunar.js
engine/solar.js
```

They are **not output authorities**. Their values flow into Core A/B/C calculations and ultimately into `MasterResult`.

### `data/*`

These remain engine/data support and are not moved into UI:

```text
data/classical_rule_coverage.js
data/determination-rules.js
data/global_classical_state_matrix.js
data/rules/classical_rule_evaluator.js
data/rules/classical_rules_B_C.js
data/sources/classical_sources_B_C.js
data/evidence/closure_signal_contract.js
data/evidence/runtime_evidence_normalizer.js
data/evidence/execution_signature.js
```

Their architectural role is:

```text
Core B / Determination / Core C
        ↑
        │
 data/rules
 data/evidence
 data/sources
 state matrices
```

They support execution and evidence/provenance. They do not become a second `MasterResult`.

---

## 5. Application shell: orchestration only

Production file:

```text
app.js
```

The production calculation sequence is:

```text
receiveInputData()
  ↓
triggerCalculation()
  ↓
Core A.calculate()
  ↓
Core B.calculate()
  ↓
Determination.calculate()
  ↓
Core C.calculate()
  ↓
FINAL window.masterResult
  ↓
BAZI_MASTER_RESULT_READY
```

`app.js` is allowed to:

- receive input;
- invoke engine stages in the defined order;
- dispatch the completed result event;
- store/broadcast a reference to the completed result.

`app.js` is **not allowed** to:

- recalculate BaZi;
- adjudicate B/C determinations;
- create a second result authority;
- patch A12.8;
- patch A12.9;
- select a winner between competing determinations.

The local variable in `app.js` that receives the event detail is only a shell reference to the completed result. It is not a second calculation source.

---

## 6. Human HTML production path

Production files:

```text
ui/chart/chart.js
template/result-template.js
template/result-template.html
template/result-template.css
ui/report/report.js
ui/report/report.html
```

The authoritative flow is:

```text
window.masterResult
       ↓
BAZI_MASTER_RESULT_READY
       ↓
app.js
       ↓
BAZI_MASTER_RESULT broadcast
       ↓
template/result-template.js
       ↓
resolvePath(masterResult, bindingPath)
       ↓
template/result-template.html
       ↓
Human-readable HTML
```

`result-template.js` is presentation/binding logic. It must not modify `masterResult` or perform independent BaZi calculation.

`result-template.html` is structure, not calculation authority.

`result-template.css` is visual presentation only.

`ui/chart/chart.js` owns the chart-only projection from authoritative `MasterResult` into a local chart view-model and renders that view-model. The projection must not mutate `MasterResult`, calculate BaZi, adjudicate determinations, or become a source of truth for A1–A17, B1–B17, Determination, or C1–C7.

---

## 7. AI JSON production path — corrected

The accurate production path is **not**:

```text
MasterResult → json-mapper → ai-result-template.json → AI JSON
```

because `ai-result-template.json` is a template/contract input, not a generated result.

The actual production path is:

```text
FINAL window.masterResult
        │
        ▼
ui/report/report.js
        │
        ├──────────────► template/ai-result-template.json
        │                         │
        │                         │ template contract
        ▼                         ▼
core/json-mapper.js ◄──────── template
        │
        ▼
AI JSON output
        │
        ▼
External LLM
```

Production files:

```text
ui/report/report.js
core/json-mapper.js
template/ai-result-template.json
core/AI_JSON_CONTRACT.md
```

`json-mapper.js` is read-only with respect to `MasterResult`.

It must not:

- calculate BaZi;
- adjudicate a determination;
- choose a winning candidate;
- convert `UNRESOLVED`/`CANDIDATE`/`PROVISIONAL`/`MULTI_METHOD`/`CONFLICT` into `FINAL`;
- mutate the source `MasterResult`.

The mapper's job is projection and semantic cleaning for the AI-facing contract.

---

## 8. Template contract

The production output contract is represented by:

```text
draft_template_bazi.docx
a.k.a. DRAFT_TEMPLATE_BAZI_CONTRACT.md
```

Its analytical structure is:

```text
A. FOUNDATION MASTER       A1–A17
B. PROFILE & STRUCTURE     B1–B17
C. TEMPORAL DYNAMICS       C1–C7
```

Production result ownership is therefore:

```text
MasterResult
├── A1–A17
├── B1–B17
├── _determinationContract
└── C1–C7
```

The determination contract is engine provenance/semantic state carried by the same result object; it is not a fourth user-facing BaZi section.

---

## 9. Complete production file map

### Entry / shell

```text
index.html
app.js
style.css
bazi-data.js
```

### Engine calculation support

```text
engine/calendar.js
engine/jieqi.js
engine/location.js
engine/lunar.js
engine/solar.js
```

### Core authoritative calculation

```text
core/coreA.js
core/coreB.js
core/determination.js
core/coreC.js
ui/chart/chart.js
```

### Rule / evidence / source support

```text
data/classical_rule_coverage.js
data/determination-rules.js
data/global_classical_state_matrix.js
data/rules/classical_rule_evaluator.js
data/rules/classical_rules_B_C.js
data/sources/classical_sources_B_C.js
data/evidence/closure_signal_contract.js
data/evidence/runtime_evidence_normalizer.js
data/evidence/execution_signature.js
```

### Human result presentation

```text
template/result-template.js
template/result-template.html
template/result-template.css
```

### AI result presentation

```text
ui/report/report.js
ui/report/report.html
ui/report/report.css
core/json-mapper.js
template/ai-result-template.json
```

### Other UI consumers of the same result

```text
ui/analysis/analysis.js
ui/analysis/analysis.html
ui/analysis/analysis.css
ui/chart/chart.js
ui/chart/chart.html
ui/chart/chart.css
ui/dayun/dayun.js
ui/dayun/dayun.html
ui/dayun/dayun.css
ui/input/input.js
ui/input/input.html
ui/input/input.css
```

These UI modules are consumers/projections. They are not alternative BaZi engines.

Assets are presentation resources only:

```text
asset/*
```

---

## 10. Final production architecture

```text
                              INPUT
                                │
                                ▼
                    ┌──────────────────────┐
                    │     ENGINE PIPELINE  │
                    │                      │
                    │ Core A   A1–A17      │
                    │ Core B   B1–B17      │
                    │ Determination        │
                    │ Core C   C1–C7       │
                    └──────────┬───────────┘
                               │
                               ▼
              ╔══════════════════════════════════╗
              ║ ONE AUTHORITATIVE MASTER RESULT  ║
              ║                                  ║
              ║ window.masterResult              ║
              ║ A1–A17                           ║
              ║ B1–B17                           ║
              ║ _determinationContract          ║
              ║ C1–C7                            ║
              ╚═══════════════╤══════════════════╝
                              │
                final read-only presentation handoff
                              │
                ┌─────────────┴──────────────┐
                │                            │
                ▼                            ▼
        HUMAN RESULT PATH              AI RESULT PATH
                │                            │
                ▼                            ▼
            app.js                    ui/report/report.js
                │                            │
                ▼                            ├── template/ai-result-template.json
 BAZI_MASTER_RESULT broadcast             │
                │                          ▼
                ▼                   core/json-mapper.js
 template/result-template.js              │
                │                          ▼
                ▼                       AI JSON
 template/result-template.html             │
                │                          ▼
                ▼                     External LLM
             HTML
```

### Non-negotiable invariant

```text
INPUT
  ↓
ENGINE
  ↓
ONE SAME AUTHORITATIVE window.masterResult
  ↓
READ-ONLY PROJECTIONS
  ├── Human HTML
  └── AI JSON
```

No production presentation layer is allowed to become an independent calculation authority.

---

## 11. What this architecture does NOT claim

This architecture does not claim that:

- every determination is always Classical-final;
- every evidence chain is externally verified;
- an AI model is allowed to resolve an open gate;
- presentation output can be used to repair upstream engine data;
- a template file is itself an engine;
- a projection is a new source of truth.

It claims only the production wiring and authority boundary:

> **Calculate once through the engine pipeline, complete one authoritative `MasterResult`, then project that result into human HTML and AI JSON without recalculation or adjudication downstream.**


## Claim authority and verification chain

`_determinationContract` is the authoritative adjudication chain for B/C claims. Its precedence is explicit: section result → closure gate → determination claim. The closure gate may weaken an open or ambiguous section result, but may never strengthen it.

Each claim carries traceability to non-empty chart evidence and executed supporting rules, followed by audit, cross-check, verification, synthesis, and overall answer. FINAL/HIGH are forbidden when the evidence or rule connection is absent. Verification is claim-scoped and reconciled into the overall verification state; internal cross-checking is not independent external verification.
