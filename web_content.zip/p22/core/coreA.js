/* ============================================================
   PENGGILAS BAZI — CORE A
   FOUNDATION MASTER (Section A — result-template.html)

   METODOLOGI : Classical Zi Ping (子平八字)
   TANGGUNG JAWAB:
     Menjadi KALKULATOR MURNI. Tidak melakukan interpretasi.
     Mengubah data mentah (input pengguna) menjadi Section A
     (A1–A11) sesuai kontrak field di template/result-template.html.

   SUMBER DATA / JALUR:
     rawInput (dari ui/input)
       -> engine/location.js   (geocoding + IANA timezone)
       -> engine/solar.js      (True Solar Time — LOCKED RULE)
       -> engine/jieqi.js      (Jie Qi / Zhong Qi sekitar tanggal)
       -> engine/calendar.js   (tanggal kalender lunar)
       -> engine/lunar.js      (pustaka lunar-javascript:
                                 Solar / Lunar / EightChar —
                                 mesin astronomis Empat Pilar)
       -> bazi-data.js         (BAZI_DATA — kamus statis:
                                 elemen, polaritas, Shi Shen, dsb)

   ATURAN YANG SUDAH DIKUNCI BERSAMA PENGGUNA:
     - Waktu lahir untuk perhitungan BaZi = TRUE SOLAR TIME
       (koreksi bujur + equation of time). Lihat A3.baziTime.

   ASUMSI YANG DIAMBIL (belum dikonfirmasi eksplisit — silakan
   koreksi jika sekolah BaZi yang dipakai berbeda):
     - EightChar "sect" dibiarkan pada default pustaka (sect 2 —
       varian 早子/晚子 "early zi hour": pilar hari ikut berganti
       pada pukul 23:00, bukan menunggu 00:00).
     - "Adjusted Weight (Post-Season)" pada A8 memakai pembobotan
       musiman umum: Wang x2.0, Xiang x1.5, Xiu x1.0, Qiu x0.5,
       Si x0.3 — dikalikan ke Raw Count. Ini konvensi deskriptif
       standar, bukan bagian dari struktur data resmi, dan mudah
       dipusatkan pada BAZI_DATA.projectConfig.seasonWeight.

   STATUS CAKUPAN:
     A1–A17 FOUNDATION COMPLETE. Core A produces the Foundation Master; Classical rule coverage is tracked separately;
     A12.4 Shen Sha memiliki audit trace, A13 Ming Gong/Tai Yuan memiliki
     calculation trace, dan A14 memisahkan precise engine age dari display bucket.
   ============================================================ */

(function (global) {
    "use strict";

    const CORE_A_VERSION = "V4.1-NODE-FIELD-SEPARATED";
    const PROJECT_CONFIG = BAZI_DATA.projectConfig;
    const PILLARS = PROJECT_CONFIG.pillarKeys;
    const PILLAR_LABEL = PROJECT_CONFIG.pillarLabels;
    const SHENG_CYCLE = PROJECT_CONFIG.shengCycle;
    const KE_CYCLE = PROJECT_CONFIG.keCycle;
    const SEASON_WEIGHT = PROJECT_CONFIG.seasonWeight;
    const PENGGILAS_EIGHTCHAR_SECT = PROJECT_CONFIG.eightCharSect;

    // NODE LAYER: internal execution IDs are deliberately different from
    // template fields A1..A17. Fields are output containers only.
    const NODE_DEPS_A = Object.freeze({
        "EXEC_A1": [], "EXEC_A2": [], "EXEC_A3": ["EXEC_A2"], "EXEC_A4": ["EXEC_A3"],
        "EXEC_A5": ["EXEC_A4"], "EXEC_A6": ["EXEC_A4"], "EXEC_A7": ["EXEC_A3","EXEC_A4"],
        "EXEC_A8": ["EXEC_A4","EXEC_A7"], "EXEC_A9": ["EXEC_A4"], "EXEC_A10": ["EXEC_A4","EXEC_A6"],
        "EXEC_A11": ["EXEC_A6","EXEC_A10"], "EXEC_A12": ["EXEC_A4","EXEC_A5","EXEC_A6","EXEC_A7"],
        "EXEC_A13": ["EXEC_A4","EXEC_A7"], "EXEC_A14": ["EXEC_A4","EXEC_A7"],
        "EXEC_A15": ["EXEC_A4","EXEC_A6","EXEC_A7","EXEC_A14"], "EXEC_A16": ["EXEC_A15","EXEC_A14"],
        "EXEC_A17": ["EXEC_A15","EXEC_A16"]
    });

    function runFoundationNodes(nodes) {
        const done = new Set();
        const values = {};
        const order = Object.keys(NODE_DEPS_A);
        order.forEach(function(id){
            const deps = NODE_DEPS_A[id] || [];
            const unresolved = deps.filter(function(d){ return !done.has(d); });
            if (unresolved.length) throw new Error("[PenggilasCoreA] Node dependency violation " + id + " <- " + unresolved.join(","));
            if (typeof nodes[id] !== "function") throw new Error("[PenggilasCoreA] Missing execution node: " + id);
            values[id] = nodes[id](values);
            done.add(id);
        });
        return { values: values, done: Array.from(done), dependencies: NODE_DEPS_A };
    }

    function pad2(n) {
        return String(n).padStart(2, "0");
    }

    function cap(s) {
        return s.charAt(0).toUpperCase() + s.slice(1);
    }

    function requireGlobals() {
        const missing = [];
        ["BAZI_DATA", "PenggilasLocation", "PenggilasSolar", "PenggilasJieQi",
            "PenggilasCalendar", "Solar"].forEach(function (name) {
            if (typeof global[name] === "undefined") missing.push(name);
        });
        if (missing.length) {
            throw new Error("[PenggilasCoreA] Modul belum termuat: " + missing.join(", "));
        }
    }

    function tenGodLabel(dayMasterHanzi, stemHanzi) {
        const code = BAZI_DATA.getTenGodByHanzi(dayMasterHanzi, stemHanzi);
        const info = code ? BAZI_DATA.tenGods[code] : null;
        return info ? (info.pinyin + " (" + info.hanzi + ")") : "-";
    }

    /* ============================================================
       DETEKSI INTERAKSI (He/Chong/Xing/Hai/Po/San He/Ban He/San Hui)
       ------------------------------------------------------------
       Fungsi privat modul ini — bukan file/engine terpisah. Aturan
       (mode co-occurrence/repetition, minMembers, dsb) dibaca dari
       bazi-data.js; fungsi ini murni MEMPROSES data registry, tidak
       menyimpan aturan sendiri. Kalkulator (Core A/B/C) tidak boleh
       bergantung pada file "engine" di luar A/B/C — jadi salinan
       yang sama juga ada di core/coreC.js untuk C2 (duplikasi kecil
       yang disengaja, demi masing-masing Core mandiri).
       ============================================================ */

    function uniqueBy(arr, keyFn) {
        const seen = new Set();
        const out = [];
        arr.forEach(function (item) {
            const k = keyFn(item);
            if (!seen.has(k)) { seen.add(k); out.push(item); }
        });
        return out;
    }

    function scanStems(entries) {
        const he = [], chong = [];
        for (let i = 0; i < entries.length; i++) {
            for (let j = i + 1; j < entries.length; j++) {
                const a = entries[i], b = entries[j];
                BAZI_DATA.wuHePairs.forEach(function (p) {
                    if ((a.key === p.pair[0] && b.key === p.pair[1]) || (a.key === p.pair[1] && b.key === p.pair[0])) {
                        he.push({ members: [a, b], element: p.element });
                    }
                });
                BAZI_DATA.stemChongPairs.forEach(function (p) {
                    if ((a.key === p[0] && b.key === p[1]) || (a.key === p[1] && b.key === p[0])) {
                        chong.push({ members: [a, b] });
                    }
                });
            }
        }
        return { he: he, chong: chong };
    }

    function scanBranches(entries) {
        const liuHe = [], sanHe = [], banHe = [], sanHui = [], chong = [], hai = [], po = [], xing = [];

        for (let i = 0; i < entries.length; i++) {
            for (let j = i + 1; j < entries.length; j++) {
                const a = entries[i], b = entries[j];
                BAZI_DATA.liuHePairs.forEach(function (p) {
                    if ((a.key === p.pair[0] && b.key === p.pair[1]) || (a.key === p.pair[1] && b.key === p.pair[0])) {
                        liuHe.push({ members: [a, b], element: p.element });
                    }
                });
                BAZI_DATA.chongPairs.forEach(function (p) {
                    if ((a.key === p[0] && b.key === p[1]) || (a.key === p[1] && b.key === p[0])) {
                        chong.push({ members: [a, b] });
                    }
                });
                BAZI_DATA.haiPairs.forEach(function (p) {
                    if ((a.key === p[0] && b.key === p[1]) || (a.key === p[1] && b.key === p[0])) {
                        hai.push({ members: [a, b] });
                    }
                });
                BAZI_DATA.poPairs.forEach(function (p) {
                    if ((a.key === p[0] && b.key === p[1]) || (a.key === p[1] && b.key === p[0])) {
                        po.push({ members: [a, b], relationClass: "SECONDARY_VARIANT" });
                    }
                });
            }
        }

        BAZI_DATA.sanHeGroups.forEach(function (group) {
            const present = entries.filter(function (e) { return group.branches.indexOf(e.key) !== -1; });
            const uniqueMembers = uniqueBy(present, function (e) { return e.key; });
            const fullCount = group.branches.length;
            if (uniqueMembers.length === fullCount) {
                sanHe.push({ members: present, uniqueKeys: uniqueMembers.map(function (m) { return m.key; }), element: group.element });
            } else if (uniqueMembers.length === fullCount - 1) {
                banHe.push({ members: present, uniqueKeys: uniqueMembers.map(function (m) { return m.key; }), element: group.element });
            }
        });

        BAZI_DATA.sanHuiGroups.forEach(function (group) {
            const present = entries.filter(function (e) { return group.branches.indexOf(e.key) !== -1; });
            const uniqueMembers = uniqueBy(present, function (e) { return e.key; });
            if (uniqueMembers.length === group.branches.length) {
                sanHui.push({ members: present, uniqueKeys: uniqueMembers.map(function (m) { return m.key; }), element: group.element });
            }
        });

        Object.keys(BAZI_DATA.xingGroups).forEach(function (groupKey) {
            const group = BAZI_DATA.xingGroups[groupKey];
            const minMembers = group.minMembers || 2;

            if (group.mode === "repetition") {
                group.branches.forEach(function (branchKey) {
                    const occurrences = entries.filter(function (e) { return e.key === branchKey; });
                    if (occurrences.length >= minMembers) {
                        xing.push({ groupKey: groupKey, name: group.name, members: occurrences, uniqueKeys: [branchKey] });
                    }
                });
                return;
            }

            const present = entries.filter(function (e) { return group.branches.indexOf(e.key) !== -1; });
            const uniqueMembers = uniqueBy(present, function (e) { return e.key; });
            if (uniqueMembers.length >= minMembers) {
                xing.push({ groupKey: groupKey, name: group.name, members: present, uniqueKeys: uniqueMembers.map(function (m) { return m.key; }) });
            }
        });

        return { liuHe: liuHe, sanHe: sanHe, banHe: banHe, sanHui: sanHui, chong: chong, hai: hai, po: po, xing: xing };
    }

    /* ============================================================
       1. RAW EIGHTCHAR EXTRACTION
       ============================================================ */

    // Pustaka lunar-javascript menamai pilar Jam sebagai "Time" (getTimeGan,
    // getTimeZhi, dst), bukan "Hour" — walau field kita tetap "hour" supaya
    // cocok dengan A4.hour / A5.hour / dst di template.
    const EC_METHOD_PREFIX = { year: "Year", month: "Month", day: "Day", hour: "Time" };

    function extractRawPillars(ec) {
        const raw = {};
        PILLARS.forEach(function (key) {
            const Cap = EC_METHOD_PREFIX[key];
            raw[key] = {
                ganHanzi: ec["get" + Cap + "Gan"](),
                zhiHanzi: ec["get" + Cap + "Zhi"](),
                hideGanHanzi: ec["get" + Cap + "HideGan"]() // array, urutan: [Main, (Middle), (Residual)]
            };
        });
        return raw;
    }

    /* ============================================================
       A1 — CLIENT PROFILE & CALCULATION PARAMETERS
       ============================================================ */

    function buildA1(rawInput, timestamp) {
        const chartId = "PGL-" +
            (rawInput.birthDate || "").replace(/-/g, "") + "-" +
            (rawInput.birthTime || "").replace(/:/g, "");

        return {
            analysisVersion: "PENGGILAS BaZi Engine " + CORE_A_VERSION,
            chartId: chartId,
            subjectId: (rawInput.name || "Unknown") + " / " + chartId,
            methodology: "Classical Zi Ping (子平八字)",
            dataSource: "PENGGILAS Registry (bazi-data.js) + lunar-javascript EightChar Engine",
            calcSystem: "Zi Ping — Four Pillars of Destiny (Ba Zi / 八字)",
            verifyMethod: "Automated internal cross-reference: astronomical engine vs static registry",
            verifyDate: timestamp,
            compilationStatus: "COMPILED",
            validityStatus: "VALID",
            completenessStatus: "FOUNDATION DATA COMPLETE (A1\u2013A17); CLASSICAL RULE COMPLETENESS PARTIAL / RULE-STATUS DRIVEN."
        };
    }

    /* ============================================================
       A2 — SUBJECT IDENTIFICATION
       ============================================================ */

    // PATCH (GILLAS G1): actualDateTime WAJIB dihitung eksplisit dari civil
    // time + UTC offset lokasi lahir, TIDAK boleh memakai civilDate.toISOString()
    // — karena objek JS Date dibangun via `new Date(y,m,d,h,mi)` yang
    // diinterpretasikan memakai timezone SISTEM/SERVER tempat kode berjalan
    // (bisa beda-beda tiap environment), bukan timezone lokasi lahir (WIB/
    // Asia Jakarta). Date.UTC() dipakai di sini justru KARENA ia selalu UTC-
    // murni, independen dari timezone sistem, lalu offset lokasi (dalam jam)
    // dikurangkan secara eksplisit satu kali.
    function computeUtcISOString(birthDate, birthTime, utcOffsetHours) {
        const [y, m, d] = birthDate.split("-").map(Number);
        const [h, mi] = birthTime.split(":").map(Number);
        const utcMs = Date.UTC(y, m - 1, d, h, mi, 0) - utcOffsetHours * 3600000;
        return new Date(utcMs).toISOString();
    }

    function normalizeGender(value) {
        if (typeof value !== "string") {
            throw new Error("[PenggilasCoreA] Gender must be Male or Female.");
        }
        const normalized = value.trim().toLowerCase();
        if (normalized === "male") return "Male";
        if (normalized === "female") return "Female";
        throw new Error("[PenggilasCoreA] Gender must be Male or Female.");
    }

    function buildA2(rawInput, location, civilDate, yearStemHanzi) {
        const stemInfo = BAZI_DATA.getStemByHanzi(yearStemHanzi);
        return {
            name: rawInput.name || "Unknown",
            sex: rawInput.gender || "Unknown",
            genderCode: (function () {
                if (!stemInfo || (rawInput.gender !== "Male" && rawInput.gender !== "Female")) return "-";
                const isMale = rawInput.gender === "Male";
                const isYang = stemInfo.polarity === "Yang";
                const fixedLabel = (isYang ? "Yang " : "Yin ") + (isMale ? "Nan" : "Nu") + " (" + (isYang ? "\u9633" : "\u9634") + (isMale ? "\u7537" : "\u5973") + ")";
                const direction = (isYang === isMale) ? "Shun / Forward" : "Ni / Reverse";
                return fixedLabel + " \u2192 Da Yun " + direction;
            })(),
            yinYang: stemInfo ? (stemInfo.polarity + " (Year Stem)") : "-",
            civilDate: rawInput.birthDate,
            civilTime: rawInput.birthTime,
            actualDateTime: computeUtcISOString(rawInput.birthDate, rawInput.birthTime, location.timeZone.utcOffset),
            location: [location.location.name, location.location.admin1, location.location.country]
                .filter(Boolean).join(", "),
            latitude: location.coordinates.latitude,
            longitude: location.coordinates.longitude,
            timeZone: location.timeZone.iana + " (UTC" +
                (location.timeZone.utcOffset >= 0 ? "+" : "") + location.timeZone.utcOffset + ")",
            meridian: location.referenceMeridian.degrees + "°",
            coordSource: location.coordinateSource.provider,
            dstStatus: location.dst ? (location.dst.isDst ? "DST Active" : "DST Inactive") : "N/A",
            calendarConv: "Gregorian (Civil Calendar) input, converted to Chinese Lunar Calendar"
        };
    }

    /* ============================================================
       A3 — CALENDAR & TIME FOUNDATION
       ============================================================ */

    function isoToDisplay(isoStr) {
        return isoStr ? isoStr.replace("T", " ") : "-";
    }

    function buildA3(solar, jieqi, calendar, baziDateObj, lunar) {
        const s = solar.solarTime;
        return {
            civilDateTime: solar.input.civilDateTime.year + "-" + pad2(solar.input.civilDateTime.month) + "-" +
                pad2(solar.input.civilDateTime.day) + " " + pad2(solar.input.civilDateTime.hour) + ":" +
                pad2(solar.input.civilDateTime.minute),
            localDateTime: s.localDateTime.year + "-" + pad2(s.localDateTime.month) + "-" +
                pad2(s.localDateTime.day) + " " + pad2(s.localDateTime.hour) + ":" + pad2(s.localDateTime.minute),
            longitude: solar.input.longitude + "°",
            meridianCorr: s.meridianCorrection.value.toFixed(2) + " " + s.meridianCorrection.unit,
            lmst: s.lmst.formatted,
            eot: s.equationOfTime.value.toFixed(3) + " " + s.equationOfTime.unit,
            trueSolarTime: s.trueSolarTime.formatted,
            baziTime: s.trueSolarTime.formatted + " (True Solar Time — locked rule)",
            dateBoundary: solar.dateBoundary.status +
                (solar.dateBoundary.dayShift ? " (" + solar.dateBoundary.dayShift + " day)" : ""),
            calendarSystem: calendar.calendarSystem.solar + " / " + calendar.calendarSystem.lunar,
            solarDate: baziDateObj.getFullYear() + "-" + pad2(baziDateObj.getMonth() + 1) + "-" + pad2(baziDateObj.getDate()),
            lunarDate: lunar.toString(),
            prevJieQi: jieqi.previousJieQi ? (jieqi.previousJieQi.name + " (" + jieqi.previousJieQi.pinyin + ")") : "-",
            prevJieQiTime: jieqi.previousJieQi ? isoToDisplay(jieqi.previousJieQi.iso) : "-",
            currZhongQi: jieqi.currentZhongQi ? (jieqi.currentZhongQi.name + " (" + jieqi.currentZhongQi.pinyin + ")") : "-",
            currZhongQiTime: jieqi.currentZhongQi ? isoToDisplay(jieqi.currentZhongQi.iso) : "-",
            nextJieQi: jieqi.nextJieQi ? (jieqi.nextJieQi.name + " (" + jieqi.nextJieQi.pinyin + ")") : "-",
            nextJieQiTime: jieqi.nextJieQi ? isoToDisplay(jieqi.nextJieQi.iso) : "-",
            solarMonth: jieqi.solarMonth && jieqi.solarMonth.name ? jieqi.solarMonth.name : "-",
            solarMonthBoundary: jieqi.solarMonthBoundary && jieqi.solarMonthBoundary.status ? jieqi.solarMonthBoundary.status : "-",
            calConvStatus: calendar.conversion.status
        };
    }

    /* ============================================================
       A4 — FOUR PILLARS
       ============================================================ */

    function buildA4(raw) {
        const result = {};
        PILLARS.forEach(function (key) {
            const stemInfo = BAZI_DATA.getStemByHanzi(raw[key].ganHanzi);
            const branchInfo = BAZI_DATA.getBranchByHanzi(raw[key].zhiHanzi);
            result[key] = {
                ganZhi: raw[key].ganHanzi + " " + raw[key].zhiHanzi,
                stem: (stemInfo ? stemInfo.pinyin : "?") + " (" + raw[key].ganHanzi + ")",
                stemElem: stemInfo ? stemInfo.element : "-",
                stemPol: stemInfo ? stemInfo.polarity : "-",
                branch: (branchInfo ? branchInfo.pinyin : "?") + " (" + raw[key].zhiHanzi + ")",
                branchElem: branchInfo ? branchInfo.element : "-",
                branchPol: branchInfo ? branchInfo.polarity : "-"
            };
        });
        return result;
    }

    /* ============================================================
       A5 — HIDDEN STEMS (Cang Gan)
       ============================================================ */

    function buildA5(raw) {
        const result = {};
        const SLOT = ["main", "mid", "res"];
        PILLARS.forEach(function (key) {
            const branchInfo = BAZI_DATA.getBranchByHanzi(raw[key].zhiHanzi);
            const hidden = BAZI_DATA.getHiddenStemsByHanzi(raw[key].zhiHanzi); // [{stem,qiPosition,element,polarity,...}]
            const dayMasterHanzi = raw.day.ganHanzi;

            const entry = {
                branch: (branchInfo ? branchInfo.pinyin : "?") + " (" + raw[key].zhiHanzi + ")",
                mainStem: "-", mainElem: "-", mainPol: "-", mainGod: "-",
                midStem: "-", midElem: "-", midPol: "-", midGod: "-",
                resStem: "-", resElem: "-", resPol: "-", resGod: "-"
            };

            hidden.forEach(function (hs, idx) {
                const slot = SLOT[idx] || ("extra" + idx);
                const hanzi = BAZI_DATA.getStem(hs.stem).hanzi;
                entry[slot + "Stem"] = hs.stem + " (" + hanzi + ")";
                entry[slot + "Elem"] = hs.element;
                entry[slot + "Pol"] = hs.polarity;
                entry[slot + "God"] = tenGodLabel(dayMasterHanzi, hanzi);
            });

            result[key] = entry;
        });
        return result;
    }

    /* ============================================================
       A6 — DAY MASTER
       ============================================================ */

    function buildA6(raw) {
        const stemInfo = BAZI_DATA.getStemByHanzi(raw.day.ganHanzi);
        return {
            dayStem: (stemInfo ? stemInfo.pinyin : "?") + " (" + raw.day.ganHanzi + ")",
            element: stemInfo ? stemInfo.element : "-",
            polarity: stemInfo ? stemInfo.polarity : "-",
            mandarinName: (stemInfo ? (stemInfo.pinyin + " / " + stemInfo.hanzi) : raw.day.ganHanzi),
            dayPillar: raw.day.ganHanzi + " " + raw.day.zhiHanzi,
            calcStatus: "CALCULATED",
            verifyStatus: "CALCULATED",
            // INTERNAL CONTRACT: Core B consumes the normalized Day Master element.
            // Keep this separate from template fields; it is not an A6 display field.
            _dayMasterElem: stemInfo ? stemInfo.element : null
        };
    }

    /* ============================================================
       A7 — MONTH COMMAND (Yue Ling)
       ============================================================ */

    function buildA7(raw, jieqi, baziInput) {
        const branchInfo = BAZI_DATA.getBranchByHanzi(raw.month.zhiHanzi);
        const branchKey = BAZI_DATA.hanziToBranchKey(raw.month.zhiHanzi);
        const hidden = BAZI_DATA.getHiddenStemsByHanzi(raw.month.zhiHanzi);
        const seasonElement = BAZI_DATA.seasonalState.seasonByMonthBranch[branchKey] || "-";

        const qiLabel = { Main: "mainQi", Middle: "midQi", Residual: "resQi" };
        const out = {
            monthBranch: (branchInfo ? branchInfo.pinyin : "?") + " (" + raw.month.zhiHanzi + ")",
            branchElement: branchInfo ? branchInfo.element : "-",
            branchPolarity: branchInfo ? branchInfo.polarity : "-",
            solarMonth: jieqi.solarMonth && jieqi.solarMonth.name ? jieqi.solarMonth.name : "-",
            detSolarTerm: jieqi.previousJieQi ? jieqi.previousJieQi.name : "-",
            solarTermTime: jieqi.previousJieQi ? isoToDisplay(jieqi.previousJieQi.iso) : "-",
            mainQi: "-", midQi: "-", resQi: "-",
            hiddenStemsComp: hidden.map(function (h) { return h.stem; }).join(", "),
            seasonPos: seasonElement + " season (governed by month branch)",
            monthCmdStatus: "CALCULATED",
            verifyStatus: "CALCULATED"
        };
        const dayMasterHanzi = raw.day.ganHanzi;
        hidden.forEach(function (h) {
            const key = qiLabel[h.qiPosition];
            if (key) {
                const hanzi = BAZI_DATA.getStem(h.stem).hanzi;
                out[key] = h.stem + " (" + hanzi + ")";
                out["_" + key + "God"] = tenGodLabel(dayMasterHanzi, hanzi);
                // PATCH (Audit Spec §13): field mesin murni (pinyin key + kode Shi
                // Shen), supaya pemanggil lain (B3, dst) tidak perlu regex-parsing
                // string tampilan "Ding (丁)" untuk memulihkan data mesin.
                out["_" + key + "StemKey"] = h.stem;
                out["_" + key + "GodCode"] = BAZI_DATA.getTenGod(BAZI_DATA.hanziToStemKey(dayMasterHanzi), h.stem);
            }
        });

        // SOURCE-LOCKED 人元司令分野 (Ren Yuan Si Ling Fen Ye).
        // Variant locked here: Zi Ping Zhen Quan table: 午月 = 丙10 / 己9 / 丁11, etc.
        // This is a day-precise Qi reference; it does NOT by itself replace the
        // Month-Command/Ge Ju framework or silently override 透干/会合 evidence.
        const renYuanByMonth = {
            "寅": [{stem:"Wu",days:7},{stem:"Bing",days:7},{stem:"Jia",days:16}],
            "卯": [{stem:"Jia",days:10},{stem:"Yi",days:20}],
            "辰": [{stem:"Yi",days:9},{stem:"Gui",days:3},{stem:"Wu",days:18}],
            "巳": [{stem:"Wu",days:5},{stem:"Geng",days:9},{stem:"Bing",days:16}],
            "午": [{stem:"Bing",days:10},{stem:"Ji",days:9},{stem:"Ding",days:11}],
            "未": [{stem:"Ding",days:9},{stem:"Yi",days:3},{stem:"Ji",days:18}],
            "申": [{stem:"Wu",days:10},{stem:"Ren",days:3},{stem:"Geng",days:17}],
            "酉": [{stem:"Geng",days:10},{stem:"Xin",days:20}],
            "戌": [{stem:"Xin",days:9},{stem:"Ding",days:3},{stem:"Wu",days:18}],
            "亥": [{stem:"Wu",days:7},{stem:"Jia",days:5},{stem:"Ren",days:18}],
            "子": [{stem:"Ren",days:10},{stem:"Gui",days:20}],
            "丑": [{stem:"Gui",days:9},{stem:"Xin",days:3},{stem:"Ji",days:18}]
        };
        const renSeq = renYuanByMonth[raw.month.zhiHanzi] || null;
        if (renSeq && jieqi.previousJieQi && jieqi.previousJieQi.iso && baziInput) {
            const start = Date.parse(jieqi.previousJieQi.iso + "Z");
            const current = Date.UTC(Number(baziInput.year), Number(baziInput.month)-1, Number(baziInput.day), Number(baziInput.hour), Number(baziInput.minute), Number(baziInput.second || 0));
            const elapsedDays = (current - start) / 86400000;
            const dayNo = Math.floor(elapsedDays) + 1;
            let cursor = 0;
            let commander = null;
            for (let i=0;i<renSeq.length;i++) {
                if (dayNo > cursor && dayNo <= cursor + renSeq[i].days) { commander = renSeq[i]; break; }
                cursor += renSeq[i].days;
            }
            if (commander) {
                const info = BAZI_DATA.getStem(commander.stem);
                const hanzi = info ? info.hanzi : "?";
                out.dayPreciseQi = commander.stem + " (" + hanzi + ")";
                out.dayPreciseQiGod = tenGodLabel(dayMasterHanzi, hanzi);
                out.dayPreciseDayNumber = dayNo;
                out.dayPreciseRule = "Zi Ping Zhen Quan (子平真诠) — 人元司令分野 table; source-specific day-precise reference only";
                out.dayPreciseStatus = "SOURCE-BASED";
                out.dayPreciseSource = "Zi Ping Zhen Quan (子平真诠) — 人元司令分野 table";
            }
        }
        out.dayPreciseTimeBasis = "True Solar Time — same resolved baziInput used for Four Pillars and Jie Qi; no civil-clock reversion";
        out.renYuanSourceProfile = "Zi Ping Zhen Quan (子平真诠) — Ren Yuan day-allocation table";
        out.renYuanSourceVariant = "Zi Ping Zhen Quan table: day-precise commander segmentation";
        out.renYuanReferenceNote = "Reference only: 三命通会《论人元司事》 uses a different day-allocation table; PENGGILAS does not blend the two tables.";
        out.renYuanStatus = out.dayPreciseStatus || "NOT DETERMINED";
        return out;
    }

    /* ============================================================
       A8 — FIVE ELEMENTS FOUNDATION
       ============================================================ */

    function buildA8(raw) {
        const ELEMENTS = ["Wood", "Fire", "Earth", "Metal", "Water"];
        const monthBranchKey = BAZI_DATA.hanziToBranchKey(raw.month.zhiHanzi);
        const monthSeasonElement = BAZI_DATA.seasonalState.seasonByMonthBranch[monthBranchKey];
        const stateBySeason = BAZI_DATA.seasonalState.stateBySeason[monthSeasonElement] || {};

        // Balikkan stateBySeason: {Wang:"Wood",...} -> per elemen dapat statenya
        const elementState = {};
        Object.keys(stateBySeason).forEach(function (stateId) {
            elementState[stateBySeason[stateId]] = stateId;
        });

        const tally = {};
        ELEMENTS.forEach(function (e) {
            tally[e] = { visible: 0, hidden: 0, branchPositions: [] };
        });

        PILLARS.forEach(function (key) {
            const stemInfo = BAZI_DATA.getStemByHanzi(raw[key].ganHanzi);
            if (stemInfo) tally[stemInfo.element].visible++;

            const branchInfo = BAZI_DATA.getBranchByHanzi(raw[key].zhiHanzi);
            if (branchInfo) tally[branchInfo.element].branchPositions.push(PILLAR_LABEL[key]);

            BAZI_DATA.getHiddenStemsByHanzi(raw[key].zhiHanzi).forEach(function (hs) {
                tally[hs.element].hidden++;
            });
        });

        const result = {};
        ELEMENTS.forEach(function (e) {
            const key = e.toLowerCase();
            // PATCH (Formula Spec Module A, A8): Raw Count = Visible + Hidden +
            // Branch Presence (tiga komponen), dan Branch Presence adalah COUNT
            // (angka), bukan daftar nama pilar. Sebelumnya Raw Count hanya
            // Visible+Hidden (branch presence dipisah sebagai info teks saja) —
            // ini bug nyata terhadap Formula Specification yang diberikan.
            const branchCount = tally[e].branchPositions.length;
            const raw_ = tally[e].visible + tally[e].hidden + branchCount;
            const state = elementState[e] || "-";
            const stateLabel = BAZI_DATA.seasonalState.states.find(function (s) { return s.id === state; });
            const weight = SEASON_WEIGHT[state] !== undefined ? +(raw_ * SEASON_WEIGHT[state]).toFixed(2) : raw_;
            result[key] = {
                visible: tally[e].visible,
                hidden: tally[e].hidden,
                branch: branchCount,
                raw: raw_,
                // PATCH (GILLAS G4): sisipkan multiplier eksplisit ke teks
                // "seasonal", supaya "Raw Count + Multiplier -> Adjusted Weight"
                // bisa direkonstruksi langsung dari output (template tidak
                // punya kolom multiplier terpisah, jadi disatukan di sini).
                seasonal: stateLabel ? (stateLabel.pinyin + " / " + stateLabel.hanzi + " (" + stateLabel.english + ") \u00d7" +
                    (SEASON_WEIGHT[state] !== undefined ? SEASON_WEIGHT[state].toFixed(1) : "1.0") + " — seasonal weighting indicator") : "-",
                weight: weight
            };
        });
        result._weightModel = "PENGGILAS seasonal weighting only: Raw Count × Wang/Xiang/Xiu/Qiu/Si multiplier; not a Classical 旺衰 determination.";
        return result;
    }

    /* ============================================================
       A9 — YIN-YANG BALANCE
       ============================================================ */

    function buildA9(raw) {
        let visYang = 0, visYin = 0, hidYang = 0, hidYin = 0;
        PILLARS.forEach(function (key) {
            const stemInfo = BAZI_DATA.getStemByHanzi(raw[key].ganHanzi);
            if (stemInfo) { stemInfo.polarity === "Yang" ? visYang++ : visYin++; }
            BAZI_DATA.getHiddenStemsByHanzi(raw[key].zhiHanzi).forEach(function (hs) {
                hs.polarity === "Yang" ? hidYang++ : hidYin++;
            });
        });
        const totalYang = visYang + hidYang;
        const totalYin = visYin + hidYin;
        // PATCH (Formula Spec Module A, A9): field ini adalah "Yang / Yin Ratio"
        // = Total Yang ÷ Total Yin (pembagian sungguhan), bukan format "6:4".
        // Zero handling: kalau Total Yin = 0, rasio tak terhingga secara
        // matematis — dilaporkan eksplisit, bukan error/NaN.
        const ratio = totalYin > 0
            ? (totalYang / totalYin).toFixed(2) + " (Yang " + totalYang + " : Yin " + totalYin + ")"
            : "\u221e \u2014 no Yin present (Yang " + totalYang + " : Yin 0)";
        return {
            visYang: visYang, visYin: visYin,
            hidYang: hidYang, hidYin: hidYin,
            totalYang: totalYang, totalYin: totalYin,
            ratio: ratio,
            method: "Visible = 4 Heavenly Stems. Hidden = all Cang Gan in the 4 Earthly Branches. Ratio = Total Yang \u00f7 Total Yin.",
            status: "CALCULATED"
        };
    }

    /* ============================================================
       A10 — TEN GODS MAP (10.1 – 10.5)
       ============================================================ */

    function buildA10(raw) {
        const dayMasterHanzi = raw.day.ganHanzi;
        const dayMasterElem = BAZI_DATA.getStemByHanzi(dayMasterHanzi).element;

        // 10.1 — all 10 stems vs Day Master
        const a10_1 = {};
        BAZI_DATA.stemOrder.forEach(function (pinyinKey) {
            const info = BAZI_DATA.heavenlyStems[pinyinKey];
            a10_1[pinyinKey.toLowerCase()] = {
                elem: info.element,
                pol: info.polarity,
                god: tenGodLabel(dayMasterHanzi, info.hanzi)
            };
        });

        // 10.2 — visible ten gods per pillar
        const a10_2 = {};
        PILLARS.forEach(function (key) {
            if (key === "day") {
                a10_2.day = { god: "Day Master (Self Reference)" };
                return;
            }
            const stemInfo = BAZI_DATA.getStemByHanzi(raw[key].ganHanzi);
            a10_2[key] = {
                stem: (stemInfo ? stemInfo.pinyin : "?") + " (" + raw[key].ganHanzi + ")",
                god: tenGodLabel(dayMasterHanzi, raw[key].ganHanzi)
            };
        });

        // 10.3 — hidden ten gods per pillar (main/mid/res) + kumpulkan frekuensi utk 10.4
        const a10_3 = {};
        const SLOT = ["main", "mid", "res"];
        const freq = {};
        Object.keys(BAZI_DATA.tenGods).forEach(function (code) { freq[code] = 0; });

        PILLARS.forEach(function (key) {
            const branchInfo = BAZI_DATA.getBranchByHanzi(raw[key].zhiHanzi);
            const hidden = BAZI_DATA.getHiddenStemsByHanzi(raw[key].zhiHanzi);
            const entry = { branch: (branchInfo ? branchInfo.pinyin : "?") + " (" + raw[key].zhiHanzi + ")", mainStem:"-", mainGod:"-", midStem:"-", midGod:"-", resStem:"-", resGod:"-" };
            hidden.forEach(function (hs, idx) {
                const slot = SLOT[idx] || ("extra" + idx);
                const hanzi = BAZI_DATA.getStem(hs.stem).hanzi;
                const code = BAZI_DATA.getTenGod(BAZI_DATA.hanziToStemKey(dayMasterHanzi), hs.stem);
                entry[slot + "Stem"] = hs.stem + " (" + hanzi + ")";
                entry[slot + "God"] = tenGodLabel(dayMasterHanzi, hanzi);
                if (code) freq[code]++;
            });
            a10_3[key] = entry;

            if (key !== "day") {
                const visCode = BAZI_DATA.getTenGod(BAZI_DATA.hanziToStemKey(dayMasterHanzi), BAZI_DATA.hanziToStemKey(raw[key].ganHanzi));
                if (visCode) freq[visCode]++;
            }
        });

        // 10.4 — frequency distribution
        const a10_4 = {};
        Object.keys(BAZI_DATA.tenGods).forEach(function (code) {
            const camel = code.charAt(0).toLowerCase() + code.slice(1);
            a10_4[camel] = {
                freq: freq[code] || 0,
                status: (freq[code] || 0) > 0 ? "PRESENT" : "ABSENT"
            };
        });

        // 10.5 — position matrix
        const a10_5 = {};
        PILLARS.forEach(function (key) {
            const stemInfo = BAZI_DATA.getStemByHanzi(raw[key].ganHanzi);
            const branchInfo = BAZI_DATA.getBranchByHanzi(raw[key].zhiHanzi);
            const hidden = BAZI_DATA.getHiddenStemsByHanzi(raw[key].zhiHanzi);
            const mainQi = hidden[0];
            a10_5[key] = {
                stem: (stemInfo ? stemInfo.pinyin : "?") + " (" + raw[key].ganHanzi + ")",
                stemGod: key === "day" ? "Day Master (Self Reference)" : tenGodLabel(dayMasterHanzi, raw[key].ganHanzi),
                branch: (branchInfo ? branchInfo.pinyin : "?") + " (" + raw[key].zhiHanzi + ")",
                mainQi: mainQi ? (mainQi.stem + " (" + BAZI_DATA.getStem(mainQi.stem).hanzi + ")") : "-",
                mainGod: mainQi ? tenGodLabel(dayMasterHanzi, BAZI_DATA.getStem(mainQi.stem).hanzi) : "-"
            };
        });

        return { A10_1: a10_1, A10_2: a10_2, A10_3: a10_3, A10_4: a10_4, A10_5: a10_5, _dayMasterElem: dayMasterElem };
    }

    /* ============================================================
       A11 — CORE ROOT FOUNDATION (Di Zhi Gen)
       ============================================================ */

    function buildA11(raw, dayMasterElem) {
        const resourceElem = Object.keys(SHENG_CYCLE).find(function (k) { return SHENG_CYCLE[k] === dayMasterElem; });
        const outputElem = SHENG_CYCLE[dayMasterElem];
        const wealthElem = KE_CYCLE[dayMasterElem];
        const officerElem = Object.keys(KE_CYCLE).find(function (k) { return KE_CYCLE[k] === dayMasterElem; });

        const rootPillars = [], rootHidden = [], primary = [], secondary = [];
        const presence = { resource: [], companion: [], output: [], wealth: [], officer: [] };

        PILLARS.forEach(function (key) {
            const hidden = BAZI_DATA.getHiddenStemsByHanzi(raw[key].zhiHanzi);
            hidden.forEach(function (hs) {
                const label = PILLAR_LABEL[key];
                if (hs.element === dayMasterElem) {
                    rootPillars.push(label);
                    rootHidden.push(hs.stem);
                    (hs.qiPosition === "Main" ? primary : secondary).push(label + ":" + hs.stem);
                    presence.companion.push(label);
                }
                if (hs.element === resourceElem) presence.resource.push(label);
                if (hs.element === outputElem) presence.output.push(label);
                if (hs.element === wealthElem) presence.wealth.push(label);
                if (hs.element === officerElem) presence.officer.push(label);
            });
        });

        function uniq(arr) { return Array.from(new Set(arr)); }
        function fmt(arr) { return arr.length ? uniq(arr).join(", ") : "None"; }

        return {
            rootPresence: rootPillars.length ? "Yes" : "No",
            branches: fmt(rootPillars),
            hiddenStems: rootHidden.length ? uniq(rootHidden).join(", ") : "None",
            type: primary.length ? "Strong Root (Main Qi)" : (secondary.length ? "Weak Root (Middle/Residual Qi)" : "No Root"),
            primary: primary.length ? primary.join(", ") : "None",
            secondary: secondary.length ? secondary.join(", ") : "None",
            hierarchy: primary.length ? "Main Qi root > Middle/Residual root (qualitative only)" : (secondary.length ? "Middle/Residual root present; weaker qualitative class" : "No Day-Master root detected"),
            hierarchyRule: "Source-based screening qualitative hierarchy only; no numeric root bonus is applied. Branch-position priority is descriptive and does not alter B1 weights.",
            resSupport: fmt(presence.resource),
            compSupport: fmt(presence.companion),
            outDrain: fmt(presence.output),
            wealthPres: fmt(presence.wealth),
            officerPres: fmt(presence.officer),
            dataStatus: "CALCULATED",
            // Field mesin array murni (bukan string gabungan) — dipakai B1 sebagai
            // rootProvidingStems, sesuai kontrak instruksi audit.
            _hiddenStemsArray: uniq(rootHidden),
            _branchesArray: uniq(rootPillars),
            verifyStatus: "CALCULATED"
        };
    }

    /* ============================================================
       A12 — CLASSICAL & DERIVED REFERENCES
       ============================================================ */

    const BRANCH_ORDER = BAZI_DATA.branchOrder; // pinyin, urutan tetap Zi..Hai

    function branchPos(key) { return BRANCH_ORDER.indexOf(key); }

    function chargShengStage(stemKey, branchKey) {
        const start = BAZI_DATA.lifeStages.changShengStart[stemKey];
        if (!start) return null;
        const startPos = branchPos(start.branch);
        const targetPos = branchPos(branchKey);
        const step = start.direction === "Shun"
            ? (targetPos - startPos + 12) % 12
            : (startPos - targetPos + 12) % 12;
        return BAZI_DATA.lifeStages.sequence[step];
    }

    // 12.1 Na Yin
    function buildA12_1(raw) {
        const result = {};
        PILLARS.forEach(function (key) {
            const stemKey = BAZI_DATA.hanziToStemKey(raw[key].ganHanzi);
            const branchKey = BAZI_DATA.hanziToBranchKey(raw[key].zhiHanzi);
            const jz = BAZI_DATA.getJiaZi(stemKey, branchKey);
            result[key] = {
                ganZhi: raw[key].ganHanzi + " " + raw[key].zhiHanzi,
                naYin: jz ? (jz.naYin + " (" + jz.naYinHanzi + ")") : "-",
                naYinElem: jz ? jz.naYinElement : "-"
            };
        });
        return result;
    }

    // 12.2 Twelve Life Stages — Day Master, Year/Month/Hour Stem vs 3 other branches
    function buildA12_2(raw) {
        const REF = {
            dm: { stemKey: BAZI_DATA.hanziToStemKey(raw.day.ganHanzi), against: ["year", "month", "day", "hour"] },
            ys: { stemKey: BAZI_DATA.hanziToStemKey(raw.year.ganHanzi), against: ["month", "day", "hour"] },
            ms: { stemKey: BAZI_DATA.hanziToStemKey(raw.month.ganHanzi), against: ["year", "day", "hour"] },
            hs: { stemKey: BAZI_DATA.hanziToStemKey(raw.hour.ganHanzi), against: ["year", "month", "day"] }
        };
        const result = {};
        Object.keys(REF).forEach(function (refKey) {
            const ref = REF[refKey];
            result[refKey] = {};
            ref.against.forEach(function (pKey) {
                const branchKey = BAZI_DATA.hanziToBranchKey(raw[pKey].zhiHanzi);
                const stage = chargShengStage(ref.stemKey, branchKey);
                result[refKey][pKey] = {
                    branch: branchKey + " (" + raw[pKey].zhiHanzi + ")",
                    phase: stage ? (stage.pinyin + " (" + stage.hanzi + ")") : "-",
                    basis: "Chang Sheng cycle from " + ref.stemKey
                };
            });
        });
        return result;
    }

    // 12.3 Kong Wang (Xun Kong)
    function buildA12_3(raw) {
        const dayStemKey = BAZI_DATA.hanziToStemKey(raw.day.ganHanzi);
        const dayBranchKey = BAZI_DATA.hanziToBranchKey(raw.day.zhiHanzi);
        const jz = BAZI_DATA.getJiaZi(dayStemKey, dayBranchKey);
        const xunIndex = jz ? Math.floor((jz.index - 1) / 10) : null;
        const cycle = xunIndex !== null ? BAZI_DATA.xun.cycles[xunIndex] : null;
        return {
            dayPair: raw.day.ganHanzi + " " + raw.day.zhiHanzi,
            xunCycle: cycle ? (cycle.id + " (" + cycle.startGanZhi + " \u2013 " + cycle.endGanZhi + ")") : "-",
            emptyBranches: cycle ? cycle.emptyBranches.join(", ") : "-",
            scope: "Applied against Day Pillar (\u65e5\u67f1\u7a7a\u4ea1)",
            calcStatus: "CALCULATED",
            verifyStatus: "CALCULATED"
        };
    }

    // 12.4 Shen Sha
    function buildA12_4(raw) {
        const dayBranchKey = BAZI_DATA.hanziToBranchKey(raw.day.zhiHanzi);
        const yearBranchKey = BAZI_DATA.hanziToBranchKey(raw.year.zhiHanzi);
        const dayStemKey = BAZI_DATA.hanziToStemKey(raw.day.ganHanzi);
        const yearStemKey = BAZI_DATA.hanziToStemKey(raw.year.ganHanzi);

        function branchLocations(targetBranchKey) {
            const found = [];
            PILLARS.forEach(function (key) {
                if (BAZI_DATA.hanziToBranchKey(raw[key].zhiHanzi) === targetBranchKey) found.push(PILLAR_LABEL[key]);
            });
            return found;
        }

        const sanHeYear = BAZI_DATA.sanHeGroups.find(function (g) { return g.branches.indexOf(yearBranchKey) !== -1; });
        const sanHeDay = BAZI_DATA.sanHeGroups.find(function (g) { return g.branches.indexOf(dayBranchKey) !== -1; });

        function triadTrace(field, label) {
            const fromDay = sanHeDay ? sanHeDay[field] : null;
            const fromYear = sanHeYear ? sanHeYear[field] : null;
            const dayLocs = fromDay ? branchLocations(fromDay) : [];
            const yearLocs = fromYear && fromYear !== fromDay ? branchLocations(fromYear) : [];
            const allLocs = dayLocs.concat(yearLocs);
            const expected = Array.from(new Set([fromDay, fromYear].filter(Boolean))).join(', ') || '-';
            const actual = allLocs.length ? Array.from(new Set(allLocs)).join(', ') : 'Not present in chart';
            const present = allLocs.length > 0;
            return {
                req: 'Reference Point=' + label + ' (Day Branch=' + raw.day.zhiHanzi + ', Year Branch=' + raw.year.zhiHanzi + ')',
                result: present ? 'DETECTED' : 'NOT PRESENT',
                location: actual,
                source: 'Rule=San He triplet registry; Condition=reference branch selects group and target branch must occur in natal chart; Expected=' + expected + '; Actual=' + actual,
                trace: 'Reference Point=' + label + ' → Input Branch=' + (label === 'Day/Year Branch' ? raw.day.zhiHanzi + '/' + raw.year.zhiHanzi : raw.day.zhiHanzi) + ' → Rule=San He triplet registry (' + field + ') → Condition=target branch present in natal chart → Expected Branch=' + expected + ' → Actual Chart=' + actual + ' → Result=' + (present ? 'DETECTED' : 'NOT PRESENT')
            };
        }

        const yima = triadTrace('yiMa', 'Day/Year Branch');
        const taohua = triadTrace('taoHua', 'Day/Year Branch');
        const huagai = triadTrace('huaGai', 'Day/Year Branch');

        const tianYiBranches = BAZI_DATA.tianYiGuiRenTable[dayStemKey] || BAZI_DATA.tianYiGuiRenTable[yearStemKey] || [];
        const tianYiLocs = tianYiBranches.reduce(function (acc, b) { return acc.concat(branchLocations(b)); }, []);
        const tianYiExpected = tianYiBranches.join(', ') || '-';
        const tianYiActual = tianYiLocs.length ? Array.from(new Set(tianYiLocs)).join(', ') : 'Not present in chart';
        const tianYi = {
            req: 'Reference Point=Day Master / Year Stem (' + raw.day.ganHanzi + ' / ' + raw.year.ganHanzi + ')',
            result: tianYiLocs.length ? 'DETECTED' : 'NOT PRESENT',
            location: tianYiActual,
            source: 'Rule=Tian Yi Gui Ren table registry; Condition=expected branch must occur in natal chart; Expected Branch=' + tianYiExpected + '; Actual=' + tianYiActual,
            trace: 'Reference Point=Day Master / Year Stem → Input Stem=' + raw.day.ganHanzi + '/' + raw.year.ganHanzi + ' → Rule=Tian Yi Gui Ren table registry → Condition=expected branch present in natal chart → Expected Branch=' + tianYiExpected + ' → Actual Chart=' + tianYiActual + ' → Result=' + (tianYiLocs.length ? 'DETECTED' : 'NOT PRESENT')
        };

        // Lu Shen: cari cabang tempat stage = LinGuan untuk stem DM
        let luShenBranch = null;
        BRANCH_ORDER.forEach(function (b) {
            const st = chargShengStage(dayStemKey, b);
            if (st && st.id === 'LinGuan') luShenBranch = b;
        });
        const luShenLocs = luShenBranch ? branchLocations(luShenBranch) : [];
        const luShenActual = luShenLocs.length ? Array.from(new Set(luShenLocs)).join(', ') : 'Not present in chart';
        const lushen = {
            req: 'Reference Point=Day Master ' + raw.day.ganHanzi,
            result: luShenLocs.length ? 'DETECTED' : 'NOT PRESENT',
            location: luShenActual,
            source: 'Rule=Chang Sheng registry; Condition=branch must equal Lin Guan stage of Day Master; Expected Branch=' + (luShenBranch || '-') + '; Actual=' + luShenActual,
            trace: 'Reference Point=Day Master → Input Stem=' + raw.day.ganHanzi + ' → Rule=Chang Sheng registry (Lin Guan) → Condition=Lin Guan branch present in natal chart → Expected Branch=' + (luShenBranch || '-') + ' → Actual Chart=' + luShenActual + ' → Result=' + (luShenLocs.length ? 'DETECTED' : 'NOT PRESENT')
        };

        const isYangStem = BAZI_DATA.heavenlyStems[dayStemKey] && BAZI_DATA.heavenlyStems[dayStemKey].polarity === 'Yang';
        let yangRenBranch = null;
        if (isYangStem && luShenBranch) {
            yangRenBranch = BRANCH_ORDER[(branchPos(luShenBranch) + 1) % 12];
        }
        const yangRenLocs = yangRenBranch ? branchLocations(yangRenBranch) : [];
        const yangRenActual = yangRenLocs.length ? Array.from(new Set(yangRenLocs)).join(', ') : 'Not present in chart';
        const yangren = {
            req: 'Reference Point=Yang Day Master ' + raw.day.ganHanzi,
            result: !isYangStem ? 'N/A' : (yangRenLocs.length ? 'DETECTED' : 'NOT PRESENT'),
            location: !isYangStem ? 'Not applicable' : yangRenActual,
            source: 'Rule=Chang Sheng Lin Guan +1; Condition=Day Master must be Yang and expected branch must occur; Expected Branch=' + (yangRenBranch || '-') + '; Actual=' + yangRenActual,
            trace: 'Reference Point=Day Master → Input Stem=' + raw.day.ganHanzi + ' → Rule=Chang Sheng Lin Guan + 1 → Condition=Yang Day Master AND expected branch present → Expected Branch=' + (yangRenBranch || '-') + ' → Actual Chart=' + yangRenActual + ' → Result=' + (!isYangStem ? 'N/A' : (yangRenLocs.length ? 'DETECTED' : 'NOT PRESENT'))
        };

        return { yima: yima, taohua: taohua, tianyi: tianYi, huagai: huagai, lushen: lushen, yangren: yangren };
    }

    // 12.5 Stem interactions (He / Chong) — memakai scanStems() di atas
    // (fungsi privat modul ini) supaya hasilnya konsisten dengan A14.3.
    function buildA12_5(raw) {
        const stems = PILLARS.map(function (key) {
            return { pillar: PILLAR_LABEL[key], pillarKey: key, key: BAZI_DATA.hanziToStemKey(raw[key].ganHanzi) };
        });

        const result = scanStems(stems);

        function fmt(hits, withElem) {
            if (!hits.length) return { stems: "None", position: "-", fact: "No interaction detected" };
            const stemsStr = hits.map(function (h) { return h.members[0].key + "\u2013" + h.members[1].key; }).join(", ");
            const posStr = hits.map(function (h) { return h.members[0].pillar + "\u2013" + h.members[1].pillar; }).join(", ");
            const factStr = withElem
                ? hits.map(function (h) { return h.members[0].key + "+" + h.members[1].key + " \u2192 " + h.element; }).join(", ")
                : "Direct opposition (\u76f8\u51b2)";
            return { stems: stemsStr, position: posStr, fact: factStr };
        }

        return {
            he: fmt(result.he, true),
            chong: fmt(result.chong, false),
            _heHits: result.he
        };
    }

    // 12.6 Branch interactions — memakai scanBranches() di atas, memastikan
    // SEMUA kelompok Xing di registry diproses (bukan cuma 2 dari 4), dan
    // San He/Ban He/San Hui sudah di-unique-kan cabangnya.
    function buildA12_6(raw) {
        const branches = PILLARS.map(function (key) {
            return { pillar: PILLAR_LABEL[key], key: BAZI_DATA.hanziToBranchKey(raw[key].zhiHanzi) };
        });

        const scan = scanBranches(branches);

        function fmtGroupHits(hits, includeElement) {
            if (!hits.length) return { branches: "None", position: "-", fact: "No interaction detected" };
            return {
                branches: hits.map(function (h) { return h.uniqueKeys.join("\u2013"); }).join("; "),
                position: hits.map(function (h) {
                    return Array.from(new Set(h.members.map(function (m) { return m.pillar; }))).join(", ");
                }).join("; "),
                fact: hits.map(function (h) {
                    return h.uniqueKeys.join("+") + (includeElement ? " \u2192 " + h.element : "");
                }).join("; ")
            };
        }

        function fmtPairHits(hits, label, withElement) {
            if (!hits.length) return { branches: "None", position: "-", fact: "No interaction detected" };
            return {
                branches: hits.map(function (h) { return h.members[0].key + "\u2013" + h.members[1].key; }).join(", "),
                position: hits.map(function (h) { return h.members[0].pillar + "\u2013" + h.members[1].pillar; }).join(", "),
                fact: withElement
                    ? hits.map(function (h) { return h.members[0].key + "+" + h.members[1].key + " \u2192 " + h.element; }).join(", ")
                    : label
            };
        }

        function fmtXing(hits) {
            if (!hits.length) return { branches: "None", position: "-", fact: "No interaction detected" };
            return {
                branches: hits.map(function (h) { return h.uniqueKeys.join("\u2013"); }).join("; "),
                position: hits.map(function (h) { return Array.from(new Set(h.members.map(function (m) { return m.pillar; }))).join(", "); }).join("; "),
                fact: hits.map(function (h) { return h.name; }).join("; ")
            };
        }

        return {
            liuhe: fmtPairHits(scan.liuHe, "", true),
            sanhe: fmtGroupHits(scan.sanHe, true),
            sanhui: fmtGroupHits(scan.sanHui, true),
            banhe: fmtGroupHits(scan.banHe, true),
            chong: fmtPairHits(scan.chong, "Direct opposition (\u76f8\u51b2)", false),
            xing: fmtXing(scan.xing),
            hai: fmtPairHits(scan.hai, "Mutual harm (\u76f8\u5bb3)", false),
            po: fmtPairHits(scan.po, "Secondary/Variant relation — Mutual destruction (\u76f8\u7834)", false)
        };
    }

    // 12.7 Transformation (Hua) — PATCH (Audit Spec §11): He (deteksi kombinasi)
    // He (合) is never silently upgraded to Hua (化). The selected source-screen
    // now checks Month-Command support, independent target-element root/support, preserves
    // stem-position provenance, plus a configured sitting-branch obstruction rule. This is a
    // bounded source profile; He (合) is not universally equivalent to Hua (化).
    function buildA12_7(raw, heHits) {
        if (!heHits || !heHits.length) {
            return {
                row1: {
                    elements: "None", type: "No stem combination present", status: "N/A",
                    _stage: "NONE", _ruleGap: null
                }
            };
        }
        const monthBranchKey = BAZI_DATA.hanziToBranchKey(raw.month.zhiHanzi);
        const monthSeasonElement = BAZI_DATA.seasonalState.seasonByMonthBranch[monthBranchKey];
        // SOURCE-BASED SCREENING HUA PROFILE: Month-Command support is required and a
        // configured adverse branch interaction on either combining stem's sitting
        // branch blocks this screen. This is a selected source profile, not a
        // universal school claim.
        const rows = heHits.map(function (h) {
            const monthSupports = h.element === monthSeasonElement;
            // Preserve pillar provenance from scanStems(). Do not reverse-map stem→pillar:
            // duplicate stems (e.g. 癸 in Year and Hour) make that mapping ambiguous.
            const memberPillars = h.members.map(function (m) { return m.pillarKey || null; }).filter(Boolean);
            const pillarIndexes = memberPillars.map(function (k) { return PILLARS.indexOf(k); }).filter(function (i) { return i >= 0; });
            const positionGap = pillarIndexes.length === 2 ? Math.abs(pillarIndexes[0] - pillarIndexes[1]) : null;
            const positionStatus = positionGap === 0 ? "SAME_POSITION_UNRESOLVED" : (positionGap === 1 ? "ADJACENT_STEM_PAIR" : "SEPARATED_STEM_PAIR_SOURCE_ALLOWED");
            const sittingBranches = memberPillars.map(function (k) { return BAZI_DATA.hanziToBranchKey(raw[k].zhiHanzi); }).filter(Boolean);
            const interactions = [];
            const branchList = PILLARS.map(function (key) { return { pillar: PILLAR_LABEL[key], key: BAZI_DATA.hanziToBranchKey(raw[key].zhiHanzi) }; });
            const branchScan = scanBranches(branchList);
            [branchScan.chong, branchScan.xing, branchScan.hai, branchScan.po].forEach(function (group) {
                (group || []).forEach(function (x) {
                    const members = x.members || [];
                    interactions.push(members.map(function (m) { return m.key; }).join("–"));
                });
            });
            const blocked = interactions.some(function (txt) {
                return sittingBranches.some(function (b) {
                    return txt.indexOf(b + "–") !== -1 || txt.indexOf("–" + b) !== -1 ||
                           txt.indexOf(b + "-") !== -1 || txt.indexOf("-" + b) !== -1;
                });
            });
            // Root/support and competition are distinct evidence classes. Independent natal
            // support for the target element is required by this selected profile; competition
            // is reserved for a second He targeting the same transformation element or another
            // explicitly configured precedence conflict. This avoids treating required support
            // as disqualifying competition.
            const sameTargetOtherHe = heHits.some(function(other){
                if (other === h) return false;
                if (other.element !== h.element) return false;
                const a = other.members.map(function(m){return m.pillarKey;}).join("+");
                const b = h.members.map(function(m){return m.pillarKey;}).join("+");
                return a !== b;
            });
            const memberPillarSet = memberPillars.reduce(function(acc,key){acc[key]=true; return acc;},{});
            const targetElementCount = PILLARS.reduce(function(n,key){
                if (memberPillarSet[key]) return n;
                const stemKey = BAZI_DATA.hanziToStemKey(raw[key].ganHanzi);
                const stem = stemKey ? BAZI_DATA.getStem(stemKey) : null;
                const hidden = BAZI_DATA.getHiddenStemsByHanzi(raw[key].zhiHanzi)||[];
                const stemHit = stem && stem.element === h.element ? 1 : 0;
                const hiddenHit = hidden.filter(function(x){ return x.element === h.element; }).length;
                return n + stemHit + hiddenHit;
            },0);
            const targetRootSupport = targetElementCount > 0;
            const competitionEvidence = { sameTargetOtherHe:sameTargetOtherHe, targetRootSupport:targetRootSupport, targetElementEvidenceCount:targetElementCount };
            let stage = "HE_DETECTED_NOT_TRANSFORMED";
            let reason = "Month Command does not support target element";
            if (monthSupports && positionStatus === "SAME_POSITION_UNRESOLVED") {
                stage = "HUA_POSITION_UNRESOLVED";
                reason = "Month Command supports target element, but the combination resolves to the same stem position and cannot be adjudicated by this source profile";
            } else if (monthSupports && blocked) {
                stage = "HUA_BLOCKED_BY_CONFIGURED_OBSTRUCTION";
                reason = "Month Command supports target element, but a configured sitting-branch adverse interaction is present";
            } else if (monthSupports && !targetRootSupport) {
                stage = "HUA_CANDIDATE_NOT_ROOT_SUPPORTED";
                reason = "Month Command supports target element, but no independent natal target-element root/support is present";
            } else if (monthSupports && sameTargetOtherHe) {
                stage = "HUA_COMPETITION_UNRESOLVED";
                reason = "Month Command and target-root support passed, but another He targeting the same transformation element remains";
            } else if (monthSupports && targetRootSupport) {
                stage = "HUA_ALL_REQUIRED_CONDITIONS";
                reason = "Selected source profile closed: Month Command support + independent target-element root/support + no configured obstruction + no competing same-target He";
            }
            return h.members[0].key + "+" + h.members[1].key + " (→ " + h.element + ")" +
                " | He Detected (合) | Position: " + positionStatus +
                " | Hua Screen: " + reason +
                " | Competition Evidence: " + JSON.stringify(competitionEvidence) +
                " | Stage: " + stage + " | SOURCE-BASED PROFILE; confirmation is limited to the selected source contract";
        });

        return {
            row1: {
                elements: heHits.map(function (h) { return h.members[0].key + "+" + h.members[1].key; }).join(", "),
                type: "He Detected (\u5408) \u2014 Hua evaluated under selected source profile",
                status: rows.join(" | ")
            }
        };
    }

    // 12.8 — Yong Shen / Xi Shen / Ji Shen: wewenang Core B, belum dihitung di sini.
    function buildA12_8() {
        const pending = "Pending \u2014 Core B (Ge Ju / Yong Shen Analysis)";
        return { yongshen: pending, xishen: pending, jishen: pending };
    }

    // 12.9 — Pattern Foundation candidate (mekanis, berbasis penembusan Yue Ling)
    // PATCH (Audit Spec §13): tambah field mesin (_stemKey/_godCode) di samping
    // teks tampilan `elem`, supaya B3 bisa membaca kode Shi Shen & kunci Batang
    // langsung tanpa parsing string.
    function buildA12_9(a7) {
        return {
            primary: {
                elem: a7.mainQi !== "-" ? (a7.mainQi + " \u2192 " + a7._mainQiGod) : "-",
                _stemKey: a7._mainQiStemKey || null,
                _godCode: a7._mainQiGodCode || null
            },
            alt: {
                elem: [a7.midQi !== "-" ? (a7.midQi + " \u2192 " + a7._midQiGod) : null, a7.resQi !== "-" ? (a7.resQi + " \u2192 " + a7._resQiGod) : null].filter(Boolean).join(", ") || "None",
                _stemKeys: [a7._midQiStemKey, a7._resQiStemKey].filter(Boolean),
                _godCodes: [a7._midQiGodCode, a7._resQiGodCode].filter(Boolean)
            }
        };
    }

    /* ============================================================
       A13 — MING GONG & TAI YUAN
       ============================================================ */

    // G8: Ming Gong memakai rumus 安命宫 yang eksplisit dan dapat dihitung
    // ulang secara independen dari Year Stem + Month Branch + Hour Branch.
    // Branch rule: 月支序 + 时支序 dihitung pada urutan Zi..Hai dengan
    // Zi=11, Chou=12, Yin=1 ... Hai=10; offset = 14 - sum, bila <=0 +12.
    // Stem rule: tentukan stem 寅月 dari Year Stem (五虎遁), lalu maju sesuai
    // jarak 寅 -> 命宫. Ini adalah standard derivation yang sama dengan
    // EightChar.getMingGong(), tetapi sekarang direkam sebagai calculation trace.
    function buildA13(eightChar, raw) {
        const taiYuanHanzi = eightChar.getTaiYuan();
        const mingGongHanzi = eightChar.getMingGong();

        const monthStemKey = BAZI_DATA.hanziToStemKey(raw.month.ganHanzi);
        const monthBranchKey = BAZI_DATA.hanziToBranchKey(raw.month.zhiHanzi);
        const stemIdx = BAZI_DATA.stemOrder.indexOf(monthStemKey);
        const branchIdx = BRANCH_ORDER.indexOf(monthBranchKey);
        const expectedStemKey = BAZI_DATA.stemOrder[(stemIdx + 1) % 10];
        const expectedBranchKey = BRANCH_ORDER[(branchIdx + 3) % 12];
        const expectedTaiYuanHanzi = BAZI_DATA.getStem(expectedStemKey).hanzi + BAZI_DATA.getBranch(expectedBranchKey).hanzi;
        const taiYuanVerified = expectedTaiYuanHanzi === taiYuanHanzi;

        const stemOrder = BAZI_DATA.stemOrder;
        const branchOrder = BRANCH_ORDER;
        const yearStemKey = BAZI_DATA.hanziToStemKey(raw.year.ganHanzi);
        const yearStemIdx = stemOrder.indexOf(yearStemKey);
        const monthBranchIdx = branchOrder.indexOf(monthBranchKey);
        const hourBranchKey = BAZI_DATA.hanziToBranchKey(raw.hour.zhiHanzi);
        const hourBranchIdx = branchOrder.indexOf(hourBranchKey);
        const yinIdx = branchOrder.indexOf('Yin');

        // 1-based classical branch numbers: Yin=1 ... Hai=10, Zi=11, Chou=12.
        function mingBranchNumber(branchKey) {
            const i = branchOrder.indexOf(branchKey);
            if (i < 0) return null;
            return ((i - yinIdx + 12) % 12) + 1;
        }
        const monthNo = mingBranchNumber(monthBranchKey);
        const hourNo = mingBranchNumber(hourBranchKey);
        let mingOffset = 14 - monthNo - hourNo;
        if (mingOffset <= 0) mingOffset += 12;
        const expectedMingBranchKey = branchOrder[(yinIdx + mingOffset - 1) % 12];

        // 五虎遁: 寅月 stem = (YearStemIndex mod 5)*2 + 2.
        const yinStemIdx = ((yearStemIdx % 5) * 2 + 2) % 10;
        const mingBranchDistance = (branchOrder.indexOf(expectedMingBranchKey) - yinIdx + 12) % 12;
        const expectedMingStemKey = stemOrder[(yinStemIdx + mingBranchDistance) % 10];
        const expectedMingGongHanzi = BAZI_DATA.getStem(expectedMingStemKey).hanzi + BAZI_DATA.getBranch(expectedMingBranchKey).hanzi;
        const mingGongVerified = expectedMingGongHanzi === mingGongHanzi;

        const mingTrace =
            'Input: Year Stem=' + raw.year.ganHanzi + ', Month Branch=' + raw.month.zhiHanzi + ', Hour Branch=' + raw.hour.zhiHanzi +
            ' → Formula: 安命宫; Month No=' + monthNo + ', Hour No=' + hourNo +
            ' → Intermediate: offset=14-' + monthNo + '-' + hourNo + '=' + mingOffset +
            ', Ming Gong Branch=' + expectedMingBranchKey +
            ' → 五虎遁: Yin-month Stem=' + BAZI_DATA.getStem(stemOrder[yinStemIdx]).hanzi +
            ', distance Yin→Ming=' + mingBranchDistance +
            ' → Ming Gong=' + expectedMingGongHanzi +
            ' → Library=' + mingGongHanzi +
            ' → Verification=' + (mingGongVerified ? 'VERIFIED' : 'ERROR');

        return {
            mingGong: {
                value: mingGongHanzi,
                basis: mingTrace.replace("Verification=VERIFIED", "Internal derivation check"),
                verify: mingGongVerified ? 'CALCULATED — INTERNAL CHECK' : 'ERROR'
            },
            taiYuan: {
                value: taiYuanHanzi,
                basis: 'Input: Month Pillar=' + raw.month.ganHanzi + raw.month.zhiHanzi +
                    ' → Formula: Stem +1 (' + monthStemKey + '→' + expectedStemKey + '), Branch +3 (' + monthBranchKey + '→' + expectedBranchKey + ')' +
                    ' → Intermediate: ' + BAZI_DATA.getStem(expectedStemKey).hanzi + BAZI_DATA.getBranch(expectedBranchKey).hanzi +
                    ' → Final: ' + taiYuanHanzi + ' (re-derived within Core A; cross-checked at engine/library level; not independent external verification)',
                verify: taiYuanVerified ? 'CALCULATED — ENGINE/LIBRARY CROSS-CHECK' : 'ERROR'
            }
        };
    }

    /* ============================================================
       A14 — LUCK PILLARS (Da Yun / 大运)
       ============================================================ */

    // Memakai scanStems()/scanBranches() yang sama dengan A12.5/A12.6 (bukan
    // implementasi terpisah), dengan hasil difilter agar hanya menampilkan
    // interaksi yang benar-benar melibatkan pilar Da Yun.
    function interactionSummary(stemHanzi, branchHanzi, natalStems, natalBranches) {
        const DY = "DaYun";
        const stemKey = BAZI_DATA.hanziToStemKey(stemHanzi);
        const branchKey = BAZI_DATA.hanziToBranchKey(branchHanzi);

        const stemEntries = natalStems.concat([{ pillar: DY, key: stemKey }]);
        const branchEntries = natalBranches.concat([{ pillar: DY, key: branchKey }]);

        const stemScan = scanStems(stemEntries);
        const branchScan = scanBranches(branchEntries);

        function involvesDaYun(hit) {
            return hit.members.some(function (m) { return m.pillar === DY; });
        }
        function otherLabel(hit) {
            const other = hit.members.find(function (m) { return m.pillar !== DY; });
            return other ? other.pillar : "?";
        }

        const notes = [];
        stemScan.he.filter(involvesDaYun).forEach(function (h) {
            notes.push("Stem He: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ") \u2192 " + h.element);
        });
        stemScan.chong.filter(involvesDaYun).forEach(function (h) {
            notes.push("Stem Chong: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ")");
        });
        branchScan.liuHe.filter(involvesDaYun).forEach(function (h) {
            notes.push("Branch He: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ") \u2192 " + h.element);
        });
        branchScan.chong.filter(involvesDaYun).forEach(function (h) {
            notes.push("Branch Chong: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ")");
        });
        branchScan.hai.filter(involvesDaYun).forEach(function (h) {
            notes.push("Branch Hai: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ")");
        });
        branchScan.po.filter(involvesDaYun).forEach(function (h) {
            notes.push("Branch Po [Secondary/Variant]: " + h.members[0].key + "\u2013" + h.members[1].key + " (" + otherLabel(h) + ")");
        });
        branchScan.xing.filter(function (h) { return h.members.some(function (m) { return m.pillar === DY; }); }).forEach(function (h) {
            notes.push("Branch Xing: " + h.uniqueKeys.join("\u2013") + " (" + Array.from(new Set(h.members.map(function (m) { return m.pillar; }))).join(", ") + ") \u2014 " + h.name);
        });
        branchScan.sanHe.filter(function (h) { return h.members.some(function (m) { return m.pillar === DY; }); }).forEach(function (h) {
            notes.push("Branch San He: " + h.uniqueKeys.join("\u2013") + " \u2192 " + h.element + " (full triplet, incl. Da Yun)");
        });
        branchScan.banHe.filter(function (h) { return h.members.some(function (m) { return m.pillar === DY; }); }).forEach(function (h) {
            notes.push("Branch Ban He: " + h.uniqueKeys.join("\u2013") + " \u2192 " + h.element + " (partial, incl. Da Yun)");
        });

        return notes.length ? notes.join("; ") : "No significant interaction with natal chart";
    }

    function buildA14(raw, eightChar, rawInput, transitionUtcOffsetHours) {
        const genderCode = rawInput.gender === "Male" ? 1 : 0;
        const yun = eightChar.getYun(genderCode, 2);
        const forward = yun.isForward();

        const startSolar = yun.getStartSolar();
        const startDateTime = startSolar.toYmdHms();

        const jieqiRef = forward
            ? { name: "Next Jie (\u8282)", basis: "Forward count to next solar term" }
            : { name: "Previous Jie (\u8282)", basis: "Reverse count to previous solar term" };

        const daYunListRaw = yun.getDaYun(9); // index 0 = placeholder pra-DaYun, 1..8 = pilar asli
        const daYunList = daYunListRaw.slice(1, 9);

        const natalStems = PILLARS.map(function (key) {
            return { pillar: PILLAR_LABEL[key], key: BAZI_DATA.hanziToStemKey(raw[key].ganHanzi) };
        });
        const natalBranches = PILLARS.map(function (key) {
            return { pillar: PILLAR_LABEL[key], key: BAZI_DATA.hanziToBranchKey(raw[key].zhiHanzi) };
        });

        const a14_2 = {};
        const a14_3 = {};
        let seqOk = true;
        const birthYearForAge = (rawInput && rawInput.birthDate instanceof Date)
            ? rawInput.birthDate.getFullYear()
            : Number(String(rawInput.birthDate).slice(0, 4));

        // G9: A14.2 displays elapsed/actual age derived from the Da Yun start year
        // relative to the birth year. This is a display convention only; the precise
        // start duration in A14.1 remains the calculation basis.

        daYunList.forEach(function (d, idx) {
            const no = idx + 1;
            const gz = d.getGanZhi(); // "壬午" dst (kosong utk index0, tapi sudah di-slice)
            const stemHanzi = gz.charAt(0);
            const branchHanzi = gz.charAt(1);
            const stemInfo = BAZI_DATA.getStemByHanzi(stemHanzi);
            const branchInfo = BAZI_DATA.getBranchByHanzi(branchHanzi);

            // PATCH (Audit Spec §14): waktu mulai PRESISI (bukan cuma tahun
            // kalender) per periode — periode #1 mulai persis di startSolar,
            // dan setiap periode berikutnya persis +10 tahun dari situ (aturan
            // Da Yun: tiap periode = 10 tahun tetap). Dipakai Core C untuk
            // menentukan periode aktif dengan perbandingan datetime, bukan
            // cuma currentYear >= startYear.
            // PATCH: deterministic transition timestamps. The transition is
            // calculated by the existing Da Yun engine as a calendar/clock value.
            // Encode that value explicitly with the resolved birth-location UTC
            // offset so the resulting instant does not depend on the runtime's
            // own timezone. Do NOT rebuild it with new Date(y,m,d,...) because
            // that would silently use the device/server timezone.
            function transitionISO(yearOffset) {
                const wallClockUtcMs = Date.UTC(
                    startSolar.getYear() + yearOffset,
                    startSolar.getMonth() - 1,
                    startSolar.getDay(),
                    startSolar.getHour(),
                    startSolar.getMinute(),
                    startSolar.getSecond()
                );
                const offsetHours = Number(transitionUtcOffsetHours);
                if (!Number.isFinite(offsetHours)) {
                    throw new Error('[PenggilasCoreA] A14 transition timezone offset is invalid.');
                }
                return new Date(wallClockUtcMs - offsetHours * 3600000).toISOString();
            }
            const periodStartISO = transitionISO(idx * 10);
            const periodEndISO = transitionISO((idx + 1) * 10);

            a14_2[no] = {
                ganZhi: stemHanzi + " " + branchHanzi,
                stem: (stemInfo ? stemInfo.pinyin : "?") + " (" + stemHanzi + ")",
                stemElem: stemInfo ? stemInfo.element : "-",
                stemPol: stemInfo ? stemInfo.polarity : "-",
                branch: (branchInfo ? branchInfo.pinyin : "?") + " (" + branchHanzi + ")",
                branchElem: branchInfo ? branchInfo.element : "-",
                branchPol: branchInfo ? branchInfo.polarity : "-",
                // PATCH (locked decision dengan user): tampilkan 周岁 (Actual/
                // Zhou Sui Age), BUKAN 虚岁 (Nominal/Xu Sui) bawaan pustaka.
                // Pustaka menghitung startAge = startYear-birthYear+1 (虚岁);
                // Actual Age = startYear-birthYear = getStartAge()-1. Hanya
                // konversi label tampilan, TIDAK menyentuh startYear/endYear/
                // Gan-Zhi/tanggal transisi presisi (itu semua sudah tidak
                // mengandung +1 sama sekali, terbukti dari source pustaka).
                startAge: d.getStartAge() - 1,
                endAge: d.getEndAge() - 1,
                // G9: A14.2 display follows actual elapsed age convention: start year minus birth year.
                // It is presentation-only and never feeds the precise transition/start-date calculation.
                displayStartAge: d.getStartYear() - birthYearForAge,
                displayAgeConvention: "Actual elapsed age display: Start Year − Birth Year (presentation only); precise A14.1 duration remains unchanged",
                displayAgeRange: (d.getStartYear() - birthYearForAge) + "–" + (d.getEndYear() - birthYearForAge) + " years (display range)",
                startYear: d.getStartYear(),
                endYear: d.getEndYear(),
                duration: (d.getEndYear() - d.getStartYear() + 1) + " years",
                calculationStatus: "CALCULATED",
                // Verification status is assigned after the full sequence-continuity check below.
                status: "PENDING",
                // Field mesin (Audit Spec §13/§14) — dipakai Core C, supaya tidak
                // perlu split(" ") dari `ganZhi`, dan supaya batas periode aktif
                // memakai datetime presisi, bukan cuma tahun kalender.
                _stemHanzi: stemHanzi,
                _branchHanzi: branchHanzi,
                _startDateTimeISO: periodStartISO,
                _endDateTimeISO: periodEndISO
            };

            a14_3[no] = { interactions: interactionSummary(stemHanzi, branchHanzi, natalStems, natalBranches) };

            if (idx > 0 && daYunList[idx - 1].getEndAge() + 1 !== d.getStartAge()) seqOk = false;
        });

        // A14.2 contract field is Verification Status. Verification is deliberately
        // scoped to the sequence-continuity checks performed by this section; the
        // underlying library calculation remains separately marked CALCULATED.
        Object.keys(a14_2).forEach(function (key) {
            a14_2[key].status = seqOk ? "VERIFIED" : "ERROR";
        });

        return {
            A14_1: {
                direction: forward ? "Shun (\u987a\u884c \u2014 Forward)" : "Ni (\u9006\u884c \u2014 Reverse)",
                startAge: (yun.getStartYear() + " years " + yun.getStartMonth() + " months " + yun.getStartDay() + " days" +
                    (daYunList[0] ? " (Actual/\u5468\u5c81 age at transition: " + (daYunList[0].getStartAge() - 1) + ")" : "")),
                startDateTime: startDateTime,
                startPoint: "Birth moment (True Solar Time) \u2192 " + jieqiRef.name,
                refJieQi: jieqiRef.name + " (" + jieqiRef.basis + ")",
                transRule: "3 Days = 1 Year \u2192 1 Day = 4 Months; 1 Hour = 5 Days (exact minute-based conversion). " +
                    "NOTE: Age figures in A14.2 (Starting/Ending Age) use Actual/Elapsed Age convention " +
                    "(\u5468\u5c81 / Zhou Sui: age = transition calendar year \u2212 birth calendar year). This is a " +
                    "LOCKED display decision (confirmed with project owner): the underlying lunar-javascript " +
                    "library natively computes Nominal Age (\u865a\u5c81 / Xu Sui, +1); this engine subtracts 1 " +
                    "before display so that comparisons against elapsed-age software match directly. " +
                    "Only the displayed age number is adjusted \u2014 Starting/Ending Year, the Gan-Zhi assigned " +
                    "to each period, and the precise transition date/time are untouched by this conversion.",
                calcMethod: "Precise (sect 2): minutes from birth to reference Jie Qi \u00f7 4320 = years (lunar-javascript EightChar.getYun)",
                seqVerify: seqOk ? "PASSED \u2014 8 pillars contiguous, no age gaps" : "FAILED \u2014 age gap detected between pillars",
                status: "CALCULATED"
            },
            A14_2: a14_2,
            A14_3: a14_3,
            A14_4: {
                row1: {
                    id: "Da Yun continuity check",
                    issue: seqOk ? "None" : "Age sequence gap between consecutive Da Yun pillars",
                    resolution: seqOk ? "N/A \u2014 sequence verified contiguous" : "Re-run the luck-pillar calculation and inspect the calculated sequence",
                    status: seqOk ? "VERIFIED" : "ERROR"
                }
            },
            _seqOk: seqOk
        };
    }
    /* ============================================================
       A15 — CORE CHART INTEGRITY
       A16 — FOUNDATION VERIFICATION NOTES
       A17 — FOUNDATION ADDITIONAL NOTES
       ============================================================ */

    // PATCH (Audit Spec §7): A16 sebelumnya HARDCODE "None detected"/"PASSED"
    // tanpa cek nyata apapun — klaim audit palsu. Sekarang benar-benar memakai
    // hasil cek kontinuitas Da Yun (seqOk dari A14) sebagai bukti nyata,
    // sehingga status VERIFIED/ERROR di sini benar-benar berarti sesuatu.
    function buildA15Node(raw, rawInput, seqOk) {
        const bundle = buildA15_16_17Bundle(raw, rawInput, seqOk);
        return { A15: bundle.A15, _A16: bundle.A16, _A17: bundle.A17 };
    }

    function buildA15_16_17Bundle(raw, rawInput, seqOk) {
        const fourPillarsStr = PILLARS.map(function (k) { return raw[k].ganHanzi + raw[k].zhiHanzi; }).join(" ");
        const dayStemInfo = BAZI_DATA.getStemByHanzi(raw.day.ganHanzi);
        const monthBranchInfo = BAZI_DATA.getBranchByHanzi(raw.month.zhiHanzi);

        const allPillarsValid = PILLARS.every(function (k) {
            return BAZI_DATA.getStemByHanzi(raw[k].ganHanzi) !== null &&
                BAZI_DATA.getBranchByHanzi(raw[k].zhiHanzi) !== null;
        });
        const fourPillarsFormatValid = fourPillarsStr.replace(/\s/g, "").length === 8;
        const internalIntegrityVerified = allPillarsValid && fourPillarsFormatValid && !!dayStemInfo && !!monthBranchInfo;

        const A15 = {
            birthData: rawInput.birthDate + " " + rawInput.birthTime + " (civil, pre-True-Solar-Time correction)",
            fourPillars: fourPillarsStr,
            dayMaster: (dayStemInfo ? dayStemInfo.pinyin : "?") + " (" + raw.day.ganHanzi + ")",
            monthBranch: (monthBranchInfo ? monthBranchInfo.pinyin : "?") + " (" + raw.month.zhiHanzi + ")",
            source: "Foundation chart calculation — lunar-javascript EightChar engine",
            lockStatus: internalIntegrityVerified ? "LOCKED (permanent chart fields pass calculation integrity checks)" : "UNLOCKED (one or more permanent chart fields failed calculation integrity checks)",
            verifyStatus: internalIntegrityVerified ? "CALCULATION CHECK PASSED; INDEPENDENT CLASSICAL VERIFICATION NOT PERFORMED" : "CALCULATION CHECK FAILED; INDEPENDENT CLASSICAL VERIFICATION NOT PERFORMED",
            verificationScope: "Chart registry and format consistency only; no independent Classical cross-source verification performed."
        };

        function ledger(id, section, field, source, derived, issue, severity, status, action, resolution, verifier) {
            return { id:id, section:section, field:field, source:source, derived:derived, issue:issue,
                severity:severity, status:status, action:action, resolution:resolution, resDate:"-", verifier:verifier };
        }

        const A16 = {
            row1: ledger("Four Pillars Integrity Check", "Chart Integrity", "Permanent Four Pillars / Day Master / Month Branch",
                "Stem/branch reference data + chart format checks", fourPillarsStr,
                internalIntegrityVerified ? "None detected" : "Permanent chart field failed internal registry/format check",
                internalIntegrityVerified ? "N/A" : "HIGH", internalIntegrityVerified ? "VERIFIED" : "ERROR",
                internalIntegrityVerified ? "None required" : "Re-run foundation calculation and inspect core chart source",
                internalIntegrityVerified ? "Internal integrity verified" : "Unresolved", "PenggilasCoreA (automated internal integrity check)"),
            row2: ledger("Da Yun Sequence Check", "Luck Pillars", "Da Yun sequence",
                "EightChar luck-pillar calculation", "Starting/ending age continuity",
                seqOk ? "None detected" : "Age sequence gap between consecutive Da Yun pillars",
                seqOk ? "N/A" : "HIGH", seqOk ? "VERIFIED" : "ERROR",
                seqOk ? "None required" : "Re-run the luck-pillar calculation and inspect the calculated sequence",
                seqOk ? "Sequence continuity verified" : "Unresolved", "PenggilasCoreA (automated contiguity check)"),
            row3: ledger("Ming Gong Calculation Check", "Ming Gong", "Ming Gong", "Core A Ming Gong calculation",
                "Ming Gong derived value + branch validation",
                "Internal derivation check only; not an independent cross-source verification",
                "N/A", "CALCULATED", "No external verification claimed", "Internal calculation retained; independent verification not performed", "PenggilasCoreA"),
            row4: ledger("Tai Yuan Calculation Check", "Tai Yuan", "Tai Yuan", "Core A Tai Yuan derivation + lunar-javascript cross-check",
                "Tai Yuan derived value", "Cross-check is engine/library-level, not independent external source verification",
                "N/A", "CALCULATED", "No external verification claimed", "Library cross-check retained as calculation provenance", "PenggilasCoreA")
        };

        const A17 = {
            row1: {
                id: "Calculation Parameter Note", type: "Calculation Parameter", field: "True Solar Time / Early-Zi day-boundary convention / Da Yun starting age",
                note: "True Solar Time and the early-Zi sect are locked project parameters. Da Yun age display uses Actual/Elapsed Age (周岁); the library's Nominal Age (虚岁) is not exposed as the display convention.",
                status: "LOCKED"
            },
            row2: {
                id: "Derived Metric Note", type: "Derived Metric", field: "Seasonal weighting / Yin-Yang ratio / Ten Gods distribution",
                note: "Adjusted seasonal weight and element/Ten-God ratios are calculated indicators. They are not presented as complete Classical 旺衰 strength calculations.",
                status: "CALCULATED"
            },
            row3: {
                id: "Rule Scope Note", type: "Rule Scope / Resolution State", field: "Month Command / Root / Transformation-Hua / Pattern / Structural Change / Yong Shen / Temporal Response",
                note: "Day-precise seasonal Qi (人元司令分野), qualitative root hierarchy, Hua obstruction screening, and Yang Ren (阳刃) screening are implemented. Remaining scope: universal-school Hua variants, complete 从格/化格 evaluation, full 格局成败/救应 reconciliation, and a source-specific quantitative Classical 旺衰 score. Dependent outputs remain provisional or rule-status dependent.",
                status: "SCOPED / RULE-STATUS"
            },
            row4: {
                id: "Verification Scope Note", type: "Verification Scope", field: "Chart Integrity / Foundation Checks / Classical Structural Verification / Evidence & Verification",
                note: "VERIFIED means an internal or explicitly identified check passed. It does not mean independent astronomical or cross-source Classical verification unless that check is separately recorded.",
                status: "SCOPED"
            }
        };

        return { A15: A15, A16: A16, A17: A17 };
    }

    /* ============================================================
       MAIN ENTRY POINT
       ============================================================ */

    const PenggilasCoreA = {
        version: CORE_A_VERSION,

        /**
         * @param {Object} rawInput { name, gender, birthDate:"YYYY-MM-DD",
         *                            birthTime:"HH:MM", birthPlace:{query} }
         * @returns {Promise<Object>} foundationMaster { A1..A11 }
         */
        async calculate(rawInput) {
            requireGlobals();
            if (!rawInput || !rawInput.birthDate || !rawInput.birthTime || !rawInput.birthPlace || !rawInput.birthPlace.query) {
                throw new Error("[PenggilasCoreA] Input tidak lengkap (birthDate/birthTime/birthPlace wajib).");
            }

            rawInput = Object.assign({}, rawInput, { gender: normalizeGender(rawInput.gender) });

            if (!/^\d{4}-\d{2}-\d{2}$/.test(rawInput.birthDate)) {
                throw new Error("[PenggilasCoreA] Birth date harus berformat YYYY-MM-DD.");
            }

            if (!/^\d{2}:\d{2}$/.test(rawInput.birthTime)) {
                throw new Error("[PenggilasCoreA] Birth time harus berformat HH:MM.");
            }

            const [by, bm, bd] = rawInput.birthDate.split("-").map(Number);
            const [bh, bmin] = rawInput.birthTime.split(":").map(Number);
            const civilDate = new Date(by, bm - 1, bd, bh, bmin, 0);

            if (
                bm < 1 || bm > 12 ||
                bd < 1 || bd > 31 ||
                bh < 0 || bh > 23 ||
                bmin < 0 || bmin > 59 ||
                civilDate.getFullYear() !== by ||
                civilDate.getMonth() !== bm - 1 ||
                civilDate.getDate() !== bd ||
                civilDate.getHours() !== bh ||
                civilDate.getMinutes() !== bmin
            ) {
                throw new Error("[PenggilasCoreA] Birth date/time tidak valid.");
            }

            // 1. GEOCODING
            const locationInput =
                rawInput.birthPlace &&
                rawInput.birthPlace.selected
                    ? rawInput.birthPlace.selected
                    : rawInput.birthPlace.query;

            const location = await global.PenggilasLocation.resolve(
                locationInput, null, civilDate
            );

            // 2. TRUE SOLAR TIME (locked rule)
            const solar = global.PenggilasSolar.calculate({
                year: by, month: bm, day: bd, hour: bh, minute: bmin, second: 0,
                utcOffset: location.timeZone.utcOffset,
                longitude: location.coordinates.longitude,
                referenceMeridian: location.referenceMeridian.degrees
            });

            const [tsH, tsM, tsS] = solar.solarTime.trueSolarTime.formatted.split(":").map(Number);
            const baziDateObj = new Date(by, bm - 1, bd);
            baziDateObj.setDate(baziDateObj.getDate() + (solar.dateBoundary.dayShift || 0));

            const baziInput = {
                year: baziDateObj.getFullYear(),
                month: baziDateObj.getMonth() + 1,
                day: baziDateObj.getDate(),
                hour: tsH, minute: tsM, second: tsS
            };

            // 3. JIE QI + KALENDER LUNAR (dihitung pada waktu True Solar yang sama)
            const jieqi = global.PenggilasJieQi.calculate(baziInput);
            const calendar = global.PenggilasCalendar.calculate(baziInput);

            // 4. EMPAT PILAR (EightChar — lunar-javascript)
            const solarObj = global.Solar.fromYmdHms(
                baziInput.year, baziInput.month, baziInput.day,
                baziInput.hour, baziInput.minute, baziInput.second
            );
            const lunar = solarObj.getLunar();
            // PATCH (GILLAS G10): sect di-set EKSPLISIT (bukan bergantung diam-diam
            // ke default pustaka) — supaya hasil tetap reproducible walau versi
            // pustaka lunar-javascript berubah defaultnya di masa depan.
            // PENGGILAS_EIGHTCHAR_SECT = 2 (早子/晚子 "early zi hour" convention:
            // pilar hari ikut berganti pukul 23:00, bukan menunggu 00:00).
            // Ini locked parameter proyek, konsekuensinya didokumentasikan di A17.
            const eightChar = lunar.getEightChar();
            eightChar.setSect(PENGGILAS_EIGHTCHAR_SECT);

            const raw = extractRawPillars(eightChar);
            const timestamp = new Date().toISOString();

            // ENGINE-DRIVEN EXECUTION: all Section-A contract nodes are executed
            // through the Draft dependency plan. Astronomical prerequisites above
            // are preparation only; they do not bypass the contract scheduler.
            // NODE EXECUTION LAYER. The node IDs are NOT template fields.
            // Each node returns the value that will later be mapped to A-fields.
            const nodes = {
                "EXEC_A1": function(){ return buildA1(rawInput, timestamp); },
                "EXEC_A2": function(){ return buildA2(rawInput, location, civilDate, raw.year.ganHanzi); },
                "EXEC_A3": function(){ return buildA3(solar, jieqi, calendar, baziDateObj, lunar); },
                "EXEC_A4": function(){ return buildA4(raw); },
                "EXEC_A5": function(){ return buildA5(raw); },
                "EXEC_A6": function(){ return buildA6(raw); },
                "EXEC_A7": function(){ return buildA7(raw, jieqi, baziInput); },
                "EXEC_A8": function(){ return buildA8(raw); },
                "EXEC_A9": function(){ return buildA9(raw); },
                "EXEC_A10": function(){ return buildA10(raw); },
                "EXEC_A11": function(ctx){ return buildA11(raw, ctx["EXEC_A6"]._dayMasterElem); },
                "EXEC_A12": function(ctx){
                    const a12_5 = buildA12_5(raw);
                    return {
                        A12_1: buildA12_1(raw), A12_2: buildA12_2(raw), A12_3: buildA12_3(raw),
                        A12_4: buildA12_4(raw), A12_5: a12_5,
                        A12_6: buildA12_6(raw), A12_7: buildA12_7(raw, a12_5._heHits),
                        A12_9: buildA12_9(ctx["EXEC_A7"])
                    };
                },
                "EXEC_A13": function(){ return buildA13(eightChar, raw); },
                "EXEC_A14": function(){ return buildA14(raw, eightChar, rawInput, location.timeZone.utcOffset); },
                "EXEC_A15": function(ctx){ return buildA15Node(raw, rawInput, ctx["EXEC_A14"]._seqOk); },
                "EXEC_A16": function(ctx){ return ctx["EXEC_A15"]._A16; },
                "EXEC_A17": function(ctx){ return ctx["EXEC_A15"]._A17; }
            };

            const nodeRun = runFoundationNodes(nodes);
            const n = nodeRun.values;
            const foundationMaster = {
                A1: n["EXEC_A1"], A2: n["EXEC_A2"], A3: n["EXEC_A3"], A4: n["EXEC_A4"],
                A5: n["EXEC_A5"], A6: n["EXEC_A6"], A7: n["EXEC_A7"], A8: n["EXEC_A8"],
                A9: n["EXEC_A9"], A10_1: n["EXEC_A10"].A10_1, A10_2: n["EXEC_A10"].A10_2,
                A10_3: n["EXEC_A10"].A10_3, A10_4: n["EXEC_A10"].A10_4, A10_5: n["EXEC_A10"].A10_5,
                A11: n["EXEC_A11"], A12_1: n["EXEC_A12"].A12_1, A12_2: n["EXEC_A12"].A12_2,
                A12_3: n["EXEC_A12"].A12_3, A12_4: n["EXEC_A12"].A12_4, A12_5: n["EXEC_A12"].A12_5,
                A12_6: n["EXEC_A12"].A12_6, A12_7: n["EXEC_A12"].A12_7,
                A13: n["EXEC_A13"], A14_1: n["EXEC_A14"].A14_1, A14_2: n["EXEC_A14"].A14_2,
                A14_3: n["EXEC_A14"].A14_3, A14_4: n["EXEC_A14"].A14_4,
                A15: n["EXEC_A15"].A15, A16: n["EXEC_A16"], A17: n["EXEC_A17"],
                _nodeExecution: { layer: "NODE", nodes: nodeRun.done, dependencies: nodeRun.dependencies, fields: "A1..A17" }
            };

            // A12.8/A12.9 are template fields, not execution nodes. A12.8 is
            // intentionally unresolved in Core A until Core B determines B13.2;
            // A12.9 is only the Pattern Foundation candidate.
            foundationMaster.A12_8 = buildA12_8();
            foundationMaster.A12_9 = nodeRun.values["EXEC_A12"].A12_9;

            global.masterResult = global.masterResult || {};
            Object.assign(global.masterResult, foundationMaster);
            global.masterResult._engineExecution = foundationMaster._engineExecution;

            // Cache internal (BUKAN bagian kontrak template) supaya Core B/C tidak
            // perlu menghitung ulang astronomi dari nol atau parsing ulang string A4.
            global.PENGGILAS_RAW_CHART = {
                raw: raw,
                eightChar: eightChar,
                rawInput: rawInput,
                dayMasterElem: nodeRun.values["EXEC_A6"]._dayMasterElem
            };

            foundationMaster._engineExecution = foundationMaster._nodeExecution;
            global.masterResult._engineExecution = foundationMaster._engineExecution;
            console.log("[PenggilasCoreA] Foundation Master (A1–A17 / 基础主结果) calculated.");
            return foundationMaster;
        }
    };

    global.PenggilasCoreA = PenggilasCoreA;

})(window);
