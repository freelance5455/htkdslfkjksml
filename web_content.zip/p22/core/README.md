# CORE — Production Engine & MasterResult Authority

## 1. Fungsi
Folder `core/` adalah lapisan utama pengolahan BaZi setelah input dan calculation-support dari `engine/` tersedia.

Core membangun **satu authoritative `window.masterResult`** secara bertahap:

```text
Core A → Core B → Determination → Core C
                    ↓
             FINAL MasterResult
```

Core adalah tempat hasil analitis A/B/C dan determination diproduksi. Core bukan presentation layer.

## 2. Isi folder

| File | Fungsi |
|---|---|
| `coreA.js` | Menghasilkan Foundation Master A1–A17 dan menginisialisasi/mengisi `window.masterResult`. |
| `coreB.js` | Menghasilkan Profile & Structure B1–B17 dari MasterResult yang sudah dibangun Core A; termasuk projection authoritative A12.9 dari B3. |
| `determination.js` | Menyusun determination contract untuk B/C dan projection authoritative A12.8. |
| `coreC.js` | Menghasilkan Temporal Dynamics C1–C7 dengan membaca A/B/determination yang sudah authoritative. |
| `json-mapper.js` | Mengubah `MasterResult` menjadi AI-facing JSON sesuai template; bukan engine BaZi dan bukan authority kedua. |
| `MASTER_RESULT_ARCHITECTURE.md` | Kontrak arsitektur ownership dan alur MasterResult. |
| `AI_JSON_CONTRACT.md` | Kontrak struktur dan batas AI JSON. |

## 3. Dokumentasi terkait

| Dokumen | Kapan dibaca | Status |
|---|---|---|
| `MASTER_RESULT_ARCHITECTURE.md` | Audit ownership, pipeline, dan single-authority `MasterResult`. | Kontrak detail |
| `AI_JSON_CONTRACT.md` | Audit batas mapper, state, evidence, null, dan AI-facing vocabulary. | Kontrak detail |
| `../PRODUCTION_ARCHITECTURE.md` | Memahami wiring produksi lintas folder. | Kontrak root |
| `../DRAFT_TEMPLATE_BAZI_CONTRACT.md` | Memahami struktur A/B/C yang menjadi output contract. | Referensi/kontrak root |

README ini adalah entry point operasional `core/`; dokumen detail di atas tidak dilebur karena memiliki scope kontrak yang berbeda.

## 4. Siapa yang memanggil Core

`app.js` adalah orchestrator production. Urutan runtime utama:

```text
INPUT
 ↓
Core A
 ↓
Core B
 ↓
Determination
 ↓
Core C
 ↓
FINAL MasterResult
```

`index.html` memuat script Core dalam urutan runtime yang diperlukan.

## 5. Input dan dependency

Core membaca input runtime dan menggunakan:

- `engine/*` untuk calculation-support seperti solar time, calendar, Jie Qi, lunar conversion, dan location/timezone;
- `data/*` untuk rules, evidence contracts, sources, state matrices, dan evaluator support;
- hasil tahap sebelumnya melalui **MasterResult yang sama**.

## 6. Output

Output utama Core adalah satu object:

```js
window.masterResult
```

Core A, Core B, Determination, dan Core C **tidak membuat competing result authority**.

## 7. Batas kewenangan

### Boleh
- menghitung dan menyusun hasil A/B/C sesuai logic production yang sudah ada;
- mempertahankan evidence, status, provenance, dan qualification;
- mengisi bagian authoritative dari `MasterResult`;
- membaca hasil tahap sebelumnya.

### Tidak boleh
- membuat MasterResult kedua sebagai authority alternatif;
- membuat `app.js` mengulang determination atau patch A12.8/A12.9;
- membuat presentation-only chart fields sebagai bagian baru dari engine authority;
- mengubah aturan BaZi hanya untuk memenuhi kebutuhan template atau UI.

## 8. Boundary dengan presentation

Setelah Core C selesai, `MasterResult` dianggap sebagai **FINAL ENGINE-PASS MASTER RESULT**.

Presentation consumer membaca result tersebut:

```text
MasterResult
 ├── result-template.js → Human HTML
 ├── json-mapper.js     → AI JSON
 └── ui/chart/chart.js   → Chart UI view-model
```

`core/` tidak bertanggung jawab merender UI.
