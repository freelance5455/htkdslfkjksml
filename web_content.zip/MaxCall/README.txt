Max Call — yangi dizayn prototipi

index.html faylini telefon yoki kompyuter brauzerida oching.

Bu HTML ko‘rinish prototipi. Tugmalar va sahifalar namuna sifatida ishlaydi.
Haqiqiy telefon qo‘ng‘irog‘i, video aloqa, kontakt import/eksporti va foydalanuvchilar
orasidagi MaxChat uchun Android ilova kodi, ruxsatlar, server/akkauntlar va
WebRTC kabi texnik qismlar kerak bo‘ladi. Bu ZIP o‘rnatiladigan APK emas.
