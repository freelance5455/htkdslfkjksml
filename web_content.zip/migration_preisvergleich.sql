-- STEP 15 · Preisvergleich je Variante / Packungsgröße
alter table public.product_prices
  add column if not exists brand text,
  add column if not exists variant text,
  add column if not exists product_key text,
  add column if not exists quantity numeric,
  add column if not exists quantity_unit text,
  add column if not exists normalized_unit_price numeric,
  add column if not exists normalized_unit text;

create index if not exists product_prices_household_product_key_idx
  on public.product_prices(household_id, product_key);
create index if not exists product_prices_household_ean_idx
  on public.product_prices(household_id, ean);
