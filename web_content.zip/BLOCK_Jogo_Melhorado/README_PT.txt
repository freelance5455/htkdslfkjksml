BLOCK — Jogo de blocos offline (versão melhorada)
=================================================

Inclui:
- Paleta de cores mais viva e confortável, com céu azul, verde luminoso e interface verde-azulada.
- 8 tipos de blocos: relva, terra, pedra, madeira, folhas, areia, água e flor.
- Mundo procedural, controlos táteis, teclado, voo, salto, mineração e construção.
- Botões para guardar e carregar o mundo usando o armazenamento local do navegador.
- Pode ser empacotado como aplicação offline se o conversor incluir os ficheiros localmente.

TESTAR
1. Extraia este ZIP.
2. Abra index.html num navegador moderno.
3. No jogo, use as setas para andar, arraste o ecrã para olhar e use Minerar/Colocar.
4. Toque nos blocos da barra inferior para escolher um bloco.
5. Use GUARDAR e CARREGAR para guardar/carregar o mundo neste dispositivo/navegador.

CONVERTER PARA APK
1. Use um conversor HTML para APK/WebView que aceite um ficheiro HTML local.
2. Defina index.html como página inicial e inclua todos os ficheiros dentro do APK.
3. Desative dependências remotas, se o conversor tiver essa opção.
4. Gere o APK e teste-o em modo avião.

LIMITAÇÕES
- Protótipo independente inspirado em jogos de construção com blocos; não é Minecraft.
- O mundo guarda as alterações feitas aos blocos no armazenamento local. A persistência dentro de um APK depende das permissões/configuração do WebView usado pelo conversor.
- Ainda não inclui multijogador, inventário complexo, combate, animais ou missões.
