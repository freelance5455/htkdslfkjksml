NOVIR - مشروع تطبيق Android
===========================

هذه نسخة Android WebView من برنامج NOVIR، وتم ربطها بواجهة اختيار الملفات الأصلية في أندرويد (Storage Access Framework).

طريقة عمل قاعدة البيانات داخل التطبيق:
1) عند اختيار قاعدة بيانات، يفتح منتقي ملفات أندرويد وتختار ملف NOVIR_database.json.
2) يحتفظ التطبيق بإذن الوصول إلى الملف المختار.
3) كل إضافة أو تعديل أو حذف تستدعي كتابة مباشرة إلى نفس URI باستخدام ContentResolver، ولا تنشئ ملف JSON جديداً.
4) إنشاء قاعدة جديدة ينشئ ملف JSON في المكان الذي تختاره.

مهم:
- هذا مجلد مصدر Android وليس ملف APK جاهزاً.
- بيئة إعداد الملفات الحالية لا تحتوي على Android SDK أو Gradle، لذلك لم يكن ممكناً تجميع APK هنا أو اختباره على هاتف فعلي.
- يوجد GitHub Actions workflow داخل .github/workflows/build-apk.yml لبناء APK تلقائياً عند رفع المشروع إلى مستودع GitHub وتشغيل Actions. سيظهر ملف app-debug.apk كـ Artifact باسم NOVIR-debug-APK.
- الحد الأدنى لأندرويد 6.0 (API 23).

ملفات المشروع:
- app/src/main/assets/index.html : برنامج NOVIR المعدل.
- app/src/main/java/com/novir/accounting/MainActivity.java : واجهة Android واختيار وقراءة وكتابة ملف قاعدة البيانات.
