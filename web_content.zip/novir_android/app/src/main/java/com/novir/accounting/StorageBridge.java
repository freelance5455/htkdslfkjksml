package com.novir.accounting;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.util.Log;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class StorageBridge {
    private static final String TAG = "NOVIR_BRIDGE";
    private final MainActivity activity;

    public StorageBridge(MainActivity activity) { this.activity = activity; }

    @JavascriptInterface public void openDatabase() {
        activity.runOnUiThread(() -> {
            try {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES,
                    new String[]{"application/json", "text/json", "application/octet-stream"});
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                activity.startActivityForResult(intent, MainActivity.OPEN_DB);
            } catch (Exception e) {
                Log.e(TAG, "Unable to launch database picker", e);
                activity.showBridgeError("تعذر فتح اختيار ملف قاعدة البيانات: " + e.getMessage());
            }
        });
    }

    @JavascriptInterface public void createDatabase() {
        activity.runOnUiThread(() -> {
            try {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "NOVIR_database.json");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                activity.startActivityForResult(intent, MainActivity.CREATE_DB);
            } catch (Exception e) {
                Log.e(TAG, "Unable to launch create document", e);
                activity.showBridgeError("تعذر فتح شاشة إنشاء ملف قاعدة البيانات: " + e.getMessage());
            }
        });
    }

    @JavascriptInterface public boolean writeDatabase(String json) {
        Uri uri = activity.getDatabaseUri();
        if (uri == null) return false;
        try (OutputStream out = activity.getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) return false;
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Database write failed", e);
            return false;
        }
    }
}
