package com.novir.accounting;

import android.webkit.JavascriptInterface;

public final class NovirAndroidBridge {
    private final MainActivity activity;
    NovirAndroidBridge(MainActivity activity) { this.activity = activity; }

    @JavascriptInterface public void openDatabase() {
        activity.runOnUiThread(() -> activity.launchPicker(false));
    }

    @JavascriptInterface public void createDatabase() {
        activity.runOnUiThread(() -> activity.launchPicker(true));
    }

    @JavascriptInterface public boolean writeDatabase(String json) {
        return activity.writeJson(json);
    }

    @JavascriptInterface public String ping() {
        return "NOVIR_BRIDGE_OK";
    }
}
