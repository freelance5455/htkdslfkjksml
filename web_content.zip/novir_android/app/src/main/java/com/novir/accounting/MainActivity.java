package com.novir.accounting;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.util.Log;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int OPEN_DB = 501;
    private static final int CREATE_DB = 502;
    private static final String TAG = "NOVIR";
    private WebView web;
    private Uri databaseUri;
    private String databaseName = "NOVIR_database.json";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage m) {
                Log.e(TAG, m.message() + " [line " + m.lineNumber() + "]");
                return true;
            }
        });
        web.addJavascriptInterface(new NovirAndroidBridge(this), "AndroidStorage");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    void launchPicker(boolean create) {
        try {
            Intent i = new Intent(create ? Intent.ACTION_CREATE_DOCUMENT : Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(create ? "application/json" : "*/*");
            if (!create) i.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[]{"application/json", "text/json", "application/octet-stream"});
            else i.putExtra(Intent.EXTRA_TITLE, "NOVIR_database.json");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                       Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                       Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, create ? CREATE_DB : OPEN_DB);
        } catch (Exception e) {
            Log.e(TAG, "Picker launch failed", e);
            Toast.makeText(this, "تعذر فتح مدير الملفات: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    boolean writeJson(String json) {
        if (databaseUri == null) return false;
        try (OutputStream out = getContentResolver().openOutputStream(databaseUri, "wt")) {
            if (out == null) return false;
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Database write failed", e);
            return false;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode != OPEN_DB && requestCode != CREATE_DB) ||
            resultCode != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        try {
            int f = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, f);
        } catch (Exception e) { Log.w(TAG, "Persistable permission unavailable", e); }

        databaseUri = uri;
        String seg = uri.getLastPathSegment();
        databaseName = (seg == null || seg.isEmpty()) ? "NOVIR_database.json" : seg;

        if (requestCode == OPEN_DB) {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream b = new ByteArrayOutputStream()) {
                if (in == null) throw new IOException("Cannot read selected file");
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) != -1) b.write(buf, 0, n);
                String json = new String(b.toByteArray(), StandardCharsets.UTF_8);
                String js = "window.onAndroidDatabaseLoaded(" +
                    org.json.JSONObject.quote(json) + "," +
                    org.json.JSONObject.quote(databaseName) + ");";
                web.post(() -> web.evaluateJavascript(js, null));
            } catch (Exception e) {
                Log.e(TAG, "Database read failed", e);
                Toast.makeText(this, "تعذر قراءة قاعدة البيانات: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            String empty = "{\"app\":\"Novir account system\",\"version\":1,\"data\":{\"clients\":[],\"products\":[],\"raw\":[],\"orders\":[],\"payments\":[],\"journal\":[]}}";
            boolean ok = writeJson(empty);
            String js = "window.onAndroidDatabaseCreated(" + ok + "," +
                org.json.JSONObject.quote(databaseName) + ");";
            web.post(() -> web.evaluateJavascript(js, null));
        }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){if(typeof go==='function'){go('home');return 'handled';}return 'no';})()", v -> {
            if ("\"no\"".equals(v)) super.onBackPressed();
        });
    }
}
