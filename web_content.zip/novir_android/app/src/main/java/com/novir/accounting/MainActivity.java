package com.novir.accounting;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ConsoleMessage;
import android.webkit.WebSettings;
import android.util.Log;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    public static final int OPEN_DB = 501, CREATE_DB = 502;
    private static final String TAG = "NOVIR";
    private WebView web;
    private Uri databaseUri;
    private String databaseName = "NOVIR_database.json";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage msg) {
                Log.e(TAG, msg.message() + " at " + msg.sourceId() + ":" + msg.lineNumber());
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new StorageBridge(this), "AndroidStorage");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    Uri getDatabaseUri() { return databaseUri; }
    void showBridgeError(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode != OPEN_DB && requestCode != CREATE_DB) ||
            resultCode != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        int flags = data.getFlags() &
            (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(uri, flags); }
        catch (Exception e) { Log.w(TAG, "Persistable permission not granted", e); }

        databaseUri = uri;
        String segment = uri.getLastPathSegment();
        databaseName = (segment == null || segment.isEmpty()) ? "NOVIR_database.json" : segment;

        if (requestCode == OPEN_DB) {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                if (in == null) throw new IOException("تعذر فتح الملف المحدد");
                byte[] bytes = new byte[8192]; int count;
                while ((count = in.read(bytes)) != -1) buffer.write(bytes, 0, count);
                String json = new String(buffer.toByteArray(), StandardCharsets.UTF_8);
                String js = "window.onAndroidDatabaseLoaded(" +
                    org.json.JSONObject.quote(json) + "," +
                    org.json.JSONObject.quote(databaseName) + ");";
                web.post(() -> web.evaluateJavascript(js, null));
            } catch (Exception e) {
                Log.e(TAG, "Database read failed", e);
                showBridgeError("تعذر قراءة قاعدة البيانات: " + e.getMessage());
            }
        } else {
            String empty = "{\"app\":\"Novir account system\",\"version\":1,\"data\":{\"clients\":[],\"products\":[],\"raw\":[],\"orders\":[],\"payments\":[],\"journal\":[]}}";
            boolean ok = new StorageBridge(this).writeDatabase(empty);
            String js = "window.onAndroidDatabaseCreated(" + ok + "," +
                org.json.JSONObject.quote(databaseName) + ");";
            web.post(() -> web.evaluateJavascript(js, null));
        }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){if(typeof go==='function'){go('home');return 'handled';}return 'no';})()", value -> {
            if ("\"no\"".equals(value)) super.onBackPressed();
        });
    }
}
