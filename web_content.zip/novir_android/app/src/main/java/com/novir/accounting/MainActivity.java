package com.novir.accounting;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.widget.Toast;
import android.util.Log;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int OPEN_DB = 501, CREATE_DB = 502;
    private static final String TAG = "NOVIR";
    private WebView web;
    private Uri databaseUri;
    private String databaseName = "NOVIR_database.json";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage msg) {
                Log.e(TAG, msg.message() + " -- line " + msg.lineNumber());
                return true;
            }
        });
        web.addJavascriptInterface(new StorageBridge(this), "AndroidStorage");
        WebView.setWebContentsDebuggingEnabled(true);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public static final class StorageBridge {
        private final MainActivity activity;
        StorageBridge(MainActivity a) { activity = a; }

        @JavascriptInterface public void openDatabase() {
            activity.runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "application/octet-stream"});
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    activity.startActivityForResult(i, OPEN_DB);
                } catch (Exception e) {
                    Log.e(TAG, "openDatabase failed", e);
                    Toast.makeText(activity, "تعذر فتح مدير الملفات: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void createDatabase() {
            activity.runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, "NOVIR_database.json");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    activity.startActivityForResult(i, CREATE_DB);
                } catch (Exception e) {
                    Log.e(TAG, "createDatabase failed", e);
                    Toast.makeText(activity, "تعذر فتح شاشة حفظ الملف: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public boolean writeDatabase(String json) {
            Uri target = activity.databaseUri;
            if (target == null) return false;
            try (OutputStream out = activity.getContentResolver().openOutputStream(target, "wt")) {
                if (out == null) return false;
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
                return true;
            } catch (Exception e) {
                Log.e(TAG, "writeDatabase failed", e);
                return false;
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode != OPEN_DB && requestCode != CREATE_DB) || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception e) { Log.w(TAG, "Persist permission unavailable", e); }
        databaseUri = uri;
        String segment = uri.getLastPathSegment();
        databaseName = (segment == null || segment.isEmpty()) ? "NOVIR_database.json" : segment;

        if (requestCode == OPEN_DB) {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                if (in == null) throw new IOException("تعذر فتح الملف");
                byte[] chunk = new byte[8192]; int n;
                while ((n = in.read(chunk)) > 0) buffer.write(chunk, 0, n);
                String json = new String(buffer.toByteArray(), StandardCharsets.UTF_8);
                String js = "window.onAndroidDatabaseLoaded(" + org.json.JSONObject.quote(json) + "," + org.json.JSONObject.quote(databaseName) + ");";
                web.post(() -> web.evaluateJavascript(js, null));
            } catch (Exception e) {
                Log.e(TAG, "read database failed", e);
                Toast.makeText(this, "تعذر قراءة قاعدة البيانات: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            String empty = "{\"app\":\"Novir account system\",\"version\":1,\"data\":{\"clients\":[],\"products\":[],\"raw\":[],\"orders\":[],\"payments\":[],\"journal\":[]}}";
            boolean ok = new StorageBridge(this).writeDatabase(empty);
            String js = "window.onAndroidDatabaseCreated(" + ok + "," + org.json.JSONObject.quote(databaseName) + ");";
            web.post(() -> web.evaluateJavascript(js, null));
        }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){if(typeof go==='function'){go('home');return 'handled';}return 'no';})()", value -> {
            if ("\"no\"".equals(value)) superOnBack();
        });
    }
    private void superOnBack() { super.onBackPressed(); }
}
