package com.novir.accounting;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int OPEN_DB = 501;
    private static final int CREATE_DB = 502;
    private WebView web;
    private Uri databaseUri;
    private String databaseName = "NOVIR_database.json";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new StorageBridge(), "AndroidStorage");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class StorageBridge {
        @JavascriptInterface public void openDatabase() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, OPEN_DB);
            });
        }
        @JavascriptInterface public void createDatabase() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, "NOVIR_database.json");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, CREATE_DB);
            });
        }
        @JavascriptInterface public boolean writeDatabase(String json) {
            if (databaseUri == null) return false;
            try (OutputStream out = getContentResolver().openOutputStream(databaseUri, "wt")) {
                if (out == null) return false;
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
                return true;
            } catch (Exception e) { return false; }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) { }
        databaseUri = uri;
        databaseName = uri.getLastPathSegment() == null ? "NOVIR_database.json" : uri.getLastPathSegment();
        if (requestCode == OPEN_DB) {
            try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                byte[] chunk = new byte[8192]; int n;
                while ((n = in.read(chunk)) > 0) buffer.write(chunk, 0, n);
                String json = new String(buffer.toByteArray(), StandardCharsets.UTF_8);
                String js = "window.onAndroidDatabaseLoaded(" + org.json.JSONObject.quote(json) + "," + org.json.JSONObject.quote(databaseName) + ");";
                web.post(() -> web.evaluateJavascript(js, null));
            } catch (Exception e) { Toast.makeText(this, "تعذر قراءة قاعدة البيانات", Toast.LENGTH_LONG).show(); }
        } else if (requestCode == CREATE_DB) {
            String empty = "{\"app\":\"Novir account system\",\"version\":1,\"data\":{\"clients\":[],\"products\":[],\"raw\":[],\"orders\":[],\"payments\":[],\"journal\":[]}}";
            boolean ok = new StorageBridge().writeDatabase(empty);
            String js = "window.onAndroidDatabaseCreated(" + ok + "," + org.json.JSONObject.quote(databaseName) + ");";
            web.post(() -> web.evaluateJavascript(js, null));
        }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){if(typeof go==='function'){go('home');return 'handled';}return 'no';})()", value -> {
            if ("\"no\"".equals(value)) superOnBack();
        });
    }
    private void superOnBack() { super.onBackPressed(); }
}
