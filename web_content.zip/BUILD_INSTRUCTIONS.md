# Jay Jagannath Puja Committee Android Project
Produced by Mr Biswa.

Firebase Android configuration supplied by you has been added as `app/google-services.json`.
Android package: `com.mrbiswa.jayjagannathgallery`.

## Build APK
1. Open this folder in Android Studio on a computer.
2. Install Android SDK Platform 35 when prompted and let Gradle sync.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

## Firebase note
The provided `google-services.json` configures the Android Firebase app, but the bundled web app uses Firebase Web SDK configuration in `app/src/main/assets/www/firebase-config.js` and loads from Android local assets. To make cloud chat/storage reliable, configure a Firebase Web App and host the web app on HTTPS, then point the Android WebView at that HTTPS URL, or implement native Firebase SDK features. You still must enable Authentication (Email/Password), Firestore, and Storage in the Firebase console and deploy the included security rules.

Entry password: `Jay jagannath` (case-sensitive). This is only a basic UI gate, not a secure authentication mechanism.
