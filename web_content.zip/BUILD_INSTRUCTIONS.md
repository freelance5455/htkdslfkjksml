# Phone-Only Build

Requirements:
- Android Studio
- Android SDK 35
- JDK supported by the installed Android Studio version

1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Select the `app` configuration.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install `app/build/outputs/apk/debug/app-debug.apk` on Android.

No VPS, Python, MT5 desktop terminal, or MQL5 compilation is required for this edition.
