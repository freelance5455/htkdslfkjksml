# Build Android APK

1. Open this folder in Android Studio.
2. Allow Gradle sync and install any requested SDK components.
3. Select the `app` configuration.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK: `app/build/outputs/apk/debug/app-debug.apk`.

The Android app requires internet access and talks to the VPS bridge over HTTPS.
