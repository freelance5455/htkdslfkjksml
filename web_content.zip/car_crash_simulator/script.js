let scene, camera, renderer, playerCar;
let aiCars = [];
let obstacles = [];
let keys = { up: false, down: false, left: false, right: false, brake: false };
let playerSpeed = 0;
let maxSpeed = 0.8;
let acceleration = 0.01;
let deceleration = 0.015;
let isGameStarted = false;

document.getElementById('start-btn').addEventListener('click', () => {
    document.getElementById('menu-screen').classList.add('hidden');
    document.getElementById('game-screen').classList.remove('hidden');
    initGame();
    isGameStarted = true;
    animate();
});

function initGame() {
    // ایجاد صحنه گرافیکی
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb); // آسمان طبیعی
    scene.fog = new THREE.FogExp2(0x87ceeb, 0.015);

    // دوربین سه‌بعدی تعقیب خودرو
    camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);

    // رندرور با کیفیت بالا و سایه‌پردازی
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    document.body.appendChild(renderer.domElement);

    // نورپردازی محیطی و خورشید
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(50, 100, 50);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    scene.add(dirLight);

    // ایجاد زمین (جاده و محیط اطراف)
    createEnvironment();

    // ایجاد خودروی بازیکن
    playerCar = createCar(0xff3333, true);
    scene.add(playerCar);

    // ایجاد خودروهای هوشمند (AI Traffic)
    for (let i = 0; i < 5; i++) {
        let ai = createCar(0x3366ff, false);
        ai.position.set((Math.random() - 0.5) * 15, 0, -30 - (i * 25));
        ai.userData = { speed: 0.3 + Math.random() * 0.2 };
        aiCars.push(ai);
        scene.add(ai);
    }

    // اتصال کنترل‌های لمسی موبایل
    setupMobileControls();

    // تنظیم ریسپانسیو صفحه
    window.addEventListener('resize', onWindowResize, false);
}

function createEnvironment() {
    // جاده
    const roadGeo = new THREE.PlaneGeometry(20, 1000);
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x333333, roughness: 0.8 });
    const road = new THREE.Mesh(roadGeo, roadMat);
    road.rotation.x = -Math.PI / 2;
    road.receiveShadow = true;
    scene.add(road);

    // چمن دو طرف جاده
    const grassGeo = new THREE.PlaneGeometry(200, 1000);
    const grassMat = new THREE.MeshStandardMaterial({ color: 0x4caf50, roughness: 0.9 });
    const grassLeft = new THREE.Mesh(grassGeo, grassMat);
    grassLeft.rotation.x = -Math.PI / 2;
    grassLeft.position.set(-110, -0.1, 0);
    grassLeft.receiveShadow = true;
    scene.add(grassLeft);

    const grassRight = new THREE.Mesh(grassGeo, grassMat);
    grassRight.rotation.x = -Math.PI / 2;
    grassRight.position.set(110, -0.1, 0);
    grassRight.receiveShadow = true;
    scene.add(grassRight);
}

function createCar(colorHex, isPlayer) {
    const carGroup = new THREE.Group();

    // بدنه اصلی خودرو
    const bodyGeo = new THREE.BoxGeometry(2, 0.8, 4);
    const bodyMat = new THREE.MeshStandardMaterial({ color: colorHex, roughness: 0.3, metalness: 0.8 });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = 0.6;
    body.castShadow = true;
    carGroup.add(body);

    // کابین خودرو
    const cabinGeo = new THREE.BoxGeometry(1.6, 0.6, 2);
    const cabinMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.1 });
    const cabin = new THREE.Mesh(cabinGeo, cabinMat);
    cabin.position.set(0, 1.2, -0.2);
    cabin.castShadow = true;
    carGroup.add(cabin);

    // چرخ‌ها
    const wheelGeo = new THREE.CylinderGeometry(0.4, 0.4, 0.3, 16);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x222222 });

    const wheelPositions = [
        [-1.1, 0.4, 1.2], [1.1, 0.4, 1.2],
        [-1.1, 0.4, -1.2], [1.1, 0.4, -1.2]
    ];

    wheelPositions.forEach(pos => {
        const wheel = new THREE.Mesh(wheelGeo, wheelMat);
        wheel.rotation.z = Math.PI / 2;
        wheel.position.set(...pos);
        wheel.castShadow = true;
        carGroup.add(wheel);
    });

    carGroup.userData = { isPlayer: isPlayer, damaged: false };
    return carGroup;
}

function setupMobileControls() {
    const bindButton = (id, keyName) => {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('touchstart', (e) => { e.preventDefault(); keys[keyName] = true; });
        el.addEventListener('touchend', (e) => { e.preventDefault(); keys[keyName] = false; });
        el.addEventListener('mousedown', () => { keys[keyName] = true; });
        el.addEventListener('mouseup', () => { keys[keyName] = false; });
    };

    bindButton('btn-up', 'up');
    bindButton('btn-brake', 'brake');
    bindButton('btn-left', 'left');
    bindButton('btn-right', 'right');
}

function animate() {
    if (!isGameStarted) return;
    requestAnimationFrame(animate);

    // حرکت خودروی بازیکن
    if (keys.up) {
        playerSpeed = Math.min(playerSpeed + acceleration, maxSpeed);
    } else if (keys.brake) {
        playerSpeed = Math.max(playerSpeed - deceleration * 2, 0);
    } else {
        playerSpeed = Math.max(playerSpeed - deceleration, 0);
    }

    if (keys.left) playerCar.position.x -= 0.15;
    if (keys.right) playerCar.position.x += 0.15;

    // محدود کردن حرکت داخل جاده
    playerCar.position.x = Math.max(Math.min(playerCar.position.x, 9), -9);
    playerCar.position.z -= playerSpeed;

    // به‌روزرسانی پنل اطلاعات سرعت
    document.getElementById('speed-val').innerText = Math.round(playerSpeed * 180);

    // دوربین تعقیب‌کننده نرم (Smooth Camera Follow)
    camera.position.x = playerCar.position.x * 0.5;
    camera.position.y = playerCar.position.y + 4;
    camera.position.z = playerCar.position.z + 8;
    camera.lookAt(playerCar.position.x, playerCar.position.y, playerCar.position.z - 3);

    // هوش مصنوعی ماشین‌های رقیب و شبیه‌ساز تصادف
    aiCars.forEach(ai => {
        ai.position.z -= ai.userData.speed;

        // بازگشت ماشین هوش مصنوعی به جلو در صورت عبور از بازیکن
        if (ai.position.z > playerCar.position.z + 20) {
            ai.position.z = playerCar.position.z - 150 - Math.random() * 50;
            ai.position.x = (Math.random() - 0.5) * 16;
            ai.userData.damaged = false;
        }

        // سیستم تشخیص تصادف فیزیکی (Collision Detection)
        const distance = playerCar.position.distanceTo(ai.position);
        if (distance < 2.5 && !playerCar.userData.damaged) {
            playerCar.userData.damaged = true;
            playerSpeed *= 0.2; // افت شدید سرعت هنگام تصادف
            
            // شبیه‌ساز دفرمه شدن و تغییر شکل بدنه ماشین هنگام تصادف
            playerCar.scale.set(1.3, 0.6, 0.7);
            document.getElementById('damage-val').innerText = 'تصادف شدید (دفرمه شده)';
            document.getElementById('damage-val').style.color = '#ff3333';
            document.getElementById('ai-status').innerText = 'واکنش هوش مصنوعی به تصادف!';
        }
    });

    renderer.render(scene, camera);
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}
