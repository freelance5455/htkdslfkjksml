/* ============================================================
   FINANÇAS PESSOAIS 2027 — Lógica da aplicação
   JavaScript Vanilla · SPA · Persistência em localStorage
   ============================================================ */
(function () {
  'use strict';

  /* ==========================================================
     1. CONSTANTES
     ========================================================== */
  var ANO          = 2027;
  var TOTAL_DIAS   = 365;
  var MESES        = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho',
                      'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  var SEMANA       = ['Domingo','Segunda-feira','Terça-feira','Quarta-feira',
                      'Quinta-feira','Sexta-feira','Sábado'];
  var INICIAIS     = ['D','S','T','Q','Q','S','S'];
  var TIPOS        = ['fixos','pessoal','familiar','diversos'];
  var LINHAS_INI   = 4;
  var K_NOME       = 'financas2027.nome';
  var K_DIA        = 'financas2027.dia_';

  /* ==========================================================
     2. MAPA DOS 365 DIAS
     ========================================================== */
  var dias = [];
  (function construirMapa() {
    for (var m = 0; m < 12; m++) {
      var totalMes = new Date(ANO, m + 1, 0).getDate();
      for (var d = 1; d <= totalMes; d++) {
        dias.push({
          seq:    dias.length + 1,
          dia:    d,
          mes:    m,
          semana: new Date(ANO, m, d).getDay()
        });
      }
    }
  })();

  /* ==========================================================
     3. ESTADO
     ========================================================== */
  var diaAtual   = 1;
  var diaState   = null;
  var timerSave  = null;
  var timerToast = null;

  /* ==========================================================
     4. HELPERS DE VALOR
     ========================================================== */
  function parseValor(str) {
    if (typeof str === 'number') return str;
    if (!str) return 0;
    str = String(str).trim().replace(/\s/g, '').replace(/€/g, '');
    if (str.indexOf(',') > -1 && str.indexOf('.') > -1) {
      // Ambos presentes: assume formato pt-PT (1.234,56)
      str = str.replace(/\./g, '').replace(',', '.');
    } else {
      str = str.replace(',', '.');
    }
    var n = parseFloat(str);
    return isNaN(n) ? 0 : n;
  }

  function formatarValor(n) {
    if (typeof n !== 'number' || isNaN(n)) n = 0;
    try {
      return new Intl.NumberFormat('pt-PT', {
        style: 'currency', currency: 'EUR',
        minimumFractionDigits: 2, maximumFractionDigits: 2
      }).format(n);
    } catch (e) {
      return n.toFixed(2).replace('.', ',') + ' €';
    }
  }

  function somaLista(arr) {
    return arr.reduce(function (acc, it) {
      return acc + (parseValor(it && it.valor) || 0);
    }, 0);
  }

  /* ==========================================================
     5. PERSISTÊNCIA
     ========================================================== */
  function novaLista() {
    var arr = [];
    for (var i = 0; i < LINHAS_INI; i++) {
      arr.push({ desc: '', valor: 0 });
    }
    return arr;
  }

  function defaultDia() {
    return {
      rendimentoMensal: 0,
      valorExtra: 0,
      fixos: novaLista(),
      pessoal: novaLista(),
      familiar: novaLista(),
      diversos: novaLista()
    };
  }

  function normalizar(obj) {
    var base = defaultDia();
    if (!obj || typeof obj !== 'object') return base;

    base.rendimentoMensal = parseValor(obj.rendimentoMensal);
    base.valorExtra       = parseValor(obj.valorExtra);

    TIPOS.forEach(function (tipo) {
      var arr = obj[tipo];
      if (Array.isArray(arr) && arr.length > 0) {
        base[tipo] = arr.map(function (it) {
          return {
            desc: (it && typeof it.desc === 'string') ? it.desc : '',
            valor: parseValor(it && it.valor)
          };
        });
      }
    });
    return base;
  }

  function carregarDia(seq) {
    try {
      var raw = localStorage.getItem(K_DIA + seq);
      if (!raw) return defaultDia();
      return normalizar(JSON.parse(raw));
    } catch (e) {
      return defaultDia();
    }
  }

  function guardarDia(seq, s) {
    try { localStorage.setItem(K_DIA + seq, JSON.stringify(s)); return true; }
    catch (e) { return false; }
  }

  function diaTemRegisto(seq) {
    try {
      var raw = localStorage.getItem(K_DIA + seq);
      if (!raw) return false;
      var d = JSON.parse(raw);
      if (!d || typeof d !== 'object') return false;

      if (parseValor(d.rendimentoMensal) > 0) return true;
      if (parseValor(d.valorExtra) > 0) return true;

      for (var i = 0; i < TIPOS.length; i++) {
        var arr = d[TIPOS[i]] || [];
        for (var j = 0; j < arr.length; j++) {
          var item = arr[j];
          if (!item) continue;
          if (item.desc && String(item.desc).trim()) return true;
          if (parseValor(item.valor) > 0) return true;
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  function agendarGuardar() {
    if (!diaState) return;
    clearTimeout(timerSave);
    timerSave = setTimeout(function () {
      var ok = guardarDia(diaAtual, diaState);
      mostrarEstado(ok ? 'Guardado automaticamente ✓' : 'Não foi possível guardar.');
      actualizarMarcadoresCalendario();
    }, 400);
  }

  function mostrarEstado(msg) {
    if (!elEstado) return;
    elEstado.textContent = msg;
    elEstado.classList.add('visivel');
    clearTimeout(timerToast);
    timerToast = setTimeout(function () {
      elEstado.classList.remove('visivel');
    }, 1800);
  }

  /* ==========================================================
     6. REFERÊNCIAS DOM
     ========================================================== */
  var elNome       = document.getElementById('nomeTitular');
  var elMeses      = document.getElementById('meses');
  var elDataDia    = document.getElementById('dataDia');
  var elDataMes    = document.getElementById('dataMes');
  var elProgresso  = document.getElementById('diaProgresso');
  var elRendMensal = document.getElementById('rendimentoMensal');
  var elValorExtra = document.getElementById('valorExtra');
  var elTotalMes   = document.getElementById('totalMes');
  var elEstado     = document.getElementById('estado');
  var btnVoltar    = document.getElementById('btnVoltar');
  var btnAnterior  = document.getElementById('btnAnterior');
  var btnSeguinte  = document.getElementById('btnSeguinte');

  var elBodies = {
    fixos:    document.getElementById('body-fixos'),
    pessoal:  document.getElementById('body-pessoal'),
    familiar: document.getElementById('body-familiar'),
    diversos: document.getElementById('body-diversos')
  };

  var elTotais = {
    fixos:    document.getElementById('total1'),
    pessoal:  document.getElementById('total2'),
    familiar: document.getElementById('total3'),
    diversos: document.getElementById('total4')
  };

  var elResumo = {
    mes:    document.getElementById('resumoMes'),
    gastos: document.getElementById('resumoGastos'),
    saldo:  document.getElementById('resumoSaldo')
  };

  var botoesDia = new Map();
  var botoesAdicionar = document.querySelectorAll('.btn-adicionar');

  /* ==========================================================
     7. NAVEGAÇÃO SPA
     ========================================================== */
  function mostrarVista(nome) {
    var vistas = document.querySelectorAll('.vista');
    for (var i = 0; i < vistas.length; i++) {
      vistas[i].classList.toggle('activa', vistas[i].id === 'vista-' + nome);
    }
    window.scrollTo(0, 0);
  }

  /* ==========================================================
     8. CALENDÁRIO (civil: 1-31 por mês)
     ========================================================== */
  function construirCalendario() {
    var frag = document.createDocumentFragment();
    var inicioMes = 0;

    for (var m = 0; m < 12; m++) {
      var card = document.createElement('div');
      card.className = 'mes';

      var h = document.createElement('h3');
      h.className = 'mes-nome';
      h.textContent = MESES[m];
      card.appendChild(h);

      var grid = document.createElement('div');
      grid.className = 'mes-grid';

      for (var i = 0; i < 7; i++) {
        var cab = document.createElement('span');
        cab.className = 'mes-dow';
        cab.textContent = INICIAIS[i];
        cab.title = SEMANA[i];
        grid.appendChild(cab);
      }

      var primeiroDow = new Date(ANO, m, 1).getDay();
      for (var v = 0; v < primeiroDow; v++) {
        var vazio = document.createElement('span');
        vazio.className = 'mes-vazio';
        vazio.setAttribute('aria-hidden', 'true');
        grid.appendChild(vazio);
      }

      var totalMes = new Date(ANO, m + 1, 0).getDate();
      for (var d = 1; d <= totalMes; d++) {
        (function (diaCivil, mesIdx, seq) {
          var info = dias[seq - 1];
          var btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'mes-dia';
          btn.dataset.dia = String(seq);
          btn.textContent = String(diaCivil);
          btn.title = 'Dia ' + seq + ' de ' + TOTAL_DIAS + ' · ' +
                      diaCivil + ' de ' + MESES[mesIdx] + ' de ' + ANO +
                      ' · ' + SEMANA[info.semana];
          btn.setAttribute('aria-label',
            'Dia ' + seq + ' de ' + TOTAL_DIAS + ', ' + SEMANA[info.semana] +
            ', ' + diaCivil + ' de ' + MESES[mesIdx] + ' de ' + ANO);
          btn.addEventListener('click', function () { abrirDia(seq); });
          botoesDia.set(seq, btn);
          grid.appendChild(btn);
        })(d, m, inicioMes + d);
      }

      inicioMes += totalMes;
      card.appendChild(grid);
      frag.appendChild(card);
    }

    elMeses.appendChild(frag);
    actualizarMarcadoresCalendario();
    marcarHoje();
  }

  function actualizarMarcadoresCalendario() {
    botoesDia.forEach(function (btn, seq) {
      btn.classList.toggle('tem-registo', diaTemRegisto(seq));
    });
  }

  function marcarHoje() {
    var hoje = new Date();
    if (hoje.getFullYear() !== ANO) return;
    for (var i = 0; i < dias.length; i++) {
      if (dias[i].mes === hoje.getMonth() && dias[i].dia === hoje.getDate()) {
        var b = botoesDia.get(dias[i].seq);
        if (b) b.classList.add('hoje');
        return;
      }
    }
  }

  /* ==========================================================
     9. ABRIR DIA
     ========================================================== */
  function abrirDia(seq) {
    if (seq < 1) seq = 1;
    if (seq > TOTAL_DIAS) seq = TOTAL_DIAS;

    diaAtual = seq;
    diaState = carregarDia(seq);

    var info = dias[seq - 1];
    elDataDia.textContent   = String(info.dia).padStart(2, '0');
    elDataMes.textContent   = String(info.mes + 1).padStart(2, '0');
    elProgresso.textContent = 'Dia ' + seq + ' de ' + TOTAL_DIAS;

    elRendMensal.value = diaState.rendimentoMensal ? formatarInput(diaState.rendimentoMensal) : '';
    elValorExtra.value = diaState.valorExtra ? formatarInput(diaState.valorExtra) : '';

    TIPOS.forEach(function (tipo) { renderTabela(tipo); });

    actualizarTotais();

    btnAnterior.disabled = seq <= 1;
    btnSeguinte.disabled = seq >= TOTAL_DIAS;

    mostrarVista('dia');
  }

  function formatarInput(n) {
    return n.toFixed(2).replace('.', ',');
  }

  /* ==========================================================
     10. RENDER DAS TABELAS
     ========================================================== */
  function renderTabela(tipo, focarUltima) {
    var container = elBodies[tipo];
    if (!container) return;
    container.innerHTML = '';

    diaState[tipo].forEach(function (item, idx) {
      var tr = document.createElement('tr');

      // Descrição
      var tdDesc = document.createElement('td');
      var inpDesc = document.createElement('input');
      inpDesc.type = 'text';
      inpDesc.placeholder = 'Descrição…';
      inpDesc.value = item.desc || '';
      inpDesc.setAttribute('aria-label', 'Descrição ' + (idx + 1));
      inpDesc.addEventListener('input', function () {
        diaState[tipo][idx].desc = inpDesc.value;
        agendarGuardar();
      });
      tdDesc.appendChild(inpDesc);

      // Valor
      var tdVal = document.createElement('td');
      var inpVal = document.createElement('input');
      inpVal.type = 'text';
      inpVal.className = 'valor-input';
      inpVal.inputMode = 'decimal';
      inpVal.placeholder = '0,00';
      inpVal.value = item.valor ? formatarInput(item.valor) : '';
      inpVal.setAttribute('aria-label', 'Valor ' + (idx + 1));
      inpVal.addEventListener('input', function () {
        diaState[tipo][idx].valor = parseValor(inpVal.value);
        actualizarTotais();
        agendarGuardar();
      });
      tdVal.appendChild(inpVal);

      // Remover
      var tdRem = document.createElement('td');
      var btnRem = document.createElement('button');
      btnRem.type = 'button';
      btnRem.className = 'btn-remover';
      btnRem.innerHTML = '×';
      btnRem.setAttribute('aria-label', 'Remover linha ' + (idx + 1));
      btnRem.addEventListener('click', function () {
        removerLinha(tipo, idx);
      });
      tdRem.appendChild(btnRem);

      tr.appendChild(tdDesc);
      tr.appendChild(tdVal);
      tr.appendChild(tdRem);
      container.appendChild(tr);
    });

    if (focarUltima) {
      var lastRow = container.lastChild;
      if (lastRow) {
        var firstInput = lastRow.querySelector('input');
        if (firstInput) firstInput.focus();
      }
    }
  }

  function adicionarLinha(tipo) {
    diaState[tipo].push({ desc: '', valor: 0 });
    renderTabela(tipo, true);
    agendarGuardar();
  }

  function removerLinha(tipo, idx) {
    if (diaState[tipo].length <= 1) {
      diaState[tipo][0] = { desc: '', valor: 0 };
    } else {
      diaState[tipo].splice(idx, 1);
    }
    renderTabela(tipo);
    actualizarTotais();
    agendarGuardar();
  }

  /* ==========================================================
     11. CÁLCULOS
     ========================================================== */
  function actualizarTotais() {
    var totalMes = (diaState.rendimentoMensal || 0) + (diaState.valorExtra || 0);

    var t1 = somaLista(diaState.fixos);
    var t2 = somaLista(diaState.pessoal);
    var t3 = somaLista(diaState.familiar);
    var t4 = somaLista(diaState.diversos);
    var gastosTotais = t1 + t2 + t3 + t4;

    var saldo = totalMes - gastosTotais;

    // Cabeçalho
    elTotalMes.textContent = formatarValor(totalMes);

    // Subtotais
    elTotais.fixos.textContent    = formatarValor(t1);
    elTotais.pessoal.textContent  = formatarValor(t2);
    elTotais.familiar.textContent = formatarValor(t3);
    elTotais.diversos.textContent = formatarValor(t4);

    // Resumo
    elResumo.mes.textContent    = formatarValor(totalMes);
    elResumo.gastos.textContent = formatarValor(gastosTotais);
    elResumo.saldo.textContent  = formatarValor(saldo);
    elResumo.saldo.classList.toggle('negativo', saldo < 0);
  }

  /* ==========================================================
     12. EVENTOS GERAIS
     ========================================================== */
  // Nome do titular
  try { elNome.value = localStorage.getItem(K_NOME) || ''; } catch (e) {}
  elNome.addEventListener('input', function () {
    try { localStorage.setItem(K_NOME, elNome.value); } catch (e) {}
  });

  // Rendimento mensal + valor extra
  elRendMensal.addEventListener('input', function () {
    if (!diaState) return;
    diaState.rendimentoMensal = parseValor(elRendMensal.value);
    actualizarTotais();
    agendarGuardar();
  });
  elValorExtra.addEventListener('input', function () {
    if (!diaState) return;
    diaState.valorExtra = parseValor(elValorExtra.value);
    actualizarTotais();
    agendarGuardar();
  });

  // Botões "Adicionar linha"
  botoesAdicionar.forEach(function (b) {
    b.addEventListener('click', function () {
      adicionarLinha(b.dataset.tabela);
    });
  });

  // Navegação
  btnVoltar.addEventListener('click', function () {
    actualizarMarcadoresCalendario();
    mostrarVista('capa');
  });
  btnAnterior.addEventListener('click', function () {
    if (diaAtual > 1) abrirDia(diaAtual - 1);
  });
  btnSeguinte.addEventListener('click', function () {
    if (diaAtual < TOTAL_DIAS) abrirDia(diaAtual + 1);
  });

  /* ==========================================================
     13. INIT
     ========================================================== */
  function init() {
    construirCalendario();
    mostrarVista('capa');
  }
  init();

})();