LilPay V4 - Mobile Build Package

This package is prepared for browser-based HTML-to-APK builders.

Main file: index.html
App name: LilPay V4 Demo
Package suggestion: com.lilpay.demo

IMPORTANT: This is a fictional demo wallet. It does not process real money or connect to real banks/payment services.
Keep the visible DEMO / NOT REAL MONEY label when publishing or sharing.
