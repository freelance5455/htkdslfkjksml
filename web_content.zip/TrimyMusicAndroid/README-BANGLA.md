# Trimy Music Android APK project

এই ZIP-এ আপনার আগের Trimy Music HTML অ্যাপকে Android WebView অ্যাপে প্যাকেজ করার প্রজেক্ট আছে।

## Android ফোন থেকে APK বানানো
1. GitHub-এ sign in করুন এবং New repository তৈরি করুন; নাম দিন `trimy-music-android`।
2. এই ZIP extract করুন। GitHub repository-তে Add file → Upload files দিয়ে ZIP-এর ভেতরের সব ফাইল/ফোল্ডার upload করুন (ZIP ফাইলটি একা নয়), তারপর Commit changes দিন।
3. Repository-র Actions tab খুলুন। Workflow enable করতে বললে enable করুন।
4. `Build Trimy Music APK` নির্বাচন করে Run workflow চাপুন।
5. Build সফল হলে run খুলে Artifacts থেকে `trimy-music-debug-apk` download করুন।
6. Artifact ZIP extract করে `app-debug.apk` বের করুন এবং tap করে Install দিন।
7. Android অনুমতি চাইলে Settings → Install unknown apps থেকে যে অ্যাপ দিয়ে APK খুলছেন সেটিকে অনুমতি দিন। ইনস্টলের পরে চাইলে অনুমতি বন্ধ করুন।

## এই APK-তে
- HTML app-এ থাকা player, search, liked songs ও local library
- ফোন থেকে audio file picker দিয়ে গান যোগ করা
- গান browser storage-এ locally থাকে

## সীমাবদ্ধতা
এটি Spotify-র মতো online service নয়। Secure email/password accounts, cloud song upload, online catalogue, streaming server, synced playlists বা admin panel এতে নেই। APKটি debug build; Play Store release-এর জন্য আলাদা release signing ও Play Console setup দরকার।
