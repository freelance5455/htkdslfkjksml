# CGD V117 — Socle 4.1 : expressions faciales et réactions collectives

## Objectif
Approfondir la présence humaine des damistes et relier les réactions du public aux attitudes visibles pendant les séquences de match, sans modifier le moteur de règles, les résultats, les compétitions ou les données de carrière.

## Évolutions
- Inclinaison de tête distincte pour la réflexion, la présentation, la célébration et la défaite.
- Variation de l'ouverture des yeux selon l'attitude.
- Géométrie de bouche et sourcils intégrée au visage pour rendre les attitudes plus lisibles.
- Réaction collective des tribunes : amplitude plus énergique lors d'une célébration, plus retenue lors d'une défaite, mouvement normal dans les autres séquences.
- Réutilisation des poses existantes déclenchées par l'interface de match ; aucun nouveau résultat ni aucune règle de dames n'est calculé ici.

## Préservation
Le socle 4.0 et les étapes antérieures restent la base. Les compétitions, calendriers, règles de déplacement/prise/promotion, chronomètres, carrière et gestion ne sont pas modifiés.

## Limites connues
Le rendu demeure stylisé WebGL et ne constitue pas une capture photoréaliste. Les expressions sont géométriques, pas un système de capture faciale. Les réactions du public suivent les séquences de pose et ne sont pas une simulation individuelle de chaque spectateur. Validation visuelle sur appareils mobiles réels à effectuer.
