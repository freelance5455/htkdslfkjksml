import { Fragment, jsxDEV } from "react/jsx-dev-runtime";
import { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import Header from "./Header.tsx";
import Footer from "./Footer.tsx";
import Anatomy3D from "./Anatomy3D.tsx";
import Timer from "./timer.tsx";
import { exercises, muscles } from "./data/exercises.ts";
import { ui, muscleNames } from "./i18n.ts";
function read(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch {
    return fallback;
  }
}
function App() {
  const [lang, setLangState] = useState(() => read("iron-lang", "en")), [gender, setGender] = useState(() => read("iron-gender", null)), [selected, setSelected] = useState(null), [favorites, setFavorites] = useState(() => read("iron-favorites", [])), [videoCount, setVideoCount] = useState(0), [dismissed, setDismissed] = useState(false), [light, setLight] = useState(() => read("iron-theme", false)), [query, setQuery] = useState(""), [difficulty, setDifficulty] = useState(null), [timer, setTimer] = useState(null), [recent, setRecent] = useState(() => read("iron-recent", [])), [history, setHistory] = useState(() => read("iron-history", [])), [showHistory, setShowHistory] = useState(false), [logged, setLogged] = useState(() => read("iron-login", false)), [form, setForm] = useState(false);
  const t = ui[lang];
  const setLang = (v) => {
    setLangState(v);
    localStorage.setItem("iron-lang", JSON.stringify(v));
  };
  const chooseGender = (v) => {
    setGender(v);
    localStorage.setItem("iron-gender", JSON.stringify(v));
  };
  const selectMuscle = (v) => {
    setSelected(v);
    setQuery("");
    setDifficulty(null);
  };
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "fa" ? "rtl" : "ltr";
  }, [lang]);
  useEffect(() => {
    localStorage.setItem("iron-favorites", JSON.stringify(favorites));
  }, [favorites]);
  useEffect(() => {
    localStorage.setItem("iron-theme", JSON.stringify(light));
  }, [light]);
  useEffect(() => {
    localStorage.setItem("iron-recent", JSON.stringify(recent));
  }, [recent]);
  useEffect(() => {
    localStorage.setItem("iron-history", JSON.stringify(history));
  }, [history]);
  const filtered = useMemo(() => exercises.filter((e) => e.muscle === selected && (!difficulty || e.difficulty === difficulty) && (!query || (e.name + " " + e.persianName + " " + e.muscle).toLowerCase().includes(query.toLowerCase()))), [selected, difficulty, query]);
  const openVideo = (e) => {
    setVideoCount((v) => v + 1);
    setRecent((prev) => [e.id, ...prev.filter((id) => id !== e.id)].slice(0, 5));
    window.open("https://www.youtube.com/results?search_query=" + encodeURIComponent(e.youtubeSearchQuery), "_blank", "noopener,noreferrer");
  };
  const markDone = (e) => {
    let count = e.defaultSets;
    try {
      const settings = JSON.parse(localStorage.getItem("iron-timer") || "{}");
      count = Number(settings.sets) || count;
    } catch {
    }
    setHistory((prev) => [{ id: e.id, name: e.name, sets: count, date: (/* @__PURE__ */ new Date()).toISOString() }, ...prev].slice(0, 30));
  };
  const toggleFavorite = (id) => setFavorites((v) => v.includes(id) ? v.filter((x) => x !== id) : [...v, id]);
  const showBanner = videoCount >= 3 && !dismissed && !logged;
  if (!gender) return /* @__PURE__ */ jsxDEV("div", { className: "gender-screen grid min-h-screen " + (lang === "fa" ? "fa" : ""), dir: lang === "fa" ? "rtl" : "ltr", children: /* @__PURE__ */ jsxDEV("div", { className: "gender-card", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "gender-mark", children: "\u25CF\u2501\u2501\u25CF" }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 3,
      columnNumber: 152
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "gender-title", children: "IRON ATLAS" }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 3,
      columnNumber: 191
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "gender-sub", children: [
      t.chooseGender,
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 3,
        columnNumber: 277
      }, this),
      t.genderSub
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 3,
      columnNumber: 235
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "gender-buttons", children: [
      /* @__PURE__ */ jsxDEV("button", { className: "gender-choice", onClick: () => chooseGender("male"), children: [
        t.male,
        /* @__PURE__ */ jsxDEV("span", { children: "\u2642" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 3,
          columnNumber: 408
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 3,
        columnNumber: 331
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "gender-choice", onClick: () => chooseGender("female"), children: [
        t.female,
        /* @__PURE__ */ jsxDEV("span", { children: "\u2640" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 3,
          columnNumber: 512
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 3,
        columnNumber: 431
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 3,
      columnNumber: 299
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "lang-toggle", style: { marginTop: 20 }, onClick: () => setLang(lang === "en" ? "fa" : "en"), "aria-label": "Change language", children: [
      /* @__PURE__ */ jsxDEV("span", { className: lang === "en" ? "active" : "", children: "EN" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 3,
        columnNumber: 670
      }, this),
      " | ",
      /* @__PURE__ */ jsxDEV("span", { className: lang === "fa" ? "active" : "", children: "FA" }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 3,
        columnNumber: 724
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 3,
      columnNumber: 541
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 3,
    columnNumber: 123
  }, this) }, void 0, false, {
    fileName: "<stdin>",
    lineNumber: 3,
    columnNumber: 19
  }, this);
  const featureItems = [[t.feature1, t.feature1d, "\u2699"], [t.feature2, t.feature2d, "\u2726"], [t.feature3, t.feature3d, "\u25C8"], [t.feature4, t.feature4d, "\u2667"]];
  return /* @__PURE__ */ jsxDEV("div", { className: "app min-h-screen bg-black-soft text-white " + (light ? "light " : "") + (lang === "fa" ? "fa" : ""), dir: lang === "fa" ? "rtl" : "ltr", id: "top", children: [
    /* @__PURE__ */ jsxDEV(Header, { lang, setLang, light, setLight, t }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 4,
      columnNumber: 288
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "hero", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "hero-kicker", children: t.heroKicker }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 4,
        columnNumber: 393
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "headline", children: [
        t.hero1,
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 472
        }, this),
        t.hero2,
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 486
        }, this),
        t.hero3.split(" ").slice(0, -2).join(" "),
        " ",
        /* @__PURE__ */ jsxDEV("em", { children: t.hero3.split(" ").slice(-2).join(" ") }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 534
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 4,
        columnNumber: 438
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "hero-copy", children: t.heroCopy }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 4,
        columnNumber: 588
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hero-buttons", children: [
        /* @__PURE__ */ jsxDEV("a", { className: "primary-btn", href: "#finder", children: [
          t.join,
          " \u2192"
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 659
        }, this),
        /* @__PURE__ */ jsxDEV("a", { className: "ghost-btn", href: "#finder", children: t.watch }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 715
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 4,
        columnNumber: 629
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 4,
      columnNumber: 367
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "features", id: "programs", children: featureItems.map(([title, description, icon]) => /* @__PURE__ */ jsxDEV("article", { className: "feature", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "feature-icon", children: icon }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 4,
        columnNumber: 915
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "feature-title", children: title }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 964
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "feature-copy", children: description }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 1006
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 4,
        columnNumber: 959
      }, this)
    ] }, title, true, {
      fileName: "<stdin>",
      lineNumber: 4,
      columnNumber: 874
    }, this)) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 4,
      columnNumber: 784
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "main-shell", id: "finder", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-head", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "kicker", children: t.kicker }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 1150
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "section-title", children: t.sectionTitle }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 1186
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 4,
        columnNumber: 1120
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "finder-grid", children: [
        /* @__PURE__ */ jsxDEV("section", { className: "anatomy-column", children: [
          /* @__PURE__ */ jsxDEV(Anatomy3D, { gender, selected, lang, onSelect: (v) => selectMuscle(v) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 4,
            columnNumber: 1308
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "legend-wrap", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "legend-top", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "legend-title", children: t.legend }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 1465
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "small-btn", onClick: () => selectMuscle(null), children: t.reset }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 1513
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 1437
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "legend-grid", children: muscles.map((m, i) => /* @__PURE__ */ jsxDEV("button", { className: "muscle-chip " + (selected === m ? "selected" : ""), onClick: () => selectMuscle(m), "aria-label": muscleNames[lang][i], children: muscleNames[lang][i] }, m, false, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 1649
            }, this)) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 1600
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 4,
            columnNumber: 1408
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 1272
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: "exercise-column", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "exercise-box", children: selected ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "exercise-header", children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "exercise-heading", children: muscleNames[lang][muscles.indexOf(selected)] }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 1952
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "count-label", children: [
                filtered.length,
                " ",
                t.exercise.toLowerCase()
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 2036
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 1919
            }, this),
            /* @__PURE__ */ jsxDEV("input", { className: "search-box", type: "search", value: query, onChange: (e) => setQuery(e.target.value), placeholder: t.search, "aria-label": t.search }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 2123
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "filter-row", children: [null, "Beginner", "Intermediate", "Advanced"].map((d) => /* @__PURE__ */ jsxDEV("button", { className: "filter-chip " + (difficulty === d ? "active" : ""), onClick: () => setDifficulty(d), children: d ? t[d] : t.all }, d || "all", false, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 2374
            }, this)) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 2266
            }, this),
            filtered.length ? /* @__PURE__ */ jsxDEV("div", { className: "exercise-list", children: filtered.map((e) => /* @__PURE__ */ jsxDEV("article", { className: "exercise-card", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "exercise-top", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "exercise-name", children: e.name }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 4,
                    columnNumber: 2661
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "persian-name", children: e.persianName }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 4,
                    columnNumber: 2704
                  }, this)
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 4,
                  columnNumber: 2656
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "difficulty " + e.difficulty, children: t[e.difficulty] }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 4,
                  columnNumber: 2757
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 2626
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "card-actions", children: [
                /* @__PURE__ */ jsxDEV("button", { className: "small-btn gold", onClick: () => openVideo(e), children: t.watchVideo }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 4,
                  columnNumber: 2862
                }, this),
                /* @__PURE__ */ jsxDEV("button", { className: "small-btn", onClick: () => setTimer(e), children: t.startTimer }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 4,
                  columnNumber: 2947
                }, this),
                /* @__PURE__ */ jsxDEV("button", { className: "small-btn", onClick: () => markDone(e), children: t.markDone }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 4,
                  columnNumber: 3026
                }, this),
                /* @__PURE__ */ jsxDEV("button", { className: "heart-btn " + (favorites.includes(e.id) ? "fav" : ""), onClick: () => toggleFavorite(e.id), "aria-label": favorites.includes(e.id) ? t.saved : "Save favorite", title: favorites.includes(e.id) ? t.saved : "Favorite", children: favorites.includes(e.id) ? "\u2665" : "\u2661" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 4,
                  columnNumber: 3103
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 2832
              }, this)
            ] }, e.id, true, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 2580
            }, this)) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 2532
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "empty-state", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "empty-icon", children: "\u25CF\u2501\u2501\u25CF" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 3418
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: t.noMatches }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 3458
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 3389
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 4,
            columnNumber: 1917
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "empty-state", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "empty-icon", children: "\u25CF\u2501\u2501\u25CF" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 3518
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "exercise-heading", children: t.muscleHeading }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 3558
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: t.empty }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 3613
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 4,
            columnNumber: 3489
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 4,
            columnNumber: 1877
          }, this),
          showBanner && /* @__PURE__ */ jsxDEV("div", { className: "notice", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("strong", { children: t.videos }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 3684
              }, this),
              form && /* @__PURE__ */ jsxDEV("div", { className: "inline-form", children: [
                /* @__PURE__ */ jsxDEV("input", { "aria-label": t.email, placeholder: t.email, type: "email" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 4,
                  columnNumber: 3747
                }, this),
                /* @__PURE__ */ jsxDEV("input", { "aria-label": t.password, placeholder: t.password, type: "password" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 4,
                  columnNumber: 3811
                }, this),
                /* @__PURE__ */ jsxDEV("button", { className: "small-btn gold", onClick: () => {
                  setLogged(true);
                  localStorage.setItem("iron-login", "true");
                  setForm(false);
                }, children: t.create }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 4,
                  columnNumber: 3884
                }, this)
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 3718
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 3679
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "notice-actions", children: [
              /* @__PURE__ */ jsxDEV("button", { className: "small-btn", onClick: () => {
                setLogged(true);
                localStorage.setItem("iron-login", "true");
              }, children: t.google }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 4072
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "small-btn", onClick: () => setForm(!form), children: form ? t.login : t.email }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 4195
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "small-btn", onClick: () => setDismissed(true), children: t.dismiss }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 4,
                columnNumber: 4285
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 4,
              columnNumber: 4040
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 4,
            columnNumber: 3655
          }, this),
          logged && /* @__PURE__ */ jsxDEV("p", { className: "count-label", style: { marginTop: 10 }, children: t.savedAccount }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 4,
            columnNumber: 4390
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 1840
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 4,
        columnNumber: 1243
      }, this),
      recent.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "recent-section", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "kicker", children: t.recent }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 4531
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "recent-row", children: recent.map((id) => {
          const e = exercises.find((x) => x.id === id);
          return e ? /* @__PURE__ */ jsxDEV("button", { className: "recent-item", onClick: () => selectMuscle(e.muscle), children: [
            e.name,
            " \u2197"
          ] }, id, true, {
            fileName: "<stdin>",
            lineNumber: 4,
            columnNumber: 4658
          }, this) : null;
        }) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 4567
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 4,
        columnNumber: 4495
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "history-section", children: [
        /* @__PURE__ */ jsxDEV("button", { className: "history-tab history-toggle", onClick: () => setShowHistory(!showHistory), children: [
          showHistory ? t.hideHistory : t.showHistory,
          " ",
          showHistory ? "\u2212" : "+"
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 4817
        }, this),
        showHistory && /* @__PURE__ */ jsxDEV("div", { className: "history-list", children: history.length ? history.map((h, i) => /* @__PURE__ */ jsxDEV("div", { className: "history-entry", children: [
          /* @__PURE__ */ jsxDEV("span", { children: [
            h.name,
            " \xB7 ",
            h.sets,
            " ",
            t.sets
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 4,
            columnNumber: 5097
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: new Date(h.date).toLocaleDateString(lang === "fa" ? "fa-IR" : "en-US") }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 4,
            columnNumber: 5138
          }, this)
        ] }, i, true, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 5058
        }, this)) : /* @__PURE__ */ jsxDEV("p", { className: "count-label", children: t.noHistory }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 5225
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 4,
          columnNumber: 4993
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 4,
        columnNumber: 4780
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 4,
      columnNumber: 1079
    }, this),
    /* @__PURE__ */ jsxDEV(Footer, { lang, t }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 4,
      columnNumber: 5294
    }, this),
    timer && /* @__PURE__ */ jsxDEV(Timer, { exercise: timer.name, lang, t, onClose: () => setTimer(null) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 4,
      columnNumber: 5329
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 4,
    columnNumber: 145
  }, this);
}
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 5,
  columnNumber: 53
}));
