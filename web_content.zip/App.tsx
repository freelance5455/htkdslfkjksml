
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  AppState,
  UserStats,
  UserTier,
  UserProfile,
  Gig,
  Transaction,
  HighPayingGigAlert,
  EmployerHustlerMatchAlert,
  AvailableHustler
} from './types';
import RadarMap from './components/RadarMap';
import ChatSystem from './components/ChatSystem';
import WalletPage from './components/WalletPage';
import AccountPage from './components/AccountPage';
import BottomNav from './components/BottomNav';
import Onboarding from './components/Onboarding';
import PanicButton from './components/PanicButton';
import GigForm from './components/GigForm';
import SplashScreen from './components/SplashScreen';
import WelcomeAuthScreen from './components/WelcomeAuthScreen';
import RoleSelectionScreen from './components/RoleSelectionScreen';
import RatingDialog from './components/RatingDialog';
import PersonalInformationPage from './components/PersonalInformationPage';
import ManageGigsPage from './components/ManageGigsPage';
import SecuritySafetyScreen from './components/SecuritySafetyScreen';
import SupportChatScreen from './components/SupportChatScreen';
import JobDetailsScreen from './components/JobDetailsScreen';
import AchievementOverlay from './components/AchievementOverlay';
import { HighPayingGigAlertBanner } from './components/HighPayingGigAlertBanner';
import { EmployerHustlerMatchAlertBanner } from './components/EmployerHustlerMatchAlertBanner';
import { PushNotificationSettingsModal } from './components/PushNotificationSettingsModal';
import {
  DEFAULT_PUSH_SETTINGS,
  evaluateGigForAlert,
  evaluateHustlerMatchForEmployer,
  playNotificationChime,
  sendBrowserPushNotification,
  sendBrowserPushNotificationForEmployer,
  calculateDistanceKm,
  matchHustlerToGig
} from './components/gigNotificationService';
import { NEARBY_HUSTLERS } from './data/hustlers';
import {
  RegisteredUser,
  getActiveSession,
  saveActiveSession,
  clearAuthSession
} from './components/authService';

const DEFAULT_STATS: UserStats = {
  jobsCompleted: 12,
  jobsPostedCount: 3, // Mocked for progress tracking
  averageRating: 4.8,
  currentTier: UserTier.ELITE,
  memberSince: new Date().getFullYear().toString()
};

const DEFAULT_PROFILE: UserProfile = {
  id: 'user_mandla_01',
  fullName: 'Mandla Zulu',
  email: 'admin@swifthustle.co.za',
  phone: '+27 72 123 4567',
  idNumber: '9201015678081',
  address: 'Sandton, Johannesburg',
  bio: 'Professional entrepreneur and local community leader.',
  isAvailable: false,
  walletBalance: 2450,
  escrowBalance: 1200, // Mocked escrow for demo
  emergencyContact: '+27 82 000 0000',
  emergencyContacts: ['+27 82 000 0000'],
  skills: ['Electrical', 'Handyman', 'Plumbing', 'General'],
  pushNotificationSettings: {
    enabled: true,
    immediateRadiusKm: 5,
    highPayingThreshold: 800,
    skillsOnly: true,
    soundEnabled: true,
    browserPushEnabled: true
  },
  isAdmin: true, // Keeping the flag but removing the UI access
  verification: {
    phone: 'verified',
    identity: 'verified',
    facial: 'unverified',
    address: 'pending'
  }
};

const INITIAL_GIGS: Gig[] = [
  { id: 'gig-1', title: 'Office Relocation Help', description: 'Moving from floor 2 to floor 5. 3 desks and some boxes.', price: 1200, location: [-26.1076, 28.0567], category: 'General', datePosted: Date.now() - 3600000, isFeatured: false, status: 'open', requiresPoW: true, isVerifiedUser: true },
  { id: 'gig-3', title: 'Assemble Decofurn TV Unit', description: 'Need someone with power tools to assemble a 2m TV cabinet.', price: 450, location: [-26.0940, 28.0640], category: 'Handyman', datePosted: Date.now() - 5400000, isFeatured: false, status: 'open', requiresPoW: false, isVerifiedUser: true },
  { id: 'gig-2', title: 'Need Plumber Urgently', description: 'Burst pipe in the garden. Urgent fix needed.', price: 850, location: [-26.1415, 28.0125], category: 'Plumbing', datePosted: Date.now() - 7200000, isFeatured: true, status: 'open', requiresPoW: true, isVerifiedUser: false },
  { id: 'gig-4', title: 'Perimeter Wall Painting', description: 'Repainting boundary wall in Bryanston. Paint supplied.', price: 1400, location: [-26.0550, 28.0200], category: 'Painting', datePosted: Date.now() - 9000000, isFeatured: true, status: 'open', requiresPoW: true, isVerifiedUser: true },
  { id: 'gig-5', title: 'Post-Tenant Deep Clean', description: '3-bedroom apartment empty deep clean including oven and windows.', price: 950, location: [-26.0120, 28.0050], category: 'Cleaning', datePosted: Date.now() - 14400000, isFeatured: false, status: 'open', requiresPoW: true, isVerifiedUser: true },
  { id: 'gig-6', title: 'Inverter & Battery Wiring', description: 'Connecting 5kW Deye inverter to main distribution board.', price: 2800, location: [-25.9920, 28.1150], category: 'Electrical', datePosted: Date.now() - 18000000, isFeatured: true, status: 'open', requiresPoW: true, isVerifiedUser: true }
];

const INITIAL_TRANSACTIONS: Transaction[] = [
  { id: 't1', type: 'in', label: 'EFT Deposit', amount: 500, timestamp: Date.now() - 172800000, status: 'completed' },
  { id: 't2', type: 'out', label: 'Withdrawal to FNB', amount: 200, timestamp: Date.now() - 345600000, status: 'completed', userName: 'Mandla Zulu', method: 'FNB' },
  { id: 'payout-1', type: 'out', label: 'Withdrawal to Capitec', amount: 1200, timestamp: Date.now() - 3600, status: 'pending', userName: 'Sabelo M.', method: 'Capitec' }
];

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.SPLASH);
  const [currentView, setCurrentView] = useState<View>(View.RADAR);
  const [isHustler, setIsHustler] = useState<boolean>(true);
  const [isNewGigOpen, setIsNewGigOpen] = useState<boolean>(false);
  const [isSwitching, setIsSwitching] = useState<boolean>(false);
  const [userStats, setUserStats] = useState<UserStats>(DEFAULT_STATS);
  const [userProfile, setUserProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [userGigs, setUserGigs] = useState<Gig[]>(INITIAL_GIGS);
  const [activeRatingJob, setActiveRatingJob] = useState<{ id: string, title: string, price: number, isInstant?: boolean } | null>(null);
  const [showAchievement, setShowAchievement] = useState<boolean>(false);
  const [selectedGigDetail, setSelectedGigDetail] = useState<Gig | null>(null);
  const [boostCredits, setBoostCredits] = useState<number>(() => {
    const saved = localStorage.getItem('sh_boost_credits');
    return saved !== null ? parseInt(saved, 10) : 3;
  });

  // Push Notification state
  const [currentAlert, setCurrentAlert] = useState<HighPayingGigAlert | null>(null);
  const [currentEmployerAlert, setCurrentEmployerAlert] = useState<EmployerHustlerMatchAlert | null>(null);
  const [isPushSettingsOpen, setIsPushSettingsOpen] = useState<boolean>(false);
  const [userLocation, setUserLocation] = useState<[number, number]>([-26.1076, 28.0567]); // Default Sandton, Johannesburg
  const [activeChatContact, setActiveChatContact] = useState<AvailableHustler | null>(null);
  const alertedGigIdsRef = useRef<Set<string>>(new Set());
  const alertedEmployerHustlerMatchRef = useRef<Set<string>>(new Set());

  // Track hustlers who are currently hired by employers / actively on jobs
  const [hiredHustlerIds, setHiredHustlerIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('sh_hired_hustler_ids');
      return saved ? JSON.parse(saved) : ['hustler-1'];
    } catch {
      return ['hustler-1'];
    }
  });

  // Track current hustler persona for RadarMap
  const [currentHustlerId, setCurrentHustlerId] = useState<string>(() => {
    const saved = localStorage.getItem('sh_current_hustler_id');
    return saved || 'hustler-1';
  });

  // Derived working statuses
  const isHustlerWorking = isHustler && Boolean(currentHustlerId && hiredHustlerIds.includes(currentHustlerId));
  const isEmployerWorkingWithHustler = !isHustler && hiredHustlerIds.length > 0;

  // Clear pending alert banners automatically when entering working mode
  useEffect(() => {
    if (isHustlerWorking) {
      setCurrentAlert(null);
    }
    if (isEmployerWorkingWithHustler) {
      setCurrentEmployerAlert(null);
    }
  }, [isHustlerWorking, isEmployerWorkingWithHustler]);

  // Watch user GPS position for accurate 5km radius calculations
  useEffect(() => {
    let watchId: number;
    if (typeof window !== 'undefined' && 'geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserLocation([pos.coords.latitude, pos.coords.longitude]);
        },
        (err) => console.log('Initial GPS fallback to Sandton:', err.message),
        { enableHighAccuracy: true, timeout: 10000 }
      );

      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          setUserLocation([pos.coords.latitude, pos.coords.longitude]);
        },
        (err) => console.warn('GPS watch error:', err.message),
        { enableHighAccuracy: true, maximumAge: 30000, timeout: 20000 }
      );
    }
    return () => {
      if (watchId && typeof window !== 'undefined' && 'geolocation' in navigator) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, []);

  // Evaluates a gig against user skills, 5km radius, and R800+ threshold (Hustler Mode)
  const triggerGigAlert = useCallback((gig: Gig) => {
    // STRICT RULE: Only alert when user is in Hustler mode
    if (!isHustler) return;

    // RULE: When hustler is in currently working mode, all notifications stop until done working
    if (isHustlerWorking) {
      console.log('Gig notifications stopped: Hustler is currently working on an active job.');
      return;
    }

    const userSkills = userProfile.skills && userProfile.skills.length > 0
      ? userProfile.skills
      : ['Electrical', 'Handyman', 'Plumbing', 'General'];

    const settings = userProfile.pushNotificationSettings || DEFAULT_PUSH_SETTINGS;

    const alert = evaluateGigForAlert(
      gig,
      userLocation,
      userSkills,
      settings
    );

    if (!alert) return;

    // Prevent duplicate alert banners for the exact same gig ID
    if (alertedGigIdsRef.current.has(gig.id)) return;
    alertedGigIdsRef.current.add(gig.id);

    setCurrentAlert(alert);

    // Audio chime
    if (settings.soundEnabled !== false) {
      playNotificationChime();
    }

    // Native Web Notification
    if (settings.browserPushEnabled !== false) {
      sendBrowserPushNotification(alert, () => {
        setSelectedGigDetail(gig);
        setCurrentView(View.JOB_DETAILS);
      });
    }
  }, [isHustler, isHustlerWorking, userLocation, userProfile.skills, userProfile.pushNotificationSettings]);

  // Evaluates available hustlers against a posted gig (Employer Mode)
  const triggerEmployerHustlerMatchAlert = useCallback((postedGig: Gig) => {
    // STRICT RULE: Only alert when user is in Employer mode
    if (isHustler) return;

    // RULE: Once employers have selected someone for hire, candidate notifications stop until done working
    if (isEmployerWorkingWithHustler) {
      console.log('Match notifications stopped: Employer has hired a hustler who is currently working.');
      return;
    }

    const settings = userProfile.pushNotificationSettings || DEFAULT_PUSH_SETTINGS;
    const alert = evaluateHustlerMatchForEmployer(
      postedGig,
      NEARBY_HUSTLERS,
      userLocation,
      settings
    );

    if (!alert) return;

    const matchKey = `${postedGig.id}-${alert.hustler.id}`;
    if (alertedEmployerHustlerMatchRef.current.has(matchKey)) return;
    alertedEmployerHustlerMatchRef.current.add(matchKey);

    setCurrentEmployerAlert(alert);

    // Audio chime
    if (settings.soundEnabled !== false) {
      playNotificationChime();
    }

    // Native Web Notification for Employer
    if (settings.browserPushEnabled !== false) {
      sendBrowserPushNotificationForEmployer(alert, () => {
        setCurrentView(View.CHAT);
      });
    }
  }, [isHustler, isEmployerWorkingWithHustler, userLocation, userProfile.pushNotificationSettings]);

  // Handler for newly submitted gigs
  const handleAddGig = useCallback((newGig: Gig) => {
    setUserGigs(prev => [newGig, ...prev]);

    if (isHustler) {
      // Hustler posted an offer or updated gigs: check if matching high-paying alert
      triggerGigAlert(newGig);
    } else {
      // Employer posted a new gig: immediately scan available hustlers & push alert!
      setTimeout(() => {
        triggerEmployerHustlerMatchAlert(newGig);
      }, 500);
    }
  }, [isHustler, triggerGigAlert, triggerEmployerHustlerMatchAlert]);

  // Simulator for Hustlers: demonstrate 5km high-paying push notification instantly
  const handleSimulateHighPayingGigAlert = useCallback(() => {
    if (isHustlerWorking) {
      alert('Notifications Paused: You are in "Currently Working" mode on an active job. All gig notifications are paused so you can focus, and will resume once this work is marked complete.');
      return;
    }

    const userSkills = userProfile.skills && userProfile.skills.length > 0
      ? userProfile.skills
      : ['Electrical', 'Handyman', 'Plumbing', 'General'];

    const chosenSkill = userSkills[Math.floor(Math.random() * userSkills.length)] || 'Electrical';

    const gigCatalog: Record<string, { title: string; desc: string; price: number; category: string }[]> = {
      'Electrical': [
        {
          title: 'Emergency 8kW Sunsynk Inverter & Backup DB Wiring',
          desc: 'Urgent installation for backup power during stage 6 loadshedding. All materials on site in Sandton.',
          price: 2650,
          category: 'Electrical'
        },
        {
          title: 'Urgent Solar Distribution Board Re-wiring',
          desc: 'Tripping main breaker in double-storey home. Certified electrician needed immediately with escrow deposit.',
          price: 1850,
          category: 'Electrical'
        }
      ],
      'Handyman': [
        {
          title: 'Custom Floating Wall Unit & TV Mount Assembly',
          desc: 'Assemble premium timber wall unit and concealed cable installation in living room.',
          price: 1250,
          category: 'Handyman'
        },
        {
          title: 'Commercial Office Partition Repairs & Mounting',
          desc: 'Mounting whiteboard displays and fixing 4 acoustic door latches in Sandton corporate park.',
          price: 1450,
          category: 'Handyman'
        }
      ],
      'Plumbing': [
        {
          title: 'High-Pressure Geyser Valve Replacement & Pipe Relocation',
          desc: 'Burst solar geyser valve leaking into ceiling. Urgent response with immediate escrow release.',
          price: 1950,
          category: 'Plumbing'
        },
        {
          title: 'Emergency Main Water Line Pipe Repair',
          desc: 'Major leak on boundary supply pipe. Immediate call-out rate pre-funded in escrow.',
          price: 1600,
          category: 'Plumbing'
        }
      ],
      'Painting': [
        {
          title: 'Luxury Double-Storey Exterior Painting Contract',
          desc: 'Urgent finish before tenant arrival. Premium Dulux weather-guard paint supplied.',
          price: 3200,
          category: 'Painting'
        }
      ],
      'Cleaning': [
        {
          title: 'Commercial Showroom Post-Construction Deep Clean',
          desc: '500 sqm commercial space needs industrial floor scrub, window polishing and sanitize.',
          price: 2400,
          category: 'Cleaning'
        }
      ],
      'General': [
        {
          title: 'Corporate Conference Logistics & Stage Handling',
          desc: 'Fast setup coordination and heavy equipment handling at Sandton Convention Centre.',
          price: 1400,
          category: 'General'
        }
      ]
    };

    const options = gigCatalog[chosenSkill] || [
      {
        title: `High-Priority ${chosenSkill} Opportunity`,
        desc: `High-paying urgent job matching your ${chosenSkill} qualifications nearby.`,
        price: 1650,
        category: chosenSkill
      }
    ];

    const template = options[Math.floor(Math.random() * options.length)];

    // Place randomly between 1.2km and 3.4km (strictly within 5km immediate perimeter)
    const angle = Math.random() * Math.PI * 2;
    const distanceKm = 1.4 + Math.random() * 2.0; // 1.4km to 3.4km
    const kmToDeg = 1 / 111; // 1 degree latitude ~ 111km
    const latOffset = (distanceKm * Math.cos(angle)) * kmToDeg;
    const lngOffset = (distanceKm * Math.sin(angle)) * (kmToDeg / Math.cos(userLocation[0] * (Math.PI / 180)));

    const simGig: Gig = {
      id: `gig-sim-${Date.now()}`,
      title: template.title,
      description: template.desc,
      price: template.price,
      location: [userLocation[0] + latOffset, userLocation[1] + lngOffset],
      category: template.category,
      datePosted: Date.now(),
      status: 'open',
      requiresPoW: true,
      isVerifiedUser: true,
      isFeatured: true
    };

    setUserGigs(prev => [simGig, ...prev]);

    const settings = userProfile.pushNotificationSettings || DEFAULT_PUSH_SETTINGS;
    const alert = evaluateGigForAlert(
      simGig,
      userLocation,
      userSkills,
      settings
    );

    if (alert) {
      alertedGigIdsRef.current.add(simGig.id);
      setCurrentAlert(alert);
      if (settings.soundEnabled !== false) {
        playNotificationChime();
      }
      if (settings.browserPushEnabled !== false) {
        sendBrowserPushNotification(alert, () => {
          setSelectedGigDetail(simGig);
          setCurrentView(View.JOB_DETAILS);
        });
      }
    }
  }, [userLocation, userProfile.skills, userProfile.pushNotificationSettings]);

  // Simulator for Employers: demonstrate candidate match push notification instantly
  const handleSimulateEmployerMatchAlert = useCallback(() => {
    if (isEmployerWorkingWithHustler) {
      alert('Notifications Paused: You have selected and hired a hustler who is currently working for you. Candidate match notifications are paused until the active work is finished.');
      return;
    }

    const settings = userProfile.pushNotificationSettings || DEFAULT_PUSH_SETTINGS;

    // Pick an existing posted gig or create a representative job
    let targetGig = userGigs.find(g => g.status === 'open');
    if (!targetGig) {
      targetGig = {
        id: `gig-emp-${Date.now()}`,
        title: 'Urgent 8kW Solar Inverter & Backup DB Wiring',
        description: 'Stage 6 loadshedding urgent install in Sandton. Certified wireman needed immediately.',
        price: 2450,
        location: userLocation,
        category: 'Electrical',
        datePosted: Date.now(),
        status: 'open',
        requiresPoW: true,
        isVerifiedUser: true,
        isFeatured: true
      };
      setUserGigs(prev => [targetGig!, ...prev]);
    }

    // Find a matching online hustler or pick top candidate
    const matching = NEARBY_HUSTLERS.filter(h => matchHustlerToGig(h, targetGig!));
    const candidate = matching.length > 0
      ? matching[Math.floor(Math.random() * matching.length)]
      : NEARBY_HUSTLERS[0];

    const distance = calculateDistanceKm(userLocation, candidate.location);

    const simAlert: EmployerHustlerMatchAlert = {
      id: `employer-match-sim-${Date.now()}`,
      hustler: candidate,
      matchedGig: targetGig,
      distanceKm: distance,
      timestamp: Date.now(),
      read: false
    };

    alertedEmployerHustlerMatchRef.current.add(`${targetGig.id}-${candidate.id}`);
    setCurrentEmployerAlert(simAlert);

    if (settings.soundEnabled !== false) {
      playNotificationChime();
    }

    if (settings.browserPushEnabled !== false) {
      sendBrowserPushNotificationForEmployer(simAlert, () => {
        setCurrentView(View.CHAT);
      });
    }
  }, [userGigs, userLocation, userProfile.pushNotificationSettings]);

  // Initial check: if Hustler is in main view, check for any qualifying gig within 5km
  useEffect(() => {
    // Notifications stop completely if hustler is currently working!
    if (appState === AppState.MAIN && isHustler && !isHustlerWorking) {
      const timer = setTimeout(() => {
        const userSkills = userProfile.skills || ['Electrical', 'Handyman', 'Plumbing', 'General'];
        const settings = userProfile.pushNotificationSettings || DEFAULT_PUSH_SETTINGS;
        for (const gig of userGigs) {
          if (!alertedGigIdsRef.current.has(gig.id)) {
            const alert = evaluateGigForAlert(gig, userLocation, userSkills, settings);
            if (alert) {
              alertedGigIdsRef.current.add(gig.id);
              setCurrentAlert(alert);
              if (settings.soundEnabled !== false) playNotificationChime();
              break;
            }
          }
        }
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [appState, isHustler, isHustlerWorking, userGigs, userLocation, userProfile.skills, userProfile.pushNotificationSettings]);

  // Initial check: if Employer is in main view, check for available hustlers matching posted gigs
  useEffect(() => {
    // Notifications stop completely if employer has selected/hired a worker!
    if (appState === AppState.MAIN && !isHustler && !isEmployerWorkingWithHustler) {
      const timer = setTimeout(() => {
        const openGigs = userGigs.filter(g => g.status === 'open');
        const settings = userProfile.pushNotificationSettings || DEFAULT_PUSH_SETTINGS;
        for (const gig of openGigs) {
          const alert = evaluateHustlerMatchForEmployer(gig, NEARBY_HUSTLERS, userLocation, settings);
          if (alert) {
            const matchKey = `${gig.id}-${alert.hustler.id}`;
            if (!alertedEmployerHustlerMatchRef.current.has(matchKey)) {
              alertedEmployerHustlerMatchRef.current.add(matchKey);
              setCurrentEmployerAlert(alert);
              if (settings.soundEnabled !== false) playNotificationChime();
              break;
            }
          }
        }
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [appState, isHustler, isEmployerWorkingWithHustler, userGigs, userLocation, userProfile.pushNotificationSettings]);

  // Ensure role separation: clear opposite alert banners when role changes
  useEffect(() => {
    if (isHustler) {
      setCurrentEmployerAlert(null);
    } else {
      setCurrentAlert(null);
    }
  }, [isHustler]);

  const calculateTier = (jobs: number, rating: number): UserTier => {
    if (jobs >= 50 && rating >= 4.8) return UserTier.PREMIUM;
    if (jobs >= 25 && rating >= 4.5) return UserTier.ELITE;
    if (jobs >= 10 && rating >= 4.0) return UserTier.RISING_STAR;
    return UserTier.ROOKIE;
  };

  const initApp = useCallback(async () => {
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      const hasSeenTutorial = localStorage.getItem('sh_tutorial_complete') === 'true';
      const activeSession = getActiveSession();
      const savedToken = localStorage.getItem('sh_auth_token');
      const isLoggedIn = Boolean(activeSession || savedToken);
      const savedRole = localStorage.getItem('sh_user_role') || activeSession?.user?.role;
      const savedStats = localStorage.getItem('sh_user_stats');
      const savedProfile = localStorage.getItem('sh_user_profile');
      
      if (savedStats) {
        try {
          setUserStats(JSON.parse(savedStats));
        } catch (e) { console.error("Stats recovery failed", e); }
      }

      if (savedProfile) {
        try {
          setUserProfile(JSON.parse(savedProfile));
        } catch (e) { console.error("Profile recovery failed", e); }
      } else if (activeSession?.user) {
        setUserProfile(prev => ({
          ...prev,
          id: activeSession.user.id,
          fullName: activeSession.user.fullName,
          email: activeSession.user.email,
          phone: activeSession.user.phone || prev.phone
        }));
      }

      if (!hasSeenTutorial) {
        setAppState(AppState.ONBOARDING);
      } else if (!isLoggedIn) {
        setAppState(AppState.AUTH);
      } else if (!savedRole) {
        setAppState(AppState.ROLE_SELECTION);
      } else {
        setIsHustler(savedRole === 'hustler');
        setAppState(AppState.MAIN);
      }
    } catch (err) {
      setAppState(AppState.AUTH);
    } finally {
      setIsSwitching(false);
    }
  }, []);

  useEffect(() => {
    initApp();
  }, [initApp]);

  const updateProfile = (updates: Partial<UserProfile>) => {
    const newProfile = { ...userProfile, ...updates };
    setUserProfile(newProfile);
    localStorage.setItem('sh_user_profile', JSON.stringify(newProfile));
  };

  const handleFinishTutorial = () => {
    localStorage.setItem('sh_tutorial_complete', 'true');
    setAppState(AppState.AUTH);
  };

  const handleLogin = (user?: RegisteredUser, rememberMe: boolean = true) => {
    if (user) {
      const updatedProfile: UserProfile = {
        ...userProfile,
        id: user.id || userProfile.id,
        fullName: user.fullName || userProfile.fullName,
        email: user.email || userProfile.email,
        phone: user.phone || userProfile.phone
      };
      setUserProfile(updatedProfile);
      localStorage.setItem('sh_user_profile', JSON.stringify(updatedProfile));

      if (user.avatarUrl) {
        localStorage.setItem('swifthustle_profile_pic', user.avatarUrl);
      }

      saveActiveSession(user, rememberMe);

      if (user.role) {
        const isHustlerRole = user.role === 'hustler';
        setIsHustler(isHustlerRole);
        localStorage.setItem('sh_user_role', user.role);
        setAppState(AppState.MAIN);
        return;
      }
    } else {
      localStorage.setItem('sh_auth_token', `sh_tok_${Date.now()}`);
      if (rememberMe) {
        localStorage.setItem('sh_remember_me', 'true');
      }
    }
    setAppState(AppState.ROLE_SELECTION);
  };

  const handleRoleSelect = (role: 'hustler' | 'client') => {
    localStorage.setItem('sh_user_role', role);
    setIsHustler(role === 'hustler');
    setAppState(AppState.MAIN);
  };

  const handleRoleSwitch = (newIsHustler: boolean) => {
    setIsSwitching(true);
    setTimeout(() => {
      setIsHustler(newIsHustler);
      localStorage.setItem('sh_user_role', newIsHustler ? 'hustler' : 'client');
      setIsSwitching(false);
    }, 1500);
  };

  const handleSignOut = () => {
    clearAuthSession(true); // preserves remembered email for 1-click re-entry on login
    localStorage.removeItem('sh_user_role');
    setAppState(AppState.AUTH);
    setCurrentView(View.RADAR);
  };

  const handleBoostGig = (gigId: string) => {
    if (boostCredits <= 0) return;
    setBoostCredits(prev => {
      const next = Math.max(0, prev - 1);
      localStorage.setItem('sh_boost_credits', next.toString());
      return next;
    });
    setUserGigs(prev => prev.map(g => g.id === gigId ? { ...g, isFeatured: true } : g));
  };

  const handleAddTransaction = (tx: Omit<Transaction, 'id' | 'timestamp'>) => {
    const newTx: Transaction = {
      ...tx,
      id: `tx-${Date.now()}`,
      timestamp: Date.now()
    };
    setTransactions(prev => [newTx, ...prev]);
    
    if (tx.status === 'completed') {
      const balanceChange = tx.type === 'in' ? tx.amount : -tx.amount;
      updateProfile({ walletBalance: userProfile.walletBalance + balanceChange });
    }
  };

  const handleOpenChatWithHustler = useCallback((hustler: AvailableHustler) => {
    setActiveChatContact(hustler);
    setCurrentView(View.CHAT);
  }, []);

  const handleDirectHireHustler = useCallback((hustler: AvailableHustler, gigTitle?: string) => {
    const deposit = hustler.hourlyRate * 3;
    handleAddTransaction({
      type: 'out',
      label: `Escrow Hold: Direct Hire ${hustler.name} (${hustler.skill})`,
      amount: deposit,
      status: 'pending',
      userName: hustler.name
    });

    // Record that this hustler has been selected & hired for work
    setHiredHustlerIds(prev => {
      const next = prev.includes(hustler.id) ? prev : [...prev, hustler.id];
      localStorage.setItem('sh_hired_hustler_ids', JSON.stringify(next));
      return next;
    });

    // Immediately stop and clear active employer candidate notifications
    setCurrentEmployerAlert(null);
    setCurrentAlert(null);

    alert(`Direct Hire request dispatched to ${hustler.name} for "${gigTitle || 'your job'}"! Escrow deposit of R${deposit} held securely. Candidate notifications have stopped while ${hustler.name} is working.`);
    setActiveChatContact(hustler);
    setCurrentView(View.CHAT);
  }, [handleAddTransaction]);

  const checkInstantPayoutUnlock = (newStats: UserStats) => {
    const hasAlreadyUnlocked = localStorage.getItem('sh_achievement_instant_unlocked') === 'true';
    const isEmployer = !isHustler;
    const meetsCriteria = newStats.jobsPostedCount >= 5 && userProfile.verification.identity === 'verified';
    
    if (isEmployer && meetsCriteria && !hasAlreadyUnlocked) {
      setShowAchievement(true);
      localStorage.setItem('sh_achievement_instant_unlocked', 'true');
    }
  };

  const submitRating = async (rating: number, comment: string) => {
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    if (activeRatingJob) {
       const releaseAmount = activeRatingJob.price;
       const fee = activeRatingJob.isInstant ? 15 : 0;

       updateProfile({
         walletBalance: userProfile.walletBalance + releaseAmount - fee,
         escrowBalance: Math.max(0, userProfile.escrowBalance - releaseAmount)
       });

       handleAddTransaction({
         type: 'transfer',
         label: `Payout: ${activeRatingJob.title}${activeRatingJob.isInstant ? ' (Instant)' : ''}`,
         amount: releaseAmount,
         status: 'completed',
         fee: fee
       });

       // Mark job as completed
       setUserGigs(prev => prev.map(g => g.id === activeRatingJob.id ? { ...g, status: 'completed' } : g));

       // The hustler is done working: remove them from active hired list so notifications resume!
       setHiredHustlerIds(prev => {
         const gig = userGigs.find(g => g.id === activeRatingJob.id);
         const targetId = gig?.hustlerId;
         const next = targetId ? prev.filter(id => id !== targetId) : prev.slice(1);
         localStorage.setItem('sh_hired_hustler_ids', JSON.stringify(next));
         return next;
       });
    }

    setUserStats(prev => {
      const isEmployer = !isHustler;
      const newJobs = prev.jobsCompleted + 1;
      const newPostedCount = isEmployer ? (prev.jobsPostedCount || 0) + 1 : prev.jobsPostedCount;
      
      const newRating = prev.jobsCompleted === 0 ? rating : ((prev.averageRating * prev.jobsCompleted) + rating) / newJobs;
      const roundedRating = Number(newRating.toFixed(1));
      const newTier = calculateTier(newJobs, roundedRating);
      
      const updated = {
        ...prev,
        jobsCompleted: newJobs,
        jobsPostedCount: newPostedCount,
        averageRating: roundedRating,
        currentTier: newTier
      };
      
      localStorage.setItem('sh_user_stats', JSON.stringify(updated));
      checkInstantPayoutUnlock(updated);
      return updated;
    });
  };

  const handleJobVerificationComplete = (job: { id: string, title: string, price: number }, isInstant: boolean) => {
    setActiveRatingJob({ ...job, isInstant });
  };

  const renderCurrentView = () => {
    const isGlobalVerified = userProfile.verification.identity === 'verified' && userProfile.verification.facial === 'verified';

    switch (currentView) {
      case View.RADAR:
        return (
          <RadarMap 
            isHustler={isHustler} 
            isAvailable={userProfile.isAvailable}
            isUserVerified={isGlobalVerified}
            userStats={userStats}
            onToggleAvailability={(v) => updateProfile({ isAvailable: v })}
            onCompleteJob={handleJobVerificationComplete} 
            gigs={userGigs}
            onOpenPushSettings={() => setIsPushSettingsOpen(true)}
            onSimulateAlert={isHustler ? handleSimulateHighPayingGigAlert : handleSimulateEmployerMatchAlert}
            onSelectGig={(gig) => {
              setSelectedGigDetail(gig);
              setCurrentView(View.JOB_DETAILS);
            }}
            onHireHustler={(hustler) => {
              handleDirectHireHustler(hustler);
            }}
            onChatHustler={(hustler) => {
              handleOpenChatWithHustler(hustler);
            }}
            currentHustlerId={currentHustlerId}
            onSwitchHustlerPersona={(id) => {
              setCurrentHustlerId(id);
              localStorage.setItem('sh_current_hustler_id', id);
            }}
            hiredHustlerIds={hiredHustlerIds}
          />
        );
      case View.CHAT:
        return (
          <ChatSystem 
            activeContact={activeChatContact}
            onClearActiveContact={() => setActiveChatContact(null)}
            onBackToRadar={() => setCurrentView(View.RADAR)}
            isHustler={isHustler}
            onDirectHire={handleDirectHireHustler}
            hiredHustlerIds={hiredHustlerIds}
            onCompleteJob={handleJobVerificationComplete}
          />
        );
      case View.WALLET:
        return <WalletPage 
          profile={userProfile} 
          stats={userStats}
          transactions={transactions} 
          onAddTx={handleAddTransaction}
          onUpdateProfile={updateProfile}
          isHustler={isHustler}
        />;
      case View.ACCOUNT:
        return (
          <AccountPage 
            isHustler={isHustler} 
            setIsHustler={handleRoleSwitch} 
            onSignOut={handleSignOut}
            stats={userStats}
            profile={userProfile}
            onUpdateProfile={updateProfile}
            onNavigatePersonalInfo={() => setCurrentView(View.PERSONAL_INFO)}
            onNavigateManageGigs={() => setCurrentView(View.MANAGE_GIGS)}
            onNavigateSecuritySafety={() => setCurrentView(View.SECURITY_SAFETY)}
            onOpenPushSettings={() => setIsPushSettingsOpen(true)}
          />
        );
      case View.PERSONAL_INFO:
        return (
          <PersonalInformationPage 
            profile={userProfile} 
            onUpdate={updateProfile} 
            onBack={() => setCurrentView(View.ACCOUNT)}
          />
        );
      case View.MANAGE_GIGS:
        return (
          <ManageGigsPage 
            gigs={userGigs} 
            stats={userStats} 
            boostCredits={boostCredits}
            onBoost={handleBoostGig} 
            onBack={() => setCurrentView(View.ACCOUNT)} 
          />
        );
      case View.SECURITY_SAFETY:
        return (
          <SecuritySafetyScreen 
            profile={userProfile}
            onUpdate={updateProfile}
            onBack={() => setCurrentView(View.ACCOUNT)}
            onNavigateSupportChat={() => setCurrentView(View.SUPPORT_CHAT)}
          />
        );
      case View.SUPPORT_CHAT:
        return (
          <SupportChatScreen 
            onBack={() => setCurrentView(View.SECURITY_SAFETY)}
          />
        );
      case View.JOB_DETAILS:
        return selectedGigDetail ? (
          <JobDetailsScreen 
            gig={selectedGigDetail} 
            isHustler={isHustler}
            onBack={() => setCurrentView(View.RADAR)}
            onApply={(gig) => {
              alert(`Application sent for ${gig.title}!`);
              setCurrentView(View.CHAT);
            }}
          />
        ) : null;
      default:
        return (
          <RadarMap 
            isHustler={isHustler} 
            isAvailable={userProfile.isAvailable} 
            userStats={userStats} 
            onToggleAvailability={(v) => updateProfile({ isAvailable: v })} 
            gigs={userGigs}
            onSelectGig={(gig) => {
              setSelectedGigDetail(gig);
              setCurrentView(View.JOB_DETAILS);
            }}
            onHireHustler={(hustler) => {
              handleDirectHireHustler(hustler);
            }}
            onChatHustler={(hustler) => {
              handleOpenChatWithHustler(hustler);
            }}
          />
        );
    }
  };

  if (appState === AppState.SPLASH) return <SplashScreen />;
  if (appState === AppState.ONBOARDING) return <Onboarding onComplete={handleFinishTutorial} />;
  if (appState === AppState.AUTH) return <WelcomeAuthScreen onLogin={handleLogin} />;
  if (appState === AppState.ROLE_SELECTION) return <RoleSelectionScreen onSelect={handleRoleSelect} />;

  const isFullScreenView = 
    currentView === View.PERSONAL_INFO || 
    currentView === View.MANAGE_GIGS || 
    currentView === View.SECURITY_SAFETY || 
    currentView === View.SUPPORT_CHAT || 
    currentView === View.JOB_DETAILS;

  return (
    <div className="flex flex-col h-screen w-full max-w-md mx-auto bg-white shadow-2xl relative overflow-hidden">
      {isSwitching && (
        <div className="absolute inset-0 z-[5000] bg-black/60 backdrop-blur-sm flex items-center justify-center p-8">
          <div className="bg-white rounded-3xl p-8 shadow-2xl flex flex-col items-center animate-in zoom-in duration-300">
            <div className="w-12 h-12 border-4 border-slate-100 border-t-[#1B263B] rounded-full animate-spin mb-4"></div>
            <p className="text-[#1B263B] font-black text-center text-xs uppercase tracking-[0.2em]">Synchronizing Profile...</p>
          </div>
        </div>
      )}

      {showAchievement && <AchievementOverlay onClose={() => setShowAchievement(false)} />}

      {activeRatingJob && (
        <RatingDialog 
          jobTitle={activeRatingJob.title}
          hustlerName="Sabelo"
          onClose={() => setActiveRatingJob(null)}
          onSubmit={submitRating}
        />
      )}

      <main className={`flex-1 relative overflow-hidden ${!isFullScreenView ? 'pb-20' : ''}`}>
        {renderCurrentView()}
      </main>

      {/* Immediate 5km High-Paying Skill Match Alert Banner (Hustler Mode Only) */}
      {isHustler && (
        <HighPayingGigAlertBanner
          alert={currentAlert}
          onDismiss={() => setCurrentAlert(null)}
          onViewGig={(gig) => {
            setSelectedGigDetail(gig);
            setCurrentView(View.JOB_DETAILS);
          }}
          onViewOnRadar={() => {
            setCurrentView(View.RADAR);
          }}
        />
      )}

      {/* Available Candidate Match Push Alert Banner (Employer Mode Only) */}
      {!isHustler && (
        <EmployerHustlerMatchAlertBanner
          alert={currentEmployerAlert}
          onDismiss={() => setCurrentEmployerAlert(null)}
          onHireHustler={(hustler, gig) => {
            handleDirectHireHustler(hustler, gig?.title);
          }}
          onChatHustler={(hustler) => {
            handleOpenChatWithHustler(hustler);
          }}
          onViewOnRadar={() => {
            setCurrentView(View.RADAR);
          }}
        />
      )}

      {/* Push Notification & Preference Settings Modal */}
      <PushNotificationSettingsModal
        isOpen={isPushSettingsOpen}
        onClose={() => setIsPushSettingsOpen(false)}
        profile={userProfile}
        onUpdateProfile={updateProfile}
        onSimulateAlert={handleSimulateHighPayingGigAlert}
        isHustler={isHustler}
        onSimulateEmployerAlert={handleSimulateEmployerMatchAlert}
        isNotificationsPaused={isHustler ? isHustlerWorking : isEmployerWorkingWithHustler}
        pausedReason={
          isHustler
            ? (isHustlerWorking ? 'You are currently in working mode on an active job. Push notifications are stopped so you can focus, and will resume once your employer marks the job complete.' : undefined)
            : (isEmployerWorkingWithHustler ? 'You have selected someone for hire who is currently working for you. Candidate match notifications are stopped until the hustler is done working.' : undefined)
        }
      />

      {!isFullScreenView && (
        <>
          {currentView !== View.RADAR && (
            <div className="absolute top-4 right-4 z-[1000]">
              <PanicButton />
            </div>
          )}

          {isNewGigOpen && (
            <GigForm 
              onClose={() => setIsNewGigOpen(false)} 
              isHustler={isHustler} 
              stats={userStats}
              onAddGig={handleAddGig}
              userLocation={userLocation}
            />
          )}

          <BottomNav 
            currentView={currentView} 
            setView={setCurrentView} 
            onAction={() => setIsNewGigOpen(true)}
            isHustler={isHustler}
          />
        </>
      )}
    </div>
  );
};

export default App;
