
import React, { useState, useRef } from 'react';
import { 
  Plus, Printer, Target, Trash2, 
  Database, Copy, Sparkles, Settings2, CheckCircle2,
  BookOpen, AlertCircle, RefreshCcw, X, FileDown
} from 'lucide-react';
import DocumentPreview from './components/DocumentPreview';
import QuestionForm from './components/QuestionForm';
import { Question, DocumentMetadata, Section } from './types';
import { parseRawQuestions, generateQuestions } from './services/geminiService';
import { exportToDocx } from './services/exportService';

const App: React.FC = () => {
  const generateNewId = () => crypto.randomUUID();
  
  const createEmptySection = (): Section => ({
    id: generateNewId(),
    title: '', 
    startNumber: 1,
    questions: []
  });

  const [sections, setSections] = useState<Section[]>([createEmptySection()]);
  const [metadata, setMetadata] = useState<DocumentMetadata>({
    title: 'EXAM_PAPER_TITLE',
    showTitle: false, 
    subtitle: 'BATCH_IDENTIFIER',
    showSubtitle: true,
    pageSettings: { margin: 'Narrow', showBorder: false }
  });

  const [activeSectionId, setActiveSectionId] = useState<string>(() => sections[0].id);
  const [isEditing, setIsEditing] = useState(false);
  const [editingContext, setEditingContext] = useState<{ sectionId: string, questionId: string | null } | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importText, setImportText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState(false);
  
  const previewRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    // Temporarily change document title to influence the default save-as filename in the PDF print dialog
    const originalTitle = document.title;
    const cleanFileName = (metadata.subtitle || metadata.title || "Exam")
      .replace(/[^a-z0-9]/gi, '_')
      .substring(0, 40);
    
    document.title = cleanFileName;
    window.print();
    
    // Restore title shortly after
    setTimeout(() => {
      document.title = originalTitle;
    }, 1500);
  };

  const handleSmartCopy = async () => {
    const el = document.getElementById('preview-content');
    if (!el) return;

    const clone = el.cloneNode(true) as HTMLElement;
    
    const mathContainers = clone.querySelectorAll('.math-container');
    mathContainers.forEach(container => {
      const htmlPart = container.querySelector('.katex-html');
      const mathmlPart = container.querySelector('.katex-mathml');
      
      if (htmlPart) htmlPart.remove(); 
      if (mathmlPart) {
        (mathmlPart as HTMLElement).style.display = 'inline';
        (mathmlPart as HTMLElement).style.position = 'static';
        (mathmlPart as HTMLElement).style.clip = 'auto';
        (mathmlPart as HTMLElement).style.width = 'auto';
        (mathmlPart as HTMLElement).style.height = 'auto';
        (mathmlPart as HTMLElement).style.visibility = 'visible';
      }
    });

    const questionWrappers = clone.querySelectorAll('.question-wrapper');
    questionWrappers.forEach(wrapper => {
      const w = wrapper as HTMLElement;
      w.style.marginBottom = '20px'; 
      w.style.display = 'block';

      const spacer = document.createElement('p');
      spacer.innerHTML = '&nbsp;';
      spacer.style.margin = '0';
      spacer.style.padding = '0';
      spacer.style.height = '15pt';
      w.after(spacer);
    });

    const questionTextContainers = clone.querySelectorAll('.question-text-container');
    questionTextContainers.forEach(container => {
      const c = container as HTMLElement;
      c.style.color = '#DC2626';
      c.style.fontWeight = 'bold';
      c.style.fontSize = '14pt';
      const allChildren = c.querySelectorAll('*');
      allChildren.forEach(child => {
        (child as HTMLElement).style.color = '#DC2626';
      });
    });

    const options = clone.querySelectorAll('.option-item');
    options.forEach(opt => {
      const o = opt as HTMLElement;
      o.style.color = '#000000';
      o.style.fontSize = '12pt';
      o.style.marginBottom = '5px';
    });

    const answers = clone.querySelectorAll('.answer-line span');
    answers.forEach(a => {
      const el = a as HTMLElement;
      el.style.color = '#15803D';
      el.style.fontWeight = 'bold';
      el.style.textDecoration = 'underline';
      el.style.fontSize = '13pt';
    });

    const explanationBoxes = clone.querySelectorAll('.explanation-box');
    explanationBoxes.forEach(box => {
      const b = box as HTMLElement;
      b.style.backgroundColor = '#F0FDF4';
      b.style.border = '1.5pt solid #000000'; 
      b.style.borderRadius = '8px';
      b.style.padding = '15pt';
      b.style.marginTop = '15pt';
      b.style.marginBottom = '15pt';
      b.style.display = 'block';
      
      const textContainer = b.querySelector('.explanation-text-container') as HTMLElement;
      if (textContainer) {
        textContainer.style.fontSize = '11.5pt';
        
        const spans = textContainer.querySelectorAll('span');
        spans.forEach(span => {
          const s = span as HTMLElement;
          if (s.innerText.includes('Explanation -')) {
            s.style.color = '#92400E';
            s.style.fontWeight = 'bold';
          } else {
            if (s.className.includes('text-black')) {
              s.style.color = '#000000';
            }
          }
        });
      }
    });

    const allMath = clone.querySelectorAll('.math-container');
    allMath.forEach(m => {
       (m as HTMLElement).style.fontFamily = 'Cambria Math, serif';
    });

    const htmlBlob = new Blob([clone.outerHTML], { type: 'text/html' });
    const textBlob = new Blob([el.innerText], { type: 'text/plain' });
    
    const data = [new ClipboardItem({ 
      'text/html': htmlBlob, 
      'text/plain': textBlob 
    })];
    
    try {
      await navigator.clipboard.write(data);
      setCopyFeedback(true);
      setTimeout(() => setCopyFeedback(false), 2000);
    } catch (err) {
      console.error("Copy failed", err);
    }
  };

  const handleDownloadDocx = async () => {
    await exportToDocx(metadata, sections);
  };

  const handleReset = () => {
    if (window.confirm("Clear all questions and start fresh?")) {
      const resetSection = createEmptySection();
      setSections([resetSection]);
      setActiveSectionId(resetSection.id);
      setIsEditing(false);
    }
  };

  const handleAddSection = () => {
    const newSection = createEmptySection();
    setSections([...sections, newSection]);
    setActiveSectionId(newSection.id);
  };

  const handleDeleteSection = (id: string) => {
    if (sections.length === 1) return;
    const remaining = sections.filter(s => s.id !== id);
    setSections(remaining);
    if (activeSectionId === id) setActiveSectionId(remaining[0].id);
  };

  const handleSaveQuestion = (question: Question) => {
    if (editingContext) {
      setSections(sections.map(s => {
        if (s.id === editingContext.sectionId) {
          if (editingContext.questionId) {
            return { ...s, questions: s.questions.map(q => q.id === editingContext.questionId ? question : q) };
          }
          return { ...s, questions: [...s.questions, question] };
        }
        return s;
      }));
    } 
    setIsEditing(false);
    setEditingContext(null);
  };

  const handleInstantImport = async () => {
    if (!importText.trim()) {
      alert("Please paste some text first.");
      return;
    }
    const parsed = await parseRawQuestions(importText);
    if (parsed.length > 0) {
      setSections(sections.map(s => 
        s.id === activeSectionId ? { ...s, questions: [...s.questions, ...parsed] } : s
      ));
      setIsImportModalOpen(false);
      setImportText('');
    } else {
      alert("FAIL: No MCQs detected.");
    }
  };

  const handleGenerateAI = async () => {
    const topic = prompt("Enter topic for AI questions:");
    if (!topic) return;
    setIsGenerating(true);
    try {
      const generated = await generateQuestions(topic, 5);
      if (generated.length > 0) {
        setSections(sections.map(s => s.id === activeSectionId ? { ...s, questions: [...s.questions, ...generated] } : s));
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const questionToEdit = editingContext?.questionId 
    ? sections.find(s => s.id === editingContext.sectionId)?.questions.find(q => q.id === editingContext.questionId)
    : undefined;

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-slate-50">
      <header className="no-print h-14 bg-white border-b border-slate-200 flex items-center justify-between px-6 z-30 shrink-0 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="bg-blue-600 p-1.5 rounded-lg">
            <Target size={20} className="text-white" />
          </div>
          <span className="font-bold text-slate-900 tracking-tight text-lg">ExamForge</span>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={handleGenerateAI} 
            disabled={isGenerating} 
            className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-md text-xs font-bold transition-all disabled:opacity-50"
          >
            <Sparkles size={14} /> {isGenerating ? 'AI WORKING...' : 'GENERATE AI'}
          </button>
          <div className="h-6 w-px bg-slate-200 mx-1" />
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
            <button 
              onClick={handleSmartCopy} 
              className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-xs font-bold transition-all shadow-sm ${copyFeedback ? 'bg-green-600 text-white' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
            >
              {copyFeedback ? <CheckCircle2 size={14} /> : <Copy size={14} />}
              {copyFeedback ? 'COPIED!' : 'COPY FOR WORD'}
            </button>
            <button 
              onClick={handleDownloadDocx} 
              className="flex items-center gap-2 px-4 py-1.5 bg-white text-slate-700 hover:bg-slate-50 border border-slate-200 rounded-md text-xs font-bold transition-all shadow-sm"
              title="Download as Word .docx"
            >
              <FileDown size={14} /> WORD FILE
            </button>
          </div>
          <button 
            onClick={handlePrint} 
            className="flex items-center gap-2 px-4 py-1.5 bg-slate-800 text-white hover:bg-slate-900 rounded-md text-xs font-bold transition-all shadow-lg flex items-center gap-2"
          >
            <Printer size={14} /> EXPORT PDF
          </button>
        </div>
      </header>
      <div className="flex flex-1 overflow-hidden">
        <aside className="no-print w-72 bg-white border-r border-slate-200 flex flex-col h-full z-20 overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <h2 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Setup</h2>
            <button onClick={handleReset} className="p-1.5 hover:bg-red-50 text-red-400 rounded-md transition-colors" title="Reset All">
              <RefreshCcw size={14}/>
            </button>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-6">
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-slate-700">
                <Settings2 size={14} className="text-blue-500" />
                <span className="text-[10px] font-bold uppercase tracking-widest">Document Header</span>
              </div>
              <div className="space-y-2">
                <input 
                  type="text" 
                  value={metadata.title} 
                  onChange={e => setMetadata({...metadata, title: e.target.value})} 
                  placeholder="Main Title"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-blue-500 transition-all"
                />
                <input 
                  type="text" 
                  value={metadata.subtitle} 
                  onChange={e => setMetadata({...metadata, subtitle: e.target.value})} 
                  placeholder="Subtitle/Batch"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs outline-none focus:border-blue-500 transition-all"
                />
              </div>
            </div>
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-700">
                  <BookOpen size={14} className="text-blue-500" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Questions</span>
                </div>
                <button onClick={handleAddSection} className="text-blue-600 hover:bg-blue-50 p-1 rounded transition-colors"><Plus size={16}/></button>
              </div>
              <div className="space-y-3">
                {sections.map(s => (
                  <div key={s.id} className={`group border rounded-xl transition-all overflow-hidden ${activeSectionId === s.id ? 'border-blue-200 shadow-sm' : 'border-slate-100'}`}>
                    <div 
                      onClick={() => setActiveSectionId(s.id)}
                      className={`px-3 py-2.5 flex items-center gap-2 cursor-pointer transition-colors ${activeSectionId === s.id ? 'bg-blue-50/30' : 'hover:bg-slate-50'}`}
                    >
                      <input 
                        className="bg-transparent border-none outline-none font-bold text-[11px] uppercase flex-1 placeholder:text-slate-300"
                        value={s.title}
                        onChange={e => setSections(sections.map(sec => sec.id === s.id ? {...sec, title: e.target.value} : sec))}
                        placeholder="SECTION TITLE..."
                        onClick={(e) => e.stopPropagation()}
                      />
                      <button onClick={(e) => {e.stopPropagation(); handleDeleteSection(s.id)}} className="opacity-0 group-hover:opacity-100 text-slate-300 hover:text-red-500 transition-opacity">
                        <Trash2 size={12}/>
                      </button>
                    </div>
                    {activeSectionId === s.id && (
                      <div className="p-3 bg-white space-y-2 border-t border-slate-100">
                        <button 
                          onClick={() => {setEditingContext({sectionId: s.id, questionId: null}); setIsEditing(true);}}
                          className="w-full py-2 bg-blue-600 text-white rounded-lg text-[10px] font-bold hover:bg-blue-700 transition-all flex items-center justify-center gap-1.5 shadow-sm"
                        >
                          <Plus size={14}/> ADD QUESTION
                        </button>
                        <button 
                          onClick={() => {setActiveSectionId(s.id); setIsImportModalOpen(true);}}
                          className="w-full py-2 bg-slate-100 text-slate-600 rounded-lg text-[10px] font-bold hover:bg-slate-200 transition-all flex items-center justify-center gap-1.5"
                        >
                          <Database size={14}/> IMPORT BULK
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </aside>
        <main className="flex-1 flex flex-col overflow-hidden workspace-bg relative">
          {isEditing && (
            <div className="no-print absolute top-10 left-1/2 -translate-x-1/2 z-40 w-full max-w-xl px-4">
              <QuestionForm 
                onSave={handleSaveQuestion} 
                onCancel={() => {setIsEditing(false); setEditingContext(null);}} 
                initialQuestion={questionToEdit} 
              />
            </div>
          )}
          <div className="flex-1 overflow-y-auto p-12 custom-scrollbar flex flex-col items-center">
             <DocumentPreview metadata={metadata} sections={sections} previewRef={previewRef} />
          </div>
        </main>
      </div>
      {isImportModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
            <div className="p-5 border-b bg-slate-50 flex items-center gap-3">
              <div className="p-2 bg-blue-600 text-white rounded-lg"><Database size={20}/></div>
              <div>
                <h3 className="font-bold text-slate-800">Smart Bulk Import</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Paste your questions below</p>
              </div>
              <button onClick={() => setIsImportModalOpen(false)} className="ml-auto p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400">
                <X size={20}/>
              </button>
            </div>
            <div className="flex-1 p-6 space-y-4">
              <textarea 
                value={importText} 
                onChange={e => setImportText(e.target.value)}
                className="w-full h-96 p-4 text-sm font-mono border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 resize-none placeholder:text-slate-300 custom-scrollbar bg-slate-50/50"
                placeholder="Paste content here..."
              />
            </div>
            <div className="p-4 bg-slate-50 border-t flex justify-end gap-3">
              <button onClick={() => setIsImportModalOpen(false)} className="px-5 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-lg uppercase transition-all">Cancel</button>
              <button onClick={handleInstantImport} className="px-8 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-lg shadow-blue-500/20 transition-all flex items-center gap-2 uppercase">
                <CheckCircle2 size={16}/> Process Import
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
