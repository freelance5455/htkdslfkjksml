import 'react-native-url-polyfill/auto';
import React, { useMemo, useState } from 'react';
import {
  Alert, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text,
  TextInput, TouchableOpacity, View
} from 'react-native';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';
import { demoRides, Ride } from './src/data/demoRides';
import { isSupabaseConfigured, supabase } from './src/lib/supabase';

type Tab = 'Home' | 'Search' | 'Publish' | 'Trips' | 'Profile';
type Vehicle = 'Any' | 'Car' | 'Bike';

const GREEN = '#147D58';
const DARK = '#17231E';
const MUTED = '#69766F';
const BG = '#F6F8F7';

function Pill({ label, active, onPress }: { label: string; active?: boolean; onPress: () => void }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.pill, active && styles.pillActive]}>
      <Text style={[styles.pillText, active && styles.pillTextActive]}>{label}</Text>
    </TouchableOpacity>
  );
}

function PrimaryButton({ title, onPress }: { title: string; onPress: () => void }) {
  return (
    <TouchableOpacity style={styles.primaryButton} onPress={onPress}>
      <Text style={styles.primaryButtonText}>{title}</Text>
    </TouchableOpacity>
  );
}

function RideCard({ ride, onBook }: { ride: Ride; onBook: (ride: Ride) => void }) {
  return (
    <View style={styles.rideCard}>
      <View style={styles.rowBetween}>
        <View style={styles.row}>
          <View style={styles.avatar}><Text style={styles.avatarText}>{ride.driverName.slice(0, 1)}</Text></View>
          <View>
            <Text style={styles.driverName}>{ride.driverName}</Text>
            <Text style={styles.smallText}>⭐ {ride.rating.toFixed(1)} · {ride.verified ? '✓ Verified' : 'Verification pending'}</Text>
          </View>
        </View>
        <Text style={styles.price}>₹{ride.price}<Text style={styles.smallText}>/seat</Text></Text>
      </View>
      <View style={styles.routeBox}>
        <View style={styles.routeDotColumn}><View style={styles.dot} /><View style={styles.routeLine} /><View style={[styles.dot, styles.dotEnd]} /></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.routeCity}>{ride.from}</Text>
          <Text style={styles.routeMeta}>{ride.departure} · {ride.date}</Text>
          <View style={{ height: 12 }} />
          <Text style={styles.routeCity}>{ride.to}</Text>
          <Text style={styles.routeMeta}>Approx. arrival {ride.arrival}</Text>
        </View>
      </View>
      <View style={styles.rowBetween}>
        <View style={styles.row}>
          <Text style={styles.vehicleBadge}>{ride.vehicle === 'Car' ? '🚗 Car' : '🏍️ Bike'}</Text>
          <Text style={styles.smallText}>{ride.seats} seat(s) left</Text>
        </View>
        <TouchableOpacity onPress={() => onBook(ride)} style={styles.outlineButton}>
          <Text style={styles.outlineButtonText}>View & book</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.trustRow}>
        <Text style={styles.trustText}>✓ {ride.vehicleVerified ? 'Vehicle verified' : 'Vehicle check pending'}</Text>
        <Text style={styles.trustText}>On-time {ride.onTime}%</Text>
        <Text style={styles.trustText}>Cancel {ride.cancellation}%</Text>
      </View>
    </View>
  );
}

export default function App() {
  const [tab, setTab] = useState<Tab>('Home');
  const [vehicle, setVehicle] = useState<Vehicle>('Any');
  const [from, setFrom] = useState('Jaipur');
  const [to, setTo] = useState('Delhi');
  const [date, setDate] = useState('Tomorrow');
  const [passengers, setPassengers] = useState('1');
  const [rides, setRides] = useState<Ride[]>(demoRides);
  const [myBookings, setMyBookings] = useState<{ ride: Ride; seats: number; id: string; status: string }[]>([]);
  const [publishFrom, setPublishFrom] = useState('Jaipur');
  const [publishTo, setPublishTo] = useState('Delhi');
  const [publishPrice, setPublishPrice] = useState('500');
  const [publishSeats, setPublishSeats] = useState('2');
  const [publishVehicle, setPublishVehicle] = useState<'Car' | 'Bike'>('Car');
  const [driverName, setDriverName] = useState('Guest Driver');
  const [language, setLanguage] = useState<'English' | 'हिन्दी'>('English');

  const filteredRides = useMemo(() => rides.filter(r =>
    (vehicle === 'Any' || r.vehicle === vehicle) &&
    (!from.trim() || r.from.toLowerCase().includes(from.trim().toLowerCase())) &&
    (!to.trim() || r.to.toLowerCase().includes(to.trim().toLowerCase()))
  ), [rides, vehicle, from, to]);

  const bookRide = (ride: Ride) => {
    Alert.alert(
      'Confirm booking',
      `${ride.from} → ${ride.to}\n${ride.vehicle} · ₹${ride.price} per seat\n\nThis MVP uses demo bookings only. No real payment will be taken.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Confirm demo booking', onPress: () => {
          const id = 'SS' + Math.random().toString(36).slice(2, 8).toUpperCase();
          setMyBookings(old => [{ ride, seats: Math.max(1, Number(passengers) || 1), id, status: 'Confirmed (demo)' }, ...old]);
          Alert.alert('Booking created', `Booking ID: ${id}\nDemo only — no payment was processed.`);
          setTab('Trips');
        }}
      ]
    );
  };

  const publishRide = () => {
    const price = Number(publishPrice);
    const seats = Number(publishSeats);
    if (!publishFrom.trim() || !publishTo.trim() || publishFrom.trim().toLowerCase() === publishTo.trim().toLowerCase()) {
      Alert.alert('Check route', 'Please enter different origin and destination cities.');
      return;
    }
    if (!Number.isFinite(price) || price <= 0 || !Number.isInteger(seats) || seats < 1 || seats > (publishVehicle === 'Bike' ? 1 : 8)) {
      Alert.alert('Check ride details', publishVehicle === 'Bike' ? 'Enter a positive fare and 1 passenger seat for a bike ride.' : 'Enter a positive fare and 1–8 available seats.');
      return;
    }
    const ride: Ride = {
      id: 'local-' + Date.now(), driverName, from: publishFrom.trim(), to: publishTo.trim(),
      date: 'Tomorrow', departure: '08:00 AM', arrival: '12:30 PM', vehicle: publishVehicle,
      vehicleModel: publishVehicle === 'Car' ? 'Vehicle details pending' : 'Bike details pending',
      price, seats, rating: 5.0, verified: false, vehicleVerified: false, onTime: 100, cancellation: 0
    };
    setRides(old => [ride, ...old]);
    setFrom(ride.from); setTo(ride.to); setVehicle('Any'); setTab('Search');
    Alert.alert('Ride published locally', 'This ride is saved in this running demo only. Connect Supabase to persist it online.');
  };

  const signInDemo = async () => {
    if (!isSupabaseConfigured || !supabase) {
      Alert.alert('Demo profile', 'Supabase is not connected. You can explore the app using demo mode. Add your Supabase URL and anon key to .env to enable backend features.');
      return;
    }
    Alert.alert('Backend ready', 'Supabase credentials are configured. Add an authentication flow before enabling real user accounts.');
  };

  const navItems: Tab[] = ['Home', 'Search', 'Publish', 'Trips', 'Profile'];
  const title = language === 'हिन्दी' ? 'SafarSaathi' : 'SafarSaathi';

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor={BG} />
      <ExpoStatusBar style="dark" />
      <View style={styles.topBar}>
        <View>
          <Text style={styles.brand}>{title}<Text style={styles.brandDot}>.</Text></Text>
          <Text style={styles.tagline}>{language === 'हिन्दी' ? 'Saath chalein, surakshit chalein' : 'Go together. Travel safer.'}</Text>
        </View>
        <TouchableOpacity style={styles.languageButton} onPress={() => setLanguage(language === 'English' ? 'हिन्दी' : 'English')}>
          <Text style={styles.languageText}>{language === 'English' ? 'हिंदी' : 'EN'}</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {tab === 'Home' && <>
          <View style={styles.hero}>
            <Text style={styles.eyebrow}>SMARTER SHARED TRAVEL</Text>
            <Text style={styles.heroTitle}>{language === 'हिन्दी' ? 'Apni agli ride dhoondhein.' : 'Your next ride, shared.'}</Text>
            <Text style={styles.heroSub}>Carpooling and bike rides across India, with trust signals up front.</Text>
            <View style={styles.vehicleRow}>
              <Pill label="🚗 Car" active={vehicle === 'Car'} onPress={() => setVehicle(vehicle === 'Car' ? 'Any' : 'Car')} />
              <Pill label="🏍️ Bike" active={vehicle === 'Bike'} onPress={() => setVehicle(vehicle === 'Bike' ? 'Any' : 'Bike')} />
              <Pill label="Any" active={vehicle === 'Any'} onPress={() => setVehicle('Any')} />
            </View>
          </View>
          <View style={styles.panel}>
            <Text style={styles.sectionTitle}>Find a ride</Text>
            <Field label="FROM" value={from} onChangeText={setFrom} placeholder="Pickup city" />
            <Field label="TO" value={to} onChangeText={setTo} placeholder="Destination city" />
            <View style={styles.twoColumns}>
              <View style={{ flex: 1 }}><Field label="DATE" value={date} onChangeText={setDate} placeholder="e.g. 12 Oct" /></View>
              <View style={{ flex: 1 }}><Field label="PASSENGERS" value={passengers} onChangeText={setPassengers} keyboardType="number-pad" placeholder="1" /></View>
            </View>
            <PrimaryButton title="Search rides →" onPress={() => setTab('Search')} />
          </View>
          <View style={styles.ctaPanel}>
            <View style={{ flex: 1 }}>
              <Text style={styles.ctaTitle}>Have empty seats?</Text>
              <Text style={styles.ctaText}>Publish your route and share travel costs.</Text>
            </View>
            <TouchableOpacity onPress={() => setTab('Publish')} style={styles.ctaButton}><Text style={styles.ctaButtonText}>+ Publish</Text></TouchableOpacity>
          </View>
          <Text style={styles.sectionTitle}>Popular routes</Text>
          <View style={styles.routeChips}>
            {['Jaipur → Delhi', 'Delhi → Agra', 'Mumbai → Pune'].map(route => <TouchableOpacity key={route} style={styles.routeChip} onPress={() => { const parts = route.split(' → '); setFrom(parts[0]); setTo(parts[1]); setTab('Search'); }}><Text style={styles.routeChipText}>{route}</Text></TouchableOpacity>)}
          </View>
          <Text style={styles.sectionTitle}>Recommended rides</Text>
          {rides.slice(0, 2).map(ride => <RideCard key={ride.id} ride={ride} onBook={bookRide} />)}
        </>}

        {tab === 'Search' && <>
          <Text style={styles.pageTitle}>Find your ride</Text>
          <Text style={styles.pageSub}>Compare fare, vehicle and transparent reliability information.</Text>
          <View style={styles.panel}>
            <Field label="FROM" value={from} onChangeText={setFrom} placeholder="Pickup city" />
            <Field label="TO" value={to} onChangeText={setTo} placeholder="Destination city" />
            <View style={styles.twoColumns}>
              <View style={{ flex: 1 }}><Field label="DATE" value={date} onChangeText={setDate} placeholder="Date" /></View>
              <View style={{ flex: 1 }}><Field label="SEATS" value={passengers} onChangeText={setPassengers} keyboardType="number-pad" placeholder="1" /></View>
            </View>
            <View style={styles.vehicleRow}>
              {(['Any', 'Car', 'Bike'] as Vehicle[]).map(v => <Pill key={v} label={v === 'Car' ? '🚗 Car' : v === 'Bike' ? '🏍️ Bike' : 'Any'} active={vehicle === v} onPress={() => setVehicle(v)} />)}
            </View>
          </View>
          <Text style={styles.resultCount}>{filteredRides.length} matching demo ride(s)</Text>
          {filteredRides.length ? filteredRides.map(ride => <RideCard key={ride.id} ride={ride} onBook={bookRide} />) : <View style={styles.empty}><Text style={styles.emptyIcon}>🧭</Text><Text style={styles.sectionTitle}>No rides found</Text><Text style={styles.pageSub}>Try Jaipur → Delhi or clear the city filters.</Text><TouchableOpacity onPress={() => { setFrom(''); setTo(''); }}><Text style={styles.link}>Clear filters</Text></TouchableOpacity></View>}
          <Text style={styles.disclaimer}>Demo data only. Driver identity and vehicle details have not been independently verified.</Text>
        </>}

        {tab === 'Publish' && <>
          <Text style={styles.pageTitle}>Publish a ride</Text>
          <Text style={styles.pageSub}>Offer empty seats and share travel costs.</Text>
          <View style={styles.panel}>
            <Text style={styles.fieldLabel}>VEHICLE TYPE</Text>
            <View style={styles.vehicleRow}>
              <Pill label="🚗 Car" active={publishVehicle === 'Car'} onPress={() => setPublishVehicle('Car')} />
              <Pill label="🏍️ Bike" active={publishVehicle === 'Bike'} onPress={() => setPublishVehicle('Bike')} />
            </View>
            <Field label="YOUR DISPLAY NAME" value={driverName} onChangeText={setDriverName} placeholder="Name" />
            <Field label="FROM" value={publishFrom} onChangeText={setPublishFrom} placeholder="Pickup city" />
            <Field label="TO" value={publishTo} onChangeText={setPublishTo} placeholder="Destination city" />
            <View style={styles.twoColumns}>
              <View style={{ flex: 1 }}><Field label="PRICE PER SEAT (₹)" value={publishPrice} onChangeText={setPublishPrice} keyboardType="number-pad" placeholder="500" /></View>
              <View style={{ flex: 1 }}><Field label="AVAILABLE SEATS" value={publishSeats} onChangeText={setPublishSeats} keyboardType="number-pad" placeholder="2" /></View>
            </View>
            {publishVehicle === 'Bike' && <View style={styles.notice}><Text style={styles.noticeTitle}>🪖 Bike safety</Text><Text style={styles.noticeText}>Passenger and rider must use helmets as required by applicable law. Confirm licence, vehicle and helmet requirements before a real ride.</Text></View>}
            <View style={styles.notice}><Text style={styles.noticeTitle}>Demo mode</Text><Text style={styles.noticeText}>Ride is added to this app session only. Do not use demo verification or fare values for real bookings.</Text></View>
            <PrimaryButton title="Publish ride" onPress={publishRide} />
          </View>
        </>}

        {tab === 'Trips' && <>
          <Text style={styles.pageTitle}>Your trips</Text>
          <Text style={styles.pageSub}>Bookings made in this demo session.</Text>
          {myBookings.length ? myBookings.map(b => <View key={b.id} style={styles.rideCard}>
            <View style={styles.rowBetween}><Text style={styles.driverName}>{b.ride.from} → {b.ride.to}</Text><Text style={styles.price}>₹{b.ride.price * b.seats}</Text></View>
            <Text style={styles.smallText}>{b.ride.date} · {b.ride.departure} · {b.seats} seat(s)</Text>
            <Text style={styles.smallText}>Booking ID: {b.id}</Text>
            <View style={styles.statusBadge}><Text style={styles.statusText}>{b.status}</Text></View>
            <Text style={styles.disclaimer}>No payment taken. Booking is not valid for real travel.</Text>
          </View>) : <View style={styles.empty}><Text style={styles.emptyIcon}>🎟️</Text><Text style={styles.sectionTitle}>No trips yet</Text><Text style={styles.pageSub}>Find a ride and make a demo booking to see it here.</Text><PrimaryButton title="Find a ride" onPress={() => setTab('Search')} /></View>}
        </>}

        {tab === 'Profile' && <>
          <Text style={styles.pageTitle}>Your profile</Text>
          <View style={styles.profileHero}><View style={styles.bigAvatar}><Text style={styles.bigAvatarText}>S</Text></View><Text style={styles.profileName}>SafarSaathi Guest</Text><Text style={styles.pageSub}>Passenger · Driver mode ready for setup</Text><View style={styles.statusBadge}><Text style={styles.statusText}>Demo profile</Text></View></View>
          <View style={styles.panel}>
            <Text style={styles.sectionTitle}>Trust & safety</Text>
            <InfoRow title="Identity verification" value="Not completed" />
            <InfoRow title="Driving licence" value="Not completed" />
            <InfoRow title="Vehicle verification" value="Not completed" />
            <InfoRow title="Emergency contact" value="Not added" />
            <Text style={styles.disclaimer}>Never treat demo profiles as verified people. Real document review and secure storage must be implemented before launch.</Text>
            <PrimaryButton title="Connect account backend" onPress={signInDemo} />
          </View>
          <View style={styles.panel}>
            <Text style={styles.sectionTitle}>App settings</Text>
            <InfoRow title="Language" value={language} />
            <InfoRow title="Backend" value={isSupabaseConfigured ? 'Configured' : 'Demo only'} />
            <TouchableOpacity onPress={() => Alert.alert('Safety', 'During a real trip, contact local emergency services if in immediate danger. SOS and live sharing are not enabled in this MVP.')} style={styles.safetyButton}><Text style={styles.safetyButtonText}>Safety information</Text></TouchableOpacity>
          </View>
        </>}
      </ScrollView>

      <View style={styles.bottomNav}>
        {navItems.map(item => <TouchableOpacity key={item} style={styles.navItem} onPress={() => setTab(item)}>
          <Text style={[styles.navIcon, tab === item && styles.navIconActive]}>{({ Home: '⌂', Search: '⌕', Publish: '+', Trips: '▤', Profile: '○' } as Record<Tab, string>)[item]}</Text>
          <Text style={[styles.navLabel, tab === item && styles.navLabelActive]}>{item}</Text>
        </TouchableOpacity>)}
      </View>
    </SafeAreaView>
  );
}

function Field({ label, value, onChangeText, placeholder, keyboardType }: {
  label: string; value: string; onChangeText: (value: string) => void; placeholder: string; keyboardType?: 'default' | 'number-pad';
}) {
  return <View style={styles.fieldWrap}>
    <Text style={styles.fieldLabel}>{label}</Text>
    <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#9AA59F" keyboardType={keyboardType || 'default'} style={styles.input} autoCapitalize="words" />
  </View>;
}

function InfoRow({ title, value }: { title: string; value: string }) {
  return <View style={styles.infoRow}><Text style={styles.infoTitle}>{title}</Text><Text style={styles.infoValue}>{value}</Text></View>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: BG },
  topBar: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 14, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  brand: { fontSize: 25, fontWeight: '900', letterSpacing: -0.7, color: DARK },
  brandDot: { color: GREEN },
  tagline: { fontSize: 11, color: MUTED, marginTop: 1 },
  languageButton: { paddingHorizontal: 13, paddingVertical: 9, borderRadius: 15, backgroundColor: '#E5F3EC' },
  languageText: { color: GREEN, fontWeight: '800', fontSize: 12 },
  content: { paddingHorizontal: 16, paddingBottom: 28 },
  hero: { padding: 20, borderRadius: 25, backgroundColor: '#E3F3EA', marginBottom: 14 },
  eyebrow: { color: GREEN, fontWeight: '900', letterSpacing: 1.4, fontSize: 10, marginBottom: 10 },
  heroTitle: { fontSize: 29, lineHeight: 34, color: DARK, fontWeight: '900', letterSpacing: -0.8 },
  heroSub: { fontSize: 13, lineHeight: 19, color: '#53665B', marginTop: 8, maxWidth: 290 },
  vehicleRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 16 },
  pill: { borderWidth: 1, borderColor: '#D7E1DB', paddingVertical: 9, paddingHorizontal: 14, borderRadius: 30, backgroundColor: '#FFFFFF' },
  pillActive: { backgroundColor: GREEN, borderColor: GREEN },
  pillText: { color: DARK, fontSize: 12, fontWeight: '700' },
  pillTextActive: { color: '#FFFFFF' },
  panel: { backgroundColor: '#FFFFFF', borderRadius: 22, padding: 17, marginBottom: 14, borderWidth: 1, borderColor: '#E8EEEA' },
  sectionTitle: { fontSize: 17, fontWeight: '850', color: DARK, marginBottom: 12 },
  fieldWrap: { marginBottom: 13, flex: 1 },
  fieldLabel: { color: MUTED, fontWeight: '800', letterSpacing: 0.9, fontSize: 9, marginBottom: 6 },
  input: { backgroundColor: '#F8FAF9', borderColor: '#E4EBE6', borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 12, color: DARK, fontSize: 14 },
  twoColumns: { flexDirection: 'row', gap: 10 },
  primaryButton: { backgroundColor: GREEN, borderRadius: 14, alignItems: 'center', paddingVertical: 15, marginTop: 3 },
  primaryButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: '900' },
  ctaPanel: { backgroundColor: DARK, borderRadius: 20, padding: 17, flexDirection: 'row', alignItems: 'center', marginBottom: 22 },
  ctaTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '850' },
  ctaText: { color: '#C5D3CB', fontSize: 12, marginTop: 4, lineHeight: 17, maxWidth: 205 },
  ctaButton: { backgroundColor: '#E4F5EB', paddingVertical: 12, paddingHorizontal: 14, borderRadius: 12, marginLeft: 8 },
  ctaButtonText: { color: GREEN, fontSize: 12, fontWeight: '900' },
  routeChips: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginBottom: 22 },
  routeChip: { borderRadius: 12, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E3EAE5', paddingVertical: 10, paddingHorizontal: 11 },
  routeChipText: { color: DARK, fontWeight: '700', fontSize: 11 },
  pageTitle: { color: DARK, fontSize: 27, fontWeight: '900', letterSpacing: -0.5, marginTop: 8 },
  pageSub: { color: MUTED, fontSize: 13, lineHeight: 19, marginTop: 5, marginBottom: 16 },
  resultCount: { color: MUTED, fontSize: 12, fontWeight: '800', marginBottom: 10, marginLeft: 2 },
  rideCard: { backgroundColor: '#FFFFFF', borderRadius: 20, borderWidth: 1, borderColor: '#E7EDE9', padding: 15, marginBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  avatar: { width: 42, height: 42, borderRadius: 15, backgroundColor: '#E3F3EA', alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 18, fontWeight: '900', color: GREEN },
  driverName: { fontSize: 14, fontWeight: '850', color: DARK },
  smallText: { fontSize: 10, color: MUTED, marginTop: 4 },
  price: { color: GREEN, fontSize: 18, fontWeight: '900' },
  routeBox: { flexDirection: 'row', marginVertical: 16, padding: 12, backgroundColor: '#F8FAF9', borderRadius: 14 },
  routeDotColumn: { alignItems: 'center', width: 18, marginRight: 8, paddingTop: 4 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: GREEN },
  dotEnd: { backgroundColor: '#FFFFFF', borderWidth: 2, borderColor: GREEN },
  routeLine: { height: 25, width: 1, borderStyle: 'dashed', borderWidth: 1, borderColor: '#A8B9AE', marginVertical: 3 },
  routeCity: { color: DARK, fontWeight: '850', fontSize: 13 },
  routeMeta: { color: MUTED, fontSize: 10, marginTop: 3 },
  vehicleBadge: { color: DARK, fontWeight: '800', fontSize: 11, backgroundColor: '#EFF4F0', paddingHorizontal: 8, paddingVertical: 6, borderRadius: 8, overflow: 'hidden' },
  outlineButton: { borderWidth: 1, borderColor: GREEN, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 9 },
  outlineButtonText: { color: GREEN, fontWeight: '900', fontSize: 11 },
  trustRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, borderTopWidth: 1, borderTopColor: '#EDF1EE', marginTop: 13, paddingTop: 11 },
  trustText: { color: '#4C6858', fontSize: 9, fontWeight: '700' },
  empty: { backgroundColor: '#FFFFFF', borderRadius: 20, padding: 24, alignItems: 'center', marginBottom: 15 },
  emptyIcon: { fontSize: 34, marginBottom: 10 },
  link: { color: GREEN, fontWeight: '900', marginTop: 10 },
  disclaimer: { color: '#87928B', fontSize: 10, lineHeight: 15, marginTop: 12 },
  notice: { backgroundColor: '#FFF7E6', borderRadius: 13, padding: 12, marginBottom: 12 },
  noticeTitle: { color: '#76501A', fontWeight: '900', fontSize: 12, marginBottom: 4 },
  noticeText: { color: '#765F3C', fontSize: 11, lineHeight: 16 },
  statusBadge: { alignSelf: 'flex-start', backgroundColor: '#E4F5EB', borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6, marginTop: 9 },
  statusText: { color: GREEN, fontWeight: '900', fontSize: 10 },
  profileHero: { backgroundColor: '#E3F3EA', borderRadius: 22, alignItems: 'center', padding: 24, marginVertical: 16 },
  bigAvatar: { width: 68, height: 68, borderRadius: 24, backgroundColor: GREEN, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  bigAvatarText: { color: '#FFFFFF', fontWeight: '900', fontSize: 28 },
  profileName: { color: DARK, fontWeight: '900', fontSize: 19 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#EEF2EF' },
  infoTitle: { color: DARK, fontSize: 12, fontWeight: '700' },
  infoValue: { color: MUTED, fontSize: 11 },
  safetyButton: { marginTop: 12, borderRadius: 12, backgroundColor: '#FFF1EE', padding: 13, alignItems: 'center' },
  safetyButtonText: { color: '#A13D2E', fontWeight: '900', fontSize: 12 },
  bottomNav: { flexDirection: 'row', backgroundColor: '#FFFFFF', borderTopWidth: 1, borderTopColor: '#E6ECE8', paddingTop: 8, paddingBottom: 7, paddingHorizontal: 4 },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 2 },
  navIcon: { color: '#8A968F', fontSize: 23, fontWeight: '700', height: 25 },
  navIconActive: { color: GREEN },
  navLabel: { color: '#8A968F', fontSize: 9, fontWeight: '700' },
  navLabelActive: { color: GREEN, fontWeight: '900' }
});