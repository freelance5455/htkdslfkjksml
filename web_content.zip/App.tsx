// To make Android APK: 1. Deploy to Vercel 2. Go to PWABuilder.com and paste URL 3. Download APK

import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenerativeAI } from '@google/generative-ai';

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  image?: string;
  isError?: boolean;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: 'नमस्ते! मैं Faiz Saathi हूँ 🙏 फोटो भेजो, बोलकर पूछो, लिखकर पूछो - हर सवाल का जवाब दूँगा।',
    },
  ]);
  const [input, setInput] = useState('');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isDark, setIsDark] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // 1. Service Worker Registration & PWA Install Prompt
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').catch((err) => {
          console.error('Service worker registration failed:', err);
        });
      });
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  // 2. Dark mode class toggle
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // 3. Auto-scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  // 4. Auto-resize textarea
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  };

  // 5. Handle image selection
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeSelectedImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // 6. Speech Recognition
  const handleMicClick = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Aapke browser me speech recognition support nahi hai.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'hi-IN';
    recognition.interimResults = false;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
      setIsListening(false);
    };

    recognition.onerror = () => {
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  // 7. Core AI Send handler
  const handleSend = async () => {
    const trimmedInput = input.trim();
    if (!trimmedInput && !selectedImage) return;

    // Get API Key
    let apiKey = (import.meta as any).env?.VITE_GEMINI_API_KEY;
    if (!apiKey) {
      apiKey = localStorage.getItem('gemini_api_key');
    }
    if (!apiKey) {
      apiKey = prompt('Apna Gemini API Key dalo (Google AI Studio se):');
      if (apiKey) {
        localStorage.setItem('gemini_api_key', apiKey.trim());
      } else {
        alert('API Key check karo! Bina API key ke Faiz Saathi jawab nahi de sakta.');
        return;
      }
    }

    const currentImagePreview = imagePreview;
    const currentFile = selectedImage;

    // Add user message
    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: trimmedInput || 'Photo bheji gayi hai',
      image: currentImagePreview || undefined,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    removeSelectedImage();
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
    setIsThinking(true);

    try {
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({
        model: 'gemini-1.5-flash',
        systemInstruction:
          'You are Faiz Saathi AI, a friendly helpful AI for India. You help students, kids, elders. Always reply in easy Hindi (Hinglish). If user uploads image, first describe the image in Hindi, then answer the question about it. If voice transcript comes, answer accordingly. You are created by Faiz.',
      });

      let responseText = '';

      if (currentFile && currentImagePreview) {
        // Base64 without data URI prefix
        const base64WithoutPrefix = currentImagePreview.split(',')[1];
        const promptText = trimmedInput || 'Kripya is photo ko dekhein aur iske baare mein batayein.';
        const result = await model.generateContent([
          promptText,
          {
            inlineData: {
              data: base64WithoutPrefix,
              mimeType: currentFile.type || 'image/jpeg',
            },
          },
        ]);
        responseText = result.response.text();
      } else {
        const result = await model.generateContent(trimmedInput);
        responseText = result.response.text();
      }

      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'ai',
          text: responseText,
        },
      ]);
    } catch (err: any) {
      console.error('Gemini error:', err);
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'ai',
          text: 'API Key check karo! (Error: ' + (err?.message || 'Gemini connection fail') + ')',
          isError: true,
        },
      ]);
    } finally {
      setIsThinking(false);
    }
  };

  const handleSuggestion = (promptText: string) => {
    if (promptText.includes('बोलकर')) {
      handleMicClick();
    } else if (promptText.includes('फोटो')) {
      fileInputRef.current?.click();
    } else if (promptText.includes('निबंध')) {
      setInput('Mujhe ek aasan Hindi nibandh (essay) likh kar do: ');
    } else if (promptText.includes('किस्सा')) {
      setInput('Mujhe Akbar-Birbal ka ek mazedaar aur seekh dene wala kissa sunao!');
    } else {
      setInput(promptText);
    }
  };

  const handleInstallClick = () => {
    if (installPrompt) {
      installPrompt.prompt();
      installPrompt.userChoice.then((choiceResult: any) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('User accepted PWA install');
        }
        setInstallPrompt(null);
      });
    } else {
      alert('PWA already installed ya browser settings me "Add to Home screen" option chunein.');
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-lg mx-auto bg-[#FFFBF5] dark:bg-zinc-900 border-x border-orange-100 dark:border-zinc-800 shadow-xl overflow-hidden font-sans">
      {/* HEADER */}
      <header className="flex items-center justify-between px-4 py-3 bg-white dark:bg-zinc-800 border-b border-orange-100 dark:border-zinc-700 shadow-sm z-10">
        <div className="flex items-center space-x-3">
          {/* Orange turban mascot logo */}
          <div className="w-10 h-10 rounded-full bg-[#FF6B35] flex items-center justify-center text-white text-xl shadow-md border-2 border-white dark:border-zinc-700">
            👳🏽‍♂️
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <h1 className="font-bold text-lg text-zinc-900 dark:text-white leading-tight">
                Faiz Saathi AI
              </h1>
              <span className="text-[10px] font-bold bg-orange-100 dark:bg-orange-950 text-[#FF6B35] px-1.5 py-0.5 rounded">
                AI
              </span>
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">Har Sawaal Ka Saathi 🇮🇳</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {installPrompt && (
            <button
              onClick={handleInstallClick}
              className="text-xs font-semibold bg-[#FF6B35] hover:bg-orange-600 text-white px-2.5 py-1.5 rounded-full shadow-sm flex items-center space-x-1 transition active:scale-95"
            >
              <span>📲</span>
              <span>Install</span>
            </button>
          )}

          {/* Dark / Light Toggle */}
          <button
            onClick={() => setIsDark(!isDark)}
            aria-label="Toggle dark mode"
            className="p-2 rounded-full hover:bg-orange-50 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 transition"
          >
            {isDark ? '☀️' : '🌙'}
          </button>
        </div>
      </header>

      {/* CHAT MESSAGES CONTAINER */}
      <main className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start items-start space-x-2'}`}
          >
            {m.sender === 'ai' && (
              <div className="w-8 h-8 rounded-full bg-[#FF6B35] flex items-center justify-center text-white text-sm shadow flex-shrink-0 mt-1">
                👳🏽‍♂️
              </div>
            )}

            <div
              className={`max-w-[80%] rounded-2xl px-4 py-3 shadow-sm ${
                m.sender === 'user'
                  ? 'bg-[#FF6B35] text-white rounded-br-sm'
                  : m.isError
                  ? 'bg-red-50 text-red-700 border border-red-200 dark:bg-red-950 dark:text-red-200 rounded-bl-sm'
                  : 'bg-white dark:bg-zinc-800 text-zinc-800 dark:text-zinc-100 border border-orange-50 dark:border-zinc-700 rounded-bl-sm'
              }`}
            >
              {m.image && (
                <img
                  src={m.image}
                  alt="Upload preview"
                  className="rounded-xl mb-2 max-h-48 w-full object-cover shadow"
                />
              )}
              <p className="whitespace-pre-wrap text-sm leading-relaxed">{m.text}</p>
            </div>
          </div>
        ))}

        {/* Typing indicator */}
        {isThinking && (
          <div className="flex items-center space-x-2 text-zinc-500 dark:text-zinc-400 text-xs py-1">
            <div className="w-7 h-7 rounded-full bg-[#FF6B35] flex items-center justify-center text-white text-xs">
              👳🏽‍♂️
            </div>
            <div className="bg-white dark:bg-zinc-800 px-3 py-2 rounded-2xl border border-orange-100 dark:border-zinc-700 shadow-sm flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-[#FF6B35] animate-ping" />
              <span className="font-medium text-[#FF6B35]">Faiz सोच रहा है...</span>
            </div>
          </div>
        )}

        {/* 4 Quick Suggestion Chips */}
        {messages.length <= 2 && !isThinking && (
          <div className="pt-2">
            <p className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-2">
              ⚡ Quick Suggestions:
            </p>
            <div className="grid grid-cols-2 gap-2">
              {[
                '📚 होमवर्क की फोटो भेजो',
                '🎤 बोलकर पूछो',
                '✍️ निबंध लिखवाओ',
                '💡 किस्सा सुनाओ',
              ].map((chip) => (
                <button
                  key={chip}
                  onClick={() => handleSuggestion(chip)}
                  className="text-left text-xs bg-white dark:bg-zinc-800 hover:bg-orange-50 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 border border-orange-200 dark:border-zinc-700 px-3 py-2.5 rounded-xl shadow-xs transition active:scale-95"
                >
                  {chip}
                </button>
              ))}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </main>

      {/* VOICE LISTENING OVERLAY */}
      {isListening && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center z-50">
          <div className="bg-white dark:bg-zinc-800 p-6 rounded-3xl shadow-2xl flex flex-col items-center max-w-xs text-center border border-orange-200 dark:border-zinc-700">
            <div className="relative mb-4">
              <div className="w-20 h-20 rounded-full bg-[#FF6B35]/30 animate-ping absolute inset-0" />
              <div className="w-20 h-20 rounded-full bg-[#FF6B35] flex items-center justify-center text-white text-3xl shadow-lg relative">
                🎤
              </div>
            </div>
            <h3 className="font-bold text-lg text-zinc-900 dark:text-white">सुन रहा हूँ... 🎤</h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 mb-4">
              Faiz Saathi sun raha hai, bolein...
            </p>
            <button
              onClick={() => setIsListening(false)}
              className="px-4 py-1.5 rounded-full bg-[#FF6B35] text-white text-xs font-medium"
            >
              Ruk jao
            </button>
          </div>
        </div>
      )}

      {/* BOTTOM INPUT BAR */}
      <footer className="bg-white dark:bg-zinc-800 border-t border-orange-100 dark:border-zinc-700 p-3">
        {/* Selected image preview with 'X' button */}
        {imagePreview && (
          <div className="relative inline-block mb-2">
            <img
              src={imagePreview}
              alt="Thumbnail"
              className="w-16 h-16 object-cover rounded-xl border-2 border-[#FF6B35] shadow"
            />
            <button
              onClick={removeSelectedImage}
              className="absolute -top-1.5 -right-1.5 bg-black text-white w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold shadow"
            >
              ✕
            </button>
          </div>
        )}

        <div className="flex items-center space-x-2">
          {/* a) Camera Button */}
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            capture="environment"
            onChange={handleImageSelect}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            title="Photo upload karein"
            className="p-2.5 rounded-full text-[#FF6B35] hover:bg-orange-50 dark:hover:bg-zinc-700 transition active:scale-95 flex-shrink-0"
          >
            📷
          </button>

          {/* b) Mic Button */}
          <button
            onClick={handleMicClick}
            title="Bolkar poochiye"
            className={`p-2.5 rounded-full transition active:scale-95 flex-shrink-0 ${
              isListening
                ? 'bg-red-500 text-white animate-pulse'
                : 'text-[#FF6B35] hover:bg-orange-50 dark:hover:bg-zinc-700'
            }`}
          >
            🎤
          </button>

          {/* c) Textarea */}
          <textarea
            ref={textareaRef}
            rows={1}
            value={input}
            onChange={handleInputChange}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Kuch bhi poocho..."
            className="flex-1 bg-orange-50/60 dark:bg-zinc-700/60 border border-orange-200 dark:border-zinc-600 rounded-2xl px-4 py-2.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#FF6B35] resize-none max-h-28"
          />

          {/* d) Send Button */}
          <button
            onClick={handleSend}
            disabled={(!input.trim() && !selectedImage) || isThinking}
            title="Bhejo"
            className="p-2.5 rounded-full bg-[#FF6B35] hover:bg-orange-600 disabled:opacity-40 text-white shadow-md transition active:scale-95 flex-shrink-0"
          >
            ➤
          </button>
        </div>
      </footer>
    </div>
  );
}
