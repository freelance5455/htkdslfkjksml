#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="$ROOT/.env"
EXAMPLE="$ROOT/.env.example"
if [[ -e "$ENV_FILE" ]]; then
  echo "Refusing to overwrite existing .env. Back it up and edit it manually if rotation is intended." >&2
  exit 1
fi
command -v openssl >/dev/null 2>&1 || { echo "OpenSSL is required." >&2; exit 1; }
cp "$EXAMPLE" "$ENV_FILE"
chmod 600 "$ENV_FILE"
set_value() {
  local key="$1" value="$2"
  KEY="$key" VALUE="$value" FILE="$ENV_FILE" python3 - <<'PYEDIT'
import os, pathlib, re
p=pathlib.Path(os.environ['FILE'])
s=p.read_text()
k=os.environ['KEY']; v=os.environ['VALUE']
pattern=re.compile(rf'^{re.escape(k)}=.*$', re.M)
if not pattern.search(s): raise SystemExit(f'Missing key in .env.example: {k}')
p.write_text(pattern.sub(f'{k}={v}', s))
PYEDIT
}
secret() { openssl rand -hex 32; }
set_value POSTGRES_PASSWORD "$(secret)"
set_value APP_SECRET "$(secret)"
set_value VOUCHER_CODE_PEPPER "$(secret)"
set_value CLOUD_ADMIN_KEY "$(secret)"
set_value APPRECIATE_CLOUD_API_KEY "$(grep '^CLOUD_ADMIN_KEY=' "$ENV_FILE" | cut -d= -f2-)"
set_value EDGE_ENROLLMENT_KEY "$(secret)"
set_value APPRECIATE_AI_API_KEY "$(secret)"
echo "Created $ENV_FILE with unique random service secrets (file mode 600)."
echo "Next: edit APP_BASE_URL, CORS_ORIGIN and APPRECIATE_CLOUD_URL to your real HTTPS domain."
echo "Do not upload .env to GitHub, share it in chat, or put these values in the APK."
