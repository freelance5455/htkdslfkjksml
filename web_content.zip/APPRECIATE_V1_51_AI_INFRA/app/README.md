# APPRECIATE Platform source in APPRECIATE OS v1.48

> The app package version in `package.json` is 1.45.1. This source directory is part of the wider APPRECIATE OS v1.48 bundle; these are different version labels.

**Bongani Magagula / Appreciate Absalom**  
A self-hosted creator, artist-development, social-commerce and corporate-partnership platform.

## What is in this package

- One-page responsive PWA interface in `public/` (one HTML file; suitable as the hosted target for an HTML-to-APK wrapper).
- Self-hosted Node.js/Express API in `server/` with PostgreSQL persistence.
- Secure account registration/login, bcrypt password hashing, server-side sessions, HttpOnly cookies, CSRF protection, rate limits and role checks.
- Creator campaigns and announcement records; external social publishing is deliberately not marked live.
- Marketplace listings, order records, payment transactions, voucher redemption, ledger entries, management commissions, payout records and refund requests.
- Payment method directory for APPRECIATE vouchers, PayPal, Capitec, FNB, TymeBank, Standard Bank and Absa.
- Corporate enquiry → proposal → agreement → signatures → deliverables → reports → invoice workflow.
- Artist profile applications, management dashboard, rights partner directory and authorised reporting request records.
- Music release metadata, rights declarations, paid entitlement records and offline play-event sync records.
- Manual shipment, delivery status, proof-of-delivery, buyer confirmation and dispute records.
- APPRECIATE Cloud Services developer workspace: private cloud projects, APPRECIATE CODE HTTPS repository URL records, deployment request ledger and provider-readiness status.
- Original APPRECIATE 3D-marketplace brand images carried forward in `public/assets/`.

## Architecture

`Browser / Android WebView / PWA` → same-origin `Express API` → self-hosted `PostgreSQL`.

The app does not require Supabase. Provider integrations are server-side adapters. Keep the `.env` file and all credentials off the public web directory and out of any APK.

## Local setup

1. Install Node.js 20+ and PostgreSQL 14+.
2. Create an empty database and restricted application database role.
3. Copy `.env.example` to `.env` and generate unique values for `APP_SECRET` and `VOUCHER_CODE_PEPPER`.
4. Apply `database/schema.sql` once to a new database. For an existing database, take a backup and apply all migrations not previously applied, in numeric order. This release adds `008_private_evidence_storage.sql`; an existing v1.39 database should be backed up and migrated with 008. Older v1.32 databases must apply migrations 004 through 008 in numeric order after the base schema.
5. Run `npm install` then `npm start`.
6. Open the configured `APP_BASE_URL`.
7. Register the owner as a normal account, then promote it from the trusted server command line with `npm run promote-admin -- owner@example.com`. Public registration never grants administrator privileges.

Do not expose the development server directly to the public internet. Use HTTPS, a reverse proxy, firewall rules, database backups, monitoring and a managed secret store.

## APPRECIATE Cloud Services

The Cloud Services section is built into the existing APPRECIATE app and shares its account system. Users can create private project records, optionally attach a APPRECIATE CODE HTTPS repository URL, choose an application type and preferred region, and save a deployment request for the `main` or another branch. Project records are owner-scoped.

**Cloud service limits:** APPRECIATE CLOUD v1.3 provides native Git repository creation, ZIP source intake, Dockerfile builds and container deployment. The APPRECIATE in-app cloud project request remains a planning record and is not itself a live deployment. Customer database provisioning, billing, quotas, backups, monitoring, custom domains and SSL automation remain incomplete. See `docs/CLOUD_SERVICES.md`.

## Booking design

- Clients submit a preferred service, date, time, duration, location and brief. A request is not an accepted appointment.
- A manager/admin reviews each request and either declines it or accepts it with a ZAR quote. Acceptance creates a client invoice; the client then chooses an available payment method.
- Unpaid booking invoices remain pending. Client cancellation voids an unpaid invoice. A paid invoice is only recorded after voucher validation or a verified provider payment event.
- Calendar synchronisation, automated reminders, availability conflict checking and real-time staff calendars are not included in this release.

## Payment design

- Voucher redemption is internal and can be used only after an administrator issues a voucher.
- PayPal checkout/capture/webhook code is present, but it is disabled until credentials, webhook ID and end-to-end tests are supplied.
- The five named South African banks are channels through a contracted PSP/aggregator. They are not separate APPRECIATE bank APIs. The provider adapter contract is in `integrations/bank-psp-adapter.template.js`.
- Artist payouts are recorded as queued/processing/paid. This package does not initiate a bank transfer.
- A provider-verified webhook or internally validated voucher is the only path that marks a payment paid.

## Important limits

This is a source build and backend starter, not a deployed production service. Email verification, MFA and password recovery are not implemented. v1.40 adds authenticated server-side uploads to a configured private S3-compatible bucket for identity, recording-rights and external partner-mandate evidence, with size/type checks, object verification and short-lived administrator viewing links. Actual storage credentials, malware scanning and human verification remain deployment requirements. APPRECIATE consent is not treated as an external partner mandate; both records are required for reporting. The feature-by-feature status is in `BUILD_STATUS.md` and the external integration release gates are in `docs/INTEGRATION_STATUS.md`.


## APPRECIATE AI integration
The authenticated app API exposes `GET /api/v1/ai/status` and `POST /api/v1/ai/chat`. The browser never receives the model API key. The API forwards only signed-in users' messages to the private `appreciate-ai` Compose service, applies a per-account session requirement and request rate limit, and records successful AI request metadata in the audit log. The AI runtime is part of the unified Compose stack and starts with `docker compose up -d --build`; first startup downloads the configured Ollama model and can take time. Set the same strong `APPRECIATE_AI_API_KEY` in the root `.env` for both the app bridge and AI gateway.
