# APPRECIATE — Operative Applications Activation Plan
Date: 18 November 2026
Baseline: APPRECIATE OS v1.49 audited source package

## Purpose
Turn the consolidated source into genuinely running services and installable user applications. This is an execution plan, not a claim that production deployment has already happened.

## Verified baseline
- `bash scripts/verify-all.sh` completed successfully in the audit environment.
- APPRECIATE platform: 20 tests passed.
- APPRECIATE AI gateway: 4 tests passed.
- APPRECIATE CLOUD control plane: 9 tests passed.
- EDGE/mobile node tests: 3 tests passed.
- Source checks passed.
- Docker and PostgreSQL client binaries were not available in the audit environment. No live database, container, public endpoint, Android APK, payment provider or music-rights partner was tested.

## Application/service boundaries
1. **APPRECIATE Platform** — customer-facing PWA/API and PostgreSQL application data.
2. **APPRECIATE CLOUD** — owner-operated infrastructure control plane, private repositories, builds and container deployment.
3. **APPRECIATE AI** — integrated gateway plus model runtime in the default ecosystem deployment; keep model/API credentials server-side.
4. **APPRECIATE EDGE** — opt-in device agents/coordinator; no remote shell or arbitrary code execution.
5. **RoyaltyTrack SA** — artist rights, repertoire, evidence, consent, reporting and query workflows inside/alongside APPRECIATE. Provider feeds are separate integrations and are not active until authorised and tested.

## Stage 1 — Establish the main platform
On the intended host, install Node.js 20+ and PostgreSQL. Create a dedicated database and user, configure the `app/.env` values from `app/.env.example`, install dependencies with `npm ci`, run the migration script, then start the app with `npm start`.
Acceptance gates:
- `/health` reports database connected.
- New account registration and login work.
- Logout/session expiry work.
- A test user can create and retrieve their own data but cannot access another user's records.
- Restarting the service does not lose data.
- Database backup and restore are demonstrated before real customer data is accepted.

## Stage 2 — Connect APPRECIATE CLOUD
The current app records Cloud project and deployment requests, while native CLOUD separately exposes repository creation, ZIP source upload, build and deployment APIs. The app request is not yet an end-to-end deployment trigger.
Required engineering:
- Add a migration to store the native CLOUD repository/application identifiers against each owner-scoped project.
- Provision a private native repository when a project is created, with safe retry/idempotency.
- Add an authenticated, size-limited source ZIP upload from the owner workspace to the private repository.
- Trigger build, then deploy only after a successful build; persist provider-issued build/application references and truthful states (`queued`, `building`, `live`, `failed`).
- Add timeout handling, retry protection, owner authorization and audit events.
- Do not expose `CLOUD_ADMIN_KEY` to browser code or customer accounts.
Acceptance gates:
- Create project → repository appears in CLOUD.
- Upload source → commit appears in the repository.
- Build → actual image exists.
- Deploy → actual container is running and health-checked.
- Stop/restart/logs are owner-authorized and reflected in the app.
- A failed build never appears as live.

## Stage 3 — RoyaltyTrack SA pilot workflow
Build and test the artist-facing workflow before attempting any partner integration:
1. Artist profile and identity-review state.
2. Recording/repertoire register with ISRC, title, contributors, rights roles, splits and supporting documents.
3. Evidence vault with private storage, malware scanning, strict access control, retention and audit history.
4. APPRECIATE consent per partner and scope, revocable by the artist.
5. Separate record for the partner's own mandate/OAuth/portal authorisation; human review required.
6. Statement intake and reconciliation with separate categories for usage, estimates, official reported royalties and settlement-confirmed payments.
7. Query/dispute case, evidence bundle and exportable history.

Pilot acceptance gates:
- Use 5–10 consenting artists and test/demo data first.
- Verify identity and recording ownership before attributing reports.
- A missing report displays “Awaiting authorised report”, not a fabricated zero.
- Offline plays are not represented as streaming royalties.
- Amounts are never marked paid without settlement evidence.
- Every import, edit, review and export has an audit event.

SAMRO collaboration boundary:
- Present RoyaltyTrack as an artist-support, evidence organisation and reconciliation tool that complements collecting societies.
- Request a discovery meeting and a limited pilot/data-process discussion.
- Do not scrape private portals, bypass access controls, claim SAMRO affiliation, or imply a feed exists before a written agreement and a successful provider-specific test.

## Stage 4 — Activate AI and EDGE
- Start AI only after the main platform is stable and the intended host has enough RAM/storage for the chosen model.
- Keep Ollama and the AI gateway private; test real inference and resource limits.
- Enrol EDGE devices only by explicit owner consent; provide pause/revoke controls and per-device credentials.
- Do not describe multiple phones as one pooled computer or promise uninterrupted availability.

## Stage 5 — Payments, media and Android apps
- Configure private object storage and malware scanning before identity/rights uploads.
- Integrate payments through an approved PSP/merchant account; verify signed webhooks, refunds and settlement before showing payments as confirmed.
- Build and sign Android APKs from the PWA/wrapper source; install on the target phone and test permissions, low-storage handling, updates and offline behaviour.
- Use a public HTTPS domain/reverse proxy and firewall rules for any public deployment. Keep owner APIs and control-plane management private.

## Android phone reality
A Termux + Node.js + PostgreSQL setup can run the main app and local development services if the phone has enough resources and stays awake. It is not a reliable public production host by itself. The native CLOUD build/deploy service requires a Docker-capable host; the current Termux-only phone setup does not provide that Docker engine. Use the phone to administer and test the platform, while a replaceable owner-controlled Linux host runs production containers.

## Release rule
A component is called **operative** only after its live acceptance gates pass on the intended device/host. Passing unit tests or seeing a screen is not proof of a live integration.


## v1.50.0 engineering update — Platform → CLOUD connector

Implemented in source: server-only authenticated Cloud API client; private repository provisioning for new projects when CLOUD credentials are configured; owner-scoped ZIP source upload (24 MB app gateway limit); build-before-deploy orchestration; provider-issued build/application IDs persisted to the deployment ledger; and truthful `building`, `live`, and `failed` outcomes. Browser UI now offers source ZIP upload and Build & deploy. Added migration `app/database/migrations/010_native_cloud_resources.sql` and four connector unit tests.

Verification: `bash scripts/verify-all.sh` passed 40 automated tests and all source checks in this environment. This is not a live deployment test. Docker Engine, PostgreSQL production connectivity, TLS/routing, and APK installation remain unverified here.
