# APPRECIATE AI — self-hosted foundation

This is the integrated APPRECIATE AI gateway to an open-weight language model running inside the unified APPRECIATE deployment. It does not call OpenAI or require an OpenAI API key. The model runtime is Ollama; the default model is `qwen2.5:3b` and can be changed with `APPRECIATE_AI_MODEL`.

## The unified APPRECIATE stack starts this service by default; deploy only on a host with enough resources

1. Run `bash infra/bootstrap-secrets.sh` from the project root. It creates a private `.env` with a unique AI key and other infrastructure secrets.
2. From the project root run `docker compose up -d --build`. The `ai-model-init` service downloads the configured model into the persistent model volume on first start; later starts reuse it.
3. Check locally on the server: `curl http://127.0.0.1:3201/health`. It returns HTTP 200 only when Ollama is reachable and the configured model is installed; otherwise it returns HTTP 503.
5. Send a chat request to `http://127.0.0.1:3201/v1/chat` with `Authorization: Bearer YOUR_KEY` and JSON `{ "messages": [{"role":"user","content":"Hello APPRECIATE"}] }`.

The host port is bound to loopback only. Do not expose the gateway or Ollama port directly to the public internet. Put it behind an authenticated HTTPS reverse proxy before remote use, and keep the API key server-side. The API key is not included in the mobile app.

## Important limits

The code and model choice are self-hostable; inference still needs compute, RAM, disk space and electricity/network access. The default 3B model is a lightweight starting point, not equivalent to a frontier model. Model licence and acceptable-use terms must be checked before commercial deployment. This initial release does not yet include persistent conversational memory, retrieval over APPRECIATE documents, user accounts/roles, moderation policy, admin model controls, or app UI integration. Those are explicit next build stages, not claimed as complete.


## API response and readiness

`GET /health` reports `ready` only when the selected model is present in Ollama. `POST /v1/chat` uses a server-side bearer key and validates message roles and lengths. The request timeout covers the full model response, including response-body reading. The gateway is intentionally bound to host loopback by Compose; do not publish it directly to the public internet.
