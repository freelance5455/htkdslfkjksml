# APPRECIATE v1.51.0 — integrated AI infrastructure

- Promoted APPRECIATE AI from optional Compose profile into the default unified stack.
- Added a strict internal AI service key requirement.
- Added AI gateway readiness health check.
- Added secure local secret bootstrap for app, database, Cloud, EDGE and AI.
- Corrected application health version to 1.51.0.
- Added integrated deployment, infrastructure and provider-cost guidance.

No public deployment or third-party account was provisioned by this source release.
