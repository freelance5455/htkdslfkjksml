# APPRECIATE v1.51 — integrated AI infrastructure

## What changed

- APPRECIATE AI is no longer behind an optional Compose profile. `docker compose up -d --build` starts the platform, PostgreSQL, native Cloud control plane, Ollama model runtime, model pull job, and AI gateway together.
- The AI gateway requires a unique 40+ character internal key at startup. The platform sends it server-to-server; it must never be embedded in the Android APK or browser JavaScript.
- The AI gateway has a readiness health check. It reports ready only after Ollama is reachable and the configured model is installed.
- The app health response version is corrected to 1.51.0.
- `infra/bootstrap-secrets.sh` creates a private `.env` with random service credentials and mode 0600. It refuses to overwrite an existing `.env` and never prints secrets.

## One integrated deployment

1. On a Docker-capable Linux host, extract this complete project. Install Docker Engine + Compose plugin and OpenSSL + Python 3.
2. Run `bash infra/bootstrap-secrets.sh`. It creates `.env` locally on that host. Do not send the file to anyone or commit it.
3. Edit only the public URL placeholders in `.env`: `APP_BASE_URL`, `CORS_ORIGIN`, and `APPRECIATE_CLOUD_URL`. Keep the generated secrets unchanged. Configure DNS and HTTPS reverse proxy to the app service. Cloud control and AI gateway remain private to the Docker network / loopback.
4. Check available resources before starting. The default `qwen2.5:3b` model download needs several GB of disk and the model runtime needs substantial RAM; allow additional headroom for PostgreSQL, Node.js and Cloud builds. CPU inference can be slow. For a production GPU workload, use a dedicated GPU inference host or a private managed endpoint and connect it through a private network/VPN or authenticated TLS endpoint; do not expose Ollama directly. **The v1.51 gateway currently speaks the Ollama API. A RunPod/vLLM or other OpenAI-compatible remote endpoint needs a provider adapter before it can replace Ollama; that adapter is not claimed as implemented in this release.**
5. Run `docker compose config` and then `docker compose up -d --build`. The first start downloads the model and can take time.
6. Verify `curl -fsS https://YOUR_DOMAIN/health`, then sign in to APPRECIATE and check `/api/v1/ai/status`. A 503/not-ready state means model runtime or model download is not ready; inspect `docker compose logs ollama ai-model-init appreciate-ai app`.
7. Test a real signed-in AI chat. Confirm audit-log entry and ensure no secret appears in browser traffic, APK files, logs or Git history.

## Credentials created locally

The bootstrap script generates: PostgreSQL password, app session secret, voucher pepper, Cloud admin key, matching app-to-Cloud key, EDGE enrollment key, and AI gateway key. These are infrastructure secrets, not third-party account credentials.

It cannot create a Render, RunPod, Hugging Face, domain registrar, DNS, payment provider, or cloud account on the owner's behalf. Those accounts require the owner's identity, consent, billing method and provider terms. Never paste provider API tokens into chat. Add them only to the host's secret manager / private environment.

## Model hosting choices researched 19 Nov 2026

- **Self-hosted Ollama (current default):** keeps the model runtime inside the APPRECIATE Docker network and avoids a third-party model API key, but requires a Docker host with enough RAM, CPU/GPU, persistent storage and power. This is the most ownership-oriented initial path.
- **RunPod Serverless:** containerised GPU inference with scale-to-zero and per-second billing; provider currently advertises a starting rate around $0.58/hour equivalent for its 16 GB class. It is a paid external compute provider, not APPRECIATE-owned infrastructure. Validate region, cold-start and actual model fit before purchase.
- **Hugging Face Inference Endpoints:** private dedicated endpoints support token-authenticated access; current published GPU examples start around $0.50/hour for a T4 and $0.80/hour for an L4. Requires an active billing method. Use only with an owner-controlled account and keep token server-side.
- **vLLM:** official Docker images provide an OpenAI-compatible serving API for supported GPUs; it is a possible later inference engine when GPU hardware is available. APPRECIATE needs a tested provider adapter before switching from its current Ollama API integration.

Do not activate paid GPU compute until the owner approves a budget. For the current no-upfront-capital stage, keep the Ollama stack available for local/self-hosted validation and seek a sponsored GPU host or compute credits for public AI service.

## Honest release boundary

This release integrates and configures the AI runtime in the unified deployment. It does **not** mean the runtime has been provisioned on a live public host: that requires an owner-controlled Docker host, DNS/HTTPS and compute resources. AI memory, retrieval over private APPRECIATE documents, model moderation/evaluation and production observability remain further engineering work and are not claimed complete.
