# APPRECIATE CLOUD + AI — v1.51 delivery status

## Integrated in source
- APPRECIATE AI is part of the default unified Docker Compose stack, not an optional profile.
- Ollama model runtime, model initialization job and the authenticated AI gateway start alongside the platform, PostgreSQL and native Cloud control plane.
- The main app proxies signed-in user chat to the private AI gateway. The AI key remains server-side.
- AI requests are rate-limited and successful requests create audit-log events.
- AI gateway readiness is checked against the actual installed model.
- `infra/bootstrap-secrets.sh` creates unique local secrets for PostgreSQL, app sessions, vouchers, Cloud, EDGE and AI.

## Still requires owner-controlled infrastructure
A Docker-capable Linux host, adequate CPU/RAM/storage or sponsored GPU compute, DNS/HTTPS, and a private secret store are still required. No public host, paid GPU account, billing method, domain, or production database has been provisioned by this source build. The owner must create those accounts and approve any spend.

## Not claimed complete
- Live public deployment and real inference on production hardware
- Persistent AI conversation memory and retrieval over private APPRECIATE files
- Production model evaluation, abuse monitoring and independent penetration testing
- Email verification, password recovery and MFA
- External bank, payment, advertising and royalty provider authorisations

See `AI_INFRASTRUCTURE_DEPLOYMENT.md` for the integrated deployment runbook and researched hosting choices.
