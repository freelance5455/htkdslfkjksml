package com.muzik.app;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;

import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_PERMS = 100;
    private static final String[] AUDIO_EXT = {
            ".mp3", ".m4a", ".aac", ".ogg", ".oga", ".opus", ".wav", ".flac"
    };

    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private volatile List<Song> songs = new ArrayList<>();
    private volatile String songsJson = "null"; // "null" = henüz taranmadı
    private volatile int refreshCounter = 0;

    private ListenableFuture<MediaController> controllerFuture;
    private MediaController controller;
    private Runnable pendingAction;

    // ------------------------------------------------------------------ yaşam döngüsü

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0B0B0B"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0B0B0B"));
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // Android 15+ kenardan kenara çizimde durum/gezinme çubuğunun altında kalmasın
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new MusicBridge(), "AndroidMusic");
        webView.loadUrl("file:///android_asset/index.html");

        requestNeededPermissions();
    }

    @Override
    protected void onStart() {
        super.onStart();
        connectController();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshSongs(); // telefona yeni müzik atıldıysa listeye girsin
    }

    @Override
    protected void onStop() {
        disconnectController();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private void requestNeededPermissions() {
        List<String> need = new ArrayList<>();
        String audio = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (ContextCompat.checkSelfPermission(this, audio) != PackageManager.PERMISSION_GRANTED) {
            need.add(audio);
        }
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS); // bildirim panelindeki kontroller için
        }
        if (!need.isEmpty()) {
            ActivityCompat.requestPermissions(this, need.toArray(new String[0]), REQ_PERMS);
        }
    }

    // ------------------------------------------------------------------ oynatıcı bağlantısı

    private void connectController() {
        if (controllerFuture != null) return;
        SessionToken token = new SessionToken(this, new ComponentName(this, PlaybackService.class));
        final ListenableFuture<MediaController> future =
                new MediaController.Builder(this, token).buildAsync();
        controllerFuture = future;
        future.addListener(() -> {
            if (controllerFuture != future) return;
            try {
                controller = future.get();
            } catch (Exception e) {
                return;
            }
            controller.addListener(playerListener);
            if (pendingAction != null) {
                Runnable r = pendingAction;
                pendingAction = null;
                r.run();
            }
            pushState();
            scheduleTick();
        }, ContextCompat.getMainExecutor(this));
    }

    private void disconnectController() {
        handler.removeCallbacks(ticker);
        pendingAction = null;
        if (controller != null) {
            controller.removeListener(playerListener);
            controller = null;
        }
        if (controllerFuture != null) {
            MediaController.releaseFuture(controllerFuture);
            controllerFuture = null;
        }
    }

    private final Player.Listener playerListener = new Player.Listener() {
        @Override
        public void onEvents(Player player, Player.Events events) {
            pushState();
            scheduleTick();
        }
    };

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            pushState();
            scheduleTick();
        }
    };

    /** Çalarken ilerleme çubuğu için yarım saniyede bir durum gönder. */
    private void scheduleTick() {
        handler.removeCallbacks(ticker);
        MediaController c = controller;
        if (c != null && c.isPlaying()) handler.postDelayed(ticker, 500);
    }

    private void onController(Runnable action) {
        if (controller != null) action.run();
        else pendingAction = action;
    }

    // ------------------------------------------------------------------ komutlar

    private boolean playlistMatches(MediaController c, List<Song> list) {
        if (c.getMediaItemCount() != list.size()) return false;
        for (int i = 0; i < list.size(); i++) {
            if (!list.get(i).id.equals(c.getMediaItemAt(i).mediaId)) return false;
        }
        return true;
    }

    private List<MediaItem> buildItems(List<Song> list) {
        List<MediaItem> items = new ArrayList<>();
        for (Song song : list) {
            MediaMetadata.Builder md = new MediaMetadata.Builder().setTitle(song.title);
            if (!song.artist.isEmpty()) md.setArtist(song.artist);
            if (song.art != null) md.setArtworkUri(song.art);
            items.add(new MediaItem.Builder()
                    .setMediaId(song.id)
                    .setUri(song.id)
                    .setMediaMetadata(md.build())
                    .build());
        }
        return items;
    }

    private void playIndex(int index) {
        MediaController c = controller;
        List<Song> list = songs;
        if (c == null || index < 0 || index >= list.size()) return;
        if (playlistMatches(c, list)) {
            c.seekTo(index, 0);
        } else {
            c.setMediaItems(buildItems(list), index, 0);
        }
        c.prepare();
        c.play();
    }

    private void togglePlay() {
        MediaController c = controller;
        if (c == null) return;
        if (c.getMediaItemCount() == 0) {
            playIndex(0);
        } else if (c.getPlayWhenReady()) {
            c.pause();
        } else {
            c.prepare();
            c.play();
        }
    }

    private void skipNext() {
        MediaController c = controller;
        if (c == null) return;
        if (c.getMediaItemCount() == 0) {
            playIndex(0);
        } else {
            c.seekToNextMediaItem();
            c.prepare();
            c.play();
        }
    }

    private void skipPrevious() {
        MediaController c = controller;
        if (c == null) return;
        if (c.getMediaItemCount() == 0) {
            playIndex(0);
        } else {
            c.seekToPreviousMediaItem();
            c.prepare();
            c.play();
        }
    }

    // ------------------------------------------------------------------ arayüze durum gönder

    private void pushState() {
        WebView w = webView;
        if (w == null) return;
        JSONObject o = new JSONObject();
        try {
            MediaController c = controller;
            MediaItem item = c == null ? null : c.getCurrentMediaItem();
            o.put("id", item == null ? "" : item.mediaId);
            o.put("title", item == null || item.mediaMetadata.title == null
                    ? "" : item.mediaMetadata.title.toString());
            o.put("artist", item == null || item.mediaMetadata.artist == null
                    ? "" : item.mediaMetadata.artist.toString());
            o.put("playing", c != null && c.getPlayWhenReady());
            o.put("pos", c == null ? 0 : Math.max(0, c.getCurrentPosition()));
            long d = c == null ? 0 : c.getDuration();
            o.put("dur", d == C.TIME_UNSET ? 0 : Math.max(0, d));
        } catch (JSONException ignored) {
        }
        w.evaluateJavascript("window.onState&&window.onState(" + o + ")", null);
    }

    // ------------------------------------------------------------------ şarkı listesi

    private static class Song {
        String id;      // çalma adresi (aynı zamanda mediaId)
        String title;
        String artist;  // bilinmiyorsa boş
        Uri art;        // albüm kapağı (yoksa null)
    }

    private void refreshSongs() {
        final int myId = ++refreshCounter;
        new Thread(() -> {
            List<Song> list = new ArrayList<>();
            list.addAll(queryBundled());
            list.addAll(queryPhoneLibrary());

            JSONArray arr = new JSONArray();
            for (Song s : list) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("title", s.title);
                    o.put("artist", s.artist);
                    o.put("file", s.id);
                    arr.put(o);
                } catch (JSONException ignored) {
                }
            }
            if (myId != refreshCounter) return; // daha yeni bir tarama başladı
            songs = list;
            songsJson = arr.toString();
            runOnUiThread(() -> {
                if (webView != null) {
                    webView.evaluateJavascript(
                            "window.setSongs&&window.setSongs(" + songsJson + ")", null);
                }
            });
        }).start();
    }

    private static boolean isAudio(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String ext : AUDIO_EXT) {
            if (n.endsWith(ext)) return true;
        }
        return false;
    }

    /** Projedeki "muzik" klasörüne atılan ve APK'ya gömülen dosyalar. */
    private List<Song> queryBundled() {
        List<Song> out = new ArrayList<>();
        try {
            String[] names = getAssets().list("");
            if (names == null) return out;
            Arrays.sort(names, String.CASE_INSENSITIVE_ORDER);
            for (String name : names) {
                if (!isAudio(name)) continue;
                int dot = name.lastIndexOf('.');
                String title = dot > 0 ? name.substring(0, dot) : name;
                String artist = "";

                try (AssetFileDescriptor afd = getAssets().openFd(name)) {
                    MediaMetadataRetriever r = new MediaMetadataRetriever();
                    try {
                        r.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                        String t = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                        String a = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                        if (t != null && !t.trim().isEmpty()) title = t.trim();
                        if (a != null && !a.trim().isEmpty()) artist = a.trim();
                    } finally {
                        r.release();
                    }
                } catch (Exception ignored) {
                }

                Song s = new Song();
                s.id = "asset:///" + Uri.encode(name);
                s.title = title;
                s.artist = artist;
                out.add(s);
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    /** Telefonun müzik kütüphanesi (Müzik klasörü vb.). */
    private List<Song> queryPhoneLibrary() {
        List<Song> out = new ArrayList<>();
        ContentResolver resolver = getContentResolver();
        Uri collection = Build.VERSION.SDK_INT >= 29
                ? MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Uri albumArt = Uri.parse("content://media/external/audio/albumart");

        String[] projection = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.ALBUM_ID
        };
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String sort = MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC";

        try (Cursor c = resolver.query(collection, projection, selection, null, sort)) {
            if (c == null) return out;
            int idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
            int titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
            int artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
            int nameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME);
            int albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID);

            while (c.moveToNext()) {
                String title = c.getString(titleCol);
                String artist = c.getString(artistCol);
                if (title == null || title.trim().isEmpty()) title = c.getString(nameCol);
                if (title == null) title = "";
                if (artist == null || artist.equals("<unknown>")) artist = "";

                Song s = new Song();
                s.id = ContentUris.withAppendedId(collection, c.getLong(idCol)).toString();
                s.title = title;
                s.artist = artist;
                long albumId = c.getLong(albumCol);
                if (albumId > 0) s.art = ContentUris.withAppendedId(albumArt, albumId);
                out.add(s);
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    // ------------------------------------------------------------------ WebView köprüsü

    public class MusicBridge {
        @JavascriptInterface
        public String getMusic() {
            return songsJson;
        }

        @JavascriptInterface
        public void ready() {
            runOnUiThread(() -> pushState());
        }

        @JavascriptInterface
        public void play(int index) {
            runOnUiThread(() -> onController(() -> playIndex(index)));
        }

        @JavascriptInterface
        public void toggle() {
            runOnUiThread(() -> onController(() -> togglePlay()));
        }

        @JavascriptInterface
        public void next() {
            runOnUiThread(() -> onController(() -> skipNext()));
        }

        @JavascriptInterface
        public void prev() {
            runOnUiThread(() -> onController(() -> skipPrevious()));
        }

        @JavascriptInterface
        public void seekTo(long positionMs) {
            runOnUiThread(() -> {
                if (controller != null) controller.seekTo(positionMs);
            });
        }
    }
}
