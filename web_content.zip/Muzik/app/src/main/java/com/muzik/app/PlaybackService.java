package com.muzik.app;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.List;

/**
 * Arka planda çalma servisi.
 * MediaSession sayesinde kilit ekranında ve bildirim panelinde
 * oynat / duraklat / önceki / sonraki / ilerleme çubuğu otomatik görünür.
 */
public class PlaybackService extends MediaSessionService {

    private MediaSession mediaSession;
    private int errorStreak = 0;

    @Override
    public void onCreate() {
        super.onCreate();

        final ExoPlayer player = new ExoPlayer.Builder(this)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(), true)            // ses odağını (arama vb.) yönet
                .setHandleAudioBecomingNoisy(true) // kulaklık çıkınca duraklat
                .setWakeMode(C.WAKE_MODE_LOCAL)    // ekran kapalıyken de çalsın
                .build();
        player.setRepeatMode(Player.REPEAT_MODE_ALL);

        // Bozuk / silinmiş bir dosya çalmayı durdurmasın: sıradakine geç
        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                if (isPlaying) errorStreak = 0;
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                errorStreak++;
                if (errorStreak < player.getMediaItemCount()) {
                    player.seekToNextMediaItem();
                    player.prepare();
                    player.play();
                }
            }
        });

        // Bildirime dokununca uygulama açılsın
        PendingIntent openApp = PendingIntent.getActivity(
                this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        mediaSession = new MediaSession.Builder(this, player)
                .setSessionActivity(openApp)
                .setCallback(new SessionCallback())
                .build();
    }

    @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    /** Uygulama son uygulamalardan silinirse: çalıyorsa devam et, değilse servisi kapat. */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Player player = mediaSession == null ? null : mediaSession.getPlayer();
        if (player == null || !player.getPlayWhenReady() || player.getMediaItemCount() == 0) {
            stopSelf();
        }
    }

    @Override
    public void onDestroy() {
        if (mediaSession != null) {
            mediaSession.getPlayer().release();
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }

    /** Uygulamadan gelen şarkıları (mediaId = adres) çalınabilir hâle getirir. */
    private static class SessionCallback implements MediaSession.Callback {
        @Override
        public ListenableFuture<List<MediaItem>> onAddMediaItems(
                MediaSession session, MediaSession.ControllerInfo controller, List<MediaItem> mediaItems) {
            List<MediaItem> resolved = new ArrayList<>();
            for (MediaItem item : mediaItems) {
                if (item.localConfiguration != null) {
                    resolved.add(item);
                } else {
                    Uri uri = item.requestMetadata.mediaUri != null
                            ? item.requestMetadata.mediaUri
                            : Uri.parse(item.mediaId);
                    resolved.add(item.buildUpon().setUri(uri).build());
                }
            }
            return Futures.immediateFuture(resolved);
        }
    }
}
