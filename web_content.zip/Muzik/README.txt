MÜZİK - ANDROID

Telefonda müzik çalan, arka planda çalmaya devam eden ve kilit ekranı /
bildirim panelinden kontrol edilebilen Android uygulaması.

ÖZELLİKLER
- Arka planda çalma (ekran kapalı, uygulama kapalı)
- Kilit ekranı ve bildirim panelinde oynat / duraklat / önceki / sonraki / ilerleme
- Kulaklık çıkınca otomatik duraklatma, arama gelince ses odağı yönetimi
- Karanlık tema

MÜZİK EKLEMEK (liste düzenlemek yok)
  1) "muzik" klasörüne ses dosyası at (mp3, m4a, aac, ogg, opus, wav, flac).
     Dosyalar APK'nın içine gömülür ve otomatik listelenir.
  2) İstersen dosyaları telefonun "Müzik" klasörüne de kopyalayabilirsin.
     Uygulama açıldığında telefondaki müzikler de otomatik listelenir.

APK OLUŞTURMA - YÖNTEM 1: Android Studio
  1) Projeyi Android Studio ile aç, Gradle senkronizasyonunu bekle.
  2) Build > Build Bundle(s) / APK(s) > Build APK(s)
  3) APK: app/build/outputs/apk/debug/app-debug.apk
     Telefona at ve dokunarak kur (bilinmeyen kaynaklara izin ver).

APK OLUŞTURMA - YÖNTEM 2: Android Studio olmadan (GitHub)
  1) github.com'da yeni bir depo aç, bu projenin TÜM dosyalarını yükle
     (gizli ".github" klasörü de dahil).
  2) Depoda Actions sekmesi > "APK olustur" çalışır (2-4 dk).
  3) Bittiğinde çalışmanın altındaki "Muzik-APK" dosyasını indir,
     içinden Muzik.apk çıkar. Telefona at ve kur.
  Not: GitHub web yüklemesinde tek dosya sınırı 25 MB. Büyük müzikler için git kullan.

İZİNLER
  İlk açılışta "müzik ve ses" ve "bildirim" izni istenir. Bildirim izni
  verilmezse kilit ekranı / bildirim paneli kontrolleri görünmeyebilir.

DEĞİŞTİRMEK İSTERSEN
  - Uygulama adı: app/src/main/res/values/strings.xml
  - Arayüz: app/src/main/assets/index.html
