MARINA FROID – Version 100 % OFFLINE
====================================

Application de gestion (devis, factures, clients, stock)
pour technicien climatisation – fonctionne SANS internet
et SANS serveur Node.js.

INSTALLATION SUR ANDROID
------------------------
1. Copiez le dossier "Marina-Froid-Offline" sur votre téléphone
   (ou servez-le via un petit serveur local / USB).

2. Ouvrez le fichier index.html avec Chrome.

3. Menu ⋮ → « Installer l'application » ou « Ajouter à l'écran d'accueil ».

4. L'icône Marina Froid apparaît. L'application fonctionne ensuite
   même sans connexion.

ALTERNATIVE – Convertir en APK
------------------------------
Vous pouvez utiliser un convertisseur en ligne gratuit :
  • https://www.htmltoapp.net/
  • https://www.apkmaker.dev/

Étapes :
1. Compressez le dossier Marina-Froid-Offline en ZIP
2. Uploadez le ZIP sur le site
3. Nom : Marina Froid
4. Package : com.marinafroid.app
5. Icône : icons/icon-512.png
6. Téléchargez l'APK et installez-le

PREMIÈRE UTILISATION
--------------------
- Créez un code d'accès (4 caractères minimum)
- Les données sont stockées uniquement sur l'appareil
- Exportez régulièrement via Réglages → Exporter JSON

CONTACT
-------
Ghislain Simo – Technicien
Tél : +237 640 345 510
Email : simoghislain640@gmail.com
Axe Lourd Bonabé, Douala
