/* Marina Froid – Stockage 100% offline (IndexedDB) */
const DB_NAME = 'marina-froid';
const DB_VER = 1;

let db = null;

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = (e) => {
      const d = e.target.result;
      if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta');
      if (!d.objectStoreNames.contains('clients')) {
        const s = d.createObjectStore('clients', { keyPath: 'id', autoIncrement: true });
        s.createIndex('nom', 'nom', { unique: false });
      }
      if (!d.objectStoreNames.contains('articles')) {
        const s = d.createObjectStore('articles', { keyPath: 'id', autoIncrement: true });
        s.createIndex('nom', 'nom', { unique: false });
      }
      if (!d.objectStoreNames.contains('devis')) {
        const s = d.createObjectStore('devis', { keyPath: 'id', autoIncrement: true });
        s.createIndex('numero', 'numero', { unique: true });
        s.createIndex('statut', 'statut', { unique: false });
      }
      if (!d.objectStoreNames.contains('factures')) {
        const s = d.createObjectStore('factures', { keyPath: 'id', autoIncrement: true });
        s.createIndex('numero', 'numero', { unique: true });
        s.createIndex('statut', 'statut', { unique: false });
      }
      if (!d.objectStoreNames.contains('mouvements')) {
        d.createObjectStore('mouvements', { keyPath: 'id', autoIncrement: true });
      }
    };
    req.onsuccess = () => { db = req.result; resolve(db); };
    req.onerror = () => reject(req.error);
  });
}

function tx(store, mode = 'readonly') {
  return db.transaction(store, mode).objectStore(store);
}

function getAll(store) {
  return new Promise((resolve, reject) => {
    const r = tx(store).getAll();
    r.onsuccess = () => resolve(r.result || []);
    r.onerror = () => reject(r.error);
  });
}

function get(store, id) {
  return new Promise((resolve, reject) => {
    const r = tx(store).get(id);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

function put(store, data) {
  return new Promise((resolve, reject) => {
    const r = tx(store, 'readwrite').put(data);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

function add(store, data) {
  return new Promise((resolve, reject) => {
    const r = tx(store, 'readwrite').add(data);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

function del(store, id) {
  return new Promise((resolve, reject) => {
    const r = tx(store, 'readwrite').delete(id);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
}

function getMeta(key) {
  return new Promise((resolve, reject) => {
    const r = tx('meta').get(key);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

function setMeta(key, value) {
  return new Promise((resolve, reject) => {
    const r = tx('meta', 'readwrite').put(value, key);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
}

/* Compteurs pour numéros */
async function nextNumero(prefix) {
  const key = 'seq_' + prefix;
  let n = (await getMeta(key)) || 0;
  n += 1;
  await setMeta(key, n);
  const year = new Date().getFullYear();
  return `${prefix}-${year}-${String(n).padStart(4, '0')}`;
}

/* Seed initial */
async function seedIfEmpty() {
  const arts = await getAll('articles');
  if (arts.length) return;
  const defaults = [
    { nom: 'Installation climatiseur split', categorie: 'Installation', prix: 45000, stock: 0, unite: 'forfait' },
    { nom: 'Dépannage climatisation', categorie: 'Dépannage', prix: 15000, stock: 0, unite: 'intervention' },
    { nom: 'Recharge gaz R410A', categorie: 'Dépannage', prix: 25000, stock: 5, unite: 'kg' },
    { nom: 'Ventilateur plafond', categorie: 'Ventilateur', prix: 35000, stock: 8, unite: 'pièce' },
    { nom: 'Réparation frigo', categorie: 'Frigo', prix: 12000, stock: 0, unite: 'intervention' },
    { nom: 'Fer à repasser (réparation)', categorie: 'Fer à repasser', prix: 5000, stock: 0, unite: 'intervention' },
    { nom: 'Filtre climatiseur', categorie: 'Pièces détachées', prix: 3500, stock: 20, unite: 'pièce' },
    { nom: 'Main d\'œuvre (heure)', categorie: 'Dépannage', prix: 5000, stock: 0, unite: 'heure' },
  ];
  for (const a of defaults) await add('articles', a);
}

window.DB = { openDB, getAll, get, put, add, del, getMeta, setMeta, nextNumero, seedIfEmpty };
