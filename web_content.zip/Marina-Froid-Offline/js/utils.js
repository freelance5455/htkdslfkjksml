const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

function money(n) {
  const v = Number(n) || 0;
  return v.toLocaleString('fr-FR') + ' FCFA';
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function formatDate(d) {
  if (!d) return '—';
  const [y, m, day] = String(d).slice(0, 10).split('-');
  return `${day}/${m}/${y}`;
}

function toast(msg, ms = 2500) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.add('hidden'), ms);
}

function openModal(title, html) {
  $('#modal-title').textContent = title;
  $('#modal-body').innerHTML = html;
  $('#modal').showModal();
}

function closeModal() {
  $('#modal').close();
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function badge(statut) {
  const map = {
    brouillon: 'brouillon', envoye: 'envoye', accepte: 'accepte', refuse: 'refuse',
    validee: 'validee', payee: 'payee', partiel: 'partiel', annulee: 'annulee'
  };
  const cls = map[statut] || 'brouillon';
  const labels = {
    brouillon: 'Brouillon', envoye: 'Envoyé', accepte: 'Accepté', refuse: 'Refusé',
    validee: 'Validée', payee: 'Payée', partiel: 'Partiel', annulee: 'Annulée'
  };
  return `<span class="badge ${cls}">${labels[statut] || statut}</span>`;
}

window.U = { $, $$, money, today, formatDate, toast, openModal, closeModal, esc, badge };
