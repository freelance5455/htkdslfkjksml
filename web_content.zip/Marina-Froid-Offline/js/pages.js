const Pages = {
  async dashboard(zone) {
    const [clients, devis, factures, articles] = await Promise.all([
      DB.getAll('clients'), DB.getAll('devis'), DB.getAll('factures'), DB.getAll('articles')
    ]);
    const ca = factures.filter(f => f.statut === 'payee' || f.statut === 'validee' || f.statut === 'partiel')
      .reduce((s, f) => s + (f.total || 0), 0);
    const aPayer = factures.filter(f => f.statut === 'validee' || f.statut === 'partiel')
      .reduce((s, f) => s + ((f.total || 0) - (f.paye || 0)), 0);
    const stockBas = articles.filter(a => a.stock > 0 && a.stock <= 3).length;

    zone.innerHTML = `
      <div class="stats">
        <div class="stat"><div class="val">${clients.length}</div><div class="lbl">Clients</div></div>
        <div class="stat"><div class="val">${devis.length}</div><div class="lbl">Devis</div></div>
        <div class="stat"><div class="val">${factures.length}</div><div class="lbl">Factures</div></div>
        <div class="stat"><div class="val">${money(ca).replace(' FCFA','')}</div><div class="lbl">CA (FCFA)</div></div>
      </div>
      <div class="card" style="margin-top:16px">
        <h3>Résumé</h3>
        <p>À encaisser : <strong>${money(aPayer)}</strong></p>
        <p>Articles en stock bas : <strong>${stockBas}</strong></p>
        <p class="muted" style="margin-top:12px">Données stockées uniquement sur cet appareil (offline).</p>
      </div>
      <div class="toolbar" style="margin-top:16px">
        <button class="btn primary" data-go="devis">+ Nouveau devis</button>
        <button class="btn secondary" data-go="factures">+ Nouvelle facture</button>
      </div>`;
    zone.querySelectorAll('[data-go]').forEach(b => b.onclick = () => App.go(b.dataset.go));
  },

  async clients(zone) {
    const list = await DB.getAll('clients');
    list.sort((a, b) => (a.nom || '').localeCompare(b.nom || ''));
    zone.innerHTML = `
      <div class="toolbar">
        <input type="search" id="search" placeholder="Rechercher un client…">
        <button class="btn primary" id="btn-add">+ Client</button>
      </div>
      <div class="list" id="list"></div>`;
    const render = (q = '') => {
      const filtered = list.filter(c => !q || (c.nom + c.telephone + c.adresse).toLowerCase().includes(q.toLowerCase()));
      const el = U.$('#list');
      if (!filtered.length) {
        el.innerHTML = `<div class="empty"><div class="ico">👥</div>Aucun client</div>`;
        return;
      }
      el.innerHTML = filtered.map(c => `
        <div class="item" data-id="${c.id}">
          <div class="info">
            <div class="title">${U.esc(c.nom)}</div>
            <div class="sub">${U.esc(c.telephone || '—')} · ${U.esc(c.adresse || '')}</div>
          </div>
        </div>`).join('');
      el.querySelectorAll('.item').forEach(it => it.onclick = () => editClient(Number(it.dataset.id)));
    };
    render();
    U.$('#search').oninput = e => render(e.target.value);
    U.$('#btn-add').onclick = () => editClient(null);

    async function editClient(id) {
      const c = id ? await DB.get('clients', id) : { nom: '', telephone: '', adresse: '', email: '', notes: '' };
      U.openModal(id ? 'Modifier client' : 'Nouveau client', `
        <form id="f">
          <label>Nom *</label><input name="nom" value="${U.esc(c.nom)}" required>
          <label>Téléphone</label><input name="telephone" value="${U.esc(c.telephone || '')}" type="tel">
          <label>Email</label><input name="email" value="${U.esc(c.email || '')}" type="email">
          <label>Adresse</label><input name="adresse" value="${U.esc(c.adresse || '')}">
          <label>Notes</label><textarea name="notes">${U.esc(c.notes || '')}</textarea>
          <div class="form-actions">
            <button type="submit" class="btn primary">Enregistrer</button>
            ${id ? '<button type="button" class="btn danger" id="del">Supprimer</button>' : ''}
            <button type="button" class="btn ghost" data-close>Annuler</button>
          </div>
        </form>`);
      U.$('#f').onsubmit = async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const data = Object.fromEntries(fd);
        if (id) { data.id = id; await DB.put('clients', data); }
        else await DB.add('clients', data);
        U.closeModal(); U.toast('Client enregistré'); App.go('clients');
      };
      if (id) U.$('#del').onclick = async () => {
        if (!confirm('Supprimer ce client ?')) return;
        await DB.del('clients', id); U.closeModal(); U.toast('Supprimé'); App.go('clients');
      };
    }
  },

  async articles(zone) {
    const list = await DB.getAll('articles');
    list.sort((a, b) => (a.nom || '').localeCompare(b.nom || ''));
    zone.innerHTML = `
      <div class="toolbar">
        <input type="search" id="search" placeholder="Rechercher…">
        <button class="btn primary" id="btn-add">+ Article / Service</button>
      </div>
      <div class="list" id="list"></div>`;
    const render = (q = '') => {
      const filtered = list.filter(a => !q || (a.nom + a.categorie).toLowerCase().includes(q.toLowerCase()));
      const el = U.$('#list');
      if (!filtered.length) { el.innerHTML = `<div class="empty"><div class="ico">📦</div>Aucun article</div>`; return; }
      el.innerHTML = filtered.map(a => `
        <div class="item" data-id="${a.id}">
          <div class="info">
            <div class="title">${U.esc(a.nom)}</div>
            <div class="sub">${U.esc(a.categorie || '')} · ${U.money(a.prix)} / ${U.esc(a.unite || 'u')}</div>
            <div class="meta">Stock : ${a.stock ?? 0}</div>
          </div>
        </div>`).join('');
      el.querySelectorAll('.item').forEach(it => it.onclick = () => editArt(Number(it.dataset.id)));
    };
    render();
    U.$('#search').oninput = e => render(e.target.value);
    U.$('#btn-add').onclick = () => editArt(null);

    async function editArt(id) {
      const a = id ? await DB.get('articles', id) : { nom: '', categorie: 'Dépannage', prix: 0, stock: 0, unite: 'pièce' };
      const cats = ['Climatisation','Réfrigération','Ventilateur','Frigo','Fer à repasser','Dépannage','Installation','Pièces détachées'];
      U.openModal(id ? 'Modifier article' : 'Nouvel article', `
        <form id="f">
          <label>Nom *</label><input name="nom" value="${U.esc(a.nom)}" required>
          <label>Catégorie</label>
          <select name="categorie">${cats.map(c => `<option ${c===a.categorie?'selected':''}>${c}</option>`).join('')}</select>
          <div class="form-row">
            <div><label>Prix (FCFA)</label><input name="prix" type="number" min="0" value="${a.prix||0}"></div>
            <div><label>Unité</label><input name="unite" value="${U.esc(a.unite||'pièce')}"></div>
          </div>
          <label>Stock actuel</label><input name="stock" type="number" value="${a.stock??0}">
          <div class="form-actions">
            <button type="submit" class="btn primary">Enregistrer</button>
            ${id ? '<button type="button" class="btn danger" id="del">Supprimer</button>' : ''}
            <button type="button" class="btn ghost" data-close>Annuler</button>
          </div>
        </form>`);
      U.$('#f').onsubmit = async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const data = {
          nom: fd.get('nom'), categorie: fd.get('categorie'),
          prix: Number(fd.get('prix')) || 0, unite: fd.get('unite'),
          stock: Number(fd.get('stock')) || 0
        };
        if (id) { data.id = id; await DB.put('articles', data); }
        else await DB.add('articles', data);
        U.closeModal(); U.toast('Enregistré'); App.go('articles');
      };
      if (id) U.$('#del').onclick = async () => {
        if (!confirm('Supprimer ?')) return;
        await DB.del('articles', id); U.closeModal(); U.toast('Supprimé'); App.go('articles');
      };
    }
  },

  async stock(zone) {
    const articles = await DB.getAll('articles');
    const mouvements = await DB.getAll('mouvements');
    mouvements.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
    zone.innerHTML = `
      <div class="toolbar">
        <button class="btn primary" id="btn-mvt">+ Mouvement de stock</button>
      </div>
      <div class="card"><h3>État du stock</h3>
        <div class="list" id="stock-list"></div>
      </div>
      <div class="card"><h3>Derniers mouvements</h3>
        <div class="list" id="mvt-list"></div>
      </div>`;
    U.$('#stock-list').innerHTML = articles.filter(a => a.stock !== undefined).map(a => `
      <div class="item"><div class="info">
        <div class="title">${U.esc(a.nom)}</div>
        <div class="sub">Stock : <strong>${a.stock}</strong> ${U.esc(a.unite||'')}</div>
      </div></div>`).join('') || '<p class="muted">Aucun article suivi en stock</p>';
    U.$('#mvt-list').innerHTML = mouvements.slice(0, 20).map(m => `
      <div class="item"><div class="info">
        <div class="title">${m.type === 'entree' ? '➕' : '➖'} ${U.esc(m.articleNom)}</div>
        <div class="sub">${m.qte} · ${U.formatDate(m.date)} · ${U.esc(m.note||'')}</div>
      </div></div>`).join('') || '<p class="muted">Aucun mouvement</p>';

    U.$('#btn-mvt').onclick = async () => {
      const arts = await DB.getAll('articles');
      U.openModal('Mouvement de stock', `
        <form id="f">
          <label>Article</label>
          <select name="articleId" required>
            ${arts.map(a => `<option value="${a.id}">${U.esc(a.nom)} (stock ${a.stock})</option>`).join('')}
          </select>
          <label>Type</label>
          <select name="type"><option value="entree">Entrée (+)</option><option value="sortie">Sortie (-)</option></select>
          <label>Quantité</label><input name="qte" type="number" min="1" value="1" required>
          <label>Note</label><input name="note" placeholder="Réception, casse…">
          <div class="form-actions">
            <button type="submit" class="btn primary">Valider</button>
            <button type="button" class="btn ghost" data-close>Annuler</button>
          </div>
        </form>`);
      U.$('#f').onsubmit = async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const id = Number(fd.get('articleId'));
        const type = fd.get('type');
        const qte = Number(fd.get('qte')) || 0;
        const art = await DB.get('articles', id);
        if (!art) return;
        const delta = type === 'entree' ? qte : -qte;
        art.stock = (art.stock || 0) + delta;
        if (art.stock < 0) art.stock = 0;
        await DB.put('articles', art);
        await DB.add('mouvements', {
          articleId: id, articleNom: art.nom, type, qte, note: fd.get('note'), date: U.today()
        });
        U.closeModal(); U.toast('Stock mis à jour'); App.go('stock');
      };
    };
  },

  async devis(zone) {
    await renderDocs(zone, 'devis', 'Devis', ['brouillon', 'envoye', 'accepte', 'refuse']);
  },

  async factures(zone) {
    await renderDocs(zone, 'factures', 'Factures', ['brouillon', 'validee', 'payee', 'partiel', 'annulee']);
  },

  async reglages(zone) {
    const params = (await DB.getMeta('params')) || {
      nom: 'Marina Froid', telephone: '+237 640 345 510',
      email: 'simoghislain640@gmail.com', adresse: 'Axe Lourd Bonabé, Douala',
      devise: 'FCFA', tva: 0
    };
    zone.innerHTML = `
      <div class="card">
        <h3>Informations entreprise</h3>
        <form id="f">
          <label>Nom</label><input name="nom" value="${U.esc(params.nom)}">
          <label>Téléphone</label><input name="telephone" value="${U.esc(params.telephone)}">
          <label>Email</label><input name="email" value="${U.esc(params.email)}">
          <label>Adresse</label><input name="adresse" value="${U.esc(params.adresse)}">
          <label>TVA par défaut (%)</label><input name="tva" type="number" value="${params.tva||0}">
          <div class="form-actions">
            <button type="submit" class="btn primary">Enregistrer</button>
          </div>
        </form>
      </div>
      <div class="card">
        <h3>Données</h3>
        <p class="muted">Toutes les données sont stockées localement dans ce navigateur / cette application.</p>
        <button class="btn secondary" id="btn-export" style="margin-top:10px">Exporter JSON</button>
        <button class="btn danger" id="btn-reset" style="margin-top:10px;margin-left:8px">Effacer toutes les données</button>
      </div>`;
    U.$('#f').onsubmit = async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      await DB.setMeta('params', {
        nom: fd.get('nom'), telephone: fd.get('telephone'), email: fd.get('email'),
        adresse: fd.get('adresse'), tva: Number(fd.get('tva')) || 0, devise: 'FCFA'
      });
      U.toast('Réglages enregistrés');
    };
    U.$('#btn-export').onclick = async () => {
      const data = {
        clients: await DB.getAll('clients'),
        articles: await DB.getAll('articles'),
        devis: await DB.getAll('devis'),
        factures: await DB.getAll('factures'),
        mouvements: await DB.getAll('mouvements'),
        params: await DB.getMeta('params')
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `marina-froid-export-${U.today()}.json`;
      a.click();
      U.toast('Export téléchargé');
    };
    U.$('#btn-reset').onclick = async () => {
      if (!confirm('Vraiment tout effacer ? Cette action est irréversible.')) return;
      indexedDB.deleteDatabase(DB_NAME);
      location.reload();
    };
  }
};

async function renderDocs(zone, store, label, statuts) {
  const list = await DB.getAll(store);
  list.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  zone.innerHTML = `
    <div class="toolbar">
      <input type="search" id="search" placeholder="Rechercher…">
      <button class="btn primary" id="btn-add">+ ${label.slice(0, -1)}</button>
    </div>
    <div class="list" id="list"></div>`;
  const render = (q = '') => {
    const filtered = list.filter(d => !q || (d.numero + (d.clientNom || '') + d.statut).toLowerCase().includes(q.toLowerCase()));
    const el = U.$('#list');
    if (!filtered.length) {
      el.innerHTML = `<div class="empty"><div class="ico">📄</div>Aucun ${label.toLowerCase()}</div>`;
      return;
    }
    el.innerHTML = filtered.map(d => `
      <div class="item" data-id="${d.id}">
        <div class="info">
          <div class="title">${U.esc(d.numero)} ${U.badge(d.statut)}</div>
          <div class="sub">${U.esc(d.clientNom || '—')} · ${U.formatDate(d.date)}</div>
          <div class="meta">${U.money(d.total)}</div>
        </div>
        <button class="btn sm ghost btn-print-item" data-id="${d.id}" title="Imprimer">📄</button>
      </div>`).join('');
    el.querySelectorAll('.item').forEach(it => {
      it.onclick = (e) => {
        if (e.target.closest('.btn-print-item')) return;
        editDoc(store, Number(it.dataset.id));
      };
    });
    el.querySelectorAll('.btn-print-item').forEach(btn => {
      btn.onclick = async (e) => {
        e.stopPropagation();
        const d = await DB.get(store, Number(btn.dataset.id));
        if (d) await printDocument(store, d);
      };
    });
  };
  render();
  U.$('#search').oninput = e => render(e.target.value);
  U.$('#btn-add').onclick = () => editDoc(store, null);
}

async function editDoc(store, id) {
  const isDevis = store === 'devis';
  const clients = await DB.getAll('clients');
  const articles = await DB.getAll('articles');
  let doc = id ? await DB.get(store, id) : null;
  if (!doc) {
    doc = {
      numero: await DB.nextNumero(isDevis ? 'DEV' : 'FAC'),
      date: U.today(), statut: 'brouillon',
      clientId: '', clientNom: '', lignes: [], total: 0, note: '', paye: 0
    };
  }

  const linesHtml = (doc.lignes || []).map((l, i) => `
    <div class="line" data-i="${i}">
      <input name="des" value="${U.esc(l.designation)}" placeholder="Désignation">
      <input name="qte" type="number" min="0" step="0.5" value="${l.qte||1}">
      <input name="prix" type="number" min="0" value="${l.prix||0}">
      <button type="button" class="icon-btn rm">✕</button>
    </div>`).join('') || `
    <div class="line" data-i="0">
      <input name="des" placeholder="Désignation">
      <input name="qte" type="number" min="0" step="0.5" value="1">
      <input name="prix" type="number" min="0" value="0">
      <button type="button" class="icon-btn rm">✕</button>
    </div>`;

  const statutOpts = isDevis
    ? [['brouillon','Brouillon'],['envoye','Envoyé'],['accepte','Accepté'],['refuse','Refusé']]
    : [['brouillon','Brouillon'],['validee','Validée'],['payee','Payée'],['partiel','Partiellement payée'],['annulee','Annulée']];

  U.openModal(id ? `Modifier ${doc.numero}` : `Nouveau ${isDevis ? 'devis' : 'facture'}`, `
    <form id="f">
      <div class="form-row">
        <div><label>N°</label><input name="numero" value="${U.esc(doc.numero)}" readonly></div>
        <div><label>Date</label><input name="date" type="date" value="${doc.date||U.today()}"></div>
      </div>
      <label>Client</label>
      <select name="clientId">
        <option value="">— Choisir —</option>
        ${clients.map(c => `<option value="${c.id}" ${c.id==doc.clientId?'selected':''}>${U.esc(c.nom)}</option>`).join('')}
      </select>
      <label>Lignes (désignation / qté / prix)</label>
      <div class="lines" id="lines">${linesHtml}</div>
      <button type="button" class="btn sm ghost" id="add-line">+ Ligne</button>
      <div class="total-box">Total : <span id="tot">${U.money(doc.total)}</span></div>
      ${!isDevis ? `<label>Déjà payé (FCFA)</label><input name="paye" type="number" min="0" value="${doc.paye||0}">` : ''}
      <label>Statut</label>
      <select name="statut">${statutOpts.map(([v,l]) => `<option value="${v}" ${v===doc.statut?'selected':''}>${l}</option>`).join('')}</select>
      <label>Note</label><textarea name="note">${U.esc(doc.note||'')}</textarea>
      <div class="form-actions">
        <button type="submit" class="btn primary">Enregistrer</button>
        ${id ? '<button type="button" class="btn secondary" id="btn-print">📄 Imprimer / PDF</button>' : ''}
        ${id ? '<button type="button" class="btn danger" id="del">Supprimer</button>' : ''}
        <button type="button" class="btn ghost" data-close>Annuler</button>
      </div>
    </form>`);

  const recalc = () => {
    let t = 0;
    U.$$('#lines .line').forEach(line => {
      const q = Number(line.querySelector('[name=qte]').value) || 0;
      const p = Number(line.querySelector('[name=prix]').value) || 0;
      t += q * p;
    });
    U.$('#tot').textContent = U.money(t);
    return t;
  };
  U.$('#lines').oninput = recalc;
  U.$('#add-line').onclick = () => {
    const div = document.createElement('div');
    div.className = 'line';
    div.innerHTML = `<input name="des" placeholder="Désignation"><input name="qte" type="number" value="1"><input name="prix" type="number" value="0"><button type="button" class="icon-btn rm">✕</button>`;
    U.$('#lines').appendChild(div);
    div.querySelector('.rm').onclick = () => { div.remove(); recalc(); };
  };
  U.$$('#lines .rm').forEach(b => b.onclick = () => { b.closest('.line').remove(); recalc(); });

  // Quick add from articles
  if (articles.length) {
    const sel = document.createElement('select');
    sel.innerHTML = `<option value="">+ Ajouter un article…</option>` + articles.map(a =>
      `<option value="${a.id}" data-prix="${a.prix}" data-nom="${U.esc(a.nom)}">${U.esc(a.nom)} – ${U.money(a.prix)}</option>`).join('');
    sel.style.marginBottom = '10px';
    U.$('#lines').before(sel);
    sel.onchange = () => {
      const opt = sel.selectedOptions[0];
      if (!opt.value) return;
      const div = document.createElement('div');
      div.className = 'line';
      div.innerHTML = `<input name="des" value="${opt.dataset.nom}"><input name="qte" type="number" value="1"><input name="prix" type="number" value="${opt.dataset.prix}"><button type="button" class="icon-btn rm">✕</button>`;
      U.$('#lines').appendChild(div);
      div.querySelector('.rm').onclick = () => { div.remove(); recalc(); };
      sel.value = '';
      recalc();
    };
  }

  U.$('#f').onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const lignes = [];
    U.$$('#lines .line').forEach(line => {
      const des = line.querySelector('[name=des]').value.trim();
      if (!des) return;
      const qte = Number(line.querySelector('[name=qte]').value) || 0;
      const prix = Number(line.querySelector('[name=prix]').value) || 0;
      lignes.push({ designation: des, qte, prix, total: qte * prix });
    });
    const total = lignes.reduce((s, l) => s + l.total, 0);
    const clientId = fd.get('clientId') ? Number(fd.get('clientId')) : null;
    const client = clientId ? clients.find(c => c.id === clientId) : null;
    const data = {
      numero: fd.get('numero'), date: fd.get('date'), statut: fd.get('statut'),
      clientId, clientNom: client ? client.nom : '',
      lignes, total, note: fd.get('note'), paye: Number(fd.get('paye')) || 0
    };
    if (id) { data.id = id; await DB.put(store, data); }
    else await DB.add(store, data);
    U.closeModal(); U.toast('Enregistré'); App.go(store);
  };
  if (id) {
    U.$('#del').onclick = async () => {
      if (!confirm('Supprimer ce document ?')) return;
      await DB.del(store, id); U.closeModal(); U.toast('Supprimé'); App.go(store);
    };
    U.$('#btn-print').onclick = async () => {
      // Collect current form values so print reflects latest edits even if not saved
      const fd = new FormData(U.$('#f'));
      const lignes = [];
      U.$$('#lines .line').forEach(line => {
        const des = line.querySelector('[name=des]').value.trim();
        if (!des) return;
        const qte = Number(line.querySelector('[name=qte]').value) || 0;
        const prix = Number(line.querySelector('[name=prix]').value) || 0;
        lignes.push({ designation: des, qte, prix, total: qte * prix });
      });
      const total = lignes.reduce((s, l) => s + l.total, 0);
      const clientId = fd.get('clientId') ? Number(fd.get('clientId')) : null;
      const client = clientId ? clients.find(c => c.id === clientId) : null;
      const snap = {
        numero: fd.get('numero'),
        date: fd.get('date'),
        statut: fd.get('statut'),
        clientNom: client ? client.nom : (doc.clientNom || ''),
        clientTel: client ? (client.telephone || '') : '',
        clientAdresse: client ? (client.adresse || '') : '',
        lignes, total,
        note: fd.get('note'),
        paye: Number(fd.get('paye')) || 0
      };
      await printDocument(store, snap);
    };
  }
}

async function printDocument(store, doc) {
  const isDevis = store === 'devis';
  const params = (await DB.getMeta('params')) || {
    nom: 'Marina Froid',
    telephone: '+237 640 345 510',
    email: 'simoghislain640@gmail.com',
    adresse: 'Axe Lourd Bonabé, Douala'
  };
  // Enrichir avec les infos client si manquantes
  if (doc.clientId && (!doc.clientTel || !doc.clientAdresse)) {
    try {
      const c = await DB.get('clients', doc.clientId);
      if (c) {
        doc.clientNom = doc.clientNom || c.nom;
        doc.clientTel = doc.clientTel || c.telephone || '';
        doc.clientAdresse = doc.clientAdresse || c.adresse || '';
      }
    } catch (e) {}
  }

  const lignesRows = (doc.lignes || []).map(l => `
    <tr>
      <td>${U.esc(l.designation)}</td>
      <td style="text-align:center">${l.qte}</td>
      <td style="text-align:right">${U.money(l.prix)}</td>
      <td style="text-align:right">${U.money(l.total)}</td>
    </tr>`).join('') || '<tr><td colspan="4" style="text-align:center;color:#888">Aucune ligne</td></tr>';

  const titre = isDevis ? 'DEVIS' : 'FACTURE';
  const reste = !isDevis ? Math.max(0, (doc.total || 0) - (doc.paye || 0)) : 0;

  const html = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>${titre} ${U.esc(doc.numero)} – Marina Froid</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: system-ui, -apple-system, 'Segoe UI', sans-serif; color: #1a2330; padding: 24px; max-width: 800px; margin: 0 auto; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #366086; padding-bottom: 16px; margin-bottom: 20px; }
    .logo { width: 72px; height: 72px; border-radius: 50%; object-fit: cover; }
    .company h1 { font-size: 22px; color: #366086; margin-bottom: 4px; }
    .company p { font-size: 12px; color: #5a6a7a; line-height: 1.4; }
    .doc-title { text-align: right; }
    .doc-title h2 { font-size: 20px; color: #e37c31; letter-spacing: 1px; }
    .doc-title p { font-size: 13px; color: #5a6a7a; margin-top: 4px; }
    .meta { display: flex; justify-content: space-between; margin-bottom: 24px; gap: 20px; }
    .box { background: #f4f6f9; border-radius: 8px; padding: 12px 16px; flex: 1; }
    .box h3 { font-size: 11px; text-transform: uppercase; color: #5a6a7a; margin-bottom: 6px; letter-spacing: .05em; }
    .box p { font-size: 14px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
    th { background: #366086; color: #fff; padding: 10px 12px; text-align: left; font-size: 12px; text-transform: uppercase; }
    td { padding: 10px 12px; border-bottom: 1px solid #e0e6ec; font-size: 14px; }
    tr:nth-child(even) td { background: #f8fafc; }
    .totals { text-align: right; margin-bottom: 20px; }
    .totals .line { font-size: 14px; margin: 4px 0; }
    .totals .grand { font-size: 20px; font-weight: 800; color: #366086; margin-top: 8px; }
    .note { background: #fff8f0; border-left: 4px solid #e37c31; padding: 12px 16px; font-size: 13px; margin-bottom: 24px; }
    .footer { border-top: 1px solid #d0d8e0; padding-top: 12px; font-size: 11px; color: #5a6a7a; text-align: center; }
    @media print {
      body { padding: 0; }
      .no-print { display: none !important; }
    }
  </style>
</head>
<body>
  <div class="header">
    <div style="display:flex;gap:14px;align-items:center">
      <img class="logo" src="icons/logo.png" alt="Marina Froid" onerror="this.style.display='none'">
      <div class="company">
        <h1>${U.esc(params.nom || 'Marina Froid')}</h1>
        <p>${U.esc(params.adresse || '')}<br>
        ${U.esc(params.telephone || '')}<br>
        ${U.esc(params.email || '')}</p>
      </div>
    </div>
    <div class="doc-title">
      <h2>${titre}</h2>
      <p>N° <strong>${U.esc(doc.numero)}</strong><br>
      Date : ${U.formatDate(doc.date)}</p>
    </div>
  </div>

  <div class="meta">
    <div class="box">
      <h3>Client</h3>
      <p><strong>${U.esc(doc.clientNom || '—')}</strong><br>
      ${U.esc(doc.clientTel || '')}<br>
      ${U.esc(doc.clientAdresse || '')}</p>
    </div>
    <div class="box">
      <h3>Document</h3>
      <p>Type : ${titre}<br>
      Statut : ${U.esc(doc.statut || '')}</p>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Désignation</th>
        <th style="text-align:center;width:70px">Qté</th>
        <th style="text-align:right;width:110px">Prix unit.</th>
        <th style="text-align:right;width:120px">Total</th>
      </tr>
    </thead>
    <tbody>${lignesRows}</tbody>
  </table>

  <div class="totals">
    <div class="line">Total HT : ${U.money(doc.total)}</div>
    ${!isDevis && doc.paye ? `<div class="line">Déjà payé : ${U.money(doc.paye)}</div>
    <div class="line">Reste à payer : ${U.money(reste)}</div>` : ''}
    <div class="grand">${U.money(doc.total)}</div>
  </div>

  ${doc.note ? `<div class="note"><strong>Note :</strong> ${U.esc(doc.note)}</div>` : ''}

  <div class="footer">
    Marina Froid – Technicien Climatisation · ${U.esc(params.telephone || '+237 640 345 510')} · ${U.esc(params.adresse || 'Axe Lourd Bonabé')}
  </div>

  <div class="no-print" style="margin-top:32px;text-align:center">
    <button onclick="window.print()" style="padding:12px 28px;font-size:16px;background:#e37c31;color:#fff;border:0;border-radius:10px;cursor:pointer;font-weight:700">
      Imprimer / Enregistrer en PDF
    </button>
    <p style="margin-top:10px;font-size:12px;color:#888">Sur mobile : utilisez le menu du navigateur → Imprimer → Enregistrer en PDF</p>
  </div>
</body>
</html>`;

  const w = window.open('', '_blank');
  if (!w) {
    U.toast('Autorisez les pop-ups pour imprimer');
    return;
  }
  w.document.write(html);
  w.document.close();
  // Try to trigger print after load (desktop)
  setTimeout(() => { try { w.focus(); } catch(e) {} }, 300);
}

window.Pages = Pages;
