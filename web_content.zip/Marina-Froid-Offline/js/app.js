const App = {
  user: null,
  page: 'dashboard',

  async init() {
    await DB.openDB();
    await DB.seedIfEmpty();

    // Auth check
    const session = await DB.getMeta('session');
    const setup = await DB.getMeta('setup');

    setTimeout(() => {
      U.$('#splash').classList.add('hidden');
      if (!setup) this.showSetup();
      else if (!session) this.showLogin();
      else {
        this.user = session;
        this.showMain();
      }
    }, 900);

    // Modal close
    document.addEventListener('click', (e) => {
      if (e.target.matches('[data-close]') || e.target.id === 'overlay') {
        U.closeModal();
        this.closeSidebar();
      }
    });
    U.$('#modal').addEventListener('click', (e) => {
      if (e.target.id === 'modal') U.closeModal();
    });
  },

  showSetup() {
    U.$('#auth').classList.remove('hidden');
    U.$('#auth-title').textContent = 'Bienvenue';
    U.$('#auth-sub').textContent = 'Créez votre code d\'accès (4 chiffres min.)';
    U.$('#auth-form').onsubmit = async (e) => {
      e.preventDefault();
      const nom = U.$('#auth-nom').value.trim();
      const code = U.$('#auth-code').value;
      if (code.length < 4) {
        U.$('#auth-error').textContent = 'Code trop court';
        U.$('#auth-error').classList.remove('hidden');
        return;
      }
      await DB.setMeta('setup', { nom, code, date: U.today() });
      await DB.setMeta('session', { nom });
      await DB.setMeta('params', {
        nom: 'Marina Froid',
        telephone: '+237 640 345 510',
        email: 'simoghislain640@gmail.com',
        adresse: 'Axe Lourd Bonabé, Douala',
        tva: 0, devise: 'FCFA'
      });
      this.user = { nom };
      U.$('#auth').classList.add('hidden');
      this.showMain();
      U.toast('Compte créé');
    };
  },

  showLogin() {
    U.$('#auth').classList.remove('hidden');
    U.$('#auth-title').textContent = 'Connexion';
    U.$('#auth-sub').textContent = 'Entrez votre code d\'accès';
    U.$('#auth-nom').parentElement.style.display = 'none';
    U.$('#auth-form').onsubmit = async (e) => {
      e.preventDefault();
      const code = U.$('#auth-code').value;
      const setup = await DB.getMeta('setup');
      if (!setup || setup.code !== code) {
        U.$('#auth-error').textContent = 'Code incorrect';
        U.$('#auth-error').classList.remove('hidden');
        return;
      }
      await DB.setMeta('session', { nom: setup.nom });
      this.user = { nom: setup.nom };
      U.$('#auth').classList.add('hidden');
      this.showMain();
    };
  },

  showMain() {
    U.$('#main').classList.remove('hidden');
    U.$('#user-name').textContent = this.user?.nom || 'Utilisateur';
    U.$('#btn-menu').onclick = () => this.toggleSidebar();
    U.$('#overlay').onclick = () => this.closeSidebar();
    U.$('#btn-logout').onclick = async () => {
      await DB.setMeta('session', null);
      location.reload();
    };
    U.$('#nav').onclick = (e) => {
      const btn = e.target.closest('[data-page]');
      if (!btn) return;
      this.go(btn.dataset.page);
      this.closeSidebar();
    };
    this.go('dashboard');
  },

  toggleSidebar() {
    U.$('#sidebar').classList.toggle('open');
    U.$('#overlay').classList.toggle('hidden');
  },
  closeSidebar() {
    U.$('#sidebar').classList.remove('open');
    U.$('#overlay').classList.add('hidden');
  },

  async go(page) {
    this.page = page;
    U.$$('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.page === page));
    const titles = {
      dashboard: 'Tableau de bord', clients: 'Clients', devis: 'Devis',
      factures: 'Factures', articles: 'Articles & Services', stock: 'Stock', reglages: 'Réglages'
    };
    U.$('#page-title').textContent = titles[page] || page;
    const zone = U.$('#content');
    zone.innerHTML = '<div class="empty"><div class="loader" style="margin:0 auto"></div></div>';
    try {
      if (Pages[page]) await Pages[page](zone);
      else zone.innerHTML = '<p class="empty">Page inconnue</p>';
    } catch (err) {
      console.error(err);
      zone.innerHTML = `<p class="empty">Erreur : ${U.esc(err.message)}</p>`;
    }
  }
};

document.addEventListener('DOMContentLoaded', () => App.init());
window.App = App;
