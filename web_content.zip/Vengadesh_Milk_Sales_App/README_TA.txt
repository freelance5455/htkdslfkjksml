VENGADESH MILK SALES - APP PROJECT

இந்த ZIP-ல் உள்ளவை:
- தினசரி பால் / தயிர் பதிவு
- கடை சேர்த்தல், பெயர் மாற்றம், கடை வாரியான கணக்கு
- வசூல் பதிவு மற்றும் பாக்கி கணக்கு
- பால் / தயிர் விலை மாற்றம்
- தினசரி மற்றும் மாதாந்திர அறிக்கை
- Print / Save as PDF (Android Print menu-ல் Save as PDF தேர்வு செய்யவும்)
- Report text Share (WhatsApp போன்ற apps-க்கு)
- JSON Backup / Restore, CSV பதிவிறக்கம்
- PWA offline support மற்றும் mobile install manifest

பயன்படுத்த:
1. ZIP-ஐ Extract செய்யவும்.
2. index.html-ஐ browser-ல் திறந்து பார்க்கலாம்.
3. PWA install / offline service worker பயன்பாட்டிற்கு HTTPS hosting அல்லது localhost தேவை.
4. Android Chrome-ல் hosting link திறந்து menu > Add to Home screen / Install app தேர்வு செய்யவும்.
5. தரவு browser local storage-ல் சேமிக்கப்படும். browser data clear செய்வதற்கு முன் JSON Backup எடுக்கவும்.

குறிப்பு:
- PDF உருவாக்க Print dialog-ஐப் பயன்படுத்துகிறது; மொபைலில் Save as PDF தேர்வு செய்யவும்.
- Share Report, WhatsApp போன்ற app-களுக்கு report text பகிர்கிறது. PDF file share-ஐ app/browser ஆதரவு மற்றும் Print மூலம் சேமித்த file-ஐப் பொறுத்து செய்யலாம்.
- இந்த project web app/PWA source ZIP; Play Store APK அல்ல.

UI UPDATE: Premium green-and-white reference-inspired theme, illustrated milk sachet and curd cup product tiles, responsive mobile layout. Existing data entry, reports, shop ledger, rates, PDF print, share, JSON backup/restore and CSV export are retained.
