# Asset Audit — Pixel Survival

## Provided runtime assets

| Asset | Dimensions | Type | Observed contents | Integration plan |
|---|---:|---|---|---|
| `public/assets/Nature_TileMegaPack.png` | 512×512 | RGB PNG, no alpha | 16×16 grid of 32px pixel-art terrain, water, trees, rocks, plants, bridge, lantern, props | Load at runtime and crop real 32px tiles for grass, sand, water and environment resource variants |
| `public/assets/MediavelFree.png` | 512×512 | RGB PNG, no alpha | Medieval player sprite atlas with idle/walk/attack/hurt/death/swim rows and props | Load at runtime and crop player frames for visible gameplay rendering |
| `public/assets/rpg_icons_free/*.png` | 24×24 | RGBA PNG | Pixel-art tools, weapons, armor, materials, torch and containers | Load as runtime inventory/tool icons where matching IDs exist |
| `src/assets/images/*.jpg` | 1024/1376px | JPEG previews/reference sheets | Asset pipeline guide and previews of the provided packs | Documentation/reference only; not used as runtime sprites |

## Existing systems verified in source

The project already contains a working canvas loop, pixelated rendering, animated water, day/night lighting, weather, swimming, dodge/sprint, wildlife AI, inventory, crafting, building, skill tree, save/load, and mobile controls. Changes must extend these systems rather than replace them.

## Findings

1. `src/game/sprites.ts` generated all runtime art procedurally; the provided PNG packs were not loaded or rendered.
2. `GameCanvas.tsx` already uses cached sprite frames and nearest-neighbor rendering, so runtime atlas crops can be integrated without changing the game architecture.
3. `App.tsx` contains visible Emoji characters in the menu/help/save notification; these violate the supplied no-Emoji rule and will be replaced with existing icon components or text labels.
4. `MediavelFree.png` visibly contains the required player states, including swimming, while `Nature_TileMegaPack.png` contains terrain/water/environment tiles.

## Verification target

After changes, `pnpm build` must pass, the runtime must load the provided atlases, at least one real atlas tile and one real player frame must be rendered by the canvas, and no Emoji characters may remain in `src/`.
