# CGD V117 — SOCLE 5.0-F
## Intégration générale — journal de livraison

Cette version assemble les modules déjà présents dans le socle 5.0-E et organise la navigation selon les neuf rubriques officielles :
1. Accueil
2. Club
3. Compétitions
4. Mercato
5. Tactique
6. Calendrier & Matchs
7. Gestion
8. Médias
9. Plus / Paramètres

### Organisation des écrans
- Les écrans Damistes et Académie sont rattachés à Club.
- Le marché des transferts est accessible dans Mercato.
- Le bureau du club et les offres commerciales sont rattachés à Gestion.
- Le moteur de partie reste dans Tactique.
- Le calendrier central et l'administration des dates officielles sont rattachés à Calendrier & Matchs.
- L'éditeur d'identité visuelle et les sauvegardes sont accessibles dans Plus / Paramètres.
- Les écrans et données historiques ne sont pas supprimés.

### Compatibilité
Les anciennes valeurs de navigation mémorisées `damistes` et `recherche` sont converties vers `club` au chargement. Les identifiants des clubs, compétitions, joueurs et historiques ne sont pas volontairement modifiés par cette intégration.

### Validation
Les tests de la version 5.0-F doivent être exécutés sur l'archive livrée. Les anciens rapports de tests 5.0-E ne sont pas considérés comme une validation de 5.0-F.
