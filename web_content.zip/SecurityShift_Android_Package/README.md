# 🛡️ 보안근무 (One UI 9.0 안드로이드 앱 빌드 패키지)

이 프로젝트 패키지는 **잠금화면 알람** 및 **다른 앱 실행 중 알람(오버레이)** 권한이 완전 적용된 안드로이드 네이티브 앱 풀 소스코드입니다.

---

### 🔑 시스템 권한 적용 내역 (`AndroidManifest.xml` & `MainActivity.kt`)

1. **`SYSTEM_ALERT_WINDOW`** (다른 앱 위에 그리기)
   - 유튜브/카카오톡 등 다른 앱을 사용하는 동안에도 근무 알람 팝업 창이 화면 위에 즉시 노출됩니다.
2. **`SHOW_WHEN_LOCKED` / `TURN_SCREEN_ON`** (잠금화면 알람)
   - 스마트폰 화면이 켜지지 않은 잠금 상태에서도 화면을 자동으로 켜고 보안근무 알람 창을 띄웁니다.
3. **`USE_EXACT_ALARM` & `SCHEDULE_EXACT_ALARM`** (정확한 시각 알람)
   - 절전 모드나 백그라운드 제한 상황에서도 지정된 분 단위 시각에 오차 없이 알람이 동작합니다.
4. **`POST_NOTIFICATIONS` & `VIBRATE`**
   - 상단 알림 메시지 및 강력한 진동 알림을 제공합니다.

---

### 📦 APK 패키지 빌드 방법 (3가지 옵션)

#### 옵션 1. Android Studio 이용 (정석 빌드 방식)
1. 컴퓨터에 **Android Studio** 설치 및 실행.
2. `Open an Existing Project` 선택 후 본 압축을 해제한 폴더 지정.
3. 상단 메뉴 `Build` -> `Build Bundle(s) / APK(s)` -> `Build APK(s)` 클릭.
4. 완성된 `app-debug.apk` 또는 `app-release.apk`를 핸드폰에 전송하여 설치.

#### 옵션 2. Capacitor / Cordova CLI 이용
1. Node.js 터미널에서 아래 명령 실행:
   ```bash
   npm install -g @capacitor/cli
   npx cap init "보안근무" "com.security.shift.alarm"
   npx cap add android
   npx cap open android
   ```
2. 생성된 Android 프로젝트에 제공된 `AndroidManifest.xml`을 적용 후 APK 빌드.

#### 옵션 3. 온라인 웹-to-APK 빌더 활용
- Capacitor 프로젝트 패키지 폴더 전체를 ZIP으로 생성하여 온라인 빌드 사이트(예: Appilix, Web2App 등)에 업로드하면 바로 설치형 APK를 다운로드할 수 있습니다.
