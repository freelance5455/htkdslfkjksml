package com.soomrostudio.cosmicwars;

import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import java.net.InetSocketAddress;

public final class LanRoomServer extends WebSocketServer {
    public interface Listener {
        void onStatus(String status);
        void onGameMessage(String json);
    }
    private final Listener listener;

    public LanRoomServer(int port, Listener listener) {
        super(new InetSocketAddress("0.0.0.0", port));
        this.listener = listener;
    }
    @Override public void onOpen(WebSocket conn, ClientHandshake handshake) {
        if (getConnections().size() > 2) {
            conn.close(1008, "Room full");
            return;
        }
        if (listener != null) listener.onStatus("Player connected: " + conn.getRemoteSocketAddress());
        conn.send("{\"type\":\"welcome\",\"message\":\"Connected to COSMIC WARS room\"}");
    }
    @Override public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        if (listener != null) listener.onStatus("Player disconnected");
    }
    @Override public void onMessage(WebSocket conn, String message) {
        if (listener != null) listener.onGameMessage(message);
        for (WebSocket peer : getConnections()) {
            if (peer != conn && peer.isOpen()) peer.send(message);
        }
    }
    @Override public void onError(WebSocket conn, Exception ex) {
        if (listener != null) listener.onStatus("LAN error: " + ex.getMessage());
    }
    @Override public void onStart() {
        if (listener != null) listener.onStatus("Room listening on port 8787");
    }
}
