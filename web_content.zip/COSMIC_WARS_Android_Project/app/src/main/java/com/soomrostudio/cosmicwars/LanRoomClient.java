package com.soomrostudio.cosmicwars;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import java.net.URI;

public final class LanRoomClient extends WebSocketClient {
    public interface Listener {
        void onStatus(String status);
        void onGameMessage(String json);
    }
    private final Listener listener;

    public LanRoomClient(String hostIp, Listener listener) throws Exception {
        super(new URI("ws://" + hostIp + ":8787"));
        this.listener = listener;
        setConnectionLostTimeout(10);
    }
    @Override public void onOpen(ServerHandshake handshake) {
        if (listener != null) listener.onStatus("Connected to host room");
    }
    @Override public void onMessage(String message) {
        if (listener != null) listener.onGameMessage(message);
    }
    @Override public void onClose(int code, String reason, boolean remote) {
        if (listener != null) listener.onStatus("Disconnected: " + reason);
    }
    @Override public void onError(Exception ex) {
        if (listener != null) listener.onStatus("Connection error: " + ex.getMessage());
    }
}
