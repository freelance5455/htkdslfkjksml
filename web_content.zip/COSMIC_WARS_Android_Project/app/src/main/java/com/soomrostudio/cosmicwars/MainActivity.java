package com.soomrostudio.cosmicwars;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.view.View;
import android.view.Gravity;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.Collections;
import org.json.JSONObject;

public class MainActivity extends Activity implements LanRoomServer.Listener, LanRoomClient.Listener {
    private static final int PORT = 8787;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private TextView status;
    private TextView log;
    private EditText hostIp;
    private WebView webView;
    private LanRoomServer server;
    private LanRoomClient client;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(5, 14, 39));

        TextView title = new TextView(this);
        title.setText("COSMIC WARS  •  HOTSPOT LAN");
        title.setTextColor(Color.rgb(85, 232, 255));
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setPadding(8, 14, 8, 10);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("Step 1: Phone A hotspot ON kare. Phone B us se connect ho.");
        status.setTextColor(Color.WHITE);
        status.setPadding(12, 6, 12, 8);
        root.addView(status);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setPadding(8, 4, 8, 4);
        Button host = new Button(this);
        host.setText("HOST ROOM");
        host.setOnClickListener(v -> startHost());
        buttons.addView(host, new LinearLayout.LayoutParams(0, -2, 1));

        Button join = new Button(this);
        join.setText("JOIN ROOM");
        join.setOnClickListener(v -> joinRoom());
        buttons.addView(join, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(buttons);

        hostIp = new EditText(this);
        hostIp.setSingleLine(true);
        hostIp.setTextColor(Color.WHITE);
        hostIp.setHintTextColor(Color.LTGRAY);
        hostIp.setHint("Host phone IP, e.g. 192.168.43.1");
        hostIp.setInputType( android.text.InputType.TYPE_CLASS_TEXT );
        hostIp.setPadding(12, 4, 12, 4);
        root.addView(hostIp, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout sendRow = new LinearLayout(this);
        EditText message = new EditText(this);
        message.setSingleLine(true);
        message.setTextColor(Color.WHITE);
        message.setHintTextColor(Color.LTGRAY);
        message.setHint("Test message / game event");
        sendRow.addView(message, new LinearLayout.LayoutParams(0, -2, 1));
        Button send = new Button(this);
        send.setText("SEND");
        send.setOnClickListener(v -> {
            String text = message.getText().toString().trim();
            if (text.isEmpty()) return;
            sendGameMessage(text);
            message.setText("");
        });
        sendRow.addView(send);
        root.addView(sendRow);

        log = new TextView(this);
        log.setTextColor(Color.rgb(215, 232, 255));
        log.setText("LAN log ready. Host room on Phone A, then join from Phone B.\n");
        log.setPadding(12, 8, 12, 8);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(log);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView gameNote = new TextView(this);
        gameNote.setText("Ad-free starter • Room messaging test. Connect your puzzle/game state before release.");
        gameNote.setTextColor(Color.LTGRAY);
        gameNote.setPadding(12, 8, 12, 12);
        root.addView(gameNote);

        setContentView(root);
    }

    private void startHost() {
        if (server != null) {
            addLog("Host server already started.");
            return;
        }
        new Thread(() -> {
            try {
                server = new LanRoomServer(PORT, this);
                server.start();
                mainHandler.post(() -> {
                    status.setText("Hosting on port " + PORT + ". Phone B ko host IP se join karwao.");
                    addLog("Host started on port " + PORT + ". Host IP: " + getLocalIp());
                });
            } catch (Exception e) {
                mainHandler.post(() -> addLog("Host error: " + e.getMessage()));
            }
        }).start();
    }

    private void joinRoom() {
        String ip = hostIp.getText().toString().trim();
        if (ip.isEmpty()) {
            Toast.makeText(this, "Host phone ka IP address likho", Toast.LENGTH_SHORT).show();
            return;
        }
        new Thread(() -> {
            try {
                client = new LanRoomClient(ip, this);
                client.connect();
            } catch (Exception e) {
                mainHandler.post(() -> addLog("Join error: " + e.getMessage()));
            }
        }).start();
    }

    private void sendGameMessage(String text) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("type", "game_message");
            obj.put("text", text);
            String json = obj.toString();
            if (client != null && client.isOpen()) {
                client.send(json);
                addLog("You → host: " + text);
            } else if (server != null && server.getConnections().size() > 0) {
                server.broadcast(json);
                addLog("Host → players: " + text);
            } else {
                addLog("Not connected yet. Start host or join a room first.");
            }
        } catch (Exception e) {
            addLog("Send error: " + e.getMessage());
        }
    }

    private String getLocalIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (java.net.InetAddress addr : Collections.list(ni.getInetAddresses())) {
                    if (!addr.isLoopbackAddress() && addr instanceof Inet4Address) {
                        String ip = addr.getHostAddress();
                        if (ip.startsWith("192.168.") || ip.startsWith("10.")) return ip;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "Check Android Wi-Fi details for host IP";
    }

    @Override public void onStatus(String text) {
        mainHandler.post(() -> {
            status.setText(text);
            addLog(text);
        });
    }

    @Override public void onGameMessage(String json) {
        mainHandler.post(() -> addLog("Received: " + json));
    }

    private void addLog(String text) {
        if (log != null) log.append("\n" + text);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        new Thread(() -> {
            try { if (client != null) client.close(); } catch (Exception ignored) {}
            try { if (server != null) server.stop(); } catch (Exception ignored) {}
        }).start();
    }
}
