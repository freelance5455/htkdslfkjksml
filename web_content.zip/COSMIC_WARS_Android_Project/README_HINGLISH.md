# COSMIC WARS Android Project (Ad-free LAN starter)

## Is project mein kya hai?
- Android Studio Java project scaffold
- Ad-free: koi ad SDK ya ads integration nahi
- Phone A par WebSocket LAN room host karne ka button
- Phone B par host IP enter karke join karne ka button
- Dono phones ke beech test messages bhejne ka UI
- Existing COSMIC WARS HTML prototype assets folder mein included

## Build karne se pehle
1. Android Studio install karo: https://developer.android.com/studio
2. ZIP extract karo.
3. Android Studio > Open > extracted `COSMIC_WARS_Android_Project` folder.
4. Gradle sync complete hone do. First sync ke liye internet chahiye hoga, kyunki Android Gradle Plugin aur Java-WebSocket dependency download hogi.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK `app/build/outputs/apk/debug/app-debug.apk` mein hogi.

## Hotspot LAN test
1. Phone A par hotspot ON karo.
2. Phone B ko us hotspot se connect karo.
3. Phone A par app khol kar HOST ROOM dabao.
4. Host IP app log mein dikhane ki koshish karta hai. Agar IP na mile, phone ke hotspot/Wi-Fi details se gateway/local IP check karo (aksar 192.168.43.1, lekin har device par alag ho sakta hai).
5. Phone B par wahi IP daalo aur JOIN ROOM dabao.
6. SEND se message test karo.

## Honest limitations
- Ye Android Studio project source hai, prebuilt/tested APK nahi.
- Is environment mein Android SDK/Gradle build run nahi kiya, isliye tumhare PC par build test karna zaroori hai.
- Included HTML game abhi WebView mein automatically open nahi hoti; project pehle LAN room/message test UI deta hai. HTML file assets mein included hai for next integration.
- LAN messages are test messages; puzzle progress, turn rules, scores, and 102-level game state abhi game logic se connected nahi hain.
- Hotspot phone par client isolation/firewall kuch models mein local connections block kar sakte hain. Agar connect na ho, same Wi-Fi router par test karo.
- Release se pehle connection security, reconnect, and input validation add karo.
