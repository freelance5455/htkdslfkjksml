# Monorbit app

Digital committees in PKR, US dollars and digital gold: a mobile web app, its backend and a staff console in one project.
Start with **START-HERE.md**. The full list of what is finished, what needs outside accounts or approvals, and the business decisions
still open is in **docs/REQUIREMENTS_STATUS.md**. API notes are in docs/API.md.

    npm start        # app at http://localhost:3000, staff console at /admin-panel
    npm test         # backend tests

| Folder | What it does |
|---|---|
| `web/` | The mobile web app (installable PWA) |
| `admin/` | Staff console with role-based access |
| `src/` | Backend: accounts, setup, consent, fees, payments, recurring, reports |
| `src/providers/index.js` | **Where real verification, payment, SMS and gold-price services plug in** |
| `test/` | Automated tests |

Go-live checklist: see docs/REQUIREMENTS_STATUS.md sections 2 to 4 and `.env.example`.
