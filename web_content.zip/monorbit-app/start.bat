@echo off
cd /d "%~dp0"
node -v >nul 2>&1 || (echo Node.js is not installed. Get it from https://nodejs.org & pause & exit /b)
npm start
pause
