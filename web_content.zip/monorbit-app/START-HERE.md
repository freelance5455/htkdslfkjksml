# Monorbit app: start here

## Run it (3 steps)
1. Install Node.js **22.13 or newer** (LTS) from https://nodejs.org, then open a NEW terminal.
2. In VS Code: File > Open Folder > choose this **monorbit-app** folder.
3. Open the terminal (Ctrl + `) and run:

       npm start

The app opens in your browser at **http://localhost:3000**. There is nothing to install.
Other ways to start: press **F5** in VS Code, or double-click **start.bat** (Windows) / **start.sh** (Mac, Linux).

## What you will see
- **The app:** http://localhost:3000. In Chrome press F12, then Ctrl+Shift+M for phone view. Allow the camera when asked.
- **Staff console:** http://localhost:3000/admin-panel. A development login is printed in the terminal when the app starts
  (`admin@monorbit.local` / `DevAdmin12345`). It exists only in development.
- First visit shows the 5 intro slides. Then: create account > verify phone > bank details > ID photos and live selfie > consent.
- **Nothing is approved automatically.** Identity and bank checks wait in the staff console for a person. Open the staff console in a
  second tab, approve the identity check, then use "Mark verified" under Bank checks. Your account is then unlocked.
- Development helpers: the SMS code is filled in for you, and payments show a "Simulate approval" button because no real gateway is connected.

## Stop / reset
- Stop: click the terminal, press Ctrl+C.
- **Important:** this version changed the database structure. If you ran an earlier version, stop the app and delete the `data` folder first.
- Start fresh any time: stop the app, delete the `data` folder, start again.
- Different port: PowerShell `$env:PORT=3001; npm start` · cmd `set PORT=3001 && npm start`

## Check everything works
    npm test                      # 21 backend tests (about 20 seconds)

Read **docs/REQUIREMENTS_STATUS.md** for what is finished, what needs outside approvals or accounts, and the decisions only the business owner can make.
