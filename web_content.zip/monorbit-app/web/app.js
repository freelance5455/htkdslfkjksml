'use strict';
/* Monorbit mobile web app. Sections: core, onboarding and accounts, setup, dashboard, committees, payments, profile, events. */
const APP = 'Monorbit';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const dfmt = iso => { if (!iso) return ''; const d = new Date(iso.length <= 10 ? iso + 'T00:00:00' : iso.replace(' ', 'T') + 'Z'); return isNaN(d) ? '' : `${d.getDate()} ${MON[d.getMonth()]} ${d.getFullYear()}`; };
const rid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
// One formatter for every amount. Currency is always explicit: PKR = paisa, USD = cents, XAU (gold) = milligrams.
function money(a, c = 'PKR') {
  if (c === 'XAU') return (a / 1000).toLocaleString('en-PK', { maximumFractionDigits: 3 }) + ' g gold';
  if (c === 'USD') return (a < 0 ? '−' : '') + '$' + (Math.abs(a) / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return (a < 0 ? '−' : '') + 'Rs ' + (Math.abs(a) / 100).toLocaleString('en-PK', { maximumFractionDigits: 2 });
}
const CUR = { PKR: 'Pakistani rupee', USD: 'US dollar', XAU: 'Digital gold' };
const brandIcon = (s = 40) => `<img src="/brand-icon.svg" width="${s}" height="${s}" alt="${APP}" style="border-radius:${Math.round(s * .14)}px;flex:none">`;
const brandLogo = (h = 34) => `<picture><source srcset="/brand-logo-white.svg" media="(prefers-color-scheme: dark)"><img class="logo-wide" style="height:${h}px" src="/brand-logo.svg" alt="${APP}"></picture>`;
const ic = (p, w = 24) => `<svg width="${w}" height="${w}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
const ICO = {
  home: ic('<path d="M3 11l9-8 9 8M5 10v10h14V10"/>'), grp: ic('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-6 6.5-6s6.5 2.5 6.5 6M16 4.5a3.5 3.5 0 010 7M18 14c2.2.6 3.5 2.6 3.5 5"/>'),
  list: ic('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'), pay: ic('<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18M16 15h2"/>'),
  me: ic('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>'), bell: ic('<path d="M6 17V11a6 6 0 0112 0v6l2 2H4zM10 21h4"/>', 22),
  help: ic('<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 115 0c0 1.7-2.5 2-2.5 4M12 17h.01"/>'), coin: ic('<circle cx="12" cy="12" r="9"/><path d="M9 9h5a2 2 0 010 4h-4a2 2 0 000 4h5M12 7v2m0 8v2"/>'),
  gold: ic('<path d="M3 18l3-8h12l3 8zM9 10l1.5-5h3L15 10"/>'), check: ic('<path d="M5 12l5 5 9-10"/>', 44), x: ic('<path d="M6 6l12 12M18 6L6 18"/>', 44), doc: ic('<path d="M6 3h9l4 4v14H6zM14 3v5h5M9 13h6M9 17h6"/>'),
};

/* ================================= core ================================= */
const S = {
  token: localStorage.getItem('mo_token') || '', me: null, dev: false, recurring: false, screen: 'boot', params: {}, stack: [], data: null,
  f: {}, err: {}, busy: false, cam: 'front', preview: false, selfie: { stage: 'intro' }, challenge: null, liveDone: false, kycImg: {}, kyc: { name: '', cnic: '', dob: '' },
  cat: 'PKR', plan: null, slot: null, order: null, pm: 'debit', idem: '', pay: null, payNext: null, bank: null, consentOk: {}, payFilter: 'all', topCur: 'PKR', topAmt: '', replay: false,
};
let renderToken = 0, pollTimer = null;
const store = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch {} }, del: k => { try { localStorage.removeItem(k); } catch {} } };

async function api(path, { method = 'GET', body } = {}) {
  let r;
  try { r = await fetch(path, { method, headers: { 'content-type': 'application/json', ...(S.token ? { authorization: 'Bearer ' + S.token } : {}) }, body: body ? JSON.stringify(body) : undefined }); }
  catch { throw Object.assign(new Error('No connection. Check your internet and try again.'), { code: 'network' }); }
  let j = null; try { j = await r.json(); } catch {}
  if (!r.ok) {
    const code = j?.error?.code;
    if (r.status === 401 && S.token && ['session_ended', 'invalid_token', 'token_expired'].includes(code)) { endSession(); throw Object.assign(new Error('Your session ended. Please log in again.'), { code: 'auth' }); }
    throw Object.assign(new Error(j?.error?.message || 'Something went wrong. Please try again.'), { code, status: r.status, extra: j?.error });
  }
  return j;
}
function toast(t) { document.querySelectorAll('.toast').forEach(x => x.remove()); const d = document.createElement('div'); d.className = 'toast'; d.setAttribute('role', 'status'); d.textContent = t; document.body.appendChild(d); setTimeout(() => d.remove(), 3200); }
function endSession() { store.del('mo_token'); S.token = ''; S.me = null; S.stack = []; S.kycImg = {}; stopCam(); go('login', { reset: true }); }
async function logout() { try { await api('/auth/logout', { method: 'POST' }); } catch {} endSession(); }
function go(screen, o = {}) { if (o.reset) S.stack = []; else if (S.screen !== 'boot') S.stack.push({ screen: S.screen, params: S.params }); S.screen = screen; S.params = o.params || {}; S.data = null; S.err = {}; render(); window.scrollTo(0, 0); }
function back() { const p = S.stack.pop(); if (!p) return go(S.token ? 'home' : 'login', { reset: true }); S.screen = p.screen; S.params = p.params; S.data = null; S.err = {}; render(); window.scrollTo(0, 0); }
const BK = '<button class="back" data-act="back">‹ Back</button>';
const TABS = [['home', 'Home', ICO.home], ['committees', 'Committees', ICO.grp], ['mine', 'My committees', ICO.list], ['payments', 'Payments', ICO.pay], ['profile', 'Profile', ICO.me]];
const TABMAP = { home: 'home', setup: 'home', notifications: 'home', committees: 'committees', plan: 'committees', mine: 'mine', mineDetail: 'mine', autopay: 'mine', payments: 'payments', topup: 'payments', profile: 'profile', report: 'profile', help: 'profile', payoutacc: 'profile', verification: 'profile', bankview: 'profile' };
const loadingHtml = '<div class="spin" role="status" aria-label="Loading"></div>';
const errCard = (m, retry = true) => `${BK}<div class="card"><h3>Could not load</h3><p class="muted small">${esc(m)}</p>${retry ? '<button class="btn" data-act="reload">Try again</button>' : ''}</div>`;
const fe = k => S.err[k] ? `<div class="errtxt" role="alert">${esc(S.err[k])}</div>` : '';
const val = k => esc(S.f[k] ?? '');

async function render() {
  const sc = SCREENS[S.screen]; const tk = ++renderToken; clearInterval(pollTimer);
  if (!(S.screen === 'camera' || (S.screen === 'selfie' && S.selfie.stage === 'live')) || S.preview) stopCam();
  const needLoad = sc.load && S.data === null;
  $('#view').innerHTML = needLoad ? loadingHtml : sc.view(); drawNav();
  if (needLoad) {
    try { const d = await sc.load(); if (tk !== renderToken) return; S.data = d; $('#view').innerHTML = sc.view(); drawNav(); }
    catch (e) { if (tk !== renderToken || e.code === 'auth') return; $('#view').innerHTML = errCard(e.message); return; }
  }
  if (sc.after) sc.after();
}
function rerender() { const sc = SCREENS[S.screen]; $('#view').innerHTML = sc.view(); drawNav(); if (sc.after) sc.after(); }
function drawNav() {
  const n = $('#nav'), a = TABMAP[S.screen]; n.hidden = !a || !S.me;
  if (a && S.me) n.innerHTML = TABS.map(([k, l, i]) => `<button data-act="tab" data-to="${k}" class="${a === k ? 'on' : ''}" ${a === k ? 'aria-current="page"' : ''}>${i}<span>${l}</span></button>`).join('');
}
const refreshMe = async () => { S.me = await api('/me'); return S.me; };
const setupDone = () => !!(S.me && S.me.setup.complete);
const needSetup = () => { if (setupDone()) return false; toast('Finish your account setup first'); go('setup'); return true; };
const pillFor = st => ({ paid: 'ok', approved: 'ok', verified: 'ok', eligible: 'ok', active: 'ok', scheduled: 'warn', pending: 'warn', awaiting_transfer: 'warn', under_review: 'warn', verification_pending: 'warn', failed: 'bad', not_eligible: 'bad', verification_failed: 'bad', rejected: 'bad', cancelled: 'dim', reversed: 'dim', information_required: 'warn' }[st] || 'dim');
const STLAB = { paid: 'Paid', pending: 'Pending', awaiting_transfer: 'Awaiting transfer', under_review: 'Under review', scheduled: 'Scheduled', failed: 'Failed', cancelled: 'Cancelled', reversed: 'Reversed', created: 'Pending', information_required: 'Information required', verification_pending: 'Verification pending', verification_failed: 'Verification failed', eligible: 'Eligible', not_eligible: 'Not eligible', approved: 'Approved', verified: 'Verified', rejected: 'Not approved', none: 'Not started', pending_payment: 'Payment needed', active: 'Active', due: 'Due', overdue: 'Overdue' };
const pill = st => `<span class="pill ${pillFor(st) === 'ok' ? '' : pillFor(st)}">${STLAB[st] || esc(st)}</span>`;
const PURP = { join: 'Committee enrolment', instalment: 'Committee instalment', topup: 'Wallet top-up', gold: 'Gold plan', gold_instalment: 'Gold instalment' };
const METHOD = { card: 'Card', bank: 'Online bank transfer', wallet: 'Wallet', recurring: 'Automatic deduction', jazz: 'JazzCash', easy: 'Easypaisa' };

/* ============================ onboarding and accounts ============================ */
const SLIDES = [
  ['Welcome to Digital Committees', 'Manage your financial committee participation through one convenient application.', '<circle cx="60" cy="62" r="26" fill="#50C878"/><ellipse cx="60" cy="22" rx="24" ry="9" fill="#50C878"/><ellipse cx="22" cy="48" rx="9" ry="20" fill="#50C878" transform="rotate(-22 22 48)"/><ellipse cx="98" cy="48" rx="9" ry="20" fill="#50C878" transform="rotate(22 98 48)"/>'],
  ['Choose Your Committee', 'Explore available committees in PKR, US dollars, and digital gold.', '<circle cx="28" cy="62" r="24" fill="#50C878"/><text x="28" y="71" font-size="24" font-weight="700" text-anchor="middle" fill="#193232">Rs</text><circle cx="68" cy="40" r="24" fill="#fff"/><text x="68" y="50" font-size="26" font-weight="700" text-anchor="middle" fill="#193232">$</text><circle cx="98" cy="74" r="20" fill="#E6C25A"/><text x="98" y="82" font-size="18" font-weight="700" text-anchor="middle" fill="#193232">Au</text>'],
  ['Select Your Contribution and Payout Slot', 'Review available committee schedules, monthly contributions, and payout opportunities.', '<rect x="14" y="14" width="92" height="86" rx="12" fill="#fff"/><rect x="14" y="14" width="92" height="20" rx="10" fill="#50C878"/>' + [0, 1, 2, 3, 4, 5, 6, 7].map(i => `<rect x="${24 + (i % 4) * 20}" y="${44 + Math.floor(i / 4) * 24}" width="15" height="16" rx="4" fill="${i === 5 ? '#193232' : i < 2 ? '#C9D6CF' : '#50C878'}"/>`).join('')],
  ['Secure Account Verification', 'Complete identity verification and securely provide the required banking information.', '<path d="M60 10l42 16v28c0 28-18 46-42 56C36 100 18 82 18 54V26z" fill="#fff"/><path d="M42 58l13 13 25-28" stroke="#50C878" stroke-width="9" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'],
  ['Simple and Transparent Payments', 'Review payment methods, applicable fees, terms, and payment schedules.', '<rect x="12" y="26" width="96" height="62" rx="10" fill="#fff"/><rect x="12" y="40" width="96" height="14" fill="#193232"/><rect x="22" y="66" width="34" height="8" rx="4" fill="#50C878"/><rect x="22" y="78" width="22" height="6" rx="3" fill="#C9D6CF"/><circle cx="92" cy="74" r="9" fill="#50C878"/>'],
];
const vOnboarding = () => `<div class="onb"><div class="onb-top">${brandLogo(28)}<button class="link no-print" data-act="onb-skip">Skip</button></div>
 <div class="onb-track" id="onbTrack" role="region" aria-label="Introduction slides">${SLIDES.map((s, i) => `<section class="onb-slide" aria-label="Slide ${i + 1} of ${SLIDES.length}"><div class="onb-art"><svg viewBox="0 0 120 112" width="200" height="190" aria-hidden="true">${s[2]}</svg></div><h1>${s[0]}</h1><p class="muted">${s[1]}</p></section>`).join('')}</div>
 <div class="onb-bottom"><div class="dots" id="onbDots" aria-hidden="true">${SLIDES.map((_, i) => `<i class="${i === 0 ? 'on' : ''}"></i>`).join('')}</div><button class="btn" id="onbNext" data-act="onb-next">Next</button></div></div>`;
function onbAfter() {
  const t = $('#onbTrack'); if (!t) return;
  t.addEventListener('scroll', () => { const i = Math.round(t.scrollLeft / t.clientWidth); document.querySelectorAll('#onbDots i').forEach((d, k) => d.classList.toggle('on', k === i)); $('#onbNext').textContent = i === SLIDES.length - 1 ? 'Get Started' : 'Next'; }, { passive: true });
}
function finishOnboarding() { store.set('mo_onboarded', '1'); if (S.replay && S.me) { S.replay = false; return back(); } go(S.token ? 'home' : 'register', { reset: true }); }

const vLogin = () => `<div style="padding-top:20px">${brandLogo(40)}<h1 style="margin-top:26px">Welcome back</h1><p class="muted">Log in to manage your committees.</p>
 <label class="lbl" for="lphone">Mobile number</label><input class="field ${S.err.lphone ? 'bad' : ''}" id="lphone" inputmode="numeric" autocomplete="tel-national" placeholder="03XX XXXXXXX" value="${val('lphone')}">${fe('lphone')}
 <label class="lbl" for="lpw">Password</label><input class="field ${S.err.lpw ? 'bad' : ''}" id="lpw" type="password" autocomplete="current-password" value="${val('lpw')}">${fe('lpw')}
 ${S.err.form ? `<div class="note bad" role="alert">${esc(S.err.form)}</div>` : ''}
 <div style="height:14px"></div><button class="btn" data-act="login">Log in</button>
 <div class="row" style="margin-top:12px"><button class="link" data-act="go" data-to="forgot">Forgot password?</button><button class="link" data-act="go" data-to="register">Create account</button></div>
 <button class="link center" style="display:block;margin:18px auto 0" data-act="replay-onb">View the introduction again</button></div>`;
const vRegister = () => `${S.stack.length ? BK : ''}<div style="padding-top:8px">${brandLogo(36)}<h1 style="margin-top:22px">Create your account</h1><p class="muted">It takes a few minutes. You will verify your phone number next.</p>
 <label class="lbl" for="rname">Full name (as on your CNIC)</label><input class="field ${S.err.rname ? 'bad' : ''}" id="rname" autocomplete="name" value="${val('rname')}">${fe('rname')}
 <label class="lbl" for="rphone">Mobile number</label><input class="field ${S.err.rphone ? 'bad' : ''}" id="rphone" inputmode="numeric" autocomplete="tel-national" placeholder="03XX XXXXXXX" value="${val('rphone')}">${fe('rphone')}
 <label class="lbl" for="remail">Email (optional)</label><input class="field ${S.err.remail ? 'bad' : ''}" id="remail" type="email" autocomplete="email" value="${val('remail')}">${fe('remail')}
 <label class="lbl" for="rpw">Password</label><input class="field ${S.err.rpw ? 'bad' : ''}" id="rpw" type="password" autocomplete="new-password" value="${val('rpw')}"><div class="hint">At least 8 characters, with letters and a number.</div>${fe('rpw')}
 ${S.err.form ? `<div class="note bad" role="alert">${esc(S.err.form)}</div>` : ''}
 <div style="height:14px"></div><button class="btn" data-act="register">Create account</button><button class="link center" style="display:block;margin:14px auto 0" data-act="go" data-to="login">I already have an account</button></div>`;
const vVerifyPhone = () => `${BK}<h1>Verify your phone</h1><p class="muted">Enter the code we sent by SMS to +92 ${esc((S.f.vphone || '').replace(/^0/, ''))}.</p>
 ${S.f.devCode ? `<div class="devnote">Development mode: the code is <b>${esc(S.f.devCode)}</b> and is filled in for you. Real SMS is used in production.</div>` : ''}
 <input class="field mono center" id="vcode" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="••••" style="font-size:28px;margin:12px 0" value="${val('vcode')}">${fe('vcode')}
 <button class="btn" data-act="verify-phone">Verify</button><button class="link" style="margin-top:10px" data-act="resend">Send the code again</button>`;
const vForgot = () => `${BK}<h1>Reset your password</h1><p class="muted">Enter your mobile number. If an account exists we will send a code.</p>
 <label class="lbl" for="fphone">Mobile number</label><input class="field" id="fphone" inputmode="numeric" placeholder="03XX XXXXXXX" value="${val('fphone')}">${fe('fphone')}<div style="height:14px"></div><button class="btn" data-act="forgot">Send code</button>`;
const vReset = () => `${BK}<h1>Choose a new password</h1>${S.f.devCode ? `<div class="devnote">Development mode: the code is <b>${esc(S.f.devCode)}</b>.</div>` : ''}
 <label class="lbl" for="fcode">Code from SMS</label><input class="field mono" id="fcode" inputmode="numeric" maxlength="6" value="${val('fcode')}">${fe('fcode')}
 <label class="lbl" for="fnew">New password</label><input class="field" id="fnew" type="password" autocomplete="new-password" value="${val('fnew')}"><div class="hint">At least 8 characters, with letters and a number. You will be signed out on all devices.</div>${fe('fnew')}
 <div style="height:14px"></div><button class="btn" data-act="reset">Save new password</button>`;

/* ================================== account setup ================================== */
const STEP_GO = { bank: 'bankform', identity: 'idintro', consent: 'consent', verification: 'verification' };
const vSetup = () => { const d = S.data; const todo = d.steps.find(s => !s.done && s.key !== 'verification' && !(s.key === 'identity' && s.state === 'pending'));
  return `<div class="logo-row">${brandIcon(36)}<h1 style="margin:0">Set up your account</h1></div><p class="muted" style="margin-top:8px">Complete these steps to join committees and make payments.</p>
 <div class="bar" aria-hidden="true"><i style="width:${d.steps.filter(s => s.done).length / d.steps.length * 100}%"></i></div>
 <div class="card" style="margin-top:14px"><ol class="steps">${d.steps.map((s, i) => {
    const cur = todo && todo.key === s.key, st = s.state; let sub = '';
    if (s.key === 'identity' && st === 'pending') sub = 'Submitted. A team member is reviewing your documents.'; else if (s.key === 'identity' && st === 'rejected') sub = 'Not approved. You can try again.';
    if (s.key === 'verification') sub = d.verification.explanation;
    return `<li class="${s.done ? 'done' : cur ? 'cur' : ''}"><span class="n">${s.done ? '✓' : i + 1}</span><div style="flex:1"><b>${s.label}</b>${s.key === 'verification' ? ` ${pill(d.verification.status)}` : ''}${sub ? `<div class="muted small">${esc(sub)}</div>` : ''}</div></li>`; }).join('')}</ol></div>
 ${d.complete ? '<button class="btn" data-act="tab" data-to="home">Go to dashboard</button>' : todo ? `<button class="btn" data-act="go" data-to="${STEP_GO[todo.key]}">Continue</button>` : '<button class="btn" data-act="go" data-to="verification">View verification status</button><button class="btn ghost" style="margin-top:10px" data-act="reload">Check status</button>'}
 <p class="muted small center" style="margin-top:12px">We only collect what is needed to verify you and run your committees.</p>`; };
const vBankForm = () => { const d = S.data, b = d.bank; const f = k => S.f[k] ?? (b ? ({ bhold: b.holderName, bbank: b.bankName, btype: b.accountType }[k]) : ''); 
  return `${BK}<div class="stepper"><i class="on"></i><i></i><i></i></div><h1>Bank information</h1>
 <div class="note"><b>Why we ask:</b> to verify that the account belongs to you and to send your committee payout to it. We never ask for your online banking password, PIN or card details. Your account number is encrypted and shown only in masked form.</div>
 <label class="lbl" for="bhold">Account holder's full name</label><input class="field ${S.err.bhold ? 'bad' : ''}" id="bhold" autocomplete="name" value="${esc(f('bhold') || S.me.name || '')}">${fe('bhold')}<div class="hint">It must match the name on your identity card.</div>
 <label class="lbl" for="bbank">Bank</label><select class="field ${S.err.bbank ? 'bad' : ''}" id="bbank"><option value="">Choose your bank</option>${d.banks.map(x => `<option ${f('bbank') === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>${fe('bbank')}
 <label class="lbl" for="btype">Account type</label><select class="field" id="btype"><option value="savings" ${f('btype') !== 'current' ? 'selected' : ''}>Savings</option><option value="current" ${f('btype') === 'current' ? 'selected' : ''}>Current</option></select>
 <label class="lbl" for="biban">IBAN</label><input class="field mono ${S.err.biban ? 'bad' : ''}" id="biban" autocapitalize="characters" autocomplete="off" maxlength="29" placeholder="PK00 XXXX 0000 0000 0000 0000" value="${val('biban')}">${fe('biban')}<div class="hint">24 characters, starting with PK. Find it in your bank app.</div>
 ${S.err.form ? `<div class="note bad" role="alert">${esc(S.err.form)}</div>` : ''}<div style="height:14px"></div><button class="btn" data-act="bank-save">Review details</button>`; };
const vBankConfirm = () => { const b = S.data.bank; return `${BK}<div class="stepper"><i class="on"></i><i class="on"></i><i></i></div><h1>Confirm your bank details</h1><p class="muted">Please check these carefully before you submit.</p>
 <div class="card"><div class="kv"><span class="muted">Account holder</span><b>${esc(b.holderName)}</b></div><div class="kv"><span class="muted">Bank</span><b>${esc(b.bankName)}</b></div><div class="kv"><span class="muted">Account type</span><b>${esc(b.accountType)}</b></div><div class="kv"><span class="muted">IBAN</span><b class="mono">${esc(b.ibanMasked)}</b></div></div>
 <p class="muted small">We may verify this information with authorised financial institutions or approved verification providers. You will be asked to give your consent for this in a later step.</p>
 <div class="cbrow"><input type="checkbox" id="bconfirm"><label for="bconfirm">I confirm that these details are correct and belong to me.</label></div>
 <button class="btn" id="bsubmit" data-act="bank-confirm" disabled>Submit bank details</button><button class="btn ghost" style="margin-top:10px" data-act="go" data-to="bankform">Edit details</button>`; };
const vBankView = () => { const b = S.data.bank; return `${BK}<h1>Bank account</h1>${b ? `<div class="card"><div class="kv"><span class="muted">Account holder</span><b>${esc(b.holderName)}</b></div><div class="kv"><span class="muted">Bank</span><b>${esc(b.bankName)}</b></div><div class="kv"><span class="muted">IBAN</span><b class="mono">${esc(b.ibanMasked)}</b></div></div><p class="muted small">Your full account number is encrypted and never shown in the app. To change it, contact support.</p>` : '<p class="muted">No bank account added yet.</p>'}`; };

/* ---- identity: ID photos, details, live selfie ---- */
const vIdIntro = () => `${BK}<div class="stepper"><i class="on"></i><i class="on"></i><i class="on"></i></div><h1>Verify your identity</h1><p class="muted">You will photograph your CNIC, confirm your details, then take a live selfie. It takes about two minutes.</p>
 <div class="card"><div class="lv"><i>✓</i><span><b>1. Photo of CNIC front</b></span></div><div class="lv"><i>✓</i><span><b>2. Photo of CNIC back</b></span></div><div class="lv"><i>✓</i><span><b>3. Confirm your details</b></span></div><div class="lv"><i>✓</i><span><b>4. Live selfie check</b><br><span class="muted small">Taken with your camera. Gallery uploads are not accepted.</span></span></div></div>
 <p class="muted small">Your photos are encrypted, used only to verify you, and deleted after the retention period in our privacy policy. The camera is only switched on while you are taking a photo.</p>
 <button class="btn" data-act="id-start">Start</button>`;
const CAMTXT = { front: ['Front of your CNIC', 'Place the front of your card inside the frame. Make sure all text is readable.'], back: ['Back of your CNIC', 'Now flip your card and place the back inside the frame.'] };
const ACTION_TEXT = { blink: 'Blink slowly', turn_left: 'Turn your head to the left', turn_right: 'Turn your head to the right', smile: 'Smile', look_up: 'Look up slightly' };
function vCamera() {
  const m = S.cam;
  if (S.preview) return `<h1>Check your photo</h1><img class="shot" src="${S.kycImg[m]}" alt="Captured CNIC ${m}"><p class="muted small">Make sure the card is not cut off and all text is sharp.</p><button class="btn" data-act="usephoto">Use this photo</button><button class="btn ghost" style="margin-top:10px" data-act="retake">Retake</button>`;
  return `${BK}<div class="stepper"><i class="on"></i><i class="on"></i><i class="on"></i></div><h1>${CAMTXT[m][0]}</h1><p class="muted">${CAMTXT[m][1]}</p>
 <div class="cam"><video id="vid" playsinline muted autoplay></video><div class="idf"></div><div class="camMsg" id="camMsg" role="status">Starting camera…</div></div>
 <button class="btn" id="capBtn" data-act="cap" disabled style="margin-top:14px">Capture photo</button>
 <div class="card" id="camErr" hidden style="margin-top:12px"><b>We could not open the camera</b><p class="muted small" style="margin:4px 0 8px">Allow camera access in your browser settings and try again. You can also use your phone camera with the button below.</p><button class="btn sm" data-act="cam-retry">Try again</button></div>
 <label class="btn ghost" style="margin-top:10px;cursor:pointer">Take or choose a photo of the card<input type="file" id="camfile" accept="image/*" capture="environment" hidden></label>`;
}
const vKycDetails = () => `${BK}<div class="stepper"><i class="on"></i><i class="on"></i><i class="on"></i></div><h1>Confirm your details</h1><p class="muted">Type your details exactly as printed on your CNIC.</p>
 <div class="thumbs" style="grid-template-columns:repeat(2,1fr)"><img src="${S.kycImg.front || ''}" alt="CNIC front" style="aspect-ratio:1.58"><img src="${S.kycImg.back || ''}" alt="CNIC back" style="aspect-ratio:1.58"></div>
 <label class="lbl" for="kname">Full name</label><input class="field ${S.err.kname ? 'bad' : ''}" id="kname" value="${esc(S.kyc.name || S.me.name || '')}">${fe('kname')}
 <label class="lbl" for="kcnic">CNIC number</label><input class="field mono ${S.err.kcnic ? 'bad' : ''}" id="kcnic" inputmode="numeric" maxlength="15" placeholder="35202-1234567-8" value="${esc(S.kyc.cnic)}">${fe('kcnic')}
 <label class="lbl" for="kdob">Date of birth</label><input class="field ${S.err.kdob ? 'bad' : ''}" id="kdob" type="date" value="${esc(S.kyc.dob)}">${fe('kdob')}
 <div style="height:16px"></div><button class="btn" data-act="kyc-next">Continue to selfie</button>`;
function vSelfie() {
  const st = S.selfie.stage;
  if (st === 'intro') return `${BK}<div class="stepper"><i class="on"></i><i class="on"></i><i class="on"></i></div><h1>Live selfie</h1><p class="muted">Take a selfie now with your camera. You cannot upload a photo from your gallery.</p>
   <div class="card"><ul class="checks"><li>Stand in a well-lit area.</li><li>Look directly at the camera.</li><li>Keep your face clearly visible.</li><li>Do not wear a cap or hat.</li><li>Remove glasses if the verification asks for it.</li><li>Keep the camera steady and follow the on-screen instructions.</li></ul></div>
   <p class="muted small">Your browser will ask for camera permission only when you press the button below.</p><button class="btn" data-act="selfie-open">Open camera</button>`;
  if (st === 'review') return `<h1>Check your selfie</h1><img class="shot mirror" src="${S.kycImg.selfie}" alt="Your selfie"><p class="muted small">Your whole face should be clear and well lit.</p>${S.err.form ? `<div class="note bad" role="alert">${esc(S.err.form)}</div>` : ''}<button class="btn" data-act="selfie-submit">Continue and submit</button><button class="btn ghost" style="margin-top:10px" data-act="selfie-open">Retake</button>`;
  const acts = (S.challenge?.actions || []).map(a => ACTION_TEXT[a] || a);
  return `${BK}<h1>Live selfie</h1><p class="muted">Keep your face inside the oval and follow the prompts.</p>
 <div class="cam"><video id="vid" playsinline muted autoplay class="mir"></video><div class="oval"></div><div class="camMsg" id="camMsg" role="status">Starting camera…</div></div>
 <div class="card" style="margin-top:12px"><div class="row"><b id="livePrompt">Getting ready…</b></div><div class="bar"><i id="liveBar" style="width:0"></i></div>${acts.map((l, i) => `<div class="lv" id="l${i}"><i>✓</i><span class="small">${esc(l)}</span></div>`).join('')}</div>
 <button class="btn" id="capBtn" data-act="cap" disabled style="margin-top:12px">Capture</button>
 <div class="card" id="camErr" hidden style="margin-top:12px"><b>We could not open the camera</b><p class="muted small" style="margin:4px 0 8px">Allow camera access in your browser settings, then try again. A live camera is required: photos from your gallery cannot be used.</p><button class="btn sm" data-act="cam-retry">Try again</button></div>`;
}
/* live camera */
let stream = null, anaTimer = null, liveTimer = null, camStarting = false, light = { ok: false, msg: '' }, lv = { i: 0, hold: 0 };
function stopCam() { clearInterval(anaTimer); clearInterval(liveTimer); if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; } camStarting = false; }
const isSelfieLive = () => S.screen === 'selfie' && S.selfie.stage === 'live';
async function startCam() {
  const v = $('#vid'); if (!v || camStarting) return; camStarting = true;
  try {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error('nocam');
    const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: isSelfieLive() ? 'user' : 'environment', width: { ideal: 1280 }, height: { ideal: 960 } }, audio: false });
    if (!(S.screen === 'camera' || isSelfieLive()) || S.preview) { s.getTracks().forEach(t => t.stop()); camStarting = false; return; }
    stream = s; v.srcObject = s; await v.play(); analyze.p = null; anaTimer = setInterval(analyze, 400); if (isSelfieLive()) startLive();
  } catch { camStarting = false; const m = $('#camMsg'); if (m) { m.textContent = 'Camera unavailable'; m.className = 'camMsg bad'; } const er = $('#camErr'); if (er) er.hidden = false; }
}
function analyze() {
  const v = $('#vid'); if (!v || !v.videoWidth) return;
  const c = analyze.c || (analyze.c = document.createElement('canvas')); c.width = 64; c.height = 48;
  const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(v, 0, 0, 64, 48); const d = x.getImageData(0, 0, 64, 48).data; const L = []; let sum = 0;
  for (let i = 0; i < d.length; i += 4) { const l = .299 * d[i] + .587 * d[i + 1] + .114 * d[i + 2]; L.push(l); sum += l; }
  const avg = sum / L.length; let mv = 0; if (analyze.p) { for (let i = 0; i < L.length; i++) mv += Math.abs(L[i] - analyze.p[i]); mv /= L.length; } analyze.p = L;
  let msg = 'Looks good. Hold steady', ok = true;
  if (avg < 55) { msg = 'Too dark. Move to a brighter place'; ok = false; } else if (avg > 215) { msg = 'Too bright. Avoid glare'; ok = false; } else if (!isSelfieLive() && mv > 10) { msg = 'Hold your phone steady'; ok = false; }
  light = { ok, msg }; const m = $('#camMsg'); if (m) { m.textContent = msg; m.className = 'camMsg ' + (ok ? 'good' : 'bad'); }
  const b = $('#capBtn'); if (b) b.disabled = isSelfieLive() ? !(ok && S.liveDone) : !ok;
}
function startLive() {   // guidance only: real liveness is decided by the verification provider or a reviewer
  const n = (S.challenge?.actions || []).length; lv = { i: 0, hold: 0 }; S.liveDone = false; clearInterval(liveTimer);
  liveTimer = setInterval(() => {
    if (!isSelfieLive()) { clearInterval(liveTimer); return; }
    if (S.liveDone) { const p = $('#livePrompt'); if (p) p.textContent = light.ok ? 'Great. Now press Capture.' : light.msg; return; }
    if (light.ok) lv.hold++; else lv.hold = 0;
    const p = $('#livePrompt'), bar = $('#liveBar'); if (p) p.textContent = light.ok ? (ACTION_TEXT[S.challenge.actions[lv.i]] || '') : light.msg;
    for (let k = 0; k < n; k++) { const r = $('#l' + k); if (r) r.className = 'lv ' + (k < lv.i ? 'done' : k === lv.i ? 'active' : ''); }
    if (bar) bar.style.width = Math.min(100, (lv.i * 4 + lv.hold) / (n * 4) * 100) + '%';
    if (lv.hold >= 4) { lv.i++; lv.hold = 0; if (lv.i >= n) { S.liveDone = true; for (let k = 0; k < n; k++) { const r = $('#l' + k); if (r) r.className = 'lv done'; } if (bar) bar.style.width = '100%'; } }
  }, 500);
}
function grab() { const v = $('#vid'); const c = document.createElement('canvas'); const sc = Math.min(1, 900 / v.videoWidth); c.width = v.videoWidth * sc; c.height = v.videoHeight * sc; c.getContext('2d').drawImage(v, 0, 0, c.width, c.height); return c.toDataURL('image/jpeg', .82); }
function downscale(dataUrl, max = 1200) { return new Promise(res => { const im = new Image(); im.onload = () => { const s = Math.min(1, max / Math.max(im.width, im.height)); const c = document.createElement('canvas'); c.width = im.width * s; c.height = im.height * s; c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', .85)); }; im.onerror = () => res(dataUrl); im.src = dataUrl; }); }
async function submitIdentity() {
  if (S.busy) return; S.busy = true; $('#view').classList.add('busy'); const k = S.kyc; S.err = {};
  try {
    const up = async (kind, extra = {}) => (await api('/uploads', { method: 'POST', body: { kind, image: S.kycImg[kind], ...extra } })).uploadId;
    const ids = { front: await up('front'), back: await up('back'), selfie: await up('selfie', { source: 'camera', challengeId: S.challenge.challengeId }) };
    await api('/kyc/submit', { method: 'POST', body: { name: k.name.trim(), cnic: k.cnic.replace(/\D/g, ''), dob: k.dob, ...ids } });
    S.kycImg = {}; S.challenge = null; await refreshMe(); toast('Submitted. We will review your documents.'); go('setup', { reset: true });
  } catch (e) {
    if (e.code === 'challenge_invalid') { S.selfie = { stage: 'intro' }; toast('The selfie check timed out. Please take the selfie again.'); go('selfie', { reset: false }); }
    else if (['cnic_in_use', 'invalid_cnic', 'invalid_name', 'invalid_dob', 'underage'].includes(e.code)) { toast(e.message); S.stack.pop(); go('kycdetails'); }
    else { S.err.form = e.message; rerender(); }
  } finally { S.busy = false; $('#view')?.classList.remove('busy'); }
}

/* ---- consent and verification ---- */
const vConsent = () => { const docs = S.data.documents.filter(d => d.required), done = docs.every(d => d.accepted);
  return `${BK}<div class="stepper"><i class="on"></i><i class="on"></i><i class="on"></i></div><h1>Terms and consent</h1><p class="muted">Read each document and accept each one separately. Only the consents needed for committee payments are required.</p>
 ${docs.map(d => `<details class="card"><summary>${esc(d.title)} ${d.accepted ? '<span class="pill">Accepted</span>' : ''}</summary><p class="small" style="white-space:pre-line">${esc(d.body)}</p></details>
 ${d.accepted ? '' : `<div class="cbrow"><input type="checkbox" class="cons" id="cons-${d.type}" data-type="${d.type}" data-version="${d.version}"><label for="cons-${d.type}">I have read and accept: <b>${esc(d.title)}</b></label></div>`}`).join('')}
 <p class="muted small">Automatic deductions use a separate authorization that you only see if you choose to turn them on. Accepted versions and the time of acceptance are recorded.</p>
 ${done ? '<button class="btn" data-act="tab" data-to="home">Continue</button>' : '<button class="btn" id="consBtn" data-act="consent-accept" disabled>Accept and continue</button>'}`; };
const vVerification = () => { const v = S.data; return `${BK}<h1>Verification status</h1><div class="card"><div class="row"><b>Application</b>${pill(v.status)}</div><p class="muted small" style="margin:8px 0 0">${esc(v.explanation)}</p>${v.missingSteps.length ? `<p class="small" style="margin:8px 0 0">Still needed: ${v.missingSteps.map(s => ({ bank: 'bank details', identity: 'identity check', consent: 'consent' }[s])).join(', ')}.</p>` : ''}</div>
 <p class="muted small">We may verify your information with authorised financial institutions or approved verification providers. Decisions use only the criteria disclosed in our terms, and every case can be reviewed.</p>
 ${v.canDispute ? `<h2>Ask for a review</h2><textarea class="field" id="dmsg" rows="3" placeholder="Tell us what you think is wrong" style="font-size:15px">${val('dmsg')}</textarea>${fe('dmsg')}<div style="height:10px"></div><button class="btn" data-act="dispute-eligibility">Request a review</button>` : ''}
 <button class="btn ghost" style="margin-top:12px" data-act="reload">Refresh status</button>`; };

/* ================================== dashboard ================================== */
const feeLine = p => p.fees ? esc(p.fees.text) : '';
function vHome() {
  const d = S.data, me = S.me, v = me.verification;
  const ms = d.mine.memberships.filter(m => m.status === 'active'); const up = d.report.byCurrency.flatMap(c => c.upcoming).slice(0, 4);
  const payouts = ms.map(m => ({ m, date: m.payoutDate })).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 3);
  const fees = ['PKR', 'USD', 'XAU'].map(c => d.plans.plans.find(p => p.currency === c)).filter(Boolean);
  return `<div class="row"><div class="logo-row">${brandIcon(42)}<div><div class="muted small">Welcome back</div><h1 style="margin:0;font-size:22px">${esc((me.name || '').split(' ')[0] || 'there')}</h1></div></div>
 <button class="bell" data-act="go" data-to="notifications" aria-label="Notifications${me.unreadNotifications ? ', ' + me.unreadNotifications + ' unread' : ''}">${ICO.bell}${me.unreadNotifications ? `<i>${me.unreadNotifications}</i>` : ''}</button></div><div style="height:12px"></div>
 <div class="card"><div class="row"><div><div class="small muted">Profile</div><b>${esc(me.name || '')}</b><div class="small muted">${esc(me.phone)}</div></div><div style="text-align:right"><div class="small muted">Identity</div>${pill(me.kycStatus === 'pending' ? 'under_review' : me.kycStatus)}<div class="small muted" style="margin-top:6px">Bank</div>${pill(v.status)}</div></div></div>
 ${!me.setup.complete ? `<button class="card" data-act="go" data-to="setup"><div class="row"><div><b>Finish setting up your account</b><div class="small muted">${me.setup.steps.filter(s => s.done).length} of ${me.setup.steps.length} steps done</div></div><span class="pill warn">Continue</span></div></button>` : ''}
 <div class="hero"><div class="sub">Wallet balances (kept separate)</div><div class="bals"><div><div class="sub">PKR</div><div class="amt">${money(me.balances.PKR, 'PKR')}</div></div><div><div class="sub">USD</div><div class="amt">${money(me.balances.USD, 'USD')}</div></div></div><div class="chips"><button class="chip" data-act="go" data-to="topup">Add money</button><button class="chip" data-act="tab" data-to="payments">Payments</button></div></div>
 <h2 style="margin-top:6px">Committee categories</h2><div class="grid3">${[['PKR', 'PKR', ICO.coin], ['USD', 'USD', ICO.coin], ['XAU', 'Digital gold', ICO.gold]].map(([c, l, i]) => `<button class="tile" data-act="cat" data-c="${c}">${i}${l}<div class="small muted">${d.plans.plans.filter(p => p.currency === c).length} committees</div></button>`).join('')}</div>
 ${d.report.byCurrency.some(c => c.outstanding) ? `<h2>Outstanding contributions</h2><div class="card">${d.report.byCurrency.filter(c => c.outstanding).map(c => `<div class="kv"><span class="muted">${CUR[c.currency]}</span><b>${money(c.outstanding, c.currency)}</b></div>`).join('')}</div>` : ''}
 <h2>Upcoming contributions</h2>${up.length ? up.map(i => `<div class="card row" style="padding:12px 16px;margin-bottom:8px"><div><b>${esc(i.name)}</b><div class="small muted">Instalment ${i.seq} · due ${dfmt(i.dueDate)}</div></div><div style="text-align:right"><b>${money(i.amount, i.currency)}</b><div>${pill(i.status)}</div></div></div>`).join('') : '<p class="muted small">Nothing due right now.</p>'}
 <h2>Upcoming payout dates</h2>${payouts.length ? payouts.map(p => `<div class="card row" style="padding:12px 16px;margin-bottom:8px"><div><b>${esc(p.m.name)}</b><div class="small muted">Payout month ${p.m.slot}</div></div><b>${dfmt(p.date)}</b></div>`).join('') : '<p class="muted small">Join a committee to see your payout date.</p>'}
 <h2>Active committees</h2>${ms.length ? ms.map(mCard).join('') : `<div class="card"><b>No committees yet</b><p class="muted small" style="margin:4px 0 12px">Pick a category above to see what is available.</p></div>`}
 <h2>Payment history</h2>${d.payments.payments.slice(0, 4).map(pRow).join('') || '<p class="muted small">No payments yet.</p>'}${d.payments.payments.length ? '<button class="link" data-act="tab" data-to="payments">See all payments ›</button>' : ''}
 <h2>Service fees</h2><div class="card">${fees.map(p => `<div class="kv"><span class="muted">${CUR[p.currency]}</span><span class="small" style="text-align:right;max-width:65%">${feeLine(p)}</span></div>`).join('')}<p class="muted small" style="margin:8px 0 0">The exact fee is always shown before you pay, and stays fixed for your committee once you enrol.</p></div>
 <h2>Quick links</h2><div class="grid2">${[['PKR committees', 'cat', 'PKR', ICO.coin], ['USD committees', 'cat', 'USD', ICO.coin], ['Digital gold', 'cat', 'XAU', ICO.gold], ['My committees', 'tab', 'mine', ICO.list], ['Payments', 'tab', 'payments', ICO.pay], ['Profile', 'tab', 'profile', ICO.me], ['Notifications', 'go', 'notifications', ICO.bell], ['Help and support', 'go', 'help', ICO.help]].map(([l, a, t, i]) => `<button class="tile" data-act="${a}" data-to="${t}" data-c="${t}">${i}${l}</button>`).join('')}</div>`;
}
const mCard = m => `<button class="card" data-act="open-mine" data-id="${m.id}"><div class="row"><b>${esc(m.name)}</b><span class="pill">Slot ${m.slot}</span></div><div class="muted small">Payout ${money(m.totalAmount, m.currency)} on ${dfmt(m.payoutDate)}</div><div class="bar"><i style="width:${m.paid / m.months * 100}%"></i></div><div class="row small muted" style="margin-top:6px"><span>${m.paid} of ${m.months} paid</span><span>${m.next ? 'Next due ' + dfmt(m.next.dueDate) : 'Complete'}</span></div></button>`;
const pRow = p => `<button class="card row" style="padding:12px 16px;margin-bottom:8px" data-act="open-pay" data-ref="${esc(p.ref)}"><div><b>${PURP[p.purpose] || p.purpose}</b><div class="small muted">${dfmt(p.scheduledFor || p.createdAt)} · ${METHOD[p.method] || p.method}</div></div><div style="text-align:right"><b>${p.purpose === 'topup' ? '+' : ''}${money(p.total, p.currency)}</b><div>${pill(p.status)}</div></div></button>`;

/* ============================= committees and enrolment ============================= */
const CATS = [['PKR', 'PKR'], ['USD', 'US dollar'], ['XAU', 'Digital gold']];
function planCard(p) { const s = p.slots;
  return `<button class="card" data-act="open-plan" data-id="${p.id}"><div class="row"><b>${esc(p.name)}</b><span class="pill ${p.enrolment === 'open' ? '' : 'dim'}">${p.enrolment === 'open' ? 'Open' : 'Full'}</span></div>
  <div class="row" style="margin-top:8px"><div><div class="small muted">Contribution (${p.frequency})</div><div style="font-size:20px;font-weight:700">${money(p.contribution, p.currency)}</div></div><div style="text-align:right"><div class="small muted">You receive</div><b>${money(p.totalAmount, p.currency)}</b></div></div>
  <div class="grid2 small" style="margin-top:10px"><div><span class="muted">Duration</span> <b>${p.months} months</b></div><div><span class="muted">Participants</span> <b>${p.participants}</b></div><div><span class="muted">Available</span> <b>${s.available}</b></div><div><span class="muted">Occupied</span> <b>${s.occupied}</b>${s.held ? ` · held ${s.held}` : ''}</div></div>
  <div class="small" style="margin-top:8px"><span class="muted">Payouts from month</span> <b>${p.firstPayoutMonth}</b></div><div class="small muted" style="margin-top:4px">${esc(feeLine(p))}</div></button>`; }
const vCommittees = () => `<h1>Committees</h1><p class="muted">Each category is kept separate. Amounts are never mixed between currencies.</p>
 <div class="tabs" role="tablist">${CATS.map(([c, l]) => `<button role="tab" aria-selected="${S.cat === c}" class="${S.cat === c ? 'on' : ''}" data-act="cat-tab" data-c="${c}">${l}</button>`).join('')}</div>
 ${S.cat === 'XAU' ? '<div class="note">Digital gold committees are valued in PKR at the gold price shown at the time of each payment. Gold is not physically owned or allocated to you unless the provider terms say so.</div>' : ''}
 ${S.data.plans.length ? S.data.plans.map(planCard).join('') : '<div class="card"><b>No committees in this category</b><p class="muted small" style="margin:4px 0 0">New committees appear here when they open.</p></div>'}`;
const SLOT_LABEL = { available: 'Available', reserved: 'Reserved', occupied: 'Occupied', held: 'Held', unavailable: 'Unavailable' };
function vPlan() {
  const d = S.data, g = d.gold;
  return `${BK}<h1>${esc(d.name)}</h1><p class="muted">${d.participants} members each contribute ${money(d.contribution, d.currency)} every month. Each month one member receives the full pot of ${money(d.totalAmount, d.currency)}.</p>
 ${g ? `<div class="card"><b>Digital gold valuation</b><div class="kv"><span class="muted">Contribution</span><b>${money(d.contribution, 'XAU')}</b></div><div class="kv"><span class="muted">Price per gram</span><b>${money(g.ratePerGram, 'PKR')}</b></div><div class="kv"><span class="muted">Price time</span><b>${dfmt(g.priceAt)}</b></div><div class="kv"><span class="muted">Price source</span><b>${esc(g.source)}</b></div><p class="small muted" style="margin:8px 0 0">${esc(g.method)}. ${esc(g.custody)}</p></div>` : ''}
 <div class="card"><div class="kv"><span class="muted">Currency</span><b>${CUR[d.currency]}</b></div><div class="kv"><span class="muted">Duration</span><b>${d.months} months</b></div><div class="kv"><span class="muted">First payout month</span><b>${d.rules.earliestSlot}</b></div><div class="kv"><span class="muted">Fees</span><span class="small" style="text-align:right;max-width:65%">${feeLine(d)}</span></div></div>
 <details class="card"><summary>Rules and terms</summary><p class="small">Waiting period: ${d.rules.minWaitMonths} months. First payout: month ${d.rules.firstPayoutMonth}. Earlier payout months cannot be chosen.</p>${d.terms.map(t => `<div class="small">• ${esc(t.title)}</div>`).join('')}</details>
 <h2>Contribution schedule</h2><div class="card">${d.schedule.map(s => `<div class="kv"><span>Month ${s.seq} · ${dfmt(s.dueDate)}</span><b>${money(s.amount, d.currency)}</b></div>`).join('')}</div>
 <h2>Choose your payout month</h2><div class="slots" role="group" aria-label="Payout slots">${d.slots.map(s => `<button class="slot ${s.state} ${S.slot === s.slot ? 'sel' : ''} ${s.mine ? 'mine' : ''}" data-act="slot" data-n="${s.slot}" data-state="${s.state}" data-reason="${esc(s.reason || '')}" aria-label="Month ${s.slot}, ${SLOT_LABEL[s.state]}${S.slot === s.slot ? ', selected' : ''}" ${s.state === 'available' ? '' : 'aria-disabled="true"'}>${s.slot}<small>${s.state === 'available' ? dfmt(d.schedule[s.slot - 1].dueDate).slice(0, -5) : SLOT_LABEL[s.state]}</small></button>`).join('')}</div>
 <div class="legend"><span><i></i>Available</span><span><i style="border-style:dashed;border-color:var(--accent-ink)"></i>Reserved</span><span><i style="background:var(--line)"></i>Occupied</span><span><i style="background:var(--amber-tint);border-color:var(--amber)"></i>Held</span><span><i style="opacity:.45"></i>Unavailable</span></div>
 ${S.slot ? `<div class="card"><div class="kv"><span class="muted">Your payout month</span><b>Month ${S.slot} · ${dfmt(d.schedule[S.slot - 1].dueDate)}</b></div><div class="kv"><span class="muted">You receive</span><b>${money(d.totalAmount, d.currency)}</b></div></div>` : ''}
 <button class="btn" data-act="hold-slot" ${S.slot ? '' : 'disabled'}>Review and hold this slot</button><p class="muted small center" style="margin-top:8px">Holding a slot reserves it for 20 minutes while you review and pay.</p>`;
}
function vSummary() {
  const q = S.data.quote, p = S.data.plan, o = S.order;
  return `${BK}<div class="stepper"><i class="on"></i><i></i><i></i></div><h1>Enrolment summary</h1><div class="note warn">Slot held for 20 minutes. Complete payment to confirm it.</div>
 <div class="card"><b>${esc(p.name)}</b><div class="kv"><span class="muted">Currency</span><b>${CUR[p.currency]}</b></div><div class="kv"><span class="muted">Contribution</span><b>${money(p.contribution, p.currency)} monthly</b></div><div class="kv"><span class="muted">Duration</span><b>${p.months} months</b></div><div class="kv"><span class="muted">Payout position</span><b>Month ${o.slot} · ${dfmt(p.schedule[o.slot - 1].dueDate)}</b></div><div class="kv"><span class="muted">Total payout</span><b>${money(p.totalAmount, p.currency)}</b></div></div>
 ${quoteHtml(q, 'Today you pay')}
 <h2>Contribution schedule</h2><div class="card">${p.schedule.map(s => `<div class="kv"><span>Month ${s.seq} · ${dfmt(s.dueDate)}</span><b>${money(s.amount, p.currency)}</b></div>`).join('')}<p class="muted small" style="margin:8px 0 0">Later instalments carry the fee shown above, fixed for your committee.</p></div>
 <details class="card"><summary>Terms that apply</summary>${p.terms.map(t => `<div class="small">• ${esc(t.title)} (version ${t.version}), accepted during setup</div>`).join('')}</details>
 <button class="btn" data-act="go" data-to="checkout">Continue to payment</button>`;
}
function quoteHtml(q, title) {
  return `<div class="card"><b>${title}</b>${q.conversion ? `<div class="note" style="margin:8px 0">Gold conversion: ${money(q.conversion.from.milligrams, 'XAU')} at ${money(q.conversion.ratePerGram, 'PKR')} per gram (${esc(q.conversion.source)}, price time ${dfmt(q.conversion.priceAt)}). ${esc(q.conversion.note)}</div>` : ''}
 <div class="kv"><span class="muted">${q.purpose === 'topup' ? 'Amount' : 'Contribution'}</span><b>${money(q.base, q.currency)}</b></div>${q.lines.filter(l => l.code !== 'discount' || l.amount).map(l => `<div class="kv"><span class="muted">${esc(l.label)}</span><b>${money(l.amount, q.currency)}</b></div>`).join('')}<div class="kv"><span><b>Total payable</b></span><b style="font-size:20px">${money(q.total, q.currency)}</b></div></div>`;
}

/* ================================= checkout and payments ================================= */
function orderBody() { const o = S.order; return { purpose: o.purpose, ...(o.targetId ? { targetId: o.targetId } : {}), ...(o.purpose === 'topup' ? { amount: o.amount, currency: o.currency } : {}) }; }
function startCheckout(o) { S.order = o; S.pm = o.purpose === 'topup' ? 'debit' : S.pm; S.idem = rid(); go('checkout'); }
const PMS = [['debit', 'Debit card', 'DC', 'Pay securely on your bank\'s page'], ['credit', 'Credit card', 'CC', 'Pay securely on your bank\'s page'], ['bank', 'Online bank transfer', 'BK', 'Transfer, then upload your receipt']];
function vCheckout() {
  const q = S.data, o = S.order, pms = [...PMS]; const w = q.methods.find(m => m.method === 'wallet'); if (w) pms.push(['wallet', 'Wallet balance', 'W', `${w.available ? 'Balance' : 'Not enough balance'}: ${money(w.balance, w.currency)}`]);
  return `${BK}<div class="stepper"><i class="on"></i><i class="on"></i><i></i></div><h1>Payment</h1><p class="muted">${esc(q.title)} · ${esc(q.subtitle || '')}</p>
 <h2 style="margin-top:6px">Payment method</h2>${pms.map(([k, l, c, s]) => `<button class="opt ${S.pm === k ? 'sel' : ''}" data-act="pm" data-k="${k}" ${k === 'wallet' && !w.available ? 'disabled style="opacity:.5"' : ''}><span class="dot">${c}</span><span><b>${l}</b><br><span class="muted small">${esc(s)}</span></span></button>`).join('')}
 ${['join', 'instalment'].includes(o.purpose) ? `<label class="lbl" for="promo">Promo code (optional)</label><div class="row" style="gap:8px"><input class="field" id="promo" style="font-size:16px;padding:12px" value="${val('promo')}"><button class="btn sm ghost" data-act="promo">Apply</button></div>` : ''}
 <div style="height:12px"></div>${quoteHtml(q, 'Review your payment')}
 <p class="muted small">Card details are entered on the provider's secure page. ${APP} never sees or stores your card number or CVV.</p>
 <button class="btn" data-act="pay-confirm">Confirm and pay ${money(q.total, q.currency)}</button>`;
}
function vWaiting() {
  const p = S.pay;
  return `<div class="spin" role="status" aria-label="Waiting"></div><h1 class="center">Waiting for confirmation</h1><p class="muted center">Finish the payment on your bank's page. We confirm it with the bank before updating your account, so this screen updates by itself.</p>
 ${S.payNext?.redirectUrl ? `<a class="btn" href="${esc(S.payNext.redirectUrl)}" target="_blank" rel="noopener noreferrer">Open secure payment page</a><div style="height:10px"></div>` : ''}
 ${S.dev ? `<div class="devnote">Development mode: no real gateway is connected. <button class="link" data-act="dev-confirm" data-ok="1">Simulate approval</button> · <button class="link" data-act="dev-confirm" data-ok="0">Simulate failure</button></div>` : ''}
 <p class="muted small center">Reference ${esc(p.ref)}</p><button class="btn ghost" data-act="tab" data-to="payments">Back to payments</button>`;
}
const vBankPay = () => { const b = S.bank, p = S.pay; const row = (k, v) => `<div class="kv"><span class="muted">${k}</span><button style="background:none;border:0;font-weight:700;text-align:right" data-act="copy" data-t="${esc(v)}">${esc(v)} ⧉</button></div>`;
  return `<h1>Online bank transfer</h1><p class="muted">Send exactly <b>${money(p.total, p.currency)}</b> from your bank app, then upload the receipt.</p><div class="card">${row('Bank', b.name)}${row('Account title', b.title)}${row('IBAN', b.iban)}${row('Reference', b.reference)}</div>
 <p class="small muted">Write the reference in the transfer comment so we can match your payment. Staff confirm the transfer, which can take a few hours.</p>
 <label class="btn" style="cursor:pointer">Upload transfer receipt<input type="file" id="rcpt" accept="image/*" hidden></label><button class="btn ghost" style="margin-top:10px" data-act="tab" data-to="payments">I will upload later</button>`; };
function vReceipt() {
  const r = S.data, ok = r.status === 'paid', bad = ['failed', 'cancelled'].includes(r.status);
  const next = ok && r.purpose === 'join' ? ['View my committees', 'tab', 'mine'] : ['Back to home', 'tab', 'home'];
  return `<div class="check no-print" style="background:${ok ? 'var(--accent)' : bad ? 'var(--warn)' : 'var(--primary)'}"><span style="color:${ok ? '#0B1F1A' : '#fff'}">${bad ? ICO.x : ICO.check}</span></div>
 <h1 class="center">${ok ? (r.purpose === 'topup' ? 'Money added' : 'Payment successful') : bad ? 'Payment ' + r.status : r.status === 'reversed' ? 'Payment reversed' : r.status === 'scheduled' ? 'Payment scheduled' : 'Payment in progress'}</h1>
 <p class="muted center">${ok ? 'Confirmed by the payment provider. Your receipt is below.' : bad ? 'You were not charged. Try again or use another method.' : 'We will update this receipt when the payment is confirmed.'}</p>
 <div class="card receipt"><div class="row"><b>Receipt</b><span class="small mono">${esc(r.reference)}</span></div>
 <div class="kv"><span class="muted">Date</span><b>${dfmt(r.date)}</b></div><div class="kv"><span class="muted">For</span><b>${PURP[r.purpose] || r.purpose}${r.committee ? ' · ' + esc(r.committee.name) : ''}</b></div><div class="kv"><span class="muted">Method</span><b>${METHOD[r.method] || r.method}${r.cardType ? ' (' + r.cardType + ')' : ''}</b></div><div class="kv"><span class="muted">Status</span>${pill(r.status)}</div>
 ${r.denomination ? `<div class="kv"><span class="muted">Denomination</span><b>${money(r.denomination.amount, r.denomination.currency)}</b></div>` : ''}${r.conversion ? `<div class="kv"><span class="muted">Gold price</span><b>${money(r.conversion.ratePerGram, 'PKR')} / g · ${dfmt(r.conversion.priceAt)}</b></div>` : ''}
 ${r.lines.map(l => `<div class="kv"><span class="muted">${esc(l.label)}</span><b>${money(l.amount, r.currency)}</b></div>`).join('')}<div class="kv"><span><b>Total (${r.currency})</b></span><b>${money(r.total, r.currency)}</b></div><div class="small muted">Paid by ${esc(r.payer.name)} · ${esc(r.payer.phone)}</div></div>
 <button class="btn no-print" data-act="${next[1]}" data-to="${next[2]}">${next[0]}</button><button class="btn ghost no-print" style="margin-top:10px" data-act="print">Print or save receipt</button>${bad ? '<button class="link no-print" data-act="tab" data-to="payments">Back to payments</button>' : ''}`;
}
const FILTERS = [['all', 'All'], ['scheduled', 'Scheduled'], ['pending', 'Pending'], ['paid', 'Successful'], ['failed', 'Failed'], ['cancelled', 'Cancelled']];
const inFilter = (p, f) => f === 'all' || (f === 'pending' ? ['pending', 'created', 'awaiting_transfer', 'under_review'].includes(p.status) : p.status === f);
const vPayments = () => { const d = S.data; const list = d.payments.payments.filter(p => inFilter(p, S.payFilter));
  return `<h1>Payments</h1><div class="grid2"><div class="card" style="margin:0"><div class="small muted">PKR wallet</div><b style="font-size:18px">${money(d.wallet.balances.PKR, 'PKR')}</b></div><div class="card" style="margin:0"><div class="small muted">USD wallet</div><b style="font-size:18px">${money(d.wallet.balances.USD, 'USD')}</b></div></div>
 <button class="btn ghost" style="margin:12px 0" data-act="go" data-to="topup">Add money to wallet</button>
 <div class="tabs" role="tablist" aria-label="Filter payments">${FILTERS.map(([k, l]) => `<button class="${S.payFilter === k ? 'on' : ''}" data-act="pfilter" data-k="${k}">${l}</button>`).join('')}</div>
 ${list.length ? list.map(pRow).join('') : '<div class="card"><b>No payments here</b><p class="muted small" style="margin:4px 0 0">Payments in this state will appear here.</p></div>'}`; };
const vTopup = () => `${BK}<h1>Add money</h1><p class="muted">Your PKR and USD wallets are kept separate.</p><div class="tabs">${['PKR', 'USD'].map(c => `<button class="${S.topCur === c ? 'on' : ''}" data-act="topcur" data-c="${c}">${c}</button>`).join('')}</div>
 <div class="tabs">${(S.topCur === 'USD' ? [2500, 5000, 10000, 50000] : [500000, 1000000, 2500000, 5000000]).map(v => `<button data-act="topquick" data-v="${v}">${money(v, S.topCur)}</button>`).join('')}</div>
 <label class="lbl" for="topamt">Or enter an amount (${S.topCur === 'USD' ? '$' : 'Rs'})</label><input class="field" id="topamt" inputmode="decimal" value="${esc(S.topAmt)}">${fe('topamt')}<div style="height:12px"></div><button class="btn" data-act="topcustom">Continue</button>`;

/* ================================ my committees ================================ */
const vMine = () => `<h1>My committees</h1>${S.data.memberships.length ? S.data.memberships.map(m => m.status === 'pending_payment' ? `<button class="card" data-act="resume-join" data-id="${m.id}"><div class="row"><b>${esc(m.name)}</b>${pill('pending_payment')}</div><div class="small muted">Slot ${m.slot} is held for you. Tap to finish paying.</div></button>` : mCard(m)).join('') : '<div class="card"><b>No committees yet</b><p class="muted small" style="margin:4px 0 12px">Browse the committees to get started.</p><button class="btn" data-act="tab" data-to="committees">Browse committees</button></div>'}`;
function vMineDetail() {
  const m = S.data, paid = m.instalments.filter(i => i.status === 'paid').length, next = m.instalments.find(i => ['due', 'overdue'].includes(i.status));
  return `${BK}<h1>${esc(m.name)}</h1><p class="muted">Payout month ${m.slot} · ${dfmt(m.payoutDate)}</p>
 <div class="card"><div class="row"><b>Progress</b><span class="muted small">${paid} / ${m.months}</span></div><div class="bar"><i style="width:${paid / m.months * 100}%"></i></div></div>
 <div class="card"><div class="kv"><span class="muted">Payout amount</span><b>${money(m.totalAmount, m.currency)}</b></div><div class="kv"><span class="muted">Payout status</span><b>${m.payout ? (m.payout.status === 'sent' ? 'Sent' : 'Being prepared') : 'Not yet due'}</b></div>${m.payout?.settlementNote ? `<p class="small muted">${esc(m.payout.settlementNote)}</p>` : ''}<button class="btn ghost" style="margin-top:10px" data-act="go" data-to="payoutacc">Payout account</button></div>
 <div class="card"><div class="row"><div><b>Automatic payments</b><div class="small muted">${m.autoPay ? 'On · ' + esc(m.autoPay.fundingSource) : S.recurring ? 'Off' : 'Not available yet'}</div></div><button class="btn sm ghost" data-act="go-autopay" data-id="${m.id}">Manage</button></div></div>
 <h2>Payout order</h2><div class="card">${m.payoutOrder.map(o => `<div class="mem ${o.name === 'You' ? 'me' : ''}"><span class="n">${o.slot}</span><span>${esc(o.name)}</span></div>`).join('')}</div>
 <h2>Instalments</h2>${m.instalments.map(i => `<div class="card row" style="padding:12px 16px;margin-bottom:8px"><span>Month ${i.seq} · ${dfmt(i.dueDate)}<br><b>${money(i.amount, i.currency)}</b></span>${pill(i.status)}</div>`).join('')}
 ${next ? `<button class="btn" data-act="pay-inst" data-id="${next.id}">Pay next instalment</button>` : ''}`;
}
const vAutopay = () => { const a = S.data.info, ms = S.data.mandates.filter(x => x.membershipId === +S.params.id && x.status === 'active');
  if (ms.length) { const m = ms[0]; return `${BK}<h1>Automatic payments</h1><div class="card"><div class="kv"><span class="muted">Status</span>${pill('active')}</div><div class="kv"><span class="muted">Funding source</span><b>${esc(m.fundingSource)}</b></div><div class="kv"><span class="muted">Frequency</span><b>Monthly, day ${m.dayOfMonth}</b></div><div class="kv"><span class="muted">Authorised</span><b>${dfmt(m.authorizedAt)}</b></div></div><p class="small muted">${esc(a.cancel)}</p><button class="btn danger" data-act="mandate-cancel" data-id="${m.id}">Cancel automatic payments</button>`; }
  if (!a.available) return `${BK}<h1>Automatic payments</h1><div class="card"><b>Not available yet</b><p class="muted small" style="margin:6px 0 0">Automatic deductions need an approved bank or payment provider, which is not connected yet. Please pay each instalment yourself. We will tell you when this becomes available.</p></div>`;
  return `${BK}<h1>Automatic payments</h1>${a.sandbox ? '<div class="devnote">Development sandbox: no real money moves.</div>' : ''}<div class="card"><div class="kv"><span class="muted">Amount</span><span class="small" style="text-align:right;max-width:65%">${esc(a.amount)}</span></div><div class="kv"><span class="muted">Frequency</span><b>${esc(a.frequency)}</b></div><div class="kv"><span class="muted">Date</span><span class="small" style="text-align:right;max-width:65%">${esc(a.date)}</span></div></div>
 <div class="card"><div class="small"><b>If a deduction fails:</b> ${esc(a.failure)}</div><div class="small" style="margin-top:6px"><b>Cancelling:</b> ${esc(a.cancel)}</div><div class="small" style="margin-top:6px"><b>Disputes:</b> ${esc(a.dispute)}</div></div>
 <label class="lbl" for="fund">Funding source (no full card or account numbers)</label><input class="field" id="fund" placeholder="Debit card ending 4242" value="${val('fund')}">${fe('fund')}
 <details class="card" style="margin-top:12px"><summary>${esc(a.authorization.title)}</summary><p class="small">${esc(a.authorization.body)}</p></details><div class="cbrow"><input type="checkbox" id="autoc"><label for="autoc">I have read and give this authorization.</label></div>
 <button class="btn" id="autoBtn" data-act="mandate-create" data-id="${S.params.id}" data-v="${a.authorization.version}" disabled>Turn on automatic payments</button>`; };

/* ======================== notifications, profile, help, reports ======================== */
const vNotifications = () => `${BK}<div class="row"><h1>Notifications</h1></div>${S.data.notifications.length ? S.data.notifications.map(n => `<div class="card" style="${n.read ? '' : 'border-color:var(--accent)'}"><div class="row"><b>${esc(n.title)}</b><span class="small muted">${dfmt(n.createdAt)}</span></div><p class="small muted" style="margin:4px 0 0">${esc(n.body)}</p></div>`).join('') : '<div class="card"><b>No notifications yet</b><p class="muted small" style="margin:4px 0 0">Important updates about your account and payments appear here.</p></div>'}`;
function vProfile() {
  const d = S.data, me = S.me;
  return `<h1>Profile</h1><div class="card row"><div class="logo-row"><span class="dot" style="width:46px;height:46px;font-size:18px">${esc((me.name || 'U')[0])}</span><div><b>${esc(me.name || '')}</b><div class="small muted">${esc(me.phone)}${me.email ? ' · ' + esc(me.email) : ''}</div></div></div></div>
 <div class="card"><div class="kv"><span>Identity verification</span>${pill(me.kycStatus === 'pending' ? 'under_review' : me.kycStatus)}</div><div class="kv"><span>Bank verification</span>${pill(me.verification.status)}</div><div class="kv"><span class="muted">Bank account</span><b>${d.bank ? esc(d.bank.bankName) + ' ' + esc(d.bank.ibanMasked.slice(-9)) : 'Not added'}</b></div><button class="link" data-act="go" data-to="${me.setup.complete ? 'verification' : 'setup'}">${me.setup.complete ? 'View verification details ›' : 'Finish account setup ›'}</button></div>
 <div class="card">${[['My report', 'report'], ['Payout account', 'payoutacc'], ['Notifications', 'notifications'], ['Help and support', 'help']].map(r => `<button class="kv" style="width:100%;background:none;border:0;border-bottom:1px dashed var(--line);text-align:left" data-act="go" data-to="${r[1]}"><span>${r[0]}</span><span class="muted">${r[1] === 'payoutacc' && d.acct ? esc(d.acct.type) + ' ···' + esc(d.acct.last4) + ' ›' : '›'}</span></button>`).join('')}<button class="kv" style="width:100%;background:none;border:0;text-align:left" data-act="replay-onb"><span>View the introduction again</span><span class="muted">›</span></button></div>
 <button class="btn ghost" data-act="logout">Log out</button><p class="muted small center" style="margin-top:12px">${APP} is not a bank. It is not approved or endorsed by the State Bank of Pakistan or any bank.</p>`;
}
const vPayoutAcc = () => `${BK}<h1>Payout account</h1><p class="muted">Where we send your committee payout.</p>${[['jazz', 'JazzCash'], ['easy', 'Easypaisa'], ['bank', 'Bank account (IBAN)']].map(([k, l]) => `<button class="opt ${(S.f.ptype || 'jazz') === k ? 'sel' : ''}" data-act="ptype" data-k="${k}"><span class="dot">${k === 'bank' ? 'BK' : k === 'jazz' ? 'JC' : 'EP'}</span><b>${l}</b></button>`).join('')}
 <label class="lbl" for="pnum">${(S.f.ptype || 'jazz') === 'bank' ? 'IBAN' : 'Mobile number'}</label><input class="field" id="pnum" placeholder="${(S.f.ptype || 'jazz') === 'bank' ? 'PK00 XXXX 0000 0000 0000 0000' : '03XX XXXXXXX'}" value="${val('pnum')}">${fe('pnum')}<div style="height:14px"></div><button class="btn" data-act="save-payout">Save payout account</button>`;
const vHelp = () => { const d = S.data; return `${BK}<h1>Help and support</h1>${[['When do I get my payout?', 'In your chosen month, once every member has paid, after our staff approve it. It goes to your payout account.'], ['What if I pay late?', 'A late fee may apply to overdue instalments. The amount is shown in your committee rules.'], ['Can I cancel automatic payments?', 'Yes, any time, from the committee page. It takes effect before the next deduction if done a business day earlier.'], ['Who can see my bank and identity details?', 'Only authorised staff with the right role, and every view is logged. Your bank account is always masked in the app.']].map(f => `<details class="card"><summary>${f[0]}</summary><p class="muted small" style="margin:0">${f[1]}</p></details>`).join('')}
 <h2>Raise a dispute or ask a question</h2><label class="lbl" for="dtype">About</label><select class="field" id="dtype"><option value="payment">A payment</option><option value="deduction">An automatic deduction</option><option value="other">Something else</option></select><label class="lbl" for="dmsg">Message</label><textarea class="field" id="dmsg" rows="3" style="font-size:15px">${val('dmsg')}</textarea>${fe('dmsg')}<div style="height:10px"></div><button class="btn" data-act="dispute-send">Send</button>
 ${d.disputes.length ? `<h2>Your messages</h2>${d.disputes.map(x => `<div class="card"><div class="row"><b>${esc(x.type)}</b>${pill(x.status === 'open' ? 'pending' : 'paid')}</div><p class="small">${esc(x.message)}</p>${x.response ? `<div class="note"><b>Reply:</b> ${esc(x.response)}</div>` : ''}</div>`).join('')}` : ''}`; };
const vReport = () => { const r = S.data; return `${BK}<h1>My report</h1>${r.byCurrency.length ? r.byCurrency.map(c => `<div class="card"><b>${CUR[c.currency]}</b><div class="kv"><span class="muted">Total contributions</span><b>${money(c.contributions, c.currency)}</b></div><div class="kv"><span class="muted">Service fees paid</span><b>${money(c.feesPaid, c.currency)}</b></div><div class="kv"><span class="muted">Transfer charges</span><b>${money(c.transferCharges, c.currency)}</b></div><div class="kv"><span class="muted">Outstanding</span><b>${money(c.outstanding, c.currency)}</b></div><div class="kv"><span class="muted">Payouts received</span><b>${money(c.payouts, c.currency)}</b></div></div>`).join('') : '<p class="muted">No activity yet.</p>'}
 <h2>Committees</h2><div class="card"><div class="kv"><span class="muted">Active</span><b>${r.committees.active.length}</b></div><div class="kv"><span class="muted">Completed</span><b>${r.committees.completed.length}</b></div></div>
 <h2>Payout history</h2>${r.payouts.length ? r.payouts.map(p => `<div class="card row"><div><b>${esc(p.name)}</b><div class="small muted">${p.sentAt ? dfmt(p.sentAt) : 'Pending'}</div></div><b>${money(p.amount, p.currency)}</b></div>`).join('') : '<p class="muted small">No payouts yet.</p>'}`; };

/* ================================= screen registry ================================= */
const SCREENS = {
  boot: { view: () => loadingHtml },
  onboarding: { view: vOnboarding, after: onbAfter }, login: { view: vLogin }, register: { view: vRegister }, verifyphone: { view: vVerifyPhone }, forgot: { view: vForgot }, reset: { view: vReset },
  setup: { load: async () => { await refreshMe(); const d = await api('/setup'); return d; }, view: vSetup },
  bankform: { load: () => api('/bank'), view: vBankForm }, bankconfirm: { load: () => api('/bank'), view: vBankConfirm }, bankview: { load: () => api('/bank'), view: vBankView },
  idintro: { view: vIdIntro }, camera: { view: vCamera, after: () => { if (!S.preview) startCam(); } }, kycdetails: { view: vKycDetails },
  selfie: { view: vSelfie, after: () => { if (S.selfie.stage === 'live') startCam(); } },
  consent: { load: () => api('/consents'), view: vConsent }, verification: { load: async () => { await refreshMe(); return api('/verification'); }, view: vVerification },
  home: { load: async () => { const [me, mine, report, payments, plans] = await Promise.all([refreshMe(), api('/memberships'), api('/reports/me'), api('/payments'), api('/plans')]); return { mine, report, payments, plans }; }, view: vHome },
  committees: { load: () => api('/plans?currency=' + S.cat), view: vCommittees },
  plan: { load: () => api('/plans/' + S.params.id), view: vPlan },
  summary: { load: async () => { const [plan, quote] = await Promise.all([api('/plans/' + S.params.planId), api('/payments/quote', { method: 'POST', body: { ...orderBody(), method: 'debit' } })]); return { plan, quote }; }, view: vSummary },
  checkout: { load: () => api('/payments/quote', { method: 'POST', body: { ...orderBody(), method: S.pm, ...(S.f.promo ? { promo: S.f.promo } : {}) } }), view: vCheckout },
  waiting: { view: vWaiting, after: () => { pollTimer = setInterval(pollPayment, 2500); } }, bankpay: { view: vBankPay },
  receipt: { load: () => api(`/payments/${S.params.ref}/receipt`), view: vReceipt },
  payments: { load: async () => { const [wallet, payments] = await Promise.all([api('/wallet'), api('/payments')]); return { wallet, payments }; }, view: vPayments }, topup: { view: vTopup },
  mine: { load: () => api('/memberships'), view: vMine }, mineDetail: { load: () => api('/memberships/' + S.params.id), view: vMineDetail },
  autopay: { load: async () => { const [info, mandates] = await Promise.all([api(`/memberships/${S.params.id}/auto-pay`), api('/mandates')]); return { info, mandates: mandates.mandates }; }, view: vAutopay },
  notifications: { load: async () => { const r = await api('/notifications'); api('/notifications/read', { method: 'POST', body: { all: true } }).then(() => { if (S.me) S.me.unreadNotifications = 0; }).catch(() => {}); return r; }, view: vNotifications },
  profile: { load: async () => { await refreshMe(); const [bank, acct] = await Promise.all([api('/bank'), api('/payout-account')]); return { bank: bank.bank, acct }; }, view: vProfile },
  payoutacc: { view: vPayoutAcc }, help: { load: () => api('/disputes'), view: vHelp }, report: { load: () => api('/reports/me'), view: vReport },
};

async function pollPayment() { if (S.screen !== 'waiting' || !S.pay) return; try { const p = await api('/payments/' + S.pay.ref); if (['paid', 'failed', 'cancelled'].includes(p.status)) { clearInterval(pollTimer); go('receipt', { reset: true, params: { ref: p.ref } }); } } catch {} }

/* ==================================== events ==================================== */
document.addEventListener('input', e => {
  const t = e.target, id = t.id; if (!id) return;
  const digits = ['lphone', 'rphone', 'fphone', 'vcode', 'fcode'];
  if (id === 'kcnic') { const d = t.value.replace(/\D/g, '').slice(0, 13); const v = d.length > 12 ? `${d.slice(0, 5)}-${d.slice(5, 12)}-${d.slice(12)}` : d.length > 5 ? `${d.slice(0, 5)}-${d.slice(5)}` : d; t.value = v; S.kyc.cnic = v; return; }
  if (id === 'kname') { S.kyc.name = t.value; return; } if (id === 'kdob') { S.kyc.dob = t.value; return; }
  if (id === 'biban') { const v = t.value.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 24).replace(/(.{4})/g, '$1 ').trim(); t.value = v; S.f.biban = v; return; }
  S.f[id] = digits.includes(id) ? t.value.replace(/\D/g, '') : t.value;
  if (id === 'topamt') S.topAmt = t.value;
  if (id === 'bconfirm') $('#bsubmit').disabled = !t.checked;
});
document.addEventListener('change', async e => {
  const t = e.target;
  if (t.id === 'bconfirm') $('#bsubmit').disabled = !t.checked;
  if (t.id === 'autoc') $('#autoBtn').disabled = !t.checked;
  if (t.classList.contains('cons')) { S.consentOk[t.dataset.type] = t.checked; const all = [...document.querySelectorAll('.cons')].every(c => c.checked); const b = $('#consBtn'); if (b) b.disabled = !all; }
  if (t.id === 'camfile' && S.screen === 'camera') { const f = t.files && t.files[0]; if (!f) return; const r = new FileReader(); r.onload = async () => { S.kycImg[S.cam] = await downscale(r.result); stopCam(); S.preview = true; rerender(); }; r.readAsDataURL(f); }
  if (t.id === 'rcpt') {
    const f = t.files && t.files[0]; if (!f) return; $('#view').classList.add('busy');
    try { const img = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); }).then(downscale);
      const up = await api('/uploads', { method: 'POST', body: { kind: 'receipt', image: img } }); await api(`/payments/${S.pay.ref}/proof`, { method: 'POST', body: { uploadId: up.uploadId } });
      $('#view').classList.remove('busy'); go('receipt', { reset: true, params: { ref: S.pay.ref } });
    } catch (err) { toast(err.message); $('#view').classList.remove('busy'); }
  }
});
const phoneOk = v => /^(?:\+92|92|0)?3\d{9}$/.test(String(v || '').replace(/[\s-]/g, ''));
const pwOk = v => typeof v === 'string' && v.length >= 8 && /[A-Za-z]/.test(v) && /\d/.test(v);
async function afterLogin(token) { S.token = token; store.set('mo_token', token); await refreshMe(); go(S.me.setup.complete ? 'home' : 'setup', { reset: true }); }

document.addEventListener('click', async e => {
  const b = e.target.closest('[data-act]'); if (!b || (b.disabled && !b.dataset.act.startsWith('x'))) return;
  const a = b.dataset.act, d = b.dataset;
  try {
    switch (a) {
      case 'back': return back();
      case 'reload': S.data = null; return render();
      case 'go': return go(d.to);
      case 'tab': return go(d.to, { reset: true });
      case 'logout': return logout();
      case 'print': return window.print();
      case 'copy': try { await navigator.clipboard.writeText(d.t); } catch {} return toast('Copied');
      case 'onb-next': { const t = $('#onbTrack'), i = Math.round(t.scrollLeft / t.clientWidth); if (i >= SLIDES.length - 1) return finishOnboarding(); t.scrollTo({ left: (i + 1) * t.clientWidth, behavior: 'smooth' }); return; }
      case 'onb-skip': return finishOnboarding();
      case 'replay-onb': S.replay = !!S.me; return go('onboarding');
      /* accounts */
      case 'login': { S.err = {}; const ph = S.f.lphone, pw = S.f.lpw; if (!phoneOk(ph)) S.err.lphone = 'Enter a valid mobile number'; if (!pw) S.err.lpw = 'Enter your password'; if (Object.keys(S.err).length) return rerender();
        try { const r = await api('/auth/login', { method: 'POST', body: { phone: ph, password: pw } }); S.f.lpw = ''; return afterLogin(r.token); }
        catch (e) { if (e.code === 'phone_unverified') { S.f.vphone = ph; S.f.devCode = e.extra?.devCode || ''; S.f.vcode = S.f.devCode; return go('verifyphone'); } S.err.form = e.message; return rerender(); } }
      case 'register': { S.err = {}; const f = S.f; if ((f.rname || '').trim().length < 2) S.err.rname = 'Enter your full name'; if (!phoneOk(f.rphone)) S.err.rphone = 'Enter a valid mobile number'; if (f.remail && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.remail)) S.err.remail = 'Enter a valid email'; if (!pwOk(f.rpw)) S.err.rpw = 'Use at least 8 characters with letters and a number'; if (Object.keys(S.err).length) return rerender();
        try { const r = await api('/auth/register', { method: 'POST', body: { name: f.rname.trim(), phone: f.rphone, email: f.remail || undefined, password: f.rpw } }); S.f.vphone = f.rphone; S.f.devCode = r.devCode || ''; S.f.vcode = S.f.devCode; S.f.rpw = ''; return go('verifyphone'); }
        catch (e) { S.err.form = e.message; return rerender(); } }
      case 'resend': { const r = await api('/auth/resend-code', { method: 'POST', body: { phone: S.f.vphone } }); S.f.devCode = r.devCode || ''; S.f.vcode = S.f.devCode; toast('Code sent'); return rerender(); }
      case 'verify-phone': { if ((S.f.vcode || '').length < 4) { S.err.vcode = 'Enter the code'; return rerender(); } try { const r = await api('/auth/verify-phone', { method: 'POST', body: { phone: S.f.vphone, code: S.f.vcode } }); S.f.vcode = ''; return afterLogin(r.token); } catch (e) { S.err.vcode = e.message; return rerender(); } }
      case 'forgot': { if (!phoneOk(S.f.fphone)) { S.err.fphone = 'Enter a valid mobile number'; return rerender(); } const r = await api('/auth/password/forgot', { method: 'POST', body: { phone: S.f.fphone } }); S.f.devCode = r.devCode || ''; S.f.fcode = S.f.devCode; return go('reset'); }
      case 'reset': { S.err = {}; if ((S.f.fcode || '').length < 4) S.err.fcode = 'Enter the code'; if (!pwOk(S.f.fnew)) S.err.fnew = 'Use at least 8 characters with letters and a number'; if (Object.keys(S.err).length) return rerender();
        try { await api('/auth/password/reset', { method: 'POST', body: { phone: S.f.fphone, code: S.f.fcode, newPassword: S.f.fnew } }); S.f.fnew = ''; toast('Password changed. Please log in.'); return go('login', { reset: true }); } catch (e) { S.err.fcode = e.message; return rerender(); } }
      /* bank */
      case 'bank-save': { S.err = {}; const f = S.f; const hold = ($('#bhold') || {}).value || ''; const bank = ($('#bbank') || {}).value || ''; const type = ($('#btype') || {}).value || 'savings'; const iban = (f.biban || '').replace(/\s/g, '');
        if (!/^[A-Za-z .'-]{3,80}$/.test(hold.trim())) S.err.bhold = 'Enter the name using letters only'; if (!bank) S.err.bbank = 'Choose your bank'; if (!/^PK\d{2}[A-Z]{4}\d{16}$/.test(iban)) S.err.biban = 'Enter a valid 24-character IBAN starting with PK';
        S.f.bhold = hold; S.f.bbank = bank; S.f.btype = type; if (Object.keys(S.err).length) return rerender();
        try { await api('/bank', { method: 'PUT', body: { holderName: hold.trim(), bankName: bank, accountType: type, iban } }); S.f.biban = ''; return go('bankconfirm'); } catch (e) { S.err.form = e.message; return rerender(); } }
      case 'bank-confirm': { await api('/bank/confirm', { method: 'POST', body: { confirm: true } }); toast('Bank details submitted'); return go('setup', { reset: true }); }
      /* identity */
      case 'id-start': S.kycImg = {}; S.cam = 'front'; S.preview = false; S.selfie = { stage: 'intro' }; return go('camera');
      case 'cap': { if (!stream) return; const img = grab(); stopCam(); S.preview = true; if (isSelfieLive()) { S.kycImg.selfie = img; S.selfie.stage = 'review'; S.preview = false; return rerender(); } S.kycImg[S.cam] = img; return rerender(); }
      case 'retake': S.preview = false; return rerender();
      case 'usephoto': if (S.cam === 'front') { S.cam = 'back'; S.preview = false; return rerender(); } S.preview = false; return go('kycdetails');
      case 'cam-retry': stopCam(); S.preview = false; return rerender();
      case 'kyc-next': { S.err = {}; const k = S.kyc; k.name = ($('#kname') || {}).value ?? k.name; k.cnic = ($('#kcnic') || {}).value ?? k.cnic; k.dob = ($('#kdob') || {}).value ?? k.dob; if (k.name.trim().length < 2) S.err.kname = 'Enter your full name'; if (k.cnic.replace(/\D/g, '').length !== 13) S.err.kcnic = 'CNIC must have 13 digits'; if (!k.dob) S.err.kdob = 'Enter your date of birth'; else if ((Date.now() - new Date(k.dob)) / 31557600000 < 18) S.err.kdob = 'You must be 18 or older'; if (Object.keys(S.err).length) return rerender(); S.selfie = { stage: 'intro' }; return go('selfie'); }
      case 'selfie-open': { stopCam(); S.challenge = await api('/kyc/liveness', { method: 'POST' }); S.liveDone = false; S.selfie = { stage: 'live' }; S.kycImg.selfie = null; return rerender(); }
      case 'selfie-submit': return submitIdentity();
      /* consent and verification */
      case 'consent-accept': { const items = [...document.querySelectorAll('.cons')].map(c => ({ type: c.dataset.type, version: +c.dataset.version, accepted: c.checked })); await api('/consents', { method: 'POST', body: { consents: items } }); await refreshMe(); toast('Thank you. Your consent was recorded.'); return go('setup', { reset: true }); }
      case 'dispute-eligibility': { const m = ($('#dmsg') || {}).value || ''; if (m.trim().length < 5) { S.err.dmsg = 'Tell us a little more (at least 5 characters)'; return rerender(); } await api('/disputes', { method: 'POST', body: { type: 'eligibility', message: m } }); S.f.dmsg = ''; toast('Review requested'); S.data = null; return render(); }
      /* dashboard and committees */
      case 'cat': S.cat = d.c; return go('committees', { reset: true });
      case 'cat-tab': S.cat = d.c; S.data = null; return render();
      case 'open-plan': S.slot = null; return go('plan', { params: { id: d.id } });
      case 'slot': { if (d.state !== 'available') return toast(d.reason || 'That slot is ' + (SLOT_LABEL[d.state] || d.state).toLowerCase()); S.slot = +d.n; return rerender(); }
      case 'hold-slot': { if (needSetup()) return; const p = S.data; const r = await api('/memberships', { method: 'POST', body: { planId: p.id, slot: S.slot } });
        S.order = { purpose: 'join', targetId: r.membershipId, slot: S.slot }; S.idem = rid(); return go('summary', { params: { planId: p.id } }); }
      case 'resume-join': { const m = await api('/memberships/' + d.id); S.order = { purpose: 'join', targetId: m.id, slot: m.slot }; S.idem = rid(); return go('summary', { params: { planId: await planIdFor(m) } }); }
      case 'open-mine': return go('mineDetail', { params: { id: d.id } });
      case 'go-autopay': return go('autopay', { params: { id: d.id } });
      case 'pay-inst': if (needSetup()) return; return startCheckout({ purpose: 'instalment', targetId: +d.id });
      /* checkout */
      case 'pm': S.pm = d.k; S.data = null; return render();
      case 'promo': S.data = null; return render();
      case 'pay-confirm': return confirmPayment();
      case 'dev-confirm': await api('/dev/gateway/confirm', { method: 'POST', body: { ref: S.pay.ref, success: d.ok === '1' } }); return pollPayment();
      case 'open-pay': return go('receipt', { params: { ref: d.ref } });
      case 'pfilter': S.payFilter = d.k; return rerender();
      case 'topcur': S.topCur = d.c; return rerender();
      case 'topquick': return startCheckout({ purpose: 'topup', amount: +d.v, currency: S.topCur });
      case 'topcustom': { const n = parseFloat(S.topAmt); const minor = Math.round(n * 100); const ok = S.topCur === 'USD' ? minor >= 500 && minor <= 1000000 : minor >= 50000 && minor <= 20000000; if (!(n > 0) || !ok) { S.err.topamt = S.topCur === 'USD' ? 'Enter between $5 and $10,000' : 'Enter between Rs 500 and Rs 200,000'; return rerender(); } if (needSetup()) return; return startCheckout({ purpose: 'topup', amount: minor, currency: S.topCur }); }
      /* automatic payments */
      case 'mandate-create': { const f = (S.f.fund || '').trim(); if (f.length < 3) { S.err.fund = 'Describe the funding source, for example "Debit card ending 4242"'; return rerender(); } await api('/mandates', { method: 'POST', body: { membershipId: +d.id, fundingLabel: f, consent: true, consentVersion: +d.v } }); toast('Automatic payments are on'); S.data = null; return render(); }
      case 'mandate-cancel': await api(`/mandates/${d.id}/cancel`, { method: 'POST' }); toast('Automatic payments cancelled'); S.data = null; return render();
      /* profile */
      case 'ptype': S.f.ptype = d.k; return rerender();
      case 'save-payout': { const num = (S.f.pnum || '').trim(); if (!num) { S.err.pnum = 'Enter a number'; return rerender(); } await api('/payout-account', { method: 'PUT', body: { type: S.f.ptype || 'jazz', number: num } }); S.f.pnum = ''; toast('Payout account saved'); return back(); }
      case 'dispute-send': { const m = ($('#dmsg') || {}).value || ''; if (m.trim().length < 5) { S.err.dmsg = 'Write at least 5 characters'; return rerender(); } await api('/disputes', { method: 'POST', body: { type: ($('#dtype') || {}).value || 'other', message: m } }); S.f.dmsg = ''; toast('Sent. We will reply in the app.'); S.data = null; return render(); }
    }
  } catch (err) { if (err.code !== 'auth') toast(err.message); if (err.code === 'setup_incomplete') go('setup'); }
});
async function planIdFor(m) { const all = (await Promise.all(['PKR', 'USD', 'XAU'].map(c => api('/plans?currency=' + c)))).flatMap(r => r.plans); return (all.find(p => p.name === m.name) || {}).id; }
async function confirmPayment() {
  if (S.busy) return; S.busy = true; $('#view').classList.add('busy'); const q = S.data;
  try {
    const r = await api('/payments', { method: 'POST', body: { ...orderBody(), method: S.pm, idempotencyKey: S.idem, quotedTotal: q.total, ...(S.f.promo ? { promo: S.f.promo } : {}) } });
    S.pay = r.payment; S.payNext = r.next || null; S.bank = r.bank || null; S.busy = false; $('#view').classList.remove('busy'); S.f.promo = '';
    if (['paid', 'under_review'].includes(r.payment.status)) return go('receipt', { reset: true, params: { ref: r.payment.ref } });
    if (r.payment.status === 'awaiting_transfer') return r.bank ? go('bankpay') : go('receipt', { reset: true, params: { ref: r.payment.ref } });
    return go('waiting');
  } catch (e) {
    S.busy = false; $('#view').classList.remove('busy'); S.idem = rid();
    if (e.code === 'quote_changed') { S.data = e.extra.quote; rerender(); return toast(e.message); }
    toast(e.message); if (['reservation_expired', 'slot_taken'].includes(e.code)) go('committees', { reset: true });
  }
}

/* ===================================== boot ===================================== */
(async () => {
  if ('serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('/sw.js').catch(() => {});
  render();
  try { const h = await fetch('/health').then(r => r.json()); S.dev = !!h.dev; S.recurring = !!h.recurringAvailable; } catch {}
  if (!store.get('mo_onboarded') && !S.token) return go('onboarding', { reset: true });
  if (!S.token) return go('login', { reset: true });
  try { await refreshMe(); go(S.me.setup.complete ? 'home' : 'setup', { reset: true }); } catch (e) { if (e.code !== 'auth') { S.screen = 'login'; render(); toast(e.message); } }
})();
