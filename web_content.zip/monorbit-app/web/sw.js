// Minimal service worker: lets the app install to the home screen and open the shell offline.
// API calls are never cached.
const SHELL = ['/', '/app.css', '/app.js', '/brand-icon.svg', '/brand-logo.svg', '/brand-logo-white.svg'];
self.addEventListener('install', e => e.waitUntil(caches.open('monorbit-shell-v2').then(c => c.addAll(SHELL)).then(() => self.skipWaiting())));
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin || !SHELL.includes(u.pathname)) return;
  e.respondWith(fetch(e.request).then(r => { const c = r.clone(); caches.open('monorbit-shell-v2').then(k => k.put(e.request, c)); return r; }).catch(() => caches.match(e.request)));
});
