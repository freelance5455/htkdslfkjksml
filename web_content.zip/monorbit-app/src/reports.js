// Reports. Totals are always grouped by currency: PKR, USD and gold (mg) are never added together.
const { HttpError } = require('./lib');

const group = rows => rows.reduce((a, r) => { (a[r.currency] ||= []).push(r); return a; }, {});
function userReport(db, uid) {
  const out = {};
  const cur = c => (out[c] ||= { currency: c, contributions: 0, feesPaid: 0, transferCharges: 0, outstanding: 0, payouts: 0, upcoming: [] });
  for (const r of db.prepare("SELECT currency, SUM(amount) a, SUM(fee) f, SUM(transfer) t FROM payments WHERE user_id=? AND status='paid' AND purpose IN ('join','instalment') GROUP BY currency").all(uid)) { const o = cur(r.currency); o.contributions = r.a; o.feesPaid = r.f; o.transferCharges = r.t; }
  for (const r of db.prepare("SELECT i.currency, SUM(i.amount) s FROM instalments i JOIN memberships m ON m.id=i.membership_id WHERE m.user_id=? AND m.status='active' AND i.status IN ('due','overdue') GROUP BY i.currency").all(uid)) cur(r.currency).outstanding = r.s;
  for (const r of db.prepare("SELECT currency, SUM(amount) s FROM payouts WHERE user_id=? AND status='sent' GROUP BY currency").all(uid)) cur(r.currency).payouts = r.s;
  for (const r of db.prepare("SELECT i.id, i.seq, i.due_date dueDate, i.amount, i.currency, i.status, pl.name FROM instalments i JOIN memberships m ON m.id=i.membership_id JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE m.user_id=? AND m.status='active' AND i.status IN ('due','overdue') ORDER BY i.due_date LIMIT 20").all(uid)) cur(r.currency).upcoming.push(r);
  const committees = db.prepare("SELECT m.id, m.slot, m.status, c.status cstatus, c.start_date startDate, pl.name, pl.currency, pl.amount, pl.months, (SELECT COUNT(*) FROM instalments i WHERE i.membership_id=m.id AND i.status='paid') paid FROM memberships m JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE m.user_id=? AND m.status='active'").all(uid);
  const payouts = db.prepare("SELECT p.id, p.amount, p.currency, p.status, p.sent_at sentAt, pl.name FROM payouts p JOIN memberships m ON m.id=p.membership_id JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE p.user_id=? ORDER BY p.id DESC").all(uid);
  return { byCurrency: Object.values(out), committees: { active: committees.filter(c => c.paid < c.months), completed: committees.filter(c => c.paid >= c.months) }, payouts };
}
function adminSummary(db, from = '0000-01-01', to = '9999-12-31') {
  const rng = [from, to + ' 23:59:59'];
  const j = (account) => db.prepare("SELECT currency, SUM(amount) s, COUNT(*) n FROM journal WHERE account=? AND reversal_of IS NULL AND created_at BETWEEN ? AND ? GROUP BY currency").all(account, ...rng);
  const rev = db.prepare("SELECT currency, SUM(amount) s, COUNT(DISTINCT reversal_of) n FROM journal WHERE reversal_of IS NOT NULL AND account IN ('contribution','wallet_deposit') AND created_at BETWEEN ? AND ? GROUP BY currency").all(...rng);
  return {
    range: { from, to },
    enrolments: db.prepare("SELECT pl.currency, COUNT(*) n FROM memberships m JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE m.status='active' GROUP BY pl.currency").all(),
    participation: db.prepare("SELECT c.id committeeId, pl.name, pl.currency, c.status, pl.months capacity, (SELECT COUNT(*) FROM memberships m WHERE m.committee_id=c.id AND m.status='active') members FROM committees c JOIN plans pl ON pl.id=c.plan_id ORDER BY c.id DESC").all(),
    contributionsCollected: j('contribution'), walletDeposits: j('wallet_deposit'), serviceFeeRevenue: j('service_fee'), transferCharges: j('transfer_charge'), discountsGiven: j('discount'), refundsAndReversals: rev,
    paymentsByStatus: db.prepare("SELECT currency, status, COUNT(*) n, SUM(total) s FROM payments WHERE created_at BETWEEN ? AND ? GROUP BY currency, status").all(...rng),
    payoutObligations: db.prepare("SELECT currency, status, COUNT(*) n, SUM(amount) s FROM payouts GROUP BY currency, status").all(),
    reconciliationDifferences: reconcile(db).differences.length,
  };
}
// Checks the books against each other. Anything that does not add up is listed, never hidden.
function reconcile(db) {
  const diffs = [];
  for (const p of db.prepare("SELECT * FROM payments WHERE status IN ('paid','reversed')").all()) {
    const s = db.prepare('SELECT COALESCE(SUM(amount),0) s, COUNT(*) n FROM journal WHERE payment_id=?').get(p.id);
    const expected = p.status === 'paid' ? p.total : 0;
    if (!s.n) diffs.push({ kind: 'missing_journal', ref: p.ref, currency: p.currency, expected, actual: 0 });
    else if (s.s !== expected) diffs.push({ kind: 'journal_total_mismatch', ref: p.ref, currency: p.currency, expected, actual: s.s });
  }
  for (const r of db.prepare("SELECT user_id, currency, SUM(amount) s, (SELECT balance_after FROM ledger l2 WHERE l2.user_id=l.user_id AND l2.currency=l.currency ORDER BY id DESC LIMIT 1) last FROM ledger l GROUP BY user_id, currency").all())
    if (r.s !== r.last) diffs.push({ kind: 'wallet_balance_mismatch', userId: r.user_id, currency: r.currency, expected: r.s, actual: r.last });
  for (const p of db.prepare("SELECT p.* FROM payments p WHERE p.method='wallet' AND p.status IN ('paid','reversed')").all()) {
    const d = db.prepare("SELECT COALESCE(SUM(amount),0) s FROM ledger WHERE payment_id=? AND kind='payment'").get(p.id).s;
    if (d !== -p.total) diffs.push({ kind: 'wallet_debit_mismatch', ref: p.ref, currency: p.currency, expected: -p.total, actual: d });
  }
  for (const i of db.prepare("SELECT i.id, i.payment_id, p.status FROM instalments i LEFT JOIN payments p ON p.id=i.payment_id WHERE i.status='paid'").all())
    if (!i.payment_id || i.status !== 'paid') diffs.push({ kind: 'paid_instalment_without_paid_payment', instalmentId: i.id });
  const totals = db.prepare("SELECT currency, SUM(amount) journal FROM journal GROUP BY currency").all();
  return { ok: !diffs.length, checkedAt: new Date().toISOString(), differences: diffs, journalTotalsByCurrency: totals };
}
const csv = rows => { if (!rows.length) return ''; const k = Object.keys(rows[0]); const q = v => { const s = String(v ?? ''); return /[",\n]/.test(s) || /^[=+\-@]/.test(s) ? '"' + (/^[=+\-@]/.test(s) ? "'" : '') + s.replace(/"/g, '""') + '"' : s; }; return [k.join(','), ...rows.map(r => k.map(c => q(r[c])).join(','))].join('\n'); };
module.exports = { userReport, adminSummary, reconcile, csv };
