const crypto = require('crypto');
const { need } = require('./lib');
const { audit } = require('./db');

const currentDocs = db => db.prepare('SELECT d.* FROM consent_docs d WHERE d.version=(SELECT MAX(version) FROM consent_docs WHERE type=d.type) ORDER BY d.required DESC, d.rowid').all();
const hash = body => crypto.createHash('sha256').update(body).digest('hex');

function status(db, userId) {
  const docs = currentDocs(db);
  const mine = db.prepare('SELECT doc_type, version, accepted_at FROM user_consents WHERE user_id=?').all(userId);
  const list = docs.map(d => { const a = mine.find(m => m.doc_type === d.type && m.version === d.version); return { type: d.type, version: d.version, title: d.title, body: d.body, required: !!d.required, accepted: !!a, acceptedAt: a?.accepted_at ?? null }; });
  return { documents: list, complete: list.filter(d => d.required).every(d => d.accepted) };
}
// Each consent is accepted individually and explicitly. Records are append-only.
function accept(db, user, items, ctx) {
  need(Array.isArray(items) && items.length, 'invalid_consents', 'Send the consents you accept');
  const docs = currentDocs(db);
  for (const it of items) {
    const d = docs.find(x => x.type === it.type); need(d, 'invalid_consent', `Unknown document ${it.type}`);
    need(it.accepted === true, 'consent_required', `You must actively accept: ${d.title}`);
    need(+it.version === d.version, 'consent_outdated', `${d.title} has been updated. Please read the new version.`, 409);
    if (db.prepare('SELECT 1 FROM user_consents WHERE user_id=? AND doc_type=? AND version=? AND context IS ?').get(user.id, d.type, d.version, it.context ?? null)) continue;
    db.prepare('INSERT INTO user_consents(user_id,doc_type,version,context,ip,ua,text_hash) VALUES(?,?,?,?,?,?,?)').run(user.id, d.type, d.version, it.context ?? null, ctx.ip ?? null, (ctx.ua || '').slice(0, 200), hash(d.body));
    audit(db, 'user:' + user.id, 'consent_accepted', { type: d.type, version: d.version });
  }
  return status(db, user.id);
}
module.exports = { currentDocs, status, accept };
