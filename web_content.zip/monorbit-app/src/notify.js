// In-app notifications. Email/SMS can be added by calling a provider here; messages never contain full bank details.
function notify(db, userId, type, title, body, ref) {
  try { db.prepare('INSERT OR IGNORE INTO notifications(user_id,type,title,body,ref) VALUES(?,?,?,?,?)').run(userId, type, title, body, ref ?? null); } catch (e) { console.error('notify failed', e.message); }
}
module.exports = { notify };
