// All money is stored as integer paisa (Rs 1 = 100 paisa). Never use floats for money.
const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, phone TEXT UNIQUE NOT NULL, email TEXT, name TEXT, cnic TEXT UNIQUE, dob TEXT,
  password_hash TEXT, phone_verified INTEGER NOT NULL DEFAULT 0,
  kyc_status TEXT NOT NULL DEFAULT 'none',            -- none | pending | verified | rejected
  status TEXT NOT NULL DEFAULT 'active', failed_logins INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0,
  defaults_flag INTEGER NOT NULL DEFAULT 0,           -- set by staff when a recorded payment default exists
  created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS sessions(
  id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires_at INTEGER NOT NULL,
  revoked INTEGER NOT NULL DEFAULT 0, ip TEXT, ua TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS otps(
  phone TEXT NOT NULL, purpose TEXT NOT NULL, code_hash TEXT NOT NULL, expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0, sent_at INTEGER NOT NULL, PRIMARY KEY(phone, purpose));
CREATE TABLE IF NOT EXISTS uploads(
  id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), kind TEXT NOT NULL, file TEXT,
  challenge_id TEXT, deleted INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS liveness_challenges(
  id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), actions TEXT NOT NULL,
  expires_at INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS kyc_submissions(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  front TEXT, back TEXT, selfie TEXT, name TEXT, cnic TEXT, dob TEXT,
  status TEXT NOT NULL,                                -- verified | review | rejected
  reason TEXT, provider_ref TEXT, reviewed_by TEXT, decided_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS bank_accounts(
  user_id INTEGER PRIMARY KEY REFERENCES users(id), holder_name TEXT NOT NULL, bank_name TEXT NOT NULL, account_type TEXT NOT NULL,
  iban_enc TEXT NOT NULL, iban_last4 TEXT NOT NULL, iban_hash TEXT NOT NULL,
  confirmed_at TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS bank_verifications(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  status TEXT NOT NULL,   -- information_required | verification_pending | verification_failed | under_review | eligible | not_eligible | approved
  provider TEXT, provider_ref TEXT, flags TEXT, result_enc TEXT, reason TEXT, reviewed_by TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS consent_docs(
  type TEXT NOT NULL, version INTEGER NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, required INTEGER NOT NULL DEFAULT 1,
  effective_at TEXT NOT NULL DEFAULT (datetime('now')), PRIMARY KEY(type, version));
CREATE TABLE IF NOT EXISTS user_consents(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), doc_type TEXT NOT NULL, version INTEGER NOT NULL,
  context TEXT, accepted_at TEXT NOT NULL DEFAULT (datetime('now')), ip TEXT, ua TEXT, text_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS plans(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, currency TEXT NOT NULL,   -- PKR | USD | XAU (gold, in milligrams)
  amount INTEGER NOT NULL, months INTEGER NOT NULL, frequency TEXT NOT NULL DEFAULT 'monthly',
  min_wait_months INTEGER NOT NULL DEFAULT 2, first_payout_month INTEGER NOT NULL DEFAULT 3,
  description TEXT, status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS slot_blocks(
  id INTEGER PRIMARY KEY, plan_id INTEGER NOT NULL REFERENCES plans(id), slot INTEGER NOT NULL,
  kind TEXT NOT NULL, note TEXT, UNIQUE(plan_id, slot));
CREATE TABLE IF NOT EXISTS committees(
  id INTEGER PRIMARY KEY, plan_id INTEGER NOT NULL REFERENCES plans(id),
  status TEXT NOT NULL DEFAULT 'open',                 -- open | running | completed
  start_date TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS memberships(
  id INTEGER PRIMARY KEY, committee_id INTEGER NOT NULL REFERENCES committees(id),
  user_id INTEGER NOT NULL REFERENCES users(id), slot INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_payment',      -- pending_payment | active | cancelled
  fee_snapshot TEXT,                                    -- fee rule agreed at enrolment; later rule changes never alter it
  reserved_until TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE UNIQUE INDEX IF NOT EXISTS uq_slot ON memberships(committee_id, slot) WHERE status<>'cancelled';
CREATE UNIQUE INDEX IF NOT EXISTS uq_member ON memberships(committee_id, user_id) WHERE status<>'cancelled';
CREATE TABLE IF NOT EXISTS instalments(
  id INTEGER PRIMARY KEY, membership_id INTEGER NOT NULL REFERENCES memberships(id), seq INTEGER NOT NULL,
  due_date TEXT NOT NULL, amount INTEGER NOT NULL, currency TEXT NOT NULL DEFAULT 'PKR',
  status TEXT NOT NULL DEFAULT 'due',                  -- due | overdue | paid | cancelled
  paid_at TEXT, payment_id INTEGER, UNIQUE(membership_id, seq));
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY, ref TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL REFERENCES users(id),
  purpose TEXT NOT NULL, target_id INTEGER, currency TEXT NOT NULL DEFAULT 'PKR',
  amount INTEGER NOT NULL, fee INTEGER NOT NULL DEFAULT 0, transfer INTEGER NOT NULL DEFAULT 0,
  discount INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL, method TEXT NOT NULL, card_type TEXT,
  denom_currency TEXT, denom_amount INTEGER,           -- e.g. gold milligrams the payment is for
  status TEXT NOT NULL,   -- scheduled | created | pending | awaiting_transfer | under_review | paid | failed | cancelled | reversed
  gateway_ref TEXT, receipt_upload TEXT, meta TEXT, idem_key TEXT, scheduled_for TEXT, mandate_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), paid_at TEXT, UNIQUE(user_id, idem_key));
CREATE TABLE IF NOT EXISTS ledger(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), currency TEXT NOT NULL DEFAULT 'PKR',
  amount INTEGER NOT NULL, balance_after INTEGER NOT NULL, kind TEXT NOT NULL, payment_id INTEGER, note TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS journal(
  id INTEGER PRIMARY KEY, payment_id INTEGER NOT NULL REFERENCES payments(id), currency TEXT NOT NULL,
  account TEXT NOT NULL,   -- contribution | service_fee | transfer_charge | discount
  amount INTEGER NOT NULL, reversal_of INTEGER, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS fee_rules(
  id INTEGER PRIMARY KEY, scope TEXT NOT NULL,         -- global | currency | plan
  currency TEXT, plan_id INTEGER, pct_bps INTEGER NOT NULL DEFAULT 0, fixed INTEGER NOT NULL DEFAULT 0,
  transfer_charge INTEGER NOT NULL DEFAULT 0, min_fee INTEGER NOT NULL DEFAULT 0, max_fee INTEGER, late_fee INTEGER NOT NULL DEFAULT 0,
  payer TEXT NOT NULL DEFAULT 'user', applies_to TEXT NOT NULL DEFAULT 'instalment',  -- instalment | enrollment | total
  effective_from TEXT NOT NULL, confirmed INTEGER NOT NULL DEFAULT 0, note TEXT, created_by TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS payout_accounts(
  user_id INTEGER PRIMARY KEY REFERENCES users(id), type TEXT NOT NULL, number TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS payouts(
  id INTEGER PRIMARY KEY, membership_id INTEGER UNIQUE NOT NULL REFERENCES memberships(id),
  user_id INTEGER NOT NULL REFERENCES users(id), amount INTEGER NOT NULL, currency TEXT NOT NULL DEFAULT 'PKR',
  status TEXT NOT NULL DEFAULT 'pending_approval',     -- pending_approval | sending | sent | failed
  account TEXT NOT NULL, gateway_ref TEXT, created_by TEXT, approved_by TEXT, settlement_note TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), sent_at TEXT);
CREATE TABLE IF NOT EXISTS gold_rates(
  id INTEGER PRIMARY KEY, rate_per_tola INTEGER NOT NULL, source TEXT NOT NULL DEFAULT 'manual',
  created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS gold_plans(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), tola REAL NOT NULL, months INTEGER NOT NULL,
  rate INTEGER NOT NULL, total INTEGER NOT NULL, down INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS gold_instalments(
  id INTEGER PRIMARY KEY, plan_id INTEGER NOT NULL REFERENCES gold_plans(id), seq INTEGER NOT NULL,
  amount INTEGER NOT NULL, due_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'due',
  paid_at TEXT, payment_id INTEGER, UNIQUE(plan_id, seq));
CREATE TABLE IF NOT EXISTS promos(
  code TEXT PRIMARY KEY, discount INTEGER NOT NULL, currency TEXT NOT NULL DEFAULT 'PKR', active INTEGER NOT NULL DEFAULT 1,
  max_uses INTEGER, used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), type TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL,
  ref TEXT, read INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE UNIQUE INDEX IF NOT EXISTS uq_notif ON notifications(user_id, type, ref) WHERE ref IS NOT NULL;
CREATE TABLE IF NOT EXISTS disputes(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), type TEXT NOT NULL, ref TEXT, message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open', response TEXT, resolved_by TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), resolved_at TEXT);
CREATE TABLE IF NOT EXISTS mandates(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), membership_id INTEGER NOT NULL REFERENCES memberships(id),
  currency TEXT NOT NULL, funding_label TEXT NOT NULL, provider_ref TEXT, frequency TEXT NOT NULL DEFAULT 'monthly',
  day_of_month INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'active',   -- active | cancelled | failed
  consent_version INTEGER NOT NULL, authorized_at TEXT NOT NULL DEFAULT (datetime('now')), cancelled_at TEXT, fail_count INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS admin_users(
  id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL, password_hash TEXT NOT NULL,
  role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, failed_logins INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS admin_sessions(
  id TEXT PRIMARY KEY, admin_id INTEGER NOT NULL REFERENCES admin_users(id), expires_at INTEGER NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS settings(
  key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_by TEXT, updated_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY, actor TEXT NOT NULL, action TEXT NOT NULL, detail TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE INDEX IF NOT EXISTS idx_pay_user ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_inst_due ON instalments(status, due_date);
CREATE INDEX IF NOT EXISTS idx_ledger_user ON ledger(user_id, currency);
CREATE INDEX IF NOT EXISTS idx_journal_pay ON journal(payment_id);
-- Financial records are append-only: corrections are made with reversal entries, never edits.
CREATE TRIGGER IF NOT EXISTS ledger_no_update BEFORE UPDATE ON ledger BEGIN SELECT RAISE(ABORT,'ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS ledger_no_delete BEFORE DELETE ON ledger BEGIN SELECT RAISE(ABORT,'ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS journal_no_update BEFORE UPDATE ON journal BEGIN SELECT RAISE(ABORT,'journal is append-only'); END;
CREATE TRIGGER IF NOT EXISTS journal_no_delete BEFORE DELETE ON journal BEGIN SELECT RAISE(ABORT,'journal is append-only'); END;
CREATE TRIGGER IF NOT EXISTS consent_no_update BEFORE UPDATE ON user_consents BEGIN SELECT RAISE(ABORT,'consent records are append-only'); END;
CREATE TRIGGER IF NOT EXISTS consent_no_delete BEFORE DELETE ON user_consents BEGIN SELECT RAISE(ABORT,'consent records are append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit BEGIN SELECT RAISE(ABORT,'audit log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit BEGIN SELECT RAISE(ABORT,'audit log is append-only'); END;
`;

function open(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
  db.exec(SCHEMA);
  seed(db);
  return db;
}

function seed(db) {
  if (!db.prepare('SELECT COUNT(*) c FROM plans').get().c) {
    const ins = db.prepare('INSERT INTO plans(name,currency,amount,months,description) VALUES(?,?,?,?,?)');
    [['PKR 5,000 monthly', 'PKR', 500000, 10], ['PKR 10,000 monthly', 'PKR', 1000000, 12], ['PKR 25,000 monthly', 'PKR', 2500000, 10], ['PKR 1 lakh monthly', 'PKR', 10000000, 12],
     ['USD 50 monthly', 'USD', 5000, 10], ['USD 100 monthly', 'USD', 10000, 12], ['USD 250 monthly', 'USD', 25000, 10],
     ['Digital gold 1 g monthly', 'XAU', 1000, 10], ['Digital gold 2 g monthly', 'XAU', 2000, 12]]
      .forEach(([n, c, a, m]) => ins.run(n, c, a, m, 'Sample plan. Edit or replace in the admin panel.'));
  }
  if (!db.prepare('SELECT COUNT(*) c FROM gold_rates').get().c)
    db.prepare("INSERT INTO gold_rates(rate_per_tola,source) VALUES(?,?)").run(412000 * 100, 'sample (set a real rate in the admin panel)');
  if (!db.prepare('SELECT COUNT(*) c FROM fee_rules').get().c) {   // WORKING PROPOSAL ONLY: the business owner must confirm before launch
    const f = db.prepare("INSERT INTO fee_rules(scope,currency,pct_bps,late_fee,applies_to,effective_from,confirmed,note,created_by) VALUES(?,?,?,?,'instalment','2000-01-01',0,?,'system')");
    f.run('global', null, 100, 0, 'Working proposal: 1% per instalment. NOT confirmed by the business owner.');
    f.run('currency', 'PKR', 100, 50000, 'Working proposal: 1% per instalment, Rs 500 late fee. NOT confirmed by the business owner.');
  }
  db.prepare("INSERT OR IGNORE INTO promos(code,discount,currency) VALUES('JAMA100',10000,'PKR')").run();
  db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES('eligibility',?)").run(JSON.stringify({ requireIdentity: true, maxOverdueInstalments: 0, blockOnDefaultFlag: true, autoApprove: true }));
  db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES('currencies',?)").run(JSON.stringify(['PKR', 'USD', 'XAU']));
  const doc = db.prepare('INSERT OR IGNORE INTO consent_docs(type,version,title,body,required) VALUES(?,?,?,?,?)');
  const NOTE = '\n\n[Draft template. Must be reviewed and approved by qualified legal counsel before launch.]';
  [
    ['terms', 'Terms and conditions', 'These terms govern your use of the app and your participation in committees. A committee is a group in which members pay a fixed contribution each period and each member receives the pooled amount in their chosen payout slot. You agree to pay every contribution on time, to give accurate information, and to follow the committee schedule you chose. The service is not a bank and is not guaranteed by any bank or by the State Bank of Pakistan unless we state this in writing.', 1],
    ['privacy', 'Privacy policy and data processing', 'We collect your name, phone number, identity document images, selfie, bank account details and payment records to run committees, verify who you are, prevent fraud and meet legal duties. We share them only with approved verification, payment and banking providers and with authorities when the law requires. Sensitive data is encrypted, access is restricted and logged, and identity images are deleted after the retention period set out in our retention policy. You may ask us to correct your data.', 1],
    ['identity_verification', 'Identity verification', 'I authorize the application and its approved service providers to verify the identity information, identity document photos and live selfie I have submitted, subject to the applicable terms and privacy policy. I understand a verification result may require manual review.', 1],
    ['bank_verification', 'Bank information verification', 'I authorize the application and its approved service providers to verify the bank account information I have submitted with the relevant financial institutions or approved verification providers, and to assess my eligibility using the criteria disclosed to me, subject to the applicable terms and privacy policy. I understand I can ask for a review of any decision.', 1],
    ['fees_payouts', 'Fees, payment schedules and payout rules', 'Service fees and transfer charges are shown before every payment and are fixed for your committee at the time you enrol; later fee changes apply only to new enrolments. Contributions are due on the scheduled dates. Late payments may carry a late fee shown in the committee rules. Payouts are made to your payout account in your chosen slot only after all members have paid for that period and after staff approval. Digital gold committees are valued using the price and timestamp shown at the time of each payment; unless the provider and custody arrangements state otherwise, gold is not physically owned or allocated to you.', 1],
    ['disputes_refunds', 'Disputes, cancellation, refunds and missed payments', 'You can raise a dispute in the app about a decision, a payment or a deduction. We aim to respond within the period stated in the app. Cancelling a committee after enrolment may be limited because other members rely on your contributions; the cancellation and refund terms of your committee are shown before you enrol. Missed payments may lead to late fees, a recorded default and loss of eligibility for future committees, after you have had a chance to respond.', 1],
    ['recurring_authorization', 'Automatic deduction authorization', 'I authorize recurring deductions for the committee instalment shown on this screen, plus the fees shown, on the scheduled date each period, from the funding source I selected. I can cancel this authorization at any time in the app; cancellation takes effect before the next scheduled deduction if made at least one business day earlier. If a deduction fails I will be notified and the instalment stays payable. I can dispute an incorrect deduction in the app.', 0],
  ].forEach(([t, title, body, req]) => doc.run(t, 1, title, body + NOTE, req));
}

// Run fn inside one atomic transaction (all-or-nothing)
function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
}
const audit = (db, actor, action, detail) =>
  db.prepare('INSERT INTO audit(actor,action,detail) VALUES(?,?,?)').run(actor, action, detail ? JSON.stringify(detail) : null);

module.exports = { open, tx, audit };
