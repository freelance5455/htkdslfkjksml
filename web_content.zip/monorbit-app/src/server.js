const http = require('http');
const cfg = require('./config');
const { HttpError, rateLimit } = require('./lib');
const auth = require('./auth');
const { open } = require('./db');

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', c => { size += c.length; if (size > limit) { reject(new HttpError(413, 'payload_too_large', 'Request body too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function createServer({ db } = {}) {
  db = db || open(cfg.dbFile);
  const bootstrap = require('./auth').bootstrapAdmin(db);
  const routes = require('./routes')(db);

  const server = http.createServer(async (req, res) => {
    const origin = req.headers.origin;
    const allow = cfg.corsOrigins.includes('*') ? '*' : cfg.corsOrigins.includes(origin) ? origin : null;
    const base = {
      'x-content-type-options': 'nosniff', 'x-frame-options': 'DENY', 'referrer-policy': 'no-referrer',
      ...(cfg.isProd ? { 'strict-transport-security': 'max-age=31536000; includeSubDomains' } : {}),
      ...(allow ? { 'access-control-allow-origin': allow, 'access-control-allow-headers': 'authorization,content-type,x-signature', 'access-control-allow-methods': 'GET,POST,PUT,OPTIONS' } : {}),
    };
    const send = (status, body, headers = {}) => {
      const isBuf = Buffer.isBuffer(body);
      res.writeHead(status, { ...base, ...(isBuf ? {} : { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }), ...headers });
      res.end(status === 204 ? undefined : isBuf ? body : JSON.stringify(body));
    };
    try {
      if (req.method === 'OPTIONS') return send(204);
      const ip = req.socket.remoteAddress || 'unknown';
      if (!rateLimit('ip:' + ip, 600, 60000)) throw new HttpError(429, 'rate_limited', 'Too many requests');
      const url = new URL(req.url, 'http://localhost');
      let route, params = {};
      for (const r of routes) {
        if (r.method !== req.method) continue;
        const m = url.pathname.match(r.regex); if (!m) continue;
        route = r; r.keys.forEach((k, i) => params[k] = decodeURIComponent(m[i + 1])); break;
      }
      if (!route) throw new HttpError(404, 'not_found', 'Route not found');

      let user = null, jti = null, admin = null;
      const bearer = (req.headers.authorization || '').replace(/^Bearer /, '');
      if (route.opts.auth === 'user') { const a = auth.authenticate(db, bearer); user = a.user; jti = a.jti; }
      else if (route.opts.auth === 'admin') {
        const a = auth.adminAuthenticate(db, bearer); admin = a.admin; jti = a.jti;
        const need = [].concat(route.opts.perm || []);
        if (need.length && !need.some(p => auth.can(admin.role, p))) throw new HttpError(403, 'forbidden', 'Your role does not allow this action');
        if (!rateLimit('admin:' + admin.id, 240, 60000)) throw new HttpError(429, 'rate_limited');
      }

      let raw = Buffer.alloc(0), body = {};
      if (req.method === 'POST' || req.method === 'PUT') {
        raw = await readBody(req, route.opts.limit || 100 * 1024);
        if (raw.length && !route.opts.raw) { try { body = JSON.parse(raw.toString()); } catch { throw new HttpError(400, 'invalid_json', 'Body must be valid JSON'); } }
        if (body === null || typeof body !== 'object' || Array.isArray(body)) body = {};
      }
      const out = await route.handler({ db, req, user, jti, admin, params, query: url.searchParams, body, raw, ip, ua: req.headers['user-agent'] || '' });
      if (out && out.__raw) return send(out.status, out.body, out.headers);
      if (out && out.__status) return send(out.__status, out.body);
      return send(200, out === undefined ? { ok: true } : out);
    } catch (e) {
      if (e instanceof HttpError) return send(e.status, { error: { code: e.code, message: e.message, ...(e.extra || {}) } });
      if (e && /UNIQUE constraint/.test(e.message || '')) return send(409, { error: { code: 'conflict', message: 'That already exists' } });
      console.error('Unhandled error:', e);
      return send(500, { error: { code: 'server_error', message: 'Something went wrong' } });
    }
  });
  server.db = db; server.bootstrap = bootstrap;
  return server;
}
module.exports = { createServer };
