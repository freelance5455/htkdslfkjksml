// Configurable fee rules. Rules are never edited: staff add a new rule with an effective date.
// A membership stores a snapshot of the rule at enrolment so later changes never alter agreed charges.
const { HttpError, need } = require('./lib');

const FIELDS = ['id', 'scope', 'currency', 'plan_id', 'pct_bps', 'fixed', 'transfer_charge', 'min_fee', 'max_fee', 'late_fee', 'payer', 'applies_to', 'effective_from', 'confirmed'];
const snap = r => Object.fromEntries(FIELDS.map(k => [k, r[k] ?? null]));

function effectiveRule(db, { planId, currency, at }) {
  const d = at || new Date().toISOString().slice(0, 10);
  const q = (where, ...p) => db.prepare(`SELECT * FROM fee_rules WHERE ${where} AND effective_from<=? ORDER BY effective_from DESC, id DESC LIMIT 1`).get(...p, d);
  return (planId && q("scope='plan' AND plan_id=?", planId)) || q("scope='currency' AND currency=?", currency) || q("scope='global'") || null;
}
const clamp = (v, r) => { let x = v; if (r.min_fee && x < r.min_fee) x = r.min_fee; if (r.max_fee != null && x > r.max_fee) x = r.max_fee; return x; };

// kind: 'join' | 'instalment' | 'topup' | 'gold' | 'gold_instalment'
function computeLines(rule, { kind, base, planTotal, method, overdue }) {
  const lines = []; let fee = 0, transfer = 0;
  if (rule && (kind === 'join' || kind === 'instalment')) {
    let svc = 0;
    const applies = rule.applies_to === 'instalment' || (rule.applies_to === 'enrollment' && kind === 'join') || (rule.applies_to === 'total' && kind === 'join');
    if (applies) { const b = rule.applies_to === 'total' ? planTotal : base; svc = clamp(Math.round(b * rule.pct_bps / 10000) + rule.fixed, rule); }
    if (svc > 0) {
      const covered = rule.payer === 'company';
      lines.push({ code: 'service_fee', label: covered ? 'Service fee (paid by the company)' : 'Service fee', amount: covered ? 0 : svc, ...(covered ? { waived: svc } : {}) });
      fee += covered ? 0 : svc;
    }
    if (overdue && rule.late_fee) { lines.push({ code: 'late_fee', label: 'Late fee', amount: rule.late_fee }); fee += rule.late_fee; }
  }
  if (rule && rule.transfer_charge && method !== 'wallet' && ['join', 'instalment', 'topup'].includes(kind)) {
    const covered = rule.payer === 'company';
    lines.push({ code: 'transfer_charge', label: covered ? 'Transfer charge (paid by the company)' : 'Transfer charge', amount: covered ? 0 : rule.transfer_charge });
    transfer += covered ? 0 : rule.transfer_charge;
  }
  return { lines, fee, transfer };
}

function addRule(db, b, actor) {
  need(['global', 'currency', 'plan'].includes(b.scope), 'invalid_scope');
  need(Number.isInteger(b.pctBps) && b.pctBps >= 0 && b.pctBps <= 2000, 'invalid_pct', 'Percentage must be between 0 and 20% (in basis points: 100 = 1%)');
  const ints = { fixed: b.fixed ?? 0, transferCharge: b.transferCharge ?? 0, minFee: b.minFee ?? 0, lateFee: b.lateFee ?? 0 };
  for (const [k, v] of Object.entries(ints)) need(Number.isInteger(v) && v >= 0, 'invalid_amount', `${k} must be a whole number of minor units`);
  need(b.maxFee == null || (Number.isInteger(b.maxFee) && b.maxFee >= ints.minFee), 'invalid_max');
  need(['user', 'company'].includes(b.payer || 'user'), 'invalid_payer');
  need(['instalment', 'enrollment', 'total'].includes(b.appliesTo || 'instalment'), 'invalid_applies_to');
  need(/^\d{4}-\d{2}-\d{2}$/.test(b.effectiveFrom || ''), 'invalid_date', 'Effective date must be YYYY-MM-DD');
  need(b.effectiveFrom >= new Date().toISOString().slice(0, 10), 'past_date', 'The effective date cannot be in the past', 400);
  let currency = null, planId = null;
  if (b.scope === 'currency') { need(['PKR', 'USD', 'XAU'].includes(b.currency), 'invalid_currency'); currency = b.currency; }
  if (b.scope === 'plan') { const p = db.prepare('SELECT * FROM plans WHERE id=?').get(+b.planId); need(p, 'not_found', 'Plan not found', 404); planId = p.id; currency = p.currency; }
  const hasAmounts = ints.fixed || ints.transferCharge || ints.minFee || ints.lateFee || b.maxFee != null;
  need(!(hasAmounts && !currency), 'currency_required', 'Fixed amounts, charges, minimum, maximum and late fees need a currency or plan scope');
  const id = db.prepare('INSERT INTO fee_rules(scope,currency,plan_id,pct_bps,fixed,transfer_charge,min_fee,max_fee,late_fee,payer,applies_to,effective_from,confirmed,note,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(b.scope, currency, planId, b.pctBps, ints.fixed, ints.transferCharge, ints.minFee, b.maxFee ?? null, ints.lateFee, b.payer || 'user', b.appliesTo || 'instalment', b.effectiveFrom, b.confirmed ? 1 : 0, b.note ?? null, actor).lastInsertRowid;
  return Number(id);
}
module.exports = { effectiveRule, computeLines, snap, addRule };
