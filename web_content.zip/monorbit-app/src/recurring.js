// Automatic deductions. Only available when an authorised recurring-payment provider is configured.
// A signed consent alone does NOT enable deductions from a bank account: a provider/bank mandate is required.
const { HttpError, need, todayIso } = require('./lib');
const { tx, audit } = require('./db');
const providers = require('./providers');
const consent = require('./consent');
const { notify } = require('./notify');
const S = require('./services');

const available = () => !!providers.recurring.supported;
function explain(db, membershipId) {
  const m = db.prepare("SELECT m.*, pl.name, pl.currency FROM memberships m JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE m.id=?").get(membershipId);
  return { available: available(), sandbox: !!providers.recurring.sandbox, committee: m?.name, currency: m?.currency,
    amount: 'Each instalment amount plus the service fee and transfer charge shown on your payment screen (fixed for your committee at enrolment).',
    frequency: 'Monthly', date: 'On the instalment due date shown in your schedule (the 5th of each month unless your committee says otherwise)',
    failure: 'If a deduction fails you are notified, the instalment stays payable, and a late fee may apply. After 3 failed deductions the authorization is suspended.',
    cancel: 'Cancel any time in the app. Cancellation takes effect before the next deduction if made at least one business day earlier.',
    dispute: 'Dispute an incorrect deduction in the app under Help and disputes.' };
}
function create(db, user, b) {
  need(available(), 'recurring_unavailable', 'Automatic deductions are not available yet. Please pay each instalment manually.', 501);
  const m = db.prepare("SELECT m.* FROM memberships m WHERE m.id=? AND m.user_id=? AND m.status='active'").get(+b.membershipId, user.id); need(m, 'not_found', 'Active membership not found', 404);
  need(!db.prepare("SELECT 1 FROM mandates WHERE membership_id=? AND status='active'").get(m.id), 'mandate_exists', 'Automatic deductions are already active for this committee', 409);
  const label = String(b.fundingLabel || '').trim(); need(label.length >= 3 && label.length <= 60 && !/\d{9,}/.test(label.replace(/[\s-]/g, '')), 'invalid_funding_label', 'Describe the funding source without full card or account numbers (for example "Debit card ending 4242")');
  const docs = consent.status(db, user.id).documents.find(d => d.type === 'recurring_authorization');
  need(b.consent === true && +b.consentVersion === docs.version, 'consent_required', 'You must accept the automatic deduction authorization', 400);
  consent.accept(db, user, [{ type: 'recurring_authorization', version: docs.version, accepted: true, context: 'membership:' + m.id }], b.ctx || {});
  const inst = db.prepare("SELECT due_date FROM instalments WHERE membership_id=? ORDER BY seq LIMIT 1 OFFSET 1").get(m.id);
  return providers.recurring.createMandate({ userId: user.id, membershipId: m.id, fundingLabel: label }).then(r => {
    const cur = db.prepare('SELECT pl.currency FROM committees c JOIN plans pl ON pl.id=c.plan_id WHERE c.id=?').get(m.committee_id).currency;
    const id = db.prepare('INSERT INTO mandates(user_id,membership_id,currency,funding_label,provider_ref,day_of_month,consent_version) VALUES(?,?,?,?,?,?,?)').run(user.id, m.id, cur, label, r.providerRef, inst ? +inst.due_date.slice(8, 10) : 5, docs.version).lastInsertRowid;
    audit(db, 'user:' + user.id, 'mandate_created', { mandateId: Number(id), membershipId: m.id });
    return view(db.prepare('SELECT * FROM mandates WHERE id=?').get(id));
  });
}
const view = m => ({ id: m.id, membershipId: m.membership_id, currency: m.currency, fundingSource: m.funding_label, frequency: m.frequency, dayOfMonth: m.day_of_month, status: m.status, authorizedAt: m.authorized_at, cancelledAt: m.cancelled_at });
const list = (db, uid) => db.prepare('SELECT * FROM mandates WHERE user_id=? ORDER BY id DESC').all(uid).map(view);
async function cancel(db, user, id) {
  const m = db.prepare('SELECT * FROM mandates WHERE id=? AND user_id=?').get(+id, user.id); need(m, 'not_found', 'Not found', 404); need(m.status === 'active', 'not_active', 'Already cancelled', 409);
  if (available()) await providers.recurring.cancel({ providerRef: m.provider_ref });
  tx(db, () => {
    db.prepare("UPDATE mandates SET status='cancelled', cancelled_at=datetime('now') WHERE id=?").run(m.id);
    db.prepare("UPDATE payments SET status='cancelled' WHERE mandate_id=? AND status='scheduled'").run(m.id);
    audit(db, 'user:' + user.id, 'mandate_cancelled', { mandateId: m.id });
  });
  notify(db, user.id, 'mandate_cancelled', 'Automatic deductions cancelled', 'No further automatic deductions will be taken for this committee.', 'mnd-c-' + m.id);
  return view(db.prepare('SELECT * FROM mandates WHERE id=?').get(m.id));
}
// Daily job: schedule the next instalment of every active mandate, then run the ones that are due.
async function run(db) {
  if (!available()) return { scheduled: 0, charged: 0 };
  let scheduled = 0, charged = 0; const t = todayIso();
  for (const m of db.prepare("SELECT * FROM mandates WHERE status='active'").all()) {
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(m.user_id);
    const inst = db.prepare("SELECT * FROM instalments WHERE membership_id=? AND status IN ('due','overdue') ORDER BY seq LIMIT 1").get(m.membership_id);
    if (!inst || inst.due_date > new Date(Date.parse(t) + 3 * 864e5).toISOString().slice(0, 10)) continue;
    if (db.prepare("SELECT 1 FROM payments WHERE purpose='instalment' AND target_id=? AND status IN ('scheduled','pending')").get(inst.id)) continue;
    let o; try { o = S.buildOrder(db, user, { purpose: 'instalment', targetId: inst.id, method: 'bank' }); } catch { continue; }
    const ref = 'MO-' + require('crypto').randomBytes(4).toString('hex').toUpperCase();
    db.prepare("INSERT INTO payments(ref,user_id,purpose,target_id,currency,amount,fee,transfer,discount,total,method,denom_currency,denom_amount,status,meta,scheduled_for,mandate_id) VALUES(?,?,?,?,?,?,?,?,?,?,'recurring',?,?,'scheduled',?,?,?)")
      .run(ref, user.id, 'instalment', inst.id, o.currency, o.base, o.fee, o.transfer, 0, o.total, o.denom?.currency ?? null, o.denom?.amount ?? null, JSON.stringify({ ...o.meta, lines: o.lines }), inst.due_date, m.id);
    scheduled++;
  }
  for (const p of db.prepare("SELECT * FROM payments WHERE status='scheduled' AND scheduled_for<=? AND mandate_id IS NOT NULL").all(t)) {
    const m = db.prepare('SELECT * FROM mandates WHERE id=?').get(p.mandate_id);
    try { const r = await providers.recurring.charge({ mandate: m, paymentRef: p.ref, amount: p.total, currency: p.currency }); db.prepare("UPDATE payments SET status='pending', gateway_ref=? WHERE id=?").run(r.gatewayRef, p.id); charged++; }
    catch { S.markFailed(db, p.ref); }
  }
  return { scheduled, charged };
}
module.exports = { available, explain, create, list, cancel, run, view };
