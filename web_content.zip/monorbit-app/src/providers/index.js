/*
 * Provider adapters. Every outside service sits behind a small interface so real vendors can be
 * connected without touching business logic.
 *
 * IMPORTANT: nothing here pretends a verification succeeded.
 *   - kyc / liveness / bank: the default "manual" providers send every case to the staff review queue.
 *     A staff member with the right role makes the decision. Replace with a real vendor (for example a
 *     NADRA-authorised identity partner, or a State Bank of Pakistan / bank verification service) ONLY
 *     once you have confirmed you are authorised to use it and hold the credentials.
 *   - payments / payouts: "mock" is a development sandbox. It never reports success by itself: payments stay
 *     pending until a signed callback arrives (in development a developer button posts that callback).
 *     The server refuses to start in production while a mock or sandbox provider is selected.
 *   - recurring: "none" means automatic deductions are NOT offered. "sandbox" exists for development only.
 *
 * Interfaces:
 *   sms.send(phone, text)                                -> Promise<void>
 *   kyc.submit({name,cnic,dob,images})                   -> Promise<{status:'verified'|'review'|'rejected', ref, reason?}>
 *   liveness.check({image, challenge})                   -> Promise<{status:'passed'|'review'|'failed', ref}>
 *   bank.submit({holder, bank, iban, cnic})              -> Promise<{status:'pending'|'verified'|'failed', ref, result?}>
 *   gateways.card.initiate(payment, input)               -> Promise<{gatewayRef, action, redirectUrl?}>
 *   gateways.card.verifyWebhook(raw, sig) / parseWebhook(body)
 *   recurring.supported / createMandate(...) / charge(...) / cancel(...)
 *   payouts.send({account, amount, currency, ref})       -> Promise<{ok, gatewayRef, error?}>
 *   goldPrice.get(db)                                    -> {ratePerTola, source, at}
 */
const crypto = require('crypto');
const cfg = require('../config');
const { HttpError, safeEq, normMobile } = require('../lib');

const log = (...a) => { if (!cfg.quiet) console.log('[provider]', ...a); };
const ref = () => 'MANUAL-' + crypto.randomBytes(4).toString('hex');

const sms = { mock: { async send(phone, text) { log(`SMS to ${phone}: ${text}`); } } };
const kyc = { manual: { async submit() { return { status: 'review', ref: ref() }; } } };
const liveness = { manual: { async check() { return { status: 'review', ref: ref() }; } } };
const bank = { manual: { async submit() { return { status: 'pending', ref: ref() }; } } };

function sandboxGateway(name) {
  return {
    name,
    async initiate(payment, input) {
      if ((name === 'jazz' || name === 'easy') && !normMobile(input.mobile)) throw new HttpError(400, 'invalid_mobile', 'Enter a valid account mobile number');
      return {
        gatewayRef: name.toUpperCase() + '-' + crypto.randomBytes(5).toString('hex'),
        action: name === 'card' ? 'redirect_checkout' : 'approve_on_phone',
        redirectUrl: name === 'card' ? `https://gateway.example/checkout/${payment.ref}` : undefined,
      };
    },
    verifyWebhook(raw, sig) {
      const expect = crypto.createHmac('sha256', cfg.gatewaySecret).update(raw).digest('hex');
      return safeEq(expect, String(sig || ''));
    },
    parseWebhook(body) { return { ref: String(body.ref || ''), gatewayRef: body.gatewayRef || null, success: body.status === 'success' }; },
  };
}
const gateways = { jazz: sandboxGateway('jazz'), easy: sandboxGateway('easy'), card: sandboxGateway('card'), recurring: sandboxGateway('recurring') };

const recurring = {
  none: { supported: false },
  sandbox: {
    supported: true, sandbox: true,
    async createMandate() { return { providerRef: 'MND-' + crypto.randomBytes(5).toString('hex') }; },
    async charge() { return { gatewayRef: 'RCH-' + crypto.randomBytes(5).toString('hex'), status: 'pending' }; },
    async cancel() { return { ok: true }; },
  },
};

const payouts = {
  mock: { async send({ account, amount, currency, ref: r }) { log(`PAYOUT ${amount} ${currency} to ${account} (${r})`); return { ok: true, gatewayRef: 'PO-' + crypto.randomBytes(5).toString('hex') }; } },
};
const goldPrice = {
  manual: { get(db) { const r = db.prepare('SELECT rate_per_tola r, source, created_at at FROM gold_rates ORDER BY id DESC LIMIT 1').get(); return { ratePerTola: r.r, source: r.source, at: r.at }; } },
};

const pick = (table, name, label) => { if (!table[name]) throw new Error(`Unknown ${label} provider "${name}". Add it in src/providers/index.js`); return table[name]; };
module.exports = {
  sms: pick(sms, cfg.providers.sms, 'SMS'),
  kyc: pick(kyc, cfg.providers.kyc, 'KYC'),
  liveness: pick(liveness, cfg.providers.liveness, 'liveness'),
  bank: pick(bank, cfg.providers.bank, 'bank verification'),
  gateways,
  recurring: pick(recurring, cfg.providers.recurring, 'recurring'),
  payouts: payouts.mock,
  goldPrice: pick(goldPrice, cfg.providers.gold, 'gold price'),
  signWebhook: raw => crypto.createHmac('sha256', cfg.gatewaySecret).update(raw).digest('hex'),
};
