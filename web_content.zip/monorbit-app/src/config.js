const e = process.env;
const cfg = {
  isProd: e.NODE_ENV === 'production',
  port: +e.PORT || 3000,
  dbFile: e.DB_FILE || './data/jama.db',
  uploadDir: e.UPLOAD_DIR || './data/uploads',
  jwtSecret: e.JWT_SECRET || 'dev-jwt-secret-change-me',
  gatewaySecret: e.GATEWAY_WEBHOOK_SECRET || 'dev-gateway-secret',
  otpLength: +e.OTP_LENGTH || 4,
  otpCooldownSec: e.OTP_COOLDOWN_SEC !== undefined ? +e.OTP_COOLDOWN_SEC : 30,
  goldDownRate: 0.2,
  bankEncKey: e.BANK_ENC_KEY || 'dev-bank-encryption-key-change-me-32bytes!',
  retentionDays: +e.IMAGE_RETENTION_DAYS || 30,        // identity images are deleted this long after a decision
  sessionDays: +e.SESSION_DAYS || 7,
  adminBootstrapEmail: e.ADMIN_BOOTSTRAP_EMAIL || '',
  adminBootstrapPassword: e.ADMIN_BOOTSTRAP_PASSWORD || '',
  reserveMinutes: 20,
  corsOrigins: (e.CORS_ORIGINS || '*').split(',').map(s => s.trim()),
  quiet: !!e.QUIET,
  providers: { sms: e.SMS_PROVIDER || 'mock', kyc: e.KYC_PROVIDER || 'manual', liveness: e.LIVENESS_PROVIDER || 'manual', bank: e.BANK_VERIFY_PROVIDER || 'manual', payments: e.PAYMENT_PROVIDER || 'mock', recurring: e.RECURRING_PROVIDER || 'none', gold: e.GOLD_PRICE_PROVIDER || 'manual' },
  bank: {
    name: e.BANK_NAME || 'Sample Bank Ltd',
    title: e.BANK_ACCOUNT_TITLE || 'Monorbit Savings (Pvt) Ltd',
    iban: e.BANK_IBAN || 'PK00SAMP0000000000000000',
  },
};
if (cfg.isProd) {
  const weak = [['BANK_ENC_KEY', cfg.bankEncKey.startsWith('dev-')], ['JWT_SECRET', cfg.jwtSecret.startsWith('dev-')], ['GATEWAY_WEBHOOK_SECRET', cfg.gatewaySecret.startsWith('dev-')]];
  const bad = weak.filter(w => w[1]).map(w => w[0]);
  if (bad.length) { console.error('Refusing to start in production with default secrets: ' + bad.join(', ')); process.exit(1); }
  if (['mock', 'sandbox'].some(m => Object.values(cfg.providers).includes(m))) { console.error('Refusing to start in production with mock/sandbox providers (SMS, payments, recurring). Implement real adapters in src/providers. Manual-review providers are allowed.'); process.exit(1); }
}
module.exports = cfg;
