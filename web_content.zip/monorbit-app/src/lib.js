const crypto = require('crypto');

class HttpError extends Error {
  constructor(status, code, message, extra) { super(message || code); this.status = status; this.code = code; this.extra = extra; }
}
const need = (cond, code, message, status = 400) => { if (!cond) throw new HttpError(status, code, message); };
const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };

function signJwt(payload, secret, ttlSec) {
  const h = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const p = Buffer.from(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + ttlSec })).toString('base64url');
  const s = crypto.createHmac('sha256', secret).update(h + '.' + p).digest('base64url');
  return `${h}.${p}.${s}`;
}
function verifyJwt(token, secret) {
  const [h, p, s] = String(token || '').split('.');
  if (!h || !p || !s) throw new HttpError(401, 'invalid_token');
  const expect = crypto.createHmac('sha256', secret).update(h + '.' + p).digest('base64url');
  if (!safeEq(expect, s)) throw new HttpError(401, 'invalid_token');
  let pl; try { pl = JSON.parse(Buffer.from(p, 'base64url').toString()); } catch { throw new HttpError(401, 'invalid_token'); }
  if (!pl.exp || pl.exp < Date.now() / 1000) throw new HttpError(401, 'token_expired');
  return pl;
}

// Pakistani mobile: 03XXXXXXXXX, 3XXXXXXXXX, 923XXXXXXXXX, +923XXXXXXXXX -> +923XXXXXXXXX
function normPhone(v) {
  const s = String(v || '').replace(/[\s-]/g, '');
  const m = s.match(/^(?:\+92|92|0)?(3\d{9})$/);
  return m ? '+92' + m[1] : null;
}
function normMobile(v) { const s = String(v || '').replace(/[\s-]/g, ''); const m = s.match(/^(?:\+92|92|0)?(3\d{9})$/); return m ? '0' + m[1] : null; }
function normCnic(v) { const d = String(v || '').replace(/\D/g, ''); return d.length === 13 ? d : null; }
function normIban(v) { const s = String(v || '').replace(/\s/g, '').toUpperCase(); return /^PK\d{2}[A-Z]{4}\d{16}$/.test(s) ? s : null; }

const pad = n => String(n).padStart(2, '0');
function addMonths(isoDate, n) { const [y, m, d0] = isoDate.split('-').map(Number); const d = Math.min(d0, 28); const dt = new Date(Date.UTC(y, m - 1 + n, 1)); return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(d)}`; }
function nextMonthDay(day = 5) { const n = new Date(); const dt = new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth() + 1, 1)); return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(day)}`; }
const todayIso = () => new Date().toISOString().slice(0, 10);

// Minimal in-memory sliding-window limiter (use Redis when you run more than one server)
const hits = new Map();
function rateLimit(key, max, windowMs) {
  const now = Date.now(); const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
  if (arr.length >= max) { hits.set(key, arr); return false; }
  arr.push(now); hits.set(key, arr); return true;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) { const f = v.filter(t => now - t < 600000); f.length ? hits.set(k, f) : hits.delete(k); } }, 300000).unref();

/* ---- passwords (scrypt) and field encryption (AES-256-GCM) ---- */
const cfg = require('./config');
function hashPassword(pw) { const salt = crypto.randomBytes(16); const h = crypto.scryptSync(pw, salt, 64); return `s1$${salt.toString('base64')}$${h.toString('base64')}`; }
function checkPassword(pw, stored) {
  const [v, s, h] = String(stored || '').split('$'); if (v !== 's1' || !s || !h) return false;
  const calc = crypto.scryptSync(String(pw), Buffer.from(s, 'base64'), 64); const exp = Buffer.from(h, 'base64');
  return calc.length === exp.length && crypto.timingSafeEqual(calc, exp);
}
function validPassword(pw) { return typeof pw === 'string' && pw.length >= 8 && pw.length <= 128 && /[A-Za-z]/.test(pw) && /\d/.test(pw); }
const encKey = () => crypto.createHash('sha256').update(cfg.bankEncKey).digest();
function encrypt(text) { const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', encKey(), iv); const enc = Buffer.concat([c.update(String(text), 'utf8'), c.final()]); return `e1.${iv.toString('base64')}.${c.getAuthTag().toString('base64')}.${enc.toString('base64')}`; }
function decrypt(blob) { const [v, iv, tag, enc] = String(blob).split('.'); if (v !== 'e1') throw new Error('bad blob'); const d = crypto.createDecipheriv('aes-256-gcm', encKey(), Buffer.from(iv, 'base64')); d.setAuthTag(Buffer.from(tag, 'base64')); return Buffer.concat([d.update(Buffer.from(enc, 'base64')), d.final()]).toString('utf8'); }
const hmac = text => crypto.createHmac('sha256', cfg.bankEncKey).update(String(text)).digest('hex');
// IBAN with the real ISO 13616 mod-97 checksum (Pakistan: PK + 2 check digits + 4 letters + 16 digits)
function validIban(v) {
  const s = normIban(v); if (!s) return null;
  const r = (s.slice(4) + s.slice(0, 4)).replace(/[A-Z]/g, ch => ch.charCodeAt(0) - 55);
  let rem = 0; for (const d of r) rem = (rem * 10 + +d) % 97;
  return rem === 1 ? s : null;
}
const maskIban = last4 => 'PK•• •••• •••• •••• ' + last4;
const normName = n => String(n || '').toLowerCase().replace(/[^a-z\s]/g, '').split(/\s+/).filter(Boolean).sort().join(' ');

module.exports = { hashPassword, checkPassword, validPassword, encrypt, decrypt, hmac, validIban, maskIban, normName, HttpError, need, safeEq, signJwt, verifyJwt, normPhone, normMobile, normCnic, normIban, addMonths, nextMonthDay, todayIso, rateLimit };
