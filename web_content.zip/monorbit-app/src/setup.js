// Account setup: identity capture, bank details, verification workflow, eligibility and setup gating.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const cfg = require('./config');
const { HttpError, need, normCnic, validIban, maskIban, encrypt, decrypt, hmac, normName } = require('./lib');
const { tx, audit } = require('./db');
const { notify } = require('./notify');
const consent = require('./consent');
const providers = require('./providers');

const BANKS = ['Allied Bank', 'Askari Bank', 'Bank Alfalah', 'Bank Al Habib', 'Bank of Punjab', 'Dubai Islamic Bank', 'Faysal Bank', 'Habib Bank (HBL)', 'Habib Metropolitan Bank', 'JS Bank', 'Meezan Bank', 'MCB Bank', 'National Bank of Pakistan', 'Silk Bank', 'Soneri Bank', 'Standard Chartered', 'United Bank (UBL)', 'Other'];
const ACTIONS = ['blink', 'turn_left', 'turn_right', 'smile', 'look_up'];
const setting = (db, k) => JSON.parse(db.prepare('SELECT value FROM settings WHERE key=?').get(k).value);

/* ------------------------------- images / liveness ------------------------------- */
const IMG_TYPES = [{ ext: 'jpg', magic: Buffer.from([0xff, 0xd8, 0xff]) }, { ext: 'png', magic: Buffer.from([0x89, 0x50, 0x4e, 0x47]) }];
function startLiveness(db, user) {
  const id = crypto.randomBytes(12).toString('hex');
  const actions = ACTIONS.slice().sort(() => crypto.randomInt(-1, 2)).slice(0, 3);
  db.prepare('INSERT INTO liveness_challenges(id,user_id,actions,expires_at) VALUES(?,?,?,?)').run(id, user.id, JSON.stringify(actions), Date.now() + 5 * 60000);
  return { challengeId: id, actions, expiresInSeconds: 300 };
}
function saveUpload(db, user, b) {
  const kind = b.kind; need(['front', 'back', 'selfie', 'receipt'].includes(kind), 'invalid_kind');
  const m = String(b.image || '').match(/^data:image\/(?:jpeg|jpg|png);base64,([A-Za-z0-9+/=]+)$/);
  need(m, 'invalid_image', 'Send a JPEG or PNG as a base64 data URL');
  const buf = Buffer.from(m[1], 'base64');
  need(buf.length > 0 && buf.length <= 5 * 1024 * 1024, 'image_too_large', 'Image must be under 5 MB');
  const type = IMG_TYPES.find(t => buf.subarray(0, t.magic.length).equals(t.magic)); need(type, 'invalid_image', 'File content is not a real JPEG or PNG');
  let challenge = null;
  if (kind === 'selfie') {   // a selfie must come from the live camera during a fresh, single-use challenge
    need(b.source === 'camera', 'camera_required', 'The selfie must be taken live with the camera');
    const c = db.prepare('SELECT * FROM liveness_challenges WHERE id=? AND user_id=?').get(String(b.challengeId), user.id);
    need(c && !c.used && c.expires_at > Date.now(), 'challenge_invalid', 'The live check expired. Start the selfie step again.');
    challenge = c.id;
  }
  const id = crypto.randomBytes(12).toString('hex'); fs.mkdirSync(cfg.uploadDir, { recursive: true });
  const file = `${id}.${type.ext}`; fs.writeFileSync(path.join(cfg.uploadDir, file), buf, { mode: 0o600 });
  db.prepare('INSERT INTO uploads(id,user_id,kind,file,challenge_id) VALUES(?,?,?,?,?)').run(id, user.id, kind, file, challenge);
  return id;
}
function purgeOldImages(db) {   // retention: identity images are deleted after the configured period
  const rows = db.prepare(`SELECT u.id, u.file FROM uploads u WHERE u.deleted=0 AND u.kind IN ('front','back','selfie') AND EXISTS (
    SELECT 1 FROM kyc_submissions k WHERE k.decided_at IS NOT NULL AND k.decided_at < datetime('now', ?) AND u.id IN (k.front,k.back,k.selfie))`).all(`-${cfg.retentionDays} days`);
  for (const r of rows) { try { fs.unlinkSync(path.join(cfg.uploadDir, r.file)); } catch {} db.prepare('UPDATE uploads SET deleted=1, file=NULL WHERE id=?').run(r.id); }
  return rows.length;
}

/* ----------------------------------- identity ----------------------------------- */
async function submitKyc(db, user, b) {
  need(user.kyc_status !== 'verified', 'already_verified', 'Identity already verified', 409);
  need(user.kyc_status !== 'pending', 'already_pending', 'Your identity check is already being reviewed', 409);
  const cnic = normCnic(b.cnic); need(cnic, 'invalid_cnic', 'CNIC must have 13 digits');
  need(typeof b.name === 'string' && b.name.trim().length >= 2 && b.name.length <= 80, 'invalid_name');
  need(/^\d{4}-\d{2}-\d{2}$/.test(String(b.dob)) && !isNaN(new Date(b.dob)), 'invalid_dob', 'Date of birth must be YYYY-MM-DD');
  const age = (Date.now() - new Date(b.dob).getTime()) / (365.25 * 864e5); need(age >= 18, 'underage', 'You must be 18 or older');
  const ids = {};
  for (const k of ['front', 'back', 'selfie']) { const u = db.prepare('SELECT * FROM uploads WHERE id=? AND user_id=? AND kind=? AND deleted=0').get(String(b[k]), user.id, k); need(u, 'missing_image', `Take the ${k} photo first`); ids[k] = u; }
  const ch = db.prepare('SELECT * FROM liveness_challenges WHERE id=? AND user_id=? AND used=0').get(ids.selfie.challenge_id, user.id); need(ch, 'challenge_invalid', 'Your selfie check is no longer valid. Retake the selfie.');
  need(!db.prepare('SELECT id FROM users WHERE cnic=? AND id<>?').get(cnic, user.id), 'cnic_in_use', 'This CNIC is already registered to another account', 409);
  const r = await providers.kyc.submit({ name: b.name.trim(), cnic, dob: b.dob, images: { front: ids.front.id, back: ids.back.id, selfie: ids.selfie.id } });
  const live = await providers.liveness.check({ image: ids.selfie.id, challenge: ch.id });
  tx(db, () => {
    db.prepare('UPDATE liveness_challenges SET used=1 WHERE id=?').run(ch.id);
    const verified = r.status === 'verified' && live.status === 'passed';
    const status = verified ? 'verified' : r.status === 'rejected' || live.status === 'failed' ? 'rejected' : 'review';
    db.prepare('INSERT INTO kyc_submissions(user_id,front,back,selfie,name,cnic,dob,status,reason,provider_ref,decided_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(user.id, ids.front.id, ids.back.id, ids.selfie.id, b.name.trim(), cnic, b.dob, status, r.reason ?? null, r.ref ?? null, status === 'review' ? null : new Date().toISOString().replace('T', ' ').slice(0, 19));
    db.prepare('UPDATE users SET kyc_status=?, name=?, cnic=?, dob=? WHERE id=?').run(status === 'review' ? 'pending' : status, b.name.trim(), cnic, b.dob, user.id);
    audit(db, 'user:' + user.id, 'kyc_submitted', { status });
  });
  notify(db, user.id, 'kyc_submitted', 'Identity check submitted', 'We received your documents. A team member will review them.', 'kyc-' + Date.now());
  maybeStartVerification(db, db.prepare('SELECT * FROM users WHERE id=?').get(user.id));
  return { status: db.prepare('SELECT status FROM kyc_submissions WHERE user_id=? ORDER BY id DESC').get(user.id).status === 'review' ? 'review' : db.prepare('SELECT status FROM kyc_submissions WHERE user_id=? ORDER BY id DESC').get(user.id).status };
}
function reviewKyc(db, id, approve, reason, actor) {
  return tx(db, () => {
    const s = db.prepare('SELECT * FROM kyc_submissions WHERE id=?').get(id); need(s, 'not_found', 'Submission not found', 404);
    need(s.status === 'review', 'not_reviewable', 'Only submissions in review can be decided', 409);
    need(approve || (reason && reason.trim()), 'reason_required', 'Give a reason when rejecting');
    db.prepare("UPDATE kyc_submissions SET status=?, reason=?, reviewed_by=?, decided_at=datetime('now') WHERE id=?").run(approve ? 'verified' : 'rejected', reason ?? null, actor, s.id);
    db.prepare('UPDATE users SET kyc_status=? WHERE id=?').run(approve ? 'verified' : 'rejected', s.user_id);
    audit(db, actor, approve ? 'kyc_approve' : 'kyc_reject', { submissionId: id, reason });
    notify(db, s.user_id, 'kyc_decision', approve ? 'Identity verified' : 'Identity check not approved', approve ? 'Your identity has been verified.' : (reason || 'We could not verify your documents. You can try again.'), 'kycd-' + id);
    return { ok: true };
  });
}

/* ------------------------------------- bank ------------------------------------- */
function saveBank(db, user, b) {
  const holder = String(b.holderName || '').trim(); need(holder.length >= 3 && holder.length <= 80 && /^[A-Za-z .'-]+$/.test(holder), 'invalid_holder', 'Enter the account holder name using letters only');
  need(BANKS.includes(b.bankName), 'invalid_bank', 'Choose your bank from the list');
  need(['savings', 'current'].includes(b.accountType), 'invalid_account_type', 'Choose an account type');
  const iban = validIban(b.iban); need(iban, 'invalid_iban', 'Enter a valid Pakistani IBAN (24 characters, starting with PK)');
  const h = hmac(iban);
  need(!db.prepare('SELECT 1 FROM bank_accounts WHERE iban_hash=? AND user_id<>?').get(h, user.id), 'bank_in_use', 'This account is already linked to another user. Contact support if this is a mistake.', 409);
  db.prepare('INSERT INTO bank_accounts(user_id,holder_name,bank_name,account_type,iban_enc,iban_last4,iban_hash) VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET holder_name=excluded.holder_name, bank_name=excluded.bank_name, account_type=excluded.account_type, iban_enc=excluded.iban_enc, iban_last4=excluded.iban_last4, iban_hash=excluded.iban_hash, confirmed_at=NULL')
    .run(user.id, holder, b.bankName, b.accountType, encrypt(iban), iban.slice(-4), h);
  return bankView(db, user);
}
function bankView(db, user) {
  const a = db.prepare('SELECT * FROM bank_accounts WHERE user_id=?').get(user.id); if (!a) return null;
  return { holderName: a.holder_name, bankName: a.bank_name, accountType: a.account_type, ibanMasked: maskIban(a.iban_last4), confirmed: !!a.confirmed_at };
}
function confirmBank(db, user, b) {
  need(b.confirm === true, 'confirmation_required', 'Please confirm the details are correct');
  const a = db.prepare('SELECT * FROM bank_accounts WHERE user_id=?').get(user.id); need(a, 'bank_missing', 'Enter your bank details first');
  db.prepare("UPDATE bank_accounts SET confirmed_at=datetime('now') WHERE user_id=?").run(user.id);
  audit(db, 'user:' + user.id, 'bank_confirmed', { last4: a.iban_last4 });
  maybeStartVerification(db, user);
  return bankView(db, user);
}

/* -------------------------- verification and eligibility -------------------------- */
const latestVerification = (db, uid) => db.prepare('SELECT * FROM bank_verifications WHERE user_id=? ORDER BY id DESC LIMIT 1').get(uid);
function prerequisites(db, user) {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(user.id);
  const bank = db.prepare('SELECT confirmed_at FROM bank_accounts WHERE user_id=?').get(user.id);
  return { bank: !!(bank && bank.confirmed_at), identitySubmitted: u.kyc_status !== 'none' && u.kyc_status !== 'rejected', consents: consent.status(db, user.id).complete };
}
function maybeStartVerification(db, user) {
  const p = prerequisites(db, user); if (!(p.bank && p.identitySubmitted && p.consents)) return null;
  const last = latestVerification(db, user.id);
  if (last && !['information_required', 'verification_failed'].includes(last.status)) return last;   // already in progress or decided
  const bank = db.prepare('SELECT * FROM bank_accounts WHERE user_id=?').get(user.id);
  const id = db.prepare("INSERT INTO bank_verifications(user_id,status,provider) VALUES(?,'verification_pending',?)").run(user.id, cfg.providers.bank).lastInsertRowid;
  providers.bank.submit({ holder: bank.holder_name, bank: bank.bank_name, iban: decrypt(bank.iban_enc), cnic: user.cnic }).then(r => {
    db.prepare('UPDATE bank_verifications SET provider_ref=?, result_enc=? WHERE id=?').run(r.ref ?? null, r.result ? encrypt(JSON.stringify(r.result)) : null, id);
    if (r.status === 'verified') decideBank(db, id, 'mark_verified', null, 'provider:' + cfg.providers.bank);
    if (r.status === 'failed') decideBank(db, id, 'fail', 'The bank could not verify this account', 'provider:' + cfg.providers.bank);
  }).catch(e => console.error('bank verification submit failed', e.message));
  notify(db, user.id, 'verification_submitted', 'Verification submitted', 'Your bank information is being verified. We will tell you the result.', 'bv-' + id);
  return { id };
}
function bankFlags(db, userId) {
  const f = []; const a = db.prepare('SELECT holder_name FROM bank_accounts WHERE user_id=?').get(userId); const u = db.prepare('SELECT name, kyc_status FROM users WHERE id=?').get(userId);
  if (a && u.name && normName(a.holder_name) !== normName(u.name)) f.push('name_mismatch');
  if (u.kyc_status !== 'verified') f.push('identity_not_verified');
  return f;
}
function evaluateEligibility(db, userId) {   // only configured, disclosed rules; a record never causes automatic rejection, it sends the case to a human
  const rules = setting(db, 'eligibility'); const reasons = [];
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(userId);
  if (rules.requireIdentity && u.kyc_status !== 'verified') reasons.push('Identity is not yet verified');
  if (bankFlags(db, userId).includes('name_mismatch')) reasons.push('The bank account holder name does not match the identity name');
  const overdue = db.prepare("SELECT COUNT(*) c FROM instalments i JOIN memberships m ON m.id=i.membership_id WHERE m.user_id=? AND i.status='overdue'").get(userId).c;
  if (overdue > rules.maxOverdueInstalments) reasons.push(`${overdue} overdue instalment(s) need review`);
  if (rules.blockOnDefaultFlag && u.defaults_flag) reasons.push('A recorded payment default needs review');
  return { result: reasons.length ? 'under_review' : 'eligible', reasons };
}
const STATUS_TEXT = {
  information_required: 'We need more information from you before we can verify your account.',
  verification_pending: 'Your information was submitted and is waiting for verification.',
  verification_failed: 'We could not verify your bank information. Check your details and try again, or ask for a review.',
  under_review: 'A team member is reviewing your application. This can take a short while.',
  eligible: 'You meet the eligibility criteria. Final approval is pending.',
  not_eligible: 'We could not approve your application. You can ask for a review if you think this is a mistake.',
  approved: 'Your account is approved. You can join committees.',
};
function decideBank(db, id, action, reason, actor) {
  return tx(db, () => {
    const v = db.prepare('SELECT * FROM bank_verifications WHERE id=?').get(id); need(v, 'not_found', 'Verification not found', 404);
    const set = (status, why) => { db.prepare("UPDATE bank_verifications SET status=?, reason=?, reviewed_by=?, updated_at=datetime('now') WHERE id=?").run(status, why ?? null, actor, id); audit(db, actor, 'bank_' + action, { id, status, reason: why }); notify(db, v.user_id, 'verification_update', 'Verification update', `${STATUS_TEXT[status]}${why ? ' ' + why : ''}`, `bvs-${id}-${status}`); return db.prepare('SELECT * FROM bank_verifications WHERE id=?').get(id); };
    const needReason = () => need(reason && reason.trim(), 'reason_required', 'Give the user a reason');
    const open = ['verification_pending', 'under_review', 'eligible'];
    need(open.includes(v.status), 'not_decidable', 'This case is already closed', 409);
    if (action === 'mark_verified') {
      const e = evaluateEligibility(db, v.user_id);
      if (e.result === 'eligible') return set(setting(db, 'eligibility').autoApprove ? 'approved' : 'eligible');
      return set('under_review', e.reasons.join('; '));
    }
    if (action === 'fail') { needReason(); return set('verification_failed', reason); }
    if (action === 'request_info') { needReason(); return set('information_required', reason); }
    if (action === 'review') return set('under_review', reason);
    if (action === 'approve') { need(['eligible', 'under_review'].includes(v.status), 'not_decidable', 'Verify the information first', 409); return set('approved', reason); }
    if (action === 'decline') { needReason(); return set('not_eligible', reason); }
    throw new HttpError(400, 'invalid_action');
  });
}
function verificationView(db, user) {
  const p = prerequisites(db, user); const v = latestVerification(db, user.id);
  const status = v ? v.status : 'information_required';
  const missing = [!p.bank && 'bank', !p.identitySubmitted && 'identity', !p.consents && 'consent'].filter(Boolean);
  return { status, explanation: v ? (STATUS_TEXT[status] + (v.reason ? ' ' + v.reason : '')) : STATUS_TEXT.information_required, missingSteps: v ? [] : missing, canDispute: ['not_eligible', 'verification_failed', 'under_review'].includes(status), updatedAt: v?.updated_at ?? null };
}
function revealBank(db, userId, actor) {
  const a = db.prepare('SELECT * FROM bank_accounts WHERE user_id=?').get(userId); need(a, 'not_found', 'No bank account', 404);
  audit(db, actor, 'bank_revealed', { userId });
  return { holderName: a.holder_name, bankName: a.bank_name, accountType: a.account_type, iban: decrypt(a.iban_enc) };
}

/* ---------------------------------- setup gating ---------------------------------- */
function setupState(db, user) {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(user.id); const p = prerequisites(db, u); const v = verificationView(db, u);
  const steps = [
    { key: 'account', label: 'Create account', done: !!u.phone_verified },
    { key: 'bank', label: 'Bank information', done: p.bank },
    { key: 'identity', label: 'Identity and selfie', done: u.kyc_status === 'verified', state: u.kyc_status },
    { key: 'consent', label: 'Terms and consent', done: p.consents },
    { key: 'verification', label: 'Verification and approval', done: v.status === 'approved', state: v.status },
  ];
  const next = steps.find(s => !s.done);
  return { steps, complete: !next, next: next ? next.key : null };
}
function requireSetup(db, user) {
  const s = setupState(db, user);
  if (!s.complete) throw new HttpError(403, 'setup_incomplete', 'Finish your account setup first', { next: s.next, steps: s.steps });
}
module.exports = { BANKS, startLiveness, saveUpload, purgeOldImages, submitKyc, reviewKyc, saveBank, bankView, confirmBank, maybeStartVerification, decideBank, evaluateEligibility, bankFlags, verificationView, revealBank, setupState, requireSetup, latestVerification, STATUS_TEXT };
