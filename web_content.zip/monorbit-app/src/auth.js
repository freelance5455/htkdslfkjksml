// Accounts: registration, phone verification, login, sessions, logout and password recovery.
const crypto = require('crypto');
const cfg = require('./config');
const { HttpError, need, safeEq, signJwt, verifyJwt, normPhone, hashPassword, checkPassword, validPassword, rateLimit } = require('./lib');
const { audit } = require('./db');
const { notify } = require('./notify');
const providers = require('./providers');

const otpHash = (phone, code) => crypto.createHash('sha256').update(phone + code + cfg.jwtSecret).digest('hex');

async function sendOtp(db, phone, purpose) {
  need(rateLimit(`otp:${purpose}:${phone}`, 5, 3600000), 'too_many_requests', 'Too many codes requested. Try again later.', 429);
  const ex = db.prepare('SELECT * FROM otps WHERE phone=? AND purpose=?').get(phone, purpose);
  if (ex && Date.now() - ex.sent_at < cfg.otpCooldownSec * 1000) throw new HttpError(429, 'otp_cooldown', 'Wait a moment before requesting another code');
  const code = String(crypto.randomInt(0, 10 ** cfg.otpLength)).padStart(cfg.otpLength, '0');
  db.prepare('INSERT INTO otps(phone,purpose,code_hash,expires_at,sent_at) VALUES(?,?,?,?,?) ON CONFLICT(phone,purpose) DO UPDATE SET code_hash=excluded.code_hash, expires_at=excluded.expires_at, sent_at=excluded.sent_at, attempts=0')
    .run(phone, purpose, otpHash(phone, code), Date.now() + 5 * 60000, Date.now());
  await providers.sms.send(phone, `Your Monorbit code is ${code}. It expires in 5 minutes. Never share it.`);
  return cfg.isProd ? {} : { devCode: code };
}
function checkOtp(db, phone, purpose, code) {
  const row = db.prepare('SELECT * FROM otps WHERE phone=? AND purpose=?').get(phone, purpose);
  need(row, 'otp_invalid', 'Request a new code');
  if (row.attempts >= 5) { db.prepare('DELETE FROM otps WHERE phone=? AND purpose=?').run(phone, purpose); throw new HttpError(429, 'otp_locked', 'Too many wrong attempts. Request a new code.'); }
  need(row.expires_at > Date.now(), 'otp_expired', 'Code expired. Request a new one.');
  if (!safeEq(otpHash(phone, String(code || '')), row.code_hash)) { db.prepare('UPDATE otps SET attempts=attempts+1 WHERE phone=? AND purpose=?').run(phone, purpose); throw new HttpError(400, 'otp_invalid', 'Wrong code'); }
  db.prepare('DELETE FROM otps WHERE phone=? AND purpose=?').run(phone, purpose);
}

function createSession(db, user, ctx = {}) {
  const jti = crypto.randomBytes(16).toString('hex');
  db.prepare('INSERT INTO sessions(id,user_id,expires_at,ip,ua) VALUES(?,?,?,?,?)').run(jti, user.id, Date.now() + cfg.sessionDays * 864e5, ctx.ip ?? null, (ctx.ua || '').slice(0, 200));
  return signJwt({ sub: user.id, jti }, cfg.jwtSecret, cfg.sessionDays * 86400);
}
function authenticate(db, token) {
  const pl = verifyJwt(token, cfg.jwtSecret);
  const s = db.prepare('SELECT * FROM sessions WHERE id=?').get(pl.jti);
  if (!s || s.revoked || s.expires_at < Date.now()) throw new HttpError(401, 'session_ended', 'Your session has ended. Please log in again.');
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(pl.sub);
  if (!u || u.status !== 'active') throw new HttpError(401, 'invalid_token');
  return { user: u, jti: pl.jti };
}
const logout = (db, jti) => { db.prepare('UPDATE sessions SET revoked=1 WHERE id=?').run(jti); };

async function register(db, b) {
  const phone = normPhone(b.phone); need(phone, 'invalid_phone', 'Enter a valid Pakistani mobile number');
  need(validPassword(b.password), 'weak_password', 'Password must be at least 8 characters with letters and a number');
  const name = String(b.name || '').trim(); need(name.length >= 2 && name.length <= 80, 'invalid_name', 'Enter your full name');
  const email = b.email ? String(b.email).trim().toLowerCase() : null; need(!email || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email), 'invalid_email', 'Enter a valid email address');
  const ex = db.prepare('SELECT * FROM users WHERE phone=?').get(phone);
  need(!(ex && ex.phone_verified), 'phone_in_use', 'An account with this number already exists. Log in instead.', 409);
  if (ex) db.prepare('UPDATE users SET password_hash=?, name=?, email=? WHERE id=?').run(hashPassword(b.password), name, email, ex.id);
  else db.prepare('INSERT INTO users(phone,name,email,password_hash) VALUES(?,?,?,?)').run(phone, name, email, hashPassword(b.password));
  return { phone, ...(await sendOtp(db, phone, 'register')) };
}
function verifyPhone(db, b, ctx) {
  const phone = normPhone(b.phone); need(phone, 'invalid_phone');
  const u = db.prepare('SELECT * FROM users WHERE phone=?').get(phone); need(u, 'otp_invalid', 'Request a new code');
  checkOtp(db, phone, 'register', b.code);
  db.prepare('UPDATE users SET phone_verified=1 WHERE id=?').run(u.id);
  notify(db, u.id, 'registered', 'Welcome to Monorbit', 'Your account is ready. Finish the account setup to join committees.', 'registered');
  audit(db, 'user:' + u.id, 'registered', null);
  return { token: createSession(db, u, ctx), userId: u.id };
}
async function login(db, b, ctx) {
  const phone = normPhone(b.phone); need(phone, 'invalid_credentials', 'Wrong phone number or password', 401);
  need(rateLimit('login:' + phone, 10, 900000), 'too_many_requests', 'Too many attempts. Try again in a few minutes.', 429);
  const u = db.prepare('SELECT * FROM users WHERE phone=?').get(phone);
  if (u && u.locked_until > Date.now()) throw new HttpError(429, 'account_locked', 'Too many wrong passwords. Try again later or reset your password.');
  if (!u || !u.password_hash || !checkPassword(b.password, u.password_hash)) {
    if (u) { const f = u.failed_logins + 1; db.prepare('UPDATE users SET failed_logins=?, locked_until=? WHERE id=?').run(f >= 5 ? 0 : f, f >= 5 ? Date.now() + 15 * 60000 : 0, u.id); }
    throw new HttpError(401, 'invalid_credentials', 'Wrong phone number or password');
  }
  db.prepare('UPDATE users SET failed_logins=0 WHERE id=?').run(u.id);
  if (u.status !== 'active') throw new HttpError(403, 'account_disabled', 'This account is disabled. Contact support.');
  if (!u.phone_verified) { const o = await sendOtp(db, phone, 'register'); throw new HttpError(403, 'phone_unverified', 'Verify your phone number to continue', o); }
  return { token: createSession(db, u, ctx) };
}
async function forgotPassword(db, b) {   // same response whether or not the account exists
  const phone = normPhone(b.phone); need(phone, 'invalid_phone');
  const u = db.prepare('SELECT * FROM users WHERE phone=? AND phone_verified=1').get(phone);
  if (!u) return {};
  return sendOtp(db, phone, 'reset');
}
function resetPassword(db, b) {
  const phone = normPhone(b.phone); need(phone, 'invalid_phone');
  need(validPassword(b.newPassword), 'weak_password', 'Password must be at least 8 characters with letters and a number');
  const u = db.prepare('SELECT * FROM users WHERE phone=? AND phone_verified=1').get(phone); need(u, 'otp_invalid', 'Request a new code');
  checkOtp(db, phone, 'reset', b.code);
  db.prepare('UPDATE users SET password_hash=?, failed_logins=0, locked_until=0 WHERE id=?').run(hashPassword(b.newPassword), u.id);
  db.prepare('UPDATE sessions SET revoked=1 WHERE user_id=?').run(u.id);   // sign out everywhere
  audit(db, 'user:' + u.id, 'password_reset', null);
  return { ok: true };
}

/* ---------------------------- staff accounts and roles ---------------------------- */
const PERMS = {
  superadmin: ['*'],
  compliance: ['users.view', 'users.sensitive', 'kyc.review', 'bank.review', 'disputes.manage', 'audit.view', 'reports.view'],
  finance: ['users.view', 'payments.view', 'payments.verify', 'payouts.create', 'payouts.approve', 'fees.manage', 'reports.view', 'reports.finance', 'reconcile.view', 'gold.manage', 'refunds.manage'],
  operations: ['users.view', 'plans.manage', 'enrollments.view', 'payouts.create', 'notifications.manage', 'reports.view', 'disputes.manage'],
  support: ['users.view', 'enrollments.view', 'disputes.manage', 'notifications.manage'],
};
const can = (role, perm) => !!PERMS[role] && (PERMS[role].includes('*') || PERMS[role].includes(perm));

function createAdmin(db, { email, name, password, role }, actor) {
  need(PERMS[role], 'invalid_role', 'Unknown role');
  need(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email || ''), 'invalid_email');
  need(validPassword(password) && password.length >= 10, 'weak_password', 'Staff passwords need at least 10 characters with letters and a number');
  const id = db.prepare('INSERT INTO admin_users(email,name,password_hash,role) VALUES(?,?,?,?)').run(email.toLowerCase(), name, hashPassword(password), role).lastInsertRowid;
  audit(db, actor, 'admin_created', { id: Number(id), email, role });
  return Number(id);
}
function adminLogin(db, b) {
  const email = String(b.email || '').toLowerCase();
  need(rateLimit('adminlogin:' + email, 10, 900000), 'too_many_requests', 'Too many attempts. Try again later.', 429);
  const a = db.prepare('SELECT * FROM admin_users WHERE email=?').get(email);
  if (a && a.locked_until > Date.now()) throw new HttpError(429, 'account_locked', 'Account temporarily locked');
  if (!a || !a.active || !checkPassword(b.password, a.password_hash)) {
    if (a) { const f = a.failed_logins + 1; db.prepare('UPDATE admin_users SET failed_logins=?, locked_until=? WHERE id=?').run(f >= 5 ? 0 : f, f >= 5 ? Date.now() + 15 * 60000 : 0, a.id); }
    throw new HttpError(401, 'invalid_credentials', 'Wrong email or password');
  }
  db.prepare('UPDATE admin_users SET failed_logins=0 WHERE id=?').run(a.id);
  const jti = crypto.randomBytes(16).toString('hex');
  db.prepare('INSERT INTO admin_sessions(id,admin_id,expires_at) VALUES(?,?,?)').run(jti, a.id, Date.now() + 8 * 3600000);
  audit(db, a.email, 'admin_login', null);
  return { token: signJwt({ adm: a.id, jti }, cfg.jwtSecret, 8 * 3600), admin: { id: a.id, email: a.email, name: a.name, role: a.role, permissions: PERMS[a.role] } };
}
function adminAuthenticate(db, token) {
  const pl = verifyJwt(token, cfg.jwtSecret); if (!pl.adm) throw new HttpError(401, 'invalid_token');
  const s = db.prepare('SELECT * FROM admin_sessions WHERE id=?').get(pl.jti);
  if (!s || s.revoked || s.expires_at < Date.now()) throw new HttpError(401, 'session_ended');
  const a = db.prepare('SELECT * FROM admin_users WHERE id=? AND active=1').get(pl.adm); if (!a) throw new HttpError(401, 'invalid_token');
  return { admin: a, jti: pl.jti };
}
function bootstrapAdmin(db) {
  if (db.prepare('SELECT COUNT(*) c FROM admin_users').get().c) return null;
  if (cfg.adminBootstrapEmail && cfg.adminBootstrapPassword) { createAdmin(db, { email: cfg.adminBootstrapEmail, name: 'Owner', password: cfg.adminBootstrapPassword, role: 'superadmin' }, 'bootstrap'); return { email: cfg.adminBootstrapEmail }; }
  if (!cfg.isProd) { createAdmin(db, { email: 'admin@monorbit.local', name: 'Dev Admin', password: 'DevAdmin12345', role: 'superadmin' }, 'bootstrap'); return { email: 'admin@monorbit.local', password: 'DevAdmin12345', dev: true }; }
  return null;
}
module.exports = { sendOtp, register, verifyPhone, login, forgotPassword, resetPassword, authenticate, logout, createSession, PERMS, can, createAdmin, adminLogin, adminAuthenticate, bootstrapAdmin };
