const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const cfg = require('./config');
const { HttpError, need, normPhone, normMobile, normIban, addMonths, nextMonthDay } = require('./lib');
const { tx, audit } = require('./db');
const S = require('./services');
const auth = require('./auth');
const setup = require('./setup');
const consent = require('./consent');
const fees = require('./fees');
const recurring = require('./recurring');
const reports = require('./reports');
const { notify } = require('./notify');
const providers = require('./providers');

const created = body => ({ __status: 201, body });
const maskName = n => { if (!n) return 'Member'; const p = n.trim().split(/\s+/); return p[0] + (p[1] ? ' ' + p[1][0] + '.' : ''); };
const maskCnic = c => c ? '•••••••••' + c.slice(-4) : null;
const limit = (q, d = 50, max = 200) => Math.min(Math.max(+q.get('limit') || d, 1), max);

module.exports = function buildRoutes(db) {
  const routes = [];
  const r = (method, p, opts, handler) => {
    if (typeof opts === 'function') { handler = opts; opts = {}; }
    const keys = []; const regex = new RegExp('^' + p.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method, regex, keys, opts, handler });
  };
  const U = { auth: 'user' }; const A = perm => ({ auth: 'admin', perm });

  r('GET', '/health', () => ({ ok: true, dev: !cfg.isProd, recurringAvailable: recurring.available(), time: new Date().toISOString() }));

  /* ----------------------------- accounts and sessions ----------------------------- */
  r('POST', '/auth/register', async ({ body }) => created({ ok: true, ...(await auth.register(db, body)) }));
  r('POST', '/auth/resend-code', async ({ body }) => { const phone = normPhone(body.phone); need(phone, 'invalid_phone'); const u = db.prepare('SELECT * FROM users WHERE phone=? AND phone_verified=0').get(phone); return u ? { ok: true, ...(await auth.sendOtp(db, phone, 'register')) } : { ok: true }; });
  r('POST', '/auth/verify-phone', ({ body, ip, ua }) => auth.verifyPhone(db, body, { ip, ua }));
  r('POST', '/auth/login', async ({ body, ip, ua }) => auth.login(db, body, { ip, ua }));
  r('POST', '/auth/logout', U, ({ jti }) => { auth.logout(db, jti); return { ok: true }; });
  r('POST', '/auth/password/forgot', async ({ body }) => ({ ok: true, ...(await auth.forgotPassword(db, body)) }));
  r('POST', '/auth/password/reset', ({ body }) => auth.resetPassword(db, body));
  const me = user => { const u = db.prepare('SELECT * FROM users WHERE id=?').get(user.id); return { id: u.id, phone: u.phone, email: u.email, name: u.name, kycStatus: u.kyc_status, balances: S.balances(db, u.id), setup: setup.setupState(db, u), verification: setup.verificationView(db, u), unreadNotifications: db.prepare('SELECT COUNT(*) c FROM notifications WHERE user_id=? AND read=0').get(u.id).c }; };
  r('GET', '/me', U, ({ user }) => me(user));

  /* ---------------------------------- account setup ---------------------------------- */
  r('GET', '/setup', U, ({ user }) => ({ ...setup.setupState(db, user), verification: setup.verificationView(db, user), banks: setup.BANKS, bank: setup.bankView(db, user) }));
  r('GET', '/bank', U, ({ user }) => ({ bank: setup.bankView(db, user), banks: setup.BANKS }));
  r('PUT', '/bank', U, ({ user, body }) => setup.saveBank(db, user, body));
  r('POST', '/bank/confirm', U, ({ user, body }) => setup.confirmBank(db, user, body));
  r('POST', '/kyc/liveness', U, ({ user }) => created(setup.startLiveness(db, user)));
  r('POST', '/uploads', { auth: 'user', limit: 8 * 1024 * 1024 }, ({ user, body }) => created({ uploadId: setup.saveUpload(db, user, body) }));
  r('POST', '/kyc/submit', U, async ({ user, body }) => setup.submitKyc(db, user, body));
  r('GET', '/kyc/status', U, ({ user }) => { const u = db.prepare('SELECT kyc_status FROM users WHERE id=?').get(user.id); return { kycStatus: u.kyc_status, latest: db.prepare('SELECT status, reason, created_at FROM kyc_submissions WHERE user_id=? ORDER BY id DESC LIMIT 1').get(user.id) || null }; });
  r('GET', '/consents', U, ({ user }) => consent.status(db, user.id));
  r('POST', '/consents', U, ({ user, body, ip, ua }) => { const s = consent.accept(db, user, body.consents, { ip, ua }); setup.maybeStartVerification(db, user); return s; });
  r('GET', '/verification', U, ({ user }) => setup.verificationView(db, user));
  r('POST', '/disputes', U, ({ user, body }) => {
    need(['eligibility', 'deduction', 'payment', 'other'].includes(body.type), 'invalid_type'); need(typeof body.message === 'string' && body.message.trim().length >= 5 && body.message.length <= 1000, 'invalid_message', 'Describe the problem (5 to 1000 characters)');
    if (body.type === 'eligibility') { const v = setup.latestVerification(db, user.id); need(v && ['not_eligible', 'verification_failed'].includes(v.status), 'not_disputable', 'There is no decision to dispute'); db.prepare("UPDATE bank_verifications SET status='under_review', reason='Review requested by the user', updated_at=datetime('now') WHERE id=?").run(v.id); }
    const id = db.prepare('INSERT INTO disputes(user_id,type,ref,message) VALUES(?,?,?,?)').run(user.id, body.type, body.ref ? String(body.ref).slice(0, 40) : null, body.message.trim()).lastInsertRowid;
    audit(db, 'user:' + user.id, 'dispute_opened', { id: Number(id), type: body.type }); return created({ id: Number(id), status: 'open' });
  });
  r('GET', '/disputes', U, ({ user }) => ({ disputes: db.prepare('SELECT id, type, ref, message, status, response, created_at createdAt, resolved_at resolvedAt FROM disputes WHERE user_id=? ORDER BY id DESC').all(user.id) }));

  /* -------------------------------- committees and slots -------------------------------- */
  r('GET', '/plans', U, ({ user, query }) => {
    const c = query.get('currency'); need(!c || S.CURRENCIES.includes(c), 'invalid_currency');
    return { plans: db.prepare("SELECT * FROM plans WHERE status='active' AND (? IS NULL OR currency=?) ORDER BY currency, amount").all(c, c).map(p => S.planCard(db, p, user.id)) };
  });
  r('GET', '/plans/:id', U, ({ user, params }) => {
    const m = S.slotMap(db, +params.id, user.id); const start = m.committee ? m.committee.start_date : nextMonthDay(5);
    return { ...S.planCard(db, m.plan, user.id), slots: m.slots, rules: m.rules, startDate: start,
      schedule: Array.from({ length: m.plan.months }, (_, i) => ({ seq: i + 1, dueDate: addMonths(start, i), amount: m.plan.amount })),
      gold: m.plan.currency === 'XAU' ? S.goldInfo(db) : null,
      terms: ['terms', 'fees_payouts', 'disputes_refunds'].map(t => { const d = consent.currentDocs(db).find(x => x.type === t); return { type: t, title: d.title, version: d.version }; }) };
  });
  r('POST', '/memberships', U, ({ user, body }) => created(S.reserveSlot(db, user, +body.planId, +body.slot)));
  r('GET', '/memberships', U, ({ user }) => ({ memberships: db.prepare(`SELECT m.id, m.slot, m.status, c.id committeeId, c.start_date startDate, pl.name, pl.currency, pl.amount, pl.months
      FROM memberships m JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE m.user_id=? AND m.status<>'cancelled' ORDER BY m.id DESC`).all(user.id).map(m => ({
    ...m, paid: db.prepare("SELECT COUNT(*) c FROM instalments WHERE membership_id=? AND status='paid'").get(m.id).c, totalAmount: m.amount * m.months, payoutDate: addMonths(m.startDate, m.slot - 1),
    next: db.prepare("SELECT id, seq, due_date dueDate, amount, status FROM instalments WHERE membership_id=? AND status IN ('due','overdue') ORDER BY seq LIMIT 1").get(m.id) || null })) }));
  r('GET', '/memberships/:id', U, ({ user, params }) => {
    const m = db.prepare(`SELECT m.id, m.slot, m.status, m.committee_id committeeId, c.start_date startDate, pl.name, pl.currency, pl.amount, pl.months FROM memberships m JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE m.id=? AND m.user_id=?`).get(+params.id, user.id);
    need(m, 'not_found', 'Membership not found', 404);
    return { ...m, totalAmount: m.amount * m.months, payoutDate: addMonths(m.startDate, m.slot - 1),
      instalments: db.prepare('SELECT id, seq, due_date dueDate, amount, currency, status, paid_at paidAt FROM instalments WHERE membership_id=? ORDER BY seq').all(m.id),
      payoutOrder: db.prepare("SELECT m2.slot, m2.user_id uid, u.name FROM memberships m2 JOIN users u ON u.id=m2.user_id WHERE m2.committee_id=? AND m2.status='active' ORDER BY m2.slot").all(m.committeeId).map(x => ({ slot: x.slot, name: x.uid === user.id ? 'You' : maskName(x.name) })),
      payout: db.prepare('SELECT amount, currency, status, sent_at sentAt, settlement_note settlementNote FROM payouts WHERE membership_id=?').get(m.id) || null,
      autoPay: recurring.list(db, user.id).find(x => x.membershipId === m.id && x.status === 'active') || null };
  });
  r('GET', '/payout-account', U, ({ user }) => { const a = db.prepare('SELECT type, number FROM payout_accounts WHERE user_id=?').get(user.id); return a ? { type: a.type, last4: a.number.slice(-4) } : null; });
  r('PUT', '/payout-account', U, ({ user, body }) => {
    need(['jazz', 'easy', 'bank'].includes(body.type), 'invalid_type'); const num = body.type === 'bank' ? normIban(body.number) : normMobile(body.number);
    need(num, 'invalid_number', body.type === 'bank' ? 'Enter a valid Pakistani IBAN' : 'Enter a valid mobile number');
    db.prepare('INSERT INTO payout_accounts(user_id,type,number) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET type=excluded.type, number=excluded.number').run(user.id, body.type, num);
    audit(db, 'user:' + user.id, 'payout_account_set', { type: body.type, last4: num.slice(-4) }); return { ok: true, last4: num.slice(-4) };
  });

  /* --------------------------------------- gold --------------------------------------- */
  r('GET', '/gold/rate', () => S.goldInfo(db));
  r('POST', '/gold/quote', U, ({ body }) => S.goldQuote(db, body.tola, body.months));
  r('GET', '/gold/plans', U, ({ user }) => ({ plans: db.prepare('SELECT * FROM gold_plans WHERE user_id=? ORDER BY id DESC').all(user.id).map(p => ({ id: p.id, tola: p.tola, months: p.months, total: p.total, down: p.down, status: p.status,
    instalments: db.prepare('SELECT id, seq, amount, due_date dueDate, status FROM gold_instalments WHERE plan_id=? ORDER BY seq').all(p.id) })) }));

  /* ---------------------------------------- payments ---------------------------------------- */
  r('POST', '/payments/quote', U, ({ user, body }) => S.quote(db, user, body));
  r('POST', '/payments', U, async ({ user, body }) => created(await S.createPayment(db, user, body)));
  r('GET', '/payments', U, ({ user, query }) => { const st = query.get('status'); return { payments: db.prepare('SELECT * FROM payments WHERE user_id=? AND (? IS NULL OR status=?) ORDER BY id DESC LIMIT 100').all(user.id, st, st).map(S.viewPayment) }; });
  r('GET', '/payments/:ref', U, ({ user, params }) => { const p = db.prepare('SELECT * FROM payments WHERE ref=? AND user_id=?').get(params.ref, user.id); need(p, 'not_found', 'Payment not found', 404); return S.viewPayment(p); });
  r('GET', '/payments/:ref/receipt', U, ({ user, params }) => S.receipt(db, user.id, params.ref));
  r('POST', '/payments/:ref/proof', U, ({ user, params, body }) => {
    const p = db.prepare('SELECT * FROM payments WHERE ref=? AND user_id=?').get(params.ref, user.id); need(p && p.method === 'bank', 'not_found', 'Bank payment not found', 404);
    need(['awaiting_transfer', 'under_review'].includes(p.status), 'not_updatable', 'Payment already decided', 409);
    need(db.prepare("SELECT 1 FROM uploads WHERE id=? AND user_id=? AND kind='receipt'").get(String(body.uploadId), user.id), 'missing_image', 'Upload the receipt first');
    db.prepare("UPDATE payments SET receipt_upload=?, status='under_review' WHERE id=?").run(String(body.uploadId), p.id); return { status: 'under_review' };
  });
  r('GET', '/wallet', U, ({ user }) => ({ balances: S.balances(db, user.id), entries: db.prepare('SELECT currency, amount, balance_after balanceAfter, kind, note, created_at createdAt FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT 60').all(user.id) }));

  /* ------------------------------------ automatic deductions ------------------------------------ */
  r('GET', '/memberships/:id/auto-pay', U, ({ user, params }) => { need(db.prepare('SELECT 1 FROM memberships WHERE id=? AND user_id=?').get(+params.id, user.id), 'not_found', 'Not found', 404); return { ...recurring.explain(db, +params.id), authorization: consent.currentDocs(db).find(d => d.type === 'recurring_authorization') }; });
  r('GET', '/mandates', U, ({ user }) => ({ mandates: recurring.list(db, user.id) }));
  r('POST', '/mandates', U, async ({ user, body, ip, ua }) => created(await recurring.create(db, user, { ...body, ctx: { ip, ua } })));
  r('POST', '/mandates/:id/cancel', U, async ({ user, params }) => recurring.cancel(db, user, params.id));

  /* -------------------------------- notifications and reports -------------------------------- */
  r('GET', '/notifications', U, ({ user }) => ({ notifications: db.prepare('SELECT id, type, title, body, read, created_at createdAt FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100').all(user.id) }));
  r('POST', '/notifications/read', U, ({ user, body }) => { if (body.all) db.prepare('UPDATE notifications SET read=1 WHERE user_id=?').run(user.id); else for (const id of [].concat(body.ids || [])) db.prepare('UPDATE notifications SET read=1 WHERE id=? AND user_id=?').run(+id, user.id); return { ok: true }; });
  r('GET', '/reports/me', U, ({ user }) => reports.userReport(db, user.id));

  /* ------------------------------------ gateway callbacks ------------------------------------ */
  r('POST', '/webhooks/:gateway', { raw: true }, ({ params, raw, req }) => {
    const gw = providers.gateways[params.gateway]; need(gw, 'not_found', 'Unknown gateway', 404);
    if (!gw.verifyWebhook(raw, req.headers['x-signature'])) throw new HttpError(401, 'bad_signature');
    let body; try { body = JSON.parse(raw.toString()); } catch { throw new HttpError(400, 'invalid_json'); }
    const ev = gw.parseWebhook(body); const p = db.prepare('SELECT * FROM payments WHERE ref=?').get(ev.ref);
    need(p && (p.method === params.gateway || (p.method === 'card' && params.gateway === 'card')), 'not_found', 'Payment not found', 404);
    if (ev.success) S.markPaid(db, ev.ref, ev.gatewayRef); else S.markFailed(db, ev.ref); return { ok: true };
  });
  if (!cfg.isProd) r('POST', '/dev/gateway/confirm', ({ body }) => {   // development only: stands in for the gateway's signed callback
    need(body.ref, 'invalid_ref'); if (body.success === false) return S.markFailed(db, body.ref); return S.markPaid(db, body.ref, 'DEV-' + crypto.randomBytes(3).toString('hex'));
  });

  /* ---------------------------------------- staff: accounts ---------------------------------------- */
  r('POST', '/admin/login', ({ body }) => auth.adminLogin(db, body));
  r('POST', '/admin/logout', { auth: 'admin' }, ({ admin, jti }) => { db.prepare('UPDATE admin_sessions SET revoked=1 WHERE id=?').run(jti); return { ok: true }; });
  r('GET', '/admin/me', { auth: 'admin' }, ({ admin }) => ({ id: admin.id, email: admin.email, name: admin.name, role: admin.role, permissions: auth.PERMS[admin.role] }));
  r('GET', '/admin/staff', A('*'), () => ({ staff: db.prepare('SELECT id, email, name, role, active, created_at createdAt FROM admin_users ORDER BY id').all() }));
  r('POST', '/admin/staff', A('*'), ({ admin, body }) => created({ id: auth.createAdmin(db, body, admin.email) }));

  /* ------------------------------------------ staff: users ------------------------------------------ */
  r('GET', '/admin/stats', A('reports.view'), () => { const c = q => db.prepare(q).get().c; return { users: c('SELECT COUNT(*) c FROM users'), kycReview: c("SELECT COUNT(*) c FROM kyc_submissions WHERE status='review'"), bankReview: c("SELECT COUNT(*) c FROM bank_verifications WHERE status IN ('verification_pending','under_review','eligible')"), activeMemberships: c("SELECT COUNT(*) c FROM memberships WHERE status='active'"), bankToVerify: c("SELECT COUNT(*) c FROM payments WHERE method='bank' AND status IN ('awaiting_transfer','under_review')"), payoutsPending: c("SELECT COUNT(*) c FROM payouts WHERE status='pending_approval'"), openDisputes: c("SELECT COUNT(*) c FROM disputes WHERE status='open'") }; });
  r('GET', '/admin/users', A('users.view'), ({ query }) => { const q = '%' + (query.get('q') || '') + '%'; return { users: db.prepare('SELECT id, phone, name, kyc_status kycStatus, status, defaults_flag defaultsFlag, created_at createdAt FROM users WHERE phone LIKE ? OR name LIKE ? ORDER BY id DESC LIMIT 100').all(q, q) }; });
  r('GET', '/admin/users/:id', A('users.view'), ({ params }) => {
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(+params.id); need(u, 'not_found', 'User not found', 404); const v = setup.latestVerification(db, u.id);
    return { id: u.id, phone: u.phone, email: u.email, name: u.name, cnic: maskCnic(u.cnic), kycStatus: u.kyc_status, status: u.status, defaultsFlag: !!u.defaults_flag, bank: setup.bankView(db, u), verification: v ? { id: v.id, status: v.status, reason: v.reason } : null, flags: setup.bankFlags(db, u.id),
      memberships: db.prepare("SELECT m.id, m.slot, m.status, pl.name, pl.currency FROM memberships m JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE m.user_id=?").all(u.id), payments: db.prepare('SELECT ref, purpose, currency, total, status, created_at createdAt FROM payments WHERE user_id=? ORDER BY id DESC LIMIT 20').all(u.id) };
  });
  r('POST', '/admin/users/:id/reveal-bank', A('users.sensitive'), ({ admin, params }) => setup.revealBank(db, +params.id, admin.email));
  r('POST', '/admin/users/:id/default-flag', A('users.sensitive'), ({ admin, params, body }) => { need(typeof body.flag === 'boolean' && body.note, 'invalid_request', 'Send flag (true/false) and a note'); db.prepare('UPDATE users SET defaults_flag=? WHERE id=?').run(body.flag ? 1 : 0, +params.id); audit(db, admin.email, 'default_flag', { userId: +params.id, flag: body.flag, note: body.note }); return { ok: true }; });
  r('POST', '/admin/users/:id/status', A('*'), ({ admin, params, body }) => { need(['active', 'locked'].includes(body.status), 'invalid_status'); db.prepare('UPDATE users SET status=? WHERE id=?').run(body.status, +params.id); if (body.status === 'locked') db.prepare('UPDATE sessions SET revoked=1 WHERE user_id=?').run(+params.id); audit(db, admin.email, 'user_status', { userId: +params.id, status: body.status }); return { ok: true }; });

  /* --------------------------------------- staff: verification --------------------------------------- */
  r('GET', '/admin/kyc', A('kyc.review'), ({ query }) => ({ submissions: db.prepare(`SELECT k.id, k.status, k.reason, k.name, k.cnic, k.dob, k.front, k.back, k.selfie, k.created_at createdAt, u.phone FROM kyc_submissions k JOIN users u ON u.id=k.user_id WHERE k.status=? ORDER BY k.id DESC LIMIT 100`).all(query.get('status') || 'review') }));
  r('POST', '/admin/kyc/:id/decision', A('kyc.review'), ({ admin, params, body }) => setup.reviewKyc(db, +params.id, body.approve === true, body.reason, admin.email));
  r('GET', '/admin/uploads/:id', { auth: 'admin' }, ({ admin, params }) => {
    const u = db.prepare('SELECT * FROM uploads WHERE id=?').get(params.id); need(u, 'not_found', 'Not found', 404);
    const perm = u.kind === 'receipt' ? 'payments.verify' : 'kyc.review'; if (!auth.can(admin.role, perm)) throw new HttpError(403, 'forbidden', 'Your role cannot view this');
    need(!u.deleted && u.file, 'image_deleted', 'This image was deleted under the retention policy', 410); audit(db, admin.email, 'view_upload', { id: u.id, kind: u.kind });
    return { __raw: true, status: 200, headers: { 'content-type': u.file.endsWith('png') ? 'image/png' : 'image/jpeg', 'cache-control': 'no-store' }, body: fs.readFileSync(path.join(cfg.uploadDir, u.file)) };
  });
  r('GET', '/admin/bank-verifications', A('bank.review'), ({ query }) => ({ items: db.prepare(`SELECT v.id, v.status, v.reason, v.provider, v.created_at createdAt, u.id userId, u.name, u.phone, b.bank_name bankName, b.iban_last4 last4 FROM bank_verifications v JOIN users u ON u.id=v.user_id LEFT JOIN bank_accounts b ON b.user_id=u.id WHERE v.status=? ORDER BY v.id DESC LIMIT 100`).all(query.get('status') || 'verification_pending').map(x => ({ ...x, flags: setup.bankFlags(db, x.userId) })) }));
  r('POST', '/admin/bank-verifications/:id/decision', A('bank.review'), ({ admin, params, body }) => setup.decideBank(db, +params.id, body.action, body.reason, admin.email));

  /* ----------------------------------------- staff: committees ----------------------------------------- */
  r('GET', '/admin/plans', A(['plans.manage', 'enrollments.view']), () => ({ plans: db.prepare('SELECT * FROM plans ORDER BY currency, amount').all().map(p => ({ ...p, blocks: db.prepare('SELECT slot, kind, note FROM slot_blocks WHERE plan_id=?').all(p.id), fee: S.feeSummary(db, p) })) }));
  const planFields = (b, p = {}) => { const o = { ...p };
    if (b.name != null) { need(String(b.name).trim().length >= 3, 'invalid_name'); o.name = String(b.name).trim(); }
    if (b.description != null) o.description = String(b.description).slice(0, 300);
    if (b.minWaitMonths != null) { need(Number.isInteger(b.minWaitMonths) && b.minWaitMonths >= 0 && b.minWaitMonths <= 12, 'invalid_wait'); o.min_wait_months = b.minWaitMonths; }
    if (b.firstPayoutMonth != null) { need(Number.isInteger(b.firstPayoutMonth) && b.firstPayoutMonth >= 1 && b.firstPayoutMonth <= 24, 'invalid_first_payout'); o.first_payout_month = b.firstPayoutMonth; }
    if (b.status != null) { need(['active', 'hidden'].includes(b.status), 'invalid_status'); o.status = b.status; } return o; };
  r('POST', '/admin/plans', A('plans.manage'), ({ admin, body }) => {
    need(S.CURRENCIES.includes(body.currency), 'invalid_currency'); need(Number.isInteger(body.amount) && body.amount > 0, 'invalid_amount', 'Contribution must be a whole number of minor units (paisa, cents or milligrams)'); need(Number.isInteger(body.months) && body.months >= 2 && body.months <= 36, 'invalid_months');
    const o = planFields(body, { min_wait_months: 2, first_payout_month: 3, description: null, status: 'active' }); need(o.name, 'invalid_name');
    const id = db.prepare('INSERT INTO plans(name,currency,amount,months,min_wait_months,first_payout_month,description,status) VALUES(?,?,?,?,?,?,?,?)').run(o.name, body.currency, body.amount, body.months, o.min_wait_months, o.first_payout_month, o.description, o.status).lastInsertRowid;
    audit(db, admin.email, 'plan_created', { id: Number(id), ...body }); return created({ id: Number(id) });
  });
  r('PUT', '/admin/plans/:id', A('plans.manage'), ({ admin, params, body }) => {   // amount, currency and duration are fixed once created, because members rely on them
    const p = db.prepare('SELECT * FROM plans WHERE id=?').get(+params.id); need(p, 'not_found', 'Plan not found', 404); const o = planFields(body, p);
    db.prepare('UPDATE plans SET name=?, description=?, min_wait_months=?, first_payout_month=?, status=? WHERE id=?').run(o.name, o.description, o.min_wait_months, o.first_payout_month, o.status, p.id);
    audit(db, admin.email, 'plan_updated', { id: p.id, ...body }); return { ok: true };
  });
  r('PUT', '/admin/plans/:id/slot-blocks', A('plans.manage'), ({ admin, params, body }) => {
    const p = db.prepare('SELECT * FROM plans WHERE id=?').get(+params.id); need(p, 'not_found', 'Plan not found', 404); need(Number.isInteger(body.slot) && body.slot >= 1 && body.slot <= p.months, 'invalid_slot'); need(['reserved', 'unavailable', 'none'].includes(body.kind), 'invalid_kind');
    if (body.kind === 'none') db.prepare('DELETE FROM slot_blocks WHERE plan_id=? AND slot=?').run(p.id, body.slot);
    else db.prepare('INSERT INTO slot_blocks(plan_id,slot,kind,note) VALUES(?,?,?,?) ON CONFLICT(plan_id,slot) DO UPDATE SET kind=excluded.kind, note=excluded.note').run(p.id, body.slot, body.kind, body.note ?? null);
    audit(db, admin.email, 'slot_block', { planId: p.id, ...body }); return { ok: true };
  });
  r('GET', '/admin/committees', A(['enrollments.view', 'plans.manage']), () => ({ committees: db.prepare(`SELECT c.id, c.status, c.start_date startDate, pl.name, pl.currency, pl.amount, pl.months, (SELECT COUNT(*) FROM memberships m WHERE m.committee_id=c.id AND m.status='active') members, (SELECT COUNT(*) FROM memberships m WHERE m.committee_id=c.id AND m.status='pending_payment') pending FROM committees c JOIN plans pl ON pl.id=c.plan_id ORDER BY c.id DESC`).all() }));
  r('GET', '/admin/committees/:id', A(['enrollments.view', 'plans.manage']), ({ params }) => ({ members: db.prepare("SELECT m.id, m.slot, m.status, u.name, u.phone FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.committee_id=? AND m.status<>'cancelled' ORDER BY m.slot").all(+params.id) }));
  r('POST', '/admin/committees/:id/cycle', A('payouts.create'), ({ admin, params, body }) => created(S.runCycle(db, +params.id, +body.month, admin.email)));

  /* --------------------------------------- staff: money --------------------------------------- */
  r('GET', '/admin/payments', A('payments.view'), ({ query }) => ({ payments: db.prepare('SELECT p.*, u.phone FROM payments p JOIN users u ON u.id=p.user_id WHERE (? IS NULL OR p.status=?) AND (? IS NULL OR p.method=?) ORDER BY p.id DESC LIMIT ?').all(query.get('status'), query.get('status'), query.get('method'), query.get('method'), limit(query)).map(p => ({ ...S.viewPayment(p), phone: p.phone, receiptUpload: p.receipt_upload })) }));
  r('POST', '/admin/payments/:ref/bank-decision', A('payments.verify'), ({ admin, params, body }) => S.verifyBankTransfer(db, params.ref, body.approve === true, admin.email));
  r('POST', '/admin/payments/:ref/reverse', A('refunds.manage'), ({ admin, params, body }) => S.reversePayment(db, params.ref, body.reason, admin.email));
  r('GET', '/admin/payouts', A(['payouts.create', 'payouts.approve']), ({ query }) => ({ payouts: db.prepare('SELECT p.id, p.amount, p.currency, p.status, p.account, p.created_by createdBy, p.approved_by approvedBy, p.settlement_note settlementNote, p.created_at createdAt, u.name, u.phone FROM payouts p JOIN users u ON u.id=p.user_id WHERE p.status=? ORDER BY p.id DESC LIMIT 100').all(query.get('status') || 'pending_approval').map(x => ({ ...x, account: x.account.split(':')[0] + ' ···' + x.account.slice(-4) })) }));
  r('POST', '/admin/payouts/:id/approve', A('payouts.approve'), async ({ admin, params }) => S.approvePayout(db, +params.id, admin.email));
  r('GET', '/admin/fees', A('fees.manage'), () => ({ rules: db.prepare('SELECT * FROM fee_rules ORDER BY effective_from DESC, id DESC').all(), note: 'Rules are never edited. Add a new rule with an effective date. Existing members keep the fee agreed at enrolment.' }));
  r('POST', '/admin/fees', A('fees.manage'), ({ admin, body }) => {
    const id = fees.addRule(db, body, admin.email); audit(db, admin.email, 'fee_rule_added', { id, ...body });
    const rows = body.scope === 'plan' ? db.prepare("SELECT DISTINCT m.user_id FROM memberships m JOIN committees c ON c.id=m.committee_id WHERE c.plan_id=? AND m.status='active'").all(+body.planId) : db.prepare("SELECT DISTINCT m.user_id FROM memberships m JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE m.status='active' AND (? IS NULL OR pl.currency=?)").all(body.currency ?? null, body.currency ?? null);
    for (const x of rows) notify(db, x.user_id, 'fee_change', 'Fee change announced', `A fee change takes effect on ${body.effectiveFrom} for new enrolments. Your current committee keeps the fees you agreed at enrolment.`, 'fee-' + id);
    return created({ id });
  });
  r('GET', '/admin/gold-rate', A('gold.manage'), () => S.goldInfo(db));
  r('PUT', '/admin/gold-rate', A('gold.manage'), ({ admin, body }) => { need(Number.isInteger(body.ratePerTola) && body.ratePerTola >= 1e6 && body.ratePerTola <= 1e9, 'invalid_rate', 'Rate is in paisa per tola'); need(body.source && String(body.source).trim().length >= 3, 'source_required', 'Name the pricing source'); db.prepare('INSERT INTO gold_rates(rate_per_tola,source) VALUES(?,?)').run(body.ratePerTola, String(body.source).slice(0, 80)); audit(db, admin.email, 'gold_rate', body); return { ok: true }; });
  r('GET', '/admin/settings', A('*'), () => ({ settings: Object.fromEntries(db.prepare('SELECT key, value FROM settings').all().map(s => [s.key, JSON.parse(s.value)])) }));
  r('PUT', '/admin/settings/:key', A('*'), ({ admin, params, body }) => {
    need(['eligibility', 'currencies'].includes(params.key), 'invalid_key');
    if (params.key === 'eligibility') { need(typeof body.requireIdentity === 'boolean' && Number.isInteger(body.maxOverdueInstalments) && typeof body.blockOnDefaultFlag === 'boolean' && typeof body.autoApprove === 'boolean', 'invalid_settings'); }
    else need(Array.isArray(body.value) && body.value.every(c => S.CURRENCIES.includes(c)), 'invalid_settings');
    db.prepare('UPDATE settings SET value=?, updated_by=?, updated_at=datetime(\'now\') WHERE key=?').run(JSON.stringify(params.key === 'currencies' ? body.value : body), admin.email, params.key); audit(db, admin.email, 'setting_changed', { key: params.key, value: body }); return { ok: true };
  });

  /* ---------------------------- staff: notifications, disputes, reports, audit ---------------------------- */
  r('POST', '/admin/notifications', A('notifications.manage'), ({ admin, body }) => {
    need(body.title && body.body && String(body.title).length <= 80 && String(body.body).length <= 400, 'invalid_message', 'Title (80) and message (400) are required');
    const ids = body.userId ? [+body.userId] : db.prepare("SELECT id FROM users WHERE phone_verified=1 AND status='active'").all().map(x => x.id); const ref = 'bc-' + Date.now();
    for (const id of ids) notify(db, id, 'announcement', body.title, body.body, ref); audit(db, admin.email, 'notification_sent', { audience: body.userId || 'all', count: ids.length, title: body.title }); return { sent: ids.length };
  });
  r('GET', '/admin/disputes', A('disputes.manage'), ({ query }) => ({ disputes: db.prepare('SELECT d.id, d.type, d.ref, d.message, d.status, d.response, d.created_at createdAt, u.phone, u.name FROM disputes d JOIN users u ON u.id=d.user_id WHERE d.status=? ORDER BY d.id DESC LIMIT 100').all(query.get('status') || 'open') }));
  r('POST', '/admin/disputes/:id/resolve', A('disputes.manage'), ({ admin, params, body }) => {
    need(body.response && String(body.response).trim().length >= 5, 'response_required', 'Write a response for the user');
    const d = db.prepare("SELECT * FROM disputes WHERE id=? AND status='open'").get(+params.id); need(d, 'not_found', 'Open dispute not found', 404);
    db.prepare("UPDATE disputes SET status='resolved', response=?, resolved_by=?, resolved_at=datetime('now') WHERE id=?").run(String(body.response).trim(), admin.email, d.id);
    audit(db, admin.email, 'dispute_resolved', { id: d.id }); notify(db, d.user_id, 'dispute_resolved', 'Your dispute was answered', String(body.response).trim().slice(0, 300), 'disp-' + d.id); return { ok: true };
  });
  r('GET', '/admin/reports/summary', A('reports.view'), ({ query }) => reports.adminSummary(db, query.get('from') || undefined, query.get('to') || undefined));
  r('GET', '/admin/reports/reconciliation', A('reconcile.view'), () => reports.reconcile(db));
  r('GET', '/admin/reports/export', A('reports.finance'), ({ admin, query }) => {
    const t = query.get('type'); need(['payments', 'journal'].includes(t), 'invalid_type');
    const rows = t === 'payments' ? db.prepare('SELECT ref, purpose, currency, amount, fee, transfer, discount, total, method, status, created_at, paid_at FROM payments ORDER BY id').all() : db.prepare('SELECT id, payment_id, currency, account, amount, reversal_of, created_at FROM journal ORDER BY id').all();
    audit(db, admin.email, 'report_export', { type: t }); return { __raw: true, status: 200, headers: { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="${t}.csv"` }, body: Buffer.from(reports.csv(rows)) };
  });
  r('GET', '/admin/audit', A('audit.view'), ({ query }) => ({ entries: db.prepare('SELECT id, actor, action, detail, created_at createdAt FROM audit ORDER BY id DESC LIMIT ?').all(limit(query, 100, 500)) }));
  r('POST', '/admin/jobs/run', A('*'), async () => ({ ...S.runJobs(db), recurring: await recurring.run(db) }));

  /* ------------------------------------- the web app and admin console ------------------------------------- */
  const WEB = path.join(__dirname, '..', 'web');
  const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png' };
  const CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'";
  const serveFile = (dir, f, ext) => () => ({ __raw: true, status: 200, headers: { 'content-type': TYPES[ext], 'content-security-policy': CSP, 'permissions-policy': 'camera=(self)', 'cache-control': 'no-cache' }, body: fs.readFileSync(path.join(dir, f)) });
  if (fs.existsSync(WEB)) for (const f of fs.readdirSync(WEB)) {
    const ext = path.extname(f); if (!TYPES[ext]) continue;
    r('GET', '/' + f, { raw: true }, serveFile(WEB, f, ext)); if (f === 'index.html') r('GET', '/', { raw: true }, serveFile(WEB, f, ext));
  }
  const ADMIN = path.join(__dirname, '..', 'admin');
  if (fs.existsSync(ADMIN)) for (const f of fs.readdirSync(ADMIN)) { const ext = path.extname(f); if (TYPES[ext]) r('GET', '/admin-panel' + (f === 'index.html' ? '' : '/' + f), { raw: true }, serveFile(ADMIN, f, ext)); }
  return routes;
};
