// Friendly check first: the built-in database needs Node 22.13 or newer.
const [maj, min] = process.versions.node.split('.').map(Number);
if (maj < 22 || (maj === 22 && min < 13)) {
  console.error(`\nThis app needs Node.js 22.13 or newer. You have ${process.versions.node}.\nInstall the LTS version from https://nodejs.org, then open a NEW terminal and try again.\n`);
  process.exit(1);
}
const { spawn } = require('child_process');
const cfg = require('./config');
const { createServer } = require('./server');
const { runJobs } = require('./services');
const recurring = require('./recurring');

const server = createServer();
server.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error(`\nPort ${cfg.port} is already in use. Close the other copy of the app, or run on another port:\n  Windows PowerShell:  $env:PORT=3001; npm start\n  Windows cmd:         set PORT=3001 && npm start\n  Mac/Linux:           PORT=3001 npm start\n`);
  else console.error(e);
  process.exit(1);
});
server.listen(cfg.port, () => {
  const url = `http://localhost:${cfg.port}`;
  console.log(`\n  Monorbit is running\n  App:    ${url}\n  Staff:  ${url}/admin-panel${server.bootstrap && server.bootstrap.dev ? `   (development login: ${server.bootstrap.email} / ${server.bootstrap.password})` : ''}\n\n  Press Ctrl+C to stop.\n`);
  if (!cfg.isProd && !process.argv.includes('--no-open') && !process.env.CI) {
    const [cmd, args] = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
    try { const c = spawn(cmd, args, { stdio: 'ignore', detached: true }); c.on('error', () => {}); c.unref(); } catch {}
  }
});

// Hourly housekeeping: mark overdue instalments, release expired slot reservations
setInterval(async () => { try { runJobs(server.db); await recurring.run(server.db); } catch (e) { console.error('job error', e); } }, 3600000).unref();
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { console.log('\nStopped.'); server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 500).unref(); });
