// Core business rules: wallets, committees and slots, quotes, payments, fulfilment, reversals, payouts, jobs.
// Money is always integer minor units with an explicit currency: PKR = paisa, USD = cents, XAU (gold) = milligrams.
const crypto = require('crypto');
const cfg = require('./config');
const { HttpError, need, addMonths, nextMonthDay, todayIso } = require('./lib');
const { tx, audit } = require('./db');
const providers = require('./providers');
const fees = require('./fees');
const { notify } = require('./notify');
const setup = require('./setup');

const TOLA_GRAMS = 11.6638;
const CURRENCIES = ['PKR', 'USD', 'XAU'];

/* ------------------------------ wallet (per currency) ------------------------------ */
const balance = (db, uid, cur = 'PKR') => db.prepare('SELECT COALESCE(SUM(amount),0) b FROM ledger WHERE user_id=? AND currency=?').get(uid, cur).b;
const balances = (db, uid) => ({ PKR: balance(db, uid, 'PKR'), USD: balance(db, uid, 'USD') });
function post(db, uid, cur, amount, kind, paymentId, note) {
  const b = balance(db, uid, cur) + amount;
  if (b < 0) throw new HttpError(402, 'insufficient_balance', 'Not enough wallet balance');
  db.prepare('INSERT INTO ledger(user_id,currency,amount,balance_after,kind,payment_id,note) VALUES(?,?,?,?,?,?,?)').run(uid, cur, amount, b, kind, paymentId ?? null, note ?? null);
  return b;
}

/* ----------------------------------- gold pricing ----------------------------------- */
function goldInfo(db) {
  const p = providers.goldPrice.get(db);
  const perGram = Math.round(p.ratePerTola / TOLA_GRAMS);
  return { ratePerTola: p.ratePerTola, ratePerGram: perGram, source: p.source, priceAt: p.at, method: 'Rate per tola divided by 11.6638 g, valued in PKR at the time of payment', custody: 'Valued in PKR. Gold is not physically owned or allocated to you unless your provider and custody terms say so.' };
}
const goldValue = (mg, perGram) => Math.round(mg / 1000 * perGram);
function goldQuote(db, tola, months) {   // legacy "buy gold on instalments" plans
  need(typeof tola === 'number' && tola >= 0.25 && tola <= 10 && Math.round(tola * 4) === tola * 4, 'invalid_tola', 'Tola must be between 0.25 and 10 in steps of 0.25');
  need([3, 6, 9, 12].includes(months), 'invalid_months');
  const rate = goldInfo(db).ratePerTola, total = Math.round(tola * rate), down = Math.round(total * cfg.goldDownRate), monthly = Math.floor((total - down) / months);
  return { tola, months, rate, total, down, monthly, lastInstalment: total - down - monthly * (months - 1) };
}

/* ------------------------------- committees and slots ------------------------------- */
const currentCommittee = (db, planId) => db.prepare("SELECT * FROM committees WHERE plan_id=? AND status='open' ORDER BY id LIMIT 1").get(planId);
const earliestSlot = p => Math.max(p.first_payout_month, p.min_wait_months + 1);   // the two settings are separate, business-owner-confirmed rules
function feeSummary(db, plan) {
  const r = fees.effectiveRule(db, { planId: plan.id, currency: plan.currency });
  if (!r) return { text: 'No service fee', confirmed: true };
  const parts = []; if (r.pct_bps) parts.push(`${r.pct_bps / 100}%`); if (r.fixed) parts.push(`+ fixed ${r.fixed}`);
  const per = r.applies_to === 'instalment' ? 'of each instalment' : r.applies_to === 'enrollment' ? 'of the enrolment payment' : 'of the total committee amount, charged once at enrolment';
  return { pctBps: r.pct_bps, appliesTo: r.applies_to, payer: r.payer, transferCharge: r.transfer_charge, lateFee: r.late_fee, text: `${parts.join(' ') || '0'} service fee ${per}${r.transfer_charge ? ' plus a transfer charge per payment' : ''}`, confirmed: !!r.confirmed };
}
function slotMap(db, planId, userId) {
  const plan = db.prepare("SELECT * FROM plans WHERE id=? AND status='active'").get(planId); need(plan, 'not_found', 'Plan not found', 404);
  const c = currentCommittee(db, planId);
  const mem = c ? db.prepare("SELECT slot, user_id, status, reserved_until > datetime('now') held FROM memberships WHERE committee_id=? AND status<>'cancelled'").all(c.id) : [];
  const blocks = db.prepare('SELECT slot, kind, note FROM slot_blocks WHERE plan_id=?').all(planId);
  const first = earliestSlot(plan);
  const slots = Array.from({ length: plan.months }, (_, i) => {
    const slot = i + 1, m = mem.find(x => x.slot === slot), b = blocks.find(x => x.slot === slot);
    if (m && m.status === 'active') return { slot, state: 'occupied', mine: m.user_id === userId };
    if (m && m.held) return { slot, state: 'held', mine: m.user_id === userId, reason: 'Temporarily held while a payment is completed' };
    if (b) return { slot, state: b.kind === 'reserved' ? 'reserved' : 'unavailable', reason: b.note || (b.kind === 'reserved' ? 'Reserved' : 'Not available') };
    if (slot < first) return { slot, state: 'unavailable', reason: `Payouts start from month ${first} (waiting-period rule)` };
    return { slot, state: 'available' };
  });
  return { plan, committee: c, slots, rules: { minWaitMonths: plan.min_wait_months, firstPayoutMonth: plan.first_payout_month, earliestSlot: first, note: 'The waiting period and first-payout month are separate configurable rules awaiting business-owner confirmation.' } };
}
function planCard(db, p, userId) {
  const m = slotMap(db, p.id, userId); const avail = m.slots.filter(s => s.state === 'available').length;
  return { id: p.id, name: p.name, currency: p.currency, contribution: p.amount, months: p.months, frequency: p.frequency, totalAmount: p.amount * p.months, participants: p.months,
    slots: { available: avail, occupied: m.slots.filter(s => s.state === 'occupied').length, held: m.slots.filter(s => s.state === 'held').length, reserved: m.slots.filter(s => s.state === 'reserved').length, unavailable: m.slots.filter(s => s.state === 'unavailable').length },
    firstPayoutMonth: m.rules.earliestSlot, enrolment: avail ? 'open' : 'full', fees: feeSummary(db, p), description: p.description };
}
function reserveSlot(db, user, planId, slot) {
  setup.requireSetup(db, user);
  const plan = db.prepare("SELECT * FROM plans WHERE id=? AND status='active'").get(planId); need(plan, 'not_found', 'Plan not found', 404);
  need(Number.isInteger(slot) && slot >= 1 && slot <= plan.months, 'invalid_slot');
  return tx(db, () => {
    db.prepare("DELETE FROM memberships WHERE status='pending_payment' AND reserved_until<=datetime('now')").run();
    let c = currentCommittee(db, planId);
    if (!c) { const id = db.prepare('INSERT INTO committees(plan_id,start_date) VALUES(?,?)').run(planId, nextMonthDay(5)).lastInsertRowid; c = db.prepare('SELECT * FROM committees WHERE id=?').get(id); }
    need(!db.prepare("SELECT 1 FROM memberships WHERE committee_id=? AND user_id=? AND status<>'cancelled'").get(c.id, user.id), 'already_member', 'You are already in this committee', 409);
    const st = slotMap(db, planId, user.id).slots.find(s => s.slot === slot);
    need(st.state === 'available', st.state === 'unavailable' ? 'slot_unavailable' : 'slot_taken', st.state === 'unavailable' ? (st.reason || 'That slot is not available') : 'That payout month was just taken. Pick another.', 409);
    const rule = fees.effectiveRule(db, { planId, currency: plan.currency });
    const id = db.prepare(`INSERT INTO memberships(committee_id,user_id,slot,fee_snapshot,reserved_until) VALUES(?,?,?,?,datetime('now','+${cfg.reserveMinutes} minutes'))`).run(c.id, user.id, slot, rule ? JSON.stringify(fees.snap(rule)) : null).lastInsertRowid;
    return { membershipId: Number(id), committeeId: c.id, slot, currency: plan.currency, contribution: plan.amount, months: plan.months, reservedMinutes: cfg.reserveMinutes };
  });
}

/* ----------------------------------- quotes and orders ----------------------------------- */
const PURPOSES = ['join', 'instalment', 'topup', 'gold', 'gold_instalment'];
function normMethod(input) {
  let m = input.method, cardType = input.cardType;
  if (m === 'debit' || m === 'credit') { cardType = m; m = 'card'; }
  need(['card', 'bank', 'wallet', 'jazz', 'easy'].includes(m), 'invalid_method', 'Choose a payment method');
  if (m === 'card') need(['debit', 'credit'].includes(cardType), 'invalid_card_type', 'Choose debit or credit card');
  return { method: m, cardType: m === 'card' ? cardType : null };
}
// Builds a complete priced order WITHOUT creating anything. Used for quotes and for real payments so both always agree.
function buildOrder(db, user, input) {
  const { purpose } = input; need(PURPOSES.includes(purpose), 'invalid_purpose');
  const { method, cardType } = normMethod(input);
  need(!(purpose === 'topup' && method === 'wallet'), 'invalid_method', 'Cannot top up from the wallet');
  setup.requireSetup(db, user);
  let base, currency = 'PKR', target = null, meta = {}, overdue = false, rule = null, kind = purpose, planTotal = 0, denom = null, title = '', sub = '';
  const goldFor = (mg) => { const g = goldInfo(db); meta.gold = { milligrams: mg, ratePerGram: g.ratePerGram, ratePerTola: g.ratePerTola, source: g.source, priceAt: g.priceAt, method: g.method, custody: g.custody }; denom = { currency: 'XAU', amount: mg }; return goldValue(mg, g.ratePerGram); };
  if (purpose === 'join' || purpose === 'instalment') {
    let m, plan, inst = null;
    if (purpose === 'join') {
      m = db.prepare('SELECT m.*, c.plan_id FROM memberships m JOIN committees c ON c.id=m.committee_id WHERE m.id=? AND m.user_id=?').get(+input.targetId, user.id);
      need(m, 'not_found', 'Membership not found', 404); need(m.status === 'pending_payment', 'already_paid', 'This slot is already paid', 409);
      need(db.prepare("SELECT 1 FROM memberships WHERE id=? AND reserved_until>datetime('now')").get(m.id), 'reservation_expired', 'Your slot reservation expired. Pick the slot again.', 410);
      plan = db.prepare('SELECT * FROM plans WHERE id=?').get(m.plan_id); target = m.id; sub = `Instalment 1 of ${plan.months} · payout month ${m.slot}`;
    } else {
      inst = db.prepare("SELECT i.*, m.user_id, m.fee_snapshot, c.plan_id FROM instalments i JOIN memberships m ON m.id=i.membership_id JOIN committees c ON c.id=m.committee_id WHERE i.id=? AND m.user_id=?").get(+input.targetId, user.id);
      need(inst, 'not_found', 'Instalment not found', 404); need(inst.status === 'due' || inst.status === 'overdue', 'already_paid', 'Already paid', 409);
      m = inst; plan = db.prepare('SELECT * FROM plans WHERE id=?').get(inst.plan_id); target = inst.id; overdue = inst.status === 'overdue'; sub = `Instalment ${inst.seq} of ${plan.months}`;
    }
    rule = m.fee_snapshot ? JSON.parse(m.fee_snapshot) : fees.effectiveRule(db, { planId: plan.id, currency: plan.currency });   // agreed rule wins over later changes
    planTotal = plan.amount * plan.months; title = plan.name;
    if (plan.currency === 'XAU') { base = goldFor(plan.amount); planTotal = goldValue(plan.amount * plan.months, goldInfo(db).ratePerGram); currency = 'PKR'; }
    else { base = plan.amount; currency = plan.currency; }
  } else if (purpose === 'topup') {
    currency = input.currency || 'PKR'; need(['PKR', 'USD'].includes(currency), 'invalid_currency', 'Wallets hold PKR or USD');
    base = input.amount; need(Number.isInteger(base) && base >= (currency === 'USD' ? 500 : 50000) && base <= (currency === 'USD' ? 1000000 : 20000000), 'invalid_amount', currency === 'USD' ? 'Top-up must be between $5 and $10,000' : 'Top-up must be between Rs 500 and Rs 200,000');
    rule = fees.effectiveRule(db, { currency }); title = `${currency} wallet top-up`; sub = 'Added once the payment is confirmed';
  } else if (purpose === 'gold') {
    const q = goldQuote(db, input.tola, input.months); base = q.down; meta = { tola: q.tola, months: q.months, rate: q.rate, total: q.total, down: q.down }; title = `${q.tola} tola gold plan`; sub = `${q.months} monthly instalments after today`;
  } else {
    const g = db.prepare('SELECT gi.*, gp.tola FROM gold_instalments gi JOIN gold_plans gp ON gp.id=gi.plan_id WHERE gi.id=? AND gp.user_id=?').get(+input.targetId, user.id);
    need(g, 'not_found', 'Instalment not found', 404); need(g.status !== 'paid', 'already_paid', 'Already paid', 409); base = g.amount; target = g.id; title = `${g.tola} tola gold instalment`; sub = `Instalment ${g.seq}`;
  }
  const { lines, fee, transfer } = fees.computeLines(rule, { kind, base, planTotal, method, overdue });
  let discount = 0;
  if (input.promo && ['join', 'instalment'].includes(purpose)) {
    const pr = db.prepare('SELECT * FROM promos WHERE code=? AND active=1 AND (max_uses IS NULL OR used<max_uses)').get(String(input.promo).trim().toUpperCase());
    need(pr && pr.currency === currency, 'invalid_promo', 'Promo code is not valid for this payment');
    discount = Math.min(pr.discount, base); meta.promo = pr.code; lines.push({ code: 'discount', label: `Promo ${pr.code}`, amount: -discount });
  }
  const total = base + fee + transfer - discount;
  const methods = [{ method: 'card', cardTypes: ['debit', 'credit'], available: true }, { method: 'bank', label: 'Online bank transfer', available: true }];
  if (purpose !== 'topup') methods.push({ method: 'wallet', available: balance(db, user.id, currency) >= total, balance: balance(db, user.id, currency), currency });
  return { purpose, targetId: target, currency, title, subtitle: sub, base, fee, transfer, discount, total, lines, meta, denom, method, cardType, methods,
    ...(meta.gold ? { conversion: { from: { currency: 'XAU', milligrams: denom.amount }, to: 'PKR', ratePerGram: meta.gold.ratePerGram, priceAt: meta.gold.priceAt, source: meta.gold.source, method: meta.gold.method, note: meta.gold.custody } } : {}),
    feeRuleConfirmed: rule ? !!rule.confirmed : true };
}
const viewOrder = o => { const { meta, ...rest } = o; return rest; };
const quote = (db, user, input) => viewOrder(buildOrder(db, user, input));

/* ----------------------------------- payments ----------------------------------- */
const viewPayment = p => ({ ref: p.ref, purpose: p.purpose, targetId: p.target_id, currency: p.currency, amount: p.amount, fee: p.fee, transfer: p.transfer, discount: p.discount, total: p.total, method: p.method, cardType: p.card_type, status: p.status, denomination: p.denom_currency ? { currency: p.denom_currency, amount: p.denom_amount } : null, scheduledFor: p.scheduled_for, createdAt: p.created_at, paidAt: p.paid_at });
const extendReservation = (db, id) => db.prepare("UPDATE memberships SET reserved_until=datetime('now','+45 minutes') WHERE id=? AND status='pending_payment'").run(id);

async function createPayment(db, user, input) {
  const idem = input.idempotencyKey ? String(input.idempotencyKey).slice(0, 80) : null;
  if (idem) { const ex = db.prepare('SELECT * FROM payments WHERE user_id=? AND idem_key=?').get(user.id, idem); if (ex) return { payment: viewPayment(ex), existing: true }; }
  const o = buildOrder(db, user, input);
  if (input.quotedTotal != null && +input.quotedTotal !== o.total) throw new HttpError(409, 'quote_changed', 'The price changed since you reviewed it. Please check the new total.', { quote: viewOrder(o) });
  const ref = 'MO-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const insert = (status, gw) => db.prepare('INSERT INTO payments(ref,user_id,purpose,target_id,currency,amount,fee,transfer,discount,total,method,card_type,denom_currency,denom_amount,status,gateway_ref,meta,idem_key) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(ref, user.id, o.purpose, o.targetId, o.currency, o.base, o.fee, o.transfer, o.discount, o.total, o.method, o.cardType, o.denom?.currency ?? null, o.denom?.amount ?? null, status, gw ?? null, JSON.stringify({ ...o.meta, lines: o.lines }), idem).lastInsertRowid;
  const get = () => viewPayment(db.prepare('SELECT * FROM payments WHERE ref=?').get(ref));
  if (o.method === 'wallet') { tx(db, () => { const id = insert('created'); post(db, user.id, o.currency, -o.total, 'payment', id); settle(db, id, null); }); return { payment: get() }; }
  if (o.method === 'bank') { insert('awaiting_transfer'); if (o.purpose === 'join') extendReservation(db, o.targetId); return { payment: get(), bank: { ...cfg.bank, reference: ref, amount: o.total, currency: o.currency } }; }
  const gw = providers.gateways[o.method]; const r = await gw.initiate({ ref, total: o.total, purpose: o.purpose, currency: o.currency }, input);
  insert('pending', r.gatewayRef); if (o.purpose === 'join') extendReservation(db, o.targetId);
  return { payment: get(), next: { action: r.action, redirectUrl: r.redirectUrl ?? null } };
}

function journalPost(db, p, sign, reversalOf) {
  const e = db.prepare('INSERT INTO journal(payment_id,currency,account,amount,reversal_of) VALUES(?,?,?,?,?)');
  const acct = p.purpose === 'topup' ? 'wallet_deposit' : 'contribution';
  if (p.amount) e.run(p.id, p.currency, acct, sign * p.amount, reversalOf ?? null);
  if (p.fee) e.run(p.id, p.currency, 'service_fee', sign * p.fee, reversalOf ?? null);
  if (p.transfer) e.run(p.id, p.currency, 'transfer_charge', sign * p.transfer, reversalOf ?? null);
  if (p.discount) e.run(p.id, p.currency, 'discount', -sign * p.discount, reversalOf ?? null);
}
// Mark paid and deliver what was bought. Idempotent: safe if a gateway retries a callback.
function settle(db, paymentId, gatewayRef) {
  const p = db.prepare('SELECT * FROM payments WHERE id=?').get(paymentId);
  if (p.status === 'paid' || p.status === 'reversed') return p;
  db.prepare("UPDATE payments SET status='paid', paid_at=datetime('now'), gateway_ref=COALESCE(?,gateway_ref) WHERE id=?").run(gatewayRef ?? null, p.id);
  const meta = JSON.parse(p.meta || '{}'); if (meta.promo) db.prepare('UPDATE promos SET used=used+1 WHERE code=?').run(meta.promo);
  journalPost(db, p, 1);
  fulfill(db, p, meta);
  notify(db, p.user_id, 'payment_success', 'Payment successful', `Your payment ${p.ref} was received.`, 'pay-ok-' + p.ref);
  return db.prepare('SELECT * FROM payments WHERE id=?').get(p.id);
}
function fulfill(db, p, meta) {
  const now = todayIso();
  if (p.purpose === 'topup') return void post(db, p.user_id, p.currency, p.amount, 'topup', p.id);
  if (p.purpose === 'join') {
    const m = db.prepare('SELECT m.*, pl.amount, pl.months, pl.currency pcur, pl.name, c.start_date FROM memberships m JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE m.id=?').get(p.target_id);
    if (!m || m.status !== 'pending_payment') { post(db, p.user_id, p.currency, p.total, 'refund', p.id, 'Slot no longer available'); return; }
    db.prepare("UPDATE memberships SET status='active', reserved_until=NULL WHERE id=?").run(m.id);
    const ins = db.prepare('INSERT INTO instalments(membership_id,seq,due_date,amount,currency,status,paid_at,payment_id) VALUES(?,?,?,?,?,?,?,?)');
    for (let s = 1; s <= m.months; s++) ins.run(m.id, s, addMonths(m.start_date, s - 1), m.amount, m.pcur, s === 1 ? 'paid' : 'due', s === 1 ? now : null, s === 1 ? p.id : null);
    if (db.prepare("SELECT COUNT(*) c FROM memberships WHERE committee_id=? AND status='active'").get(m.committee_id).c === m.months) db.prepare("UPDATE committees SET status='running' WHERE id=?").run(m.committee_id);
    notify(db, p.user_id, 'enrolment_confirmed', 'Enrolment confirmed', `You joined ${m.name}, payout month ${m.slot}.`, 'enrol-' + m.id);
    return;
  }
  if (p.purpose === 'instalment') { if (!db.prepare("UPDATE instalments SET status='paid', paid_at=datetime('now'), payment_id=? WHERE id=? AND status IN ('due','overdue')").run(p.id, p.target_id).changes) post(db, p.user_id, p.currency, p.total, 'refund', p.id, 'Instalment already paid'); return; }
  if (p.purpose === 'gold') {
    const gid = db.prepare('INSERT INTO gold_plans(user_id,tola,months,rate,total,down) VALUES(?,?,?,?,?,?)').run(p.user_id, meta.tola, meta.months, meta.rate, meta.total, meta.down).lastInsertRowid;
    const monthly = Math.floor((meta.total - meta.down) / meta.months); const ins = db.prepare('INSERT INTO gold_instalments(plan_id,seq,amount,due_date) VALUES(?,?,?,?)');
    for (let s = 1; s <= meta.months; s++) ins.run(gid, s, s === meta.months ? meta.total - meta.down - monthly * (meta.months - 1) : monthly, addMonths(now, s)); return;
  }
  if (p.purpose === 'gold_instalment') {
    if (!db.prepare("UPDATE gold_instalments SET status='paid', paid_at=datetime('now'), payment_id=? WHERE id=? AND status<>'paid'").run(p.id, p.target_id).changes) return void post(db, p.user_id, p.currency, p.total, 'refund', p.id, 'Instalment already paid');
    const gi = db.prepare('SELECT plan_id FROM gold_instalments WHERE id=?').get(p.target_id);
    if (!db.prepare("SELECT 1 FROM gold_instalments WHERE plan_id=? AND status<>'paid'").get(gi.plan_id)) db.prepare("UPDATE gold_plans SET status='completed' WHERE id=?").run(gi.plan_id);
  }
}
function markPaid(db, ref, gatewayRef) {
  return tx(db, () => { const p = db.prepare('SELECT * FROM payments WHERE ref=?').get(ref); need(p, 'not_found', 'Payment not found', 404); return viewPayment(settle(db, p.id, gatewayRef)); });
}
function markFailed(db, ref) {
  const p = db.prepare("SELECT * FROM payments WHERE ref=? AND status IN ('pending','created','scheduled')").get(ref); if (!p) return { changed: 0 };
  db.prepare("UPDATE payments SET status='failed' WHERE id=?").run(p.id);
  notify(db, p.user_id, 'payment_failed', 'Payment failed', `Your payment ${p.ref} did not go through. You were not charged.`, 'pay-fail-' + p.ref);
  if (p.mandate_id) { const m = db.prepare('SELECT * FROM mandates WHERE id=?').get(p.mandate_id); if (m) { const f = m.fail_count + 1; db.prepare("UPDATE mandates SET fail_count=?, status=CASE WHEN ?>=3 THEN 'failed' ELSE status END WHERE id=?").run(f, f, m.id); } }
  return { changed: 1 };
}
function verifyBankTransfer(db, ref, approve, actor) {
  return tx(db, () => {
    const p = db.prepare('SELECT * FROM payments WHERE ref=?').get(ref); need(p && p.method === 'bank', 'not_found', 'Bank payment not found', 404);
    need(['awaiting_transfer', 'under_review'].includes(p.status), 'not_verifiable', 'Payment already decided', 409);
    audit(db, actor, approve ? 'bank_transfer_verified' : 'bank_transfer_rejected', { ref });
    if (!approve) { db.prepare("UPDATE payments SET status='failed' WHERE id=?").run(p.id); notify(db, p.user_id, 'payment_failed', 'Transfer not confirmed', `We could not confirm your transfer ${p.ref}.`, 'pay-fail-' + p.ref); return { status: 'failed' }; }
    return { status: settle(db, p.id, null).status };
  });
}
// Corrections are reversal entries, never edits: the original payment and journal rows stay untouched.
function reversePayment(db, ref, reason, actor) {
  need(reason && reason.trim(), 'reason_required', 'Give a reason for the reversal');
  return tx(db, () => {
    const p = db.prepare('SELECT * FROM payments WHERE ref=?').get(ref); need(p, 'not_found', 'Payment not found', 404);
    need(p.status === 'paid', 'not_reversible', 'Only paid payments can be reversed', 409);
    if (p.purpose === 'topup') post(db, p.user_id, p.currency, -p.amount, 'reversal', p.id, reason);
    else if (p.purpose === 'instalment' || p.purpose === 'gold_instalment') {
      const t = p.purpose === 'instalment' ? 'instalments' : 'gold_instalments';
      db.prepare(`UPDATE ${t} SET status='due', paid_at=NULL, payment_id=NULL WHERE id=?`).run(p.target_id);
      post(db, p.user_id, p.currency, p.total, 'refund', p.id, reason);   // refunds go to the wallet; refunds to the original method are handled manually by finance
    } else if (p.purpose === 'join') {
      need(db.prepare("SELECT COUNT(*) c FROM instalments WHERE membership_id=? AND status='paid'").get(p.target_id).c <= 1, 'not_reversible', 'Later instalments were paid. Reverse those first.', 409);
      need(!db.prepare('SELECT 1 FROM payouts WHERE membership_id=?').get(p.target_id), 'not_reversible', 'A payout exists for this membership', 409);
      db.prepare("UPDATE instalments SET status='cancelled' WHERE membership_id=?").run(p.target_id); db.prepare("UPDATE memberships SET status='cancelled' WHERE id=?").run(p.target_id);
      post(db, p.user_id, p.currency, p.total, 'refund', p.id, reason);
    } else throw new HttpError(409, 'not_reversible', 'This payment type cannot be reversed automatically');
    journalPost(db, p, -1, p.id);
    db.prepare("UPDATE payments SET status='reversed' WHERE id=?").run(p.id);
    audit(db, actor, 'payment_reversed', { ref, reason });
    notify(db, p.user_id, 'payment_reversed', 'Payment reversed', `Payment ${p.ref} was reversed. ${p.purpose === 'topup' ? '' : 'The amount was returned to your wallet.'}`, 'rev-' + p.ref);
    return { status: 'reversed' };
  });
}
function receipt(db, userId, ref) {
  const p = db.prepare('SELECT * FROM payments WHERE ref=?').get(ref); if (!p || (userId && p.user_id !== userId)) throw new HttpError(404, 'not_found', 'Payment not found');
  const meta = JSON.parse(p.meta || '{}'); const u = db.prepare('SELECT name, phone FROM users WHERE id=?').get(p.user_id);
  let committee = null;
  if (p.purpose === 'join' || p.purpose === 'instalment') {
    committee = db.prepare(`SELECT pl.name, pl.currency, m.slot ${p.purpose === 'instalment' ? ', i.seq' : ''} FROM ${p.purpose === 'join' ? 'memberships m' : 'instalments i JOIN memberships m ON m.id=i.membership_id'} JOIN committees c ON c.id=m.committee_id JOIN plans pl ON pl.id=c.plan_id WHERE ${p.purpose === 'join' ? 'm.id' : 'i.id'}=?`).get(p.target_id) || null;
  }
  return { reference: p.ref, date: p.paid_at || p.created_at, status: p.status, purpose: p.purpose, currency: p.currency, method: p.method, cardType: p.card_type, lines: meta.lines || [], total: p.total, denomination: p.denom_currency ? { currency: p.denom_currency, amount: p.denom_amount } : null, conversion: meta.gold || null, committee, payer: { name: u.name, phone: u.phone.slice(0, 4) + '•••••' + u.phone.slice(-3) } };
}

/* ---------------------------- payouts (maker / checker) ---------------------------- */
function runCycle(db, committeeId, month, actor) {
  return tx(db, () => {
    const c = db.prepare('SELECT c.*, pl.amount, pl.months, pl.currency, pl.name FROM committees c JOIN plans pl ON pl.id=c.plan_id WHERE c.id=?').get(committeeId); need(c, 'not_found', 'Committee not found', 404);
    need(Number.isInteger(month) && month >= 1 && month <= c.months, 'invalid_month');
    const members = db.prepare("SELECT * FROM memberships WHERE committee_id=? AND status='active'").all(committeeId);
    need(members.length === c.months, 'committee_not_full', 'Committee is not full yet', 409);
    const unpaid = db.prepare("SELECT m.user_id FROM memberships m JOIN instalments i ON i.membership_id=m.id AND i.seq=? WHERE m.committee_id=? AND m.status='active' AND i.status<>'paid'").all(month, committeeId).map(r => r.user_id);
    if (unpaid.length) throw new HttpError(409, 'unpaid_instalments', 'Some members have not paid this month', { unpaidUserIds: unpaid });
    const winner = members.find(m => m.slot === month); const ex = db.prepare('SELECT * FROM payouts WHERE membership_id=?').get(winner.id); if (ex) return ex;
    const acct = db.prepare('SELECT * FROM payout_accounts WHERE user_id=?').get(winner.user_id); need(acct, 'no_payout_account', 'Recipient has not added a payout account', 409);
    const note = c.currency === 'XAU' ? `Gold committee: ${c.amount * c.months / 1000} g to be settled under the provider's settlement terms. No physical ownership or allocation is implied.` : null;
    const id = db.prepare('INSERT INTO payouts(membership_id,user_id,amount,currency,account,created_by,settlement_note) VALUES(?,?,?,?,?,?,?)').run(winner.id, winner.user_id, c.amount * c.months, c.currency, `${acct.type}:${acct.number}`, actor, note).lastInsertRowid;
    audit(db, actor, 'payout_created', { payoutId: Number(id), committeeId, month });
    notify(db, winner.user_id, 'payout_scheduled', 'Payout scheduled', `Your payout for ${c.name} is being prepared and awaits approval.`, 'po-s-' + id);
    return db.prepare('SELECT * FROM payouts WHERE id=?').get(id);
  });
}
async function approvePayout(db, id, actor) {
  const p0 = db.prepare('SELECT * FROM payouts WHERE id=?').get(id); need(p0, 'not_found', 'Payout not found', 404);
  need(p0.created_by !== actor, 'maker_checker', 'A different staff member must approve this payout', 403);
  need(db.prepare("UPDATE payouts SET status='sending', approved_by=? WHERE id=? AND status='pending_approval'").run(actor, id).changes === 1, 'not_approvable', 'Payout is not waiting for approval', 409);
  const p = db.prepare('SELECT * FROM payouts WHERE id=?').get(id);
  const res = await providers.payouts.send({ account: p.account, amount: p.amount, currency: p.currency, ref: 'PO-' + p.id });
  db.prepare("UPDATE payouts SET status=?, gateway_ref=?, sent_at=CASE WHEN ?=1 THEN datetime('now') END WHERE id=?").run(res.ok ? 'sent' : 'failed', res.gatewayRef ?? null, res.ok ? 1 : 0, id);
  audit(db, actor, res.ok ? 'payout_sent' : 'payout_failed', { id, error: res.error });
  if (res.ok) notify(db, p.user_id, 'payout_processed', 'Payout sent', 'Your payout has been sent to your payout account.', 'po-p-' + id);
  return db.prepare('SELECT * FROM payouts WHERE id=?').get(id);
}

/* ------------------------------------- jobs ------------------------------------- */
function runJobs(db) {
  const t = todayIso();
  const overdue = db.prepare("UPDATE instalments SET status='overdue' WHERE status='due' AND due_date<?").run(t).changes;
  const overdueGold = db.prepare("UPDATE gold_instalments SET status='overdue' WHERE status='due' AND due_date<?").run(t).changes;
  const expired = db.prepare("DELETE FROM memberships WHERE status='pending_payment' AND reserved_until<=datetime('now')").run().changes;
  const soon = db.prepare("SELECT i.id, i.seq, i.due_date, i.amount, i.currency, m.user_id FROM instalments i JOIN memberships m ON m.id=i.membership_id WHERE i.status='due' AND m.status='active' AND i.due_date<=date(?, '+3 days')").all(t);
  for (const i of soon) notify(db, i.user_id, 'contribution_due', 'Contribution due soon', `Instalment ${i.seq} is due on ${i.due_date}.`, 'due-' + i.id);
  return { overdueCommittee: overdue, overdueGold, expiredReservations: expired, remindersQueued: soon.length, imagesPurged: setup.purgeOldImages(db) };
}
module.exports = { CURRENCIES, balance, balances, post, goldInfo, goldValue, goldQuote, slotMap, planCard, feeSummary, reserveSlot, buildOrder, quote, viewPayment, createPayment, markPaid, markFailed, verifyBankTransfer, reversePayment, receipt, runCycle, approvePayout, runJobs, saveUpload: setup.saveUpload, submitKyc: setup.submitKyc, reviewKyc: setup.reviewKyc };
