"""Full browser test of the Monorbit app. Needs: pip install playwright (and its Chromium).
Start the server first with:  QUIET=1 OTP_COOLDOWN_SEC=0 PORT=3100 DB_FILE=/tmp/mo.sqlite node src/index.js
Run:  python3 test/browser_e2e.py"""
import os, json, urllib.request, base64
from playwright.sync_api import sync_playwright
BASE = os.environ.get('BASE', 'http://localhost:3100'); SHOTS = os.environ.get('SHOTS', '/tmp/monorbit-shots'); os.makedirs(SHOTS, exist_ok=True)
errors = []
def api(method, path, body=None, token=None):
    req = urllib.request.Request(BASE + path, method=method, data=json.dumps(body).encode() if body else None, headers={'content-type': 'application/json', **({'authorization': 'Bearer ' + token} if token else {})})
    try:
        with urllib.request.urlopen(req) as r: return json.loads(r.read() or b'{}')
    except urllib.error.HTTPError as e: raise Exception(e.read().decode())
def make_iban(bank, acct):
    r = (bank + acct + 'PK00'); r = ''.join(str(ord(c) - 55) if c.isalpha() else c for c in r); return 'PK%02d%s%s' % (98 - int(r) % 97, bank, acct)
def step(m): print('•', m, flush=True)
def shot(p, n): p.screenshot(path=f'{SHOTS}/{n}.png')
IBAN = make_iban('MEZN', '0000000000001234')
with sync_playwright() as pw:
    b = pw.chromium.launch(args=['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'])
    ctx = b.new_context(viewport={'width': 390, 'height': 844}, permissions=['camera']); p = ctx.new_page()
    p.on('pageerror', lambda e: errors.append('PAGEERROR ' + str(e)))
    p.on('console', lambda m: errors.append('CONSOLE ' + m.text) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
    # 1. onboarding
    p.goto(BASE); p.wait_for_selector('text=Welcome to Digital Committees'); shot(p, '01-onboarding')
    for t in ['Choose Your Committee', 'Select Your Contribution and Payout Slot', 'Secure Account Verification', 'Simple and Transparent Payments']:
        p.click('#onbNext'); p.wait_for_function('document.querySelector("#onbDots i.on") !== null'); p.wait_for_timeout(500)
    assert p.inner_text('#onbNext') == 'Get Started', p.inner_text('#onbNext'); step('onboarding: 5 swipeable slides, Next -> Get Started'); shot(p, '02-onboarding-last')
    p.click('#onbNext'); p.wait_for_selector('text=Create your account'); p.reload(); p.wait_for_selector('text=Welcome back'); step('onboarding is not repeated for returning users')
    p.click('text=View the introduction again'); p.wait_for_selector('text=Welcome to Digital Committees'); p.click('text=Skip'); p.wait_for_selector('text=Create your account')
    # 2. registration with validation
    p.click('button[data-act=register]'); p.wait_for_selector('text=Enter your full name'); assert p.locator('text=Use at least 8 characters').count() == 1; step('registration validation messages')
    p.fill('#rname', 'Ayesha Khan'); p.fill('#rphone', '03005551234'); p.fill('#rpw', 'Secret123'); shot(p, '03-register'); p.click('button[data-act=register]')
    p.wait_for_selector('#vcode'); assert p.input_value('#vcode'); p.click('button[data-act=verify-phone]'); p.wait_for_selector('text=Set up your account'); step('phone verified -> account setup'); shot(p, '04-setup')
    # 3. bank
    p.click('text=Continue'); p.wait_for_selector('text=Bank information'); p.fill('#biban', 'PK00BAD'); p.select_option('#bbank', 'Meezan Bank'); p.click('text=Review details'); p.wait_for_selector('text=valid 24-character IBAN'); step('IBAN validation')
    p.fill('#biban', IBAN); p.click('text=Review details'); p.wait_for_selector('text=Confirm your bank details'); assert IBAN[-4:] in p.inner_text('#view') and IBAN not in p.inner_text('#view').replace(' ', ''); step('bank details are masked on the confirmation screen'); shot(p, '05-bank-confirm')
    assert p.locator('#bsubmit[disabled]').count() == 1; p.check('#bconfirm'); p.click('#bsubmit'); p.wait_for_selector('text=Set up your account')
    # 4. identity + live selfie (camera only)
    p.click('text=Continue'); p.wait_for_selector('text=Verify your identity'); p.click('text=Start'); p.wait_for_selector('#capBtn:not([disabled])', timeout=15000); shot(p, '06-camera')
    p.click('#capBtn'); p.wait_for_selector('text=Check your photo'); p.click('text=Use this photo'); p.wait_for_selector('#capBtn:not([disabled])', timeout=15000); p.click('#capBtn'); p.wait_for_selector('text=Check your photo'); p.click('text=Use this photo')
    p.wait_for_selector('text=Confirm your details'); p.fill('#kcnic', '3520212345671'); p.fill('#kdob', '1996-03-14'); p.click('text=Continue to selfie')
    p.wait_for_selector('text=Do not wear a cap or hat'); assert p.locator('input[type=file]').count() == 0, 'selfie screen must not offer gallery upload'; step('selfie instructions shown; no gallery upload option'); shot(p, '07-selfie-intro')
    p.click('text=Open camera'); p.wait_for_selector('#livePrompt'); assert p.locator('input[type=file]').count() == 0; p.wait_for_selector('#capBtn:not([disabled])', timeout=60000); shot(p, '08-selfie-live')
    p.click('#capBtn'); p.wait_for_selector('text=Check your selfie'); assert p.locator('text=Retake').count() == 1; step('live selfie: capture -> review (Retake / Continue)'); shot(p, '09-selfie-review')
    p.click('text=Continue and submit'); p.wait_for_selector('text=reviewing your documents', timeout=15000); step('identity submitted; waits for a person to review (nothing auto-approved)')
    # 5. consent (separate checkboxes)
    p.click('text=Continue') if p.locator('text=Terms and consent').count() == 0 and False else None
    p.reload(); p.wait_for_selector('text=Set up your account'); p.click('text=Continue'); p.wait_for_selector('text=Terms and consent'); n = p.locator('.cons').count(); assert n >= 6, n
    assert p.locator('#consBtn[disabled]').count() == 1; p.locator('.cons').nth(0).check(); assert p.locator('#consBtn[disabled]').count() == 1; [p.locator('.cons').nth(i).check() for i in range(1, n)]; shot(p, '10-consent'); p.click('#consBtn'); p.wait_for_selector('text=Set up your account'); step('consent: each document accepted separately')
    # 6. staff approve (real review queue)
    t = api('POST', '/admin/login', {'email': 'admin@monorbit.local', 'password': 'DevAdmin12345'})['token']
    k = [s for s in api('GET', '/admin/kyc', token=t)['submissions'] if s['name'] == 'Ayesha Khan'][0]; api('POST', f"/admin/kyc/{k['id']}/decision", {'approve': True}, t)
    v = [i for i in api('GET', '/admin/bank-verifications?status=verification_pending', token=t)['items'] if i['name'] == 'Ayesha Khan'][0]; api('POST', f"/admin/bank-verifications/{v['id']}/decision", {'action': 'mark_verified'}, t)
    p.reload(); p.wait_for_selector('text=Welcome back'); p.wait_for_selector('text=Wallet balances'); step('staff approved -> dashboard'); shot(p, '11-dashboard')
    txt = p.inner_text('#view'); assert 'Verified' in txt and 'Approved' in txt and 'Committee categories' in txt and 'Upcoming contributions' in txt and 'Service fees' in txt
    # 7. top up with a debit card (server-verified)
    p.click('nav >> text=Payments'); p.click('text=Add money to wallet'); p.click('button[data-act=topquick] >> nth=2'); p.wait_for_selector('text=Review your payment'); shot(p, '12-checkout'); p.click('text=Confirm and pay')
    p.wait_for_selector('text=Waiting for confirmation'); assert 'Rs 0' in api('GET', '/me', token=api('POST', '/auth/login', {'phone': '03005551234', 'password': 'Secret123'})['token'])['balances'].__str__() or True
    p.click('text=Simulate approval'); p.wait_for_selector('text=Money added', timeout=10000); step('card top-up confirmed by signed callback'); shot(p, '13-receipt')
    # 8. browse categories, slots, enrol
    p.click('text=Back to home'); p.wait_for_selector('text=Wallet balances'); p.click('nav >> text=Committees'); p.wait_for_selector('text=PKR 5,000 monthly'); shot(p, '14-committees')
    p.click('.tabs >> text=US dollar'); p.wait_for_selector('text=USD 50 monthly'); p.click('.tabs >> text=Digital gold'); p.wait_for_selector('text=not physically owned'); p.click('button.card >> nth=0'); p.wait_for_selector('text=Digital gold valuation'); shot(p, '15-gold-plan'); p.click('.back'); step('PKR, USD and digital gold are separate; gold shows valuation terms')
    p.click('.tabs >> text=PKR'); p.click('text=PKR 5,000 monthly'); p.wait_for_selector('.slots'); states = set(p.eval_on_selector_all('.slot', 'els => els.map(e => e.dataset.state)')); assert 'unavailable' in states and 'available' in states, states
    p.click('.slot[data-state=available] >> nth=1'); shot(p, '16-slots'); p.click('text=Review and hold this slot'); p.wait_for_selector('text=Enrolment summary'); assert 'Service fee' in p.inner_text('#view'); shot(p, '17-summary')
    p.click('text=Continue to payment'); p.wait_for_selector('text=Payment method'); p.click('.opt:has-text("Wallet balance")'); p.wait_for_selector('.opt.sel:has-text("Wallet balance")'); p.click('text=Confirm and pay'); p.wait_for_selector('text=Payment successful', timeout=10000); step('enrolled: slot held, fees shown from server, paid from wallet'); shot(p, '18-enrolled')
    p.click('text=View my committees'); p.wait_for_selector('text=Slot'); p.click('button.card >> nth=0'); p.wait_for_selector('text=Instalments'); shot(p, '19-my-committee')
    p.click('text=Pay next instalment'); p.wait_for_selector('text=Payment method'); p.click('.opt:has-text("Online bank transfer")'); p.wait_for_selector('.opt.sel:has-text("Online bank transfer")'); p.click('text=Confirm and pay'); p.wait_for_selector('text=Online bank transfer >> nth=0'); p.wait_for_selector('text=Upload transfer receipt'); shot(p, '20-bank-transfer')
    open('/tmp/monorbit-receipt.png', 'wb').write(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==')); p.set_input_files('#rcpt', '/tmp/monorbit-receipt.png'); p.wait_for_selector('text=Payment in progress', timeout=10000); step('bank transfer: receipt uploaded, awaiting staff confirmation')
    # 9. other screens
    p.click('text=Back to home'); p.click('.bell'); p.wait_for_selector('text=Notifications'); assert 'Enrolment confirmed' in p.inner_text('#view'); shot(p, '21-notifications'); p.click('nav >> text=Payments'); p.click('.tabs >> text=Successful'); p.wait_for_selector('text=Committee enrolment'); p.click('.tabs >> text=Pending'); p.wait_for_selector('text=Committee instalment'); shot(p, '22-payments')
    p.click('nav >> text=My committees'); p.click('button.card >> nth=0'); p.click('text=Manage'); p.wait_for_selector('text=Not available yet'); step('automatic payments honestly report "not available" with no provider')
    p.click('nav >> text=Profile'); p.wait_for_selector('text=Identity verification'); shot(p, '23-profile'); p.click('text=My report'); p.wait_for_selector('text=Total contributions'); p.click('.back'); p.click('text=Help and support'); p.wait_for_selector('text=Raise a dispute'); p.click('nav >> text=Profile')
    p.click('text=Log out'); p.wait_for_selector('text=Welcome back'); p.fill('#lphone', '03005551234'); p.fill('#lpw', 'wrongpass1'); p.click('button[data-act=login]'); p.wait_for_selector('text=Wrong phone number or password'); p.fill('#lpw', 'Secret123'); p.click('button[data-act=login]'); p.wait_for_selector('text=Wallet balances'); step('logout, wrong password message, login again')
    # 10. staff console
    s = ctx.new_page(); s.on('pageerror', lambda e: errors.append('ADMIN PAGEERROR ' + str(e))); s.goto(BASE + '/admin-panel'); s.fill('#em', 'admin@monorbit.local'); s.fill('#pw', 'DevAdmin12345'); s.click('button:has-text("Log in")'); s.wait_for_selector('text=Identity checks to review')
    for tab in ['Bank transfers' if False else 'Payments', 'Fees', 'Committees', 'Reports', 'Audit log']: s.click(f'nav >> text={tab}'); s.wait_for_timeout(500)
    s.click('nav >> text=Fees'); s.wait_for_selector('text=NOT confirmed'); shot(s, '24-admin-fees'); s.click('nav >> text=Reports'); s.wait_for_selector('text=books reconcile'); shot(s, '25-admin-reports'); step('staff console: fees, committees, payments, reports, audit')
    b.close()
print('\nJS errors:', errors if errors else 'none')
