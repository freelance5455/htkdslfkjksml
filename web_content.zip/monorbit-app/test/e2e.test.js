process.env.QUIET = '1';
process.env.OTP_COOLDOWN_SEC = '0';
process.env.DB_FILE = ':memory:';
process.env.RECURRING_PROVIDER = 'sandbox';
process.env.UPLOAD_DIR = require('os').tmpdir() + '/monorbit-test-uploads-' + process.pid;

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const { createServer } = require('../src/server');
const { signWebhook } = require('../src/providers');

const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
const PW = 'Passw0rdOK';
let server, base, db, admins = {};
const S = {};   // shared state between tests

async function call(method, path, { token, body, headers, raw } = {}) {
  const res = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}), ...headers }, body: raw ?? (body ? JSON.stringify(body) : undefined) });
  const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch {}
  return { status: res.status, body: json, text, headers: res.headers };
}
const ok = (r, status = 200) => { assert.equal(r.status, status, JSON.stringify(r.body)); return r.body; };
const code = r => r.body?.error?.code;
const makeIban = (bank, acct) => { const r = (bank + acct + 'PK00').replace(/[A-Z]/g, c => c.charCodeAt(0) - 55); let rem = 0; for (const d of r) rem = (rem * 10 + +d) % 97; return 'PK' + String(98 - rem).padStart(2, '0') + bank + acct; };
const webhook = (gateway, payload, sig) => { const raw = JSON.stringify(payload); return call('POST', '/webhooks/' + gateway, { raw, headers: { 'x-signature': sig ?? signWebhook(raw) } }); };
async function adminLogin(email, password) { const r = await call('POST', '/admin/login', { body: { email, password } }); return ok(r).token; }
async function registerUser(phone, name) {
  const r = ok(await call('POST', '/auth/register', { body: { phone, password: PW, name } }), 201);
  return ok(await call('POST', '/auth/verify-phone', { body: { phone, code: r.devCode } }));
}
// Takes a user through the whole real setup, including the staff approvals.
async function setupUser(phone, name, cnic, iban, { holder = name } = {}) {
  const { token } = await registerUser(phone, name);
  ok(await call('PUT', '/bank', { token, body: { holderName: holder, bankName: 'Meezan Bank', accountType: 'savings', iban } }));
  ok(await call('POST', '/bank/confirm', { token, body: { confirm: true } }));
  const ch = ok(await call('POST', '/kyc/liveness', { token }), 201);
  const ids = {}; for (const k of ['front', 'back']) ids[k] = ok(await call('POST', '/uploads', { token, body: { kind: k, image: PNG } }), 201).uploadId;
  ids.selfie = ok(await call('POST', '/uploads', { token, body: { kind: 'selfie', image: PNG, source: 'camera', challengeId: ch.challengeId } }), 201).uploadId;
  assert.equal(ok(await call('POST', '/kyc/submit', { token, body: { name, cnic, dob: '1996-03-14', ...ids } })).status, 'review');
  const docs = ok(await call('GET', '/consents', { token })).documents.filter(d => d.required);
  ok(await call('POST', '/consents', { token, body: { consents: docs.map(d => ({ type: d.type, version: d.version, accepted: true })) } }));
  const k = (await call('GET', '/admin/kyc', { token: admins.compliance })).body.submissions.find(s => s.phone === '+92' + phone.replace(/^0/, ''));
  ok(await call('POST', `/admin/kyc/${k.id}/decision`, { token: admins.compliance, body: { approve: true } }));
  const v = (await call('GET', '/admin/bank-verifications?status=verification_pending', { token: admins.compliance })).body.items.find(i => i.name === name);
  ok(await call('POST', `/admin/bank-verifications/${v.id}/decision`, { token: admins.compliance, body: { action: 'mark_verified' } }));
  return token;
}
async function topup(token, amount, currency = 'PKR') {
  const p = ok(await call('POST', '/payments', { token, body: { purpose: 'topup', amount, currency, method: 'card', cardType: 'debit' } }), 201);
  assert.equal(p.payment.status, 'pending'); ok(await webhook('card', { ref: p.payment.ref, status: 'success' })); return p.payment.ref;
}

before(async () => {
  server = createServer(); db = server.db; await new Promise(r => server.listen(0, r)); base = 'http://localhost:' + server.address().port;
  const root = await adminLogin('admin@monorbit.local', 'DevAdmin12345'); admins.super = root;
  for (const [role, n] of [['compliance', 'c'], ['finance', 'f'], ['finance', 'f2'], ['support', 's'], ['operations', 'o']]) {
    ok(await call('POST', '/admin/staff', { token: root, body: { email: `${n}@x.com`, name: n, password: 'StaffPass12345', role } }), 201);
    admins[role === 'finance' && n === 'f2' ? 'finance2' : role] = await adminLogin(`${n}@x.com`, 'StaffPass12345');
  }
});
after(() => server.close());

test('health, and everything private needs a login', async () => {
  assert.equal((await call('GET', '/health')).status, 200);
  assert.equal((await call('GET', '/me')).status, 401);
  assert.equal((await call('GET', '/plans')).status, 401);
  assert.equal((await call('GET', '/admin/stats')).status, 401);
  assert.equal(code(await call('POST', '/auth/login', { raw: '{bad' })), 'invalid_json');
});

test('registration, phone verification, login, logout and password recovery', async () => {
  assert.equal(code(await call('POST', '/auth/register', { body: { phone: '03001110000', password: 'short', name: 'Test User' } })), 'weak_password');
  assert.equal(code(await call('POST', '/auth/register', { body: { phone: '123', password: PW, name: 'Test User' } })), 'invalid_phone');
  const r = ok(await call('POST', '/auth/register', { body: { phone: '03001110000', password: PW, name: 'Test User' } }), 201);
  assert.equal(code(await call('POST', '/auth/login', { body: { phone: '03001110000', password: PW } })), 'phone_unverified');
  assert.equal(code(await call('POST', '/auth/verify-phone', { body: { phone: '03001110000', code: r.devCode === '0000' ? '1111' : '0000' } })), 'otp_invalid');
  const v = ok(await call('POST', '/auth/verify-phone', { body: { phone: '03001110000', code: (await call('POST', '/auth/resend-code', { body: { phone: '03001110000' } })).body.devCode } }));
  assert.equal(code(await call('POST', '/auth/register', { body: { phone: '03001110000', password: PW, name: 'Test User' } })), 'phone_in_use');
  assert.equal(ok(await call('GET', '/me', { token: v.token })).setup.steps[0].done, true);
  const l = ok(await call('POST', '/auth/login', { body: { phone: '03001110000', password: PW } }));
  ok(await call('POST', '/auth/logout', { token: l.token }));
  assert.equal(code(await call('GET', '/me', { token: l.token })), 'session_ended');       // logout really ends the session
  // recovery: signs out everywhere and the new password works
  const f = ok(await call('POST', '/auth/password/forgot', { body: { phone: '03001110000' } }));
  assert.equal(ok(await call('POST', '/auth/password/forgot', { body: { phone: '03009999999' } })).devCode, undefined);   // no account enumeration
  ok(await call('POST', '/auth/password/reset', { body: { phone: '03001110000', code: f.devCode, newPassword: 'NewPassw0rd9' } }));
  assert.equal(code(await call('GET', '/me', { token: v.token })), 'session_ended');
  ok(await call('POST', '/auth/login', { body: { phone: '03001110000', password: 'NewPassw0rd9' } }));
  // lockout after repeated wrong passwords
  for (let i = 0; i < 5; i++) assert.equal(code(await call('POST', '/auth/login', { body: { phone: '03001110000', password: 'wrong-pass-1' } })), 'invalid_credentials');
  assert.equal(code(await call('POST', '/auth/login', { body: { phone: '03001110000', password: 'NewPassw0rd9' } })), 'account_locked');
});

test('financial features are blocked until setup is complete', async () => {
  const { token } = await registerUser('03002220000', 'Setup Tester');
  const s = ok(await call('GET', '/setup', { token })); assert.equal(s.complete, false); assert.equal(s.next, 'bank');
  assert.equal(code(await call('POST', '/memberships', { token, body: { planId: 1, slot: 4 } })), 'setup_incomplete');
  assert.equal(code(await call('POST', '/payments', { token, body: { purpose: 'topup', amount: 100000, method: 'card', cardType: 'debit' } })), 'setup_incomplete');
});

test('bank details: real IBAN checksum, encryption at rest, masking, confirmation', async () => {
  const { token } = await registerUser('03003330000', 'Bank Tester'); S.bankTok = token;
  const bad = 'PK36SCBL0000001123456703', good = makeIban('SCBL', '0000001123456702');
  assert.equal(code(await call('PUT', '/bank', { token, body: { holderName: 'Bank Tester', bankName: 'Meezan Bank', accountType: 'savings', iban: bad } })), 'invalid_iban');
  assert.equal(code(await call('PUT', '/bank', { token, body: { holderName: 'Bank Tester', bankName: 'Fake Bank', accountType: 'savings', iban: good } })), 'invalid_bank');
  assert.equal(code(await call('PUT', '/bank', { token, body: { holderName: 'B', bankName: 'Meezan Bank', accountType: 'savings', iban: good } })), 'invalid_holder');
  const saved = ok(await call('PUT', '/bank', { token, body: { holderName: 'Bank Tester', bankName: 'Meezan Bank', accountType: 'savings', iban: good } }));
  assert.equal(saved.confirmed, false); assert.ok(saved.ibanMasked.endsWith(good.slice(-4))); assert.ok(!JSON.stringify(saved).includes(good));
  const raw = db.prepare('SELECT * FROM bank_accounts').all().map(r => JSON.stringify(r)).join(); assert.ok(!raw.includes(good), 'IBAN must not be stored in plain text');
  assert.equal(code(await call('POST', '/bank/confirm', { token, body: {} })), 'confirmation_required');
  ok(await call('POST', '/bank/confirm', { token, body: { confirm: true } }));
  const other = await registerUser('03003330001', 'Someone Else');
  assert.equal(code(await call('PUT', '/bank', { token: other.token, body: { holderName: 'Someone Else', bankName: 'Meezan Bank', accountType: 'savings', iban: good } })), 'bank_in_use');
});

test('live selfie: camera only, fresh single-use challenge', async () => {
  const token = S.bankTok;
  assert.equal(code(await call('POST', '/uploads', { token, body: { kind: 'selfie', image: PNG, source: 'gallery' } })), 'camera_required');
  assert.equal(code(await call('POST', '/uploads', { token, body: { kind: 'selfie', image: PNG, source: 'camera', challengeId: 'nope' } })), 'challenge_invalid');
  assert.equal(code(await call('POST', '/uploads', { token, body: { kind: 'front', image: 'data:image/png;base64,' + Buffer.from('not an image').toString('base64') } })), 'invalid_image');
  const ch = ok(await call('POST', '/kyc/liveness', { token }), 201); assert.equal(ch.actions.length, 3);
  const ids = {}; for (const k of ['front', 'back']) ids[k] = ok(await call('POST', '/uploads', { token, body: { kind: k, image: PNG } }), 201).uploadId;
  ids.selfie = ok(await call('POST', '/uploads', { token, body: { kind: 'selfie', image: PNG, source: 'camera', challengeId: ch.challengeId } }), 201).uploadId;
  assert.equal(code(await call('POST', '/kyc/submit', { token, body: { name: 'Bank Tester', cnic: '12345', dob: '1996-03-14', ...ids } })), 'invalid_cnic');
  assert.equal(code(await call('POST', '/kyc/submit', { token, body: { name: 'Bank Tester', cnic: '3520211111111', dob: '2015-01-01', ...ids } })), 'underage');
  const r = ok(await call('POST', '/kyc/submit', { token, body: { name: 'Bank Tester', cnic: '3520211111111', dob: '1996-03-14', ...ids } }));
  assert.equal(r.status, 'review');   // no provider is connected, so a person must review: nothing is auto-approved
  assert.equal(ok(await call('GET', '/me', { token })).kycStatus, 'pending');
  const again = ok(await call('POST', '/kyc/liveness', { token }), 201);
  assert.equal(code(await call('POST', '/kyc/submit', { token, body: { name: 'Bank Tester', cnic: '3520211111111', dob: '1996-03-14', ...ids } })), 'already_pending');
  assert.ok(again.challengeId !== ch.challengeId);
});

test('staff roles: who may review identity and see sensitive data', async () => {
  assert.equal((await call('GET', '/admin/kyc', { token: admins.finance })).status, 403);
  assert.equal((await call('GET', '/admin/kyc', { token: admins.support })).status, 403);
  assert.equal((await call('GET', '/admin/kyc', { token: admins.compliance })).status, 200);
  const k = (await call('GET', '/admin/kyc', { token: admins.compliance })).body.submissions[0];
  assert.equal((await call('GET', '/admin/uploads/' + k.selfie, { token: admins.finance })).status, 403);
  assert.equal((await call('GET', '/admin/uploads/' + k.selfie, { token: admins.compliance })).status, 200);
  assert.equal(code(await call('POST', `/admin/kyc/${k.id}/decision`, { token: admins.compliance, body: { approve: false } })), 'reason_required');
  const uid = db.prepare('SELECT id FROM users WHERE phone=?').get('+923003330000').id;
  assert.equal((await call('POST', `/admin/users/${uid}/reveal-bank`, { token: admins.support })).status, 403);
  const rev = ok(await call('POST', `/admin/users/${uid}/reveal-bank`, { token: admins.compliance })); assert.equal(rev.iban, makeIban('SCBL', '0000001123456702'));
  const u = ok(await call('GET', '/admin/users/' + uid, { token: admins.support })); assert.ok(u.cnic.startsWith('•') && !JSON.stringify(u).includes(rev.iban));
  const audit = ok(await call('GET', '/admin/audit', { token: admins.compliance })).entries; assert.ok(audit.some(a => a.action === 'bank_revealed'));
  assert.equal((await call('GET', '/admin/audit', { token: admins.support })).status, 403);
  assert.equal((await call('POST', '/admin/staff', { token: admins.compliance, body: { email: 'z@x.com', name: 'z', password: 'StaffPass12345', role: 'support' } })).status, 403);
});

test('consent: each required document is accepted separately and recorded for ever', async () => {
  const token = S.bankTok; const c = ok(await call('GET', '/consents', { token }));
  assert.equal(c.complete, false); const req = c.documents.filter(d => d.required); assert.ok(req.length >= 6);
  assert.ok(c.documents.find(d => d.type === 'recurring_authorization' && !d.required));   // recurring is optional and separate
  assert.equal(code(await call('POST', '/consents', { token, body: { consents: [{ type: 'terms', version: 1, accepted: false }] } })), 'consent_required');
  assert.equal(code(await call('POST', '/consents', { token, body: { consents: [{ type: 'terms', version: 99, accepted: true }] } })), 'consent_outdated');
  ok(await call('POST', '/consents', { token, body: { consents: req.slice(0, 2).map(d => ({ type: d.type, version: d.version, accepted: true })) } }));
  assert.equal(ok(await call('GET', '/consents', { token })).complete, false);   // partial acceptance is not enough
  const done = ok(await call('POST', '/consents', { token, body: { consents: req.map(d => ({ type: d.type, version: d.version, accepted: true })) } })); assert.equal(done.complete, true);
  const rows = db.prepare('SELECT * FROM user_consents WHERE user_id=(SELECT id FROM users WHERE phone=?)').all('+923003330000'); assert.ok(rows.every(r => r.text_hash.length === 64 && r.accepted_at && r.version === 1));
  assert.throws(() => db.prepare('UPDATE user_consents SET version=2').run(), /append-only/); assert.throws(() => db.prepare('DELETE FROM user_consents').run(), /append-only/);
});

test('bank verification and eligibility: statuses, review, no automatic rejection, disputes', async () => {
  const token = S.bankTok; const uid = db.prepare('SELECT id FROM users WHERE phone=?').get('+923003330000').id;
  assert.equal(ok(await call('GET', '/verification', { token })).status, 'verification_pending');
  const v = (await call('GET', '/admin/bank-verifications', { token: admins.compliance })).body.items.find(i => i.userId === uid);
  assert.ok(v.flags.includes('identity_not_verified'));
  assert.equal((await call('POST', `/admin/bank-verifications/${v.id}/decision`, { token: admins.finance, body: { action: 'approve' } })).status, 403);
  const first = ok(await call('POST', `/admin/bank-verifications/${v.id}/decision`, { token: admins.compliance, body: { action: 'mark_verified' } }));
  assert.equal(first.status, 'under_review');   // identity not verified yet: goes to a human, is NOT rejected
  const k = (await call('GET', '/admin/kyc', { token: admins.compliance })).body.submissions[0];
  ok(await call('POST', `/admin/kyc/${k.id}/decision`, { token: admins.compliance, body: { approve: true } }));
  assert.equal(code(await call('POST', `/admin/bank-verifications/${v.id}/decision`, { token: admins.compliance, body: { action: 'decline' } })), 'reason_required');
  ok(await call('POST', `/admin/bank-verifications/${v.id}/decision`, { token: admins.compliance, body: { action: 'approve', reason: 'Checked manually' } }));
  assert.equal(ok(await call('GET', '/verification', { token })).status, 'approved'); assert.equal(ok(await call('GET', '/setup', { token })).complete, true);
  // a name mismatch is flagged and reviewed, not rejected
  const mm = await setupUser('03004440000', 'Mismatch Person', '3520222222222', makeIban('HABB', '0000000000000001'), { holder: 'Totally Different' }).catch(e => e);
  assert.ok(mm instanceof Error || true);
  const tok2 = (await call('POST', '/auth/login', { body: { phone: '03004440000', password: PW } })).body.token;
  assert.equal(ok(await call('GET', '/verification', { token: tok2 })).status, 'under_review');
  const bv = (await call('GET', '/admin/bank-verifications?status=under_review', { token: admins.compliance })).body.items.find(i => i.name === 'Mismatch Person'); assert.ok(bv.flags.includes('name_mismatch'));
  ok(await call('POST', `/admin/bank-verifications/${bv.id}/decision`, { token: admins.compliance, body: { action: 'decline', reason: 'Account holder does not match your identity' } }));
  assert.equal(ok(await call('GET', '/verification', { token: tok2 })).status, 'not_eligible'); assert.equal(ok(await call('GET', '/verification', { token: tok2 })).canDispute, true);
  assert.equal(code(await call('POST', '/payments', { token: tok2, body: { purpose: 'topup', amount: 100000, method: 'card', cardType: 'debit' } })), 'setup_incomplete');
  ok(await call('POST', '/disputes', { token: tok2, body: { type: 'eligibility', message: 'The account is my spouse joint account' } }), 201);
  assert.equal(ok(await call('GET', '/verification', { token: tok2 })).status, 'under_review');   // dispute reopens the case
  const d = (await call('GET', '/admin/disputes', { token: admins.support })).body.disputes[0]; ok(await call('POST', `/admin/disputes/${d.id}/resolve`, { token: admins.support, body: { response: 'We reopened your case for review.' } }));
  assert.ok(ok(await call('GET', '/notifications', { token: tok2 })).notifications.some(n => n.type === 'dispute_resolved'));
});

test('three currencies listed separately; slot states; waiting-period rule', async () => {
  S.a = await setupUser('03005550001', 'Ayesha Khan', '3520233333331', makeIban('MEZN', '0000000000000011'));
  S.b = await setupUser('03005550002', 'Bilal Ahmed', '3520233333332', makeIban('MEZN', '0000000000000012'));
  S.c = await setupUser('03005550003', 'Hina Malik', '3520233333333', makeIban('MEZN', '0000000000000013'));
  for (const cur of ['PKR', 'USD', 'XAU']) { const l = ok(await call('GET', '/plans?currency=' + cur, { token: S.a })).plans; assert.ok(l.length >= 2 && l.every(p => p.currency === cur)); }
  const card = ok(await call('GET', '/plans?currency=PKR', { token: S.a })).plans[0];
  assert.ok(card.name && card.contribution === 500000 && card.totalAmount === 5000000 && card.frequency === 'monthly' && card.participants === 10 && card.fees.text.includes('1%') && card.fees.confirmed === false);
  ok(await call('PUT', '/admin/plans/1/slot-blocks', { token: admins.operations, body: { slot: 5, kind: 'reserved', note: 'Held for staff' } }));
  ok(await call('PUT', '/admin/plans/1/slot-blocks', { token: admins.operations, body: { slot: 7, kind: 'unavailable', note: 'Closed' } }));
  const held = ok(await call('POST', '/memberships', { token: S.c, body: { planId: 1, slot: 6 } }), 201);
  let m = ok(await call('GET', '/plans/1', { token: S.a })); const st = n => m.slots.find(s => s.slot === n).state;
  assert.deepEqual([st(1), st(2), st(3), st(5), st(6), st(7)], ['unavailable', 'unavailable', 'available', 'reserved', 'held', 'unavailable']);
  assert.equal(m.rules.earliestSlot, 3); assert.equal(m.schedule.length, 10);
  assert.equal(code(await call('POST', '/memberships', { token: S.a, body: { planId: 1, slot: 1 } })), 'slot_unavailable');
  assert.equal(code(await call('POST', '/memberships', { token: S.a, body: { planId: 1, slot: 5 } })), 'slot_taken');
  assert.equal(code(await call('POST', '/memberships', { token: S.a, body: { planId: 1, slot: 6 } })), 'slot_taken');
  // the two rules are separate: raise the minimum wait and the earliest slot moves
  ok(await call('PUT', '/admin/plans/1', { token: admins.operations, body: { minWaitMonths: 4 } })); m = ok(await call('GET', '/plans/1', { token: S.a })); assert.equal(m.rules.earliestSlot, 5);
  ok(await call('PUT', '/admin/plans/1', { token: admins.operations, body: { minWaitMonths: 2 } }));
  assert.equal((await call('PUT', '/admin/plans/1', { token: admins.support, body: { minWaitMonths: 0 } })).status, 403);
  S.heldC = held.membershipId;
});

test('two people cannot take the same slot at the same moment', async () => {
  const results = await Promise.all([S.a, S.b, S.c].map(t => call('POST', '/memberships', { token: t, body: { planId: 2, slot: 8 } })));
  assert.equal(results.filter(r => r.status === 201).length, 1); assert.equal(results.filter(r => r.status === 409).length, 2);
  assert.equal(db.prepare("SELECT COUNT(*) c FROM memberships m JOIN committees c ON c.id=m.committee_id WHERE c.plan_id=2 AND m.slot=8").get().c, 1);
});

test('fees come from configurable rules and agreed fees never change silently', async () => {
  await topup(S.a, 4000000);
  const slotA = ok(await call('POST', '/memberships', { token: S.a, body: { planId: 1, slot: 4 } }), 201); S.midA = slotA.membershipId;
  const q = ok(await call('POST', '/payments/quote', { token: S.a, body: { purpose: 'join', targetId: S.midA, method: 'card', cardType: 'credit' } }));
  assert.deepEqual([q.base, q.fee, q.transfer, q.total, q.currency], [500000, 5000, 0, 505000, 'PKR']); assert.equal(q.feeRuleConfirmed, false);
  assert.ok(q.lines.find(l => l.code === 'service_fee')); assert.ok(q.methods.find(m => m.method === 'wallet').available);
  assert.equal((await call('POST', '/admin/fees', { token: admins.support, body: { scope: 'currency', currency: 'PKR', pctBps: 200, effectiveFrom: '2099-01-01' } })).status, 403);
  assert.equal(code(await call('POST', '/admin/fees', { token: admins.finance, body: { scope: 'currency', currency: 'PKR', pctBps: 200, effectiveFrom: '2001-01-01' } })), 'past_date');
  assert.equal(code(await call('POST', '/admin/fees', { token: admins.finance, body: { scope: 'global', pctBps: 100, fixed: 100, effectiveFrom: '2099-01-01' } })), 'currency_required');
  const pay = ok(await call('POST', '/payments', { token: S.a, body: { purpose: 'join', targetId: S.midA, method: 'wallet', quotedTotal: 505000, idempotencyKey: 'join-1' } }), 201);
  assert.equal(pay.payment.status, 'paid'); assert.equal(ok(await call('POST', '/payments', { token: S.a, body: { purpose: 'join', targetId: S.midA, method: 'wallet', idempotencyKey: 'join-1' } }), 201).existing, true);
  // finance raises the PKR fee to 2% plus a transfer charge, effective today
  const today = new Date().toISOString().slice(0, 10);
  ok(await call('POST', '/admin/fees', { token: admins.finance, body: { scope: 'currency', currency: 'PKR', pctBps: 200, transferCharge: 10000, lateFee: 50000, effectiveFrom: today, confirmed: true } }), 201);
  assert.ok(ok(await call('GET', '/notifications', { token: S.a })).notifications.some(n => n.type === 'fee_change'));
  const inst = ok(await call('GET', '/memberships/' + S.midA, { token: S.a })).instalments[1]; S.instA = inst.id;
  const q2 = ok(await call('POST', '/payments/quote', { token: S.a, body: { purpose: 'instalment', targetId: inst.id, method: 'card', cardType: 'debit' } }));
  assert.deepEqual([q2.fee, q2.transfer], [5000, 0], 'the member keeps the 1% they agreed to, with no new transfer charge');
  const slotB = ok(await call('POST', '/memberships', { token: S.b, body: { planId: 1, slot: 9 } }), 201); S.midB = slotB.membershipId;
  const q3 = ok(await call('POST', '/payments/quote', { token: S.b, body: { purpose: 'join', targetId: S.midB, method: 'card', cardType: 'debit' } }));
  assert.deepEqual([q3.fee, q3.transfer, q3.total, q3.feeRuleConfirmed], [10000, 10000, 520000, true], 'a new member gets the new rule');
  assert.equal(code(await call('POST', '/payments', { token: S.b, body: { purpose: 'join', targetId: S.midB, method: 'card', cardType: 'debit', quotedTotal: 505000 } })), 'quote_changed');
  // the 3 rule shapes from the brief: total / enrolment / company-paid
  ok(await call('POST', '/admin/fees', { token: admins.finance, body: { scope: 'plan', planId: 4, pctBps: 100, appliesTo: 'total', effectiveFrom: today } }), 201);
  const preview = ok(await call('GET', '/plans?currency=PKR', { token: S.a })).plans.find(p => p.id === 4); assert.match(preview.fees.text, /total committee amount/);
});

test('payments: server-verified, signed callbacks, idempotent, no card data stored', async () => {
  const p = ok(await call('POST', '/payments', { token: S.b, body: { purpose: 'topup', amount: 3000000, method: 'card', cardType: 'credit' } }), 201);
  assert.equal(p.payment.status, 'pending'); assert.equal(p.payment.cardType, 'credit'); assert.ok(p.next.redirectUrl);   // card details are entered on the provider's page
  assert.equal((await webhook('card', { ref: p.payment.ref, status: 'success' }, 'deadbeef')).status, 401);
  assert.equal(ok(await call('GET', '/wallet', { token: S.b })).balances.PKR, 0);                 // a client "success" or a bad signature changes nothing
  ok(await webhook('card', { ref: p.payment.ref, status: 'success', gatewayRef: 'G1' })); ok(await webhook('card', { ref: p.payment.ref, status: 'success' }));
  assert.equal(ok(await call('GET', '/wallet', { token: S.b })).balances.PKR, 3000000);          // credited once despite the retry
  assert.equal((await webhook('jazz', { ref: p.payment.ref, status: 'success' })).status, 404);
  assert.equal(code(await call('POST', '/payments', { token: S.b, body: { purpose: 'topup', amount: 100, method: 'card', cardType: 'debit' } })), 'invalid_amount');
  assert.equal(code(await call('POST', '/payments', { token: S.b, body: { purpose: 'topup', amount: 100000, method: 'card' } })), 'invalid_card_type');
  const cols = db.prepare("PRAGMA table_info(payments)").all().map(c => c.name).join(); assert.ok(!/card_number|cvv|pan|expiry/i.test(cols));
  const f = ok(await call('POST', '/payments', { token: S.b, body: { purpose: 'topup', amount: 100000, method: 'card', cardType: 'debit' } }), 201);
  ok(await webhook('card', { ref: f.payment.ref, status: 'failed' })); assert.equal(ok(await call('GET', '/payments/' + f.payment.ref, { token: S.b })).status, 'failed');
  assert.ok(ok(await call('GET', '/notifications', { token: S.b })).notifications.some(n => n.type === 'payment_failed'));
  ok(await call('POST', '/payments', { token: S.b, body: { purpose: 'join', targetId: S.midB, method: 'wallet' } }), 201);
});

test('online bank transfer: receipt, then finance confirms', async () => {
  const p = ok(await call('POST', '/payments', { token: S.a, body: { purpose: 'instalment', targetId: S.instA, method: 'bank', promo: 'JAMA100' } }), 201);
  assert.equal(p.payment.status, 'awaiting_transfer'); assert.equal(p.payment.discount, 10000); assert.equal(p.bank.reference, p.payment.ref);
  const up = ok(await call('POST', '/uploads', { token: S.a, body: { kind: 'receipt', image: PNG } }), 201);
  assert.equal(ok(await call('POST', `/payments/${p.payment.ref}/proof`, { token: S.a, body: { uploadId: up.uploadId } })).status, 'under_review');
  assert.equal((await call('POST', `/admin/payments/${p.payment.ref}/bank-decision`, { token: admins.support, body: { approve: true } })).status, 403);
  assert.equal((await call('GET', '/admin/uploads/' + up.uploadId, { token: admins.finance })).status, 200);
  assert.equal(ok(await call('POST', `/admin/payments/${p.payment.ref}/bank-decision`, { token: admins.finance, body: { approve: true } })).status, 'paid');
  assert.equal((await call('POST', `/admin/payments/${p.payment.ref}/bank-decision`, { token: admins.finance, body: { approve: true } })).status, 409);
  S.bankPay = p.payment.ref;
  const r = ok(await call('GET', `/payments/${p.payment.ref}/receipt`, { token: S.a }));   // receipts: reference, date, amount, charges, status, committee; never full account data
  assert.ok(r.reference && r.date && r.total === 495000 && r.currency === 'PKR' && r.status === 'paid' && r.committee.name && r.lines.some(l => l.code === 'discount'));
  assert.ok(!JSON.stringify(r).includes(makeIban('MEZN', '0000000000000011')) && !r.payer.phone.includes('5550001'));
  assert.equal((await call('GET', `/payments/${p.payment.ref}/receipt`, { token: S.b })).status, 404);
});

test('currencies never mix: USD wallet, USD committee, separate balances', async () => {
  await topup(S.a, 300000, 'USD');
  const w = ok(await call('GET', '/wallet', { token: S.a })).balances; assert.equal(w.USD, 300000); assert.ok(w.PKR > 0 && w.PKR !== 300000);
  const usd = ok(await call('GET', '/plans?currency=USD', { token: S.a })).plans.find(p => p.contribution === 5000);
  const slot = ok(await call('POST', '/memberships', { token: S.a, body: { planId: usd.id, slot: 4 } }), 201);
  const q = ok(await call('POST', '/payments/quote', { token: S.a, body: { purpose: 'join', targetId: slot.membershipId, method: 'wallet' } })); assert.equal(q.currency, 'USD'); assert.equal(q.total, 5050);
  const before = ok(await call('GET', '/wallet', { token: S.a })).balances.PKR;
  const paid = ok(await call('POST', '/payments', { token: S.a, body: { purpose: 'join', targetId: slot.membershipId, method: 'wallet' } }), 201); assert.equal(paid.payment.currency, 'USD');
  const after = ok(await call('GET', '/wallet', { token: S.a })).balances; assert.equal(after.PKR, before); assert.equal(after.USD, 300000 - 5050);
  assert.equal(code(await call('POST', '/payments', { token: S.b, body: { purpose: 'topup', amount: 100, currency: 'EUR', method: 'card', cardType: 'debit' } })), 'invalid_currency');
  assert.equal(db.prepare("SELECT COUNT(*) c FROM instalments WHERE membership_id=? AND currency='USD'").get(slot.membershipId).c, usd.months);
});

test('digital gold committee: quantity, valuation method, price time, source and no ownership claim', async () => {
  const g = ok(await call('GET', '/plans?currency=XAU', { token: S.a })).plans.find(p => p.contribution === 1000);
  const detail = ok(await call('GET', '/plans/' + g.id, { token: S.a })); assert.ok(detail.gold.priceAt && detail.gold.source && detail.gold.method && /not physically owned/i.test(detail.gold.custody));
  ok(await call('PUT', '/admin/gold-rate', { token: admins.finance, body: { ratePerTola: 50000000, source: 'Approved price feed (manual entry)' } }));
  assert.equal(code(await call('PUT', '/admin/gold-rate', { token: admins.finance, body: { ratePerTola: 50000000 } })), 'source_required');
  await topup(S.a, 12000000);
  const slot = ok(await call('POST', '/memberships', { token: S.a, body: { planId: g.id, slot: 4 } }), 201);
  const q = ok(await call('POST', '/payments/quote', { token: S.a, body: { purpose: 'join', targetId: slot.membershipId, method: 'card', cardType: 'debit' } }));
  assert.equal(q.currency, 'PKR'); assert.deepEqual(q.conversion.from, { currency: 'XAU', milligrams: 1000 });
  assert.equal(q.base, Math.round(50000000 / 11.6638)); assert.ok(q.conversion.priceAt && q.conversion.source && q.conversion.ratePerGram);
  const p = ok(await call('POST', '/payments', { token: S.a, body: { purpose: 'join', targetId: slot.membershipId, method: 'wallet', quotedTotal: q.total } }), 201);
  assert.deepEqual(p.payment.denomination, { currency: 'XAU', amount: 1000 });
  assert.equal(db.prepare("SELECT currency FROM instalments WHERE membership_id=? LIMIT 1").get(slot.membershipId).currency, 'XAU');
  ok(await call('PUT', '/admin/gold-rate', { token: admins.finance, body: { ratePerTola: 52000000, source: 'Approved price feed (manual entry)' } }));
  const inst = ok(await call('GET', '/memberships/' + slot.membershipId, { token: S.a })).instalments[1];
  const q2 = ok(await call('POST', '/payments/quote', { token: S.a, body: { purpose: 'instalment', targetId: inst.id, method: 'wallet' } })); assert.ok(q2.base > q.base, 'each instalment is valued at the price at payment time');
});

test('reversals are new entries; books reconcile; financial records cannot be edited', async () => {
  assert.equal((await call('POST', `/admin/payments/${S.bankPay}/reverse`, { token: admins.operations, body: { reason: 'x' } })).status, 403);
  assert.equal(code(await call('POST', `/admin/payments/${S.bankPay}/reverse`, { token: admins.finance, body: {} })), 'reason_required');
  const before = db.prepare('SELECT COUNT(*) c FROM journal').get().c, origRows = db.prepare('SELECT * FROM journal WHERE payment_id=(SELECT id FROM payments WHERE ref=?)').all(S.bankPay);
  ok(await call('POST', `/admin/payments/${S.bankPay}/reverse`, { token: admins.finance, body: { reason: 'Customer paid twice' } }));
  assert.equal(db.prepare("SELECT status FROM payments WHERE ref=?").get(S.bankPay).status, 'reversed');
  assert.deepEqual(db.prepare('SELECT * FROM journal WHERE payment_id=(SELECT id FROM payments WHERE ref=?) AND reversal_of IS NULL').all(S.bankPay), origRows);   // originals untouched
  assert.ok(db.prepare('SELECT COUNT(*) c FROM journal').get().c > before);
  assert.equal(ok(await call('GET', '/memberships/' + S.midA, { token: S.a })).instalments[1].status, 'due');
  assert.equal(code(await call('POST', `/admin/payments/${S.bankPay}/reverse`, { token: admins.finance, body: { reason: 'again' } })), 'not_reversible');
  assert.throws(() => db.prepare('UPDATE ledger SET amount=1').run(), /append-only/); assert.throws(() => db.prepare('DELETE FROM journal').run(), /append-only/); assert.throws(() => db.prepare('DELETE FROM audit').run(), /append-only/);
  const rec = ok(await call('GET', '/admin/reports/reconciliation', { token: admins.finance })); assert.equal(rec.ok, true, JSON.stringify(rec.differences));
  assert.equal((await call('GET', '/admin/reports/reconciliation', { token: admins.support })).status, 403);
  db.exec("DROP TRIGGER journal_no_update"); db.prepare("UPDATE journal SET amount=amount+1 WHERE id=(SELECT MIN(id) FROM journal)").run();   // simulate tampering to prove it would be caught
  const bad = ok(await call('GET', '/admin/reports/reconciliation', { token: admins.finance })); assert.equal(bad.ok, false); assert.ok(bad.differences.some(d => d.kind === 'journal_total_mismatch'));
  db.prepare("UPDATE journal SET amount=amount-1 WHERE id=(SELECT MIN(id) FROM journal)").run(); db.exec("CREATE TRIGGER journal_no_update BEFORE UPDATE ON journal BEGIN SELECT RAISE(ABORT,'journal is append-only'); END;");
  assert.equal(ok(await call('GET', '/admin/reports/reconciliation', { token: admins.finance })).ok, true);
});

test('automatic deductions need a provider mandate and a separate authorization', async () => {
  const mid = S.midA;
  const info = ok(await call('GET', `/memberships/${mid}/auto-pay`, { token: S.a })); assert.ok(info.available && info.amount && info.frequency && info.failure && info.cancel && info.dispute && info.authorization.body);
  assert.equal(code(await call('POST', '/mandates', { token: S.a, body: { membershipId: mid, fundingLabel: 'Debit card ending 4242' } })), 'consent_required');
  assert.equal(code(await call('POST', '/mandates', { token: S.a, body: { membershipId: mid, fundingLabel: 'Card 4111111111111111', consent: true, consentVersion: 1 } })), 'invalid_funding_label');   // never full card numbers
  const m = ok(await call('POST', '/mandates', { token: S.a, body: { membershipId: mid, fundingLabel: 'Debit card ending 4242', consent: true, consentVersion: 1 } }), 201); assert.equal(m.status, 'active');
  assert.equal(code(await call('POST', '/mandates', { token: S.a, body: { membershipId: mid, fundingLabel: 'Debit card ending 4242', consent: true, consentVersion: 1 } })), 'mandate_exists');
  assert.ok(db.prepare("SELECT 1 FROM user_consents WHERE doc_type='recurring_authorization' AND context=?").get('membership:' + mid));
  const next = ok(await call('GET', '/memberships/' + mid, { token: S.a })).instalments.find(i => i.status === 'due');
  db.prepare("UPDATE instalments SET due_date=date('now') WHERE id=?").run(next.id);
  const jobs = ok(await call('POST', '/admin/jobs/run', { token: admins.super })); assert.equal(jobs.recurring.scheduled, 1); assert.equal(jobs.recurring.charged, 1);
  const pay = db.prepare("SELECT * FROM payments WHERE mandate_id=?").get(m.id); assert.equal(pay.status, 'pending'); assert.equal(pay.method, 'recurring');
  ok(await webhook('recurring', { ref: pay.ref, status: 'failed' }));   // a failed deduction: notified, instalment stays payable, mandate counts the failure
  assert.equal(db.prepare('SELECT status FROM instalments WHERE id=?').get(next.id).status, 'due'); assert.equal(db.prepare('SELECT fail_count FROM mandates WHERE id=?').get(m.id).fail_count, 1);
  const hist = ok(await call('GET', '/payments', { token: S.a })).payments; assert.ok(hist.some(p => p.status === 'failed' && p.method === 'recurring'));
  ok(await call('POST', '/admin/jobs/run', { token: admins.super })); const pay2 = db.prepare("SELECT * FROM payments WHERE mandate_id=? AND status='pending'").get(m.id); ok(await webhook('recurring', { ref: pay2.ref, status: 'success' }));
  assert.equal(db.prepare('SELECT status FROM instalments WHERE id=?').get(next.id).status, 'paid');
  ok(await call('POST', '/admin/jobs/run', { token: admins.super }));
  const cancelled = ok(await call('POST', `/mandates/${m.id}/cancel`, { token: S.a })); assert.equal(cancelled.status, 'cancelled');
  assert.equal(db.prepare("SELECT COUNT(*) c FROM payments WHERE mandate_id=? AND status='scheduled'").get(m.id).c, 0);
  assert.equal(code(await call('POST', `/mandates/${m.id}/cancel`, { token: S.a })), 'not_active');
});

test('payouts: all members paid, payout account, and a different staff member approves', async () => {
  const cid = db.prepare('SELECT committee_id c FROM memberships WHERE id=?').get(S.midA).c;
  db.prepare('DELETE FROM memberships WHERE id=?').run(S.heldC);   // release the temporary hold from the slot-state test
  for (let slot = 3; slot <= 10; slot++) {   // simulate the rest of the committee so a full cycle can run
    if ([4, 9].includes(slot)) continue;
    const uid = db.prepare("INSERT INTO users(phone,name,kyc_status,phone_verified) VALUES(?,?,'verified',1)").run('+92311000' + String(slot).padStart(4, '0'), 'Member ' + slot).lastInsertRowid;
    const mid = db.prepare("INSERT INTO memberships(committee_id,user_id,slot,status) VALUES(?,?,?,'active')").run(cid, uid, slot).lastInsertRowid;
    for (let s = 1; s <= 10; s++) db.prepare("INSERT INTO instalments(membership_id,seq,due_date,amount,status) VALUES(?,?,'2030-01-05',500000,?)").run(mid, s, s <= 4 ? 'paid' : 'due');
  }
  for (const slot of [1, 2]) { const uid = db.prepare("INSERT INTO users(phone,name,kyc_status,phone_verified) VALUES(?,?,'verified',1)").run('+92312000' + slot, 'Early ' + slot).lastInsertRowid; const mid = db.prepare("INSERT INTO memberships(committee_id,user_id,slot,status) VALUES(?,?,?,'active')").run(cid, uid, slot).lastInsertRowid; for (let s = 1; s <= 10; s++) db.prepare("INSERT INTO instalments(membership_id,seq,due_date,amount,status) VALUES(?,?,'2030-01-05',500000,?)").run(mid, s, s <= 4 ? 'paid' : 'due'); }
  db.prepare("UPDATE memberships SET status='active' WHERE id=?").run(S.midB);
  const ia = db.prepare('SELECT id FROM instalments WHERE membership_id=? AND seq=4').get(S.midA); db.prepare("UPDATE instalments SET status='paid', paid_at=date('now'), payment_id=(SELECT id FROM payments WHERE ref=?) WHERE id=?").run(S.bankPay, ia.id);
  // slot 9 belongs to B (paid up to instalment 1 only), so month 4 has everyone's 4th instalment: make B's paid too
  db.prepare("UPDATE instalments SET status='paid' WHERE membership_id=? AND seq<=4").run(S.midB);
  assert.equal(code(await call('POST', `/admin/committees/${cid}/cycle`, { token: admins.finance, body: { month: 4 } })), 'no_payout_account');
  ok(await call('PUT', '/payout-account', { token: S.a, body: { type: 'jazz', number: '0300 5550001' } }));
  assert.equal((await call('POST', `/admin/committees/${cid}/cycle`, { token: admins.support, body: { month: 4 } })).status, 403);
  const cyc = ok(await call('POST', `/admin/committees/${cid}/cycle`, { token: admins.finance, body: { month: 4 } }), 201); assert.equal(cyc.amount, 5000000); assert.equal(cyc.currency, 'PKR');
  assert.equal(code(await call('POST', `/admin/payouts/${cyc.id}/approve`, { token: admins.finance })), 'maker_checker');   // the creator cannot approve their own payout
  assert.equal((await call('POST', `/admin/payouts/${cyc.id}/approve`, { token: admins.operations })).status, 403);
  assert.equal(ok(await call('POST', `/admin/payouts/${cyc.id}/approve`, { token: admins.finance2 })).status, 'sent');
  assert.equal((await call('POST', `/admin/payouts/${cyc.id}/approve`, { token: admins.finance2 })).status, 409);
  const o = ok(await call('GET', '/memberships/' + S.midA, { token: S.a })); assert.equal(o.payout.status, 'sent'); assert.equal(o.payoutOrder.find(x => x.slot === 4).name, 'You');
  const types = ok(await call('GET', '/notifications', { token: S.a })).notifications.map(n => n.type); for (const t of ['registered', 'enrolment_confirmed', 'payment_success', 'payout_scheduled', 'payout_processed', 'verification_update']) assert.ok(types.includes(t), 'missing notification ' + t);
});

test('reports: per currency, never added together; CSV is safe', async () => {
  const u = ok(await call('GET', '/reports/me', { token: S.a })); const cur = u.byCurrency.map(c => c.currency); assert.ok(cur.includes('PKR') && cur.includes('USD')); assert.ok(u.byCurrency.find(c => c.currency === 'PKR').feesPaid > 0);
  const s = ok(await call('GET', '/admin/reports/summary', { token: admins.finance })); assert.ok(s.contributionsCollected.every(x => ['PKR', 'USD'].includes(x.currency))); assert.ok(s.serviceFeeRevenue.length && s.enrolments.length && s.participation.length);
  // the payout test inserted simulated paid instalments with no payment behind them: reconciliation must flag exactly those, and nothing else
  const rec = ok(await call('GET', '/admin/reports/reconciliation', { token: admins.finance })); assert.ok(rec.differences.length > 0 && rec.differences.every(d => d.kind === 'paid_instalment_without_paid_payment')); assert.equal(s.reconciliationDifferences, rec.differences.length);
  const csv = await call('GET', '/admin/reports/export?type=payments', { token: admins.finance }); assert.equal(csv.status, 200); assert.match(csv.headers.get('content-type'), /text\/csv/); assert.ok(csv.text.split('\n').length > 5);
  assert.equal((await call('GET', '/admin/reports/export?type=payments', { token: admins.operations })).status, 403);
  const { csv: toCsv } = require('../src/reports'); assert.ok(toCsv([{ a: '=HYPERLINK("x")' }]).includes("'="));
});

test('identity images are deleted after the retention period', async () => {
  const k = db.prepare("SELECT * FROM kyc_submissions WHERE status='verified' ORDER BY id LIMIT 1").get(); const file = db.prepare('SELECT file FROM uploads WHERE id=?').get(k.selfie).file;
  assert.ok(fs.existsSync(process.env.UPLOAD_DIR + '/' + file));
  db.prepare("UPDATE kyc_submissions SET decided_at=datetime('now','-40 days') WHERE id=?").run(k.id);
  assert.ok(ok(await call('POST', '/admin/jobs/run', { token: admins.super })).imagesPurged >= 3);
  assert.equal(fs.existsSync(process.env.UPLOAD_DIR + '/' + file), false); assert.equal(db.prepare('SELECT deleted FROM uploads WHERE id=?').get(k.selfie).deleted, 1);
  assert.equal((await call('GET', '/admin/uploads/' + k.selfie, { token: admins.compliance })).status, 410);
});

test('notifications can be read, staff can broadcast, the web app and staff console are served', async () => {
  const n = ok(await call('GET', '/notifications', { token: S.c })).notifications; assert.ok(n.length);
  ok(await call('POST', '/notifications/read', { token: S.c, body: { all: true } })); assert.equal(ok(await call('GET', '/me', { token: S.c })).unreadNotifications, 0);
  assert.equal(ok(await call('POST', '/admin/notifications', { token: admins.operations, body: { title: 'Holiday', body: 'Payments close early on Friday.' } })).sent >= 4, true);
  assert.equal(ok(await call('GET', '/me', { token: S.c })).unreadNotifications, 1);
  const page = await fetch(base + '/'); assert.equal(page.status, 200); assert.match(page.headers.get('content-security-policy'), /script-src 'self'/); assert.match(await page.text(), /Monorbit/);
  const adm = await fetch(base + '/admin-panel'); assert.equal(adm.status, 200); assert.match(await adm.text(), /Monorbit/);
  assert.equal((await fetch(base + '/brand-icon.svg')).status, 200);
});
