# Requirements status, integrations and open decisions

Legend: **Done** = built and covered by automated tests · **Needs outside access** = built and ready to connect, but cannot work until you hold the credentials or approval · **Decision** = the business owner must confirm a value.

## 1. What was built, by requirement
| # | Requirement | Status | Where |
|---|---|---|---|
| 1 | Onboarding: 5 swipeable slides, progress dots, Skip / Next / Get Started, shown once, replayable from Profile | Done (browser-tested) | `web/app.js` (onboarding) |
| 2 | Registration, phone verification, login, password recovery, lockout, sessions that really end on logout, step-by-step setup | Done. **Email verification is not built** (phone is used) | `src/auth.js` |
| 3 | Bank form: validation incl. real IBAN checksum, encrypted at rest (AES-256-GCM), masked display, confirmation screen, purpose explained, no credentials stored | Done | `src/setup.js`, `src/lib.js` |
| 4 | Live selfie: camera only (no file input on that screen, server rejects non-camera source), instructions, Capture / Retake / Continue, fresh single-use challenge, lighting check, permission-denied handling, retention deletion | Done. **Real liveness and face matching need a provider** | `src/setup.js` |
| 5 | Consent: 6 separate required documents + separate optional recurring authorization; version, time, hash, IP recorded; append-only | Done. **Texts are drafts for your lawyer** | `src/consent.js`, `src/db.js` |
| 6 | Bank verification and eligibility: all 7 statuses, configurable rules, human review, dispute flow, no automatic rejection | Done as a staff review workflow. **No State Bank of Pakistan or bank API is connected** | `src/setup.js` |
| 7 | PKR, USD and digital gold committees; separate balances; explicit currency codes; gold shows quantity, rate, source, price time, method, no ownership claim | Done. **Gold price is entered by staff**; an authorised feed is needed | `src/services.js` |
| 8 | Dashboard with all listed items and 8 navigation areas | Done | `web/app.js` |
| 9 | Committee cards, detail, schedule, 5 slot states, waiting-period rules, server-side transactions, race-safe booking, enrolment summary | Done (concurrency test included) | `src/services.js` |
| 10 | Debit card, credit card, online bank transfer; quote > confirm > provider > server verification > receipt; idempotency; no card data stored | Done against a **sandbox gateway**. Real gateways need merchant accounts | `src/providers`, `src/services.js` |
| 11 | Automatic deductions: separate authorization, explanation, scheduled / failed / cancelled states, cancel and dispute | Built end to end with a **sandbox provider**. With no provider the app says "not available" | `src/recurring.js` |
| 12 | Fee rules: percent, fixed, transfer, min / max, currency, payer, effective date, per plan or currency; agreed fees frozen per member | Done. **Values are unconfirmed** | `src/fees.js` |
| 13 | Staff console with roles (superadmin, compliance, finance, operations, support), audit log, payout maker-checker | Done | `admin/`, `src/auth.js` |
| 14 | Notifications and receipts (no full account numbers) | In-app done. **Email / SMS notifications need providers** (hook in `src/notify.js`) | |
| 15 | User and admin reports by currency, append-only ledger and journal, reversals as new entries, reconciliation that detects tampering, CSV export | Done | `src/reports.js` |
| 16 | Security: hashing, encryption, rate limits, validation, strict CSP, audit, image checks, retention | Done in code. **Backups, key vault, HTTPS hosting are your deployment tasks** | |
| 17 | UI quality: responsive, empty / loading / error states, accessible controls | Done | |

## 2. Outside integrations you must arrange
1. **Identity verification and liveness provider** (for example a NADRA-authorised partner). Implement `kyc.submit` and `liveness.check` in `src/providers/index.js`.
2. **Bank verification / State Bank of Pakistan or bank service.** Confirm you are allowed to use one before building. Implement `bank.submit`. Until then staff verify manually.
3. **Payment gateways** for debit and credit cards and for online bank transfer: merchant accounts, hosted checkout, each gateway's real signature scheme in `verifyWebhook`.
4. **Recurring-payment provider and bank mandate.** A signed consent alone does not allow deductions from a bank account. Set `RECURRING_PROVIDER` once an approved one exists.
5. **SMS provider** (OTP and alerts) and optionally an email provider.
6. **Gold price feed** from an authorised source. Today staff enter the rate with its source and time.
7. **Payout channel** (bank / wallet payout API) in `providers.payouts`.
The server refuses to start in production while a `mock` or `sandbox` provider is selected.

## 3. Business decisions needed before launch
- **Service fee:** the 1% in the system is a working proposal flagged "unconfirmed". Decide: percentage, whether it applies to each instalment, the enrolment payment, or the total committee amount, any fixed or transfer charges, minimum and maximum, and who pays.
- **Waiting period and first payout:** stored as two separate settings (default 2 and 3 months). The earliest selectable slot is the later of the two. Confirm what each means.
- **Late fee, cancellation and refund terms**, dispute response time, and the eligibility rules shown to members.
- **Gold custody and settlement model**: what the member actually receives, and when.
- **Refunds** currently go to the member's wallet; refunds to the original card or bank are handled by hand.
- **Retention period** for identity photos (default 30 days after a decision).

## 4. Legal and compliance (before any real money)
Get qualified advice on: the committee model and whether it needs SECP or State Bank of Pakistan approval or licences; holding member funds or gold; payment processing; recurring deductions; consumer disclosures and the consent texts. The app does not claim approval from the State Bank of Pakistan or any bank, and says so in Profile.

## 5. Known limits
- SQLite is suited to a pilot on one server. Move to PostgreSQL before scaling and add scheduled backups and a restore test.
- The rate limiter is in memory (use Redis with more than one server).
- This is a mobile **web app** (installable PWA). A Play Store / App Store version can wrap it.
- The earlier "buy gold in instalments" screens were replaced by digital gold committees (the server still supports the old plans).
- The database structure changed: delete the old `data` folder when upgrading from the first version (no live data existed).
- Existing users' staff passwords: change the bootstrap password after first login.

## 6. Test results
- `npm test`: 21 backend tests (accounts, setup gating, bank encryption, selfie rules, consent, eligibility, slots and concurrency, fees, payments, currencies, gold, reversals, reconciliation, recurring, payouts, reports, retention, role permissions).
- `python3 test/browser_e2e.py`: full browser run on a phone-sized screen with a simulated camera: onboarding, registration, bank, ID photos, live selfie, consent, staff approval, top-up, enrolment, bank transfer, all dashboard screens, staff console.
