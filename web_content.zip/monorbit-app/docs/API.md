# API notes
Bodies are JSON. Money is integer minor units with an explicit currency (PKR = paisa, USD = cents, XAU = milligrams of gold). Member routes use `Authorization: Bearer <token>`; staff routes use a staff token from `POST /admin/login` and are limited by role.
Errors look like `{"error":{"code":"slot_taken","message":"..."}}`.

**Accounts** `POST /auth/register`, `/auth/verify-phone`, `/auth/resend-code`, `/auth/login`, `/auth/logout`, `/auth/password/forgot`, `/auth/password/reset`, `GET /me`
**Setup** `GET /setup`, `GET|PUT /bank`, `POST /bank/confirm`, `POST /kyc/liveness`, `POST /uploads`, `POST /kyc/submit`, `GET|POST /consents`, `GET /verification`, `POST /disputes`
**Committees** `GET /plans?currency=`, `GET /plans/:id` (slots, rules, schedule, gold info), `POST /memberships`, `GET /memberships[/:id]`
**Payments** `POST /payments/quote`, `POST /payments`, `GET /payments`, `GET /payments/:ref[/receipt]`, `POST /payments/:ref/proof`, `GET /wallet`
 methods: `debit`, `credit`, `bank`, `wallet`; send `quotedTotal` so a changed price is rejected with `quote_changed`.
**Automatic payments** `GET /memberships/:id/auto-pay`, `POST /mandates`, `GET /mandates`, `POST /mandates/:id/cancel`
**Other** `GET /notifications`, `POST /notifications/read`, `GET /reports/me`, `GET|PUT /payout-account`, `GET /gold/rate`
**Gateway callbacks** `POST /webhooks/:gateway` with `x-signature` (HMAC-SHA256 of the raw body). Development only: `POST /dev/gateway/confirm`.
**Staff** `POST /admin/login`, then (by role) `/admin/stats`, `/admin/users`, `/admin/kyc`, `/admin/bank-verifications`, `/admin/plans`, `/admin/fees`, `/admin/payments`, `/admin/payouts`, `/admin/disputes`, `/admin/notifications`, `/admin/reports/*`, `/admin/audit`, `/admin/settings`, `/admin/staff`
