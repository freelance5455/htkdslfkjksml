NutriLife AI 1.0 — prototipo interattivo

Apri index.html con il browser per vedere il design e usare ricette, menu settimanale, lista della spesa e bozze locali.

NON è ancora un APK/IPA. Non contiene AI funzionante: per collegare Gemini serve un backend che custodisca la chiave API, mai inserirla nel codice pubblico o nell'APK.

Non inserire dati reali di pazienti/clienti: la sezione professionista è una demo senza autenticazione o protezione dei dati sanitari.

Per pubblicazione GitHub Pages: carica i file in un repository, abilita Pages nelle impostazioni. Per app Android nativa serve una successiva fase di packaging/build.
