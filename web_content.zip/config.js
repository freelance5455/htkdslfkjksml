/*
  تنظیم اتصال آنلاین:
  1) از داشبورد Supabase، Project URL و anon/public key را بگیرید.
  2) مقادیر زیر را جایگزین کنید.
  هرگز service_role key یا رمز دیتابیس را در این فایل قرار ندهید.
*/
window.KF_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_PUBLIC_KEY",
  TABLE_PRODUCTS: "products"
};