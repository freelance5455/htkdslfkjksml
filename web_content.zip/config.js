// ============================================
// CONFIGURACIÓN DE NAVI AI
// ============================================
// Cambia la URL por la de tu backend (el que creamos abajo).
// Ejemplo local: http://localhost:3000/chat
// Ejemplo en internet: https://tu-servidor.com/chat

window.NAVI_CONFIG = {
  API_URL: "http://localhost:3000/chat"   // ← Cambia esto por tu URL real
};
