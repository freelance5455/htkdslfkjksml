/* CONFIGURAÇÃO OPCIONAL DO SUPABASE
   1. Copie a URL do projeto e a chave publishable/anon do Supabase.
   2. Cole nos campos abaixo.
   3. NUNCA coloque a secret key ou service_role key no aplicativo.
*/
window.APP_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",
  ADMIN_EMAILS: [] // e-mails autorizados no painel de administração
};