// Add your deployed backend URL here. Never put an API key here.
window.GBA_CONFIG={API_URL:""};