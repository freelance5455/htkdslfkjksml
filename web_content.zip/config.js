// Udaan - Supabase config (anon key public hoti hai, ye safe hai)
window.UDAAN_CONFIG = {
  SUPABASE_URL: "https://jxpjnweutqcjmygyktwb.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp4cGpud2V1dHFjam15Z3lrdHdiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI4MzMzMDYsImV4cCI6MjEwODQwOTMwNn0.OS2LRgjlwwbqM-Mg2CbFLBdpyZxV7ilmSZdk4pct8aA"
};
