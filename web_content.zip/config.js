/*
  S Sanskar AI configuration.
  IMPORTANT: Do not put the API key in this file if you are going to share the APK.
  The app lets you enter it from Settings and stores it locally on the device.
*/
window.SSANSKAR_CONFIG = {
  defaultModel: "gemini-3.8-flash",
  appName: "S Sanskar AI",
  creator: "Aryan tiwari"
};
