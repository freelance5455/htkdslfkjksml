// Supabase → Project Settings → API. The anon key is public by design; security comes from RLS in schema.sql.
const CFG = { url: 'https://YOUR-PROJECT.supabase.co', key: 'YOUR-ANON-KEY', testMode: true };
