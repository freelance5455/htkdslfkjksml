// Public browser configuration only. Never put Supabase service_role or LiveKit API Secret here.
window.FRIENDSHIP_CONFIG = {
  supabaseUrl: "https://xgolvfwygwsmoefwdexw.supabase.co",
  supabasePublishableKey: "sb_publishable_LruPWj_qsEtN_W1VpKHC5Q_G-aHaQIp",
  livekitUrl: "wss://friendship-q5tdo0oe.livekit.cloud",
  // Your deployed Edge Function slug is currently "quick-task".
  livekitTokenFunction: "quick-task"
};