window.CONFIG = {
  // Customer site er SOMAN Supabase URL ar anon key boshao
  SUPABASE_URL: "https://jinxwzscogqubawzikxr.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_Gp2h13d2zT5GYZH_ne9Htw_enF06l0-",
  CURRENCY: "৳"
};
