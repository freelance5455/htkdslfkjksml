// OPCIONAL: preencha aqui (ou deixe vazio e digite as chaves dentro do app, na primeira abertura).
window.PINTUGE_CONFIG = {
  SUPABASE_URL: "",       // ex.: https://xxxx.supabase.co
  SUPABASE_ANON_KEY: ""   // chave anon/publishable (NUNCA a service_role)
};
