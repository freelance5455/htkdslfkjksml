window.CFG={url:'https://VOTRE-PROJET.supabase.co',key:'VOTRE_CLE_PUBLIQUE_ANON'};
