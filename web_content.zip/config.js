// Firebase konfiguratsiyasi — Taksi App
export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyCn536bxfjmOqrnHG1NOoKK-gXs_DMJ-UA",
  authDomain: "taksopar.firebaseapp.com",
  projectId: "taksopar",
  storageBucket: "taksopar.firebasestorage.app",
  messagingSenderId: "708849227707",
  appId: "1:708849227707:web:b1d65d1f9524fd4d25169e",
  measurementId: "G-2K06TH80KM"
};

export const APP_CONFIG = {
  appName: "Taksi",
  city: "Toshkent",
  center: [41.3111, 69.2797],
  contact: "+998",
  driverRadiusKm: 5,
  locationIntervalMs: 10000
};
