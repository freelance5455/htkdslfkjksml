// GH MARKETPLACE public client configuration. Use ONLY the public publishable/anon key.
window.GHMP_CONFIG = {
  url: 'https://mosnokxglrgcwvvqpeyd.supabase.co',
  key: 'sb_publishable_E4v-cQM-45MR_1mz26aOqQ_x9qZ5cZk'
};
