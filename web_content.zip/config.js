/* آدرس پشتیبان ایتازبان. از قبل پر شده است؛ لازم نیست چیزی را عوض کنی. */
window.EITAZABAN_API = "https://eitazaban.jungle-jupiter.workers.dev";
