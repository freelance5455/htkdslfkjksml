// Supabase > Project Settings > API theke ei duita value boshao
window.CONFIG = {
  SUPABASE_URL: "https://jinxwzscogqubawzikxr.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_Gp2h13d2zT5GYZH_ne9Htw_enF06l0-",
  // Customer ra ei number gulote "Send Money" korbe (nijer number boshao)
  PAY_NUMBERS: {
    bkash: "01338810296",
    nagad: "01338810296",
    rocket: "013388102962",
    upay: "01338810296"
  },
  HELPLINES: ["09643868624", "09638875879"],
  CURRENCY: "৳"
};
