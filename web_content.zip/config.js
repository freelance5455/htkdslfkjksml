// TPH-X Flight Radar non-secret application configuration
const CONFIG = {
    // Points to your real backend deployment address
    API_BASE_URL: window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1' 
        ? 'http://127.0.0.1:8000' 
        : 'https://tph-x-radar-backend.onrender.com', // Replace with production URL when deployed
    POLL_INTERVAL_MS: 10000, // 10 seconds refresh rate
    STALE_THRESHOLD_MS: 30000, // 30 seconds without updates marks data as stale
    INITIAL_COORDS: [50.7, -3.5],
    INITIAL_ZOOM: 7
};
