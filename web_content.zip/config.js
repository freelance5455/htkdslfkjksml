// ضع مفتاح FreeModel API بين علامتي الاقتباس بالأسفل. لا تضعه داخل واجهة التطبيق.
// مثال: FREEMODEL_API_KEY: "fm_xxxxxxxxx"
window.NOOR_CONFIG = {
  FREEMODEL_API_KEY: "PASTE_YOUR_API_KEY_HERE"
};
