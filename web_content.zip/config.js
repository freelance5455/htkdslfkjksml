// Tweak the world here. Reload the page to apply.
// Pick a region of Ethiopia: edit `region` below, or add ?region=simien to the page address.
// Biomes (grass, farms, desert, trees, animals) follow the REAL altitude of the place you pick.
const REGIONS = {
  bluenile:  { lat: 11.4896, lon: 37.5909, name: 'Blue Nile Falls (Tis Abay)' },   // gorge + falls, ~1800 m, farmland and eucalyptus
  simien:    { lat: 13.2300, lon: 38.0700, name: 'Simien Mountains' },            // huge escarpments, up to 4500 m, giant lobelia
  bale:      { lat: 6.8300,  lon: 39.8200, name: 'Bale Mountains / Sanetti' },    // 4000 m afroalpine plateau, heath
  lalibela:  { lat: 12.0300, lon: 39.0400, name: 'Lalibela highlands' },
  entoto:    { lat: 9.0800,  lon: 38.7600, name: 'Addis Ababa / Entoto' },
  tana:      { lat: 11.9500, lon: 37.3200, name: 'Lake Tana' },
  aksum:     { lat: 14.1200, lon: 38.7200, name: 'Aksum plateau' },
  rift:      { lat: 7.6000,  lon: 38.7000, name: 'Rift Valley lakes (Langano)' },
  omo:       { lat: 5.5000,  lon: 36.0000, name: 'Lower Omo valley (hot savanna)' },
  dallol:    { lat: 14.2400, lon: 40.3000, name: 'Danakil / Dallol (below sea level desert)' },
  harar:     { lat: 9.3100,  lon: 42.1200, name: 'Harar' }
};
const _q = new URLSearchParams(location.search).get('region');
const REGION = _q && REGIONS[_q] ? _q : 'bluenile';

const _la = parseFloat(new URLSearchParams(location.search).get('lat')), _lo = parseFloat(new URLSearchParams(location.search).get('lon'));
const CUSTOM = isFinite(_la) && isFinite(_lo) ? { lat: _la, lon: _lo, name: 'Chosen place in Ethiopia' } : null;   // set by clicking the big map on the pause screen

window.CFG = {
  real: CUSTOM || REGIONS[REGION],   // set real: null for the fully generated world
  region: REGION,
  seed: 7,            // change for a different world
  size: 4800,         // size of the loaded piece of land in metres; Ethiopia is loaded around you as you walk
  seg: 400,           // terrain resolution (higher = prettier, slower)
  trees: 6500,
  rocks: 700,
  waterLevel: 0,
  walk: 4.2, sprint: 8.5, crouch: 2.0,   // m/s
  jump: 6.2, gravity: 20, eye: 1.7,
  dayLength: 300,     // real seconds per in-game day
  startHour: 17,
  relics: 10,         // (relics now sit on 10 real Ethiopian heritage sites)
  wolves: 8,          // hunting hyenas (name kept for compatibility)
  fov: 70,            // field of view
  sens: 0.0022        // mouse sensitivity
};
