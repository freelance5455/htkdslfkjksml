/* Optional: paste your Google OAuth Client ID here once, then redeploy. (It can also be pasted inside the app: Profile > Cloud backup.) */
window.VD_CONFIG={googleClientId:''};
