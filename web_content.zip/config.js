// Inserisci qui le credenziali PUBLIC di un progetto Supabase.
// Non inserire MAI una service_role key nel frontend.
export const SUPABASE_URL = "INCOLLA_QUI_URL";
export const SUPABASE_ANON_KEY = "INCOLLA_QUI_ANON_KEY";
