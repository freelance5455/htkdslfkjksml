/*
JARVIS configuration.
IMPORTANT: Do NOT put a real ElevenLabs API key in this file if the project will be shared.
A key embedded in an APK can be extracted.

For production, use a small backend that keeps the ElevenLabs key secret.
*/
window.JARVIS_CONFIG = {
  aiEndpoint: "",
  elevenLabsBackend: "",
  voiceId: "JBFqnCBsd6RMkjVDRZzb",
  modelId: "eleven_multilingual_v2",
  outputFormat: "mp3_44100_128"
};
