// Public Supabase browser key only; do not put service keys or passwords here.
window.STORE_CONFIG = {
  supabaseUrl: 'https://blyzxraexhnrixameiuo.supabase.co',
  supabaseAnonKey: 'sb_publishable_jp6GH0Wiz63lNQbNnbMqjg_AxomNstq',
  currency: 'ر.س',
  allowDemoCheckout: false,
};
