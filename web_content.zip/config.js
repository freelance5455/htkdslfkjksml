// Tempel URL Web App Google Apps Script (berakhiran /exec) supaya SEMUA HP pembeli tersinkron.
// Contoh: window.SERVER_URL='https://script.google.com/macros/s/AKfycbzz3loPNMA5W-y_QDKmmbtm3PHgsEAAspHDLakY3kRcneNC8c9nG2to5iVed93HBYACnA/exec';
if(!window.SERVER_URL)window.SERVER_URL='';
