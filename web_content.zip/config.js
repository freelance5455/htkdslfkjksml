// Paste the two values from Supabase → Project Settings → API.
// Use the "anon / public" key ONLY. Never put the service_role key here.
window.LEDGER_CONFIG = {
  SUPABASE_URL: 'YOUR_SUPABASE_URL',
  SUPABASE_ANON_KEY: 'YOUR_SUPABASE_ANON_KEY'
};
