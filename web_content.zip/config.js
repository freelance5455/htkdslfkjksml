window.WS_CONFIG={supabaseUrl:'https://uqkjevqvntihbmsswqvh.supabase.co',syncEndpoint:'https://uqkjevqvntihbmsswqvh.supabase.co/functions/v1/wonder-shift-sync'};
