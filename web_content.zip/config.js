// OPTION A (private, needs hosting): address of your hosted Xenhana backend.
// Example: 'https://xenhana-ai.onrender.com'. Leave '' on Termux/localhost.
window.XA_API = '';

// OPTION B (no backend, easiest for an APK): paste your Gemini API key between the quotes.
// Warning: anyone who unpacks the APK can read this key. Keep the APK private.
// Leave '' to use the backend instead.
window.XA_KEY = 'AQ.Ab8RN6IgNbipJqfb-b3wN9wa5B7LUz3f1JhgsrFDcaSUCa2Kiw';

// BACKUP AI (Groq): used only when Gemini is overloaded. Paste a Groq key here, or leave ''.
window.XA_GROQ_KEY = '';

// BACKUP (optional): a free Groq key from console.groq.com. Used only when Gemini is overloaded.
// It answers text only (no photos or files). Leave '' to turn the backup off.
window.XA_GROQ = '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';
