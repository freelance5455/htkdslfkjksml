/*
 * CONFIGURATION
 * 1) Crée un compte API-Football.
 * 2) Copie ta clé dans API_KEY.
 * 3) Ne publie jamais une clé personnelle dans une application distribuée.
 */
window.PRONOSTICS_CONFIG = {
  API_KEY: "703955d9845eb4bab73cbee1deaa2a58",
  API_BASE: "https://v3.football.api-sports.io",
  TIMEZONE: "Africa/Abidjan",
  LANGUAGE: "fr"
};
