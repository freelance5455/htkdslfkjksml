// ضع بيانات مشروع Supabase هنا بعد إنشاء المشروع.
// لا تضع service_role key في تطبيق المتصفح مطلقاً. استخدم anon/publishable key فقط مع RLS.
export const SUPABASE_URL = '';
export const SUPABASE_ANON_KEY = '';
