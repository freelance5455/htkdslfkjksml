window.KSP_CONFIG = {
  SUPABASE_URL: '',
  SUPABASE_PUBLISHABLE_KEY: '',
  PAYMENT_PAGE_URL: 'https://paystack.shop/pay/n-9eic-9vp',
  PAYMENT_API_URL: '',
  PREMIUM_AMOUNT_NGN: 1500
};
