// ===== আপনার Supabase তথ্য এখানে বসান =====
window.SUPABASE_URL='https://wxztghwauomfwdcbxagj.supabase.co';
window.SUPABASE_ANON_KEY='sb_publishable_Z3_I9wYclJ8-6xZfuBMqpg_pvlrLUwR';
// ==========================================
