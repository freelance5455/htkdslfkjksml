// إعداد الاتصال المباشر بقاعدة Supabase — لا يوجد اتصال بـ Netlify.
// استبدل القيم التالية من لوحة مشروعك في Supabase.
window.YALLA_CONFIG = {
  SUPABASE_URL: "https://YOUR_PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY",
  MATCHES_TABLE: "match_overrides"
};
