// Set this to your secure backend endpoint after you deploy it.
// Example: API_URL: "https://your-domain.example/api/chat"
// NEVER put a private AI-provider API key in this file.
window.GBA_CONFIG = { API_URL: "" };