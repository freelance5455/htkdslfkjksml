// Complete these two values after creating the KILILA project in Supabase.
// NEVER put a service_role/secret key here. Use only the public/publishable/anon key.
window.KILILA_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: "",
  branchName: "KILILA",
  businessDays: [4,5,6,0], // Thursday, Friday, Saturday, Sunday
  timezone: "America/Argentina/Buenos_Aires",
  paymentAlias: "kilila.mp"
};
