// WONDER SHIFT — configuration client
window.WS_CONFIG = {
  supabaseUrl: 'https://uqkjevqvntihbmsswqvh.supabase.co',
  supabaseAnonKey: 'sb_publishable_s1Ur9_ZxIoqySs6hYFTaLQ_bbTZYYHI'
};
