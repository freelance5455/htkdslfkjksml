// Configuración V5 - Entre Ríos Fly Fishing
// Publishable key de Supabase. No usar service_role/secret aquí.
window.ER_CONFIG = {
  SUPABASE_URL: "https://jpttvnfpmwgbcrbkmwa.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_FLYqfcxBtGHyaA0gqNStnW_gz8jI1QH"
};
