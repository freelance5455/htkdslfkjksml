// Адрес вашего backend-сервера (где запущен apps/server), БЕЗ слэша в конце.
// Пример: "https://chat.example.com". Пусто = тот же домен, где лежит PWA.
window.VORTEX_SERVER_URL = "";
