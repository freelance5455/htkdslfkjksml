Diaco Forex - mobile-friendly HTML prototype

Open index.html in a modern browser.
Included: chart analysis form with selectable instrument logos, risk calculator, journal, account performance charts, appearance-only settings.
The market watchlist has been removed. Instrument logos are representative emoji/flags, not official brand assets. Quotes and broker/AI integrations are not live or connected. Journal and appearance preferences use browser local storage.
