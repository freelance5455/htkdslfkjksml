import React, { useState, useEffect } from 'react';
import { Language, ThemeMode, TextSize, ActiveTab } from './types';
import { Header } from './components/Header';
import { TabsNav } from './components/TabsNav';
import { AboutSchoolTab } from './components/AboutSchoolTab';
import { AccessibleToolsTab } from './components/AccessibleToolsTab';
import { StudyRightsTab } from './components/StudyRightsTab';
import { Footer } from './components/Footer';
import { VoiceCommandAssistant } from './components/VoiceCommandAssistant';
import { speakText, triggerHaptic } from './utils/speech';
import { Volume2, Sparkles, AlertCircle } from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('hi');
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(true);
  const [themeMode, setThemeMode] = useState<ThemeMode>('normal');
  const [textSize, setTextSize] = useState<TextSize>('normal');
  const [activeTab, setActiveTab] = useState<ActiveTab>('about');
  const [announcement, setAnnouncement] = useState<string>('');

  // Synchronize document title and lang
  useEffect(() => {
    document.documentElement.lang = lang;
    if (lang === 'hi') {
      document.title = 'स्पर्श साथी | Sparsh Saathi - स्पर्श राजकीय दृष्टिबाधित इंटर कॉलेज, गोरखपुर';
    } else {
      document.title = 'Sparsh Saathi | स्पर्श साथी - Sparsh Govt Inter College, Gorakhpur';
    }
  }, [lang]);

  // Apply theme classes to body
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('dark', 'theme-high-contrast');

    if (themeMode === 'dark') {
      root.classList.add('dark');
    } else if (themeMode === 'yellow-contrast') {
      root.classList.add('theme-high-contrast');
    }
  }, [themeMode]);

  // Keyboard shortcut support (Alt + 1 / 2 / 3 for tabs, Alt + L for language)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey) {
        if (e.key === '1') {
          e.preventDefault();
          setActiveTab('about');
          triggerHaptic(20);
          if (voiceEnabled) speakText(lang === 'hi' ? 'हमारा विद्यालय टैब' : 'About School tab', lang);
        } else if (e.key === '2') {
          e.preventDefault();
          setActiveTab('tools');
          triggerHaptic(20);
          if (voiceEnabled) speakText(lang === 'hi' ? 'उपयोगी टूल्स टैब' : 'Accessible Tools tab', lang);
        } else if (e.key === '3') {
          e.preventDefault();
          setActiveTab('knowledge');
          triggerHaptic(20);
          if (voiceEnabled) speakText(lang === 'hi' ? 'ज्ञान एवं संदर्भ टैब' : 'Study & Rights tab', lang);
        } else if (e.key.toLowerCase() === 'l') {
          e.preventDefault();
          setLang((prev) => (prev === 'hi' ? 'en' : 'hi'));
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lang, voiceEnabled]);

  // Text size classes
  const getTextSizeClass = () => {
    switch (textSize) {
      case 'large':
        return 'text-lg';
      case 'extralarge':
        return 'text-xl';
      default:
        return 'text-base';
    }
  };

  const handleLanguageToggle = () => {
    setLang((prev) => (prev === 'hi' ? 'en' : 'hi'));
  };

  const handleVoiceToggle = () => {
    setVoiceEnabled((prev) => !prev);
  };

  const handleThemeToggle = () => {
    setThemeMode((prev) => {
      if (prev === 'normal') return 'yellow-contrast';
      if (prev === 'yellow-contrast') return 'dark';
      return 'normal';
    });
  };

  return (
    <div
      className={`min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors ${getTextSizeClass()}`}
    >
      {/* Live Region for Screen Readers (TalkBack / NVDA / VoiceOver) */}
      <div className="sr-only" aria-live="polite" aria-atomic="true">
        {announcement}
      </div>

      {/* Header */}
      <Header
        lang={lang}
        onLanguageToggle={handleLanguageToggle}
        voiceEnabled={voiceEnabled}
        onVoiceToggle={handleVoiceToggle}
        themeMode={themeMode}
        onThemeToggle={handleThemeToggle}
        textSize={textSize}
        onTextSizeChange={setTextSize}
      />

      {/* Main Container */}
      <main id="main-content" tabIndex={-1} className="flex-1 max-w-5xl w-full mx-auto px-4 py-5 space-y-6">
        {/* Navigation Tabs Bar */}
        <TabsNav
          activeTab={activeTab}
          onTabChange={setActiveTab}
          lang={lang}
          voiceEnabled={voiceEnabled}
        />

        {/* Tab 1: हमारा विद्यालय (About School) */}
        {activeTab === 'about' && (
          <AboutSchoolTab lang={lang} voiceEnabled={voiceEnabled} />
        )}

        {/* Tab 2: उपयोगी टूल्स (Accessible Daily Tools) */}
        {activeTab === 'tools' && (
          <AccessibleToolsTab lang={lang} voiceEnabled={voiceEnabled} />
        )}

        {/* Tab 3: ज्ञान एवं संदर्भ (Study & Rights) */}
        {activeTab === 'knowledge' && (
          <StudyRightsTab lang={lang} voiceEnabled={voiceEnabled} />
        )}
      </main>

      {/* Voice Command Assistant Floating Widget */}
      <VoiceCommandAssistant
        lang={lang}
        onTabChange={setActiveTab}
        onLanguageToggle={handleLanguageToggle}
        voiceEnabled={voiceEnabled}
      />

      {/* Footer */}
      <Footer lang={lang} voiceEnabled={voiceEnabled} />
    </div>
  );
}
