import { Language } from '../types';

let currentUtterance: SpeechSynthesisUtterance | null = null;

export const isSpeechSupported = (): boolean => {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
};

export const stopSpeaking = (): void => {
  if (isSpeechSupported()) {
    try {
      window.speechSynthesis.cancel();
      currentUtterance = null;
    } catch {
      // Ignore
    }
  }
};

export const speakText = (
  text: string,
  lang: Language = 'hi',
  onEnd?: () => void,
  rate: number = 0.95
): void => {
  if (!isSpeechSupported() || !text?.trim()) return;

  try {
    stopSpeaking();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = rate;
    utterance.pitch = 1.0;

    // Detect appropriate voices
    const voices = window.speechSynthesis.getVoices?.() || [];
    const targetLangCode = lang === 'hi' ? 'hi' : 'en';

    // Prioritize high quality regional voices (e.g. Google Hindi, Lekha, Rishi, etc.)
    const matchedVoice = voices.find((v) => {
      const code = v.lang.toLowerCase();
      return lang === 'hi' ? code.startsWith('hi') : code.startsWith('en-in') || code.startsWith('en');
    });

    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }
    utterance.lang = lang === 'hi' ? 'hi-IN' : 'en-IN';

    utterance.onend = () => {
      currentUtterance = null;
      onEnd?.();
    };

    utterance.onerror = () => {
      currentUtterance = null;
      onEnd?.();
    };

    currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Speech synthesis error:', err);
  }
};

export const triggerHaptic = (duration: number = 25): void => {
  try {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(duration);
    }
  } catch {
    // Ignore unsupported vibration
  }
};

/**
 * Reads mathematical operation names aloud in Hindi or English
 */
export const getSpokenSymbol = (symbol: string, lang: Language): string => {
  if (lang === 'hi') {
    switch (symbol) {
      case '+': return 'धन (जोड़)';
      case '-': return 'ऋण (घटाव)';
      case '×':
      case '*': return 'गुणा';
      case '÷':
      case '/': return 'भाग';
      case '%': return 'प्रतिशत';
      case '=': return 'बराबर';
      case '.': return 'दशमलव';
      case '(': return 'कोष्टक शुरू';
      case ')': return 'कोष्टक बंद';
      case 'C': return 'हटाया';
      case 'DEL': return 'पिछला अंक मिटाया';
      default: return symbol;
    }
  } else {
    switch (symbol) {
      case '+': return 'plus';
      case '-': return 'minus';
      case '×':
      case '*': return 'multiplied by';
      case '÷':
      case '/': return 'divided by';
      case '%': return 'percent';
      case '=': return 'equals';
      case '.': return 'point';
      case '(': return 'open bracket';
      case ')': return 'close bracket';
      case 'C': return 'cleared';
      case 'DEL': return 'backspace';
      default: return symbol;
    }
  }
};
