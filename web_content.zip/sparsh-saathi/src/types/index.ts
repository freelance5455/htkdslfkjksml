export type Language = 'hi' | 'en';

export type ThemeMode = 'normal' | 'dark' | 'yellow-contrast';

export type TextSize = 'normal' | 'large' | 'extralarge';

export type ActiveTab = 'about' | 'tools' | 'knowledge';

export interface NoticeItem {
  id: string;
  titleHi: string;
  titleEn: string;
  date: string;
  category: 'academic' | 'exam' | 'event' | 'welfare';
  detailsHi: string;
  detailsEn: string;
  isUrgent?: boolean;
}

export interface PrayerItem {
  id: string;
  titleHi: string;
  titleEn: string;
  category: 'prayer' | 'anthem';
  stanzasHi: string[];
  stanzasEn: string[];
  meaningHi: string;
  meaningEn: string;
}

export interface RpwdRuleItem {
  id: string;
  section: string;
  titleHi: string;
  titleEn: string;
  summaryHi: string;
  summaryEn: string;
  detailsHi: string[];
  detailsEn: string[];
}

export interface ConstitutionArticle {
  id: string;
  article: string;
  titleHi: string;
  titleEn: string;
  provisionHi: string;
  provisionEn: string;
  importanceHi: string;
  importanceEn: string;
}

export interface GkItem {
  id: string;
  category: 'gorakhpur' | 'up' | 'braille' | 'history';
  titleHi: string;
  titleEn: string;
  factHi: string;
  factEn: string;
  highlightHi: string;
  highlightEn: string;
}
