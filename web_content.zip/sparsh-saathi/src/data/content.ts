import { NoticeItem, PrayerItem, RpwdRuleItem, ConstitutionArticle, GkItem } from '../types';

export const SCHOOL_INFO = {
  nameHi: 'स्पर्श राजकीय दृष्टिबाधित इंटर कॉलेज',
  nameEn: 'Sparsh Government Visually Impaired Inter College',
  locationHi: 'लालडिग्गी, गोरखपुर, उत्तर प्रदेश',
  locationEn: 'Laldiggi, Gorakhpur, Uttar Pradesh',
  fullAddressHi: 'लालडिग्गी, निकट घण्टाघर एवं रामलीला मैदान, गोरखपुर - 273001 (उ.प्र.)',
  fullAddressEn: 'Laldiggi, Near Ghantaghar & Ramleela Ground, Gorakhpur - 273001 (U.P.)',
  departmentHi: 'दिव्यांगजन सशक्तीकरण विभाग, उत्तर प्रदेश शासन',
  departmentEn: 'Department of Empowerment of Persons with Disabilities, Govt of UP',
  visionHi: 'दृष्टिबाधित विद्यार्थियों को आधुनिक ब्रेल लिपि, सुगम कम्प्यूटर शिक्षा, संगीत, खेलकूद एवं नैतिक मूल्यों से परिपूर्ण कर समाज की मुख्यधारा में आत्मनिर्भर बनाना।',
  visionEn: 'Empowering visually impaired students through modern braille literacy, accessible IT education, music, sports, and ethical values to achieve complete self-reliance in mainstream society.',
  quoteHi: '"संसार की सबसे सुंदर और उत्तम वस्तुएं न तो देखी जा सकती हैं और न ही छुई जा सकती हैं, वे केवल दिल से महसूस की जाती हैं।" — हेलेन केलर',
  quoteEn: '"The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart." — Helen Keller',
};

export const DEVELOPER_INFO = {
  nameHi: 'मंजीत भारती',
  nameEn: 'Manjeet Bharti',
  roleHi: 'छात्र: स्पर्श राजकीय दृष्टिबाधित इंटर कॉलेज, लालडिग्गी, गोरखपुर',
  roleEn: 'Student: Sparsh Govt Visually Impaired Inter College, Laldiggi, Gorakhpur',
  badgeHi: 'ऐप निर्माता / App Developer',
  badgeEn: 'App Developer / Creator',
  email: 'manjitbharti892@gmail.com',
  photoUrl: '1758707631848.jpg',
  messageHi: 'नमस्ते! मैं मंजीत भारती हूँ। मैंने यह "स्पर्श साथी" वेब एप्लिकेशन अपने प्यारे सहपाठियों, पूज्य गुरुजनों और समस्त दृष्टिबाधित समाज की दैनिक सुगमता (Accessibility) हेतु निर्मित किया है। तकनीक हमारा सच्चा सहारा है।',
  messageEn: 'Hello! I am Manjeet Bharti. I built this "Sparsh Saathi" web application for my beloved classmates, respected teachers, and the entire visually impaired community to make daily study and tools 100% accessible. Technology is our greatest enabler.',
  dedicationHi: 'समर्पित: स्पर्श राजकीय दृष्टिबाधित इंटर कॉलेज परिवार व गुरुजनों के श्रीचरणों में',
  dedicationEn: 'Dedicated to the teachers and students of Sparsh Govt Visually Impaired Inter College',
};

export const PRAYERS_DATA: PrayerItem[] = [
  {
    id: 'itni-shakti',
    titleHi: 'सुबह की प्रार्थना: इतनी शक्ति हमें देना दाता',
    titleEn: 'Morning Prayer: Itni Shakti Hame Dena Data',
    category: 'prayer',
    stanzasHi: [
      'इतनी शक्ति हमें देना दाता, मन का विश्वास कमजोर होना।\nहम चलें नेक रस्ते पे हमसे, भूलकर भी कोई भूल होना॥',
      'दूर अज्ञान के हो अंधेरे, तू हमें ज्ञान की रोशनी दे।\nहर बुराई से बचते रहें हम, जितनी भी दे भली जिंदगी दे।\nबैर होना किसी का किसी से, भावना मन में बदले की होना॥',
      'हम न सोचें हमें क्या मिला है, हम ये सोचें किया क्या है अर्पण।\nफूल खुशियों के बांटें सभी को, सब का जीवन ही बन जाए मधुबन।\nअपनी करुणा का जल तू बहा के, करदे पावन हर इक मन का कोना॥',
      'इतनी शक्ति हमें देना दाता, मन का विश्वास कमजोर होना।\nहम चलें नेक रस्ते पे हमसे, भूलकर भी कोई भूल होना॥'
    ],
    stanzasEn: [
      'Give us so much strength, O Divine Creator, that the faith in our heart never wavers.\nMay we always walk the path of virtue, and may we never commit any mistake even inadvertently.',
      'Dispel the darkness of ignorance and bestow upon us the light of true wisdom.\nKeep us safe from every evil and grant us a noble, fulfilling life.\nMay there be no animosity between anyone, and may no feeling of revenge enter our hearts.',
      'Let us not brood over what we have received, but reflect upon what we have offered to the world.\nLet us scatter blossoms of joy everywhere, turning every life into a fragrant garden.\nPour forth the nectar of Your compassion and purify every corner of every human heart.',
      'Give us so much strength, O Divine Creator, that the faith in our heart never wavers.\nMay we always walk the path of virtue, and may we never commit any mistake even inadvertently.'
    ],
    meaningHi: 'यह प्रार्थना हमें ईश्वर से आंतरिक शक्ति, सन्मार्ग पर चलने की प्रेरणा, दयाभाव और समाज के प्रति निस्वार्थ सेवा भाव की शक्ति मांगती है।',
    meaningEn: 'A timeless school prayer seeking inner moral strength, wisdom, compassion, and selflessness in service to society.'
  },
  {
    id: 'vah-shakti',
    titleHi: 'दैनिक प्रार्थना: वह शक्ति हमें दो दयानिधे',
    titleEn: 'Daily Prayer: Vah Shakti Hame Do Dayanidhe',
    category: 'prayer',
    stanzasHi: [
      'वह शक्ति हमें दो दयानिधे, कर्तव्य मार्ग पर डट जावें।\nपर सेवा पर उपकार में हम, निज जीवन सफल बना जावें॥',
      'हम दीन-दुखी निबलों-विकलों के सेवक बन संताप हरें।\nजो हैं अटके भूले-भटके, उनको तारें खुद तर जावें॥',
      'छल, दंभ, द्वेष, पाखंड, झूठ, अन्याय से निसिदिन दूर रहें।\nजीवन हो शुद्ध सरल अपना, शुचि प्रेम-सुधारस बरसावें॥',
      'निज आन, बान, मर्यादा का प्रभु ध्यान रहे अभिमान रहे।\nजिस देश-जाति में जन्म लिया, बलिदान उसी पर हो जावें॥'
    ],
    stanzasEn: [
      'Bestow that divine strength upon us, O Merciful Lord, that we remain resolute on the path of duty.\nIn serving others and doing good to humanity, may we make our lives worthy and fruitful.',
      'May we become the loving servants of the poor, distressed, and disabled to eradicate their suffering.\nThose who are lost or struggling in life, may we guide them to the shore while crossing over ourselves.',
      'May we stay far away each day from deceit, arrogance, malice, hypocrisy, falsehood, and injustice.\nMay our life be pure and simple, showering the nectar of sacred unconditional love.',
      'May we always preserve the honor, dignity, and heritage of our nation with righteous pride.\nFor the motherland in which we were blessed to be born, may we gladly dedicate our entire being.'
    ],
    meaningHi: 'यह प्रार्थना कर्तव्यपरायणता, दीन-दुखियों की सेवा, सत्यनिष्ठा और राष्ट्रभक्ति की प्रेरणा देती है।',
    meaningEn: 'Inspires dedication to duty, upliftment of the needy and persons with disabilities, truthfulness, and patriotic sacrifice.'
  },
  {
    id: 'rashtrageet',
    titleHi: 'राष्ट्रगान: जन गण मन (52 सेकंड)',
    titleEn: 'National Anthem: Jana Gana Mana (52 Seconds)',
    category: 'anthem',
    stanzasHi: [
      'जन-गण-मन अधिनायक जय हे, भारत भाग्य विधाता।\nपंजाब-सिंधु-गुजरात-मराठा, द्राविड़-उत्कल-बंग।\nविंध्य-हिमाचल-यमुना-गंगा, उच्छल जलधि तरंग।\nतव शुभ नामे जागे, तव शुभ आशिष मागे,\nगाहे तव जय गाथा।\nजन-गण-मंगल दायक जय हे, भारत भाग्य विधाता।\nजय हे, जय हे, जय हे, जय जय जय जय हे॥'
    ],
    stanzasEn: [
      'Thou art the ruler of the minds of all people, Dispenser of India\'s destiny.\nThy name rouses the hearts of Punjab, Sindh, Gujarat and Maratha, Of the Dravida, Utkala and Bengal;\nIt echoes in the hills of Vindhyas and Himalayas, Mingles in the music of Yamuna and Ganga,\nAnd is chanted by the waves of the Indian Sea.\nThey pray for thy blessings and sing thy praise.\nThe saving of all people waits in thy hand, Thou dispenser of India\'s destiny.\nVictory, victory, victory to thee.'
    ],
    meaningHi: 'कविगुरु रवीन्द्रनाथ टैगोर द्वारा रचित भारत का राष्ट्रगान। इसे संपूर्ण रूप से 52 सेकंड में गाया जाता है।',
    meaningEn: 'Composed by Rabindranath Tagore, the National Anthem of India celebrates the cultural, geographic, and spiritual unity of the nation.'
  }
];

export const NOTICES_DATA: NoticeItem[] = [
  {
    id: 'n-1',
    titleHi: 'सत्र 2026-27: कक्षा 6 से 12 तक निःशुल्क प्रवेश एवं पंजीकरण सूचना',
    titleEn: 'Session 2026-27: Free Admission & Registration Notice (Class 6 to 12)',
    date: '10 अक्टूबर 2026',
    category: 'academic',
    isUrgent: true,
    detailsHi: 'स्पर्श राजकीय दृष्टिबाधित इंटर कॉलेज, लालडिग्गी, गोरखपुर में नए शैक्षणिक सत्र हेतु दृष्टिबाधित बालक-बालिकाओं के निःशुल्क छात्रावास, भोजन, ब्रेल पुस्तकें व अध्ययन सामग्री सहित प्रवेश प्रारम्भ हैं। प्रधानाचार्य कार्यालय से संपर्क करें।',
    detailsEn: 'Free admissions for visually impaired students in Class 6 to 12 with boarding, lodging, braille textbooks, and audio learning aids are open at Sparsh Govt Inter College, Gorakhpur.'
  },
  {
    id: 'n-2',
    titleHi: 'यूपी बोर्ड परीक्षा: लेखक (Scribe) व अतिरिक्त समय (20 मिनट प्रति घंटा) की व्यवस्था',
    titleEn: 'UP Board Exam: Scribe & Extra Compensatory Time (20 min/hr) Facility',
    date: '02 अक्टूबर 2026',
    category: 'exam',
    isUrgent: true,
    detailsHi: 'हाईस्कूल व इंटरमीडिएट बोर्ड परीक्षा में सम्मिलित होने वाले समस्त दृष्टिबाधित छात्रों को RPwD एक्ट 2016 के तहत अपनी पसंद का लेखक चुनने तथा प्रति घण्टे 20 मिनट अतिरिक्त समय की सुविधा सुनिश्चित की गई है।',
    detailsEn: 'Under the RPwD Act 2016, all visually impaired students appearing in Class 10 & 12 Board Exams are guaranteed own scribe flexibility and 20 minutes compensatory extra time per examination hour.'
  },
  {
    id: 'n-3',
    titleHi: 'डिजिटल सुगमता: एनवीडीए (NVDA) स्क्रीन रीडर व स्मार्ट फोन प्रशिक्षण शिविर',
    titleEn: 'Digital Accessibility: NVDA Screen Reader & Smartphone Training Camp',
    date: '25 सितंबर 2026',
    category: 'welfare',
    detailsHi: 'विद्यालय के कम्प्यूटर कक्ष में दृष्टिबाधित विद्यार्थियों के लिए कीबोर्ड शॉर्टकट, NVDA स्क्रीन रीडर, टॉकबैक एवं डिजिटल डेजी प्लेयर का विशेष 15 दिवसीय व्यावहारिक कार्यशाला आयोजित की जा रही है।',
    detailsEn: 'A specialized 15-day hands-on workshop is underway in the school computer lab on NVDA screen reader, keyboard shortcuts, Android TalkBack, and Daisy digital players.'
  },
  {
    id: 'n-4',
    titleHi: 'राज्य स्तरीय पैरा-एथलेटिक्स व दृष्टिबाधित शतरंज प्रतियोगिता चयन ट्रायल',
    titleEn: 'State Level Para Athletics & Visually Impaired Chess Selection Trials',
    date: '18 सितंबर 2026',
    category: 'event',
    detailsHi: 'गोरखपुर मंडल के दृष्टिबाधित खिलाड़ियों हेतु 100 मी. दौड़, गोला फेंक एवं ब्रेल शतरंज प्रतियोगिता हेतु चयन ट्रायल विद्यालय खेल परिसर में संपन्न होंगे। सभी उत्साही छात्र भाग लें।',
    detailsEn: 'Selection trials for 100m sprint, shot put, and Braille chess for visually impaired athletes will be held at the school sports ground.'
  }
];

export const RPWD_RULES_DATA: RpwdRuleItem[] = [
  {
    id: 'rpwd-31',
    section: 'धारा 31 (Section 31)',
    titleHi: '6 से 18 वर्ष तक निःशुल्क व सुगम शिक्षा का कानूनी अधिकार',
    titleEn: 'Right to Free & Accessible Education (Ages 6 to 18)',
    summaryHi: 'प्रत्येक बेंचमार्क दिव्यांग बच्चे (दृष्टिबाधित सहित) को 18 वर्ष की आयु तक पड़ोस के विद्यालय या विशेष विद्यालय में निःशुल्क शिक्षा प्राप्त करने का वैधानिक अधिकार है।',
    summaryEn: 'Every child with a benchmark disability has the statutory right to free education in a neighborhood school or special school up to the age of 18.',
    detailsHi: [
      'धारा 31 के अनुसार 18 वर्ष तक निःशुल्क शिक्षा अनिवार्य है (सामान्य RTE में यह 14 वर्ष तक है)।',
      'विद्यालयों द्वारा ब्रेल लिपि पुस्तकें, बड़े अक्षरों की पुस्तकें, ऑडियो रिकॉर्डिंग व स्क्रीन रीडर युक्त कम्प्यूटर निःशुल्क उपलब्ध कराए जाने का प्रावधान है।',
      'परिवहन सुविधा अथवा सुगम छात्रावास की व्यवस्था सरकार द्वारा की जाती है।'
    ],
    detailsEn: [
      'Free education extended up to 18 years under Section 31 (compared to 14 years under standard RTE).',
      'Schools must provide free Braille books, large print materials, audiobooks, and computers equipped with screen readers.',
      'Accessible transport facilities or residential hostel accommodation are mandated.'
    ]
  },
  {
    id: 'rpwd-scribe',
    section: 'परीक्षा दिशानिर्देश (Exam Guidelines 2018/2022)',
    titleHi: 'लेखक (Scribe) व प्रति घण्टे 20 मिनट अतिरिक्त समय (Compensatory Time)',
    titleEn: 'Right to Scribe & 20 Minutes Extra Compensatory Time Per Hour',
    summaryHi: 'बोर्ड, विश्वविद्यालय व प्रतियोगी परीक्षाओं में दृष्टिबाधित अभ्यर्थियों को स्वयं का लेखक चुनने की स्वतंत्रता और न्यूनतम 20 मिनट प्रति घण्टा अतिरिक्त समय का अधिकार है।',
    summaryEn: 'Full liberty for visually impaired candidates to choose their own scribe and an absolute entitlement to at least 20 minutes compensatory extra time per hour.',
    detailsHi: [
      'न्यूनतम 20 मिनट प्रति घण्टा अतिरिक्त समय: 3 घण्टे के प्रश्नपत्र में 60 मिनट (1 घण्टा) अतिरिक्त समय मिलना कानूनी अधिकार है।',
      'लेखक की शैक्षिक योग्यता पर कोई कठोर बाध्यता नहीं: अभ्यर्थी परीक्षा में स्वयं अपनी पसंद का लेखक ला सकता है।',
      'यदि अभ्यर्थी परीक्षा एजेंसी से लेखक मांगता है, तो परीक्षा से 1 दिन पूर्व अभ्यर्थी को लेखक से मिलने का अधिकार है।',
      'वैकल्पिक सुगमता: ब्रेल प्रश्नपत्र, कम्प्यूटर पर स्क्रीन रीडर या मैग्नीफायर के साथ परीक्षा देने का विकल्प।'
    ],
    detailsEn: [
      'Mandatory compensatory time of minimum 20 minutes per hour (e.g., 60 extra minutes in a standard 3-hour exam).',
      'Candidates can bring their own scribe; no unfair restriction on scribe academic qualifications below the exam level.',
      'If relying on an agency scribe, candidate has the legal right to meet the scribe 1 day before the exam.',
      'Choice of assistive media: Question paper in Braille, large print, or screen-reader accessible computer.'
    ]
  },
  {
    id: 'rpwd-32-34',
    section: 'धारा 32 एवं 34 (Section 32 & 34)',
    titleHi: 'उच्च शिक्षण संस्थानों में 5% तथा सरकारी नौकरियों में 4% आरक्षण',
    titleEn: '5% Reservation in Higher Education & 4% in Govt Jobs',
    summaryHi: 'सभी सरकारी व अनुदान प्राप्त उच्च शिक्षण संस्थानों में 5% सीटें तथा समस्त सरकारी सेवाओं में 4% पद दिव्यांगजनों के लिए आरक्षित हैं (जिसमें 1% दृष्टिबाधितों के लिए विशिष्ट है)।',
    summaryEn: '5% quota in government higher educational institutions and 4% quota in public employment, with 1% specifically earmarked for blindness and low vision.',
    detailsHi: [
      'धारा 32: विश्वविद्यालय, मेडिकल, इंजीनियरिंग, बीएड, डीएलएड, आईटीआई में 5% आरक्षण और 5 वर्ष की आयु सीमा छूट।',
      'धारा 34: समूह क, ख, ग एवं घ की सरकारी नौकरियों में 4% आरक्षण, जिसमें दृष्टिबाधिता (Blindness & Low Vision) के लिए 1% आरक्षित पद।',
      'पदोन्नति (Promotion) में भी दिव्यांगजनों को आरक्षण का लाभ मिलता है।'
    ],
    detailsEn: [
      'Section 32: 5% seat reservation in universities, polytechnics, teacher training, and higher education with 5 years age relaxation.',
      'Section 34: 4% horizontal reservation in Group A, B, C, and D government posts, with 1% dedicated for blindness/low vision.',
      'Equal opportunity in promotion and career progression.'
    ]
  },
  {
    id: 'rpwd-grievance',
    section: 'शिकायत निवारण (Grievance Redressal)',
    titleHi: 'भेदभाव के विरुद्ध राज्य दिव्यांगजन आयुक्त में शिकायत का अधिकार',
    titleEn: 'Right to File Grievance with State Disability Commissioner',
    summaryHi: 'यदि कोई विद्यालय, कॉलेज या परीक्षा केंद्र दृष्टिबाधित छात्र के अधिकारों का उल्लंघन करे, तो राज्य आयुक्त के समक्ष त्वरित शिकायत दर्ज की जा सकती है।',
    summaryEn: 'In case of rights denial by any school, college, or exam board, students have the right to file direct complaints before the State Commissioner for Persons with Disabilities.',
    detailsHi: [
      'उत्तर प्रदेश दिव्यांगजन राज्य आयुक्त कार्यालय, इंदिरा भवन, लखनऊ में सीधे शिकायत दर्ज की जा सकती है।',
      'धारा 89/92: दिव्यांगजनों के अधिकारों का जानबूझकर उल्लंघन करने या अपमानित करने पर 6 माह से 5 वर्ष तक कारावास व जुर्माने का कठोर दंड।',
      'टोल फ्री हेल्पलाइन 1800-180-1995 पर उत्तर प्रदेश सरकार से सहायता ली जा सकती है।'
    ],
    detailsEn: [
      'Direct complaint can be registered at the UP State Commissioner for Persons with Disabilities, Indira Bhawan, Lucknow.',
      'Sections 89/92 prescribe penal imprisonment from 6 months up to 5 years and fines for intentional denial of rights or atrocities.',
      'Assistance available via UP State helpline 1800-180-1995.'
    ]
  }
];

export const CONSTITUTION_ARTICLES_DATA: ConstitutionArticle[] = [
  {
    id: 'const-preamble',
    article: 'प्रस्तावना (Preamble)',
    titleHi: 'भारतीय संविधान की प्रस्तावना / उद्देशिका',
    titleEn: 'Preamble of the Constitution of India',
    provisionHi: '"हम, भारत के लोग, भारत को एक सम्पूर्ण प्रभुत्व-सम्पन्न, समाजवादी, पंथनिरपेक्ष, लोकतंत्रात्मक गणराज्य बनाने के लिए तथा उसके समस्त नागरिकों को: सामाजिक, आर्थिक और राजनीतिक न्याय; विचार, अभिव्यक्ति, विश्वास, धर्म और उपासना की स्वतंत्रता; प्रतिष्ठा और अवसर की समता प्राप्त कराने के लिए..."',
    provisionEn: '"WE, THE PEOPLE OF INDIA, having solemnly resolved to constitute India into a SOVEREIGN SOCIALIST SECULAR DEMOCRATIC REPUBLIC and to secure to all its citizens: JUSTICE, social, economic and political; LIBERTY of thought, expression, belief, faith and worship; EQUALITY of status and of opportunity; and to promote among them all FRATERNITY assuring the dignity of the individual and the unity and integrity of the Nation..."',
    importanceHi: 'संविधान की आत्मा; यह सभी नागरिकों के लिए न्याय, स्वतंत्रता और अवसर की समानता की गारंटी देती है।',
    importanceEn: 'The soul of the Constitution guaranteeing justice, liberty, and equality of opportunity for all citizens.'
  },
  {
    id: 'art-14',
    article: 'अनुच्छेद 14 (Article 14)',
    titleHi: 'विधि के समक्ष समता और समान संरक्षण',
    titleEn: 'Equality before Law & Equal Protection of Laws',
    provisionHi: 'राज्य, भारत के राज्यक्षेत्र में किसी व्यक्ति को विधि के समक्ष समता से या विधियों के समान संरक्षण से वंचित नहीं करेगा।',
    provisionEn: 'The State shall not deny to any person equality before the law or the equal protection of the laws within the territory of India.',
    importanceHi: 'यह दृष्टिबाधित विद्यार्थियों को सामान्य नागरिकों के बराबर कानूनी अधिकार और संरक्षण का मूल आधार प्रदान करता है।',
    importanceEn: 'Forms the constitutional bedrock ensuring visually impaired citizens enjoy equal legal rights and state protection.'
  },
  {
    id: 'art-15',
    article: 'अनुच्छेद 15 (Article 15)',
    titleHi: 'भेदभाव का प्रतिषेध एवं विशेष प्रावधान',
    titleEn: 'Prohibition of Discrimination & Special Provisions',
    provisionHi: 'राज्य किसी नागरिक के विरुद्ध केवल धर्म, मूलवंश, जाति, लिंग, जन्मस्थान या इनमें से किसी के आधार पर विभेद नहीं करेगा। साथ ही वंचित व दिव्यांग वर्गों के कल्याण हेतु विशेष कानून बना सकता है।',
    provisionEn: 'The State shall not discriminate against any citizen on grounds only of religion, race, caste, sex, place of birth or any of them, and empowers positive affirmative action for vulnerable groups.',
    importanceHi: 'दिव्यांगजनों हेतु छात्रवृत्ति, आरक्षण व विशेष विद्यालयों की स्थापना अनुच्छेद 15 के सकारात्मक संरक्षण से प्रेरित है।',
    importanceEn: 'Empowers positive affirmative action, scholarships, quotas, and specialized residential schools like Sparsh.'
  },
  {
    id: 'art-21',
    article: 'अनुच्छेद 21 (Article 21)',
    titleHi: 'प्राण और दैहिक स्वतंत्रता का संरक्षण (गरिमापूर्ण जीवन)',
    titleEn: 'Protection of Life & Personal Liberty with Dignity',
    provisionHi: 'किसी व्यक्ति को उसके प्राण या दैहिक स्वतंत्रता से विधि द्वारा स्थापित प्रक्रिया के अनुसार ही वंचित किया जाएगा, अन्यथा नहीं। उच्चतम न्यायालय के अनुसार इसमें मानवीय गरिमा से जीने का अधिकार सम्मिलित है।',
    provisionEn: 'No person shall be deprived of his life or personal liberty except according to procedure established by law. The Supreme Court has ruled this includes the right to live with human dignity.',
    importanceHi: 'सुगम सड़कें, ब्रेल सामग्री, व सुलभ परिवहन पाना दृष्टिबाधित व्यक्ति के मानवीय गरिमापूर्ण जीवन का अभिन्न अंग है।',
    importanceEn: 'Living with accessibility, audio/braille access, and independent mobility is recognized as a facet of human dignity.'
  },
  {
    id: 'art-21a',
    article: 'अनुच्छेद 21क (Article 21A)',
    titleHi: 'शिक्षा का मौलिक अधिकार (Right to Education)',
    titleEn: 'Fundamental Right to Free & Compulsory Education',
    provisionHi: 'राज्य 6 से 14 वर्ष तक की आयु वाले सभी बालकों के लिए निःशुल्क और अनिवार्य शिक्षा देने का प्रबंध करेगा। (RPwD एक्ट में दिव्यांगों हेतु यह 18 वर्ष तक है)।',
    provisionEn: 'The State shall provide free and compulsory education to all children of the age of six to fourteen years. (Extended up to 18 years for children with disabilities under the RPwD Act).',
    importanceHi: 'शिक्षा पाना प्रत्येक दृष्टिबाधित बालक-बालिका का मौलिक और अनुल्लंघनीय अधिकार है।',
    importanceEn: 'Every visually impaired child possesses an inviolable fundamental right to quality education.'
  },
  {
    id: 'art-41',
    article: 'अनुच्छेद 41 (Article 41)',
    titleHi: 'काम, शिक्षा और निःशक्तता में लोक सहायता पाने का अधिकार',
    titleEn: 'Right to Work, Education and Public Assistance in Disablement',
    provisionHi: 'राज्य अपनी आर्थिक सामर्थ्य और विकास की सीमाओं के भीतर काम पाने के, शिक्षा पाने के और बेकारी, बुढ़ापा, बीमारी और निःशक्तता (Disability) तथा अन्य अनर्ह अभाव की दशाओं में लोक सहायता पाने के अधिकार को प्राप्त कराने का प्रभावी उपबंध करेगा।',
    provisionEn: 'The State shall, within the limits of its economic capacity and development, make effective provision for securing the right to work, to education and to public assistance in cases of unemployment, old age, sickness and disablement.',
    importanceHi: 'दिव्यांग पेंशन, उपकरण वितरण एवं ब्रेल प्रेसों का संचालन इसी संवैधानिक नीति-निदेशक तत्व से संचालित होता है।',
    importanceEn: 'Directs the government to provide disability pensions, free assistive devices, and braille publications.'
  }
];

export const GK_DATA: GkItem[] = [
  {
    id: 'gk-geeta-press',
    category: 'gorakhpur',
    titleHi: 'गीता प्रेस, गोरखपुर (Geeta Press, Gorakhpur)',
    titleEn: 'Geeta Press, Gorakhpur - World Heritage Publisher',
    factHi: 'गीता प्रेस, गोरखपुर दुनिया का सबसे बड़ा धार्मिक पुस्तकों का प्रकाशक है। इसकी स्थापना 1923 में जयदयाल गोयन्दका जी द्वारा की गई थी। इसे वर्ष 2021 का गांधी शांति पुरस्कार प्राप्त हुआ है।',
    factEn: 'Established in 1923, Geeta Press in Gorakhpur is the world\'s largest publisher of Hindu spiritual texts like Ramcharitmanas and Bhagavad Gita. It was awarded the prestigious Gandhi Peace Prize.',
    highlightHi: 'स्थापना: 1923 | पुरस्कार: गांधी शांति पुरस्कार',
    highlightEn: 'Founded: 1923 | Honor: Gandhi Peace Prize'
  },
  {
    id: 'gk-gorakhnath',
    category: 'gorakhpur',
    titleHi: 'गोरखनाथ मंदिर व रामगढ़ ताल (Gorakhnath Temple & Ramgarh Tal)',
    titleEn: 'Gorakhnath Temple & Scenic Ramgarh Tal',
    factHi: 'गोरखपुर का नाम महायोगी गुरु गोरखनाथ जी के नाम पर पड़ा है। यहाँ स्थित भव्य गोरखनाथ मंदिर नाथ पंथ की प्रधान पीठ है। गोरखपुर का विशाल रामगढ़ ताल 1800 एकड़ में फैला एक खूबसूरत प्राकृतिक सरोवर है।',
    factEn: 'Gorakhpur is named after Mahayogi Guru Gorakhnath. The Gorakhnath Temple is the revered spiritual seat of the Nath tradition. The historic Ramgarh Tal spans over 1,800 acres.',
    highlightHi: 'नाथ संप्रदाय का केंद्र | रामगढ़ ताल: 1800 एकड़',
    highlightEn: 'Seat of Nath Tradition | Ramgarh Tal Lake'
  },
  {
    id: 'gk-railway',
    category: 'gorakhpur',
    titleHi: 'गोरखपुर रेलवे स्टेशन प्लेटफॉर्म',
    titleEn: 'Gorakhpur Junction Railway Platform',
    factHi: 'पूर्वोत्तर रेलवे (NER) का मुख्यालय गोरखपुर में स्थित है। गोरखपुर जंक्शन का प्लेटफॉर्म संख्या 1 व 2 (लंबाई लगभग 1,366.33 मीटर) दुनिया के सबसे लंबे रेलवे प्लेटफॉर्म्स में से एक है।',
    factEn: 'Gorakhpur is the Zonal Headquarters of North Eastern Railway (NER). Its platform (measuring approx 1,366 meters) is globally celebrated among the world\'s longest railway platforms.',
    highlightHi: 'लंबाई: 1,366 मीटर | NER मुख्यालय',
    highlightEn: 'Length: 1,366 meters | North Eastern Railway HQ'
  },
  {
    id: 'gk-up-symbols',
    category: 'up',
    titleHi: 'उत्तर प्रदेश के राजकीय प्रतीक (UP State Symbols)',
    titleEn: 'State Symbols of Uttar Pradesh',
    factHi: 'राजधानी: लखनऊ | राजकीय पशु: बारहसिंगा (Swamp Deer) | राजकीय पक्षी: सारस क्रेन (Sarus Crane) | राजकीय पुष्प: पलाश (ढाक) | राजकीय वृक्ष: अशोक (Ashoka Tree) | राजकीय जलीय जीव: गंगा डॉल्फिन।',
    factEn: 'Capital: Lucknow | State Animal: Barasingha (Swamp Deer) | State Bird: Sarus Crane | State Flower: Palash | State Tree: Ashoka | State Aquatic Animal: Gangetic Dolphin.',
    highlightHi: 'पक्षी: सारस | पशु: बारहसिंगा | वृक्ष: अशोक',
    highlightEn: 'Bird: Sarus | Animal: Swamp Deer | Tree: Ashoka'
  },
  {
    id: 'gk-louis-braille',
    category: 'braille',
    titleHi: 'लुई ब्रेल व विश्व ब्रेल दिवस (Louis Braille & World Braille Day)',
    titleEn: 'Louis Braille & World Braille Day (4th January)',
    factHi: 'लुई ब्रेल का जन्म 4 जनवरी 1809 को फ्रांस के कूपव्रे नगर में हुआ था। उन्होंने वर्ष 1824 में मात्र 15 वर्ष की आयु में 6 बिंदुओं पर आधारित जादुई ब्रेल लिपि का आविष्कार किया। प्रत्येक वर्ष 4 जनवरी को विश्व ब्रेल दिवस मनाया जाता है।',
    factEn: 'Louis Braille was born on 4 January 1809 in Coupvray, France. At the tender age of 15 in 1824, he invented the revolutionary 6-dot tactile reading system. 4th January is celebrated globally as World Braille Day.',
    highlightHi: 'जन्म: 4 जनवरी 1809 | लिपि: 6 उभरे बिंदु',
    highlightEn: 'Born: 4 Jan 1809 | 6 Raised Tactile Dots'
  },
  {
    id: 'gk-bharati-braille',
    category: 'braille',
    titleHi: 'भारती ब्रेल लिपि (Bharati Braille for Indian Languages)',
    titleEn: 'Bharati Braille - Unified Code for Indian Languages',
    factHi: 'भारती ब्रेल भारत की सभी प्रमुख भाषाओं (हिन्दी, संस्कृत, बांग्ला, तमिल आदि) के लिए मानकीकृत ब्रेल कोड है। इसमें देवनागरी वर्णमाला के स्वरों व व्यंजनों को 6-डॉट सेल में व्यवस्थित किया गया है।',
    factEn: 'Bharati Braille is the unified tactile reading code adopted across India for Hindi, Sanskrit, and all regional languages, mapping phonetics neatly into standard 6-dot cells.',
    highlightHi: 'देवनागरी व भारतीय भाषाओं हेतु मानकीकृत कोड',
    highlightEn: 'Unified code for all Indian regional languages'
  }
];

export const BHARATI_BRAILLE_LETTERS = [
  { char: 'अ (a)', dots: 'Dot 1 (⠁)', dotNums: [1], desc: 'पहला बिंदु ऊपर बाएं' },
  { char: 'आ (aa)', dots: 'Dots 3, 4, 5 (⠜)', dotNums: [3, 4, 5], desc: 'डॉट 3, 4, 5' },
  { char: 'इ (i)', dots: 'Dots 2, 4 (⠊)', dotNums: [2, 4], desc: 'डॉट 2, 4' },
  { char: 'ई (ee)', dots: 'Dots 3, 5 (⠔)', dotNums: [3, 5], desc: 'डॉट 3, 5' },
  { char: 'उ (u)', dots: 'Dots 1, 3, 6 (⠥)', dotNums: [1, 3, 6], desc: 'डॉट 1, 3, 6' },
  { char: 'क (k)', dots: 'Dots 1, 3 (⠅)', dotNums: [1, 3], desc: 'डॉट 1, 3' },
  { char: 'ख (kh)', dots: 'Dots 4, 6 (⠨)', dotNums: [4, 6], desc: 'डॉट 4, 6' },
  { char: 'ग (g)', dots: 'Dots 1, 2, 4, 5 (⠛)', dotNums: [1, 2, 4, 5], desc: 'डॉट 1, 2, 4, 5' },
  { char: 'म (m)', dots: 'Dots 1, 3, 4 (⠍)', dotNums: [1, 3, 4], desc: 'डॉट 1, 3, 4' },
  { char: 'र (r)', dots: 'Dots 1, 2, 3, 5 (⠗)', dotNums: [1, 2, 3, 5], desc: 'डॉट 1, 2, 3, 5' },
  { char: 'स (s)', dots: 'Dots 2, 3, 4 (⠎)', dotNums: [2, 3, 4], desc: 'डॉट 2, 3, 4' },
  { char: 'ह (h)', dots: 'Dots 1, 2, 5 (⠓)', dotNums: [1, 2, 5], desc: 'डॉट 1, 2, 5' }
];
