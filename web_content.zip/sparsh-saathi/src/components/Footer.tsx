import React from 'react';
import { DEVELOPER_INFO, SCHOOL_INFO } from '../data/content';
import { Language } from '../types';
import { speakText, triggerHaptic } from '../utils/speech';
import { Heart, School, Mail, Award, Volume2, ArrowUp, Download } from 'lucide-react';

interface FooterProps {
  lang: Language;
  voiceEnabled: boolean;
}

export const Footer: React.FC<FooterProps> = ({ lang, voiceEnabled }) => {
  const [photoUrl, setPhotoUrl] = React.useState<string>(DEVELOPER_INFO.photoUrl);
  const [imgError, setImgError] = React.useState<boolean>(false);

  React.useEffect(() => {
    const updatePhoto = () => {
      try {
        const saved = localStorage.getItem('manjeet_dev_photo');
        if (saved) setPhotoUrl(saved);
        else setPhotoUrl(DEVELOPER_INFO.photoUrl);
      } catch {
        // Ignore
      }
    };
    updatePhoto();
    window.addEventListener('manjeet_photo_updated', updatePhoto);
    return () => window.removeEventListener('manjeet_photo_updated', updatePhoto);
  }, []);

  const scrollToTop = () => {
    triggerHaptic(20);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (voiceEnabled) {
      speakText(lang === 'hi' ? 'शीर्ष पर पहुंचे' : 'Scrolled to top', lang);
    }
  };

  return (
    <footer className="mt-16 bg-slate-900 text-slate-300 border-t-4 border-amber-500 pt-10 pb-24 md:pb-12 px-4 transition-colors">
      <div className="max-w-5xl mx-auto space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          {/* Col 1: School Identity */}
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600 text-amber-300 flex items-center justify-center font-bold text-lg border border-amber-400">
                ⠎
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">
                {lang === 'hi' ? SCHOOL_INFO.nameHi : SCHOOL_INFO.nameEn}
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              {lang === 'hi' ? SCHOOL_INFO.fullAddressHi : SCHOOL_INFO.fullAddressEn}
            </p>
            <p className="text-xs text-amber-400/90 font-medium mt-1">
              {lang === 'hi' ? SCHOOL_INFO.departmentHi : SCHOOL_INFO.departmentEn}
            </p>
          </div>

          {/* Col 2: Developer Dedication with Circular Photo */}
          <div className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-3">
              <Award className="w-4 h-4 text-amber-400 shrink-0" aria-hidden="true" />
              <span>{lang === 'hi' ? 'ऐप निर्माता एवं परिकल्पना' : 'App Creator & Conception'}</span>
            </div>

            <div className="flex items-center gap-4 mb-3">
              {/* Circular Photo */}
              <div className="w-14 h-14 rounded-full ring-2 ring-amber-400 p-0.5 shadow-md bg-amber-50 dark:bg-slate-800 shrink-0 overflow-hidden flex items-center justify-center">
                {!imgError ? (
                  <img
                    src={photoUrl}
                    alt={lang === 'hi' ? 'मंजीत भारती (Manjeet Bharti)' : 'Manjeet Bharti'}
                    referrerPolicy="no-referrer"
                    onError={() => setImgError(true)}
                    className="w-full h-full object-cover object-[70%_20%] rounded-full shadow-inner"
                  />
                ) : (
                  <div className="w-full h-full rounded-full bg-blue-700 text-amber-300 font-extrabold flex items-center justify-center text-sm">
                    MB
                  </div>
                )}
              </div>

              <div>
                <div className="text-base sm:text-lg font-bold text-white leading-tight">
                  {lang === 'hi' ? DEVELOPER_INFO.nameHi : DEVELOPER_INFO.nameEn}
                </div>
                <div className="text-xs text-blue-300 mt-0.5">
                  {lang === 'hi' ? DEVELOPER_INFO.roleHi : DEVELOPER_INFO.roleEn}
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-300 italic">
              "{lang === 'hi' ? DEVELOPER_INFO.dedicationHi : DEVELOPER_INFO.dedicationEn}"
            </p>

            <div className="mt-3 flex flex-wrap items-center gap-3">
              <a
                href={`mailto:${DEVELOPER_INFO.email}`}
                className="text-xs font-semibold text-amber-300 hover:text-amber-200 flex items-center gap-1.5 underline"
              >
                <Mail className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{DEVELOPER_INFO.email}</span>
              </a>

              <a
                href="/sparsh-saathi-source-code.zip"
                download="sparsh-saathi-source-code.zip"
                className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1.5 underline"
              >
                <Download className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{lang === 'hi' ? 'सोर्स कोड डाउनलोड (.zip)' : 'Download Source (.zip)'}</span>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom copyright & scroll-to-top */}
        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400 text-center sm:text-left">
          <div>
            © 2026 {lang === 'hi' ? 'स्पर्श साथी — दृष्टिबाधित सुगमता पहल' : 'Sparsh Saathi — Visual Accessibility Initiative'} | Gorakhpur, UP
          </div>

          <button
            type="button"
            onClick={scrollToTop}
            aria-label={lang === 'hi' ? 'पृष्ठ के शीर्ष पर जाएं' : 'Scroll to top of page'}
            className="min-touch-target px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl flex items-center gap-1.5 border border-slate-700 transition-colors"
          >
            <ArrowUp className="w-4 h-4" aria-hidden="true" />
            <span>{lang === 'hi' ? 'ऊपर जाएं' : 'Back to Top'}</span>
          </button>
        </div>
      </div>
    </footer>
  );
};
