import React, { useState } from 'react';
import { SCHOOL_INFO, PRAYERS_DATA, NOTICES_DATA } from '../data/content';
import { Language } from '../types';
import { speakText, triggerHaptic, stopSpeaking } from '../utils/speech';
import { DeveloperCard } from './DeveloperCard';
import {
  School,
  MapPin,
  Bell,
  Heart,
  Volume2,
  VolumeX,
  Play,
  Quote,
  Sparkles,
  Award,
  BookOpen,
  Calendar
} from 'lucide-react';

interface AboutSchoolTabProps {
  lang: Language;
  voiceEnabled: boolean;
}

export const AboutSchoolTab: React.FC<AboutSchoolTabProps> = ({
  lang,
  voiceEnabled,
}) => {
  const [selectedPrayerId, setSelectedPrayerId] = useState<string>('itni-shakti');
  const [noticeFilter, setNoticeFilter] = useState<string>('all');
  const [isReadingPrayer, setIsReadingPrayer] = useState<boolean>(false);

  const selectedPrayer = PRAYERS_DATA.find((p) => p.id === selectedPrayerId) || PRAYERS_DATA[0];

  const filteredNotices = NOTICES_DATA.filter((n) => {
    if (noticeFilter === 'all') return true;
    return n.category === noticeFilter;
  });

  const handleReadSchoolVision = () => {
    triggerHaptic(25);
    const speech = lang === 'hi'
      ? `${SCHOOL_INFO.nameHi}। पता: ${SCHOOL_INFO.fullAddressHi}। विभाग: ${SCHOOL_INFO.departmentHi}। संकल्प: ${SCHOOL_INFO.visionHi}`
      : `${SCHOOL_INFO.nameEn}. Address: ${SCHOOL_INFO.fullAddressEn}. Department: ${SCHOOL_INFO.departmentEn}. Vision: ${SCHOOL_INFO.visionEn}`;
    speakText(speech, lang);
  };

  const handleReadFullPrayer = () => {
    triggerHaptic(25);
    if (isReadingPrayer) {
      stopSpeaking();
      setIsReadingPrayer(false);
      return;
    }

    setIsReadingPrayer(true);
    const title = lang === 'hi' ? selectedPrayer.titleHi : selectedPrayer.titleEn;
    const stanzas = lang === 'hi' ? selectedPrayer.stanzasHi.join('. ') : selectedPrayer.stanzasEn.join('. ');
    const fullText = `${title}. ${stanzas}`;

    speakText(fullText, lang, () => {
      setIsReadingPrayer(false);
    });
  };

  const handleReadSingleStanza = (text: string) => {
    triggerHaptic(20);
    speakText(text, lang);
  };

  const handleReadNotice = (notice: typeof NOTICES_DATA[0]) => {
    triggerHaptic(20);
    const title = lang === 'hi' ? notice.titleHi : notice.titleEn;
    const details = lang === 'hi' ? notice.detailsHi : notice.detailsEn;
    const date = notice.date;
    speakText(`${date}। ${title}। विवरण: ${details}`, lang);
  };

  return (
    <div className="space-y-8">
      {/* -------------------- SECTION 1: PROMINENT DEVELOPER PROFILE CARD -------------------- */}
      <section aria-label={lang === 'hi' ? 'ऐप निर्माता प्रोफ़ाइल' : 'App Developer Profile'}>
        <DeveloperCard lang={lang} voiceEnabled={voiceEnabled} />
      </section>

      {/* -------------------- SECTION 2: SCHOOL ADDRESS & VISION -------------------- */}
      <section
        aria-label={lang === 'hi' ? 'विद्यालय परिचय एवं संकल्प' : 'School Information and Vision'}
        className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 shadow-md"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-blue-700 text-white flex items-center justify-center shrink-0 shadow-md">
              <School className="w-8 h-8" aria-hidden="true" />
            </div>
            <div>
              <div className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                {lang === 'hi' ? SCHOOL_INFO.departmentHi : SCHOOL_INFO.departmentEn}
              </div>
              <h2 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
                {lang === 'hi' ? SCHOOL_INFO.nameHi : SCHOOL_INFO.nameEn}
              </h2>
              <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300 mt-1 font-medium">
                <MapPin className="w-4 h-4 text-red-600 shrink-0" aria-hidden="true" />
                <span>{lang === 'hi' ? SCHOOL_INFO.fullAddressHi : SCHOOL_INFO.fullAddressEn}</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleReadSchoolVision}
            aria-label={lang === 'hi' ? 'विद्यालय विवरण व संकल्प बोलकर सुनें' : 'Listen to school details and vision'}
            className="min-touch-target px-4 py-2.5 bg-blue-50 dark:bg-blue-950/70 hover:bg-blue-100 dark:hover:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-xl font-bold text-sm flex items-center gap-2 border border-blue-200 dark:border-blue-800 self-start md:self-center transition-all"
          >
            <Volume2 className="w-4 h-4" aria-hidden="true" />
            <span>{lang === 'hi' ? 'विवरण सुनें' : 'Listen About'}</span>
          </button>
        </div>

        {/* Vision Box */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-blue-50/70 dark:bg-slate-800/70 p-5 rounded-2xl border border-blue-200/60 dark:border-slate-700">
            <div className="text-xs font-bold text-blue-900 dark:text-blue-300 uppercase tracking-wider mb-2 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-700 dark:text-blue-400" aria-hidden="true" />
              <span>{lang === 'hi' ? 'हमारा पावन संकल्प (School Vision)' : 'Our Noble Vision'}</span>
            </div>
            <p className="text-sm sm:text-base text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
              {lang === 'hi' ? SCHOOL_INFO.visionHi : SCHOOL_INFO.visionEn}
            </p>
          </div>

          <div className="bg-amber-50/70 dark:bg-slate-800/70 p-5 rounded-2xl border border-amber-200/60 dark:border-slate-700">
            <div className="text-xs font-bold text-amber-900 dark:text-amber-300 uppercase tracking-wider mb-2 flex items-center gap-2">
              <Quote className="w-4 h-4 text-amber-600 dark:text-amber-400" aria-hidden="true" />
              <span>{lang === 'hi' ? 'प्रेरक संदेश (Inspiring Thought)' : 'Inspiring Thought'}</span>
            </div>
            <p className="text-sm sm:text-base text-slate-800 dark:text-slate-200 italic leading-relaxed">
              {lang === 'hi' ? SCHOOL_INFO.quoteHi : SCHOOL_INFO.quoteEn}
            </p>
          </div>
        </div>
      </section>

      {/* -------------------- SECTION 3: DAILY PRAYERS & NATIONAL ANTHEM -------------------- */}
      <section
        aria-label={lang === 'hi' ? 'दैनिक प्रार्थना व राष्ट्रगान' : 'Daily Prayers and National Anthem'}
        className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 shadow-md"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 shadow-sm">
              <Heart className="w-6 h-6" aria-hidden="true" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                {lang === 'hi' ? 'दैनिक प्रार्थना व राष्ट्रगान' : 'Daily School Prayers & Anthem'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                {lang === 'hi'
                  ? 'सुबह की सभा में गाई जाने वाली पवित्र प्रार्थनाएं व राष्ट्रगान बड़े सुगम फॉन्ट में।'
                  : 'Daily morning assembly prayer hymns and National Anthem in accessible font.'}
              </p>
            </div>
          </div>

          {/* Master Read Aloud Action Button */}
          <button
            type="button"
            onClick={handleReadFullPrayer}
            aria-label={
              isReadingPrayer
                ? (lang === 'hi' ? 'प्रार्थना वाचन रोकें' : 'Stop reading prayer')
                : (lang === 'hi' ? 'पूरी प्रार्थना आवाज़ में सुनें' : 'Listen to full prayer aloud')
            }
            className={`min-touch-target px-5 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 shadow-md transition-all active:scale-95 ${
              isReadingPrayer
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-blue-700 hover:bg-blue-800 text-white'
            }`}
          >
            {isReadingPrayer ? (
              <>
                <VolumeX className="w-4 h-4" aria-hidden="true" />
                <span>{lang === 'hi' ? 'वाचन रोकें (Stop)' : 'Stop Audio'}</span>
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4" aria-hidden="true" />
                <span>{lang === 'hi' ? 'पूरी प्रार्थना सुनें (Play Audio)' : 'Play Full Prayer'}</span>
              </>
            )}
          </button>
        </div>

        {/* Prayer Selection Buttons */}
        <div className="flex flex-wrap gap-2 mb-6" role="tablist" aria-label="Prayers selector">
          {PRAYERS_DATA.map((prayer) => (
            <button
              key={prayer.id}
              type="button"
              role="tab"
              aria-selected={selectedPrayerId === prayer.id}
              onClick={() => {
                triggerHaptic(20);
                setSelectedPrayerId(prayer.id);
                if (isReadingPrayer) stopSpeaking();
                setIsReadingPrayer(false);
              }}
              className={`min-touch-target px-4 py-2 rounded-xl text-xs sm:text-sm font-bold border transition-all ${
                selectedPrayerId === prayer.id
                  ? 'bg-blue-700 text-white border-blue-700 shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:bg-slate-200'
              }`}
            >
              {lang === 'hi' ? prayer.titleHi.split(':')[1] || prayer.titleHi : prayer.titleEn.split(':')[1] || prayer.titleEn}
            </button>
          ))}
        </div>

        {/* Prayer Card Content */}
        <div className="bg-slate-50 dark:bg-slate-800/80 rounded-2xl p-5 sm:p-7 border-2 border-slate-200 dark:border-slate-700">
          <div className="border-b border-slate-200 dark:border-slate-700 pb-4 mb-5">
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              {lang === 'hi' ? selectedPrayer.titleHi : selectedPrayer.titleEn}
            </h3>
            <p className="text-xs sm:text-sm text-amber-700 dark:text-amber-300 mt-1 font-semibold">
              {lang === 'hi' ? selectedPrayer.meaningHi : selectedPrayer.meaningEn}
            </p>
          </div>

          {/* Stanzas Display with Individual Listen Trigger */}
          <div className="space-y-5">
            {(lang === 'hi' ? selectedPrayer.stanzasHi : selectedPrayer.stanzasEn).map((stanza, idx) => (
              <div
                key={idx}
                className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm hover:border-blue-400 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <p className="text-base sm:text-lg md:text-xl font-semibold text-slate-900 dark:text-white whitespace-pre-line leading-relaxed">
                    {stanza}
                  </p>
                  <button
                    type="button"
                    onClick={() => handleReadSingleStanza(stanza)}
                    aria-label={lang === 'hi' ? `पद ${idx + 1} आवाज़ में सुनें` : `Listen stanza ${idx + 1}`}
                    title={lang === 'hi' ? 'यह पद सुनें' : 'Listen this stanza'}
                    className="p-2 text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-slate-800 rounded-lg shrink-0"
                  >
                    <Volume2 className="w-5 h-5" aria-hidden="true" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* -------------------- SECTION 4: NOTICE BOARD -------------------- */}
      <section
        aria-label={lang === 'hi' ? 'विद्यालय सूचना पट्ट (Notice Board)' : 'School Notice Board'}
        className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 shadow-md"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-sm">
              <Bell className="w-6 h-6" aria-hidden="true" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                {lang === 'hi' ? 'सूचना पट्ट (Notice Board)' : 'Official Notice Board'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                {lang === 'hi' ? 'परीक्षा, प्रवेश, छात्र कल्याण व खेलकूद की नवीनतम सूचनाएं।' : 'Latest announcements for exams, admissions, and student welfare.'}
              </p>
            </div>
          </div>

          {/* Notice Filter */}
          <div className="flex flex-wrap gap-1.5" role="group" aria-label="Notice filter">
            {[
              { id: 'all', labelHi: 'सभी सूचनाएं', labelEn: 'All' },
              { id: 'academic', labelHi: 'प्रवेश / पढ़ाई', labelEn: 'Academics' },
              { id: 'exam', labelHi: 'बोर्ड परीक्षा', labelEn: 'Exams' },
              { id: 'welfare', labelHi: 'कल्याण', labelEn: 'Welfare' },
            ].map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setNoticeFilter(f.id)}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                  noticeFilter === f.id
                    ? 'bg-blue-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {lang === 'hi' ? f.labelHi : f.labelEn}
              </button>
            ))}
          </div>
        </div>

        {/* Notice List */}
        <div className="space-y-4" role="feed" aria-label="Notices Feed">
          {filteredNotices.map((notice) => (
            <article
              key={notice.id}
              className={`p-5 rounded-2xl border-2 transition-all ${
                notice.isUrgent
                  ? 'bg-amber-50/50 dark:bg-slate-800/80 border-amber-300 dark:border-amber-700/80'
                  : 'bg-slate-50/60 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                    <Calendar className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>{notice.date}</span>
                    {notice.isUrgent && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-red-600 font-bold uppercase">{lang === 'hi' ? 'महत्वपूर्ण' : 'Important'}</span>
                      </>
                    )}
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                    {lang === 'hi' ? notice.titleHi : notice.titleEn}
                  </h3>
                  <p className="text-sm text-slate-700 dark:text-slate-300 mt-2 leading-relaxed">
                    {lang === 'hi' ? notice.detailsHi : notice.detailsEn}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => handleReadNotice(notice)}
                  aria-label={lang === 'hi' ? `सूचना सुनें: ${notice.titleHi}` : `Listen notice: ${notice.titleEn}`}
                  className="min-touch-target px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 self-start shrink-0 shadow-sm active:scale-95 transition-transform"
                >
                  <Volume2 className="w-4 h-4" aria-hidden="true" />
                  <span>{lang === 'hi' ? 'सुनें' : 'Listen'}</span>
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};
