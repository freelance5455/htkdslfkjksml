import React from 'react';
import { ActiveTab, Language } from '../types';
import { speakText, triggerHaptic } from '../utils/speech';
import { School, Wrench, BookOpenCheck } from 'lucide-react';

interface TabsNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  lang: Language;
  voiceEnabled: boolean;
}

export const TabsNav: React.FC<TabsNavProps> = ({
  activeTab,
  onTabChange,
  lang,
  voiceEnabled,
}) => {
  const tabs = [
    {
      id: 'about' as ActiveTab,
      labelHi: 'हमारा विद्यालय',
      labelEn: 'About School',
      descHi: 'विद्यालय परिचय, प्रार्थना व सूचना पट्ट',
      descEn: 'Campus, daily prayer, notices & developer',
      icon: School,
    },
    {
      id: 'tools' as ActiveTab,
      labelHi: 'उपयोगी टूल्स',
      labelEn: 'Accessible Tools',
      descHi: 'टॉकिंग कैलकुलेटर, आयु गणक व बैटरी',
      descEn: 'Talking calc, age finder, live time & battery',
      icon: Wrench,
    },
    {
      id: 'knowledge' as ActiveTab,
      labelHi: 'ज्ञान एवं संदर्भ',
      labelEn: 'Study & Rights',
      descHi: 'RPwD एक्ट, संविधान व सामान्य ज्ञान',
      descEn: 'RPwD 2016 Act, Constitution & GK',
      icon: BookOpenCheck,
    },
  ];

  const handleTabClick = (tabId: ActiveTab, labelHi: string, labelEn: string) => {
    triggerHaptic(30);
    onTabChange(tabId);
    if (voiceEnabled) {
      const speech = lang === 'hi' ? `${labelHi} टैब खोला गया` : `${labelEn} tab opened`;
      speakText(speech, lang);
    }
  };

  return (
    <>
      {/* Desktop / Tablet Navigation Bar (Above Content) */}
      <nav
        role="tablist"
        aria-label={lang === 'hi' ? 'मुख्य नेविगेशन टैब्स' : 'Main Navigation Tabs'}
        className="hidden md:grid grid-cols-3 gap-3 p-1.5 bg-slate-200/80 dark:bg-slate-800/80 rounded-2xl border border-slate-300 dark:border-slate-700"
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              role="tab"
              type="button"
              aria-selected={isActive}
              onClick={() => handleTabClick(tab.id, tab.labelHi, tab.labelEn)}
              className={`min-touch-target py-3 px-4 rounded-xl flex items-center justify-center gap-3 font-bold text-sm lg:text-base transition-all ${
                isActive
                  ? 'bg-blue-700 text-white shadow-md'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300/70 dark:hover:bg-slate-700/70'
              }`}
            >
              <Icon className="w-5 h-5 shrink-0" aria-hidden="true" />
              <div className="text-left">
                <div>{lang === 'hi' ? tab.labelHi : tab.labelEn}</div>
                <div className="text-[11px] font-normal opacity-85 hidden lg:block">
                  {lang === 'hi' ? tab.descHi : tab.descEn}
                </div>
              </div>
            </button>
          );
        })}
      </nav>

      {/* Mobile Fixed Bottom Navigation Bar (Natural Thumb Zone Ergonomics) */}
      <nav
        role="tablist"
        aria-label={lang === 'hi' ? 'मोबाइल निचला नेविगेशन' : 'Mobile Bottom Navigation'}
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t-2 border-slate-200 dark:border-slate-800 shadow-2xl px-2 py-1.5"
      >
        <div className="grid grid-cols-3 gap-1 max-w-md mx-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                role="tab"
                type="button"
                aria-selected={isActive}
                onClick={() => handleTabClick(tab.id, tab.labelHi, tab.labelEn)}
                className={`min-touch-target flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all ${
                  isActive
                    ? 'text-blue-700 dark:text-blue-400 font-black'
                    : 'text-slate-600 dark:text-slate-400 font-medium hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <div
                  className={`p-1 rounded-lg transition-transform ${
                    isActive ? 'scale-110 bg-blue-50 dark:bg-blue-950/70' : ''
                  }`}
                >
                  <Icon className="w-5 h-5" aria-hidden="true" />
                </div>
                <span className="text-[11px] mt-0.5 tracking-tight truncate max-w-[95px]">
                  {lang === 'hi' ? tab.labelHi : tab.labelEn}
                </span>
                {isActive && (
                  <span
                    className="w-1.5 h-1.5 bg-blue-700 dark:bg-blue-400 rounded-full mt-0.5"
                    aria-hidden="true"
                  />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
