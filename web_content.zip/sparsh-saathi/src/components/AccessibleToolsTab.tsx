import React, { useState, useEffect, useRef } from 'react';
import { Language } from '../types';
import { speakText, triggerHaptic, getSpokenSymbol } from '../utils/speech';
import { BHARATI_BRAILLE_LETTERS } from '../data/content';
import {
  Calculator as CalcIcon,
  Calendar,
  Battery,
  BatteryCharging,
  Clock,
  Volume2,
  Trash2,
  Sparkles,
  Info,
  RotateCcw,
  BookOpen
} from 'lucide-react';

interface AccessibleToolsTabProps {
  lang: Language;
  voiceEnabled: boolean;
}

export const AccessibleToolsTab: React.FC<AccessibleToolsTabProps> = ({
  lang,
  voiceEnabled,
}) => {
  // Sub-tool toggle for comfortable mobile scrolling
  const [activeSubTool, setActiveSubTool] = useState<'calc' | 'age' | 'device' | 'braille'>('calc');

  // ---------- CALCULATOR STATE ----------
  const [calcInput, setCalcInput] = useState<string>('0');
  const [calcResult, setCalcResult] = useState<string>('');
  const [calcHistory, setCalcHistory] = useState<{ expr: string; res: string }[]>([]);
  const [calcAnnouncement, setCalcAnnouncement] = useState<string>('');

  // ---------- AGE CALCULATOR STATE ----------
  const [birthDate, setBirthDate] = useState<string>('2008-01-01');
  const [ageResult, setAgeResult] = useState<{
    years: number;
    months: number;
    days: number;
    totalDays: number;
    dayOfWeekHi: string;
    dayOfWeekEn: string;
    nextBirthdayDays: number;
  } | null>(null);

  // ---------- DEVICE STATUS STATE ----------
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [isCharging, setIsCharging] = useState<boolean | null>(null);
  const [batterySupported, setBatterySupported] = useState<boolean>(true);

  // ---------- BRAILLE EXPLORER STATE ----------
  const [activeDots, setActiveDots] = useState<number[]>([]);

  // Clock ticker
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Battery API check
  useEffect(() => {
    let batteryObj: any = null;
    const updateBattery = (battery: any) => {
      setBatteryLevel(Math.round(battery.level * 100));
      setIsCharging(battery.charging);
    };

    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        batteryObj = battery;
        updateBattery(battery);
        battery.addEventListener('levelchange', () => updateBattery(battery));
        battery.addEventListener('chargingchange', () => updateBattery(battery));
      }).catch(() => {
        setBatterySupported(false);
      });
    } else {
      setBatterySupported(false);
    }
  }, []);

  // Compute Age on load or date change
  const calculateAge = (selectedDateStr: string) => {
    if (!selectedDateStr) return;
    const birth = new Date(selectedDateStr);
    const today = new Date();

    if (isNaN(birth.getTime()) || birth > today) {
      const msg = lang === 'hi' ? 'कृपया मान्य जन्म तिथि चुनें जो आज से पूर्व की हो।' : 'Please choose a valid birth date prior to today.';
      setCalcAnnouncement(msg);
      if (voiceEnabled) speakText(msg, lang);
      return;
    }

    let years = today.getFullYear() - birth.getFullYear();
    let months = today.getMonth() - birth.getMonth();
    let days = today.getDate() - birth.getDate();

    if (days < 0) {
      months -= 1;
      const prevMonth = new Date(today.getFullYear(), today.getMonth(), 0);
      days += prevMonth.getDate();
    }
    if (months < 0) {
      years -= 1;
      months += 12;
    }

    const diffTime = Math.abs(today.getTime() - birth.getTime());
    const totalDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    // Day of week
    const daysOfWeekHi = ['रविवार (Sunday)', 'सोमवार (Monday)', 'मंगलवार (Tuesday)', 'बुधवार (Wednesday)', 'गुरुवार (Thursday)', 'शुक्रवार (Friday)', 'शनिवार (Saturday)'];
    const daysOfWeekEn = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const birthDayIndex = birth.getDay();

    // Next Birthday
    const nextBday = new Date(today.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBday < today) {
      nextBday.setFullYear(today.getFullYear() + 1);
    }
    const daysUntilNext = Math.ceil((nextBday.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    const result = {
      years,
      months,
      days,
      totalDays,
      dayOfWeekHi: daysOfWeekHi[birthDayIndex],
      dayOfWeekEn: daysOfWeekEn[birthDayIndex],
      nextBirthdayDays: daysUntilNext,
    };
    setAgeResult(result);

    const speechText = lang === 'hi'
      ? `आपकी सही आयु है: ${years} वर्ष, ${months} महीने, और ${days} दिन। आपका जन्म दिन था ${daysOfWeekHi[birthDayIndex]}। अगले जन्मदिन में ${daysUntilNext} दिन शेष हैं।`
      : `Your exact age is: ${years} years, ${months} months, and ${days} days. You were born on ${daysOfWeekEn[birthDayIndex]}. There are ${daysUntilNext} days remaining until your next birthday.`;

    setCalcAnnouncement(speechText);
    if (voiceEnabled) {
      speakText(speechText, lang);
    }
  };

  useEffect(() => {
    calculateAge(birthDate);
  }, []);

  // ---------- CALCULATOR LOGIC ----------
  const handleCalcPress = (val: string) => {
    triggerHaptic(20);
    const spoken = getSpokenSymbol(val, lang);

    if (val === 'C') {
      setCalcInput('0');
      setCalcResult('');
      setCalcAnnouncement(lang === 'hi' ? 'गणना साफ की गई' : 'Calculator cleared');
      if (voiceEnabled) speakText(lang === 'hi' ? 'साफ किया' : 'Cleared', lang);
      return;
    }

    if (val === 'DEL') {
      setCalcInput((prev) => {
        if (prev.length <= 1 || prev === 'Error') return '0';
        return prev.slice(0, -1);
      });
      if (voiceEnabled) speakText(spoken, lang);
      return;
    }

    if (val === '=') {
      try {
        // Sanitize and evaluate expression safely
        const sanitized = calcInput
          .replace(/×/g, '*')
          .replace(/÷/g, '/')
          .replace(/[^0-9+\-*/.()%]/g, '');

        if (!sanitized) return;

        // Simple math eval with Function
        // Handle percent
        const parsedWithPercent = sanitized.replace(/(\d+(\.\d+)?)%/g, '($1/100)');
        // eslint-disable-next-line no-new-func
        const evaluated = Function(`"use strict"; return (${parsedWithPercent})`)();
        const formatted = Number.isFinite(evaluated)
          ? parseFloat(evaluated.toFixed(6)).toString()
          : 'Error';

        setCalcResult(formatted);
        setCalcHistory((prev) => [{ expr: calcInput, res: formatted }, ...prev.slice(0, 5)]);

        const resultSpeech = lang === 'hi'
          ? `परिणाम है: ${formatted}`
          : `Result is: ${formatted}`;

        setCalcAnnouncement(resultSpeech);
        if (voiceEnabled) {
          speakText(resultSpeech, lang);
        }
      } catch (e) {
        setCalcResult('Error');
        const errSpeech = lang === 'hi' ? 'अमान्य गणना' : 'Invalid expression';
        setCalcAnnouncement(errSpeech);
        if (voiceEnabled) speakText(errSpeech, lang);
      }
      return;
    }

    // Append digit or operator
    setCalcInput((prev) => {
      if (prev === '0' && !['+', '-', '×', '÷', '%', '.'].includes(val)) {
        return val;
      }
      return prev + val;
    });

    if (voiceEnabled) {
      speakText(spoken, lang);
    }
  };

  // Announce Device & Time Status
  const handleAnnounceDeviceStatus = () => {
    triggerHaptic(30);
    const hours = currentTime.getHours();
    const minutes = currentTime.getMinutes();
    const isPM = hours >= 12;
    const hour12 = hours % 12 || 12;

    let peharHi = 'प्रातःकाल';
    if (hours >= 12 && hours < 16) peharHi = 'दोपहर';
    else if (hours >= 16 && hours < 20) peharHi = 'सायंकाल';
    else if (hours >= 20 || hours < 4) peharHi = 'रात्रि';

    const dayNameHi = ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'][currentTime.getDay()];
    const dayNameEn = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][currentTime.getDay()];

    const dateStrHi = `${dayNameHi}, ${currentTime.getDate()} ${currentTime.toLocaleDateString('hi-IN', { month: 'long' })} ${currentTime.getFullYear()}`;
    const dateStrEn = `${dayNameEn}, ${currentTime.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}`;

    let batteryTextHi = batteryLevel !== null
      ? `बैटरी स्तर ${batteryLevel} प्रतिशत है${isCharging ? ' और चार्जर से चार्ज हो रही है' : ''}।`
      : 'बैटरी स्थिति उपलब्ध नहीं है।';

    let batteryTextEn = batteryLevel !== null
      ? `Battery level is ${batteryLevel} percent${isCharging ? ' and charging' : ''}.`
      : 'Battery status is unavailable.';

    const speechText = lang === 'hi'
      ? `वर्तमान समय ${peharHi} ${hour12} बजकर ${minutes} मिनट है। आज की तारीख ${dateStrHi} है। ${batteryTextHi}`
      : `Current time is ${hour12}:${minutes.toString().padStart(2, '0')} ${isPM ? 'PM' : 'AM'}. Today is ${dateStrEn}. ${batteryTextEn}`;

    setCalcAnnouncement(speechText);
    speakText(speechText, lang);
  };

  // Toggle braille dot
  const toggleDot = (dotNum: number) => {
    triggerHaptic(20);
    setActiveDots((prev) => {
      const exists = prev.includes(dotNum);
      const next = exists ? prev.filter((d) => d !== dotNum) : [...prev, dotNum].sort();
      const action = exists
        ? (lang === 'hi' ? `बिंदु ${dotNum} हटाया` : `Dot ${dotNum} off`)
        : (lang === 'hi' ? `बिंदु ${dotNum} चुना` : `Dot ${dotNum} on`);
      if (voiceEnabled) speakText(action, lang);
      return next;
    });
  };

  return (
    <div className="space-y-6">
      {/* Hidden Live Region for Screen Readers */}
      <div className="sr-only" aria-live="polite" role="status">
        {calcAnnouncement}
      </div>

      {/* Segmented Sub-tool Switcher */}
      <div
        role="tablist"
        aria-label={lang === 'hi' ? 'उपयोगी टूल्स चुनें' : 'Choose Accessible Tool'}
        className="flex flex-wrap p-1.5 bg-slate-200 dark:bg-slate-800 rounded-2xl gap-1.5"
      >
        <button
          role="tab"
          type="button"
          aria-selected={activeSubTool === 'calc'}
          onClick={() => {
            setActiveSubTool('calc');
            triggerHaptic(25);
            if (voiceEnabled) speakText(lang === 'hi' ? 'टॉकिंग कैलकुलेटर खोला' : 'Opened Talking Calculator', lang);
          }}
          className={`flex-1 min-w-[120px] min-h-[44px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
            activeSubTool === 'calc'
              ? 'bg-blue-700 text-white shadow-md'
              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          <CalcIcon className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{lang === 'hi' ? 'बोलने वाला कैलकुलेटर' : 'Talking Calc'}</span>
        </button>

        <button
          role="tab"
          type="button"
          aria-selected={activeSubTool === 'age'}
          onClick={() => {
            setActiveSubTool('age');
            triggerHaptic(25);
            if (voiceEnabled) speakText(lang === 'hi' ? 'आयु एवं दिन गणक खोला' : 'Opened Age Calculator', lang);
          }}
          className={`flex-1 min-w-[120px] min-h-[44px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
            activeSubTool === 'age'
              ? 'bg-blue-700 text-white shadow-md'
              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          <Calendar className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{lang === 'hi' ? 'आयु व दिन गणक' : 'Age & Day'}</span>
        </button>

        <button
          role="tab"
          type="button"
          aria-selected={activeSubTool === 'device'}
          onClick={() => {
            setActiveSubTool('device');
            triggerHaptic(25);
            if (voiceEnabled) speakText(lang === 'hi' ? 'समय व बैटरी स्थिति खोली' : 'Opened Device Status', lang);
          }}
          className={`flex-1 min-w-[120px] min-h-[44px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
            activeSubTool === 'device'
              ? 'bg-blue-700 text-white shadow-md'
              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          <Clock className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{lang === 'hi' ? 'समय व बैटरी' : 'Time & Battery'}</span>
        </button>

        <button
          role="tab"
          type="button"
          aria-selected={activeSubTool === 'braille'}
          onClick={() => {
            setActiveSubTool('braille');
            triggerHaptic(25);
            if (voiceEnabled) speakText(lang === 'hi' ? 'ब्रेल लिपि संदर्भ खोला' : 'Opened Braille Explorer', lang);
          }}
          className={`flex-1 min-w-[120px] min-h-[44px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
            activeSubTool === 'braille'
              ? 'bg-blue-700 text-white shadow-md'
              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          <BookOpen className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{lang === 'hi' ? 'ब्रेल संदर्भ' : 'Braille Guide'}</span>
        </button>
      </div>

      {/* -------------------- TOOL 1: TALKING CALCULATOR -------------------- */}
      {activeSubTool === 'calc' && (
        <section
          aria-label={lang === 'hi' ? 'सुलभ बोलने वाला कैलकुलेटर' : 'Accessible Talking Calculator'}
          className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-7 shadow-md"
        >
          <div className="flex items-center justify-between gap-3 mb-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CalcIcon className="w-6 h-6 text-blue-700 dark:text-blue-400" aria-hidden="true" />
                <span>{lang === 'hi' ? 'सुगम टॉकिंग कैलकुलेटर' : 'Accessible Talking Calculator'}</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
                {lang === 'hi'
                  ? 'बड़े अक्षरों व स्पष्ट ध्वनि संकेत युक्त। हर बटन दबाने पर अंक और परिणाम बोलेगा।'
                  : 'Large tactile keys with speech announcement for every digit and result.'}
              </p>
            </div>

            {/* Quick replay voice button */}
            {calcResult && (
              <button
                type="button"
                onClick={() => {
                  const speech = lang === 'hi' ? `परिणाम है: ${calcResult}` : `Result is: ${calcResult}`;
                  speakText(speech, lang);
                }}
                aria-label={lang === 'hi' ? `परिणाम पुनः सुनें: ${calcResult}` : `Speak result again: ${calcResult}`}
                className="min-touch-target px-3.5 py-2 bg-amber-100 hover:bg-amber-200 dark:bg-amber-950 dark:hover:bg-amber-900 text-amber-900 dark:text-amber-200 font-bold rounded-xl flex items-center gap-1.5 text-xs sm:text-sm border border-amber-300 dark:border-amber-700"
              >
                <Volume2 className="w-4 h-4" aria-hidden="true" />
                <span>{lang === 'hi' ? 'सुनें' : 'Speak'}</span>
              </button>
            )}
          </div>

          {/* Calculator Display Screen */}
          <div
            tabIndex={0}
            role="region"
            aria-label={
              lang === 'hi'
                ? `कैलकुलेटर स्क्रीन। अभिव्यक्ति: ${calcInput}। परिणाम: ${calcResult || 'शून्य'}`
                : `Calculator screen. Expression: ${calcInput}. Result: ${calcResult || 'none'}`
            }
            className="bg-slate-900 text-white rounded-2xl p-5 mb-5 shadow-inner border-2 border-slate-700 focus:outline-none focus:ring-4 focus:ring-amber-400"
          >
            <div className="text-right text-xs sm:text-sm text-slate-400 font-mono tracking-wider break-all min-h-[20px]">
              {calcInput}
            </div>
            <div className="text-right text-3xl sm:text-4xl md:text-5xl font-mono font-bold text-amber-300 tracking-tight mt-1 overflow-x-auto">
              {calcResult || calcInput}
            </div>
          </div>

          {/* Keypad Grid (Ergonomic, Min 52px Touch Hitbox) */}
          <div className="grid grid-cols-4 gap-2.5 sm:gap-3">
            {/* Row 1 */}
            <button
              type="button"
              onClick={() => handleCalcPress('C')}
              aria-label={lang === 'hi' ? 'साफ करें (Clear)' : 'Clear All'}
              className="min-h-[54px] rounded-2xl bg-red-100 hover:bg-red-200 dark:bg-red-950/80 dark:hover:bg-red-900 text-red-700 dark:text-red-300 font-extrabold text-lg sm:text-xl border-2 border-red-300 dark:border-red-800 transition-all active:scale-95"
            >
              C
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('DEL')}
              aria-label={lang === 'hi' ? 'पिछला अंक मिटाएं (Backspace)' : 'Backspace'}
              className="min-h-[54px] rounded-2xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold text-base sm:text-lg border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              ⌫
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('%')}
              aria-label={lang === 'hi' ? 'प्रतिशत' : 'Percent'}
              className="min-h-[54px] rounded-2xl bg-blue-100 hover:bg-blue-200 dark:bg-blue-950/70 text-blue-900 dark:text-blue-200 font-bold text-lg border-2 border-blue-300 dark:border-blue-800 transition-all active:scale-95"
            >
              %
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('÷')}
              aria-label={lang === 'hi' ? 'भाग (Divide)' : 'Divide'}
              className="min-h-[54px] rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-900 font-black text-2xl border-2 border-amber-600 shadow-sm transition-all active:scale-95"
            >
              ÷
            </button>

            {/* Row 2 */}
            <button
              type="button"
              onClick={() => handleCalcPress('7')}
              aria-label={lang === 'hi' ? 'सात (7)' : 'Seven (7)'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              7
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('8')}
              aria-label={lang === 'hi' ? 'आठ (8)' : 'Eight (8)'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              8
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('9')}
              aria-label={lang === 'hi' ? 'नौ (9)' : 'Nine (9)'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              9
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('×')}
              aria-label={lang === 'hi' ? 'गुणा (Multiply)' : 'Multiply'}
              className="min-h-[54px] rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-900 font-black text-2xl border-2 border-amber-600 shadow-sm transition-all active:scale-95"
            >
              ×
            </button>

            {/* Row 3 */}
            <button
              type="button"
              onClick={() => handleCalcPress('4')}
              aria-label={lang === 'hi' ? 'चार (4)' : 'Four (4)'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              4
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('5')}
              aria-label={lang === 'hi' ? 'पाँच (5)' : 'Five (5)'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              5
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('6')}
              aria-label={lang === 'hi' ? 'छह (6)' : 'Six (6)'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              6
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('-')}
              aria-label={lang === 'hi' ? 'घटाव (Subtract)' : 'Subtract'}
              className="min-h-[54px] rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-900 font-black text-2xl border-2 border-amber-600 shadow-sm transition-all active:scale-95"
            >
              −
            </button>

            {/* Row 4 */}
            <button
              type="button"
              onClick={() => handleCalcPress('1')}
              aria-label={lang === 'hi' ? 'एक (1)' : 'One (1)'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              1
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('2')}
              aria-label={lang === 'hi' ? 'दो (2)' : 'Two (2)'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              2
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('3')}
              aria-label={lang === 'hi' ? 'तीन (3)' : 'Three (3)'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              3
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('+')}
              aria-label={lang === 'hi' ? 'जोड़ (Plus)' : 'Add Plus'}
              className="min-h-[54px] rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-900 font-black text-2xl border-2 border-amber-600 shadow-sm transition-all active:scale-95"
            >
              +
            </button>

            {/* Row 5 */}
            <button
              type="button"
              onClick={() => handleCalcPress('0')}
              aria-label={lang === 'hi' ? 'शून्य (0)' : 'Zero (0)'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              0
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('.')}
              aria-label={lang === 'hi' ? 'दशमलव (Decimal Point)' : 'Decimal Point'}
              className="min-h-[54px] rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 text-slate-900 dark:text-white font-extrabold text-xl sm:text-2xl border-2 border-slate-300 dark:border-slate-700 transition-all active:scale-95"
            >
              .
            </button>
            <button
              type="button"
              onClick={() => handleCalcPress('=')}
              aria-label={lang === 'hi' ? 'बराबर (Equals)' : 'Equals result'}
              className="col-span-2 min-h-[54px] rounded-2xl bg-blue-700 hover:bg-blue-800 text-white font-black text-2xl border-2 border-blue-800 shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <span>=</span>
              <span className="text-xs font-semibold uppercase tracking-wider">{lang === 'hi' ? 'उत्तर' : 'Solve'}</span>
            </button>
          </div>

          {/* History */}
          {calcHistory.length > 0 && (
            <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                <span>{lang === 'hi' ? 'हाल की गणनाएं' : 'Recent Calculations'}</span>
                <button
                  type="button"
                  onClick={() => setCalcHistory([])}
                  className="text-red-600 hover:text-red-700 font-semibold"
                >
                  {lang === 'hi' ? 'इतिहास मिटाएं' : 'Clear History'}
                </button>
              </div>
              <ul className="space-y-1.5" role="list">
                {calcHistory.map((item, idx) => (
                  <li
                    key={idx}
                    className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 text-xs sm:text-sm font-mono"
                  >
                    <span className="text-slate-600 dark:text-slate-400">{item.expr} =</span>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-blue-700 dark:text-blue-300">{item.res}</span>
                      <button
                        type="button"
                        onClick={() => {
                          speakText(`${item.expr} बराबर ${item.res}`, lang);
                        }}
                        aria-label={lang === 'hi' ? `${item.expr} बराबर ${item.res} बोलें` : `Speak ${item.expr} equals ${item.res}`}
                        className="p-1 text-slate-500 hover:text-blue-600"
                      >
                        <Volume2 className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>
      )}

      {/* -------------------- TOOL 2: AGE & DAY CALCULATOR -------------------- */}
      {activeSubTool === 'age' && (
        <section
          aria-label={lang === 'hi' ? 'आयु एवं जन्म का दिन गणक' : 'Exact Age & Day of Birth Calculator'}
          className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-7 shadow-md"
        >
          <div className="flex items-center gap-3 mb-4">
            <Calendar className="w-6 h-6 text-blue-700 dark:text-blue-400 shrink-0" aria-hidden="true" />
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                {lang === 'hi' ? 'आयु एवं जन्म दिन गणक' : 'Exact Age & Day Calculator'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
                {lang === 'hi'
                  ? 'अपनी जन्म तिथि चुनें — यह आपकी सटीक आयु (वर्ष, माह, दिन) और जन्म का वार (सोमवार, मंगलवार आदि) बताएगा।'
                  : 'Select your birth date to calculate exact years, months, days, and day of birth.'}
              </p>
            </div>
          </div>

          {/* Date Picker Input */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-700 mb-6">
            <label
              htmlFor="birth-date-input"
              className="block text-sm sm:text-base font-bold text-slate-900 dark:text-white mb-2"
            >
              {lang === 'hi' ? 'अपनी जन्म तिथि चुनें (Select Date of Birth):' : 'Select Date of Birth:'}
            </label>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                id="birth-date-input"
                type="date"
                value={birthDate}
                onChange={(e) => {
                  setBirthDate(e.target.value);
                  calculateAge(e.target.value);
                }}
                max={new Date().toISOString().split('T')[0]}
                className="flex-1 min-touch-target px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border-2 border-blue-600 text-slate-900 dark:text-white text-base font-bold focus:outline-none focus:ring-4 focus:ring-amber-400"
                aria-label={lang === 'hi' ? 'जन्म तिथि चुनें' : 'Choose Date of Birth'}
              />

              <button
                type="button"
                onClick={() => calculateAge(birthDate)}
                className="min-touch-target px-6 py-3 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl shadow-md flex items-center justify-center gap-2 active:scale-95 transition-transform"
              >
                <Sparkles className="w-4 h-4" aria-hidden="true" />
                <span>{lang === 'hi' ? 'आयु गणना करें' : 'Calculate Age'}</span>
              </button>
            </div>
          </div>

          {/* Age Result Cards */}
          {ageResult && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                <div className="bg-blue-50 dark:bg-blue-950/60 border-2 border-blue-200 dark:border-blue-900/60 p-4 rounded-2xl text-center">
                  <div className="text-xs font-bold text-blue-900 dark:text-blue-300 uppercase">
                    {lang === 'hi' ? 'वर्ष (Years)' : 'Years'}
                  </div>
                  <div className="text-3xl sm:text-4xl font-extrabold text-blue-700 dark:text-blue-400 mt-1 tabular-nums">
                    {ageResult.years}
                  </div>
                </div>

                <div className="bg-amber-50 dark:bg-amber-950/60 border-2 border-amber-200 dark:border-amber-900/60 p-4 rounded-2xl text-center">
                  <div className="text-xs font-bold text-amber-900 dark:text-amber-300 uppercase">
                    {lang === 'hi' ? 'महीने (Months)' : 'Months'}
                  </div>
                  <div className="text-3xl sm:text-4xl font-extrabold text-amber-600 dark:text-amber-400 mt-1 tabular-nums">
                    {ageResult.months}
                  </div>
                </div>

                <div className="bg-emerald-50 dark:bg-emerald-950/60 border-2 border-emerald-200 dark:border-emerald-900/60 p-4 rounded-2xl text-center">
                  <div className="text-xs font-bold text-emerald-900 dark:text-emerald-300 uppercase">
                    {lang === 'hi' ? 'दिन (Days)' : 'Days'}
                  </div>
                  <div className="text-3xl sm:text-4xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1 tabular-nums">
                    {ageResult.days}
                  </div>
                </div>
              </div>

              {/* Day of week & Birthday info */}
              <div className="p-4 sm:p-5 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-300 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    {lang === 'hi' ? 'जन्म का वार (Day of Birth):' : 'Born on Day of Week:'}
                  </span>
                  <span className="text-base font-extrabold text-blue-800 dark:text-blue-300">
                    {lang === 'hi' ? ageResult.dayOfWeekHi : ageResult.dayOfWeekEn}
                  </span>
                </div>

                <div className="flex items-center justify-between flex-wrap gap-2">
                  <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    {lang === 'hi' ? 'कुल जीवन काल (Total Days Lived):' : 'Total Days Lived:'}
                  </span>
                  <span className="text-base font-bold text-slate-900 dark:text-white tabular-nums">
                    {ageResult.totalDays.toLocaleString(lang === 'hi' ? 'hi-IN' : 'en-US')} {lang === 'hi' ? 'दिन' : 'days'}
                  </span>
                </div>

                <div className="flex items-center justify-between flex-wrap gap-2">
                  <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    {lang === 'hi' ? 'अगला जन्मदिन आने में:' : 'Next Birthday in:'}
                  </span>
                  <span className="text-base font-bold text-amber-600 dark:text-amber-400 tabular-nums">
                    {ageResult.nextBirthdayDays} {lang === 'hi' ? 'दिन शेष' : 'days to go'}
                  </span>
                </div>
              </div>

              {/* Voice Readout button */}
              <button
                type="button"
                onClick={() => {
                  const speechText = lang === 'hi'
                    ? `आपकी सही आयु है: ${ageResult.years} वर्ष, ${ageResult.months} महीने, और ${ageResult.days} दिन। आपका जन्म दिन था ${ageResult.dayOfWeekHi}। अगले जन्मदिन में ${ageResult.nextBirthdayDays} दिन शेष हैं।`
                    : `Your exact age is: ${ageResult.years} years, ${ageResult.months} months, and ${ageResult.days} days. You were born on ${ageResult.dayOfWeekEn}. There are ${ageResult.nextBirthdayDays} days until your next birthday.`;
                  speakText(speechText, lang);
                }}
                className="w-full min-touch-target py-3 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-2xl flex items-center justify-center gap-2 shadow-md"
              >
                <Volume2 className="w-5 h-5" aria-hidden="true" />
                <span>{lang === 'hi' ? 'आयु परिणाम बोलकर सुनें' : 'Listen Age Breakdown Aloud'}</span>
              </button>
            </div>
          )}
        </section>
      )}

      {/* -------------------- TOOL 3: DEVICE & BATTERY STATUS -------------------- */}
      {activeSubTool === 'device' && (
        <section
          aria-label={lang === 'hi' ? 'लाइव समय व डिवाइस बैटरी स्थिति' : 'Live Time & Device Battery Status'}
          className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-7 shadow-md"
        >
          <div className="flex items-center justify-between gap-3 mb-4">
            <div className="flex items-center gap-3">
              <Clock className="w-6 h-6 text-blue-700 dark:text-blue-400 shrink-0" aria-hidden="true" />
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                  {lang === 'hi' ? 'लाइव समय व डिवाइस स्थिति' : 'Live Time & Battery Status'}
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
                  {lang === 'hi'
                    ? 'एक टैप में वर्तमान समय, दिनांक और आपके फोन/टैबलेट की बैटरी स्तर सुनें।'
                    : 'One-tap audio announcement of current live time, date, and device battery level.'}
                </p>
              </div>
            </div>
          </div>

          {/* Big Clock Display */}
          <div className="bg-gradient-to-br from-blue-900 to-slate-900 text-white p-6 rounded-3xl shadow-lg border-2 border-blue-800 text-center mb-6">
            <div className="text-xs sm:text-sm font-semibold text-blue-200 uppercase tracking-widest">
              {lang === 'hi' ? 'वर्तमान भारतीय मानक समय (IST)' : 'Current Standard Time'}
            </div>
            <div className="text-4xl sm:text-5xl md:text-6xl font-mono font-black text-amber-300 mt-2 tracking-tight tabular-nums">
              {currentTime.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: true,
              })}
            </div>
            <div className="text-sm sm:text-base text-slate-200 mt-2 font-medium">
              {currentTime.toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-IN', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </div>
          </div>

          {/* Battery Status Card */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div className="p-4 sm:p-5 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-100 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0 border border-amber-300 dark:border-amber-800">
                {isCharging ? (
                  <BatteryCharging className="w-7 h-7" aria-hidden="true" />
                ) : (
                  <Battery className="w-7 h-7" aria-hidden="true" />
                )}
              </div>
              <div>
                <div className="text-xs font-bold text-slate-500 uppercase">
                  {lang === 'hi' ? 'डिवाइस बैटरी स्तर' : 'Device Battery Level'}
                </div>
                <div className="text-2xl font-black text-slate-900 dark:text-white mt-0.5 tabular-nums">
                  {batteryLevel !== null ? `${batteryLevel}%` : (lang === 'hi' ? 'सक्रिय' : 'Active')}
                </div>
                <div className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                  {isCharging
                    ? (lang === 'hi' ? '⚡ चार्ज हो रहा है' : '⚡ Charging plugged in')
                    : (lang === 'hi' ? '🔋 बैटरी पर चल रहा है' : '🔋 Discharging')}
                </div>
              </div>
            </div>

            <div className="p-4 sm:p-5 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-blue-100 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 flex items-center justify-center shrink-0 border border-blue-300 dark:border-blue-800">
                <Clock className="w-7 h-7" aria-hidden="true" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-500 uppercase">
                  {lang === 'hi' ? 'दिन का पहर' : 'Time of Day'}
                </div>
                <div className="text-2xl font-black text-slate-900 dark:text-white mt-0.5">
                  {(() => {
                    const h = currentTime.getHours();
                    if (h < 12) return lang === 'hi' ? 'प्रातःकाल (Morning)' : 'Morning';
                    if (h < 16) return lang === 'hi' ? 'दोपहर (Afternoon)' : 'Afternoon';
                    if (h < 20) return lang === 'hi' ? 'सायंकाल (Evening)' : 'Evening';
                    return lang === 'hi' ? 'रात्रि (Night)' : 'Night';
                  })()}
                </div>
                <div className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                  {lang === 'hi' ? 'गोरखपुर, उत्तर प्रदेश' : 'Gorakhpur, Uttar Pradesh'}
                </div>
              </div>
            </div>
          </div>

          {/* Master One-Tap Audio Announcement Button */}
          <button
            type="button"
            onClick={handleAnnounceDeviceStatus}
            className="w-full min-touch-target py-4 bg-blue-700 hover:bg-blue-800 text-white font-extrabold text-base sm:text-lg rounded-2xl flex items-center justify-center gap-2.5 shadow-lg active:scale-95 transition-transform"
          >
            <Volume2 className="w-6 h-6" aria-hidden="true" />
            <span>{lang === 'hi' ? 'वर्तमान समय व बैटरी बोलकर सुनें (Announce)' : 'Announce Time & Battery Aloud'}</span>
          </button>
        </section>
      )}

      {/* -------------------- TOOL 4: BRAILLE QUICK REFERENCE -------------------- */}
      {activeSubTool === 'braille' && (
        <section
          aria-label={lang === 'hi' ? 'ब्रेल लिपि संदर्भ व 6-बिंदु अन्वेषक' : 'Braille Reference & 6-Dot Cell Explorer'}
          className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-7 shadow-md"
        >
          <div className="flex items-center gap-3 mb-4">
            <BookOpen className="w-6 h-6 text-blue-700 dark:text-blue-400 shrink-0" aria-hidden="true" />
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                {lang === 'hi' ? 'इंटरैक्टिव 6-डॉट ब्रेल सेल' : 'Interactive 6-Dot Braille Cell'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
                {lang === 'hi'
                  ? 'बिंदु 1 से 6 पर टैप करके स्थिति समझें। प्रत्येक बिंदु का क्रमांक उच्चारित होगा।'
                  : 'Tap dots 1 to 6 to explore braille dot positions with speech synthesis.'}
              </p>
            </div>
          </div>

          {/* Interactive 6-Dot Braille Cell Box */}
          <div className="bg-slate-900 text-white p-6 rounded-3xl max-w-sm mx-auto shadow-inner border-2 border-amber-400 mb-6">
            <div className="text-center text-xs font-bold text-amber-300 uppercase tracking-widest mb-4">
              {lang === 'hi' ? 'ब्रेल सेल (Braille 6-Dot Matrix)' : 'Braille 6-Dot Matrix'}
            </div>

            <div className="grid grid-cols-2 gap-y-5 gap-x-10 max-w-[180px] mx-auto py-2">
              {/* Dot 1 & Dot 4 */}
              <button
                type="button"
                onClick={() => toggleDot(1)}
                aria-pressed={activeDots.includes(1)}
                aria-label={lang === 'hi' ? 'बिंदु 1 (ऊपर बायां)' : 'Dot 1 (Top Left)'}
                className={`w-14 h-14 rounded-full font-bold text-xl flex items-center justify-center transition-all ${
                  activeDots.includes(1)
                    ? 'bg-amber-400 text-slate-950 scale-110 shadow-lg ring-4 ring-amber-300'
                    : 'bg-slate-800 text-slate-300 border-2 border-slate-600 hover:border-amber-400'
                }`}
              >
                1
              </button>
              <button
                type="button"
                onClick={() => toggleDot(4)}
                aria-pressed={activeDots.includes(4)}
                aria-label={lang === 'hi' ? 'बिंदु 4 (ऊपर दायां)' : 'Dot 4 (Top Right)'}
                className={`w-14 h-14 rounded-full font-bold text-xl flex items-center justify-center transition-all ${
                  activeDots.includes(4)
                    ? 'bg-amber-400 text-slate-950 scale-110 shadow-lg ring-4 ring-amber-300'
                    : 'bg-slate-800 text-slate-300 border-2 border-slate-600 hover:border-amber-400'
                }`}
              >
                4
              </button>

              {/* Dot 2 & Dot 5 */}
              <button
                type="button"
                onClick={() => toggleDot(2)}
                aria-pressed={activeDots.includes(2)}
                aria-label={lang === 'hi' ? 'बिंदु 2 (मध्य बायां)' : 'Dot 2 (Middle Left)'}
                className={`w-14 h-14 rounded-full font-bold text-xl flex items-center justify-center transition-all ${
                  activeDots.includes(2)
                    ? 'bg-amber-400 text-slate-950 scale-110 shadow-lg ring-4 ring-amber-300'
                    : 'bg-slate-800 text-slate-300 border-2 border-slate-600 hover:border-amber-400'
                }`}
              >
                2
              </button>
              <button
                type="button"
                onClick={() => toggleDot(5)}
                aria-pressed={activeDots.includes(5)}
                aria-label={lang === 'hi' ? 'बिंदु 5 (मध्य दायां)' : 'Dot 5 (Middle Right)'}
                className={`w-14 h-14 rounded-full font-bold text-xl flex items-center justify-center transition-all ${
                  activeDots.includes(5)
                    ? 'bg-amber-400 text-slate-950 scale-110 shadow-lg ring-4 ring-amber-300'
                    : 'bg-slate-800 text-slate-300 border-2 border-slate-600 hover:border-amber-400'
                }`}
              >
                5
              </button>

              {/* Dot 3 & Dot 6 */}
              <button
                type="button"
                onClick={() => toggleDot(3)}
                aria-pressed={activeDots.includes(3)}
                aria-label={lang === 'hi' ? 'बिंदु 3 (नीचे बायां)' : 'Dot 3 (Bottom Left)'}
                className={`w-14 h-14 rounded-full font-bold text-xl flex items-center justify-center transition-all ${
                  activeDots.includes(3)
                    ? 'bg-amber-400 text-slate-950 scale-110 shadow-lg ring-4 ring-amber-300'
                    : 'bg-slate-800 text-slate-300 border-2 border-slate-600 hover:border-amber-400'
                }`}
              >
                3
              </button>
              <button
                type="button"
                onClick={() => toggleDot(6)}
                aria-pressed={activeDots.includes(6)}
                aria-label={lang === 'hi' ? 'बिंदु 6 (नीचे दायां)' : 'Dot 6 (Bottom Right)'}
                className={`w-14 h-14 rounded-full font-bold text-xl flex items-center justify-center transition-all ${
                  activeDots.includes(6)
                    ? 'bg-amber-400 text-slate-950 scale-110 shadow-lg ring-4 ring-amber-300'
                    : 'bg-slate-800 text-slate-300 border-2 border-slate-600 hover:border-amber-400'
                }`}
              >
                6
              </button>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 text-center">
              <span className="text-xs text-slate-400">
                {lang === 'hi'
                  ? `सक्रिय बिंदु: ${activeDots.length > 0 ? activeDots.join(', ') : 'कोई नहीं'}`
                  : `Active Dots: ${activeDots.length > 0 ? activeDots.join(', ') : 'None'}`}
              </span>
              {activeDots.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    setActiveDots([]);
                    if (voiceEnabled) speakText(lang === 'hi' ? 'बिंदु रीसेट किए' : 'Dots reset', lang);
                  }}
                  className="block mx-auto mt-2 text-xs text-amber-400 hover:underline"
                >
                  {lang === 'hi' ? 'सभी बिंदु हटाएं' : 'Reset Dots'}
                </button>
              )}
            </div>
          </div>

          {/* Quick Bharati Braille Chart */}
          <div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-3">
              {lang === 'hi' ? 'भारती ब्रेल वर्णमाला चार्ट' : 'Bharati Braille Alphabet Reference'}
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {BHARATI_BRAILLE_LETTERS.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-black text-blue-700 dark:text-blue-300">{item.char}</span>
                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic(20);
                        setActiveDots(item.dotNums);
                        const speech = lang === 'hi'
                          ? `अक्षर ${item.char}, ${item.dots}`
                          : `Letter ${item.char}, ${item.dots}`;
                        speakText(speech, lang);
                      }}
                      aria-label={lang === 'hi' ? `${item.char} का ब्रेल कोड सुनें` : `Listen Braille for ${item.char}`}
                      className="p-1 text-slate-500 hover:text-blue-600 rounded"
                    >
                      <Volume2 className="w-4 h-4" aria-hidden="true" />
                    </button>
                  </div>
                  <div className="text-xs font-mono font-bold text-amber-600 dark:text-amber-400 mt-1">
                    {item.dots}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
