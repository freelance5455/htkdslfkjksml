import React, { useState, useEffect, useRef } from 'react';
import { DEVELOPER_INFO } from '../data/content';
import { Language } from '../types';
import { speakText, triggerHaptic } from '../utils/speech';
import { Camera, Volume2, Mail, Award, CheckCircle2, RefreshCw, Download } from 'lucide-react';

interface DeveloperCardProps {
  lang: Language;
  voiceEnabled: boolean;
  isCompact?: boolean;
}

export const DeveloperCard: React.FC<DeveloperCardProps> = ({
  lang,
  voiceEnabled,
  isCompact = false,
}) => {
  const [photoUrl, setPhotoUrl] = useState<string>(DEVELOPER_INFO.photoUrl);
  const [imgError, setImgError] = useState<boolean>(false);
  const [isPhotoChanged, setIsPhotoChanged] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load persisted photo from localStorage if user uploaded a custom one
  useEffect(() => {
    try {
      const saved = localStorage.getItem('manjeet_dev_photo');
      if (saved) {
        setPhotoUrl(saved);
        setIsPhotoChanged(true);
      }
    } catch {
      // Storage unavailable or disabled
    }
  }, []);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert(lang === 'hi' ? 'कृपया 5MB से छोटी फोटो चुनें।' : 'Please select an image smaller than 5MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          setPhotoUrl(result);
          setImgError(false);
          setIsPhotoChanged(true);
          try {
            localStorage.setItem('manjeet_dev_photo', result);
            window.dispatchEvent(new Event('manjeet_photo_updated'));
          } catch {
            // Storage quota warning
          }
          triggerHaptic(40);
          if (voiceEnabled) {
            speakText(
              lang === 'hi' ? 'प्रोफ़ाइल फोटो सफलतापूर्वक अपडेट की गई।' : 'Profile photo updated successfully.',
              lang
            );
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const resetPhoto = () => {
    setPhotoUrl(DEVELOPER_INFO.photoUrl);
    setImgError(false);
    setIsPhotoChanged(false);
    try {
      localStorage.removeItem('manjeet_dev_photo');
      window.dispatchEvent(new Event('manjeet_photo_updated'));
    } catch {
      // Ignore
    }
    triggerHaptic(30);
    if (voiceEnabled) {
      speakText(lang === 'hi' ? 'डिफ़ॉल्ट फोटो बहाल की गई।' : 'Default photo restored.', lang);
    }
  };

  const handleSpeakProfile = () => {
    triggerHaptic(25);
    const speech = lang === 'hi'
      ? `${DEVELOPER_INFO.badgeHi}। नाम: ${DEVELOPER_INFO.nameHi}। पद: ${DEVELOPER_INFO.roleHi}। संदेश: ${DEVELOPER_INFO.messageHi}`
      : `${DEVELOPER_INFO.badgeEn}. Name: ${DEVELOPER_INFO.nameEn}. Status: ${DEVELOPER_INFO.roleEn}. Message: ${DEVELOPER_INFO.messageEn}`;
    speakText(speech, lang);
  };

  return (
    <article
      aria-label={lang === 'hi' ? 'ऐप निर्माता प्रोफ़ाइल: मंजीत भारती' : 'App Developer Profile: Manjeet Bharti'}
      className="bg-white dark:bg-slate-900 border-2 border-amber-400 dark:border-amber-500 rounded-3xl p-6 sm:p-7 shadow-lg relative overflow-hidden transition-all duration-200"
    >
      {/* Top subtle decorative ribbon */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-500 via-blue-600 to-amber-500" />

      <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
        {/* Circular Profile Photo Area */}
        <div className="flex flex-col items-center shrink-0">
          <div className="relative group">
            <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full ring-4 ring-amber-400/80 dark:ring-amber-500 p-1 shadow-md bg-amber-50 dark:bg-slate-800 flex items-center justify-center overflow-hidden">
              {!imgError && photoUrl ? (
                <img
                  src={photoUrl}
                  alt={lang === 'hi' ? 'मंजीत भारती की तस्वीर (Manjeet Bharti)' : 'Manjeet Bharti portrait'}
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover object-[70%_20%] rounded-full shadow-inner"
                />
              ) : (
                /* High-fidelity default student SVG avatar */
                <svg
                  className="w-full h-full rounded-full bg-gradient-to-br from-blue-100 to-amber-100 dark:from-slate-800 dark:to-slate-700 p-2"
                  viewBox="0 0 100 100"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  role="img"
                  aria-label="Student Avatar"
                >
                  <circle cx="50" cy="50" r="48" fill="#F1F5F9" />
                  <circle cx="50" cy="38" r="18" fill="#1E3A8A" />
                  <path
                    d="M24 82C24 67.6406 35.6406 56 50 56C64.3594 56 76 67.6406 76 82"
                    fill="#1E3A8A"
                  />
                  {/* Student collar details */}
                  <path d="M42 56L50 66L58 56" fill="#FBBF24" />
                  <circle cx="50" cy="34" r="11" fill="#F8FAFC" />
                  {/* Spectacles/smart visual aid representation */}
                  <rect x="42" y="31" width="6" height="5" rx="2" stroke="#1E3A8A" strokeWidth="1.5" />
                  <rect x="52" y="31" width="6" height="5" rx="2" stroke="#1E3A8A" strokeWidth="1.5" />
                  <line x1="48" y1="33" x2="52" y2="33" stroke="#1E3A8A" strokeWidth="1.5" />
                </svg>
              )}
            </div>

            {/* Camera action overlay trigger button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              aria-label={lang === 'hi' ? 'डिवाइस से नई फोटो अपलोड करें' : 'Upload photo from device'}
              className="absolute bottom-0 right-0 bg-blue-700 hover:bg-blue-800 text-white p-2.5 rounded-full shadow-lg border-2 border-white dark:border-slate-900 focus:outline-none focus:ring-4 focus:ring-amber-400 transition-transform active:scale-95"
              title={lang === 'hi' ? 'फोटो अपलोड करें' : 'Upload Photo'}
            >
              <Camera className="w-5 h-5" aria-hidden="true" />
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handlePhotoUpload}
              accept="image/*"
              className="hidden"
              aria-hidden="true"
            />
          </div>

          {/* Upload & Reset Buttons */}
          <div className="mt-3 flex flex-wrap gap-2 justify-center">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="text-xs font-semibold px-3 py-1.5 bg-blue-50 dark:bg-slate-800 text-blue-800 dark:text-blue-300 border border-blue-300 dark:border-slate-700 rounded-lg hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-500 flex items-center gap-1.5"
            >
              <Camera className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{lang === 'hi' ? 'फोटो बदलें' : 'Change Photo'}</span>
            </button>
            {photoUrl && (
              <button
                type="button"
                onClick={resetPhoto}
                title={lang === 'hi' ? 'डिफ़ॉल्ट फोटो पर वापस आएं' : 'Reset to default avatar'}
                aria-label={lang === 'hi' ? 'डिफ़ॉल्ट फोटो पर वापस आएं' : 'Reset to default avatar'}
                className="text-xs px-2.5 py-1.5 text-slate-600 dark:text-slate-400 hover:text-red-600 border border-slate-300 dark:border-slate-700 rounded-lg"
              >
                <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            )}
          </div>
        </div>

        {/* Text Details */}
        <div className="flex-1 text-center sm:text-left">
          {/* Badge */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-100 dark:bg-amber-950/70 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700/60 rounded-full text-xs font-bold tracking-wide uppercase">
            <Award className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" aria-hidden="true" />
            <span>{lang === 'hi' ? DEVELOPER_INFO.badgeHi : DEVELOPER_INFO.badgeEn}</span>
          </div>

          {/* Name */}
          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-2 tracking-tight">
            {lang === 'hi' ? DEVELOPER_INFO.nameHi : DEVELOPER_INFO.nameEn}
          </h3>

          {/* School Status */}
          <p className="text-sm sm:text-base font-semibold text-blue-900 dark:text-blue-300 mt-1">
            {lang === 'hi' ? DEVELOPER_INFO.roleHi : DEVELOPER_INFO.roleEn}
          </p>

          {/* Dedicated Message */}
          <blockquote className="mt-3 text-sm text-slate-700 dark:text-slate-300 italic bg-amber-50/60 dark:bg-slate-800/60 p-3.5 rounded-xl border border-amber-200/70 dark:border-slate-700">
            "{lang === 'hi' ? DEVELOPER_INFO.messageHi : DEVELOPER_INFO.messageEn}"
          </blockquote>

          {/* Action Row */}
          <div className="mt-4 flex flex-wrap items-center justify-center sm:justify-start gap-3">
            {/* Listen Button */}
            <button
              type="button"
              onClick={handleSpeakProfile}
              aria-label={lang === 'hi' ? 'निर्माता परिचय आवाज़ में सुनें' : 'Listen to developer introduction'}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold rounded-xl shadow-sm focus:outline-none focus:ring-3 focus:ring-amber-400 transition-all active:scale-95"
            >
              <Volume2 className="w-4 h-4" aria-hidden="true" />
              <span>{lang === 'hi' ? 'परिचय सुनें (Audio)' : 'Listen (Audio)'}</span>
            </button>

            {/* Email Contact */}
            <a
              href={`mailto:${DEVELOPER_INFO.email}?subject=${encodeURIComponent('स्पर्श साथी ऐप - शुभकामनाएँ व प्रतिक्रिया')}`}
              aria-label={lang === 'hi' ? `मंजीत भारती को ईमेल भेजें: ${DEVELOPER_INFO.email}` : `Send email to Manjeet Bharti: ${DEVELOPER_INFO.email}`}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-sm font-semibold rounded-xl border border-slate-300 dark:border-slate-700 focus:outline-none focus:ring-3 focus:ring-amber-400 transition-all"
            >
              <Mail className="w-4 h-4 text-blue-600 dark:text-blue-400" aria-hidden="true" />
              <span>{DEVELOPER_INFO.email}</span>
            </a>

            {/* Direct Project ZIP Download Button */}
            <a
              href="/sparsh-saathi-source-code.zip"
              download="sparsh-saathi-source-code.zip"
              aria-label={lang === 'hi' ? 'संपूर्ण प्रोजेक्ट सोर्स कोड ज़िप फ़ाइल डाउनलोड करें' : 'Download Complete Project Source Code ZIP'}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold rounded-xl shadow-sm focus:outline-none focus:ring-3 focus:ring-amber-400 transition-all active:scale-95"
            >
              <Download className="w-4 h-4" aria-hidden="true" />
              <span>{lang === 'hi' ? 'प्रोजेक्ट डाउनलोड (.zip)' : 'Download Code (.zip)'}</span>
            </a>
          </div>
        </div>
      </div>
    </article>
  );
};
