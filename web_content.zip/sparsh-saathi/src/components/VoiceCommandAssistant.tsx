import React, { useState, useEffect, useRef } from 'react';
import { Language, ActiveTab } from '../types';
import { speakText, triggerHaptic, stopSpeaking } from '../utils/speech';
import { Mic, MicOff, Volume2, HelpCircle, X, Sparkles } from 'lucide-react';

export interface VoiceCommandAssistantProps {
  lang: Language;
  onTabChange: (tab: ActiveTab) => void;
  onLanguageToggle: () => void;
  voiceEnabled: boolean;
  onAnnounceStatus?: () => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export const VoiceCommandAssistant: React.FC<VoiceCommandAssistantProps> = ({
  lang,
  onTabChange,
  onLanguageToggle,
  voiceEnabled,
  onAnnounceStatus,
  isOpen: controlledIsOpen,
  onClose: controlledOnClose,
}) => {
  const [internalIsOpen, setInternalIsOpen] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [transcript, setTranscript] = useState<string>('');
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [isSupported, setIsSupported] = useState<boolean>(true);

  const recognitionRef = useRef<any>(null);

  const isModalOpen = controlledIsOpen !== undefined ? controlledIsOpen : internalIsOpen;
  const closeModal = controlledOnClose || (() => setInternalIsOpen(false));

  // Initialize Web Speech Recognition API
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = lang === 'hi' ? 'hi-IN' : 'en-IN';

        recognition.onstart = () => {
          setIsListening(true);
          setStatusMessage(lang === 'hi' ? 'सुन रहा हूँ... बोलिए' : 'Listening... please speak');
          triggerHaptic(30);
        };

        recognition.onresult = (event: any) => {
          const text = event.results[0][0].transcript;
          setTranscript(text);
          processVoiceCommand(text);
        };

        recognition.onerror = (event: any) => {
          setIsListening(false);
          const err = event.error;
          if (err === 'not-allowed') {
            setStatusMessage(lang === 'hi' ? 'माइक्रोफ़ोन अनुमति नहीं मिली।' : 'Microphone permission denied.');
          } else if (err === 'no-speech') {
            setStatusMessage(lang === 'hi' ? 'कोई आवाज़ नहीं सुनाई दी।' : 'No speech detected. Please try again.');
          } else {
            setStatusMessage(lang === 'hi' ? 'पहचान में त्रुटि। पुनः प्रयास करें।' : 'Speech error. Please retry.');
          }
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      } else {
        setIsSupported(false);
      }
    }
  }, [lang]);

  const startListening = () => {
    triggerHaptic(40);
    stopSpeaking();
    if (!recognitionRef.current) {
      // Fallback announcement
      const msg = lang === 'hi'
        ? 'आपके ब्राउज़र में वॉइस रिकॉग्निशन समर्थित नहीं है। आप सीधे बटनों का उपयोग कर सकते हैं।'
        : 'Speech recognition is not supported in this browser. Please use standard buttons.';
      setStatusMessage(msg);
      speakText(msg, lang);
      return;
    }

    try {
      recognitionRef.current.lang = lang === 'hi' ? 'hi-IN' : 'en-IN';
      recognitionRef.current.start();
    } catch {
      try {
        recognitionRef.current.stop();
        setTimeout(() => recognitionRef.current?.start(), 200);
      } catch (e) {
        console.warn('Speech recognition start error:', e);
      }
    }
  };

  const stopListening = () => {
    triggerHaptic(20);
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // Ignore
      }
    }
    setIsListening(false);
  };

  const processVoiceCommand = (rawText: string) => {
    const text = rawText.toLowerCase().trim();

    // Tab 1: About School
    if (
      text.includes('विद्यालय') ||
      text.includes('स्कूल') ||
      text.includes('प्रार्थना') ||
      text.includes('सूचना') ||
      text.includes('school') ||
      text.includes('prayer') ||
      text.includes('anthem') ||
      text.includes('notice')
    ) {
      onTabChange('about');
      const response = lang === 'hi' ? 'हमारा विद्यालय टैब खोला गया।' : 'Opened About School tab.';
      setStatusMessage(response);
      speakText(response, lang);
      return;
    }

    // Tab 2: Accessible Tools
    if (
      text.includes('टूल') ||
      text.includes('कैलकुलेटर') ||
      text.includes('गणक') ||
      text.includes('आयु') ||
      text.includes('उम्र') ||
      text.includes('बैटरी') ||
      text.includes('समय') ||
      text.includes('ब्रेल') ||
      text.includes('calculator') ||
      text.includes('tools') ||
      text.includes('age') ||
      text.includes('battery') ||
      text.includes('braille')
    ) {
      onTabChange('tools');
      const response = lang === 'hi' ? 'उपयोगी टूल्स टैब खोला गया।' : 'Opened Accessible Tools tab.';
      setStatusMessage(response);
      speakText(response, lang);
      return;
    }

    // Tab 3: Study & Rights
    if (
      text.includes('अधिकार') ||
      text.includes('संविधान') ||
      text.includes('धारा') ||
      text.includes('ज्ञान') ||
      text.includes('गोरखपुर') ||
      text.includes('लेखक') ||
      text.includes('rights') ||
      text.includes('constitution') ||
      text.includes('study') ||
      text.includes('gk') ||
      text.includes('scribe')
    ) {
      onTabChange('knowledge');
      const response = lang === 'hi' ? 'ज्ञान एवं संदर्भ टैब खोला गया।' : 'Opened Study & Rights tab.';
      setStatusMessage(response);
      speakText(response, lang);
      return;
    }

    // Language toggle command
    if (
      text.includes('अंग्रेजी') ||
      text.includes('इंग्लिश') ||
      text.includes('हिंदी') ||
      text.includes('language') ||
      text.includes('english') ||
      text.includes('hindi')
    ) {
      onLanguageToggle();
      const response = lang === 'hi' ? 'भाषा बदली गई।' : 'Language changed.';
      setStatusMessage(response);
      speakText(response, lang);
      return;
    }

    // Unrecognized command
    const fallback = lang === 'hi'
      ? `आपने कहा: "${rawText}"। कृपया "विद्यालय", "कैलकुलेटर", "अधिकार", या "भाषा" बोलें।`
      : `You said: "${rawText}". Try saying "School", "Calculator", "Rights", or "Language".`;
    setStatusMessage(fallback);
    speakText(fallback, lang);
  };

  return (
    <>
      {/* Floating Microphone Trigger for Quick Voice Navigation */}
      <button
        type="button"
        onClick={() => {
          setInternalIsOpen(true);
          triggerHaptic(30);
          setTimeout(() => startListening(), 300);
        }}
        aria-label={lang === 'hi' ? 'वॉइस कमांड सहायक खोलें' : 'Open Voice Command Assistant'}
        title={lang === 'hi' ? 'वॉइस कमांड (बोलकर चलाएं)' : 'Voice Command'}
        className="fixed bottom-20 md:bottom-6 right-4 z-40 w-14 h-14 rounded-full bg-blue-700 hover:bg-blue-800 text-white shadow-2xl flex items-center justify-center border-3 border-amber-400 focus:outline-none focus:ring-4 focus:ring-amber-300 active:scale-95 transition-all"
      >
        <Mic className="w-7 h-7" aria-hidden="true" />
      </button>

      {/* Voice Assistant Modal Overlay */}
      {isModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="voice-assistant-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200"
        >
          <div className="bg-white dark:bg-slate-900 border-2 border-amber-400 rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl relative">
            {/* Close Button */}
            <button
              type="button"
              onClick={closeModal}
              aria-label={lang === 'hi' ? 'वॉइस सहायक बंद करें' : 'Close voice assistant'}
              className="absolute top-4 right-4 p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-full bg-slate-100 dark:bg-slate-800"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center shrink-0">
                <Sparkles className="w-6 h-6" aria-hidden="true" />
              </div>
              <div>
                <h2 id="voice-assistant-title" className="text-xl font-extrabold text-slate-900 dark:text-white">
                  {lang === 'hi' ? 'वॉइस कमांड सहायक' : 'Voice Command Assistant'}
                </h2>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  {lang === 'hi' ? 'बोलकर ऐप नेविगेट करें' : 'Navigate hands-free with voice'}
                </p>
              </div>
            </div>

            {/* Mic Center Action */}
            <div className="my-6 flex flex-col items-center justify-center text-center">
              <button
                type="button"
                onClick={isListening ? stopListening : startListening}
                aria-label={
                  isListening
                    ? (lang === 'hi' ? 'माइक बंद करें' : 'Stop listening')
                    : (lang === 'hi' ? 'माइक चालू करें और बोलें' : 'Start microphone and speak')
                }
                className={`w-24 h-24 rounded-full flex items-center justify-center shadow-xl transition-all ${
                  isListening
                    ? 'bg-red-600 text-white animate-pulse ring-8 ring-red-300 dark:ring-red-900'
                    : 'bg-blue-700 text-white hover:bg-blue-800 ring-4 ring-amber-400'
                }`}
              >
                {isListening ? (
                  <MicOff className="w-10 h-10" aria-hidden="true" />
                ) : (
                  <Mic className="w-10 h-10" aria-hidden="true" />
                )}
              </button>

              <div className="mt-4 text-base font-bold text-slate-900 dark:text-white">
                {isListening
                  ? (lang === 'hi' ? '🎙️ सुन रहा हूँ... बोलिए' : '🎙️ Listening... speak now')
                  : (lang === 'hi' ? 'माइक बटन दबाकर बोलें' : 'Tap mic and speak')}
              </div>

              {transcript && (
                <div className="mt-2 text-sm italic text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-slate-800 p-2.5 rounded-xl border border-blue-200 dark:border-slate-700 w-full">
                  "{transcript}"
                </div>
              )}

              {statusMessage && (
                <div className="mt-2 text-xs font-semibold text-slate-700 dark:text-slate-300" role="status">
                  {statusMessage}
                </div>
              )}
            </div>

            {/* Quick Command Suggestions */}
            <div className="bg-slate-50 dark:bg-slate-800/80 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{lang === 'hi' ? 'मुख्य कमांड्स (Commands):' : 'Sample Voice Commands:'}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => processVoiceCommand('विद्यालय')}
                  className="p-2 text-left bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-blue-500 font-semibold text-slate-800 dark:text-slate-200"
                >
                  👉 {lang === 'hi' ? '"विद्यालय" (School)' : '"School"'}
                </button>
                <button
                  type="button"
                  onClick={() => processVoiceCommand('कैलकुलेटर')}
                  className="p-2 text-left bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-blue-500 font-semibold text-slate-800 dark:text-slate-200"
                >
                  👉 {lang === 'hi' ? '"कैलकुलेटर" (Calc)' : '"Calculator"'}
                </button>
                <button
                  type="button"
                  onClick={() => processVoiceCommand('अधिकार')}
                  className="p-2 text-left bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-blue-500 font-semibold text-slate-800 dark:text-slate-200"
                >
                  👉 {lang === 'hi' ? '"अधिकार" (Rights)' : '"Rights"'}
                </button>
                <button
                  type="button"
                  onClick={() => processVoiceCommand('भाषा')}
                  className="p-2 text-left bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-blue-500 font-semibold text-slate-800 dark:text-slate-200"
                >
                  👉 {lang === 'hi' ? '"भाषा" (Language)' : '"Language"'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default VoiceCommandAssistant;
