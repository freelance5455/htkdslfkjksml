import React from 'react';
import { Language, ThemeMode, TextSize } from '../types';
import { speakText, triggerHaptic, stopSpeaking } from '../utils/speech';
import { Languages, Volume2, VolumeX, Eye, Sun, Moon, Type, Sparkles } from 'lucide-react';

interface HeaderProps {
  lang: Language;
  onLanguageToggle: () => void;
  voiceEnabled: boolean;
  onVoiceToggle: () => void;
  themeMode: ThemeMode;
  onThemeToggle: () => void;
  textSize: TextSize;
  onTextSizeChange: (size: TextSize) => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onLanguageToggle,
  voiceEnabled,
  onVoiceToggle,
  themeMode,
  onThemeToggle,
  textSize,
  onTextSizeChange,
}) => {
  const handleLangClick = () => {
    triggerHaptic(30);
    const nextLang = lang === 'hi' ? 'en' : 'hi';
    onLanguageToggle();
    if (voiceEnabled) {
      speakText(nextLang === 'hi' ? 'भाषा बदलकर हिंदी की गई' : 'Language switched to English', nextLang);
    }
  };

  const handleVoiceClick = () => {
    triggerHaptic(30);
    const nextState = !voiceEnabled;
    onVoiceToggle();
    if (nextState) {
      speakText(lang === 'hi' ? 'आवाज़ सहायता चालू की गई' : 'Voice assistance turned on', lang);
    } else {
      stopSpeaking();
    }
  };

  const handleThemeClick = () => {
    triggerHaptic(30);
    onThemeToggle();
  };

  const cycleTextSize = () => {
    triggerHaptic(25);
    const nextSize: TextSize = textSize === 'normal' ? 'large' : textSize === 'large' ? 'extralarge' : 'normal';
    onTextSizeChange(nextSize);
    if (voiceEnabled) {
      const msg = lang === 'hi'
        ? `फॉन्ट आकार: ${nextSize === 'normal' ? 'सामान्य' : nextSize === 'large' ? 'बड़ा' : 'अति बड़ा'}`
        : `Font size: ${nextSize}`;
      speakText(msg, lang);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b-2 border-slate-200 dark:border-slate-800 shadow-sm transition-colors">
      {/* Skip to Main Content Link for screen readers */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:p-3 focus:bg-amber-400 focus:text-slate-950 focus:font-bold focus:rounded-xl focus:shadow-xl focus:outline-none"
      >
        {lang === 'hi' ? 'सीधे मुख्य सामग्री पर जाएं' : 'Skip to main content'}
      </a>

      {/* Main Bar */}
      <div className="max-w-5xl mx-auto px-4 py-2.5 sm:py-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Brand & School Title */}
          <div className="flex items-center gap-3">
            {/* School Emblem / Seal SVG */}
            <div
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-blue-700 text-amber-300 flex items-center justify-center font-black shadow-md shrink-0 border-2 border-amber-400"
              aria-hidden="true"
            >
              <span className="text-xl font-mono">⠎</span>
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl md:text-2xl font-black text-slate-900 dark:text-white tracking-tight leading-tight truncate">
                  {lang === 'hi' ? 'स्पर्श साथी | Sparsh Saathi' : 'Sparsh Saathi | स्पर्श साथी'}
                </h1>
              </div>
              <p className="text-xs sm:text-sm font-semibold text-blue-800 dark:text-blue-300 truncate">
                {lang === 'hi'
                  ? 'स्पर्श राजकीय दृष्टिबाधित इंटर कॉलेज, लालडिग्गी, गोरखपुर'
                  : 'Sparsh Govt Visually Impaired Inter College, Gorakhpur'}
              </p>
            </div>
          </div>

          {/* Quick Action Controls (Ergonomic Hitboxes >= 44px) */}
          <div className="flex items-center gap-2 self-end sm:self-center shrink-0 flex-wrap">
            {/* Language Switcher */}
            <button
              type="button"
              onClick={handleLangClick}
              aria-label={
                lang === 'hi'
                  ? 'अंग्रेजी भाषा में बदलें (Switch to English)'
                  : 'हिंदी भाषा में बदलें (Switch to Hindi)'
              }
              className="min-touch-target px-3 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
            >
              <Languages className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{lang === 'hi' ? 'English' : 'हिंदी'}</span>
            </button>

            {/* Voice Readout Toggle */}
            <button
              type="button"
              onClick={handleVoiceClick}
              aria-pressed={voiceEnabled}
              aria-label={
                voiceEnabled
                  ? (lang === 'hi' ? 'आवाज़ सहायता बंद करें' : 'Disable Voice Assistance')
                  : (lang === 'hi' ? 'आवाज़ सहायता चालू करें' : 'Enable Voice Assistance')
              }
              title={lang === 'hi' ? 'आवाज़ सहायता' : 'Voice Assistance'}
              className={`min-touch-target px-3 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 border transition-all ${
                voiceEnabled
                  ? 'bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 border-amber-400'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-700'
              }`}
            >
              {voiceEnabled ? (
                <>
                  <Volume2 className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" aria-hidden="true" />
                  <span className="hidden xs:inline">{lang === 'hi' ? 'आवाज़ चालू' : 'Voice ON'}</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span className="hidden xs:inline">{lang === 'hi' ? 'आवाज़ बंद' : 'Voice OFF'}</span>
                </>
              )}
            </button>

            {/* High Contrast / Dark Mode Toggle */}
            <button
              type="button"
              onClick={handleThemeClick}
              aria-label={
                lang === 'hi'
                  ? `थीम मोड बदलें: वर्तमान ${themeMode === 'yellow-contrast' ? 'पीला-काला उच्च कंट्रास्ट' : themeMode === 'dark' ? 'डार्क मोड' : 'सामान्य'}`
                  : `Toggle theme mode: current is ${themeMode}`
              }
              title={lang === 'hi' ? 'कंट्रास्ट / थीम बदलें' : 'Toggle Theme / High Contrast'}
              className="min-touch-target p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 flex items-center justify-center transition-all"
            >
              {themeMode === 'yellow-contrast' ? (
                <Eye className="w-4 h-4 text-amber-400" aria-hidden="true" />
              ) : themeMode === 'dark' ? (
                <Moon className="w-4 h-4" aria-hidden="true" />
              ) : (
                <Sun className="w-4 h-4 text-amber-600" aria-hidden="true" />
              )}
            </button>

            {/* Text Size Scaler */}
            <button
              type="button"
              onClick={cycleTextSize}
              aria-label={
                lang === 'hi'
                  ? `फॉन्ट का आकार बदलें: वर्तमान ${textSize === 'normal' ? 'सामान्य' : textSize === 'large' ? 'बड़ा' : 'अति बड़ा'}`
                  : `Change font size: current is ${textSize}`
              }
              title={lang === 'hi' ? 'फॉन्ट आकार (Text Size)' : 'Text Size'}
              className="min-touch-target px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 flex items-center gap-1 font-bold text-xs"
            >
              <Type className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{textSize === 'normal' ? 'A' : textSize === 'large' ? 'A+' : 'A++'}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
