import React, { useState } from 'react';
import { RPWD_RULES_DATA, CONSTITUTION_ARTICLES_DATA, GK_DATA } from '../data/content';
import { Language } from '../types';
import { speakText, triggerHaptic } from '../utils/speech';
import {
  ShieldCheck,
  Scale,
  Landmark,
  Search,
  Volume2,
  BookOpen,
  Award,
  HelpCircle,
  ExternalLink,
  PhoneCall
} from 'lucide-react';

interface StudyRightsTabProps {
  lang: Language;
  voiceEnabled: boolean;
}

export const StudyRightsTab: React.FC<StudyRightsTabProps> = ({
  lang,
  voiceEnabled,
}) => {
  const [activeSubSection, setActiveSubSection] = useState<'rpwd' | 'const' | 'gk'>('rpwd');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Speech handler for RPwD Rule
  const handleReadRpwd = (rule: typeof RPWD_RULES_DATA[0]) => {
    triggerHaptic(20);
    const title = lang === 'hi' ? rule.titleHi : rule.titleEn;
    const summary = lang === 'hi' ? rule.summaryHi : rule.summaryEn;
    const details = lang === 'hi' ? rule.detailsHi.join('. ') : rule.detailsEn.join('. ');
    speakText(`${rule.section}। ${title}। संक्षेप: ${summary}। मुख्य बिंदु: ${details}`, lang);
  };

  // Speech handler for Constitution
  const handleReadArticle = (art: typeof CONSTITUTION_ARTICLES_DATA[0]) => {
    triggerHaptic(20);
    const title = lang === 'hi' ? art.titleHi : art.titleEn;
    const prov = lang === 'hi' ? art.provisionHi : art.provisionEn;
    const imp = lang === 'hi' ? art.importanceHi : art.importanceEn;
    speakText(`${art.article}। ${title}। प्रावधान: ${prov}। महत्व: ${imp}`, lang);
  };

  // Speech handler for GK
  const handleReadGk = (gk: typeof GK_DATA[0]) => {
    triggerHaptic(20);
    const title = lang === 'hi' ? gk.titleHi : gk.titleEn;
    const fact = lang === 'hi' ? gk.factHi : gk.factEn;
    const highlight = lang === 'hi' ? gk.highlightHi : gk.highlightEn;
    speakText(`${title}। मुख्य तथ्य: ${fact}। संक्षेप: ${highlight}`, lang);
  };

  // Filter items based on search query
  const q = searchQuery.toLowerCase().trim();

  const filteredRpwd = RPWD_RULES_DATA.filter((r) => {
    if (!q) return true;
    return (
      r.titleHi.toLowerCase().includes(q) ||
      r.titleEn.toLowerCase().includes(q) ||
      r.summaryHi.toLowerCase().includes(q) ||
      r.summaryEn.toLowerCase().includes(q) ||
      r.section.toLowerCase().includes(q)
    );
  });

  const filteredConst = CONSTITUTION_ARTICLES_DATA.filter((c) => {
    if (!q) return true;
    return (
      c.titleHi.toLowerCase().includes(q) ||
      c.titleEn.toLowerCase().includes(q) ||
      c.article.toLowerCase().includes(q) ||
      c.provisionHi.toLowerCase().includes(q)
    );
  });

  const filteredGk = GK_DATA.filter((g) => {
    if (!q) return true;
    return (
      g.titleHi.toLowerCase().includes(q) ||
      g.titleEn.toLowerCase().includes(q) ||
      g.factHi.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Search Input Bar */}
      <div className="relative">
        <label htmlFor="knowledge-search" className="sr-only">
          {lang === 'hi' ? 'अधिकार, संविधान व सामान्य ज्ञान खोजें' : 'Search rights, constitution, and GK'}
        </label>
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
          <Search className="w-5 h-5" aria-hidden="true" />
        </div>
        <input
          id="knowledge-search"
          type="search"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={
            lang === 'hi'
              ? 'खोजें (उदा. लेखक, 20 मिनट, धारा 31, गोरखपुर, संविधान, आरक्षण)...'
              : 'Search rights, scribe rules, 20 mins, Section 31, Constitution...'
          }
          className="w-full min-touch-target pl-12 pr-4 py-3 rounded-2xl bg-white dark:bg-slate-900 border-2 border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 font-medium focus:outline-none focus:ring-4 focus:ring-amber-400"
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => setSearchQuery('')}
            className="absolute inset-y-0 right-0 pr-4 flex items-center text-xs font-bold text-slate-500 hover:text-red-600"
          >
            {lang === 'hi' ? 'हटाएं' : 'Clear'}
          </button>
        )}
      </div>

      {/* Sub-section Tabs */}
      <div
        role="tablist"
        aria-label={lang === 'hi' ? 'अध्ययन श्रेणियां' : 'Study Categories'}
        className="flex flex-wrap p-1.5 bg-slate-200 dark:bg-slate-800 rounded-2xl gap-1.5"
      >
        <button
          role="tab"
          type="button"
          aria-selected={activeSubSection === 'rpwd'}
          onClick={() => {
            setActiveSubSection('rpwd');
            triggerHaptic(20);
            if (voiceEnabled) speakText(lang === 'hi' ? 'दिव्यांगजन अधिकार अधिनियम खोला' : 'Opened RPwD Act 2016', lang);
          }}
          className={`flex-1 min-w-[130px] min-h-[44px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
            activeSubSection === 'rpwd'
              ? 'bg-blue-700 text-white shadow-md'
              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          <ShieldCheck className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{lang === 'hi' ? 'RPwD एक्ट 2016 (अधिकार)' : 'RPwD Act 2016'}</span>
        </button>

        <button
          role="tab"
          type="button"
          aria-selected={activeSubSection === 'const'}
          onClick={() => {
            setActiveSubSection('const');
            triggerHaptic(20);
            if (voiceEnabled) speakText(lang === 'hi' ? 'भारतीय संविधान खोला' : 'Opened Indian Constitution', lang);
          }}
          className={`flex-1 min-w-[130px] min-h-[44px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
            activeSubSection === 'const'
              ? 'bg-blue-700 text-white shadow-md'
              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          <Scale className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{lang === 'hi' ? 'भारतीय संविधान' : 'Constitution'}</span>
        </button>

        <button
          role="tab"
          type="button"
          aria-selected={activeSubSection === 'gk'}
          onClick={() => {
            setActiveSubSection('gk');
            triggerHaptic(20);
            if (voiceEnabled) speakText(lang === 'hi' ? 'सामान्य ज्ञान खोला' : 'Opened General Knowledge', lang);
          }}
          className={`flex-1 min-w-[130px] min-h-[44px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
            activeSubSection === 'gk'
              ? 'bg-blue-700 text-white shadow-md'
              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          <Landmark className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{lang === 'hi' ? 'सामान्य ज्ञान (GK)' : 'General Knowledge'}</span>
        </button>
      </div>

      {/* -------------------- SECTION 1: RPwD ACT 2016 -------------------- */}
      {activeSubSection === 'rpwd' && (
        <section
          aria-label={lang === 'hi' ? 'दिव्यांगजन अधिकार अधिनियम 2016' : 'Rights of Persons with Disabilities Act 2016'}
          className="space-y-4"
        >
          <div className="bg-blue-900 text-white p-5 rounded-2xl shadow-md border-2 border-blue-800">
            <h2 className="text-xl sm:text-2xl font-black">
              {lang === 'hi' ? 'दिव्यांगजन अधिकार अधिनियम 2016 (RPwD Act)' : 'RPwD Act 2016: Student Rights'}
            </h2>
            <p className="text-xs sm:text-sm text-blue-200 mt-1">
              {lang === 'hi'
                ? 'दृष्टिबाधित विद्यार्थियों के लिए परीक्षा, लेखक (Scribe), 20 मिनट अतिरिक्त समय और उच्च शिक्षा में अधिकार।'
                : 'Educational rights, scribe liberty, 20 min/hour extra compensatory time, and quotas for visually impaired students.'}
            </p>
          </div>

          <div className="space-y-4">
            {filteredRpwd.map((item) => (
              <article
                key={item.id}
                className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm hover:border-blue-400 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-3">
                  <div>
                    <span className="text-xs font-bold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/70 px-2.5 py-1 rounded-md border border-amber-200 dark:border-amber-800">
                      {item.section}
                    </span>
                    <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white mt-2">
                      {lang === 'hi' ? item.titleHi : item.titleEn}
                    </h3>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleReadRpwd(item)}
                    aria-label={lang === 'hi' ? `नियम सुनें: ${item.titleHi}` : `Listen rule: ${item.titleEn}`}
                    className="min-touch-target px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 self-start shrink-0 shadow-sm active:scale-95 transition-transform"
                  >
                    <Volume2 className="w-4 h-4" aria-hidden="true" />
                    <span>{lang === 'hi' ? 'सुनें' : 'Listen'}</span>
                  </button>
                </div>

                <p className="text-sm sm:text-base font-semibold text-slate-800 dark:text-slate-200 mb-3">
                  {lang === 'hi' ? item.summaryHi : item.summaryEn}
                </p>

                <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                  {(lang === 'hi' ? item.detailsHi : item.detailsEn).map((point, pIdx) => (
                    <div key={pIdx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                      <span className="text-blue-600 font-bold shrink-0">✓</span>
                      <span>{point}</span>
                    </div>
                  ))}
                </div>
              </article>
            ))}
          </div>

          {/* Grievance Help Box */}
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-700 flex items-center gap-3">
            <PhoneCall className="w-6 h-6 text-amber-700 dark:text-amber-300 shrink-0" aria-hidden="true" />
            <div className="text-xs sm:text-sm text-amber-900 dark:text-amber-200 font-medium">
              <span className="font-bold">{lang === 'hi' ? 'हेल्पलाइन सहायता: ' : 'Disability Helpline: '}</span>
              {lang === 'hi'
                ? 'अधिकारों के उल्लंघन या परीक्षा लेखक संबंधी कठिनाई पर उत्तर प्रदेश दिव्यांगजन हेल्पलाइन 1800-180-1995 पर संपर्क कर सकते हैं।'
                : 'For any issues regarding examination scribes or educational rights, call UP Disability Helpline 1800-180-1995.'}
            </div>
          </div>
        </section>
      )}

      {/* -------------------- SECTION 2: INDIAN CONSTITUTION -------------------- */}
      {activeSubSection === 'const' && (
        <section
          aria-label={lang === 'hi' ? 'भारतीय संविधान व मौलिक अधिकार' : 'Constitution of India and Fundamental Rights'}
          className="space-y-4"
        >
          <div className="bg-slate-900 text-white p-5 rounded-2xl shadow-md border-2 border-slate-800">
            <h2 className="text-xl sm:text-2xl font-black">
              {lang === 'hi' ? 'भारतीय संविधान: मौलिक अधिकार व समानता' : 'Constitution of India: Fundamental Rights'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              {lang === 'hi'
                ? 'अनुच्छेद 14, 15, 21, 21A एवं 41: समता, गरिमा और निःशुल्क शिक्षा के संवैधानिक स्तंभ।'
                : 'Key articles ensuring equality before law, life with dignity, and the fundamental right to education.'}
            </p>
          </div>

          <div className="space-y-4">
            {filteredConst.map((art) => (
              <article
                key={art.id}
                className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm hover:border-blue-400 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-3">
                  <div>
                    <span className="text-xs font-bold text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/70 px-2.5 py-1 rounded-md border border-blue-200 dark:border-blue-800">
                      {art.article}
                    </span>
                    <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white mt-2">
                      {lang === 'hi' ? art.titleHi : art.titleEn}
                    </h3>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleReadArticle(art)}
                    aria-label={lang === 'hi' ? `अनुच्छेद सुनें: ${art.titleHi}` : `Listen article: ${art.titleEn}`}
                    className="min-touch-target px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 self-start shrink-0 shadow-sm active:scale-95 transition-transform"
                  >
                    <Volume2 className="w-4 h-4" aria-hidden="true" />
                    <span>{lang === 'hi' ? 'सुनें' : 'Listen'}</span>
                  </button>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-900 dark:text-slate-100 leading-relaxed mb-3">
                  {lang === 'hi' ? art.provisionHi : art.provisionEn}
                </div>

                <div className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                  <span className="font-bold text-amber-700 dark:text-amber-400">
                    {lang === 'hi' ? 'छात्रों के लिए महत्व: ' : 'Relevance: '}
                  </span>
                  <span>{lang === 'hi' ? art.importanceHi : art.importanceEn}</span>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {/* -------------------- SECTION 3: GENERAL KNOWLEDGE (GORAKHPUR, UP & BRAILLE) -------------------- */}
      {activeSubSection === 'gk' && (
        <section
          aria-label={lang === 'hi' ? 'सामान्य ज्ञान: गोरखपुर, उत्तर प्रदेश व ब्रेल' : 'General Knowledge: Gorakhpur, UP & Braille'}
          className="space-y-4"
        >
          <div className="bg-amber-600 text-slate-950 p-5 rounded-2xl shadow-md border-2 border-amber-700">
            <h2 className="text-xl sm:text-2xl font-black">
              {lang === 'hi' ? 'सामान्य ज्ञान: गोरखपुर, उत्तर प्रदेश एवं ब्रेल' : 'General Knowledge: Gorakhpur, UP & Braille'}
            </h2>
            <p className="text-xs sm:text-sm text-amber-950 font-medium mt-1">
              {lang === 'hi'
                ? 'गीता प्रेस, रामगढ़ ताल, गोरखनाथ मंदिर, उत्तर प्रदेश के राजकीय प्रतीक और लुई ब्रेल का जीवन परिचय।'
                : 'Heritage facts of Gorakhpur, UP state symbols, and Louis Braille invention milestones.'}
            </p>
          </div>

          <div className="space-y-4">
            {filteredGk.map((item) => (
              <article
                key={item.id}
                className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm hover:border-amber-400 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-2">
                  <div>
                    <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                      {lang === 'hi' ? item.titleHi : item.titleEn}
                    </h3>
                    <div className="text-xs font-bold text-amber-600 dark:text-amber-400 mt-1">
                      {lang === 'hi' ? item.highlightHi : item.highlightEn}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleReadGk(item)}
                    aria-label={lang === 'hi' ? `तथ्य सुनें: ${item.titleHi}` : `Listen fact: ${item.titleEn}`}
                    className="min-touch-target px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 self-start shrink-0 shadow-sm active:scale-95 transition-transform"
                  >
                    <Volume2 className="w-4 h-4" aria-hidden="true" />
                    <span>{lang === 'hi' ? 'सुनें' : 'Listen'}</span>
                  </button>
                </div>

                <p className="text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                  {lang === 'hi' ? item.factHi : item.factEn}
                </p>
              </article>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
