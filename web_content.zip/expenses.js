// 10. صفحة المصروفات المستقلة
// ========================================
function expenseMatches(e) {
  const date = String(e.date || "");
  return reportMode === "daily"
    ? date === reportDate
    : date.startsWith(reportMonth);
}

function renderExpensesPage(c) {
  const list = db.expenses.slice().sort(
    (a, b) => String(b.date).localeCompare(String(a.date))
  );

  const total = list.reduce(
    (a, e) => a + (Number(e.amount) || 0), 0
  );

  c.innerHTML = `<div class="bar">
      <div>
        <h2>المصروفات</h2>
        <p class="muted">إدارة مصروفات الصالة وتحديثها.</p>
      </div>
      <button class="primary" onclick="expenseForm()">＋ إضافة مصروف</button>
    </div>

    <div class="stats">
      <div class="stat">
        <small>عدد المصروفات</small>
        <strong>${list.length}</strong>
      </div>
      <div class="stat">
        <small>إجمالي المصروفات</small>
        <strong>${cash(total)}</strong>
      </div>
    </div>

    <div class="card table">
      ${list.length ? `
        <table>
          <thead>
            <tr>
              <th>التاريخ</th>
              <th>البيان</th>
              <th>المبلغ</th>
              <th>الإجراء</th>
            </tr>
          </thead>
          <tbody>
            ${list.map(e => `
              <tr>
                <td>${esc(e.date)}</td>
                <td>${esc(e.note)}</td>
                <td>${cash(e.amount)}</td>
                <td>
                  <button onclick="expenseForm(${e.id})">تعديل</button>
                  <button class="bad" onclick="deleteExpense(${e.id})">حذف</button>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      ` : `<p class="muted">لا توجد مصروفات مسجلة حتى الآن.</p>`}
    </div>`;
}

function expenseForm(id) {
  const e = id
    ? db.expenses.find(x => x.id === id)
    : { date: localDate(), note: "", amount: "" };

  if (!e) return;

  modal(`<h3>${id ? "تعديل مصروف" : "إضافة مصروف"}</h3>
    <div class="field">
      <label for="expenseDate">تاريخ المصروف</label>
      <input id="expenseDate" type="date" value="${esc(e.date || localDate())}">
    </div>
    <div class="field">
      <label for="expenseNote">بيان المصروف</label>
      <input id="expenseNote" maxlength="120"
        value="${esc(e.note)}" placeholder="مثلاً: كهرباء أو صيانة">
    </div>
    <div class="field">
      <label for="expenseAmount">المبلغ</label>
      <input id="expenseAmount" type="number" min="0.01" step="any"
        value="${Number(e.amount) > 0 ? e.amount : ""}" placeholder="أدخل المبلغ">
    </div>
    <button class="primary" onclick="saveExpense(${id || 0})">حفظ المصروف</button>
    <button onclick="closemodal()">إلغاء</button>`);
}

function saveExpense(id = 0) {
  const date = document.getElementById("expenseDate").value;
  const note = document.getElementById("expenseNote").value.trim();
  const raw = document.getElementById("expenseAmount").value;
  const amount = Number(raw);

  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) ||
      !note || raw === "" ||
      !Number.isFinite(amount) || amount <= 0) {
    return notify("أدخل التاريخ والبيان ومبلغاً أكبر من صفر");
  }

  if (id) {
    const e = db.expenses.find(x => x.id === id);
    if (!e) return;

    e.date = date;
    e.note = note;
    e.amount = amount;
  } else {
    db.expenses.push({
      id: db.id++,
      date,
      note,
      amount,
      createdAt: Date.now()
    });
  }

  try {
    save();
    closemodal();
    render();
    notify(id ? "تم تعديل المصروف" : "تم حفظ المصروف");
  } catch (e) {
    notify("تعذّر حفظ المصروف");
  }
}

function deleteExpense(id) {
  if (!confirm("هل تريد حذف هذا المصروف؟")) return;

  db.expenses = db.expenses.filter(e => e.id !== id);
  save();
  render();
  notify("تم حذف المصروف");
}

// ========================================
