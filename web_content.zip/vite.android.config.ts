import path from "node:path";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { viteSingleFile } from "vite-plugin-singlefile";

const root = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  root: path.join(root, "android-web"),
  plugins: [tailwindcss(), react(), viteSingleFile({ useRecommendedBuildConfig: true })],
  resolve: {
    alias: { "@": path.join(root, "src") },
  },
  build: {
    outDir: path.join(root, "android/app/src/main/assets/www"),
    emptyOutDir: true,
    assetsInlineLimit: 10_000_000,
    cssCodeSplit: false,
  },
});
