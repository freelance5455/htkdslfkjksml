// ================================================================
// METALLIC FEAST — data_expansion.js
// EXPANSIÓN "NEXUS-110"
//   · 100 sectores nuevos (11 al 110) en 10 zonas
//   · 100 recetas nuevas + 25 ingredientes nuevos
//   · 50 bestias nuevas (con ventanas de aparición por sector)
//   · 120 armas nuevas con perks
//   · Laboratorio de Mejoras (29 líneas de mejoras con niveles)
//   · 30 clientes nuevos, hitos de nivel 25-50 y habilidades nuevas
//
// Se carga DESPUÉS de data.js y ANTES de game.js.
// Todo el balance vive en EXP_BAL: si algo te parece muy fácil o
// muy difícil, cambia los números de ahí (no hace falta tocar el resto).
// ================================================================

// ───────────────────────────── BALANCE ──────────────────────────────
const EXP_BAL = {
  firstSector: 11,
  lastSector: 110,

  // Multiplicadores de bestia. El Sector 10 original usa 5.0 / 3.8 / +14 / 5.5 / 5.8
  hpBase: 5.0,   hpGrowth: 1.03,      // vida de bestias
  atkBase: 3.8,  atkGrowth: 1.03,     // ataque de bestias
  defBase: 14,   defPerSector: 1.6,   // defensa extra
  xpBase: 16.5,  xpGrowth: 1.03,      // XP por baja (mucho mayor: los niveles 21+ cuestan más)
  credBase: 6.5, credGrowth: 1.03,    // créditos por baja

  // Nivel requerido = levelBase + ceil((sector-10) * levelPerSector)  → Sector 11 = Nv 20, Sector 110 = Nv 49
  levelBase: 19,
  levelPerSector: 0.3,

  // Curva de XP: hasta el nivel 20 sigue igual (x1.55); después crece más suave
  xpGrowthPre20: 1.55,
  xpGrowthPost20: 1.09,

  // Bonos al subir de nivel pasado el 20 (hasta el 20 siguen siendo +15 HP / +2 ATK / +2 DEF).
  //   ganancia = base + FIJO + CRECIENTE × (nivel - 20)
  lvlGainFlat:  { hp: 130, atk: 10,  def: 9   },   // fijo por nivel
  lvlGainExtra: { hp: 10,  atk: 1.5, def: 0.8 },   // crece con cada nivel

  // Velocidad máxima de la barra de cocina (no cambia nada hasta el nivel 20)
  cookBarSpeedCap: 5.7,

  // Precio de armas ≈ N bajas "promedio" del sector donde aparecen
  weaponPriceKills: 6
};

// ─────────────────────────── ZONAS (PÁGINAS) ─────────────────────────
// La zona 0 es el Yermo original (sectores 1-10). Cada zona nueva son 10 sectores.
const SECTOR_ZONES = [
  { id: 0,  name: 'Yermo Original',        emoji: '⚙️', from: 1,   to: 10  },
  { id: 1,  name: 'Cinturón Refinador',    emoji: '🏭', from: 11,  to: 20,  diff: 'INFERNAL',     color: '#ff4d00', dEmoji: '🔥' },
  { id: 2,  name: 'Archipiélago Tóxico',   emoji: '🌊', from: 21,  to: 30,  diff: 'APOCALÍPTICO', color: '#e6007a', dEmoji: '☣️' },
  { id: 3,  name: 'Desierto de Silicio',   emoji: '🏜️', from: 31,  to: 40,  diff: 'ABISAL',       color: '#d100d1', dEmoji: '💀' },
  { id: 4,  name: 'Ciudad Hundida',        emoji: '🐋', from: 41,  to: 50,  diff: 'TITÁNICO',     color: '#a020ff', dEmoji: '🌀' },
  { id: 5,  name: 'Órbita Baja',           emoji: '🛰️', from: 51,  to: 60,  diff: 'CÓSMICO',      color: '#7b3fff', dEmoji: '☄️' },
  { id: 6,  name: 'Selva Sintética',       emoji: '🌴', from: 61,  to: 70,  diff: 'SALVAJE',      color: '#00d68f', dEmoji: '🐅' },
  { id: 7,  name: 'Ciberespacio Roto',     emoji: '👾', from: 71,  to: 80,  diff: 'DIGITAL',      color: '#00c8ff', dEmoji: '💾' },
  { id: 8,  name: 'Infierno de Fundición', emoji: '🌋', from: 81,  to: 90,  diff: 'INFERNO',      color: '#ff2a00', dEmoji: '👹' },
  { id: 9,  name: 'Dimensiones Rotas',     emoji: '🌌', from: 91,  to: 100, diff: 'IMPOSIBLE',    color: '#ffffff', dEmoji: '⏳' },
  { id: 10, name: 'Corazón de Nexus',      emoji: '👑', from: 101, to: 110, diff: 'FIN DEL MUNDO',color: '#ffd700', dEmoji: '👑' }
];

function getZoneOfSector(sectorId) {
  return SECTOR_ZONES.find(z => sectorId >= z.from && sectorId <= z.to) || SECTOR_ZONES[0];
}

// Nivel requerido para entrar a un sector (los originales conservan Nv = sector)
function getRequiredLevelForSector(sectorId) {
  if (sectorId <= 10) return sectorId;
  return EXP_BAL.levelBase + Math.ceil((sectorId - 10) * EXP_BAL.levelPerSector);
}

// Dificultad de los sectores nuevos (11-110). Devuelve el mismo formato que
// sectorConfigs del sector 1-10 dentro de game.js.
function buildExpandedSectorDifficulty(sectorId) {
  const t = sectorId - 10;
  const zone = getZoneOfSector(sectorId);
  const r2 = v => Math.round(v * 100) / 100;
  const weights = zone.id <= 3 ? { common: 0, uncommon: 10, elite: 50, boss: 40 }
                : zone.id <= 6 ? { common: 0, uncommon: 5,  elite: 50, boss: 45 }
                :                { common: 0, uncommon: 0,  elite: 50, boss: 50 };
  return {
    hpMult:   r2(EXP_BAL.hpBase   * Math.pow(EXP_BAL.hpGrowth,   t)),
    atkMult:  r2(EXP_BAL.atkBase  * Math.pow(EXP_BAL.atkGrowth,  t)),
    defBonus: EXP_BAL.defBase + Math.round(t * EXP_BAL.defPerSector),
    xpMult:   r2(EXP_BAL.xpBase   * Math.pow(EXP_BAL.xpGrowth,   t)),
    credMult: r2(EXP_BAL.credBase * Math.pow(EXP_BAL.credGrowth, t)),
    name: zone.diff, color: zone.color, emoji: zone.dEmoji,
    tierWeights: weights
  };
}

// Bonos por subir de nivel (los niveles 1-20 no cambian)
function getLevelGains(newLevel) {
  const extra = Math.max(0, newLevel - 20);
  const flat = extra > 0 ? EXP_BAL.lvlGainFlat : { hp: 0, atk: 0, def: 0 };
  return {
    hp:  Math.round(15 + flat.hp  + EXP_BAL.lvlGainExtra.hp  * extra),
    atk: Math.round(2  + flat.atk + EXP_BAL.lvlGainExtra.atk * extra),
    def: Math.round(2  + flat.def + EXP_BAL.lvlGainExtra.def * extra)
  };
}
function getXpGrowthForLevel(newLevel) {
  return newLevel <= 20 ? EXP_BAL.xpGrowthPre20 : EXP_BAL.xpGrowthPost20;
}

// ─────────────────────── INGREDIENTES NUEVOS (25) ────────────────────
Object.assign(INGREDIENTS, {
  // Zona 1 — Cinturón Refinador
  coolant_gel:     { name: 'Gel Refrigerante',        emoji: '🧊', type: 'seasoning' },
  solder_syrup:    { name: 'Almíbar de Soldadura',    emoji: '🍯', type: 'seasoning' },
  circuit_moss:    { name: 'Musgo de Circuito',       emoji: '🌿', type: 'garnish'   },
  // Zona 2 — Archipiélago Tóxico
  rust_pepper:     { name: 'Pimienta Oxidada',        emoji: '🌶️', type: 'seasoning' },
  cobalt_ribs:     { name: 'Costillar de Cobalto',    emoji: '🦴', type: 'protein'   },
  // Zona 3 — Desierto de Silicio
  magnet_salt:     { name: 'Sal Magnética',           emoji: '🧂', type: 'seasoning' },
  data_cactus:     { name: 'Cactus de Datos',         emoji: '🌵', type: 'garnish'   },
  pulse_egg:       { name: 'Huevo de Pulso',          emoji: '🥚', type: 'special'   },
  // Zona 4 — Ciudad Hundida
  abyss_pearl:     { name: 'Perla Abisal',            emoji: '⚪', type: 'special'   },
  mercury_marrow:  { name: 'Tuétano de Mercurio',     emoji: '🧬', type: 'protein'   },
  // Zona 5 — Órbita Baja
  ion_crystal:     { name: 'Cristal Iónico',          emoji: '💎', type: 'special'   },
  hologram_leaf:   { name: 'Hoja Holográfica',        emoji: '🍃', type: 'garnish'   },
  turbine_heart:   { name: 'Corazón de Turbina',      emoji: '🫀', type: 'protein'   },
  // Zona 6 — Selva Sintética
  graphene_flake:  { name: 'Copo de Grafeno',         emoji: '🔲', type: 'garnish'   },
  acid_fruit:      { name: 'Fruta Ácida',             emoji: '🍋', type: 'special'   },
  // Zona 7 — Ciberespacio Roto
  void_ink:        { name: 'Tinta del Vacío',         emoji: '🖋️', type: 'seasoning' },
  tesla_truffle:   { name: 'Trufa Tesla',             emoji: '🍄', type: 'special'   },
  nebula_dust:     { name: 'Polvo de Nebulosa',       emoji: '🌫️', type: 'garnish'   },
  // Zona 8 — Infierno de Fundición
  ember_ash:       { name: 'Ceniza Ardiente',         emoji: '🌋', type: 'garnish'   },
  forge_core:      { name: 'Núcleo de Forja',         emoji: '♨️', type: 'special'   },
  // Zona 9 — Dimensiones Rotas
  time_crystal:    { name: 'Cristal Temporal',        emoji: '⏳', type: 'special'   },
  entropy_spice:   { name: 'Especia de Entropía',     emoji: '🌪️', type: 'seasoning' },
  cosmic_marrow:   { name: 'Tuétano Cósmico',         emoji: '🌌', type: 'protein'   },
  // Zona 10 — Corazón de Nexus
  singularity_seed:{ name: 'Semilla de Singularidad', emoji: '🌰', type: 'special'   },
  genesis_core:    { name: 'Núcleo Génesis',          emoji: '🌟', type: 'special'   }
});

// ──────────────────────── BESTIAS NUEVAS (50) ────────────────────────
// 5 por zona (1 poco común, 2 élite, 2 jefes). Cada una aparece en su zona
// y en la siguiente (ventana minSector..maxSector) para que los ingredientes
// de la zona anterior sigan siendo fáciles de conseguir.
const _EXP_TIER_BASE = {
  uncommon: z => ({ hp: 170 + 12 * z, atk: [24 + 1.5 * z, 38 + 2.5 * z], def: 10 + z,     xp:  95 + 8 * z,  credits: 125 + 10 * z }),
  elite:    z => ({ hp: 300 + 22 * z, atk: [40 + 3 * z,   60 + 4 * z],   def: 22 + 2 * z,  xp: 200 + 20 * z, credits: 250 + 22 * z }),
  boss:     z => ({ hp: 620 + 45 * z, atk: [78 + 5 * z,   118 + 7 * z],  def: 40 + 3 * z,  xp: 700 + 60 * z, credits: 800 + 65 * z })
};
const _EXP_VARIANT = {
  std:   { hp: 1,    atk: 1,    def: 1    },
  tank:  { hp: 1.25, atk: 0.85, def: 1.35 },
  glass: { hp: 0.8,  atk: 1.25, def: 0.7  },
  brute: { hp: 1.1,  atk: 1.15, def: 1    }
};
const _EXP_DROP_SLOTS = {
  normal: [ { chance: 0.90, qty: [1, 2] }, { chance: 0.70, qty: [1, 2] }, { chance: 0.50, qty: [1, 1] } ],
  boss:   [ { chance: 0.95, qty: [1, 3] }, { chance: 0.80, qty: [1, 2] }, { chance: 0.60, qty: [1, 2] } ]
};

// [id, nombre, emoji, color, tier, variante, [drops], lore]
const _EXP_BEAST_ROWS = {
  1: [
    ['valve_crab',      'Cangrejo de Válvula',        '🦀', '#c0c0c0', 'elite',    'tank',  ['coolant_gel',  'chrome_claw',   'heavy_scrap'],       'Pinzas hidráulicas y caparazón de tubería. Cierra válvulas... con tu brazo dentro.'],
    ['crude_mosquito',  'Mosquito de Crudo',          '🦟', '#3a3a3a', 'uncommon', 'glass', ['solder_syrup', 'blue_venom',    'fiber_wire'],        'Chupa petróleo sintético y lo escupe encendido. Nunca viene solo.'],
    ['boiler_boar',     'Jabalí de Caldera',          '🐗', '#ff5a1f', 'elite',    'brute', ['solder_syrup', 'red_core',      'heavy_scrap'],       'Embiste con una caldera al rojo vivo soldada al lomo.'],
    ['press_rhino',     'Rinoceronte Prensa',         '🦏', '#7a8a99', 'boss',     'tank',  ['circuit_moss', 'coolant_gel',   'titanium_scale'],    'Su cuerno es un pistón industrial capaz de aplastar contenedores enteros.'],
    ['crane_elephant',  'Elefante de Grúa',           '🐘', '#ffb300', 'boss',     'std',   ['circuit_moss', 'plasma_core',   'titanium_scale'],    'Trompa de brazo articulado y colmillos de gancho. Levanta tanques como juguetes.']
  ],
  2: [
    ['toxic_frog',      'Rana de Ácido Libre',        '🐸', '#9dff00', 'uncommon', 'glass', ['rust_pepper',  'neon_fluid',    'scale_membrane'],    'Su lengua disuelve el acero. Croa en frecuencias que hacen sangrar los visores.'],
    ['oil_caiman',      'Caimán de Desecho',          '🐊', '#4b5d2a', 'elite',    'brute', ['cobalt_ribs',  'rust_pepper',   'titanium_scale'],    'Acecha bajo manchas de petróleo con la mandíbula llena de tornillos.'],
    ['rad_seal',        'Foca Radiactiva',            '🦭', '#8cff3a', 'elite',    'tank',  ['cobalt_ribs',  'coolant_gel',   'plasma_core'],       'Brilla en la oscuridad y sus aletas emiten pulsos de neutrones.'],
    ['rig_octopus',     'Pulpo de Plataforma',        '🐙', '#ff3d7f', 'boss',     'std',   ['cobalt_ribs',  'rust_pepper',   'volt_fang'],         'Ocho tentáculos de perforación que arrancan plataformas petroleras de raíz.'],
    ['corrosive_squid', 'Calamar Corrosivo',          '🦑', '#00ffb3', 'boss',     'glass', ['rust_pepper',  'quantum_condenser', 'cobalt_ribs'],   'Lanza tinta ácida que carcome hasta el titanio templado.']
  ],
  3: [
    ['solar_camel',     'Camello Recolector',         '🐫', '#e0b060', 'uncommon', 'tank',  ['magnet_salt',  'neon_fluid',    'glass_eye'],         'Carga paneles solares en las jorobas y camina sin parar por las dunas de vidrio.'],
    ['glass_hedgehog',  'Erizo de Cristal Solar',     '🦔', '#ffe08a', 'elite',    'glass', ['data_cactus',  'magnet_salt',   'volt_fang'],         'Cada púa de silicio refracta la luz en rayos cegadores.'],
    ['sun_eagle',       'Águila Solar',               '🦅', '#ffcf40', 'elite',    'brute', ['pulse_egg',    'data_cactus',   'quantum_condenser'], 'Baja en picada desde el sol con las garras al rojo blanco.'],
    ['dune_bison',      'Bisonte de Dunas',           '🦬', '#b5651d', 'boss',     'tank',  ['magnet_salt',  'pulse_egg',     'titanium_jaw'],      'Manada de una sola bestia. Carga levantando tormentas de arena magnética.'],
    ['silicon_mammoth', 'Mamut de Silicio',           '🦣', '#c9d1d9', 'boss',     'std',   ['pulse_egg',    'data_cactus',   'titanium_jaw'],      'Colmillos de fibra óptica y una piel de circuitos congelados.']
  ],
  4: [
    ['mine_puffer',     'Pez Globo Mina',             '🐡', '#ffaa33', 'uncommon', 'glass', ['abyss_pearl',  'blue_venom',    'scale_membrane'],    'Se infla y explota. Después se reinicia y vuelve a inflarse.'],
    ['lantern_fish',    'Pez Linterna Blindado',      '🐠', '#33d6ff', 'elite',    'tank',  ['mercury_marrow','abyss_pearl',  'plasma_core'],       'Atrae presas con un faro láser antes de embestirlas con casco de acero.'],
    ['sonar_dolphin',   'Delfín Sónar',               '🐬', '#66c2ff', 'elite',    'glass', ['abyss_pearl',  'mercury_marrow','glass_eye'],         'Sus chasquidos resuenan en el casco y quiebran los cristales de tu visor.'],
    ['sonic_whale',     'Ballena Sónica',             '🐋', '#3a6ea5', 'boss',     'tank',  ['mercury_marrow','abyss_pearl',  'titanium_jaw'],      'Su canto a 190 decibeles derrumba edificios sumergidos.'],
    ['sunken_leviathan','Leviatán Hundido',           '🐳', '#1b3a5c', 'boss',     'brute', ['abyss_pearl',  'quantum_condenser','antimatter_shard'],'Dormía bajo el asfalto inundado desde antes del colapso. Ya despertó.']
  ],
  5: [
    ['live_comet',      'Cometa Vivo',                '☄️', '#ff9955', 'uncommon', 'glass', ['ion_crystal',  'plasma_core',   'neon_fluid'],        'Una roca en órbita con instinto de manada y cola de plasma.'],
    ['predator_sat',    'Satélite Depredador',        '🛰️', '#b0b8c4', 'elite',    'brute', ['ion_crystal',  'hologram_leaf', 'quantum_condenser'], 'Fue un satélite espía. Ahora caza chefs desde la órbita.'],
    ['orbit_zombie',    'Cosmonauta Reanimado',       '🧟', '#7fd67f', 'elite',    'tank',  ['hologram_leaf','turbine_heart', 'titanium_jaw'],      'Su traje sigue funcionando; quien lo habitaba, no tanto.'],
    ['stray_rocket',    'Cohete Errante',             '🚀', '#ff5544', 'boss',     'glass', ['turbine_heart','ion_crystal',  'antimatter_shard'],  'Perdió a su tripulación y ahora busca a quién lanzar. Mejor no estar en la trayectoria.'],
    ['station_ghost',   'Fantasma de la Estación',    '👻', '#e6e6ff', 'boss',     'std',   ['hologram_leaf','turbine_heart', 'ion_crystal'],       'Un módulo de mando poseído por su IA. Sella puertas y apaga el oxígeno.']
  ],
  6: [
    ['fiber_monkey',    'Mono de Fibra',              '🐒', '#c68642', 'uncommon', 'glass', ['graphene_flake','acid_fruit',  'fiber_wire'],        'Trepa por lianas de fibra óptica y lanza frutas ácidas con puntería letal.'],
    ['neon_tiger',      'Tigre de Neón',              '🐯', '#ff8a00', 'elite',    'brute', ['graphene_flake','turbine_heart','red_core'],         'Sus rayas emiten luz estroboscópica que desorienta antes del zarpazo.'],
    ['synth_orangutan', 'Orangután Sintético',        '🦧', '#e07b39', 'elite',    'tank',  ['acid_fruit',   'graphene_flake','titanium_jaw'],       'Arranca árboles de titanio y los usa como garrotes.'],
    ['saber_cyber_cat', 'Dientes de Sable Cibernético','🐅','#ffd24d', 'boss',     'glass', ['acid_fruit',   'graphene_flake','antimatter_shard'],   'Colmillos monomoleculares. Corta primero, pregunta nunca.'],
    ['emerald_dragon',  'Dragón Esmeralda',           '🐉', '#00e676', 'boss',     'std',   ['acid_fruit',   'ion_crystal',   'quantum_condenser'],   'Reina de la selva sintética. Respira esporas que incineran el aire.']
  ],
  7: [
    ['glitch_eater',    'Devorador de Glitches',      '👾', '#39ff14', 'uncommon', 'glass', ['nebula_dust',  'void_ink',      'plasma_core'],        'Un pixel que aprendió a morder. Se multiplica cada vez que lo golpeas mal.'],
    ['net_ghost',       'Fantasma de la Red',         '👻', '#b3e5ff', 'elite',    'glass', ['void_ink',      'nebula_dust',   'glass_eye'],          'Atraviesa cortafuegos y armaduras por igual. Solo teme al antivirus.'],
    ['firewall_skull',  'Cráneo de Firewall',         '💀', '#ff7043', 'elite',    'tank',  ['tesla_truffle', 'void_ink',      'titanium_jaw'],       'Guardián de un servidor olvidado. Sus ojos son puertos abiertos.'],
    ['giant_virus',     'Virus Colosal',              '🦠', '#76ff03', 'boss',     'brute', ['tesla_truffle', 'nebula_dust',   'antimatter_shard'],   'Se replica a sí mismo mientras lo golpeas. Cada copia es peor.'],
    ['intruder_alien',  'Intruso Alienígena',         '👽', '#7cff6b', 'boss',     'std',   ['tesla_truffle', 'void_ink',      'omega_cell'],         'Entró en la red por un puerto y salió por tu cocina.']
  ],
  8: [
    ['forge_lion',      'León de Fundición',          '🦁', '#ff9100', 'uncommon', 'brute', ['ember_ash',    'forge_core',    'red_core'],           'Melena de chispas y rugido de fuelle. Domina la fragua a zarpazos.'],
    ['anvil_bull',      'Toro de Forja',              '🐂', '#d84315', 'elite',    'tank',  ['ember_ash',    'forge_core',    'titanium_jaw'],       'Cada embestida suena como un martillo sobre un yunque.'],
    ['magma_buffalo',   'Búfalo de Magma',            '🐃', '#ff6d00', 'elite',    'brute', ['forge_core',   'ember_ash',     'quantum_condenser'],  'Camina sobre lava líquida sin inmutarse. Deja huellas de cristal negro.'],
    ['anvil_demon',     'Demonio de Yunque',          '😈', '#c2185b', 'boss',     'brute', ['forge_core',   'ember_ash',     'antimatter_shard'],   'Forja armas con sus propias manos... y las prueba en ti.'],
    ['lava_colossus',   'Coloso de Lava',             '🌋', '#ff3d00', 'boss',     'tank',  ['forge_core',   'ember_ash',     'omega_cell'],         'Un volcán mecánico con piernas. Su erupción cocina todo en un radio de cien metros.']
  ],
  9: [
    ['fractal_unicorn', 'Unicornio Fractal',          '🦄', '#ff80ff', 'uncommon', 'glass', ['time_crystal', 'entropy_spice', 'plasma_core'],        'Su cuerno se subdivide infinitamente. Lo que toca se desordena.'],
    ['paradox_butterfly','Mariposa de Paradoja',      '🦋', '#80d8ff', 'elite',    'glass', ['entropy_spice','time_crystal', 'omega_cell'],         'Un aleteo suyo causa que ganes la pelea... hace tres segundos. O pierdas.'],
    ['anti_time_dove',  'Paloma del Anti-Tiempo',     '🕊️', '#f5f5f5', 'elite',    'tank',  ['time_crystal', 'cosmic_marrow', 'antimatter_shard'],  'Vuela hacia atrás en el tiempo para llegar antes que tú al combate.'],
    ['time_guardian',   'Guardián del Tiempo',        '🗿', '#9e9e9e', 'boss',     'tank',  ['time_crystal', 'cosmic_marrow', 'omega_cell'],         'Una estatua que detiene los relojes. Pelear contra ella dura una eternidad.'],
    ['ghost_sauropod',  'Saurópodo Espectral',        '🦕', '#b388ff', 'boss',     'brute', ['cosmic_marrow','entropy_spice', 'omega_cell'],         'Un gigante de otra línea temporal. Cada paso deshace un pedazo del mapa.']
  ],
  10: [
    ['holo_peacock',    'Pavo Real Holográfico',      '🦚', '#00e5ff', 'uncommon', 'glass', ['genesis_core', 'entropy_spice', 'omega_cell'],         'Despliega un abanico de mil ojos que ve todos tus futuros posibles.'],
    ['glitch_swan',     'Cisne Negro Glitch',         '🦢', '#212121', 'elite',    'glass', ['singularity_seed','genesis_core','antimatter_shard'],  'Elegante, silencioso y absolutamente corrupto. Duplica su daño a cada error de la realidad.'],
    ['apoc_steed',      'Corcel Apocalíptico',        '🐴', '#5d0000', 'elite',    'brute', ['genesis_core', 'singularity_seed','omega_cell'],       'Cabalga entre sectores sin tocar el suelo. Su relincho parte cielos.'],
    ['nexus_king',      'Rey de Nexus',               '👑', '#ffd700', 'boss',     'brute', ['singularity_seed','genesis_core','omega_cell'],        'El primer chef de la ciudad, convertido en tirano metálico. Su cocina es ley.'],
    ['core_eye',        'Ojo del Núcleo',             '🧿', '#00bcd4', 'boss',     'std',   ['genesis_core', 'singularity_seed','antimatter_shard'], 'Observa desde el corazón del sistema. Lo que mira, deja de existir.']
  ]
};

(function buildExpansionBeasts() {
  Object.entries(_EXP_BEAST_ROWS).forEach(([zKey, rows]) => {
    const z = Number(zKey);
    rows.forEach(([id, name, emoji, color, tier, variant, dropIds, lore]) => {
      const b = _EXP_TIER_BASE[tier](z);
      const v = _EXP_VARIANT[variant];
      const hp = Math.round(b.hp * v.hp);
      const slots = _EXP_DROP_SLOTS[tier === 'boss' ? 'boss' : 'normal'];
      BEASTS.push({
        id, name, emoji, color,
        hp, maxHp: hp,
        attack: [Math.round(b.atk[0] * v.atk), Math.round(b.atk[1] * v.atk)],
        defense: Math.round(b.def * v.def),
        xp: b.xp, credits: b.credits,
        tier,
        minSector: 10 * z + 1,
        maxSector: Math.min(EXP_BAL.lastSector, 10 * z + 20),
        drops: dropIds.map((did, i) => ({ id: did, chance: slots[i].chance, qty: slots[i].qty })),
        lore
      });
    });
  });

  // Las bestias originales dejan de aparecer pasado cierto sector (no afecta a los sectores 1-10)
  const oldWindow = { common: 10, uncommon: 15, elite: 20, boss: 24 };
  BEASTS.forEach(b => {
    if (b.maxSector === undefined) b.maxSector = oldWindow[b.tier] || 999;
  });
})();

// ────────────────────────── RECETAS NUEVAS (100) ─────────────────────
// 10 por zona. El precio base sube ~3% por receta; las de 2 ingredientes
// valen un 20% menos. Cada receta es la "especialidad" de un sector de su zona.
// [id, nombre, emoji, [ingredientes], descripción]
const _EXP_RECIPE_ROWS = [
  // ── ZONA 1: CINTURÓN REFINADOR ──
  ['cryo_jelly',       'Gelatina Criogénica',            '🍧', ['coolant_gel', 'scale_membrane'],                    'Postre a -196 °C. Crujiente al morder, quema al tragar.'],
  ['moss_tempura',     'Tempura de Musgo de Circuito',   '🍤', ['circuit_moss', 'fiber_wire', 'heavy_scrap'],        'Rebozado electrostático con un crujido que suena a estática.'],
  ['solder_lobster',   'Langosta Soldada',               '🦞', ['chrome_claw', 'solder_syrup', 'neon_fluid'],        'Pinza de cromo bañada en almíbar metálico caramelizado.'],
  ['coolant_ceviche',  'Ceviche Refrigerante',           '🥗', ['coolant_gel', 'glass_eye', 'blue_venom'],           'Marinado en gel helado. El ojo de vidrio te mira mientras comes.'],
  ['refinery_ramen',   'Ramen de Refinería',             '🍜', ['heavy_scrap', 'circuit_moss', 'solder_syrup'],      'Caldo espeso de aceites nobles con fideos de cable pelado.'],
  ['frost_sandwich',   'Sándwich Escarchado',            '🥪', ['titanium_scale', 'coolant_gel', 'red_core'],        'Pan de grafito, carne de escama y corazón helado de núcleo rojo.'],
  ['syrup_cookies',    'Galletas de Almíbar Soldado',    '🥠', ['solder_syrup', 'titanium_scale', 'volt_fang'],      'Dulces, duras y con un ligero cosquilleo eléctrico.'],
  ['glow_dumplings',   'Dumplings Fosforescentes',       '🥟', ['circuit_moss', 'plasma_core', 'fiber_wire'],        'Brillan en la oscuridad. Los clientes los piden a oscuras.'],
  ['arctic_stew',      'Estofado Ártico',                '🥘', ['heavy_scrap', 'coolant_gel', 'neon_fluid'],         'Contundente y helado. El favorito de los obreros de turno noche.'],
  ['belt_platter',     'Parrillada del Cinturón',        '🍛', ['red_core', 'circuit_moss', 'coolant_gel'],          'Firma de la zona: fuego, hielo y un poco de musgo eléctrico.'],

  // ── ZONA 2: ARCHIPIÉLAGO TÓXICO ──
  ['toxic_calamari',   'Calamar Tóxico Frito',           '🦑', ['cobalt_ribs', 'rust_pepper', 'scale_membrane'],     'Crujiente por fuera, radiactivo por dentro. Se sirve con limón.'],
  ['rig_paella',       'Paella de Plataforma',           '🍚', ['scale_membrane', 'rust_pepper', 'neon_fluid'],      'Arroz de aceite nacarado con pimienta oxidada. Socarrat metálico.'],
  ['slick_soup',       'Sopa de Mancha de Petróleo',     '🍵', ['plasma_core', 'cobalt_ribs', 'coolant_gel'],        'Oscura, brillante y sospechosamente espesa.'],
  ['cobalt_bbq',       'Costillas BBQ de Cobalto',       '🥓', ['cobalt_ribs', 'solder_syrup', 'rust_pepper'],       'Glaseadas con almíbar de soldadura y ahumadas al sopleto.'],
  ['pepper_tacos',     'Tacos de Pimienta Oxidada',      '🌮', ['rust_pepper', 'chrome_claw', 'circuit_moss'],       'Pican tanto que se oye el óxido crepitar.'],
  ['caiman_skewers',   'Brochetas de Caimán',            '🍡', ['cobalt_ribs', 'titanium_scale', 'rust_pepper'],     'Carne de caimán de desecho, macerada tres días en salmuera ácida.'],
  ['reef_chowder',     'Crema del Arrecife',             '🥣', ['scale_membrane', 'coolant_gel', 'cobalt_ribs'],     'Sopa cremosa de escamas y cobalto. Refrescante y pesada.'],
  ['seal_hotdog',      'Hot Dog de Foca Radiactiva',     '🌭', ['cobalt_ribs', 'volt_fang', 'neon_fluid'],           'Brilla en verde. Se pide sin cebolla y sin dosímetro.'],
  ['wire_spaghetti',   'Espagueti de Cable Pimentado',   '🍝', ['fiber_wire', 'rust_pepper', 'quantum_condenser'],   'Fideos de fibra al dente con salsa de condensador.'],
  ['archipelago_feast','Festín del Archipiélago',        '🦪', ['cobalt_ribs', 'titanium_scale', 'quantum_condenser'], 'Ostras de plataforma, escamas de titanio y cuánticos al horno.'],

  // ── ZONA 3: DESIERTO DE SILICIO ──
  ['salt_wrap',        'Wrap de Sal Magnética',          '🥙', ['magnet_salt', 'cobalt_ribs', 'titanium_scale'],     'Las especias se orientan solas hacia el norte del paladar.'],
  ['cactus_salad',     'Ensalada de Cactus de Datos',    '🥬', ['data_cactus', 'neon_fluid', 'scale_membrane'],      'Refrescante y con 4 gigas de sabor por bocado.'],
  ['pulse_omelette',   'Tortilla de Pulso',              '🍳', ['pulse_egg', 'magnet_salt', 'neon_fluid'],           'Late en el plato. Cuanto más fresca, más late.'],
  ['dune_burrito',     'Burrito de Dunas',               '🌯', ['titanium_jaw', 'data_cactus', 'magnet_salt'],       'Envuelto en tortilla solar. Se come rápido antes de que se derrita.'],
  ['sand_fries',       'Papas de Silicio',               '🍟', ['data_cactus', 'volt_fang', 'magnet_salt'],          'Crujientes como cristal molido. Con dip de voltios.'],
  ['pulse_flan',       'Flan de Huevo de Pulso',         '🍮', ['pulse_egg', 'magnet_salt', 'glass_eye'],          'Tiembla con cada latido. Caramelo de sal magnética por encima.'],
  ['solar_falafel',    'Falafel Solar',                  '🧆', ['titanium_jaw', 'pulse_egg', 'rust_pepper'],         'Bolitas doradas al foco de un espejo gigante.'],
  ['mirage_pie',       'Tarta Espejismo',                '🥧', ['pulse_egg', 'glass_eye', 'data_cactus'],            'Nunca sabes si lo estás comiendo... hasta que desaparece.'],
  ['caravan_box',      'Cajita de la Caravana',          '🥡', ['volt_fang', 'quantum_condenser', 'magnet_salt'],    'Comida de viaje. Sobrevive tormentas de arena y tormentas de clientes.'],
  ['silicon_cake',     'Banquete de Silicio',            '🍰', ['pulse_egg', 'titanium_jaw', 'quantum_condenser'],   'Pastel de tres pisos con glaseado de cuarzo comestible.'],

  // ── ZONA 4: CIUDAD HUNDIDA ──
  ['pearl_cake',       'Pastelito de Perla Abisal',      '🍥', ['abyss_pearl', 'scale_membrane'],                    'Pequeño, nacarado, y con un fondo de mar profundo.'],
  ['mercury_nigiri',   'Nigiri de Mercurio',             '🍙', ['mercury_marrow', 'glass_eye', 'scale_membrane'],    'Se derrite sobre la lengua y deja regusto plateado.'],
  ['pearl_cocktail',   'Cóctel de Perla',                '🍸', ['abyss_pearl', 'magnet_salt', 'neon_fluid'],         'Una perla en el fondo. No te la tragues (o sí).'],
  ['whale_carpaccio',  'Carpaccio de Ballena Sónica',    '🥮', ['mercury_marrow', 'abyss_pearl', 'titanium_jaw'],    'Láminas finísimas que vibran al cortarlas.'],
  ['brine_can',        'Conserva de Salmuera Profunda',  '🥫', ['data_cactus', 'abyss_pearl', 'scale_membrane'],     'Sabor de siglos bajo el agua. Aguanta cualquier apocalipsis.'],
  ['mercury_fondue',   'Fondue de Mercurio',             '🧀', ['mercury_marrow', 'plasma_core', 'blue_venom'],      'Se moja en cobre líquido. Pinchos de titanio incluidos.'],
  ['leviathan_fillet', 'Filete de Leviatán',             '🍴', ['titanium_jaw', 'mercury_marrow', 'quantum_condenser'], 'Un solo corte alimenta a un sector entero.'],
  ['puffer_popcorn',   'Palomitas de Pez Globo',         '🍿', ['abyss_pearl', 'pulse_egg', 'scale_membrane'],       'Explotan en la boca. Literalmente.'],
  ['sonar_sashimi',    'Sashimi Sónar',                  '🍹', ['glass_eye', 'abyss_pearl', 'blue_venom'],           'Se sirve con eco. Pídelo con vistas al abismo.'],
  ['sunken_banquet',   'Banquete Sumergido',             '🍾', ['mercury_marrow', 'antimatter_shard', 'abyss_pearl'],'Descorchado a 400 metros bajo el asfalto.'],

  // ── ZONA 5: ÓRBITA BAJA ──
  ['comet_candy',      'Caramelo de Cometa',             '🍬', ['ion_crystal', 'neon_fluid'],                        'Cristaliza en la lengua y deja una estela de plasma.'],
  ['orbital_tartare',  'Tartar Orbital',                 '🥒', ['turbine_heart', 'hologram_leaf', 'glass_eye'],      'Picado en gravedad cero para que no se caiga ni un cubito.'],
  ['zerog_souffle',    'Suflé de Gravedad Cero',         '🧁', ['ion_crystal', 'hologram_leaf', 'scale_membrane'],   'Crece hasta el techo y ahí se queda flotando.'],
  ['astro_bun',        'Bollo de Astronauta',            '🥯', ['turbine_heart', 'titanium_jaw', 'hologram_leaf'],   'Relleno de proteína liofilizada de turbina. Nutritivo y algo ruidoso.'],
  ['satellite_dimsum', 'Dim Sum Satelital',              '🍘', ['hologram_leaf', 'quantum_condenser', 'plasma_core'],'Cada dumpling emite una señal. Cada bocado, una respuesta.'],
  ['rocket_ribs',      'Costillas Cohete',               '🧇', ['turbine_heart', 'ion_crystal', 'blue_venom'],       'Salen disparadas de la parrilla directo al plato.'],
  ['ion_sorbet',       'Sorbete Iónico',                 '🍨', ['ion_crystal', 'abyss_pearl', 'neon_fluid'],         'Helado que se carga solo. Cuidado con la estática.'],
  ['ghost_ramen',      'Ramen Fantasma',                 '🥖', ['hologram_leaf', 'mercury_marrow', 'quantum_condenser'], 'Traslúcido. Los fideos atraviesan el tazón.'],
  ['station_pancakes', 'Panqueques de la Estación',      '🥞', ['turbine_heart', 'mercury_marrow', 'plasma_core'],   'Esponjosos, densos y con vistas a la Tierra.'],
  ['orbit_cake',       'Festín Orbital',                 '🎂', ['turbine_heart', 'ion_crystal', 'antimatter_shard'], 'Tarta de tres capas que gira sola alrededor del plato.'],

  // ── ZONA 6: SELVA SINTÉTICA ──
  ['jungle_ceviche',   'Ceviche Selvático',              '🥑', ['acid_fruit', 'hologram_leaf', 'neon_fluid'],        'Fruta ácida, hojas holográficas y un toque de neón.'],
  ['graphene_chips',   'Chips de Grafeno',               '🍠', ['graphene_flake', 'fiber_wire', 'red_core'],         'Finísimos, resistentes y conducen bien la sal.'],
  ['tiger_curry',      'Curry del Tigre',                '🥕', ['turbine_heart', 'acid_fruit', 'red_core'],          'Rugiente y llameante. Deja el paladar en modo estroboscópico.'],
  ['vine_rolls',       'Rollitos de Liana',              '🌽', ['fiber_wire', 'hologram_leaf', 'acid_fruit'],        'Enrollados con lianas de fibra óptica. Se comen enteros.'],
  ['orangutan_ribs',   'Costillas del Orangután',        '🍇', ['titanium_jaw', 'graphene_flake', 'acid_fruit'],     'Glaseadas con jugo de fruta ácida y grafeno tostado.'],
  ['dragon_wok',       'Wok del Dragón Esmeralda',       '🍍', ['acid_fruit', 'ion_crystal', 'quantum_condenser'],   'Salteado a 900 grados. El humo huele a jade.'],
  ['monkey_skewers',   'Brochetas del Mono',             '🥥', ['fiber_wire', 'graphene_flake'],                     'Rápidas, ligeras y siempre demasiado pocas.'],
  ['spore_soup',       'Sopa de Esporas',                '🥦', ['hologram_leaf', 'graphene_flake', 'neon_fluid'],    'Espesa, verde y algo consciente.'],
  ['saber_steak',      'Bistec de Dientes de Sable',     '🍒', ['antimatter_shard', 'acid_fruit', 'graphene_flake'], 'Se corta con el propio colmillo. Jugoso hasta el hueso.'],
  ['jungle_banquet',   'Banquete Sintético',             '🍓', ['turbine_heart', 'graphene_flake', 'ion_crystal'],   'Toda la selva en un solo plato. Aún se mueve un poco.'],

  // ── ZONA 7: CIBERESPACIO ROTO ──
  ['glitch_nachos',    'Nachos Glitcheados',             '🧃', ['nebula_dust', 'void_ink', 'fiber_wire'],            'Cada chip tiene un sabor distinto. A veces el mismo dos veces.'],
  ['ink_pasta',        'Pasta de Tinta del Vacío',       '🥤', ['void_ink', 'tesla_truffle', 'quantum_condenser'],   'Negra como un agujero de memoria. Deja los dientes cuánticos.'],
  ['truffle_risotto',  'Risotto de Trufa Tesla',         '🧉', ['tesla_truffle', 'glass_eye', 'acid_fruit'],         'Cremoso, con chispas. Lo remueves con un pararrayos.'],
  ['nebula_meringue',  'Merengue de Nebulosa',           '🍭', ['nebula_dust', 'graphene_flake', 'plasma_core'],     'Ligero como un pixel y dulce como un reinicio.'],
  ['firewall_grill',   'Parrilla Cortafuegos',           '🔥', ['titanium_jaw', 'void_ink', 'red_core'],             'Carne sellada a prueba de intrusos. Punto: encriptado.'],
  ['packet_sushi',     'Sushi de Paquetes',              '🥢', ['glass_eye', 'void_ink', 'nebula_dust'],             'Cada pieza llega en orden... casi siempre.'],
  ['virus_bites',      'Bocados de Virus',               '🍩', ['tesla_truffle', 'antimatter_shard', 'nebula_dust'], 'Adictivos y contagiosos. Se replican en el plato.'],
  ['ghost_broth',      'Caldo Fantasma',                 '🍶', ['void_ink', 'turbine_heart', 'tesla_truffle'],       'Un caldo que estaba aquí hace un momento.'],
  ['byte_tart',        'Tarta de Bytes',                 '🍪', ['nebula_dust', 'tesla_truffle', 'ion_crystal'],      'Ocho bocados exactos. Sin bugs (hasta el último).'],
  ['cyber_omakase',    'Omakase del Ciberespacio',       '🍽️', ['tesla_truffle', 'omega_cell', 'void_ink'],          'El chef decide. El servidor también.'],

  // ── ZONA 8: INFIERNO DE FUNDICIÓN ──
  ['ember_wings',      'Alitas Ígneas',                  '🍫', ['ember_ash', 'forge_core', 'red_core'],              'Rebozadas en ceniza viva. Hay que comerlas con guantes.'],
  ['forge_steak',      'Bistec de Fragua',               '🍯', ['titanium_jaw', 'forge_core', 'ember_ash'],          'Forjado a martillazos. Se corta con soplete.'],
  ['magma_fondue',     'Fondue de Magma',                '🥜', ['forge_core', 'tesla_truffle', 'quantum_condenser'], 'Se moja con varillas de tungsteno. Ni te asomes.'],
  ['anvil_ribs',       'Costillas de Yunque',            '🌰', ['titanium_jaw', 'ember_ash', 'red_core'],            'Tan duras que se sirven con martillo.'],
  ['lava_cake',        'Volcán de Chocolate Líquido',    '🍦', ['forge_core', 'ember_ash', 'void_ink'],              'Al abrirlo, lava de verdad. Hay que salir corriendo con la cuchara.'],
  ['smoke_brisket',    'Brisket Ahumado de Fundición',   '🥨', ['titanium_jaw', 'ember_ash', 'tesla_truffle'],       'Doce horas sobre carbón de fragua. Perfecto.'],
  ['forge_ramen',      'Ramen de Fundición',             '🍞', ['forge_core', 'nebula_dust', 'glass_eye'],           'El caldo hierve sin fuego. Los fideos, de acero fundido.'],
  ['lion_paella',      'Paella del León',                '🧄', ['ember_ash', 'plasma_core', 'glass_eye'],            'Rugiente, dorada y con socarrat de brasa.'],
  ['inferno_curry',    'Curry Inferno',                  '🧅', ['forge_core', 'red_core', 'void_ink'],               'Solo apto para paladares blindados. Exige seguro de vida.'],
  ['magma_banquet',    'Banquete de Magma',              '🍉', ['forge_core', 'omega_cell', 'antimatter_shard'],     'Tres platos: incandescente, fundido y volcánico.'],

  // ── ZONA 9: DIMENSIONES ROTAS ──
  ['time_tacos',       'Tacos Temporales',               '🍊', ['time_crystal', 'entropy_spice', 'plasma_core'],     'Se comen antes de prepararse. Sabores de mañana.'],
  ['paradox_pancakes', 'Panqueques de Paradoja',         '🍋', ['time_crystal', 'forge_core', 'entropy_spice'],      'Se voltean solos y a veces aterrizan ayer.'],
  ['fractal_pizza',    'Pizza Fractal',                  '🍕', ['entropy_spice', 'quantum_condenser', 'red_core'],   'Cada porción contiene una pizza más pequeña. Y otra. Y otra.'],
  ['antitime_soup',    'Sopa Anti-Tiempo',               '🍌', ['time_crystal', 'cosmic_marrow', 'plasma_core'],     'Se enfría al hervir y hierve al enfriarse.'],
  ['sauropod_roast',   'Asado de Saurópodo',             '🍑', ['cosmic_marrow', 'titanium_jaw', 'ember_ash'],       'Para cuarenta comensales... de cuarenta líneas temporales.'],
  ['guardian_pot',     'Olla del Guardián',              '🍐', ['cosmic_marrow', 'time_crystal', 'omega_cell'],      'Cocción eterna: tarda un instante y una eternidad.'],
  ['chaos_cocktail',   'Cóctel del Caos',                '🍏', ['entropy_spice', 'forge_core', 'cosmic_marrow'],      'Cada trago sabe distinto. Ninguno es seguro.'],
  ['unicorn_cake',     'Pastel de Unicornio',            '🍎', ['entropy_spice', 'antimatter_shard'],                'Arcoíris hexagonal. Sabor: probabilístico.'],
  ['marrow_bao',       'Bao de Tuétano Cósmico',         '🥭', ['cosmic_marrow', 'quantum_condenser', 'entropy_spice'], 'Esponjoso, denso y con un agujero negro en el centro.'],
  ['eternal_banquet',  'Banquete Eterno',                '🍈', ['cosmic_marrow', 'omega_cell', 'antimatter_shard'],  'No se acaba nunca. Tampoco se enfría. Tampoco se olvida.'],

  // ── ZONA 10: CORAZÓN DE NEXUS ──
  ['genesis_soup',     'Sopa Génesis',                   '🥝', ['genesis_core', 'entropy_spice', 'plasma_core'],     'La receta más antigua de Nexus-7: cocinar el universo desde cero.'],
  ['seed_dumplings',   'Dumplings de Semilla',           '🍅', ['singularity_seed', 'cosmic_marrow', 'entropy_spice'], 'Dentro de cada uno late un universo diminuto.'],
  ['peacock_platter',  'Bandeja del Pavo Real',          '🍆', ['genesis_core', 'omega_cell', 'time_crystal'],       'Mil ojos de sabor en un solo plato. Todos te juzgan.'],
  ['swan_confit',      'Confit de Cisne Negro',          '🥔', ['singularity_seed', 'antimatter_shard', 'entropy_spice'], 'Lento, elegante y ligeramente corrupto.'],
  ['steed_steak',      'Bistec del Corcel',              '🥐', ['genesis_core', 'cosmic_marrow', 'omega_cell'],      'Un bistec que sigue galopando por el plato.'],
  ['king_roast',       'Asado del Rey',                  '🫓', ['singularity_seed', 'omega_cell', 'cosmic_marrow'],  'Servido con corona de hueso. Solo para cabezas coronadas.'],
  ['eye_carpaccio',    'Carpaccio del Ojo',              '🥚', ['genesis_core', 'singularity_seed', 'plasma_core'],  'Cortado a una molécula de grosor. El ojo sigue viendo.'],
  ['nexus_nectar',     'Néctar de Nexus',                '🧋', ['genesis_core', 'time_crystal', 'entropy_spice'],    'Bebida sagrada. Cada gota vale una ciudad.'],
  ['omega_tasting',    'Menú Degustación Omega',         '🥂', ['omega_cell', 'antimatter_shard', 'genesis_core'],   'Nueve tiempos para nueve dimensiones. Solo un comensal sobrevive al postre.'],
  ['heart_of_nexus',   'Corazón de Nexus',               '❤️', ['singularity_seed', 'genesis_core', 'omega_cell'],   'El plato final. Late, brilla y te devuelve la mirada.']
];

(function buildExpansionRecipes() {
  _EXP_RECIPE_ROWS.forEach(([id, name, emoji, ingredients, description], k) => {
    let price = 1500 * Math.pow(1.03, k);
    if (ingredients.length === 2) price *= 0.8;
    RECIPES.push({
      id, name, emoji, ingredients,
      basePrice: Math.round(price / 10) * 10,
      description,
      tier: Math.floor(k / 10) + 1   // zona 1-10
    });
  });
})();

// ───────────────────── ECONOMÍA: CRÉDITOS POR BAJA ───────────────────
// Créditos promedio por bestia en un sector (sirve para fijar precios)
function expectedKillCredits(sectorId) {
  const s = Math.max(10, sectorId);
  const diff = buildExpandedSectorDifficulty(s <= 10 ? 11 : s);
  const z = Math.max(0, getZoneOfSector(s).id);
  const w = s <= 10 ? { uncommon: 10, elite: 50, boss: 40 } : diff.tierWeights;
  const credMult = s <= 10 ? 5.8 : diff.credMult;
  const total = (w.uncommon || 0) + w.elite + w.boss;
  const c = t => _EXP_TIER_BASE[t](z).credits * credMult;
  return ((w.uncommon || 0) * c('uncommon') + w.elite * c('elite') + w.boss * c('boss')) / total;
}

// ───────────────────────── PERKS DE ARMAS ────────────────────────────
// Las armas nuevas dan Ataque + 1 perk. El valor sube a lo largo del catálogo.
const WEAPON_PERK_INFO = {
  crit:      { label: '🎯 Prob. crítico',          min: 0.03,  max: 0.14 },
  critdmg:   { label: '💢 Daño crítico',           min: 0.10,  max: 0.55 },
  pierce:    { label: '📌 Ignora defensa enemiga', min: 0.05,  max: 0.30 },
  lifesteal: { label: '🩸 Robo de vida',           min: 0.01,  max: 0.06 },
  double:    { label: '⚡ Golpe doble',            min: 0.02,  max: 0.12 },
  special:   { label: '💥 Daño del especial',      min: 0.10,  max: 0.70 },
  exec:      { label: '☠️ Daño a enemigos <30% HP',min: 0.05,  max: 0.40 },
  thorns:    { label: '🌵 Daño reflejado',         min: 0.03,  max: 0.25 },
  dodge:     { label: '💨 Esquiva',                min: 0.02,  max: 0.12 },
  regen:     { label: '💚 Regeneración/turno',     min: 0.003, max: 0.02 },
  reduce:    { label: '🛡️ Reducción de daño',      min: 0.02,  max: 0.10 }
};

function getWeaponPerkText(w) {
  if (!w || !w.perk) return '';
  const info = WEAPON_PERK_INFO[w.perk.type];
  if (!info) return '';
  return `${info.label}: +${(w.perk.value * 100).toFixed(w.perk.value < 0.05 ? 1 : 0)}%`;
}

// [id, nombre, emoji, familia(perk), descripción]
const _EXP_WEAPON_ROWS = [
  // ── ZONA 1: CINTURÓN REFINADOR ──
  ['refinery_cleaver', 'Cuchilla de Refinería',       '🔪', 'crit',      'Hoja de acero templado en aceite de cracking. Corta más que la envidia.'],
  ['cryo_machete',     'Machete Criogénico',          '🗡️', 'pierce',    'Congela el filo a -200 °C: el blindaje se vuelve quebradizo.'],
  ['welder_axe',       'Hacha de Soldador',           '🪓', 'critdmg',   'Un arco de soldadura recorre la hoja y funde cada golpe certero.'],
  ['valve_maul',       'Mazo de Válvula',             '🔨', 'pierce',    'Una válvula de 30 kilos en un mango de tubería. Sin sutilezas.'],
  ['coolant_saber',    'Sable de Coolant',            '⚔️', 'crit',      'Filo hueco relleno de gel refrigerante. Cada tajo deja escarcha.'],
  ['pipe_lance',       'Lanza de Tubería',            '🔱', 'pierce',    'Punta de perforación. Atraviesa placas como si fueran papel.'],
  ['hydraulic_shears', 'Cizalla Hidráulica',          '✂️', 'exec',      'Presión de 400 bar. Perfecta para rematar lo que ya está roto.'],
  ['probe_pick',       'Pica de Sondeo',              '⛏️', 'pierce',    'Diseñada para taladrar roca; la carne metálica no es tan distinta.'],
  ['cable_whip',       'Látigo de Cable de Alta',     '⛓️', 'double',    'Cable de alta tensión pelado. Restalla dos veces por chasquido.'],
  ['steam_scythe',     'Guadaña de Vapor',            '🌾', 'lifesteal', 'Sopla vapor caliente al cortar y recicla la energía en tus baterías.'],
  ['slag_katana',      'Katana de Escoria',           '🗡️', 'critdmg',   'Forjada con residuos de fundición. Fea, desigual y letal.'],
  ['flange_breaker',   'Rompebridas',                 '🔧', 'special',   'Llave gigante cargada con presión. Su golpe especial revienta bridas y bestias.'],

  // ── ZONA 2: ARCHIPIÉLAGO TÓXICO ──
  ['toxic_harpoon',    'Arpón Tóxico',                '🎣', 'pierce',    'Arpón con cable de recuperación y punta impregnada de ácido de rana.'],
  ['rig_hook',         'Garfio de Plataforma',        '🪝', 'double',    'Gancho de grúa naval. Engancha una vez y desgarra otra al soltar.'],
  ['tide_cutlass',     'Alfanje de Marea',            '🗡️', 'crit',      'Curva como una ola y con el mismo instinto de marea alta.'],
  ['oil_trident',      'Tridente de Petróleo',        '🔱', 'lifesteal', 'Sus púas succionan crudo sintético y lo convierten en combustible vital.'],
  ['anchor_mace',      'Maza de Ancla',               '⚓', 'exec',      'Un ancla de 80 kilos en cadena. Lo que aún se mueve, deja de hacerlo.'],
  ['squid_whip',       'Látigo de Calamar',           '🪢', 'double',    'Trenzado con tentáculos sintéticos que se mueven por su cuenta.'],
  ['coral_blade',      'Hoja de Coral',               '🐚', 'crit',      'Coral rígido y afilado como vidrio. Sangra más de lo que corta.'],
  ['acid_sprayer',     'Rociador Ácido',              '🧪', 'special',   'Lanzallamas de ácido. Con el especial, cada gota multiplica el daño.'],
  ['barnacle_hammer',  'Martillo de Percebes',        '🔨', 'critdmg',   'Costras de percebes acerados en la cabeza. Aumentan el daño en cada impacto crítico.'],
  ['wreck_saw',        'Sierra de Naufragio',         '🪚', 'exec',      'Recuperada de un barco hundido. Se especializa en terminar trabajos.'],
  ['kelp_lash',        'Fusta de Alga',               '🌿', 'regen',     'Alga sintética que te cura cada turno gracias a su fotosíntesis nocturna.'],
  ['buoy_shield',      'Boya Reactiva',               '🛡️', 'reduce',    'Boya blindada que amortigua parte del daño y flota sobre el resto.'],

  // ── ZONA 3: DESIERTO DE SILICIO ──
  ['dune_scimitar',    'Cimitarra de Dunas',          '🌙', 'crit',      'Curva pulida por el viento de silicio. Se vuelve más afilada con cada tormenta.'],
  ['glass_spear',      'Lanza de Cristal Solar',      '🔱', 'pierce',    'Concentra la luz del sol en la punta y funde el blindaje al contacto.'],
  ['mirage_dagger',    'Daga Espejismo',              '🔪', 'double',    'Tu enemigo nunca sabe cuál de las dos es la real. Tú tampoco.'],
  ['sand_whip',        'Látigo de Arena',             '⛓️', 'critdmg',   'Cuero de dunas sinterizadas. El golpe crítico se siente como una tormenta.'],
  ['solar_lance',      'Lanza Solar',                 '🌞', 'special',   'Almacena luz del día y la libera en un especial cegador.'],
  ['cactus_club',      'Garrote de Cactus',           '🌵', 'thorns',    'Espinas de datos que se clavan en quien te golpea.'],
  ['magnet_hammer',    'Martillo Magnético',          '🧲', 'pierce',    'Atrae el blindaje hacia el golpe y lo desgarra desde dentro.'],
  ['caravan_blade',    'Hoja de Caravana',            '🗡️', 'lifesteal', 'Herencia de mil viajes. Roba un poco de vida al vencedor.'],
  ['heliograph_gun',   'Heliógrafo Láser',            '🔫', 'special',   'Pistola de señales que emite ráfagas láser cuando lo necesitas de verdad.'],
  ['silicon_axe',      'Hacha de Silicio',            '🪓', 'crit',      'Hoja de vidrio de dunas. Pura precisión con un toque de suerte.'],
  ['storm_flail',      'Mangual de Tormenta',         '⚡', 'double',    'Dos bolas con carga eléctrica opuesta. Golpean casi al mismo tiempo.'],
  ['oasis_staff',      'Bastón del Oasis',            '🪄', 'regen',     'Una gota de agua limpia brota de la punta cada turno y sana tus heridas.'],

  // ── ZONA 4: CIUDAD HUNDIDA ──
  ['depth_charge',     'Carga de Profundidad',        '💣', 'special',   'No es exactamente un arma... pero funciona muy bien como especial.'],
  ['abyss_trident',    'Tridente Abisal',             '🔱', 'lifesteal', 'Bebe la presión de las profundidades y te devuelve una parte.'],
  ['sonar_blade',      'Hoja Sónar',                  '🗡️', 'crit',      'Pings de sonar que marcan los puntos débiles del enemigo.'],
  ['pearl_katana',     'Katana de Perla',             '⚔️', 'critdmg',   'Filo nacarado. Cada crítico resuena como una campana de catedral.'],
  ['harpoon_gun',      'Fusil Arpón',                 '🔫', 'pierce',    'Dispara un arpón supersónico que perfora hasta placas de casco naval.'],
  ['sunken_anchor',    'Martillo del Ancla Hundida',  '⚓', 'exec',      'Pesa el doble por el agua acumulada. Remata con gravedad extra.'],
  ['mercury_whip',     'Látigo de Mercurio',          '⛓️', 'double',    'Eslabones de mercurio líquido que chasquean y regresan como un espejo.'],
  ['tide_scythe',      'Guadaña de Marea',            '🌾', 'lifesteal', 'Sube y baja con tu pulso; cada vaivén repone algo de vida.'],
  ['pressure_pick',    'Pico de Presión',             '⛏️', 'pierce',    'Concentra 1000 atmósferas en la punta. Nada aguanta eso.'],
  ['coral_staff',      'Bastón de Coral Vivo',        '🪄', 'regen',     'El coral crece con tu sangre y te devuelve un poco cada turno.'],
  ['whalebone_club',   'Garrote de Hueso de Ballena', '🦴', 'thorns',    'Su resonancia devuelve parte del daño recibido como onda sonora.'],
  ['flooded_shield',   'Escudo Anegado',              '🛡️', 'reduce',    'Cuanta más agua acumula, más golpes absorbe.'],

  // ── ZONA 5: ÓRBITA BAJA ──
  ['ion_saber',        'Sable Iónico',                '⚔️', 'crit',      'Un chorro de iones estabilizado. Perfecto para cortes limpios.'],
  ['orbital_lance',    'Lanza Orbital',               '🔱', 'pierce',    'Diseñada para caer desde la órbita. Tú solo la sostienes.'],
  ['zerog_hammer',     'Martillo de Gravedad Cero',   '🔨', 'critdmg',   'No pesa nada... hasta que golpea. Entonces pesa lo suficiente.'],
  ['satellite_blade',  'Hoja Satelital',              '🛰️', 'special',   'Se sincroniza con satélites y descarga un especial guiado.'],
  ['comet_axe',        'Hacha Cometa',                '☄️', 'exec',      'Estela ardiente sobre la hoja. Pensada para rematar presas en fuga.'],
  ['station_wrench',   'Llave de Estación',           '🔧', 'double',    'Herramienta de mantenimiento espacial. Golpea dos veces si aprietas bien.'],
  ['orbit_pistol',     'Pistola Láser Orbital',       '🔫', 'crit',      'Rayo de precisión quirúrgica. Cada disparo busca una debilidad.'],
  ['airlock_blade',    'Cuchilla de Esclusa',         '🗡️', 'pierce',    'Se abre en dos como una compuerta. Nada bloquea su corte.'],
  ['turbine_scythe',   'Guadaña de Turbina',          '🌀', 'lifesteal', 'Rota a 40.000 rpm. Recicla un poco de energía en cada tajo.'],
  ['hologram_staff',   'Bastón Holográfico',          '🪄', 'dodge',     'Proyecta copias tuyas. El enemigo falla más ataques.'],
  ['rocket_fist',      'Puño Cohete',                 '🚀', 'special',   'Un guante propulsado. El especial lo dispara como un misil.'],
  ['thruster_shield',  'Escudo Propulsor',            '🛡️', 'reduce',    'Sus propulsores desvían los impactos frontales.'],

  // ── ZONA 6: SELVA SINTÉTICA ──
  ['vine_whip',        'Látigo de Liana',             '🌿', 'double',    'Liana sintética con reflejos. Golpea dos veces si la sacudes bien.'],
  ['neon_machete',     'Machete de Neón',             '🗡️', 'crit',      'Abre camino entre la maleza sintética y entre los tendones.'],
  ['tiger_claw',       'Garra de Tigre',              '🐯', 'critdmg',   'Cuchillas retráctiles. El zarpazo crítico deja tres líneas ardientes.'],
  ['fiber_blowgun',    'Cerbatana de Fibra',          '🎯', 'pierce',    'Dardos de grafeno hueco. Silenciosos y directos al sensor.'],
  ['graphene_spear',   'Lanza de Grafeno',            '🔱', 'pierce',    'Un átomo de grosor y una resistencia de mil aceros.'],
  ['acid_dart',        'Dardo de Fruta Ácida',        '🏹', 'special',   'Jugo ácido concentrado en cada punta. El especial lo multiplica.'],
  ['timber_club',      'Garrote de Ironwood',         '🪵', 'exec',      'Madera sintética más dura que el titanio. Remata sin piedad.'],
  ['emerald_blade',    'Espada Esmeralda',            '🗡️', 'lifesteal', 'Un filo verde translúcido que absorbe vida con cada estocada.'],
  ['sable_fang',       'Colmillo de Sable',           '🦷', 'crit',      'Trofeo de la bestia más temida de la selva. Corta con instinto.'],
  ['jungle_bow',       'Arco de Selva',               '🏹', 'double',    'Dispara dos flechas por cuerda. Ambas de fibra óptica.'],
  ['spore_launcher',   'Lanzaesporas',                '🍄', 'regen',     'Suelta esporas curativas que cierran tus heridas turno a turno.'],
  ['bark_shield',      'Escudo de Corteza',           '🛡️', 'thorns',    'Corteza llena de espinas de titanio. Golpearte duele.'],

  // ── ZONA 7: CIBERESPACIO ROTO ──
  ['glitch_blade',     'Hoja Glitch',                 '🗡️', 'crit',      'Su filo parpadea. A veces corta antes de que la muevas.'],
  ['firewall_shield',  'Firewall Blindado',           '🛡️', 'reduce',    'Bloquea paquetes hostiles y una buena parte de los golpes.'],
  ['packet_gun',       'Pistola de Paquetes',         '🔫', 'double',    'Envía los disparos duplicados por si uno se pierde en la red.'],
  ['virus_dagger',     'Daga Virus',                  '🔪', 'lifesteal', 'Infecta y drena. Parte de la vida robada es tuya.'],
  ['void_pen',         'Pluma del Vacío',             '🖋️', 'critdmg',   'Tinta negra que borra lo que toca. Los críticos escriben tu victoria.'],
  ['root_access',      'Acceso Root',                 '🔑', 'pierce',    'Abre cualquier defensa. Todas las contraseñas son «1234».'],
  ['tesla_lance',      'Lanza Tesla',                 '⚡', 'special',   'Acumula cargas en la punta y las libera en un rayo gigante.'],
  ['nebula_staff',     'Bastón de Nebulosa',          '🪄', 'dodge',     'Una nube de polvo cósmico te vuelve difícil de acertar.'],
  ['bit_scythe',       'Guadaña de Bits',             '🌾', 'exec',      'Corta el último bit de vida. Cero, uno. Fin.'],
  ['data_whip',        'Látigo de Datos',             '⛓️', 'double',    'Cadena de cables de fibra que golpea en ráfagas.'],
  ['exploit_axe',      'Hacha Exploit',               '🪓', 'crit',      'Aprovecha vulnerabilidades. Encuentra el punto débil casi siempre.'],
  ['ghost_cloak',      'Capa Fantasma',               '🧥', 'dodge',     'Te vuelve traslúcido por momentos. Muchos ataques te atraviesan.'],

  // ── ZONA 8: INFIERNO DE FUNDICIÓN ──
  ['anvil_hammer',     'Martillo de Yunque',          '🔨', 'critdmg',   'Golpe crítico con la fuerza de mil forjas. Los yunques tiemblan.'],
  ['magma_blade',      'Espada de Magma',             '🌋', 'crit',      'Corta y cauteriza. Cada golpe deja una marca de lava.'],
  ['forge_axe',        'Hacha de Fragua',             '🪓', 'pierce',    'Roja al blanco. Atraviesa cualquier blindaje que se enfríe.'],
  ['ember_spear',      'Lanza de Brasas',             '🔱', 'special',   'Punta viva de ascuas. El especial la lanza como un cohete.'],
  ['lava_whip',        'Látigo de Lava',              '🔥', 'double',    'Chorros de lava líquida a doble golpe.'],
  ['slag_maul',        'Maza de Escoria',             '🔨', 'exec',      'Pesada y quebradiza por dentro. Para terminar combates.'],
  ['inferno_katana',   'Katana Infernal',             '🗡️', 'crit',      'Se enciende al desenvainar. Los enemigos se rinden antes de que caiga.'],
  ['cinder_scythe',    'Guadaña de Cenizas',          '🌾', 'lifesteal', 'Convierte lo que corta en ceniza... y una parte en vida para ti.'],
  ['molten_shield',    'Escudo Fundido',              '🛡️', 'thorns',    'Quema a quien golpee. Nadie lo hace dos veces.'],
  ['titan_tongs',      'Tenazas Titánicas',           '🔧', 'pierce',    'Sujetan el metal candente... o al enemigo. Su armadura no aguanta.'],
  ['smelter_cannon',   'Cañón de Fundidor',           '💣', 'special',   'Dispara bolas de metal fundido. Un especial brutal.'],
  ['phoenix_blade',    'Hoja del Ave de Fuego',       '⚔️', 'regen',     'Al arder renace: te regenera un poco cada turno.'],

  // ── ZONA 9: DIMENSIONES ROTAS ──
  ['time_blade',       'Hoja del Tiempo',             '⏳', 'double',    'Golpea ahora y un instante después. A veces, también antes.'],
  ['paradox_sword',    'Espada Paradoja',             '⚔️', 'crit',      'Ya sabe dónde vas a fallar y ataca justo ahí.'],
  ['entropy_scythe',   'Guadaña de Entropía',         '🌾', 'lifesteal', 'Desordena las moléculas y te devuelve la energía sobrante.'],
  ['fractal_axe',      'Hacha Fractal',               '🪓', 'critdmg',   'Cada corte se subdivide en cortes más pequeños. Al infinito.'],
  ['rift_dagger',      'Daga de Grieta',              '🔪', 'pierce',    'Abre una grieta dimensional en el blindaje.'],
  ['chrono_hammer',    'Martillo Crono',              '🔨', 'exec',      'Su golpe adelanta el fin del enemigo unos segundos.'],
  ['unicorn_lance',    'Lanza de Unicornio',          '🦄', 'special',   'Un cuerno fractal. El especial pinta el aire de arcoíris.'],
  ['sauropod_club',    'Garrote de Saurópodo',        '🦕', 'thorns',    'Un hueso gigante. Devuelve la agresión con intereses.'],
  ['clock_shield',     'Escudo Reloj',                '🛡️', 'reduce',    'Retrasa cada golpe medio segundo. Suficiente para reducirlo.'],
  ['mirror_blade',     'Hoja Espejo',                 '🗡️', 'dodge',     'Refleja ataques en otra dimensión. A veces salen ilesos.'],
  ['warp_bow',         'Arco de Distorsión',          '🏹', 'double',    'La flecha se dobla el espacio y llega dos veces.'],
  ['anti_staff',       'Bastón Antimateria',          '🪄', 'regen',     'Contiene una gota de antimateria que anula el daño turno a turno.'],

  // ── ZONA 10: CORAZÓN DE NEXUS ──
  ['genesis_blade',    'Hoja Génesis',                '⚔️', 'crit',      'La primera espada. Todas las demás son copias.'],
  ['seed_scythe',      'Guadaña de la Semilla',       '🌾', 'lifesteal', 'Siembra la muerte y cosecha vida para su portador.'],
  ['nexus_katana',     'Katana de Nexus',             '🗡️', 'critdmg',   'Cada crítico resuena por los diez sectores.'],
  ['core_hammer',      'Martillo del Núcleo',         '🔨', 'exec',      'Late con el corazón de la ciudad. Termina cualquier combate.'],
  ['omega_lance',      'Lanza Omega',                 '🔱', 'pierce',    'Atraviesa hasta el último escudo de existencia.'],
  ['swan_wing',        'Ala de Cisne Negro',          '🪶', 'dodge',     'Ligera y letal. Te mueves como si el golpe no existiera.'],
  ['steed_lance',      'Lanza del Corcel',            '🐴', 'double',    'Se carga a galope. Golpea dos veces antes de que puedas parpadear.'],
  ['king_blade',       'Espada del Rey',              '👑', 'critdmg',   'Forjada con la corona del primer chef. Lo que corta, se arrodilla.'],
  ['eye_cannon',       'Cañón del Ojo',               '🧿', 'special',   'Dispara lo que ve. El especial arrasa lo que ve.'],
  ['heart_shield',     'Escudo Corazón',              '🛡️', 'reduce',    'Late en tu pecho. Cada latido amortigua un golpe.'],
  ['apocalypse_axe',   'Hacha del Apocalipsis',       '🪓', 'crit',      'Pesa lo que pesa el fin del mundo. Y corta lo mismo.'],
  ['final_edge',       'Filo Final de Nexus',         '🌟', 'critdmg',   'El arma definitiva. Después de esto, ya no queda nada por conquistar.']
];

(function buildExpansionWeapons() {
  const n = _EXP_WEAPON_ROWS.length;
  _EXP_WEAPON_ROWS.forEach(([id, name, emoji, perkType, desc], k) => {
    // Ataque: geométrico 210 → ~3400, redondeado a 5
    const attack = Math.round(210 * Math.pow(1.0237, k) / 5) * 5;
    // Sector "de referencia" del arma y precio en función de las bajas promedio ahí
    const refSector = Math.min(EXP_BAL.lastSector, EXP_BAL.firstSector + Math.floor(k * 100 / n));
    const price = Math.round(expectedKillCredits(refSector) * EXP_BAL.weaponPriceKills / 100) * 100;
    const info = WEAPON_PERK_INFO[perkType];
    const frac = k / (n - 1);
    const rawVal = info.min + (info.max - info.min) * frac;
    const value = Math.round(rawVal * 1000) / 1000;
    WEAPONS_CATALOG.push({
      id, name, emoji, attack, price, desc,
      perk: { type: perkType, value },
      reqLevel: getRequiredLevelForSector(refSector),
      refSector
    });
  });
})();

// ────────────────────────── SECTORES 11-110 ──────────────────────────
// [nombre, emoji, descripción]. El 10º sector de cada zona (20, 30, ... 110) es un
// Gran Bazar: paga parejo (~1.18x) por TODAS las comidas, ideal para farmear.
const _EXP_SECTOR_ROWS = [
  // ── ZONA 1: CINTURÓN REFINADOR (11-20) ──
  ['Depósito de Crudo Sintético', '🛢️', 'Tanques oxidados que rezuman petróleo sintético. Los recolectores pagan bien por platos calientes.'],
  ['Chimeneas Eternas',           '🏭', 'Un bosque de chimeneas que nunca se apagan. El aire sabe a metal y a promesas.'],
  ['Muelle de Coolant',           '🧊', 'Muelles cubiertos de escarcha química. Los estibadores adoran lo helado y lo ácido.'],
  ['Fundición Abandonada',        '⚒️', 'Talleres vacíos con brasas aún vivas. Comida contundente, sin preguntas.'],
  ['Planta de Baterías',          '🔋', 'Celdas del tamaño de casas. El personal come rápido y paga con descarga.'],
  ['Cinturón de Tuberías',        '🚰', 'Laberinto de tubos en tres niveles. Se cocina en cualquier codo.'],
  ['Torres de Destilación',       '🗼', 'Torres humeantes de las que gotea lo que nadie quiere saber.'],
  ['Laguna de Lodos',             '🟤', 'Un lago de residuos espeso como sopa. Sus habitantes, exigentes.'],
  ['Patio de Contenedores',       '📦', 'Pilas de contenedores convertidos en restaurantes clandestinos.'],
  ['Bazar del Cinturón',          '🌐', 'Mercado interzonal del Cinturón. Precio parejo por todo, sin especialidades.'],

  // ── ZONA 2: ARCHIPIÉLAGO TÓXICO (21-30) ──
  ['Costa de Aceite',             '🌊', 'Playas negras y brillantes. Los pescadores mutantes pagan en cobre y sal.'],
  ['Plataforma Petrolera Zeta',   '⛴️', 'Una plataforma que sigue perforando sola. Los turnos de cena son eternos.'],
  ['Arrecife de Chatarra',        '🐚', 'Coral hecho de latas y cables. Hogar de bestias curiosas y hambrientas.'],
  ['Isla de Barcos Muertos',      '⚓', 'Cementerio de cascos varados. Los fantasmas piden el menú del día.'],
  ['Faros Corroídos',             '🏝️', 'Faros sin luz que atraen a criaturas con luz propia.'],
  ['Bahía de la Marea Ácida',     '🧪', 'La marea corroe el muelle cada noche. Las cocinas flotan.'],
  ['Puerto Flotante',             '🚢', 'Una ciudad de barcazas atadas con cadena. Comercio y peleas a partes iguales.'],
  ['Manglar de Cables',           '🌿', 'Raíces de fibra óptica bajo aguas verdes. Se cocina en silencio.'],
  ['Atolón Radiactivo',           '☢️', 'Un anillo de tierra que brilla de noche. Los clientes también.'],
  ['Bazar del Archipiélago',      '🌐', 'Mercado de trueque sobre balsas. Precio parejo por todo.'],

  // ── ZONA 3: DESIERTO DE SILICIO (31-40) ──
  ['Dunas de Vidrio',             '🏜️', 'Arena vitrificada que corta las botas. Las caravanas pasan hambrientas.'],
  ['Granja Solar Infinita',       '☀️', 'Millones de paneles hasta el horizonte. Aquí siempre es mediodía.'],
  ['Oasis de Coolant',            '🌴', 'Una charca de refrigerante rodeada de palmeras de titanio.'],
  ['Cañón de Cables',             '🏞️', 'Un cañón tapizado de cableado antiguo. El eco lleva pedidos lejos.'],
  ['Ruinas del Data Center',      '🏚️', 'Servidores a medio fundir. Hackers nostálgicos cenan aquí.'],
  ['Tormenta Magnética',          '🌪️', 'Un torbellino que imanta todo lo metálico. Las bandejas se pegan solas.'],
  ['Caravanas de Silicio',        '🐫', 'Mercaderes nómadas con camellos de carga. Compran para semanas.'],
  ['Espejismo Permanente',        '🔮', 'Un campamento que solo existe cuando no lo miras.'],
  ['Torre de Refrigeración',      '🏗️', 'La única sombra en cien kilómetros. Colas interminables.'],
  ['Bazar del Desierto',          '🌐', 'Zoco central de las dunas. Precio parejo por todo.'],

  // ── ZONA 4: CIUDAD HUNDIDA (41-50) ──
  ['Puerto Sumergido',            '🚧', 'Muelles a diez metros bajo el agua. Se cocina con escafandra.'],
  ['Metro Inundado',              '🚇', 'Andenes anegados con vagones habitados. La línea 3 pide siempre lo mismo.'],
  ['Rascacielos de Coral',        '🏙️', 'Torres cubiertas de coral vivo que brilla de noche.'],
  ['Catedral de Presión',         '⛪', 'Una nave gótica sostenida por bombas de aire. Silencio y buen paladar.'],
  ['Cementerio de Submarinos',    '💀', 'Cascos gigantes hundidos. Los fantasmas tienen mucho apetito.'],
  ['Jardines de Perlas',          '⚪', 'Granjas de ostras del tamaño de coches. Riqueza y sabor.'],
  ['Túneles de Sonar',            '📡', 'Galerías donde el eco delata cada movimiento. Los clientes escuchan tus pasos.'],
  ['Fosa de los Leviatanes',      '🌑', 'La grieta más profunda de la ciudad. Las bestias cantan aquí.'],
  ['Cúpula de Aire',              '🔵', 'Una burbuja habitable a 200 metros. La élite cena aquí.'],
  ['Bazar Hundido',               '🌐', 'Bazar bajo la superficie. Precio parejo por todo.'],

  // ── ZONA 5: ÓRBITA BAJA (51-60) ──
  ['Ascensor Espacial',           '🚀', 'El cable que une Nexus con las estrellas. Viajeros hambrientos de todos lados.'],
  ['Estación Alfa',               '🛰️', 'Primera estación de la órbita. Sus tripulantes cenan flotando.'],
  ['Anillo de Basura Espacial',   '♻️', 'Chatarra orbital convertida en barrio. Todo se reutiliza, incluida la cena.'],
  ['Laboratorio Cero-G',          '🧬', 'Científicos sin gravedad. Prueban cualquier receta al menos una vez.'],
  ['Hangar de Cohetes',           '🛫', 'Pilotos que pagan mucho por comer rápido y salir aún más rápido.'],
  ['Cinturón de Asteroides',      '☄️', 'Mineros que cenan entre rocas. Les encanta lo picante.'],
  ['Cúpula de Invernaderos',      '🌱', 'Cultivos en gravedad artificial. Paladares delicados.'],
  ['Puente de Mando',             '🎛️', 'Oficiales que exigen precisión. Cada plato con protocolo.'],
  ['Muelle Lunar',                '🌙', 'Última parada antes de la Luna. Cenas caras y despedidas más caras.'],
  ['Bazar Orbital',               '🌐', 'Zoco de la estación. Precio parejo por todo.'],

  // ── ZONA 6: SELVA SINTÉTICA (61-70) ──
  ['Claro de Fibra Óptica',       '🌴', 'Un claro donde las lianas iluminan como lámparas. Ambiente íntimo.'],
  ['Pantano de Neón',             '🐸', 'Lodazal fluorescente. Los sapos hacen de camareros.'],
  ['Cascada de Coolant',          '💧', 'Agua azul brillante que cae por rocas de silicio. Muy fotogénica.'],
  ['Templo Vegetal',              '🛕', 'Un santuario cubierto de raíces. Se cocina como ofrenda.'],
  ['Copa de los Árboles',         '🌳', 'Restaurantes colgantes entre ramas de titanio.'],
  ['Guarida del Tigre',           '🐅', 'Territorio de un felino que nadie ha visto y todos temen.'],
  ['Lianas Eléctricas',           '⚡', 'Redes de lianas que descargan al pisarlas. Sabor picante garantizado.'],
  ['Raíces de Titanio',           '🪵', 'Raíces gigantes de metal vivo. Aquí se cocina con leña metálica.'],
  ['Claro Esmeralda',             '💚', 'Aire limpio y luz verde. Los clientes más exigentes vienen a relajarse.'],
  ['Bazar de la Selva',           '🌐', 'Mercado bajo el dosel. Precio parejo por todo.'],

  // ── ZONA 7: CIBERESPACIO ROTO (71-80) ──
  ['Puerto de Entrada',           '🔌', 'La puerta al ciberespacio. Los paquetes hacen fila para cenar.'],
  ['Servidor Abandonado',         '🗄️', 'Racks vacíos y bestias con hambre de datos.'],
  ['Bosque de Firewalls',         '🔥', 'Muros de fuego que se abren solo para el buen plato.'],
  ['Océano de Datos',             '💾', 'Olas de bits en las que flotan restaurantes de paquetes.'],
  ['Nodo Fantasma',               '👻', 'Un nodo que no existe. Los clientes también, a ratos.'],
  ['Mercado Negro Digital',       '🕶️', 'Ofertas cifradas. Solo paga bien quien conoce la contraseña.'],
  ['Cámara de Encriptación',      '🔐', 'Sala blindada donde cada plato debe venir cifrado.'],
  ['Laberinto de Bits',           '🧩', 'Pasillos que cambian cada vez. La cocina se reconfigura sola.'],
  ['Núcleo de Procesamiento',     '🖥️', 'El corazón de la red. Los procesos exigen platos de alto rendimiento.'],
  ['Bazar Digital',               '🌐', 'Tienda global de paquetes. Precio parejo por todo.'],

  // ── ZONA 8: INFIERNO DE FUNDICIÓN (81-90) ──
  ['Puerta de la Fragua',         '🚪', 'Portón de hierro al rojo vivo. Al otro lado, el calor lo decide todo.'],
  ['Río de Magma',                '🌋', 'Un río ardiente. Se cocina con solo mojar la cuchara.'],
  ['Yunque Colosal',              '🔨', 'Un yunque del tamaño de una plaza. Los herreros comen a su alrededor.'],
  ['Cámara de Escoria',           '⛓️', 'Sala de residuos de metal. Los clientes pagan por lo ardiente y ligero.'],
  ['Altos Hornos',                '♨️', 'Cuatro hornos que no se apagan desde el colapso.'],
  ['Volcán Mecánico',             '🗻', 'Un volcán con engranajes. Su erupción es a la hora del almuerzo.'],
  ['Mina de Carbón Vivo',         '⛏️', 'Carbón que respira. Los mineros lo cocinan mientras trabajan.'],
  ['Trono de Cenizas',            '🪑', 'Un trono de ceniza acumulada. Su ocupante exige lo mejor.'],
  ['Cráter del Demonio',          '😈', 'El fondo de la fundición. Solo cenan los que pueden soportarlo.'],
  ['Bazar de la Fundición',       '🌐', 'Mercado de herreros. Precio parejo por todo.'],

  // ── ZONA 9: DIMENSIONES ROTAS (91-100) ──
  ['Grieta Inicial',              '🌀', 'La primera fisura entre mundos. Los clientes llegan de todas partes.'],
  ['Reloj Roto',                  '⌛', 'Una plaza con relojes detenidos. Nadie tiene prisa, todos tienen hambre.'],
  ['Jardín Fractal',              '🌸', 'Flores que se repiten al infinito. Cocinas que también.'],
  ['Biblioteca de Paradojas',     '📚', 'Libros que se escriben mientras los lees. Menú incluido.'],
  ['Playa del Fin del Tiempo',    '🏖️', 'Una orilla donde las olas retroceden. Cenas atemporales.'],
  ['Cielo Invertido',             '🙃', 'El suelo está arriba. Los platos caen hacia el techo.'],
  ['Laberinto de Espejos',        '🪞', 'Cada espejo es un restaurante distinto. Todos con la misma carta.'],
  ['Museo del Futuro',            '🏛️', 'Muestras de lo que aún no ha ocurrido. Menú degustación permanente.'],
  ['Umbral Cuántico',             '🚪', 'La puerta que está abierta y cerrada. Los clientes también.'],
  ['Bazar Interdimensional',      '🌐', 'Comercio entre mundos. Precio parejo por todo.'],

  // ── ZONA 10: CORAZÓN DE NEXUS (101-110) ──
  ['Puertas de Nexus',            '🏰', 'La entrada al corazón de la ciudad. Guardias con paladar.'],
  ['Avenida de los Reyes',        '🛣️', 'Una avenida de estatuas. Todas ellas piden postre.'],
  ['Núcleo de Servidores',        '💽', 'El cerebro de Nexus-7. Sus procesos cenan puntuales.'],
  ['Plaza de la Singularidad',    '⚫', 'Un punto negro que atrae a todos. Cenar aquí es un privilegio.'],
  ['Jardines del Génesis',        '🌺', 'Flores que nacieron antes del colapso. Clientes con mucha historia.'],
  ['Cámara del Ojo',              '🧿', 'Una sala vigilada por un ojo enorme. Mejor servir bien.'],
  ['Cocina Primigenia',           '🍳', 'La primera cocina de Nexus. Todo chef sueña con trabajar aquí.'],
  ['Salón del Trono',             '👑', 'El trono del Rey de Nexus. Solo se sirve lo mejor de lo mejor.'],
  ['Reactor del Origen',          '⚛️', 'De aquí salió la energía que creó la ciudad. Y aún late.'],
  ['Gran Bazar de Nexus',         '🌐', 'La cima del comercio. Precio parejo por todo, para todos, siempre.']
];

(function buildExpansionSectors() {
  // Generador pseudoaleatorio con semilla (los precios de cada sector son siempre los mismos)
  let seed = 1107;
  const rnd = () => {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
  const between = (a, b) => Math.round((a + rnd() * (b - a)) * 100) / 100;
  const pick = arr => arr[Math.floor(rnd() * arr.length)];

  const oldIds = RECIPES.slice(0, 9).map(r => r.id);  // las 9 recetas originales
  const newIds = _EXP_RECIPE_ROWS.map(r => r[0]);

  _EXP_SECTOR_ROWS.forEach(([name, emoji, desc], i) => {
    const id = 11 + i;
    const z = Math.floor(i / 10) + 1;           // 1..10
    const j = i % 10;                            // 0..9 (9 = bazar)
    const zoneIds = newIds.slice((z - 1) * 10, z * 10);
    const prevIds = z > 1 ? newIds.slice((z - 2) * 10, (z - 1) * 10) : oldIds;
    const isMarket = j === 9;
    let multipliers = {};

    if (isMarket) {
      RECIPES.forEach(r => { multipliers[r.id] = 1.18; });
    } else {
      multipliers[zoneIds[j]] = between(1.40, 1.55);                       // especialidad
      const second = (j === 2 || j === 5 || j === 8) ? zoneIds[9] : pick(zoneIds.filter(x => x !== zoneIds[j]));
      if (!multipliers[second]) multipliers[second] = between(1.20, 1.30);
      const third = pick(prevIds);
      if (!multipliers[third]) multipliers[third] = between(1.10, 1.25);
      // dos platos que ahí se pagan peor
      for (let n = 0; n < 2; n++) {
        const bad = pick([...oldIds, ...prevIds, ...zoneIds]);
        if (!multipliers[bad]) multipliers[bad] = between(0.75, 0.90);
      }
    }

    SECTORS.push({
      id,
      name: `Sector ${id}: ${name}`,
      emoji,
      desc,
      reqLevel: getRequiredLevelForSector(id),
      zoneId: z,
      balanced: isMarket,
      multipliers
    });
  });

  // El Gran Mercado del Sector 10 también paga parejo por las recetas nuevas
  const s10 = SECTORS.find(s => s.id === 10);
  if (s10) { s10.balanced = true; newIds.forEach(rid => { s10.multipliers[rid] = 1.18; }); }
})();

// ───────────────────────── CLIENTES NUEVOS (30) ──────────────────────
// 3 por zona. Cada uno prefiere 4 recetas de su zona (todas las recetas nuevas
// tienen al menos un cliente que las pide).
const _EXP_CUSTOMER_ROWS = [
  [['Capataz del Cinturón', '👷'], ['Soldador Cyborg', '🦾'], ['Rata de Muelle', '🐭']],
  [['Pescador Tóxico', '🎣'], ['Capitán Oxidado', '🧔'], ['Sirena Mutante', '🧜']],
  [['Camellero de Datos', '🐪'], ['Escorpión Mercader', '🦂'], ['Nómada del Espejismo', '🏜️']],
  [['Buzo Cibernético', '🤿'], ['Almirante Hundido', '🎖️'], ['Sirena Sónica', '🐬']],
  [['Astronauta Gourmet', '🧑‍🚀'], ['Ovni Curioso', '🛸'], ['Piloto de Cohete', '🚀']],
  [['Cazador de Selva', '🏹'], ['Chamán Verde', '🧙'], ['Reina de la Jungla', '🦜']],
  [['Hacker Fantasma', '🥷'], ['Streamer Glitch', '🎮'], ['Bot Crítico', '🤖']],
  [['Herrero Demonio', '😈'], ['Minero de Brasas', '⛏️'], ['Duquesa de Ceniza', '🔥']],
  [['Viajero del Tiempo', '⌛'], ['Filósofa Cuántica', '🧠'], ['Anciano Paradoja', '🧓']],
  [['Príncipe de Nexus', '🤴'], ['Emperatriz Génesis', '👸'], ['Chef Primordial', '🧑‍🍳']]
];

(function buildExpansionCustomers() {
  const newIds = _EXP_RECIPE_ROWS.map(r => r[0]);
  _EXP_CUSTOMER_ROWS.forEach((trio, zi) => {
    const zoneIds = newIds.slice(zi * 10, zi * 10 + 10);
    const prefSets = [
      [zoneIds[0], zoneIds[1], zoneIds[2], zoneIds[3]],
      [zoneIds[4], zoneIds[5], zoneIds[6], zoneIds[7]],
      [zoneIds[8], zoneIds[9], zoneIds[0], zoneIds[5]]
    ];
    trio.forEach(([name, emoji], n) => {
      CUSTOMER_TYPES.push({
        id: `exp_z${zi + 1}_c${n + 1}`,
        name, emoji,
        preferences: prefSets[n],
        budget: Math.round(1500 * Math.pow(1.03, zi * 10 + 4) * 1.4 / 10) * 10,
        patience: Math.max(22, 38 - n * 5 - Math.floor(zi / 3))
      });
    });
  });
})();

// ───────────────────── LABORATORIO DE MEJORAS (29) ───────────────────
// Cada línea tiene niveles. stat = nombre del bonus (se suma con perks de arma y habilidades).
// perLevel = valor por nivel (0.015 = +1.5%). instant = se aplica al comprar (vida/defensa).
// costFactor = cuántas "bajas promedio" cuesta el primer nivel; luego sube (n+1)^1.4.
const LAB_CATEGORIES = [
  { id: 'combat',  name: '⚔️ COMBATE' },
  { id: 'defense', name: '🛡️ DEFENSA' },
  { id: 'economy', name: '💰 ECONOMÍA' },
  { id: 'kitchen', name: '🍳 COCINA' }
];

function getSectorForLevel(level) {
  if (level <= EXP_BAL.levelBase + 1) return 10;
  return Math.min(EXP_BAL.lastSector, 10 + Math.ceil((level - EXP_BAL.levelBase) / EXP_BAL.levelPerSector));
}

// Coste base de un nivel 1: bajas promedio del sector donde se desbloquea × factor
function getLabBaseCost(reqLevel, costFactor) {
  const basis = expectedKillCredits(getSectorForLevel(reqLevel));
  // Las mejoras de Nv 10-20 son más baratas (el jugador aún no gana tanto)
  const early = reqLevel < 20 ? 0.25 + 0.75 * Math.max(0, reqLevel - 10) / 10 : 1;
  return Math.max(500, Math.round(basis * costFactor * early / 50) * 50);
}

// [id, nombre, emoji, categoría, stat, porNivel, máx, nivelReq, factorCoste, descripción]
const _EXP_LAB_ROWS = [
  // ── COMBATE ──
  ['lab_crit',       'Óptica Crítica',          '🎯', 'combat',  'crit',       0.015, 30, 10, 0.50, 'prob. de golpe crítico'],
  ['lab_critdmg',    'Filos Resonantes',        '💢', 'combat',  'critdmg',    0.06,  25, 14, 0.50, 'daño extra de los críticos'],
  ['lab_atkpct',     'Servos de Fuerza',        '💪', 'combat',  'atkpct',     0.02,  50, 12, 0.60, 'ataque total'],
  ['lab_pierce',     'Punta Perforante',        '📌', 'combat',  'pierce',     0.02,  30, 20, 0.60, 'defensa enemiga ignorada'],
  ['lab_lifesteal',  'Sifón Vampírico',         '🩸', 'combat',  'lifesteal',  0.004, 25, 22, 0.70, 'del daño infligido se convierte en vida'],
  ['lab_special',    'Módulo de Especial',      '💥', 'combat',  'special',    0.05,  20, 16, 0.40, 'daño del ataque especial'],
  ['lab_specialacc', 'Sintonía de Especial',    '🎲', 'combat',  'specialacc', 0.01,  30, 16, 0.35, 'prob. de éxito del especial'],
  ['lab_double',     'Doble Corte',             '⚡', 'combat',  'double',     0.01,  20, 26, 0.80, 'prob. de golpear dos veces'],
  ['lab_exec',       'Ejecutor',                '☠️', 'combat',  'exec',       0.02,  25, 30, 0.80, 'daño vs enemigos bajo 30% de vida'],
  // ── DEFENSA ──
  ['lab_reduce',     'Campo de Fuerza',         '🛡️', 'defense', 'reduce',     0.01,  35, 12, 0.60, 'reducción del daño recibido'],
  ['lab_dodge',      'Reflejos Sintéticos',     '💨', 'defense', 'dodge',      0.01,  30, 18, 0.60, 'prob. de esquivar ataques'],
  ['lab_thorns',     'Espinas Reactivas',       '🌵', 'defense', 'thorns',     0.03,  20, 24, 0.50, 'del daño recibido se refleja al enemigo'],
  ['lab_regen',      'Nanoregeneración',        '💚', 'defense', 'regen',      0.003, 20, 20, 0.70, 'de vida máx. recuperada cada turno'],
  ['lab_hp',         'Implante Mayor',          '❤️', 'defense', null,         0.05,  25, 10, 0.80, 'de vida máxima (se aplica al comprar y cura)', 'maxHp'],
  ['lab_def',        'Blindaje Adaptativo',     '🧱', 'defense', null,         0.06,  25, 14, 0.70, 'de defensa (se aplica al comprar)', 'defense'],
  ['lab_secondwind', 'Segundo Aliento',         '🔁', 'defense', 'secondwind', 0.04,  10, 34, 1.20, 'prob. de sobrevivir un golpe mortal (1 vez por combate)'],
  // ── ECONOMÍA ──
  ['lab_credits',    'Contrato Corporativo',    '💰', 'economy', 'creditpct',  0.02,  50, 10, 0.60, 'créditos por bestia derrotada'],
  ['lab_xp',         'Neuro-Acelerador',        '🧠', 'economy', 'xppct',      0.02,  50, 10, 0.60, 'XP por bestia derrotada'],
  ['lab_drops',      'Sensor de Rastreo',       '🔍', 'economy', 'droppct',    0.02,  40, 12, 0.40, 'prob. de obtener ingredientes'],
  ['lab_lootqty',    'Bolsas Ampliadas',        '🎒', 'economy', 'lootqty',    0.015, 30, 18, 0.50, 'prob. de doble botín'],
  ['lab_discount',   'Descuento de Mercader',   '🏷️', 'economy', 'discount',   0.01,  30, 22, 1.00, 'de descuento en tienda y laboratorio'],
  ['lab_huntheal',   'Kit de Campo',            '🩹', 'economy', 'huntheal',   0.02,  25, 14, 0.30, 'de vida máx. recuperada al empezar una caza'],
  // ── COCINA ──
  ['lab_cookzone',   'Termostato de Precisión', '🌡️', 'kitchen', 'cookzone',   0.005, 20, 10, 0.30, 'de zona perfecta por lado en el medidor'],
  ['lab_cookslow',   'Fogón Estabilizado',      '🐢', 'kitchen', 'cookslow',   0.02,  25, 12, 0.30, 'menos velocidad del medidor'],
  ['lab_starup',     'Sazón Maestra',           '✨', 'kitchen', 'starup',     0.02,  30, 18, 0.50, 'prob. de subir el plato +1 ⭐'],
  ['lab_tip',        'Propina Cibernética',     '💵', 'kitchen', 'tip',        0.03,  30, 16, 0.50, 'de pago extra al servir'],
  ['lab_patience',   'Aroma Relajante',         '🌸', 'kitchen', 'patience',   0.03,  30, 14, 0.30, 'de paciencia extra en clientes'],
  ['lab_servetime',  'Reloj de Servicio',       '⏱️', 'kitchen', 'servetime',  1,     30, 20, 0.40, 'segundo extra de servicio'],
  ['lab_extracust',  'Barra Ampliada',          '💺', 'kitchen', 'extracust',  1,      3, 28, 3.00, 'cliente extra por servicio']
];

const UPGRADE_LINES = _EXP_LAB_ROWS.map(([id, name, emoji, cat, stat, perLevel, max, reqLevel, costFactor, desc, instant]) => ({
  id, name, emoji, cat, stat, perLevel, max, reqLevel, desc,
  instant: instant || null,
  baseCost: getLabBaseCost(reqLevel, costFactor)
}));

// Coste del siguiente nivel (sin descuento; game.js aplica el descuento del mercader)
function getLabUpgradeCost(line, currentLevel) {
  return Math.round(line.baseCost * Math.pow(currentLevel + 1, 1.4));
}

// Tope de cada bonus para que nada rompa el juego
const STAT_CAPS = {
  crit: 0.75, pierce: 0.75, lifesteal: 0.35, double: 0.5, dodge: 0.5, reduce: 0.6,
  thorns: 0.8, regen: 0.15, secondwind: 0.6, discount: 0.5, cookslow: 0.6, cookzone: 0.3,
  specialacc: 0.3, huntheal: 0.6
};

// ────────────────────── HABILIDADES NUEVAS (por hito) ─────────────────
// Las habilidades originales (overcharge, nanoshield) siguen funcionando en game.js.
const ABILITY_DEFS = {
  fortune:   { name: '🍀 Fortuna de Cazador',   stats: { droppct: 0.25 },   text: '+25% de probabilidad de conseguir ingredientes.' },
  vampirism: { name: '🧛 Vampirismo Táctico',    stats: { lifesteal: 0.06 }, text: 'Recuperas un 6% del daño infligido como vida.' },
  phoenix:   { name: '🔥 Fénix Mecánico',        stats: {},                  text: 'Una vez por combate, si caes a 0 de vida, revives con 50%.' },
  overdrive: { name: '🚀 Sobrecarga Total',      stats: { atkpct: 0.20 },    text: '+20% de ataque total permanente.' },
  gourmet:   { name: '🍽️ Paladar Gourmet',       stats: { tip: 0.15 },       text: '+15% de pago extra al servir platos.' }
};

// ───────────────────────── HITOS DE NIVEL 25-50 ──────────────────────
(function buildExpansionMilestones() {
  const wAt = k => WEAPONS_CATALOG.find(w => w.id === _EXP_WEAPON_ROWS[k][0]);
  const gold = lvl => Math.round(expectedKillCredits(getSectorForLevel(lvl)) * 15 / 1000) * 1000;
  const defs = [
    { lvl: 25, heals: 5,  weapon: 20 },
    { lvl: 28, heals: 5,  ability: 'fortune' },
    { lvl: 30, heals: 6,  ability: 'vampirism' },
    { lvl: 33, heals: 8,  weapon: 45 },
    { lvl: 36, heals: 8,  ability: 'phoenix' },
    { lvl: 40, heals: 10, ability: 'overdrive' },
    { lvl: 43, heals: 12, weapon: 80 },
    { lvl: 46, heals: 12, ability: 'gourmet' },
    { lvl: 50, heals: 20, weapon: 119 }
  ];
  const titles = {
    25: '⚔️ VETERANO DE LA REFINERÍA (NV. 25)', 28: '🍀 OLFATO DE CAZADOR (NV. 28)',
    30: '🧛 SED DE BATALLA (NV. 30)',           33: '🌵 SEÑOR DEL DESIERTO (NV. 33)',
    36: '🔥 RENACIDO DE LAS CENIZAS (NV. 36)', 40: '🚀 LEYENDA DE NEXUS (NV. 40)',
    43: '🌋 FORJADOR DEL INFIERNO (NV. 43)',   46: '🍽️ PALADAR SUPREMO (NV. 46)',
    50: '👑 REY DE NEXUS-110 (NV. 50)'
  };
  defs.forEach(d => {
    const credits = gold(d.lvl);
    let m = { title: titles[d.lvl], credits, heals: d.heals };
    if (d.weapon !== undefined) {
      const w = wAt(d.weapon);
      m.rewardType = 'weapon'; m.weaponId = w.id; m.weaponName = `${w.emoji} ${w.name}`;
      m.description = `Recibes ${credits.toLocaleString()}₿, ${d.heals} Curaciones Completas y el arma "${w.emoji} ${w.name}" (+${w.attack} de Daño) directamente a tu mochila.`;
    } else {
      const a = ABILITY_DEFS[d.ability];
      m.rewardType = 'ability'; m.abilityId = d.ability; m.abilityName = a.name;
      m.description = `Recibes ${credits.toLocaleString()}₿, ${d.heals} Curaciones Completas y la habilidad pasiva: ${a.text}`;
    }
    LEVEL_MILESTONES[d.lvl] = m;
  });
})();
