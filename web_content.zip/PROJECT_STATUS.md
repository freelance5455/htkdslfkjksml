# Smart 1.3.0 Free + Pro
Included: Free 10-request daily limit, Pro upgrade flow, Google Play Billing integration, safe Android actions, voice input, accessibility/notification foundations, API 36 build configuration and commercial docs.
Remaining: connect server-side AI model, production authentication/usage sync, secure Play purchase verification, signed AAB build, Play Console configuration and device/policy testing.


## v1.4 Production AI integration
- Server-side OpenAI Responses API integration added.
- Android SmartAiClient added.
- API key remains server-side.
- Replace the backend URL and deploy before installing a production APK.


- Smart 10.2: clearer Chat with Smart panel, quick prompts, improved message composer and assistant bubbles.

## Smart 10.3 — Menu + Complete Feature Hub
- Rebuilt the browser companion UI to make the menu, Chat, Smart Voice, phone actions and feature list obvious.
- Added a full Smart menu with Chat/AI, Phone Control, Tools, Accessibility, Floating Smart Button, Sign in, Smart Pro and Devices/Company sections.
- Added native Android “Everything Smart can do” feature dialog and clearer top menu accessibility label.
- Added clearer web-preview messaging so users do not mistake the browser preview for native Android phone control.
