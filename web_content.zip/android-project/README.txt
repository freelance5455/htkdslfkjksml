طريقة بناء الـ APK:
1) نزّل Android Studio (مجاني) وافتحه.
2) File > Open واختر مجلد RocketBallAndroid (بعد فك الضغط) وانتظر حتى ينتهي Gradle Sync.
3) من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s).
4) الملف يظهر في app/build/outputs/apk/debug/app-debug.apk ، انسخه لهاتفك وثبّته (فعّل "التثبيت من مصادر غير معروفة").
ملاحظة: اللعبة تحتاج إنترنت (مكتبات three.js و PeerJS تتحمل من الشبكة).
