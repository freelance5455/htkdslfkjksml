package com.widmate.browser;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    ProgressBar progress;
    ValueCallback<Uri[]> uploadCallback;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(8,6,8,6);
        bar.setBackgroundColor(Color.rgb(124,77,255));

        Button back = btn("‹"), forward = btn("›"), home = btn("⌂"), refresh = btn("↻");
        EditText url = new EditText(this);
        url.setSingleLine(true); url.setHint("Search Google or enter website");
        url.setTextColor(Color.WHITE); url.setHintTextColor(0xCCFFFFFF);
        url.setBackgroundColor(0x22FFFFFF);
        Button go = btn("GO");
        bar.addView(back); bar.addView(forward); bar.addView(home); bar.addView(refresh);
        bar.addView(url,new LinearLayout.LayoutParams(0,52,1)); bar.addView(go);

        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); progress.setVisibility(View.GONE);

        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setSupportZoom(true);
        s.setBuiltInZoomControls(false); s.setMediaPlaybackRequiresUserGesture(false);
        CookieManager.getInstance().setAcceptCookie(true);

        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ return false; }
            @Override public void onPageFinished(WebView v,String u){ url.setText(u); progress.setVisibility(View.GONE); }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onProgressChanged(WebView v,int p){ progress.setProgress(p); progress.setVisibility(p<100?View.VISIBLE:View.GONE); }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(uploadCallback!=null) uploadCallback.onReceiveValue(null);
                uploadCallback=cb;
                Intent i=params.createIntent();
                try { startActivityForResult(i,9001); } catch(Exception e){ uploadCallback=null; return false; }
                return true;
            }
        });
        web.setDownloadListener((u,userAgent,contentDisposition,mimeType,contentLength)->{
            DownloadManager dm=(DownloadManager)getSystemService(DOWNLOAD_SERVICE);
            try {
                DownloadManager.Request r=new DownloadManager.Request(Uri.parse(u));
                r.setTitle(URLUtil.guessFileName(u,contentDisposition,mimeType));
                r.setDescription("WidMate download");
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setAllowedOverMetered(true); r.setAllowedOverRoaming(true);
                dm.enqueue(r);
                Toast.makeText(this,"Download started",Toast.LENGTH_SHORT).show();
            } catch(Exception e){ Toast.makeText(this,"Download failed",Toast.LENGTH_SHORT).show(); }
        });

        root.addView(bar); root.addView(progress,new LinearLayout.LayoutParams(-1,4)); root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        back.setOnClickListener(v->{if(web.canGoBack())web.goBack();});
        forward.setOnClickListener(v->{if(web.canGoForward())web.goForward();});
        refresh.setOnClickListener(v->web.reload());
        home.setOnClickListener(v->web.loadUrl("file:///android_asset/index.html"));
        go.setOnClickListener(v->navigate(url.getText().toString()));
        url.setOnEditorActionListener((v,a,e)->{navigate(url.getText().toString());return true;});

        web.loadUrl("file:///android_asset/index.html");
    }

    Button btn(String t){ Button b=new Button(this); b.setText(t); b.setTextColor(Color.WHITE); b.setTextSize(20); b.setAllCaps(false); b.setMinWidth(46); b.setPadding(4,0,4,0); return b; }

    void navigate(String x){
        x=x.trim(); if(x.isEmpty())return;
        if(x.startsWith("http://")||x.startsWith("https://")) web.loadUrl(x);
        else if(x.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(/.*)?$")) web.loadUrl("https://"+x);
        else web.loadUrl("https://www.google.com/search?q="+Uri.encode(x));
    }

    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==9001 && uploadCallback!=null){
            Uri[] result=null;
            if(res==RESULT_OK && data!=null){
                if(data.getClipData()!=null){ int n=data.getClipData().getItemCount(); result=new Uri[n]; for(int i=0;i<n;i++) result[i]=data.getClipData().getItemAt(i).getUri(); }
                else if(data.getData()!=null) result=new Uri[]{data.getData()};
            }
            uploadCallback.onReceiveValue(result); uploadCallback=null;
        }
    }

    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}