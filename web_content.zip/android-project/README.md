# Business App — Android Studio Project

This is a native Android wrapper (WebView) around the Business web app.
The web app itself lives at `app/src/main/assets/www/index.html` and runs
fully offline — all data is stored locally via localStorage/IndexedDB inside
the WebView.

## How to open and build

1. Open **Android Studio** (Giraffe / Koala or newer recommended).
2. Choose **Open** and select this project's root folder (the one containing
   `settings.gradle`).
3. Let Gradle sync — it will download the Android Gradle Plugin and
   dependencies automatically (needs internet the first time).
4. Once synced, click **Run ▶** to install on a connected device/emulator,
   or go to **Build → Generate Signed Bundle / APK** to produce a release
   APK/AAB for distribution.

## App details

- Package name: `com.business.app` (change in `app/build.gradle` and move
  the `MainActivity.java` package folder if you want a different one)
- Min SDK: 24 (Android 7.0+)
- Target/Compile SDK: 34
- Entry point: `MainActivity.java` loads
  `file:///android_asset/www/index.html` into a WebView with JavaScript
  and DOM storage enabled.

## Updating the app content

To update the app's content, replace
`app/src/main/assets/www/index.html` with a newer export, then rebuild.

## App icon

Placeholder launcher icons (a "B" mark) are included under
`app/src/main/res/mipmap-*/`. Replace `ic_launcher.png` /
`ic_launcher_round.png` in each density folder with your real logo at:
- mdpi: 48x48
- hdpi: 72x72
- xhdpi: 96x96
- xxhdpi: 144x144
- xxxhdpi: 192x192

## Signing for release

To publish to the Play Store, use **Build → Generate Signed Bundle / APK**
in Android Studio, create/select a keystore, and build an **Android App
Bundle (.aab)** — Google Play's required format.
