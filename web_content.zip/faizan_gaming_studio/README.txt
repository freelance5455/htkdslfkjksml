FAIZAN GAMING STUDIO website

Files:
- index.html: complete responsive website (HTML, CSS, JavaScript in one file)

How to preview:
1. Open index.html in a browser.
2. For publishing, upload index.html to a static hosting service such as GitHub Pages, Netlify, or your hosting provider.

How to customize:
- Search for CONTACT_EMAIL in the script and add your email address between the quotes.
- Replace the email, WhatsApp and social placeholders in the Contact section.
- Replace the four concept project cards with your real projects when ready.
- Colors and layout variables are near the top of the CSS under :root.

Contact form:
The form is a front-end demo. It opens the visitor's email app only after CONTACT_EMAIL is filled in. It does not store or transmit form data by itself.
