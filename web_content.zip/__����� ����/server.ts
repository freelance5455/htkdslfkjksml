import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface SignalingMessage {
  id: string;
  sender: string;
  type: 'offer' | 'answer' | 'candidate' | 'command' | 'leave';
  payload: any;
  timestamp: number;
}

interface RoomData {
  roomId: string;
  pin: string;
  hostOnline: boolean;
  viewerCount: number;
  lastActive: number;
  messages: SignalingMessage[];
}

const rooms = new Map<string, RoomData>();

// Cleanup stale rooms older than 1 hour
setInterval(() => {
  const now = Date.now();
  for (const [id, room] of rooms.entries()) {
    if (now - room.lastActive > 3600000) {
      rooms.delete(id);
    }
  }
}, 60000);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '10mb' }));

  // API Routes for Signaling
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', activeRooms: rooms.size, timestamp: Date.now() });
  });

  // Download project source archive
  app.get('/api/download-source', (req, res) => {
    const filePath = path.resolve(__dirname, 'public', 'remotecam-max-source.tar.gz');
    res.download(filePath, 'remotecam-max-source.tar.gz');
  });

  // Download APK binary
  app.get(['/RemoteCamMax.apk', '/api/download-apk'], (req, res) => {
    const apkPath = path.resolve(__dirname, 'public', 'RemoteCamMax.apk');
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.download(apkPath, 'RemoteCamMax.apk');
  });

  // Join / Register room
  app.post('/api/signaling/room', (req, res) => {
    const { roomId, pin, role } = req.body;
    if (!roomId) {
      return res.status(400).json({ error: 'Missing roomId' });
    }

    let room = rooms.get(roomId);
    if (!room) {
      room = {
        roomId,
        pin: pin || '123456',
        hostOnline: role === 'host',
        viewerCount: role === 'viewer' ? 1 : 0,
        lastActive: Date.now(),
        messages: []
      };
      rooms.set(roomId, room);
    } else {
      room.lastActive = Date.now();
      if (role === 'host') room.hostOnline = true;
      if (role === 'viewer') room.viewerCount++;
    }

    res.json({ success: true, room: { roomId: room.roomId, hostOnline: room.hostOnline, viewerCount: room.viewerCount } });
  });

  // Send signaling message (offer, answer, candidate, command)
  app.post('/api/signaling/message', (req, res) => {
    const { roomId, sender, type, payload } = req.body;
    if (!roomId || !type) {
      return res.status(400).json({ error: 'Missing parameters' });
    }

    let room = rooms.get(roomId);
    if (!room) {
      room = {
        roomId,
        pin: '123456',
        hostOnline: false,
        viewerCount: 0,
        lastActive: Date.now(),
        messages: []
      };
      rooms.set(roomId, room);
    }

    const msg: SignalingMessage = {
      id: Math.random().toString(36).substring(2, 9),
      sender: sender || 'anonymous',
      type,
      payload,
      timestamp: Date.now()
    };

    room.messages.push(msg);
    // Keep max 200 messages in buffer
    if (room.messages.length > 200) {
      room.messages.splice(0, room.messages.length - 200);
    }
    room.lastActive = Date.now();

    res.json({ success: true, messageId: msg.id });
  });

  // Poll signaling messages after a specific timestamp or id
  app.get('/api/signaling/messages', (req, res) => {
    const roomId = req.query.roomId as string;
    const since = Number(req.query.since) || 0;
    const sender = req.query.sender as string;

    if (!roomId) {
      return res.status(400).json({ error: 'Missing roomId' });
    }

    const room = rooms.get(roomId);
    if (!room) {
      return res.json({ messages: [], hostOnline: false });
    }

    room.lastActive = Date.now();
    // Return messages newer than 'since', excluding the sender's own messages
    const newMessages = room.messages.filter(
      (m) => m.timestamp > since && (!sender || m.sender !== sender)
    );

    res.json({
      messages: newMessages,
      hostOnline: room.hostOnline,
      viewerCount: room.viewerCount,
      serverTime: Date.now()
    });
  });

  // Reset or clear room
  app.post('/api/signaling/reset', (req, res) => {
    const { roomId } = req.body;
    if (roomId && rooms.has(roomId)) {
      rooms.delete(roomId);
    }
    res.json({ success: true });
  });

  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RemoteCam Max server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
