export type DeviceRole = 'host' | 'viewer' | 'split';

export type NightVisionMode = 'none' | 'infrared' | 'bw' | 'bright';

export interface PairingPayload {
  roomId: string;
  pin: string;
  role: DeviceRole;
  deviceName: string;
  createdAt: number;
}

export type RemoteCommandType =
  | 'SWITCH_CAMERA'
  | 'TOGGLE_TORCH'
  | 'SET_ZOOM'
  | 'TRIGGER_ALARM'
  | 'SET_STEALTH'
  | 'TAKE_SNAPSHOT'
  | 'PING'
  | 'PONG';

export interface RemoteCommand {
  type: RemoteCommandType;
  payload?: any;
  timestamp: number;
  senderId: string;
}

export interface HostTelemetry {
  batteryLevel: number;
  isCharging: boolean;
  motionDetected: boolean;
  audioLevel: number; // 0 to 100
  facingMode: 'environment' | 'user';
  torchSupported: boolean;
  torchOn: boolean;
  stealthMode: boolean;
  resolution: { width: number; height: number };
  fps: number;
  zoomLevel: number;
  activeViewers: number;
  timestamp: number;
}

export interface GalleryItem {
  id: string;
  type: 'photo' | 'video';
  url: string;
  timestamp: number;
  filename: string;
  size?: string;
  duration?: number;
}

export interface SignalingMessage {
  id: string;
  sender: string;
  type: 'offer' | 'answer' | 'candidate' | 'command' | 'telemetry' | 'leave' | 'viewer_ready';
  payload: any;
  timestamp: number;
}
