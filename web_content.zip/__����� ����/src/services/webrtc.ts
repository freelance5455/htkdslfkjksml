import { SignalingMessage, RemoteCommand, HostTelemetry } from '../types';
import { SignalingService } from './signaling';

export interface WebRtcCallbacks {
  onRemoteStream?: (stream: MediaStream) => void;
  onRemoteCommand?: (cmd: RemoteCommand) => void;
  onTelemetry?: (telemetry: HostTelemetry) => void;
  onConnectionStateChange?: (state: RTCPeerConnectionState) => void;
  onLatencyUpdate?: (latencyMs: number) => void;
}

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
  ],
};

export class WebRtcEngine {
  public peerConnection: RTCPeerConnection | null = null;
  public dataChannel: RTCDataChannel | null = null;
  private signaling: SignalingService;
  private callbacks: WebRtcCallbacks;
  private isInitiator: boolean;
  private pingInterval: any = null;
  private lastPingSent = 0;
  private cleanupSignaling: (() => void) | null = null;
  private pendingCandidates: RTCIceCandidateInit[] = [];
  private hasRemoteDescription = false;
  private localStream: MediaStream | null = null;

  constructor(signaling: SignalingService, isInitiator: boolean, callbacks: WebRtcCallbacks) {
    this.signaling = signaling;
    this.isInitiator = isInitiator;
    this.callbacks = callbacks;
  }

  init(localStream?: MediaStream) {
    if (localStream) {
      this.localStream = localStream;
    }

    this.peerConnection = new RTCPeerConnection(RTC_CONFIG);

    // Add local tracks if available
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => {
        if (this.peerConnection) {
          this.peerConnection.addTrack(track, this.localStream!);
        }
      });
    }

    // Handle incoming remote media tracks
    this.peerConnection.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        this.callbacks.onRemoteStream?.(event.streams[0]);
      } else {
        const stream = new MediaStream([event.track]);
        this.callbacks.onRemoteStream?.(stream);
      }
    };

    // Connection state
    this.peerConnection.onconnectionstatechange = () => {
      const state = this.peerConnection?.connectionState || 'closed';
      this.callbacks.onConnectionStateChange?.(state);
    };

    this.peerConnection.oniceconnectionstatechange = () => {
      const iceState = this.peerConnection?.iceConnectionState;
      if (iceState === 'connected' || iceState === 'completed') {
        this.callbacks.onConnectionStateChange?.('connected');
      }
    };

    // ICE Candidate generation
    this.peerConnection.onicecandidate = (event) => {
      if (event.candidate) {
        this.signaling.sendMessage('candidate', event.candidate.toJSON());
      }
    };

    // Data Channel setup
    if (this.isInitiator) {
      // Host creates data channel
      this.dataChannel = this.peerConnection.createDataChannel('remotecam_control', {
        ordered: true,
      });
      this.setupDataChannel(this.dataChannel);
    } else {
      // Monitor receives data channel
      this.peerConnection.ondatachannel = (event) => {
        this.dataChannel = event.channel;
        this.setupDataChannel(this.dataChannel);
      };
    }

    // Listen to signaling messages
    this.cleanupSignaling = this.signaling.onMessage(async (msg) => {
      try {
        if (msg.type === 'viewer_ready' && this.isInitiator) {
          // A viewer just connected and is ready for an offer!
          await this.createOffer();
        } else if (msg.type === 'offer' && !this.isInitiator) {
          await this.handleOffer(msg.payload);
        } else if (msg.type === 'answer' && this.isInitiator) {
          await this.handleAnswer(msg.payload);
        } else if (msg.type === 'candidate' && this.peerConnection) {
          await this.handleCandidate(msg.payload);
        } else if (msg.type === 'command') {
          this.callbacks.onRemoteCommand?.(msg.payload);
        } else if (msg.type === 'telemetry') {
          this.callbacks.onTelemetry?.(msg.payload);
        }
      } catch (err) {
        console.error('Error handling signaling message:', err);
      }
    });

    if (this.isInitiator) {
      // Host announces itself with initial offer
      this.createOffer();
    } else {
      // Viewer notifies host that it's ready to receive an offer!
      this.signaling.sendMessage('viewer_ready', { timestamp: Date.now() });
    }
  }

  private setupDataChannel(channel: RTCDataChannel) {
    channel.onopen = () => {
      if (!this.isInitiator) {
        this.startPingPong();
      }
    };

    channel.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'PING') {
          channel.send(JSON.stringify({ type: 'PONG', timestamp: data.timestamp }));
        } else if (data.type === 'PONG') {
          const rtt = Date.now() - data.timestamp;
          this.callbacks.onLatencyUpdate?.(Math.max(1, Math.round(rtt / 2)));
        } else if (data.type === 'TELEMETRY') {
          this.callbacks.onTelemetry?.(data.payload);
        } else {
          this.callbacks.onRemoteCommand?.(data);
        }
      } catch {}
    };
  }

  private startPingPong() {
    this.pingInterval = setInterval(() => {
      if (this.dataChannel && this.dataChannel.readyState === 'open') {
        this.lastPingSent = Date.now();
        this.dataChannel.send(JSON.stringify({ type: 'PING', timestamp: this.lastPingSent }));
      }
    }, 2000);
  }

  public async createOffer() {
    if (!this.peerConnection) return;
    try {
      const offer = await this.peerConnection.createOffer();
      await this.peerConnection.setLocalDescription(offer);
      this.signaling.sendMessage('offer', offer);
    } catch (err) {
      console.error('Failed to create offer:', err);
    }
  }

  private async handleOffer(offer: RTCSessionDescriptionInit) {
    if (!this.peerConnection) return;
    try {
      await this.peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
      this.hasRemoteDescription = true;
      this.processPendingCandidates();

      const answer = await this.peerConnection.createAnswer();
      await this.peerConnection.setLocalDescription(answer);
      this.signaling.sendMessage('answer', answer);
    } catch (err) {
      console.error('Failed to handle offer:', err);
    }
  }

  private async handleAnswer(answer: RTCSessionDescriptionInit) {
    if (!this.peerConnection) return;
    try {
      if (this.peerConnection.signalingState !== 'stable') {
        await this.peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
        this.hasRemoteDescription = true;
        this.processPendingCandidates();
      }
    } catch (err) {
      console.error('Failed to handle answer:', err);
    }
  }

  private async handleCandidate(candidate: RTCIceCandidateInit) {
    if (!this.peerConnection) return;
    if (!this.hasRemoteDescription) {
      // Queue candidate until remote description is set
      this.pendingCandidates.push(candidate);
      return;
    }
    try {
      await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
    } catch (err) {
      console.error('Failed to add ICE candidate:', err);
    }
  }

  private processPendingCandidates() {
    while (this.pendingCandidates.length > 0) {
      const cand = this.pendingCandidates.shift();
      if (cand && this.peerConnection) {
        this.peerConnection.addIceCandidate(new RTCIceCandidate(cand)).catch(() => {});
      }
    }
  }

  sendCommand(command: RemoteCommand) {
    if (this.dataChannel && this.dataChannel.readyState === 'open') {
      try {
        this.dataChannel.send(JSON.stringify(command));
        return;
      } catch {}
    }
    this.signaling.sendMessage('command', command);
  }

  sendTelemetry(telemetry: HostTelemetry) {
    if (this.dataChannel && this.dataChannel.readyState === 'open') {
      try {
        this.dataChannel.send(JSON.stringify({ type: 'TELEMETRY', payload: telemetry }));
        return;
      } catch {}
    }
    this.signaling.sendMessage('telemetry', telemetry);
  }

  replaceVideoTrack(newTrack: MediaStreamTrack) {
    if (!this.peerConnection) return;
    const senders = this.peerConnection.getSenders();
    const videoSender = senders.find((s) => s.track && s.track.kind === 'video');
    if (videoSender) {
      videoSender.replaceTrack(newTrack).catch((e) => console.error('Failed to replace track:', e));
    }
  }

  destroy() {
    if (this.pingInterval) clearInterval(this.pingInterval);
    if (this.cleanupSignaling) this.cleanupSignaling();
    if (this.dataChannel) {
      try {
        this.dataChannel.close();
      } catch {}
      this.dataChannel = null;
    }
    if (this.peerConnection) {
      try {
        this.peerConnection.close();
      } catch {}
      this.peerConnection = null;
    }
    this.hasRemoteDescription = false;
    this.pendingCandidates = [];
  }
}
