export interface MotionResult {
  score: number; // 0 to 100
  hasMotion: boolean;
  intensity: number;
}

export class MotionDetector {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D | null;
  private prevFrameData: Uint8ClampedArray | null = null;
  private width = 64;
  private height = 48;
  private lastTriggerTime = 0;

  constructor() {
    this.canvas = document.createElement('canvas');
    this.canvas.width = this.width;
    this.canvas.height = this.height;
    this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
  }

  detect(videoElement: HTMLVideoElement, sensitivity: number): MotionResult {
    if (!this.ctx || !videoElement || videoElement.readyState < 2) {
      return { score: 0, hasMotion: false, intensity: 0 };
    }

    try {
      this.ctx.drawImage(videoElement, 0, 0, this.width, this.height);
      const currentFrame = this.ctx.getImageData(0, 0, this.width, this.height).data;

      if (!this.prevFrameData) {
        this.prevFrameData = new Uint8ClampedArray(currentFrame);
        return { score: 0, hasMotion: false, intensity: 0 };
      }

      let diffPixels = 0;
      const totalPixels = this.width * this.height;
      // Pixel diff threshold inversely proportional to sensitivity (sensitivity 1..10)
      const diffThreshold = Math.max(15, 45 - sensitivity * 3);

      for (let i = 0; i < currentFrame.length; i += 4) {
        const rDiff = Math.abs(currentFrame[i] - this.prevFrameData[i]);
        const gDiff = Math.abs(currentFrame[i + 1] - this.prevFrameData[i + 1]);
        const bDiff = Math.abs(currentFrame[i + 2] - this.prevFrameData[i + 2]);
        const avgDiff = (rDiff + gDiff + bDiff) / 3;

        if (avgDiff > diffThreshold) {
          diffPixels++;
        }
      }

      // Update previous frame
      this.prevFrameData.set(currentFrame);

      const percentDiff = (diffPixels / totalPixels) * 100;
      const score = Math.min(100, Math.round(percentDiff * 4));

      // Trigger condition: score > trigger threshold (sensitivity 1 -> threshold 15, sensitivity 10 -> threshold 3)
      const triggerThreshold = Math.max(2, 14 - sensitivity);
      const hasMotion = score >= triggerThreshold;

      const now = Date.now();
      const isNewDetection = hasMotion && now - this.lastTriggerTime > 1500;
      if (hasMotion) {
        this.lastTriggerTime = now;
      }

      return {
        score,
        hasMotion: isNewDetection || hasMotion,
        intensity: Math.min(100, Math.round((score / 25) * 100))
      };
    } catch {
      return { score: 0, hasMotion: false, intensity: 0 };
    }
  }

  reset() {
    this.prevFrameData = null;
  }
}
