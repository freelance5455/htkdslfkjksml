// Audio Alerts Synthesizer using Web Audio API

class AudioAlertService {
  private ctx: AudioContext | null = null;
  private sirenOsc1: OscillatorNode | null = null;
  private sirenOsc2: OscillatorNode | null = null;
  private isSirenActive = false;

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  // Play Camera Shutter Sound
  playShutterSound() {
    try {
      const ctx = this.getContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.5, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.09);
    } catch {
      // Audio not permitted or supported yet
    }
  }

  // Play Motion Alert Ping
  playMotionAlert() {
    try {
      const ctx = this.getContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.setValueAtTime(1320, ctx.currentTime + 0.08);
      osc.frequency.setValueAtTime(1760, ctx.currentTime + 0.16);

      gain.gain.setValueAtTime(0.4, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.36);
    } catch {
      // ignore
    }
  }

  // Play Walkie-Talkie Click/Squelch
  playWalkieTalkieChime(start = true) {
    try {
      const ctx = this.getContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'square';
      osc.frequency.setValueAtTime(start ? 600 : 400, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(start ? 900 : 300, ctx.currentTime + 0.06);

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.07);
    } catch {
      // ignore
    }
  }

  // Start Siren Alarm
  startSiren(durationMs = 4000) {
    if (this.isSirenActive) return;
    try {
      const ctx = this.getContext();
      this.isSirenActive = true;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      gain.gain.setValueAtTime(0.6, ctx.currentTime);

      // Sweep frequency up and down
      const startTime = ctx.currentTime;
      const cycleTime = 0.6;
      const cycles = Math.ceil((durationMs / 1000) / cycleTime);

      for (let i = 0; i < cycles; i++) {
        const t = startTime + i * cycleTime;
        osc.frequency.setValueAtTime(500, t);
        osc.frequency.linearRampToValueAtTime(1100, t + cycleTime / 2);
        osc.frequency.linearRampToValueAtTime(500, t + cycleTime);
      }

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + durationMs / 1000);

      this.sirenOsc1 = osc;

      setTimeout(() => {
        this.stopSiren();
      }, durationMs);
    } catch {
      this.isSirenActive = false;
    }
  }

  // Stop Siren
  stopSiren() {
    if (this.sirenOsc1) {
      try {
        this.sirenOsc1.stop();
        this.sirenOsc1.disconnect();
      } catch {}
      this.sirenOsc1 = null;
    }
    this.isSirenActive = false;
  }
}

export const audioAlerts = new AudioAlertService();
