import { GalleryItem } from '../types';

const GALLERY_STORAGE_KEY = 'remotecam_max_gallery_items';
const SETTINGS_STORAGE_KEY = 'remotecam_max_settings';
const RECENT_ROOMS_KEY = 'remotecam_max_recent_rooms';

export interface UserSettings {
  lang: 'he' | 'en';
  soundAlerts: boolean;
  motionSensitivity: number; // 1 to 10
  audioDetectionThreshold: number; // 0 to 100
  defaultResolution: '1080p' | '720p' | '480p';
  theme: 'dark' | 'oled';
}

const defaultSettings: UserSettings = {
  lang: 'he',
  soundAlerts: true,
  motionSensitivity: 5,
  audioDetectionThreshold: 45,
  defaultResolution: '720p',
  theme: 'dark'
};

export const storageService = {
  getSettings(): UserSettings {
    try {
      const data = localStorage.getItem(SETTINGS_STORAGE_KEY);
      return data ? { ...defaultSettings, ...JSON.parse(data) } : defaultSettings;
    } catch {
      return defaultSettings;
    }
  },

  saveSettings(settings: Partial<UserSettings>): UserSettings {
    const current = this.getSettings();
    const updated = { ...current, ...settings };
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(updated));
    } catch {}
    return updated;
  },

  getGalleryItems(): GalleryItem[] {
    try {
      const data = localStorage.getItem(GALLERY_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveGalleryItem(item: GalleryItem) {
    try {
      const items = this.getGalleryItems();
      items.unshift(item);
      // Keep up to 30 items
      const trimmed = items.slice(0, 30);
      localStorage.setItem(GALLERY_STORAGE_KEY, JSON.stringify(trimmed));
    } catch (e) {
      console.warn('Storage quota exceeded for gallery items:', e);
    }
  },

  deleteGalleryItem(id: string) {
    try {
      const items = this.getGalleryItems().filter((i) => i.id !== id);
      localStorage.setItem(GALLERY_STORAGE_KEY, JSON.stringify(items));
    } catch {}
  },

  clearGallery() {
    try {
      localStorage.removeItem(GALLERY_STORAGE_KEY);
    } catch {}
  },

  getRecentRooms(): string[] {
    try {
      const data = localStorage.getItem(RECENT_ROOMS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  addRecentRoom(roomId: string) {
    if (!roomId) return;
    try {
      const rooms = this.getRecentRooms().filter((r) => r !== roomId);
      rooms.unshift(roomId);
      localStorage.setItem(RECENT_ROOMS_KEY, JSON.stringify(rooms.slice(0, 5)));
    } catch {}
  }
};
