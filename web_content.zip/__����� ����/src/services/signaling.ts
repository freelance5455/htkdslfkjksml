import { SignalingMessage } from '../types';

export class SignalingService {
  private roomId: string;
  private senderId: string;
  private broadcastChannel: BroadcastChannel | null = null;
  private listeners: Set<(msg: SignalingMessage) => void> = new Set();
  private pollInterval: any = null;
  private lastServerTimestamp = 0;
  private processedMessageIds = new Set<string>();
  private internalListener: ((e: any) => void) | null = null;

  constructor(roomId: string, senderId: string) {
    this.roomId = roomId;
    this.senderId = senderId;
    this.initInternalBus();
    this.initBroadcastChannel();
    this.initServerSignaling();
  }

  // 1. Same-window instant EventBus (for DualView side-by-side mode)
  private initInternalBus() {
    if (typeof window !== 'undefined') {
      this.internalListener = (event: CustomEvent) => {
        const msg = event.detail as SignalingMessage;
        if (msg && msg.sender !== this.senderId && !this.processedMessageIds.has(msg.id)) {
          this.processedMessageIds.add(msg.id);
          this.notifyListeners(msg);
        }
      };
      window.addEventListener(`remotecam_bus_${this.roomId}`, this.internalListener as EventListener);
    }
  }

  // 2. Cross-tab BroadcastChannel
  private initBroadcastChannel() {
    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        this.broadcastChannel = new BroadcastChannel(`remotecam_${this.roomId}`);
        this.broadcastChannel.onmessage = (event) => {
          const msg = event.data as SignalingMessage;
          if (msg && msg.sender !== this.senderId && !this.processedMessageIds.has(msg.id)) {
            this.processedMessageIds.add(msg.id);
            this.notifyListeners(msg);
          }
        };
      }
    } catch (e) {
      console.warn('BroadcastChannel not supported:', e);
    }
  }

  // 3. Cross-device Server Polling
  private initServerSignaling() {
    fetch('/api/signaling/room', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ roomId: this.roomId, role: this.senderId.startsWith('host') ? 'host' : 'viewer' }),
    }).catch(() => {});

    this.pollInterval = setInterval(async () => {
      try {
        const res = await fetch(
          `/api/signaling/messages?roomId=${encodeURIComponent(this.roomId)}&since=${this.lastServerTimestamp}&sender=${encodeURIComponent(this.senderId)}`
        );
        if (!res.ok) return;
        const data = await res.json();
        if (data.serverTime) {
          this.lastServerTimestamp = Math.max(this.lastServerTimestamp, data.serverTime - 100);
        }

        if (Array.isArray(data.messages)) {
          for (const msg of data.messages) {
            if (!this.processedMessageIds.has(msg.id)) {
              this.processedMessageIds.add(msg.id);
              this.notifyListeners(msg);
            }
          }
        }
      } catch {}
    }, 700);
  }

  sendMessage(type: SignalingMessage['type'], payload: any) {
    const msg: SignalingMessage = {
      id: Math.random().toString(36).substring(2, 9) + Date.now().toString(36),
      sender: this.senderId,
      type,
      payload,
      timestamp: Date.now(),
    };

    this.processedMessageIds.add(msg.id);

    // A. Dispatch to same window (DualView)
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(`remotecam_bus_${this.roomId}`, { detail: msg }));
    }

    // B. Dispatch to other browser tabs
    if (this.broadcastChannel) {
      try {
        this.broadcastChannel.postMessage(msg);
      } catch {}
    }

    // C. Dispatch to server for other devices / network
    fetch('/api/signaling/message', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        roomId: this.roomId,
        sender: this.senderId,
        type: msg.type,
        payload: msg.payload,
      }),
    }).catch(() => {});
  }

  onMessage(callback: (msg: SignalingMessage) => void) {
    this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notifyListeners(msg: SignalingMessage) {
    this.listeners.forEach((cb) => {
      try {
        cb(msg);
      } catch (e) {
        console.error('Error in signaling listener:', e);
      }
    });
  }

  destroy() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    if (this.internalListener && typeof window !== 'undefined') {
      window.removeEventListener(`remotecam_bus_${this.roomId}`, this.internalListener as EventListener);
      this.internalListener = null;
    }
    if (this.broadcastChannel) {
      try {
        this.broadcastChannel.close();
      } catch {}
      this.broadcastChannel = null;
    }
    this.listeners.clear();
  }
}
