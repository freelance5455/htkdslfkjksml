/**
 * Creates a synthetic live camera MediaStream from a canvas.
 * Used when no webcam is connected, permissions denied, or in demo test mode.
 */
export function createSimulatedCameraStream(label = 'CAM-01 [LIVING ROOM]'): {
  stream: MediaStream;
  stop: () => void;
} {
  const canvas = document.createElement('canvas');
  canvas.width = 1280;
  canvas.height = 720;
  const ctx = canvas.getContext('2d');

  let animFrameId: number;
  let ballX = 200;
  let ballY = 250;
  let dx = 4;
  let dy = 3;
  let angle = 0;

  const draw = () => {
    if (!ctx) return;

    // Dark security room background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Grid floor perspective
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 60) {
      ctx.beginPath();
      ctx.moveTo(x, 400);
      ctx.lineTo(x * 1.5 - 300, canvas.height);
      ctx.stroke();
    }
    for (let y = 400; y < canvas.height; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Room wall furniture representation
    // Window with moon
    ctx.fillStyle = '#1e1b4b';
    ctx.fillRect(800, 100, 320, 240);
    ctx.strokeStyle = '#312e81';
    ctx.lineWidth = 4;
    ctx.strokeRect(800, 100, 320, 240);

    // Stars & Moon
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(1040, 170, 30, 0, Math.PI * 2);
    ctx.fill();

    // Crib or Desk silhouette
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(150, 340, 350, 160);
    ctx.fillStyle = '#334155';
    ctx.fillRect(160, 330, 330, 20);

    // Moving pet/baby/motion object
    ballX += dx;
    ballY += dy;
    if (ballX < 180 || ballX > 450) dx = -dx;
    if (ballY < 280 || ballY > 400) dy = -dy;

    // Breathing / moving entity
    angle += 0.05;
    const pulse = Math.sin(angle) * 8;

    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.arc(ballX, ballY, 32 + pulse, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#0284c7';
    ctx.beginPath();
    ctx.arc(ballX + 8, ballY - 6, 8, 0, Math.PI * 2);
    ctx.arc(ballX - 8, ballY - 6, 8, 0, Math.PI * 2);
    ctx.fill();

    // Camera OSD (On-Screen Display)
    ctx.fillStyle = '#22c55e';
    ctx.font = 'bold 22px monospace';
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0] + '.' + String(now.getMilliseconds()).padStart(3, '0').slice(0, 2);
    const dateStr = now.toISOString().split('T')[0];

    ctx.fillText(`● REC [LIVE]  ${label}`, 40, 50);
    ctx.fillText(`${dateStr}  ${timeStr}`, 40, 85);
    ctx.fillText(`FPS: 30.0   RES: 1280x720   SIG: 98%`, 40, 120);

    // Crosshairs in center
    ctx.strokeStyle = 'rgba(34, 197, 94, 0.4)';
    ctx.lineWidth = 1.5;
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    ctx.beginPath();
    ctx.moveTo(cx - 30, cy);
    ctx.lineTo(cx + 30, cy);
    ctx.moveTo(cx, cy - 30);
    ctx.lineTo(cx, cy + 30);
    ctx.stroke();

    // Subtle noise grain
    const imgData = ctx.getImageData(0, 0, 100, 100);
    for (let i = 0; i < imgData.data.length; i += 16) {
      const v = (Math.random() - 0.5) * 20;
      imgData.data[i] += v;
      imgData.data[i + 1] += v;
      imgData.data[i + 2] += v;
    }

    animFrameId = requestAnimationFrame(draw);
  };

  draw();

  const canvasStream = canvas.captureStream(30);

  // Synthetic low hum audio track
  let audioContext: AudioContext | null = null;
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    audioContext = new AudioCtx();
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    const dest = audioContext.createMediaStreamDestination();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(120, audioContext.currentTime);
    gain.gain.setValueAtTime(0.005, audioContext.currentTime);

    osc.connect(gain);
    gain.connect(dest);
    osc.start();

    const audioTrack = dest.stream.getAudioTracks()[0];
    if (audioTrack) {
      canvasStream.addTrack(audioTrack);
    }
  } catch {}

  return {
    stream: canvasStream,
    stop: () => {
      cancelAnimationFrame(animFrameId);
      canvasStream.getTracks().forEach((t) => t.stop());
      if (audioContext && audioContext.state !== 'closed') {
        audioContext.close().catch(() => {});
      }
    }
  };
}
