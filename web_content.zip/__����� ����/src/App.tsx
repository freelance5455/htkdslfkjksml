/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { DeviceRole, GalleryItem } from './types';
import { Navbar } from './components/Navbar';
import { CameraHostScreen } from './components/CameraHostScreen';
import { MonitorScreen } from './components/MonitorScreen';
import { DualViewScreen } from './components/DualViewScreen';
import { QrScannerModal } from './components/QrScannerModal';
import { GalleryModal } from './components/GalleryModal';
import { storageService } from './services/storage';

export default function App() {
  const [role, setRole] = useState<DeviceRole>('split');
  const [lang, setLang] = useState<'he' | 'en'>('he');
  const [roomId, setRoomId] = useState<string>('');
  const [pin, setPin] = useState<string>('');
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);
  const [showGallery, setShowGallery] = useState(false);
  const [showConnectModal, setShowConnectModal] = useState(false);

  // Initialize Room ID, PIN, and parse URL query params
  useEffect(() => {
    // Generate clean 6-digit room and pin if not provided
    const randomRoom = Math.floor(100000 + Math.random() * 900000).toString();
    const randomPin = Math.floor(100000 + Math.random() * 900000).toString();

    try {
      const params = new URLSearchParams(window.location.search);
      const urlRoom = params.get('room');
      const urlPin = params.get('pin');
      const urlRole = params.get('role') as DeviceRole | null;

      if (urlRoom) {
        setRoomId(urlRoom);
        setPin(urlPin || randomPin);
        if (urlRole && ['host', 'viewer', 'split'].includes(urlRole)) {
          setRole(urlRole);
        } else {
          setRole('viewer');
        }
      } else {
        setRoomId(randomRoom);
        setPin(randomPin);
      }
    } catch {
      setRoomId(randomRoom);
      setPin(randomPin);
    }

    // Load gallery items & settings
    const savedSettings = storageService.getSettings();
    setLang(savedSettings.lang || 'he');
    setGalleryItems(storageService.getGalleryItems());
  }, []);

  // Sync RTL / LTR document direction
  useEffect(() => {
    document.documentElement.setAttribute('dir', lang === 'he' ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', lang);
  }, [lang]);

  const handleToggleLang = () => {
    const nextLang = lang === 'he' ? 'en' : 'he';
    setLang(nextLang);
    storageService.saveSettings({ lang: nextLang });
  };

  const handleConnectRoom = (newRoomId: string, newPin: string) => {
    setRoomId(newRoomId);
    setPin(newPin);
    setRole('viewer');
    setShowConnectModal(false);
  };

  const refreshGallery = () => {
    setGalleryItems(storageService.getGalleryItems());
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Top Navigation */}
      <Navbar
        currentRole={role}
        onChangeRole={setRole}
        lang={lang}
        onToggleLang={handleToggleLang}
        onOpenGallery={() => {
          refreshGallery();
          setShowGallery(true);
        }}
        onOpenConnectModal={() => setShowConnectModal(true)}
        galleryCount={galleryItems.length}
      />

      {/* Main View Area */}
      <main className="flex-1 relative overflow-hidden">
        {roomId && (
          <>
            {role === 'split' && (
              <DualViewScreen
                roomId={roomId}
                pin={pin}
                lang={lang}
              />
            )}

            {role === 'host' && (
              <CameraHostScreen
                roomId={roomId}
                pin={pin}
                lang={lang}
                onSwitchMode={setRole}
              />
            )}

            {role === 'viewer' && (
              <MonitorScreen
                roomId={roomId}
                pin={pin}
                lang={lang}
                onOpenConnectModal={() => setShowConnectModal(true)}
                onOpenGallery={() => {
                  refreshGallery();
                  setShowGallery(true);
                }}
              />
            )}
          </>
        )}
      </main>

      {/* Modals */}
      {showConnectModal && (
        <QrScannerModal
          lang={lang}
          currentRoomId={roomId}
          onConnect={handleConnectRoom}
          onClose={() => setShowConnectModal(false)}
        />
      )}

      {showGallery && (
        <GalleryModal
          items={galleryItems}
          lang={lang}
          onClose={() => setShowGallery(false)}
          onRefresh={refreshGallery}
        />
      )}
    </div>
  );
}
