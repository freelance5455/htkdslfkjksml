import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Camera,
  RotateCcw,
  Flashlight,
  Volume2,
  VolumeX,
  Eye,
  EyeOff,
  Battery,
  BatteryCharging,
  QrCode,
  ShieldAlert,
  Activity,
  Users,
  Sliders,
  Sparkles,
} from 'lucide-react';
import { translations } from '../translations';
import { SignalingService } from '../services/signaling';
import { WebRtcEngine } from '../services/webrtc';
import { MotionDetector } from '../services/motionDetector';
import { audioAlerts } from '../services/audioAlerts';
import { createSimulatedCameraStream } from '../services/simulationStream';
import { PairingDrawer } from './PairingDrawer';
import { HostTelemetry, RemoteCommand } from '../types';

interface CameraHostScreenProps {
  roomId: string;
  pin: string;
  lang: 'he' | 'en';
  onSwitchMode?: (mode: 'host' | 'viewer' | 'split') => void;
  isSplitView?: boolean;
  onStreamReady?: (stream: MediaStream) => void;
}

export const CameraHostScreen: React.FC<CameraHostScreenProps> = ({
  roomId,
  pin,
  lang,
  isSplitView = false,
  onStreamReady,
}) => {
  const t = translations[lang];

  // Camera & Stream State
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [resolution, setResolution] = useState<'1080p' | '720p' | '480p'>('720p');
  const [isTorchOn, setIsTorchOn] = useState(false);
  const [isTorchSupported, setIsTorchSupported] = useState(false);
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [isSimulated, setIsSimulated] = useState(false);

  // Stealth & Feature States
  const [isStealth, setIsStealth] = useState(false);
  const [stealthTaps, setStealthTaps] = useState(0);
  const [motionDetectionEnabled, setMotionDetectionEnabled] = useState(true);
  const [motionSensitivity, setMotionSensitivity] = useState(6);
  const [motionAlertActive, setMotionAlertActive] = useState(false);

  // Status & Telemetry
  const [audioLevel, setAudioLevel] = useState(0);
  const [batteryLevel, setBatteryLevel] = useState(100);
  const [isCharging, setIsCharging] = useState(false);
  const [connectedViewers, setConnectedViewers] = useState(0);
  const [showPairingModal, setShowPairingModal] = useState(false);
  const [alarmActive, setAlarmActive] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Refs
  const videoRef = useRef<HTMLVideoElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const simStopRef = useRef<(() => void) | null>(null);
  const webRtcRef = useRef<WebRtcEngine | null>(null);
  const signalingRef = useRef<SignalingService | null>(null);
  const motionDetectorRef = useRef<MotionDetector>(new MotionDetector());
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioAnalyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Keep digital clock updated
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Monitor Battery Status
  useEffect(() => {
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        setBatteryLevel(Math.round(battery.level * 100));
        setIsCharging(battery.charging);

        battery.addEventListener('levelchange', () => {
          setBatteryLevel(Math.round(battery.level * 100));
        });
        battery.addEventListener('chargingchange', () => {
          setIsCharging(battery.charging);
        });
      }).catch(() => {});
    }
  }, []);

  // Initialize Camera Stream
  const startCamera = useCallback(async (facing: 'user' | 'environment', res: '1080p' | '720p' | '480p') => {
    // Stop previous streams
    if (simStopRef.current) {
      simStopRef.current();
      simStopRef.current = null;
    }
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
    }

    const resMap = {
      '1080p': { width: { ideal: 1920 }, height: { ideal: 1080 } },
      '720p': { width: { ideal: 1280 }, height: { ideal: 720 } },
      '480p': { width: { ideal: 640 }, height: { ideal: 480 } },
    };

    let stream: MediaStream | null = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facing,
          ...resMap[res],
        },
        audio: true,
      });
      setIsSimulated(false);
    } catch (err) {
      console.warn('Real camera not available or denied, starting simulated stream:', err);
      const sim = createSimulatedCameraStream('CAM-01 [HOST]');
      stream = sim.stream;
      simStopRef.current = sim.stop;
      setIsSimulated(true);
    }

    localStreamRef.current = stream;
    if (videoRef.current) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(() => {});
    }

    if (onStreamReady && stream) {
      onStreamReady(stream);
    }

    // Check torch capability
    const videoTrack = stream.getVideoTracks()[0];
    if (videoTrack) {
      const caps = (videoTrack.getCapabilities && videoTrack.getCapabilities()) || {};
      setIsTorchSupported(Boolean((caps as any).torch));
    }

    // Setup Web Audio Analyser for volume metering
    try {
      const audioTrack = stream.getAudioTracks()[0];
      if (audioTrack) {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtx();
        const source = ctx.createMediaStreamSource(new MediaStream([audioTrack]));
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 64;
        source.connect(analyser);

        audioContextRef.current = ctx;
        audioAnalyserRef.current = analyser;
      }
    } catch {}

    // Update WebRTC track if connection is already established
    if (webRtcRef.current && videoTrack) {
      webRtcRef.current.replaceVideoTrack(videoTrack);
    }
  }, []);

  // Handle Remote Commands from Monitor
  const handleRemoteCommand = useCallback((cmd: RemoteCommand) => {
    switch (cmd.type) {
      case 'SWITCH_CAMERA': {
        setFacingMode((prev) => {
          const next = prev === 'user' ? 'environment' : 'user';
          startCamera(next, resolution);
          return next;
        });
        break;
      }
      case 'TOGGLE_TORCH': {
        const videoTrack = localStreamRef.current?.getVideoTracks()[0];
        if (videoTrack) {
          const nextTorch = !isTorchOn;
          (videoTrack as any).applyConstraints?.({
            advanced: [{ torch: nextTorch }],
          }).catch(() => {});
          setIsTorchOn(nextTorch);
        }
        break;
      }
      case 'TRIGGER_ALARM': {
        setAlarmActive(true);
        audioAlerts.startSiren(4500);
        setTimeout(() => setAlarmActive(false), 4500);
        break;
      }
      case 'SET_STEALTH': {
        setIsStealth(Boolean(cmd.payload?.enabled ?? !isStealth));
        break;
      }
      case 'TAKE_SNAPSHOT': {
        audioAlerts.playShutterSound();
        break;
      }
    }
  }, [isTorchOn, isStealth, resolution, startCamera]);

  // WebRTC & Signaling Setup
  useEffect(() => {
    const senderId = `host_${Math.random().toString(36).substring(2, 7)}`;
    const signaling = new SignalingService(roomId, senderId);
    signalingRef.current = signaling;

    const webrtc = new WebRtcEngine(signaling, true, {
      onRemoteCommand: handleRemoteCommand,
      onConnectionStateChange: (state) => {
        if (state === 'connected') {
          setConnectedViewers((c) => Math.max(1, c + 1));
        } else if (state === 'disconnected' || state === 'failed') {
          setConnectedViewers((c) => Math.max(0, c - 1));
        }
      },
      onRemoteStream: (stream) => {
        // Reverse audio from viewer walkie-talkie!
        const audio = new Audio();
        audio.srcObject = stream;
        audio.play().catch(() => {});
      },
    });
    webRtcRef.current = webrtc;

    // Start camera then init webrtc
    startCamera(facingMode, resolution).then(() => {
      if (localStreamRef.current) {
        webrtc.init(localStreamRef.current);
      }
    });

    return () => {
      if (simStopRef.current) simStopRef.current();
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      webrtc.destroy();
      signaling.destroy();
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close().catch(() => {});
      }
    };
  }, [roomId]);

  // Motion Detection & Audio Metering Loop
  useEffect(() => {
    let isRunning = true;
    const dataArray = new Uint8Array(32);

    const checkFrame = () => {
      if (!isRunning) return;

      // 1. Audio meter
      if (audioAnalyserRef.current && !isAudioMuted) {
        audioAnalyserRef.current.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
        const avg = Math.min(100, Math.round((sum / dataArray.length / 255) * 100));
        setAudioLevel(avg);
      }

      // 2. Motion Detection
      if (motionDetectionEnabled && videoRef.current) {
        const result = motionDetectorRef.current.detect(videoRef.current, motionSensitivity);
        if (result.hasMotion) {
          setMotionAlertActive(true);
          audioAlerts.playMotionAlert();
          setTimeout(() => setMotionAlertActive(false), 2000);
        }
      }

      // 3. Broadcast Telemetry every 1.5s
      animFrameRef.current = requestAnimationFrame(checkFrame);
    };

    animFrameRef.current = requestAnimationFrame(checkFrame);

    // Periodic telemetry update to viewer
    const telemetryInterval = setInterval(() => {
      if (webRtcRef.current) {
        const telemetry: HostTelemetry = {
          batteryLevel,
          isCharging,
          motionDetected: motionAlertActive,
          audioLevel,
          facingMode,
          torchSupported: isTorchSupported,
          torchOn: isTorchOn,
          stealthMode: isStealth,
          resolution: resolution === '1080p' ? { width: 1920, height: 1080 } : resolution === '720p' ? { width: 1280, height: 720 } : { width: 640, height: 480 },
          fps: 30,
          zoomLevel: 1,
          activeViewers: connectedViewers,
          timestamp: Date.now(),
        };
        webRtcRef.current.sendTelemetry(telemetry);
      }
    }, 1500);

    return () => {
      isRunning = false;
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      clearInterval(telemetryInterval);
    };
  }, [
    isAudioMuted,
    motionDetectionEnabled,
    motionSensitivity,
    batteryLevel,
    isCharging,
    motionAlertActive,
    audioLevel,
    facingMode,
    isTorchSupported,
    isTorchOn,
    isStealth,
    resolution,
    connectedViewers,
  ]);

  // Torch Toggle
  const handleToggleTorch = () => {
    const videoTrack = localStreamRef.current?.getVideoTracks()[0];
    if (videoTrack) {
      const nextTorch = !isTorchOn;
      (videoTrack as any).applyConstraints?.({
        advanced: [{ torch: nextTorch }],
      }).catch(() => {});
      setIsTorchOn(nextTorch);
    }
  };

  // Flip Camera
  const handleSwitchCamera = () => {
    const nextFacing = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(nextFacing);
    startCamera(nextFacing, resolution);
  };

  // Triple-tap to exit stealth
  const handleStealthTap = () => {
    setStealthTaps((prev) => {
      const next = prev + 1;
      if (next >= 3) {
        setIsStealth(false);
        return 0;
      }
      return next;
    });
  };

  return (
    <div className={`relative w-full h-full bg-slate-950 flex flex-col overflow-hidden select-none ${isSplitView ? 'border-r border-slate-800' : ''}`}>
      {/* STEALTH MODE OVERLAY */}
      {isStealth && (
        <div
          onClick={handleStealthTap}
          className="absolute inset-0 z-50 bg-black flex flex-col items-center justify-center cursor-pointer transition-opacity"
        >
          <div className="text-center opacity-40 hover:opacity-80 transition p-6">
            <span className="font-mono text-6xl text-slate-600 font-extralight block mb-2">
              {currentTime.toTimeString().split(' ')[0]}
            </span>
            <div className="flex items-center justify-center gap-2 text-xs text-slate-600">
              {isCharging ? <BatteryCharging className="w-4 h-4 text-emerald-500" /> : <Battery className="w-4 h-4" />}
              <span>{batteryLevel}%</span>
              <span>•</span>
              <span className="text-emerald-500">REC ●</span>
            </div>
            <p className="text-[11px] text-slate-700 mt-6 tracking-wider">
              {t.exitStealth} ({stealthTaps}/3)
            </p>
          </div>
        </div>
      )}

      {/* TOP STATUS BAR */}
      <div className="absolute top-0 inset-x-0 z-20 bg-gradient-to-b from-black/80 via-black/40 to-transparent p-4 flex items-center justify-between text-white pointer-events-auto">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            LIVE HOST
          </div>

          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900/80 text-slate-300 border border-slate-800 text-xs">
            <Users className="w-3.5 h-3.5 text-emerald-400" />
            <span>{connectedViewers}</span>
          </div>

          {isSimulated && (
            <span className="hidden sm:inline-block px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px]">
              DEMO FEED
            </span>
          )}
        </div>

        {/* Pairing code & battery right pill */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowPairingModal(true)}
            className="flex items-center gap-1.5 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full text-xs font-semibold shadow-lg shadow-emerald-950 transition"
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>{pin}</span>
          </button>

          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-slate-900/80 text-slate-300 text-xs font-mono">
            {isCharging ? (
              <BatteryCharging className="w-4 h-4 text-emerald-400" />
            ) : (
              <Battery className="w-4 h-4" />
            )}
            <span>{batteryLevel}%</span>
          </div>
        </div>
      </div>

      {/* ALARM / MOTION WARNING BANNER */}
      {alarmActive && (
        <div className="absolute top-16 inset-x-4 z-30 bg-rose-600 text-white p-3 rounded-2xl flex items-center justify-center gap-3 shadow-2xl animate-bounce">
          <ShieldAlert className="w-6 h-6 animate-spin" />
          <span className="font-bold text-sm tracking-wide">
            {lang === 'he' ? 'אזעקה הופעלה מרחוק!' : 'REMOTE ALARM TRIGGERED!'}
          </span>
        </div>
      )}

      {motionAlertActive && !alarmActive && (
        <div className="absolute top-16 inset-x-4 z-30 bg-amber-500/90 text-slate-950 px-4 py-2 rounded-2xl flex items-center justify-center gap-2 font-bold text-xs shadow-lg backdrop-blur">
          <Activity className="w-4 h-4 animate-pulse" />
          <span>{t.motionDetected}</span>
        </div>
      )}

      {/* VIDEO PREVIEW CONTAINER */}
      <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden">
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          className="w-full h-full object-cover"
        />

        {/* OSD Crosshair & Corner Marks */}
        <div className="absolute inset-4 pointer-events-none border border-emerald-500/20 rounded-2xl flex flex-col justify-between p-3">
          <div className="flex justify-between items-start">
            <div className="font-mono text-[11px] text-emerald-400/80 bg-black/40 px-2 py-0.5 rounded">
              CAM-HOST #{roomId.slice(0, 4)} • {resolution}
            </div>
            <div className="font-mono text-[11px] text-emerald-400/80 bg-black/40 px-2 py-0.5 rounded">
              {currentTime.toTimeString().split(' ')[0]}
            </div>
          </div>

          {/* Sound audio visualizer bar */}
          <div className="w-28 bg-black/60 rounded-full h-2 p-0.5 border border-slate-700 self-end">
            <div
              className="h-full rounded-full bg-emerald-500 transition-all duration-75"
              style={{ width: `${audioLevel}%` }}
            />
          </div>
        </div>
      </div>

      {/* BOTTOM CONTROLS DOCK */}
      <div className="z-20 bg-slate-900/95 border-t border-slate-800 p-3 sm:p-4 backdrop-blur-md">
        <div className="flex items-center justify-around gap-2 max-w-lg mx-auto">
          {/* Flip Camera */}
          <button
            onClick={handleSwitchCamera}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-white transition p-2 rounded-xl hover:bg-slate-800"
            title={t.switchCamera}
          >
            <div className="p-2.5 bg-slate-800 rounded-xl text-slate-200 shadow">
              <RotateCcw className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium">
              {facingMode === 'user' ? (lang === 'he' ? 'קדמית' : 'Front') : (lang === 'he' ? 'אחורית' : 'Rear')}
            </span>
          </button>

          {/* Torch / Flashlight */}
          <button
            onClick={handleToggleTorch}
            className={`flex flex-col items-center gap-1 transition p-2 rounded-xl hover:bg-slate-800 ${
              isTorchOn ? 'text-amber-400' : 'text-slate-300 hover:text-white'
            }`}
            title={t.toggleTorch}
          >
            <div
              className={`p-2.5 rounded-xl shadow transition ${
                isTorchOn ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-slate-800 text-slate-200'
              }`}
            >
              <Flashlight className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium">{t.toggleTorch}</span>
          </button>

          {/* Stealth Mode Toggle */}
          <button
            onClick={() => setIsStealth(true)}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-white transition p-2 rounded-xl hover:bg-slate-800"
            title={t.stealthMode}
          >
            <div className="p-2.5 bg-slate-800 rounded-xl text-slate-200 shadow">
              <EyeOff className="w-5 h-5 text-indigo-400" />
            </div>
            <span className="text-[10px] font-medium">{lang === 'he' ? 'מסך חשוך' : 'Stealth'}</span>
          </button>

          {/* Audio Mute */}
          <button
            onClick={() => setIsAudioMuted(!isAudioMuted)}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-white transition p-2 rounded-xl hover:bg-slate-800"
          >
            <div className="p-2.5 bg-slate-800 rounded-xl text-slate-200 shadow">
              {isAudioMuted ? <VolumeX className="w-5 h-5 text-rose-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
            </div>
            <span className="text-[10px] font-medium">
              {isAudioMuted ? (lang === 'he' ? 'מושתק' : 'Muted') : (lang === 'he' ? 'פעיל' : 'Mic')}
            </span>
          </button>

          {/* Motion Toggle & Settings */}
          <button
            onClick={() => setMotionDetectionEnabled(!motionDetectionEnabled)}
            className={`flex flex-col items-center gap-1 transition p-2 rounded-xl hover:bg-slate-800 ${
              motionDetectionEnabled ? 'text-emerald-400' : 'text-slate-500'
            }`}
          >
            <div
              className={`p-2.5 rounded-xl shadow transition ${
                motionDetectionEnabled ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
              }`}
            >
              <Activity className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium">
              {motionDetectionEnabled ? (lang === 'he' ? 'תנועה פעילה' : 'Motion On') : (lang === 'he' ? 'תנועה כבויה' : 'Motion Off')}
            </span>
          </button>
        </div>

        {/* Secondary quick bar: Resolution & sensitivity */}
        <div className="flex items-center justify-between text-xs text-slate-400 mt-2 pt-2 border-t border-slate-800/80 px-2">
          <div className="flex items-center gap-2">
            <span>{t.resolution}:</span>
            {(['720p', '1080p', '480p'] as const).map((r) => (
              <button
                key={r}
                onClick={() => {
                  setResolution(r);
                  startCamera(facingMode, r);
                }}
                className={`px-2 py-0.5 rounded text-[11px] font-mono transition ${
                  resolution === r
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span>{t.motionSensitivity}:</span>
            <input
              type="range"
              min={1}
              max={10}
              value={motionSensitivity}
              onChange={(e) => setMotionSensitivity(Number(e.target.value))}
              className="w-16 h-1.5 accent-emerald-500 rounded-lg cursor-pointer bg-slate-700"
            />
            <span className="font-mono text-emerald-400 text-[11px]">{motionSensitivity}</span>
          </div>
        </div>
      </div>

      {/* PAIRING MODAL */}
      {showPairingModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <PairingDrawer
            roomId={roomId}
            pin={pin}
            lang={lang}
            onClose={() => setShowPairingModal(false)}
          />
        </div>
      )}
    </div>
  );
};
