import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Copy, Check, ExternalLink, QrCode as QrIcon, Smartphone } from 'lucide-react';
import { translations } from '../translations';

interface PairingDrawerProps {
  roomId: string;
  pin: string;
  lang: 'he' | 'en';
  onClose?: () => void;
}

export const PairingDrawer: React.FC<PairingDrawerProps> = ({ roomId, pin, lang, onClose }) => {
  const t = translations[lang];
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const pairingUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${window.location.pathname}?room=${roomId}&pin=${pin}&role=viewer`
    : '';

  useEffect(() => {
    if (pairingUrl) {
      QRCode.toDataURL(pairingUrl, {
        width: 280,
        margin: 2,
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
      })
        .then((url) => setQrDataUrl(url))
        .catch((err) => console.error('Error generating QR:', err));
    }
  }, [pairingUrl]);

  const handleCopy = () => {
    navigator.clipboard.writeText(pairingUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const formattedPin = pin.length === 6 ? `${pin.slice(0, 3)} - ${pin.slice(3)}` : pin;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 shadow-2xl max-w-md w-full mx-auto">
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
            <QrIcon className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-lg">{t.pairingCode}</h3>
            <p className="text-xs text-slate-400">{t.scanWithOtherDevice}</p>
          </div>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-lg p-1"
          >
            ✕
          </button>
        )}
      </div>

      {/* QR Code Container */}
      <div className="flex flex-col items-center my-6">
        <div className="p-3 bg-white rounded-xl shadow-lg border-2 border-emerald-500/30">
          {qrDataUrl ? (
            <img src={qrDataUrl} alt="Pairing QR Code" className="w-56 h-56 object-contain" />
          ) : (
            <div className="w-56 h-56 flex items-center justify-center bg-slate-100 text-slate-400 text-sm">
              Loading QR...
            </div>
          )}
        </div>
        <p className="text-xs text-slate-400 mt-2 flex items-center gap-1.5">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          {t.scanQrToConnect}
        </p>
      </div>

      {/* PIN Code Box */}
      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 text-center mb-4">
        <span className="text-xs text-slate-400 uppercase tracking-wider block mb-1">
          PIN CODE
        </span>
        <div className="font-mono text-3xl font-extrabold tracking-widest text-emerald-400">
          {formattedPin}
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col gap-2">
        <button
          onClick={handleCopy}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-medium rounded-xl transition text-sm shadow-lg shadow-emerald-950"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-200" /> : <Copy className="w-4 h-4" />}
          {copied ? t.linkCopied : t.copyLink}
        </button>

        <a
          href={pairingUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded-xl transition text-sm border border-slate-700"
        >
          <ExternalLink className="w-4 h-4" />
          {lang === 'he' ? 'פתח מסך צפייה בלשונית חדשה' : 'Open Monitor in New Tab'}
        </a>
      </div>
    </div>
  );
};
