import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Smartphone, Download, X, CheckCircle, Info } from 'lucide-react';

interface PWAInstallButtonProps {
  lang: 'he' | 'en';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ lang }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [installedSuccess, setInstalledSuccess] = useState(false);

  // If already running inside standalone installed app
  if (isInstalled) {
    return (
      <span className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[11px] font-semibold">
        <CheckCircle className="w-3.5 h-3.5" />
        {lang === 'he' ? 'מותקן באפליקציה' : 'App Installed'}
      </span>
    );
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) setInstalledSuccess(true);
    } else {
      setShowGuide(true);
    }
  };

  return (
    <>
      <button
        onClick={handleInstallClick}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-950 transition active:scale-95"
        title={lang === 'he' ? 'התקן אפליקציה למכשיר' : 'Install App to Device'}
      >
        <Smartphone className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
        <span className="hidden sm:inline">
          {lang === 'he' ? 'התקן למכשיר' : 'Install App'}
        </span>
        <span className="sm:hidden">
          {lang === 'he' ? 'התקן' : 'Install'}
        </span>
      </button>

      {/* Guide / How to Install Modal */}
      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-6 text-slate-100 shadow-2xl relative">
            <button
              onClick={() => setShowGuide(false)}
              className="absolute top-4 left-4 p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-4">
              <Smartphone className="w-6 h-6" />
            </div>

            <h3 className="text-lg font-bold text-white mb-2">
              {lang === 'he' ? 'התקנת RemoteCam Max במכשיר' : 'Install RemoteCam Max'}
            </h3>

            {isIOS ? (
              <div className="space-y-3 text-sm text-slate-300">
                <p>
                  {lang === 'he'
                    ? 'במכשירי iPhone / iPad של אפל:'
                    : 'On iPhone / iPad devices:'}
                </p>
                <ol className="list-decimal list-inside space-y-2 text-xs text-slate-400">
                  <li>
                    {lang === 'he'
                      ? 'לחץ על כפתור השיתוף בתחתית דפדפן Safari (אייקון ריבוע עם חץ למעלה).'
                      : 'Tap the Share button in Safari toolbar.'}
                  </li>
                  <li>
                    {lang === 'he'
                      ? 'גלול מטה ובחר "הוסף למסך הבית" (Add to Home Screen).'
                      : 'Scroll down and tap "Add to Home Screen".'}
                  </li>
                  <li>
                    {lang === 'he'
                      ? 'האפליקציה תופיע כאפליקציה מלאה במסך הבית שלך!'
                      : 'The app will appear as a full native app on your home screen!'}
                  </li>
                </ol>
              </div>
            ) : (
              <div className="space-y-3 text-sm text-slate-300">
                <p>
                  {lang === 'he'
                    ? 'במכשירי אנדרואיד / דפדפן Chrome:'
                    : 'On Android / Chrome browser:'}
                </p>
                <ol className="list-decimal list-inside space-y-2 text-xs text-slate-400">
                  <li>
                    {lang === 'he'
                      ? 'לחץ על 3 הנקודות בתפריט הדפדפן למעלה.'
                      : 'Tap the 3 dots menu in your browser.'}
                  </li>
                  <li>
                    {lang === 'he'
                      ? 'בחר באפשרות "התקן אפליקציה" או "הוסף למסך הבית".'
                      : 'Select "Install app" or "Add to Home screen".'}
                  </li>
                  <li>
                    {lang === 'he'
                      ? 'האפליקציה תותקן מיד כמכשיר עצמאי במסך הבית שלך ללא צורך בקובץ APK!'
                      : 'The app will install directly on your home screen without needing an APK file!'}
                  </li>
                </ol>
              </div>
            )}

            <button
              onClick={() => setShowGuide(false)}
              className="mt-6 w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-xl text-sm transition"
            >
              {lang === 'he' ? 'הבנתי, תודה' : 'Got it'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
