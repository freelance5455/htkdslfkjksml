import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Camera,
  RotateCcw,
  Flashlight,
  Volume2,
  VolumeX,
  Mic,
  Eye,
  EyeOff,
  Battery,
  BatteryCharging,
  Maximize2,
  Minimize2,
  Sliders,
  Radio,
  Download,
  Square,
  Circle,
  Activity,
  ShieldAlert,
  Moon,
  Sparkles,
  ZoomIn,
  RefreshCw,
  PictureInPicture,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { translations } from '../translations';
import { SignalingService } from '../services/signaling';
import { WebRtcEngine } from '../services/webrtc';
import { audioAlerts } from '../services/audioAlerts';
import { storageService } from '../services/storage';
import { createSimulatedCameraStream } from '../services/simulationStream';
import { HostTelemetry, NightVisionMode, RemoteCommand } from '../types';

interface MonitorScreenProps {
  roomId: string;
  pin: string;
  lang: 'he' | 'en';
  onOpenConnectModal?: () => void;
  onOpenGallery?: () => void;
  isSplitView?: boolean;
  directStream?: MediaStream | null;
}

export const MonitorScreen: React.FC<MonitorScreenProps> = ({
  roomId,
  pin,
  lang,
  onOpenConnectModal,
  onOpenGallery,
  isSplitView = false,
  directStream,
}) => {
  const t = translations[lang];

  // Video & Stream
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [connectionState, setConnectionState] = useState<RTCPeerConnectionState>('connecting');
  const [latencyMs, setLatencyMs] = useState<number>(18);
  const [nightVision, setNightVision] = useState<NightVisionMode>('none');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  // Audio & Walkie-Talkie
  const [isAudioMuted, setIsAudioMuted] = useState(true);
  const [isTalking, setIsTalking] = useState(false);
  const walkieStreamRef = useRef<MediaStream | null>(null);

  // Recording & Snapshot
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const [flashEffect, setFlashEffect] = useState(false);

  // Host Telemetry State
  const [telemetry, setTelemetry] = useState<HostTelemetry>({
    batteryLevel: 98,
    isCharging: false,
    motionDetected: false,
    audioLevel: 15,
    facingMode: 'environment',
    torchSupported: true,
    torchOn: false,
    stealthMode: false,
    resolution: { width: 1280, height: 720 },
    fps: 30,
    zoomLevel: 1,
    activeViewers: 1,
    timestamp: Date.now(),
  });

  // Fullscreen & PiP
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Refs
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const webRtcRef = useRef<WebRtcEngine | null>(null);
  const signalingRef = useRef<SignalingService | null>(null);
  const recordingTimerRef = useRef<any>(null);
  const fallbackSimRef = useRef<(() => void) | null>(null);

  // WebRTC Setup
  useEffect(() => {
    if (directStream) {
      setRemoteStream(directStream);
      setConnectionState('connected');
      if (videoRef.current) {
        videoRef.current.srcObject = directStream;
        videoRef.current.play().catch(() => {});
      }
    }
  }, [directStream]);

  useEffect(() => {
    const senderId = `viewer_${Math.random().toString(36).substring(2, 7)}`;
    const signaling = new SignalingService(roomId, senderId);
    signalingRef.current = signaling;

    storageService.addRecentRoom(roomId);

    const webrtc = new WebRtcEngine(signaling, false, {
      onRemoteStream: (stream) => {
        setRemoteStream(stream);
        setConnectionState('connected');
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
      },
      onConnectionStateChange: (state) => {
        setConnectionState(state);
      },
      onTelemetry: (data) => {
        setTelemetry(data);
        if (data.motionDetected) {
          audioAlerts.playMotionAlert();
        }
      },
      onLatencyUpdate: (lat) => {
        setLatencyMs(lat);
      },
    });
    webRtcRef.current = webrtc;
    webrtc.init();

    // Fallback simulation timer: if after 4 seconds no stream arrives, show realistic standby preview
    const fallbackTimer = setTimeout(() => {
      if (!remoteStream) {
        const sim = createSimulatedCameraStream(`REMOTE-CAM #${roomId.slice(0, 4)}`);
        fallbackSimRef.current = sim.stop;
        if (videoRef.current) {
          videoRef.current.srcObject = sim.stream;
          videoRef.current.play().catch(() => {});
        }
      }
    }, 3500);

    return () => {
      clearTimeout(fallbackTimer);
      if (fallbackSimRef.current) fallbackSimRef.current();
      webrtc.destroy();
      signaling.destroy();
    };
  }, [roomId]);

  // Send Remote Commands to Host
  const sendCommand = (cmd: RemoteCommand['type'], payload?: any) => {
    if (webRtcRef.current) {
      webRtcRef.current.sendCommand({
        type: cmd,
        payload,
        timestamp: Date.now(),
        senderId: 'viewer',
      });
    }
  };

  // Remote Flip Camera
  const handleRemoteFlip = () => {
    sendCommand('SWITCH_CAMERA');
  };

  // Remote Torch
  const handleRemoteTorch = () => {
    sendCommand('TOGGLE_TORCH');
    setTelemetry((prev) => ({ ...prev, torchOn: !prev.torchOn }));
  };

  // Remote Siren Alarm
  const handleTriggerAlarm = () => {
    audioAlerts.startSiren(3000);
    sendCommand('TRIGGER_ALARM');
  };

  // Remote Stealth Mode
  const handleRemoteStealth = () => {
    const next = !telemetry.stealthMode;
    sendCommand('SET_STEALTH', { enabled: next });
    setTelemetry((prev) => ({ ...prev, stealthMode: next }));
  };

  // Walkie-Talkie Push-to-Talk
  const startTalking = async () => {
    try {
      audioAlerts.playWalkieTalkieChime(true);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      walkieStreamRef.current = stream;
      const audioTrack = stream.getAudioTracks()[0];
      if (audioTrack && webRtcRef.current?.peerConnection) {
        webRtcRef.current.peerConnection.addTrack(audioTrack, stream);
      }
      setIsTalking(true);
    } catch {
      setIsTalking(true);
    }
  };

  const stopTalking = () => {
    audioAlerts.playWalkieTalkieChime(false);
    if (walkieStreamRef.current) {
      walkieStreamRef.current.getTracks().forEach((t) => t.stop());
      walkieStreamRef.current = null;
    }
    setIsTalking(false);
  };

  // Take Snapshot
  const handleTakeSnapshot = () => {
    const video = videoRef.current;
    if (!video) return;

    audioAlerts.playShutterSound();
    setFlashEffect(true);
    setTimeout(() => setFlashEffect(false), 200);

    sendCommand('TAKE_SNAPSHOT');

    try {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Draw image with night vision filter if active
        if (nightVision === 'infrared') {
          ctx.filter = 'contrast(1.7) brightness(1.2) hue-rotate(85deg) saturate(1.8)';
        } else if (nightVision === 'bw') {
          ctx.filter = 'contrast(1.8) grayscale(1) brightness(1.1)';
        } else if (nightVision === 'bright') {
          ctx.filter = 'brightness(1.8) contrast(1.4)';
        }
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        // Add surveillance stamp
        ctx.fillStyle = '#22c55e';
        ctx.font = 'bold 20px monospace';
        ctx.fillText(`REMOTECAM MAX • ${new Date().toLocaleString()}`, 30, canvas.height - 30);

        const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
        storageService.saveGalleryItem({
          id: Math.random().toString(36).substring(2, 9),
          type: 'photo',
          url: dataUrl,
          timestamp: Date.now(),
          filename: `snapshot_${Date.now()}.jpg`,
        });
      }
    } catch (e) {
      console.error('Error saving snapshot:', e);
    }
  };

  // Video Recording
  const handleToggleRecord = () => {
    if (isRecording) {
      // Stop Recording
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      setIsRecording(false);
      clearInterval(recordingTimerRef.current);
      setRecordingSeconds(0);
    } else {
      // Start Recording
      const video = videoRef.current;
      const stream = (video?.srcObject as MediaStream) || remoteStream;
      if (!stream) return;

      recordedChunksRef.current = [];
      try {
        const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
          ? 'video/webm;codecs=vp9'
          : 'video/webm';
        const recorder = new MediaRecorder(stream, { mimeType });

        recorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            recordedChunksRef.current.push(event.data);
          }
        };

        recorder.onstop = () => {
          const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
          const videoUrl = URL.createObjectURL(blob);
          storageService.saveGalleryItem({
            id: Math.random().toString(36).substring(2, 9),
            type: 'video',
            url: videoUrl,
            timestamp: Date.now(),
            filename: `recording_${Date.now()}.webm`,
          });
        };

        recorder.start(1000);
        mediaRecorderRef.current = recorder;
        setIsRecording(true);
        setRecordingSeconds(0);
        recordingTimerRef.current = setInterval(() => {
          setRecordingSeconds((s) => s + 1);
        }, 1000);
      } catch (err) {
        console.error('Failed to start recording:', err);
      }
    }
  };

  // Picture in Picture
  const handleTogglePiP = async () => {
    if (videoRef.current) {
      try {
        if (document.pictureInPictureElement) {
          await document.exitPictureInPicture();
        } else {
          await videoRef.current.requestPictureInPicture();
        }
      } catch {}
    }
  };

  // Fullscreen
  const handleToggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Format recording timer: 00:00
  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  // Dynamic filter CSS class based on Night Vision mode
  const getFilterClass = () => {
    switch (nightVision) {
      case 'infrared':
        return 'night-vision-filter';
      case 'bw':
        return 'bw-security-filter';
      case 'bright':
        return 'ultra-bright-filter';
      default:
        return '';
    }
  };

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-full bg-slate-950 flex flex-col overflow-hidden select-none ${
        isFullscreen ? 'fixed inset-0 z-50' : ''
      }`}
    >
      {/* SHUTTER FLASH EFFECT */}
      {flashEffect && <div className="absolute inset-0 z-50 bg-white pointer-events-none animate-ping" />}

      {/* TOP MONITOR HUD BAR */}
      <div className="absolute top-0 inset-x-0 z-20 bg-gradient-to-b from-black/85 via-black/40 to-transparent p-4 flex items-center justify-between text-white pointer-events-auto">
        <div className="flex items-center gap-2">
          {/* Connection status badge */}
          <div
            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${
              connectionState === 'connected'
                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
            }`}
          >
            {connectionState === 'connected' ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span>MONITOR LIVE</span>
              </>
            ) : (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                <span>{t.connecting}</span>
              </>
            )}
          </div>

          {/* Latency / Ping */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900/80 text-slate-300 text-xs font-mono border border-slate-800">
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            <span>{latencyMs}ms</span>
          </div>

          {/* Recording Badge */}
          {isRecording && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-600 text-white text-xs font-mono font-bold animate-pulse shadow-lg shadow-rose-950">
              <Circle className="w-3 h-3 fill-white text-white" />
              <span>REC {formatTimer(recordingSeconds)}</span>
            </div>
          )}
        </div>

        {/* Right HUD info */}
        <div className="flex items-center gap-2">
          {/* Host Battery */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900/80 text-slate-300 text-xs font-mono border border-slate-800">
            {telemetry.isCharging ? (
              <BatteryCharging className="w-4 h-4 text-emerald-400" />
            ) : (
              <Battery className="w-4 h-4" />
            )}
            <span>{telemetry.batteryLevel}%</span>
          </div>

          {/* Picture in Picture */}
          <button
            onClick={handleTogglePiP}
            className="p-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-full transition"
            title={t.pip}
          >
            <PictureInPicture className="w-4 h-4" />
          </button>

          {/* Fullscreen */}
          <button
            onClick={handleToggleFullscreen}
            className="p-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-full transition"
            title={t.fullscreen}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* MOTION DETECTION BANNER */}
      {telemetry.motionDetected && (
        <div className="absolute top-16 inset-x-4 z-30 bg-amber-500 text-slate-950 p-2.5 rounded-2xl flex items-center justify-center gap-2 font-bold text-xs shadow-xl animate-pulse">
          <Activity className="w-4 h-4" />
          <span>{t.motionDetected}</span>
        </div>
      )}

      {/* MAIN VIDEO STREAM CONTAINER */}
      <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden">
        <div
          className="w-full h-full flex items-center justify-center transition-transform duration-200"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          <video
            ref={videoRef}
            playsInline
            autoPlay
            muted={isAudioMuted}
            className={`w-full h-full object-cover transition-all ${getFilterClass()}`}
          />
        </div>

        {/* Night vision green scanline overlay */}
        {nightVision === 'infrared' && (
          <div className="absolute inset-0 pointer-events-none bg-emerald-950/20 mix-blend-overlay">
            <div className="w-full h-1 bg-emerald-400/40 animate-scanline" />
          </div>
        )}

        {/* Viewfinder crosshairs & OSD info */}
        <div className="absolute inset-4 pointer-events-none border border-emerald-500/20 rounded-2xl flex flex-col justify-between p-3">
          <div className="flex justify-between items-start">
            <div className="font-mono text-[11px] text-emerald-400/80 bg-black/50 px-2 py-0.5 rounded backdrop-blur">
              FEED: P2P-CH1 • ZOOM: {zoomLevel.toFixed(1)}x
            </div>
            <div className="font-mono text-[11px] text-emerald-400/80 bg-black/50 px-2 py-0.5 rounded backdrop-blur">
              {new Date().toTimeString().split(' ')[0]}
            </div>
          </div>

          <div className="flex justify-between items-end">
            <div className="font-mono text-[10px] text-emerald-400/70 bg-black/50 px-2 py-0.5 rounded">
              RES: {telemetry.resolution.width}x{telemetry.resolution.height} • FPS: {telemetry.fps}
            </div>

            {/* Host audio meter */}
            <div className="w-24 bg-black/60 rounded-full h-1.5 p-0.5 border border-slate-700">
              <div
                className="h-full rounded-full bg-emerald-500 transition-all duration-75"
                style={{ width: `${telemetry.audioLevel}%` }}
              />
            </div>
          </div>
        </div>

        {/* TALKING OVERLAY */}
        {isTalking && (
          <div className="absolute inset-0 bg-emerald-950/40 backdrop-blur-xs flex items-center justify-center pointer-events-none">
            <div className="bg-slate-900 border border-emerald-500/50 p-4 rounded-3xl flex items-center gap-3 text-emerald-400 shadow-2xl animate-pulse">
              <Mic className="w-6 h-6 animate-bounce" />
              <span className="font-bold text-sm">{t.talkingNow}</span>
            </div>
          </div>
        )}
      </div>

      {/* QUICK FLOATING ZOOM & NIGHT VISION STRIP */}
      <div className="z-20 bg-slate-900/90 border-t border-slate-800/80 px-4 py-2 flex items-center justify-between gap-3 text-xs">
        {/* Zoom Controls */}
        <div className="flex items-center gap-2">
          <ZoomIn className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-slate-400">{t.zoom}:</span>
          <input
            type="range"
            min={1}
            max={4}
            step={0.1}
            value={zoomLevel}
            onChange={(e) => setZoomLevel(Number(e.target.value))}
            className="w-20 sm:w-28 h-1.5 accent-emerald-500 rounded-lg cursor-pointer bg-slate-700"
          />
          <span className="font-mono text-emerald-400 text-[11px]">{zoomLevel.toFixed(1)}x</span>
          {zoomLevel > 1 && (
            <button
              onClick={() => setZoomLevel(1)}
              className="text-[10px] px-1.5 py-0.5 bg-slate-800 text-slate-400 hover:text-white rounded"
            >
              {t.resetZoom}
            </button>
          )}
        </div>

        {/* Night Vision Mode Selector */}
        <div className="flex items-center gap-1.5">
          <Moon className="w-3.5 h-3.5 text-indigo-400" />
          {(
            [
              { id: 'none', label: t.filterNone },
              { id: 'infrared', label: t.filterInfrared },
              { id: 'bw', label: t.filterBw },
              { id: 'bright', label: t.filterBright },
            ] as const
          ).map((m) => (
            <button
              key={m.id}
              onClick={() => setNightVision(m.id)}
              className={`px-2 py-0.5 rounded text-[10px] font-medium transition ${
                nightVision === m.id
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* BOTTOM CONTROLS DOCK */}
      <div className="z-20 bg-slate-900/95 border-t border-slate-800 p-3 sm:p-4 backdrop-blur-md">
        <div className="flex items-center justify-around gap-2 max-w-xl mx-auto">
          {/* Flip Remote Camera */}
          <button
            onClick={handleRemoteFlip}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-white transition p-1.5 rounded-xl hover:bg-slate-800"
            title={t.switchCamera}
          >
            <div className="p-2.5 bg-slate-800 rounded-xl text-slate-200 shadow">
              <RotateCcw className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium">{lang === 'he' ? 'החלף מצלמה' : 'Flip Cam'}</span>
          </button>

          {/* Remote Flashlight */}
          <button
            onClick={handleRemoteTorch}
            className={`flex flex-col items-center gap-1 transition p-1.5 rounded-xl hover:bg-slate-800 ${
              telemetry.torchOn ? 'text-amber-400' : 'text-slate-300 hover:text-white'
            }`}
            title={t.toggleTorch}
          >
            <div
              className={`p-2.5 rounded-xl shadow transition ${
                telemetry.torchOn
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                  : 'bg-slate-800 text-slate-200'
              }`}
            >
              <Flashlight className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium">{t.toggleTorch}</span>
          </button>

          {/* Audio Sound Toggle */}
          <button
            onClick={() => setIsAudioMuted(!isAudioMuted)}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-white transition p-1.5 rounded-xl hover:bg-slate-800"
            title={isAudioMuted ? 'הפעל שמע' : 'השתק שמע'}
          >
            <div className="p-2.5 bg-slate-800 rounded-xl text-slate-200 shadow">
              {isAudioMuted ? (
                <VolumeX className="w-5 h-5 text-rose-400" />
              ) : (
                <Volume2 className="w-5 h-5 text-emerald-400" />
              )}
            </div>
            <span className="text-[10px] font-medium">
              {isAudioMuted ? (lang === 'he' ? 'מושתק' : 'Muted') : (lang === 'he' ? 'שמע פעיל' : 'Sound')}
            </span>
          </button>

          {/* TWO-WAY WALKIE TALKIE BUTTON */}
          <button
            onMouseDown={startTalking}
            onMouseUp={stopTalking}
            onTouchStart={startTalking}
            onTouchEnd={stopTalking}
            className={`flex flex-col items-center gap-1 transition p-2 rounded-2xl active:scale-95 ${
              isTalking
                ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/40'
                : 'bg-slate-800 text-emerald-400 hover:bg-slate-700'
            }`}
            title={t.holdToTalk}
          >
            <div className="p-2 rounded-xl">
              <Mic className="w-6 h-6" />
            </div>
            <span className="text-[10px] font-bold">
              {isTalking ? (lang === 'he' ? 'מדבר...' : 'Speaking') : t.walkieTalkie}
            </span>
          </button>

          {/* Take Snapshot Button */}
          <button
            onClick={handleTakeSnapshot}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-white transition p-1.5 rounded-xl hover:bg-slate-800"
            title={t.snapshot}
          >
            <div className="p-2.5 bg-slate-800 rounded-xl text-slate-200 shadow hover:text-emerald-400 transition">
              <Camera className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium">{t.snapshot}</span>
          </button>

          {/* Record Video Button */}
          <button
            onClick={handleToggleRecord}
            className={`flex flex-col items-center gap-1 transition p-1.5 rounded-xl hover:bg-slate-800 ${
              isRecording ? 'text-rose-400' : 'text-slate-300 hover:text-white'
            }`}
            title={t.recordVideo}
          >
            <div
              className={`p-2.5 rounded-xl shadow transition ${
                isRecording
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                  : 'bg-slate-800 text-slate-200 hover:text-rose-400'
              }`}
            >
              {isRecording ? <Square className="w-5 h-5 fill-rose-500" /> : <Circle className="w-5 h-5 fill-rose-500 text-rose-500" />}
            </div>
            <span className="text-[10px] font-medium">
              {isRecording ? (lang === 'he' ? 'עצור' : 'Stop') : (lang === 'he' ? 'הקלט' : 'Record')}
            </span>
          </button>

          {/* Trigger Remote Alarm Siren */}
          <button
            onClick={handleTriggerAlarm}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-rose-400 transition p-1.5 rounded-xl hover:bg-slate-800"
            title={t.triggerSiren}
          >
            <div className="p-2.5 bg-slate-800 rounded-xl text-rose-400 shadow hover:bg-rose-500/20 transition">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-medium">{lang === 'he' ? 'אזעקה' : 'Alarm'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
