import React, { useState } from 'react';
import { GalleryItem } from '../types';
import { Download, Trash2, X, Play, Image as ImageIcon, Video, Calendar } from 'lucide-react';
import { translations } from '../translations';
import { storageService } from '../services/storage';

interface GalleryModalProps {
  items: GalleryItem[];
  lang: 'he' | 'en';
  onClose: () => void;
  onRefresh: () => void;
}

export const GalleryModal: React.FC<GalleryModalProps> = ({
  items,
  lang,
  onClose,
  onRefresh,
}) => {
  const t = translations[lang];
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    storageService.deleteGalleryItem(id);
    if (selectedItem?.id === id) setSelectedItem(null);
    onRefresh();
  };

  const handleDownload = (item: GalleryItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const link = document.createElement('a');
    link.href = item.url;
    link.download = item.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
              <ImageIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">{t.gallery}</h3>
              <p className="text-xs text-slate-400">
                {items.length} {lang === 'he' ? 'קבצים שמורים' : 'saved items'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list / grid */}
        <div className="flex-1 overflow-y-auto p-5">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center text-slate-500">
              <ImageIcon className="w-12 h-12 stroke-[1.5] mb-3 opacity-40" />
              <p className="text-sm font-medium">{t.noItemsInGallery}</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {items.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedItem(item)}
                  className="group relative bg-slate-950 border border-slate-800 rounded-xl overflow-hidden aspect-video cursor-pointer hover:border-emerald-500/50 transition shadow"
                >
                  {item.type === 'photo' ? (
                    <img
                      src={item.url}
                      alt="Capture"
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                  ) : (
                    <div className="relative w-full h-full bg-slate-950 flex items-center justify-center">
                      <video src={item.url} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <div className="w-9 h-9 rounded-full bg-emerald-500/90 text-slate-950 flex items-center justify-center shadow">
                          <Play className="w-4 h-4 fill-slate-950 ml-0.5" />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Type badge */}
                  <div className="absolute top-2 left-2 px-1.5 py-0.5 bg-black/70 backdrop-blur rounded text-[10px] text-white flex items-center gap-1">
                    {item.type === 'photo' ? (
                      <ImageIcon className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Video className="w-3 h-3 text-rose-400" />
                    )}
                  </div>

                  {/* Hover actions */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition p-2 flex items-end justify-between">
                    <span className="text-[10px] text-slate-300 truncate">
                      {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <div className="flex gap-1.5">
                      <button
                        onClick={(e) => handleDownload(item, e)}
                        className="p-1 bg-slate-800/90 hover:bg-emerald-600 rounded text-slate-200 transition"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => handleDelete(item.id, e)}
                        className="p-1 bg-slate-800/90 hover:bg-rose-600 rounded text-slate-200 transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Selected Item Modal / Lightbox */}
        {selectedItem && (
          <div className="fixed inset-0 z-60 bg-black/90 flex flex-col p-4">
            <div className="flex items-center justify-between text-white p-2">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Calendar className="w-4 h-4" />
                {new Date(selectedItem.timestamp).toLocaleString()}
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => handleDownload(selectedItem)}
                  className="p-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-white flex items-center gap-1.5 text-xs font-medium"
                >
                  <Download className="w-4 h-4" />
                  {t.download}
                </button>
                <button
                  onClick={(e) => handleDelete(selectedItem.id, e)}
                  className="p-2 bg-rose-600/80 hover:bg-rose-500 rounded-xl text-white text-xs"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedItem(null)}
                  className="p-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 flex items-center justify-center p-4 overflow-hidden">
              {selectedItem.type === 'photo' ? (
                <img
                  src={selectedItem.url}
                  alt="Preview"
                  className="max-h-full max-w-full object-contain rounded-xl shadow-2xl"
                />
              ) : (
                <video
                  src={selectedItem.url}
                  controls
                  autoPlay
                  className="max-h-full max-w-full rounded-xl shadow-2xl"
                />
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
