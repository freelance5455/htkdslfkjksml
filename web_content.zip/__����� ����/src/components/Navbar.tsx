import React from 'react';
import {
  Video,
  Tv,
  Columns,
  QrCode,
  Image as ImageIcon,
  Globe,
  Radio,
  Download,
  Smartphone,
} from 'lucide-react';
import { DeviceRole } from '../types';
import { translations } from '../translations';
import { PWAInstallButton } from './PWAInstallButton';

interface NavbarProps {
  currentRole: DeviceRole;
  onChangeRole: (role: DeviceRole) => void;
  lang: 'he' | 'en';
  onToggleLang: () => void;
  onOpenGallery: () => void;
  onOpenConnectModal: () => void;
  galleryCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  onChangeRole,
  lang,
  onToggleLang,
  onOpenGallery,
  onOpenConnectModal,
  galleryCount,
}) => {
  const t = translations[lang];

  return (
    <header className="h-14 bg-slate-900/90 border-b border-slate-800 px-4 flex items-center justify-between text-slate-100 z-30 select-none backdrop-blur-md">
      {/* Brand Logo */}
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-slate-950 font-bold shadow-md shadow-emerald-950">
          <Video className="w-4 h-4 fill-slate-950 text-slate-950" />
        </div>
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="font-extrabold text-sm tracking-tight text-white">
              RemoteCam<span className="text-emerald-400 font-black">MAX</span>
            </span>
            <span className="px-1.5 py-0.2 rounded text-[9px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
              P2P
            </span>
          </div>
          <span className="text-[10px] text-slate-400 hidden sm:block">
            {t.subtitle}
          </span>
        </div>
      </div>

      {/* Center Role Navigation Pill */}
      <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
        <button
          onClick={() => onChangeRole('split')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            currentRole === 'split'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
          title={t.modeSplit}
        >
          <Columns className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{t.modeSplit}</span>
          <span className="sm:hidden">{lang === 'he' ? 'כפול' : 'Dual'}</span>
        </button>

        <button
          onClick={() => onChangeRole('host')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            currentRole === 'host'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
          title={t.modeHost}
        >
          <Video className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{t.modeHost}</span>
          <span className="sm:hidden">{lang === 'he' ? 'מצלמה' : 'Host'}</span>
        </button>

        <button
          onClick={() => onChangeRole('viewer')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            currentRole === 'viewer'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
          title={t.modeMonitor}
        >
          <Tv className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{t.modeMonitor}</span>
          <span className="sm:hidden">{lang === 'he' ? 'מוניטור' : 'Viewer'}</span>
        </button>
      </div>

      {/* Right Action Icons */}
      <div className="flex items-center gap-2">
        {/* Download APK binary */}
        <a
          href="/RemoteCamMax.apk"
          download="RemoteCamMax.apk"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-950 transition active:scale-95 border border-emerald-400/40"
          title="הורד קובץ APK מוכן להתקנה באנדרואיד"
        >
          <Smartphone className="w-3.5 h-3.5 fill-white text-white" />
          <span>APK</span>
        </a>

        {/* PWA Install Button */}
        <PWAInstallButton lang={lang} />

        {/* Connect / Pair Button */}
        <button
          onClick={onOpenConnectModal}
          className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium border border-slate-700 transition"
          title={t.scanQrToConnect}
        >
          <QrCode className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden md:inline">{lang === 'he' ? 'צימוד' : 'Pair'}</span>
        </button>

        {/* Gallery button with badge */}
        <button
          onClick={onOpenGallery}
          className="relative p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs transition border border-slate-700"
          title={t.gallery}
        >
          <ImageIcon className="w-4 h-4 text-emerald-400" />
          {galleryCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 text-slate-950 font-bold text-[9px] flex items-center justify-center">
              {galleryCount}
            </span>
          )}
        </button>

        {/* Download project source archive */}
        <a
          href="/api/download-source"
          download="remotecam-max-source.tar.gz"
          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs transition border border-slate-700"
          title={lang === 'he' ? 'הורד את קובץ הפרויקט המלא (ZIP/TAR)' : 'Download Source Archive'}
        >
          <Download className="w-4 h-4 text-emerald-400" />
        </a>

        {/* Language switch */}
        <button
          onClick={onToggleLang}
          className="flex items-center gap-1 px-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-mono border border-slate-700 transition"
        >
          <Globe className="w-3.5 h-3.5 text-slate-400" />
          <span>{lang === 'he' ? 'EN' : 'עב'}</span>
        </button>
      </div>
    </header>
  );
};
