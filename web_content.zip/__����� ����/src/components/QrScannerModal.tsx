import React, { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { Camera, Hash, Clock, X, Zap } from 'lucide-react';
import { translations } from '../translations';
import { storageService } from '../services/storage';

interface QrScannerModalProps {
  lang: 'he' | 'en';
  onConnect: (roomId: string, pin: string) => void;
  onClose: () => void;
  currentRoomId?: string;
}

export const QrScannerModal: React.FC<QrScannerModalProps> = ({
  lang,
  onConnect,
  onClose,
  currentRoomId,
}) => {
  const t = translations[lang];
  const [activeTab, setActiveTab] = useState<'scan' | 'pin'>('scan');
  const [pinInput, setPinInput] = useState('');
  const [scanError, setScanError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const recentRooms = storageService.getRecentRooms();

  // QR Scanning Loop
  useEffect(() => {
    if (activeTab !== 'scan') {
      stopCamera();
      return;
    }

    let isSubscribed = true;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    async function startCamera() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
          audio: false,
        });
        if (!isSubscribed) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
        setScanError(null);
        scanLoop();
      } catch (err: any) {
        console.warn('Cannot open scanner camera:', err);
        setScanError(
          lang === 'he'
            ? 'אין גישה למצלמה לסריקה, אנא הזן קוד PIN ידנית.'
            : 'Camera access denied, please enter PIN manually.'
        );
        setActiveTab('pin');
      }
    }

    function scanLoop() {
      if (!isSubscribed) return;
      const video = videoRef.current;
      if (video && video.readyState === video.HAVE_ENOUGH_DATA && ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code && code.data) {
          try {
            // Check if it's a URL or direct JSON
            const url = new URL(code.data);
            const rId = url.searchParams.get('room');
            const pin = url.searchParams.get('pin') || '123456';
            if (rId) {
              stopCamera();
              onConnect(rId, pin);
              return;
            }
          } catch {
            // maybe simple room text
            if (code.data.length >= 4) {
              stopCamera();
              onConnect(code.data, '123456');
              return;
            }
          }
        }
      }
      animFrameRef.current = requestAnimationFrame(scanLoop);
    }

    startCamera();

    return () => {
      isSubscribed = false;
      stopCamera();
    };
  }, [activeTab]);

  const stopCamera = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPin = pinInput.replace(/\D/g, '');
    if (cleanPin.length >= 4) {
      // Use clean PIN as room identifier
      onConnect(cleanPin, cleanPin);
    }
  };

  const handleQuickDemo = () => {
    const demoId = currentRoomId || 'DEMO-88';
    onConnect(demoId, '123456');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-lg text-white">
              {lang === 'he' ? 'התחברות למצלמת מקור' : 'Connect to Camera'}
            </h3>
            <p className="text-xs text-slate-400">{t.scanQrToConnect}</p>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 p-1">
          <button
            onClick={() => setActiveTab('scan')}
            className={`flex-1 py-2.5 text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition ${
              activeTab === 'scan'
                ? 'bg-slate-800 text-emerald-400 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Camera className="w-4 h-4" />
            {lang === 'he' ? 'סורק QR' : 'QR Scanner'}
          </button>
          <button
            onClick={() => setActiveTab('pin')}
            className={`flex-1 py-2.5 text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition ${
              activeTab === 'pin'
                ? 'bg-slate-800 text-emerald-400 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Hash className="w-4 h-4" />
            {lang === 'he' ? 'קוד PIN ידני' : 'Enter PIN'}
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {activeTab === 'scan' && (
            <div className="flex flex-col items-center">
              <div className="relative w-64 h-64 bg-black rounded-2xl overflow-hidden border-2 border-emerald-500/40 shadow-inner flex items-center justify-center">
                <video
                  ref={videoRef}
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
                {/* Aiming square */}
                <div className="absolute inset-8 border-2 border-emerald-400/80 rounded-xl pointer-events-none animate-pulse">
                  <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-emerald-400" />
                  <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-emerald-400" />
                  <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-emerald-400" />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-emerald-400" />
                </div>
                <div className="absolute bottom-2 bg-black/60 px-2 py-0.5 rounded text-[10px] text-emerald-300">
                  {lang === 'he' ? 'כוון אל קוד ה-QR במסך המצלמה' : 'Point camera at QR code'}
                </div>
              </div>

              {scanError && (
                <p className="text-xs text-rose-400 mt-3 text-center">{scanError}</p>
              )}
            </div>
          )}

          {activeTab === 'pin' && (
            <form onSubmit={handlePinSubmit} className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">
                  {lang === 'he' ? 'הזן את קוד ה-PIN של המצלמה (6 ספרות):' : 'Enter 6-digit PIN code:'}
                </label>
                <input
                  type="text"
                  maxLength={8}
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="לדוגמה: 492018"
                  className="w-full py-3 px-4 bg-slate-950 border border-slate-700 rounded-xl text-center font-mono text-2xl font-bold tracking-widest text-emerald-400 placeholder:text-slate-600 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                type="submit"
                disabled={pinInput.trim().length < 4}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-medium rounded-xl transition text-sm shadow-lg shadow-emerald-950"
              >
                {t.startMonitor}
              </button>
            </form>
          )}

          {/* Quick Demo Test Button */}
          <div className="mt-5 pt-4 border-t border-slate-800 flex flex-col gap-2">
            <button
              onClick={handleQuickDemo}
              className="w-full py-2.5 px-4 bg-slate-800/80 hover:bg-slate-700 text-emerald-400 font-medium rounded-xl transition text-xs flex items-center justify-center gap-2 border border-emerald-500/20"
            >
              <Zap className="w-4 h-4 text-emerald-400" />
              {t.quickTest}
            </button>

            {/* Recent rooms list */}
            {recentRooms.length > 0 && (
              <div className="mt-2">
                <span className="text-[11px] text-slate-500 flex items-center gap-1 mb-1.5">
                  <Clock className="w-3 h-3" />
                  {t.recentCameras}:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {recentRooms.map((r) => (
                    <button
                      key={r}
                      onClick={() => onConnect(r, '123456')}
                      className="text-xs px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-mono border border-slate-700"
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
