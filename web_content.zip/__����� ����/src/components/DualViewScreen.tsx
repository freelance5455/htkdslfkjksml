import React, { useState } from 'react';
import { CameraHostScreen } from './CameraHostScreen';
import { MonitorScreen } from './MonitorScreen';
import { translations } from '../translations';
import { QrCode, Smartphone, Sparkles, ExternalLink } from 'lucide-react';
import { PairingDrawer } from './PairingDrawer';

interface DualViewScreenProps {
  roomId: string;
  pin: string;
  lang: 'he' | 'en';
}

export const DualViewScreen: React.FC<DualViewScreenProps> = ({ roomId, pin, lang }) => {
  const t = translations[lang];
  const [showPairingModal, setShowPairingModal] = useState(false);
  const [sharedStream, setSharedStream] = useState<MediaStream | null>(null);

  return (
    <div className="relative w-full h-full flex flex-col bg-slate-950 overflow-hidden">
      {/* Top Banner explaining Dual Simulation & option to connect real phone */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <span className="p-1 rounded-md bg-emerald-500/10 text-emerald-400 font-bold">
            <Sparkles className="w-3.5 h-3.5" />
          </span>
          <span className="font-semibold text-white">
            {lang === 'he'
              ? 'מצב בדיקה מפוצל: מצלמת מקור מימין / משמאל ומוניטור מרוחק מחוברים בזמן אמת'
              : 'Dual Simulator: Live Camera Host & Remote Monitor connected side-by-side'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowPairingModal(true)}
            className="flex items-center gap-1.5 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium transition shadow"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{lang === 'he' ? 'חבר טלפון אמיתי ב-QR' : 'Pair Real Phone'}</span>
          </button>
        </div>
      </div>

      {/* Side-by-Side or Stacked Dual Screens */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x md:divide-x-reverse divide-slate-800 overflow-hidden">
        {/* Left/Right Host Screen */}
        <div className="relative h-full flex flex-col overflow-hidden">
          <div className="absolute top-2 left-2 z-30 bg-black/70 backdrop-blur px-2.5 py-0.5 rounded text-[11px] font-mono text-emerald-400 border border-emerald-500/30 pointer-events-none">
            [1] {lang === 'he' ? 'מצלמת מקור (Host)' : 'Camera Host'}
          </div>
          <CameraHostScreen
            roomId={roomId}
            pin={pin}
            lang={lang}
            isSplitView={true}
            onStreamReady={setSharedStream}
          />
        </div>

        {/* Right/Left Monitor Screen */}
        <div className="relative h-full flex flex-col overflow-hidden">
          <div className="absolute top-2 left-2 z-30 bg-black/70 backdrop-blur px-2.5 py-0.5 rounded text-[11px] font-mono text-emerald-400 border border-emerald-500/30 pointer-events-none">
            [2] {lang === 'he' ? 'מסך מוניטור (Viewer)' : 'Monitor Viewer'}
          </div>
          <MonitorScreen
            roomId={roomId}
            pin={pin}
            lang={lang}
            isSplitView={true}
            directStream={sharedStream}
          />
        </div>
      </div>

      {/* QR PAIRING MODAL */}
      {showPairingModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <PairingDrawer
            roomId={roomId}
            pin={pin}
            lang={lang}
            onClose={() => setShowPairingModal(false)}
          />
        </div>
      )}
    </div>
  );
};
