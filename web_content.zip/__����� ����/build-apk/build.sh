#!/bin/bash
set -e

APK_DIR="/app/applet/build-apk"
mkdir -p "$APK_DIR/gen" "$APK_DIR/bin" "$APK_DIR/res/layout" "$APK_DIR/res/values" "$APK_DIR/res/mipmap-hdpi"
cp /app/applet/public/pwa-192x192.png "$APK_DIR/res/mipmap-hdpi/ic_launcher.png"

echo "=== 1. Generating R.java with aapt ==="
aapt package -f -m \
    -J "$APK_DIR/gen" \
    -M "$APK_DIR/AndroidManifest.xml" \
    -S "$APK_DIR/res" \
    -I /tmp/android.jar

echo "=== 2. Compiling Java sources with javac ==="
javac -source 1.8 -target 1.8 \
    -bootclasspath /tmp/android.jar \
    -cp "/tmp/android.jar:$APK_DIR/gen" \
    -d "$APK_DIR/bin" \
    "$APK_DIR/gen/com/remotecam/max/R.java" \
    "$APK_DIR/src/com/remotecam/max/MainActivity.java"

echo "=== 3. Dexing classes with dalvik-exchange ==="
/usr/bin/dalvik-exchange --dex --output="$APK_DIR/bin/classes.dex" "$APK_DIR/bin"

echo "=== 4. Packaging APK with aapt ==="
aapt package -f \
    -M "$APK_DIR/AndroidManifest.xml" \
    -S "$APK_DIR/res" \
    -I /tmp/android.jar \
    -F "$APK_DIR/bin/unaligned.apk"

echo "=== 5. Adding classes.dex to APK ==="
(cd "$APK_DIR/bin" && aapt add unaligned.apk classes.dex)

echo "=== 6. Aligning APK with zipalign ==="
zipalign -f -p 4 "$APK_DIR/bin/unaligned.apk" "$APK_DIR/bin/aligned.apk"

echo "=== 7. Generating Debug Keystore ==="
if [ ! -f "$APK_DIR/debug.keystore" ]; then
    keytool -genkey -v \
        -keystore "$APK_DIR/debug.keystore" \
        -alias androiddebugkey \
        -keypass android \
        -storepass android \
        -keyalg RSA \
        -keysize 2048 \
        -validity 10000 \
        -dname "CN=AndroidDebug,O=Android,C=US"
fi

echo "=== 8. Signing APK with apksigner ==="
apksigner sign \
    --ks "$APK_DIR/debug.keystore" \
    --ks-pass pass:android \
    --key-pass pass:android \
    --out "$APK_DIR/bin/RemoteCamMax.apk" \
    "$APK_DIR/bin/aligned.apk"

echo "=== 9. Verifying signed APK ==="
apksigner verify "$APK_DIR/bin/RemoteCamMax.apk"

echo "=== 10. Copying APK to public and dist directories ==="
mkdir -p /app/applet/public /app/applet/dist
cp "$APK_DIR/bin/RemoteCamMax.apk" /app/applet/public/RemoteCamMax.apk
cp "$APK_DIR/bin/RemoteCamMax.apk" /app/applet/dist/RemoteCamMax.apk

echo "SUCCESS! RemoteCamMax.apk has been generated and signed!"
ls -lh /app/applet/public/RemoteCamMax.apk
