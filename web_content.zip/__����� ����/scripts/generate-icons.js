import { PNG } from 'pngjs';
import fs from 'fs';
import path from 'path';

function createIcon(size, isMaskable = false) {
  const png = new PNG({ width: size, height: size });
  const center = size / 2;
  const radius = size * 0.42;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (size * y + x) << 2;
      const dx = x - center;
      const dy = y - center;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Dark background with emerald gradient
      const bgR = 15 + Math.round((y / size) * 5);
      const bgG = 23 + Math.round((y / size) * 20);
      const bgB = 42 + Math.round((x / size) * 5);

      if (dist < radius) {
        // Outer green ring
        if (dist > radius - size * 0.05) {
          png.data[idx] = 16;
          png.data[idx + 1] = 185;
          png.data[idx + 2] = 129;
          png.data[idx + 3] = 255;
        } else if (dist > radius - size * 0.12) {
          // Lens bezel
          png.data[idx] = 30;
          png.data[idx + 1] = 41;
          png.data[idx + 2] = 59;
          png.data[idx + 3] = 255;
        } else if (dist > radius - size * 0.22) {
          // Dark lens aperture
          png.data[idx] = 10;
          png.data[idx + 1] = 15;
          png.data[idx + 2] = 25;
          png.data[idx + 3] = 255;
        } else {
          // Inner emerald sensor
          png.data[idx] = 5;
          png.data[idx + 1] = 150;
          png.data[idx + 2] = 105;
          png.data[idx + 3] = 255;
        }

        // Glare spot
        if (Math.hypot(x - (center - size * 0.08), y - (center - size * 0.08)) < size * 0.04) {
          png.data[idx] = 255;
          png.data[idx + 1] = 255;
          png.data[idx + 2] = 255;
          png.data[idx + 3] = 220;
        }
      } else {
        // Outside lens
        png.data[idx] = bgR;
        png.data[idx + 1] = bgG;
        png.data[idx + 2] = bgB;
        png.data[idx + 3] = 255;
      }
    }
  }

  return PNG.sync.write(png);
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir, { recursive: true });

fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createIcon(192));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createIcon(512));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createIcon(180));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createIcon(512, true));

console.log('PWA icons created successfully in public/');
