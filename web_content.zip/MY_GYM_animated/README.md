# MY GYM – Animated HTML-to-APK version

Premium motion and MY GYM branding were added while preserving the existing app logic.

- CSS-only animations; no external libraries
- Animated MY GYM logo on the Dashboard
- Card entrance animations
- Button press feedback
- Progress/number pop animation
- Completed workout pulse
- Reduced-motion support
- Suitable for HTML-to-APK/WebView packaging

## App icon
- `icons/` – web/PWA icons (favicon, apple-touch, 192, 512, maskable) linked in index.html + manifest.webmanifest
- `android-res/` – ic_launcher / ic_launcher_round for every density (copy mipmap-* into app/src/main/res) and a 512px Play Store icon
- For APK builders (Median, WebIntoApp, etc.) upload `icons/icon-512.png`

## Theme
Colours and animations are synced to the logo: pink #ee3c8a, purple #804aba, blue #59b1df (buttons, bars, title shimmer, logo glow, card glows).
