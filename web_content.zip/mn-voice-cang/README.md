# MN Voice Cang – AI Voice Processing Studio

A modern, futuristic AI voice studio website with a dark theme, mobile-first design, and clear backend integration points.

## Features

- **Text to Voice** – Convert text into natural AI speech (Bangla, English, Hindi, Arabic, Spanish)
- **AI Voice Changer** – Safe effects only: Deep, High, Robot, Echo, Radio, Cartoon, Reverb, Chipmunk
- **Language Convert** – Speech → text → translation → natural AI voice in target language
- Preview with Play / Pause / Stop + waveform visualization
- Download processed audio
- Upload audio (user must own or have permission)
- Secure client-side deletion of audio blobs
- Clear safety messaging: **no voice cloning, no impersonation, no deceptive use**

## Design

- Futuristic dark theme (cyan / purple / magenta accents)
- “MN Voice Cang” branding with animated logo
- Mobile-first responsive layout (Android, tablets, desktop)
- Processing animation + progress bar + audio waveform
- Toast notifications and clear error states

## Quick Start (Frontend Demo)

1. Open `index.html` in a modern browser, **or**
2. Serve the folder with any static server:

```bash
# Example with Python
cd mn-voice-cang
python -m http.server 8080
```

Then visit `http://localhost:8080`.

The current build runs in **demo mode**:
- Text-to-Speech uses the browser Web Speech API for live preview + a generated demo WAV for download.
- Voice Changer and Language Convert simulate processing and return the uploaded (or demo) audio.
- All UI, animations, waveform, controls, upload/delete flows are fully functional.

## Production Backend Integration

Keep **all API keys on the server**. Never put them in frontend code.

Suggested endpoints (see comments at the bottom of `js/app.js`):

| Method | Endpoint              | Purpose                          |
|--------|-----------------------|----------------------------------|
| POST   | `/api/tts`            | Text → Speech                    |
| POST   | `/api/voice-change`   | Apply safe audio effect          |
| POST   | `/api/translate`      | Speech translation + TTS         |
| DELETE | `/api/audio/:id`      | Secure file deletion             |

Recommended services (server-side only):

- Google Cloud Speech-to-Text + Translation + Text-to-Speech
- Azure Cognitive Services (Speech + Translator)
- Amazon Polly + Transcribe + Translate
- OpenAI Whisper + TTS
- ElevenLabs (high-quality TTS – disable any cloning features)

### Safety Requirements (must enforce on backend)

1. Only accept audio the user confirms they own or have permission to process.
2. Do **not** offer voice cloning, speaker identity transfer, or impersonation features.
3. Validate MIME type and size (max 20 MB recommended).
4. Auto-expire temporary files and provide immediate deletion.
5. Rate-limit and log only non-PII metadata.
6. Return clear, user-friendly error messages.

## File Structure

```
mn-voice-cang/
├── index.html          # Single-page app
├── css/
│   └── styles.css      # Dark futuristic theme + responsive
├── js/
│   └── app.js          # UI logic, audio controls, demo processing
├── assets/             # (optional logos / icons)
├── uploads/            # (server-side only – never serve publicly)
└── README.md
```

## Browser Support

- Chrome / Edge / Firefox / Safari (recent versions)
- Web Speech API for live TTS preview (varies by browser & language support)
- AudioContext for waveform visualization

## License & Responsible Use

Built for creative and accessibility-friendly voice processing.  
Users are responsible for ensuring they have the right to process any uploaded audio.  
MN Voice Cang deliberately excludes voice-cloning and impersonation capabilities.
