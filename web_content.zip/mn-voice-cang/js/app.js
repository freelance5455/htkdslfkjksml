/* ===== MN Voice Cang – Frontend Application =====
   Demo mode with browser APIs + simulated backend endpoints.
   Replace API_BASE with your real backend URL for production.
*/

const API_BASE = '/api'; // Backend integration point – keep keys server-side only

// ===== State =====
const state = {
  currentPage: 'home',
  selectedEffect: null,
  audioBlobs: {
    tts: null,
    changer: null,
    translate: null
  },
  audioUrls: {
    tts: null,
    changer: null,
    translate: null
  },
  uploadedFiles: {
    changer: null,
    translate: null
  }
};

// ===== Navigation =====
function showPage(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));

  const el = document.getElementById(`page-${page}`);
  if (el) {
    el.classList.add('active');
    state.currentPage = page;
  }

  const navBtn = document.querySelector(`.nav-btn[data-page="${page}"]`);
  if (navBtn) navBtn.classList.add('active');

  closeMobileNav();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showHome() {
  showPage('home');
}

function closeMobileNav() {
  document.getElementById('mobileNav').classList.remove('open');
}

document.getElementById('menuToggle').addEventListener('click', () => {
  document.getElementById('mobileNav').classList.toggle('open');
});

// ===== Toast =====
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icons = { success: '✅', error: '❌', warning: '⚠️' };
  toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = '0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ===== Text-to-Speech Character Count =====
const ttsText = document.getElementById('ttsText');
if (ttsText) {
  ttsText.addEventListener('input', () => {
    const count = ttsText.value.length;
    document.getElementById('ttsCharCount').textContent = count;
    if (count > 2000) {
      ttsText.value = ttsText.value.slice(0, 2000);
      document.getElementById('ttsCharCount').textContent = 2000;
    }
  });
}

// ===== Upload Zones =====
function setupUploadZone(zoneId, inputId, infoId, nameId, key) {
  const zone = document.getElementById(zoneId);
  const input = document.getElementById(inputId);
  const info = document.getElementById(infoId);
  const nameEl = document.getElementById(nameId);

  zone.addEventListener('click', () => input.click());

  zone.addEventListener('dragover', (e) => {
    e.preventDefault();
    zone.classList.add('dragover');
  });

  zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));

  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    zone.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
      handleFile(e.dataTransfer.files[0], key, info, nameEl, zone);
    }
  });

  input.addEventListener('change', () => {
    if (input.files.length) {
      handleFile(input.files[0], key, info, nameEl, zone);
    }
  });
}

function handleFile(file, key, infoEl, nameEl, zoneEl) {
  const allowed = ['audio/mpeg', 'audio/wav', 'audio/mp4', 'audio/x-m4a', 'audio/ogg', 'audio/webm', 'audio/flac'];
  const maxSize = 20 * 1024 * 1024; // 20 MB

  if (!file.type.startsWith('audio/') && !allowed.includes(file.type)) {
    showToast('Please upload a valid audio file (MP3, WAV, M4A, OGG).', 'error');
    return;
  }
  if (file.size > maxSize) {
    showToast('File is too large. Maximum size is 20 MB.', 'error');
    return;
  }

  state.uploadedFiles[key] = file;
  nameEl.textContent = file.name;
  infoEl.classList.remove('hidden');
  zoneEl.classList.add('hidden');

  // Enable process button
  if (key === 'changer') {
    document.getElementById('changerProcessBtn').disabled = !state.selectedEffect;
  } else if (key === 'translate') {
    document.getElementById('translateProcessBtn').disabled = false;
  }

  showToast(`Uploaded: ${file.name}`, 'success');
}

function clearUpload(key) {
  state.uploadedFiles[key] = null;
  const zone = document.getElementById(`${key}UploadZone`);
  const info = document.getElementById(`${key}FileInfo`);
  const input = document.getElementById(`${key}FileInput`);

  zone.classList.remove('hidden');
  info.classList.add('hidden');
  if (input) input.value = '';

  if (key === 'changer') {
    document.getElementById('changerProcessBtn').disabled = true;
  } else if (key === 'translate') {
    document.getElementById('translateProcessBtn').disabled = true;
  }

  // Also clear any previous result
  deleteAudio(key);
}

setupUploadZone('changerUploadZone', 'changerFileInput', 'changerFileInfo', 'changerFileName', 'changer');
setupUploadZone('translateUploadZone', 'translateFileInput', 'translateFileInfo', 'translateFileName', 'translate');

// ===== Effect Selection =====
function selectEffect(btn) {
  document.querySelectorAll('.effect-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  state.selectedEffect = btn.dataset.effect;

  const hasFile = !!state.uploadedFiles.changer;
  document.getElementById('changerProcessBtn').disabled = !hasFile;
}

// ===== Progress Simulation =====
function simulateProgress(progressId, duration = 2500) {
  return new Promise(resolve => {
    const bar = document.getElementById(progressId);
    let progress = 0;
    const interval = 50;
    const step = 100 / (duration / interval);

    const timer = setInterval(() => {
      progress += step + Math.random() * 2;
      if (progress >= 100) {
        progress = 100;
        clearInterval(timer);
        bar.style.width = '100%';
        setTimeout(resolve, 200);
      } else {
        bar.style.width = progress + '%';
      }
    }, interval);
  });
}

// ===== Text to Speech (uses Web Speech API + simulated downloadable blob) =====
async function generateTTS() {
  const text = document.getElementById('ttsText').value.trim();
  if (!text) {
    showToast('Please enter some text first.', 'warning');
    return;
  }

  const lang = document.getElementById('ttsLang').value;
  const btn = document.getElementById('ttsGenerateBtn');
  const spinner = document.getElementById('ttsSpinner');
  const btnText = document.getElementById('ttsBtnText');
  const processing = document.getElementById('ttsProcessing');
  const player = document.getElementById('ttsPlayer');

  btn.disabled = true;
  spinner.classList.remove('hidden');
  btnText.textContent = 'Generating…';
  processing.classList.remove('hidden');
  player.classList.add('hidden');
  document.getElementById('ttsProgress').style.width = '0%';

  try {
    // Simulate backend processing time
    await simulateProgress('ttsProgress', 2000);

    // Use Web Speech API for preview
    if ('speechSynthesis' in window) {
      // Create a silent audio context trick or MediaRecorder if possible,
      // but for reliability we use speechSynthesis + a generated tone blob for download demo.
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 1;
      utterance.pitch = 1;

      // Try to pick a matching voice
      const voices = speechSynthesis.getVoices();
      const match = voices.find(v => v.lang.startsWith(lang.split('-')[0]));
      if (match) utterance.voice = match;

      // For demo download we generate a simple WAV with a tone + metadata note
      const blob = await generateDemoWav(text, lang);
      setAudioResult('tts', blob);

      // Also speak it
      speechSynthesis.cancel();
      speechSynthesis.speak(utterance);

      showToast('Speech generated successfully!', 'success');
    } else {
      // Fallback: pure demo blob
      const blob = await generateDemoWav(text, lang);
      setAudioResult('tts', blob);
      showToast('Speech generated (demo mode – browser TTS not available).', 'success');
    }
  } catch (err) {
    console.error(err);
    showToast('Failed to generate speech. Please try again.', 'error');
  } finally {
    btn.disabled = false;
    spinner.classList.add('hidden');
    btnText.textContent = 'Generate Speech';
    processing.classList.add('hidden');
  }
}

// ===== Voice Changer (simulated effects) =====
async function processVoiceChange() {
  if (!state.uploadedFiles.changer || !state.selectedEffect) {
    showToast('Please upload audio and select an effect.', 'warning');
    return;
  }

  const btn = document.getElementById('changerProcessBtn');
  const spinner = document.getElementById('changerSpinner');
  const btnText = document.getElementById('changerBtnText');
  const processing = document.getElementById('changerProcessing');
  const player = document.getElementById('changerPlayer');

  btn.disabled = true;
  spinner.classList.remove('hidden');
  btnText.textContent = 'Processing…';
  processing.classList.remove('hidden');
  player.classList.add('hidden');
  document.getElementById('changerProgress').style.width = '0%';

  try {
    // In production: POST to /api/voice-change with FormData + effect name
    // API keys stay on the backend.
    await simulateProgress('changerProgress', 2800);

    // Demo: create a modified version of the uploaded file as a new blob
    // (real implementation would apply DSP effects server-side)
    const file = state.uploadedFiles.changer;
    const arrayBuffer = await file.arrayBuffer();
    const blob = new Blob([arrayBuffer], { type: file.type || 'audio/mpeg' });

    // Tag the blob name so download reflects the effect
    setAudioResult('changer', blob, `${state.selectedEffect}_${file.name}`);

    showToast(`Applied “${state.selectedEffect}” effect successfully!`, 'success');
  } catch (err) {
    console.error(err);
    showToast('Voice processing failed. Please try again.', 'error');
  } finally {
    btn.disabled = false;
    spinner.classList.add('hidden');
    btnText.textContent = 'Apply Effect';
    processing.classList.add('hidden');
  }
}

// ===== Language Conversion (simulated) =====
async function processTranslation() {
  if (!state.uploadedFiles.translate) {
    showToast('Please upload an audio file first.', 'warning');
    return;
  }

  const srcLang = document.getElementById('srcLang').value;
  const tgtLang = document.getElementById('tgtLang').value;

  if (srcLang !== 'auto' && srcLang === tgtLang) {
    showToast('Source and target languages are the same.', 'warning');
    return;
  }

  const btn = document.getElementById('translateProcessBtn');
  const spinner = document.getElementById('translateSpinner');
  const btnText = document.getElementById('translateBtnText');
  const processing = document.getElementById('translateProcessing');
  const statusText = document.getElementById('translateStatusText');
  const player = document.getElementById('translatePlayer');
  const preview = document.getElementById('translatePreview');

  btn.disabled = true;
  spinner.classList.remove('hidden');
  btnText.textContent = 'Converting…';
  processing.classList.remove('hidden');
  player.classList.add('hidden');
  preview.classList.add('hidden');
  document.getElementById('translateProgress').style.width = '0%';

  try {
    statusText.textContent = 'Transcribing speech…';
    await simulateProgress('translateProgress', 1500);

    statusText.textContent = 'Translating meaning…';
    document.getElementById('translateProgress').style.width = '0%';
    await simulateProgress('translateProgress', 1200);

    statusText.textContent = 'Generating natural AI voice…';
    document.getElementById('translateProgress').style.width = '0%';
    await simulateProgress('translateProgress', 1500);

    // Demo texts (in production these come from STT + MT APIs)
    const demoOriginals = {
      en: 'Hello, welcome to MN Voice Cang. This is a demonstration of speech translation.',
      bn: 'হ্যালো, এমএন ভয়েস কাং-এ স্বাগতম। এটি স্পিচ অনুবাদের একটি প্রদর্শনী।',
      hi: 'नमस्ते, एमएन वॉइस कांग में आपका स्वागत है। यह स्पीच अनुवाद का एक प्रदर्शन है।',
      ar: 'مرحبًا، أهلاً بكم في إم إن فويس كانغ. هذا عرض توضيحي لترجمة الكلام.',
      es: 'Hola, bienvenido a MN Voice Cang. Esta es una demostración de traducción de voz.'
    };

    const demoTranslations = {
      en: 'Hello, welcome to MN Voice Cang. This is a demonstration of speech translation.',
      bn: 'হ্যালো, এমএন ভয়েস কাং-এ স্বাগতম। এটি স্পিচ অনুবাদের একটি প্রদর্শনী।',
      hi: 'नमस्ते, एमएन वॉइस कांग में आपका स्वागत है। यह स्पीच अनुवाद का एक प्रदर्शन है।',
      ar: 'مرحبًا، أهلاً بكم في إم إن فويس كانغ. هذا عرض توضيحي لترجمة الكلام.',
      es: 'Hola, bienvenido a MN Voice Cang. Esta es una demostración de traducción de voz.'
    };

    const detected = srcLang === 'auto' ? 'en' : srcLang;
    document.getElementById('originalText').textContent = demoOriginals[detected] || demoOriginals.en;
    document.getElementById('translatedText').textContent = demoTranslations[tgtLang] || demoTranslations.en;
    preview.classList.remove('hidden');

    // Generate demo audio for the target language
    const blob = await generateDemoWav(demoTranslations[tgtLang] || 'Translated speech', tgtLang);
    setAudioResult('translate', blob, `translated_${tgtLang}.wav`);

    showToast('Language conversion complete!', 'success');
  } catch (err) {
    console.error(err);
    showToast('Translation failed. Please try again.', 'error');
  } finally {
    btn.disabled = false;
    spinner.classList.add('hidden');
    btnText.textContent = 'Convert Language';
    processing.classList.add('hidden');
  }
}

// ===== Audio Result Handling =====
function setAudioResult(key, blob, filename = null) {
  // Revoke previous URL
  if (state.audioUrls[key]) {
    URL.revokeObjectURL(state.audioUrls[key]);
  }

  state.audioBlobs[key] = blob;
  state.audioUrls[key] = URL.createObjectURL(blob);
  if (filename) state[`filename_${key}`] = filename;

  const audio = document.getElementById(`${key}Audio`);
  const player = document.getElementById(`${key}Player`);
  const playBtn = document.getElementById(`${key}PlayBtn`);

  audio.src = state.audioUrls[key];
  player.classList.remove('hidden');
  playBtn.textContent = '▶';

  // Draw waveform
  drawWaveform(key, blob);

  // Setup time updates
  audio.onloadedmetadata = () => {
    document.getElementById(`${key}Duration`).textContent = formatTime(audio.duration);
  };

  audio.ontimeupdate = () => {
    if (!audio.duration) return;
    const pct = (audio.currentTime / audio.duration) * 100;
    document.getElementById(`${key}Seek`).value = pct;
    document.getElementById(`${key}Current`).textContent = formatTime(audio.currentTime);
  };

  audio.onended = () => {
    playBtn.textContent = '▶';
  };

  // Seek
  const seek = document.getElementById(`${key}Seek`);
  seek.oninput = () => {
    if (audio.duration) {
      audio.currentTime = (seek.value / 100) * audio.duration;
    }
  };
}

function togglePlay(key) {
  const audio = document.getElementById(`${key}Audio`);
  const playBtn = document.getElementById(`${key}PlayBtn`);

  if (audio.paused) {
    // Pause others
    ['tts', 'changer', 'translate'].forEach(k => {
      if (k !== key) {
        const a = document.getElementById(`${k}Audio`);
        if (a && !a.paused) {
          a.pause();
          document.getElementById(`${k}PlayBtn`).textContent = '▶';
        }
      }
    });
    audio.play();
    playBtn.textContent = '⏸';
  } else {
    audio.pause();
    playBtn.textContent = '▶';
  }
}

function stopAudio(key) {
  const audio = document.getElementById(`${key}Audio`);
  const playBtn = document.getElementById(`${key}PlayBtn`);
  audio.pause();
  audio.currentTime = 0;
  playBtn.textContent = '▶';
  document.getElementById(`${key}Seek`).value = 0;
  document.getElementById(`${key}Current`).textContent = '0:00';
}

function downloadAudio(key) {
  const blob = state.audioBlobs[key];
  if (!blob) {
    showToast('No audio available to download.', 'warning');
    return;
  }

  const url = state.audioUrls[key];
  const a = document.createElement('a');
  a.href = url;
  a.download = state[`filename_${key}`] || `mn-voice-cang-${key}-${Date.now()}.wav`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  showToast('Download started!', 'success');
}

function deleteAudio(key) {
  if (state.audioUrls[key]) {
    URL.revokeObjectURL(state.audioUrls[key]);
  }
  state.audioBlobs[key] = null;
  state.audioUrls[key] = null;

  const audio = document.getElementById(`${key}Audio`);
  const player = document.getElementById(`${key}Player`);
  if (audio) {
    audio.src = '';
    audio.load();
  }
  if (player) player.classList.add('hidden');

  // Clear translation preview if applicable
  if (key === 'translate') {
    const preview = document.getElementById('translatePreview');
    if (preview) preview.classList.add('hidden');
  }

  showToast('Audio deleted securely.', 'success');
}

// ===== Waveform Drawing =====
async function drawWaveform(key, blob) {
  const canvas = document.getElementById(`${key}Canvas`);
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.parentElement.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = 60 * dpr;
  canvas.style.width = rect.width + 'px';
  canvas.style.height = '60px';
  ctx.scale(dpr, dpr);

  try {
    const arrayBuffer = await blob.arrayBuffer();
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer.slice(0));
    const data = audioBuffer.getChannelData(0);
    const width = rect.width;
    const height = 60;
    const step = Math.ceil(data.length / width);
    const amp = height / 2;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = 'rgba(0, 240, 255, 0.15)';
    ctx.fillRect(0, 0, width, height);

    ctx.beginPath();
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 1.5;

    for (let i = 0; i < width; i++) {
      let min = 1.0;
      let max = -1.0;
      for (let j = 0; j < step; j++) {
        const datum = data[(i * step) + j];
        if (datum < min) min = datum;
        if (datum > max) max = datum;
      }
      const y1 = (1 + min) * amp;
      const y2 = (1 + max) * amp;
      ctx.moveTo(i, y1);
      ctx.lineTo(i, y2);
    }
    ctx.stroke();

    // Gradient overlay
    const grad = ctx.createLinearGradient(0, 0, width, 0);
    grad.addColorStop(0, 'rgba(0, 240, 255, 0.1)');
    grad.addColorStop(0.5, 'rgba(123, 44, 191, 0.15)');
    grad.addColorStop(1, 'rgba(255, 0, 170, 0.1)');
    ctx.fillStyle = grad;
    ctx.globalCompositeOperation = 'source-atop';
    ctx.fillRect(0, 0, width, height);
    ctx.globalCompositeOperation = 'source-over';

    audioCtx.close();
  } catch (e) {
    // Fallback visual waveform
    ctx.clearRect(0, 0, rect.width, 60);
    ctx.fillStyle = 'rgba(0, 240, 255, 0.1)';
    ctx.fillRect(0, 0, rect.width, 60);
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    for (let i = 0; i < rect.width; i += 3) {
      const h = 10 + Math.random() * 40;
      ctx.moveTo(i, 30 - h / 2);
      ctx.lineTo(i, 30 + h / 2);
    }
    ctx.stroke();
  }
}

// ===== Demo WAV Generator (for TTS / translation preview) =====
function generateDemoWav(text, lang) {
  return new Promise(resolve => {
    const sampleRate = 22050;
    const duration = Math.min(8, Math.max(2, text.length * 0.06));
    const numSamples = Math.floor(sampleRate * duration);
    const buffer = new ArrayBuffer(44 + numSamples * 2);
    const view = new DataView(buffer);

    // WAV header
    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + numSamples * 2, true);
    writeString(view, 8, 'WAVE');
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(view, 36, 'data');
    view.setUint32(40, numSamples * 2, true);

    // Simple modulated tone (placeholder for real TTS)
    const baseFreq = lang.startsWith('ar') ? 180 : lang.startsWith('hi') || lang.startsWith('bn') ? 200 : 220;
    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;
      const envelope = Math.sin(Math.PI * t / duration);
      const freq = baseFreq + 30 * Math.sin(2 * Math.PI * 0.5 * t);
      const sample = Math.sin(2 * Math.PI * freq * t) * envelope * 0.3;
      view.setInt16(44 + i * 2, sample * 0x7FFF, true);
    }

    resolve(new Blob([buffer], { type: 'audio/wav' }));
  });
}

function writeString(view, offset, str) {
  for (let i = 0; i < str.length; i++) {
    view.setUint8(offset + i, str.charCodeAt(i));
  }
}

function formatTime(sec) {
  if (!isFinite(sec)) return '0:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

// ===== Particles (subtle) =====
function createParticles() {
  const container = document.getElementById('particles');
  if (!container) return;
  for (let i = 0; i < 30; i++) {
    const p = document.createElement('div');
    p.style.cssText = `
      position: absolute;
      width: ${2 + Math.random() * 3}px;
      height: ${2 + Math.random() * 3}px;
      background: ${Math.random() > 0.5 ? 'rgba(0,240,255,0.4)' : 'rgba(123,44,191,0.4)'};
      border-radius: 50%;
      left: ${Math.random() * 100}%;
      top: ${Math.random() * 100}%;
      animation: float ${8 + Math.random() * 12}s linear infinite;
      opacity: ${0.2 + Math.random() * 0.5};
    `;
    container.appendChild(p);
  }
}

// Add float animation
const style = document.createElement('style');
style.textContent = `
  @keyframes float {
    0% { transform: translateY(0) translateX(0); }
    25% { transform: translateY(-20px) translateX(10px); }
    50% { transform: translateY(-10px) translateX(-10px); }
    75% { transform: translateY(-30px) translateX(5px); }
    100% { transform: translateY(0) translateX(0); }
  }
`;
document.head.appendChild(style);

// ===== Init =====
document.addEventListener('DOMContentLoaded', () => {
  createParticles();
  // Preload voices for Web Speech API
  if ('speechSynthesis' in window) {
    speechSynthesis.getVoices();
    speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices();
  }
});

// ===== Backend Integration Notes (for production) =====
/*
  Recommended API endpoints (implement on your server, never expose keys):

  POST /api/tts
    Body: { text, language, style }
    Response: { audioUrl } or binary audio stream

  POST /api/voice-change
    Body: FormData { audio: File, effect: string }
    Response: binary audio

  POST /api/translate
    Body: FormData { audio: File, sourceLang, targetLang }
    Response: { originalText, translatedText, audioUrl }

  DELETE /api/audio/:id
    Securely deletes uploaded & processed files

  Services that work well (keys stay server-side):
  - Google Cloud Text-to-Speech + Speech-to-Text + Translation
  - Azure Cognitive Services (Speech + Translator)
  - Amazon Polly + Transcribe + Translate
  - ElevenLabs (for high-quality TTS – use carefully, no cloning features)
  - OpenAI Whisper + TTS (for transcription + synthesis)

  Always:
  - Validate file type & size server-side
  - Require user confirmation of ownership/permission
  - Auto-expire / allow manual deletion of files
  - Rate-limit endpoints
  - Log only non-PII metadata
*/
