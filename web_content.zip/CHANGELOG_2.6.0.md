# ANONYMOUX STUDIOS 2.6.0 — Fish Audio Voice & Agent Rebuild

## Dashboard and navigation
- Reorganized the authenticated user sidebar into Dashboard, Creative Workspaces, AI Creation, Your Library, Account and Administration groups across both shared-shell pages and the separately-rendered Realtime Studio page.
- Renamed Voice Studio to Voice Cloning Studio and Video Studio to Video Edit Studio.
- Added AI Agent Studio and WhatsApp Deployments navigation destinations.
- Corrected active states for agent conversations and WhatsApp setup navigation.
- Replaced legacy green accents in the user dashboard, sidebar, voice workspace and agent workspace with the official black/red palette.
- Replaced generic/duplicate dashboard shortcuts with direct links to the six actual creative workspaces.

## Voice Cloning Studio
- Added Fish Audio persistent private voice creation through the documented `POST /model` multipart API.
- Added sample upload, optional browser Ogg/Opus recording, consent confirmation, private voice library, selection and owner-only deletion.
- Added server-side audio extension, MIME, signature and size validation.
- Added per-user private voice ownership enforcement across TTS and agent creation, update and session start.
- Prevented private voice models from appearing in another user's provider voice list.
- Added clone request idempotency and optional administrator-configured clone credits (default 0).
- Kept existing speech generation, voice browsing, favorites, preview, playback, generation history and wallet idempotency.

## AI Agent Studio
- Rebuilt the standalone Agent Studio layout with searchable/filterable agent cards and a cleaner creation/edit dialog.
- Added private cloned voices to the agent voice picker.
- Added Fish Audio-supported speaking language, Drama 3 / S2.1 Pro model, speed and expressive settings.
- Explicitly sets the Fish TTS engine when using these agent voice settings.
- Editing a published agent marks its configuration as Draft; users must publish again to apply changes to live sessions.
- Added WhatsApp Business Calling setup guidance without inventing a number-import API or connection state.

## Administration and billing
- Added an authenticated Fish Audio connection-test action using a real provider voice-list request.
- Added configurable credits per private voice clone; defaults to disabled until configured by an administrator.
- Removed the implicit default Agent USD/minute assumption; provider rate remains zero until configured by the administrator.

## Database
- Added migration 007 for private voice ownership and idempotent clone requests (SQLite and MySQL).
- Existing database records and prior migrations remain additive and preserved.
