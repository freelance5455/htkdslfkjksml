// ========== AI BRAIN - improved individual knowledge + varied chat ==========

const AIBrain = {
    update(bot, dt, game) {
        if (!bot.isAlive || game.phase !== 'playing') {
            bot.vx = 0; bot.vy = 0;
            return;
        }

        // Vent travel / exit
        if (bot.inVent && bot._ventTravel && bot.stateTimer <= 0) {
            bot._ventTravel = false;
            const curr = bot.currentVent;
            if (curr && curr.connections.length && Math.random() < 0.7) {
                const tid = randomChoice(curr.connections);
                const tv = MAP.vents.find(v => v.id === tid);
                if (tv) bot.travelVent(tv);
            }
            // exit after another short wait
            bot.stateTimer = 800 + Math.random() * 1200;
            bot._ventExit = true;
        }
        if (bot.inVent && bot._ventExit && bot.stateTimer <= 0) {
            bot._ventExit = false;
            bot.exitVent();
            bot.state = 'idle';
        }

        this.updateVision(bot, game);

        // Crewmates report bodies they see
        if (!bot.isImpostor) {
            for (const other of game.crewmates) {
                if (other.isAlive) continue;
                if (bot.knowledge.reportedBodies.has(other.id)) continue;
                if (dist(bot, other) < 55) {
                    bot.knowledge.reportedBodies.add(other.id);
                    if (Math.random() < 0.75) {
                        game.meeting.start(bot, other);
                        return;
                    }
                }
            }
        }

        switch (bot.state) {
            case 'idle':
                this.decideNextAction(bot, game);
                break;
            case 'walking':
            case 'hunt':
                this.walkToTarget(bot, dt, game);
                break;
            case 'task':
                this.doTask(bot, dt, game);
                break;
            case 'fake_task':
                this.doFakeTask(bot, dt, game);
                break;
            default:
                bot.state = 'idle';
        }
    },

    updateVision(bot, game) {
        const range = 170;
        for (const other of game.crewmates) {
            if (other.id === bot.id) continue;
            // Saw someone enter/exit vent nearby
            if (other.inVent && dist(bot, other) < 90 && other.isImpostor) {
                bot.knowledge.susLevel[other.id] = (bot.knowledge.susLevel[other.id] || 0) + 35;
                bot.knowledge.statements.push({
                    fromId: -1, text: `vi ${other.name} entrando na vent`, time: game.time
                });
            }
            if (other.inVent) continue;
            if (dist(bot, other) < range) {
                if (other.isAlive) {
                    bot.knowledge.lastSeen[other.id] = {
                        x: other.x, y: other.y,
                        room: getRoomAt(other.x, other.y)?.name || 'corredor',
                        time: game.time
                    };
                } else {
                    const already = bot.knowledge.seenBodies.find(b => b.bodyId === other.id);
                    if (!already) {
                        bot.knowledge.seenBodies.push({
                            bodyId: other.id,
                            room: getRoomAt(other.x, other.y)?.name || '?',
                            time: game.time
                        });
                        for (const [id, seen] of Object.entries(bot.knowledge.lastSeen)) {
                            if (game.time - seen.time < 10000 && Math.hypot(seen.x - other.x, seen.y - other.y) < 120) {
                                bot.knowledge.susLevel[id] = (bot.knowledge.susLevel[id] || 0) + 30;
                            }
                        }
                    }
                }
            }
        }
    },

    decideNextAction(bot, game) {
        if (bot.stateTimer > 0) return;

        if (bot.isImpostor) {
            // Use sabotage sometimes if none active
            if (!game.sabotageActive && Math.random() < 0.12) {
                const types = ['lights', 'reactor', 'doors'];
                const t = randomChoice(types);
                if (t === 'lights') {
                    game.lightsSabotaged = true;
                    game.sabotageActive = 'lights';
                    game.sabotageTimer = 30000;
                    game.fixFix = { x: 6*40, y: 15.5*40, name: 'Consertar Luzes' };
                } else if (t === 'reactor') {
                    game.sabotageActive = 'reactor';
                    game.sabotageTimer = 40000;
                    game.reactorMeltdown = true;
                    game.fixFix = { x: 2.5*40, y: 7*40, name: 'Estabilizar Reactor' };
                } else {
                    game.sabotageActive = 'doors';
                    game.sabotageTimer = 18000;
                    game.doorsLocked = true;
                }
                bot.stateTimer = 2000;
                return;
            }

            // Use vents sometimes
            if (!bot.inVent && Math.random() < 0.18) {
                const v = randomChoice(MAP.vents);
                bot.targetX = v.x; bot.targetY = v.y;
                bot.state = 'walking';
                bot._wantVent = true;
                return;
            }

            // Smart kill
            const nearbyCrew = game.crewmates.filter(c =>
                c.isAlive && !c.isImpostor && c.id !== bot.id && dist(bot, c) < 190
            );
            const witnesses = nearbyCrew.length;
            if (witnesses >= 1 && witnesses <= 2 && bot.killCooldown <= 0 && Math.random() < (witnesses === 1 ? 0.55 : 0.2)) {
                const target = nearbyCrew.reduce((a, b) => dist(bot, a) < dist(bot, b) ? a : b);
                bot.state = 'hunt';
                bot.targetX = target.x;
                bot.targetY = target.y;
                bot.stateTimer = 4500;
                return;
            }

            if (Math.random() < 0.35) {
                const t = randomChoice(MAP.tasks);
                bot.targetX = t.x; bot.targetY = t.y;
                bot.state = 'walking';
                bot.fakeTask = true;
                bot._pendingFake = t;
                return;
            }
        } else {
            // Crew: prioritize fixing sabotage
            if (game.sabotageActive && game.fixFix && Math.random() < 0.7) {
                bot.targetX = game.fixFix.x;
                bot.targetY = game.fixFix.y;
                bot.state = 'walking';
                bot._goingToFix = true;
                return;
            }

            const rem = bot.assignedTasks.filter(t => !bot.completedTasks.has(t.id));
            if (rem.length && Math.random() < 0.75) {
                const t = randomChoice(rem);
                bot.targetX = t.x; bot.targetY = t.y;
                bot.state = 'walking';
                bot._pendingTask = t;
                return;
            }
        }

        const room = randomChoice(MAP.rooms);
        bot.targetX = room.x + 30 + Math.random() * (room.w - 60);
        bot.targetY = room.y + 30 + Math.random() * (room.h - 60);
        bot.state = 'walking';
    },

    walkToTarget(bot, dt, game) {
        const dx = bot.targetX - bot.x;
        const dy = bot.targetY - bot.y;
        const d = Math.hypot(dx, dy) || 1;

        if (bot.stuckTimer > 400) {
            bot.vx = -dy / d * bot.speed * 0.7 + (Math.random() - 0.5) * 40;
            bot.vy = dx / d * bot.speed * 0.7 + (Math.random() - 0.5) * 40;
        } else {
            bot.vx = (dx / d) * bot.speed * 0.9;
            bot.vy = (dy / d) * bot.speed * 0.9;
        }

        if (d < 28) {
            bot.vx = 0; bot.vy = 0;
            if (bot._wantVent) {
                bot._wantVent = false;
                let nv = null, nd = 45;
                for (const v of MAP.vents) {
                    const dd = dist(bot, v);
                    if (dd < nd) { nd = dd; nv = v; }
                }
                if (nv) {
                    bot.enterVent(nv);
                    bot._ventTravel = true;
                    bot.stateTimer = 1200 + Math.random() * 2000;
                }
                bot.state = 'idle';
            } else if (bot._goingToFix && game.fixFix) {
                bot._goingToFix = false;
                bot.state = 'task';
                bot.doingTask = { id: 'fix', name: game.fixFix.name, duration: 4500 };
                bot.taskProgress = 0;
                bot._fixingSab = true;
            } else if (bot._pendingTask) {
                bot.state = 'task';
                bot.doingTask = bot._pendingTask;
                bot.taskProgress = 0;
                bot._pendingTask = null;
            } else if (bot.fakeTask && bot._pendingFake) {
                bot.state = 'fake_task';
                bot.doingTask = bot._pendingFake;
                bot.taskProgress = 0;
                bot._pendingFake = null;
            } else if (bot.state === 'hunt') {
                let best = null, bd = 999;
                for (const c of game.crewmates) {
                    if (c.isAlive && !c.isImpostor && c.id !== bot.id) {
                        const dd = dist(bot, c);
                        if (dd < bd) { bd = dd; best = c; }
                    }
                }
                if (best && bot.canKill(best)) bot.kill(best, game);
                bot.state = 'idle';
                bot.stateTimer = 1200;
            } else {
                bot.state = 'idle';
                bot.stateTimer = 600 + Math.random() * 1800;
            }
        }

        if (bot.state === 'hunt') {
            // Abort if too many witnesses appear
            const witnesses = game.crewmates.filter(c =>
                c.isAlive && !c.isImpostor && c.id !== bot.id && dist(bot, c) < 160
            ).length;
            if (witnesses >= 3) {
                bot.state = 'idle';
                bot.stateTimer = 800;
                return;
            }
            let best = null, bd = 999;
            for (const c of game.crewmates) {
                if (c.isAlive && !c.isImpostor && c.id !== bot.id) {
                    const dd = dist(bot, c);
                    if (dd < bd) { bd = dd; best = c; }
                }
            }
            if (best && bd < 250) {
                bot.targetX = best.x;
                bot.targetY = best.y;
                if (bot.canKill(best) && witnesses <= 2) {
                    bot.kill(best, game);
                    bot.state = 'idle';
                    bot.stateTimer = 1500;
                }
            } else {
                bot.state = 'idle';
            }
        }
    },

    doTask(bot, dt, game) {
        bot.vx = 0; bot.vy = 0;
        if (!bot.doingTask) { bot.state = 'idle'; return; }
        bot.taskProgress += dt * 1000;
        if (bot.taskProgress >= bot.doingTask.duration) {
            if (bot._fixingSab) {
                bot._fixingSab = false;
                game.completeSabotageFix();
                bot.doingTask = null;
                bot.taskProgress = 0;
                bot.state = 'idle';
                bot.stateTimer = 400;
            } else {
                bot.completedTasks.add(bot.doingTask.id);
                bot.doingTask = null;
                bot.taskProgress = 0;
                bot.state = 'idle';
                bot.stateTimer = 400;
                game.onTaskComplete(bot);
            }
        }
    },

    doFakeTask(bot, dt, game) {
        bot.vx = 0; bot.vy = 0;
        bot.taskProgress += dt * 1000;
        if (bot.taskProgress >= 2200 + Math.random() * 2500) {
            bot.doingTask = null;
            bot.taskProgress = 0;
            bot.fakeTask = false;
            bot.state = 'idle';
            bot.stateTimer = 300;
        }
    },

    generateChatResponse(bot, game, recentMessages) {
        if (!bot.isAlive) return null;
        if (game.time - bot.lastChatTime < bot.chatCooldown) return null;
        if (Math.random() > (game.gameMode === 'online' ? 0.38 : 0.5)) return null;

        // Online mode: try real generative AI
        if (game.gameMode === 'online') {
            this.generateOnlineChat(bot, game, recentMessages);
            return null; // async, will add message later
        }

        // ===== OFFLINE (local templates) =====
        return this.generateLocalChat(bot, game, recentMessages);
    },

    generateLocalChat(bot, game, recentMessages) {
        const myRoom = getRoomAt(bot.x, bot.y)?.name || 'corredor';
        const bodies = bot.knowledge.seenBodies;
        const kills = bot.knowledge.seenKills;
        const sus = Object.entries(bot.knowledge.susLevel)
            .filter(([id, v]) => v > 18)
            .sort((a, b) => b[1] - a[1]);
        const used = new Set(bot.recentPhrases.slice(-6));
        let candidates = [];

        const lastMsgs = recentMessages.slice(-5);
        for (const m of lastMsgs) {
            const low = (m.text || '').toLowerCase();
            if (low.includes(bot.name.toLowerCase()) && /sus|impostor|vote|vi |matou|é o/.test(low)) {
                candidates.push(
                    `Não fui eu, eu estava em ${myRoom} fazendo task.`,
                    `Mentira! Eu nem estava perto.`,
                    `Por que eu? Tem gente bem mais sus.`
                );
            }
        }
        if (bodies.length) {
            const b = bodies[bodies.length - 1];
            const vic = game.crewmates.find(c => c.id === b.bodyId);
            const vname = vic ? vic.name : 'alguém';
            candidates.push(
                `Eu achei o corpo de ${vname} em ${b.room}.`,
                `Corpo de ${vname} tava em ${b.room}, alguém viu quem saiu de lá?`
            );
        }
        if (kills.length) {
            const k = kills[kills.length - 1];
            const killer = game.crewmates.find(c => c.id === k.killerId);
            if (killer) {
                candidates.push(`Eu vi o ${killer.name} matando em ${k.room}!`, `Vote no ${killer.name}, eu vi a kill!`);
                bot.knowledge.susLevel[killer.id] = (bot.knowledge.susLevel[killer.id] || 0) + 50;
            }
        }
        if (sus.length) {
            const sp = game.crewmates.find(c => c.id === parseInt(sus[0][0]));
            if (sp && sp.isAlive) {
                candidates.push(`${sp.name} tá muito suspeito pra mim.`, `Eu acho que é o ${sp.name}.`);
            }
        }
        const othersAlive = game.crewmates.filter(c => c.isAlive && c.id !== bot.id);
        const randomName = othersAlive.length ? randomChoice(othersAlive).name : 'alguém';
        candidates.push(
            `Eu estava em ${myRoom} o tempo todo.`,
            `Alguém tem informação boa?`,
            `Onde o ${randomName} estava?`
        );
        candidates = candidates.filter(c => c && !used.has(c));
        if (!candidates.length) return null;
        const textOut = randomChoice(candidates);
        bot.recentPhrases.push(textOut);
        if (bot.recentPhrases.length > 8) bot.recentPhrases.shift();
        bot.lastChatTime = game.time;
        bot.chatCooldown = 4500 + Math.random() * 5000;
        bot.knowledge.statements.push({ fromId: bot.id, text: textOut, time: game.time });
        return textOut;
    },

    async generateOnlineChat(bot, game, recentMessages) {
        if (bot._generating) return;
        bot._generating = true;
        bot.lastChatTime = game.time;
        bot.chatCooldown = 5500 + Math.random() * 3500;

        const key = localStorage.getItem('groq_api_key') || '';
        if (!key) {
            const fallback = this.generateLocalChat(bot, game, recentMessages);
            if (fallback && game.meeting && game.meeting.active) game.meeting.addMessage(bot, fallback);
            bot._generating = false;
            return;
        }

        const myRoom = getRoomAt(bot.x, bot.y)?.name || 'corredor';
        const bodies = bot.knowledge.seenBodies.map(b => {
            const v = game.crewmates.find(c => c.id === b.bodyId);
            return (v ? v.name : '?') + ' em ' + b.room;
        }).join('; ') || 'nenhum';
        const susList = Object.entries(bot.knowledge.susLevel)
            .filter(([,v]) => v > 15)
            .sort((a,b) => b[1]-a[1])
            .slice(0,3)
            .map(([id]) => {
                const p = game.crewmates.find(c => c.id === parseInt(id));
                return p ? p.name : null;
            }).filter(Boolean).join(', ') || 'ninguém';
        const recent = recentMessages.slice(-5).map(m => (m.name || 'Sistema') + ': ' + (m.text || '')).join('\n') || '(nenhuma ainda)';
        const roleHint = bot.isImpostor
            ? 'Você é IMPOSTOR. Finja ser inocente. Nunca admita. Pode mentir e acusar outros.'
            : 'Você é TRIPULANTE inocente. Tente achar o impostor com base no que sabe.';

        const systemPrompt = 'Você joga Among Us. Responda SEMPRE em português brasileiro, com no máximo 2 frases curtas, como mensagem de chat de reunião. Sem aspas, sem explicação, só a fala.';
        const userPrompt = roleHint + '\nSeu nome: ' + bot.name + '\nSala atual: ' + myRoom + '\nCorpos que você viu: ' + bodies + '\nQuem você acha suspeito: ' + susList + '\nÚltimas mensagens do chat:\n' + recent + '\n\nEscreva sua próxima mensagem no chat:';

        let reply = null;
        try {
            const ctrl = new AbortController();
            const timer = setTimeout(() => ctrl.abort(), 9000);
            const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + key
                },
                body: JSON.stringify({
                    model: 'llama-3.1-8b-instant',
                    messages: [
                        { role: 'system', content: systemPrompt },
                        { role: 'user', content: userPrompt }
                    ],
                    temperature: 0.9,
                    max_tokens: 80
                }),
                signal: ctrl.signal
            });
            clearTimeout(timer);
            const data = await res.json();
            if (data && data.choices && data.choices[0] && data.choices[0].message) {
                reply = (data.choices[0].message.content || '').trim();
                reply = reply.replace(/^["']|["']$/g, '').split('\n')[0].slice(0, 120);
            }
            if (data && data.error) reply = null;
        } catch (e) {
            reply = null;
        }

        if (!reply || reply.length < 3) {
            reply = this.generateLocalChat(bot, game, recentMessages);
        }

        if (reply && game.meeting && game.meeting.active) {
            bot.recentPhrases.push(reply);
            if (bot.recentPhrases.length > 8) bot.recentPhrases.shift();
            bot.knowledge.statements.push({ fromId: bot.id, text: reply, time: game.time });
            const last = game.meeting.messages[game.meeting.messages.length - 1];
            if (!last || last.text !== reply) {
                game.meeting.addMessage(bot, reply);
            }
        }
        bot._generating = false;
    },

    decideVote(bot, game) {
        if (!bot.isAlive || bot.knowledge.hasVoted) return null;

        if (bot.isImpostor) {
            const crews = game.crewmates.filter(c => c.isAlive && !c.isImpostor && c.id !== bot.id);
            if (crews.length && Math.random() < 0.7) return randomChoice(crews).id;
            return 'skip';
        }

        const sus = Object.entries(bot.knowledge.susLevel)
            .filter(([id]) => {
                const p = game.crewmates.find(c => c.id === parseInt(id));
                return p && p.isAlive;
            })
            .sort((a, b) => b[1] - a[1]);

        if (sus.length && sus[0][1] > 25) return parseInt(sus[0][0]);

        if (bot.knowledge.seenKills.length) {
            const k = bot.knowledge.seenKills[bot.knowledge.seenKills.length - 1];
            const killer = game.crewmates.find(c => c.id === k.killerId);
            if (killer && killer.isAlive) return killer.id;
        }

        if (Math.random() < 0.5) return 'skip';
        const others = game.crewmates.filter(c => c.isAlive && c.id !== bot.id);
        return others.length ? randomChoice(others).id : 'skip';
    },

    hearMessage(bot, fromId, text, game) {
        if (fromId === bot.id) return;
        bot.knowledge.statements.push({ fromId, text, time: game.time });

        const low = text.toLowerCase();
        for (const c of game.crewmates) {
            if (c.id === bot.id) continue;
            if (low.includes(c.name.toLowerCase())) {
                if (/sus|impostor|vote|matou|vi o|é o/.test(low)) {
                    bot.knowledge.susLevel[c.id] = (bot.knowledge.susLevel[c.id] || 0) + 15;
                }
                if (/inocente|crew|confia|não foi/.test(low)) {
                    bot.knowledge.susLevel[c.id] = (bot.knowledge.susLevel[c.id] || 0) - 10;
                }
            }
        }
        if (/não fui|mentira|eu sou crew|estava fazendo/.test(low)) {
            bot.knowledge.susLevel[fromId] = (bot.knowledge.susLevel[fromId] || 0) - 6;
        }
    }
};

window.AIBrain = AIBrain;
