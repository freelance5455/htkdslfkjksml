// ========== MEETING SYSTEM ==========

class MeetingSystem {
    constructor(game) {
        this.game = game;
        this.active = false;
        this.phase = 'discussion';
        this.timer = 0;
        this.discussionTime = 45000;
        this.votingTime = 25000;
        this.messages = [];
        this.votes = {};
        this.reporter = null;
        this.reportedBody = null;
        this.resultText = '';
        this.ejected = null;
    }

    start(reporter, body = null) {
        this.active = true;
        this.phase = 'discussion';
        this.timer = this.discussionTime;
        this.messages = [];
        this.votes = {};
        this.reporter = reporter;
        this.reportedBody = body;
        this.resultText = '';
        this.ejected = null;

        // Clear all bodies when meeting starts (they are "reported")
        for (const c of this.game.crewmates) {
            if (!c.isAlive) {
                c._bodyCleared = true; // flag so we don't draw
            }
            c.knowledge.hasVoted = false;
            c.knowledge.votedFor = null;
            c.lastChatTime = 0;
        }

        if (body) {
            this.addSystemMessage(`${reporter.name} reportou o corpo de ${body.name}!`);
        } else {
            this.addSystemMessage(`${reporter.name} chamou reunião de emergência!`);
        }

        document.getElementById('meeting-overlay').classList.remove('hidden');
        document.getElementById('voting-area').classList.add('hidden');
        document.getElementById('meeting-result').classList.add('hidden');
        document.getElementById('chat-container').classList.remove('hidden');
        document.getElementById('meeting-title').textContent = body ? 'CORPO REPORTADO' : 'REUNIÃO DE EMERGÊNCIA';
        document.getElementById('chat-messages').innerHTML = '';
        this.renderMessages();

        this.game.phase = 'meeting';
    }

    addSystemMessage(text) {
        this.messages.push({ fromId: -1, name: 'Sistema', text, time: this.game.time, isSystem: true });
        this.renderMessages();
    }

    addMessage(from, text) {
        this.messages.push({
            fromId: from.id, name: from.name, color: from.color.body, text, time: this.game.time
        });
        for (const c of this.game.crewmates) {
            if (c.isAlive) AIBrain.hearMessage(c, from.id, text, this.game);
        }
        this.renderMessages();
    }

    renderMessages() {
        const container = document.getElementById('chat-messages');
        container.innerHTML = '';
        for (const msg of this.messages) {
            const div = document.createElement('div');
            div.className = 'chat-msg ' + (msg.fromId === this.game.player.id ? 'player' : 'bot');
            if (msg.isSystem) {
                div.style.background = '#4b5563';
                div.style.alignSelf = 'center';
                div.style.fontSize = '13px';
                div.textContent = msg.text;
            } else {
                div.innerHTML = `<div class="name" style="color:${msg.color}">${msg.name}</div>${msg.text}`;
            }
            container.appendChild(div);
        }
        container.scrollTop = container.scrollHeight;
    }

    update(dt) {
        if (!this.active) return;
        this.timer -= dt * 1000;

        if (this.phase === 'discussion') {
            document.getElementById('meeting-timer').textContent = `Discussão: ${Math.ceil(this.timer / 1000)}s`;
            if (Math.random() < 0.02) {
                const aliveBots = this.game.crewmates.filter(c => c.isAlive && !c.isPlayer);
                if (aliveBots.length) {
                    const bot = randomChoice(aliveBots);
                    const text = AIBrain.generateChatResponse(bot, this.game, this.messages.slice(-8));
                    if (text) this.addMessage(bot, text);
                }
            }
            if (this.timer <= 0) this.startVoting();
        } else if (this.phase === 'voting') {
            document.getElementById('meeting-timer').textContent = `Votação: ${Math.ceil(this.timer / 1000)}s`;
            for (const c of this.game.crewmates) {
                if (!c.isAlive || c.isPlayer || c.knowledge.hasVoted) continue;
                if (Math.random() < 0.025) {
                    const vote = AIBrain.decideVote(c, this.game);
                    this.castVote(c, vote);
                }
            }
            if (this.timer <= 0) this.finishVoting();
        } else if (this.phase === 'result') {
            if (this.timer <= 0) this.end();
        }
    }

    startVoting() {
        this.phase = 'voting';
        this.timer = this.votingTime;
        document.getElementById('chat-container').classList.add('hidden');
        document.getElementById('voting-area').classList.remove('hidden');

        const voteButtons = document.getElementById('vote-buttons');
        voteButtons.innerHTML = '';
        this._playerVoted = false;

        const alive = this.game.crewmates.filter(c => c.isAlive);
        for (const c of alive) {
            const btn = document.createElement('button');
            btn.className = 'vote-btn';
            btn.textContent = c.name;
            btn.dataset.id = c.id;
            btn.style.borderLeft = `4px solid ${c.color.body}`;
            btn.onclick = () => {
                if (this._playerVoted || this.game.player.knowledge.hasVoted) return;
                // clear previous selection
                document.querySelectorAll('.vote-btn').forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
                this.castVote(this.game.player, c.id);
                this._playerVoted = true;
                // disable all
                document.querySelectorAll('.vote-btn').forEach(b => b.disabled = true);
                document.getElementById('btn-skip-vote').disabled = true;
            };
            voteButtons.appendChild(btn);
        }
    }

    castVote(voter, targetId) {
        if (voter.knowledge.hasVoted) return;
        voter.knowledge.hasVoted = true;
        voter.knowledge.votedFor = targetId;
        this.votes[voter.id] = targetId;
    }

    finishVoting() {
        this.phase = 'result';
        this.timer = 4500;

        for (const c of this.game.crewmates) {
            if (c.isAlive && !c.knowledge.hasVoted) {
                const vote = AIBrain.decideVote(c, this.game);
                this.castVote(c, vote);
            }
        }

        const tally = {};
        let skipCount = 0;
        for (const v of Object.values(this.votes)) {
            if (v === 'skip') skipCount++;
            else tally[v] = (tally[v] || 0) + 1;
        }

        let maxVotes = 0, ejectedId = null, tie = false;
        for (const [id, count] of Object.entries(tally)) {
            if (count > maxVotes) { maxVotes = count; ejectedId = parseInt(id); tie = false; }
            else if (count === maxVotes) tie = true;
        }

        document.getElementById('voting-area').classList.add('hidden');
        const resultDiv = document.getElementById('meeting-result');
        resultDiv.classList.remove('hidden');

        if (tie || maxVotes === 0 || skipCount >= maxVotes) {
            this.resultText = 'Ninguém foi ejetado.';
            this.ejected = null;
        } else {
            const ejected = this.game.crewmates.find(c => c.id === ejectedId);
            if (ejected) {
                ejected.isAlive = false;
                ejected._bodyCleared = true; // no body left after eject
                this.ejected = ejected;
                const role = ejected.isImpostor ? 'era um IMPOSTOR' : 'era um TRIPULANTE';
                this.resultText = `${ejected.name} foi ejetado.\n${ejected.name} ${role}!`;
            }
        }

        resultDiv.innerHTML = this.resultText.replace('\n', '<br>');
        document.getElementById('meeting-timer').textContent = 'Resultado';
    }

    end() {
        this.active = false;
        document.getElementById('meeting-overlay').classList.add('hidden');
        this.game.phase = 'playing';
        this.game.checkWinConditions();
    }

    playerChat(text) {
        if (this.phase !== 'discussion' || !text.trim()) return;
        this.addMessage(this.game.player, text.trim());
    }
}
