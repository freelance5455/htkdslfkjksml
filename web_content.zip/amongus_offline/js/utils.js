// ========== UTILITIES ==========
const COLORS = {
    red:    { body: '#e74c3c', visor: '#a0d2ff', name: 'Vermelho' },
    blue:   { body: '#3498db', visor: '#a0d2ff', name: 'Azul' },
    green:  { body: '#2ecc71', visor: '#a0d2ff', name: 'Verde' },
    pink:   { body: '#e91e63', visor: '#a0d2ff', name: 'Rosa' },
    orange: { body: '#e67e22', visor: '#a0d2ff', name: 'Laranja' },
    yellow: { body: '#f1c40f', visor: '#a0d2ff', name: 'Amarelo' },
    black:  { body: '#2c3e50', visor: '#a0d2ff', name: 'Preto' },
    white:  { body: '#ecf0f1', visor: '#a0d2ff', name: 'Branco' },
    purple: { body: '#9b59b6', visor: '#a0d2ff', name: 'Roxo' },
    cyan:   { body: '#1abc9c', visor: '#a0d2ff', name: 'Ciano' }
};

const COLOR_KEYS = Object.keys(COLORS);

function dist(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    return Math.sqrt(dx * dx + dy * dy);
}

function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
}

function randomChoice(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function shuffle(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

function now() {
    return performance.now();
}

// Simple noise for slight movement variation
function noise(t) {
    return Math.sin(t * 0.001) * 0.5 + Math.sin(t * 0.0017) * 0.3;
}
