// ========== PLAYER / CREWMATE ==========

class Crewmate {
    constructor(id, colorKey, x, y, isPlayer = false) {
        this.id = id;
        this.colorKey = colorKey;
        this.color = COLORS[colorKey];
        this.x = x;
        this.y = y;
        this.vx = 0;
        this.vy = 0;
        this.speed = 145;
        this.radius = 16;
        this.isPlayer = isPlayer;
        this.isAlive = true;
        this.isImpostor = false;
        this.inVent = false;
        this.currentVent = null;
        this.facing = 1; // 1 = right, -1 = left
        this.walkPhase = 0;

        // Tasks
        this.assignedTasks = [];
        this.completedTasks = new Set();
        this.doingTask = null;
        this.taskProgress = 0;

        // Kill
        this.killCooldown = 0;
        this.killRange = 48;

        // AI / knowledge
        this.knowledge = {
            seenKills: [],
            seenBodies: [],
            statements: [],
            susLevel: {},
            lastSeen: {},
            votedFor: null,
            hasVoted: false,
            reportedBodies: new Set()
        };

        this.targetX = x;
        this.targetY = y;
        this.state = 'idle';
        this.stateTimer = 0;
        this.fakeTask = false;
        this.stuckTimer = 0;
        this.lastX = x;
        this.lastY = y;

        this.lastChatTime = 0;
        this.chatCooldown = 3500 + Math.random() * 4000;
        this.recentPhrases = [];
    }

    get name() {
        return this.color.name;
    }

    update(dt, game) {
        if (!this.isAlive) return;

        if (this.isPlayer) {
            this.updatePlayer(dt, game);
        } else {
            this.updateAI(dt, game);
        }

        // Facing + walk anim AFTER velocity is finalized (important for player)
        if (Math.abs(this.vx) > 10) {
            this.facing = this.vx > 0 ? 1 : -1;
        }
        const moving = Math.abs(this.vx) > 15 || Math.abs(this.vy) > 15;
        if (moving) {
            this.walkPhase += dt * 11;
        } else {
            this.walkPhase *= 0.85;
        }

        // Movement with better sliding collision
        if (!this.inVent) {
            let nx = this.x + this.vx * dt;
            let ny = this.y + this.vy * dt;

            if (!collidesWall(nx, this.y, this.radius)) {
                this.x = nx;
            } else {
                this.vx *= 0.2;
            }
            if (!collidesWall(this.x, ny, this.radius)) {
                this.y = ny;
            } else {
                this.vy *= 0.2;
            }

            this.x = clamp(this.x, this.radius + 6, MAP.width - this.radius - 6);
            this.y = clamp(this.y, this.radius + 6, MAP.height - this.radius - 6);
        }

        if (this.killCooldown > 0) this.killCooldown -= dt * 1000;
        if (this.stateTimer > 0) this.stateTimer -= dt * 1000;

        // Stuck detection (AI only)
        if (!this.isPlayer && (this.state === 'walking' || this.state === 'hunt')) {
            const moved = Math.hypot(this.x - this.lastX, this.y - this.lastY);
            if (moved < 1.8) {
                this.stuckTimer += dt * 1000;
                if (this.stuckTimer > 800) {
                    this.stuckTimer = 0;
                    this.state = 'idle';
                    this.stateTimer = 150;
                    // Nudge away from wall
                    this.x += (Math.random() - 0.5) * 20;
                    this.y += (Math.random() - 0.5) * 20;
                }
            } else {
                this.stuckTimer = 0;
            }
            this.lastX = this.x;
            this.lastY = this.y;
        }
    }

    updatePlayer(dt, game) {
        const len = Math.hypot(this.vx, this.vy);
        if (len > 1) {
            this.vx = (this.vx / len) * this.speed;
            this.vy = (this.vy / len) * this.speed;
        } else {
            this.vx *= this.speed;
            this.vy *= this.speed;
        }

        if (this.doingTask) {
            this.taskProgress += dt * 1000;
            if (this.taskProgress >= this.doingTask.duration) {
                if (this._fixingSabotage) {
                    game.completeSabotageFix();
                    this.doingTask = null;
                    this.taskProgress = 0;
                    this._fixingSabotage = false;
                } else {
                    this.completedTasks.add(this.doingTask.id);
                    this.doingTask = null;
                    this.taskProgress = 0;
                    game.onTaskComplete(this);
                }
            }
        }
    }

    updateAI(dt, game) {
        if (game.phase !== 'playing') {
            this.vx = 0;
            this.vy = 0;
            return;
        }
        if (window.AIBrain) window.AIBrain.update(this, dt, game);
    }

    tryStartTask(task) {
        if (this.isImpostor && !this.fakeTask) return false;
        if (this.completedTasks.has(task.id)) return false;
        if (dist(this, task) > 38) return false;
        this.doingTask = task;
        this.taskProgress = 0;
        return true;
    }

    canKill(target) {
        if (!this.isImpostor || !this.isAlive || !target.isAlive) return false;
        if (this.killCooldown > 0 || this.inVent) return false;
        return dist(this, target) < this.killRange;
    }

    kill(target, game) {
        if (!this.canKill(target)) return false;
        target.isAlive = false;
        target.vx = 0;
        target.vy = 0;
        this.killCooldown = 22000;
        game.onKill(this, target);
        return true;
    }

    enterVent(vent) {
        if (!this.isImpostor || !this.isAlive) return false;
        if (dist(this, vent) > 34) return false;
        this.inVent = true;
        this.currentVent = vent;
        this.x = vent.x;
        this.y = vent.y;
        this.vx = 0;
        this.vy = 0;
        return true;
    }

    exitVent() {
        this.inVent = false;
        if (this.currentVent) {
            this.x = this.currentVent.x + (Math.random() - 0.5) * 12;
            this.y = this.currentVent.y + (Math.random() - 0.5) * 12;
        }
        this.currentVent = null;
    }

    travelVent(targetVent) {
        if (!this.inVent || !this.currentVent) return false;
        if (!this.currentVent.connections.includes(targetVent.id)) return false;
        this.currentVent = targetVent;
        this.x = targetVent.x;
        this.y = targetVent.y;
        return true;
    }

    draw(ctx, camX, camY) {
        // Hidden completely while inside vent
        if (this.inVent) return;

        const sx = this.x - camX;
        const sy = this.y - camY;

        if (!this.isAlive) {
            // Dead body
            ctx.save();
            ctx.translate(sx, sy);
            ctx.fillStyle = this.color.body;
            ctx.beginPath();
            ctx.ellipse(0, 8, 15, 9, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#eee';
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.moveTo(-7, 3); ctx.lineTo(7, 12);
            ctx.moveTo(7, 3); ctx.lineTo(-7, 12);
            ctx.stroke();
            ctx.fillStyle = 'rgba(0,0,0,0.6)';
            ctx.font = 'bold 10px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(this.name, 0, -10);
            ctx.restore();
            return;
        }

        ctx.save();
        ctx.translate(sx, sy);
        ctx.scale(this.facing, 1);

        // Bob
        const bob = Math.sin(this.walkPhase) * 2.5;
        ctx.translate(0, bob);

        // Shadow
        ctx.fillStyle = 'rgba(0,0,0,0.28)';
        ctx.beginPath();
        ctx.ellipse(0, 20 - bob, 13, 5, 0, 0, Math.PI * 2);
        ctx.fill();

        // Backpack
        ctx.fillStyle = shade(this.color.body, -30);
        ctx.beginPath();
        ctx.roundRect(-19, -11, 11, 21, 4);
        ctx.fill();

        // Body bean
        ctx.fillStyle = this.color.body;
        ctx.beginPath();
        ctx.ellipse(0, 0, 15, 18, 0, 0, Math.PI * 2);
        ctx.fill();

        // Visor
        ctx.fillStyle = this.color.visor;
        ctx.beginPath();
        ctx.ellipse(6, -5, 9.5, 7.5, 0.12, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.beginPath();
        ctx.ellipse(8.5, -7, 3.5, 2.6, 0.12, 0, Math.PI * 2);
        ctx.fill();

        // Legs
        const leg = Math.sin(this.walkPhase) * 3.5;
        ctx.fillStyle = this.color.body;
        ctx.fillRect(-10, 13, 8, 9 + leg * 0.25);
        ctx.fillRect(2, 13, 8, 9 - leg * 0.25);

        ctx.restore();

        // Name (not flipped)
        if (!this.isPlayer) {
            ctx.save();
            ctx.translate(sx, sy);
            ctx.fillStyle = 'rgba(0,0,0,0.65)';
            ctx.font = 'bold 11px sans-serif';
            ctx.textAlign = 'center';
            const tw = ctx.measureText(this.name).width;
            ctx.fillRect(-tw / 2 - 5, -37, tw + 10, 15);
            ctx.fillStyle = '#fff';
            ctx.fillText(this.name, 0, -26);
            ctx.restore();
        }

        if (this.isPlayer && this.isImpostor) {
            ctx.save();
            ctx.translate(sx, sy);
            ctx.fillStyle = '#ef4444';
            ctx.font = 'bold 11px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('IMPOSTOR', 0, -40);
            ctx.restore();
        }
    }
}

function shade(col, pct) {
    const n = parseInt(col.slice(1), 16);
    const a = Math.round(2.55 * pct);
    const r = Math.min(255, Math.max(0, (n >> 16) + a));
    const g = Math.min(255, Math.max(0, (n >> 8 & 255) + a));
    const b = Math.min(255, Math.max(0, (n & 255) + a));
    return '#' + (0x1000000 + r * 0x10000 + g * 0x100 + b).toString(16).slice(1);
}
