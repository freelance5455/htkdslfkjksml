// ========== MAP DEFINITION ==========
// Compact custom map inspired by The Skeld, optimized for 7 players

const TILE = 40; // pixels per logical unit

const MAP = {
    width: 28 * TILE,   // 1120
    height: 20 * TILE,  // 800

    // Rooms: { name, x, y, w, h, color }
    rooms: [
        { id: 'cafeteria', name: 'Cafeteria', x: 8*TILE, y: 2*TILE, w: 12*TILE, h: 6*TILE, color: '#2a3a4a' },
        { id: 'weapons',   name: 'Weapons',   x: 21*TILE, y: 2*TILE, w: 5*TILE,  h: 4*TILE, color: '#3a2a2a' },
        { id: 'navigation',name: 'Navigation',x: 21*TILE, y: 7*TILE, w: 5*TILE,  h: 3*TILE, color: '#2a3a2a' },
        { id: 'o2',        name: 'O2',        x: 16*TILE, y: 9*TILE, w: 4*TILE,  h: 3*TILE, color: '#2a3a3a' },
        { id: 'admin',     name: 'Admin',     x: 10*TILE, y: 9*TILE, w: 5*TILE,  h: 3*TILE, color: '#3a2a3a' },
        { id: 'storage',   name: 'Storage',   x: 4*TILE,  y: 9*TILE, w: 5*TILE,  h: 4*TILE, color: '#3a3a2a' },
        { id: 'electrical',name: 'Electrical',x: 4*TILE,  y: 14*TILE,w: 5*TILE,  h: 4*TILE, color: '#3a3a1a' },
        { id: 'medbay',    name: 'Medbay',    x: 10*TILE, y: 13*TILE,w: 5*TILE,  h: 5*TILE, color: '#1a3a3a' },
        { id: 'security',  name: 'Security',  x: 16*TILE, y: 13*TILE,w: 4*TILE,  h: 3*TILE, color: '#2a2a3a' },
        { id: 'reactor',   name: 'Reactor',   x: 1*TILE,  y: 5*TILE, w: 4*TILE,  h: 5*TILE, color: '#3a1a1a' },
        { id: 'upper_eng', name: 'Upper Engine', x: 1*TILE, y: 1*TILE, w: 5*TILE, h: 3*TILE, color: '#2a2a2a' },
        { id: 'lower_eng', name: 'Lower Engine', x: 1*TILE, y: 11*TILE,w: 4*TILE, h: 3*TILE, color: '#2a2a2a' },
    ],

    // Walls as axis-aligned rectangles (for collision)
    // Generated from room borders + extra corridors
    walls: [],

    // Corridors connecting rooms (walkable)
    corridors: [
        // horizontal main
        { x: 6*TILE, y: 7*TILE, w: 15*TILE, h: 2*TILE },
        // vertical left
        { x: 5*TILE, y: 4*TILE, w: 2*TILE, h: 10*TILE },
        // to reactor
        { x: 3*TILE, y: 6*TILE, w: 3*TILE, h: 2*TILE },
        // to electrical
        { x: 6*TILE, y: 14*TILE, w: 4*TILE, h: 2*TILE },
        // to medbay
        { x: 12*TILE, y: 12*TILE, w: 2*TILE, h: 2*TILE },
        // to security / o2
        { x: 15*TILE, y: 12*TILE, w: 3*TILE, h: 2*TILE },
        // to weapons/nav
        { x: 20*TILE, y: 5*TILE, w: 2*TILE, h: 5*TILE },
    ],

    // Vents: { id, x, y, connections: [otherVentIds] }
    vents: [
        { id: 'v_cafeteria', x: 10*TILE, y: 5*TILE, connections: ['v_admin', 'v_weapons'] },
        { id: 'v_admin',     x: 12*TILE, y: 10.5*TILE, connections: ['v_cafeteria', 'v_electrical'] },
        { id: 'v_electrical',x: 6*TILE,  y: 15.5*TILE, connections: ['v_admin', 'v_medbay'] },
        { id: 'v_medbay',    x: 12*TILE, y: 15*TILE, connections: ['v_electrical', 'v_security'] },
        { id: 'v_security',  x: 17.5*TILE,y: 14*TILE, connections: ['v_medbay', 'v_weapons'] },
        { id: 'v_weapons',   x: 23*TILE, y: 3.5*TILE, connections: ['v_cafeteria', 'v_security'] },
        { id: 'v_reactor',   x: 2.5*TILE,y: 7*TILE, connections: ['v_upper', 'v_lower'] },
        { id: 'v_upper',     x: 3*TILE,  y: 2*TILE, connections: ['v_reactor'] },
        { id: 'v_lower',     x: 2.5*TILE,y: 12*TILE, connections: ['v_reactor'] },
    ],

    // Tasks: { id, name, room, x, y, duration (ms) }
    tasks: [
        { id: 't1', name: 'Limpar Filtro O2', room: 'o2', x: 17.5*TILE, y: 10*TILE, duration: 4000 },
        { id: 't2', name: 'Calibrar Distribuidor', room: 'electrical', x: 6*TILE, y: 15.5*TILE, duration: 5000 },
        { id: 't3', name: 'Escanear Medbay', room: 'medbay', x: 12*TILE, y: 15*TILE, duration: 6000 },
        { id: 't4', name: 'Desviar Energia', room: 'electrical', x: 5.5*TILE, y: 16*TILE, duration: 4500 },
        { id: 't5', name: 'Esvaziar Lixo', room: 'storage', x: 6*TILE, y: 11*TILE, duration: 3500 },
        { id: 't6', name: 'Arrumar Fios', room: 'admin', x: 12*TILE, y: 10*TILE, duration: 5000 },
        { id: 't7', name: 'Combustível Motor', room: 'upper_eng', x: 3*TILE, y: 2*TILE, duration: 5500 },
        { id: 't8', name: 'Estabilizar Direção', room: 'navigation', x: 23*TILE, y: 8*TILE, duration: 4000 },
        { id: 't9', name: 'Lançar Asteroides', room: 'weapons', x: 23*TILE, y: 3.5*TILE, duration: 4500 },
        { id: 't10',name: 'Inspecionar Amostra', room: 'medbay', x: 13*TILE, y: 14*TILE, duration: 5000 },
    ],

    // Spawn points (cafeteria)
    spawns: [
        { x: 10*TILE, y: 4*TILE },
        { x: 12*TILE, y: 4*TILE },
        { x: 14*TILE, y: 4*TILE },
        { x: 16*TILE, y: 4*TILE },
        { x: 11*TILE, y: 6*TILE },
        { x: 13*TILE, y: 6*TILE },
        { x: 15*TILE, y: 6*TILE },
    ],

    // Emergency button position
    emergencyButton: { x: 14*TILE, y: 4.5*TILE },
};

// Build walls from room outlines (simple AABB walls)
function buildWalls() {
    const walls = [];
    const thickness = 8;

    MAP.rooms.forEach(room => {
        // top
        walls.push({ x: room.x, y: room.y, w: room.w, h: thickness });
        // bottom
        walls.push({ x: room.x, y: room.y + room.h - thickness, w: room.w, h: thickness });
        // left
        walls.push({ x: room.x, y: room.y, w: thickness, h: room.h });
        // right
        walls.push({ x: room.x + room.w - thickness, y: room.y, w: thickness, h: room.h });
    });

    // Outer boundary
    walls.push({ x: 0, y: 0, w: MAP.width, h: thickness });
    walls.push({ x: 0, y: MAP.height - thickness, w: MAP.width, h: thickness });
    walls.push({ x: 0, y: 0, w: thickness, h: MAP.height });
    walls.push({ x: MAP.width - thickness, y: 0, w: thickness, h: MAP.height });

    MAP.walls = walls;
}

buildWalls();

// Helper: is point inside any room or corridor?
function isWalkable(x, y, radius = 14) {
    // Check corridors and rooms (open space)
    const inArea = (area) => {
        return x + radius > area.x && x - radius < area.x + area.w &&
               y + radius > area.y && y - radius < area.y + area.h;
    };

    for (const room of MAP.rooms) {
        if (inArea(room)) return true;
    }
    for (const corr of MAP.corridors) {
        if (inArea(corr)) return true;
    }
    return false;
}

// Collision against walls (simple)
function collidesWall(x, y, radius = 14) {
    for (const w of MAP.walls) {
        if (x + radius > w.x && x - radius < w.x + w.w &&
            y + radius > w.y && y - radius < w.y + w.h) {
            // Only collide if not in a walkable area (doors are open)
            if (!isWalkable(x, y, radius - 2)) return true;
        }
    }
    return false;
}

function getRoomAt(x, y) {
    for (const room of MAP.rooms) {
        if (x >= room.x && x <= room.x + room.w &&
            y >= room.y && y <= room.y + room.h) {
            return room;
        }
    }
    // Fallback: nearest room center (for corridors)
    let best = null, bestD = 1e9;
    for (const room of MAP.rooms) {
        const cx = room.x + room.w / 2;
        const cy = room.y + room.h / 2;
        const d = Math.hypot(x - cx, y - cy);
        if (d < bestD) { bestD = d; best = room; }
    }
    return best;
}
