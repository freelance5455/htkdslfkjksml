// ========== MAIN GAME ==========

class Game {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.crewmates = [];
        this.player = null;
        this.phase = 'start';
        this.time = 0;
        this.meeting = new MeetingSystem(this);
        this.impostorCount = 2;
        this.totalTasks = 0;
        this.completedTasksTotal = 0;
        this.camera = { x: 0, y: 0 };
        this.keys = {};
        this.joystick = { active: false, dx: 0, dy: 0 };
        this.gameMode = 'offline';
        this.gameMode = 'offline';
        this.visionRadius = 210;
        this.sabotageActive = null;
        this.sabotageTimer = 0;
        this.lightsSabotaged = false;
        this.reactorMeltdown = false;
        this.doorsLocked = false;
        this.fixFix = null;

        this.resize();
        window.addEventListener('resize', () => this.resize());
        this.setupControls();
        this.setupUI();
    }

    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }

    setupControls() {
        window.addEventListener('keydown', e => {
            this.keys[e.key.toLowerCase()] = true;
            if (e.key === 'Enter' && this.meeting.active) {
                const input = document.getElementById('chat-input');
                if (document.activeElement === input) {
                    this.meeting.playerChat(input.value);
                    input.value = '';
                }
            }
        });
        window.addEventListener('keyup', e => { this.keys[e.key.toLowerCase()] = false; });

        const zone = document.getElementById('joystick-zone');
        const knob = document.getElementById('joystick-knob');
        const base = document.getElementById('joystick-base');

        const startJoy = (x, y) => {
            this.joystick.active = true;
            knob.classList.add('active');
            this.updateJoystick(x, y, base);
        };
        const moveJoy = (x, y) => { if (this.joystick.active) this.updateJoystick(x, y, base); };
        const endJoy = () => {
            this.joystick.active = false;
            this.joystick.dx = 0; this.joystick.dy = 0;
            knob.style.transform = 'translate(-50%, -50%)';
            knob.classList.remove('active');
        };

        zone.addEventListener('touchstart', e => { e.preventDefault(); startJoy(e.touches[0].clientX, e.touches[0].clientY); }, { passive: false });
        zone.addEventListener('touchmove', e => { e.preventDefault(); moveJoy(e.touches[0].clientX, e.touches[0].clientY); }, { passive: false });
        zone.addEventListener('touchend', endJoy);
        zone.addEventListener('mousedown', e => startJoy(e.clientX, e.clientY));
        window.addEventListener('mousemove', e => moveJoy(e.clientX, e.clientY));
        window.addEventListener('mouseup', endJoy);
    }

    updateJoystick(clientX, clientY, base) {
        const rect = base.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        let dx = clientX - cx, dy = clientY - cy;
        const max = rect.width / 2 - 10;
        const len = Math.hypot(dx, dy) || 1;
        if (len > max) { dx = dx / len * max; dy = dy / len * max; }
        this.joystick.dx = dx / max;
        this.joystick.dy = dy / max;
        document.getElementById('joystick-knob').style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    }

    setupUI() {
        document.getElementById('btn-offline').onclick = () => {
            this.impostorCount = parseInt(document.getElementById('impostor-count').value);
            this.gameMode = 'offline';
            this.startGame();
        };
        document.getElementById('btn-online').onclick = () => {
            this.impostorCount = parseInt(document.getElementById('impostor-count').value);
            this.gameMode = 'online';
            // Save / ensure Groq key
            const defaultKey = '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';
            if (!localStorage.getItem('groq_api_key')) {
                localStorage.setItem('groq_api_key', defaultKey);
            }
            this.startGame();
        };
        document.getElementById('btn-restart').onclick = () => {
            document.getElementById('end-screen').classList.add('hidden');
            document.getElementById('start-screen').classList.remove('hidden');
            this.phase = 'start';
        };

        document.getElementById('btn-use').onclick = () => this.playerUse();
        document.getElementById('btn-report').onclick = () => this.playerReport();
        document.getElementById('btn-kill').onclick = () => this.playerKill();
        document.getElementById('btn-sabotage').onclick = () => this.openSabotageMenu();
        document.getElementById('btn-vent').onclick = () => this.playerVent();
        document.getElementById('btn-emergency').onclick = () => this.playerEmergency();
        document.getElementById('chat-send').onclick = () => {
            const input = document.getElementById('chat-input');
            this.meeting.playerChat(input.value);
            input.value = '';
        };
        document.getElementById('btn-skip-vote').onclick = () => {
            if (this.meeting.phase === 'voting' && !this.player.knowledge.hasVoted) {
                this.meeting.castVote(this.player, 'skip');
                this.meeting._playerVoted = true;
                document.querySelectorAll('.vote-btn').forEach(b => b.disabled = true);
                document.getElementById('btn-skip-vote').disabled = true;
            }
        };

        // Sabotage modal buttons
        document.querySelectorAll('.sab-btn').forEach(btn => {
            btn.onclick = () => this.doSabotage(btn.dataset.sab);
        });
        document.getElementById('sab-cancel').onclick = () => {
            document.getElementById('sabotage-overlay').classList.add('hidden');
        };
        document.getElementById('vent-exit').onclick = () => {
            this.player.exitVent();
            document.getElementById('vent-overlay').classList.add('hidden');
        };
    }

    startGame() {
        document.getElementById('start-screen').classList.add('hidden');
        this.crewmates = [];
        this.time = 0;
        this.completedTasksTotal = 0;
        this.lightsSabotaged = false;
        this.sabotageActive = null;
        this.reactorMeltdown = false;
        this.doorsLocked = false;
        this.fixFix = null;

        const colors = shuffle(COLOR_KEYS).slice(0, 7);
        const spawns = shuffle(MAP.spawns);

        for (let i = 0; i < 7; i++) {
            const isPlayer = i === 0;
            const c = new Crewmate(i, colors[i], spawns[i].x, spawns[i].y, isPlayer);
            this.crewmates.push(c);
            if (isPlayer) this.player = c;
        }

        const indices = shuffle([...Array(7).keys()]);
        for (let i = 0; i < this.impostorCount; i++) {
            this.crewmates[indices[i]].isImpostor = true;
        }

        let taskPool = shuffle([...MAP.tasks]);
        for (const c of this.crewmates) {
            if (c.isImpostor) c.assignedTasks = [];
            else {
                c.assignedTasks = [];
                for (let t = 0; t < 4; t++) {
                    if (!taskPool.length) taskPool = shuffle([...MAP.tasks]);
                    c.assignedTasks.push(taskPool.pop());
                }
            }
        }

        this.totalTasks = this.crewmates.filter(c => !c.isImpostor)
            .reduce((s, c) => s + c.assignedTasks.length, 0);

        this.phase = 'playing';
        this.updateRoleUI();
        this.updateTaskUI();
        this.lastTime = 0;
        this.loop(0);
    }

    updateRoleUI() {
        const el = document.getElementById('role-display');
        if (this.player.isImpostor) {
            el.textContent = 'IMPOSTOR';
            el.className = 'impostor';
            document.querySelectorAll('.impostor-only').forEach(b => b.style.display = 'block');
        } else {
            el.textContent = 'TRIPULANTE';
            el.className = 'crewmate';
            document.querySelectorAll('.impostor-only').forEach(b => b.style.display = 'none');
        }
    }

    updateTaskUI() {
        const ul = document.getElementById('tasks-ul');
        ul.innerHTML = '';
        if (this.player.isImpostor) {
            ul.innerHTML = '<li style="color:#f87171">Sabote e elimine os tripulantes</li>';
            return;
        }
        for (const t of this.player.assignedTasks) {
            const li = document.createElement('li');
            li.textContent = t.name;
            if (this.player.completedTasks.has(t.id)) li.classList.add('done');
            ul.appendChild(li);
        }
    }

    playerUse() {
        if (this.phase !== 'playing' || !this.player.isAlive) return;
        // Priority: fix sabotage
        if (this.tryFixSabotage()) return;
        let nearest = null, best = 40;
        for (const t of MAP.tasks) {
            const d = dist(this.player, t);
            if (d < best && !this.player.completedTasks.has(t.id)) { best = d; nearest = t; }
        }
        if (nearest) this.player.tryStartTask(nearest);
    }

    playerReport() {
        if (this.phase !== 'playing' || !this.player.isAlive) return;
        for (const c of this.crewmates) {
            if (!c.isAlive && !c._bodyCleared && dist(this.player, c) < 55) {
                this.meeting.start(this.player, c);
                return;
            }
        }
    }

    playerKill() {
        if (this.phase !== 'playing' || !this.player.isAlive || !this.player.isImpostor) return;
        let nearest = null, best = this.player.killRange;
        for (const c of this.crewmates) {
            if (c.isAlive && !c.isImpostor && c.id !== this.player.id) {
                const d = dist(this.player, c);
                if (d < best) { best = d; nearest = c; }
            }
        }
        if (nearest) this.player.kill(nearest, this);
    }

    openSabotageMenu() {
        if (!this.player.isImpostor || !this.player.isAlive || this.phase !== 'playing') return;
        document.getElementById('sabotage-overlay').classList.remove('hidden');
    }

    doSabotage(type) {
        document.getElementById('sabotage-overlay').classList.add('hidden');
        if (type === 'lights') {
            this.lightsSabotaged = true;
            this.sabotageActive = 'lights';
            this.sabotageTimer = 30000;
            this.fixFix = { x: 6*40, y: 15.5*40, name: 'Consertar Luzes (Electrical)' };
        } else if (type === 'reactor') {
            this.sabotageActive = 'reactor';
            this.sabotageTimer = 40000;
            this.fixFix = { x: 2.5*40, y: 7*40, name: 'Estabilizar Reactor' };
            this.reactorMeltdown = true;
        } else if (type === 'doors') {
            this.sabotageActive = 'doors';
            this.sabotageTimer = 18000;
            this.doorsLocked = true;
            this.fixFix = null;
        }
    }

    tryFixSabotage() {
        if (!this.sabotageActive || !this.fixFix) return false;
        if (dist(this.player, this.fixFix) > 40) return false;
        // Player starts fixing
        this.player.doingTask = { id: 'fix_' + this.sabotageActive, name: this.fixFix.name, duration: 5000 };
        this.player.taskProgress = 0;
        this.player._fixingSabotage = true;
        return true;
    }

    completeSabotageFix() {
        this.lightsSabotaged = false;
        this.reactorMeltdown = false;
        this.doorsLocked = false;
        this.sabotageActive = null;
        this.sabotageTimer = 0;
        this.fixFix = null;
        this.player._fixingSabotage = false;
    }

    playerVent() {
        if (!this.player.isImpostor || !this.player.isAlive) return;

        if (this.player.inVent) {
            // Show visual vent menu
            const curr = this.player.currentVent;
            document.getElementById('vent-current').textContent = 'Você está em: ' + curr.id.replace('v_', '');
            const container = document.getElementById('vent-options');
            container.innerHTML = '';
            for (const cid of curr.connections) {
                const v = MAP.vents.find(vv => vv.id === cid);
                if (!v) continue;
                const btn = document.createElement('button');
                btn.textContent = '→ ' + cid.replace('v_', '');
                btn.onclick = () => {
                    this.player.travelVent(v);
                    document.getElementById('vent-overlay').classList.add('hidden');
                };
                container.appendChild(btn);
            }
            document.getElementById('vent-overlay').classList.remove('hidden');
            return;
        }

        // Enter nearest
        let nearest = null, best = 36;
        for (const v of MAP.vents) {
            const d = dist(this.player, v);
            if (d < best) { best = d; nearest = v; }
        }
        if (nearest) this.player.enterVent(nearest);
    }

    playerEmergency() {
        if (this.phase !== 'playing' || !this.player.isAlive) return;
        if (dist(this.player, MAP.emergencyButton) < 45) {
            this.meeting.start(this.player, null);
        }
    }

    onKill(killer, victim) {
        for (const bot of this.crewmates) {
            if (!bot.isAlive || bot.id === killer.id) continue;
            if (dist(bot, victim) < 150) {
                bot.knowledge.seenKills.push({
                    killerId: killer.id, victimId: victim.id,
                    time: this.time, room: getRoomAt(victim.x, victim.y)?.name || '?'
                });
                bot.knowledge.susLevel[killer.id] = (bot.knowledge.susLevel[killer.id] || 0) + 45;
            }
        }
    }

    onTaskComplete(crew) {
        if (!crew.isImpostor) {
            this.completedTasksTotal++;
            if (crew.isPlayer) this.updateTaskUI();
            this.checkWinConditions();
        }
    }

    checkWinConditions() {
        const aliveCrew = this.crewmates.filter(c => c.isAlive && !c.isImpostor).length;
        const aliveImp = this.crewmates.filter(c => c.isAlive && c.isImpostor).length;
        if (aliveImp === 0) { this.endGame(false); return; }
        if (aliveImp >= aliveCrew) { this.endGame(true); return; }
        if (this.completedTasksTotal >= this.totalTasks && this.totalTasks > 0) this.endGame(false);
    }

    endGame(impostorsWin) {
        this.phase = 'end';
        const screen = document.getElementById('end-screen');
        const title = document.getElementById('end-title');
        const msg = document.getElementById('end-message');
        screen.classList.remove('hidden');
        if (this.player.isImpostor) {
            title.textContent = impostorsWin ? 'VITÓRIA!' : 'DERROTA';
            title.style.color = impostorsWin ? '#ef4444' : '#60a5fa';
            msg.textContent = impostorsWin ? 'Os impostores venceram!' : 'Os tripulantes venceram.';
        } else {
            title.textContent = !impostorsWin ? 'VITÓRIA!' : 'DERROTA';
            title.style.color = !impostorsWin ? '#60a5fa' : '#ef4444';
            msg.textContent = !impostorsWin ? 'Os tripulantes venceram!' : 'Os impostores venceram.';
        }
    }

    update(dt) {
        this.time += dt * 1000;

        if (this.sabotageTimer > 0) {
            this.sabotageTimer -= dt * 1000;
            if (this.sabotageTimer <= 0) {
                if (this.reactorMeltdown) {
                    // Reactor exploded - impostors win
                    this.endGame(true);
                    return;
                }
                this.lightsSabotaged = false;
                this.reactorMeltdown = false;
                this.doorsLocked = false;
                this.sabotageActive = null;
                this.fixFix = null;
            }
        }

        if (this.phase === 'playing') {
            let ix = 0, iy = 0;
            if (this.keys['w'] || this.keys['arrowup']) iy -= 1;
            if (this.keys['s'] || this.keys['arrowdown']) iy += 1;
            if (this.keys['a'] || this.keys['arrowleft']) ix -= 1;
            if (this.keys['d'] || this.keys['arrowright']) ix += 1;
            if (this.joystick.active) { ix = this.joystick.dx; iy = this.joystick.dy; }
            this.player.vx = ix;
            this.player.vy = iy;

            for (const c of this.crewmates) c.update(dt, this);

            this.camera.x = this.player.x - this.canvas.width / 2;
            this.camera.y = this.player.y - this.canvas.height / 2;
            this.camera.x = clamp(this.camera.x, 0, Math.max(0, MAP.width - this.canvas.width));
            this.camera.y = clamp(this.camera.y, 0, Math.max(0, MAP.height - this.canvas.height));

            this.updateActionButtons();
        }

        if (this.meeting.active) this.meeting.update(dt);
    }

    updateActionButtons() {
        const p = this.player;
        let canUse = false;
        for (const t of MAP.tasks) {
            if (dist(p, t) < 38 && !p.completedTasks.has(t.id)) canUse = true;
        }
        document.getElementById('btn-use').disabled = !canUse || p.isImpostor;

        let canReport = false;
        for (const c of this.crewmates) {
            if (!c.isAlive && !c._bodyCleared && dist(p, c) < 55) canReport = true;
        }
        document.getElementById('btn-report').disabled = !canReport;

        let canKill = false;
        if (p.isImpostor) {
            for (const c of this.crewmates) {
                if (c.isAlive && !c.isImpostor && dist(p, c) < p.killRange) canKill = true;
            }
            canKill = canKill && p.killCooldown <= 0 && !p.inVent;
        }
        document.getElementById('btn-kill').disabled = !canKill;

        // Sabotage always enabled for impostor
        document.getElementById('btn-sabotage').disabled = !p.isImpostor || !p.isAlive || p.inVent;

        let canVent = false;
        if (p.isImpostor) {
            if (p.inVent) canVent = true;
            else for (const v of MAP.vents) if (dist(p, v) < 36) canVent = true;
        }
        document.getElementById('btn-vent').disabled = !canVent;

        document.getElementById('btn-emergency').disabled = dist(p, MAP.emergencyButton) > 45;

        const cdEl = document.getElementById('kill-cooldown');
        if (p.isImpostor && p.killCooldown > 0) {
            cdEl.classList.remove('hidden');
            cdEl.textContent = Math.ceil(p.killCooldown / 1000) + 's';
        } else cdEl.classList.add('hidden');
    }

    render() {
        const ctx = this.ctx;
        const W = this.canvas.width, H = this.canvas.height;
        ctx.clearRect(0, 0, W, H);
        if (this.phase === 'start' || this.phase === 'end') return;

        const camX = this.camera.x, camY = this.camera.y;

        // Dark background
        ctx.fillStyle = '#0b0b14';
        ctx.fillRect(0, 0, W, H);

        // Rooms with better look
        for (const room of MAP.rooms) {
            // Floor
            ctx.fillStyle = room.color;
            ctx.fillRect(room.x - camX, room.y - camY, room.w, room.h);
            // Subtle grid
            ctx.strokeStyle = 'rgba(255,255,255,0.04)';
            ctx.lineWidth = 1;
            for (let gx = 0; gx < room.w; gx += 20) {
                ctx.beginPath();
                ctx.moveTo(room.x - camX + gx, room.y - camY);
                ctx.lineTo(room.x - camX + gx, room.y - camY + room.h);
                ctx.stroke();
            }
            // Border
            ctx.strokeStyle = 'rgba(255,255,255,0.12)';
            ctx.lineWidth = 2;
            ctx.strokeRect(room.x - camX + 1, room.y - camY + 1, room.w - 2, room.h - 2);
            // Name
            ctx.fillStyle = 'rgba(255,255,255,0.35)';
            ctx.font = 'bold 13px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(room.name, room.x - camX + room.w / 2, room.y - camY + 18);
        }

        // Corridors
        ctx.fillStyle = '#151525';
        for (const c of MAP.corridors) {
            ctx.fillRect(c.x - camX, c.y - camY, c.w, c.h);
        }

        // Vents
        for (const v of MAP.vents) {
            ctx.fillStyle = '#222';
            ctx.beginPath();
            ctx.arc(v.x - camX, v.y - camY, 13, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#555';
            ctx.lineWidth = 2;
            ctx.stroke();
            ctx.beginPath();
            for (let i = -1; i <= 1; i++) {
                ctx.moveTo(v.x - camX - 9, v.y - camY + i * 5);
                ctx.lineTo(v.x - camX + 9, v.y - camY + i * 5);
            }
            ctx.stroke();
        }

        // Tasks
        for (const t of MAP.tasks) {
            const done = this.player && this.player.completedTasks.has(t.id);
            ctx.fillStyle = done ? '#22c55e' : '#eab308';
            ctx.beginPath();
            ctx.arc(t.x - camX, t.y - camY, 9, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = 'rgba(0,0,0,0.4)';
            ctx.stroke();
        }

        // Emergency
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(MAP.emergencyButton.x - camX, MAP.emergencyButton.y - camY, 15, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 14px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('!', MAP.emergencyButton.x - camX, MAP.emergencyButton.y - camY + 5);

        // Sabotage fix point
        if (this.fixFix) {
            ctx.fillStyle = '#f97316';
            ctx.beginPath();
            ctx.arc(this.fixFix.x - camX, this.fixFix.y - camY, 14, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 11px sans-serif';
            ctx.fillText('FIX', this.fixFix.x - camX, this.fixFix.y - camY + 4);
            // label
            ctx.fillStyle = 'rgba(0,0,0,0.7)';
            ctx.fillRect(this.fixFix.x - camX - 50, this.fixFix.y - camY - 32, 100, 16);
            ctx.fillStyle = '#fdba74';
            ctx.font = '10px sans-serif';
            ctx.fillText(this.fixFix.name, this.fixFix.x - camX, this.fixFix.y - camY - 20);
        }

        // Sabotage banner
        if (this.sabotageActive) {
            ctx.fillStyle = 'rgba(127,29,29,0.85)';
            ctx.fillRect(0, 0, W, 28);
            ctx.fillStyle = '#fecaca';
            ctx.font = 'bold 13px sans-serif';
            ctx.textAlign = 'center';
            let msg = this.sabotageActive === 'lights' ? 'LUZES SABOTADAS' :
                      this.sabotageActive === 'reactor' ? 'REACTOR EM MELTDOWN! ' + Math.ceil(this.sabotageTimer/1000) + 's' :
                      'PORTAS TRAVADAS';
            ctx.fillText(msg, W/2, 19);
        }

        // Crewmates (skip cleared bodies)
        const sorted = [...this.crewmates].sort((a, b) => {
            if (!a.isAlive && b.isAlive) return -1;
            if (a.isAlive && !b.isAlive) return 1;
            return a.y - b.y;
        });
        for (const c of sorted) {
            if (!c.isAlive && c._bodyCleared) continue;
            c.draw(ctx, camX, camY);
        }

        // ===== FOG OF WAR / VISION =====
        const visR = this.lightsSabotaged ? 95 : this.visionRadius;
        const px = this.player.x - camX;
        const py = this.player.y - camY;

        // Dark overlay with radial hole
        ctx.save();
        ctx.fillStyle = 'rgba(0,0,0,0.78)';
        ctx.beginPath();
        ctx.rect(0, 0, W, H);
        ctx.arc(px, py, visR, 0, Math.PI * 2, true); // cut hole
        ctx.fill('evenodd');

        // Soft edge
        const grad = ctx.createRadialGradient(px, py, visR * 0.65, px, py, visR);
        grad.addColorStop(0, 'rgba(0,0,0,0)');
        grad.addColorStop(1, 'rgba(0,0,0,0.55)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(px, py, visR, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Task progress
        if (this.player && this.player.doingTask) {
            const t = this.player.doingTask;
            const pct = this.player.taskProgress / t.duration;
            const bx = W / 2 - 70, by = H / 2 + 50;
            ctx.fillStyle = 'rgba(0,0,0,0.75)';
            ctx.fillRect(bx - 4, by - 4, 148, 20);
            ctx.fillStyle = '#22c55e';
            ctx.fillRect(bx, by, 140 * pct, 12);
            ctx.fillStyle = '#fff';
            ctx.font = '13px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(t.name, W / 2, by - 12);
        }

        // In vent indicator
        if (this.player.inVent) {
            ctx.fillStyle = 'rgba(0,0,0,0.7)';
            ctx.fillRect(W / 2 - 80, 40, 160, 36);
            ctx.fillStyle = '#a78bfa';
            ctx.font = 'bold 14px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('DENTRO DA VENT', W / 2, 63);
        }
    }

    loop(timestamp) {
        if (!this.lastTime) this.lastTime = timestamp;
        const dt = Math.min((timestamp - this.lastTime) / 1000, 0.05);
        this.lastTime = timestamp;
        this.update(dt);
        this.render();
        if (this.phase !== 'start') requestAnimationFrame(t => this.loop(t));
    }
}

window.onload = () => { window.game = new Game(); };
