(function () {
  const TAU = Math.PI * 2;

  // ---------- नई बंदूकें ----------
  GUNS.sniper = { rate: 0.8,  n: 1, sp: 0,    life: 1.5 };
  GUNS.rocket = { rate: 1.0,  n: 1, sp: 0.02, life: 1.1 };
  GUNS.flame  = { rate: 0.07, n: 1, sp: 0.4,  life: 0.3 };
  GUNS.homing = { rate: 0.32, n: 3, sp: 1.2,  life: 1.8 };

  DROPS.snip = { col: '#4fd1ff', t: 'R' };
  DROPS.rkt  = { col: '#ff4040', t: 'B' };
  DROPS.flm  = { col: '#ff9a2a', t: 'F' };
  DROPS.hom  = { col: '#d96ad6', t: 'H' };

  const KIND = { snip: 'sniper', rkt: 'rocket', flm: 'flame', hom: 'homing' };
  const NG = {
    sniper: { dm: 5,   pi: 3, sp: 1.5 },
    rocket: { dm: 1,   po: 0, sp: 0.7, ex: true },
    flame:  { dm: 0.4, po: 99, sp: 0.65 },
    homing: { dm: 1.2, pi: 0, sp: 0.75 }
  };
  const NM = {
    shotgun: 'शॉटगन', machine: 'मशीनगन', sniper: 'स्नाइपर',
    rocket: 'रॉकेट', flame: 'फ्लेमथ्रोअर', homing: 'होमिंग'
  };

  let rk = [], fx = [];

  // बंदूक का नाम और बचा समय
  const gh = document.createElement('div');
  gh.style.cssText = 'position:fixed;top:92px;left:12px;color:#fff7e0;font-weight:800;font-size:15px;pointer-events:none;text-shadow:0 1px 3px rgba(0,0,0,.6)';
  document.body.appendChild(gh);
  let ghTxt = '';
  function ghUpdate() {
    const t = p.gun !== 'pistol' ? '🔫 ' + (NM[p.gun] || '') + ' ' + Math.max(0, Math.ceil(p.gunT)) + ' से' : '';
    if (t !== ghTxt) { ghTxt = t; gh.textContent = t; }
  }

  const _pick = pickUp;
  pickUp = function (d) {
    const g = KIND[d.kind];
    if (g) {
      p.gun = g; p.gunT = 12;
      sfx.pick();
      burst(d.x, d.y, DROPS[d.kind].col, 8, 120);
      updateHud();
    } else _pick(d);
  };

  function gunSound(g) {
    if (g === 'sniper') beep(900, 0.12, 'sine', 0.08, 0.3);
    else if (g === 'rocket') beep(110, 0.22, 'sawtooth', 0.1, 0.5);
    else if (g === 'flame') beep(140, 0.05, 'sawtooth', 0.02, 0.7);
    else if (g === 'homing') beep(700, 0.08, 'triangle', 0.05, 0.7);
  }

  function kill(e) {
    score += TYPES[e.type].pts;
    dropItem(e.x, e.y, e.type === 'boss');
    sfx.kill();
    burst(e.x, e.y, TYPES[e.type].col, e.type === 'boss' ? 36 : 12, e.type === 'boss' ? 260 : 180);
    if (e.type === 'boss') shake = 12;
    updateHud();
  }

  function explode(x, y) {
    const R = 95, dmg = 4 + 2 * p.dmg;
    for (const e of enemies) {
      if (e.hp <= 0) continue;
      if (Math.hypot(e.x - x, e.y - y) < R + e.r) {
        e.hp -= dmg;
        if (e.hp <= 0) kill(e); else burst(e.x, e.y, '#ff9a2a', 4, 120);
      }
    }
    fx.push({ x, y, t: 0.35, max: 0.35, R });
    burst(x, y, '#ff7a3c', 18, 260);
    beep(90, 0.35, 'sawtooth', 0.14, 0.3);
    shake = Math.max(shake, 8);
    enemies = enemies.filter(e => e.hp > 0);
  }

  // ---------- बॉस के अलग-अलग हमले ----------
  const BN = ['रिंग बॉस', 'सर्पिल बॉस', 'झपट्टा बॉस', 'बुलावा बॉस', 'पंखा बॉस'];
  const BD = ['चारों तरफ़ गोलियों का घेरा', 'घूमती गोलियों की धार', 'चमके तो किनारे हटो', 'अपने साथी बुलाता है', 'सामने गोलियों का पंखा'];

  function ring(e, n, off, speed, dmg) {
    for (let i = 0; i < n; i++) enemyShoot(e, off + i / n * TAU, speed, dmg);
  }

  function bossAI(e, dt) {
    if (e.k === undefined) {
      e.k = (Math.max(1, Math.floor(wave / 5)) - 1) % 5;
      e.bt = 2; e.bs = 'idle'; e.n = 0; e.rot = 0; e.fc = 0;
      note('बॉस: ' + BN[e.k] + ' — ' + BD[e.k]);
    }
    e.cd = 999; // पुराना गोलों का हमला बंद
    const dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy) || 1;
    const ang = Math.atan2(dy, dx), sp = 170 + wave * 2, dm = 9 * dmgMult(wave);
    const k = e.k;
    e.bt -= dt;

    if (k === 0) {
      // रिंग: चेतावनी, फिर गोलियों का घेरा
      if (e.bs === 'idle') { if (e.bt <= 0) { e.bs = 'wind'; e.bt = 0.5; } }
      else if (e.bt <= 0) {
        const n = Math.min(18, 8 + Math.floor(wave / 5) * 2);
        ring(e, n, e.rot, sp, dm);
        if (wave >= 20) ring(e, n, e.rot + TAU / n / 2, sp * 0.7, dm);
        e.rot += 0.25; sfx.efire();
        e.bs = 'idle'; e.bt = Math.max(1.3, 2.6 - wave * 0.03);
      }
    } else if (k === 1) {
      // सर्पिल: घूमती धार, फिर आराम
      if (e.bs === 'idle') { if (e.bt <= 0) { e.bs = 'wind'; e.bt = 0.6; } }
      else if (e.bs === 'wind') { if (e.bt <= 0) { e.bs = 'fire'; e.bt = 2.6; e.fc = 0; sfx.efire(); } }
      else {
        e.fc -= dt;
        if (e.fc <= 0) {
          enemyShoot(e, e.rot, sp, dm);
          enemyShoot(e, e.rot + Math.PI, sp, dm);
          if (wave >= 20) {
            enemyShoot(e, e.rot + Math.PI / 2, sp, dm);
            enemyShoot(e, e.rot + Math.PI * 1.5, sp, dm);
          }
          e.rot += 0.38; e.fc = 0.12;
        }
        if (e.bt <= 0) { e.bs = 'idle'; e.bt = Math.max(1.3, 2.4 - wave * 0.02); }
      }
    } else if (k === 2) {
      // झपट्टा: चमकता है, फिर तेज़ी से झपटता है
      if (e.bs === 'idle') { if (e.bt <= 0) { e.bs = 'wind'; e.bt = 0.75; e.n = wave >= 25 ? 3 : 2; } }
      else if (e.bs === 'wind') { if (e.bt <= 0) { e.bs = 'dash'; e.bt = 0.5; e.dx = dx / d; e.dy = dy / d; } }
      else if (e.bs === 'dash') {
        e.x = Math.min(W - e.r, Math.max(e.r, e.x + e.dx * 520 * dt));
        e.y = Math.min(H - e.r, Math.max(e.r, e.y + e.dy * 520 * dt));
        if (e.bt <= 0) {
          e.n--;
          if (e.n > 0) { e.bs = 'wind'; e.bt = 0.5; }
          else { e.bs = 'rest'; e.bt = 1.2; ring(e, 12, ang, 220, dm); sfx.efire(); }
        }
      } else if (e.bt <= 0) { e.bs = 'idle'; e.bt = 1.5; }
    } else if (k === 3) {
      // बुलावा: साथी बुलाता है और तीन गोलियाँ चलाता है
      if (e.bs === 'idle') {
        e.fc -= dt;
        if (e.fc <= 0) {
          for (const a of [-0.25, 0, 0.25]) enemyShoot(e, ang + a, sp * 1.2, dm);
          e.fc = 2.2; sfx.efire();
        }
        if (e.bt <= 0) { e.bs = 'wind'; e.bt = 0.7; }
      } else if (e.bt <= 0) {
        const alive = enemies.filter(x => x.type !== 'boss').length;
        const n = Math.min(4, Math.max(0, 11 - alive));
        for (let i = 0; i < n; i++) {
          spawnEnemy(wave >= 20 && i === 0 ? 'tank' : (Math.random() < 0.5 ? 'fast' : 'normal'));
          const m = enemies[enemies.length - 1];
          m.x = e.x + (Math.random() - 0.5) * 120;
          m.y = e.y + (Math.random() - 0.5) * 120;
        }
        burst(e.x, e.y, '#8be0a0', 16, 200); sfx.wave();
        e.bs = 'idle'; e.bt = Math.max(3.5, 5.5 - wave * 0.04);
      }
    } else {
      // पंखा: सीधे आप की तरफ़ गोलियों का पंखा, तीन बार
      if (e.bs === 'idle') { if (e.bt <= 0) { e.bs = 'wind'; e.bt = 0.65; } }
      else if (e.bs === 'wind') { if (e.bt <= 0) { e.bs = 'fire'; e.n = wave >= 25 ? 4 : 3; e.fc = 0; } }
      else {
        e.fc -= dt;
        if (e.fc <= 0) {
          const cnt = 6;
          for (let i = 0; i < cnt; i++) enemyShoot(e, ang + (i / (cnt - 1) - 0.5) * 1.1, sp * 1.3, dm);
          sfx.efire(); e.n--; e.fc = 0.22;
          if (e.n <= 0) { e.bs = 'idle'; e.bt = Math.max(1.8, 3 - wave * 0.02); }
        }
      }
    }

    // चमकने का इशारा (चेतावनी)
    e.state = e.bs === 'wind' ? 'wind' : '';
    e.wt = Math.max(0, e.bt);
  }

  // ---------- अपडेट में जोड़ना ----------
  const _update = update;
  update = function (dt) {
    const eff = (p.gun !== 'pistol' && p.gunT - dt <= 0) ? 'pistol' : p.gun;
    const G = NG[eff];
    const bd = p.dmg, bp = p.pierce;
    let muted = null;
    if (G) {
      p.dmg = bd * G.dm;
      p.pierce = G.po !== undefined ? G.po : bp + (G.pi || 0);
      if (eff === 'flame') { muted = [sfx.shoot, sfx.hit]; sfx.shoot = sfx.hit = () => {}; }
    }
    try { _update(dt); }
    finally {
      p.dmg = bd; p.pierce = bp;
      if (muted) { sfx.shoot = muted[0]; sfx.hit = muted[1]; }
    }

    // नई गोलियों पर बंदूक का असर
    let fired = false;
    for (const b of bullets) {
      if (b.g !== undefined) continue;
      b.g = eff;
      if (G) {
        b.vx *= G.sp; b.vy *= G.sp; b.l0 = b.life;
        if (G.ex) rk.push(b);
        if (!fired) { fired = true; gunSound(eff); }
      }
    }

    // होमिंग गोलियाँ दुश्मन की तरफ़ मुड़ती हैं
    for (const b of bullets) {
      if (b.g !== 'homing') continue;
      let t = null, best = 450;
      for (const e of enemies) {
        const dd = Math.hypot(e.x - b.x, e.y - b.y);
        if (dd < best && !b.hit.includes(e)) { best = dd; t = e; }
      }
      if (!t) continue;
      const spd = Math.hypot(b.vx, b.vy), cur = Math.atan2(b.vy, b.vx);
      let df = Math.atan2(t.y - b.y, t.x - b.x) - cur;
      while (df > Math.PI) df -= TAU;
      while (df < -Math.PI) df += TAU;
      const turn = Math.max(-6.5 * dt, Math.min(6.5 * dt, df));
      b.vx = Math.cos(cur + turn) * spd; b.vy = Math.sin(cur + turn) * spd;
    }

    // रॉकेट फटते हैं
    rk = rk.filter(b => {
      if (b.life <= 0) { explode(b.x, b.y); return false; }
      return true;
    });
    for (const f of fx) f.t -= dt;
    fx = fx.filter(f => f.t > 0);

    // बॉस के हमले
    for (const e of enemies) if (e.type === 'boss') bossAI(e, dt);
  };

  const _reset = reset;
  reset = function () { _reset(); rk = []; fx = []; ghUpdate(); };

  // ---------- ड्रॉइंग ----------
  const _draw = draw;
  draw = function () {
    const all = bullets;
    bullets = all.filter(b => !NG[b.g]);
    try { _draw(); } finally { bullets = all; }

    ctx.save();
    if (shake > 0) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
    ctx.lineCap = 'round';
    for (const b of all) {
      if (!NG[b.g]) continue;
      if (b.g === 'sniper') {
        ctx.strokeStyle = 'rgba(79,209,255,.55)'; ctx.lineWidth = 5;
        ctx.beginPath(); ctx.moveTo(b.x - b.vx * 0.045, b.y - b.vy * 0.045); ctx.lineTo(b.x, b.y); ctx.stroke();
        ctx.fillStyle = '#e8fbff'; ctx.beginPath(); ctx.arc(b.x, b.y, 4, 0, 7); ctx.fill();
      } else if (b.g === 'rocket') {
        ctx.fillStyle = 'rgba(255,154,42,.5)';
        ctx.beginPath(); ctx.arc(b.x - b.vx * 0.02, b.y - b.vy * 0.02, 6, 0, 7); ctx.fill();
        ctx.fillStyle = '#ff4040'; ctx.beginPath(); ctx.arc(b.x, b.y, 6.5, 0, 7); ctx.fill();
        ctx.strokeStyle = '#5a0f0f'; ctx.lineWidth = 2; ctx.stroke();
      } else if (b.g === 'flame') {
        const k = Math.max(0, b.life / (b.l0 || 0.3));
        ctx.fillStyle = 'rgba(255,' + Math.round(80 + 140 * k) + ',30,' + (0.25 + 0.5 * k) + ')';
        ctx.beginPath(); ctx.arc(b.x, b.y, 5 + (1 - k) * 9, 0, 7); ctx.fill();
      } else {
        ctx.strokeStyle = 'rgba(217,106,214,.5)'; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.moveTo(b.x - b.vx * 0.04, b.y - b.vy * 0.04); ctx.lineTo(b.x, b.y); ctx.stroke();
        ctx.fillStyle = '#d96ad6'; ctx.beginPath(); ctx.arc(b.x, b.y, 5, 0, 7); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(b.x, b.y, 2, 0, 7); ctx.fill();
      }
    }
    for (const f of fx) {
      const a = Math.max(0, f.t / f.max), r = f.R * (1 - a * 0.6);
      ctx.fillStyle = 'rgba(255,154,42,' + (0.35 * a) + ')';
      ctx.beginPath(); ctx.arc(f.x, f.y, r, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(255,230,160,' + a + ')'; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.arc(f.x, f.y, r, 0, 7); ctx.stroke();
    }
    ctx.restore();
    ghUpdate();
  };

  reset();
  draw();
})();