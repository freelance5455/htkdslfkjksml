# MR,KHORASANI v2.0 Build Status

## Implemented
- Real HTTP backend in Node.js.
- SQLite transactional persistence for zero-dependency local execution.
- PostgreSQL production schema reference in `backend/schema.postgres.sql`.
- User authentication with scrypt password hashing and expiring bearer sessions.
- Roles: admin, accountant, sales, viewer.
- Party and product master APIs.
- Sales/returns and purchase/returns invoice API with server-side totals.
- Automatic balanced double-entry journal creation.
- Receipt/payment/transfer API with accounting posting.
- Received/issued cheque lifecycle with initial and clearing journal entries.
- Day-close lock: transactional writes dated on a closed Shamsi day are rejected.
- Trial balance, journal, one-page daily report and audit log endpoints.
- Automated API integration tests and existing accounting logic tests.
- Existing PWA remains served from the same server.

## Not yet claimed
- Native APK/AAB build is not included in v2.0.
- PostgreSQL runtime adapter is schema-ready but not wired as the default runtime adapter yet.
- Full UI-to-API migration is not complete; the current browser UI still supports its localStorage workflow.
- Direct Samaneh Moadian API integration is not claimed until official technical specifications/credentials are implemented and tested.

## Local start
1. Set `MRK_ADMIN_PASSWORD` before first start.
2. Run `npm start`.
3. Open `http://localhost:4173`.
4. Backend health: `GET /api/health`.

## Tests
`npm test` must report both `MRK logic tests: PASS` and `MRK backend API tests: PASS`.
