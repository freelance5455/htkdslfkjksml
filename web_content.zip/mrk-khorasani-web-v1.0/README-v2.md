# MR,KHORASANI Finance — v2.0

نسخه ۲٫۰، لایه واقعی Backend را به پروژه وب/PWA اضافه می‌کند.

### اجرای سریع
```bash
export MRK_ADMIN_PASSWORD='یک-رمز-قوی'
npm start
```

سپس: `http://localhost:4173`

### Backend
- Node.js HTTP server
- SQLite local transactional database
- PostgreSQL production schema reference
- Authentication + roles
- Double-entry journal enforcement
- Day close lock
- Audit log
- Reports API

### نکته حسابداری
سندهای فروش/برگشت، خرید/برگشت، دریافت، پرداخت، انتقال و چرخه چک در Backend با کنترل توازن سند طراحی شده‌اند. VAT نرخ ثابت قانونی فرض نشده و به‌صورت پارامتر سند ذخیره می‌شود.

### APK
در این نسخه هنوز APK/AAB واقعی ساخته نشده است. پس از تکمیل اتصال UI به API و فراهم شدن Android toolchain، پروژه Android از همین Backend/PWA ساخته و تست خواهد شد.
