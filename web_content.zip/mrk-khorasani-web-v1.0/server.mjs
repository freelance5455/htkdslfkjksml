import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';
const root=path.resolve(new URL('.',import.meta.url).pathname);
const port=process.env.PORT||4173;
const mime={'.html':'text/html;charset=utf-8','.js':'text/javascript;charset=utf-8','.css':'text/css;charset=utf-8','.json':'application/json;charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.csv':'text/csv;charset=utf-8','.txt':'text/plain;charset=utf-8'};
const server=http.createServer((req,res)=>{const u=url.parse(req.url).pathname;let p=path.normalize(path.join(root,u==='/'?'index.html':u));if(!p.startsWith(root))return res.writeHead(403).end('Forbidden');fs.stat(p,(err,st)=>{if(err||!st.isFile())return res.writeHead(404).end('Not found');res.setHeader('Content-Type',mime[path.extname(p)]||'application/octet-stream');res.end(fs.readFileSync(p));});});
server.listen(port,()=>console.log(`MRK Finance PWA: http://localhost:${port}`));
