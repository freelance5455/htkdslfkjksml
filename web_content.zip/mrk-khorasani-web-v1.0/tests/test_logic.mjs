import assert from 'node:assert/strict';
function sale(gross,discount,freight,other,vatRate){const net=gross-discount,base=Math.max(0,net+freight-other),vat=base*vatRate/100;return {net,vat,total:base+vat};}
const s=sale(100000000,5000000,2000000,0,10);assert.equal(s.net,95000000);assert.equal(s.vat,9700000);assert.equal(s.total,106700000);
function balanced(lines){return lines.reduce((a,l)=>a+l.debit,0)===lines.reduce((a,l)=>a+l.credit,0)}
assert.equal(balanced([{debit:100,credit:0},{debit:0,credit:100}]),true);
assert.equal(balanced([{debit:90,credit:0},{debit:0,credit:100}]),false);
function locked(closed,date){return closed.includes(date)}assert.equal(locked(['1405/06/03'],'1405/06/03'),true);assert.equal(locked(['1405/06/03'],'1405/06/04'),false);
console.log('MRK logic tests: PASS');
