-- MR,KHORASANI Accounting Core (PostgreSQL reference schema)
-- Production backend should use this relational model instead of browser localStorage.
create table if not exists fiscal_years(id uuid primary key, code varchar(10) unique not null, title text not null, start_date date not null, end_date date not null, is_closed boolean default false);
create table if not exists parties(id uuid primary key, code varchar(40) unique not null, name text not null, kind varchar(30) not null, phone text, national_id text, economic_id text, tax_profile text, address text, active boolean default true);
create table if not exists products(id uuid primary key, code varchar(50) unique not null, barcode varchar(100), name text not null, unit text, product_group text, purchase_price numeric(20,2) default 0, sale_price numeric(20,2) default 0, active boolean default true);
create table if not exists accounts(id uuid primary key, full_code varchar(50) unique not null, group_code varchar(20), group_name text, sub_code varchar(20), sub_name text, ledger_code varchar(20), ledger_name text, detail_code varchar(30), detail_name text, nature varchar(20) not null, parent_code varchar(50));
create table if not exists cost_centers(id uuid primary key, code varchar(40) unique not null, name text not null, active boolean default true);
create table if not exists invoices(id uuid primary key, invoice_no varchar(60) not null, invoice_type varchar(30) not null, date_sh varchar(12) not null, party_id uuid references parties(id), due_date_sh varchar(12), status varchar(20), freight numeric(20,2) default 0, other_deduction numeric(20,2) default 0, vat_rate numeric(8,4) default 0, vat_amount numeric(20,2) default 0, net_amount numeric(20,2) default 0, total_amount numeric(20,2) default 0, warehouse text, shipping_method text, reference_no text, cost_center_id uuid references cost_centers(id), description text, created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists invoice_lines(id uuid primary key, invoice_id uuid references invoices(id) on delete cascade, line_no int not null, product_id uuid references products(id), qty numeric(20,4) not null, unit_price numeric(20,2) not null, discount_amount numeric(20,2) default 0, discount_percent numeric(8,4) default 0, line_net numeric(20,2) not null);
create table if not exists cash_transactions(id uuid primary key, date_sh varchar(12) not null, transaction_type varchar(20) not null, party_id uuid references parties(id), invoice_id uuid references invoices(id), source_account varchar(50) references accounts(full_code), destination_account varchar(50) references accounts(full_code), amount numeric(20,2) not null, reference_no text, description text);
create table if not exists checks(id uuid primary key, kind varchar(20) not null, issue_date_sh varchar(12) not null, due_date_sh varchar(12) not null, cleared_date_sh varchar(12), party_id uuid references parties(id), cheque_no varchar(80), bank text, amount numeric(20,2) not null, status varchar(30) not null, description text);
create table if not exists journal_entries(id uuid primary key, voucher_no bigint not null unique, date_sh varchar(12) not null, source_type varchar(30) not null, source_id uuid, description text, is_balanced boolean not null);
create table if not exists journal_lines(id uuid primary key, journal_id uuid references journal_entries(id) on delete cascade, account_code varchar(50) references accounts(full_code), party_id uuid references parties(id), cost_center_id uuid references cost_centers(id), debit numeric(20,2) default 0, credit numeric(20,2) default 0, description text);
create table if not exists day_closes(id uuid primary key, date_sh varchar(12) unique not null, closed_by text not null, closed_at timestamptz not null default now(), locked boolean not null default true);
create table if not exists audit_log(id uuid primary key, event_at timestamptz default now(), user_name text, action varchar(30), entity varchar(50), record_id uuid, details text);

create or replace function validate_journal_balance() returns trigger language plpgsql as $$
begin
  if exists(select 1 from journal_entries j where j.id=new.journal_id and j.is_balanced=false) then
    raise exception 'Journal entry must be balanced before posting';
  end if;
  return new;
end $$;
