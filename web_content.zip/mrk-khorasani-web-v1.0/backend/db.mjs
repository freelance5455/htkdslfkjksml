import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const dir = path.resolve(new URL('.', import.meta.url).pathname);
const dataDir = path.join(dir, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const dbPath = process.env.MRK_DB || path.join(dataDir, 'mrk.sqlite');
const schema = fs.readFileSync(path.join(dir, 'schema.sqlite.sql'), 'utf8');
export const db = new DatabaseSync(dbPath);
db.exec(schema);

db.exec(`PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;`);

export const uuid = () => crypto.randomUUID();
export const nowIso = () => new Date().toISOString();
export function tx(fn){ db.exec('BEGIN IMMEDIATE'); try { const out=fn(); db.exec('COMMIT'); return out; } catch(e){ try{db.exec('ROLLBACK')}catch{}; throw e; } }
export function one(sql, params=[]){ return db.prepare(sql).get(...params); }
export function all(sql, params=[]){ return db.prepare(sql).all(...params); }
export function run(sql, params=[]){ return db.prepare(sql).run(...params); }
export function seed(){
  if (!one('select id from users limit 1')) {
    const salt=crypto.randomBytes(16).toString('hex');
    const hash=crypto.scryptSync(process.env.MRK_ADMIN_PASSWORD||'MRK-ChangeMe-1405', salt, 64).toString('hex');
    run('insert into users(id,username,display_name,role,password_hash,password_salt) values(?,?,?,?,?,?)',[uuid(),'admin','مدیر سیستم','admin',hash,salt]);
  }
  const accounts=[
    ['1101','وجه نقد','debit'],['1102','بانک','debit'],['1103','اسناد دریافتنی','debit'],['1201','حسابهای دریافتنی','debit'],
    ['1301','مالیات و عوارض ارزش افزوده خرید','debit'],['1401','موجودی کالا','debit'],['2101','حسابهای پرداختنی','credit'],['2102','اسناد پرداختنی','credit'],
    ['2201','مالیات و عوارض ارزش افزوده فروش','credit'],['4101','فروش','credit'],['4102','برگشت از فروش','debit'],['5101','خرید','debit'],['6101','هزینه های عملیاتی','debit']
  ];
  for(const [code,name,nature] of accounts){ if(!one('select id from accounts where full_code=?',[code])) run('insert into accounts(id,full_code,group_code,group_name,ledger_code,ledger_name,detail_name,nature) values(?,?,?,?,?,?,?,?)',[uuid(),code,code.slice(0,1),'حساب کل',code,name,name,nature]); }
  if(!one('select id from fiscal_years limit 1')) run('insert into fiscal_years(id,code,title,start_date_sh,end_date_sh) values(?,?,?,?,?)',[uuid(),'1405','سال مالی ۱۴۰۵','1405/01/01','1405/12/29']);
}
seed();
