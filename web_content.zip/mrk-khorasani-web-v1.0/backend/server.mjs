import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { db, uuid, nowIso, tx, one, all, run } from './db.mjs';

const root=path.resolve(new URL('../',import.meta.url).pathname);
const port=Number(process.env.PORT||4173);
const mime={'.html':'text/html;charset=utf-8','.js':'text/javascript;charset=utf-8','.css':'text/css;charset=utf-8','.json':'application/json;charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.csv':'text/csv;charset=utf-8'};
const roles={admin:new Set(['*']),accountant:new Set(['read','write','close']),sales:new Set(['read','write:sales','write:cash']),viewer:new Set(['read'])};
const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json;charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
const text=(res,status,data,type='text/plain;charset=utf-8')=>{res.writeHead(status,{'Content-Type':type});res.end(data);};
async function body(req){let s='';for await(const c of req)s+=c;return s?JSON.parse(s):{};}
function hashPassword(password,salt){return crypto.scryptSync(password,salt,64).toString('hex');}
function auth(req, permission='read'){
  const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
  if(!token) throw Object.assign(new Error('ورود لازم است'),{status:401});
  const s=one('select s.*,u.username,u.display_name,u.role from sessions s join users u on u.id=s.user_id where s.token=? and u.active=1',[token]);
  if(!s || new Date(s.expires_at)<=new Date()) throw Object.assign(new Error('نشست منقضی شده است'),{status:401});
  const ok=roles[s.role]?.has('*')||roles[s.role]?.has(permission)||permission==='read'&&roles[s.role]?.has('read');
  if(!ok) throw Object.assign(new Error('دسترسی کافی نیست'),{status:403});
  return s;
}
function assertOpen(dateSh){if(one('select id from day_closes where date_sh=? and locked=1',[dateSh])) throw Object.assign(new Error(`روز ${dateSh} بسته است`),{status:409});}
function audit(user,action,entity,id,details){run('insert into audit_log(id,user_name,action,entity,record_id,details) values(?,?,?,?,?,?)',[uuid(),user,action,entity,id,JSON.stringify(details||{})]);}
function account(code){if(!one('select full_code from accounts where full_code=? and active=1',[code])) throw Object.assign(new Error(`حساب ${code} وجود ندارد`),{status:422});}
function balanced(lines){const d=lines.reduce((s,x)=>s+Number(x.debit||0),0);const c=lines.reduce((s,x)=>s+Number(x.credit||0),0);return Math.round((d-c)*100)/100===0;}
function nextVoucher(){return Number(one('select coalesce(max(voucher_no),0)+1 n from journal_entries').n);}
function postJournal({dateSh,dateIso,sourceType,sourceId,description,lines,createdBy}){
  if(!lines.length||!balanced(lines)) throw Object.assign(new Error('سند نامتوازن است'),{status:422});
  for(const l of lines){account(l.accountCode); if(l.partyId && !one('select id from parties where id=?',[l.partyId])) throw Object.assign(new Error('تفصیلی/طرف حساب نامعتبر است'),{status:422});}
  const id=uuid(); run('insert into journal_entries(id,voucher_no,date_sh,date_iso,source_type,source_id,description,is_balanced,created_by) values(?,?,?,?,?,?,?,?,?)',[id,nextVoucher(),dateSh,dateIso||null,sourceType,sourceId||null,description||'',1,createdBy]);
  lines.forEach((l,i)=>run('insert into journal_lines(id,journal_id,line_no,account_code,party_id,cost_center_id,debit,credit,description) values(?,?,?,?,?,?,?,?,?)',[uuid(),id,i+1,l.accountCode,l.partyId||null,l.costCenterId||null,Number(l.debit||0),Number(l.credit||0),l.description||description||'']));
  return id;
}
function invoiceTotals(lines,freight=0,other=0,vatRate=0){const gross=lines.reduce((s,l)=>s+Number(l.qty)*Number(l.unit_price ?? l.unitPrice ?? 0),0);const disc=lines.reduce((s,l)=>s+Number(l.discount_amount ?? l.discountAmount ?? 0),0);const net=gross-disc;const base=Math.max(0,net+Number(freight||0)-Number(other||0));const vat=base*Number(vatRate||0)/100;return {gross,discount:disc,net,freight:Number(freight||0),other:Number(other||0),vat,total:base+vat};}
function invoiceJournal(inv, totals, user){
  const customer=inv.party_id; const isSale=inv.invoice_type==='sale'||inv.invoice_type==='sale_return';
  if(!customer) throw Object.assign(new Error('طرف حساب برای سند لازم است'),{status:422});
  if(isSale){
    const sign=inv.invoice_type==='sale_return'?-1:1;
    const lines=[
      {accountCode:'1201',partyId:customer,debit:sign<0?0:totals.total,credit:sign<0?totals.total:0,description:inv.description||'فروش'},
      {accountCode:'4101',debit:sign<0?(totals.net+totals.freight-totals.other):0,credit:sign<0?0:(totals.net+totals.freight-totals.other),description:'فروش و حمل'},
      {accountCode:'2201',debit:sign<0?totals.vat:0,credit:sign<0?0:totals.vat,description:'مالیات و عوارض ارزش افزوده فروش'}
    ]; return postJournal({dateSh:inv.date_sh,dateIso:inv.date_iso,sourceType:inv.invoice_type,sourceId:inv.id,description:inv.description||`سند ${inv.invoice_no}`,lines,createdBy:user});
  }
  const sign=inv.invoice_type==='purchase_return'?-1:1;
  const lines=[
    {accountCode:'1401',partyId:null,debit:sign>0?(totals.net+totals.freight-totals.other):0,credit:sign<0?(totals.net+totals.freight-totals.other):0,description:'خرید و حمل'},
    {accountCode:'1301',debit:sign>0?totals.vat:0,credit:sign<0?totals.vat:0,description:'مالیات و عوارض ارزش افزوده خرید'},
    {accountCode:'2101',partyId:customer,debit:sign<0?totals.total:0,credit:sign>0?totals.total:0,description:'تامین کننده'}
  ]; return postJournal({dateSh:inv.date_sh,dateIso:inv.date_iso,sourceType:inv.invoice_type,sourceId:inv.id,description:inv.description||`سند ${inv.invoice_no}`,lines,createdBy:user});
}
function listResource(table,q,kind){let sql=`select * from ${table}`;const p=[];if(kind){sql+=' where kind=?';p.push(kind)}if(q){sql+=(kind?' and':' where')+' (name like ? or code like ?)';p.push('%'+q+'%','%'+q+'%')}sql+=' order by name,code limit 500';return all(sql,p);}

async function route(req,res){
  const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);const p=u.pathname;const method=req.method;
  if(method==='GET'&&p==='/api/health') return json(res,200,{ok:true,service:'MR,KHORASANI Backend',version:'2.0.0',db:'sqlite'});
  if(method==='POST'&&p==='/api/auth/login'){
    const b=await body(req);const user=one('select * from users where username=? and active=1',[String(b.username||'')]);
    if(!user||hashPassword(String(b.password||''),user.password_salt)!==user.password_hash)return json(res,401,{error:'نام کاربری یا رمز عبور نادرست است'});
    const token=crypto.randomBytes(32).toString('hex');const expires=new Date(Date.now()+12*3600e3).toISOString();run('insert into sessions(token,user_id,expires_at) values(?,?,?)',[token,user.id,expires]);return json(res,200,{token,expires_at:expires,user:{username:user.username,display_name:user.display_name,role:user.role}});
  }
  try{
    if(method==='GET'&&p==='/api/bootstrap'){const s=auth(req);return json(res,200,{company:'MR,KHORASANI',user:{username:s.username,display_name:s.display_name,role:s.role},fiscal_year:one('select * from fiscal_years order by code desc limit 1'),accounts:all('select * from accounts where active=1 order by full_code'),settings:all('select key,value from settings')});}
    if(method==='GET'&&p==='/api/parties'){auth(req);return json(res,200,listResource('parties',u.searchParams.get('q'),u.searchParams.get('kind')));}
    if(method==='POST'&&p==='/api/parties'){const s=auth(req,'write');const b=await body(req);if(!b.code||!b.name||!b.kind)throw Object.assign(new Error('کد، نام و نوع طرف حساب الزامی است'),{status:422});const id=uuid();run('insert into parties(id,code,name,kind,phone,national_id,economic_id,tax_profile,address) values(?,?,?,?,?,?,?,?,?)',[id,b.code,b.name,b.kind,b.phone||null,b.national_id||null,b.economic_id||null,b.tax_profile||null,b.address||null]);audit(s.username,'create','party',id,b);return json(res,201,{id,...one('select * from parties where id=?',[id])});}
    if(method==='GET'&&p==='/api/products'){auth(req);return json(res,200,listResource('products',u.searchParams.get('q')));}
    if(method==='POST'&&p==='/api/products'){const s=auth(req,'write');const b=await body(req);if(!b.code||!b.name)throw Object.assign(new Error('کد و نام کالا الزامی است'),{status:422});const id=uuid();run('insert into products(id,code,barcode,name,unit,product_group,purchase_price,sale_price) values(?,?,?,?,?,?,?,?)',[id,b.code,b.barcode||null,b.name,b.unit||null,b.product_group||null,Number(b.purchase_price||0),Number(b.sale_price||0)]);audit(s.username,'create','product',id,b);return json(res,201,one('select * from products where id=?',[id]));}
    if(method==='POST'&&p==='/api/invoices'){
      const s=auth(req,'write');const b=await body(req);if(!b.invoice_no||!b.invoice_type||!b.date_sh||!Array.isArray(b.lines)||!b.lines.length)throw Object.assign(new Error('شماره، نوع، تاریخ و اقلام فاکتور الزامی است'),{status:422});assertOpen(b.date_sh);
      const totals=invoiceTotals(b.lines,b.freight,b.other_deduction,b.vat_rate);const id=uuid();
      tx(()=>{run('insert into invoices(id,invoice_no,invoice_type,date_sh,date_iso,party_id,due_date_sh,due_date_iso,status,freight,other_deduction,vat_rate,vat_amount,net_amount,total_amount,warehouse,shipping_method,reference_no,cost_center_id,description,created_by) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[id,b.invoice_no,b.invoice_type,b.date_sh,b.date_iso||null,b.party_id||null,b.due_date_sh||null,b.due_date_iso||null,'open',Number(b.freight||0),Number(b.other_deduction||0),Number(b.vat_rate||0),totals.vat,totals.net,totals.total,b.warehouse||null,b.shipping_method||null,b.reference_no||null,b.cost_center_id||null,b.description||null,s.username]);b.lines.forEach((l,i)=>run('insert into invoice_lines(id,invoice_id,line_no,product_id,qty,unit_price,discount_amount,discount_percent,line_net) values(?,?,?,?,?,?,?,?,?)',[uuid(),id,i+1,l.product_id||null,Number(l.qty),Number(l.unit_price),Number(l.discount_amount||0),Number(l.discount_percent||0),Number(l.qty)*Number(l.unit_price)-Number(l.discount_amount||0)]));invoiceJournal(one('select * from invoices where id=?',[id]),totals,s.username);audit(s.username,'create','invoice',id,{invoice_no:b.invoice_no,totals});});
      return json(res,201,{id,totals,journal:one('select * from journal_entries where source_id=?',[id])});
    }
    if(method==='POST'&&p==='/api/cash-transactions'){
      const s=auth(req,'write:cash');const b=await body(req);if(!b.date_sh||!b.transaction_type||!b.amount||!b.source_account)throw Object.assign(new Error('تاریخ، نوع، مبلغ و حساب منبع الزامی است'),{status:422});assertOpen(b.date_sh);const id=uuid();
      tx(()=>{run('insert into cash_transactions(id,date_sh,date_iso,transaction_type,party_id,invoice_id,source_account,destination_account,amount,reference_no,description,created_by) values(?,?,?,?,?,?,?,?,?,?,?,?)',[id,b.date_sh,b.date_iso||null,b.transaction_type,b.party_id||null,b.invoice_id||null,b.source_account,b.destination_account||null,Number(b.amount),b.reference_no||null,b.description||null,s.username]);let lines;if(b.transaction_type==='receipt')lines=[{accountCode:b.source_account,debit:Number(b.amount),credit:0,partyId:b.party_id},{accountCode:'1201',debit:0,credit:Number(b.amount),partyId:b.party_id}];else if(b.transaction_type==='payment')lines=[{accountCode:b.source_account,debit:0,credit:Number(b.amount),partyId:b.party_id},{accountCode:b.destination_account||'2101',debit:Number(b.amount),credit:0,partyId:b.party_id}];else lines=[{accountCode:b.destination_account,debit:Number(b.amount),credit:0},{accountCode:b.source_account,debit:0,credit:Number(b.amount)}];postJournal({dateSh:b.date_sh,dateIso:b.date_iso,sourceType:b.transaction_type,sourceId:id,description:b.description||b.transaction_type,lines,createdBy:s.username});audit(s.username,'create','cash_transaction',id,b);});return json(res,201,{id});
    }
    if(method==='POST'&&p==='/api/checks'){
      const s=auth(req,'write');const b=await body(req);if(!b.kind||!b.issue_date_sh||!b.due_date_sh||!b.amount)throw Object.assign(new Error('نوع، تاریخ صدور، سررسید و مبلغ چک الزامی است'),{status:422});assertOpen(b.issue_date_sh);const id=uuid();
      tx(()=>{run('insert into checks(id,kind,issue_date_sh,issue_date_iso,due_date_sh,due_date_iso,party_id,invoice_id,cheque_no,bank,amount,status,description,created_by) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[id,b.kind,b.issue_date_sh,b.issue_date_iso||null,b.due_date_sh,b.due_date_iso||null,b.party_id||null,b.invoice_id||null,b.cheque_no||null,b.bank||null,Number(b.amount),b.status||'در جریان',b.description||null,s.username]);
        const lines=b.kind==='received'?[{accountCode:'1103',debit:Number(b.amount),credit:0,partyId:b.party_id},{accountCode:'1201',debit:0,credit:Number(b.amount),partyId:b.party_id}]:[{accountCode:'2101',debit:Number(b.amount),credit:0,partyId:b.party_id},{accountCode:'2102',debit:0,credit:Number(b.amount),partyId:b.party_id}];
        postJournal({dateSh:b.issue_date_sh,dateIso:b.issue_date_iso,sourceType:b.kind==='received'?'check_received':'check_issued',sourceId:id,description:b.description||`چک ${b.cheque_no||''}`.trim(),lines,createdBy:s.username});audit(s.username,'create','check',id,b);
      });return json(res,201,one('select * from checks where id=?',[id]));}
    if(method==='PATCH'&&/^\/api\/checks\/[^/]+$/.test(p)){
      const s=auth(req,'write');const id=p.split('/').pop();const b=await body(req);const old=one('select * from checks where id=?',[id]);if(!old)throw Object.assign(new Error('چک یافت نشد'),{status:404});assertOpen(old.issue_date_sh);
      tx(()=>{run('update checks set status=coalesce(?,status),cleared_date_sh=coalesce(?,cleared_date_sh),cleared_date_iso=coalesce(?,cleared_date_iso),description=coalesce(?,description),updated_at=CURRENT_TIMESTAMP where id=?',[b.status||null,b.cleared_date_sh||null,b.cleared_date_iso||null,b.description||null,id]);
        if((b.status==='تسویه شده'||b.status==='cleared') && old.status!=='تسویه شده' && old.status!=='cleared'){const bank=b.clearing_account||'1102';account(bank);const lines=old.kind==='received'?[{accountCode:bank,debit:Number(old.amount),credit:0,partyId:old.party_id},{accountCode:'1103',debit:0,credit:Number(old.amount),partyId:old.party_id}]:[{accountCode:'2102',debit:Number(old.amount),credit:0,partyId:old.party_id},{accountCode:bank,debit:0,credit:Number(old.amount),partyId:old.party_id}];postJournal({dateSh:b.cleared_date_sh||old.due_date_sh,dateIso:b.cleared_date_iso||null,sourceType:old.kind==='received'?'check_clear_received':'check_clear_issued',sourceId:id,description:`تسویه چک ${old.cheque_no||''}`.trim(),lines,createdBy:s.username});}
        audit(s.username,'update','check',id,b);
      });return json(res,200,one('select * from checks where id=?',[id]));}
    if(method==='POST'&&p==='/api/day-closes'){const s=auth(req,'close');const b=await body(req);if(!b.date_sh)throw Object.assign(new Error('تاریخ روز الزامی است'),{status:422});if(one('select id from day_closes where date_sh=?',[b.date_sh]))return json(res,409,{error:'روز قبلا بسته شده است'});run('insert into day_closes(id,date_sh,closed_by) values(?,?,?)',[uuid(),b.date_sh,s.username]);audit(s.username,'close','day',null,{date_sh:b.date_sh});return json(res,201,{date_sh:b.date_sh,locked:true});}
    if(method==='GET'&&p==='/api/reports/trial-balance'){auth(req);const rows=all(`select jl.account_code,sum(jl.debit) debit,sum(jl.credit) credit,sum(jl.debit-jl.credit) balance from journal_lines jl join journal_entries je on je.id=jl.journal_id where (?='' or je.date_sh>=?) and (?='' or je.date_sh<=?) group by jl.account_code order by jl.account_code`,[u.searchParams.get('from')||'',u.searchParams.get('from')||'',u.searchParams.get('to')||'',u.searchParams.get('to')||'']);return json(res,200,rows);}
    if(method==='GET'&&p==='/api/reports/journal'){auth(req);return json(res,200,all(`select je.*,jl.line_no,jl.account_code,jl.party_id,jl.debit,jl.credit,jl.description line_description from journal_entries je join journal_lines jl on jl.journal_id=je.id where (?='' or je.date_sh>=?) and (?='' or je.date_sh<=?) order by je.date_sh,je.voucher_no,jl.line_no`,[u.searchParams.get('from')||'',u.searchParams.get('from')||'',u.searchParams.get('to')||'',u.searchParams.get('to')||'']));}
    if(method==='GET'&&p==='/api/reports/daily-one-page'){auth(req);const date=u.searchParams.get('date');if(!date)throw Object.assign(new Error('date الزامی است'),{status:422});return json(res,200,{date,sales:all('select * from invoices where date_sh=? and invoice_type in (\'sale\',\'sale_return\') order by invoice_no',[date]),purchases:all('select * from invoices where date_sh=? and invoice_type in (\'purchase\',\'purchase_return\') order by invoice_no',[date]),cash:all('select * from cash_transactions where date_sh=? order by created_at',[date]),checks:all('select * from checks where issue_date_sh=? order by created_at',[date]),journal:all('select * from journal_entries where date_sh=? order by voucher_no',[date]),closed:!!one('select id from day_closes where date_sh=?',[date])});}
    if(method==='GET'&&p==='/api/audit-log'){auth(req);return json(res,200,all('select * from audit_log order by event_at desc limit 1000'));}
    if(method==='POST'&&p==='/api/logout'){const s=auth(req);run('delete from sessions where token=?',[req.headers.authorization.replace(/^Bearer\s+/i,'')]);return json(res,200,{ok:true});}
    if(p.startsWith('/api/')) return json(res,404,{error:'مسیر API یافت نشد'});
  }catch(e){return json(res,e.status||500,{error:e.message||'خطای داخلی'});}
  const rel=p==='/'?'/index.html':p;const file=path.normalize(path.join(root,rel));if(!file.startsWith(root))return text(res,403,'Forbidden');try{const st=fs.statSync(file);if(!st.isFile())throw new Error();res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(fs.readFileSync(file));}catch{text(res,404,'Not found');}
}
http.createServer((req,res)=>route(req,res).catch(e=>json(res,500,{error:e.message}))).listen(port,()=>console.log(`MRK Finance Web+Backend v2.0: http://localhost:${port}`));
