import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const dir=path.resolve(new URL('../',import.meta.url).pathname); const db=path.join(dir,'data','test.sqlite'); try{fs.rmSync(db,{force:true})}catch{}
const server=spawn(process.execPath,[path.join(dir,'server.mjs')],{env:{...process.env,PORT:'8089',MRK_DB:db,MRK_ADMIN_PASSWORD:'test-pass'}});
await new Promise(r=>setTimeout(r,500));
async function req(path,options={}){const r=await fetch('http://127.0.0.1:8089'+path,options);const j=await r.json();return {status:r.status,body:j};}
try{
 let r=await req('/api/health');assert.equal(r.status,200);assert.equal(r.body.ok,true);
 r=await req('/api/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username:'admin',password:'test-pass'})});assert.equal(r.status,200);const token=r.body.token;
 const H={'content-type':'application/json',authorization:`Bearer ${token}`};
 r=await req('/api/parties',{method:'POST',headers:H,body:JSON.stringify({code:'C-001',name:'مشتری آزمایشی',kind:'customer'})});assert.equal(r.status,201);const party=r.body.id;
 r=await req('/api/invoices',{method:'POST',headers:H,body:JSON.stringify({invoice_no:'S-001',invoice_type:'sale',date_sh:'1405/06/03',party_id:party,vat_rate:10,lines:[{qty:2,unit_price:100000,discount_amount:10000}]})});assert.equal(r.status,201);assert.equal(r.body.totals.total,209000);
 r=await req('/api/reports/trial-balance',{headers:{authorization:`Bearer ${token}`}});assert.equal(r.status,200);const totals=r.body.reduce((x,a)=>({d:x.d+Number(a.debit),c:x.c+Number(a.credit)}),{d:0,c:0});assert.equal(totals.d,totals.c);
 r=await req('/api/checks',{method:'POST',headers:H,body:JSON.stringify({kind:'received',issue_date_sh:'1405/06/04',due_date_sh:'1405/06/07',party_id:party,cheque_no:'CHK-1',amount:50000,status:'در جریان'})});assert.equal(r.status,201);
 r=await req('/api/checks/'+r.body.id,{method:'PATCH',headers:H,body:JSON.stringify({status:'تسویه شده',cleared_date_sh:'1405/06/07',clearing_account:'1102'})});assert.equal(r.status,200);
 r=await req('/api/day-closes',{method:'POST',headers:H,body:JSON.stringify({date_sh:'1405/06/03'})});assert.equal(r.status,201);
 r=await req('/api/invoices',{method:'POST',headers:H,body:JSON.stringify({invoice_no:'S-002',invoice_type:'sale',date_sh:'1405/06/03',party_id:party,vat_rate:10,lines:[{qty:1,unit_price:1000}]})});assert.equal(r.status,409);
 console.log('MRK backend API tests: PASS');
} finally {server.kill('SIGTERM');await new Promise(r=>setTimeout(r,100));try{fs.rmSync(db,{force:true});fs.rmSync(db+'-wal',{force:true});fs.rmSync(db+'-shm',{force:true})}catch{}}
