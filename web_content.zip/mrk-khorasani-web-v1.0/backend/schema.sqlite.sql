PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users(
  id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin','accountant','sales','viewer')),
  password_hash TEXT NOT NULL, password_salt TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS fiscal_years(
  id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, title TEXT NOT NULL,
  start_date_sh TEXT NOT NULL, end_date_sh TEXT NOT NULL, start_date_iso TEXT, end_date_iso TEXT,
  is_closed INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS parties(
  id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK(kind IN ('customer','supplier','both','other')),
  phone TEXT, national_id TEXT, economic_id TEXT, tax_profile TEXT, address TEXT, active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products(
  id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, barcode TEXT, name TEXT NOT NULL, unit TEXT,
  product_group TEXT, purchase_price NUMERIC NOT NULL DEFAULT 0, sale_price NUMERIC NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS accounts(
  id TEXT PRIMARY KEY, full_code TEXT UNIQUE NOT NULL, group_code TEXT, group_name TEXT,
  sub_code TEXT, sub_name TEXT, ledger_code TEXT, ledger_name TEXT, detail_code TEXT, detail_name TEXT,
  nature TEXT NOT NULL CHECK(nature IN ('debit','credit','mixed')), parent_code TEXT, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS cost_centers(id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS invoices(
  id TEXT PRIMARY KEY, invoice_no TEXT NOT NULL, invoice_type TEXT NOT NULL CHECK(invoice_type IN ('sale','sale_return','purchase','purchase_return')),
  date_sh TEXT NOT NULL, date_iso TEXT, party_id TEXT REFERENCES parties(id), due_date_sh TEXT, due_date_iso TEXT,
  status TEXT NOT NULL DEFAULT 'open', freight NUMERIC NOT NULL DEFAULT 0, other_deduction NUMERIC NOT NULL DEFAULT 0,
  vat_rate NUMERIC NOT NULL DEFAULT 0, vat_amount NUMERIC NOT NULL DEFAULT 0, net_amount NUMERIC NOT NULL DEFAULT 0,
  total_amount NUMERIC NOT NULL DEFAULT 0, warehouse TEXT, shipping_method TEXT, reference_no TEXT,
  cost_center_id TEXT REFERENCES cost_centers(id), description TEXT, created_by TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(invoice_no, invoice_type)
);
CREATE TABLE IF NOT EXISTS invoice_lines(
  id TEXT PRIMARY KEY, invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE, line_no INTEGER NOT NULL,
  product_id TEXT REFERENCES products(id), qty NUMERIC NOT NULL, unit_price NUMERIC NOT NULL,
  discount_amount NUMERIC NOT NULL DEFAULT 0, discount_percent NUMERIC NOT NULL DEFAULT 0,
  line_net NUMERIC NOT NULL, UNIQUE(invoice_id,line_no)
);
CREATE TABLE IF NOT EXISTS cash_transactions(
  id TEXT PRIMARY KEY, date_sh TEXT NOT NULL, date_iso TEXT, transaction_type TEXT NOT NULL CHECK(transaction_type IN ('receipt','payment','transfer')),
  party_id TEXT REFERENCES parties(id), invoice_id TEXT REFERENCES invoices(id), source_account TEXT REFERENCES accounts(full_code),
  destination_account TEXT REFERENCES accounts(full_code), amount NUMERIC NOT NULL CHECK(amount>0), reference_no TEXT,
  description TEXT, created_by TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS checks(
  id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('received','issued')), issue_date_sh TEXT NOT NULL, issue_date_iso TEXT,
  due_date_sh TEXT NOT NULL, due_date_iso TEXT, cleared_date_sh TEXT, cleared_date_iso TEXT, party_id TEXT REFERENCES parties(id),
  invoice_id TEXT REFERENCES invoices(id), cheque_no TEXT, bank TEXT, amount NUMERIC NOT NULL CHECK(amount>0), status TEXT NOT NULL,
  description TEXT, created_by TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS journal_entries(
  id TEXT PRIMARY KEY, voucher_no INTEGER UNIQUE NOT NULL, date_sh TEXT NOT NULL, date_iso TEXT, source_type TEXT NOT NULL,
  source_id TEXT, description TEXT, is_balanced INTEGER NOT NULL DEFAULT 0, created_by TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS journal_lines(
  id TEXT PRIMARY KEY, journal_id TEXT NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
  line_no INTEGER NOT NULL, account_code TEXT NOT NULL REFERENCES accounts(full_code), party_id TEXT REFERENCES parties(id),
  cost_center_id TEXT REFERENCES cost_centers(id), debit NUMERIC NOT NULL DEFAULT 0, credit NUMERIC NOT NULL DEFAULT 0,
  description TEXT, UNIQUE(journal_id,line_no), CHECK(debit>=0 AND credit>=0 AND NOT(debit>0 AND credit>0))
);
CREATE TABLE IF NOT EXISTS day_closes(
  id TEXT PRIMARY KEY, date_sh TEXT UNIQUE NOT NULL, closed_by TEXT NOT NULL, closed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, locked INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS audit_log(
  id TEXT PRIMARY KEY, event_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, user_name TEXT, action TEXT NOT NULL,
  entity TEXT NOT NULL, record_id TEXT, details TEXT
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_invoice_date ON invoices(date_sh);
CREATE INDEX IF NOT EXISTS idx_cash_date ON cash_transactions(date_sh);
CREATE INDEX IF NOT EXISTS idx_journal_date ON journal_entries(date_sh);
CREATE INDEX IF NOT EXISTS idx_checks_due ON checks(due_date_sh);
