# Android deployment path — MR,KHORASANI

## Current v2.0 architecture
- Web/PWA frontend is served by `backend/server.mjs`.
- Backend persists data locally in SQLite for development and is schema-ready for PostgreSQL in `backend/schema.postgres.sql`.
- The mobile app should eventually use the same HTTPS API rather than keeping the authoritative accounting ledger only in browser localStorage.

## Native APK/AAB next step
1. Complete UI-to-API migration and offline sync rules.
2. Configure a production PostgreSQL instance and HTTPS reverse proxy.
3. Package the web client with Capacitor/TWA after API authentication and offline behavior are verified.
4. Build signed APK/AAB with Android SDK/Gradle.
5. Test Android 10+ for RTL, Persian dates, login/session expiry, invoice CRUD, journal balance, day close, cheque lifecycle, backup/export, and network loss.

This repository does not claim to contain a finished APK/AAB until an Android build is actually produced and installed/tested.
