# Android packaging path

This repository is a PWA-first web build. It is designed to run on Android and be installed from the browser.

For a native APK/AAB, package this same web app using one of:
- Trusted Web Activity (TWA) for a hosted HTTPS deployment.
- Capacitor/Android WebView for a native shell with offline asset bundling.

Required release verification:
- Android 10+ install
- back navigation
- Persian RTL rendering
- offline start and local data persistence
- create/edit/delete invoice before close
- create/edit/delete blocked after close
- balanced journal assertion
- CSV/Excel template import/export workflow
- backup/restore
- screen capture of daily one-page report
