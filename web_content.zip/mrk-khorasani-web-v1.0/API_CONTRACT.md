# MR,KHORASANI Backend API Contract — planned production layer

## Core endpoints
- `GET /api/health`
- `GET /api/bootstrap` — company, fiscal year, dictionaries, accounts
- `GET /api/parties?kind=customer|supplier`
- `POST /api/parties`
- `PATCH /api/parties/{id}`
- `DELETE /api/parties/{id}`
- `GET /api/products`
- `POST /api/products`
- `POST /api/invoices` — validates document status/date/period and generates journal
- `PATCH /api/invoices/{id}` — rejected if day is closed
- `DELETE /api/invoices/{id}` — rejected if day is closed
- `POST /api/cash-transactions`
- `POST /api/checks`
- `PATCH /api/checks/{id}`
- `POST /api/day-closes`
- `GET /api/reports/daily-one-page?date=YYYY/MM/DD`
- `GET /api/reports/trial-balance`
- `GET /api/reports/journal`
- `GET /api/reports/crm`
- `GET /api/audit-log`
- `POST /api/import/excel`
- `GET /api/export/excel?dataset=...`

## Invariants
1. Every posted operational transaction creates exactly one accounting journal header plus balanced journal lines.
2. Sum(debit) == Sum(credit) is mandatory before commit.
3. Any document dated on a closed day is immutable/deletion-protected.
4. Accounting descriptions are generated from source fields, then remain editable with an audit trail.
5. Persian/Shamsi display dates are stored alongside canonical sortable date representation in the production database.
6. Tax metadata is per invoice/document; VAT rate is configuration, not a permanent hard-coded legal constant.
7. Electronic-invoice identifiers and taxpayer status fields must be persisted to support a real Samaneh Moadian integration.
