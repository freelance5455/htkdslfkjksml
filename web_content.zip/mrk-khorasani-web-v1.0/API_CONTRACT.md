# MR,KHORASANI Backend API v2.0

The v2 backend is a real local API server with a transactional SQLite adapter and a PostgreSQL production schema reference. PostgreSQL is the intended multi-user production target; SQLite is included so the project can be run and tested without installing a database server.

## Authentication
- `POST /api/auth/login` — username/password, returns a 12-hour bearer session.
- `POST /api/logout` — invalidates the current session.
- Default local account: `admin`. Set `MRK_ADMIN_PASSWORD` before first startup; otherwise the development fallback is `MRK-ChangeMe-1405` and should be changed immediately.

## Core
- `GET /api/health`
- `GET /api/bootstrap`
- `GET/POST /api/parties`
- `GET/POST /api/products`
- `POST /api/invoices`
- `POST /api/cash-transactions`
- `POST /api/checks`
- `PATCH /api/checks/{id}`
- `POST /api/day-closes`

## Reports
- `GET /api/reports/daily-one-page?date=1405/06/03`
- `GET /api/reports/trial-balance?from=1405/01/01&to=1405/12/29`
- `GET /api/reports/journal?from=...&to=...`
- `GET /api/audit-log`

## Accounting invariants
1. A posted operational document generates a balanced journal inside the same database transaction.
2. Debit and credit totals must match before commit.
3. A closed Shamsi date rejects new transactional writes.
4. Party-level subsidiary is stored on journal lines for receivable/payable/check flows.
5. VAT is a document configuration value, not a permanently hard-coded legal rate.
6. Shamsi display date is stored with an optional canonical ISO date for server-side sorting/integration.
7. Received checks initially post to `1103` and clear to the selected bank; issued checks initially post to `2102` and clear against the selected bank.
8. Audit records are written for create/update/close actions.

## Production note
Direct Samaneh Moadian integration is intentionally not claimed in v2.0. The database has fields needed for future electronic-invoice identifiers/status metadata, but a real integration must be implemented against the applicable official technical specifications and credentials.
