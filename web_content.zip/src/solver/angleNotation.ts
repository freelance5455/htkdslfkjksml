// Helpers for parsing geometric notation out of plain-text questions, e.g.
// "∠ABC", "angle ABC = 70°", "triangle ABC", "BC is produced to D".
// These are intentionally conservative: if something is ambiguous, callers
// should ask the student to clarify rather than guessing.

export function extractAngleValues(text: string): Record<string, number> {
  const map: Record<string, number> = {};
  const re = /(?:∠|angle)\s*([A-Za-z]{1,3})\s*(?:=|is\s+equal\s+to|equals|is)\s*(\d+(?:\.\d+)?)\s*(?:°|deg(?:rees)?)?/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    map[m[1].toUpperCase()] = parseFloat(m[2]);
  }
  return map;
}

/** Returns the vertex letters of the main triangle referenced in the text,
 *  e.g. "triangle ABC" -> ["A","B","C"]. Falls back to inferring the
 *  triangle from the set of letters used across any angle labels, only
 *  when exactly 3 distinct letters are used (to avoid guessing wrongly). */
export function extractTriangleVertices(text: string): string[] | null {
  const direct = /triangle\s+([A-Za-z]{3})\b/i.exec(text);
  if (direct) return direct[1].toUpperCase().split("");

  const labels = new Set<string>();
  const re = /(?:∠|angle)\s*([A-Za-z]{2,3})/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    for (const ch of m[1].toUpperCase()) labels.add(ch);
  }
  if (labels.size === 3) return Array.from(labels);
  return null;
}

export function extractProducedSegment(text: string): { seg: string; to: string } | null {
  const m = /([A-Za-z]{2})\s+(?:is|are)?\s*produced\s+to\s+(?:a\s+point\s+)?([A-Za-z])\b/i.exec(text);
  if (!m) return null;
  return { seg: m[1].toUpperCase(), to: m[2].toUpperCase() };
}

export function findTargetAngleLabel(text: string): string | null {
  const m = /(?:find|calculate|determine|what\s+is)\s+(?:the\s+(?:value|measure)\s+of\s+)?(?:∠|angle)\s*([A-Za-z]{1,3})/i.exec(text);
  if (!m) return null;
  return m[1].toUpperCase();
}

/** Looks up the interior angle AT `vertex` of the main triangle, i.e. a
 *  value stored either as the single letter itself, or as a 3-letter label
 *  whose middle letter is `vertex` and whose outer two letters are exactly
 *  the other two triangle vertices (so it is unambiguously the triangle's
 *  own interior angle, not some exterior/other angle). */
export function getInteriorAngleAtVertex(vertex: string, triangleVerts: string[], rawAngles: Record<string, number>): number | undefined {
  if (rawAngles[vertex] !== undefined) return rawAngles[vertex];
  const others = triangleVerts.filter((v) => v !== vertex);
  if (others.length !== 2) return undefined;
  for (const [label, val] of Object.entries(rawAngles)) {
    if (label.length === 3 && label[1] === vertex) {
      const outer = [label[0], label[2]].sort().join("");
      const expect = [...others].sort().join("");
      if (outer === expect) return val;
    }
  }
  return undefined;
}

/** Looks up any angle value whose label has `vertex` as the middle letter
 *  and whose outer two letters match `armA`/`armB` in either order. */
export function findAngleByArms(rawAngles: Record<string, number>, vertex: string, armA: string, armB: string): number | undefined {
  const expect = [armA, armB].sort().join("");
  for (const [label, val] of Object.entries(rawAngles)) {
    if (label.length === 3 && label[1] === vertex) {
      const outer = [label[0], label[2]].sort().join("");
      if (outer === expect) return val;
    }
  }
  return undefined;
}

export function parseEqualSides(text: string): [string, string][] {
  const pairs: [string, string][] = [];
  const re = /([A-Za-z]{2})\s*=\s*([A-Za-z]{2})\b/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    pairs.push([m[1].toUpperCase(), m[2].toUpperCase()]);
  }
  return pairs;
}

export function parseEqualAngles(text: string): [string, string][] {
  const pairs: [string, string][] = [];
  const re = /(?:∠|angle)\s*([A-Za-z]{1,3})\s*=\s*(?:∠|angle)\s*([A-Za-z]{1,3})/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    pairs.push([m[1].toUpperCase(), m[2].toUpperCase()]);
  }
  return pairs;
}
