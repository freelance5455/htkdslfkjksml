import type { Board, ClassLevel, Formula, Subject } from "../data/types";

/** Describes a formula/theorem that was actually used to produce a solution,
 *  so it can be recorded in Formula History. */
export interface FormulaUsage {
  name: string;
  expression: string;
  subject?: Subject;
  topic?: string;
  classLevel?: ClassLevel;
  /** Board context, when known (e.g. selected in the AI Tutor or solver UI). */
  board?: Board;
  /** Chapter name, when known (links back to the syllabus master list). */
  chapter?: string;
  explanation: string;
  example?: string;
  /** Present only if this formula exists in the built-in interactive library. */
  formulaId?: string;
  /** Present only if the formula/theorem was actually looked up from an
   *  external source in this session. Never fabricated. */
  source?: { name: string; url: string };
}

export interface SolverResult {
  matched: boolean;
  category: string;
  /** Simple flat steps — used by the original arithmetic/physics/chemistry solvers. */
  steps: string[];
  answer: string;
  relatedFormulaId?: string;
  suggestions?: Formula[];

  // Richer structured solution (used by the geometry/algebra engines).
  given?: string[];
  toFind?: string;
  concept?: string;
  formulaText?: string;
  verification?: string;
  needsClarification?: string;
  formulaUsed?: FormulaUsage;
  diagram?: DiagramSpec;
}

/** A deliberately schematic (never-to-scale) geometry diagram description,
 *  built only from labels/values actually present in the question — never
 *  invented positions or measurements. Rendered by GeometryDiagram.tsx. */
export interface DiagramSpec {
  kind: "triangle" | "circle";
  // triangle
  vertices?: string[]; // e.g. ["A", "B", "C"]
  producedFrom?: string; // vertex the extended side starts at
  producedThrough?: string; // vertex the side is extended beyond
  producedTo?: string; // new point label at the end of the extension, e.g. "D"
  angleLabels?: { at: string; value?: number }[]; // annotate specific vertices/angles
  // circle
  centre?: string;
  pointsOnCircle?: string[];
  externalPoint?: string;
  tangentPoints?: string[];
  note?: string;
}

export type WordProblemSolver = (lower: string, original: string) => SolverResult | null;
