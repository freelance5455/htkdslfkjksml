import { fmt } from "../utils/format";
import { extractVar } from "./extract";
import { KNOWLEDGE_BASE } from "./knowledgeBase";
import type { WordProblemSolver } from "./types";

function angleFromText(text: string): number | undefined {
  const m = /(\d+(?:\.\d+)?)\s*°/.exec(text) || /(\d+(?:\.\d+)?)\s*degrees?/i.exec(text);
  return m ? parseFloat(m[1]) : undefined;
}

export const circleTheoremSolver: WordProblemSolver = (lower, original) => {
  if (!/circle|tangent|chord|diameter|semicircle|cyclic/.test(lower)) return null;

  // 1. Angle in a semicircle
  if (/semicircle/.test(lower) || (/diameter/.test(lower) && /(right angle|90°|angle)/.test(lower) && /point on the circle|on the circle/.test(lower))) {
    const kb = KNOWLEDGE_BASE.angleSemicircle;
    return {
      matched: true,
      category: "Circle Theorem — Angle in a Semicircle",
      given: ["AB is a diameter of the circle.", "C is a point on the circle (forming triangle ACB)."],
      toFind: "The angle subtended by the diameter at the point on the circle",
      concept: kb.explanation,
      formulaText: kb.expression,
      steps: ["The angle in a semicircle is always a right angle, regardless of exactly where C lies on the circle (as long as AB is a diameter)."],
      verification: "This follows from the Angle at the Centre Theorem: the angle at the centre for a diameter is 180°, so the angle at the circumference is half of that, i.e. 90°.",
      answer: "90°",
      formulaUsed: kb,
      diagram: { kind: "circle", centre: "O", pointsOnCircle: ["A", "B", "C"], note: "AB is a diameter; C is any point on the circle" },
    };
  }

  // 2. Tangent perpendicular to radius
  if (/tangent/.test(lower) && /radius/.test(lower) && /(perpendicular|right angle|90)/.test(lower) === false && /find/.test(lower)) {
    // e.g. "OP is a radius and PT is a tangent at P, find angle OPT"
    const m = /find\s+(?:the\s+)?(?:∠|angle)\s*([A-Za-z]{1,3})/i.exec(original);
    if (m) {
      const kb = KNOWLEDGE_BASE.tangentPerpRadius;
      return {
        matched: true,
        category: "Circle Theorem — Tangent & Radius",
        given: ["A line is a radius of the circle.", "Another line is a tangent at the same point of contact."],
        toFind: `∠${m[1].toUpperCase()}`,
        concept: kb.explanation,
        formulaText: kb.expression,
        steps: ["A tangent to a circle is always perpendicular to the radius drawn at the point of contact."],
        verification: "This is a standard circle theorem — true for every tangent and radius pair at the same point.",
        answer: "90°",
        formulaUsed: kb,
        diagram: { kind: "circle", centre: "O", tangentPoints: ["P"], note: "OP is a radius; the tangent touches the circle at P" },
      };
    }
  }

  // 3. Equal tangents from an external point: relate ∠APB (at external point) and ∠AOB (at centre)
  if (/tangents?/.test(lower) && /external point|outside the circle/.test(lower)) {
    const apb = extractVar(lower, ["angle apb", "∠apb"]) ?? angleFromText(original.match(/∠?APB[^\d]{0,10}(\d+)/i)?.[0] ?? "");
    const aob = extractVar(lower, ["angle aob", "∠aob"]);
    const kb = KNOWLEDGE_BASE.equalTangents;
    if (apb !== undefined) {
      const result = 180 - apb;
      return {
        matched: true,
        category: "Circle Theorem — Tangents from an External Point",
        given: [`∠APB (between the two tangents) = ${fmt(apb)}°`, "PA and PB are tangents from external point P; O is the centre."],
        toFind: "∠AOB (angle subtended at the centre by the two points of contact)",
        concept: kb.explanation,
        formulaText: kb.expression,
        steps: [
          "OA ⟂ PA and OB ⟂ PB (tangent ⟂ radius), so ∠OAP = ∠OBP = 90°.",
          "Quadrilateral OAPB has angle sum 360°: ∠AOB + ∠OAP + ∠APB + ∠OBP = 360°",
          `∠AOB = 360° − 90° − 90° − ${fmt(apb)}° = ${fmt(result)}°`,
        ],
        verification: `Check: ${fmt(result)}° + 90° + 90° + ${fmt(apb)}° = 360° ✓`,
        answer: `∠AOB = ${fmt(result)}°`,
        formulaUsed: kb,
        diagram: { kind: "circle", centre: "O", externalPoint: "P", tangentPoints: ["A", "B"], note: "PA and PB are tangents from external point P" },
      };
    }
    if (aob !== undefined) {
      const result = 180 - aob;
      return {
        matched: true,
        category: "Circle Theorem — Tangents from an External Point",
        given: [`∠AOB (at the centre) = ${fmt(aob)}°`, "PA and PB are tangents from external point P; O is the centre."],
        toFind: "∠APB (angle between the two tangents)",
        concept: kb.explanation,
        formulaText: kb.expression,
        steps: [
          "OA ⟂ PA and OB ⟂ PB (tangent ⟂ radius), so ∠OAP = ∠OBP = 90°.",
          "Quadrilateral OAPB has angle sum 360°: ∠AOB + 90° + ∠APB + 90° = 360°",
          `∠APB = 360° − 90° − 90° − ${fmt(aob)}° = ${fmt(result)}°`,
        ],
        verification: `Check: ${fmt(aob)}° + 90° + ${fmt(result)}° + 90° = 360° ✓`,
        answer: `∠APB = ${fmt(result)}°`,
        formulaUsed: kb,
        diagram: { kind: "circle", centre: "O", externalPoint: "P", tangentPoints: ["A", "B"], note: "PA and PB are tangents from external point P" },
      };
    }
  }

  // 4. Angle at centre = 2 × angle at circumference
  if (/centre|center/.test(lower) && /circumference|same arc/.test(lower)) {
    const centre = extractVar(lower, ["angle at the centre", "angle at centre", "∠aob"]);
    const circ = extractVar(lower, ["angle at the circumference", "∠acb"]);
    const kb = KNOWLEDGE_BASE.angleCentreCircumference;
    if (centre !== undefined) {
      const value = centre / 2;
      return {
        matched: true,
        category: "Circle Theorem — Angle at the Centre",
        given: [`Angle at the centre = ${fmt(centre)}°`, "Both angles stand on the same arc."],
        toFind: "The angle at the circumference",
        concept: kb.explanation,
        formulaText: kb.expression,
        steps: [`By the Angle at the Centre Theorem, the angle at the centre is twice the angle at the circumference: ${fmt(centre)}° = 2 × (angle at circumference)`, `angle at circumference = ${fmt(centre)}° / 2 = ${fmt(value)}°`],
        verification: `Check: 2 × ${fmt(value)}° = ${fmt(centre)}° ✓`,
        answer: `${fmt(value)}°`,
        formulaUsed: kb,
      };
    }
    if (circ !== undefined) {
      const value = circ * 2;
      return {
        matched: true,
        category: "Circle Theorem — Angle at the Centre",
        given: [`Angle at the circumference = ${fmt(circ)}°`, "Both angles stand on the same arc."],
        toFind: "The angle at the centre",
        concept: kb.explanation,
        formulaText: kb.expression,
        steps: [`By the Angle at the Centre Theorem: angle at centre = 2 × angle at circumference = 2 × ${fmt(circ)}°`],
        verification: `Check: ${fmt(value)}° / 2 = ${fmt(circ)}° ✓`,
        answer: `${fmt(value)}°`,
        formulaUsed: kb,
      };
    }
  }

  // 5. Cyclic quadrilateral — opposite angles supplementary
  if (/cyclic quadrilateral/.test(lower)) {
    const given = angleFromText(original);
    const kb = KNOWLEDGE_BASE.cyclicQuadrilateral;
    if (given !== undefined) {
      const value = 180 - given;
      return {
        matched: true,
        category: "Circle Theorem — Cyclic Quadrilateral",
        given: [`One angle of the cyclic quadrilateral = ${fmt(given)}°`],
        toFind: "The opposite angle",
        concept: kb.explanation,
        formulaText: kb.expression,
        steps: [`Opposite angles of a cyclic quadrilateral are supplementary: given angle + opposite angle = 180°`, `opposite angle = 180° − ${fmt(given)}° = ${fmt(value)}°`],
        verification: `Check: ${fmt(given)}° + ${fmt(value)}° = 180° ✓`,
        answer: `${fmt(value)}°`,
        formulaUsed: kb,
      };
    }
  }

  // 6. Perpendicular from centre bisects chord (Pythagoras on radius/half-chord/distance)
  if (/chord/.test(lower) && /(perpendicular|distance)/.test(lower) && /radius|centre|center/.test(lower)) {
    const r = extractVar(lower, ["radius", "\\br\\b"]);
    const d = extractVar(lower, ["distance", "\\bd\\b"]);
    const kb = KNOWLEDGE_BASE.perpendicularBisectsChord;
    if (r !== undefined && d !== undefined) {
      const half = Math.sqrt(Math.max(r * r - d * d, 0));
      const chord = 2 * half;
      return {
        matched: true,
        category: "Circle Theorem — Chord Length",
        given: [`Radius r = ${fmt(r)}`, `Perpendicular distance from centre to chord d = ${fmt(d)}`],
        toFind: "The length of the chord",
        concept: kb.explanation,
        formulaText: kb.expression,
        steps: [
          "The perpendicular from the centre to a chord bisects the chord, forming a right triangle with the radius as hypotenuse.",
          `half-chord = √(r² − d²) = √(${fmt(r)}² − ${fmt(d)}²) = √(${fmt(r * r)} − ${fmt(d * d)}) = ${fmt(half)}`,
          `full chord = 2 × ${fmt(half)} = ${fmt(chord)}`,
        ],
        verification: `Check with Pythagoras: ${fmt(half)}² + ${fmt(d)}² = ${fmt(half * half + d * d)} ≈ r² = ${fmt(r * r)} ✓`,
        answer: `Chord length = ${fmt(chord)} units`,
        formulaUsed: kb,
      };
    }
  }

  // 7. Tangent length from external point (reuse existing library formula)
  if (/tangent/.test(lower) && /(external point|length of the tangent|length of tangent)/.test(lower)) {
    const d = extractVar(lower, ["distance", "\\bd\\b"]);
    const r = extractVar(lower, ["radius", "\\br\\b"]);
    if (d !== undefined && r !== undefined) {
      const len = Math.sqrt(Math.max(d * d - r * r, 0));
      return {
        matched: true,
        category: "Circle Theorem — Tangent Length",
        given: [`Distance from external point to centre d = ${fmt(d)}`, `Radius r = ${fmt(r)}`],
        toFind: "The length of the tangent from the external point",
        concept: "A tangent is perpendicular to the radius at the point of contact, forming a right triangle with the line to the centre as the hypotenuse.",
        formulaText: "Tangent length = √(d² − r²)",
        steps: [`Tangent length = √(d² − r²) = √(${fmt(d)}² − ${fmt(r)}²) = √(${fmt(d * d)} − ${fmt(r * r)}) = ${fmt(len)}`],
        verification: `Check with Pythagoras: ${fmt(len)}² + ${fmt(r)}² = ${fmt(len * len + r * r)} ≈ d² = ${fmt(d * d)} ✓`,
        answer: `Tangent length = ${fmt(len)} units`,
        relatedFormulaId: "m10-tangent-length",
      };
    }
  }

  return null;
};
