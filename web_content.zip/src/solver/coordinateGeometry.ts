import { fmt } from "../utils/format";
import { KNOWLEDGE_BASE } from "./knowledgeBase";
import type { WordProblemSolver } from "./types";

function getPoints(original: string): [number, number][] {
  const re = /\(\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)/g;
  const pts: [number, number][] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(original))) pts.push([parseFloat(m[1]), parseFloat(m[2])]);
  return pts;
}

export const coordinateGeometrySolver: WordProblemSolver = (lower, original) => {
  const pts = getPoints(original);

  if (/slope|gradient/.test(lower) && pts.length >= 2) {
    const [[x1, y1], [x2, y2]] = pts;
    if (x2 === x1) {
      return {
        matched: true,
        category: "Coordinate Geometry — Slope",
        given: [`Points: (${fmt(x1)}, ${fmt(y1)}) and (${fmt(x2)}, ${fmt(y2)})`],
        toFind: "Slope of the line through the two points",
        concept: KNOWLEDGE_BASE.slopeFormula.explanation,
        formulaText: KNOWLEDGE_BASE.slopeFormula.expression,
        steps: ["Since x₂ = x₁, the line is vertical and its slope is undefined."],
        answer: "Undefined (vertical line)",
        formulaUsed: KNOWLEDGE_BASE.slopeFormula,
      };
    }
    const m = (y2 - y1) / (x2 - x1);
    return {
      matched: true,
      category: "Coordinate Geometry — Slope",
      given: [`Points: (${fmt(x1)}, ${fmt(y1)}) and (${fmt(x2)}, ${fmt(y2)})`],
      toFind: "Slope of the line through the two points",
      concept: KNOWLEDGE_BASE.slopeFormula.explanation,
      formulaText: KNOWLEDGE_BASE.slopeFormula.expression,
      steps: [`m = (y₂ − y₁)/(x₂ − x₁) = (${fmt(y2)} − ${fmt(y1)}) / (${fmt(x2)} − ${fmt(x1)}) = ${fmt(m)}`],
      verification: `Check direction: moving from x=${fmt(x1)} to x=${fmt(x2)}, y changes by ${fmt(y2 - y1)}, consistent with slope ${fmt(m)}.`,
      answer: `Slope m = ${fmt(m)}`,
      formulaUsed: KNOWLEDGE_BASE.slopeFormula,
    };
  }

  if (/collinear/.test(lower) && pts.length >= 3) {
    const [[x1, y1], [x2, y2], [x3, y3]] = pts;
    const area = 0.5 * Math.abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2));
    const isCollinear = area < 1e-6;
    return {
      matched: true,
      category: "Coordinate Geometry — Collinearity",
      given: [`Points: (${fmt(x1)}, ${fmt(y1)}), (${fmt(x2)}, ${fmt(y2)}), (${fmt(x3)}, ${fmt(y3)})`],
      toFind: "Whether the three points are collinear",
      concept: "Three points are collinear if the triangle they would form has zero area.",
      formulaText: "Area = ½|x₁(y₂−y₃) + x₂(y₃−y₁) + x₃(y₁−y₂)|",
      steps: [
        `Area = ½|${fmt(x1)}(${fmt(y2)}−${fmt(y3)}) + ${fmt(x2)}(${fmt(y3)}−${fmt(y1)}) + ${fmt(x3)}(${fmt(y1)}−${fmt(y2)})|`,
        `Area = ${fmt(area)} square units`,
      ],
      verification: isCollinear ? "Area = 0, confirming the points lie on a single straight line." : "Area ≠ 0, so the points form a proper triangle (not collinear).",
      answer: isCollinear ? "Yes — the points are collinear (area = 0)" : `No — the points are not collinear (area = ${fmt(area)} sq units)`,
      relatedFormulaId: "m10-area-triangle-coordinates",
      formulaUsed: KNOWLEDGE_BASE.collinearity,
    };
  }

  if (/distance/.test(lower) && pts.length >= 2) {
    const [[x1, y1], [x2, y2]] = pts;
    const d = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
    return {
      matched: true,
      category: "Coordinate Geometry — Distance Formula",
      given: [`Points: (${fmt(x1)}, ${fmt(y1)}) and (${fmt(x2)}, ${fmt(y2)})`],
      toFind: "Distance between the two points",
      concept: "The Distance Formula comes directly from the Pythagoras theorem applied to the coordinate plane.",
      formulaText: "d = √[(x₂−x₁)² + (y₂−y₁)²]",
      steps: [`d = √[(${fmt(x2)}−${fmt(x1)})² + (${fmt(y2)}−${fmt(y1)})²]`, `d = √[${fmt((x2 - x1) ** 2)} + ${fmt((y2 - y1) ** 2)}] = √${fmt((x2 - x1) ** 2 + (y2 - y1) ** 2)} = ${fmt(d)}`],
      verification: `${fmt(d)}² = ${fmt(d * d)} ≈ ${fmt((x2 - x1) ** 2 + (y2 - y1) ** 2)} ✓`,
      answer: `Distance = ${fmt(d)} units`,
      relatedFormulaId: "m10-distance-formula",
    };
  }

  if (/midpoint/.test(lower) && pts.length >= 2) {
    const [[x1, y1], [x2, y2]] = pts;
    const mx = (x1 + x2) / 2;
    const my = (y1 + y2) / 2;
    return {
      matched: true,
      category: "Coordinate Geometry — Midpoint",
      given: [`Points: (${fmt(x1)}, ${fmt(y1)}) and (${fmt(x2)}, ${fmt(y2)})`],
      toFind: "Midpoint of the segment",
      concept: "The midpoint is the average of the x-coordinates and the average of the y-coordinates.",
      formulaText: "M = ((x₁+x₂)/2, (y₁+y₂)/2)",
      steps: [`Mx = (${fmt(x1)} + ${fmt(x2)}) / 2 = ${fmt(mx)}`, `My = (${fmt(y1)} + ${fmt(y2)}) / 2 = ${fmt(my)}`],
      answer: `Midpoint = (${fmt(mx)}, ${fmt(my)})`,
      relatedFormulaId: "m10-midpoint",
    };
  }

  if (/section|divides?\s+.*\s+in\s+the\s+ratio/.test(lower) && pts.length >= 2) {
    const ratioMatch = /(\d+)\s*:\s*(\d+)/.exec(original);
    if (ratioMatch) {
      const [[x1, y1], [x2, y2]] = pts;
      const m = parseFloat(ratioMatch[1]);
      const n = parseFloat(ratioMatch[2]);
      const px = (m * x2 + n * x1) / (m + n);
      const py = (m * y2 + n * y1) / (m + n);
      return {
        matched: true,
        category: "Coordinate Geometry — Section Formula",
        given: [`Points: (${fmt(x1)}, ${fmt(y1)}) and (${fmt(x2)}, ${fmt(y2)})`, `Ratio m:n = ${fmt(m)}:${fmt(n)}`],
        toFind: "The point dividing the segment in the given ratio",
        concept: "The Section Formula finds a point that divides a line segment internally in a given ratio.",
        formulaText: "P = ((m·x₂+n·x₁)/(m+n), (m·y₂+n·y₁)/(m+n))",
        steps: [`Px = (${fmt(m)}×${fmt(x2)} + ${fmt(n)}×${fmt(x1)}) / (${fmt(m)}+${fmt(n)}) = ${fmt(px)}`, `Py = (${fmt(m)}×${fmt(y2)} + ${fmt(n)}×${fmt(y1)}) / (${fmt(m)}+${fmt(n)}) = ${fmt(py)}`],
        answer: `Point = (${fmt(px)}, ${fmt(py)})`,
        relatedFormulaId: "m10-section-formula",
      };
    }
  }

  if (/area/.test(lower) && /triangle/.test(lower) && pts.length >= 3) {
    const [[x1, y1], [x2, y2], [x3, y3]] = pts;
    const area = 0.5 * Math.abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2));
    return {
      matched: true,
      category: "Coordinate Geometry — Area of a Triangle",
      given: [`Vertices: (${fmt(x1)}, ${fmt(y1)}), (${fmt(x2)}, ${fmt(y2)}), (${fmt(x3)}, ${fmt(y3)})`],
      toFind: "Area of the triangle",
      concept: "This formula finds a triangle's area directly from its vertices' coordinates.",
      formulaText: "Area = ½|x₁(y₂−y₃) + x₂(y₃−y₁) + x₃(y₁−y₂)|",
      steps: [`Area = ½|${fmt(x1)}(${fmt(y2)}−${fmt(y3)}) + ${fmt(x2)}(${fmt(y3)}−${fmt(y1)}) + ${fmt(x3)}(${fmt(y1)}−${fmt(y2)})|`, `Area = ${fmt(area)} square units`],
      answer: `Area = ${fmt(area)} sq units`,
      relatedFormulaId: "m10-area-triangle-coordinates",
    };
  }

  return null;
};
