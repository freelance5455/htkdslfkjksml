import { fmt } from "../utils/format";
import { parseSideToCoeffs } from "./algebraParsing";
import type { WordProblemSolver } from "./types";

interface LinearEq {
  a: number; // coefficient of x
  b: number; // coefficient of y
  c: number; // constant (ax + by = c)
}

// Parses an equation like "2x+3y=12" or "2(x+1) - y = 3x - 7" into
// {a,b,c} representing ax+by=c, correctly handling parentheses/distribution
// via the shared algebraic term parser.
function parseEquationToXY(eqRaw: string): LinearEq | null {
  const [lhs, rhs] = eqRaw.split("=");
  if (rhs === undefined) return null;
  const L = parseSideToCoeffs(lhs, ["x", "y"]);
  const R = parseSideToCoeffs(rhs, ["x", "y"]);
  return { a: (L["x"] ?? 0) - (R["x"] ?? 0), b: (L["y"] ?? 0) - (R["y"] ?? 0), c: R._const - L._const };
}

/** Solves a pair of simultaneous linear equations in x and y, e.g.
 *  "2x + y = 10, x - y = 2" or "2x+3y=12 and x-y=1". */
export const simultaneousEquationsSolver: WordProblemSolver = (lower, original) => {
  if (!/[xy]/.test(lower) || !original.includes("=")) return null;
  // Need exactly two equations, split on "and"/","/newline/semicolon, each containing both x and y.
  const parts = original
    .split(/,|\band\b|;|\n/i)
    .map((p) => p.trim())
    .filter((p) => p.includes("=") && /x/i.test(p) && /y/i.test(p));
  if (parts.length !== 2) return null;

  const eq1 = parseEquationToXY(parts[0]);
  const eq2 = parseEquationToXY(parts[1]);
  if (!eq1 || !eq2) return null;
  if ((eq1.a === 0 && eq1.b === 0) || (eq2.a === 0 && eq2.b === 0)) return null;

  const det = eq1.a * eq2.b - eq2.a * eq1.b;
  const given = [`Equation 1: ${fmt(eq1.a)}x + ${fmt(eq1.b)}y = ${fmt(eq1.c)}`, `Equation 2: ${fmt(eq2.a)}x + ${fmt(eq2.b)}y = ${fmt(eq2.c)}`];

  if (Math.abs(det) < 1e-9) {
    return {
      matched: true,
      category: "Simultaneous Linear Equations",
      given,
      toFind: "Values of x and y",
      concept: "Elimination method for a pair of linear equations in two variables.",
      steps: ["The two equations are parallel (their coefficients are proportional), so the system has either no solution or infinitely many solutions."],
      answer: "No unique solution (lines are parallel or coincident)",
      relatedFormulaId: "m9-linear-two-variables",
    };
  }

  const x = (eq1.c * eq2.b - eq2.c * eq1.b) / det;
  const y = (eq1.a * eq2.c - eq2.a * eq1.c) / det;

  return {
    matched: true,
    category: "Simultaneous Linear Equations",
    given,
    toFind: "Values of x and y that satisfy both equations",
    concept: "Elimination / cross-multiplication method for a pair of linear equations in two variables.",
    formulaText: "x = (c₁b₂ − c₂b₁) / (a₁b₂ − a₂b₁),  y = (a₁c₂ − a₂c₁) / (a₁b₂ − a₂b₁)",
    steps: [
      `From eq.1: ${fmt(eq1.a)}x + ${fmt(eq1.b)}y = ${fmt(eq1.c)}`,
      `From eq.2: ${fmt(eq2.a)}x + ${fmt(eq2.b)}y = ${fmt(eq2.c)}`,
      `Determinant = a₁b₂ − a₂b₁ = (${fmt(eq1.a)})(${fmt(eq2.b)}) − (${fmt(eq2.a)})(${fmt(eq1.b)}) = ${fmt(det)}`,
      `x = (c₁b₂ − c₂b₁) / determinant = (${fmt(eq1.c)}×${fmt(eq2.b)} − ${fmt(eq2.c)}×${fmt(eq1.b)}) / ${fmt(det)} = ${fmt(x)}`,
      `y = (a₁c₂ − a₂c₁) / determinant = (${fmt(eq1.a)}×${fmt(eq2.c)} − ${fmt(eq2.a)}×${fmt(eq1.c)}) / ${fmt(det)} = ${fmt(y)}`,
    ],
    verification: `Substitute back: eq.1 → ${fmt(eq1.a)}(${fmt(x)}) + ${fmt(eq1.b)}(${fmt(y)}) = ${fmt(eq1.a * x + eq1.b * y)} ${Math.abs(eq1.a * x + eq1.b * y - eq1.c) < 1e-6 ? "✓" : "⚠"}; eq.2 → ${fmt(eq2.a)}(${fmt(x)}) + ${fmt(eq2.b)}(${fmt(y)}) = ${fmt(eq2.a * x + eq2.b * y)} ${Math.abs(eq2.a * x + eq2.b * y - eq2.c) < 1e-6 ? "✓" : "⚠"}`,
    answer: `x = ${fmt(x)}, y = ${fmt(y)}`,
    relatedFormulaId: "m9-linear-two-variables",
  };
};

/** Factorises a monic or simple quadratic trinomial ax^2+bx+c with integer-ish roots. */
export const factorizationSolver: WordProblemSolver = (lower, original) => {
  if (!/factor/.test(lower)) return null;
  const m = /(-?\d*)\s*x\s*(?:\^|²)?2\s*([+-]\s*\d*)\s*x\s*([+-]\s*\d+)/i.exec(original.replace(/\s+/g, " "));
  if (!m) return null;
  const a = m[1] === "" || m[1] === "-" ? (m[1] === "-" ? -1 : 1) : parseFloat(m[1]);
  const b = parseFloat((m[2] || "+0").replace(/\s+/g, ""));
  const c = parseFloat((m[3] || "+0").replace(/\s+/g, ""));

  if (a === 0) return null;

  // Try to find two numbers p, q such that p*q = a*c and p+q = b (standard splitting method).
  const target = a * c;
  let found: [number, number] | null = null;
  for (let p = -Math.abs(target) - 1; p <= Math.abs(target) + 1; p++) {
    if (p === 0) continue;
    if (target % p === 0) {
      const q = target / p;
      if (p + q === b) {
        found = [p, q];
        break;
      }
    }
  }

  const given = [`Quadratic expression: ${fmt(a)}x² ${b >= 0 ? "+" : "-"} ${Math.abs(b)}x ${c >= 0 ? "+" : "-"} ${Math.abs(c)}`];

  if (!found) {
    const D = b * b - 4 * a * c;
    if (D < 0) {
      return {
        matched: true,
        category: "Factorization",
        given,
        toFind: "Factors of the quadratic expression",
        concept: "Splitting the middle term method for factorising a quadratic trinomial.",
        steps: [`We need two numbers whose product is a×c = ${fmt(target)} and whose sum is b = ${fmt(b)}.`, `Discriminant = b² − 4ac = ${fmt(D)}, which is negative, so this expression cannot be factorised over the real numbers (no real roots).`],
        answer: "Cannot be factorised with real/rational numbers.",
      };
    }
    return {
      matched: true,
      category: "Factorization",
      given,
      toFind: "Factors of the quadratic expression",
      concept: "Splitting the middle term method for factorising a quadratic trinomial.",
      steps: [`We need two integers whose product is a×c = ${fmt(target)} and whose sum is b = ${fmt(b)} — no such integer pair exists, so this doesn't factor neatly with integers.`, `You can still solve it using the quadratic formula: x = (−b ± √D) / 2a with D = ${fmt(D)}.`],
      answer: "No clean integer factorisation — use the quadratic formula instead.",
      relatedFormulaId: "m10-quadratic-formula",
    };
  }

  const [p, q] = found;
  const g = (x: number, y: number): number => (y === 0 ? Math.abs(x) : g(y, x % y));
  const gcdA1 = g(a, p);
  const t1a = a / gcdA1,
    t1b = p / gcdA1;
  const gcdA2 = g(a, q);
  const t2a = a / gcdA2,
    t2b = q / gcdA2;

  const factorStr = `(${t1a === 1 ? "" : t1a}x ${t1b >= 0 ? "+" : "-"} ${Math.abs(t1b)}) (${t2a === 1 ? "" : t2a}x ${t2b >= 0 ? "+" : "-"} ${Math.abs(t2b)})`;

  return {
    matched: true,
    category: "Factorization",
    given,
    toFind: "Factors of the quadratic expression",
    concept: "Splitting the middle term: rewrite bx as the sum of two terms whose coefficients multiply to a×c.",
    formulaText: "ax² + bx + c, split b into p + q where p×q = a×c",
    steps: [
      `We need two numbers whose product is a×c = (${fmt(a)})(${fmt(c)}) = ${fmt(target)} and whose sum is b = ${fmt(b)}.`,
      `Those numbers are ${fmt(p)} and ${fmt(q)} (check: ${fmt(p)}×${fmt(q)} = ${fmt(p * q)}, ${fmt(p)}+${fmt(q)} = ${fmt(p + q)}).`,
      `Rewrite: ${fmt(a)}x² + ${fmt(p)}x + ${fmt(q)}x + ${fmt(c)}`,
      `Group and factor each pair, then factor out the common binomial.`,
      `Result: ${factorStr}`,
    ],
    verification: `Expand ${factorStr} to confirm it matches the original expression.`,
    answer: factorStr,
  };
};

/** Ratio and proportion word problems, e.g. "divide 600 in the ratio 2:3:5" or "if a:b = 2:3 and b:c = 4:5, find a:b:c". */
export const ratioProportionSolver: WordProblemSolver = (_lower, original) => {
  let m = /divide\s+(-?\d+(?:\.\d+)?)\s+in\s+the\s+ratio\s+([\d.]+(?::[\d.]+)+)/i.exec(original);
  if (m) {
    const total = parseFloat(m[1]);
    const parts = m[2].split(":").map(Number);
    const sum = parts.reduce((s, p) => s + p, 0);
    const shares = parts.map((p) => (p / sum) * total);
    return {
      matched: true,
      category: "Ratio and Proportion",
      given: [`Total quantity = ${fmt(total)}`, `Ratio = ${parts.join(":")}`],
      toFind: "Each share of the division",
      concept: "To divide a quantity in a given ratio, divide it into (sum of ratio parts) equal units, then multiply each ratio term by one unit.",
      formulaText: "Each share = (ratio term / sum of ratio terms) × total",
      steps: [`Sum of ratio terms = ${parts.join(" + ")} = ${fmt(sum)}`, `One unit = ${fmt(total)} / ${fmt(sum)} = ${fmt(total / sum)}`, ...parts.map((p, i) => `Share ${i + 1} = ${fmt(p)} × ${fmt(total / sum)} = ${fmt(shares[i])}`)],
      verification: `Check: ${shares.map((s) => fmt(s)).join(" + ")} = ${fmt(shares.reduce((s, v) => s + v, 0))} ✓ (equals total ${fmt(total)})`,
      answer: shares.map((s) => fmt(s)).join(" : "),
    };
  }

  m = /(-?\d+(?:\.\d+)?)\s*:\s*(-?\d+(?:\.\d+)?)\s*(?:::|=)\s*(-?\d+(?:\.\d+)?)\s*:\s*x/i.exec(original);
  if (m) {
    const [a, b, c] = [parseFloat(m[1]), parseFloat(m[2]), parseFloat(m[3])];
    const x = (b * c) / a;
    return {
      matched: true,
      category: "Ratio and Proportion",
      given: [`${fmt(a)} : ${fmt(b)} :: ${fmt(c)} : x`],
      toFind: "x",
      concept: "In a proportion, the product of the extremes equals the product of the means.",
      formulaText: "a : b :: c : d  ⟹  a × d = b × c",
      steps: [`a×x = b×c`, `${fmt(a)}×x = ${fmt(b)}×${fmt(c)}`, `x = ${fmt(b)}×${fmt(c)} / ${fmt(a)} = ${fmt(x)}`],
      verification: `Check: ${fmt(a)} × ${fmt(x)} = ${fmt(a * x)}, and ${fmt(b)} × ${fmt(c)} = ${fmt(b * c)} ✓`,
      answer: `x = ${fmt(x)}`,
    };
  }

  return null;
};

/** Simple fraction arithmetic: "1/2 + 1/3", "2/5 of 150", etc. (kept small —
 *  the generic arithmetic evaluator in evaluate.ts already handles plain
 *  decimals; this specifically targets a/b fraction notation.) */
export const fractionSolver: WordProblemSolver = (_lower, original) => {
  const m = /(-?\d+)\s*\/\s*(\d+)\s*([+\-*/])\s*(-?\d+)\s*\/\s*(\d+)/.exec(original);
  if (!m) return null;
  const [n1, d1, op, n2, d2] = [parseFloat(m[1]), parseFloat(m[2]), m[3], parseFloat(m[4]), parseFloat(m[5])];
  let numN: number, numD: number, opSymbol: string;
  switch (op) {
    case "+":
      numN = n1 * d2 + n2 * d1;
      numD = d1 * d2;
      opSymbol = "+";
      break;
    case "-":
      numN = n1 * d2 - n2 * d1;
      numD = d1 * d2;
      opSymbol = "−";
      break;
    case "*":
      numN = n1 * n2;
      numD = d1 * d2;
      opSymbol = "×";
      break;
    default:
      numN = n1 * d2;
      numD = d1 * n2;
      opSymbol = "÷";
  }
  const gcd = (x: number, y: number): number => (y === 0 ? Math.abs(x) : gcd(y, x % y));
  const g = gcd(numN, numD) || 1;
  const simpN = numN / g;
  const simpD = numD / g;
  const decimal = numN / numD;

  return {
    matched: true,
    category: "Fractions",
    given: [`${fmt(n1)}/${fmt(d1)} ${opSymbol} ${fmt(n2)}/${fmt(d2)}`],
    toFind: "The simplified result",
    concept: op === "+" || op === "-" ? "To add/subtract fractions, use a common denominator." : "To multiply fractions, multiply numerators and denominators directly; to divide, multiply by the reciprocal.",
    steps:
      op === "+" || op === "-"
        ? [`Common denominator = ${fmt(d1)} × ${fmt(d2)} = ${fmt(d1 * d2)}`, `= (${fmt(n1)}×${fmt(d2)} ${opSymbol} ${fmt(n2)}×${fmt(d1)}) / ${fmt(d1 * d2)} = ${fmt(numN)}/${fmt(numD)}`, `Simplify by dividing numerator and denominator by their HCF (${fmt(g)}): ${fmt(simpN)}/${fmt(simpD)}`]
        : [`${fmt(n1)}/${fmt(d1)} ${opSymbol} ${fmt(n2)}/${fmt(d2)} = ${fmt(numN)}/${fmt(numD)}`, `Simplify by dividing by the HCF (${fmt(g)}): ${fmt(simpN)}/${fmt(simpD)}`],
    verification: `As a decimal: ${fmt(simpN)}/${fmt(simpD)} ≈ ${fmt(decimal, 4)}`,
    answer: `${fmt(simpN)}/${fmt(simpD)} (≈ ${fmt(decimal, 4)})`,
  };
};
