import { fmt } from "../utils/format";
import { KNOWLEDGE_BASE } from "./knowledgeBase";
import {
  extractAngleValues,
  extractTriangleVertices,
  findTargetAngleLabel,
  getInteriorAngleAtVertex,
} from "./angleNotation";
import type { WordProblemSolver } from "./types";

/**
 * Handles triangle angle-sum and exterior-angle style questions, including
 * notation such as ∠ACD or ∠BAE (an exterior angle formed by extending a
 * side of a named triangle). Mathematical convention used throughout:
 * in ∠XYZ, the MIDDLE letter Y is always the vertex of the angle.
 */
export const triangleAngleSolver: WordProblemSolver = (_lower, original) => {
  if (!/triangle|∠|angle/i.test(original)) return null;

  const triangleVerts = extractTriangleVertices(original);
  const target = findTargetAngleLabel(original);
  if (!triangleVerts || !target) return null;

  const rawAngles = extractAngleValues(original);
  if (Object.keys(rawAngles).length === 0) return null;

  // Only proceed if the target is plausibly related to this triangle —
  // i.e. at least one of its letters is a vertex of the triangle.
  if (![...target].some((ch) => triangleVerts.includes(ch))) return null;

  const given = Object.entries(rawAngles).map(([label, v]) => `∠${label} = ${fmt(v)}°`);

  // Case 1: target is a single vertex letter OR a 3-letter label whose
  // outer letters are exactly the other two triangle vertices => it's a
  // plain interior angle of the main triangle. Solve via angle-sum.
  const pivot = target.length === 1 ? target : target[1];
  const outerLetters = target.length === 3 ? [target[0], target[2]] : null;
  const isPlainInterior =
    triangleVerts.includes(pivot) &&
    (target.length === 1 || (outerLetters && outerLetters.every((l) => triangleVerts.includes(l))));

  if (isPlainInterior) {
    const others = triangleVerts.filter((v) => v !== pivot);
    const a = getInteriorAngleAtVertex(others[0], triangleVerts, rawAngles);
    const b = getInteriorAngleAtVertex(others[1], triangleVerts, rawAngles);
    if (a === undefined || b === undefined) {
      const missing = [others[0], others[1]].filter((v) => getInteriorAngleAtVertex(v, triangleVerts, rawAngles) === undefined);
      return {
        matched: true,
        category: "Triangle — Angle Sum",
        given,
        toFind: `∠${pivot} (interior angle of triangle ${triangleVerts.join("")})`,
        concept: "Angle Sum Property of a Triangle",
        steps: [],
        needsClarification: `I need the value of the interior angle at ${missing.map((v) => `∠${v}`).join(" and ")} to use the Angle Sum Property. Please provide the missing angle(s) — I won't guess them.`,
        answer: "Cannot be determined yet — missing information.",
      };
    }
    const value = 180 - a - b;
    return {
      matched: true,
      category: "Triangle — Angle Sum",
      given,
      toFind: `∠${pivot}, the third interior angle of triangle ${triangleVerts.join("")}`,
      concept: "Angle Sum Property of a Triangle: the interior angles of a triangle always add up to 180°.",
      formulaText: "∠A + ∠B + ∠C = 180°",
      steps: [
        `The interior angles of triangle ${triangleVerts.join("")} are ∠${others[0]} = ${fmt(a)}°, ∠${others[1]} = ${fmt(b)}°, and ∠${pivot} (unknown).`,
        `By the Angle Sum Property: ∠${others[0]} + ∠${others[1]} + ∠${pivot} = 180°`,
        `${fmt(a)}° + ${fmt(b)}° + ∠${pivot} = 180°`,
        `∠${pivot} = 180° − ${fmt(a + b)}° = ${fmt(value)}°`,
      ],
      verification: `Check: ${fmt(a)}° + ${fmt(b)}° + ${fmt(value)}° = ${fmt(a + b + value)}° ✓ (equals 180°)`,
      answer: `∠${pivot} = ${fmt(value)}°`,
      relatedFormulaId: "m9-angle-sum-triangle",
      formulaUsed: KNOWLEDGE_BASE.angleSumTriangle,
      diagram: {
        kind: "triangle",
        vertices: triangleVerts,
        angleLabels: [
          { at: others[0], value: a },
          { at: others[1], value: b },
          { at: pivot, value: value },
        ],
      },
    };
  }

  // Case 2: target's middle letter (pivot) is a triangle vertex, but one
  // outer letter is NOT a triangle vertex => this is an exterior angle
  // formed by extending a side of the triangle (e.g. ∠ACD, ∠BAE).
  if (triangleVerts.includes(pivot) && outerLetters && outerLetters.some((l) => !triangleVerts.includes(l))) {
    const remoteVerts = triangleVerts.filter((v) => v !== pivot); // the two "remote" (non-adjacent) interior angles
    const extendedPoint = outerLetters.find((l) => !triangleVerts.includes(l))!;
    const armVertex = outerLetters.find((l) => triangleVerts.includes(l))!; // the triangle side CA/BA/etc. that remains as one arm of the exterior angle
    // The side that is actually produced (extended) runs from the OTHER remote vertex, through the pivot, to the extension point.
    const producedFromVertex = remoteVerts.find((v) => v !== armVertex)!;
    const producedSideLabel = `${producedFromVertex}${pivot}`;

    const remote1 = getInteriorAngleAtVertex(remoteVerts[0], triangleVerts, rawAngles);
    const remote2 = getInteriorAngleAtVertex(remoteVerts[1], triangleVerts, rawAngles);
    const pivotInterior = findAngleAtVertexAnyLabel(rawAngles, pivot, triangleVerts.filter((v) => v !== pivot));

    // propagate: exterior = remote1 + remote2; exterior + pivotInterior = 180
    let exterior: number | undefined;
    let r1 = remote1;
    let r2 = remote2;
    let pInt = pivotInterior;

    if (r1 !== undefined && r2 !== undefined) exterior = r1 + r2;
    else if (pInt !== undefined) exterior = 180 - pInt;

    if (exterior === undefined) {
      const missingParts: string[] = [];
      if (r1 === undefined) missingParts.push(`∠${remoteVerts[0]}`);
      if (r2 === undefined) missingParts.push(`∠${remoteVerts[1]}`);
      return {
        matched: true,
        category: "Triangle — Exterior Angle",
        given,
        toFind: `∠${target} (exterior angle at ${pivot})`,
        concept: "Exterior Angle Theorem",
        steps: [
          `Interpreting the question: side ${producedSideLabel} of triangle ${triangleVerts.join("")} is produced beyond ${pivot} to point ${extendedPoint}, forming exterior angle ∠${target}.`,
        ],
        needsClarification: `To use the Exterior Angle Theorem (exterior angle = sum of the two remote interior angles), I need the values of ${missingParts.join(" and ")}, or alternatively the interior angle ∠${pivot} of the triangle. Please provide the missing angle(s).`,
        answer: "Cannot be determined yet — missing information.",
      };
    }

    if (pInt === undefined) pInt = 180 - exterior;
    if (r1 === undefined && r2 !== undefined) r1 = exterior - r2;
    if (r2 === undefined && r1 !== undefined) r2 = exterior - r1;

    const steps = [
      `Interpreting the question: side ${producedSideLabel} of triangle ${triangleVerts.join("")} is produced beyond ${pivot} to point ${extendedPoint}, forming exterior angle ∠${target} at vertex ${pivot}.`,
      `By the Exterior Angle Theorem, the exterior angle equals the sum of the two remote (non-adjacent) interior angles: ∠${target} = ∠${remoteVerts[0]} + ∠${remoteVerts[1]}.`,
    ];
    if (remote1 !== undefined && remote2 !== undefined) {
      steps.push(`∠${target} = ${fmt(remote1)}° + ${fmt(remote2)}° = ${fmt(exterior)}°`);
    } else {
      steps.push(`The interior angle ∠${pivot} = ${fmt(pInt)}° is given/known, and ∠${pivot} + ∠${target} = 180° (linear pair), so ∠${target} = 180° − ${fmt(pInt)}° = ${fmt(exterior)}°.`);
    }

    return {
      matched: true,
      category: "Triangle — Exterior Angle",
      given,
      toFind: `∠${target}`,
      concept: "Exterior Angle Theorem: an exterior angle of a triangle equals the sum of the two interior angles not adjacent to it.",
      formulaText: "Exterior angle = sum of the two remote interior angles",
      steps,
      verification: `Check with the Angle Sum Property: ∠${remoteVerts[0]} (${fmt(r1 ?? NaN)}°) + ∠${remoteVerts[1]} (${fmt(r2 ?? NaN)}°) + ∠${pivot} (${fmt(pInt)}°) = ${fmt((r1 ?? 0) + (r2 ?? 0) + pInt)}° ✓, and ∠${pivot} + ∠${target} = ${fmt(pInt + exterior)}° ✓ (linear pair = 180°)`,
      answer: `∠${target} = ${fmt(exterior)}°`,
      relatedFormulaId: "m9-exterior-angle",
      formulaUsed: KNOWLEDGE_BASE.exteriorAngleTheorem,
      diagram: {
        kind: "triangle",
        vertices: triangleVerts,
        producedFrom: producedFromVertex,
        producedThrough: pivot,
        producedTo: extendedPoint,
        angleLabels: [
          { at: remoteVerts[0], value: r1 },
          { at: remoteVerts[1], value: r2 },
          { at: pivot, value: pInt },
        ],
      },
    };
  }

  return null;
};

function findAngleAtVertexAnyLabel(rawAngles: Record<string, number>, vertex: string, otherTriangleVerts: string[]): number | undefined {
  if (rawAngles[vertex] !== undefined) return rawAngles[vertex];
  const expect = [...otherTriangleVerts].sort().join("");
  for (const [label, val] of Object.entries(rawAngles)) {
    if (label.length === 3 && label[1] === vertex) {
      const outer = [label[0], label[2]].sort().join("");
      if (outer === expect) return val;
    }
  }
  return undefined;
}

/** Parallel-lines-and-a-transversal angle relationship questions. Since the
 * exact relationship between two named angles (corresponding / alternate /
 * co-interior) cannot be determined from text alone without a diagram, this
 * solver only computes a result when: (a) the user explicitly states the
 * relationship, or (b) they ask generally for "the other angles" given one
 * value, in which case it reports the two possible families of angles
 * (equal / supplementary) without inventing specific point labels. */
export const parallelLinesSolver: WordProblemSolver = (lower, original) => {
  if (!/parallel|\|\|/.test(lower) || !/transversal|angle/.test(lower)) return null;

  const valueMatch = /(\d+(?:\.\d+)?)\s*°/.exec(original) || /(\d+(?:\.\d+)?)\s*degrees?/.exec(lower);
  if (!valueMatch) return null;
  const given = parseFloat(valueMatch[1]);

  const given_: string[] = [`One of the angles formed = ${fmt(given)}°`, "Two lines are parallel, cut by a transversal."];

  let relation: "equal" | "supplementary" | null = null;
  let name = "";
  if (/co-?interior|allied|consecutive interior/.test(lower)) {
    relation = "supplementary";
    name = "Co-interior (allied) angles";
  } else if (/alternate/.test(lower)) {
    relation = "equal";
    name = "Alternate angles";
  } else if (/corresponding/.test(lower)) {
    relation = "equal";
    name = "Corresponding angles";
  } else if (/vertically opposite/.test(lower)) {
    relation = "equal";
    name = "Vertically opposite angles";
  } else if (/linear pair/.test(lower)) {
    relation = "supplementary";
    name = "Linear pair";
  }

  if (relation) {
    const value = relation === "equal" ? given : 180 - given;
    const kb = name.includes("Co-interior")
      ? KNOWLEDGE_BASE.coInteriorAngles
      : name.includes("Alternate")
      ? KNOWLEDGE_BASE.alternateAngles
      : name.includes("Corresponding")
      ? KNOWLEDGE_BASE.correspondingAngles
      : name.includes("Vertically")
      ? KNOWLEDGE_BASE.verticallyOpposite
      : KNOWLEDGE_BASE.linearPair;
    return {
      matched: true,
      category: "Parallel Lines — Angle Relationship",
      given: given_,
      toFind: "The related angle",
      concept: `${name}: ${kb.explanation}`,
      formulaText: kb.expression,
      steps: [
        `Given angle = ${fmt(given)}°`,
        relation === "equal" ? `${name} are equal, so the required angle = ${fmt(given)}°.` : `${name} are supplementary (sum to 180°), so the required angle = 180° − ${fmt(given)}° = ${fmt(value)}°.`,
      ],
      verification: relation === "supplementary" ? `Check: ${fmt(given)}° + ${fmt(value)}° = 180° ✓` : `${name} are always equal by this property.`,
      answer: `${fmt(value)}°`,
      formulaUsed: kb,
    };
  }

  // No explicit relationship named — only answer generally if the question
  // is NOT asking for one specific named angle (to avoid guessing).
  if (/find\s+(?:the\s+)?(?:angle|∠)\s*[A-Za-z]{1,3}\b/i.test(original)) {
    return {
      matched: false,
      category: "Parallel Lines — Angle Relationship",
      given: given_,
      steps: [],
      needsClarification:
        "I can see two parallel lines cut by a transversal with one angle given, but I can't tell which relationship (corresponding, alternate interior, alternate exterior, or co-interior) connects it to the angle you're asking for without seeing the figure. Please specify the relationship, e.g. 'find the co-interior angle to the 70° angle'.",
      answer: "Cannot be determined — please clarify the angle relationship.",
    };
  }

  return {
    matched: true,
    category: "Parallel Lines — Angle Relationship",
    given: given_,
    toFind: "All angles formed at the intersections",
    concept: "When a transversal cuts two parallel lines, 8 angles are formed in two equal families.",
    formulaText: "Corresponding, alternate angles are equal; co-interior and linear-pair angles are supplementary (180°)",
    steps: [
      `Given one angle = ${fmt(given)}°.`,
      `Angles equal to it (${fmt(given)}°): its vertically opposite angle, its corresponding angle, and the alternate angle on the other parallel line.`,
      `Angles supplementary to it (${fmt(180 - given)}°): its linear-pair neighbours, and the co-interior angle on the other parallel line.`,
    ],
    verification: `${fmt(given)}° + ${fmt(180 - given)}° = 180° ✓`,
    answer: `Equal angles = ${fmt(given)}°, supplementary angles = ${fmt(180 - given)}°`,
    formulaUsed: KNOWLEDGE_BASE.correspondingAngles,
  };
};

/** Classifies a triangle congruence/similarity question from stated
 * equalities, e.g. "AB=DE, BC=EF, angle B = angle E". */
export const congruenceSolver: WordProblemSolver = (lower, original) => {
  if (!/congruent|congruence|≅|similar/.test(lower)) return null;

  const sidePairs: string[] = [];
  const sideRe = /([A-Za-z]{2})\s*=\s*([A-Za-z]{2})\b/g;
  let m: RegExpExecArray | null;
  while ((m = sideRe.exec(original))) sidePairs.push(`${m[1].toUpperCase()}=${m[2].toUpperCase()}`);

  const angleRe = /(?:∠|angle)\s*([A-Za-z]{1,3})\s*=\s*(?:∠|angle)\s*([A-Za-z]{1,3})/gi;
  const anglePairs: string[] = [];
  while ((m = angleRe.exec(original))) anglePairs.push(`∠${m[1].toUpperCase()}=∠${m[2].toUpperCase()}`);

  if (sidePairs.length === 0 && anglePairs.length === 0) return null;

  const isSimilar = /similar/.test(lower);
  const given = [...sidePairs, ...anglePairs];
  const rightAngleMentioned = /right angle|90°|90 degrees/.test(lower);

  let criterion = "";
  let kbKey: keyof typeof KNOWLEDGE_BASE = "congruenceSSS";

  if (isSimilar) {
    if (anglePairs.length >= 2) {
      criterion = "AA (Angle-Angle) similarity";
      kbKey = "similarAA";
    } else {
      return {
        matched: false,
        category: "Similar Triangles",
        given,
        steps: [],
        needsClarification: "To confirm similarity, I need at least two pairs of equal corresponding angles (AA), or all three pairs of sides in the same ratio (SSS similarity), or two sides in ratio with the included angle equal (SAS similarity). Please provide more conditions.",
        answer: "Cannot determine the similarity criterion yet.",
      };
    }
  } else if (sidePairs.length >= 3) {
    criterion = "SSS (Side-Side-Side)";
    kbKey = "congruenceSSS";
  } else if (rightAngleMentioned && sidePairs.length >= 2) {
    criterion = "RHS (Right angle-Hypotenuse-Side)";
    kbKey = "congruenceRHS";
  } else if (sidePairs.length === 2 && anglePairs.length === 1) {
    criterion = "SAS (Side-Angle-Side) — provided the given angle is the INCLUDED angle between the two given sides";
    kbKey = "congruenceSAS";
  } else if (sidePairs.length === 1 && anglePairs.length === 2) {
    criterion = "ASA or AAS, depending on whether the given side lies between the two given angles";
    kbKey = "congruenceASA";
  } else {
    return {
      matched: false,
      category: isSimilar ? "Similar Triangles" : "Congruent Triangles",
      given,
      steps: [],
      needsClarification: "I found some equal sides/angles, but not enough to confidently identify a standard congruence criterion (SSS, SAS, ASA, AAS, RHS). Please state which sides/angles are equal and, for SAS/ASA, confirm whether the given angle/side is the one between the other two given parts.",
      answer: "Cannot determine the congruence criterion yet.",
    };
  }

  const kb = KNOWLEDGE_BASE[kbKey];
  return {
    matched: true,
    category: isSimilar ? "Similar Triangles" : "Congruent Triangles",
    given,
    toFind: isSimilar ? "Which similarity criterion applies" : "Which congruence criterion applies",
    concept: kb.explanation,
    formulaText: kb.expression,
    steps: [`Equal parts given: ${given.join(", ")}`, `This matches the ${criterion} criterion.`],
    verification: "Double-check that the matched vertices correspond in the same order on both triangles before concluding.",
    answer: `${isSimilar ? "Similar" : "Congruent"} by ${criterion}`,
    formulaUsed: kb,
  };
};
