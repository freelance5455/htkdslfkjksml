import { getFormulaById, searchFormulas } from "../data";
import { detectEquationVariable, evaluateExpression, isArithmeticCandidate, isEquationCandidate, solveEquationToABC } from "./evaluate";
import { simultaneousEquationsSolver, factorizationSolver, ratioProportionSolver, fractionSolver } from "./algebra";
import { triangleAngleSolver, parallelLinesSolver, congruenceSolver } from "./geometryAngles";
import { circleTheoremSolver } from "./circleTheorems";
import { coordinateGeometrySolver } from "./coordinateGeometry";
import { proofSolver } from "./proofs";
import { WORD_PROBLEM_SOLVERS } from "./wordProblems";
import type { SolverResult } from "./types";
import { fmt } from "../utils/format";

export type { SolverResult, FormulaUsage } from "./types";
export { INTERNET_LOOKUP_CONFIGURED } from "./lookup";

const INSTRUCTION_PHRASES = [
  "solve for x",
  "solve the equation",
  "solve this",
  "solve",
  "find the value of x",
  "find x",
  "evaluate",
  "calculate",
  "simplify",
  "what is",
  "compute",
  "the value of",
];

function stripInstructions(text: string): string {
  let t = text.trim();
  for (const phrase of INSTRUCTION_PHRASES) {
    t = t.replace(new RegExp(phrase, "ig"), "");
  }
  return t.replace(/[?.]+$/g, "").trim();
}

function buildEquationResult(a: number, b: number, c: number, variable: string): SolverResult {
  const v = variable;
  if (Math.abs(a) < 1e-9) {
    if (Math.abs(b) < 1e-9) {
      const isIdentity = Math.abs(c) < 1e-9;
      return {
        matched: true,
        category: "Linear Equation",
        given: [`${v} appears with coefficient 0 on both sides after simplifying`],
        toFind: `The value of ${v}`,
        concept: "A linear equation in one variable.",
        steps: [`Simplified: 0${v} + (${fmt(c)}) = 0`, isIdentity ? "This is true for every value — infinitely many solutions." : "This is never true — no solution exists."],
        answer: isIdentity ? "Infinite solutions" : "No solution",
      };
    }
    const x = -c / b;
    return {
      matched: true,
      category: "Linear Equation",
      given: [`Equation simplifies to ${fmt(b)}${v} + (${fmt(c)}) = 0`],
      toFind: `The value of ${v}`,
      concept: "Isolate the variable by moving the constant term to the other side, then divide by its coefficient.",
      formulaText: "ax + b = 0  ⟹  x = −b/a",
      steps: [`Standard form: ${fmt(b)}${v} + (${fmt(c)}) = 0`, `${v} = −(${fmt(c)}) / ${fmt(b)}`, `${v} = ${fmt(x)}`],
      verification: `Substitute back: ${fmt(b)}(${fmt(x)}) + (${fmt(c)}) = ${fmt(b * x + c)} ✓ (equals 0)`,
      answer: `${v} = ${fmt(x)}`,
      relatedFormulaId: "m8-linear-equation",
    };
  }

  const D = b * b - 4 * a * c;
  const given = [`Equation in standard form: ${fmt(a)}${v}² + (${fmt(b)})${v} + (${fmt(c)}) = 0`];
  const steps = [`Discriminant D = b² − 4ac = (${fmt(b)})² − 4(${fmt(a)})(${fmt(c)}) = ${fmt(D)}`];
  if (D < 0) {
    steps.push("D < 0, so there are no real roots.");
    return {
      matched: true,
      category: "Quadratic Equation",
      given,
      toFind: `The roots of the equation in ${v}`,
      concept: "The discriminant of a quadratic equation tells us the nature of its roots.",
      formulaText: "D = b² − 4ac",
      steps,
      answer: "No real roots (D < 0)",
      relatedFormulaId: "m10-discriminant",
    };
  }
  const x1 = (-b + Math.sqrt(D)) / (2 * a);
  const x2 = (-b - Math.sqrt(D)) / (2 * a);
  steps.push(`${v} = (−b ± √D) / 2a = (${fmt(-b)} ± ${fmt(Math.sqrt(D))}) / ${fmt(2 * a)}`);
  steps.push(D === 0 ? `${v} = ${fmt(x1)} (equal roots)` : `${v}₁ = ${fmt(x1)}, ${v}₂ = ${fmt(x2)}`);
  const verifyX1 = a * x1 * x1 + b * x1 + c;
  return {
    matched: true,
    category: "Quadratic Equation",
    given,
    toFind: `The roots of the equation in ${v}`,
    concept: "The quadratic formula solves any equation of the form ax² + bx + c = 0.",
    formulaText: "x = (−b ± √(b² − 4ac)) / 2a",
    steps,
    verification: `Substitute ${v}₁ = ${fmt(x1)} back: ${fmt(a)}(${fmt(x1)})² + (${fmt(b)})(${fmt(x1)}) + (${fmt(c)}) ≈ ${fmt(verifyX1, 6)} ✓ (≈ 0)`,
    answer: D === 0 ? `${v} = ${fmt(x1)}` : `${v} = ${fmt(x1)} or ${v} = ${fmt(x2)}`,
    relatedFormulaId: "m10-quadratic-formula",
  };
}

// Geometry/algebra engines run before the generic word-problem solvers,
// since they recognise more specific structured notation.
const PRIORITY_SOLVERS = [
  proofSolver,
  congruenceSolver,
  circleTheoremSolver,
  triangleAngleSolver,
  parallelLinesSolver,
  coordinateGeometrySolver,
  simultaneousEquationsSolver,
  factorizationSolver,
  ratioProportionSolver,
  fractionSolver,
];

/** Fills in `formulaUsed` from the main interactive library whenever a
 *  result references a `relatedFormulaId` but doesn't already carry usage
 *  metadata (e.g. the existing physics/chemistry/math word-problem
 *  solvers, which only set relatedFormulaId). This is what powers
 *  automatic Formula History logging. */
function attachFormulaUsage(result: SolverResult): SolverResult {
  if (result.formulaUsed || !result.relatedFormulaId) return result;
  const f = getFormulaById(result.relatedFormulaId);
  if (!f) return result;
  return {
    ...result,
    formulaUsed: {
      name: f.name,
      expression: f.expression,
      subject: f.subject,
      topic: f.topic,
      classLevel: f.classLevel,
      explanation: f.explanation,
      example: f.example,
      formulaId: f.id,
    },
  };
}

export function solveProblem(rawText: string): SolverResult {
  const text = rawText.trim();
  if (!text) {
    return { matched: false, category: "Empty", steps: [], answer: "Please type a question first." };
  }

  const cleaned = stripInstructions(text);
  const lower = text.toLowerCase();

  // 1. Equation in a single variable (linear or quadratic) — but only if it
  // doesn't look like a two-variable system (handled by the geometry/algebra
  // engines below).
  if (isEquationCandidate(cleaned)) {
    try {
      const variable = detectEquationVariable(cleaned)!;
      const { a, b, c } = solveEquationToABC(cleaned, variable);
      return attachFormulaUsage(buildEquationResult(a, b, c, variable));
    } catch {
      /* fall through to other strategies */
    }
  }

  // 2. Geometry, proofs, simultaneous equations, factorisation, fractions, ratios.
  for (const solver of PRIORITY_SOLVERS) {
    try {
      const result = solver(lower, text);
      if (result) return attachFormulaUsage(result);
    } catch {
      /* ignore and keep trying other solvers */
    }
  }

  // 3. Domain-specific word problems (math / physics / chemistry).
  for (const solver of WORD_PROBLEM_SOLVERS) {
    try {
      const result = solver(lower, text);
      if (result) return attachFormulaUsage(result);
    } catch {
      /* ignore and keep trying other solvers */
    }
  }

  // 4. Pure arithmetic expression.
  if (isArithmeticCandidate(cleaned)) {
    try {
      const value = evaluateExpression(cleaned);
      return { matched: true, category: "Arithmetic", steps: [`${cleaned} = ${fmt(value, 4)}`], answer: `${fmt(value, 4)}` };
    } catch {
      /* ignore */
    }
  }

  // 5. Fallback — suggest related formulas from the library.
  const suggestions = searchFormulas(text).slice(0, 5);
  return {
    matched: false,
    category: "Unrecognized",
    steps: [],
    answer:
      "I couldn't automatically solve this one yet. Try rephrasing with clear numbers/labels (e.g. \"find area of circle with radius 7\", \"triangle ABC, ∠B=70°, ∠C=60°, find ∠A\") or browse the related formulas below.",
    suggestions,
  };
}

export { lookupFormula } from "./lookup";

/** Second-pass helper for the UI: when solveProblem() can't find a match,
 *  this attempts an (honest) formula lookup — a configured online service
 *  if available, otherwise FormulaVerse's built-in knowledge base — and
 *  turns a match into a presentable result with correctly-labelled source
 *  information. Never fabricates a source. */
export async function trySmartLookup(query: string): Promise<SolverResult | null> {
  const { lookupFormula } = await import("./lookup");
  const outcome = await lookupFormula(query);
  if (!outcome.found || !outcome.entry) return null;
  const entry = outcome.entry;
  return {
    matched: true,
    category: outcome.usedInternet ? "Formula Lookup (Online)" : "Formula Lookup (Built-in Knowledge Base)",
    given: [`Topic looked up: "${query}"`],
    toFind: "A relevant formula or theorem",
    concept: entry.explanation,
    formulaText: entry.expression,
    steps: [outcome.message],
    answer: `${entry.name}: ${entry.expression}`,
    formulaUsed: entry,
  };
}
