import type { WordProblemSolver } from "./types";

interface ProofEntry {
  keywords: string[];
  title: string;
  classLevel: number;
  given: string[];
  toProve: string;
  steps: { statement: string; reason: string }[];
}

// A small curated set of standard Class 9-10 geometry proofs (NCERT/CBSE
// style). These are well-known, textbook-verified results — nothing here is
// invented. If a "prove" question doesn't match one of these, the solver
// honestly says so instead of fabricating a proof.
const PROOFS: ProofEntry[] = [
  {
    keywords: ["isosceles", "angles opposite", "equal sides", "base angles"],
    title: "Angles opposite to equal sides of an isosceles triangle are equal",
    classLevel: 9,
    given: ["Triangle ABC with AB = AC"],
    toProve: "∠B = ∠C",
    steps: [
      { statement: "Draw AD, the bisector of ∠A, meeting BC at D.", reason: "Construction" },
      { statement: "In △ABD and △ACD: AB = AC", reason: "Given" },
      { statement: "∠BAD = ∠CAD", reason: "AD bisects ∠A (construction)" },
      { statement: "AD = AD", reason: "Common side" },
      { statement: "△ABD ≅ △ACD", reason: "SAS congruence criterion" },
      { statement: "∠B = ∠C", reason: "Corresponding parts of congruent triangles (CPCT)" },
    ],
  },
  {
    keywords: ["exterior angle theorem", "exterior angle", "produced"],
    title: "Exterior Angle Theorem",
    classLevel: 9,
    given: ["Triangle ABC with side BC produced to D"],
    toProve: "∠ACD = ∠ABC + ∠BAC",
    steps: [
      { statement: "∠ACB + ∠ACD = 180°", reason: "Linear pair (BCD is a straight line)" },
      { statement: "∠ABC + ∠BAC + ∠ACB = 180°", reason: "Angle Sum Property of a triangle" },
      { statement: "∠ACB + ∠ACD = ∠ABC + ∠BAC + ∠ACB", reason: "Both equal 180° (from the two statements above)" },
      { statement: "∠ACD = ∠ABC + ∠BAC", reason: "Subtracting ∠ACB from both sides" },
    ],
  },
  {
    keywords: ["angle sum property", "sum of angles of a triangle", "angles of a triangle is 180"],
    title: "Angle Sum Property of a Triangle",
    classLevel: 9,
    given: ["Triangle ABC"],
    toProve: "∠A + ∠B + ∠C = 180°",
    steps: [
      { statement: "Draw a line PQ through A, parallel to BC.", reason: "Construction" },
      { statement: "∠PAB = ∠ABC", reason: "Alternate interior angles (PQ ∥ BC, AB is the transversal)" },
      { statement: "∠QAC = ∠ACB", reason: "Alternate interior angles (PQ ∥ BC, AC is the transversal)" },
      { statement: "∠PAB + ∠BAC + ∠QAC = 180°", reason: "Angles on a straight line PQ at point A" },
      { statement: "∠ABC + ∠BAC + ∠ACB = 180°", reason: "Substituting from the alternate angle equalities above" },
    ],
  },
  {
    keywords: ["cyclic quadrilateral", "opposite angles", "supplementary"],
    title: "Opposite angles of a cyclic quadrilateral are supplementary",
    classLevel: 9,
    given: ["ABCD is a cyclic quadrilateral (inscribed in a circle with centre O)"],
    toProve: "∠A + ∠C = 180° and ∠B + ∠D = 180°",
    steps: [
      { statement: "Join OB and OD.", reason: "Construction" },
      { statement: "Reflex ∠BOD = 2∠BAD (angle at centre) and ∠BOD = 2∠BCD", reason: "Angle at the Centre Theorem (angle at centre = 2 × angle at circumference, for each arc BD)" },
      { statement: "Reflex ∠BOD + ∠BOD = 360°", reason: "Angles around point O" },
      { statement: "2∠BAD + 2∠BCD = 360°", reason: "Substituting from the centre-angle relations" },
      { statement: "∠BAD + ∠BCD = 180°, i.e. ∠A + ∠C = 180°", reason: "Dividing both sides by 2" },
      { statement: "Similarly, ∠B + ∠D = 180°", reason: "Same reasoning applied to the other pair of opposite angles" },
    ],
  },
  {
    keywords: ["tangent", "perpendicular", "radius", "point of contact"],
    title: "The tangent at any point of a circle is perpendicular to the radius through the point of contact",
    classLevel: 10,
    given: ["A circle with centre O, and XY a tangent to the circle at point P"],
    toProve: "OP ⟂ XY",
    steps: [
      { statement: "Take any point Q on the tangent XY, other than P, and join OQ.", reason: "Construction" },
      { statement: "Q lies outside the circle (every point of a tangent other than the point of contact lies outside the circle).", reason: "Definition of a tangent" },
      { statement: "OQ > OP", reason: "OP is a radius (point P is on the circle) while OQ reaches a point outside the circle" },
      { statement: "This is true for every point Q on XY other than P, so OP is the shortest distance from O to line XY.", reason: "OQ > OP for all Q ≠ P on the tangent" },
      { statement: "OP ⟂ XY", reason: "The shortest distance from a point to a line is the perpendicular distance" },
    ],
  },
  {
    keywords: ["equal tangents", "tangents drawn from an external point", "pa = pb", "pa=pb"],
    title: "The lengths of two tangents drawn from an external point are equal",
    classLevel: 10,
    given: ["P is an external point; PA and PB are tangents to a circle with centre O, touching it at A and B"],
    toProve: "PA = PB",
    steps: [
      { statement: "Join OA, OB and OP.", reason: "Construction" },
      { statement: "∠OAP = ∠OBP = 90°", reason: "Tangent is perpendicular to the radius at the point of contact" },
      { statement: "OA = OB", reason: "Both are radii of the same circle" },
      { statement: "OP = OP", reason: "Common side" },
      { statement: "△OAP ≅ △OBP", reason: "RHS congruence criterion (right angle, hypotenuse OP, side OA=OB)" },
      { statement: "PA = PB", reason: "Corresponding parts of congruent triangles (CPCT)" },
    ],
  },
  {
    keywords: ["basic proportionality theorem", "thales", "line parallel to one side"],
    title: "Basic Proportionality Theorem (Thales' Theorem)",
    classLevel: 10,
    given: ["Triangle ABC with DE ∥ BC, where D lies on AB and E lies on AC"],
    toProve: "AD/DB = AE/EC",
    steps: [
      { statement: "Join BE and CD, and draw DM ⟂ AC and EN ⟂ AB.", reason: "Construction" },
      { statement: "area(ADE)/area(DBE) = AD/DB, and area(ADE)/area(DEC) = AE/EC", reason: "Triangles with the same height have areas proportional to their bases" },
      { statement: "area(DBE) = area(DEC)", reason: "Both triangles lie between the same parallels DE and BC and share the same base DE" },
      { statement: "AD/DB = AE/EC", reason: "From the two area ratios above, since area(DBE) = area(DEC)" },
    ],
  },
  {
    keywords: ["midpoint theorem", "joining the midpoints", "midpoints of two sides"],
    title: "Midpoint Theorem",
    classLevel: 9,
    given: ["Triangle ABC with D and E the midpoints of AB and AC respectively"],
    toProve: "DE ∥ BC and DE = ½BC",
    steps: [
      { statement: "Produce DE to F such that EF = DE, and join CF.", reason: "Construction" },
      { statement: "AE = EC and DE = EF", reason: "E is the midpoint of AC (given) and by construction" },
      { statement: "△AED ≅ △CEF", reason: "SAS (AE=EC, ∠AED=∠CEF vertically opposite, DE=EF)" },
      { statement: "AD = CF and ∠ADE = ∠CFE, so AD ∥ CF", reason: "CPCT, and equal alternate angles imply parallel lines" },
      { statement: "Since AD = DB (D is the midpoint) and AD = CF, we get DB = CF and DB ∥ CF, so DBCF is a parallelogram.", reason: "AD = DB (given), AD = CF (shown above)" },
      { statement: "DF ∥ BC and DF = BC, so DE ∥ BC and DE = ½DF = ½BC", reason: "Opposite sides of a parallelogram are equal and parallel; DE is half of DF by construction" },
    ],
  },
];

export const proofSolver: WordProblemSolver = (lower) => {
  if (!/\bprove\b|\bproof\b|show that/.test(lower)) return null;

  let best: ProofEntry | null = null;
  let bestScore = 0;
  for (const entry of PROOFS) {
    let score = 0;
    for (const kw of entry.keywords) if (lower.includes(kw)) score++;
    if (score > bestScore) {
      bestScore = score;
      best = entry;
    }
  }

  if (!best || bestScore === 0) {
    return {
      matched: false,
      category: "Geometry Proof",
      steps: [],
      needsClarification:
        "This looks like a proof question, but it doesn't clearly match one of the standard Class 9–10 proofs in FormulaVerse's library yet (e.g. isosceles triangle angles, exterior angle theorem, angle sum property, cyclic quadrilateral, tangent–radius perpendicularity, equal tangents, basic proportionality theorem, or the midpoint theorem). Please check the wording, or rephrase using the exact theorem name.",
      answer: "I can't reliably generate this proof yet — please clarify which theorem or result you need proved.",
    };
  }

  const steps = best.steps.map((s, i) => `${i + 1}. ${s.statement}   [Reason: ${s.reason}]`);

  return {
    matched: true,
    category: `Geometry Proof — ${best.title}`,
    given: best.given,
    toFind: `Prove: ${best.toProve}`,
    concept: best.title,
    steps,
    verification: "Each statement above follows logically from the previous ones and a stated geometric reason (axiom, theorem, or construction) — re-check each 'Reason' against the figure described in your question.",
    answer: `Proved: ${best.toProve}`,
  };
};

export function listAvailableProofs(): string[] {
  return PROOFS.map((p) => p.title);
}
