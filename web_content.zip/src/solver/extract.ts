// Small heuristics for pulling numeric values out of a typed/scanned
// word problem. These are intentionally simple pattern matches (no AI) —
// they look for a keyword (or short variable letter) followed shortly
// afterwards by a number.

export function extractVar(text: string, aliases: string[]): number | undefined {
  for (const alias of aliases) {
    const boundary = alias.length <= 2 && /^[a-z]+$/i.test(alias) ? `\\b${alias}\\b` : alias;
    const re = new RegExp(`${boundary}\\D{0,20}?(-?\\d+(?:\\.\\d+)?)`, "i");
    const m = re.exec(text);
    if (m) {
      const v = parseFloat(m[1]);
      if (!Number.isNaN(v)) return v;
    }
  }
  return undefined;
}

export function allNumbers(text: string): number[] {
  const matches = text.match(/-?\d+(?:\.\d+)?/g) || [];
  return matches.map(Number);
}
