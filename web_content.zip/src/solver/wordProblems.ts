import { fmt } from "../utils/format";
import { allNumbers, extractVar } from "./extract";
import type { SolverResult, WordProblemSolver } from "./types";

function arith(category: string, expr: string, value: number): SolverResult {
  return { matched: true, category, steps: [`${expr} = ${fmt(value, 4)}`], answer: `${fmt(value, 4)}` };
}

const naturalArithmeticSolver: WordProblemSolver = (lower) => {
  let m = /sum of\s*(-?\d+(?:\.\d+)?)\s*(?:and|,)\s*(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) {
    const a = +m[1],
      b = +m[2];
    return arith("Sum", `${fmt(a)} + ${fmt(b)}`, a + b);
  }
  m = /difference (?:of|between)\s*(-?\d+(?:\.\d+)?)\s*(?:and|,)\s*(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) {
    const a = +m[1],
      b = +m[2];
    return arith("Difference", `|${fmt(a)} − ${fmt(b)}|`, Math.abs(a - b));
  }
  m = /product of\s*(-?\d+(?:\.\d+)?)\s*(?:and|,)\s*(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) {
    const a = +m[1],
      b = +m[2];
    return arith("Product", `${fmt(a)} × ${fmt(b)}`, a * b);
  }
  m = /quotient of\s*(-?\d+(?:\.\d+)?)\s*(?:and|,)\s*(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) {
    const a = +m[1],
      b = +m[2];
    return arith("Quotient", `${fmt(a)} ÷ ${fmt(b)}`, a / b);
  }
  m = /cube root of\s*(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) return arith("Cube Root", `∛${fmt(+m[1])}`, Math.cbrt(+m[1]));
  m = /square root of\s*(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) return arith("Square Root", `√${fmt(+m[1])}`, Math.sqrt(+m[1]));
  m = /square of\s*(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) return arith("Square", `${fmt(+m[1])}²`, +m[1] * +m[1]);
  m = /cube of\s*(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) return arith("Cube", `${fmt(+m[1])}³`, Math.pow(+m[1], 3));
  return null;
};

const squareRootSolver: WordProblemSolver = (_lower, original) => {
  const m = /√\s*(-?\d+(?:\.\d+)?)/.exec(original);
  if (!m) return null;
  return arith("Square Root", `√${fmt(+m[1])}`, Math.sqrt(+m[1]));
};

const circleSolver: WordProblemSolver = (lower) => {
  if (!lower.includes("circle")) return null;
  const r = extractVar(lower, ["radius", "\\br\\b"]);
  const d = extractVar(lower, ["diameter", "\\bd\\b"]);
  const radius = r ?? (d !== undefined ? d / 2 : undefined);
  if (radius === undefined) return null;
  const wantsCircumference = /circumference|perimeter/.test(lower);
  const wantsArea = /area/.test(lower);
  const area = Math.PI * radius * radius;
  const circumference = 2 * Math.PI * radius;
  const steps = [`Radius r = ${fmt(radius)}`];
  if (wantsCircumference && !wantsArea) {
    steps.push(`Circumference = 2πr = 2 × π × ${fmt(radius)} = ${fmt(circumference)}`);
    return { matched: true, category: "Circle — Circumference", steps, answer: `Circumference ≈ ${fmt(circumference)} units`, relatedFormulaId: "m8-circumference-circle" };
  }
  if (wantsArea && !wantsCircumference) {
    steps.push(`Area = πr² = π × ${fmt(radius)}² = ${fmt(area)}`);
    return { matched: true, category: "Circle — Area", steps, answer: `Area ≈ ${fmt(area)} sq units`, relatedFormulaId: "m8-area-circle" };
  }
  steps.push(`Area = πr² = ${fmt(area)}`, `Circumference = 2πr = ${fmt(circumference)}`);
  return { matched: true, category: "Circle", steps, answer: `Area ≈ ${fmt(area)}, Circumference ≈ ${fmt(circumference)}`, relatedFormulaId: "m8-area-circle" };
};

const rectangleSolver: WordProblemSolver = (lower) => {
  if (!lower.includes("rectangle")) return null;
  const l = extractVar(lower, ["length", "\\bl\\b"]);
  const b = extractVar(lower, ["breadth", "width", "\\bb\\b"]);
  if (l === undefined || b === undefined) return null;
  const area = l * b;
  const perimeter = 2 * (l + b);
  const wantsPerimeter = /perimeter/.test(lower);
  const wantsArea = /area/.test(lower);
  const steps = [`length l = ${fmt(l)}, breadth b = ${fmt(b)}`];
  if (wantsPerimeter && !wantsArea) {
    steps.push(`Perimeter = 2(l + b) = 2(${fmt(l)} + ${fmt(b)}) = ${fmt(perimeter)}`);
    return { matched: true, category: "Rectangle — Perimeter", steps, answer: `Perimeter = ${fmt(perimeter)} units`, relatedFormulaId: "m8-area-rectangle" };
  }
  steps.push(`Area = l × b = ${fmt(l)} × ${fmt(b)} = ${fmt(area)}`);
  if (!wantsPerimeter) return { matched: true, category: "Rectangle — Area", steps, answer: `Area = ${fmt(area)} sq units`, relatedFormulaId: "m8-area-rectangle" };
  steps.push(`Perimeter = 2(l + b) = ${fmt(perimeter)}`);
  return { matched: true, category: "Rectangle", steps, answer: `Area = ${fmt(area)}, Perimeter = ${fmt(perimeter)}`, relatedFormulaId: "m8-area-rectangle" };
};

const squareSolver: WordProblemSolver = (lower) => {
  if (!lower.includes("square") || lower.includes("square root") || lower.includes("square of")) return null;
  const a = extractVar(lower, ["side", "\\ba\\b"]);
  if (a === undefined) return null;
  const area = a * a;
  const perimeter = 4 * a;
  const wantsPerimeter = /perimeter/.test(lower);
  const steps = [`side a = ${fmt(a)}`];
  if (wantsPerimeter) {
    steps.push(`Perimeter = 4a = ${fmt(perimeter)}`);
    return { matched: true, category: "Square — Perimeter", steps, answer: `Perimeter = ${fmt(perimeter)} units`, relatedFormulaId: "m8-area-square" };
  }
  steps.push(`Area = a² = ${fmt(a)}² = ${fmt(area)}`);
  return { matched: true, category: "Square — Area", steps, answer: `Area = ${fmt(area)} sq units`, relatedFormulaId: "m8-area-square" };
};

const quadAreaSolver: WordProblemSolver = (lower) => {
  if (/trapezium/.test(lower)) {
    const a = extractVar(lower, ["parallel side a", "\\ba\\b"]);
    const b = extractVar(lower, ["parallel side b", "\\bb\\b"]);
    const h = extractVar(lower, ["height", "\\bh\\b"]);
    if (a !== undefined && b !== undefined && h !== undefined) {
      const area = 0.5 * (a + b) * h;
      return { matched: true, category: "Trapezium — Area", steps: [`a=${fmt(a)}, b=${fmt(b)}, h=${fmt(h)}`, `Area = ½(a+b)h = ½(${fmt(a)}+${fmt(b)})×${fmt(h)} = ${fmt(area)}`], answer: `Area = ${fmt(area)} sq units`, relatedFormulaId: "m8-area-trapezium" };
    }
  }
  if (/parallelogram/.test(lower)) {
    const base = extractVar(lower, ["base", "\\bb\\b"]);
    const h = extractVar(lower, ["height", "\\bh\\b"]);
    if (base !== undefined && h !== undefined) {
      const area = base * h;
      return { matched: true, category: "Parallelogram — Area", steps: [`base=${fmt(base)}, height=${fmt(h)}`, `Area = base × height = ${fmt(area)}`], answer: `Area = ${fmt(area)} sq units`, relatedFormulaId: "m8-area-parallelogram" };
    }
  }
  if (/rhombus/.test(lower)) {
    const d1 = extractVar(lower, ["d1", "diagonal 1", "first diagonal"]);
    const d2 = extractVar(lower, ["d2", "diagonal 2", "second diagonal"]);
    if (d1 !== undefined && d2 !== undefined) {
      const area = 0.5 * d1 * d2;
      return { matched: true, category: "Rhombus — Area", steps: [`d1=${fmt(d1)}, d2=${fmt(d2)}`, `Area = ½ × d1 × d2 = ${fmt(area)}`], answer: `Area = ${fmt(area)} sq units`, relatedFormulaId: "m8-area-rhombus" };
    }
  }
  return null;
};

const triangleSolver: WordProblemSolver = (lower) => {
  if (!lower.includes("triangle")) return null;
  const base = extractVar(lower, ["base", "\\bb\\b"]);
  const height = extractVar(lower, ["height", "\\bh\\b"]);
  if (base !== undefined && height !== undefined) {
    const area = 0.5 * base * height;
    return { matched: true, category: "Triangle — Area", steps: [`base = ${fmt(base)}, height = ${fmt(height)}`, `Area = ½ × base × height = ½ × ${fmt(base)} × ${fmt(height)} = ${fmt(area)}`], answer: `Area = ${fmt(area)} sq units`, relatedFormulaId: "m8-area-triangle" };
  }
  if (/sides?/.test(lower)) {
    const nums = allNumbers(lower);
    if (nums.length >= 3) {
      const [a, b, c] = nums;
      const s = (a + b + c) / 2;
      const inside = s * (s - a) * (s - b) * (s - c);
      if (inside >= 0) {
        const area = Math.sqrt(inside);
        return {
          matched: true,
          category: "Triangle — Heron's Formula",
          steps: [`a=${fmt(a)}, b=${fmt(b)}, c=${fmt(c)}`, `s = (a+b+c)/2 = ${fmt(s)}`, `Area = √(s(s−a)(s−b)(s−c)) = √(${fmt(s)}×${fmt(s - a)}×${fmt(s - b)}×${fmt(s - c)}) = ${fmt(area)}`],
          answer: `Area ≈ ${fmt(area)} sq units`,
          relatedFormulaId: "m9-herons-formula",
        };
      }
    }
  }
  return null;
};

const solidVolumeSolver: WordProblemSolver = (lower) => {
  if (/cube\b/.test(lower) && !/cuboid/.test(lower)) {
    const a = extractVar(lower, ["side", "edge", "\\ba\\b"]);
    if (a === undefined) return null;
    const volume = Math.pow(a, 3);
    const sa = 6 * a * a;
    return { matched: true, category: "Cube", steps: [`edge a = ${fmt(a)}`, `Volume = a³ = ${fmt(volume)}`, `Surface Area = 6a² = ${fmt(sa)}`], answer: `Volume = ${fmt(volume)}, Surface Area = ${fmt(sa)}`, relatedFormulaId: "m8-cube" };
  }
  if (/cuboid/.test(lower)) {
    const l = extractVar(lower, ["length", "\\bl\\b"]);
    const b = extractVar(lower, ["breadth", "width", "\\bb\\b"]);
    const h = extractVar(lower, ["height", "\\bh\\b"]);
    if (l === undefined || b === undefined || h === undefined) return null;
    const volume = l * b * h;
    const sa = 2 * (l * b + b * h + h * l);
    return { matched: true, category: "Cuboid", steps: [`l=${fmt(l)}, b=${fmt(b)}, h=${fmt(h)}`, `Volume = l×b×h = ${fmt(volume)}`, `Surface Area = 2(lb+bh+hl) = ${fmt(sa)}`], answer: `Volume = ${fmt(volume)}, Surface Area = ${fmt(sa)}`, relatedFormulaId: "m8-cuboid" };
  }
  if (/cylinder/.test(lower)) {
    const r = extractVar(lower, ["radius", "\\br\\b"]);
    const h = extractVar(lower, ["height", "\\bh\\b"]);
    if (r === undefined || h === undefined) return null;
    const volume = Math.PI * r * r * h;
    const csa = 2 * Math.PI * r * h;
    return { matched: true, category: "Cylinder", steps: [`r=${fmt(r)}, h=${fmt(h)}`, `Volume = πr²h = ${fmt(volume)}`, `Curved Surface Area = 2πrh = ${fmt(csa)}`], answer: `Volume ≈ ${fmt(volume)} cubic units`, relatedFormulaId: "m8-cylinder" };
  }
  if (/cone/.test(lower)) {
    const r = extractVar(lower, ["radius", "\\br\\b"]);
    const h = extractVar(lower, ["height", "\\bh\\b"]);
    if (r === undefined || h === undefined) return null;
    const volume = (Math.PI * r * r * h) / 3;
    const l = Math.sqrt(r * r + h * h);
    return { matched: true, category: "Cone", steps: [`r=${fmt(r)}, h=${fmt(h)}`, `slant height l = √(r²+h²) = ${fmt(l)}`, `Volume = (1/3)πr²h = ${fmt(volume)}`], answer: `Volume ≈ ${fmt(volume)} cubic units`, relatedFormulaId: "m9-cone" };
  }
  if (/hemisphere/.test(lower)) {
    const r = extractVar(lower, ["radius", "\\br\\b"]);
    if (r === undefined) return null;
    const volume = (2 / 3) * Math.PI * Math.pow(r, 3);
    return { matched: true, category: "Hemisphere", steps: [`r=${fmt(r)}`, `Volume = (2/3)πr³ = ${fmt(volume)}`], answer: `Volume ≈ ${fmt(volume)} cubic units`, relatedFormulaId: "m9-hemisphere" };
  }
  if (/sphere/.test(lower)) {
    const r = extractVar(lower, ["radius", "\\br\\b"]);
    if (r === undefined) return null;
    const volume = (4 / 3) * Math.PI * Math.pow(r, 3);
    const sa = 4 * Math.PI * r * r;
    return { matched: true, category: "Sphere", steps: [`r=${fmt(r)}`, `Volume = (4/3)πr³ = ${fmt(volume)}`, `Surface Area = 4πr² = ${fmt(sa)}`], answer: `Volume ≈ ${fmt(volume)} cubic units`, relatedFormulaId: "m9-sphere" };
  }
  return null;
};

const pythagorasSolver: WordProblemSolver = (lower) => {
  if (!/pythagoras|hypotenuse|right\s*triangle|right-angled/.test(lower)) return null;
  const hyp = extractVar(lower, ["hypotenuse", "\\bc\\b"]);
  const a = extractVar(lower, ["\\ba\\b", "base", "one side", "first side", "first leg"]);
  const b = extractVar(lower, ["\\bb\\b", "perpendicular", "other side", "second side", "second leg"]);
  if (hyp === undefined && a !== undefined && b !== undefined) {
    const c = Math.sqrt(a * a + b * b);
    return { matched: true, category: "Pythagoras Theorem", steps: [`a=${fmt(a)}, b=${fmt(b)}`, `c = √(a²+b²) = √(${fmt(a * a)}+${fmt(b * b)}) = ${fmt(c)}`], answer: `Hypotenuse = ${fmt(c)}`, relatedFormulaId: "m10-pythagoras" };
  }
  if (hyp !== undefined && a !== undefined && b === undefined) {
    const other = Math.sqrt(Math.max(hyp * hyp - a * a, 0));
    return { matched: true, category: "Pythagoras Theorem", steps: [`c=${fmt(hyp)}, a=${fmt(a)}`, `b = √(c²−a²) = ${fmt(other)}`], answer: `Other side = ${fmt(other)}`, relatedFormulaId: "m10-pythagoras" };
  }
  const nums = allNumbers(lower);
  if (nums.length >= 2) {
    const [x, y] = nums;
    const c = Math.sqrt(x * x + y * y);
    return { matched: true, category: "Pythagoras Theorem", steps: [`legs = ${fmt(x)}, ${fmt(y)}`, `hypotenuse = √(${fmt(x)}²+${fmt(y)}²) = ${fmt(c)}`], answer: `Hypotenuse ≈ ${fmt(c)}`, relatedFormulaId: "m10-pythagoras" };
  }
  return null;
};

const statsListSolver: WordProblemSolver = (lower, original) => {
  if (!/mean|average|median|mode|\brange\b/.test(lower)) return null;
  const nums = allNumbers(original);
  if (nums.length < 2) return null;
  const sorted = [...nums].sort((x, y) => x - y);
  const mean = nums.reduce((s, v) => s + v, 0) / nums.length;
  const mid = Math.floor(sorted.length / 2);
  const median = sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
  const freq: Record<number, number> = {};
  nums.forEach((n) => (freq[n] = (freq[n] || 0) + 1));
  let mode = nums[0];
  let maxF = 0;
  Object.entries(freq).forEach(([k, c]) => {
    if (c > maxF) {
      maxF = c;
      mode = Number(k);
    }
  });
  const range = Math.max(...nums) - Math.min(...nums);
  const steps = [`Data: ${nums.join(", ")}`];
  if (/mean|average/.test(lower)) {
    steps.push(`Mean = sum / count = ${fmt(nums.reduce((s, v) => s + v, 0))} / ${nums.length} = ${fmt(mean)}`);
    return { matched: true, category: "Statistics — Mean", steps, answer: `Mean = ${fmt(mean)}`, relatedFormulaId: "m9-mean" };
  }
  if (/median/.test(lower)) {
    steps.push(`Sorted: ${sorted.join(", ")}`, `Median = ${fmt(median)}`);
    return { matched: true, category: "Statistics — Median", steps, answer: `Median = ${fmt(median)}`, relatedFormulaId: "m9-median" };
  }
  if (/mode/.test(lower)) {
    steps.push(`Most frequent value = ${fmt(mode)} (appears ${maxF} times)`);
    return { matched: true, category: "Statistics — Mode", steps, answer: `Mode = ${fmt(mode)}`, relatedFormulaId: "m9-mode" };
  }
  steps.push(`Range = max − min = ${fmt(Math.max(...nums))} − ${fmt(Math.min(...nums))} = ${fmt(range)}`);
  return { matched: true, category: "Statistics — Range", steps, answer: `Range = ${fmt(range)}`, relatedFormulaId: "m9-range" };
};

const hcfLcmSolver: WordProblemSolver = (lower, original) => {
  if (!/\bhcf\b|\blcm\b|\bgcd\b|greatest common|lowest common/.test(lower)) return null;
  const nums = allNumbers(original);
  if (nums.length < 2) return null;
  const [a, b] = nums;
  const gcd = (x: number, y: number): number => (y === 0 ? x : gcd(y, x % y));
  const h = gcd(Math.round(a), Math.round(b));
  const l = (a * b) / h;
  const steps = [`Numbers: ${fmt(a)}, ${fmt(b)}`, `HCF = ${fmt(h)}`, `LCM = (a×b) / HCF = (${fmt(a)}×${fmt(b)}) / ${fmt(h)} = ${fmt(l)}`];
  return { matched: true, category: "HCF and LCM", steps, answer: `HCF = ${fmt(h)}, LCM = ${fmt(l)}`, relatedFormulaId: "m10-hcf-lcm" };
};

const apSolver: WordProblemSolver = (lower) => {
  if (!/arithmetic progression|\bap\b|nth term|common difference/.test(lower)) return null;
  const a = extractVar(lower, ["first term", "\\ba\\b"]);
  const d = extractVar(lower, ["common difference", "\\bd\\b"]);
  const n = extractVar(lower, ["term number", "nth term", "\\bn\\b"]);
  if (a === undefined || d === undefined || n === undefined) return null;
  const term = a + (n - 1) * d;
  return { matched: true, category: "Arithmetic Progression", steps: [`a=${fmt(a)}, d=${fmt(d)}, n=${fmt(n)}`, `aₙ = a + (n−1)d = ${fmt(a)} + (${fmt(n)}−1)×${fmt(d)} = ${fmt(term)}`], answer: `aₙ = ${fmt(term)}`, relatedFormulaId: "m10-ap-nth-term" };
};

const trigSolver: WordProblemSolver = (_lower, original) => {
  const m = /\b(cosec|sec|cot|sin|cos|tan)\b\D{0,6}?(-?\d+(?:\.\d+)?)/i.exec(original);
  if (!m) return null;
  const fn = m[1].toLowerCase();
  const deg = parseFloat(m[2]);
  const rad = (deg * Math.PI) / 180;
  let value: number;
  switch (fn) {
    case "sin":
      value = Math.sin(rad);
      break;
    case "cos":
      value = Math.cos(rad);
      break;
    case "tan":
      value = Math.tan(rad);
      break;
    case "cosec":
      value = 1 / Math.sin(rad);
      break;
    case "sec":
      value = 1 / Math.cos(rad);
      break;
    default:
      value = 1 / Math.tan(rad);
  }
  return { matched: true, category: "Trigonometric Ratio", steps: [`${fn} ${fmt(deg)}°`], answer: `${fn} ${fmt(deg)}° ≈ ${fmt(value, 4)}`, relatedFormulaId: "m10-trig-ratios" };
};

const percentageSolver: WordProblemSolver = (lower) => {
  let m = /(-?\d+(?:\.\d+)?)\s*(?:%|percent)\s*of\s*(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) {
    const p = parseFloat(m[1]);
    const n = parseFloat(m[2]);
    const result = (p / 100) * n;
    return { matched: true, category: "Percentage", steps: [`${fmt(p)}% of ${fmt(n)}`, `= (${fmt(p)}/100) × ${fmt(n)} = ${fmt(result)}`], answer: `${fmt(result)}`, relatedFormulaId: "m8-percentage" };
  }
  m = /(-?\d+(?:\.\d+)?)\s+is\s+what\s+percent(?:age)?\s+of\s+(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) {
    const x = parseFloat(m[1]);
    const y = parseFloat(m[2]);
    const result = (x / y) * 100;
    return { matched: true, category: "Percentage", steps: [`${fmt(x)} is what % of ${fmt(y)}`, `= (${fmt(x)}/${fmt(y)}) × 100 = ${fmt(result)}%`], answer: `${fmt(result)}%`, relatedFormulaId: "m8-percentage" };
  }
  m = /what\s+percent(?:age)?\s+of\s+(-?\d+(?:\.\d+)?)\s+is\s+(-?\d+(?:\.\d+)?)/i.exec(lower);
  if (m) {
    const y = parseFloat(m[1]);
    const x = parseFloat(m[2]);
    const result = (x / y) * 100;
    return { matched: true, category: "Percentage", steps: [`what % of ${fmt(y)} is ${fmt(x)}`, `= (${fmt(x)}/${fmt(y)}) × 100 = ${fmt(result)}%`], answer: `${fmt(result)}%`, relatedFormulaId: "m8-percentage" };
  }
  return null;
};

const profitLossSolver: WordProblemSolver = (lower) => {
  if (!/\bcp\b|cost price|\bsp\b|selling price|profit|loss/.test(lower)) return null;
  const cp = extractVar(lower, ["cost price", "\\bcp\\b"]);
  const sp = extractVar(lower, ["selling price", "\\bsp\\b"]);
  if (cp === undefined || sp === undefined) return null;
  const diff = sp - cp;
  const isProfit = diff >= 0;
  const pct = (Math.abs(diff) / cp) * 100;
  const label = isProfit ? "Profit" : "Loss";
  const steps = [`CP = ${fmt(cp)}, SP = ${fmt(sp)}`, `${label} = |SP − CP| = ${fmt(Math.abs(diff))}`, `${label}% = (${fmt(Math.abs(diff))}/${fmt(cp)}) × 100 = ${fmt(pct)}%`];
  return { matched: true, category: label, steps, answer: `${label} = ${fmt(Math.abs(diff))}, ${label}% = ${fmt(pct)}%`, relatedFormulaId: "m8-profit-loss" };
};

const simpleInterestSolver: WordProblemSolver = (lower) => {
  if (!/simple interest/.test(lower)) return null;
  const p = extractVar(lower, ["principal", "\\bp\\b"]);
  const r = extractVar(lower, ["rate", "\\br\\b"]);
  const t = extractVar(lower, ["time", "years?", "\\bt\\b"]);
  if (p === undefined || r === undefined || t === undefined) return null;
  const si = (p * r * t) / 100;
  const steps = [`P=${fmt(p)}, R=${fmt(r)}%, T=${fmt(t)} yrs`, `SI = (P×R×T)/100 = (${fmt(p)}×${fmt(r)}×${fmt(t)})/100 = ${fmt(si)}`];
  return { matched: true, category: "Simple Interest", steps, answer: `SI = ${fmt(si)}, Amount = ${fmt(p + si)}`, relatedFormulaId: "m8-simple-interest" };
};

const compoundInterestSolver: WordProblemSolver = (lower) => {
  if (!/compound interest/.test(lower)) return null;
  const p = extractVar(lower, ["principal", "\\bp\\b"]);
  const r = extractVar(lower, ["rate", "\\br\\b"]);
  const t = extractVar(lower, ["time", "years?", "\\bt\\b", "\\bn\\b"]);
  if (p === undefined || r === undefined || t === undefined) return null;
  const a = p * Math.pow(1 + r / 100, t);
  const ci = a - p;
  const steps = [`P=${fmt(p)}, R=${fmt(r)}%, n=${fmt(t)} yrs`, `A = P(1+R/100)ⁿ = ${fmt(p)}×(1+${fmt(r)}/100)^${fmt(t)} = ${fmt(a)}`, `CI = A − P = ${fmt(ci)}`];
  return { matched: true, category: "Compound Interest", steps, answer: `Amount = ${fmt(a)}, CI = ${fmt(ci)}`, relatedFormulaId: "m8-compound-interest" };
};

const speedSolver: WordProblemSolver = (lower) => {
  if (!/speed|distance|velocity|travel|cover/.test(lower)) return null;
  let d = extractVar(lower, ["distance", "\\bd\\b"]);
  let t = extractVar(lower, ["time", "\\bt\\b"]);
  const s = extractVar(lower, ["speed", "velocity", "\\bs\\b"]);

  if (d === undefined) {
    const m = /(?:travels?|covers?|runs?|moves?)\D{0,10}?(-?\d+(?:\.\d+)?)/i.exec(lower);
    if (m) d = parseFloat(m[1]);
  }
  if (t === undefined) {
    const m = /in\s*(-?\d+(?:\.\d+)?)\s*(?:hours?|hrs?|h\b|minutes?|mins?|seconds?|secs?|s\b)/i.exec(lower);
    if (m) t = parseFloat(m[1]);
  }

  if (d !== undefined && t !== undefined && s === undefined) {
    const speed = d / t;
    return { matched: true, category: "Speed, Distance & Time", steps: [`distance = ${fmt(d)}, time = ${fmt(t)}`, `Speed = Distance / Time = ${fmt(d)} / ${fmt(t)} = ${fmt(speed)}`], answer: `Speed = ${fmt(speed)}`, relatedFormulaId: "p8-speed-basic" };
  }
  if (s !== undefined && t !== undefined && d === undefined) {
    const dist = s * t;
    return { matched: true, category: "Speed, Distance & Time", steps: [`speed = ${fmt(s)}, time = ${fmt(t)}`, `Distance = Speed × Time = ${fmt(s)} × ${fmt(t)} = ${fmt(dist)}`], answer: `Distance = ${fmt(dist)}`, relatedFormulaId: "p8-speed-basic" };
  }
  if (s !== undefined && d !== undefined && t === undefined) {
    const time = d / s;
    return { matched: true, category: "Speed, Distance & Time", steps: [`distance = ${fmt(d)}, speed = ${fmt(s)}`, `Time = Distance / Speed = ${fmt(d)} / ${fmt(s)} = ${fmt(time)}`], answer: `Time = ${fmt(time)}`, relatedFormulaId: "p8-speed-basic" };
  }
  return null;
};

const motionSolver: WordProblemSolver = (lower) => {
  if (!/acceleration|equations? of motion|initial velocity|final velocity/.test(lower)) return null;
  const u = extractVar(lower, ["initial velocity", "\\bu\\b"]);
  const v = extractVar(lower, ["final velocity", "\\bv\\b"]);
  const t = extractVar(lower, ["time", "\\bt\\b"]);
  const a = extractVar(lower, ["acceleration", "\\ba\\b"]);
  if (u !== undefined && v !== undefined && t !== undefined && a === undefined) {
    const acc = (v - u) / t;
    return { matched: true, category: "Acceleration", steps: [`u=${fmt(u)}, v=${fmt(v)}, t=${fmt(t)}`, `a = (v−u)/t = (${fmt(v)}−${fmt(u)})/${fmt(t)} = ${fmt(acc)}`], answer: `a = ${fmt(acc)} m/s²`, relatedFormulaId: "p9-acceleration" };
  }
  if (u !== undefined && a !== undefined && t !== undefined) {
    const vFinal = u + a * t;
    const s = u * t + 0.5 * a * t * t;
    return { matched: true, category: "Equations of Motion", steps: [`u=${fmt(u)}, a=${fmt(a)}, t=${fmt(t)}`, `v = u + at = ${fmt(u)} + ${fmt(a)}×${fmt(t)} = ${fmt(vFinal)}`, `s = ut + ½at² = ${fmt(s)}`], answer: `v = ${fmt(vFinal)} m/s, s = ${fmt(s)} m`, relatedFormulaId: "p9-equations-of-motion" };
  }
  return null;
};

const ohmsLawSolver: WordProblemSolver = (lower) => {
  if (!/ohm|voltage|resistance|current/.test(lower)) return null;
  const V = extractVar(lower, ["voltage", "potential difference", "\\bv\\b"]);
  const I = extractVar(lower, ["current", "\\bi\\b"]);
  const R = extractVar(lower, ["resistance", "\\br\\b"]);
  if (V !== undefined && R !== undefined && I === undefined) {
    const current = V / R;
    return { matched: true, category: "Ohm's Law", steps: [`V=${fmt(V)}V, R=${fmt(R)}Ω`, `I = V/R = ${fmt(V)}/${fmt(R)} = ${fmt(current)}A`], answer: `I = ${fmt(current)} A`, relatedFormulaId: "p10-ohms-law" };
  }
  if (V !== undefined && I !== undefined && R === undefined) {
    const res = V / I;
    return { matched: true, category: "Ohm's Law", steps: [`V=${fmt(V)}V, I=${fmt(I)}A`, `R = V/I = ${fmt(V)}/${fmt(I)} = ${fmt(res)}Ω`], answer: `R = ${fmt(res)} Ω`, relatedFormulaId: "p10-ohms-law" };
  }
  if (I !== undefined && R !== undefined && V === undefined) {
    const volt = I * R;
    return { matched: true, category: "Ohm's Law", steps: [`I=${fmt(I)}A, R=${fmt(R)}Ω`, `V = I×R = ${fmt(I)}×${fmt(R)} = ${fmt(volt)}V`], answer: `V = ${fmt(volt)} V`, relatedFormulaId: "p10-ohms-law" };
  }
  return null;
};

const workEnergySolver: WordProblemSolver = (lower) => {
  const force = extractVar(lower, ["force", "\\bf\\b"]);
  const dist = extractVar(lower, ["distance", "\\bd\\b"]);
  if (/\bwork\b/.test(lower) && force !== undefined && dist !== undefined) {
    const w = force * dist;
    return { matched: true, category: "Work Done", steps: [`F=${fmt(force)}N, d=${fmt(dist)}m`, `W = F × d = ${fmt(force)} × ${fmt(dist)} = ${fmt(w)} J`], answer: `W = ${fmt(w)} J`, relatedFormulaId: "p9-work" };
  }
  const work = extractVar(lower, ["work done", "\\bw\\b"]);
  const time = extractVar(lower, ["time", "\\bt\\b"]);
  if (/power/.test(lower) && work !== undefined && time !== undefined && !/voltage|current/.test(lower)) {
    const p = work / time;
    return { matched: true, category: "Power", steps: [`W=${fmt(work)}J, t=${fmt(time)}s`, `P = W/t = ${fmt(work)}/${fmt(time)} = ${fmt(p)} W`], answer: `P = ${fmt(p)} W`, relatedFormulaId: "p9-power" };
  }
  const mass = extractVar(lower, ["mass", "\\bm\\b"]);
  const vel = extractVar(lower, ["velocity", "speed", "\\bv\\b"]);
  if (/kinetic energy|\bke\b/.test(lower) && mass !== undefined && vel !== undefined) {
    const ke = 0.5 * mass * vel * vel;
    return { matched: true, category: "Kinetic Energy", steps: [`m=${fmt(mass)}kg, v=${fmt(vel)}m/s`, `KE = ½mv² = ½×${fmt(mass)}×${fmt(vel)}² = ${fmt(ke)} J`], answer: `KE = ${fmt(ke)} J`, relatedFormulaId: "p9-kinetic-energy" };
  }
  const height = extractVar(lower, ["height", "\\bh\\b"]);
  if (/potential energy|\bpe\b/.test(lower) && mass !== undefined && height !== undefined) {
    const g = 9.8;
    const pe = mass * g * height;
    return { matched: true, category: "Potential Energy", steps: [`m=${fmt(mass)}kg, h=${fmt(height)}m, g=9.8m/s²`, `PE = mgh = ${fmt(mass)}×9.8×${fmt(height)} = ${fmt(pe)} J`], answer: `PE = ${fmt(pe)} J`, relatedFormulaId: "p9-potential-energy" };
  }
  return null;
};

const densitySolver: WordProblemSolver = (lower) => {
  if (!/density/.test(lower)) return null;
  const mass = extractVar(lower, ["mass", "\\bm\\b"]);
  const volume = extractVar(lower, ["volume", "\\bv\\b"]);
  const density = extractVar(lower, ["density", "ρ"]);
  if (mass !== undefined && volume !== undefined) {
    const d = mass / volume;
    return { matched: true, category: "Density", steps: [`m=${fmt(mass)}, V=${fmt(volume)}`, `ρ = m/V = ${fmt(mass)}/${fmt(volume)} = ${fmt(d)}`], answer: `Density = ${fmt(d)}`, relatedFormulaId: "p8-density" };
  }
  if (density !== undefined && volume !== undefined) {
    const m = density * volume;
    return { matched: true, category: "Density", steps: [`ρ=${fmt(density)}, V=${fmt(volume)}`, `m = ρ×V = ${fmt(density)}×${fmt(volume)} = ${fmt(m)}`], answer: `Mass = ${fmt(m)}`, relatedFormulaId: "p8-density" };
  }
  if (density !== undefined && mass !== undefined) {
    const v = mass / density;
    return { matched: true, category: "Density", steps: [`ρ=${fmt(density)}, m=${fmt(mass)}`, `V = m/ρ = ${fmt(mass)}/${fmt(density)} = ${fmt(v)}`], answer: `Volume = ${fmt(v)}`, relatedFormulaId: "p8-density" };
  }
  return null;
};

const pressureSolver: WordProblemSolver = (lower) => {
  if (!/pressure/.test(lower)) return null;
  const force = extractVar(lower, ["force", "\\bf\\b"]);
  const area = extractVar(lower, ["area", "\\ba\\b"]);
  if (force === undefined || area === undefined) return null;
  const p = force / area;
  return { matched: true, category: "Pressure", steps: [`F=${fmt(force)}N, A=${fmt(area)}m²`, `P = F/A = ${fmt(force)}/${fmt(area)} = ${fmt(p)} Pa`], answer: `P = ${fmt(p)} Pa`, relatedFormulaId: "p8-pressure" };
};

const electricalSolver: WordProblemSolver = (lower) => {
  const V = extractVar(lower, ["voltage", "\\bv\\b"]);
  const I = extractVar(lower, ["current", "\\bi\\b"]);
  const R = extractVar(lower, ["resistance", "\\br\\b"]);
  const t = extractVar(lower, ["time", "\\bt\\b"]);
  if (/heat|joule/.test(lower) && I !== undefined && R !== undefined && t !== undefined) {
    const h = I * I * R * t;
    return { matched: true, category: "Joule's Law of Heating", steps: [`I=${fmt(I)}A, R=${fmt(R)}Ω, t=${fmt(t)}s`, `H = I²Rt = ${fmt(I)}²×${fmt(R)}×${fmt(t)} = ${fmt(h)} J`], answer: `H = ${fmt(h)} J`, relatedFormulaId: "p10-joules-law" };
  }
  if (/electrical power|\bpower\b/.test(lower) && V !== undefined && I !== undefined) {
    const p = V * I;
    return { matched: true, category: "Electrical Power", steps: [`V=${fmt(V)}V, I=${fmt(I)}A`, `P = V×I = ${fmt(V)}×${fmt(I)} = ${fmt(p)} W`], answer: `P = ${fmt(p)} W`, relatedFormulaId: "p10-electrical-power" };
  }
  return null;
};

const moleSolver: WordProblemSolver = (lower) => {
  if (!/\bmole\b|\bmoles\b|molar mass/.test(lower)) return null;
  const mass = extractVar(lower, ["given mass", "mass", "\\bm\\b"]);
  const molar = extractVar(lower, ["molar mass"]);
  if (mass === undefined || molar === undefined) return null;
  const n = mass / molar;
  return { matched: true, category: "Mole Concept", steps: [`mass = ${fmt(mass)} g, molar mass = ${fmt(molar)} g/mol`, `n = mass / molar mass = ${fmt(mass)} / ${fmt(molar)} = ${fmt(n)} mol`], answer: `n = ${fmt(n)} mol`, relatedFormulaId: "c9-mole-concept" };
};

const phSolver: WordProblemSolver = (lower, original) => {
  if (!/\bph\b/.test(lower)) return null;
  const m = /10\s*\^?\s*-\s*(\d+(?:\.\d+)?)/.exec(original) || /1e-(\d+(?:\.\d+)?)/i.exec(original);
  if (!m) return null;
  const exp = parseFloat(m[1]);
  return { matched: true, category: "pH Scale", steps: [`[H⁺] = 10^(−${fmt(exp)})`, `pH = −log₁₀[H⁺] = ${fmt(exp)}`], answer: `pH = ${fmt(exp)}`, relatedFormulaId: "c10-ph" };
};

export const WORD_PROBLEM_SOLVERS: WordProblemSolver[] = [
  naturalArithmeticSolver,
  squareRootSolver,
  hcfLcmSolver,
  apSolver,
  trigSolver,
  statsListSolver,
  circleSolver,
  rectangleSolver,
  squareSolver,
  quadAreaSolver,
  triangleSolver,
  solidVolumeSolver,
  pythagorasSolver,
  percentageSolver,
  profitLossSolver,
  simpleInterestSolver,
  compoundInterestSolver,
  motionSolver,
  speedSolver,
  ohmsLawSolver,
  electricalSolver,
  workEnergySolver,
  densitySolver,
  pressureSolver,
  moleSolver,
  phSolver,
];
