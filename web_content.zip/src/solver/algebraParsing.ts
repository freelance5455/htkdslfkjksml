// Shared algebraic term parser used by both the single-variable equation
// solver (evaluate.ts) and the two-variable simultaneous equation solver
// (algebra.ts). Handles distribution over parentheses (e.g. "2(x+3)-5"),
// which a naive term-splitter would silently mis-parse — a real source of
// wrong answers in the previous version of this solver.

export type CoeffMap = Record<string, number> & { _const: number };

function normalize(raw: string, variables: string[]): string {
  let s = raw
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/×/g, "*")
    .replace(/÷/g, "/");
  for (const v of variables) {
    s = s.replace(new RegExp(`\\*${v}`, "g"), v);
    s = s.replace(new RegExp(`${v}\\^2`, "g"), `${v}2`);
    s = s.replace(new RegExp(`${v}²`, "g"), `${v}2`);
  }
  return s;
}

/** Multiplies a single signed term (e.g. "+3x", "-x2", "+7") by `factor`,
 *  returning a new signed term string with the same variable suffix. */
function multiplyTerm(term: string, factor: number, variables: string[]): string {
  const sign = term[0] === "-" ? -1 : 1;
  const rest = term.slice(1);
  for (const v of variables) {
    if (rest.endsWith(`${v}2`)) {
      const numPart = rest.slice(0, -(v.length + 1));
      const coef = numPart === "" ? 1 : parseFloat(numPart);
      const result = sign * (Number.isNaN(coef) ? 1 : coef) * factor;
      return `${result < 0 ? "-" : "+"}${Math.abs(result)}${v}2`;
    }
  }
  for (const v of variables) {
    if (rest.endsWith(v)) {
      const numPart = rest.slice(0, -v.length);
      const coef = numPart === "" ? 1 : parseFloat(numPart);
      const result = sign * (Number.isNaN(coef) ? 1 : coef) * factor;
      return `${result < 0 ? "-" : "+"}${Math.abs(result)}${v}`;
    }
  }
  const coef = parseFloat(rest);
  const result = sign * (Number.isNaN(coef) ? 0 : coef) * factor;
  return `${result < 0 ? "-" : "+"}${Math.abs(result)}`;
}

function splitSignedTerms(s: string): string[] {
  let t = s;
  if (!t) return [];
  if (!/^[+-]/.test(t)) t = "+" + t;
  return t.match(/[+-][^+-]+/g) || [];
}

/** Repeatedly expands single-level (non-nested, or innermost-first nested)
 *  parenthesised groups like "3(x+2)" or "-(x-4)" by distributing the
 *  leading coefficient across every term inside, until no parentheses
 *  remain. Handles the common Class 8-10 "multi-step" equation patterns. */
export function expandParentheses(raw: string, variables: string[]): string {
  return expandParenthesesLoop(raw, variables);
}

function expandParenthesesLoop(raw: string, variables: string[]): string {
  let s = raw;
  const re = /([+-]?\d*\.?\d*)\(([^()]+)\)/;
  let guard = 0;
  while (guard < 15) {
    const m = re.exec(s);
    if (!m) break;
    const [full, coefRaw, inner] = m;
    const coef = coefRaw === "" || coefRaw === "+" ? 1 : coefRaw === "-" ? -1 : parseFloat(coefRaw);
    const terms = splitSignedTerms(inner);
    const expanded = terms.map((t) => multiplyTerm(t, coef, variables)).join("");
    s = s.slice(0, m.index) + (expanded.startsWith("-") || expanded.startsWith("+") ? expanded : "+" + expanded) + s.slice(m.index + full.length);
    guard++;
  }
  return s;
}

/** Parses one side of an equation (already variable-normalized, e.g. "x"/"y")
 *  into a coefficient map: { x: 2, y: -1, _const: 5 } for "2x - y + 5". */
export function parseSideToCoeffs(sideRaw: string, variables: string[]): CoeffMap {
  const normalized = normalize(sideRaw, variables);
  const expanded = expandParenthesesLoop(normalized, variables);
  const result: CoeffMap = { _const: 0 } as CoeffMap;
  for (const v of variables) result[v] = 0;

  if (!expanded) return result;
  const terms = splitSignedTerms(expanded);
  for (const term of terms) {
    const sign = term[0] === "-" ? -1 : 1;
    const rest = term.slice(1);
    if (!rest) continue;
    let matchedVar: string | null = null;
    let isSquare = false;
    for (const v of variables) {
      if (rest.endsWith(`${v}2`)) {
        matchedVar = v;
        isSquare = true;
        break;
      }
    }
    if (!matchedVar) {
      for (const v of variables) {
        if (rest.endsWith(v)) {
          matchedVar = v;
          break;
        }
      }
    }
    if (matchedVar) {
      const suffixLen = matchedVar.length + (isSquare ? 1 : 0);
      const numPart = rest.slice(0, rest.length - suffixLen);
      const coef = numPart === "" ? 1 : parseFloat(numPart);
      const key = isSquare ? `${matchedVar}2` : matchedVar;
      result[key] = (result[key] ?? 0) + sign * (Number.isNaN(coef) ? 1 : coef);
    } else {
      const coef = parseFloat(rest);
      if (!Number.isNaN(coef)) result._const += sign * coef;
    }
  }
  return result;
}
