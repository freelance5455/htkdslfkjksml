import { KNOWLEDGE_BASE } from "./knowledgeBase";
import type { FormulaUsage } from "./types";

// ---------------------------------------------------------------------------
// Honest internet formula lookup.
//
// FormulaVerse is a static, frontend-only web app with no backend server.
// There is currently no search/AI API key configured for this deployment,
// and secret API keys must never be embedded in frontend code (they would be
// visible to anyone who opens dev tools). Because of that, this module NEVER
// fabricates a web search result, source name, or URL.
//
// What it actually does:
//   1. If a future deployment wires up `VITE_FORMULA_LOOKUP_ENDPOINT` to a
//      real backend/proxy that performs a genuine, verified educational
//      search, this function will call it and only return a formula/source
//      when that service genuinely found one.
//   2. Otherwise (the default, today) it falls back to FormulaVerse's own
//      curated, textbook-verified knowledge base of Class 8-10 theorems that
//      aren't full interactive library pages yet — and it clearly labels
//      these as "built-in knowledge", not an internet result.
// ---------------------------------------------------------------------------

export interface LookupOutcome {
  found: boolean;
  usedInternet: boolean;
  entry?: FormulaUsage;
  message: string;
}

const LOOKUP_ENDPOINT = (import.meta as any).env?.VITE_FORMULA_LOOKUP_ENDPOINT as string | undefined;

async function tryOnlineLookup(query: string): Promise<FormulaUsage | null> {
  if (!LOOKUP_ENDPOINT) return null;
  try {
    const res = await fetch(`${LOOKUP_ENDPOINT}?q=${encodeURIComponent(query)}`, { method: "GET" });
    if (!res.ok) return null;
    const data = await res.json();
    if (!data || !data.name || !data.expression || !data.source?.url) return null;
    return {
      name: data.name,
      expression: data.expression,
      explanation: data.explanation ?? "",
      example: data.example,
      subject: data.subject,
      topic: data.topic,
      classLevel: data.classLevel,
      source: { name: data.source.name, url: data.source.url },
    };
  } catch {
    return null;
  }
}

function searchKnowledgeBase(query: string): FormulaUsage | null {
  const q = query.toLowerCase();
  const terms = q.split(/\s+/).filter((t) => t.length > 2);
  let best: FormulaUsage | null = null;
  let bestScore = 0;
  for (const entry of Object.values(KNOWLEDGE_BASE)) {
    const haystack = `${entry.name} ${entry.topic ?? ""} ${entry.explanation}`.toLowerCase();
    let score = 0;
    for (const t of terms) if (haystack.includes(t)) score++;
    if (score > bestScore) {
      bestScore = score;
      best = entry;
    }
  }
  return bestScore > 0 ? best : null;
}

export async function lookupFormula(query: string): Promise<LookupOutcome> {
  const online = await tryOnlineLookup(query);
  if (online) {
    return { found: true, usedInternet: true, entry: online, message: `Found via ${online.source?.name ?? "an online educational source"}.` };
  }

  const builtin = searchKnowledgeBase(query);
  if (builtin) {
    return {
      found: true,
      usedInternet: false,
      entry: builtin,
      message: "No internet lookup service is configured in this deployment, so this was matched against FormulaVerse's built-in, textbook-verified knowledge base (not fetched from the internet).",
    };
  }

  return {
    found: false,
    usedInternet: false,
    message: LOOKUP_ENDPOINT
      ? "Neither the online lookup service nor the built-in knowledge base had a matching formula for this question."
      : "No internet lookup service is configured in this deployment, and this topic isn't in FormulaVerse's built-in knowledge base yet. Try rephrasing, or browse Search for a related formula.",
  };
}

export const INTERNET_LOOKUP_CONFIGURED = Boolean(LOOKUP_ENDPOINT);
