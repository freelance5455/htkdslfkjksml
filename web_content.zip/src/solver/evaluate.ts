// Safe, dependency-free arithmetic expression evaluator and
// linear/quadratic single-variable equation solver. No eval(), no AI —
// just a small recursive-descent parser.

import { parseSideToCoeffs } from "./algebraParsing";

export function evaluateExpression(raw: string): number {
  const expr = raw
    .replace(/π/g, "3.14159265358979")
    .replace(/\bpi\b/gi, "3.14159265358979")
    .replace(/×/g, "*")
    .replace(/÷/g, "/")
    .replace(/√/g, "sqrt")
    .replace(/\s+/g, "");

  let i = 0;
  const peek = () => expr[i];
  const consume = () => expr[i++];

  function parseExpression(): number {
    let value = parseTerm();
    while (peek() === "+" || peek() === "-") {
      const op = consume();
      const rhs = parseTerm();
      value = op === "+" ? value + rhs : value - rhs;
    }
    return value;
  }
  function parseTerm(): number {
    let value = parsePower();
    while (peek() === "*" || peek() === "/") {
      const op = consume();
      const rhs = parsePower();
      value = op === "*" ? value * rhs : value / rhs;
    }
    return value;
  }
  function parsePower(): number {
    const value = parseUnary();
    if (peek() === "^") {
      consume();
      const rhs = parsePower();
      return Math.pow(value, rhs);
    }
    return value;
  }
  function parseUnary(): number {
    if (peek() === "-") {
      consume();
      return -parseUnary();
    }
    if (peek() === "+") {
      consume();
      return parseUnary();
    }
    return parseAtom();
  }
  function parseAtom(): number {
    if (peek() === "(") {
      consume();
      const value = parseExpression();
      if (peek() === (")" as string)) consume();
      return value;
    }
    if (expr.slice(i, i + 4) === "sqrt") {
      i += 4;
      if (peek() === "(") {
        consume();
        const value = parseExpression();
        if (peek() === (")" as string)) consume();
        return Math.sqrt(value);
      }
    }
    const start = i;
    while (i < expr.length && /[0-9.]/.test(expr[i])) i++;
    if (start === i) throw new Error(`Unexpected character at position ${i}: ${expr[i]}`);
    return parseFloat(expr.slice(start, i));
  }

  if (!expr) throw new Error("Empty expression");
  const result = parseExpression();
  if (i < expr.length) throw new Error("Unexpected trailing characters in expression");
  if (Number.isNaN(result)) throw new Error("Invalid expression");
  return result;
}

export function isArithmeticCandidate(cleaned: string): boolean {
  if (!cleaned || cleaned.includes("=")) return false;
  const withoutFns = cleaned.replace(/sqrt/gi, "").replace(/\bpi\b/gi, "");
  return /^[0-9+\-*/^().\s]+$/.test(withoutFns) && /\d/.test(withoutFns) && /[+\-*/^]/.test(withoutFns);
}

interface ABC {
  a: number;
  b: number;
  c: number;
}

export function detectEquationVariable(cleaned: string): string | null {
  if (!cleaned.includes("=")) return null;
  const letters = Array.from(new Set((cleaned.toLowerCase().match(/[a-z]/g) || []).filter((l) => l !== "e")));
  if (letters.length !== 1) return null;
  return letters[0];
}

export function isEquationCandidate(cleaned: string): boolean {
  const variable = detectEquationVariable(cleaned);
  if (!variable) return false;
  const charset = new RegExp(`^[0-9${variable}+\\-*/^().=\\s]+$`, "i");
  return charset.test(cleaned);
}

/** Solves ax^2+bx+c=0 (or ax+c=0 when a=0) for a single variable, correctly
 *  handling parentheses/distribution (e.g. "2(x+3) - 5 = 3x - 7") via the
 *  shared algebraic term parser. */
export function solveEquationToABC(cleaned: string, variable: string): ABC {
  const normalized = cleaned.replace(new RegExp(variable, "gi"), "x");
  const [lhs, rhs] = normalized.split("=");
  if (rhs === undefined) throw new Error("No '=' found in equation");
  const L = parseSideToCoeffs(lhs, ["x"]);
  const R = parseSideToCoeffs(rhs, ["x"]);
  return { a: (L["x2"] ?? 0) - (R["x2"] ?? 0), b: (L["x"] ?? 0) - (R["x"] ?? 0), c: L._const - R._const };
}
