
/* =====================================================================
   ANIMASI — PUPPET RIG 2D
   Sprite dipotong jadi bagian (badan atas, kaki+jubah, senjata, perisai, sayap)
   lalu tiap bagian diputar dari sendinya (pivot). Pose dihitung per state.
   Semua pose ditulis untuk sprite yang menghadap KIRI (maju = x negatif).
   ===================================================================== */
const SC=1.12;                       // skala gambar karakter (lebih besar di layar)
const D2R=Math.PI/180;
const easeIO=k=>{k=clamp(k,0,1);return k*k*(3-2*k)},easeO=k=>1-Math.pow(1-clamp(k,0,1),3);
const RIGDEF={
  slayer:{key:'slayer',sf:-1,B:23,polys:{sword:[[50,186],[84,184],[82,204],[72,232],[60,262],[48,290],[30,322],[14,340],[0,340],[0,322],[12,296],[24,262],[32,232],[40,206]]},
    parts:[{id:'legL',rect:[0,252,140,420],cut:['sword'],pv:[100,256],z:0,parent:'lower'},
           {id:'legR',rect:[140,252,217,420],cut:['sword'],pv:[178,256],z:0,parent:'lower'},
           {id:'lower',rect:[0,196,217,272],cut:['sword'],pv:[112,205],z:1},
           {id:'upper',rect:[0,0,217,214],fade:[196,214],cut:['sword'],pv:[112,205],z:2},
           {id:'sword',poly:'sword',pv:[66,188],z:3,parent:'upper',glow:'#ff2a3a'}]},
  blood:{key:'blood',sf:-1,B:20,polys:{sword:[[44,178],[66,168],[70,180],[60,215],[46,255],[30,292],[12,320],[2,328],[0,318],[10,290],[22,250],[36,210]]},
    parts:[{id:'lower',rect:[0,186,233,330],cut:['sword'],pv:[115,195],z:0},{id:'upper',rect:[0,0,233,206],fade:[186,206],cut:['sword'],pv:[115,195],z:1},{id:'sword',poly:'sword',pv:[58,172],z:2,parent:'upper',glow:'#ff2a3a'}]},
  goblin:{key:'goblin',sf:-1,B:46,polys:{sword:[[0,106],[0,122],[26,98],[36,98],[46,92],[52,84],[68,44],[74,32],[62,30],[40,62],[30,70],[22,84]],shield:[[138,28],[166,36],[182,64],[182,112],[168,120],[150,110],[140,84],[136,50]]},
    parts:[{id:'lower',rect:[0,100,183,153],cut:['sword','shield'],pv:[100,104],z:0},{id:'upper',rect:[0,0,183,112],fade:[100,112],cut:['sword','shield'],pv:[100,104],z:1},{id:'sword',poly:'sword',pv:[40,80],z:2,parent:'upper'},{id:'shield',poly:'shield',pv:[150,74],z:2,parent:'upper'}]},
  skeleton:{key:'skeleton',sf:-1,B:155,polys:{sword:[[12,16],[26,16],[52,76],[62,84],[62,96],[46,102],[34,92],[40,82]],shield:[[136,54],[162,56],[174,84],[174,128],[160,132],[146,118],[140,92]]},
    parts:[{id:'lower',rect:[0,104,174,165],cut:['sword','shield'],pv:[85,100],z:0},{id:'upper',rect:[0,0,174,116],fade:[104,116],cut:['sword','shield'],pv:[85,100],z:1},{id:'sword',poly:'sword',pv:[52,94],z:2,parent:'upper'},{id:'shield',poly:'shield',pv:[150,92],z:2,parent:'upper'}]},
  gargoyle:{key:'gargoyle',sf:1,B:0,polys:{wl:[[20,2],[84,0],[86,40],[82,80],[66,100],[52,120],[40,140],[28,140],[6,110],[0,80],[4,40]],wr:[[166,0],[196,4],[196,120],[178,112],[170,90],[168,50]]},
    parts:[{id:'body',cut:['wl','wr'],pv:[110,100],z:1},{id:'wl',poly:'wl',pv:[84,58],z:0,parent:'body'},{id:'wr',poly:'wr',pv:[168,48],z:0,parent:'body'}]}
};
const RIGS={};
function pathPoly(g,pts){g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath()}
function buildRigs(){
  for(const name in RIGDEF){
    const def=RIGDEF[name],im=IMG[def.key];if(!im)continue;
    const parts=def.parts.map(p=>{
      const c=document.createElement('canvas');c.width=im.width;c.height=im.height;const g=c.getContext('2d');
      g.save();
      if(p.poly){pathPoly(g,def.polys[p.poly]);g.clip()}
      else if(p.rect){g.beginPath();g.rect(p.rect[0],p.rect[1],p.rect[2]-p.rect[0],p.rect[3]-p.rect[1]);g.clip()}
      g.drawImage(im,0,0);g.restore();
      if(p.cut){g.globalCompositeOperation='destination-out';g.fillStyle='#000';g.strokeStyle='#000';g.lineWidth=1.5;for(const n of p.cut){pathPoly(g,def.polys[n]);g.fill();g.stroke()}g.globalCompositeOperation='source-over'}
      if(p.fade){g.globalCompositeOperation='destination-in';const gr=g.createLinearGradient(0,p.fade[0],0,p.fade[1]);gr.addColorStop(0,'#000');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(0,0,c.width,c.height);g.globalCompositeOperation='source-over'}
      const part={id:p.id,c,pv:p.pv,z:p.z,parent:p.parent||null,sil:{}};
      if(p.glow){const gc=document.createElement('canvas');gc.width=c.width;gc.height=c.height;const gg=gc.getContext('2d');gg.drawImage(c,0,0);gg.globalCompositeOperation='source-in';gg.fillStyle=p.glow;gg.fillRect(0,0,gc.width,gc.height);part.glowC=gc}
      return part;
    }).sort((a,b)=>a.z-b.z);
    RIGS[name]={def,parts,W0:im.width,H0:im.height};
  }
}
function partSil(part,col){
  if(part.sil[col])return part.sil[col];
  const c=document.createElement('canvas');c.width=part.c.width;c.height=part.c.height;const g=c.getContext('2d');
  g.drawImage(part.c,0,0);g.globalCompositeOperation='source-in';g.fillStyle=col;g.fillRect(0,0,c.width,c.height);return part.sil[col]=c;
}
/* gambar rig: x tengah, y kaki, h tinggi, pose {g:{dx,dy,rot,sx,sy},<part>:{rot,dx,dy,sx,sy,trail,glow}} */
function drawRig(name,x,y,h,face,pose,o){
  const R=RIGS[name];if(!R)return false;o=o||{};
  const s=h/R.H0,flip=(R.def.sf!==0&&face!==R.def.sf)?-1:1,g=pose.g||{};
  cx.save();
  cx.translate(x,y);cx.scale(flip*s*(g.sx||1),s*(g.sy||1));cx.translate(g.dx||0,g.dy||0);
  cx.translate(0,-R.H0/2);cx.rotate(g.rot||0);cx.translate(-R.W0/2,-R.H0/2);
  const alpha=o.alpha==null?1:o.alpha,byId={};
  for(const p of R.parts)byId[p.id]=p;
  const chain=(part)=>{if(part.parent&&byId[part.parent])chain(byId[part.parent]);const pt=pose[part.id]||{},pv=part.pv;cx.translate(pv[0]+(pt.dx||0),pv[1]+(pt.dy||0));cx.rotate(pt.rot||0);cx.scale(pt.sx||1,pt.sy||1);cx.translate(-pv[0],-pv[1])};
  for(const part of R.parts){
    const pt=pose[part.id]||{},pv=part.pv;
    const draw=(extraRot,a,src)=>{
      cx.save();cx.globalAlpha=a;
      if(part.parent&&byId[part.parent])chain(byId[part.parent]);
      cx.translate(pv[0]+(pt.dx||0),pv[1]+(pt.dy||0));cx.rotate((pt.rot||0)+extraRot);cx.scale(pt.sx||1,pt.sy||1);cx.translate(-pv[0],-pv[1]);
      cx.drawImage(src||part.c,0,0);cx.restore();
    };
    if(pt.trail&&part.glowC){
      cx.save();cx.globalCompositeOperation='lighter';
      for(let i=3;i>=1;i--)draw(pt.trail*i*.2,alpha*.22*(4-i)/3,part.glowC);
      cx.restore();
    }
    draw(0,alpha);
    if(o.tint&&o.ta)draw(0,alpha*o.ta,partSil(part,o.tint));
    if(pt.glow&&part.glowC){cx.save();cx.globalCompositeOperation='lighter';draw(0,alpha*.55*pt.glow,part.glowC);cx.restore()}
  }
  cx.restore();return true;
}
/* sprite tanpa rig: potong jadi strip lalu digeser (kain, gerak melata, napas) */
function drawWarp(key,x,y,h,face,sf,g,o){
  const im=IMG[key];if(!im)return;o=o||{};
  const s=h/im.height,W0=im.width,H0=im.height,flip=(sf!==0&&face!==sf)?-1:1,n=o.n||14;
  const passes=[[im,o.alpha==null?1:o.alpha]];
  if(o.tint&&o.ta){const sc=sil(key,o.tint);if(sc)passes.push([sc,(o.alpha==null?1:o.alpha)*o.ta])}
  cx.save();cx.translate(x,y);cx.scale(flip*s*(g.sx||1),s*(g.sy||1));cx.translate(g.dx||0,g.dy||0);
  cx.translate(0,-H0/2);cx.rotate(g.rot||0);cx.translate(-W0/2,-H0/2);
  for(const [src,a] of passes){
    cx.globalAlpha=a;
    if(o.mode==='h'){const sh=H0/n;for(let i=0;i<n;i++){const wgt=o.flat?1:Math.pow(i/(n-1),o.pow||1.15);const off=Math.sin(o.t*o.freq+i*o.ph)*o.amp*wgt;cx.drawImage(src,0,i*sh,W0,sh+.7,off,i*sh,W0,sh+.7)}}
    else{const sw=W0/n;for(let i=0;i<n;i++){const off=Math.sin(o.t*o.freq+i*o.ph)*o.amp;cx.drawImage(src,i*sw,0,sw+.7,H0,i*sw,off,sw+.7,H0)}}
  }
  cx.restore();
}

/* ---------- pose: ayunan senjata (dipakai Slayer, Goblin, Skeleton, Blood Knight) ---------- */
function newPose(){return {g:{},upper:{},lower:{},legL:{},legR:{},sword:{},shield:{}}}
function swingPose(P,cfg,B,ph,q){
  const sw=phi=>(phi-B)*D2R;let phi=B,lean=0,dx=0,crouch=0,legs=0,trail=0,st=0,bash=0;
  if(ph==='wind'){const e=easeIO(q);phi=lerp(B,cfg.w,e);lean=cfg.wl*e;dx=6*e;crouch=(cfg.cr==null?.03:cfg.cr)*e;legs=-.08*e;bash=-.15*e}
  else if(ph==='act'){const e=easeO(q);phi=lerp(cfg.w,cfg.s,e);lean=lerp(cfg.wl,-cfg.sl,e);dx=lerp(6,-cfg.lg,e);crouch=(cfg.cr==null?.03:cfg.cr)*(1-e);legs=lerp(-.08,.22,e);trail=q<1?1:0;st=.05*e;bash=lerp(-.15,-.7,e)}
  else{const e=easeIO((q-.25)/.75);phi=lerp(cfg.s,B,e);lean=lerp(-cfg.sl,0,e);dx=lerp(-cfg.lg,0,e);legs=lerp(.22,0,e);bash=lerp(-.7,0,e)}
  P.g.dx=(P.g.dx||0)+dx;P.g.sy=1-crouch+st;P.upper.rot=(P.upper.rot||0)+lean;P.lower.rot=(P.lower.rot||0)+legs*.5;P.legL.rot=(P.legL.rot||0)+legs*2.2;P.legR.rot=(P.legR.rot||0)-legs*1.5;
  P.sword.rot=sw(phi);P.sword.trail=trail?(cfg.w>cfg.s?1:-1):0;P.sword.glow=trail?1:0;
  if(cfg.tw)P.upper.sx=1-cfg.tw*(ph==='act'?easeO(q):(ph==='wind'?0:1-easeIO(q)));
  if(cfg.bash){P.shield.rot=bash*1.3;P.shield.dx=bash*-26;P.g.dx-=dx*.4}
}
function locoPose(P,t,spd,amp,B,lean){
  const ph=t*spd,s=Math.sin(ph),c=Math.cos(ph);
  P.g.dy=-Math.abs(s)*5*amp;P.upper.rot=-lean+s*.03*amp;P.upper.dy=Math.abs(c)*1.2;P.lower.rot=s*.07*amp;P.lower.sx=1+c*.03*amp;
  P.legL.rot=s*.62*amp;P.legR.rot=-s*.62*amp;P.legL.dy=-Math.max(0,c)*5*amp;P.legR.dy=-Math.max(0,-c)*5*amp;
  P.sword.rot=(30-B)*D2R+Math.sin(ph+1.4)*.32*amp;P.shield.rot=-s*.08*amp;
}
function idlePose(P,t,B){
  const b=Math.sin(t*2.4);P.upper.dy=b*1.6;P.upper.rot=b*.012;P.lower.sx=1+b*.004;P.sword.rot=Math.sin(t*2.4+1.2)*.045;P.shield.rot=Math.sin(t*2.4+.6)*.03;P.g.sy=1+b*.007;
}
/* ---------- Slayer ---------- */
const SL_ATK={
  c0:{w:205,s:45,wl:.15,sl:.30,lg:16,cr:.03},
  c1:{w:-25,s:150,wl:.10,sl:.24,lg:18,cr:.03},
  c2:{w:258,s:55,wl:.20,sl:.36,lg:22,cr:.04,tw:.14},
  c3:{w:228,s:15,wl:.28,sl:.44,lg:24,cr:.09},
  air:{w:195,s:40,wl:.10,sl:.30,lg:8,cr:0},
  heavy:{w:235,s:10,wl:.28,sl:.46,lg:26,cr:.10},
  rising:{w:-55,s:172,wl:.12,sl:.28,lg:10,cr:.09},
  wave:{w:268,s:78,wl:.22,sl:.32,lg:14,cr:.03}
};
function poseSlayer(p){
  const P=newPose(),t=p.anim,B=23,sw=phi=>(phi-B)*D2R;
  switch(p.state){
    case 'idle':idlePose(P,t,B);break;
    case 'run':locoPose(P,t,14,Math.min(1.2,Math.abs(p.vx)/200),B,.12);break;
    case 'jump':{
      if(p.vy<0){P.g.sy=1.05;P.g.sx=.97;P.upper.rot=-.05;P.legL.rot=-.75;P.legR.rot=.35;P.sword.rot=sw(-8)}
      else{P.g.sy=.97;P.g.sx=1.03;P.upper.rot=-.02;P.legL.rot=.55;P.legR.rot=-.45;P.sword.rot=sw(70)}
      break;}
    case 'atk':{
      const d=p.cur,cfg=SL_ATK[p.skill||(p.idx>=0?'c'+p.idx:'air')]||SL_ATK.c0;
      const k=p.stateT/d.dur,w0=d.hit[0]/d.dur,w1=d.hit[1]/d.dur+.04;
      if(k<w0)swingPose(P,cfg,B,'wind',k/w0);
      else if(k<w1)swingPose(P,cfg,B,'act',(k-w0)/(w1-w0));
      else swingPose(P,cfg,B,'rec',(k-w1)/(1-w1));
      if(!p.onGround)P.lower.rot+=-.12;
      break;}
    case 'dash':P.g.sx=1.12;P.g.sy=.9;P.g.dx=-14;P.upper.rot=-.42;P.lower.rot=.1;P.legL.rot=.9;P.legR.rot=-.8;P.sword.rot=sw(-45);P.sword.trail=-1;P.sword.glow=.6;break;
    case 'hurt':{const q=1-clamp(p.stateT/.28,0,1);P.upper.rot=.30*q;P.g.dx=10*q;P.g.sy=1-.06*q;P.lower.rot=-.05*q;P.legL.rot=-.3*q;P.legR.rot=.3*q;P.sword.rot=sw(-30)*q+Math.sin(t*40)*.06*q;break;}
    case 'ult':{
      const k=p.stateT;
      if(k<.55){const q=easeIO(k/.55);P.sword.rot=sw(lerp(B,215,q));P.upper.rot=.2*q;P.g.sy=1-.1*q;P.lower.rot=-.1*q;P.g.dy=-Math.sin(q*3.14)*6;P.sword.glow=q}
      else{const q=easeO((k-.55)/.25),r=easeIO((k-.8)/.4);P.sword.rot=sw(lerp(215,5,q)+ (0-0)*r);P.upper.rot=lerp(.2,-.5,q)*(1-r);P.g.dx=-30*q*(1-r);P.g.sy=1+.05*q;P.sword.trail=1;P.sword.glow=1-r*.6;P.lower.rot=.25*q*(1-r)}
      break;}
    case 'dead':{const q=easeO(p.stateT/.5);P.g.rot=Math.min(1.4,q*1.4);P.g.dy=Math.min(60,p.stateT*100);P.upper.rot=.3*q;P.sword.rot=sw(80)*q;P.lower.rot=-.15*q;P.legL.rot=-.5*q;P.legR.rot=.4*q;break;}
  }
  return P;
}
/* ---------- musuh humanoid ---------- */
const EN_ATK={
  'goblin.slash':{w:-30,s:108,wl:.12,sl:.28,lg:16},
  'goblin.bash':{w:46,s:46,wl:.14,sl:.40,lg:26,bash:1,cr:.05},
  'skeleton.slash':{w:218,s:38,wl:.14,sl:.30,lg:14},
  'skeleton.bone':{w:205,s:80,wl:.18,sl:.16,lg:4,cr:.02},
  'blood.slash':{w:240,s:12,wl:.20,sl:.42,lg:28,cr:.06},
  'blood.charge':{w:100,s:100,wl:.08,sl:.42,lg:0,cr:.04},
  'blood.slam':{w:258,s:0,wl:.26,sl:.46,lg:12,cr:.09},
  'blood.wave':{w:205,s:50,wl:.14,sl:.30,lg:12},
  'blood.spin':{w:95,s:95,wl:0,sl:0,lg:0}
};
const EN_LOCO={goblin:[9,1,.10],skeleton:[8,1,.08],blood:[5.5,.9,.10]};
function poseHumanoid(e){
  const d=e.def,P=newPose(),B=RIGDEF[d.spr].B,t=e.anim,sw=phi=>(phi-B)*D2R;
  if(e.dead){const q=easeO(e.deathT/.5);P.g.rot=Math.min(1.45,q*1.45);P.g.dy=Math.min(40,e.deathT*60);P.upper.rot=.3*q;P.sword.rot=sw(B+70)*q;P.lower.rot=-.3*q;P.shield.rot=.6*q;return P}
  if(e.hitT>0){
    const q=clamp(e.hitT/.28,0,1);P.upper.rot=.32*q;P.g.dx=9*q;P.g.sy=1-.07*q;P.lower.rot=-.12*q;P.sword.rot=Math.sin(t*38)*.08*q;P.shield.rot=Math.sin(t*33)*.1*q;
    return P;
  }
  const a=e.curAtk,lo=EN_LOCO[d.spr]||[8,1,.08];
  if(e.state==='wind'&&a){swingPose(P,EN_ATK[d.spr+'.'+a.id]||{w:B+70,s:B-20,wl:.1,sl:.2,lg:10},B,'wind',clamp(e.t/Math.max(.05,e.windT),0,1));return P}
  if(e.state==='act'&&a){
    const cfg=EN_ATK[d.spr+'.'+a.id]||{w:B+70,s:B-20,wl:.1,sl:.2,lg:10};
    const dur=a.kind==='melee'?Math.min(a.act,.16):Math.max(.2,a.act||.2);
    swingPose(P,cfg,B,'act',clamp(e.t/dur,0,1));
    if(a.kind==='spin'){P.sword.rot=sw(95)+Math.sin(e.t*30)*.15;P.sword.trail=1;P.sword.glow=1;P.g.sx=Math.cos(e.t*22)}
    if(a.kind==='charge'){P.g.sx=1.06;P.g.sy=.96;P.lower.rot=.3;P.sword.trail=1}
    return P;
  }
  if(e.state==='rec'&&a){const kk=d.boss&&e.phase===2?.78:1;swingPose(P,EN_ATK[d.spr+'.'+a.id]||{w:B+70,s:B-20,wl:.1,sl:.2,lg:10},B,'rec',clamp(e.t/Math.max(.05,a.rec*kk),0,1));return P}
  if(e.state==='phase'){const q=Math.sin(t*50);P.g.dx=q*3;P.upper.rot=-.05+q*.02;P.sword.rot=sw(200)+q*.05;P.g.sy=1+Math.sin(t*8)*.02;return P}
  if(Math.abs(e.vx)>8)locoPose(P,t,lo[0],lo[1],B,lo[2]);else idlePose(P,t,B);
  return P;
}
/* ---------- gargoyle ---------- */
function poseGargoyle(e){
  const P={g:{},body:{},wl:{},wr:{}},t=e.anim;
  if(e.dead){P.g.rot=Math.min(1.3,e.deathT*3);P.wl.rot=-.5;P.wr.rot=.5;return P}
  let f=Math.sin(t*7);let flap=.5,lift=1;
  if(e.hitT>0){const q=clamp(e.hitT/.28,0,1);P.g.dx=-9*q;P.g.sy=1-.07*q;P.g.rot=-.12*q;f=Math.sin(t*38)*q}
  const a=e.curAtk;
  if(e.state==='wind'&&a){const q=easeIO(e.t/Math.max(.05,e.windT));P.wl.rot=.75*q;P.wr.rot=-.75*q;P.g.sy=1-.05*q;P.g.rot=-.14*q;P.g.dx=-6*q;return P}
  if(e.state==='act'&&a){
    const q=easeO(e.t/Math.max(.15,Math.min(a.act||.3,.4)));
    P.wl.rot=lerp(.75,-.55,q);P.wr.rot=lerp(-.75,.55,q);P.g.dx=12*q;P.g.rot=.2*q;P.g.sx=1+.06*q;
    if(a.kind==='dive'){P.wl.rot=-.9;P.wr.rot=.9;P.g.rot=.5;P.g.sy=1.08}
    return P;
  }
  P.wl.rot=f*.5*flap+.15;P.wr.rot=-f*.5*flap-.15;P.g.dy=-f*3.5;P.g.rot=Math.sin(t*3)*.03;
  return P;
}
/* ---------- warp: wolf, spider, cultist, wraith ---------- */
function warpFor(e){
  const d=e.def,t=e.anim,fw=d.sf===1?1:-1,g={},o={t,alpha:1};
  const a=e.curAtk,moving=e.state==='move'&&Math.abs(e.vx)>8;
  const recoil=e.hitT>0?clamp(e.hitT/.28,0,1):0;
  if(d.spr==='wolf'){
    o.mode='v';o.n=18;o.ph=-.5;o.freq=moving?18:3;o.amp=moving?3.6:1.1;
    if(moving){g.dy=-Math.abs(Math.sin(t*18))*3.5;g.sy=1+Math.sin(t*36)*.04;g.rot=fw*.05*Math.sin(t*18)}
    else g.sy=1+Math.sin(t*3)*.02;
  }else if(d.spr==='spider'){
    o.mode='v';o.n=16;o.ph=1.7;o.freq=moving?34:6;o.amp=moving?2.8:.9;
    if(moving)g.dy=-Math.abs(Math.sin(t*15))*2.5;g.sy=(g.sy||1)+Math.sin(t*3)*.015;
  }else if(d.spr==='wraith'){
    o.mode='h';o.n=16;o.ph=.55;o.freq=4.5;o.amp=5.5;g.dy=Math.sin(t*2)*4;g.rot=fw*Math.sin(t*1.5)*.04;
    o.alpha=.9+.1*Math.sin(t*9);if(moving)g.rot+=fw*.08;
  }else{ // cultist
    o.mode='h';o.n=14;o.ph=.6;o.freq=moving?7:3;o.amp=moving?3.2:2;g.sy=1+Math.sin(t*2.4)*.012;
  }
  if(e.dead){g.rot=-fw*Math.min(1.45,e.deathT*3.4);o.amp*=.4}
  else if(recoil){g.dx=-fw*10*recoil;g.sy=(g.sy||1)*(1-.08*recoil);g.rot=(g.rot||0)-fw*.14*recoil;o.amp=(o.amp||2)+5*recoil}
  else if(e.state==='wind'&&a){
    const q=easeIO(e.t/Math.max(.05,e.windT));
    if(a.kind==='melee'){g.dx=-fw*8*q;g.rot=-fw*.20*q;g.sy=(g.sy||1)*(1-.06*q);g.sx=1+.04*q}
    else if(a.kind==='charge'||a.kind==='leap'){g.sy=(g.sy||1)*(1-.18*q);g.sx=1+.12*q;g.dx=-fw*10*q;g.rot=-fw*.14*q}
    else{g.sy=(g.sy||1)*(1+.06*q);g.rot=-fw*.16*q;g.dx=-fw*6*q}   // cast: badan naik/mundur
    o.amp=(o.amp||2)+2*q;
  }else if(e.state==='act'&&a){
    const q=easeO(e.t/Math.max(.14,Math.min(a.act||.3,.4)));
    if(a.kind==='melee'){g.dx=fw*22*(1-q*.4);g.rot=fw*.2*(1-q);g.sx=1.10}
    else if(a.kind==='charge'){g.sx=1.2;g.sy=.9;g.rot=fw*.1;o.amp=5;g.dx=fw*6}
    else if(a.kind==='leap'){if(e.vy<0){g.sy=1.13;g.sx=.9;g.rot=fw*-.22}else{g.sy=.92;g.sx=1.08;g.rot=fw*.24}}
    else{g.dx=fw*10*(1-q);g.sy=(g.sy||1)*(1+.04*(1-q));g.rot=fw*.1*(1-q)}
  }else if(e.state==='rec'&&a){
    const q=clamp(e.t/Math.max(.1,a.rec),0,1);g.dx=fw*8*(1-q);g.sy=(g.sy||1)*(1-.05*(1-q))
  }
  return [g,o];
}

/* =====================================================================
   ANIMASI FRAME — sprite sheet Slayer: Run(12) · Dash(16) · Attack 1(6) · Attack 2(6)
   Semua frame menghadap KANAN. Anchor = tengah kaki (dasar sepatu).
   Tambah animasi baru: taruh frame di assets/frames, daftarkan di ANIM + tabel urutan.
   ===================================================================== */
const GS=.80;                              // skala dasar frame -> layar
const ANIM={run:{pre:'run_',k:.9375},dash:{pre:'dash_',k:1.22},atk1:{pre:'atk1_',k:1},atk2:{pre:'atk2_',k:1}};
const fkey=(a,i)=>ANIM[a].pre+String(i).padStart(2,'0');
function framesReady(){return !!(FRAMEMETA&&FRAMEMETA.run_01&&IMG.run_01&&IMG.atk1_01&&IMG.atk2_01&&IMG.dash_01)}
function drawFrame(a,i,x,y,face,o){
  o=o||{};const key=fkey(a,i),im=IMG[key],m=FRAMEMETA[key];if(!im||!m)return;
  const s=GS*ANIM[a].k*(o.sc||1),al=o.alpha==null?1:o.alpha;
  cx.save();cx.translate(x+(o.dx||0),y+(o.dy||0));if(o.rot)cx.rotate(o.rot);
  cx.scale(face*s*(o.sx||1),s*(o.sy||1));cx.globalAlpha=al;
  cx.drawImage(im,-m.ax,-m.ay);
  if(o.tint){const sc=sil(key,o.tint);if(sc){cx.globalAlpha=al*(o.ta||.6);cx.drawImage(sc,-m.ax,-m.ay)}}
  cx.restore();
}
/* urutan frame tiap serangan: [anim, frame-windup[], frame-tebas[], frame-pemulihan[], skala] */
const SL_SEQ={
  c0:['atk1',[2],[3,4],[5,6],1],
  c1:['atk2',[2],[3,4],[5,6],1],
  c2:['atk1',[2],[3,4],[5,6],1.06],
  c3:['atk2',[2],[3,4],[5,6],1.12],
  air:['atk2',[3],[4],[5],1],
  heavy:['atk2',[2],[3,4],[5,6],1.12],
  rising:['atk2',[2],[3,4],[5],1.05],
  wave:['atk1',[2],[3,4],[5,6],1]
};
const pickF=(l,q)=>l[Math.min(l.length-1,Math.floor(clamp(q,0,.999)*l.length))];
function slayerFrame(p){
  const t=p.anim,o={};let a='atk1',i=1;
  switch(p.state){
    case 'idle':o.sy=1+Math.sin(t*2.6)*.012;o.sx=1-Math.sin(t*2.6)*.006;break;
    case 'run':{a='run';const fps=15*clamp(Math.abs(p.vx)/235,.6,1.3);i=1+Math.floor(t*fps)%12;break}
    case 'jump':a='run';i=p.vy<0?5:6;o.sy=p.vy<0?1.04:.98;break;
    case 'atk':{
      const d=p.cur,sq=SL_SEQ[p.skill||(p.idx>=0?'c'+p.idx:'air')]||SL_SEQ.c0;
      const k=p.stateT/d.dur,w0=d.hit[0]/d.dur,w1=d.hit[1]/d.dur+.04;
      a=sq[0];o.sc=sq[4];
      if(k<w0)i=pickF(sq[1],k/w0);
      else if(k<w1){i=pickF(sq[2],(k-w0)/(w1-w0));o.sx=1.03}
      else i=pickF(sq[3],(k-w1)/(1-w1));
      break;}
    case 'dash':{
      a='dash';
      if(p.dashT>0)i=1+Math.floor(clamp(p.stateT/.24,0,.999)*9);           // frame 1-9: jongkok -> melesat -> memudar
      else i=10+Math.floor(clamp((p.stateT-.24)/.14,0,.999)*4);            // frame 10-13: mendarat
      break;}
    case 'hurt':{a='dash';i=12;const q=1-clamp(p.stateT/.28,0,1);o.dx=-p.face*10*q;o.sy=1-.05*q;break}
    case 'ult':{
      a='atk2';const k=p.stateT;o.sc=1.12;
      i=k<.55?2:k<.7?3:k<.85?4:k<1.0?5:6;
      if(k<.55){o.sy=1-.03*(k/.55)}
      break;}
    case 'dead':{a='dash';i=13;const q=easeO(p.stateT/.5);o.rot=-p.face*q*1.45;o.dy=Math.min(8,p.stateT*30);break}
  }
  return {a,i,o};
}
