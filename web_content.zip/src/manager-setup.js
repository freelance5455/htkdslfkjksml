export const MANAGER_AVATARS = Object.freeze([
  { id: 'strategist', label: 'Stratège', symbol: '♟️' },
  { id: 'captain', label: 'Leader', symbol: '🛡️' },
  { id: 'visionary', label: 'Visionnaire', symbol: '🌌' },
  { id: 'analyst', label: 'Analyste', symbol: '📊' },
  { id: 'mentor', label: 'Formateur', symbol: '🎓' },
  { id: 'champion', label: 'Champion', symbol: '🏆' }
]);
export const MANAGER_EXPERIENCES = Object.freeze([
  { id: 'debutant', label: 'Débutant', description: 'Découvre les exigences du management.' },
  { id: 'amateur', label: 'Amateur', description: 'Quelques expériences dans des équipes locales.' },
  { id: 'confirme', label: 'Confirmé', description: 'A déjà dirigé un groupe compétitif.' },
  { id: 'professionnel', label: 'Professionnel', description: 'Habitué aux exigences du haut niveau.' },
  { id: 'legende', label: 'Légende', description: 'Une réputation déjà reconnue dans l’univers des dames.' }
]);
export const MANAGER_PROFILES = Object.freeze([
  { id: 'tacticien', label: 'Tacticien', description: 'Analyse, stratégie et préparation des rencontres.' },
  { id: 'formateur', label: 'Formateur', description: 'Progression, développement et académie.' },
  { id: 'meneur', label: 'Meneur d’hommes', description: 'Motivation, cohésion et gestion du vestiaire.' },
  { id: 'gestionnaire', label: 'Gestionnaire', description: 'Organisation, finances et stabilité du club.' }
]);
export const MANAGER_NATIONALITIES = Object.freeze([
  'Terra Unie','Mars Fédérale','Vénus Impériale','Mercure Solaire','Jupiter Majeure','Saturne des Anneaux',
  'Neptune Abyssale','Uranus Glaciale','Pluton Lointaine','Lune Argentée','Andromède Unie','Orion Suprême',
  'Sirius Doré','Proxima Libre','Kepler Républicaine','Nébuleuse du Crabe','Cassiopée Royale','Pégase Céleste',
  'Centaure Alpha','Lyra Harmonieuse','Vega Éternelle','Solarys Impériale','Éclipse Noire','Astra Nova'
]);
const clean = value => String(value ?? '').trim();
export function validateManagerDraft(input) {
  const draft = {
    firstName: clean(input?.firstName), lastName: clean(input?.lastName), avatar: clean(input?.avatar),
    nationality: clean(input?.nationality), sex: clean(input?.sex), experience: clean(input?.experience), profile: clean(input?.profile)
  };
  if (!draft.firstName || !draft.lastName) throw new Error('Renseigne le prénom et le nom du manager.');
  if (draft.firstName.length > 32 || draft.lastName.length > 32) throw new Error('Le prénom et le nom sont limités à 32 caractères.');
  if (!MANAGER_AVATARS.some(item => item.id === draft.avatar)) throw new Error('Choisis un avatar parmi les modèles proposés.');
  if (!MANAGER_NATIONALITIES.includes(draft.nationality)) throw new Error('Choisis une origine galactique dans la liste.');
  if (!['Femme','Homme','Non précisé'].includes(draft.sex)) throw new Error('Choisis un profil valide.');
  if (!MANAGER_EXPERIENCES.some(item => item.id === draft.experience)) throw new Error('Choisis un niveau d’expérience.');
  if (!MANAGER_PROFILES.some(item => item.id === draft.profile)) throw new Error('Choisis un profil de manager.');
  return draft;
}
export function saveManagerDraft(state, input) {
  if (!state || !state.career) throw new Error('La carrière ne peut pas recevoir ce profil.');
  const draft = validateManagerDraft(input);
  state.career.managerDraft = { ...draft, displayName: `${draft.firstName} ${draft.lastName}`, savedAt: new Date().toISOString() };
  return structuredClone(state.career.managerDraft);
}
