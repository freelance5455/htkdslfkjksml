import React, {useEffect, useState} from "react";
import {createRoot} from "react-dom/client";
import {LockKeyhole, Plus, Eye, EyeOff, Trash2, LogOut, ShieldCheck, Search, KeyRound} from "lucide-react";
import "./styles.css";

const KEY="privatevault_data_v1";

function App(){
  const [password,setPassword]=useState("");
  const [confirm,setConfirm]=useState("");
  const [unlocked,setUnlocked]=useState(false);
  const [hasVault,setHasVault]=useState(!!localStorage.getItem(KEY));
  const [showPass,setShowPass]=useState(false);
  const [items,setItems]=useState([]);
  const [title,setTitle]=useState("");
  const [secret,setSecret]=useState("");
  const [query,setQuery]=useState("");
  const [error,setError]=useState("");
  const [busy,setBusy]=useState(false);

  useEffect(()=>{ document.title="PrivateVault"; },[]);

  async function deriveKey(pass,salt){
    const enc=new TextEncoder();
    const base=await crypto.subtle.importKey("raw",enc.encode(pass),"PBKDF2",false,["deriveKey"]);
    return crypto.subtle.deriveKey({name:"PBKDF2",salt,iterations:250000,hash:"SHA-256"},base,{name:"AES-GCM",length:256},false,["encrypt","decrypt"]);
  }
  function b64(buf){return btoa(String.fromCharCode(...new Uint8Array(buf)))}
  function unb64(s){return Uint8Array.from(atob(s),c=>c.charCodeAt(0))}
  async function encrypt(data,pass,salt){
    const key=await deriveKey(pass,salt); const iv=crypto.getRandomValues(new Uint8Array(12));
    const ct=await crypto.subtle.encrypt({name:"AES-GCM",iv},key,new TextEncoder().encode(JSON.stringify(data)));
    return {salt:b64(salt),iv:b64(iv),data:b64(ct)};
  }
  async function decrypt(record,pass){
    const salt=unb64(record.salt),iv=unb64(record.iv),data=unb64(record.data);
    const key=await deriveKey(pass,salt);
    const pt=await crypto.subtle.decrypt({name:"AES-GCM",iv},key,data);
    return JSON.parse(new TextDecoder().decode(pt));
  }
  async function setup(){
    setError("");
    const pw=window.__pvPassword ?? password; const cf=window.__pvConfirm ?? confirm;
    if(pw.length<6){setError("Password kam az kam 6 characters ka hona chahiye.");return}
    if(pw!==cf){setError("Passwords match nahi karte.");return}
    setBusy(true);
    try{
      const salt=crypto.getRandomValues(new Uint8Array(16));
      localStorage.setItem(KEY,JSON.stringify(await encrypt([],pw,salt)));
      setHasVault(true);setUnlocked(true);setItems([]);
    }catch(e){setError("Vault create nahi ho saka.")}
    setBusy(false);
  }
  async function unlock(){
    setError("");setBusy(true);
    try{
      const pw=window.__pvPassword ?? password;
      const rec=JSON.parse(localStorage.getItem(KEY));
      const data=await decrypt(rec,pw);
      setItems(data);setUnlocked(true);passwordForSave.current=pw;setPassword("");
    }catch(e){setError("Wrong password ya vault data invalid hai.")}
    setBusy(false);
  }
  async function save(newItems=items){
    const rec=JSON.parse(localStorage.getItem(KEY));
    const salt=unb64(rec.salt);
    localStorage.setItem(KEY,JSON.stringify(await encrypt(newItems,passwordForSave.current,salt)));
  }
  const passwordForSave=React.useRef("");
  useEffect(()=>{if(unlocked && (password || window.__pvPassword)) passwordForSave.current=password || window.__pvPassword},[password,unlocked]);

  async function addItem(){
    if(!title.trim()||!secret.trim())return;
    const next=[{id:Date.now(),title:title.trim(),secret:secret.trim()},...items];
    try{
      const rec=JSON.parse(localStorage.getItem(KEY));
      const salt=unb64(rec.salt);
      localStorage.setItem(KEY,JSON.stringify(await encrypt(next,passwordForSave.current,salt)));
      setItems(next);setTitle("");setSecret("");
    }catch(e){setError("Save nahi ho saka.")}
  }
  async function removeItem(id){
    const next=items.filter(x=>x.id!==id);
    const rec=JSON.parse(localStorage.getItem(KEY)); const salt=unb64(rec.salt);
    localStorage.setItem(KEY,JSON.stringify(await encrypt(next,passwordForSave.current,salt)));
    setItems(next);
  }
  function logout(){setUnlocked(false);setItems([]);setPassword("");setError("")}
  const filtered=items.filter(x=>x.title.toLowerCase().includes(query.toLowerCase()));

  if(!hasVault) return <Auth title="Create your PrivateVault" action={setup} button="Create Vault" showConfirm />;
  if(!unlocked) return <Auth title="Unlock PrivateVault" action={unlock} button="Unlock Vault" />;

  return <main className="app">
    <header className="top">
      <div className="brand"><div className="logo"><LockKeyhole size={25}/></div><div><b>PrivateVault</b><small>Your private space</small></div></div>
      <button className="iconBtn" onClick={logout} title="Lock"><LogOut size={19}/></button>
    </header>

    <section className="hero">
      <div><ShieldCheck size={20}/><span>Encrypted local vault</span></div>
      <p>Your vault data is encrypted in this browser using AES-GCM.</p>
    </section>

    <section className="card">
      <h2><Plus size={20}/> Add Secret</h2>
      <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title (e.g. Wi-Fi)" />
      <textarea value={secret} onChange={e=>setSecret(e.target.value)} placeholder="Secret / note" rows="3" />
      <button className="primary" onClick={addItem}>Save Secret</button>
    </section>

    <section className="listHead">
      <h2>My Secrets <span>{items.length}</span></h2>
      <div className="search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search..." /></div>
    </section>

    <section className="items">
      {filtered.length===0 && <div className="empty"><KeyRound size={32}/><p>{items.length?"No matching secrets":"No secrets yet."}</p></div>}
      {filtered.map(item=><SecretCard key={item.id} item={item} onDelete={()=>removeItem(item.id)}/>)}
    </section>
  </main>
}

function SecretCard({item,onDelete}){
  const [show,setShow]=useState(false);
  return <div className="secretCard">
    <div className="secretTop"><div className="miniLogo"><LockKeyhole size={17}/></div><strong>{item.title}</strong><button className="iconBtn danger" onClick={onDelete}><Trash2 size={17}/></button></div>
    <div className="secretValue">{show?item.secret:"••••••••••••"}<button className="iconBtn" onClick={()=>setShow(!show)}>{show?<EyeOff size={17}/>:<Eye size={17}/>}</button></div>
  </div>
}

function Auth({title,action,button,showConfirm}){
  const [p,setP]=useState(""); const [c,setC]=useState(""); const [show,setShow]=useState(false); const [err,setErr]=useState("");
  async function go(){
    if(p.length<6){setErr("Password kam az kam 6 characters ka hona chahiye.");return}
    if(showConfirm&&p!==c){setErr("Passwords match nahi karte.");return}
    // Bridge values into the action expected by the parent through temporary globals.
    window.__pvPassword=p; window.__pvConfirm=c;
    await action();
  }
  return <main className="auth">
    <div className="authBox">
      <div className="bigLogo"><LockKeyhole size={40}/></div>
      <h1>{title}</h1><p className="muted">{showConfirm?"Create a strong password to protect your vault.":"Enter your password to continue."}</p>
      <div className="passwordWrap"><input type={show?"text":"password"} value={p} onChange={e=>{setP(e.target.value);window.__pvPassword=e.target.value}} placeholder="Password" autoFocus/><button onClick={()=>setShow(!show)}>{show?<EyeOff size={19}/>:<Eye size={19}/>}</button></div>
      {showConfirm&&<input type={show?"text":"password"} value={c} onChange={e=>{setC(e.target.value);window.__pvConfirm=e.target.value}} placeholder="Confirm password"/>}
      {err&&<div className="error">{err}</div>}
      <button className="primary wide" onClick={go}>{button}</button>
      <small className="security"><ShieldCheck size={15}/> Data stays on this device/browser.</small>
    </div>
  </main>
}
const root=createRoot(document.getElementById("root"));
root.render(<App/>);