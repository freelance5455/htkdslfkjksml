import React, {useEffect, useRef, useState} from 'react';
import {createRoot} from 'react-dom/client';
import './style.css';

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

function App(){
  const [active,setActive]=useState(false);
  const [status,setStatus]=useState('اضغط تشغيل وقل: توبة');
  const [heard,setHeard]=useState('');
  const recRef=useRef(null);

  const speak=(text)=>{
    if('speechSynthesis' in window){
      window.speechSynthesis.cancel();
      const u=new SpeechSynthesisUtterance(text);
      u.lang='ar-EG'; u.rate=0.95;
      window.speechSynthesis.speak(u);
    }
  };

  const start=()=>{
    if(!SpeechRecognition){
      setStatus('التعرف على الصوت غير مدعوم في هذا المتصفح.');
      return;
    }
    const r=new SpeechRecognition();
    r.lang='ar-EG';
    r.continuous=true;
    r.interimResults=true;
    r.onstart=()=>{setActive(true);setStatus('سامعك... قل «توبة»');};
    r.onerror=(e)=>setStatus('مشكلة في الميكروفون: '+e.error);
    r.onend=()=>{
      if(active){
        try{r.start();}catch{}
      }
    };
    r.onresult=(event)=>{
      let text='';
      for(let i=event.resultIndex;i<event.results.length;i++) text+=event.results[i][0].transcript+' ';
      text=text.trim();
      if(!text)return;
      setHeard(text);
      if(/توبة|توبا|توبه|توبى/i.test(text)){
        setStatus('سمعتك ❤️');
        speak('أيوه، معاك');
        setTimeout(()=>setStatus('قول الأمر اللي عايزه...'),900);
      }
    };
    recRef.current=r;
    try{r.start();}catch{}
  };

  const stop=()=>{
    setActive(false);
    if(recRef.current){try{recRef.current.stop();}catch{}}
    setStatus('متوقف');
  };

  return <main>
    <div className="orb">ت</div>
    <h1>توبة</h1>
    <p className="sub">مساعدك الصوتي الشخصي</p>
    <div className={"status "+(active?'on':'')}>{status}</div>
    <button onClick={active?stop:start}>{active?'إيقاف الاستماع':'تشغيل توبة'}</button>
    <div className="heard"><span>آخر كلام سمعته</span><strong>{heard||'—'}</strong></div>
    <p className="note">النسخة الأولى للتجربة الصوتية. خلي الصفحة مفتوحة أثناء الاستماع.</p>
  </main>
}

createRoot(document.getElementById('root')).render(<App/>);
