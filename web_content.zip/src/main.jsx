
import React,{useEffect,useRef,useState} from 'react'
import {createRoot} from 'react-dom/client'
import {Home,MessageCircle,Users,User,Phone,Video,Mic,MicOff,Plus,Search,Settings,LogOut,UserPlus,Check,X,Radio,Send,Paperclip,Image as ImageIcon,Volume2,VideoIcon,Shield,Edit3,ArrowLeft} from 'lucide-react'
import './styles.css'

const theme='/danger-theme.png'
const initialUsers=[
 {id:1,name:'Ali Khan',status:'Online',img:theme,request:false},
 {id:2,name:'Ahmed',status:'Last seen recently',img:theme,request:true},
 {id:3,name:'Hamza',status:'Online',img:theme,request:true},
 {id:4,name:'Usman',status:'Offline',img:theme,request:false}
]
const initialChats=[{id:1,name:'Ahmed',img:theme,messages:[{from:'them',text:'Welcome to Danger Chat 👋'},{from:'me',text:'Hello!'}]}]

function App(){
 const [user,setUser]=useState(()=>JSON.parse(localStorage.getItem('dc_user')||'null'))
 const [tab,setTab]=useState('home')
 const [users,setUsers]=useState(initialUsers)
 const [chats,setChats]=useState(initialChats)
 const [active,setActive]=useState(null)
 const [room,setRoom]=useState(null)
 const [mic,setMic]=useState(false)
 const [stream,setStream]=useState(null)
 const [recording,setRecording]=useState(false)
 const rec=useRef(null),chunks=useRef([])

 const login=()=>{const u={name:'Danger User',email:'user@gmail.com',img:theme};setUser(u);localStorage.setItem('dc_user',JSON.stringify(u))}
 const logout=()=>{setUser(null);localStorage.removeItem('dc_user')}
 const startMic=async()=>{try{const s=await navigator.mediaDevices.getUserMedia({audio:true});setStream(s);setMic(true)}catch(e){alert('Microphone permission required.')}}
 const stopMic=()=>{stream?.getTracks().forEach(t=>t.stop());setStream(null);setMic(false)}
 useEffect(()=>()=>stopMic(),[])
 if(!user)return <Login login={login}/>

 const send=(text)=>{
  if(!text.trim()||!active)return
  setChats(cs=>cs.map(c=>c.id===active.id?{...c,messages:[...c.messages,{from:'me',text}]}:c))
 }
 return <div className="app">
  <header className="top"><div className="brand">DANGER <span>CHAT</span></div><img className="avatar" src={user.img}/></header>
  <main className="wrap">
   {tab==='home'&&<HomePage setTab={setTab} setActive={setActive}/>}
   {tab==='chats'&&<Chats chats={chats} setActive={setActive} setTab={setTab}/>}
   {tab==='friends'&&<Friends users={users} setUsers={setUsers}/>}
   {tab==='profile'&&<Profile user={user} setUser={setUser}/>}
   {tab==='rooms'&&<Rooms room={room} setRoom={setRoom} mic={mic} startMic={startMic} stopMic={stopMic}/>}
   {tab==='calls'&&<Calls/>}
   {active&&tab==='chat'&&<Chat chat={chats.find(c=>c.id===active.id)} send={send} go={()=>{setActive(null);setTab('chats')}}/>}
  </main>
  {tab!=='chat'&&!active&&<nav className="bottom">
   <Nav active={tab==='home'} onClick={()=>setTab('home')} icon={<Home/>} t="Home"/>
   <Nav active={tab==='chats'} onClick={()=>setTab('chats')} icon={<MessageCircle/>} t="Chats"/>
   <Nav active={tab==='rooms'} onClick={()=>setTab('rooms')} icon={<Radio/>} t="Rooms"/>
   <Nav active={tab==='friends'} onClick={()=>setTab('friends')} icon={<Users/>} t="Friends"/>
   <Nav active={tab==='profile'} onClick={()=>setTab('profile')} icon={<User/>} t="Profile"/>
  </nav>}
 </div>
}

const Nav=({active,onClick,icon,t})=><button className={'nav '+(active?'active':'')} onClick={onClick}>{React.cloneElement(icon,{size:19})}{t}</button>

function Login({login}){return <div className="app"><main className="wrap"><section className="hero"><img src={theme}/><div className="heroText"><h1>DANGER <span className="red">CHAT</span></h1><p>Chat • Rooms • Voice • Video</p><button className="primary" onClick={login}>Continue with Google</button></div></section><div className="panel"><b>Gmail login</b><p className="muted">This starter build uses a demo login so you can test the interface immediately. Real Google authentication needs your Firebase/Google OAuth configuration.</p></div></main></div>}

function HomePage({setTab,setActive}){return <><section className="hero"><img src={theme}/><div className="heroText"><h1>Danger <span className="red">Chat</span></h1><p>Your community. Your voice. Your rooms.</p></div></section><div className="grid">
 <Tile icon={<MessageCircle/>} t="Private Chat" s="1-to-1 messages" on={()=>setTab('chats')}/>
 <Tile icon={<Radio/>} t="Voice Chat Rooms" s="Join live rooms" on={()=>setTab('rooms')}/>
 <Tile icon={<Phone/>} t="Voice Call" s="Call friends" on={()=>setTab('calls')}/>
 <Tile icon={<Video/>} t="Video Call" s="Video calling" on={()=>setTab('calls')}/>
 <Tile icon={<UserPlus/>} t="Add Friends" s="Requests & accepts" on={()=>setTab('friends')}/>
 <Tile icon={<User/>} t="My Profile" s="Name & DP" on={()=>setTab('profile')}/>
 </div><div className="notice">🔒 For production: connect Firebase Auth, Firestore, Storage, FCM and a WebRTC signaling service to make accounts, real-time chat, calls and notifications fully live.</div></>}

const Tile=({icon,t,s,on})=><button className="tile" onClick={on}><div className="ic">{icon}</div><b>{t}</b><small>{s}</small></button>

function Chats({chats,setActive,setTab}){return <section className="panel"><div className="row"><h2>Private Chats</h2><button className="secondary" onClick={()=>setTab('friends')}><Plus size={17}/> New</button></div><div className="list">{chats.map(c=><button className="item" key={c.id} onClick={()=>{setActive(c);setTab('chat')}}><img className="avatar" src={c.img}/><div className="grow"><b>{c.name}</b><div className="muted">{c.messages.at(-1)?.text}</div></div><MessageCircle size={18}/></button>)}</div></section>}

function Chat({chat,send,go}){const [text,setText]=useState('');return <section className="panel"><div className="row"><button className="secondary" onClick={go}><ArrowLeft size={17}/></button><img className="avatar" src={chat.img}/><h2>{chat.name}</h2><button className="secondary"><Phone size={17}/></button><button className="secondary"><Video size={17}/></button></div><div className="chat">{chat.messages.map((m,i)=><div key={i} className={'bubble '+(m.from==='me'?'me':'')}>{m.text}</div>)}</div><div className="compose"><button className="secondary"><Paperclip size={18}/></button><input className="input" value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>e.key==='Enter'&&(send(text),setText(''))} placeholder="Write a message..."/><button className="primary" onClick={()=>{send(text);setText('')}}><Send size={18}/></button></div></section>}

function Friends({users,setUsers}){const [q,setQ]=useState('');return <section className="panel"><h2>Friends & Requests</h2><input className="input" placeholder="Search users..." value={q} onChange={e=>setQ(e.target.value)}/><div className="tabs"><button className="tab active">People</button><button className="tab">Requests</button></div><div className="list">{users.filter(u=>u.name.toLowerCase().includes(q.toLowerCase())).map(u=><div className="item" key={u.id}><img className="avatar" src={u.img}/><div className="grow"><b>{u.name}</b><div className="muted">{u.status}</div></div>{u.request?<><button className="primary" onClick={()=>setUsers(us=>us.map(x=>x.id===u.id?{...x,request:false}:x))}><Check size={17}/></button><button className="danger"><X size={17}/></button></>:<button className="secondary"><UserPlus size={17}/> Add</button>}</div>)}</div></section>}

function Profile({user,setUser}){const [name,setName]=useState(user.name);const save=()=>{const u={...user,name};setUser(u);localStorage.setItem('dc_user',JSON.stringify(u));alert('Profile updated')};return <section className="panel"><h2>My Profile</h2><div className="profile"><img src={user.img}/><div><b>{user.name}</b><div className="muted">{user.email}</div></div></div><label>Name</label><input className="input" value={name} onChange={e=>setName(e.target.value)}/><div className="row" style={{marginTop:10}}><button className="primary" onClick={save}><Edit3 size={16}/> Save Name</button><button className="secondary" onClick={()=>alert('In the production version, choose an image from your phone.') }><ImageIcon size={16}/> Change DP</button></div><div className="notice">Google login, real profile photo upload and cloud profile sync need Firebase configuration.</div></section>}

function Rooms({room,setRoom,mic,startMic,stopMic}){const [rooms]=useState([{id:1,name:'Chill & Talk',users:12},{id:2,name:'Music Lounge',users:28},{id:3,name:'Gaming Room',users:7}]);if(!room)return <section className="panel"><div className="row"><h2>Voice Chat Rooms</h2><button className="primary" onClick={()=>setRoom({id:99,name:'My Room',users:1})}><Plus size={17}/> Create</button></div><div className="list">{rooms.map(r=><button className="item" key={r.id} onClick={()=>setRoom(r)}><div className="ic"><Radio size={19}/></div><div className="grow"><b>{r.name}</b><div className="muted">{r.users} people live</div></div><Radio size={18}/></button>)}</div></section>;return <section className="panel"><div className="row"><button className="secondary" onClick={()=>setRoom(null)}><ArrowLeft size={17}/></button><h2>{room.name}</h2></div><div className="room"><div className="muted">LIVE VOICE ROOM</div><div className="bigmic">{mic?<Mic/>:<MicOff/>}</div><b>{mic?'Microphone ON':'Tap mic to speak'}</b><div className="row" style={{justifyContent:'center',marginTop:18}}><button className="primary" onClick={mic?stopMic:startMic}>{mic?'Mute':'Speak'}</button><button className="secondary"><Volume2 size={17}/> Speaker</button></div></div></section>}

function Calls(){return <section className="panel"><h2>Calls</h2><div className="grid"><button className="tile"><Phone size={25}/><b>Voice Call</b><small>WebRTC-ready UI</small></button><button className="tile"><Video size={25}/><b>Video Call</b><small>WebRTC-ready UI</small></button></div><div className="notice">Calls require a real-time signaling/backend service before they can connect two different users.</div></section>}

createRoot(document.getElementById('root')).render(<App/>)
