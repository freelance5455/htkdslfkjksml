import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { getFirestore, collection, addDoc, onSnapshot, doc, updateDoc, increment, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { BookOpen, Video, Heart, Upload, LogIn, LogOut, Radio, Bot, ShieldCheck, FileText, Home } from 'lucide-react';
import './style.css';

const cfg = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};
let auth, db, storage, ready = false;
try {
  if (cfg.apiKey && cfg.projectId) {
    const app = initializeApp(cfg); auth = getAuth(app); db = getFirestore(app); storage = getStorage(app); ready = true;
  }
} catch (e) { console.error(e); }

const ownerEmail = (import.meta.env.VITE_OWNER_EMAIL || '').toLowerCase();
const admins = (import.meta.env.VITE_ADMIN_EMAILS || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);

function App() {
  const [user, setUser] = useState(null);
  const [videos, setVideos] = useState([]);
  const [notes, setNotes] = useState([]);
  const [tab, setTab] = useState('videos');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState(null);
  const [kind, setKind] = useState('video');
  const [question, setQuestion] = useState('');
  const [chat, setChat] = useState([{role:'assistant', text:'Namaste! Main Ritika hoon. Aaj kya seekhna hai? Apna sawal likho.'}]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const isAdmin = !!user && ((ownerEmail && user.email?.toLowerCase() === ownerEmail) || admins.includes(user.email?.toLowerCase()));
  const liveUrl = import.meta.env.VITE_LIVE_STREAM_URL || '';

  useEffect(() => {
    if (!ready) return;
    return onAuthStateChanged(auth, setUser);
  }, []);
  useEffect(() => {
    if (!ready) return;
    const a = onSnapshot(query(collection(db, 'videos'), orderBy('createdAt', 'desc')), s => setVideos(s.docs.map(d => ({id:d.id, ...d.data()}))), e => console.warn(e));
    const b = onSnapshot(query(collection(db, 'notes'), orderBy('createdAt', 'desc')), s => setNotes(s.docs.map(d => ({id:d.id, ...d.data()}))), e => console.warn(e));
    return () => { a(); b(); };
  }, []);

  async function login() {
    try { await signInWithPopup(auth, new GoogleAuthProvider()); }
    catch (e) { setMessage('Sign-in error: ' + e.message); }
  }
  async function publish(e) {
    e.preventDefault();
    if (!ready) return setMessage('Pehle Firebase setup karein. README.md dekhein.');
    if (!user) return setMessage('Pehle Google se sign in karein.');
    if (!isAdmin) return setMessage('Upload permission sirf owner aur approved teachers ko hai.');
    if (!file || !title.trim()) return setMessage('Title aur file dono zaroori hain.');
    setBusy(true);
    try {
      const bucket = kind === 'note' ? 'notes' : 'videos';
      const path = `${bucket}/${user.uid}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
      const fileRef = ref(storage, path);
      await uploadBytes(fileRef, file);
      const url = await getDownloadURL(fileRef);
      await addDoc(collection(db, bucket), {
        title: title.trim(), description: description.trim(), url, fileName: file.name,
        owner: user.uid, ownerEmail: user.email, likes: 0, views: 0, createdAt: serverTimestamp()
      });
      setTitle(''); setDescription(''); setFile(null); e.target.reset();
      setMessage('Upload ho gaya!');
    } catch (err) { setMessage('Upload error: ' + err.message); }
    finally { setBusy(false); }
  }
  async function like(v) {
    if (!ready) return setMessage('Firebase setup ke baad likes chalu honge.');
    try { await updateDoc(doc(db, 'videos', v.id), {likes: increment(1)}); }
    catch (e) { setMessage('Like karne ke liye sign in karein.'); }
  }
  async function countView(v) {
    if (!ready) return;
    try { await updateDoc(doc(db, 'videos', v.id), {views: increment(1)}); } catch {}
  }
  async function askRitika(e) {
    e.preventDefault();
    const q = question.trim(); if (!q) return;
    setChat(c => [...c, {role:'user', text:q}]); setQuestion('');
    const endpoint = import.meta.env.VITE_RITIKA_AI_ENDPOINT;
    if (endpoint) {
      try {
        const res = await fetch(endpoint, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({message:q})});
        const data = await res.json();
        setChat(c => [...c, {role:'assistant', text:data.reply || data.answer || 'Abhi jawab nahi mil saka.'}]);
      } catch { setChat(c => [...c, {role:'assistant', text:'AI service se connection nahi hua. Thodi der baad try karo.'}]); }
    } else {
      setChat(c => [...c, {role:'assistant', text:'Main Ritika hoon! AI jawab chalu karne ke liye README mein diye gaye secure AI backend ko connect karna hoga. Filhaal apne sawal ko topic ke saath likho aur teacher ke notes/videos dekho.'}]);
    }
  }

  return <div className="app">
    <header className="topbar">
      <div className="brand"><div className="logo"><BookOpen size={24}/></div><div><b>Ritika Knowledge</b><small>Seekho • Sikhao • Aage Badho</small></div></div>
      {user ? <button className="outline" onClick={() => signOut(auth)}><LogOut size={16}/> Logout</button> : <button onClick={login} disabled={!ready}><LogIn size={16}/> Sign in</button>}
    </header>
    {!ready && <div className="notice">Demo mode: videos cloud mein save karne ke liye Firebase setup karein. Setup steps README.md mein hain.</div>}
    {message && <button className="toast" onClick={() => setMessage('')}>{message} ×</button>}
    <section className="hero"><div><span className="pill">FREE LEARNING</span><h1>Knowledge sabke liye. <em>Bilkul simple.</em></h1><p>Videos dekho, notes padho, live class join karo aur Ritika se madad lo.</p><div className="hero-actions"><button onClick={() => setTab('videos')}>Videos dekhein</button><button className="light" onClick={() => setTab('ritika')}><Bot size={17}/> Ritika se poochhein</button></div></div><div className="hero-art"><div className="book-art"><BookOpen size={76}/><span>Learn every day ✨</span></div></div></section>
    <nav className="tabs">
      {[['videos','Videos',Video],['notes','Notes',FileText],['live','Live class',Radio],['ritika','Ritika AI',Bot],['upload','Upload',Upload],['admin','Admin',ShieldCheck]].map(([id,label,Icon])=><button key={id} className={tab===id?'active':''} onClick={()=>setTab(id)}><Icon size={17}/>{label}</button>)}
    </nav>
    <main>
      {tab==='videos' && <><div className="section-title"><div><h2>Knowledge videos</h2><p>Apni learning aaj se shuru karo.</p></div><span className="count">{videos.length} videos</span></div>
        {videos.length===0 ? <Empty title="Abhi videos nahi hain" text="Owner ya approved teacher yahan videos upload kar sakte hain."/> : <div className="cards">{videos.map(v=><article className="card" key={v.id}><div className="video-frame"><video src={v.url} controls preload="metadata" onPlay={()=>countView(v)} /></div><div className="card-body"><h3>{v.title}</h3><p>{v.description}</p><div className="meta"><span>▶ {v.views||0} views</span><button className="like" onClick={()=>like(v)}><Heart size={16}/> {v.likes||0}</button></div></div></article>)}</div>}
      </>}
      {tab==='notes' && <><div className="section-title"><div><h2>Study notes</h2><p>PDF notes padhein aur download karein.</p></div></div>{notes.length===0?<Empty title="Notes jald aayenge" text="Teachers se PDF notes upload karwayein."/>:<div className="cards">{notes.map(n=><article className="note-card" key={n.id}><FileText size={32}/><h3>{n.title}</h3><p>{n.description}</p><a href={n.url} target="_blank" rel="noreferrer">PDF kholein / download karein ↗</a></article>)}</div>}</>}
      {tab==='live' && <div className="panel"><div className="panel-icon"><Radio size={28}/></div><h2>Live classes</h2><p>Teacher ke live stream ka link yahan set hoga. Live streaming provider ka URL .env file mein add karein.</p>{liveUrl?<a className="button-link" href={liveUrl} target="_blank" rel="noreferrer">Live class join karein ↗</a>:<div className="notice">Abhi live stream configure nahi hai. README mein setup dekhein.</div>}</div>}
      {tab==='ritika' && <div className="chat-panel"><div className="chat-head"><div className="ritika-avatar"><Bot/></div><div><h2>Ritika AI</h2><p>Learning assistant • Hindi & English</p></div><span className="online">● Ready</span></div><div className="messages">{chat.map((m,i)=><div className={'bubble '+m.role} key={i}>{m.text}</div>)}</div><form className="chat-form" onSubmit={askRitika}><input value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Apna sawal likho..." /><button type="submit">Send</button></form><small className="hint">Real AI answers ke liye secure backend endpoint configure karein; API key browser mein na rakhein.</small></div>}
      {tab==='upload' && <div className="panel upload-panel"><h2><Upload size={22}/> Upload content</h2><p>Sirf owner aur approved teachers upload kar sakte hain.</p>{!user?<button onClick={login}><LogIn size={17}/> Google se sign in</button>:!isAdmin?<div className="notice">Signed in: {user.email}. Is account ko upload permission nahi mili. Owner .env mein teacher email add kare.</div>:<form onSubmit={publish} className="upload-form"><label>Content type<select value={kind} onChange={e=>setKind(e.target.value)}><option value="video">Knowledge video (MP4/WebM)</option><option value="note">Study notes (PDF)</option></select></label><label>Title<input value={title} onChange={e=>setTitle(e.target.value)} required placeholder="Jaise: Class 10 Science - Light"/></label><label>Description<textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Is lesson mein kya seekhenge?"/></label><label>File<input type="file" required accept={kind==='note'?'.pdf,application/pdf':'video/mp4,video/webm,video/quicktime'} onChange={e=>setFile(e.target.files?.[0]||null)}/></label><button disabled={busy}>{busy?'Uploading...':'Publish content'}</button></form>}</div>}
      {tab==='admin' && <div className="panel"><h2><ShieldCheck size={22}/> Admin dashboard</h2><p>Content aur audience ka quick overview.</p><div className="stats"><div><strong>{videos.length}</strong><span>Videos</span></div><div><strong>{videos.reduce((n,v)=>n+(v.views||0),0)}</strong><span>Video views</span></div><div><strong>{videos.reduce((n,v)=>n+(v.likes||0),0)}</strong><span>Likes</span></div><div><strong>{notes.length}</strong><span>Notes</span></div></div><div className="notice">Upload permissions .env ke VITE_OWNER_EMAIL aur VITE_ADMIN_EMAILS se UI mein check hote hain. Production mein Firestore/Storage security rules bhi zaroor lagayein.</div><h3>Ads & earning</h3><p>Ad network approval milne ke baad hi ads se revenue aa sakta hai. AdSense publisher/client ID aur policy-compliant ad placements configure karna hoga; views se guaranteed payment nahi hoti.</p></div>}
    </main>
    <footer><div className="brand"><div className="logo small-logo"><BookOpen size={18}/></div><b>Ritika Knowledge</b></div><span>Made for curious minds 💙</span></footer>
  </div>;
}
function Empty({title,text}){return <div className="empty"><div><BookOpen size={30}/></div><h3>{title}</h3><p>{text}</p></div>}
createRoot(document.getElementById('root')).render(<App/>);
