import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './index.css';
import { preloadCoreGameAssets } from './utils/gameAssets';
preloadCoreGameAssets([]);
createRoot(document.getElementById('root')).render(<StrictMode>
    <App />
  </StrictMode>);
// Offline support: register the service worker in production builds only
if ('serviceWorker' in navigator && import.meta.env.PROD && import.meta.env.MODE !== 'apk') {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js').catch((err) => {
            console.warn('Service worker registration failed:', err);
        });
    });
}
