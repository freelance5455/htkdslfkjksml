import React,{useState} from "react";
import {createRoot} from "react-dom/client";
import {Sparkles,Play,Globe,Upload,Plus,Settings,Code2,FolderOpen,ChevronRight} from "lucide-react";
import "./style.css";

function App(){
 const [prompt,setPrompt]=useState("");
 const [projects,setProjects]=useState([{name:"My first project",status:"Draft"}]);
 const [selected,setSelected]=useState(0);
 const [deploying,setDeploying]=useState(false);
 const [url,setUrl]=useState("");
 const create=()=>{if(!prompt.trim())return;setProjects(p=>[...p,{name:prompt.slice(0,28),status:"Draft"}]);setSelected(projects.length);setPrompt("")};
 const deploy=()=>{setDeploying(true);setTimeout(()=>{setDeploying(false);setUrl("https://"+projects[selected].name.toLowerCase().replace(/[^a-z0-9]+/g,"-")+".example.com")},900)};
 return <div className="app">
  <header><div className="brand"><Sparkles/> <b>OpenBuilder</b></div><div className="actions"><button><Code2/> Code</button><button><Settings/> Settings</button><button className="deploy" onClick={deploy}><Upload/> {deploying?"Deploying…":"Deploy"}</button></div></header>
  <aside><button className="new" onClick={()=>setPrompt("")}><Plus/> New project</button><h4>PROJECTS</h4>{projects.map((p,i)=><div className={"project "+(i===selected?"active":"")} onClick={()=>setSelected(i)} key={i}><FolderOpen size={16}/><span>{p.name}</span><ChevronRight size={14}/></div>)}<div className="sideBottom"><Globe/> <span>Hosting</span><span className="free">FREE</span></div></aside>
  <main>
   <section className="hero"><div className="badge">AI website builder</div><h1>Build anything.<br/><em>Deploy instantly.</em></h1><p>Describe your website or app and generate a production-ready starter project.</p>
   <div className="composer"><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="e.g. Build a premium restaurant website with menu, gallery and contact form…"/><button onClick={create}><Sparkles/> Generate</button></div>
   <div className="chips">{["Landing page","Dashboard","Online store","Portfolio"].map(x=><button onClick={()=>setPrompt("Build a "+x.toLowerCase()+" with a premium responsive design.")}>{x}</button>)}</div></section>
   <section className="workspace"><div className="bar"><span>Preview</span><span>{projects[selected]?.name}</span><button onClick={deploy}><Play size={15}/> {deploying?"Deploying":"One-click deploy"}</button></div>
   <div className="preview"><div className="mockNav"><b>{projects[selected]?.name||"Your project"}</b><span>Home　About　Contact</span><button>Get started</button></div><div className="mockHero"><small>YOUR NEW WEBSITE</small><h2>Turn your idea into<br/>a beautiful website.</h2><p>Fast, responsive and ready to customize.</p><button>Explore project</button></div></div>
   {url&&<div className="live"><Globe size={18}/><b>Deployment ready:</b> <span>{url}</span></div>}</section>
  </main>
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);