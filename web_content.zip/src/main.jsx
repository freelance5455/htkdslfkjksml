import React,{useMemo,useState} from "react";
import {createRoot} from "react-dom/client";
import {Search,ShoppingBag,Star,Plus,Minus,MapPin,Clock,Sparkles,Heart,ChevronRight} from "lucide-react";
import "./styles.css";

const foods=[
 {id:1,name:"Truffle Wagyu Burger",cat:"Burgers",price:1890,rating:4.9,time:"25 min",emoji:"🍔",tag:"Chef's Pick"},
 {id:2,name:"Creamy Truffle Pasta",cat:"Pasta",price:1690,rating:4.8,time:"20 min",emoji:"🍝",tag:"Signature"},
 {id:3,name:"Saffron Chicken",cat:"Mains",price:2190,rating:4.9,time:"30 min",emoji:"🍗",tag:"Premium"},
 {id:4,name:"Royal Margherita",cat:"Pizza",price:1490,rating:4.7,time:"22 min",emoji:"🍕",tag:"Classic"},
 {id:5,name:"Salmon Avocado Bowl",cat:"Healthy",price:1790,rating:4.8,time:"18 min",emoji:"🥗",tag:"Fresh"},
 {id:6,name:"Chocolate Lava",cat:"Desserts",price:990,rating:4.9,time:"15 min",emoji:"🍫",tag:"Bestseller"}
];

function App(){
 const [cat,setCat]=useState("All"),[q,setQ]=useState(""),[cart,setCart]=useState({}),[liked,setLiked]=useState({});
 const shown=useMemo(()=>foods.filter(f=>(cat==="All"||f.cat===cat)&&f.name.toLowerCase().includes(q.toLowerCase())),[cat,q]);
 const count=Object.values(cart).reduce((a,b)=>a+b,0);
 const total=Object.entries(cart).reduce((s,[id,n])=>s+(foods.find(f=>f.id==id)?.price||0)*n,0);
 const add=id=>setCart(c=>({...c,[id]:(c[id]||0)+1}));
 const sub=id=>setCart(c=>{let x={...c}; x[id]=(x[id]||0)-1;if(x[id]<=0)delete x[id];return x});
 return <div className="app">
  <header><div className="logo"><span>V</span> VELORA</div><nav><a>Home</a><a>Menu</a><a>Collections</a><a>About</a></nav><button className="cart"><ShoppingBag size={20}/><b>{count}</b></button></header>
  <main>
   <section className="hero"><div><div className="eyebrow"><Sparkles size={16}/> PREMIUM DINING, DELIVERED</div><h1>Indulgence<br/><i>at your door.</i></h1><p>Curated flavors, exquisite ingredients and restaurant-level luxury — made for your moments.</p><button className="goldBtn" onClick={()=>document.getElementById("menu").scrollIntoView({behavior:"smooth"})}>Explore Menu <ChevronRight size={18}/></button><div className="trust"><span><Star size={15} fill="currentColor"/> 4.9/5</span><span><Clock size={15}/> 20–30 min</span><span><MapPin size={15}/> Faisalabad</span></div></div><div className="heroFood"><div className="glow"></div><div className="plate">🍔</div><div className="floating">Chef's Pick<br/><b>Wagyu Collection</b></div></div></section>
   <section id="menu" className="menu"><div className="sectionTop"><div><small>OUR MENU</small><h2>Made for <i>cravings.</i></h2></div><div className="search"><Search size={18}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search dishes..."/></div></div>
    <div className="cats">{["All","Burgers","Pasta","Mains","Pizza","Healthy","Desserts"].map(c=><button className={cat===c?"active":""} onClick={()=>setCat(c)}>{c}</button>)}</div>
    <div className="grid">{shown.map(f=><article className="card"><div className="pic"><span className="tag">{f.tag}</span><button className="heart" onClick={()=>setLiked(x=>({...x,[f.id]:!x[f.id]}))}><Heart size={18} fill={liked[f.id]?"currentColor":"none"}/></button><div className="foodEmoji">{f.emoji}</div></div><div className="info"><div className="rating"><Star size={14} fill="currentColor"/> {f.rating} <em>•</em> {f.time}</div><h3>{f.name}</h3><div className="bottom"><strong>Rs {f.price.toLocaleString()}</strong><button className="add" onClick={()=>add(f.id)}><Plus size={18}/>{cart[f.id]?"Add more":"Add"}</button></div>{cart[f.id]&&<div className="qty"><button onClick={()=>sub(f.id)}><Minus size={15}/></button><b>{cart[f.id]}</b><button onClick={()=>add(f.id)}><Plus size={15}/></button></div>}</div></article>)}</div>
   </section>
   <section className="banner"><div><small>THE VELORA STANDARD</small><h2>Luxury isn't extra.<br/><i>It's the standard.</i></h2><p>Freshly prepared. Beautifully packed. Delivered with care.</p></div><div className="seal">100%<br/><small>PREMIUM</small></div></section>
  </main>
  {count>0&&<div className="checkout"><div><span>{count} items</span><b>Rs {total.toLocaleString()}</b></div><button className="goldBtn">View Cart & Checkout <ChevronRight size={18}/></button></div>}
  <footer><div className="logo"><span>V</span> VELORA</div><p>Premium food, elevated.</p><small>© 2026 Velora. Crafted for exceptional moments.</small></footer>
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);