import AuthCard from "@/components/AuthCard";

export const dynamic = "force-dynamic";

export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const params = await searchParams;
  return <AuthCard mode="reset" token={params.token ?? ""} />;
}
