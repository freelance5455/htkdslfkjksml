import { useState } from "react";
import { nativeFiles, totalLines } from "../../data/nativeSources";
import { buildZip, downloadBlob } from "../../lib/zip";
import { I, StatusBar } from "../ui";

export default function NativeSourceScreen({
  onBack,
  toast,
}: {
  onBack: () => void;
  toast: (text: string, tone?: "ok" | "err" | "info") => void;
}) {
  const [open, setOpen] = useState<string | null>(null);
  const [zipping, setZipping] = useState(false);

  const download = () => {
    setZipping(true);
    setTimeout(() => {
      try {
        const blob = buildZip(
          nativeFiles.map((f) => ({ path: f.zipPath, content: f.code }))
        );
        downloadBlob(blob, "meshlink-android-source.zip");
        toast("Source kit downloaded — meshlink-android-source.zip", "ok");
      } catch {
        toast("Download failed — try Copy all instead", "err");
      }
      setZipping(false);
    }, 350);
  };

  const copyAll = async () => {
    const all = nativeFiles
      .map((f) => `\n\n${"=".repeat(70)}\nFILE: ${f.zipPath}\n${"=".repeat(70)}\n\n${f.code}`)
      .join("");
    try {
      await navigator.clipboard.writeText(all);
      toast("All files copied to clipboard", "ok");
    } catch {
      toast("Copy failed in this browser", "err");
    }
  };

  return (
    <div className="absolute inset-0 flex flex-col bg-mist animate-screen">
      <StatusBar />

      <div className="px-3.5 pt-2 pb-3 bg-white/80 backdrop-blur border-b border-royal/10 flex items-center gap-2.5">
        <button
          onClick={onBack}
          className="w-9 h-9 grid place-items-center rounded-full hover:bg-royal/10 text-ink active:scale-90 transition-all"
          aria-label="back"
        >
          {I.back()}
        </button>
        <div className="flex-1 leading-tight">
          <div className="font-bold text-[15px] text-ink">Native Android build</div>
          <div className="text-[10.5px] text-ink-soft/80 font-mono">
            Google Nearby Connections API · Bluetooth + Wi-Fi / hotspot
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto app-scroll px-5 py-4 space-y-4">
        <div className="glass-deep rounded-3xl p-5 text-white relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-36 h-36 rounded-full bg-royal/30 blur-2xl" />
          <div className="text-[10px] font-mono font-bold tracking-[0.18em] text-ice/80">
            THE REAL RADIO BUILD
          </div>
          <h2 className="mt-1.5 font-display font-bold text-[19px] leading-snug">
            Complete Flutter source on the Google Nearby Connections API
          </h2>
          <p className="mt-2 text-[12px] leading-relaxed text-ice/90">
            P2P_CLUSTER strategy — devices link over <b>Bluetooth LE</b> and{" "}
            <b>Wi-Fi Direct</b>, including phones joined through a{" "}
            <b>hotspot</b>. Hop-by-hop relay, TTL 10, loop-proof delivery,
            fully offline. No internet, no SIM, no server.
          </p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {["nearby_connections ^5.0.0", "BLE", "Wi-Fi Direct", "hotspot", "offline"].map(
              (t) => (
                <span
                  key={t}
                  className="rounded-full bg-white/12 border border-white/15 px-2.5 py-1 text-[10px] font-mono font-semibold text-ice"
                >
                  {t}
                </span>
              )
            )}
          </div>
        </div>

        <button
          onClick={download}
          disabled={zipping}
          className="w-full rounded-2xl bg-royal text-white font-bold text-[15px] py-4 shadow-[0_12px_30px_rgba(10,108,255,0.45)] hover:bg-royal-deep active:scale-[0.98] transition-all disabled:opacity-60 flex items-center justify-center gap-2.5"
        >
          {zipping ? (
            <>
              <span className="w-4 h-4 rounded-full border-2 border-white/40 border-t-white animate-spin" />
              Packing zip…
            </>
          ) : (
            <>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 3v12m0 0l-4.5-4.5M12 15l4.5-4.5" />
                <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
              </svg>
              Download source kit (.zip)
            </>
          )}
        </button>
        <button
          onClick={copyAll}
          className="w-full rounded-2xl glass text-ink font-bold text-[13.5px] py-3.5 hover:border-royal/40 hover:text-royal active:scale-[0.98] transition-all flex items-center justify-center gap-2"
        >
          {I.copy(14)}
          Copy all {nativeFiles.length} files
        </button>

        <div className="glass rounded-3xl p-5">
          <div className="text-[10px] font-mono font-bold tracking-[0.18em] text-royal mb-3">
            BUILD THE APK — 3 STEPS
          </div>
          <ol className="space-y-2.5">
            {[
              ["Install Flutter", "flutter.dev — one-time setup on your computer."],
              ["Scaffold and drop in", "flutter create meshlink --platforms android, then replace pubspec.yaml, AndroidManifest.xml and lib/ with these files; flutter pub get."],
              ["Run on real phones", "flutter run with two or more physical Android devices. Emulators cannot do BLE / Wi-Fi Direct."],
            ].map(([t, d], i) => (
              <li key={t} className="flex gap-3">
                <span className="w-6 h-6 shrink-0 rounded-full bg-royal text-white font-display font-bold text-[12px] grid place-items-center mt-0.5">
                  {i + 1}
                </span>
                <div>
                  <div className="text-[13px] font-bold text-ink leading-tight">{t}</div>
                  <div className="text-[11.5px] text-ink-soft leading-relaxed mt-0.5">{d}</div>
                </div>
              </li>
            ))}
          </ol>
        </div>

        <div>
          <div className="flex items-center justify-between px-1 mb-2.5">
            <span className="text-[10px] font-mono font-bold tracking-[0.18em] text-royal">
              SOURCE FILES — {nativeFiles.length} FILES, {totalLines.toLocaleString()} LINES
            </span>
          </div>
          <div className="space-y-2">
            {nativeFiles.map((f) => (
              <div key={f.zipPath} className="glass rounded-2xl overflow-hidden">
                <button
                  onClick={() => setOpen(open === f.zipPath ? null : f.zipPath)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-royal/5 transition-colors"
                >
                  <span className="w-8 h-8 shrink-0 rounded-lg bg-royal/10 grid place-items-center text-royal font-mono font-bold text-[10px]">
                    {f.label.endsWith(".dart") ? "DT" : f.label.endsWith(".yaml") ? "YM" : f.label.endsWith(".xml") ? "XL" : "MD"}
                  </span>
                  <span className="flex-1 min-w-0">
                    <span className="block font-mono font-bold text-[12.5px] text-ink truncate">
                      {f.label}
                    </span>
                    <span className="block text-[10.5px] text-ink-soft/85 truncate mt-0.5">
                      {f.note}
                    </span>
                  </span>
                  <svg
                    width="13"
                    height="13"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#33507a"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    className={`shrink-0 transition-transform duration-200 ${open === f.zipPath ? "rotate-90" : ""}`}
                  >
                    <path d="M9 6l6 6-6 6" />
                  </svg>
                </button>
                {open === f.zipPath && (
                  <pre className="px-4 pb-4 pt-1 text-[10px] leading-[1.55] font-mono text-ice bg-panel overflow-x-auto app-scroll max-h-[260px] whitespace-pre">
                    {f.code}
                  </pre>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="pb-4 text-center font-mono text-[10px] text-ink-soft/55">
          Free forever — every dependency is open source on pub.dev
        </div>
      </div>
    </div>
  );
}
