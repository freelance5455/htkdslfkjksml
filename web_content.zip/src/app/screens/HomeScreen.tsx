import { useState } from "react";
import { net } from "../../lib/net";
import { normCode, type Transport } from "../../lib/store";
import { Dot, I, StatusBar, TransportIcon } from "../ui";

export default function HomeScreen({
  toast,
  openChat,
  openNative,
}: {
  toast: (text: string, tone?: "ok" | "err" | "info") => void;
  openChat: (code: string) => void;
  openNative: () => void;
}) {
  const profile = net.profile!;
  const [addDraft, setAddDraft] = useState("");
  const [scanning, setScanning] = useState(false);
  const [btScanning, setBtScanning] = useState(false);
  const [addError, setAddError] = useState<string | null>(null);
  const [shakeKey, setShakeKey] = useState(0);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [copied, setCopied] = useState(false);

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(profile.code);
      setCopied(true);
      toast("Code copied to clipboard", "ok");
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast("Copy failed — note the code manually", "err");
    }
  };

  const addCode = async () => {
    const code = normCode(addDraft);
    if (code.length < 6) {
      setAddError("Enter the full 6-character code, e.g. K7M-2QP.");
      setShakeKey((k) => k + 1);
      return;
    }
    setAddError(null);
    setScanning(true);
    const res = await net.addByCode(code);
    setScanning(false);
    if (res.ok) {
      setAddDraft("");
      toast(`Linked with ${res.peer.name} — saved to your devices`, "ok");
    } else {
      setAddError(res.error);
      setShakeKey((k) => k + 1);
    }
  };

  const setTransport = (t: Transport) => {
    net.setTransport(t);
    toast(t === "bluetooth" ? "Bluetooth radio selected" : "Wi-Fi / hotspot radio selected", "info");
  };

  /* Real Web Bluetooth scan — the platform's own BLE picker (Android Chrome). */
  const scanBluetooth = async () => {
    const bt = (navigator as unknown as { bluetooth?: { requestDevice: (o: object) => Promise<{ name?: string }> } }).bluetooth;
    if (!bt) {
      toast("No Bluetooth radio in this browser — the Android build uses real BLE", "err");
      return;
    }
    try {
      setBtScanning(true);
      const device = await bt.requestDevice({ acceptAllDevices: true });
      toast(`Bluetooth device found: ${device.name || "unnamed device"}`, "ok");
    } catch {
      /* user closed the picker — nothing to report */
    } finally {
      setBtScanning(false);
    }
  };

  return (
    <div className="absolute inset-0 flex flex-col bg-mist animate-screen">
      <StatusBar />

      <div className="px-5 pt-3 pb-4 flex items-center gap-3">
        <div className="w-11 h-11 rounded-full bg-gradient-to-br from-sky to-royal grid place-items-center text-white font-display font-bold text-[17px] shadow-[0_8px_20px_rgba(10,108,255,0.4)]">
          {profile.name[0]?.toUpperCase()}
        </div>
        <div className="flex-1 min-w-0 leading-tight">
          <div className="font-display font-bold text-[19px] text-ink truncate">
            Hello, {profile.name}
          </div>
          <div className="text-[11px] text-ink-soft/80 font-mono">mesh radio: active</div>
        </div>
        <button
          onClick={() => {
            setAboutOpen(true);
            setConfirmReset(false);
          }}
          className="w-10 h-10 rounded-full glass grid place-items-center text-ink-soft hover:text-royal active:scale-95 transition-all"
          aria-label="settings"
        >
          {I.gear()}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto app-scroll px-5 pb-8 space-y-4">
        {/* status card */}
        <div className="glass-deep rounded-3xl p-5 text-white relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-36 h-36 rounded-full bg-royal/30 blur-2xl" />
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold tracking-[0.18em] text-ice/80">
              DEVICE STATUS
            </span>
            <span
              className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold border ${
                net.online
                  ? "bg-white/10 border-white/20 text-white"
                  : "bg-emerald-400/15 border-emerald-400/40 text-emerald-300"
              }`}
            >
              {I.globeOff(11)}
              {net.online ? "INTERNET: ONLINE" : "INTERNET: OFFLINE — AS INTENDED"}
            </span>
          </div>
          <div className="mt-2 font-display font-bold text-[17px] leading-snug">
            {net.online
              ? "Internet detected — but you don't need it"
              : "Fully offline, exactly as it should be"}
          </div>
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-mono font-bold tracking-[0.18em] text-ice/80">
                CONNECT USING
              </span>
              {profile.transport === "bluetooth" && (
                <button
                  onClick={scanBluetooth}
                  disabled={btScanning}
                  className="inline-flex items-center gap-1.5 rounded-full bg-white/12 hover:bg-white/20 border border-white/15 px-2.5 py-1 text-[10px] font-bold text-ice transition-colors disabled:opacity-60"
                >
                  {btScanning ? (
                    <span className="w-2.5 h-2.5 rounded-full border border-white/40 border-t-white animate-spin" />
                  ) : (
                    I.bt(11)
                  )}
                  {btScanning ? "Scanning…" : "Scan BLE"}
                </button>
              )}
            </div>
            <div className="grid grid-cols-2 gap-1 rounded-2xl bg-white/10 p-1">
              {(
                [
                  ["bluetooth", "Bluetooth", I.bt(15)],
                  ["wifi", "Wi-Fi / Hotspot", I.wifi(15)],
                ] as [Transport, string, React.ReactNode][]
              ).map(([t, label, icon]) => (
                <button
                  key={t}
                  onClick={() => setTransport(t)}
                  className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-[12.5px] font-bold transition-all ${
                    profile.transport === t
                      ? "bg-royal text-white shadow-[0_6px_16px_rgba(10,108,255,0.5)]"
                      : "text-ice/85 hover:bg-white/8"
                  }`}
                >
                  {icon}
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* my code */}
        <div className="rounded-3xl bg-gradient-to-br from-royal to-royal-deep text-white p-5 shadow-[0_16px_40px_rgba(10,108,255,0.4)] relative overflow-hidden">
          <div className="absolute -bottom-12 -right-10 w-40 h-40 rounded-full bg-white/12 blur-2xl" />
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold tracking-[0.18em] text-white/75">
              MY CODE — GIVE THIS TO A FRIEND
            </span>
            <button
              onClick={() => {
                const c = net.regenCode();
                toast(`New code generated: ${c}`, "info");
              }}
              className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 grid place-items-center active:scale-90 transition-all"
              aria-label="generate new code"
            >
              {I.refresh()}
            </button>
          </div>
          <div className="mt-2.5 font-mono font-bold text-[34px] tracking-[0.14em] leading-none">
            {profile.code}
          </div>
          <div className="mt-4 flex gap-2">
            <button
              onClick={copyCode}
              className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-white/15 hover:bg-white/25 py-2.5 text-[12.5px] font-bold transition-all active:scale-[0.98]"
            >
              {copied ? I.check() : I.copy()}
              {copied ? "Copied" : "Copy code"}
            </button>
          </div>
        </div>

        {/* add code */}
        <div className="glass rounded-3xl p-5">
          <div className="flex items-center gap-2 text-royal">
            {I.link(15)}
            <span className="text-[10px] font-mono font-bold tracking-[0.18em]">
              ADD A FRIEND'S CODE
            </span>
          </div>
          <div key={shakeKey} className={`mt-3 flex gap-2 ${addError ? "animate-shake" : ""}`}>
            <input
              value={addDraft}
              onChange={(e) => {
                setAddDraft(e.target.value.toUpperCase());
                setAddError(null);
              }}
              onKeyDown={(e) => e.key === "Enter" && !scanning && addCode()}
              placeholder="K7M-2QP"
              maxLength={7}
              disabled={scanning}
              className="w-full min-w-0 rounded-xl bg-white border border-royal/20 px-4 py-3 font-mono font-bold text-[16px] tracking-[0.15em] text-ink placeholder:text-ink-soft/35 outline-none focus:border-royal focus:shadow-[0_0_0_4px_rgba(10,108,255,0.12)] transition-all"
            />
            <button
              onClick={addCode}
              disabled={scanning || normCode(addDraft).length < 6}
              className="shrink-0 rounded-xl bg-royal text-white font-bold text-[13.5px] px-5 disabled:opacity-40 hover:bg-royal-deep active:scale-[0.97] transition-all"
            >
              {scanning ? (
                <span className="flex items-center gap-2">
                  <span className="w-3.5 h-3.5 rounded-full border-2 border-white/40 border-t-white animate-spin" />
                  Searching…
                </span>
              ) : (
                "Add code"
              )}
            </button>
          </div>
          {addError && (
            <div className="mt-2.5 text-[11.5px] font-semibold text-red-500 leading-snug">{addError}</div>
          )}
          <p className="mt-2.5 text-[11px] text-ink-soft/80 leading-relaxed">
            Both phones must have MeshLink open. Enter their code here — or give
            them yours. Either direction works: once one side adds, both devices
            connect and get saved.
          </p>
        </div>

        {/* linked devices */}
        <div>
          <div className="flex items-center justify-between px-1 mb-2.5">
            <span className="text-[10px] font-mono font-bold tracking-[0.18em] text-royal">
              LINKED DEVICES — SAVED IN APP
            </span>
            <span className="text-[11px] font-bold text-ink-soft/70">{net.peers.length}</span>
          </div>

          {net.peers.length === 0 ? (
            <div className="rounded-3xl border-2 border-dashed border-royal/25 bg-white/50 p-6 text-center">
              <div className="mx-auto w-11 h-11 rounded-full bg-royal/10 grid place-items-center text-royal">
                {I.bt(18)}
              </div>
              <div className="mt-2 text-[13px] font-bold text-ink">No devices linked yet</div>
              <p className="mt-1 text-[11.5px] text-ink-soft/85 leading-relaxed">
                Share your code or add theirs — once linked,
                <br />
                the device is saved here permanently.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {net.peers.map((p) => {
                const online = net.peerOnline(p.code);
                const unread = net.unread(p.code);
                return (
                  <div
                    key={p.code}
                    className="glass rounded-2xl p-3.5 flex items-center gap-3 hover:border-royal/40 transition-colors"
                  >
                    <button onClick={() => openChat(p.code)} className="flex items-center gap-3 flex-1 min-w-0 text-left">
                      <div className="relative w-11 h-11 shrink-0 rounded-full bg-royal/12 grid place-items-center font-display font-bold text-royal text-[16px]">
                        {p.name[0]?.toUpperCase()}
                        <span className="absolute -bottom-0.5 -right-0.5">
                          <Dot on={online} size={11} />
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-[14px] text-ink truncate">{p.name}</div>
                        <div className="flex items-center gap-1.5 text-[10.5px] text-ink-soft/80 mt-0.5">
                          <TransportIcon t={p.transport} size={11} />
                          <span className="font-mono">{p.code}</span>
                          <span className={online ? "text-emerald-600 font-bold" : ""}>
                            · {online ? "online" : "offline"}
                          </span>
                        </div>
                      </div>
                      {unread > 0 && (
                        <span className="shrink-0 min-w-[20px] h-5 px-1.5 rounded-full bg-royal text-white text-[10.5px] font-bold grid place-items-center shadow-[0_3px_8px_rgba(10,108,255,0.4)]">
                          {unread}
                        </span>
                      )}
                    </button>
                    <button
                      onClick={() => {
                        net.removePeer(p.code);
                        toast(`${p.name} removed from your devices`, "info");
                      }}
                      className="w-8 h-8 shrink-0 rounded-full grid place-items-center text-ink-soft/45 hover:text-red-500 hover:bg-red-500/10 active:scale-90 transition-all"
                      aria-label={`remove ${p.name}`}
                    >
                      {I.trash()}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* native build card */}
        <button
          onClick={openNative}
          className="w-full text-left glass-deep rounded-3xl p-5 text-white relative overflow-hidden hover:-translate-y-0.5 transition-transform duration-300"
        >
          <div className="absolute -bottom-12 -right-10 w-40 h-40 rounded-full bg-sky/25 blur-2xl" />
          <div className="flex items-center gap-2 text-ice/85">
            {I.bt(13)}
            {I.wifi(14)}
            <span className="text-[10px] font-mono font-bold tracking-[0.18em]">
              NATIVE ANDROID BUILD
            </span>
          </div>
          <div className="mt-1.5 font-display font-bold text-[16.5px] leading-snug">
            Google Nearby Connections API — real Bluetooth + Wi-Fi / hotspot radio
          </div>
          <p className="mt-1.5 text-[11.5px] leading-relaxed text-ice/85">
            Complete Flutter source kit with the relay engine, permissions and UI.
            Fully offline, hop-by-hop mesh. Download it inside this app.
          </p>
          <span className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-bold text-sky">
            Open the source kit
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round"><path d="M9 6l6 6-6 6" /></svg>
          </span>
        </button>

        <div className="pt-2 text-center font-mono text-[10px] text-ink-soft/55">
          MeshLink v1.0 · offline-first · no servers
        </div>
      </div>

      {/* about / settings sheet */}
      {aboutOpen && (
        <div className="absolute inset-0 z-50">
          <div className="absolute inset-0 bg-ink/45 backdrop-blur-[2px]" onClick={() => setAboutOpen(false)} />
          <div className="absolute inset-x-0 bottom-0 animate-sheet">
            <div className="mx-2 mb-2 rounded-3xl glass-deep p-6 text-white">
              <div className="flex items-center gap-3">
                <img src="/icon-512.png" alt="" className="w-11 h-11 rounded-xl" />
                <div>
                  <div className="font-display font-bold text-[17px]">MeshLink v1.0</div>
                  <div className="text-[11px] text-ice/80 font-mono">offline chat · code-to-code</div>
                </div>
                <button
                  onClick={() => setAboutOpen(false)}
                  className="ml-auto w-8 h-8 rounded-full bg-white/10 grid place-items-center hover:bg-white/20 transition-colors"
                  aria-label="close"
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round">
                    <path d="M6 6l12 12M18 6L6 18" />
                  </svg>
                </button>
              </div>
              <p className="mt-4 text-[12.5px] leading-relaxed text-ice/90">
                Name, code, link, chat. Everything is stored on this device.
                No internet, no SIM card and no server is involved at any point.
              </p>
              <p className="mt-2.5 text-[11px] leading-relaxed text-ice/60">
                This web build links MeshLink instances inside this browser — open
                two windows to run two devices side by side. For real Bluetooth and
                Wi-Fi Direct / hotspot radio between physical phones, use the native
                Android build in the source kit (Google Nearby Connections API).
              </p>
              {!confirmReset ? (
                <button
                  onClick={() => setConfirmReset(true)}
                  className="mt-5 w-full rounded-xl border border-red-400/40 text-red-300 font-bold text-[13px] py-3 hover:bg-red-400/10 transition-colors"
                >
                  Reset all data
                </button>
              ) : (
                <div className="mt-5 rounded-xl bg-red-500/15 border border-red-400/40 p-3.5">
                  <div className="text-[12.5px] font-bold text-red-200">
                    Sure? Name, code, links and chats will all be erased.
                  </div>
                  <div className="mt-2.5 flex gap-2">
                    <button
                      onClick={() => setConfirmReset(false)}
                      className="flex-1 rounded-lg border border-white/20 py-2 text-[12px] font-bold hover:bg-white/10 transition-colors"
                    >
                      Keep it
                    </button>
                    <button
                      onClick={() => {
                        localStorage.clear();
                        location.reload();
                      }}
                      className="flex-1 rounded-lg bg-red-500 py-2 text-[12px] font-bold hover:bg-red-600 transition-colors"
                    >
                      Yes, erase
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
