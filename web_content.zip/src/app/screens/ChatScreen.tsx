import { useEffect, useRef, useState } from "react";
import { net } from "../../lib/net";
import { fmtTime } from "../../lib/store";
import { Dot, I, StatusBar, TransportIcon } from "../ui";

export default function ChatScreen({
  peerCode,
  onBack,
  toast,
}: {
  peerCode: string;
  onBack: () => void;
  toast: (text: string, tone?: "ok" | "err" | "info") => void;
}) {
  const peer = net.peers.find((p) => p.code === peerCode);
  const [draft, setDraft] = useState("");
  const listRef = useRef<HTMLDivElement>(null);
  const thread = net.thread(peerCode);
  const online = net.peerOnline(peerCode);

  useEffect(() => {
    net.markRead(peerCode);
  }, [peerCode, thread.length]);

  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [thread.length, peerCode]);

  if (!peer) {
    return (
      <div className="absolute inset-0 bg-mist grid place-items-center">
        <button onClick={onBack} className="glass rounded-full px-5 py-2.5 font-bold text-royal">
          Go back
        </button>
      </div>
    );
  }

  const send = () => {
    const text = draft.trim();
    if (!text) return;
    net.send(peerCode, text);
    setDraft("");
    if (!online) toast("Message saved — it will be delivered when they return", "info");
  };

  return (
    <div className="absolute inset-0 flex flex-col bg-mist animate-screen">
      <StatusBar />

      <div className="px-3.5 pt-2 pb-3 bg-white/80 backdrop-blur border-b border-royal/10 flex items-center gap-2.5">
        <button
          onClick={onBack}
          className="w-9 h-9 grid place-items-center rounded-full hover:bg-royal/10 text-ink active:scale-90 transition-all"
          aria-label="back"
        >
          {I.back()}
        </button>
        <div className="relative w-10 h-10 rounded-full bg-royal/12 grid place-items-center font-display font-bold text-royal text-[15px]">
          {peer.name[0]?.toUpperCase()}
          <span className="absolute -bottom-0.5 -right-0.5">
            <Dot on={online} size={11} />
          </span>
        </div>
        <div className="flex-1 min-w-0 leading-tight">
          <div className="font-bold text-[15px] text-ink truncate">{peer.name}</div>
          <div className="flex items-center gap-1.5 text-[10.5px] mt-0.5">
            <span className="text-ink-soft/75 inline-flex items-center gap-1">
              <TransportIcon t={peer.transport} size={11} />
              via {peer.transport === "bluetooth" ? "Bluetooth" : "Wi-Fi / hotspot"}
            </span>
            <span className={`font-bold ${online ? "text-emerald-600" : "text-ink-soft/60"}`}>
              · {online ? "ONLINE" : "OFFLINE"}
            </span>
          </div>
        </div>
      </div>

      {!online && (
        <div className="px-4 py-2 bg-amber-400/15 border-b border-amber-400/30 text-[11px] font-semibold text-amber-700 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
          {peer.name} is offline — messages are saved and will deliver when they're back.
        </div>
      )}

      <div ref={listRef} className="flex-1 overflow-y-auto app-scroll px-4 py-4 space-y-2 min-h-0">
        <div className="flex justify-center">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-royal/8 border border-royal/15 px-3.5 py-1.5 text-[10.5px] font-semibold text-royal-deep">
            {I.link(11)}
            Linked via {peer.transport === "bluetooth" ? "Bluetooth" : "Wi-Fi / hotspot"} ·{" "}
            {new Date(peer.linkedAt).toLocaleDateString()}
          </span>
        </div>

        {thread.length === 0 && (
          <div className="text-center mt-12 px-8">
            <div className="mx-auto w-12 h-12 rounded-full bg-royal/10 grid place-items-center text-royal">
              {I.send(18)}
            </div>
            <p className="mt-3 text-[12.5px] leading-relaxed text-ink-soft/85">
              Start the conversation — messages go straight to their phone.
              No internet involved at any point.
            </p>
          </div>
        )}

        {thread.map((m) => {
          const mine = m.from === net.profile!.code;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 ${
                  mine
                    ? "rounded-br-md bg-royal text-white shadow-[0_6px_16px_rgba(10,108,255,0.3)]"
                    : "rounded-bl-md bg-white border border-royal/10 text-ink shadow-sm"
                }`}
              >
                <p className="text-[13.5px] leading-relaxed whitespace-pre-wrap break-words">{m.text}</p>
                <div
                  className={`mt-1 flex items-center gap-1 text-[9px] ${
                    mine ? "text-white/70 justify-end" : "text-ink-soft/60"
                  }`}
                >
                  {fmtTime(m.ts)}
                  {mine && (
                    <span className={m.status === "delivered" ? "text-emerald-300" : ""}>
                      {m.status === "delivered" ? I.checks(13) : I.check(11)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="px-3 pt-2.5 pb-4 bg-white/85 backdrop-blur border-t border-royal/10">
        <div className="flex items-center gap-2">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Type a message…"
            className="w-full min-w-0 rounded-full bg-mist border border-transparent py-3 text-[14px] text-ink placeholder:text-ink-soft/45 outline-none focus:border-royal/40 focus:bg-white transition-all"
            style={{ paddingLeft: 18, paddingRight: 18 }}
          />
          <button
            onClick={send}
            disabled={!draft.trim()}
            className="w-12 h-12 shrink-0 rounded-full bg-royal grid place-items-center text-white shadow-[0_8px_20px_rgba(10,108,255,0.45)] disabled:opacity-35 disabled:shadow-none hover:bg-royal-deep active:scale-90 transition-all"
            aria-label="send"
          >
            {I.send(18)}
          </button>
        </div>
      </div>
    </div>
  );
}
