import { useState } from "react";
import { StatusBar } from "../ui";

export default function NameScreen({ onSave }: { onSave: (name: string) => void }) {
  const [name, setName] = useState("");
  const ready = name.trim().length >= 2;

  return (
    <div className="absolute inset-0 flex flex-col bg-mist animate-screen overflow-hidden">
      <StatusBar />
      <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-royal/12 blur-3xl" />
      <div className="absolute -bottom-24 -left-20 w-72 h-72 rounded-full bg-sky/14 blur-3xl" />

      <div className="relative flex-1 flex flex-col px-7 pt-10">
        <img
          src="/icon-512.png"
          alt=""
          className="w-14 h-14 rounded-[16px] shadow-[0_10px_26px_rgba(10,108,255,0.35)]"
        />
        <h1 className="mt-6 font-display font-bold text-[27px] leading-tight text-ink">
          Welcome to MeshLink.
          <br />
          <span className="text-royal">What's your name?</span>
        </h1>
        <p className="mt-2.5 text-[13.5px] leading-relaxed text-ink-soft">
          This name is shown to phones near you. No account, no phone number,
          no internet — just a name and you are in.
        </p>

        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => ready && e.key === "Enter" && onSave(name.trim())}
          placeholder="e.g. Aryan"
          maxLength={16}
          autoFocus
          className="mt-8 w-full rounded-2xl bg-white border border-royal/20 px-5 py-4 text-[16px] font-semibold text-ink placeholder:text-ink-soft/40 outline-none focus:border-royal focus:shadow-[0_0_0_4px_rgba(10,108,255,0.14)] transition-all"
        />

        <button
          onClick={() => ready && onSave(name.trim())}
          disabled={!ready}
          className="mt-4 w-full rounded-2xl bg-royal text-white font-bold text-[15.5px] py-4 shadow-[0_12px_30px_rgba(10,108,255,0.45)] disabled:opacity-40 disabled:shadow-none hover:bg-royal-deep active:scale-[0.98] transition-all"
        >
          Get started
        </button>

        <div className="mt-auto pb-8 flex items-center justify-center gap-2 text-[11px] font-mono text-ink-soft/60">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          100% offline — your data never leaves this phone
        </div>
      </div>
    </div>
  );
}
