import { useEffect, useState } from "react";
import { StatusBar } from "../ui";

const STEPS: [number, string][] = [
  [8, "Starting MeshLink…"],
  [34, "Checking radios…"],
  [62, "Bluetooth ready"],
  [86, "Wi-Fi Direct ready"],
  [100, "All set — let's go"],
];

export default function Splash({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  const [label, setLabel] = useState(STEPS[0][1]);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    const marks = [350, 1050, 1750, 2350, 2750];
    STEPS.forEach(([p, text], i) => {
      timers.push(
        setTimeout(() => {
          setProgress(p);
          setLabel(text);
        }, marks[i])
      );
    });
    timers.push(setTimeout(onDone, 3250));
    return () => timers.forEach(clearTimeout);
  }, [onDone]);

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-gradient-to-b from-panel via-ink to-royal-deep text-white">
      <StatusBar dark />

      <div className="flex-1 grid place-items-center relative overflow-hidden">
        <div className="absolute w-[340px] h-[340px] rounded-full border border-sky/15" />
        <div className="absolute w-[240px] h-[240px] rounded-full border border-sky/20" />
        {[0, 0.8, 1.6].map((d) => (
          <span
            key={d}
            className="absolute w-[150px] h-[150px] rounded-full border-2 border-sky/40 animate-ring"
            style={{ animationDelay: `${d}s` }}
          />
        ))}

        <div className="relative flex flex-col items-center animate-logo">
          <img
            src="/icon-512.png"
            alt="MeshLink logo"
            className="w-[104px] h-[104px] rounded-[26px] shadow-[0_18px_50px_rgba(46,155,255,0.45)]"
          />
          <div className="mt-6 font-display font-bold text-[30px] tracking-tight">
            Mesh<span className="text-sky">Link</span>
          </div>
          <div className="mt-1.5 font-mono text-[11.5px] text-ice/85 tracking-[0.14em]">
            NO INTERNET · NO SIM · JUST PHONES
          </div>
        </div>
      </div>

      <div className="px-10 pb-12">
        <div className="h-[7px] rounded-full bg-white/12 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-sky to-royal shimmer transition-all duration-700 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mt-3 flex items-center justify-between">
          <span className="text-[11.5px] text-ice/90 font-medium">{label}</span>
          <span className="font-mono text-[11px] text-ice/70">{progress}%</span>
        </div>
      </div>
    </div>
  );
}
