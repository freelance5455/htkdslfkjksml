import raw from "./catalog.json";

export interface CatalogMovie {
  qid: string;
  title: string;
  desc: string;
  year: number | null;
  image: string | null;
  imdb: string | null;
  genres: string[];
  director: string | null;
  kids: boolean;
}
export interface CatalogSeries {
  id: number;
  name: string;
  genres: string[];
  premiered: string | null;
  year: number | null;
  status: string;
  network: string | null;
  rating: number | null;
  image: string | null;
  summary: string;
  url: string;
  kids: boolean;
}

const data = raw as unknown as { movies: CatalogMovie[]; series: CatalogSeries[]; fetched: string };

export const MOVIES = data.movies;
export const SERIES = data.series;
export const CATALOG_FETCHED = data.fetched;
export const KIDS_MOVIES = MOVIES.filter((m) => m.kids);
export const KIDS_SERIES = SERIES.filter((s) => s.kids);

/** Deterministic hue from a string — used for typographic poster tiles. */
export function hueOf(seed: string): number {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return h % 360;
}

export function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "";
  const s = Math.max(0, Math.floor((Date.now() - then) / 1000));
  if (s < 3600) return `hace ${Math.max(1, Math.floor(s / 60))} min`;
  if (s < 86400) return `hace ${Math.floor(s / 3600)} h`;
  return `hace ${Math.floor(s / 86400)} d`;
}
