import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import Header from "@/components/Header";
import PwaRegister from "@/components/PwaRegister";
import VoiceAssistant from "@/components/VoiceAssistant";
import { LangProvider } from "@/lib/i18n";
import "./globals.css";

export const metadata: Metadata = {
  title: "يوروتيكس | EuroTix – حجز تذاكر السياحة في أوروبا بالصوت",
  description:
    "احجز تذاكر المعالم والرحلات السياحية في أوروبا بسهولة مع مساعد صوتي ذكي. Book European attraction tickets with an AI voice assistant.",
  applicationName: "EuroTix",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "EuroTix", statusBarStyle: "default" },
  icons: { icon: "/icon-192.png", apple: "/icon-192.png" },
};

export const viewport: Viewport = {
  themeColor: "#4f46e5",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className="min-h-screen bg-slate-100 text-slate-900 antialiased">
        <LangProvider>
          <Header />
          <main>{children}</main>
          <VoiceAssistant />
          <PwaRegister />
        </LangProvider>
      </body>
    </html>
  );
}
