import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Crypto Day Trading & AI Hub",
  description:
    "בוט מסחר אוטונומי, סורק רב-טווחי 1m-1w, Copy-Trading, מסחר דמו ומרכז מס — הכל בעברית ובזמן אמת.",
  icons: { icon: "/icon.svg" },
};

export const viewport: Viewport = {
  themeColor: "#0f172a",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="he" dir="rtl">
      <body className="bg-[#0f172a] text-slate-200 antialiased">{children}</body>
    </html>
  );
}
