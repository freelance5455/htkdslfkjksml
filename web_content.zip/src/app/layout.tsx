import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Heebo, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const heebo = Heebo({
  subsets: ["hebrew", "latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-heebo",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "600", "700", "800"],
  variable: "--font-jetbrains",
});

export const metadata: Metadata = {
  title: "זירת הקריפטו AI | סורק שוק, אותות מסחר, Copy Trading, מסחר דמו ומיסוי ישראלי",
  description:
    "מערכת מסחר קריפטו מוסדית בעברית מלאה (RTL): ניתוח טכני דינמי (RSI, MACD, EMA, ATR, Kelly Criterion), סנכרון Bybit V5, חיקוי עסקאות סוחרים, סימולטור דמו $10,000, מפת חום Finviz, מחקר Messari ודיווח מס ישראלי (טופס 909).",
  icons: {
    icon: "/assets/images/crypto_app_icon.png",
    apple: "/assets/images/crypto_app_icon.png",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="he"
      dir="rtl"
      className={`${heebo.variable} ${jetbrainsMono.variable} dark`}
    >
      <body className="min-h-screen bg-[#0B0E14] font-sans text-[#F1F5F9] antialiased selection:bg-[#3B82F6] selection:text-white">
        {children}
      </body>
    </html>
  );
}
