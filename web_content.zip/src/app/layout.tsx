import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Auria AI — Tu espacio para crear",
  description: "Tu asistente de inteligencia artificial para conversar, crear imágenes, escribir, traducir y aprender.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}

