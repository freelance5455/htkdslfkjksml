import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Fraunces, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  style: ["normal", "italic"],
});
const grotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-grotesk",
});
const jetmono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetmono",
});

export const metadata: Metadata = {
  title: "AXIOM — The Crucible of Minds",
  description:
    "Not a game for players. A crucible for minds. 1,100+ trials of pattern cognition, deep science, paradox, strategy and imagination — scored across the Three Pillars of genius.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${grotesk.variable} ${jetmono.variable}`}>
      <body className="bg-void text-ivory antialiased font-sans">
        {children}
        <div className="fx-overlay" />
        <div className="fx-noise" />
      </body>
    </html>
  );
}
