import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { ScrollReveal } from "@/components/scroll-reveal";

export const metadata: Metadata = {
  title: {
    default: "لأنه الله — منصة تعليمية إسلامية",
    template: "%s | لأنه الله",
  },
  description:
    "منصة تعليمية إسلامية: بالعلم نرتقي، وبالذكر نطمئن، وبالإيمان نحيا. تلاوة القرآن، والأذكار، والحديث، والسيرة، وقصص الصحابة، والمسارات التعليمية، والمحاضرات.",
  applicationName: "لأنه الله",
};

const FONTS_HREF =
  "https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="stylesheet" href={FONTS_HREF} />
      </head>
      <body className="min-h-screen bg-ivory font-sans text-navy antialiased">
        <SiteHeader />
        {children}
        <SiteFooter />
        <ScrollReveal />
      </body>
    </html>
  );
}
