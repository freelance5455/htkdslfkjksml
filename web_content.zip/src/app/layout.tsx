import type { Metadata, Viewport } from "next";
import "./globals.css";
import { CartProvider } from "@/lib/cart-context";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "CALCORA 3D | Explore The Future of Calculation",
  description:
    "CALCORA 3D — a premium futuristic 3D calculator and product marketplace. Discover premium models, calculate smarter, shop better. Prices in BDT.",
  keywords: ["calculator", "3d", "marketplace", "CALCORA", "premium models", "Bangladesh"],
};

export const viewport: Viewport = {
  themeColor: "#05060a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#04050a] font-sans text-slate-100 antialiased">
        <CartProvider>
          <Navbar />
          <main className="min-h-screen">{children}</main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  );
}