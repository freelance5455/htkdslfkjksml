import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Creator Toolkit — Create better content in minutes",
  description:
    "AI-powered titles, hooks, scripts, captions, hashtags, thumbnail text, content ideas, calendars and analysis for YouTube, Shorts, TikTok and Instagram Reels creators.",
  applicationName: "Creator Toolkit",
};

export const viewport: Viewport = {
  themeColor: "#070914",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-dvh antialiased">{children}</body>
    </html>
  );
}
