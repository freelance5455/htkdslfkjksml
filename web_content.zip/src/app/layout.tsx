import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Website X-Ray AI – Deep Website Analyzer & Master Prompt Generator",
  description:
    "Production-ready Playwright website inspector, interactive element tester, and AI Master Prompt Generator.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-surface-950 text-zinc-100 antialiased">
        {children}
      </body>
    </html>
  );
}
