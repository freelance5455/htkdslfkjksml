import type { Metadata, Viewport } from "next";
import { cookies } from "next/headers";
import type { ReactNode } from "react";
import "./globals.css";
import { Providers } from "@/components/providers";
import { ensureSeeded } from "@/db/seed";
import { LOCALE_COOKIE, LOCALE_META, normalizeLocale } from "@/lib/constants";
import { getSiteData } from "@/lib/site";

export const metadata: Metadata = {
  title: {
    default: "ShifaCare · شفاء كير — Soins infirmiers à domicile à Fès",
    template: "%s · ShifaCare",
  },
  description:
    "ShifaCare · شفاء كير : soins infirmiers à domicile à Fès, Maroc, et informations de santé fiables en arabe, français et anglais.",
  applicationName: "ShifaCare",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/icons/icon-96.png", sizes: "96x96", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  appleWebApp: {
    capable: true,
    title: "ShifaCare",
    statusBarStyle: "default",
  },
};

export const viewport: Viewport = {
  themeColor: "#0d9488",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const store = await cookies();
  const locale = normalizeLocale(store.get(LOCALE_COOKIE)?.value);
  await ensureSeeded();
  const site = await getSiteData();

  return (
    <html lang={locale} dir={LOCALE_META[locale].dir} suppressHydrationWarning>
      <body className="bg-white text-slate-900 antialiased">
        <Providers initialLocale={locale} initialSite={site}>
          {children}
        </Providers>
      </body>
    </html>
  );
}
