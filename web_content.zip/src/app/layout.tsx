import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import { Noto_Nastaliq_Urdu } from "next/font/google";
import { ConditionalFooter } from "@/components/app-chrome";
import { StaticNav } from "@/components/static-nav";
import { BatBallLogo } from "@/components/cricket";
import { DEVELOPER } from "@/lib/developer";
import { ConnectionProvider } from "@/components/connection";
import { LanguageProvider } from "@/components/lang";
import "./globals.css";

const urdu = Noto_Nastaliq_Urdu({
  subsets: ["arabic"],
  weight: ["400", "600"],
  variable: "--font-urdu",
  display: "swap",
});

export const metadata: Metadata = {
  title: "MATCH CRICKET — Cricket Scoring & Match Statistics",
  description:
    "Professional live cricket scoring, ball-by-ball Urdu commentary and real-time scorecards.",
  authors: [{ name: DEVELOPER.name }],
  creator: DEVELOPER.name,
  applicationName: "MATCH CRICKET",
  keywords: ["cricket scoring", "live cricket score", "Urdu commentary", "cricket scorecard"],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={urdu.variable}>
      <body className="bg-[#070b12] text-slate-100 antialiased">
        <StaticNav />
        <ConnectionProvider>
        <LanguageProvider>
        <header className="sticky top-0 z-50 border-b border-slate-800/80 bg-[#070b12]/85 backdrop-blur">
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-2 px-3 py-1.5 sm:px-4 sm:py-2">
            <Link href="/" className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-900 ring-1 ring-slate-700">
                <BatBallLogo className="h-6 w-6" />
              </span>
              <span className="text-sm font-black tracking-tight sm:text-lg">
                MATCH <span className="text-emerald-400">CRICKET</span>
              </span>
            </Link>
            <nav className="flex shrink-0 items-center gap-0.5 text-sm font-semibold sm:gap-1.5">
              <Link
                href="/"
                className="hidden rounded-lg px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800/70 hover:text-white md:inline-block md:text-sm"
              >
                Home
              </Link>
              <Link
                href="/leagues"
                className="rounded-lg px-2 py-1.5 text-xs text-slate-300 hover:bg-slate-800/70 hover:text-white sm:px-2.5 sm:text-sm"
              >
                Leagues
              </Link>
              <Link
                href="/history"
                className="rounded-lg px-2 py-1.5 text-xs text-slate-300 hover:bg-slate-800/70 hover:text-white sm:px-2.5 sm:text-sm"
              >
                History
              </Link>
              <Link
                href="/new"
                className="rounded-lg bg-emerald-500 px-2.5 py-1.5 text-xs font-bold text-slate-950 hover:bg-emerald-400 sm:text-sm"
              >
                New
              </Link>
            </nav>
          </div>
        </header>
        {children}
        <ConditionalFooter />
        </LanguageProvider>
        </ConnectionProvider>
      </body>
    </html>
  );
}
