import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "NovaBrowser — быстрый браузер с Nova AI",
  description: "Кроссплатформенный браузер с ИИ-ассистентом, блокировкой трекеров и синхронизацией.",
  applicationName: "NovaBrowser",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "NovaBrowser", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#0b1020",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var s=JSON.parse(localStorage.getItem('nova.settings')||'{}');var t=s.theme||'system';var d=t==='dark'||(t==='system'&&matchMedia('(prefers-color-scheme: dark)').matches);if(d)document.documentElement.classList.add('dark');if(s.accent)document.documentElement.style.setProperty('--accent',s.accent);}catch(e){}})();`,
          }}
        />
      </head>
      <body className="h-full bg-slate-100 text-slate-900 antialiased dark:bg-[#0b1020] dark:text-slate-100">{children}</body>
    </html>
  );
}
