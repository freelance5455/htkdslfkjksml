import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "סורק קריפטו AI | מסחר, חיקוי סוחרים ומודיעין שוק",
  description:
    "אפליקציית סריקת קריפטו מתקדמת: אותות AI, ניתוח עומק, חיקוי סוחרים, מסחר דמו, ספר פקודות, מפת שוק, מחקר יסודי וניהול מיסוי ישראלי.",
  icons: { icon: "/crypto_app_icon.png", apple: "/crypto_app_icon.png" },
};

export const viewport: Viewport = {
  themeColor: "#020617",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="he" dir="rtl">
      <body className="min-h-screen bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
