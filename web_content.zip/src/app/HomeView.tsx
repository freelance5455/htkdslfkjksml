import { useEffect, useState } from "react";
import {
  Clapperboard, Clock3, Flame, Heart, MonitorPlay, Play, Radio, Sparkles, Star, Trophy,
  Sun, CloudSun, Cloud, CloudFog, CloudRain, CloudSnow, CloudLightning, Droplets, Wind, MapPin, RefreshCw,
  Popcorn, ChevronLeft, ChevronRight, ChevronDown, Sparkles as SparkIcon,
} from "lucide-react";
import { MOVIES, SERIES, hueOf } from "./catalog";
import { useLocalStorage } from "./useLocalStorage";
import { fetchWeather, skyKind, type WeatherNow } from "./weather";
import { fetchIssPosition, type IssPosition } from "./api";
import { Shuffle, Rocket, Quote } from "lucide-react";

const WALLPAPERS: Record<string, string> = {
  desert: "/img/art-desert.jpg",
  earth: "/img/hero-art.jpg",
  space: "/img/art-space.jpg",
  stadium: "/img/art-stadium.jpg",
  neon: "/img/art-controller.jpg",
  sound: "/img/art-headphones.jpg",
};
const SKY_ICONS = { clear: Sun, partly: CloudSun, cloud: Cloud, fog: CloudFog, rain: CloudRain, snow: CloudSnow, storm: CloudLightning } as const;
function WeatherIcon({ code, size = 22, className = "" }: { code: number; size?: number; className?: string }) {
  const Icon = SKY_ICONS[skyKind(code)];
  return <Icon size={size} className={className} strokeWidth={1.8} />;
}
import { usePrivacyMax } from "./usePrivacyMax";

export interface ContinueItem { kind: "movie" | "series"; id: string; title: string; progress: number }
const SEED_CONTINUE: ContinueItem[] = [
  { kind: "movie", id: "Dune: Part Two", title: "Dune: Parte Dos", progress: 62 },
  { kind: "series", id: "Stranger Things", title: "Stranger Things · S4 E7", progress: 71 },
  { kind: "series", id: "Breaking Bad", title: "Breaking Bad · S5 E14", progress: 84 },
  { kind: "movie", id: "Oppenheimer", title: "Oppenheimer", progress: 88 },
];

export default function HomeView({ profile, onNavigate }: { profile: { name: string }; onNavigate: (route: string) => void }) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Buenos días" : hour < 19 ? "Buenas tardes" : "Buenas noches";
  const pm = usePrivacyMax();
  const [continueList] = useLocalStorage<ContinueItem[]>("lo3-continue", SEED_CONTINUE);
  const [favs] = useLocalStorage<string[]>("lo3-favs", []);
  const featured = MOVIES[0];
  const [wallpaper] = useLocalStorage("lo3-wallpaper", "desert");
  const [weather, setWeather] = useState<WeatherNow | null>(null);
  const [weatherError, setWeatherError] = useState(false);
  const [cityQuery, setCityQuery] = useLocalStorage("lo3-weather-city", "Madrid");
  const [cityInput, setCityInput] = useState("");
  const [iss, setIss] = useState<IssPosition | null>(null);
  const [calCursor, setCalCursor] = useState(() => new Date());
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
  const QUOTE = QUOTES[dayOfYear % QUOTES.length];
  const [apod, setApod] = useState<{ title: string; url: string; explanation: string; media_type: string } | null>(null);
  const [apodOpen, setApodOpen] = useState(false);

  useEffect(() => {
    let alive = true;
    setWeatherError(false);
    fetchWeather(cityQuery).then((w) => { if (alive) setWeather(w); }).catch(() => { if (alive) setWeatherError(true); });
    return () => { alive = false; };
  }, [cityQuery]);

  useEffect(() => {
    let alive = true;
    const today = new Date().toISOString().slice(0, 10);
    try {
      const raw = window.localStorage.getItem("lo3-apod");
      if (raw) { const c = JSON.parse(raw) as { date: string; title: string; url: string; explanation: string; media_type: string }; if (c.date === today) { setApod(c); return () => { alive = false; }; } }
    } catch { /* no cache */ }
    fetch("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&thumbs=true")
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error("apod"))))
      .then((d: { title?: string; url?: string; hdurl?: string; explanation?: string; media_type?: string }) => {
        if (!alive || !d?.url) return;
        const item = { date: today, title: d.title ?? "NASA", url: d.url, explanation: d.explanation ?? "", media_type: d.media_type ?? "image" };
        setApod(item);
        try { window.localStorage.setItem("lo3-apod", JSON.stringify(item)); } catch { /* quota */ }
      })
      .catch(() => {});
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    let alive = true;
    const poll = () => fetchIssPosition().then((p) => { if (alive) setIss(p); }).catch(() => {});
    poll();
    const id = window.setInterval(poll, 10000);
    return () => { alive = false; window.clearInterval(id); };
  }, []);

  const resolveTitle = (id: string) =>
    MOVIES.find((m) => m.title === id)?.title ?? SERIES.find((s) => String(s.id) === id)?.name ?? id;

  return (
    <div className="flex h-full flex-col gap-4 overflow-y-auto p-4 thin-scroll sm:p-5">
      {/* ── hero banner ───────────────────────────────────────── */}
      <section className="relative min-h-[210px] overflow-hidden rounded-2xl border border-white/10 sm:min-h-[230px]" aria-label="Destacado">
        <img src={WALLPAPERS[wallpaper] ?? WALLPAPERS.desert} alt="Fondo de pantalla de TV LO3" className="absolute inset-0 h-full w-full object-cover object-[62%_38%]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#04061a]/95 via-[#04061a]/60 to-transparent" />
        <div className="relative flex h-full max-w-md flex-col justify-center gap-2 p-5 sm:p-6">
          <p className="eyebrow">Estreno de la casa</p>
          <h1 className="font-display text-3xl font-black leading-[1.02] text-white sm:text-4xl">{greeting}, {profile.name}.</h1>
          <p className="text-sm text-slate-200">Hoy manda <strong>{featured.title}</strong> ({featured.year}) — {featured.genres.slice(0, 2).join(" · ")}. Tu próxima maratón empieza aquí.</p>
          <div className="mt-1.5 flex flex-wrap gap-2">
            <button onClick={() => onNavigate("movies")} className="grad-btn flex h-11 items-center gap-2 rounded-xl px-4 text-sm font-bold text-white"><Play size={17} fill="currentColor" /> Ver ficha</button>
            <button onClick={() => onNavigate("worldtv")} className="ghost-btn flex h-11 items-center gap-2 rounded-xl px-4 text-sm font-semibold text-white"><Radio size={17} className="text-cyanx" /> World TV en vivo</button>
            <button onClick={() => { const pool = [...MOVIES, ...SERIES.map((sr) => ({ title: sr.name, target: "series" as const }))]; const pick = pool[Math.floor(Math.random() * pool.length)]; onNavigate((pick as { target?: string }).target ?? "movies"); }} className="ghost-btn flex h-11 items-center gap-2 rounded-xl px-4 text-sm font-semibold text-white" aria-label="Sorpréndeme"><Shuffle size={16} className="text-lilac" /> Sorpréndeme</button>
          </div>
        </div>
      </section>

      {/* ── clima real ───────────────────────────────────────── */}
      {weather && !weatherError && (
        <section className="flex flex-wrap items-center gap-3 rounded-2xl border border-white/10 bg-gradient-to-r from-sky-500/10 via-cyanx/5 to-violetx/10 px-4 py-2.5" aria-label="Clima">
          <WeatherIcon code={weather.code} size={38} className="shrink-0 text-cyanx" />
          <div className="min-w-0">
            <p className="font-display text-2xl font-black leading-none text-white">{Math.round(weather.tempC)}°<span className="text-sm font-bold text-slate-400">C</span></p>
            <p className="mt-0.5 max-w-36 truncate text-[9px] font-semibold capitalize text-slate-400">{weather.desc}</p>
          </div>
          <div className="hidden flex-wrap gap-x-4 gap-y-1 border-l border-white/10 pl-4 text-[9px] text-slate-400 sm:flex">
            <span className="flex items-center gap-1"><Droplets size={11} className="text-sky-400" />{weather.humidity}% humedad</span>
            <span className="flex items-center gap-1"><Wind size={11} className="text-emerald-400" />{weather.windKmph} km/h</span>
            <span className="flex items-center gap-1">Sens. térmica {Math.round(weather.feelsC)}°</span>
            {iss && <a href="https://wheretheiss.at/satellite/25544" target="_blank" rel="noopener noreferrer" title="Estación Espacial Internacional en vivo" className="hidden items-center gap-1 lg:flex"><Rocket size={11} className="text-violet-300" />ISS · {Math.round(iss.velocity).toLocaleString("es-ES")} km/h · {Math.round(iss.altitude)} km</a>}
          </div>
          <div className="ml-auto flex items-center gap-3">
            <div className="hidden gap-3 md:flex">
              {weather.days.slice(0, 3).map((d) => (
                <div key={d.date} className="flex flex-col items-center gap-0.5 text-center">
                  <span className="text-[8px] font-bold uppercase tracking-wider text-slate-500">{new Date(d.date + "T00:00:00").toLocaleDateString("es-ES", { weekday: "short" })}</span>
                  <WeatherIcon code={d.code} size={15} className="text-slate-300" />
                  <span className="text-[9px] font-bold tabular-nums text-slate-200">{Math.round(d.maxC)}°<span className="text-slate-500">/{Math.round(d.minC)}°</span></span>
                </div>
              ))}
            </div>
            <form onSubmit={(e) => { e.preventDefault(); const q = cityInput.trim(); if (q) { setCityQuery(q); setCityInput(""); } }} className="flex items-center gap-1.5">
              <MapPin size={12} className="shrink-0 text-slate-500" aria-hidden="true" />
              <label htmlFor="weather-city" className="sr-only">Ciudad para el clima</label>
              <input id="weather-city" value={cityInput} onChange={(e) => setCityInput(e.target.value)} placeholder={weather.city} className="h-8 w-24 rounded-lg border border-white/10 bg-black/30 px-2 text-[10px] text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-cyanx/50" />
              <button type="submit" aria-label="Cambiar ciudad" className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-400 hover:text-white"><RefreshCw size={12} /></button>
            </form>
          </div>
        </section>
      )}

      {/* ── continuar viendo ──────────────────────────────────── */}
      <section aria-labelledby="continue-title">
        <div className="mb-2 flex items-center justify-between">
          <h2 id="continue-title" className="flex items-center gap-2 text-sm font-bold uppercase tracking-[0.18em] text-slate-300"><Clock3 size={15} className="text-cyanx" /> Continuar viendo</h2>
          <button onClick={() => onNavigate("movies")} className="text-[11px] font-semibold text-cyanx hover:underline">Ver todo →</button>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {continueList.slice(0, 4).map((item, i) => (
            <button key={i} onClick={() => onNavigate(item.kind === "movie" ? "movies" : "series")} className="group relative overflow-hidden rounded-xl border border-white/10 bg-panel2 p-3 text-left transition-colors hover:border-cyanx/40">
              <div className="flex items-start justify-between gap-2">
                <p className="line-clamp-2 text-xs font-bold leading-snug text-slate-100">{item.title}</p>
                <Play size={14} className="mt-0.5 shrink-0 text-cyanx opacity-70 transition-transform group-hover:scale-125" fill="currentColor" />
              </div>
              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10">
                <div className="h-full rounded-full bg-gradient-to-r from-cyanx to-violetx" style={{ width: `${item.progress}%` }} />
              </div>
              <p className="mt-1.5 text-[9px] font-semibold uppercase tracking-wider text-slate-500">{item.progress}% completado</p>
            </button>
          ))}
        </div>
      </section>

      {/* ── favoritos ─────────────────────────────────────────── */}
      {favs.length > 0 && (
        <section aria-labelledby="favs-title">
          <h2 id="favs-title" className="mb-2 flex items-center gap-2 text-sm font-bold uppercase tracking-[0.18em] text-slate-300"><Heart size={15} className="text-rose-400" /> Tus favoritos</h2>
          <div className="flex gap-2 overflow-x-auto pb-1 thin-scroll">
            {favs.slice(0, 10).map((id) => (
              <button key={id} onClick={() => onNavigate("movies")} className="chip whitespace-nowrap hover:border-rose-400/50">{resolveTitle(id)}</button>
            ))}
          </div>
        </section>
      )}

      {/* ── recomendado ───────────────────────────────────────── */}
      <section aria-labelledby="rec-title">
        <div className="mb-2 flex items-center justify-between">
          <h2 id="rec-title" className="flex items-center gap-2 text-sm font-bold uppercase tracking-[0.18em] text-slate-300"><Flame size={15} className="text-amber-400" /> Recomendado para ti</h2>
          <button onClick={() => onNavigate("movies")} className="text-[11px] font-semibold text-cyanx hover:underline">Catálogo completo →</button>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 thin-scroll">
          {MOVIES.slice(1, 15).map((m) => {
            const hue = hueOf(m.qid);
            return (
              <button key={m.qid} onClick={() => onNavigate("movies")} className="group relative h-36 w-24 shrink-0 overflow-hidden rounded-xl border border-white/10 text-left transition-transform hover:-translate-y-1" style={{ background: `linear-gradient(165deg, hsl(${hue} 55% 38%), hsl(${(hue + 40) % 360} 65% 16%))` }}>
                <span className="absolute inset-0 flex flex-col justify-between p-2">
                  <span className="text-[8px] font-black uppercase tracking-widest text-white/60">{m.year}</span>
                  <span className="font-display text-[11px] font-bold leading-tight text-white">{m.title}</span>
                </span>
                <span className="absolute inset-0 flex items-center justify-center bg-black/0 transition-colors group-hover:bg-black/40"><Play size={22} className="text-white opacity-0 transition-opacity group-hover:opacity-100" fill="white" /></span>
              </button>
            );
          })}
        </div>
      </section>

      {/* ── series en seguimiento ─────────────────────────────── */}
      <section aria-labelledby="series-title">
        <div className="mb-2 flex items-center justify-between">
          <h2 id="series-title" className="flex items-center gap-2 text-sm font-bold uppercase tracking-[0.18em] text-slate-300"><Clapperboard size={15} className="text-violet-300" /> Series en antena</h2>
          <button onClick={() => onNavigate("series")} className="text-[11px] font-semibold text-cyanx hover:underline">Ver todas →</button>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 thin-scroll">
          {SERIES.slice(0, 12).map((s) => (
            <button key={s.id} onClick={() => onNavigate("series")} className="group w-20 shrink-0 text-left">
              <div className="relative aspect-[2/3] overflow-hidden rounded-xl border border-white/10">
                {!pm && s.image ? <img src={s.image} alt={`Póster de ${s.name}`} loading="lazy" className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")} /> : null}
                <span className="absolute inset-0 -z-0 flex items-end bg-gradient-to-t from-black/80 to-transparent p-1.5"><span className="text-[8px] font-bold leading-tight text-white">{s.name}</span></span>
                {s.rating != null && <span className="absolute right-1 top-1 flex items-center gap-0.5 rounded bg-black/70 px-1 py-0.5 text-[8px] font-bold text-gold"><Star size={8} fill="currentColor" />{s.rating}</span>}
              </div>
            </button>
          ))}
        </div>
      </section>

      <div className="grid gap-2 md:grid-cols-[1fr_auto]">
        {/* frase del día */}
        <figure className="flex items-start gap-3 rounded-2xl border border-white/8 bg-white/[0.02] px-4 py-3">
          <Quote size={16} className="mt-0.5 shrink-0 text-violet-300/70" aria-hidden="true" />
          <blockquote>
            <p className="text-[12px] italic leading-snug text-slate-300">“{QUOTE.text}”</p>
            <figcaption className="mt-1 text-[9px] font-bold uppercase tracking-[0.2em] text-slate-500">{QUOTE.author}</figcaption>
          </blockquote>
        </figure>
        {/* mini calendario */}
        <MiniCalendar cursor={calCursor} onChange={setCalCursor} />
      </div>

      {/* ── cosmos hoy (NASA APOD) ──────────────────────────── */}
      {apod && (
        <section className="relative overflow-hidden rounded-2xl border border-violetx/30" aria-label="Imagen astronómica del día">
          {apod.media_type === "image"
            ? <img src={apod.url} alt={apod.title} loading="lazy" className="absolute inset-0 h-full w-full object-cover object-center" onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")} />
            : <div className="absolute inset-0 bg-gradient-to-br from-panel2 to-abyss" />}
          <div className="absolute inset-0 bg-gradient-to-r from-[#04061a]/92 via-[#04061a]/55 to-transparent" />
          <div className="relative flex flex-col justify-center gap-1.5 p-4 sm:p-5">
            <p className="flex items-center gap-1.5 text-[8px] font-black uppercase tracking-[0.3em] text-violet-300"><SparkIcon size={10} /> NASA · Imagen del cosmos</p>
            <h2 className="max-w-md font-display text-lg font-black leading-tight text-white sm:text-xl">{apod.title}</h2>
            {apodOpen && <p className="max-h-24 max-w-md overflow-y-auto text-[10px] leading-snug text-slate-300 thin-scroll">{apod.explanation}</p>}
            <button onClick={() => setApodOpen((v) => !v)} className="mt-1 flex w-max items-center gap-1 rounded-lg border border-white/15 bg-black/40 px-2.5 py-1.5 text-[9px] font-bold uppercase tracking-wider text-slate-200 backdrop-blur-sm transition-colors hover:text-white" aria-expanded={apodOpen}>{apodOpen ? "Ocultar" : "Leer"} <ChevronDown size={11} className={`transition-transform ${apodOpen ? "rotate-180" : ""}`} /></button>
          </div>
        </section>
      )}

      {/* ── accesos rápidos ───────────────────────────────────── */}
      <section className="grid grid-cols-3 gap-2 sm:grid-cols-6" aria-label="Accesos rápidos">
        {[
          { icon: Trophy, label: "Deportes", route: "sports" },
          { icon: Clapperboard, label: "Movies", route: "movies" },
          { icon: MonitorPlay, label: "Series", route: "series" },
          { icon: Radio, label: "Radio", route: "radio" },
          { icon: Sparkles, label: "TV LO3 AI", route: "ai" },
          { icon: Popcorn, label: "Gratis", route: "gratis" },
        ].map(({ icon: Icon, label, route }, i) => (
          <button key={i} onClick={() => onNavigate(route)} className="tile flex flex-col items-center justify-center gap-1.5 rounded-xl py-3 text-slate-300 hover:text-white">
            <Icon size={19} strokeWidth={1.8} />
            <span className="text-[10px] font-bold">{label}</span>
          </button>
        ))}
      </section>
    </div>
  );
}
function MiniCalendar({ cursor, onChange }: { cursor: Date; onChange: (d: Date) => void }) {
  const y = cursor.getFullYear();
  const m = cursor.getMonth();
  const today = new Date();
  const firstDow = (new Date(y, m, 1).getDay() + 6) % 7; // lunes primero
  const days = new Date(y, m + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(firstDow).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  const monthName = cursor.toLocaleDateString("es-ES", { month: "long", year: "numeric" });
  const shift = (delta: number) => onChange(new Date(y, m + delta, 1));
  return (
    <div className="w-56 rounded-2xl border border-white/8 bg-white/[0.02] p-3" aria-label="Calendario">
      <div className="flex items-center justify-between gap-2">
        <button onClick={() => shift(-1)} aria-label="Mes anterior" className="rounded-lg p-1.5 text-slate-500 hover:bg-white/5 hover:text-white"><ChevronLeft size={15} /></button>
        <p className="text-[11px] font-bold capitalize text-slate-200">{monthName}</p>
        <button onClick={() => shift(1)} aria-label="Mes siguiente" className="rounded-lg p-1.5 text-slate-500 hover:bg-white/5 hover:text-white"><ChevronRight size={15} /></button>
      </div>
      <div className="mt-1.5 grid grid-cols-7 gap-0.5 text-center text-[8px] font-black uppercase tracking-wider text-slate-600">
        {["L", "M", "X", "J", "V", "S", "D"].map((d) => <span key={d}>{d}</span>)}
      </div>
      <div className="mt-0.5 grid grid-cols-7 gap-0.5 text-center text-[9px] font-semibold">
        {cells.map((d, i) => {
          const isToday = d === today.getDate() && m === today.getMonth() && y === today.getFullYear();
          return <span key={i} className={`flex h-6 w-6 items-center justify-center rounded-md ${isToday ? "bg-electric font-black text-white" : d ? "text-slate-400" : ""}`}>{d ?? ""}</span>;
        })}
      </div>
    </div>
  );
}

const QUOTES = [
  { text: "En un lugar de la Mancha, de cuyo nombre no quiero acordarme.", author: "Miguel de Cervantes · Don Quijote" },
  { text: "Se hace camino al andar.", author: "Antonio Machado" },
  { text: "Polvo serán, mas polvo enamorado.", author: "Francisco de Quevedo" },
  { text: "¿Qué es la vida? Una ilusión, una sombra, una ficción.", author: "Calderón de la Barca · La vida es sueño" },
  { text: "Nada te turbe, nada te espante; todo se pasa, Dios no se muda.", author: "Santa Teresa de Jesús" },
  { text: "Lo bueno, si breve, dos veces bueno.", author: "Baltasar Gracián" },
  { text: "Más sabe el necio en su casa que el sabio en la ajena.", author: "Refrán popular" },
  { text: "Donde hay gana hay camino.", author: "Refrán popular" },
  { text: "La pluma es animal de mucha malicia.", author: "Refrán popular" },
  { text: "No hay mayor desprecio que no hacer aprecio.", author: "Refrán popular" },
];
