"use client";

import { QueryIdRoute } from "@/components/query-route";
import ScorerClient from "./scorer-client";

/**
 * Scoring screen. The match id travels as `?id=…` rather than a path segment
 * so the app can be statically exported as flat HTML for an Android WebView.
 */
export default function ScorerPage() {
  return (
    <QueryIdRoute emptyTitle="No match selected." backHref="/" backLabel="Back to matches">
      {(id) => <ScorerClient id={id} />}
    </QueryIdRoute>
  );
}
