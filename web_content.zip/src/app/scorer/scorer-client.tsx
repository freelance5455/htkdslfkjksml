"use client";

import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { useMatch } from "@/lib/useMatch";
import { LanguageSelect, langClass, useLang, usePhrase } from "@/components/lang";
import type { Awards, DismissalType, Player } from "@/lib/types";
import { computeAwards, oversStr, squadOf } from "@/lib/engine";
import {
  BatBallLogo,
  BatIcon,
  CommentaryIcon,
  HistoryIcon,
  PlayerAvatar,
  ScorecardIcon,
  TrophyIcon,
} from "@/components/cricket";
import {
  BattingTable,
  BowlingTable,
  CommentaryList,
  CurrentOverStrip,
  CurrentPlayersPanel,
  ExtrasCard,
  FallOfWickets,
  MatchAwards,
  MatchHeader,
  MatchResultPanel,
  MatchStatsPanel,
  OverAnalysis,
  PartnershipPanel,
  PlayerProfileProvider,
  ScoreHeader,
} from "@/components/match-ui";
import {
  CommentaryAnnouncer,
  CommentaryAudioDock,
  CommentaryAudioProvider,
  ReplayButton,
  SpeakerIndicator,
  useVoice,
} from "@/components/voice";

type ScorerView = "scoring" | "scoreboard" | "commentary";

type Modal =
  | null
  | { kind: "extra"; extra: "wide" | "noball" | "bye" | "legbye" }
  | { kind: "wicket" }
  | { kind: "bowler" }
  | { kind: "batter" }
  | { kind: "startInnings" }
  | { kind: "undo" }
  | { kind: "endInnings" }
  | { kind: "awards" };

const DISMISSALS: DismissalType[] = [
  "Bowled",
  "Caught",
  "LBW",
  "Run Out",
  "Stumped",
  "Hit Wicket",
  "Other",
];

export default function ScorerClient({ id }: { id: string }) {
  return (
    <CommentaryAudioProvider>
      <ScorerInner id={id} />
      <CommentaryAudioDock />
    </CommentaryAudioProvider>
  );
}

/** Raises floating docks above the fixed bottom nav while this screen is open. */
function useBottomNavSpacing() {
  useEffect(() => {
    document.body.classList.add("mc-has-bottom-nav");
    return () => document.body.classList.remove("mc-has-bottom-nav");
  }, []);
}

function ScorerInner({ id }: { id: string }) {
  useBottomNavSpacing();
  const { lang } = useLang();
  const t = usePhrase();
  const { state, error, busy, send, undo, isLocal, missing, updateAwards } = useMatch(id, 5000);
  const { settings } = useVoice();
  /** Wraps send() so any rejection is shown to the scorer instead of failing silently. */
  const dispatch = async (event: Parameters<typeof send>[0]) => {
    const problem = await send(event);
    setActionError(problem);
    return problem === null;
  };
  /**
   * UI-only view switch. All three views read the SAME live match state from
   * useMatch() — this is a navigation split, never a data split.
   */
  const [view, setView] = useState<ScorerView>("scoring");
  const [modal, setModal] = useState<Modal>(null);
  const [extraRuns, setExtraRuns] = useState(0);
  const [nbBat, setNbBat] = useState(0);
  const [wk, setWk] = useState<{
    dismissal: DismissalType;
    who: "striker" | "nonStriker";
    fielder: string;
    newBatter: string;
    runs: number;
  }>({ dismissal: "Bowled", who: "striker", fielder: "", newBatter: "", runs: 0 });
  const [newBowler, setNewBowler] = useState("");
  const [incomingBatter, setIncomingBatter] = useState("");
  const [actionError, setActionError] = useState<string | null>(null);
  const [si, setSi] = useState({ batter1: "", batter2: "", bowler: "" });
  const [awardsDraft, setAwardsDraft] = useState<Awards | null>(null);
  const [savingAwards, setSavingAwards] = useState(false);

  if (missing && !state) {
    return (
      <main className="mx-auto max-w-3xl px-4 py-16 text-center">
        <p className="text-lg font-bold text-red-400">
          This match is not stored on this device and could not be loaded from the cloud.
        </p>
        <Link href="/" className="mt-4 inline-block text-emerald-400 underline">
          Back to matches
        </Link>
      </main>
    );
  }
  if (!state) return <main className="px-4 py-20 text-center text-slate-400">Loading match…</main>;

  const inn = state.innings[state.currentInnings];
  const bowlingSquad = squadOf(state.setup, inn.bowlingTeam);
  const nextBattingSquad = squadOf(state.setup, state.innings[1].battingTeam);
  const nextBowlingSquad = squadOf(state.setup, state.innings[1].bowlingTeam);
  const allPlayers = [...state.setup.playersA, ...state.setup.playersB];

  /** Batting-side names that may come in: never out, not already at the crease. */
  const availableBatters: NameOption[] = squadOf(state.setup, inn.battingTeam)
    .filter((p) => {
      const stat = inn.batters.find((b) => b.name === p.name);
      return !stat?.out && p.name !== inn.striker && p.name !== inn.nonStriker;
    })
    .map((p) => {
      const stat = inn.batters.find((b) => b.name === p.name);
      return {
        name: p.name,
        note: stat ? `${stat.runs} (${stat.balls}) not out` : "yet to bat",
      };
    });

  /**
   * Every bowler who has already bowled, with their figures, plus the rest of
   * the fielding side. The bowler of the previous over is excluded because a
   * bowler may not deliver two consecutive overs.
   */
  const availableBowlers: NameOption[] = (() => {
    const used = inn.bowlers.map((b) => ({
      name: b.name,
      note: `${oversStr(b.balls)} ov · ${b.runs} runs · ${b.wickets} wkt${b.wickets === 1 ? "" : "s"}`,
    }));
    const rest = bowlingSquad
      .filter((p) => !inn.bowlers.some((b) => b.name === p.name))
      .map((p) => ({ name: p.name, note: "has not bowled" }));
    return [...used, ...rest].filter((o) => !(inn.needNewBowler && o.name === inn.bowler));
  })();

  const lastOver = inn.overs[inn.overs.length - 1];
  // Awards are derived from the live match state, never entered by hand.
  const autoAwards = computeAwards(state);

  const locked =
    state.status !== "live" ||
    inn.completed ||
    inn.needNewBowler ||
    inn.needNewBatter !== null ||
    busy;

  async function saveAwards(next: Awards) {
    setSavingAwards(true);
    try {
      await updateAwards(next);
    } finally {
      setSavingAwards(false);
    }
  }

  const draft: Awards = awardsDraft ?? state.awards;

  const runBtn = (n: number) => (
    <button
      key={n}
      disabled={locked}
      onClick={() => void dispatch({ type: "run", runs: n })}
      className={`mc-btn flex h-12 items-center justify-center rounded-xl text-lg font-black disabled:opacity-40 sm:h-14 sm:text-xl ${
        n === 4
          ? "bg-sky-500 text-white hover:bg-sky-400"
          : n === 6
            ? "bg-violet-500 text-white hover:bg-violet-400"
            : "bg-slate-800 text-slate-100 hover:bg-slate-700"
      }`}
    >
      {n}
    </button>
  );

  return (
    <PlayerProfileProvider state={state}>
      <CommentaryAnnouncer state={state} />
      <main className="mx-auto max-w-7xl px-3 pb-28 pt-3 sm:px-4 sm:pb-8 sm:pt-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h1 className="flex items-center gap-1.5 text-base font-black tracking-tight sm:text-xl">
              <BatBallLogo className="h-5 w-5" />
              SCORING
            </h1>
            <p className="text-[11px] text-slate-400 sm:text-xs">
              {state.setup.teamA} vs {state.setup.teamB} · {state.setup.format} ·{" "}
              {state.setup.overs} overs
              {isLocal && (
                <span className="ml-1.5 rounded bg-slate-800 px-1 py-px text-[9px] font-bold tracking-wide text-slate-500">
                  LOCAL
                </span>
              )}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => {
                setAwardsDraft(state.awards);
                setModal({ kind: "awards" });
              }}
              className="mc-btn inline-flex h-9 items-center gap-1.5 rounded-lg border border-amber-500/50 px-3 text-xs font-bold text-amber-300 hover:bg-amber-500/10"
            >
              <TrophyIcon className="h-[18px] w-[18px]" /> Awards
            </button>
            <button
              onClick={() => setModal({ kind: "undo" })}
              className="mc-btn inline-flex h-9 items-center rounded-lg border border-amber-500/50 bg-amber-500/10 px-3 text-xs font-black text-amber-300 hover:bg-amber-500/20"
            >
              UNDO
            </button>
            {state.status === "live" && !inn.completed && (
              <button
                onClick={() => setModal({ kind: "endInnings" })}
                className="mc-btn inline-flex h-9 items-center rounded-lg border border-slate-700 px-3 text-xs font-black text-slate-300 hover:bg-slate-800"
              >
                END INNINGS
              </button>
            )}
          </div>
        </div>

        {/* ---------- Section navigation ---------- */}
        <ScorerNav view={view} onChange={setView} />

        {/* ---------- SCORING : fast, compact, its own scroll area ---------- */}
        {view === "scoring" && (
          // Professional console width: controls stay appropriately sized on
          // desktop instead of stretching across the whole page.
          <section className="mc-section mx-auto max-w-3xl space-y-3 lg:max-w-4xl">
          <div className="sticky top-[57px] z-30">
            <ScoreHeader state={state} />
          </div>
          <CurrentPlayersPanel state={state} />
          <CurrentOverStrip inn={inn} />

          {settings.textCommentary && state.commentary[0] && (
            <div className="mc-card px-4 py-3">
              <div className="mb-1.5 flex items-center justify-between">
                <p className="text-xs font-bold uppercase tracking-widest text-slate-400">
                  Last ball
                </p>
                <div className="flex items-center gap-1.5">
                  <LanguageSelect compact />
                  <SpeakerIndicator />
                  <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-black text-slate-400">
                    {state.commentary[0].ballRef}
                  </span>
                  <ReplayButton text={t(state.commentary[0].texts)} />
                </div>
              </div>
              <p className={`${langClass(lang)} text-[15px] text-slate-100`}>
                {t(state.commentary[0].texts)}
              </p>
            </div>
          )}

          {state.status === "innings-break" && (
            <button
              onClick={() => setModal({ kind: "startInnings" })}
              className="mc-btn w-full rounded-xl bg-emerald-500 px-4 py-3 text-sm font-black text-slate-950 sm:text-base"
            >
              Start Second Innings — Target {state.innings[1].target}
            </button>
          )}
          {actionError && (
            <div className="mc-pop flex items-start gap-3 rounded-xl border border-red-500/50 bg-red-500/10 px-4 py-3">
              <span className="text-lg leading-none">⚠️</span>
              <p className="flex-1 text-sm font-semibold text-red-200">{actionError}</p>
              <button
                onClick={() => setActionError(null)}
                className="text-red-300 hover:text-white"
              >
                ✕
              </button>
            </div>
          )}

          {inn.needNewBatter && state.status === "live" && !inn.completed && (
            <button
              onClick={() => {
                setIncomingBatter("");
                setModal({ kind: "batter" });
              }}
              className="mc-btn w-full rounded-xl bg-red-600 px-4 py-3 text-sm font-black text-white sm:text-base"
            >
              Wicket fell — Send in the next batter
            </button>
          )}
          {inn.needNewBowler && state.status === "live" && (
            <button
              onClick={() => {
                setNewBowler("");
                setModal({ kind: "bowler" });
              }}
              className="mc-btn w-full rounded-xl bg-amber-500 px-4 py-3 text-sm font-black text-slate-950 sm:text-base"
            >
              Over complete — Select next bowler
            </button>
          )}
          {state.status === "completed" && <MatchResultPanel state={state} matchId={id} />}

          <div className="mc-card px-3 py-4">
            <p className="mb-3 px-1 text-xs font-bold uppercase tracking-widest text-slate-400">
              Runs off the bat
            </p>
            <div className="grid grid-cols-4 gap-2 sm:grid-cols-7">
              {[0, 1, 2, 3, 4, 5, 6].map(runBtn)}
            </div>

            <p className="mb-3 mt-5 px-1 text-xs font-bold uppercase tracking-widest text-slate-400">
              Extras
            </p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {(
                [
                  ["wide", "WIDE"],
                  ["noball", "NO BALL"],
                  ["bye", "BYE"],
                  ["legbye", "LEG BYE"],
                ] as const
              ).map(([k, label]) => (
                <button
                  key={k}
                  disabled={locked}
                  onClick={() => {
                    setExtraRuns(k === "bye" || k === "legbye" ? 1 : 0);
                    setNbBat(0);
                    setModal({ kind: "extra", extra: k });
                  }}
                  className="mc-btn h-11 rounded-xl border border-amber-500/40 bg-amber-500/10 text-[11px] font-black tracking-wide text-amber-300 hover:bg-amber-500/20 disabled:opacity-40 sm:text-xs"
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="mx-auto mt-3 grid max-w-md grid-cols-2 gap-2">
              <button
                disabled={locked}
                onClick={() => {
                  setWk({
                    dismissal: "Bowled",
                    who: "striker",
                    fielder: "",
                    newBatter: inn.yetToBat[0] ?? "",
                    runs: 0,
                  });
                  setModal({ kind: "wicket" });
                }}
                className="mc-btn h-12 rounded-xl bg-red-600 text-base font-black text-white hover:bg-red-500 disabled:opacity-40"
              >
                WICKET
              </button>
              <button
                disabled={locked}
                onClick={() => void dispatch({ type: "swapStrike" })}
                className="mc-btn h-12 rounded-xl border border-slate-700 text-[11px] font-black text-slate-200 hover:bg-slate-800 disabled:opacity-40 sm:text-xs"
              >
                SWAP STRIKE
              </button>
            </div>
          </div>

          </section>
        )}

        {/* ---------- SCOREBOARD : dedicated detailed statistics ---------- */}
        {view === "scoreboard" && (
          <section className="mc-section mc-scroll space-y-4">
            <MatchHeader state={state} />
            <MatchStatsPanel state={state} />
            <BattingTable inn={inn} setup={state.setup} />
            <BowlingTable inn={inn} setup={state.setup} />
            <ExtrasCard inn={inn} />
            <PartnershipPanel inn={inn} />
            <FallOfWickets inn={inn} />
            <OverAnalysis inn={inn} />
            <MatchAwards state={state} />
          </section>
        )}

        {/* ---------- COMMENTARY : Urdu text + voice controls ---------- */}
        {view === "commentary" && (
          <section className="mc-section mc-scroll space-y-4">
            <CommentaryList state={state} />
          </section>
        )}

        {/* ---------- Modals ---------- */}
        {modal?.kind === "extra" && (
          <Modal title={modal.extra.toUpperCase()} onClose={() => setModal(null)}>
            {modal.extra === "noball" ? (
              <>
                <p className="text-sm text-slate-400">
                  1 run no-ball penalty is added automatically. Select runs off the bat.
                </p>
                <NumberRow value={nbBat} onChange={setNbBat} max={6} />
                <p className="mt-3 text-sm text-slate-400">Byes off the no ball (optional)</p>
                <NumberRow value={extraRuns} onChange={setExtraRuns} max={4} />
              </>
            ) : modal.extra === "wide" ? (
              <>
                <p className="text-sm text-slate-400">
                  1 wide penalty added automatically. Add extra runs run by the batters.
                </p>
                <NumberRow value={extraRuns} onChange={setExtraRuns} max={4} />
              </>
            ) : (
              <>
                <p className="text-sm text-slate-400">
                  Runs taken as {modal.extra === "bye" ? "byes" : "leg byes"} (legal delivery).
                </p>
                <NumberRow value={extraRuns} onChange={setExtraRuns} max={4} />
              </>
            )}
            <button
              onClick={() => {
                const e = modal.extra;
                if (e === "wide") void dispatch({ type: "wide", runs: extraRuns });
                else if (e === "noball")
                  void dispatch({ type: "noball", batRuns: nbBat, byeRuns: extraRuns });
                else void dispatch({ type: e, runs: extraRuns });
                setModal(null);
              }}
              className="mc-btn mt-5 w-full rounded-xl bg-emerald-500 py-3 font-black text-slate-950"
            >
              Confirm
            </button>
          </Modal>
        )}

        {modal?.kind === "wicket" && (
          <Modal title="WICKET" onClose={() => setModal(null)}>
            <Field label="Dismissal type">
              <div className="flex flex-wrap gap-2">
                {DISMISSALS.map((d) => (
                  <button
                    key={d}
                    onClick={() => setWk({ ...wk, dismissal: d })}
                    className={`mc-btn rounded-lg px-3 py-2 text-xs font-bold ${
                      wk.dismissal === d
                        ? "bg-red-600 text-white"
                        : "border border-slate-700 text-slate-300"
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </Field>
            <Field label="Batter dismissed">
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    ["striker", inn.striker],
                    ["nonStriker", inn.nonStriker],
                  ] as const
                ).map(([k, name]) => (
                  <button
                    key={k}
                    onClick={() => setWk({ ...wk, who: k })}
                    className={`mc-btn rounded-lg px-3 py-2 text-xs font-bold ${
                      wk.who === k ? "bg-slate-700 text-white" : "border border-slate-700"
                    }`}
                  >
                    {name ?? "—"}
                    <span className="block text-[10px] font-normal text-slate-400">
                      {k === "striker" ? "striker" : "non-striker"}
                    </span>
                  </button>
                ))}
              </div>
            </Field>
            {(wk.dismissal === "Caught" ||
              wk.dismissal === "Run Out" ||
              wk.dismissal === "Stumped") && (
              <Field label="Fielder">
                <NameSelect
                  options={bowlingSquad.map((p) => ({ name: p.name }))}
                  value={wk.fielder}
                  onChange={(n) => setWk({ ...wk, fielder: n })}
                  placeholder="Enter fielder name"
                />
              </Field>
            )}
            <Field label="Runs completed before the dismissal">
              <NumberRow value={wk.runs} onChange={(n) => setWk({ ...wk, runs: n })} max={4} />
            </Field>
            <Field label="New batsman">
              <NameSelect
                options={availableBatters}
                value={wk.newBatter}
                onChange={(n) => setWk({ ...wk, newBatter: n })}
                placeholder="Enter new batsman name"
              />
            </Field>
            {!wk.newBatter.trim() && (
              <p className="mt-2 text-xs font-semibold text-amber-300">
                Enter or choose the incoming batsman to continue scoring.
              </p>
            )}
            <button
              disabled={!wk.newBatter.trim()}
              onClick={async () => {
                const ok = await dispatch({
                  type: "wicket",
                  runs: wk.runs,
                  dismissal: wk.dismissal,
                  who: wk.who,
                  newBatter: wk.newBatter,
                  fielder: wk.fielder || undefined,
                });
                if (ok) setModal(null);
              }}
              className="mc-btn mt-4 w-full rounded-xl bg-red-600 py-3 font-black text-white disabled:opacity-40"
            >
              CONFIRM NEW BATSMAN
            </button>
          </Modal>
        )}

        {modal?.kind === "bowler" && (
          <Modal title="Over Completed" onClose={() => setModal(null)}>
            {lastOver && (
              <div className="mb-3 grid grid-cols-4 gap-2 rounded-xl border border-slate-800 bg-slate-950/60 px-3 py-2.5 text-center">
                <div>
                  <p className="text-[10px] font-bold uppercase text-slate-500">Bowler</p>
                  <p className="truncate text-sm font-black">{lastOver.bowler}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase text-slate-500">Over</p>
                  <p className="text-sm font-black">{lastOver.number}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase text-slate-500">Runs</p>
                  <p className="text-sm font-black text-emerald-400">{lastOver.runs}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase text-slate-500">Wickets</p>
                  <p className="text-sm font-black text-red-400">{lastOver.wickets}</p>
                </div>
              </div>
            )}
            <p className="mb-1.5 text-xs font-bold uppercase tracking-wider text-slate-400">
              Select new bowler
            </p>
            <NameSelect
              options={availableBowlers}
              value={newBowler}
              onChange={setNewBowler}
              placeholder="Enter new bowler name"
              existingLabel="Existing bowlers"
            />
            <button
              disabled={!newBowler.trim()}
              onClick={async () => {
                const ok = await dispatch({ type: "newBowler", name: newBowler.trim() });
                if (ok) {
                  setNewBowler("");
                  setModal(null);
                }
              }}
              className="mc-btn mt-4 w-full rounded-xl bg-emerald-500 py-3 font-black text-slate-950 disabled:opacity-40"
            >
              Start Over
            </button>
          </Modal>
        )}

        {modal?.kind === "batter" && (
          <Modal title="Next batter" onClose={() => setModal(null)}>
            <p className="mb-2 text-xs text-slate-400">
              {inn.needNewBatter === "striker" ? "Striker's" : "Non-striker's"} end is vacant for{" "}
              {inn.battingTeam}.
            </p>
            <NameSelect
              options={availableBatters}
              value={incomingBatter}
              onChange={setIncomingBatter}
              placeholder="Enter new batsman name"
            />
            <button
              disabled={!incomingBatter.trim() || !inn.needNewBatter}
              onClick={async () => {
                if (!inn.needNewBatter) return;
                const ok = await dispatch({
                  type: "newBatter",
                  name: incomingBatter.trim(),
                  end: inn.needNewBatter,
                });
                if (ok) {
                  setIncomingBatter("");
                  setModal(null);
                }
              }}
              className="mc-btn mt-4 w-full rounded-xl bg-emerald-500 py-3 font-black text-slate-950 disabled:opacity-40"
            >
              Send In
            </button>
          </Modal>
        )}

        {modal?.kind === "startInnings" && (
          <Modal title="Second Innings" onClose={() => setModal(null)}>
            <div className="mb-3 grid grid-cols-3 gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-2.5 text-center">
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400">Target</p>
                <p className="text-lg font-black text-emerald-300">
                  {state.innings[1].target}
                </p>
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400">Batting</p>
                <p className="truncate text-xs font-black">{state.innings[1].battingTeam}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400">Bowling</p>
                <p className="truncate text-xs font-black">{state.innings[1].bowlingTeam}</p>
              </div>
            </div>
            <Field label="Opening batsman 1 (striker)">
              <NameSelect
                options={nextBattingSquad.map((p) => ({ name: p.name }))}
                value={si.batter1}
                onChange={(n) => setSi({ ...si, batter1: n })}
                placeholder="Enter batsman name"
              />
            </Field>
            <Field label="Opening batsman 2">
              <NameSelect
                options={nextBattingSquad
                  .filter((p) => p.name !== si.batter1)
                  .map((p) => ({ name: p.name }))}
                value={si.batter2}
                onChange={(n) => setSi({ ...si, batter2: n })}
                placeholder="Enter batsman name"
              />
            </Field>
            <Field label="Opening bowler">
              <NameSelect
                options={nextBowlingSquad.map((p) => ({ name: p.name }))}
                value={si.bowler}
                onChange={(n) => setSi({ ...si, bowler: n })}
                placeholder="Enter bowler name"
              />
            </Field>
            <button
              disabled={!si.batter1.trim() || !si.batter2.trim() || !si.bowler.trim()}
              onClick={async () => {
                const ok = await dispatch({
                  type: "startInnings",
                  batter1: si.batter1.trim(),
                  batter2: si.batter2.trim(),
                  bowler: si.bowler.trim(),
                });
                if (ok) setModal(null);
              }}
              className="mc-btn mt-4 w-full rounded-xl bg-emerald-500 py-3 font-black text-slate-950 disabled:opacity-40"
            >
              Start Innings
            </button>
          </Modal>
        )}

        {modal?.kind === "awards" && (
          <Modal title="Match awards & prizes" onClose={() => setModal(null)}>
            <p className="rounded-lg border border-slate-800 bg-slate-900/60 px-3 py-2 text-[11px] text-slate-400">
              Player of the Match, Best Batter and Best Bowler are selected
              automatically from the recorded match statistics when the match
              finishes. Prize amounts below are optional.
            </p>

            {state.status === "completed" ? (
              <div className="mt-3 space-y-1.5">
                {(
                  [
                    ["Player of the Match", autoAwards.playerOfMatch],
                    ["Best Batter", autoAwards.bestBatter],
                    ["Best Bowler", autoAwards.bestBowler],
                  ] as const
                ).map(([label, winner]) => (
                  <div
                    key={label}
                    className="rounded-lg border border-slate-800 bg-slate-950/50 px-3 py-2"
                  >
                    <p className="text-[10px] font-black uppercase tracking-wider text-amber-400">
                      {label}
                    </p>
                    <p className="text-sm font-black">{winner?.name ?? "—"}</p>
                    {winner && (
                      <p className="text-[11px] text-slate-400">{winner.summary}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-3 text-xs text-slate-500">
                Awards will be decided when the match is complete.
              </p>
            )}

            {(
              [
                ["playerOfMatch", "Player of the Match Prize"],
                ["winningTeam", "Winning Team Prize"],
                ["bestBatter", "Best Batter Prize"],
                ["bestBowler", "Best Bowler Prize"],
              ] as const
            ).map(([k, label]) => (
              <Field key={k} label={label}>
                <input
                  className={selCls}
                  placeholder="e.g. Rs. 5,000 (optional)"
                  value={draft.prizes[k] ?? ""}
                  onChange={(e) =>
                    setAwardsDraft({
                      ...draft,
                      prizes: { ...draft.prizes, [k]: e.target.value },
                    })
                  }
                />
              </Field>
            ))}
            <button
              disabled={savingAwards}
              onClick={async () => {
                await saveAwards(draft);
                setModal(null);
              }}
              className="mc-btn mt-4 w-full rounded-xl bg-amber-500 py-3 font-black text-slate-950 disabled:opacity-50"
            >
              {savingAwards ? "Saving…" : "Save prizes"}
            </button>
          </Modal>
        )}

        {modal?.kind === "endInnings" && (
          <Modal
            title={state.currentInnings === 0 ? "End Innings?" : "End Match?"}
            onClose={() => setModal(null)}
          >
            <div className="grid grid-cols-2 gap-2 rounded-xl border border-slate-800 bg-slate-950/60 px-4 py-3 text-center">
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-500">Current score</p>
                <p className="text-2xl font-black text-emerald-400">
                  {inn.runs}/{inn.wickets}
                </p>
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-500">Overs</p>
                <p className="text-2xl font-black">{oversStr(inn.legalBalls)}</p>
              </div>
            </div>
            <p className="mt-3 text-sm text-slate-300">
              {state.currentInnings === 0
                ? `This freezes the ${inn.battingTeam} innings and sets a target of ${inn.runs + 1}.`
                : "This ends the match and produces the final result."}
            </p>
            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setModal(null)}
                className="mc-btn flex-1 rounded-xl border border-slate-700 py-3 font-bold"
              >
                CANCEL
              </button>
              <button
                onClick={async () => {
                  const ok = await dispatch({ type: "endInnings" });
                  if (ok) setModal(null);
                }}
                className="mc-btn flex-1 rounded-xl bg-red-600 py-3 font-black text-white"
              >
                END INNINGS
              </button>
            </div>
          </Modal>
        )}

        {modal?.kind === "undo" && (
          <Modal title="Undo last action" onClose={() => setModal(null)}>
            <p className="text-sm text-slate-300">
              This removes the most recent scoring action and fully restores the previous match
              state — score, wickets, overs, batter and bowler statistics, strike, current over and
              commentary.
            </p>
            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setModal(null)}
                className="mc-btn flex-1 rounded-xl border border-slate-700 py-3 font-bold"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  void undo();
                  setModal(null);
                }}
                className="mc-btn flex-1 rounded-xl bg-amber-500 py-3 font-black text-slate-950"
              >
                Undo
              </button>
            </div>
          </Modal>
        )}
      </main>
    </PlayerProfileProvider>
  );
}

/**
 * Section switcher. Segmented control on desktop, fixed bottom bar on mobile
 * so the scorer can jump between Scoring and Scoreboard with one thumb tap.
 */
function ScorerNav({
  view,
  onChange,
}: {
  view: ScorerView;
  onChange: (v: ScorerView) => void;
}) {
  const items: { key: ScorerView; label: string; icon: ReactNode }[] = [
    { key: "scoring", label: "Scoring", icon: <BatIcon className="h-[18px] w-[18px]" /> },
    { key: "scoreboard", label: "Scoreboard", icon: <ScorecardIcon /> },
    { key: "commentary", label: "Commentary", icon: <CommentaryIcon /> },
  ];

  return (
    <>
      {/* Desktop / tablet */}
      <nav className="mb-4 hidden gap-1 rounded-xl border border-slate-800 bg-slate-900/50 p-1 sm:flex">
        {items.map((it) => (
          <button
            key={it.key}
            onClick={() => onChange(it.key)}
            className={`mc-btn inline-flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg text-xs font-black tracking-wide ${
              view === it.key
                ? "bg-emerald-500 text-slate-950"
                : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            {it.icon}
            {it.label}
          </button>
        ))}
        <Link
          href="/history"
          className="mc-btn inline-flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg text-xs font-black tracking-wide text-slate-300 hover:bg-slate-800"
        >
          <HistoryIcon />
          History
        </Link>
      </nav>

      {/* Mobile bottom bar */}
      <nav className="fixed inset-x-0 bottom-0 z-50 flex border-t border-slate-800 bg-[#070b12]/97 pb-[env(safe-area-inset-bottom)] backdrop-blur sm:hidden">
        {items.map((it) => (
          <button
            key={it.key}
            onClick={() => onChange(it.key)}
            className={`flex flex-1 flex-col items-center gap-0.5 py-2 text-[10px] font-black tracking-wide transition ${
              view === it.key ? "text-emerald-400" : "text-slate-400"
            }`}
          >
            {it.icon}
            {it.label}
          </button>
        ))}
        <Link
          href="/history"
          className="flex flex-1 flex-col items-center gap-0.5 py-2 text-[10px] font-black tracking-wide text-slate-400"
        >
          <HistoryIcon />
          History
        </Link>
      </nav>
    </>
  );
}

const selCls =
  "w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm outline-none focus:border-emerald-500";

/** A selectable existing player plus an optional stat line. */
type NameOption = { name: string; note?: string };

/**
 * Lets the scorer pick a player who is already in the match (showing their
 * current figures) OR type a brand-new name. This is what keeps the New Match
 * flow short — squads build up as the match progresses.
 */
function NameSelect({
  options,
  value,
  onChange,
  placeholder,
  existingLabel = "Existing players",
}: {
  options: NameOption[];
  value: string;
  onChange: (name: string) => void;
  placeholder: string;
  existingLabel?: string;
}) {
  const known = options.some((o) => o.name === value);
  return (
    <div>
      {options.length > 0 && (
        <>
          <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">
            {existingLabel}
          </p>
          <div className="mb-3 max-h-44 space-y-1.5 overflow-y-auto pr-1">
            {options.map((o) => (
              <button
                key={o.name}
                onClick={() => onChange(o.name)}
                className={`mc-btn flex w-full items-center gap-2.5 rounded-lg border px-3 py-2 text-left ${
                  value === o.name
                    ? "border-emerald-500 bg-emerald-500/15"
                    : "border-slate-700 hover:bg-slate-800"
                }`}
              >
                <PlayerAvatar player={{ id: o.name, name: o.name, role: "Batsman" }} size={30} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-bold">{o.name}</span>
                  {o.note && (
                    <span className="block text-[11px] text-slate-400">{o.note}</span>
                  )}
                </span>
                {value === o.name && <span className="text-emerald-400">✓</span>}
              </button>
            ))}
          </div>
        </>
      )}
      <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">
        Or enter a new name
      </p>
      <input
        value={known ? "" : value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm outline-none focus:border-emerald-500"
      />
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mt-3">
      <p className="mb-1.5 text-xs font-bold uppercase tracking-wider text-slate-400">{label}</p>
      {children}
    </div>
  );
}

function NumberRow({
  value,
  onChange,
  max,
}: {
  value: number;
  onChange: (n: number) => void;
  max: number;
}) {
  return (
    <div className="mt-2 flex flex-wrap gap-2">
      {Array.from({ length: max + 1 }, (_, i) => i).map((n) => (
        <button
          key={n}
          onClick={() => onChange(n)}
          className={`mc-btn h-11 w-11 rounded-lg text-base font-black ${
            value === n
              ? "bg-emerald-500 text-slate-950"
              : "border border-slate-700 text-slate-200 hover:bg-slate-800"
          }`}
        >
          {n}
        </button>
      ))}
    </div>
  );
}

function Modal({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-3 sm:items-center">
      <div className="mc-pop mc-card max-h-[90vh] w-full max-w-md overflow-y-auto px-5 py-5">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-lg font-black uppercase tracking-wide">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
