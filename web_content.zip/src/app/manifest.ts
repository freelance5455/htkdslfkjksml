import type { MetadataRoute } from "next";

/** Web app manifest: makes the site installable and gives the Android wrapper its identity. */
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "لأنه الله — منصة تعليمية إسلامية",
    short_name: "لأنه الله",
    description: "بالعلم نرتقي، وبالذكر نطمئن، وبالإيمان نحيا.",
    lang: "ar",
    dir: "rtl",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#0F1828",
    theme_color: "#17243A",
    icons: [
      {
        src: "/apple-icon.png",
        sizes: "180x180",
        type: "image/png",
      },
      {
        src: "/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  };
}
