import type { Metadata } from "next";
import { PageHero } from "@/components/page-hero";
import { FormA } from "@/components/form-a";

export const metadata: Metadata = {
  title: "نموذج أ",
  description: "نموذج أ: استمارة تقديم الطلبات والاقتراحات الخاصة بمنصة لأنه الله.",
};

export default function FormAPage() {
  return (
    <main>
      <PageHero
        eyebrow="الاستمارات الرسمية"
        title={
          <>
            نموذج <span className="text-gold-gradient">أ</span>
          </>
        }
        description="املأ الاستمارة بالبيانات الصحيحة، وسيُحفظ طلبك ويتم التواصل معك عبر الرقم الذي تُدخله."
      />

      <section className="relative bg-ivory py-20 sm:py-24">
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          <FormA />
        </div>
      </section>
    </main>
  );
}
