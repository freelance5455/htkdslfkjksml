import { useMemo, useState } from "react";
import { Check, Clapperboard, Heart, MonitorPlay, Search, Share2, Trash2, X } from "lucide-react";
import { MOVIES, SERIES, hueOf } from "./catalog";
import { useLocalStorage } from "./useLocalStorage";

type Filter = "todo" | "movies" | "series";

/** Mi Colección — tus favoritos, reunidos en un solo lugar. */
export default function CollectionView({ onNavigate }: { onNavigate: (route: string) => void }) {
  const [favs, setFavs] = useLocalStorage<string[]>("lo3-favs", []);
  const [continueList] = useLocalStorage<{ id: string }[]>("lo3-continue", []);
  const [triviaBest] = useLocalStorage<number>("lo3-trivia-best", 0);
  const [neonBest] = useLocalStorage<number>("lo3-neon-best", 0);
  const [filter, setFilter] = useState<Filter>("todo");
  const [query, setQuery] = useState("");

  const items = useMemo(() => {
    const movieMatches = MOVIES.filter((m) => favs.includes(m.title)).map((m) => ({ kind: "movies" as const, name: m.title, meta: `Película · ${m.year}`, img: m.image as string | null, seed: m.qid, rating: null as number | null }));
    const seriesMatches = SERIES.filter((s) => favs.includes(s.name)).map((s) => ({ kind: "series" as const, name: s.name, meta: `Serie · ${s.year}`, img: s.image as string | null, seed: String(s.id), rating: s.rating }));
    let list = [...movieMatches, ...seriesMatches];
    if (filter !== "todo") list = list.filter((i) => i.kind === filter);
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((i) => i.name.toLowerCase().includes(q));
    return list;
  }, [favs, filter, query]);

  // favoritos guardados que ya no existen en catálogo
  const orphanCount = favs.length - MOVIES.filter((m) => favs.includes(m.title)).length - SERIES.filter((s) => favs.includes(s.name)).length;
  const catalogCount = MOVIES.length + SERIES.length;
  const shareText = `Mi colección TV LO3: ${favs.slice(0, 12).join(", ")}${favs.length > 12 ? `… y ${favs.length - 12} más` : ""} · ${favs.length} favoritos`;
  const share = async () => {
    try { if (navigator.share) await navigator.share({ title: "Mi colección TV LO3", text: shareText }); else { await navigator.clipboard.writeText(shareText); window.alert("Copiado al portapapeles"); } } catch { /* cancelado */ }
  };

  return (
    <div className="flex h-full flex-col gap-3 overflow-hidden p-3 sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-500 to-red-800"><Heart size={21} className="fill-white text-white" /></span>
          <div>
            <h1 className="font-display text-lg font-black text-white">Mi Colección</h1>
            <p className="text-[10px] uppercase tracking-wider text-slate-500">Tus {favs.length} favoritos · solo en este dispositivo</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1 rounded-xl border border-white/10 bg-white/[0.04] p-1" role="group" aria-label="Filtrar colección">
            {([["todo", "Todo"], ["movies", "Movies"], ["series", "Series"]] as [Filter, string][]).map(([v, l]) => (
              <button key={v} onClick={() => setFilter(v)} aria-pressed={filter === v} className={`h-8 rounded-lg px-3 text-[10px] font-bold transition-colors ${filter === v ? "bg-electric text-white" : "text-slate-400 hover:text-white"}`}>{l}</button>
            ))}
          </div>
          <button onClick={share} className="flex h-10 items-center gap-1.5 rounded-xl border border-cyanx/30 bg-cyanx/10 px-3 text-[10px] font-bold text-cyanx transition-colors hover:bg-cyanx/20" aria-label="Compartir tu colección"><Share2 size={13} /> Compartir</button>
          {favs.length > 0 && (
            <button onClick={() => { if (window.confirm("¿Vaciar toda tu colección?")) setFavs([]); }} className="flex h-10 items-center gap-1.5 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 text-[10px] font-bold text-rose-300 transition-colors hover:bg-rose-500/20" aria-label="Vaciar colección"><Trash2 size={13} /> Vaciar</button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4" aria-label="Tus estadísticas">
        {[
          { v: catalogCount, l: "Catálogo real", d: "títulos" },
          { v: favs.length, l: "Tu lista", d: "favoritos" },
          { v: continueList.length, l: "Continuar", d: "pendientes" },
          { v: `${triviaBest}${neonBest > 0 ? ` · ${neonBest}` : ""}`, l: "Trivia · Neon Dash", d: "pts · récord" },
        ].map((s2) => (
          <div key={s2.l} className="rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2.5">
            <p className="font-display text-xl font-black leading-none text-white">{s2.v}</p>
            <p className="mt-1 text-[9px] font-semibold uppercase tracking-wider text-slate-500">{s2.l}</p>
            <p className="text-[8px] text-slate-600">{s2.d}</p>
          </div>
        ))}
      </div>

      <div className="relative">
        <Search size={13} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <label htmlFor="collection-search" className="sr-only">Buscar en tu colección</label>
        <input id="collection-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar en tu colección…" className="h-11 w-full rounded-xl border border-white/10 bg-black/30 pl-9 pr-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-rose-500/50" />
        {query && <button onClick={() => setQuery("")} aria-label="Borrar búsqueda" className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full p-1 text-slate-500 hover:text-white"><X size={14} /></button>}
      </div>

      <div className="thin-scroll min-h-0 flex-1 overflow-y-auto pr-0.5" aria-live="polite">
        {items.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/12 p-8 text-center">
            <Heart size={36} className="text-slate-700" strokeWidth={1.5} />
            <div>
              <p className="font-display text-base font-bold text-slate-300">{query ? `Nada coincide con “${query}”` : "Tu colección está vacía"}</p>
              <p className="mt-1 max-w-xs text-[11px] text-slate-500">Marca títulos con el corazón en Movies o Series y aparecerán aquí, con sus pósters y accesos directos.</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => onNavigate("movies")} className="ghost-btn flex h-10 items-center gap-2 rounded-xl px-4 text-[11px] font-bold text-white"><Clapperboard size={13} className="text-cyanx" /> Ir a Movies</button>
              <button onClick={() => onNavigate("series")} className="ghost-btn flex h-10 items-center gap-2 rounded-xl px-4 text-[11px] font-bold text-white"><MonitorPlay size={13} className="text-violetx" /> Ir a Series</button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2 pb-2 sm:grid-cols-4 lg:grid-cols-6">
            {items.map((item, i) => (
              <div key={i} className="group relative aspect-[2/3] overflow-hidden rounded-xl border border-white/10">
                {item.img
                  ? <img src={item.img} alt={`Póster de ${item.name}`} loading="lazy" className="absolute inset-0 h-full w-full object-cover" onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")} />
                  : <div className="absolute inset-0" style={{ background: `linear-gradient(165deg, hsl(${hueOf(item.seed)} 52% 40%), hsl(${(hueOf(item.seed) + 45) % 360} 68% 14%))` }} />}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/15 to-transparent" />
                <span className="absolute left-1.5 top-1.5 rounded bg-black/60 px-1.5 py-0.5 text-[7px] font-black uppercase tracking-wider text-slate-300">{item.kind === "movies" ? "Film" : "Serie"}</span>
                <span className="absolute inset-x-1.5 bottom-1.5">
                  <span className="block font-display text-[9px] font-bold leading-tight text-white">{item.name}</span>
                  <span className="mt-0.5 block text-[7px] uppercase tracking-wider text-slate-500">{item.meta}</span>
                  <button onClick={() => setFavs((p) => p.filter((x) => x !== item.name))} className="mt-1 flex h-6 items-center gap-1 rounded bg-black/50 px-1.5 text-[8px] font-bold text-rose-300 backdrop-blur-sm hover:bg-rose-500/20" aria-label={`Quitar ${item.name} de favoritos`}><Heart size={9} className="fill-rose-500 text-rose-500" /><Check size={9} /> Quitar</button>
                </span>
              </div>
            ))}
          </div>
        )}
        {orphanCount > 0 && <p className="pb-2 text-[9px] text-slate-600">{orphanCount} favorito(s) guardado(s) que ya no están en el catálogo se conservan en tu copia de seguridad.</p>}
      </div>
    </div>
  );
}
