"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { formatBDT } from "@/lib/utils";

interface Category {
  id: number;
  name: string;
  slug: string;
}

interface Product {
  id: number;
  name: string;
  modelNumber: string;
  category: string;
  categoryId: number | null;
  price: number;
  description: string;
  features: string[];
  colors: string[];
  image: string;
  status: string;
  isFeatured: boolean;
  isBestSeller: boolean;
  isNewArrival: boolean;
  stock: number;
}

interface OrderItem {
  id: number;
  productName: string;
  quantity: number;
  price: number;
}

interface Order {
  id: number;
  customerName: string;
  phone: string;
  address: string;
  message?: string | null;
  totalPrice: number;
  status: string;
  trackingNumber: string;
  createdAt: string;
  items?: OrderItem[];
}

const EMPTY_PRODUCT = {
  name: "",
  modelNumber: "",
  categoryId: "",
  price: "",
  description: "",
  features: "",
  colors: "",
  image: "",
  status: "available",
  isFeatured: false,
  isBestSeller: false,
  isNewArrival: false,
  stock: "10",
};

export default function AdminPage() {
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [tab, setTab] = useState<"overview" | "products" | "orders" | "categories">("overview");

  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState("");

  // product form
  const [form, setForm] = useState(EMPTY_PRODUCT);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [imagePreview, setImagePreview] = useState("");

  const checkSession = useCallback(async () => {
    const res = await fetch("/api/admin");
    const data = await res.json();
    setAuthenticated(data.authenticated);
    setUsername(data.username || "");
  }, []);

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [pRes, oRes, cRes] = await Promise.all([
        fetch("/api/products"),
        fetch("/api/orders"),
        fetch("/api/categories"),
      ]);
      const pData = await pRes.json();
      const oData = await oRes.json();
      const cData = await cRes.json();
      setProducts(pData.products || []);
      setOrders(oData.orders || []);
      setCategories(cData.categories || []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (authenticated) loadData();
  }, [authenticated, loadData]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    const res = await fetch("/api/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (!res.ok) return setLoginError(data.error || "Login failed");
    setUsername(data.username);
    setAuthenticated(true);
  };

  const handleLogout = async () => {
    await fetch("/api/admin", { method: "DELETE" });
    setAuthenticated(false);
    setPassword("");
  };

  const flash = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(""), 3000);
  };

  const handleImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setForm((f) => ({ ...f, image: dataUrl }));
      setImagePreview(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const categoryObj = categories.find((c) => String(c.id) === form.categoryId);
    const payload = {
      name: form.name,
      modelNumber: form.modelNumber,
      categoryId: form.categoryId ? Number(form.categoryId) : null,
      category: categoryObj?.name || "General",
      price: Number(form.price),
      description: form.description,
      image: form.image,
      features: form.features.split(",").map((s) => s.trim()).filter(Boolean),
      colors: form.colors.split(",").map((s) => s.trim()).filter(Boolean),
      status: form.status,
      isFeatured: form.isFeatured,
      isBestSeller: form.isBestSeller,
      isNewArrival: form.isNewArrival,
      stock: Number(form.stock),
    };
    const res = await fetch(editingId ? `/api/products/${editingId}` : "/api/products", {
      method: editingId ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) return flash(data.error || "Failed to save product");
    flash(editingId ? "Product updated!" : "Product created!");
    setForm(EMPTY_PRODUCT);
    setEditingId(null);
    setImagePreview("");
    loadData();
  };

  const handleDeleteProduct = async (id: number) => {
    if (!confirm("Delete this product?")) return;
    const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
    if (res.ok) {
      flash("Product deleted");
      loadData();
    }
  };

  const handleStatusUpdate = async (id: number, status: string) => {
    const res = await fetch(`/api/orders/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    if (res.ok) {
      flash("Order status updated");
      loadData();
    }
  };

  const handleCategoryAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    const name = (e.target as HTMLFormElement).catName.value;
    if (!name) return;
    const res = await fetch("/api/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    if (res.ok) {
      flash("Category added");
      loadData();
      (e.target as HTMLFormElement).reset();
    } else {
      const data = await res.json();
      flash(data.error || "Failed to add category");
    }
  };

  const handleCategoryDelete = async (id: number) => {
    if (!confirm("Delete this category?")) return;
    const res = await fetch("/api/categories", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    if (res.ok) {
      flash("Category deleted");
      loadData();
    }
  };

  const startEdit = (p: Product) => {
    setEditingId(p.id);
    setForm({
      name: p.name,
      modelNumber: p.modelNumber,
      categoryId: String(p.categoryId ?? ""),
      price: String(p.price),
      description: p.description,
      features: p.features.join(", "),
      colors: p.colors.join(", "),
      image: p.image,
      status: p.status,
      isFeatured: p.isFeatured,
      isBestSeller: p.isBestSeller,
      isNewArrival: p.isNewArrival,
      stock: String(p.stock),
    });
    setImagePreview(p.image);
    setTab("products");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (authenticated === null) {
    return (
      <div className="grid min-h-screen place-items-center bg-futuristic pt-20">
        <div className="text-center text-slate-400">Loading admin panel...</div>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="relative flex min-h-screen items-center justify-center bg-futuristic px-4 pt-20">
        <div className="glass w-full max-w-md rounded-[2rem] p-8">
          <div className="text-center">
            <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-purple-500 to-blue-600 font-display text-2xl font-black text-white shadow-[0_0_30px_rgba(139,92,246,0.5)]">
              C
            </span>
            <h1 className="mt-4 font-display text-2xl font-bold text-white">Admin Access</h1>
            <p className="mt-1 text-sm text-slate-400">Secure dashboard · Authorized only</p>
          </div>
          <form onSubmit={handleLogin} className="mt-8 space-y-4">
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              required
              className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-white placeholder:text-slate-500 focus:border-purple-400/60 focus:outline-none"
            />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              required
              className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-white placeholder:text-slate-500 focus:border-purple-400/60 focus:outline-none"
            />
            {loginError && <p className="rounded-xl border border-red-400/30 bg-red-500/10 p-3 text-sm text-red-300">{loginError}</p>}
            <button className="w-full rounded-2xl bg-gradient-to-r from-purple-500 to-blue-600 py-3.5 font-bold text-white shadow-[0_0_25px_rgba(139,92,246,0.4)] transition hover:brightness-110">
              Login to Dashboard
            </button>
          </form>
        </div>
      </div>
    );
  }

  const stats = [
    { label: "Total Models", value: products.length, icon: "🧮" },
    { label: "Total Orders", value: orders.length, icon: "📦" },
    { label: "Pending Orders", value: orders.filter((o) => o.status === "pending").length, icon: "⏳" },
    { label: "Revenue (BDT)", value: `৳${orders.reduce((s, o) => s + o.totalPrice, 0).toLocaleString("en-IN")}`, icon: "💰" },
  ];

  const inputCls = "w-full rounded-xl border border-white/10 bg-black/40 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-purple-400/60 focus:outline-none";
  const labelCls = "mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-400";

  return (
    <div className="relative min-h-screen bg-futuristic pt-28">
      <div className="mx-auto max-w-7xl px-4 pb-24">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-black text-white">Admin <span className="text-gradient">Dashboard</span></h1>
            <p className="text-sm text-slate-400">Welcome back, <span className="font-bold text-purple-300">{username}</span></p>
          </div>
          <button onClick={handleLogout} className="rounded-xl border border-red-400/30 bg-red-500/10 px-5 py-2.5 text-sm font-bold text-red-300 transition hover:bg-red-500/20">
            Logout
          </button>
        </div>

        {notice && (
          <div className="mt-4 rounded-xl border border-emerald-400/30 bg-emerald-500/10 p-3 text-sm text-emerald-300">{notice}</div>
        )}

        {/* Tabs */}
        <div className="mt-6 flex flex-wrap gap-2">
          {(["overview", "products", "orders", "categories"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-full px-5 py-2.5 text-sm font-bold capitalize transition ${
                tab === t ? "bg-gradient-to-r from-purple-500 to-blue-600 text-white" : "border border-white/10 text-slate-300 hover:text-white"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* OVERVIEW */}
        {tab === "overview" && (
          <div className="mt-8">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {stats.map((s) => (
                <div key={s.label} className="glass rounded-3xl p-6">
                  <span className="text-2xl">{s.icon}</span>
                  <p className="mt-3 font-display text-2xl font-black text-white">{s.value}</p>
                  <p className="text-xs uppercase tracking-widest text-slate-400">{s.label}</p>
                </div>
              ))}
            </div>
            <div className="glass mt-6 rounded-3xl p-6">
              <h2 className="font-display text-lg font-bold text-white">Recent Orders</h2>
              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="text-xs uppercase tracking-widest text-slate-400">
                    <tr>
                      <th className="pb-3">Tracking</th>
                      <th className="pb-3">Customer</th>
                      <th className="pb-3">Phone</th>
                      <th className="pb-3">Total</th>
                      <th className="pb-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {orders.slice(0, 6).map((o) => (
                      <tr key={o.id}>
                        <td className="py-3 font-mono text-purple-300">{o.trackingNumber}</td>
                        <td className="py-3 text-white">{o.customerName}</td>
                        <td className="py-3 text-slate-300">{o.phone}</td>
                        <td className="py-3 font-bold text-white">{formatBDT(o.totalPrice)}</td>
                        <td className="py-3 capitalize text-slate-300">{o.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* PRODUCTS */}
        {tab === "products" && (
          <div className="mt-8 grid gap-8 lg:grid-cols-[380px_1fr]">
            {/* Form */}
            <form onSubmit={handleProductSubmit} className="glass h-fit rounded-3xl p-6 lg:sticky lg:top-24">
              <h2 className="font-display text-lg font-bold text-white">{editingId ? "Edit Model" : "Add New Model"}</h2>
              <div className="mt-4 space-y-3">
                <div>
                  <label className={labelCls}>Model Name *</label>
                  <input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required placeholder="CALCORA X1" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={labelCls}>Model Number *</label>
                    <input className={inputCls} value={form.modelNumber} onChange={(e) => setForm({ ...form, modelNumber: e.target.value })} required placeholder="CX-1001" />
                  </div>
                  <div>
                    <label className={labelCls}>Category *</label>
                    <select className={inputCls} value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })} required>
                      <option value="">Select category</option>
                      {categories.map((c) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={labelCls}>Price (BDT) *</label>
                    <input className={inputCls} type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} required placeholder="4990" />
                  </div>
                  <div>
                    <label className={labelCls}>Stock *</label>
                    <input className={inputCls} type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} required />
                  </div>
                </div>
                <div>
                  <label className={labelCls}>Description *</label>
                  <textarea className={inputCls} rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required />
                </div>
                <div>
                  <label className={labelCls}>Features (comma separated)</label>
                  <input className={inputCls} value={form.features} onChange={(e) => setForm({ ...form, features: e.target.value })} placeholder="Solar powered, 12-digit display" />
                </div>
                <div>
                  <label className={labelCls}>Colors (comma separated)</label>
                  <input className={inputCls} value={form.colors} onChange={(e) => setForm({ ...form, colors: e.target.value })} placeholder="Midnight Black, Silver" />
                </div>
                <div>
                  <label className={labelCls}>Product Image *</label>
                  <input type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0])} className="w-full text-xs text-slate-400 file:mr-3 file:rounded-lg file:border-0 file:bg-purple-500/20 file:px-3 file:py-2 file:text-purple-300" />
                  <input className={`${inputCls} mt-2`} value={form.image.startsWith("data:") ? "(uploaded image)" : form.image} onChange={(e) => { setForm({ ...form, image: e.target.value }); setImagePreview(e.target.value); }} placeholder="...or paste image URL" />
                  {imagePreview && (
                    <div className="relative mt-2 h-24 w-24 overflow-hidden rounded-xl border border-white/10">
                      <Image src={imagePreview} alt="preview" fill sizes="96px" className="object-cover" />
                    </div>
                  )}
                </div>
                <div>
                  <label className={labelCls}>Status</label>
                  <select className={inputCls} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                    <option value="available">Available</option>
                    <option value="pre_order">Pre-Order</option>
                    <option value="out_of_stock">Out of Stock</option>
                  </select>
                </div>
                <div className="flex flex-wrap gap-4 text-sm text-slate-300">
                  {(["isFeatured", "isBestSeller", "isNewArrival"] as const).map((flag) => (
                    <label key={flag} className="flex items-center gap-2">
                      <input type="checkbox" checked={form[flag]} onChange={(e) => setForm({ ...form, [flag]: e.target.checked })} className="accent-purple-500" />
                      {flag.replace("is", "")}
                    </label>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button type="submit" className="rounded-xl bg-gradient-to-r from-purple-500 to-blue-600 py-3 font-bold text-white">
                    {editingId ? "Save Changes" : "Add Model"}
                  </button>
                  {editingId && (
                    <button type="button" onClick={() => { setEditingId(null); setForm(EMPTY_PRODUCT); setImagePreview(""); }} className="rounded-xl border border-white/15 py-3 font-bold text-slate-300">
                      Cancel
                    </button>
                  )}
                </div>
              </div>
            </form>

            {/* Product list */}
            <div className="space-y-3">
              {loading && <p className="text-sm text-slate-400">Loading...</p>}
              {products.map((p) => (
                <div key={p.id} className="glass flex flex-wrap items-center gap-4 rounded-2xl p-4">
                  <div className="relative h-16 w-16 flex-none overflow-hidden rounded-xl bg-black/40">
                    <Image src={p.image} alt={p.name} fill sizes="64px" className="object-cover" />
                  </div>
                  <div className="min-w-[180px] flex-1">
                    <p className="font-display font-bold text-white">{p.name}</p>
                    <p className="text-xs text-slate-500">{p.modelNumber} · {p.category}</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-bold text-white">{formatBDT(p.price)}</p>
                    <p className="text-xs text-slate-500">stock: {p.stock}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${p.status === "available" ? "bg-emerald-500/20 text-emerald-300" : p.status === "pre_order" ? "bg-amber-500/20 text-amber-300" : "bg-red-500/20 text-red-300"}`}>
                      {p.status}
                    </span>
                    <button onClick={() => startEdit(p)} className="rounded-lg border border-white/10 px-3 py-1.5 text-xs font-bold text-white transition hover:border-blue-400/60">Edit</button>
                    <button onClick={() => handleDeleteProduct(p.id)} className="rounded-lg border border-red-400/30 px-3 py-1.5 text-xs font-bold text-red-300 transition hover:bg-red-500/20">Delete</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ORDERS */}
        {tab === "orders" && (
          <div className="mt-8 space-y-4">
            {loading && <p className="text-sm text-slate-400">Loading...</p>}
            {orders.map((o) => (
              <div key={o.id} className="glass rounded-3xl p-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="font-mono font-black text-white">{o.trackingNumber}</p>
                    <p className="text-sm text-slate-400">{o.customerName} · {o.phone}</p>
                    <p className="text-xs text-slate-500">{o.address}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-display font-black text-gradient">{formatBDT(o.totalPrice)}</span>
                    <select
                      value={o.status}
                      onChange={(e) => handleStatusUpdate(o.id, e.target.value)}
                      className="rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm capitalize text-white focus:border-purple-400/60 focus:outline-none"
                    >
                      {["pending", "confirmed", "shipped", "delivered", "cancelled"].map((s) => (
                        <option key={s} value={s} className="capitalize">{s}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2 text-xs text-slate-300">
                  {o.items?.map((it) => (
                    <span key={it.id} className="rounded-full border border-white/10 bg-white/5 px-3 py-1">
                      {it.productName} × {it.quantity} — {formatBDT(it.price * it.quantity)}
                    </span>
                  ))}
                  {o.message && <span className="w-full text-slate-500">📝 {o.message}</span>}
                </div>
              </div>
            ))}
            {!loading && orders.length === 0 && <p className="py-10 text-center text-slate-500">No orders yet.</p>}
          </div>
        )}

        {/* CATEGORIES */}
        {tab === "categories" && (
          <div className="mt-8 grid gap-8 md:grid-cols-2">
            <form onSubmit={handleCategoryAdd} className="glass h-fit rounded-3xl p-6">
              <h2 className="font-display text-lg font-bold text-white">Add Category</h2>
              <div className="mt-4 flex gap-2">
                <input name="catName" placeholder="Category name" required className={inputCls} />
                <button className="flex-none rounded-xl bg-gradient-to-r from-purple-500 to-blue-600 px-5 py-2.5 font-bold text-white">Add</button>
              </div>
              <div className="mt-6 space-y-2">
                {categories.map((c) => (
                  <div key={c.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-black/30 px-4 py-3">
                    <div>
                      <p className="font-semibold text-white">{c.name}</p>
                      <p className="text-xs text-slate-500">/{c.slug}</p>
                    </div>
                    <button onClick={() => handleCategoryDelete(c.id)} className="rounded-lg border border-red-400/30 px-3 py-1.5 text-xs font-bold text-red-300 hover:bg-red-500/20">
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            </form>
            <div className="glass rounded-3xl p-6">
              <h2 className="font-display text-lg font-bold text-white">Manage Categories</h2>
              <p className="mt-2 text-sm text-slate-400">
                Categories power the marketplace filter chips. Every product must belong to a category.
                Deleting a category keeps existing products but they fall back to &quot;General&quot;.
              </p>
              <div className="mt-4 rounded-2xl border border-purple-400/20 bg-purple-500/10 p-4 text-sm text-purple-200">
                💡 Tip: Use categories like &quot;Standard Models&quot;, &quot;Premium Models&quot;, &quot;3D Models&quot;, &quot;Scientific Models&quot;,
                &quot;Digital Models&quot;, &quot;Special Edition&quot; and &quot;New Arrivals&quot;.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}