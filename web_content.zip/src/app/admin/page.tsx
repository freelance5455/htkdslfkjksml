"use client";

import { useState } from "react";
import { BookOpen, CalendarCheck, Globe, LayoutDashboard, Star, Stethoscope, Tags, Users } from "lucide-react";
import { useAuth, useI18n } from "@/components/providers";
import { ArticlesSection, BookingsSection, ServicesSection } from "@/components/admin/admin-content";
import { CategoriesSection, SiteSection } from "@/components/admin/admin-site";
import { OverviewSection, ReviewsSection, UsersSection } from "@/components/admin/admin-panel";
import { Alert, CardSkeleton, LoginPrompt, PageHeader, Tabs } from "@/components/ui";

type AdminTab = "overview" | "site" | "categories" | "bookings" | "articles" | "services" | "users" | "reviews";

export default function AdminPage() {
  const { t } = useI18n();
  const { user, loading } = useAuth();
  const [tab, setTab] = useState<AdminTab>("overview");

  if (loading) return <CardSkeleton lines={6} />;
  if (!user) {
    return (
      <div>
        <PageHeader title={t("adm.title")} subtitle={t("adm.subtitle")} />
        <LoginPrompt message={t("adm.forbidden")} next="/admin" />
      </div>
    );
  }
  if (user.role !== "admin") {
    return (
      <div>
        <PageHeader title={t("adm.title")} />
        <Alert tone="danger">{t("adm.forbidden")}</Alert>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title={t("adm.title")} subtitle={t("adm.subtitle")} />
      <div className="mb-8 overflow-x-auto">
        <Tabs<AdminTab>
          className="min-w-max"
          value={tab}
          onChange={setTab}
          items={[
            { value: "overview", label: t("adm.tabOverview"), icon: LayoutDashboard },
            { value: "bookings", label: t("adm.tabBookings"), icon: CalendarCheck },
            { value: "site", label: t("adm.tabSite"), icon: Globe },
            { value: "articles", label: t("adm.tabArticles"), icon: BookOpen },
            { value: "categories", label: t("adm.tabCategories"), icon: Tags },
            { value: "services", label: t("adm.tabServices"), icon: Stethoscope },
            { value: "users", label: t("adm.tabUsers"), icon: Users },
            { value: "reviews", label: t("adm.tabReviews"), icon: Star },
          ]}
        />
      </div>

      {tab === "overview" && <OverviewSection />}
      {tab === "site" && <SiteSection />}
      {tab === "categories" && <CategoriesSection />}
      {tab === "bookings" && <BookingsSection />}
      {tab === "articles" && <ArticlesSection />}
      {tab === "services" && <ServicesSection />}
      {tab === "users" && <UsersSection />}
      {tab === "reviews" && <ReviewsSection />}
    </div>
  );
}
