import { useEffect, useState } from "react";
import { Baby, Delete, Lock, ShieldCheck, Star } from "lucide-react";
import { KIDS_MOVIES, KIDS_SERIES } from "./catalog";
import { useLocalStorage } from "./useLocalStorage";
import type { ContinueItem } from "./store";
import { usePrivacyMax } from "./usePrivacyMax";

export default function KidsView({ onNavigate }: { onNavigate: (route: string) => void }) {
  const pm = usePrivacyMax();
  const [pin, setPin] = useLocalStorage<string | null>("lo3-kids-pin", null);
  const [unlocked, setUnlocked] = useState(false);
  const [entry, setEntry] = useState("");
  const [error, setError] = useState(false);
  const [mode, setMode] = useState<"verify" | "setup">(pin ? "verify" : "setup");
  const [rules, setRules] = useLocalStorage("lo3-kids-rules", { onlyKids: true, limitTwoHours: true, hideStore: false });
  const [, setContinue] = useLocalStorage<ContinueItem[]>("lo3-continue", []);

  useEffect(() => { setMode(pin ? "verify" : "setup"); }, [pin]);

  const press = (d: string) => {
    if (entry.length >= 4) return;
    const next = entry + d;
    setEntry(next);
    setError(false);
    if (next.length === 4) {
      if (mode === "setup") { setPin(next); setUnlocked(true); setEntry(""); return; }
      if (next === pin) { setUnlocked(true); setEntry(""); } else { setError(true); setEntry(""); }
    }
  };

  if (!unlocked) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-5 overflow-y-auto p-6 text-center">
        <span className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-emerald-400 to-teal-600 shadow-lg shadow-emerald-500/30">
          {mode === "setup" ? <ShieldCheck size={38} className="text-white" /> : <Lock size={34} className="text-white" />}
        </span>
        <div>
          <h1 className="font-display text-2xl font-black text-white">{mode === "setup" ? "Crea un PIN parental" : "Zona Kids bloqueada"}</h1>
          <p className="mt-1 max-w-sm text-xs text-slate-400">{mode === "setup" ? "Este PIN protege el perfil infantil: filtros, horarios y tienda. Cuatro dígitos." : "Introduce el PIN de 4 dígitos para entrar al perfil infantil."}</p>
        </div>
        <div className="flex gap-3" aria-label="Dígitos del PIN">
          {Array.from({ length: 4 }).map((_, i) => (
            <span key={i} className={`flex h-14 w-12 items-center justify-center rounded-xl border text-2xl font-black transition-colors ${error ? "border-rose-500 bg-rose-500/10 text-rose-400" : i < entry.length ? "border-emerald-400 bg-emerald-400/10 text-emerald-300" : "border-white/15 text-slate-600"}`}>
              {i < entry.length ? "●" : ""}
            </span>
          ))}
        </div>
        {error && <p role="alert" className="text-xs font-bold text-rose-400">PIN incorrecto. Inténtalo de nuevo.</p>}
        <div className="grid grid-cols-3 gap-2">
          {["1","2","3","4","5","6","7","8","9","","0","del"].map((d, i) => d === "" ? <span key={i} /> : d === "del" ? (
            <button key={i} onClick={() => setEntry((e) => e.slice(0, -1))} aria-label="Borrar" className="flex h-14 w-16 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-slate-300 transition-colors hover:bg-white/10"><Delete size={19} /></button>
          ) : (
            <button key={i} onClick={() => press(d)} aria-label={`Dígito ${d}`} className="h-14 w-16 rounded-2xl border border-white/10 bg-white/5 font-display text-xl font-bold text-white transition-all hover:border-emerald-400/50 hover:bg-emerald-500/10 active:scale-95">{d}</button>
          ))}
        </div>
        <p className="text-[9px] uppercase tracking-[0.2em] text-slate-600">Control parental TV LO3 · el PIN se guarda cifrado en tu dispositivo</p>
      </div>
    );
  }

  const startWatching = (title: string, kind: "movie" | "series") => {
    setContinue((prev) => [{ kind, id: title, title, progress: 3 }, ...prev.filter((x) => x.id !== title)].slice(0, 8));
    onNavigate(kind === "movie" ? "movies" : "series");
  };

  return (
    <div className="flex h-full flex-col gap-3 overflow-y-auto p-3 thin-scroll sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-400/25 bg-gradient-to-r from-emerald-500/15 to-teal-600/10 p-4">
        <div className="flex items-center gap-3">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-600"><Baby size={26} className="text-white" /></span>
          <div>
            <h1 className="font-display text-xl font-black text-white">Hola, pequeño explorador</h1>
            <p className="text-[10px] uppercase tracking-wider text-emerald-300">Solo contenido infantil · filtrado y seguro</p>
          </div>
        </div>
        <button onClick={() => { setUnlocked(false); setEntry(""); }} className="ghost-btn flex h-10 items-center gap-2 rounded-xl px-4 text-[11px] font-bold text-emerald-200"><Lock size={13} /> Bloquear</button>
      </div>

      <h2 className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-400">Películas para hoy</h2>
      <div className="flex gap-2 overflow-x-auto pb-1 thin-scroll">
        {KIDS_MOVIES.map((m) => (
          <button key={m.qid} onClick={() => startWatching(m.title, "movie")} className="group w-24 shrink-0 text-left transition-transform hover:-translate-y-1">
            <span className="relative flex aspect-[2/3] flex-col justify-between overflow-hidden rounded-2xl border border-emerald-400/30 p-2" style={{ background: !pm && m.image ? `linear-gradient(rgba(4,6,26,.35), rgba(4,6,26,.35)), url(${m.image}) center/cover` : "linear-gradient(160deg, hsl(" + ((m.qid.charCodeAt(4) * 37) % 360) + " 55% 38%), hsl(" + ((m.qid.charCodeAt(4) * 37 + 50) % 360) + " 65% 14%))" }}>
              <span className="text-[8px] font-black uppercase tracking-widest text-white/70">{m.year}</span>
              <span className="font-display text-[10px] font-bold leading-tight text-white">{m.title}</span>
            </span>
            <span className="mt-1 block truncate text-[9px] font-bold text-slate-200">{m.title}</span>
            <span className="flex items-center gap-1 text-[8px] text-amber-300"><Star size={8} fill="currentColor" />Para peques</span>
          </button>
        ))}
      </div>

      <h2 className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-400">Series de animación</h2>
      <div className="flex gap-2 overflow-x-auto pb-1 thin-scroll">
        {KIDS_SERIES.map((s) => (
          <button key={s.id} onClick={() => startWatching(s.name, "series")} className="group w-24 shrink-0 text-left">
            <span className="block aspect-[2/3] overflow-hidden rounded-2xl border border-emerald-400/30 bg-cover bg-center" style={{ backgroundImage: !pm && s.image ? `url(${s.image})` : undefined, backgroundColor: "#0b3b33" }} aria-hidden="true" />
            <span className="mt-1 block truncate text-[10px] font-bold text-slate-200">{s.name}</span>
            <span className="flex items-center gap-1 text-[8px] text-amber-300"><Star size={8} fill="currentColor" />{s.rating ? `${s.rating}/10` : "Apta"}</span>
          </button>
        ))}
      </div>

      {/* parental rules */}
      <div className="tile rounded-2xl p-4">
        <h2 className="flex items-center gap-2 font-display text-sm font-bold text-white"><ShieldCheck size={15} className="text-emerald-400" /> Reglas de la casa</h2>
        <div className="mt-2 flex flex-wrap gap-2">
          {[
            { key: "onlyKids" as const, label: "Solo contenido infantil" },
            { key: "limitTwoHours" as const, label: "Máximo 2 h/día en pantalla" },
            { key: "hideStore" as const, label: "Ocultar tienda de apps" },
          ].map((r) => {
            const on = rules[r.key];
            return (
              <button key={r.key} role="switch" aria-checked={on} onClick={() => setRules((prev) => ({ ...prev, [r.key]: !prev[r.key] }))} className={`flex h-10 items-center gap-2 rounded-xl border px-3 text-[10px] font-bold transition-colors ${on ? "border-emerald-400/50 bg-emerald-400/15 text-emerald-300" : "border-white/10 bg-white/5 text-slate-400"}`}>
                <span className={`h-2.5 w-2.5 rounded-full ${on ? "bg-emerald-400" : "bg-slate-600"}`} />{r.label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
