import Link from "next/link";
import PlanCards from "@/components/PlanCards";
import { getSessionUser } from "@/lib/auth/session";
import { getPlans } from "@/lib/plans";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function PricingPage() {
  const [user, plans, settings] = await Promise.all([getSessionUser(), getPlans(), getSettings()]);
  const paid = plans;

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-10">
      <div className="mb-6 flex items-center justify-between">
        <Link href={user ? "/home" : "/"} className="text-sm text-violet-300">
          ← {user ? "Back to dashboard" : "Back to home"}
        </Link>
        {!user ? (
          <Link href="/login" className="btn btn-ghost btn-sm">
            Sign in
          </Link>
        ) : null}
      </div>
      <h1 className="text-3xl font-black leading-tight">
        Simple pricing for <span className="gradient-text">serious creators</span>
      </h1>
      <p className="mt-2 max-w-xl text-sm text-[color:var(--muted)]">
        {settings.brandName} plans are configurable by the site owner, so limits and prices always match what you see here.
        Cancel any time — saved content stays in your library.
      </p>

      <div className="mt-6">
        <PlanCards plans={paid} currentPlan={user?.planKey} signedIn={Boolean(user)} />
      </div>

      <p className="mt-6 text-xs text-[color:var(--muted)]">
        Results are creative suggestions only. {settings.brandName} never guarantees views, virality or performance.
      </p>
    </div>
  );
}
