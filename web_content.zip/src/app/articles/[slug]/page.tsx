"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, BookOpen, Clock, Heart, MessageCircle, ShieldCheck, TriangleAlert } from "lucide-react";
import { ArticleCard } from "@/components/cards";
import { useAuth, useI18n, useSite, useToast } from "@/components/providers";
import { Alert, buttonClass, Card, CardSkeleton, ErrorState } from "@/components/ui";
import { api } from "@/lib/api-client";
import type { ArticleDTO } from "@/lib/types";
import { formatDay, loc } from "@/lib/utils";

export default function ArticleDetailPage() {
  const { t, locale, te } = useI18n();
  const { categoryName, whatsapp } = useSite();
  const { user } = useAuth();
  const toast = useToast();
  const { slug } = useParams<{ slug: string }>();
  const [article, setArticle] = useState<ArticleDTO | null>(null);
  const [related, setRelated] = useState<ArticleDTO[]>([]);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState(false);
  const [favorited, setFavorited] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [pageUrl, setPageUrl] = useState("");

  useEffect(() => {
    setPageUrl(window.location.href);
  }, [slug]);

  useEffect(() => {
    let alive = true;
    setError(false);
    setNotFound(false);
    api<ArticleDTO>(`/api/articles/${encodeURIComponent(slug)}`)
      .then((a) => alive && setArticle(a))
      .catch((err: { status?: number }) => {
        if (!alive) return;
        if (err?.status === 404) setNotFound(true);
        else setError(true);
      });
    return () => {
      alive = false;
    };
  }, [slug, reloadKey]);

  useEffect(() => {
    if (!article) return;
    let alive = true;
    api<{ articles: ArticleDTO[] }>(`/api/articles?kind=article&category=${encodeURIComponent(article.category)}`)
      .then((r) => alive && setRelated(r.articles.filter((a) => a.id !== article.id).slice(0, 3)))
      .catch(() => alive && setRelated([]));
    return () => {
      alive = false;
    };
  }, [article]);

  useEffect(() => {
    if (!user || !article) return;
    let alive = true;
    api<{ articles: ArticleDTO[] }>("/api/favorites")
      .then((r) => alive && setFavorited(r.articles.some((a) => a.id === article.id)))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [user, article]);

  const paragraphs = useMemo(
    () => (article ? loc(article.body, locale).split(/\n\s*\n/).filter(Boolean) : []),
    [article, locale],
  );

  const toggleFavorite = async () => {
    if (!article) return;
    if (!user) {
      window.location.assign(`/login?next=/articles/${slug}`);
      return;
    }
    const previous = favorited;
    setFavorited(!previous);
    try {
      const res = await api<{ favorited: boolean }>("/api/favorites", { body: { articleId: article.id } });
      setFavorited(res.favorited);
      toast.success(res.favorited ? t("art.favAdded") : t("art.favRemoved"));
    } catch (err) {
      setFavorited(previous);
      toast.error(te(err));
    }
  };

  if (error) return <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />;
  if (notFound)
    return (
      <Card className="text-center">
        <p className="text-slate-700">{t("art.notFound")}</p>
        <Link href="/articles" className={buttonClass("primary", "md", "mt-4")}>
          {t("common.back")}
        </Link>
      </Card>
    );
  if (!article)
    return (
      <div className="space-y-4">
        <CardSkeleton lines={2} />
        <CardSkeleton lines={6} />
      </div>
    );

  const title = loc(article.title, locale);
  const shareText = t("wa.shareArticle", { title, url: pageUrl });
  const shareHref = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
  const reviewed = !!article.reviewedBy && !!article.reviewedAt;

  return (
    <article className="mx-auto max-w-3xl">
      <Link href="/articles" className="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-teal-700">
        <ArrowLeft className="h-4 w-4 rtl:rotate-180" />
        {t("common.back")}
      </Link>

      <header className="rounded-3xl bg-gradient-to-br from-sky-50 via-white to-teal-50 p-6 ring-1 ring-sky-100 sm:p-10">
        <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-teal-800">
          <span className="rounded-full bg-white px-3 py-1 ring-1 ring-teal-100">{categoryName(article.category)}</span>
          <span className="inline-flex items-center gap-1 text-slate-500">
            <Clock className="h-3.5 w-3.5" />
            {t("art.readTime", { n: article.readMinutes })}
          </span>
        </div>
        <div className="mt-5 flex items-start gap-4">
          <span className="text-4xl" aria-hidden>
            {article.emoji}
          </span>
          <div className="min-w-0">
            <h1 className="text-2xl font-extrabold leading-tight text-slate-900 sm:text-3xl">{title}</h1>
            <p className="mt-3 text-base leading-relaxed text-slate-600">{loc(article.summary, locale)}</p>
          </div>
        </div>
        <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-white pt-5">
          <div className="space-y-1 text-sm text-slate-600">
            <p className="text-slate-500">{t("art.lastUpdated", { date: formatDay(article.updatedAt, locale) })}</p>
            <p className="inline-flex items-center gap-2">
              <ShieldCheck className={reviewed ? "h-4 w-4 text-emerald-600" : "h-4 w-4 text-amber-600"} />
              {reviewed
                ? t("art.reviewedOn", { name: article.reviewedBy, date: formatDay(article.reviewedAt as string, locale) })
                : t("art.validationPending")}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => void toggleFavorite()} aria-pressed={favorited} className={buttonClass(favorited ? "danger" : "outline", "sm")}>
              <Heart className={favorited ? "h-4 w-4 fill-rose-500 text-rose-500" : "h-4 w-4"} />
              {favorited ? t("art.favRemove") : t("art.favAdd")}
            </button>
            <a href={shareHref} target="_blank" rel="noopener noreferrer" className={buttonClass("whatsapp", "sm")}>
              <MessageCircle className="h-4 w-4" />
              {t("btn.share")}
            </a>
          </div>
        </div>
      </header>

      <div className="mt-6">
        <Alert tone="warning">
          <span className="inline-flex items-start gap-2">
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
            {t("art.disclaimer")}
          </span>
        </Alert>
      </div>

      <div className="mt-8 space-y-5 text-[16px] leading-8 text-slate-700">
        {paragraphs.map((p, i) => (
          <p key={i}>{p}</p>
        ))}
      </div>

      {article.sources.length > 0 && (
        <section className="mt-10 rounded-2xl bg-slate-50 p-5 ring-1 ring-slate-100">
          <h2 className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-900">
            <BookOpen className="h-4 w-4 text-teal-600" />
            {t("art.sources")}
          </h2>
          <ol className="list-decimal space-y-1.5 ps-5 text-sm leading-relaxed text-slate-600">
            {article.sources.map((s) => (
              <li key={s} dir="ltr" className="text-start">
                {s}
              </li>
            ))}
          </ol>
        </section>
      )}

      {related.length > 0 && (
        <section className="mt-12">
          <h2 className="mb-5 text-lg font-bold text-slate-900">{t("art.related")}</h2>
          <div className="grid gap-5 md:grid-cols-3">
            {related.map((r) => (
              <ArticleCard key={r.id} article={r} />
            ))}
          </div>
        </section>
      )}
    </article>
  );
}
