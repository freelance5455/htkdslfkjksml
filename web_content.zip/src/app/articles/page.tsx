"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { BookOpen, Heart, Lightbulb, Search } from "lucide-react";
import { useAuth, useI18n, useSite, useToast } from "@/components/providers";
import { ArticleCard, TipCard } from "@/components/cards";
import { CardSkeleton, Chip, EmptyState, ErrorState, Input, LoginPrompt, PageHeader, Tabs } from "@/components/ui";
import { api } from "@/lib/api-client";

import type { ArticleDTO } from "@/lib/types";

type Tab = "articles" | "tips" | "favorites";

export default function ArticlesPage() {
  return (
    <Suspense fallback={<div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3"><CardSkeleton /><CardSkeleton /><CardSkeleton /></div>}>
      <ArticlesContent />
    </Suspense>
  );
}

function ArticlesContent() {
  const { t, te } = useI18n();
  const { categories, categoryName } = useSite();
  const { user, loading: authLoading } = useAuth();
  const toast = useToast();
  const router = useRouter();
  const params = useSearchParams();

  const [tab, setTab] = useState<Tab>(params.get("tab") === "favorites" ? "favorites" : "articles");
  const [q, setQ] = useState(params.get("q") ?? "");
  const [debouncedQ, setDebouncedQ] = useState(q);
  const [category, setCategory] = useState("");
  const [items, setItems] = useState<ArticleDTO[] | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [favIds, setFavIds] = useState<Set<string>>(new Set());
  const [favItems, setFavItems] = useState<ArticleDTO[] | null>(null);

  useEffect(() => {
    const id = window.setTimeout(() => setDebouncedQ(q.trim()), 300);
    return () => window.clearTimeout(id);
  }, [q]);

  useEffect(() => {
    if (tab === "favorites") return;
    let alive = true;
    setError(false);
    setItems(null);
    const qs = new URLSearchParams({ kind: tab === "tips" ? "tip" : "article" });
    if (category) qs.set("category", category);
    if (debouncedQ) qs.set("q", debouncedQ);
    api<{ articles: ArticleDTO[] }>(`/api/articles?${qs.toString()}`)
      .then((r) => alive && setItems(r.articles))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [tab, category, debouncedQ, reloadKey]);

  useEffect(() => {
    if (!user) {
      setFavIds(new Set());
      setFavItems(null);
      return;
    }
    let alive = true;
    api<{ articles: ArticleDTO[] }>("/api/favorites")
      .then((r) => {
        if (!alive) return;
        setFavItems(r.articles);
        setFavIds(new Set(r.articles.map((a) => a.id)));
      })
      .catch(() => alive && setFavItems([]));
    return () => {
      alive = false;
    };
  }, [user]);

  /** Optimistic favourite toggle: UI updates immediately and rolls back if the request fails. */
  const toggleFavorite = async (article: ArticleDTO) => {
    if (!user) {
      toast.info(t("art.loginToSave"));
      router.push("/login?next=/articles");
      return;
    }
    const wasFav = favIds.has(article.id);
    setFavIds((prev) => {
      const next = new Set(prev);
      if (wasFav) next.delete(article.id);
      else next.add(article.id);
      return next;
    });
    setFavItems((prev) => (wasFav ? (prev ?? []).filter((a) => a.id !== article.id) : [article, ...(prev ?? [])]));
    try {
      const res = await api<{ favorited: boolean }>("/api/favorites", { body: { articleId: article.id } });
      toast.success(res.favorited ? t("art.favAdded") : t("art.favRemoved"));
    } catch (err) {
      setFavIds((prev) => {
        const next = new Set(prev);
        if (wasFav) next.add(article.id);
        else next.delete(article.id);
        return next;
      });
      setFavItems((prev) => (wasFav ? [article, ...(prev ?? [])] : (prev ?? []).filter((a) => a.id !== article.id)));
      toast.error(te(err));
    }
  };

  const tabs = [
    { value: "articles" as Tab, label: t("art.tabArticles"), icon: BookOpen },
    { value: "tips" as Tab, label: t("art.tabTips"), icon: Lightbulb },
    { value: "favorites" as Tab, label: t("art.tabFavorites"), icon: Heart, count: user && favItems ? favItems.length : undefined },
  ];

  const renderGrid = () => {
    if (error)
      return <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />;
    if (!items)
      return (
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <CardSkeleton key={i} lines={3} />
          ))}
        </div>
      );
    if (items.length === 0)
      return (
        <EmptyState
          icon={Search}
          title={tab === "tips" ? t("art.noTips") : t("art.noArticles")}
          action={q || category ? <button type="button" className="text-sm font-semibold text-teal-700 underline" onClick={() => { setQ(""); setCategory(""); }}>{t("common.reset")}</button> : undefined}
        />
      );
    if (tab === "tips")
      return (
        <div className="grid gap-4 md:grid-cols-2">
          {items.map((tip) => (
            <TipCard key={tip.id} tip={tip} />
          ))}
        </div>
      );
    return (
      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {items.map((a) => (
          <ArticleCard key={a.id} article={a} favorited={favIds.has(a.id)} onToggleFavorite={() => void toggleFavorite(a)} />
        ))}
      </div>
    );
  };

  const renderFavorites = () => {
    if (authLoading) return <CardSkeleton />;
    if (!user) return <LoginPrompt message={t("art.loginToSave")} next="/articles?tab=favorites" />;
    if (!favItems)
      return (
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          <CardSkeleton />
          <CardSkeleton />
        </div>
      );
    if (favItems.length === 0) return <EmptyState icon={Heart} title={t("art.noFavorites")} />;
    return (
      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {favItems.map((a) => (
          <ArticleCard key={a.id} article={a} favorited onToggleFavorite={() => void toggleFavorite(a)} />
        ))}
      </div>
    );
  };

  return (
    <div>
      <PageHeader title={t("art.title")} subtitle={t("art.subtitle")} />

      <div className="mb-6 space-y-4">
        <Tabs items={tabs} value={tab} onChange={setTab} />
        {tab !== "favorites" && (
          <>
            <div className="relative">
              <Search className="pointer-events-none absolute start-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <Input
                type="search"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t("art.searchPlaceholder")}
                aria-label={t("common.search")}
                className="ps-11"
              />
            </div>
            {tab === "articles" && (
              <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
                <Chip active={category === ""} onClick={() => setCategory("")}>
                  {t("art.allCategories")}
                </Chip>
                {categories.map((c) => (
                  <Chip key={c.slug} active={category === c.slug} onClick={() => setCategory(c.slug)}>
                    {categoryName(c.slug)}
                  </Chip>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      {tab === "favorites" ? renderFavorites() : renderGrid()}
    </div>
  );
}
