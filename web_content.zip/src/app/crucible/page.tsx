"use client";

import dynamic from "next/dynamic";
import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Scale, ChevronRight, Gavel } from "lucide-react";
import { Nav, PillarBar } from "@/components/Shell";
import Onboard from "@/components/Onboard";
import { useMindStore, useHydrateMind } from "@/lib/store";
import { sfx } from "@/lib/sound";

const MindScene = dynamic(() => import("@/components/MindScene"), { ssr: false });
const ease = [0.22, 1, 0.36, 1] as const;

interface Decision {
  id: string;
  s: string;
  title: string;
  narrative: string;
  difficulty: number;
  choices: { text: string }[];
  remaining: number;
}

interface Resolution {
  score: number;
  cascade: string;
  xp: number;
  optimalText: string;
  deltaPillars: { c: number; i: number; p: number };
  mind: { creativity: number; imagination: number; pattern: number; mindIndex: number; title: { title: string } };
}

export default function CruciblePage() {
  useHydrateMind();
  const hydrated = useMindStore((s) => s.hydrated);
  const mind = useMindStore((s) => s.mind);
  const patchMind = useMindStore((s) => s.patchMind);

  const [decision, setDecision] = useState<Decision | null>(null);
  const [res, setRes] = useState<Resolution | null>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [chars, setChars] = useState(0);

  const load = useCallback(async () => {
    const m = useMindStore.getState().mind;
    if (!m) return;
    setDecision(null);
    setRes(null);
    setPicked(null);
    setChars(0);
    const r = await fetch(`/api/decision?mindId=${m.id}`);
    const d = await r.json();
    setDecision(d.decision);
  }, []);

  // Load when a mind appears — mind stat updates (same id) must NOT refetch
  useEffect(() => {
    void load();
  }, [load, mind?.id]);

  // typewriter
  useEffect(() => {
    if (!decision) return;
    const total = decision.narrative.length;
    setChars(0);
    const id = window.setInterval(() => {
      setChars((c) => {
        if (c >= total) {
          window.clearInterval(id);
          return c;
        }
        return c + 3;
      });
    }, 18);
    return () => window.clearInterval(id);
  }, [decision]);

  async function choose(i: number) {
    if (!mind || !decision || busy || res) return;
    setBusy(true);
    setPicked(i);
    sfx.click();
    const r = await fetch("/api/decision", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mindId: mind.id, decisionId: decision.id, choiceIndex: i, s: decision.s }),
    });
    const data: Resolution = await r.json();
    setRes(data);
    patchMind({
      creativity: data.mind.creativity,
      imagination: data.mind.imagination,
      pattern: data.mind.pattern,
      mindIndex: data.mind.mindIndex,
      title: data.mind.title.title,
    });
    if (data.score >= 7) sfx.correct(); else sfx.wrong();
    setBusy(false);
  }

  if (!hydrated) return <main className="grid min-h-screen place-items-center bg-void"><p className="font-mono text-[10px] tracking-[0.5em] text-ash">CALIBRATING…</p></main>;
  if (!mind) {
    return (
      <main className="relative min-h-screen">
        <Nav />
        <div className="absolute inset-0"><MindScene dim /></div>
        <Onboard onDone={() => {}} />
      </main>
    );
  }

  return (
    <main className="relative min-h-screen">
      <Nav />
      <div className="absolute inset-0"><MindScene dim /></div>

      <div className="relative z-10 mx-auto min-h-screen max-w-4xl px-5 pb-24 pt-24">
        <div className="panel mb-8 grid gap-4 p-4 md:grid-cols-[1fr_auto]">
          <div className="grid gap-2">
            <PillarBar label="LATERAL CREATION" value={mind.creativity} glyph="◬" color="#e9c46a" />
            <PillarBar label="IMAGINATIVE PHYSICS" value={mind.imagination} glyph="◍" color="#8b7cff" />
            <PillarBar label="PATTERN & KNOWLEDGE" value={mind.pattern} glyph="◈" color="#3ddc97" />
          </div>
          <div className="flex items-center gap-6 border-l hairline pl-6 font-mono text-[10px] tracking-[0.2em] text-ash md:flex-col md:items-end md:justify-center">
            <div className="flex items-center gap-2"><span>MIND INDEX</span><span className="text-2xl text-violet-x text-glow-violet">{mind.mindIndex}</span></div>
            <div className="text-amber-x">{mind.title.toString().toUpperCase()}</div>
          </div>
        </div>

        <div className="mb-6 flex items-center justify-between font-mono text-[10px] tracking-[0.3em] text-ash">
          <span className="flex items-center gap-2"><Scale className="h-4 w-4 text-amber-x" />DECISION CRUCIBLE</span>
          {decision && <span>SCENARIO VAULT · {decision.remaining} UNRESOLVED</span>}
        </div>

        <AnimatePresence mode="wait">
          {!decision ? (
            <motion.div key="load" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="panel grid min-h-[400px] place-items-center p-12">
              <p className="font-mono text-[10px] tracking-[0.4em] text-ash">SUMMONING A SCENARIO…</p>
            </motion.div>
          ) : (
            <motion.div key={decision.id} initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.6, ease }} className="panel panel-hot p-8 md:p-12">
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                <h2 className="font-display text-4xl md:text-5xl">{decision.title}</h2>
                <span className="font-mono text-[10px] tracking-[0.3em] text-blood">SEVERITY {decision.difficulty}/10</span>
              </div>

              <p className="mt-6 min-h-[120px] font-display text-lg italic leading-relaxed text-ivory/90 md:text-xl">
                {decision.narrative.slice(0, chars)}
                {chars < decision.narrative.length && <span className="text-violet-x">▌</span>}
              </p>

              <div className="mt-8 grid gap-3">
                {decision.choices.map((c, i) => {
                  let cls = "";
                  if (res) {
                    if (i === picked) cls = res.score >= 7 ? "border-jade bg-jade/10 text-jade" : "border-amber-x/70 bg-amber-x/10 text-amber-x";
                    else cls = "opacity-40";
                  }
                  return (
                    <button
                      key={i}
                      disabled={!!res || busy}
                      onClick={() => choose(i)}
                      className={`opt-card flex items-center gap-5 border hairline bg-void/60 px-6 py-4 text-left ${cls}`}
                    >
                      <span className="font-mono text-[10px] tracking-widest text-violet-x">{["A", "B", "C", "D"][i]}</span>
                      <span className="text-sm md:text-base">{c.text}</span>
                    </button>
                  );
                })}
              </div>

              <AnimatePresence>
                {res && (
                  <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease }} className="mt-8 border-t hairline pt-6">
                    <div className="flex flex-wrap items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <Gavel className="h-5 w-5 text-amber-x" />
                        <p className="font-mono text-[10px] tracking-[0.4em] text-amber-x">CONSEQUENCE CASCADE</p>
                      </div>
                      <div className="flex items-center gap-6 font-mono text-[10px] tracking-widest">
                        <span className={res.score >= 7 ? "text-jade" : res.score >= 4 ? "text-amber-x" : "text-blood"}>
                          WISDOM {res.score}/10
                        </span>
                        <span className="text-violet-x">+{res.xp} XP</span>
                        {res.deltaPillars.c > 0 && <span className="text-amber-x">◬ +{res.deltaPillars.c}</span>}
                        {res.deltaPillars.i > 0 && <span className="text-violet-x">◍ +{res.deltaPillars.i}</span>}
                        {res.deltaPillars.p > 0 && <span className="text-jade">◈ +{res.deltaPillars.p}</span>}
                      </div>
                    </div>
                    <p className="mt-4 border-l-2 border-amber-x/50 pl-4 font-display text-base italic leading-relaxed text-ash">
                      {res.cascade}
                    </p>
                    {res.score < 10 && (
                      <p className="mt-3 font-mono text-[10px] tracking-[0.2em] text-jade">
                        THE MASTERMIND PATH WAS: <span className="text-ivory">{res.optimalText}</span>
                      </p>
                    )}
                    <button onClick={() => { sfx.click(); void load(); }} className="btn-crucible mt-6 inline-flex items-center gap-2 border border-amber-x/60 px-8 py-3 font-mono text-[10px] tracking-[0.3em] text-amber-x">
                      NEXT CRUCIBLE <ChevronRight className="h-3 w-3" />
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>

        <p className="mt-6 text-center font-mono text-[10px] tracking-[0.25em] text-ash/60">
          SCORES ARE HIDDEN UNTIL FATE RESOLVES — LIKE REAL LIFE.
        </p>
      </div>
    </main>
  );
}
