"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { listCompetitions } from "@/lib/competition-store";
import type { Competition } from "@/lib/competition";
import { TrophyIcon } from "@/components/cricket";
import { CompetitionLogo } from "@/components/competition-ui";

export default function LeaguesPage() {
  const [comps, setComps] = useState<Competition[] | null>(null);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const all = await listCompetitions();
      if (alive) setComps(all);
    };
    void load();
    const t = setInterval(() => void load(), 5000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  return (
    <main className="mx-auto max-w-6xl px-3 py-6 sm:px-4 sm:py-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <TrophyIcon className="h-5 w-5 text-amber-400" />
          <h1 className="text-2xl font-black tracking-tight sm:text-3xl">
            Leagues &amp; Tournaments
          </h1>
        </div>
        <Link
          href="/leagues-new"
          className="mc-btn inline-flex h-9 items-center rounded-lg bg-emerald-500 px-3 text-xs font-black text-slate-950 hover:bg-emerald-400"
        >
          New Competition
        </Link>
      </div>
      <p className="mt-1 text-sm text-slate-400">
        Run round-robin leagues and knockout tournaments. Fixtures open directly in the existing
        scoring engine and results flow straight back into the table.
      </p>

      {comps === null ? (
        <p className="mt-8 text-center text-sm text-slate-500">Loading…</p>
      ) : comps.length === 0 ? (
        <div className="mc-card mt-6 px-6 py-12 text-center">
          <TrophyIcon className="mx-auto h-8 w-8 text-slate-700" />
          <p className="mt-3 text-sm text-slate-400">No competitions yet.</p>
          <Link
            href="/leagues-new"
            className="mc-btn mt-4 inline-flex h-10 items-center rounded-lg bg-emerald-500 px-4 text-sm font-black text-slate-950"
          >
            Create your first competition
          </Link>
        </div>
      ) : (
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {comps.map((c) => {
            const done = c.fixtures.filter((f) => f.status === "completed").length;
            const live = c.fixtures.filter((f) => f.status === "live").length;
            return (
              <Link
                key={c.id}
                href={`/league?id=${c.id}`}
                className="mc-card mc-btn flex flex-col gap-2 px-4 py-4 hover:border-emerald-500/40"
              >
                <div className="flex items-center gap-2.5">
                  <CompetitionLogo name={c.name} logo={c.logo} size={36} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-black">{c.name}</p>
                    <p className="text-[11px] text-slate-400">
                      {c.type === "league" ? "League" : "Tournament"}
                      {c.season ? ` · ${c.season}` : ""}
                    </p>
                  </div>
                  {live > 0 && (
                    <span className="shrink-0 rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] font-black text-red-400">
                      LIVE
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap gap-1.5 text-[11px]">
                  <Pill>{c.teams.length} teams</Pill>
                  <Pill>{c.fixtures.length} fixtures</Pill>
                  <Pill>
                    {done}/{c.fixtures.length} played
                  </Pill>
                  <Pill>{c.overs} ov</Pill>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </main>
  );
}

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full border border-slate-800 bg-slate-900/60 px-2 py-0.5 font-semibold text-slate-400">
      {children}
    </span>
  );
}
