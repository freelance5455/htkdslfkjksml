"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { BadgeCheck, HeartHandshake, UserPlus } from "lucide-react";
import { useAuth, useI18n, useToast, type ProfessionalSummary } from "@/components/providers";
import { Alert, buttonClass, Card, Checkbox, Field, Input, Select, Textarea } from "@/components/ui";
import { api } from "@/lib/api-client";
import { MOROCCAN_CITIES, PROFESSIONS } from "@/lib/constants";
import type { CurrentUser, ServiceDTO } from "@/lib/types";
import { loc } from "@/lib/utils";
import { cn } from "@/lib/utils";

type Role = "patient" | "professional";

export default function RegisterPage() {
  const { t, te, locale } = useI18n();
  const { setSession } = useAuth();
  const toast = useToast();
  const router = useRouter();
  const [role, setRole] = useState<Role>("patient");
  const [services, setServices] = useState<ServiceDTO[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    password: "",
    phone: "",
    city: "Casablanca",
    profession: "nurse",
    licenseNumber: "",
    experienceYears: 0,
    qualifications: "",
    bio: "",
    serviceCodes: [] as string[],
    serviceCities: [] as string[],
    consent: false,
  });

  useEffect(() => {
    api<{ services: ServiceDTO[] }>("/api/services")
      .then((r) => setServices(r.services))
      .catch(() => undefined);
  }, []);

  const toggle = (key: "serviceCodes" | "serviceCities", value: string) =>
    setForm((f) => ({
      ...f,
      [key]: f[key].includes(value) ? f[key].filter((x) => x !== value) : [...f[key], value],
    }));

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.consent) {
      toast.error(t("err.invalid_input"));
      return;
    }
    setSubmitting(true);
    try {
      const body =
        role === "professional"
          ? {
              role,
              fullName: form.fullName.trim(),
              email: form.email.trim(),
              password: form.password,
              phone: form.phone.replace(/[\s.-]/g, ""),
              city: form.city,
              locale,
              profession: form.profession,
              licenseNumber: form.licenseNumber.trim(),
              experienceYears: Number(form.experienceYears) || 0,
              qualifications: form.qualifications.trim(),
              bio: form.bio.trim(),
              serviceCodes: form.serviceCodes,
              serviceCities: form.serviceCities,
              consent: true,
            }
          : {
              role,
              fullName: form.fullName.trim(),
              email: form.email.trim(),
              password: form.password,
              phone: form.phone.replace(/[\s.-]/g, ""),
              city: form.city,
              locale,
              consent: true,
            };
      const res = await api<{ user: CurrentUser; professional: ProfessionalSummary | null }>("/api/auth/register", { body });
      setSession(res.user, res.professional);
      if (res.professional) {
        toast.info(t("auth.pendingNotice"));
        router.push("/profile");
      } else {
        toast.success(t("auth.registerSuccess"));
        router.push("/");
      }
    } catch (err) {
      toast.error(te(err));
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-extrabold text-slate-900 sm:text-3xl">{t("auth.registerTitle")}</h1>
        <p className="mt-2 text-slate-600">{t("auth.registerSubtitle")}</p>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-2 rounded-2xl bg-slate-100/80 p-1.5" role="tablist">
        {(
          [
            { value: "patient", label: t("auth.asPatient"), icon: HeartHandshake },
            { value: "professional", label: t("auth.asProfessional"), icon: BadgeCheck },
          ] as const
        ).map((opt) => (
          <button
            key={opt.value}
            type="button"
            role="tab"
            aria-selected={role === opt.value}
            onClick={() => setRole(opt.value)}
            className={cn(
              "flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition",
              role === opt.value ? "bg-white text-teal-700 shadow-sm" : "text-slate-600 hover:text-slate-900",
            )}
          >
            <opt.icon className="h-4 w-4" />
            {opt.label}
          </button>
        ))}
      </div>

      <Card className="sm:p-8">
        <form onSubmit={onSubmit} className="space-y-6" noValidate>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={t("auth.fullName")} htmlFor="fullName">
              <Input id="fullName" required autoComplete="name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
            </Field>
            <Field label={t("common.email")} htmlFor="email">
              <Input id="email" dir="ltr" type="email" required autoComplete="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </Field>
            <Field label={t("common.password")} htmlFor="password" hint={t("auth.passwordRule")}>
              <Input id="password" type="password" required autoComplete="new-password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </Field>
            <Field label={t("common.phone")} htmlFor="phone">
              <Input id="phone" dir="ltr" type="tel" required autoComplete="tel" placeholder="06 12 34 56 78" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </Field>
            <Field label={t("auth.city")} htmlFor="city">
              <Select id="city" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })}>
                {MOROCCAN_CITIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          {role === "professional" && (
            <div className="space-y-5 rounded-2xl bg-sky-50/50 p-5 ring-1 ring-sky-100">
              <Alert tone="info">{t("auth.proNote")}</Alert>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label={t("auth.profession")} htmlFor="profession">
                  <Select id="profession" value={form.profession} onChange={(e) => setForm({ ...form, profession: e.target.value })}>
                    {PROFESSIONS.map((p) => (
                      <option key={p} value={p}>
                        {t(`pro.profession.${p}`)}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label={t("auth.licenseNumber")} htmlFor="license">
                  <Input id="license" value={form.licenseNumber} onChange={(e) => setForm({ ...form, licenseNumber: e.target.value })} />
                </Field>
                <Field label={t("auth.experience")} htmlFor="experience">
                  <Input id="experience" type="number" min={0} max={60} value={form.experienceYears} onChange={(e) => setForm({ ...form, experienceYears: Number(e.target.value) })} />
                </Field>
              </div>
              <Field label={t("auth.qualifications")} htmlFor="qualifications">
                <Textarea id="qualifications" rows={3} value={form.qualifications} onChange={(e) => setForm({ ...form, qualifications: e.target.value })} />
              </Field>
              <Field label={t("auth.bio")} htmlFor="bio">
                <Textarea id="bio" rows={3} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
              </Field>
              <div>
                <p className="mb-2 text-sm font-medium text-slate-700">{t("auth.services")}</p>
                <div className="grid gap-2 sm:grid-cols-2">
                  {services.map((s) => (
                    <Checkbox
                      key={s.id}
                      id={`svc-${s.slug}`}
                      checked={form.serviceCodes.includes(s.slug)}
                      onChange={() => toggle("serviceCodes", s.slug)}
                      label={loc(s.name, locale)}
                    />
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-2 text-sm font-medium text-slate-700">{t("auth.cities")}</p>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {MOROCCAN_CITIES.map((c) => (
                    <Checkbox key={c} id={`city-${c}`} checked={form.serviceCities.includes(c)} onChange={() => toggle("serviceCities", c)} label={c} />
                  ))}
                </div>
              </div>
            </div>
          )}

          <Checkbox id="consent" checked={form.consent} onChange={(v) => setForm({ ...form, consent: v })} label={t("auth.consent")} />

          <button type="submit" disabled={submitting} className={buttonClass("primary", "lg", "w-full")}>
            <UserPlus className="h-5 w-5" />
            {submitting ? t("common.loading") : t("nav.register")}
          </button>
        </form>
      </Card>

      <p className="mt-6 text-center text-sm text-slate-600">
        {t("auth.haveAccount")}{" "}
        <Link href="/login" className="font-semibold text-teal-700 hover:underline">
          {t("nav.login")}
        </Link>
      </p>
    </div>
  );
}
