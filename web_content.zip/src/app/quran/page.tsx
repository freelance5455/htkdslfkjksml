import type { Metadata } from "next";
import Link from "next/link";
import { BookOpen } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { SurahSearch } from "@/components/surah-search";
import { SURAHS, TOTAL_AYAHS } from "@/data/surahs";
import { toArabicDigits } from "@/lib/site";

export const metadata: Metadata = {
  title: "القرآن الكريم",
  description: "فهرس سور القرآن الكريم بالرسم العثماني مع التلاوة الصوتية لكل آية.",
};

export default function QuranPage() {
  return (
    <main>
      <PageHero
        eyebrow="تجربة المصحف"
        title={
          <>
            القرآن <span className="text-gold-gradient">الكريم</span>
          </>
        }
        description="اقرأ وتدبّر آيات كتاب الله بالرسم العثماني، واستمع لكل آية بصوت الشيخ مشاري العفاسي."
      >
        <Link
          href="/quran/1"
          className="inline-flex items-center gap-3 rounded-full bg-gradient-to-b from-gold-light to-gold px-8 py-4 font-semibold text-navy shadow-[0_20px_50px_-15px_rgba(182,154,105,0.9)] transition-all hover:-translate-y-0.5"
        >
          <BookOpen className="size-5" aria-hidden="true" />
          ابدأ بسورة الفاتحة
        </Link>
      </PageHero>

      <section className="relative bg-ivory py-20 sm:py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <dl className="mb-14 grid grid-cols-3 divide-x divide-x-reverse divide-gold/30 rounded-3xl border border-gold/30 bg-card p-6 text-center shadow-[0_30px_60px_-40px_rgba(23,36,58,0.5)]">
            <div className="px-4">
              <dt className="text-sm text-navy/60">سورة</dt>
              <dd className="mt-1 font-serif text-4xl font-bold text-navy">{toArabicDigits(SURAHS.length)}</dd>
            </div>
            <div className="px-4">
              <dt className="text-sm text-navy/60">آية</dt>
              <dd className="mt-1 font-serif text-4xl font-bold text-navy">{toArabicDigits(TOTAL_AYAHS)}</dd>
            </div>
            <div className="px-4">
              <dt className="text-sm text-navy/60">جزءًا</dt>
              <dd className="mt-1 font-serif text-4xl font-bold text-navy">{toArabicDigits(30)}</dd>
            </div>
          </dl>

          <SurahSearch />
        </div>
      </section>
    </main>
  );
}
