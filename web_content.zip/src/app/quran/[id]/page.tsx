import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, List } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { QuranReader } from "@/components/quran-reader";
import { getSurah } from "@/data/surahs";
import { fetchSurahText } from "@/lib/quran";
import { toArabicDigits } from "@/lib/site";

type Params = { params: Promise<{ id: string }> };

function parseSurahId(raw: string): number | null {
  if (!/^\d+$/.test(raw)) return null;
  const n = Number(raw);
  return Number.isInteger(n) && n >= 1 && n <= 114 ? n : null;
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { id } = await params;
  const n = parseSurahId(id);
  const meta = n ? getSurah(n) : undefined;
  if (!meta) return { title: "سورة غير موجودة" };
  return {
    title: `سورة ${meta.name}`,
    description: `تلاوة سورة ${meta.name} (${meta.english}) بالرسم العثماني مع التلاوة الصوتية لكل آية.`,
  };
}

export default async function SurahPage({ params }: Params) {
  const { id } = await params;
  const n = parseSurahId(id);
  if (!n) notFound();

  const meta = getSurah(n);
  if (!meta) notFound();

  const surah = await fetchSurahText(n);
  const prev = n > 1 ? getSurah(n - 1) : undefined;
  const next = n < 114 ? getSurah(n + 1) : undefined;
  const showBasmala = n !== 1 && n !== 9;

  return (
    <main>
      <PageHero
        eyebrow={`القرآن الكريم · السورة ${toArabicDigits(n)}`}
        title={<>سورة {meta.name}</>}
        description={`${meta.english} · ${toArabicDigits(meta.ayahs)} آية · ${
          meta.revelation === "M" ? "مكية" : "مدنية"
        }`}
      >
        <Link
          href="/quran"
          className="inline-flex items-center gap-2 rounded-full border border-gold/50 px-6 py-3 text-sm text-gold-light transition-all hover:bg-gold hover:text-navy"
        >
          <List className="size-4" aria-hidden="true" />
          فهرس السور
        </Link>
      </PageHero>

      <section className="relative bg-ivory py-16 sm:py-20">
        <div className="mx-auto max-w-4xl px-5 lg:px-8">
          {showBasmala && (
            <p className="mb-12 text-center font-serif text-4xl text-navy/85" lang="ar">
              بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
            </p>
          )}

          {surah ? (
            <QuranReader ayahs={surah.ayahs} surahName={`سورة ${meta.name}`} />
          ) : (
            <div role="alert" className="rounded-3xl border border-destructive/30 bg-destructive/5 p-8 text-center">
              <p className="font-serif text-2xl font-bold text-destructive">تعذّر تحميل نص السورة الآن</p>
              <p className="mt-3 leading-8 text-navy/70">
                خدمة نصوص القرآن غير متاحة مؤقتاً. يرجى تحديث الصفحة بعد قليل.
              </p>
            </div>
          )}

          <nav aria-label="التنقل بين السور" className="mt-14 grid gap-4 sm:grid-cols-2">
            {prev ? (
              <Link
                href={`/quran/${prev.number}`}
                className="group flex items-center justify-between gap-4 rounded-3xl border border-border bg-card p-6 transition-all hover:-translate-y-0.5 hover:border-gold/60"
              >
                <span className="flex items-center gap-3">
                  <ArrowRight className="size-5 text-gold transition-transform group-hover:translate-x-1" aria-hidden="true" />
                  <span className="text-sm text-navy/60">السورة السابقة</span>
                </span>
                <span className="font-serif text-xl font-bold text-navy">سورة {prev.name}</span>
              </Link>
            ) : (
              <span className="hidden sm:block" />
            )}
            {next ? (
              <Link
                href={`/quran/${next.number}`}
                className="group flex items-center justify-between gap-4 rounded-3xl border border-border bg-card p-6 transition-all hover:-translate-y-0.5 hover:border-gold/60"
              >
                <span className="font-serif text-xl font-bold text-navy">سورة {next.name}</span>
                <span className="flex items-center gap-3">
                  <span className="text-sm text-navy/60">السورة التالية</span>
                  <ArrowLeft className="size-5 text-gold transition-transform group-hover:-translate-x-1" aria-hidden="true" />
                </span>
              </Link>
            ) : (
              <span className="hidden sm:block" />
            )}
          </nav>
        </div>
      </section>
    </main>
  );
}
