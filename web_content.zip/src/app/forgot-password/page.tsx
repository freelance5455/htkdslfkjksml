import AuthCard from "@/components/AuthCard";

export const dynamic = "force-dynamic";

export default function ForgotPasswordPage() {
  return <AuthCard mode="forgot" />;
}
