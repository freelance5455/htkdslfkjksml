"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";
import { KeyRound, Mail } from "lucide-react";
import { useI18n, useToast } from "@/components/providers";
import { Alert, buttonClass, Card, CardSkeleton, Field, Input } from "@/components/ui";
import { api } from "@/lib/api-client";

export default function ForgotPasswordPage() {
  return (
    <Suspense fallback={<CardSkeleton lines={4} />}>
      <RecoveryFlow />
    </Suspense>
  );
}

/** Same page handles both steps: request a link (no token) and set a new password (?token=...). */
function RecoveryFlow() {
  const params = useSearchParams();
  const token = params.get("token");
  return (
    <div className="mx-auto max-w-md">
      {token ? <ResetForm token={token} /> : <RequestForm />}
    </div>
  );
}

function RequestForm() {
  const { t, te } = useI18n();
  const toast = useToast();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [demoUrl, setDemoUrl] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api<{ ok: boolean; demoResetUrl: string | null }>("/api/auth/forgot", { body: { email: email.trim() } });
      setSent(true);
      setDemoUrl(res.demoResetUrl);
    } catch (err) {
      toast.error(te(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="space-y-6 sm:p-8">
      <div className="text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-50 text-teal-600">
          <KeyRound className="h-7 w-7" />
        </span>
        <h1 className="mt-4 text-xl font-bold text-slate-900">{t("auth.forgotTitle")}</h1>
        <p className="mt-2 text-sm text-slate-600">{t("auth.forgotSubtitle")}</p>
      </div>
      {sent ? (
        <div className="space-y-4">
          <Alert tone="success">{t("auth.linkSent")}</Alert>
          {demoUrl && (
            <Alert tone="warning">
              <p className="mb-2">{t("auth.demoLink")}</p>
              <a href={demoUrl} className="break-all font-semibold text-teal-700 underline">
                {t("auth.openLink")}
              </a>
            </Alert>
          )}
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-5">
          <Field label={t("common.email")} htmlFor="fp-email">
            <div className="relative">
              <Mail className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input id="fp-email" type="email" dir="ltr" required className="ps-10" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
          </Field>
          <button type="submit" disabled={loading} className={buttonClass("primary", "lg", "w-full")}>
            {loading ? t("common.loading") : t("auth.sendLink")}
          </button>
        </form>
      )}
      <Link href="/login" className="block text-center text-sm font-semibold text-teal-700 hover:underline">
        {t("auth.backToLogin")}
      </Link>
    </Card>
  );
}

function ResetForm({ token }: { token: string }) {
  const { t, te } = useI18n();
  const toast = useToast();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [mismatch, setMismatch] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (password !== confirm) {
      setMismatch(true);
      return;
    }
    setMismatch(false);
    setLoading(true);
    try {
      await api("/api/auth/reset", { body: { token, password } });
      setDone(true);
    } catch (err) {
      toast.error(te(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="space-y-6 sm:p-8">
      <div className="text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-50 text-teal-600">
          <KeyRound className="h-7 w-7" />
        </span>
        <h1 className="mt-4 text-xl font-bold text-slate-900">{t("auth.resetTitle")}</h1>
        <p className="mt-2 text-sm text-slate-600">{t("auth.resetSubtitle")}</p>
      </div>
      {done ? (
        <div className="space-y-4">
          <Alert tone="success">{t("auth.resetDone")}</Alert>
          <Link href="/login" className={buttonClass("primary", "lg", "w-full")}>
            {t("nav.login")}
          </Link>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-5">
          <Field label={t("auth.newPassword")} htmlFor="np" hint={t("auth.passwordRule")}>
            <Input id="np" type="password" required autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          <Field label={t("auth.confirmPassword")} htmlFor="cp" error={mismatch ? t("auth.mismatch") : null}>
            <Input id="cp" type="password" required autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          </Field>
          <button type="submit" disabled={loading} className={buttonClass("primary", "lg", "w-full")}>
            {loading ? t("common.loading") : t("prof.changePassword")}
          </button>
        </form>
      )}
    </Card>
  );
}
