import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import ProductViewer3D from "@/components/ProductViewer3D";
import ProductActions from "@/components/ProductActions";
import { formatBDT } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [product] = await db.select().from(products).where(eq(products.id, Number(id)));
  if (!product) notFound();

  return (
    <div className="relative min-h-screen bg-futuristic pt-28">
      <div className="mx-auto max-w-7xl px-4 pb-24">
        <nav className="mb-8 flex items-center gap-2 text-sm text-slate-400">
          <Link href="/" className="transition hover:text-purple-300">Home</Link>
          <span>/</span>
          <Link href="/models" className="transition hover:text-purple-300">Marketplace</Link>
          <span>/</span>
          <span className="text-white">{product.name}</span>
        </nav>

        <div className="grid gap-10 lg:grid-cols-2">
          {/* 3D viewer */}
          <div>
            <ProductViewer3D
              colors={product.colors}
              modelNumber={product.modelNumber}
              priceLabel={formatBDT(product.price)}
              accent={product.colors[0]?.includes("Gold") ? "#f59e0b" : product.colors.some((c) => /pink|rose/i.test(c)) ? "#ec4899" : "#a855f7"}
            />
            <div className="mt-4 grid grid-cols-4 gap-3">
              {product.features.slice(0, 4).map((f, i) => (
                <div key={i} className="glass rounded-2xl p-3 text-center text-xs text-slate-300">
                  <span className="mb-1 block text-lg">{["⚡", "🔋", "📱", "🧠"][i]}</span>
                  {f}
                </div>
              ))}
            </div>
          </div>

          {/* Info */}
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full border border-purple-400/30 bg-purple-500/10 px-3 py-1 text-xs font-bold text-purple-300">
                {product.category}
              </span>
              <span
                className={`rounded-full px-3 py-1 text-xs font-bold ${
                  product.status === "available"
                    ? "bg-emerald-500/90 text-white"
                    : product.status === "pre_order"
                      ? "bg-amber-500/90 text-black"
                      : "bg-red-500/90 text-white"
                }`}
              >
                {product.status === "available" ? "● Available" : product.status === "pre_order" ? "Pre-Order" : "Out of Stock"}
              </span>
              {product.isBestSeller && (
                <span className="rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-3 py-1 text-xs font-bold text-black">
                  Best Seller
                </span>
              )}
            </div>

            <h1 className="mt-4 font-display text-3xl font-black text-white md:text-4xl">{product.name}</h1>
            <p className="mt-1 text-sm text-slate-400">Model Number: <span className="font-mono text-slate-300">{product.modelNumber}</span></p>

            <p className="mt-5 leading-relaxed text-slate-300">{product.description}</p>

            <div className="mt-8">
              <ProductActions
                product={{
                  id: product.id,
                  name: product.name,
                  modelNumber: product.modelNumber,
                  price: product.price,
                  image: product.image,
                  colors: product.colors,
                  status: product.status,
                }}
              />
            </div>
          </div>
        </div>

        {/* Specifications */}
        <div className="mt-16 grid gap-6 lg:grid-cols-2">
          <div className="glass rounded-3xl p-7">
            <h2 className="font-display text-xl font-bold text-white">Features & Specifications</h2>
            <ul className="mt-5 space-y-3">
              {product.features.map((f, i) => (
                <li key={i} className="flex items-start gap-3 text-slate-300">
                  <span className="mt-0.5 grid h-5 w-5 flex-none place-items-center rounded-full bg-purple-500/20 text-xs text-purple-300">✓</span>
                  {f}
                </li>
              ))}
            </ul>
          </div>
          <div className="glass rounded-3xl p-7">
            <h2 className="font-display text-xl font-bold text-white">Order Summary</h2>
            <div className="mt-5 space-y-3 text-sm">
              <div className="flex justify-between border-b border-white/5 pb-3">
                <span className="text-slate-400">Model</span>
                <span className="font-semibold text-white">{product.modelNumber}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-3">
                <span className="text-slate-400">Category</span>
                <span className="font-semibold text-white">{product.category}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-3">
                <span className="text-slate-400">Colors</span>
                <span className="font-semibold text-white">{product.colors.join(", ") || "Midnight Black"}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-3">
                <span className="text-slate-400">Stock</span>
                <span className={`font-semibold ${product.stock > 0 ? "text-emerald-400" : "text-red-400"}`}>
                  {product.stock > 0 ? `${product.stock} units available` : "Sold out"}
                </span>
              </div>
              <div className="flex justify-between pt-1">
                <span className="font-bold text-white">Total (per unit)</span>
                <span className="font-display text-2xl font-black text-gradient">{formatBDT(product.price)}</span>
              </div>
            </div>
            <div className="mt-6 rounded-2xl border border-purple-400/20 bg-purple-500/10 p-4 text-sm text-purple-200">
              💡 Pay <b>৳200</b> booking only, pay the rest in cash when your model arrives.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}