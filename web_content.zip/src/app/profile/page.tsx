"use client";

import Link from "next/link";
import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { BadgeCheck, CalendarCheck, GraduationCap, ShieldCheck, Star, Stethoscope, UserRound, Lock } from "lucide-react";
import { useAuth, useI18n, useToast } from "@/components/providers";
import { LocalizedFields, Alert, Badge, buttonClass, Card, CardSkeleton, Checkbox, Field, Input, LoginPrompt, PageHeader, Select, Textarea, VerificationBadge } from "@/components/ui";
import { api } from "@/lib/api-client";
import { DAYS, MOROCCAN_CITIES, PROFESSIONS } from "@/lib/constants";
import type { AppointmentDTO, CurrentUser, L10n, ProfessionalDTO, ServiceDTO } from "@/lib/types";
import { loc } from "@/lib/utils";

interface ProForm {
  photoUrl: string;
  bio: L10n;
  profession: string;
  qualifications: string;
  specializations: string;
  experienceYears: number;
  serviceCodes: string[];
  serviceCities: string[];
  availableDays: string[];
  availableFrom: number;
  availableTo: number;
}

function toProForm(p: ProfessionalDTO): ProForm {
  return {
    photoUrl: p.photoUrl,
    bio: p.bio,
    profession: p.profession,
    qualifications: p.qualifications,
    specializations: p.specializations.join(", "),
    experienceYears: p.experienceYears,
    serviceCodes: p.serviceCodes,
    serviceCities: p.serviceCities,
    availableDays: p.availableDays,
    availableFrom: p.availableFrom,
    availableTo: p.availableTo,
  };
}

export default function ProfilePage() {
  const { t, locale } = useI18n();
  const { user, professional, loading, setSession } = useAuth();

  if (loading) return <CardSkeleton lines={6} />;
  if (!user)
    return (
      <div>
        <PageHeader title={t("prof.title")} subtitle={t("prof.subtitle")} />
        <LoginPrompt message={t("book.loginRequired")} next="/profile" />
      </div>
    );

  return (
    <div>
      <PageHeader title={t("prof.title")} subtitle={t("prof.subtitle")} />
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <PersonalForm user={user} onSaved={(u) => setSession(u, professional)} />
          <PasswordForm />
          {professional && user.role === "professional" && <ProfessionalSection status={professional.verificationStatus} />}
        </div>
        <aside className="space-y-6 lg:sticky lg:top-8 lg:self-start">
          <Card className="space-y-4">
            <div className="flex items-center gap-4">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 to-sky-500 text-white shadow-md">
                <UserRound className="h-7 w-7" />
              </span>
              <div className="min-w-0">
                <p className="truncate font-semibold text-slate-900">{user.fullName}</p>
                <p className="truncate text-sm text-slate-500">{user.email}</p>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500">{t("prof.role")}</span>
              <Badge tone="teal">{t(`role.${user.role}`)}</Badge>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500">{t("common.city")}</span>
              <span className="font-medium text-slate-800">{user.city}</span>
            </div>
            {user.role === "patient" && (
              <Link href="/appointments" className={buttonClass("outline", "md", "w-full")}>
                <CalendarCheck className="h-4 w-4" />
                {t("nav.appointments")}
              </Link>
            )}
          </Card>
          <Card className="space-y-3 bg-sky-50/60">
            <h2 className="flex items-center gap-2 font-semibold text-slate-900">
              <ShieldCheck className="h-5 w-5 text-sky-600" />
              {t("prof.privacy")}
            </h2>
            <p className="text-sm leading-relaxed text-slate-700">{t("prof.privacyText")}</p>
          </Card>
        </aside>
      </div>
    </div>
  );
}

function PersonalForm({ user, onSaved }: { user: CurrentUser; onSaved: (u: CurrentUser) => void }) {
  const { t, te } = useI18n();
  const toast = useToast();
  const [form, setForm] = useState({
    fullName: user.fullName,
    phone: user.phone,
    city: user.city,
    address: user.address,
    emergencyContactName: user.emergencyContactName,
    emergencyContactPhone: user.emergencyContactPhone,
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm({
      fullName: user.fullName,
      phone: user.phone,
      city: user.city,
      address: user.address,
      emergencyContactName: user.emergencyContactName,
      emergencyContactPhone: user.emergencyContactPhone,
    });
  }, [user]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updated = await api<CurrentUser>("/api/profile", { method: "PATCH", body: form });
      onSaved(updated);
      toast.success(t("prof.saved"));
    } catch (err) {
      toast.error(te(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <form onSubmit={submit} className="space-y-5">
        <h2 className="flex items-center gap-2 font-semibold text-slate-900">
          <UserRound className="h-5 w-5 text-teal-600" />
          {t("prof.personal")}
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={t("common.name")} htmlFor="pf-name">
            <Input id="pf-name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </Field>
          <Field label={t("common.phone")} htmlFor="pf-phone">
            <Input id="pf-phone" dir="ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </Field>
          <Field label={t("common.city")} htmlFor="pf-city">
            <Select id="pf-city" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })}>
              {MOROCCAN_CITIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          </Field>
          <Field label={t("common.email")} htmlFor="pf-email">
            <Input id="pf-email" dir="ltr" value={user.email} disabled />
          </Field>
        </div>
        <Field label={t("common.address")} htmlFor="pf-address">
          <Textarea id="pf-address" rows={2} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        </Field>
        <div className="rounded-2xl bg-rose-50/60 p-4 ring-1 ring-rose-100">
          <p className="mb-3 flex items-center gap-2 text-sm font-semibold text-rose-900">
            <Stethoscope className="h-4 w-4" />
            {t("prof.emergency")}
          </p>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={t("prof.emergencyName")} htmlFor="pf-ename">
              <Input id="pf-ename" value={form.emergencyContactName} onChange={(e) => setForm({ ...form, emergencyContactName: e.target.value })} />
            </Field>
            <Field label={t("prof.emergencyPhone")} htmlFor="pf-ephone">
              <Input id="pf-ephone" dir="ltr" value={form.emergencyContactPhone} onChange={(e) => setForm({ ...form, emergencyContactPhone: e.target.value })} />
            </Field>
          </div>
        </div>
        <div className="flex justify-end">
          <button type="submit" disabled={saving} className={buttonClass("primary")}>
            {saving ? t("common.loading") : t("prof.saveChanges")}
          </button>
        </div>
      </form>
    </Card>
  );
}

function PasswordForm() {
  const { t, te } = useI18n();
  const toast = useToast();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (next.length < 8) return setError(t("err.password_too_short"));
    if (next !== confirm) return setError(t("auth.mismatch"));
    setError(null);
    setSaving(true);
    try {
      await api("/api/profile", { method: "PATCH", body: { currentPassword: current, newPassword: next } });
      setCurrent("");
      setNext("");
      setConfirm("");
      toast.success(t("prof.passwordChanged"));
    } catch (err) {
      toast.error(te(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <form onSubmit={submit} className="space-y-5">
        <h2 className="flex items-center gap-2 font-semibold text-slate-900">
          <Lock className="h-5 w-5 text-teal-600" />
          {t("prof.security")}
        </h2>
        <Field label={t("prof.currentPassword")} htmlFor="pw-current">
          <Input id="pw-current" type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={t("prof.newPassword")} htmlFor="pw-new" error={error}>
            <Input id="pw-new" type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} />
          </Field>
          <Field label={t("auth.confirmPassword")} htmlFor="pw-confirm">
            <Input id="pw-confirm" type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          </Field>
        </div>
        <div className="flex justify-end">
          <button type="submit" disabled={saving || !current || !next} className={buttonClass("outline")}>
            {t("prof.changePassword")}
          </button>
        </div>
      </form>
    </Card>
  );
}

function CheckGroup({
  options,
  selected,
  onChange,
  label,
}: {
  options: Array<{ value: string; label: string }>;
  selected: string[];
  onChange: (v: string[]) => void;
  label: string;
}) {
  return (
    <div>
      <p className="mb-2 text-sm font-medium text-slate-700">{label}</p>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {options.map((o) => {
          const checked = selected.includes(o.value);
          return (
            <Checkbox
              key={o.value}
              id={`${label}-${o.value}`}
              checked={checked}
              label={o.label}
              onChange={(v) => onChange(v ? [...selected, o.value] : selected.filter((x) => x !== o.value))}
            />
          );
        })}
      </div>
    </div>
  );
}

function ProfessionalSection({ status }: { status: string }) {
  const { t, locale, te } = useI18n();
  const toast = useToast();
  const [pro, setPro] = useState<ProfessionalDTO | null>(null);
  const [form, setForm] = useState<ProForm | null>(null);
  const [services, setServices] = useState<ServiceDTO[]>([]);
  const [upcoming, setUpcoming] = useState(0);
  const [completed, setCompleted] = useState(0);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api<{ professional: ProfessionalDTO }>("/api/professionals?me=1")
      .then((r) => {
        setPro(r.professional);
        setForm(toProForm(r.professional));
      })
      .catch(() => undefined);
    api<{ services: ServiceDTO[] }>("/api/services")
      .then((r) => setServices(r.services))
      .catch(() => undefined);
    api<{ appointments: AppointmentDTO[] }>("/api/appointments")
      .then((r) => {
        setUpcoming(r.appointments.filter((a) => a.status === "pending" || a.status === "confirmed").length);
        setCompleted(r.appointments.filter((a) => a.status === "completed").length);
      })
      .catch(() => undefined);
  }, []);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!form) return;
    setSaving(true);
    try {
      const body = {
        photoUrl: form.photoUrl,
        bio: form.bio,
        profession: form.profession,
        qualifications: form.qualifications,
        specializations: form.specializations.split(",").map((s) => s.trim()).filter(Boolean),
        experienceYears: Number(form.experienceYears) || 0,
        serviceCodes: form.serviceCodes,
        serviceCities: form.serviceCities,
        availableDays: form.availableDays,
        availableFrom: Number(form.availableFrom),
        availableTo: Number(form.availableTo),
      };
      const res = await api<{ professional: ProfessionalDTO }>("/api/professionals", { method: "PATCH", body });
      setPro(res.professional);
      setForm(toProForm(res.professional));
      toast.success(t("prof.saved"));
    } catch (err) {
      toast.error(te(err));
    } finally {
      setSaving(false);
    }
  };

  const bannerTone = status === "verified" ? "success" : status === "rejected" ? "danger" : "warning";
  const bannerText = status === "verified" ? t("prof.verifiedBanner") : status === "rejected" ? t("prof.rejectedBanner") : t("prof.pendingBanner");

  return (
    <div className="space-y-6">
      <Card className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="flex items-center gap-2 font-semibold text-slate-900">
            <BadgeCheck className="h-5 w-5 text-teal-600" />
            {t("prof.professionalSpace")}
          </h2>
          <VerificationBadge status={status} />
        </div>
        <Alert tone={bannerTone}>{bannerText}</Alert>
        <div className="grid gap-3 sm:grid-cols-3">
          <Stat icon={<Star className="h-4 w-4 text-amber-500" />} label={t("prof.stats")} value={pro ? `${pro.ratingAvg.toFixed(1)} / 5` : "—"} />
          <Stat icon={<CalendarCheck className="h-4 w-4 text-sky-600" />} label={t("prof.upcoming")} value={String(upcoming)} />
          <Stat icon={<GraduationCap className="h-4 w-4 text-emerald-600" />} label={t("prof.completed")} value={String(completed)} />
        </div>
        <Link href="/appointments" className={buttonClass("secondary", "sm")}>
          {t("prof.goAppointments")}
        </Link>
      </Card>

      {!form || !pro ? (
        <CardSkeleton lines={6} />
      ) : (
        <Card>
          <form onSubmit={save} className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={t("prof.license")} hint={pro.licenseNumber}>
                <Input value={pro.licenseNumber ?? ""} disabled />
              </Field>
              <Field label={t("prof.profession")} htmlFor="pr-prof">
                <Select id="pr-prof" value={form.profession} onChange={(e) => setForm({ ...form, profession: e.target.value })}>
                  {PROFESSIONS.map((p) => (
                    <option key={p} value={p}>
                      {t(`pro.profession.${p}`)}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label={t("prof.experienceYears")} htmlFor="pr-exp">
                <Input id="pr-exp" type="number" min={0} max={60} value={form.experienceYears} onChange={(e) => setForm({ ...form, experienceYears: Number(e.target.value) })} />
              </Field>
              <Field label={t("prof.photoUrl")} htmlFor="pr-photo">
                <Input id="pr-photo" dir="ltr" value={form.photoUrl} onChange={(e) => setForm({ ...form, photoUrl: e.target.value })} placeholder="https://…" />
              </Field>
            </div>

            <LocalizedFields label={t("prof.bio")} value={form.bio} onChange={(bio) => setForm({ ...form, bio })} multiline rows={3} />

            <Field label={t("prof.qualifications")} htmlFor="pr-qual">
              <Textarea id="pr-qual" rows={3} value={form.qualifications} onChange={(e) => setForm({ ...form, qualifications: e.target.value })} />
            </Field>
            <Field label={t("prof.specializations")} htmlFor="pr-spec">
              <Input id="pr-spec" value={form.specializations} onChange={(e) => setForm({ ...form, specializations: e.target.value })} />
            </Field>

            <CheckGroup
              label={t("prof.serviceCodes")}
              options={services.map((s) => ({ value: s.slug, label: loc(s.name, locale) }))}
              selected={form.serviceCodes}
              onChange={(serviceCodes) => setForm({ ...form, serviceCodes })}
            />
            <CheckGroup
              label={t("prof.serviceCities")}
              options={MOROCCAN_CITIES.map((c) => ({ value: c, label: c }))}
              selected={form.serviceCities}
              onChange={(serviceCities) => setForm({ ...form, serviceCities })}
            />
            <CheckGroup
              label={t("prof.availableDays")}
              options={DAYS.map((d) => ({ value: d, label: t(`day.${d}`) }))}
              selected={form.availableDays}
              onChange={(availableDays) => setForm({ ...form, availableDays })}
            />
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={t("prof.availableFrom")} htmlFor="pr-from">
                <Select id="pr-from" value={form.availableFrom} onChange={(e) => setForm({ ...form, availableFrom: Number(e.target.value) })}>
                  {Array.from({ length: 24 }, (_, h) => (
                    <option key={h} value={h}>
                      {String(h).padStart(2, "0")}:00
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label={t("prof.availableTo")} htmlFor="pr-to">
                <Select id="pr-to" value={form.availableTo} onChange={(e) => setForm({ ...form, availableTo: Number(e.target.value) })}>
                  {Array.from({ length: 24 }, (_, i) => i + 1).map((h) => (
                    <option key={h} value={h}>
                      {String(h).padStart(2, "0")}:00
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            <div className="flex justify-end">
              <button type="submit" disabled={saving} className={buttonClass("primary")}>
                {saving ? t("common.loading") : t("prof.saveChanges")}
              </button>
            </div>
          </form>
        </Card>
      )}
    </div>
  );
}

function Stat({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-xl bg-slate-50 p-4 ring-1 ring-slate-100">
      <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
        {icon}
        {label}
      </div>
      <p className="mt-1 text-xl font-bold text-slate-900">{value}</p>
    </div>
  );
}
