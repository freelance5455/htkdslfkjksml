"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Crown } from "lucide-react";
import { Nav } from "@/components/Shell";
import { useMindStore } from "@/lib/store";

const MindScene = dynamic(() => import("@/components/MindScene"), { ssr: false });

interface Row {
  id: string;
  alias: string;
  mindIndex: number;
  creativity: number;
  imagination: number;
  pattern: number;
  bestRing: number;
  bestStreak: number;
  trialsSolved: number;
  isBenchmark: boolean;
  title: { title: string; cls: string };
}

export default function HallPage() {
  const [rows, setRows] = useState<Row[]>([]);
  const me = useMindStore((s) => s.mind);

  useEffect(() => {
    fetch("/api/leaderboard").then((r) => r.json()).then((d) => setRows(d.minds ?? [])).catch(() => setRows([]));
  }, []);

  return (
    <main className="relative min-h-screen">
      <Nav />
      <div className="absolute inset-0"><MindScene dim /></div>

      <div className="relative z-10 mx-auto min-h-screen max-w-5xl px-5 pb-24 pt-24">
        <motion.header initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
          <p className="font-mono text-[10px] tracking-[0.5em] text-amber-x">THE HALL OF GREAT MINDS</p>
          <h1 className="mt-4 font-display text-5xl md:text-7xl">Minds, <em className="text-glow-gold not-italic text-amber-x">classified</em>.</h1>
          <p className="mt-4 max-w-xl text-sm leading-relaxed text-ash">
            Gold rows are immortal benchmarks — historical classes of cognition etched into the hall.
            Live rows are minds currently descending the rings. There is no first place here.
            There is only <span className="text-ivory">what kind of mind you became</span>.
          </p>
        </motion.header>

        <div className="mt-12 space-y-2">
          {rows.length === 0 && (
            <div className="panel p-10 text-center font-mono text-[10px] tracking-[0.3em] text-ash">QUERYING THE ARCHIVE…</div>
          )}
          {rows.map((r, i) => {
            const isMe = me && r.id === me.id;
            return (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: Math.min(i * 0.03, 0.6) }}
                className={`panel group grid grid-cols-[3rem_1fr_auto] items-center gap-4 p-4 md:grid-cols-[4rem_1.4fr_1fr_auto] ${
                  r.isBenchmark ? "border-amber-x/25" : isMe ? "border-violet-x/60 panel-hot" : ""
                }`}
              >
                <div className="font-display text-2xl text-ash">
                  {String(i + 1).padStart(2, "0")}
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className={`truncate font-display text-lg ${r.isBenchmark ? "text-amber-x" : "text-ivory"}`}>
                      {r.alias}
                    </p>
                    {r.isBenchmark && <Crown className="h-3.5 w-3.5 text-amber-x" />}
                    {isMe && <span className="border border-violet-x/60 px-2 py-0.5 font-mono text-[9px] tracking-[0.2em] text-violet-x">YOU</span>}
                  </div>
                  <p className="font-mono text-[10px] tracking-[0.2em] text-ash">
                    {r.title.title.toUpperCase()}{r.title.cls ? ` · ${r.title.cls.toUpperCase()}` : ""}
                  </p>
                </div>
                <div className="hidden w-full max-w-[220px] gap-1 md:grid">
                  <MiniBar value={r.creativity} color="#e9c46a" />
                  <MiniBar value={r.imagination} color="#8b7cff" />
                  <MiniBar value={r.pattern} color="#3ddc97" />
                </div>
                <div className="text-right font-mono text-[10px] tracking-widest text-ash">
                  <p className={`font-display text-3xl ${r.isBenchmark ? "text-amber-x" : "text-violet-x"}`}>{r.mindIndex}</p>
                  <p className="mt-1">RING {r.bestRing} · STREAK {r.bestStreak}</p>
                </div>
              </motion.div>
            );
          })}
        </div>

        <p className="mt-10 text-center font-mono text-[10px] tracking-[0.3em] text-ash/60">
          CHASE NO ONE. LEARN FROM EVERYONE. THE HALL ONLY MEASURES DEPTH.
        </p>
      </div>
    </main>
  );
}

function MiniBar({ value, color }: { value: number; color: string }) {
  return (
    <div className="h-[3px] w-full bg-edge">
      <div className="h-full transition-all duration-1000" style={{ width: `${Math.min(100, value / 10)}%`, background: color }} />
    </div>
  );
}
