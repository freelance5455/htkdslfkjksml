export { useLocalStorage } from "./useLocalStorage";
export interface ContinueItem { kind: "movie" | "series"; id: string; title: string; progress: number }
