// Clima real vía wttr.in (público, sin clave, CORS abierto)
export interface WeatherDay { date: string; maxC: number; minC: number; code: number }
export interface WeatherNow {
  city: string;
  tempC: number;
  feelsC: number;
  humidity: number;
  windKmph: number;
  desc: string;
  code: number;
  isDay: boolean;
  days: WeatherDay[];
}

interface WttrJson {
  current_condition?: { temp_C: string; FeelsLikeC: string; humidity: string; windspeedKmph: string; weatherCode: string; lang_es?: { value: string }[]; observation_time?: string }[];
  nearest_area?: { areaName?: { value: string }[]; country?: { value: string }[] }[];
  weather?: { date: string; maxtempC: string; mintempC: string; hourly?: { weatherCode: string }[] }[];
}

export async function fetchWeather(query: string): Promise<WeatherNow> {
  const res = await fetch(`https://wttr.in/${encodeURIComponent(query)}?format=j1&lang=es`);
  if (!res.ok) throw new Error("wttr.in no disponible");
  const j = (await res.json()) as WttrJson;
  const cur = j.current_condition?.[0];
  if (!cur) throw new Error("Respuesta sin datos actuales");
  const desc = cur.lang_es?.[0]?.value ?? j.weather?.[0]?.hourly?.[0] ? (cur.lang_es?.[0]?.value ?? "Sin descripción") : "Sin descripción";
  const midday = (idx: number) => {
    const h = j.weather?.[idx]?.hourly;
    return h && h.length ? Number(h[Math.floor(h.length / 2)].weatherCode) : 116;
  };
  return {
    city: j.nearest_area?.[0]?.areaName?.[0]?.value ?? query,
    tempC: Number(cur.temp_C),
    feelsC: Number(cur.FeelsLikeC),
    humidity: Number(cur.humidity),
    windKmph: Number(cur.windspeedKmph),
    desc,
    code: Number(cur.weatherCode),
    isDay: true,
    days: (j.weather ?? []).slice(0, 4).map((d, i) => ({
      date: d.date,
      maxC: Number(d.maxtempC),
      minC: Number(d.mintempC),
      code: midday(i),
    })),
  };
}

/** wttr.in code → emoji-free icon key handled in the UI layer. */
export type SkyKind = "clear" | "partly" | "cloud" | "fog" | "rain" | "snow" | "storm";
export function skyKind(code: number): SkyKind {
  if (code === 113) return "clear";
  if (code === 116 || code === 119 || code === 122) return code === 116 ? "partly" : "cloud";
  if (code === 143 || code === 248 || code === 260) return "fog";
  if (code >= 200 && code < 250) return "storm";
  if ((code >= 320 && code <= 338) || code === 227 || code === 230 || code === 323 || code === 326) return "snow";
  return "rain"; // 176, 263–302, 353–359, 179, 182, 185…
}
