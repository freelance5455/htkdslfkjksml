import { useEffect, useRef, useState } from "react";
import { Bot, Loader2, Mic, SendHorizonal, Sparkles } from "lucide-react";
import { fetchEspnNewsSafe, fetchEspnScoreboardSafe, fetchRadioStations, wikidataSearchFilms } from "./api";
import { MOVIES, SERIES } from "./catalog";

type Msg = { role: "user" | "ai"; text: string; link?: { label: string; url: string } };
const SUGGESTIONS = ["¿Qué hay hoy en LaLiga?", "Recomiéndame una película de ciencia ficción", "Noticias deportivas de última hora", "Emisoras de radio españolas"];

export default function AiView() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "ai", text: "¡Hola! Soy TV LO3 AI. Pregúntame por marcadores en vivo, noticias, películas, series o radio — consulto fuentes reales (ESPN, Wikidata, TVMaze, Radio Browser)." },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const ask = async (raw: string) => {
    const q = raw.trim();
    if (!q || busy) return;
    setMessages((m) => [...m, { role: "user", text: q }]);
    setInput("");
    setBusy(true);
    const t = q.toLowerCase();
    const reply = (text: string, link?: Msg["link"]) => setMessages((m) => [...m, { role: "ai", text, link }]);

    try {
      if (/(marcador|resultado|score|hoy).*(la ?liga|madrid|barcelona|fútbol|futbol)|la ?liga|laliga/i.test(t)) {
        const { events: evs } = await fetchEspnScoreboardSafe("soccer/esp.1");
        if (evs.length === 0) reply("Ahora mismo no hay partidos de LaLiga programados. Puedo contarte las noticias más recientes — escribe «noticias de deporte».");
        else reply("Marcadores LaLiga (ESPN, en vivo):\n" + evs.map((ev) => {
          const comp = ev.competitions?.[0];
          const st = comp?.status?.type;
          const [a, h] = [comp?.competitors.find((c) => c.homeAway === "away"), comp?.competitors.find((c) => c.homeAway === "home")];
          const score = st?.state === "pre" ? "por empezar" : `${a?.score ?? 0} - ${h?.score ?? 0}`;
          return `${a?.team.shortDisplayName ?? a?.team.displayName} vs ${h?.team.shortDisplayName ?? h?.team.displayName}: ${score} (${(st?.shortDetail || "").trim()})`;
        }).join("\n"));
      } else if (/nba|basket/i.test(t)) {
        const { events: evs } = await fetchEspnScoreboardSafe("basketball/nba");
        reply(evs.length ? "NBA hoy (ESPN):\n" + evs.map((ev) => {
          const comp = ev.competitions?.[0];
          const st = comp?.status?.type;
          const [a, h] = [comp?.competitors.find((c) => c.homeAway === "away"), comp?.competitors.find((c) => c.homeAway === "home")];
          const score = st?.state === "pre" ? "por empezar" : `${a?.score ?? 0} - ${h?.score ?? 0}`;
          return `${a?.team.abbreviation ?? "?"} vs ${h?.team.abbreviation ?? "?"}: ${score} (${(st?.shortDetail || "").trim()})`;
        }).join("\n") : "La NBA descansa hoy — no hay partidos programados.");
      } else if (/noticia|titular|deporte/i.test(t)) {
        const { articles: arts } = await fetchEspnNewsSafe(4);
        reply("Últimos titulares de LaLiga (ESPN):\n" + arts.map((a) => `• ${a.headline}`).join("\n"), arts[0] ? { label: "Leer en ESPN", url: arts[0].link } : undefined);
      } else if (/radio|emisora/i.test(t)) {
        const stations = await fetchRadioStations("ES", "", 3);
        reply(stations.length ? "Emisoras españolas más votadas (Radio Browser):\n" + stations.map((s) => `• ${s.name} — ${s.codec || "MP3"} ${s.bitrate || 128} kbps`).join("\n") + "\n\nÁbrelas en la sección Radio." : "No pude consultar Radio Browser ahora mismo.");
      } else if (/serie|temporada/i.test(t)) {
        const hits = SERIES.filter((s) => !s.kids || /kid|infantil|anim/.test(t)).slice(0, 4);
        reply("De mi catálogo (TVMaze): " + hits.map((s) => `${s.name} (${s.year})`).join(", ") + ". Abre Series y filtra por género — pósters y sinopsis oficiales incluidas.");
      } else if (/pel[ií]cula|cine|film|sci|acción|terror|drama|comedia/i.test(t)) {
        const cleaned = t.replace(/(recomiéndame|recomiendame|una?|de|película|pelicula|pelis?|cine|ver|que)/g, " ").trim();
        const films = cleaned.length >= 3 ? await wikidataSearchFilms(cleaned, 3).catch(() => []) : [];
        if (films.length) {
          reply("Encontré esto (Wikidata):\n" + films.map((f) => `• ${f.label} — ${f.description}`).join("\n") + "\n\nY en tu catálogo local hay 18 fichas con carátulas y enlaces IMDb.", { label: "Abrir Movies", url: "#app-movies" });
        } else {
          const pick = MOVIES[Math.floor(Math.random() * MOVIES.length)];
          reply(`Te propongo «${pick.title}» (${pick.year}) — ${pick.genres.join(", ")}. ${pick.desc}`, pick.imdb ? { label: "Ver en IMDb", url: `https://www.imdb.com/title/${pick.imdb}/` } : undefined);
        }
      } else if (/kid|niñ|hijo/i.test(t)) {
        reply("En el perfil Kids (protegido con PIN) tienes Toy Story, Frozen 2, Finding Nemo, Shrek, Bluey, Peppa Pig, Pokémon y Avatar: ATLA — todo filtrado y con reglas de tiempo. Configúralo en Ajustes → Infancia.");
      } else if (/premium|precio|plan|gratis/i.test(t)) {
        reply("TV LO3 FREE es gratis para siempre. PREMIUM (4,99 €/mes) quita anuncios y añade 4K HDR, EPG completo y offline. PRO (9,99 €) suma 8K y 4 dispositivos. FAMILY (7,99 €) cubre 4 perfiles con PIN. En la app: Ajustes → Planes.");
      } else {
        reply("Puedo consultar marcadores (LaLiga/NBA), noticias ESPN, radio en vivo, películas (Wikidata) y series (TVMaze). Prueba con «¿qué hay hoy en LaLiga?» o «recomiéndame una peli».");
      }
    } catch {
      reply("La fuente de datos no respondió este rato. Inténtalo de nuevo en unos segundos o mira los enlaces de Ajustes → Fuentes en vivo.");
    } finally {
      setBusy(false);
    }
  };

  const voice = () => {
    setListening(true);
    window.setTimeout(() => {
      setListening(false);
      ask(SUGGESTIONS[Math.floor(Math.random() * SUGGESTIONS.length)]);
    }, 1500);
  };

  return (
    <div className="flex h-full flex-col gap-2 overflow-hidden p-3 sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-fuchsia-500 to-violetx shadow-lg shadow-fuchsia-600/30"><Bot size={24} className="text-white" /></span>
          <div>
            <h1 className="font-display text-lg font-black text-white">TV LO3 AI</h1>
            <p className="flex items-center gap-1.5 text-[10px] font-semibold text-emerald-400"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />En línea · consultas a fuentes reales</p>
          </div>
        </div>
        <button onClick={voice} aria-pressed={listening} aria-label="Usar voz (demo)" className={`flex h-11 items-center gap-2 rounded-xl border px-4 text-[11px] font-bold transition-all ${listening ? "animate-live border-red-500/60 bg-red-500/15 text-red-300" : "border-white/12 bg-white/5 text-slate-300 hover:text-white"}`}>
          <Mic size={15} />{listening ? "Escuchando…" : "Hablar"}
        </button>
      </div>

      <div ref={scrollRef} className="thin-scroll min-h-0 flex-1 space-y-2 overflow-y-auto rounded-2xl border border-white/8 bg-white/[0.02] p-3" aria-live="polite">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-[12px] leading-relaxed ${m.role === "user" ? "rounded-br-md bg-electric text-white" : "rounded-bl-md border border-white/8 bg-panel3/80 text-slate-100"}`}>
              <p className="whitespace-pre-line">{m.text}</p>
              {m.link && (m.link.url.startsWith("#app-")
                ? null
                : <a href={m.link.url} target="_blank" rel="noopener noreferrer" className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-bold text-cyanx hover:underline">{m.link.label} →</a>)}
            </div>
          </div>
        ))}
        {busy && <div className="flex items-center gap-2 text-xs text-slate-500"><Loader2 size={13} className="animate-spin" /> Consultando fuentes…</div>}
      </div>

      <div className="flex gap-1.5 overflow-x-auto thin-scroll -mx-1 px-1 pb-0.5">
        {SUGGESTIONS.map((s) => <button key={s} onClick={() => ask(s)} disabled={busy} className="whitespace-nowrap rounded-full border border-white/12 bg-white/5 px-3 py-1.5 text-[10px] font-semibold text-slate-300 transition-colors hover:border-cyanx/40 hover:text-white disabled:opacity-50">{s}</button>)}
      </div>
      <form onSubmit={(e) => { e.preventDefault(); ask(input); }} className="flex gap-2">
        <label htmlFor="ai-question" className="sr-only">Escribe tu pregunta</label>
        <input id="ai-question" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Pregúntame… («marcadores hoy», «noticias», «recomiéndame algo»)" className="h-12 flex-1 rounded-xl border border-white/10 bg-black/30 px-4 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-violetx/60" />
        <button type="submit" disabled={busy} aria-label="Enviar" className="grad-btn flex h-12 w-12 items-center justify-center rounded-xl text-white disabled:opacity-60"><SendHorizonal size={18} /></button>
      </form>
      <p className="flex items-center gap-1.5 px-1 text-[9px] text-slate-600"><Sparkles size={10} className="text-lilac" /> Respuestas generadas con datos en vivo de ESPN, Wikidata, TVMaze, Radio Browser y Hacker News. Verifica la información en la fuente enlazada.</p>
    </div>
  );
}
