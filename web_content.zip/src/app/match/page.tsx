"use client";

import { QueryIdRoute } from "@/components/query-route";
import PublicMatchClient from "./public-client";

/** Public live match view, addressed by `?id=…` for the static export. */
export default function MatchPage() {
  return (
    <QueryIdRoute emptyTitle="No match selected." backHref="/" backLabel="Back to matches">
      {(id) => <PublicMatchClient id={id} />}
    </QueryIdRoute>
  );
}
