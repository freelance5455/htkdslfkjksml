"use client";

import { useState } from "react";
import Link from "next/link";
import { useMatch } from "@/lib/useMatch";
import { oversStr } from "@/lib/engine";
import { TeamLogo } from "@/components/cricket";
import { langClass, useLang, usePhrase } from "@/components/lang";
import {
  BattingTable,
  BowlingTable,
  CommentaryList,
  CurrentOverStrip,
  CurrentPlayersPanel,
  FallOfWickets,
  LiveBadge,
  MatchAwards,
  MatchHeader,
  MatchResultPanel,
  MatchStatsPanel,
  OverAnalysis,
  PartnershipPanel,
  PlayerProfileProvider,
  PlayersPanel,
  SummaryPanel,
} from "@/components/match-ui";
import {
  CommentaryAnnouncer,
  CommentaryAudioDock,
  CommentaryAudioProvider,
  ReplayButton,
  SpeakerIndicator,
  useVoice,
  VoiceToggleInline,
} from "@/components/voice";

const TABS = [
  "SUMMARY",
  "SCORECARD",
  "BALL BY BALL",
  "COMMENTARY",
  "OVER ANALYSIS",
  "PLAYERS",
  "AWARDS",
] as const;
type Tab = (typeof TABS)[number];

function kindTone(kind: string) {
  return kind === "wicket"
    ? "text-red-400"
    : kind === "boundary"
      ? "text-sky-300"
      : kind === "six"
        ? "text-violet-300"
        : kind === "extra"
          ? "text-amber-300"
          : kind === "info" || kind === "over" || kind === "milestone"
            ? "text-emerald-300"
            : "text-slate-200";
}

export default function PublicMatchClient({ id }: { id: string }) {
  return (
    <CommentaryAudioProvider>
      <PublicMatchInner id={id} />
      <CommentaryAudioDock />
    </CommentaryAudioProvider>
  );
}

function PublicMatchInner({ id }: { id: string }) {
  const { state, error } = useMatch(id, 2000);
  const { settings } = useVoice();
  const { lang } = useLang();
  const t = usePhrase();
  const [tab, setTab] = useState<Tab>("SUMMARY");
  const [inningsView, setInningsView] = useState<0 | 1>(0);

  if (error && !state) {
    return (
      <main className="mx-auto max-w-3xl px-4 py-16 text-center">
        <p className="text-lg font-bold text-red-400">{error}</p>
        <Link href="/" className="mt-4 inline-block text-emerald-400 underline">
          Back to matches
        </Link>
      </main>
    );
  }
  if (!state)
    return <main className="px-4 py-20 text-center text-slate-400">Loading live match…</main>;

  const cur = state.innings[state.currentInnings];
  const s = state.setup;
  const scoreFor = (team: string) => {
    const i = state.innings.find((x) => x.battingTeam === team);
    if (!i || !i.started) return null;
    return i;
  };
  const showSecond = state.currentInnings === 1;
  const view = showSecond ? state.innings[inningsView] : state.innings[0];

  const latest = state.commentary[0];

  return (
    <PlayerProfileProvider state={state}>
      <CommentaryAnnouncer state={state} />
      <main className="mx-auto max-w-6xl px-3 pb-24 pt-4 sm:px-4 sm:pt-5">
        {/* Sticky live score */}
        <div className="sticky top-[57px] z-30 mb-4">
          <div className="mc-card overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-4 py-2">
              <div className="flex items-center gap-2">
                <LiveBadge status={state.status} />
                <span className="text-xs font-semibold text-slate-400">
                  {s.format} · {s.overs} ov{s.venue ? ` · ${s.venue}` : ""}
                </span>
              </div>
            </div>
            <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3 px-4 py-4">
              {[
                { team: s.teamA, logo: s.logoA, right: false },
                { team: s.teamB, logo: s.logoB, right: true },
              ].map(({ team, logo, right }) => {
                const i = scoreFor(team);
                const batting = cur.battingTeam === team && state.status === "live";
                return (
                  <div
                    key={team}
                    className={`flex items-center gap-3 ${right ? "order-3 justify-end text-right" : ""}`}
                  >
                    {!right && <TeamLogo name={team} logo={logo} size={32} />}
                    <div className="min-w-0">
                      <p
                        className={`truncate text-sm font-black uppercase ${
                          batting ? "text-emerald-400" : "text-slate-300"
                        }`}
                      >
                        {team}
                      </p>
                      {i ? (
                        <>
                          <p className="text-2xl font-black leading-tight sm:text-3xl">
                            {i.runs}
                            <span className="text-slate-500">/</span>
                            {i.wickets}
                          </p>
                          <p className="text-[11px] text-slate-400">
                            {oversStr(i.legalBalls)} Overs
                          </p>
                        </>
                      ) : (
                        <p className="mt-1 text-xs text-slate-500">Yet to bat</p>
                      )}
                    </div>
                    {right && <TeamLogo name={team} logo={logo} size={32} />}
                  </div>
                );
              })}
              <div className="order-2 text-center text-xs font-black text-slate-500">VS</div>
            </div>
            {settings.textCommentary && latest && (
              <div className="flex items-start gap-2 border-t border-slate-800 bg-slate-900/60 px-4 py-2">
                <span className="mt-0.5 shrink-0 rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-black text-slate-400">
                  {latest.ballRef}
                </span>
                <p className={`${langClass(lang)} min-w-0 flex-1 text-[14px] ${kindTone(latest.kind)}`}>
                  {t(latest.texts)}
                </p>
                <ReplayButton text={t(latest.texts)} />
              </div>
            )}
            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-800 bg-slate-900/50 px-4 py-2">
              <span className="text-xs font-semibold text-slate-300">
                {state.result ??
                  (state.status === "innings-break"
                    ? `Innings break · ${state.innings[1].battingTeam} need ${state.innings[1].target} to win`
                    : "Live Urdu commentary")}
              </span>
              <div className="flex items-center gap-2">
                <SpeakerIndicator />
                <VoiceToggleInline />
              </div>
            </div>
          </div>
        </div>

        <div className="mb-4 flex gap-1 overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/50 p-1">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`mc-btn h-8 whitespace-nowrap rounded-lg px-3 text-[11px] font-black tracking-wide ${
                tab === t ? "bg-emerald-500 text-slate-950" : "text-slate-300 hover:bg-slate-800"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {tab === "SUMMARY" && (
          <div className="space-y-4">
            {state.status === "completed" && (
              <MatchResultPanel state={state} onOpenTab={(t) => setTab(t)} />
            )}
            <MatchHeader state={state} />
            <SummaryPanel state={state} />
            <FallOfWickets inn={cur} />
            <PartnershipPanel inn={cur} />
          </div>
        )}

        {tab === "SCORECARD" && (
          <div className="space-y-4">
            {showSecond && (
              <div className="flex gap-2">
                {state.innings.map((i, idx) => (
                  <button
                    key={idx}
                    onClick={() => setInningsView(idx as 0 | 1)}
                    className={`mc-btn rounded-lg px-3 py-2 text-xs font-bold ${
                      inningsView === idx
                        ? "bg-slate-700 text-white"
                        : "border border-slate-700 text-slate-300"
                    }`}
                  >
                    {i.battingTeam} innings
                  </button>
                ))}
              </div>
            )}
            <BattingTable inn={view} setup={s} />
            <BowlingTable inn={view} setup={s} />
            <FallOfWickets inn={view} />
            <PartnershipPanel inn={view} />
            <MatchStatsPanel state={state} />
          </div>
        )}

        {tab === "BALL BY BALL" && (
          <div className="space-y-4">
            <CurrentPlayersPanel state={state} />
            <CurrentOverStrip inn={cur} />
            <OverAnalysis inn={cur} />
          </div>
        )}

        {tab === "COMMENTARY" && <CommentaryList state={state} />}
        {tab === "OVER ANALYSIS" && <OverAnalysis inn={cur} />}
        {tab === "PLAYERS" && <PlayersPanel setup={s} />}
        {tab === "AWARDS" && (
          <div className="space-y-4">
            <MatchAwards state={state} />
            {!state.awards.playerOfMatch && (
              <div className="mc-card px-4 py-8 text-center text-sm text-slate-500">
                No Player of the Match has been declared yet.
              </div>
            )}
            {state.result && (
              <div className="mc-card px-4 py-5 text-center">
                <p className="text-xs font-black uppercase tracking-widest text-slate-400">
                  Match result
                </p>
                <p className="mt-1 text-xl font-black text-emerald-300">{state.result}</p>
              </div>
            )}
          </div>
        )}
      </main>
    </PlayerProfileProvider>
  );
}
