// ─────────────────────────────────────────────────────────────
// TV LO3 — capa de datos (fuentes públicas, legales y verificables)
// ─────────────────────────────────────────────────────────────

export interface Channel {
  id: string;
  name: string;
  logo: string | null;
  group: string;
  url: string;
  geoBlocked: boolean;
}

const COUNTRY_PLAYLISTS: Record<string, string> = {
  es: "España", mx: "México", ar: "Argentina", co: "Colombia", cl: "Chile", pe: "Perú",
  us: "EE. UU.", br: "Brasil", fr: "Francia", de: "Alemania", it: "Italia", pt: "Portugal",
  gb: "Reino Unido", uy: "Uruguay",
};
export const TV_COUNTRIES = Object.entries(COUNTRY_PLAYLISTS).map(([code, label]) => ({ code, label }));

function attr(tag: string, name: string): string | null {
  const m = tag.match(new RegExp(`${name}="([^"]*)"`, "i"));
  return m ? m[1] : null;
}

export function parseM3U(text: string): Channel[] {
  const lines = text.split(/\r?\n/);
  const channels: Channel[] = [];
  const seen = new Set<string>();
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line.startsWith("#EXTINF")) continue;
    const comma = line.lastIndexOf(",");
    let name = comma >= 0 ? line.slice(comma + 1).trim() : "Canal";
    const geoBlocked = /\[\s*geo-blocked\s*\]/i.test(name);
    name = name.replace(/\[\s*geo-blocked\s*\]/gi, "").trim();
    const url = (lines[i + 1] || "").trim();
    if (!url || !/^https?:\/\//.test(url) || seen.has(url)) continue;
    seen.add(url);
    const rawGroup = (attr(line, "group-title") || "").trim();
    const grp0 = rawGroup.split(";")[0].trim();
    const group = !grp0 || /^(undefined|null|na|n\/a)$/i.test(grp0) ? "General" : grp0;
    channels.push({
      id: attr(line, "tvg-id") || `${url.slice(-24)}-${channels.length}`,
      name,
      logo: attr(line, "tvg-logo"),
      group,
      url,
      geoBlocked,
    });
  }
  return channels;
}

export async function fetchCountryChannels(cc: string, signal?: AbortSignal): Promise<Channel[]> {
  const res = await fetch(`https://iptv-org.github.io/iptv/countries/${cc}.m3u`, { signal });
  if (!res.ok) throw new Error(`iptv-org respondió ${res.status}`);
  return parseM3U(await res.text());
}

/* ───────── ESPN (marcadores y noticias deportivas) ───────── */
export interface EspnEvent {
  id: string;
  name?: string;
  date: string;
  competitions: {
    competitors: { homeAway: string; score?: string; team: { displayName?: string; shortDisplayName?: string; abbreviation?: string; logo?: string } }[];
    status: { type: { state: "pre" | "in" | "post"; shortDetail: string } };
  }[];
}

export async function fetchEspnScoreboard(slug: string, signal?: AbortSignal): Promise<EspnEvent[]> {
  const res = await fetch(`https://site.api.espn.com/apis/site/v2/sports/${slug}/scoreboard`, { signal });
  if (!res.ok) throw new Error(`ESPN ${res.status}`);
  const json = await res.json();
  return (json.events ?? []) as EspnEvent[];
}

export interface EspnArticle {
  id: string;
  headline: string;
  description: string;
  link: string;
  image: string | null;
  published: string;
}

export async function fetchEspnNews(limit = 8): Promise<EspnArticle[]> {
  const res = await fetch(`https://site.api.espn.com/apis/site/v2/sports/soccer/esp.1/news?limit=${limit}`);
  if (!res.ok) throw new Error(`ESPN news ${res.status}`);
  const json = await res.json();
  return (json.articles ?? []).map((a: {
    id: number | string; headline: string; description?: string;
    links?: { web?: { href?: string } }; images?: { url: string }[]; published?: string;
  }): EspnArticle => ({
    id: String(a.id),
    headline: a.headline,
    description: a.description ?? "",
    link: a.links?.web?.href ?? "https://www.espn.com/soccer/",
    image: a.images?.[0]?.url ?? a.images?.[1]?.url ?? null,
    published: a.published ?? "",
  }));
}

/* ───────── Hacker News (tecnología) ───────── */
export interface HnStory {
  id: number;
  title: string;
  url: string;
  score: number;
  by: string;
  time: number;
  descendants: number;
  domain: string;
}

export async function fetchHnTop(limit = 12): Promise<HnStory[]> {
  const res = await fetch("https://hacker-news.firebaseio.com/v0/topstories.json");
  if (!res.ok) throw new Error("Hacker News no disponible");
  const ids: number[] = (await res.json()).slice(0, limit);
  const items = await Promise.all(
    ids.map((id) => fetch(`https://hacker-news.firebaseio.com/v0/item/${id}.json`).then((r) => r.json()).catch(() => null))
  );
  return items.filter(Boolean).map((s: { id: number; title: string; url?: string; score: number; by: string; time: number; descendants?: number }) => {
    let domain = "news.ycombinator.com";
    try { if (s.url) domain = new URL(s.url).hostname.replace(/^www\./, ""); } catch { /* keep default */ }
    return { id: s.id, title: s.title, url: s.url ?? `https://news.ycombinator.com/item?id=${s.id}`, score: s.score, by: s.by, time: s.time, descendants: s.descendants ?? 0, domain };
  });
}

/* ───────── Deezer vía JSONP (api.deezer.com no expone CORS) ───────── */
export interface DeezerTrack {
  id: number;
  title: string;
  artist: string;
  album: string;
  cover: string;
  preview: string | null;
  duration: number;
  link: string;
}

type JsonpCallback = (data: unknown) => void;

export function deezerSearch(query: string, limit = 16): Promise<DeezerTrack[]> {
  return new Promise((resolve, reject) => {
    const cb = `__lo3dz_${Date.now().toString(36)}_${Math.floor(Math.random() * 1e6)}`;
    const script = document.createElement("script");
    const timer = window.setTimeout(() => { cleanup(); reject(new Error("Deezer no respondió")); }, 9000);
    const cleanup = () => {
      window.clearTimeout(timer);
      delete (window as unknown as Record<string, JsonpCallback>)[cb];
      script.remove();
    };
    (window as unknown as Record<string, JsonpCallback>)[cb] = (data) => {
      cleanup();
      const tracks = ((data as { data?: Array<Record<string, unknown>> })?.data ?? []).map((t) => ({
        id: Number(t.id),
        title: String(t.title ?? ""),
        artist: String((t.artist as { name?: string })?.name ?? ""),
        album: String((t.album as { title?: string })?.title ?? ""),
        cover: String((t.album as { cover_medium?: string })?.cover_medium ?? ""),
        preview: (t.preview as string) || null,
        duration: Number(t.duration ?? 0),
        link: String(t.link ?? "https://www.deezer.com"),
      }));
      resolve(tracks);
    };
    script.onerror = () => { cleanup(); reject(new Error("Deezer no disponible")); };
    script.src = `https://api.deezer.com/search?q=${encodeURIComponent(query)}&limit=${limit}&output=jsonp&callback=${cb}`;
    document.body.appendChild(script);
  });
}

/* ───────── Radio Browser (radio real) ───────── */
export interface RadioStation {
  id: string;
  name: string;
  stream: string;
  favicon: string | null;
  codec: string;
  bitrate: number;
  country: string;
}

export async function fetchRadioStations(country: string, query: string, limit = 18, signal?: AbortSignal, tag = ""): Promise<RadioStation[]> {
  const params = new URLSearchParams({ limit: String(limit), hidebroken: "true", order: "votes", reverse: "true" });
  if (country !== "ALL") params.set("countrycode", country);
  if (query.trim().length >= 2) params.set("name", query.trim());
  else if (tag && tag !== "todos") params.set("tag", tag);
  const res = await fetch(`https://de1.api.radio-browser.info/json/stations/search?${params.toString()}`, { signal });
  if (!res.ok) throw new Error("Radio Browser no disponible");
  const rows: { stationuuid: string; name: string; url_resolved?: string; url: string; favicon?: string; codec?: string; bitrate?: number; country?: string }[] = await res.json();
  return rows.map((s) => ({
    id: s.stationuuid,
    name: s.name.trim(),
    stream: s.url_resolved || s.url,
    favicon: s.favicon || null,
    codec: s.codec || "MP3",
    bitrate: s.bitrate || 128,
    country: s.country || country,
  }));
}

/* ───────── Wikipedia/Wikidata (apoyo para TV LO3 AI) ───────── */
export interface WikiFilmResult { qid: string; label: string; description: string; }

export async function wikidataSearchFilms(query: string, limit = 4): Promise<WikiFilmResult[]> {
  const res = await fetch(`https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${encodeURIComponent(query)}&type=item&language=en&limit=10&format=json`);
  if (!res.ok) throw new Error("Wikidata no disponible");
  const json = await res.json();
  const hits: { id: string; label?: string; description?: string }[] = json.search ?? [];
  return hits
    .filter((h) => /film|movie|motion picture|película/i.test(h.description ?? ""))
    .slice(0, limit)
    .map((h) => ({ qid: h.id, label: h.label ?? h.id, description: h.description ?? "" }));
}

/* ───────── ESPN con fallback offline (captura real 24/11/2026) ───────── */
export interface EspnFetchResult { events: EspnEvent[]; fromSnapshot: boolean }

export async function fetchEspnScoreboardSafe(slug: string): Promise<EspnFetchResult> {
  try {
    const events = await fetchEspnScoreboard(slug);
    return { events: events.slice(0, 6), fromSnapshot: false };
  } catch {
    const snap = (await import("../lib/espn-snapshot")).default;
    const id = slug.split("/")[1].replace(".", "").replace(/-/g, "") === "esp1" ? "laliga" : slug;
    const key = slug.endsWith("esp.1") ? "laliga" : slug.endsWith("eng.1") ? "premier" : slug.endsWith("uefa.champions") ? "champions" : slug.includes("nba") ? "nba" : slug.includes("nfl") ? "nfl" : slug.includes("mlb") ? "mlb" : slug.includes("nhl") ? "nhl" : id;
    return { events: (snap[key] ?? []) as unknown as EspnEvent[], fromSnapshot: true };
  }
}

export async function fetchEspnNewsSafe(limit = 8): Promise<{ articles: EspnArticle[]; fromSnapshot: boolean }> {
  try {
    const articles = await fetchEspnNews(limit);
    return { articles, fromSnapshot: false };
  } catch {
    const snap = (await import("../lib/espn-news-snapshot")).default;
    return { articles: snap.slice(0, limit), fromSnapshot: true };
  }
}

/** Fetch + parse any iptv-org playlist URL (country/region/category/language/index). */
export async function fetchTvSource(url: string, signal?: AbortSignal): Promise<Channel[]> {
  const res = await fetch(url, { signal });
  if (!res.ok) throw new Error(`IPTV-org respondió ${res.status}`);
  return parseM3U(await res.text());
}

/* ───────── ESPN · clasificaciones (standings) ───────── */
export interface EspnStandingEntry {
  team: string; abbr: string; logo: string | null; color?: string | null; stats: Record<string, string>;
}
export interface EspnStandingGroup { name: string; entries: EspnStandingEntry[] }

const STANDINGS_MAP: Record<string, string> = {
  "soccer/esp.1": "laliga", "basketball/nba": "nba", "football/nfl": "nfl", "racing/f1": "f1",
};

export async function fetchEspnStandings(slug: string, signal?: AbortSignal): Promise<EspnStandingGroup[]> {
  const res = await fetch(`https://site.api.espn.com/apis/v2/sports/${slug}/standings`, { signal });
  if (!res.ok) throw new Error(`ESPN standings ${res.status}`);
  const j = await res.json();
  return (j.children ?? []).map((c: { name?: string; standings?: { entries?: { team?: Record<string, unknown>; stats?: { name: string; displayValue: string }[] }[] } }) => ({
    name: c.name ?? "",
    entries: (c.standings?.entries ?? []).map((e) => {
      const stats: Record<string, string> = {};
      for (const s of e.stats ?? []) stats[s.name] = s.displayValue;
      const entity = e as unknown as { team?: { shortDisplayName?: string; displayName?: string; abbreviation?: string; color?: string; logos?: { href: string }[] }; athlete?: { shortName?: string; displayName?: string; abbreviation?: string } };
      const who = entity.team?.shortDisplayName ?? entity.team?.displayName ?? entity.athlete?.shortName ?? entity.athlete?.displayName ?? "?";
      const abbr = entity.athlete?.abbreviation ?? entity.team?.abbreviation ?? "?";
      return {
        team: who,
        abbr,
        logo: entity.team?.logos?.[0]?.href ?? null,
        color: entity.team?.color ? `#${entity.team.color}` : null,
        stats,
      };
    }),
  }));
}

export async function fetchEspnStandingsSafe(slug: string): Promise<{ groups: EspnStandingGroup[]; fromSnapshot: boolean }> {
  try {
    return { groups: await fetchEspnStandings(slug), fromSnapshot: false };
  } catch {
    const key = STANDINGS_MAP[slug];
    if (!key) return { groups: [], fromSnapshot: true };
    const snap = (await import("../lib/espn-standings-snapshot")).default;
    return { groups: snap[key] ?? [], fromSnapshot: true };
  }
}

export const STANDINGS_SUPPORTED = new Set(Object.keys(STANDINGS_MAP));

/* ───────── ESPN · búsqueda de jugadores y equipos ───────── */
export interface EspnSearchHit {
  id: string;
  type: string;
  name: string;
  subtitle: string;
  link: string;
  uid: string;
}

export async function searchEspn(query: string, limit = 7): Promise<EspnSearchHit[]> {
  const res = await fetch(`https://site.api.espn.com/apis/search/v2?query=${encodeURIComponent(query)}&limit=${limit}`);
  if (!res.ok) throw new Error(`ESPN search ${res.status}`);
  const j = await res.json();
  interface EspnSearchContent { id?: string; uid?: string; type?: string; displayName?: string; subtitle?: string; shortDisplayName?: string; link?: { web?: string } }
  const contents: EspnSearchContent[] = (j.results ?? []).flatMap((r: { contents?: EspnSearchContent[] }) => r.contents ?? []);
  return contents.slice(0, limit).map((c) => ({
    id: String(c.id ?? c.uid ?? Math.random()),
    type: c.type ?? "player",
    name: c.displayName ?? "?",
    subtitle: c.subtitle ?? c.shortDisplayName ?? "",
    link: c.link?.web ?? "https://www.espn.com",
    uid: c.uid ?? "",
  }));
}

/* ───────── ISS · telemetría en vivo ───────── */
export interface IssPosition {
  latitude: number;
  longitude: number;
  altitude: number;
  velocity: number;
  visibility: string;
  timestamp: number;
}

export async function fetchIssPosition(): Promise<IssPosition> {
  const res = await fetch("https://api.wheretheiss.at/v1/satellites/25544");
  if (!res.ok) throw new Error("ISS no disponible");
  const j = await res.json();
  return {
    latitude: j.latitude,
    longitude: j.longitude,
    altitude: j.altitude,
    velocity: j.velocity,
    visibility: j.visibility,
    timestamp: j.timestamp,
  };
}

/* ───────── Wikipedia · búsqueda de artículos (opensearch) ───────── */
export interface WikiHit { title: string; description: string; url: string }

export async function wikipediaOpenSearch(query: string, limit = 4, signal?: AbortSignal): Promise<WikiHit[]> {
  const res = await fetch(`https://es.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(query)}&limit=${limit}&namespace=0&format=json`, { signal });
  if (!res.ok) throw new Error("Wikipedia no disponible");
  const json = (await res.json()) as [string, string[], string[], string[]];
  const [, titles, descriptions, urls] = json;
  return (titles ?? []).map((t, i) => ({ title: t, description: descriptions?.[i] ?? "", url: urls?.[i] ?? `https://es.wikipedia.org/wiki/${encodeURIComponent(t)}` }));
}

/** Busca una emisora concreta por UUID (para "tus más escuchadas"). */
export async function fetchRadioStationByUuid(uuid: string, signal?: AbortSignal): Promise<RadioStation | null> {
  const res = await fetch(`https://de1.api.radio-browser.info/json/stations/byuuid?uuids=${encodeURIComponent(uuid)}`, { signal });
  if (!res.ok) return null;
  const rows: { stationuuid: string; name: string; url_resolved?: string; url: string; favicon?: string; codec?: string; bitrate?: number; country?: string }[] = await res.json();
  const s = rows[0];
  if (!s) return null;
  return {
    id: s.stationuuid,
    name: s.name.trim(),
    stream: s.url_resolved || s.url,
    favicon: s.favicon || null,
    codec: s.codec || "MP3",
    bitrate: s.bitrate || 128,
    country: s.country || "",
  };
}

/** Lista M3U lista para descargar de tus emisoras cargadas. */
export function stationsToM3u(stations: RadioStation[]): string {
  const lines = ["#EXTM3U", "#PLAYLIST: TV LO3 Radio"];
  for (const s of stations) lines.push(`#EXTINF:-1,${s.name}`, s.stream);
  return lines.join("\n");
}

/* ───────── Divisas (open.er-api.com · ECB, sin clave) ───────── */
export interface EurRates { USD: number; GBP: number; MXN: number }
export async function fetchEurRates(): Promise<EurRates | null> {
  try {
    const res = await fetch("https://open.er-api.com/v6/latest/EUR");
    if (!res.ok) return null;
    const j = await res.json();
    const r = j?.rates;
    if (!r) return null;
    return { USD: Number(r.USD), GBP: Number(r.GBP), MXN: Number(r.MXN) };
  } catch { return null; }
}
