import { useEffect, useRef, useState } from "react";
import { Cloud, Download, File, FileArchive, FileText, Film, Image as ImageIcon, Loader2, Music2, Search, Trash2, Upload, X } from "lucide-react";

interface CloudFile { id: string; name: string; size: number; type: string; modified: number; blob: Blob }
const DB_NAME = "lo3-cloud";
const STORE_NAME = "files";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => { const db = req.result; if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: "id" }); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function dbList(): Promise<CloudFile[]> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).getAll();
    req.onsuccess = () => resolve((req.result as CloudFile[]).sort((a, b) => b.modified - a.modified));
    req.onerror = () => reject(req.error);
  });
}
async function dbPut(file: CloudFile): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = db.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME).put(file);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}
async function dbDelete(id: string): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = db.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME).delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}
const fmtSize = (b: number) => (b < 1024 * 1024 ? `${Math.max(1, Math.round(b / 1024))} KB` : `${(b / 1024 / 1024).toFixed(1)} MB`);
function iconFor(type: string, name: string) {
  if (type.startsWith("image/")) return ImageIcon;
  if (type.startsWith("video/")) return Film;
  if (type.startsWith("audio/")) return Music2;
  if (/pdf|document|text/.test(type) || /\.(pdf|doc|txt|md)$/i.test(name)) return FileText;
  if (/zip|rar|7z|tar|gz/.test(name)) return FileArchive;
  return File;
}

export default function CloudView() {
  const [files, setFiles] = useState<CloudFile[] | null>(null);
  const [query, setQuery] = useState("");
  const [uploading, setUploading] = useState(false);
  const [quota, setQuota] = useState<{ usage: number; quota: number } | null>(null);
  const [dragging, setDragging] = useState(false);
  const [thumbs, setThumbs] = useState<Record<string, string>>({});
  const inputRef = useRef<HTMLInputElement>(null);

  const refresh = async () => {
    try { setFiles(await dbList()); } catch { setFiles([]); }
    try { const e = await navigator.storage?.estimate?.(); if (e) setQuota({ usage: e.usage ?? 0, quota: e.quota ?? 0 }); } catch { /* estimate unsupported */ }
  };
  useEffect(() => { refresh(); }, []);

  // object URLs for image thumbnails
  useEffect(() => {
    if (!files) return;
    const urls: Record<string, string> = {};
    for (const f of files) if (f.type.startsWith("image/")) urls[f.id] = URL.createObjectURL(f.blob);
    setThumbs(urls);
    return () => { for (const u of Object.values(urls)) URL.revokeObjectURL(u); };
  }, [files]);

  const upload = async (list: FileList | null) => {
    if (!list?.length) return;
    setUploading(true);
    for (const f of Array.from(list)) {
      try { await dbPut({ id: crypto.randomUUID(), name: f.name, size: f.size, type: f.type || "application/octet-stream", modified: Date.now(), blob: f }); } catch { /* quota exceeded — saltamos ese archivo */ }
    }
    await refresh();
    setUploading(false);
  };
  const remove = async (id: string) => { await dbDelete(id); await refresh(); };
  const download = (f: CloudFile) => {
    const url = URL.createObjectURL(f.blob);
    const a = document.createElement("a");
    a.href = url; a.download = f.name; a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
  };

  const shown = (files ?? []).filter((f) => f.name.toLowerCase().includes(query.trim().toLowerCase()));
  const totalBytes = (files ?? []).reduce((acc, f) => acc + f.size, 0);
  const quotaPct = quota && quota.quota > 0 ? Math.min(100, (quota.usage / quota.quota) * 100) : null;

  return (
    <div className="flex h-full flex-col gap-3 overflow-hidden p-3 sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-sky-400 to-indigo-700"><Cloud size={19} className="text-white" /></span>
          <div>
            <h1 className="font-display text-lg font-black text-white">TV LO3 Cloud</h1>
            <p className="text-[10px] uppercase tracking-wider text-slate-500">Bóveda local cifrada por el dispositivo · IndexedDB · sin subir nada</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <label className="relative">
            <span className="sr-only">Buscar archivo</span>
            <Search size={13} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar archivo…" className="h-10 w-44 rounded-xl border border-white/10 bg-black/30 pl-9 pr-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-cyanx/50" />
          </label>
          <button onClick={() => inputRef.current?.click()} disabled={uploading} className="grad-btn flex h-10 items-center gap-2 rounded-xl px-4 text-xs font-bold text-white disabled:opacity-60">
            {uploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />} Subir
          </button>
          <input ref={inputRef} type="file" multiple hidden onChange={(e) => upload(e.target.files)} />
        </div>
      </div>

      {/* stats row */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2"><p className="font-display text-lg font-black text-white">{files?.length ?? "…"}</p><p className="text-[9px] uppercase tracking-wider text-slate-500">Archivos</p></div>
        <div className="rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2"><p className="font-display text-lg font-black text-white">{fmtSize(totalBytes)}</p><p className="text-[9px] uppercase tracking-wider text-slate-500">Almacenados</p></div>
        <div className="rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2">
          <p className="font-display text-lg font-black text-white">{quotaPct != null ? `${quotaPct.toFixed(1)}%` : "—"}</p>
          <p className="text-[9px] uppercase tracking-wider text-slate-500">Cuota del navegador</p>
          {quotaPct != null && <div className="mt-1 h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-cyanx to-violetx" style={{ width: `${Math.max(2, quotaPct)}%` }} /></div>}
        </div>
      </div>

      {/* drop zone / list */}
      <div
        className={`thin-scroll min-h-0 flex-1 overflow-y-auto rounded-2xl border transition-colors ${dragging ? "border-cyanx/60 bg-cyanx/5" : "border-white/8"}`}
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => { e.preventDefault(); setDragging(false); upload(e.dataTransfer.files); }}
      >
        {files === null && <div className="flex h-full items-center justify-center"><Loader2 className="animate-spin text-slate-600" /></div>}
        {files !== null && shown.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center gap-2 p-6 text-center">
            <Upload size={34} className="text-slate-700" strokeWidth={1.5} />
            <p className="text-sm font-bold text-slate-300">{query ? `Nada para “${query}”` : "Arrastra archivos aquí o pulsa Subir"}</p>
            <p className="max-w-xs text-[11px] text-slate-500">Los archivos nunca salen de este dispositivo. Ideal para vídeos y fotos que no quieres sincronizar todavía.</p>
          </div>
        )}
        <ul className="grid gap-1.5 p-2 sm:grid-cols-2">
          {shown.map((f) => {
            const Icon = iconFor(f.type, f.name);
            const thumb = thumbs[f.id];
            return (
              <li key={f.id} className="group flex items-center gap-2.5 rounded-xl border border-white/8 bg-white/[0.03] p-2 transition-colors hover:border-cyanx/30">
                {thumb
                  ? <img src={thumb} alt="" className="h-12 w-12 shrink-0 rounded-lg object-cover" />
                  : <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-panel3"><Icon size={18} className="text-cyanx" /></span>}
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[11px] font-bold text-slate-100" title={f.name}>{f.name}</span>
                  <span className="text-[8px] uppercase tracking-wider text-slate-500">{fmtSize(f.size)} · {new Date(f.modified).toLocaleDateString("es-ES", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                </span>
                <span className="flex shrink-0 items-center gap-1 opacity-70 transition-opacity group-hover:opacity-100">
                  <button onClick={() => download(f)} aria-label={`Descargar ${f.name}`} className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-cyanx"><Download size={15} /></button>
                  <button onClick={() => remove(f.id)} aria-label={`Eliminar ${f.name}`} className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-rose-400"><Trash2 size={15} /></button>
                </span>
              </li>
            );
          })}
        </ul>
      </div>
      <p className="flex items-center justify-between gap-2 text-[9px] text-slate-600"><span>TV LO3 Cloud 4.0 sincronizará con tu proveedor (próximamente). Lo que guardes aquí se queda aquí.</span>{files?.length ? <button onClick={async () => { if (window.confirm("¿Borrar TODA la bóveda local y sus blobs?")) { const db = await openDb(); db.close(); indexedDB.deleteDatabase(DB_NAME); window.setTimeout(() => window.location.reload(), 150); } }} className="flex shrink-0 items-center gap-1 font-bold text-slate-500 hover:text-rose-400"><X size={10} />Vaciar bóveda</button> : null}</p>
    </div>
  );
}
