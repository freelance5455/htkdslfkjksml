import { useEffect, useMemo, useState } from "react";
import { CircleAlert, History, Layers, ListFilter, Loader2, RefreshCw, RotateCw, SatelliteDish, Search, Star } from "lucide-react";
import { fetchTvSource, type Channel } from "./api";
import { TV_MODE_LABELS, TV_MODE_SOURCES, type TvSource, type TvSourceMode } from "./tv-sources";
import VideoPlayer from "./VideoPlayer";
import { usePrivacyMax } from "./usePrivacyMax";
import { useLocalStorage } from "./useLocalStorage";

const PAGE = 240;
const MODES: TvSourceMode[] = ["paises", "regiones", "categorias", "idiomas", "todo"];

export default function WorldTvView() {
  const [mode, setMode] = useState<TvSourceMode>("paises");
  const [source, setSource] = useState<TvSource>(() => TV_MODE_SOURCES.paises.find((s) => s.code === "es") ?? TV_MODE_SOURCES.paises[0]);
  const [channels, setChannels] = useState<Channel[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [filter, setFilter] = useState("");
  const [group, setGroup] = useState("Todos");
  const [visible, setVisible] = useState(PAGE);
  const pm = usePrivacyMax();
  const [selected, setSelected] = useState<Channel | null>(null);
  const [favs, setFavs] = useLocalStorage<string[]>("lo3-tv-favs", []);
  const [last, setLast] = useLocalStorage<{ sourceCode: string; mode: TvSourceMode; id: string } | null>("lo3-tv-last", null);

  const load = (src: TvSource) => {
    setLoading(true);
    setError(false);
    setChannels(null);
    setVisible(PAGE);
    setGroup("Todos");
    const ctrl = new AbortController();
    fetchTvSource(src.url, ctrl.signal)
      .then(setChannels)
      .catch((e) => { if ((e as Error).name !== "AbortError") setError(true); })
      .finally(() => setLoading(false));
    return () => ctrl.abort();
  };

  useEffect(() => load(source), [source]); // eslint-disable-line react-hooks/exhaustive-deps

  const selectMode = (m: TvSourceMode) => {
    setMode(m);
    const first = m === "paises" ? TV_MODE_SOURCES[m].find((s) => s.code === "es")! : TV_MODE_SOURCES[m][0];
    setSource(first);
  };

  const sources = TV_MODE_SOURCES[mode];
  const groupOrder = useMemo(() => {
    const order: string[] = [];
    for (const s of sources) if (s.group && !order.includes(s.group)) order.push(s.group);
    return order;
  }, [sources]);

  const groups = useMemo(() => {
    const counts = new Map<string, number>();
    for (const ch of channels ?? []) counts.set(ch.group, (counts.get(ch.group) ?? 0) + 1);
    return ["Todos", ...[...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([g]) => g)];
  }, [channels]);

  const shown = useMemo(() => {
    let list = channels ?? [];
    if (group !== "Todos") list = list.filter((c) => c.group === group);
    const q = filter.trim().toLowerCase();
    if (q) list = list.filter((c) => c.name.toLowerCase().includes(q) || c.group.toLowerCase().includes(q));
    return list;
  }, [channels, group, filter]);
  const visibleList = shown.slice(0, visible);

  const pick = (ch: Channel) => {
    setSelected(ch);
    setLast({ sourceCode: source.code, mode, id: ch.id });
  };
  const toggleFav = (id: string) => setFavs((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  const sintonizeLast = () => {
    if (!last) return;
    if (last.mode !== mode || last.sourceCode !== source.code) {
      setMode(last.mode);
      const src = TV_MODE_SOURCES[last.mode].find((s) => s.code === last.sourceCode);
      if (src) setSource(src);
      return; // el usuario pulsa de nuevo tras recargar la lista
    }
    const ch = channels?.find((c) => c.id === last.id);
    if (ch) pick(ch);
  };

  return (
    <div className="flex h-full gap-3 overflow-hidden p-3 sm:p-4">
      {/* ── left: player ─────────────────────────────────────── */}
      <div className="flex min-w-0 flex-1 flex-col gap-2">
        {selected ? (
          <>
            <VideoPlayer src={selected.url} title={selected.name} />
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2">
              <div className="min-w-0">
                <p className="truncate text-sm font-bold text-white">{selected.name}</p>
                <p className="text-[10px] uppercase tracking-wider text-slate-500">{selected.group}{selected.geoBlocked ? " · Geo-bloqueado en algunas regiones" : ""} · {source.label}</p>
              </div>
              <button onClick={() => toggleFav(selected.id)} aria-pressed={favs.includes(selected.id)} aria-label="Alternar favorito" className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 transition-transform hover:scale-105">
                <Star size={18} className={favs.includes(selected.id) ? "fill-gold text-gold" : "text-slate-400"} />
              </button>
            </div>
          </>
        ) : (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/12 bg-white/[0.02] p-6 text-center">
            <SatelliteDish size={40} className="text-slate-600" strokeWidth={1.4} />
            <div>
              <p className="font-display text-lg font-bold text-slate-200">Elige un canal para sintonizar</p>
              <p className="mt-1 max-w-md text-xs text-slate-500">{TV_ALL_LONG}</p>
            </div>
            {last && (
              <button onClick={sintonizeLast} className="ghost-btn flex h-11 items-center gap-2 rounded-xl px-4 text-sm font-semibold text-cyanx"><History size={16} /> Sintonizar último canal</button>
            )}
          </div>
        )}
        <p className="hidden text-[9px] leading-snug text-slate-600 lg:block">Fuentes: iptv-org (github.io y espejo gitlab.io) — índices de canales públicos por país, región, categoría e idioma. TV LO3 no aloja streams; las señales geobloqueadas o caídas no abrirán. Contenidos sujetos a la licencia de cada emisora.</p>
      </div>

      {/* ── right: browser ───────────────────────────────────── */}
      <aside className="flex w-[320px] shrink-0 flex-col gap-2 lg:w-[380px]" aria-label="Explorador de canales">
        <div className="flex items-center justify-between gap-2">
          <h1 className="flex items-center gap-2 font-display text-base font-bold text-white"><Layers size={16} className="text-cyanx" /> World TV</h1>
          <span className="chip">{channels ? `${shown.length.toLocaleString("es-ES")} canales` : "…"}</span>
        </div>

        {/* mode segmented control */}
        <div className="flex gap-1 rounded-xl border border-white/8 bg-white/[0.04] p-1" role="tablist" aria-label="Tipo de lista">
          {MODES.map((m) => (
            <button key={m} role="tab" aria-selected={mode === m} onClick={() => selectMode(m)} className={`h-8 flex-1 rounded-lg text-[9px] font-black uppercase tracking-wider transition-colors ${mode === m ? "bg-gradient-to-r from-electric to-violetx text-white" : "text-slate-500 hover:text-white"}`}>{TV_MODE_LABELS[m]}</button>
          ))}
        </div>

        {/* sources chips */}
        <div className="thin-scroll -mx-1 flex max-h-24 flex-wrap gap-1 overflow-y-auto px-1" role="tablist" aria-label={`${TV_MODE_LABELS[mode]} disponibles`}>
          {groupOrder.length > 0 && sources.map((s, i) => {
            const prevGroup = i > 0 ? sources[i - 1].group : null;
            const showDivider = s.group && s.group !== prevGroup;
            const active = source.code === s.code && source.url === s.url;
            return (
              <span key={s.code + s.url} className="contents">
                {showDivider && <span className="w-full pt-1 text-[8px] font-black uppercase tracking-[0.25em] text-slate-600">{s.group}</span>}
                <button role="tab" aria-selected={active} onClick={() => setSource(s)} className={`flex items-center gap-1 rounded-lg px-2 py-1 text-[9px] font-bold transition-colors ${active ? "bg-electric text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}>
                  {s.label}{s.approx != null && <span className="text-[8px] font-semibold text-slate-500">~{(s.approx / 1000).toFixed(1)}k</span>}
                </button>
              </span>
            );
          })}
          {groupOrder.length === 0 && sources.map((s) => {
            const active = source.code === s.code && source.url === s.url;
            return (
              <button key={s.code} role="tab" aria-selected={active} onClick={() => setSource(s)} className={`flex items-center gap-1 rounded-lg px-2 py-1 text-[9px] font-bold transition-colors ${active ? "bg-electric text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}>
                {s.label}{s.approx != null && <span className="text-[8px] font-semibold text-slate-500">~{(s.approx / 1000).toFixed(1)}k</span>}
              </button>
            );
          })}
        </div>

        {/* search + refresh */}
        <div className="flex gap-1.5">
          <div className="relative flex-1">
            <Search size={13} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <label htmlFor="channel-filter" className="sr-only">Buscar canal</label>
            <input id="channel-filter" value={filter} onChange={(e) => { setFilter(e.target.value); setVisible(PAGE); }} placeholder={`Buscar en ${source.label}…`} className="h-9 w-full rounded-xl border border-white/10 bg-black/30 pl-8 pr-2 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-cyanx/50" />
          </div>
          <button onClick={() => load(source)} aria-label="Recargar lista" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-slate-400 hover:text-white">
            <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
          </button>
        </div>

        {/* group filter */}
        <div className="thin-scroll -mx-1 flex gap-1 overflow-x-auto px-1">
          {groups.map((g) => (
            <button key={g} onClick={() => setGroup(g)} aria-pressed={group === g} className={`whitespace-nowrap rounded-lg px-2 py-1 text-[9px] font-bold uppercase tracking-wider transition-colors ${group === g ? "bg-violetx/80 text-white" : "bg-white/5 text-slate-500 hover:text-slate-200"}`}>{g}</button>
          ))}
        </div>

        {/* list */}
        <div className="thin-scroll min-h-0 flex-1 space-y-1 overflow-y-auto pr-0.5" aria-busy={loading}>
          {loading && Array.from({ length: 8 }).map((_, i) => <div key={i} className="flex h-12 items-center gap-2 rounded-xl bg-white/[0.04] px-2"><Loader2 size={14} className="animate-spin text-slate-700" /></div>)}
          {error && (
            <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-center">
              <CircleAlert size={22} className="mx-auto text-red-400" />
              <p className="mt-1.5 text-xs text-red-300">No se pudo descargar «{source.label}».</p>
              <button onClick={() => setSource({ ...source })} className="mt-2 rounded-lg bg-red-500/20 px-3 py-1.5 text-[11px] font-bold text-red-200 hover:bg-red-500/30"><RotateCw size={11} className="mr-1 inline" />Reintentar</button>
            </div>
          )}
          {!loading && !error && shown.length === 0 && <p className="rounded-xl border border-white/8 p-4 text-center text-[11px] text-slate-500">Sin canales para “{filter}”.</p>}
          {!loading && !error && visibleList.map((ch) => {
            const active = selected?.id === ch.id;
            const fav = favs.includes(ch.id);
            return (
              <div key={ch.id} className={`group flex items-center gap-2 rounded-xl border p-1.5 transition-colors ${active ? "border-cyanx/50 bg-cyanx/8" : "border-white/6 bg-white/[0.02] hover:border-white/15"}`}>
                <button onClick={() => pick(ch)} className="flex min-w-0 flex-1 items-center gap-2 text-left" aria-label={`Sintonizar ${ch.name}`}>
                  {!pm && ch.logo
                    ? <img src={ch.logo} alt="" loading="lazy" width={36} height={36} className="h-9 w-9 shrink-0 rounded-lg bg-white/5 object-contain p-0.5" onError={(e) => ((e.target as HTMLImageElement).style.visibility = "hidden")} />
                    : <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-panel3 text-[10px] font-black text-slate-300">{ch.name.slice(0, 2).toUpperCase()}</span>}
                  <span className="min-w-0">
                    <span className="block truncate text-[11px] font-semibold leading-tight text-slate-100">{ch.name}</span>
                    <span className="text-[8px] uppercase tracking-wider text-slate-500">{ch.group}{fav ? " · ★" : ""}</span>
                  </span>
                </button>
                <button onClick={() => toggleFav(ch.id)} aria-pressed={fav} aria-label={fav ? `Quitar ${ch.name} de favoritos` : `Añadir ${ch.name} a favoritos`} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-500 opacity-60 transition-all hover:bg-white/5 hover:text-gold hover:opacity-100">
                  <Star size={15} className={fav ? "fill-gold text-gold opacity-100" : ""} />
                </button>
              </div>
            );
          })}
          {!loading && !error && shown.length > visible && (
            <button onClick={() => setVisible((v) => v + PAGE)} className="flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-cyanx/30 bg-cyanx/5 text-[11px] font-bold text-cyanx transition-colors hover:bg-cyanx/15">
              <ListFilter size={13} /> Mostrar {Math.min(PAGE, shown.length - visible)} más de {shown.length.toLocaleString("es-ES")}
            </button>
          )}
        </div>
        <p className="flex items-center justify-between gap-2 text-[9px] text-slate-600"><span className="flex items-center gap-1.5"><Star size={10} />Favoritos y último canal se guardan aquí</span><span className="font-mono">{channels?.length.toLocaleString("es-ES") ?? 0} señales</span></p>
      </aside>
    </div>
  );
}

const TV_ALL_LONG = "Más de 10.000 señales públicas IPTV clasificadas: 150+ países, 46 regiones, 31 categorías, 25 idiomas y los índices maestros de iptv-org (incluido el espejo GitLab).";
