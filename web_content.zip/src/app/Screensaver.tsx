import { useEffect, useRef, useState } from "react";
import { useLocalStorage } from "./useLocalStorage";
import { useNow } from "../lib/hooks";

/**
 * Salvapantallas TV LO3 — se activa solo tras N segundos sin input.
 * Toca/pulsa/rueda/tecla para volver. Configurable en Ajustes → Sistema.
 */
export default function Screensaver({ profileName }: { profileName: string }) {
  const [enabled] = useLocalStorage("lo3-screensaver", true);
  const [clockStyle] = useLocalStorage<"digital" | "analog" | "minimal">("lo3-clock-style", "digital");
  const [delay] = useLocalStorage("lo3-screensaver-delay", 30);
  const [active, setActive] = useState(false);
  const now = useNow(1000);
  const timer = useRef(0);
  const inputRef = useRef<() => void>(() => {});

  useEffect(() => {
    if (!enabled) { setActive(false); return; }
    const arm = () => {
      window.clearTimeout(timer.current);
      setActive(false);
      timer.current = window.setTimeout(() => setActive(true), Math.max(5, delay) * 1000);
    };
    inputRef.current = arm;
    const events = ["pointerdown", "pointermove", "wheel", "keydown", "touchstart", "scroll"] as const;
    arm();
    events.forEach((e) => window.addEventListener(e, arm, { passive: true }));
    return () => {
      window.clearTimeout(timer.current);
      events.forEach((e) => window.removeEventListener(e, arm));
    };
  }, [enabled, delay]);

  if (!active) return null;

  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  const date = now.toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "long" });

  return (
    <div className="tvlo3-screensaver fixed inset-0 z-[70] flex flex-col items-center justify-center overflow-hidden bg-[#020617]" role="dialog" aria-label="Salvapantallas — toca para volver">
      {/* aurora blobs */}
      <div aria-hidden="true" className="pointer-events-none absolute -left-40 top-[-20%] h-[42rem] w-[42rem] rounded-full bg-[radial-gradient(circle,rgba(34,211,238,0.22),transparent_65%)] blur-3xl ss-drift-1" />
      <div aria-hidden="true" className="pointer-events-none absolute right-[-15%] top-[20%] h-[38rem] w-[38rem] rounded-full bg-[radial-gradient(circle,rgba(168,85,247,0.24),transparent_65%)] blur-3xl ss-drift-2" />
      <div aria-hidden="true" className="pointer-events-none absolute bottom-[-25%] left-[30%] h-[40rem] w-[46rem] rounded-full bg-[radial-gradient(circle,rgba(47,123,255,0.2),transparent_65%)] blur-3xl ss-drift-3" />
      {/* stars */}
      {STARS.map((s, i) => (
        <span key={i} aria-hidden="true" className="ss-twinkle absolute rounded-full bg-white" style={{ left: `${s[0]}%`, top: `${s[1]}%`, width: s[2], height: s[2], animationDelay: `${s[3]}s`, animationDuration: `${s[4]}s` }} />
      ))}
      {clockStyle === "digital" && (
        <>
          <p className="relative font-display text-[9rem] font-black leading-none tracking-tighter text-white/95 tabular-nums sm:text-[11rem]" style={{ textShadow: "0 0 120px rgba(56,189,248,0.45)" }}>{hh}<span className="ss-colon">:</span>{mm}</p>
          <p className="relative mt-1 font-mono text-xs uppercase tracking-[0.5em] text-cyanx/80">{ss}s</p>
          <p className="relative mt-6 text-xl font-medium capitalize text-slate-300">{date}</p>
          <p className="relative mt-2 text-[10px] uppercase tracking-[0.35em] text-slate-600">TV LO3 · {profileName.toUpperCase()}</p>
        </>
      )}
      {clockStyle === "minimal" && (
        <p className="relative font-extralight tracking-tighter text-white/90 tabular-nums" style={{ fontSize: "clamp(8rem, 28vw, 16rem)", textShadow: "0 0 80px rgba(148,163,255,0.35)" }}>{hh}:{mm}</p>
      )}
      {clockStyle === "analog" && (
        <div className="relative flex flex-col items-center">
          <svg width="300" height="300" viewBox="0 0 200 200" role="img" aria-label={`Reloj analógico: ${hh}:${mm}`}>
            <circle cx="100" cy="100" r="92" fill="rgba(9,14,42,0.55)" stroke="url(#ssFace)" strokeWidth="2.5" />
            <defs>
              <linearGradient id="ssFace" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#22d3ee" /><stop offset="0.5" stopColor="#2f7bff" /><stop offset="1" stopColor="#a855f7" /></linearGradient>
            </defs>
            {Array.from({ length: 60 }).map((_, i) => {
              const a = (i * Math.PI) / 30;
              const long = i % 5 === 0;
              const x1 = 100 + Math.sin(a) * (long ? 78 : 84);
              const y1 = 100 - Math.cos(a) * (long ? 78 : 84);
              const x2 = 100 + Math.sin(a) * 90;
              const y2 = 100 - Math.cos(a) * 90;
              return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={long ? "#7dd8ff" : "#3b4a86"} strokeWidth={long ? 2.5 : 1} strokeLinecap="round" />;
            })}
            {(() => { const secs = now.getSeconds() + now.getMilliseconds() / 1000; const mins = now.getMinutes() + secs / 60; const hours = (now.getHours() % 12) + mins / 60;
              const hand = (deg: number, len: number, w: number, color: string) => <line x1={100} y1={100} x2={100 + Math.sin((deg * Math.PI) / 180) * len} y2={100 - Math.cos((deg * Math.PI) / 180) * len} stroke={color} strokeWidth={w} strokeLinecap="round" />;
              return (<>
                {hand(hours * 30, 52, 6, "#e8ecff")}
                {hand(mins * 6, 74, 4, "#cdd6ff")}
                {hand(secs * 6, 82, 1.6, "#22d3ee")}
              </>); })()}
            <circle cx="100" cy="100" r="4.5" fill="#22d3ee" stroke="#04061a" strokeWidth="1.5" />
          </svg>
          <p className="relative mt-6 text-lg font-medium capitalize text-slate-300">{date}</p>
          <p className="relative mt-1 text-[10px] uppercase tracking-[0.35em] text-slate-600">TV LO3 · {profileName.toUpperCase()}</p>
        </div>
      )}
      <p className="relative mt-8 animate-pulse rounded-full border border-white/15 px-6 py-2 text-[10px] font-bold uppercase tracking-[0.3em] text-slate-500">Toca cualquier parte para volver</p>
    </div>
  );
}

// deterministic pseudo-random star field
const STARS: [number, number, number, number, number][] = Array.from({ length: 70 }, (_, i) => {
  const r = (seed: number) => { const x = Math.sin(seed * 999 + i * 77.7) * 10000; return x - Math.floor(x); };
  return [r(1) * 100, r(2) * 100, 1 + r(3) * 2.2, r(4) * 4, 2.4 + r(5) * 3];
});
