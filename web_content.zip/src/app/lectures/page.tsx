import type { Metadata } from "next";
import { PageHero } from "@/components/page-hero";
import { LecturePlayer } from "@/components/lecture-player";
import { LECTURES } from "@/data/lectures";
import { toArabicDigits } from "@/lib/site";

export const metadata: Metadata = {
  title: "المحاضرات الإسلامية",
  description: "محاضرات مقروءة مع مشغّل وفصول ونص مصاحب يتتبع التشغيل.",
};

export default function LecturesPage() {
  return (
    <main>
      <PageHero
        eyebrow="مجالس العلم والإيمان"
        title={
          <>
            المحاضرات <span className="text-gold-gradient">الإسلامية</span>
          </>
        }
        description={`${toArabicDigits(LECTURES.length)} محاضرة ودرساً لعلماء ودعاة سوريين: الشيخ علي الطنطاوي، والشيخ محمد سعيد رمضان البوطي، والشيخ عبد الفتاح البزم، والدكتور محمد خير الشعال، والشيخ محمد نعيم عرقسوسي، والشيخ أسامة الرفاعي. الفيديو يعمل داخل الصفحة مباشرة.`}
      />

      <section className="relative overflow-hidden bg-navy-deep py-20 text-ivory sm:py-24">
        <div
          className="absolute inset-0 bg-[radial-gradient(ellipse_50%_40%_at_80%_10%,rgba(49,75,117,0.7),transparent_70%),radial-gradient(ellipse_40%_30%_at_10%_90%,rgba(182,154,105,0.15),transparent_70%)]"
          aria-hidden="true"
        />
        <div className="grain absolute inset-0 opacity-[0.05] mix-blend-overlay" aria-hidden="true" />
        <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
          <LecturePlayer lectures={LECTURES} />
        </div>
      </section>
    </main>
  );
}
