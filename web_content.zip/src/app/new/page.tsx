"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { goTo } from "@/lib/navigate";
import type { MatchFormat, Player } from "@/lib/types";
import { BatBallLogo, BallIcon, BatIcon, TeamLogo } from "@/components/cricket";
import { createMatch } from "@/lib/match-repo";

const FORMATS: { key: MatchFormat; overs: number }[] = [
  { key: "T10", overs: 10 },
  { key: "T20", overs: 20 },
  { key: "T30", overs: 30 },
  { key: "T50", overs: 50 },
  { key: "Custom", overs: 12 },
];

const input =
  "w-full rounded-xl border border-slate-700 bg-slate-900/70 px-3 py-2.5 text-sm outline-none focus:border-emerald-500 sm:px-4 sm:text-base";
const label = "mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400";

function player(name: string): Player {
  return {
    id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    name: name.trim(),
    role: "Batsman",
  };
}

export default function NewMatchPage() {
  const router = useRouter();

  const [step, setStep] = useState(1);
  const [teamA, setTeamA] = useState("");
  const [teamB, setTeamB] = useState("");
  const [format, setFormat] = useState<MatchFormat>("T20");
  const [overs, setOvers] = useState(20);
  const [venue, setVenue] = useState("");
  const [matchDate, setMatchDate] = useState(new Date().toISOString().slice(0, 10));

  const [tossWinner, setTossWinner] = useState<"A" | "B" | null>(null);
  const [tossDecision, setTossDecision] = useState<"bat" | "bowl" | null>(null);

  const [striker, setStriker] = useState("");
  const [nonStriker, setNonStriker] = useState("");
  const [bowler, setBowler] = useState("");

  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const nameA = teamA.trim() || "Team 1";
  const nameB = teamB.trim() || "Team 2";

  // Toss winner + decision determines who bats first.
  const battingFirst: "A" | "B" | null =
    tossWinner && tossDecision
      ? tossDecision === "bat"
        ? tossWinner
        : tossWinner === "A"
          ? "B"
          : "A"
      : null;
  const battingTeam = battingFirst === "A" ? nameA : nameB;
  const bowlingTeam = battingFirst === "A" ? nameB : nameA;

  async function start() {
    setError(null);
    if (!striker.trim() || !nonStriker.trim())
      return setError("Enter both opening batsmen.");
    if (striker.trim() === nonStriker.trim())
      return setError("The two opening batsmen must be different.");
    if (!bowler.trim()) return setError("Enter the opening bowler.");
    if (!battingFirst) return setError("Complete the toss first.");

    setSaving(true);
    try {
      const batters = [player(striker), player(nonStriker)];
      const bowlers = [player(bowler)];
      const { id } = await createMatch({
        teamA: nameA,
        teamB: nameB,
        overs,
        format,
        venue: venue.trim() || undefined,
        matchDate: new Date(matchDate).toISOString(),
        tossWinner: tossWinner === "A" ? nameA : nameB,
        tossDecision: tossDecision ?? "bat",
        battingFirst,
        // Only the openers are registered now; every other player is added
        // automatically the first time they bat or bowl.
        playersA: battingFirst === "A" ? batters : bowlers,
        playersB: battingFirst === "A" ? bowlers : batters,
        openingBatsman1: striker.trim(),
        openingBatsman2: nonStriker.trim(),
        openingBowler: bowler.trim(),
        playersPerTeam: 11,
      });
      goTo(router, `/scorer?id=${id}`);
    } catch (e) {
      // Local storage failed (private-mode browser, quota). Never a cloud/database
      // problem — those are handled silently and never block starting a match.
      console.error("[match-cricket] local match creation failed:", e);
      setError("Could not start the match on this device. Please try again.");
      setSaving(false);
    }
  }

  const steps = ["Match", "Toss", "Batsmen", "Bowler"];

  return (
    <main className="mx-auto max-w-2xl px-4 py-6">
      <div className="flex items-center gap-3">
        <BatBallLogo className="h-8 w-8" />
        <div>
          <h1 className="text-xl font-black tracking-tight sm:text-2xl">New Match</h1>
          <p className="text-xs text-slate-400">
            Four quick steps — no full squad required.
          </p>
        </div>
      </div>

      {/* Step rail */}
      <div className="mt-5 flex items-center gap-1.5">
        {steps.map((s, i) => (
          <div key={s} className="flex flex-1 items-center gap-1.5">
            <div
              className={`flex h-8 flex-1 items-center justify-center rounded-lg text-[11px] font-black uppercase tracking-wide ${
                step === i + 1
                  ? "bg-emerald-500 text-slate-950"
                  : step > i + 1
                    ? "bg-emerald-500/15 text-emerald-300"
                    : "border border-slate-800 text-slate-500"
              }`}
            >
              {step > i + 1 ? "✓ " : `${i + 1}. `}
              {s}
            </div>
          </div>
        ))}
      </div>

      {/* ---------- STEP 1 : TEAMS / FORMAT ---------- */}
      {step === 1 && (
        <section className="mc-card mt-5 px-5 py-5">
          <div className="space-y-4">
            <div>
              <label className={label}>Team 1 name</label>
              <div className="flex items-center gap-3">
                <TeamLogo name={nameA} size={36} />
                <input
                  className={input}
                  value={teamA}
                  onChange={(e) => setTeamA(e.target.value)}
                  placeholder="Royal Strikers"
                  autoFocus
                />
              </div>
            </div>
            <div>
              <label className={label}>Team 2 name</label>
              <div className="flex items-center gap-3">
                <TeamLogo name={nameB} size={36} />
                <input
                  className={input}
                  value={teamB}
                  onChange={(e) => setTeamB(e.target.value)}
                  placeholder="City Warriors"
                />
              </div>
            </div>

            <div>
              <label className={label}>Match format</label>
              <div className="grid grid-cols-5 gap-2">
                {FORMATS.map((f) => (
                  <button
                    key={f.key}
                    onClick={() => {
                      setFormat(f.key);
                      if (f.key !== "Custom") setOvers(f.overs);
                    }}
                    className={`mc-btn rounded-xl py-3 text-sm font-black ${
                      format === f.key
                        ? "bg-emerald-500 text-slate-950"
                        : "border border-slate-700 text-slate-300"
                    }`}
                  >
                    {f.key}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className={label}>Overs per innings</label>
              <input
                type="number"
                min={1}
                max={90}
                className={input}
                value={overs}
                onChange={(e) => {
                  setOvers(Number(e.target.value));
                  setFormat("Custom");
                }}
              />
            </div>

            <details className="rounded-xl border border-slate-800 px-4 py-3">
              <summary className="cursor-pointer text-xs font-bold uppercase tracking-wider text-slate-400">
                Venue &amp; date (optional)
              </summary>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <input
                  className={input}
                  value={venue}
                  onChange={(e) => setVenue(e.target.value)}
                  placeholder="Central Ground"
                />
                <input
                  type="date"
                  className={input}
                  value={matchDate}
                  onChange={(e) => setMatchDate(e.target.value)}
                />
              </div>
            </details>
          </div>

          <button
            onClick={() => {
              if (!teamA.trim() || !teamB.trim()) return setError("Enter both team names.");
              if (teamA.trim().toLowerCase() === teamB.trim().toLowerCase())
                return setError("Team names must be different.");
              if (!overs || overs < 1) return setError("Enter a valid number of overs.");
              setError(null);
              setStep(2);
            }}
            className="mc-btn mt-5 h-12 w-full rounded-xl bg-emerald-500 text-base font-black text-slate-950"
          >
            Continue
          </button>
        </section>
      )}

      {/* ---------- STEP 2 : TOSS ---------- */}
      {step === 2 && (
        <section className="mc-card mt-5 px-5 py-5">
          <p className={label}>Who won the toss?</p>
          <div className="grid grid-cols-2 gap-2">
            {(["A", "B"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTossWinner(t)}
                className={`mc-btn flex items-center justify-center gap-2 rounded-xl py-4 text-sm font-black ${
                  tossWinner === t
                    ? "bg-emerald-500 text-slate-950"
                    : "border border-slate-700 text-slate-200"
                }`}
              >
                <TeamLogo name={t === "A" ? nameA : nameB} size={22} />
                {t === "A" ? nameA : nameB}
              </button>
            ))}
          </div>

          <p className={`${label} mt-5`}>What did they choose?</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setTossDecision("bat")}
              className={`mc-btn flex items-center justify-center gap-2 rounded-xl py-4 text-sm font-black ${
                tossDecision === "bat"
                  ? "bg-emerald-500 text-slate-950"
                  : "border border-slate-700 text-slate-200"
              }`}
            >
              <BatIcon className="h-4 w-4" /> BAT
            </button>
            <button
              onClick={() => setTossDecision("bowl")}
              className={`mc-btn flex items-center justify-center gap-2 rounded-xl py-4 text-sm font-black ${
                tossDecision === "bowl"
                  ? "bg-emerald-500 text-slate-950"
                  : "border border-slate-700 text-slate-200"
              }`}
            >
              <BallIcon className="h-4 w-4" /> BOWL
            </button>
          </div>

          {battingFirst && (
            <div className="mc-pop mt-5 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-center">
              <p className="text-sm font-black text-emerald-300">
                {battingTeam} will Bat First
              </p>
              <p className="text-xs text-emerald-200/70">{bowlingTeam} will Bowl First</p>
            </div>
          )}

          <div className="mt-5 flex gap-2">
            <button
              onClick={() => setStep(1)}
              className="mc-btn h-12 rounded-xl border border-slate-700 px-4 text-sm font-bold"
            >
              Back
            </button>
            <button
              disabled={!battingFirst}
              onClick={() => {
                setError(null);
                setStep(3);
              }}
              className="mc-btn h-12 flex-1 rounded-xl bg-emerald-500 text-base font-black text-slate-950 disabled:opacity-40"
            >
              Continue
            </button>
          </div>
        </section>
      )}

      {/* ---------- STEP 3 : OPENING BATSMEN ---------- */}
      {step === 3 && (
        <section className="mc-card mt-5 px-5 py-5">
          <div className="mb-4 flex items-center gap-2">
            <BatIcon className="h-4 w-4" />
            <h2 className="text-sm font-black uppercase tracking-wider">Opening Batsmen</h2>
            <span className="ml-auto text-xs text-emerald-400">{battingTeam}</span>
          </div>
          <div className="space-y-4">
            <div>
              <label className={label}>Striker ★</label>
              <input
                className={input}
                value={striker}
                onChange={(e) => setStriker(e.target.value)}
                placeholder="Enter player name"
                autoFocus
              />
            </div>
            <div>
              <label className={label}>Non-Striker</label>
              <input
                className={input}
                value={nonStriker}
                onChange={(e) => setNonStriker(e.target.value)}
                placeholder="Enter player name"
              />
            </div>
          </div>
          <div className="mt-5 flex gap-2">
            <button
              onClick={() => setStep(2)}
              className="mc-btn h-12 rounded-xl border border-slate-700 px-4 text-sm font-bold"
            >
              Back
            </button>
            <button
              disabled={!striker.trim() || !nonStriker.trim()}
              onClick={() => {
                if (striker.trim() === nonStriker.trim())
                  return setError("The two opening batsmen must be different.");
                setError(null);
                setStep(4);
              }}
              className="mc-btn h-12 flex-1 rounded-xl bg-emerald-500 text-base font-black text-slate-950 disabled:opacity-40"
            >
              Continue
            </button>
          </div>
        </section>
      )}

      {/* ---------- STEP 4 : OPENING BOWLER ---------- */}
      {step === 4 && (
        <section className="mc-card mt-5 px-5 py-5">
          <div className="mb-4 flex items-center gap-2">
            <BallIcon className="h-4 w-4" />
            <h2 className="text-sm font-black uppercase tracking-wider">Opening Bowler</h2>
            <span className="ml-auto text-xs text-emerald-400">{bowlingTeam}</span>
          </div>
          <input
            className={input}
            value={bowler}
            onChange={(e) => setBowler(e.target.value)}
            placeholder="Enter bowler name"
            autoFocus
          />

          <div className="mt-5 rounded-xl border border-slate-800 bg-slate-950/50 px-4 py-3 text-xs text-slate-400">
            <p>
              <span className="font-bold text-slate-300">{battingTeam}</span> batting ·{" "}
              <span className="font-bold text-slate-300">{bowlingTeam}</span> bowling ·{" "}
              {overs} overs
            </p>
            <p className="mt-1">
              Remaining players are added automatically when they come in to bat or bowl.
            </p>
          </div>

          <div className="mt-5 flex gap-2">
            <button
              onClick={() => setStep(3)}
              className="mc-btn h-12 rounded-xl border border-slate-700 px-4 text-sm font-bold"
            >
              Back
            </button>
            <button
              onClick={start}
              disabled={saving || !bowler.trim()}
              className="mc-btn h-12 flex-1 rounded-xl bg-emerald-500 text-base font-black text-slate-950 disabled:opacity-40"
            >
              {saving ? "Starting…" : "START SCORING"}
            </button>
          </div>
        </section>
      )}

      {error && (
        <p className="mt-4 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-300">
          {error}
        </p>
      )}
    </main>
  );
}
