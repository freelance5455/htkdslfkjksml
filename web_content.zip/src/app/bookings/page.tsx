"use client";

/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { useState } from "react";
import { useLang } from "@/lib/i18n";

type Row = {
  ref: string;
  visitDate: string;
  tickets: number;
  total: number;
  attraction: { slug: string; nameEn: string; nameAr: string; cityEn: string; cityAr: string; image: string };
};

export default function BookingsPage() {
  const { lang, t } = useLang();
  const [email, setEmail] = useState("");
  const [rows, setRows] = useState<Row[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function find(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError(t("invalidEmail"));
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/bookings?email=${encodeURIComponent(email.trim())}`);
      const data = await res.json();
      if (!res.ok) throw new Error();
      setRows(data.bookings);
    } catch {
      setError(t("error"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 pb-28">
      <h1 className="text-2xl font-extrabold">{t("lookupTitle")}</h1>
      <p className="mt-1 text-slate-600">{t("lookupSub")}</p>
      <form onSubmit={find} className="mt-5 flex gap-2">
        <input
          type="email"
          dir="ltr"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-3 text-start outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
        />
        <button disabled={busy} className="rounded-xl bg-indigo-600 px-6 font-semibold text-white hover:bg-indigo-500 disabled:opacity-60">
          {t("find")}
        </button>
      </form>
      {error && <p className="mt-3 rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</p>}

      {rows && rows.length === 0 && <p className="mt-10 text-center text-slate-500">{t("noBookings")}</p>}
      <div className="mt-6 space-y-3">
        {rows?.map((r) => (
          <Link
            key={r.ref}
            href={`/booking/${r.ref}`}
            className="flex items-center gap-4 rounded-2xl bg-white p-3 shadow-sm ring-1 ring-slate-200 transition hover:shadow-md"
          >
            <img src={r.attraction.image} alt="" className="h-20 w-24 rounded-xl object-cover" />
            <div className="min-w-0 flex-1">
              <div className="truncate font-bold">{lang === "ar" ? r.attraction.nameAr : r.attraction.nameEn}</div>
              <div className="text-sm text-slate-500">
                {lang === "ar" ? r.attraction.cityAr : r.attraction.cityEn} · {r.visitDate} · 🎟 {r.tickets}
              </div>
              <div className="font-mono text-xs text-slate-400" dir="ltr">
                {r.ref}
              </div>
            </div>
            <div className="font-extrabold text-indigo-700">€{r.total}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
