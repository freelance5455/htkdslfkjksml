import { useCallback, useEffect, useState } from "react";
import {
  CalendarClock, Car, Circle, CircleAlert, Disc, ExternalLink, Flag, Goal, Loader2, Newspaper,
  RefreshCw, Search, Shield, Snowflake, Swords, Table2, Target, Trophy, Zap, Star,
} from "lucide-react";
import {
  STANDINGS_SUPPORTED, fetchEspnNewsSafe, fetchEspnScoreboardSafe, fetchEspnStandingsSafe, searchEspn,
  type EspnArticle, type EspnEvent, type EspnSearchHit, type EspnStandingGroup,
} from "./api";
import { timeAgo } from "./catalog";
import { useLocalStorage } from "./useLocalStorage";
import { usePrivacyMax } from "./usePrivacyMax";

type SportLeague = { slug: string; label: string };
type SportSection = { id: string; label: string; tagline: string; icon: typeof Goal; accent: string; leagues: SportLeague[] };

const SECTIONS: SportSection[] = [
  { id: "futbol", label: "Fútbol", tagline: "LaLiga · Europa · América · Mundial · Copas", icon: Goal, accent: "from-emerald-400 to-teal-700", leagues: [
    { slug: "soccer/esp.1", label: "LaLiga" }, { slug: "soccer/esp.2", label: "LaLiga Hypermotion" },
    { slug: "soccer/eng.1", label: "Premier League" }, { slug: "soccer/eng.2", label: "Championship" },
    { slug: "soccer/eng.fa", label: "FA Cup" }, { slug: "soccer/ger.1", label: "Bundesliga" },
    { slug: "soccer/ita.1", label: "Serie A" }, { slug: "soccer/fra.1", label: "Ligue 1" },
    { slug: "soccer/por.1", label: "Liga Portugal" }, { slug: "soccer/ned.1", label: "Eredivisie" },
    { slug: "soccer/uefa.champions", label: "Champions League" }, { slug: "soccer/uefa.europa", label: "Europa League" },
    { slug: "soccer/uefa.europa.conf", label: "Conference League" }, { slug: "soccer/fifa.world", label: "Mundial" },
    { slug: "soccer/usa.1", label: "MLS" }, { slug: "soccer/mex.1", label: "Liga MX" },
    { slug: "soccer/arg.1", label: "Liga Profesional" }, { slug: "soccer/bra.1", label: "Brasileirão" },
    { slug: "soccer/col.1", label: "Primera A (COL)" }, { slug: "soccer/per.1", label: "Liga 1 (PER)" }, { slug: "soccer/uru.1", label: "Primera (URU)" },
    { slug: "soccer/esp.copa_del_rey", label: "Copa del Rey" }, { slug: "soccer/eng.league_cup", label: "EFL Cup" },
    { slug: "soccer/ita.coppa_italia", label: "Coppa Italia" }, { slug: "soccer/ger.dfb_pokal", label: "DFB-Pokal" },
    { slug: "soccer/conmebol.libertadores", label: "Libertadores" }, { slug: "soccer/conmebol.sudamericana", label: "Sudamericana" },
    { slug: "soccer/concacaf.champions", label: "CONCACAF Champions" }, { slug: "soccer/uefa.nations", label: "Nations League" },
    { slug: "soccer/sco.1", label: "Premiership (SCO)" }, { slug: "soccer/bel.1", label: "Pro League" },
    { slug: "soccer/sui.1", label: "Super League (SUI)" }, { slug: "soccer/tur.1", label: "Süper Lig" },
    { slug: "soccer/aus.1", label: "A-League (AUS)" }, { slug: "soccer/ksa.1", label: "Saudi Pro League" },
    { slug: "soccer/aut.1", label: "Bundesliga (AUT)" }, { slug: "soccer/den.1", label: "Superliga (DEN)" },
    { slug: "soccer/nor.1", label: "Eliteserien (NOR)" },
  ]},
  { id: "femenino", label: "F. femenino", tagline: "Liga F · WSL — el fútbol manda", icon: Goal, accent: "from-pink-400 to-rose-800", leagues: [
    { slug: "soccer/esp.w.1", label: "Liga F" }, { slug: "soccer/eng.w.1", label: "WSL" },
  ]},
  { id: "futsal", label: "Fútbol sala", tagline: "Liga Nacional de Fútbol Sala", icon: Goal, accent: "from-lime-400 to-emerald-800", leagues: [] },
  { id: "baloncesto", label: "Baloncesto", tagline: "NBA · WNBA · ACB · Euroliga", icon: Circle, accent: "from-orange-400 to-red-700", leagues: [
    { slug: "basketball/nba", label: "NBA" }, { slug: "basketball/wnba", label: "WNBA" },
    { slug: "basketball/acb", label: "Liga ACB" }, { slug: "basketball/euroleague", label: "Euroliga" },
  ]},
  { id: "americano", label: "F. americano", tagline: "NFL — la liga rey del domingo", icon: Shield, accent: "from-amber-400 to-yellow-800", leagues: [
    { slug: "football/nfl", label: "NFL" },
  ]},
  { id: "beisbol", label: "Béisbol", tagline: "MLB — la gran liga americana", icon: Disc, accent: "from-rose-400 to-red-800", leagues: [
    { slug: "baseball/mlb", label: "MLB" },
  ]},
  { id: "hockey", label: "Hockey hielo", tagline: "NHL — goles sobre hielo", icon: Snowflake, accent: "from-sky-300 to-blue-800", leagues: [
    { slug: "hockey/nhl", label: "NHL" },
  ]},
  { id: "tenis", label: "Tenis", tagline: "ATP · WTA — gira mundial", icon: Target, accent: "from-lime-400 to-green-800", leagues: [
    { slug: "tennis/atp", label: "ATP" }, { slug: "tennis/wta", label: "WTA" },
  ]},
  { id: "golf", label: "Golf", tagline: "PGA Tour · LPGA Tour · LIV Golf", icon: Flag, accent: "from-emerald-300 to-green-900", leagues: [
    { slug: "golf/pga", label: "PGA Tour" }, { slug: "golf/lpga", label: "LPGA Tour" }, { slug: "golf/liv", label: "LIV Golf" },
  ]},
  { id: "motor", label: "Motor", tagline: "Fórmula 1 · NASCAR Cup", icon: Car, accent: "from-red-500 to-rose-900", leagues: [
    { slug: "racing/f1", label: "Fórmula 1" }, { slug: "racing/nascar-premier", label: "NASCAR Cup" },
  ]},
  { id: "mma", label: "MMA", tagline: "UFC · PFL · Bellator — el octágono", icon: Swords, accent: "from-violet-400 to-purple-900", leagues: [
    { slug: "mma/ufc", label: "UFC" }, { slug: "mma/pfl", label: "PFL" }, { slug: "mma/bellator", label: "Bellator" },
  ]},
  { id: "rugby", label: "Rugby", tagline: "Top 14 — la élite francesa", icon: Zap, accent: "from-teal-400 to-cyan-900", leagues: [
    { slug: "rugby/270559", label: "Top 14" },
  ]},
];

const FUTSAL_CLUBS = [
  { name: "Inter FS", desc: "El club capitalino, dominador histórico de la LNFS — varias ligas y copas.", url: "https://es.wikipedia.org/w/index.php?search=Inter+FS" },
  { name: "Palma Futsal", desc: "El proyecto balear más ambicioso, dos veces campeón de liga y de la UEFA Futsal Champions League.", url: "https://es.wikipedia.org/w/index.php?search=Palma+Futsal" },
  { name: "FC Barcelona", desc: "Un clásico moderno: el Barça aspira cada temporada al título nacional y europeo.", url: "https://es.wikipedia.org/wiki/F%C3%BAtbol_Sala_Club_Barcelona" },
  { name: "ElPozo Murcia", desc: "El gigante del sureste, varias veces campeón de Liga y de Europa.", url: "https://es.wikipedia.org/w/index.php?search=ElPozo+Murcia" },
  { name: "Jimbee Cartagena", desc: "El club cartagenero que ha peleado el tramo final de casi todas las recientes.", url: "https://es.wikipedia.org/w/index.php?search=Jimbee+Cartagena" },
  { name: "Atlético Navalcarnero", desc: "El FútSi histórico de Madrid, campeón de Europa y habitual en el top-4.", url: "https://es.wikipedia.org/w/index.php?search=Atl%C3%A9tico+Navalcarnero" },
  { name: "Valdepeñas", desc: "El 'Torreffaro' jienense, histórico de los playoffs de la LNFS.", url: "https://es.wikipedia.org/w/index.php?search=Valdepe%C3%B1as+f%C3%BAtbol+sala" },
  { name: "Noia Portus Apostoli", desc: "El gallego que ha roto el monopolio de siempre con una gestión impecable.", url: "https://es.wikipedia.org/w/index.php?search=Noia+Portus+Apostoli" },
];

function FutsalPane() {
  return (
    <div className="flex h-full flex-col gap-3 overflow-y-auto p-3 thin-scroll sm:p-4">
      <div className="flex items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-lime-400 to-emerald-800"><Goal size={26} className="text-white" /></span>
        <div>
          <h1 className="font-display text-xl font-black text-white">Fútbol sala</h1>
          <p className="text-[10px] uppercase tracking-wider text-slate-500">Liga Nacional de Fútbol Sala · Real Federación Española de Fútbol</p>
        </div>
      </div>
      <div className="rounded-2xl border border-lime-400/25 bg-lime-400/5 p-4 text-[11px] leading-relaxed text-lime-100/85">
        <p className="font-bold text-lime-300">España, potencia mundial del fútbol sala.</p>
        <p className="mt-1">España es una de las selecciones más laureadas de la historia del fútbol sala: campeona del mundo en 2000 y 2004 y múltiple campeona de Europa. La LNFS, fundada en 1989, es su máxima competición de clubes. TV LO3 no inventa marcadores: las APIs abiertas no publican resultados de esta liga, así que te enlaza directamente a las fuentes oficiales.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <a href="https://www.lnfs.es" target="_blank" rel="noopener noreferrer" className="grad-btn flex h-10 items-center gap-2 rounded-xl px-4 text-[11px] font-bold text-white">lnfs.es — web oficial <ExternalLink size={12} /></a>
          <a href="https://www.teledeporte.rtve.es/deportes/futbol-sala.shtml" target="_blank" rel="noopener noreferrer" className="ghost-btn flex h-10 items-center gap-2 rounded-xl px-4 text-[11px] font-bold text-white">Teledeporte — en TV pública <ExternalLink size={12} /></a>
          <a href="https://www.rfef.es" target="_blank" rel="noopener noreferrer" className="ghost-btn flex h-10 items-center gap-2 rounded-xl px-4 text-[11px] font-bold text-slate-200">RFEF <ExternalLink size={12} /></a>
          <a href="https://www.uefa.com/futsal/" target="_blank" rel="noopener noreferrer" className="ghost-btn flex h-10 items-center gap-2 rounded-xl px-4 text-[11px] font-bold text-slate-200">UEFA Futsal Champions League <ExternalLink size={12} /></a>
        </div>
      </div>
      <h2 className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-400">Clubes históricos de la LNFS</h2>
      <div className="grid gap-2 sm:grid-cols-2">
        {FUTSAL_CLUBS.map((c) => (
          <a key={c.name} href={c.url} target="_blank" rel="noopener noreferrer" className="group rounded-2xl border border-white/8 bg-panel2 p-3 transition-colors hover:border-lime-400/40">
            <span className="flex items-center justify-between gap-2"><span className="text-sm font-bold text-slate-100 transition-colors group-hover:text-white">{c.name}</span><ExternalLink size={12} className="shrink-0 text-slate-600 transition-colors group-hover:text-lime-400" /></span>
            <span className="mt-1 block text-[10px] leading-snug text-slate-500">{c.desc}</span>
          </a>
        ))}
      </div>
      <p className="text-[9px] leading-snug text-slate-600">Datos: Wikipedia (enlaces) y fuentes oficiales LNFS/RFEF/UEFA/Teledeporte. Resultados y calendarios en vivo de la LNFS no disponibles en APIs abiertas — TV LO3 solo muestra datos verificables.</p>
    </div>
  );
}

export default function SportsView() {
  const [sectionId, setSectionId] = useState("futbol");
  const section = SECTIONS.find((s) => s.id === sectionId)!;
  const [leagueSlug, setLeagueSlug] = useState(section.leagues[0].slug);
  const [tab, setTab] = useState<"partidos" | "tabla" | "noticias">("partidos");
  const [events, setEvents] = useState<EspnEvent[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [fromSnapshot, setFromSnapshot] = useState(false);
  const [standings, setStandings] = useState<EspnStandingGroup[] | null>(null);
  const [standingsSnap, setStandingsSnap] = useState(false);
  const [news, setNews] = useState<EspnArticle[] | null>(null);
  const [favs, setFavs] = useLocalStorage<string[]>("lo3-sports-favs", ["LaLiga", "NBA"]);
  const [searchQ, setSearchQ] = useState("");
  const [hits, setHits] = useState<EspnSearchHit[] | null>(null);
  const [searching, setSearching] = useState(false);
  const pm = usePrivacyMax();
  const league = section.leagues.find((l) => l.slug === leagueSlug) ?? section.leagues[0] ?? { slug: "", label: "Fútbol sala" };
  const selectSection = (s: SportSection) => {
    setSectionId(s.id);
    const first = s.leagues[0]?.slug ?? "";
    setLeagueSlug(first);
    setTab("partidos");
    setSearchQ("");
    setHits(null);
  };

  const load = useCallback(async (slug: string) => {
    setLoading(true);
    const res = await fetchEspnScoreboardSafe(slug);
    setEvents(res.events.slice(0, 8));
    setFromSnapshot(res.fromSnapshot);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!league.slug) return;
    load(league.slug);
    const id = window.setInterval(() => load(league.slug), 60000);
    // standings
    if (STANDINGS_SUPPORTED.has(league.slug)) {
      setStandings(null);
      fetchEspnStandingsSafe(league.slug).then((r: { groups: EspnStandingGroup[]; fromSnapshot: boolean }) => { setStandings(r.groups); setStandingsSnap(r.fromSnapshot); });
    } else { setStandings([]); setStandingsSnap(false); }
    // news
    setNews(null);
    (async () => {
      try {
        const res = await fetch(`https://site.api.espn.com/apis/site/v2/sports/${league.slug}/news?limit=6`);
        if (!res.ok) throw new Error("news");
        const json = await res.json();
        const arts = (json.articles ?? []).map((a: { id: number | string; headline: string; description?: string; links?: { web?: { href?: string } }; images?: { url: string }[]; published?: string }): EspnArticle => ({
          id: String(a.id), headline: a.headline, description: a.description ?? "",
          link: a.links?.web?.href ?? "https://www.espn.com", image: a.images?.[0]?.url ?? a.images?.[1]?.url ?? null, published: a.published ?? "",
        }));
        setNews(arts);
      } catch {
        setNews((await fetchEspnNewsSafe(6)).articles);
      }
    })();
    return () => window.clearInterval(id);
  }, [league.slug, load]);

  useEffect(() => {
    const q = searchQ.trim();
    if (q.length < 3) { setHits(null); return; }
    setSearching(true);
    const id = window.setTimeout(() => {
      searchEspn(q, 6).then(setHits).catch(() => setHits([])).finally(() => setSearching(false));
    }, 350);
    return () => window.clearTimeout(id);
  }, [searchQ]);

  if (section.id === "futsal") return <FutsalPane />;

  const isSoccer = league.slug.startsWith("soccer/");
  const isF1 = league.slug === "racing/f1";
  const finishedLabel = (d: string) => (d || "FINAL").toUpperCase().slice(0, 24);

  return (
    <div className="flex h-full overflow-hidden">
      {/* ── sports rail ─────────────────────────────────────── */}
      <aside className="flex w-32 shrink-0 flex-col gap-0.5 overflow-y-auto border-r border-white/5 bg-[#080e2e] p-2 thin-scroll lg:w-40" aria-label="Deportes">
        <p className="px-2 pb-1.5 pt-1 text-[8px] font-black uppercase tracking-[0.25em] text-slate-600">Todos los deportes</p>
        {SECTIONS.map((s) => {
          const Icon = s.icon;
          const active = s.id === sectionId;
          return (
            <button key={s.id} onClick={() => selectSection(s)} aria-current={active ? "true" : undefined} className={`flex items-center gap-2 rounded-xl px-2 py-2 text-left transition-all ${active ? `bg-gradient-to-r ${s.accent} text-white shadow-lg` : "text-slate-400 hover:bg-white/5 hover:text-white"}`}>
              <Icon size={16} strokeWidth={2} className="shrink-0" />
              <span className="min-w-0">
                <span className="block truncate text-[10px] font-bold leading-tight lg:text-[11px]">{s.label}</span>
                <span className={`hidden text-[8px] lg:block ${active ? "text-white/75" : "text-slate-600"}`}>{s.leagues.length} {s.leagues.length === 1 ? "competición" : "competiciones"}</span>
              </span>
            </button>
          );
        })}
        <p className="mt-auto px-2 pt-2 text-[8px] leading-snug text-slate-700">Datos reales © ESPN · clasificaciones y marcadores oficiales</p>
      </aside>

      {/* ── main pane ────────────────────────────────────────── */}
      <div className="flex min-w-0 flex-1 flex-col gap-2 overflow-y-auto p-3 thin-scroll sm:p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <span className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${section.accent}`}><section.icon size={20} className="text-white" /></span>
            <div>
              <h1 className="font-display text-lg font-black leading-tight text-white">{section.label}</h1>
              <p className="text-[9px] uppercase tracking-wider text-slate-500">{section.tagline}</p>
            </div>
          </div>
          <button onClick={() => load(league.slug)} className="flex h-10 items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 text-xs font-bold text-slate-300 transition-colors hover:text-white" aria-label="Actualizar">
            {loading ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />} Actualizar
          </button>
        </div>

        {fromSnapshot && <p className="rounded-lg border border-amber-400/30 bg-amber-400/10 px-3 py-1.5 text-[10px] font-medium text-amber-300">Sin conexión con ESPN — captura real del 24/11/2026. Se actualizará sola al volver la red.</p>}

        {/* global athlete/team search */}
        <div className="relative">
          <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <label htmlFor="espn-search" className="sr-only">Buscar jugadores y equipos</label>
          <input id="espn-search" value={searchQ} onChange={(e) => setSearchQ(e.target.value)} placeholder="Buscar jugadores y equipos… (Mbappé, Jokic, Real Madrid…)" className="h-11 w-full rounded-xl border border-white/10 bg-black/30 pl-9 pr-10 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-electric/60" />
          {searching && <Loader2 size={14} className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin text-slate-500" />}
          {hits && hits.length > 0 && (
            <div role="listbox" aria-label="Resultados de búsqueda" className="absolute z-30 mt-1.5 w-full overflow-hidden rounded-xl border border-cyanx/25 bg-[#0b1130]/95 shadow-2xl backdrop-blur-xl">
              {hits.map((h) => {
                const m = /a:(\d+)/.exec(h.uid);
                const headshot = m ? `https://a.espncdn.com/i/headshots/soccer/players/full/${m[1]}.png` : null;
                return (
                  <button key={h.id} role="option" onClick={() => window.open(h.link, "_blank", "noopener,noreferrer")} className="flex w-full items-center gap-3 px-3 py-2 text-left transition-colors hover:bg-cyanx/10">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-full bg-white/8 text-[9px] font-black text-slate-300">
                      {headshot ? <img src={headshot} alt="" width={36} height={36} className="h-full w-full object-cover" loading="lazy" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} /> : h.name[0]}
                    </span>
                    <span className="min-w-0 flex-1"><span className="block truncate text-xs font-bold text-slate-100">{h.name}</span><span className="text-[9px] uppercase tracking-wider text-slate-500">{h.subtitle || h.type}</span></span>
                    <ExternalLink size={12} className="shrink-0 text-slate-600" />
                  </button>
                );
              })}
              <p className="border-t border-white/8 px-3 py-1.5 text-[8px] font-semibold uppercase tracking-wider text-slate-600">Búsqueda en vivo © ESPN Search</p>
            </div>
          )}
          {hits && hits.length === 0 && searchQ.trim().length >= 3 && !searching && (
            <p className="absolute z-30 mt-1.5 w-full rounded-xl border border-white/10 bg-[#0b1130]/95 px-3 py-2.5 text-center text-[10px] text-slate-500 shadow-xl backdrop-blur-xl">Sin resultados para “{searchQ.trim()}” en ESPN.</p>
          )}
        </div>

        {/* league chips */}
        <div className="thin-scroll -mx-1 flex gap-1.5 overflow-x-auto px-1" role="tablist" aria-label="Competiciones">
          {section.leagues.map((l) => (
            <button key={l.slug} role="tab" aria-selected={league.slug === l.slug} onClick={() => setLeagueSlug(l.slug)} className={`flex h-8 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-3 text-[10px] font-bold transition-colors ${league.slug === l.slug ? "bg-gradient-to-r from-electric to-violetx text-white" : "bg-white/5 text-slate-300 hover:text-white"}`}>
              {l.label}
              <span
                role="checkbox" aria-checked={favs.includes(l.label)} tabIndex={0}
                aria-label={`${favs.includes(l.label) ? "Quitar" : "Seguir"} ${l.label}`}
                onClick={(e) => { e.stopPropagation(); setFavs((p) => (p.includes(l.label) ? p.filter((x) => x !== l.label) : [...p, l.label])); }}
                onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); setFavs((p) => (p.includes(l.label) ? p.filter((x) => x !== l.label) : [...p, l.label])); } }}
                className="rounded-full p-0.5 text-slate-500 transition-colors hover:text-gold"
              >
                <Star size={11} className={favs.includes(l.label) ? "fill-gold text-gold" : ""} />
              </span>
            </button>
          ))}
        </div>

        {/* tabs */}
        <div className="flex gap-1 border-b border-white/8" role="tablist" aria-label="Vista">
          {[
            { id: "partidos" as const, label: "Partidos", icon: CalendarClock },
            { id: "tabla" as const, label: "Clasificación", icon: Table2 },
            { id: "noticias" as const, label: "Noticias", icon: Newspaper },
          ].map((t) => (
            <button key={t.id} role="tab" aria-selected={tab === t.id} onClick={() => setTab(t.id)} className={`flex h-9 items-center gap-1.5 rounded-t-lg border-b-2 px-4 text-[11px] font-bold transition-colors ${tab === t.id ? "border-cyanx text-cyanx" : "border-transparent text-slate-500 hover:text-white"}`}>
              <t.icon size={13} />{t.label}
            </button>
          ))}
        </div>

        {/* ── PARTIDOS ── */}
        {tab === "partidos" && (
          <div className="grid gap-2 md:grid-cols-2" aria-live="polite">
            {loading && events === null && Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-24 animate-pulse rounded-2xl border border-white/5 bg-white/[0.03]" />)}
            {!loading && events?.length === 0 && <p className="col-span-full flex flex-col items-center gap-2 rounded-2xl border border-white/8 bg-white/[0.02] p-6 text-center text-xs text-slate-500"><CircleAlert size={20} className="text-slate-600" />Sin partidos hoy en {league.label}.<br />Los datos ESPN se actualizan en cuanto hay jornada.</p>}
            {events?.map((ev) => {
              const comp = ev.competitions?.[0];
              if (!comp) return null;
              const state = comp.status?.type?.state ?? "pre";
              const detail = comp.status?.type?.shortDetail ?? "";
              const home = comp.competitors.find((c) => c.homeAway === "home");
              const away = comp.competitors.find((c) => c.homeAway === "away");
              const badge = state === "in"
                ? <span className="flex items-center gap-1 rounded bg-red-500/20 px-1.5 py-0.5 text-[9px] font-black text-red-400"><span className="h-1.5 w-1.5 animate-live rounded-full bg-red-500" />EN VIVO</span>
                : state === "post"
                  ? <span className="rounded bg-white/10 px-1.5 py-0.5 text-[9px] font-bold text-slate-300">{finishedLabel(detail)}</span>
                  : <span className="flex items-center gap-1 rounded bg-electric/20 px-1.5 py-0.5 text-[9px] font-bold text-cyan-300"><CalendarClock size={9} />{new Date(ev.date).toLocaleDateString("es-ES", { weekday: "short", day: "numeric" })} · {new Date(ev.date).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })}</span>;
              const hasCompetitors = comp.competitors.some((c) => c?.team);
              return (
                <article key={ev.id} className="rounded-2xl border border-white/8 bg-panel2 p-3 transition-colors hover:border-cyanx/30">
                  <div className="flex items-center justify-between">{badge}<span className="text-[9px] font-bold uppercase tracking-widest text-slate-600">{league.label}</span></div>
                  {!hasCompetitors && (
                    <div className="mt-2 rounded-xl border border-white/10 bg-[#0d1434] p-3">
                      <p className="font-display text-sm font-black leading-snug text-white">{ev.name ?? league.label}</p>
                      <p className="mt-1 text-[10px] leading-snug text-slate-500">La previa completa (parrilla, horario y resultado en vivo) se publica en ESPN el día del evento. Mientras, consulta la clasificación del campeonato.</p>
                      {STANDINGS_SUPPORTED.has(league.slug) && (
                        <button onClick={() => setTab("tabla")} className="mt-2 flex h-9 items-center gap-1.5 rounded-lg bg-electric px-3 text-[10px] font-bold text-white transition-colors hover:bg-blue-500">Ver clasificación del campeonato <Table2 size={12} /></button>
                      )}
                    </div>
                  )}
                  {hasCompetitors && [away, home].map((c) => c && (
                    <div key={c.team.abbreviation + c.homeAway} className="mt-2 flex items-center gap-2">
                      {!pm && c.team.logo ? <img src={c.team.logo} alt="" width={22} height={22} loading="lazy" className="h-6 w-6 object-contain" onError={(e) => ((e.target as HTMLImageElement).style.visibility = "hidden")} /> : <span className="flex h-6 w-6 items-center justify-center rounded-full bg-white/10 text-[9px] font-black">{c.team.abbreviation?.[0]}</span>}
                      <span className="flex-1 truncate text-xs font-semibold text-slate-100">{c.team.shortDisplayName ?? c.team.displayName}</span>
                      <span className="font-display text-base font-black tabular-nums text-white">{state === "pre" ? "—" : c.score ?? "0"}</span>
                    </div>
                  ))}
                </article>
              );
            })}
          </div>
        )}

        {/* ── TABLA ── */}
        {tab === "tabla" && (
          <div aria-live="polite">
            {!STANDINGS_SUPPORTED.has(league.slug) && (
              <div className="flex flex-col items-center gap-2 rounded-2xl border border-white/8 bg-white/[0.02] p-8 text-center">
                <Trophy size={26} className="text-slate-600" />
                <p className="text-sm font-bold text-slate-300">Clasificación no disponible para {league.label}</p>
                <p className="max-w-sm text-[11px] text-slate-500">ESPN publica tabla para LaLiga, NBA y NFL. Para {league.label} tienes marcadores y noticias en sus pestañas.</p>
              </div>
            )}
            {STANDINGS_SUPPORTED.has(league.slug) && standings === null && <div className="space-y-1.5">{Array.from({ length: 10 }).map((_, i) => <div key={i} className="h-9 animate-pulse rounded-lg bg-white/[0.04]" />)}</div>}
            {STANDINGS_SUPPORTED.has(league.slug) && standingsSnap && standings && standings.length > 0 && <p className="mb-2 rounded-lg border border-amber-400/30 bg-amber-400/10 px-3 py-1.5 text-[10px] font-medium text-amber-300">Captura real del 24/11/2026 (sin conexión con ESPN).</p>}
            {STANDINGS_SUPPORTED.has(league.slug) && isF1 && standings?.map((group) => (
              <div key={group.name || "tabla"} className="mb-3 overflow-hidden rounded-2xl border border-white/8">
                <p className="border-b border-white/8 bg-white/[0.04] px-3 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{group.name === "Driver Standings" ? "Campeonato de pilotos" : "Campeonato de constructores"}</p>
                <table className="w-full text-[11px]">
                  <thead>
                    <tr className="text-left text-[9px] uppercase tracking-wider text-slate-500">
                      <th className="px-3 py-2">#</th><th className="px-2 py-2">{group.name === "Driver Standings" ? "Piloto" : "Equipo"}</th><th className="px-3 py-2 text-right">Pts</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...group.entries].sort((a, b) => Number(a.stats.rank ?? 99) - Number(b.stats.rank ?? 99)).map((e, i) => (
                      <tr key={e.abbr + i} className={`border-t border-white/5 text-slate-200 ${i === 0 ? "bg-gold/10" : i % 2 ? "bg-white/[0.02]" : ""}`}>
                        <td className="px-3 py-1.5 font-mono text-[10px] text-slate-500">{e.stats.rank ?? i + 1}</td>
                        <td className="px-2 py-1.5"><span className="flex items-center gap-2"><span className="flex h-5 w-5 shrink-0 items-center justify-center rounded text-[7px] font-black text-white" style={{ background: e.color ?? "#2f7bff" }}>{(e.abbr || "?").slice(0, 3).toUpperCase()}</span><span className="truncate font-semibold text-slate-100">{e.team}</span></span></td>
                        <td className="px-3 py-1.5 text-right font-display font-black tabular-nums text-white">{e.stats.championshipPts ?? e.stats.points ?? "0"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <p className="border-t border-white/5 px-3 py-1.5 text-[8px] uppercase tracking-wider text-slate-600">El líder en <span className="text-gold">dorado</span> · datos ESPN</p>
              </div>
            ))}
            {STANDINGS_SUPPORTED.has(league.slug) && !isF1 && standings?.map((group) => (
              <div key={group.name || "tabla"} className="mb-3 overflow-hidden rounded-2xl border border-white/8">
                {group.name && <p className="border-b border-white/8 bg-white/[0.04] px-3 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{group.name}</p>}
                <table className="w-full text-[11px]">
                  <thead>
                    <tr className="text-left text-[9px] uppercase tracking-wider text-slate-500">
                      <th className="px-3 py-2">#</th><th className="px-2 py-2">Equipo</th>
                      {isSoccer ? (<><th className="px-2 py-2 text-center">PJ</th><th className="px-2 py-2 text-center">G</th><th className="px-2 py-2 text-center">E</th><th className="px-2 py-2 text-center">P</th><th className="px-2 py-2 text-center">DG</th><th className="px-3 py-2 text-right">Pts</th></>) : (<><th className="px-2 py-2 text-center">G</th><th className="px-2 py-2 text-center">P</th><th className="px-2 py-2 text-center">DIF</th><th className="px-2 py-2 text-center">%</th><th className="px-3 py-2 text-right">Racha</th></>)}
                    </tr>
                  </thead>
                  <tbody>
                    {[...group.entries].sort((a, b) => Number(a.stats.rank ?? a.stats.playoffSeed ?? 99) - Number(b.stats.rank ?? b.stats.playoffSeed ?? 99)).map((e, i) => {
                      const zone = isSoccer ? (i < 4 ? "border-l-2 border-l-emerald-400" : i >= group.entries.length - 3 ? "border-l-2 border-l-rose-500" : "border-l-2 border-l-transparent") : "";
                      return (
                        <tr key={e.abbr + i} className={`border-t border-white/5 text-slate-200 ${zone} ${i % 2 ? "bg-white/[0.02]" : ""}`}>
                          <td className="px-3 py-1.5 font-mono text-[10px] text-slate-500">{i + 1}</td>
                          <td className="px-2 py-1.5"><span className="flex items-center gap-1.5">{!pm && e.logo && <img src={e.logo} alt="" width={16} height={16} className="h-4 w-4 object-contain" loading="lazy" onError={(ev) => ((ev.target as HTMLImageElement).style.visibility = "hidden")} />}<span className="max-w-32 truncate font-semibold text-slate-100">{e.team}</span></span></td>
                          {isSoccer ? (
                            <>
                              <td className="px-2 py-1.5 text-center tabular-nums">{e.stats.gamesPlayed ?? "—"}</td>
                              <td className="px-2 py-1.5 text-center tabular-nums">{e.stats.wins ?? "—"}</td>
                              <td className="px-2 py-1.5 text-center tabular-nums">{e.stats.ties ?? "0"}</td>
                              <td className="px-2 py-1.5 text-center tabular-nums">{e.stats.losses ?? "—"}</td>
                              <td className="px-2 py-1.5 text-center tabular-nums">{e.stats.pointDifferential ?? "—"}</td>
                              <td className="px-3 py-1.5 text-right font-display font-black text-white">{e.stats.points ?? "—"}</td>
                            </>
                          ) : (
                            <>
                              <td className="px-2 py-1.5 text-center tabular-nums">{e.stats.wins ?? "—"}</td>
                              <td className="px-2 py-1.5 text-center tabular-nums">{e.stats.losses ?? "—"}</td>
                              <td className="px-2 py-1.5 text-center tabular-nums">{e.stats.pointDifferential ?? e.stats.differential ?? "—"}</td>
                              <td className="px-2 py-1.5 text-center tabular-nums">{e.stats.winPercent ?? "—"}</td>
                              <td className="px-3 py-1.5 text-right tabular-nums">{e.stats.streak ?? "—"}</td>
                            </>
                          )}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {isSoccer && <p className="border-t border-white/5 px-3 py-1.5 text-[8px] uppercase tracking-wider text-slate-600"><span className="text-emerald-400">■</span> Champions · <span className="text-rose-500">■</span> Descenso · datos ESPN</p>}
              </div>
            ))}
          </div>
        )}

        {/* ── NOTICIAS ── */}
        {tab === "noticias" && (
          <div className="grid gap-2 md:grid-cols-2" aria-live="polite">
            {news === null && Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-32 animate-pulse rounded-2xl bg-white/[0.04]" />)}
            {news?.length === 0 && <p className="col-span-full rounded-2xl border border-white/8 p-6 text-center text-xs text-slate-500">Sin titulares disponibles para {league.label} ahora mismo.</p>}
            {news?.map((a) => (
              <a key={a.id} href={a.link} target="_blank" rel="noopener noreferrer" className="group overflow-hidden rounded-2xl border border-white/8 bg-panel2 transition-colors hover:border-cyanx/40">
                {!pm && a.image && <img src={a.image} alt="" loading="lazy" className="h-28 w-full object-cover transition-transform duration-500 group-hover:scale-105" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />}
                <span className="block p-3">
                  <span className="line-clamp-2 text-[12px] font-bold leading-snug text-slate-100">{a.headline}</span>
                  <span className="mt-1.5 flex items-center gap-1.5 text-[8px] font-bold uppercase tracking-wider text-orange-400">ESPN · {a.published ? timeAgo(a.published) : "hoy"} <ExternalLink size={9} /></span>
                </span>
              </a>
            ))}
          </div>
        )}

        {favs.length > 0 && <p className="flex items-center gap-1.5 text-[9px] text-slate-600"><Star size={10} className="fill-gold text-gold" /> Siguiendo: {favs.join(" · ")}</p>}
      </div>
    </div>
  );
}
