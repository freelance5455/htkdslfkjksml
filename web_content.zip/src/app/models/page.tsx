import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { desc } from "drizzle-orm";
import Marketplace from "@/components/Marketplace";
import type { ProductCardData } from "@/components/ProductCard";

export const dynamic = "force-dynamic";

export default async function ModelsPage() {
  const [allProducts, allCategories] = await Promise.all([
    db.select().from(products).orderBy(desc(products.id)),
    db.select().from(categories),
  ]);

  const productData: ProductCardData[] = allProducts.map((p) => ({
    id: p.id,
    name: p.name,
    modelNumber: p.modelNumber,
    category: p.category,
    price: p.price,
    description: p.description,
    image: p.image,
    status: p.status,
    isFeatured: p.isFeatured,
    isBestSeller: p.isBestSeller,
    isNewArrival: p.isNewArrival,
  }));

  return (
    <div className="relative min-h-screen bg-futuristic pt-28">
      <div className="bg-grid pointer-events-none absolute inset-0" />
      <div className="relative mx-auto max-w-7xl px-4 pb-24">
        <div className="mb-10 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-purple-400">Full Catalog</p>
          <h1 className="mt-3 font-display text-4xl font-bold text-white md:text-5xl">
            Marketplace <span className="text-gradient">Collection</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-slate-400">
            Explore every CALCORA 3D model. All prices are shown in Bangladeshi Taka (৳) with cash on delivery.
          </p>
        </div>
        <Marketplace products={productData} categories={allCategories.map((c) => c.name)} />
      </div>
    </div>
  );
}