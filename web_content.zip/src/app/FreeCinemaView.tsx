import { useEffect, useRef, useState } from "react";
import { CalendarDays, Check, ChevronRight, Clapperboard, ExternalLink, GraduationCap, Loader2, Play, Popcorn, Rocket, Search, Share2, Tv, X } from "lucide-react";
import { archiveItemUrl, archiveThumb, archiveVideoUrl, fetchArchiveMeta, searchArchive, type ArchiveDoc, type ArchiveMeta, type ArchiveTab } from "./archive";
import { usePrivacyMax } from "./usePrivacyMax";
import { useLocalStorage } from "./useLocalStorage";
import { hueOf } from "./catalog";

const GENRES = [
  { id: "todos", label: "Todas", query: "" },
  { id: "silent", label: "Cine mudo", query: 'subject:"silent film"' },
  { id: "horror", label: "Terror", query: "subject:horror" },
  { id: "western", label: "Western", query: "subject:western" },
  { id: "scifi", label: "Ciencia ficción", query: 'subject:"science fiction"' },
  { id: "comedy", label: "Comedia", query: "subject:comedy" },
  { id: "animation", label: "Animación", query: "subject:animation" },
  { id: "noir", label: "Film noir", query: 'subject:"film noir"' },
  { id: "chaplin", label: "Chaplin", query: "subject:chaplin" },
  { id: "keaton", label: "Buster Keaton", query: "subject:keaton" },
] as const;

const TABS: { id: ArchiveTab; label: string; icon: typeof Popcorn }[] = [
  { id: "movies", label: "Películas", icon: Popcorn },
  { id: "series", label: "Series", icon: Tv },
  { id: "prelinger", label: "Clásicos libres", icon: GraduationCap },
  { id: "nasa", label: "NASA", icon: Rocket },
];

export default function FreeCinemaView({ seed = "" }: { seed?: string }) {
  const [tab, setTab] = useState<ArchiveTab>("movies");
  const [genre, setGenre] = useState("todos");
  const [query, setQuery] = useState(seed);
  const dayIndex = Math.floor(Date.now() / 86400000);
  void dayIndex;
  const [docs, setDocs] = useState<ArchiveDoc[] | null>(null);
  const [numFound, setNumFound] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState(false);
  const [active, setActive] = useState<ArchiveDoc | null>(null);
  const pm = usePrivacyMax();
  const [played, setPlayed] = useLocalStorage<string[]>("lo3-free-watched", []);

  const activeGenre = GENRES.find((g) => g.id === genre) ?? GENRES[0];
  const effectiveQuery = [query.trim(), activeGenre.query].filter(Boolean).join(" AND ");

  const load = (t: ArchiveTab, q: string, p = 1, append = false) => {
    if (append) setLoadingMore(true); else setLoading(true);
    setError(false);
    const ctrl = new AbortController();
    searchArchive(t, q, p, ctrl.signal)
      .then(({ docs, numFound }) => {
        setDocs((prev) => (append && prev ? [...prev, ...docs] : docs));
        setNumFound(numFound);
      })
      .catch((e) => { if ((e as Error).name !== "AbortError") setError(true); })
      .finally(() => { setLoading(false); setLoadingMore(false); });
    return () => ctrl.abort();
  };

  useEffect(() => { setPage(1); load(tab, effectiveQuery, 1, false); }, [tab, genre]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setQuery(seed); }, [seed]);
  useEffect(() => { const id = window.setTimeout(() => { setPage(1); load(tab, effectiveQuery, 1, false); }, 450); return () => window.clearTimeout(id); }, [query]); // eslint-disable-line react-hooks/exhaustive-deps

  const loadMore = () => { const next = page + 1; setPage(next); load(tab, effectiveQuery, next, true); };

  return (
    <div className="flex h-full flex-col gap-2 overflow-hidden p-3 thin-scroll sm:p-4">
      {/* header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-orange-700"><Popcorn size={21} className="text-white" /></span>
          <div>
            <h1 className="font-display text-lg font-black text-white">Gratis</h1>
            <p className="text-[10px] uppercase tracking-wider text-slate-500">Dominio público y Creative Commons · 53.000+ títulos · Internet Archive</p>
          </div>
        </div>
        <div className="flex items-center gap-1 rounded-xl border border-white/10 bg-white/[0.04] p-1" role="tablist" aria-label="Tipo de contenido">
          {TABS.map((t) => {
            const Icon = t.icon;
            const on = tab === t.id;
            return (
              <button key={t.id} role="tab" aria-selected={on} onClick={() => setTab(t.id)} className={`flex h-9 items-center gap-1.5 rounded-lg px-3 text-[11px] font-bold transition-colors ${on ? "bg-gradient-to-r from-amber-400 to-orange-600 text-abyss" : "text-slate-400 hover:text-white"}`}><Icon size={14} />{t.label}</button>
            );
          })}
        </div>
      </div>

      {/* genre chips */}
      <div className="thin-scroll -mx-1 flex gap-1 overflow-x-auto px-1" role="tablist" aria-label="Géneros de archivo">
        {GENRES.map((g) => (
          <button key={g.id} role="tab" aria-selected={genre === g.id} onClick={() => setGenre(g.id)} className={`whitespace-nowrap rounded-full px-3 py-1.5 text-[10px] font-bold transition-colors ${genre === g.id ? "bg-amber-400 text-abyss" : "bg-white/5 text-slate-400 hover:text-white"}`}>{g.label}</button>
        ))}
      </div>

      {/* search + count */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search size={13} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <label htmlFor="archive-search" className="sr-only">Buscar en el archivo gratis</label>
          <input id="archive-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar películas y series gratis… («dracula», «chaplin», «frankenstein»…)" className="h-10 w-full rounded-xl border border-white/10 bg-black/30 pl-9 pr-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-amber-400/50" />
        </div>
        <span className="chip hidden sm:inline-flex">{loading ? "…" : numFound.toLocaleString("es-ES")} títulos</span>
      </div>

      {/* película gratis del día */}
      {tab === "movies" && !query.trim() && genre === "todos" && <FeaturedOfDay onOpen={setActive} pm={pm} />}

      {/* grid */}
      <div className="thin-scroll min-h-0 flex-1 overflow-y-auto pr-0.5" aria-busy={loading}>
        {loading && <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-6">{Array.from({ length: 12 }).map((_, i) => <div key={i} className="aspect-[2/3] animate-pulse rounded-xl bg-white/[0.04]" />)}</div>}
        {error && (
          <div className="rounded-2xl border border-red-500/30 bg-red-500/10 p-6 text-center">
            <p className="text-xs font-bold text-red-300">Internet Archive no respondió.</p>
            <button onClick={() => load(tab, query, 1, false)} className="mt-2 rounded-lg bg-red-500/20 px-4 py-2 text-[11px] font-bold text-red-200 hover:bg-red-500/30">Reintentar</button>
          </div>
        )}
        {!loading && !error && docs?.length === 0 && <p className="rounded-2xl border border-white/8 p-6 text-center text-xs text-slate-500">Nada coincide con “{query}” en {tab === "movies" ? "películas" : "series"} gratis.</p>}
        {!loading && !error && docs && (
          <>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-6">
              {docs.map((d) => {
                const watched = played.includes(d.identifier);
                return (
                  <button key={d.identifier} onClick={() => setActive(d)} className="group relative aspect-[2/3] overflow-hidden rounded-xl border border-white/10 text-left transition-all hover:-translate-y-1 hover:border-amber-400/40 focus:outline-none focus:ring-2 focus:ring-amber-400">
                    {!pm
                      ? <img src={archiveThumb(d.identifier)} alt={`Carátula de ${d.title}`} loading="lazy" className="absolute inset-0 h-full w-full object-cover" onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")} />
                      : <div className="absolute inset-0 flex flex-col justify-between p-2" style={{ background: `linear-gradient(160deg, hsl(${hueOf(d.identifier)} 55% 38%), hsl(${(hueOf(d.identifier) + 45) % 360} 65% 14%))` }}><span className="text-[8px] font-black uppercase tracking-widest text-white/60">{d.year}</span><Clapperboard size={26} className="self-center text-white/40" /></div>}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                    {watched && <span className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500" title="Ya la viste"><Check size={13} strokeWidth={3.5} className="text-abyss" /></span>}
                    <span className="absolute inset-x-1.5 bottom-1.5">
                      <span className="block line-clamp-2 font-display text-[9px] font-bold leading-tight text-white">{d.title}</span>
                      {d.year && <span className="mt-0.5 block text-[7px] uppercase tracking-wider text-amber-300/90">{d.year} · Gratis</span>}
                    </span>
                  </button>
                );
              })}
            </div>
            {docs.length < numFound && (
              <button onClick={loadMore} disabled={loadingMore} className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-amber-400/30 bg-amber-400/10 text-[11px] font-bold text-amber-300 transition-colors hover:bg-amber-400/20 disabled:opacity-60">
                {loadingMore ? <Loader2 size={15} className="animate-spin" /> : <ChevronRight size={15} />} Cargar más ({docs.length.toLocaleString("es-ES")} de {numFound.toLocaleString("es-ES")})
              </button>
            )}
          </>
        )}
      </div>
      <p className="text-[8px] leading-snug text-slate-600">Internet Archive (archive.org) indexa dominio público, Creative Commons y subidas de terceros — la licitud exacta de cada título varía según tu país. Si dudas de un título, no lo reproduzcas. Atribución: Internet Archive.</p>

      {active && <FreeModal doc={active} onClose={() => setActive(null)} onMarkWatched={() => setPlayed((p) => (p.includes(active.identifier) ? p : [...p, active.identifier]))} />}
    </div>
  );
}

/* ═══════════════ MODAL FICHA + REPRODUCTOR ═══════════════ */
function FreeModal({ doc, onClose, onMarkWatched }: { doc: ArchiveDoc; onClose: () => void; onMarkWatched: () => void }) {
  const [meta, setMeta] = useState<ArchiveMeta | null>(null);
  const [error, setError] = useState(false);
  const [playing, setPlaying] = useState(false);
  const pm = usePrivacyMax();
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const ctrl = new AbortController();
    fetchArchiveMeta(doc.identifier, ctrl.signal).then(setMeta).catch(() => setError(true));
    return () => ctrl.abort();
  }, [doc.identifier]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const hue = hueOf(doc.identifier);

  return (
    <div role="dialog" aria-modal="true" aria-label={`Ficha de ${doc.title}`} className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6">
      <button aria-label="Cerrar" onClick={onClose} className="absolute inset-0 cursor-default bg-black/75 backdrop-blur-sm" />
      <div className="relative flex max-h-[92vh] w-full max-w-2xl flex-col overflow-y-auto rounded-2xl border border-white/12 bg-[#0b1130] shadow-2xl">
        <button onClick={onClose} aria-label="Cerrar" className="absolute right-3 top-3 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-black/60 text-slate-300 backdrop-blur-sm hover:text-white"><X size={17} /></button>

        {playing && meta?.videoFile ? (
          <div className="relative w-full bg-black">
            <video ref={videoRef} src={archiveVideoUrl(meta.identifier, meta.videoFile.name)} controls autoPlay playsInline className="aspect-video w-full" aria-label={`Reproduciendo ${meta.title}`} />
            <div className="flex items-center justify-between gap-2 p-3">
              <p className="min-w-0 truncate text-xs font-bold text-slate-200">{meta.title}</p>
              <button onClick={() => setPlaying(false)} className="ghost-btn h-9 shrink-0 rounded-lg px-3 text-[11px] font-bold text-white">← Ficha</button>
            </div>
          </div>
        ) : (
          <div className="grid sm:grid-cols-[200px_1fr]">
            {/* poster */}
            <div className="relative min-h-40 overflow-hidden" style={{ background: `linear-gradient(160deg, hsl(${hue} 55% 34%), hsl(${(hue + 50) % 360} 70% 12%))` }}>
              {!pm && <img src={archiveThumb(doc.identifier)} alt="" className="absolute inset-0 h-full w-full object-cover opacity-80" onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")} />}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <p className="absolute bottom-2 left-3 right-3 font-display text-sm font-black leading-tight text-white">{doc.year ?? ""}</p>
            </div>
            {/* body */}
            <div className="flex flex-col gap-2 p-4 sm:p-5">
              <h3 className="font-display text-lg font-black leading-tight text-white">{meta?.title ?? doc.title}</h3>
              {meta?.creators.length ? <p className="text-[10px] uppercase tracking-wider text-slate-500">{meta.creators.slice(0, 3).join(" · ")}</p> : null}
              {error ? (
                <p className="rounded-xl border border-red-500/25 bg-red-500/10 p-3 text-[11px] text-red-300">No se pudo cargar la ficha en Internet Archive.</p>
              ) : meta === null ? (
                <div className="space-y-2"><div className="h-4 w-2/3 animate-pulse rounded bg-white/5" /><div className="h-4 animate-pulse rounded bg-white/5" /><div className="h-4 w-4/5 animate-pulse rounded bg-white/5" /><div className="h-4 w-1/2 animate-pulse rounded bg-white/5" /></div>
              ) : (
                <>
                  <p className="thin-scroll max-h-36 overflow-y-auto text-[11px] leading-relaxed text-slate-300">{meta.description || "Sin sinopsis disponible en el archivo."}</p>
                  <p className="text-[9px] text-slate-600">{meta.downloads > 0 ? `${meta.downloads.toLocaleString("es-ES")} descargas` : "Colección pública"}{meta.videoFile ? ` · ${meta.videoFile.format}${meta.videoFile.sizeMb ? ` · ${meta.videoFile.sizeMb} MB` : ""}` : ""}</p>
                  <div className="mt-auto flex flex-wrap items-center gap-2 pt-2">
                    {meta.videoFile ? (
                      <button onClick={() => { setPlaying(true); onMarkWatched(); }} className="grad-btn flex h-12 items-center gap-2 rounded-xl px-5 text-sm font-black text-white"><Play size={17} fill="currentColor" /> Reproducir gratis</button>
                    ) : (
                      <span className="rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-[10px] font-bold text-slate-400">Item sin archivo de vídeo reproducible</span>
                    )}
                    <a href={archiveItemUrl(meta.identifier)} target="_blank" rel="noopener noreferrer" className="ghost-btn flex h-12 items-center gap-2 rounded-xl px-4 text-[10px] font-bold text-slate-200">archive.org <ExternalLink size={12} /></a>
                    <button onClick={async () => { const text = `${meta.title} (${meta.year ?? "clásica"}) — gratis en TV LO3`; try { if (navigator.share) await navigator.share({ title: meta.title, text, url: archiveItemUrl(meta.identifier) }); else { await navigator.clipboard.writeText(`${text} ${archiveItemUrl(meta.identifier)}`); window.alert("Copiado al portapapeles"); } } catch { /* cancelado */ } }} className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/12 bg-white/5 text-slate-300 transition-transform hover:scale-105 hover:text-white" aria-label="Compartir película"><Share2 size={17} /></button>
                  </div>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ══════════ Película gratis del día (determinista por fecha) ══════════ */
function FeaturedOfDay({ onOpen, pm }: { onOpen: (d: ArchiveDoc) => void; pm: boolean }) {
  const [doc, setDoc] = useState<ArchiveDoc | null>(null);
  useEffect(() => {
    let alive = true;
    const dayOfYear = Math.floor(Date.now() / 86400000);
    searchArchive("movies", "", (dayOfYear % 40) + 1)
      .then(({ docs }) => { if (alive && docs.length) setDoc(docs[dayOfYear % docs.length]); })
      .catch(() => {});
    return () => { alive = false; };
  }, []);
  if (!doc) return null;
  return (
    <button onClick={() => onOpen(doc)} className="relative h-20 shrink-0 overflow-hidden rounded-2xl border border-amber-400/30 text-left transition-all hover:border-amber-400/60 sm:h-24">
      {!pm
        ? <img src={archiveThumb(doc.identifier)} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover object-[50%_20%]" onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")} />
        : <div className="absolute inset-0" style={{ background: `linear-gradient(120deg, hsl(${hueOf(doc.identifier)} 55% 35%), hsl(${(hueOf(doc.identifier) + 45) % 360} 60% 14%))` }} />}
      <div className="absolute inset-0 bg-gradient-to-r from-[#0b1130]/95 via-[#0b1130]/60 to-transparent" />
      <span className="relative flex h-full max-w-md flex-col justify-center gap-0.5 p-3 sm:p-4">
        <span className="flex items-center gap-1.5 text-[8px] font-black uppercase tracking-[0.25em] text-amber-300"><CalendarDays size={10} /> La película del día</span>
        <span className="line-clamp-1 font-display text-sm font-black text-white sm:text-base">{doc.title}</span>
        <span className="text-[8px] font-bold uppercase tracking-wider text-slate-400">{doc.year} · Dominio público · pulsa para reproducir</span>
      </span>
    </button>
  );
}
