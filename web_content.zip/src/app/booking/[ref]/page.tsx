import { notFound } from "next/navigation";
import TicketView from "@/components/TicketView";
import { getBookingByRef } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function BookingPage({ params }: { params: Promise<{ ref: string }> }) {
  const { ref } = await params;
  const row = await getBookingByRef(ref.toUpperCase());
  if (!row) notFound();
  const { booking, attraction } = row;
  return (
    <TicketView
      data={{
        ref: booking.ref,
        name: booking.name,
        visitDate: booking.visitDate,
        tickets: booking.tickets,
        total: booking.total,
        attraction: {
          slug: attraction.slug,
          nameEn: attraction.nameEn,
          nameAr: attraction.nameAr,
          cityEn: attraction.cityEn,
          cityAr: attraction.cityAr,
          countryCode: attraction.countryCode,
          image: attraction.image,
        },
      }}
    />
  );
}
