import { redirect } from "next/navigation";
import AuthCard from "@/components/AuthCard";
import { getSessionUser } from "@/lib/auth/session";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function SignupPage() {
  const user = await getSessionUser();
  if (user) redirect("/home");
  const settings = await getSettings();
  return (
    <>
      {!settings.signupEnabled ? (
        <p className="mx-auto max-w-md px-4 pt-6 text-center text-sm text-amber-200">
          Sign ups are temporarily closed. Please check back soon.
        </p>
      ) : null}
      <AuthCard mode="signup" />
    </>
  );
}
