"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { ArrowLeft, CalendarCheck, Clock, MessageCircle, Phone, Wallet } from "lucide-react";
import { useI18n, useSite } from "@/components/providers";
import { Alert, buttonClass, Card, CardSkeleton, ErrorState, ServiceIcon } from "@/components/ui";
import { api } from "@/lib/api-client";
import type { ServiceDTO } from "@/lib/types";
import { formatPrice, loc } from "@/lib/utils";

export default function ServiceDetailPage() {
  const { t, locale } = useI18n();
  const { whatsapp, callLink, settings } = useSite();
  const { slug } = useParams<{ slug: string }>();
  const [service, setService] = useState<ServiceDTO | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let alive = true;
    setError(false);
    setNotFound(false);
    api<ServiceDTO>(`/api/services/${encodeURIComponent(slug)}`)
      .then((s) => alive && setService(s))
      .catch((err: { status?: number }) => {
        if (!alive) return;
        if (err?.status === 404) setNotFound(true);
        else setError(true);
      });
    return () => {
      alive = false;
    };
  }, [slug, reloadKey]);

  if (error) return <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />;
  if (notFound)
    return (
      <Card className="text-center">
        <p className="text-slate-700">{t("svc.notFound")}</p>
        <Link href="/services" className={buttonClass("primary", "md", "mt-4")}>
          {t("common.back")}
        </Link>
      </Card>
    );
  if (!service)
    return (
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <CardSkeleton lines={3} />
          <CardSkeleton lines={3} />
        </div>
        <CardSkeleton lines={4} />
      </div>
    );

  const name = loc(service.name, locale);
  const price = formatPrice(service.priceMad, locale);
  const message = t("wa.bookService", { service: name, price });

  return (
    <div>
      <Link href="/services" className="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-teal-700">
        <ArrowLeft className="h-4 w-4 rtl:rotate-180" />
        {t("svc.title")}
      </Link>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section className="rounded-3xl bg-gradient-to-br from-sky-50 via-white to-teal-50 p-6 ring-1 ring-sky-100 sm:p-8">
            <div className="flex items-start gap-4">
              <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 to-sky-500 text-white shadow-lg shadow-teal-500/25">
                <ServiceIcon name={service.icon} className="h-8 w-8" />
              </span>
              <h1 className="text-2xl font-extrabold leading-tight text-slate-900 sm:text-3xl">{name}</h1>
            </div>
            <p className="mt-5 text-base leading-relaxed text-slate-700">{loc(service.description, locale)}</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <span className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-base font-bold text-slate-900 shadow-sm ring-1 ring-slate-100">
                <Wallet className="h-5 w-5 text-teal-600" />
                {price}
              </span>
              <span className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-slate-900 shadow-sm ring-1 ring-slate-100">
                <Clock className="h-4 w-4 text-sky-600" />
                {service.durationMinutes} {t("common.minutes")}
              </span>
            </div>
          </section>

          <Alert tone="info">
            <p>{t("book.estimateNote")}</p>
            <p className="mt-1">{t("book.locationNote")}</p>
          </Alert>
        </div>

        <aside className="lg:sticky lg:top-8 lg:self-start">
          <Card className="space-y-5">
            <div>
              <p className="text-sm text-slate-500">{t("common.price")}</p>
              <p className="text-3xl font-extrabold text-slate-900">{price}</p>
              <p className="mt-1 text-sm text-slate-500">
                {t("common.duration")}: {service.durationMinutes} {t("common.minutes")}
              </p>
            </div>
            <a href={whatsapp(message)} target="_blank" rel="noopener noreferrer" className={buttonClass("whatsapp", "lg", "w-full")}>
              <MessageCircle className="h-5 w-5" />
              {t("btn.bookWhatsapp")}
            </a>
            <Link href={`/book?service=${service.slug}`} className={buttonClass("primary", "lg", "w-full")}>
              <CalendarCheck className="h-5 w-5" />
              {t("btn.book")}
            </Link>
            <a href={callLink} className={buttonClass("outline", "lg", "w-full")}>
              <Phone className="h-5 w-5" />
              {t("btn.callNow")} · <span dir="ltr">{settings.contact.phoneDisplay}</span>
            </a>
          </Card>
        </aside>
      </div>
    </div>
  );
}
