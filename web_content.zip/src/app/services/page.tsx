"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Search, Stethoscope } from "lucide-react";
import { useI18n } from "@/components/providers";
import { ServiceCard } from "@/components/cards";
import { CardSkeleton, Chip, EmptyState, ErrorState, Input, PageHeader } from "@/components/ui";
import { api } from "@/lib/api-client";
import { SERVICE_CATEGORIES } from "@/lib/constants";
import type { ServiceDTO } from "@/lib/types";

export default function ServicesPage() {
  return (
    <Suspense fallback={<div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"><CardSkeleton /><CardSkeleton /><CardSkeleton /></div>}>
      <ServicesContent />
    </Suspense>
  );
}

function ServicesContent() {
  const { t } = useI18n();
  const params = useSearchParams();
  const [q, setQ] = useState(params.get("q") ?? "");
  const [debouncedQ, setDebouncedQ] = useState(q);
  const [category, setCategory] = useState("");
  const [services, setServices] = useState<ServiceDTO[] | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    const id = window.setTimeout(() => setDebouncedQ(q.trim()), 300);
    return () => window.clearTimeout(id);
  }, [q]);

  useEffect(() => {
    let alive = true;
    setError(false);
    const qs = new URLSearchParams();
    if (debouncedQ) qs.set("q", debouncedQ);
    if (category) qs.set("category", category);
    api<{ services: ServiceDTO[] }>(`/api/services?${qs.toString()}`)
      .then((r) => alive && setServices(r.services))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [debouncedQ, category, reloadKey]);

  return (
    <div>
      <PageHeader title={t("svc.title")} subtitle={t("svc.subtitle")} />

      <div className="mb-8 space-y-4 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-sky-100 sm:p-5">
        <div className="relative">
          <Search className="pointer-events-none absolute start-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
          <Input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("svc.searchPlaceholder")} aria-label={t("common.search")} className="ps-11" />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          <Chip active={category === ""} onClick={() => setCategory("")}>
            {t("svc.allCategories")}
          </Chip>
          {SERVICE_CATEGORIES.map((c) => (
            <Chip key={c} active={category === c} onClick={() => setCategory(c)}>
              {t(`scat.${c}`)}
            </Chip>
          ))}
        </div>
      </div>

      {error ? (
        <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
      ) : !services ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <CardSkeleton key={i} lines={3} />
          ))}
        </div>
      ) : services.length === 0 ? (
        <EmptyState icon={Stethoscope} title={t("svc.noServices")} />
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (
            <ServiceCard key={s.id} service={s} />
          ))}
        </div>
      )}
    </div>
  );
}
