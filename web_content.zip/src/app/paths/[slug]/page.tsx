import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { LessonList } from "@/components/lesson-list";
import { Quiz } from "@/components/quiz";
import { PATHS, getPath } from "@/data/paths";
import { toArabicDigits } from "@/lib/site";

type Params = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return PATHS.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const path = getPath(slug);
  if (!path) return { title: "مسار غير موجود" };
  return { title: path.title, description: path.description };
}

export default async function PathPage({ params }: Params) {
  const { slug } = await params;
  const path = getPath(slug);
  if (!path) notFound();

  const index = PATHS.findIndex((p) => p.slug === path.slug);
  const nextPath = PATHS[index + 1];

  return (
    <main>
      <PageHero
        eyebrow={`${path.stageLabel} · ${toArabicDigits(path.lessons.length)} دروس · اختبار`}
        title={path.title}
        description={path.description}
      >
        <Link
          href="/paths"
          className="inline-flex items-center gap-2 rounded-full border border-gold/50 px-6 py-3 text-sm text-gold-light transition-all hover:bg-gold hover:text-navy"
        >
          <ArrowRight className="size-4" aria-hidden="true" />
          جميع المسارات
        </Link>
      </PageHero>

      <section className="relative bg-ivory py-20 sm:py-24">
        <div className="mx-auto grid max-w-7xl gap-8 px-5 lg:grid-cols-[1.25fr_1fr] lg:px-8">
          <div className="rounded-[2rem] border border-border bg-stone/60 p-6 sm:p-10">
            <LessonList pathSlug={path.slug} lessons={path.lessons} variant="full" />
          </div>

          <div className="space-y-8">
            <Quiz key={path.slug} title={path.title} questions={path.quiz} />

            {nextPath && (
              <Link
                href={`/paths/${nextPath.slug}`}
                className="group flex items-center justify-between gap-4 rounded-3xl border border-border bg-card p-6 transition-all hover:-translate-y-0.5 hover:border-gold/60"
              >
                <div>
                  <p className="text-xs text-gold">المسار التالي · {nextPath.stageLabel}</p>
                  <p className="mt-1 font-serif text-2xl font-bold text-navy">{nextPath.title}</p>
                </div>
                <ArrowRight className="size-5 rotate-180 text-gold transition-transform group-hover:-translate-x-1" aria-hidden="true" />
              </Link>
            )}
          </div>
        </div>
      </section>
    </main>
  );
}
