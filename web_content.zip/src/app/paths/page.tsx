import type { Metadata } from "next";
import type * as React from "react";
import { PageHero } from "@/components/page-hero";
import { PathCard } from "@/components/path-card";
import { PATHS } from "@/data/paths";

export const metadata: Metadata = {
  title: "المسارات التعليمية",
  description: "دروس متدرجة في العقيدة والعبادات والأخلاق وعلوم القرآن، مع اختبارات تفاعلية.",
};

export default function PathsPage() {
  return (
    <main>
      <PageHero
        eyebrow="الرحلة التعليمية"
        title={
          <>
            درجاتٌ نحو <span className="text-gold-gradient">الفهم العميق</span>
          </>
        }
        description="اختر مسارك، تقدّم في دروسه خطوة بخطوة، ثم اختبر فهمك. يُحفظ تقدّمك تلقائياً في متصفحك."
      />

      <section className="relative bg-ivory py-20 sm:py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <ul className="grid gap-6 md:grid-cols-2">
            {PATHS.map((path, i) => (
              <li key={path.slug} className="reveal" style={{ "--reveal-delay": `${i * 90}ms` } as React.CSSProperties}>
                <PathCard path={path} index={i} />
              </li>
            ))}
          </ul>
        </div>
      </section>
    </main>
  );
}
