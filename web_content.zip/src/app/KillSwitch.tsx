import { useEffect, useState } from "react";
import { ExternalLink, ShieldCheck, X } from "lucide-react";

/**
 * Kill Switch (TV LO3 Secure) — when enabled, ANY external link clicked inside
 * the app is intercepted and routed through an interstitial so no request ever
 * leaves the device without the user's explicit confirmation.
 * Reads localStorage at click time: always in sync, zero re-render cost.
 */
export default function KillSwitch() {
  const [pending, setPending] = useState<{ host: string; href: string } | null>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      let enabled = false;
      try { enabled = window.localStorage.getItem("lo3-killswitch") === "true"; } catch { return; }
      if (!enabled) return;
      const a = (e.target as HTMLElement | null)?.closest?.("a");
      if (!a) return;
      const href = a.getAttribute("href") || "";
      if (!/^https?:\/\//i.test(href)) return;
      let host = "";
      try { host = new URL(href).hostname; } catch { return; }
      e.preventDefault();
      e.stopPropagation();
      setPending({ host, href });
    };
    document.addEventListener("click", onClick, true);
    return () => document.removeEventListener("click", onClick, true);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setPending(null); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  /* Wipe-on-exit — si el usuario lo activa, la sesión se limpia al salir/recargar */
  useEffect(() => {
    const onUnload = () => {
      try {
        if (window.localStorage.getItem("lo3-wipe-on-exit") !== "true") return;
        ["lo3-continue", "lo3-favs", "lo3-tv-last", "lo3-sports-favs", "lo3-neon-best", "lo3-neon-ach", "lo3-search-history"].forEach((k) => window.localStorage.removeItem(k));
      } catch { /* noop */ }
    };
    window.addEventListener("beforeunload", onUnload);
    return () => window.removeEventListener("beforeunload", onUnload);
  }, []);

  if (!pending) return null;

  return (
    <div role="dialog" aria-modal="true" aria-label="Kill Switch: abrir enlace externo" className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <button aria-label="Cancelar" onClick={() => setPending(null)} className="absolute inset-0 cursor-default bg-black/70 backdrop-blur-sm" />
      <div className="relative w-full max-w-md rounded-2xl border border-emerald-400/30 bg-[#061a12] p-6 text-center shadow-2xl">
        <button onClick={() => setPending(null)} aria-label="Cerrar" className="absolute right-3 top-3 rounded-lg p-1.5 text-slate-500 hover:text-white"><X size={17} /></button>
        <ShieldCheck size={40} className="mx-auto text-emerald-400" />
        <h2 className="mt-3 font-display text-xl font-black text-white">Kill Switch activo</h2>
        <p className="mt-1 text-xs text-slate-400">TV LO3 ha detenido esta salida para que decidas tú:</p>
        <p className="mx-auto mt-3 max-w-full truncate rounded-lg border border-white/10 bg-black/40 px-3 py-2 font-mono text-[11px] text-emerald-200" dir="ltr">{pending.host}</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button onClick={() => setPending(null)} className="h-12 rounded-xl border border-emerald-400/40 bg-emerald-400/15 text-xs font-black uppercase tracking-wider text-emerald-300 transition-colors hover:bg-emerald-400/25">Bloquear salida</button>
          <a href={pending.href} target="_blank" rel="noopener noreferrer" onClick={() => setPending(null)} className="flex h-12 items-center justify-center gap-1.5 rounded-xl border border-white/15 bg-white/5 text-xs font-bold text-slate-200 transition-colors hover:border-white/30 hover:text-white">Abrir <ExternalLink size={12} /></a>
        </div>
        <p className="mt-3 text-[9px] text-slate-600">Tu IP y petición NO se envían hasta que pulses «Abrir». Nada sale sin tu confirmación.</p>
      </div>
    </div>
  );
}
