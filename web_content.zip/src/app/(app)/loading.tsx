export default function AppLoading() {
  return (
    <div className="space-y-4" aria-busy="true">
      <div className="skeleton h-32 w-full" />
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="skeleton h-24" />
        <div className="skeleton h-24" />
        <div className="skeleton h-24" />
      </div>
      <div className="skeleton h-40 w-full" />
    </div>
  );
}
