import { redirect } from "next/navigation";
import GeneratorPanel from "@/components/GeneratorPanel";
import ToolTabs from "@/components/ToolTabs";
import { getSessionUser } from "@/lib/auth/session";
import { getPreferences } from "@/lib/preferences";
import { getSettings } from "@/lib/settings";
import { getUsageSummary } from "@/lib/usage";
import { getToolDefinitions, TOOL_IDS, type ToolId } from "@/lib/ai/tools";

export const dynamic = "force-dynamic";

const CREATE_TOOLS: ToolId[] = ["titles", "hooks", "scripts", "captions", "hashtags", "thumbnail"];

export default async function CreatePage({ searchParams }: { searchParams: Promise<{ tool?: string }> }) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const settings = await getSettings();
  const params = await searchParams;
  const requested = (params.tool ?? "titles") as ToolId;
  const tool: ToolId = CREATE_TOOLS.includes(requested) ? requested : "titles";

  const tools = getToolDefinitions(settings.niches).filter((t) => CREATE_TOOLS.includes(t.id));
  const toolDef = tools.find((t) => t.id === tool)!;

  const [usage, prefs] = await Promise.all([getUsageSummary(user.id, user.planKey), getPreferences(user.id)]);

  return (
    <div>
      <ToolTabs tools={tools} active={tool} />
      <GeneratorPanel
        tool={tool}
        toolDef={toolDef}
        planKey={user.planKey}
        usage={{ remaining: usage.remaining, limit: usage.limit, used: usage.used, planName: usage.planName }}
        defaults={{
          platform: prefs.defaultPlatform,
          niche: prefs.defaultNiche,
          tone: prefs.defaultTone,
        }}
      />
    </div>
  );
}
