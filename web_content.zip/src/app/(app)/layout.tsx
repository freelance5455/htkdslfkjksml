import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import AppShell from "@/components/AppShell";
import { getSessionUser } from "@/lib/auth/session";
import { getSettings } from "@/lib/settings";
import { getUsageSummary } from "@/lib/usage";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const [usage, settings] = await Promise.all([getUsageSummary(user.id, user.planKey), getSettings()]);

  return (
    <AppShell
      user={{ id: user.id, email: user.email, name: user.name, role: user.role, planKey: user.planKey }}
      usage={{ remaining: usage.remaining, limit: usage.limit, planName: usage.planName }}
      announcement={settings.announcement}
    >
      {children}
    </AppShell>
  );
}
