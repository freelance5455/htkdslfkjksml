import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { contentCalendars } from "@/db/schema";
import CalendarList, { type CalendarRow } from "@/components/CalendarList";
import GeneratorPanel from "@/components/GeneratorPanel";
import { getSessionUser } from "@/lib/auth/session";
import { getPreferences } from "@/lib/preferences";
import { getSettings } from "@/lib/settings";
import { getUsageSummary } from "@/lib/usage";
import { getToolDefinitions } from "@/lib/ai/tools";

export const dynamic = "force-dynamic";

export default async function CalendarPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const settings = await getSettings();
  const toolDef = getToolDefinitions(settings.niches).find((t) => t.id === "calendar")!;
  const [usage, prefs, rows] = await Promise.all([
    getUsageSummary(user.id, user.planKey),
    getPreferences(user.id),
    db
      .select()
      .from(contentCalendars)
      .where(eq(contentCalendars.userId, user.id))
      .orderBy(desc(contentCalendars.createdAt))
      .limit(30),
  ]);

  const initial: CalendarRow[] = rows.map((r) => ({
    id: r.id,
    name: r.name,
    planLength: r.planLength,
    createdAt: r.createdAt.toISOString(),
    days: Array.isArray(r.days) ? r.days : [],
  }));

  return (
    <div className="space-y-5">
      <GeneratorPanel
        tool="calendar"
        toolDef={toolDef}
        planKey={user.planKey}
        usage={{ remaining: usage.remaining, limit: usage.limit, used: usage.used, planName: usage.planName }}
        defaults={{ platform: prefs.defaultPlatform, niche: prefs.defaultNiche, tone: prefs.defaultTone }}
      />
      <section>
        <h2 className="mb-2 px-1 text-sm font-semibold uppercase tracking-wider text-[color:var(--muted)]">
          Saved plans
        </h2>
        <CalendarList initial={initial} />
      </section>
    </div>
  );
}
