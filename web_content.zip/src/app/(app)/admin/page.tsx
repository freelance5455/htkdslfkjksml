import { redirect } from "next/navigation";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { plans } from "@/db/schema";
import AdminDashboard from "@/components/AdminDashboard";
import { getSessionUser } from "@/lib/auth/session";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "admin") redirect("/home");

  const [settings, planRows] = await Promise.all([
    getSettings(),
    db.select().from(plans).orderBy(asc(plans.sortOrder)),
  ]);

  return (
    <AdminDashboard
      settings={{
        niches: settings.niches,
        features: settings.features,
        freeLimitBonus: settings.freeLimitBonus,
        burstLimitPerMinute: settings.burstLimitPerMinute,
        signupEnabled: settings.signupEnabled,
        announcement: settings.announcement,
        brandName: settings.brandName,
      }}
      plans={planRows.map((p) => ({
        id: p.id,
        key: p.key,
        name: p.name,
        tagline: p.tagline,
        priceCents: p.priceCents,
        currency: p.currency,
        interval: p.interval,
        monthlyLimit: p.monthlyLimit,
        features: Array.isArray(p.features) ? p.features : [],
        sortOrder: p.sortOrder,
        isActive: p.isActive,
      }))}
    />
  );
}
