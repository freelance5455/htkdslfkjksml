import { redirect } from "next/navigation";
import GeneratorPanel from "@/components/GeneratorPanel";
import { getSessionUser } from "@/lib/auth/session";
import { getPreferences } from "@/lib/preferences";
import { getSettings } from "@/lib/settings";
import { getUsageSummary } from "@/lib/usage";
import { getToolDefinitions } from "@/lib/ai/tools";

export const dynamic = "force-dynamic";

export default async function IdeasPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const settings = await getSettings();
  const toolDef = getToolDefinitions(settings.niches).find((t) => t.id === "ideas")!;
  const [usage, prefs] = await Promise.all([getUsageSummary(user.id, user.planKey), getPreferences(user.id)]);

  return (
    <div className="space-y-4">
      <div className="grid gap-2 sm:grid-cols-3">
        {settings.niches.slice(0, 11).map((niche) => (
          <div key={niche} className="card px-3 py-2 text-xs font-medium text-[color:var(--muted)]">
            {niche}
          </div>
        ))}
      </div>
      <GeneratorPanel
        tool="ideas"
        toolDef={toolDef}
        planKey={user.planKey}
        usage={{ remaining: usage.remaining, limit: usage.limit, used: usage.used, planName: usage.planName }}
        defaults={{ platform: prefs.defaultPlatform, niche: prefs.defaultNiche, tone: prefs.defaultTone }}
      />
    </div>
  );
}
