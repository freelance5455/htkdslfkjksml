import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { savedItems } from "@/db/schema";
import BillingActions from "@/components/BillingActions";
import LibraryList, { type LibraryRow } from "@/components/LibraryList";
import ProfileForm from "@/components/ProfileForm";
import SignOutButton from "@/components/SignOutButton";
import { getSessionUser } from "@/lib/auth/session";
import { getActiveSubscription, getPlan } from "@/lib/plans";
import { getPreferences } from "@/lib/preferences";
import { getSettings } from "@/lib/settings";
import { getUsageStats, getUsageSummary, nextReset } from "@/lib/usage";
import { toolById } from "@/lib/ai/tools";

export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const [usage, stats, plan, subscription, prefs, settings, library] = await Promise.all([
    getUsageSummary(user.id, user.planKey),
    getUsageStats(user.id),
    getPlan(user.planKey),
    getActiveSubscription(user.id),
    getPreferences(user.id),
    getSettings(),
    db
      .select()
      .from(savedItems)
      .where(eq(savedItems.userId, user.id))
      .orderBy(desc(savedItems.createdAt))
      .limit(60),
  ]);

  const initial: LibraryRow[] = library.map((item) => ({
    id: item.id,
    tool: item.tool,
    title: item.title,
    body: item.body,
    createdAt: item.createdAt.toISOString(),
  }));

  const isPaid = user.planKey !== "free";

  return (
    <div className="space-y-5">
      <section className="card p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold">{user.name || "Creator"}</h1>
            <p className="text-sm text-[color:var(--muted)]">{user.email}</p>
            <p className="mt-1 text-xs text-[color:var(--muted)]">
              Member since {new Date(user.createdAt).toLocaleDateString()}
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <span className="chip border-violet-400/30 bg-violet-500/15 text-violet-100">
              {plan?.name ?? "Free"} plan
            </span>
          <BillingActions planKey={user.planKey} isAdmin={user.role === "admin"} />
          </div>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-2">
        <div className="card p-4">
          <p className="text-[0.7rem] uppercase tracking-wider text-[color:var(--muted)]">Usage this month</p>
          <p className="mt-1 text-2xl font-bold">
            {usage.used}
            <span className="text-sm font-medium text-[color:var(--muted)]"> / {usage.limit} credits</span>
          </p>
          <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-violet-400 to-cyan-300"
              style={{ width: `${usage.limit ? Math.min(100, (usage.used / usage.limit) * 100) : 100}%` }}
            />
          </div>
          <p className="mt-2 text-xs text-[color:var(--muted)]">
            Resets on {new Date(nextReset()).toLocaleDateString(undefined, { month: "long", day: "numeric" })}
          </p>
          <ul className="mt-3 space-y-1 text-xs text-[color:var(--muted)]">
            {stats.length === 0 ? <li>No usage recorded yet.</li> : null}
            {stats
              .sort((a, b) => b.total - a.total)
              .slice(0, 5)
              .map((row) => (
                <li key={row.tool} className="flex justify-between gap-2">
                  <span>{toolById(row.tool, settings.niches)?.name ?? row.tool}</span>
                  <span className="text-white/80">{row.total}</span>
                </li>
              ))}
          </ul>
        </div>

        <div className="card p-4">
          <p className="text-[0.7rem] uppercase tracking-wider text-[color:var(--muted)]">Subscription</p>
          {subscription ? (
            <div className="mt-1 space-y-1 text-sm">
              <p className="font-semibold capitalize">{subscription.planKey}</p>
              <p className="text-[color:var(--muted)]">
                Status: <span className="text-emerald-300">{subscription.status}</span>
              </p>
              <p className="text-[color:var(--muted)]">
                Renews {new Date(subscription.currentPeriodEnd).toLocaleDateString()} ·{" "}
                {(subscription.amountCents / 100).toFixed(2)} {plan?.currency ?? "USD"}/mo
              </p>
            </div>
          ) : (
            <div className="mt-1 space-y-2 text-sm">
              <p className="font-semibold">Free</p>
              <p className="text-[color:var(--muted)]">
                {usage.limit} credits per month. Upgrade any time — your saved content stays.
              </p>
              <Link href="/pricing" className="btn btn-primary btn-sm">
                Compare plans
              </Link>
            </div>
          )}
          <div className="mt-3 space-y-1 text-xs text-[color:var(--muted)]">
            {(plan?.features ?? []).map((feature) => (
              <p key={feature}>✓ {feature}</p>
            ))}
          </div>
        </div>
      </section>

      <ProfileForm
        name={user.name}
        email={user.email}
        preferences={{ defaultPlatform: prefs.defaultPlatform, defaultNiche: prefs.defaultNiche, defaultTone: prefs.defaultTone }}
        niches={settings.niches}
      />

      <section>
        <h2 className="mb-2 px-1 text-sm font-semibold uppercase tracking-wider text-[color:var(--muted)]">
          Saved content
        </h2>
        <LibraryList initial={initial} />
      </section>

      <SignOutButton />
    </div>
  );
}
