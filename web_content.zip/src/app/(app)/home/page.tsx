import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { generations } from "@/db/schema";
import { getSessionUser } from "@/lib/auth/session";
import { getPlan } from "@/lib/plans";
import { getUsageSummary, getUsageStats, nextReset } from "@/lib/usage";
import { getSettings } from "@/lib/settings";
import { toolById } from "@/lib/ai/tools";

export const dynamic = "force-dynamic";

const QUICK = [
  { href: "/create?tool=titles", label: "Viral titles", emoji: "🎯" },
  { href: "/create?tool=hooks", label: "3-second hooks", emoji: "🪝" },
  { href: "/create?tool=scripts", label: "Write a script", emoji: "🎬" },
  { href: "/create?tool=captions", label: "Captions", emoji: "✍️" },
  { href: "/create?tool=hashtags", label: "Hashtags", emoji: "#️⃣" },
  { href: "/create?tool=thumbnail", label: "Thumbnail text", emoji: "🖼️" },
  { href: "/ideas", label: "Content ideas", emoji: "💡" },
  { href: "/calendar", label: "Post calendar", emoji: "🗓️" },
  { href: "/analyze", label: "Analyze content", emoji: "🔍" },
];

function timeAgo(date: Date): string {
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.round(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

export default async function HomePage() {
  const user = await getSessionUser();
  const settings = await getSettings();
  if (!user) return null;

  const [usage, stats, plan, recent] = await Promise.all([
    getUsageSummary(user.id, user.planKey),
    getUsageStats(user.id),
    getPlan(user.planKey),
    db
      .select({
        id: generations.id,
        tool: generations.tool,
        topic: generations.topic,
        niche: generations.niche,
        createdAt: generations.createdAt,
        output: generations.output,
      })
      .from(generations)
      .where(eq(generations.userId, user.id))
      .orderBy(desc(generations.createdAt))
      .limit(6),
  ]);

  const usedPct = usage.limit ? Math.min(100, Math.round((usage.used / usage.limit) * 100)) : 100;
  const isFree = user.planKey === "free";
  const resets = new Date(nextReset());

  return (
    <div className="space-y-5">
      <section className="card overflow-hidden p-5">
        <p className="text-xs uppercase tracking-[0.2em] text-[color:var(--muted)]">Welcome back</p>
        <h1 className="mt-1 text-2xl font-black leading-tight sm:text-3xl">
          {user.name ? `Hey ${user.name.split(" ")[0]}, ` : "Hey creator, "}
          <span className="gradient-text">create better content in minutes.</span>
        </h1>
        <p className="mt-2 max-w-xl text-sm text-[color:var(--muted)]">
          Nine AI tools for titles, hooks, scripts, captions, hashtags, thumbnails, ideas, calendars and analysis — built
          for YouTube, Shorts, TikTok and Reels.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Link href="/create?tool=titles" className="btn btn-primary">
            ✨ Start creating
          </Link>
          <Link href="/ideas" className="btn btn-ghost">
            💡 Get ideas
          </Link>
          {isFree ? (
            <Link href="/pricing" className="btn btn-ghost">
              Upgrade plan
            </Link>
          ) : null}
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-3">
        <div className="card p-4">
          <p className="text-[0.7rem] uppercase tracking-wider text-[color:var(--muted)]">{plan?.name ?? "Free"} plan</p>
          <p className="mt-1 text-2xl font-bold">
            {usage.remaining}
            <span className="text-sm font-medium text-[color:var(--muted)]">/{usage.limit} left</span>
          </p>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-gradient-to-r from-violet-400 to-cyan-300" style={{ width: `${100 - usedPct}%` }} />
          </div>
          <p className="mt-2 text-xs text-[color:var(--muted)]">
            Resets {resets.toLocaleDateString(undefined, { month: "short", day: "numeric" })}
          </p>
        </div>
        <div className="card p-4">
          <p className="text-[0.7rem] uppercase tracking-wider text-[color:var(--muted)]">Generations this month</p>
          <p className="mt-1 text-2xl font-bold">{usage.used}</p>
          <p className="mt-2 text-xs text-[color:var(--muted)]">
            {stats.length ? `Top tool: ${toolById(stats.sort((a, b) => b.total - a.total)[0].tool, settings.niches)?.name ?? stats[0].tool}` : "No generations yet"}
          </p>
        </div>
        <div className="card p-4">
          <p className="text-[0.7rem] uppercase tracking-wider text-[color:var(--muted)]">Subscription</p>
          <p className="mt-1 text-2xl font-bold capitalize">{user.planKey}</p>
          {isFree ? (
            <Link href="/pricing" className="btn btn-primary btn-sm mt-2">
              Upgrade for more
            </Link>
          ) : (
            <Link href="/profile" className="btn btn-ghost btn-sm mt-2">
              Manage billing
            </Link>
          )}
        </div>
      </section>

      <section>
        <h2 className="mb-2 px-1 text-sm font-semibold uppercase tracking-wider text-[color:var(--muted)]">Quick create</h2>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {QUICK.map((item) => (
            <Link key={item.href} href={item.href} className="card card-hover flex items-center gap-3 p-3">
              <span className="text-xl">{item.emoji}</span>
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <div className="mb-2 flex items-center justify-between px-1">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-[color:var(--muted)]">Recent generations</h2>
          <Link href="/profile" className="text-xs text-violet-300">
            View library →
          </Link>
        </div>
        {recent.length === 0 ? (
          <div className="card p-6 text-center">
            <p className="text-sm font-medium">Nothing generated yet</p>
            <p className="mt-1 text-sm text-[color:var(--muted)]">Start with a title — it takes about 10 seconds.</p>
            <Link href="/create?tool=titles" className="btn btn-primary btn-sm mt-3">
              Generate titles
            </Link>
          </div>
        ) : (
          <ul className="space-y-2">
            {recent.map((row) => {
              const def = toolById(row.tool, settings.niches);
              const preview =
                (row.topic as string) ||
                (typeof row.output === "object" && row.output ? Object.values(row.output)[0]?.toString().slice(0, 80) : "") ||
                "Saved generation";
              return (
                <li key={row.id}>
                  <Link href={`/create?tool=${row.tool}`} className="card card-hover flex items-center gap-3 p-3">
                    <span className="text-lg">{def?.emoji ?? "✨"}</span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{preview}</p>
                      <p className="text-xs text-[color:var(--muted)]">
                        {def?.name ?? row.tool} • {timeAgo(row.createdAt)}
                      </p>
                    </div>
                    <span className="text-[color:var(--muted)]">›</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
