import { redirect } from "next/navigation";
import GeneratorPanel from "@/components/GeneratorPanel";
import { getSessionUser } from "@/lib/auth/session";
import { getPreferences } from "@/lib/preferences";
import { getSettings } from "@/lib/settings";
import { getUsageSummary } from "@/lib/usage";
import { getToolDefinitions } from "@/lib/ai/tools";

export const dynamic = "force-dynamic";

export default async function AnalyzePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const settings = await getSettings();
  const toolDef = getToolDefinitions(settings.niches).find((t) => t.id === "analyze")!;
  const [usage, prefs] = await Promise.all([getUsageSummary(user.id, user.planKey), getPreferences(user.id)]);

  return (
    <GeneratorPanel
      tool="analyze"
      toolDef={toolDef}
      planKey={user.planKey}
      usage={{ remaining: usage.remaining, limit: usage.limit, used: usage.used, planName: usage.planName }}
      defaults={{ platform: prefs.defaultPlatform, niche: prefs.defaultNiche, tone: prefs.defaultTone }}
    />
  );
}
