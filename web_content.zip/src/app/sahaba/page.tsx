import type { Metadata } from "next";
import type * as React from "react";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { COMPANIONS } from "@/data/sahaba";
import { toArabicDigits } from "@/lib/site";

export const metadata: Metadata = {
  title: "قصص الصحابة",
  description: "سير مختصرة لأصحاب النبي ﷺ ومواقفهم الخالدة ودروسها.",
};

export default function SahabaPage() {
  return (
    <main>
      <PageHero
        eyebrow="نجوم الهداية"
        title={
          <>
            قصص <span className="text-gold-gradient">الصحابة</span>
          </>
        }
        description="سير مختصرة لأصحاب النبي ﷺ ومواقفهم الخالدة، وما نتعلمه من أخلاقهم وثباتهم وتضحياتهم."
      />

      <section className="relative bg-ivory py-20 sm:py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {COMPANIONS.map((c, i) => (
              <li key={c.slug} className="reveal" style={{ "--reveal-delay": `${(i % 3) * 90}ms` } as React.CSSProperties}>
                <Link
                  href={`/sahaba/${c.slug}`}
                  className="group relative flex h-full flex-col overflow-hidden rounded-[2rem] border border-border bg-card p-8 shadow-[0_30px_70px_-45px_rgba(23,36,58,0.55)] transition-all duration-500 hover:-translate-y-1 hover:border-gold/60 hover:shadow-[0_45px_90px_-40px_rgba(23,36,58,0.75)]"
                >
                  <div className="pattern-stars absolute inset-0 opacity-[0.05]" aria-hidden="true" />
                  <div className="relative flex items-center justify-between gap-4">
                    <span className="grid size-14 place-items-center rounded-2xl bg-navy font-serif text-2xl font-bold text-gold-light">
                      {toArabicDigits(i + 1)}
                    </span>
                    <span className="text-xs text-muted-foreground">{c.lifespan}</span>
                  </div>
                  <h2 className="relative mt-6 font-serif text-3xl font-bold text-navy">{c.name}</h2>
                  <p className="relative mt-1 text-sm text-gold">{c.epithet}</p>
                  <p className="relative mt-4 flex-1 leading-7 text-navy/65">{c.summary}</p>
                  <span className="relative mt-6 inline-flex items-center gap-2 text-sm font-medium text-royal transition-all group-hover:gap-3 group-hover:text-gold">
                    اقرأ سيرته <ArrowLeft className="size-4" aria-hidden="true" />
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </main>
  );
}
