import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Quote } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { COMPANIONS, getCompanion } from "@/data/sahaba";

type Params = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return COMPANIONS.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const companion = getCompanion(slug);
  if (!companion) return { title: "صحابي غير موجود" };
  return {
    title: companion.name,
    description: companion.summary,
  };
}

export default async function CompanionPage({ params }: Params) {
  const { slug } = await params;
  const companion = getCompanion(slug);
  if (!companion) notFound();

  return (
    <main>
      <PageHero eyebrow={companion.epithet} title={companion.name} description={companion.summary}>
        <span className="inline-flex items-center rounded-full border border-gold/40 bg-gold/10 px-5 py-2 text-sm text-gold-light">
          {companion.role}
        </span>
        <span className="inline-flex items-center rounded-full border border-white/15 px-5 py-2 text-sm text-ivory/70">
          {companion.lifespan}
        </span>
      </PageHero>

      <section className="relative bg-ivory py-20 sm:py-24">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 lg:grid-cols-[1.6fr_1fr] lg:px-8">
          <article className="rounded-[2rem] border border-border bg-card p-8 shadow-[0_30px_70px_-45px_rgba(23,36,58,0.55)] sm:p-12">
            <Quote className="size-10 text-gold/60" aria-hidden="true" />
            <div className="mt-6 space-y-6">
              {companion.story.map((paragraph, i) => (
                <p key={i} className="font-serif text-xl leading-[2.1] text-navy/85">
                  {paragraph}
                </p>
              ))}
            </div>
          </article>

          <aside className="space-y-6">
            <div className="relative overflow-hidden rounded-[2rem] bg-navy p-8 text-ivory shadow-[0_30px_70px_-40px_rgba(23,36,58,0.8)]">
              <div className="pattern-lattice absolute inset-0 rounded-[2rem] opacity-[0.06]" aria-hidden="true" />
              <h2 className="relative font-serif text-2xl font-bold text-gold-light">دروس مستفادة</h2>
              <ul className="relative mt-6 space-y-4">
                {companion.lessons.map((lesson) => (
                  <li key={lesson} className="flex items-start gap-3 leading-7 text-ivory/80">
                    <span className="mt-2.5 size-1.5 shrink-0 rounded-full bg-gold" aria-hidden="true" />
                    {lesson}
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-[2rem] border border-border bg-card p-8">
              <p className="text-sm text-gold">صحابة آخرون</p>
              <ul className="mt-4 space-y-3">
                {COMPANIONS.filter((c) => c.slug !== companion.slug)
                  .slice(0, 4)
                  .map((c) => (
                    <li key={c.slug}>
                      <Link
                        href={`/sahaba/${c.slug}`}
                        className="flex items-center justify-between rounded-xl px-3 py-2 text-navy transition-colors hover:bg-stone"
                      >
                        <span className="font-serif text-lg">{c.name}</span>
                        <ArrowLeft className="size-4 text-gold" aria-hidden="true" />
                      </Link>
                    </li>
                  ))}
              </ul>
              <Link href="/sahaba" className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-royal hover:text-gold">
                <ArrowLeft className="size-4" aria-hidden="true" />
                العودة إلى قصص الصحابة
              </Link>
            </div>
          </aside>
        </div>
      </section>
    </main>
  );
}
