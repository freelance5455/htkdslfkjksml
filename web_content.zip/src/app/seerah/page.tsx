import type { Metadata } from "next";
import { PageHero } from "@/components/page-hero";
import { SEERAH_STATIONS } from "@/data/seerah";
import { toArabicDigits } from "@/lib/site";

export const metadata: Metadata = {
  title: "السيرة النبوية",
  description: "محطات السيرة النبوية من المولد إلى الوفاة في خط زمني متتابع.",
};

export default function SeerahPage() {
  return (
    <main>
      <PageHero
        eyebrow="حياة خير البشر"
        title={
          <>
            السيرة <span className="text-gold-gradient">النبوية</span>
          </>
        }
        description="محطات السيرة من المولد إلى الوفاة في خط زمني متتابع، مع أبرز ما وقع فيها من أحداث ودروس."
      />

      <section className="relative bg-ivory py-20 sm:py-28">
        <div className="mx-auto max-w-5xl px-5 lg:px-8">
          <div className="relative">
            <div
              className="absolute inset-y-0 start-5 w-px bg-gradient-to-b from-transparent via-gold/50 to-transparent md:start-1/2 md:-translate-x-1/2"
              aria-hidden="true"
            />

            <ol className="space-y-12">
              {SEERAH_STATIONS.map((station, i) => {
                const onStart = i % 2 === 0;
                return (
                  <li
                    key={station.id}
                    className="reveal relative ps-16 md:grid md:grid-cols-2 md:gap-16 md:ps-0"
                  >
                    <span
                      className="absolute start-0 top-6 grid size-10 place-items-center rounded-full border-2 border-gold bg-ivory font-serif text-gold md:start-1/2 md:-translate-x-1/2"
                      aria-hidden="true"
                    >
                      {toArabicDigits(i + 1)}
                    </span>
                    <article
                      className={`rounded-3xl border border-border bg-card p-7 shadow-[0_30px_60px_-40px_rgba(23,36,58,0.5)] transition-all duration-500 hover:-translate-y-1 hover:border-gold/50 ${
                        onStart ? "md:col-start-1" : "md:col-start-2"
                      }`}
                    >
                      <p className="text-xs tracking-wide text-gold">{station.year}</p>
                      <h2 className="mt-2 font-serif text-2xl font-bold text-navy sm:text-3xl">{station.title}</h2>
                      <p className="mt-3 leading-8 text-navy/70">{station.description}</p>
                    </article>
                  </li>
                );
              })}
            </ol>
          </div>
        </div>
      </section>
    </main>
  );
}
