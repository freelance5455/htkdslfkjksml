"use client";

import dynamic from "next/dynamic";

// Client-only SPA — all engines rely on WebSockets / localStorage / SW.
const App = dynamic(() => import("@/App"), {
  ssr: false,
  loading: () => (
    <div className="flex min-h-screen items-center justify-center bg-[#0f172a]">
      <div className="text-center">
        <div className="mx-auto mb-3 h-10 w-10 animate-spin rounded-full border-2 border-emerald-500 border-t-transparent" />
        <p className="text-sm text-slate-400">טוען את מנוע המסחר…</p>
      </div>
    </div>
  ),
});

export default function Page() {
  return <App />;
}
