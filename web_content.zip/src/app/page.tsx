"use client";

import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  ErrorBoundary,
  LoadingSkeletonHe,
} from "@/components/ErrorBoundary";
import { useConnectionHealth } from "@/services/useConnectionHealth";
import {
  tradeTapeService,
  TradeTapeExecution,
  OrderBookLevel,
} from "@/services/tradeTapeService";
import {
  notificationsService,
  MobilePushAlert,
} from "@/services/notificationsService";
import {
  OHLCVCandle,
  CoinTechnicalAnalysis,
  formatPriceNumber,
} from "@/services/technicalEngine";
import { CandlestickTerminal } from "@/components/CandlestickTerminal";
import { CopyTradingModule } from "@/components/CopyTradingModule";
import {
  PaperTradingModule,
  PaperPositionItem,
  PaperLimitOrderItem,
} from "@/components/PaperTradingModule";
import { FinvizHeatmapModule } from "@/components/FinvizHeatmapModule";
import { MessariResearchModule } from "@/components/MessariResearchModule";
import {
  InvoappTaxModule,
  TaxInvoiceItem,
} from "@/components/InvoappTaxModule";
import {
  EvaluatorAgentPanel,
  EvaluatorLogRecord,
} from "@/components/EvaluatorAgentModal";
import {
  Radar,
  Users,
  Wallet,
  CandlestickChart,
  Flame,
  Database,
  Landmark,
  RefreshCw,
  Bell,
  Smartphone,
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  Target,
  ShieldAlert,
  Sparkles,
  X,
} from "lucide-react";

type MainTabKey =
  | "SIGNALS_ADVICE"
  | "COPY_TRADING"
  | "PAPER_TRADING"
  | "CHARTS_ORDERBOOK"
  | "MARKET_HEATMAP"
  | "DEEP_RESEARCH"
  | "FINANCE_TAX";

interface EnrichedCoinAnalysis extends CoinTechnicalAnalysis {
  nameHe: string;
  sectorHe: string;
  marketCapBillions: number;
  messariMetrics: {
    activeWallets24h: number;
    onChainVolume24hMillions: number;
    supplyInflationAnnualPct: number;
    githubCommits30d: number;
    activeDevelopers: number;
    nextUnlockSummaryHe: string;
    aiSummaryHe: string;
    institutionalRating: string;
  };
}

const NAVIGATION_TABS: Array<{
  key: MainTabKey;
  labelHe: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  {
    key: "SIGNALS_ADVICE",
    labelHe: "אותות ועצות מסחר",
    icon: Radar,
  },
  {
    key: "COPY_TRADING",
    labelHe: "חיקוי עסקאות סוחרים",
    icon: Users,
  },
  {
    key: "PAPER_TRADING",
    labelHe: "מסחר דמו / ניסיון",
    icon: Wallet,
  },
  {
    key: "CHARTS_ORDERBOOK",
    labelHe: "גרפים וספר פקודות",
    icon: CandlestickChart,
  },
  {
    key: "MARKET_HEATMAP",
    labelHe: "מפת שוק",
    icon: Flame,
  },
  {
    key: "DEEP_RESEARCH",
    labelHe: "מחקר עומק",
    icon: Database,
  },
  {
    key: "FINANCE_TAX",
    labelHe: "פיננסים, מיסוי ודוחות",
    icon: Landmark,
  },
];

export default function CryptoScannerTradingHubApp() {
  const [activeTab, setActiveTab] = useState<MainTabKey>("SIGNALS_ADVICE");
  const [focusSymbol, setFocusSymbol] = useState<string>("BTCUSDT");
  const [signalFilter, setSignalFilter] = useState<"ALL" | "LONG" | "SHORT">(
    "ALL"
  );

  // Market Proxy Data State
  const [coins, setCoins] = useState<EnrichedCoinAnalysis[]>([]);
  const [focusCandles, setFocusCandles] = useState<OHLCVCandle[]>([]);
  const [orderBook, setOrderBook] = useState<{
    symbol: string;
    midPrice: number;
    spreadPct: number;
    asks: OrderBookLevel[];
    bids: OrderBookLevel[];
  }>({
    symbol: "BTCUSDT",
    midPrice: 94280,
    spreadPct: 0.04,
    asks: [],
    bids: [],
  });
  const [fearGreed, setFearGreed] = useState({
    value: 64,
    labelHe: "תאוות בצע (Greed)",
    yesterdayValue: 61,
    lastWeekValue: 57,
  });
  const [proxySource, setProxySource] = useState<string>("BYBIT_V5_PRIMARY");
  const [proxyLatencyMs, setProxyLatencyMs] = useState<number>(38);

  // Database Trading Hub State
  const [virtualBalanceUsdt, setVirtualBalanceUsdt] = useState<number>(10000);
  const [realizedPnlUsdt, setRealizedPnlUsdt] = useState<number>(0);
  const [rollingWinRatePct, setRollingWinRatePct] = useState<number>(78.6);
  const [strictMode, setStrictMode] = useState<boolean>(false);
  const [minConfluenceThreshold, setMinConfluenceThreshold] =
    useState<number>(74);

  const [openPositions, setOpenPositions] = useState<PaperPositionItem[]>([]);
  const [closedPositions, setClosedPositions] = useState<PaperPositionItem[]>(
    []
  );
  const [limitOrders, setLimitOrders] = useState<PaperLimitOrderItem[]>([]);
  const [copiedTraders, setCopiedTraders] = useState<
    Array<{
      traderId: string;
      allocatedBudgetUsdt: number;
      stopLossPct: number;
      maxLeverage: number;
      isActive: boolean;
      totalCopiedTrades: number;
      copiedPnlUsdt: number;
    }>
  >([]);
  const [evaluatorLogs, setEvaluatorLogs] = useState<EvaluatorLogRecord[]>([]);
  const [taxInvoices, setTaxInvoices] = useState<TaxInvoiceItem[]>([]);

  // Real-time WebSocket Trade Tape & Push Notifications
  const [tradeTape, setTradeTape] = useState<TradeTapeExecution[]>([]);
  const [pushAlerts, setPushAlerts] = useState<MobilePushAlert[]>([
    {
      id: "INIT-PUSH-1",
      category: "HIGH_CONFLUENCE_SIGNAL",
      titleHe: "אות מסחר בעל קונפלואנס גבוה (88%)",
      bodyHe:
        "BTCUSDT: מבנה ממוצעים EMA20>50 שורי + פריצת נקודת POC בנפח 1.65x. המלצת קלי: 4x לונג.",
      symbol: "BTCUSDT",
      confluenceScore: 88,
      timestamp: Date.now() - 120000,
      isRead: false,
    },
  ]);
  const [showNotificationsDrawer, setShowNotificationsDrawer] =
    useState<boolean>(false);
  const [showApkConfigModal, setShowApkConfigModal] = useState<boolean>(false);

  // Loading, Error & Toast States
  const [initialLoading, setInitialLoading] = useState<boolean>(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isManualScanning, setIsManualScanning] = useState<boolean>(false);
  const [toastHe, setToastHe] = useState<string | null>(null);
  const [nextPollSeconds, setNextPollSeconds] = useState<number>(300); // 5-minute background poll

  // Heartbeat & Health Check Hook
  const connectionHealth = useConnectionHealth(proxySource, proxyLatencyMs);

  const showHebrewToast = useCallback((msg: string) => {
    setToastHe(msg);
    setTimeout(() => {
      setToastHe((current) => (current === msg ? null : current));
    }, 4500);
  }, []);

  // Fetch Unified Market Proxy & Database State
  const fetchAllData = useCallback(
    async (symbolToFetch = focusSymbol, isManual = false) => {
      try {
        if (isManual) setIsManualScanning(true);
        setLoadError(null);

        const [marketRes, dbRes] = await Promise.all([
          fetch(
            `/api/market-proxy?symbol=${symbolToFetch}&balance=${virtualBalanceUsdt}&strict=${strictMode}`,
            { cache: "no-store" }
          ),
          fetch("/api/trading-hub", { cache: "no-store" }),
        ]);

        if (!marketRes.ok) {
          throw new Error("שגיאה בגישה לשרת הפרוקסי של הבורסה");
        }

        const marketJson = await marketRes.json();
        const dbJson = dbRes.ok ? await dbRes.json() : null;

        if (Array.isArray(marketJson?.coins)) {
          setCoins(marketJson.coins);
        }
        if (Array.isArray(marketJson?.focusCandles)) {
          setFocusCandles(marketJson.focusCandles);
        }
        if (marketJson?.orderBook) {
          setOrderBook(marketJson.orderBook);
        }
        if (marketJson?.fearGreed) {
          setFearGreed(marketJson.fearGreed);
        }
        if (marketJson?.source) {
          setProxySource(marketJson.source);
        }
        if (marketJson?.latencyMs) {
          setProxyLatencyMs(marketJson.latencyMs);
        }

        if (dbJson?.ok) {
          if (dbJson.account) {
            setVirtualBalanceUsdt(
              Number(dbJson.account.virtualBalanceUsdt ?? 10000)
            );
            setRealizedPnlUsdt(Number(dbJson.account.realizedPnlUsdt ?? 0));
            setRollingWinRatePct(
              Number(dbJson.account.rollingWinRatePct ?? 78.6)
            );
            setStrictMode(Boolean(dbJson.account.evaluatorStrictMode));
            setMinConfluenceThreshold(
              Number(dbJson.account.minConfluenceThreshold ?? 74)
            );
          }
          setOpenPositions(
            Array.isArray(dbJson.openPositions) ? dbJson.openPositions : []
          );
          setClosedPositions(
            Array.isArray(dbJson.closedPositions) ? dbJson.closedPositions : []
          );
          setLimitOrders(
            Array.isArray(dbJson.limitOrders) ? dbJson.limitOrders : []
          );
          setCopiedTraders(
            Array.isArray(dbJson.copiedTraders) ? dbJson.copiedTraders : []
          );
          setEvaluatorLogs(
            Array.isArray(dbJson.evaluatorLogs) ? dbJson.evaluatorLogs : []
          );
          setTaxInvoices(
            Array.isArray(dbJson.taxInvoices) ? dbJson.taxInvoices : []
          );
        }

        // Fire high-confluence push alert if manual scan discovers >80% signal
        if (isManual && Array.isArray(marketJson?.coins)) {
          const highConf = marketJson.coins.find(
            (c: EnrichedCoinAnalysis) =>
              c.confluenceScore >= 80 && c.recommendation !== "WAIT"
          );
          if (highConf) {
            const alert = notificationsService.dispatchPushAlert({
              category: "HIGH_CONFLUENCE_SIGNAL",
              titleHe: `התראת סורק AI: ${highConf.symbol} (${highConf.recommendationLabelHe})`,
              bodyHe: `ציון קונפלואנס ${highConf.confluenceScore}% | כניסה: $${formatPriceNumber(
                highConf.entryPrice
              )} | יעד TP1: $${formatPriceNumber(highConf.takeProfit1)}`,
              symbol: highConf.symbol,
              confluenceScore: highConf.confluenceScore,
            });
            setPushAlerts((prev) => [alert, ...prev.slice(0, 19)]);
          }
          showHebrewToast("הסריקה הושלמה בהצלחה");
        }
      } catch (err) {
        console.error("Fetch error:", err);
        setLoadError("שגיאה בטעינת הנתונים - לחץ לנסות שוב");
      } finally {
        setInitialLoading(false);
        setIsManualScanning(false);
        setNextPollSeconds(300);
      }
    },
    [focusSymbol, virtualBalanceUsdt, strictMode, showHebrewToast]
  );

  // Manual Scan Button Handler (`handleManualScan`)
  const handleManualScan = async () => {
    await fetchAllData(focusSymbol, true);
  };

  // Initial Data Load
  useEffect(() => {
    fetchAllData(focusSymbol, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusSymbol]);

  // 5-Minute Background Polling Loop + Countdown Timer
  useEffect(() => {
    const countdownTimer = setInterval(() => {
      setNextPollSeconds((prev) => {
        if (prev <= 1) {
          fetchAllData(focusSymbol, false);
          return 300;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(countdownTimer);
  }, [fetchAllData, focusSymbol]);

  // Live WebSocket Trade Tape & Real-Time Price Tick Stream (`tradeTapeService`)
  const focusedCoinRef = useRef<number>(94280);
  useEffect(() => {
    const found = coins.find((c) => c.symbol === focusSymbol);
    if (found && found.currentPrice > 0) {
      focusedCoinRef.current = found.currentPrice;
    }
  }, [coins, focusSymbol]);

  useEffect(() => {
    tradeTapeService.startStream(
      focusSymbol,
      focusedCoinRef.current,
      (trade) => {
        setTradeTape((prev) => [trade, ...prev.slice(0, 29)]);
      },
      (sym, livePrice) => {
        // Update live ticker price smoothly in memory so Unrealized P&L & Order Book mid-price tick live
        setCoins((prevCoins) =>
          prevCoins.map((c) =>
            c.symbol === sym ? { ...c, currentPrice: livePrice } : c
          )
        );
      }
    );

    return () => {
      tradeTapeService.stopStream();
    };
  }, [focusSymbol]);

  // Paper Trading & Copy Trading Action Handlers
  const handleOpenMarketPosition = async (payload: {
    symbol: string;
    side: "LONG" | "SHORT";
    entryPrice: number;
    sizeUsdt: number;
    leverage: number;
    stopLoss: number;
    takeProfit: number;
    copiedFromTrader?: string;
  }) => {
    const res = await fetch("/api/trading-hub", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "OPEN_MARKET_POSITION",
        ...payload,
      }),
    });
    const json = await res.json();
    if (json.ok) {
      showHebrewToast(json.messageHe || "העסקה בוצעה בהצלחה בתיק הדמו");
      const alert = notificationsService.dispatchPushAlert({
        category: "SL_TP_TRIGGERED",
        titleHe: `פוזיציית דמו נפתחה: ${payload.symbol} (${payload.side})`,
        bodyHe: `בטחונות: $${payload.sizeUsdt} במינוף ${payload.leverage}x | מחיר כניסה: $${formatPriceNumber(
          payload.entryPrice
        )}`,
        symbol: payload.symbol,
      });
      setPushAlerts((prev) => [alert, ...prev.slice(0, 19)]);
      await fetchAllData(focusSymbol, false);
    } else {
      showHebrewToast(json.error || "שגיאה בפתיחת פוזיציה");
    }
  };

  const handlePlaceLimitOrder = async (payload: {
    symbol: string;
    side: "LONG" | "SHORT";
    limitPrice: number;
    sizeUsdt: number;
    leverage: number;
    stopLoss: number;
    takeProfit: number;
  }) => {
    const res = await fetch("/api/trading-hub", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "PLACE_LIMIT_ORDER",
        ...payload,
      }),
    });
    const json = await res.json();
    if (json.ok) {
      showHebrewToast(json.messageHe);
      await fetchAllData(focusSymbol, false);
    }
  };

  const handleCancelLimitOrder = async (orderId: number) => {
    const res = await fetch("/api/trading-hub", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "CANCEL_LIMIT_ORDER",
        orderId,
      }),
    });
    const json = await res.json();
    if (json.ok) {
      showHebrewToast(json.messageHe);
      await fetchAllData(focusSymbol, false);
    }
  };

  const handleClosePosition = async (positionId: number, exitPrice: number) => {
    const res = await fetch("/api/trading-hub", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "CLOSE_POSITION",
        positionId,
        exitPrice,
      }),
    });
    const json = await res.json();
    if (json.ok) {
      showHebrewToast(json.messageHe);
      await fetchAllData(focusSymbol, false);
    }
  };

  const handleToggleCopyTrader = async (payload: {
    traderId: string;
    traderName: string;
    allocatedBudgetUsdt: number;
    stopLossPct: number;
    maxLeverage: number;
    mirrorSymbol: string;
    mirrorPrice: number;
  }) => {
    const res = await fetch("/api/trading-hub", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "TOGGLE_COPY_TRADER",
        ...payload,
      }),
    });
    const json = await res.json();
    if (json.ok) {
      showHebrewToast(json.messageHe);
      const alert = notificationsService.dispatchPushAlert({
        category: "COPY_TRADE_EXECUTED",
        titleHe: `חיקוי סוחרים: ${payload.traderName}`,
        bodyHe: json.messageHe,
        symbol: payload.mirrorSymbol,
      });
      setPushAlerts((prev) => [alert, ...prev.slice(0, 19)]);
      await fetchAllData(focusSymbol, false);
    }
  };

  const handleRunEvaluatorAudit = async () => {
    const focused = coins.find((c) => c.symbol === focusSymbol) || coins[0];
    const res = await fetch("/api/trading-hub", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "RUN_EVALUATOR_AUDIT",
        symbol: focused?.symbol || "BTCUSDT",
        currentPrice: focused?.currentPrice || 94280,
        adxValue: focused?.adx14 || 24.5,
        rsiValue: focused?.rsi14 || 58.0,
        volumeRatio: focused?.volumeProfile?.volumeSpikeRatio || 1.25,
      }),
    });
    const json = await res.json();
    if (json.ok) {
      showHebrewToast(json.messageHe);
      await fetchAllData(focusSymbol, false);
    }
  };

  const handleCreateTaxInvoice = async (payload: {
    clientOrExchange: string;
    descriptionHe: string;
    amountUsdt: number;
    usdIlsRate: number;
    taxType: "capital_gains_25" | "business_income";
  }) => {
    const res = await fetch("/api/trading-hub", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "CREATE_TAX_INVOICE",
        ...payload,
      }),
    });
    const json = await res.json();
    if (json.ok) {
      showHebrewToast(json.messageHe);
      await fetchAllData(focusSymbol, false);
    }
  };

  const handleResetDemoAccount = async () => {
    const res = await fetch("/api/trading-hub", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "RESET_DEMO_ACCOUNT" }),
    });
    const json = await res.json();
    if (json.ok) {
      showHebrewToast(json.messageHe);
      await fetchAllData(focusSymbol, false);
    }
  };

  const safeCoins = Array.isArray(coins) ? coins : [];
  const filteredSignalCoins =
    signalFilter === "ALL"
      ? safeCoins
      : safeCoins.filter((c) => c.recommendation === signalFilter);

  const focusedCoinObj =
    safeCoins.find((c) => c.symbol === focusSymbol) || safeCoins[0];

  const livePricesMap: Record<string, number> = {};
  for (const c of safeCoins) {
    livePricesMap[c.symbol] = c.currentPrice;
  }

  const totalUnrealizedPnl = (
    Array.isArray(openPositions) ? openPositions : []
  ).reduce((acc, p) => {
    const mark = livePricesMap[p.symbol] || p.entryPrice;
    const diff = p.side === "LONG" ? mark - p.entryPrice : p.entryPrice - mark;
    return acc + diff * p.quantity;
  }, 0);

  return (
    <ErrorBoundary
      sectionTitleHe="אפליקציית המסחר והסריקה הראשית"
      onRetry={() => fetchAllData(focusSymbol, true)}
    >
      <div dir="rtl" className="min-h-screen bg-[#0B0E14] text-[#F1F5F9]">
        {/* Hebrew Toast Notification Banner */}
        {toastHe && (
          <div className="fixed bottom-6 left-6 z-50 flex items-center gap-3 rounded-xl border border-[#00E676] bg-[#11161F] px-5 py-3.5 text-sm font-bold text-[#F1F5F9] shadow-2xl">
            <CheckCircle2 className="h-5 w-5 text-[#00E676]" />
            <span>{toastHe}</span>
          </div>
        )}

        {/* Top Institutional Command Header Bar */}
        <header className="sticky top-0 z-40 border-b border-[#222B3A] bg-[#0B0E14]/95 backdrop-blur-md">
          <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-3 px-4 py-3">
            {/* Brand & Icon */}
            <div className="flex items-center gap-3">
              <img
                src="/assets/images/crypto_app_icon.png"
                alt="Crypto Scanner App Icon"
                className="h-10 w-10 rounded-xl border border-[#222B3A] object-cover shadow"
              />
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base font-extrabold tracking-tight text-[#F1F5F9] sm:text-lg">
                    זירת הקריפטו החכמה AI
                  </h1>
                  <span className="hidden rounded bg-[#00E676]/15 px-2 py-0.5 font-mono text-[10px] font-bold text-[#00E676] sm:inline-block">
                    v2.4 PRO RTL
                  </span>
                </div>
                <p className="text-[11px] text-[#94A3B8]">
                  סורק אלגוריתמי • חיקוי סוחרים • סימולטור $10,000 • מיסוי ישראלי
                </p>
              </div>
            </div>

            {/* Live Connection Health Badge (`useConnectionHealth`) + Polling Timer */}
            <div className="flex flex-wrap items-center gap-2.5">
              {/* Live Exchange Heartbeat Badge */}
              <div
                onClick={() => connectionHealth.triggerHeartbeat()}
                title="לחץ לבדיקת פינג מיידית מול הבורסה"
                className="flex cursor-pointer items-center gap-2 rounded-lg border border-[#222B3A] bg-[#11161F] px-3 py-1.5 text-xs transition hover:border-[#3B82F6]"
              >
                <span>{connectionHealth.dotEmoji}</span>
                <span className="font-bold text-[#F1F5F9]">
                  {connectionHealth.badgeTextHe}
                </span>
                <span className="font-mono text-[11px] text-[#94A3B8]">
                  ({connectionHealth.latencyMs}ms)
                </span>
              </div>

              {/* Virtual Portfolio Equity Quick Pill */}
              <div
                onClick={() => setActiveTab("PAPER_TRADING")}
                className="hidden cursor-pointer items-center gap-2 rounded-lg border border-[#222B3A] bg-[#11161F] px-3 py-1.5 text-xs md:flex hover:border-[#00E676]"
              >
                <Wallet className="h-3.5 w-3.5 text-[#00E676]" />
                <span className="text-[#94A3B8]">יתרת דמו:</span>
                <span className="font-mono font-extrabold text-[#00E676]">
                  ${virtualBalanceUsdt.toFixed(2)}
                </span>
              </div>

              {/* 5-Minute Background Poll Countdown */}
              <div className="hidden items-center gap-1.5 rounded-lg border border-[#222B3A] bg-[#11161F] px-2.5 py-1.5 font-mono text-[11px] text-[#94A3B8] xl:flex">
                <Clock className="h-3.5 w-3.5 text-[#3B82F6]" />
                <span>
                  רענון רקע: {Math.floor(nextPollSeconds / 60)}:
                  {String(nextPollSeconds % 60).padStart(2, "0")}
                </span>
              </div>

              {/* Manual Scan Trigger Button (`handleManualScan`) */}
              <button
                type="button"
                disabled={isManualScanning}
                onClick={handleManualScan}
                className="inline-flex items-center gap-2 rounded-lg bg-[#3B82F6] px-3.5 py-1.5 text-xs font-bold text-white shadow transition hover:bg-[#2563EB] disabled:opacity-60"
              >
                <RefreshCw
                  className={`h-3.5 w-3.5 ${
                    isManualScanning ? "animate-spin" : ""
                  }`}
                />
                <span>
                  {isManualScanning ? "סורק שוק..." : "סריקה ידנית עכשיו"}
                </span>
              </button>

              {/* Mobile Push Notifications Button */}
              <button
                type="button"
                onClick={() => {
                  notificationsService.requestPermissions();
                  setShowNotificationsDrawer(!showNotificationsDrawer);
                }}
                className="relative flex items-center gap-1.5 rounded-lg border border-[#222B3A] bg-[#11161F] px-3 py-1.5 text-xs font-semibold text-[#F1F5F9] hover:border-[#3B82F6]"
              >
                <Bell className="h-4 w-4 text-[#F59E0B]" />
                <span className="hidden sm:inline">התראות</span>
                <span className="rounded-full bg-[#FF3B69] px-1.5 py-0.2 font-mono text-[10px] font-bold text-white">
                  {pushAlerts.length}
                </span>
              </button>

              {/* Android APK & EAS Build Config Modal Button */}
              <button
                type="button"
                onClick={() => setShowApkConfigModal(true)}
                className="flex items-center gap-1.5 rounded-lg border border-[#00E676]/40 bg-[#00E676]/10 px-3 py-1.5 text-xs font-bold text-[#00E676] hover:bg-[#00E676]/20"
              >
                <Smartphone className="h-4 w-4" />
                <span className="hidden sm:inline">הגדרות APK</span>
              </button>
            </div>
          </div>

          {/* 7 Main Hebrew RTL Navigation Tabs */}
          <div className="border-t border-[#222B3A] bg-[#11161F]">
            <nav className="mx-auto flex max-w-[1600px] items-center gap-1.5 overflow-x-auto px-4 py-2">
              {NAVIGATION_TABS.map((tab) => {
                const IconComp = tab.icon;
                const isActive = activeTab === tab.key;
                return (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() => setActiveTab(tab.key)}
                    className={`flex shrink-0 items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-bold transition ${
                      isActive
                        ? "bg-[#3B82F6] text-white shadow"
                        : "text-[#94A3B8] hover:bg-[#181F2C] hover:text-[#F1F5F9]"
                    }`}
                  >
                    <IconComp className="h-4 w-4" />
                    <span>{tab.labelHe}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </header>

        {/* Mobile Push Notifications Drawer */}
        {showNotificationsDrawer && (
          <div className="fixed left-4 top-28 z-50 w-96 max-w-[92vw] rounded-xl border border-[#222B3A] bg-[#11161F] p-4 shadow-2xl">
            <div className="mb-3 flex items-center justify-between border-b border-[#222B3A] pb-2">
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4 text-[#F59E0B]" />
                <h4 className="text-sm font-bold text-[#F1F5F9]">
                  מרכז התראות Mobile Push (Expo/FCM)
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowNotificationsDrawer(false)}
                className="text-[#94A3B8] hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mb-3 flex items-center justify-between rounded bg-[#0B0E14] px-3 py-2 text-[11px]">
              <span className="text-[#94A3B8]">סטטוס ערוץ Push:</span>
              <button
                type="button"
                onClick={() => {
                  const testAlert = notificationsService.dispatchPushAlert({
                    category: "HIGH_CONFLUENCE_SIGNAL",
                    titleHe: "בדיקת התראת Push לטלפון הושלמה",
                    bodyHe:
                      "ערוץ Expo/Firebase מחובר עבור חבילת com.crypto.scanner.",
                  });
                  setPushAlerts((prev) => [testAlert, ...prev]);
                }}
                className="font-bold text-[#00E676] underline"
              >
                שגר התראת בדיקה
              </button>
            </div>
            <div className="max-h-80 space-y-2 overflow-y-auto">
              {pushAlerts.map((al) => (
                <div
                  key={al.id}
                  className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-2.5 text-xs"
                >
                  <div className="flex justify-between font-bold text-[#F1F5F9]">
                    <span>{al.titleHe}</span>
                    <span className="font-mono text-[10px] text-[#64748B]">
                      {new Date(al.timestamp).toLocaleTimeString("he-IL", {
                        hour12: false,
                      })}
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-[#94A3B8]">{al.bodyHe}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Android APK & EAS Build Config Modal */}
        {showApkConfigModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
            <div className="w-full max-w-2xl rounded-2xl border border-[#222B3A] bg-[#11161F] p-6 shadow-2xl">
              <div className="flex items-center justify-between border-b border-[#222B3A] pb-3">
                <div className="flex items-center gap-2.5">
                  <Smartphone className="h-5 w-5 text-[#00E676]" />
                  <h3 className="text-lg font-bold text-[#F1F5F9]">
                    תצורת בניית Android APK (`eas.json` &amp; `app.json`)
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowApkConfigModal(false)}
                  className="text-[#94A3B8] hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="mt-4 space-y-3 text-xs">
                <p className="text-[#94A3B8]">
                  הקבצים <code className="text-[#00E676]">app.json</code>,{" "}
                  <code className="text-[#00E676]">eas.json</code> והאייקון{" "}
                  <code className="text-[#00E676]">
                    ./assets/images/crypto_app_icon.png
                  </code>{" "}
                  מוגדרים בשורש הפרויקט לבניית APK עצמאית (`com.crypto.scanner`).
                </p>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div className="rounded-lg bg-[#0B0E14] p-3 font-mono text-[11px] text-[#E2E8F0]">
                    <div className="mb-1 font-bold text-[#3B82F6]">
                      eas.json (Preview APK Profile)
                    </div>
                    <pre className="overflow-x-auto">{`{
  "build": {
    "preview": {
      "distribution": "internal",
      "android": {
        "buildType": "apk"
      }
    }
  }
}`}</pre>
                  </div>
                  <div className="rounded-lg bg-[#0B0E14] p-3 font-mono text-[11px] text-[#E2E8F0]">
                    <div className="mb-1 font-bold text-[#00E676]">
                      app.json (Package &amp; Icon)
                    </div>
                    <pre className="overflow-x-auto">{`{
  "expo": {
    "icon": "./assets/images/crypto_app_icon.png",
    "android": {
      "package": "com.crypto.scanner"
    }
  }
}`}</pre>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main Workspace Container */}
        <main className="mx-auto max-w-[1600px] px-4 py-6">
          {/* Loading or Error Fallback States */}
          {initialLoading ? (
            <LoadingSkeletonHe
              label="טוען נתונים... מחשב אינדיקטורים דינמיים (RSI, MACD, EMA, ATR, Volume Profile) מ-200 נרות"
              rows={5}
            />
          ) : loadError ? (
            <div className="rounded-xl border border-[#FF3B69] bg-[#11161F] p-6 text-center">
              <AlertTriangle className="mx-auto h-10 w-10 text-[#FF3B69]" />
              <h3 className="mt-2 text-lg font-bold text-[#F1F5F9]">
                {loadError}
              </h3>
              <button
                type="button"
                onClick={() => fetchAllData(focusSymbol, true)}
                className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[#3B82F6] px-5 py-2.5 text-xs font-bold text-white"
              >
                <RefreshCw className="h-4 w-4" />
                <span>שגיאה בטעינת הנתונים - לחץ לנסות שוב</span>
              </button>
            </div>
          ) : (
            <>
              {/* TAB 1: "אותות ועצות מסחר" (AI Signals, Deep Analysis & Trade Advice) */}
              {activeTab === "SIGNALS_ADVICE" && (
                <ErrorBoundary sectionTitleHe="אותות ועצות מסחר (AI Signals)">
                  <div className="space-y-6">
                    {/* Top Filter & Status Bar */}
                    <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#222B3A] bg-[#11161F] p-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <Sparkles className="h-5 w-5 text-[#00E676]" />
                          <h2 className="text-lg font-bold text-[#F1F5F9]">
                            אותות מסחר בזמן אמת, ניתוח טכני עמוק וניהול סיכונים (Kelly
                            Criterion)
                          </h2>
                        </div>
                        <p className="mt-0.5 text-xs text-[#94A3B8]">
                          כל הערכים מחושבים דינמית מ-200 נרות OHLCV חיים ללא נתוני דמה:
                          RSI(14), MACD(12,26,9), EMA(20/50/200), ATR(14) ו-Volume Profile.
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        {(
                          [
                            { id: "ALL", label: "כל האיתותים (12)" },
                            { id: "LONG", label: "לונג בלבד (LONG)" },
                            { id: "SHORT", label: "שורט בלבד (SHORT)" },
                          ] as const
                        ).map((f) => (
                          <button
                            key={f.id}
                            type="button"
                            onClick={() => setSignalFilter(f.id)}
                            className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${
                              signalFilter === f.id
                                ? "bg-[#3B82F6] text-white"
                                : "bg-[#181F2C] text-[#94A3B8] hover:text-white"
                            }`}
                          >
                            {f.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Dynamic AI Signal & Position Sizing Cards Grid */}
                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
                      {filteredSignalCoins.map((coin) => {
                        const isLong = coin.recommendation === "LONG";
                        const isShort = coin.recommendation === "SHORT";

                        return (
                          <div
                            key={coin.symbol}
                            className={`flex flex-col justify-between rounded-xl border bg-[#11161F] p-5 transition hover:shadow-xl ${
                              isLong
                                ? "border-[#00E676]/45"
                                : isShort
                                ? "border-[#FF3B69]/45"
                                : "border-[#222B3A]"
                            }`}
                          >
                            <div>
                              {/* Card Top Header */}
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-mono text-lg font-extrabold text-[#F1F5F9]">
                                      {coin.symbol}
                                    </span>
                                    <span className="text-xs text-[#94A3B8]">
                                      {coin.nameHe}
                                    </span>
                                  </div>
                                  <div className="mt-1 flex items-baseline gap-2 font-mono">
                                    <span className="text-2xl font-extrabold text-[#F1F5F9]">
                                      ${formatPriceNumber(coin.currentPrice)}
                                    </span>
                                    <span
                                      className={`text-xs font-bold ${
                                        coin.change24hPct >= 0
                                          ? "text-[#00E676]"
                                          : "text-[#FF3B69]"
                                      }`}
                                    >
                                      {coin.change24hPct >= 0 ? "+" : ""}
                                      {coin.change24hPct}%
                                    </span>
                                  </div>
                                </div>

                                {/* Trade Recommendation Badge ("עצות מסחר") */}
                                <div className="text-left">
                                  <span
                                    className={`inline-flex items-center gap-1 rounded-lg px-3 py-1.5 font-mono text-xs font-extrabold ${
                                      isLong
                                        ? "bg-[#00E676] text-[#0B0E14]"
                                        : isShort
                                        ? "bg-[#FF3B69] text-white"
                                        : "bg-[#F59E0B]/20 text-[#F59E0B]"
                                    }`}
                                  >
                                    {isLong ? (
                                      <TrendingUp className="h-3.5 w-3.5" />
                                    ) : isShort ? (
                                      <TrendingDown className="h-3.5 w-3.5" />
                                    ) : null}
                                    {coin.recommendationLabelHe}
                                  </span>
                                  <div className="mt-1 font-mono text-[11px] font-bold text-[#3B82F6]">
                                    קונפלואנס: {coin.confluenceScore}%
                                  </div>
                                </div>
                              </div>

                              {/* Dynamic Technical Indicators Grid */}
                              <div className="mt-4 grid grid-cols-3 gap-2 rounded-lg bg-[#0B0E14] p-3 font-mono text-xs">
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    RSI (14)
                                  </span>
                                  <strong
                                    className={
                                      coin.rsi14 > 68
                                        ? "text-[#FF3B69]"
                                        : coin.rsi14 < 36
                                        ? "text-[#00E676]"
                                        : "text-[#F1F5F9]"
                                    }
                                  >
                                    {coin.rsi14}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    MACD Hist
                                  </span>
                                  <strong
                                    className={
                                      coin.macd.histogram >= 0
                                        ? "text-[#00E676]"
                                        : "text-[#FF3B69]"
                                    }
                                  >
                                    {coin.macd.histogram >= 0 ? "+" : ""}
                                    {coin.macd.histogram}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    ADX (14)
                                  </span>
                                  <strong className="text-[#F1F5F9]">
                                    {coin.adx14}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    EMA 20 / 50
                                  </span>
                                  <strong className="text-[11px] text-[#3B82F6]">
                                    ${formatPriceNumber(coin.ema.ema20)}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    ATR (14)
                                  </span>
                                  <strong className="text-[11px] text-[#F59E0B]">
                                    {coin.atrPct}%
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    POC נפח
                                  </span>
                                  <strong className="text-[11px] text-[#00E676]">
                                    ${formatPriceNumber(coin.volumeProfile.pocPrice)}
                                  </strong>
                                </div>
                              </div>

                              {/* Entry, Stop-Loss & Take-Profit Targets */}
                              <div className="mt-3 grid grid-cols-3 gap-2 rounded-lg border border-[#222B3A] bg-[#181F2C]/50 p-2.5 font-mono text-xs">
                                <div>
                                  <span className="block font-sans text-[10px] text-[#94A3B8]">
                                    מחיר כניסה
                                  </span>
                                  <strong className="text-[#F1F5F9]">
                                    ${formatPriceNumber(coin.entryPrice)}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#FF3B69]">
                                    Stop-Loss (SL)
                                  </span>
                                  <strong className="text-[#FF3B69]">
                                    ${formatPriceNumber(coin.stopLoss)}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#00E676]">
                                    Take-Profit (TP1)
                                  </span>
                                  <strong className="text-[#00E676]">
                                    ${formatPriceNumber(coin.takeProfit1)}
                                  </strong>
                                </div>
                              </div>

                              {/* Position Sizing Box ("בכמה לסחור" - Kelly Criterion & ATR) */}
                              <div className="mt-3 rounded-lg border border-[#3B82F6]/30 bg-[#3B82F6]/10 p-3 text-xs">
                                <div className="flex items-center justify-between font-bold text-[#F1F5F9]">
                                  <span>
                                    בכמה לסחור (Kelly Criterion + ATR):
                                  </span>
                                  <span className="font-mono text-[#00E676]">
                                    מינוף {coin.kellySizing.recommendedLeverage}x
                                  </span>
                                </div>
                                <div className="mt-1 flex justify-between font-mono text-xs">
                                  <span className="text-[#E2E8F0]">
                                    הקצאה: {coin.kellySizing.positionPctOfBalance}% מהתיק
                                  </span>
                                  <strong className="text-[#00E676]">
                                    ${coin.kellySizing.marginSizeUsdt} USDT (חשיפה $
                                    {coin.kellySizing.notionalSizeUsdt})
                                  </strong>
                                </div>
                              </div>

                              {/* Dynamic Confluence Reasons */}
                              <ul className="mt-3 space-y-1 text-xs text-[#94A3B8]">
                                {coin.reasonsHe.slice(0, 3).map((reason, rIdx) => (
                                  <li
                                    key={rIdx}
                                    className="flex items-start gap-1.5"
                                  >
                                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[#00E676]" />
                                    <span>{reason}</span>
                                  </li>
                                ))}
                              </ul>

                              {coin.evaluatorWarningHe && (
                                <div className="mt-2.5 rounded border border-[#F59E0B]/40 bg-[#F59E0B]/10 px-2.5 py-1.5 text-[11px] text-[#F59E0B]">
                                  ⚠️ {coin.evaluatorWarningHe}
                                </div>
                              )}
                            </div>

                            {/* 1-Click Execute in Demo & Open Chart Buttons */}
                            <div className="mt-4 flex items-center gap-2 pt-2">
                              <button
                                type="button"
                                onClick={() =>
                                  handleOpenMarketPosition({
                                    symbol: coin.symbol,
                                    side:
                                      coin.recommendation === "SHORT"
                                        ? "SHORT"
                                        : "LONG",
                                    entryPrice: coin.currentPrice,
                                    sizeUsdt: coin.kellySizing.marginSizeUsdt,
                                    leverage:
                                      coin.kellySizing.recommendedLeverage,
                                    stopLoss: coin.stopLoss,
                                    takeProfit: coin.takeProfit1,
                                  })
                                }
                                className="flex-1 rounded-lg bg-[#00E676] py-2.5 text-xs font-extrabold text-[#0B0E14] transition hover:brightness-110"
                              >
                                בצע בעסקת דמו (${coin.kellySizing.marginSizeUsdt} •{" "}
                                {coin.kellySizing.recommendedLeverage}x)
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setFocusSymbol(coin.symbol);
                                  setActiveTab("CHARTS_ORDERBOOK");
                                }}
                                className="rounded-lg border border-[#222B3A] bg-[#181F2C] px-3 py-2.5 text-xs font-bold text-[#F1F5F9] hover:border-[#3B82F6]"
                              >
                                גרף + ספר
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Self-Checking & Self-Scanning Evaluator-Optimizer Panel */}
                    <EvaluatorAgentPanel
                      logs={evaluatorLogs}
                      rollingWinRatePct={rollingWinRatePct}
                      strictMode={strictMode}
                      minConfluenceThreshold={minConfluenceThreshold}
                      onRunManualAudit={handleRunEvaluatorAudit}
                    />
                  </div>
                </ErrorBoundary>
              )}

              {/* TAB 2: "חיקוי עסקאות סוחרים" (Copy Trading & Leaderboard) */}
              {activeTab === "COPY_TRADING" && (
                <ErrorBoundary sectionTitleHe="חיקוי עסקאות סוחרים (Copy Trading)">
                  <CopyTradingModule
                    copiedSubscriptions={copiedTraders}
                    livePricesMap={livePricesMap}
                    onToggleCopyTrader={handleToggleCopyTrader}
                  />
                </ErrorBoundary>
              )}

              {/* TAB 3: "מסחר דמו / ניסיון" (Paper Trading Simulator) */}
              {activeTab === "PAPER_TRADING" && (
                <ErrorBoundary sectionTitleHe="סימולטור מסחר דמו ($10,000 USDT)">
                  <PaperTradingModule
                    virtualBalanceUsdt={virtualBalanceUsdt}
                    realizedPnlUsdt={realizedPnlUsdt}
                    coins={safeCoins}
                    openPositions={openPositions}
                    closedPositions={closedPositions}
                    limitOrders={limitOrders}
                    onOpenMarketPosition={handleOpenMarketPosition}
                    onPlaceLimitOrder={handlePlaceLimitOrder}
                    onCancelLimitOrder={handleCancelLimitOrder}
                    onClosePosition={handleClosePosition}
                    onResetAccount={handleResetDemoAccount}
                  />
                </ErrorBoundary>
              )}

              {/* TAB 4: "גרפים וספר פקודות" (Bybit Synced Chart, Order Book & Trade Tape) */}
              {activeTab === "CHARTS_ORDERBOOK" && focusedCoinObj && (
                <ErrorBoundary sectionTitleHe="גרפים, ספר פקודות וסרט עסקאות">
                  <div className="space-y-4">
                    {/* Symbol Switcher Strip */}
                    <div className="flex flex-wrap items-center gap-2 rounded-xl border border-[#222B3A] bg-[#11161F] p-3">
                      <span className="text-xs font-bold text-[#94A3B8]">
                        בחר צמד לגרף וספר פקודות:
                      </span>
                      {safeCoins.map((c) => (
                        <button
                          key={c.symbol}
                          type="button"
                          onClick={() => setFocusSymbol(c.symbol)}
                          className={`rounded-lg px-3 py-1.5 font-mono text-xs font-bold transition ${
                            c.symbol === focusSymbol
                              ? "bg-[#3B82F6] text-white"
                              : "bg-[#181F2C] text-[#94A3B8] hover:text-white"
                          }`}
                        >
                          {c.baseAsset} (${formatPriceNumber(c.currentPrice)})
                        </button>
                      ))}
                    </div>

                    <CandlestickTerminal
                      coin={focusedCoinObj}
                      candles={focusCandles}
                      orderBook={orderBook}
                      tradeTape={tradeTape}
                      onQuickOrder={(side) =>
                        handleOpenMarketPosition({
                          symbol: focusedCoinObj.symbol,
                          side,
                          entryPrice: focusedCoinObj.currentPrice,
                          sizeUsdt: focusedCoinObj.kellySizing.marginSizeUsdt,
                          leverage:
                            focusedCoinObj.kellySizing.recommendedLeverage,
                          stopLoss: focusedCoinObj.stopLoss,
                          takeProfit: focusedCoinObj.takeProfit1,
                        })
                      }
                    />
                  </div>
                </ErrorBoundary>
              )}

              {/* TAB 5: "מפת שוק" (Finviz Heatmap & Fear & Greed Index) */}
              {activeTab === "MARKET_HEATMAP" && (
                <ErrorBoundary sectionTitleHe="מפת שוק (Finviz Heatmap & Fear/Greed)">
                  <FinvizHeatmapModule
                    coins={safeCoins}
                    fearGreed={fearGreed}
                    onSelectCoin={(sym) => {
                      setFocusSymbol(sym);
                      setActiveTab("CHARTS_ORDERBOOK");
                    }}
                  />
                </ErrorBoundary>
              )}

              {/* TAB 6: "מחקר עומק" (Messari Fundamental Intelligence) */}
              {activeTab === "DEEP_RESEARCH" && (
                <ErrorBoundary sectionTitleHe="מחקר עומק פונדמנטלי (Messari)">
                  <MessariResearchModule
                    coins={safeCoins}
                    onTradeDemoFromResearch={(coin) => {
                      handleOpenMarketPosition({
                        symbol: coin.symbol,
                        side:
                          coin.recommendation === "SHORT" ? "SHORT" : "LONG",
                        entryPrice: coin.currentPrice,
                        sizeUsdt: coin.kellySizing.marginSizeUsdt,
                        leverage: coin.kellySizing.recommendedLeverage,
                        stopLoss: coin.stopLoss,
                        takeProfit: coin.takeProfit1,
                      });
                    }}
                  />
                </ErrorBoundary>
              )}

              {/* TAB 7: "פיננסים, מיסוי ודוחות" (Invoapp Accounting & Israeli Tax Hub) */}
              {activeTab === "FINANCE_TAX" && (
                <ErrorBoundary sectionTitleHe="פיננסים, מיסוי ודוחות (טופס 909)">
                  <InvoappTaxModule
                    realizedPnlUsdt={realizedPnlUsdt}
                    unrealizedPnlUsdt={totalUnrealizedPnl}
                    invoices={taxInvoices}
                    onCreateInvoice={handleCreateTaxInvoice}
                  />
                </ErrorBoundary>
              )}
            </>
          )}
        </main>
      </div>
    </ErrorBoundary>
  );
}
