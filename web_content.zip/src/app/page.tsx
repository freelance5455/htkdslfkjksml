"use client";

import Link from "next/link";
import { LocalMatches } from "@/components/local-matches";

/**
 * Home.
 *
 * Reads matches straight from on-device storage, so the page works with no
 * server at all — required for the static/WebView build and for ordinary
 * offline scoring.
 */
export default function HomePage() {
  return (
    <main className="mx-auto max-w-7xl px-3 py-6 sm:px-4 sm:py-8">
      <section className="mc-card relative overflow-hidden px-4 py-8 sm:px-10 sm:py-14">
        <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-emerald-500/20 blur-3xl" />
        <div className="relative">
          <span className="rounded-full border border-emerald-500/40 bg-emerald-500/10 px-3 py-1 text-[11px] font-black uppercase tracking-[0.2em] text-emerald-300">
            Cricket Scoring Engine
          </span>
          <h1 className="mt-3 text-3xl font-black leading-tight tracking-tight sm:text-5xl">
            Score every ball.
            <br />
            <span className="text-emerald-400">Ball by ball.</span>
          </h1>
          <p className="mt-3 max-w-xl text-slate-400">
            Register full Playing XIs with roles, jerseys and captaincy, score ball by ball, and
            get professional live scorecards, over analysis, player profiles and automatic match
            awards — fully offline.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              href="/new"
              className="mc-btn rounded-xl bg-emerald-500 px-5 py-3 font-black text-slate-950 hover:bg-emerald-400"
            >
              Create New Match
            </Link>
            <Link
              href="/leagues"
              className="mc-btn rounded-xl border border-slate-700 px-5 py-3 font-bold text-slate-200 hover:bg-slate-800"
            >
              Leagues &amp; Tournaments
            </Link>
            <Link
              href="/history"
              className="mc-btn rounded-xl border border-slate-700 px-5 py-3 font-bold text-slate-200 hover:bg-slate-800"
            >
              Match History
            </Link>
          </div>

          <div className="mt-8 grid max-w-2xl grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { k: "Ball-by-ball", v: "Scoring Engine" },
              { k: "اردو", v: "Voice Commentary" },
              { k: "Offline", v: "Works Anywhere" },
              { k: "Leagues", v: "& Tournaments" },
            ].map((s) => (
              <div
                key={s.k}
                className="rounded-xl border border-slate-800 bg-slate-950/40 px-3 py-2.5"
              >
                <p className="text-sm font-black text-emerald-400">{s.k}</p>
                <p className="text-[11px] text-slate-400">{s.v}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <h2 className="mb-3 mt-10 text-lg font-black uppercase tracking-wider text-slate-300">
        Live &amp; upcoming
      </h2>
      <LocalMatches filter="live" emptyMessage="No live matches. Create a match to start scoring." />
    </main>
  );
}
