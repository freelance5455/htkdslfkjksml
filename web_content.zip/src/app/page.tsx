import Image from "next/image";
import Link from "next/link";
import type { CSSProperties } from "react";
import { ArrowDown, ArrowLeft, BookOpen, HeartHandshake, Sparkles, BookOpenText } from "lucide-react";
import { LogoMark } from "@/components/logo-mark";
import { WaveDivider, Eyebrow } from "@/components/page-hero";
import { TiltCard } from "@/components/tilt-card";
import { DhikrCounter } from "@/components/dhikr-counter";
import { JourneyExplorer } from "@/components/journey-explorer";
import { PrayerTimes } from "@/components/prayer-times";
import { PATHS } from "@/data/paths";
import { TASBIH_ITEMS } from "@/data/adhkar";
import { SITE, toArabicDigits } from "@/lib/site";

const enter = (ms: string) => ({ "--enter-delay": ms }) as CSSProperties;
const reveal = (ms: string) => ({ "--reveal-delay": ms }) as CSSProperties;

export default function HomePage() {
  return (
    <main>
      <Hero />
      <Experience />
      <QuranSection />
      <AdhkarSection />
      <JourneySection />
      <PrayerSection />
      <IdentitySection />
    </main>
  );
}

/* ------------------------------------------------------------------ */
/* Hero                                                                */
/* ------------------------------------------------------------------ */
function Hero() {
  return (
    <section
      aria-labelledby="hero-title"
      className="relative isolate flex min-h-svh flex-col overflow-hidden bg-navy-deep text-ivory"
    >
      <div
        className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_70%_60%_at_25%_45%,rgba(49,75,117,0.9),transparent_70%),radial-gradient(ellipse_50%_40%_at_25%_30%,rgba(182,154,105,0.28),transparent_70%),linear-gradient(180deg,#0F1828_0%,#17243A_60%,#1B2C48_100%)]"
        aria-hidden="true"
      />
      <div className="pattern-lattice mask-radial absolute inset-0 -z-10 opacity-[0.09]" aria-hidden="true" />
      <div className="grain absolute inset-0 -z-10 opacity-[0.06] mix-blend-overlay" aria-hidden="true" />
      <div className="absolute inset-0 -z-10 flex items-center justify-center" aria-hidden="true">
        <div className="size-40 animate-pulse rounded-full bg-gold/20 blur-3xl" />
      </div>
      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-navy-deep via-navy-deep/85 to-transparent lg:hidden"
        aria-hidden="true"
      />

      <div className="pointer-events-none relative mx-auto flex w-full max-w-7xl flex-1 items-end px-5 pt-32 pb-28 lg:items-center lg:px-8 lg:pb-20">
        <div className="pointer-events-auto max-w-xl lg:max-w-[34rem]">
          <p
            className="hero-enter mb-6 inline-flex items-center gap-3 rounded-full border border-gold/30 bg-navy/40 px-4 py-1.5 text-sm text-gold-light backdrop-blur"
            style={enter("100ms")}
          >
            <LogoMark className="size-4" />
            {SITE.eyebrow}
          </p>
          <h1
            id="hero-title"
            className="hero-enter font-serif text-7xl leading-[1.15] font-bold sm:text-8xl lg:text-9xl"
            style={enter("250ms")}
          >
            <span className="text-gold-gradient animate-shimmer">{SITE.name}</span>
          </h1>
          <p
            className="hero-enter mt-6 max-w-md font-serif text-2xl leading-relaxed text-ivory/90 sm:text-3xl"
            style={enter("450ms")}
          >
            {SITE.tagline}
          </p>
          <div
            className="hero-enter mt-8 flex items-center gap-4 border-s-2 border-gold/60 ps-4"
            style={enter("600ms")}
          >
            <div>
              <p className="text-lg font-semibold text-ivory">{SITE.author}</p>
              <p className="text-sm text-ivory/60">{SITE.school}</p>
            </div>
          </div>
          <div className="hero-enter mt-10 flex flex-wrap gap-4" style={enter("750ms")}>
            <Link
              className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-gradient-to-b from-gold-light to-gold px-8 py-4 text-base font-semibold text-navy shadow-[0_20px_50px_-15px_rgba(182,154,105,0.9)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_25px_60px_-12px_rgba(182,154,105,1)] active:translate-y-0"
              href="/paths"
            >
              <span
                className="absolute inset-0 -translate-x-full bg-gradient-to-l from-transparent via-white/40 to-transparent transition-transform duration-700 group-hover:translate-x-full"
                aria-hidden="true"
              />
              ابدأ رحلتك
              <ArrowLeft className="size-5 transition-transform group-hover:-translate-x-1" aria-hidden="true" />
            </Link>
            <a
              className="group inline-flex items-center gap-3 rounded-full border border-ivory/25 bg-ivory/5 px-8 py-4 text-base font-medium text-ivory backdrop-blur transition-all duration-300 hover:border-gold hover:bg-ivory/10 hover:text-gold-light"
              href="#experience"
            >
              اكتشف التطبيق
              <ArrowDown className="size-5 transition-transform group-hover:translate-y-1" aria-hidden="true" />
            </a>
          </div>
        </div>
      </div>

      <div
        className="pointer-events-none absolute bottom-14 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-xs text-ivory/40 lg:flex"
        aria-hidden="true"
      >
        <span>مرّر للأسفل</span>
        <span className="h-10 w-px animate-pulse bg-gradient-to-b from-gold to-transparent" />
      </div>

      <WaveDivider />
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Experience: seven doors                                             */
/* ------------------------------------------------------------------ */
function Experience() {
  return (
    <section
      id="experience"
      aria-labelledby="experience-title"
      className="relative scroll-mt-20 overflow-hidden bg-ivory py-24 sm:py-32"
    >
      <div className="pattern-stars mask-fade-y absolute inset-x-0 top-0 h-[28rem] opacity-[0.12]" aria-hidden="true" />
      <div className="absolute -start-40 top-1/3 size-[36rem] rounded-full bg-gold/10 blur-3xl" aria-hidden="true" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="reveal mb-16 flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-end" style={reveal("0ms")}>
          <div>
            <Eyebrow>التجربة التعليمية</Eyebrow>
            <h2 id="experience-title" className="mt-4 max-w-2xl font-serif text-5xl leading-tight font-bold text-navy sm:text-6xl">
              سبعة أبواب إلى <span className="text-gold">نور العلم</span>
            </h2>
          </div>
          <p className="max-w-md leading-8 text-navy/65">
            رحلة متكاملة تجمع كتاب الله وسنة نبيه ﷺ، وسير الصحابة، ومسارات تعليمية بالاختبارات، ومحاضرات مختارة.
          </p>
        </div>

        <ul className="grid auto-rows-auto gap-6 md:grid-cols-2 lg:grid-cols-4">
          {/* 01 — Quran */}
          <li className="reveal md:col-span-2 lg:row-span-2" style={reveal("0ms")}>
            <TiltCard href="/quran" ariaLabel="القرآن الكريم — كلام الله المحفوظ" className="">
              <div className="relative flex h-full min-h-[30rem] flex-col justify-end overflow-hidden rounded-[2rem] bg-navy p-8 shadow-[0_30px_70px_-40px_rgba(23,36,58,0.55)] transition-shadow duration-500 group-hover/tilt:shadow-[0_45px_90px_-40px_rgba(23,36,58,0.75)] sm:p-10">
                <Image
                  src="/images/card-quran.jpg"
                  alt=""
                  fill
                  sizes="(min-width: 1024px) 50vw, 100vw"
                  className="object-cover transition-transform duration-500 ease-out [transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.08)] group-hover/tilt:[transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.14)]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-deep via-navy-deep/60 to-transparent" />
                <div className="absolute inset-4 rounded-[1.6rem] border border-gold/25" aria-hidden="true" />
                <div className="relative [transform:translateZ(40px)]">
                  <CardNumber n={1} label="١١٤ سورة" light />
                  <h3 className="font-serif text-4xl font-bold text-ivory sm:text-5xl">القرآن الكريم</h3>
                  <p className="mt-1 text-sm text-gold-light">كلام الله المحفوظ</p>
                  <p className="mt-3 max-w-md text-sm leading-7 text-ivory/70">
                    تلاوة السور كاملة بالرسم العثماني مع الاستماع لكل آية بصوت الشيخ مشاري العفاسي.
                  </p>
                  <CardLink light />
                </div>
              </div>
            </TiltCard>
          </li>

          {/* 02 — Adhkar */}
          <li className="reveal md:col-span-2" style={reveal("70ms")}>
            <TiltCard href="/adhkar" ariaLabel="الأذكار والأدعية — طمأنينة القلب">
              <div className="relative flex h-full min-h-[18rem] flex-col overflow-hidden rounded-[2rem] bg-ivory shadow-[0_30px_70px_-40px_rgba(23,36,58,0.55)] transition-shadow duration-500 group-hover/tilt:shadow-[0_45px_90px_-40px_rgba(23,36,58,0.75)] sm:flex-row">
                <div className="relative min-h-52 overflow-hidden sm:w-1/2">
                  <Image
                    src="/images/card-adhkar.jpg"
                    alt=""
                    fill
                    sizes="(min-width: 640px) 25vw, 100vw"
                    className="object-cover transition-transform duration-500 ease-out [transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.08)] group-hover/tilt:[transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.14)]"
                  />
                </div>
                <div className="flex flex-1 items-center p-8">
                  <div className="relative [transform:translateZ(40px)]">
                    <CardNumber n={2} label="٤ مجموعات" />
                    <h3 className="font-serif text-3xl font-bold text-navy">الأذكار والأدعية</h3>
                    <p className="mt-1 text-sm text-gold">طمأنينة القلب</p>
                    <p className="mt-3 max-w-md text-sm leading-7 text-navy/65">
                      أذكار الصباح والمساء وما بعد الصلاة والنوم، مع عدّاد لكل ذكر.
                    </p>
                    <CardLink />
                  </div>
                </div>
              </div>
            </TiltCard>
          </li>

          {/* 03 — Hadith */}
          <li className="reveal" style={reveal("140ms")}>
            <TiltCard href="/hadith" ariaLabel="الحديث الشريف — من مشكاة النبوة">
              <div className="relative flex h-full min-h-[26rem] flex-col items-center overflow-hidden rounded-[2rem] bg-ivory p-7 text-center shadow-[0_30px_70px_-40px_rgba(23,36,58,0.55)] transition-shadow duration-500 group-hover/tilt:shadow-[0_45px_90px_-40px_rgba(23,36,58,0.75)]">
                <div className="relative mb-6 h-48 w-40 overflow-hidden rounded-t-full border-4 border-gold/30 shadow-inner">
                  <Image
                    src="/images/card-hadith.jpg"
                    alt=""
                    fill
                    sizes="160px"
                    className="object-cover transition-transform duration-500 ease-out [transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.08)] group-hover/tilt:[transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.14)]"
                  />
                </div>
                <div className="[transform:translateZ(40px)] [&_div]:justify-center [&_p]:mx-auto">
                  <CardNumber n={3} label="١٠ أحاديث" />
                  <h3 className="font-serif text-3xl font-bold text-navy">الحديث الشريف</h3>
                  <p className="mt-1 text-sm text-gold">من مشكاة النبوة</p>
                  <p className="mt-3 text-sm leading-7 text-navy/65">
                    أحاديث جامعة مختارة مع راويها ومصدرها وشرح موجز لمعانيها.
                  </p>
                  <CardLink />
                </div>
              </div>
            </TiltCard>
          </li>

          {/* 04 — Seerah */}
          <li className="reveal" style={reveal("210ms")}>
            <TiltCard href="/seerah" ariaLabel="السيرة النبوية — حياة خير البشر">
              <div className="relative flex h-full min-h-[26rem] flex-col overflow-hidden rounded-[2rem] bg-ivory shadow-[0_30px_70px_-40px_rgba(23,36,58,0.55)] transition-shadow duration-500 group-hover/tilt:shadow-[0_45px_90px_-40px_rgba(23,36,58,0.75)]">
                <div className="relative h-52 overflow-hidden">
                  <Image
                    src="/images/card-seerah.jpg"
                    alt=""
                    fill
                    sizes="(min-width: 1024px) 25vw, 100vw"
                    className="object-cover transition-transform duration-500 ease-out [transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.08)] group-hover/tilt:[transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.14)]"
                  />
                </div>
                <div className="flex flex-1 flex-col p-7">
                  <div className="[transform:translateZ(40px)]">
                    <CardNumber n={4} label="١٠ محطات" />
                    <h3 className="font-serif text-3xl font-bold text-navy">السيرة النبوية</h3>
                    <p className="mt-1 text-sm text-gold">حياة خير البشر</p>
                    <p className="mt-3 text-sm leading-7 text-navy/65">
                      محطات السيرة من المولد إلى الوفاة في خط زمني متتابع.
                    </p>
                    <CardLink />
                  </div>
                </div>
              </div>
            </TiltCard>
          </li>

          {/* 05 — Sahaba */}
          <li className="reveal" style={reveal("280ms")}>
            <TiltCard href="/sahaba" ariaLabel="قصص الصحابة — نجوم الهداية">
              <div className="relative flex h-full min-h-[22rem] flex-col overflow-hidden rounded-[2rem] bg-stone shadow-[0_30px_70px_-40px_rgba(23,36,58,0.55)] transition-shadow duration-500 group-hover/tilt:shadow-[0_45px_90px_-40px_rgba(23,36,58,0.75)] sm:flex-row-reverse">
                <div className="relative min-h-44 overflow-hidden sm:w-1/2">
                  <Image
                    src="/images/card-sahaba.jpg"
                    alt=""
                    fill
                    sizes="(min-width: 640px) 25vw, 100vw"
                    className="object-cover transition-transform duration-500 ease-out [transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.08)] group-hover/tilt:[transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.14)]"
                  />
                </div>
                <div className="flex flex-1 items-center p-7">
                  <div className="[transform:translateZ(40px)]">
                    <CardNumber n={5} label="٨ قصص" />
                    <h3 className="font-serif text-3xl font-bold text-navy">قصص الصحابة</h3>
                    <p className="mt-1 text-sm text-gold">نجوم الهداية</p>
                    <p className="mt-3 text-sm leading-7 text-navy/65">
                      سير مختصرة لأصحاب النبي ﷺ ومواقفهم الخالدة ودروسها.
                    </p>
                    <CardLink />
                  </div>
                </div>
              </div>
            </TiltCard>
          </li>

          {/* 06 — Paths */}
          <li className="reveal" style={reveal("350ms")}>
            <TiltCard href="/paths" ariaLabel="المسارات التعليمية — تعلّم خطوة بخطوة">
              <div className="relative flex h-full min-h-[22rem] flex-col overflow-hidden rounded-[2rem] bg-ivory shadow-[0_30px_70px_-40px_rgba(23,36,58,0.55)] transition-shadow duration-500 group-hover/tilt:shadow-[0_45px_90px_-40px_rgba(23,36,58,0.75)] sm:flex-row">
                <div className="relative min-h-44 overflow-hidden sm:w-1/2">
                  <Image
                    src="/images/card-paths.jpg"
                    alt=""
                    fill
                    sizes="(min-width: 640px) 25vw, 100vw"
                    className="object-cover transition-transform duration-500 ease-out [transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.08)] group-hover/tilt:[transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.14)]"
                  />
                </div>
                <div className="flex flex-1 items-center p-7">
                  <div className="[transform:translateZ(40px)]">
                    <CardNumber n={6} label="٤ مسارات" />
                    <h3 className="font-serif text-3xl font-bold text-navy">المسارات التعليمية</h3>
                    <p className="mt-1 text-sm text-gold">تعلّم خطوة بخطوة</p>
                    <p className="mt-3 text-sm leading-7 text-navy/65">
                      دروس متدرجة في العقيدة والعبادات والأخلاق مع اختبارات تفاعلية.
                    </p>
                    <CardLink />
                  </div>
                </div>
              </div>
            </TiltCard>
          </li>

          {/* 07 — Lectures */}
          <li className="reveal lg:col-span-2" style={reveal("420ms")}>
            <TiltCard href="/lectures" ariaLabel="المحاضرات الإسلامية — مجالس العلم">
              <div className="relative flex h-full min-h-[22rem] flex-col overflow-hidden rounded-[2rem] bg-ivory shadow-[0_30px_70px_-40px_rgba(23,36,58,0.55)] transition-shadow duration-500 group-hover/tilt:shadow-[0_45px_90px_-40px_rgba(23,36,58,0.75)] sm:flex-row">
                <div className="relative h-52 overflow-hidden sm:h-auto sm:w-1/2">
                  <Image
                    src="/images/card-lectures.jpg"
                    alt=""
                    fill
                    sizes="(min-width: 640px) 35vw, 100vw"
                    className="object-cover transition-transform duration-500 ease-out [transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.08)] group-hover/tilt:[transform:translate3d(calc(var(--mx,0)*-18px),calc(var(--my,0)*-18px),0)_scale(1.14)]"
                  />
                  <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-ivory to-transparent sm:inset-y-0 sm:start-0 sm:h-auto sm:w-16 sm:bg-gradient-to-r" />
                </div>
                <div className="flex flex-1 items-center p-7 sm:p-8">
                  <div className="[transform:translateZ(40px)]">
                    <CardNumber n={7} label="٦ محاضرات" />
                    <h3 className="font-serif text-3xl font-bold text-navy">المحاضرات الإسلامية</h3>
                    <p className="mt-1 text-sm text-gold">مجالس العلم</p>
                    <p className="mt-3 max-w-md text-sm leading-7 text-navy/65">
                      محاضرات مقروءة مع مشغّل وفصول ونص مصاحب يتتبع التشغيل.
                    </p>
                    <CardLink />
                  </div>
                </div>
              </div>
            </TiltCard>
          </li>
        </ul>
      </div>
    </section>
  );
}

function CardNumber({ n, label, light = false }: { n: number; label: string; light?: boolean }) {
  return (
    <div className="mb-3 flex items-center gap-3">
      <span className={`font-serif text-sm ${light ? "text-gold-light" : "text-gold"}`}>{toArabicDigits(String(n).padStart(2, "0"))}</span>
      <span className="h-px w-8 bg-gold/50" />
      <span className={`text-xs ${light ? "text-ivory/60" : "text-muted-foreground"}`}>{label}</span>
    </div>
  );
}

function CardLink({ light = false }: { light?: boolean }) {
  return (
    <span
      className={`mt-5 inline-flex items-center gap-2 text-sm font-medium transition-all group-hover/tilt:gap-3 ${
        light ? "text-gold-light" : "text-royal"
      }`}
    >
      ادخل القسم
      <ArrowLeft className="size-4" aria-hidden="true" />
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Quran                                                               */
/* ------------------------------------------------------------------ */
function QuranSection() {
  return (
    <section aria-labelledby="quran-title" className="relative overflow-hidden bg-stone py-24 sm:py-32">
      <div className="pattern-circles absolute inset-0 opacity-[0.07]" aria-hidden="true" />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-l from-transparent via-gold/60 to-transparent" aria-hidden="true" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-16 px-5 lg:grid-cols-2 lg:px-8">
        <div className="reveal" style={reveal("0ms")}>
          <Eyebrow>تجربة المصحف</Eyebrow>
          <h2 id="quran-title" className="mt-4 font-serif text-5xl leading-tight font-bold text-navy sm:text-6xl">
            القرآن الكريم
            <span className="mt-2 block text-3xl text-royal sm:text-4xl">نورٌ يهدي القلوب</span>
          </h2>

          <figure className="relative mt-10 rounded-3xl border border-gold/40 bg-ivory/70 p-8 shadow-[0_30px_60px_-40px_rgba(23,36,58,0.5)] backdrop-blur">
            <span className="absolute -top-3 start-8 bg-stone px-3 text-xs text-gold">الإسراء · ٩</span>
            <blockquote className="font-serif text-3xl leading-[2] text-navy sm:text-4xl">
              ﴿إِنَّ هَٰذَا الْقُرْآنَ يَهْدِي لِلَّتِي هِيَ أَقْوَمُ﴾
            </blockquote>
          </figure>

          <dl className="mt-10 grid grid-cols-3 divide-x divide-x-reverse divide-gold/30">
            <Stat value="١١٤" label="سورة" />
            <Stat value="٦٢٣٦" label="آية" />
            <Stat value="٣٠" label="جزءًا" />
          </dl>

          <div className="mt-10 flex flex-wrap gap-4">
            <Link
              className="inline-flex items-center gap-3 rounded-full bg-navy px-8 py-4 font-semibold text-ivory shadow-[0_20px_40px_-20px_rgba(23,36,58,0.9)] transition-all hover:-translate-y-0.5 hover:bg-royal"
              href="/quran"
            >
              <BookOpen className="size-5" aria-hidden="true" />
              افتح المصحف
            </Link>
            <Link
              className="inline-flex items-center gap-3 rounded-full border border-navy/20 px-8 py-4 font-medium text-navy transition-all hover:border-gold hover:text-gold"
              href="/quran/1"
            >
              ابدأ بسورة الفاتحة
            </Link>
          </div>
        </div>

        <div className="reveal relative" style={reveal("150ms")}>
          <div className="relative mx-auto aspect-[4/5] w-full max-w-lg">
            <div className="absolute inset-0 overflow-hidden rounded-t-[50%] border border-gold/40 bg-gradient-to-b from-ivory via-ivory to-stone shadow-[inset_0_0_80px_rgba(182,154,105,0.25)]">
              <div className="pattern-stars absolute inset-0 opacity-[0.15]" aria-hidden="true" />
            </div>
            <div className="absolute inset-3 rounded-t-[50%] border border-gold/20" aria-hidden="true" />
            <div className="absolute inset-0 flex items-center justify-center" aria-hidden="true">
              <div className="size-40 animate-pulse rounded-full bg-gold/20 blur-3xl" />
            </div>
            <div className="absolute inset-x-0 bottom-10 text-center" aria-hidden="true">
              <p className="font-serif text-3xl text-navy/80">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div className="px-4 text-center first:ps-0">
      <dt className="sr-only">{label}</dt>
      <dd className="font-serif text-4xl font-bold text-navy">{value}</dd>
      <dd className="mt-1 text-sm text-navy/60">{label}</dd>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Adhkar                                                              */
/* ------------------------------------------------------------------ */
function AdhkarSection() {
  return (
    <section aria-labelledby="adhkar-title" className="relative overflow-hidden bg-navy text-ivory">
      <svg viewBox="0 0 1440 80" preserveAspectRatio="none" className="pointer-events-none block h-10 w-full rotate-180 sm:h-16" aria-hidden="true">
        <path d="M0 80V40C240 40 420 0 720 0s480 40 720 40v40Z" fill="#E9E6E0" />
      </svg>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_45%,rgba(49,75,117,0.85),transparent_70%)]" aria-hidden="true" />
      <div className="pattern-lattice mask-radial absolute inset-0 opacity-[0.08]" aria-hidden="true" />

      <div className="relative mx-auto max-w-7xl px-5 py-20 sm:py-28 lg:px-8">
        <div className="reveal mx-auto mb-14 max-w-2xl text-center" style={reveal("0ms")}>
          <p className="inline-flex items-center gap-3 text-sm font-medium tracking-wide text-gold-light">
            <LogoMark className="size-4" />
            تجربة الذكر
          </p>
          <h2 id="adhkar-title" className="mt-4 font-serif text-5xl leading-tight font-bold sm:text-6xl">
            ﴿أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ﴾
          </h2>
          <div className="mt-6 flex items-center justify-center gap-4 text-gold" aria-hidden="true">
            <span className="h-px w-16 bg-gradient-to-l from-gold to-transparent sm:w-28" />
            <LogoMark className="size-5" />
            <span className="h-px w-16 bg-gradient-to-r from-gold to-transparent sm:w-28" />
          </div>
        </div>

        <div className="reveal" style={reveal("120ms")}>
          <DhikrCounter items={TASBIH_ITEMS} storageKey="after-prayer" variant="compact" />
        </div>

        <div className="reveal mt-14 flex justify-center" style={reveal("0ms")}>
          <Link
            className="group inline-flex items-center gap-3 rounded-full border border-gold/50 px-7 py-3.5 text-gold-light transition-all hover:bg-gold hover:text-navy"
            href="/adhkar"
          >
            أذكار الصباح والمساء والأدعية
            <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" aria-hidden="true" />
          </Link>
        </div>
      </div>
      <svg viewBox="0 0 1440 80" preserveAspectRatio="none" className="pointer-events-none block h-10 w-full sm:h-16" aria-hidden="true">
        <path d="M0 80V40C240 40 420 0 720 0s480 40 720 40v40Z" fill="#F8F7F4" />
      </svg>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Journey (paths + quizzes)                                           */
/* ------------------------------------------------------------------ */
function JourneySection() {
  return (
    <section aria-labelledby="journey-title" className="relative bg-ivory py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="reveal mb-16 max-w-2xl" style={reveal("0ms")}>
          <Eyebrow>الرحلة التعليمية</Eyebrow>
          <h2 id="journey-title" className="mt-4 font-serif text-5xl leading-tight font-bold text-navy sm:text-6xl">
            درجاتٌ نحو <span className="text-royal">الفهم العميق</span>
          </h2>
          <p className="mt-4 leading-8 text-navy/65">اختر مسارك، تقدّم في دروسه خطوة بخطوة، ثم اختبر فهمك.</p>
        </div>

        <JourneyExplorer paths={PATHS} />
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Prayer times & Qibla                                                */
/* ------------------------------------------------------------------ */
function PrayerSection() {
  return (
    <section id="prayer" aria-labelledby="prayer-title" className="relative scroll-mt-20 overflow-hidden bg-navy-deep py-24 text-ivory sm:py-32">
      <div
        className="absolute inset-0 bg-[radial-gradient(ellipse_50%_40%_at_80%_10%,rgba(49,75,117,0.7),transparent_70%),radial-gradient(ellipse_40%_30%_at_10%_90%,rgba(182,154,105,0.15),transparent_70%)]"
        aria-hidden="true"
      />
      <div className="grain absolute inset-0 opacity-[0.05] mix-blend-overlay" aria-hidden="true" />
      <div className="pattern-lattice mask-radial absolute inset-0 opacity-[0.06]" aria-hidden="true" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="reveal mb-14 max-w-3xl" style={reveal("0ms")}>
          <Eyebrow light>في يومك</Eyebrow>
          <h2 id="prayer-title" className="mt-4 font-serif text-5xl leading-tight font-bold sm:text-6xl">
            مواقيت الصلاة <span className="text-gold-gradient">واتجاه القبلة</span>
          </h2>
          <p className="mt-4 leading-8 text-ivory/70">
            مواقيت اليوم حسب موقعك، مع الصلاة القادمة والعدّ التنازلي لها، واتجاه القبلة والمسافة إلى الكعبة المشرفة.
          </p>
        </div>

        <div className="reveal" style={reveal("100ms")}>
          <PrayerTimes />
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Identity                                                            */
/* ------------------------------------------------------------------ */
function IdentitySection() {
  const pillars = [
    { icon: BookOpenText, title: "بالعلم نرتقي", text: "محتوى موثوق من القرآن والسنة والسيرة." },
    { icon: HeartHandshake, title: "وبالذكر نطمئن", text: "أذكار وأدعية وتجربة تسبيح تفاعلية." },
    { icon: Sparkles, title: "وبالإيمان نحيا", text: "قيم تُعاش في السلوك والحياة اليومية." },
  ];

  return (
    <section aria-labelledby="identity-title" className="relative overflow-hidden bg-ivory py-24 sm:py-32">
      <div className="pattern-stars absolute inset-0 opacity-[0.08]" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="relative overflow-hidden rounded-[2.5rem] border border-gold/30 bg-gradient-to-br from-stone via-ivory to-stone shadow-[0_50px_100px_-50px_rgba(23,36,58,0.6)]">
          <div className="grid items-center lg:grid-cols-[1.1fr_1fr]">
            <div className="reveal relative z-10 p-8 sm:p-14" style={reveal("0ms")}>
              <Eyebrow>هوية المشروع</Eyebrow>
              <p className="mt-6 text-sm text-navy/50">مشروع</p>
              <h2 id="identity-title" className="font-serif text-6xl font-bold text-navy sm:text-7xl">
                {SITE.name}
              </h2>

              <dl className="mt-10 grid gap-6 sm:grid-cols-2">
                <div className="rounded-2xl border border-gold/30 bg-ivory/80 p-5">
                  <dt className="text-xs text-gold">إعداد الطالب</dt>
                  <dd className="mt-2 font-serif text-2xl font-bold text-navy">{SITE.author}</dd>
                </div>
                <div className="rounded-2xl border border-gold/30 bg-ivory/80 p-5">
                  <dt className="text-xs text-gold">المدرسة</dt>
                  <dd className="mt-2 font-serif text-2xl font-bold text-navy">{SITE.school}</dd>
                </div>
              </dl>

              <ul className="mt-10 space-y-4">
                {pillars.map(({ icon: Icon, title, text }) => (
                  <li key={title} className="flex items-start gap-4">
                    <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-navy text-gold-light">
                      <Icon className="size-5" aria-hidden="true" />
                    </span>
                    <div>
                      <p className="font-serif text-xl font-bold text-navy">{title}</p>
                      <p className="text-sm text-navy/60">{text}</p>
                    </div>
                  </li>
                ))}
              </ul>

              <Link
                className="mt-10 inline-flex items-center gap-3 rounded-full bg-navy px-8 py-4 font-semibold text-ivory transition-all hover:-translate-y-0.5 hover:bg-royal"
                href="/about"
              >
                <LogoMark className="size-5 text-gold" />
                تعرّف على المشروع
              </Link>
            </div>

            <div className="relative h-[26rem] bg-gradient-to-b from-navy to-navy-deep sm:h-[34rem] lg:h-full lg:min-h-[44rem]">
              <div className="pattern-lattice absolute inset-0 opacity-[0.1]" aria-hidden="true" />
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(182,154,105,0.3),transparent_55%)]" aria-hidden="true" />
              <div className="absolute inset-0 flex items-center justify-center" aria-hidden="true">
                <div className="size-40 animate-pulse rounded-full bg-gold/20 blur-3xl" />
              </div>
              <p className="absolute inset-x-0 bottom-8 text-center font-serif text-lg text-gold-light/80">
                ﴿وَقُل رَّبِّ زِدْنِي عِلْمًا﴾
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
