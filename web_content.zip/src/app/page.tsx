"use client";

import Link from "next/link";
import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Brain, Eye, Grid3X3, ArrowDown, Flame, Scale, Atom, Infinity as InfinityIcon } from "lucide-react";
import { Nav } from "@/components/Shell";
import { DOMAINS } from "@/lib/types";
import { TITLES } from "@/lib/ranks";
import { sfx } from "@/lib/sound";

const MindScene = dynamic(() => import("@/components/MindScene"), { ssr: false });

const ease = [0.22, 1, 0.36, 1] as const;

export default function Landing() {
  const [stats, setStats] = useState<{ trials: number; bosses: number; decisions: number; minds: number } | null>(null);
  const { scrollY } = useScroll();
  const heroY = useTransform(scrollY, [0, 800], [0, 220]);
  const heroOpacity = useTransform(scrollY, [0, 600], [1, 0]);

  useEffect(() => {
    fetch("/api/stats").then((r) => r.json()).then(setStats).catch(() => setStats(null));
  }, []);

  return (
    <main className="relative">
      <Nav />

      {/* ══════════ HERO ══════════ */}
      <section className="relative flex min-h-screen items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <MindScene />
        </div>
        <motion.div style={{ y: heroY, opacity: heroOpacity }} className="relative z-10 px-5 text-center">
          <motion.p
            initial={{ opacity: 0, letterSpacing: "1.2em" }}
            animate={{ opacity: 1, letterSpacing: "0.5em" }}
            transition={{ duration: 1.4, ease }}
            className="font-mono text-[11px] text-violet-x"
          >
            THE CRUCIBLE OF MINDS
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 0.25, ease }}
            className="mt-6 font-display text-[18vw] leading-[0.85] tracking-tight md:text-[11rem]"
          >
            AXIO<span className="italic text-violet-x text-glow-violet">M</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.2, delay: 0.8 }}
            className="mx-auto mt-8 max-w-xl text-balance font-display text-lg italic text-ash md:text-xl"
          >
            Not a game for players. A descent for the mind — built to make great minds sweat,
            doubt, and eventually, expand.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1.1, ease }}
            className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center"
          >
            <Link
              href="/descent"
              onMouseEnter={() => sfx.click()}
              className="btn-crucible border border-violet-x/70 px-12 py-5 font-mono text-sm tracking-[0.3em]"
            >
              PLAY — RING 1 FIRES INSTANTLY
            </Link>
            <Link
              href="/hall"
              className="border hairline px-10 py-4 font-mono text-xs tracking-[0.3em] text-ash transition-colors hover:border-amber-x/60 hover:text-amber-x"
            >
              WITNESS THE HALL
            </Link>
          </motion.div>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.35 }}
            className="mt-4 font-mono text-[10px] tracking-[0.3em] text-ash/70"
          >
            ONE CLICK · NO ACCOUNT · THE FIRST TRIAL HITS IN SECONDS
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.5 }}
            className="mt-12 flex items-center justify-center gap-6 font-mono text-[10px] tracking-[0.25em] text-ash"
          >
            <span><span className="text-ivory">{stats ? stats.trials.toLocaleString() : "——"}</span> TRIALS</span>
            <span className="text-violet-x">·</span>
            <span><span className="text-ivory">{stats ? stats.decisions : "——"}</span> CRUCIBLES</span>
            <span className="text-violet-x">·</span>
            <span><span className="text-ivory">{stats ? stats.bosses : "——"}</span> BOSSES</span>
            <span className="text-violet-x">·</span>
            <span>∞ RINGS</span>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.2 }}
          className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 text-ash"
        >
          <ArrowDown className="h-4 w-4 animate-bounce" />
        </motion.div>
      </section>

      {/* ══════════ MARQUEE ══════════ */}
      <section className="overflow-hidden border-y hairline py-4">
        <div className="marquee-track flex w-max gap-10 whitespace-nowrap font-mono text-[11px] tracking-[0.4em] text-ash">
          {Array.from({ length: 2 }).map((_, k) => (
            <div key={k} className="flex gap-10">
              {["PATTERN COGNITION", "DEEP SCIENCE", "STRATEGY & SYSTEMS", "PHILOSOPHY & PARADOX", "LATERAL CREATION", "IMAGINATIVE PHYSICS", "DECISION CRUCIBLE"].map((w) => (
                <span key={w} className="flex items-center gap-10">
                  <span>{w}</span>
                  <span className="text-violet-x">◈</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* ══════════ DOCTRINE ══════════ */}
      <section className="mx-auto max-w-6xl px-5 py-28">
        <motion.p
          initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
          className="font-mono text-[10px] tracking-[0.4em] text-violet-x"
        >
          THE DOCTRINE
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          transition={{ duration: 0.8, ease }}
          className="mt-4 max-w-3xl font-display text-4xl leading-tight md:text-6xl"
        >
          Scoreboards create <span className="text-ash line-through">players</span>.<br />
          This crucible forges <em className="text-glow-gold not-italic text-amber-x">minds</em>.
        </motion.h2>

        <div className="mt-16 grid gap-px bg-edge md:grid-cols-3">
          {[
            {
              icon: Brain, glyph: "◬", title: "LATERAL CREATION",
              body: "Out-of-the-box so far out the box forgets it existed. Constraint-collapse riddles, inversion puzzles, and the discipline of seeing what isn't there.",
              stat: "CREATIVITY",
            },
            {
              icon: Eye, glyph: "◍", title: "IMAGINATIVE PHYSICS",
              body: "Counterfactual worlds rendered with scientific rigor. Rewire gravity, delete friction, give Earth no Moon — then reason correctly inside the impossible.",
              stat: "IMAGINATION",
            },
            {
              icon: Grid3X3, glyph: "◈", title: "PATTERN & KNOWLEDGE",
              body: "Sequences that eat IQ tests for breakfast, deep science at researcher altitude, strategy at statesman depth. Structure beneath chaos, on demand.",
              stat: "RECOGNITION",
            },
          ].map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: i * 0.12, ease }}
              className="group panel p-8"
            >
              <div className="flex items-center justify-between">
                <p.icon className="h-6 w-6 text-violet-x transition-transform duration-500 group-hover:scale-125" />
                <span className="font-mono text-[10px] tracking-[0.3em] text-ash">{p.stat}</span>
              </div>
              <h3 className="mt-6 font-display text-2xl">{p.glyph} {p.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-ash">{p.body}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ══════════ SPHERES ══════════ */}
      <section className="border-t hairline bg-panel/40">
        <div className="mx-auto max-w-6xl px-5 py-28">
          <p className="font-mono text-[10px] tracking-[0.4em] text-violet-x">THE SEVEN SPHERES</p>
          <h2 className="mt-4 font-display text-4xl md:text-5xl">Six domains of trial.<br /><em className="text-ash">One arena of consequence.</em></h2>

          <div className="mt-14 grid gap-px bg-edge sm:grid-cols-2 lg:grid-cols-3">
            {DOMAINS.map((d, i) => (
              <motion.div
                key={d.id}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.08 }}
                className="panel group p-7 transition-colors hover:bg-violet-x/5"
              >
                <div className="flex items-baseline justify-between">
                  <span className="text-3xl text-violet-x">{d.glyph}</span>
                  <span className="font-mono text-[10px] tracking-[0.3em] text-ash">SPHERE {["I", "II", "III", "IV", "V", "VI"][i]}</span>
                </div>
                <h3 className="mt-5 font-display text-xl">{d.name}</h3>
                <p className="mt-2 font-mono text-[10px] tracking-[0.15em] text-ash uppercase">{d.epithet}</p>
              </motion.div>
            ))}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.48 }}
              className="panel panel-hot group p-7"
            >
              <div className="flex items-baseline justify-between">
                <Scale className="h-6 w-6 text-amber-x" />
                <span className="font-mono text-[10px] tracking-[0.3em] text-amber-x">SPHERE VII</span>
              </div>
              <h3 className="mt-5 font-display text-xl">Decision Crucible</h3>
              <p className="mt-2 font-mono text-[10px] tracking-[0.15em] text-ash uppercase">
                Real dilemmas. Hidden weightings. Cascading consequences.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ══════════ LADDER ══════════ */}
      <section className="border-t hairline">
        <div className="mx-auto max-w-6xl px-5 py-28">
          <div className="grid gap-16 md:grid-cols-[1fr_1.2fr]">
            <div>
              <p className="font-mono text-[10px] tracking-[0.4em] text-violet-x">THE LADDER OF MINDS</p>
              <h2 className="mt-4 font-display text-4xl md:text-5xl">Ten classifications.<br />One apex.</h2>
              <p className="mt-6 max-w-md text-sm leading-relaxed text-ash">
                Minds are not ranked — they are <span className="text-ivory">classified</span> like species of thought.
                Your Mind Index fuses the Three Pillars with the depth of your Descent and the ferocity of your streaks.
                At the summit waits a single word: <span className="text-amber-x">Apex</span>.
              </p>
              <div className="mt-8 flex items-center gap-3 font-mono text-[10px] tracking-[0.25em] text-ash">
                <Flame className="h-4 w-4 text-blood" />
                RING MASTERY ADDS +9 PER ASCENDED RING
              </div>
              <div className="mt-3 flex items-center gap-3 font-mono text-[10px] tracking-[0.25em] text-ash">
                <Atom className="h-4 w-4 text-violet-x" />
                BOSS TRIALS AMPLIFY XP BY 1.6×
              </div>
            </div>
            <div className="space-y-px bg-edge">
              {[...TITLES].reverse().map((t, i) => (
                <motion.div
                  key={t.title}
                  initial={{ opacity: 0, x: 24 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.04 }}
                  className="flex items-center justify-between gap-4 bg-void px-6 py-4"
                >
                  <div>
                    <p className={`font-display text-lg ${i === 0 ? "text-amber-x text-glow-gold" : ""}`}>{t.title}</p>
                    <p className="font-mono text-[10px] tracking-[0.2em] text-ash">{t.epithet.toUpperCase()}</p>
                  </div>
                  <div className="text-right font-mono text-[11px]">
                    <p className="text-ivory">≥ {t.min}</p>
                    {t.cls && <p className="text-violet-x">{t.cls.toUpperCase()}</p>}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ══════════ FINAL CTA ══════════ */}
      <section className="relative overflow-hidden border-t hairline">
        <div className="mx-auto max-w-4xl px-5 py-32 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, ease }}
          >
            <InfinityIcon className="mx-auto h-8 w-8 text-violet-x" />
            <h2 className="mt-8 font-display text-5xl leading-tight md:text-7xl">
              The chamber is <em className="text-glow-violet not-italic text-violet-x">already</em><br />assembled.
            </h2>
            <p className="mx-auto mt-6 max-w-lg text-balance text-sm leading-relaxed text-ash">
              {stats ? stats.trials.toLocaleString() : "1,100"}+ trials await. Each verdict teaches.
              Each ring deepens. The Hall remembers the minds that descend.
            </p>
            <Link
              href="/descent"
              className="btn-crucible mt-12 inline-block border border-violet-x/70 px-14 py-5 font-mono text-sm tracking-[0.35em]"
            >
              BEGIN DESCENT
            </Link>
          </motion.div>
        </div>
      </section>

      <footer className="border-t hairline">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-5 py-8 font-mono text-[10px] tracking-[0.3em] text-ash md:flex-row">
          <span>AXIOM — THE CRUCIBLE OF MINDS</span>
          <span>FOR AGES 21 → 50+. NO PARTICIPATION TROPHIES EXIST HERE.</span>
          <span className="flex items-center gap-6">
            <a href="/index.html" className="text-violet-x transition-colors hover:text-ivory">PORTABLE BUILD ↗</a>
            <span>MINDS OVER PLAYERS</span>
          </span>
        </div>
      </footer>
    </main>
  );
}
