"use client";

import { useMemo, useState } from "react";
import ErrorBoundary from "@/components/ErrorBoundary";
import { ToastProvider } from "@/components/Toast";
import { useApi } from "@/lib/client/useApi";
import { useConnectionHealth } from "@/lib/client/useConnectionHealth";
import { arr, fmtPct, fmtPrice, fmtTime } from "@/lib/format";
import SignalsScreen from "@/components/screens/SignalsScreen";
import CopyTradingScreen from "@/components/screens/CopyTradingScreen";
import PaperTradingScreen from "@/components/screens/PaperTradingScreen";
import ChartScreen from "@/components/screens/ChartScreen";
import HeatmapScreen from "@/components/screens/HeatmapScreen";
import ResearchScreen from "@/components/screens/ResearchScreen";
import FinanceScreen from "@/components/screens/FinanceScreen";
import NotificationsBell from "@/components/NotificationsBell";

type TabKey = "signals" | "copy" | "paper" | "chart" | "heatmap" | "research" | "finance";

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: "signals", label: "אותות ועצות מסחר", icon: "🎯" },
  { key: "copy", label: "חיקוי עסקאות סוחרים", icon: "👥" },
  { key: "paper", label: "מסחר דמו / ניסיון", icon: "🧪" },
  { key: "chart", label: "גרפים וספר פקודות", icon: "📈" },
  { key: "heatmap", label: "מפת שוק", icon: "🗺️" },
  { key: "research", label: "מחקר עומק", icon: "🔬" },
  { key: "finance", label: "פיננסים, מיסוי ודוחות", icon: "🧾" },
];

type OverviewResponse = {
  ok?: boolean;
  source?: string;
  tickers?: { symbol: string; price: number; change24h: number }[];
  fearGreed?: { value: number; hebrew: string; classification: string };
};

export default function Home() {
  const [tab, setTab] = useState<TabKey>("signals");
  const health = useConnectionHealth(12000);
  const overview = useApi<OverviewResponse>("/api/market/overview", { intervalMs: 20000 });

  const tickers = arr<{ symbol: string; price: number; change24h: number }>(overview.data?.tickers);
  const fng = overview.data?.fearGreed;

  const badge = useMemo(() => {
    switch (health.status) {
      case "online":
        return { dot: "🟢", cls: "border-emerald-500/50 bg-emerald-500/10 text-emerald-300" };
      case "slow":
        return { dot: "🟡", cls: "border-amber-500/50 bg-amber-500/10 text-amber-300" };
      case "backup":
        return { dot: "🟠", cls: "border-orange-500/50 bg-orange-500/10 text-orange-300" };
      case "offline":
        return { dot: "🔴", cls: "border-rose-500/50 bg-rose-500/10 text-rose-300" };
      default:
        return { dot: "⚪", cls: "border-slate-600 bg-slate-800/50 text-slate-300" };
    }
  }, [health.status]);

  return (
    <ToastProvider>
      <ErrorBoundary title="שגיאה כללית באפליקציה - לחץ לנסות שוב">
        <div className="mx-auto flex min-h-screen max-w-7xl flex-col pb-28">
          <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/95 backdrop-blur">
            <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">₿</span>
                <div>
                  <h1 className="text-sm font-black leading-tight text-slate-100">סורק הקריפטו החכם</h1>
                  <p className="text-[10px] text-slate-500">
                    מקור נתונים: {String(overview.data?.source ?? health.marketSource ?? "—")} · עדכון{" "}
                    {overview.lastUpdated ? fmtTime(new Date(overview.lastUpdated)) : "—"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {fng ? (
                  <div className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-1 text-[11px]">
                    <span className="text-slate-400">פחד/חמדנות: </span>
                    <span
                      className={`font-bold ${
                        fng.value >= 55 ? "text-emerald-400" : fng.value <= 44 ? "text-rose-400" : "text-amber-400"
                      }`}
                    >
                      {fng.value} · {fng.hebrew}
                    </span>
                  </div>
                ) : null}
                <NotificationsBell />
                <button
                  onClick={() => void health.ping()}
                  className={`rounded-xl border px-3 py-1 text-[11px] font-bold transition ${badge.cls}`}
                  title={`השהיה ${health.latency}ms · כשלונות ${health.failures} · חיבורים מחדש ${health.reconnects}`}
                >
                  {badge.dot} {health.label}
                </button>
              </div>
            </div>

            <div className="flex gap-4 overflow-x-auto border-t border-slate-800/70 px-4 py-1 text-[11px] tabular-nums">
              {tickers.slice(0, 12).map((t) => (
                <span key={t.symbol} className="whitespace-nowrap text-slate-400">
                  {t.symbol.replace("USDT", "")}{" "}
                  <span className="text-slate-200">{fmtPrice(t.price)}</span>{" "}
                  <span className={t.change24h >= 0 ? "text-emerald-400" : "text-rose-400"}>{fmtPct(t.change24h)}</span>
                </span>
              ))}
              {tickers.length === 0 && <span className="text-slate-500">טוען נתוני שוק...</span>}
            </div>
          </header>

          <main className="flex-1 px-3 py-4">
            <ErrorBoundary key={tab}>
              {tab === "signals" && <SignalsScreen />}
              {tab === "copy" && <CopyTradingScreen />}
              {tab === "paper" && <PaperTradingScreen />}
              {tab === "chart" && <ChartScreen />}
              {tab === "heatmap" && <HeatmapScreen />}
              {tab === "research" && <ResearchScreen />}
              {tab === "finance" && <FinanceScreen />}
            </ErrorBoundary>
          </main>

          <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-800 bg-slate-950/98 backdrop-blur">
            <div className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-2 py-2">
              {TABS.map((t) => (
                <button
                  key={t.key}
                  onClick={() => setTab(t.key)}
                  className={`flex min-w-[104px] flex-1 flex-col items-center gap-1 rounded-xl px-2 py-2 text-[10px] font-bold transition ${
                    tab === t.key
                      ? "bg-sky-500/15 text-sky-300 ring-1 ring-sky-500/40"
                      : "text-slate-400 hover:bg-slate-900"
                  }`}
                >
                  <span className="text-lg">{t.icon}</span>
                  <span className="text-center leading-tight">{t.label}</span>
                </button>
              ))}
            </div>
          </nav>
        </div>
      </ErrorBoundary>
    </ToastProvider>
  );
}
