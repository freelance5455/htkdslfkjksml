import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { desc } from "drizzle-orm";
import HeroSection from "@/components/HeroSection";
import CalculatorSection from "@/components/CalculatorSection";
import Marketplace from "@/components/Marketplace";
import type { ProductCardData } from "@/components/ProductCard";

export const dynamic = "force-dynamic";

const FEATURES = [
  {
    icon: "🧮",
    title: "Real 3D Models",
    desc: "Every product is rendered as an interactive 3D model you can rotate and inspect from every angle.",
  },
  {
    icon: "⚡",
    title: "Instant Calculations",
    desc: "Our futuristic calculator engine performs real-time math with sound, vibration and history.",
  },
  {
    icon: "🚚",
    title: "Nationwide Delivery",
    desc: "Cash on delivery available across Bangladesh. Track your order in real time from your phone.",
  },
  {
    icon: "🛡️",
    title: "Premium Warranty",
    desc: "Every CALCORA model ships with a 1-year warranty and 7-day easy return policy.",
  },
];

export default async function HomePage() {
  const [allProducts, allCategories] = await Promise.all([
    db.select().from(products).orderBy(desc(products.id)),
    db.select().from(categories),
  ]);

  const productData: ProductCardData[] = allProducts.map((p) => ({
    id: p.id,
    name: p.name,
    modelNumber: p.modelNumber,
    category: p.category,
    price: p.price,
    description: p.description,
    image: p.image,
    status: p.status,
    isFeatured: p.isFeatured,
    isBestSeller: p.isBestSeller,
    isNewArrival: p.isNewArrival,
  }));

  const categoryNames = allCategories.map((c) => c.name);

  return (
    <>
      {/* HERO */}
      <HeroSection />

      {/* CALCULATOR */}
      <div className="relative bg-futuristic">
        <CalculatorSection />
      </div>

      {/* MARKETPLACE */}
      <section id="models" className="relative py-24">
        <div className="pointer-events-none absolute left-1/2 top-0 h-64 w-2/3 -translate-x-1/2 rounded-full bg-purple-600/10 blur-[120px]" />
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-12 text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.3em] text-purple-400">Premium Model Collection</p>
            <h2 className="mt-3 font-display text-4xl font-bold text-white md:text-5xl">Choose Your <span className="text-gradient">Machine</span></h2>
            <p className="mx-auto mt-4 max-w-2xl text-slate-400">
              From Standard to Special Edition — explore our full collection of futuristic calculators.
              Search, filter and sort to find the perfect model for you.
            </p>
          </div>
          <Marketplace products={productData} categories={categoryNames} />
        </div>
      </section>

      {/* FEATURES */}
      <section className="relative py-20">
        <div className="mx-auto max-w-7xl px-4">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="glass group rounded-3xl p-6 transition duration-300 hover:-translate-y-1.5 hover:border-purple-400/40 hover:shadow-[0_0_35px_rgba(139,92,246,0.2)]"
              >
                <span className="text-3xl">{f.icon}</span>
                <h3 className="mt-4 font-display text-lg font-bold text-white">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-24">
        <div className="mx-auto max-w-5xl px-4">
          <div className="glass glow-purple relative overflow-hidden rounded-[2rem] px-6 py-16 text-center">
            <div className="bg-grid absolute inset-0 opacity-60" />
            <div className="relative z-10">
              <h2 className="font-display text-3xl font-black text-white md:text-5xl">
                Ready to <span className="text-gradient">Calculate</span> Smarter?
              </h2>
              <p className="mx-auto mt-4 max-w-xl text-slate-300">
                Join thousands of users who already upgraded to a premium CALCORA 3D model.
                Order now with cash on delivery.
              </p>
              <div className="mt-8 flex flex-col justify-center gap-4 sm:flex-row">
                <a
                  href="#models"
                  className="rounded-2xl bg-gradient-to-r from-purple-500 to-blue-600 px-8 py-4 font-bold text-white shadow-[0_0_30px_rgba(139,92,246,0.5)] transition hover:brightness-110"
                >
                  Shop All Models
                </a>
                <a
                  href="/orders"
                  className="rounded-2xl border border-white/20 bg-white/5 px-8 py-4 font-bold text-white transition hover:border-purple-400/60"
                >
                  Track Your Order
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}