import HomeClient from "@/components/HomeClient";
import { getAttractions } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function Home() {
  const attractions = await getAttractions();
  return <HomeClient attractions={attractions} />;
}
