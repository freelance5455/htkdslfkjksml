import Link from "next/link";
import { redirect } from "next/navigation";
import PlanCards from "@/components/PlanCards";
import { getSessionUser } from "@/lib/auth/session";
import { getPlans } from "@/lib/plans";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const FEATURES = [
  { emoji: "🎯", title: "Viral Title Generator", body: "Title variations tuned per platform: YouTube, Shorts, TikTok, Reels." },
  { emoji: "🪝", title: "Hook Generator", body: "First 3 seconds, curiosity, story, suspense, educational and debate openers." },
  { emoji: "🎬", title: "AI Script Writer", body: "15s, 30s, 60s and long-form scripts with sections and CTAs." },
  { emoji: "✍️", title: "Caption Generator", body: "Short, emotional, funny, suspenseful or professional captions." },
  { emoji: "#️⃣", title: "Hashtag Generator", body: "Broad, niche and long-tail sets matched to your topic." },
  { emoji: "🖼️", title: "Thumbnail Text", body: "Concise 3–5 word overlays plus pairing suggestions." },
  { emoji: "💡", title: "Content Idea Engine", body: "Angles and formats across 11+ niches, from gaming to finance." },
  { emoji: "🗓️", title: "Content Calendar", body: "7, 30 or 90 day plans with posting schedule included." },
  { emoji: "🔍", title: "Content Analyzer", body: "Strengths, weaknesses, clarity fixes, engagement ideas, rewrites." },
];

export default async function LandingPage() {
  const user = await getSessionUser();
  if (user) redirect("/home");
  const [plans, settings] = await Promise.all([getPlans(), getSettings()]);

  return (
    <main className="mx-auto w-full max-w-5xl px-4 pb-16 pt-6">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-lg">🛠️</span>
          <span className="text-sm font-bold">{settings.brandName}</span>
        </div>
        <nav className="flex items-center gap-2">
          <Link href="/login" className="btn btn-ghost btn-sm">
            Sign in
          </Link>
          <Link href="/signup" className="btn btn-primary btn-sm">
            Start free
          </Link>
        </nav>
      </header>

      <section className="mt-10 text-center">
        <span className="chip mx-auto">{settings.announcement}</span>
        <h1 className="mt-4 text-4xl font-black leading-[1.05] sm:text-6xl">
          Create better content
          <br />
          <span className="gradient-text">in minutes.</span>
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-sm text-[color:var(--muted)] sm:text-base">
          Nine AI tools for YouTube, Shorts, TikTok and Instagram Reels. Titles, hooks, scripts, captions, hashtags,
          thumbnails, ideas, calendars and analysis — all in one fast, mobile-first workspace.
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
          <Link href="/signup" className="btn btn-primary">
            Start free — no card needed
          </Link>
          <Link href="/pricing" className="btn btn-ghost">
            See pricing
          </Link>
        </div>
        <p className="mt-3 text-xs text-[color:var(--muted)]">
          Suggestions, not guarantees — you stay in control of what you publish.
        </p>
      </section>

      <section className="mt-14">
        <h2 className="text-center text-sm font-semibold uppercase tracking-[0.2em] text-[color:var(--muted)]">
          Everything in one toolkit
        </h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="card card-hover p-4">
              <span className="text-2xl">{f.emoji}</span>
              <h3 className="mt-2 font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-[color:var(--muted)]">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-14">
        <h2 className="text-center text-sm font-semibold uppercase tracking-[0.2em] text-[color:var(--muted)]">Pricing</h2>
        <div className="mt-4">
          <PlanCards plans={plans} signedIn={false} />
        </div>
      </section>

      <section className="card mt-14 p-5">
        <h2 className="text-lg font-bold">Built for how creators actually work</h2>
        <div className="mt-3 grid gap-4 sm:grid-cols-3">
          <div>
            <p className="font-semibold">Mobile-first</p>
            <p className="text-sm text-[color:var(--muted)]">Generate on your phone between takes; everything syncs to your library.</p>
          </div>
          <div>
            <p className="font-semibold">Save, copy, edit</p>
            <p className="text-sm text-[color:var(--muted)]">Keep the winners, remix them later, delete what you don&apos;t need.</p>
          </div>
          <div>
            <p className="font-semibold">Fair usage</p>
            <p className="text-sm text-[color:var(--muted)]">Credits are tracked server-side per account, so limits stay honest.</p>
          </div>
        </div>
      </section>

      <footer className="mt-12 text-center text-xs text-[color:var(--muted)]">
        {settings.brandName} · AI outputs are creative suggestions. Results are never guaranteed.
      </footer>
    </main>
  );
}
