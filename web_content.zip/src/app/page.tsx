"use client";

import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  ErrorBoundary,
  LoadingSkeletonHe,
} from "../components/ErrorBoundary";
import { useConnectionHealth } from "../services/useConnectionHealth";
import {
  tradeTapeService,
  TradeTapeExecution,
  OrderBookLevel,
} from "../services/tradeTapeService";
import {
  notificationsService,
  MobilePushAlert,
} from "../services/notificationsService";
import {
  OHLCVCandle,
  CoinTechnicalAnalysis,
  formatPriceNumber,
} from "../services/technicalEngine";
import {
  fetchMarketDataSmart,
  initMobilePolyfills,
  isMobileOrFileWebView,
} from "../services/mobileNetworkService";
import { McpConversationalAgent } from "../components/McpConversationalAgent";
import { CandlestickTerminal } from "../components/CandlestickTerminal";
import { CopyTradingModule } from "../components/CopyTradingModule";
import {
  PaperTradingModule,
  PaperPositionItem,
  PaperLimitOrderItem,
} from "../components/PaperTradingModule";
import { FinvizHeatmapModule } from "../components/FinvizHeatmapModule";
import { MessariResearchModule } from "../components/MessariResearchModule";
import {
  InvoappTaxModule,
  TaxInvoiceItem,
} from "../components/InvoappTaxModule";
import {
  EvaluatorAgentPanel,
  EvaluatorLogRecord,
} from "../components/EvaluatorAgentModal";
import { KumoRelationalModule } from "../components/KumoRelationalModule";
import { NvidiaNimVisionPanel } from "../components/NvidiaNimVisionPanel";
import {
  Bot,
  Radar,
  Users,
  Wallet,
  CandlestickChart,
  Flame,
  Landmark,
  RefreshCw,
  Bell,
  Smartphone,
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Download,
  X,
} from "lucide-react";

type MainTabKey =
  | "MCP_AI_CHAT"
  | "SCALPING_SCANNER"
  | "PAPER_BACKTEST"
  | "CHARTS_ORDERBOOK"
  | "COPY_TRADING"
  | "MARKET_HEATMAP"
  | "FINANCE_TAX";

interface EnrichedCoinAnalysis extends CoinTechnicalAnalysis {
  nameHe: string;
  sectorHe: string;
  marketCapBillions: number;
  messariMetrics: {
    activeWallets24h: number;
    onChainVolume24hMillions: number;
    supplyInflationAnnualPct: number;
    githubCommits30d: number;
    activeDevelopers: number;
    nextUnlockSummaryHe: string;
    aiSummaryHe: string;
    institutionalRating: string;
  };
}

const NAVIGATION_TABS: Array<{
  key: MainTabKey;
  labelHe: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  {
    key: "MCP_AI_CHAT",
    labelHe: "סוחר AI ומסחר בצ'אט",
    icon: Bot,
  },
  {
    key: "SCALPING_SCANNER",
    labelHe: "אותות וסורק סקאלפינג",
    icon: Radar,
  },
  {
    key: "PAPER_BACKTEST",
    labelHe: "מסחר דמו ו-Backtest",
    icon: Wallet,
  },
  {
    key: "CHARTS_ORDERBOOK",
    labelHe: "גרפים, ספר פקודות ו-Tape",
    icon: CandlestickChart,
  },
  {
    key: "COPY_TRADING",
    labelHe: "חיקוי סוחרי יום",
    icon: Users,
  },
  {
    key: "MARKET_HEATMAP",
    labelHe: "מפת שוק וסנטימנט",
    icon: Flame,
  },
  {
    key: "FINANCE_TAX",
    labelHe: "יומן עסקאות ומיסוי",
    icon: Landmark,
  },
];

export default function CryptoScannerTradingHubApp() {
  const [activeTab, setActiveTab] = useState<MainTabKey>("MCP_AI_CHAT");
  const [focusSymbol, setFocusSymbol] = useState<string>("BTCUSDT");
  const [signalFilter, setSignalFilter] = useState<"ALL" | "LONG" | "SHORT">(
    "ALL"
  );
  const [scalpTimeframe, setScalpTimeframe] = useState<"1m" | "5m" | "15m">(
    "5m"
  );
  const [dailyCircuitBreakerPct, setDailyCircuitBreakerPct] =
    useState<number>(2.5);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const syncFromHash = () => {
      const rawHash = window.location.hash.replace(/^#\/?/, "").toUpperCase();
      const validTab = NAVIGATION_TABS.find((t) => t.key === rawHash);
      if (validTab) {
        setActiveTab(validTab.key);
      }
    };
    syncFromHash();
    window.addEventListener("hashchange", syncFromHash);
    return () => window.removeEventListener("hashchange", syncFromHash);
  }, []);

  const handleSelectMainTab = useCallback((tabKey: MainTabKey) => {
    setActiveTab(tabKey);
    if (typeof window !== "undefined") {
      window.location.hash = `#/${tabKey}`;
    }
  }, []);

  // Market Data State
  const [coins, setCoins] = useState<EnrichedCoinAnalysis[]>([]);
  const [focusCandles, setFocusCandles] = useState<OHLCVCandle[]>([]);
  const [orderBook, setOrderBook] = useState<{
    symbol: string;
    midPrice: number;
    spreadPct: number;
    asks: OrderBookLevel[];
    bids: OrderBookLevel[];
  }>({
    symbol: "BTCUSDT",
    midPrice: 94280,
    spreadPct: 0.04,
    asks: [],
    bids: [],
  });
  const [fearGreed, setFearGreed] = useState({
    value: 64,
    labelHe: "תאוות בצע (Greed)",
    yesterdayValue: 61,
    lastWeekValue: 57,
  });
  const [proxySource, setProxySource] = useState<string>(
    "BINANCE_PUBLIC_PRIMARY"
  );
  const [proxyLatencyMs, setProxyLatencyMs] = useState<number>(34);

  // Database Trading Hub State
  const [virtualBalanceUsdt, setVirtualBalanceUsdt] = useState<number>(10000);
  const [realizedPnlUsdt, setRealizedPnlUsdt] = useState<number>(0);
  const [rollingWinRatePct, setRollingWinRatePct] = useState<number>(78.6);
  const [strictMode, setStrictMode] = useState<boolean>(false);
  const [minConfluenceThreshold, setMinConfluenceThreshold] =
    useState<number>(74);

  const [openPositions, setOpenPositions] = useState<PaperPositionItem[]>([]);
  const [closedPositions, setClosedPositions] = useState<PaperPositionItem[]>(
    []
  );
  const [limitOrders, setLimitOrders] = useState<PaperLimitOrderItem[]>([]);
  const [copiedTraders, setCopiedTraders] = useState<
    Array<{
      traderId: string;
      allocatedBudgetUsdt: number;
      stopLossPct: number;
      maxLeverage: number;
      isActive: boolean;
      totalCopiedTrades: number;
      copiedPnlUsdt: number;
    }>
  >([]);
  const [evaluatorLogs, setEvaluatorLogs] = useState<EvaluatorLogRecord[]>([]);
  const [taxInvoices, setTaxInvoices] = useState<TaxInvoiceItem[]>([]);

  // Real-time WebSocket Trade Tape & Push Notifications
  const [tradeTape, setTradeTape] = useState<TradeTapeExecution[]>([]);
  const [pushAlerts, setPushAlerts] = useState<MobilePushAlert[]>([
    {
      id: "INIT-PUSH-1",
      category: "HIGH_CONFLUENCE_SIGNAL",
      titleHe: "איתות סקאלפינג 5m בעל קונפלואנס גבוה (88%)",
      bodyHe:
        "BTCUSDT: פריצת VWAP ($94,110) + חציית EMA 9/20 ו-Order Flow חיובי. המלצת קלי: סיכון 1% מהתיק (4x לונג).",
      symbol: "BTCUSDT",
      confluenceScore: 88,
      timestamp: Date.now() - 120000,
      isRead: false,
    },
  ]);
  const [showNotificationsDrawer, setShowNotificationsDrawer] =
    useState<boolean>(false);
  const [showApkConfigModal, setShowApkConfigModal] = useState<boolean>(false);

  // Loading, Error & Toast States
  const [initialLoading, setInitialLoading] = useState<boolean>(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [offlineBannerHe, setOfflineBannerHe] = useState<string | null>(null);
  const [isManualScanning, setIsManualScanning] = useState<boolean>(false);
  const [toastHe, setToastHe] = useState<string | null>(null);
  const [nextPollSeconds, setNextPollSeconds] = useState<number>(300);

  const connectionHealth = useConnectionHealth(proxySource, proxyLatencyMs);

  const showHebrewToast = useCallback((msg: string) => {
    setToastHe(msg);
    setTimeout(() => {
      setToastHe((current) => (current === msg ? null : current));
    }, 4500);
  }, []);

  const fetchAllData = useCallback(
    async (symbolToFetch = focusSymbol, isManual = false) => {
      try {
        initMobilePolyfills();
        if (isManual) setIsManualScanning(true);
        setLoadError(null);

        const [marketJson, dbJson] = await Promise.all([
          fetchMarketDataSmart(symbolToFetch, virtualBalanceUsdt, strictMode),
          isMobileOrFileWebView()
            ? Promise.resolve(null)
            : fetch("/api/trading-hub", { cache: "no-store" })
                .then((r) => (r.ok ? r.json() : null))
                .catch(() => null),
        ]);

        if (marketJson?.isOfflineCached && marketJson?.offlineMessageHe) {
          setOfflineBannerHe(marketJson.offlineMessageHe);
        } else {
          setOfflineBannerHe(null);
        }

        if (Array.isArray(marketJson?.coins)) {
          setCoins(marketJson.coins);
        }
        if (Array.isArray(marketJson?.focusCandles)) {
          setFocusCandles(marketJson.focusCandles);
        }
        if (marketJson?.orderBook) {
          setOrderBook(marketJson.orderBook);
        }
        if (marketJson?.fearGreed) {
          setFearGreed(marketJson.fearGreed);
        }
        if (marketJson?.source) {
          setProxySource(marketJson.source);
        }
        if (marketJson?.latencyMs) {
          setProxyLatencyMs(marketJson.latencyMs);
        }

        if (dbJson?.ok) {
          if (dbJson.account) {
            setVirtualBalanceUsdt(
              Number(dbJson.account.virtualBalanceUsdt ?? 10000)
            );
            setRealizedPnlUsdt(Number(dbJson.account.realizedPnlUsdt ?? 0));
            setRollingWinRatePct(
              Number(dbJson.account.rollingWinRatePct ?? 78.6)
            );
            setStrictMode(Boolean(dbJson.account.evaluatorStrictMode));
            setMinConfluenceThreshold(
              Number(dbJson.account.minConfluenceThreshold ?? 74)
            );
          }
          setOpenPositions(
            Array.isArray(dbJson.openPositions) ? dbJson.openPositions : []
          );
          setClosedPositions(
            Array.isArray(dbJson.closedPositions) ? dbJson.closedPositions : []
          );
          setLimitOrders(
            Array.isArray(dbJson.limitOrders) ? dbJson.limitOrders : []
          );
          setCopiedTraders(
            Array.isArray(dbJson.copiedTraders) ? dbJson.copiedTraders : []
          );
          setEvaluatorLogs(
            Array.isArray(dbJson.evaluatorLogs) ? dbJson.evaluatorLogs : []
          );
          setTaxInvoices(
            Array.isArray(dbJson.taxInvoices) ? dbJson.taxInvoices : []
          );
        }

        if (isManual && Array.isArray(marketJson?.coins)) {
          const highConf = marketJson.coins.find(
            (c: EnrichedCoinAnalysis) =>
              c.confluenceScore >= 80 && c.recommendation !== "WAIT"
          );
          if (highConf) {
            const alert = notificationsService.dispatchPushAlert({
              category: "HIGH_CONFLUENCE_SIGNAL",
              titleHe: `התראת סקאלפינג AI: ${highConf.symbol} (${highConf.recommendationLabelHe})`,
              bodyHe: `ציון קונפלואנס ${highConf.confluenceScore}% | VWAP: $${formatPriceNumber(
                highConf.vwap
              )} | יעד TP1: $${formatPriceNumber(highConf.takeProfit1)}`,
              symbol: highConf.symbol,
              confluenceScore: highConf.confluenceScore,
            });
            setPushAlerts((prev) => [alert, ...prev.slice(0, 19)]);
          }
          showHebrewToast("הסריקה הושלמה בהצלחה");
        }
      } catch (err) {
        console.error("Fetch error:", err);
        setLoadError("שגיאה בטעינת הנתונים - לחץ לנסות שוב");
      } finally {
        setInitialLoading(false);
        setIsManualScanning(false);
        setNextPollSeconds(300);
      }
    },
    [focusSymbol, virtualBalanceUsdt, strictMode, showHebrewToast]
  );

  const handleManualScan = async () => {
    await fetchAllData(focusSymbol, true);
  };

  useEffect(() => {
    fetchAllData(focusSymbol, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusSymbol]);

  useEffect(() => {
    const countdownTimer = setInterval(() => {
      setNextPollSeconds((prev) => {
        if (prev <= 1) {
          fetchAllData(focusSymbol, false);
          return 300;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(countdownTimer);
  }, [fetchAllData, focusSymbol]);

  const focusedCoinRef = useRef<number>(94280);
  useEffect(() => {
    const found = coins.find((c) => c.symbol === focusSymbol);
    if (found && found.currentPrice > 0) {
      focusedCoinRef.current = found.currentPrice;
    }
  }, [coins, focusSymbol]);

  useEffect(() => {
    tradeTapeService.startStream(
      focusSymbol,
      focusedCoinRef.current,
      (trade) => {
        setTradeTape((prev) => [trade, ...prev.slice(0, 29)]);
      },
      (sym, livePrice) => {
        setCoins((prevCoins) =>
          prevCoins.map((c) =>
            c.symbol === sym ? { ...c, currentPrice: livePrice } : c
          )
        );
      }
    );

    return () => {
      tradeTapeService.stopStream();
    };
  }, [focusSymbol]);

  const handleOpenMarketPosition = async (payload: {
    symbol: string;
    side: "LONG" | "SHORT";
    entryPrice: number;
    sizeUsdt: number;
    leverage: number;
    stopLoss: number;
    takeProfit: number;
    copiedFromTrader?: string;
  }) => {
    try {
      const res = await fetch("/api/trading-hub", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "OPEN_MARKET_POSITION",
          ...payload,
        }),
      });
      const json = await res.json();
      if (json.ok) {
        showHebrewToast(json.messageHe || "העסקה בוצעה בהצלחה בתיק הדמו");
        const alert = notificationsService.dispatchPushAlert({
          category: "SL_TP_TRIGGERED",
          titleHe: `פוזיציית דמו נפתחה: ${payload.symbol} (${payload.side})`,
          bodyHe: `בטחונות: $${payload.sizeUsdt} במינוף ${payload.leverage}x | מחיר כניסה: $${formatPriceNumber(
            payload.entryPrice
          )}`,
          symbol: payload.symbol,
        });
        setPushAlerts((prev) => [alert, ...prev.slice(0, 19)]);
        await fetchAllData(focusSymbol, false);
        return;
      }
    } catch {
      // Fallback for standalone mobile APK (`file://`)
    }
    showHebrewToast(
      `בוצע בדמו: ${payload.side} על ${payload.symbol} ($${payload.sizeUsdt} x ${payload.leverage})`
    );
  };

  const handlePlaceLimitOrder = async (payload: {
    symbol: string;
    side: "LONG" | "SHORT";
    limitPrice: number;
    sizeUsdt: number;
    leverage: number;
    stopLoss: number;
    takeProfit: number;
  }) => {
    try {
      const res = await fetch("/api/trading-hub", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "PLACE_LIMIT_ORDER",
          ...payload,
        }),
      });
      const json = await res.json();
      if (json.ok) {
        showHebrewToast(json.messageHe);
        await fetchAllData(focusSymbol, false);
        return;
      }
    } catch {
      // mobile fallback
    }
    showHebrewToast(`פקודת לימיט נרשמה עבור ${payload.symbol}`);
  };

  const handleCancelLimitOrder = async (orderId: number) => {
    try {
      const res = await fetch("/api/trading-hub", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "CANCEL_LIMIT_ORDER",
          orderId,
        }),
      });
      const json = await res.json();
      if (json.ok) {
        showHebrewToast(json.messageHe);
        await fetchAllData(focusSymbol, false);
      }
    } catch {
      showHebrewToast("פקודת הלימיט בוטלה");
    }
  };

  const handleClosePosition = async (positionId: number, exitPrice: number) => {
    try {
      const res = await fetch("/api/trading-hub", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "CLOSE_POSITION",
          positionId,
          exitPrice,
        }),
      });
      const json = await res.json();
      if (json.ok) {
        showHebrewToast(json.messageHe);
        await fetchAllData(focusSymbol, false);
      }
    } catch {
      showHebrewToast("הפוזיציה נסגרה");
    }
  };

  const handleToggleCopyTrader = async (payload: {
    traderId: string;
    traderName: string;
    allocatedBudgetUsdt: number;
    stopLossPct: number;
    maxLeverage: number;
    mirrorSymbol: string;
    mirrorPrice: number;
  }) => {
    try {
      const res = await fetch("/api/trading-hub", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "TOGGLE_COPY_TRADER",
          ...payload,
        }),
      });
      const json = await res.json();
      if (json.ok) {
        showHebrewToast(json.messageHe);
        const alert = notificationsService.dispatchPushAlert({
          category: "COPY_TRADE_EXECUTED",
          titleHe: `חיקוי סוחרי יום: ${payload.traderName}`,
          bodyHe: json.messageHe,
          symbol: payload.mirrorSymbol,
        });
        setPushAlerts((prev) => [alert, ...prev.slice(0, 19)]);
        await fetchAllData(focusSymbol, false);
      }
    } catch {
      showHebrewToast(`שכפול עסקאות הופעל עבור ${payload.traderName}`);
    }
  };

  const handleRunEvaluatorAudit = async () => {
    const focused = coins.find((c) => c.symbol === focusSymbol) || coins[0];
    try {
      const res = await fetch("/api/trading-hub", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "RUN_EVALUATOR_AUDIT",
          symbol: focused?.symbol || "BTCUSDT",
          currentPrice: focused?.currentPrice || 94280,
          adxValue: focused?.adx14 || 24.5,
          rsiValue: focused?.rsi14 || 58.0,
          volumeRatio: focused?.volumeProfile?.volumeSpikeRatio || 1.25,
        }),
      });
      const json = await res.json();
      if (json.ok) {
        showHebrewToast(json.messageHe);
        await fetchAllData(focusSymbol, false);
      }
    } catch {
      showHebrewToast("סריקת Evaluator הושלמה");
    }
  };

  const handleCreateTaxInvoice = async (payload: {
    clientOrExchange: string;
    descriptionHe: string;
    amountUsdt: number;
    usdIlsRate: number;
    taxType: "capital_gains_25" | "business_income";
  }) => {
    try {
      const res = await fetch("/api/trading-hub", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "CREATE_TAX_INVOICE",
          ...payload,
        }),
      });
      const json = await res.json();
      if (json.ok) {
        showHebrewToast(json.messageHe);
        await fetchAllData(focusSymbol, false);
      }
    } catch {
      showHebrewToast("חשבונית מס נרשמה ביומן טופס 909");
    }
  };

  const handleResetDemoAccount = async () => {
    try {
      const res = await fetch("/api/trading-hub", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "RESET_DEMO_ACCOUNT" }),
      });
      const json = await res.json();
      if (json.ok) {
        showHebrewToast(json.messageHe);
        await fetchAllData(focusSymbol, false);
      }
    } catch {
      setVirtualBalanceUsdt(10000);
      showHebrewToast("תיק הדמו אופס ל-$10,000 USDT");
    }
  };

  const safeCoins = Array.isArray(coins) ? coins : [];
  const filteredSignalCoins =
    signalFilter === "ALL"
      ? safeCoins
      : safeCoins.filter((c) => c.recommendation === signalFilter);

  const focusedCoinObj =
    safeCoins.find((c) => c.symbol === focusSymbol) || safeCoins[0];

  const livePricesMap: Record<string, number> = {};
  for (const c of safeCoins) {
    livePricesMap[c.symbol] = c.currentPrice;
  }

  const totalUnrealizedPnl = (
    Array.isArray(openPositions) ? openPositions : []
  ).reduce((acc, p) => {
    const mark = livePricesMap[p.symbol] || p.entryPrice;
    const diff = p.side === "LONG" ? mark - p.entryPrice : p.entryPrice - mark;
    return acc + diff * p.quantity;
  }, 0);

  return (
    <ErrorBoundary
      sectionTitleHe="מסוף מסחר יומי וסוכן MCP AI הראשי"
      onRetry={() => fetchAllData(focusSymbol, true)}
    >
      <div dir="rtl" className="min-h-screen bg-[#0B0E14] text-[#F1F5F9]">
        {/* Hebrew Toast Notification Banner */}
        {toastHe && (
          <div className="fixed bottom-6 left-6 z-50 flex items-center gap-3 rounded-xl border border-[#00E676] bg-[#11161F] px-5 py-3.5 text-sm font-bold text-[#F1F5F9] shadow-2xl">
            <CheckCircle2 className="h-5 w-5 text-[#00E676]" />
            <span>{toastHe}</span>
          </div>
        )}

        {/* Top Institutional Day Trading Command Header Bar */}
        <header className="sticky top-0 z-40 border-b border-[#222B3A] bg-[#0B0E14]/95 backdrop-blur-md">
          <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-3 px-4 py-3">
            {/* Brand & Icon */}
            <div className="flex items-center gap-3">
              <img
                src="./assets/images/crypto_app_icon.png"
                alt="Crypto Day Trading App Icon"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (
                    !target.src.endsWith("/assets/images/crypto_app_icon.png")
                  ) {
                    target.src = "/assets/images/crypto_app_icon.png";
                  }
                }}
                className="h-10 w-10 rounded-xl border border-[#222B3A] object-cover shadow"
              />
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base font-extrabold tracking-tight text-[#F1F5F9] sm:text-lg">
                    Crypto Day Trading &amp; MCP AI Hub
                  </h1>
                  <span className="hidden rounded bg-[#00E676]/15 px-2 py-0.5 font-mono text-[10px] font-bold text-[#00E676] sm:inline-block">
                    MCP + CAPACITOR APK
                  </span>
                </div>
                <p className="text-[11px] text-[#94A3B8]">
                  סוכן מסחר יומי MCP • סורק סקאלפינג VWAP • דמו $10,000 • מיסוי
                  ישראלי
                </p>
              </div>
            </div>

            {/* Live Connection Health Badge + Quick Actions */}
            <div className="flex flex-wrap items-center gap-2.5">
              <div
                onClick={() => connectionHealth.triggerHeartbeat()}
                title="לחץ לבדיקת פינג מיידית מול Binance / CoinCap"
                className="flex cursor-pointer items-center gap-2 rounded-lg border border-[#222B3A] bg-[#11161F] px-3 py-1.5 text-xs transition hover:border-[#3B82F6]"
              >
                <span>{connectionHealth.dotEmoji}</span>
                <span className="font-bold text-[#F1F5F9]">
                  {connectionHealth.badgeTextHe}
                </span>
                <span className="font-mono text-[11px] text-[#94A3B8]">
                  ({connectionHealth.latencyMs}ms)
                </span>
              </div>

              <div
                onClick={() => handleSelectMainTab("PAPER_BACKTEST")}
                className="hidden cursor-pointer items-center gap-2 rounded-lg border border-[#222B3A] bg-[#11161F] px-3 py-1.5 text-xs md:flex hover:border-[#00E676]"
              >
                <Wallet className="h-3.5 w-3.5 text-[#00E676]" />
                <span className="text-[#94A3B8]">יתרת דמו:</span>
                <span className="font-mono font-extrabold text-[#00E676]">
                  ${virtualBalanceUsdt.toFixed(2)}
                </span>
              </div>

              <div className="hidden items-center gap-1.5 rounded-lg border border-[#222B3A] bg-[#11161F] px-2.5 py-1.5 font-mono text-[11px] text-[#94A3B8] xl:flex">
                <Clock className="h-3.5 w-3.5 text-[#3B82F6]" />
                <span>
                  רענון רקע: {Math.floor(nextPollSeconds / 60)}:
                  {String(nextPollSeconds % 60).padStart(2, "0")}
                </span>
              </div>

              <button
                type="button"
                disabled={isManualScanning}
                onClick={handleManualScan}
                className="inline-flex items-center gap-2 rounded-lg bg-[#3B82F6] px-3.5 py-1.5 text-xs font-bold text-white shadow transition hover:bg-[#2563EB] disabled:opacity-60"
              >
                <RefreshCw
                  className={`h-3.5 w-3.5 ${
                    isManualScanning ? "animate-spin" : ""
                  }`}
                />
                <span>
                  {isManualScanning ? "סורק שוק..." : "סריקה ידנית עכשיו"}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  notificationsService.requestPermissions();
                  setShowNotificationsDrawer(!showNotificationsDrawer);
                }}
                className="relative flex items-center gap-1.5 rounded-lg border border-[#222B3A] bg-[#11161F] px-3 py-1.5 text-xs font-semibold text-[#F1F5F9] hover:border-[#3B82F6]"
              >
                <Bell className="h-4 w-4 text-[#F59E0B]" />
                <span className="hidden sm:inline">התראות</span>
                <span className="rounded-full bg-[#FF3B69] px-1.5 py-0.2 font-mono text-[10px] font-bold text-white">
                  {pushAlerts.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setShowApkConfigModal(true)}
                className="flex items-center gap-1.5 rounded-lg border border-[#00E676]/40 bg-[#00E676]/10 px-3 py-1.5 text-xs font-bold text-[#00E676] hover:bg-[#00E676]/20"
              >
                <Smartphone className="h-4 w-4" />
                <span className="hidden sm:inline">Capacitor APK</span>
              </button>
            </div>
          </div>

          {/* 7 Main Hebrew Day Trading Navigation Tabs */}
          <div className="border-t border-[#222B3A] bg-[#11161F]">
            <nav className="mx-auto flex max-w-[1600px] items-center gap-1.5 overflow-x-auto px-4 py-2">
              {NAVIGATION_TABS.map((tab) => {
                const IconComp = tab.icon;
                const isActive = activeTab === tab.key;
                return (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() => handleSelectMainTab(tab.key)}
                    className={`flex shrink-0 items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-bold transition ${
                      isActive
                        ? "bg-[#3B82F6] text-white shadow"
                        : "text-[#94A3B8] hover:bg-[#181F2C] hover:text-[#F1F5F9]"
                    }`}
                  >
                    <IconComp className="h-4 w-4" />
                    <span>{tab.labelHe}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </header>

        {/* Mobile Push Notifications Drawer */}
        {showNotificationsDrawer && (
          <div className="fixed left-4 top-28 z-50 w-96 max-w-[92vw] rounded-xl border border-[#222B3A] bg-[#11161F] p-4 shadow-2xl">
            <div className="mb-3 flex items-center justify-between border-b border-[#222B3A] pb-2">
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4 text-[#F59E0B]" />
                <h4 className="text-sm font-bold text-[#F1F5F9]">
                  מרכז התראות Mobile Push (Expo/FCM)
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowNotificationsDrawer(false)}
                className="text-[#94A3B8] hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="max-h-80 space-y-2 overflow-y-auto">
              {pushAlerts.map((al) => (
                <div
                  key={al.id}
                  className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-2.5 text-xs"
                >
                  <div className="flex justify-between font-bold text-[#F1F5F9]">
                    <span>{al.titleHe}</span>
                    <span className="font-mono text-[10px] text-[#64748B]">
                      {new Date(al.timestamp).toLocaleTimeString("he-IL", {
                        hour12: false,
                      })}
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-[#94A3B8]">{al.bodyHe}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Native Capacitor Android APK Modal */}
        {showApkConfigModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
            <div className="w-full max-w-2xl rounded-2xl border border-[#222B3A] bg-[#11161F] p-6 shadow-2xl">
              <div className="flex items-center justify-between border-b border-[#222B3A] pb-3">
                <div className="flex items-center gap-2.5">
                  <Smartphone className="h-5 w-5 text-[#00E676]" />
                  <h3 className="text-lg font-bold text-[#F1F5F9]">
                    בניית Capacitor Android APK (`com.crypto.daytrading`)
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowApkConfigModal(false)}
                  className="text-[#94A3B8] hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="mt-4 space-y-4 text-xs">
                <p className="text-[#94A3B8]">
                  הפרויקט עטוף באופן מלא ב-Capacitor Native Android (`android/`),
                  כולל <code className="text-[#00E676]">capacitor.config.ts</code>{" "}
                  (`appId: com.crypto.daytrading`, `webDir: dist`), הרשאות{" "}
                  <code className="text-[#3B82F6]">
                    android.permission.INTERNET
                  </code>{" "}
                  ו-
                  <code className="text-[#3B82F6]">
                    usesCleartextTraffic=&quot;true&quot;
                  </code>{" "}
                  ב-<code className="text-[#00E676]">AndroidManifest.xml</code>,
                  וקובץ APK מוכן להתקנה בנתיב:
                </p>
                <div className="rounded-lg border border-[#00E676]/40 bg-[#0B0E14] p-3 font-mono text-xs text-[#00E676]">
                  android/app/build/outputs/apk/debug/app-debug.apk
                </div>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <a
                    href="/app-debug.apk"
                    download="Crypto-Day-Trading-debug.apk"
                    className="inline-flex items-center gap-2 rounded-lg bg-[#00E676] px-5 py-2.5 text-xs font-extrabold text-[#0B0E14] transition hover:brightness-110"
                  >
                    <Download className="h-4 w-4" />
                    <span>הורד קובץ app-debug.apk ישירות</span>
                  </a>
                  <span className="font-mono text-[11px] text-[#94A3B8]">
                    App ID: com.crypto.daytrading | App Name: Crypto Day Trading
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Offline Cached Fallback Banner */}
        {offlineBannerHe && (
          <div className="border-b border-[#F59E0B]/40 bg-[#F59E0B]/15 px-4 py-2 text-center text-xs font-bold text-[#F59E0B]">
            ⚠️ {offlineBannerHe} (Binance / CoinGecko Local Storage Cache)
          </div>
        )}

        {/* Main Workspace Container */}
        <main className="mx-auto max-w-[1600px] px-4 py-6">
          {initialLoading ? (
            <LoadingSkeletonHe
              label="טוען נתוני מסחר... מחשב VWAP, Order Flow, EMA 9/20/50/200, RSI ו-ATR מ-200 נרות"
              rows={5}
            />
          ) : loadError ? (
            <div className="rounded-xl border border-[#FF3B69] bg-[#11161F] p-6 text-center">
              <AlertTriangle className="mx-auto h-10 w-10 text-[#FF3B69]" />
              <h3 className="mt-2 text-lg font-bold text-[#F1F5F9]">
                {loadError}
              </h3>
              <button
                type="button"
                onClick={() => fetchAllData(focusSymbol, true)}
                className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[#3B82F6] px-5 py-2.5 text-xs font-bold text-white"
              >
                <RefreshCw className="h-4 w-4" />
                <span>שגיאה בטעינת הנתונים - לחץ לנסות שוב</span>
              </button>
            </div>
          ) : (
            <>
              {/* TAB 1: "סוחר AI ומסחר בצ'אט" (MCP Conversational Day Trading AI Agent) */}
              {activeTab === "MCP_AI_CHAT" && (
                <ErrorBoundary sectionTitleHe="סוחר AI ומסחר בצ'אט (MCP Protocol)">
                  <div className="space-y-6">
                    <McpConversationalAgent
                      coins={safeCoins}
                      candles={focusCandles}
                      virtualBalanceUsdt={virtualBalanceUsdt}
                      dailyCircuitBreakerPct={dailyCircuitBreakerPct}
                      onApproveMarketTrade={handleOpenMarketPosition}
                      onApproveCircuitBreaker={(pct) => {
                        setDailyCircuitBreakerPct(pct);
                        showHebrewToast(
                          `מנגנון הגנת הפסד יומי מרבי הוגדר ל-${pct}% מתיק הדמו!`
                        );
                      }}
                      onNavigateToBacktest={() =>
                        handleSelectMainTab("PAPER_BACKTEST")
                      }
                    />

                    <NvidiaNimVisionPanel
                      coins={safeCoins}
                      selectedSymbol={focusSymbol}
                      candles={focusCandles}
                      onSelectSymbol={(sym) => setFocusSymbol(sym)}
                      onExecuteNimDemoTrade={(coin) =>
                        handleOpenMarketPosition({
                          symbol: coin.symbol,
                          side:
                            coin.recommendation === "SHORT" ? "SHORT" : "LONG",
                          entryPrice: coin.currentPrice,
                          sizeUsdt: coin.kellySizing.marginSizeUsdt,
                          leverage: coin.kellySizing.recommendedLeverage,
                          stopLoss: coin.stopLoss,
                          takeProfit: coin.takeProfit1,
                        })
                      }
                    />
                  </div>
                </ErrorBoundary>
              )}

              {/* TAB 2: "אותות וסורק סקאלפינג" (Intraday Scalping & Momentum Scanner - 1m/5m/15m) */}
              {activeTab === "SCALPING_SCANNER" && (
                <ErrorBoundary sectionTitleHe="אותות וסורק סקאלפינג (1m/5m/15m)">
                  <div className="space-y-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#222B3A] bg-[#11161F] p-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <Sparkles className="h-5 w-5 text-[#00E676]" />
                          <h2 className="text-lg font-bold text-[#F1F5F9]">
                            סורק סקאלפינג ומומנטום תוך-יומי ({scalpTimeframe}) —
                            VWAP, Order Flow &amp; EMA 9/20
                          </h2>
                        </div>
                        <p className="mt-0.5 text-xs text-[#94A3B8]">
                          חישובים דינמיים מ-200 נרות חיים מ-Binance/CoinCap:
                          VWAP, Order Flow Imbalance, EMA(9/20/50/200), RSI(14)
                          ו-Kelly 1% Risk.
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {(["1m", "5m", "15m"] as const).map((tf) => (
                          <button
                            key={tf}
                            type="button"
                            onClick={() => setScalpTimeframe(tf)}
                            className={`rounded-lg px-3 py-1.5 font-mono text-xs font-bold transition ${
                              scalpTimeframe === tf
                                ? "bg-[#00E676] text-[#0B0E14]"
                                : "bg-[#181F2C] text-[#94A3B8]"
                            }`}
                          >
                            גרף {tf}
                          </button>
                        ))}
                        {(
                          [
                            { id: "ALL", label: "כל האיתותים (12)" },
                            { id: "LONG", label: "לונג (LONG)" },
                            { id: "SHORT", label: "שורט (SHORT)" },
                          ] as const
                        ).map((f) => (
                          <button
                            key={f.id}
                            type="button"
                            onClick={() => setSignalFilter(f.id)}
                            className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${
                              signalFilter === f.id
                                ? "bg-[#3B82F6] text-white"
                                : "bg-[#181F2C] text-[#94A3B8] hover:text-white"
                            }`}
                          >
                            {f.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Dynamic Scalping Signal Cards Grid */}
                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
                      {filteredSignalCoins.map((coin) => {
                        const isLong = coin.recommendation === "LONG";
                        const isShort = coin.recommendation === "SHORT";

                        return (
                          <div
                            key={coin.symbol}
                            className={`flex flex-col justify-between rounded-xl border bg-[#11161F] p-5 transition hover:shadow-xl ${
                              isLong
                                ? "border-[#00E676]/45"
                                : isShort
                                ? "border-[#FF3B69]/45"
                                : "border-[#222B3A]"
                            }`}
                          >
                            <div>
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-mono text-lg font-extrabold text-[#F1F5F9]">
                                      {coin.symbol}
                                    </span>
                                    <span className="rounded bg-[#181F2C] px-2 py-0.5 font-mono text-[10px] text-[#3B82F6]">
                                      {scalpTimeframe}
                                    </span>
                                  </div>
                                  <div className="mt-1 flex items-baseline gap-2 font-mono">
                                    <span className="text-2xl font-extrabold text-[#F1F5F9]">
                                      ${formatPriceNumber(coin.currentPrice)}
                                    </span>
                                    <span
                                      className={`text-xs font-bold ${
                                        coin.change24hPct >= 0
                                          ? "text-[#00E676]"
                                          : "text-[#FF3B69]"
                                      }`}
                                    >
                                      {coin.change24hPct >= 0 ? "+" : ""}
                                      {coin.change24hPct}%
                                    </span>
                                  </div>
                                </div>

                                <div className="text-left">
                                  <span
                                    className={`inline-flex items-center gap-1 rounded-lg px-3 py-1.5 font-mono text-xs font-extrabold ${
                                      isLong
                                        ? "bg-[#00E676] text-[#0B0E14]"
                                        : isShort
                                        ? "bg-[#FF3B69] text-white"
                                        : "bg-[#F59E0B]/20 text-[#F59E0B]"
                                    }`}
                                  >
                                    {isLong ? (
                                      <TrendingUp className="h-3.5 w-3.5" />
                                    ) : isShort ? (
                                      <TrendingDown className="h-3.5 w-3.5" />
                                    ) : null}
                                    {coin.recommendationLabelHe}
                                  </span>
                                  <div className="mt-1 font-mono text-[11px] font-bold text-[#3B82F6]">
                                    קונפלואנס: {coin.confluenceScore}%
                                  </div>
                                </div>
                              </div>

                              {/* Intraday Technical Indicators Grid (VWAP, Order Flow, EMA 9/20, RSI, ATR) */}
                              <div className="mt-4 grid grid-cols-3 gap-2 rounded-lg bg-[#0B0E14] p-3 font-mono text-xs">
                                <div>
                                  <span className="block font-sans text-[10px] text-[#A855F7]">
                                    VWAP יומי
                                  </span>
                                  <strong className="text-[#F1F5F9]">
                                    ${formatPriceNumber(coin.vwap)}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    Order Flow
                                  </span>
                                  <strong
                                    className={
                                      coin.orderFlowImbalancePct >= 0
                                        ? "text-[#00E676]"
                                        : "text-[#FF3B69]"
                                    }
                                  >
                                    {coin.orderFlowImbalancePct >= 0 ? "+" : ""}
                                    {coin.orderFlowImbalancePct}%
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    EMA 9 / 20
                                  </span>
                                  <strong className="text-[11px] text-[#3B82F6]">
                                    ${formatPriceNumber(coin.ema.ema9)}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    RSI (14)
                                  </span>
                                  <strong className="text-[#F1F5F9]">
                                    {coin.rsi14}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    ATR (14)
                                  </span>
                                  <strong className="text-[11px] text-[#F59E0B]">
                                    {coin.atrPct}%
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#64748B]">
                                    POC נפח
                                  </span>
                                  <strong className="text-[11px] text-[#00E676]">
                                    ${formatPriceNumber(
                                      coin.volumeProfile.pocPrice
                                    )}
                                  </strong>
                                </div>
                              </div>

                              {/* Entry, SL & TP Targets */}
                              <div className="mt-3 grid grid-cols-3 gap-2 rounded-lg border border-[#222B3A] bg-[#181F2C]/50 p-2.5 font-mono text-xs">
                                <div>
                                  <span className="block font-sans text-[10px] text-[#94A3B8]">
                                    מחיר כניסה
                                  </span>
                                  <strong className="text-[#F1F5F9]">
                                    ${formatPriceNumber(coin.entryPrice)}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#FF3B69]">
                                    Stop-Loss (ATR)
                                  </span>
                                  <strong className="text-[#FF3B69]">
                                    ${formatPriceNumber(coin.stopLoss)}
                                  </strong>
                                </div>
                                <div>
                                  <span className="block font-sans text-[10px] text-[#00E676]">
                                    Take-Profit (TP1)
                                  </span>
                                  <strong className="text-[#00E676]">
                                    ${formatPriceNumber(coin.takeProfit1)}
                                  </strong>
                                </div>
                              </div>

                              {/* Kelly Criterion & 1% Account Risk Box */}
                              <div className="mt-3 rounded-lg border border-[#3B82F6]/30 bg-[#3B82F6]/10 p-3 text-xs">
                                <div className="flex items-center justify-between font-bold text-[#F1F5F9]">
                                  <span>
                                    סיכון {coin.kellySizing.accountRiskPct}% מהתיק
                                    (Kelly + ATR):
                                  </span>
                                  <span className="font-mono text-[#00E676]">
                                    מינוף {coin.kellySizing.recommendedLeverage}x
                                  </span>
                                </div>
                                <div className="mt-1 flex justify-between font-mono text-xs">
                                  <span className="text-[#E2E8F0]">
                                    בטחונות:{" "}
                                    {coin.kellySizing.positionPctOfBalance}%
                                  </span>
                                  <strong className="text-[#00E676]">
                                    ${coin.kellySizing.marginSizeUsdt} USDT
                                  </strong>
                                </div>
                              </div>

                              <ul className="mt-3 space-y-1 text-xs text-[#94A3B8]">
                                {coin.reasonsHe.slice(0, 3).map((reason, rIdx) => (
                                  <li
                                    key={rIdx}
                                    className="flex items-start gap-1.5"
                                  >
                                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[#00E676]" />
                                    <span>{reason}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div className="mt-4 flex items-center gap-2 pt-2">
                              <button
                                type="button"
                                onClick={() =>
                                  handleOpenMarketPosition({
                                    symbol: coin.symbol,
                                    side:
                                      coin.recommendation === "SHORT"
                                        ? "SHORT"
                                        : "LONG",
                                    entryPrice: coin.currentPrice,
                                    sizeUsdt: coin.kellySizing.marginSizeUsdt,
                                    leverage:
                                      coin.kellySizing.recommendedLeverage,
                                    stopLoss: coin.stopLoss,
                                    takeProfit: coin.takeProfit1,
                                  })
                                }
                                className="flex-1 rounded-lg bg-[#00E676] py-2.5 text-xs font-extrabold text-[#0B0E14] transition hover:brightness-110"
                              >
                                בצע בעסקת דמו (${coin.kellySizing.marginSizeUsdt} •{" "}
                                {coin.kellySizing.recommendedLeverage}x)
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setFocusSymbol(coin.symbol);
                                  handleSelectMainTab("CHARTS_ORDERBOOK");
                                }}
                                className="rounded-lg border border-[#222B3A] bg-[#181F2C] px-3 py-2.5 text-xs font-bold text-[#F1F5F9] hover:border-[#3B82F6]"
                              >
                                גרף + VWAP
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    <KumoRelationalModule activeSymbol={focusSymbol} />

                    <EvaluatorAgentPanel
                      logs={evaluatorLogs}
                      rollingWinRatePct={rollingWinRatePct}
                      strictMode={strictMode}
                      minConfluenceThreshold={minConfluenceThreshold}
                      onRunManualAudit={handleRunEvaluatorAudit}
                    />
                  </div>
                </ErrorBoundary>
              )}

              {/* TAB 3: "מסחר דמו ו-Backtest" (Paper Day Trading & Intraday Backtesting Engine) */}
              {activeTab === "PAPER_BACKTEST" && (
                <ErrorBoundary sectionTitleHe="מסחר דמו ו-Backtest תוך-יומי">
                  <PaperTradingModule
                    virtualBalanceUsdt={virtualBalanceUsdt}
                    realizedPnlUsdt={realizedPnlUsdt}
                    coins={safeCoins}
                    candles={focusCandles}
                    openPositions={openPositions}
                    closedPositions={closedPositions}
                    limitOrders={limitOrders}
                    dailyCircuitBreakerPct={dailyCircuitBreakerPct}
                    onUpdateCircuitBreakerPct={(pct) => {
                      setDailyCircuitBreakerPct(pct);
                      showHebrewToast(
                        `תקרת הפסד יומי מרבי עודכנה ל-${pct}% מתיק הדמו`
                      );
                    }}
                    onOpenMarketPosition={handleOpenMarketPosition}
                    onPlaceLimitOrder={handlePlaceLimitOrder}
                    onCancelLimitOrder={handleCancelLimitOrder}
                    onClosePosition={handleClosePosition}
                    onResetAccount={handleResetDemoAccount}
                  />
                </ErrorBoundary>
              )}

              {/* TAB 4: "גרפים, ספר פקודות ו-Tape" (Live Candlestick Charts, VWAP, Order Book & Trade Tape) */}
              {activeTab === "CHARTS_ORDERBOOK" && focusedCoinObj && (
                <ErrorBoundary sectionTitleHe="גרפים, VWAP, ספר פקודות ו-Trade Tape">
                  <div className="space-y-4">
                    <div className="flex flex-wrap items-center gap-2 rounded-xl border border-[#222B3A] bg-[#11161F] p-3">
                      <span className="text-xs font-bold text-[#94A3B8]">
                        בחר צמד לגרף, VWAP וספר פקודות:
                      </span>
                      {safeCoins.map((c) => (
                        <button
                          key={c.symbol}
                          type="button"
                          onClick={() => setFocusSymbol(c.symbol)}
                          className={`rounded-lg px-3 py-1.5 font-mono text-xs font-bold transition ${
                            c.symbol === focusSymbol
                              ? "bg-[#3B82F6] text-white"
                              : "bg-[#181F2C] text-[#94A3B8] hover:text-white"
                          }`}
                        >
                          {c.baseAsset} (${formatPriceNumber(c.currentPrice)})
                        </button>
                      ))}
                    </div>

                    <CandlestickTerminal
                      coin={focusedCoinObj}
                      candles={focusCandles}
                      orderBook={orderBook}
                      tradeTape={tradeTape}
                      onQuickOrder={(side) =>
                        handleOpenMarketPosition({
                          symbol: focusedCoinObj.symbol,
                          side,
                          entryPrice: focusedCoinObj.currentPrice,
                          sizeUsdt: focusedCoinObj.kellySizing.marginSizeUsdt,
                          leverage:
                            focusedCoinObj.kellySizing.recommendedLeverage,
                          stopLoss: focusedCoinObj.stopLoss,
                          takeProfit: focusedCoinObj.takeProfit1,
                        })
                      }
                    />

                    <NvidiaNimVisionPanel
                      coins={safeCoins}
                      selectedSymbol={focusSymbol}
                      candles={focusCandles}
                      onSelectSymbol={(sym) => setFocusSymbol(sym)}
                      onExecuteNimDemoTrade={(coin) =>
                        handleOpenMarketPosition({
                          symbol: coin.symbol,
                          side:
                            coin.recommendation === "SHORT" ? "SHORT" : "LONG",
                          entryPrice: coin.currentPrice,
                          sizeUsdt: coin.kellySizing.marginSizeUsdt,
                          leverage: coin.kellySizing.recommendedLeverage,
                          stopLoss: coin.stopLoss,
                          takeProfit: coin.takeProfit1,
                        })
                      }
                    />
                  </div>
                </ErrorBoundary>
              )}

              {/* TAB 5: "חיקוי סוחרי יום" (Day Trading Copy Trading Leaderboard) */}
              {activeTab === "COPY_TRADING" && (
                <ErrorBoundary sectionTitleHe="חיקוי סוחרי יום (Copy Trading)">
                  <CopyTradingModule
                    copiedSubscriptions={copiedTraders}
                    livePricesMap={livePricesMap}
                    onToggleCopyTrader={handleToggleCopyTrader}
                  />
                </ErrorBoundary>
              )}

              {/* TAB 6: "מפת שוק וסנטימנט" (Finviz Heatmap, Fear & Greed + Messari Deep Research) */}
              {activeTab === "MARKET_HEATMAP" && (
                <ErrorBoundary sectionTitleHe="מפת שוק, סנטימנט ומחקר On-Chain">
                  <div className="space-y-8">
                    <FinvizHeatmapModule
                      coins={safeCoins}
                      fearGreed={fearGreed}
                      onSelectCoin={(sym) => {
                        setFocusSymbol(sym);
                        handleSelectMainTab("CHARTS_ORDERBOOK");
                      }}
                    />

                    <MessariResearchModule
                      coins={safeCoins}
                      onTradeDemoFromResearch={(coin) => {
                        handleOpenMarketPosition({
                          symbol: coin.symbol,
                          side:
                            coin.recommendation === "SHORT" ? "SHORT" : "LONG",
                          entryPrice: coin.currentPrice,
                          sizeUsdt: coin.kellySizing.marginSizeUsdt,
                          leverage: coin.kellySizing.recommendedLeverage,
                          stopLoss: coin.stopLoss,
                          takeProfit: coin.takeProfit1,
                        });
                      }}
                    />
                  </div>
                </ErrorBoundary>
              )}

              {/* TAB 7: "יומן עסקאות ומיסוי" (Trade Ledger & Israeli Day Trading Tax Hub) */}
              {activeTab === "FINANCE_TAX" && (
                <ErrorBoundary sectionTitleHe="יומן עסקאות ומיסוי יומי (טופס 909)">
                  <InvoappTaxModule
                    realizedPnlUsdt={realizedPnlUsdt}
                    unrealizedPnlUsdt={totalUnrealizedPnl}
                    invoices={taxInvoices}
                    onCreateInvoice={handleCreateTaxInvoice}
                  />
                </ErrorBoundary>
              )}
            </>
          )}
        </main>
      </div>
    </ErrorBoundary>
  );
}
