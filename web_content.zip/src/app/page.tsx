import Image from "next/image";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ensureSeeded, getMovies, getSessionMember } from "@/lib/data";
import { Onboarding } from "@/components/onboarding";
import { Countdown } from "@/components/countdown";
import { PosterImage } from "@/components/poster";
import { SessionResume } from "@/components/session-resume";

export const dynamic = "force-dynamic";

const STEPS = [
  {
    emoji: "🎬",
    title: "Segna i film",
    text: "Tutti i film Marvel, dalle origini a Doomsday. Metti “visto”, aggiungi alla watchlist e dai un voto da 1 a 5 stelle.",
  },
  {
    emoji: "🔗",
    title: "Invita la squadra",
    text: "Crea la tua squadra e condividi il codice. I tuoi amici entrano in un secondo, senza password e senza registrazioni.",
  },
  {
    emoji: "🏆",
    title: "Sfida gli amici",
    text: "Classifica, medie, preferiti e recensioni: guarda cosa hanno visto gli altri e chi arriva più preparato a Doomsday.",
  },
];

export default async function LandingPage() {
  const session = await getSessionMember().catch(() => null);
  if (session) redirect("/squad");

  await ensureSeeded().catch(() => undefined);
  const movies = await getMovies().catch(() => []);
  const preview = movies.filter((movie) => movie.saga === "MCU").slice(0, 14);
  const mcuCount = movies.filter((movie) => movie.saga === "MCU").length;
  const total = movies.length || 64;

  return (
    <div className="relative min-h-screen">
      <SessionResume />
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[560px] overflow-hidden">
        <Image
          src="/images/hero-comic.jpg"
          alt=""
          fill
          priority
          sizes="100vw"
          className="object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-mv-ink/50 via-mv-ink/85 to-mv-ink" />
      </div>
      <header className="mx-auto flex max-w-7xl items-center justify-between px-4 py-5">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-mv-red font-display text-lg text-white shadow-[0_6px_18px_-6px_rgba(230,36,41,0.9)]">
            M
          </span>
          <span className="font-display text-lg leading-none tracking-wide text-white">
            Marvel<span className="text-mv-red">Squad</span>
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-white/50 sm:block">
            {total} film · {mcuCount} MCU
          </span>
          <Link
            href="#inizia"
            className="rounded-xl bg-white px-3.5 py-2 text-[11px] font-black uppercase tracking-widest text-black transition hover:bg-mv-gold"
          >
            Inizia
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 pb-16">
        <section className="grid items-start gap-6 lg:grid-cols-[1.15fr_1fr]">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-mv-red/40 bg-mv-red/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.25em] text-mv-red">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-mv-red" />
              La tua reunion prima di Doomsday
            </span>
            <h1 className="mt-4 font-display text-5xl leading-[0.92] text-white sm:text-6xl lg:text-7xl">
              Tutti i film Marvel.
              <br />
              <span className="text-mv-red">Un solo posto.</span>
              <br />
              Con i tuoi amici.
            </h1>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-white/60 sm:text-base">
              Segna i film che hai visto, crea la watchlist, vota con le stelle e scrivi recensioni. Condividi un
              semplice codice con la tua squadra e scopri chi è il vero esperto del multiverso — prima che arrivi{" "}
              <span className="font-semibold text-white">Avengers: Doomsday</span>.
            </p>

            <div className="mt-5 flex flex-wrap items-center gap-3">
              <Link
                href="#inizia"
                className="rounded-xl bg-mv-red px-5 py-3 text-xs font-black uppercase tracking-widest text-white shadow-[0_18px_35px_-18px_rgba(230,36,41,0.95)] transition hover:bg-mv-red-dark"
              >
                Crea la tua squadra
              </Link>
              <Link
                href="#catalogo"
                className="rounded-xl border border-white/15 px-5 py-3 text-xs font-black uppercase tracking-widest text-white/70 transition hover:border-white/40 hover:text-white"
              >
                Guarda il catalogo
              </Link>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {[
                ["🎬", `${total}`, "film"],
                ["🎞️", "6", "fasi MCU"],
                ["👥", "∞", "amici"],
                ["⏳", "1", "countdown"],
              ].map(([emoji, value, label]) => (
                <div key={label} className="comic-panel rounded-2xl px-3 py-2.5">
                  <p className="text-base">{emoji}</p>
                  <p className="font-display text-2xl leading-none text-white">{value}</p>
                  <p className="text-[9px] font-bold uppercase tracking-widest text-white/35">{label}</p>
                </div>
              ))}
            </div>

            <div className="comic-panel mt-4 rounded-2xl p-4">
              <p className="text-[10px] font-black uppercase tracking-[0.3em] text-mv-red">Countdown</p>
              <p className="mt-1 font-display text-2xl leading-none text-white">
                Avengers: Doomsday <span className="text-white/40">· 18.12.2026</span>
              </p>
              <div className="mt-3">
                <Countdown />
              </div>
            </div>
          </div>

          <div id="inizia" className="scroll-mt-6">
            <Onboarding />
            <div className="mt-3 grid gap-2 sm:grid-cols-3">
              {STEPS.map((step) => (
                <div key={step.title} className="comic-panel rounded-2xl p-3">
                  <p className="text-lg">{step.emoji}</p>
                  <p className="mt-1 font-display text-sm leading-none text-white">{step.title}</p>
                  <p className="mt-1.5 text-[11px] leading-relaxed text-white/45">{step.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="catalogo" className="mt-12 scroll-mt-6">
          <div className="flex flex-wrap items-end justify-between gap-2">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.3em] text-mv-gold">Il catalogo</p>
              <h2 className="font-display text-3xl leading-none text-white sm:text-4xl">
                Dalla Fase 1 a <span className="text-mv-red">Doomsday</span>
              </h2>
            </div>
            <p className="text-xs text-white/40">
              + X-Men, Deadpool, Sony Spider-Man e i Fantastici Quattro di Fox
            </p>
          </div>

          <div className="no-scrollbar mt-4 flex gap-3 overflow-x-auto pb-2">
            {preview.map((movie) => (
              <div
                key={movie.id}
                className="group relative w-32 shrink-0 overflow-hidden rounded-xl border border-white/10 shadow-lg transition duration-300 hover:-translate-y-1 hover:border-white/30 sm:w-36"
              >
                <div className="relative aspect-[2/3] w-full">
                  <PosterImage
                    src={movie.posterUrl}
                    palette={movie.palette}
                    alt={movie.title}
                    className="absolute inset-0 h-full w-full"
                    width={300}
                  />
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
                  <span className="absolute left-1.5 top-1.5 rounded bg-black/70 px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-white/85">
                    Fase {movie.phase}
                  </span>
                  <div className="absolute inset-x-0 bottom-0 p-2">
                    <p className="font-display text-[12px] leading-[1.1] text-white drop-shadow">{movie.title}</p>
                    <p className="text-[9px] text-white/60">{movie.year}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <footer className="mt-14 flex flex-col items-center gap-2 border-t border-white/10 pt-6 text-center">
          <p className="font-display text-sm tracking-wide text-white/60">
            Marvel<span className="text-mv-red">Squad</span> · fan project non ufficiale
          </p>
          <p className="max-w-md text-[11px] leading-relaxed text-white/30">
            Nessun film è stato caricato: solo i tuoi voti, le tue recensioni e i tuoi amici. I marchi e i titoli
            appartengono ai rispettivi proprietari.
          </p>
        </footer>
      </main>
    </div>
  );
}
