import Browser from "@/components/Browser";

export default function Page() {
  return <Browser />;
}
