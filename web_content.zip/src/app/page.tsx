"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { BookOpen, CalendarCheck, MapPin, MessageCircle, Phone, Quote, Search, ShieldCheck, Star, Stethoscope } from "lucide-react";
import { useI18n, useSite } from "@/components/providers";
import { ArticleCard, ServiceCard, TipCard } from "@/components/cards";
import { Badge, buttonClass, Card, CardSkeleton, ErrorState, Input, Select, SectionTitle, Stars } from "@/components/ui";
import { api } from "@/lib/api-client";
import { EMERGENCY_NUMBERS } from "@/lib/constants";
import type { ArticleDTO, ServiceDTO } from "@/lib/types";
import { loc, waLink } from "@/lib/utils";

/** Public APK link, set NEXT_PUBLIC_ANDROID_APK_URL once the release APK is hosted. */
const apkUrl = process.env.NEXT_PUBLIC_ANDROID_APK_URL || "";

interface HomeData {
  featuredServices: ServiceDTO[];
  featuredArticles: ArticleDTO[];
  tip: ArticleDTO | null;
  stats: { professionals: number; services: number; articles: number };
}

export default function HomePage() {
  const { t, locale } = useI18n();
  const { settings, whatsapp, callLink, defaultMessage } = useSite();
  const router = useRouter();
  const [data, setData] = useState<HomeData | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [query, setQuery] = useState("");
  const [scope, setScope] = useState<"services" | "articles">("services");
  const [quickService, setQuickService] = useState("");
  const [quickDate, setQuickDate] = useState("");

  useEffect(() => {
    let alive = true;
    setError(false);
    api<HomeData>("/api/home")
      .then((r) => {
        if (alive) setData(r);
      })
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [reloadKey]);

  const today = new Date().toISOString().slice(0, 10);
  const contact = settings.contact;
  const shownServices = data?.featuredServices ?? [];

  const onSearch = (e: FormEvent) => {
    e.preventDefault();
    const base = scope === "services" ? "/services" : "/articles";
    const q = query.trim();
    router.push(q ? `${base}?q=${encodeURIComponent(q)}` : base);
  };

  const onQuickBook = (e: FormEvent) => {
    e.preventDefault();
    const qs = new URLSearchParams();
    if (quickService) qs.set("service", quickService);
    if (quickDate) qs.set("date", quickDate);
    router.push(`/book${qs.toString() ? `?${qs.toString()}` : ""}`);
  };

  return (
    <div className="space-y-14 sm:space-y-16">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-teal-600 via-teal-500 to-sky-500 px-6 py-10 text-white shadow-xl shadow-teal-600/20 sm:px-10 sm:py-14">
        <div className="pointer-events-none absolute -end-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-2xl" />
        <div className="pointer-events-none absolute -bottom-32 start-1/3 h-80 w-80 rounded-full bg-emerald-300/20 blur-3xl" />
        <div className="relative grid items-start gap-10 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3.5 py-1.5 text-sm font-semibold ring-1 ring-white/30 backdrop-blur">
              <ShieldCheck className="h-4 w-4" />
              {t("home.heroBadge")}
            </span>
            <p className="mt-6 text-base font-semibold text-white/90 sm:text-lg">{t("home.welcome")}</p>
            <h1 className="mt-2 text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl lg:text-5xl">
              {loc(settings.hero.headline, locale)}
            </h1>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-white/90 sm:text-lg">{loc(settings.hero.subtitle, locale)}</p>

            <form onSubmit={onSearch} className="mt-7 rounded-2xl bg-white p-2 shadow-2xl shadow-teal-900/20" role="search">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                <div className="flex flex-1 items-center gap-2 px-3">
                  <Search className="h-5 w-5 shrink-0 text-slate-400" />
                  <input
                    type="search"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder={scope === "services" ? t("home.searchNursing") : t("home.searchMedical")}
                    aria-label={t("common.search")}
                    className="w-full bg-transparent py-3 text-base text-slate-900 placeholder:text-slate-400 focus:outline-none"
                  />
                </div>
                <div className="flex gap-2">
                  <select
                    aria-label={t("common.filter")}
                    value={scope}
                    onChange={(e) => setScope(e.target.value as "services" | "articles")}
                    className="rounded-xl bg-slate-50 px-3 py-2.5 text-sm font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="services">{t("home.searchServices")}</option>
                    <option value="articles">{t("home.searchArticles")}</option>
                  </select>
                  <button type="submit" className={buttonClass("primary", "md", "shrink-0 px-5")}>
                    {t("home.searchBtn")}
                  </button>
                </div>
              </div>
            </form>

            <div className="mt-6 grid gap-3 sm:flex sm:flex-wrap">
              <a href={whatsapp(defaultMessage)} target="_blank" rel="noopener noreferrer" className={buttonClass("whatsapp", "lg")}>
                <MessageCircle className="h-5 w-5" />
                {t("btn.whatsapp")}
              </a>
              <a href={callLink} className={buttonClass("outline", "lg", "bg-white/95 text-teal-800 ring-0 hover:bg-white")}>
                <Phone className="h-5 w-5" />
                {t("btn.callNow")} · <span dir="ltr">{contact.phoneDisplay}</span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-2">
            <form onSubmit={onQuickBook} className="space-y-4 rounded-3xl bg-white p-6 text-slate-900 shadow-2xl shadow-teal-900/20">
              <div>
                <h2 className="flex items-center gap-2 text-lg font-bold">
                  <CalendarCheck className="h-5 w-5 text-teal-600" />
                  {t("home.quickBook")}
                </h2>
                <p className="mt-1 text-sm text-slate-600">{t("home.quickBookText")}</p>
              </div>
              <Select value={quickService} onChange={(e) => setQuickService(e.target.value)} aria-label={t("book.service")}>
                <option value="">{t("book.chooseService")}</option>
                {shownServices.map((s) => (
                  <option key={s.id} value={s.slug}>
                    {loc(s.name, locale)}
                  </option>
                ))}
              </Select>
              <Input type="date" min={today} value={quickDate} onChange={(e) => setQuickDate(e.target.value)} aria-label={t("book.date")} />
              <button type="submit" className={buttonClass("primary", "lg", "w-full")}>
                <CalendarCheck className="h-5 w-5" />
                {t("btn.book")}
              </button>
              <p className="flex items-start gap-2 text-xs leading-relaxed text-slate-500">
                <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                {t("home.location")}
              </p>
            </form>
          </div>
        </div>
      </section>

      {/* Daily tip */}
      <section>
        <SectionTitle title={t("home.tipTitle")} />
        {data?.tip ? (
          <div className="rounded-2xl bg-gradient-to-br from-emerald-50 via-white to-sky-50 p-1 shadow-sm ring-1 ring-emerald-100">
            <TipCard tip={data.tip} />
          </div>
        ) : error ? (
          <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
        ) : (
          <CardSkeleton lines={2} />
        )}
      </section>

      {/* Services */}
      <section>
        <SectionTitle
          title={t("home.servicesTitle")}
          action={
            <Link href="/services" className="text-sm font-semibold text-teal-700 hover:underline">
              {t("home.viewAll")}
            </Link>
          }
        />
        <p className="-mt-2 mb-6 rounded-2xl bg-teal-50/70 px-5 py-4 text-center text-base font-semibold text-teal-900 ring-1 ring-teal-100">
          {t("svc.tagline")}
        </p>
        {!data && !error ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <CardSkeleton key={i} lines={3} />
            ))}
          </div>
        ) : shownServices.length === 0 ? (
          <Card className="text-center text-slate-600">{t("home.noServices")}</Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {shownServices.map((s) => (
              <ServiceCard key={s.id} service={s} />
            ))}
          </div>
        )}
      </section>

      {/* Popular articles */}
      <section>
        <SectionTitle
          title={t("home.popularArticles")}
          action={
            <Link href="/articles" className="text-sm font-semibold text-teal-700 hover:underline">
              {t("home.viewAll")}
            </Link>
          }
        />
        {data && (
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {data.featuredArticles.map((a) => (
              <ArticleCard key={a.id} article={a} />
            ))}
          </div>
        )}
      </section>

      {/* Testimonials */}
      {settings.testimonials.length > 0 && (
        <section>
          <SectionTitle title={t("home.testimonials")} />
          <div className="grid gap-5 md:grid-cols-3">
            {settings.testimonials.map((tm) => (
              <Card key={tm.id} className="flex flex-col gap-4">
                <Quote className="h-7 w-7 text-teal-300" />
                <p className="flex-1 text-[15px] leading-relaxed text-slate-700">{loc(tm.text, locale)}</p>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="font-semibold text-slate-900">{tm.name}</p>
                    <p className="text-xs text-slate-500">{tm.city}</p>
                  </div>
                  <Stars value={tm.rating} size={16} />
                </div>
                {tm.fictional && <Badge tone="amber">{t("home.sampleLabel")}</Badge>}
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Android app download */}
      <section className="flex flex-col gap-5 rounded-3xl bg-gradient-to-br from-teal-50 via-white to-sky-50 p-6 ring-1 ring-teal-100 sm:flex-row sm:items-center sm:p-8">
        <img src="/icons/icon-192.png" alt="" width={72} height={72} className="h-18 w-18 shrink-0 rounded-2xl shadow-md" />
        <div className="min-w-0 flex-1 space-y-2">
          <h2 className="text-lg font-bold text-slate-900">{t("app.download.title")}</h2>
          <p className="text-sm leading-relaxed text-slate-600">{t("app.download.text")}</p>
          <p className="text-xs leading-relaxed text-slate-500">{t("app.download.steps")}</p>
          <p className="text-xs font-semibold text-teal-700">{t("app.download.version")}</p>
        </div>
        {apkUrl ? (
          <a href={apkUrl} download className={buttonClass("primary", "lg", "shrink-0")}>
            {t("app.download.button")}
          </a>
        ) : (
          <a href={whatsapp(t("app.download.waMessage"))} target="_blank" rel="noopener noreferrer" className={buttonClass("whatsapp", "lg", "shrink-0")}>
            <MessageCircle className="h-5 w-5" />
            {t("app.download.waButton")}
          </a>
        )}
      </section>

      {/* Contact & emergency */}
      <section className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2 space-y-5">
          <h2 className="text-xl font-bold text-slate-900">{t("home.contact")}</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            <a href={callLink} className="flex items-center gap-3 rounded-2xl bg-emerald-50 p-4 ring-1 ring-emerald-100 transition hover:bg-emerald-100">
              <Phone className="h-6 w-6 text-emerald-700" />
              <span>
                <span className="block text-sm font-bold text-emerald-900">{t("btn.callNow")}</span>
                <span className="block text-sm text-emerald-800" dir="ltr">{contact.phoneDisplay}</span>
              </span>
            </a>
            <a
              href={whatsapp(defaultMessage)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 rounded-2xl bg-emerald-500 p-4 text-white shadow-md shadow-emerald-500/20 transition hover:bg-emerald-600"
            >
              <MessageCircle className="h-6 w-6" />
              <span>
                <span className="block text-sm font-bold">{t("btn.whatsapp")}</span>
                <span className="block text-sm text-white/90" dir="ltr">{contact.phoneDisplay}</span>
              </span>
            </a>
          </div>
          <ul className="grid gap-2 text-sm text-slate-700 sm:grid-cols-2">
            <li className="flex items-center gap-2"><MapPin className="h-4 w-4 text-teal-600" />{contact.city ? `${contact.city}, ${t("app.country")}` : t("app.country")}</li>
            {contact.address && <li className="flex items-center gap-2"><Stethoscope className="h-4 w-4 text-teal-600" />{contact.address}</li>}
            {contact.email && <li className="flex items-center gap-2"><BookOpen className="h-4 w-4 text-teal-600" /><span dir="ltr">{contact.email}</span></li>}
            {loc(contact.hours, locale) && <li className="flex items-center gap-2"><CalendarCheck className="h-4 w-4 text-teal-600" />{t("contact.hours")}: {loc(contact.hours, locale)}</li>}
          </ul>
        </Card>

        <div className="rounded-3xl bg-gradient-to-br from-rose-50 to-white p-6 ring-1 ring-rose-100">
          <h2 className="text-base font-bold text-rose-900">{t("home.emergencyTitle")}</h2>
          <p className="mt-1 text-xs leading-relaxed text-rose-800/80">{t("home.emergencyDesc")}</p>
          <ul className="mt-4 space-y-2">
            {EMERGENCY_NUMBERS.map((n) => (
              <li key={n.key}>
                <a href={`tel:${n.number}`} className="flex items-center justify-between rounded-xl bg-white px-4 py-3 text-sm ring-1 ring-rose-100 transition hover:bg-rose-100/60">
                  <span className="text-slate-800">{t(`em.${n.key}`)}</span>
                  <span className="font-bold text-rose-700">{n.number}</span>
                </a>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}

