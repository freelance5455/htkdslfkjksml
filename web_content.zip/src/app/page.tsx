"use client";

import React, { useCallback, useEffect, useState } from "react";
import {
  Activity,
  Clock,
  Globe,
  History,
  Loader2,
  MousePointerClick,
  ScanSearch,
  ShieldCheck,
  Trash2,
} from "lucide-react";
import ScanResultsDashboard from "@/components/ScanResultsDashboard";
import type { FullScanDetails, MasterPromptRecord, ScanRecord } from "@/types/xray";

const ACTIVE_STATUSES = new Set([
  "queued",
  "validating",
  "scanning",
  "testing_interactions",
  "analyzing_ai",
  "generating_prompt",
]);

export default function HomePage() {
  const [urlInput, setUrlInput] = useState("");
  const [maxPages, setMaxPages] = useState(6);
  const [maxDepth, setMaxDepth] = useState(2);
  const [includeMobile, setIncludeMobile] = useState(true);
  const [respectRobotsTxt, setRespectRobotsTxt] = useState(true);

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const [history, setHistory] = useState<ScanRecord[]>([]);
  const [activeDetails, setActiveDetails] = useState<FullScanDetails | null>(null);
  const [showHistory, setShowHistory] = useState(false);

  const fetchHistory = useCallback(async () => {
    try {
      const res = await fetch("/api/scans");
      if (!res.ok) return;
      const data = await res.json();
      setHistory(data.scans || []);
    } catch {
      // ignore transient network errors
    }
  }, []);

  const fetchScanDetails = useCallback(async (scanId: string) => {
    try {
      const res = await fetch(`/api/scans/${scanId}`);
      if (!res.ok) return;
      const data = (await res.json()) as FullScanDetails;
      setActiveDetails(data);
    } catch {
      // ignore transient network errors
    }
  }, []);

  useEffect(() => {
    void fetchHistory();
  }, [fetchHistory]);

  // Poll active scan every 1.5s until completed or failed
  useEffect(() => {
    const scanId = activeDetails?.scan.id;
    const status = activeDetails?.scan.status;
    if (!scanId || !status || !ACTIVE_STATUSES.has(status)) return;

    const timer = setInterval(() => {
      void fetchScanDetails(scanId);
      void fetchHistory();
    }, 1500);

    return () => clearInterval(timer);
  }, [activeDetails?.scan.id, activeDetails?.scan.status, fetchScanDetails, fetchHistory]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setSubmitError(null);

    try {
      const res = await fetch("/api/scans", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: urlInput.trim(),
          maxPages,
          maxDepth,
          includeMobile,
          respectRobotsTxt,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to start website scan");
      }

      const createdScan = data.scan as ScanRecord;
      setActiveDetails({
        scan: createdScan,
        pages: [],
        interactions: [],
        report: null,
        prompts: [],
      });
      void fetchHistory();
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : "Failed to submit URL");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteScan = async (scanId: string) => {
    await fetch(`/api/scans/${scanId}`, { method: "DELETE" });
    if (activeDetails?.scan.id === scanId) {
      setActiveDetails(null);
    }
    void fetchHistory();
  };

  const handlePromptCreated = (newPrompt: MasterPromptRecord) => {
    setActiveDetails((prev) =>
      prev ? { ...prev, prompts: [newPrompt, ...prev.prompts] } : prev
    );
  };

  const scan = activeDetails?.scan ?? null;
  const isScanning = scan ? ACTIVE_STATUSES.has(scan.status) : false;

  return (
    <div className="min-h-screen bg-surface-950 text-zinc-100">
      {/* Top Navigation */}
      <header className="border-b border-zinc-800 bg-surface-900/90 sticky top-0 z-30">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-indigo-500/30 bg-indigo-500/10 text-indigo-400">
              <ScanSearch className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-base font-semibold tracking-tight text-white">
                Website X-Ray AI
              </h1>
              <p className="text-xs text-zinc-400">
                Deep Website Analyzer &amp; Master Prompt Generator
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden items-center gap-1.5 rounded-lg border border-zinc-800 bg-surface-950 px-3 py-1.5 text-xs text-zinc-400 sm:flex">
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
              <span>SSRF Guard &amp; Public-Only Mode</span>
            </div>

            <button
              type="button"
              onClick={() => setShowHistory((s) => !s)}
              className="inline-flex items-center gap-2 rounded-lg border border-zinc-700 bg-surface-850 px-3 py-1.5 text-xs font-medium text-zinc-200 transition hover:bg-surface-800"
            >
              <History className="h-3.5 w-3.5" />
              <span>History ({history.length})</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 space-y-6">
        {/* History Drawer */}
        {showHistory && (
          <section className="rounded-xl border border-zinc-800 bg-surface-900 p-4">
            <h2 className="text-sm font-semibold text-zinc-200 mb-3">Recent Analysis History</h2>
            {history.length === 0 ? (
              <p className="text-xs text-zinc-500">No scans recorded yet.</p>
            ) : (
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {history.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between rounded-lg border border-zinc-800 bg-surface-950 px-3 py-2.5"
                  >
                    <button
                      type="button"
                      onClick={() => {
                        void fetchScanDetails(item.id);
                        setShowHistory(false);
                      }}
                      className="min-w-0 flex-1 text-left"
                    >
                      <div className="truncate font-mono text-xs font-medium text-zinc-200">
                        {item.domain}
                      </div>
                      <div className="mt-0.5 flex items-center gap-2 text-[11px] text-zinc-500">
                        <span>{item.status}</span>
                        <span>·</span>
                        <span>{item.pagesAnalyzed} pages</span>
                        <span>·</span>
                        <span>{item.buttonsTested} tests</span>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleDeleteScan(item.id)}
                      aria-label={`Delete scan for ${item.domain}`}
                      className="ml-2 rounded p-1.5 text-zinc-500 hover:bg-surface-800 hover:text-rose-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}

        {/* URL Scanner Input Card */}
        <section className="rounded-xl border border-zinc-800 bg-surface-900 p-5 sm:p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex flex-col gap-3 sm:flex-row">
              <div className="relative flex-1">
                <Globe className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                <input
                  type="text"
                  required
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://example.com"
                  aria-label="Website URL to analyze"
                  className="w-full rounded-lg border border-zinc-700 bg-surface-950 py-2.5 pl-10 pr-4 font-mono text-sm text-white placeholder-zinc-500 focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <button
                type="submit"
                disabled={submitting || isScanning}
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-500 disabled:opacity-50"
              >
                {submitting || isScanning ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Scanning...
                  </>
                ) : (
                  <>
                    <ScanSearch className="h-4 w-4" />
                    Analyze Website
                  </>
                )}
              </button>
            </div>

            {/* Scanner Configuration Controls */}
            <div className="flex flex-wrap items-center gap-4 border-t border-zinc-800/80 pt-3 text-xs text-zinc-400">
              <label className="flex items-center gap-2">
                <span>Max Pages:</span>
                <select
                  value={maxPages}
                  onChange={(e) => setMaxPages(Number(e.target.value))}
                  className="rounded border border-zinc-700 bg-surface-950 px-2 py-1 text-zinc-200"
                >
                  <option value={3}>3</option>
                  <option value={6}>6</option>
                  <option value={10}>10</option>
                  <option value={15}>15</option>
                </select>
              </label>

              <label className="flex items-center gap-2">
                <span>Crawl Depth:</span>
                <select
                  value={maxDepth}
                  onChange={(e) => setMaxDepth(Number(e.target.value))}
                  className="rounded border border-zinc-700 bg-surface-950 px-2 py-1 text-zinc-200"
                >
                  <option value={1}>1</option>
                  <option value={2}>2</option>
                  <option value={3}>3</option>
                </select>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeMobile}
                  onChange={(e) => setIncludeMobile(e.target.checked)}
                  className="rounded border-zinc-700 bg-surface-950 text-indigo-600"
                />
                <span>Inspect Mobile Viewport (390px)</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={respectRobotsTxt}
                  onChange={(e) => setRespectRobotsTxt(e.target.checked)}
                  className="rounded border-zinc-700 bg-surface-950 text-indigo-600"
                />
                <span>Respect robots.txt</span>
              </label>
            </div>

            {submitError && (
              <div className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-sm text-rose-300">
                {submitError}
              </div>
            )}
          </form>
        </section>

        {/* Live Scanning Progress & Telemetry Counters */}
        {scan && (
          <section className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-xl border border-zinc-800 bg-surface-900 p-4">
                <div className="flex items-center justify-between text-xs text-zinc-400">
                  <span>Analysis Status</span>
                  <Activity className="h-4 w-4 text-indigo-400" />
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="font-mono text-base font-semibold uppercase text-white">
                    {scan.status.replace("_", " ")}
                  </span>
                  <span className="font-mono text-xs text-indigo-400">
                    {scan.progressPercent}%
                  </span>
                </div>
                <div className="mt-2.5 h-1.5 w-full overflow-hidden rounded-full bg-surface-800">
                  <div
                    className={`h-full transition-all duration-300 ${
                      scan.status === "failed"
                        ? "bg-rose-500"
                        : scan.status === "completed"
                        ? "bg-emerald-500"
                        : "bg-indigo-500"
                    }`}
                    style={{ width: `${scan.progressPercent}%` }}
                  />
                </div>
              </div>

              <div className="rounded-xl border border-zinc-800 bg-surface-900 p-4">
                <div className="flex items-center justify-between text-xs text-zinc-400">
                  <span>Current Page Being Analyzed</span>
                  <Clock className="h-4 w-4 text-zinc-500" />
                </div>
                <div className="mt-2 truncate font-mono text-sm font-medium text-zinc-100">
                  {scan.currentPage || (scan.status === "completed" ? "All pages finished" : "—")}
                </div>
                <div className="mt-1 text-xs text-zinc-500">
                  Target: {scan.domain}
                </div>
              </div>

              <div className="rounded-xl border border-zinc-800 bg-surface-900 p-4">
                <div className="flex items-center justify-between text-xs text-zinc-400">
                  <span>Pages Discovered</span>
                  <Globe className="h-4 w-4 text-emerald-400" />
                </div>
                <div className="mt-2 font-mono text-2xl font-semibold text-white">
                  {scan.pagesDiscovered}
                </div>
                <div className="mt-1 text-xs text-zinc-500">
                  {scan.pagesAnalyzed} inspected in Playwright
                </div>
              </div>

              <div className="rounded-xl border border-zinc-800 bg-surface-900 p-4">
                <div className="flex items-center justify-between text-xs text-zinc-400">
                  <span>Buttons &amp; Controls Tested</span>
                  <MousePointerClick className="h-4 w-4 text-amber-400" />
                </div>
                <div className="mt-2 font-mono text-2xl font-semibold text-white">
                  {scan.buttonsTested}
                </div>
                <div className="mt-1 text-xs text-zinc-500">
                  {scan.interactionsPassed} passed · {scan.interactionsFailed} failed ·{" "}
                  {scan.interactionsBlocked} skipped
                </div>
              </div>
            </div>

            {scan.errorMessage && (
              <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-4 text-sm text-rose-300">
                <strong>Scan Error: </strong>
                {scan.errorMessage}
              </div>
            )}

            {/* Live Logs */}
            {scan.logs.length > 0 && (
              <details open={isScanning} className="rounded-xl border border-zinc-800 bg-surface-900">
                <summary className="cursor-pointer px-4 py-2.5 text-xs font-medium text-zinc-300 select-none">
                  Live Execution Log ({scan.logs.length} events)
                </summary>
                <div className="max-h-44 overflow-y-auto border-t border-zinc-800 bg-surface-950 p-3 font-mono text-[11px] space-y-1">
                  {scan.logs.map((entry, idx) => (
                    <div
                      key={idx}
                      className={
                        entry.level === "error"
                          ? "text-rose-400"
                          : entry.level === "warn"
                          ? "text-amber-400"
                          : entry.level === "success"
                          ? "text-emerald-400"
                          : "text-zinc-400"
                      }
                    >
                      <span className="text-zinc-600">
                        [{new Date(entry.timestamp).toLocaleTimeString()}]{" "}
                      </span>
                      {entry.message}
                    </div>
                  ))}
                </div>
              </details>
            )}

            {/* Detailed Results & Master Prompt */}
            {activeDetails && (activeDetails.pages.length > 0 || scan.status === "completed") && (
              <ScanResultsDashboard
                details={activeDetails}
                onPromptCreated={handlePromptCreated}
              />
            )}
          </section>
        )}
      </main>
    </div>
  );
}
