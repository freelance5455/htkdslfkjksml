import Link from "next/link";
import { notFound } from "next/navigation";
import { Stars } from "@/components/stars";
import { ensureSeeded, getMemberById, getSessionMember, getSquadSnapshot } from "@/lib/data";
import { formatAvg } from "@/lib/palette";
import { PosterImage } from "@/components/poster";

export const dynamic = "force-dynamic";

export default async function FriendPage({ params }: { params: Promise<{ id: string }> }) {
  await ensureSeeded();

  const session = await getSessionMember().catch(() => null);

  const { id } = await params;
  const memberId = Number.parseInt(id, 10);
  if (!Number.isFinite(memberId)) notFound();

  const member = await getMemberById(memberId);
  if (!member) notFound();

  const snapshot = await getSquadSnapshot(member.squadId);
  if (!snapshot) notFound();

  const stats = snapshot.members.find((item) => item.id === member.id);
  if (!stats) notFound();

  const memberEntries = snapshot.entries.filter((entry) => entry.memberId === member.id);
  const movieById = new Map(snapshot.movies.map((movie) => [movie.id, movie]));
  const watched = memberEntries
    .filter((entry) => entry.status === "watched")
    .sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
  const watchlist = memberEntries.filter((entry) => entry.status === "watchlist");
  const reviews = memberEntries.filter((entry) => (entry.review ?? "").trim().length > 0);
  const viewerId = session?.member.id ?? null;
  const isMe = viewerId === member.id;

  const myWatchedIds = new Set(
    snapshot.entries
      .filter((entry) => entry.memberId === viewerId && entry.status === "watched")
      .map((entry) => entry.movieId),
  );
  const theirWatchedIds = new Set(watched.map((entry) => entry.movieId));
  const shared = watched.filter((entry) => myWatchedIds.has(entry.movieId));
  const onlyThem = watched.filter((entry) => !myWatchedIds.has(entry.movieId));
  const onlyMe = snapshot.movies.filter(
    (movie) => myWatchedIds.has(movie.id) && !theirWatchedIds.has(movie.id),
  );

  return (
    <div className="min-h-screen pb-16">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-mv-ink/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link href="/squad" className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-mv-red font-display text-lg text-white">
              M
            </span>
            <span className="font-display text-lg leading-none tracking-wide text-white">
              Marvel<span className="text-mv-red">Squad</span>
            </span>
          </Link>
          <Link
            href="/squad"
            className="ml-auto rounded-xl border border-white/12 px-3 py-1.5 text-[11px] font-bold uppercase tracking-widest text-white/60 transition hover:border-white/35 hover:text-white"
          >
            ← Torna alla squadra
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4">
        <section className="comic-panel relative mt-5 overflow-hidden rounded-3xl p-5 sm:p-6">
          <div className="stripes absolute inset-x-0 top-0 h-1.5 opacity-80" />
          <div
            className="halftone pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full opacity-10"
            style={{ backgroundColor: stats.color }}
          />
          <div className="flex flex-wrap items-center gap-4">
            <span
              className="grid h-16 w-16 place-items-center rounded-2xl text-3xl"
              style={{ backgroundColor: `${stats.color}26`, color: stats.color }}
            >
              {stats.avatar}
            </span>
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.3em] text-white/40">
                {isMe ? "Il tuo profilo" : "Profilo di un amico"}
              </p>
              <h1 className="font-display text-3xl leading-none text-white sm:text-4xl">{stats.name}</h1>
              <p className="mt-1 font-mono text-[10px] tracking-widest text-white/35">{stats.code}</p>
            </div>
            <div className="ml-auto grid grid-cols-2 gap-2 sm:grid-cols-4">
              {[
                ["Visti", `${stats.watched}`],
                ["Watchlist", `${stats.watchlist}`],
                ["Media", formatAvg(stats.avgRating)],
                ["Preferiti", `${stats.favorites}`],
              ].map(([label, value]) => (
                <div key={label} className="rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2 text-center">
                  <p className="font-display text-xl leading-none text-white">{value}</p>
                  <p className="text-[9px] font-bold uppercase tracking-widest text-white/35">{label}</p>
                </div>
              ))}
            </div>
          </div>
          {stats.topFilm ? (
            <p className="mt-4 rounded-xl border border-mv-gold/25 bg-mv-gold/5 px-3 py-2 text-xs text-white/70">
              Il suo preferito: <span className="font-bold text-mv-gold">{stats.topFilm.title}</span>{" "}
              <span className="text-mv-gold">{"★".repeat(stats.topFilm.rating)}</span>
            </p>
          ) : null}
        </section>

        {!isMe && viewerId !== null ? (
          <section className="mt-4 grid gap-2 sm:grid-cols-3">
            {[
              ["🤝", `${shared.length}`, "film visti insieme"],
              ["🙋", `${onlyMe.length}`, "visti solo da te"],
              ["🎯", `${onlyThem.length}`, `visti solo da ${stats.name}`],
            ].map(([emoji, value, label]) => (
              <div key={label} className="comic-panel flex items-center gap-3 rounded-2xl px-4 py-3">
                <span className="text-xl">{emoji}</span>
                <div>
                  <p className="font-display text-2xl leading-none text-white">{value}</p>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/35">{label}</p>
                </div>
              </div>
            ))}
            {shared.length > 0 ? (
              <div className="comic-panel rounded-2xl p-3 sm:col-span-3">
                <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">Avete visto entrambi</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {shared.map((entry) => {
                    const movie = movieById.get(entry.movieId);
                    if (!movie) return null;
                    const mine = snapshot.entries.find(
                      (item) => item.memberId === viewerId && item.movieId === entry.movieId,
                    );
                    return (
                      <span
                        key={entry.movieId}
                        className="rounded-lg border border-white/10 bg-white/[0.03] px-2 py-1 text-[10px] text-white/70"
                      >
                        {movie.title}
                        <span className="ml-1.5 text-mv-gold">
                          {entry.rating ?? "?"}★ / {mine?.rating ?? "?"}★
                        </span>
                      </span>
                    );
                  })}
                </div>
              </div>
            ) : null}
          </section>
        ) : null}

        <section className="mt-5">
          <div className="flex items-end justify-between">
            <h2 className="font-display text-2xl text-white">I film che ha visto</h2>
            <span className="text-[11px] uppercase tracking-widest text-white/35">{watched.length} film</span>
          </div>
          {watched.length === 0 ? (
            <p className="mt-3 rounded-2xl border border-dashed border-white/10 p-6 text-center text-sm text-white/40">
              Non ha ancora segnato nessun film.
            </p>
          ) : (
            <div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
              {watched.map((entry) => {
                const movie = movieById.get(entry.movieId);
                if (!movie) return null;
                return (
                  <div key={entry.movieId} className="relative">
                    <div className="relative aspect-[2/3] overflow-hidden rounded-2xl border border-white/10 shadow-lg">
                      <PosterImage
                        src={movie.posterUrl}
                        palette={movie.palette}
                        alt={movie.title}
                        className="absolute inset-0 h-full w-full"
                        width={300}
                      />
                      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
                      <span className="absolute left-1.5 top-1.5 rounded bg-black/70 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white/85">
                        {movie.saga === "MCU" ? `Fase ${movie.phase}` : movie.saga}
                      </span>
                      {entry.favorite ? <span className="absolute right-1.5 top-1.5 text-xs text-mv-red">♥</span> : null}
                      <div className="absolute inset-x-0 bottom-0 p-2">
                        <p className="font-display text-[12px] leading-[1.1] text-white drop-shadow">{movie.title}</p>
                        <p className="text-[9px] text-white/60">{movie.year}</p>
                      </div>
                    </div>
                    <div className="mt-1.5 flex items-center justify-between">
                      <Stars value={entry.rating ?? 0} size="sm" readOnly />
                      <span className="text-[10px] text-white/30">{entry.rating ? `${entry.rating}/5` : "—"}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          <section className="comic-panel rounded-3xl p-5">
            <h2 className="font-display text-2xl text-white">Watchlist</h2>
            <div className="mt-3 space-y-2">
              {watchlist.length === 0 ? (
                <p className="text-xs text-white/40">Nessun film in watchlist.</p>
              ) : (
                watchlist.map((entry) => {
                  const movie = movieById.get(entry.movieId);
                  if (!movie) return null;
                  return (
                    <div
                      key={entry.movieId}
                      className="flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.02] p-2"
                    >
                      <PosterImage
                        src={movie.posterUrl}
                        palette={movie.palette}
                        alt={movie.title}
                        className="h-10 w-8 shrink-0 rounded-md"
                        width={100}
                        emojiClassName="text-sm"
                      />
                      <div className="min-w-0">
                        <p className="truncate text-xs font-bold text-white">{movie.title}</p>
                        <p className="text-[10px] text-white/35">{movie.year}</p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </section>

          <section className="comic-panel rounded-3xl p-5">
            <h2 className="font-display text-2xl text-white">Recensioni</h2>
            <div className="mt-3 space-y-2">
              {reviews.length === 0 ? (
                <p className="text-xs text-white/40">Nessuna recensione scritta.</p>
              ) : (
                reviews.map((entry) => {
                  const movie = movieById.get(entry.movieId);
                  if (!movie) return null;
                  return (
                    <div key={entry.movieId} className="rounded-xl border border-white/8 bg-white/[0.02] p-3">
                      <div className="flex items-center justify-between gap-2">
                        <p className="truncate text-xs font-bold text-white">{movie.title}</p>
                        <Stars value={entry.rating ?? 0} size="sm" readOnly />
                      </div>
                      <p className="mt-1 text-xs italic leading-relaxed text-white/55">“{entry.review}”</p>
                    </div>
                  );
                })
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
