import Link from "next/link";

export default function NotFound() {
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="comic-panel relative w-full max-w-lg overflow-hidden rounded-3xl p-8 text-center">
        <div className="stripes absolute inset-x-0 top-0 h-1.5 opacity-80" />
        <p className="text-[10px] font-black uppercase tracking-[0.3em] text-mv-red">Errore 404</p>
        <h1 className="mt-2 font-display text-5xl leading-none text-white">
          Sei nel <span className="text-mv-red">multiverso</span> sbagliato
        </h1>
        <p className="mt-3 text-sm text-white/55">
          Questa pagina non esiste in nessuna delle 616 dimensioni conosciute. Torna alla tua squadra.
        </p>
        <Link
          href="/squad"
          className="mt-6 inline-block rounded-xl bg-mv-red px-5 py-3 text-xs font-black uppercase tracking-widest text-white transition hover:bg-mv-red-dark"
        >
          Torna alla squadra
        </Link>
      </div>
    </div>
  );
}
