import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center gap-3 px-4 text-center">
      <span className="text-4xl">🧭</span>
      <h1 className="text-xl font-bold">Page not found</h1>
      <p className="text-sm text-[color:var(--muted)]">That link doesn&apos;t exist in the toolkit.</p>
      <Link href="/home" className="btn btn-primary">
        Go to dashboard
      </Link>
    </div>
  );
}
