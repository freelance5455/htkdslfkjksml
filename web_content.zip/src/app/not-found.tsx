import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { LogoMark } from "@/components/logo-mark";
import { WaveDivider } from "@/components/page-hero";

export const metadata: Metadata = {
  title: "الصفحة غير موجودة",
};

export default function NotFound() {
  return (
    <main className="relative isolate flex min-h-svh flex-col items-center justify-center overflow-hidden bg-navy-deep px-5 pt-32 pb-40 text-center text-ivory">
      <div
        className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_70%_60%_at_50%_40%,rgba(49,75,117,0.9),transparent_70%),radial-gradient(ellipse_50%_40%_at_50%_30%,rgba(182,154,105,0.22),transparent_70%),linear-gradient(180deg,#0F1828_0%,#17243A_60%,#1B2C48_100%)]"
        aria-hidden="true"
      />
      <div className="pattern-lattice mask-radial absolute inset-0 -z-10 opacity-[0.09]" aria-hidden="true" />
      <div className="grain absolute inset-0 -z-10 opacity-[0.06] mix-blend-overlay" aria-hidden="true" />

      <span className="mb-6 grid size-14 place-items-center rounded-full border border-gold/50 bg-gradient-to-br from-royal to-navy text-gold">
        <LogoMark className="size-6" />
      </span>
      <p className="font-serif text-8xl font-bold text-gold-gradient sm:text-9xl">٤٠٤</p>
      <h1 className="mt-4 font-serif text-4xl font-bold sm:text-5xl">الصفحة غير موجودة</h1>
      <p className="mt-5 max-w-md text-lg leading-8 text-ivory/70">
        الرابط الذي تبحث عنه غير متوفر، أو ربما تغيّر مكانه. يمكنك العودة إلى الرئيسية أو اختيار قسم آخر.
      </p>

      <div className="mt-10 flex flex-wrap justify-center gap-4">
        <Link
          href="/"
          className="group inline-flex items-center gap-3 rounded-full bg-gradient-to-b from-gold-light to-gold px-8 py-4 font-semibold text-navy shadow-[0_20px_50px_-15px_rgba(182,154,105,0.9)] transition-all hover:-translate-y-0.5"
        >
          العودة للرئيسية
          <ArrowLeft className="size-5 transition-transform group-hover:-translate-x-1" aria-hidden="true" />
        </Link>
        <Link
          href="/quran"
          className="inline-flex items-center gap-3 rounded-full border border-ivory/25 bg-ivory/5 px-8 py-4 font-medium text-ivory transition-all hover:border-gold hover:text-gold-light"
        >
          فهرس القرآن
        </Link>
        <Link
          href="/paths"
          className="inline-flex items-center gap-3 rounded-full border border-ivory/25 bg-ivory/5 px-8 py-4 font-medium text-ivory transition-all hover:border-gold hover:text-gold-light"
        >
          المسارات التعليمية
        </Link>
      </div>

      <WaveDivider />
    </main>
  );
}
