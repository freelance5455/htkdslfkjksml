import type { Metadata } from "next";
import { PageHero } from "@/components/page-hero";
import { HADITHS } from "@/data/hadith";
import { toArabicDigits } from "@/lib/site";

export const metadata: Metadata = {
  title: "الحديث الشريف",
  description: "أحاديث جامعة مختارة مع راويها ومصدرها وشرح موجز لمعانيها.",
};

export default function HadithPage() {
  return (
    <main>
      <PageHero
        eyebrow="من مشكاة النبوة"
        title={
          <>
            الحديث <span className="text-gold-gradient">الشريف</span>
          </>
        }
        description="أحاديث جامعة مختارة من الصحيحين وكتب السنن، مع راويها ومصدرها وشرح موجز لمعانيها."
      />

      <section className="relative bg-ivory py-20 sm:py-24">
        <div className="mx-auto max-w-5xl px-5 lg:px-8">
          <p className="mb-10 text-sm text-navy/60">
            عدد الأحاديث: <span className="font-semibold text-navy">{toArabicDigits(HADITHS.length)}</span>
          </p>

          <ol className="grid gap-6">
            {HADITHS.map((hadith, i) => (
              <li
                key={hadith.id}
                id={hadith.id}
                className="reveal relative scroll-mt-28 overflow-hidden rounded-[2rem] border border-border bg-card p-7 shadow-[0_30px_70px_-45px_rgba(23,36,58,0.55)] sm:p-10"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <span className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-gold/10 px-4 py-1 text-xs text-gold">
                    {hadith.theme}
                  </span>
                  <span className="font-serif text-lg text-gold">{toArabicDigits(i + 1)}</span>
                </div>

                <blockquote className="mt-6 font-serif text-2xl leading-[2.1] text-navy sm:text-3xl" lang="ar">
                  {hadith.text}
                </blockquote>

                <dl className="mt-6 flex flex-wrap gap-x-8 gap-y-3 text-sm text-navy/60">
                  <div>
                    <dt className="inline">الراوي: </dt>
                    <dd className="inline font-medium text-navy">{hadith.narrator}</dd>
                  </div>
                  <div>
                    <dt className="inline">المصدر: </dt>
                    <dd className="inline font-medium text-navy">{hadith.source}</dd>
                  </div>
                </dl>

                <details className="group mt-6 rounded-2xl bg-ivory p-5">
                  <summary className="flex cursor-pointer list-none items-center justify-between font-medium text-royal transition-colors hover:text-gold">
                    شرح موجز
                    <span className="grid size-7 place-items-center rounded-full border border-gold/40 text-lg leading-none text-gold transition-transform group-open:rotate-45">
                      +
                    </span>
                  </summary>
                  <p className="mt-4 leading-8 text-navy/70">{hadith.explanation}</p>
                </details>
              </li>
            ))}
          </ol>
        </div>
      </section>
    </main>
  );
}
