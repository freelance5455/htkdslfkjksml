import { useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import { Maximize2, Play, Radio, TriangleAlert, Volume2, VolumeX } from "lucide-react";

interface Props {
  src: string;
  title: string;
  live?: boolean;
}

export default function VideoPlayer({ src, title, live = true }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const autoplay = useRef((() => { try { return window.localStorage.getItem("lo3-autoplay") !== "false"; } catch { return true; } })());
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [muted, setMuted] = useState(() => { try { return window.localStorage.getItem("lo3-muted-default") === "true"; } catch { return false; } });
  const [attempt, setAttempt] = useState(0);
  const [videoPaused, setVideoPaused] = useState(true);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    setStatus("loading");
    let cancelled = false;

    const cleanup = () => {
      hlsRef.current?.destroy();
      hlsRef.current = null;
      video.removeAttribute("src");
      video.load();
    };

    const isHlsUrl = /\.m3u8($|[?#])/i.test(src);
    const canNative = !isHlsUrl && video.canPlayType("application/vnd.apple.mpegurl") !== "";
    if (canNative || !isHlsUrl) {
      // MP4/progressivo directo o navegadores con HLS nativo (Safari/Android)
      video.src = src;
      const onReady = () => !cancelled && setStatus("ready");
      const onErr = () => !cancelled && setStatus("error");
      const onStall = () => { /* el navegador reintenta solo */ };
      video.addEventListener("playing", onReady);
      video.addEventListener("error", onErr);
      video.addEventListener("stalled", onStall);
      const timer = window.setTimeout(() => !cancelled && setStatus((st) => (st === "loading" ? "error" : st)), 12000);
      return () => { cancelled = true; window.clearTimeout(timer); video.removeEventListener("playing", onReady); video.removeEventListener("error", onErr); video.removeEventListener("stalled", onStall); cleanup(); };
    }
    if (Hls.isSupported()) {
      const hls = new Hls({ maxBufferLength: 30, enableWorker: true });
      hlsRef.current = hls;
      hls.loadSource(src);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => { if (!cancelled) { setStatus("ready"); if (autoplay.current) video.play().catch(() => {}); } });
      hls.on(Hls.Events.ERROR, (_evt, data) => {
        if (data.fatal) { hls.destroy(); if (!cancelled) setStatus("error"); }
      });
      return () => { cancelled = true; cleanup(); };
    }
    setStatus("error");
    return () => { cancelled = true; cleanup(); };
  }, [src, attempt]);

  const toggleFullscreen = () => {
    const frame = frameRef.current;
    if (!frame) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void frame.requestFullscreen().catch(() => {});
  };

  return (
    <div ref={frameRef} className="group/player relative aspect-video w-full overflow-hidden rounded-2xl border border-white/10 bg-black shadow-2xl">
      <video ref={videoRef} className="h-full w-full" controls autoPlay={autoplay.current} playsInline muted={muted} onPlay={() => setVideoPaused(false)} onPause={() => setVideoPaused(true)} aria-label={`Reproduciendo ${title}`} />

      {/* top overlay */}
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between bg-gradient-to-b from-black/70 to-transparent p-3">
        <div className="flex items-center gap-2">
          {live && <span className="flex items-center gap-1.5 rounded-md bg-red-600 px-2 py-1 text-[10px] font-black uppercase tracking-widest text-white"><span className="h-2 w-2 animate-live rounded-full bg-white" />En vivo</span>}
          <span className="max-w-[60%] truncate text-xs font-bold text-white">{title}</span>
        </div>
        <div className="pointer-events-auto flex items-center gap-1.5">
          <button onClick={() => setMuted((v) => !v)} aria-label={muted ? "Activar sonido" : "Silenciar"} className="flex h-8 w-8 items-center justify-center rounded-lg bg-black/55 text-white backdrop-blur-sm transition-colors hover:bg-black/80">
            {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
          <button onClick={toggleFullscreen} aria-label="Pantalla completa" className="flex h-8 w-8 items-center justify-center rounded-lg bg-black/55 text-white backdrop-blur-sm transition-colors hover:bg-black/80">
            <Maximize2 size={15} />
          </button>
        </div>
      </div>

      {/* manual start when autoplay disabled */}
      {!autoplay.current && status === "ready" && videoPaused && (
        <button onClick={() => videoRef.current?.play().catch(() => {})} aria-label="Reproducir" className="absolute inset-0 flex items-center justify-center bg-black/35 transition-colors hover:bg-black/20">
          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-cyanx text-abyss shadow-2xl"><Play size={26} fill="currentColor" className="ml-1" /></span>
        </button>
      )}

      {/* loading */}
      {status === "loading" && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/45">
          <Radio size={30} className="animate-pulse text-cyanx" />
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-cyan-100">Sintonizando…</p>
        </div>
      )}

      {/* error */}
      {status === "error" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-[#05081f]/95 p-4 text-center">
          <TriangleAlert size={30} className="text-amber-400" />
          <p className="text-sm font-bold text-white">Señal no disponible</p>
          <p className="max-w-xs text-[11px] leading-snug text-slate-400">Esta emisión pública puede estar geobloqueada en tu región o caída en origen. Prueba otro canal de la lista.</p>
          <button onClick={() => setAttempt((a) => a + 1)} className="mt-1 h-9 rounded-xl border border-cyanx/40 bg-cyanx/10 px-4 text-xs font-bold text-cyanx transition-colors hover:bg-cyanx hover:text-abyss">Reintentar</button>
        </div>
      )}
    </div>
  );
}
