import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, BookOpenText, HeartHandshake, Sparkles } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { LogoMark } from "@/components/logo-mark";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: "عن المشروع",
  description: "عن مشروع لأنه الله: منصة تعليمية إسلامية، إعداد محمد هشام الترجمان، مدرسة الفرقان الشرعية.",
};

const PILLARS = [
  {
    icon: BookOpenText,
    title: "بالعلم نرتقي",
    text: "محتوى موثوق من القرآن والسنة والسيرة، يُعرض في مسارات متدرجة تنتهي باختبار يثبّت الفهم.",
    href: "/paths",
  },
  {
    icon: HeartHandshake,
    title: "وبالذكر نطمئن",
    text: "أذكار الصباح والمساء وما بعد الصلاة والنوم، وتجربة تسبيح تفاعلية مع عدّاد محفوظ في متصفحك.",
    href: "/adhkar",
  },
  {
    icon: Sparkles,
    title: "وبالإيمان نحيا",
    text: "قيم تُعاش في السلوك والحياة اليومية، من خلال قصص الصحابة وسيرة النبي ﷺ ومحاضرات التزكية.",
    href: "/lectures",
  },
];

const SOURCES = [
  {
    title: "نصوص القرآن الكريم",
    text: "واجهة برمجة alquran.cloud، بالرسم العثماني.",
  },
  {
    title: "التلاوة الصوتية",
    text: "تلاوة الشيخ مشاري راشد العفاسي لكل آية، عبر خدمة cdn.islamic.network.",
  },
  {
    title: "الأحاديث النبوية",
    text: "من الصحيحين (البخاري ومسلم) وكتب السنن (أبي داود والترمذي وابن ماجه)، مع بيان المصدر عند كل حديث.",
  },
  {
    title: "السيرة وقصص الصحابة",
    text: "سرد مختصر مستخلص من كتب السيرة والتاريخ الإسلامي المعتمدة.",
  },
];

export default function AboutPage() {
  return (
    <main>
      <PageHero
        eyebrow="عن المشروع"
        title={
          <>
            لأنه <span className="text-gold-gradient">الله</span>
          </>
        }
        description="مشروع تعليمي إسلامي يجمع بين كتاب الله وسنة نبيه ﷺ، ويقدّم العلم في صورة رحلة متدرجة، والذكر في صورة تجربة تفاعلية تُطمئن القلب."
      />

      {/* Pillars */}
      <section className="relative bg-ivory py-20 sm:py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mb-14 max-w-2xl">
            <p className="inline-flex items-center gap-3 text-sm font-medium tracking-wide text-gold">
              <LogoMark className="size-4" />
              رسالة المشروع
            </p>
            <h2 className="mt-4 font-serif text-5xl leading-tight font-bold text-navy sm:text-6xl">
              ثلاثة <span className="text-royal">أركان</span> لرحلة واحدة
            </h2>
          </div>

          <ul className="grid gap-6 md:grid-cols-3">
            {PILLARS.map(({ icon: Icon, title, text, href }) => (
              <li key={title}>
                <Link
                  href={href}
                  className="group relative flex h-full flex-col overflow-hidden rounded-[2rem] border border-border bg-card p-8 shadow-[0_30px_70px_-45px_rgba(23,36,58,0.55)] transition-all duration-500 hover:-translate-y-1 hover:border-gold/60"
                >
                  <span className="grid size-14 place-items-center rounded-2xl bg-navy text-gold-light">
                    <Icon className="size-6" aria-hidden="true" />
                  </span>
                  <h3 className="mt-6 font-serif text-2xl font-bold text-navy">{title}</h3>
                  <p className="mt-3 flex-1 leading-8 text-navy/65">{text}</p>
                  <span className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-royal group-hover:text-gold">
                    استكشف القسم <ArrowLeft className="size-4" aria-hidden="true" />
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Identity */}
      <section className="relative overflow-hidden bg-navy py-20 text-ivory sm:py-24">
        <div className="pattern-lattice absolute inset-0 opacity-[0.06]" aria-hidden="true" />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-5 lg:grid-cols-2 lg:px-8">
          <div>
            <p className="text-sm text-gold-light">هوية المشروع</p>
            <h2 className="mt-3 font-serif text-5xl font-bold">{SITE.name}</h2>
            <p className="mt-6 max-w-lg leading-8 text-ivory/70">
              منصة تعليمية إسلامية تُعدّ ضمن مشروع دراسي في مدرسة الفرقان الشرعية.
            </p>
          </div>
          <dl className="grid gap-6 sm:grid-cols-2">
            <div className="rounded-2xl border border-gold/30 bg-white/[0.03] p-6">
              <dt className="text-xs text-gold-light">إعداد الطالب</dt>
              <dd className="mt-2 font-serif text-2xl font-bold">{SITE.author}</dd>
            </div>
            <div className="rounded-2xl border border-gold/30 bg-white/[0.03] p-6">
              <dt className="text-xs text-gold-light">المدرسة</dt>
              <dd className="mt-2 font-serif text-2xl font-bold">{SITE.school}</dd>
            </div>
          </dl>
        </div>
      </section>

      {/* Sources */}
      <section id="sources" className="relative scroll-mt-24 bg-ivory py-20 sm:py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <h2 className="font-serif text-4xl font-bold text-navy sm:text-5xl">المصادر والمراجع</h2>
          <p className="mt-4 max-w-2xl leading-8 text-navy/65">
            نعتمد على مصادر موثوقة في النص القرآني والحديث والسيرة، ونذكر مصدر كل حديث بجانبه.
          </p>
          <ul className="mt-12 grid gap-6 md:grid-cols-2">
            {SOURCES.map((s) => (
              <li key={s.title} className="rounded-3xl border border-border bg-card p-7">
                <p className="font-serif text-xl font-bold text-navy">{s.title}</p>
                <p className="mt-2 leading-7 text-navy/65">{s.text}</p>
              </li>
            ))}
          </ul>

          <div className="mt-16 rounded-[2.5rem] border border-gold/30 bg-gradient-to-br from-stone via-ivory to-stone p-10 text-center">
            <p className="font-serif text-3xl leading-[1.9] text-navy">﴿وَقُل رَّبِّ زِدْنِي عِلْمًا﴾</p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Link
                href="/paths"
                className="inline-flex items-center gap-3 rounded-full bg-navy px-8 py-4 font-semibold text-ivory transition-all hover:-translate-y-0.5 hover:bg-royal"
              >
                ابدأ المسارات التعليمية
              </Link>
              <Link
                href="/quran"
                className="inline-flex items-center gap-3 rounded-full border border-navy/20 px-8 py-4 font-medium text-navy transition-all hover:border-gold hover:text-gold"
              >
                افتح المصحف
              </Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
