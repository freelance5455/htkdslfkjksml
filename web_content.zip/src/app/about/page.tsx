"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Award, CalendarCheck, GraduationCap, HeartHandshake, MapPin, Mail, MessageCircle, Phone, Sparkles } from "lucide-react";
import { useI18n, useSite } from "@/components/providers";
import { Avatar, buttonClass, Card, PageHeader, ServiceIcon } from "@/components/ui";
import { api } from "@/lib/api-client";
import type { ServiceDTO } from "@/lib/types";
import { loc } from "@/lib/utils";

export default function AboutPage() {
  const { t, locale } = useI18n();
  const { settings, whatsapp, callLink, defaultMessage } = useSite();
  const [services, setServices] = useState<ServiceDTO[]>([]);

  useEffect(() => {
    api<{ services: ServiceDTO[] }>("/api/services")
      .then((r) => setServices(r.services))
      .catch(() => undefined);
  }, []);

  const p = settings.profile;
  const c = settings.contact;
  const name = p.name || t("about.defaultName");
  const qualifications = loc(p.qualifications, locale);
  const values = p.values.map((v) => loc(v, locale)).filter(Boolean);

  return (
    <div className="space-y-10">
      <PageHeader title={t("about.title")} />

      <section className="grid gap-6 lg:grid-cols-5">
        <Card className="relative overflow-hidden bg-gradient-to-br from-sky-50 via-white to-teal-50 p-6 sm:p-8 lg:col-span-3">
          <div className="pointer-events-none absolute -end-16 -top-16 h-56 w-56 rounded-full bg-teal-200/30 blur-2xl" />
          <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center">
            <Avatar src={p.photoUrl} name={name} className="h-28 w-28 rounded-3xl text-3xl" />
            <div>
              <h2 className="text-2xl font-extrabold text-slate-900 sm:text-3xl">{name}</h2>
              <p className="mt-1 text-base font-semibold text-teal-700">{loc(p.title, locale)}</p>
              <p className="mt-2 inline-flex items-center gap-1.5 text-sm text-slate-600">
                <MapPin className="h-4 w-4 text-teal-600" />
                {loc(p.location, locale)}
              </p>
            </div>
          </div>
          <p className="relative mt-6 text-base leading-relaxed text-slate-700">{loc(p.intro, locale)}</p>
          <div className="relative mt-7 grid gap-3 sm:grid-cols-3">
            <a href={whatsapp(defaultMessage)} target="_blank" rel="noopener noreferrer" className={buttonClass("whatsapp", "lg", "w-full")}>
              <MessageCircle className="h-5 w-5" />
              {t("btn.whatsapp")}
            </a>
            <a href={callLink} className={buttonClass("outline", "lg", "w-full")}>
              <Phone className="h-5 w-5" />
              {t("btn.callNow")}
            </a>
            <Link href="/book" className={buttonClass("primary", "lg", "w-full")}>
              <CalendarCheck className="h-5 w-5" />
              {t("btn.book")}
            </Link>
          </div>
        </Card>

        <Card className="space-y-5 lg:col-span-2">
          <h2 className="flex items-center gap-2 font-bold text-slate-900">
            <Phone className="h-5 w-5 text-teal-600" />
            {t("about.contact")}
          </h2>
          <ul className="space-y-4 text-sm text-slate-700">
            <li className="flex items-center gap-3">
              <Phone className="h-4 w-4 shrink-0 text-emerald-600" />
              <a href={callLink} className="font-semibold hover:underline" dir="ltr">{c.phoneDisplay}</a>
            </li>
            <li className="flex items-center gap-3">
              <MessageCircle className="h-4 w-4 shrink-0 text-emerald-600" />
              <a href={whatsapp(defaultMessage)} target="_blank" rel="noopener noreferrer" className="font-semibold hover:underline">
                {t("btn.whatsapp")}
              </a>
            </li>
            {c.email && (
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 shrink-0 text-teal-600" />
                <a href={`mailto:${c.email}`} className="hover:underline" dir="ltr">{c.email}</a>
              </li>
            )}
            <li className="flex items-center gap-3">
              <MapPin className="h-4 w-4 shrink-0 text-teal-600" />
              <span>{c.address ? `${c.address}, ${c.city}` : `${c.city}, ${t("app.country")}`}</span>
            </li>
            {loc(c.hours, locale) && (
              <li className="flex items-center gap-3">
                <CalendarCheck className="h-4 w-4 shrink-0 text-teal-600" />
                <span>{t("contact.hours")}: {loc(c.hours, locale)}</span>
              </li>
            )}
          </ul>
        </Card>
      </section>

      <section className="grid gap-6 md:grid-cols-2">
        <Card className="space-y-4">
          <h2 className="flex items-center gap-2 font-bold text-slate-900">
            <HeartHandshake className="h-5 w-5 text-teal-600" />
            {t("about.services")}
          </h2>
          <ul className="grid gap-2 sm:grid-cols-2">
            {services.map((s) => (
              <li key={s.id}>
                <Link href={`/services/${s.slug}`} className="flex items-center gap-2.5 rounded-xl bg-slate-50 px-3 py-2.5 text-sm font-medium text-slate-800 ring-1 ring-slate-100 transition hover:bg-teal-50 hover:ring-teal-200">
                  <ServiceIcon name={s.icon} className="h-4 w-4 shrink-0 text-teal-600" />
                  <span className="truncate">{loc(s.name, locale)}</span>
                </Link>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="space-y-4">
          <h2 className="flex items-center gap-2 font-bold text-slate-900">
            <Sparkles className="h-5 w-5 text-teal-600" />
            {t("about.values")}
          </h2>
          <ul className="space-y-3">
            {values.map((v) => (
              <li key={v} className="flex items-start gap-3 text-sm leading-relaxed text-slate-700">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-teal-500" />
                {v}
              </li>
            ))}
          </ul>
        </Card>

        {(qualifications || p.experienceYears !== null) && (
          <Card className="space-y-4 md:col-span-2">
            <h2 className="flex items-center gap-2 font-bold text-slate-900">
              <GraduationCap className="h-5 w-5 text-teal-600" />
              {t("about.qualifications")}
            </h2>
            {qualifications && <p className="whitespace-pre-line text-sm leading-relaxed text-slate-700">{qualifications}</p>}
            {p.experienceYears !== null && (
              <p className="inline-flex items-center gap-2 text-sm font-semibold text-slate-800">
                <Award className="h-4 w-4 text-teal-600" />
                {t("pro.experience", { n: p.experienceYears })}
              </p>
            )}
          </Card>
        )}
      </section>
    </div>
  );
}
