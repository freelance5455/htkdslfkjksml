import { useCallback, useEffect, useRef, useState } from "react";
import { ListMusic, Loader2, Music2, Pause, Play, Radio, Search, Square, Volume2 } from "lucide-react";
import { deezerSearch, fetchRadioStations, fetchRadioStationByUuid, stationsToM3u, type DeezerTrack, type RadioStation } from "./api";
import { usePrivacyMax } from "./usePrivacyMax";
import { useLocalStorage } from "./useLocalStorage";

/* ════════════════════ MUSIC (Deezer · previews reales de 30s) ════════════════════ */
const MUSIC_CHIPS = ["Bad Bunny", "Daft Punk", "Rosalía", "Queen", "Radiohead", "Karol G", "Imagine Dragons", "C. Tangana"];

export function MusicView() {
  const pm = usePrivacyMax();
  const [query, setQuery] = useState("Bad Bunny");
  const [tracks, setTracks] = useState<DeezerTrack[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [current, setCurrent] = useState<DeezerTrack | null>(null);
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const search = useCallback((q: string) => {
    if (!q.trim()) return;
    setLoading(true);
    setError(false);
    deezerSearch(q.trim(), 16)
      .then((t) => { setTracks(t); })
      .catch(() => { setError(true); setTracks([]); })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { search("Bad Bunny"); }, [search]);
  useEffect(() => () => { audioRef.current?.pause(); }, []);

  const toggle = (t: DeezerTrack) => {
    const audio = audioRef.current;
    if (!audio || !t.preview) return;
    if (current?.id === t.id && playing) { audio.pause(); setPlaying(false); return; }
    audio.src = t.preview;
    try { audio.volume = Number(window.localStorage.getItem("lo3-default-volume") ?? 80) / 100; } catch { audio.volume = 0.8; }
    audio.play().then(() => { setCurrent(t); setPlaying(true); }).catch(() => setPlaying(false));
    setCurrent(t);
  };

  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

  return (
    <div className="flex h-full flex-col gap-3 overflow-hidden p-3 sm:p-4">
      <audio ref={audioRef} preload="none" onEnded={() => setPlaying(false)} />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-black text-white">Music</h1>
          <p className="text-[10px] uppercase tracking-wider text-slate-500">Catálogo y previews reales de 30 s · Deezer</p>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); search(query); }} className="flex gap-1.5">
          <div className="relative">
            <Search size={13} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <label htmlFor="music-search" className="sr-only">Buscar canción o artista</label>
            <input id="music-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Canción o artista…" className="h-10 w-52 rounded-xl border border-white/10 bg-black/30 pl-9 pr-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-violetx/60 sm:w-64" />
          </div>
          <button type="submit" aria-label="Buscar" className="flex h-10 w-10 items-center justify-center rounded-xl bg-electric text-white transition-colors hover:bg-blue-500">{loading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}</button>
        </form>
      </div>

      <div className="flex gap-1 overflow-x-auto thin-scroll -mx-1 px-1">
        {MUSIC_CHIPS.map((c) => <button key={c} onClick={() => { setQuery(c); search(c); }} className="chip hover:border-violetx/50">{c}</button>)}
      </div>

      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-5">
        {/* now playing */}
        <div className="relative overflow-hidden rounded-2xl border border-violetx/25 lg:col-span-2">
          <img src="/img/art-headphones.jpg" alt="Auriculares de neón" className="absolute inset-0 h-full w-full object-cover object-[50%_28%]" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#04061a] via-[#04061a]/55 to-transparent" />
          <div className="relative flex h-full min-h-44 flex-col justify-end p-5">
            <p className="eyebrow">Sonando ahora</p>
            <p className="mt-1 truncate font-display text-xl font-black text-white">{current?.title ?? "Elige una canción"}</p>
            <p className="truncate text-xs text-slate-300">{current ? `${current.artist} — ${current.album}` : "Previews oficiales de 30 segundos"}</p>
            <div className={`mt-3 flex h-8 items-end gap-[3px] ${playing ? "" : "eq-paused"}`} aria-hidden="true">
              {Array.from({ length: 26 }).map((_, i) => <span key={i} className="eq-bar w-1.5 rounded-sm bg-gradient-to-t from-electric via-cyanx to-lilac" style={{ height: "100%", animationDelay: `${(i * 89) % 800}ms`, animationDuration: `${0.6 + (i % 5) * 0.12}s` }} />)}
            </div>
            <button onClick={() => current && toggle(current)} aria-label={playing ? "Pausar" : "Reproducir"} className="mt-3 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-cyan-400 to-blue-600 text-[#03102a] transition-transform hover:scale-105">
              {playing ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
            </button>
          </div>
        </div>

        {/* results */}
        <div className="thin-scroll min-h-0 space-y-1 overflow-y-auto pr-0.5 lg:col-span-3">
          {error && <p className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-center text-xs text-red-300">Deezer no respondió. <button className="font-bold underline" onClick={() => search(query)}>Reintentar</button></p>}
          {!loading && !error && tracks?.length === 0 && <p className="rounded-xl border border-white/8 p-5 text-center text-xs text-slate-500">Sin resultados para “{query}”.</p>}
          {loading && Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-14 animate-pulse rounded-xl bg-white/[0.04]" />)}
          {tracks?.map((t) => {
            const active = current?.id === t.id;
            return (
              <button key={t.id} onClick={() => toggle(t)} disabled={!t.preview} className={`flex w-full items-center gap-2.5 rounded-xl border p-1.5 text-left transition-colors disabled:opacity-50 ${active ? "border-violetx/50 bg-violetx/10" : "border-white/6 bg-white/[0.02] hover:border-white/15"}`} aria-label={`${playing && active ? "Pausar" : "Reproducir"} ${t.title} de ${t.artist}`}>
                {!pm && t.cover ? <img src={t.cover} alt="" loading="lazy" width={40} height={40} className="h-11 w-11 rounded-lg object-cover" onError={(e) => ((e.target as HTMLImageElement).style.visibility = "hidden")} /> : <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-panel3"><Music2 size={16} className="text-lilac" /></span>}
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[11px] font-bold text-slate-100">{t.title}</span>
                  <span className="block truncate text-[9px] text-slate-500">{t.artist} · {t.album}</span>
                </span>
                <span className="w-8 text-right font-mono text-[9px] text-slate-500">{fmt(t.duration)}</span>
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/8 text-white">{active && playing ? <Pause size={12} fill="currentColor" /> : <Play size={12} fill="currentColor" className="ml-0.5" />}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ════════════════════ RADIO (Radio Browser · emisoras en vivo) ════════════════════ */
const RADIO_COUNTRIES = [
  { code: "ES", label: "España" }, { code: "MX", label: "México" }, { code: "AR", label: "Argentina" },
  { code: "CO", label: "Colombia" }, { code: "CL", label: "Chile" }, { code: "US", label: "USA" }, { code: "ALL", label: "Mundo" },
];
const RADIO_TAGS: { id: string; label: string }[] = [
  { id: "todos", label: "Todas" }, { id: "music", label: "Música" }, { id: "sport", label: "Deportes" },
  { id: "news", label: "Noticias" }, { id: "talk", label: "Talk" }, { id: "rock", label: "Rock" },
  { id: "pop", label: "Pop" }, { id: "jazz", label: "Jazz" }, { id: "classical", label: "Clásica" }, { id: "electronic", label: "Electrónica" },
];

export function RadioView() {
  const pm = usePrivacyMax();
  const [country, setCountry] = useState("ES");
  const [tag, setTag] = useState("todos");
  const [query, setQuery] = useState("");
  const [playCounts, setPlayCounts] = useLocalStorage<Record<string, { name: string; count: number }>>("lo3-radio-counts", {});
  const [stations, setStations] = useState<RadioStation[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [current, setCurrent] = useState<RadioStation | null>(null);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(() => { try { return Number(window.localStorage.getItem("lo3-default-volume") ?? 80) / 100; } catch { return 0.8; } });
  const audioRef = useRef<HTMLAudioElement>(null);

  const load = useCallback((cc: string, q: string, t = "todos") => {
    setLoading(true);
    const ctrl = new AbortController();
    fetchRadioStations(cc, q, 18, ctrl.signal, t)
      .then(setStations)
      .catch(() => setStations([]))
      .finally(() => setLoading(false));
    return () => ctrl.abort();
  }, []);

  useEffect(() => load(country, query, tag), [country, tag]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => () => { audioRef.current?.pause(); }, []);
  useEffect(() => { if (audioRef.current) audioRef.current.volume = volume; }, [volume]);

  const toggle = (s: RadioStation) => {
    const audio = audioRef.current;
    if (!audio) return;
    if (current?.id === s.id && playing) { audio.pause(); setPlaying(false); return; }
    audio.src = s.stream;
    audio.volume = volume;
    audio.play().then(() => { setCurrent(s); setPlaying(true); }).catch(() => { setCurrent(s); setPlaying(false); });
    setCurrent(s); setPlaying(true);
    setPlayCounts((p) => { const e = p[s.id] ?? { name: s.name, count: 0 }; return { ...p, [s.id]: { name: s.name, count: e.count + 1 } }; });
  };
  const playByUuid = async (uuid: string) => {
    const st = await fetchRadioStationByUuid(uuid);
    if (st) toggle(st);
  };
  const topStations = Object.entries(playCounts).sort((a, b) => b[1].count - a[1].count).slice(0, 4);
  const downloadM3u = () => {
    if (!stations?.length) return;
    const blob = new Blob([stationsToM3u(stations)], { type: "audio/x-mpegurl" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "tvlo3-radio.m3u"; a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
  };

  const stop = () => { audioRef.current?.pause(); setPlaying(false); };

  return (
    <div className="flex h-full flex-col gap-3 overflow-hidden p-3 sm:p-4">
      <audio ref={audioRef} preload="none" />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-black text-white">Radio</h1>
          <p className="text-[10px] uppercase tracking-wider text-slate-500">Emisoras públicas en directo · Radio Browser (votos reales)</p>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); load(country, query); }} className="relative">
          <label htmlFor="radio-search" className="sr-only">Buscar emisora</label>
          <input id="radio-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar emisora y pulsa Enter…" className="h-10 w-56 rounded-xl border border-white/10 bg-black/30 pl-9 pr-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-cyanx/60" />
          <Search size={13} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        </form>
      </div>

      <div className="flex flex-wrap items-center gap-1.5">
        <div className="flex gap-1 overflow-x-auto thin-scroll -mx-1 px-1" role="tablist" aria-label="Países">
          {RADIO_COUNTRIES.map((c) => <button key={c.code} role="tab" aria-selected={country === c.code} onClick={() => setCountry(c.code)} className={`whitespace-nowrap rounded-full px-2.5 py-1.5 text-[10px] font-bold transition-colors ${country === c.code ? "bg-cyanx text-abyss" : "bg-white/5 text-slate-400 hover:text-white"}`}>{c.label}</button>)}
        </div>
        <div className="flex gap-1 overflow-x-auto thin-scroll" role="tablist" aria-label="Géneros">
          {RADIO_TAGS.map((t) => <button key={t.id} role="tab" aria-selected={tag === t.id} onClick={() => { setTag(t.id); setQuery(""); }} className={`whitespace-nowrap rounded-full px-2 py-1.5 text-[9px] font-bold uppercase tracking-wider transition-colors ${tag === t.id ? "bg-violetx text-white" : "bg-white/5 text-slate-500 hover:text-slate-200"}`}>{t.label}</button>)}
        </div>
        <button onClick={downloadM3u} disabled={!stations?.length} className="ml-auto flex h-9 items-center gap-1.5 rounded-xl border border-cyanx/30 bg-cyanx/10 px-3 text-[9px] font-bold uppercase tracking-wider text-cyanx transition-colors hover:bg-cyanx/20 disabled:opacity-40" title="Descargar lista .m3u para VLC u otras apps" aria-label="Descargar M3U"><ListMusic size={13} />M3U</button>
      </div>

      <div className="thin-scroll min-h-0 flex-1 space-y-1 overflow-y-auto pr-0.5" aria-busy={loading}>
        {loading && Array.from({ length: 10 }).map((_, i) => <div key={i} className="h-13 animate-pulse rounded-xl bg-white/[0.04]" />)}
        {!loading && stations?.length === 0 && <p className="rounded-xl border border-white/8 p-5 text-center text-xs text-slate-500">Sin emisoras para “{query}”. Prueba con otro nombre o país.</p>}
        {stations?.map((s) => {
          const active = current?.id === s.id;
          return (
            <div key={s.id} className={`flex items-center gap-2.5 rounded-xl border p-2 transition-colors ${active ? "border-cyanx/50 bg-cyanx/8" : "border-white/6 bg-white/[0.02] hover:border-white/15"}`}>
              {!pm && s.favicon ? <img src={s.favicon} alt="" loading="lazy" width={40} height={40} className="h-10 w-10 shrink-0 rounded-lg object-cover" onError={(e) => ((e.target as HTMLImageElement).style.visibility = "hidden")} /> : <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-panel3 text-[10px] font-black text-slate-300">{s.name.slice(0, 2).toUpperCase()}</span>}
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[11px] font-bold text-slate-100">{s.name}</span>
                <span className="text-[8px] uppercase tracking-wider text-slate-500">{s.country || country} · {s.codec} · {s.bitrate} kbps{active && playing ? " · EN VIVO" : ""}</span>
              </span>
              <button onClick={() => toggle(s)} aria-pressed={active && playing} aria-label={active && playing ? `Pausar ${s.name}` : `Escuchar ${s.name}`} className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-all ${active && playing ? "bg-cyanx text-abyss" : "bg-white/10 text-white hover:bg-electric"}`}>
                {active && playing ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" className="ml-0.5" />}
              </button>
            </div>
          );
        })}
      </div>

      {/* tus más escuchadas */}
      {topStations.length >= 1 && (
        <div className="flex flex-wrap items-center gap-1.5" aria-label="Tus emisoras más escuchadas">
          <span className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-600">Tus emisoras:</span>
          {topStations.map(([id, s]) => (
            <button key={id} onClick={() => playByUuid(id)} title={`${s.name} · ${s.count} reproducciones`} className="flex max-w-40 items-center gap-1.5 rounded-full border border-violetx/40 bg-violetx/10 px-2.5 py-1.5 text-[9px] font-bold text-lilac transition-colors hover:bg-violetx/20"><Radio size={11} /><span className="truncate">{s.name}</span><span className="tabular-nums text-slate-500">{s.count}</span></button>
          ))}
        </div>
      )}

      {/* now playing bar */}
      {current && (
        <div className="flex items-center gap-3 rounded-2xl border border-cyanx/30 bg-[#071231] px-4 py-2.5">
          <Radio size={17} className="shrink-0 text-cyanx" />
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-bold text-white">{current.name}</p>
            <p className="text-[8px] font-semibold uppercase tracking-[0.2em] text-cyanx">En directo</p>
          </div>
          <Volume2 size={15} className="shrink-0 text-slate-500" aria-hidden="true" />
          <label htmlFor="radio-volume" className="sr-only">Volumen</label>
          <input id="radio-volume" type="range" min={0} max={1} step={0.01} value={volume} onChange={(e) => setVolume(Number(e.target.value))} className="h-1 w-24 cursor-pointer accent-cyan-400" />
          <button onClick={stop} aria-label="Detener radio" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"><Square size={12} fill="currentColor" /></button>
        </div>
      )}
    </div>
  );
}
