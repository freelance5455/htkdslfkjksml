import { useLocalStorage } from "./useLocalStorage";

/** Avatar circular del perfil: foto personalizada si existe, o inicial con degradado. */
export default function Avatar({ name, hue, size = 32, className = "" }: { name: string; hue: number; size?: number; className?: string }) {
  const [avatar] = useLocalStorage<string | null>("lo3-avatar", null);
  if (avatar) {
    return (
      <img
        src={avatar}
        alt={`Avatar de ${name}`}
        width={size}
        height={size}
        className={`shrink-0 rounded-full object-cover ${className}`}
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <span
      aria-hidden="true"
      className={`flex shrink-0 items-center justify-center rounded-full font-display font-black text-white ${className}`}
      style={{
        width: size,
        height: size,
        fontSize: Math.round(size * 0.36),
        background: `linear-gradient(155deg, hsl(${hue} 70% 55%), hsl(${(hue + 40) % 360} 70% 30%))`,
      }}
    >
      {name[0]?.toUpperCase() ?? "L"}
    </span>
  );
}
