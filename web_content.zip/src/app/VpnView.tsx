import { useCallback, useEffect, useState } from "react";
import {
  CheckCircle2, ChevronRight, Eraser, ExternalLink, Globe2, Loader2, Lock, Network,
  Radar, RefreshCw, Search, ShieldCheck, Wifi, Bug, Server, Globe,
} from "lucide-react";
import { useLocalStorage } from "./useLocalStorage";
import { usePrivacyMax, setPrivacyMax } from "./usePrivacyMax";

type Trace = { ip: string; colo: string; loc: string; tls: string; warp: string; http: string };
type IpInfo = {
  ip: string; country: string; country_code: string; region: string; city: string;
  connection?: { asn?: number; org?: string; isp?: string };
  timezone?: { utc?: string };
};

const RECORD_TYPES = [["A", 1], ["AAAA", 28], ["MX", 15], ["TXT", 16], ["NS", 2], ["CNAME", 5]] as const;

function parseTrace(text: string): Trace {
  const map: Record<string, string> = {};
  for (const line of text.split("\n")) {
    const idx = line.indexOf("=");
    if (idx > 0) map[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
  }
  return {
    ip: map.ip ?? "—",
    colo: map.colo ?? "—",
    loc: map.loc ?? "—",
    tls: map.tls ?? "—",
    warp: map.warp ?? "—",
    http: map.http ?? "—",
  };
}

export default function VpnView() {
  const [doh, setDoh] = useLocalStorage("lo3-doh", true);
  const [killSwitch, setKillSwitch] = useLocalStorage("lo3-killswitch", false);
  const [wipeOnExit, setWipeOnExit] = useLocalStorage("lo3-wipe-on-exit", false);
  const privacyMax = usePrivacyMax();
  const [trace, setTrace] = useState<Trace | null>(null);
  const [ipinfo, setIpinfo] = useState<IpInfo | null>(null);
  const [latency, setLatency] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [traceError, setTraceError] = useState(false);
  const [domain, setDomain] = useState("espn.com");
  const [recordType, setRecordType] = useState<(typeof RECORD_TYPES)[number]>(RECORD_TYPES[0]);
  const [records, setRecords] = useState<{ name: string; type: number; TTL: number; data: string }[] | null>(null);
  const [dnsLoading, setDnsLoading] = useState(false);
  const [dnsError, setDnsError] = useState(false);
  const [dnsHistory, setDnsHistory] = useLocalStorage<string[]>("lo3-dns-history", []);

  const loadConnection = useCallback(async () => {
    setLoading(true);
    setTraceError(false);
    const t0 = performance.now();
    try {
      const res = await fetch("https://1.1.1.1/cdn-cgi/trace", { cache: "no-store" });
      if (!res.ok) throw new Error("trace");
      setTrace(parseTrace(await res.text()));
      setLatency(Math.round(performance.now() - t0));
    } catch {
      setTraceError(true);
    }
    try {
      const res = await fetch("https://ipwho.is/", { cache: "no-store" });
      if (!res.ok) throw new Error("ipwho.is");
      setIpinfo(await res.json());
    } catch {
      /* geolocalización no disponible — IP sigue viniendo del trace */
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadConnection(); }, [loadConnection]);

  const queryDns = useCallback(async (name: string, typeIdx = 0) => {
    if (!doh) return;
    const q = name.trim().toLowerCase().replace(/^https?:\/\//, "").split("/")[0];
    if (!q || !q.includes(".")) { setDnsError(true); setRecords([]); return; }
    setDnsLoading(true);
    setDnsError(false);
    try {
      const [label, type] = RECORD_TYPES[typeIdx];
      void label;
      const res = await fetch(`https://dns.google/resolve?name=${encodeURIComponent(q)}&type=${type}`);
      if (!res.ok) throw new Error("doh");
      const json = await res.json();
      setRecords(json.Answer ?? []);
      setDnsHistory((h) => [q, ...h.filter((x) => x !== q)].slice(0, 5));
    } catch {
      setDnsError(true);
      setRecords([]);
    } finally {
      setDnsLoading(false);
    }
  }, [doh, setDnsHistory]);

  useEffect(() => { if (doh) void queryDns(domain, RECORD_TYPES.indexOf(recordType)); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const activeLayers = [doh, killSwitch, privacyMax, wipeOnExit].filter(Boolean).length;
  const flagUrl = ipinfo?.country_code ? `https://cdn.ipwhois.io/flags/${ipinfo.country_code.toLowerCase()}.svg` : null;

  return (
    <div className="flex h-full flex-col gap-3 overflow-y-auto p-3 thin-scroll sm:p-4">
      {/* ── header ─────────────────────────────────────────── */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="relative flex h-12 w-12 items-center justify-center">
            <span className="absolute inset-0 animate-ping rounded-2xl bg-emerald-400/20" aria-hidden="true" />
            <span className="relative flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-700 shadow-lg shadow-emerald-500/25"><ShieldCheck size={24} className="text-white" /></span>
          </span>
          <div>
            <h1 className="font-display text-lg font-black text-white">TV LO3 <span className="text-emerald-400">Secure</span></h1>
            <p className="text-[10px] uppercase tracking-wider text-slate-500">Privacidad operativa · verificable · sin magia</p>
          </div>
        </div>
        <span className={`chip ${activeLayers >= 3 ? "border-emerald-400/50 text-emerald-300" : activeLayers >= 1 ? "border-amber-400/40 text-amber-300" : "border-rose-400/40 text-rose-300"}`}>
          {activeLayers}/4 capas activas
        </span>
      </div>

      <div className="grid gap-3 pb-2 lg:grid-cols-3">
        {/* ── A · estado ─────────────────────────────────────── */}
        <section className="tile relative overflow-hidden rounded-2xl p-4">
          <Radar size={120} className="absolute -right-4 -top-4 text-emerald-500/10" strokeWidth={1} aria-hidden="true" />
          <h2 className="flex items-center gap-2 font-display text-sm font-bold text-white"><ShieldCheck size={15} className="text-emerald-400" /> Estado del túnel</h2>
          <p className="mt-2 font-display text-2xl font-black text-white">{loading ? "Analizando…" : traceError ? "Sin diagnóstico" : "Conexión directa"}</p>
          <p className="mt-1 text-[10px] leading-snug text-slate-500">{loading ? "Midiendo tu red real…" : traceError ? "No se pudo contactar con 1.1.1.1 ahora mismo." : `TLS ${trace?.tls} · HTTP/${trace?.http?.replace("http/", "") ?? "2"} · WARP ${trace?.warp === "off" ? "desactivado" : "ACTIVO"}`}</p>
          <div className="mt-3 space-y-1 text-[9px] text-slate-500">
            <p className="flex items-center gap-1.5"><CheckCircle2 size={11} className="text-emerald-400" /> Cifrado en tránsito: el servidor y tu navegador negocian TLS 1.3</p>
            <p className="flex items-center gap-1.5"><CheckCircle2 size={11} className="text-emerald-400" /> Cookies de terceros en TV LO3: 0 — jamás las usamos</p>
            <p className="flex items-center gap-1.5"><CheckCircle2 size={11} className="text-emerald-400" /> Tus datos de la bóveda no salen de este dispositivo</p>
            <p className="flex items-center gap-1.5"><Radar size={11} className="text-amber-400" /> Lo que ves arriba es TU red real — TV LO3 no la oculta por sí solo</p>
          </div>
          <button onClick={loadConnection} disabled={loading} className="ghost-btn mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl text-xs font-bold text-white disabled:opacity-60">
            {loading ? <Loader2 size={15} className="animate-spin" /> : <RefreshCw size={15} />} Probar mi conexión de nuevo
          </button>
        </section>

        {/* ── B · tu conexión real (IP/geo en vivo) ─────────── */}
        <section className="tile rounded-2xl p-4 lg:col-span-2">
          <div className="flex items-center justify-between gap-2">
            <h2 className="flex items-center gap-2 font-display text-sm font-bold text-white"><Globe2 size={15} className="text-cyanx" /> Tu conexión real — en vivo</h2>
            {!privacyMax && flagUrl && <img src={flagUrl} alt={`Bandera de ${ipinfo?.country}`} width={28} height={20} className="h-5 w-7 rounded object-cover" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />}
          </div>
          <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2 text-[10px] sm:grid-cols-3">
            {[
              ["IP pública", <span key="ip" className="font-mono text-[11px] text-cyanx">{ipinfo?.ip ?? trace?.ip ?? "…"}</span>],
              ["País", ipinfo ? `${ipinfo.country} (${ipinfo.country_code})` : trace?.loc ?? "—"],
              ["Región", ipinfo?.region ?? "—"],
              ["Ciudad", ipinfo?.city ?? "—"],
              ["ISP / Org", ipinfo?.connection?.org ?? ipinfo?.connection?.isp ?? "—"],
              ["ASN", ipinfo?.connection?.asn ? `AS${ipinfo.connection.asn}` : "—"],
              ["Nodo Cloudflare", trace?.colo ?? "—"],
              ["Zona horaria", ipinfo?.timezone?.utc ?? "—"],
              ["Latencia 1.1.1.1", latency != null ? `${latency} ms` : "—"],
            ].map(([k, v], i) => (
              <div key={i} className="border-b border-white/5 pb-1.5"><p className="text-[8px] uppercase tracking-wider text-slate-600">{k}</p><p className="mt-0.5 truncate font-semibold text-slate-100">{v}</p></div>
            ))}
          </div>
          <p className="mt-2 flex items-center gap-1.5 px-1 text-[9px] text-slate-600"><Wifi size={10} /> Medido en tu navegador ahora mismo — ni TV LO3 ni nadie más lo ve salvo los servicios que consultas.</p>
        </section>

        {/* ── C · DNS cifrado DoH + inspector ───────────────── */}
        <section className="tile rounded-2xl p-4 lg:col-span-2">
          <div className="flex items-center justify-between gap-3">
            <h2 className="flex items-center gap-2 font-display text-sm font-bold text-white"><Network size={15} className="text-lilac" /> DNS cifrado (DoH)</h2>
            <button role="switch" aria-checked={doh} onClick={() => setDoh(!doh)} aria-label="DNS cifrado" className={`relative h-6 w-11 rounded-full transition-colors ${doh ? "bg-electric" : "bg-slate-700"}`}><span className={`absolute top-1 h-4 w-4 rounded-full bg-white shadow transition-all ${doh ? "left-6" : "left-1"}`} /></button>
          </div>
          <p className="mt-1 text-[10px] text-slate-500">Consultas resueltas por <span className="font-mono">dns.google</span> sobre HTTPS — tu ISP no ve los dominios.</p>

          {doh ? (
            <>
              <form onSubmit={(e) => { e.preventDefault(); void queryDns(domain, RECORD_TYPES.indexOf(recordType)); }} className="mt-2 flex flex-wrap items-center gap-1.5">
                <div className="relative min-w-48 flex-1">
                  <Search size={13} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <label htmlFor="doh-domain" className="sr-only">Dominio a inspeccionar</label>
                  <input id="doh-domain" value={domain} onChange={(e) => setDomain(e.target.value)} spellCheck={false} placeholder="dominio.com" className="h-10 w-full rounded-xl border border-white/10 bg-black/30 pl-9 pr-3 font-mono text-xs text-cyan-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-lilac/50" />
                </div>
                <div className="flex gap-1" role="tablist" aria-label="Tipo de registro">
                  {RECORD_TYPES.map(([label, type]) => (
                    <button key={label} role="tab" aria-selected={recordType[0] === label} onClick={() => { setRecordType([label, type] as (typeof RECORD_TYPES)[number]); void queryDns(domain, RECORD_TYPES.findIndex(([l]) => l === label)); }} className={`h-9 rounded-lg px-2 text-[10px] font-black transition-colors ${recordType[0] === label ? "bg-violetx text-white" : "bg-white/5 text-slate-500 hover:text-white"}`}>{label}</button>
                  ))}
                </div>
              </form>
              <div className="mt-2 min-h-28 rounded-xl border border-white/8 bg-black/30 p-2 font-mono text-[10px]">
                {dnsLoading ? <p className="flex items-center gap-2 p-2 text-slate-500"><Loader2 size={13} className="animate-spin" />Resolviendo…</p>
                  : dnsError ? <p className="p-2 text-rose-400">Dominio inválido o DNS no disponible. Prueba con algo como «espn.com».</p>
                  : records && records.length > 0 ? records.map((r, i) => (
                      <p key={i} className="flex items-baseline gap-2 border-b border-white/5 px-1 py-1.5 last:border-0"><span className="w-8 shrink-0 text-[8px] font-black text-lilac">TTL {r.TTL}</span><span className="min-w-0 break-all text-cyan-100">{r.data}</span></p>
                    ))
                  : records ? <p className="p-2 text-slate-500">Sin registros {recordType[0]} públicos para ese dominio.</p> : <p className="p-2 text-slate-600">Escribe un dominio y pulsa Enter.</p>}
              </div>
              {dnsHistory.length > 0 && (
                <p className="mt-2 flex flex-wrap items-center gap-1 text-[9px] text-slate-600"><span className="font-bold">Historial:</span>{dnsHistory.map((h) => <button key={h} onClick={() => { setDomain(h); void queryDns(h, RECORD_TYPES.indexOf(recordType)); }} className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-slate-400 hover:text-cyanx">{h}</button>)}</p>
              )}
            </>
          ) : (
            <div className="mt-2 flex flex-col items-center gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-6 text-center">
              <Lock size={26} className="text-slate-600" />
              <p className="text-xs font-bold text-slate-300">Inspector bloqueado</p>
              <p className="max-w-xs text-[10px] text-slate-500">Activa DNS cifrado arriba para inspeccionar cualquier dominio con DoH. Mientras, tus consultas DNS viajan sin protección.</p>
            </div>
          )}
        </section>

        {/* ── D · capas de protección (toggles reales) ─────── */}
        <section className="tile rounded-2xl p-4">
          <h2 className="flex items-center gap-2 font-display text-sm font-bold text-white"><Bug size={15} className="text-emerald-300" /> Capas activas</h2>
          <div className="mt-2 space-y-2">
            {[
              { label: "Kill Switch", hint: "Todo enlace externo pide confirmación — nada sale sin tu OK", on: killSwitch, toggle: () => setKillSwitch(!killSwitch) },
              { label: "Privacidad máxima", hint: "Cero imágenes externas: logos, pósters, portadas, banderas", on: privacyMax, toggle: () => setPrivacyMax(!privacyMax) },
              { label: "Borrar historial al cerrar", hint: "Continuar viendo y favoritos se limpian al salir de la app", on: wipeOnExit, toggle: () => setWipeOnExit(!wipeOnExit) },
              { label: "DNS cifrado (DoH)", hint: "El inspector y tus consultas nunca viajan en claro", on: doh, toggle: () => setDoh(!doh) },
            ].map((r) => (
              <button key={r.label} role="switch" aria-checked={r.on} onClick={r.toggle} className="flex w-full items-center justify-between gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-2.5 text-left transition-colors hover:border-white/15">
                <span>
                  <span className="block text-[11px] font-bold text-slate-100">{r.label}</span>
                  <span className="mt-0.5 block text-[9px] leading-snug text-slate-500">{r.hint}</span>
                </span>
                <span className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${r.on ? "bg-emerald-500" : "bg-slate-700"}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${r.on ? "left-4.5" : "left-0.5"}`} style={{ left: r.on ? "18px" : "2px" }} /></span>
              </button>
            ))}
          </div>
        </section>

        {/* ── E · VPN para todo Android (honesto) ───────────── */}
        <section className="rounded-2xl border border-emerald-400/25 bg-gradient-to-br from-emerald-500/10 to-teal-900/10 p-4 lg:col-span-2">
          <h2 className="flex items-center gap-2 font-display text-sm font-bold text-white"><Server size={15} className="text-emerald-300" /> VPN para todo el teléfono</h2>
          <p className="mt-1.5 text-[11px] leading-snug text-emerald-100/80">
            Ninguna página web puede crear un túnel WireGuard a nivel de sistema: eso exige una app del sistema. Para encapsular <strong>todo Android</strong> (no solo TV LO3), instala el cliente oficial gratuito que prefieras:
          </p>
          <div className="mt-2 grid gap-2 sm:grid-cols-3">
            {[
              { name: "Proton VPN Free", desc: "Sin límite de datos · sin anuncios · política auditada", url: "https://protonvpn.com/es/free" },
              { name: "Windscribe Free", desc: "10 GB/mes gratis · 10+ países · sin registro de actividad", url: "https://windscribe.com/download" },
              { name: "Cloudflare WARP", desc: "1.1.1.1 — rápido, sin cuenta, protege DNS y tráfico", url: "https://1.1.1.1/" },
            ].map((p) => (
              <a key={p.name} href={p.url} target="_blank" rel="noopener noreferrer" className="group rounded-xl border border-white/10 bg-black/30 p-3 transition-colors hover:border-emerald-400/40">
                <span className="flex items-center justify-between gap-1 text-[11px] font-black text-white">{p.name}<ExternalLink size={11} className="text-slate-500 transition-colors group-hover:text-emerald-400" /></span>
                <span className="mt-1 block text-[9px] leading-snug text-slate-400">{p.desc}</span>
                <span className="mt-1.5 block text-[8px] font-black uppercase tracking-widest text-emerald-500">Sitio oficial →</span>
              </a>
            ))}
          </div>
          <p className="mt-2 flex items-center gap-1.5 text-[9px] text-emerald-200/60"><Globe size={10} /> Tras instalar: Ajustes del móvil → VPN → activa el interruptor. Verás una llave en la barra de estado cuando esté activo.</p>
        </section>

        {/* ── F · informe de fugas ─────────────────────────────── */}
        <section className="tile rounded-2xl p-4">
          <h2 className="flex items-center gap-2 font-display text-sm font-bold text-white"><Radar size={15} className="text-amber-300" /> Informe de fugas</h2>
          <ul className="mt-2 space-y-1.5 text-[10px]">
            {[
              ["Cookies de terceros", "0 activas", true],
              ["Trackers / píxeles", "ninguno embebido", true],
              ["Historial en nuestros servidores", "no existe servidor", true],
              ["Imágenes externas cargando hoy", privacyMax ? "bloqueadas" : "permitidas", privacyMax],
              ["Kill Switch en enlaces", killSwitch ? "activo" : "inactivo", killSwitch],
              ["Salida automática de enlaces", wipeOnExit ? "se borra al cerrar" : "se conserva", wipeOnExit],
            ].map(([k, v, ok], i) => (
              <li key={i} className="flex items-center justify-between gap-2 border-b border-white/5 pb-1.5">
                <span className="text-slate-400">{k}</span>
                <span className={`flex items-center gap-1 font-bold ${ok ? "text-emerald-400" : "text-amber-400"}`}>{ok ? <CheckCircle2 size={11} /> : <Radar size={11} />}{v as string}</span>
              </li>
            ))}
          </ul>
          <button onClick={() => { window.localStorage.removeItem("lo3-dns-history"); window.alert("Historial DNS del inspector borrado."); }} className="mt-2 flex h-9 w-full items-center justify-center gap-1.5 rounded-lg border border-white/10 text-[10px] font-bold text-slate-400 transition-colors hover:text-white"><Eraser size={12} /> Borrar historial DNS<ChevronRight size={11} /></button>
        </section>
      </div>
      <p className="flex items-center gap-2 px-1 pb-1 text-[9px] leading-snug text-slate-600"><Lock size={10} className="shrink-0" /> TV LO3 Secure protege lo que ocurre dentro de la app. El enmascaramiento total del tráfico (toda la IP, todo el tráfico) lo hace únicamente un VPN del sistema — te mostramos los oficiales arriba, sin afiliación ni comisión.</p>
    </div>
  );
}
