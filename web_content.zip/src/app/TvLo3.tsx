import { useEffect, useMemo, useRef, useState } from "react";
import {
  Baby, ChevronRight, Clapperboard, Cloud, Gamepad2, Globe2, Home, Info, Maximize2, MonitorPlay,
  Heart, Music2, Newspaper, Popcorn, Radio, Search, Settings, ShoppingBag, Sparkles, Trophy, X, ShieldCheck,
} from "lucide-react";
import { useNow } from "../lib/hooks";
import { useLocalStorage } from "./useLocalStorage";
import HomeView from "./HomeView";
import WorldTvView from "./WorldTvView";
import SportsView from "./SportsView";
import { MoviesView, SeriesView } from "./MediaCatalog";
import GamesView from "./GamesView";
import { MusicView, RadioView } from "./MusicRadio";
import NewsView from "./NewsView";
import StoreView from "./StoreView";
import CloudView from "./CloudView";
import KidsView from "./KidsView";
import AiView from "./AiView";
import SettingsView from "./SettingsView";
import VpnView from "./VpnView";
import CollectionView from "./CollectionView";
import FreeCinemaView from "./FreeCinemaView";
import KillSwitch from "./KillSwitch";
import { MOVIES, SERIES } from "./catalog";
import { searchArchive, type ArchiveDoc } from "./archive";
import { wikipediaOpenSearch, type WikiHit } from "./api";
import Avatar from "./Avatar";
import Screensaver from "./Screensaver";
import { InstallPill } from "./InstallApp";

export interface Profile { name: string; hue: number; kid?: boolean }
const PRESET_PROFILES: Profile[] = [
  { name: "Leo", hue: 210 },
  { name: "Ana", hue: 272 },
  { name: "Carlos", hue: 152 },
  { name: "Familia", hue: 24 },
  { name: "Kids", hue: 160, kid: true },
];

const NAV = [
  { id: "inicio", label: "Inicio", icon: Home },
  { id: "worldtv", label: "World TV", icon: Globe2 },
  { id: "sports", label: "Sports Center", icon: Trophy },
  { id: "movies", label: "Movies", icon: Clapperboard },
  { id: "series", label: "Series", icon: MonitorPlay },
  { id: "gratis", label: "Gratis", icon: Popcorn },
  { id: "games", label: "Games Hub", icon: Gamepad2 },
  { id: "music", label: "Music", icon: Music2 },
  { id: "radio", label: "Radio", icon: Radio },
  { id: "news", label: "News", icon: Newspaper },
  { id: "vpn", label: "VPN Secure", icon: ShieldCheck },
  { id: "store", label: "Store", icon: ShoppingBag },
  { id: "coleccion", label: "Colección", icon: Heart },
  { id: "cloud", label: "Cloud", icon: Cloud },
  { id: "kids", label: "Kids", icon: Baby },
  { id: "ai", label: "TV LO3 AI", icon: Sparkles },
  { id: "settings", label: "Ajustes", icon: Settings },
] as const;
type Route = (typeof NAV)[number]["id"];
const KID_LOCKED: Route[] = ["store", "settings", "ai", "news", "cloud", "sports", "worldtv", "vpn"];

function SearchSection({ label }: { label: string }) {
  return <p className="px-2 pb-0.5 pt-1.5 text-[8px] font-black uppercase tracking-[0.22em] text-slate-500 first:pt-1">{label}</p>;
}

function Mark({ size = 34 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="tv3-m" x1="8" y1="8" x2="56" y2="56" gradientUnits="userSpaceOnUse">
          <stop stopColor="#22d3ee" /><stop offset="0.5" stopColor="#2f7bff" /><stop offset="1" stopColor="#a855f7" />
        </linearGradient>
      </defs>
      <path d="M32 5 55 18.5v27L32 59 9 45.5v-27L32 5Z" stroke="url(#tv3-m)" strokeWidth="5" strokeLinejoin="round" />
      <path d="M27.5 24.6v14.8c0 1.9 2.1 3.1 3.8 2.1l12.2-7.4a2.5 2.5 0 0 0 0-4.2l-12.2-7.4c-1.7-1-3.8.2-3.8 2.1Z" fill="url(#tv3-m)" />
    </svg>
  );
}

function Splash({ onDone }: { onDone: () => void }) {
  useEffect(() => { const id = window.setTimeout(onDone, 1500); return () => window.clearTimeout(id); }, [onDone]);
  return (
    <div className="fixed inset-0 z-40 flex flex-col items-center justify-center gap-6 bg-abyss" role="status" aria-label="Cargando TV LO3">
      <div className="animate-floaty"><Mark size={88} /></div>
      <div className="text-center">
        <p className="font-display text-4xl font-black tracking-tight text-white">TV <span className="text-cyanx">LO3</span></p>
        <p className="mt-1 text-[10px] font-medium uppercase tracking-[0.35em] text-slate-500">Tu mundo en un solo lugar</p>
      </div>
      <div className="h-1 w-48 overflow-hidden rounded-full bg-white/10"><div className="animate-splash-bar h-full w-full bg-gradient-to-r from-cyanx via-electric to-violetx" /></div>
    </div>
  );
}

function ProfileGate({ onPick }: { onPick: (p: Profile) => void }) {
  const [name, setName] = useState("");
  const [hue, setHue] = useState(315);
  const hues = [210, 272, 152, 24, 315, 0, 190, 55];
  return (
    <div className="fixed inset-0 z-30 flex flex-col items-center justify-center overflow-hidden bg-abyss px-4">
      <img src="/img/hero-art.jpg" alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover opacity-35" />
      <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-b from-[#04061a]/60 via-transparent to-[#04061a]" />
      <div className="relative flex w-full max-w-2xl flex-col items-center gap-6">
        <div className="flex items-center gap-3"><Mark size={44} /><p className="font-display text-2xl font-black text-white">TV <span className="text-cyanx">LO3</span></p></div>
        <h1 className="text-center font-display text-3xl font-bold text-white sm:text-4xl">¿Quién está viendo?</h1>
        <div className="flex flex-wrap items-start justify-center gap-4">
          {PRESET_PROFILES.map((p) => (
            <button key={p.name} onClick={() => onPick(p)} className="group flex w-20 flex-col items-center gap-2" aria-label={`Entrar como ${p.name}`}>
              <span className="flex h-16 w-16 items-center justify-center rounded-2xl font-display text-2xl font-black text-white shadow-lg ring-2 ring-transparent transition-all group-hover:scale-110 group-hover:ring-cyanx" style={{ background: `linear-gradient(155deg, hsl(${p.hue} 70% 55%), hsl(${(p.hue + 40) % 360} 70% 30%))` }}>
                {p.name[0]}
              </span>
              <span className="text-xs font-bold text-slate-200">{p.kid ? "Kids" : p.name}</span>
              {p.kid && <span className="-mt-1 text-[8px] font-bold uppercase tracking-widest text-emerald-400">PIN</span>}
            </button>
          ))}
        </div>
        {/* custom profile */}
        <form className="flex w-full max-w-md flex-col items-center gap-2" onSubmit={(e) => { e.preventDefault(); const n = name.trim(); if (n) onPick({ name: n.slice(0, 14), hue }); }}>
          <label htmlFor="new-profile" className="text-[10px] font-bold uppercase tracking-[0.25em] text-slate-500">O crea el tuyo</label>
          <div className="flex w-full gap-2">
            <input id="new-profile" value={name} onChange={(e) => setName(e.target.value)} maxLength={14} placeholder="Nombre del perfil…" className="h-12 flex-1 rounded-xl border border-white/12 bg-black/50 px-4 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-cyanx/60" />
            <button type="submit" className="grad-btn h-12 rounded-xl px-4 text-sm font-bold text-white">Crear</button>
          </div>
          <div className="flex gap-1.5">{hues.map((h) => <button key={h} type="button" onClick={() => setHue(h)} aria-label={`Color ${h}`} aria-pressed={hue === h} className={`h-6 w-6 rounded-full ring-2 transition-transform hover:scale-125 ${hue === h ? "ring-white" : "ring-transparent"}`} style={{ background: `linear-gradient(155deg, hsl(${h} 70% 55%), hsl(${(h + 40) % 360} 70% 30%))` }} />)}</div>
        </form>
        <p className="text-center text-[9px] uppercase tracking-[0.3em] text-slate-600">Perfil Kids activa filtros parentales automáticamente</p>
      </div>
    </div>
  );
}

export default function TvLo3({ onOpenInfo }: { onOpenInfo: () => void }) {
  const [booted, setBooted] = useState(() => sessionStorage.getItem("lo3-booted") === "1");
  const [profile, setProfile] = useLocalStorage<Profile | null>("lo3-profile", null);
  const [route, setRoute] = useState<Route>("inicio");
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [gratisHits, setGratisHits] = useState<ArchiveDoc[] | null>(null);
  const [gratisTotal, setGratisTotal] = useState(0);
  const [wikiHits, setWikiHits] = useState<WikiHit[]>([]);
  const [searching, setSearching] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const now = useNow(20000);

  useEffect(() => {
    try {
      if (window.localStorage.getItem("lo3-hc") === "true") document.documentElement.classList.add("hc");
      if (window.localStorage.getItem("lo3-rm") === "true") document.documentElement.classList.add("rm");
      if (window.localStorage.getItem("lo3-no-rotate") === "true") document.documentElement.classList.add("no-rotate");
      if (window.localStorage.getItem("lo3-night-mode") === "true") document.documentElement.classList.add("night-mode");
      const ts = window.localStorage.getItem("lo3-text-size");
      if (ts === "lg") document.documentElement.classList.add("txt-lg");
      else if (ts === "xl") document.documentElement.classList.add("txt-xl");
    } catch { /* noop */ }
  }, []);

  useEffect(() => {
    const order = ["inicio", "worldtv", "sports", "movies", "series", "games", "music", "radio", "news"] as const;
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); searchRef.current?.focus(); }
      if (e.key === "Escape" && document.activeElement === searchRef.current) { setQuery(""); searchRef.current?.blur(); }
      if ((e.metaKey || e.ctrlKey) && /^[1-9]$/.test(e.key)) {
        const idx = Number(e.key) - 1;
        const target = order[idx];
        if (target) { e.preventDefault(); setRoute(target as Route); }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => { if (profile?.kid) setRoute("kids"); }, [profile?.kid]);

  const catalogHits = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return { movies: [] as typeof MOVIES, series: [] as typeof SERIES };
    return {
      movies: MOVIES.filter((m) => m.title.toLowerCase().includes(q)).slice(0, 3),
      series: SERIES.filter((s) => s.name.toLowerCase().includes(q)).slice(0, 3),
    };
  }, [query]);

  useEffect(() => {
    const q = query.trim();
    if (q.length < 3) { setGratisHits(null); setWikiHits([]); setSearching(false); return; }
    setSearching(true);
    const id = window.setTimeout(() => {
      searchArchive("movies", q, 1).then((r) => { setGratisHits(r.docs.slice(0, 4)); setGratisTotal(r.numFound); }).catch(() => setGratisHits([]));
      wikipediaOpenSearch(q, 4).then(setWikiHits).catch(() => setWikiHits([]));
      setSearching(false);
    }, 350);
    return () => window.clearTimeout(id);
  }, [query]);

  if (!booted) return <Splash onDone={() => { try { sessionStorage.setItem("lo3-booted", "1"); } catch { /* noop */ } setBooted(true); }} />;
  if (!profile) return <ProfileGate onPick={(p) => { setProfile(p); setRoute(p.kid ? "kids" : "inicio"); }} />;

  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const date = now.toLocaleDateString("es-ES", { weekday: "short", day: "numeric", month: "short" });
  const routeLabel = NAV.find((n) => n.id === route)?.label ?? "Inicio";
  const kidBlocked = profile.kid && KID_LOCKED.includes(route);

  const fullscreen = () => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen().catch(() => {});
  };

  const renderView = () => {
    if (kidBlocked) {
      return (
        <div className="flex h-full flex-col items-center justify-center gap-4 p-6 text-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-2xl border border-emerald-400/40 bg-emerald-400/10 text-3xl"><Baby size={32} className="text-emerald-400" /></span>
          <h2 className="font-display text-2xl font-bold text-white">Zona de mayores</h2>
          <p className="max-w-sm text-sm text-slate-400">El perfil Kids no puede abrir <strong className="text-slate-200">{routeLabel}</strong>. Pide a un adulto que cambie de perfil.</p>
          <button onClick={() => setProfile(null)} className="grad-btn h-12 rounded-xl px-6 text-sm font-bold text-white">Cambiar a perfil de adulto</button>
        </div>
      );
    }
    switch (route) {
      case "inicio": return <HomeView profile={profile} onNavigate={(r) => setRoute(r as Route)} />;
      case "worldtv": return <WorldTvView />;
      case "sports": return <SportsView />;
      case "movies": return <MoviesView query={query} onClearQuery={() => setQuery("")} />;
      case "series": return <SeriesView query={query} onClearQuery={() => setQuery("")} />;
      case "gratis": return <FreeCinemaView seed={query} />;
      case "games": return <GamesView onNavigate={(r) => setRoute(r as Route)} />;
      case "music": return <MusicView />;
      case "radio": return <RadioView />;
      case "news": return <NewsView />;
      case "store": return <StoreView />;
      case "coleccion": return <CollectionView onNavigate={(r) => setRoute(r as Route)} />;
      case "cloud": return <CloudView />;
      case "kids": return <KidsView onNavigate={(r) => setRoute(r as Route)} />;
      case "vpn": return <VpnView />;
      case "ai": return <AiView />;
      case "settings": return <SettingsView onOpenInfo={onOpenInfo} onChangeProfile={() => setProfile(null)} />;
      default: return <HomeView profile={profile} onNavigate={(r) => setRoute(r as Route)} />;
    }
  };

  return (
    <div className="fixed inset-0 overflow-hidden bg-abyss font-sans text-slate-100">
      <KillSwitch />
      <Screensaver profileName={profile?.name ?? "Invitado"} />
      <InstallPill />
      <div className="tvlo3-stage flex h-full w-full">
        {/* ── sidebar ─────────────────────────────────────────── */}
        <nav className="flex w-14 shrink-0 flex-col items-center border-r border-white/5 bg-[#070d2c] py-3 sm:w-16 lg:w-52 lg:items-stretch lg:px-2.5" aria-label="Menú TV LO3">
          <div className="mb-3 flex items-center justify-center gap-2 lg:justify-start lg:px-1.5">
            <Mark size={30} />
            <span className="hidden font-display text-lg font-black text-white lg:block">TV <span className="text-cyanx">LO3</span></span>
          </div>
          <ul className="flex min-h-0 flex-1 flex-col gap-0.5 overflow-y-auto thin-scroll lg:pr-1">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = route === item.id;
              const locked = profile.kid && KID_LOCKED.includes(item.id);
              return (
                <li key={item.id}>
                  <button onClick={() => setRoute(item.id)} aria-current={active ? "page" : undefined} aria-label={item.label} title={item.label} className={`flex w-full items-center justify-center gap-2 rounded-xl px-2 py-2 transition-all lg:justify-start ${active ? "bg-gradient-to-r from-electric to-violetx font-bold text-white shadow-lg shadow-blue-700/30" : "text-slate-400 hover:bg-white/5 hover:text-white"}`}>
                    <Icon size={17} strokeWidth={2} className="shrink-0" />
                    <span className="hidden text-[11px] lg:block">{item.label}</span>
                    {locked && <span className="ml-auto hidden lg:block" aria-hidden="true"><span className="text-[9px] font-black text-emerald-500">PIN</span></span>}
                  </button>
                </li>
              );
            })}
          </ul>
          <div className="mt-2 flex flex-col items-center gap-1 border-t border-white/5 pt-2 lg:items-stretch">
            <button onClick={fullscreen} aria-label="Pantalla completa" title="Pantalla completa" className="flex w-full items-center justify-center gap-2 rounded-xl px-2 py-2 text-slate-500 transition-colors hover:bg-white/5 hover:text-white lg:justify-start"><Maximize2 size={16} /><span className="hidden text-[10px] lg:block">Pantalla completa</span></button>
            <button onClick={onOpenInfo} aria-label="Sobre TV LO3" title="Sobre TV LO3" className="flex w-full items-center justify-center gap-2 rounded-xl px-2 py-2 text-slate-500 transition-colors hover:bg-white/5 hover:text-white lg:justify-start"><Info size={16} /><span className="hidden text-[10px] lg:block">Sobre TV LO3</span></button>
            <button onClick={() => setProfile(null)} aria-label="Cambiar de perfil" title="Cambiar de perfil" className="flex w-full items-center justify-center gap-2 rounded-xl px-2 py-2 transition-colors hover:bg-white/5 lg:justify-start">
              <Avatar name={profile.name} hue={profile.hue} size={28} className="rounded-lg" />
              <span className="hidden truncate text-[10px] font-bold text-slate-300 lg:block">{profile.name}</span>
            </button>
          </div>
        </nav>

        {/* ── right column ────────────────────────────────────── */}
        <div className="flex min-w-0 flex-1 flex-col bg-[#060b24]">
          {/* top bar */}
          <header className="flex h-12 shrink-0 items-center gap-2 border-b border-white/5 bg-[#070d2c]/70 px-3 backdrop-blur sm:h-14 sm:gap-4 sm:px-4">
            <p className="hidden items-center gap-1 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500 md:flex">TV LO3 <ChevronRight size={11} /> <span className="text-cyanx">{routeLabel}</span></p>
            {/* search + universal dropdown */}
            <div className="relative min-w-0 flex-1 sm:max-w-md">
              {searchOpen && <button aria-label="Cerrar buscador" onClick={() => setSearchOpen(false)} className="fixed inset-0 z-20 cursor-default bg-transparent" />}
              <Search size={14} className="pointer-events-none absolute left-3 top-1/2 z-10 -translate-y-1/2 text-slate-500" />
              <label htmlFor="lo3-search" className="sr-only">Buscar en toda la app</label>
              <input
                ref={searchRef} id="lo3-search" value={query}
                onChange={(e) => { setQuery(e.target.value); setSearchOpen(true); }}
                onFocus={() => setSearchOpen(true)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); setRoute("movies"); setSearchOpen(false); searchRef.current?.blur(); } }}
                placeholder="Buscar películas, series, gratis, Wikipedia…  (Ctrl K)"
                autoComplete="off" spellCheck={false}
                className="h-9 w-full rounded-full border border-white/10 bg-black/30 pl-9 pr-8 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-electric/60 sm:h-10"
              />
              {query && <button onClick={() => { setQuery(""); searchRef.current?.focus(); }} aria-label="Borrar búsqueda" className="absolute right-2 top-1/2 z-10 -translate-y-1/2 rounded-full p-1 text-slate-500 hover:text-white"><X size={14} /></button>}
              {searchOpen && query.trim().length >= 2 && (
                <div role="dialog" aria-label="Resultados de búsqueda" className="absolute left-0 right-0 top-full z-30 mt-2 max-h-[70vh] overflow-y-auto rounded-2xl border border-cyanx/20 bg-[#0a102b]/95 p-2 shadow-2xl shadow-black/60 backdrop-blur-xl thin-scroll">
                  {catalogHits.movies.length > 0 && <SearchSection label="Movies" />}
                  {catalogHits.movies.map((m) => (
                    <button key={m.qid} onClick={() => { setRoute("movies"); setSearchOpen(false); }} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[11px] text-slate-200 transition-colors hover:bg-electric/20"><Clapperboard size={13} className="shrink-0 text-cyanx" /><span className="truncate">{m.title}</span><span className="ml-auto shrink-0 text-[9px] text-slate-500">{m.year}</span></button>
                  ))}
                  {catalogHits.series.length > 0 && <SearchSection label="Series" />}
                  {catalogHits.series.map((s) => (
                    <button key={s.id} onClick={() => { setRoute("series"); setSearchOpen(false); }} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[11px] text-slate-200 transition-colors hover:bg-violetx/20"><MonitorPlay size={13} className="shrink-0 text-lilac" /><span className="truncate">{s.name}</span><span className="ml-auto shrink-0 text-[9px] text-slate-500">{s.year}</span></button>
                  ))}
                  {gratisHits && gratisHits.length > 0 && <SearchSection label={`Gratis · ${gratisTotal.toLocaleString("es-ES")} títulos`} />}
                  {gratisHits?.map((d) => (
                    <button key={d.identifier} onClick={() => { setRoute("gratis"); setSearchOpen(false); }} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[11px] text-slate-200 transition-colors hover:bg-amber-500/15"><Popcorn size={13} className="shrink-0 text-amber-400" /><span className="truncate">{d.title}</span><span className="ml-auto shrink-0 text-[9px] text-slate-500">{d.year}</span></button>
                  ))}
                  {wikiHits.length > 0 && <SearchSection label="Wikipedia" />}
                  {wikiHits.map((w) => (
                    <a key={w.url} href={w.url} target="_blank" rel="noopener noreferrer" className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[11px] text-slate-200 transition-colors hover:bg-emerald-500/15"><Globe2 size={13} className="shrink-0 text-emerald-400" /><span className="min-w-0"><span className="block truncate">{w.title}</span>{w.description && <span className="block truncate text-[9px] text-slate-500">{w.description}</span>}</span></a>
                  ))}
                  {searching && <p className="px-3 py-2 text-[10px] text-slate-500">Buscando en Gratis y Wikipedia…</p>}
                  {!searching && query.trim().length >= 2 && catalogHits.movies.length === 0 && catalogHits.series.length === 0 && (!gratisHits || gratisHits.length === 0) && wikiHits.length === 0 && (
                    <p className="px-3 py-3 text-center text-[10px] text-slate-500">Nada por aquí. Pulsa Enter para buscar en Movies.</p>
                  )}
                  <p className="border-t border-white/5 px-3 py-1.5 text-[8px] font-semibold uppercase tracking-wider text-slate-600">Enter → Movies · Esc cierra</p>
                </div>
              )}
            </div>
            <span className="chip hidden border-cyanx/30 text-cyanx lg:inline-flex">16:9</span>
            <div className="ml-auto flex items-center gap-2 text-right">
              <div className="leading-none">
                <p className="font-display text-sm font-bold tabular-nums text-white sm:text-base">{hh}:{mm}</p>
                <p className="text-[8px] capitalize text-slate-500 sm:text-[9px]">{date}</p>
              </div>
              <Avatar name={profile.name} hue={profile.hue} size={32} className="border border-white/10" />
            </div>
          </header>

          {/* view */}
          <main className="min-h-0 flex-1 overflow-hidden">{renderView()}</main>
        </div>
      </div>
    </div>
  );
}
