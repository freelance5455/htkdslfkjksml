"use client";

import dynamic from "next/dynamic";
import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Flame, Skull, TriangleAlert, ChevronRight, RotateCcw } from "lucide-react";
import { Nav, PillarBar } from "@/components/Shell";
import Onboard from "@/components/Onboard";
import { useMindStore, useHydrateMind, type MindState } from "@/lib/store";
import { DOMAINS } from "@/lib/types";
import { ringTrialCount, ringPassThreshold } from "@/lib/scoring";
import { sfx } from "@/lib/sound";

const MindScene = dynamic(() => import("@/components/MindScene"), { ssr: false });

interface Trial {
  id: string;
  s: string;
  domain: string;
  kind: string;
  difficulty: number;
  prompt: string;
  options: string[];
  timeLimit: number;
  isBoss: boolean;
}

interface Verdict {
  correct: boolean;
  answerIndex: number;
  explanation: string;
  xp: number;
  deltaPillars: { c: number; i: number; p: number };
  isBoss: boolean;
  mind: MindState & { title: { title: string }; nextTitle?: { title: string; min: number } | null };
}

const ease = [0.22, 1, 0.36, 1] as const;

export default function DescentPage() {
  useHydrateMind();
  const hydrated = useMindStore((s) => s.hydrated);
  const mind = useMindStore((s) => s.mind);
  const patchMind = useMindStore((s) => s.patchMind);

  const [phase, setPhase] = useState<"idle" | "playing" | "verdict" | "ringEnd">("idle");
  const [ring, setRing] = useState(1);
  const [domain, setDomain] = useState<string>("mixed");
  const [trials, setTrials] = useState<Trial[]>([]);
  const [ti, setTi] = useState(0);
  const [verdict, setVerdict] = useState<Verdict | null>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const [solved, setSolved] = useState(0);
  const [passed, setPassed] = useState(false);
  const trialStart = useRef(0);

  // Initialize ring once when a mind appears — later mind updates (XP, streaks,
  // bestRing patches) must never stomp in-progress ring state.
  const ringInit = useRef(false);
  useEffect(() => {
    if (mind && !ringInit.current) {
      ringInit.current = true;
      setRing(mind.bestRing + 1);
    }
  }, [mind]);

  const startRing = useCallback(async (m: MindState, r: number, d: string) => {
    const target = d === "mixed" ? "" : `&domain=${d}`;
    const count = ringTrialCount(r);
    const res = await fetch(`/api/trials?mindId=${m.id}&ring=${r}&count=${count}${target}`);
    const data = await res.json();
    if (!data.trials?.length) return;
    setTrials(data.trials);
    setTi(0);
    setSolved(0);
    setVerdict(null);
    setPicked(null);
    trialStart.current = Date.now();
    setPhase("playing");
  }, []);

  const begin = useCallback(async () => {
    if (!mind) return;
    sfx.click();
    await startRing(mind, ring, domain);
  }, [mind, ring, domain, startRing]);

  /* One-click onboarding → the first ring starts itself. No intermediate screens. */
  const onRegistered = useCallback((m: MindState) => {
    const r = (m.bestRing || 0) + 1;
    ringInit.current = true;
    setRing(r);
    void startRing(m, r, "mixed");
  }, [startRing]);

  const answer = useCallback(async (choiceIndex: number, timedOut = false) => {
    if (!mind || phase !== "playing") return;
    const t = trials[ti];
    const elapsedMs = Date.now() - trialStart.current;
    try {
      const res = await fetch("/api/attempt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mindId: mind.id, questionId: t.id, choiceIndex, elapsedMs, s: t.s }),
      });
      const v: Verdict = await res.json();
      setVerdict(v);
      setPicked(choiceIndex);
      if (v.correct) { sfx.correct(); setSolved((s) => s + 1); } else sfx.wrong();
      patchMind({
        creativity: v.mind.creativity,
        imagination: v.mind.imagination,
        pattern: v.mind.pattern,
        mindIndex: v.mind.mindIndex,
        streak: v.mind.streak,
        bestStreak: v.mind.bestStreak,
        title: v.mind.title.title,
      });
      if (timedOut || choiceIndex === -1) setVerdict({ ...v, correct: false });
      setPhase("verdict");
    } catch {
      /* network hiccup — stay */
    }
  }, [mind, phase, trials, ti, patchMind]);

  const nextTrial = useCallback(async () => {
    if (ti + 1 >= trials.length) {
      const target = solved >= ringPassThreshold(ring);
      setPassed(target);
      if (target && mind) {
        sfx.ascend();
        await fetch("/api/minds", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: mind.id, completedRing: ring }),
        });
        patchMind({ bestRing: ring });
      }
      setPhase("ringEnd");
    } else {
      setTi((v) => v + 1);
      setVerdict(null);
      setPicked(null);
      trialStart.current = Date.now();
      setPhase("playing");
    }
  }, [ti, trials.length, mind, ring, patchMind, solved]);

  if (!hydrated) return <Boot />;
  if (!mind) {
    return (
      <GateMode>
        <Onboard onDone={onRegistered} />
      </GateMode>
    );
  }

  return (
    <GateMode>
      <div className="relative z-10 mx-auto min-h-screen max-w-5xl px-5 pb-24 pt-24">
        {/* HUD */}
        <div className="panel mb-8 grid gap-4 p-4 md:grid-cols-[1fr_auto]">
          <div className="grid gap-2">
            <PillarBar label="LATERAL CREATION" value={mind.creativity} glyph="◬" color="#e9c46a" />
            <PillarBar label="IMAGINATIVE PHYSICS" value={mind.imagination} glyph="◍" color="#8b7cff" />
            <PillarBar label="PATTERN & KNOWLEDGE" value={mind.pattern} glyph="◈" color="#3ddc97" />
          </div>
          <div className="flex items-center gap-6 border-l hairline pl-6 font-mono text-[10px] tracking-[0.2em] text-ash md:flex-col md:items-end md:justify-center">
            <div className="flex items-center gap-2"><span>MIND INDEX</span><span className="text-2xl text-violet-x text-glow-violet">{mind.mindIndex}</span></div>
            <div className="flex items-center gap-2"><Flame className="h-3 w-3 text-blood" /><span>STREAK {mind.streak}</span></div>
            <div className="text-amber-x">{mind.title.toString().toUpperCase()}</div>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {phase === "idle" && (
            <motion.div key="idle" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.6, ease }}>
              <div className="panel panel-hot p-8 md:p-12">
                <div className="flex flex-wrap items-end justify-between gap-6">
                  <div>
                    <p className="font-mono text-[10px] tracking-[0.4em] text-violet-x">DESCENT PROTOCOL</p>
                    <h2 className="mt-3 font-display text-5xl md:text-6xl">
                      Ring <span className="text-violet-x">{ring}</span>
                    </h2>
                    <p className="mt-3 max-w-md text-sm leading-relaxed text-ash">
                      {ringTrialCount(ring)} trials will fire. Pass {ringPassThreshold(ring)} of them to ascend.
                      Every failure is archived; every explanation is a lesson the universe charged interest for.
                    </p>
                  </div>
                  <div className="font-mono text-[10px] tracking-[0.25em] text-ash">
                    <p>BEST RING · {mind.bestRing}</p>
                    <p className="mt-1">BEST STREAK · {mind.bestStreak}</p>
                    {ring % 5 === 0 && <p className="mt-1 flex items-center gap-2 text-blood"><Skull className="h-3 w-3" />BOSS WILL APPEAR THIS RING</p>}
                  </div>
                </div>

                <button onClick={begin} className="btn-crucible mt-10 w-full border border-violet-x/70 px-12 py-5 font-mono text-sm tracking-[0.35em] md:w-auto md:px-16">
                  INITIATE RING {ring} ▸
                </button>
                <p className="mt-3 font-mono text-[10px] tracking-[0.25em] text-ash/60">
                  PRESS ENTER OR CLICK — {ringTrialCount(ring)} TRIALS FIRE IMMEDIATELY
                </p>

                <details className="mt-8">
                  <summary className="cursor-pointer font-mono text-[10px] tracking-[0.25em] text-ash/70 hover:text-ivory">
                    NARROW THE SPHERE — OPTIONAL
                  </summary>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <SphereChip label="MIXED" active={domain === "mixed"} onClick={() => setDomain("mixed")} />
                    {DOMAINS.map((d) => (
                      <SphereChip key={d.id} label={`${d.glyph} ${d.name.toUpperCase()}`} active={domain === d.id} onClick={() => setDomain(d.id)} />
                    ))}
                  </div>
                </details>
              </div>
            </motion.div>
          )}

          {(phase === "playing" || phase === "verdict") && trials.length > 0 && (
            <TrialView
              key={`${ti}-${trials[ti].id}`}
              trial={trials[ti]}
              index={ti}
              total={trials.length}
              phase={phase}
              verdict={verdict}
              picked={picked}
              onAnswer={answer}
              onNext={nextTrial}
            />
          )}

          {phase === "ringEnd" && (
            <motion.div key="end" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, ease }} className="panel panel-hot p-10 text-center md:p-16">
              {passed ? (
                <>
                  <p className="font-mono text-[10px] tracking-[0.5em] text-jade">RING {ring} — ASCENDED</p>
                  <h2 className="mt-4 font-display text-5xl text-jade">The chamber yields.</h2>
                  <p className="mx-auto mt-4 max-w-md text-sm text-ash">
                    {solved}/{trials.length} trials conquered. Ring {ring + 1} now arms itself — difficulty deepens,
                    margins narrow. The crucible has begun to take you <span className="text-ivory">seriously</span>.
                  </p>
                  <button onClick={() => { setRing((r) => r + 1); setPhase("idle"); }} className="btn-crucible mt-10 inline-flex items-center gap-3 border border-jade/60 px-10 py-4 font-mono text-xs tracking-[0.3em] text-jade">
                    PROCEED TO RING {ring + 1} <ChevronRight className="h-4 w-4" />
                  </button>
                </>
              ) : (
                <>
                  <p className="font-mono text-[10px] tracking-[0.5em] text-blood">RING {ring} — REJECTED</p>
                  <h2 className="mt-4 flex items-center justify-center gap-4 font-display text-5xl text-blood"><TriangleAlert className="h-8 w-8" />The chamber holds.</h2>
                  <p className="mx-auto mt-4 max-w-md text-sm text-ash">
                    {solved}/{trials.length} solved — the threshold was {ringPassThreshold(ring)}. Study the verdicts you earned;
                    pain is data with a tuition fee. Re-enter when ready.
                  </p>
                  <button onClick={() => setPhase("idle")} className="btn-crucible mt-10 inline-flex items-center gap-3 border border-blood/60 px-10 py-4 font-mono text-xs tracking-[0.3em] text-blood">
                    <RotateCcw className="h-4 w-4" /> RE-ENTER RING {ring}
                  </button>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </GateMode>
  );
}

function GateMode({ children }: { children: React.ReactNode }) {
  return (
    <main className="relative min-h-screen">
      <Nav />
      <div className="absolute inset-0">
        <MindScene dim />
      </div>
      {children}
    </main>
  );
}

function Boot() {
  return (
    <main className="relative flex min-h-screen items-center justify-center bg-void">
      <p className="font-mono text-[10px] tracking-[0.5em] text-ash">CALIBRATING NEURAL LATTICE…</p>
    </main>
  );
}

function SphereChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`border px-4 py-2 font-mono text-[10px] tracking-[0.2em] transition-all ${
        active ? "border-violet-x bg-violet-x/15 text-ivory" : "hairline text-ash hover:text-ivory"
      }`}
    >
      {label}
    </button>
  );
}

/* ─────────────── TRIAL VIEW ─────────────── */

function TrialView({
  trial, index, total, phase, verdict, picked, onAnswer, onNext,
}: {
  trial: Trial;
  index: number;
  total: number;
  phase: "playing" | "verdict";
  verdict: Verdict | null;
  picked: number | null;
  onAnswer: (i: number, timedOut?: boolean) => void;
  onNext: () => void;
}) {
  const [frac, setFrac] = useState(1);
  const [seconds, setSeconds] = useState(trial.timeLimit);
  const startRef = useRef(0);
  const answeredRef = useRef(false);
  const onAnswerRef = useRef(onAnswer);
  onAnswerRef.current = onAnswer;
  const onNextRef = useRef(onNext);
  onNextRef.current = onNext;

  /* Keyboard: 1–4 / A–D answer; Enter advances. */
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const map: Record<string, number> = { "1": 0, "2": 1, "3": 2, "4": 3, a: 0, b: 1, c: 2, d: 3 };
      const idx = map[e.key.toLowerCase()];
      if (phase === "playing" && idx !== undefined && !answeredRef.current && trial.options[idx] !== undefined) {
        answeredRef.current = true;
        onAnswerRef.current(idx);
      }
      if (phase === "verdict" && e.key === "Enter") onNextRef.current();
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [phase, trial.options.length]);

  useEffect(() => {
    startRef.current = Date.now();
    answeredRef.current = false;
    setFrac(1);
    setSeconds(trial.timeLimit);
    const id = window.setInterval(() => {
      const elapsed = (Date.now() - startRef.current) / 1000;
      const left = Math.max(0, trial.timeLimit - elapsed);
      setFrac(left / trial.timeLimit);
      setSeconds(Math.ceil(left));
      if (left <= 5.5 && left > 5) sfx.tick();
      if (left <= 0 && !answeredRef.current) {
        answeredRef.current = true;
        window.clearInterval(id);
        onAnswerRef.current(-1, true);
      }
    }, 100);
    return () => window.clearInterval(id);
  }, [trial.id, trial.timeLimit]);

  const C = 2 * Math.PI * 26;
  const danger = frac < 0.25;

  return (
    <motion.div key={trial.id} initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.5, ease }}>
      <div className="mb-4 flex items-center justify-between font-mono text-[10px] tracking-[0.25em] text-ash">
        <span>TRIAL {index + 1} / {total}</span>
        <span className={trial.isBoss ? "text-blood" : "text-violet-x"}>
          {trial.isBoss ? "◈ BOSS TRIAL" : (DOMAINS.find((d) => d.id === trial.domain)?.name ?? "").toUpperCase()}
        </span>
        <span>DIFFICULTY {trial.difficulty}/10</span>
      </div>

      <div className={`panel p-8 md:p-12 ${trial.isBoss ? "border-blood/50" : ""} ${verdict ? (verdict.correct ? "border-jade/50" : "border-blood/60") : ""}`}>
        <div className="flex items-start justify-between gap-8">
          <h2 className="font-display text-2xl leading-snug md:text-4xl md:leading-tight">{trial.prompt}</h2>
          <div className="relative hidden shrink-0 md:block">
            <svg width="64" height="64" viewBox="0 0 64 64" className="-rotate-90">
              <circle cx="32" cy="32" r="26" fill="none" stroke="#1c1c28" strokeWidth="4" />
              <circle
                cx="32" cy="32" r="26" fill="none"
                stroke={danger ? "#ff4455" : "#8b7cff"} strokeWidth="4" strokeLinecap="round"
                strokeDasharray={C} strokeDashoffset={C * (1 - frac)}
                style={{ transition: "stroke 0.3s" }}
              />
            </svg>
            <span className={`absolute inset-0 grid place-items-center rotate-0 font-mono text-sm ${danger ? "text-blood" : "text-ivory"}`}>
              {seconds}
            </span>
          </div>
        </div>
        <p className="mt-2 font-mono text-[10px] tracking-[0.25em] text-ash md:hidden">TIME {seconds}s</p>

        <div className="mt-10 grid gap-3">
          {trial.options.map((opt, i) => {
            let cls = "";
            if (phase === "verdict" && verdict) {
              if (i === verdict.answerIndex) cls = "border-jade bg-jade/10 text-jade";
              else if (i === picked) cls = "border-blood bg-blood/10 text-blood";
              else cls = "opacity-40";
            }
            return (
              <button
                key={i}
                disabled={phase === "verdict"}
                onClick={() => { if (phase === "playing" && !answeredRef.current) { answeredRef.current = true; onAnswer(i); } }}
                className={`opt-card group flex items-center gap-5 border hairline bg-void/60 px-6 py-4 text-left ${cls}`}
              >
                <span className="font-mono text-[10px] tracking-widest text-violet-x">{["A", "B", "C", "D"][i]}</span>
                <span className="font-sans text-sm md:text-base">{opt}</span>
              </button>
            );
          })}
        </div>
        {phase === "playing" && (
          <p className="mt-4 font-mono text-[9px] tracking-[0.3em] text-ash/50">KEYS 1–4 ANSWER · POSITIONS SHUFFLED PER MIND</p>
        )}

        <AnimatePresence>
          {phase === "verdict" && verdict && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease }}
              className={`mt-8 border-t pt-6 ${verdict.correct ? "border-jade/30" : "border-blood/30"}`}
            >
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className={`font-mono text-[10px] tracking-[0.4em] ${verdict.correct ? "text-jade" : "text-blood"}`}>
                    {verdict.correct ? (verdict.isBoss ? "BOSS OBLITERATED" : "VERDICT — CORRECT") : "VERDICT — WRONG"}
                  </p>
                  <p className="mt-2 font-display text-xl">{verdict.correct ? `+${verdict.xp} XP` : "The chamber remembers."}</p>
                </div>
                {!verdict.correct && verdict.answerIndex >= 0 && (
                  <p className="font-mono text-[10px] tracking-widest text-jade">CORRECT: {trial.options[verdict.answerIndex]}</p>
                )}
                {verdict.xp > 0 && (
                  <div className="flex gap-4 font-mono text-[10px] tracking-widest">
                    {verdict.deltaPillars.c > 0 && <span className="text-amber-x">◬ +{verdict.deltaPillars.c}</span>}
                    {verdict.deltaPillars.i > 0 && <span className="text-violet-x">◍ +{verdict.deltaPillars.i}</span>}
                    {verdict.deltaPillars.p > 0 && <span className="text-jade">◈ +{verdict.deltaPillars.p}</span>}
                  </div>
                )}
              </div>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.25 }}
                className="mt-4 border-l-2 border-violet-x/50 pl-4 font-display text-base italic leading-relaxed text-ash"
              >
                {verdict.explanation}
              </motion.p>
              <button onClick={onNext} className="btn-crucible mt-6 inline-flex items-center gap-2 border border-violet-x/60 px-8 py-3 font-mono text-[10px] tracking-[0.3em]">
                {index + 1 >= total ? "RING VERDICT" : "NEXT TRIAL"} <ChevronRight className="h-3 w-3" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
