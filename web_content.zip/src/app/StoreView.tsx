import { useEffect, useMemo, useState } from "react";
import { BadgeCheck, ExternalLink, Search, ShoppingBag } from "lucide-react";
import { fetchEurRates } from "./api";
import { hueOf } from "./catalog";

interface StoreApp {
  name: string;
  maker: string;
  desc: string;
  url: string;
  category: string;
  tag: "Código abierto" | "Gratis" | "Freemium";
}

const APPS: StoreApp[] = [
  { name: "Firefox", maker: "Mozilla", desc: "El navegador libre y privado, con sincronización entre dispositivos.", url: "https://www.mozilla.org/es-ES/firefox/", category: "Navegador", tag: "Código abierto" },
  { name: "VLC for Android", maker: "VideoLAN", desc: "Reproductor multimedia definitivo: todos los formatos, sin anuncios.", url: "https://www.videolan.org/vlc-android/", category: "Multimedia", tag: "Código abierto" },
  { name: "NewPipe", maker: "Team NewPipe", desc: "Cliente ligero para vídeos y audio en streaming, sin cuenta.", url: "https://newpipe.net/", category: "Multimedia", tag: "Código abierto" },
  { name: "AntennaPod", maker: "AntennaPod team", desc: "Gestor de podcasts libre: suscripción, descargas y velocidad variable.", url: "https://antennapod.org/", category: "Música", tag: "Código abierto" },
  { name: "Signal", maker: "Signal Foundation", desc: "Mensajería cifrada de extremo a extremo, sin anuncios ni rastreadores.", url: "https://signal.org/android/", category: "Seguridad", tag: "Código abierto" },
  { name: "Thunderbird", maker: "MZLA Technologies", desc: "Correo y calendario de escritorio y Android, sin ataduras.", url: "https://www.thunderbird.net/", category: "Herramientas", tag: "Código abierto" },
  { name: "OsmAnd", maker: "OsmAnd BV", desc: "Navegación offline con mapas de OpenStreetMap — gratis y sin límites.", url: "https://osmand.net/", category: "Herramientas", tag: "Freemium" },
  { name: "Aegis Authenticator", maker: "Beem Development", desc: "Códigos 2FA cifrados con respaldo seguro. Imprescindible.", url: "https://getaegis.app/", category: "Seguridad", tag: "Código abierto" },
  { name: "F-Droid", maker: "F-Droid", desc: "La tienda de apps libres por excelencia: instalar, actualizar, auditar.", url: "https://f-droid.org/", category: "Herramientas", tag: "Código abierto" },
  { name: "KDE Connect", maker: "KDE", desc: "Portapapeles, avisos, archivos y mando remoto entre móvil y ordenador.", url: "https://kdeconnect.kde.org/", category: "Herramientas", tag: "Código abierto" },
  { name: "VLC Remote", maker: "VideoLAN", desc: "Convierte tu Android en el mando perfecto para tu VLC de casa.", url: "https://www.videolan.org/vlc/", category: "Herramientas", tag: "Gratis" },
  { name: "KeePassDX", maker: "Kunzisoft", desc: "Gestor de contraseñas compatible con KeePass, 100% offline.", url: "https://keepassdx.com/", category: "Seguridad", tag: "Código abierto" },
];
const CATEGORIES = ["Todas", "Herramientas", "Multimedia", "Seguridad", "Música", "Navegador"];

export default function StoreView() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Todas");
  const [rates, setRates] = useState<{ USD: number; GBP: number; MXN: number } | null>(null);
  useEffect(() => { fetchEurRates().then(setRates); }, []);
  const shown = useMemo(() => APPS.filter((a) => {
    if (category !== "Todas" && a.category !== category) return false;
    const q = query.trim().toLowerCase();
    if (q && !`${a.name} ${a.maker} ${a.desc}`.toLowerCase().includes(q)) return false;
    return true;
  }), [query, category]);

  return (
    <div className="flex h-full flex-col gap-3 overflow-hidden p-3 sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-blue-700"><ShoppingBag size={19} className="text-white" /></span>
          <div>
            <h1 className="font-display text-lg font-black text-white">TV LO3 Store</h1>
            <p className="text-[10px] uppercase tracking-wider text-slate-500">Selección curada de apps libres y autorizadas</p>
          </div>
        </div>
        <label className="relative">
          <span className="sr-only">Buscar en la Store</span>
          <Search size={13} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar apps…" className="h-10 w-48 rounded-xl border border-white/10 bg-black/30 pl-9 pr-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-cyanx/50" />
        </label>
      </div>

      <div className="flex gap-1 overflow-x-auto thin-scroll -mx-1 px-1" role="tablist" aria-label="Categorías">
        {CATEGORIES.map((c) => <button key={c} role="tab" aria-selected={category === c} onClick={() => setCategory(c)} className={`rounded-full px-3 py-1.5 text-[10px] font-bold transition-colors ${category === c ? "bg-electric text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}>{c}</button>)}
      </div>

      <div className="thin-scroll min-h-0 flex-1 overflow-y-auto pr-0.5">
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {shown.map((app) => (
            <article key={app.name} className="flex flex-col rounded-2xl border border-white/8 bg-panel2 p-3 transition-colors hover:border-cyanx/30">
              <div className="flex items-start gap-3">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl font-display text-lg font-black text-white" style={{ background: `linear-gradient(150deg, hsl(${hueOf(app.name)} 62% 44%), hsl(${(hueOf(app.name) + 45) % 360} 65% 18%))` }}>{app.name[0]}</span>
                <div className="min-w-0">
                  <h2 className="flex items-center gap-1.5 text-sm font-bold text-slate-100">{app.name} <BadgeCheck size={13} className="text-cyanx" aria-label="Verificada" /></h2>
                  <p className="text-[9px] uppercase tracking-wider text-slate-500">{app.maker} · {app.category}</p>
                </div>
              </div>
              <p className="mt-2 flex-1 text-[11px] leading-snug text-slate-400">{app.desc}</p>
              <div className="mt-2 flex items-center justify-between gap-2">
                <span className={`chip ${app.tag === "Código abierto" ? "border-emerald-400/40 text-emerald-300" : ""}`}>{app.tag}</span>
                <a href={app.url} target="_blank" rel="noopener noreferrer" className="flex h-9 items-center gap-1.5 rounded-lg bg-electric/90 px-3 text-[10px] font-bold text-white transition-colors hover:bg-electric">Obtener <ExternalLink size={11} /></a>
              </div>
            </article>
          ))}
          {shown.length === 0 && <p className="col-span-full rounded-2xl border border-white/8 p-6 text-center text-xs text-slate-500">Nada coincide con “{query}”.</p>}
        </div>
      </div>
      {rates && (
        <p className="rounded-xl border border-gold/25 bg-gold/5 px-3 py-2 text-center text-[10px] text-amber-100/90">
          PREMIUM · 4,99 €/mes ≈ <span className="font-bold text-gold">${(4.99 * rates.USD).toFixed(2)}</span> · <span className="font-bold text-gold">£{(4.99 * rates.GBP).toFixed(2)}</span> · <span className="font-bold text-gold">MX${(4.99 * rates.MXN).toFixed(2)}</span> <span className="text-slate-500">· cambio en vivo (ECB vía er-api)</span>
        </p>
      )}
      <p className="text-[9px] leading-snug text-slate-600">TV LO3 Store solo distribuye software libre y autorizado: sin descargas silenciosas, sin instaladores de terceros. Instalar desde fuera de la Store requiere tu confirmación explícita.</p>
    </div>
  );
}
