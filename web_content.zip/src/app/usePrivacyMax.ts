import { useEffect, useState } from "react";

const KEY = "lo3-privacy-max";

/** Privacy Max — when true, the app loads ZERO external images (logos, posters, covers, flags). */
export function usePrivacyMax(): boolean {
  const [v, setV] = useState<boolean>(() => {
    try { return window.localStorage.getItem(KEY) === "true"; } catch { return false; }
  });
  useEffect(() => {
    const onChange = () => { try { setV(window.localStorage.getItem(KEY) === "true"); } catch { /* noop */ } };
    window.addEventListener("lo3-privacy", onChange);
    window.addEventListener("storage", onChange);
    return () => { window.removeEventListener("lo3-privacy", onChange); window.removeEventListener("storage", onChange); };
  }, []);
  return v;
}

export function setPrivacyMax(v: boolean) {
  try { window.localStorage.setItem(KEY, String(v)); } catch { /* noop */ }
  window.dispatchEvent(new Event("lo3-privacy"));
}
