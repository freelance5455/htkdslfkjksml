import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { verifyPassword, hashPassword } from "@/lib/crypto";
import { fail, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { toCurrentUser } from "@/lib/mappers";
import { profileSchema } from "@/lib/validators";

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  return ok(auth.user);
}

export async function PATCH(req: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const parsed = await parseBody(req, profileSchema);
  if ("response" in parsed) return parsed.response;
  const d = parsed.data;

  try {
    const set: Partial<typeof users.$inferInsert> = { updatedAt: new Date() };
    if (d.fullName !== undefined) set.fullName = d.fullName;
    if (d.phone !== undefined) set.phone = d.phone;
    if (d.city !== undefined) set.city = d.city;
    if (d.address !== undefined) set.address = d.address;
    if (d.emergencyContactName !== undefined) set.emergencyContactName = d.emergencyContactName;
    if (d.emergencyContactPhone !== undefined) set.emergencyContactPhone = d.emergencyContactPhone;

    if (d.newPassword) {
      const [row] = await db.select({ hash: users.passwordHash }).from(users).where(eq(users.id, auth.user.id)).limit(1);
      if (!row || !(await verifyPassword(d.currentPassword ?? "", row.hash))) return fail("wrong_password", 400);
      set.passwordHash = await hashPassword(d.newPassword);
    }

    const [updated] = await db.update(users).set(set).where(eq(users.id, auth.user.id)).returning();
    return ok(toCurrentUser(updated));
  } catch (err) {
    return serverError(err);
  }
}
