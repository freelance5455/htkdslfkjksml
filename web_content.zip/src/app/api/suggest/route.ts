import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { history, bookmarks } from "@/db/schema";
import { ilike, or, desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const q = (req.nextUrl.searchParams.get("q") || "").trim();
  const engine = req.nextUrl.searchParams.get("engine") || "google";
  if (!q) return NextResponse.json({ suggestions: [] });

  const pattern = `%${q}%`;
  const [hist, bms, remote] = await Promise.all([
    db
      .select({ url: history.url, title: history.title, c: sql<number>`count(*)` })
      .from(history)
      .where(or(ilike(history.url, pattern), ilike(history.title, pattern)))
      .groupBy(history.url, history.title)
      .orderBy(desc(sql`count(*)`))
      .limit(4)
      .catch(() => []),
    db
      .select({ url: bookmarks.url, title: bookmarks.title })
      .from(bookmarks)
      .where(or(ilike(bookmarks.url, pattern), ilike(bookmarks.title, pattern)))
      .limit(3)
      .catch(() => []),
    fetchRemoteSuggestions(q, engine),
  ]);

  const suggestions: { type: string; text: string; url?: string; title?: string }[] = [];
  const seen = new Set<string>();
  for (const b of bms) {
    if (!seen.has(b.url)) {
      seen.add(b.url);
      suggestions.push({ type: "bookmark", text: b.url, url: b.url, title: b.title });
    }
  }
  for (const h of hist) {
    if (!seen.has(h.url)) {
      seen.add(h.url);
      suggestions.push({ type: "history", text: h.url, url: h.url, title: h.title });
    }
  }
  for (const s of remote) {
    if (!seen.has("s:" + s)) {
      seen.add("s:" + s);
      suggestions.push({ type: "search", text: s });
    }
  }
  return NextResponse.json({ suggestions: suggestions.slice(0, 10) });
}

async function fetchRemoteSuggestions(q: string, engine: string): Promise<string[]> {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), 2500);
  try {
    if (engine === "yandex") {
      const r = await fetch(
        `https://suggest.yandex.ru/suggest-ff.cgi?part=${encodeURIComponent(q)}&uil=ru&v=3&sn=6`,
        { signal: controller.signal, headers: { "user-agent": "Mozilla/5.0" } }
      );
      const data = (await r.json()) as unknown[];
      return Array.isArray(data[1]) ? (data[1] as string[]).slice(0, 6) : [];
    }
    const r = await fetch(
      `https://suggestqueries.google.com/complete/search?client=firefox&hl=ru&q=${encodeURIComponent(q)}`,
      { signal: controller.signal, headers: { "user-agent": "Mozilla/5.0" } }
    );
    const data = (await r.json()) as unknown[];
    return Array.isArray(data[1]) ? (data[1] as string[]).slice(0, 6) : [];
  } catch {
    return [];
  } finally {
    clearTimeout(t);
  }
}
