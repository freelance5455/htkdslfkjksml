import { and, count, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { ok, requireUser, serverError } from "@/lib/http";

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const rows = await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, auth.user.id))
      .orderBy(desc(notifications.createdAt))
      .limit(50);
    const [{ c }] = await db
      .select({ c: count() })
      .from(notifications)
      .where(and(eq(notifications.userId, auth.user.id), eq(notifications.isRead, false)));
    return ok({ notifications: rows, unreadCount: Number(c) });
  } catch (err) {
    return serverError(err);
  }
}

/** Marks all of the current user's notifications as read. */
export async function PATCH() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(and(eq(notifications.userId, auth.user.id), eq(notifications.isRead, false)));
    return ok({ ok: true });
  } catch (err) {
    return serverError(err);
  }
}
