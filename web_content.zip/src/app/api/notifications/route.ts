import { NextRequest } from "next/server";
import { db } from "@/db";
import { pushTokens } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { USER_KEY, listNotifications, notify } from "@/server/store";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const items = await listNotifications(40);
    return Response.json({ ok: true, notifications: items });
  } catch (err) {
    return Response.json(
      { ok: false, notifications: [], error: err instanceof Error ? err.message : "שגיאה" },
      { status: 500 },
    );
  }
}

type Body = { action?: "REGISTER" | "TEST"; token?: string; platform?: string };

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Body;
    if (body.action === "TEST") {
      await notify("בדיקת התראות", "מנוע ההתראות פעיל ומחובר למכשיר", "signal");
      return Response.json({ ok: true, message: "נשלחה התראת בדיקה" });
    }
    const token = String(body.token ?? "").trim();
    if (!token) return Response.json({ ok: false, error: "חסר טוקן" }, { status: 400 });
    const existing = await db
      .select()
      .from(pushTokens)
      .where(and(eq(pushTokens.userKey, USER_KEY), eq(pushTokens.token, token)))
      .limit(1);
    if (existing.length === 0) {
      await db.insert(pushTokens).values({ userKey: USER_KEY, token, platform: body.platform ?? "expo" });
    }
    return Response.json({ ok: true, message: "המכשיר נרשם לקבלת התראות" });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "שגיאה ברישום התראות" },
      { status: 500 },
    );
  }
}
