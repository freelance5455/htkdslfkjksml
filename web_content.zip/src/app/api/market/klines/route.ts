import { NextRequest } from "next/server";
import { getKlines, getTicker } from "@/lib/market";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const symbol = (req.nextUrl.searchParams.get("symbol") ?? "BTCUSDT").toUpperCase();
  const interval = req.nextUrl.searchParams.get("interval") ?? "1h";
  const limit = Math.min(500, Math.max(50, Number(req.nextUrl.searchParams.get("limit") ?? 200)));
  const [kl, ticker] = await Promise.all([getKlines(symbol, interval, limit), getTicker(symbol)]);
  return Response.json({
    ok: kl.data.length > 0,
    symbol,
    interval,
    source: kl.source,
    degraded: kl.degraded,
    error: kl.error ?? null,
    candles: kl.data,
    ticker,
  });
}
