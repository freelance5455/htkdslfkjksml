import { NextRequest } from "next/server";
import { getOrderBook, getTicker, getTrades } from "@/lib/market";

export const dynamic = "force-dynamic";

/** ספר פקודות + סרט עסקאות בזמן אמת (גיבוי ל-WebSocket) */
export async function GET(req: NextRequest) {
  const symbol = (req.nextUrl.searchParams.get("symbol") ?? "BTCUSDT").toUpperCase();
  const [book, trades, ticker] = await Promise.all([
    getOrderBook(symbol, 25),
    getTrades(symbol, 40),
    getTicker(symbol),
  ]);
  return Response.json({
    ok: book.data.bids.length > 0 || trades.data.length > 0,
    symbol,
    source: book.source !== "none" ? book.source : trades.source,
    degraded: book.degraded || trades.degraded,
    error: book.error ?? trades.error ?? null,
    orderBook: book.data,
    trades: trades.data,
    ticker,
  });
}
