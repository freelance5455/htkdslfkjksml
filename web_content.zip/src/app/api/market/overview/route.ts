import { getFearGreed, getGlobalStats, getTickers } from "@/lib/market";
import { metaFor } from "@/lib/universe";

export const dynamic = "force-dynamic";

export async function GET() {
  const [tickers, fng, global] = await Promise.all([getTickers(), getFearGreed(), getGlobalStats()]);
  const rows = (Array.isArray(tickers.data) ? tickers.data : []).map((t) => {
    const meta = metaFor(t.symbol);
    return { ...t, name: meta.name, hebrewName: meta.hebrewName, sector: meta.sector, base: meta.base };
  });
  return Response.json({
    ok: rows.length > 0,
    source: tickers.source,
    degraded: tickers.degraded,
    error: tickers.error ?? null,
    tickers: rows,
    fearGreed: fng.data,
    fearGreedDegraded: fng.degraded,
    global: global.data,
    serverTime: Date.now(),
  });
}
