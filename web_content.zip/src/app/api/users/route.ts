import { and, desc, eq, ilike, or, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ROLES } from "@/lib/constants";
import { fail, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { logActivity } from "@/lib/notify";
import { userAdminSchema } from "@/lib/validators";

const publicColumns = {
  id: users.id,
  email: users.email,
  fullName: users.fullName,
  phone: users.phone,
  city: users.city,
  role: users.role,
  isActive: users.isActive,
  createdAt: users.createdAt,
};

/** Admin: list and search platform users (never returns password hashes). */
export async function GET(req: Request) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  try {
    const url = new URL(req.url);
    const q = url.searchParams.get("q")?.trim();
    const role = url.searchParams.get("role");
    const conds: SQL[] = [];
    if (q) {
      const pattern = `%${q.replace(/[%_]/g, "\\$&")}%`;
      conds.push(or(ilike(users.fullName, pattern), ilike(users.email, pattern))!);
    }
    if (role && (ROLES as readonly string[]).includes(role)) conds.push(eq(users.role, role));

    const rows = await db
      .select(publicColumns)
      .from(users)
      .where(conds.length ? and(...conds) : undefined)
      .orderBy(desc(users.createdAt))
      .limit(300);
    return ok({ users: rows });
  } catch (err) {
    return serverError(err);
  }
}

/** Admin: activate / deactivate accounts or change roles. */
export async function PATCH(req: Request) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const parsed = await parseBody(req, userAdminSchema);
  if ("response" in parsed) return parsed.response;
  const d = parsed.data;

  try {
    if (d.id === auth.user.id && (d.isActive === false || (d.role && d.role !== "admin"))) {
      return fail("cannot_disable_self", 409);
    }
    const set: Partial<typeof users.$inferInsert> = { updatedAt: new Date() };
    if (d.isActive !== undefined) set.isActive = d.isActive;
    if (d.role !== undefined) set.role = d.role;
    const [row] = await db.update(users).set(set).where(eq(users.id, d.id)).returning(publicColumns);
    if (!row) return fail("not_found", 404);
    await logActivity(auth.user.id, "user.updated", "user", d.id, JSON.stringify({ isActive: d.isActive, role: d.role }));
    return ok(row);
  } catch (err) {
    return serverError(err);
  }
}
