import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { minds, questions, attempts } from "@/db/schema";
import { eq } from "drizzle-orm";
import { trialXP, distributeXP, mindIndex, PILLAR_CAP } from "@/lib/scoring";
import { titleFor, nextTitle } from "@/lib/ranks";
import { shuffledOrder } from "@/lib/rng";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const { mindId, questionId, choiceIndex, elapsedMs, s } = body ?? {};
  if (!mindId || !questionId || typeof choiceIndex !== "number") {
    return NextResponse.json({ error: "invalid payload" }, { status: 400 });
  }

  const [mind] = await db.select().from(minds).where(eq(minds.id, mindId));
  if (!mind) return NextResponse.json({ error: "Mind not found" }, { status: 404 });
  const [q] = await db.select().from(questions).where(eq(questions.id, questionId));
  if (!q) return NextResponse.json({ error: "Question not found" }, { status: 404 });

  const elapsed = Math.max(0, Number(elapsedMs) || 0);
  /* Remap the shuffled choice back to the canonical index. If a nonce is
     supplied (all modern deliveries), position memory is useless. */
  let chosenOriginal = choiceIndex;
  let displayAnswerPos = q.answerIndex;
  if (typeof s === "string" && s.length > 0) {
    const order = shuffledOrder(q.id, s, q.options.length);
    chosenOriginal = order[choiceIndex] ?? -1;
    displayAnswerPos = order.indexOf(q.answerIndex);
  }
  const correct = chosenOriginal === q.answerIndex && elapsed <= (q.timeLimit + 8) * 1000;

  const bossBoost = q.isBoss ? 1.6 : 1;
  const xp = correct ? Math.round(trialXP(q.difficulty, mind.streak, elapsed, q.timeLimit) * bossBoost) : 0;
  const penalty = correct ? 0 : Math.min(4, Math.round(q.difficulty / 2));
  const delta = correct
    ? distributeXP(q.pillar, xp)
    : { c: -Math.min(mind.creativity, Math.round(penalty * q.pillar.c / 10)), i: -Math.min(mind.imagination, Math.round(penalty * q.pillar.i / 10)), p: -Math.min(mind.pattern, Math.round(penalty * q.pillar.p / 10)) };

  const creativity = Math.max(0, Math.min(PILLAR_CAP, mind.creativity + delta.c));
  const imagination = Math.max(0, Math.min(PILLAR_CAP, mind.imagination + delta.i));
  const pattern = Math.max(0, Math.min(PILLAR_CAP, mind.pattern + delta.p));
  const streak = correct ? mind.streak + 1 : 0;
  const bestStreak = Math.max(mind.bestStreak, streak);
  const idx = mindIndex(creativity, imagination, pattern, mind.bestRing, bestStreak);

  await db.update(minds).set({
    creativity, imagination, pattern,
    streak, bestStreak, mindIndex: idx,
    trialsSolved: mind.trialsSolved + (correct ? 1 : 0),
    trialsFailed: mind.trialsFailed + (correct ? 0 : 1),
    updatedAt: new Date(),
  }).where(eq(minds.id, mindId));

  await db.insert(attempts).values({
    mindId, kind: "trial", subjectId: questionId,
    choiceIndex: chosenOriginal, correct, score: xp, elapsedMs: Math.round(elapsed),
  });

  return NextResponse.json({
    correct,
    answerIndex: displayAnswerPos,
    explanation: q.explanation,
    xp,
    isBoss: q.isBoss,
    deltaPillars: delta,
    mind: {
      creativity, imagination, pattern, mindIndex: idx,
      streak, bestStreak, bestRing: mind.bestRing,
      title: titleFor(idx), nextTitle: nextTitle(idx),
    },
  });
}
