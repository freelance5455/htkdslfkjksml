import { sql } from "drizzle-orm";
import { getDb, isDatabaseConfigured } from "@/db";

/**
 * Health endpoint.
 *
 * `force-dynamic` + the Node runtime guarantee this is evaluated per request
 * and never statically pre-rendered, so it cannot fail the Next.js build when
 * DATABASE_URL is absent.
 *
 * The response is deliberately free of configuration detail: the client is
 * told only whether the cloud is usable (`cloudAvailable`). Reasons such as a
 * missing environment variable are logged server-side for operators.
 *
 *   GET /api/health       → liveness probe, never touches the database
 *   GET /api/health?db=1  → readiness probe, verifies real connectivity
 */
export const dynamic = "force-dynamic";
export const revalidate = 0;
export const runtime = "nodejs";

const NO_STORE = { "Cache-Control": "no-store, max-age=0" };

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const deep = searchParams.get("db") === "1" || searchParams.get("deep") === "1";
  const timestamp = new Date().toISOString();

  if (!isDatabaseConfigured()) {
    // Operator-facing detail stays in the server log.
    console.warn("[match-cricket] cloud sync disabled: DATABASE_URL is not set.");
    return Response.json(
      {
        status: "ok",
        service: "match-cricket",
        cloudAvailable: false,
        mode: "local",
        timestamp,
      },
      { status: 200, headers: NO_STORE },
    );
  }

  if (!deep) {
    return Response.json(
      { status: "ok", service: "match-cricket", cloudAvailable: true, timestamp },
      { headers: NO_STORE },
    );
  }

  try {
    const started = Date.now();
    await getDb().execute(sql`select 1`);
    return Response.json(
      {
        status: "ok",
        service: "match-cricket",
        cloudAvailable: true,
        mode: "cloud",
        latencyMs: Date.now() - started,
        timestamp,
      },
      { headers: NO_STORE },
    );
  } catch (error) {
    console.error("[match-cricket] DATABASE_CONNECTION_FAILED:", error);
    return Response.json(
      {
        status: "ok",
        service: "match-cricket",
        cloudAvailable: false,
        mode: "local",
        timestamp,
      },
      { status: 200, headers: NO_STORE },
    );
  }
}
