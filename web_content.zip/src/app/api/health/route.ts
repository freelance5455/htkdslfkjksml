// Platform healthcheck endpoint only — the application itself is a 100%
// client-side SPA with zero backend/database dependencies (all persistence
// lives in window.localStorage). This route is statically exportable and is
// excluded from the offline APK bundle.
export const dynamic = "force-static";

export async function GET() {
  return Response.json({ ok: true, mode: "static-client-spa" });
}
