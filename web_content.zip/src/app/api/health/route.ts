import { db } from "@/db";
import { sql } from "drizzle-orm";
import { getTickers, peekTickerStatus } from "@/lib/market";

export const dynamic = "force-dynamic";

/** בדיקת בריאות (Heartbeat) - נקראת כל 10-15 שניות מה-UI */
export async function GET() {
  const started = Date.now();
  try {
    await db.execute(sql`select 1`);
    const market = peekTickerStatus();
    // חימום קאש ברקע כדי להתאושש אוטומטית מניתוקים, בלי להאט את בדיקת הדופק
    if (market.count === 0 || market.ageMs > 60_000) {
      void getTickers().catch(() => undefined);
    }
    const latency = Date.now() - started;
    const primary = market.source === "bybit";
    const offline = market.source === "none" || market.count === 0;
    const stale = market.ageMs > 90_000;
    const status = offline ? "offline" : !primary ? "backup" : latency > 900 || stale ? "slow" : "online";
    const label =
      status === "offline"
        ? "אין תקשורת - מנסה להתחבר..."
        : status === "backup"
          ? "מחובר לשרת גיבוי"
          : status === "slow"
            ? "תקשורת איטית"
            : "מחובר לבורסה";
    return Response.json({
      ok: true,
      status,
      label,
      latency,
      marketSource: market.source,
      marketAgeMs: Number.isFinite(market.ageMs) ? market.ageMs : null,
      symbols: market.count,
      serverTime: Date.now(),
    });
  } catch {
    return Response.json(
      { ok: false, status: "offline", label: "אין תקשורת - מנסה להתחבר...", latency: Date.now() - started },
      { status: 500 },
    );
  }
}
