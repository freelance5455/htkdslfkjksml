import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { minds, decisions, attempts } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { decisionXP, distributeXP, mindIndex, PILLAR_CAP } from "@/lib/scoring";
import { titleFor } from "@/lib/ranks";
import { shuffledOrder, newNonce } from "@/lib/rng";

export async function GET(req: NextRequest) {
  const mindId = req.nextUrl.searchParams.get("mindId");
  if (!mindId) return NextResponse.json({ error: "mindId required" }, { status: 400 });

  const answeredRows = await db
    .select({ subjectId: attempts.subjectId })
    .from(attempts)
    .where(and(eq(attempts.mindId, mindId as never), eq(attempts.kind, "decision")));
  const answered = new Set(answeredRows.map((r) => r.subjectId));

  const all = await db.select().from(decisions);
  let pool = all.filter((d) => !answered.has(d.id));
  if (!pool.length) pool = all;
  const d = pool[Math.floor(Math.random() * pool.length)];

  // Shuffle choice order per delivery so positions are unlearnable.
  const s = newNonce();
  const order = shuffledOrder(d.id, s, d.choices.length);
  return NextResponse.json({
    decision: {
      id: d.id,
      s,
      title: d.title,
      narrative: d.narrative,
      difficulty: d.difficulty,
      choices: order.map((i) => ({ text: d.choices[i].text })), // scores stay hidden
      remaining: pool.length,
    },
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const { mindId, decisionId, choiceIndex, s } = body ?? {};
  if (!mindId || !decisionId || typeof choiceIndex !== "number") {
    return NextResponse.json({ error: "invalid payload" }, { status: 400 });
  }

  const [mind] = await db.select().from(minds).where(eq(minds.id, mindId));
  if (!mind) return NextResponse.json({ error: "Mind not found" }, { status: 404 });
  const [d] = await db.select().from(decisions).where(eq(decisions.id, decisionId));
  if (!d) return NextResponse.json({ error: "Decision not found" }, { status: 404 });
  let chosenOriginal = choiceIndex;
  if (typeof s === "string" && s.length > 0) {
    const order = shuffledOrder(d.id, s, d.choices.length);
    chosenOriginal = order[choiceIndex] ?? -1;
  }
  const choice = d.choices[chosenOriginal];
  if (!choice) return NextResponse.json({ error: "Invalid choice" }, { status: 400 });

  const xp = decisionXP(choice.score, d.difficulty);
  const delta = distributeXP(d.pillar, xp);
  const creativity = Math.min(PILLAR_CAP, mind.creativity + delta.c);
  const imagination = Math.min(PILLAR_CAP, mind.imagination + delta.i);
  const pattern = Math.min(PILLAR_CAP, mind.pattern + delta.p);
  const idx = mindIndex(creativity, imagination, pattern, mind.bestRing, mind.bestStreak);

  await db.update(minds).set({ creativity, imagination, pattern, mindIndex: idx, updatedAt: new Date() }).where(eq(minds.id, mindId));
  await db.insert(attempts).values({
    mindId, kind: "decision", subjectId: decisionId,
    choiceIndex: chosenOriginal, correct: choice.score >= 7, score: xp, elapsedMs: 0,
  });

  return NextResponse.json({
    score: choice.score,
    cascade: choice.cascade,
    xp,
    deltaPillars: delta,
    optimalText: d.choices.reduce((a, b) => (b.score > a.score ? b : a)).text,
    mind: { creativity, imagination, pattern, mindIndex: idx, streak: mind.streak, bestStreak: mind.bestStreak, bestRing: mind.bestRing, title: titleFor(idx) },
  });
}
