import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { entries, movies } from "@/db/schema";
import { toEntryDTO } from "@/lib/data";
import { getSessionFromRequest } from "@/lib/session";

export const dynamic = "force-dynamic";

type Patch = {
  status?: "watched" | "watchlist";
  rating?: number | null;
  review?: string | null;
  favorite?: boolean;
};

export async function POST(request: Request) {
  const session = await getSessionFromRequest(request);
  if (!session) {
    return Response.json({ error: "Sessione non valida" }, { status: 401 });
  }

  const body = (await request.json().catch(() => null)) as
    | { movieId?: number; status?: string; rating?: number | null; review?: string | null; favorite?: boolean }
    | null;

  const movieId = Number(body?.movieId);
  if (!Number.isFinite(movieId)) {
    return Response.json({ error: "Film non valido" }, { status: 400 });
  }

  const movieRows = await db.select({ id: movies.id }).from(movies).where(eq(movies.id, movieId)).limit(1);
  if (movieRows.length === 0) {
    return Response.json({ error: "Film inesistente" }, { status: 404 });
  }

  const existingRows = await db
    .select()
    .from(entries)
    .where(and(eq(entries.memberId, session.member.id), eq(entries.movieId, movieId)))
    .limit(1);
  const existing = existingRows[0];

  const patch: Patch = {};
  if (body?.status === "watched" || body?.status === "watchlist") patch.status = body.status;
  if (body?.rating === null) patch.rating = null;
  else if (typeof body?.rating === "number" && Number.isFinite(body.rating)) {
    if (body.rating <= 0) {
      patch.rating = null;
    } else {
      patch.rating = Math.min(5, Math.max(1, Math.round(body.rating)));
      patch.status = "watched";
    }
  }
  if (typeof body?.review === "string") patch.review = body.review.slice(0, 600);
  else if (body?.review === null) patch.review = null;
  if (typeof body?.favorite === "boolean") patch.favorite = body.favorite;

  const nextStatus = patch.status ?? (existing?.status as "watched" | "watchlist" | undefined) ?? "watched";
  const nextRating = patch.rating !== undefined ? patch.rating : (existing?.rating ?? null);
  const nextReview = patch.review !== undefined ? patch.review : (existing?.review ?? null);
  const nextFavorite = patch.favorite ?? existing?.favorite ?? false;

  if (nextStatus === "watchlist" && nextRating === null && nextReview === null && !nextFavorite) {
    // still a valid watchlist entry
  }

  const values = {
    memberId: session.member.id,
    movieId,
    status: nextStatus,
    rating: nextRating,
    review: nextReview,
    favorite: nextFavorite,
    updatedAt: new Date(),
  };

  const [saved] = await db
    .insert(entries)
    .values(values)
    .onConflictDoUpdate({
      target: [entries.memberId, entries.movieId],
      set: {
        status: values.status,
        rating: values.rating,
        review: values.review,
        favorite: values.favorite,
        updatedAt: values.updatedAt,
      },
    })
    .returning();

  return Response.json({ ok: true, entry: toEntryDTO(saved) });
}

export async function DELETE(request: Request) {
  const session = await getSessionFromRequest(request);
  if (!session) {
    return Response.json({ error: "Sessione non valida" }, { status: 401 });
  }
  const { searchParams } = new URL(request.url);
  const movieId = Number(searchParams.get("movieId"));
  if (!Number.isFinite(movieId)) {
    return Response.json({ error: "Film non valido" }, { status: 400 });
  }

  await db
    .delete(entries)
    .where(and(eq(entries.memberId, session.member.id), eq(entries.movieId, movieId)));

  return Response.json({ ok: true });
}
