import { ok, toErrorResponse } from "@/lib/api";
import { destroySession } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    await destroySession();
    return ok({});
  } catch (error) {
    return toErrorResponse(error);
  }
}
