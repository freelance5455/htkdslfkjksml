import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, userPreferences } from "@/db/schema";
import { hashPassword, normalizeEmail, validateEmail, passwordProblem } from "@/lib/auth/password";
import { createSession } from "@/lib/auth/session";
import { fail, ok, readJson, toErrorResponse } from "@/lib/api";
import { ensureBootstrap, getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    await ensureBootstrap();
    const body = await readJson(request);
    const email = normalizeEmail(String(body.email ?? ""));
    const password = String(body.password ?? "");
    const name = String(body.name ?? "").trim().slice(0, 120);

    if (!validateEmail(email)) return fail("Enter a valid email address.");
    const pwProblem = passwordProblem(password);
    if (pwProblem) return fail(pwProblem);
    if (password !== String(body.confirmPassword ?? password)) return fail("Passwords do not match.");

    const settings = await getSettings();
    if (!settings.signupEnabled) return fail("Sign ups are temporarily closed. Please check back soon.", 403);

    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing.length) return fail("An account with that email already exists.", 409);

    const [created] = await db
      .insert(users)
      .values({ email, name: name || email.split("@")[0], passwordHash: hashPassword(password), planKey: "free" })
      .returning({ id: users.id, email: users.email, name: users.name, planKey: users.planKey, role: users.role });

    if (!created) return fail("Could not create your account. Please try again.", 500);

    await db.insert(userPreferences).values({ userId: created.id }).onConflictDoNothing();
    await createSession(created.id);

    return ok({ user: created });
  } catch (error) {
    return toErrorResponse(error);
  }
}
