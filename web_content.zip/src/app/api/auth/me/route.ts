import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, userPreferences } from "@/db/schema";
import { getSessionUser } from "@/lib/auth/session";
import { ok, readJson, toErrorResponse } from "@/lib/api";
import { getSettings } from "@/lib/settings";
import { getPlans } from "@/lib/plans";
import { getUsageSummary, getUsageStats } from "@/lib/usage";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getSessionUser();
    const settings = await getSettings();
    if (!user) {
      return ok({ user: null, plans: await getPlans(), settings: publicSettings(settings) });
    }
    const [prefs] = await db
      .select()
      .from(userPreferences)
      .where(eq(userPreferences.userId, user.id))
      .limit(1);
    const [usage, stats, plans] = await Promise.all([
      getUsageSummary(user.id, user.planKey),
      getUsageStats(user.id),
      getPlans(),
    ]);
    return ok({
      user,
      preferences: prefs ?? null,
      usage,
      usageStats: stats,
      plans,
      settings: publicSettings(settings),
    });
  } catch (error) {
    return toErrorResponse(error);
  }
}

export async function PATCH(request: Request) {
  try {
    const user = await getSessionUser();
    if (!user) return toErrorResponse(new Error("Unauthorized"));
    const body = await readJson(request);
    const patch: Record<string, string> = {};
    for (const key of ["defaultPlatform", "defaultNiche", "defaultTone", "name"]) {
      if (typeof body[key] === "string") patch[key] = (body[key] as string).slice(0, 120);
    }
    if (patch.name) {
      await db.update(users).set({ name: patch.name }).where(eq(users.id, user.id));
    }
    const allowed = ["defaultPlatform", "defaultNiche", "defaultTone"] as const;
    const prefPatch: Record<string, string> = {};
    for (const key of allowed) if (patch[key]) prefPatch[key] = patch[key];
    await db.insert(userPreferences).values({ userId: user.id, ...prefPatch }).onConflictDoUpdate({
      target: userPreferences.userId,
      set: { ...prefPatch, updatedAt: new Date() },
    });
    return ok({ preferences: prefPatch, name: patch.name ?? undefined });
  } catch (error) {
    return toErrorResponse(error);
  }
}

function publicSettings(settings: Awaited<ReturnType<typeof getSettings>>) {
  return {
    niches: settings.niches,
    announcement: settings.announcement,
    brandName: settings.brandName,
    signupEnabled: settings.signupEnabled,
  };
}
