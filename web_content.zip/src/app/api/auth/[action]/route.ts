import { and, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { passwordResetTokens, professionals, users } from "@/db/schema";
import { getSessionUser, sessionCookie, signSession, SESSION_COOKIE } from "@/lib/auth";
import { hashPassword, hashToken, newToken, verifyPassword } from "@/lib/crypto";
import { fail, isSecure, ok, parseBody, publicOrigin, serverError } from "@/lib/http";
import { sendEmail } from "@/lib/mail";
import { toCurrentUser } from "@/lib/mappers";
import { getProfessionalByUserId } from "@/lib/queries";
import { L, logActivity, notifyAdmins } from "@/lib/notify";
import { forgotSchema, loginSchema, registerSchema, resetSchema } from "@/lib/validators";

type Ctx = { params: Promise<{ action: string }> };

function proSummary(p: { id: string; verificationStatus: string; profession: string } | null) {
  return p ? { id: p.id, verificationStatus: p.verificationStatus, profession: p.profession } : null;
}

export async function GET(_req: Request, ctx: Ctx) {
  const { action } = await ctx.params;
  if (action !== "me") return fail("not_found", 404);
  try {
    const user = await getSessionUser();
    if (!user) return ok({ user: null, professional: null });
    const pro = user.role === "professional" ? await getProfessionalByUserId(user.id) : null;
    return ok({ user, professional: proSummary(pro) });
  } catch (err) {
    return serverError(err);
  }
}

export async function POST(req: Request, ctx: Ctx) {
  const { action } = await ctx.params;
  try {
    switch (action) {
      case "register":
        return await register(req);
      case "login":
        return await login(req);
      case "logout": {
        const res = ok({ ok: true });
        res.cookies.set({ name: SESSION_COOKIE, value: "", path: "/", maxAge: 0 });
        return res;
      }
      case "forgot":
        return await forgot(req);
      case "reset":
        return await reset(req);
      default:
        return fail("not_found", 404);
    }
  } catch (err) {
    return serverError(err);
  }
}

async function register(req: Request) {
  const parsed = await parseBody(req, registerSchema);
  if ("response" in parsed) return parsed.response;
  const d = parsed.data;

  const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, d.email)).limit(1);
  if (existing) return fail("email_taken", 409);

  const passwordHash = await hashPassword(d.password);
  const { user, pro } = await db.transaction(async (tx) => {
    const [created] = await tx
      .insert(users)
      .values({
        email: d.email,
        passwordHash,
        fullName: d.fullName,
        phone: d.phone,
        city: d.city,
        role: d.role,
        locale: d.locale ?? "fr",
      })
      .returning();
    let proRow: typeof professionals.$inferSelect | null = null;
    if (d.role === "professional") {
      const rows = await tx
        .insert(professionals)
        .values({
          userId: created.id,
          profession: d.profession ?? "nurse",
          bio: { ar: "", fr: d.bio ?? "", en: "" },
          licenseNumber: d.licenseNumber ?? "",
          qualifications: d.qualifications ?? "",
          experienceYears: d.experienceYears ?? 0,
          serviceCodes: d.serviceCodes ?? [],
          serviceCities: d.serviceCities ?? [],
          availableDays: ["mon", "tue", "wed", "thu", "fri", "sat"],
          verificationStatus: "pending",
        })
        .returning();
      proRow = rows[0] ?? null;
    }
    return { user: created, pro: proRow };
  });

  if (pro) {
    await notifyAdmins(
      L("Nouveau professionnel à vérifier", "New professional to verify", "مهني جديد للتحقق"),
      L(
        `${user.fullName} (${pro.profession}) demande à être vérifié(e).`,
        `${user.fullName} (${pro.profession}) requests verification.`,
        `${user.fullName} يطلب التحقق من ملفه.`,
      ),
      "/admin",
    );
    await logActivity(user.id, "professional.registered", "professional", pro.id, user.email);
  } else {
    await logActivity(user.id, "user.registered", "user", user.id, user.email);
  }

  const token = await signSession(user.id, user.role);
  const res = ok({ user: toCurrentUser(user), professional: proSummary(pro) }, 201);
  res.cookies.set(sessionCookie(token, isSecure(req)));
  return res;
}

async function login(req: Request) {
  const parsed = await parseBody(req, loginSchema);
  if ("response" in parsed) return parsed.response;
  const { email, password } = parsed.data;

  const [user] = await db.select().from(users).where(eq(users.email, email.toLowerCase())).limit(1);
  if (!user || !(await verifyPassword(password, user.passwordHash))) {
    return fail("invalid_credentials", 401);
  }
  if (!user.isActive) return fail("account_disabled", 403);

  const pro = user.role === "professional" ? await getProfessionalByUserId(user.id) : null;
  const token = await signSession(user.id, user.role);
  const res = ok({ user: toCurrentUser(user), professional: proSummary(pro) });
  res.cookies.set(sessionCookie(token, isSecure(req)));
  return res;
}

async function forgot(req: Request) {
  const parsed = await parseBody(req, forgotSchema);
  if ("response" in parsed) return parsed.response;

  const [user] = await db
    .select({ id: users.id, email: users.email, fullName: users.fullName })
    .from(users)
    .where(eq(users.email, parsed.data.email))
    .limit(1);

  let demoResetUrl: string | null = null;
  if (user) {
    const token = newToken();
    await db.insert(passwordResetTokens).values({
      userId: user.id,
      tokenHash: hashToken(token),
      expiresAt: new Date(Date.now() + 60 * 60 * 1000),
    });
    const link = `${publicOrigin(req)}/forgot-password?token=${token}`;
    const sent = await sendEmail({
      to: user.email,
      subject: "ShifaCare — Réinitialisation du mot de passe / Password reset",
      html: `<p>Bonjour ${user.fullName},</p><p>Pour réinitialiser votre mot de passe, cliquez sur ce lien (valable 1 heure) :</p><p><a href="${link}">${link}</a></p><p>Si vous n'êtes pas à l'origine de cette demande, ignorez ce message.</p>`,
    });
    if (!sent && process.env.DEMO_RESET_LINKS === "true") demoResetUrl = link;
  }
  // Same response whether or not the account exists (prevents account enumeration).
  return ok({ ok: true, demoResetUrl });
}

async function reset(req: Request) {
  const parsed = await parseBody(req, resetSchema);
  if ("response" in parsed) return parsed.response;

  const [row] = await db
    .select()
    .from(passwordResetTokens)
    .where(
      and(
        eq(passwordResetTokens.tokenHash, hashToken(parsed.data.token)),
        isNull(passwordResetTokens.usedAt),
        gt(passwordResetTokens.expiresAt, new Date()),
      ),
    )
    .limit(1);
  if (!row) return fail("invalid_token", 400);

  const passwordHash = await hashPassword(parsed.data.password);
  await db.transaction(async (tx) => {
    await tx.update(users).set({ passwordHash, updatedAt: new Date() }).where(eq(users.id, row.userId));
    await tx
      .update(passwordResetTokens)
      .set({ usedAt: new Date() })
      .where(eq(passwordResetTokens.userId, row.userId));
  });
  await logActivity(row.userId, "user.password_reset", "user", row.userId);
  return ok({ ok: true });
}
