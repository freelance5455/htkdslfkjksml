import { and, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { passwordResets, users } from "@/db/schema";
import { newToken, normalizeEmail, passwordProblem } from "@/lib/auth/password";
import { fail, ok, readJson, toErrorResponse } from "@/lib/api";
import { ensureBootstrap } from "@/lib/settings";

export const dynamic = "force-dynamic";

/** Step 1 — request a reset link. Always returns ok to avoid user enumeration. */
export async function POST(request: Request) {
  try {
    await ensureBootstrap();
    const body = await readJson(request);
    const email = normalizeEmail(String(body.email ?? ""));
    if (!email) return fail("Enter the email on your account.");
    const rows = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    const user = rows[0];
    let devToken: string | undefined;

    if (user) {
      await db.delete(passwordResets).where(eq(passwordResets.userId, user.id));
      const token = newToken();
      await db.insert(passwordResets).values({
        token,
        userId: user.id,
        expiresAt: new Date(Date.now() + 60 * 60 * 1000),
      });
      // No mail provider is wired in this deployment, so the link is returned for
      // the demo environment only (and logged server-side in production).
      devToken = process.env.NODE_ENV === "production" ? undefined : token;
      console.info(`[auth] password reset requested for ${email}`);
    }
    return ok({
      message: "If that email exists, a reset link is on its way.",
      devToken,
    });
  } catch (error) {
    return toErrorResponse(error);
  }
}

/** Step 2 — complete the reset with the token + new password. */
export async function PUT(request: Request) {
  try {
    const body = await readJson(request);
    const token = String(body.token ?? "").trim();
    const password = String(body.password ?? "");
    if (!token) return fail("Reset token missing.");
    const problem = passwordProblem(password);
    if (problem) return fail(problem);
    if (password !== String(body.confirmPassword ?? password)) return fail("Passwords do not match.");

    const rows = await db
      .select()
      .from(passwordResets)
      .where(
        and(
          eq(passwordResets.token, token),
          isNull(passwordResets.usedAt),
          gt(passwordResets.expiresAt, new Date()),
        ),
      )
      .limit(1);
    const reset = rows[0];
    if (!reset) return fail("That reset link is invalid or has expired.", 400);

    const { hashPassword } = await import("@/lib/auth/password");
    await db.update(users).set({ passwordHash: hashPassword(password) }).where(eq(users.id, reset.userId));
    await db.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.token, token));
    await db.delete(passwordResets).where(eq(passwordResets.userId, reset.userId));

    return ok({ message: "Password updated. You can sign in now." });
  } catch (error) {
    return toErrorResponse(error);
  }
}
