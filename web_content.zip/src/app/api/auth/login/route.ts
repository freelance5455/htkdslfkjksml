import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, userPreferences } from "@/db/schema";
import { normalizeEmail, verifyPassword } from "@/lib/auth/password";
import { createSession, destroySession } from "@/lib/auth/session";
import { fail, ok, readJson, toErrorResponse } from "@/lib/api";
import { ensureBootstrap } from "@/lib/settings";

export const dynamic = "force-dynamic";

const tooMany = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function POST(request: Request) {
  try {
    await ensureBootstrap();
    const body = await readJson(request);
    const email = normalizeEmail(String(body.email ?? ""));
    const password = String(body.password ?? "");
    if (!email || !password) return fail("Email and password are required.");

    const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
    const user = rows[0];
    // Constant-ish response time to avoid user enumeration.
    if (!user) {
      await tooMany(150);
      return fail("Incorrect email or password.", 401);
    }
    if (!verifyPassword(password, user.passwordHash)) {
      await tooMany(150);
      return fail("Incorrect email or password.", 401);
    }

    await db.insert(userPreferences).values({ userId: user.id }).onConflictDoNothing();
    await destroySession().catch(() => undefined);
    await createSession(user.id);

    return ok({ user: { id: user.id, email: user.email, name: user.name, planKey: user.planKey, role: user.role } });
  } catch (error) {
    return toErrorResponse(error);
  }
}
