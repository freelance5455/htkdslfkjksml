import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ChatMessage = { role: "user" | "assistant"; content: string };

const systemPrompt =
  "Eres Auria AI, una asistente útil, clara, creativa y honesta. Responde en español por defecto, " +
  "excepto si el usuario pide expresamente otro idioma o una traducción. Da respuestas bien estructuradas " +
  "y prácticas. Puedes usar Markdown para organizar respuestas y bloques de código. No inventes fuentes, " +
  "datos recientes ni capacidades que no tengas. Reconoce la incertidumbre cuando corresponda.";

export async function POST(request: NextRequest) {
  let body: { messages?: unknown; mode?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "La solicitud no tiene un formato válido." }, { status: 400 });
  }

  if (!body || typeof body !== "object" || !Array.isArray(body.messages) || body.messages.length < 1 || body.messages.length > 16) {
    return NextResponse.json({ error: "Envía entre 1 y 16 mensajes." }, { status: 400 });
  }

  const messages: ChatMessage[] = [];
  let totalSize = 0;
  for (const item of body.messages) {
    if (
      typeof item !== "object" || item === null ||
      (item.role !== "user" && item.role !== "assistant") ||
      typeof item.content !== "string" || item.content.length > 23000
    ) {
      return NextResponse.json({ error: "Hay un mensaje no válido o demasiado largo." }, { status: 400 });
    }
    totalSize += item.content.length;
    messages.push({ role: item.role, content: item.content });
  }
  if (totalSize > 48000 || messages.at(-1)?.role !== "user") {
    return NextResponse.json({ error: "El contenido es demasiado largo o falta el mensaje del usuario." }, { status: 400 });
  }

  const mode = typeof body.mode === "string" ? body.mode.slice(0, 30) : "chat";
  const prompt = `${systemPrompt}${mode === "chat" ? " Mantén el hilo de la conversación." : " Completa la tarea solicitada antes de añadir comentarios."}`;
  const formattedMessages = [{ role: "system", content: prompt }, ...messages];
  const openAIKey = process.env.OPENAI_API_KEY;
  const pollinationsKey = process.env.POLLINATIONS_API_KEY;
  const endpoint = openAIKey
    ? `${(process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "")}/chat/completions`
    : pollinationsKey
      ? "https://gen.pollinations.ai/v1/chat/completions"
      : "https://text.pollinations.ai/openai";
  const token = openAIKey || pollinationsKey;
  const model = openAIKey ? (process.env.OPENAI_MODEL || "gpt-4o-mini") : "openai";

  try {
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ model, messages: formattedMessages, max_tokens: 1800, stream: false }),
      signal: AbortSignal.timeout(58000),
      cache: "no-store",
    });
    const raw = await upstream.text();
    let data: Record<string, unknown> | null = null;
    try { data = JSON.parse(raw) as Record<string, unknown>; } catch { /* The free endpoint can return plain text. */ }

    if (upstream.status === 402 || upstream.status === 429) {
      return NextResponse.json({ error: "El servicio gratuito alcanzó su límite. Espera unos 30 segundos y vuelve a intentarlo." }, { status: 429 });
    }
    if (!upstream.ok) {
      console.error("Auria AI upstream error:", upstream.status, raw.slice(0, 250));
      return NextResponse.json({ error: "El servicio de IA no está disponible en este momento. Inténtalo de nuevo." }, { status: 502 });
    }
    if (data && data.error) {
      return NextResponse.json({ error: "El servicio de IA no pudo completar la solicitud. Inténtalo de nuevo." }, { status: 502 });
    }
    const choices = data?.choices as Array<{ message?: { content?: string } }> | undefined;
    const answer = typeof choices?.[0]?.message?.content === "string"
      ? choices[0].message.content
      : typeof data?.answer === "string"
        ? data.answer
        : data === null ? raw : "";
    if (!answer.trim()) {
      return NextResponse.json({ error: "La IA no devolvió una respuesta. Inténtalo otra vez." }, { status: 502 });
    }
    return NextResponse.json({ answer: answer.trim(), provider: token ? "connected" : "free" }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Auria AI request failed:", error);
    return NextResponse.json({ error: "No se pudo conectar con el servicio de IA. Comprueba tu conexión e inténtalo otra vez." }, { status: 503 });
  }
}
