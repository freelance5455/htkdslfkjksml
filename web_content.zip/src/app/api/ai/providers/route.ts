import { NextResponse } from "next/server";
import { availableProviders, detectProvider } from "@/lib/ai";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({
    providers: availableProviders(),
    active: detectProvider(),
    search: {
      google: Boolean(process.env.GOOGLE_SEARCH_API_KEY && process.env.GOOGLE_SEARCH_CX),
      yandex: Boolean(process.env.YANDEX_SEARCH_API_KEY && process.env.YANDEX_FOLDER_ID),
      duckduckgo: true,
    },
  });
}
