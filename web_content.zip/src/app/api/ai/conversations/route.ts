import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const profileId = Number(req.nextUrl.searchParams.get("profileId") || 0);
  const rows = await db
    .select()
    .from(conversations)
    .where(eq(conversations.profileId, profileId))
    .orderBy(desc(conversations.updatedAt))
    .limit(50);
  return NextResponse.json(rows);
}
