import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { eq } from "drizzle-orm";
import { complete, detectProvider, formatSearchForPrompt, type ChatMsg } from "@/lib/ai";
import { webSearch, fetchPageText, type SearchResult } from "@/lib/websearch";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

type Body = {
  conversationId?: number;
  message: string;
  task?: "chat" | "summarize" | "translate" | "page" | "tabs" | "code";
  useSearch?: boolean;
  searchEngine?: string;
  provider?: string;
  page?: { url: string; title: string; text?: string } | null;
  tabs?: { url: string; title: string }[];
  targetLang?: string;
  profileId?: number;
};

export async function POST(req: NextRequest) {
  const body = (await req.json()) as Body;
  const task = body.task || "chat";
  const text = (body.message || "").trim();
  if (!text) return NextResponse.json({ error: "Пустое сообщение" }, { status: 400 });

  // 1. Диалог
  let convId = body.conversationId;
  if (!convId) {
    const [c] = await db
      .insert(conversations)
      .values({ title: text.slice(0, 60), profileId: body.profileId || 0 })
      .returning();
    convId = c.id;
  }
  const prior = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, convId))
    .orderBy(messages.id)
    .limit(20);

  await db.insert(messages).values({ conversationId: convId, role: "user", content: text });

  // 2. Контекст: страница, поиск, вкладки
  let pageText = body.page?.text || "";
  if ((task === "summarize" || task === "page") && body.page?.url && !pageText) {
    try {
      pageText = (await fetchPageText(body.page.url)).text;
    } catch {
      /* ignore */
    }
  }

  let sources: SearchResult[] = [];
  const needSearch =
    body.useSearch !== false && (task === "chat" || task === "code") && !/^(привет|hello|hi|спасибо)/i.test(text);
  if (needSearch) {
    try {
      sources = await webSearch(text, body.searchEngine || "auto", 6);
    } catch {
      sources = [];
    }
  }

  const system: string[] = [
    `Ты — Nova AI, встроенный ассистент браузера NovaBrowser. Отвечай на языке пользователя (по умолчанию русский), кратко и по делу, используй Markdown. Сегодня: ${new Date().toLocaleDateString("ru-RU")}.`,
    `[TASK]${task}[/TASK]`,
  ];
  if (task === "summarize") system.push("Задача: сделай структурированное краткое содержание страницы (5–8 пунктов), затем ключевые выводы.");
  if (task === "translate") system.push(`Задача: переведи текст пользователя на ${body.targetLang || "русский"} язык. Выведи только перевод.`);
  if (task === "code") system.push("Задача: помогай с кодом — объясняй, исправляй, пиши примеры в блоках кода с указанием языка.");
  if (task === "tabs") system.push("Задача: проанализируй открытые вкладки пользователя — сгруппируй по темам, предложи что закрыть/сохранить.");
  if (pageText) {
    system.push(`Текущая страница: ${body.page?.title || ""} (${body.page?.url || ""}).\n[PAGE]${pageText.slice(0, 12000)}[/PAGE]`);
  }
  if (body.tabs?.length) {
    system.push(`[TABS]${body.tabs.map((t) => `${t.title} — ${t.url}`).join("\n")}[/TABS]`);
  }
  if (sources.length) {
    system.push(
      `Результаты веб-поиска в реальном времени (используй их для актуальных фактов и ссылайся на источники номерами [1], [2]):\n[SEARCH]${formatSearchForPrompt(sources)}[/SEARCH]`
    );
  }

  const chat: ChatMsg[] = [
    { role: "system", content: system.join("\n\n") },
    ...prior.filter((m) => m.role !== "system").map((m) => ({ role: m.role as "user" | "assistant", content: m.content })),
    { role: "user", content: text },
  ];

  const provider = detectProvider(body.provider);
  let answer: string;
  try {
    answer = await complete(provider, chat);
  } catch (e) {
    answer = `⚠️ Ошибка провайдера (${provider}): ${e instanceof Error ? e.message : "unknown"}\n\n` + (await complete("local", chat));
  }

  const srcs = sources.map((s) => ({ title: s.title, url: s.url }));
  const [saved] = await db
    .insert(messages)
    .values({ conversationId: convId, role: "assistant", content: answer, sources: srcs })
    .returning();
  await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, convId));

  return NextResponse.json({ conversationId: convId, message: saved, provider, sources: srcs });
}
