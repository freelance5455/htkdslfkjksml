import { NextRequest, NextResponse } from "next/server";
import { fetchPageText } from "@/lib/websearch";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const url = req.nextUrl.searchParams.get("url") || "";
  if (!/^https?:\/\//.test(url)) return NextResponse.json({ error: "bad url" }, { status: 400 });
  try {
    return NextResponse.json(await fetchPageText(url));
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "fail" }, { status: 502 });
  }
}
