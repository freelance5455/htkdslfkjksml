import { getRecentActivity, getSquadSnapshot } from "@/lib/data";
import { getSessionFromRequest } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const session = await getSessionFromRequest(request);
  if (!session) {
    return Response.json({ error: "Sessione non trovata" }, { status: 401 });
  }

  const snapshot = await getSquadSnapshot(session.squad.id);
  if (!snapshot) {
    return Response.json({ error: "Squadra non trovata" }, { status: 404 });
  }

  const me = snapshot.members.find((member) => member.id === session.member.id);
  if (!me) {
    return Response.json({ error: "Profilo non trovato" }, { status: 404 });
  }

  const activity = await getRecentActivity(session.squad.id);

  return Response.json({ snapshot, me, activity });
}
