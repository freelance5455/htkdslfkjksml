import { NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await ctx.params;
    const body = await req.json();
    const [updated] = await db
      .update(products)
      .set({
        name: body.name !== undefined ? String(body.name) : undefined,
        modelNumber: body.modelNumber !== undefined ? String(body.modelNumber) : undefined,
        category: body.category !== undefined ? String(body.category) : undefined,
        categoryId: body.categoryId !== undefined ? Number(body.categoryId) : undefined,
        price: body.price !== undefined ? Number(body.price) : undefined,
        description: body.description !== undefined ? String(body.description) : undefined,
        image: body.image !== undefined ? String(body.image) : undefined,
        features: body.features !== undefined ? body.features : undefined,
        colors: body.colors !== undefined ? body.colors : undefined,
        status: body.status !== undefined ? String(body.status) : undefined,
        isFeatured: body.isFeatured !== undefined ? Boolean(body.isFeatured) : undefined,
        isBestSeller: body.isBestSeller !== undefined ? Boolean(body.isBestSeller) : undefined,
        isNewArrival: body.isNewArrival !== undefined ? Boolean(body.isNewArrival) : undefined,
        stock: body.stock !== undefined ? Number(body.stock) : undefined,
      })
      .where(eq(products.id, Number(id)))
      .returning();
    if (!updated) return NextResponse.json({ error: "Product not found" }, { status: 404 });
    return NextResponse.json({ product: updated });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await ctx.params;
    await db.delete(products).where(eq(products.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}