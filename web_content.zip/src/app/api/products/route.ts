import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, type NewProduct } from "@/db/schema";
import { desc } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const all = await db.select().from(products).orderBy(desc(products.id));
    return NextResponse.json({ products: all });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const required: (keyof NewProduct)[] = ["name", "modelNumber", "category", "price", "description", "image"];
    for (const field of required) {
      if (!body[field]) return NextResponse.json({ error: `${field} is required` }, { status: 400 });
    }

    const [created] = await db
      .insert(products)
      .values({
        name: String(body.name),
        modelNumber: String(body.modelNumber),
        category: String(body.category),
        categoryId: body.categoryId ? Number(body.categoryId) : null,
        price: Number(body.price),
        description: String(body.description),
        image: String(body.image),
        features: Array.isArray(body.features) ? body.features : [],
        colors: Array.isArray(body.colors) ? body.colors : [],
        status: body.status || "available",
        isFeatured: Boolean(body.isFeatured),
        isBestSeller: Boolean(body.isBestSeller),
        isNewArrival: Boolean(body.isNewArrival),
        stock: Number(body.stock) || 0,
      })
      .returning();

    return NextResponse.json({ product: created });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}