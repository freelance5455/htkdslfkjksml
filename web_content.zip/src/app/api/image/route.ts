import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams;
  const prompt = (params.get("prompt") || "").trim();
  const width = Number(params.get("width"));
  const height = Number(params.get("height"));
  const seed = Number(params.get("seed"));

  if (prompt.length < 4 || prompt.length > 1100 ||
      !Number.isInteger(width) || width < 256 || width > 1024 || width % 64 !== 0 ||
      !Number.isInteger(height) || height < 256 || height > 1024 || height % 64 !== 0 ||
      !Number.isInteger(seed) || seed < 0 || seed > 99999999) {
    return NextResponse.json({ error: "Describe la imagen y elige un tamaño válido." }, { status: 400 });
  }

  const key = process.env.POLLINATIONS_API_KEY;
  const endpoint = key
    ? `https://gen.pollinations.ai/image/${encodeURIComponent(prompt)}?width=${width}&height=${height}&seed=${seed}`
    : `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${width}&height=${height}&seed=${seed}`;

  try {
    const response = await fetch(endpoint, {
      headers: key ? { Authorization: `Bearer ${key}` } : {},
      signal: AbortSignal.timeout(105000),
      cache: "no-store",
    });
    if (response.status === 402 || response.status === 429) {
      return NextResponse.json({ error: "El servicio gratuito está ocupado. Espera un momento e inténtalo otra vez." }, { status: 429 });
    }
    const type = response.headers.get("content-type") || "";
    if (!response.ok || !type.startsWith("image/")) {
      console.error("Auria image upstream error:", response.status, type);
      return NextResponse.json({ error: "No se pudo crear la imagen ahora mismo. Prueba de nuevo en unos instantes." }, { status: 502 });
    }
    const image = await response.arrayBuffer();
    if (!image.byteLength || image.byteLength > 15 * 1024 * 1024) {
      return NextResponse.json({ error: "La imagen recibida no es válida." }, { status: 502 });
    }
    return new NextResponse(image, {
      headers: { "Content-Type": type, "Cache-Control": "public, max-age=86400, s-maxage=604800" },
    });
  } catch (error) {
    console.error("Auria image request failed:", error);
    return NextResponse.json({ error: "La generación tardó demasiado o el servicio no responde. Inténtalo de nuevo." }, { status: 503 });
  }
}
