import { and, count, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { generations, subscriptions, usageRecords, users } from "@/db/schema";
import { ok, requireUser, toErrorResponse } from "@/lib/api";
import { getPlans } from "@/lib/plans";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  if (auth.user.role !== "admin") return toErrorResponse(new Error("Admins only."));

  try {
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    const [
      userCounts,
      subCounts,
      genTotals,
      toolRows,
      dailyRows,
      planRows,
      recentUsers,
      recentGens,
    ] = await Promise.all([
      db.select({ total: count(), paid: sql<number>`sum(case when ${users.planKey} <> 'free' then 1 else 0 end)::int` }).from(users),
      db
        .select({ total: count(), mrr: sql<number>`coalesce(sum(${subscriptions.amountCents}), 0)::int` })
        .from(subscriptions)
        .where(eq(subscriptions.status, "active")),
      db.select({ total: count() }).from(generations),
      db
        .select({ tool: generations.tool, total: count() })
        .from(generations)
        .groupBy(generations.tool)
        .orderBy(desc(count())),
      db
        .select({
          day: sql<string>`to_char(date_trunc('day', ${usageRecords.createdAt}), 'YYYY-MM-DD')`,
          total: sql<number>`coalesce(sum(${usageRecords.credits}), 0)::int`,
        })
        .from(usageRecords)
        .where(gte(usageRecords.createdAt, sevenDaysAgo))
        .groupBy(sql`date_trunc('day', ${usageRecords.createdAt})`)
        .orderBy(sql`date_trunc('day', ${usageRecords.createdAt})`),
      getPlans(),
      db
        .select({ id: users.id, email: users.email, name: users.name, planKey: users.planKey, createdAt: users.createdAt })
        .from(users)
        .orderBy(desc(users.createdAt))
        .limit(8),
      db
        .select({ id: generations.id, tool: generations.tool, topic: generations.topic, createdAt: generations.createdAt })
        .from(generations)
        .orderBy(desc(generations.createdAt))
        .limit(8),
    ]);

    const paidUsers = Number(userCounts[0]?.paid ?? 0);
    const totalUsers = Number(userCounts[0]?.total ?? 0);
    const activeSubs = Number(subCounts[0]?.total ?? 0);
    const mrrCents = Number(subCounts[0]?.mrr ?? 0);

    const freeTier = await db
      .select({ total: count() })
      .from(users)
      .where(and(eq(users.planKey, "free")));

    return ok({
      stats: {
        totalUsers,
        paidUsers,
        freeUsers: Number(freeTier[0]?.total ?? 0),
        activeSubscriptions: activeSubs,
        totalGenerations: Number(genTotals[0]?.total ?? 0),
        mrrCents,
        arrCents: mrrCents * 12,
        conversionRate: totalUsers ? Math.round((paidUsers / totalUsers) * 1000) / 10 : 0,
      },
      popularTools: toolRows.map((r) => ({ tool: r.tool, total: Number(r.total) })),
      usageByDay: dailyRows.map((r) => ({ day: r.day, total: Number(r.total) })),
      plans: planRows,
      recentUsers,
      recentGenerations: recentGens,
    });
  } catch (error) {
    return toErrorResponse(error);
  }
}
