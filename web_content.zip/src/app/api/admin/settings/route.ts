import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { plans } from "@/db/schema";
import { ok, readJson, requireUser, toErrorResponse, fail } from "@/lib/api";
import { getSettings, invalidateSettingsCache, updateSettings, type AppSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  if (auth.user.role !== "admin") return toErrorResponse(new Error("Admins only."));
  try {
    const settings = await getSettings();
    const planRows = await db.select().from(plans).orderBy(asc(plans.sortOrder));
    return ok({ settings, plans: planRows });
  } catch (error) {
    return toErrorResponse(error);
  }
}

type PlanPatch = {
  key: string;
  name?: string;
  tagline?: string;
  priceCents?: number;
  monthlyLimit?: number;
  isActive?: boolean;
  features?: string[];
};

export async function PATCH(request: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  if (auth.user.role !== "admin") return toErrorResponse(new Error("Admins only."));
  try {
    const body = await readJson(request);
    const settingsPatch: Partial<AppSettings> = {};

    if (Array.isArray(body.niches)) {
      const niches = body.niches
        .map((n) => String(n).trim().slice(0, 40))
        .filter(Boolean)
        .slice(0, 40);
      if (!niches.length) return fail("Keep at least one niche available.");
      settingsPatch.niches = Array.from(new Set(niches));
    }
    if (typeof body.freeLimitBonus === "number") {
      settingsPatch.freeLimitBonus = Math.max(0, Math.min(500, Math.round(body.freeLimitBonus)));
    }
    if (typeof body.burstLimitPerMinute === "number") {
      settingsPatch.burstLimitPerMinute = Math.max(1, Math.min(120, Math.round(body.burstLimitPerMinute)));
    }
    if (typeof body.signupEnabled === "boolean") settingsPatch.signupEnabled = body.signupEnabled;
    if (typeof body.announcement === "string") settingsPatch.announcement = body.announcement.slice(0, 200);
    if (typeof body.brandName === "string") settingsPatch.brandName = body.brandName.slice(0, 60) || "Creator Toolkit";
    if (typeof body.features === "object" && body.features) {
      const features: Record<string, boolean> = {};
      for (const [key, value] of Object.entries(body.features as Record<string, unknown>)) {
        features[key.slice(0, 40)] = Boolean(value);
      }
      settingsPatch.features = features;
    }

    const settings = Object.keys(settingsPatch).length ? await updateSettings(settingsPatch) : await getSettings();

    if (Array.isArray(body.plans)) {
      for (const raw of body.plans as PlanPatch[]) {
        if (!raw?.key) continue;
        const patch: Record<string, unknown> = { updatedAt: new Date() };
        if (typeof raw.name === "string" && raw.name.trim()) patch.name = raw.name.trim().slice(0, 80);
        if (typeof raw.tagline === "string") patch.tagline = raw.tagline.slice(0, 160);
        if (typeof raw.priceCents === "number") patch.priceCents = Math.max(0, Math.min(100_000, Math.round(raw.priceCents)));
        if (typeof raw.monthlyLimit === "number") patch.monthlyLimit = Math.max(0, Math.min(100_000, Math.round(raw.monthlyLimit)));
        if (typeof raw.isActive === "boolean") patch.isActive = raw.isActive;
        if (Array.isArray(raw.features)) {
          patch.features = raw.features.map((f) => String(f).slice(0, 120)).filter(Boolean).slice(0, 12);
        }
        await db.update(plans).set(patch).where(eq(plans.key, raw.key));
      }
      invalidateSettingsCache();
    }

    const planRows = await db.select().from(plans).orderBy(asc(plans.sortOrder));
    return ok({ settings, plans: planRows });
  } catch (error) {
    return toErrorResponse(error);
  }
}
