import { NextResponse } from "next/server";
import { handleAssistant, type Lang } from "@/lib/assistant";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      text?: string;
      lang?: string;
      currentSlug?: string | null;
      lastSlugs?: string[];
    };
    const text = (body.text ?? "").toString().slice(0, 500);
    if (!text.trim()) return NextResponse.json({ error: "Empty message" }, { status: 400 });
    const lang: Lang = body.lang === "en" ? "en" : "ar";
    const res = await handleAssistant({
      text,
      lang,
      currentSlug: body.currentSlug ?? null,
      lastSlugs: Array.isArray(body.lastSlugs) ? body.lastSlugs.slice(0, 10) : [],
    });
    return NextResponse.json(res);
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Assistant failed" }, { status: 500 });
  }
}
