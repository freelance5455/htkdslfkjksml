import { asc, count, eq } from "drizzle-orm";
import { db } from "@/db";
import { articles, categories } from "@/db/schema";
import { fail, isUuid, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { logActivity } from "@/lib/notify";
import { slugify } from "@/lib/utils";
import { categorySchema } from "@/lib/validators";

/** Public: list of health categories in display order. */
export async function GET() {
  try {
    const rows = await db
      .select()
      .from(categories)
      .orderBy(asc(categories.sortOrder), asc(categories.slug));
    return ok({ categories: rows });
  } catch (err) {
    return serverError(err);
  }
}

/** Admin: create a category. */
export async function POST(req: Request) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const parsed = await parseBody(req, categorySchema);
  if ("response" in parsed) return parsed.response;
  const d = parsed.data;

  try {
    const slug = d.slug || slugify(d.name.en || d.name.fr) || `category-${Date.now()}`;
    const [clash] = await db.select({ id: categories.id }).from(categories).where(eq(categories.slug, slug)).limit(1);
    if (clash) return fail("slug_taken", 409);
    const [row] = await db
      .insert(categories)
      .values({ slug, name: d.name, sortOrder: d.sortOrder ?? 0 })
      .returning();
    await logActivity(auth.user.id, "category.created", "category", row.id, slug);
    return ok(row, 201);
  } catch (err) {
    return serverError(err);
  }
}

/** Admin: rename or reorder a category (?id=...). The identifier is fixed once created. */
export async function PATCH(req: Request) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const id = new URL(req.url).searchParams.get("id") ?? "";
  if (!isUuid(id)) return fail("not_found", 404);
  const parsed = await parseBody(req, categorySchema.partial());
  if ("response" in parsed) return parsed.response;

  try {
    const set: Partial<typeof categories.$inferInsert> = {};
    if (parsed.data.name !== undefined) set.name = parsed.data.name;
    if (parsed.data.sortOrder !== undefined) set.sortOrder = parsed.data.sortOrder;
    const [row] = await db.update(categories).set(set).where(eq(categories.id, id)).returning();
    if (!row) return fail("not_found", 404);
    await logActivity(auth.user.id, "category.updated", "category", row.id, row.slug);
    return ok(row);
  } catch (err) {
    return serverError(err);
  }
}

/** Admin: delete a category that no article uses. */
export async function DELETE(req: Request) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const id = new URL(req.url).searchParams.get("id") ?? "";
  if (!isUuid(id)) return fail("not_found", 404);

  try {
    const [cat] = await db.select().from(categories).where(eq(categories.id, id)).limit(1);
    if (!cat) return fail("not_found", 404);
    const [{ c }] = await db.select({ c: count() }).from(articles).where(eq(articles.category, cat.slug));
    if (Number(c) > 0) return fail("category_in_use", 409);
    await db.delete(categories).where(eq(categories.id, id));
    await logActivity(auth.user.id, "category.deleted", "category", id, cat.slug);
    return ok({ ok: true });
  } catch (err) {
    return serverError(err);
  }
}
