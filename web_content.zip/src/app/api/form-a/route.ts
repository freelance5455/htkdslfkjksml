import { db } from "@/db";
import { formASubmissions } from "@/db/schema";
import { validateFormA, type FormAInput } from "@/lib/form-a";

export const dynamic = "force-dynamic";

function clean(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

/** Accepts a JSON body matching FormAInput and stores the submission. */
export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "صيغة البيانات غير صحيحة." }, { status: 400 });
  }

  const input: FormAInput = {
    fullName: clean(body.fullName),
    phone: clean(body.phone),
    email: clean(body.email),
    governorate: clean(body.governorate),
    mosqueName: clean(body.mosqueName),
    role: clean(body.role),
    requestType: clean(body.requestType),
    details: clean(body.details),
  };

  const errors = validateFormA(input);
  if (Object.keys(errors).length > 0) {
    return Response.json({ ok: false, errors }, { status: 422 });
  }

  try {
    const [row] = await db
      .insert(formASubmissions)
      .values({
        fullName: input.fullName,
        phone: input.phone,
        email: input.email || null,
        governorate: input.governorate,
        mosqueName: input.mosqueName || null,
        role: input.role,
        requestType: input.requestType,
        details: input.details,
      })
      .returning({ id: formASubmissions.id });

    return Response.json({ ok: true, id: row.id }, { status: 201 });
  } catch {
    return Response.json(
      { ok: false, error: "تعذّر حفظ النموذج الآن. حاول مرة أخرى بعد قليل." },
      { status: 500 },
    );
  }
}
