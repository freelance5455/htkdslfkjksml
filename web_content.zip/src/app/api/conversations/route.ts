import { db } from "@/db";
import { conversations, type StoredMessage } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const allowedTools = new Set(["chat", "write", "summary", "translate", "code", "study", "ideas"]);
const validUUID = (value: unknown): value is string => typeof value === "string" && uuidPattern.test(value);

export async function GET(request: NextRequest) {
  const ownerId = request.nextUrl.searchParams.get("ownerId");
  if (!validUUID(ownerId)) return NextResponse.json({ error: "Identificador no válido." }, { status: 400 });
  try {
    const rows = await db.select().from(conversations).where(eq(conversations.ownerId, ownerId)).orderBy(desc(conversations.updatedAt)).limit(70);
    return NextResponse.json({ sessions: rows.map(row => ({
      id: row.id, title: row.title, tool: row.tool, messages: row.messages,
      prompt: row.prompt, option: row.option, favorite: row.favorite,
      createdAt: row.createdAt.toISOString(), updatedAt: row.updatedAt.toISOString(),
    })) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("History read failed:", error);
    return NextResponse.json({ error: "No se pudo cargar el historial." }, { status: 503 });
  }
}

export async function POST(request: NextRequest) {
  let body: Record<string, unknown>;
  try { body = await request.json(); }
  catch { return NextResponse.json({ error: "Solicitud no válida." }, { status: 400 }); }

  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Solicitud no válida." }, { status: 400 });
  }
  const ownerId = body.ownerId;
  const session = body.session;
  if (!validUUID(ownerId) || !session || typeof session !== "object") {
    return NextResponse.json({ error: "Identificador o conversación no válidos." }, { status: 400 });
  }
  const item = session as Record<string, unknown>;
  if (!validUUID(item.id) || typeof item.title !== "string" || item.title.length > 180 ||
      typeof item.tool !== "string" || !allowedTools.has(item.tool) ||
      !Array.isArray(item.messages) || item.messages.length > 100 ||
      (item.prompt !== undefined && item.prompt !== null && (typeof item.prompt !== "string" || item.prompt.length > 9000)) ||
      (item.option !== undefined && item.option !== null && (typeof item.option !== "string" || item.option.length > 80))) {
    return NextResponse.json({ error: "Los datos de la conversación no son válidos." }, { status: 400 });
  }

  let totalSize = 0;
  const messages: StoredMessage[] = [];
  for (const message of item.messages) {
    if (!message || typeof message !== "object" ||
        (message.role !== "user" && message.role !== "assistant") ||
        typeof message.content !== "string" || message.content.length > 35000 ||
        (message.attachmentText !== undefined && (typeof message.attachmentText !== "string" || message.attachmentText.length > 14000))) {
      return NextResponse.json({ error: "Un mensaje contiene datos no válidos." }, { status: 400 });
    }
    totalSize += message.content.length + (message.attachmentText?.length || 0);
    messages.push({ role: message.role, content: message.content,
      ...(typeof message.attachmentName === "string" ? { attachmentName: message.attachmentName.slice(0, 80) } : {}),
      ...(typeof message.attachmentText === "string" ? { attachmentText: message.attachmentText } : {}),
    });
  }
  if (totalSize > 200000) return NextResponse.json({ error: "La conversación es demasiado larga." }, { status: 400 });

  try {
    const result = await db.insert(conversations).values({
      id: item.id, ownerId, title: item.title || "Sin título", tool: item.tool,
      messages, prompt: typeof item.prompt === "string" ? item.prompt : null,
      option: typeof item.option === "string" ? item.option : null,
      favorite: item.favorite === true, updatedAt: new Date(),
    }).onConflictDoUpdate({
      target: conversations.id,
      set: { title: item.title || "Sin título", tool: item.tool, messages,
        prompt: typeof item.prompt === "string" ? item.prompt : null,
        option: typeof item.option === "string" ? item.option : null,
        favorite: item.favorite === true, updatedAt: new Date() },
      setWhere: eq(conversations.ownerId, ownerId),
    }).returning({ id: conversations.id });
    if (!result.length) return NextResponse.json({ error: "No se puede modificar esta conversación." }, { status: 403 });
    return NextResponse.json({ ok: true, id: result[0].id });
  } catch (error) {
    console.error("History write failed:", error);
    return NextResponse.json({ error: "No se pudo guardar la conversación." }, { status: 503 });
  }
}

export async function DELETE(request: NextRequest) {
  const ownerId = request.nextUrl.searchParams.get("ownerId");
  const id = request.nextUrl.searchParams.get("id");
  if (!validUUID(ownerId) || !validUUID(id)) {
    return NextResponse.json({ error: "Identificador no válido." }, { status: 400 });
  }
  try {
    await db.delete(conversations).where(and(eq(conversations.ownerId, ownerId), eq(conversations.id, id)));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("History delete failed:", error);
    return NextResponse.json({ error: "No se pudo borrar la conversación." }, { status: 503 });
  }
}
