import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

/**
 * פרוקסי אחיד לכל בקשות ה-REST של השוק - מנטרל חסימות CORS במכשירים ובדפדפן.
 * שימוש: /api/market-proxy?url=https://api.bybit.com/v5/market/tickers?category=linear
 */
const ALLOWED_HOSTS = [
  "api.bybit.com",
  "api.bytick.com",
  "api.binance.com",
  "data-api.binance.vision",
  "api.mexc.com",
  "api.coingecko.com",
  "api.alternative.me",
  "api.frankfurter.app",
];

const CORS_HEADERS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,OPTIONS",
  "access-control-allow-headers": "content-type",
};

export function OPTIONS() {
  return new Response(null, { status: 204, headers: CORS_HEADERS });
}

export async function GET(req: NextRequest) {
  const target = req.nextUrl.searchParams.get("url");
  if (!target) {
    return Response.json(
      { ok: false, error: "חסר פרמטר url" },
      { status: 400, headers: CORS_HEADERS },
    );
  }
  let parsed: URL;
  try {
    parsed = new URL(target);
  } catch {
    return Response.json({ ok: false, error: "כתובת לא תקינה" }, { status: 400, headers: CORS_HEADERS });
  }
  if (!ALLOWED_HOSTS.includes(parsed.hostname)) {
    return Response.json(
      { ok: false, error: `דומיין חסום: ${parsed.hostname}` },
      { status: 403, headers: CORS_HEADERS },
    );
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 9000);
  const started = Date.now();
  try {
    const upstream = await fetch(parsed.toString(), {
      signal: controller.signal,
      cache: "no-store",
      headers: { accept: "application/json" },
    });
    const body = await upstream.text();
    return new Response(body, {
      status: upstream.status,
      headers: {
        ...CORS_HEADERS,
        "content-type": upstream.headers.get("content-type") ?? "application/json",
        "x-proxy-latency": String(Date.now() - started),
      },
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "שגיאת פרוקסי" },
      { status: 502, headers: CORS_HEADERS },
    );
  } finally {
    clearTimeout(timer);
  }
}
