import { and, asc, desc, eq, ilike, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { professionals, users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { VERIFICATION_STATUSES } from "@/lib/constants";
import { fail, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { toProfessional } from "@/lib/mappers";
import { getProfessionalByUserId, loadProfessional, professionalSet } from "@/lib/queries";
import { professionalSelfSchema } from "@/lib/validators";

/** Public list of verified professionals. Admins (?all=1) can see every status. Professionals can fetch their own profile with ?me=1. */
export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    if (url.searchParams.get("me") === "1") {
      const auth = await requireUser(["professional"]);
      if ("response" in auth) return auth.response;
      const pro = await getProfessionalByUserId(auth.user.id);
      if (!pro) return fail("not_found", 404);
      return ok({
        professional: toProfessional(
          pro,
          { fullName: auth.user.fullName, city: auth.user.city, email: auth.user.email, phone: auth.user.phone },
          true,
        ),
      });
    }

    const city = url.searchParams.get("city");
    const service = url.searchParams.get("service");
    const q = url.searchParams.get("q")?.trim();
    const status = url.searchParams.get("status");
    const all = url.searchParams.get("all") === "1";
    const user = await getSessionUser();
    const adminView = all && user?.role === "admin";

    const conds: SQL[] = [];
    if (!adminView) conds.push(eq(professionals.verificationStatus, "verified"));
    else if (status && (VERIFICATION_STATUSES as readonly string[]).includes(status)) {
      conds.push(eq(professionals.verificationStatus, status));
    }
    if (service) conds.push(sql`${professionals.serviceCodes} @> ${JSON.stringify([service])}::jsonb`);
    if (city) conds.push(sql`${professionals.serviceCities} @> ${JSON.stringify([city])}::jsonb`);
    if (q) conds.push(ilike(users.fullName, `%${q.replace(/[%_]/g, "\\$&")}%`));

    const rows = await db
      .select({
        pro: professionals,
        user: { fullName: users.fullName, city: users.city, email: users.email, phone: users.phone },
      })
      .from(professionals)
      .innerJoin(users, eq(users.id, professionals.userId))
      .where(and(...conds))
      .orderBy(desc(professionals.ratingAvg), asc(users.fullName));

    return ok({ professionals: rows.map((r) => toProfessional(r.pro, r.user, adminView)) });
  } catch (err) {
    return serverError(err);
  }
}

/** Professionals update their own profile (bio, services, areas, availability). Verification is admin-only. */
export async function PATCH(req: Request) {
  const auth = await requireUser(["professional"]);
  if ("response" in auth) return auth.response;
  const parsed = await parseBody(req, professionalSelfSchema);
  if ("response" in parsed) return parsed.response;

  try {
    const pro = await getProfessionalByUserId(auth.user.id);
    if (!pro) return fail("not_found", 404);
    const set = professionalSet({ ...parsed.data, verificationStatus: undefined });
    if (Object.keys(set).length > 0) {
      await db.update(professionals).set(set).where(eq(professionals.id, pro.id));
    }
    const row = await loadProfessional(pro.id);
    if (!row) return fail("not_found", 404);
    return ok({ professional: toProfessional(row.pro, row.user, true) });
  } catch (err) {
    return serverError(err);
  }
}
