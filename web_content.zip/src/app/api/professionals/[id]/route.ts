import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { professionals, reviews, users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { fail, isUuid, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { toProfessional } from "@/lib/mappers";
import { loadProfessional, patientUsers, professionalSet } from "@/lib/queries";
import { L, logActivity, notify } from "@/lib/notify";
import { professionalAdminSchema } from "@/lib/validators";
import { publicName } from "@/lib/utils";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    if (!isUuid(id)) return fail("not_found", 404);
    const row = await loadProfessional(id);
    if (!row) return fail("not_found", 404);

    const viewer = await getSessionUser();
    const isStaff = viewer?.role === "admin";
    if (row.pro.verificationStatus !== "verified" && !isStaff) return fail("not_found", 404);

    const reviewRows = await db
      .select({
        id: reviews.id,
        rating: reviews.rating,
        comment: reviews.comment,
        createdAt: reviews.createdAt,
        patientName: patientUsers.fullName,
      })
      .from(reviews)
      .innerJoin(patientUsers, eq(patientUsers.id, reviews.patientId))
      .where(eq(reviews.professionalId, id))
      .orderBy(desc(reviews.createdAt))
      .limit(20);

    return ok({
      professional: toProfessional(row.pro, row.user, isStaff),
      reviews: reviewRows.map((r) => ({ ...r, patientName: publicName(r.patientName) })),
    });
  } catch (err) {
    return serverError(err);
  }
}

/** Admin: verify / reject / edit any professional profile. */
export async function PATCH(req: Request, ctx: Ctx) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const { id } = await ctx.params;
  if (!isUuid(id)) return fail("not_found", 404);
  const parsed = await parseBody(req, professionalAdminSchema);
  if ("response" in parsed) return parsed.response;

  try {
    const before = await loadProfessional(id);
    if (!before) return fail("not_found", 404);

    const set = professionalSet(parsed.data);
    if (Object.keys(set).length > 0) {
      await db.update(professionals).set(set).where(eq(professionals.id, id));
    }
    const row = await loadProfessional(id);
    if (!row) return fail("not_found", 404);

    const statusChanged = parsed.data.verificationStatus && parsed.data.verificationStatus !== before.pro.verificationStatus;
    if (statusChanged) {
      const status = row.pro.verificationStatus;
      const [owner] = await db.select({ id: users.id }).from(users).where(eq(users.id, row.pro.userId)).limit(1);
      if (owner) {
        const messages = {
          verified: L("Profil vérifié", "Profile verified", "تم اعتماد ملفك"),
          rejected: L("Vérification non approuvée", "Verification not approved", "لم تتم الموافقة على التحقق"),
          pending: L("Vérification en attente", "Verification pending", "التحقق قيد الانتظار"),
        } as const;
        const body = {
          verified: L(
            "Votre autorisation d'exercice a été vérifiée. Vous pouvez désormais recevoir des visites.",
            "Your licence has been verified. You can now receive visits.",
            "تم التحقق من ترخيص مزاولتك. يمكنك الآن استقبال الزيارات.",
          ),
          rejected: L(
            "Votre dossier n'a pas été approuvé. Consultez votre profil pour plus d'informations.",
            "Your application was not approved. Check your profile for details.",
            "لم يتم اعتماد ملفك. راجع ملفك الشخصي لمزيد من المعلومات.",
          ),
          pending: L("Votre dossier est de nouveau en cours de vérification.", "Your application is back under review.", "ملفك عاد إلى المراجعة."),
        } as const;
        const key = status as keyof typeof messages;
        if (key in messages) await notify(owner.id, messages[key], body[key], "/profile");
      }
    }
    await logActivity(auth.user.id, "professional.updated", "professional", id, JSON.stringify(parsed.data));
    return ok({ professional: toProfessional(row.pro, row.user, true) });
  } catch (err) {
    return serverError(err);
  }
}
