import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { contentCalendars } from "@/db/schema";
import { fail, ok, readJson, requireUser, toErrorResponse } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const rows = await db
      .select()
      .from(contentCalendars)
      .where(eq(contentCalendars.userId, auth.user.id))
      .orderBy(desc(contentCalendars.createdAt))
      .limit(50);
    return ok({ calendars: rows });
  } catch (error) {
    return toErrorResponse(error);
  }
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const body = await readJson(request);
    const name = String(body.name ?? "").trim().slice(0, 160) || "Untitled plan";
    const planLength = Math.min(90, Math.max(1, Number(body.planLength ?? 7)));
    const rawDays = Array.isArray(body.days) ? body.days : [];
    const days = rawDays
      .map((d, i) => {
        const day = (d ?? {}) as Record<string, unknown>;
        return {
          day: Number(day.day) || i + 1,
          topic: String(day.topic ?? "").slice(0, 200),
          platform: String(day.platform ?? "").slice(0, 40),
          contentType: String(day.contentType ?? "").slice(0, 60),
          postTime: String(day.postTime ?? "").slice(0, 30),
        };
      })
      .filter((d) => d.topic)
      .slice(0, planLength);
    if (!days.length) return fail("Nothing to save yet — generate a plan first.");

    const [created] = await db
      .insert(contentCalendars)
      .values({ userId: auth.user.id, name, planLength: days.length, days })
      .returning();
    return ok({ calendar: created });
  } catch (error) {
    return toErrorResponse(error);
  }
}

export async function DELETE(request: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const body = await readJson(request);
    const id = Number(body.id);
    if (!Number.isFinite(id)) return fail("Invalid plan.");
    await db
      .delete(contentCalendars)
      .where(and(eq(contentCalendars.id, id), eq(contentCalendars.userId, auth.user.id)));
    return ok({});
  } catch (error) {
    return toErrorResponse(error);
  }
}
