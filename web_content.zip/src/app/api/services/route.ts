import { and, asc, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { professionals, services } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { fail, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { logActivity } from "@/lib/notify";
import { slugify } from "@/lib/utils";
import { serviceSchema } from "@/lib/validators";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const q = url.searchParams.get("q")?.trim();
    const category = url.searchParams.get("category");
    const city = url.searchParams.get("city");
    const includeAll = url.searchParams.get("all") === "1";
    const user = await getSessionUser();
    const adminView = includeAll && user?.role === "admin";

    const conds: SQL[] = [];
    if (!adminView) conds.push(eq(services.isActive, true));
    if (category) conds.push(eq(services.category, category));
    if (q) {
      const pattern = `%${q.replace(/[%_]/g, "\\$&")}%`;
      conds.push(or(ilike(sql`${services.name}::text`, pattern), ilike(sql`${services.description}::text`, pattern))!);
    }

    const rows = await db
      .select()
      .from(services)
      .where(conds.length ? and(...conds) : undefined)
      .orderBy(asc(services.sortOrder), asc(services.priceMad));

    const pros = await db
      .select({ codes: professionals.serviceCodes, cities: professionals.serviceCities })
      .from(professionals)
      .where(eq(professionals.verificationStatus, "verified"));

    const withCounts = rows.map((s) => ({
      ...s,
      proCount: pros.filter((p) => p.codes.includes(s.slug)).length,
      proInCity: city ? pros.filter((p) => p.codes.includes(s.slug) && p.cities.includes(city)).length : null,
    }));
    return ok({ services: withCounts });
  } catch (err) {
    return serverError(err);
  }
}

export async function POST(req: Request) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const parsed = await parseBody(req, serviceSchema);
  if ("response" in parsed) return parsed.response;
  const d = parsed.data;

  try {
    const slug = d.slug || slugify(d.name.en || d.name.fr);
    const [clash] = await db.select({ id: services.id }).from(services).where(eq(services.slug, slug)).limit(1);
    if (clash) return fail("slug_taken", 409);
    const [row] = await db
      .insert(services)
      .values({
        slug,
        category: d.category,
        name: d.name,
        description: d.description,
        priceMad: d.priceMad,
        durationMinutes: d.durationMinutes,
        requiresVerifiedPro: d.requiresVerifiedPro,
        icon: d.icon || "stethoscope",
        isFeatured: d.isFeatured,
        isActive: d.isActive,
        sortOrder: d.sortOrder ?? 0,
      })
      .returning();
    await logActivity(auth.user.id, "service.created", "service", row.id, slug);
    return ok(row, 201);
  } catch (err) {
    return serverError(err);
  }
}
