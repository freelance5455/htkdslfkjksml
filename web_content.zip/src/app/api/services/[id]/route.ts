import { count, eq, or } from "drizzle-orm";
import { db } from "@/db";
import { appointments, services } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { fail, isUuid, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { logActivity } from "@/lib/notify";
import { serviceSchema } from "@/lib/validators";

type Ctx = { params: Promise<{ id: string }> };

function matcher(key: string) {
  return isUuid(key) ? or(eq(services.id, key), eq(services.slug, key))! : eq(services.slug, key);
}

export async function GET(_req: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const [row] = await db.select().from(services).where(matcher(id)).limit(1);
    if (!row) return fail("not_found", 404);
    if (!row.isActive) {
      const user = await getSessionUser();
      if (user?.role !== "admin") return fail("not_found", 404);
    }
    return ok(row);
  } catch (err) {
    return serverError(err);
  }
}

export async function PATCH(req: Request, ctx: Ctx) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const { id } = await ctx.params;
  const parsed = await parseBody(req, serviceSchema.partial());
  if ("response" in parsed) return parsed.response;
  const d = parsed.data;

  try {
    const set: Partial<typeof services.$inferInsert> = { updatedAt: new Date() };
    if (d.slug !== undefined) set.slug = d.slug;
    if (d.category !== undefined) set.category = d.category;
    if (d.name !== undefined) set.name = d.name;
    if (d.description !== undefined) set.description = d.description;
    if (d.priceMad !== undefined) set.priceMad = d.priceMad;
    if (d.durationMinutes !== undefined) set.durationMinutes = d.durationMinutes;
    if (d.requiresVerifiedPro !== undefined) set.requiresVerifiedPro = d.requiresVerifiedPro;
    if (d.icon !== undefined) set.icon = d.icon;
    if (d.isFeatured !== undefined) set.isFeatured = d.isFeatured;
    if (d.isActive !== undefined) set.isActive = d.isActive;
    if (d.sortOrder !== undefined) set.sortOrder = d.sortOrder;

    const [row] = await db.update(services).set(set).where(matcher(id)).returning();
    if (!row) return fail("not_found", 404);
    await logActivity(auth.user.id, "service.updated", "service", row.id, row.slug);
    return ok(row);
  } catch (err) {
    if (typeof err === "object" && err && "code" in err && err.code === "23505") return fail("slug_taken", 409);
    return serverError(err);
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const { id } = await ctx.params;
  try {
    const [svc] = await db.select().from(services).where(matcher(id)).limit(1);
    if (!svc) return fail("not_found", 404);

    const [{ c }] = await db.select({ c: count() }).from(appointments).where(eq(appointments.serviceId, svc.id));
    if (Number(c) > 0) {
      // Keep booking history intact: archive instead of deleting.
      await db.update(services).set({ isActive: false, updatedAt: new Date() }).where(eq(services.id, svc.id));
      await logActivity(auth.user.id, "service.archived", "service", svc.id, svc.slug);
      return ok({ ok: true, archived: true });
    }
    await db.delete(services).where(eq(services.id, svc.id));
    await logActivity(auth.user.id, "service.deleted", "service", svc.id, svc.slug);
    return ok({ ok: true, archived: false });
  } catch (err) {
    return serverError(err);
  }
}
