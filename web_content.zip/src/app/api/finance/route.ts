import { NextRequest } from "next/server";
import { db } from "@/db";
import { invoices, paperPositions } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { getTickers, getUsdIlsRate } from "@/lib/market";
import { positionPnl } from "@/server/engine";
import { USER_KEY, ensureSeed } from "@/server/store";

export const dynamic = "force-dynamic";

const VAT_PCT = 18;
const CAPITAL_GAINS_TAX = 25; // מס רווחי הון ליחיד
const BUSINESS_TAX_EST = 47; // מס שולי מקסימלי לעוסק/הכנסה מעסק

export async function GET() {
  try {
    await ensureSeed();
    const rate = await getUsdIlsRate();
    const tickers = await getTickers();

    const closed = await db
      .select()
      .from(paperPositions)
      .where(and(eq(paperPositions.userKey, USER_KEY), eq(paperPositions.status, "CLOSED")))
      .orderBy(desc(paperPositions.closedAt))
      .limit(200);
    const open = await db
      .select()
      .from(paperPositions)
      .where(and(eq(paperPositions.userKey, USER_KEY), eq(paperPositions.status, "OPEN")));

    const ledger = closed.map((p) => ({
      id: p.id,
      symbol: p.symbol,
      side: p.side,
      qty: p.qty,
      entryPrice: p.entryPrice,
      exitPrice: p.exitPrice ?? 0,
      realizedPnl: p.realizedPnl ?? 0,
      realizedPnlIls: (p.realizedPnl ?? 0) * rate,
      closeReason: p.closeReason ?? "",
      openedAt: p.openedAt,
      closedAt: p.closedAt,
    }));
    const unrealizedRows = open.map((p) => {
      const mark = tickers.data.find((t) => t.symbol === p.symbol)?.price ?? p.entryPrice;
      const pnl = positionPnl(p.side, p.entryPrice, mark, p.qty);
      return { id: p.id, symbol: p.symbol, side: p.side, qty: p.qty, entryPrice: p.entryPrice, markPrice: mark, unrealizedPnl: pnl };
    });

    const realizedTotal = ledger.reduce((s, r) => s + r.realizedPnl, 0);
    const realizedGains = ledger.filter((r) => r.realizedPnl > 0).reduce((s, r) => s + r.realizedPnl, 0);
    const realizedLosses = Math.abs(ledger.filter((r) => r.realizedPnl < 0).reduce((s, r) => s + r.realizedPnl, 0));
    const unrealizedTotal = unrealizedRows.reduce((s, r) => s + r.unrealizedPnl, 0);
    const taxableBase = Math.max(0, realizedTotal);

    const invoiceRows = await db
      .select()
      .from(invoices)
      .where(eq(invoices.userKey, USER_KEY))
      .orderBy(desc(invoices.issuedAt))
      .limit(100);
    const invoicedIls = invoiceRows.reduce((s, i) => s + i.totalIls, 0);
    const vatCollected = invoiceRows.reduce((s, i) => s + (i.totalIls - i.amountIls), 0);

    return Response.json({
      ok: true,
      usdIlsRate: rate,
      ledger,
      unrealized: unrealizedRows,
      invoices: invoiceRows,
      summary: {
        realizedTotal,
        realizedTotalIls: realizedTotal * rate,
        realizedGains,
        realizedLosses,
        unrealizedTotal,
        unrealizedTotalIls: unrealizedTotal * rate,
        tradesCount: ledger.length,
        openCount: unrealizedRows.length,
        invoicedIls,
        vatCollected,
      },
      tax: {
        capitalGainsPct: CAPITAL_GAINS_TAX,
        businessTaxPct: BUSINESS_TAX_EST,
        vatPct: VAT_PCT,
        taxableBaseUsd: taxableBase,
        taxableBaseIls: taxableBase * rate,
        capitalGainsDueIls: taxableBase * rate * (CAPITAL_GAINS_TAX / 100),
        businessIncomeDueIls: taxableBase * rate * (BUSINESS_TAX_EST / 100),
        form909Required: taxableBase > 0,
        notes: [
          "רווח הון ממכירת מטבעות דיגיטליים חייב במס בשיעור 25% ליחיד (רווח ריאלי).",
          "סוחר בהיקף עסקי מסווג כהכנסה מעסק לפי סעיף 2(1) וממוסה במס שולי + ביטוח לאומי.",
          "יש לדווח על כל עסקה בטופס 1399 / נספח ג' ולהעביר מקדמות תוך 30 יום מתום חצי השנה.",
          "טופס 909 - דיווח ניכוי מס במקור עבור תשלומים לספקים בתשלומי קריפטו.",
          "מע\"מ בשיעור 18% חל על מתן שירותים בתשלום קריפטו לעוסק מורשה בישראל.",
        ],
      },
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "שגיאה בטעינת נתונים פיננסיים" },
      { status: 500 },
    );
  }
}

type InvoiceBody = {
  clientName?: string;
  clientTaxId?: string;
  description?: string;
  amountUsdt?: number;
  vatPct?: number;
};

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as InvoiceBody;
    const amountUsdt = Number(body.amountUsdt ?? 0);
    if (!body.clientName || amountUsdt <= 0) {
      return Response.json({ ok: false, error: "נדרש שם לקוח וסכום גדול מאפס" }, { status: 400 });
    }
    const rate = await getUsdIlsRate();
    const amountIls = amountUsdt * rate;
    const vatPct = Number(body.vatPct ?? VAT_PCT);
    const totalIls = amountIls * (1 + vatPct / 100);
    const count = await db.select().from(invoices).where(eq(invoices.userKey, USER_KEY));
    const inserted = await db
      .insert(invoices)
      .values({
        userKey: USER_KEY,
        invoiceNumber: `INV-${new Date().getFullYear()}-${String(count.length + 1).padStart(4, "0")}`,
        clientName: String(body.clientName),
        clientTaxId: String(body.clientTaxId ?? ""),
        description: String(body.description ?? "שירותי מסחר וייעוץ"),
        amountUsdt,
        usdIlsRate: rate,
        amountIls,
        vatPct,
        totalIls,
        status: "ISSUED",
      })
      .returning();
    return Response.json({ ok: true, message: "החשבונית הופקה בהצלחה", invoice: inserted[0] });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "שגיאה בהפקת חשבונית" },
      { status: 500 },
    );
  }
}
