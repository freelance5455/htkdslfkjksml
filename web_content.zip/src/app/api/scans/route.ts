import crypto from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createScan, listScans } from "@/lib/db";
import { enqueueScanJob } from "@/lib/queue/scan-worker";
import { checkRateLimit } from "@/lib/security/rate-limit";
import { assertPublicTarget, SSRFError } from "@/lib/security/ssrf";
import type { ScanConfig, ScanRecord } from "@/types/xray";

const createScanSchema = z.object({
  url: z.string().min(1, "URL is required").max(2048),
  maxPages: z.number().int().min(1).max(20).optional(),
  maxDepth: z.number().int().min(0).max(4).optional(),
  maxInteractionsPerPage: z.number().int().min(1).max(50).optional(),
  includeMobile: z.boolean().optional(),
  respectRobotsTxt: z.boolean().optional(),
});

export async function GET() {
  try {
    const scans = listScans(40);
    return NextResponse.json({ scans });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to list scans" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const clientIp =
      request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      request.headers.get("x-real-ip") ||
      "local-client";

    const rate = checkRateLimit(clientIp);
    if (!rate.allowed) {
      return NextResponse.json(
        {
          error: `Rate limit exceeded. Try again in ${rate.retryAfterSeconds} seconds.`,
        },
        { status: 429 }
      );
    }

    const body = await request.json().catch(() => null);
    const parsed = createScanSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message || "Invalid request payload" },
        { status: 400 }
      );
    }

    const normalizedUrl = await assertPublicTarget(parsed.data.url);

    const config: ScanConfig = {
      maxPages: parsed.data.maxPages ?? Number(process.env.SCAN_MAX_PAGES ?? 8),
      maxDepth: parsed.data.maxDepth ?? Number(process.env.SCAN_MAX_DEPTH ?? 2),
      maxInteractionsPerPage:
        parsed.data.maxInteractionsPerPage ??
        Number(process.env.SCAN_MAX_INTERACTIONS_PER_PAGE ?? 25),
      includeMobile: parsed.data.includeMobile ?? true,
      respectRobotsTxt: parsed.data.respectRobotsTxt ?? true,
    };

    const now = new Date().toISOString();
    const scanId = crypto.randomUUID();
    const scan: ScanRecord = {
      id: scanId,
      targetUrl: parsed.data.url.trim(),
      normalizedUrl: normalizedUrl.toString(),
      domain: normalizedUrl.hostname,
      status: "queued",
      progressPercent: 0,
      currentPage: normalizedUrl.toString(),
      pagesDiscovered: 1,
      pagesAnalyzed: 0,
      buttonsTested: 0,
      interactionsPassed: 0,
      interactionsFailed: 0,
      interactionsBlocked: 0,
      errorMessage: null,
      config,
      logs: [
        {
          timestamp: now,
          level: "info",
          message: `Scan queued for ${normalizedUrl.toString()} (max ${config.maxPages} pages, depth ${config.maxDepth}).`,
        },
      ],
      createdAt: now,
      updatedAt: now,
      completedAt: null,
    };

    createScan(scan);
    enqueueScanJob(scanId, normalizedUrl.toString(), config);

    return NextResponse.json({ scan }, { status: 201 });
  } catch (err) {
    if (err instanceof SSRFError) {
      return NextResponse.json({ error: err.message }, { status: 400 });
    }
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to start scan" },
      { status: 500 }
    );
  }
}
