import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getFullScanDetails, savePrompt } from "@/lib/db";
import { generateMasterPrompt } from "@/lib/ai/prompt-generator";

const refineSchema = z.object({
  instruction: z.string().max(1500).optional(),
});

export async function POST(
  request: NextRequest,
  context: { params: { id: string } }
) {
  try {
    const details = getFullScanDetails(context.params.id);
    if (!details) {
      return NextResponse.json({ error: "Scan not found" }, { status: 404 });
    }
    if (!details.report || details.pages.length === 0) {
      return NextResponse.json(
        { error: "Scan must complete page inspection and analysis before refining the prompt." },
        { status: 400 }
      );
    }

    const body = await request.json().catch(() => ({}));
    const parsed = refineSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid refinement instruction" }, { status: 400 });
    }

    const latestPrompt = details.prompts[0] ?? null;
    const nextVersion = (latestPrompt?.version ?? 0) + 1;

    const newPrompt = await generateMasterPrompt({
      scanId: details.scan.id,
      version: nextVersion,
      targetUrl: details.scan.normalizedUrl,
      pages: details.pages,
      interactions: details.interactions,
      report: details.report,
      refinementInstruction: parsed.data.instruction?.trim() || null,
      previousPrompt: latestPrompt?.promptText ?? null,
    });

    savePrompt(newPrompt);
    return NextResponse.json({ prompt: newPrompt });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to refine master prompt" },
      { status: 500 }
    );
  }
}
