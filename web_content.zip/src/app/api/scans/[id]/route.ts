import fs from "node:fs";
import path from "node:path";
import { NextRequest, NextResponse } from "next/server";
import { deleteScan, getFullScanDetails, getScreenshotsRoot } from "@/lib/db";

export async function GET(
  _request: NextRequest,
  context: { params: { id: string } }
) {
  try {
    const details = getFullScanDetails(context.params.id);
    if (!details) {
      return NextResponse.json({ error: "Scan not found" }, { status: 404 });
    }
    return NextResponse.json(details);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to load scan" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _request: NextRequest,
  context: { params: { id: string } }
) {
  try {
    const scanId = context.params.id;
    const deleted = deleteScan(scanId);
    if (!deleted) {
      return NextResponse.json({ error: "Scan not found" }, { status: 404 });
    }

    const screenshotsDir = path.join(getScreenshotsRoot(), path.basename(scanId));
    if (fs.existsSync(screenshotsDir)) {
      fs.rmSync(screenshotsDir, { recursive: true, force: true });
    }

    return NextResponse.json({ deleted: true });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to delete scan" },
      { status: 500 }
    );
  }
}
