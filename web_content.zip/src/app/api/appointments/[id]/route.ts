import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appointments, professionals, services } from "@/db/schema";
import { fail, isUuid, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { L, logActivity, notify } from "@/lib/notify";
import { appointmentBaseQuery, getProfessionalByUserId, mapAppointment } from "@/lib/queries";
import { appointmentActionSchema } from "@/lib/validators";
import type { CurrentUser } from "@/lib/types";

type Ctx = { params: Promise<{ id: string }> };

async function loadAccess(user: CurrentUser, patientId: string | null, assignedProId: string | null) {
  const pro = user.role === "professional" ? await getProfessionalByUserId(user.id) : null;
  return {
    isAdmin: user.role === "admin",
    isOwner: user.id === patientId,
    isAssigned: !!pro && pro.id === assignedProId,
  };
}

export async function GET(_req: Request, ctx: Ctx) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await ctx.params;
  if (!isUuid(id)) return fail("not_found", 404);
  try {
    const [row] = await appointmentBaseQuery().where(eq(appointments.id, id)).limit(1);
    if (!row) return fail("not_found", 404);
    const access = await loadAccess(auth.user, row.appt.patientId, row.appt.professionalId);
    if (!access.isAdmin && !access.isOwner && !access.isAssigned) return fail("forbidden", 403);
    return ok(mapAppointment(row));
  } catch (err) {
    return serverError(err);
  }
}

/**
 * Status transitions:
 * - cancel: patient (owner), assigned professional or admin, while pending/confirmed
 * - confirm: assigned professional or admin, from pending
 * - complete: assigned professional or admin, from confirmed
 * - assign: admin only, sets or clears the professional (must be verified and cover service + city)
 */
export async function PATCH(req: Request, ctx: Ctx) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await ctx.params;
  if (!isUuid(id)) return fail("not_found", 404);
  const parsed = await parseBody(req, appointmentActionSchema);
  if ("response" in parsed) return parsed.response;
  const { action, reason, professionalId } = parsed.data;

  try {
    const [appt] = await db.select().from(appointments).where(eq(appointments.id, id)).limit(1);
    if (!appt) return fail("not_found", 404);
    const [svc] = await db.select().from(services).where(eq(services.id, appt.serviceId)).limit(1);
    if (!svc) return fail("not_found", 404);

    const access = await loadAccess(auth.user, appt.patientId, appt.professionalId);
    const patch: Partial<typeof appointments.$inferInsert> = { updatedAt: new Date() };
    let newProUserId: string | null = null;

    switch (action) {
      case "cancel":
        if (!access.isAdmin && !access.isOwner && !access.isAssigned) return fail("forbidden", 403);
        if (appt.status !== "pending" && appt.status !== "confirmed") return fail("cannot_cancel", 409);
        patch.status = "cancelled";
        patch.cancelReason = reason ?? "";
        break;
      case "confirm":
        if (!access.isAdmin && !access.isAssigned) return fail("forbidden", 403);
        if (appt.status !== "pending") return fail("invalid_status", 409);
        patch.status = "confirmed";
        break;
      case "complete":
        if (!access.isAdmin && !access.isAssigned) return fail("forbidden", 403);
        if (appt.status !== "confirmed") return fail("invalid_status", 409);
        patch.status = "completed";
        break;
      case "assign": {
        if (!access.isAdmin) return fail("forbidden", 403);
        if (professionalId) {
          const [target] = await db.select().from(professionals).where(eq(professionals.id, professionalId)).limit(1);
          const covers = target?.serviceCodes.includes(svc.slug) && target?.serviceCities.includes(appt.city);
          if (!target || target.verificationStatus !== "verified" || !covers) {
            return fail("professional_not_available", 422);
          }
          patch.professionalId = target.id;
          newProUserId = target.userId;
        } else {
          patch.professionalId = null;
        }
        break;
      }
    }

    await db.update(appointments).set(patch).where(eq(appointments.id, id));

    const assignedProUserId = appt.professionalId
      ? (await db.select({ userId: professionals.userId }).from(professionals).where(eq(professionals.id, appt.professionalId)).limit(1))[0]?.userId
      : undefined;

    if (action === "confirm") {
      await notify(
        appt.patientId,
        L("Visite confirmée", "Visit confirmed", "تم تأكيد الزيارة"),
        L(`Votre visite ${appt.reference} est confirmée.`, `Your visit ${appt.reference} is confirmed.`, `تم تأكيد زيارتك ${appt.reference}.`),
        "/appointments",
      );
    } else if (action === "complete") {
      await notify(
        appt.patientId,
        L("Visite terminée", "Visit completed", "اكتملت الزيارة"),
        L("Merci de laisser un avis sur votre visite.", "Please leave a review of your visit.", "يرجى ترك تقييم لزيارتك."),
        "/appointments",
      );
    } else if (action === "cancel") {
      if (!access.isOwner) {
        await notify(
          appt.patientId,
          L("Visite annulée", "Visit cancelled", "تم إلغاء الزيارة"),
          L(`La visite ${appt.reference} a été annulée.`, `Visit ${appt.reference} was cancelled.`, `تم إلغاء الزيارة ${appt.reference}.`),
          "/appointments",
        );
      }
      if (access.isOwner && assignedProUserId) {
        await notify(
          assignedProUserId,
          L("Visite annulée par le patient", "Visit cancelled by patient", "ألغى المريض الزيارة"),
          L(`La visite ${appt.reference} a été annulée.`, `Visit ${appt.reference} was cancelled.`, `تم إلغاء الزيارة ${appt.reference}.`),
          "/appointments",
        );
      }
    } else if (action === "assign" && newProUserId) {
      await notify(
        newProUserId,
        L("Nouvelle visite assignée", "New visit assigned", "زيارة جديدة مخصصة لك"),
        L(`La visite ${appt.reference} vous a été assignée.`, `Visit ${appt.reference} has been assigned to you.`, `تم تخصيص الزيارة ${appt.reference} لك.`),
        "/appointments",
      );
    }

    await logActivity(auth.user.id, `appointment.${action}`, "appointment", id, appt.reference);
    const [row] = await appointmentBaseQuery().where(eq(appointments.id, id)).limit(1);
    return ok(mapAppointment(row));
  } catch (err) {
    return serverError(err);
  }
}
