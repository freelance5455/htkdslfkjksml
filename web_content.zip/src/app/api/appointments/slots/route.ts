import { and, gte, inArray, lte } from "drizzle-orm";
import { db } from "@/db";
import { appointments } from "@/db/schema";
import { fail, ok, serverError } from "@/lib/http";

const TZ = "Africa/Casablanca";

/** Public: times already requested for a given day (pending or confirmed), so visitors pick a free slot. */
export async function GET(req: Request) {
  const date = new URL(req.url).searchParams.get("date") ?? "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return fail("invalid_input", 422);

  try {
    const from = new Date(`${date}T00:00:00+01:00`);
    const to = new Date(from.getTime() + 36 * 3600_000);
    const rows = await db
      .select({ at: appointments.scheduledAt })
      .from(appointments)
      .where(
        and(
          gte(appointments.scheduledAt, from),
          lte(appointments.scheduledAt, to),
          inArray(appointments.status, ["pending", "confirmed"]),
        ),
      );

    const fmt = new Intl.DateTimeFormat("en-GB", {
      timeZone: TZ,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23",
    });
    const taken = new Set<string>();
    for (const r of rows) {
      const p = Object.fromEntries(fmt.formatToParts(r.at).map((x) => [x.type, x.value]));
      if (`${p.year}-${p.month}-${p.day}` === date) taken.add(`${p.hour}:${p.minute}`);
    }
    return ok({ taken: [...taken].sort() });
  } catch (err) {
    return serverError(err);
  }
}
