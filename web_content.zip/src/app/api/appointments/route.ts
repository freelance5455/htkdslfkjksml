import { randomBytes } from "node:crypto";
import { and, desc, eq, inArray, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { appointments, professionals, services } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { MIN_BOOKING_LEAD_HOURS } from "@/lib/constants";
import { fail, isUuid, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { L, logActivity, notify, notifyAdmins } from "@/lib/notify";
import { appointmentBaseQuery, getProfessionalByUserId, mapAppointment, pickProfessional } from "@/lib/queries";
import { appointmentCreateSchema, statusFilterSchema } from "@/lib/validators";

function makeReference() {
  return `SC-${Date.now().toString(36).toUpperCase()}-${randomBytes(2).toString("hex").toUpperCase()}`;
}

/** Signed-in patients see their visits, professionals see assigned visits, admins see everything. */
export async function GET(req: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { user } = auth;
  try {
    const conds: SQL[] = [];
    if (user.role === "patient") conds.push(eq(appointments.patientId, user.id));
    if (user.role === "professional") {
      const pro = await getProfessionalByUserId(user.id);
      if (!pro) return ok({ appointments: [] });
      conds.push(eq(appointments.professionalId, pro.id));
    }
    const status = statusFilterSchema.safeParse(new URL(req.url).searchParams.get("status"));
    if (status.success) conds.push(eq(appointments.status, status.data));

    const rows = await appointmentBaseQuery()
      .where(conds.length ? and(...conds) : undefined)
      .orderBy(desc(appointments.scheduledAt));
    return ok({ appointments: rows.map(mapAppointment) });
  } catch (err) {
    return serverError(err);
  }
}

/**
 * Public booking request. Visitors do not need an account; signed-in patients get the request
 * linked to their history. Requests are reviewed by the team, who confirm them by WhatsApp or phone.
 */
export async function POST(req: Request) {
  const parsed = await parseBody(req, appointmentCreateSchema);
  if ("response" in parsed) return parsed.response;
  const d = parsed.data;
  if (!isUuid(d.serviceId)) return fail("not_found", 404);

  try {
    const user = await getSessionUser();
    const patientId = user?.role === "patient" ? user.id : null;

    const [svc] = await db.select().from(services).where(eq(services.id, d.serviceId)).limit(1);
    if (!svc || !svc.isActive) return fail("service_inactive", 404);

    const scheduledAt = new Date(d.scheduledAt);
    if (scheduledAt.getTime() < Date.now() + MIN_BOOKING_LEAD_HOURS * 3600_000) return fail("too_soon", 422);

    const [taken] = await db
      .select({ id: appointments.id })
      .from(appointments)
      .where(and(eq(appointments.scheduledAt, scheduledAt), inArray(appointments.status, ["pending", "confirmed"])))
      .limit(1);
    if (taken) return fail("slot_taken", 409);

    let professionalId: string | null = null;
    if (d.professionalId) {
      if (!isUuid(d.professionalId)) return fail("invalid_input", 422);
      const [pro] = await db.select().from(professionals).where(eq(professionals.id, d.professionalId)).limit(1);
      const covers = pro?.serviceCodes.includes(svc.slug) && pro?.serviceCities.includes(d.city);
      if (!pro || pro.verificationStatus !== "verified" || !covers) return fail("professional_not_available", 422);
      professionalId = pro.id;
    } else {
      professionalId = await pickProfessional(svc.slug, d.city, scheduledAt);
    }

    const reference = makeReference();
    const [created] = await db
      .insert(appointments)
      .values({
        reference,
        patientId,
        professionalId,
        serviceId: svc.id,
        scheduledAt,
        status: "pending",
        patientName: d.patientName,
        phone: d.phone,
        city: d.city,
        address: d.address,
        medicalNotes: d.medicalNotes ?? "",
        priceMad: svc.priceMad,
        durationMinutes: svc.durationMinutes,
      })
      .returning({ id: appointments.id });

    if (patientId) {
      await notify(
        patientId,
        L("Demande de visite reçue", "Visit request received", "تم استلام طلب الزيارة"),
        L(
          `Votre demande ${reference} pour « ${svc.name.fr} » est en cours de confirmation.`,
          `Your request ${reference} for “${svc.name.en}” is being confirmed.`,
          `طلبك ${reference} لخدمة « ${svc.name.ar} » قيد التأكيد.`,
        ),
        "/appointments",
      );
    }

    if (professionalId) {
      const [pro] = await db
        .select({ userId: professionals.userId })
        .from(professionals)
        .where(eq(professionals.id, professionalId))
        .limit(1);
      if (pro) {
        await notify(
          pro.userId,
          L("Nouvelle visite à confirmer", "New visit to confirm", "زيارة جديدة للتأكيد"),
          L(`Demande ${reference} (${svc.name.fr}).`, `Request ${reference} (${svc.name.en}).`, `طلب ${reference} (${svc.name.ar}).`),
          "/appointments",
        );
      }
    }

    await notifyAdmins(
      L("Nouvelle demande de visite", "New visit request", "طلب زيارة جديد"),
      L(
        `${reference} : ${svc.name.fr} (${d.city}), ${d.patientName}.`,
        `${reference}: ${svc.name.en} (${d.city}), ${d.patientName}.`,
        `${reference}: ${svc.name.ar} (${d.city})، ${d.patientName}.`,
      ),
      "/admin",
    );

    await logActivity(user?.id ?? null, "appointment.created", "appointment", created.id, reference);
    const [full] = await appointmentBaseQuery().where(eq(appointments.id, created.id)).limit(1);
    return ok(mapAppointment(full), 201);
  } catch (err) {
    return serverError(err);
  }
}
