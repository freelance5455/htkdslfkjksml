import { NextRequest, NextResponse } from "next/server";
import { isTrackerUrl } from "@/lib/browser";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 NovaBrowser/1.0";

/** Скрипт, внедряемый в каждую проксируемую страницу: перехват навигации, отчёты родителю */
function injectedScript(finalUrl: string, incognito: boolean) {
  return `<script data-nova="1">(function(){
var NOVA_URL=${JSON.stringify(finalUrl)};
var NOVA_INCOG=${incognito};
function proxy(u){try{var abs=new URL(u,NOVA_URL).href;return abs;}catch(e){return null;}}
function go(u,newTab){var abs=proxy(u);if(!abs)return;if(/^javascript:/i.test(abs))return;
  if(abs.startsWith('#')||(abs.split('#')[0]===NOVA_URL.split('#')[0]&&abs.indexOf('#')>-1)){return;}
  parent.postMessage({nova:'navigate',url:abs,newTab:!!newTab},'*');}
window.__novaGo=go;
document.addEventListener('click',function(e){
  if(e.defaultPrevented)return;
  var a=e.target&&e.target.closest?e.target.closest('a[href]'):null;if(!a)return;
  var href=a.getAttribute('href');if(!href||/^(javascript:|mailto:|tel:)/i.test(href))return;
  if(href.charAt(0)==='#')return;
  e.preventDefault();e.stopPropagation();
  var nt=a.target==='_blank'||e.ctrlKey||e.metaKey||e.button===1;
  go(href,nt);
},true);
document.addEventListener('auxclick',function(e){var a=e.target&&e.target.closest?e.target.closest('a[href]'):null;if(a&&e.button===1){e.preventDefault();go(a.getAttribute('href'),true);}},true);
document.addEventListener('submit',function(e){
  var f=e.target;if(!f||f.tagName!=='FORM')return;
  var method=(f.getAttribute('method')||'get').toLowerCase();
  if(method!=='get')return; // POST отправляем как есть через прокси
  e.preventDefault();
  var action=f.getAttribute('action')||NOVA_URL;
  var u=new URL(action,NOVA_URL);var fd=new FormData(f);
  var sp=new URLSearchParams();fd.forEach(function(v,k){if(typeof v==='string')sp.append(k,v);});
  if(e.submitter&&e.submitter.name)sp.append(e.submitter.name,e.submitter.value||'');
  u.search=sp.toString();go(u.href,false);
},true);
var _open=window.open;window.open=function(u){if(u){go(u,true);}return null;};
try{if(navigator.serviceWorker){navigator.serviceWorker.register=function(){return Promise.reject(new Error('blocked by NovaBrowser'));};}}catch(e){}
function report(){try{parent.postMessage({nova:'meta',url:NOVA_URL,title:document.title||'',blocked:window.__novaBlocked||0,
  favicon:(function(){var l=document.querySelector('link[rel~="icon"]');return l?new URL(l.getAttribute('href'),NOVA_URL).href:new URL('/favicon.ico',NOVA_URL).href;})()},'*');}catch(e){}}
document.addEventListener('DOMContentLoaded',report);window.addEventListener('load',report);
setTimeout(report,50);
new MutationObserver(function(){report();}).observe(document.documentElement,{childList:true,subtree:false});
window.addEventListener('message',function(e){
  var d=e.data||{};
  if(d.nova==='getText'){var t=(document.body&&document.body.innerText)||'';parent.postMessage({nova:'pageText',text:t.slice(0,20000),title:document.title,url:NOVA_URL},'*');}
  if(d.nova==='getSelection'){parent.postMessage({nova:'selection',text:String(window.getSelection()||'')},'*');}
  if(d.nova==='find'){try{window.find(d.q);}catch(err){}}
  if(d.nova==='scrollTop'){window.scrollTo({top:0,behavior:'smooth'});}
});
var ts=null;document.addEventListener('touchstart',function(e){if(e.touches.length===1){ts={x:e.touches[0].clientX,y:e.touches[0].clientY,t:Date.now()};}},{passive:true});
document.addEventListener('touchend',function(e){if(!ts)return;var c=e.changedTouches[0];var dx=c.clientX-ts.x,dy=c.clientY-ts.y;
  if(Math.abs(dx)>90&&Math.abs(dy)<60&&Date.now()-ts.t<600&&(ts.x<40||ts.x>window.innerWidth-40)){parent.postMessage({nova:dx>0?'back':'forward'},'*');}ts=null;},{passive:true});
document.addEventListener('keydown',function(e){if((e.ctrlKey||e.metaKey)&&['t','l','w','d','r','k'].indexOf(e.key.toLowerCase())>-1){e.preventDefault();parent.postMessage({nova:'hotkey',key:e.key.toLowerCase()},'*');}});
})();</script>`;
}

function detectCharset(contentType: string | null, buf: Uint8Array): string {
  const ct = contentType?.match(/charset=([\w-]+)/i);
  if (ct) return ct[1].toLowerCase();
  const head = new TextDecoder("latin1").decode(buf.slice(0, 4096));
  const m = head.match(/<meta[^>]+charset=["']?([\w-]+)/i);
  if (m) return m[1].toLowerCase();
  return "utf-8";
}

function rewriteHtml(html: string, finalUrl: string, incognito: boolean, blockTrackers: boolean, dark: boolean): string {
  let out = html;
  let blocked = 0;
  if (blockTrackers) {
    // Вырезаем теги script/iframe/img/link, ведущие на трекеры
    out = out.replace(/<(script|iframe|img|link)\b[^>]*\b(?:src|href)=["']([^"']+)["'][^>]*>(?:\s*<\/\1>)?/gi, (m, _tag, src) => {
      let abs = src;
      try {
        abs = new URL(src, finalUrl).href;
      } catch {
        return m;
      }
      if (isTrackerUrl(abs)) {
        blocked++;
        return "<!-- blocked by NovaBrowser -->";
      }
      return m;
    });
    // Инлайн-инициализация популярных счётчиков
    out = out.replace(/<script\b[^>]*>[\s\S]{0,400}?(?:ym\(\d+|gtag\(|ga\('create'|fbq\('init')[\s\S]*?<\/script>/gi, () => {
      blocked++;
      return "<!-- blocked inline tracker -->";
    });
  }
  const darkCss = dark
    ? `<style data-nova-dark>html{filter:invert(.92) hue-rotate(180deg);background:#111!important}img,video,picture,canvas,[style*="background-image"]{filter:invert(1) hue-rotate(180deg)}</style>`
    : "";
  // Убираем CSP и refresh-мета, которые ломают проксирование
  out = out.replace(/<meta[^>]+http-equiv=["']?content-security-policy["']?[^>]*>/gi, "");
  out = out.replace(/<meta[^>]+http-equiv=["']?x-frame-options["']?[^>]*>/gi, "");
  // integrity-атрибуты не помешают (ресурсы грузятся с оригинала), но убираем для надёжности
  out = out.replace(/\sintegrity=["'][^"']*["']/gi, "");
  // Убираем существующий <base>
  out = out.replace(/<base[^>]*>/gi, "");
  // Переписываем meta refresh на навигацию через прокси
  out = out.replace(
    /<meta[^>]+http-equiv=["']?refresh["']?[^>]*content=["']?\s*\d+\s*;\s*url=([^"'>\s]+)[^>]*>/gi,
    (_m, u) => `<script>setTimeout(function(){window.__novaGo&&window.__novaGo(${JSON.stringify(u)})},1500)</script>`
  );

  const inject =
    `<base href="${finalUrl.replace(/"/g, "&quot;")}">` +
    darkCss +
    `<script>window.__novaBlocked=${blocked};</script>` +
    injectedScript(finalUrl, incognito);
  if (/<head[^>]*>/i.test(out)) {
    out = out.replace(/<head[^>]*>/i, (m) => m + inject);
  } else if (/<html[^>]*>/i.test(out)) {
    out = out.replace(/<html[^>]*>/i, (m) => m + "<head>" + inject + "</head>");
  } else {
    out = inject + out;
  }
  return out;
}

export async function GET(req: NextRequest) {
  return handle(req);
}
export async function POST(req: NextRequest) {
  return handle(req);
}

async function handle(req: NextRequest) {
  const target = req.nextUrl.searchParams.get("url");
  const incognito = req.nextUrl.searchParams.get("incognito") === "1";
  const blockTrackers = req.nextUrl.searchParams.get("block") !== "0";
  const dark = req.nextUrl.searchParams.get("dark") === "1";
  if (!target) return new NextResponse("Missing url", { status: 400 });

  let url: URL;
  try {
    url = new URL(target);
  } catch {
    return errorPage("Некорректный адрес", target);
  }
  if (!["http:", "https:"].includes(url.protocol)) {
    return errorPage("Поддерживаются только http/https", target);
  }
  // Защита от SSRF: не ходим на локальные адреса
  if (/^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|0\.0\.0\.0|\[::1\])/i.test(url.hostname)) {
    return errorPage("Доступ к локальной сети запрещён", target);
  }
  if (blockTrackers && isTrackerUrl(url.href)) {
    return new NextResponse("Blocked by NovaBrowser tracker protection", {
      status: 204,
      headers: { "x-nova-blocked": "1" },
    });
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    const init: RequestInit = {
      method: req.method,
      headers: {
        "user-agent": UA,
        accept: req.headers.get("accept") || "text/html,application/xhtml+xml,*/*;q=0.8",
        "accept-language": "ru-RU,ru;q=0.9,en;q=0.8",
        ...(req.method === "POST"
          ? { "content-type": req.headers.get("content-type") || "application/x-www-form-urlencoded" }
          : {}),
      },
      redirect: "follow",
      signal: controller.signal,
    };
    if (req.method === "POST") init.body = await req.arrayBuffer();

    const res = await fetch(url.href, init);
    const finalUrl = res.url || url.href;
    const ctype = res.headers.get("content-type") || "";

    const baseHeaders: Record<string, string> = {
      "x-nova-final-url": finalUrl,
      "x-nova-status": String(res.status),
      "cache-control": "no-store",
    };

    if (ctype.includes("text/html") || ctype.includes("application/xhtml")) {
      const buf = new Uint8Array(await res.arrayBuffer());
      const charset = detectCharset(ctype, buf);
      let html: string;
      try {
        html = new TextDecoder(charset).decode(buf);
      } catch {
        html = new TextDecoder("utf-8").decode(buf);
      }
      const rewritten = rewriteHtml(html, finalUrl, incognito, blockTrackers, dark);
      return new NextResponse(rewritten, {
        status: res.status >= 400 ? 200 : res.status,
        headers: { ...baseHeaders, "content-type": "text/html; charset=utf-8" },
      });
    }

    // Не-HTML: отдаём как есть (PDF, изображения, JSON и т.д.)
    const headers: Record<string, string> = { ...baseHeaders, "content-type": ctype || "application/octet-stream" };
    const cd = res.headers.get("content-disposition");
    if (cd) headers["content-disposition"] = cd;
    return new NextResponse(res.body, { status: res.status, headers });
  } catch (e) {
    const msg = e instanceof Error ? (e.name === "AbortError" ? "Превышено время ожидания" : e.message) : "Ошибка";
    return errorPage(msg, target);
  } finally {
    clearTimeout(timer);
  }
}

function errorPage(message: string, url: string) {
  const html = `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Не удалось открыть</title>
<style>body{font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#0f172a;color:#e2e8f0}.c{text-align:center;max-width:460px;padding:24px}.i{font-size:56px}h1{font-size:20px;margin:12px 0}p{color:#94a3b8;word-break:break-all}button{margin-top:16px;padding:10px 18px;border:0;border-radius:10px;background:#6366f1;color:#fff;font-size:14px;cursor:pointer}</style></head>
<body><div class="c"><div class="i">🛰️</div><h1>${message}</h1><p>${url.replace(/</g, "&lt;")}</p><button onclick="parent.postMessage({nova:'reload'},'*')">Повторить</button></div></body></html>`;
  return new NextResponse(html, { status: 200, headers: { "content-type": "text/html; charset=utf-8" } });
}
