import { NextRequest } from "next/server";
import { db } from "@/db";
import { copyFollows, masterTraders, paperPositions } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { getTickers } from "@/lib/market";
import { getCachedScan, positionPnl, runCopyEngine, runScan } from "@/server/engine";
import { USER_KEY, ensureSeed, notify } from "@/server/store";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET() {
  try {
    await ensureSeed();
    const traders = await db.select().from(masterTraders).orderBy(desc(masterTraders.roi30d));
    const follows = await db
      .select()
      .from(copyFollows)
      .where(eq(copyFollows.userKey, USER_KEY))
      .orderBy(desc(copyFollows.createdAt));
    const positions = await db
      .select()
      .from(paperPositions)
      .where(and(eq(paperPositions.userKey, USER_KEY), eq(paperPositions.source, "COPY")))
      .orderBy(desc(paperPositions.openedAt))
      .limit(50);
    const tickers = await getTickers();
    const enriched = positions.map((p) => {
      const mark = tickers.data.find((t) => t.symbol === p.symbol)?.price ?? p.entryPrice;
      return {
        ...p,
        markPrice: mark,
        pnl: p.status === "OPEN" ? positionPnl(p.side, p.entryPrice, mark, p.qty) : (p.realizedPnl ?? 0),
      };
    });
    return Response.json({ ok: true, traders, follows, positions: enriched, source: tickers.source });
  } catch (err) {
    return Response.json(
      { ok: false, traders: [], follows: [], positions: [], error: err instanceof Error ? err.message : "שגיאה" },
      { status: 500 },
    );
  }
}

type Body = {
  action?: "FOLLOW" | "UNFOLLOW" | "UPDATE" | "SYNC";
  masterTraderId?: number;
  followId?: number;
  budget?: number;
  copyStopLossPct?: number;
  maxOpenPositions?: number;
  maxLeverage?: number;
  active?: boolean;
};

export async function POST(req: NextRequest) {
  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return Response.json({ ok: false, error: "בקשה לא תקינה" }, { status: 400 });
  }
  try {
    await ensureSeed();
    const action = body.action ?? "FOLLOW";

    if (action === "UNFOLLOW") {
      const id = Number(body.followId);
      await db.delete(copyFollows).where(and(eq(copyFollows.id, id), eq(copyFollows.userKey, USER_KEY)));
      return Response.json({ ok: true, message: "המעקב הופסק" });
    }

    if (action === "UPDATE") {
      const id = Number(body.followId);
      await db
        .update(copyFollows)
        .set({
          budget: Number(body.budget ?? 1000),
          copyStopLossPct: Number(body.copyStopLossPct ?? 15),
          maxOpenPositions: Number(body.maxOpenPositions ?? 3),
          maxLeverage: Number(body.maxLeverage ?? 5),
          active: body.active ?? true,
        })
        .where(and(eq(copyFollows.id, id), eq(copyFollows.userKey, USER_KEY)));
      return Response.json({ ok: true, message: "הגדרות החיקוי עודכנו" });
    }

    if (action === "SYNC") {
      const scan = getCachedScan() ?? (await runScan(false));
      const executed = await runCopyEngine(scan.analyses);
      return Response.json({
        ok: true,
        executed,
        message: executed > 0 ? `שוכפלו ${executed} עסקאות חדשות` : "אין עסקאות חדשות לשכפול כרגע",
      });
    }

    const masterTraderId = Number(body.masterTraderId);
    if (!masterTraderId) return Response.json({ ok: false, error: "חסר מזהה סוחר" }, { status: 400 });
    const existing = await db
      .select()
      .from(copyFollows)
      .where(and(eq(copyFollows.userKey, USER_KEY), eq(copyFollows.masterTraderId, masterTraderId)))
      .limit(1);
    if (existing.length > 0) {
      return Response.json({ ok: false, error: "כבר קיים מעקב אחרי סוחר זה" }, { status: 400 });
    }
    const inserted = await db
      .insert(copyFollows)
      .values({
        userKey: USER_KEY,
        masterTraderId,
        budget: Number(body.budget ?? 1000),
        copyStopLossPct: Number(body.copyStopLossPct ?? 15),
        maxOpenPositions: Number(body.maxOpenPositions ?? 3),
        maxLeverage: Number(body.maxLeverage ?? 5),
        active: true,
      })
      .returning();
    await db
      .update(masterTraders)
      .set({ followers: (await db.select().from(masterTraders).where(eq(masterTraders.id, masterTraderId)).limit(1))[0]?.followers + 1 })
      .where(eq(masterTraders.id, masterTraderId));

    const scan = getCachedScan() ?? (await runScan(false));
    const executed = await runCopyEngine(scan.analyses);
    await notify("חיקוי סוחר הופעל", `התחלת לשכפל עסקאות עם תקציב ${body.budget ?? 1000}$`, "copy");
    return Response.json({
      ok: true,
      follow: inserted[0],
      executed,
      message: "עקוב ושכפל הופעל בהצלחה",
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "שגיאה בהפעלת חיקוי" },
      { status: 500 },
    );
  }
}
