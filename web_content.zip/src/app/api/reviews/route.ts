import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { appointments, professionals, reviews } from "@/db/schema";
import { fail, isUuid, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { L, logActivity, notify } from "@/lib/notify";
import { patientUsers, proUsers, recomputeRating } from "@/lib/queries";
import { reviewSchema } from "@/lib/validators";

/** Admin: list all reviews and feedback. */
export async function GET() {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  try {
    const rows = await db
      .select({
        id: reviews.id,
        appointmentId: reviews.appointmentId,
        professionalId: reviews.professionalId,
        rating: reviews.rating,
        comment: reviews.comment,
        createdAt: reviews.createdAt,
        reference: appointments.reference,
        professionalName: proUsers.fullName,
        patientName: patientUsers.fullName,
      })
      .from(reviews)
      .innerJoin(appointments, eq(appointments.id, reviews.appointmentId))
      .leftJoin(professionals, eq(professionals.id, reviews.professionalId))
      .leftJoin(proUsers, eq(proUsers.id, professionals.userId))
      .innerJoin(patientUsers, eq(patientUsers.id, reviews.patientId))
      .orderBy(desc(reviews.createdAt));
    return ok({ reviews: rows });
  } catch (err) {
    return serverError(err);
  }
}

/** Signed-in patient: review a completed visit (one review per visit). */
export async function POST(req: Request) {
  const auth = await requireUser(["patient"]);
  if ("response" in auth) return auth.response;
  const parsed = await parseBody(req, reviewSchema);
  if ("response" in parsed) return parsed.response;
  const d = parsed.data;
  if (!isUuid(d.appointmentId)) return fail("not_found", 404);

  try {
    const [appt] = await db.select().from(appointments).where(eq(appointments.id, d.appointmentId)).limit(1);
    if (!appt || appt.patientId !== auth.user.id) return fail("not_found", 404);
    if (appt.status !== "completed") return fail("not_completed", 409);

    const [row] = await db
      .insert(reviews)
      .values({
        appointmentId: appt.id,
        professionalId: appt.professionalId,
        patientId: auth.user.id,
        rating: d.rating,
        comment: d.comment ?? "",
      })
      .onConflictDoNothing({ target: reviews.appointmentId })
      .returning();
    if (!row) return fail("already_reviewed", 409);

    if (appt.professionalId) {
      await recomputeRating(appt.professionalId);
      const [pro] = await db
        .select({ userId: professionals.userId })
        .from(professionals)
        .where(eq(professionals.id, appt.professionalId))
        .limit(1);
      if (pro) {
        await notify(
          pro.userId,
          L("Nouvel avis patient", "New patient review", "تقييم جديد من مريض"),
          L(`Vous avez reçu une note de ${d.rating}/5.`, `You received a ${d.rating}/5 rating.`, `تلقيت تقييماً من ${d.rating}/5.`),
          "/profile",
        );
      }
    }
    await logActivity(auth.user.id, "review.created", "review", row.id, `${d.rating}/5`);
    return ok(row, 201);
  } catch (err) {
    return serverError(err);
  }
}

/** Admin: remove an abusive or invalid review (?id=...). */
export async function DELETE(req: Request) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const id = new URL(req.url).searchParams.get("id") ?? "";
  if (!isUuid(id)) return fail("not_found", 404);
  try {
    const [row] = await db.delete(reviews).where(eq(reviews.id, id)).returning({ professionalId: reviews.professionalId });
    if (!row) return fail("not_found", 404);
    if (row.professionalId) await recomputeRating(row.professionalId);
    await logActivity(auth.user.id, "review.deleted", "review", id);
    return ok({ ok: true });
  } catch (err) {
    return serverError(err);
  }
}
