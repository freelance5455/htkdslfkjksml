import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { questions, attempts } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { difficultyForRing } from "@/lib/scoring";
import { shuffledOrder, newNonce } from "@/lib/rng";
import type { DomainId } from "@/lib/types";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const mindId = sp.get("mindId");
  const ring = Math.max(1, parseInt(sp.get("ring") ?? "1", 10) || 1);
  const count = Math.min(12, Math.max(5, parseInt(sp.get("count") ?? "7", 10) || 7));
  const domain = sp.get("domain") as DomainId | null;

  if (!mindId) return NextResponse.json({ error: "mindId required" }, { status: 400 });

  const target = difficultyForRing(ring);
  const lo = Math.max(1, target - 2);
  const hi = Math.min(10, target + 1);

  const answeredRows = await db
    .select({ subjectId: attempts.subjectId })
    .from(attempts)
    .where(and(eq(attempts.mindId, mindId as never), eq(attempts.kind, "trial")));
  const answered = new Set(answeredRows.map((r) => r.subjectId));

  const all = await db.select().from(questions);
  const inWindow = all.filter(
    (q) => q.difficulty >= lo && q.difficulty <= hi && !q.isBoss && (!domain || q.domain === domain),
  );

  let pool = inWindow.filter((q) => !answered.has(q.id));
  if (pool.length < count) pool = inWindow; // mind exhausted fresh trials — allow repeats

  // shuffle
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }

  const selected = pool.slice(0, count);

  // Boss injection at ring milestones
  if (ring % 5 === 0) {
    const bosses = all.filter((q) => q.isBoss && !answered.has(q.id) && (!domain || q.domain === domain));
    if (bosses.length) {
      const boss = bosses[Math.floor(Math.random() * bosses.length)];
      selected[Math.floor(Math.random() * selected.length)] = boss;
    }
  }

  return NextResponse.json({
    ring,
    targetDifficulty: target,
    /* Options are shuffled per-delivery with a nonce. The client sees only
       the shuffled text; grading remaps positions through the same nonce.
       No mind can learn positions — every visit reshuffles. */
    trials: selected.map((q) => {
      const s = newNonce();
      const order = shuffledOrder(q.id, s, q.options.length);
      return {
        id: q.id,
        s,
        domain: q.domain,
        kind: q.kind,
        difficulty: q.difficulty,
        prompt: q.prompt,
        options: order.map((orig) => q.options[orig]),
        timeLimit: q.timeLimit,
        isBoss: q.isBoss,
      };
    }),
  });
}
