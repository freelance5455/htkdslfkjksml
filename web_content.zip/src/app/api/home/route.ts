import { and, asc, count, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { articles, professionals, services } from "@/db/schema";
import { ok, serverError } from "@/lib/http";

export const dynamic = "force-dynamic";

/** Public home-page payload: featured services, guides, the daily tip and platform counters. */
export async function GET() {
  try {
    const featuredServices = await db
      .select()
      .from(services)
      .where(eq(services.isActive, true))
      .orderBy(asc(services.sortOrder), asc(services.priceMad))
      .limit(12);

    const featuredArticles = await db
      .select()
      .from(articles)
      .where(and(eq(articles.kind, "article"), eq(articles.isPublished, true)))
      .orderBy(desc(articles.isFeatured), desc(articles.createdAt))
      .limit(4);

    const tips = await db
      .select()
      .from(articles)
      .where(and(eq(articles.kind, "tip"), eq(articles.isPublished, true)))
      .orderBy(asc(articles.createdAt));
    // One tip per calendar day, rotating through the list.
    const tip = tips.length ? tips[Math.floor(Date.now() / 86_400_000) % tips.length] : null;

    const [pros] = await db
      .select({ c: count() })
      .from(professionals)
      .where(eq(professionals.verificationStatus, "verified"));
    const [svcCount] = await db.select({ c: count() }).from(services).where(eq(services.isActive, true));
    const [artCount] = await db
      .select({ c: count() })
      .from(articles)
      .where(and(eq(articles.kind, "article"), eq(articles.isPublished, true)));

    return ok({
      featuredServices,
      featuredArticles,
      tip,
      stats: {
        professionals: Number(pros?.c ?? 0),
        services: Number(svcCount?.c ?? 0),
        articles: Number(artCount?.c ?? 0),
      },
    });
  } catch (err) {
    return serverError(err);
  }
}
