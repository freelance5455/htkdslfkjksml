import { NextResponse } from "next/server";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import { getAttraction, getBookingsByEmail } from "@/lib/queries";

export const dynamic = "force-dynamic";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function makeRef() {
  let s = "";
  for (let i = 0; i < 6; i++) s += CHARS[Math.floor(Math.random() * CHARS.length)];
  return `ET-${s}`;
}

export async function GET(req: Request) {
  const email = new URL(req.url).searchParams.get("email")?.trim().toLowerCase() ?? "";
  if (!EMAIL_RE.test(email)) return NextResponse.json({ error: "Invalid email" }, { status: 400 });
  const rows = await getBookingsByEmail(email);
  return NextResponse.json({
    bookings: rows.map(({ booking, attraction }) => ({
      ref: booking.ref,
      visitDate: booking.visitDate,
      tickets: booking.tickets,
      total: booking.total,
      attraction: {
        slug: attraction.slug,
        nameEn: attraction.nameEn,
        nameAr: attraction.nameAr,
        cityEn: attraction.cityEn,
        cityAr: attraction.cityAr,
        image: attraction.image,
      },
    })),
  });
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      slug?: string;
      name?: string;
      email?: string;
      date?: string;
      tickets?: number;
    };
    const name = (body.name ?? "").trim().slice(0, 100);
    const email = (body.email ?? "").trim().toLowerCase();
    const date = body.date ?? "";
    const tickets = Number(body.tickets);

    if (!name) return NextResponse.json({ error: "name" }, { status: 400 });
    if (!EMAIL_RE.test(email)) return NextResponse.json({ error: "email" }, { status: 400 });
    if (!Number.isInteger(tickets) || tickets < 1 || tickets > 20) {
      return NextResponse.json({ error: "tickets" }, { status: 400 });
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return NextResponse.json({ error: "date" }, { status: 400 });
    const today = new Date();
    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
    if (date < todayStr) return NextResponse.json({ error: "date" }, { status: 400 });

    const attraction = await getAttraction(body.slug ?? "");
    if (!attraction) return NextResponse.json({ error: "attraction" }, { status: 404 });

    let ref = makeRef();
    for (let attempt = 0; attempt < 5; attempt++) {
      try {
        await db.insert(bookings).values({
          ref,
          attractionId: attraction.id,
          name,
          email,
          visitDate: date,
          tickets,
          total: tickets * attraction.price,
        });
        return NextResponse.json({ ref });
      } catch (err) {
        if (attempt === 4) throw err;
        ref = makeRef();
      }
    }
    return NextResponse.json({ error: "failed" }, { status: 500 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "failed" }, { status: 500 });
  }
}
