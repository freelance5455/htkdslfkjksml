import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { history } from "@/db/schema";
import { desc, eq, ilike, and, or } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q") || "";
  const profileId = Number(req.nextUrl.searchParams.get("profileId") || 0);
  const where = q
    ? and(eq(history.profileId, profileId), or(ilike(history.url, `%${q}%`), ilike(history.title, `%${q}%`)))
    : eq(history.profileId, profileId);
  const rows = await db.select().from(history).where(where).orderBy(desc(history.visitedAt)).limit(300);
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const b = (await req.json()) as { url: string; title?: string; profileId?: number };
  if (!b.url || b.url.startsWith("nova://")) return NextResponse.json({ ok: true });
  const [row] = await db
    .insert(history)
    .values({ url: b.url, title: b.title || "", profileId: b.profileId || 0 })
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  const profileId = Number(req.nextUrl.searchParams.get("profileId") || 0);
  if (id) await db.delete(history).where(eq(history.id, Number(id)));
  else await db.delete(history).where(eq(history.profileId, profileId));
  return NextResponse.json({ ok: true });
}
