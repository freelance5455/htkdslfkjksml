import { db } from "@/db";
import { siteSettings } from "@/db/schema";
import { fail, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { logActivity } from "@/lib/notify";
import { getSiteData } from "@/lib/site";
import { siteSettingsSchema } from "@/lib/validators";

/** Public: website content used by every page (contact numbers, WhatsApp, texts, categories). */
export async function GET() {
  try {
    return ok(await getSiteData());
  } catch (err) {
    return serverError(err);
  }
}

/** Admin: update website content. Validates the WhatsApp and call numbers before saving. */
export async function PATCH(req: Request) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const parsed = await parseBody(req, siteSettingsSchema);
  if ("response" in parsed) return parsed.response;

  try {
    await db
      .insert(siteSettings)
      .values({ key: "main", value: parsed.data })
      .onConflictDoUpdate({
        target: siteSettings.key,
        set: { value: parsed.data, updatedAt: new Date() },
      });
    await logActivity(auth.user.id, "site.updated", "site", "main");
    return ok(await getSiteData());
  } catch (err) {
    if (err instanceof Error && err.message.includes("invalid")) return fail("invalid_input", 422);
    return serverError(err);
  }
}
