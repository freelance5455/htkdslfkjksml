import { eq } from "drizzle-orm";
import { db } from "@/db";
import { members, squads } from "@/db/schema";
import { DEMO_SQUAD_CODE, ensureSeeded, setSessionCookie } from "@/lib/data";
import { makeSessionToken } from "@/lib/session";
import { clearSessionCookie } from "@/lib/session";

export const dynamic = "force-dynamic";

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function randomCode(length: number) {
  let out = "";
  for (let i = 0; i < length; i += 1) {
    out += ALPHABET[Math.floor(Math.random() * ALPHABET.length)];
  }
  return out;
}

const AVATAR_COLORS = ["#e62429", "#f5c542", "#8b5cf6", "#22d3ee", "#22c55e", "#f97316", "#ec4899"];

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) {
    return Response.json({ error: "Richiesta non valida" }, { status: 400 });
  }

  const mode = String(body.mode ?? "create");
  const rawName = String(body.name ?? "").trim();
  const avatar = String(body.avatar ?? "🦸").slice(0, 8) || "🦸";

  if (rawName.length < 2) {
    return Response.json({ error: "Inserisci un nome di almeno 2 caratteri" }, { status: 400 });
  }
  const name = rawName.slice(0, 24);
  const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

  await ensureSeeded();

  try {
    if (mode === "join") {
      const code = String(body.code ?? "").trim().toUpperCase();
      if (!code) {
        return Response.json({ error: "Inserisci il codice della squadra" }, { status: 400 });
      }
      const found = await db.select().from(squads).where(eq(squads.code, code)).limit(1);
      const squad = found[0];
      if (!squad) {
        return Response.json({ error: "Codice squadra non trovato. Controlla e riprova." }, { status: 404 });
      }
      const [member] = await db
        .insert(members)
        .values({
          squadId: squad.id,
          name,
          avatar,
          color,
          code: `${name.slice(0, 5).toUpperCase()}-${randomCode(3)}`,
        })
        .returning();
      const payload = {
        id: member.id,
        squadCode: squad.code,
        squadName: squad.name,
        memberCode: member.code,
        name: member.name,
        avatar: member.avatar,
        color: member.color,
      };
      await setSessionCookie(payload);
      return Response.json({ ok: true, memberId: member.id, squadId: squad.id, token: makeSessionToken(payload) });
    }

    if (mode === "demo") {
      const found = await db.select().from(squads).where(eq(squads.code, DEMO_SQUAD_CODE)).limit(1);
      let squad = found[0];
      if (!squad) {
        const [created] = await db
          .insert(squads)
          .values({ name: "Squadra Vendicatori", code: DEMO_SQUAD_CODE })
          .returning();
        squad = created;
      }
      const [member] = await db
        .insert(members)
        .values({
          squadId: squad.id,
          name,
          avatar,
          color,
          code: `${name.slice(0, 5).toUpperCase()}-${randomCode(3)}`,
        })
        .returning();
      const payload = {
        id: member.id,
        squadCode: squad.code,
        squadName: squad.name,
        memberCode: member.code,
        name: member.name,
        avatar: member.avatar,
        color: member.color,
      };
      await setSessionCookie(payload);
      return Response.json({ ok: true, memberId: member.id, squadId: squad.id, token: makeSessionToken(payload) });
    }

    const squadName = String(body.squadName ?? "").trim().slice(0, 32) || `Squadra di ${name}`;
    let code = randomCode(6);
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const clash = await db.select({ id: squads.id }).from(squads).where(eq(squads.code, code)).limit(1);
      if (clash.length === 0) break;
      code = randomCode(6);
    }

    const [squad] = await db.insert(squads).values({ name: squadName, code }).returning();
    const [member] = await db
      .insert(members)
      .values({
        squadId: squad.id,
        name,
        avatar,
        color,
        code: `${name.slice(0, 5).toUpperCase()}-${randomCode(3)}`,
      })
      .returning();

    const payload = {
      id: member.id,
      squadCode: squad.code,
      squadName: squad.name,
      memberCode: member.code,
      name: member.name,
      avatar: member.avatar,
      color: member.color,
    };
    await setSessionCookie(payload);
    return Response.json({
      ok: true,
      memberId: member.id,
      squadId: squad.id,
      code: squad.code,
      token: makeSessionToken(payload),
    });
  } catch (error) {
    console.error("session error", error);
    return Response.json({ error: "Qualcosa è andato storto. Riprova." }, { status: 500 });
  }
}

export async function DELETE() {
  await clearSessionCookie();
  return Response.json({ ok: true });
}
