import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure-schema";
import { matches } from "@/db/schema";
import { apiError, databaseErrorResponse } from "@/lib/api-errors";
import { buildState, oversStr } from "@/lib/engine";
import type { MatchSetup, Player, PlayerRole } from "@/lib/types";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const ROLES: PlayerRole[] = ["Batsman", "Bowler", "All-rounder", "Wicketkeeper-batter"];

export async function GET() {
  try {
    await ensureSchema();
    const rows = await db.select().from(matches).orderBy(desc(matches.createdAt)).limit(100);
    const list = rows.map((r) => {
      const state = buildState(r.setup, r.events ?? [], r.awards);
      const inn = state.innings[state.currentInnings];
      return {
        id: r.id,
        title: r.title,
        teamA: r.setup.teamA,
        teamB: r.setup.teamB,
        overs: r.setup.overs,
        format: r.setup.format,
        venue: r.setup.venue ?? null,
        date: r.setup.matchDate ?? r.createdAt,
        status: state.status,
        result: state.result,
        playerOfMatch: state.awards.playerOfMatch ?? null,
        summary: `${inn.battingTeam} ${inn.runs}/${inn.wickets} (${oversStr(inn.legalBalls)})`,
        createdAt: r.createdAt,
      };
    });
    return NextResponse.json({ matches: list });
  } catch (error) {
    return databaseErrorResponse(error);
  }
}

function normalizePlayers(raw: unknown): Player[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((p, i): Player | null => {
      if (!p || typeof p !== "object") return null;
      const o = p as Record<string, unknown>;
      const name = String(o.name ?? "").trim();
      if (!name) return null;
      const role = ROLES.includes(o.role as PlayerRole) ? (o.role as PlayerRole) : "Batsman";
      const jerseyNum = Number(o.jersey);
      return {
        id: String(o.id ?? `p${i}-${name.toLowerCase().replace(/\s+/g, "-")}`),
        name,
        photo: typeof o.photo === "string" && o.photo.trim() ? o.photo.trim() : undefined,
        jersey: Number.isFinite(jerseyNum) && jerseyNum > 0 ? jerseyNum : undefined,
        role,
        captain: !!o.captain,
        viceCaptain: !!o.viceCaptain,
        wicketKeeper: !!o.wicketKeeper || role === "Wicketkeeper-batter",
      };
    })
    .filter((p): p is Player => p !== null);
}

function dedupeNames(players: Player[]): Player[] {
  const seen = new Map<string, number>();
  return players.map((p) => {
    const count = seen.get(p.name) ?? 0;
    seen.set(p.name, count + 1);
    return count === 0 ? p : { ...p, name: `${p.name} (${count + 1})` };
  });
}

export async function POST(req: Request) {
  // Guarded: a malformed/empty body must be a clean 400, never an opaque 500.
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return apiError("VALIDATION_ERROR", "A valid JSON request body is required.", 400);
  }
  const teamA = String(body.teamA ?? "").trim();
  const teamB = String(body.teamB ?? "").trim();
  const overs = Number(body.overs);
  const playersA = dedupeNames(normalizePlayers(body.playersA));
  const playersB = dedupeNames(normalizePlayers(body.playersB));

  if (!teamA || !teamB) {
    return apiError("VALIDATION_ERROR", "Both team names are required", 400);
  }
  if (teamA.toLowerCase() === teamB.toLowerCase()) {
    return apiError("VALIDATION_ERROR", "Team names must be different", 400);
  }
  if (!Number.isFinite(overs) || overs < 1 || overs > 90) {
    return apiError("VALIDATION_ERROR", "Overs must be between 1 and 90", 400);
  }
  // The simplified flow only collects the openers; the rest of the squad is
  // added as the match progresses, so no fixed roster size is required here.
  if (playersA.length === 0 || playersB.length === 0) {
    return apiError("VALIDATION_ERROR", "Each team needs at least one named player", 400);
  }

  const battingFirst: "A" | "B" = body.battingFirst === "B" ? "B" : "A";
  const b1 = String(body.openingBatsman1 ?? "").trim();
  const b2 = String(body.openingBatsman2 ?? "").trim();
  const bowler = String(body.openingBowler ?? "").trim();

  if (!b1 || !b2) {
    return apiError("VALIDATION_ERROR", "Both opening batters are required", 400);
  }
  if (b1 === b2) {
    return apiError("VALIDATION_ERROR", "Opening batters must be different", 400);
  }
  if (!bowler) {
    return apiError("VALIDATION_ERROR", "An opening bowler is required", 400);
  }

  const formatRaw = String(body.format ?? "Custom");
  const format = (["T5", "T10", "T20", "T30", "T50", "ODI", "Custom"].includes(formatRaw)
    ? formatRaw
    : "Custom") as MatchSetup["format"];

  const setup: MatchSetup = {
    teamA,
    teamB,
    logoA: typeof body.logoA === "string" && body.logoA.trim() ? body.logoA.trim() : undefined,
    logoB: typeof body.logoB === "string" && body.logoB.trim() ? body.logoB.trim() : undefined,
    overs,
    format,
    venue: String(body.venue ?? "").trim() || undefined,
    matchDate: String(body.matchDate ?? "").trim() || new Date().toISOString(),
    tossWinner: String(body.tossWinner ?? teamA).trim(),
    tossDecision: body.tossDecision === "bowl" ? "bowl" : "bat",
    battingFirst,
    playersA,
    playersB,
    openingBatsman1: b1,
    openingBatsman2: b2,
    openingBowler: bowler,
    playersPerTeam: Number(body.playersPerTeam) > 1 ? Number(body.playersPerTeam) : 11,
  };

  try {
    await ensureSchema();
    const [row] = await db
      .insert(matches)
      .values({
        setup,
        events: [],
        awards: { playerOfMatch: null, prizes: {} },
        title: `${teamA} vs ${teamB}`,
      })
      .returning();

    return NextResponse.json({ id: row.id });
  } catch (error) {
    return databaseErrorResponse(error);
  }
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");

  try {
    await ensureSchema();
    // Wipe everything and start from zero.
    if (searchParams.get("all") === "1") {
      const removed = await db.delete(matches).returning({ id: matches.id });
      return NextResponse.json({ ok: true, deleted: removed.length });
    }

    if (!id) return apiError("VALIDATION_ERROR", "id required", 400);
    await db.delete(matches).where(eq(matches.id, id));
    return NextResponse.json({ ok: true, deleted: 1 });
  } catch (error) {
    return databaseErrorResponse(error);
  }
}
