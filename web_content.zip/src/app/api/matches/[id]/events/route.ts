import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure-schema";
import { matches } from "@/db/schema";
import { apiError, databaseErrorResponse } from "@/lib/api-errors";
import { buildState } from "@/lib/engine";
import type { MatchEvent, MatchState } from "@/lib/types";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

async function load(id: string) {
  const [row] = await db.select().from(matches).where(eq(matches.id, id)).limit(1);
  return row;
}

/**
 * Validates an incoming event against the current match state so the scorer
 * gets an explicit reason instead of a silently ignored tap.
 */
function validate(state: MatchState, ev: MatchEvent): string | null {
  const inn = state.innings[state.currentInnings];
  switch (ev.type) {
    // Squads are built up as the match progresses, so any non-empty name is
    // accepted here and registered by the engine. Only cricket rules are enforced.
    case "newBowler": {
      if (state.status !== "live" || inn.completed) return "The innings is not live.";
      if (!ev.name?.trim()) return "A bowler name is required.";
      if (inn.needNewBowler && inn.bowler === ev.name)
        return `${ev.name} bowled the previous over and cannot bowl two overs in a row.`;
      if (!inn.needNewBowler) return "An over is already in progress.";
      return null;
    }
    case "newBatter": {
      if (state.status !== "live" || inn.completed) return "The innings is not live.";
      const name = ev.name?.trim();
      if (!name) return "A batter name is required.";
      if (inn.batters.some((b) => b.name === name && b.out))
        return `${name} has already been dismissed in this innings.`;
      if (name === inn.striker || name === inn.nonStriker)
        return `${name} is already at the crease.`;
      if (ev.end === "striker" && inn.striker) return "The striker's end is not vacant.";
      if (ev.end === "nonStriker" && inn.nonStriker) return "The non-striker's end is not vacant.";
      return null;
    }
    case "startInnings": {
      if (state.status !== "innings-break") return "The second innings has already started.";
      if (!ev.batter1?.trim() || !ev.batter2?.trim()) return "Both opening batters are required.";
      if (ev.batter1.trim() === ev.batter2.trim())
        return "Opening batters must be two different players.";
      if (!ev.bowler?.trim()) return "An opening bowler is required.";
      return null;
    }
    case "wicket": {
      if (inn.needNewBowler) return "Select the next bowler before recording a delivery.";
      if (inn.needNewBatter) return "Send in the next batter before recording a delivery.";
      const incoming = ev.newBatter?.trim();
      if (incoming) {
        if (inn.batters.some((b) => b.name === incoming && b.out))
          return `${incoming} has already been dismissed in this innings.`;
        if (incoming === inn.striker || incoming === inn.nonStriker)
          return `${incoming} is already at the crease.`;
      }
      return null;
    }
    case "run":
    case "wide":
    case "noball":
    case "bye":
    case "legbye": {
      if (state.status === "innings-break") return "Start the second innings first.";
      if (state.status === "completed") return "The match has finished.";
      if (inn.needNewBowler) return "Select the next bowler before recording a delivery.";
      if (inn.needNewBatter) return "Send in the next batter before recording a delivery.";
      if (!inn.striker || !inn.nonStriker) return "Both batters must be at the crease.";
      return null;
    }
    default:
      return null;
  }
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  let body: { event?: MatchEvent };
  try {
    body = (await req.json()) as { event?: MatchEvent };
  } catch {
    return apiError("VALIDATION_ERROR", "A valid JSON request body is required.", 400);
  }
  const event = body.event;
  if (!event || typeof event.type !== "string") {
    return apiError("VALIDATION_ERROR", "An event is required.", 400);
  }
  try {
    await ensureSchema();
    const row = await load(id);
    if (!row) return apiError("NOT_FOUND", "Match not found.", 404);

    const before = buildState(row.setup, row.events ?? [], row.awards);
    const problem = validate(before, event);
    if (problem) {
      return NextResponse.json({ success: false, error: "VALIDATION_ERROR", message: problem, state: before }, { status: 400 });
    }

    const existing = row.events ?? [];
    // Idempotent: an event already stored under this eventId is never re-added.
    if (event.eventId && existing.some((e) => e.eventId === event.eventId)) {
      return NextResponse.json({ state: before, duplicate: true });
    }
    const events = [...existing, event];
    const state = buildState(row.setup, events, row.awards);
    await db
      .update(matches)
      .set({ events, status: state.status, result: state.result, rev: row.rev + 1, updatedAt: new Date() })
      .where(eq(matches.id, id));
    return NextResponse.json({ state });
  } catch (error) {
    return databaseErrorResponse(error);
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    await ensureSchema();
    const row = await load(id);
    if (!row) return apiError("NOT_FOUND", "Match not found.", 404);
    const events = [...(row.events ?? [])];
    events.pop();
    const state = buildState(row.setup, events, row.awards);
    await db
      .update(matches)
      .set({ events, status: state.status, result: state.result, rev: row.rev + 1, updatedAt: new Date() })
      .where(eq(matches.id, id));
    return NextResponse.json({ state });
  } catch (error) {
    return databaseErrorResponse(error);
  }
}
