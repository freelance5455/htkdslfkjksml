import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure-schema";
import { matches } from "@/db/schema";
import { buildState, DEFAULT_AWARDS } from "@/lib/engine";
import { apiError, databaseErrorResponse } from "@/lib/api-errors";
import type { Awards } from "@/lib/types";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    await ensureSchema();
    const [row] = await db.select().from(matches).where(eq(matches.id, id)).limit(1);
    if (!row) return apiError("NOT_FOUND", "Match not found.", 404);
    const state = buildState(row.setup, row.events ?? [], row.awards);
    // `events` and `rev` are returned so a device can adopt the match locally.
    return NextResponse.json({
      id: row.id,
      title: row.title,
      state,
      events: row.events ?? [],
      rev: row.rev,
    });
  } catch (error) {
    return databaseErrorResponse(error);
  }
}

/** Update awards / prizes (scorer-admin action). */
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  let body: { awards?: Partial<Awards> };
  try {
    body = (await req.json()) as { awards?: Partial<Awards> };
  } catch {
    return apiError("VALIDATION_ERROR", "A valid JSON request body is required.", 400);
  }

  try {
    await ensureSchema();
    const [row] = await db.select().from(matches).where(eq(matches.id, id)).limit(1);
    if (!row) return apiError("NOT_FOUND", "Match not found.", 404);

    const current: Awards = row.awards ?? { ...DEFAULT_AWARDS };
    const incoming = body.awards ?? {};

    // Player of the Match / Best Batter / Best Bowler are decided
    // automatically from the recorded match data, so only the optional prize
    // amounts can be edited here.
    const awards: Awards = {
      playerOfMatch: current.playerOfMatch ?? null,
      prizes: { ...current.prizes, ...(incoming.prizes ?? {}) },
    };

    await db
      .update(matches)
      .set({ awards, rev: row.rev + 1, updatedAt: new Date() })
      .where(eq(matches.id, id));
    const state = buildState(row.setup, row.events ?? [], awards);
    return NextResponse.json({ state });
  } catch (error) {
    return databaseErrorResponse(error);
  }
}
