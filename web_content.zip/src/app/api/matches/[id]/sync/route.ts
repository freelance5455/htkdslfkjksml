import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure-schema";
import { matches } from "@/db/schema";
import { buildState, DEFAULT_AWARDS } from "@/lib/engine";
import { apiError, databaseErrorResponse } from "@/lib/api-errors";
import type { Awards, MatchEvent, MatchSetup } from "@/lib/types";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * Idempotent upload of a locally-scored match.
 *
 * Every event carries a stable `eventId` generated on the scoring device, so
 * replaying a sync can never store the same ball twice. A `rev` counter is
 * bumped on every local mutation (including undo); the server accepts a
 * payload only when it is at least as new as what it already holds, which
 * makes retries safe and prevents a stale device from clobbering newer data.
 */
export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;

  let body: {
    setup?: MatchSetup;
    events?: MatchEvent[];
    awards?: Awards;
    rev?: number;
    createdAt?: number;
  };
  try {
    body = await req.json();
  } catch {
    return apiError("VALIDATION_ERROR", "Invalid JSON body.", 400);
  }

  const setup = body.setup;
  if (!setup?.teamA || !setup?.teamB || !Array.isArray(setup.playersA)) {
    return apiError("VALIDATION_ERROR", "A valid match setup is required.", 400);
  }

  // De-duplicate by eventId while preserving the scorer's exact ordering.
  const seen = new Set<string>();
  const events: MatchEvent[] = [];
  for (const ev of body.events ?? []) {
    if (!ev || typeof ev.type !== "string") continue;
    const key = ev.eventId;
    if (key) {
      if (seen.has(key)) continue;
      seen.add(key);
    }
    events.push(ev);
  }

  const awards: Awards = body.awards ?? { ...DEFAULT_AWARDS };
  const incomingRev = Number.isFinite(body.rev) ? Number(body.rev) : 0;
  const state = buildState(setup, events, awards);

  const row = {
    setup,
    events,
    awards,
    title: `${setup.teamA} vs ${setup.teamB}`,
    format: setup.format ?? null,
    venue: setup.venue ?? null,
    matchDate: setup.matchDate ? new Date(setup.matchDate) : null,
    status: state.status,
    result: state.result,
    rev: incomingRev,
    updatedAt: new Date(),
  };

  try {
    await ensureSchema();
    const [existing] = await db
      .select({ rev: matches.rev })
      .from(matches)
      .where(eq(matches.id, id))
      .limit(1);

    if (!existing) {
      await db.insert(matches).values({
        id,
        ...row,
        createdAt: body.createdAt ? new Date(body.createdAt) : new Date(),
      });
      return NextResponse.json({ success: true, synced: true, rev: incomingRev, created: true });
    }

    if (incomingRev < existing.rev) {
      // A newer revision already exists on the server; keep it.
      return NextResponse.json({
        success: true,
        synced: false,
        rev: existing.rev,
        stale: true,
      });
    }

    await db.update(matches).set(row).where(eq(matches.id, id));
    return NextResponse.json({ success: true, synced: true, rev: incomingRev });
  } catch (error) {
    return databaseErrorResponse(error);
  }
}
