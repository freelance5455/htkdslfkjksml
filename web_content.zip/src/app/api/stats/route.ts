import { NextResponse } from "next/server";
import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const result = await db.execute(
    sql`SELECT
      (SELECT count(*) FROM questions)::int AS trials,
      (SELECT count(*) FROM questions WHERE is_boss)::int AS bosses,
      (SELECT count(*) FROM decisions)::int AS decisions,
      (SELECT count(*) FROM minds WHERE NOT is_benchmark)::int AS minds`,
  );
  const row = result.rows[0] as { trials: number; bosses: number; decisions: number; minds: number };
  return NextResponse.json(row);
}
