import { avg, count, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { activityLogs, appointments, articles, professionals, reviews, services, users } from "@/db/schema";
import { requireUser, serverError, ok } from "@/lib/http";

/** Admin: platform statistics, booking trend and recent activity. */
export async function GET() {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  try {
    const roleRows = await db.select({ key: users.role, c: count() }).from(users).groupBy(users.role);
    const proRows = await db
      .select({ key: professionals.verificationStatus, c: count() })
      .from(professionals)
      .groupBy(professionals.verificationStatus);
    const apptRows = await db
      .select({ key: appointments.status, c: count() })
      .from(appointments)
      .groupBy(appointments.status);
    const [reviewAgg] = await db.select({ c: count(), avg: avg(reviews.rating) }).from(reviews);
    const [articleCount] = await db
      .select({ c: count() })
      .from(articles)
      .where(eq(articles.isPublished, true));
    const [serviceCount] = await db.select({ c: count() }).from(services).where(eq(services.isActive, true));
    const dailyRes = await db.execute(
      sql`select to_char(date_trunc('day', created_at), 'YYYY-MM-DD') as day, count(*)::int as count
          from appointments
          where created_at > now() - interval '14 days'
          group by 1 order by 1`,
    );
    const activity = await db
      .select({
        id: activityLogs.id,
        action: activityLogs.action,
        entity: activityLogs.entity,
        details: activityLogs.details,
        createdAt: activityLogs.createdAt,
        actorName: users.fullName,
      })
      .from(activityLogs)
      .leftJoin(users, eq(users.id, activityLogs.actorId))
      .orderBy(desc(activityLogs.createdAt))
      .limit(25);

    const toMap = (rows: Array<{ key: string; c: number }>) =>
      Object.fromEntries(rows.map((r) => [r.key, Number(r.c)]));
    const byRole = toMap(roleRows);
    const byStatus = toMap(apptRows);

    return ok({
      users: { total: Object.values(byRole).reduce((s, n) => s + n, 0), byRole },
      professionals: toMap(proRows),
      appointments: { total: Object.values(byStatus).reduce((s, n) => s + n, 0), byStatus },
      reviews: { count: Number(reviewAgg?.c ?? 0), average: reviewAgg?.avg ? Math.round(Number(reviewAgg.avg) * 10) / 10 : 0 },
      articles: Number(articleCount?.c ?? 0),
      services: Number(serviceCount?.c ?? 0),
      daily: dailyRes.rows as Array<{ day: string; count: number }>,
      activity,
    });
  } catch (err) {
    return serverError(err);
  }
}
