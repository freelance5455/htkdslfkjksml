import fs from "node:fs";
import path from "node:path";
import { NextRequest, NextResponse } from "next/server";
import { getScreenshotsRoot } from "@/lib/db";

export async function GET(
  _request: NextRequest,
  context: { params: { path: string[] } }
) {
  const root = path.resolve(getScreenshotsRoot());
  const requested = path.resolve(root, ...(context.params.path || []));

  if (!requested.startsWith(root + path.sep)) {
    return NextResponse.json({ error: "Invalid path" }, { status: 400 });
  }

  if (!fs.existsSync(requested) || !fs.statSync(requested).isFile()) {
    return NextResponse.json({ error: "Screenshot not found" }, { status: 404 });
  }

  const buffer = fs.readFileSync(requested);
  return new NextResponse(buffer, {
    status: 200,
    headers: {
      "Content-Type": "image/png",
      "Cache-Control": "public, max-age=3600",
    },
  });
}
