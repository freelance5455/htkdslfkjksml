import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, products } from "@/db/schema";
import { desc, eq, inArray } from "drizzle-orm";
import { getSession, generateTrackingNumber } from "@/lib/auth";

export const dynamic = "force-dynamic";

async function withItems(list: (typeof orders.$inferSelect)[]) {
  if (list.length === 0) return [];
  const items = await db
    .select()
    .from(orderItems)
    .where(inArray(orderItems.orderId, list.map((o) => o.id)));
  return list.map((o) => ({ ...o, items: items.filter((i) => i.orderId === o.id) }));
}

export async function GET(req: Request) {
  try {
    const session = await getSession();
    const url = new URL(req.url);
    const phone = url.searchParams.get("phone")?.trim();
    const tracking = url.searchParams.get("tracking")?.trim().toUpperCase();

    if (tracking) {
      const list = await db.select().from(orders).where(eq(orders.trackingNumber, tracking));
      return NextResponse.json({ orders: await withItems(list) });
    }

    if (phone) {
      const list = await db.select().from(orders).where(eq(orders.phone, phone)).orderBy(desc(orders.id));
      return NextResponse.json({ orders: await withItems(list) });
    }

    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const all = await db.select().from(orders).orderBy(desc(orders.id));
    return NextResponse.json({ orders: await withItems(all) });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const customerName = String(body.customerName ?? "").trim();
    const phone = String(body.phone ?? "").trim();
    const address = String(body.address ?? "").trim();
    const message = String(body.message ?? "").trim();
    const items = Array.isArray(body.items) ? body.items : [];

    if (customerName.length < 2 || !phone || address.length < 5) {
      return NextResponse.json({ error: "Name, phone and address are required" }, { status: 400 });
    }
    if (!/^[+0-9\s-]{8,16}$/.test(phone)) {
      return NextResponse.json({ error: "Please enter a valid phone number" }, { status: 400 });
    }
    if (items.length === 0) {
      return NextResponse.json({ error: "No items in order" }, { status: 400 });
    }

    // Never trust client prices: load every product from the database.
    const lines: { productId: number; name: string; price: number; quantity: number }[] = [];
    for (const raw of items) {
      const productId = Number(raw?.productId);
      const quantity = Math.max(1, Math.min(50, Math.round(Number(raw?.quantity) || 1)));
      const [p] = await db.select().from(products).where(eq(products.id, productId));
      if (!p) return NextResponse.json({ error: "A product in your cart no longer exists" }, { status: 400 });
      if (p.status === "out_of_stock") {
        return NextResponse.json({ error: `${p.name} is out of stock` }, { status: 409 });
      }
      if (p.status === "available" && p.stock < quantity) {
        return NextResponse.json({ error: `Only ${p.stock} × ${p.name} left in stock` }, { status: 409 });
      }
      lines.push({ productId: p.id, name: p.name, price: p.price, quantity });
    }

    const totalPrice = lines.reduce((sum, l) => sum + l.price * l.quantity, 0);
    const trackingNumber = generateTrackingNumber();

    const [order] = await db
      .insert(orders)
      .values({ customerName, phone, address, message: message || null, totalPrice, trackingNumber })
      .returning();

    const saved = await db
      .insert(orderItems)
      .values(lines.map((l) => ({ orderId: order.id, productId: l.productId, productName: l.name, quantity: l.quantity, price: l.price })))
      .returning();

    for (const l of lines) {
      const [p] = await db.select({ stock: products.stock }).from(products).where(eq(products.id, l.productId));
      if (p) await db.update(products).set({ stock: Math.max(0, p.stock - l.quantity) }).where(eq(products.id, l.productId));
    }

    return NextResponse.json({ order: { ...order, items: saved } }, { status: 201 });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}
