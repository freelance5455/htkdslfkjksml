import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { articles, favorites } from "@/db/schema";
import { fail, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { favoriteSchema } from "@/lib/validators";

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const rows = await db
      .select({ article: articles })
      .from(favorites)
      .innerJoin(articles, eq(articles.id, favorites.articleId))
      .where(eq(favorites.userId, auth.user.id))
      .orderBy(desc(favorites.createdAt));
    return ok({ articles: rows.map((r) => r.article) });
  } catch (err) {
    return serverError(err);
  }
}

/** Toggles a favourite. Returns the new state so the client can reconcile optimistic updates. */
export async function POST(req: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const parsed = await parseBody(req, favoriteSchema);
  if ("response" in parsed) return parsed.response;
  const { articleId } = parsed.data;

  try {
    const [article] = await db.select({ id: articles.id }).from(articles).where(eq(articles.id, articleId)).limit(1);
    if (!article) return fail("not_found", 404);

    const [existing] = await db
      .select({ articleId: favorites.articleId })
      .from(favorites)
      .where(and(eq(favorites.userId, auth.user.id), eq(favorites.articleId, articleId)))
      .limit(1);

    if (existing) {
      await db
        .delete(favorites)
        .where(and(eq(favorites.userId, auth.user.id), eq(favorites.articleId, articleId)));
      return ok({ articleId, favorited: false });
    }
    await db.insert(favorites).values({ userId: auth.user.id, articleId }).onConflictDoNothing();
    return ok({ articleId, favorited: true });
  } catch (err) {
    return serverError(err);
  }
}
