import { NextRequest } from "next/server";
import { db } from "@/db";
import { paperOrders, paperPositions } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { getTickers } from "@/lib/market";
import { closePosition, placeOrder } from "@/server/engine";
import { USER_KEY, notify } from "@/server/store";

export const dynamic = "force-dynamic";

type Body = {
  action?: "OPEN" | "CLOSE" | "CANCEL";
  symbol?: string;
  side?: "LONG" | "SHORT";
  orderType?: "MARKET" | "LIMIT";
  notional?: number;
  leverage?: number;
  limitPrice?: number | null;
  stopLoss?: number | null;
  takeProfit?: number | null;
  positionId?: number;
  orderId?: number;
  source?: string;
};

export async function POST(req: NextRequest) {
  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return Response.json({ ok: false, error: "בקשה לא תקינה" }, { status: 400 });
  }
  const action = body.action ?? "OPEN";

  try {
    if (action === "CANCEL") {
      const id = Number(body.orderId);
      if (!id) return Response.json({ ok: false, error: "חסר מזהה פקודה" }, { status: 400 });
      await db
        .update(paperOrders)
        .set({ status: "CANCELLED", updatedAt: new Date() })
        .where(and(eq(paperOrders.id, id), eq(paperOrders.userKey, USER_KEY)));
      return Response.json({ ok: true, message: "הפקודה בוטלה" });
    }

    if (action === "CLOSE") {
      const id = Number(body.positionId);
      if (!id) return Response.json({ ok: false, error: "חסר מזהה פוזיציה" }, { status: 400 });
      const rows = await db.select().from(paperPositions).where(eq(paperPositions.id, id)).limit(1);
      const pos = rows[0];
      if (!pos) return Response.json({ ok: false, error: "הפוזיציה לא נמצאה" }, { status: 404 });
      const tickers = await getTickers();
      const price = tickers.data.find((t) => t.symbol === pos.symbol)?.price ?? pos.entryPrice;
      const closed = await closePosition(id, price, "MANUAL");
      return Response.json({ ok: true, message: "הפוזיציה נסגרה", position: closed });
    }

    const symbol = String(body.symbol ?? "").toUpperCase();
    const side = body.side === "SHORT" ? "SHORT" : "LONG";
    if (!symbol) return Response.json({ ok: false, error: "חסר סימול" }, { status: 400 });
    const res = await placeOrder({
      symbol,
      side,
      orderType: body.orderType === "LIMIT" ? "LIMIT" : "MARKET",
      notional: Number(body.notional ?? 0),
      leverage: Number(body.leverage ?? 1),
      limitPrice: body.limitPrice ?? null,
      stopLoss: body.stopLoss ?? null,
      takeProfit: body.takeProfit ?? null,
      source: body.source ?? "MANUAL",
    });
    if (!res.ok) return Response.json(res, { status: 400 });
    await notify(
      `פקודת דמו נשלחה: ${symbol}`,
      `${side === "LONG" ? "לונג" : "שורט"} | ${body.orderType === "LIMIT" ? "לימיט" : "מרקט"} | מינוף ${body.leverage}x`,
      "sltp",
    );
    return Response.json({
      ...res,
      ok: true,
      message: body.orderType === "LIMIT" ? "פקודת לימיט נפתחה וממתינה לביצוע" : "העסקה בוצעה בהצלחה",
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "שגיאה בביצוע הפקודה" },
      { status: 500 },
    );
  }
}
