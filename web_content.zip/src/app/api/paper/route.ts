import { db } from "@/db";
import { paperOrders, paperPositions } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { getTickers } from "@/lib/market";
import { positionPnl, syncPaperAccount } from "@/server/engine";
import { USER_KEY, getAccount } from "@/server/store";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const sync = await syncPaperAccount();
    const account = await getAccount();
    const tickers = await getTickers();
    const priceOf = (s: string) => tickers.data.find((t) => t.symbol === s)?.price ?? 0;

    const openPositions = await db
      .select()
      .from(paperPositions)
      .where(and(eq(paperPositions.userKey, USER_KEY), eq(paperPositions.status, "OPEN")))
      .orderBy(desc(paperPositions.openedAt));
    const closedPositions = await db
      .select()
      .from(paperPositions)
      .where(and(eq(paperPositions.userKey, USER_KEY), eq(paperPositions.status, "CLOSED")))
      .orderBy(desc(paperPositions.closedAt))
      .limit(40);
    const orders = await db
      .select()
      .from(paperOrders)
      .where(eq(paperOrders.userKey, USER_KEY))
      .orderBy(desc(paperOrders.createdAt))
      .limit(50);

    const enriched = openPositions.map((p) => {
      const mark = priceOf(p.symbol) || p.entryPrice;
      const pnl = positionPnl(p.side, p.entryPrice, mark, p.qty);
      const pnlPct = p.margin > 0 ? (pnl / p.margin) * 100 : 0;
      return { ...p, markPrice: mark, unrealizedPnl: pnl, unrealizedPnlPct: pnlPct };
    });

    const usedMargin = enriched.reduce((s, p) => s + p.margin, 0);
    const unrealized = enriched.reduce((s, p) => s + p.unrealizedPnl, 0);
    const equity = account.balance + usedMargin + unrealized;

    return Response.json({
      ok: true,
      source: sync.source,
      degraded: sync.degraded,
      account: {
        ...account,
        usedMargin,
        unrealizedPnl: unrealized,
        equity,
        marginUsagePct: equity > 0 ? (usedMargin / equity) * 100 : 0,
      },
      positions: enriched,
      history: closedPositions,
      orders,
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "שגיאה בטעינת חשבון הדמו" },
      { status: 500 },
    );
  }
}
