import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { ok, parseBody, requireUser, serverError } from "@/lib/http";
import { logActivity } from "@/lib/notify";
import { articleSchema } from "@/lib/validators";
import { slugify } from "@/lib/utils";
import { ARTICLE_KINDS } from "@/lib/constants";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const kind = url.searchParams.get("kind");
    const category = url.searchParams.get("category");
    const q = url.searchParams.get("q")?.trim();
    const includeAll = url.searchParams.get("all") === "1";
    const user = await getSessionUser();
    const adminView = includeAll && user?.role === "admin";

    const conds = [];
    if (!adminView) conds.push(eq(articles.isPublished, true));
    if (kind && (ARTICLE_KINDS as readonly string[]).includes(kind)) conds.push(eq(articles.kind, kind));
    if (category) conds.push(eq(articles.category, category));
    if (q) {
      const pattern = `%${q.replace(/[%_]/g, "\\$&")}%`;
      conds.push(
        or(
          ilike(sql`${articles.title}::text`, pattern),
          ilike(sql`${articles.summary}::text`, pattern),
          ilike(sql`${articles.body}::text`, pattern),
        )!,
      );
    }

    const rows = await db
      .select()
      .from(articles)
      .where(conds.length ? and(...conds) : undefined)
      .orderBy(desc(articles.isFeatured), desc(articles.createdAt));
    return ok({ articles: rows });
  } catch (err) {
    return serverError(err);
  }
}

export async function POST(req: Request) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const parsed = await parseBody(req, articleSchema);
  if ("response" in parsed) return parsed.response;
  const d = parsed.data;

  try {
    const base = d.slug || slugify(d.title.en || d.title.fr) || `article-${Date.now()}`;
    const slug = (await db.select({ id: articles.id }).from(articles).where(eq(articles.slug, base)).limit(1)).length
      ? `${base}-${Date.now().toString(36)}`
      : base;
    const [row] = await db
      .insert(articles)
      .values({
        slug,
        kind: d.kind,
        category: d.category,
        title: d.title,
        summary: d.summary,
        body: d.body,
        emoji: d.emoji,
        readMinutes: d.readMinutes,
        reviewedBy: d.reviewedBy,
        sources: d.sources ?? [],
        reviewedAt: d.reviewedBy ? new Date() : null,
        isPublished: d.isPublished,
        isFeatured: d.isFeatured,
      })
      .returning();
    await logActivity(auth.user.id, "article.created", "article", row.id, slug);
    return ok(row, 201);
  } catch (err) {
    return serverError(err);
  }
}
