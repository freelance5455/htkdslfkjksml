import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { fail, isUuid, ok, parseBody, requireUser, serverError } from "@/lib/http";
import { logActivity } from "@/lib/notify";
import { articleSchema } from "@/lib/validators";

type Ctx = { params: Promise<{ id: string }> };

function matcher(key: string) {
  return isUuid(key) ? or(eq(articles.id, key), eq(articles.slug, key))! : eq(articles.slug, key);
}

export async function GET(_req: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const [row] = await db.select().from(articles).where(matcher(id)).limit(1);
    if (!row) return fail("not_found", 404);
    if (!row.isPublished) {
      const user = await getSessionUser();
      if (user?.role !== "admin") return fail("not_found", 404);
    }
    return ok(row);
  } catch (err) {
    return serverError(err);
  }
}

export async function PATCH(req: Request, ctx: Ctx) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const { id } = await ctx.params;
  const parsed = await parseBody(req, articleSchema.partial());
  if ("response" in parsed) return parsed.response;
  const d = parsed.data;

  try {
    const set: Partial<typeof articles.$inferInsert> = { updatedAt: new Date() };
    if (d.kind !== undefined) set.kind = d.kind;
    if (d.category !== undefined) set.category = d.category;
    if (d.title !== undefined) set.title = d.title;
    if (d.summary !== undefined) set.summary = d.summary;
    if (d.body !== undefined) set.body = d.body;
    if (d.emoji !== undefined) set.emoji = d.emoji;
    if (d.readMinutes !== undefined) set.readMinutes = d.readMinutes;
    if (d.sources !== undefined) set.sources = d.sources;
    if (d.isPublished !== undefined) set.isPublished = d.isPublished;
    if (d.isFeatured !== undefined) set.isFeatured = d.isFeatured;
    if (d.reviewedBy !== undefined) {
      set.reviewedBy = d.reviewedBy;
      set.reviewedAt = d.reviewedBy ? new Date() : null;
    }
    const [row] = await db.update(articles).set(set).where(matcher(id)).returning();
    if (!row) return fail("not_found", 404);
    await logActivity(auth.user.id, "article.updated", "article", row.id, row.slug);
    return ok(row);
  } catch (err) {
    return serverError(err);
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const auth = await requireUser(["admin"]);
  if ("response" in auth) return auth.response;
  const { id } = await ctx.params;
  try {
    const [row] = await db.delete(articles).where(matcher(id)).returning({ id: articles.id, slug: articles.slug });
    if (!row) return fail("not_found", 404);
    await logActivity(auth.user.id, "article.deleted", "article", row.id, row.slug);
    return ok({ ok: true });
  } catch (err) {
    return serverError(err);
  }
}
