import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { generations } from "@/db/schema";
import { ok, readJson, requireUser, toErrorResponse } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const url = new URL(request.url);
    const tool = url.searchParams.get("tool");
    const limit = Math.min(50, Math.max(1, Number(url.searchParams.get("limit") ?? 12)));
    const where = tool
      ? and(eq(generations.userId, auth.user.id), eq(generations.tool, tool))
      : eq(generations.userId, auth.user.id);

    const rows = await db
      .select()
      .from(generations)
      .where(where)
      .orderBy(desc(generations.createdAt))
      .limit(limit);

    return ok({ generations: rows });
  } catch (error) {
    return toErrorResponse(error);
  }
}

export async function DELETE(request: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const body = await readJson(request);
    const id = Number(body.id);
    if (!Number.isFinite(id)) return toErrorResponse(new Error("Invalid id"));
    await db.delete(generations).where(and(eq(generations.id, id), eq(generations.userId, auth.user.id)));
    return ok({});
  } catch (error) {
    return toErrorResponse(error);
  }
}
