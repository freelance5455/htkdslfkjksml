import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { savedItems } from "@/db/schema";
import { fail, ok, readJson, requireUser, toErrorResponse } from "@/lib/api";
import { TOOL_IDS, type ToolId } from "@/lib/ai/tools";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const url = new URL(request.url);
    const tool = url.searchParams.get("tool");
    const where = tool
      ? and(eq(savedItems.userId, auth.user.id), eq(savedItems.tool, tool))
      : eq(savedItems.userId, auth.user.id);
    const rows = await db
      .select()
      .from(savedItems)
      .where(where)
      .orderBy(desc(savedItems.createdAt))
      .limit(100);
    return ok({ items: rows });
  } catch (error) {
    return toErrorResponse(error);
  }
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const body = await readJson(request);
    const tool = String(body.tool ?? "") as ToolId;
    if (!TOOL_IDS.includes(tool)) return fail("Unknown tool.");
    const title = String(body.title ?? "").trim().slice(0, 200);
    const text = String(body.text ?? "").trim().slice(0, 20_000);
    if (!text) return fail("Nothing to save yet.");
    const [item] = await db
      .insert(savedItems)
      .values({
        userId: auth.user.id,
        tool,
        title: title || "Saved snippet",
        body: text,
        generationId: Number.isFinite(Number(body.generationId)) ? Number(body.generationId) : null,
        meta: typeof body.meta === "object" && body.meta ? (body.meta as Record<string, unknown>) : {},
      })
      .returning();
    return ok({ item });
  } catch (error) {
    return toErrorResponse(error);
  }
}
