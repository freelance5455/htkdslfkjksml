import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { savedItems } from "@/db/schema";
import { fail, ok, readJson, requireUser, toErrorResponse } from "@/lib/api";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, ctx: Ctx) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const { id } = await ctx.params;
    const itemId = Number(id);
    if (!Number.isFinite(itemId)) return fail("Invalid item.");
    const body = await readJson(request);
    const patch: { title?: string; body?: string; updatedAt: Date } = { updatedAt: new Date() };
    if (typeof body.title === "string") patch.title = body.title.slice(0, 200);
    if (typeof body.body === "string") patch.body = body.body.slice(0, 20_000);
    const [updated] = await db
      .update(savedItems)
      .set(patch)
      .where(and(eq(savedItems.id, itemId), eq(savedItems.userId, auth.user.id)))
      .returning();
    if (!updated) return fail("Saved item not found.", 404);
    return ok({ item: updated });
  } catch (error) {
    return toErrorResponse(error);
  }
}

export async function DELETE(_request: Request, ctx: Ctx) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const { id } = await ctx.params;
    const itemId = Number(id);
    if (!Number.isFinite(itemId)) return fail("Invalid item.");
    await db.delete(savedItems).where(and(eq(savedItems.id, itemId), eq(savedItems.userId, auth.user.id)));
    return ok({});
  } catch (error) {
    return toErrorResponse(error);
  }
}
