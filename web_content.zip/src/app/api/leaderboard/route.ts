import { NextResponse } from "next/server";
import { db } from "@/db";
import { minds } from "@/db/schema";
import { desc } from "drizzle-orm";
import { titleFor } from "@/lib/ranks";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(minds).orderBy(desc(minds.mindIndex)).limit(50);
  return NextResponse.json({
    minds: rows.map((m) => ({
      id: m.id,
      alias: m.alias,
      mindIndex: m.mindIndex,
      creativity: m.creativity,
      imagination: m.imagination,
      pattern: m.pattern,
      bestRing: m.bestRing,
      bestStreak: m.bestStreak,
      trialsSolved: m.trialsSolved,
      isBenchmark: m.isBenchmark,
      title: titleFor(m.mindIndex),
    })),
  });
}
