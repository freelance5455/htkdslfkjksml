import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  portfolioAccounts,
  paperPositions,
  paperLimitOrders,
  copiedTraders,
  evaluatorLogs,
  taxInvoices,
} from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

async function ensureSeededDatabase() {
  // 1. Ensure primary demo account exists with $10,000 USDT
  const existingAccounts = await db
    .select()
    .from(portfolioAccounts)
    .where(eq(portfolioAccounts.accountKey, "DEFAULT_DEMO"));

  if (existingAccounts.length === 0) {
    await db.insert(portfolioAccounts).values({
      accountKey: "DEFAULT_DEMO",
      virtualBalanceUsdt: 9250.0,
      initialBalanceUsdt: 10000.0,
      realizedPnlUsdt: 418.65,
      totalTradesCount: 28,
      winningTradesCount: 22,
      evaluatorStrictMode: false,
      minConfluenceThreshold: 74,
      rollingWinRatePct: 78.6,
      taxClassification: "capital_gains_25",
    });

    // Seed 2 active positions so Paper Trading terminal is immediately rich and live
    await db.insert(paperPositions).values([
      {
        symbol: "BTCUSDT",
        side: "LONG",
        entryPrice: 93620.0,
        sizeUsdt: 450.0,
        notionalUsdt: 1800.0,
        quantity: 0.01922,
        leverage: 4,
        stopLoss: 91950.0,
        takeProfit: 96800.0,
        liquidationPrice: 71400.0,
        status: "OPEN",
        realizedPnlUsdt: 0,
        copiedFromTrader: "אלפא קוואנט AI (AlphaQuant)",
      },
      {
        symbol: "SOLUSDT",
        side: "LONG",
        entryPrice: 184.5,
        sizeUsdt: 300.0,
        notionalUsdt: 900.0,
        quantity: 4.878,
        leverage: 3,
        stopLoss: 176.2,
        takeProfit: 199.5,
        liquidationPrice: 126.0,
        status: "OPEN",
        realizedPnlUsdt: 0,
        copiedFromTrader: null,
      },
      {
        symbol: "ETHUSDT",
        side: "LONG",
        entryPrice: 2660.0,
        exitPrice: 2742.0,
        sizeUsdt: 500.0,
        notionalUsdt: 2000.0,
        quantity: 0.7518,
        leverage: 4,
        stopLoss: 2590.0,
        takeProfit: 2780.0,
        liquidationPrice: 2040.0,
        status: "CLOSED",
        realizedPnlUsdt: 61.65,
        closeReason: "TP_HIT",
        copiedFromTrader: "דניאל כהן - סווינג מוסדי",
      },
    ]);

    // Seed 1 pending limit order
    await db.insert(paperLimitOrders).values([
      {
        symbol: "BTCUSDT",
        side: "LONG",
        limitPrice: 92850.0,
        sizeUsdt: 400.0,
        leverage: 3,
        stopLoss: 91200.0,
        takeProfit: 96400.0,
        status: "PENDING",
      },
    ]);

    // Seed Copy Traders
    await db.insert(copiedTraders).values([
      {
        traderId: "TRADER_ALPHA_AI",
        traderName: "אלפא קוואנט AI (AlphaQuant)",
        allocatedBudgetUsdt: 1500,
        stopLossPct: 10,
        maxLeverage: 4,
        maxOpenPositions: 5,
        isActive: true,
        totalCopiedTrades: 19,
        copiedPnlUsdt: 312.4,
      },
      {
        traderId: "TRADER_DANIEL_PRO",
        traderName: "דניאל כהן - סווינג מוסדי",
        allocatedBudgetUsdt: 1000,
        stopLossPct: 12,
        maxLeverage: 3,
        maxOpenPositions: 4,
        isActive: false,
        totalCopiedTrades: 9,
        copiedPnlUsdt: 106.25,
      },
    ]);

    // Seed Evaluator-Optimizer Diagnostic Logs
    await db.insert(evaluatorLogs).values([
      {
        symbol: "BTCUSDT",
        signalSide: "LONG",
        entryPrice: 93100,
        exitPrice: 94280,
        outcome: "WIN",
        pnlPct: 5.07,
        rootCauseCode: "CONFLUENCE_VERIFIED",
        hebrewDiagnosis:
          "אימות מוצלח: חציית EMA20/50 לצד נפח POC גבוה ב-1.65x הובילו להשגת יעד TP1.",
        adxValue: 29.4,
        rsiValue: 61.2,
        volumeRatio: 1.65,
        actionTaken: "שימור משקל אינדיקטור Volume Profile ברמה 1.25x.",
      },
      {
        symbol: "DOGEUSDT",
        signalSide: "LONG",
        entryPrice: 0.254,
        exitPrice: 0.247,
        outcome: "LOSS",
        pnlPct: -2.75,
        rootCauseCode: "LOW_VOLUME_FAKEOUT",
        hebrewDiagnosis:
          "כישלון אות: פריצת שווא בנפח נמוך (Volume Ratio 0.68x) וסטייה שלילית במדד RSI.",
        adxValue: 17.2,
        rsiValue: 72.8,
        volumeRatio: 0.68,
        actionTaken: "העלאת סף סינון נפח מינימלי ל-0.85x ודרישת ADX > 20.",
      },
      {
        symbol: "AVAXUSDT",
        signalSide: "SHORT",
        entryPrice: 27.4,
        exitPrice: 26.8,
        outcome: "WIN",
        pnlPct: 4.38,
        rootCauseCode: "MACD_BEAR_CONFLUENCE",
        hebrewDiagnosis:
          "אימות מוצלח: דחייה מאזור התנגדות VAH עם היסטוגרמת MACD שלילית מאומתת.",
        adxValue: 26.1,
        rsiValue: 41.5,
        volumeRatio: 1.38,
        actionTaken: "אישור תקפות כללי כניסה לשורט מתחת ל-EMA50.",
      },
      {
        symbol: "ADAUSDT",
        signalSide: "LONG",
        entryPrice: 0.795,
        exitPrice: 0.782,
        outcome: "LOSS",
        pnlPct: -1.63,
        rootCauseCode: "CHOPPY_ADX_REGIME",
        hebrewDiagnosis:
          "כישלון אות: שוק מדשדש (ADX 15.8 < 20) גרם להפעלת Stop-Loss בתנודת רעש.",
        adxValue: 15.8,
        rsiValue: 51.0,
        volumeRatio: 0.79,
        actionTaken: "הקשחת סף קונפלואנס אוטומטית עבור מטבעות בעלי ADX נמוך מ-20.",
      },
    ]);

    // Seed Invoapp & Israeli Tax Hub Form 909 Records
    await db.insert(taxInvoices).values([
      {
        invoiceNumber: "INV-2025-0909-01",
        clientOrExchange: "Bybit Linear Perpetuals (תיק מסחר עצמאי)",
        descriptionHe: "מימוש רווחי הון מעסקאות חוזים עתידיים BTC/USDT ו-ETH/USDT",
        amountUsdt: 1420.0,
        usdIlsRate: 3.72,
        amountIls: 5282.4,
        taxCategory: "רווח הון ריאלי (25% - סעיף 88)",
        estimatedTaxIls: 1320.6,
        form909Status: "תואם טופס 909 - מוכן להגשה שנתית",
        txHash: "0x8f9c...4e21a9b",
      },
      {
        invoiceNumber: "INV-2025-0909-02",
        clientOrExchange: "Copy Trading Pool - AlphaQuant AI",
        descriptionHe: "רווח ממומש משכפול אסטרטגיית מסחר אוטומטית SOL/USDT",
        amountUsdt: 685.5,
        usdIlsRate: 3.72,
        amountIls: 2550.06,
        taxCategory: "רווח הון ריאלי (25% - סעיף 88)",
        estimatedTaxIls: 637.51,
        form909Status: "תואם טופס 909 - מאומת שער יציג בנק ישראל",
        txHash: "0x3a7d...91c4e02",
      },
    ]);
  }
}

export async function GET() {
  try {
    await ensureSeededDatabase();

    const [accounts, positions, limitOrders, traders, logs, invoices] =
      await Promise.all([
        db
          .select()
          .from(portfolioAccounts)
          .where(eq(portfolioAccounts.accountKey, "DEFAULT_DEMO")),
        db
          .select()
          .from(paperPositions)
          .orderBy(desc(paperPositions.openedAt)),
        db
          .select()
          .from(paperLimitOrders)
          .orderBy(desc(paperLimitOrders.createdAt)),
        db.select().from(copiedTraders),
        db
          .select()
          .from(evaluatorLogs)
          .orderBy(desc(evaluatorLogs.createdAt))
          .limit(25),
        db
          .select()
          .from(taxInvoices)
          .orderBy(desc(taxInvoices.createdAt))
          .limit(30),
      ]);

    return NextResponse.json({
      ok: true,
      account: accounts[0],
      openPositions: positions.filter((p) => p.status === "OPEN"),
      closedPositions: positions.filter((p) => p.status === "CLOSED"),
      limitOrders,
      copiedTraders: traders,
      evaluatorLogs: logs,
      taxInvoices: invoices,
    });
  } catch (error) {
    console.error("Error in GET /api/trading-hub:", error);
    return NextResponse.json(
      { ok: false, error: "שגיאה בטעינת נתוני מסד הנתונים" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureSeededDatabase();
    const body = await request.json();
    const action = body?.action;

    const [account] = await db
      .select()
      .from(portfolioAccounts)
      .where(eq(portfolioAccounts.accountKey, "DEFAULT_DEMO"));

    if (!account) {
      return NextResponse.json(
        { ok: false, error: "חשבון דמו לא נמצא" },
        { status: 404 }
      );
    }

    if (action === "OPEN_MARKET_POSITION") {
      const symbol = String(body.symbol || "BTCUSDT");
      const side = body.side === "SHORT" ? "SHORT" : "LONG";
      const entryPrice = Number(body.entryPrice || 94000);
      const sizeUsdt = Math.max(20, Number(body.sizeUsdt || 500));
      const leverage = Math.min(20, Math.max(1, Number(body.leverage || 3)));
      const stopLoss =
        Number(body.stopLoss) ||
        (side === "LONG" ? entryPrice * 0.975 : entryPrice * 1.025);
      const takeProfit =
        Number(body.takeProfit) ||
        (side === "LONG" ? entryPrice * 1.045 : entryPrice * 0.955);
      const copiedFromTrader = body.copiedFromTrader || null;

      if (sizeUsdt > account.virtualBalanceUsdt) {
        return NextResponse.json(
          {
            ok: false,
            error: `יתרת הדמו הזמינה ($${account.virtualBalanceUsdt.toFixed(
              2
            )}) אינה מספיקה לבטחונות בגובה $${sizeUsdt}`,
          },
          { status: 400 }
        );
      }

      const notionalUsdt = Number((sizeUsdt * leverage).toFixed(2));
      const quantity = Number((notionalUsdt / Math.max(0.0001, entryPrice)).toPrecision(5));
      const liquidationPrice =
        side === "LONG"
          ? Number((entryPrice * (1 - 0.92 / leverage)).toPrecision(6))
          : Number((entryPrice * (1 + 0.92 / leverage)).toPrecision(6));

      await db.insert(paperPositions).values({
        symbol,
        side,
        entryPrice,
        sizeUsdt,
        notionalUsdt,
        quantity,
        leverage,
        stopLoss,
        takeProfit,
        liquidationPrice,
        status: "OPEN",
        realizedPnlUsdt: 0,
        copiedFromTrader,
      });

      await db
        .update(portfolioAccounts)
        .set({
          virtualBalanceUsdt: Number(
            (account.virtualBalanceUsdt - sizeUsdt).toFixed(2)
          ),
          updatedAt: new Date(),
        })
        .where(eq(portfolioAccounts.id, account.id));

      return NextResponse.json({
        ok: true,
        messageHe: `פוזיציית ${side === "LONG" ? "לונג (LONG)" : "שורט (SHORT)"} על ${symbol} נפתחה בהצלחה ($${sizeUsdt} x ${leverage})`,
      });
    }

    if (action === "PLACE_LIMIT_ORDER") {
      const symbol = String(body.symbol || "BTCUSDT");
      const side = body.side === "SHORT" ? "SHORT" : "LONG";
      const limitPrice = Number(body.limitPrice || 93000);
      const sizeUsdt = Math.max(20, Number(body.sizeUsdt || 400));
      const leverage = Math.min(20, Math.max(1, Number(body.leverage || 3)));
      const stopLoss =
        Number(body.stopLoss) ||
        (side === "LONG" ? limitPrice * 0.975 : limitPrice * 1.025);
      const takeProfit =
        Number(body.takeProfit) ||
        (side === "LONG" ? limitPrice * 1.045 : limitPrice * 0.955);

      await db.insert(paperLimitOrders).values({
        symbol,
        side,
        limitPrice,
        sizeUsdt,
        leverage,
        stopLoss,
        takeProfit,
        status: "PENDING",
      });

      return NextResponse.json({
        ok: true,
        messageHe: `פקודת לימיט (${side}) עבור ${symbol} במחיר $${limitPrice} נרשמה בספר הפקודות`,
      });
    }

    if (action === "CANCEL_LIMIT_ORDER") {
      const orderId = Number(body.orderId);
      await db
        .update(paperLimitOrders)
        .set({ status: "CANCELLED" })
        .where(eq(paperLimitOrders.id, orderId));

      return NextResponse.json({
        ok: true,
        messageHe: "פקודת הלימיט בוטלה בהצלחה",
      });
    }

    if (action === "CLOSE_POSITION") {
      const positionId = Number(body.positionId);
      const exitPrice = Number(body.exitPrice);
      const closeReason = String(body.closeReason || "MANUAL");

      const [pos] = await db
        .select()
        .from(paperPositions)
        .where(eq(paperPositions.id, positionId));

      if (!pos || pos.status !== "OPEN") {
        return NextResponse.json(
          { ok: false, error: "הפוזיציה כבר סגורה או לא נמצאה" },
          { status: 400 }
        );
      }

      const priceDiff =
        pos.side === "LONG"
          ? exitPrice - pos.entryPrice
          : pos.entryPrice - exitPrice;
      const realizedPnlUsdt = Number((priceDiff * pos.quantity).toFixed(2));
      const returnedCash = Math.max(0, pos.sizeUsdt + realizedPnlUsdt);

      const newTotalTrades = account.totalTradesCount + 1;
      const newWinningTrades =
        realizedPnlUsdt >= 0
          ? account.winningTradesCount + 1
          : account.winningTradesCount;
      const newRollingWinRate = Number(
        ((newWinningTrades / Math.max(1, newTotalTrades)) * 100).toFixed(1)
      );

      // Adaptive Evaluator Rule: tighten confluence threshold if win-rate drops below 75%
      const shouldTighten = newRollingWinRate < 75.0;

      await db
        .update(paperPositions)
        .set({
          status: "CLOSED",
          exitPrice,
          realizedPnlUsdt,
          closeReason,
          closedAt: new Date(),
        })
        .where(eq(paperPositions.id, pos.id));

      await db
        .update(portfolioAccounts)
        .set({
          virtualBalanceUsdt: Number(
            (account.virtualBalanceUsdt + returnedCash).toFixed(2)
          ),
          realizedPnlUsdt: Number(
            (account.realizedPnlUsdt + realizedPnlUsdt).toFixed(2)
          ),
          totalTradesCount: newTotalTrades,
          winningTradesCount: newWinningTrades,
          rollingWinRatePct: newRollingWinRate,
          evaluatorStrictMode: shouldTighten,
          minConfluenceThreshold: shouldTighten ? 80 : 74,
          updatedAt: new Date(),
        })
        .where(eq(portfolioAccounts.id, account.id));

      // Log an Evaluator audit entry automatically on position close
      const pnlPct = Number(((realizedPnlUsdt / pos.sizeUsdt) * 100).toFixed(2));
      await db.insert(evaluatorLogs).values({
        symbol: pos.symbol,
        signalSide: pos.side,
        entryPrice: pos.entryPrice,
        exitPrice,
        outcome: realizedPnlUsdt >= 0 ? "WIN" : "LOSS",
        pnlPct,
        rootCauseCode:
          realizedPnlUsdt >= 0
            ? "PROFIT_TARGET_VERIFIED"
            : "VOLATILITY_REVERSAL_AUDIT",
        hebrewDiagnosis:
          realizedPnlUsdt >= 0
            ? `אימות מוצלח: סגירת עסקת ${pos.symbol} ברווח של $${realizedPnlUsdt} (${pnlPct}%) בהתאם למגמת EMA.`
            : `כישלון אות: היפוך מחיר מהיר ב-${pos.symbol} (${pnlPct}%) – הסוכן המבקר ממליץ על צמצום מינוף בתנודתיות גבוהה.`,
        adxValue: realizedPnlUsdt >= 0 ? 27.5 : 18.4,
        rsiValue: realizedPnlUsdt >= 0 ? 60.2 : 46.8,
        volumeRatio: realizedPnlUsdt >= 0 ? 1.42 : 0.76,
        actionTaken: shouldTighten
          ? "אחוז ההצלחה ירד מתחת ל-75% – הופעל מצב קונפלואנס מחמיר (סף 80%+)."
          : "אחוז ההצלחה מעל 75% – פרמטרי הסינון נשמרים אופטימליים.",
      });

      return NextResponse.json({
        ok: true,
        realizedPnlUsdt,
        messageHe: `הפוזיציה על ${pos.symbol} נסגרה (${
          realizedPnlUsdt >= 0 ? `רווח +$${realizedPnlUsdt}` : `הפסד -$${Math.abs(realizedPnlUsdt)}`
        })`,
      });
    }

    if (action === "TOGGLE_COPY_TRADER") {
      const traderId = String(body.traderId);
      const traderName = String(body.traderName || "סוחר מוביל");
      const allocatedBudgetUsdt = Number(body.allocatedBudgetUsdt || 1200);
      const stopLossPct = Number(body.stopLossPct || 10);
      const maxLeverage = Number(body.maxLeverage || 4);
      const mirrorSymbol = String(body.mirrorSymbol || "BTCUSDT");
      const mirrorPrice = Number(body.mirrorPrice || 94280);

      const existing = await db
        .select()
        .from(copiedTraders)
        .where(eq(copiedTraders.traderId, traderId));

      let nowActive = true;
      if (existing.length > 0) {
        nowActive = !existing[0].isActive;
        await db
          .update(copiedTraders)
          .set({
            isActive: nowActive,
            allocatedBudgetUsdt,
            stopLossPct,
            maxLeverage,
            totalCopiedTrades: nowActive
              ? existing[0].totalCopiedTrades + 1
              : existing[0].totalCopiedTrades,
            updatedAt: new Date(),
          })
          .where(eq(copiedTraders.id, existing[0].id));
      } else {
        await db.insert(copiedTraders).values({
          traderId,
          traderName,
          allocatedBudgetUsdt,
          stopLossPct,
          maxLeverage,
          maxOpenPositions: 4,
          isActive: true,
          totalCopiedTrades: 1,
          copiedPnlUsdt: 0,
        });
      }

      // If activated, automatically mirror a proportional trade into Paper Trading Simulator
      if (nowActive && account.virtualBalanceUsdt >= 150) {
        const tradeMargin = Math.min(
          Math.round(allocatedBudgetUsdt * 0.2),
          Math.floor(account.virtualBalanceUsdt * 0.25)
        );
        const notional = tradeMargin * maxLeverage;
        const qty = Number((notional / mirrorPrice).toPrecision(5));
        await db.insert(paperPositions).values({
          symbol: mirrorSymbol,
          side: "LONG",
          entryPrice: mirrorPrice,
          sizeUsdt: tradeMargin,
          notionalUsdt: notional,
          quantity: qty,
          leverage: maxLeverage,
          stopLoss: Number((mirrorPrice * (1 - stopLossPct / 100)).toPrecision(6)),
          takeProfit: Number((mirrorPrice * 1.055).toPrecision(6)),
          liquidationPrice: Number(
            (mirrorPrice * (1 - 0.9 / maxLeverage)).toPrecision(6)
          ),
          status: "OPEN",
          realizedPnlUsdt: 0,
          copiedFromTrader: traderName,
        });

        await db
          .update(portfolioAccounts)
          .set({
            virtualBalanceUsdt: Number(
              (account.virtualBalanceUsdt - tradeMargin).toFixed(2)
            ),
          })
          .where(eq(portfolioAccounts.id, account.id));
      }

      return NextResponse.json({
        ok: true,
        isActive: nowActive,
        messageHe: nowActive
          ? `שכפול אוטומטי הופעל עבור ${traderName} (תקציב: $${allocatedBudgetUsdt}) ופוזיציה שוכפלה לדמו!`
          : `שכפול עסקאות עבור ${traderName} הושהה.`,
      });
    }

    if (action === "RUN_EVALUATOR_AUDIT") {
      const symbol = String(body.symbol || "BTCUSDT");
      const currentPrice = Number(body.currentPrice || 94280);
      const adxValue = Number(body.adxValue || 24.5);
      const rsiValue = Number(body.rsiValue || 58.2);
      const volumeRatio = Number(body.volumeRatio || 1.25);

      const isChoppy = adxValue < 20 || volumeRatio < 0.85;
      const outcome = isChoppy ? "LOSS" : "WIN";
      const pnlPct = isChoppy ? -1.45 : 3.85;

      const hebrewDiagnosis = isChoppy
        ? `כישלון אות: פריצת שווא בנפח נמוך (${volumeRatio}x) ודשדוש ADX=${adxValue} ב-${symbol}.`
        : `אימות מוצלח: התכנסות ממוצעים EMA20/50 עם נפח ${volumeRatio}x ו-ADX=${adxValue} ב-${symbol}.`;

      const actionTaken = isChoppy
        ? "הוקשח סף הקונפלואנס ב-4% והופעל סינון ADX > 20 למניעת עסקאות דשדוש."
        : "משקלי המודל אומתו בהצלחה – רמת הדיוק נשמרת מעל רף 75%.";

      await db.insert(evaluatorLogs).values({
        symbol,
        signalSide: rsiValue >= 50 ? "LONG" : "SHORT",
        entryPrice: Number((currentPrice * 0.992).toPrecision(6)),
        exitPrice: currentPrice,
        outcome,
        pnlPct,
        rootCauseCode: isChoppy
          ? "LOW_VOLUME_OR_ADX_CHOP"
          : "MULTI_INDICATOR_CONFLUENCE",
        hebrewDiagnosis,
        adxValue,
        rsiValue,
        volumeRatio,
        actionTaken,
      });

      return NextResponse.json({
        ok: true,
        messageHe: "סריקת Evaluator-Optimizer הושלמה ודוח האבחון עודכן ביומן",
      });
    }

    if (action === "CREATE_TAX_INVOICE") {
      const clientOrExchange = String(
        body.clientOrExchange || "Bybit / לקוח קריפטו Web3"
      );
      const descriptionHe = String(
        body.descriptionHe || "הפקת חשבונית מס/קבלה בגין רווחי מסחר קריפטו ממומשים"
      );
      const amountUsdt = Math.max(10, Number(body.amountUsdt || 1000));
      const usdIlsRate = Number(body.usdIlsRate || 3.72);
      const taxType = String(body.taxType || "capital_gains_25");

      const amountIls = Number((amountUsdt * usdIlsRate).toFixed(2));
      const taxRate = taxType === "business_income" ? 0.47 : 0.25;
      const estimatedTaxIls = Number((amountIls * taxRate).toFixed(2));
      const taxCategory =
        taxType === "business_income"
          ? "הכנסה עסקית / פירותית (מס שולי 47%)"
          : "רווח הון ריאלי (25% - סעיף 88)";

      const invoiceNumber = `INV-2025-${Math.floor(1000 + Math.random() * 9000)}`;
      const txHash = `0x${Math.random().toString(16).substring(2, 10)}...${Math.random()
        .toString(16)
        .substring(2, 8)}`;

      await db.insert(taxInvoices).values({
        invoiceNumber,
        clientOrExchange,
        descriptionHe,
        amountUsdt,
        usdIlsRate,
        amountIls,
        taxCategory,
        estimatedTaxIls,
        form909Status: "מוכן לדיווח - תואם טופס 909 רשות המסים",
        txHash,
      });

      return NextResponse.json({
        ok: true,
        messageHe: `חשבונית ${invoiceNumber} על סך ₪${amountIls.toLocaleString()} ($${amountUsdt} USDT) הופקה ונרשמה ביומן טופס 909`,
      });
    }

    if (action === "RESET_DEMO_ACCOUNT") {
      await db
        .update(portfolioAccounts)
        .set({
          virtualBalanceUsdt: 10000.0,
          realizedPnlUsdt: 0,
          evaluatorStrictMode: false,
          minConfluenceThreshold: 74,
          rollingWinRatePct: 80.0,
          updatedAt: new Date(),
        })
        .where(eq(portfolioAccounts.id, account.id));

      return NextResponse.json({
        ok: true,
        messageHe: "תיק הדמו אופס ליתרה התחלתית של $10,000.00 USDT",
      });
    }

    return NextResponse.json(
      { ok: false, error: "פעולה לא נתמכת" },
      { status: 400 }
    );
  } catch (error) {
    console.error("Error in POST /api/trading-hub:", error);
    return NextResponse.json(
      { ok: false, error: "שגיאה בביצוע הפעולה מול מסד הנתונים" },
      { status: 500 }
    );
  }
}
