import { evaluatorSnapshot, runEvaluator } from "@/server/engine";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET() {
  try {
    const snap = await evaluatorSnapshot();
    return Response.json({ ok: true, ...snap });
  } catch (err) {
    return Response.json(
      { ok: false, logs: [], error: err instanceof Error ? err.message : "שגיאה בטעינת יומן האבחונים" },
      { status: 500 },
    );
  }
}

export async function POST() {
  try {
    const result = await runEvaluator();
    const snap = await evaluatorSnapshot();
    return Response.json({
      ok: true,
      message: `הסריקה העצמית הושלמה - נבדקו ${result.audited} אותות`,
      ...result,
      ...snap,
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "שגיאה בהרצת סוכן הבקרה" },
      { status: 500 },
    );
  }
}
