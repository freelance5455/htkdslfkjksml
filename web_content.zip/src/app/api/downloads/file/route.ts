import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { downloads } from "@/db/schema";

export const dynamic = "force-dynamic";

/** Скачивание файла через сервер с записью в менеджер загрузок */
export async function GET(req: NextRequest) {
  const url = req.nextUrl.searchParams.get("url");
  const profileId = Number(req.nextUrl.searchParams.get("profileId") || 0);
  if (!url) return new NextResponse("url required", { status: 400 });
  try {
    const r = await fetch(url, { headers: { "user-agent": "Mozilla/5.0 NovaBrowser" }, signal: AbortSignal.timeout(60000) });
    if (!r.ok) return new NextResponse("Fetch failed: " + r.status, { status: 502 });
    const u = new URL(r.url || url);
    let filename = decodeURIComponent(u.pathname.split("/").pop() || "download");
    const cd = r.headers.get("content-disposition");
    const fm = cd?.match(/filename\*?=(?:UTF-8'')?["']?([^"';]+)/i);
    if (fm) filename = decodeURIComponent(fm[1]);
    if (!filename) filename = "download";
    const mime = r.headers.get("content-type") || "application/octet-stream";
    const size = Number(r.headers.get("content-length") || 0);
    await db.insert(downloads).values({ url, filename, size, mime, status: "completed", profileId });
    return new NextResponse(r.body, {
      headers: {
        "content-type": mime,
        "content-disposition": `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`,
        ...(size ? { "content-length": String(size) } : {}),
      },
    });
  } catch (e) {
    await db.insert(downloads).values({ url, filename: url.split("/").pop() || "file", status: "failed", profileId });
    return new NextResponse("Error: " + (e instanceof Error ? e.message : "unknown"), { status: 500 });
  }
}
