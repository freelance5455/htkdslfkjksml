import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { downloads } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const profileId = Number(req.nextUrl.searchParams.get("profileId") || 0);
  const rows = await db.select().from(downloads).where(eq(downloads.profileId, profileId)).orderBy(desc(downloads.createdAt)).limit(100);
  return NextResponse.json(rows);
}

export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  const profileId = Number(req.nextUrl.searchParams.get("profileId") || 0);
  if (id) await db.delete(downloads).where(eq(downloads.id, Number(id)));
  else await db.delete(downloads).where(eq(downloads.profileId, profileId));
  return NextResponse.json({ ok: true });
}
