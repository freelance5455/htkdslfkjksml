import { NextRequest } from "next/server";
import { getFundamentals, getKlines, getTicker } from "@/lib/market";
import { analyzeSymbol } from "@/lib/signals";
import { metaFor } from "@/lib/universe";
import { getRules } from "@/server/store";

export const dynamic = "force-dynamic";

/** מחקר עומק בסגנון Messari - נתוני יסוד + סיכום פרוטוקול אוטומטי */
export async function GET(req: NextRequest) {
  const symbol = (req.nextUrl.searchParams.get("symbol") ?? "BTCUSDT").toUpperCase();
  const meta = metaFor(symbol);
  try {
    const [fund, kl, ticker, rules] = await Promise.all([
      getFundamentals(symbol),
      getKlines(symbol, "1d", 120),
      getTicker(symbol),
      getRules(),
    ]);
    const analysis = analyzeSymbol(symbol, kl.data, ticker, rules, kl.source);
    const f = fund.data;

    const summaryParts: string[] = [];
    if (f) {
      summaryParts.push(
        `${meta.hebrewName} (${meta.base}) נסחר בשווי שוק של ${(f.marketCap / 1e9).toFixed(2)} מיליארד דולר`,
      );
      summaryParts.push(
        f.volumeToMcap > 10
          ? `נזילות גבוהה מאוד - מחזור יומי של ${f.volumeToMcap.toFixed(1)}% משווי השוק`
          : `נזילות ${f.volumeToMcap > 4 ? "תקינה" : "נמוכה"} - מחזור של ${f.volumeToMcap.toFixed(1)}% משווי השוק`,
      );
      summaryParts.push(
        f.supplyInflation > 15
          ? `לחץ דילול משמעותי: ${f.supplyInflation.toFixed(1)}% מההיצע טרם שוחרר`
          : `אינפלציית היצע נמוכה (${f.supplyInflation.toFixed(1)}%)`,
      );
      summaryParts.push(
        f.developerActivity > 100
          ? `פעילות פיתוח חזקה (${f.developerActivity} קומיטים ב-4 שבועות)`
          : `פעילות פיתוח מתונה (${f.developerActivity} קומיטים ב-4 שבועות)`,
      );
      if (analysis) {
        summaryParts.push(
          `הקריאה הטכנית הנוכחית: ${analysis.directionHe} בביטחון ${analysis.confidence.toFixed(0)}%`,
        );
      }
    }

    return Response.json({
      ok: Boolean(f),
      symbol,
      meta,
      fundamentals: f,
      analysis,
      source: fund.source,
      degraded: fund.degraded,
      aiSummary: summaryParts.join(". ") || "אין נתוני יסוד זמינים כרגע",
      error: f ? null : fund.error ?? "אין נתוני יסוד",
    });
  } catch (err) {
    return Response.json(
      { ok: false, fundamentals: null, error: err instanceof Error ? err.message : "שגיאת מחקר" },
      { status: 500 },
    );
  }
}
