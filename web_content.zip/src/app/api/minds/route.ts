import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { minds } from "@/db/schema";
import { eq } from "drizzle-orm";
import { mindIndex, PILLAR_CAP } from "@/lib/scoring";
import { titleFor } from "@/lib/ranks";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const alias = typeof body?.alias === "string" ? body.alias.trim().slice(0, 32) : "";
  if (!alias) return NextResponse.json({ error: "Alias required" }, { status: 400 });

  const [mind] = await db.insert(minds).values({ alias }).returning();
  return NextResponse.json({ mind: serialize(mind) });
}

export async function GET(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const rows = await db.select().from(minds).where(eq(minds.id, id));
  if (!rows.length) return NextResponse.json({ error: "Mind not found" }, { status: 404 });
  return NextResponse.json({ mind: serialize(rows[0]) });
}

/* PUT: ring ascent — {id, completedRing} */
export async function PUT(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const { id, completedRing } = body ?? {};
  if (!id || typeof completedRing !== "number") {
    return NextResponse.json({ error: "invalid payload" }, { status: 400 });
  }
  const rows = await db.select().from(minds).where(eq(minds.id, id));
  if (!rows.length) return NextResponse.json({ error: "Mind not found" }, { status: 404 });
  const m = rows[0];
  const bestRing = Math.max(m.bestRing, completedRing);
  const idx = mindIndex(m.creativity, m.imagination, m.pattern, bestRing, m.bestStreak);
  await db.update(minds).set({ bestRing, mindIndex: idx, updatedAt: new Date() }).where(eq(minds.id, id));
  return NextResponse.json({ ok: true, bestRing });
}

export function serialize(m: typeof minds.$inferSelect) {
  return {
    id: m.id,
    alias: m.alias,
    creativity: Math.min(m.creativity, PILLAR_CAP),
    imagination: Math.min(m.imagination, PILLAR_CAP),
    pattern: Math.min(m.pattern, PILLAR_CAP),
    mindIndex: m.mindIndex,
    bestRing: m.bestRing,
    streak: m.streak,
    bestStreak: m.bestStreak,
    trialsSolved: m.trialsSolved,
    trialsFailed: m.trialsFailed,
    title: titleFor(m.mindIndex),
    nextTitle: undefined,
  };
}
