import { NextRequest, NextResponse } from "next/server";
import {
  buildRuleBasedNimAnalysis,
  detectCandlestickVisionPatterns,
} from "@/services/nvidiaNimService";
import {
  CoinTechnicalAnalysis,
  OHLCVCandle,
  formatPriceNumber,
} from "@/services/technicalEngine";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const startTime = Date.now();
  try {
    const body = await request.json();
    const coin: CoinTechnicalAnalysis = body?.coin;
    const candles: OHLCVCandle[] = Array.isArray(body?.candles)
      ? body.candles
      : [];

    if (!coin || !coin.symbol) {
      return NextResponse.json(
        { ok: false, error: "נתוני מטבע חסרים לניתוח NVIDIA NIM" },
        { status: 400 }
      );
    }

    const baseAnalysis = buildRuleBasedNimAnalysis(coin, candles);
    const detectedPatterns = detectCandlestickVisionPatterns(coin, candles);
    const nvidiaApiKey = process.env.NVIDIA_API_KEY;

    // If NVIDIA_API_KEY is configured, invoke NVIDIA NIM (`https://integrate.api.nvidia.com/v1/chat/completions`)
    if (nvidiaApiKey && nvidiaApiKey.trim().length > 0) {
      try {
        const promptHe = `אתה אנליסט קריפטו מוסדי בכיר ומערכת מסחר אלגוריתמית.
נתח את הצמד ${coin.symbol} במחיר $${formatPriceNumber(coin.currentPrice)}:
- RSI(14): ${coin.rsi14}
- MACD Histogram: ${coin.macd.histogram}
- EMA20: $${formatPriceNumber(coin.ema.ema20)}, EMA50: $${formatPriceNumber(
          coin.ema.ema50
        )}, EMA200: $${formatPriceNumber(coin.ema.ema200)}
- ATR(14): ${coin.atrPct}%, ADX(14): ${coin.adx14}
- Volume Profile POC: $${formatPriceNumber(coin.volumeProfile.pocPrice)}
- תבנית גרף שזוהתה בראייה ממוחשבת: ${
          detectedPatterns[0]?.nameHe || "מבנה התכנסות"
        }

כתוב בעברית מקצועית (2-3 משפטים תמציתיים) נימוק מסחר מדויק להמלצת [${
          coin.recommendationLabelHe
        }] כולל התייחסות לכניסה ($${formatPriceNumber(
          coin.entryPrice
        )}), יעד רווח ($${formatPriceNumber(
          coin.takeProfit1
        )}) וקטיעת הפסד ($${formatPriceNumber(coin.stopLoss)}).`;

        const nimRes = await fetch(
          "https://integrate.api.nvidia.com/v1/chat/completions",
          {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${nvidiaApiKey.trim()}`,
            },
            body: JSON.stringify({
              model: "nvidia/llama-3.1-nemotron-70b-instruct",
              messages: [
                {
                  role: "system",
                  content:
                    "You are an institutional Hebrew-speaking algorithmic crypto trading architect powered by NVIDIA NIM.",
                },
                {
                  role: "user",
                  content: promptHe,
                },
              ],
              temperature: 0.25,
              max_tokens: 260,
            }),
            signal: AbortSignal.timeout(7500),
          }
        );

        if (nimRes.ok) {
          const nimJson = await nimRes.json();
          const aiText =
            nimJson?.choices?.[0]?.message?.content?.trim() ||
            baseAnalysis.nimReasoningHe;

          return NextResponse.json({
            ...baseAnalysis,
            provider: "NVIDIA_NIM_CLOUD_API",
            latencyMs: Date.now() - startTime,
            nimReasoningHe: aiText,
          });
        }
      } catch {
        // Seamless fallback to rule-based technical calculations below
      }
    }

    return NextResponse.json({
      ...baseAnalysis,
      latencyMs: Math.max(16, Date.now() - startTime),
    });
  } catch (error) {
    console.error("Error in /api/nvidia-nim:", error);
    return NextResponse.json(
      { ok: false, error: "שגיאה בשירות NVIDIA NIM" },
      { status: 500 }
    );
  }
}
