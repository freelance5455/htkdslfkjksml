import { NextRequest, NextResponse } from "next/server";
import { webSearch } from "@/lib/websearch";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q") || "";
  const engine = req.nextUrl.searchParams.get("engine") || "auto";
  if (!q) return NextResponse.json({ results: [] });
  const results = await webSearch(q, engine, 8);
  return NextResponse.json({ results });
}
