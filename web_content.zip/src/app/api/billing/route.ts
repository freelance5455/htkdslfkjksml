import { eq } from "drizzle-orm";
import { db } from "@/db";
import { subscriptions, users } from "@/db/schema";
import { fail, ok, readJson, requireUser, toErrorResponse } from "@/lib/api";
import { activateSubscription, getActiveSubscription, getPlan, getPlans } from "@/lib/plans";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const plans = await getPlans();
    return ok({ plans });
  } catch (error) {
    return toErrorResponse(error);
  }
}

/**
 * Demo checkout. In production replace this with a Stripe Checkout session and
 * call `activateSubscription` from a verified webhook instead.
 */
export async function POST(request: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const body = await readJson(request);
    const planKey = String(body.planKey ?? "");
    const plan = await getPlan(planKey);
    if (!plan) return fail("Unknown plan.");

    // Downgrade / cancel: end the subscription now and fall back to Free limits.
    if (plan.key === "free") {
      await db.update(subscriptions).set({ status: "canceled" }).where(eq(subscriptions.userId, auth.user.id));
      await db.update(users).set({ planKey: "free" }).where(eq(users.id, auth.user.id));
      return ok({ planKey: "free", currentPeriodEnd: null, subscription: null });
    }
    if (auth.user.role !== "admin" && plan.priceCents > 0 && process.env.ENABLE_DEMO_BILLING === "false") {
      return fail("Billing is not enabled in this environment.", 403);
    }
    const { currentPeriodEnd } = await activateSubscription(auth.user.id, plan.key, plan.priceCents);
    const subscription = await getActiveSubscription(auth.user.id);
    return ok({ planKey: plan.key, currentPeriodEnd, subscription });
  } catch (error) {
    return toErrorResponse(error);
  }
}
