import { db } from "@/db";
import { generations } from "@/db/schema";
import { normalizeInput, runGeneration } from "@/lib/ai/generate";
import { TOOL_IDS, PLAN_RANK, toolById, type PlanTier, type ToolId } from "@/lib/ai/tools";
import { fail, ok, readJson, requireUser, toErrorResponse } from "@/lib/api";
import { getSettings } from "@/lib/settings";
import { consumeCredits, getUsageSummary } from "@/lib/usage";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { user } = auth;

  try {
    const body = await readJson(request);
    const tool = String(body.tool ?? "") as ToolId;
    if (!TOOL_IDS.includes(tool)) return fail("Unknown tool.");

    const settings = await getSettings();
    if (settings.features[tool] === false) {
      return fail("This tool is temporarily disabled by the administrator.", 403);
    }

    const def = toolById(tool, settings.niches);
    if (!def) return fail("Unknown tool.");

    const userTier = (user.planKey === "pro" ? "pro" : user.planKey === "creator" ? "creator" : "free") as PlanTier;
    if (PLAN_RANK[userTier] < PLAN_RANK[def.minPlan]) {
      return fail(`${def.name} requires the ${def.minPlan === "pro" ? "Pro" : "Creator"} plan.`, 402, {
        code: "UPGRADE_REQUIRED",
        requiredPlan: def.minPlan,
      });
    }

    // Per-tool option gating (long-form scripts = Pro, 60s = Creator).
    if (tool === "scripts") {
      const input = normalizeInput(tool, body);
      const length = input.length || "30s";
      const required = length === "longform" ? "pro" : length === "60s" ? "creator" : "free";
      if (PLAN_RANK[userTier] < PLAN_RANK[required as PlanTier]) {
        return fail(
          `${length === "longform" ? "Long-form scripts" : "60-second scripts"} require the ${required === "pro" ? "Pro" : "Creator"} plan.`,
          402,
          { code: "UPGRADE_REQUIRED", requiredPlan: required },
        );
      }
    }

    const input = normalizeInput(tool, body);

    // Reserve credits up-front so parallel/refresh spam cannot exceed the plan.
    const usageAfter = await consumeCredits({
      userId: user.id,
      tool,
      credits: def.credits,
      planKey: user.planKey,
    });

    try {
      const { engine, output } = await runGeneration(tool, input);
      const [saved] = await db
        .insert(generations)
        .values({
          userId: user.id,
          tool,
          platform: input.platform ?? "",
          topic: input.topic ?? "",
          niche: input.niche ?? "",
          tone: input.tone ?? "",
          inputs: input as unknown as Record<string, unknown>,
          output: output as unknown as Record<string, unknown>,
          engine,
        })
        .returning({ id: generations.id, createdAt: generations.createdAt });

      return ok({
        id: saved?.id ?? null,
        tool,
        engine,
        output,
        usage: {
          used: usageAfter.used,
          limit: usageAfter.limit,
          remaining: usageAfter.remaining,
        },
      });
    } catch (error) {
      console.error("[generate]", tool, error);
      return fail("Generation failed. Your credit was returned — please try again.", 502);
    }
  } catch (error) {
    return toErrorResponse(error);
  }
}

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const usage = await getUsageSummary(auth.user.id, auth.user.planKey);
    return ok({ usage });
  } catch (error) {
    return toErrorResponse(error);
  }
}
