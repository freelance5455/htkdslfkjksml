import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { bookmarks } from "@/db/schema";
import { desc, eq, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const profileId = Number(req.nextUrl.searchParams.get("profileId") || 0);
  const rows = await db.select().from(bookmarks).where(eq(bookmarks.profileId, profileId)).orderBy(desc(bookmarks.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const b = (await req.json()) as { url: string; title?: string; folder?: string; profileId?: number };
  if (!b.url) return NextResponse.json({ error: "url required" }, { status: 400 });
  const profileId = b.profileId || 0;
  const existing = await db
    .select()
    .from(bookmarks)
    .where(and(eq(bookmarks.url, b.url), eq(bookmarks.profileId, profileId)))
    .limit(1);
  if (existing.length) {
    // toggle: удалить
    await db.delete(bookmarks).where(eq(bookmarks.id, existing[0].id));
    return NextResponse.json({ removed: true });
  }
  const [row] = await db
    .insert(bookmarks)
    .values({ url: b.url, title: b.title || b.url, folder: b.folder || "Панель закладок", profileId })
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(req: NextRequest) {
  const id = Number(req.nextUrl.searchParams.get("id"));
  await db.delete(bookmarks).where(eq(bookmarks.id, id));
  return NextResponse.json({ ok: true });
}
