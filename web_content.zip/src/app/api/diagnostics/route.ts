import { isDatabaseConfigured } from "@/db";
import { ensureSchema } from "@/db/ensure-schema";

/**
 * Operator diagnostics for cloud synchronisation.
 *
 * Reports WHETHER things are configured and what to do about it — never the
 * values themselves. No connection string, credential, host or secret is
 * exposed. Normal users never see this route; it exists so a deployment
 * problem can be identified without reading function logs.
 */
export const dynamic = "force-dynamic";
export const revalidate = 0;
export const runtime = "nodejs";

export async function GET() {
  const configured = isDatabaseConfigured();

  const checks: { name: string; ok: boolean; detail: string }[] = [
    {
      name: "DATABASE_URL",
      ok: configured,
      detail: configured
        ? "Set on the server."
        : "Missing. Cloud sync needs storage — add DATABASE_URL in your hosting provider's environment variables (all deploy contexts) and redeploy. Scoring continues offline-first without it.",
    },
  ];

  let schema: Awaited<ReturnType<typeof ensureSchema>> | null = null;
  if (configured) {
    schema = await ensureSchema();
    checks.push(
      {
        name: "DATABASE_CONNECTION",
        ok: schema.tableExists,
        detail: schema.tableExists
          ? "Connected and the matches table is reachable."
          : "Could not reach the matches table. Check the credentials and network access of the database.",
      },
      {
        name: "SCHEMA",
        ok: schema.missing.length === 0,
        detail:
          schema.missing.length === 0
            ? "All expected columns are present."
            : `Missing column(s): ${schema.missing.join(", ")}. Apply the schema with an owner role: \`DATABASE_URL="..." npx drizzle-kit push\`.`,
      },
    );
  }

  const cloudReady = checks.every((c) => c.ok);

  return Response.json(
    {
      service: "match-cricket",
      cloudReady,
      // Scoring is offline-first and never depends on any of the above.
      scoringAvailable: true,
      checks,
      timestamp: new Date().toISOString(),
    },
    { status: 200, headers: { "Cache-Control": "no-store" } },
  );
}
