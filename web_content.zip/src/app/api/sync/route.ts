import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

function genCode() {
  const a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 12; i++) s += a[Math.floor(Math.random() * a.length)];
  return s.replace(/(.{4})(?=.)/g, "$1-");
}

/** Создать аккаунт синхронизации (sync-код) или войти по коду */
export async function POST(req: NextRequest) {
  const b = (await req.json()) as { code?: string; name?: string; settings?: Record<string, unknown> };
  if (b.code) {
    const [p] = await db.select().from(profiles).where(eq(profiles.syncCode, b.code.trim().toUpperCase())).limit(1);
    if (!p) return NextResponse.json({ error: "Код не найден" }, { status: 404 });
    if (b.settings) await db.update(profiles).set({ settings: b.settings }).where(eq(profiles.id, p.id));
    return NextResponse.json(p);
  }
  const [p] = await db.insert(profiles).values({ syncCode: genCode(), name: b.name || "Пользователь", settings: b.settings || {} }).returning();
  return NextResponse.json(p);
}

export async function GET(req: NextRequest) {
  const id = Number(req.nextUrl.searchParams.get("id") || 0);
  if (!id) return NextResponse.json(null);
  const [p] = await db.select().from(profiles).where(eq(profiles.id, id)).limit(1);
  return NextResponse.json(p || null);
}
