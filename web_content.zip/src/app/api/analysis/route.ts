import { NextRequest } from "next/server";
import { getKlines, getTicker } from "@/lib/market";
import { analyzeSymbol } from "@/lib/signals";
import { getRules } from "@/server/store";

export const dynamic = "force-dynamic";

/** ניתוח עומק למטבע בודד */
export async function GET(req: NextRequest) {
  const symbol = (req.nextUrl.searchParams.get("symbol") ?? "BTCUSDT").toUpperCase();
  const interval = req.nextUrl.searchParams.get("interval") ?? "1h";
  try {
    const rules = await getRules();
    const [kl, ticker] = await Promise.all([getKlines(symbol, interval, 200), getTicker(symbol)]);
    const analysis = analyzeSymbol(symbol, kl.data, ticker, rules, kl.source);
    return Response.json({
      ok: Boolean(analysis),
      symbol,
      interval,
      source: kl.source,
      degraded: kl.degraded,
      analysis,
      candles: kl.data.slice(-120),
      error: analysis ? null : kl.error ?? "אין מספיק נתוני נרות לניתוח",
    });
  } catch (err) {
    return Response.json(
      { ok: false, analysis: null, error: err instanceof Error ? err.message : "שגיאת ניתוח" },
      { status: 500 },
    );
  }
}
