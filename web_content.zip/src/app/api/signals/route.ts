import { NextRequest } from "next/server";
import { runScan } from "@/server/engine";
import { getRules } from "@/server/store";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET() {
  try {
    const scan = await runScan(false);
    const rules = await getRules();
    return Response.json({ ok: !scan.degraded, ...scan, rules });
  } catch (err) {
    return Response.json(
      { ok: false, analyses: [], error: err instanceof Error ? err.message : "שגיאת סריקה" },
      { status: 500 },
    );
  }
}

/** סריקה ידנית - handleManualScan */
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as { force?: boolean };
    const scan = await runScan(body?.force !== false);
    const rules = await getRules();
    return Response.json({
      ok: scan.analyses.length > 0,
      message: scan.analyses.length > 0 ? "הסריקה הושלמה בהצלחה" : "הסריקה הסתיימה ללא נתונים - נסה שוב",
      ...scan,
      rules,
    });
  } catch (err) {
    return Response.json(
      { ok: false, analyses: [], message: "שגיאה בסריקה", error: err instanceof Error ? err.message : "" },
      { status: 500 },
    );
  }
}
