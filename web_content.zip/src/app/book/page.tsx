"use client";

import Link from "next/link";
import { Suspense, useEffect, useMemo, useState, type FormEvent } from "react";
import { useSearchParams } from "next/navigation";
import { CalendarCheck, CheckCircle2, Clock, MapPin, MessageCircle, Phone, ShieldCheck, Wallet } from "lucide-react";
import { useAuth, useI18n, useSite, useToast } from "@/components/providers";
import { buttonClass, Card, CardSkeleton, Checkbox, Field, Input, PageHeader, Select, ServiceIcon, Textarea } from "@/components/ui";
import { api, ApiError } from "@/lib/api-client";
import { MOROCCAN_CITIES, TIME_SLOTS } from "@/lib/constants";
import type { ServiceDTO } from "@/lib/types";
import { formatDateTime, formatPrice, loc, toLocalIso } from "@/lib/utils";

const PHONE_RE = /^(\+212|0)[5-7]\d{8}$/;

export default function BookPage() {
  return (
    <Suspense fallback={<CardSkeleton lines={8} />}>
      <BookingForm />
    </Suspense>
  );
}

interface BookingForm {
  serviceSlug: string;
  date: string;
  time: string;
  patientName: string;
  phone: string;
  city: string;
  address: string;
  medicalNotes: string;
  consent: boolean;
}

function BookingForm() {
  const { t, locale, te } = useI18n();
  const { user } = useAuth();
  const { whatsapp, callLink, settings } = useSite();
  const toast = useToast();
  const params = useSearchParams();

  const [services, setServices] = useState<ServiceDTO[] | null>(null);
  const [taken, setTaken] = useState<string[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof BookingForm, string>>>({});
  const [done, setDone] = useState<{ reference: string } | null>(null);
  const [form, setForm] = useState<BookingForm>({
    serviceSlug: params.get("service") ?? "",
    date: params.get("date") ?? "",
    time: "",
    patientName: "",
    phone: "",
    city: params.get("city") ?? "Fès",
    address: "",
    medicalNotes: "",
    consent: false,
  });

  const set = <K extends keyof BookingForm>(key: K, value: BookingForm[K]) => setForm((f) => ({ ...f, [key]: value }));

  useEffect(() => {
    api<{ services: ServiceDTO[] }>("/api/services")
      .then((r) => setServices(r.services))
      .catch(() => setServices([]));
  }, []);

  // Prefill from the account when signed in (optional).
  useEffect(() => {
    if (!user) return;
    setForm((f) => ({
      ...f,
      patientName: f.patientName || user.fullName,
      phone: f.phone || user.phone,
      city: f.city || user.city,
      address: f.address || user.address,
    }));
  }, [user]);

  useEffect(() => {
    if (!services || services.length === 0) return;
    if (!services.some((s) => s.slug === form.serviceSlug)) setForm((f) => ({ ...f, serviceSlug: services[0].slug }));
  }, [services, form.serviceSlug]);

  const selected = useMemo(() => services?.find((s) => s.slug === form.serviceSlug) ?? null, [services, form.serviceSlug]);

  const loadSlots = (date: string) => {
    if (!date) {
      setTaken([]);
      return;
    }
    setSlotsLoading(true);
    api<{ taken: string[] }>(`/api/appointments/slots?date=${date}`)
      .then((r) => setTaken(r.taken))
      .catch(() => setTaken([]))
      .finally(() => setSlotsLoading(false));
  };

  useEffect(() => {
    loadSlots(form.date);
    // loadSlots only reads the date; re-run when the date changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.date]);

  // A time that became unavailable is cleared so the visitor picks a free one.
  useEffect(() => {
    if (form.time && taken.includes(form.time)) setForm((f) => ({ ...f, time: "" }));
  }, [taken, form.time]);

  const validate = () => {
    const e: Partial<Record<keyof BookingForm, string>> = {};
    const today = new Date().toISOString().slice(0, 10);
    if (!selected) e.serviceSlug = t("common.required");
    if (!form.date) e.date = t("common.required");
    else if (form.date < today) e.date = t("err.past_date");
    if (!form.time) e.time = t("common.required");
    else if (taken.includes(form.time)) e.time = t("book.slotTaken");
    else if (new Date(`${form.date}T${form.time}:00`).getTime() < Date.now() + 2 * 3600_000) e.time = t("err.too_soon");
    if (form.patientName.trim().length < 2) e.patientName = t("common.required");
    if (!PHONE_RE.test(form.phone.replace(/[\s.-]/g, ""))) e.phone = t("err.invalid_phone");
    if (!form.city) e.city = t("common.required");
    if (form.address.trim().length < 5) e.address = t("common.required");
    if (!form.consent) e.consent = t("common.required");
    return e;
  };

  const onSubmit = async (ev: FormEvent) => {
    ev.preventDefault();
    const v = validate();
    setErrors(v);
    if (Object.keys(v).length > 0 || !selected) return;
    setSubmitting(true);
    try {
      const res = await api<{ reference: string }>("/api/appointments", {
        body: {
          serviceId: selected.id,
          scheduledAt: toLocalIso(form.date, form.time),
          patientName: form.patientName.trim(),
          phone: form.phone.replace(/[\s.-]/g, ""),
          city: form.city,
          address: form.address.trim(),
          medicalNotes: form.medicalNotes.trim(),
          consent: true,
        },
      });
      setDone({ reference: res.reference });
      toast.success(t("book.requestReceived"));
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      if (err instanceof ApiError && err.code === "slot_taken") {
        setErrors({ time: t("book.slotTaken") });
        setForm((f) => ({ ...f, time: "" }));
        loadSlots(form.date);
      }
      toast.error(te(err));
    } finally {
      setSubmitting(false);
    }
  };

  const reset = () => {
    setDone(null);
    setForm((f) => ({ ...f, time: "", medicalNotes: "", consent: false }));
  };

  if (done) {
    return (
      <div>
        <PageHeader title={t("book.requestReceived")} />
        <Card className="mx-auto max-w-2xl space-y-6 text-center">
          <span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 ring-8 ring-emerald-50/60">
            <CheckCircle2 className="h-11 w-11" />
          </span>
          <p className="text-lg font-bold text-slate-900">{t("book.referenceLine", { ref: done.reference })}</p>
          <p className="text-base leading-relaxed text-slate-600">{t("book.confirmHelp")}</p>
          <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
            <a
              href={whatsapp(t("wa.confirmBooking", { ref: done.reference }))}
              target="_blank"
              rel="noopener noreferrer"
              className={buttonClass("whatsapp", "lg")}
            >
              <MessageCircle className="h-5 w-5" />
              {t("btn.whatsapp")}
            </a>
            <button type="button" onClick={reset} className={buttonClass("outline", "lg")}>
              {t("book.newRequest")}
            </button>
          </div>
          <Link href="/" className="block text-sm font-semibold text-teal-700 hover:underline">
            {t("nav.home")}
          </Link>
        </Card>
      </div>
    );
  }

  const scheduledLabel = form.date && form.time ? formatDateTime(toLocalIso(form.date, form.time), locale) : "—";
  const minDate = new Date().toISOString().slice(0, 10);

  return (
    <div>
      <PageHeader title={t("book.title")} subtitle={`${t("book.subtitle")} ${t("book.noAccount")}`} />

      <form onSubmit={onSubmit} noValidate className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="space-y-5">
            <h2 className="flex items-center gap-3 text-lg font-bold text-slate-900">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-600 text-sm text-white">1</span>
              {t("book.service")}
            </h2>
            <Field label={t("book.service")} htmlFor="service" error={errors.serviceSlug}>
              <Select id="service" value={form.serviceSlug} onChange={(e) => set("serviceSlug", e.target.value)} className="py-3">
                {(services ?? []).map((s) => (
                  <option key={s.id} value={s.slug}>
                    {loc(s.name, locale)} — {formatPrice(s.priceMad, locale)}
                  </option>
                ))}
              </Select>
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={t("book.date")} htmlFor="date" error={errors.date}>
                <Input id="date" type="date" min={minDate} value={form.date} onChange={(e) => set("date", e.target.value)} className="py-3" />
              </Field>
              <Field
                label={t("book.time")}
                htmlFor="time"
                error={errors.time}
                hint={!form.date ? t("book.chooseDate") : slotsLoading ? t("book.slotsLoading") : undefined}
              >
                <Select id="time" value={form.time} onChange={(e) => set("time", e.target.value)} disabled={!form.date} className="py-3">
                  <option value="">—</option>
                  {TIME_SLOTS.map((slot) => (
                    <option key={slot} value={slot} disabled={taken.includes(slot)}>
                      {slot}
                      {taken.includes(slot) ? " ✕" : ""}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
          </Card>

          <Card className="space-y-5">
            <h2 className="flex items-center gap-3 text-lg font-bold text-slate-900">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-600 text-sm text-white">2</span>
              {t("book.patientName")}
            </h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={t("book.patientName")} htmlFor="patientName" error={errors.patientName}>
                <Input id="patientName" value={form.patientName} onChange={(e) => set("patientName", e.target.value)} autoComplete="name" className="py-3" />
              </Field>
              <Field label={t("book.phone")} htmlFor="phone" error={errors.phone} hint={t("book.phoneExample")}>
                <Input id="phone" dir="ltr" type="tel" inputMode="tel" value={form.phone} onChange={(e) => set("phone", e.target.value)} autoComplete="tel" className="py-3" />
              </Field>
              <Field label={t("book.city")} htmlFor="city" error={errors.city}>
                <Select id="city" value={form.city} onChange={(e) => set("city", e.target.value)} className="py-3">
                  {MOROCCAN_CITIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            <Field label={t("book.address")} htmlFor="address" hint={t("book.addressHint")} error={errors.address}>
              <Textarea id="address" rows={2} value={form.address} onChange={(e) => set("address", e.target.value)} autoComplete="street-address" />
            </Field>
          </Card>

          <Card className="space-y-5">
            <h2 className="flex items-center gap-3 text-lg font-bold text-slate-900">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-600 text-sm text-white">3</span>
              {t("book.notes")}
            </h2>
            <Field label={t("book.notes")} htmlFor="notes" hint={`${t("common.optional")} · ${t("book.notesHint")}`}>
              <Textarea id="notes" rows={4} maxLength={1500} value={form.medicalNotes} onChange={(e) => set("medicalNotes", e.target.value)} />
            </Field>
            <div className="flex items-start gap-3 rounded-2xl bg-sky-50 p-4 text-sm leading-relaxed text-sky-900 ring-1 ring-sky-100">
              <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-sky-600" />
              {t("book.consent")}
            </div>
            <Checkbox id="consent" checked={form.consent} onChange={(v) => set("consent", v)} label={t("book.consent")} />
            {errors.consent && <p className="text-xs font-medium text-rose-600">{errors.consent}</p>}
          </Card>

          <button type="submit" disabled={submitting || !selected} className={buttonClass("primary", "lg", "w-full sm:w-auto")}>
            <CalendarCheck className="h-5 w-5" />
            {submitting ? t("common.loading") : t("book.submit")}
          </button>
        </div>

        <aside className="lg:sticky lg:top-8 lg:self-start">
          <Card className="space-y-5">
            <h2 className="font-bold text-slate-900">{t("book.summary")}</h2>
            {selected ? (
              <div className="flex items-start gap-3">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-sky-500 text-white">
                  <ServiceIcon name={selected.icon} className="h-6 w-6" />
                </span>
                <div>
                  <p className="font-semibold text-slate-900">{loc(selected.name, locale)}</p>
                  <p className="text-sm font-bold text-teal-700">{formatPrice(selected.priceMad, locale)}</p>
                </div>
              </div>
            ) : (
              <CardSkeleton lines={1} />
            )}
            <ul className="space-y-3 text-sm text-slate-700">
              <li className="flex items-center gap-3">
                <Wallet className="h-4 w-4 shrink-0 text-teal-600" />
                <span>
                  {t("book.estimate")}: <strong>{selected ? formatPrice(selected.priceMad, locale) : "—"}</strong>
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="h-4 w-4 shrink-0 text-sky-600" />
                <span>
                  {t("book.duration")}: {selected?.durationMinutes ?? "—"} {t("common.minutes")}
                </span>
              </li>
              <li className="flex items-center gap-3">
                <CalendarCheck className="h-4 w-4 shrink-0 text-teal-600" />
                <span>{scheduledLabel}</span>
              </li>
              <li className="flex items-center gap-3">
                <MapPin className="h-4 w-4 shrink-0 text-teal-600" />
                <span>{form.city || "—"}</span>
              </li>
            </ul>
            <p className="rounded-xl bg-slate-50 p-3 text-xs leading-relaxed text-slate-600">{t("book.policyText")}</p>
            <div className="grid gap-2">
              <a href={callLink} className={buttonClass("outline", "md", "w-full")}>
                <Phone className="h-4 w-4" />
                <span dir="ltr">{settings.contact.phoneDisplay}</span>
              </a>
            </div>
          </Card>
        </aside>
      </form>
    </div>
  );
}
