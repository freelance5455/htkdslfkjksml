"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { formatBDT } from "@/lib/utils";

interface OrderSummary {
  id: number;
  customerName: string;
  phone: string;
  totalPrice: number;
  status: string;
  trackingNumber: string;
  createdAt: string;
}

const STATUS_FLOW = ["pending", "confirmed", "shipped", "delivered"];

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "bg-amber-500/20 text-amber-300 border-amber-400/30",
    confirmed: "bg-blue-500/20 text-blue-300 border-blue-400/30",
    shipped: "bg-purple-500/20 text-purple-300 border-purple-400/30",
    delivered: "bg-emerald-500/20 text-emerald-300 border-emerald-400/30",
    cancelled: "bg-red-500/20 text-red-300 border-red-400/30",
  };
  return (
    <span className={`rounded-full border px-3 py-1 text-xs font-bold capitalize ${map[status] || ""}`}>
      {status}
    </span>
  );
}

export default function OrdersPage() {
  const [phone, setPhone] = useState("");
  const [orders, setOrders] = useState<OrderSummary[]>([]);
  const [searched, setSearched] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const search = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!phone.trim()) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/orders?phone=${encodeURIComponent(phone.trim())}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to load orders");
      setOrders(data.orders || []);
      setSearched(true);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen bg-futuristic pt-28">
      <div className="mx-auto max-w-4xl px-4 pb-24">
        <h1 className="font-display text-4xl font-bold text-white">Order <span className="text-gradient">Tracking</span></h1>
        <p className="mt-2 text-slate-400">Enter your phone number to view order history and track delivery status.</p>

        <form onSubmit={search} className="mt-8 flex flex-col gap-3 sm:flex-row">
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Enter your phone number (e.g. 017XXXXXXXX)"
            className="flex-1 rounded-2xl border border-white/10 bg-black/40 px-5 py-4 text-white placeholder:text-slate-500 focus:border-purple-400/60 focus:outline-none"
          />
          <button className="rounded-2xl bg-gradient-to-r from-purple-500 to-blue-600 px-8 py-4 font-bold text-white shadow-[0_0_20px_rgba(139,92,246,0.4)] transition hover:brightness-110 disabled:opacity-50" disabled={loading}>
            {loading ? "Searching..." : "Track Orders"}
          </button>
        </form>

        {error && <p className="mt-4 rounded-xl border border-red-400/30 bg-red-500/10 p-3 text-red-300">{error}</p>}

        <div className="mt-10 space-y-4">
          {searched && !loading && orders.length === 0 && (
            <div className="glass rounded-3xl py-16 text-center">
              <p className="text-4xl">📦</p>
              <p className="mt-3 text-slate-400">No orders found for this phone number.</p>
              <Link href="/models" className="mt-5 inline-block rounded-2xl bg-gradient-to-r from-purple-500 to-blue-600 px-6 py-3 font-bold text-white">
                Start Shopping
              </Link>
            </div>
          )}
          {orders.map((o, idx) => {
            const currentStep = STATUS_FLOW.indexOf(o.status);
            const cancelled = o.status === "cancelled";
            return (
              <motion.div
                key={o.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.08 }}
                className="glass rounded-3xl p-6"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="font-mono text-lg font-black text-white">{o.trackingNumber}</p>
                    <p className="text-sm text-slate-400">
                      {o.customerName} · {o.phone} ·{" "}
                      {new Date(o.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-display font-black text-gradient">{formatBDT(o.totalPrice)}</span>
                    <StatusBadge status={o.status} />
                  </div>
                </div>

                {/* Tracking timeline */}
                {cancelled ? (
                  <div className="mt-5 rounded-xl border border-red-400/20 bg-red-500/10 p-3 text-sm text-red-300">
                    This order was cancelled. Contact support for details.
                  </div>
                ) : (
                  <div className="mt-6 grid grid-cols-4 gap-1">
                    {STATUS_FLOW.map((s, i) => (
                      <div key={s} className="relative">
                        <div className={`h-1.5 rounded-full ${i <= currentStep ? "bg-gradient-to-r from-purple-500 to-blue-500" : "bg-white/10"}`} />
                        <div className={`mt-2 grid h-7 w-7 place-items-center rounded-full text-xs font-bold ${i <= currentStep ? "bg-purple-500 text-white" : "bg-white/5 text-slate-500"}`}>
                          {i + 1}
                        </div>
                        <p className={`mt-1 text-[10px] font-semibold uppercase tracking-wide ${i <= currentStep ? "text-purple-300" : "text-slate-500"}`}>{s}</p>
                      </div>
                    ))}
                  </div>
                )}

                <div className="mt-5 flex justify-end">
                  <Link href={`/order/${o.id}`} className="rounded-xl border border-white/15 px-5 py-2 text-sm font-semibold text-white transition hover:border-purple-400/60">
                    View Full Details →
                  </Link>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}