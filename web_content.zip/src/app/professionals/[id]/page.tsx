"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { ArrowLeft, Award, BadgeCheck, CalendarCheck, Clock, GraduationCap, MapPin, ShieldCheck } from "lucide-react";
import { useI18n } from "@/components/providers";
import { Avatar, Badge, buttonClass, Card, CardSkeleton, ErrorState, Stars, VerificationBadge } from "@/components/ui";
import { api } from "@/lib/api-client";
import { DAYS } from "@/lib/constants";
import type { ProfessionalDTO, ServiceDTO } from "@/lib/types";
import { formatDay, loc } from "@/lib/utils";

interface ProfilePayload {
  professional: ProfessionalDTO;
  reviews: Array<{ id: string; rating: number; comment: string; createdAt: string; patientName: string }>;
}

export default function ProfessionalProfilePage() {
  const { t, locale } = useI18n();
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<ProfilePayload | null>(null);
  const [services, setServices] = useState<ServiceDTO[]>([]);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let alive = true;
    setError(false);
    setNotFound(false);
    api<ProfilePayload>(`/api/professionals/${encodeURIComponent(id)}`)
      .then((r) => alive && setData(r))
      .catch((err: { status?: number }) => {
        if (!alive) return;
        if (err?.status === 404) setNotFound(true);
        else setError(true);
      });
    api<{ services: ServiceDTO[] }>("/api/services")
      .then((r) => alive && setServices(r.services))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [id, reloadKey]);

  if (error) return <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />;
  if (notFound)
    return (
      <Card className="text-center">
        <p className="text-slate-700">{t("pro.notFound")}</p>
        <Link href="/professionals" className={buttonClass("primary", "md", "mt-4")}>
          {t("common.back")}
        </Link>
      </Card>
    );
  if (!data)
    return (
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <CardSkeleton lines={3} />
          <CardSkeleton lines={5} />
        </div>
        <CardSkeleton lines={4} />
      </div>
    );

  const p = data.professional;
  const serviceName = (slug: string) => {
    const s = services.find((x) => x.slug === slug);
    return s ? loc(s.name, locale) : slug;
  };

  return (
    <div>
      <Link href="/professionals" className="mb-6 inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-teal-700">
        <ArrowLeft className="h-4 w-4 rtl:rotate-180" />
        {t("pro.title")}
      </Link>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section className="rounded-3xl bg-gradient-to-br from-sky-50 via-white to-teal-50 p-6 ring-1 ring-sky-100 sm:p-8">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
              <Avatar src={p.photoUrl} name={p.fullName} className="h-24 w-24 rounded-3xl text-2xl" />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="text-2xl font-extrabold text-slate-900">{p.fullName}</h1>
                  <VerificationBadge status={p.verificationStatus} />
                </div>
                <p className="mt-1 text-slate-600">
                  {t(`pro.profession.${p.profession}`)} · <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{p.city}</span>
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-slate-600">
                  <Stars value={p.ratingAvg} size={16} />
                  <span>
                    {p.ratingCount > 0 ? `${p.ratingAvg.toFixed(1)} · ${t("pro.ratingCount", { n: p.ratingCount })}` : t("pro.newPro")}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Award className="h-4 w-4 text-teal-600" />
                    {t("pro.experience", { n: p.experienceYears })}
                  </span>
                </div>
              </div>
            </div>
            <p className="mt-6 text-base leading-relaxed text-slate-700">{loc(p.bio, locale)}</p>
          </section>

          {p.verificationStatus === "verified" && (
            <div className="flex items-start gap-3 rounded-2xl bg-emerald-50 p-4 text-sm text-emerald-900 ring-1 ring-emerald-100">
              <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" />
              <p>{t("pro.verifiedExplain")}</p>
            </div>
          )}

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <h2 className="mb-3 flex items-center gap-2 font-semibold text-slate-900">
                <GraduationCap className="h-5 w-5 text-teal-600" />
                {t("pro.qualifications")}
              </h2>
              <p className="text-sm leading-relaxed text-slate-700">{p.qualifications || "—"}</p>
              {p.specializations.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {p.specializations.map((s) => (
                    <Badge key={s} tone="sky">
                      {s}
                    </Badge>
                  ))}
                </div>
              )}
            </Card>
            <Card>
              <h2 className="mb-3 flex items-center gap-2 font-semibold text-slate-900">
                <Clock className="h-5 w-5 text-teal-600" />
                {t("pro.availability")}
              </h2>
              <div className="flex flex-wrap gap-1.5">
                {DAYS.map((d) => (
                  <span
                    key={d}
                    className={
                      p.availableDays.includes(d)
                        ? "rounded-lg bg-teal-600 px-2.5 py-1 text-xs font-semibold text-white"
                        : "rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-400"
                    }
                  >
                    {t(`day.${d}`)}
                  </span>
                ))}
              </div>
              <p className="mt-3 text-sm text-slate-600">
                {p.availableFrom}:00 – {p.availableTo}:00
              </p>
              <h3 className="mt-5 flex items-center gap-2 text-sm font-semibold text-slate-900">
                <MapPin className="h-4 w-4 text-teal-600" />
                {t("pro.serviceAreas")}
              </h3>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {p.serviceCities.map((c) => (
                  <span key={c} className="rounded-full bg-sky-50 px-2.5 py-1 text-xs text-sky-700 ring-1 ring-sky-100">
                    {c}
                  </span>
                ))}
              </div>
            </Card>
          </div>

          <Card>
            <h2 className="mb-4 font-semibold text-slate-900">{t("pro.services")}</h2>
            <div className="flex flex-wrap gap-2">
              {p.serviceCodes.map((code) => (
                <Link
                  key={code}
                  href={`/services/${code}`}
                  className="inline-flex items-center gap-1.5 rounded-full bg-white px-3.5 py-1.5 text-sm font-medium text-slate-700 ring-1 ring-slate-200 transition hover:ring-teal-300 hover:text-teal-700"
                >
                  <BadgeCheck className="h-4 w-4 text-emerald-500" />
                  {serviceName(code)}
                </Link>
              ))}
            </div>
          </Card>

          <section>
            <h2 className="mb-4 text-lg font-semibold text-slate-900">{t("pro.reviewsTitle")}</h2>
            {data.reviews.length === 0 ? (
              <Card>
                <p className="text-sm text-slate-600">{t("pro.noReviews")}</p>
              </Card>
            ) : (
              <div className="space-y-3">
                {data.reviews.map((r) => (
                  <Card key={r.id} className="p-5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <Stars value={r.rating} size={14} />
                      <span className="text-xs text-slate-500">{formatDay(r.createdAt, locale)}</span>
                    </div>
                    {r.comment && <p className="mt-2 text-sm leading-relaxed text-slate-700">“{r.comment}”</p>}
                    <p className="mt-2 text-xs font-semibold text-slate-500">{r.patientName}</p>
                  </Card>
                ))}
              </div>
            )}
          </section>
        </div>

        <aside className="lg:sticky lg:top-8 lg:self-start">
          <Card className="space-y-4">
            <p className="text-sm text-slate-600">{t("pro.bookWith", { name: p.fullName })}</p>
            <Link href={`/book?professional=${p.id}`} className={buttonClass("primary", "lg", "w-full")}>
              <CalendarCheck className="h-5 w-5" />
              {t("common.bookNow")}
            </Link>
            <p className="text-xs leading-relaxed text-slate-500">{t("book.autoAssigned")}</p>
          </Card>
        </aside>
      </div>
    </div>
  );
}
