"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Search, UserRound } from "lucide-react";
import { useI18n } from "@/components/providers";
import { ProfessionalCard } from "@/components/cards";
import { CardSkeleton, EmptyState, ErrorState, Input, PageHeader, Select } from "@/components/ui";
import { api } from "@/lib/api-client";
import { MOROCCAN_CITIES } from "@/lib/constants";
import type { ProfessionalDTO, ServiceDTO } from "@/lib/types";
import { loc } from "@/lib/utils";
import { useAuth } from "@/components/providers";

export default function ProfessionalsPage() {
  return (
    <Suspense fallback={<div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3"><CardSkeleton /><CardSkeleton /><CardSkeleton /></div>}>
      <ProfessionalsContent />
    </Suspense>
  );
}

function ProfessionalsContent() {
  const { t, locale } = useI18n();
  const { user } = useAuth();
  const params = useSearchParams();
  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [city, setCity] = useState(params.get("city") ?? user?.city ?? "");
  const [service, setService] = useState(params.get("service") ?? "");
  const [services, setServices] = useState<ServiceDTO[]>([]);
  const [pros, setPros] = useState<ProfessionalDTO[] | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    const id = window.setTimeout(() => setDebouncedQ(q.trim()), 300);
    return () => window.clearTimeout(id);
  }, [q]);

  useEffect(() => {
    api<{ services: ServiceDTO[] }>("/api/services")
      .then((r) => setServices(r.services))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    let alive = true;
    setError(false);
    const qs = new URLSearchParams();
    if (debouncedQ) qs.set("q", debouncedQ);
    if (city) qs.set("city", city);
    if (service) qs.set("service", service);
    api<{ professionals: ProfessionalDTO[] }>(`/api/professionals?${qs.toString()}`)
      .then((r) => alive && setPros(r.professionals))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [debouncedQ, city, service, reloadKey]);

  return (
    <div>
      <PageHeader title={t("pro.title")} subtitle={t("pro.subtitle")} />

      <div className="mb-8 grid gap-3 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-sky-100 sm:p-5 md:grid-cols-3">
        <div className="relative">
          <Search className="pointer-events-none absolute start-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
          <Input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("common.name")}
            aria-label={t("common.search")}
            className="ps-11"
          />
        </div>
        <Select value={city} onChange={(e) => setCity(e.target.value)} aria-label={t("common.city")}>
          <option value="">{t("svc.allCities")}</option>
          {MOROCCAN_CITIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </Select>
        <Select value={service} onChange={(e) => setService(e.target.value)} aria-label={t("pro.allServices")}>
          <option value="">{t("pro.allServices")}</option>
          {services.map((s) => (
            <option key={s.id} value={s.slug}>
              {loc(s.name, locale)}
            </option>
          ))}
        </Select>
      </div>

      {error ? (
        <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
      ) : !pros ? (
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <CardSkeleton key={i} lines={3} />
          ))}
        </div>
      ) : pros.length === 0 ? (
        <EmptyState icon={UserRound} title={t("pro.noPros")} />
      ) : (
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {pros.map((p) => (
            <ProfessionalCard key={p.id} pro={p} />
          ))}
        </div>
      )}
    </div>
  );
}
