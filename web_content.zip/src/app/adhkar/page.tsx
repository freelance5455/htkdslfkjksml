import type { Metadata } from "next";
import Link from "next/link";
import { DHIKR_GROUPS } from "@/data/adhkar";
import { DhikrCounter } from "@/components/dhikr-counter";
import { PageHero } from "@/components/page-hero";
import { toArabicDigits } from "@/lib/site";

export const metadata: Metadata = {
  title: "الأذكار والأدعية",
  description: "أذكار الصباح والمساء وما بعد الصلاة والنوم والأدعية المأثورة، مع عدّاد لكل ذكر.",
};

export default function AdhkarPage() {
  return (
    <main>
      <PageHero
        eyebrow="تجربة الذكر"
        title={
          <>
            الأذكار <span className="text-gold-gradient">والأدعية</span>
          </>
        }
        description="﴿أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ﴾ — أذكار الصباح والمساء وما بعد الصلاة والنوم، مع عدّاد لكل ذكر يُحفظ في متصفحك."
      >
        <a
          href="#groups"
          className="inline-flex items-center gap-3 rounded-full bg-gradient-to-b from-gold-light to-gold px-8 py-4 font-semibold text-navy shadow-[0_20px_50px_-15px_rgba(182,154,105,0.9)] transition-all hover:-translate-y-0.5"
        >
          ابدأ الذكر
        </a>
      </PageHero>

      <section id="groups" className="relative scroll-mt-24 bg-ivory py-20 sm:py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <nav aria-label="مجموعات الأذكار" className="mb-14 flex flex-wrap justify-center gap-3">
            {DHIKR_GROUPS.map((group, i) => (
              <Link
                key={group.slug}
                href={`#${group.slug}`}
                className="rounded-full border border-gold/40 bg-card px-5 py-2.5 text-sm text-navy transition-colors hover:border-gold hover:bg-gold hover:text-navy"
              >
                {toArabicDigits(i + 1)} · {group.title}
              </Link>
            ))}
          </nav>

          <div className="space-y-10">
            {DHIKR_GROUPS.map((group, i) => (
              <section
                key={group.slug}
                id={group.slug}
                aria-labelledby={`${group.slug}-title`}
                className="relative scroll-mt-28 overflow-hidden rounded-[2.5rem] bg-navy p-6 text-ivory shadow-[0_50px_100px_-50px_rgba(23,36,58,0.8)] sm:p-10"
              >
                <div className="pattern-lattice absolute inset-0 opacity-[0.06]" aria-hidden="true" />
                <div
                  className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(49,75,117,0.85),transparent_70%)]"
                  aria-hidden="true"
                />

                <header className="relative mb-10 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                  <div>
                    <p className="text-sm text-gold-light">
                      {toArabicDigits(i + 1)} · {group.subtitle}
                    </p>
                    <h2 id={`${group.slug}-title`} className="mt-2 font-serif text-4xl font-bold sm:text-5xl">
                      {group.title}
                    </h2>
                  </div>
                  <p className="max-w-md leading-7 text-ivory/65">{group.description}</p>
                </header>

                <div className="relative">
                  <DhikrCounter items={group.items} storageKey={group.slug} variant="full" />
                </div>
              </section>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
