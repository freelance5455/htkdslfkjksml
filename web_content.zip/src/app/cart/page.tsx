"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { useCart } from "@/lib/cart-context";
import { formatBDT } from "@/lib/utils";

interface WishProduct {
  id: number;
  name: string;
  modelNumber: string;
  price: number;
  image: string;
  status: string;
}

interface OrderResult {
  trackingNumber: string;
  id: number;
  totalPrice: number;
}

export default function CartPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-futuristic pt-40 text-center text-slate-400">Loading cart...</div>}>
      <CartInner />
    </Suspense>
  );
}

function CartInner() {
  const searchParams = useSearchParams();
  const tab = searchParams.get("tab") || "cart";
  const { items, removeFromCart, updateQuantity, clearCart, cartTotal, wishlist, addToCart } = useCart();

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<OrderResult | null>(null);
  const [wishProducts, setWishProducts] = useState<WishProduct[]>([]);

  useEffect(() => {
    fetch("/api/products")
      .then((r) => r.json())
      .then((data) => setWishProducts(data.products || []))
      .catch(() => setWishProducts([]));
  }, []);

  const wishlistItems = useMemo(
    () => wishProducts.filter((p) => wishlist.includes(p.id)),
    [wishProducts, wishlist]
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (items.length === 0) return setError("Your cart is empty.");
    if (!/^[0-9+\-\s]{6,}$/.test(phone)) return setError("Please enter a valid phone number.");
    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: name,
          phone,
          address,
          message,
          items: items.map((i) => ({
            productId: i.productId,
            name: i.name,
            quantity: i.quantity,
            price: i.price,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Order failed");
      setResult(data.order);
      clearCart();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen bg-futuristic pt-28">
      <div className="mx-auto max-w-7xl px-4 pb-24">
        <h1 className="font-display text-4xl font-bold text-white">
          {tab === "wishlist" ? "Your <span class='text-gradient'>Wishlist</span>" : "Your <span class='text-gradient'>Cart</span>"}
        </h1>
        <p className="mt-2 text-slate-400">Checkout securely · Cash on Delivery · Prices in BDT (৳)</p>

        <div className="mt-6 flex gap-2">
          <Link
            href="/cart"
            className={`rounded-full px-5 py-2 text-sm font-bold transition ${tab !== "wishlist" ? "bg-gradient-to-r from-purple-500 to-blue-600 text-white" : "border border-white/10 text-slate-300"}`}
          >
            🛒 Cart ({items.length})
          </Link>
          <Link
            href="/cart?tab=wishlist"
            className={`rounded-full px-5 py-2 text-sm font-bold transition ${tab === "wishlist" ? "bg-gradient-to-r from-pink-500 to-rose-600 text-white" : "border border-white/10 text-slate-300"}`}
          >
            ❤️ Wishlist ({wishlist.length})
          </Link>
        </div>

        {tab === "wishlist" ? (
          <div className="mt-10">
            {wishlistItems.length === 0 ? (
              <div className="glass rounded-3xl py-20 text-center">
                <p className="text-4xl">💜</p>
                <p className="mt-3 text-slate-400">Your wishlist is empty.</p>
                <Link href="/models" className="mt-5 inline-block rounded-2xl bg-gradient-to-r from-purple-500 to-blue-600 px-6 py-3 font-bold text-white">
                  Explore Models
                </Link>
              </div>
            ) : (
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {wishlistItems.map((p) => (
                  <div key={p.id} className="glass rounded-3xl p-4">
                    <div className="relative aspect-square overflow-hidden rounded-2xl bg-black/40">
                      <Image src={p.image} alt={p.name} fill sizes="(max-width: 768px) 100vw, 33vw" className="object-cover" />
                    </div>
                    <h3 className="mt-3 font-display font-bold text-white">{p.name}</h3>
                    <p className="text-xs text-slate-500">{p.modelNumber}</p>
                    <div className="mt-3 flex items-center justify-between">
                      <span className="font-display font-black text-white">{formatBDT(p.price)}</span>
                      <button
                        onClick={() =>
                          addToCart({ productId: p.id, name: p.name, modelNumber: p.modelNumber, price: p.price, image: p.image })
                        }
                        disabled={p.status !== "available"}
                        className="rounded-xl bg-gradient-to-r from-purple-500 to-blue-600 px-4 py-2 text-sm font-bold text-white disabled:opacity-40"
                      >
                        Add to Cart
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : result ? (
          /* CONFIRMATION */
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="mx-auto mt-14 max-w-xl">
            <div className="glass glow-purple rounded-[2rem] p-10 text-center">
              <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-emerald-500/20 text-5xl">✅</div>
              <h2 className="mt-6 font-display text-2xl font-black text-white">Order Confirmed!</h2>
              <p className="mt-3 text-slate-300">
                Thank you for ordering from CALCORA 3D. Your order has been placed successfully.
              </p>
              <div className="mt-6 rounded-2xl border border-purple-400/30 bg-purple-500/10 p-5">
                <p className="text-xs uppercase tracking-widest text-purple-300">Tracking Number</p>
                <p className="mt-1 font-mono text-3xl font-black tracking-wider text-white">{result.trackingNumber}</p>
                <p className="mt-1 text-sm text-slate-400">Order Total: <span className="font-bold text-white">{formatBDT(result.totalPrice)}</span></p>
              </div>
              <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
                <Link href="/orders" className="rounded-2xl bg-gradient-to-r from-purple-500 to-blue-600 px-6 py-3 font-bold text-white">
                  Track My Order
                </Link>
                <Link href="/models" className="rounded-2xl border border-white/15 px-6 py-3 font-bold text-white">
                  Continue Shopping
                </Link>
              </div>
            </div>
          </motion.div>
        ) : (
          <div className="mt-10 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
            {/* Items */}
            <div className="space-y-4">
              <AnimatePresence>
                {items.length === 0 && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass rounded-3xl py-20 text-center">
                    <p className="text-4xl">🛒</p>
                    <p className="mt-3 text-slate-400">Your cart is empty.</p>
                    <Link href="/models" className="mt-5 inline-block rounded-2xl bg-gradient-to-r from-purple-500 to-blue-600 px-6 py-3 font-bold text-white">
                      Explore Models
                    </Link>
                  </motion.div>
                )}
                {items.map((item) => (
                  <motion.div
                    key={item.productId}
                    layout
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: 40 }}
                    className="glass flex gap-4 rounded-3xl p-4"
                  >
                    <div className="relative h-24 w-24 flex-none overflow-hidden rounded-2xl bg-black/40">
                      <Image src={item.image} alt={item.name} fill sizes="96px" className="object-cover" />
                    </div>
                    <div className="flex flex-1 flex-col">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-display font-bold text-white">{item.name}</h3>
                          <p className="text-xs text-slate-500">{item.modelNumber}{item.color ? ` · ${item.color}` : ""}</p>
                        </div>
                        <button onClick={() => removeFromCart(item.productId)} className="text-slate-500 transition hover:text-red-400" aria-label="Remove">
                          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                      <div className="mt-auto flex items-center justify-between pt-2">
                        <div className="flex items-center gap-2">
                          <button onClick={() => updateQuantity(item.productId, item.quantity - 1)} className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 transition hover:bg-white/10">−</button>
                          <span className="w-10 text-center font-mono font-bold text-white">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.productId, item.quantity + 1)} className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 transition hover:bg-white/10">+</button>
                        </div>
                        <span className="font-display text-lg font-black text-gradient">{formatBDT(item.price * item.quantity)}</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              {items.length > 0 && (
                <button onClick={clearCart} className="text-sm text-slate-500 transition hover:text-red-400">
                  Clear cart
                </button>
              )}
            </div>

            {/* Checkout */}
            <div className="glass h-fit rounded-3xl p-6 lg:sticky lg:top-24">
              <h2 className="font-display text-xl font-bold text-white">Checkout</h2>
              <div className="mt-4 flex items-center justify-between border-b border-white/10 pb-4 text-sm">
                <span className="text-slate-400">Subtotal</span>
                <span className="font-display text-2xl font-black text-white">{formatBDT(cartTotal)}</span>
              </div>
              <form onSubmit={handleSubmit} className="mt-4 space-y-3">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  placeholder="Your full name *"
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-purple-400/60 focus:outline-none"
                />
                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  placeholder="Phone number (e.g. 017XXXXXXXX) *"
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-purple-400/60 focus:outline-none"
                />
                <textarea
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  required
                  rows={2}
                  placeholder="Full delivery address *"
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-purple-400/60 focus:outline-none"
                />
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={2}
                  placeholder="Additional message (optional)"
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:border-purple-400/60 focus:outline-none"
                />
                {error && <p className="rounded-xl border border-red-400/30 bg-red-500/10 p-3 text-sm text-red-300">{error}</p>}
                <button
                  type="submit"
                  disabled={submitting || items.length === 0}
                  className="w-full rounded-2xl bg-gradient-to-r from-purple-500 to-blue-600 py-4 font-bold text-white shadow-[0_0_25px_rgba(139,92,246,0.4)] transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
                >
                  {submitting ? "Placing Order..." : `Place Order · ${formatBDT(cartTotal)}`}
                </button>
                <p className="text-center text-[11px] text-slate-500">🔒 Secure order · Cash on Delivery · No advance payment needed</p>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}