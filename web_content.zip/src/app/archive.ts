// ─────────────────────────────────────────────────────────────
// Internet Archive — cine y series gratis (dominio público / CC)
// APIs públicas: CORS * verificado desde este proyecto.
// ─────────────────────────────────────────────────────────────

export type ArchiveTab = "movies" | "series" | "prelinger" | "nasa";
export interface ArchiveDoc { identifier: string; title: string; year?: number; downloads?: number }

const BASE = "https://archive.org";

export async function searchArchive(tab: ArchiveTab, query: string, page = 1, signal?: AbortSignal): Promise<{ docs: ArchiveDoc[]; numFound: number }> {
  const q = query.trim();
  const collections: Record<ArchiveTab, string> = {
    movies: "feature_films",
    series: "television",
    prelinger: "prelinger",
    nasa: "nasa",
  };
  const collection = collections[tab];
  const filters = [`collection:${collection}`, "mediatype:movies"];
  if (q) filters.push(`title:(${q}*) OR subject:(${q}) OR creator:(${q})`);
  const params = new URLSearchParams({
    q: filters.join(" AND "),
    "fl[]": "",
    rows: "24",
    page: String(page),
    output: "json",
    sort: "downloads desc",
  });
  // fl[] as repeated params
  params.delete("fl[]");
  ["identifier", "title", "year", "downloads"].forEach((f) => params.append("fl[]", f));
  const res = await fetch(`${BASE}/advancedsearch.php?${params.toString()}`, { signal });
  if (!res.ok) throw new Error("Internet Archive no disponible");
  const json = await res.json();
  const docs = (json?.response?.docs ?? []).map((d: { identifier: string; title?: string; year?: number | string; downloads?: number }) => ({
    identifier: String(d.identifier),
    title: String(d.title ?? d.identifier),
    year: d.year != null ? Number(d.year) || undefined : undefined,
    downloads: d.downloads,
  }));
  return { docs, numFound: json?.response?.numFound ?? 0 };
}

export interface ArchiveMeta {
  identifier: string;
  title: string;
  description: string;
  creators: string[];
  year?: number;
  downloads: number;
  videoFile: { name: string; format: string; sizeMb: number | null } | null;
}

const stripHtml = (s: string) => s.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();

export async function fetchArchiveMeta(identifier: string, signal?: AbortSignal): Promise<ArchiveMeta> {
  const res = await fetch(`${BASE}/metadata/${encodeURIComponent(identifier)}`, { signal });
  if (!res.ok) throw new Error("No se pudo cargar la ficha");
  const json = await res.json();
  const md = json?.metadata ?? {};
  const creators = Array.isArray(md.creator) ? md.creator : md.creator ? [md.creator] : [];
  const files: { name: string; format?: string; size?: string | number }[] = json?.files ?? [];
  const candidates = files
    .filter((f) => /\.(mp4|webm|ogv)$/i.test(f.name))
    .map((f) => ({ name: f.name, format: String(f.format ?? ""), sizeMb: f.size != null ? Math.round(Number(f.size) / 1048576) : null }));
  const pick =
    candidates.find((f) => /512kb/i.test(f.name)) ??
    candidates.find((f) => /\.mp4$/i.test(f.name)) ??
    candidates.find((f) => /\.webm$/i.test(f.name)) ??
    candidates[0] ??
    null;
  return {
    identifier,
    title: String(md.title ?? identifier),
    description: stripHtml(String(md.description ?? "")),
    creators: creators.map(String),
    year: md.year != null ? Number(md.year) || undefined : undefined,
    downloads: Number(json?.item?.downloads ?? md.downloads ?? 0) || 0,
    videoFile: pick ? { name: pick.name, format: pick.format, sizeMb: pick.sizeMb } : null,
  };
}

export function archiveVideoUrl(identifier: string, file: string): string {
  return `${BASE}/download/${encodeURIComponent(identifier)}/${encodeURIComponent(file)}`;
}
export function archiveItemUrl(identifier: string): string {
  return `${BASE}/details/${encodeURIComponent(identifier)}`;
}
export function archiveThumb(identifier: string): string {
  return `${BASE}/services/img/${encodeURIComponent(identifier)}`;
}
