import { useState } from "react";
import { BadgeCheck, Check, Copy, Download, MoreVertical, Share, MonitorDown, Smartphone, X } from "lucide-react";
import { useInstallPrompt } from "./install";

/* ── Pill flotante "Instalar TV LO3" (solo cuando el navegador lo permite) ── */
export function InstallPill() {
  const { canInstall, install } = useInstallPrompt();
  const [dismissed, setDismissed] = useState(false);
  if (!canInstall || dismissed) return null;
  return (
    <div className="fixed bottom-5 left-1/2 z-[65] flex h-14 -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-2xl border border-cyanx/40 bg-[#071231]/95 pl-4 pr-2 shadow-2xl shadow-cyan-500/20 backdrop-blur-xl">
      <Download size={18} className="text-cyanx" />
      <span className="text-xs font-bold text-white">Instala TV LO3 en tu Android</span>
      <button onClick={install} className="grad-btn flex h-10 items-center rounded-xl px-4 text-[11px] font-black uppercase tracking-wider text-white">Instalar</button>
      <button onClick={() => setDismissed(true)} aria-label="Descartar" className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:text-white"><X size={16} /></button>
    </div>
  );
}

/* ── Tarjeta completa para Ajustes: pasos + copiar enlace ── */
export function InstallCard() {
  const { canInstall, installed, install } = useInstallPrompt();
  const [copied, setCopied] = useState(false);
  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      window.prompt("Copia el enlace de la app:", window.location.href);
    }
  };

  return (
    <div className="tile rounded-2xl border-cyanx/20 bg-gradient-to-br from-cyanx/8 to-transparent p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-700"><Smartphone size={21} className="text-white" /></span>
          <div>
            <h2 className="font-display text-sm font-bold text-white">Instalar TV LO3 en tu Android</h2>
            <p className="text-[9px] uppercase tracking-wider text-slate-500">Como app nativa · sin tiendas · sin APK</p>
          </div>
        </div>
        {installed
          ? <span className="flex items-center gap-1.5 rounded-full border border-emerald-400/40 bg-emerald-400/10 px-3 py-1.5 text-[10px] font-bold text-emerald-300"><BadgeCheck size={12} /> Ya instalada</span>
          : canInstall
            ? <button onClick={install} className="grad-btn flex h-11 items-center gap-2 rounded-xl px-4 text-[11px] font-black uppercase tracking-wider text-white"><Download size={15} /> Instalar ahora</button>
            : <button onClick={copyLink} className="ghost-btn flex h-11 items-center gap-2 rounded-xl px-4 text-[11px] font-bold text-slate-200">{copied ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />}{copied ? "¡Copiado!" : "Copiar enlace"}</button>}
      </div>
      <ol className="mt-3 grid gap-1.5 text-[10px] text-slate-400 sm:grid-cols-3">
        <li className="flex items-start gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-2.5"><MoreVertical size={14} className="mt-0.5 shrink-0 text-cyanx" /><span><strong className="text-slate-200">Chrome Android:</strong> menú ⋮ → «Añadir a pantalla principal» → <strong className="text-slate-200">Instalar</strong></span></li>
        <li className="flex items-start gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-2.5"><Share size={14} className="mt-0.5 shrink-0 text-violetx" /><span><strong className="text-slate-200">iPhone Safari:</strong> botón Compartir □↑ → «Añadir a pantalla de inicio» → Añadir</span></li>
        <li className="flex items-start gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-2.5"><MonitorDown size={14} className="mt-0.5 shrink-0 text-emerald-400" /><span><strong className="text-slate-200">PC Chrome/Edge:</strong> icono ⊕ en la barra de direcciones → Instalar TV LO3</span></li>
      </ol>
      <p className="mt-2 text-[9px] text-slate-600">Tras instalar: icono propio, arranque a pantalla completa sin barra del navegador, orientación horizontal 16:9 forzada, precaché offline. Cero permisos extra, cero datos fuera de tu dispositivo.</p>
    </div>
  );
}
