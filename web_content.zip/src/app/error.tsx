"use client";

import { useEffect } from "react";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("[app]", error);
  }, [error]);

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center gap-3 px-4 text-center">
      <span className="text-4xl">⚠️</span>
      <h1 className="text-xl font-bold">Something went wrong</h1>
      <p className="text-sm text-[color:var(--muted)]">
        The page hit an unexpected error. Your saved content is safe — try again.
      </p>
      <button type="button" className="btn btn-primary" onClick={reset}>
        Try again
      </button>
    </div>
  );
}
