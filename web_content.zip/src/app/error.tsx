"use client";

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="comic-panel relative w-full max-w-lg overflow-hidden rounded-3xl p-8 text-center">
        <div className="stripes absolute inset-x-0 top-0 h-1.5 opacity-80" />
        <p className="text-[10px] font-black uppercase tracking-[0.3em] text-mv-gold">Interferenza</p>
        <h1 className="mt-2 font-display text-4xl leading-none text-white">Qualcosa ha rotto il multiverso</h1>
        <p className="mt-3 text-sm text-white/55">
          Riprova: a volte anche gli Avengers sbagliano un incantesimo.
        </p>
        <button
          type="button"
          onClick={reset}
          className="mt-6 cursor-pointer rounded-xl bg-mv-red px-5 py-3 text-xs font-black uppercase tracking-widest text-white transition hover:bg-mv-red-dark"
        >
          Riprova
        </button>
      </div>
    </div>
  );
}
