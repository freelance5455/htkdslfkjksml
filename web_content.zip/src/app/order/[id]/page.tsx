import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { formatBDT } from "@/lib/utils";

export const dynamic = "force-dynamic";

const STATUS_FLOW = ["pending", "confirmed", "shipped", "delivered"];

export default async function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.id, Number(id)));
  if (!order) notFound();
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));

  const currentStep = STATUS_FLOW.indexOf(order.status);
  const cancelled = order.status === "cancelled";

  return (
    <div className="relative min-h-screen bg-futuristic pt-28">
      <div className="mx-auto max-w-4xl px-4 pb-24">
        <nav className="mb-8 text-sm text-slate-400">
          <Link href="/orders" className="transition hover:text-purple-300">← Back to tracking</Link>
        </nav>

        <div className="glass rounded-[2rem] p-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-sm uppercase tracking-widest text-slate-400">Order Details</p>
              <h1 className="mt-1 font-mono text-3xl font-black tracking-wider text-white">{order.trackingNumber}</h1>
            </div>
            <span
              className={`rounded-full border px-4 py-1.5 text-sm font-bold capitalize ${
                order.status === "delivered"
                  ? "border-emerald-400/40 bg-emerald-500/15 text-emerald-300"
                  : order.status === "cancelled"
                    ? "border-red-400/40 bg-red-500/15 text-red-300"
                    : "border-purple-400/40 bg-purple-500/15 text-purple-300"
              }`}
            >
              {order.status}
            </span>
          </div>

          {cancelled ? (
            <div className="mt-6 rounded-xl border border-red-400/20 bg-red-500/10 p-4 text-red-300">This order was cancelled.</div>
          ) : (
            <div className="mt-8 grid grid-cols-4 gap-1">
              {STATUS_FLOW.map((s, i) => (
                <div key={s}>
                  <div className={`h-2 rounded-full ${i <= currentStep ? "bg-gradient-to-r from-purple-500 to-blue-500" : "bg-white/10"}`} />
                  <div className={`mt-2 grid h-8 w-8 place-items-center rounded-full text-sm font-bold ${i <= currentStep ? "bg-purple-500 text-white" : "bg-white/5 text-slate-500"}`}>
                    {i + 1}
                  </div>
                  <p className={`mt-1 text-xs font-bold uppercase ${i <= currentStep ? "text-purple-300" : "text-slate-500"}`}>{s}</p>
                </div>
              ))}
            </div>
          )}

          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            <div className="rounded-2xl border border-white/5 bg-black/30 p-4">
              <p className="text-xs uppercase tracking-widest text-slate-500">Customer</p>
              <p className="mt-1 font-semibold text-white">{order.customerName}</p>
              <p className="text-sm text-slate-400">{order.phone}</p>
            </div>
            <div className="rounded-2xl border border-white/5 bg-black/30 p-4">
              <p className="text-xs uppercase tracking-widest text-slate-500">Delivery Address</p>
              <p className="mt-1 text-sm text-white">{order.address}</p>
            </div>
            <div className="rounded-2xl border border-white/5 bg-black/30 p-4">
              <p className="text-xs uppercase tracking-widest text-slate-500">Placed On</p>
              <p className="mt-1 text-sm text-white">
                {new Date(order.createdAt ?? 0).toLocaleString("en-GB", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
          </div>

          {order.message && (
            <div className="mt-4 rounded-2xl border border-white/5 bg-black/30 p-4 text-sm text-slate-300">
              <span className="text-slate-500">Message: </span>{order.message}
            </div>
          )}

          <div className="mt-8 overflow-hidden rounded-2xl border border-white/10">
            <table className="w-full text-left text-sm">
              <thead className="bg-white/5 text-xs uppercase tracking-widest text-slate-400">
                <tr>
                  <th className="px-4 py-3">Product</th>
                  <th className="px-4 py-3">Qty</th>
                  <th className="px-4 py-3">Unit Price</th>
                  <th className="px-4 py-3 text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {items.map((it) => (
                  <tr key={it.id}>
                    <td className="px-4 py-3 font-semibold text-white">{it.productName}</td>
                    <td className="px-4 py-3 text-slate-300">{it.quantity}</td>
                    <td className="px-4 py-3 text-slate-300">{formatBDT(it.price)}</td>
                    <td className="px-4 py-3 text-right font-bold text-white">{formatBDT(it.price * it.quantity)}</td>
                  </tr>
                ))}
                <tr>
                  <td colSpan={3} className="px-4 py-3 text-right font-bold text-slate-300">Total</td>
                  <td className="px-4 py-3 text-right font-display text-lg font-black text-gradient">{formatBDT(order.totalPrice)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="mt-8 flex justify-center">
            <Link href="/models" className="rounded-2xl bg-gradient-to-r from-purple-500 to-blue-600 px-8 py-3 font-bold text-white shadow-[0_0_20px_rgba(139,92,246,0.4)] transition hover:brightness-110">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}