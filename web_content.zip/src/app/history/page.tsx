"use client";

import Link from "next/link";
import { TrophyIcon } from "@/components/cricket";
import { LocalMatches } from "@/components/local-matches";

/**
 * Match History.
 *
 * Reads from on-device storage so history survives app restarts with no
 * server involved. Competition context for each match is shown on the cards.
 */
export default function HistoryPage() {
  return (
    <main className="mx-auto max-w-7xl px-3 py-6 sm:px-4 sm:py-8">
      <div className="flex items-center gap-2">
        <TrophyIcon className="h-5 w-5 text-amber-400" />
        <h1 className="text-2xl font-black tracking-tight sm:text-3xl">Match History</h1>
      </div>
      <p className="mt-1 text-sm text-slate-400">
        Every match scored on this device, with final scores, result and Player of the Match. Open
        a match for the complete scorecard, or resume one that is still in progress.
      </p>

      <section className="mt-6">
        <LocalMatches
          filter="live"
          heading="In progress"
          emptyMessage="No matches in progress."
        />
      </section>

      <section className="mt-6">
        <LocalMatches
          filter="completed"
          heading="Completed"
          emptyMessage="No completed matches yet."
        />
      </section>

      <p className="mt-8 text-center text-xs text-slate-500">
        Looking for a competition?{" "}
        <Link href="/leagues" className="text-emerald-400 underline">
          Leagues &amp; Tournaments
        </Link>
      </p>
    </main>
  );
}
