import { redirect } from "next/navigation";
import AuthCard from "@/components/AuthCard";
import { getSessionUser } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const user = await getSessionUser();
  if (user) redirect("/home");
  return <AuthCard mode="login" />;
}
