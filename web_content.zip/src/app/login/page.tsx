"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";
import { HeartPulse, LogIn, ShieldCheck, Stethoscope, UserRound } from "lucide-react";
import { useAuth, useI18n, useToast, type ProfessionalSummary } from "@/components/providers";
import { buttonClass, Card, CardSkeleton, Field, Input } from "@/components/ui";
import { api } from "@/lib/api-client";
import type { CurrentUser } from "@/lib/types";

const DEMO_ACCOUNTS = [
  { key: "auth.demoPatient", email: "patient@shifacare.ma", password: "Demo@2026", icon: UserRound },

  { key: "auth.demoAdmin", email: "admin@shifacare.ma", password: "Admin@2026", icon: ShieldCheck },
];

export default function LoginPage() {
  return (
    <Suspense fallback={<CardSkeleton lines={5} />}>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const { t, te } = useI18n();
  const { setSession } = useAuth();
  const toast = useToast();
  const router = useRouter();
  const params = useSearchParams();
  const requested = params.get("next") ?? "/";
  const nextPath = requested.startsWith("/") && !requested.startsWith("//") ? requested : "/";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api<{ user: CurrentUser; professional: ProfessionalSummary | null }>("/api/auth/login", {
        body: { email: email.trim(), password },
      });
      setSession(res.user, res.professional);
      toast.success(t("auth.loginSuccess"));
      router.replace(nextPath);
    } catch (err) {
      toast.error(te(err));
      setLoading(false);
    }
  };

  return (
    <div className="grid items-start gap-8 lg:grid-cols-5">
      <div className="lg:col-span-2">
        <div className="rounded-3xl bg-gradient-to-br from-teal-600 via-teal-500 to-sky-500 p-8 text-white shadow-xl shadow-teal-600/20">
          <HeartPulse className="h-10 w-10" />
          <h1 className="mt-4 text-2xl font-extrabold leading-tight sm:text-3xl">{t("auth.loginTitle")}</h1>
          <p className="mt-3 text-sm leading-relaxed text-white/90">{t("auth.loginSubtitle")}</p>
        </div>
        <Card className="mt-6">
          <h2 className="mb-4 font-semibold text-slate-900">{t("auth.demoTitle")}</h2>
          <div className="space-y-2">
            {DEMO_ACCOUNTS.map((d) => (
              <div key={d.email} className="flex items-center gap-3 rounded-xl bg-slate-50 p-3 ring-1 ring-slate-100">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white text-teal-600 shadow-sm">
                  <d.icon className="h-4 w-4" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-800">{t(d.key)}</p>
                  <p className="truncate text-xs text-slate-500" dir="ltr">
                    {d.email}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setEmail(d.email);
                    setPassword(d.password);
                  }}
                  className="rounded-lg px-2.5 py-1.5 text-xs font-semibold text-teal-700 ring-1 ring-teal-200 transition hover:bg-teal-50"
                >
                  {t("auth.useDemo")}
                </button>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="lg:col-span-3 sm:p-8">
        <form onSubmit={onSubmit} className="space-y-5" noValidate>
          <Field label={t("common.email")} htmlFor="email">
            <Input id="email" type="email" dir="ltr" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label={t("common.password")} htmlFor="password">
            <Input id="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          <div className="flex justify-end">
            <Link href="/forgot-password" className="text-sm font-semibold text-teal-700 hover:underline">
              {t("auth.forgot")}
            </Link>
          </div>
          <button type="submit" disabled={loading} className={buttonClass("primary", "lg", "w-full")}>
            <LogIn className="h-5 w-5" />
            {loading ? t("common.loading") : t("nav.login")}
          </button>
        </form>
        <p className="mt-6 text-center text-sm text-slate-600">
          {t("auth.noAccount")}{" "}
          <Link href="/register" className="font-semibold text-teal-700 hover:underline">
            {t("nav.register")}
          </Link>
        </p>
      </Card>
    </div>
  );
}
