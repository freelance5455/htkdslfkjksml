import { notFound } from "next/navigation";
import AttractionClient from "@/components/AttractionClient";
import { getAttraction } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function AttractionPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ tickets?: string; date?: string }>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const a = await getAttraction(slug);
  if (!a) notFound();
  const tickets = Number(sp.tickets);
  const date = sp.date && /^\d{4}-\d{2}-\d{2}$/.test(sp.date) ? sp.date : undefined;
  return (
    <AttractionClient
      key={`${a.slug}-${sp.tickets ?? ""}-${sp.date ?? ""}`}
      a={a}
      initialTickets={Number.isFinite(tickets) && tickets > 0 ? tickets : undefined}
      initialDate={date}
    />
  );
}
