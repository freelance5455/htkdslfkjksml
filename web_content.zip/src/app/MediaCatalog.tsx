import { useEffect, useMemo, useState } from "react";
import { Check, Clapperboard, ExternalLink, Heart, Play, Plus, Star, X } from "lucide-react";
import { MOVIES, SERIES, hueOf, type CatalogMovie, type CatalogSeries } from "./catalog";
import { useLocalStorage, type ContinueItem } from "./store";
import { usePrivacyMax } from "./usePrivacyMax";

type Kind = "movies" | "series";

export function MoviesView({ query, onClearQuery }: { query: string; onClearQuery: () => void }) {
  return <Catalog kind="movies" query={query} onClearQuery={onClearQuery} />;
}
export function SeriesView({ query, onClearQuery }: { query: string; onClearQuery: () => void }) {
  return <Catalog kind="series" query={query} onClearQuery={onClearQuery} />;
}

function Catalog({ kind, query, onClearQuery }: { kind: Kind; query: string; onClearQuery: () => void }) {
  const [genre, setGenre] = useState("Todos");
  const [active, setActive] = useState<CatalogMovie | CatalogSeries | null>(null);
  const [favs, setFavs] = useLocalStorage<string[]>("lo3-favs", []);
  const [, setContinue] = useLocalStorage<ContinueItem[]>("lo3-continue", []);

  useEffect(() => { setGenre("Todos"); }, [kind]);

  const items = useMemo(() => (kind === "movies" ? MOVIES : SERIES) as (CatalogMovie | CatalogSeries)[], [kind]);
  const genres = useMemo(() => {
    const counts = new Map<string, number>();
    for (const item of items) for (const g of item.genres) counts.set(g, (counts.get(g) ?? 0) + 1);
    return ["Todos", ...[...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 7).map(([g]) => g)];
  }, [items]);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((item) => {
      const name = kind === "movies" ? (item as CatalogMovie).title : (item as CatalogSeries).name;
      if (genre !== "Todos" && !item.genres.includes(genre)) return false;
      if (q && !name.toLowerCase().includes(q) && !item.genres.some((g) => g.toLowerCase().includes(q))) return false;
      return true;
    });
  }, [items, genre, query, kind]);

  const toggleFav = (id: string) => setFavs((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  const startWatching = (item: CatalogMovie | CatalogSeries) => {
    const name = kind === "movies" ? (item as CatalogMovie).title : (item as CatalogSeries).name;
    setContinue((prev) => {
      const id = name;
      const rest = prev.filter((x) => x.id !== id);
      const entry: ContinueItem = { kind: kind === "movies" ? "movie" : "series", id, title: name, progress: 4 };
      return [entry, ...rest].slice(0, 8);
    });
  };

  return (
    <div className="flex h-full flex-col gap-2 overflow-y-auto p-3 thin-scroll sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-display text-lg font-black text-white">{kind === "movies" ? "Movies" : "Series"}</h1>
          <p className="text-[10px] uppercase tracking-wider text-slate-500">{kind === "movies" ? "Información verificada de Wikidata · enlaces IMDb" : "Datos reales de TVMaze · pósters oficiales"}</p>
        </div>
        <div className="flex items-center gap-2">
          {query.trim() && (
            <button onClick={onClearQuery} className="chip border-cyanx/40 text-cyanx hover:bg-cyanx/10">“{query.trim()}” <X size={11} /></button>
          )}
          <span className="chip">{shown.length} títulos</span>
        </div>
      </div>

      {/* genre filter */}
      <div className="thin-scroll -mx-1 flex gap-1 overflow-x-auto px-1" role="tablist" aria-label="Géneros">
        {genres.map((g) => (
          <button key={g} role="tab" aria-selected={genre === g} onClick={() => setGenre(g)} className={`whitespace-nowrap rounded-full px-3 py-1.5 text-[10px] font-bold transition-colors ${genre === g ? "bg-electric text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}>{g}</button>
        ))}
      </div>

      {/* grid */}
      {shown.length === 0 ? (
        <p className="rounded-2xl border border-white/8 p-8 text-center text-xs text-slate-500">Nada coincide con “{query}”. Prueba con otro término.</p>
      ) : (
        <div className="grid grid-cols-3 gap-2 pb-4 sm:grid-cols-4 lg:grid-cols-6">
          {shown.map((item) => (
            <CatalogCard key={kind === "movies" ? (item as CatalogMovie).qid : (item as CatalogSeries).id} kind={kind} item={item} fav={favs.includes(nameOf(item, kind))} onToggleFav={() => toggleFav(nameOf(item, kind))} onOpen={() => setActive(item)} />
          ))}
        </div>
      )}

      {/* detail modal */}
      {active && (
        <DetailModal kind={kind} item={active} fav={favs.includes(nameOf(active, kind))} onToggleFav={() => toggleFav(nameOf(active, kind))} onContinue={() => startWatching(active)} onClose={() => setActive(null)} />
      )}
    </div>
  );
}

function nameOf(item: CatalogMovie | CatalogSeries, kind: Kind): string {
  return kind === "movies" ? (item as CatalogMovie).title : (item as CatalogSeries).name;
}

function CatalogCard({ kind, item, fav, onToggleFav, onOpen }: { kind: Kind; item: CatalogMovie | CatalogSeries; fav: boolean; onToggleFav: () => void; onOpen: () => void }) {
  const pm = usePrivacyMax();
  const name = nameOf(item, kind);
  const isMovie = kind === "movies";
  const hue = hueOf(isMovie ? (item as CatalogMovie).qid : String((item as CatalogSeries).id));
  const series = item as CatalogSeries;
  return (
    <div className="group relative aspect-[2/3] overflow-hidden rounded-xl border border-white/10 transition-all duration-300 hover:-translate-y-1 hover:border-cyanx/40">
      {isMovie ? (
        <div className="absolute inset-0 flex flex-col justify-between p-2" style={{ background: `linear-gradient(165deg, hsl(${hue} 52% 40% / 1), hsl(${(hue + 45) % 360} 68% 14% / 1))` }}>
          {!pm && (item as CatalogMovie).image && <img src={(item as CatalogMovie).image!} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-25 mix-blend-luminosity" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />}
          <span className="relative text-[8px] font-black uppercase tracking-[0.2em] text-white/70">{(item as CatalogMovie).year}</span>
          <span className="relative">
            <span className="block font-display text-[11px] font-bold leading-tight text-white">{name}</span>
            <span className="mt-0.5 block text-[7px] uppercase tracking-wider text-white/60">{item.genres.slice(0, 2).join(" · ")}</span>
          </span>
        </div>
      ) : (
        <>
          {!pm && series.image
            ? <img src={series.image} alt={`Póster de ${name}`} loading="lazy" className="absolute inset-0 h-full w-full object-cover" onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")} />
            : <div className="absolute inset-0" style={{ background: `linear-gradient(165deg, hsl(${hue} 52% 40%), hsl(${(hue + 45) % 360} 68% 14%))` }} />}
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
          <span className="absolute left-1.5 top-1.5 text-[8px] font-black uppercase tracking-[0.2em] text-white/80">{series.year}</span>
          {series.rating != null && <span className="absolute right-1.5 top-1.5 flex items-center gap-0.5 rounded bg-black/70 px-1 py-0.5 text-[9px] font-bold text-gold"><Star size={9} fill="currentColor" />{series.rating}</span>}
          <span className="absolute inset-x-1.5 bottom-1.5">
            <span className="block font-display text-[10px] font-bold leading-tight text-white">{name}</span>
            <span className="mt-0.5 block text-[7px] uppercase tracking-wider text-white/60">{series.network ?? "Serie"}</span>
          </span>
        </>
      )}
      {/* hover actions */}
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 bg-black/55 opacity-0 backdrop-blur-[2px] transition-opacity duration-200 group-hover:opacity-100 group-focus-within:opacity-100">
        <button onClick={onOpen} className="flex h-9 items-center gap-1.5 rounded-full bg-white px-3 text-[10px] font-black uppercase tracking-wider text-abyss transition-transform hover:scale-105"><Play size={12} fill="currentColor" /> Ficha</button>
        <button onClick={onToggleFav} aria-pressed={fav} aria-label={fav ? "Quitar de favoritos" : "Añadir a favoritos"} className="flex h-8 w-8 items-center justify-center rounded-full border border-white/30 bg-black/50 transition-transform hover:scale-110">
          <Heart size={14} className={fav ? "fill-rose-500 text-rose-500" : "text-white"} />
        </button>
      </div>
    </div>
  );
}

function DetailModal({ kind, item, fav, onToggleFav, onContinue, onClose }: { kind: Kind; item: CatalogMovie | CatalogSeries; fav: boolean; onToggleFav: () => void; onContinue: () => void; onClose: () => void }) {
  const pm = usePrivacyMax();
  const [started, setStarted] = useState(false);
  const name = nameOf(item, kind);
  const isMovie = kind === "movies";
  const movie = item as CatalogMovie;
  const series = item as CatalogSeries;
  const hue = hueOf(isMovie ? movie.qid : String(series.id));

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const trailer = `https://www.youtube.com/results?search_query=${encodeURIComponent(name + " official trailer")}`;
  const external = isMovie
    ? (movie.imdb ? `https://www.imdb.com/title/${movie.imdb}/` : `https://www.imdb.com/find?q=${encodeURIComponent(name)}`)
    : series.url;

  return (
    <div role="dialog" aria-modal="true" aria-label={`Ficha de ${name}`} className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <button aria-label="Cerrar ficha" onClick={onClose} className="absolute inset-0 cursor-default bg-black/70 backdrop-blur-sm" />
      <div className="relative grid max-h-[92vh] w-full max-w-2xl grid-cols-1 overflow-y-auto rounded-2xl border border-white/12 bg-[#0b1130] shadow-2xl sm:grid-cols-[210px_1fr]">
        <button onClick={onClose} aria-label="Cerrar" className="absolute right-3 top-3 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-black/55 text-slate-300 backdrop-blur-sm hover:text-white"><X size={16} /></button>
        {/* poster panel */}
        <div className="relative min-h-44 overflow-hidden" style={{ background: `linear-gradient(160deg, hsl(${hue} 55% 34%), hsl(${(hue + 50) % 360} 70% 12%))` }}>
          {!pm && !isMovie && series.image && <img src={series.image} alt={`Póster de ${name}`} className="absolute inset-0 h-full w-full object-cover" onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")} />}
          {!pm && isMovie && movie.image && <img src={movie.image} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />}
          <div className="relative flex h-full flex-col justify-end p-4">
            <Clapperboard size={18} className="mb-auto text-white/50" />
            <p className="font-display text-xl font-black leading-tight text-white">{name}</p>
            <p className="mt-1 text-[10px] uppercase tracking-[0.2em] text-white/70">{isMovie ? movie.year : `${series.year} · ${series.status === "Ended" ? "Finalizada" : "En emisión"}`}</p>
          </div>
        </div>
        {/* body */}
        <div className="flex flex-col gap-3 p-5">
          <div className="flex flex-wrap gap-1.5">
            {item.genres.map((g) => <span key={g} className="chip">{g}</span>)}
            {!isMovie && series.rating != null && <span className="chip border-gold/40 text-gold"><Star size={10} fill="currentColor" />{series.rating}/10 TVMaze</span>}
            {!isMovie && series.network && <span className="chip">{series.network}</span>}
          </div>
          <p className="text-sm leading-relaxed text-slate-200">{isMovie ? (movie.desc || "Sin sinopsis disponible.") : (series.summary || "Sin sinopsis disponible.")}</p>
          {isMovie && movie.director && <p className="text-[11px] text-slate-400"><span className="font-bold text-slate-300">Dirección:</span> {movie.director}</p>}
          <div className="mt-auto flex flex-wrap items-center gap-2 pt-2">
            <button onClick={() => { setStarted(true); onContinue(); }} className="grad-btn flex h-11 items-center gap-2 rounded-xl px-4 text-xs font-bold text-white">
              {started ? <Check size={15} /> : <Plus size={15} />} {started ? "En tu lista" : "Continuar viendo"}
            </button>
            <button onClick={onToggleFav} aria-pressed={fav} className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/12 bg-white/5 text-slate-300 transition-transform hover:scale-105" aria-label="Alternar favorito">
              <Heart size={18} className={fav ? "fill-rose-500 text-rose-500" : ""} />
            </button>
            <a href={trailer} target="_blank" rel="noopener noreferrer" className="ghost-btn flex h-11 items-center gap-2 rounded-xl px-4 text-xs font-bold text-white"><Play size={14} className="text-cyanx" /> Tráiler</a>
            <a href={external} target="_blank" rel="noopener noreferrer" className="ghost-btn flex h-11 items-center gap-2 rounded-xl px-4 text-xs font-bold text-slate-200">{isMovie ? "IMDb" : "TVMaze"} <ExternalLink size={12} /></a>
          </div>
          <p className="text-[9px] text-slate-600">{isMovie ? "Ficha: Wikidata / IMDb · carátula: Commons (si existe)" : "Póster y datos: TVMaze · clasificación de audiencia propia de TVMaze"} · El streaming comercial depende de tu suscripción — TV LO3 abre la ficha y tus listas, no retransmite sin licencia.</p>
        </div>
      </div>
    </div>
  );
}
