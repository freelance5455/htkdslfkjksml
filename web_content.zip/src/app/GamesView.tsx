import { useEffect, useRef, useState } from "react";
import { Lightbulb, Medal, CheckCircle2, ExternalLink, Gamepad2, Play, RotateCcw, Star, Trophy } from "lucide-react";
import { useLocalStorage } from "./useLocalStorage";
import { MOVIES, SERIES } from "./catalog";
import { hueOf } from "./catalog";

const OPEN_SOURCE_GAMES = [
  { repo: "Hextris/hextris", name: "Hextris", desc: "Puzzle de reflejos estilo Tetris con fichas hexagonales.", stars: 2449, url: "https://github.com/Hextris/hextris" },
  { repo: "mozilla/BrowserQuest", name: "BrowserQuest", desc: "MMORPG multijugador HTML5 original de Mozilla.", stars: 9369, url: "https://github.com/mozilla/BrowserQuest" },
  { repo: "freeciv/freeciv-web", name: "Freeciv-web", desc: "Estrategia 4X por turnos, sucesor abierto de Civilization.", stars: 2219, url: "https://github.com/freeciv/freeciv-web" },
  { repo: "phaserjs/phaser-ce-examples", name: "Phaser CE Examples", desc: "Cientos de minijuegos y demos listos para aprender y jugar.", stars: 1783, url: "https://github.com/phaserjs/phaser-ce-examples" },
  { repo: "4ian/GDevelop", name: "GDevelop", desc: "Motor de juegos 2D de código abierto — cero código.", stars: 29267, url: "https://github.com/4ian/GDevelop" },
  { repo: "KilledByAPixel/LittleJS", name: "LittleJS Engine", desc: "Motor 2D/3D ultraligero y sin dependencias para juegos web.", stars: 4403, url: "https://github.com/KilledByAPixel/LittleJS" },
];

const ACHIEVEMENTS = [
  { id: "dash-50", label: "Sobreviviente · 50 m", at: 50 },
  { id: "dash-150", label: "Domador de neón · 150 m", at: 150 },
  { id: "dash-300", label: "Leyenda TV LO3 · 300 m", at: 300 },
] as const;

const LOGICAL_W = 480;
const LOGICAL_H = 270;
const GROUND = LOGICAL_H - 46;

export default function GamesView({ onNavigate }: { onNavigate: (route: string) => void }) {
  const [pane, setPane] = useState<"catalog" | "trivia">("catalog");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<"ready" | "playing" | "over">("ready");
  const [uiState, setUiState] = useState<"ready" | "playing" | "over">("ready");
  const [score, setScore] = useState(0);
  const [best, setBest] = useLocalStorage<number>("lo3-neon-best", 0);
  const [unlocked, setUnlocked] = useLocalStorage<string[]>("lo3-neon-ach", []);
  const [toast, setToast] = useState<string | null>(null);
  const bestRef = useRef(best);
  bestRef.current = best;
  const unlockedRef = useRef(unlocked);
  unlockedRef.current = unlocked;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = LOGICAL_W * dpr;
    canvas.height = LOGICAL_H * dpr;
    ctx.scale(dpr, dpr);

    let raf = 0;
    let last = performance.now();
    const player = { x: 72, y: GROUND - 16, vy: 0, size: 15 };
    const obstacles: { x: number; w: number; h: number }[] = [];
    let distance = 0;
    let speed = 3.1;
    let spawnTimer = 0;
    let gridOffset = 0;
    const stars = Array.from({ length: 46 }, () => ({ x: Math.random() * LOGICAL_W, y: Math.random() * (GROUND - 60), s: Math.random() * 1.4 + 0.4, tw: Math.random() * Math.PI * 2 }));

    const reset = () => {
      player.y = GROUND - player.size;
      player.vy = 0;
      obstacles.length = 0;
      distance = 0;
      speed = 3.1;
      spawnTimer = 0;
      gridOffset = 0;
    };

    const jump = () => {
      if (stateRef.current !== "playing") return;
      if (player.y >= GROUND - player.size - 0.5) player.vy = -8.4;
    };

    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") {
        e.preventDefault();
        if (stateRef.current === "playing") jump(); else start();
      }
    };
    const onPointer = () => { if (stateRef.current === "playing") jump(); else start(); };
    window.addEventListener("keydown", onKey);
    canvas.addEventListener("pointerdown", onPointer);

    const start = () => {
      reset();
      stateRef.current = "playing";
      setUiState("playing");
      setScore(0);
    };

    const finish = () => {
      stateRef.current = "over";
      setUiState("over");
      const finalScore = Math.floor(distance);
      setScore(finalScore);
      if (finalScore > bestRef.current) setBest(finalScore);
      for (const a of ACHIEVEMENTS) {
        if (finalScore >= a.at && !unlockedRef.current.includes(a.id)) {
          setUnlocked((p) => [...p, a.id]);
          setToast(a.label);
          window.setTimeout(() => setToast(null), 2600);
        }
      }
    };

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const dt = Math.min(0.033, (now - last) / 1000);
      last = now;
      const playing = stateRef.current === "playing";

      // physics
      if (playing) {
        speed = Math.min(7.2, speed + dt * 0.16);
        distance += speed * dt * 3.4;
        player.vy += 0.34;
        player.y = Math.min(GROUND - player.size, player.y + player.vy);
        gridOffset = (gridOffset + speed * dt * 8) % 48;
        spawnTimer -= dt;
        if (spawnTimer <= 0) {
          obstacles.push({ x: LOGICAL_W + 10, w: 12 + Math.random() * 10, h: 34 + Math.random() * 52 });
          spawnTimer = 0.75 + Math.random() * 0.75;
        }
        for (const o of obstacles) o.x -= speed * dt * 60;
        for (let i = obstacles.length - 1; i >= 0; i--) if (obstacles[i].x + obstacles[i].w < -20) obstacles.splice(i, 1);
        // collision
        for (const o of obstacles) {
          if (player.x < o.x + o.w && player.x + player.size > o.x && player.y + player.size > GROUND - o.h) { finish(); break; }
        }
        setScore(Math.floor(distance));
      }

      // draw
      const sky = ctx.createLinearGradient(0, 0, 0, LOGICAL_H);
      sky.addColorStop(0, "#060a24");
      sky.addColorStop(0.55, "#120a35");
      sky.addColorStop(1, "#04061a");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, LOGICAL_W, LOGICAL_H);
      // sun
      const sun = ctx.createRadialGradient(LOGICAL_W / 2, GROUND - 66, 6, LOGICAL_W / 2, GROUND - 66, 84);
      sun.addColorStop(0, "rgba(255,120,220,0.9)");
      sun.addColorStop(0.4, "rgba(168,85,247,0.55)");
      sun.addColorStop(1, "rgba(168,85,247,0)");
      ctx.fillStyle = sun;
      ctx.fillRect(0, 0, LOGICAL_W, LOGICAL_H);
      // stars
      for (const s of stars) {
        ctx.globalAlpha = 0.5 + 0.5 * Math.sin(now / 500 + s.tw);
        ctx.fillStyle = "#cfe4ff";
        ctx.fillRect(s.x, s.y, s.s, s.s);
      }
      ctx.globalAlpha = 1;
      // grid floor
      ctx.strokeStyle = "rgba(56,189,248,0.5)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = -48 + gridOffset; x < LOGICAL_W + 48; x += 48) {
        ctx.moveTo(LOGICAL_W / 2 + (x - LOGICAL_W / 2) * 0.32, GROUND);
        ctx.lineTo(x, LOGICAL_H);
      }
      for (let y = GROUND; y <= LOGICAL_H; y += 9) { ctx.moveTo(0, y); ctx.lineTo(LOGICAL_W, y); }
      ctx.stroke();
      // ground line
      ctx.strokeStyle = "rgba(125,216,255,0.9)";
      ctx.shadowColor = "#22d3ee";
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.moveTo(0, GROUND + 0.5);
      ctx.lineTo(LOGICAL_W, GROUND + 0.5);
      ctx.stroke();
      ctx.shadowBlur = 0;
      // obstacles
      for (const o of obstacles) {
        ctx.fillStyle = "#f472b6";
        ctx.shadowColor = "#ec4899";
        ctx.shadowBlur = 14;
        ctx.fillRect(o.x, GROUND - o.h, o.w, o.h);
        ctx.shadowBlur = 0;
        ctx.fillStyle = "rgba(255,255,255,0.35)";
        ctx.fillRect(o.x + 2, GROUND - o.h + 3, 2, o.h - 6);
      }
      // player (glowing delta)
      ctx.save();
      ctx.translate(player.x + player.size / 2, player.y + player.size / 2);
      ctx.fillStyle = "#22d3ee";
      ctx.shadowColor = "#22d3ee";
      ctx.shadowBlur = 16;
      ctx.beginPath();
      ctx.moveTo(0, -player.size * 0.62);
      ctx.lineTo(player.size * 0.58, player.size * 0.5);
      ctx.lineTo(0, player.size * 0.2);
      ctx.lineTo(-player.size * 0.58, player.size * 0.5);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", onKey);
      canvas.removeEventListener("pointerdown", onPointer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="grid h-full gap-3 overflow-y-auto p-3 thin-scroll sm:p-4 lg:grid-cols-5">
      {/* playable game */}
      <section className="relative overflow-hidden rounded-2xl border border-violetx/30 lg:col-span-3">
        <img src="/img/art-controller.jpg" alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover opacity-25" />
        <div className="absolute inset-0 bg-gradient-to-br from-[#04061a]/70 to-[#04061a]/30" />
        <div className="relative flex h-full min-h-[300px] flex-col p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gamepad2 size={18} className="text-lilac" />
              <h1 className="font-display text-lg font-black text-white">Neon Dash <span className="text-xs font-bold text-slate-400">· original TV LO3</span></h1>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-bold text-slate-300">
              <span className="chip">Puntos {score}</span>
              <span className="chip border-gold/40 text-gold"><Star size={10} fill="currentColor" /> Récord {best}</span>
            </div>
          </div>

          <div className="relative mt-3 flex-1 overflow-hidden rounded-xl border border-white/15 shadow-2xl">
            <canvas ref={canvasRef} className="h-full w-full touch-none select-none" style={{ aspectRatio: "16/9" }} aria-label="Neon Dash — haz clic o pulsa espacio para saltar" />
            {uiState !== "playing" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/55 backdrop-blur-[2px]">
                {uiState === "over" && <p className="font-display text-2xl font-black text-white">{score}<span className="text-sm text-slate-400"> m</span></p>}
                {uiState === "over" && <p className="text-[11px] font-semibold text-slate-400">Récord: {best} m</p>}
                <button onClick={() => { const c = canvasRef.current; c?.dispatchEvent(new PointerEvent("pointerdown")); }} className="grad-btn flex h-12 items-center gap-2 rounded-xl px-6 text-sm font-black uppercase tracking-wider text-white">
                  {uiState === "over" ? <RotateCcw size={17} /> : <Play size={17} fill="currentColor" />} {uiState === "over" ? "Reintentar" : "Jugar"}
                </button>
                <p className="text-[10px] text-slate-500">Espacio / ↑ / clic para saltar · mando Bluetooth compatible</p>
              </div>
            )}
            {toast && (
              <div className="absolute left-1/2 top-3 -translate-x-1/2 rounded-xl border border-gold/50 bg-black/80 px-4 py-2 text-center backdrop-blur-md">
                <Medal size={15} className="mx-auto text-gold" />
                <p className="mt-0.5 text-[11px] font-bold text-gold">Logro desbloqueado</p>
                <p className="text-[10px] text-slate-200">{toast}</p>
              </div>
            )}
          </div>

          {/* achievements */}
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            {ACHIEVEMENTS.map((a) => {
              const got = unlocked.includes(a.id);
              return (
                <span key={a.id} className={`chip ${got ? "border-gold/50 text-gold" : "opacity-50"}`}>
                  {got ? <CheckCircle2 size={11} /> : <Medal size={11} />}{a.label}
                </span>
              );
            })}
          </div>
        </div>
      </section>

      {/* open-source catalog / trivia */}
      <aside className="flex min-h-0 flex-col gap-2 lg:col-span-2">
        <div className="flex gap-1 rounded-xl border border-white/10 bg-white/[0.04] p-1" role="tablist" aria-label="Vista del catálogo">
          <button role="tab" aria-selected={pane === "catalog"} onClick={() => setPane("catalog")} className={`flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg text-[10px] font-bold transition-colors ${pane === "catalog" ? "bg-electric text-white" : "text-slate-400 hover:text-white"}`}><Gamepad2 size={13} />Catálogo</button>
          <button role="tab" aria-selected={pane === "trivia"} onClick={() => setPane("trivia")} className={`flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg text-[10px] font-bold transition-colors ${pane === "trivia" ? "bg-violetx text-white" : "text-slate-400 hover:text-white"}`}><Lightbulb size={13} />Trivia de cine</button>
        </div>
        {pane === "catalog" ? (<>
        <div className="tile rounded-2xl p-4">
          <h2 className="font-display text-base font-bold text-white">Catálogo open-source</h2>
          <p className="text-[10px] uppercase tracking-wider text-slate-500">Los juegos web libres más populares en GitHub · verificados hoy</p>
        </div>
        <div className="thin-scroll min-h-0 flex-1 space-y-2 overflow-y-auto pr-0.5">
          {OPEN_SOURCE_GAMES.map((g) => (
            <a key={g.repo} href={g.url} target="_blank" rel="noopener noreferrer" className="group flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.02] p-2.5 transition-colors hover:border-violetx/40">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl font-display text-base font-black text-white" style={{ background: `linear-gradient(150deg, hsl(${hueOf(g.repo)} 60% 42%), hsl(${(hueOf(g.repo) + 45) % 360} 65% 18%))` }}>{g.name[0]}</span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-xs font-bold text-slate-100 transition-colors group-hover:text-white">{g.name}</span>
                <span className="line-clamp-2 text-[9px] leading-snug text-slate-500">{g.desc}</span>
                <span className="mt-1 block text-[9px] font-bold text-gold">★ {g.stars.toLocaleString("es-ES")}</span>
              </span>
              <ExternalLink size={13} className="shrink-0 text-slate-600 transition-colors group-hover:text-lilac" />
            </a>
          ))}
        </div>
        </>) : <TriviaPane />}
        {pane === "catalog" && <button onClick={() => onNavigate("store")} className="ghost-btn flex h-11 items-center justify-center gap-2 rounded-xl text-xs font-bold text-white">Ver tiendas de apps en TV LO3 Store <ExternalLink size={13} /></button>}
      </aside>
    </div>
  );
}

/* ════════════════════ TRIVIA DE CINE (datos reales TMDB/TVMaze) ════════════════════ */
interface TQ { q: string; options: string[]; answer: number }

const shuffled = <T,>(arr: T[]): T[] => [...arr].sort(() => Math.random() - 0.5);

function buildQuestions(): TQ[] {
  const qs: TQ[] = [];
  const withYear = shuffled(MOVIES.filter((m) => m.year != null));
  for (const m of withYear.slice(0, 4)) {
    const y = m.year as number;
    const wrong = shuffled([y - 3, y - 2, y - 1, y + 1, y + 2, y + 4]).filter((v) => v > 1880).slice(0, 3);
    const options = shuffled([y, ...wrong]).map(String);
    qs.push({ q: `¿En qué año se estrenó «${m.title}»?`, options, answer: options.indexOf(String(y)) });
  }
  const withDir = shuffled(MOVIES.filter((m) => m.director));
  const allDirs = [...new Set(MOVIES.map((m) => m.director).filter(Boolean) as string[])];
  for (const m of withDir.slice(0, 4)) {
    const options = shuffled([m.director as string, ...shuffled(allDirs.filter((d) => d !== m.director)).slice(0, 3)]);
    qs.push({ q: `¿Quién dirigió «${m.title}»?`, options, answer: options.indexOf(m.director as string) });
  }
  const allGenres = [...new Set(MOVIES.flatMap((m) => m.genres))];
  for (const m of shuffled(MOVIES.filter((m) => m.genres.length > 0)).slice(0, 2)) {
    const g = m.genres[0];
    const options = shuffled([g, ...shuffled(allGenres.filter((x) => x !== g)).slice(0, 3)]);
    qs.push({ q: `¿Qué género describe mejor «${m.title}»?`, options, answer: options.indexOf(g) });
  }
  const withRating = shuffled(SERIES.filter((s) => s.rating != null));
  for (const s of withRating.slice(0, 1)) {
    const r = s.rating as number;
    const options = shuffled([r, Math.min(10, +(r + 0.8).toFixed(1)), Math.max(1, +(r - 1.4).toFixed(1)), Math.min(10, +(r + 1.6).toFixed(1))]).map((v) => v.toFixed(1));
    qs.push({ q: `¿Qué puntuación tiene «${s.name}» en TVMaze?`, options, answer: options.indexOf(r.toFixed(1)) });
  }
  const nets = [...new Set(SERIES.map((s) => s.network).filter(Boolean) as string[])];
  for (const s of shuffled(SERIES.filter((s) => s.network)).slice(0, 1)) {
    const n = s.network as string;
    const options = shuffled([n, ...shuffled(nets.filter((x) => x !== n)).slice(0, 3)]);
    qs.push({ q: `¿En qué cadena se emite/emitió «${s.name}»?`, options, answer: options.indexOf(n) });
  }
  return shuffled(qs).slice(0, 12);
}

function TriviaPane() {
  const [phase, setPhase] = useState<"intro" | "play" | "done">("intro");
  const [questions, setQuestions] = useState<TQ[]>([]);
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [gain, setGain] = useState(0);
  const [best, setBest] = useLocalStorage<number>("lo3-trivia-best", 0);
  const [bestBefore, setBestBefore] = useState(0);

  const start = () => {
    setQuestions(buildQuestions());
    setIdx(0);
    setScore(0);
    setStreak(0);
    setPicked(null);
    setGain(0);
    setBestBefore(best);
    setPhase("play");
  };

  const answer = (i: number) => {
    if (picked !== null) return;
    setPicked(i);
    const correct = questions[idx].answer === i;
    const g = correct ? 100 + streak * 25 : 0;
    setGain(g);
    setScore((v) => v + g);
    setStreak((v) => (correct ? v + 1 : 0));
    window.setTimeout(() => {
      const total = score + g;
      if (idx + 1 >= questions.length) {
        if (total > best) setBest(total);
        setPhase("done");
      } else {
        setIdx(idx + 1);
        setPicked(null);
        setGain(0);
      }
    }, 1100);
  };

  if (phase === "intro") {
    return (
      <div className="tile flex flex-1 flex-col items-center justify-center gap-3 rounded-2xl p-6 text-center">
        <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violetx to-electric"><Lightbulb size={30} className="text-white" /></span>
        <div>
          <h3 className="font-display text-2xl font-black text-white">Trivia de cine</h3>
          <p className="mt-1 max-w-[16rem] text-[11px] text-slate-400">12 preguntas generadas con tu propio catálogo — estrenos, directores, géneros y cadenas. Datos reales, cero cuentos.</p>
        </div>
        <div className="flex items-center gap-2 chip border-gold/40 text-gold"><Trophy size={12} /> Récord: {best} pts</div>
        <button onClick={start} className="grad-btn flex h-12 items-center gap-2 rounded-xl px-6 text-sm font-black uppercase tracking-wider text-white"><Play size={16} fill="currentColor" /> Jugar</button>
      </div>
    );
  }

  if (phase === "done") {
    const newBest = score > bestBefore;
    return (
      <div className="tile flex flex-1 flex-col items-center justify-center gap-3 rounded-2xl p-6 text-center">
        <Trophy size={40} className={newBest ? "text-gold" : "text-slate-600"} />
        <p className="font-display text-4xl font-black text-white">{score}<span className="text-base text-slate-500"> pts</span></p>
        {newBest
          ? <p className="rounded-full border border-gold/50 bg-gold/10 px-4 py-1.5 text-[11px] font-black uppercase tracking-widest text-gold">¡Nuevo récord!</p>
          : <p className="text-[11px] text-slate-400">Tu récord: {best} pts</p>}
        <button onClick={start} className="grad-btn flex h-12 items-center gap-2 rounded-xl px-6 text-sm font-black uppercase tracking-wider text-white"><RotateCcw size={15} /> Otra ronda</button>
      </div>
    );
  }

  const q = questions[idx];
  const answered = picked !== null;
  return (
    <div className="tile flex min-h-0 flex-1 flex-col rounded-2xl p-4">
      <div className="flex items-center justify-between gap-2">
        <div className="flex gap-1">{questions.map((_, i) => <span key={i} className={`h-1.5 w-4 rounded-full ${i < idx ? "bg-violetx" : i === idx ? "bg-cyanx" : "bg-white/10"}`} />)}</div>
        <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-wider text-slate-400">
          {streak >= 2 && <span className="flex items-center gap-1 text-amber-400">Racha ×{streak}</span>}
          <span className="tabular-nums text-cyanx">{score} pts</span>
        </div>
      </div>
      <p className="mt-3 text-[10px] font-black uppercase tracking-[0.25em] text-slate-500">Pregunta {idx + 1}/12</p>
      <h3 className="mt-1 min-h-14 font-display text-lg font-bold leading-snug text-white">{q.q}</h3>
      <div className="mt-2 flex flex-col gap-2">
        {q.options.map((opt, i) => {
          const isAnswer = q.answer === i;
          const state = !answered ? "idle" : isAnswer ? "right" : picked === i ? "wrong" : "dim";
          const cls = state === "right" ? "border-emerald-400/70 bg-emerald-500/15 text-emerald-200" : state === "wrong" ? "border-rose-500/70 bg-rose-500/15 text-rose-200" : state === "dim" ? "border-white/8 bg-white/[0.02] text-slate-500" : "border-white/12 bg-white/[0.04] text-slate-100 hover:border-cyanx/40 hover:text-white";
          return (
            <button key={i} onClick={() => answer(i)} disabled={answered} className={`flex h-12 items-center justify-between rounded-xl border px-4 text-left text-[12px] font-semibold transition-all ${cls}`}>
              <span className="truncate">{opt}</span>
              {state === "right" && <CheckCircle2 size={17} className="shrink-0" />}
            </button>
          );
        })}
      </div>
      {gain > 0 && <p className="pointer-events-none mt-2 text-center font-display text-xl font-black text-emerald-400">+{gain}</p>}
      <p className="mt-auto pt-3 text-center text-[9px] uppercase tracking-[0.25em] text-slate-600">100 pts base · +25 por racha</p>
    </div>
  );
}
