"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Bell, BellRing, CheckCheck } from "lucide-react";
import { useAuth, useI18n, useToast } from "@/components/providers";
import { Button, CardSkeleton, EmptyState, ErrorState, LoginPrompt, PageHeader } from "@/components/ui";
import { api } from "@/lib/api-client";
import type { NotificationDTO } from "@/lib/types";
import { cn, formatDateTime, loc } from "@/lib/utils";

export default function NotificationsPage() {
  const { t, locale, te } = useI18n();
  const { user, loading: authLoading } = useAuth();
  const toast = useToast();
  const router = useRouter();
  const [items, setItems] = useState<NotificationDTO[] | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    if (!user) return;
    let alive = true;
    setError(false);
    api<{ notifications: NotificationDTO[] }>("/api/notifications")
      .then((r) => alive && setItems(r.notifications))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [user, reloadKey]);

  /** Optimistic: every notification is shown as read at once; restored on failure. */
  const markAllRead = async () => {
    if (!items) return;
    const previous = items;
    setItems(items.map((n) => ({ ...n, isRead: true })));
    try {
      await api("/api/notifications", { method: "PATCH" });
      window.dispatchEvent(new Event("shifacare:notifications"));
    } catch (err) {
      setItems(previous);
      toast.error(te(err));
    }
  };

  if (authLoading) return <CardSkeleton lines={4} />;
  if (!user)
    return (
      <div>
        <PageHeader title={t("notif.title")} subtitle={t("notif.subtitle")} />
        <LoginPrompt message={t("book.loginRequired")} next="/notifications" />
      </div>
    );

  const unread = items?.filter((n) => !n.isRead).length ?? 0;

  return (
    <div>
      <PageHeader
        title={t("notif.title")}
        subtitle={t("notif.subtitle")}
        actions={
          unread > 0 ? (
            <Button variant="secondary" onClick={() => void markAllRead()}>
              <CheckCheck className="h-4 w-4" />
              {t("notif.markAll")}
            </Button>
          ) : undefined
        }
      />

      {error ? (
        <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
      ) : !items ? (
        <div className="space-y-3">
          <CardSkeleton lines={2} />
          <CardSkeleton lines={2} />
        </div>
      ) : items.length === 0 ? (
        <EmptyState icon={Bell} title={t("notif.empty")} />
      ) : (
        <ul className="space-y-3">
          {items.map((n) => {
            const clickable = !!n.link;
            return (
              <li key={n.id}>
                <button
                  type="button"
                  disabled={!clickable}
                  onClick={() => clickable && router.push(n.link)}
                  className={cn(
                    "flex w-full items-start gap-4 rounded-2xl p-5 text-start shadow-sm ring-1 transition",
                    n.isRead ? "bg-white ring-sky-100/80" : "bg-gradient-to-r from-teal-50/80 to-white ring-teal-200",
                    clickable && "hover:shadow-md",
                  )}
                >
                  <span
                    className={cn(
                      "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
                      n.isRead ? "bg-slate-100 text-slate-500" : "bg-teal-600 text-white",
                    )}
                  >
                    {n.isRead ? <Bell className="h-5 w-5" /> : <BellRing className="h-5 w-5" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center justify-between gap-2">
                      <span className={cn("font-semibold", n.isRead ? "text-slate-800" : "text-slate-900")}>{loc(n.title, locale)}</span>
                      <span className="text-xs text-slate-500">{formatDateTime(n.createdAt, locale)}</span>
                    </span>
                    <span className="mt-1 block text-sm leading-relaxed text-slate-600">{loc(n.message, locale)}</span>
                  </span>
                  {!n.isRead && <span className="mt-2 h-2.5 w-2.5 shrink-0 rounded-full bg-teal-500" aria-label={t("notif.unread")} />}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
