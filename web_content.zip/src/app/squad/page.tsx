import { SquadApp } from "@/components/squad-app";
import { SquadGate } from "@/components/squad-gate";
import { ensureSeeded, getRecentActivity, getSessionMember, getSquadSnapshot } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function SquadPage() {
  await ensureSeeded();

  // Percorso veloce: se il cookie è disponibile usiamo i dati del server.
  const session = await getSessionMember().catch(() => null);

  if (session) {
    const snapshot = await getSquadSnapshot(session.squad.id).catch(() => null);
    const me = snapshot?.members.find((member) => member.id === session.member.id);

    if (snapshot && me) {
      const activity = await getRecentActivity(session.squad.id).catch(() => []);
      return <SquadApp snapshot={snapshot} me={me} activity={activity} />;
    }
  }

  // Altrimenti (cookie bloccati) ci pensa il client con il token salvato.
  return <SquadGate />;
}
