"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { goTo } from "@/lib/navigate";
import {
  DEFAULT_POINTS,
  generateFixtures,
  newId,
  type Competition,
  type CompetitionFormat,
  type CompetitionType,
  type CompTeam,
} from "@/lib/competition";
import { saveCompetition } from "@/lib/competition-store";
import type { MatchFormat } from "@/lib/types";
import { TeamLogo, TrophyIcon } from "@/components/cricket";

const FORMATS: { key: MatchFormat; overs: number }[] = [
  { key: "T5", overs: 5 },
  { key: "T10", overs: 10 },
  { key: "T20", overs: 20 },
  { key: "T30", overs: 30 },
  { key: "T50", overs: 50 },
  { key: "Custom", overs: 12 },
];

const input =
  "w-full rounded-lg border border-slate-700 bg-slate-900/70 px-3 py-2.5 text-sm outline-none focus:border-emerald-500";
const label = "mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400";

export default function NewCompetitionPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [type, setType] = useState<CompetitionType>("league");
  const [format, setFormat] = useState<CompetitionFormat>("single-round-robin");
  const [season, setSeason] = useState(String(new Date().getFullYear()));
  const [location, setLocation] = useState("");
  const [organizer, setOrganizer] = useState("");
  const [startDate, setStartDate] = useState(new Date().toISOString().slice(0, 10));
  const [endDate, setEndDate] = useState("");
  const [oversFormat, setOversFormat] = useState<MatchFormat>("T20");
  const [overs, setOvers] = useState(20);
  const [ballType, setBallType] = useState("Tape Ball");
  const [logo, setLogo] = useState("");
  const [groupCount, setGroupCount] = useState(2);
  const [qualifyPerGroup, setQualifyPerGroup] = useState(2);
  const [points, setPoints] = useState({ ...DEFAULT_POINTS });
  const [teamNames, setTeamNames] = useState<string[]>(["", "", "", ""]);

  const named = teamNames.map((t) => t.trim()).filter(Boolean);

  function setTeam(i: number, v: string) {
    const next = [...teamNames];
    next[i] = v;
    setTeamNames(next);
  }

  async function create() {
    setError(null);
    if (!name.trim()) return setError("Enter a competition name.");
    if (named.length < 2) return setError("Add at least 2 teams.");
    if (new Set(named.map((n) => n.toLowerCase())).size !== named.length)
      return setError("Team names must be unique.");

    setSaving(true);
    try {
      const id = newId();
      const teams: CompTeam[] = named.map((n, i) => ({
        id: newId(),
        name: n,
        players: [],
        group:
          format === "group-knockout"
            ? String.fromCharCode(65 + (i % Math.max(1, groupCount)))
            : undefined,
      }));

      const fixtures = generateFixtures({
        competitionId: id,
        teams,
        format,
        overs,
        venue: location.trim() || undefined,
        startDate,
        groupCount,
        qualifyPerGroup,
      });

      const comp: Competition = {
        id,
        name: name.trim(),
        type,
        format,
        season: season.trim() || undefined,
        location: location.trim() || undefined,
        organizer: organizer.trim() || undefined,
        startDate,
        endDate: endDate || undefined,
        oversFormat,
        overs,
        ballType: ballType.trim() || undefined,
        logo: logo.trim() || undefined,
        teams,
        fixtures,
        points,
        groupCount: format === "group-knockout" ? groupCount : undefined,
        qualifyPerGroup: format === "group-knockout" ? qualifyPerGroup : undefined,
        playerOfTournament: null,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        rev: 0,
        syncedRev: 0,
      };
      await saveCompetition(comp);
      goTo(router, `/league?id=${id}`);
    } catch (e) {
      console.error("[match-cricket] competition creation failed:", e);
      setError("Could not create the competition on this device. Please try again.");
      setSaving(false);
    }
  }

  return (
    <main className="mx-auto max-w-3xl px-3 py-6 sm:px-4">
      <div className="flex items-center gap-2">
        <TrophyIcon className="h-5 w-5 text-amber-400" />
        <h1 className="text-xl font-black tracking-tight sm:text-2xl">New Competition</h1>
      </div>

      <div className="mt-4 flex gap-1.5">
        {["Details", "Format", "Teams"].map((s, i) => (
          <div
            key={s}
            className={`flex h-8 flex-1 items-center justify-center rounded-lg text-[11px] font-black uppercase ${
              step === i + 1
                ? "bg-emerald-500 text-slate-950"
                : step > i + 1
                  ? "bg-emerald-500/15 text-emerald-300"
                  : "border border-slate-800 text-slate-500"
            }`}
          >
            {step > i + 1 ? "✓ " : `${i + 1}. `}
            {s}
          </div>
        ))}
      </div>

      {step === 1 && (
        <section className="mc-card mt-4 space-y-4 px-4 py-4">
          <div>
            <label className={label}>Competition name</label>
            <div className="flex items-center gap-2.5">
              <TeamLogo name={name || "C"} logo={logo} size={40} />
              <input
                className={input}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ramadan Cup 2026"
                autoFocus
              />
            </div>
            <input
              className={`${input} mt-2`}
              value={logo}
              onChange={(e) => setLogo(e.target.value)}
              placeholder="Logo URL (optional)"
            />
          </div>

          <div>
            <label className={label}>Competition type</label>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  ["league", "League"],
                  ["tournament", "Tournament"],
                ] as const
              ).map(([k, l]) => (
                <button
                  key={k}
                  onClick={() => {
                    setType(k);
                    setFormat(k === "league" ? "single-round-robin" : "group-knockout");
                  }}
                  className={`mc-btn h-10 rounded-lg text-sm font-black ${
                    type === k
                      ? "bg-emerald-500 text-slate-950"
                      : "border border-slate-700 text-slate-300"
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className={label}>Season / Year</label>
              <input className={input} value={season} onChange={(e) => setSeason(e.target.value)} />
            </div>
            <div>
              <label className={label}>Location</label>
              <input
                className={input}
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Central Ground"
              />
            </div>
            <div>
              <label className={label}>Organizer</label>
              <input
                className={input}
                value={organizer}
                onChange={(e) => setOrganizer(e.target.value)}
              />
            </div>
            <div>
              <label className={label}>Ball type</label>
              <select
                className={input}
                value={ballType}
                onChange={(e) => setBallType(e.target.value)}
              >
                {["Tape Ball", "Hard Ball", "Leather", "Tennis"].map((b) => (
                  <option key={b}>{b}</option>
                ))}
              </select>
            </div>
            <div>
              <label className={label}>Start date</label>
              <input
                type="date"
                className={input}
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div>
              <label className={label}>End date</label>
              <input
                type="date"
                className={input}
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>

          <button
            onClick={() => {
              if (!name.trim()) return setError("Enter a competition name.");
              setError(null);
              setStep(2);
            }}
            className="mc-btn h-11 w-full rounded-xl bg-emerald-500 text-sm font-black text-slate-950"
          >
            Continue
          </button>
        </section>
      )}

      {step === 2 && (
        <section className="mc-card mt-4 space-y-4 px-4 py-4">
          <div>
            <label className={label}>Overs format</label>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
              {FORMATS.map((f) => (
                <button
                  key={f.key}
                  onClick={() => {
                    setOversFormat(f.key);
                    if (f.key !== "Custom") setOvers(f.overs);
                  }}
                  className={`mc-btn h-9 rounded-lg text-xs font-black ${
                    oversFormat === f.key
                      ? "bg-emerald-500 text-slate-950"
                      : "border border-slate-700 text-slate-300"
                  }`}
                >
                  {f.key}
                </button>
              ))}
            </div>
            <input
              type="number"
              min={1}
              max={90}
              className={`${input} mt-2`}
              value={overs}
              onChange={(e) => {
                setOvers(Number(e.target.value));
                setOversFormat("Custom");
              }}
            />
          </div>

          <div>
            <label className={label}>Structure</label>
            <div className="space-y-2">
              {(
                [
                  ["single-round-robin", "Single Round Robin", "Each team plays every other once"],
                  ["double-round-robin", "Double Round Robin", "Home and away fixtures"],
                  ["group-knockout", "Group Stage + Knockout", "Groups, then semis and final"],
                  ["knockout", "Straight Knockout", "Direct elimination bracket"],
                ] as const
              ).map(([k, t, d]) => (
                <button
                  key={k}
                  onClick={() => setFormat(k)}
                  className={`mc-btn w-full rounded-lg border px-3 py-2 text-left ${
                    format === k
                      ? "border-emerald-500 bg-emerald-500/10"
                      : "border-slate-700 hover:bg-slate-800"
                  }`}
                >
                  <span className="block text-sm font-bold">{t}</span>
                  <span className="block text-[11px] text-slate-400">{d}</span>
                </button>
              ))}
            </div>
          </div>

          {format === "group-knockout" && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className={label}>Number of groups</label>
                <input
                  type="number"
                  min={1}
                  max={8}
                  className={input}
                  value={groupCount}
                  onChange={(e) => setGroupCount(Math.max(1, Number(e.target.value)))}
                />
              </div>
              <div>
                <label className={label}>Qualify per group</label>
                <input
                  type="number"
                  min={1}
                  max={4}
                  className={input}
                  value={qualifyPerGroup}
                  onChange={(e) => setQualifyPerGroup(Math.max(1, Number(e.target.value)))}
                />
              </div>
            </div>
          )}

          <div>
            <label className={label}>Points configuration</label>
            <div className="grid grid-cols-4 gap-2">
              {(
                [
                  ["win", "Win"],
                  ["tie", "Tie"],
                  ["noResult", "No Result"],
                  ["loss", "Loss"],
                ] as const
              ).map(([k, l]) => (
                <div key={k}>
                  <p className="mb-1 text-[10px] font-bold uppercase text-slate-500">{l}</p>
                  <input
                    type="number"
                    min={0}
                    className="w-full rounded-lg border border-slate-700 bg-slate-900/70 px-2 py-2 text-center text-sm outline-none focus:border-emerald-500"
                    value={points[k]}
                    onChange={(e) => setPoints({ ...points, [k]: Number(e.target.value) })}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setStep(1)}
              className="mc-btn h-11 rounded-xl border border-slate-700 px-4 text-sm font-bold"
            >
              Back
            </button>
            <button
              onClick={() => setStep(3)}
              className="mc-btn h-11 flex-1 rounded-xl bg-emerald-500 text-sm font-black text-slate-950"
            >
              Continue
            </button>
          </div>
        </section>
      )}

      {step === 3 && (
        <section className="mc-card mt-4 space-y-3 px-4 py-4">
          <div className="flex items-center justify-between">
            <label className={`${label} mb-0`}>Teams</label>
            <span className="text-[11px] font-bold text-slate-400">{named.length} added</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Only team names are needed now — squads and Playing XIs can be managed later, and the
            scorer picks players during the match.
          </p>

          <div className="space-y-2">
            {teamNames.map((t, i) => (
              <div key={i} className="flex items-center gap-2">
                <TeamLogo name={t || String(i + 1)} size={30} />
                <input
                  className={input}
                  value={t}
                  onChange={(e) => setTeam(i, e.target.value)}
                  placeholder={`Team ${i + 1}`}
                />
                {teamNames.length > 2 && (
                  <button
                    onClick={() => setTeamNames(teamNames.filter((_, j) => j !== i))}
                    className="mc-btn shrink-0 rounded-lg border border-slate-700 px-2.5 py-2 text-xs text-slate-400 hover:border-red-500/60 hover:text-red-400"
                  >
                    ✕
                  </button>
                )}
              </div>
            ))}
          </div>

          <button
            onClick={() => setTeamNames([...teamNames, ""])}
            className="mc-btn h-9 w-full rounded-lg border border-slate-700 text-xs font-bold text-slate-300 hover:bg-slate-800"
          >
            + Add team
          </button>

          <div className="flex gap-2 pt-1">
            <button
              onClick={() => setStep(2)}
              className="mc-btn h-11 rounded-xl border border-slate-700 px-4 text-sm font-bold"
            >
              Back
            </button>
            <button
              onClick={create}
              disabled={saving}
              className="mc-btn h-11 flex-1 rounded-xl bg-emerald-500 text-sm font-black text-slate-950 disabled:opacity-50"
            >
              {saving ? "Creating…" : "Create & Generate Fixtures"}
            </button>
          </div>
        </section>
      )}

      {error && (
        <p className="mt-4 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-300">
          {error}
        </p>
      )}
    </main>
  );
}
