"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { goTo } from "@/lib/navigate";
import { useCompetition } from "@/lib/useCompetition";
import { topPerformers, type Fixture } from "@/lib/competition";
import { deleteCompetition } from "@/lib/competition-store";
import { createMatch } from "@/lib/match-repo";
import { oversStr } from "@/lib/engine";
import { TeamLogo, TrophyIcon } from "@/components/cricket";
import {
  CompetitionLogo,
  FixtureRow,
  StandingsTable,
  StatCard,
  TableScroll,
} from "@/components/competition-ui";

const TABS = [
  "Overview",
  "Fixtures",
  "Live",
  "Points Table",
  "Teams",
  "Batting",
  "Bowling",
  "Results",
  "Settings",
] as const;
type Tab = (typeof TABS)[number];

export default function CompetitionClient({ id }: { id: string }) {
  const router = useRouter();
  const { comp, states, standings, leaderboards, loading, update } = useCompetition(id);
  const [tab, setTab] = useState<Tab>("Overview");
  const [starting, setStarting] = useState<string | null>(null);
  const [editing, setEditing] = useState<Fixture | null>(null);

  if (loading) {
    return <main className="px-4 py-20 text-center text-slate-400">Loading competition…</main>;
  }
  if (!comp) {
    return (
      <main className="mx-auto max-w-md px-4 py-16 text-center">
        <p className="text-sm font-bold text-red-400">This competition was not found.</p>
        <Link href="/leagues" className="mt-3 inline-block text-sm text-emerald-400 underline">
          Back to competitions
        </Link>
      </main>
    );
  }

  const teamName = (tid: string | null, placeholder?: string) =>
    tid ? (comp.teams.find((t) => t.id === tid)?.name ?? "TBD") : (placeholder ?? "TBD");

  const liveFixtures = comp.fixtures.filter((f) => f.status === "live");
  const completed = comp.fixtures.filter((f) => f.status === "completed");
  const perf = topPerformers(leaderboards, [...states.values()]);
  const final = comp.fixtures.find((f) => f.round === "Final");
  const champion =
    final?.status === "completed" && final.winnerTeamId
      ? comp.teams.find((t) => t.id === final.winnerTeamId)
      : null;

  /**
   * Opens a fixture in the existing scoring engine.
   *
   * A match is created through the same offline-first repository the scorer
   * uses, then linked to the fixture by id — there is no second scoring
   * engine and no duplicated match data.
   */
  async function startScoring(f: Fixture) {
    if (!comp || !f.teamAId || !f.teamBId) return;
    if (f.matchId) {
      goTo(router, `/scorer?id=${f.matchId}`);
      return;
    }
    setStarting(f.id);
    try {
      const a = comp.teams.find((t) => t.id === f.teamAId);
      const b = comp.teams.find((t) => t.id === f.teamBId);
      if (!a || !b) return;
      // Squads may be empty at this point; the scorer names players as they
      // come in, exactly as in a standalone match.
      const { id: matchId } = await createMatch({
        teamA: a.name,
        teamB: b.name,
        logoA: a.logo,
        logoB: b.logo,
        overs: f.overs,
        format: comp.oversFormat,
        venue: f.venue ?? comp.location,
        matchDate: f.date ? new Date(f.date).toISOString() : new Date().toISOString(),
        tossWinner: a.name,
        tossDecision: "bat",
        battingFirst: "A",
        playersA: a.players.length ? a.players : [{ id: "a1", name: "Batter 1", role: "Batsman" }],
        playersB: b.players.length ? b.players : [{ id: "b1", name: "Bowler 1", role: "Bowler" }],
        openingBatsman1: a.players[0]?.name ?? "Batter 1",
        openingBatsman2: a.players[1]?.name ?? "Batter 2",
        openingBowler: b.players[0]?.name ?? "Bowler 1",
        playersPerTeam: 11,
      });
      await update({
        fixtures: comp.fixtures.map((x) =>
          x.id === f.id ? { ...x, matchId, status: "live" as const } : x,
        ),
      });
      goTo(router, `/scorer?id=${matchId}`);
    } finally {
      setStarting(null);
    }
  }

  return (
    <main className="mx-auto max-w-6xl px-3 pb-10 pt-4 sm:px-4">
      {/* Header */}
      <div className="mc-card overflow-hidden">
        <div className="flex items-center gap-3 px-4 py-3">
          <CompetitionLogo name={comp.name} logo={comp.logo} size={44} />
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-lg font-black">{comp.name}</h1>
            <p className="truncate text-[11px] text-slate-400">
              {comp.type === "league" ? "League" : "Tournament"}
              {comp.season ? ` · ${comp.season}` : ""} · {comp.oversFormat} · {comp.overs} ov
              {comp.location ? ` · ${comp.location}` : ""}
            </p>
          </div>
          {champion ? (
            <span className="shrink-0 rounded bg-amber-500/15 px-2 py-1 text-[10px] font-black text-amber-300">
              🏆 {champion.name}
            </span>
          ) : liveFixtures.length > 0 ? (
            <span className="shrink-0 rounded bg-red-500/15 px-2 py-1 text-[10px] font-black text-red-400">
              LIVE
            </span>
          ) : null}
        </div>
      </div>

      {/* Tabs */}
      <div className="mc-scroll mt-3 flex gap-1 overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/50 p-1">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`mc-btn h-8 whitespace-nowrap rounded-lg px-3 text-[11px] font-black ${
              tab === t ? "bg-emerald-500 text-slate-950" : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            {t}
            {t === "Live" && liveFixtures.length > 0 && (
              <span className="ml-1 rounded bg-red-500 px-1 text-[9px] text-white">
                {liveFixtures.length}
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="mc-section mt-3 space-y-3">
        {/* ---------------- OVERVIEW ---------------- */}
        {tab === "Overview" && (
          <>
            {champion && (
              <div className="mc-card overflow-hidden">
                <div className="bg-gradient-to-r from-amber-500/20 to-transparent px-4 py-4 text-center">
                  <p className="text-[11px] font-black uppercase tracking-[0.2em] text-amber-400">
                    🏆 Champion
                  </p>
                  <div className="mt-2 flex items-center justify-center gap-2">
                    <TeamLogo name={champion.name} logo={champion.logo} size={36} />
                    <p className="text-2xl font-black">{champion.name}</p>
                  </div>
                  {final?.resultText && (
                    <p className="mt-1 text-xs text-slate-300">{final.resultText}</p>
                  )}
                </div>
                <div className="grid gap-2 border-t border-slate-800 px-4 py-3 sm:grid-cols-2">
                  <StatCard
                    label="Player of the Tournament"
                    name={comp.playerOfTournament ?? "Not selected"}
                  />
                  <StatCard
                    label="Runner-up"
                    name={
                      comp.teams.find(
                        (t) =>
                          t.id ===
                          (final?.teamAId === champion.id ? final?.teamBId : final?.teamAId),
                      )?.name
                    }
                  />
                </div>
              </div>
            )}

            <div className="grid gap-2 sm:grid-cols-4">
              <StatCard label="Teams" name={String(comp.teams.length)} />
              <StatCard label="Fixtures" name={String(comp.fixtures.length)} />
              <StatCard label="Completed" name={String(completed.length)} />
              <StatCard label="Live" name={String(liveFixtures.length)} />
            </div>

            <div className="mc-card overflow-hidden">
              <div className="border-b border-slate-800 px-4 py-2.5 text-sm font-black uppercase tracking-wider">
                Top performers
              </div>
              <div className="grid gap-2 px-3 py-3 sm:grid-cols-2 lg:grid-cols-4">
                <StatCard
                  label="Top Run Scorer"
                  name={perf.topRunScorer?.name}
                  detail={perf.topRunScorer ? `${perf.topRunScorer.runs} runs` : undefined}
                />
                <StatCard
                  label="Most Wickets"
                  name={perf.mostWickets?.name}
                  detail={perf.mostWickets ? `${perf.mostWickets.wickets} wkts` : undefined}
                />
                <StatCard
                  label="Highest Score"
                  name={perf.highestScore?.name}
                  detail={
                    perf.highestScore
                      ? `${perf.highestScore.runs} (${perf.highestScore.balls})`
                      : undefined
                  }
                />
                <StatCard
                  label="Best Bowling"
                  name={perf.bestBowling?.name}
                  detail={
                    perf.bestBowling
                      ? `${perf.bestBowling.bestWickets}/${perf.bestBowling.bestRuns}`
                      : undefined
                  }
                />
                <StatCard
                  label="Best Strike Rate"
                  name={perf.bestStrikeRate?.name}
                  detail={perf.bestStrikeRate ? perf.bestStrikeRate.strikeRate.toFixed(1) : undefined}
                />
                <StatCard
                  label="Best Economy"
                  name={perf.bestEconomy?.name}
                  detail={perf.bestEconomy ? perf.bestEconomy.economy.toFixed(2) : undefined}
                />
                <StatCard
                  label="Most Sixes"
                  name={perf.mostSixes?.name}
                  detail={perf.mostSixes ? `${perf.mostSixes.sixes} sixes` : undefined}
                />
                <StatCard
                  label="Most Fours"
                  name={perf.mostFours?.name}
                  detail={perf.mostFours ? `${perf.mostFours.fours} fours` : undefined}
                />
              </div>
            </div>
          </>
        )}

        {/* ---------------- FIXTURES ---------------- */}
        {tab === "Fixtures" && (
          <div className="mc-card overflow-hidden">
            <div className="border-b border-slate-800 px-4 py-2.5 text-sm font-black uppercase tracking-wider">
              Fixtures
            </div>
            <div className="divide-y divide-slate-800/70">
              {comp.fixtures.map((f) => (
                <FixtureRow
                  key={f.id}
                  fixture={f}
                  teamName={teamName}
                  action={
                    <div className="flex shrink-0 gap-1.5">
                      <button
                        onClick={() => setEditing(f)}
                        className="mc-btn h-8 rounded-lg border border-slate-700 px-2 text-[11px] font-bold text-slate-300 hover:bg-slate-800"
                      >
                        Edit
                      </button>
                      {f.status === "completed" && f.matchId ? (
                        <Link
                          href={`/match?id=${f.matchId}`}
                          className="mc-btn inline-flex h-8 items-center rounded-lg border border-slate-700 px-2 text-[11px] font-bold text-slate-300"
                        >
                          Scorecard
                        </Link>
                      ) : (
                        <button
                          disabled={!f.teamAId || !f.teamBId || starting === f.id}
                          onClick={() => void startScoring(f)}
                          className="mc-btn h-8 rounded-lg bg-emerald-500 px-2.5 text-[11px] font-black text-slate-950 disabled:opacity-40"
                        >
                          {starting === f.id
                            ? "…"
                            : f.matchId
                              ? "Resume"
                              : "Start Scoring"}
                        </button>
                      )}
                    </div>
                  }
                />
              ))}
            </div>
          </div>
        )}

        {/* ---------------- LIVE ---------------- */}
        {tab === "Live" && (
          <div className="space-y-2">
            {liveFixtures.length === 0 && (
              <div className="mc-card px-4 py-10 text-center text-sm text-slate-500">
                No live matches right now.
              </div>
            )}
            {liveFixtures.map((f) => {
              const st = states.get(f.id);
              const inn = st?.innings[st.currentInnings];
              return (
                <div key={f.id} className="mc-card px-4 py-3">
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 text-[10px] font-black text-red-400">
                      <span className="mc-live-dot h-1.5 w-1.5 rounded-full bg-red-500" /> LIVE
                    </span>
                    <span className="text-[11px] text-slate-500">{f.round}</span>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-black">
                        {inn?.battingTeam ?? teamName(f.teamAId)}
                      </p>
                      {inn && (
                        <p className="text-xl font-black">
                          {inn.runs}/{inn.wickets}{" "}
                          <span className="text-xs font-semibold text-slate-400">
                            ({oversStr(inn.legalBalls)} ov)
                          </span>
                        </p>
                      )}
                      <p className="truncate text-[11px] text-slate-500">
                        vs {teamName(f.teamAId) === inn?.battingTeam ? teamName(f.teamBId) : teamName(f.teamAId)}
                      </p>
                    </div>
                    <Link
                      href={`/scorer?id=${f.matchId}`}
                      className="mc-btn inline-flex h-9 shrink-0 items-center rounded-lg bg-emerald-500 px-3 text-xs font-black text-slate-950"
                    >
                      Open Scoring
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ---------------- POINTS TABLE ---------------- */}
        {tab === "Points Table" && (
          <>
            <StandingsTable rows={standings} />
            <p className="px-1 text-[11px] text-slate-500">
              Win {comp.points.win} · Tie {comp.points.tie} · No Result {comp.points.noResult} ·
              Loss {comp.points.loss}. NRR = runs scored per over − runs conceded per over (a side
              bowled out counts its full quota of overs).
            </p>
          </>
        )}

        {/* ---------------- TEAMS ---------------- */}
        {tab === "Teams" && (
          <div className="grid gap-2 sm:grid-cols-2">
            {comp.teams.map((t) => {
              const row = standings.find((s) => s.teamId === t.id);
              return (
                <div key={t.id} className="mc-card px-4 py-3">
                  <div className="flex items-center gap-2.5">
                    <TeamLogo name={t.name} logo={t.logo} size={34} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-black">{t.name}</p>
                      <p className="text-[11px] text-slate-400">
                        {t.group ? `Group ${t.group} · ` : ""}
                        {t.players.length} squad players
                      </p>
                    </div>
                  </div>
                  {row && (
                    <div className="mt-2 grid grid-cols-4 gap-1.5 text-center">
                      {[
                        ["P", row.played],
                        ["W", row.won],
                        ["L", row.lost],
                        ["Pts", row.points],
                      ].map(([l, v]) => (
                        <div key={l} className="rounded-lg bg-slate-900/60 px-2 py-1.5">
                          <p className="text-[10px] text-slate-500">{l}</p>
                          <p className="text-sm font-black">{v}</p>
                        </div>
                      ))}
                      <div className="col-span-4 rounded-lg bg-slate-900/60 px-2 py-1.5 text-left">
                        <p className="text-[10px] text-slate-500">
                          NRR {row.played ? (row.nrr >= 0 ? "+" : "") + row.nrr.toFixed(3) : "—"} ·
                          Runs {row.runsFor} for / {row.runsAgainst} against
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ---------------- BATTING ---------------- */}
        {tab === "Batting" && (
          <div className="mc-card overflow-hidden">
            <div className="border-b border-slate-800 px-4 py-2.5 text-sm font-black uppercase tracking-wider">
              Batting leaderboard
            </div>
            <TableScroll>
              <table className="w-full min-w-[620px] text-sm">
                <thead className="bg-slate-900/60 text-[11px] uppercase text-slate-400">
                  <tr>
                    <th className="px-3 py-2 text-left font-bold">Batter</th>
                    {["M", "I", "R", "B", "HS", "Avg", "SR", "4s", "6s", "50", "100"].map((h) => (
                      <th key={h} className="px-2 py-2 text-right font-bold">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {leaderboards.batting.map((b) => (
                    <tr key={b.name} className="border-t border-slate-800/70">
                      <td className="px-3 py-2">
                        <span className="font-semibold">{b.name}</span>
                        <span className="block text-[10px] text-slate-500">{b.team}</span>
                      </td>
                      <td className="px-2 py-2 text-right">{b.matches}</td>
                      <td className="px-2 py-2 text-right">{b.innings}</td>
                      <td className="px-2 py-2 text-right font-black text-emerald-400">{b.runs}</td>
                      <td className="px-2 py-2 text-right">{b.balls}</td>
                      <td className="px-2 py-2 text-right">{b.highest}</td>
                      <td className="px-2 py-2 text-right">{b.average.toFixed(1)}</td>
                      <td className="px-2 py-2 text-right">{b.strikeRate.toFixed(1)}</td>
                      <td className="px-2 py-2 text-right">{b.fours}</td>
                      <td className="px-2 py-2 text-right">{b.sixes}</td>
                      <td className="px-2 py-2 text-right">{b.fifties}</td>
                      <td className="px-2 py-2 text-right">{b.hundreds}</td>
                    </tr>
                  ))}
                  {leaderboards.batting.length === 0 && (
                    <tr>
                      <td colSpan={12} className="px-4 py-6 text-center text-slate-500">
                        No completed matches yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </TableScroll>
          </div>
        )}

        {/* ---------------- BOWLING ---------------- */}
        {tab === "Bowling" && (
          <div className="mc-card overflow-hidden">
            <div className="border-b border-slate-800 px-4 py-2.5 text-sm font-black uppercase tracking-wider">
              Bowling leaderboard
            </div>
            <TableScroll>
              <table className="w-full min-w-[560px] text-sm">
                <thead className="bg-slate-900/60 text-[11px] uppercase text-slate-400">
                  <tr>
                    <th className="px-3 py-2 text-left font-bold">Bowler</th>
                    {["M", "O", "R", "W", "Econ", "Best", "Md", "Dots"].map((h) => (
                      <th key={h} className="px-2 py-2 text-right font-bold">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {leaderboards.bowling.map((b) => (
                    <tr key={b.name} className="border-t border-slate-800/70">
                      <td className="px-3 py-2">
                        <span className="font-semibold">{b.name}</span>
                        <span className="block text-[10px] text-slate-500">{b.team}</span>
                      </td>
                      <td className="px-2 py-2 text-right">{b.matches}</td>
                      <td className="px-2 py-2 text-right">{oversStr(b.balls)}</td>
                      <td className="px-2 py-2 text-right">{b.runs}</td>
                      <td className="px-2 py-2 text-right font-black text-emerald-400">
                        {b.wickets}
                      </td>
                      <td className="px-2 py-2 text-right">{b.economy.toFixed(2)}</td>
                      <td className="px-2 py-2 text-right">
                        {b.bestWickets}/{b.bestRuns}
                      </td>
                      <td className="px-2 py-2 text-right">{b.maidens}</td>
                      <td className="px-2 py-2 text-right">{b.dots}</td>
                    </tr>
                  ))}
                  {leaderboards.bowling.length === 0 && (
                    <tr>
                      <td colSpan={9} className="px-4 py-6 text-center text-slate-500">
                        No completed matches yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </TableScroll>
          </div>
        )}

        {/* ---------------- RESULTS ---------------- */}
        {tab === "Results" && (
          <div className="space-y-2">
            {completed.length === 0 && (
              <div className="mc-card px-4 py-10 text-center text-sm text-slate-500">
                No completed matches yet.
              </div>
            )}
            {completed.map((f) => {
              const st = states.get(f.id);
              return (
                <Link
                  key={f.id}
                  href={f.matchId ? `/match?id=${f.matchId}` : "#"}
                  className="mc-card mc-btn block px-4 py-3 hover:border-emerald-500/40"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-bold text-slate-500">
                      #{f.number} · {f.round}
                    </span>
                    <span className="text-[11px] text-slate-500">{f.date}</span>
                  </div>
                  {st && (
                    <div className="mt-1.5 space-y-0.5">
                      {st.innings
                        .filter((i) => i.started)
                        .map((i, idx) => (
                          <p key={idx} className="text-sm">
                            <span className="font-bold">{i.battingTeam}</span>{" "}
                            <span className="font-black text-emerald-400">
                              {i.runs}/{i.wickets}
                            </span>{" "}
                            <span className="text-[11px] text-slate-400">
                              ({oversStr(i.legalBalls)} ov)
                            </span>
                          </p>
                        ))}
                    </div>
                  )}
                  <p className="mt-1 text-xs font-black text-emerald-300">{f.resultText}</p>
                  {st?.awards.playerOfMatch && (
                    <p className="text-[11px] text-amber-300">
                      🏆 Player of the Match: {st.awards.playerOfMatch}
                    </p>
                  )}
                  {f.venue && <p className="text-[11px] text-slate-500">{f.venue}</p>}
                </Link>
              );
            })}
          </div>
        )}

        {/* ---------------- SETTINGS ---------------- */}
        {tab === "Settings" && (
          <div className="space-y-3">
            <div className="mc-card px-4 py-4">
              <p className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">
                Player of the Tournament
              </p>
              <p className="mb-2 text-[11px] text-slate-500">
                Statistical awards are calculated automatically; this one is the organizer&apos;s
                choice.
              </p>
              <select
                value={comp.playerOfTournament ?? ""}
                onChange={(e) => void update({ playerOfTournament: e.target.value || null })}
                className="w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm outline-none focus:border-emerald-500"
              >
                <option value="">Not selected</option>
                {leaderboards.batting.map((b) => (
                  <option key={b.name} value={b.name}>
                    {b.name} ({b.team})
                  </option>
                ))}
              </select>
            </div>

            <div className="mc-card px-4 py-4">
              <p className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">
                Points configuration
              </p>
              <div className="grid grid-cols-4 gap-2">
                {(
                  [
                    ["win", "Win"],
                    ["tie", "Tie"],
                    ["noResult", "No Result"],
                    ["loss", "Loss"],
                  ] as const
                ).map(([k, l]) => (
                  <div key={k}>
                    <p className="mb-1 text-[10px] font-bold uppercase text-slate-500">{l}</p>
                    <input
                      type="number"
                      min={0}
                      value={comp.points[k]}
                      onChange={(e) =>
                        void update({ points: { ...comp.points, [k]: Number(e.target.value) } })
                      }
                      className="w-full rounded-lg border border-slate-700 bg-slate-900/70 px-2 py-2 text-center text-sm outline-none focus:border-emerald-500"
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="mc-card px-4 py-4">
              <p className="mb-2 text-xs font-bold uppercase tracking-wider text-red-400">
                Danger zone
              </p>
              <button
                onClick={async () => {
                  await deleteCompetition(comp.id);
                  goTo(router, "/leagues");
                }}
                className="mc-btn h-9 rounded-lg border border-red-500/50 bg-red-500/10 px-3 text-xs font-black text-red-300 hover:bg-red-500/20"
              >
                Delete competition
              </button>
              <p className="mt-1.5 text-[11px] text-slate-500">
                Scored matches remain in Match History.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Fixture editor */}
      {editing && (
        <div
          className="fixed inset-0 z-[90] flex items-end justify-center bg-black/75 p-3 sm:items-center"
          onClick={() => setEditing(null)}
        >
          <div
            className="mc-pop mc-card w-full max-w-sm px-4 py-4"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="mb-3 text-sm font-black uppercase">Edit fixture #{editing.number}</h3>
            {(
              [
                ["date", "Date", "date"],
                ["time", "Time", "time"],
                ["venue", "Venue", "text"],
              ] as const
            ).map(([k, l, t]) => (
              <div key={k} className="mb-2">
                <p className="mb-1 text-[10px] font-bold uppercase text-slate-500">{l}</p>
                <input
                  type={t}
                  value={(editing[k] as string) ?? ""}
                  onChange={(e) => setEditing({ ...editing, [k]: e.target.value })}
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm outline-none focus:border-emerald-500"
                />
              </div>
            ))}
            <div className="mb-3">
              <p className="mb-1 text-[10px] font-bold uppercase text-slate-500">Status</p>
              <select
                value={editing.status}
                onChange={(e) =>
                  setEditing({ ...editing, status: e.target.value as Fixture["status"] })
                }
                className="w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm outline-none focus:border-emerald-500"
              >
                {["scheduled", "live", "completed", "abandoned", "postponed"].map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
            <button
              onClick={async () => {
                await update({
                  fixtures: comp.fixtures.map((x) => (x.id === editing.id ? editing : x)),
                });
                setEditing(null);
              }}
              className="mc-btn h-10 w-full rounded-lg bg-emerald-500 text-sm font-black text-slate-950"
            >
              Save fixture
            </button>
          </div>
        </div>
      )}
    </main>
  );
}
