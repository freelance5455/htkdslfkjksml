"use client";

import { QueryIdRoute } from "@/components/query-route";
import CompetitionClient from "./competition-client";

/** Competition dashboard, addressed by `?id=…` for the static export. */
export default function LeaguePage() {
  return (
    <QueryIdRoute
      emptyTitle="No competition selected."
      backHref="/leagues"
      backLabel="Back to competitions"
    >
      {(id) => <CompetitionClient id={id} />}
    </QueryIdRoute>
  );
}
