import { useEffect, useState } from "react";
import { useRef } from "react";
import {
  BadgeCheck, Bell, Contrast, Crown, Cpu, Gauge, Globe, Info, Maximize2, MoonStar, MonitorPlay,
  ShieldCheck, Trash2, UserRound, Video, Volume2, Wifi, HardDrive, BellRing, Languages, Sparkles, ChevronRight,
  Wrench, Download, Upload, Smartphone, RotateCcw, CheckCircle2, Image as ImageIcon, Timer, MoonStar as MoonIcon, Check,
  Hourglass, CloudRain, Flame as FlameIcon, Wind, Keyboard,
} from "lucide-react";
import { useLocalStorage } from "./useLocalStorage";
import { InstallCard } from "./InstallApp";

function Toggle({ on, onToggle, label, hint }: { on: boolean; onToggle: () => void; label: string; hint: string }) {
  return (
    <button role="switch" aria-checked={on} onClick={onToggle} className="flex w-full items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/[0.03] p-3 text-left transition-colors hover:border-white/15">
      <span>
        <span className="block text-xs font-bold text-slate-100">{label}</span>
        <span className="mt-0.5 block text-[10px] leading-snug text-slate-500">{hint}</span>
      </span>
      <span className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${on ? "bg-electric" : "bg-slate-700"}`}>
        <span className={`absolute top-1 h-4 w-4 rounded-full bg-white shadow transition-all ${on ? "left-6" : "left-1"}`} />
      </span>
    </button>
  );
}

function SectionTitle({ icon: Icon, children, tint = "text-cyanx" }: { icon: typeof Video; children: React.ReactNode; tint?: string }) {
  return <h2 className={`flex items-center gap-2 font-display text-sm font-bold text-white`}><Icon size={15} className={tint} /> {children}</h2>;
}

function browserName(): string {
  const ua = navigator.userAgent;
  if (/Edg\//.test(ua)) return "Microsoft Edge";
  if (/Chrome\//.test(ua) && !/Chromium/.test(ua)) return "Google Chrome";
  if (/Firefox\//.test(ua)) return "Mozilla Firefox";
  if (/Safari\//.test(ua)) return "Safari";
  return "Navegador desconocido";
}
function osName(): string {
  const ua = navigator.userAgent;
  if (/Android/.test(ua)) return "Android";
  if (/iPhone|iPad/.test(ua)) return "iOS";
  if (/Windows/.test(ua)) return "Windows";
  if (/Mac OS/.test(ua)) return "macOS";
  if (/Linux/.test(ua)) return "Linux";
  return "Sistema desconocido";
}

export default function SettingsView({ onOpenInfo, onChangeProfile }: { onOpenInfo: () => void; onChangeProfile: () => void }) {
  const [hc, setHc] = useLocalStorage("lo3-hc", false);
  const [rm, setRm] = useLocalStorage("lo3-rm", false);
  const [mutedDefault, setMutedDefault] = useLocalStorage("lo3-muted-default", false);
  const [autoplay, setAutoplay] = useLocalStorage("lo3-autoplay", true);
  const [quality, setQuality] = useLocalStorage("lo3-quality", "auto");
  const [defaultVolume, setDefaultVolume] = useLocalStorage("lo3-default-volume", 80);
  const [textSize, setTextSize] = useLocalStorage<"normal" | "lg" | "xl">("lo3-text-size", "normal");
  const [notifNews, setNotifNews] = useLocalStorage("lo3-notif-news", true);
  const [notifScores, setNotifScores] = useLocalStorage("lo3-notif-scores", true);
  const [notifUpdates, setNotifUpdates] = useLocalStorage("lo3-notif-updates", false);
  const [storage, setStorage] = useState<{ used: number; quota: number } | null>(null);
  const [battery, setBattery] = useState<string>("…");
  const [localBytes, setLocalBytes] = useState(0);
  const [noRotate, setNoRotate] = useLocalStorage("lo3-no-rotate", false);
  const [nightMode, setNightMode] = useLocalStorage("lo3-night-mode", false);
  const [clockStyle, setClockStyle] = useLocalStorage("lo3-clock-style", "digital");
  const [notifTest, setNotifTest] = useState<string>("sin probar");
  const [vibTest, setVibTest] = useState<string>("sin probar");
  const backupInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const ambientSrcRef = useRef<AudioBufferSourceNode | null>(null);
  const timerEndRef = useRef(0);
  const [timerLeft, setTimerLeft] = useState<number | null>(null);
  const [timerTotal, setTimerTotal] = useState(0);
  const [ambient, setAmbient] = useState<"off" | "rain" | "fire" | "wind">("off");
  const [wallpaper, setWallpaper] = useLocalStorage("lo3-wallpaper", "desert");
  const [screensaverOn, setScreensaverOn] = useLocalStorage("lo3-screensaver", true);
  const [ssDelay, setSsDelay] = useLocalStorage("lo3-screensaver-delay", 30);
  const WALLS: { id: string; label: string; img: string }[] = [
    { id: "desert", label: "Desierto", img: "/img/art-desert.jpg" },
    { id: "earth", label: "Tierra desde el espacio", img: "/img/hero-art.jpg" },
    { id: "space", label: "Órbita", img: "/img/art-space.jpg" },
    { id: "stadium", label: "Estadio", img: "/img/art-stadium.jpg" },
    { id: "neon", label: "Neon Game", img: "/img/art-controller.jpg" },
    { id: "sound", label: "Ecualizador", img: "/img/art-headphones.jpg" },
  ];
  const pickAvatar = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) { window.alert("Solo imágenes (JPG, PNG, WebP…)."); return; }
    if (file.size > 3 * 1024 * 1024) { window.alert("Máximo 3 MB."); return; }
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const c = document.createElement("canvas");
      c.width = 128; c.height = 128;
      const ctx = c.getContext("2d");
      if (ctx) {
        const side = Math.min(img.width, img.height);
        ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, 128, 128);
        try { window.localStorage.setItem("lo3-avatar", c.toDataURL("image/jpeg", 0.85)); window.location.reload(); } catch { window.alert("No se pudo guardar (almacenamiento lleno)."); }
      }
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };
  const removeAvatar = () => { try { window.localStorage.removeItem("lo3-avatar"); } catch { /* noop */ } window.location.reload(); };

  useEffect(() => {
    let bytes = 0;
    try { for (let i = 0; i < window.localStorage.length; i++) { const k = window.localStorage.key(i); if (k) bytes += k.length + (window.localStorage.getItem(k)?.length ?? 0); } } catch { /* noop */ }
    setLocalBytes(bytes * 2);
    navigator.storage?.estimate?.().then((e) => setStorage({ used: e?.usage ?? 0, quota: e?.quota ?? 0 })).catch(() => setStorage(null));
    const nav = navigator as Navigator & { getBattery?: () => Promise<{ level: number; charging: boolean }>; connection?: { effectiveType?: string; downlink?: number } };
    nav.getBattery?.().then((b) => setBattery(`${Math.round(b.level * 100)}% ${b.charging ? "· cargando" : "· en batería"}`)).catch(() => setBattery("no disponible"));
  }, []);

  const applyHc = (v: boolean) => { setHc(v); document.documentElement.classList.toggle("hc", v); };
  const applyRm = (v: boolean) => { setRm(v); document.documentElement.classList.toggle("rm", v); };
  const applyTextSize = (size: "normal" | "lg" | "xl") => {
    setTextSize(size);
    document.documentElement.classList.remove("txt-lg", "txt-xl");
    if (size !== "normal") document.documentElement.classList.add(size === "lg" ? "txt-lg" : "txt-xl");
  };

  const applyNoRotate = (v: boolean) => { setNoRotate(v); document.documentElement.classList.toggle("no-rotate", v); };
  const applyNightMode = (v: boolean) => { setNightMode(v); document.documentElement.classList.toggle("night-mode", v); };
  const testVibration = () => {
    if (typeof navigator.vibrate === "function") { navigator.vibrate([120, 60, 120]); setVibTest("vibrando…"); window.setTimeout(() => setVibTest("soportada ✓"), 600); }
    else setVibTest("no soportada en este navegador");
  };
  const testNotification = async () => {
    if (!("Notification" in window)) { setNotifTest("no soportada"); return; }
    try {
      const perm = Notification.permission === "default" ? await Notification.requestPermission() : Notification.permission;
      if (perm === "granted") { new Notification("TV LO3 Secure", { body: "Las notificaciones funcionan en tu TV LO3. Así te avisaremos de resultados." }); setNotifTest("enviada ✓"); }
      else setNotifTest(perm === "denied" ? "bloqueadas por el navegador" : "sin permiso");
    } catch { setNotifTest("error"); }
  };
  const exportBackup = () => {
    const data: Record<string, string> = {};
    for (let i = 0; i < window.localStorage.length; i++) { const k = window.localStorage.key(i); if (k && k.startsWith("lo3")) data[k] = window.localStorage.getItem(k) ?? ""; }
    const blob = new Blob([JSON.stringify({ app: "TV LO3", version: "3.2.1", exportedAt: new Date().toISOString(), data }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `tvlo3-backup-${new Date().toISOString().slice(0, 10)}.json`; a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
  };
  const importBackup = async (file: File | undefined) => {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      const entries = parsed?.data && typeof parsed.data === "object" ? Object.entries(parsed.data as Record<string, string>) : [];
      const valid = entries.filter(([k, v]) => k.startsWith("lo3") && typeof v === "string");
      if (valid.length === 0) throw new Error("copia inválida");
      for (const [k, v] of valid) window.localStorage.setItem(k, v);
      window.alert(`Copia restaurada (${valid.length} ajustes). TV LO3 se reiniciará.`);
      window.location.reload();
    } catch {
      window.alert("Ese archivo no es una copia de seguridad válida de TV LO3.");
    }
  };
  const restartApp = () => { try { sessionStorage.removeItem("lo3-booted"); } catch { /* noop */ } window.location.reload(); };

  const chime = () => {
    try {
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = audioCtxRef.current ?? new Ctx();
      audioCtxRef.current = ctx;
      void ctx.resume();
      [0, 0.4, 0.8].forEach((t) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = "sine";
        o.frequency.value = 880;
        o.connect(g); g.connect(ctx.destination);
        g.gain.setValueAtTime(0.0001, ctx.currentTime + t);
        g.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime + t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + t + 0.32);
        o.start(ctx.currentTime + t);
        o.stop(ctx.currentTime + t + 0.35);
      });
    } catch { /* audio no disponible */ }
  };
  const startTimer = (mins: number) => {
    timerEndRef.current = Date.now() + mins * 60000;
    setTimerTotal(mins * 60);
    setTimerLeft(mins * 60);
  };
  const stopTimer = () => setTimerLeft(null);
  useEffect(() => {
    if (timerLeft === null) return;
    const id = window.setInterval(() => {
      const left = Math.max(0, Math.round((timerEndRef.current - Date.now()) / 1000));
      setTimerLeft(left);
      if (left === 0) { window.clearInterval(id); chime(); setTimerLeft(null); }
    }, 250);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timerLeft !== null]);

  const buildNoise = (kind: "rain" | "fire" | "wind") => {
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = audioCtxRef.current ?? new Ctx();
    audioCtxRef.current = ctx;
    const len = 4 * ctx.sampleRate;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const ch = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      if (kind === "rain") ch[i] = white * (0.75 + 0.25 * Math.sin(i / 80));
      else if (kind === "fire") { last = (last + 0.025 * white) / 1.025; ch[i] = last * 3.2 + (Math.random() > 0.995 ? (Math.random() * 2 - 1) * 0.85 : 0); }
      else { last = (last + 0.03 * white) / 1.03; ch[i] = last * 2.4; }
    }
    return { ctx, buf };
  };
  const stopAmbient = () => { try { ambientSrcRef.current?.stop(); } catch { /* ya paró */ } ambientSrcRef.current = null; setAmbient("off"); };
  const startAmbient = (kind: "rain" | "fire" | "wind") => {
    if (ambient === kind) { stopAmbient(); return; }
    stopAmbient();
    try {
      const { ctx, buf } = buildNoise(kind);
      void ctx.resume();
      const src = ctx.createBufferSource();
      src.buffer = buf;
      src.loop = true;
      const filter = ctx.createBiquadFilter();
      filter.type = kind === "rain" ? "highpass" : kind === "wind" ? "lowpass" : "bandpass";
      filter.frequency.value = kind === "rain" ? 500 : kind === "wind" ? 300 : 650;
      filter.Q.value = kind === "fire" ? 0.7 : 1;
      const gain = ctx.createGain();
      gain.gain.value = 0.14;
      src.connect(filter); filter.connect(gain); gain.connect(ctx.destination);
      src.start();
      ambientSrcRef.current = src;
      setAmbient(kind);
    } catch { /* audio no disponible */ }
  };
  useEffect(() => () => { try { ambientSrcRef.current?.stop(); } catch { /* noop */ } }, []);

  const wipeAppData = () => {
    if (!window.confirm("¿Borrar favoritos, historial, perfiles y bóveda local? TV LO3 volverá al estado de fábrica en este navegador.")) return;
    Object.keys(window.localStorage).filter((k) => k.startsWith("lo3")).forEach((k) => window.localStorage.removeItem(k));
    indexedDB.deleteDatabase("lo3-cloud");
    window.location.reload();
  };

  const fullscreen = () => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen().catch(() => {});
  };

  const connection = (navigator as Navigator & { connection?: { effectiveType?: string; downlink?: number } }).connection;
  const usedKb = (localBytes / 1024).toFixed(1);
  const storageUsedMb = storage ? (storage.used / 1024 / 1024).toFixed(1) : "…";
  const storageQuotaGb = storage && storage.quota > 0 ? (storage.quota / 1024 / 1024 / 1024).toFixed(1) : null;

  return (
    <div className="flex h-full flex-col gap-3 overflow-y-auto p-3 thin-scroll sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-black text-white">Ajustes</h1>
          <p className="text-[10px] uppercase tracking-wider text-slate-500">Todo se aplica al instante y se guarda en este dispositivo</p>
        </div>
        <button onClick={onOpenInfo} className="ghost-btn flex h-10 items-center gap-2 rounded-xl px-4 text-[11px] font-bold text-white"><Crown size={13} className="text-gold" /> FREE activo · Ver PREMIUM <ChevronRight size={13} /></button>
      </div>

      <div className="grid gap-3 pb-2 lg:grid-cols-2">
        {/* ───── VÍDEO ───── */}
        <section className="tile rounded-2xl p-4">
          <SectionTitle icon={Video}>Vídeo y reproducción</SectionTitle>
          <div className="mt-2 space-y-2">
            <Toggle on={autoplay} onToggle={() => setAutoplay(!autoplay)} label="Autoplay de emisiones" hint="El stream arranca solo al sintonizar un canal" />
            <Toggle on={mutedDefault} onToggle={() => setMutedDefault(!mutedDefault)} label="Silenciar canales por defecto" hint="Los streams arrancan sin sonido — ideal de noche" />
            <div className="rounded-xl border border-white/8 bg-white/[0.03] p-3">
              <p className="text-xs font-bold text-slate-100">Calidad preferida</p>
              <p className="mt-0.5 text-[10px] text-slate-500">Se recordará para cuando llegue la selección de bitrate (v4.0)</p>
              <div className="mt-2 flex gap-1.5" role="group" aria-label="Calidad de vídeo">
                {[["auto", "Auto"], ["hd", "HD siempre"], ["saver", "Ahorro de datos"]].map(([v, l]) => (
                  <button key={v} onClick={() => setQuality(v)} aria-pressed={quality === v} className={`h-9 flex-1 rounded-lg text-[10px] font-bold transition-colors ${quality === v ? "bg-electric text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}>{l}</button>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ───── SONIDO ───── */}
        <section className="tile rounded-2xl p-4">
          <SectionTitle icon={Volume2} tint="text-lilac">Sonido</SectionTitle>
          <div className="mt-2 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold text-slate-100">Volumen por defecto</p>
              <span className="font-display text-sm font-black tabular-nums text-cyanx">{defaultVolume}%</span>
            </div>
            <p className="mt-0.5 text-[10px] text-slate-500">Se aplica a Radio y previews de Music (Deezer)</p>
            <div className="mt-2 flex items-center gap-2">
              <Volume2 size={13} className="text-slate-500" aria-hidden="true" />
              <label htmlFor="default-volume" className="sr-only">Volumen por defecto</label>
              <input id="default-volume" type="range" min={0} max={100} value={defaultVolume} onChange={(e) => setDefaultVolume(Number(e.target.value))} className="h-1.5 flex-1 cursor-pointer accent-cyan-400" />
            </div>
          </div>
          <div className="mt-2 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <p className="text-xs font-bold text-slate-100">Salida de audio</p>
            <p className="mt-0.5 text-[10px] text-slate-500">{typeof AudioContext !== "undefined" ? "Web Audio API disponible · dual-mono, control de ganancia y ecualizador de 10 bandas dentro de la app" : "Audio estándar del navegador"}</p>
          </div>
        </section>

        {/* ───── ACCESIBILIDAD ───── */}
        <section className="tile rounded-2xl p-4">
          <SectionTitle icon={Contrast} tint="text-amber-300">Accesibilidad</SectionTitle>
          <div className="mt-2 space-y-2">
            <Toggle on={hc} onToggle={() => applyHc(!hc)} label="Alto contraste" hint="Negro puro, bordes cian y texto reforzado — modo salón" />
            <Toggle on={rm} onToggle={() => applyRm(!rm)} label="Reducir animaciones" hint="Sin pulsos ni transiciones — para fotosensibilidad" />
            <div className="rounded-xl border border-white/8 bg-white/[0.03] p-3">
              <p className="text-xs font-bold text-slate-100">Tamaño de texto</p>
              <div className="mt-2 flex gap-1.5" role="group" aria-label="Tamaño de texto">
                {([["normal", "Normal"], ["lg", "Grande"], ["xl", "Muy grande"]] as const).map(([v, l]) => (
                  <button key={v} onClick={() => applyTextSize(v)} aria-pressed={textSize === v} className={`h-9 flex-1 rounded-lg text-[10px] font-bold transition-colors ${textSize === v ? "bg-electric text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}>{l}</button>
                ))}
              </div>
            </div>
            <Toggle on={nightMode} onToggle={() => applyNightMode(!nightMode)} label="Modo nocturno cálido" hint="Cálido y tenue: menos azul y brillo para ver de noche" />
            <button onClick={fullscreen} className="flex w-full items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/[0.03] p-3 text-left transition-colors hover:border-white/15">
              <span><span className="block text-xs font-bold text-slate-100">Pantalla completa</span><span className="mt-0.5 block text-[10px] text-slate-500">Modo cine real con Fullscreen API · Esc para salir</span></span>
              <Maximize2 size={18} className="shrink-0 text-slate-400" />
            </button>
          </div>
        </section>

        {/* ───── NOTIFICACIONES ───── */}
        <section className="tile rounded-2xl p-4">
          <SectionTitle icon={Bell} tint="text-rose-300">Notificaciones en este dispositivo</SectionTitle>
          <div className="mt-2 space-y-2">
            <Toggle on={notifScores} onToggle={() => setNotifScores(!notifScores)} label="Resultados de tus seguidos" hint="Avisos cuando marcan LaLiga, NBA, NFL y tus ligas ★" />
            <Toggle on={notifNews} onToggle={() => setNotifNews(!notifNews)} label="Titulares al abrir la app" hint="Un resumen de 3 titulares ESPN y Hacker News" />
            <Toggle on={notifUpdates} onToggle={() => setNotifUpdates(!notifUpdates)} label="Actualizaciones de TV LO3" hint="Novedades de versión y parcheos de seguridad" />
            <p className="flex items-start gap-1.5 px-1 text-[9px] leading-snug text-slate-600"><BellRing size={10} className="mt-0.5 shrink-0" /> Push real con la versión instalada en Android; en el navegador se muestran al abrir y dentro de la app.</p>
          </div>
        </section>

        {/* ───── DIAGNÓSTICO DEL DISPOSITIVO (real) ───── */}
        <section className="tile rounded-2xl p-4">
          <SectionTitle icon={Cpu} tint="text-emerald-300">Diagnóstico del dispositivo</SectionTitle>
          <ul className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1.5 text-[10px] text-slate-400">
            <li className="flex justify-between gap-2 border-b border-white/5 pb-1"><span>Navegador</span><span className="font-semibold text-slate-200">{browserName()}</span></li>
            <li className="flex justify-between gap-2 border-b border-white/5 pb-1"><span>Sistema</span><span className="font-semibold text-slate-200">{osName()}</span></li>
            <li className="flex justify-between gap-2 border-b border-white/5 pb-1"><span>Pantalla</span><span className="font-semibold tabular-nums text-slate-200">{window.screen.width}×{window.screen.height}</span></li>
            <li className="flex justify-between gap-2 border-b border-white/5 pb-1"><span>Idioma</span><span className="font-semibold text-slate-200">{navigator.language}</span></li>
            <li className="flex justify-between gap-2 border-b border-white/5 pb-1"><span>Núcleos CPU</span><span className="font-semibold tabular-nums text-slate-200">{navigator.hardwareConcurrency ?? "—"}</span></li>
            <li className="flex justify-between gap-2 border-b border-white/5 pb-1"><span>Memoria RAM</span><span className="font-semibold tabular-nums text-slate-200">{(navigator as Navigator & { deviceMemory?: number }).deviceMemory ? `~${(navigator as Navigator & { deviceMemory?: number }).deviceMemory} GB` : "—"}</span></li>
            <li className="flex justify-between gap-2 border-b border-white/5 pb-1"><span>Red</span><span className="font-semibold text-slate-200">{connection?.effectiveType ? `${connection.effectiveType.toUpperCase()}${connection.downlink ? ` · ${connection.downlink} Mb/s` : ""}` : "desconocida"}</span></li>
            <li className="flex justify-between gap-2 border-b border-white/5 pb-1"><span>Batería</span><span className="font-semibold text-slate-200">{battery}</span></li>
          </ul>
        </section>

        {/* ───── ALMACENAMIENTO ───── */}
        <section className="tile rounded-2xl p-4">
          <SectionTitle icon={HardDrive} tint="text-sky-300">Almacenamiento</SectionTitle>
          <div className="mt-2 grid grid-cols-2 gap-2 text-[10px]">
            <div className="rounded-xl border border-white/8 bg-white/[0.03] p-2.5"><p className="font-display text-lg font-black text-white">{usedKb} KB</p><p className="text-[9px] uppercase tracking-wider text-slate-500">Ajustes y datos (localStorage)</p></div>
            <div className="rounded-xl border border-white/8 bg-white/[0.03] p-2.5"><p className="font-display text-lg font-black text-white">{storageUsedMb} MB{storageQuotaGb ? ` / ${storageQuotaGb} GB` : ""}</p><p className="text-[9px] uppercase tracking-wider text-slate-500">Cuota del navegador (IndexedDB)</p></div>
          </div>
          <div className="mt-2 space-y-2">
            <button onClick={() => { Object.keys(window.localStorage).filter((k) => k.startsWith("lo3") && k !== "lo3-profile").forEach((k) => window.localStorage.removeItem(k)); window.alert("Favoritos, historial y ajustes borrados. Se conserva tu perfil."); }} className="flex w-full items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/[0.03] p-3 text-left transition-colors hover:border-white/15">
              <span><span className="block text-xs font-bold text-slate-100">Borrar historial y favoritos</span><span className="mt-0.5 block text-[10px] text-slate-500">Conserva tu perfil y el PIN parental</span></span>
              <Trash2 size={17} className="shrink-0 text-slate-400" />
            </button>
            <button onClick={wipeAppData} className="flex w-full items-center justify-between gap-3 rounded-xl border border-rose-500/30 bg-rose-500/8 p-3 text-left transition-colors hover:border-rose-500/50">
              <span><span className="block text-xs font-bold text-rose-200">Restablecer TV LO3 de fábrica</span><span className="mt-0.5 block text-[10px] text-rose-200/60">Borra TODO: perfiles, bóveda local, PIN, historial</span></span>
              <Trash2 size={17} className="shrink-0 text-rose-300" />
            </button>
          </div>
        </section>

        {/* ───── PERFIL Y KIDS ───── */}
        <section className="tile rounded-2xl p-4">
          <SectionTitle icon={UserRound} tint="text-violetx">Perfil e infancia</SectionTitle>
          <div className="mt-2 space-y-2">
            <button onClick={onChangeProfile} className="flex w-full items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/[0.03] p-3 text-left transition-colors hover:border-white/15">
              <span><span className="block text-xs font-bold text-slate-100">Cambiar de perfil</span><span className="mt-0.5 block text-[10px] text-slate-500">Selector de perfiles TV LO3 (Kids aplica filtros)</span></span>
              <span className="chip">Perfil</span>
            </button>
            <button onClick={() => { window.localStorage.removeItem("lo3-kids-pin"); window.alert("PIN de Kids restablecido. La próxima visita te pedirá crearlo de nuevo."); }} className="flex w-full items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/[0.03] p-3 text-left transition-colors hover:border-white/15">
              <span><span className="block text-xs font-bold text-slate-100">Restablecer PIN de Kids</span><span className="mt-0.5 block text-[10px] text-slate-500">Elimina el PIN parental guardado en este dispositivo</span></span>
              <ShieldCheck size={18} className="shrink-0 text-emerald-400" />
            </button>
          </div>
        </section>

        {/* ───── IDIOMA ───── */}
        <section className="tile rounded-2xl p-4">
          <SectionTitle icon={Languages} tint="text-gold">Idioma y región</SectionTitle>
          <div className="mt-2 space-y-2">
            <div className="flex w-full items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/[0.03] p-3">
              <span><span className="block text-xs font-bold text-slate-100">Idioma de la interfaz</span><span className="mt-0.5 block text-[10px] text-slate-500">Español — único idioma disponible por ahora</span></span>
              <span className="chip">ES</span>
            </div>
            <div className="flex w-full items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/[0.03] p-3">
              <span><span className="block text-xs font-bold text-slate-100">Región detectada</span><span className="mt-0.5 block text-[10px] text-slate-500">Según tu navegador ({navigator.language})</span></span>
              <span className="chip">{navigator.language?.split("-")[1] ?? "ES"}</span>
            </div>
            <p className="flex items-center gap-1.5 px-1 text-[9px] text-slate-600"><Globe size={10} /> World TV ya funciona con 25+ mercados (ES, MX, US, AR…) desde la sección World TV → Idiomas.</p>
          </div>
        </section>

        {/* ───── PLAN ───── */}
        <section className="rounded-2xl border border-gold/30 bg-gradient-to-br from-gold/12 to-amber-600/5 p-4">
          <SectionTitle icon={Crown} tint="text-gold">Tu plan</SectionTitle>
          <p className="mt-2 font-display text-2xl font-black text-white">TV LO3 <span className="text-gold">FREE</span></p>
          <p className="mt-1 text-[11px] leading-snug text-amber-100/70">Canales públicos, catálogo, radio y 1 perfil — gratis para siempre. PREMIUM añade 4K HDR, EPG completo, offline y TV LO3 AI sin límites.</p>
          <button onClick={onOpenInfo} className="grad-btn mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl text-xs font-black text-white"><Sparkles size={15} /> Probar PREMIUM 7 días gratis <ChevronRight size={13} /></button>
        </section>

        {/* ───── RED Y FUENTES ───── */}
        <section className="tile rounded-2xl p-4">
          <SectionTitle icon={Wifi} tint="text-emerald-300">Red y fuentes en vivo</SectionTitle>
          <ul className="mt-2 space-y-1.5 text-[10px] text-slate-400">
            {[
              ["Marcadores", "site.api.espn.com · ESPN Public"],
              ["Clasificaciones", "ESPN Standings API"],
              ["Noticias", "ESPN (LaLiga) · Hacker News"],
              ["Canales", "iptv-org · streams públicos + GitLab"],
              ["Películas / Series", "Wikidata · TVMaze · Commons"],
              ["Música", "Deezer · previews de 30 s"],
              ["Radio", "Radio Browser · emisoras verificadas"],
            ].map(([k, v]) => <li key={k} className="flex items-baseline justify-between gap-3 border-b border-white/5 pb-1.5"><span className="font-bold text-slate-300">{k}</span><span className="text-right font-mono text-[9px] text-slate-500">{v}</span></li>)}
          </ul>
          <p className="mt-2 flex items-center gap-1.5 px-1 text-[9px] text-slate-600"><MoonStar size={10} /> Sin conexión solo funcionan tus archivos locales y la bóveda Cloud.</p>
        </section>

        {/* ───── ACERCA DE ───── */}
        <section className="tile rounded-2xl p-4">
          <SectionTitle icon={Info} tint="text-slate-300">Acerca de TV LO3</SectionTitle>
          <ul className="mt-2 space-y-1.5 text-[10px] text-slate-400">
            {[
              ["Versión", "TV LO3 Ultimate Edition v3.2.1 (build 2026.11)"],
              ["Motor", "React 19 · Vite · Tailwind 4 · hls.js (Apache-2.0)"],
              ["APK", "Firmada SHA-256 · Android 9+ · 16:9 forzado"],
              ["Datos", "100% fuentes públicas con licencia"],
              ["Privacidad", "Sin cuentas forzosas · sin tracking · sin venta de datos"],
            ].map(([k, v]) => <li key={k} className="flex items-baseline justify-between gap-3 border-b border-white/5 pb-1.5"><span className="font-bold text-slate-300">{k}</span><span className="text-right text-[9px] text-slate-500">{v}</span></li>)}
          </ul>
          <a href="mailto:soporte@tvlo3.example" className="ghost-btn mt-3 flex h-10 w-full items-center justify-center gap-2 rounded-xl text-[11px] font-bold text-white"><MonitorPlay size={13} className="text-cyanx" /> Reportar un problema <ChevronRight size={12} /></a>
        </section>
      </div>

      {/* ───── SISTEMA Y COPIA DE SEGURIDAD ───── */}
      <section className="tile rounded-2xl p-4">
        <SectionTitle icon={Wrench} tint="text-cyanx">Sistema y copia de seguridad</SectionTitle>
        <div className="mt-2 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
          <div className="flex flex-col justify-between gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <div>
              <p className="text-xs font-bold text-slate-100">Orientación horizontal 16:9</p>
              <p className="mt-0.5 text-[9px] leading-snug text-slate-500">Gira la app forzosamente en móviles verticales (recomendado en TV LO3)</p>
            </div>
            <button role="switch" aria-checked={!noRotate} onClick={() => applyNoRotate(!noRotate)} className={`relative h-6 w-11 self-end rounded-full transition-colors ${!noRotate ? "bg-electric" : "bg-slate-700"}`} aria-label="Forzar orientación horizontal">
              <span className="absolute top-1 h-4 w-4 rounded-full bg-white shadow transition-all" style={{ left: !noRotate ? "24px" : "4px" }} />
            </button>
          </div>
          <div className="flex flex-col justify-between gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <div>
              <p className="text-xs font-bold text-slate-100">Vibración</p>
              <p className="mt-0.5 text-[9px] leading-snug text-slate-500">Haptics en Android: saltos en Neon Dash, marcadores y alertas</p>
            </div>
            <button onClick={testVibration} className="ghost-btn flex h-10 items-center justify-center gap-2 rounded-lg text-[10px] font-bold text-slate-200"><Smartphone size={14} /> Probar · {vibTest}</button>
          </div>
          <div className="flex flex-col justify-between gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <div>
              <p className="text-xs font-bold text-slate-100">Notificación de prueba</p>
              <p className="mt-0.5 text-[9px] leading-snug text-slate-500">Comprueba el permiso real del navegador para avisos</p>
            </div>
            <button onClick={testNotification} className="ghost-btn flex h-10 items-center justify-center gap-2 rounded-lg text-[10px] font-bold text-slate-200"><BellRing size={14} /> Probar · {notifTest}</button>
          </div>
          <div className="flex flex-col justify-between gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <div>
              <p className="text-xs font-bold text-slate-100">Reiniciar TV LO3</p>
              <p className="mt-0.5 text-[9px] leading-snug text-slate-500">Vuelve a la pantalla de arranque como en un TV Box real</p>
            </div>
            <button onClick={restartApp} className="ghost-btn flex h-10 items-center justify-center gap-2 rounded-lg text-[10px] font-bold text-slate-200"><RotateCcw size={14} /> Reiniciar</button>
          </div>
        </div>
        <div className="mt-2 grid gap-2 sm:grid-cols-2">
          <button onClick={exportBackup} className="flex items-center justify-between gap-3 rounded-xl border border-emerald-400/30 bg-emerald-400/8 p-3 text-left transition-colors hover:border-emerald-400/50">
            <span><span className="block text-xs font-bold text-emerald-200">Exportar copia de seguridad</span><span className="mt-0.5 block text-[10px] text-emerald-100/60">Descarga tvlo3-backup.json con TODOS tus ajustes (favoritos, PINs, perfiles)</span></span>
            <Download size={19} className="shrink-0 text-emerald-300" />
          </button>
          <button onClick={() => backupInputRef.current?.click()} className="flex items-center justify-between gap-3 rounded-xl border border-cyanx/30 bg-cyanx/8 p-3 text-left transition-colors hover:border-cyanx/50">
            <span><span className="block text-xs font-bold text-cyan-100">Importar copia de seguridad</span><span className="mt-0.5 block text-[10px] text-cyan-100/60">Restaura tu tvlo3-backup.json en este dispositivo y reinicia</span></span>
            <Upload size={19} className="shrink-0 text-cyanx" />
          </button>
          <input ref={backupInputRef} type="file" accept="application/json,.json" hidden onChange={(e) => importBackup(e.target.files?.[0])} />
        </div>
        <p className="mt-2 flex items-center gap-1.5 px-1 text-[9px] text-slate-600"><CheckCircle2 size={10} className="text-emerald-500" />La copia incluye: perfiles, favoritos, historial, ajustes, PINs y bóveda (excepto los blobs de la bóveda — esos viven en IndexedDB y no caben en un JSON).</p>
      </section>

      {/* ───── EN CASA (SALÓN) ───── */}
      <section className="tile rounded-2xl p-4">
        <SectionTitle icon={Hourglass} tint="text-sky-300">En casa (salón)</SectionTitle>
        <div className="mt-2 grid gap-2 lg:grid-cols-3">
          {/* temporizador */}
          <div className="flex flex-col gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <p className="flex items-center justify-between gap-2 text-xs font-bold text-slate-100"><Hourglass size={14} className="text-sky-300" /> Temporizador
              {timerLeft !== null && <button onClick={stopTimer} className="text-[9px] font-bold uppercase tracking-wider text-rose-400 hover:text-rose-300">Cancelar</button>}
            </p>
            {timerLeft !== null ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-1 py-1">
                <p className="font-display text-4xl font-black tabular-nums text-white">{String(Math.floor(timerLeft / 60)).padStart(2, "0")}:{String(timerLeft % 60).padStart(2, "0")}</p>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-sky-400 to-cyanx transition-all duration-300" style={{ width: `${timerTotal > 0 ? (timerLeft / timerTotal) * 100 : 0}%` }} /></div>
                <p className="text-[8px] uppercase tracking-widest text-slate-500">Te aviso con una campana</p>
              </div>
            ) : (
              <div className="flex flex-1 flex-wrap content-center gap-1.5">
                {[["1 min", 1], ["5 min", 5], ["10 min", 10], ["20 min", 20], ["30 min", 30], ["45 min", 45]].map(([l, v]) => (
                  <button key={l} onClick={() => startTimer(v as number)} className="h-10 flex-1 whitespace-nowrap rounded-lg border border-sky-400/30 bg-sky-400/10 px-3 text-[11px] font-bold text-sky-200 transition-colors hover:bg-sky-400/20">{l}</button>
                ))}
              </div>
            )}
          </div>
          {/* sonidos ambientales */}
          <div className="flex flex-col gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <p className="flex items-center justify-between gap-2 text-xs font-bold text-slate-100"><CloudRain size={14} className="text-lilac" /> Sonidos del salón
              {ambient !== "off" && <button onClick={stopAmbient} className="text-[9px] font-bold uppercase tracking-wider text-rose-400 hover:text-rose-300">Silencio</button>}
            </p>
            <p className="text-[9px] leading-snug text-slate-500">Ambiente sintetizado en tu móvil (Web Audio, sin archivos): cine, lluvia o concentración mientras ves algo.</p>
            <div className="flex flex-1 flex-wrap content-center gap-1.5">
              {([["rain", "Lluvia", CloudRain], ["fire", "Chimenea", FlameIcon], ["wind", "Viento", Wind]] as const).map(([kind, label, Icon]) => (
                <button key={kind} onClick={() => startAmbient(kind)} aria-pressed={ambient === kind} className={`flex h-12 flex-1 items-center justify-center gap-2 rounded-xl border text-[11px] font-bold transition-all ${ambient === kind ? "border-violetx/60 bg-violetx/20 text-lilac" : "border-white/10 bg-white/5 text-slate-300 hover:text-white"}`}><Icon size={17} />{label}</button>
              ))}
            </div>
          </div>
          {/* atajos de teclado */}
          <div className="flex flex-col gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <p className="flex items-center gap-2 text-xs font-bold text-slate-100"><Keyboard size={14} className="text-emerald-300" /> Atajos de teclado</p>
            <ul className="grid flex-1 content-center grid-cols-2 gap-1 text-[9px] text-slate-400">
              {[["Ctrl+1", "Inicio"], ["Ctrl+2", "World TV"], ["Ctrl+3", "Sports"], ["Ctrl+4", "Movies"], ["Ctrl+5", "Series"], ["Ctrl+6", "Games"], ["Ctrl+7", "Music"], ["Ctrl+8", "Radio"], ["Ctrl+9", "News"], ["Ctrl+K", "Buscar"], ["Esc", "Borrar búsqueda"]].map(([k, d]) => (
                <li key={k} className="flex items-center gap-1.5 rounded-md bg-white/[0.03] px-1.5 py-1"><kbd className="rounded border border-white/15 bg-black/40 px-1 font-mono text-[8px] font-bold text-slate-200">{k}</kbd>{d}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* ───── INSTALAR ───── */}
      <InstallCard />

      {/* ───── PERSONALIZACIÓN ───── */}
      <section className="tile rounded-2xl p-4">
        <SectionTitle icon={ImageIcon} tint="text-fuchsia-300">Personalización</SectionTitle>
        <div className="mt-2 grid gap-2 lg:grid-cols-3">
          {/* foto de perfil */}
          <div className="flex flex-col items-center gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-3 text-center">
            <p className="text-xs font-bold text-slate-100">Foto de perfil</p>
            <button onClick={() => avatarInputRef.current?.click()} className="group relative flex h-16 w-16 items-center justify-center overflow-hidden rounded-2xl border border-dashed border-white/20 bg-white/5 transition-colors hover:border-cyanx/50" aria-label="Subir foto de perfil">
              <span className="flex flex-col items-center gap-1 text-slate-500 group-hover:text-cyanx"><Upload size={18} /><span className="text-[8px] font-bold uppercase">Cambiar</span></span>
            </button>
            <input ref={avatarInputRef} type="file" accept="image/*" hidden onChange={(e) => pickAvatar(e.target.files?.[0])} />
            <button onClick={removeAvatar} className="text-[9px] font-semibold uppercase tracking-wider text-slate-500 hover:text-rose-400">Quitar foto</button>
          </div>
          {/* fondo de pantalla */}
          <div className="flex flex-col gap-1.5 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <p className="text-xs font-bold text-slate-100">Fondo de pantalla</p>
            <div className="grid grid-cols-3 gap-1.5">
              {WALLS.map((w) => (
                <button key={w.id} onClick={() => setWallpaper(w.id)} aria-pressed={wallpaper === w.id} title={w.label} className={`group relative h-12 overflow-hidden rounded-lg border transition-all ${wallpaper === w.id ? "border-cyanx ring-2 ring-cyanx/50" : "border-white/10 hover:border-white/30"}`}>
                  <img src={w.img} alt={w.label} loading="lazy" className="absolute inset-0 h-full w-full object-cover" onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")} />
                  <span className="absolute inset-0 flex items-end bg-gradient-to-t from-black/70 to-transparent p-1 text-[7px] font-bold text-white/90">{w.label}</span>
                  {wallpaper === w.id && <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-cyanx"><Check size={10} strokeWidth={3.5} className="text-abyss" /></span>}
                </button>
              ))}
            </div>
            <p className="text-[8px] text-slate-600">Se aplica al instante en el Inicio de TV LO3</p>
          </div>
          {/* salvapantallas */}
          <div className="flex flex-col justify-between gap-2 rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <div className="flex items-center justify-between gap-2">
              <p className="flex items-center gap-1.5 text-xs font-bold text-slate-100"><MoonIcon size={14} className="text-lilac" /> Salvapantallas</p>
              <button role="switch" aria-checked={screensaverOn} onClick={() => setScreensaverOn(!screensaverOn)} aria-label="Activar salvapantallas" className={`relative h-6 w-11 rounded-full transition-colors ${screensaverOn ? "bg-violetx" : "bg-slate-700"}`}><span className="absolute top-1 h-4 w-4 rounded-full bg-white shadow transition-all" style={{ left: screensaverOn ? "24px" : "4px" }} /></button>
            </div>
            <p className="text-[9px] leading-snug text-slate-500">Aurora + reloj gigante cuando dejas el móvil quieto — como un TV Box de verdad. Toca cualquier parte para volver.</p>
            <div>
              <p className="flex items-center gap-1 text-[8px] font-bold uppercase tracking-wider text-slate-600"><Timer size={9} /> Tras</p>
              <div className="mt-1 flex flex-wrap gap-1">
                {[["15 s", 15], ["30 s", 30], ["1 min", 60], ["5 min", 300]].map(([l, v]) => (
                  <button key={v as number} onClick={() => setSsDelay(v as number)} aria-pressed={ssDelay === v} className={`h-7 rounded-md px-2 text-[9px] font-bold transition-colors ${ssDelay === v ? "bg-violetx text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}>{l}</button>
                ))}
              </div>
              <p className="flex items-center gap-1 text-[8px] font-bold uppercase tracking-wider text-slate-600">Estilo de reloj</p>
              <div className="flex gap-1">
                {([["digital", "Digital"], ["analog", "Analógico"], ["minimal", "Minimal"]] as const).map(([v, l]) => (
                  <button key={v} onClick={() => setClockStyle(v)} aria-pressed={clockStyle === v} className={`h-7 flex-1 rounded-md px-2 text-[9px] font-bold transition-colors ${clockStyle === v ? "bg-electric text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}>{l}</button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <p className="flex flex-wrap items-center gap-x-4 gap-y-1 px-1 pb-1 text-[9px] text-slate-600">
        <span className="flex items-center gap-1"><BadgeCheck size={11} className="text-emerald-500" />Datos verificados en cada arranque</span>
        <span className="flex items-center gap-1"><Gauge size={11} />Rendimiento priorizado en Android de gama baja</span>
        <span className="flex items-center gap-1"><ShieldCheck size={11} />Sin emisiones piratas · listas personales autorizadas</span>
      </p>
    </div>
  );
}
