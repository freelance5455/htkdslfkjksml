import { useEffect, useState } from "react";
import { Cpu, ExternalLink, Flame, Globe2, History, Loader2, MessageSquare, RefreshCw, TrendingUp } from "lucide-react";
import { fetchEspnNews, fetchHnTop, type EspnArticle, type HnStory } from "./api";
import { timeAgo } from "./catalog";
import { usePrivacyMax } from "./usePrivacyMax";

interface Efemeride { year: number; text: string; link?: string }
interface MostRead { title: string; views: number; link: string }

export default function NewsView() {
  const pm = usePrivacyMax();
  const [tab, setTab] = useState<"deportes" | "tech" | "efemerides" | "popular">("deportes");
  const [efemerides, setEfemerides] = useState<Efemeride[] | null>(null);
  const [mostRead, setMostRead] = useState<MostRead[] | null>(null);
  const [espn, setEspn] = useState<EspnArticle[] | null>(null);
  const [hn, setHn] = useState<HnStory[] | null>(null);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    Promise.allSettled([fetchEspnNews(9), fetchHnTop(14)]).then(([e, h]) => {
      setEspn(e.status === "fulfilled" ? e.value : []);
      setHn(h.status === "fulfilled" ? h.value : []);
      setLoading(false);
    });
  };
  useEffect(load, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (efemerides !== null) return;
    const now = new Date();
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    const dd = String(now.getDate()).padStart(2, "0");
    fetch(`https://api.wikimedia.org/feed/v1/wikipedia/es/onthisday/all/${mm}/${dd}`)
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error("wikimedia"))))
      .then((j: { selected?: { year: number; text: string; pages?: { titles?: { normalized?: string } }[] }[] }) => {
        setEfemerides((j.selected ?? []).slice(0, 6).map((e) => ({
          year: e.year,
          text: e.text,
          link: e.pages?.[0]?.titles?.normalized ? `https://es.wikipedia.org/wiki/${e.pages[0].titles.normalized.replace(/ /g, "_")}` : undefined,
        })));
      })
      .catch(() => setEfemerides([]));
  }, [efemerides]);

  useEffect(() => {
    if (mostRead !== null) return;
    const now = new Date();
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    const dd = String(now.getDate()).padStart(2, "0");
    const yyyy = now.getFullYear();
    fetch(`https://es.wikipedia.org/api/rest_v1/feed/featured/${yyyy}/${mm}/${dd}`)
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error("wiki"))))
      .then((j: { mostread?: { articles?: { title: string; views?: number }[] } }) => {
        setMostRead((j.mostread?.articles ?? []).slice(0, 8).map((a) => ({
          title: a.title.replace(/_/g, " "),
          views: a.views ?? 0,
          link: `https://es.wikipedia.org/wiki/${a.title}`,
        })));
      })
      .catch(() => setMostRead([]));
  }, [mostRead]);

  return (
    <div className="flex h-full flex-col gap-3 overflow-hidden p-3 sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-black text-white">News</h1>
          <p className="text-[10px] uppercase tracking-wider text-slate-500">Titulares reales: ESPN (LaLiga) · Hacker News (tecnología) · con enlace a la fuente</p>
        </div>
        <button onClick={load} className="flex h-10 items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 text-xs font-bold text-slate-300 hover:text-white" aria-label="Actualizar noticias">
          {loading ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />} Actualizar
        </button>
      </div>

      <div className="flex gap-1.5" role="tablist" aria-label="Secciones de noticias">
        <button role="tab" aria-selected={tab === "deportes"} onClick={() => setTab("deportes")} className={`flex h-10 items-center gap-2 rounded-xl px-4 text-xs font-bold transition-colors ${tab === "deportes" ? "bg-orange-500/80 text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}><Flame size={14} /> Deportes</button>
        <button role="tab" aria-selected={tab === "tech"} onClick={() => setTab("tech")} className={`flex h-10 items-center gap-2 rounded-xl px-4 text-xs font-bold transition-colors ${tab === "tech" ? "bg-electric text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}><Cpu size={14} /> Tecnología</button>
        <button role="tab" aria-selected={tab === "efemerides"} onClick={() => setTab("efemerides")} className={`flex h-10 items-center gap-2 rounded-xl px-4 text-xs font-bold transition-colors ${tab === "efemerides" ? "bg-violetx text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}><History size={14} /> Efemérides</button>
        <button role="tab" aria-selected={tab === "popular"} onClick={() => setTab("popular")} className={`flex h-10 items-center gap-2 rounded-xl px-4 text-xs font-bold transition-colors ${tab === "popular" ? "bg-emerald-600 text-white" : "bg-white/5 text-slate-400 hover:text-white"}`}><Globe2 size={14} /> Lo más leído</button>
      </div>

      <div className="thin-scroll min-h-0 flex-1 overflow-y-auto pr-0.5">
        {loading && <div className="grid gap-2 md:grid-cols-2">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-36 animate-pulse rounded-2xl bg-white/[0.04]" />)}</div>}

        {!loading && tab === "deportes" && (
          <div className="grid gap-2 md:grid-cols-2">
            {(espn ?? []).length === 0 && <p className="col-span-full rounded-2xl border border-white/8 p-6 text-center text-xs text-slate-500">ESPN no respondió. Pulsa actualizar o inténtalo en unos minutos.</p>}
            {(espn ?? []).map((a) => (
              <a key={a.id} href={a.link} target="_blank" rel="noopener noreferrer" className="group overflow-hidden rounded-2xl border border-white/8 bg-panel2 transition-all hover:border-orange-400/40">
                {!pm && a.image && <img src={a.image} alt="" loading="lazy" className="h-32 w-full object-cover transition-transform duration-500 group-hover:scale-105" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />}
                <span className="block p-3">
                  <span className="line-clamp-2 text-[12px] font-bold leading-snug text-slate-100">{a.headline}</span>
                  {a.description && <span className="mt-1 line-clamp-2 block text-[10px] leading-snug text-slate-500">{a.description}</span>}
                  <span className="mt-1.5 flex items-center gap-1.5 text-[8px] font-bold uppercase tracking-wider text-orange-400">ESPN · {a.published ? timeAgo(a.published) : "hoy"} <ExternalLink size={9} /></span>
                </span>
              </a>
            ))}
          </div>
        )}

        {!loading && tab === "popular" && (
          <div>
            <div className="mb-2 flex items-center justify-between gap-2">
              <p className="text-[10px] uppercase tracking-wider text-slate-500">Lo más leído en Wikipedia en español · hoy</p>
              <a href="https://es.wikipedia.org/wiki/Especial:Aleatoria" target="_blank" rel="noopener noreferrer" className="flex h-8 shrink-0 items-center gap-1.5 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-2.5 text-[9px] font-bold text-emerald-300 hover:bg-emerald-500/20">Descubrir aleatoriamente <ExternalLink size={9} /></a>
            </div>
            {mostRead === null && <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-12 animate-pulse rounded-xl bg-white/[0.04]" />)}</div>}
            {mostRead?.length === 0 && <p className="rounded-2xl border border-white/8 p-6 text-center text-xs text-slate-500">Wikimedia no respondió ahora mismo.</p>}
            <ol className="space-y-1">
              {(mostRead ?? []).map((a, i) => (
                <li key={i}>
                  <a href={a.link} target="_blank" rel="noopener noreferrer" className="group flex items-center gap-3 rounded-xl border border-white/6 bg-white/[0.02] p-2.5 transition-colors hover:border-emerald-500/40">
                    <span className="w-7 shrink-0 text-right font-display text-base font-black tabular-nums text-slate-600">{i + 1}</span>
                    <span className="min-w-0 flex-1"><span className="block truncate text-[12px] font-semibold text-slate-100 group-hover:text-white">{a.title}</span><span className="text-[9px] font-semibold tabular-nums text-slate-500">{a.views.toLocaleString("es-ES")} lecturas hoy</span></span>
                    <ExternalLink size={12} className="shrink-0 text-slate-600 transition-colors group-hover:text-emerald-400" />
                  </a>
                </li>
              ))}
            </ol>
          </div>
        )}

        {!loading && tab === "efemerides" && (
          <div>
            <p className="mb-2 text-[10px] uppercase tracking-wider text-slate-500">Hoy en la historia · <span className="text-violet-300">Wikimedia</span> — {new Date().toLocaleDateString("es-ES", { day: "numeric", month: "long" })}</p>
            {efemerides === null && <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-white/[0.04]" />)}</div>}
            {efemerides?.length === 0 && <p className="rounded-2xl border border-white/8 p-6 text-center text-xs text-slate-500">Wikimedia no respondió ahora mismo. Inténtalo en unos minutos.</p>}
            <ol className="space-y-2">
              {(efemerides ?? []).map((e, i) => (
                <li key={i} className="flex items-start gap-3 rounded-2xl border border-white/8 bg-panel2 p-3 transition-colors hover:border-violetx/40">
                  <span className="shrink-0 rounded-lg bg-violetx/15 px-2 py-1.5 font-display text-sm font-black tabular-nums text-lilac">{e.year}</span>
                  <span className="min-w-0 flex-1">
                    <span className="text-[12px] leading-snug text-slate-100">{e.text}</span>
                    {e.link && <a href={e.link} target="_blank" rel="noopener noreferrer" className="mt-1 inline-flex items-center gap-1 text-[10px] font-bold text-cyanx hover:underline">Leer en Wikipedia <ExternalLink size={10} /></a>}
                  </span>
                </li>
              ))}
            </ol>
          </div>
        )}

        {!loading && tab === "tech" && (
          <ol className="space-y-1">
            {(hn ?? []).length === 0 && <li className="rounded-2xl border border-white/8 p-6 text-center text-xs text-slate-500">Hacker News no respondió. Pulsa actualizar.</li>}
            {(hn ?? []).map((s, i) => (
              <li key={s.id}>
                <a href={s.url} target="_blank" rel="noopener noreferrer" className="group flex items-start gap-3 rounded-xl border border-white/6 bg-white/[0.02] p-2.5 transition-colors hover:border-electric/40">
                  <span className="w-6 shrink-0 text-right font-display text-base font-black text-slate-600">{i + 1}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[12px] font-semibold leading-snug text-slate-100 transition-colors group-hover:text-white">{s.title}</span>
                    <span className="mt-1 flex flex-wrap items-center gap-2 text-[9px] font-semibold text-slate-500">
                      <span className="rounded bg-white/5 px-1.5 py-0.5 text-slate-400">{s.domain}</span>
                      <span className="flex items-center gap-1"><TrendingUp size={10} />{s.score} pts</span>
                      <span className="flex items-center gap-1"><MessageSquare size={10} />{s.descendants}</span>
                      <span>por {s.by} · {timeAgo(new Date(s.time * 1000).toISOString())}</span>
                    </span>
                  </span>
                  <ExternalLink size={13} className="mt-1 shrink-0 text-slate-600 group-hover:text-cyanx" />
                </a>
              </li>
            ))}
          </ol>
        )}
      </div>
    </div>
  );
}
