import { useEffect, useState } from "react";
import { fmtClock, type Transport } from "../lib/store";

/* ------------------------------- icons -------------------------------- */
export const I = {
  bt: (s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M7 7l10 10-5 5V2l5 5L7 17" />
    </svg>
  ),
  wifi: (s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M5 12.5a10 10 0 0 1 14 0M2 8.5a15 15 0 0 1 20 0M8.5 16a5 5 0 0 1 7 0" />
      <circle cx="12" cy="19.4" r="1.3" fill="currentColor" stroke="none" />
    </svg>
  ),
  globeOff: (s = 14) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <circle cx="12" cy="12" r="9" />
      <path d="M3.6 9h16.8M3.6 15h16.8M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" />
      <line x1="4" y1="4" x2="20" y2="20" />
    </svg>
  ),
  back: (s = 18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
      <path d="M15 6l-6 6 6 6" />
    </svg>
  ),
  send: (s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M3 20l18-8L3 4v6.5L14 12 3 13.5V20z" />
    </svg>
  ),
  copy: (s = 14) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="12" height="12" rx="2.5" />
      <path d="M5 15V5a2 2 0 0 1 2-2h10" />
    </svg>
  ),
  gear: (s = 18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3.2" />
      <path d="M19 12a7 7 0 0 0-.15-1.4l2-1.55-2-3.46-2.35.95A7 7 0 0 0 14.05 5L13.7 2.5h-3.4L9.95 5a7 7 0 0 0-2.45 1.44l-2.35-.85-2 3.46 2 1.55A7 7 0 0 0 5 12c0 .48.05.94.15 1.4l-2 1.55 2 3.46 2.35-.95A7 7 0 0 0 9.95 19l.35 2.5h3.4l.35-2.5a7 7 0 0 0 2.45-1.44l2.35.85 2-3.46-2-1.55c.1-.46.15-.92.15-1.4z" />
    </svg>
  ),
  check: (s = 12) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round">
      <path d="M4 12.5l5 5L20 6.5" />
    </svg>
  ),
  checks: (s = 14) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round">
      <path d="M2.5 12.5l4 4L14 9" />
      <path d="M9.5 16.5l1.5 1.5L19.5 9.5" />
    </svg>
  ),
  clock: (s = 11) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 2" />
    </svg>
  ),
  trash: (s = 14) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m-8 0l1 13a1 1 0 0 0 1 .9h6a1 1 0 0 0 1-.9l1-13" />
    </svg>
  ),
  refresh: (s = 14) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 11A8 8 0 1 0 18.5 16" />
      <path d="M20 5v6h-6" />
    </svg>
  ),
  link: (s = 14) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 15l6-6" />
      <path d="M11 6l1.5-1.5a4 4 0 0 1 5.7 5.7L16.5 12" />
      <path d="M13 18l-1.5 1.5a4 4 0 0 1-5.7-5.7L7.5 12" />
    </svg>
  ),
};

export function TransportIcon({ t, size = 13 }: { t: Transport; size?: number }) {
  return t === "bluetooth" ? I.bt(size) : I.wifi(size);
}

/* --------------------------- status bar (app) -------------------------- */
export function StatusBar({ dark = false }: { dark?: boolean }) {
  const [time, setTime] = useState(fmtClock());
  useEffect(() => {
    const t = setInterval(() => setTime(fmtClock()), 15000);
    return () => clearInterval(t);
  }, []);
  const cls = dark ? "text-white/85" : "text-ink";
  return (
    <div className={`flex items-center justify-between px-6 pt-3 pb-1 text-[11px] font-semibold ${cls}`}>
      <span className="font-mono">{time}</span>
      <span className="flex items-center gap-1.5">
        {I.bt(12)}
        {I.wifi(13)}
        <span className="ml-1 inline-flex items-center gap-0.5">
          <span className="relative inline-block w-[18px] h-[9px] rounded-[2.5px] border border-current">
            <span className="absolute inset-[1.5px] right-[4px] rounded-[1px] bg-current" />
          </span>
          <span className="inline-block w-[1.5px] h-[4px] rounded-full bg-current" />
        </span>
      </span>
    </div>
  );
}

/* ------------------------------- toasts -------------------------------- */
export interface ToastData {
  id: number;
  text: string;
  tone: "ok" | "err" | "info";
}

export function Toasts({ items }: { items: ToastData[] }) {
  return (
    <div className="absolute bottom-24 inset-x-0 z-50 flex flex-col items-center gap-2 px-6 pointer-events-none">
      {items.map((t) => (
        <div
          key={t.id}
          className={`animate-toast max-w-full rounded-full px-4 py-2.5 text-[12.5px] font-semibold shadow-lg backdrop-blur border ${
            t.tone === "ok"
              ? "bg-emerald-500/95 border-emerald-400 text-white shadow-emerald-500/30"
              : t.tone === "err"
                ? "bg-red-500/95 border-red-400 text-white shadow-red-500/30"
                : "bg-ink/90 border-white/15 text-white shadow-ink/30"
          }`}
        >
          {t.text}
        </div>
      ))}
    </div>
  );
}

/* ------------------------------ presence dot --------------------------- */
export function Dot({ on, size = 8 }: { on: boolean; size?: number }) {
  return (
    <span
      style={{ width: size, height: size }}
      className={`inline-block rounded-full ${on ? "bg-emerald-500 animate-pulse-dot" : "bg-slate-300"}`}
    />
  );
}
