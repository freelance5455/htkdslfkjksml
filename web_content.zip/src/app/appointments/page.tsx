"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { CalendarCheck, CheckCircle2, MapPin, Phone, Star, Wallet, ShieldCheck } from "lucide-react";
import { useAuth, useI18n, useToast } from "@/components/providers";
import { Alert, Button, buttonClass, CardSkeleton, EmptyState, ErrorState, PageHeader, ServiceIcon, StatusBadge, Tabs, Textarea, Badge, LoginPrompt } from "@/components/ui";
import { api } from "@/lib/api-client";
import type { AppointmentDTO, AppointmentStatus } from "@/lib/types";
import { cn, formatDateTime, formatPrice, loc } from "@/lib/utils";

type Filter = "all" | AppointmentStatus;
type Action = "confirm" | "complete" | "cancel";

const NEXT_STATUS: Record<Action, AppointmentStatus> = {
  confirm: "confirmed",
  complete: "completed",
  cancel: "cancelled",
};

export default function AppointmentsPage() {
  const { t, locale, te } = useI18n();
  const { user, loading: authLoading } = useAuth();
  const toast = useToast();
  const [items, setItems] = useState<AppointmentDTO[] | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    let alive = true;
    setError(false);
    api<{ appointments: AppointmentDTO[] }>("/api/appointments")
      .then((r) => alive && setItems(r.appointments))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [user, reloadKey]);

  /** Optimistic status change: the card updates instantly and is restored if the server rejects it. */
  const runAction = async (appt: AppointmentDTO, action: Action) => {
    if (action === "cancel" && !window.confirm(t("appt.cancelConfirm"))) return;
    const previous = appt.status;
    setItems((prev) => prev?.map((a) => (a.id === appt.id ? { ...a, status: NEXT_STATUS[action] } : a)) ?? null);
    setBusyId(appt.id);
    try {
      const updated = await api<AppointmentDTO>(`/api/appointments/${appt.id}`, { method: "PATCH", body: { action } });
      setItems((prev) => prev?.map((a) => (a.id === appt.id ? updated : a)) ?? null);
      toast.success(t("appt.updated"));
      window.dispatchEvent(new Event("shifacare:notifications"));
    } catch (err) {
      setItems((prev) => prev?.map((a) => (a.id === appt.id ? { ...a, status: previous } : a)) ?? null);
      toast.error(te(err));
    } finally {
      setBusyId(null);
    }
  };

  if (authLoading) return <CardSkeleton lines={6} />;
  if (!user)
    return (
      <div>
        <PageHeader title={t("appt.title")} subtitle={t("appt.subtitle")} />
        <LoginPrompt message={t("book.loginRequired")} next="/appointments" />
      </div>
    );

  const visible = items?.filter((a) => filter === "all" || a.status === filter) ?? [];
  const count = (s: Filter) => (items ? items.filter((a) => s === "all" || a.status === s).length : undefined);
  const filters: Array<{ value: Filter; label: string; count?: number }> = [
    { value: "all", label: t("appt.filterAll"), count: count("all") },
    { value: "pending", label: t("status.pending"), count: count("pending") },
    { value: "confirmed", label: t("status.confirmed"), count: count("confirmed") },
    { value: "completed", label: t("status.completed"), count: count("completed") },
    { value: "cancelled", label: t("status.cancelled"), count: count("cancelled") },
  ];

  return (
    <div>
      <PageHeader
        title={t("appt.title")}
        subtitle={t("appt.subtitle")}
        actions={user.role === "patient" ? <Link href="/book" className={buttonClass("primary")}><CalendarCheck className="h-4 w-4" />{t("nav.book")}</Link> : undefined}
      />

      {user.role === "admin" && (
        <div className="mb-6">
          <Alert tone="info">
            <span className="flex flex-wrap items-center justify-between gap-3">
              {t("appt.adminHint")}
              <Link href="/admin" className={buttonClass("secondary", "sm")}>
                {t("appt.adminOpen")}
              </Link>
            </span>
          </Alert>
        </div>
      )}

      <div className="mb-6 overflow-x-auto">
        <Tabs items={filters} value={filter} onChange={setFilter} className="min-w-max" />
      </div>

      {error ? (
        <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
      ) : !items ? (
        <div className="space-y-4">
          <CardSkeleton lines={3} />
          <CardSkeleton lines={3} />
        </div>
      ) : visible.length === 0 ? (
        <EmptyState
          icon={CalendarCheck}
          title={t("appt.empty")}
          action={user.role === "patient" ? <Link href="/book" className={buttonClass("primary")}>{t("appt.emptyCta")}</Link> : undefined}
        />
      ) : (
        <div className="space-y-4">
          {visible.map((a) => (
            <AppointmentCard
              key={a.id}
              appt={a}
              role={user.role}
              busy={busyId === a.id}
              onAction={(action) => void runAction(a, action)}
              onReviewed={(rating) =>
                setItems((prev) => prev?.map((x) => (x.id === a.id ? { ...x, reviewId: "submitted", reviewRating: rating } : x)) ?? null)
              }
            />
          ))}
        </div>
      )}
    </div>
  );
}

function AppointmentCard({
  appt,
  role,
  busy,
  onAction,
  onReviewed,
}: {
  appt: AppointmentDTO;
  role: string;
  busy: boolean;
  onAction: (action: Action) => void;
  onReviewed: (rating: number) => void;
}) {
  const { t, locale, te } = useI18n();
  const toast = useToast();
  const [reviewOpen, setReviewOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState(false);

  const isOpen = appt.status === "pending" || appt.status === "confirmed";
  const canReview = role === "patient" && appt.status === "completed" && !appt.reviewId && !!appt.professionalId;

  const submitReview = async () => {
    setSaving(true);
    try {
      await api("/api/reviews", { body: { appointmentId: appt.id, rating, comment: comment.trim() } });
      toast.success(t("appt.reviewThanks"));
      onReviewed(rating);
      setReviewOpen(false);
    } catch (err) {
      toast.error(te(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <article className={cn("rounded-2xl bg-white p-5 shadow-sm ring-1 ring-sky-100/80 transition sm:p-6", busy && "opacity-70")}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-sky-500 text-white shadow">
            <ServiceIcon name={appt.serviceIcon} className="h-5 w-5" />
          </span>
          <div>
            <h3 className="font-semibold text-slate-900">{loc(appt.serviceName, locale)}</h3>
            <p className="text-xs text-slate-500">
              {t("appt.reference")}: <span className="font-mono">{appt.reference}</span>
            </p>
          </div>
        </div>
        <StatusBadge status={appt.status} />
      </div>

      <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-2">
        <div>
          <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">{t("appt.when")}</dt>
          <dd className="mt-1 font-medium text-slate-900">{formatDateTime(appt.scheduledAt, locale)}</dd>
        </div>
        <div>
          <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">{t("appt.professional")}</dt>
          <dd className="mt-1 font-medium text-slate-900">{appt.professionalName ?? <span className="text-amber-700">{t("appt.unassigned")}</span>}</dd>
        </div>
        <div>
          <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">{t("common.address")}</dt>
          <dd className="mt-1 flex items-start gap-1.5 text-slate-700">
            <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-slate-400" />
            <span>
              {appt.city} · {appt.address}
            </span>
          </dd>
        </div>
        <div>
          <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">{t("common.price")}</dt>
          <dd className="mt-1 flex items-center gap-1.5 text-slate-700">
            <Wallet className="h-3.5 w-3.5 text-slate-400" />
            {formatPrice(appt.priceMad, locale)} · {appt.durationMinutes} {t("common.minutes")}
          </dd>
        </div>
        {role !== "patient" && (
          <div className="sm:col-span-2 rounded-xl bg-slate-50 p-3">
            <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">{t("common.name")}</dt>
            <dd className="mt-1 flex flex-wrap items-center gap-3 font-medium text-slate-900">
              {appt.patientName}
              <a href={`tel:${appt.phone}`} className="inline-flex items-center gap-1 text-teal-700 hover:underline">
                <Phone className="h-3.5 w-3.5" />
                {appt.phone}
              </a>
            </dd>
            {appt.medicalNotes && (
              <p className="mt-2 text-sm leading-relaxed text-slate-700">
                <span className="font-semibold">{t("appt.patientNotes")}: </span>
                {appt.medicalNotes}
              </p>
            )}
            <p className="mt-2 flex items-center gap-1 text-xs text-slate-500">
              <ShieldCheck className="h-3.5 w-3.5" />
              {t("appt.assignedHint")}
            </p>
          </div>
        )}
        {role === "patient" && appt.medicalNotes && (
          <div className="sm:col-span-2">
            <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">{t("common.notes")}</dt>
            <dd className="mt-1 text-slate-700">{appt.medicalNotes}</dd>
          </div>
        )}
      </dl>

      {appt.status === "cancelled" && appt.cancelReason && (
        <p className="mt-4 rounded-xl bg-rose-50 px-3 py-2 text-sm text-rose-800">{appt.cancelReason}</p>
      )}

      <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-4">
        {role === "patient" && isOpen && (
          <Button variant="danger" size="sm" onClick={() => onAction("cancel")} disabled={busy}>
            {t("appt.cancel")}
          </Button>
        )}
        {role === "professional" && appt.status === "pending" && (
          <Button variant="primary" size="sm" onClick={() => onAction("confirm")} disabled={busy}>
            <CheckCircle2 className="h-4 w-4" />
            {t("appt.confirm")}
          </Button>
        )}
        {role === "professional" && appt.status === "confirmed" && (
          <Button variant="primary" size="sm" onClick={() => onAction("complete")} disabled={busy}>
            <CheckCircle2 className="h-4 w-4" />
            {t("appt.complete")}
          </Button>
        )}
        {role === "professional" && isOpen && (
          <Button variant="danger" size="sm" onClick={() => onAction("cancel")} disabled={busy}>
            {t("appt.cancel")}
          </Button>
        )}
        {canReview && !reviewOpen && (
          <Button variant="secondary" size="sm" onClick={() => setReviewOpen(true)}>
            <Star className="h-4 w-4" />
            {t("appt.review")}
          </Button>
        )}
        {role === "patient" && appt.reviewId && (
          <Badge tone="green">
            <CheckCircle2 className="h-3.5 w-3.5" />
            {t("appt.reviewed")} · {appt.reviewRating}/5
          </Badge>
        )}
      </div>

      {canReview && reviewOpen && (
        <div className="mt-4 space-y-4 rounded-2xl bg-amber-50/60 p-4 ring-1 ring-amber-100">
          <p className="font-semibold text-slate-900">{t("appt.reviewTitle")}</p>
          <div>
            <p className="mb-2 text-sm text-slate-700">{t("appt.rating")}</p>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((n) => (
                <button key={n} type="button" aria-label={`${n}/5`} onClick={() => setRating(n)} className="rounded-lg p-1 transition hover:scale-110">
                  <Star className={cn("h-7 w-7", n <= rating ? "fill-amber-400 text-amber-400" : "text-slate-300")} />
                </button>
              ))}
            </div>
          </div>
          <Textarea rows={3} maxLength={1000} value={comment} onChange={(e) => setComment(e.target.value)} placeholder={t("appt.comment")} />
          <div className="flex gap-2">
            <Button variant="primary" size="sm" loading={saving} onClick={() => void submitReview()}>
              {t("appt.submitReview")}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setReviewOpen(false)}>
              {t("common.cancel")}
            </Button>
          </div>
        </div>
      )}
    </article>
  );
}
