import { LanguageCode } from './types';

export interface TranslationPack {
  appName: string;
  navDashboard: string;
  navGames: string;
  navUltra: string;
  navGfx: string;
  navHud: string;
  navMonitor: string;
  navDeviceCheck: string;
  navCoach: string;
  navNetwork: string;
  navTraining: string;
  navSettings: string;
  navSplash: string;
  navOnboarding: string;
  launchUltra: string;
  systemInfo: string;
  mainFeatures: string;
  liveFps: string;
  battery: string;
  memoryRam: string;
  cpuCompute: string;
  networkLink: string;
  batteryTemp: string;
  notExposedByBrowser: string;
  activeSession: string;
  startTest: string;
  themeDark: string;
  themeLight: string;
  languageLabel: string;
}

export const TRANSLATIONS: Record<LanguageCode, TranslationPack> = {
  en: {
    appName: 'Game Booster PRO',
    navDashboard: 'Dashboard',
    navGames: 'My Games',
    navUltra: 'Ultra Mode',
    navGfx: 'GFX Guide',
    navHud: 'Game HUD',
    navMonitor: 'System Monitor',
    navDeviceCheck: 'Device Check',
    navCoach: 'AI Game Coach',
    navNetwork: 'Network Check',
    navTraining: 'Gamer Training',
    navSettings: 'Settings',
    navSplash: 'Splash Screen',
    navOnboarding: 'Onboarding',
    launchUltra: 'Ultra Mode',
    systemInfo: 'System Information',
    mainFeatures: 'Main Features',
    liveFps: 'Live Frame Rate',
    battery: 'Battery Level',
    memoryRam: 'Memory & Heap',
    cpuCompute: 'CPU & Thread Load',
    networkLink: 'Network Link',
    batteryTemp: 'Battery Temp',
    notExposedByBrowser: 'Android Native API Only',
    activeSession: 'Active Session',
    startTest: 'Run Diagnostic',
    themeDark: 'Dark Obsidian',
    themeLight: 'Light Studio',
    languageLabel: 'Interface Language',
  },
  es: {
    appName: 'Game Booster PRO',
    navDashboard: 'Panel Principal',
    navGames: 'Mis Juegos',
    navUltra: 'Modo Ultra',
    navGfx: 'Guía GFX',
    navHud: 'HUD Flotante',
    navMonitor: 'Monitor Sistema',
    navDeviceCheck: 'Test Dispositivo',
    navCoach: 'Coach IA',
    navNetwork: 'Test de Red',
    navTraining: 'Entrenamiento',
    navSettings: 'Ajustes',
    navSplash: 'Pantalla Inicio',
    navOnboarding: 'Bienvenida',
    launchUltra: 'Modo Ultra',
    systemInfo: 'Información del Sistema',
    mainFeatures: 'Funciones Principales',
    liveFps: 'FPS en Vivo',
    battery: 'Batería',
    memoryRam: 'Memoria RAM',
    cpuCompute: 'CPU y Carga',
    networkLink: 'Red Activa',
    batteryTemp: 'Temp. Batería',
    notExposedByBrowser: 'Solo API Nativa Android',
    activeSession: 'Sesión Activa',
    startTest: 'Iniciar Test',
    themeDark: 'Obsidiana Oscura',
    themeLight: 'Estudio Claro',
    languageLabel: 'Idioma de Interfaz',
  },
  pt: {
    appName: 'Game Booster PRO',
    navDashboard: 'Painel',
    navGames: 'Meus Jogos',
    navUltra: 'Modo Ultra',
    navGfx: 'Guia GFX',
    navHud: 'HUD Flutuante',
    navMonitor: 'Monitor Ao Vivo',
    navDeviceCheck: 'Teste Hardware',
    navCoach: 'Coach IA',
    navNetwork: 'Teste de Rede',
    navTraining: 'Treino Gamer',
    navSettings: 'Configurações',
    navSplash: 'Tela Inicial',
    navOnboarding: 'Introdução',
    launchUltra: 'Modo Ultra',
    systemInfo: 'Informações do Sistema',
    mainFeatures: 'Recursos Principais',
    liveFps: 'FPS ao Vivo',
    battery: 'Bateria',
    memoryRam: 'Memória RAM',
    cpuCompute: 'CPU e Núcleos',
    networkLink: 'Conexão',
    batteryTemp: 'Temp. Bateria',
    notExposedByBrowser: 'Apenas API Nativa Android',
    activeSession: 'Sessão Ativa',
    startTest: 'Iniciar Teste',
    themeDark: 'Obsidiana Escura',
    themeLight: 'Estúdio Claro',
    languageLabel: 'Idioma do App',
  },
  hi: {
    appName: 'Game Booster PRO',
    navDashboard: 'डैशबोर्ड',
    navGames: 'मेरे गेम्स',
    navUltra: 'अल्ट्रा मोड',
    navGfx: 'GFX गाइड',
    navHud: 'गेम HUD',
    navMonitor: 'सिस्टम मॉनिटर',
    navDeviceCheck: 'डिवाइस जांच',
    navCoach: 'AI गेम कोच',
    navNetwork: 'नेटवर्क जांच',
    navTraining: 'गेमर ट्रेनिंग',
    navSettings: 'सेटिंग्स',
    navSplash: 'स्प्लैश स्क्रीन',
    navOnboarding: 'ऑनबोर्डिंग',
    launchUltra: 'अल्ट्रा मोड',
    systemInfo: 'सिस्टम जानकारी',
    mainFeatures: 'मुख्य विशेषताएं',
    liveFps: 'लाइव FPS',
    battery: 'बैटरी स्तर',
    memoryRam: 'मेमोरी और रैम',
    cpuCompute: 'CPU कोर और लोड',
    networkLink: 'नेटवर्क लिंक',
    batteryTemp: 'बैटरी तापमान',
    notExposedByBrowser: 'केवल Android नेटिव API',
    activeSession: 'सक्रिय सत्र',
    startTest: 'टेस्ट चलाएं',
    themeDark: 'डार्क ओब्सीडियन',
    themeLight: 'लाइट स्टूडियो',
    languageLabel: 'इंटरफ़ेस भाषा',
  },
  ja: {
    appName: 'Game Booster PRO',
    navDashboard: 'ダッシュボード',
    navGames: 'マイゲーム',
    navUltra: 'ウルトラモード',
    navGfx: 'GFXガイド',
    navHud: 'ゲームHUD',
    navMonitor: 'システム監視',
    navDeviceCheck: 'デバイス診断',
    navCoach: 'AIコーチ',
    navNetwork: '通信テスト',
    navTraining: '反射トレーニング',
    navSettings: '設定',
    navSplash: 'スプラッシュ',
    navOnboarding: 'オンボーディング',
    launchUltra: 'ウルトラモード',
    systemInfo: 'システム情報',
    mainFeatures: '主要機能',
    liveFps: 'リアルタイムFPS',
    battery: 'バッテリー残量',
    memoryRam: 'メモリ / RAM',
    cpuCompute: 'CPUコア / 負荷',
    networkLink: 'ネットワーク',
    batteryTemp: 'バッテリー温度',
    notExposedByBrowser: 'AndroidネイティブAPI限定',
    activeSession: 'アクティブ中',
    startTest: 'テスト実行',
    themeDark: 'ダークモード',
    themeLight: 'ライトモード',
    languageLabel: '表示言語',
  },
};

export const LANGUAGE_OPTIONS: Array<{ code: LanguageCode; label: string }> = [
  { code: 'en', label: 'English' },
  { code: 'es', label: 'Español' },
  { code: 'pt', label: 'Português' },
  { code: 'hi', label: 'हिन्दी' },
  { code: 'ja', label: '日本語' },
];
