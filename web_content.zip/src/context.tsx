import { createContext, useContext } from "react";

export type TabId = "composer" | "review" | "pulse" | "memory";

export type PageId =
  | "about"
  | "customers"
  | "careers"
  | "press"
  | "docs"
  | "blog"
  | "security"
  | "status"
  | "changelog"
  | "privacy"
  | "terms"
  | "dpa";

export type TrialOptions = {
  email?: string;
  plan?: string;
};

export type AppContextValue = {
  openTrial: (opts?: TrialOptions) => void;
  openLogin: () => void;
  openDemo: () => void;
  openPage: (id: PageId) => void;
  closeOverlay: () => void;
  showcase: TabId;
  setShowcase: (tab: TabId) => void;
  menuOpen: boolean;
  setMenuOpen: (open: boolean) => void;
  trialEmail: string;
  trialPlan: string;
  trialNonce: number;
  page: PageId;
  overlay: "trial" | "login" | "demo" | "page" | null;
};

const AppContext = createContext<AppContextValue | null>(null);

export const AppProvider = AppContext.Provider;

export function useApp() {
  const value = useContext(AppContext);
  if (!value) {
    throw new Error("useApp must be used within AppProvider");
  }
  return value;
}
