/* ==========================================================================
   store.js — مدل داده + ذخیره‌سازی محلی + حالت نمایشی (Demo)
   ========================================================================== */

import { readLS, writeLS, KEYS } from './storage.js';
import { uid, todayKey, dateKey, addDays, currentMonthKey, addMonthsKey, monthKeyOf, deepMerge, clamp } from './utils.js';
import { buildRoadmap, discoverPaths } from './engines/roadmap-engine.js';
import { ensureDay } from './engines/planner.js';
import { checkAchievements } from './achievements.js';

export const STATE_VERSION = 1;

export function defaultState() {
  return {
    id: uid('user'),
    version: STATE_VERSION,
    createdAt: todayKey(),
    updatedAt: Date.now(),
    onboardingDone: false,
    demoMode: false,
    profile: {
      name: '', age: 30, gender: '', country: 'ایران', city: '', marital: '', dependents: 0,
      job: 'employee', skills: [], experienceYears: 0, freeHours: 2, riskTolerance: 50,
      currency: 'IRT', currencyLabel: '', dayStartHour: 8, mission: '', reasons: [],
      incomeGoal: 0, targetWealth: 0, goalUnit: 'IRT',
      assumptions: { inflation: 30, returnRate: 35, incomeGrowth: 15 },
    },
    finance: { incomes: [], expenses: [], assets: [], debts: [], transactions: [], snapshots: [] },
    goals: [],
    plan: { pathId: '', roadmap: null, missions: [], days: {}, weeks: {}, monthlyReviews: [], weeklyReviews: [], restDays: [6], businessStarted: false },
    habits: [],
    skills: [],
    learning: { books: [], lessonsDone: 0 },
    chat: [],
    notes: [],
    decisions: [],
    streak: { current: 0, best: 0, lastActiveDay: null, history: [] },
    gamification: { xp: 0, achievements: [], history: [], tasksDone: 0 },
    settings: { theme: 'dark', language: 'fa', persianDigits: true, notifications: false, lockEnabled: false },
    meta: { lastRecalc: null, installDate: todayKey() },
  };
}

const listeners = new Set();
let data = null;

export const State = {
  init() {
    const raw = readLS(KEYS.state, null);
    data = raw ? deepMerge(defaultState(), raw) : defaultState();
    return data;
  },
  get() { return data; },
  isDemo() { return !!(data && data.demoMode); },
  /** mutator(draft) — تغییر مستقیم و سپس ذخیره + اطلاع به UI */
  update(mutator, opts = {}) {
    if (!data) State.init();
    mutator(data);
    data.updatedAt = Date.now();
    if (opts.persist !== false) writeLS(KEYS.state, data);
    if (opts.silent !== true) State.notify();
    return data;
  },
  replace(next) {
    data = deepMerge(defaultState(), next);
    data.updatedAt = Date.now();
    writeLS(KEYS.state, data);
    State.notify();
  },
  persist() { if (data) writeLS(KEYS.state, data); },
  reset() { data = defaultState(); writeLS(KEYS.state, data); State.notify(); },
  subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
  notify() { listeners.forEach((fn) => { try { fn(data); } catch (e) { void e; } }); },
};

/* ------------------------------------------------------------- حالت نمایشی */
export function buildDemoState() {
  const s = defaultState();
  s.demoMode = true;
  s.onboardingDone = true;
  s.id = 'demo_user';
  s.profile.name = 'کاربر نمایشی';
  s.profile.age = 30;
  s.profile.country = 'ایران';
  s.profile.city = 'تهران';
  s.profile.marital = 'متأهل';
  s.profile.dependents = 2;
  s.profile.job = 'technician';
  s.profile.skills = ['مکانیک', 'تعمیرات', 'برق صنعتی'];
  s.profile.experienceYears = 8;
  s.profile.freeHours = 2;
  s.profile.riskTolerance = 45;
  s.profile.currency = 'IRT';
  s.profile.incomeGoal = 150000000;
  s.profile.mission = 'می‌خواهم تا ۴۰ سالگی آزادی زمانی داشته باشم و برای خانواده‌ام امنیت مالی بسازم.';
  s.profile.reasons = ['آزادی زمانی', 'خانواده', 'امنیت'];

  s.finance.incomes = [
    { id: uid('i'), label: 'حقوق کارگاه', amount: 45000000, type: 'fixed', kind: 'salary' },
    { id: uid('i'), label: 'تعمیرات آزاد (تعطیلات)', amount: 5000000, type: 'variable', kind: 'side' },
  ];
  s.finance.expenses = [
    { id: uid('e'), label: 'اجاره خانه', category: 'مسکن', amount: 12000000 },
    { id: uid('e'), label: 'خوراک', category: 'غذا', amount: 9000000 },
    { id: uid('e'), label: 'حمل‌ونقل', category: 'حمل‌ونقل', amount: 3000000 },
    { id: uid('e'), label: 'اقساط خودرو', category: 'اقساط', amount: 4500000 },
    { id: uid('e'), label: 'تفریح و اینترنت', category: 'تفریح', amount: 1500000 },
  ];
  s.finance.assets = [
    { id: uid('a'), label: 'موجودی نقد', category: 'نقد', amount: 60000000, liquid: true },
    { id: uid('a'), label: 'سپرده بانکی', category: 'سپرده', amount: 40000000, liquid: false },
    { id: uid('a'), label: 'طلا', category: 'طلا', amount: 60000000, liquid: false },
    { id: uid('a'), label: 'خودرو', category: 'خودرو', amount: 150000000, liquid: false },
    { id: uid('a'), label: 'ابزار کارگاه', category: 'تجهیزات', amount: 35000000, liquid: false },
  ];
  s.finance.debts = [
    { id: uid('d'), label: 'وام خودرو', kind: 'vehicle', amount: 70000000, rate: 23, term: 24, monthlyPayment: 4500000 },
    { id: uid('d'), label: 'بدهی به دوستان', kind: 'personal', amount: 30000000, rate: 0, term: 12, monthlyPayment: 2500000 },
  ];

  s.goals = [{
    id: uid('g'), title: 'استقلال مالی', type: 'freedom', unit: 'IRT',
    targetAmount: 9000000000, monthlyIncomeTarget: 150000000,
    deadline: addDays(todayKey(), 365 * 10), createdAt: todayKey(), done: false,
  }];

  // تراکنش‌های سه ماه گذشته برای نمودارها و گزارش ماهانه
  const mk0 = currentMonthKey();
  [2, 1, 0].forEach((back) => {
    const mk = addMonthsKey(mk0, -back);
    const base = mk.slice(0, 7);
    [1, 5, 12, 20].forEach((day) => {
      const gy = Number(base.split('-')[0]), gm = Number(base.split('-')[1]);
      const dt = new Date(gy, gm - 1, Math.min(day, 27));
      s.finance.transactions.push({ id: uid('tx'), date: dateKey(dt), type: 'income', category: 'درآمد', kind: 'salary', label: 'حقوق', amount: 45000000 + (back === 0 ? 3000000 : 0) });
    });
    [3, 8, 15, 22, 26].forEach((day, i) => {
      const gy = Number(base.split('-')[0]), gm = Number(base.split('-')[1]);
      const dt = new Date(gy, gm - 1, Math.min(day, 27));
      s.finance.transactions.push({
        id: uid('tx'), date: dateKey(dt), type: 'expense',
        category: ['مسکن', 'غذا', 'حمل‌ونقل', 'اقساط', 'تفریح'][i % 5], kind: '',
        label: 'هزینه ماهانه', amount: [12000000, 9000000, 3000000, 4500000, 1500000][i % 5] + (back === 1 && i === 4 ? 2500000 : 0),
      });
    });
  });

  s.habits = [
    { id: uid('h'), title: 'مطالعه ۲۰ صفحه', cat: 'یادگیری', minutes: 25, targetPerWeek: 6, icon: '📖', history: [], streak: 0, impact: 60 },
    { id: uid('h'), title: 'اقدام فروش (تماس/پیام)', cat: 'درآمد', minutes: 30, targetPerWeek: 5, icon: '🤝', history: [], streak: 0, impact: 70 },
    { id: uid('h'), title: 'ثبت هزینه‌ها', cat: 'مالی', minutes: 3, targetPerWeek: 7, icon: '🧾', history: [], streak: 0, impact: 65 },
  ];
  s.skills = [
    { id: uid('s'), title: 'مکانیک', level: 4, note: 'تعمیر موتور و سیستم تعلیق' },
    { id: uid('s'), title: 'تعمیرات', level: 3, note: 'خدمات در محل' },
    { id: uid('s'), title: 'فروش', level: 2, note: 'در حال یادگیری' },
  ];
  s.learning.books = [
    { id: 'b05', title: 'روانشناسی پول', readAt: todayKey() },
    { id: 'b01', title: 'ثروتمندترین مرد بابل', readAt: todayKey() },
  ];
  s.learning.lessonsDone = 12;

  s.notes = [
    { id: uid('n'), text: 'هدف اول: صندوق اضطراری سه‌ماهه تا پایان فصل.', at: todayKey() },
  ];
  s.chat = [{
    id: uid('c'), role: 'ai',
    text: 'سلام! من مربی مالی آفلاین تو هستم. وضعیت فعلی‌ات را تحلیل کردم: نرخ پس‌انداز و صندوق اضطراری نقطه ضعف اصلی تو است. از من بپرس «این ماه چه کاری انجام بدهم؟»',
    ts: Date.now(),
  }];
  s.decisions = [];

  // مسیر و نقشه راه
  const paths = discoverPaths(s);
  const best = paths[0];
  s.plan.pathId = best.id;
  s.plan.roadmap = buildRoadmap(s, best).roadmap;
  s.plan.missions = [];
  s.plan.businessStarted = false;

  // چند روز گذشته با میزان انجام متفاوت
  for (let i = 10; i >= 1; i--) {
    const key = addDays(todayKey(), -i);
    const day = ensureDay(s, key);
    const ratio = i > 6 ? 0.4 : i > 3 ? 0.7 : 0.9;
    const doneCount = Math.round(day.tasks.length * ratio);
    day.tasks.slice(0, doneCount).forEach((t) => { t.done = true; });
    s.gamification.tasksDone += doneCount;
    if (doneCount > 0) {
      s.streak.history.push(key);
      s.gamification.xp += doneCount * 10;
    }
  }
  s.streak.history = Array.from(new Set(s.streak.history)).sort();
  s.streak.current = 4;
  s.streak.best = 9;
  s.streak.lastActiveDay = addDays(todayKey(), -1);
  s.gamification.xp += 120;
  s.habits.forEach((h, idx) => {
    for (let i = 1; i <= 5 - idx; i++) h.history.push(addDays(todayKey(), -i));
    h.streak = h.history.length;
  });
  s.finance.snapshots = [];
  checkAchievements(s, 420);
  return s;
}

export function applyDemo() {
  const demo = buildDemoState();
  State.replace(demo);
  return demo;
}

export function currentMonthOfState() { return monthKeyOf(todayKey()); }
export function clampExport(n, a, b) { return clamp(n, a, b); }
