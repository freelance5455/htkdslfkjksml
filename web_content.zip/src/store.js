import { DIVISIONS, COMPETITIONS } from './config.js';
import { LEGACY_GALAXIES, LEGENDARY_DAMISTES, SPECIAL_ARENAS, VISUAL_ARENAS, CLUB_ARENA_SLOTS, BANKS, SPONSORS, PROMOTERS, PARTNERS, FIRMS, validateLegacyCatalog } from './legacy-catalog.js';
import { populateRosterCatalog, validateRosterCatalog } from './roster-catalog.js';
import { UNIVERSE_CATALOG } from './universe-catalog.js';

const CLUB_SEEDS = new Map(UNIVERSE_CATALOG.clubs.map(club => [club.id, club]));
const CLUB_MANAGERS = new Map(UNIVERSE_CATALOG.clubManagers.map(manager => [manager.clubId, manager]));

function createLegacyWorldState() {
  validateLegacyCatalog();
  return { catalogVersion: 3, galaxies: LEGACY_GALAXIES.map((x,index) => {
    const source = UNIVERSE_CATALOG.galaxies[index];
    return { ...x, id: source.id, damistes: [
      { id: `${source.id}-REP-H`, name: source.representant_h, gender: 'M', level: 50, form: 50, origin: source.nom, originGalaxyId: source.id },
      { id: `${source.id}-REP-F`, name: source.representant_f, gender: 'F', level: 50, form: 50, origin: source.nom, originGalaxyId: source.id }
    ] };
  }), legendaryDamistes: LEGENDARY_DAMISTES.map(x=>({...x})), specialArenas: SPECIAL_ARENAS.map(x=>({...x})), visualArenas: [...VISUAL_ARENAS], clubArenaSlots: CLUB_ARENA_SLOTS.map(x=>({...x})), banks: [...BANKS], sponsors: [...SPONSORS], promoters: [...PROMOTERS], partners: [...PARTNERS], firms: FIRMS.map(x=>({...x})) };
}


export function createInitialState() {
  const divisions = DIVISIONS.map(d => ({
    ...d,
    status: d.initial ? 'active' : 'announced',
    clubs: d.initial ? Array.from({ length: d.clubs }, (_, i) => makeClub(d.id, i + 1)) : []
  }));
  const initial = {
    schemaVersion: 1, season: 1, day: 1, phase: 'regular-season',
    career: { mode: null, manager: null, managerDraft: null, started: false, jobOffers: [], applications: [], history: [] },
    options: { aiDifficulty: 'Moyen' },
    divisions, competitions: COMPETITIONS.map(c => ({ ...c, season: null, status: 'pending', fixtures: [] })),
    calendar: { fixtures: [], processedFixtureIds: [], lastGeneratedSeason: null, lunarThursdays: [], officialCalendars: {}, currentDate: null, currentDay: 1, competitionEvents: [], scheduleValidation: null },
    expansion: { ligueC: { announced: true, activated: false, activationSeason: 3 }, ligueD: { announced: true, activated: false, activationSeason: 5 } },
    history: { seasons: [], awards: [], notices: [] },
    dameOr: { version: 1, seasons: {}, history: [] },
    management: { inbox: [], relations: { boardConfidence: 50, supporterSatisfaction: 50, mediaReputation: 50, playerMorale: {} }, press: { history: [] }, commercialOffers: [], commercialContracts: [], contractNegotiations: [], transferOffers: [], transferHistory: [], careerLog: [], offerMilestones: [], processedEvents: [] },
    world: {
      ...createLegacyWorldState(),
      clubCatalog: UNIVERSE_CATALOG.clubs.map(seed => makeClub(seed.divisionId, Number(seed.id.split('-').at(-1)))),
      clubManagers: UNIVERSE_CATALOG.clubManagers.map(manager => ({ ...manager })),
      selectionManagers: UNIVERSE_CATALOG.selectionManagers.map(manager => ({ ...manager }))
    },
    userClubId: 'super-league-01', userGalaxyId: null, userNationId: null, createdAt: new Date().toISOString()
  };
  populateRosterCatalog(initial);
  // Les 60 clubs sont conservés dans le registre, mais les Ligues C/D restent verrouillées.
  initial.world.clubCatalog = UNIVERSE_CATALOG.clubs.map(seed => {
    const division = initial.divisions.find(item => item.id === seed.divisionId);
    const club = makeClub(seed.divisionId, Number(seed.id.split('-').at(-1)));
    club.catalogStatus = division?.initial ? 'available' : 'locked';
    return club;
  });
  return initial;
}

function makeClub(divisionId, n) {
  const id = `${divisionId}-${String(n).padStart(2, '0')}`;
  const seed = CLUB_SEEDS.get(id);
  const managerProfile = CLUB_MANAGERS.get(id);
  const damistes = seed ? seed.damistes.map((player, slot) => ({
    id: `${id}-d${slot + 1}`, name: player.name, gender: player.gender,
    level: 50, form: 50, age: 22, potential: 75,
    origin: player.originGalaxy, originGalaxyId: player.originGalaxyId
  })) : [
    { id: `${id}-d1`, name: 'Damiste 1', gender: null, level: 50, form: 50 },
    { id: `${id}-d2`, name: 'Damiste 2', gender: null, level: 50, form: 50 }
  ];
  return {
    id, name: seed?.name || `${divisionId.toUpperCase()} ${String(n).padStart(2, '0')}`, divisionId,
    manager: null,
    managerProfile: managerProfile ? { ...managerProfile } : null,
    budget: 1000000, played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, points: 0,
    damistes
  };
}

export function validateState(s) {
  if (!s || s.schemaVersion !== 1 || !Array.isArray(s.divisions) || !Array.isArray(s.calendar?.fixtures)) throw new Error('État de carrière invalide');
  if (s.calendar.currentDay !== undefined && (!Number.isInteger(s.calendar.currentDay) || s.calendar.currentDay < 1)) throw new Error('Jour courant du calendrier invalide');
  if (s.calendar.scheduleValidation && !s.calendar.scheduleValidation.valid) throw new Error('Le calendrier contient un chevauchement de compétitions ou de rencontres de club');
  if (s.world && (s.world.galaxies?.length !== 24 || s.world.clubArenaSlots?.length !== 60 || s.world.legendaryDamistes?.length !== 24)) throw new Error('Catalogue galactique historique incomplet');
  if (s.world?.clubManagers && (s.world.clubManagers.length !== 60 || new Set(s.world.clubManagers.map(x => x.id)).size !== 60)) throw new Error('Registre des 60 managers de clubs invalide');
  if (s.world?.selectionManagers && (s.world.selectionManagers.length !== 24 || new Set(s.world.selectionManagers.map(x => x.id)).size !== 24)) throw new Error('Registre des 24 sélectionneurs invalide');
  if (s.world?.clubCatalog && (s.world.clubCatalog.length !== 60 || new Set(s.world.clubCatalog.map(x => x.id)).size !== 60)) throw new Error('Catalogue des 60 clubs invalide');
  const clubIds = s.divisions.flatMap(d => d.clubs.map(c => c.id));
  if (new Set(clubIds).size !== clubIds.length) throw new Error('Identifiant de club dupliqué');
  for (const d of s.divisions) for (const c of d.clubs) if (c.damistes?.length !== 2) throw new Error(`Le club ${c.id} doit posséder exactement deux damistes`);
  if (s.world?.rosterCatalogVersion) validateRosterCatalog(s);
  const ids = s.calendar.fixtures.map(f => f.id);
  if (new Set(ids).size !== ids.length) throw new Error('Identifiant de match dupliqué');
  return true;
}

export function saveState(state, storage = globalThis.localStorage) {
  validateState(state);
  storage?.setItem('cgd-v117-career', JSON.stringify(state));
}
export function loadState(storage = globalThis.localStorage) {
  const raw = storage?.getItem('cgd-v117-career');
  if (!raw) return null;
  const parsed = JSON.parse(raw);
  // Migration douce des sauvegardes du prototype antérieures au catalogue galactique.
  if (!parsed.world) parsed.world = createLegacyWorldState();
  else {
    // Migration des sauvegardes antérieures : compléter les légendaires et leurs galaxies d'origine.
    const current = new Map((parsed.world.legendaryDamistes || []).map(p => [p.name, p]));
    parsed.world.legendaryDamistes = LEGENDARY_DAMISTES.map(template => ({ ...template, ...(current.get(template.name) || {}), originGalaxy: template.originGalaxy, originGalaxyIndex: template.originGalaxyIndex }));
    parsed.world.galaxies = LEGACY_GALAXIES.map((template,index) => {
      const source = UNIVERSE_CATALOG.galaxies[index];
      const existing = (parsed.world.galaxies || []).find(g => g.name === template.name) || {};
      return { ...template, ...existing, id: source.id, damistes: [
        { id: `${source.id}-REP-H`, name: source.representant_h, gender: 'M', level: 50, form: 50, origin: source.nom, originGalaxyId: source.id },
        { id: `${source.id}-REP-F`, name: source.representant_f, gender: 'F', level: 50, form: 50, origin: source.nom, originGalaxyId: source.id }
      ] };
    });
    parsed.world.catalogVersion = 3;
  }
  parsed.career ??= { mode: null, manager: null, started: false, jobOffers: [], applications: [], history: [] };
  parsed.career.managerDraft ??= null; parsed.career.jobOffers ??= []; parsed.career.applications ??= []; parsed.career.history ??= [];
  parsed.options ??= { aiDifficulty: 'Moyen' }; parsed.options.aiDifficulty ??= 'Moyen';
  parsed.dameOr ??= { version: 1, seasons: {}, history: [] };
  parsed.dameOr.version ??= 1; parsed.dameOr.seasons ??= {}; parsed.dameOr.history ??= [];
  parsed.management ??= { inbox: [], relations: { boardConfidence: 50, supporterSatisfaction: 50, mediaReputation: 50, playerMorale: {} }, press: { history: [] }, commercialOffers: [], commercialContracts: [], contractNegotiations: [], transferOffers: [], transferHistory: [], careerLog: [], offerMilestones: [], processedEvents: [] };
  parsed.management.inbox ??= []; parsed.management.relations ??= { boardConfidence: 50, supporterSatisfaction: 50, mediaReputation: 50, playerMorale: {} };
  parsed.management.relations.playerMorale ??= {}; parsed.management.press ??= { history: [] }; parsed.management.press.history ??= [];
  parsed.management.commercialOffers ??= []; parsed.management.commercialContracts ??= []; parsed.management.contractNegotiations ??= []; parsed.management.transferOffers ??= []; parsed.management.transferHistory ??= []; parsed.management.careerLog ??= []; parsed.management.offerMilestones ??= []; parsed.management.processedEvents ??= [];
  for (const division of parsed.divisions) for (const club of division.clubs) club.payrollCommitment ??= 0;
  populateRosterCatalog(parsed);
  parsed.world.clubManagers ??= UNIVERSE_CATALOG.clubManagers.map(manager => ({ ...manager }));
  parsed.world.selectionManagers ??= UNIVERSE_CATALOG.selectionManagers.map(manager => ({ ...manager }));
  parsed.world.clubCatalog ??= UNIVERSE_CATALOG.clubs.map(seed => {
    const club = makeClub(seed.divisionId, Number(seed.id.split('-').at(-1)));
    club.catalogStatus = ['super-league','ligue-a','ligue-b'].includes(seed.divisionId) ? 'available' : 'locked';
    return club;
  });
  parsed.userGalaxyId ??= null;
  parsed.userNationId ??= null;
  parsed.calendar.lunarThursdays ??= [];
  parsed.calendar.officialCalendars ??= {};
  parsed.calendar.currentDate ??= null;
  parsed.calendar.currentDay ??= 1;
  parsed.calendar.competitionEvents ??= [];
  parsed.calendar.scheduleValidation ??= null;
  // Migration rétrocompatible : ajouter la Coupe Fédéral sans remplacer les sept compétitions historiques.
  const existingCompetitions = new Map((parsed.competitions || []).map(c => [c.id, c]));
  parsed.competitions = COMPETITIONS.map(template => ({ ...template, ...(existingCompetitions.get(template.id) || {}), id: template.id, name: template.name, authority: template.authority, calendarEngineReady: template.calendarEngineReady }));
  validateState(parsed); return parsed;
}
