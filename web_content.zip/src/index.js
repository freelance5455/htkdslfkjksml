/**
 * /<ACCESS>/              hub
 * /<ACCESS>/regex[/]      UI
 * /<ACCESS>/regex/api/... API
 * /<ACCESS>/api/...       API alias
 * /<ACCESS>/api/ai/...   AI assistant (admin only)
 */

import { withSecurity, html, json, sameText } from './security.js';
import { handleRegex, isAdmin, ensureRegexSchema } from './regex.js';
import { handleDominant } from './dominant.js';
import { handleAi } from './ai.js';
import { handleServices } from './services.js';

function hubPage(code) {
  return `<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Regex</title>
<style>
body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0a090b;color:#f3ecea;font:15px system-ui,sans-serif}
a{color:#e5484d;text-decoration:none;font-weight:600}
a:hover{text-decoration:underline}
.card{padding:28px 32px;border:1px solid rgba(229,72,77,.25);border-radius:16px;background:#140c0e}
</style></head><body>
<div class="card">
<p><a href="/${code}/regex/">Open Regex Manager →</a></p>
<p style="opacity:.6;font-size:13px;margin-top:12px">AI assistant: sign in to the Regex Manager</p>
</div>
</body></html>`;
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

function assetPathFor(name) {
  return name === 'index.html' ? '/' : '/' + name;
}

function apiRequest(request, apiParts) {
  const url = new URL(request.url);
  url.pathname = `/api/${apiParts.join('/')}`;
  return new Request(url.toString(), request);
}

function mimeFor(name) {
  const dot = name.lastIndexOf('.');
  return MIME[dot >= 0 ? name.slice(dot).toLowerCase() : ''] || 'application/octet-stream';
}

async function loadAsset(env, request, name) {
  if (!env.ASSETS) {
    return { error: 'ASSETS binding missing' };
  }
  const target = new URL(request.url);
  target.pathname = assetPathFor(name);
  target.search = '';
  target.hash = '';
  const res = await env.ASSETS.fetch(new Request(target.toString(), { method: 'GET' }));
  if (res.status === 200) {
    return { res, type: res.headers.get('Content-Type') || mimeFor(name) };
  }
  return { error: 'not found', status: res.status, path: target.pathname };
}

export default {
  async fetch(request, env) {
    try {
      if (!env.DB) return json({ error: 'D1 DB missing' }, 500);
      await ensureRegexSchema(env.DB);

      const url = new URL(request.url);
      const segs = url.pathname.split('/').filter(Boolean);
      const access = String(env.ACCESS_CODE || '');

      if (!access || access.length < 8) {
        return json({ error: 'ACCESS_CODE missing' }, 500);
      }
      if (!segs.length || !sameText(segs[0], access)) {
        return new Response('Not Found', { status: 404 });
      }

      const rest = segs.slice(1);
      const base = `/${access}`;

      // hub
      if (rest.length === 0) {
        return html(hubPage(access));
      }

      // API under /ACCESS/api/...
      if (rest[0] === 'api') {
        const apiRest = rest.slice(1);
        if (apiRest[0] === 'ai') {
          const admin = await isAdmin(request, env);
          return withSecurity(await handleAi(request, env, { admin, rest: apiRest.slice(1) }));
        }
        if (apiRest[0] === 'services') {
          const admin = await isAdmin(request, env);
          return withSecurity(await handleServices(request, env, { admin, rest: apiRest.slice(1) }));
        }
        if (apiRest[0] === 'dominant') {
          const admin = await isAdmin(request, env);
          return withSecurity(await handleDominant(request, env, { admin, base }));
        }
        // forward other api to regex handler
        return withSecurity(await handleRegex(apiRequest(request, apiRest), env));
      }

      // /ACCESS/regex/...
      if (rest[0] === 'regex') {
        const after = rest.slice(1);

        // /regex/api/...
        if (after[0] === 'api') {
          if (after[1] === 'ai') {
            const admin = await isAdmin(request, env);
            return withSecurity(await handleAi(request, env, { admin, rest: after.slice(2) }));
          }
          if (after[1] === 'services') {
            const admin = await isAdmin(request, env);
            return withSecurity(await handleServices(request, env, { admin, rest: after.slice(2) }));
          }
          if (after[1] === 'dominant') {
            const admin = await isAdmin(request, env);
            return withSecurity(await handleDominant(request, env, { admin, base }));
          }
          return withSecurity(await handleRegex(apiRequest(request, after.slice(1)), env));
        }

        // static UI
        let name = after.join('/') || 'index.html';
        if (name.endsWith('/')) name += 'index.html';
        if (!name.includes('.')) name = 'index.html';
        // only allow files from public root
        name = name.replace(/^\/+/, '');
        if (name.includes('..')) return new Response('Bad Request', { status: 400 });

        const { res, type, error, status } = await loadAsset(env, request, name);
        if (error) {
          if (name !== 'index.html') {
            const again = await loadAsset(env, request, 'index.html');
            if (again.res) {
              let htmlBody = await again.res.text();
              htmlBody = htmlBody.replaceAll('__BASE__', `${base}/regex/`);
              return withSecurity(
                new Response(htmlBody, {
                  status: 200,
                  headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' },
                })
              );
            }
          }
          return new Response('Not Found', { status: status || 404 });
        }

        let ct = type;
        if (name === 'index.html' || name.endsWith('.html')) {
          let htmlBody = await res.text();
          htmlBody = htmlBody.replaceAll('__BASE__', `${base}/regex/`);
          return withSecurity(
            new Response(htmlBody, {
              status: 200,
              headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' },
            })
          );
        }

        const headers = new Headers(res.headers);
        headers.set('Content-Type', ct);
        headers.set('Cache-Control', 'no-cache');
        return withSecurity(new Response(res.body, { status: 200, headers }));
      }

      return new Response('Not Found', { status: 404 });
    } catch (e) {
      return json({ error: 'internal', message: String(e?.message || e) }, 500);
    }
  },
};
