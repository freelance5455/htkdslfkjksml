
/* =====================================================================
   GAME STATE
   ===================================================================== */
const G={scene:'boot',now:0,cam:{x:0,zoom:1,zt:1,shake:0},hitstop:0,ts:1,paused:false,lock:null,len:3000,map:null,stage:null,stageIdx:0,
  waves:[],stats:null,combo:0,comboT:0,banner:null,flashA:0,flashCol:'#fff',redA:0,clearT:0,defeatT:0,revives:0,bossRef:null,phaseTxt:null,dark:0,goHint:0,decor:[],fg:[],bossDown:false,over:false};
let P=null;
const E=[],PR=[],FX=[],PK=[],FL=[],BR=[];
const PT=[];for(let i=0;i<520;i++)PT.push({on:0,x:0,y:0,vx:0,vy:0,life:0,max:1,size:2,color:'#fff',g:0,add:1});
let ptI=0;
const pmul=()=>[.35,.65,1][S.gfx]||1;
function spark(x,y,vx,vy,life,size,color,g,add){const p=PT[ptI=(ptI+1)%PT.length];p.on=1;p.x=x;p.y=y;p.vx=vx;p.vy=vy;p.life=p.max=life;p.size=size;p.color=color;p.g=g||0;p.add=add==null?1:add}
function burst(x,y,n,o){o=o||{};n=Math.ceil(n*pmul());for(let i=0;i<n;i++){const a=o.a!=null?o.a+rnd(-(o.sp||3.14),(o.sp||3.14)):rnd(0,6.283),s=rnd(o.s0||60,o.s1||260);
  spark(x+rnd(-(o.jx||0),o.jx||0),y+rnd(-(o.jy||0),o.jy||0),Math.cos(a)*s,Math.sin(a)*s,rnd(o.l0||.25,o.l1||.6),rnd(o.z0||2,o.z1||4.5),o.c||pick(['#ff5a3a','#ff9a4a','#ffd08a']),o.g==null?500:o.g,o.add==null?1:o.add)}}
function floater(x,y,text,col,big){FL.push({x,y,vy:-70,t:0,text:String(text),col,big:!!big})}
function shake(a){G.cam.shake=Math.max(G.cam.shake,a)}
function vib(ms){if(S.vib&&navigator.vibrate)try{navigator.vibrate(ms)}catch(e){}}
const rectO=(a0,b0,a1,b1,c0,d0,c1,d1)=>a0<c1&&a1>c0&&b0<d1&&b1>d0;
const pRect=()=>[P.x-18,P.y-130,P.x+18,P.y];

/* ---------- input (keyboard + touch berbagi state yang sama) ---------- */
const IN={x:0,held:{},p:{}};
function press(n){IN.p[n]=G.now;IN.held[n]=true}
function release(n){IN.held[n]=false}
function take(n){if(G.now-(IN.p[n]||-9)<.16){IN.p[n]=-9;return true}return false}

/* ---------- stats & level ---------- */
const expNeed=lv=>Math.floor(50*Math.pow(lv,1.45));
function pStats(cid,lv){const c=DATA.chars[cid],b=c.base,g=c.grow;return {hp:Math.round(b.hp+g.hp*(lv-1)),mp:Math.round(b.mp+g.mp*(lv-1)),atk:b.atk+g.atk*(lv-1),def:b.def+g.def*(lv-1),crit:b.crit+g.crit*(lv-1),cdmg:b.cdmg,spd:b.spd}}
function makePlayer(cid){
  const c=DATA.chars[cid],cs=SV.chars[cid],st=pStats(cid,cs.lv);
  P={cid,c,x:120,y:GROUND,vx:0,vy:0,face:1,onGround:true,state:'idle',stateT:0,anim:0,lv:cs.lv,maxhp:st.hp,hp:st.hp,maxmp:st.mp,mp:st.mp,atk:st.atk,def:st.def,crit:st.crit,cdmg:st.cdmg,spd:st.spd,
    rage:0,combo:0,comboT:0,queued:false,cur:null,idx:0,fired:false,hitSet:new Set(),inv:0,flash:0,slowT:0,hurtT:0,dead:false,ghosts:[],dashT:0,ultT:0,ultStage:0,
    cd:{s1:0,s2:0,s3:0,dash:0,ult:0,pot:0}};
}
function applyLevelStats(healFrac){
  const cs=SV.chars[P.cid],st=pStats(P.cid,cs.lv);P.lv=cs.lv;P.maxhp=st.hp;P.maxmp=st.mp;P.atk=st.atk;P.def=st.def;P.crit=st.crit;
  P.hp=Math.min(P.maxhp,P.hp+P.maxhp*healFrac);P.mp=Math.min(P.maxmp,P.mp+P.maxmp*healFrac);
}
function gainExp(n){
  const cs=SV.chars[P.cid];cs.exp+=n;G.stats.exp+=n;let up=false;
  while(cs.lv<MAXLV&&cs.exp>=expNeed(cs.lv)){cs.exp-=expNeed(cs.lv);cs.lv++;up=true;
    const u=P.c.unlock,names=[['s1',0],['s2',1],['s3',2]];
    names.forEach(([k,i])=>{if(u[k]===cs.lv)toast(T('newskill')+' '+P.c.skills[i].name)});
    if(u.ult===cs.lv)toast(T('newskill')+' '+P.c.ultName);}
  if(cs.lv>=MAXLV)cs.exp=0;
  if(up){applyLevelStats(.4);AU.play('lvl');floater(P.x,P.y-150,T('lvup'),'#ffd23a',true);
    burst(P.x,P.y-60,34,{c:'#ffd23a',s0:80,s1:340,g:-60,l0:.5,l1:1.1});G.flashA=.35;G.flashCol='#ffd23a';persist()}
}
const skillUnlocked=k=>P.lv>=P.c.unlock[k];

/* ---------- toast ---------- */
let toastT=0;
function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('on');clearTimeout(toastT);toastT=setTimeout(()=>el.classList.remove('on'),2600)}

/* =====================================================================
   PLAYER
   ===================================================================== */
function enemyAlive(){return E.some(e=>!e.dead)}
function startAtk(def,idx,skill){
  const p=P;p.state='atk';p.stateT=0;p.cur=def;p.idx=idx;p.fired=false;p.queued=false;p.hitSet=new Set();p.skill=skill||null;
  if(!skill&&idx>=0)p.combo=idx;
  if(def.mp){p.mp-=def.mp}
  if(def.lunge&&p.onGround)p.vx=p.face*def.lunge;
}
function tryActions(){
  const p=P,c=p.c;
  if(take('potHp'))usePotion('hp');
  if(take('potMp'))usePotion('mp');
  if(take('dash')&&p.cd.dash<=0){startDash();return true}
  if(take('ult')&&p.rage>=100&&skillUnlocked('ult')){startUlt();return true}
  const sk=[['s1',0,'heavy'],['s2',1,'rising'],['s3',2,'wave']];
  for(const [k,i,id] of sk){
    if(take(k)){
      if(!skillUnlocked(k)){toast('Lv.'+c.unlock[k]+' — '+c.skills[i].name);continue}
      const sd=c.skills[i];
      if(p.cd[k]>0)continue;
      if(p.mp<sd.mp){toast('MP!');continue}
      p.cd[k]=sd.cd;startAtk(SKILLDEF[id],-1,id);return true;
    }
  }
  if(take('atk')){
    if(!p.onGround)startAtk(c.air,-1);
    else{const idx=p.comboT>0?(p.combo+1)%4:0;startAtk(c.combo[idx],idx)}
    return true;
  }
  return false;
}
const SKILLDEF={
  heavy:{dur:.62,hit:[.22,.32],dmg:2.7,w:158,h:150,kb:440,stun:.55,lunge:90,a0:-2.1,a1:1.5,r:135,sfx:'heavy',shake:9,hs:.11,heavy:1,mp:12,armor:1,glow:1},
  rising:{dur:.52,hit:[.1,.24],dmg:2.3,w:118,h:160,kb:70,stun:.6,launch:560,lunge:60,a0:.8,a1:-2.2,r:118,sfx:'heavy',shake:5,hs:.08,mp:16,hop:-640,armor:0},
  wave:{dur:.5,hit:[.16,.26],dmg:.9,w:100,h:120,kb:120,stun:.25,lunge:0,a0:-1.5,a1:1.2,r:100,sfx:'slash',shake:3,hs:.04,mp:22,proj:{sp:560,r:34,hh:52,life:1.15,dmg:2.0,col:'#ff2b3a',kind:'crescent',kb:260,stun:.4}}
};
function startDash(){
  const p=P;p.state='dash';p.stateT=0;p.cd.dash=.85;p.inv=Math.max(p.inv,.3);p.dashT=.24;
  const mx=Math.abs(IN.x)>.3?sgn(IN.x):p.face;p.face=mx;p.vx=mx*720;p.vy=0;p.ghosts.length=0;
  AU.play('dash');burst(p.x,p.y-10,10,{c:'#5a0b14',s0:60,s1:220,g:0,add:0,z1:6});
}
function usePotion(k){
  const p=P;if(p.cd.pot>0||SV.pot[k]<=0||p.dead)return;
  if(k==='hp'&&p.hp>=p.maxhp)return;if(k==='mp'&&p.mp>=p.maxmp)return;
  SV.pot[k]--;p.cd.pot=6;AU.play('drink');
  if(k==='hp'){const h=Math.round(p.maxhp*DATA.items.hp.heal);p.hp=Math.min(p.maxhp,p.hp+h);floater(p.x,p.y-140,'+'+h,'#5dff8a');burst(p.x,p.y-60,16,{c:'#5dff8a',s0:30,s1:140,g:-120,l1:.9})}
  else{const m=Math.round(p.maxmp*DATA.items.mp.heal);p.mp=Math.min(p.maxmp,p.mp+m);floater(p.x,p.y-140,'+'+m,'#66aaff');burst(p.x,p.y-60,16,{c:'#66aaff',s0:30,s1:140,g:-120,l1:.9})}
}
function startUlt(){
  const p=P;p.state='ult';p.stateT=0;p.rage=0;p.inv=2.4;p.vx=0;p.vy=0;p.ultStage=0;p.cd.ult=1;
  AU.play('ult');G.cam.zt=1.3;G.dark=.55;vib(60);
}
function playerHitCheck(def){
  const p=P,x0=p.face>0?p.x-14:p.x-def.w,x1=p.face>0?p.x+def.w:p.x+14,y0=p.y-def.h,y1=p.y+10;
  for(const e of E){
    if(e.dead||p.hitSet.has(e))continue;
    if(rectO(x0,y0,x1,y1,e.x-e.def.bw/2,e.y-e.def.bh,e.x+e.def.bw/2,e.y)){
      p.hitSet.add(e);
      hitEnemy(e,def.dmg,{kb:def.kb,stun:def.stun,launch:def.launch,dir:p.face,hs:def.hs,shake:def.shake,heavy:def.heavy});
    }
  }
  for(const b of BR){
    if(b.broken||p.hitSet.has(b))continue;
    if(rectO(x0,y0,x1,y1,b.x-22,GROUND-56,b.x+22,GROUND)){p.hitSet.add(b);breakBarrel(b)}
  }
}
function spawnFx(def){
  if(framesReady())return;   // busur tebasan sudah tergambar di frame animasi
  const p=P;FX.push({t:'slash',x:p.x,y:p.y-70,face:p.face,r:def.r,a0:def.a0,a1:def.a1,life:(def.heavy||def.glow)?0.3:0.2,age:0,col:def.heavy||def.glow?'#ff2233':'#ff5a4a',w:def.heavy?26:16});
}
function updPlayer(dt){
  const p=P;p.anim+=dt;p.inv-=dt;p.flash-=dt;p.slowT-=dt;p.comboT-=dt;p.hurtT-=dt;
  for(const k in p.cd)p.cd[k]=Math.max(0,p.cd[k]-dt);
  if(!p.dead)p.mp=Math.min(p.maxmp,p.mp+(3+p.lv*.06)*dt);
  if(p.dead){p.stateT+=dt;p.vx*=Math.pow(.02,dt);pPhysics(dt);return}
  const sp=p.spd*(p.slowT>0?.55:1);
  switch(p.state){
    case 'idle':case 'run':case 'jump':{
      const mx=IN.x;
      if(Math.abs(mx)>.15){p.vx=lerp(p.vx,mx*sp,Math.min(1,dt*18));p.face=sgn(mx)}else p.vx=lerp(p.vx,0,Math.min(1,dt*16));
      if(take('jump')&&p.onGround){p.vy=-730;p.onGround=false;AU.play('jump');burst(p.x,p.y,6,{c:'#8a6a6a',s0:30,s1:120,g:200,a:-1.57,sp:1.2,add:0})}
      if(IN.held.up&&p.onGround&&IN.upEdge){p.vy=-730;p.onGround=false;IN.upEdge=false;AU.play('jump')}
      p.state=!p.onGround?'jump':(Math.abs(p.vx)>25?'run':'idle');
      tryActions();
      break;}
    case 'atk':{
      const d=p.cur;p.stateT+=dt;
      if(p.onGround&&d.lunge){const k=1-p.stateT/(d.dur*.65);p.vx=p.face*d.lunge*Math.max(0,k)}
      else if(!p.onGround)p.vx*=.985;
      if(!p.fired&&p.stateT>=d.hit[0]){
        p.fired=true;AU.play(d.sfx);spawnFx(d);
        if(d.hop){p.vy=d.hop;p.onGround=false}
        if(d.proj){const q=d.proj;PR.push({own:'p',kind:q.kind,x:p.x+p.face*40,y:p.y-52,vx:p.face*q.sp,vy:0,g:0,r:q.r,hh:q.hh,life:q.life,mult:q.dmg,col:q.col,pierce:1,hit:new Set(),kb:q.kb,stun:q.stun,dir:p.face,rot:0});AU.play('magic')}
        if(d.dmg>=2)burst(p.x+p.face*60,p.y-60,10,{c:'#ff3344',s0:80,s1:300,g:0,a:p.face>0?0:3.14,sp:.9,l1:.4});
      }
      if(p.fired&&p.stateT<=d.hit[1]+dt)playerHitCheck(d);
      // chain / cancel
      if(p.stateT>=d.hit[0]*.7&&take('atk'))p.queued=true;
      if(p.stateT>=d.hit[1]+.02){
        if(IN.p.dash>G.now-.16&&p.cd.dash<=0&&take('dash')){startDash();break}
        if(p.skill===null||p.skill===undefined){for(const k of ['s1','s2','s3']){if(IN.p[k]>G.now-.16){const i={s1:0,s2:1,s3:2}[k];if(skillUnlocked(k)&&p.cd[k]<=0&&p.mp>=p.c.skills[i].mp){take(k);p.cd[k]=p.c.skills[i].cd;startAtk(SKILLDEF[['heavy','rising','wave'][i]],-1,['heavy','rising','wave'][i]);return}}}}
      }
      if(p.stateT>=d.dur){
        if(p.queued&&!p.skill&&p.idx>=0&&p.idx<3&&p.onGround){startAtk(p.c.combo[p.idx+1],p.idx+1)}
        else{p.state=p.onGround?'idle':'jump';p.comboT=p.skill?0:.42;p.cur=null;p.skill=null;if(p.onGround)p.vx*=.3}
      }
      break;}
    case 'dash':{
      p.stateT+=dt;p.dashT-=dt;
      if(p.dashT<=0){                                   // fase pemulihan (frame 10-13 Dash), bisa dibatalkan
        p.vx*=Math.pow(.0005,dt);
        if(tryActions())break;
        if(take('jump')&&p.onGround){p.vy=-730;p.onGround=false;p.state='jump';AU.play('jump');break}
        if(Math.abs(IN.x)>.3||p.stateT>=.38||!p.onGround){p.state=p.onGround?(Math.abs(IN.x)>.3?'run':'idle'):'jump';if(Math.abs(IN.x)>.3)p.face=sgn(IN.x)}
      }
      break;}
    case 'hurt':{
      p.stateT+=dt;p.vx*=Math.pow(.02,dt);
      if(p.stateT>=.28)p.state=p.onGround?'idle':'jump';
      break;}
    case 'ult':updUlt(dt);break;
  }
  for(const g of p.ghosts)g.a-=dt*3.2;
  while(p.ghosts.length&&p.ghosts[0].a<=0)p.ghosts.shift();
  pPhysics(dt);
}
function updUlt(dt){
  const p=P;p.stateT+=dt;
  if(p.stateT<.55){
    if(Math.random()<.9)spark(p.x+rnd(-140,140),p.y-rnd(0,150),0,0,.35,rnd(2,4),'#ff2233',0,1);
    if(pmul()>.5&&Math.random()<.5){const a=rnd(0,6.28),d=rnd(90,180);spark(p.x+Math.cos(a)*d,p.y-70+Math.sin(a)*d,-Math.cos(a)*d*2.6,-Math.sin(a)*d*2.6,.4,rnd(2,4),'#ff5566',0,1)}
  }else if(p.ultStage===0){
    p.ultStage=1;G.flashA=.9;G.flashCol='#ffffff';shake(20);AU.play('boom');vib(120);
    FX.push({t:'ultslash',x:p.x,y:p.y-70,face:p.face,life:.55,age:0});
    FX.push({t:'ring',x:p.x,y:p.y-10,r0:20,r1:520,life:.5,age:0,col:'#ff2233',w:14});
    burst(p.x,p.y-60,60,{c:'#ff2233',s0:120,s1:620,g:0,l0:.3,l1:.8,z1:6});
    G.ultHits=0;p.ultNext=0;
    ultStrike(6.0,true);
  }else{
    p.ultNext+=dt;
    if(p.ultStage<4&&p.ultNext>=.13){p.ultNext=0;p.ultStage++;ultStrike(1.3,false);shake(8);AU.play('hit')}
  }
  if(p.stateT>=1.2){p.state='idle';G.cam.zt=1;G.dark=0;p.cur=null}
}
function ultStrike(mult,first){
  const p=P;
  for(const e of E){if(e.dead)continue;if(Math.abs(e.x-p.x)<560){
    hitEnemy(e,mult,{kb:first?520:60,stun:first?1.0:.6,launch:first?420:0,dir:sgn(e.x-p.x)||p.face,hs:first?.18:.05,shake:first?14:5,heavy:1,noRage:1});
  }}
  for(const b of BR){if(!b.broken&&Math.abs(b.x-p.x)<560)breakBarrel(b)}
}
function pPhysics(dt){
  const p=P;
  if(p.state!=='dash'&&p.state!=='ult')p.vy+=GRAV*dt;
  p.x+=p.vx*dt;p.y+=p.vy*dt;
  if(p.y>=GROUND){if(!p.onGround&&p.vy>300){burst(p.x,GROUND,5,{c:'#7a5a5a',s0:20,s1:110,g:100,a:-1.57,sp:1.4,add:0})}p.y=GROUND;p.vy=0;p.onGround=true}else p.onGround=false;
  const lo=G.lock?G.lock.min+26:26,hi=G.lock?G.lock.max-26:G.len-26;
  p.x=clamp(p.x,lo,hi);
}
function hurtPlayer(src,mult,o){
  o=o||{};const p=P;if(p.dead||p.inv>0||p.state==='ult')return false;
  let d=src.atk*mult*(100/(100+p.def))*rnd(.92,1.08);d=Math.max(1,Math.round(d));
  p.hp-=d;p.inv=.6;p.flash=.14;G.stats.hits++;G.stats.dmgTaken+=d;p.rage=Math.min(100,p.rage+4);
  const dir=sgn(p.x-src.x);
  const armored=p.cur&&p.cur.armor&&p.state==='atk';
  if(!armored){p.state='hurt';p.stateT=0;p.cur=null;p.skill=null;p.vx=dir*(o.kb||220);if(!p.onGround)p.vy=Math.min(p.vy,-120)}
  else p.vx+=dir*60;
  if(o.slow)p.slowT=o.slow;
  G.combo=0;G.comboT=0;G.redA=.5;shake(6);vib(40);AU.play('hurt');G.hitstop=Math.max(G.hitstop,.05);
  floater(p.x,p.y-135,d,'#ff5a5a',false);
  burst(p.x,p.y-70,10,{c:'#ff3a3a',s0:60,s1:220,l1:.4});
  if(p.hp<=0){p.hp=0;p.dead=true;p.state='dead';p.stateT=0;p.vx=dir*260;p.vy=-360;G.defeatT=0;G.ts=.4;AU.play('boom');vib(200);AU.stop()}
  return true;
}

/* =====================================================================
   ENEMIES
   ===================================================================== */
function spawnEnemy(type,x,o){
  o=o||{};const d=DATA.enemies[type],lv=o.lvl||1;
  const sc=(v,k)=>v*(1+k*(lv-1));
  const e={type,def:d,x,y:GROUND,vx:0,vy:0,kbx:0,face:-1,hp:0,maxhp:0,atk:sc(d.atk,.16),def:0,lvl:lv,state:'move',t:0,windT:0,stun:0,flash:0,atkCd:rnd(.4,1.2),cds:{},curAtk:null,dead:false,deathT:0,anim:rnd(0,6),
    onGround:true,fy:d.fly?d.hover:0,alpha:1,inv:0,wave:o.wave||null,elite:!!o.elite,minion:!!o.minion,hitT:0,gh:[],phase:1,spdMul:1,pref:(d.pref||60)*rnd(.9,1.35),hit:false,tgt:null,forceNext:null,spinT:0,mult:1};
  e.def=d;e.dfn=sc(d.def,.1);
  e.maxhp=Math.round(sc(d.hp,.24)*(o.elite?1.9:1));e.hp=e.maxhp;
  if(o.elite){e.atk*=1.25}
  if(d.fly)e.y=GROUND-e.fy;
  E.push(e);return e;
}
/* kompat: e.def dipakai sebagai data; nilai defense numerik di e.dfn */
function hitEnemy(e,mult,o){
  if(e.dead||e.inv>0)return false;
  const crit=Math.random()<P.crit;
  let d=P.atk*mult*(100/(100+e.dfn))*rnd(.92,1.08);if(crit)d*=P.cdmg;d=Math.max(1,Math.round(d));
  e.hp-=d;e.flash=.1;e.hitT=e.def.armor?.14:.28;G.stats.dmg=(G.stats.dmg||0)+d;
  if(o.heavy||crit)G.cam.zoom=Math.min(1.07,G.cam.zoom+(o.heavy?.022:.012));
  const dir=o.dir||P.face,d0=e.def;
  if(!d0.armor){
    e.stun=Math.max(e.stun,o.stun||.25);e.kbx=dir*(o.kb||120);
    if(o.launch&&!d0.fly){e.vy=-o.launch;e.y-=3;e.onGround=false}
    if(e.state!=='move'&&e.state!=='intro'){e.state='move';e.curAtk=null;e.t=0;e.atkCd=Math.max(e.atkCd,.5);e.alpha=1}
  }else{e.kbx=dir*(o.kb||120)*.1}
  const cy=e.y-d0.bh*.6;
  floater(e.x+rnd(-12,12),e.y-d0.bh-6,d,crit?'#ffd23a':'#ffffff',crit);
  burst(e.x-dir*6,cy,crit?16:9,{c:crit?'#ffd23a':undefined,s0:80,s1:crit?380:280,a:dir>0?0:3.14,sp:1.3,l1:.4,z1:crit?5:3.5});
  if(crit)burst(e.x,cy,4,{c:'#fff',s0:20,s1:80,g:0,l1:.2});
  G.hitstop=Math.max(G.hitstop,(o.hs||.04)+(crit?.03:0));shake(o.shake||2);
  AU.play(crit?'crit':(o.heavy?'heavy':'hit'));
  if(!o.noRage)P.rage=Math.min(100,P.rage+(o.heavy?6:3));
  P.mp=Math.min(P.maxmp,P.mp+1.2);
  G.combo++;G.comboT=2.4;if(G.combo>G.stats.maxCombo)G.stats.maxCombo=G.combo;
  if(d0.boss&&e.phase===1&&e.hp>0&&e.hp<=e.maxhp*.5)startPhase2(e);
  if(e.hp<=0)killEnemy(e);
  return true;
}
function startPhase2(e){
  e.state='phase';e.t=0;e.inv=2.0;e.curAtk=null;e.alpha=1;
  G.phaseTxt={t:0,text:'PHASE 2'};G.flashA=.6;G.flashCol='#ff1a1a';shake(18);AU.play('roar');vib(150);
  burst(e.x,e.y-e.def.bh*.5,60,{c:'#2a0a10',s0:120,s1:520,g:700,l0:.6,l1:1.3,z0:3,z1:8,add:0});
  burst(e.x,e.y-e.def.bh*.5,50,{c:'#ff2233',s0:100,s1:460,g:200,l1:1});
  FX.push({t:'ring',x:e.x,y:e.y-20,r0:20,r1:600,life:.8,age:0,col:'#ff2233',w:18});
  // bersihkan proyektil musuh
  for(let i=PR.length-1;i>=0;i--)if(PR[i].own==='e')PR.splice(i,1);
}
function killEnemy(e){
  e.dead=true;e.deathT=0;e.state='dead';e.alpha=1;G.stats.kills++;
  const ex=Math.round(e.def.exp*(1+.25*(e.lvl-1))*(e.minion?.25:1)*(e.elite?2:1));
  gainExp(ex);
  const gv=rndi(e.def.gold[0],e.def.gold[1])*(e.elite?2:1)*(e.minion?0:1),n=e.def.boss?14:Math.min(4,1+(gv/6>>0));
  if(gv>0)for(let i=0;i<n;i++)PK.push({k:'gold',x:e.x,y:e.y-40,vx:rnd(-120,120),vy:rnd(-420,-200),val:Math.max(1,Math.round(gv/n)),t:0});
  if(!e.minion&&Math.random()<(e.elite||e.def.boss?.9:.09))PK.push({k:Math.random()<.65?'hp':'mp',x:e.x,y:e.y-40,vx:rnd(-60,60),vy:-300,val:1,t:0});
  if(!e.minion&&P.hp>0)P.hp=Math.min(P.maxhp,P.hp+P.maxhp*.02);
  burst(e.x,e.y-e.def.bh*.5,e.def.boss?70:22,{c:e.def.boss?'#ff2233':undefined,s0:80,s1:e.def.boss?520:320,l1:.7,z1:5});
  G.hitstop=Math.max(G.hitstop,e.def.boss?.25:.07);AU.play(e.def.boss?'boom':'hit');
  if(e.def.boss){G.bossDown=true;G.ts=.3;G.clearT=.001;shake(22);G.flashA=.7;G.flashCol='#ffffff';AU.stop()}
}
function breakBarrel(b){
  b.broken=true;AU.play('break');burst(b.x,GROUND-24,14,{c:'#8a5a2a',s0:60,s1:240,g:700,a:-1.57,sp:1.6,add:0,z1:5});
  if(Math.random()<.7)PK.push({k:'gold',x:b.x,y:GROUND-30,vx:rnd(-80,80),vy:-300,val:rndi(2,6),t:0});
  if(Math.random()<.15)PK.push({k:Math.random()<.6?'hp':'mp',x:b.x,y:GROUND-30,vx:rnd(-60,60),vy:-320,val:1,t:0});
}
function eBounds(){return G.lock?[G.lock.min-115,G.lock.max+115]:[20,G.len-20]}
function chooseAttack(e,dist){
  if(e.forceNext){const a=e.def.attacks.find(x=>x.id===e.forceNext);e.forceNext=null;if(a)return a}
  let tot=0;const c=[];
  for(const a of e.def.attacks){
    if(!a.wt)continue;if(a.ph&&e.phase<a.ph)continue;if((e.cds[a.id]||0)>0)continue;
    if(dist<(a.rmin||0)||dist>a.r)continue;
    c.push(a);tot+=a.wt;
  }
  if(!c.length)return null;let r=Math.random()*tot;for(const a of c){r-=a.wt;if(r<=0)return a}return c[0];
}
function startAttack(e,a){
  const k=e.def.boss&&e.phase===2?.78:1;
  e.curAtk=a;e.cds[a.id]=a.cd*(e.def.boss&&e.phase===2?.75:1);e.state='wind';e.t=0;e.hit=false;e.windT=a.wind*k;e.vx=0;
  if(a.kind==='aoe'){e.tgt={x:P.x};FX.push({t:'tele',x:P.x,r:a.rad,life:e.windT+.28,age:0})}
  if(a.kind==='dive'){e.tgt={x:P.x}}
  if(a.kind==='spin'||a.kind==='slam'||(e.def.boss&&a.kind==='charge'))AU.play('warn');
  if(a.kind==='charge'&&e.def.boss){FX.push({t:'lane',x:e.x,face:sgn(P.x-e.x),life:e.windT,age:0,len:420})}
}
function eContact(e,a,once){
  if(once&&e.hit)return false;
  const [x0,y0,x1,y1]=pRect();
  if(rectO(e.x-e.def.bw/2-6,e.y-e.def.bh,e.x+e.def.bw/2+6,e.y,x0,y0,x1,y1)){e.hit=true;hurtPlayer(e,a.dmg,{kb:a.kb,slow:a.slow});return true}
  return false;
}
function beginAct(e,a){
  e.state='act';e.t=0;e.hit=false;const dist=Math.abs(P.x-e.x),dir=sgn(P.x-e.x);
  switch(a.kind){
    case 'proj':{
      const q=a.proj,shots=(a.shots&&e.phase===2)?3:1;
      for(let i=0;i<shots;i++){
        const sy=e.y-e.def.bh*(e.def.boss?.25:.6)-(shots>1?(i-1)*-46:0);
        const tx=P.x,ty=P.y-60;let vx=e.face*q.sp,vy=q.vy;
        if(q.kind==='orb'){const dx=tx-e.x,dy=ty-sy,L=Math.hypot(dx,dy)||1;vx=dx/L*q.sp;vy=dy/L*q.sp}
        else if(q.g&&q.kind!=='crescent'){const T=Math.max(.35,Math.min(1.1,dist/q.sp));vx=e.face*Math.min(q.sp,dist/T);vy=q.vy}
        PR.push({own:'e',kind:q.kind,x:e.x+e.face*36,y:sy,vx,vy:shots>1&&q.kind==='crescent'?(i-1)*60:vy,g:q.g,r:q.r,hh:q.kind==='crescent'?46:q.r,life:q.life,atk:e.atk,mult:a.dmg,col:q.color,slow:a.slow,kb:a.kb||160,pierce:0,rot:0});
      }
      AU.play(q.kind==='bone'?'bone':'magic');break;}
    case 'charge':e.vx=e.face*a.sp;break;
    case 'leap':e.vy=-a.vy;e.vx=e.face*Math.min(a.vx,dist*1.7);e.onGround=false;break;
    case 'aoe':{
      const tx=e.tgt?e.tgt.x:P.x;AU.play('boom');shake(6);
      FX.push({t:'ring',x:tx,y:GROUND-6,r0:8,r1:a.rad*1.3,life:.35,age:0,col:'#b06bff',w:10});
      FX.push({t:'pillar',x:tx,life:.4,age:0,col:'#b06bff'});
      burst(tx,GROUND-30,26,{c:'#b06bff',s0:80,s1:380,g:200,a:-1.57,sp:1.4,l1:.7});
      if(Math.abs(P.x-tx)<a.rad+16&&P.y>=GROUND-70)hurtPlayer(e,a.dmg,{kb:a.kb});
      break;}
    case 'summon':{
      const mine=E.filter(m=>m.summoner===e&&!m.dead).length;
      for(let i=0;i<a.n&&mine+i<a.cap;i++){
        const mx=clamp(e.x+(i%2?-1:1)*(70+i*30),eBounds()[0]+40,eBounds()[1]-40),m=spawnEnemy(a.mob,mx,{lvl:e.lvl,minion:true,wave:e.wave});m.summoner=e;m.face=e.face;
        m.stun=.5;burst(mx,GROUND-40,18,{c:'#b06bff',s0:40,s1:220,g:-100,l1:.8});
      }
      FX.push({t:'ring',x:e.x,y:e.y-50,r0:10,r1:110,life:.5,age:0,col:'#b06bff',w:8});AU.play('magic');break;}
    case 'dive':e.tgt={x:P.x};e.vx=0;AU.play('dash');break;
    case 'tele':{
      const [lo,hi]=eBounds(),nx=clamp(P.x-P.face*120,lo+60,hi-60);
      burst(e.x,e.y-60,16,{c:'#7aa2ff',s0:30,s1:170,g:-80,l1:.7});
      e.x=nx;e.face=sgn(P.x-e.x)||1;e.alpha=0;burst(e.x,e.y-60,16,{c:'#7aa2ff',s0:30,s1:170,g:-80,l1:.7});AU.play('magic');break;}
    case 'slam':{
      shake(12);AU.play('boom');
      FX.push({t:'ring',x:e.x+e.face*80,y:GROUND-6,r0:10,r1:150,life:.4,age:0,col:'#ff5a3a',w:14});
      burst(e.x+e.face*80,GROUND-6,30,{c:'#a06a4a',s0:80,s1:360,g:500,a:-1.57,sp:1.5,add:0,z1:7});
      for(const s of [-1,1])PR.push({own:'e',kind:'shock',x:e.x+s*70,y:GROUND-26,vx:s*430,vy:0,g:0,r:34,hh:28,life:1.0,atk:e.atk,mult:a.dmg*.85,col:'#ff5a3a',kb:300,pierce:0,rot:0});
      if(Math.abs(P.x-(e.x+e.face*80))<120&&P.y>=GROUND-40)hurtPlayer(e,a.dmg,{kb:a.kb});
      break;}
    case 'spin':e.spinT=0;AU.play('roar');break;
    case 'melee':AU.play('slash');
      FX.push({t:'slash',x:e.x+e.face*8,y:e.y-e.def.bh*.5,face:e.face,r:Math.min(150,a.w*.62),a0:-1.2,a1:1.0,life:.2,age:0,col:e.def.boss?'#ff2233':(e.type==='skeleton'?'#e8e0cc':(e.type==='goblin'?'#cfe8b0':'#ff7a4a')),w:e.def.boss?24:12});break;
  }
}
function updAct(e,a,dt,dir){
  e.t+=dt;
  switch(a.kind){
    case 'melee':{
      if(!e.hit&&e.t<=a.act+.05){
        const x0=e.face>0?e.x-10:e.x-a.w,x1=e.face>0?e.x+a.w:e.x+10,[px0,py0,px1,py1]=pRect();
        if(rectO(x0,e.y-a.h,x1,e.y+6,px0,py0,px1,py1)){e.hit=true;hurtPlayer(e,a.dmg,{kb:a.kb})}
      }
      if(e.t>=a.act)endAct(e);break;}
    case 'proj':case 'aoe':case 'summon':case 'slam':if(e.t>=a.act)endAct(e);break;
    case 'charge':{
      e.x+=e.vx*dt;eContact(e,a,true);
      if(e.t>=a.act){e.vx=0;endAct(e)}break;}
    case 'leap':{
      e.x+=e.vx*dt;eContact(e,a,true);
      if((e.onGround&&e.t>.12)||e.t>1.5){e.vx=0;burst(e.x,GROUND,6,{c:'#7a5a5a',s0:20,s1:100,g:100,a:-1.57,sp:1.4,add:0});endAct(e)}break;}
    case 'dive':{
      const tx=e.tgt.x;e.x+=clamp(tx-e.x,-330*dt,330*dt);e.fy-=880*dt;
      if(e.fy<=0){e.fy=0;e.y=GROUND;shake(8);AU.play('boom');burst(e.x,GROUND,18,{c:'#7a6a6a',s0:60,s1:260,g:300,a:-1.57,sp:1.5,add:0});
        FX.push({t:'ring',x:e.x,y:GROUND-6,r0:8,r1:110,life:.3,age:0,col:'#aa8888',w:8});
        if(Math.abs(P.x-e.x)<80&&P.y>=GROUND-60)hurtPlayer(e,a.dmg,{kb:a.kb});endAct(e)}
      else eContact(e,a,true);
      break;}
    case 'tele':{e.alpha=Math.min(1,e.t/.25);if(e.t>=a.act){e.alpha=1;e.forceNext=a.then;e.atkCd=0;endAct(e)}break;}
    case 'spin':{
      e.spinT+=dt;e.face=dir;e.x+=dir*200*dt;
      if(e.spinT>=.24){e.spinT=0;AU.play('slash');
        if(Math.abs(P.x-e.x)<a.rad+18&&P.y>e.y-e.def.bh){hurtPlayer(e,a.dmg,{kb:280})}}
      if(e.t>=a.act)endAct(e);break;}
  }
}
function endAct(e){e.state='rec';e.t=0}
function updEnemy(e,dt){
  const d=e.def;
  if(e.dead){e.deathT+=dt;e.kbx*=Math.pow(.02,dt);e.x+=e.kbx*dt;if(!d.fly)eGrav(e,dt);return}
  e.anim+=dt;e.flash-=dt;e.hitT-=dt;e.atkCd-=dt;e.inv-=dt;for(const k in e.cds)e.cds[k]-=dt;
  if(e.state==='act'&&e.curAtk&&(e.curAtk.kind==='charge'||e.curAtk.kind==='leap'||e.curAtk.kind==='dive')){e.gh.push({x:e.x,y:e.y,face:e.face,a:.6});if(e.gh.length>6)e.gh.shift()}
  for(const g of e.gh)g.a-=dt*3.2;while(e.gh.length&&e.gh[0].a<=0)e.gh.shift();
  e.kbx*=Math.pow(.004,dt);
  const dx=P.x-e.x,dist=Math.abs(dx),dir=sgn(dx),k=(d.boss&&e.phase===2)?.78:1;
  const [lo,hi]=eBounds();
  if(e.stun>0){
    e.stun-=dt;e.x+=e.kbx*dt;if(!d.fly)eGrav(e,dt);else e.y=GROUND-e.fy;e.x=clamp(e.x,lo,hi);return;
  }
  e.x+=e.kbx*dt;
  switch(e.state){
    case 'intro':{
      e.t+=dt;e.face=-1;e.x-=150*dt;e.inv=.1;
      if(e.t>1.7||e.x<=G.lock.max-300){e.state='move';e.t=0;e.inv=0;e.atkCd=.8}
      break;}
    case 'phase':{
      e.t+=dt;e.face=dir;e.inv=.1;
      if(Math.random()<.5)spark(e.x+rnd(-50,50),e.y-rnd(20,200),rnd(-40,40),rnd(-200,-60),.7,rnd(2,5),'#ff2233',0,1);
      if(e.t>=1.9){e.state='move';e.t=0;e.phase=2;e.spdMul=1.3;e.inv=0;e.atkCd=.5;e.cds={}}
      break;}
    case 'move':{
      e.face=dir;let vx=0;
      if(d.keep){if(dist<d.keep[0])vx=-dir*d.spd*.9;else if(dist>d.keep[1])vx=dir*d.spd}
      else if(dist>e.pref)vx=dir*d.spd*e.spdMul*(e.slowMul||1);
      for(const o of E){if(o!==e&&!o.dead&&!o.def.boss&&Math.abs(o.x-e.x)<32)vx+=sgn(e.x-o.x||1)*30}
      e.vx=vx;e.x+=vx*dt;
      if(d.fly){const target=d.hover+Math.sin(e.anim*2.2)*9;e.fy+=(target-e.fy)*Math.min(1,5*dt)}
      if(e.atkCd<=0){const a=chooseAttack(e,dist);if(a)startAttack(e,a);else if(e.def.boss)e.atkCd=.2}
      break;}
    case 'wind':{
      const a=e.curAtk;e.t+=dt;
      if(e.t<e.windT*.6&&a.kind!=='tele')e.face=dir;
      if(a.kind==='tele')e.alpha=Math.max(0,1-e.t/e.windT);
      if(a.kind==='dive')e.fy+=(d.hover+95-e.fy)*Math.min(1,7*dt);
      else if(d.fly)e.fy+=(d.hover-e.fy)*Math.min(1,4*dt);
      if(e.t>=e.windT)beginAct(e,a);
      break;}
    case 'act':updAct(e,e.curAtk,dt,dir);break;
    case 'rec':{
      const a=e.curAtk;e.t+=dt;
      if(d.fly)e.fy+=(d.hover-e.fy)*Math.min(1,(a.kind==='dive'?1.5:4)*dt);
      if(e.t>=a.rec*k){e.state='move';e.t=0;e.atkCd=d.boss?rnd(.35,.9)*k:rnd(.35,.95);e.curAtk=null}
      break;}
  }
  if(d.fly)e.y=GROUND-e.fy;else if(!(e.state==='act'&&e.curAtk&&e.curAtk.kind==='dive'))eGrav(e,dt);
  e.x=clamp(e.x,lo,hi);
}
function eGrav(e,dt){e.vy+=GRAV*dt;e.y+=e.vy*dt;if(e.y>=GROUND){e.y=GROUND;e.vy=0;e.onGround=true}else e.onGround=false}

/* =====================================================================
   PROJECTILES / PICKUPS / EFFECTS
   ===================================================================== */
function updProj(dt){
  for(let i=PR.length-1;i>=0;i--){
    const q=PR[i];q.life-=dt;q.vy+=(q.g||0)*dt;q.x+=q.vx*dt;q.y+=q.vy*dt;q.rot+=dt*8;
    let dead=q.life<=0;
    if(q.kind==='bone'||q.kind==='web'){if(q.y>=GROUND-6)dead=true}
    if(Math.random()<.5&&q.kind!=='bone')spark(q.x+rnd(-6,6),q.y+rnd(-6,6),rnd(-20,20),rnd(-20,20),.3,rnd(2,4),q.col,0,1);
    if(q.own==='e'){
      const [x0,y0,x1,y1]=pRect();
      if(rectO(q.x-q.r,q.y-q.hh,q.x+q.r,q.y+q.hh,x0,y0,x1,y1)){
        if(hurtPlayer({atk:q.atk,x:q.x-Math.sign(q.vx||1)*40},q.mult,{kb:q.kb,slow:q.slow}))dead=!q.pierce;
      }
    }else{
      for(const e of E){
        if(e.dead||q.hit.has(e))continue;
        if(rectO(q.x-q.r,q.y-q.hh,q.x+q.r,q.y+q.hh,e.x-e.def.bw/2,e.y-e.def.bh,e.x+e.def.bw/2,e.y)){
          q.hit.add(e);hitEnemy(e,q.mult,{kb:q.kb,stun:q.stun,dir:q.dir,hs:.05,shake:4});if(!q.pierce)dead=true;
        }
      }
    }
    if(dead){if(q.kind==='orb')burst(q.x,q.y,8,{c:q.col,s0:30,s1:150,l1:.4});PR.splice(i,1)}
  }
}
let coinT=0;
function updPickups(dt){
  coinT-=dt;
  for(let i=PK.length-1;i>=0;i--){
    const k=PK[i];k.t+=dt;
    if(k.t<.45||Math.hypot(P.x-k.x,(P.y-50)-k.y)>170){k.vy+=1500*dt;k.x+=k.vx*dt;k.y+=k.vy*dt;if(k.y>GROUND-8){k.y=GROUND-8;k.vy*=-.35;k.vx*=.7}}
    else{const a=Math.atan2(P.y-50-k.y,P.x-k.x),s=520+k.t*300;k.x+=Math.cos(a)*s*dt;k.y+=Math.sin(a)*s*dt}
    if(k.t>.3&&Math.hypot(P.x-k.x,(P.y-50)-k.y)<30){
      if(k.k==='gold'){SV.gold+=k.val;G.stats.gold+=k.val;if(coinT<=0){AU.play('coin');coinT=.05}}
      else{SV.pot[k.k]++;G.stats.items[k.k]++;AU.play('coin');floater(P.x,P.y-150,(k.k==='hp'?'HP':'MP')+' Potion','#fff')}
      PK.splice(i,1);continue;
    }
    if(k.t>30)PK.splice(i,1);
  }
}
function updFx(dt){
  for(let i=FX.length-1;i>=0;i--){const f=FX[i];f.age+=dt;if(f.age>=f.life)FX.splice(i,1)}
  for(let i=FL.length-1;i>=0;i--){const f=FL[i];f.t+=dt;f.y+=f.vy*dt;f.vy*=Math.pow(.05,dt);if(f.t>.9)FL.splice(i,1)}
  for(const p of PT){if(!p.on)continue;p.life-=dt;if(p.life<=0){p.on=0;continue}p.vy+=p.g*dt;p.x+=p.vx*dt;p.y+=p.vy*dt}
}

/* =====================================================================
   STAGE FLOW
   ===================================================================== */
function decorFor(len,seed){
  let s=seed;const r=()=>(s=(s*16807)%2147483647)/2147483647;
  const list=[],fg=[];let x=260;
  while(x<len){list.push({t:['torch','torch','banner','ruin','barrels','torch'][Math.floor(r()*6)],x,v:r()});x+=340+r()*300}
  x=500;while(x<len){fg.push({t:r()<.5?'post':'chain',x,v:r()});x+=760+r()*600}
  return {list,fg};
}
function startStage(mapId,idx){
  const map=DATA.maps[mapId],st=map.stages[idx];if(!st)return;
  G.map=map;G.stageIdx=idx;G.stage=st;G.len=st.len;
  E.length=0;PR.length=0;FX.length=0;PK.length=0;FL.length=0;BR.length=0;for(const p of PT)p.on=0;
  makePlayer(SV.char);
  G.waves=st.waves.map(w=>({x:w.x,e:w.e,boss:w.boss,elite:w.elite,started:false,done:false,list:[]}));
  G.lock=null;G.cam.x=0;G.cam.zoom=1;G.cam.zt=1;G.cam.shake=0;G.ts=1;G.hitstop=0;G.dark=0;
  G.stats={time:0,kills:0,maxCombo:0,exp:0,gold:0,items:{hp:0,mp:0},hits:0,dmgTaken:0,dmg:0};
  G.combo=0;G.comboT=0;G.clearT=0;G.defeatT=0;G.revives=0;G.bossDown=false;G.over=false;G.phaseTxt=null;G.redA=0;G.flashA=0;
  const dc=decorFor(st.len,1000+idx*77);G.decor=dc.list;G.fg=dc.fg;
  // tong yang bisa dihancurkan di antara wave
  let bx=380;while(bx<st.len-200){const inWave=st.waves.some(w=>Math.abs(bx-w.x)<520);if(!inWave&&!st.boss)BR.push({x:bx,broken:false});bx+=rnd(260,420)}
  G.banner={t:0,text:((st.boss?T('boss')+' ':T('stage')+' ')+st.id).toUpperCase(),sub:TR(map.chapter)};
  IN.p={};IN.held={};IN.x=0;
  setScene('play');AU.music('battle');
}
function startWave(w){
  w.started=true;const st=G.stage;
  const min=clamp(w.x-W/2,0,G.len-W);G.lock={min,max:min+W};
  const lvl=st.lv;
  if(w.boss){
    const e=spawnEnemy(w.e[0],G.lock.max+90,{lvl,wave:w});e.state='intro';e.face=-1;w.list.push(e);G.bossRef=e;
    G.banner={t:0,text:DATA.enemies[w.e[0]].name.toUpperCase(),sub:'BOSS'};AU.play('roar');shake(10);AU.music('boss');
  }else{
    let elitePicked=false;
    w.e.forEach((type,i)=>{
      const left=i%2===0,off=Math.min(100,30+Math.floor(i/2)*28);
      const isElite=!!w.elite&&type===w.elite&&!elitePicked;if(isElite)elitePicked=true;
      const e=spawnEnemy(type,left?G.lock.min-off:G.lock.max+off,{lvl:lvl+(isElite?1:0),wave:w,elite:isElite});w.list.push(e);
    });
    AU.play('warn');
  }
}
function updWaves(dt){
  for(const w of G.waves){
    if(w.done)continue;
    if(!w.started){if(!G.lock&&P.x>=w.x-330)startWave(w);break}
    const mine=E.filter(e=>e.wave===w);
    if(mine.length&&mine.every(e=>e.dead)){
      w.done=true;G.lock=null;
      if(G.waves.every(x=>x.done)&&!w.boss){G.clearT=.001}
      else if(!w.boss)G.goHint=4;
    }
    break;
  }
}
function updCamera(rdt){
  const c=G.cam;
  let target=P.x-W/2+P.face*60;
  if(G.lock)target=G.lock.min;
  target=clamp(target,0,Math.max(0,G.len-W));
  c.x=lerp(c.x,target,Math.min(1,(G.lock?7:6)*rdt));
  c.zoom=lerp(c.zoom,c.zt,Math.min(1,7*rdt));
  c.shake=Math.max(0,c.shake-c.shake*7*rdt-10*rdt);
}
function updatePlay(rdt){
  let dt=rdt;
  if(G.hitstop>0){G.hitstop-=rdt;dt=rdt*.05}
  dt*=G.ts;
  G.ts=lerp(G.ts,1,Math.min(1,(G.defeatT>0||G.bossDown?.6:2.2)*rdt));if(G.ts>.985)G.ts=1;
  G.stats.time+=rdt*(G.clearT>0||G.over?0:1);
  if(G.comboT>0){G.comboT-=dt;if(G.comboT<=0)G.combo=0}
  G.flashA=Math.max(0,G.flashA-rdt*2.2);G.redA=Math.max(0,G.redA-rdt*1.6);G.goHint=Math.max(0,G.goHint-rdt);
  if(G.banner){G.banner.t+=rdt;if(G.banner.t>2.6)G.banner=null}
  if(G.phaseTxt){G.phaseTxt.t+=rdt;if(G.phaseTxt.t>2.2)G.phaseTxt=null}
  updPlayer(dt);
  for(const e of E)updEnemy(e,dt);
  for(let i=E.length-1;i>=0;i--)if(E[i].dead&&E[i].deathT>1.3)E.splice(i,1);
  updProj(dt);updPickups(dt);updFx(dt);
  if(!G.bossDown&&!P.dead)updWaves(dt);
  // aura merah Slayer
  if(!P.dead&&Math.random()<.35*pmul()){spark(P.x+rnd(-24,24),P.y-rnd(0,90),rnd(-10,10),rnd(-70,-30),.7,rnd(1.5,3),'#ff2a3a',0,1)}
  if(G.map&&(G.stage.boss)){/* boss aura di render */}
  updCamera(rdt);
  // akhir stage
  if(G.clearT>0&&!G.over){G.clearT+=rdt;if(G.clearT>(G.bossDown?2.6:1.5))finishStage()}
  if(P.dead){G.defeatT+=rdt;if(G.defeatT>1.5&&!G.over){G.over=true;showDefeat()}}
  IN.upEdge=false;
}
function finishStage(){
  if(G.over)return;G.over=true;
  const st=G.stage,map=G.map,no=G.stageIdx+1,ms=SV.maps[map.id],st2=G.stats;
  const first=ms.cleared<no;
  let bonusExp=25*no+(st.boss?300:0),bonusGold=40*no+(st.boss?400:0),crystals=first?(st.boss?10:3):0;
  if(first)ms.cleared=no;
  gainExp(bonusExp);SV.gold+=bonusGold;st2.gold+=bonusGold;SV.crystal+=crystals;
  let bossNote='';
  if(st.boss&&!SV.bosses.includes(map.boss)){SV.bosses.push(map.boss);ms.boss=true;if(SV.maps[map.id+1])SV.maps[map.id+1].unlocked=true;bossNote=T('bosskill')}
  const par=st.par||120;
  const score=100-Math.max(0,(st2.time-par)/par)*35-st2.hits*3+Math.min(st2.maxCombo,40)*.5;
  const rank=score>=90?'S':score>=72?'A':score>=52?'B':'C';
  SV.playSec+=st2.time;persist();AU.jingle('win');
  showVictory({st,rank,bonusExp,bonusGold,crystals,bossNote,hasNext:!!map.stages[G.stageIdx+1]});
}
function doRevive(){
  const cost=5*(G.revives+1);if(SV.crystal<cost)return false;
  SV.crystal-=cost;G.revives++;const p=P;
  p.dead=false;p.hp=Math.round(p.maxhp*.6);p.mp=p.maxmp;p.state='idle';p.stateT=0;p.inv=2.5;p.vx=0;p.vy=0;
  for(let i=PR.length-1;i>=0;i--)if(PR[i].own==='e')PR.splice(i,1);
  G.over=false;G.defeatT=0;G.ts=1;AU.play('lvl');burst(p.x,p.y-60,30,{c:'#ffd23a',s0:80,s1:320,g:-60,l1:1});
  AU.music(G.bossRef&&!G.bossRef.dead&&G.lock?'boss':'battle');return true;
}
