import { audioManager } from '../audio/AudioManager.js';

export class InventorySystem {
  constructor(maxSlots = 8) {
    this.maxSlots = maxSlots;
    this.items = []; // array of { id, name, type, count, icon, description, combineWith }
    this.itemBox = []; // shared storage box items

    // Pre-populate starting inventory
    this.addItem({ id: 'handgun', name: 'VP70 Handgun', type: 'weapon', count: 1, icon: '🔫', description: 'Standard 9mm service pistol.' });
    this.addItem({ id: 'ammo_handgun', name: 'Handgun Ammo', type: 'ammo', count: 15, icon: '📦', description: '9mm Parabellum ammunition.' });
    this.addItem({ id: 'herb_green', name: 'Green Herb', type: 'herb', count: 1, icon: '🌿', description: 'Medicinal herb. Restores a small amount of health.' });
  }

  addItem(item) {
    // Check if stackable (ammo)
    if (item.type === 'ammo') {
      const existing = this.items.find(i => i.id === item.id);
      if (existing) {
        existing.count += item.count;
        audioManager.playItemPickup();
        return true;
      }
    }

    if (this.items.length >= this.maxSlots) {
      return false; // Inventory full
    }

    this.items.push({ ...item });
    audioManager.playItemPickup();
    return true;
  }

  removeItem(index) {
    if (index >= 0 && index < this.items.length) {
      return this.items.splice(index, 1)[0];
    }
    return null;
  }

  combineItems(indexA, indexB) {
    if (indexA === indexB) return false;
    const itemA = this.items[indexA];
    const itemB = this.items[indexB];

    if (!itemA || !itemB) return false;

    // Green Herb + Red Herb = Mixed Herb (Full Heal)
    if (
      (itemA.id === 'herb_green' && itemB.id === 'herb_red') ||
      (itemA.id === 'herb_red' && itemB.id === 'herb_green')
    ) {
      this.items.splice(Math.max(indexA, indexB), 1);
      this.items.splice(Math.min(indexA, indexB), 1);
      this.addItem({
        id: 'herb_mixed_gr',
        name: 'Mixed Herb (G+R)',
        type: 'herb',
        count: 1,
        icon: '🧪',
        description: 'Combined herbs. Completely restores health.'
      });
      return true;
    }

    // Gunpowder A + Gunpowder B = Handgun Ammo / Shotgun Ammo
    if (
      (itemA.id === 'gunpowder_a' && itemB.id === 'gunpowder_b') ||
      (itemA.id === 'gunpowder_b' && itemB.id === 'gunpowder_a')
    ) {
      this.items.splice(Math.max(indexA, indexB), 1);
      this.items.splice(Math.min(indexA, indexB), 1);
      this.addItem({
        id: 'ammo_shotgun',
        name: 'Shotgun Shells',
        type: 'ammo',
        count: 10,
        icon: '💥',
        description: '12-gauge shotgun shells.'
      });
      return true;
    }

    return false;
  }

  moveToBox(index) {
    const item = this.removeItem(index);
    if (item) {
      this.itemBox.push(item);
      audioManager.playUIClick();
      return true;
    }
    return false;
  }

  takeFromBox(boxIndex) {
    if (this.items.length >= this.maxSlots) return false;
    const item = this.itemBox.splice(boxIndex, 1)[0];
    if (item) {
      this.items.push(item);
      audioManager.playUIClick();
      return true;
    }
    return false;
  }
}
