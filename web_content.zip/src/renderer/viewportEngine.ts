import * as THREE from 'three';
import { EngineObject, SceneData, ViewportMode, TransformGizmoMode } from '../types';

export interface ViewportStats {
  fps: number;
  frameTime: number;
  triangles: number;
  drawCalls: number;
  objectsCount: number;
  memoryGeometries: number;
  memoryTextures: number;
  webglVersion: string;
}

export class ViewportEngine {
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  private container: HTMLElement;
  private animFrameId: number | null = null;
  private clock: THREE.Clock;

  // Orbit / Editor camera controls state
  private isOrbiting = false;
  private isPanning = false;
  private previousPointerPosition = { x: 0, y: 0 };
  private cameraTarget = new THREE.Vector3(0, 2, 0);
  private cameraRadius = 25;
  private cameraTheta = 0.8;
  private cameraPhi = 0.6;

  // Selection & Picking
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();
  private objectMeshes = new Map<string, THREE.Object3D>();
  private selectionBox: THREE.BoxHelper | null = null;
  public selectedObjectId: string | null = null;

  // Viewport mode & settings
  public viewportMode: ViewportMode = 'material';
  public gizmoMode: TransformGizmoMode = 'translate';
  public showGrid: boolean = true;
  public snapEnabled: boolean = false;
  public snapStep: number = 1.0;
  private gridHelper: THREE.GridHelper | null = null;

  // Game Mode (Play)
  public isGameMode: boolean = false;
  public playerVelocity = new THREE.Vector3();
  public playerOnGround = true;
  public inputMove = { forward: 0, right: 0, jump: false, action: false };
  public playerCamYaw = 0;
  public playerCamPitch = 0.35;
  private isGameOrbiting = false;

  // Procedural Texture Cache
  private textureCache = new Map<string, THREE.CanvasTexture>();

  // Gizmo dragging state
  public isDraggingGizmo = false;
  public activeGizmoAxis: 'x' | 'y' | 'z' | null = null;
  private gizmoGroup = new THREE.Group();
  private dragPlane = new THREE.Plane();
  private planeIntersect = new THREE.Vector3();

  // Callbacks
  public onSelectObject?: (id: string | null) => void;
  public onObjectTransformChange?: (id: string, transform: EngineObject['transform']) => void;
  public onStatsUpdate?: (stats: ViewportStats) => void;

  // Stats calculation
  private frames = 0;
  private lastTime = performance.now();
  private currentFps = 60;
  private currentFrameTime = 16.6;
  public webglVersion = 'WebGL 2.0';

  constructor(container: HTMLElement) {
    this.container = container;
    this.clock = new THREE.Clock();

    // 1. Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#0b0f19');

    // 2. Camera setup
    const aspect = container.clientWidth / Math.max(1, container.clientHeight);
    this.camera = new THREE.PerspectiveCamera(55, aspect, 0.1, 1000);
    this.updateCameraPosition();

    // 3. Renderer with Android 8 WebGL 1/2 fallback detection
    let contextType = 'webgl2';
    let glContext: WebGLRenderingContext | WebGL2RenderingContext | null = null;
    const canvas = document.createElement('canvas');

    try {
      glContext = canvas.getContext('webgl2') as WebGL2RenderingContext;
      if (!glContext) {
        contextType = 'webgl';
        glContext = (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')) as WebGLRenderingContext;
      }
    } catch {
      contextType = 'webgl';
    }

    this.webglVersion = glContext instanceof WebGL2RenderingContext ? 'WebGL 2.0 (High Performance)' : 'WebGL 1.0 (Compat Fallback)';

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      precision: 'mediump', // Safe and high performance on Android 8 GPUs (Adreno / Mali)
    });

    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // 4. Grid Helper
    this.initGrid();

    // 5. Gizmo Group
    this.initGizmos();

    // 6. Selection Box Helper
    this.selectionBox = new THREE.BoxHelper(new THREE.Mesh(), 0x38bdf8);
    this.selectionBox.visible = false;
    this.scene.add(this.selectionBox);

    // 7. Event listeners
    this.initEventListeners();

    // 8. Start loop
    this.animate();
  }

  private initGrid() {
    if (this.gridHelper) {
      this.scene.remove(this.gridHelper);
    }
    this.gridHelper = new THREE.GridHelper(80, 80, 0x0284c7, 0x1e293b);
    this.gridHelper.position.y = 0.001;
    this.scene.add(this.gridHelper);
  }

  private initGizmos() {
    this.gizmoGroup.name = 'DaviGizmo';
    this.scene.add(this.gizmoGroup);
    this.buildGizmoMesh();
  }

  private buildGizmoMesh() {
    // Clear previous gizmo children
    while (this.gizmoGroup.children.length > 0) {
      const child = this.gizmoGroup.children[0];
      this.gizmoGroup.remove(child);
    }

    if (!this.selectedObjectId || this.isGameMode) {
      this.gizmoGroup.visible = false;
      return;
    }

    this.gizmoGroup.visible = true;
    const arrowLength = 2.4;
    const arrowRadius = 0.06;

    if (this.gizmoMode === 'translate') {
      // X Arrow (Red)
      const matX = new THREE.MeshBasicMaterial({ color: 0xef4444, depthTest: false });
      const shaftX = new THREE.Mesh(new THREE.CylinderGeometry(arrowRadius, arrowRadius, arrowLength), matX);
      shaftX.rotation.z = -Math.PI / 2;
      shaftX.position.x = arrowLength / 2;
      const headX = new THREE.Mesh(new THREE.ConeGeometry(arrowRadius * 3, 0.6, 12), matX);
      headX.rotation.z = -Math.PI / 2;
      headX.position.x = arrowLength;
      const groupX = new THREE.Group();
      groupX.name = 'gizmo_x';
      groupX.add(shaftX, headX);

      // Y Arrow (Green)
      const matY = new THREE.MeshBasicMaterial({ color: 0x22c55e, depthTest: false });
      const shaftY = new THREE.Mesh(new THREE.CylinderGeometry(arrowRadius, arrowRadius, arrowLength), matY);
      shaftY.position.y = arrowLength / 2;
      const headY = new THREE.Mesh(new THREE.ConeGeometry(arrowRadius * 3, 0.6, 12), matY);
      headY.position.y = arrowLength;
      const groupY = new THREE.Group();
      groupY.name = 'gizmo_y';
      groupY.add(shaftY, headY);

      // Z Arrow (Blue)
      const matZ = new THREE.MeshBasicMaterial({ color: 0x3b82f6, depthTest: false });
      const shaftZ = new THREE.Mesh(new THREE.CylinderGeometry(arrowRadius, arrowRadius, arrowLength), matZ);
      shaftZ.rotation.x = Math.PI / 2;
      shaftZ.position.z = arrowLength / 2;
      const headZ = new THREE.Mesh(new THREE.ConeGeometry(arrowRadius * 3, 0.6, 12), matZ);
      headZ.rotation.x = Math.PI / 2;
      headZ.position.z = arrowLength;
      const groupZ = new THREE.Group();
      groupZ.name = 'gizmo_z';
      groupZ.add(shaftZ, headZ);

      this.gizmoGroup.add(groupX, groupY, groupZ);
    } else if (this.gizmoMode === 'rotate') {
      const ringRadius = 2.0;
      const tubeRadius = 0.05;

      const ringMatX = new THREE.MeshBasicMaterial({ color: 0xef4444, depthTest: false });
      const ringX = new THREE.Mesh(new THREE.TorusGeometry(ringRadius, tubeRadius, 8, 32), ringMatX);
      ringX.rotation.y = Math.PI / 2;
      ringX.name = 'gizmo_x';

      const ringMatY = new THREE.MeshBasicMaterial({ color: 0x22c55e, depthTest: false });
      const ringY = new THREE.Mesh(new THREE.TorusGeometry(ringRadius, tubeRadius, 8, 32), ringMatY);
      ringY.rotation.x = Math.PI / 2;
      ringY.name = 'gizmo_y';

      const ringMatZ = new THREE.MeshBasicMaterial({ color: 0x3b82f6, depthTest: false });
      const ringZ = new THREE.Mesh(new THREE.TorusGeometry(ringRadius, tubeRadius, 8, 32), ringMatZ);
      ringZ.name = 'gizmo_z';

      this.gizmoGroup.add(ringX, ringY, ringZ);
    } else if (this.gizmoMode === 'scale') {
      const scaleLen = 2.0;
      // X Handle
      const matX = new THREE.MeshBasicMaterial({ color: 0xef4444, depthTest: false });
      const shaftX = new THREE.Mesh(new THREE.CylinderGeometry(arrowRadius, arrowRadius, scaleLen), matX);
      shaftX.rotation.z = -Math.PI / 2;
      shaftX.position.x = scaleLen / 2;
      const cubeX = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.35), matX);
      cubeX.position.x = scaleLen;
      const groupX = new THREE.Group();
      groupX.name = 'gizmo_x';
      groupX.add(shaftX, cubeX);

      // Y Handle
      const matY = new THREE.MeshBasicMaterial({ color: 0x22c55e, depthTest: false });
      const shaftY = new THREE.Mesh(new THREE.CylinderGeometry(arrowRadius, arrowRadius, scaleLen), matY);
      shaftY.position.y = scaleLen / 2;
      const cubeY = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.35), matY);
      cubeY.position.y = scaleLen;
      const groupY = new THREE.Group();
      groupY.name = 'gizmo_y';
      groupY.add(shaftY, cubeY);

      // Z Handle
      const matZ = new THREE.MeshBasicMaterial({ color: 0x3b82f6, depthTest: false });
      const shaftZ = new THREE.Mesh(new THREE.CylinderGeometry(arrowRadius, arrowRadius, scaleLen), matZ);
      shaftZ.rotation.x = Math.PI / 2;
      shaftZ.position.z = scaleLen / 2;
      const cubeZ = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.35), matZ);
      cubeZ.position.z = scaleLen;
      const groupZ = new THREE.Group();
      groupZ.name = 'gizmo_z';
      groupZ.add(shaftZ, cubeZ);

      this.gizmoGroup.add(groupX, groupY, groupZ);
    }
  }

  private updateCameraPosition() {
    this.cameraPhi = Math.max(0.01, Math.min(Math.PI / 2 - 0.01, this.cameraPhi));
    const x = this.cameraTarget.x + this.cameraRadius * Math.sin(this.cameraPhi) * Math.sin(this.cameraTheta);
    const y = this.cameraTarget.y + this.cameraRadius * Math.cos(this.cameraPhi);
    const z = this.cameraTarget.z + this.cameraRadius * Math.sin(this.cameraPhi) * Math.cos(this.cameraTheta);
    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.cameraTarget);
  }

  public setCameraView(preset: 'perspective' | 'top' | 'front' | 'side' | 'reset') {
    if (preset === 'top') {
      this.cameraPhi = 0.05;
      this.cameraTheta = 0;
    } else if (preset === 'front') {
      this.cameraPhi = Math.PI / 2.3;
      this.cameraTheta = 0;
    } else if (preset === 'side') {
      this.cameraPhi = Math.PI / 2.3;
      this.cameraTheta = Math.PI / 2;
    } else {
      this.cameraTarget.set(0, 2, 0);
      this.cameraRadius = 25;
      this.cameraTheta = 0.8;
      this.cameraPhi = 0.6;
    }
    this.updateCameraPosition();
  }

  public focusSelected() {
    if (this.selectedObjectId && this.objectMeshes.has(this.selectedObjectId)) {
      const mesh = this.objectMeshes.get(this.selectedObjectId)!;
      this.cameraTarget.copy(mesh.position);
      this.cameraRadius = 10;
      this.updateCameraPosition();
    }
  }

  public setViewportMode(mode: ViewportMode) {
    this.viewportMode = mode;
    this.applyViewportMode();
  }

  private getProceduralTexture(type: 'grid' | 'rock' | 'wood' | 'metal' | 'sand'): THREE.CanvasTexture {
    if (this.textureCache.has(type)) {
      return this.textureCache.get(type)!;
    }

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      const tex = new THREE.CanvasTexture(canvas);
      return tex;
    }

    if (type === 'grid') {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, 256, 256);
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 2;
      const step = 32;
      for (let x = 0; x <= 256; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, 256);
        ctx.stroke();
      }
      for (let y = 0; y <= 256; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(256, y);
        ctx.stroke();
      }
      ctx.fillStyle = '#38bdf8';
      for (let x = 0; x <= 256; x += step) {
        for (let y = 0; y <= 256; y += step) {
          ctx.fillRect(x - 2, y - 2, 4, 4);
        }
      }
    } else if (type === 'rock') {
      ctx.fillStyle = '#52525b';
      ctx.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 2000; i++) {
        const rx = Math.random() * 256;
        const ry = Math.random() * 256;
        const shade = Math.floor(60 + Math.random() * 120);
        ctx.fillStyle = `rgb(${shade},${shade},${shade})`;
        ctx.fillRect(rx, ry, Math.random() * 3 + 1, Math.random() * 3 + 1);
      }
    } else if (type === 'wood') {
      ctx.fillStyle = '#78350f';
      ctx.fillRect(0, 0, 256, 256);
      for (let y = 0; y < 256; y += 4) {
        const variation = Math.sin(y * 0.1) * 20;
        ctx.fillStyle = `rgb(${Math.max(50, 110 + variation)},${Math.max(30, 60 + variation * 0.6)},20)`;
        ctx.fillRect(0, y, 256, 3);
      }
    } else if (type === 'metal') {
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(0, 0, 256, 256);
      for (let x = 0; x < 256; x += 2) {
        const v = Math.floor(160 + Math.random() * 60);
        ctx.fillStyle = `rgb(${v},${v},${v + 5})`;
        ctx.fillRect(x, 0, 1, 256);
      }
    } else if (type === 'sand') {
      ctx.fillStyle = '#d97706';
      ctx.fillRect(0, 0, 256, 256);
      for (let y = 0; y < 256; y += 8) {
        ctx.fillStyle = '#b45309';
        ctx.fillRect(0, y + Math.sin(y * 0.1) * 3, 256, 2);
      }
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(2, 2);
    this.textureCache.set(type, texture);
    return texture;
  }

  private applyViewportMode() {
    this.objectMeshes.forEach((mesh) => {
      const objData = mesh.userData?.objectData as EngineObject | undefined;
      mesh.traverse((child) => {
        if (child instanceof THREE.Mesh && child.name !== 'GizmoHelper') {
          if (child.name === 'DroneRing' || child.name === 'RoverWheel') return;
          if (this.viewportMode === 'wireframe') {
            if (child.material instanceof THREE.MeshStandardMaterial || child.material instanceof THREE.MeshBasicMaterial) {
              child.material.wireframe = true;
            }
          } else if (this.viewportMode === 'solid') {
            child.material = new THREE.MeshStandardMaterial({
              color: 0x94a3b8,
              roughness: 0.65,
              metalness: 0.1,
              wireframe: false,
            });
          } else if (objData?.material) {
            child.material = this.buildMaterial(objData.material);
          } else if (child.material instanceof THREE.MeshStandardMaterial) {
            child.material.wireframe = false;
          }
        }
      });
    });
  }

  public setGizmoMode(mode: TransformGizmoMode) {
    this.gizmoMode = mode;
    this.buildGizmoMesh();
  }

  public loadScene(sceneData: SceneData) {
    // 1. Clear previous objects (except helpers)
    this.objectMeshes.forEach((mesh) => {
      this.scene.remove(mesh);
    });
    this.objectMeshes.clear();

    // 2. Set environment & fog
    this.scene.fog = new THREE.FogExp2(sceneData.fogColor || '#0f172a', sceneData.fogDensity || 0.01);
    this.scene.background = new THREE.Color(sceneData.skyColor || '#0284c7');

    // Remove old ambient light
    const oldAmb = this.scene.getObjectByName('EngineAmbientLight');
    if (oldAmb) this.scene.remove(oldAmb);
    const ambient = new THREE.AmbientLight(
      sceneData.ambientLightColor || '#60a5fa',
      sceneData.ambientLightIntensity ?? 0.7
    );
    ambient.name = 'EngineAmbientLight';
    this.scene.add(ambient);

    // 3. Build Three.js objects
    sceneData.objects.forEach((obj) => {
      this.addObjectToScene(obj);
    });

    // 4. Update gizmo & selection
    this.updateSelectionVisuals();
  }

  public addObjectToScene(obj: EngineObject) {
    if (this.objectMeshes.has(obj.id)) {
      const existing = this.objectMeshes.get(obj.id)!;
      this.scene.remove(existing);
      this.objectMeshes.delete(obj.id);
    }

    const mesh = this.createMeshForObject(obj);
    mesh.name = obj.id;
    mesh.visible = obj.visible;
    mesh.userData = { engineObjectId: obj.id, objectData: obj };

    this.scene.add(mesh);
    this.objectMeshes.set(obj.id, mesh);

    if (this.selectedObjectId === obj.id) {
      this.updateSelectionVisuals();
    }
  }

  public updateObjectTransform(obj: EngineObject) {
    const mesh = this.objectMeshes.get(obj.id);
    if (!mesh) return;

    mesh.position.set(obj.transform.position.x, obj.transform.position.y, obj.transform.position.z);
    mesh.rotation.set(
      THREE.MathUtils.degToRad(obj.transform.rotation.x),
      THREE.MathUtils.degToRad(obj.transform.rotation.y),
      THREE.MathUtils.degToRad(obj.transform.rotation.z)
    );
    mesh.scale.set(obj.transform.scale.x, obj.transform.scale.y, obj.transform.scale.z);

    if (this.selectedObjectId === obj.id) {
      this.gizmoGroup.position.copy(mesh.position);
      if (this.selectionBox) {
        this.selectionBox.setFromObject(mesh);
      }
    }
  }

  public updateObjectMaterial(obj: EngineObject) {
    const mesh = this.objectMeshes.get(obj.id);
    if (!mesh) return;

    if (mesh.userData) {
      mesh.userData.objectData = obj;
    }

    mesh.traverse((child) => {
      if (child instanceof THREE.Mesh && child.name !== 'GizmoHelper') {
        if (child.name === 'DroneRing' || child.name === 'RoverWheel') return;
        child.material = this.buildMaterial(obj.material);
      }
    });
  }

  public updateObjectLighting(obj: EngineObject) {
    const group = this.objectMeshes.get(obj.id);
    if (!group || !obj.lighting) return;
    group.traverse((child) => {
      if (child instanceof THREE.DirectionalLight || child instanceof THREE.PointLight || child instanceof THREE.SpotLight) {
        child.color.set(obj.lighting!.color);
        child.intensity = obj.lighting!.intensity;
        child.castShadow = obj.lighting!.castShadow;
        if (child instanceof THREE.PointLight || child instanceof THREE.SpotLight) {
          child.distance = obj.lighting!.distance;
        }
        if (child instanceof THREE.SpotLight && obj.lighting!.angle) {
          child.angle = obj.lighting!.angle * (Math.PI / 180);
        }
      }
    });
  }

  public removeObjectFromScene(id: string) {
    const mesh = this.objectMeshes.get(id);
    if (mesh) {
      this.scene.remove(mesh);
      this.objectMeshes.delete(id);
    }
    if (this.selectedObjectId === id) {
      this.selectObject(null);
    }
  }

  private buildMaterial(matData: EngineObject['material']): THREE.Material {
    if (this.viewportMode === 'solid') {
      return new THREE.MeshStandardMaterial({
        color: 0x94a3b8,
        roughness: 0.65,
        metalness: 0.1,
        wireframe: false,
      });
    }

    let map: THREE.Texture | null = null;
    if (matData.textureType && matData.textureType !== 'none') {
      map = this.getProceduralTexture(matData.textureType as any);
    }

    const mat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(matData.baseColor || '#4f46e5'),
      metalness: matData.metallic ?? 0.1,
      roughness: matData.roughness ?? 0.7,
      emissive: new THREE.Color(matData.emissive || '#000000'),
      emissiveIntensity: matData.emissiveIntensity ?? 0,
      opacity: matData.opacity ?? 1,
      transparent: (matData.opacity ?? 1) < 1,
      wireframe: this.viewportMode === 'wireframe' || !!matData.wireframe,
      map: map,
    });

    return mat;
  }

  private createMeshForObject(obj: EngineObject): THREE.Object3D {
    const p = obj.transform.position;
    const r = obj.transform.rotation;
    const s = obj.transform.scale;

    let group = new THREE.Group();

    if (obj.type === 'cube') {
      const geo = new THREE.BoxGeometry(1, 1, 1);
      const mat = this.buildMaterial(obj.material);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      group.add(mesh);
    } else if (obj.type === 'sphere') {
      const geo = new THREE.SphereGeometry(0.5, 32, 32);
      const mat = this.buildMaterial(obj.material);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      group.add(mesh);
    } else if (obj.type === 'capsule') {
      const geo = new THREE.CapsuleGeometry(0.5, 1, 16, 32);
      const mat = this.buildMaterial(obj.material);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      group.add(mesh);

      // If it's player, add visor
      if (obj.id === 'player_character') {
        const visorGeo = new THREE.BoxGeometry(0.5, 0.2, 0.25);
        const visorMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
        const visor = new THREE.Mesh(visorGeo, visorMat);
        visor.position.set(0, 0.4, 0.45);
        group.add(visor);
      }
    } else if (obj.type === 'cylinder') {
      const geo = new THREE.CylinderGeometry(0.5, 0.5, 1, 32);
      const mat = this.buildMaterial(obj.material);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      group.add(mesh);
    } else if (obj.type === 'cone') {
      const geo = new THREE.ConeGeometry(0.5, 1, 32);
      const mat = this.buildMaterial(obj.material);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      group.add(mesh);
    } else if (obj.type === 'plane') {
      const geo = new THREE.PlaneGeometry(1, 1);
      const mat = this.buildMaterial(obj.material);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.receiveShadow = true;
      group.add(mesh);
    } else if (obj.type === 'water') {
      const geo = new THREE.PlaneGeometry(1, 1, 32, 32);
      const mat = new THREE.MeshStandardMaterial({
        color: 0x0284c7,
        metalness: 0.1,
        roughness: 0.1,
        transparent: true,
        opacity: 0.75,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.name = 'AnimatedWaterMesh';
      group.add(mesh);
    } else if (obj.type === 'terrain') {
      // Procedural height terrain
      const geo = new THREE.PlaneGeometry(1, 1, 48, 48);
      geo.rotateX(-Math.PI / 2);
      const posAttr = geo.attributes.position;
      for (let i = 0; i < posAttr.count; i++) {
        const vx = posAttr.getX(i);
        const vz = posAttr.getZ(i);
        // Stylized island height profile
        const dist = Math.sqrt(vx * vx + vz * vz);
        const islandMask = Math.max(0, 1 - dist * 2.2);
        const elevation = (Math.sin(vx * 12) * 0.1 + Math.cos(vz * 12) * 0.1 + Math.sin(vx * 6 + vz * 6) * 0.15) * islandMask;
        posAttr.setY(i, elevation);
      }
      geo.computeVertexNormals();
      const mat = this.buildMaterial(obj.material);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.receiveShadow = true;
      group.add(mesh);
    } else if (obj.type === 'vehicle') {
      // Stylized hover rover
      const bodyMat = this.buildMaterial(obj.material);
      const chassis = new THREE.Mesh(new THREE.BoxGeometry(1, 0.4, 1.6), bodyMat);
      chassis.castShadow = true;
      const cabin = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.4, 0.8), new THREE.MeshStandardMaterial({ color: 0x1e293b }));
      cabin.position.set(0, 0.35, -0.1);
      const wheelGeo = new THREE.CylinderGeometry(0.25, 0.25, 0.2, 16);
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x0f172a });
      const w1 = new THREE.Mesh(wheelGeo, wheelMat);
      w1.rotation.z = Math.PI / 2;
      w1.position.set(0.6, -0.15, 0.5);
      const w2 = w1.clone();
      w2.position.set(-0.6, -0.15, 0.5);
      const w3 = w1.clone();
      w3.position.set(0.6, -0.15, -0.5);
      const w4 = w1.clone();
      w4.position.set(-0.6, -0.15, -0.5);
      group.add(chassis, cabin, w1, w2, w3, w4);
    } else if (obj.type === 'building') {
      const mat = this.buildMaterial(obj.material);
      const baseMesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), mat);
      baseMesh.castShadow = true;
      baseMesh.receiveShadow = true;
      group.add(baseMesh);
    } else if (obj.type === 'npc') {
      // Floating Drone Sentinel
      const coreMat = this.buildMaterial(obj.material);
      const core = new THREE.Mesh(new THREE.SphereGeometry(0.4, 24, 24), coreMat);
      const ringMat = new THREE.MeshStandardMaterial({ color: 0xa855f7, metalness: 0.8, roughness: 0.2 });
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.05, 12, 32), ringMat);
      ring.rotation.x = Math.PI / 2;
      ring.name = 'DroneRing';
      group.add(core, ring);
    } else if (obj.type === 'light_directional') {
      const color = new THREE.Color(obj.lighting?.color || '#ffffff');
      const light = new THREE.DirectionalLight(color, obj.lighting?.intensity ?? 1.5);
      light.castShadow = obj.lighting?.castShadow ?? true;
      light.shadow.mapSize.width = 1024;
      light.shadow.mapSize.height = 1024;
      light.shadow.camera.near = 0.5;
      light.shadow.camera.far = 150;
      light.shadow.camera.left = -30;
      light.shadow.camera.right = 30;
      light.shadow.camera.top = 30;
      light.shadow.camera.bottom = -30;
      group.add(light);

      // Visual helper in editor
      const helperMat = new THREE.MeshBasicMaterial({ color: 0xfacc15, wireframe: true });
      const bulb = new THREE.Mesh(new THREE.OctahedronGeometry(0.5), helperMat);
      bulb.name = 'GizmoHelper';
      group.add(bulb);
    } else if (obj.type === 'light_point') {
      const color = new THREE.Color(obj.lighting?.color || '#ffb74d');
      const light = new THREE.PointLight(color, obj.lighting?.intensity ?? 2.0, obj.lighting?.distance ?? 20);
      light.castShadow = obj.lighting?.castShadow ?? true;
      group.add(light);

      const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 12), new THREE.MeshBasicMaterial({ color: 0xf59e0b }));
      bulb.name = 'GizmoHelper';
      group.add(bulb);
    } else if (obj.type === 'light_spot') {
      const color = new THREE.Color(obj.lighting?.color || '#ffffff');
      const light = new THREE.SpotLight(color, obj.lighting?.intensity ?? 3.0);
      light.angle = (obj.lighting?.angle || 45) * (Math.PI / 180);
      light.castShadow = true;
      group.add(light);

      const coneHelper = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.6, 12), new THREE.MeshBasicMaterial({ color: 0x38bdf8, wireframe: true }));
      coneHelper.name = 'GizmoHelper';
      group.add(coneHelper);
    } else if (obj.type === 'camera') {
      const camHelper = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.4, 0.8), new THREE.MeshBasicMaterial({ color: 0x64748b, wireframe: true }));
      camHelper.name = 'GizmoHelper';
      group.add(camHelper);
    } else if (obj.type === 'audio_source') {
      const speakerHelper = new THREE.Mesh(new THREE.OctahedronGeometry(0.4), new THREE.MeshBasicMaterial({ color: 0x10b981, wireframe: true }));
      speakerHelper.name = 'GizmoHelper';
      group.add(speakerHelper);
    } else {
      // Empty or fallback
      const emptyHelper = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 8), new THREE.MeshBasicMaterial({ color: 0x94a3b8, wireframe: true }));
      emptyHelper.name = 'GizmoHelper';
      group.add(emptyHelper);
    }

    group.position.set(p.x, p.y, p.z);
    group.rotation.set(THREE.MathUtils.degToRad(r.x), THREE.MathUtils.degToRad(r.y), THREE.MathUtils.degToRad(r.z));
    group.scale.set(s.x, s.y, s.z);

    return group;
  }

  public selectObject(id: string | null) {
    this.selectedObjectId = id;
    this.updateSelectionVisuals();
    if (this.onSelectObject) {
      this.onSelectObject(id);
    }
  }

  private updateSelectionVisuals() {
    if (!this.selectedObjectId || !this.objectMeshes.has(this.selectedObjectId) || this.isGameMode) {
      if (this.selectionBox) this.selectionBox.visible = false;
      this.gizmoGroup.visible = false;
      return;
    }

    const targetMesh = this.objectMeshes.get(this.selectedObjectId)!;
    if (this.selectionBox) {
      this.selectionBox.setFromObject(targetMesh);
      this.selectionBox.visible = true;
    }

    this.gizmoGroup.position.copy(targetMesh.position);
    this.gizmoGroup.visible = true;
  }

  private initEventListeners() {
    const el = this.renderer.domElement;

    // Pointer events for desktop & Android 8 touch
    el.addEventListener('pointerdown', this.onPointerDown.bind(this));
    el.addEventListener('pointermove', this.onPointerMove.bind(this));
    el.addEventListener('pointerup', this.onPointerUp.bind(this));
    el.addEventListener('wheel', this.onWheel.bind(this), { passive: false });

    // Touch events for smooth Android 8 pinch zoom
    el.addEventListener('touchstart', this.onTouchStart.bind(this), { passive: false });
    el.addEventListener('touchmove', this.onTouchMove.bind(this), { passive: false });

    // Prevent context menu
    el.addEventListener('contextmenu', (e) => e.preventDefault());

    // Window resize
    window.addEventListener('resize', this.onWindowResize.bind(this));

    // Double click to focus selected object
    el.addEventListener('dblclick', () => {
      this.focusSelected();
    });
  }

  private onPointerDown(e: PointerEvent) {
    if (this.isGameMode) {
      if (e.button === 0 || e.button === 2) {
        this.isGameOrbiting = true;
        this.previousPointerPosition = { x: e.clientX, y: e.clientY };
      }
      return;
    }

    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.previousPointerPosition = { x: e.clientX, y: e.clientY };

    // 1. Check Gizmo Click
    if (this.selectedObjectId && this.gizmoGroup.visible) {
      this.raycaster.setFromCamera(this.mouse, this.camera);
      const gizmoHits = this.raycaster.intersectObjects(this.gizmoGroup.children, true);
      if (gizmoHits.length > 0) {
        let hitObject: THREE.Object3D | null = gizmoHits[0].object;
        while (hitObject && !hitObject.name.startsWith('gizmo_') && hitObject.parent !== this.gizmoGroup) {
          hitObject = hitObject.parent;
        }

        if (hitObject && hitObject.name.startsWith('gizmo_')) {
          this.isDraggingGizmo = true;
          this.activeGizmoAxis = hitObject.name.replace('gizmo_', '') as 'x' | 'y' | 'z';

          // Setup drag plane facing camera
          const normal = new THREE.Vector3();
          this.camera.getWorldDirection(normal).negate();
          this.dragPlane.setFromNormalAndCoplanarPoint(normal, this.gizmoGroup.position);
          this.raycaster.ray.intersectPlane(this.dragPlane, this.planeIntersect);
          return;
        }
      }
    }

    // 2. Middle click or Shift+Left click -> Pan
    if (e.button === 1 || (e.button === 0 && e.shiftKey)) {
      this.isPanning = true;
      return;
    }

    // 3. Right click or Alt+Left click -> Orbit
    if (e.button === 2 || (e.button === 0 && e.altKey)) {
      this.isOrbiting = true;
      return;
    }

    // 4. Standard Left click -> Raycast select object
    if (e.button === 0) {
      this.raycaster.setFromCamera(this.mouse, this.camera);
      const intersects = this.raycaster.intersectObjects(Array.from(this.objectMeshes.values()), true);

      // Filter out helpers
      const validHits = intersects.filter((h) => h.object.name !== 'GizmoHelper' && h.object.name !== 'AnimatedWaterMesh');

      if (validHits.length > 0) {
        let topObj: THREE.Object3D | null = validHits[0].object;
        while (topObj && !topObj.userData?.engineObjectId && topObj.parent !== this.scene) {
          topObj = topObj.parent;
        }
        if (topObj && topObj.userData?.engineObjectId) {
          this.selectObject(topObj.userData.engineObjectId);
          return;
        }
      } else {
        // Orbit if dragged on empty space
        this.isOrbiting = true;
      }
    }
  }

  private onPointerMove(e: PointerEvent) {
    if (this.isGameMode) {
      if (this.isGameOrbiting) {
        const deltaX = e.clientX - this.previousPointerPosition.x;
        const deltaY = e.clientY - this.previousPointerPosition.y;
        this.previousPointerPosition = { x: e.clientX, y: e.clientY };

        this.playerCamYaw -= deltaX * 0.006;
        this.playerCamPitch = Math.max(0.08, Math.min(Math.PI / 2.3, this.playerCamPitch + deltaY * 0.006));
      }
      return;
    }

    const deltaX = e.clientX - this.previousPointerPosition.x;
    const deltaY = e.clientY - this.previousPointerPosition.y;
    this.previousPointerPosition = { x: e.clientX, y: e.clientY };

    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    // Gizmo Dragging Logic
    if (this.isDraggingGizmo && this.selectedObjectId && this.activeGizmoAxis) {
      this.raycaster.setFromCamera(this.mouse, this.camera);
      const currentIntersect = new THREE.Vector3();
      if (this.raycaster.ray.intersectPlane(this.dragPlane, currentIntersect)) {
        const offset = currentIntersect.clone().sub(this.planeIntersect);
        this.planeIntersect.copy(currentIntersect);

        const targetMesh = this.objectMeshes.get(this.selectedObjectId);
        if (targetMesh) {
          const currentPos = targetMesh.position.clone();
          const currentRot = targetMesh.rotation.clone();
          const currentScale = targetMesh.scale.clone();

          if (this.gizmoMode === 'translate') {
            let moveAmount = 0;
            if (this.activeGizmoAxis === 'x') moveAmount = offset.x;
            if (this.activeGizmoAxis === 'y') moveAmount = offset.y;
            if (this.activeGizmoAxis === 'z') moveAmount = offset.z;

            if (this.snapEnabled) {
              const step = this.snapStep;
              currentPos[this.activeGizmoAxis] = Math.round((currentPos[this.activeGizmoAxis] + moveAmount) / step) * step;
            } else {
              currentPos[this.activeGizmoAxis] += moveAmount;
            }
          } else if (this.gizmoMode === 'rotate') {
            const rotSpeed = 0.05;
            const rotAmount = (deltaX + deltaY) * rotSpeed;
            if (this.activeGizmoAxis === 'x') currentRot.x += rotAmount;
            if (this.activeGizmoAxis === 'y') currentRot.y += rotAmount;
            if (this.activeGizmoAxis === 'z') currentRot.z += rotAmount;
          } else if (this.gizmoMode === 'scale') {
            const scaleSpeed = 0.02;
            const scaleFactor = 1 + (deltaX - deltaY) * scaleSpeed;
            currentScale[this.activeGizmoAxis] = Math.max(0.1, currentScale[this.activeGizmoAxis] * scaleFactor);
          }

          targetMesh.position.copy(currentPos);
          targetMesh.rotation.copy(currentRot);
          targetMesh.scale.copy(currentScale);
          this.gizmoGroup.position.copy(currentPos);
          if (this.selectionBox) this.selectionBox.setFromObject(targetMesh);

          if (this.onObjectTransformChange) {
            this.onObjectTransformChange(this.selectedObjectId, {
              position: { x: Number(currentPos.x.toFixed(2)), y: Number(currentPos.y.toFixed(2)), z: Number(currentPos.z.toFixed(2)) },
              rotation: {
                x: Number(THREE.MathUtils.radToDeg(currentRot.x).toFixed(1)),
                y: Number(THREE.MathUtils.radToDeg(currentRot.y).toFixed(1)),
                z: Number(THREE.MathUtils.radToDeg(currentRot.z).toFixed(1)),
              },
              scale: { x: Number(currentScale.x.toFixed(2)), y: Number(currentScale.y.toFixed(2)), z: Number(currentScale.z.toFixed(2)) },
            });
          }
        }
      }
      return;
    }

    if (this.isOrbiting) {
      this.cameraTheta -= deltaX * 0.007;
      this.cameraPhi -= deltaY * 0.007;
      this.updateCameraPosition();
    } else if (this.isPanning) {
      const panSpeed = this.cameraRadius * 0.0015;
      const right = new THREE.Vector3();
      const up = new THREE.Vector3(0, 1, 0);
      this.camera.getWorldDirection(right);
      right.cross(up).normalize();

      this.cameraTarget.addScaledVector(right, -deltaX * panSpeed);
      this.cameraTarget.y += deltaY * panSpeed;
      this.updateCameraPosition();
    }
  }

  private onPointerUp() {
    this.isOrbiting = false;
    this.isPanning = false;
    this.isDraggingGizmo = false;
    this.activeGizmoAxis = null;
    this.isGameOrbiting = false;
  }

  private onWheel(e: WheelEvent) {
    e.preventDefault();
    if (this.isGameMode) return;
    const zoomSpeed = 0.002;
    this.cameraRadius = Math.max(2, Math.min(250, this.cameraRadius + e.deltaY * this.cameraRadius * zoomSpeed));
    this.updateCameraPosition();
  }

  private touchStartDistance = 0;
  private onTouchStart(e: TouchEvent) {
    if (e.touches.length === 2) {
      e.preventDefault();
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      this.touchStartDistance = Math.hypot(dx, dy);
    }
  }

  private onTouchMove(e: TouchEvent) {
    if (e.touches.length === 2 && !this.isGameMode) {
      e.preventDefault();
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      const factor = this.touchStartDistance / Math.max(1, dist);
      this.cameraRadius = Math.max(2, Math.min(200, this.cameraRadius * (factor > 1 ? 1.04 : 0.96)));
      this.touchStartDistance = dist;
      this.updateCameraPosition();
    }
  }

  public onWindowResize() {
    if (!this.container) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / Math.max(1, height);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  public setGameMode(enabled: boolean) {
    this.isGameMode = enabled;
    if (this.selectionBox) this.selectionBox.visible = !enabled && !!this.selectedObjectId;
    this.gizmoGroup.visible = !enabled && !!this.selectedObjectId;
    if (this.gridHelper) this.gridHelper.visible = !enabled && this.showGrid;

    if (enabled) {
      this.playerCamYaw = 0;
      this.playerCamPitch = 0.35;
      // Find player character or fallback
      let player = this.objectMeshes.get('player_character');
      if (!player) {
        // Fallback to first non-terrain mesh
        for (const [id, mesh] of this.objectMeshes.entries()) {
          if (id !== 'main_terrain' && id !== 'water_basin' && !id.startsWith('sun_')) {
            player = mesh;
            break;
          }
        }
      }
      if (player) {
        this.cameraTarget.copy(player.position);
        this.updateCameraPosition();
      }
    } else {
      this.setCameraView('perspective');
    }
  }

  public getTerrainHeightAt(wx: number, wz: number): number {
    const terrainMesh = this.objectMeshes.get('main_terrain');
    if (!terrainMesh) return 0;
    const sx = terrainMesh.scale.x || 60;
    const sy = terrainMesh.scale.y || 4;
    const sz = terrainMesh.scale.z || 60;
    const lx = (wx - terrainMesh.position.x) / sx;
    const lz = (wz - terrainMesh.position.z) / sz;
    const dist = Math.sqrt(lx * lx + lz * lz);
    const islandMask = Math.max(0, 1 - dist * 2.2);
    const elevation = (Math.sin(lx * 12) * 0.1 + Math.cos(lz * 12) * 0.1 + Math.sin(lx * 6 + lz * 6) * 0.15) * islandMask;
    return terrainMesh.position.y + elevation * sy;
  }

  public fireActionPulse() {
    let player = this.objectMeshes.get('player_character');
    if (!player && this.objectMeshes.size > 0) {
      player = Array.from(this.objectMeshes.values())[0];
    }
    if (!player) return;

    const pulseGeom = new THREE.RingGeometry(0.4, 0.6, 32);
    pulseGeom.rotateX(-Math.PI / 2);
    const pulseMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9,
    });
    const pulseMesh = new THREE.Mesh(pulseGeom, pulseMat);
    pulseMesh.position.copy(player.position).add(new THREE.Vector3(0, 0.15, 0));
    this.scene.add(pulseMesh);

    let scale = 1;
    const interval = setInterval(() => {
      scale += 0.45;
      pulseMesh.scale.set(scale, scale, scale);
      pulseMat.opacity -= 0.08;
      if (pulseMat.opacity <= 0) {
        clearInterval(interval);
        this.scene.remove(pulseMesh);
        pulseGeom.dispose();
        pulseMat.dispose();
      }
    }, 16);
  }

  private updateGameSimulation(delta: number) {
    let player = this.objectMeshes.get('player_character');
    if (!player) {
      for (const [id, mesh] of this.objectMeshes.entries()) {
        if (id !== 'main_terrain' && id !== 'water_basin' && !id.startsWith('sun_')) {
          player = mesh;
          break;
        }
      }
    }
    if (!player) return;

    const moveSpeed = 9.5;
    const rotateSpeed = 8.0;

    // Movement relative to camera yaw
    const forward = new THREE.Vector3();
    this.camera.getWorldDirection(forward);
    forward.y = 0;
    forward.normalize();

    const right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();

    const moveDir = new THREE.Vector3()
      .addScaledVector(forward, this.inputMove.forward)
      .addScaledVector(right, this.inputMove.right);

    if (moveDir.lengthSq() > 0.01) {
      moveDir.normalize();
      player.position.addScaledVector(moveDir, moveSpeed * delta);

      // Rotate player towards movement direction
      const targetAngle = Math.atan2(moveDir.x, moveDir.z);
      player.rotation.y = THREE.MathUtils.lerp(player.rotation.y, targetAngle, rotateSpeed * delta);
    }

    // Dynamic ground height based on terrain elevation
    const groundY = this.getTerrainHeightAt(player.position.x, player.position.z) + 0.9;
    if (player.position.y > groundY) {
      this.playerVelocity.y -= 26.0 * delta;
      player.position.y += this.playerVelocity.y * delta;
      if (player.position.y <= groundY) {
        player.position.y = groundY;
        this.playerVelocity.y = 0;
        this.playerOnGround = true;
      }
    } else {
      player.position.y = groundY;
      this.playerVelocity.y = 0;
      this.playerOnGround = true;
    }

    // Jump
    if (this.inputMove.jump && this.playerOnGround) {
      this.playerVelocity.y = 10.0;
      this.playerOnGround = false;
      this.inputMove.jump = false;
    }

    // Smooth Third-Person Camera with 360-degree Orbit
    const camDist = 7.5;
    const camX = Math.sin(this.playerCamYaw) * Math.cos(this.playerCamPitch) * camDist;
    const camY = Math.sin(this.playerCamPitch) * camDist + 1.2;
    const camZ = Math.cos(this.playerCamYaw) * Math.cos(this.playerCamPitch) * camDist;

    const cameraOffset = new THREE.Vector3(camX, camY, camZ);
    const desiredTarget = player.position.clone().add(new THREE.Vector3(0, 1.4, 0));
    this.cameraTarget.lerp(desiredTarget, 0.2);

    const desiredCamPos = this.cameraTarget.clone().add(cameraOffset);
    this.camera.position.lerp(desiredCamPos, 0.2);
    this.camera.lookAt(this.cameraTarget);

    // Animate NPC Sentinel
    const sentinel = this.objectMeshes.get('npc_guardian');
    if (sentinel) {
      const time = this.clock.getElapsedTime();
      sentinel.position.y = 2.2 + Math.sin(time * 2) * 0.4;
      const ring = sentinel.getObjectByName('DroneRing');
      if (ring) {
        ring.rotation.z += delta * 2;
      }
    }
  }

  private animate = () => {
    this.animFrameId = requestAnimationFrame(this.animate);
    const delta = Math.min(this.clock.getDelta(), 0.1);

    // Animate subtle water waves
    const water = this.scene.getObjectByName('AnimatedWaterMesh');
    if (water instanceof THREE.Mesh) {
      const time = this.clock.getElapsedTime();
      water.rotation.z = Math.sin(time * 0.5) * 0.02;
    }

    // Run Game simulation if active
    if (this.isGameMode) {
      this.updateGameSimulation(delta);
    }

    // Render Scene
    this.renderer.render(this.scene, this.camera);

    // Profiler metrics
    this.frames++;
    const now = performance.now();
    if (now >= this.lastTime + 500) {
      this.currentFps = Math.round((this.frames * 1000) / (now - this.lastTime));
      this.currentFrameTime = Number((1000 / Math.max(1, this.currentFps)).toFixed(1));
      this.frames = 0;
      this.lastTime = now;

      if (this.onStatsUpdate) {
        this.onStatsUpdate({
          fps: this.currentFps,
          frameTime: this.currentFrameTime,
          triangles: this.renderer.info.render.triangles,
          drawCalls: this.renderer.info.render.calls,
          objectsCount: this.objectMeshes.size,
          memoryGeometries: this.renderer.info.memory.geometries,
          memoryTextures: this.renderer.info.memory.textures,
          webglVersion: this.webglVersion,
        });
      }
    }
  };

  public destroy() {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
    this.renderer.dispose();
    if (this.container.contains(this.renderer.domElement)) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
