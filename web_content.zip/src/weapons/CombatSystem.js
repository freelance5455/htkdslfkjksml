import * as THREE from 'three';
import { audioManager } from '../audio/AudioManager.js';

export class CombatSystem {
  constructor(scene, player, cameraManager) {
    this.scene = scene;
    this.player = player;
    this.cameraManager = cameraManager;
    this.raycaster = new THREE.Raycaster();

    this.weaponsConfig = {
      handgun: { name: 'VP70 Handgun', damage: 25, headshotMultiplier: 3.0, range: 25, spread: 0.05, maxCap: 15 },
      shotgun: { name: 'W-870 Shotgun', damage: 90, headshotMultiplier: 2.5, range: 10, spread: 0.25, maxCap: 6 },
      magnum: { name: 'Lightning Hawk Magnum', damage: 220, headshotMultiplier: 4.0, range: 35, spread: 0.01, maxCap: 6 },
      knife: { name: 'Combat Knife', damage: 35, headshotMultiplier: 1.5, range: 1.5, spread: 0.0, maxCap: 100 }
    };

    this.muzzleFlashes = [];
  }

  performAttack(enemies) {
    if (this.player.isDead || !this.player.isAiming) return null;

    const weaponKey = this.player.currentWeapon;
    const config = this.weaponsConfig[weaponKey];

    if (weaponKey !== 'knife') {
      if (this.player.ammo[weaponKey] <= 0) {
        audioManager.playUIClick();
        return null;
      }
      this.player.ammo[weaponKey] -= 1;
      audioManager.playGunshot(weaponKey);
      this.cameraManager.addShake(weaponKey === 'magnum' ? 0.35 : weaponKey === 'shotgun' ? 0.25 : 0.12);
      this.createMuzzleFlash();
    } else {
      audioManager.playUIClick();
    }

    // Raycast line of sight aiming forward from player head/chest position
    const origin = this.player.mesh.position.clone().add(new THREE.Vector3(0, 1.2, 0));
    const forward = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.player.mesh.rotation.y);

    // Apply random weapon spread
    forward.x += (Math.random() - 0.5) * config.spread;
    forward.y += (Math.random() - 0.5) * config.spread;
    forward.normalize();

    this.raycaster.set(origin, forward);
    this.raycaster.far = config.range;

    const targetMeshes = [];
    enemies.forEach(e => {
      if (e.mesh && e.isAlive) {
        e.mesh.traverse(child => {
          if (child.isMesh) {
            child.userData.enemyRef = e;
            targetMeshes.push(child);
          }
        });
      }
    });

    const intersects = this.raycaster.intersectObjects(targetMeshes, false);

    if (intersects.length > 0) {
      const hit = intersects[0];
      const enemy = hit.object.userData.enemyRef;

      if (enemy && enemy.isAlive) {
        // Calculate Headshot hit detection
        const isHeadshot = hit.point.y > (enemy.mesh.position.y + 1.2);
        const finalDamage = config.damage * (isHeadshot ? config.headshotMultiplier : 1.0);

        enemy.takeDamage(finalDamage, isHeadshot, forward);

        // Visual blood splatter particles
        this.createBloodImpact(hit.point);

        return { enemy, isHeadshot, damage: finalDamage };
      }
    }

    return null;
  }

  createMuzzleFlash() {
    const flash = new THREE.PointLight(0xffaa33, 5, 4);
    const playerPos = this.player.mesh.position.clone();
    const forward = new THREE.Vector3(0, 0, 0.8).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.player.mesh.rotation.y);
    flash.position.copy(playerPos.add(new THREE.Vector3(0, 1.1, 0)).add(forward));
    
    this.scene.add(flash);
    this.muzzleFlashes.push({ light: flash, life: 0.05 });
  }

  createBloodImpact(pos) {
    const geo = new THREE.SphereGeometry(0.08, 6, 6);
    const mat = new THREE.MeshBasicMaterial({ color: 0x880000 });
    const p = new THREE.Mesh(geo, mat);
    p.position.copy(pos);
    this.scene.add(p);

    setTimeout(() => this.scene.remove(p), 300);
  }

  update(delta) {
    // Clean up temporary muzzle flash lights
    for (let i = this.muzzleFlashes.length - 1; i >= 0; i--) {
      const item = this.muzzleFlashes[i];
      item.life -= delta;
      if (item.life <= 0) {
        this.scene.remove(item.light);
        this.muzzleFlashes.splice(i, 1);
      }
    }
  }
}
