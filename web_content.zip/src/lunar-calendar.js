/** Calendrier civil interne du CGD : aucun mois ni jour terrestre. */
export const LUNAR_YEAR_DAYS = 360;
export const LUNAR_MONTH_DAYS = 30;
export const LUNAR_MONTHS = Object.freeze([
  'Auron','Kelys','Voryn','Zéthar','Névar','Orvys',
  'Thalor','Myzra','Elyon','Drakys','Solvyr','Astréon'
]);
export const LUNAR_WEEKDAYS = Object.freeze([
  'Aster','Veyra','Qoril','Theryn','Myr','Solven','Nyxar'
]);
export const LUNAR_DAY_INDEX = Object.freeze(Object.fromEntries(LUNAR_WEEKDAYS.map((name,index)=>[name.toLocaleLowerCase('fr'),index+1])));

export function getLunarDate(seasonDay) {
  if (!Number.isInteger(seasonDay) || seasonDay < 1) throw new Error('Jour galactique invalide');
  const year = Math.floor((seasonDay - 1) / LUNAR_YEAR_DAYS) + 1;
  const dayOfYear = ((seasonDay - 1) % LUNAR_YEAR_DAYS) + 1;
  const monthIndex = Math.floor((dayOfYear - 1) / LUNAR_MONTH_DAYS);
  const dayOfMonth = ((dayOfYear - 1) % LUNAR_MONTH_DAYS) + 1;
  const weekdayIndex = (seasonDay - 1) % LUNAR_WEEKDAYS.length;
  return {
    year, month: monthIndex + 1, monthName: LUNAR_MONTHS[monthIndex],
    day: dayOfMonth, weekday: LUNAR_WEEKDAYS[weekdayIndex],
    dayOfYear, absoluteDay: seasonDay,
    label: `${LUNAR_WEEKDAYS[weekdayIndex]} ${dayOfMonth} ${LUNAR_MONTHS[monthIndex]} · Cycle ${year}`
  };
}

export function getSeasonDayFromLunarDate({year=1,month,day}) {
  if (![year,month,day].every(Number.isInteger) || year < 1 || month < 1 || month > 12 || day < 1 || day > 30) throw new Error('Date lunaire invalide');
  return (year - 1) * LUNAR_YEAR_DAYS + (month - 1) * LUNAR_MONTH_DAYS + day;
}

export function isLunarWeekday(value, weekdayIndex) {
  return String(value || '').toLocaleLowerCase('fr') === LUNAR_WEEKDAYS[weekdayIndex - 1]?.toLocaleLowerCase('fr');
}
