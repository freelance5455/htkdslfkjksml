export const APP_LOGO = '/src/assets/images/unknown_gamer_logo_1793437689232.jpg';
export const WHATSAPP_SERVICE_NUMBER = '03260715961';
export const WHATSAPP_SERVICE_URL = 'https://wa.me/923260715961';
export const APP_VERSION = 'v2.4.0 Esports Edition';
