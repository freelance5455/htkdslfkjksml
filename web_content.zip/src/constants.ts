import { AppSettings, GameEntry, HudConfig } from './types';

export const APP_EMBLEM_URL = '/src/assets/images/app_emblem_pro_1794985266663.jpg';
export const HERO_RIG_URL = '/src/assets/images/hero_gaming_rig_1794985267491.jpg';

export const DEFAULT_GAMES: GameEntry[] = [
  {
    id: 'bgmi-mobile',
    name: 'Battlegrounds Mobile',
    packageName: 'com.pubg.imobile',
    genre: 'Battle Royale',
    iconUrl: '/src/assets/images/game_battle_royale_1794985267244.jpg',
    launchUrl: 'https://play.google.com/store/apps/details?id=com.pubg.imobile',
    preferences: {
      targetFps: 90,
      gfxPreset: 'smooth',
      dndEnabled: true,
      wakeLockEnabled: true,
      hudEnabled: true,
      audioFocus: 'footsteps',
      powerProfile: 'performance',
    },
  },
  {
    id: 'cod-warzone',
    name: 'Tactical Ops Strike',
    packageName: 'com.activision.callofduty.shooter',
    genre: 'Tactical FPS',
    iconUrl: '/src/assets/images/game_tactical_ops_1794985267701.jpg',
    launchUrl: 'https://play.google.com/store/apps/details?id=com.activision.callofduty.shooter',
    preferences: {
      targetFps: 120,
      gfxPreset: 'smooth',
      dndEnabled: true,
      wakeLockEnabled: true,
      hudEnabled: true,
      audioFocus: 'footsteps',
      powerProfile: 'performance',
    },
  },
  {
    id: 'apex-asphalt',
    name: 'Apex Horizon GT',
    packageName: 'com.gameloft.android.ANMP.GloftA9HM',
    genre: 'Racing',
    iconUrl: '/src/assets/images/game_apex_racing_1794985268182.jpg',
    launchUrl: 'https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftA9HM',
    preferences: {
      targetFps: 60,
      gfxPreset: 'hd',
      dndEnabled: false,
      wakeLockEnabled: true,
      hudEnabled: true,
      audioFocus: 'cinema',
      powerProfile: 'balanced',
    },
  },
];

export const DEFAULT_HUD_CONFIG: HudConfig = {
  enabled: false,
  locked: false,
  corner: 'top-right',
  appearance: 'tactical',
  opacity: 92,
  neonBorder: true,
  showFps: true,
  showRam: true,
  showBattery: true,
  showNetwork: true,
  showShortcuts: true,
};

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  language: 'en',
  notificationsEnabled: true,
  dndAutoPrompt: true,
  shareContextWithAi: true,
  autoRefreshTelemetry: true,
};
