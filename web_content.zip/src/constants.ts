import { ThemeConfig, AccentConfig, FileItem, Assignment } from './types';

export const THEMES: Record<string, ThemeConfig> = {
  'pure-black': {
    id: 'pure-black',
    name: 'Pure Black (AMOLED)',
    isDark: true,
    bg: '#000000',
    surface: '#111111',
    surfaceHover: '#1c1c1c',
    header: '#0d0d0d',
    sidebar: '#080808',
    border: '#262626',
    text: '#ffffff',
    textMuted: '#a3a3a3',
    accent: '#359efe',
    accentText: '#ffffff',
    accentHover: '#2b88e3',
    editorBg: '#000000',
    monacoTheme: 'pure-black-monaco',
  },
  'vscode-dark': {
    id: 'vscode-dark',
    name: 'VS Code Dark+',
    isDark: true,
    bg: '#1e1e1e',
    surface: '#252526',
    surfaceHover: '#2a2d2e',
    header: '#1f1f20',
    sidebar: '#181818',
    border: '#3c3c3c',
    text: '#cccccc',
    textMuted: '#858585',
    accent: '#359efe',
    accentText: '#ffffff',
    accentHover: '#2b88e3',
    editorBg: '#1e1e1e',
    monacoTheme: 'vs-dark',
  },
  'github-dark': {
    id: 'github-dark',
    name: 'GitHub Dark',
    isDark: true,
    bg: '#0d1117',
    surface: '#161b22',
    surfaceHover: '#21262d',
    header: '#161b22',
    sidebar: '#010409',
    border: '#30363d',
    text: '#c9d1d9',
    textMuted: '#8b949e',
    accent: '#359efe',
    accentText: '#ffffff',
    accentHover: '#2b88e3',
    editorBg: '#0d1117',
    monacoTheme: 'github-dark-monaco',
  },
  'github-light': {
    id: 'github-light',
    name: 'GitHub Light',
    isDark: false,
    bg: '#ffffff',
    surface: '#f6f8fa',
    surfaceHover: '#f1f3f5',
    header: '#ffffff',
    sidebar: '#f6f8fa',
    border: '#d0d7de',
    text: '#1f2328',
    textMuted: '#636c76',
    accent: '#359efe',
    accentText: '#ffffff',
    accentHover: '#2b88e3',
    editorBg: '#ffffff',
    monacoTheme: 'github-light-monaco',
  },
  'one-dark-pro': {
    id: 'one-dark-pro',
    name: 'One Dark Pro',
    isDark: true,
    bg: '#282c34',
    surface: '#21252b',
    surfaceHover: '#2c313a',
    header: '#21252b',
    sidebar: '#21252b',
    border: '#181a1f',
    text: '#abb2bf',
    textMuted: '#5c6370',
    accent: '#359efe',
    accentText: '#ffffff',
    accentHover: '#2b88e3',
    editorBg: '#282c34',
    monacoTheme: 'one-dark-pro-monaco',
  },
  'nord': {
    id: 'nord',
    name: 'Nord Dark',
    isDark: true,
    bg: '#2e3440',
    surface: '#3b4252',
    surfaceHover: '#434c5e',
    header: '#3b4252',
    sidebar: '#2e3440',
    border: '#4c566a',
    text: '#eceff4',
    textMuted: '#d8dee9',
    accent: '#359efe',
    accentText: '#ffffff',
    accentHover: '#2b88e3',
    editorBg: '#2e3440',
    monacoTheme: 'nord-monaco',
  },
  'vscode-light': {
    id: 'vscode-light',
    name: 'VS Code Light+',
    isDark: false,
    bg: '#f8f9fa',
    surface: '#ffffff',
    surfaceHover: '#f1f3f5',
    header: '#ffffff',
    sidebar: '#f1f5f9',
    border: '#e2e8f0',
    text: '#0f172a',
    textMuted: '#64748b',
    accent: '#359efe',
    accentText: '#ffffff',
    accentHover: '#2b88e3',
    editorBg: '#ffffff',
    monacoTheme: 'vs',
  },
};

export const ACCENTS: Record<string, AccentConfig> = {
  blue: { id: 'blue', name: 'Sky Blue (#359efe)', color: '#359efe', hover: '#2b88e3', text: '#ffffff' },
  emerald: { id: 'emerald', name: 'Emerald Green (#10b981)', color: '#10b981', hover: '#059669', text: '#ffffff' },
  violet: { id: 'violet', name: 'Royal Violet (#8b5cf6)', color: '#8b5cf6', hover: '#7c3aed', text: '#ffffff' },
  amber: { id: 'amber', name: 'Warm Amber (#f59e0b)', color: '#f59e0b', hover: '#d97706', text: '#ffffff' },
  crimson: { id: 'crimson', name: 'Crimson Red (#ef4444)', color: '#ef4444', hover: '#dc2626', text: '#ffffff' },
  cyan: { id: 'cyan', name: 'Cyan Neon (#06b6d4)', color: '#06b6d4', hover: '#0891b2', text: '#ffffff' },
  indigo: { id: 'indigo', name: 'Indigo (#6366f1)', color: '#6366f1', hover: '#4f46e5', text: '#ffffff' },
};

export const DEFAULT_FILES: FileItem[] = [
  {
    id: 'f1',
    name: 'index.html',
    path: 'index.html',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div id="app">
    <h1>Hello, World!</h1>
    <p>Welcome to <strong>NEXORA Studio</strong>. Start editing code and see live changes instantly!</p>
    <button id="counterBtn">Click Me: 0</button>
  </div>
  <script src="script.js"></script>
</body>
</html>`,
    language: 'html',
  },
  {
    id: 'f2',
    name: 'styles.css',
    path: 'styles.css',
    content: `body {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  margin: 0;
  padding: 2.5rem;
  background-color: #0f172a;
  color: #f8fafc;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  box-sizing: border-box;
}

#app {
  max-width: 540px;
  background: #1e293b;
  padding: 2.5rem;
  border-radius: 1rem;
  border: 1px solid #334155;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.4);
  text-align: center;
}

h1 {
  color: #38bdf8;
  margin-top: 0;
  font-size: 2.25rem;
  font-weight: 800;
}

p {
  color: #94a3b8;
  line-height: 1.6;
}

button {
  margin-top: 1.5rem;
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  font-weight: 600;
  color: #ffffff;
  background-color: #359efe;
  border: none;
  border-radius: 0.5rem;
  cursor: pointer;
  transition: all 0.2s ease;
}

button:hover {
  background-color: #2563eb;
  transform: translateY(-1px);
}`,
    language: 'css',
  },
  {
    id: 'f3',
    name: 'script.js',
    path: 'script.js',
    content: `// JavaScript code
console.log("App loaded successfully in NEXORA Studio!");

let count = 0;
const btn = document.getElementById("counterBtn");

if (btn) {
  btn.addEventListener("click", () => {
    count++;
    btn.textContent = \`Click Me: \${count}\`;
    console.log("Button clicked, count is now:", count);
  });
}`,
    language: 'javascript',
  },
];

export const AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80',
];

export const DEFAULT_CLASS_KEYS = ['CLASS-101', 'CLASS-7803', 'CLASS-7802'];

export const SAMPLE_ASSIGNMENTS: Assignment[] = [
  {
    id: 'assign_sample_1',
    classKey: 'CLASS-101',
    teacherId: 'teacher_sample',
    teacherName: 'amaan',
    title: 'Build a Personal Portfolio Page',
    description: 'Create a responsive web page with a modern hero header, an About section, showcase project cards, and a working contact button.',
    requiredTech: 'html-css',
    attachments: [
      {
        id: 'att_1',
        title: 'Sample Portfolio Layout Reference',
        type: 'image',
        urlOrContent: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80',
      },
    ],
    initialTemplateFiles: [
      {
        id: 'tpl_f1',
        name: 'index.html',
        path: 'index.html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Portfolio</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header class="header">
    <div class="logo">amaan</div>
    <nav class="nav">
      <a href="#about">About</a>
      <a href="#projects">Projects</a>
      <a href="#contact">Contact</a>
    </nav>
  </header>
  
  <section class="hero">
    <h1>Frontend Developer & Designer</h1>
    <p>Building delightful, responsive experiences for the modern web.</p>
  </section>

  <section id="projects" class="projects">
    <h2>Featured Works</h2>
    <div class="grid">
      <div class="card">
        <h3>Project One</h3>
        <p>Interactive web dashboard built with vanilla web technologies.</p>
      </div>
      <div class="card">
        <h3>Project Two</h3>
        <p>Creative design portfolio featuring animations and smooth transitions.</p>
      </div>
    </div>
  </section>
</body>
</html>`,
        language: 'html',
      },
      {
        id: 'tpl_f2',
        name: 'styles.css',
        path: 'styles.css',
        content: `* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: sans-serif; background: #0f172a; color: #f8fafc; line-height: 1.6; }
.header { display: flex; justify-content: space-between; align-items: center; padding: 1.5rem 2rem; border-bottom: 1px solid #334155; }
.logo { font-size: 1.25rem; font-weight: 700; color: #38bdf8; }
.nav a { color: #94a3b8; text-decoration: none; margin-left: 1.5rem; font-weight: 500; }
.hero { text-align: center; padding: 4rem 1rem; }
.hero h1 { font-size: 2.5rem; margin-bottom: 1rem; color: #ffffff; }
.projects { max-width: 900px; margin: 0 auto; padding: 2rem; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-top: 1.5rem; }
.card { background: #1e293b; padding: 1.5rem; border-radius: 0.75rem; border: 1px solid #334155; }`,
        language: 'css',
      },
    ],
    createdAt: new Date().toISOString(),
  },
];
