export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  createdAt: string;
  error?: boolean;
}

export interface AiRequestPayload {
  deviceId: string;
  messages: { role: "user" | "assistant"; content: string }[];
}

export interface AiResponsePayload {
  reply: string;
  // Optional: a backend MAY report how many requests remain today if it
  // enforces quota server-side, so the frontend can display the
  // authoritative number instead of (or alongside) its local estimate.
  remainingToday?: number;
  resetAt?: string;
}

export type AiCallOutcome =
  | { ok: true; reply: string; remainingToday?: number; resetAt?: string }
  | { ok: false; errorType: "not_configured" | "quota_exceeded" | "network" | "timeout" | "server_error" | "auth_required"; message: string };
