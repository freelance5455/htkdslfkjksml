import { AI_MODEL, AI_REQUEST_TIMEOUT_MS, MAX_CONTEXT_MESSAGES } from "./config";
import type { AiCallOutcome, ChatMessage } from "./types";

// ---------------------------------------------------------------------------
// Real AI Tutor via Puter.js — no backend, no API key.
//
// Puter.js (loaded in index.html) lets the browser call real AI models
// (OpenAI, Anthropic, Google, etc.) directly. Each user covers their own
// usage by signing in with a free Puter.com account ("User-Pays" model), so
// this never requires FormulaVerse's developer to hold or expose a secret
// API key. The sign-in popup is a one-time step per browser.
// ---------------------------------------------------------------------------

function getPuter() {
  return typeof window !== "undefined" ? window.puter : undefined;
}

export function isPuterScriptLoaded(): boolean {
  return Boolean(getPuter());
}

export function isPuterSignedIn(): boolean {
  try {
    return Boolean(getPuter()?.auth.isSignedIn());
  } catch {
    return false;
  }
}

export async function getPuterUsername(): Promise<string | null> {
  const puter = getPuter();
  if (!puter || !puter.auth.isSignedIn()) return null;
  try {
    const user = await puter.auth.getUser();
    return user?.username ?? null;
  } catch {
    return null;
  }
}

/** Opens Puter's sign-in popup. Must be called from a direct user action
 *  (e.g. a button's onClick) — browsers block popups opened otherwise. */
export async function connectPuter(): Promise<{ ok: true; username: string | null } | { ok: false; message: string }> {
  const puter = getPuter();
  if (!puter) {
    return { ok: false, message: "The AI engine hasn't finished loading yet. Please wait a moment and try again, or reload the page." };
  }
  try {
    await puter.auth.signIn();
    const username = await getPuterUsername();
    return { ok: true, username };
  } catch (err: any) {
    const code = typeof err === "string" ? err : err?.message || err?.error || "";
    if (/popup_blocked/i.test(code)) {
      return { ok: false, message: "Your browser blocked the sign-in popup. Please allow popups for this site and click Connect again." };
    }
    if (/auth_window_closed/i.test(code)) {
      return { ok: false, message: "Sign-in was closed before finishing. Click Connect AI Tutor to try again." };
    }
    return { ok: false, message: "Couldn't sign in right now. Please check your connection and try again." };
  }
}

export function disconnectPuter(): void {
  try {
    getPuter()?.auth.signOut();
  } catch {
    /* ignore */
  }
}

function extractReplyText(response: any): string | null {
  if (typeof response === "string") return response;
  if (!response) return null;
  const content = response.message?.content ?? response.content;
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    const text = content.map((c: any) => (typeof c === "string" ? c : c?.text ?? "")).join("");
    if (text) return text;
  }
  if (typeof response.text === "string") return response.text;
  return null;
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("timeout")), ms);
    promise.then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      }
    );
  });
}

export async function askPuterTutor(system: string, history: ChatMessage[], question: string): Promise<AiCallOutcome> {
  const puter = getPuter();
  if (!puter) {
    return {
      ok: false,
      errorType: "not_configured",
      message: "The AI engine hasn't finished loading. Check your internet connection and reload the page.",
    };
  }

  const recentHistory = history.slice(-MAX_CONTEXT_MESSAGES).map((m) => ({
    role: m.role === "assistant" ? "assistant" : "user",
    content: m.content,
  }));
  const messages = [{ role: "system", content: system }, ...recentHistory, { role: "user", content: question }];

  try {
    const response = await withTimeout(puter.ai.chat(messages, { model: AI_MODEL }), AI_REQUEST_TIMEOUT_MS);
    const text = extractReplyText(response);
    if (!text) {
      return { ok: false, errorType: "server_error", message: "The AI Tutor responded without any readable content. Please try again." };
    }
    return { ok: true, reply: text };
  } catch (err: any) {
    if (err?.message === "timeout") {
      return { ok: false, errorType: "timeout", message: "The AI Tutor took too long to respond. Please try again." };
    }
    const msg: string = typeof err === "string" ? err : err?.message || err?.error?.message || "";
    if (/auth|sign.?in|not.?signed/i.test(msg)) {
      return { ok: false, errorType: "auth_required", message: "Please connect/sign in to the AI Tutor first using the Connect button." };
    }
    if (/usage|limit|quota|credit|insufficient/i.test(msg)) {
      return {
        ok: false,
        errorType: "quota_exceeded",
        message: "Your Puter account's AI usage allowance has been reached for now. Please try again later.",
      };
    }
    return {
      ok: false,
      errorType: "network",
      message: msg ? `AI Tutor error: ${msg}` : "Couldn't reach the AI engine. Check your internet connection and try again.",
    };
  }
}
