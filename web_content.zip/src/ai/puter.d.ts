// Minimal type declarations for the Puter.js global, loaded via the
// <script src="https://js.puter.com/v2/"> tag in index.html. Puter.js
// attaches itself to `window.puter`; we deliberately type it loosely (its
// full surface is large and only a small part is used here).
export {};

declare global {
  interface Window {
    puter?: {
      ai: {
        chat: (
          input: string | Array<{ role: string; content: string }>,
          options?: Record<string, unknown>
        ) => Promise<any>;
      };
      auth: {
        signIn: (options?: Record<string, unknown>) => Promise<unknown>;
        signOut: () => void;
        isSignedIn: () => boolean;
        getUser: () => Promise<{ username?: string } | undefined>;
      };
      print: (value: unknown) => void;
    };
  }
}
