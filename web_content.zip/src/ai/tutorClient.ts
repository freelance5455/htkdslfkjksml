import { AI_REQUEST_TIMEOUT_MS, AI_TUTOR_ENDPOINT, MAX_CONTEXT_MESSAGES } from "./config";
import { askPuterTutor } from "./puterClient";
import type { AiCallOutcome, ChatMessage } from "./types";

export interface TutorContext {
  board?: string;
  classLevel?: number;
  subject?: string;
  chapter?: string;
}

const BASE_SYSTEM_PRIMER =
  "You are the FormulaVerse AI Tutor, helping Indian school students in Class 8, 9 or 10 with Mathematics, Physics and Chemistry " +
  "(CBSE/NCERT or ICSE/CISCE curricula). Follow these rules strictly:\n" +
  "1. Explain concepts in simple, student-friendly language appropriate to the student's class.\n" +
  "2. For numerical/word problems, give complete step-by-step working: state what is given, what must be found, which formula or " +
  "theorem applies and why, each calculation step, the final answer clearly separated, and a quick verification (substitution or " +
  "sanity check) when possible.\n" +
  "3. For geometry questions, correctly interpret angle notation such as ∠ACD or ∠BAE (the middle letter is always the vertex), " +
  "triangle/circle theorems, congruence and similarity criteria, and constructions. Never assume a figure is drawn to scale, and " +
  "never invent a given angle, length, or condition that was not stated — ask the student to clarify instead.\n" +
  "4. Use plain-text math notation (e.g. x^2, sqrt(x), degrees as °, fractions as a/b) since the interface does not render LaTeX.\n" +
  "5. If a question is ambiguous or missing information, ask a clarifying question instead of guessing.\n" +
  "6. Be honest about uncertainty: if you are not confident about a fact, syllabus detail, or formula, say so plainly rather than " +
  "presenting a guess as settled fact. Never fabricate a theorem, formula, textbook citation, or syllabus claim.\n" +
  "7. After a full explanation, briefly ask if the student would like a simpler explanation or another example, when that seems useful.\n" +
  "8. Keep answers focused and appropriately concise for a mobile screen — use short paragraphs and numbered steps rather than dense walls of text.";

function buildSystemPrompt(context?: TutorContext): string {
  if (!context || (!context.board && !context.classLevel && !context.subject && !context.chapter)) {
    return BASE_SYSTEM_PRIMER;
  }
  const parts: string[] = [];
  if (context.board) parts.push(`Board: ${context.board}`);
  if (context.classLevel) parts.push(`Class: ${context.classLevel}`);
  if (context.subject) parts.push(`Subject: ${context.subject}`);
  if (context.chapter) parts.push(`Chapter: ${context.chapter}`);
  return (
    BASE_SYSTEM_PRIMER +
    `\n\nCurrent study context selected by the student: ${parts.join(", ")}. Tailor explanations, terminology and difficulty to this ` +
    "context when relevant, but still answer helpfully if the student asks about something outside it."
  );
}

/**
 * Gets a reply from the AI Tutor.
 *
 * By default (no setup needed) this calls Puter.js directly from the
 * browser — a real AI model, no backend, no API key (see puterClient.ts).
 *
 * If VITE_AI_TUTOR_ENDPOINT is set, FormulaVerse instead calls that
 * self-hosted backend (the original/advanced path, preserved exactly as
 * before, useful if you want a hard server-enforced daily quota).
 */
export async function askAiTutor(deviceId: string, history: ChatMessage[], question: string, context?: TutorContext): Promise<AiCallOutcome> {
  const system = buildSystemPrompt(context);

  if (!AI_TUTOR_ENDPOINT) {
    return askPuterTutor(system, history, question);
  }

  const recentHistory = history.slice(-MAX_CONTEXT_MESSAGES).map((m) => ({ role: m.role === "assistant" ? ("assistant" as const) : ("user" as const), content: m.content }));

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), AI_REQUEST_TIMEOUT_MS);

  try {
    const res = await fetch(AI_TUTOR_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        deviceId,
        system,
        context,
        messages: [...recentHistory, { role: "user", content: question }],
      }),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (res.status === 429) {
      const data = await safeJson(res);
      return {
        ok: false,
        errorType: "quota_exceeded",
        message: data?.message ?? "The daily AI quota has been reached for this account/device. Please try again after the reset time.",
      };
    }

    if (!res.ok) {
      const data = await safeJson(res);
      return { ok: false, errorType: "server_error", message: data?.message ?? `The AI backend returned an error (status ${res.status}).` };
    }

    const data = await safeJson(res);
    if (!data?.reply) {
      return { ok: false, errorType: "server_error", message: "The AI backend responded without any content. Please try again." };
    }

    return { ok: true, reply: data.reply, remainingToday: data.remainingToday, resetAt: data.resetAt };
  } catch (err: any) {
    clearTimeout(timeout);
    if (err?.name === "AbortError") {
      return { ok: false, errorType: "timeout", message: "The AI Tutor took too long to respond. Please try again." };
    }
    return { ok: false, errorType: "network", message: "Couldn't reach the AI backend. Check your internet connection and try again." };
  }
}

async function safeJson(res: Response): Promise<any> {
  try {
    return await res.json();
  } catch {
    return null;
  }
}
