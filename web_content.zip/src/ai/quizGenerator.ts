import { AI_MODEL, AI_REQUEST_TIMEOUT_MS } from "./config";
import type { ClassLevel, Subject } from "../data/types";
import type { Difficulty, QuizQuestion } from "../data/quiz";

// ---------------------------------------------------------------------------
// Honest AI quiz question generation.
//
// This ONLY runs when the student explicitly asks for an AI-generated
// question. The result is strictly validated before being shown — if the
// model's output doesn't parse into a well-formed multiple-choice question
// with a valid answer index, we return null (never show a malformed or
// fabricated question labeled as "AI-generated"). Callers must keep using
// the verified stored question bank as the default/fallback.
// ---------------------------------------------------------------------------

function getPuter() {
  return typeof window !== "undefined" ? window.puter : undefined;
}

function extractText(response: any): string | null {
  if (typeof response === "string") return response;
  const content = response?.message?.content ?? response?.content;
  if (typeof content === "string") return content;
  if (Array.isArray(content)) return content.map((c: any) => (typeof c === "string" ? c : c?.text ?? "")).join("");
  if (typeof response?.text === "string") return response.text;
  return null;
}

function tryParseQuestion(raw: string, classLevel: ClassLevel, subject: Subject, difficulty: Difficulty): QuizQuestion | null {
  let jsonText = raw.trim();
  const fenceMatch = jsonText.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenceMatch) jsonText = fenceMatch[1].trim();
  const braceStart = jsonText.indexOf("{");
  const braceEnd = jsonText.lastIndexOf("}");
  if (braceStart === -1 || braceEnd === -1) return null;
  jsonText = jsonText.slice(braceStart, braceEnd + 1);

  let parsed: any;
  try {
    parsed = JSON.parse(jsonText);
  } catch {
    return null;
  }

  const question = typeof parsed.question === "string" ? parsed.question.trim() : "";
  const options = Array.isArray(parsed.options) ? parsed.options.map((o: unknown) => String(o).trim()) : [];
  const correctIndex = Number(parsed.correctIndex);
  const explanation = typeof parsed.explanation === "string" ? parsed.explanation.trim() : "";
  const topic = typeof parsed.topic === "string" ? parsed.topic.trim() : "AI-generated";

  // Strict validation — reject anything malformed rather than guessing.
  if (!question || question.length < 5) return null;
  if (options.length !== 4 || options.some((o: string) => !o)) return null;
  if (!Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex > 3) return null;
  if (!explanation || explanation.length < 5) return null;
  const uniqueOptions = new Set(options.map((o: string) => o.toLowerCase()));
  if (uniqueOptions.size !== options.length) return null;

  return {
    id: `ai-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
    classLevel,
    subject,
    difficulty,
    topic,
    question,
    options,
    correctIndex,
    explanation,
    source: "ai",
  };
}

export interface QuizGenResult {
  ok: boolean;
  question?: QuizQuestion;
  error?: string;
}

export async function generateAiQuizQuestion(board: string, classLevel: ClassLevel, subject: Subject, difficulty: Difficulty): Promise<QuizGenResult> {
  const puter = getPuter();
  if (!puter) {
    return { ok: false, error: "The AI engine isn't available right now. Please use a question from the verified bank instead." };
  }

  const prompt =
    `Create ONE multiple-choice question for a ${board} Class ${classLevel} ${subject} student, ${difficulty} difficulty, appropriate to the ` +
    `standard school syllabus. Respond with ONLY a single valid JSON object (no markdown, no extra commentary) in exactly this shape: ` +
    `{"topic": "short topic name", "question": "the question text", "options": ["optA","optB","optC","optD"], "correctIndex": 0, "explanation": "why the correct answer is correct"}. ` +
    `The "options" array must have exactly 4 distinct choices, and "correctIndex" must be the 0-based index of the correct one. ` +
    `Do not include any text outside the JSON object. Make sure the question and answer are factually and mathematically correct.`;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), AI_REQUEST_TIMEOUT_MS);
    const response = await puter.ai.chat([{ role: "user", content: prompt }], { model: AI_MODEL });
    clearTimeout(timeout);

    const text = extractText(response);
    if (!text) return { ok: false, error: "The AI didn't return a usable response. Please try again or use a bank question." };

    const parsedQuestion = tryParseQuestion(text, classLevel, subject, difficulty);
    if (!parsedQuestion) {
      return { ok: false, error: "The AI's response couldn't be validated as a well-formed question, so it was discarded. Please try again or use a bank question." };
    }
    return { ok: true, question: parsedQuestion };
  } catch (err: any) {
    const msg = typeof err === "string" ? err : err?.message || "";
    if (/auth|sign.?in/i.test(msg)) {
      return { ok: false, error: "Please connect to the AI Tutor first (see the AI Tutor screen), then try again." };
    }
    return { ok: false, error: "Couldn't generate an AI question right now. Please use a bank question instead." };
  }
}
