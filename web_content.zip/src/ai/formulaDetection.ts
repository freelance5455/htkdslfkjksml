import { allFormulas } from "../data";
import { KNOWLEDGE_BASE } from "../solver/knowledgeBase";
import type { FormulaUsage } from "../solver/types";

/**
 * Scans a block of text (an AI Tutor reply) for mentions of formulas or
 * theorems that already exist in FormulaVerse's own library or built-in
 * knowledge base, and returns usage records for any genuine matches. This
 * is deliberately conservative — it only recognises formulas FormulaVerse
 * already knows about, so Formula History never records something that
 * wasn't actually a known, verified entry.
 */
export function detectKnownFormulas(text: string): FormulaUsage[] {
  const lower = text.toLowerCase();
  const found: FormulaUsage[] = [];
  const seen = new Set<string>();

  for (const f of allFormulas) {
    const nameLower = f.name.toLowerCase();
    if (nameLower.length > 4 && lower.includes(nameLower) && !seen.has(f.id)) {
      seen.add(f.id);
      found.push({
        name: f.name,
        expression: f.expression,
        subject: f.subject,
        topic: f.topic,
        classLevel: f.classLevel,
        explanation: f.explanation,
        example: f.example,
        formulaId: f.id,
      });
    }
  }

  for (const [key, kb] of Object.entries(KNOWLEDGE_BASE)) {
    const nameLower = kb.name.toLowerCase();
    if (nameLower.length > 4 && lower.includes(nameLower) && !seen.has(key)) {
      seen.add(key);
      found.push(kb);
    }
  }

  return found.slice(0, 5);
}
