// Central, easily-adjustable configuration for the AI Tutor feature.
//
// Two ways the AI Tutor can be powered (see AI_TUTOR_SETUP.md for full detail):
//
//   1. "puter" (DEFAULT, already active, zero setup) — the browser calls a
//      real AI model directly via Puter.js (loaded in index.html). There is
//      no backend and no API key anywhere in this project; each user covers
//      their own usage with a free Puter.com account (the "User-Pays"
//      model), so this costs the FormulaVerse developer nothing.
//
//   2. "custom" (advanced/optional) — if you deploy your own backend (e.g.
//      to get a hard, server-enforced daily quota instead of the local
//      device-based counter), set VITE_AI_TUTOR_ENDPOINT and the app will
//      use that instead. This path is unchanged from before and still works
//      exactly as documented in AI_TUTOR_SETUP.md.

/** URL of a self-hosted backend endpoint (optional, advanced path). When
 *  unset (the default), FormulaVerse uses Puter.js directly — no setup
 *  required. */
export const AI_TUTOR_ENDPOINT = (import.meta as any).env?.VITE_AI_TUTOR_ENDPOINT as string | undefined;

/** Which AI Tutor engine is active. */
export const AI_PROVIDER: "puter" | "custom" = AI_TUTOR_ENDPOINT ? "custom" : "puter";

/** The AI model used for the Puter.js path. Configurable without touching
 *  code via VITE_AI_MODEL. "openai/gpt-4o-mini" is a fast, capable, widely
 *  available default — change to e.g. "anthropic/claude-haiku-4.5" or
 *  "google/gemini-3.8-flash" if you prefer another provider's model. */
export const AI_MODEL = ((import.meta as any).env?.VITE_AI_MODEL as string | undefined) || "openai/gpt-4o-mini";

/** Default number of AI messages allowed per device, per day. This is a
 *  courtesy/app-level limit tracked in this browser — independent of any
 *  usage limits your Puter.com account itself may have. Configurable via
 *  VITE_AI_DAILY_LIMIT without touching any code. */
export const DEFAULT_DAILY_LIMIT = Number((import.meta as any).env?.VITE_AI_DAILY_LIMIT) || 10;

/** Request timeout for AI calls, in milliseconds. */
export const AI_REQUEST_TIMEOUT_MS = 30000;

/** Maximum number of prior messages sent as conversation context, to keep
 *  requests small and bounded (avoids unbounded growth / excessive cost). */
export const MAX_CONTEXT_MESSAGES = 10;

/** True once an AI engine is wired up at all (always true now — either
 *  Puter.js by default, or a custom backend if configured). */
export const AI_BACKEND_CONFIGURED = true;
