/* ==========================================================================
   utils.js — ابزارهای پایه: اعداد، پول، تاریخ جلالی، کمکی‌ها
   ========================================================================== */

export const FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toFaDigits(input) {
  return String(input).replace(/\d/g, (d) => FA_DIGITS[+d]);
}
export function toEnDigits(input) {
  const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
  return String(input)
    .replace(/[۰-۹]/g, (d) => String(fa.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String(ar.indexOf(d)));
}

export function uid(prefix = 'id') {
  return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

export function clamp(n, min, max) { return Math.min(max, Math.max(min, n)); }
export function round(n, d = 0) { const f = Math.pow(10, d); return Math.round((+n + Number.EPSILON) * f) / f; }
export function sum(arr, fn = (x) => x) { return (arr || []).reduce((a, b) => a + (Number(fn(b)) || 0), 0); }
export function safeDiv(a, b) { return b ? a / b : 0; }
export function pct(x, d = 0) { return toFaDigits(round((Number(x) || 0) * 100, d)) + '٪'; }
export function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
export function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
export function hashStr(str) {
  let h = 2166136261;
  const s = String(str);
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return Math.abs(h);
}
/** انتخاب شبه‌تصادفی پایدار بر اساس کلید (برای Daily Wisdom و ...) */
export function pickStable(arr, key) { return arr[hashStr(key) % arr.length]; }

/* ------------------------------------------------------------------ numbers */
export function fmtInt(n) {
  const v = Math.round(Number(n) || 0);
  const s = Math.abs(v).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '٬');
  return (v < 0 ? '−' : '') + toFaDigits(s);
}
export const CURRENCIES = {
  IRT: { fa: 'تومان', code: 'IRT' },
  IRR: { fa: 'ریال', code: 'IRR' },
  USD: { fa: 'دلار', code: 'USD' },
  EUR: { fa: 'یورو', code: 'EUR' },
  AFN: { fa: 'افغانی', code: 'AFN' },
  AED: { fa: 'درهم', code: 'AED' },
  TRY: { fa: 'لیر', code: 'TRY' },
  OTHER: { fa: 'واحد سفارشی', code: 'OTHER' },
};

export function currencyLabel(profile) {
  const c = profile && profile.currency;
  if (!c) return 'تومان';
  if (c === 'OTHER') return profile.currencyLabel || 'واحد';
  return (CURRENCIES[c] && CURRENCIES[c].fa) || 'تومان';
}

/** نمایش خوانا: ۱٫۲ میلیارد تومان */
export function fmtCompact(n, profile) {
  const v = Number(n) || 0;
  const unit = currencyLabel(profile);
  const abs = Math.abs(v);
  const sign = v < 0 ? '−' : '';
  let out;
  if (abs >= 1e12) out = round(abs / 1e12, 2) + ' هزار میلیارد';
  else if (abs >= 1e9) out = round(abs / 1e9, 2) + ' میلیارد';
  else if (abs >= 1e6) out = round(abs / 1e6, 2) + ' میلیون';
  else if (abs >= 1e4) out = round(abs / 1e3, 0) + ' هزار';
  else out = fmtInt(abs);
  return sign + toFaDigits(String(out)).replace('.', '٫') + ' ' + unit;
}

/** عدد کوتاه برای نمودار */
export function fmtShort(n) {
  const v = Math.abs(Number(n) || 0);
  if (v >= 1e9) return toFaDigits(round(v / 1e9, 1)) + 'B';
  if (v >= 1e6) return toFaDigits(round(v / 1e6, 1)) + 'M';
  if (v >= 1e3) return toFaDigits(round(v / 1e3, 1)) + 'K';
  return toFaDigits(round(v, 0));
}

/** تبدیل ورودی کاربر به عدد: «۲٬۵۰۰٬000» , «2.5 میلیون» , «20m» */
export function parseNum(input) {
  if (input == null) return 0;
  let s = toEnDigits(String(input)).trim().replace(/[،,\s_]/g, '');
  const faWords = [
    [/میلیارد|بلیون|miliard/g, 1e9],
    [/میلیون/m, 1e6],
  ];
  let mult = 1;
  if (/میلیارد|بلیون/.test(s)) mult = 1e9;
  else if (/میلیون/.test(s)) mult = 1e6;
  else if (/هزار/.test(s)) mult = 1e3;
  s = s.replace(/میلیارد|میلیون|هزار|تومان|دلار|یورو|ریال/g, '');
  if (/k$/i.test(s)) { mult = 1e3; s = s.slice(0, -1); }
  if (/m$/i.test(s)) { mult = 1e6; s = s.slice(0, -1); }
  if (/b$/i.test(s)) { mult = 1e9; s = s.slice(0, -1); }
  const n = parseFloat(s.replace(/[^\d.\-]/g, ''));
  void faWords;
  return isNaN(n) ? 0 : n * mult;
}

/* ------------------------------------------------------------ جلالی (Persian calendar) */
const div = (a, b) => ~~(a / b);
const mod = (a, b) => a - ~~(a / b) * b;

function jalCal(jy) {
  const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
  const bl = breaks.length, gy = jy + 621;
  let leapJ = -14, jp = breaks[0], jm, jump = 0, n, i;
  if (jy < jp || jy >= breaks[bl - 1]) jy = clamp(jy, jp + 1, breaks[bl - 1] - 1);
  for (i = 1; i < bl; i += 1) {
    jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  n = jy - jp;
  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}
function g2d(gy, gm, gd) {
  let d = div((gy + div(gm - 8, 6) + 100100) * 1461, 4) + div(153 * mod(gm + 9, 12) + 2, 5) + gd - 34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}
function d2g(jdn) {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}
export function toJalali(date) {
  const d = date instanceof Date ? date : new Date(date);
  const jdn = g2d(d.getFullYear(), d.getMonth() + 1, d.getDate());
  const g = d2g(jdn);
  let jy = g.gy - 621, k;
  const r = jalCal(jy);
  const jdn1f = g2d(g.gy, 3, r.march);
  k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) return { jy, jm: 1 + div(k, 31), jd: mod(k, 31) + 1 };
    k -= 186;
  } else { jy -= 1; k += 179; if (r.leap === 1) k += 1; }
  return { jy, jm: 7 + div(k, 30), jd: mod(k, 30) + 1 };
}
export function toGregorian(jy, jm, jd) {
  const r = jalCal(jy);
  const jdn = g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
  const g = d2g(jdn);
  return new Date(g.gy, g.gm - 1, g.gd);
}
export const J_MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
/** شنبه = 0 ... جمعه = 6 */
export const J_DOW = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];
export function jalaliMonthLength(jy, jm) {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return jalCal(jy).leap === 0 ? 30 : 29;
}
/** کلید استاندارد تاریخ: YYYY-MM-DD میلادی */
export function dateKey(d) {
  const t = d instanceof Date ? d : new Date(d);
  return t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0');
}
export function todayKey() { return dateKey(new Date()); }
export function fromKey(key) {
  const p = String(key).split('-').map(Number);
  return new Date(p[0], (p[1] || 1) - 1, p[2] || 1);
}
export function addDays(key, n) {
  const d = fromKey(key);
  d.setDate(d.getDate() + n);
  return dateKey(d);
}
export function daysBetween(a, b) {
  return Math.round((fromKey(b) - fromKey(a)) / 86400000);
}
/** شنبه‌ی هفته */
export function startOfWeek(key) {
  const d = fromKey(key);
  const dow = d.getDay(); // 0=Sun..6=Sat
  const shift = (dow + 1) % 7; // Sat=0
  d.setDate(d.getDate() - shift);
  return dateKey(d);
}
export function monthKeyOf(key) { return String(key).slice(0, 7); }
export function currentMonthKey() { return monthKeyOf(todayKey()); }
export function prevMonthKey(mk) {
  const [y, m] = mk.split('-').map(Number);
  const d = new Date(y, m - 2, 1);
  return dateKey(d).slice(0, 7);
}
export function addMonthsKey(mk, n) {
  const [y, m] = mk.split('-').map(Number);
  const d = new Date(y, m - 1 + n, 1);
  return dateKey(d).slice(0, 7);
}
export function jalaliMonthKey(key) {
  const j = toJalali(fromKey(key));
  return j.jy + '-' + String(j.jm).padStart(2, '0');
}
export function faDate(key, opts = {}) {
  if (!key) return '—';
  const j = toJalali(fromKey(key));
  const base = toFaDigits(j.jd) + ' ' + J_MONTHS[j.jm - 1] + (opts.withYear === false ? '' : ' ' + toFaDigits(j.jy));
  if (opts.withWeekday) return J_DOW[(fromKey(key).getDay() + 1) % 7] + ' ' + base;
  return base;
}
export function faMonthLabel(mk) {
  const [gy, gm] = mk.split('-').map(Number);
  const j = toJalali(new Date(gy, gm - 1, 15));
  return J_MONTHS[j.jm - 1] + ' ' + toFaDigits(j.jy);
}
export function weekdayIndex(key) { return (fromKey(key).getDay() + 1) % 7; } // 0=شنبه
export function isFriday(key) { return weekdayIndex(key) === 6; }

/** شبکه تقویم ماه جلالی: آرایه‌ای از {key, jd, isToday, holiday} */
export function jalaliMonthGrid(jy, jm, selectedKey) {
  const len = jalaliMonthLength(jy, jm);
  const first = toGregorian(jy, jm, 1);
  const offset = (first.getDay() + 1) % 7; // شنبه=0
  const cells = [];
  for (let i = 0; i < offset; i++) cells.push({ empty: true });
  const tk = todayKey();
  for (let d = 1; d <= len; d++) {
    const g = toGregorian(jy, jm, d);
    const key = dateKey(g);
    cells.push({ key, jd: d, isToday: key === tk, selected: key === selectedKey, holiday: weekdayIndex(key) === 6 });
  }
  return cells;
}

/* ------------------------------------------------------------------ misc */
export function downloadJSON(filename, obj) {
  const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 800);
}
export function readFileText(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result || ''));
    r.onerror = () => reject(new Error('خطا در خواندن فایل'));
    r.readAsText(file);
  });
}
export function deepMerge(base, patch) {
  if (Array.isArray(patch)) return patch.slice();
  if (patch && typeof patch === 'object') {
    const out = base && typeof base === 'object' && !Array.isArray(base) ? { ...base } : {};
    Object.keys(patch).forEach((k) => { out[k] = deepMerge(out[k], patch[k]); });
    return out;
  }
  return patch === undefined ? base : patch;
}
export function vibrate(ms = 12) { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) { void e; } }
export function pluralFa(n, one, many) { return (Number(n) === 1 ? one : many).replace('#', toFaDigits(n)); }
