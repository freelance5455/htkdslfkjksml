import { createFileRoute } from "@tanstack/react-router";
import { YearView } from "@/components/planner/views/year";

export const Route = createFileRoute("/year")({
  component: YearView,
});
