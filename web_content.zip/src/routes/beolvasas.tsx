import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "@/components/shell";
import { Field, Segmented } from "@/components/ui";
import { backupJson, holdingsCsv, parseImportCsv } from "@/lib/csv";
import { CLASS_LABEL, formatQty } from "@/lib/format";
import { parseStatement, SAMPLE_STATEMENT } from "@/lib/lightyear";
import { usePortfolio } from "@/lib/portfolio-context";
import { extractPdfText } from "@/lib/pdf-text";
import type { Chain, ParsedRow } from "@/lib/types";
import { fetchWallet } from "@/lib/wallet.functions";

export const Route = createFileRoute("/beolvasas")({ component: Page });

type Tab = "lightyear" | "tabla" | "csv";

function Page() {
  return (
    <Shell>
      <ImportPage />
    </Shell>
  );
}

function download(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function ImportPage() {
  const { state, importRows, refresh, upsertWallet, importBackup } = usePortfolio();
  const [tab, setTab] = useState<Tab>("lightyear");
  const [text, setText] = useState("");
  const [rows, setRows] = useState<ParsedRow[]>([]);
  const [picked, setPicked] = useState<Record<string, boolean>>({});
  const [groups, setGroups] = useState<Record<string, string>>({});
  const [mode, setMode] = useState<"csere" | "hozzaad">("csere");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [chain, setChain] = useState<Chain>("ethereum");
  const [address, setAddress] = useState("");
  const [walletGroup, setWalletGroup] = useState(state.groups.find((group) => group.kind === "kripto")?.id ?? state.groups[0]?.id ?? "");
  const [walletPreview, setWalletPreview] = useState<{ symbol: string; quantity: number; chain: Chain; address: string } | null>(null);

  const defaultGroup = state.groups[0]?.id ?? "";

  const adopt = (parsed: ParsedRow[]) => {
    setRows(parsed);
    const nextPick: Record<string, boolean> = {};
    const nextGroup: Record<string, string> = {};
    for (const row of parsed) {
      nextPick[row.key] = true;
      nextGroup[row.key] = defaultGroup;
    }
    setPicked(nextPick);
    setGroups(nextGroup);
    setNotice(parsed.length ? `${parsed.length} sor olvasva. Pipáld ki, amit átveszel.` : "Nem találtam állományt. Nézd meg a szöveget, vagy illeszd be kézzel.");
  };

  const readPdf = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    setNotice("");
    try {
      const extracted = await extractPdfText(file);
      setText(extracted);
      adopt(parseStatement(extracted));
    } catch (error) {
      setNotice(error instanceof Error ? `${error.message} Másold ki a szöveget, és illeszd be.` : "A PDF nem olvasható.");
    } finally {
      setBusy(false);
    }
  };

  const commitRows = () => {
    const items = rows.filter((row) => picked[row.key]).map((row) => ({ row, groupId: groups[row.key] || defaultGroup }));
    if (!items.length) {
      setNotice("Nincs kijelölt sor.");
      return;
    }
    importRows(items, mode);
    setNotice(`${items.length} sor bekerült. A bekerülési ár új sornál a kivonat ára — írd át, ha tudod a valódit.`);
    void refresh();
  };

  const lookupWallet = async () => {
    setBusy(true);
    setWalletPreview(null);
    setNotice("");
    try {
      const result = await fetchWallet({ data: { chain, address } });
      setWalletPreview({ ...result, address: address.trim() });
      setNotice("Csak a natív egyenleg jön le (BTC, ETH vagy SOL). A tokeneket kézzel vedd fel.");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "A tárca nem válaszolt.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <h1 className="font-serif text-3xl">Beolvasás</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted">
        A PDF és a tárcacím a böngészőből indul, a kivonatot nem tároljuk a portfólión kívül. Az IBKR és a saját CSV ugyanide érkezik.
      </p>
      <div className="mt-6">
        <Segmented<Tab>
          label="Beolvasás típusa"
          value={tab}
          onChange={setTab}
          options={[
            { id: "lightyear", label: "Lightyear PDF" },
            { id: "tabla", label: "Kriptotárca" },
            { id: "csv", label: "CSV és mentés" },
          ]}
        />
      </div>
      {notice ? <p className="mt-4 text-sm">{notice}</p> : null}

      {tab === "lightyear" ? (
        <section className="mt-6 grid gap-4">
          <p className="text-sm text-muted">
            Béta. A kivonat jelenlegi állományát olvassa, a régi vételeket nem. Válaszd ki a sorokat, és tedd őket csoportba.
          </p>
          <Field label="PDF a gépről">
            <input
              className="field py-2 file:mr-3 file:rounded-md file:border-0 file:bg-pine file:px-3 file:py-2 file:text-sm file:text-on-pine"
              type="file"
              accept="application/pdf"
              onChange={(event) => void readPdf(event.target.files?.[0])}
            />
          </Field>
          <Field label="Vagy a kivonat szövege">
            <textarea className="field h-40 py-2" value={text} onChange={(event) => setText(event.target.value)} />
          </Field>
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn btn-primary" disabled={busy} onClick={() => adopt(parseStatement(text))}>
              Szöveg olvasása
            </button>
            <button
              type="button"
              className="btn btn-ghost"
              onClick={() => {
                setText(SAMPLE_STATEMENT);
                adopt(parseStatement(SAMPLE_STATEMENT));
              }}
            >
              Minta-kivonat
            </button>
          </div>
        </section>
      ) : null}

      {tab === "tabla" ? (
        <section className="mt-6 grid max-w-xl gap-3">
          <Field label="Lánc">
            <select className="field" value={chain} onChange={(event) => setChain(event.target.value as Chain)}>
              <option value="bitcoin">Bitcoin</option>
              <option value="ethereum">Ethereum</option>
              <option value="solana">Solana</option>
            </select>
          </Field>
          <Field label="Cím">
            <input className="field" value={address} onChange={(event) => setAddress(event.target.value)} placeholder="0x… vagy bc1…" />
          </Field>
          <Field label="Csoport">
            <select className="field" value={walletGroup} onChange={(event) => setWalletGroup(event.target.value)}>
              {state.groups.map((group) => (
                <option key={group.id} value={group.id}>
                  {group.name}
                </option>
              ))}
            </select>
          </Field>
          <button type="button" className="btn btn-primary w-fit" disabled={busy || address.trim().length < 20} onClick={() => void lookupWallet()}>
            Egyenleg lekérése
          </button>
          {walletPreview ? (
            <div className="rounded-2xl border border-line bg-surface p-4">
              <p className="font-serif text-2xl tabular-nums">
                {formatQty(walletPreview.quantity)} {walletPreview.symbol}
              </p>
              <p className="mt-1 text-sm break-all text-muted">{walletPreview.address}</p>
              <button
                type="button"
                className="btn btn-primary mt-3"
                onClick={() => {
                  upsertWallet({
                    chain: walletPreview.chain,
                    address: walletPreview.address,
                    symbol: walletPreview.symbol,
                    quantity: walletPreview.quantity,
                    groupId: walletGroup,
                  });
                  setNotice("A tárca egyenlege bekerült. A bekerülési ár a mostani ár, ha új sor.");
                  void refresh();
                }}
              >
                Hozzáadom az állományhoz
              </button>
            </div>
          ) : null}
        </section>
      ) : null}

      {tab === "csv" ? (
        <section className="mt-6 grid gap-4">
          <p className="text-sm text-muted">
            IBKR pozíció-CSV (Positions,Data sorok) vagy saját fejléc: symbol, quantity, és ha van, name, currency, price. A felhős
            szinkron helyett fájlt viszel magaddal.
          </p>
          <Field label="CSV">
            <textarea className="field h-40 py-2" value={text} onChange={(event) => setText(event.target.value)} />
          </Field>
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn btn-primary" onClick={() => adopt(parseImportCsv(text))}>
              CSV olvasása
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => download("szamvetes-eszkozok.csv", holdingsCsv(state), "text/csv")}>
              Eszközök CSV-ben
            </button>
            <button
              type="button"
              className="btn btn-ghost"
              onClick={() => download("szamvetes-mentes.json", backupJson(state), "application/json")}
            >
              Teljes mentés
            </button>
          </div>
          <Field label="Mentés visszatöltése">
            <input
              className="field py-2"
              type="file"
              accept="application/json"
              onChange={async (event) => {
                const file = event.target.files?.[0];
                if (!file) return;
                try {
                  importBackup(JSON.parse(await file.text()));
                  setNotice("A mentés betöltve. Az árgörbét a következő frissítés hozza vissza.");
                  void refresh();
                } catch {
                  setNotice("Ez a fájl nem Számvetés-mentés.");
                }
              }}
            />
          </Field>
        </section>
      ) : null}

      {rows.length ? (
        <section className="mt-8">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-serif text-2xl">Átveendő sorok</h2>
            <Segmented<"csere" | "hozzaad">
              label="Ha már megvan"
              value={mode}
              onChange={setMode}
              options={[
                { id: "csere", label: "Darab csere" },
                { id: "hozzaad", label: "Hozzáad" },
              ]}
            />
          </div>
          <ul className="mt-3 divide-y divide-line border-t border-line">
            {rows.map((row) => (
              <li key={row.key} className="grid gap-3 py-3 md:grid-cols-[auto_1fr_10rem]">
                <label className="flex min-h-11 items-center gap-3">
                  <input
                    type="checkbox"
                    className="size-5 accent-pine"
                    checked={Boolean(picked[row.key])}
                    onChange={(event) => setPicked((current) => ({ ...current, [row.key]: event.target.checked }))}
                  />
                  <span className="sr-only">Kijelölés</span>
                </label>
                <div>
                  <p>
                    {row.name} <span className="text-sm text-muted">{row.symbol}</span>
                  </p>
                  <p className="text-sm text-muted">
                    {CLASS_LABEL[row.assetClass]} · {formatQty(row.quantity)} {row.currency}
                    {row.price != null ? ` · ár ${row.price}` : ""}
                    {row.warning ? ` · ${row.warning}` : ""}
                  </p>
                </div>
                <select
                  className="field"
                  value={groups[row.key] ?? defaultGroup}
                  onChange={(event) => setGroups((current) => ({ ...current, [row.key]: event.target.value }))}
                >
                  {state.groups.map((group) => (
                    <option key={group.id} value={group.id}>
                      {group.name}
                    </option>
                  ))}
                </select>
              </li>
            ))}
          </ul>
          <button type="button" className="btn btn-primary mt-4" onClick={commitRows}>
            Kijelöltek felvétele
          </button>
        </section>
      ) : null}

      <p className="mt-8 text-sm text-muted">
        A vételi napló a <Link to="/mozgasok" className="text-pine">mozgások</Link> között van. Az IBKR-aktivitás részletes könyvelése még nincs meg, a pozíciólista igen.
      </p>
    </div>
  );
}
