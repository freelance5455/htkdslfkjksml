import { useState, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Plus, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { formatAud, formatWhen, parseAud } from "@/lib/money";
import { useVault } from "@/lib/vault-store";

const SOURCES = ["Sale", "Gig", "Affiliate", "Invoice", "Tip"] as const;

export const Route = createFileRoute("/_app/")({ component: Home });

function Home() {
  return (
    <div className="space-y-4">
      <LogEarningForm />
      <RecentEarnings />
    </div>
  );
}

function LogEarningForm() {
  const addEarning = useVault((s) => s.addEarning);
  const [amount, setAmount] = useState("");
  const [source, setSource] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const parsed = parseAud(amount);
    if (parsed === null) {
      setError("Enter an amount greater than 0.");
      return;
    }
    if (!source.trim()) {
      setError("Add a source so you can recognise this later.");
      return;
    }
    addEarning({ amountAud: parsed, source, note });
    setAmount("");
    setSource("");
    setNote("");
    setError(null);
    toast.success(`${formatAud(parsed)} logged`);
  }

  return (
    <Card className="rise-in">
      <form onSubmit={onSubmit} className="space-y-4">
        <CardTitle className="flex items-center gap-2">
          <Plus className="size-5" strokeWidth={2} />
          Log an earning
        </CardTitle>

        <div className="space-y-2">
          <Label htmlFor="amount">Amount (AUD)</Label>
          <Input
            id="amount"
            inputMode="decimal"
            autoComplete="off"
            placeholder="0.00"
            value={amount}
            onChange={(e) => {
              setAmount(e.target.value);
              setError(null);
            }}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="source">Source</Label>
          <Input
            id="source"
            placeholder="e.g. Sale, Gig, Affiliate"
            value={source}
            onChange={(e) => {
              setSource(e.target.value);
              setError(null);
            }}
          />
          <div className="flex flex-wrap gap-1.5 pt-1">
            {SOURCES.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => {
                  setSource(item);
                  setError(null);
                }}
                className={cn(
                  "h-8 rounded-full px-3 text-xs font-medium transition-colors duration-150",
                  source === item
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-accent",
                )}
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="note">Note (optional)</Label>
          <Input
            id="note"
            placeholder="Details about this earning"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </div>

        {error ? <p className="text-sm text-destructive">{error}</p> : null}

        <Button type="submit" className="h-12 w-full text-base">
          Add earning
        </Button>
      </form>
    </Card>
  );
}

function RecentEarnings() {
  const earnings = useVault((s) => s.earnings);

  return (
    <Card className="rise-in rise-in-2">
      <CardTitle className="mb-4 flex items-center gap-2">
        <TrendingUp className="size-5" strokeWidth={2} />
        Recent earnings
      </CardTitle>
      {earnings.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          Nothing logged yet. Add your first earning above and it will show up here.
        </p>
      ) : (
        <ul className="divide-y divide-border">
          {earnings.slice(0, 12).map((row) => (
            <li key={row.id} className="flex items-start justify-between gap-4 py-3 first:pt-0 last:pb-0">
              <div className="min-w-0">
                <p className="truncate font-medium">{row.source}</p>
                <p className="text-sm text-muted-foreground">{formatWhen(row.createdAt)}</p>
                {row.note ? (
                  <p className="mt-0.5 truncate text-sm text-muted-foreground">{row.note}</p>
                ) : null}
              </div>
              <p className="shrink-0 font-medium tabular-nums text-success">
                {formatAud(row.amountAud, { sign: true })}
              </p>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
