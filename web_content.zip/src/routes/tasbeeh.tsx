import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Btn, Card, Page, fieldClass } from "@/components/ui";
import { dayKey } from "@/lib/arabic";
import { usePrefs } from "@/lib/prefs";

export const Route = createFileRoute("/tasbeeh")({ component: TasbeehPage });

const PRESET = ["سبحان الله", "الحمد لله", "الله أكبر", "لا إله إلا الله", "أستغفر الله وأتوب إليه", "لا حول ولا قوة إلا بالله"];

let audioCtx: AudioContext | null = null;
function beep() {
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!audioCtx) audioCtx = new Ctx();
  const o = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  o.frequency.value = 740;
  g.gain.value = 0.03;
  o.connect(g);
  g.connect(audioCtx.destination);
  o.start();
  o.stop(audioCtx.currentTime + 0.05);
}

function TasbeehPage() {
  const prefs = usePrefs();
  const t = prefs.tasbeeh;
  const today = dayKey();
  const todayCount = t.today === today ? t.todayCount : 0;
  const [confirm, setConfirm] = useState(false);
  const [custom, setCustom] = useState("");
  const month = useMemo(() => t.history.reduce((s, h) => s + h.count, 0), [t.history]);
  const phrases = [...PRESET, ...t.customs];

  return (
    <Page title="السبحة" subtitle="عدّ هادئ بلا ضغط. الأرقام تبقى على جهازك.">
      <div className="flex flex-wrap gap-2">
        {phrases.map((p) => (
          <button key={p} type="button" onClick={() => prefs.setTasbeehPhrase(p)} className={`min-h-11 rounded-full px-3 text-sm ${t.phrase === p ? "bg-btn text-btn-fg" : "border border-line bg-card"}`}>
            {p}
          </button>
        ))}
      </div>
      <button
        type="button"
        className="mx-auto mt-6 grid size-56 place-items-center rounded-full border-8 border-gold bg-emerald-deep text-btn-fg shadow-[var(--shadow)]"
        onClick={() => {
          prefs.tasbeehTap(today);
          if (t.vibrate && navigator.vibrate) navigator.vibrate(12);
          if (t.sound) beep();
        }}
      >
        <span>
          <span className="block text-center text-5xl font-bold">{t.count}</span>
          <span className="mt-1 block text-center text-sm text-gold">{t.phrase}</span>
        </span>
      </button>
      <p className="mt-4 text-center text-sm text-muted">
        اليوم {todayCount} · الهدف {t.goal} · مجموع السجل {month}
      </p>
      <div className="mt-4 flex justify-center gap-2">
        {!confirm ? (
          <Btn tone="danger" onClick={() => setConfirm(true)}>
            تصفير العدّاد
          </Btn>
        ) : (
          <>
            <Btn tone="danger" onClick={() => { prefs.tasbeehReset(today); setConfirm(false); }}>
              تأكيد التصفير
            </Btn>
            <Btn tone="ghost" onClick={() => setConfirm(false)}>
              إلغاء
            </Btn>
          </>
        )}
      </div>
      <Card className="mt-4">
        <label className="flex min-h-11 items-center gap-2 text-sm">
          <input type="checkbox" checked={t.vibrate} onChange={(e) => prefs.patch({ tasbeeh: { ...t, vibrate: e.target.checked } })} />
          اهتزاز
        </label>
        <label className="flex min-h-11 items-center gap-2 text-sm">
          <input type="checkbox" checked={t.sound} onChange={(e) => prefs.patch({ tasbeeh: { ...t, sound: e.target.checked } })} />
          نغمة عدّ خفيفة
        </label>
        <label className="mt-2 block text-sm">
          الهدف اليومي
          <input className={fieldClass} type="number" min={1} value={t.goal} onChange={(e) => prefs.patch({ tasbeeh: { ...t, goal: Number(e.target.value) || 1 }, goals: { ...prefs.goals, tasbeeh: Number(e.target.value) || 1 } })} />
        </label>
        <div className="mt-3 flex gap-2">
          <input className={fieldClass} placeholder="ذكر مخصص" value={custom} onChange={(e) => setCustom(e.target.value)} />
          <Btn
            onClick={() => {
              const phrase = custom.trim();
              if (!phrase) return;
              prefs.patch({ tasbeeh: { ...t, customs: [...t.customs, phrase].slice(0, 12), phrase, count: 0 } });
              setCustom("");
            }}
          >
            أضف
          </Btn>
        </div>
      </Card>
      <Card className="mt-3">
        <p className="font-bold">السجل</p>
        <ul className="mt-2 max-h-48 space-y-1 overflow-auto text-sm">
          {t.history.length === 0 && <li className="text-muted">لا سجل بعد.</li>}
          {t.history.map((h) => (
            <li key={h.date} className="flex justify-between">
              <span>{h.date}</span>
              <span>{h.count}</span>
            </li>
          ))}
        </ul>
      </Card>
    </Page>
  );
}
