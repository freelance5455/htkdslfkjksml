import { PageFrame } from "@/components/app-shell";
import { ChipBar } from "@/components/chip-bar";
import { ErrorBoundary } from "@/components/error-boundary";
import { PostCard, PostCardSkeleton } from "@/components/post-card";
import { PullToRefresh } from "@/components/pull-to-refresh";
import { SubscribeButton } from "@/components/subscribe-button";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useSentinel } from "@/hooks/use-sentinel";
import { POST_SORTS, POST_TYPES, sortPosts, type PostSort, type TypeFilter } from "@/lib/sort";
import { formatCount } from "@/lib/utils";
import { getChannelFn, getChannelPostsFn } from "@/lib/youtube/api";
import { TYPE_FILTER } from "@/lib/youtube/topics";
import type { ChannelDetails } from "@/lib/youtube/types";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useInfiniteQuery, useQuery } from "@tanstack/react-query";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useCallback, useMemo, useRef, useState } from "react";

export const Route = createFileRoute("/channel/$channelId")({
  component: ChannelPage,
});

function ChannelPage() {
  const { channelId } = Route.useParams();
  const [sort, setSort] = useState<PostSort>("newest");
  const [type, setType] = useState<TypeFilter>("all");

  const channelQuery = useQuery({
    queryKey: ["channel", channelId],
    queryFn: () => getChannelFn({ data: { id: channelId } }),
    retry: 1,
  });

  const postsQuery = useInfiniteQuery({
    queryKey: ["channel-posts", channelId],
    initialPageParam: null as string | null,
    queryFn: async ({ pageParam }) =>
      getChannelPostsFn({
        data: { channelId, continuation: pageParam },
      }),
    getNextPageParam: (last, pages) => {
      const token = last.continuation ?? undefined;
      if (!token) return undefined;
      if (pages.some((p, i) => i < pages.length - 1 && p.continuation === token)) {
        return undefined;
      }
      return token;
    },
    retry: 1,
  });

  const channel: ChannelDetails | null =
    channelQuery.data ?? postsQuery.data?.pages[0]?.channel ?? null;

  const posts = useMemo(() => {
    const seen = new Set<string>();
    const list = [];
    for (const page of postsQuery.data?.pages ?? []) {
      for (const post of page.posts) {
        if (seen.has(post.id)) continue;
        seen.add(post.id);
        list.push(post);
      }
    }
    const kind = type === "all" ? undefined : TYPE_FILTER[type];
    const typed = kind ? list.filter((p) => p.kind === kind) : list;
    return sortPosts(typed, sort);
  }, [postsQuery.data, sort, type]);

  const hasPostsTab =
    postsQuery.data?.pages[0]?.hasPostsTab ?? channel?.hasPostsTab ?? posts.length > 0;

  const sentinel = useRef<HTMLDivElement>(null);
  const {
    hasNextPage,
    isFetchingNextPage,
    isFetching,
    fetchNextPage,
    isLoading: postsLoading,
    refetch: refetchPosts,
  } = postsQuery;
  const loadMore = useCallback(() => {
    if (hasNextPage && !isFetchingNextPage && !isFetching) {
      void fetchNextPage();
    }
  }, [fetchNextPage, hasNextPage, isFetching, isFetchingNextPage]);
  useSentinel(sentinel, Boolean(hasNextPage && !isFetchingNextPage), loadMore);

  const summary = channel
    ? {
        id: channel.id,
        title: channel.title,
        handle: channel.handle,
        description: channel.description,
        thumbnail: channel.thumbnail,
        subscriberCount: channel.subscriberCount,
        subscriberText: channel.subscriberText,
        videoCount: channel.videoCount,
        videoText: channel.videoText,
        verified: channel.verified,
        hasPostsTab,
      }
    : null;

  return (
    <PageFrame>
      <div className="flex h-full min-h-0 min-w-0 flex-1 flex-col overflow-hidden">
        <header className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur-sm">
          <div className="flex items-center gap-3 px-3 py-3">
            <Button asChild size="icon" variant="ghost" aria-label="Back">
              <Link to="/">
                <ArrowLeft />
              </Link>
            </Button>
            <div className="min-w-0 flex-1">
              <p className="truncate font-display text-base font-semibold">
                {channel?.title ?? "Channel"}
              </p>
              <p className="truncate text-xs text-muted-foreground">Community</p>
            </div>
          </div>
          <ChipBar ariaLabel="Post type" items={POST_TYPES} value={type} onChange={setType} />
          <ChipBar ariaLabel="Sort posts" items={POST_SORTS} value={sort} onChange={setSort} />
        </header>

        <PullToRefresh
          onRefresh={async () => {
            await Promise.all([channelQuery.refetch(), refetchPosts()]);
          }}
        >
          <div className="mx-auto w-full max-w-2xl px-4 pb-24 pt-4">
            <ErrorBoundary>
              {channelQuery.isLoading && !channel ? (
                <div className="mb-5 rounded-2xl border border-border bg-card p-4">
                  <div className="flex gap-3">
                    <div className="size-16 animate-pulse rounded-full bg-muted" />
                    <div className="flex-1 space-y-2 pt-2">
                      <div className="h-4 w-40 animate-pulse rounded bg-muted" />
                      <div className="h-3 w-28 animate-pulse rounded bg-muted" />
                    </div>
                  </div>
                </div>
              ) : summary ? (
                <section className="mb-5 rounded-2xl border border-border bg-card p-4">
                  <div className="flex items-start gap-3">
                    {summary.thumbnail ? (
                      <img
                        src={summary.thumbnail}
                        alt=""
                        className="size-16 rounded-full object-cover"
                      />
                    ) : (
                      <span className="flex size-16 items-center justify-center rounded-full bg-muted text-xl font-medium">
                        {summary.title.slice(0, 1)}
                      </span>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h1 className="font-display text-lg font-semibold leading-tight">
                          {summary.title}
                        </h1>
                        {summary.verified ? <Badge>Verified</Badge> : null}
                      </div>
                      <p className="mt-0.5 text-sm text-muted-foreground">
                        {summary.handle ? `${summary.handle} · ` : ""}
                        {summary.subscriberText ||
                          `${formatCount(summary.subscriberCount)} subscribers`}
                      </p>
                      <div className="mt-3">
                        <SubscribeButton channel={summary} size="default" />
                      </div>
                    </div>
                  </div>
                  {summary.description ? (
                    <p className="mt-3 line-clamp-4 text-sm leading-relaxed text-muted-foreground">
                      {summary.description}
                    </p>
                  ) : null}
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {hasPostsTab ? (
                      <Badge>Community tab</Badge>
                    ) : (
                      <Badge variant="outline">No Community tab</Badge>
                    )}
                    {summary.subscriberCount === 0 ? (
                      <Badge variant="outline">0 subscribers</Badge>
                    ) : null}
                  </div>
                </section>
              ) : channelQuery.isError ? (
                <div className="mb-5 rounded-2xl border border-border bg-card px-5 py-8 text-center">
                  <p className="font-medium">Channel not found</p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Try searching by @handle or paste a channel URL.
                  </p>
                </div>
              ) : null}

              {postsLoading ? (
                <div className="space-y-3">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <PostCardSkeleton key={i} />
                  ))}
                </div>
              ) : posts.length === 0 ? (
                <div className="rounded-2xl border border-border bg-card px-6 py-12 text-center">
                  <h3 className="font-display text-lg font-semibold">
                    {hasPostsTab ? "No Community posts yet" : "This channel has no Community tab"}
                  </h3>
                  <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
                    You can still subscribe. If they start posting, their updates will show here.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {posts.map((post) => (
                    <PostCard key={post.id} post={post} />
                  ))}
                </div>
              )}

              <div ref={sentinel} className="h-10" />
              {isFetchingNextPage ? (
                <div className="flex items-center justify-center py-6 text-muted-foreground">
                  <Loader2 className="size-5 animate-spin" />
                </div>
              ) : null}
            </ErrorBoundary>
          </div>
        </PullToRefresh>
      </div>
    </PageFrame>
  );
}
