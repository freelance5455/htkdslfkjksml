import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/ministry/shell";
import { SkillsPage } from "@/components/ministry/skills-page";

export const Route = createFileRoute("/skills")({
  component: function SkillsRoute() {
    return (
      <AppShell>
        <SkillsPage />
      </AppShell>
    );
  },
});
