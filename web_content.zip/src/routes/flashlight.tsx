import { createFileRoute } from "@tanstack/react-router";
import { Flashlight, FlashlightOff } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { AppShell, ScreenBody } from "@/components/vishal/app-shell";
import { ScreenHeader } from "@/components/vishal/screen-header";

export const Route = createFileRoute("/flashlight")({ component: FlashlightPage });

type TorchMode = "off" | "led" | "screen";

function FlashlightPage() {
  const [mode, setMode] = useState<TorchMode>("off");
  const [message, setMessage] = useState<string | null>(null);
  const [hasLed, setHasLed] = useState<boolean | null>(null);
  const trackRef = useRef<MediaStreamTrack | null>(null);

  useEffect(() => {
    return () => {
      stopTrack();
    };
  }, []);

  function stopTrack() {
    const track = trackRef.current;
    if (!track) return;
    try {
      void track.applyConstraints({ advanced: [{ torch: false } as MediaTrackConstraintSet] });
    } catch {
      /* ignore */
    }
    track.stop();
    trackRef.current = null;
  }

  async function tryLed(on: boolean) {
    if (!on) {
      stopTrack();
      return true;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setHasLed(false);
      return false;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" } },
      });
      const track = stream.getVideoTracks()[0];
      if (!track) {
        stream.getTracks().forEach((t) => t.stop());
        setHasLed(false);
        return false;
      }
      const caps = track.getCapabilities() as MediaTrackCapabilities & { torch?: boolean };
      if (!caps.torch) {
        track.stop();
        setHasLed(false);
        return false;
      }
      await track.applyConstraints({
        advanced: [{ torch: true } as MediaTrackConstraintSet],
      });
      trackRef.current = track;
      setHasLed(true);
      return true;
    } catch {
      setHasLed(false);
      return false;
    }
  }

  async function toggleLed() {
    if (mode === "led") {
      await tryLed(false);
      setMode("off");
      setMessage(null);
      return;
    }
    const ok = await tryLed(true);
    if (ok) {
      setMode("led");
      setMessage("LED torch is on");
    } else {
      setMessage("No LED torch on this device. Use screen light instead.");
    }
  }

  function toggleScreen() {
    if (mode === "led") {
      void tryLed(false);
    }
    setMode((prev) => (prev === "screen" ? "off" : "screen"));
    setMessage(null);
  }

  const isOn = mode !== "off";

  return (
    <AppShell>
      <ScreenBody>
        <ScreenHeader
          title="Flashlight"
          subtitle="Uses the camera LED when available. Safe if this device has no flash."
        />
        {mode === "screen" ? (
          <button
            type="button"
            onClick={toggleScreen}
            className="fixed inset-0 z-40 bg-fg"
            aria-label="Turn screen light off"
          />
        ) : null}

        <section className="rounded-card bg-surface px-[18px] py-8 text-center shadow-[var(--shadow-border)]">
          <button
            type="button"
            onClick={() => void toggleLed()}
            className="mx-auto flex size-40 items-center justify-center rounded-full transition-colors duration-200 ease-out active:scale-[0.96]"
            style={{ background: isOn && mode === "led" ? "rgba(245, 193, 74, 0.22)" : "var(--color-elevated)" }}
            aria-pressed={mode === "led"}
          >
            <span
              className="flex size-32 items-center justify-center rounded-full"
              style={{ background: mode === "led" ? "var(--color-warning)" : "var(--color-elevated)" }}
            >
              {mode === "led" ? (
                <Flashlight className="size-14 text-fg" />
              ) : (
                <FlashlightOff className="size-14 text-muted" />
              )}
            </span>
          </button>
          <h2 className="mt-5 text-xl font-semibold text-fg">
            {mode === "led" ? "Flashlight is ON" : mode === "screen" ? "Screen light is ON" : "Flashlight is OFF"}
          </h2>
          <p className="mt-1 text-sm text-muted">
            {hasLed === false
              ? "This device has no camera flash"
              : "Tap the button to toggle the LED"}
          </p>
          {message ? <p className="mt-3 text-sm text-primary">{message}</p> : null}
          <button
            type="button"
            onClick={toggleScreen}
            className="mt-6 inline-flex h-12 min-w-44 items-center justify-center rounded-2xl bg-elevated px-5 text-sm font-semibold text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
          >
            {mode === "screen" ? "Turn screen light off" : "Use screen light"}
          </button>
        </section>
      </ScreenBody>
    </AppShell>
  );
}
