import { createFileRoute } from "@tanstack/react-router";
import { ClickerPage } from "@/features/clicker";

export const Route = createFileRoute("/clicker")({
  head: () => ({ meta: [{ title: "Auto Clicker · FrameForge BOOYAH" }] }),
  component: ClickerPage,
});
