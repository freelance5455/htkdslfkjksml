import { useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { LayoutGrid, List as ListIcon, Search } from "lucide-react";
import { FileInspector } from "@/components/file-inspector";
import { MediaCard } from "@/components/media-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { folderGroups, itemsForTab, sortItems, useLibrary } from "@/lib/library-store";
import type { LibraryTab } from "@/lib/media-types";
import { useSettings } from "@/lib/settings-store";
import { cn } from "@/lib/utils";

const TABS: { id: LibraryTab; label: string }[] = [
  { id: "videos", label: "Videos" },
  { id: "movies", label: "Movies" },
  { id: "music", label: "Music" },
  { id: "recent", label: "Recent" },
  { id: "favourites", label: "Favourites" },
  { id: "folders", label: "Folders" },
  { id: "downloads", label: "Downloads" },
];

type Search = {
  tab?: LibraryTab;
  folder?: string;
  q?: string;
  inspect?: string;
  action?: string;
};

export const Route = createFileRoute("/library")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    tab: typeof s.tab === "string" ? (s.tab as LibraryTab) : undefined,
    folder: typeof s.folder === "string" ? s.folder : undefined,
    q: typeof s.q === "string" ? s.q : undefined,
    inspect: typeof s.inspect === "string" ? s.inspect : undefined,
    action: typeof s.action === "string" ? s.action : undefined,
  }),
  component: LibraryPage,
});

function LibraryPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const items = useLibrary((s) => s.items);
  const ready = useLibrary((s) => s.ready);
  const sort = useSettings((s) => s.sort);
  const view = useSettings((s) => s.view);
  const setSetting = useSettings((s) => s.set);
  const [q, setQ] = useState(search.q ?? "");
  const tab: LibraryTab = search.tab ?? "videos";
  const folders = folderGroups(items);

  const list = useMemo(() => {
    let next = itemsForTab(items, tab);
    if (search.folder) next = next.filter((i) => i.folder === search.folder);
    const query = q.trim().toLowerCase();
    if (query) {
      next = next.filter(
        (i) =>
          i.name.toLowerCase().includes(query) ||
          i.folder.toLowerCase().includes(query) ||
          i.relativePath.toLowerCase().includes(query),
      );
    }
    return sortItems(next, sort);
  }, [items, tab, search.folder, q, sort]);

  const inspectItem = items.find((i) => i.id === search.inspect);

  const setTab = (id: LibraryTab) => {
    void navigate({
      to: "/library",
      search: { tab: id, q: q || undefined },
    });
  };

  return (
    <div className="space-y-5">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-semibold">Library</h1>
          <p className="text-sm text-muted">{items.length} items on this device</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            size="icon"
            variant={view === "grid" ? "secondary" : "ghost"}
            aria-label="Grid view"
            onClick={() => setSetting("view", "grid")}
          >
            <LayoutGrid />
          </Button>
          <Button
            size="icon"
            variant={view === "list" ? "secondary" : "ghost"}
            aria-label="List view"
            onClick={() => setSetting("view", "list")}
          >
            <ListIcon />
          </Button>
        </div>
      </header>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search titles and folders"
          className="pl-10"
          aria-label="Search library"
        />
      </div>

      <div className="rail-scroll flex gap-2 overflow-x-auto pb-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "h-10 shrink-0 rounded-full px-4 text-sm font-medium",
              tab === t.id ? "bg-primary text-primary-fg" : "bg-secondary text-muted",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="flex flex-wrap gap-2">
        {(["name", "date", "duration", "size"] as const).map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => setSetting("sort", key)}
            className={cn(
              "h-8 rounded-full px-3 text-xs font-medium capitalize",
              sort === key ? "bg-elevated text-fg shadow-[var(--shadow-border)]" : "text-muted",
            )}
          >
            {key}
          </button>
        ))}
      </div>

      {tab === "folders" && !search.folder ? (
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {folders.map((f) => (
            <li key={f.name}>
              <button
                type="button"
                className="w-full rounded-xl bg-surface p-4 text-left shadow-[var(--shadow-border)]"
                onClick={() =>
                  void navigate({ to: "/library", search: { tab: "folders", folder: f.name } })
                }
              >
                <p className="font-medium">{f.name}</p>
                <p className="text-sm text-muted">
                  {f.count} files · {f.videos} video · {f.audio} audio
                </p>
              </button>
            </li>
          ))}
          {folders.length === 0 ? <Empty ready={ready} /> : null}
        </ul>
      ) : list.length === 0 ? (
        <Empty ready={ready} />
      ) : view === "list" ? (
        <ul className="space-y-2">
          {list.map((item) => (
            <li key={item.id}>
              <MediaCard item={item} queue={list} layout="list" />
            </li>
          ))}
        </ul>
      ) : (
        <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {list.map((item) => (
            <li key={item.id}>
              <MediaCard item={item} queue={list} />
            </li>
          ))}
        </ul>
      )}

      <FileInspector
        item={inspectItem}
        action={search.action}
        onClose={() =>
          void navigate({
            to: "/library",
            search: { tab: search.tab, folder: search.folder, q: search.q },
          })
        }
      />
    </div>
  );
}

function Empty({ ready }: { ready: boolean }) {
  return (
    <div className="rounded-xl bg-surface px-6 py-16 text-center shadow-[var(--shadow-border)]">
      <p className="font-display text-xl font-semibold">{ready ? "No matching files" : "Loading library"}</p>
      <p className="mt-2 text-sm text-muted">
        {ready ? "Add media or clear filters." : "Reading on-device index…"}
      </p>
    </div>
  );
}
