import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { getMe, joinGroup, leaveGroup, listGroupMembers } from "@/lib/cutegirls/api";
import type { GroupCard, Person } from "@/lib/cutegirls/model";
import { useSalon } from "@/lib/cutegirls/store";
import { Avatar, primaryBtn, quietBtn } from "@/components/bits";
import { FeedView } from "@/components/feed-view";
import { Shell } from "@/components/shell";
import { useMeId } from "@/components/use-me-id";

export const Route = createFileRoute("/groups/$slug")({ component: GroupPage });

function GroupPage() {
  const { slug } = Route.useParams();
  return (
    <Shell>
      <Room slug={slug} />
    </Shell>
  );
}

function Room({ slug }: { slug: string }) {
  const meId = useMeId();
  const bump = useSalon((s) => s.bump);
  const openCompose = useSalon((s) => s.openCompose);
  const [group, setGroup] = useState<GroupCard | null>(null);
  const [missing, setMissing] = useState(false);
  const [people, setPeople] = useState<Person[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    const me = await getMe();
    const found = me.groups.find((item) => item.slug === slug) ?? null;
    setGroup(found);
    setMissing(!found);
    if (found) {
      const members = await listGroupMembers({ data: { slug } });
      if (members.ok) setPeople(members.people);
    }
  }

  useEffect(() => {
    let live = true;
    load()
      .catch((err: unknown) => {
        if (live) setError(err instanceof Error ? err.message : "تعذر التحميل");
      });
    return () => {
      live = false;
    };
    // slug is the only identity; load closes over it
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug]);

  async function enter() {
    const result = await joinGroup({ data: { slug } });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    bump();
    await load();
  }

  async function leave() {
    const result = await leaveGroup({ data: { slug } });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    bump();
    await load();
  }

  if (!meId) return null;

  return (
    <div className="mx-auto w-full max-w-xl space-y-4">
      <Link to="/groups" className="text-sm text-mute">
        كل المجموعات
      </Link>
      {missing ? <p className="text-sm text-rose">هذه المجموعة غير موجودة.</p> : null}
      {group ? (
        <header className="rounded-3xl bg-paper p-5 shadow-card">
          <p className="text-xs text-rose">{group.forced ? "معك دائماً" : group.joined ? "أنت داخلها" : "لست عضواً بعد"}</p>
          <h1 className="mt-1 font-display text-4xl leading-tight">{group.name}</h1>
          <p className="mt-2 text-sm leading-6 text-mute">{group.blurb}</p>
          <p className="mt-2 text-xs tabular-nums text-mute">{group.members} عضو</p>
          <div className="mt-4 flex flex-wrap gap-2">
            {group.joined ? (
              <button type="button" className={primaryBtn} onClick={() => openCompose({ group: group.slug })}>
                انشر هنا
              </button>
            ) : (
              <button type="button" className={primaryBtn} onClick={() => void enter()}>
                انضمام فوري
              </button>
            )}
            {group.joined && !group.forced ? (
              <button type="button" className={quietBtn} onClick={() => void leave()}>
                مغادرة
              </button>
            ) : null}
          </div>
          {people.length ? (
            <ul className="mt-4 flex gap-3 overflow-x-auto pb-1">
              {people.map((person) => (
                <li key={person.username} className="w-16 shrink-0 text-center">
                  <Link to="/u/$username" params={{ username: person.username }} className="block">
                    <Avatar src={person.avatar} name={person.username} className="mx-auto size-11 text-sm" />
                    <span className="mt-1 block truncate text-xs">{person.username}</span>
                  </Link>
                </li>
              ))}
            </ul>
          ) : null}
        </header>
      ) : null}
      {error ? <p className="text-sm text-rose">{error}</p> : null}
      {group ? (
        <FeedView
          meId={meId}
          query={{ surface: "group", slug }}
          variant="feed"
          emptyTitle="الغرفة هادئة"
          emptyBody="أول منشور هنا يظهر أيضاً في الساحة إن كان فضفضة أو مسابقة أو معلومة أو نشرة."
        />
      ) : null}
    </div>
  );
}
