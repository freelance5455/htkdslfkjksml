import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Gem, House, Moon, Users } from "lucide-react";
import { getMe, joinGroup } from "@/lib/cutegirls/api";
import type { GroupCard } from "@/lib/cutegirls/model";
import { useSalon } from "@/lib/cutegirls/store";
import { Shell } from "@/components/shell";

const ICONS = { everyone: Users, family: House, yandere: Moon, suitor: Gem } as const;

export const Route = createFileRoute("/groups/")({ component: GroupsPage });

function GroupsPage() {
  return (
    <Shell>
      <Groups />
    </Shell>
  );
}

function Groups() {
  const navigate = useNavigate();
  const bump = useSalon((s) => s.bump);
  const [groups, setGroups] = useState<GroupCard[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    getMe()
      .then((me) => {
        if (live) setGroups(me.groups);
      })
      .catch((err: unknown) => {
        if (live) setError(err instanceof Error ? err.message : "تعذر التحميل");
      });
    return () => {
      live = false;
    };
  }, []);

  async function enter(group: GroupCard) {
    if (!group.joined) {
      setPending(group.slug);
      const result = await joinGroup({ data: { slug: group.slug } });
      setPending(null);
      if (!result.ok) {
        setError(result.error);
        return;
      }
      bump();
    }
    await navigate({ to: "/groups/$slug", params: { slug: group.slug } });
  }

  return (
    <div className="mx-auto w-full max-w-xl space-y-4">
      <header>
        <p className="text-xs tracking-widest text-rose">غرف</p>
        <h1 className="font-display text-4xl">المجموعات</h1>
        <p className="mt-2 text-sm leading-6 text-mute">الدخول فوري. الجماعة الشاملة معك رغماً عن أي اختيار آخر.</p>
      </header>
      {error ? <p className="text-sm text-rose">{error}</p> : null}
      <ul className="space-y-3">
        {(groups ?? []).map((group) => {
          const Icon = ICONS[group.slug as keyof typeof ICONS] ?? Users;
          return (
            <li key={group.slug} className="rounded-3xl bg-paper p-4 shadow-card">
              <div className="flex items-start gap-3">
                <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-rose/10 text-rose">
                  <Icon className="size-5" strokeWidth={1.75} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-display text-2xl leading-snug">{group.name}</h2>
                    {group.forced ? <span className="text-xs text-rose">معك دائماً</span> : null}
                  </div>
                  <p className="mt-1 text-sm leading-6 text-mute">{group.blurb}</p>
                  <p className="mt-2 text-xs tabular-nums text-mute">{group.members} عضو</p>
                </div>
              </div>
              <button
                type="button"
                disabled={pending === group.slug}
                onClick={() => void enter(group)}
                className="mt-4 inline-flex min-h-11 w-full items-center justify-center rounded-full bg-rose text-sm font-medium text-paper disabled:opacity-50"
              >
                {pending === group.slug ? "لحظات…" : group.joined ? "ادخل" : "انضمام ودخول"}
              </button>
            </li>
          );
        })}
      </ul>
      <p className="text-center text-xs text-mute">
        أو من <Link to="/search" search={{ q: "" }} className="text-rose">البحث</Link>
      </p>
    </div>
  );
}
