import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell, ScreenBody } from "@/components/vishal/app-shell";
import { ScreenHeader } from "@/components/vishal/screen-header";
import { initialCalc, reduceCalc, type CalcState } from "@/lib/calculator";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/calculator")({ component: CalculatorPage });

const rows: string[][] = [
  ["C", "÷", "×", "⌫"],
  ["7", "8", "9", "−"],
  ["4", "5", "6", "+"],
  ["1", "2", "3", "="],
];

function CalculatorPage() {
  const [state, setState] = useState<CalcState>(initialCalc);

  function press(key: string) {
    setState((prev) => reduceCalc(prev, key));
  }

  return (
    <AppShell>
      <ScreenBody>
        <ScreenHeader title="Calculator" subtitle="Basic arithmetic. Works fully offline." />
        <div className="rounded-card bg-surface px-[18px] py-6 shadow-[var(--shadow-border)]">
          {state.error ? <p className="mb-1 text-right text-sm text-danger">{state.error}</p> : null}
          <p className="truncate text-right text-4xl font-bold tabular-nums tracking-tight text-fg">
            {state.display}
          </p>
        </div>
        <div className="mt-4 flex flex-col gap-2.5">
          {rows.map((row) => (
            <div key={row.join("-")} className="grid grid-cols-4 gap-2.5">
              {row.map((key) => (
                <KeyButton key={key} label={key} onPress={press} />
              ))}
            </div>
          ))}
          <div className="grid grid-cols-4 gap-2.5">
            <KeyButton label="0" onPress={press} className="col-span-2 min-h-16" />
            <KeyButton label="." onPress={press} />
            <span className="rounded-key bg-surface/50" aria-hidden />
          </div>
        </div>
      </ScreenBody>
    </AppShell>
  );
}

function KeyButton({
  label,
  onPress,
  className,
}: {
  label: string;
  onPress: (key: string) => void;
  className?: string;
}) {
  const accent = label === "=";
  const op = ["÷", "×", "−", "+", "C", "⌫"].includes(label);
  return (
    <button
      type="button"
      onClick={() => onPress(label)}
      className={cn(
        "min-h-16 rounded-key text-xl font-semibold transition-transform duration-150 ease-out active:scale-[0.96]",
        accent && "bg-primary text-bg",
        !accent && op && "bg-elevated",
        !accent && !op && "bg-surface text-fg shadow-[var(--shadow-border)]",
        label === "C" && "text-danger",
        op && label !== "C" && "text-primary",
        className,
      )}
    >
      {label}
    </button>
  );
}
