import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Btn, Card, Page, fieldClass } from "@/components/ui";
import { AUDIO_SOURCE, RECITERS } from "@/data/reciters";
import { cancelAudioDownload, downloadSurah, downloadSurahList } from "@/lib/audio";
import { savedAudioPosition, syncPlayerRates, usePlayer } from "@/lib/player";
import { usePrefs } from "@/lib/prefs";
import { juzStart, loadQuran, type Quran, type Surah } from "@/lib/quran";

export const Route = createFileRoute("/reciters")({ component: RecitersPage });

function RecitersPage() {
  const prefs = usePrefs();
  const player = usePlayer();
  const [q, setQ] = useState<Quran | null>(null);
  const [surahN, setSurahN] = useState(1);
  const [msg, setMsg] = useState("");
  const [saved, setSaved] = useState<ReturnType<typeof savedAudioPosition>>(null);

  useEffect(() => {
    void loadQuran().then(setQ);
    setSaved(savedAudioPosition());
  }, []);

  const surah: Surah | undefined = q?.surahs[surahN - 1];

  return (
    <Page title="مكتبة القراء" subtitle={AUDIO_SOURCE}>
      <Card>
        <label className="text-sm font-semibold">
          القارئ
          <select className={fieldClass} value={prefs.reciterId} onChange={(e) => prefs.patch({ reciterId: e.target.value })}>
            {RECITERS.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name} · {r.note}
              </option>
            ))}
          </select>
        </label>
        <label className="mt-3 block text-sm font-semibold">
          السورة
          <select className={fieldClass} value={surahN} onChange={(e) => setSurahN(Number(e.target.value))}>
            {q?.surahs.map((s) => (
              <option key={s.n} value={s.n}>
                {s.n}. {s.ar}
              </option>
            ))}
          </select>
        </label>
        <div className="mt-3 flex flex-wrap gap-2">
          <Btn
            disabled={!surah}
            onClick={() => {
              if (!surah) return;
              player.playList(
                surah.ayahs.map((a) => ({ surah: surah.n, ayah: a.a, title: `${surah.ar} · ${a.a}` })),
                0,
              );
            }}
          >
            استماع
          </Btn>
          <Btn
            tone="gold"
            disabled={!surah}
            onClick={() => {
              if (!surah) return;
              setMsg("يبدأ تنزيل السورة…");
              void downloadSurah(prefs.reciterId, surah, (d, t) => setMsg(`${surah.ar}: ${d}/${t}`))
                .then((r) => {
                  if (r === "done") {
                    prefs.markCached(prefs.reciterId, surah.n);
                    setMsg("اكتمل تنزيل السورة ويمكن سماعها دون اتصال.");
                  } else setMsg("أُلغي التنزيل.");
                })
                .catch(() => setMsg("فشل التنزيل. تأكد من الاتصال ثم أعد المحاولة."));
            }}
          >
            تنزيل السورة
          </Btn>
          <Btn tone="ghost" onClick={() => cancelAudioDownload()}>
            إلغاء التنزيل
          </Btn>
        </div>
        {msg && <p className="mt-2 text-sm">{msg}</p>}
        <p className="mt-2 text-xs text-muted">
          سور محفوظة لهذا القارئ: {(prefs.cachedAudio[prefs.reciterId] || []).join("، ") || "لا شيء بعد"}
        </p>
      </Card>
      <Card className="mt-3">
        <p className="font-bold">التحكم</p>
        <label className="mt-2 block text-sm">
          السرعة {prefs.playbackRate}
          <input
            type="range"
            min={0.75}
            max={1.5}
            step={0.25}
            value={prefs.playbackRate}
            onChange={(e) => {
              prefs.patch({ playbackRate: Number(e.target.value) });
              void syncPlayerRates();
            }}
            className="w-full"
          />
        </label>
        <label className="mt-2 block text-sm">
          الصوت
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={prefs.volume}
            onChange={(e) => {
              prefs.patch({ volume: Number(e.target.value) });
              void syncPlayerRates();
            }}
            className="w-full"
          />
        </label>
        <label className="mt-2 block text-sm">
          التكرار
          <select className={fieldClass} value={player.repeat} onChange={(e) => player.setRepeat(e.target.value as "off" | "ayah" | "surah")}>
            <option value="off">بدون</option>
            <option value="ayah">تكرار الآية</option>
            <option value="surah">تكرار السورة</option>
          </select>
        </label>
        <label className="mt-2 block text-sm">
          مؤقت الإيقاف
          <select
            className={fieldClass}
            defaultValue=""
            onChange={(e) => player.setSleep(e.target.value ? Number(e.target.value) : null)}
          >
            <option value="">متوقف</option>
            <option value="5">5 دقائق</option>
            <option value="10">10</option>
            <option value="15">15</option>
            <option value="30">30</option>
            <option value="45">45</option>
            <option value="60">60</option>
          </select>
        </label>
        {saved && (
          <button
            type="button"
            className="mt-3 min-h-11 text-sm font-semibold text-emerald"
            onClick={() => {
              if (!q) return;
              const s = q.surahs[saved.surah - 1];
              const idx = s.ayahs.findIndex((a) => a.a === saved.ayah);
              player.playList(
                s.ayahs.map((a) => ({ surah: s.n, ayah: a.a, title: `${s.ar} · ${a.a}` })),
                Math.max(0, idx),
              );
            }}
          >
            متابعة آخر موضع: {saved.title}
          </button>
        )}
        <p className="mt-2 text-xs text-muted">
          التشغيل يستمر أثناء تصفح التطبيق. بعد إغلاق المتصفح تمامًا يتوقف الصوت؛ هذا حد المتصفح وليس مشغل أندرويد خلفي.
        </p>
      </Card>
      <Card className="mt-3">
        <p className="font-bold">تنزيل جزء</p>
        <p className="text-sm text-muted">المصحف كاملًا لقارئ واحد قد يتجاوز مئات الميغابايتات. نزّل جزءًا واحدًا كل مرة.</p>
        <div className="mt-2 grid grid-cols-5 gap-2">
          {Array.from({ length: 30 }, (_, i) => i + 1).map((j) => (
            <button
              key={j}
              type="button"
              className="min-h-11 rounded-xl border border-line text-sm"
              onClick={() => {
                if (!q) return;
                const start = juzStart(q, j);
                const end = j < 30 ? juzStart(q, j + 1) : null;
                const list = q.surahs.filter((s) => {
                  const first = s.ayahs[0];
                  const last = s.ayahs[s.ayahs.length - 1];
                  const from = start ? start.surah : 1;
                  const to = end ? end.surah : 114;
                  return s.n >= from && s.n <= to && (last.j >= j && first.j <= j || s.n === from || s.n === to);
                });
                setMsg(`تنزيل الجزء ${j}…`);
                void downloadSurahList(prefs.reciterId, list, setMsg)
                  .then((r) => {
                    if (r === "done") {
                      list.forEach((s) => prefs.markCached(prefs.reciterId, s.n));
                      setMsg(`اكتمل الجزء ${j}`);
                    }
                  })
                  .catch(() => setMsg("توقف التنزيل بسبب خطأ في الشبكة."));
              }}
            >
              {j}
            </button>
          ))}
        </div>
      </Card>
    </Page>
  );
}
