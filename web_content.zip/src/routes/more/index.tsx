import { createFileRoute, Link } from "@tanstack/react-router";
import { BackButton } from "@/components/back-button";
import { AppShell, TopBar } from "@/components/layout/app-shell";
import { quranMeta } from "@/content/catalog";
import { RECITERS } from "@/lib/audio";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/more/")({ component: MorePage });

function MorePage() {
  const settings = useAppStore((s) => s.settings);
  const setTheme = useAppStore((s) => s.setTheme);
  const setLarge = useAppStore((s) => s.setLargeDisplay);
  const setReciter = useAppStore((s) => s.setReciter);
  const setFont = useAppStore((s) => s.setFontScale);
  const setQuran = useAppStore((s) => s.setQuranScale);

  return (
    <AppShell>
      <TopBar title="المزيد" back={<BackButton href="/" />} />
      <div className="space-y-4 px-4 py-4">
        <Card title="العرض الكبير">
          <p className="mb-3 text-xs leading-5 text-muted-foreground">
            خط أكبر، أزرار أوضح، ومساحات أوسع لتسهيل القراءة والاستماع لكبار السن.
          </p>
          <Toggle checked={settings.largeDisplay} onChange={setLarge} label="تفعيل العرض الكبير" />
        </Card>

        <Card title="المظهر">
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                ["light", "فاتح"],
                ["dark", "ليلي"],
                ["system", "تلقائي"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTheme(id)}
                className={`h-11 rounded-xl text-sm ${settings.theme === id ? "bg-accent text-accent-foreground" : "bg-surface"}`}
              >
                {label}
              </button>
            ))}
          </div>
        </Card>

        <Card title="حجم الخط">
          <label className="block text-xs text-muted-foreground">المصحف</label>
          <input
            type="range"
            min={0.9}
            max={1.8}
            step={0.05}
            value={settings.quranScale}
            onChange={(e) => setQuran(Number(e.target.value))}
            className="mt-1 w-full"
          />
          <label className="mt-3 block text-xs text-muted-foreground">المتون والأذكار</label>
          <input
            type="range"
            min={0.85}
            max={1.6}
            step={0.05}
            value={settings.fontScale}
            onChange={(e) => setFont(Number(e.target.value))}
            className="mt-1 w-full"
          />
        </Card>

        <Card title="القارئ">
          <select
            className="h-11 w-full rounded-xl border border-border bg-background px-3 text-sm"
            value={settings.reciterId}
            onChange={(e) => setReciter(e.target.value)}
          >
            {RECITERS.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>
        </Card>

        <Card title="أقسام">
          <Link to="/listen" className="block py-2 text-sm">
            الاستماع والتنزيل
          </Link>
          <Link to="/search" className="block py-2 text-sm">
            البحث الموحد
          </Link>
        </Card>

        <Card title="المصادر">
          <ul className="space-y-3 text-xs leading-6 text-muted-foreground">
            <li>
              <strong className="text-foreground">{quranMeta.source.name}</strong>
              <br />
              {quranMeta.source.publisher}. {quranMeta.source.note}
            </li>
            <li>
              التفسير الميسر، إعداد مجمع الملك فهد لطباعة المصحف الشريف.
            </li>
            <li>
              حصن المسلم من أذكار الكتاب والسنة، لسعيد بن علي بن وهف القحطاني (نسخة مقابلة على المطبوع).
            </li>
            <li>الأربعون النووية، عن رواية معتمدة عبر sunnah.com.</li>
            <li>
              الأصول الثلاثة، القواعد الأربع، كتاب التوحيد، وتحفة الأطفال: من ويكي مصدر اعتمادًا على المطبوع.
            </li>
            <li>التلاوة من تسجيلات مشاري العفاسي والحصري والسديس والمنشاوي عبر مصادر علنية للتلاوة.</li>
          </ul>
        </Card>

        <p className="px-1 pb-4 text-center text-[11px] text-muted-foreground">
          رفيق تطبيق يومي للقراءة والاستماع. لا شبكة اجتماعية، ولا اشتراك على النصوص الشرعية.
        </p>
      </div>
    </AppShell>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl bg-card p-4 shadow-[var(--shadow-border)]">
      <h2 className="mb-3 text-sm font-semibold">{title}</h2>
      {children}
    </section>
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative h-8 w-14 rounded-full ${checked ? "bg-accent" : "bg-surface-2"}`}
    >
      <span
        className={`absolute top-1 size-6 rounded-full bg-paper transition-transform duration-[var(--motion-fast)] ${checked ? "start-7" : "start-1"}`}
      />
    </button>
  );
}
