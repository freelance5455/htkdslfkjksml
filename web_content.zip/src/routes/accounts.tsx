import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Badge, PageTitle, TableWrap, Td, Th } from "@/components/ui";
import { bootstrap } from "@/lib/server/books";
import { useQuery } from "@tanstack/react-query";

export const Route = createFileRoute("/accounts")({ component: AccountsPage });

function AccountsPage() {
  const boot = useQuery({ queryKey: ["bootstrap"], queryFn: () => bootstrap() });
  const accounts = (boot.data?.accounts ?? []) as Array<Record<string, unknown>>;
  return (
    <AppShell>
      <PageTitle title="کدینگ حساب‌ها" subtitle="چهار سطح پویا — گروه، کل، معین، تفصیلی شناور" />
      <TableWrap>
        <thead>
          <tr>
            <Th>کد</Th>
            <Th>نام</Th>
            <Th>سطح</Th>
            <Th>ماهیت</Th>
            <Th>نوع</Th>
          </tr>
        </thead>
        <tbody>
          {accounts.map((a) => (
            <tr key={String(a.id)}>
              <Td className="tabular font-medium" style={{ paddingInlineStart: `${(Number(a.level) - 1) * 12}px` }}>
                {String(a.code)}
              </Td>
              <Td>{String(a.name)}</Td>
              <Td>{String(a.level)}</Td>
              <Td>{a.nature === "debit" ? "بدهکار" : "بستانکار"}</Td>
              <Td>
                <Badge>{String(a.type)}</Badge>
              </Td>
            </tr>
          ))}
        </tbody>
      </TableWrap>
    </AppShell>
  );
}
