import { Link, createFileRoute } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { WEEKDAYS, WEEKDAY_LABEL, weekdayFromDate } from "@/lib/dates";
import { SESSION_TYPE_LABEL } from "@/lib/defaults";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/treinos/")({ component: TreinosPage });

function TreinosPage() {
  const workouts = useAppStore((s) => s.workouts);
  const todayKey = weekdayFromDate(new Date());
  const active = useAppStore((s) => s.activeSession);

  return (
    <div className="animate-in fade-in duration-300">
      <PageHeader
        kicker="Semana"
        title="Treinos"
        subtitle="Muay Thai, força e recuperação. Postura fica na aba própria."
      />
      <div className="space-y-3">
        {WEEKDAYS.map((day) => {
          const w = workouts[day];
          const isToday = day === todayKey;
          return (
            <Link key={day} to="/treinos/$day" params={{ day }} className="block">
              <Card
                className={cn(
                  "flex items-center gap-4 p-4 transition-colors hover:border-primary/40",
                  isToday && "glow-ring",
                )}
              >
                <div className="w-16 shrink-0">
                  <p className="text-[11px] font-medium tracking-wide text-muted-foreground uppercase">
                    {WEEKDAY_LABEL[day].slice(0, 3)}
                  </p>
                  <p className="font-display text-lg font-semibold leading-tight">
                    {WEEKDAY_LABEL[day]}
                  </p>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-medium">{SESSION_TYPE_LABEL[w.type]}</p>
                    {isToday ? <Badge tone="primary">Hoje</Badge> : null}
                    {active?.dayKey === day ? (
                      <Badge tone="success">Em andamento</Badge>
                    ) : null}
                  </div>
                  <p className="text-sm text-muted-foreground">{w.subtitle}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {w.exercises.length} exercícios
                  </p>
                </div>
                <ChevronRight className="size-4 text-muted-foreground" />
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
