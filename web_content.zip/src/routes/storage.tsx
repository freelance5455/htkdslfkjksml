import { createFileRoute } from "@tanstack/react-router";
import { HardDrive } from "lucide-react";
import { useEffect, useState } from "react";
import { AppShell, ScreenBody } from "@/components/vishal/app-shell";
import { IconBadge, InfoRow, Panel, ScreenHeader } from "@/components/vishal/screen-header";
import { formatBytes } from "@/lib/utils";
import { readStorage, type StorageReading } from "@/lib/web-device";

export const Route = createFileRoute("/storage")({ component: StoragePage });

function StoragePage() {
  const [storage, setStorage] = useState<StorageReading | null>(null);

  useEffect(() => {
    void readStorage().then(setStorage);
  }, []);

  const fraction = storage && storage.totalBytes > 0 ? storage.usedBytes / storage.totalBytes : 0;
  const usedPct = Math.round(fraction * 100);

  return (
    <AppShell>
      <ScreenBody>
        <ScreenHeader
          title="Storage Info"
          subtitle="This preview shows browser storage. The Android app shows real phone storage."
        />
        <Panel>
          <IconBadge className="bg-sky/15 text-sky">
            <HardDrive className="size-5" />
          </IconBadge>
          <p className="mt-4 text-4xl font-bold tabular-nums tracking-tight text-fg">
            {storage ? `${usedPct}% used` : "—"}
          </p>
          <p className="text-sm text-muted">
            {storage ? `${formatBytes(storage.freeBytes)} free` : "Reading storage…"}
          </p>
          <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-primary/15">
            <div
              className="h-full rounded-full bg-primary transition-[width] duration-300 ease-out"
              style={{ width: `${usedPct}%` }}
            />
          </div>
        </Panel>
        <div className="mt-3.5 flex flex-col gap-2.5">
          <InfoRow label="Total storage" value={storage ? formatBytes(storage.totalBytes) : "..."} />
          <InfoRow label="Used storage" value={storage ? formatBytes(storage.usedBytes) : "..."} />
          <InfoRow label="Free storage" value={storage ? formatBytes(storage.freeBytes) : "..."} />
        </div>
      </ScreenBody>
    </AppShell>
  );
}
