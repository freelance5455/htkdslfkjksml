import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, ImagePlus, Star, Upload } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { MediaGrid } from "@/components/media-grid";
import { MediaViewer } from "@/components/media-viewer";
import { StarPhoto } from "@/components/star-photo";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  useStar,
  useStarMedia,
  useVault,
  type MediaMeta,
} from "@/store/vault";

export const Route = createFileRoute("/star/$slug")({ component: StarPage });

function StarPage() {
  const { slug } = Route.useParams();
  const navigate = useNavigate();
  const ready = useVault((s) => s.ready);
  const star = useStar(slug);
  const media = useStarMedia(slug);
  const importFiles = useVault((s) => s.importFiles);
  const setStarPhoto = useVault((s) => s.setStarPhoto);
  const toggleFavorite = useVault((s) => s.toggleFavorite);
  const removeMedia = useVault((s) => s.removeMedia);
  const removeUserStar = useVault((s) => s.removeUserStar);
  const photoRef = useRef<HTMLInputElement>(null);
  const mediaRef = useRef<HTMLInputElement>(null);
  const [tab, setTab] = useState("all");
  const [open, setOpen] = useState<MediaMeta | null>(null);
  const [busy, setBusy] = useState(false);

  const items = useMemo(() => {
    if (tab === "all") return media;
    return media.filter((m) => m.kind === tab);
  }, [media, tab]);

  if (!star) {
    if (!ready) {
      return (
        <AppShell>
          <div className="mx-auto max-w-lg px-6 py-24 text-center text-muted-foreground">Loading</div>
        </AppShell>
      );
    }
    return (
      <AppShell>
        <div className="mx-auto max-w-lg px-6 py-24 text-center">
          <p className="font-display text-3xl">Not in the roster</p>
          <Button asChild className="mt-6">
            <Link to="/">Back</Link>
          </Button>
        </div>
      </AppShell>
    );
  }

  const profile = star;

  async function addFiles(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    try {
      const result = await importFiles([...files], slug);
      if (result.filed) toast.success(`${result.filed} added to ${profile.name}`);
      if (result.failed) toast.error("Some files could not be saved");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl px-4 pb-20 pt-4">
        <div className="mb-6 flex items-center gap-2">
          <Button variant="ghost" size="icon" asChild aria-label="Back">
            <Link to="/">
              <ArrowLeft className="size-4" />
            </Link>
          </Button>
          <p className="text-sm text-muted-foreground">Roster</p>
        </div>

        <div className="grid gap-6 md:grid-cols-[16rem_1fr] md:items-end">
          <button
            type="button"
            onClick={() => photoRef.current?.click()}
            className="relative mx-auto aspect-portrait w-56 overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)] md:mx-0 md:w-full"
            aria-label="Change profile photo"
          >
            <StarPhoto star={profile} sizes="256px" />
            <span className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-1 bg-ink/70 py-2 text-xs text-paper">
              <ImagePlus className="size-3.5" />
              Change photo
            </span>
          </button>
          <div>
            <h1 className="font-display text-4xl font-medium tracking-tight sm:text-5xl">
              {profile.name}
            </h1>
            <p className="mt-2 text-sm tabular-nums text-muted-foreground">
              {profile.counts.video} videos · {profile.counts.photo} photos · {profile.counts.gif} GIFs
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button onClick={() => mediaRef.current?.click()} disabled={busy}>
                <Upload className="size-4" />
                Add media
              </Button>
              <Button
                variant={profile.favorite ? "default" : "outline"}
                onClick={() => void toggleFavorite(profile.slug)}
              >
                <Star className={`size-4 ${profile.favorite ? "fill-current" : ""}`} />
                {profile.favorite ? "Saved" : "Save"}
              </Button>
              {profile.addedByUser ? (
                <Button
                  variant="ghost"
                  className="text-muted-foreground"
                  onClick={async () => {
                    await removeUserStar(profile.slug);
                    navigate({ to: "/" });
                  }}
                >
                  Remove profile
                </Button>
              ) : null}
            </div>
          </div>
        </div>

        <input
          ref={photoRef}
          type="file"
          accept="image/*"
          className="sr-only"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void setStarPhoto(profile.slug, file);
            e.currentTarget.value = "";
          }}
        />
        <input
          ref={mediaRef}
          type="file"
          accept="video/*,image/*,.gif,.webm,.mp4,.mov,.mkv,.m4v"
          multiple
          className="sr-only"
          onChange={(e) => {
            void addFiles(e.target.files);
            e.currentTarget.value = "";
          }}
        />

        <Tabs value={tab} onValueChange={setTab} className="mt-10">
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="video">Videos</TabsTrigger>
            <TabsTrigger value="photo">Photos</TabsTrigger>
            <TabsTrigger value="gif">GIFs</TabsTrigger>
          </TabsList>
          <TabsContent value={tab}>
            <MediaGrid
              items={items}
              onOpen={setOpen}
              onDelete={(item) => void removeMedia(item.id)}
            />
          </TabsContent>
        </Tabs>
      </div>
      <MediaViewer item={open} onClose={() => setOpen(null)} />
    </AppShell>
  );
}
