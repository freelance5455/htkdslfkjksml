import { useState } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, Pencil, Play } from "lucide-react";
import { toast } from "sonner";
import { LiveExerciseCard } from "@/components/exercise-card";
import { PageHeader } from "@/components/page-header";
import { WorkoutEditor } from "@/components/workout-editor";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { WEEKDAY_LABEL, toDateKey } from "@/lib/dates";
import { SESSION_TYPE_LABEL } from "@/lib/defaults";
import { useAppStore } from "@/lib/store";
import type { Weekday } from "@/lib/types";

export const Route = createFileRoute("/treinos/$day")({
  component: WorkoutDayPage,
});

const VALID: Weekday[] = [
  "segunda",
  "terca",
  "quarta",
  "quinta",
  "sexta",
  "sabado",
  "domingo",
];

function WorkoutDayPage() {
  const { day } = Route.useParams();
  const dayKey = day as Weekday;
  const valid = VALID.includes(dayKey);
  const workout = useAppStore((s) => (valid ? s.workouts[dayKey] : null));
  const active = useAppStore((s) => s.activeSession);
  const startSession = useAppStore((s) => s.startSession);
  const completeSet = useAppStore((s) => s.completeSet);
  const undoSet = useAppStore((s) => s.undoSet);
  const updateLiveExercise = useAppStore((s) => s.updateLiveExercise);
  const finishSession = useAppStore((s) => s.finishSession);
  const abandonSession = useAppStore((s) => s.abandonSession);
  const setSessionNotes = useAppStore((s) => s.setSessionNotes);
  const [editing, setEditing] = useState(false);
  const [finishOpen, setFinishOpen] = useState(false);

  const updateWorkoutExercise = useAppStore((s) => s.updateWorkoutExercise);
  const addWorkoutExercise = useAppStore((s) => s.addWorkoutExercise);
  const removeWorkoutExercise = useAppStore((s) => s.removeWorkoutExercise);
  const duplicateWorkoutExercise = useAppStore((s) => s.duplicateWorkoutExercise);
  const moveWorkoutExercise = useAppStore((s) => s.moveWorkoutExercise);
  const restoreWorkout = useAppStore((s) => s.restoreWorkout);

  if (!valid || !workout) {
    return (
      <div>
        <p className="text-sm text-muted-foreground">Treino não encontrado.</p>
        <Button asChild variant="outline" className="mt-4">
          <Link to="/treinos">Voltar</Link>
        </Button>
      </div>
    );
  }

  const isLive = active?.dayKey === dayKey;
  const live = isLive ? active : null;
  const totalSets = (live?.exercises ?? workout.exercises).reduce(
    (a, e) => a + e.sets,
    0,
  );
  const doneSets = live
    ? live.exercises.reduce((a, e) => a + e.completedSets, 0)
    : 0;

  function start() {
    if (active && active.dayKey !== dayKey) {
      toast.error("Finalize a sessão em andamento antes de começar outra.");
      return;
    }
    if (!workout) return;
    startSession({
      date: toDateKey(new Date()),
      dayKey,
      exercises: workout.exercises,
      type: workout.type,
      title: workout.title,
    });
    setEditing(false);
    toast.success("Sessão iniciada");
  }

  function confirmFinish() {
    finishSession();
    setFinishOpen(false);
    toast.success("Sessão salva");
  }

  return (
    <div className="animate-in fade-in duration-300">
      <Button asChild variant="ghost" size="sm" className="-ml-2 mb-3">
        <Link to="/treinos">
          <ArrowLeft /> Semana
        </Link>
      </Button>
      <PageHeader
        kicker={WEEKDAY_LABEL[dayKey]}
        title={SESSION_TYPE_LABEL[workout.type]}
        subtitle={workout.subtitle}
        action={
          live ? null : (
            <Button
              variant={editing ? "secondary" : "outline"}
              size="sm"
              onClick={() => setEditing((v) => !v)}
            >
              <Pencil /> {editing ? "Fechar edição" : "Editar treino"}
            </Button>
          )
        }
      />

      {live ? (
        <Card className="mb-4 flex items-center justify-between gap-3 p-4">
          <div>
            <p className="text-xs text-muted-foreground">Sessão em andamento</p>
            <p className="font-mono text-lg font-semibold tabular-nums">
              {doneSets}/{totalSets} séries
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={abandonSession}>
              Descartar
            </Button>
            <Button size="sm" onClick={() => setFinishOpen(true)}>
              Finalizar
            </Button>
          </div>
        </Card>
      ) : editing ? null : (
        <Button className="mb-4 w-full" size="lg" onClick={start}>
          <Play /> Iniciar sessão
        </Button>
      )}

      {editing && !live ? (
        <WorkoutEditor
          exercises={workout.exercises}
          handlers={{
            onUpdate: (id, patch) => updateWorkoutExercise(dayKey, id, patch),
            onAdd: () => addWorkoutExercise(dayKey),
            onRemove: (id) => removeWorkoutExercise(dayKey, id),
            onDuplicate: (id) => duplicateWorkoutExercise(dayKey, id),
            onMove: (id, dir) => moveWorkoutExercise(dayKey, id, dir),
            onRestore: () => restoreWorkout(dayKey),
          }}
        />
      ) : live ? (
        <div className="space-y-3">
          {live.exercises.map((ex) => (
            <LiveExerciseCard
              key={ex.id}
              exercise={ex}
              onCompleteSet={() => completeSet(ex.id)}
              onUndoSet={() => undoSet(ex.id)}
              onPatch={(patch) => updateLiveExercise(ex.id, patch)}
            />
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {workout.exercises.map((ex) => (
            <Card key={ex.id} className="p-4">
              <h3 className="font-display font-semibold">{ex.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {ex.sets} × {ex.reps}
                {ex.load ? ` · ${ex.load}` : ""} · descanso {ex.restSec}s
              </p>
              {ex.notes ? (
                <p className="mt-2 text-xs text-muted-foreground">{ex.notes}</p>
              ) : null}
            </Card>
          ))}
        </div>
      )}

      <Dialog open={finishOpen} onOpenChange={setFinishOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Finalizar sessão</DialogTitle>
            <DialogDescription>
              A sessão entra no histórico. Você pode acrescentar uma observação.
            </DialogDescription>
          </DialogHeader>
          <Textarea
            value={live?.notes ?? ""}
            onChange={(e) => setSessionNotes(e.target.value)}
            placeholder="Como foi o treino"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setFinishOpen(false)}>
              Voltar
            </Button>
            <Button onClick={confirmFinish}>Salvar sessão</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
