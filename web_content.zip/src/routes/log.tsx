import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { BreedingForm, HealthForm } from "@/components/forms";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  formatDate,
  formatInt,
  HEALTH_KIND_LABEL,
  sheepName,
} from "@/lib/flock/logic";
import { useFlock } from "@/lib/flock/store";

export const Route = createFileRoute("/log")({
  component: LogPage,
});

function LogPage() {
  const sheep = useFlock((s) => s.sheep);
  const health = useFlock((s) => s.health);
  const breeding = useFlock((s) => s.breeding);
  const removeHealth = useFlock((s) => s.removeHealth);
  const removeBreeding = useFlock((s) => s.removeBreeding);
  const [showHealth, setShowHealth] = useState(false);
  const [showBreed, setShowBreed] = useState(false);

  const healthRows = health.slice().sort((a, b) => (a.date < b.date ? 1 : -1));
  const breedRows = breeding
    .slice()
    .sort((a, b) => (a.matingDate < b.matingDate ? 1 : -1));

  return (
    <AppShell title="السجلات">
      <Tabs defaultValue="health">
          <TabsList>
            <TabsTrigger value="health">الصحة</TabsTrigger>
            <TabsTrigger value="breeding">التناسل</TabsTrigger>
          </TabsList>
          <TabsContent value="health">
            <div className="flex flex-col gap-4">
              {showHealth ? (
                <Card>
                  <HealthForm onDone={() => setShowHealth(false)} />
                </Card>
              ) : (
                <Button variant="outline" onClick={() => setShowHealth(true)}>
                  تسجيل علاج أو تطعيم
                </Button>
              )}
              <p className="text-sm leading-normal text-muted-foreground">
                سجل شخصي للمتابعة، وليس استشارة بيطرية.
              </p>
              {healthRows.length === 0 ? (
                <p className="text-sm text-muted-foreground">لا سجلات صحية بعد.</p>
              ) : (
                healthRows.map((h) => {
                  const who = sheep.find((s) => s.id === h.sheepId);
                  return (
                    <div key={h.id} className="border-b border-border pb-3">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="font-medium">{h.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {HEALTH_KIND_LABEL[h.kind]} · {formatDate(h.date)}
                          </p>
                          {who ? (
                            <Link
                              to="/sheep/$id"
                              params={{ id: who.id }}
                              className="text-sm"
                            >
                              {sheepName(who, "")}
                            </Link>
                          ) : (
                            <p className="text-sm">القطيع كله</p>
                          )}
                          {h.notes ? (
                            <p className="mt-1 text-sm whitespace-pre-wrap text-muted-foreground">
                              {h.notes}
                            </p>
                          ) : null}
                        </div>
                        <button
                          type="button"
                          className="text-sm text-muted-foreground"
                          onClick={() => removeHealth(h.id)}
                        >
                          حذف
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </TabsContent>
          <TabsContent value="breeding">
            <div className="flex flex-col gap-4">
              {showBreed ? (
                <Card>
                  <BreedingForm onDone={() => setShowBreed(false)} />
                </Card>
              ) : (
                <Button variant="outline" onClick={() => setShowBreed(true)}>
                  تسجيل تلقيح
                </Button>
              )}
              {breedRows.length === 0 ? (
                <p className="text-sm text-muted-foreground">لا تلقيحات بعد.</p>
              ) : (
                breedRows.map((b) => {
                  const ewe = sheep.find((s) => s.id === b.eweId);
                  const ram = sheep.find((s) => s.id === b.ramId);
                  const label =
                    b.result === "pending"
                      ? "حمل قائم"
                      : b.result === "lambed"
                        ? `ولادة · ${formatInt(b.lambCount ?? 0)}`
                        : "حمل مفقود";
                  return (
                    <div key={b.id} className="border-b border-border pb-3">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="font-medium">{label}</p>
                          <p className="text-sm text-muted-foreground">
                            تلقيح {formatDate(b.matingDate)}
                            {b.result === "pending"
                              ? ` · ولادة ${formatDate(b.expectedDate)}`
                              : b.closedDate
                                ? ` · أُغلق ${formatDate(b.closedDate)}`
                                : ""}
                          </p>
                          <p className="text-sm">
                            {ewe ? (
                              <Link to="/sheep/$id" params={{ id: ewe.id }}>
                                نعجة {sheepName(ewe, "")}
                              </Link>
                            ) : (
                              "نعجة محذوفة"
                            )}
                            {" · "}
                            {ram ? (
                              <Link to="/sheep/$id" params={{ id: ram.id }}>
                                كبش {sheepName(ram, "")}
                              </Link>
                            ) : (
                              "كبش غير محدد"
                            )}
                          </p>
                          {b.notes ? (
                            <p className="mt-1 text-sm text-muted-foreground">
                              {b.notes}
                            </p>
                          ) : null}
                        </div>
                        {b.result !== "pending" ? (
                          <button
                            type="button"
                            className="text-sm text-muted-foreground"
                            onClick={() => removeBreeding(b.id)}
                          >
                            حذف
                          </button>
                        ) : null}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </TabsContent>
        </Tabs>
    </AppShell>
  );
}
