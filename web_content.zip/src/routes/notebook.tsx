import { createFileRoute } from "@tanstack/react-router";
import { NotebookView } from "@/components/planner/views/notebook";

export const Route = createFileRoute("/notebook")({
  component: NotebookView,
});
