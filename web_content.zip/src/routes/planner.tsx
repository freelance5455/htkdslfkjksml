import { createFileRoute } from "@tanstack/react-router";
import { PlannerPage } from "@/components/ministry/planner-page";
import { AppShell } from "@/components/ministry/shell";

export const Route = createFileRoute("/planner")({
  component: function PlannerRoute() {
    return (
      <AppShell>
        <PlannerPage />
      </AppShell>
    );
  },
});
