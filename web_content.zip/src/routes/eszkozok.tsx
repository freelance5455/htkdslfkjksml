import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { HoldingDialog } from "@/components/holding-dialog";
import { Shell } from "@/components/shell";
import { Field, Modal } from "@/components/ui";
import { CLASS_LABEL, KIND_LABEL, formatMoney, formatQty, pnlClass, uid } from "@/lib/format";
import { sumViews, viewHolding, viewsOf } from "@/lib/portfolio-math";
import { usePortfolio } from "@/lib/portfolio-context";
import type { Group, GroupKind, Holding } from "@/lib/types";

export const Route = createFileRoute("/eszkozok")({ component: Page });

function Page() {
  return (
    <Shell>
      <Assets />
    </Shell>
  );
}

function Assets() {
  const { state, deleteHolding, saveGroup, deleteGroup } = usePortfolio();
  const [groupFilter, setGroupFilter] = useState("mind");
  const [query, setQuery] = useState("");
  const [dialog, setDialog] = useState<{ open: boolean; holding: Holding | null; mode: "asset" | "cash" }>({
    open: false,
    holding: null,
    mode: "asset",
  });
  const [groupEditor, setGroupEditor] = useState<Group | null>(null);
  const [groupError, setGroupError] = useState("");

  const rows = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return viewsOf(state, groupFilter === "mind" ? undefined : groupFilter)
      .filter((row) => {
        if (!needle) return true;
        return `${row.holding.name} ${row.holding.symbol}`.toLowerCase().includes(needle);
      })
      .sort((a, b) => b.huf - a.huf);
  }, [state, groupFilter, query]);
  const totals = sumViews(rows);

  const cashByGroup = state.groups
    .map((group) => ({
      group,
      rows: state.holdings
        .filter((holding) => holding.assetClass === "keszpenz" && holding.groupId === group.id)
        .map((holding) => viewHolding(holding, state.market)),
    }))
    .filter((block) => block.rows.length);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl">Eszközök</h1>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Egy számlán több deviza is állhat. Ugyanaz az ETF külön TBSZ-eken külön sor, külön bekerüléssel.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn btn-ghost" onClick={() => setDialog({ open: true, holding: null, mode: "cash" })}>
            Készpénz
          </button>
          <button type="button" className="btn btn-primary" onClick={() => setDialog({ open: true, holding: null, mode: "asset" })}>
            Új eszköz
          </button>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        <Filter on={groupFilter === "mind"} onClick={() => setGroupFilter("mind")}>
          Mind
        </Filter>
        {state.groups.map((group) => (
          <Filter key={group.id} on={groupFilter === group.id} onClick={() => setGroupFilter(group.id)}>
            {group.name}
          </Filter>
        ))}
        <button type="button" className="btn btn-quiet" onClick={() => setGroupEditor({ id: uid(), name: "", kind: "tbsz" })}>
          Új csoport
        </button>
      </div>

      <div className="mt-4">
        <input className="field max-w-sm" placeholder="Keresés" value={query} onChange={(event) => setQuery(event.target.value)} />
      </div>

      <p className="mt-6 text-sm text-muted tabular-nums">
        Szűrt érték {formatMoney(totals.huf, "HUF")} · {formatMoney(totals.usd, "USD")}
      </p>

      {cashByGroup.length ? (
        <section className="mt-8">
          <h2 className="font-serif text-2xl">Készpénz devizánként</h2>
          <div className="mt-3 grid gap-4 md:grid-cols-2">
            {cashByGroup.map((block) => {
              const sum = sumViews(block.rows);
              return (
                <div key={block.group.id} className="rounded-2xl border border-line bg-surface p-4">
                  <div className="flex items-baseline justify-between gap-3">
                    <h3 className="font-medium">{block.group.name}</h3>
                    <p className="text-sm text-muted tabular-nums">{formatMoney(sum.huf, "HUF")}</p>
                  </div>
                  <ul className="mt-2">
                    {block.rows.map((row) => (
                      <li key={row.holding.id} className="flex items-baseline justify-between gap-3 py-1 text-sm tabular-nums">
                        <span>{formatQty(row.holding.quantity)} {row.holding.currency}</span>
                        <span className="text-muted">{formatMoney(row.usd, "USD")}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </section>
      ) : null}

      <ul className="mt-8 divide-y divide-line border-t border-line">
        {rows.map((row) => {
          const group = state.groups.find((item) => item.id === row.holding.groupId);
          return (
            <li key={row.holding.id} className="grid gap-3 py-4 md:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)_auto] md:items-center">
              <div className="min-w-0">
                <p className="truncate">
                  <span className="font-medium">{row.holding.name}</span>{" "}
                  <span className="text-sm text-muted">{row.holding.symbol}</span>
                </p>
                <p className="text-sm text-muted">
                  {group?.name ?? "Csoport nélkül"} · {CLASS_LABEL[row.holding.assetClass]} · {formatQty(row.holding.quantity)}{" "}
                  {row.holding.assetClass === "keszpenz" ? row.holding.currency : "db"}
                </p>
              </div>
              <div className="tabular-nums md:text-right">
                <p>{formatMoney(row.huf, "HUF")}</p>
                <p className="text-sm text-muted">{formatMoney(row.usd, "USD")}</p>
              </div>
              <div className="flex items-center justify-between gap-3 md:flex-col md:items-end">
                <p className={`text-sm tabular-nums ${pnlClass(row.totalPnlHuf)}`}>
                  ár {formatMoney(row.pricePnlHuf, "HUF")} · deviza {formatMoney(row.fxPnlHuf, "HUF")}
                </p>
                <div className="flex gap-1">
                  <button type="button" className="btn btn-quiet" onClick={() => setDialog({ open: true, holding: row.holding, mode: "asset" })}>
                    Módosít
                  </button>
                  <button
                    type="button"
                    className="btn btn-quiet text-clay"
                    onClick={() => {
                      if (confirm(`Törlöd: ${row.holding.name}?`)) deleteHolding(row.holding.id);
                    }}
                  >
                    Töröl
                  </button>
                </div>
              </div>
            </li>
          );
        })}
        {rows.length === 0 ? <li className="py-10 text-sm text-muted">Ebben a szűrésben nincs eszköz.</li> : null}
      </ul>

      <section className="mt-10">
        <h2 className="font-serif text-2xl">Csoportok</h2>
        <ul className="mt-3 divide-y divide-line">
          {state.groups.map((group) => (
            <li key={group.id} className="flex items-center justify-between gap-3 py-3">
              <div>
                <p>{group.name}</p>
                <p className="text-sm text-muted">{KIND_LABEL[group.kind]}</p>
              </div>
              <div className="flex gap-1">
                <button type="button" className="btn btn-quiet" onClick={() => setGroupEditor(group)}>
                  Átnevez
                </button>
                <button
                  type="button"
                  className="btn btn-quiet text-clay"
                  onClick={() => {
                    const message = deleteGroup(group.id);
                    if (message) setGroupError(message);
                  }}
                >
                  Töröl
                </button>
              </div>
            </li>
          ))}
        </ul>
        {groupError ? <p className="text-sm text-clay">{groupError}</p> : null}
      </section>

      <HoldingDialog
        open={dialog.open}
        holding={dialog.holding}
        mode={dialog.mode}
        onClose={() => setDialog((current) => ({ ...current, open: false }))}
      />
      <GroupDialog
        group={groupEditor}
        onClose={() => setGroupEditor(null)}
        onSave={(group) => {
          saveGroup(group);
          setGroupEditor(null);
          setGroupError("");
        }}
      />
    </div>
  );
}

function Filter({ on, onClick, children }: { on: boolean; onClick: () => void; children: string }) {
  return (
    <button type="button" onClick={onClick} className={`btn ${on ? "btn-primary" : "btn-ghost"}`}>
      {children}
    </button>
  );
}

function GroupDialog({ group, onClose, onSave }: { group: Group | null; onClose: () => void; onSave: (group: Group) => void }) {
  const [name, setName] = useState(group?.name ?? "");
  const [kind, setKind] = useState<GroupKind>(group?.kind ?? "tbsz");
  useEffect(() => {
    setName(group?.name ?? "");
    setKind(group?.kind ?? "egyeb");
  }, [group]);
  return (
    <Modal open={Boolean(group)} title={group && group.name ? "Csoport" : "Új csoport"} onClose={onClose}>
      <div className="grid gap-3">
        <Field label="Név">
          <input className="field" value={name} onChange={(event) => setName(event.target.value)} placeholder="TBSZ 2027" />
        </Field>
        <Field label="Típus">
          <select className="field" value={kind} onChange={(event) => setKind(event.target.value as GroupKind)}>
            {(Object.keys(KIND_LABEL) as GroupKind[]).map((item) => (
              <option key={item} value={item}>
                {KIND_LABEL[item]}
              </option>
            ))}
          </select>
        </Field>
        <div className="mt-2 flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Mégse
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => group && name.trim() && onSave({ ...group, name: name.trim(), kind })}
          >
            Mentés
          </button>
        </div>
      </div>
    </Modal>
  );
}
