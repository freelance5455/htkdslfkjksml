import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { MoneyText } from "@/components/fields";
import { Card, PageTitle } from "@/components/ui";
import { getDashboard, getKpis } from "@/lib/server/books";
import { useQuery } from "@tanstack/react-query";
import { toFaDigits } from "@/lib/accounting/jalali";

export const Route = createFileRoute("/kpi")({ component: KpiPage });

function KpiPage() {
  const k = useQuery({ queryKey: ["kpi"], queryFn: () => getKpis() });
  const d = useQuery({ queryKey: ["dashboard"], queryFn: () => getDashboard() });
  return (
    <AppShell>
      <PageTitle title="شاخص‌های مدیریتی" subtitle={`سال مالی ${k.data?.fy ?? ""}`} />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <M t="فروش امروز" v={k.data?.salesDaily} />
        <M t="فروش ماه" v={k.data?.salesMonthly} />
        <M t="متوسط فروش" v={k.data?.avgSale} />
        <M t="تعداد فروش ماه" v={k.data?.saleCount} unit="فقره" />
        <M t="وصول ماه" v={k.data?.collection} />
        <M t="درصد وصول" v={k.data?.collectionRate} unit="٪" />
        <M t="هزینه ماه" v={k.data?.expenseMonthly} />
        <M t="هزینه به فروش" v={k.data?.expenseRatio} unit="٪" />
        <M t="مطالبات" v={d.data?.receivables} />
        <M t="بدهی‌ها" v={d.data?.payables} />
        <M t="نقدینگی" v={d.data?.cashTotal} />
        <M t="سود تقریبی" v={d.data?.profit} />
      </div>
    </AppShell>
  );
}

function M({ t, v, unit }: { t: string; v?: number; unit?: string }) {
  return (
    <Card>
      <p className="text-xs text-muted">{t}</p>
      <p className="mt-2 text-2xl font-semibold text-navy">
        {unit === "٪" || unit === "فقره" ? (
          <span className="tabular">{toFaDigits(v ?? 0)} {unit}</span>
        ) : (
          <MoneyText value={v ?? 0} />
        )}
      </p>
    </Card>
  );
}
