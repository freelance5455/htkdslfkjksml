import { createFileRoute } from "@tanstack/react-router";
import { Page } from "@/components/ui";
import { PEOPLE } from "@/data/people";

export const Route = createFileRoute("/companions/$id")({ component: PersonPage });

function PersonPage() {
  const person = PEOPLE.find((p) => p.id === Route.useParams().id);
  if (!person) return <Page title="غير موجود" back>لا توجد هذه الترجمة.</Page>;
  return (
    <Page title={person.name} subtitle={person.cat} back>
      <p className="mb-3 text-sm leading-relaxed">{person.summary}</p>
      <ul className="mb-3 list-disc space-y-2 pe-5 text-sm">
        {person.points.map((p) => (
          <li key={p}>{p}</li>
        ))}
      </ul>
      <p className="text-xs text-muted">المراجع: {person.sources.join(" · ")}</p>
    </Page>
  );
}
