import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Page } from "@/components/ui";
import { PEOPLE } from "@/data/people";

export const Route = createFileRoute("/companions/")({ component: PeopleHome });

function PeopleHome() {
  const cats = Array.from(new Set(PEOPLE.map((p) => p.cat)));
  const [cat, setCat] = useState(cats[0]);
  return (
    <Page title="الصحابة والصالحون" subtitle="تراجم مختصرة. العلماء من أهل السنة ليسوا صحابة، وجُعلوا في تبويب مستقل.">
      <div className="mb-3 flex gap-2 overflow-x-auto">
        {cats.map((c) => (
          <button key={c} type="button" onClick={() => setCat(c)} className={`shrink-0 min-h-11 rounded-full px-3 text-xs ${c === cat ? "bg-btn text-btn-fg" : "border border-line"}`}>
            {c}
          </button>
        ))}
      </div>
      <ul className="space-y-2">
        {PEOPLE.filter((p) => p.cat === cat).map((p) => (
          <li key={p.id}>
            <Link to="/companions/$id" params={{ id: p.id }} className="block rounded-2xl border border-line bg-card px-4 py-3">
              <span className="font-bold">{p.name}</span>
              <span className="mt-1 block text-sm text-muted">{p.summary}</span>
            </Link>
          </li>
        ))}
      </ul>
    </Page>
  );
}
