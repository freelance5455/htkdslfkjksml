import { createFileRoute } from "@tanstack/react-router";
import { Smartphone } from "lucide-react";
import { useEffect, useState } from "react";
import { AppShell, ScreenBody } from "@/components/vishal/app-shell";
import { IconBadge, InfoRow, Panel, ScreenHeader } from "@/components/vishal/screen-header";
import { readDevice, type DeviceReading } from "@/lib/web-device";

export const Route = createFileRoute("/device")({ component: DevicePage });

function DevicePage() {
  const [device, setDevice] = useState<DeviceReading | null>(null);

  useEffect(() => {
    void readDevice().then(setDevice);
  }, []);

  return (
    <AppShell>
      <ScreenBody>
        <ScreenHeader
          title="Device Info"
          subtitle="Hardware and software reported by this device."
        />
        <Panel>
          <IconBadge>
            <Smartphone className="size-5" />
          </IconBadge>
          <h2 className="mt-4 text-2xl font-semibold tracking-tight text-fg">
            {device?.model ?? "Reading…"}
          </h2>
          <p className="text-sm text-muted">{device?.manufacturer ?? ""}</p>
        </Panel>
        <div className="mt-3.5 flex flex-col gap-2.5">
          <InfoRow label="Device model" value={device?.model ?? "..."} />
          <InfoRow label="Manufacturer" value={device?.manufacturer ?? "..."} />
          <InfoRow label="Android / OS" value={device?.androidVersion ?? "..."} />
          <InfoRow label="SDK version" value={device?.sdk ?? "..."} />
          <InfoRow label="Platform" value={device?.platform ?? "..."} />
          <InfoRow label="CPU cores" value={device?.cores ?? "..."} />
          <InfoRow label="Device memory" value={device?.memory ?? "..."} />
          <InfoRow label="Screen" value={device?.screen ?? "..."} />
        </div>
      </ScreenBody>
    </AppShell>
  );
}
