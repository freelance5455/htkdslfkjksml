import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/shell";
import { Field, Modal } from "@/components/ui";
import { formatDay, formatMoney, todayIso, uid } from "@/lib/format";
import { monthlySubscriptionHuf, subscriptionTotals } from "@/lib/portfolio-math";
import { usePortfolio } from "@/lib/portfolio-context";
import type { Cadence, Currency, Subscription } from "@/lib/types";

export const Route = createFileRoute("/dijak")({ component: Page });

const CADENCE: Record<Cadence, string> = { heti: "Hetente", havi: "Havonta", eves: "Évente" };

function Page() {
  return (
    <Shell>
      <Fees />
    </Shell>
  );
}

function Fees() {
  const { state, saveSub, deleteSub } = usePortfolio();
  const [editing, setEditing] = useState<Subscription | null>(null);
  const totals = subscriptionTotals(state.subscriptions, state.market.fx);
  const usd = state.market.fx.usdHuf ? totals.monthly / state.market.fx.usdHuf : 0;
  const wasteUsd = state.market.fx.usdHuf ? totals.wastefulMonthly / state.market.fx.usdHuf : 0;
  const rows = [...state.subscriptions].sort((a, b) => Number(b.wasteful) - Number(a.wasteful) || a.name.localeCompare(b.name, "hu"));

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl">Előfizetések</h1>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Ami rendszeresen elmegy. A feleslegesnek jelölt tételek külön összeadódnak, hogy lásd a szivárgást.
          </p>
        </div>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() =>
            setEditing({
              id: uid(),
              name: "",
              amount: 0,
              currency: "HUF",
              cadence: "havi",
              category: "Egyéb",
              nextDate: todayIso(),
              active: true,
              wasteful: false,
              note: "",
            })
          }
        >
          Új díj
        </button>
      </div>

      <section className="mt-8 grid gap-8 border-t border-line pt-8 sm:grid-cols-2">
        <div>
          <p className="text-sm text-muted">Havi teher</p>
          <p className="mt-1 font-serif text-4xl tabular-nums">{formatMoney(totals.monthly, "HUF")}</p>
          <p className="text-sm text-muted tabular-nums">{formatMoney(usd, "USD")} · évente {formatMoney(totals.annual, "HUF")}</p>
        </div>
        <div className="sm:border-l sm:border-line sm:pl-8">
          <p className="text-sm text-muted">Ebből feleslegesnek jelölt</p>
          <p className="mt-1 font-serif text-4xl text-clay tabular-nums">{formatMoney(totals.wastefulMonthly, "HUF")}</p>
          <p className="text-sm text-muted tabular-nums">{formatMoney(wasteUsd, "USD")} havonta</p>
        </div>
      </section>

      <ul className="mt-8 divide-y divide-line border-t border-line">
        {rows.map((item) => {
          const monthly = monthlySubscriptionHuf(item, state.market.fx);
          return (
            <li key={item.id} className={`grid gap-3 py-4 sm:grid-cols-[minmax(0,1fr)_auto] ${item.wasteful ? "border-l-2 border-clay pl-3" : ""}`}>
              <div>
                <p>
                  <span className={item.active ? "" : "text-muted line-through"}>{item.name}</span>{" "}
                  <span className="text-sm text-muted">{item.category}</span>
                </p>
                <p className="text-sm text-muted">
                  {formatMoney(item.amount, item.currency)} · {CADENCE[item.cadence].toLowerCase()}
                  {item.nextDate ? ` · következő ${formatDay(item.nextDate)}` : ""}
                  {item.wasteful ? " · felesleges" : ""}
                  {!item.active ? " · szünetel" : ""}
                </p>
                {item.note ? <p className="text-sm text-muted">{item.note}</p> : null}
              </div>
              <div className="flex items-center justify-between gap-3 sm:flex-col sm:items-end">
                <p className="tabular-nums">{item.active ? formatMoney(monthly, "HUF") : "—"}</p>
                <div className="flex gap-1">
                  <button type="button" className="btn btn-quiet" onClick={() => saveSub({ ...item, wasteful: !item.wasteful })}>
                    {item.wasteful ? "Mégis kell" : "Felesleges"}
                  </button>
                  <button type="button" className="btn btn-quiet" onClick={() => setEditing(item)}>
                    Módosít
                  </button>
                  <button type="button" className="btn btn-quiet text-clay" onClick={() => deleteSub(item.id)}>
                    Töröl
                  </button>
                </div>
              </div>
            </li>
          );
        })}
        {rows.length === 0 ? <li className="py-10 text-sm text-muted">Nincs rögzített díj.</li> : null}
      </ul>
      <SubDialog item={editing} onClose={() => setEditing(null)} onSave={(item) => { saveSub(item); setEditing(null); }} />
    </div>
  );
}

function SubDialog({ item, onClose, onSave }: { item: Subscription | null; onClose: () => void; onSave: (item: Subscription) => void }) {
  const [draft, setDraft] = useState<Subscription | null>(item);
  useEffect(() => setDraft(item), [item]);
  if (!draft) return <Modal open={false} title="Díj" onClose={onClose}><div /></Modal>;
  return (
    <Modal open={Boolean(item)} title="Előfizetés" onClose={onClose}>
      <div className="grid gap-3">
        <Field label="Név">
          <input className="field" value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} />
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Összeg">
            <input className="field tabular-nums" inputMode="decimal" value={draft.amount || ""} onChange={(event) => setDraft({ ...draft, amount: Number(event.target.value.replace(",", ".")) || 0 })} />
          </Field>
          <Field label="Deviza">
            <select className="field" value={draft.currency} onChange={(event) => setDraft({ ...draft, currency: event.target.value as Currency })}>
              {(["HUF", "USD", "EUR", "GBP"] as Currency[]).map((currency) => (
                <option key={currency}>{currency}</option>
              ))}
            </select>
          </Field>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Gyakoriság">
            <select className="field" value={draft.cadence} onChange={(event) => setDraft({ ...draft, cadence: event.target.value as Cadence })}>
              {(Object.keys(CADENCE) as Cadence[]).map((cadence) => (
                <option key={cadence} value={cadence}>
                  {CADENCE[cadence]}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Kategória">
            <input className="field" value={draft.category} onChange={(event) => setDraft({ ...draft, category: event.target.value })} />
          </Field>
        </div>
        <Field label="Következő terhelés">
          <input className="field" type="date" value={draft.nextDate} onChange={(event) => setDraft({ ...draft, nextDate: event.target.value })} />
        </Field>
        <Field label="Megjegyzés">
          <input className="field" value={draft.note} onChange={(event) => setDraft({ ...draft, note: event.target.value })} />
        </Field>
        <label className="flex min-h-11 items-center gap-3 text-sm">
          <input type="checkbox" className="size-5 accent-pine" checked={draft.active} onChange={(event) => setDraft({ ...draft, active: event.target.checked })} />
          Aktív
        </label>
        <label className="flex min-h-11 items-center gap-3 text-sm">
          <input type="checkbox" className="size-5 accent-pine" checked={draft.wasteful} onChange={(event) => setDraft({ ...draft, wasteful: event.target.checked })} />
          Feleslegesnek jelölöm
        </label>
        <div className="mt-2 flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Mégse
          </button>
          <button type="button" className="btn btn-primary" disabled={!draft.name.trim()} onClick={() => onSave({ ...draft, name: draft.name.trim() })}>
            Mentés
          </button>
        </div>
      </div>
    </Modal>
  );
}
