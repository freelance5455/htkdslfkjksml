import { Link, createFileRoute } from "@tanstack/react-router";
import { AppFrame, PageTitle } from "@/components/shell";
import { useEdu } from "@/components/edu-provider";
import { t } from "@/content/copy";
import { exams } from "@/content/catalog";
import { fill, tx, useLocale } from "@/lib/locale";

export const Route = createFileRoute("/exams/")({ component: ExamsPage });

function ExamsPage() {
  return (
    <AppFrame>
      <ExamsBody />
    </AppFrame>
  );
}

function ExamsBody() {
  const locale = useLocale((state) => state.locale);
  const { profile, progress } = useEdu();
  if (!profile) return null;

  return (
    <div>
      <PageTitle title={t(locale, "exams")} lede={t(locale, "examsLede")} />
      <p className="mb-4 text-sm text-muted">{t(locale, "examNote")}</p>
      <ul className="grid gap-3">
        {exams.map((exam) => {
          const primary = exam.grade === profile.grade || (profile.grade >= 7 && exam.grade === 8) || (profile.grade <= 6 && exam.grade === 6);
          const best = progress
            .filter((row) => row.kind === "exam" && row.itemId === exam.id)
            .map((row) => row.score ?? 0)
            .sort((a, b) => b - a)[0];
          return (
            <li key={exam.id}>
              <article className="rounded-2xl border border-line bg-card p-4">
                <p className="text-sm font-semibold text-teal-deep">
                  {exam.grade === profile.grade ? t(locale, "forYourGrade") : t(locale, "lookingAhead")}
                </p>
                <h2 className="mt-1 text-lg font-semibold">{tx(locale, exam.title)}</h2>
                <p className="mt-1 text-sm text-muted">
                  {exam.questions.length} {t(locale, "questions")} · {fill(t(locale, "minutes"), { n: exam.minutes })}
                  {best !== undefined ? ` · ${t(locale, "best")} ${best}` : ""}
                </p>
                <Link
                  to="/exams/$examId"
                  params={{ examId: exam.id }}
                  className={
                    primary
                      ? "mt-4 inline-flex min-h-11 items-center rounded-md bg-teal px-4 font-semibold text-card"
                      : "mt-4 inline-flex min-h-11 items-center rounded-md border border-line px-4 font-semibold"
                  }
                >
                  {t(locale, "startExam")}
                </Link>
              </article>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
