import { Link, createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppFrame } from "@/components/shell";
import { QuizRunner } from "@/components/quiz-runner";
import { Button } from "@/components/ui/button";
import { useEdu } from "@/components/edu-provider";
import { t } from "@/content/copy";
import { findExam } from "@/content/catalog";
import { fill, tx, useLocale } from "@/lib/locale";
import { hasPack, removePack, savePack } from "@/lib/offline";
import { useOnline } from "@/lib/use-online";

export const Route = createFileRoute("/exams/$examId")({ component: ExamPage });

function ExamPage() {
  return (
    <AppFrame>
      <ExamBody />
    </AppFrame>
  );
}

function ExamBody() {
  const { examId } = Route.useParams();
  const exam = findExam(examId);
  const locale = useLocale((state) => state.locale);
  const { recordExam } = useEdu();
  const online = useOnline();
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    hasPack(examId).then(setSaved).catch(() => setSaved(false));
  }, [examId]);

  if (!exam) return <p className="text-sm">{t(locale, "notFound")}</p>;

  if (!online && !saved) {
    return (
      <div>
        <h1 className="text-2xl font-semibold">{tx(locale, exam.title)}</h1>
        <p className="mt-3 text-sm text-danger">{t(locale, "needsDownload")}</p>
        <Link to="/exams" className="mt-4 inline-flex min-h-11 items-center font-semibold text-teal-deep">
          {t(locale, "back")}
        </Link>
      </div>
    );
  }

  return (
    <div>
      <Link to="/exams" className="text-sm font-semibold text-teal-deep">
        {t(locale, "back")}
      </Link>
      <h1 className="mt-2 text-2xl font-semibold">{tx(locale, exam.title)}</h1>
      <p className="mt-2 text-sm text-muted">
        {exam.questions.length} {t(locale, "questions")} · {fill(t(locale, "minutes"), { n: exam.minutes })}
      </p>
      <div className="mt-4">
        <Button
          variant="secondary"
          onClick={() => {
            void (async () => {
              if (saved) {
                await removePack(exam.id);
                setSaved(false);
              } else {
                await savePack({
                  id: exam.id,
                  kind: "exam",
                  title: tx(locale, exam.title),
                  savedAt: Date.now(),
                  payload: { id: exam.id },
                });
                setSaved(true);
              }
            })();
          }}
        >
          {saved ? t(locale, "remove") : t(locale, "download")}
        </Button>
      </div>
      <div className="mt-6">
        <QuizRunner
          questions={exam.questions}
          locale={locale}
          mode="step"
          submitLabel={t(locale, "submit")}
          onSubmit={(answers) => recordExam(exam.id, answers)}
        />
      </div>
    </div>
  );
}
