import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { MoneyText } from "@/components/fields";
import { Badge, Button, PageTitle, TableWrap, Td, Th } from "@/components/ui";
import { listJournals } from "@/lib/server/books";
import { isoToJalali } from "@/lib/accounting/jalali";
import { downloadCsv } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";

export const Route = createFileRoute("/journals")({ component: JournalsPage });

function JournalsPage() {
  const q = useQuery({ queryKey: ["journals"], queryFn: () => listJournals({ data: {} }) });
  const rows = (q.data ?? []) as Array<Record<string, unknown>>;
  return (
    <AppShell>
      <PageTitle
        title="دفتر روزنامه"
        subtitle="اسناد حسابداری دوبل تولیدشده از عملیات"
        actions={
          <Button
            variant="secondary"
            onClick={() =>
              downloadCsv(
                "journal.csv",
                ["number", "date", "desc", "debit", "credit", "status"],
                rows.map((r) => [String(r.number), isoToJalali(String(r.date), false), String(r.description), String(r.debit_sum), String(r.credit_sum), String(r.status)]),
              )
            }
          >
            Excel
          </Button>
        }
      />
      <TableWrap>
        <thead>
          <tr>
            <Th>شماره</Th>
            <Th>تاریخ</Th>
            <Th>شرح</Th>
            <Th>بدهکار</Th>
            <Th>بستانکار</Th>
            <Th>نوع</Th>
            <Th>وضعیت</Th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const ok = Number(r.debit_sum) === Number(r.credit_sum);
            return (
              <tr key={String(r.id)}>
                <Td className="tabular">{String(r.number)}</Td>
                <Td>{isoToJalali(String(r.date))}</Td>
                <Td>{String(r.description)}</Td>
                <Td><MoneyText value={r.debit_sum} /></Td>
                <Td><MoneyText value={r.credit_sum} /></Td>
                <Td>{String(r.kind)}</Td>
                <Td>
                  <Badge tone={r.status === "posted" && ok ? "ok" : "danger"}>
                    {String(r.status)} {ok ? "" : "نامتوازن"}
                  </Badge>
                </Td>
              </tr>
            );
          })}
        </tbody>
      </TableWrap>
      <p className="mt-3 text-xs text-muted">جمع‌ها باید برابر باشند. اختلاف غیرصفر مانع بستن روز می‌شود.</p>
    </AppShell>
  );
}
