import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Button, Field, Input, PageTitle, Select } from "@/components/ui";
import { bootstrap, saveSettings } from "@/lib/server/books";
import { ROLE_LABELS, type Role } from "@/lib/accounting/types";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const qc = useQueryClient();
  const boot = useQuery({ queryKey: ["bootstrap"], queryFn: () => bootstrap() });
  const c = boot.data?.company;
  const [name, setName] = useState("");
  const [legal, setLegal] = useState("");
  const [role, setRole] = useState<Role>("admin");
  const [salesShipping, setSalesShipping] = useState("income");
  const [purchaseShipping, setPurchaseShipping] = useState("inventory");
  useEffect(() => {
    if (!c) return;
    setName(c.name);
    setLegal(c.legalName);
    setRole(c.role);
    setSalesShipping(c.salesShipping);
    setPurchaseShipping(c.purchaseShipping);
  }, [c]);
  return (
    <AppShell>
      <PageTitle title="تنظیمات" subtitle="شرکت، سال مالی، نقش و سیاست حمل" />
      <form
        className="max-w-lg space-y-3"
        onSubmit={async (e) => {
          e.preventDefault();
          try {
            await saveSettings({
              data: {
                name,
                legalName: legal,
                role,
                salesShipping: salesShipping as "income" | "expense" | "receivable",
                purchaseShipping: purchaseShipping as "inventory" | "expense",
              },
            });
            toast.success("ذخیره شد.");
            qc.invalidateQueries();
          } catch (err) {
            toast.error(err instanceof Error ? err.message : "خطا");
          }
        }}
      >
        <Field label="نام شرکت"><Input value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="نام قانونی"><Input value={legal} onChange={(e) => setLegal(e.target.value)} /></Field>
        <Field label="سال مالی جاری">
          <Input disabled value={c?.fiscalYearCode ?? ""} />
        </Field>
        <Field label="نقش فعال (کنترل دسترسی)">
          <Select value={role} onChange={(e) => setRole(e.target.value as Role)}>
            {Object.entries(ROLE_LABELS).map(([k, v]) => (
              <option key={k} value={k}>{v}</option>
            ))}
          </Select>
        </Field>
        <Field label="اثر حمل در فروش">
          <Select value={salesShipping} onChange={(e) => setSalesShipping(e.target.value)}>
            <option value="income">درآمد حمل</option>
            <option value="expense">هزینه حمل</option>
            <option value="receivable">قابل دریافت از مشتری</option>
          </Select>
        </Field>
        <Field label="اثر حمل در خرید">
          <Select value={purchaseShipping} onChange={(e) => setPurchaseShipping(e.target.value)}>
            <option value="inventory">بخشی از بهای تمام‌شده</option>
            <option value="expense">هزینه حمل</option>
          </Select>
        </Field>
        <Button type="submit">ذخیره تنظیمات</Button>
      </form>
      <div className="mt-8 max-w-lg rounded-xl border border-line bg-card p-4 text-sm leading-7 text-muted">
        <p className="font-medium text-navy">قواعد حسابداری</p>
        هسته سیستم دفتر دوبل است. هیچ سندی بدون توازن بدهکار و بستانکار ثبت نمی‌شود.
        پس از بستن روز فقط سند اصلاحی / برگشتی مجاز است. حذف‌ها منطقی‌اند و در Audit Trail می‌مانند.
        این نرم‌افزار ابزار کنترل داخلی است و ادعای تأیید رسمی حسابرس ندارد.
      </div>
    </AppShell>
  );
}
