import { createFileRoute } from "@tanstack/react-router";
import { SettingsPage } from "@/components/ministry/desk-pages";
import { AppShell } from "@/components/ministry/shell";

export const Route = createFileRoute("/settings")({
  component: function SettingsRoute() {
    return (
      <AppShell>
        <SettingsPage />
      </AppShell>
    );
  },
});
