import type { ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { APP_NAME, APP_VERSION, EQ_FREQUENCIES, SEARCH_ENGINES } from "@/lib/constants";
import { decoderDescription, decoderHelp } from "@/lib/codecs";
import { useBrowser } from "@/lib/browser-store";
import { useSettings } from "@/lib/settings-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const s = useSettings();
  const clearHistory = useBrowser((st) => st.clearHistory);

  return (
    <div className="mx-auto max-w-2xl space-y-10">
      <header>
        <h1 className="font-display text-3xl font-semibold">Settings</h1>
        <p className="text-sm text-muted">Stored on this device only.</p>
      </header>

      <Section title="Appearance">
        <Row label="Theme">
          <Segment
            value={s.theme}
            onChange={(v) => s.set("theme", v)}
            options={[
              { id: "dark", label: "Dark" },
              { id: "light", label: "Light" },
              { id: "system", label: "System" },
            ]}
          />
        </Row>
        <Row label="Accent">
          <Segment
            value={s.accent}
            onChange={(v) => s.set("accent", v)}
            options={[
              { id: "peacock", label: "Peacock" },
              { id: "copper", label: "Copper" },
              { id: "steel", label: "Steel" },
            ]}
          />
        </Row>
      </Section>

      <Section title="Player">
        <Row label="Resume playback" hint="Continue from the last position">
          <Switch checked={s.resumePlayback} onCheckedChange={(v) => s.set("resumePlayback", v)} />
        </Row>
        <Row label="Gesture controls">
          <Switch checked={s.gestures} onCheckedChange={(v) => s.set("gestures", v)} />
        </Row>
        <Row label="Brightness gesture" hint="Left-edge vertical drag">
          <Switch checked={s.brightnessGesture} onCheckedChange={(v) => s.set("brightnessGesture", v)} />
        </Row>
        <Row label="Background playback" hint="Keep a mini player when you leave the screen">
          <Switch checked={s.backgroundPlayback} onCheckedChange={(v) => s.set("backgroundPlayback", v)} />
        </Row>
        <Row label="Picture-in-picture">
          <Switch checked={s.pipEnabled} onCheckedChange={(v) => s.set("pipEnabled", v)} />
        </Row>
        <Row label="Default speed" hint={`${s.defaultSpeed}×`}>
          <div className="w-40">
            <Slider
              min={0.25}
              max={2}
              step={0.25}
              value={[s.defaultSpeed]}
              onValueChange={([v]) => s.set("defaultSpeed", v ?? 1)}
            />
          </div>
        </Row>
        <Row label="Double-tap seek" hint={`${s.doubleTapSeek}s`}>
          <div className="w-40">
            <Slider
              min={5}
              max={30}
              step={5}
              value={[s.doubleTapSeek]}
              onValueChange={([v]) => s.set("doubleTapSeek", v ?? 10)}
            />
          </div>
        </Row>
        <Row label="Decoder">
          <p className="max-w-xs text-right text-sm text-muted">
            {decoderDescription()}
          </p>
        </Row>
        <p className="text-xs text-subtle">{decoderHelp()}</p>
      </Section>

      <Section title="Video">
        <Row label="Default aspect">
          <Segment
            value={s.aspect}
            onChange={(v) => s.set("aspect", v)}
            options={[
              { id: "contain", label: "Fit" },
              { id: "cover", label: "Crop" },
              { id: "fill", label: "Stretch" },
            ]}
          />
        </Row>
      </Section>

      <Section title="Audio">
        <Row label="Equalizer">
          <Switch checked={s.eqEnabled} onCheckedChange={(v) => s.set("eqEnabled", v)} />
        </Row>
        {s.eqEnabled ? (
          <div className="space-y-3">
            {EQ_FREQUENCIES.map((freq, i) => (
              <Row key={freq} label={freq >= 1000 ? `${freq / 1000} kHz` : `${freq} Hz`} hint={`${s.eqBands[i] ?? 0} dB`}>
                <div className="w-40">
                  <Slider
                    min={-12}
                    max={12}
                    step={1}
                    value={[s.eqBands[i] ?? 0]}
                    onValueChange={([v]) => {
                      const next = [...s.eqBands];
                      next[i] = v ?? 0;
                      s.set("eqBands", next);
                    }}
                  />
                </div>
              </Row>
            ))}
          </div>
        ) : (
          <p className="text-xs text-subtle">Turned off so unused Web Audio graphs are not created.</p>
        )}
        <Row label="Bass boost" hint={`${s.bassBoost} dB`}>
          <div className="w-40">
            <Slider min={0} max={12} step={1} value={[s.bassBoost]} onValueChange={([v]) => s.set("bassBoost", v ?? 0)} />
          </div>
        </Row>
        <Row label="Stereo">
          <Switch checked={s.stereo} onCheckedChange={(v) => s.set("stereo", v)} />
        </Row>
        <Row label="Loudness limiter" hint="Gentle compressor, not replay-gain scanning">
          <Switch checked={s.normalize} onCheckedChange={(v) => s.set("normalize", v)} />
        </Row>
        <Button variant="outline" size="sm" onClick={() => s.resetEq()}>
          Reset equalizer
        </Button>
      </Section>

      <Section title="Subtitles">
        <Row label="Enabled">
          <Switch checked={s.subtitleEnabled} onCheckedChange={(v) => s.set("subtitleEnabled", v)} />
        </Row>
        <Row label="Size" hint={`${s.subtitleSize.toFixed(2)} rem`}>
          <div className="w-40">
            <Slider min={0.8} max={2} step={0.05} value={[s.subtitleSize]} onValueChange={([v]) => s.set("subtitleSize", v ?? 1)} />
          </div>
        </Row>
        <Row label="Position from bottom" hint={`${s.subtitlePosition}%`}>
          <div className="w-40">
            <Slider min={4} max={40} step={1} value={[s.subtitlePosition]} onValueChange={([v]) => s.set("subtitlePosition", v ?? 12)} />
          </div>
        </Row>
        <Row label="Delay" hint={`${s.subtitleDelay.toFixed(1)}s`}>
          <div className="w-40">
            <Slider min={-5} max={5} step={0.1} value={[s.subtitleDelay]} onValueChange={([v]) => s.set("subtitleDelay", v ?? 0)} />
          </div>
        </Row>
        <Row label="Colour">
          <input
            type="color"
            value={s.subtitleColor}
            onChange={(e) => s.set("subtitleColor", e.target.value)}
            className="h-10 w-14 cursor-pointer rounded-md bg-transparent"
            aria-label="Subtitle colour"
          />
        </Row>
      </Section>

      <Section title="Library">
        <Row label="Default sort">
          <Segment
            value={s.sort}
            onChange={(v) => s.set("sort", v)}
            options={[
              { id: "date", label: "Added" },
              { id: "name", label: "Name" },
              { id: "duration", label: "Length" },
              { id: "size", label: "Size" },
            ]}
          />
        </Row>
        <Row label="Default view">
          <Segment
            value={s.view}
            onChange={(v) => s.set("view", v)}
            options={[
              { id: "grid", label: "Grid" },
              { id: "list", label: "List" },
            ]}
          />
        </Row>
      </Section>

      <Section title="Browser">
        <div className="grid gap-1.5">
          <Label htmlFor="homepage">Homepage</Label>
          <Input id="homepage" value={s.homepage} onChange={(e) => s.set("homepage", e.target.value)} />
        </div>
        <Row label="Search engine">
          <Segment
            value={s.searchEngine}
            onChange={(v) => s.set("searchEngine", v)}
            options={(Object.keys(SEARCH_ENGINES) as Array<keyof typeof SEARCH_ENGINES>).map((id) => ({
              id,
              label: SEARCH_ENGINES[id].label,
            }))}
          />
        </Row>
        <Row label="Remember history" hint="Stored locally. Never sent to a server.">
          <Switch checked={s.rememberHistory} onCheckedChange={(v) => s.set("rememberHistory", v)} />
        </Row>
        <Button
          variant="outline"
          onClick={() => {
            void clearHistory();
          }}
        >
          Clear browsing data
        </Button>
      </Section>

      <Section title="Downloads">
        <Row label="Concurrent downloads" hint={String(s.concurrentDownloads)}>
          <div className="w-40">
            <Slider
              min={1}
              max={3}
              step={1}
              value={[s.concurrentDownloads]}
              onValueChange={([v]) => s.set("concurrentDownloads", v ?? 1)}
            />
          </div>
        </Row>
        <p className="text-xs text-subtle">
          Files save through the browser download prompt. UPLAY.IND does not write arbitrary paths on
          disk — that would bypass browser security.
        </p>
      </Section>

      <Section title="About">
        <p className="text-sm">
          {APP_NAME} {APP_VERSION}
        </p>
        <p className="text-sm text-muted">
          Playback uses the browser’s media engine. Library metadata, playback position, favourites,
          history, and settings stay in IndexedDB / localStorage on this device. No accounts. No
          analytics. No media uploaded.
        </p>
        <p className="text-sm text-muted">
          Permissions used: file access you grant via the picker. No contacts, SMS, phone, location,
          camera, or microphone.
        </p>
        <p className="text-sm text-muted">
          Open-source libraries: React, TanStack Router, Zustand, Radix UI, Lucide, Sonner. Media
          decoding is provided by the browser, not a bundled codec pack.
        </p>
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="space-y-4">
      <div>
        <h2 className="font-display text-lg font-semibold">{title}</h2>
        <Separator className="mt-2" />
      </div>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

function Row({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <p className="text-sm font-medium">{label}</p>
        {hint ? <p className="text-xs text-subtle">{hint}</p> : null}
      </div>
      {children}
    </div>
  );
}

function Segment<T extends string>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { id: T; label: string }[];
}) {
  return (
    <div className="flex flex-wrap justify-end gap-1 rounded-lg bg-secondary p-1">
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          onClick={() => onChange(o.id)}
          className={cn(
            "h-8 rounded-md px-2.5 text-xs font-medium",
            value === o.id ? "bg-elevated text-fg shadow-[var(--shadow-border)]" : "text-muted",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

