import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import * as Switch from "@radix-ui/react-switch";
import { Field, SelectInput } from "@/components/ui/field";
import { Button } from "@/components/ui/button";
import { useProjects } from "@/components/storyboard/use-projects";
import { STYLES } from "@/lib/storyboard/options";
import { DEFAULT_PREFS, readPrefs, writePrefs } from "@/lib/storyboard/prefs";
import { useStory } from "@/lib/storyboard/store";
import type { Aspect, Prefs } from "@/lib/storyboard/types";
import { SCENE_COUNTS } from "@/lib/storyboard/types";

export const Route = createFileRoute("/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const ready = useProjects();
  const clearAll = useStory((state) => state.clearAll);
  const [prefs, setPrefs] = useState<Prefs>(DEFAULT_PREFS);
  const [confirm, setConfirm] = useState(false);

  useEffect(() => {
    setPrefs(readPrefs());
  }, []);

  function save(next: Prefs) {
    setPrefs(next);
    writePrefs(next);
  }

  return (
    <div className="mx-auto grid max-w-xl gap-4">
      <div>
        <p className="text-xs font-medium tracking-widest text-muted uppercase">Settings</p>
        <h1 className="font-display text-3xl font-medium tracking-tight">Pengaturan baru</h1>
        <p className="mt-2 text-sm text-muted">
          Dipakai saat storyboard baru dibuat. Storyboard yang sudah ada tidak berubah. Data tetap di browser ini.
        </p>
      </div>
      <section className="grid gap-4 rounded-xl border border-line bg-surface p-4">
        <fieldset className="grid gap-2">
          <legend className="text-sm font-medium">Default scenes</legend>
          <div className="flex flex-wrap gap-2">
            {SCENE_COUNTS.map((count) => (
              <button
                key={count}
                type="button"
                onClick={() => save({ ...prefs, sceneCount: count })}
                className={`inline-flex size-11 items-center justify-center rounded-md text-sm font-medium ${
                  prefs.sceneCount === count ? "bg-accent text-accent-fg" : "border border-line bg-bg"
                }`}
              >
                {count}
              </button>
            ))}
          </div>
        </fieldset>
        <Field label="Default photography style">
          <SelectInput value={prefs.style} onChange={(event) => save({ ...prefs, style: event.target.value })}>
            {STYLES.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </SelectInput>
        </Field>
        <Field label="Default aspect ratio">
          <SelectInput
            value={prefs.aspect}
            onChange={(event) => save({ ...prefs, aspect: event.target.value as Aspect })}
          >
            {(["1:1", "4:5", "9:16", "16:9"] as Aspect[]).map((item) => (
              <option key={item}>{item}</option>
            ))}
          </SelectInput>
        </Field>
        <div className="flex min-h-11 items-center justify-between gap-3">
          <span className="text-sm font-medium">Product consistency lock</span>
          <Switch.Root
            checked={prefs.consistencyLock}
            onCheckedChange={(checked) => save({ ...prefs, consistencyLock: checked })}
            className="relative h-7 w-12 rounded-full bg-faint data-[state=checked]:bg-ink"
          >
            <Switch.Thumb className="block size-5 translate-x-1 rounded-full bg-surface transition-transform duration-150 data-[state=checked]:translate-x-6" />
          </Switch.Root>
        </div>
      </section>
      <section className="grid gap-3 rounded-xl border border-line bg-surface p-4">
        <h2 className="font-medium">Hapus semua storyboard</h2>
        <p className="text-sm text-muted">Foto referensi dan gambar scene di browser ini ikut terhapus.</p>
        <Button
          variant="secondary"
          disabled={!ready}
          onClick={() => {
            if (!confirm) {
              setConfirm(true);
              return;
            }
            clearAll();
            setConfirm(false);
          }}
        >
          {confirm ? "Ya, hapus semua" : "Hapus semua"}
        </Button>
      </section>
    </div>
  );
}
