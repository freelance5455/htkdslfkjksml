import { createFileRoute } from "@tanstack/react-router";
import { useSalon } from "@/lib/cutegirls/store";
import { FeedView } from "@/components/feed-view";
import { Shell } from "@/components/shell";
import { primaryBtn } from "@/components/bits";
import { useMeId } from "@/components/use-me-id";

export const Route = createFileRoute("/subliminals")({ component: SubliminalsPage });

function SubliminalsPage() {
  return (
    <Shell>
      <Shelf />
    </Shell>
  );
}

function Shelf() {
  const meId = useMeId();
  const openCompose = useSalon((s) => s.openCompose);
  if (!meId) return null;
  return (
    <div className="mx-auto w-full max-w-xl space-y-4">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-xs tracking-widest text-rose">رف هادئ</p>
          <h1 className="font-display text-4xl">سيبلمنال</h1>
        </div>
        <button type="button" className={primaryBtn} onClick={() => openCompose({ kind: "subliminal" })}>
          إضافة
        </button>
      </header>
      <p className="text-sm leading-6 text-mute">عنوان، وصف، ورابط إن أحببت. الكل يراه.</p>
      <FeedView
        meId={meId}
        query={{ surface: "subliminals" }}
        variant="subliminal"
        emptyTitle="الرف فارغ"
        emptyBody="أضف سيبلمنال بوصف واضح. يمكن ربط فيديو يوتيوب."
      />
    </div>
  );
}
