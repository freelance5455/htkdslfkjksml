import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageIntro } from "@/components/page";
import { copyText } from "@/lib/utils";

export const Route = createFileRoute("/report")({
  head: () => ({ meta: [{ title: "الإبلاغ عن خطأ — لأنه الله" }] }),
  component: ReportPage,
});

function ReportPage() {
  const [kind, setKind] = useState("خطأ علمي");
  const [page, setPage] = useState("");
  const [detail, setDetail] = useState("");
  const [note, setNote] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    const text = `بلاغ عن محتوى منصة لأنه الله\nالنوع: ${kind}\nالصفحة: ${page || "غير محددة"}\nالوصف:\n${detail}\n\nهذا النص لم يُرسل إلى خادم. أرسله أنت إلى الجهة التي تراجع المحتوى إن أردت.`;
    await copyText(text);
    setNote("نُسخ البلاغ. لم يُرسل إلى أي خادم ولم يُحفظ.");
    setDetail("");
  }

  return (
    <main>
      <PageIntro
        kicker="المراجعة البشرية"
        title="الإبلاغ عن خطأ"
        lede="إن رأيت خطأ في آية أو حديث أو معنى أو رابط، صِغ بلاغًا من غير بيانات شخصية. النسخ محلي فقط."
      />
      <form onSubmit={submit} className="mx-auto grid max-w-xl gap-4 px-4 py-8">
        <label className="grid gap-2 text-sm">
          نوع الملاحظة
          <select value={kind} onChange={(event) => setKind(event.target.value)} className="rounded-full border border-line bg-surface px-4 py-3">
            <option>خطأ علمي</option>
            <option>خطأ في رابط</option>
            <option>اقتراح صياغة</option>
          </select>
        </label>
        <label className="grid gap-2 text-sm">
          الصفحة
          <input value={page} onChange={(event) => setPage(event.target.value)} className="rounded-full border border-line bg-surface px-4 py-3" placeholder="مثال: اسم الرحمن" />
        </label>
        <label className="grid gap-2 text-sm">
          الوصف
          <textarea required value={detail} onChange={(event) => setDetail(event.target.value)} rows={6} className="rounded-card border border-line bg-surface px-4 py-3" placeholder="صف الخطأ من غير اسمك أو اسم طفل أو رقم هاتف" />
        </label>
        <button type="submit" className="w-fit rounded-full bg-primary px-5 py-3 text-primary-fg">نسخ البلاغ</button>
        {note ? <p role="status" className="text-sm text-olive">{note}</p> : null}
        <p className="text-sm leading-7 text-muted">
          للتواصل مع الجهة المنظمة للحملة استخدم قنواتها المعلنة، لا هذا النموذج: موقع الوزارة وحسابها الرسمي مذكوران في صفحة الحملة.
        </p>
      </form>
    </main>
  );
}
