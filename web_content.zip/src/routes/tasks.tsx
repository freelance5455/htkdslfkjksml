import { createFileRoute } from "@tanstack/react-router";
import { TasksView } from "@/components/planner/views/tasks";

export const Route = createFileRoute("/tasks")({
  component: TasksView,
});
