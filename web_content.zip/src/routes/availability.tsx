import { createFileRoute } from "@tanstack/react-router";
import { AvailabilityPage } from "@/components/ministry/desk-pages";
import { AppShell } from "@/components/ministry/shell";

export const Route = createFileRoute("/availability")({
  component: function AvailabilityRoute() {
    return (
      <AppShell>
        <AvailabilityPage />
      </AppShell>
    );
  },
});
