import { createFileRoute } from "@tanstack/react-router";
import { Bookmark, Heart } from "lucide-react";
import { useState } from "react";
import { BackButton } from "@/components/back-button";
import { AppShell, TopBar } from "@/components/layout/app-shell";
import { TextLink } from "@/components/text-link";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/favorites/")({ component: FavoritesPage });

function FavoritesPage() {
  const [tab, setTab] = useState<"fav" | "marks">("fav");
  const favorites = useAppStore((s) => s.favorites);
  const bookmarks = useAppStore((s) => s.bookmarks);
  const removeBookmark = useAppStore((s) => s.removeBookmark);
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);

  return (
    <AppShell>
      <TopBar title="المفضلة والعلامات" back={<BackButton href="/" />} />
      <div className="mx-4 mt-3 grid grid-cols-2 gap-1 rounded-2xl bg-surface p-1">
        <button
          type="button"
          className={`h-10 rounded-xl text-sm ${tab === "fav" ? "bg-card" : "text-muted-foreground"}`}
          onClick={() => setTab("fav")}
        >
          المفضلة
        </button>
        <button
          type="button"
          className={`h-10 rounded-xl text-sm ${tab === "marks" ? "bg-card" : "text-muted-foreground"}`}
          onClick={() => setTab("marks")}
        >
          العلامات
        </button>
      </div>

      {tab === "fav" ? (
        favorites.length === 0 ? (
          <Empty icon={Heart} text="لم تحفظ شيئًا بعد. أضف آية أو ذكرًا أو صفحة من متن." />
        ) : (
          <ul className="space-y-2 px-4 py-4">
            {favorites.map((f) => (
              <li key={f.id} className="rounded-2xl bg-card p-4 shadow-[var(--shadow-border)]">
                <TextLink href={f.href} className="block">
                  <p className="text-xs text-sage">{labelKind(f.kind)}</p>
                  <p className="mt-1 font-medium">{f.title}</p>
                  <p className="mt-2 line-clamp-3 text-sm leading-7 text-muted-foreground">{f.text}</p>
                </TextLink>
                <button
                  type="button"
                  className="mt-2 text-xs text-muted-foreground"
                  onClick={() => toggleFavorite(f)}
                >
                  إزالة
                </button>
              </li>
            ))}
          </ul>
        )
      ) : bookmarks.length === 0 ? (
        <Empty icon={Bookmark} text="ضع علامة على موضع قراءة لتعود إليه لاحقًا." />
      ) : (
        <ul className="space-y-2 px-4 py-4">
          {bookmarks.map((b) => (
            <li key={b.id} className="flex items-center gap-2 rounded-2xl bg-card px-4 py-3 shadow-[var(--shadow-border)]">
              <TextLink href={b.href} className="flex-1">
                {b.label}
              </TextLink>
              <button type="button" className="text-xs text-muted-foreground" onClick={() => removeBookmark(b.id)}>
                حذف
              </button>
            </li>
          ))}
        </ul>
      )}
    </AppShell>
  );
}

function labelKind(k: string) {
  if (k === "ayah") return "آية";
  if (k === "dhikr") return "ذكر";
  if (k === "dua") return "دعاء";
  if (k === "hadith") return "حديث";
  return "متن";
}

function Empty({ icon: Icon, text }: { icon: typeof Heart; text: string }) {
  return (
    <div className="px-8 py-16 text-center text-sm text-muted-foreground">
      <Icon className="mx-auto mb-3 size-8 opacity-40" />
      {text}
    </div>
  );
}
