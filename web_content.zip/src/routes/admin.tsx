import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts";
import { AppFrame, PageTitle, ScreenSkeleton } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { useEdu } from "@/components/edu-provider";
import { t } from "@/content/copy";
import { claimAdmin, getAdminDesk, setRole, type StudentRow } from "@/lib/edu.functions";
import { fill, useLocale } from "@/lib/locale";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/admin")({ component: AdminPage });

type Desk =
  | { ok: false; adminCount: number }
  | {
      ok: true;
      adminCount: number;
      stats: { students: number; lessons: number; average: number | null };
      bySubject: { id: string; label: string; n: number }[];
      students: StudentRow[];
    };

function AdminPage() {
  const { user, isPending } = useCurrentUserState();
  const { profile, loading, refresh } = useEdu();
  const locale = useLocale((state) => state.locale);
  const [desk, setDesk] = useState<Desk | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const next = await getAdminDesk();
    setDesk(next);
  }, []);

  useEffect(() => {
    if (!profile) return;
    load().catch(() => setDesk(null));
  }, [profile, load]);

  if (isPending || (user && loading)) return <ScreenSkeleton label={t(locale, "loading")} />;
  if (!user) return <RedirectToSignIn />;
  if (!profile) return <ScreenSkeleton label={t(locale, "loading")} />;

  async function claim() {
    setBusy(true);
    setNote(null);
    try {
      const result = await claimAdmin();
      if (!result.ok && result.reason === "taken") setNote(t(locale, "claimTaken"));
      if (!result.ok && result.reason === "need-profile") setNote(t(locale, "claimNeedProfile"));
      await refresh();
      await load();
    } finally {
      setBusy(false);
    }
  }

  async function changeRole(userId: string, role: "student" | "admin") {
    setBusy(true);
    try {
      await setRole({ data: { userId, role } });
      await load();
    } finally {
      setBusy(false);
    }
  }

  const allowed = desk?.ok === true;

  return (
    <AppFrame>
      <PageTitle title={t(locale, "adminTitle")} lede={t(locale, "adminOnly")} />
      {!desk ? <p className="text-sm text-muted">{t(locale, "loading")}</p> : null}
      {desk && !allowed ? (
        <section className="rounded-2xl border border-line bg-card p-4">
          <h2 className="text-lg font-semibold">{t(locale, "claimTitle")}</h2>
          <p className="mt-2 text-sm text-muted">{desk.adminCount === 0 ? t(locale, "claimBody") : t(locale, "claimTaken")}</p>
          {desk.adminCount === 0 ? (
            <Button className="mt-4" disabled={busy} onClick={() => void claim()}>
              {busy ? t(locale, "working") : t(locale, "claimButton")}
            </Button>
          ) : null}
          {note ? <p className="mt-3 text-sm font-semibold text-danger">{note}</p> : null}
        </section>
      ) : null}
      {desk && allowed ? (
        <div className="space-y-6">
          <div className="grid gap-3 sm:grid-cols-3">
            <Stat label={t(locale, "students")} value={String(desk.stats.students)} />
            <Stat label={t(locale, "lessonsDoneStat")} value={String(desk.stats.lessons)} />
            <Stat
              label={t(locale, "avgExam")}
              value={desk.stats.average === null ? t(locale, "noneYet") : `${desk.stats.average}%`}
            />
          </div>
          <section className="rounded-2xl border border-line bg-card p-4">
            <h2 className="mb-3 text-sm font-semibold text-muted">{t(locale, "lessonsDoneStat")}</h2>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={desk.bySubject}>
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} interval={0} />
                  <YAxis allowDecimals={false} width={28} />
                  <Bar dataKey="n" fill="var(--color-teal)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </section>
          <section>
            <h2 className="mb-3 text-sm font-semibold text-muted">{t(locale, "students")}</h2>
            {desk.students.length === 0 ? <p className="text-sm text-muted">{t(locale, "noStudents")}</p> : null}
            <ul className="space-y-3">
              {desk.students.map((student) => (
                <li key={student.userId} className="rounded-2xl border border-line bg-card p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold">
                        {student.fullName}{" "}
                        {student.userId === profile.userId ? <span className="text-sm text-muted">({t(locale, "you")})</span> : null}
                      </p>
                      <p className="text-sm text-muted">{student.email}</p>
                      <p className="mt-1 text-sm tabular-nums text-muted">
                        {fill(t(locale, "gradeLabel"), { grade: student.grade })} · {student.role === "admin" ? t(locale, "roleAdmin") : t(locale, "roleStudent")} · {t(locale, "lessonsFinished")} {student.lessons}
                      </p>
                    </div>
                  </div>
                  {student.userId !== profile.userId ? (
                    <Button
                      className="mt-3"
                      variant="secondary"
                      disabled={busy}
                      onClick={() =>
                        void changeRole(student.userId, student.role === "admin" ? "student" : "admin")
                      }
                    >
                      {student.role === "admin" ? t(locale, "makeStudent") : t(locale, "promote")}
                    </Button>
                  ) : null}
                </li>
              ))}
            </ul>
          </section>
        </div>
      ) : null}
      <section className="mt-8 rounded-2xl border border-line bg-paper-2 p-4">
        <h2 className="text-sm font-semibold">{t(locale, "prototypeTitle")}</h2>
        <p className="mt-2 text-sm text-muted">{t(locale, "prototypeBody")}</p>
      </section>
    </AppFrame>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <article className="rounded-2xl border border-line bg-card p-4">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 text-2xl font-semibold tabular-nums">{value}</p>
    </article>
  );
}
