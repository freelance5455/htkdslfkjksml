import { createFileRoute } from "@tanstack/react-router";
import { ReaderView } from "@/components/reader-view";

export const Route = createFileRoute("/read/$bookId")({
  component: ReadPage,
});

function ReadPage() {
  const { bookId } = Route.useParams();
  return <ReaderView bookId={bookId} />;
}
