import { createFileRoute } from "@tanstack/react-router";
import { MembersPage } from "@/components/ministry/members-page";
import { AppShell } from "@/components/ministry/shell";

export const Route = createFileRoute("/members")({
  component: function MembersRoute() {
    return (
      <AppShell>
        <MembersPage />
      </AppShell>
    );
  },
});
