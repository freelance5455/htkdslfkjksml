import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Btn, Card, Page, fieldClass } from "@/components/ui";
import { playAdhan, stopAdhan } from "@/lib/alerts";
import { idbDel, idbSet } from "@/lib/idb";
import { SALAH } from "@/lib/prayer";
import { usePrefs } from "@/lib/prefs";

export const Route = createFileRoute("/adhan")({ component: AdhanPage });

const SLOTS = [{ key: "all", name: "لكل الصلوات إن لم يُختر غيرها" }, ...SALAH];

function AdhanPage() {
  const prefs = usePrefs();
  const [msg, setMsg] = useState("");
  const [preview, setPreview] = useState("fajr");

  return (
    <Page
      title="الأذان"
      subtitle="أذان واحد مضمّن ومرخّص، ويمكنك استيراد تسجيلاتك لكل صلاة. لا نضع أصواتًا بلا مصدر."
    >
      <Card>
        <p className="font-bold">الأذان المضمّن</p>
        <p className="mt-1 text-sm leading-relaxed text-muted">
          تسجيل «The Adhan» لعقيل عزيز (Aaqib Azeez)، نشره على ويكيميديا كومنز باسم Atcovi برخصة المشاع الإبداعي CC BY-SA 4.0. يُنسب إليه، ويُسمح بمشاركته مع ذكر الرخصة. ليس أذان فجر خاصًا بجملة «الصلاة خير من النوم» إلا إن كان ذلك في التسجيل نفسه؛ للفجر يمكنك استيراد تسجيل تعرفه.
        </p>
        <a className="mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-emerald" href="https://commons.wikimedia.org/wiki/File:The_Adhan_-_Muslim_Call_to_Prayer_-_Aaqib_Azeez.mp3" target="_blank" rel="noreferrer">
          صفحة المصدر والترخيص
        </a>
      </Card>
      <Card className="mt-3">
        <p className="font-bold">معاينة</p>
        <div className="mt-2 flex flex-wrap gap-2">
          <select className={fieldClass + " max-w-xs"} value={preview} onChange={(e) => setPreview(e.target.value)}>
            {SALAH.map((s) => (
              <option key={s.key} value={s.key}>
                {s.name}
              </option>
            ))}
          </select>
          <Btn onClick={() => void playAdhan(preview).catch(() => setMsg("اسمح بالصوت من المتصفح ثم أعد المحاولة."))}>تشغيل</Btn>
          <Btn tone="ghost" onClick={() => stopAdhan()}>
            إيقاف
          </Btn>
        </div>
        <label className="mt-3 block text-sm">
          مستوى صوت الأذان
          <input
            className="mt-1 w-full"
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={prefs.adhanVolume}
            onChange={(e) => prefs.patch({ adhanVolume: Number(e.target.value) })}
          />
        </label>
        <div className="mt-3 flex flex-wrap gap-2">
          <Btn
            tone="ghost"
            onClick={() => {
              prefs.patch({ mutedUntil: Date.now() + 60 * 60 * 1000 });
              setMsg("كُتم الأذان لمدة ساعة.");
            }}
          >
            كتم ساعة
          </Btn>
          <Btn tone="ghost" onClick={() => prefs.patch({ mutedUntil: null })}>
            إلغاء الكتم
          </Btn>
        </div>
        {prefs.mutedUntil && prefs.mutedUntil > Date.now() && (
          <p className="mt-2 text-sm">الأذان مكتوم حتى {new Date(prefs.mutedUntil).toLocaleTimeString("ar")}</p>
        )}
      </Card>
      <Card className="mt-3">
        <p className="font-bold">استيراد أذان من جهازك</p>
        <p className="mt-1 text-sm text-muted">اختر ملف MP3 تملك حق استخدامه. يُحفظ داخل المتصفح ولا يُرفع إلى خادم.</p>
        <ul className="mt-3 space-y-3">
          {SLOTS.map((s) => (
            <li key={s.key} className="text-sm">
              <span className="mb-1 block font-semibold">{s.name}</span>
              <input
                className="block w-full text-sm"
                type="file"
                accept="audio/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  void file.arrayBuffer().then((buf) => idbSet(`adhan-file-${s.key}`, buf)).then(() => setMsg(`حُفظ أذان: ${s.name}`));
                }}
              />
              <button type="button" className="mt-1 text-xs text-danger" onClick={() => void idbDel(`adhan-file-${s.key}`).then(() => setMsg("حُذف التسجيل المستورد"))}>
                حذف التسجيل المستورد
              </button>
            </li>
          ))}
        </ul>
      </Card>
      <Card className="mt-3">
        <p className="font-bold">الإقامة</p>
        <p className="mt-1 text-sm text-muted">لا يوجد تسجيل إقامة مرخّص مضمّن. يمكن تذكير نصي تقريبي بعد الأذان بعدد دقائق تختاره، وليس أذان إقامة.</p>
        <label className="mt-2 flex min-h-11 items-center gap-2 text-sm">
          <input type="checkbox" checked={prefs.iqamaNotify} onChange={(e) => prefs.patch({ iqamaNotify: e.target.checked })} />
          تذكير نصي للإقامة
        </label>
        <label className="text-sm">
          بعد الأذان بدقائق
          <input className={fieldClass} type="number" min={5} max={40} value={prefs.iqamaDelay} onChange={(e) => prefs.patch({ iqamaDelay: Number(e.target.value) || 15 })} />
        </label>
      </Card>
      {msg && <p className="mt-3 text-sm">{msg}</p>}
    </Page>
  );
}
