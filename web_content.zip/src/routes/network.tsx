import { createFileRoute } from "@tanstack/react-router";
import { Wifi, WifiOff } from "lucide-react";
import { useEffect, useState } from "react";
import { AppShell, ScreenBody } from "@/components/vishal/app-shell";
import { IconBadge, InfoRow, Panel, ScreenHeader } from "@/components/vishal/screen-header";
import { subscribeNetwork, type NetworkReading } from "@/lib/web-device";

export const Route = createFileRoute("/network")({ component: NetworkPage });

function NetworkPage() {
  const [network, setNetwork] = useState<NetworkReading | null>(null);

  useEffect(() => subscribeNetwork(setNetwork), []);

  const online = network?.online ?? false;

  return (
    <AppShell>
      <ScreenBody>
        <ScreenHeader
          title="Network Info"
          subtitle="Connection type only. No personal data is collected."
        />
        <Panel>
          <IconBadge className={online ? "bg-primary/15 text-primary" : "bg-danger/15 text-danger"}>
            {online ? <Wifi className="size-5" /> : <WifiOff className="size-5" />}
          </IconBadge>
          <p className="mt-4 text-4xl font-bold tracking-tight text-fg">
            {network ? (online ? "Connected" : "Offline") : "…"}
          </p>
          <p className={`text-sm ${online ? "text-primary" : "text-muted"}`}>
            {network?.typeLabel ?? "Reading…"}
          </p>
        </Panel>
        <div className="mt-3.5 flex flex-col gap-2.5">
          <InfoRow label="Status" value={network ? (online ? "Online" : "Offline") : "..."} />
          <InfoRow label="Connection type" value={network?.typeLabel ?? "..."} />
          <InfoRow label="Details" value={network?.detail ?? "..."} />
          <InfoRow label="Downlink" value={network?.downlink ?? "..."} />
        </div>
      </ScreenBody>
    </AppShell>
  );
}
