import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { RoadSign } from "@/components/road-sign";
import { ItText } from "@/components/it-text";
import { CATS, SIGNS, type SignCat, type SignInfo } from "@/data/signs";
import { useStudy } from "@/lib/study-store";

export const Route = createFileRoute("/segnali")({ component: Segnali });

function Segnali() {
  const [cat, setCat] = useState<SignCat | "all">("all");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<SignInfo | null>(null);
  const learned = useStudy((s) => s.learned);
  const toggle = useStudy((s) => s.toggleLearned);

  const list = useMemo(() => {
    const query = q.trim().toLowerCase();
    return SIGNS.filter((s) => (cat === "all" ? true : s.cat === cat)).filter((s) => {
      if (!query) return true;
      return (
        s.nameIt.toLowerCase().includes(query) ||
        s.nameAr.includes(query) ||
        s.explainAr.includes(query)
      );
    });
  }, [cat, q]);

  return (
    <div className="space-y-4">
      <header>
        <p className="text-sm text-primary">Segnaletica</p>
        <h1 className="text-3xl font-semibold">الإشارات</h1>
        <p className="mt-2 text-muted">اسم إيطالي، اسم عربي، وشرح للاثنين. الرسم تعليمي بشكل الإشارة الرسمي.</p>
      </header>
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="ابحث: توقف، sorpasso، أولوية…"
        className="min-h-11 w-full rounded-xl border border-line bg-surface px-3 outline-none focus:border-primary"
      />
      <div className="flex gap-2 overflow-x-auto pb-1">
        <Chip on={cat === "all"} onClick={() => setCat("all")}>
          الكل
        </Chip>
        {CATS.map((c) => (
          <Chip key={c.id} on={cat === c.id} onClick={() => setCat(c.id)}>
            {c.ar}
          </Chip>
        ))}
      </div>
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {list.map((s) => (
          <li key={s.id}>
            <button
              type="button"
              onClick={() => setOpen(s)}
              className="h-full w-full rounded-2xl border border-line bg-surface p-3 text-right"
            >
              <RoadSign id={s.id} className="mx-auto h-24 w-24" />
              <span dir="ltr" lang="it" className="mt-2 block text-left text-sm font-semibold">
                {s.nameIt}
              </span>
              <span className="mt-1 block text-sm text-muted">{s.nameAr}</span>
            </button>
          </li>
        ))}
      </ul>
      {list.length === 0 ? <p className="text-muted">لا توجد إشارة بهذا البحث.</p> : null}
      {open ? (
        <div
          className="fixed inset-0 z-40 flex items-end justify-center bg-ink/40 md:items-center"
          role="presentation"
          onClick={() => setOpen(null)}
        >
          <div
            className="max-h-screen w-full overflow-y-auto rounded-t-2xl bg-surface p-4 md:max-w-lg md:rounded-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <RoadSign id={open.id} className="mx-auto h-40 w-40" />
            <ItText text={open.nameIt} className="mt-3 text-2xl font-semibold" />
            <h2 className="mt-1 text-xl font-semibold">{open.nameAr}</h2>
            <div className="mt-4 space-y-2">
              <ItText text={open.explainIt} />
              <p className="rounded-xl bg-soft px-3 py-3 leading-relaxed">{open.explainAr}</p>
            </div>
            <div className="mt-4 flex gap-2">
              <button
                type="button"
                className="min-h-11 rounded-full bg-primary px-4 text-primary-fg"
                onClick={() => toggle(open.id)}
              >
                {learned.includes(open.id) ? "محفوظة في مراجعتي" : "علّمها كمُراجعة"}
              </button>
              <button type="button" className="min-h-11 rounded-full border border-line px-4" onClick={() => setOpen(null)}>
                إغلاق
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Chip({ children, on, onClick }: { children: string; on: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`min-h-11 shrink-0 rounded-full px-3 text-sm ${on ? "bg-primary text-primary-fg" : "border border-line bg-surface"}`}
    >
      {children}
    </button>
  );
}
