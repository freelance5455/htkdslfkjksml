import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Card, Page, fieldClass } from "@/components/ui";
import { SUNAN, SUNNAH_CATS } from "@/data/sunnah";
import { dayKey, includesArabic } from "@/lib/arabic";
import { usePrefs } from "@/lib/prefs";

export const Route = createFileRoute("/sunnah")({ component: SunnahPage });

function SunnahPage() {
  const [cat, setCat] = useState("الكل");
  const [q, setQ] = useState("");
  const [grade, setGrade] = useState("الكل");
  const prefs = usePrefs();
  const today = dayKey();
  const grades = ["الكل", ...Array.from(new Set(SUNAN.map((s) => s.grade)))];
  const list = useMemo(
    () =>
      SUNAN.filter((s) => (cat === "الكل" || s.cat === cat) && (grade === "الكل" || s.grade === grade) && (!q || includesArabic(`${s.title} ${s.explain} ${s.evidence}`, q))),
    [cat, q, grade],
  );
  return (
    <Page title="السنن النبوية" subtitle={`مجموعة مختارة موثّقة: ${SUNAN.length} سنة. ليست موسوعة بعدد ستة آلاف، ولم نختلق سننًا لإكمال العدد.`}>
      <input className={fieldClass} placeholder="بحث" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="mt-3 flex gap-2 overflow-x-auto pb-2">
        {["الكل", ...SUNNAH_CATS].map((c) => (
          <button key={c} type="button" className={`shrink-0 min-h-11 rounded-full px-3 text-xs ${c === cat ? "bg-btn text-btn-fg" : "border border-line"}`} onClick={() => setCat(c)}>
            {c}
          </button>
        ))}
      </div>
      <select className={fieldClass + " mb-3"} value={grade} onChange={(e) => setGrade(e.target.value)}>
        {grades.map((g) => (
          <option key={g}>{g}</option>
        ))}
      </select>
      <ul className="space-y-3">
        {list.map((s) => {
          const applied = prefs.sunnahLog[s.id] === today;
          return (
            <li key={s.id}>
              <Card>
                <p className="text-xs text-gold">{s.cat}</p>
                <h2 className="font-bold">{s.title}</h2>
                <p className="mt-1 text-sm">{s.explain}</p>
                <p className="mt-2 text-sm"><span className="font-semibold">التطبيق: </span>{s.how}</p>
                <p className="mt-2 text-sm leading-relaxed">«{s.evidence}»</p>
                <p className="mt-1 text-xs text-muted">{s.source} · {s.grade}</p>
                <p className="mt-1 text-sm">{s.benefits}</p>
                <div className="mt-3 flex gap-2">
                  <button type="button" className="min-h-11 rounded-xl bg-btn px-3 text-sm text-btn-fg" onClick={() => prefs.toggleSunnah(s.id, today)}>
                    {applied ? "طُبقت اليوم" : "تم التطبيق"}
                  </button>
                  <button type="button" className="min-h-11 rounded-xl border border-line px-3 text-sm" onClick={() => prefs.toggleFav({ id: `sunnah-${s.id}`, kind: "sunnah", title: s.title, text: s.evidence })}>
                    {prefs.favorites.some((f) => f.id === `sunnah-${s.id}`) ? "محفوظة" : "مفضلة"}
                  </button>
                </div>
              </Card>
            </li>
          );
        })}
      </ul>
    </Page>
  );
}
