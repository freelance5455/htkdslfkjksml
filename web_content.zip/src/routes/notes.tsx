import { createFileRoute } from "@tanstack/react-router";
import { NotesView } from "@/components/planner/views/notes";

export const Route = createFileRoute("/notes")({
  component: NotesView,
});
