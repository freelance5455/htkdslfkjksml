import { Link, createFileRoute } from "@tanstack/react-router";
import { format } from "date-fns";
import { PageHeader } from "@/components/page-header";
import { Card } from "@/components/ui/card";
import {
  PROJECT_DAYS,
  allProjectDates,
  getDayStatus,
  parseDateKey,
  projectDayNumber,
  toDateKey,
} from "@/lib/dates";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/calendario")({ component: CalendarPage });

const DOW = ["S", "T", "Q", "Q", "S", "S", "D"];

function CalendarPage() {
  const logs = useAppStore((s) => s.logs);
  const settings = useAppStore((s) => s.settings);
  const dates = allProjectDates();
  const today = toDateKey(new Date());
  const complete = dates.filter(
    (d) => getDayStatus(logs[d], settings) === "complete",
  ).length;
  const partial = dates.filter(
    (d) => getDayStatus(logs[d], settings) === "partial",
  ).length;

  return (
    <div className="animate-in fade-in duration-300">
      <PageHeader
        kicker="101 dias"
        title="Calendário"
        subtitle={`${complete} completos · ${partial} parciais · ${PROJECT_DAYS - complete - partial} em aberto`}
      />
      <div className="mb-4 flex flex-wrap gap-4 text-xs text-muted-foreground">
        <Legend swatch="bg-primary" label="Dia completo" />
        <Legend swatch="bg-primary/35" label="Parcial" />
        <Legend swatch="bg-muted" label="Não registrado" />
      </div>
      <Card className="p-4">
        <div className="mb-2 grid grid-cols-7 gap-1 text-center text-[10px] tracking-wide text-muted-foreground uppercase">
          {DOW.map((d, i) => (
            <span key={`${d}-${i}`}>{d}</span>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1.5">
          {offsetBlanks(dates[0]!).map((_, i) => (
            <span key={`b-${i}`} />
          ))}
          {dates.map((d) => {
            const status = getDayStatus(logs[d], settings);
            const n = projectDayNumber(parseDateKey(d));
            const isToday = d === today;
            return (
              <Link
                key={d}
                to="/dia/$date"
                params={{ date: d }}
                title={`${format(parseDateKey(d), "dd/MM")} · dia ${n}`}
                className={cn(
                  "flex aspect-square flex-col items-center justify-center rounded-lg text-[11px] font-medium tabular-nums transition-colors",
                  status === "complete" && "bg-primary text-primary-foreground",
                  status === "partial" && "bg-primary/30 text-foreground",
                  status === "empty" && "bg-muted text-muted-foreground",
                  isToday && "ring-2 ring-primary ring-offset-2 ring-offset-background",
                )}
              >
                {n}
              </Link>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

function offsetBlanks(first: string) {
  const dow = parseDateKey(first).getDay();
  const mondayIndex = (dow + 6) % 7;
  return Array.from({ length: mondayIndex });
}

function Legend({ swatch, label }: { swatch: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span className={cn("size-2.5 rounded-sm", swatch)} />
      {label}
    </span>
  );
}
