import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Card, Page, fieldClass } from "@/components/ui";
import { ADHKAR, ADHKAR_CATS, type Dhikr } from "@/data/adhkar";
import { dayKey } from "@/lib/arabic";
import { usePrefs } from "@/lib/prefs";
import { loadQuran, type Quran } from "@/lib/quran";

export const Route = createFileRoute("/adhkar")({ component: AdhkarPage });

function AdhkarPage() {
  const [cat, setCat] = useState(ADHKAR_CATS[0]);
  const [q, setQuery] = useState("");
  const [quran, setQuran] = useState<Quran | null>(null);
  const prefs = usePrefs();
  const today = dayKey();
  useEffect(() => {
    void loadQuran().then(setQuran);
  }, []);
  const list = useMemo(
    () => ADHKAR.filter((d) => d.cat === cat).filter((d) => !q || `${d.title} ${d.text || ""}`.includes(q)),
    [cat, q],
  );
  return (
    <Page title="الأذكار والأدعية" subtitle="نصوص مختارة من القرآن والصحيحين والسنن. لا يوجد تسجيل صوتي للأذكار هنا حتى لا نُشغّل صوتًا غير موثّق.">
      <input className={fieldClass} placeholder="بحث" value={q} onChange={(e) => setQuery(e.target.value)} />
      <div className="mt-3 flex gap-2 overflow-x-auto pb-2">
        {ADHKAR_CATS.map((c) => (
          <button key={c} type="button" onClick={() => setCat(c)} className={`shrink-0 min-h-11 rounded-full px-3 text-xs font-semibold ${c === cat ? "bg-btn text-btn-fg" : "border border-line bg-card"}`}>
            {c}
          </button>
        ))}
      </div>
      <ul className="space-y-3">
        {list.map((d) => (
          <Item key={d.id} d={d} quran={quran} today={today} count={prefs.adhkarLog[d.id]?.date === today ? prefs.adhkarLog[d.id].count : 0} />
        ))}
      </ul>
    </Page>
  );
}

function Item({ d, quran, today, count }: { d: Dhikr; quran: Quran | null; today: string; count: number }) {
  const prefs = usePrefs();
  const ayah = d.ayah && quran ? quran.surahs[d.ayah.s - 1]?.ayahs.find((a) => a.a === d.ayah?.a) : undefined;
  const text = ayah?.t || d.text || "";
  const done = count >= d.count;
  return (
    <li>
      <Card>
        <div className="flex items-start justify-between gap-2">
          <h2 className="font-bold">{d.title}</h2>
          <button type="button" className="text-sm text-gold" onClick={() => prefs.toggleFav({ id: `dhikr-${d.id}`, kind: "dhikr", title: d.title, text })}>
            {prefs.favorites.some((f) => f.id === `dhikr-${d.id}`) ? "في المفضلة" : "حفظ"}
          </button>
        </div>
        <p className={ayah ? "quran-text mt-2" : "mt-2 text-sm leading-relaxed"} style={ayah ? { ["--quran-scale" as string]: String(prefs.fontScale) } : undefined}>
          {text || "يُعرض نص الآية من المصحف بعد تحميله."}
        </p>
        {d.note && <p className="mt-2 text-xs text-muted">{d.note}</p>}
        <p className="mt-2 text-xs text-muted">
          {d.source} · {d.grade} · المطلوب {d.count}
        </p>
        <div className="mt-3 flex items-center gap-2">
          <button type="button" className="min-h-11 min-w-11 rounded-xl bg-btn text-lg text-btn-fg" onClick={() => prefs.bumpAdhkar(d.id, today, 1)}>
            +
          </button>
          <button type="button" className="min-h-11 min-w-11 rounded-xl border border-line" onClick={() => prefs.bumpAdhkar(d.id, today, -1)}>
            -
          </button>
          <span className="text-sm">
            {count} / {d.count} {done ? "· اكتمل اليوم" : ""}
          </span>
        </div>
      </Card>
    </li>
  );
}
