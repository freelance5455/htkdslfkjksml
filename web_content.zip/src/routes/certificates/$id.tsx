"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { CertificateDoc } from "@/components/certificate-doc";
import { getStudent } from "@/lib/bac/server";

export const Route = createFileRoute("/certificates/$id")({
  loader: ({ params }) => getStudent({ data: { id: Number(params.id) } }),
  component: CertificatePage,
});

function CertificatePage() {
  const { id } = Route.useParams();
  const studentId = Number(id);
  const studentQuery = useQuery({
    queryKey: ["student", studentId],
    queryFn: () => getStudent({ data: { id: studentId } }),
    enabled: Number.isFinite(studentId),
    initialData: Route.useLoaderData() ?? undefined,
  });

  const student = studentQuery.data;

  return (
    <div className="min-h-dvh bg-bg px-4 py-6 text-fg">
      <div className="no-print mx-auto mb-6 flex max-w-[210mm] flex-wrap items-center justify-between gap-3">
        <Button asChild variant="ghost">
          <Link
            to="/students/$id"
            params={{ id }}
            className="inline-flex items-center gap-1"
          >
            <ArrowRight className="size-4" />
            ملف المترشح
          </Link>
        </Button>
        <Button onClick={() => window.print()} disabled={!student?.certificateNumber}>
          <Printer className="size-4" />
          طباعة الشهادة
        </Button>
      </div>

      {studentQuery.isLoading ? (
        <Skeleton className="mx-auto h-[280mm] max-w-[210mm] rounded-lg" />
      ) : !student ? (
        <p className="text-center text-sm text-muted">المترشح غير موجود.</p>
      ) : student.decision !== "ناجح" || !student.certificateNumber ? (
        <p className="text-center text-sm text-muted">
          لا توجد شهادة صادرة لهذا الملف. أصدر الشهادة من صفحة المترشح بعد النجاح.
        </p>
      ) : (
        <CertificateDoc student={student} />
      )}
    </div>
  );
}
