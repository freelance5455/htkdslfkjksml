import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/page";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: [{ title: "من نحن — لأنه الله" }] }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <main>
      <PageIntro
        kicker="وضوح المنهج"
        title="من نحن"
        lede="منصة تعليمية عربية مستقلة بُنيت لتعريف الناس بالله من أسمائه وآياته وخلقه، وللتعريف بحملة «لأنه الله» من مصادرها العلنية."
      />
      <article className="mx-auto max-w-3xl space-y-6 px-4 py-8 leading-8">
        <section>
          <h2 className="font-display text-3xl text-primary">ما هذه المنصة وما ليست هي</h2>
          <p className="mt-3">
            ليست الموقع الرسمي لوزارة الأوقاف السورية، ولم يُعلن اعتمادها من الوزارة. الحساب والموقع الرسميان مذكوران في صفحة الحملة للإحالة فقط. لا شعار حكومي يوحي بخلاف ذلك.
          </p>
        </section>
        <section>
          <h2 className="font-display text-3xl text-primary">طبقات المحتوى</h2>
          <ul className="mt-3 list-disc space-y-2 pe-5">
            <li>موثّق: نص قرآني أو حديث مع مصدره ودرجته.</li>
            <li>تعليمي: شرح أو تدبر صاغته المنصة، ومفصول عن النص المنقول.</li>
            <li>بانتظار المراجعة: شروح الأسماء تحتاج نظر متخصص قبل اعتماد رسمي.</li>
            <li>بانتظار ملف خارجي: كتب ومواد أُعلن نوعها ولم يتوفر تسجيل أو ملف مأذون.</li>
          </ul>
        </section>
        <section>
          <h2 className="font-display text-3xl text-primary">لماذا لا توجد لوحة إدارة للزوار؟</h2>
          <p className="mt-3">
            تعديل النص الشرعي لا يُفتح للعموم. لا حسابات ولا قاعدة بيانات عامة في هذه النسخة. التحديث يتم بمراجعة بشرية ثم نشر محتوى جديد. التقدم والمفضلة وخطوة اليوم تبقى على جهازك.
          </p>
        </section>
        <section>
          <h2 className="font-display text-3xl text-primary">الضوابط</h2>
          <p className="mt-3">
            لا تجسيد للذات الإلهية. الزخارف الهندسية والصور الطبيعية للتأمل في المخلوق. لا أحاديث مختلقة، ولا جوائز غير معلنة، ولا جمع لبيانات الأطفال.
          </p>
        </section>
        <section>
          <h2 className="font-display text-3xl text-primary">مصادر يُرجع إليها</h2>
          <ul className="mt-3 list-disc space-y-2 pe-5">
            <li>المصحف برواية حفص، وتُراجع الآيات عبر Quran.com.</li>
            <li>الصحيحان وسنن الترمذي عبر Sunnah.com بالأرقام المذكورة.</li>
            <li>شروح الأسماء: الخطابي، والغزالي مع التنبيه، والسعدي، وابن عثيمين، والبدر.</li>
            <li>أخبار الحملة: حساب الوزارة @SyMOfE، والإخبارية السورية، وتغطيات نسبت إلى سانا.</li>
          </ul>
        </section>
        <p>
          رأيت خطأ؟ <Link to="/report" className="text-primary">أبلغ عنه</Link>. السياسة: <Link to="/privacy" className="text-primary">الخصوصية</Link>.
        </p>
      </article>
    </main>
  );
}
