import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { InternalLink } from "@/components/internal-link";
import { PageIntro } from "@/components/page";
import { searchAll } from "@/data/search";

export const Route = createFileRoute("/guide")({
  head: () => ({ meta: [{ title: "دليل المحتوى — لأنه الله" }] }),
  component: GuidePage,
});

function GuidePage() {
  const [value, setValue] = useState("");
  const [asked, setAsked] = useState("");
  const hits = asked ? searchAll(asked) : [];
  const strong = hits.filter((hit) => hit.score >= 4);

  return (
    <main>
      <PageIntro
        kicker="ليس مفتيًا"
        title="دليل يبحث في محتوى المنصة"
        lede="يجيب بعرض المقاطع الموجودة هنا مع نوعها. إذا لم يكفِ النص قال ذلك. لا يولّد فتوى ولا حكمًا جديدًا."
      />
      <section className="mx-auto max-w-3xl px-4 py-8">
        <form
          className="grid gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            setAsked(value.trim());
          }}
        >
          <label htmlFor="ask" className="text-sm text-olive">سؤالك عن محتوى الموقع</label>
          <textarea id="ask" value={value} onChange={(event) => setValue(event.target.value)} rows={4} className="rounded-card border border-line bg-surface px-4 py-3" placeholder="مثال: ما معنى اسم الرحمن؟" />
          <button type="button" onClick={() => setAsked(value.trim())} className="w-fit rounded-full bg-primary px-5 py-3 text-primary-fg">ابحث في المحتوى</button>
        </form>
        {asked && strong.length === 0 ? (
          <p className="mt-6 rounded-card border border-line bg-soft p-5 leading-8">
            لا أجد في محتوى الموقع ما يكفي للإجابة عن «{asked}». لا أصدر فتوى. ارجع إلى عالم، أو تصفح الأقسام، أو أبلغ عن نقص من صفحة الإبلاغ.
          </p>
        ) : null}
        {strong.length > 0 ? (
          <div className="mt-6 space-y-3">
            <p className="text-sm text-olive">مقاطع من المحتوى المنشور، لا اجتهاد جديد:</p>
            {strong.slice(0, 6).map((hit) => (
              <article key={`${hit.href}${hit.title}`} className="rounded-card border border-line bg-surface p-4">
                <p className="text-xs text-olive">{hit.type}</p>
                <h2 className="mt-1 font-display text-2xl text-primary">{hit.title}</h2>
                <p className="mt-2 leading-8">{hit.excerpt}</p>
                <InternalLink href={hit.href} className="mt-2 inline-block text-sm text-primary">افتح المصدر داخل الموقع</InternalLink>
              </article>
            ))}
          </div>
        ) : null}
      </section>
    </main>
  );
}
