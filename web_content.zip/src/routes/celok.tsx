import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/shell";
import { Field, Modal } from "@/components/ui";
import { formatDay, formatMoney, formatNumber, todayIso, uid } from "@/lib/format";
import { inflationFactor, inflationLossPct } from "@/lib/inflation";
import {
  addMonthsIso,
  goalCurrentHuf,
  goalTargetHuf,
  subscriptionTotals,
  sumViews,
  toHuf,
  viewsOf,
  yearsToTarget,
} from "@/lib/portfolio-math";
import { usePortfolio } from "@/lib/portfolio-context";
import type { Currency, Goal } from "@/lib/types";

export const Route = createFileRoute("/celok")({ component: Page });

function Page() {
  return (
    <Shell>
      <Goals />
    </Shell>
  );
}

function Goals() {
  const { state, saveGoal, deleteGoal, setPlan, setFire, setInflationBase } = usePortfolio();
  const [editing, setEditing] = useState<Goal | null>(null);
  const today = todayIso();
  const totals = sumViews(viewsOf(state));
  const subs = subscriptionTotals(state.subscriptions, state.market.fx);
  const annualSpend = subs.annual + state.fire.extraAnnualHuf;
  const fiHuf = state.fire.swrPct > 0 ? annualSpend / (state.fire.swrPct / 100) : 0;
  const fiUsd = state.market.fx.usdHuf ? fiHuf / state.market.fx.usdHuf : 0;
  const years = yearsToTarget(totals.huf, state.capitalPlan.monthlyHuf, fiHuf, state.fire.realReturnPct);
  const progress = fiHuf > 0 ? Math.min(100, (totals.huf / fiHuf) * 100) : 0;
  const base = state.inflationBase || state.capitalPlan.startDate;

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl">Célok és FIRE</h1>
          <p className="mt-1 max-w-xl text-sm text-muted">
            A cél a választott csoportok mai forintértékéhez méri magát. A reálcél az inflációval együtt nő.
          </p>
        </div>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() =>
            setEditing({
              id: uid(),
              name: "",
              target: 1000000,
              currency: "HUF",
              deadline: "",
              groupIds: [],
              real: false,
              note: "",
            })
          }
        >
          Új cél
        </button>
      </div>

      <ul className="mt-8 divide-y divide-line border-t border-line">
        {state.goals.map((goal) => {
          const current = goalCurrentHuf(goal, state);
          const target = goalTargetHuf(goal, state, today);
          const pct = target > 0 ? (current / target) * 100 : 0;
          const usd = state.market.fx.usdHuf ? current / state.market.fx.usdHuf : 0;
          const targetUsd = state.market.fx.usdHuf ? target / state.market.fx.usdHuf : 0;
          return (
            <li key={goal.id} className="py-5">
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                <h2 className="font-serif text-2xl">{goal.name}</h2>
                <p className="text-sm text-muted tabular-nums">{formatNumber(Math.min(999, pct), 0)}%</p>
              </div>
              <p className="mt-1 text-sm text-muted">
                {goal.groupIds.length
                  ? state.groups
                      .filter((group) => goal.groupIds.includes(group.id))
                      .map((group) => group.name)
                      .join(", ")
                  : "Teljes vagyon"}
                {goal.deadline ? ` · határidő ${formatDay(goal.deadline)}` : ""}
                {goal.real ? " · reálcél" : " · nominális cél"}
              </p>
              <div className="mt-3 h-2 rounded-full bg-line">
                <div className="h-2 rounded-full bg-pine" style={{ width: `${Math.min(100, Math.max(0, pct))}%` }} />
              </div>
              <div className="mt-3 grid gap-2 text-sm tabular-nums sm:grid-cols-2">
                <p>
                  Most {formatMoney(current, "HUF")} · {formatMoney(usd, "USD")}
                </p>
                <p className="sm:text-right">
                  Cél {formatMoney(target, "HUF")} · {formatMoney(targetUsd, "USD")}
                </p>
              </div>
              {goal.note ? <p className="mt-2 text-sm text-muted">{goal.note}</p> : null}
              <div className="mt-2 flex gap-1">
                <button type="button" className="btn btn-quiet" onClick={() => setEditing(goal)}>
                  Módosít
                </button>
                <button type="button" className="btn btn-quiet text-clay" onClick={() => deleteGoal(goal.id)}>
                  Töröl
                </button>
              </div>
            </li>
          );
        })}
        {state.goals.length === 0 ? <li className="py-8 text-sm text-muted">Még nincs cél.</li> : null}
      </ul>

      <section className="mt-12 grid gap-10 lg:grid-cols-2">
        <div>
          <h2 className="font-serif text-2xl">FIRE</h2>
          <p className="mt-1 text-sm text-muted">
            Éves költés = előfizetések ({formatMoney(subs.annual, "HUF")}) + a lent megadott egyéb. A szám {state.fire.swrPct}%
            -os kivétből indul.
          </p>
          <p className="mt-4 font-serif text-4xl tabular-nums leading-tight">{formatMoney(fiHuf, "HUF")}</p>
          <p className="text-sm text-muted tabular-nums">{formatMoney(fiUsd, "USD")} a függetlenséghez</p>
          <div className="mt-3 h-2 rounded-full bg-line">
            <div className="h-2 rounded-full bg-pine" style={{ width: `${progress}%` }} />
          </div>
          <p className="mt-3 text-sm">
            {years == null
              ? "Ezzel a befizetéssel és hozammal a cél nem jön ki."
              : years === 0
                ? "A mai vagyon már eléri a számot."
                : `Kb. ${formatNumber(years, 1)} év, ${formatDay(addMonthsIso(today, years * 12))} körül, ha a havi befizetés és a reálhozam tartja magát.`}
          </p>
          <div className="mt-4 grid gap-3">
            <Field label={`Egyéb éves költés, előfizetésen felül (${formatMoney(state.fire.extraAnnualHuf, "HUF")})`}>
              <input
                className="field tabular-nums"
                inputMode="numeric"
                value={state.fire.extraAnnualHuf}
                onChange={(event) => setFire({ ...state.fire, extraAnnualHuf: Number(event.target.value) || 0 })}
              />
            </Field>
            <Field label={`Kivét, százalék (${state.fire.swrPct})`}>
              <input
                type="range"
                min={2.5}
                max={5}
                step={0.1}
                value={state.fire.swrPct}
                className="w-full accent-pine"
                onChange={(event) => setFire({ ...state.fire, swrPct: Number(event.target.value) })}
              />
            </Field>
            <Field label={`Várt reálhozam, százalék (${state.fire.realReturnPct})`}>
              <input
                type="range"
                min={0}
                max={10}
                step={0.5}
                value={state.fire.realReturnPct}
                className="w-full accent-pine"
                onChange={(event) => setFire({ ...state.fire, realReturnPct: Number(event.target.value) })}
              />
            </Field>
          </div>
        </div>
        <div>
          <h2 className="font-serif text-2xl">Befizetési ütem</h2>
          <p className="mt-1 text-sm text-muted">Ebből rajzolódik a kezdőlap tőkevonalja, és ezt használja a FIRE-év is.</p>
          <div className="mt-4 grid gap-3">
            <Field label="Kezdőnap">
              <input
                className="field"
                type="date"
                value={state.capitalPlan.startDate}
                onChange={(event) => setPlan({ ...state.capitalPlan, startDate: event.target.value })}
              />
            </Field>
            <Field label="Induló összeg, Ft">
              <input
                className="field tabular-nums"
                inputMode="numeric"
                value={state.capitalPlan.initialHuf}
                onChange={(event) => setPlan({ ...state.capitalPlan, initialHuf: Number(event.target.value) || 0 })}
              />
            </Field>
            <Field label="Havi befizetés, Ft">
              <input
                className="field tabular-nums"
                inputMode="numeric"
                value={state.capitalPlan.monthlyHuf}
                onChange={(event) => setPlan({ ...state.capitalPlan, monthlyHuf: Number(event.target.value) || 0 })}
              />
            </Field>
            <Field label="Inflációs bázis">
              <input className="field" type="date" value={base} onChange={(event) => setInflationBase(event.target.value)} />
            </Field>
            <p className="text-sm text-muted">
              {base} óta a fogyasztói árak {formatNumber(inflationLossPct(base, today), 1)}
              %-kal magasabbak (szorzó {formatNumber(inflationFactor(base, today), 2)}). A 2026-os év előzetes.
            </p>
          </div>
        </div>
      </section>
      <GoalDialog goal={editing} onClose={() => setEditing(null)} onSave={(goal) => { saveGoal(goal); setEditing(null); }} />
    </div>
  );
}

function GoalDialog({ goal, onClose, onSave }: { goal: Goal | null; onClose: () => void; onSave: (goal: Goal) => void }) {
  const { state } = usePortfolio();
  const [draft, setDraft] = useState<Goal | null>(goal);
  useEffect(() => setDraft(goal), [goal]);
  if (!draft) {
    return <Modal open={false} title="Cél" onClose={onClose}><div /></Modal>;
  }
  const toggle = (id: string) => {
    const has = draft.groupIds.includes(id);
    setDraft({ ...draft, groupIds: has ? draft.groupIds.filter((item) => item !== id) : [...draft.groupIds, id] });
  };
  return (
    <Modal open={Boolean(goal)} title="Megtakarítási cél" onClose={onClose} description="Üres csoportlista az egész vagyont méri.">
      <div className="grid gap-3">
        <Field label="Név">
          <input className="field" value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} />
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Összeg">
            <input
              className="field tabular-nums"
              inputMode="decimal"
              value={draft.target}
              onChange={(event) => setDraft({ ...draft, target: Number(event.target.value.replace(",", ".")) || 0 })}
            />
          </Field>
          <Field label="Deviza">
            <select className="field" value={draft.currency} onChange={(event) => setDraft({ ...draft, currency: event.target.value as Currency })}>
              {(["HUF", "USD", "EUR", "GBP"] as Currency[]).map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="Határidő, üresen hagyható">
          <input className="field" type="date" value={draft.deadline} onChange={(event) => setDraft({ ...draft, deadline: event.target.value })} />
        </Field>
        <fieldset>
          <legend className="mb-1 text-sm text-muted">Melyik csoport számít bele</legend>
          <div className="grid gap-1">
            {state.groups.map((group) => (
              <label key={group.id} className="flex min-h-11 items-center gap-3 text-sm">
                <input type="checkbox" className="size-5 accent-pine" checked={draft.groupIds.includes(group.id)} onChange={() => toggle(group.id)} />
                {group.name}
              </label>
            ))}
          </div>
        </fieldset>
        <label className="flex min-h-11 items-center gap-3 text-sm">
          <input type="checkbox" className="size-5 accent-pine" checked={draft.real} onChange={(event) => setDraft({ ...draft, real: event.target.checked })} />
          A cél inflációval korrigálva nőjön
        </label>
        <Field label="Megjegyzés">
          <input className="field" value={draft.note} onChange={(event) => setDraft({ ...draft, note: event.target.value })} />
        </Field>
        <p className="text-xs text-muted">
          Mai forintban a nominális cél {formatMoney(toHuf(draft.target, draft.currency, state.market.fx), "HUF")}.
        </p>
        <div className="mt-2 flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Mégse
          </button>
          <button type="button" className="btn btn-primary" disabled={!draft.name.trim()} onClick={() => onSave({ ...draft, name: draft.name.trim() })}>
            Mentés
          </button>
        </div>
      </div>
    </Modal>
  );
}
