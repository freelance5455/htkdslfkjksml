import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page";
import { Badge, Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { createAccount, getLedger } from "@/lib/accounting/actions";
import { formatJalali, formatRial, GROUP_LABELS, todayIso } from "@/lib/accounting/format";
import { useBootstrap, useInvalidateBooks } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/accounts")({ component: AccountsPage });

function AccountsPage() {
  const boot = useBootstrap();
  const invalidate = useInvalidateBooks();
  const accounts = boot.data?.accounts ?? [];
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [parentCode, setParentCode] = useState("6111");
  const [open, setOpen] = useState(false);
  const [ledgerId, setLedgerId] = useState<string | null>(null);
  const [ledger, setLedger] = useState<Awaited<ReturnType<typeof getLedger>> | null>(null);

  async function save() {
    try {
      const parent = accounts.find((a) => a.code === parentCode);
      await createAccount({
        data: {
          code,
          name,
          parentCode,
          nature: (parent?.nature as "debit" | "credit") ?? "debit",
          groupCode: parent?.groupCode ?? "expense",
        },
      });
      toast.success("حساب ایجاد شد");
      setOpen(false);
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    }
  }

  async function openLedger(id: string) {
    setLedgerId(id);
    const data = await getLedger({ data: { accountId: id, from: "2026-03-21", to: todayIso() } });
    setLedger(data);
  }

  return (
    <div>
      <PageHeader
        title="کدینگ حساب‌ها"
        description="چهار سطح: گروه، کل، معین، تفصیلی. ساختار پویا است و حساب جدید به سال مالی آسیب نمی‌زند."
        actions={
          <Button variant="gold" onClick={() => setOpen(true)}>
            حساب جدید
          </Button>
        }
      />
      {open ? (
        <Card className="mb-5 grid gap-3 sm:grid-cols-3">
          <Field label="کد">
            <Input value={code} onChange={(e) => setCode(e.target.value)} dir="ltr" />
          </Field>
          <Field label="نام">
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="والد">
            <select value={parentCode} onChange={(e) => setParentCode(e.target.value)} className="h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm">
              {accounts
                .filter((a) => a.level < 4)
                .map((a) => (
                  <option key={a.id} value={a.code}>
                    {a.code} {a.name}
                  </option>
                ))}
            </select>
          </Field>
          <div className="sm:col-span-3 flex gap-2">
            <Button onClick={save}>ثبت</Button>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              انصراف
            </Button>
          </div>
        </Card>
      ) : null}
      <div className="overflow-x-auto rounded-[24px] border border-line bg-paper">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="text-xs text-muted">
            <tr>
              <th className="px-4 py-3 text-right">کد</th>
              <th className="px-4 py-3 text-right">نام</th>
              <th className="px-4 py-3 text-right">سطح</th>
              <th className="px-4 py-3 text-right">گروه</th>
              <th className="px-4 py-3 text-right">ماهیت</th>
            </tr>
          </thead>
          <tbody>
            {accounts.map((a) => (
              <tr key={a.id} className="border-t border-line">
                <td className="px-4 py-2 font-medium" style={{ paddingRight: 16 + (a.level - 1) * 12 }}>
                  {a.isPostable ? (
                    <button type="button" className="text-navy underline-offset-2 hover:underline" onClick={() => openLedger(a.id)}>
                      {a.code}
                    </button>
                  ) : (
                    a.code
                  )}
                </td>
                <td className="px-4 py-2">{a.name}</td>
                <td className="px-4 py-2">{a.level}</td>
                <td className="px-4 py-2">{GROUP_LABELS[a.groupCode] ?? a.groupCode}</td>
                <td className="px-4 py-2">
                  <Badge tone={a.nature === "debit" ? "default" : "gold"}>{a.nature === "debit" ? "بدهکار" : "بستانکار"}</Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {ledger && ledgerId ? (
        <Card className="mt-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-medium text-navy">
              دفتر کل {ledger.account.code} — {ledger.account.name}
            </h2>
            <button type="button" className="text-xs text-muted" onClick={() => setLedger(null)}>
              بستن
            </button>
          </div>
          <div className="mb-3 text-xs text-muted">مانده اول دوره: {formatRial(ledger.opening)}</div>
          <table className="w-full text-xs">
            <thead>
              <tr className="text-muted">
                <th className="py-2 text-right">تاریخ</th>
                <th className="py-2 text-right">سند</th>
                <th className="py-2 text-right">شرح</th>
                <th className="py-2 text-left">بدهکار</th>
                <th className="py-2 text-left">بستانکار</th>
                <th className="py-2 text-left">مانده</th>
              </tr>
            </thead>
            <tbody>
              {ledger.lines.map((l, i) => (
                <tr key={i} className="border-t border-line">
                  <td className="py-2">{formatJalali(l.date)}</td>
                  <td className="py-2">{l.number}</td>
                  <td className="py-2">{l.description}</td>
                  <td className="py-2 text-left">{l.debit ? formatRial(l.debit) : ""}</td>
                  <td className="py-2 text-left">{l.credit ? formatRial(l.credit) : ""}</td>
                  <td className="py-2 text-left">{formatRial(l.balance)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : null}
    </div>
  );
}
