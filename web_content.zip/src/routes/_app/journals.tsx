import { createFileRoute } from "@tanstack/react-router";
import { Money, PageHeader } from "@/components/layout/page";
import { Badge } from "@/components/ui/card";
import { formatJalali, todayIso } from "@/lib/accounting/format";
import { useJournalBook } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/journals")({ component: JournalsPage });

function JournalsPage() {
  const { data = [] } = useJournalBook("2026-03-21", todayIso());
  const grouped = new Map<string, typeof data>();
  for (const row of data) {
    const list = grouped.get(row.journalId) ?? [];
    list.push(row);
    grouped.set(row.journalId, list);
  }
  return (
    <div>
      <PageHeader title="اسناد حسابداری" description="هر سند حداقل دو ردیف متوازن دارد. مسیر ردیابی: گزارش → حساب → سند → عملیات → کاربر." />
      <div className="space-y-3">
        {[...grouped.values()].map((lines) => {
          const head = lines[0];
          const d = lines.reduce((s, l) => s + l.debit, 0);
          const c = lines.reduce((s, l) => s + l.credit, 0);
          return (
            <article key={head.journalId} className="rounded-[22px] border border-line bg-paper p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="font-medium text-navy">{head.number}</div>
                  <div className="text-xs text-muted">
                    {formatJalali(head.date)} · {head.journalDescription} · {head.operationNumber}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone={head.status === "posted" ? "ok" : "danger"}>{head.status}</Badge>
                  <Badge tone={d === c ? "ok" : "danger"}>{d === c ? "متوازن" : "نامتوازن"}</Badge>
                </div>
              </div>
              <table className="mt-3 w-full text-xs">
                <tbody>
                  {lines.map((l, i) => (
                    <tr key={i} className="border-t border-line">
                      <td className="py-2">
                        {l.accountCode} {l.accountName}
                      </td>
                      <td className="py-2">{l.partyName}</td>
                      <td className="py-2 text-left">
                        {l.debit ? <Money value={l.debit} compact /> : ""}
                      </td>
                      <td className="py-2 text-left">
                        {l.credit ? <Money value={l.credit} compact /> : ""}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </article>
          );
        })}
      </div>
    </div>
  );
}
