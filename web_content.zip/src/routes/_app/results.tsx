"use client";

import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DecisionBadge, MentionBadge } from "@/components/mention-badge";
import { listResults, listSchools, listStreams } from "@/lib/bac/server";
import { formatScore, fullName } from "@/lib/bac/calc";

export const Route = createFileRoute("/_app/results")({
  loader: async () => {
    const [results, streams, schools] = await Promise.all([
      listResults({ data: {} }),
      listStreams(),
      listSchools(),
    ]);
    return { results, streams, schools };
  },
  component: ResultsPage,
});

function ResultsPage() {
  const navigate = useNavigate();
  const initial = Route.useLoaderData();
  const [q, setQ] = useState("");
  const [streamId, setStreamId] = useState("all");
  const [schoolId, setSchoolId] = useState("all");
  const [decision, setDecision] = useState("all");

  const filters = {
    q: q.trim() || undefined,
    streamId: streamId === "all" ? undefined : Number(streamId),
    schoolId: schoolId === "all" ? undefined : Number(schoolId),
    decision: decision === "all" ? undefined : (decision as "ناجح" | "راسب"),
  };

  const unfiltered = !filters.q && !filters.streamId && !filters.schoolId && !filters.decision;

  const resultsQuery = useQuery({
    queryKey: ["results", filters],
    queryFn: () => listResults({ data: filters }),
    initialData: unfiltered ? initial.results : undefined,
  });
  const streamsQuery = useQuery({
    queryKey: ["streams"],
    queryFn: () => listStreams(),
    initialData: initial.streams,
  });
  const schoolsQuery = useQuery({
    queryKey: ["schools"],
    queryFn: () => listSchools(),
    initialData: initial.schools,
  });

  const rows = resultsQuery.data ?? [];
  const passed = rows.filter((r) => r.decision === "ناجح").length;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-semibold">نتائج الدورة</h1>
        <p className="mt-1 text-sm text-muted">
          المعدلات المحسومة بعد إدخال كل علامات الشعبة. اضغط صفاً لفتح الملف أو الشهادة.
        </p>
      </div>

      <Card className="p-4">
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
          <div className="relative">
            <Search className="pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-subtle" />
            <Input
              className="pr-9"
              placeholder="بحث"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <Select value={streamId} onValueChange={setStreamId}>
            <SelectTrigger>
              <SelectValue placeholder="الشعبة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الشعب</SelectItem>
              {streamsQuery.data?.map((s) => (
                <SelectItem key={s.id} value={String(s.id)}>
                  {s.nameAr}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={schoolId} onValueChange={setSchoolId}>
            <SelectTrigger>
              <SelectValue placeholder="الثانوية" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الثانويات</SelectItem>
              {schoolsQuery.data?.map((s) => (
                <SelectItem key={s.id} value={String(s.id)}>
                  {s.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={decision} onValueChange={setDecision}>
            <SelectTrigger>
              <SelectValue placeholder="الحسم" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">ناجح وراسب</SelectItem>
              <SelectItem value="ناجح">ناجح فقط</SelectItem>
              <SelectItem value="راسب">راسب فقط</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <p className="mt-3 text-xs text-muted">
          المعروض {rows.length} نتيجة · منها {passed} ناجح
        </p>
      </Card>

      <Card className="min-w-0 overflow-hidden p-0">
        {resultsQuery.isLoading ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-12" />
            ))}
          </div>
        ) : !rows.length ? (
          <p className="p-8 text-center text-sm text-muted">لا توجد نتائج محسومة بعد.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الترتيب</TableHead>
                <TableHead>رقم التسجيل</TableHead>
                <TableHead>المترشح</TableHead>
                <TableHead>الشعبة</TableHead>
                <TableHead>المعدل</TableHead>
                <TableHead>التقدير</TableHead>
                <TableHead>الحسم</TableHead>
                <TableHead>رقم الشهادة</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((row, index) => (
                <TableRow
                  key={row.id}
                  className="cursor-pointer"
                  onClick={() =>
                    void navigate({ to: "/students/$id", params: { id: String(row.id) } })
                  }
                >
                  <TableCell className="tabular-nums">{index + 1}</TableCell>
                  <TableCell className="tabular-nums">{row.examNumber}</TableCell>
                  <TableCell>{fullName(row.lastName, row.firstName)}</TableCell>
                  <TableCell>{row.streamName}</TableCell>
                  <TableCell className="font-medium tabular-nums">
                    {formatScore(row.average)}
                  </TableCell>
                  <TableCell>
                    <MentionBadge mention={row.mention} decision={row.decision} />
                  </TableCell>
                  <TableCell>
                    <DecisionBadge decision={row.decision} />
                  </TableCell>
                  <TableCell className="tabular-nums text-muted">
                    {row.certificateNumber ?? "—"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
}
