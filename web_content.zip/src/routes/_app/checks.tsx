import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Money, PageHeader } from "@/components/layout/page";
import { Badge } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { updateCheckStatus } from "@/lib/accounting/actions";
import { CHECK_STATUS, formatJalali } from "@/lib/accounting/format";
import { useChecks, useInvalidateBooks } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/checks")({ component: ChecksPage });

function ChecksPage() {
  const { data = [] } = useChecks();
  const invalidate = useInvalidateBooks();
  async function setStatus(id: string, status: string) {
    await updateCheckStatus({ data: { id, status } });
    toast.success("وضعیت چک به‌روز شد");
    invalidate();
  }
  return (
    <div>
      <PageHeader title="مدیریت چک‌ها" description="دریافتنی و پرداختنی. وصول و برگشت از مسیر عملیات، سند دوبل می‌سازد." />
      <div className="overflow-x-auto rounded-[24px] border border-line bg-paper">
        <table className="w-full min-w-[700px] text-sm">
          <thead className="text-xs text-muted">
            <tr>
              <th className="px-4 py-3 text-right">شماره</th>
              <th className="px-4 py-3 text-right">نوع</th>
              <th className="px-4 py-3 text-right">شخص</th>
              <th className="px-4 py-3 text-right">بانک</th>
              <th className="px-4 py-3 text-left">مبلغ</th>
              <th className="px-4 py-3 text-right">سررسید</th>
              <th className="px-4 py-3 text-right">وضعیت</th>
            </tr>
          </thead>
          <tbody>
            {data.map((c) => (
              <tr key={c.id} className="border-t border-line">
                <td className="px-4 py-3">{c.number}</td>
                <td className="px-4 py-3">{c.kind === "receivable" ? "دریافتنی" : "پرداختنی"}</td>
                <td className="px-4 py-3">{c.party_name}</td>
                <td className="px-4 py-3">{c.bank_name}</td>
                <td className="px-4 py-3 text-left">
                  <Money value={c.amount} compact />
                </td>
                <td className="px-4 py-3">{c.due_date ? formatJalali(c.due_date) : "—"}</td>
                <td className="px-4 py-3">
                  <Badge>{CHECK_STATUS[c.status] ?? c.status}</Badge>
                  {c.kind === "receivable" && c.status === "in_hand" ? (
                    <Button size="sm" variant="ghost" className="mr-2" onClick={() => setStatus(c.id, "deposited")}>
                      واگذاری
                    </Button>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
