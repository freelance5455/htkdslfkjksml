import { createFileRoute } from "@tanstack/react-router";
import { Money, PageHeader, StatCard } from "@/components/layout/page";
import { Card } from "@/components/ui/card";
import { CHECK_STATUS, formatJalali } from "@/lib/accounting/format";
import { useChecks, useDashboard } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/liquidity")({ component: LiquidityPage });

function LiquidityPage() {
  const { data } = useDashboard();
  const checks = useChecks();
  if (!data) return <div className="h-40 animate-pulse rounded-[24px] bg-secondary" />;
  const rec = (checks.data ?? []).filter((c) => c.kind === "receivable" && ["in_hand", "deposited"].includes(c.status));
  const pay = (checks.data ?? []).filter((c) => c.kind === "payable" && ["issued"].includes(c.status));
  const recSum = rec.reduce((s, c) => s + c.amount, 0);
  const paySum = pay.reduce((s, c) => s + c.amount, 0);
  return (
    <div>
      <PageHeader title="نقدینگی" description="وضعیت امروز، هفته و ماه بر اساس مانده منابع مالی، چک‌ها و تعهدات." />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard gold label="نقد و بانک" value={<Money value={data.liquid} compact />} />
        <StatCard label="صندوق" value={<Money value={data.cash} compact />} />
        <StatCard label="بانک‌ها" value={<Money value={data.bank} compact />} />
        <StatCard label="تنخواه" value={<Money value={data.petty} compact />} />
        <StatCard label="خالص جریان امروز" value={<Money value={data.netCashToday} compact />} />
        <StatCard label="چک‌های دریافتی" value={<Money value={recSum} compact />} />
        <StatCard label="چک‌های پرداختی" value={<Money value={paySum} compact />} />
        <StatCard label="تعهدات + بدهی" value={<Money value={data.ap + paySum} compact />} />
      </div>
      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <Card>
          <h2 className="text-sm font-medium text-navy">پیش‌بینی ۷ تا ۳۰ روز</h2>
          <p className="mt-2 text-sm text-muted">
            نقد فعلی به‌علاوه چک‌های دریافتنی سررسیدنشده، منهای چک‌های پرداختنی و بدهی‌های باز.
          </p>
          <div className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span>افق ۷ روز</span>
              <Money value={data.liquid + recSum * 0.3 - paySum * 0.2} compact />
            </div>
            <div className="flex justify-between">
              <span>افق ۳۰ روز</span>
              <Money value={data.liquid + recSum - paySum - data.ap * 0.25} compact />
            </div>
          </div>
        </Card>
        <Card>
          <h2 className="text-sm font-medium text-navy">چک‌های باز</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {(checks.data ?? []).slice(0, 8).map((c) => (
              <li key={c.id} className="flex justify-between gap-2">
                <span>
                  {c.number} · {c.party_name} · {CHECK_STATUS[c.status] ?? c.status}
                  <div className="text-[11px] text-muted">{c.due_date ? formatJalali(c.due_date) : ""}</div>
                </span>
                <Money value={c.amount} compact />
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
