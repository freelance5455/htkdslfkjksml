"use client";

import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { createSchool, listSchools } from "@/lib/bac/server";
import { WILAYAS } from "@/lib/bac/types";

export const Route = createFileRoute("/_app/schools")({
  loader: () => listSchools(),
  component: SchoolsPage,
});

function SchoolsPage() {
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [wilaya, setWilaya] = useState("الجزائر");

  const schoolsQuery = useQuery({
    queryKey: ["schools"],
    queryFn: () => listSchools(),
    initialData: Route.useLoaderData(),
  });

  const createMutation = useMutation({
    mutationFn: createSchool,
    onSuccess: () => {
      toast.success("أُضيفت الثانوية إلى السجل");
      setName("");
      queryClient.invalidateQueries({ queryKey: ["schools"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-semibold">الثانويات</h1>
        <p className="mt-1 text-sm text-muted">
          مرجع المؤسسات المرتبطة بملفات المترشحين حسب الولاية.
        </p>
      </div>

      <Card>
        <h2 className="text-base font-semibold">إضافة ثانوية</h2>
        <form
          className="mt-4 grid gap-3 sm:grid-cols-[1fr_12rem_auto]"
          onSubmit={(e) => {
            e.preventDefault();
            createMutation.mutate({ data: { name, wilaya } });
          }}
        >
          <div className="space-y-1.5">
            <Label htmlFor="school-name">اسم الثانوية</Label>
            <Input
              id="school-name"
              required
              minLength={3}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="ثانوية…"
            />
          </div>
          <div className="space-y-1.5">
            <Label>الولاية</Label>
            <Select value={wilaya} onValueChange={setWilaya}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {WILAYAS.map((w) => (
                  <SelectItem key={w} value={w}>
                    {w}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-end">
            <Button type="submit" className="w-full sm:w-auto" disabled={createMutation.isPending}>
              إضافة
            </Button>
          </div>
        </form>
      </Card>

      <Card className="overflow-hidden p-0">
        {schoolsQuery.isLoading ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-10" />
            ))}
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الثانوية</TableHead>
                <TableHead>الولاية</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {schoolsQuery.data?.map((school) => (
                <TableRow key={school.id}>
                  <TableCell className="font-medium">{school.name}</TableCell>
                  <TableCell>{school.wilaya}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
}
