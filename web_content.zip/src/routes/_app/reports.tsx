import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Money, PageHeader } from "@/components/layout/page";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { downloadCsv, printReport } from "@/lib/accounting/export";
import { formatJalali, formatRial, todayIso } from "@/lib/accounting/format";
import { useJournalBook, useStatements, useTrial } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/reports")({ component: ReportsPage });

const TABS = [
  { id: "trial", label: "تراز آزمایشی" },
  { id: "pnl", label: "سود و زیان" },
  { id: "bs", label: "ترازنامه" },
  { id: "cf", label: "جریان وجوه" },
  { id: "journal", label: "دفتر روزنامه" },
] as const;

function monthStart() {
  const d = new Date();
  d.setDate(1);
  const z = (v: number) => String(v).padStart(2, "0");
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}

function ReportsPage() {
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("trial");
  const [from, setFrom] = useState("2026-03-21");
  const [to, setTo] = useState(todayIso());
  const [cols, setCols] = useState<2 | 4 | 6>(6);
  const trial = useTrial(from, to);
  const st = useStatements(from, to);
  const book = useJournalBook(from, to);

  const title = TABS.find((t) => t.id === tab)?.label ?? "";

  return (
    <div>
      <PageHeader
        title="گزارش‌های مالی"
        description={`از ${formatJalali(from)} تا ${formatJalali(to)}`}
        actions={
          <>
            <Button variant="outline" onClick={() => printReport()}>
              PDF / چاپ
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                if (tab === "trial" && trial.data) {
                  downloadCsv(
                    "trial-balance",
                    ["کد", "حساب", "بدهکار اول", "بستانکار اول", "گردش بد", "گردش بس", "مانده بد", "مانده بس"],
                    trial.data.rows.map((r) => [
                      r.code,
                      r.name,
                      r.openingDebit,
                      r.openingCredit,
                      r.turnoverDebit,
                      r.turnoverCredit,
                      r.balanceDebit,
                      r.balanceCredit,
                    ]),
                  );
                }
              }}
            >
              Excel / CSV
            </Button>
          </>
        }
      />
      <div className="no-print mb-4 flex flex-wrap items-end gap-3">
        <label className="text-xs text-muted">
          از تاریخ
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="mt-1" />
        </label>
        <label className="text-xs text-muted">
          تا تاریخ
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="mt-1" />
        </label>
        <Button size="sm" variant="ghost" onClick={() => setFrom(monthStart())}>
          ماه جاری
        </Button>
      </div>
      <div className="no-print mb-5 flex gap-1 overflow-x-auto">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`rounded-full px-3 py-1.5 text-xs ${tab === t.id ? "bg-navy text-cream" : "bg-paper text-muted"}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <Card className="print:shadow-none print:border-none">
        <div className="mb-4 hidden print:block">
          <div className="font-display text-xl tracking-[0.14em]">MR,KHORASANI</div>
          <div className="text-sm">{title}</div>
        </div>
        {tab === "trial" && trial.data ? (
          <div>
            <div className="no-print mb-3 flex gap-2">
              {([2, 4, 6] as const).map((n) => (
                <Button key={n} size="sm" variant={cols === n ? "default" : "outline"} onClick={() => setCols(n)}>
                  {n} ستونی
                </Button>
              ))}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px] text-xs">
                <thead>
                  <tr className="text-muted">
                    <th className="py-2 text-right">کد</th>
                    <th className="py-2 text-right">حساب</th>
                    {cols === 6 ? (
                      <>
                        <th className="py-2 text-left">بد اول دوره</th>
                        <th className="py-2 text-left">بس اول دوره</th>
                      </>
                    ) : null}
                    {cols >= 4 ? (
                      <>
                        <th className="py-2 text-left">گردش بد</th>
                        <th className="py-2 text-left">گردش بس</th>
                      </>
                    ) : null}
                    <th className="py-2 text-left">مانده بد</th>
                    <th className="py-2 text-left">مانده بس</th>
                  </tr>
                </thead>
                <tbody>
                  {trial.data.rows.map((r) => (
                    <tr key={r.accountId} className="border-t border-line">
                      <td className="py-2">{r.code}</td>
                      <td className="py-2">{r.name}</td>
                      {cols === 6 ? (
                        <>
                          <td className="py-2 text-left tabular">{r.openingDebit ? formatRial(r.openingDebit) : ""}</td>
                          <td className="py-2 text-left tabular">{r.openingCredit ? formatRial(r.openingCredit) : ""}</td>
                        </>
                      ) : null}
                      {cols >= 4 ? (
                        <>
                          <td className="py-2 text-left tabular">{r.turnoverDebit ? formatRial(r.turnoverDebit) : ""}</td>
                          <td className="py-2 text-left tabular">{r.turnoverCredit ? formatRial(r.turnoverCredit) : ""}</td>
                        </>
                      ) : null}
                      <td className="py-2 text-left tabular">{r.balanceDebit ? formatRial(r.balanceDebit) : ""}</td>
                      <td className="py-2 text-left tabular">{r.balanceCredit ? formatRial(r.balanceCredit) : ""}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-navy/30 font-medium">
                    <td className="py-2" colSpan={2}>
                      جمع
                    </td>
                    {cols === 6 ? (
                      <>
                        <td className="py-2 text-left tabular">{formatRial(trial.data.totals.openingDebit)}</td>
                        <td className="py-2 text-left tabular">{formatRial(trial.data.totals.openingCredit)}</td>
                      </>
                    ) : null}
                    {cols >= 4 ? (
                      <>
                        <td className="py-2 text-left tabular">{formatRial(trial.data.totals.turnoverDebit)}</td>
                        <td className="py-2 text-left tabular">{formatRial(trial.data.totals.turnoverCredit)}</td>
                      </>
                    ) : null}
                    <td className="py-2 text-left tabular">{formatRial(trial.data.totals.balanceDebit)}</td>
                    <td className="py-2 text-left tabular">{formatRial(trial.data.totals.balanceCredit)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
            <div className={`mt-4 text-sm ${trial.data.difference === 0 ? "text-success" : "text-danger"}`}>
              اختلاف تراز: <Money value={trial.data.difference} /> {trial.data.difference === 0 ? "— متوازن" : ""}
            </div>
          </div>
        ) : null}

        {tab === "pnl" && st.data ? (
          <StatementList
            sections={[
              { title: "درآمدها", rows: st.data.pnl.income, total: st.data.pnl.incomeSum },
              { title: "بهای تمام‌شده", rows: st.data.pnl.cogs, total: st.data.pnl.cogsSum },
              { title: "هزینه‌ها", rows: st.data.pnl.expense, total: st.data.pnl.expSum },
            ]}
            footer={[
              ["سود ناخالص", st.data.pnl.gross],
              ["سود خالص", st.data.pnl.net],
            ]}
          />
        ) : null}

        {tab === "bs" && st.data ? (
          <StatementList
            sections={[
              { title: "دارایی‌ها", rows: st.data.balanceSheet.assets, total: st.data.balanceSheet.assets.reduce((s, r) => s + r.amount, 0) },
              { title: "بدهی‌ها", rows: st.data.balanceSheet.liabilities, total: st.data.balanceSheet.liabilities.reduce((s, r) => s + r.amount, 0) },
              { title: "سرمایه", rows: st.data.balanceSheet.equity, total: st.data.balanceSheet.equity.reduce((s, r) => s + r.amount, 0) },
            ]}
            footer={[["سود جاری (به حقوق صاحبان سرمایه)", st.data.balanceSheet.net]]}
          />
        ) : null}

        {tab === "cf" && st.data ? (
          <div className="space-y-3 text-sm">
            <Row k="وجوه ورودی عملیاتی" v={st.data.cashFlow.receipts} />
            <Row k="وجوه خروجی عملیاتی" v={st.data.cashFlow.payments} />
            <Row k="خالص جریان نقدی" v={st.data.cashFlow.receipts - st.data.cashFlow.payments} />
          </div>
        ) : null}

        {tab === "journal" && book.data ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[800px] text-xs">
              <thead>
                <tr className="text-muted">
                  <th className="py-2 text-right">سند</th>
                  <th className="py-2 text-right">تاریخ</th>
                  <th className="py-2 text-right">حساب</th>
                  <th className="py-2 text-right">تفصیلی</th>
                  <th className="py-2 text-left">بدهکار</th>
                  <th className="py-2 text-left">بستانکار</th>
                  <th className="py-2 text-right">مرجع</th>
                </tr>
              </thead>
              <tbody>
                {book.data.map((r, i) => (
                  <tr key={`${r.journalId}-${r.lineNo}-${i}`} className="border-t border-line">
                    <td className="py-2">{r.number}</td>
                    <td className="py-2">{formatJalali(r.date)}</td>
                    <td className="py-2">
                      {r.accountCode} {r.accountName}
                    </td>
                    <td className="py-2">{r.partyName ?? ""}</td>
                    <td className="py-2 text-left tabular">{r.debit ? formatRial(r.debit) : ""}</td>
                    <td className="py-2 text-left tabular">{r.credit ? formatRial(r.credit) : ""}</td>
                    <td className="py-2">{r.operationNumber ?? ""}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </Card>
    </div>
  );
}

function StatementList({
  sections,
  footer,
}: {
  sections: { title: string; rows: { code: string; name: string; amount: number }[]; total: number }[];
  footer: [string, number][];
}) {
  return (
    <div className="space-y-6">
      {sections.map((s) => (
        <div key={s.title}>
          <h3 className="mb-2 text-sm font-medium text-navy">{s.title}</h3>
          {s.rows.map((r) => (
            <Row key={r.code} k={`${r.code} ${r.name}`} v={r.amount} />
          ))}
          <Row k={`جمع ${s.title}`} v={s.total} strong />
        </div>
      ))}
      {footer.map(([k, v]) => (
        <Row key={k} k={k} v={v} strong />
      ))}
    </div>
  );
}

function Row({ k, v, strong }: { k: string; v: number; strong?: boolean }) {
  return (
    <div className={`flex items-center justify-between border-t border-line py-2 text-sm ${strong ? "font-medium" : ""}`}>
      <span>{k}</span>
      <Money value={v} />
    </div>
  );
}
