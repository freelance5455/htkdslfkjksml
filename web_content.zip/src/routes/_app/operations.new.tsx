import { createFileRoute, Link } from "@tanstack/react-router";
import { OpForm } from "@/components/ops/op-form";
import { PageHeader } from "@/components/layout/page";
import { OP_GROUPS, OP_LABELS } from "@/lib/accounting/format";
import type { OpType } from "@/lib/accounting/types";
import { useState } from "react";

export const Route = createFileRoute("/_app/operations/new")({ component: NewOpPage });

function NewOpPage() {
  const [picked, setPicked] = useState<OpType | null>(null);
  return (
    <div>
      <PageHeader
        title="ثبت عملیات"
        description="نوع رویداد را انتخاب کنید. سیستم سند دوبل را می‌سازد."
        actions={
          <Link to="/operations" className="text-sm text-muted">
            بازگشت به فهرست
          </Link>
        }
      />
      {!picked ? (
        <div className="space-y-6">
          {OP_GROUPS.map((g) => (
            <section key={g.title}>
              <h2 className="mb-3 text-xs tracking-[0.18em] text-muted">{g.title}</h2>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
                {g.types.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setPicked(t)}
                    className="rounded-[18px] border border-line bg-paper px-3 py-4 text-right text-sm hover:border-gold"
                  >
                    {OP_LABELS[t]}
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>
      ) : (
        <div>
          <button type="button" className="mb-4 text-xs text-muted" onClick={() => setPicked(null)}>
            تغییر نوع عملیات
          </button>
          <OpForm initialType={picked} />
        </div>
      )}
    </div>
  );
}
