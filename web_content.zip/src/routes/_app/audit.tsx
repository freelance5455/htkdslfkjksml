import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/page";
import { Badge } from "@/components/ui/card";
import { formatJalali } from "@/lib/accounting/format";
import { useAudit } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/audit")({ component: AuditPage });

function AuditPage() {
  const { data = [] } = useAudit();
  return (
    <div>
      <PageHeader
        title="ردپای حسابرسی"
        description="چه کسی، چه چیزی، چه زمانی، چه مبلغی، قبل و بعد از تغییر، روی کدام سند و کدام روز."
      />
      <div className="overflow-x-auto rounded-[24px] border border-line bg-paper">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="text-xs text-muted">
            <tr>
              <th className="px-4 py-3 text-right">زمان</th>
              <th className="px-4 py-3 text-right">عمل</th>
              <th className="px-4 py-3 text-right">موجودیت</th>
              <th className="px-4 py-3 text-right">شناسه</th>
              <th className="px-4 py-3 text-right">دلیل</th>
            </tr>
          </thead>
          <tbody>
            {data.map((r) => (
              <tr key={r.id} className="border-t border-line align-top">
                <td className="px-4 py-3 text-xs">{r.occurred_at.slice(0, 19).replace("T", " ")}</td>
                <td className="px-4 py-3">
                  <Badge>{r.action}</Badge>
                </td>
                <td className="px-4 py-3">{r.entity}</td>
                <td className="px-4 py-3 text-xs">{r.entity_id}</td>
                <td className="px-4 py-3 text-xs">
                  {r.reason}
                  {r.old_value ? <div className="mt-1 text-muted">قبل: {r.old_value.slice(0, 80)}</div> : null}
                  {r.new_value ? <div className="text-muted">بعد: {r.new_value.slice(0, 80)}</div> : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
