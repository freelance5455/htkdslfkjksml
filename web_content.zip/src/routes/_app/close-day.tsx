import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { closeDay, requestReopenDay } from "@/lib/accounting/actions";
import { downloadJson } from "@/lib/accounting/export";
import { formatJalaliLong, todayIso } from "@/lib/accounting/format";
import { useDashboard, useHealth, useInvalidateBooks } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/close-day")({ component: CloseDayPage });

function CloseDayPage() {
  const dash = useDashboard();
  const health = useHealth();
  const invalidate = useInvalidateBooks();
  const [date, setDate] = useState(todayIso());
  const [ack, setAck] = useState(false);
  const [phrase, setPhrase] = useState("");
  const [busy, setBusy] = useState(false);

  async function close() {
    if (!ack) {
      toast.error("تأیید الزامی است.");
      return;
    }
    setBusy(true);
    try {
      const res = await closeDay({ data: { date, confirm: true } });
      toast.success(`روز بسته شد. پشتیبان ${res.backupName}`);
      downloadJson(res.backupName, JSON.parse(res.packageJson));
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    } finally {
      setBusy(false);
    }
  }

  async function reopen() {
    try {
      await requestReopenDay({ data: { date, phrase } });
      toast.success("روز با ثبت در حسابرسی بازگشایی شد.");
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    }
  }

  return (
    <div>
      <PageHeader title="بستن روز" description="پس از بستن، ویرایش مستقیم ممنوع است. اصلاح فقط با سند برگشتی / اصلاحی." />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h2 className="text-sm font-medium text-navy">کنترل‌های پایان روز</h2>
          <ul className="mt-4 space-y-2 text-sm">
            <li>اسناد نامتوازن: {health.data?.unbalanced ?? "—"}</li>
            <li>عملیات امروز: {health.data?.opsToday ?? "—"}</li>
            <li>وضعیت امروز: {dash.data?.todayStatus === "closed" ? "بسته" : "باز"}</li>
            <li>تاریخ انتخابی: {formatJalaliLong(date)}</li>
          </ul>
          <label className="mt-5 block text-xs text-muted">
            تاریخ
            <Input type="date" className="mt-1" value={date} onChange={(e) => setDate(e.target.value)} />
          </label>
          <label className="mt-4 flex items-start gap-2 text-sm">
            <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} className="mt-1" />
            پس از بستن روز، اطلاعات این روز قابل ویرایش مستقیم نخواهد بود.
          </label>
          <Button className="mt-5 w-full" variant="gold" disabled={busy} onClick={close}>
            بستن روز و تولید بسته روزانه
          </Button>
        </Card>
        <Card>
          <h2 className="text-sm font-medium text-navy">درخواست اصلاح روز بسته‌شده</h2>
          <p className="mt-2 text-sm text-muted">
            بازگشایی عادی مجاز نیست. برای موارد استثنا، عبارت «بازگشایی» را وارد کنید. تمام این فرآیند در Audit Log ثبت می‌شود.
          </p>
          <Input className="mt-4" value={phrase} onChange={(e) => setPhrase(e.target.value)} placeholder="بازگشایی" />
          <Button className="mt-4" variant="outline" onClick={reopen}>
            ثبت درخواست و بازگشایی
          </Button>
        </Card>
      </div>
    </div>
  );
}
