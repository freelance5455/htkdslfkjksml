"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Award, GraduationCap, Percent, Users } from "lucide-react";
import { Card } from "@/components/ui/card";
import { MentionBadge } from "@/components/mention-badge";
import { getDashboard } from "@/lib/bac/server";
import { formatPercent, formatScore, fullName } from "@/lib/bac/calc";

export const Route = createFileRoute("/_app/")({
  loader: () => getDashboard(),
  component: DashboardPage,
});

function DashboardPage() {
  const initial = Route.useLoaderData();
  const { data = initial } = useQuery({
    queryKey: ["dashboard"],
    queryFn: () => getDashboard(),
    initialData: initial,
  });

  const stats = [
    { label: "المترشحون", value: data.candidates, icon: Users },
    { label: "الناجحون", value: data.passed, icon: Award },
    { label: "نسبة النجاح", value: formatPercent(data.passRate), icon: Percent },
    { label: "تقدير امتياز", value: data.excellence, icon: GraduationCap },
  ];

  return (
    <div className="space-y-6">
      <header className="overflow-hidden rounded-lg bg-primary px-5 py-6 text-primary-fg sm:px-8">
        <p className="text-xs tracking-wide text-primary-fg/70">
          الجمهورية الجزائرية الديمقراطية الشعبية · وزارة التربية الوطنية
        </p>
        <h1 className="font-display mt-2 text-3xl sm:text-4xl">ديوان البكالوريا</h1>
        <p className="mt-2 max-w-xl text-sm text-primary-fg/80">
          تسيير المترشحين، إدخال العلامات، حسم النتائج وإصدار شهادات البكالوريا — {data.sessionLabel}.
        </p>
      </header>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((item) => {
          const Icon = item.icon;
          return (
            <Card key={item.label} className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-medium text-muted">{item.label}</p>
                <p className="mt-2 text-2xl font-semibold tabular-nums">{item.value}</p>
              </div>
              <span className="flex size-10 items-center justify-center rounded-sm bg-surface-2 text-primary">
                <Icon className="size-4" />
              </span>
            </Card>
          );
        })}
      </section>

      <section className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <h2 className="text-base font-semibold">توزيع التقديرات</h2>
          <p className="mt-1 text-sm text-muted">عدد المترشحين حسب التقدير بعد حسم المعدل</p>
          <div className="mt-4 h-64">
            {data.mentions.length === 0 ? (
              <p className="flex h-full items-center justify-center text-sm text-muted">
                لا توجد نتائج محسومة بعد.
              </p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.mentions} barSize={28}>
                  <CartesianGrid stroke="var(--color-border)" vertical={false} />
                  <XAxis
                    dataKey="mention"
                    tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    allowDecimals={false}
                    tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                    width={32}
                  />
                  <Tooltip
                    cursor={{ fill: "var(--color-surface-2)" }}
                    contentStyle={{
                      background: "var(--color-surface)",
                      border: "1px solid var(--color-border)",
                      borderRadius: 8,
                      direction: "rtl",
                    }}
                    formatter={(value) => [value as number, "العدد"]}
                  />
                  <Bar dataKey="count" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        <Card className="lg:col-span-2">
          <h2 className="text-base font-semibold">النجاح حسب الشعبة</h2>
          <ul className="mt-4 space-y-3">
            {data.streams.map((stream) => (
              <li key={stream.streamName}>
                <div className="flex items-baseline justify-between gap-2 text-sm">
                  <span>{stream.streamName}</span>
                  <span className="tabular-nums text-muted">
                    {stream.passed}/{stream.candidates} · {formatPercent(stream.passRate)}
                  </span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-surface-2">
                  <div
                    className="h-full rounded-full bg-primary transition-[width] duration-300"
                    style={{ width: `${Math.min(100, stream.passRate)}%` }}
                  />
                </div>
              </li>
            ))}
          </ul>
        </Card>
      </section>

      <Card>
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="text-base font-semibold">أوائل الدفعة</h2>
          <Link to="/results" className="text-sm text-primary hover:underline">
            كل النتائج
          </Link>
        </div>
        {data.topStudents.length === 0 ? (
          <p className="text-sm text-muted">لم يُحسم أي ناجح بعد.</p>
        ) : (
          <ol className="divide-y divide-border">
            {data.topStudents.map((student, index) => (
              <li key={student.id}>
                <Link
                  to="/students/$id"
                  params={{ id: String(student.id) }}
                  className="flex min-h-14 items-center gap-3 py-3"
                >
                  <span className="flex size-8 items-center justify-center rounded-sm bg-surface-2 text-sm font-semibold tabular-nums">
                    {index + 1}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-medium">
                      {fullName(student.lastName, student.firstName)}
                    </span>
                    <span className="block truncate text-xs text-muted">
                      {student.streamName} · {student.schoolName}
                    </span>
                  </span>
                  <span className="text-sm font-semibold tabular-nums">
                    {formatScore(student.average)}
                  </span>
                  <MentionBadge mention={student.mention} decision={student.decision} />
                </Link>
              </li>
            ))}
          </ol>
        )}
      </Card>
    </div>
  );
}
