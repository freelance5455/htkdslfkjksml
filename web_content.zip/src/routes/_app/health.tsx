import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, StatCard } from "@/components/layout/page";
import { Card } from "@/components/ui/card";
import { useHealth } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/health")({ component: HealthPage });

function HealthPage() {
  const { data } = useHealth();
  if (!data) return <div className="h-40 animate-pulse rounded-[24px] bg-secondary" />;
  return (
    <div>
      <PageHeader title="سلامت سیستم" description="تراز، همگام‌سازی، پشتیبان و روزهای باز." />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="عملیات امروز" value={data.opsToday} />
        <StatCard label="اسناد" value={data.journals} />
        <StatCard label="اسناد نامتوازن" value={data.unbalanced} hint={data.unbalanced === 0 ? "سالم" : "نیاز به بررسی"} />
        <StatCard label="روزهای باز" value={data.openDays} />
        <StatCard label="روزهای بسته" value={data.closedDays} />
        <StatCard label="رویداد حسابرسی" value={data.auditEvents} />
        <StatCard label="صف همگام‌سازی" value={data.syncPending} />
        <StatCard label="آخرین پشتیبان" value={data.lastBackup?.backup_name ?? "—"} />
      </div>
      <Card className="mt-5 text-sm text-muted">
        هسته سیستم زنجیرهٔ عملیات → اعتبارسنجی → موتور حسابداری → سند دوبل → دفتر کل → تراز → گزارش و KPI را در یک تراکنش منطقی اجرا می‌کند.
      </Card>
    </div>
  );
}
