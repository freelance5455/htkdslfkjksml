import { createFileRoute } from "@tanstack/react-router";
import { Money, PageHeader, StatCard } from "@/components/layout/page";
import { Badge, Card } from "@/components/ui/card";
import { formatJalali } from "@/lib/accounting/format";
import { useParties } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/crm")({ component: CrmPage });

function CrmPage() {
  const { data = [] } = useParties();
  const customers = data.filter((p) => p.kind === "customer");
  const active = customers.filter((p) => p.opCount > 0);
  const highAr = customers.filter((p) => p.ar > 50_000_000);
  return (
    <div>
      <PageHeader title="باشگاه مشتریان" description="ارزش مشتری، مانده، رفتار پرداخت و آخرین معامله — متصل به دفتر معین." />
      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="مشتریان" value={customers.length} />
        <StatCard label="فعال" value={active.length} />
        <StatCard label="مانده بالا" value={highAr.length} />
        <StatCard label="فروش تجمعی" value={<Money value={customers.reduce((s, p) => s + p.sales, 0)} compact />} />
      </div>
      <div className="grid gap-3">
        {customers.map((p) => (
          <Card key={p.id} className="p-4">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <div className="font-medium text-navy">{p.name}</div>
                <div className="text-xs text-muted">
                  {p.code} · {p.phone} · {p.address}
                </div>
              </div>
              <Badge tone={p.ar > 80_000_000 ? "warn" : "ok"}>
                {p.ar > 80_000_000 ? "ریسک وصول" : "سالم"}
              </Badge>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 text-xs sm:grid-cols-4">
              <div>
                فروش <div className="mt-1 text-sm"><Money value={p.sales} compact /></div>
              </div>
              <div>
                دریافت <div className="mt-1 text-sm"><Money value={p.receipts} compact /></div>
              </div>
              <div>
                مانده بدهکار <div className="mt-1 text-sm"><Money value={p.ar} compact /></div>
              </div>
              <div>
                آخرین خرید <div className="mt-1 text-sm">{p.lastDate ? formatJalali(p.lastDate) : "—"}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
