import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Money, PageHeader } from "@/components/layout/page";
import { Badge, Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { createParty } from "@/lib/accounting/actions";
import { formatJalali, PARTY_LABELS } from "@/lib/accounting/format";
import { useInvalidateBooks, useParties } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/parties")({ component: PartiesPage });

function PartiesPage() {
  const { data = [] } = useParties();
  const invalidate = useInvalidateBooks();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [kind, setKind] = useState("customer");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  async function save() {
    try {
      await createParty({ data: { name, kind, phone, address } });
      toast.success("شخص ثبت شد");
      setOpen(false);
      setName("");
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    }
  }

  return (
    <div>
      <PageHeader
        title="اشخاص"
        description="مشتری، تأمین‌کننده و سایر تفصیلی‌های شناور — بدون تکرار در کدینگ حساب."
        actions={
          <Button variant="gold" onClick={() => setOpen(true)}>
            شخص جدید
          </Button>
        }
      />
      {open ? (
        <Card className="mb-5 grid gap-3 sm:grid-cols-2">
          <Field label="نام">
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="نوع">
            <select value={kind} onChange={(e) => setKind(e.target.value)} className="h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm">
              {Object.entries(PARTY_LABELS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </Field>
          <Field label="تلفن">
            <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
          </Field>
          <Field label="آدرس">
            <Input value={address} onChange={(e) => setAddress(e.target.value)} />
          </Field>
          <div className="sm:col-span-2 flex gap-2">
            <Button onClick={save}>ثبت</Button>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              انصراف
            </Button>
          </div>
        </Card>
      ) : null}
      <div className="grid gap-3 sm:grid-cols-2">
        {data.map((p) => (
          <Card key={p.id} className="p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="font-medium text-navy">{p.name}</div>
                <div className="text-xs text-muted">{p.code}</div>
              </div>
              <Badge>{PARTY_LABELS[p.kind as keyof typeof PARTY_LABELS] ?? p.kind}</Badge>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
              <div>
                فروش / خرید
                <div className="mt-1 text-sm">
                  <Money value={p.sales || p.purchases} compact />
                </div>
              </div>
              <div>
                مانده
                <div className="mt-1 text-sm">
                  <Money value={p.ar || p.ap} compact />
                </div>
              </div>
              <div>آخرین تراکنش: {p.lastDate ? formatJalali(p.lastDate) : "—"}</div>
              <div>تعداد عملیات: {p.opCount}</div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
