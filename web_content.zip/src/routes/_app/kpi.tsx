import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { Money, PageHeader, StatCard } from "@/components/layout/page";
import { Card } from "@/components/ui/card";
import { formatJalali, formatRialCompact } from "@/lib/accounting/format";
import { useDashboard } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/kpi")({ component: KpiPage });

function KpiPage() {
  const { data } = useDashboard();
  if (!data) return <div className="h-40 animate-pulse rounded-[24px] bg-secondary" />;
  const collectionRate = data.ar + data.receiptsToday > 0 ? Math.round((data.receiptsToday / (data.ar + data.receiptsToday)) * 1000) / 10 : 0;
  const expenseToSales = data.income > 0 ? Math.round((data.expense / data.income) * 1000) / 10 : 0;
  return (
    <div>
      <PageHeader title="شاخص‌های مدیریتی" description="فروش، وصول، نقدینگی، هزینه و سودآوری از روی دفتر کل محاسبه می‌شود." />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard gold label="فروش دوره" value={<Money value={data.income} compact />} />
        <StatCard label="سود ناخالص" value={<Money value={data.gross} compact />} />
        <StatCard label="سود خالص" value={<Money value={data.net} compact />} />
        <StatCard label="هزینه به فروش" value={`${expenseToSales}٪`} />
        <StatCard label="مطالبات باز" value={<Money value={data.ar} compact />} />
        <StatCard label="وصول امروز" value={<Money value={data.receiptsToday} compact />} />
        <StatCard label="نسبت نقد" value={<Money value={data.liquid} compact />} />
        <StatCard label="تعهدات" value={<Money value={data.ap + data.notesPay} compact />} />
      </div>
      <Card className="mt-5">
        <div className="mb-4 text-sm font-medium text-navy">فروش در برابر هزینه</div>
        <div className="h-56" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.series}>
              <XAxis dataKey="date" tickFormatter={(v) => formatJalali(String(v)).slice(-5)} tick={{ fontSize: 10 }} />
              <Tooltip formatter={(v) => formatRialCompact(Number(v))} labelFormatter={(v) => formatJalali(String(v))} />
              <Bar dataKey="sales" name="فروش" fill="#071428" radius={[4, 4, 0, 0]} />
              <Bar dataKey="expense" name="هزینه" fill="#C9A227" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}
