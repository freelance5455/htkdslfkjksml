import { createFileRoute, Link } from "@tanstack/react-router";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { Money, PageHeader, SkeletonGrid, StatCard } from "@/components/layout/page";
import { Card } from "@/components/ui/card";
import { formatJalali, formatJalaliLong, formatRialCompact } from "@/lib/accounting/format";
import { useDashboard } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/dashboard")({ component: DashboardPage });

function DashboardPage() {
  const { data, isLoading } = useDashboard();
  if (isLoading || !data) return <SkeletonGrid n={10} />;

  return (
    <div>
      <PageHeader
        eyebrow="Overview"
        title="داشبورد مدیریتی"
        description={`${formatJalaliLong(data.today)} · سال مالی ${data.fiscalYear} · روز ${data.todayStatus === "closed" ? "بسته" : "باز"}`}
        actions={
          <Link to="/operations/new" className="inline-flex h-11 items-center rounded-[10px] bg-navy px-4 text-sm text-cream">
            ثبت عملیات امروز
          </Link>
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <StatCard gold label="موجودی نقد" value={<Money value={data.liquid} compact />} hint="صندوق + بانک + تنخواه" />
        <StatCard label="بانک" value={<Money value={data.bank} compact />} />
        <StatCard label="صندوق" value={<Money value={data.cash} compact />} />
        <StatCard label="مطالبات" value={<Money value={data.ar} compact />} />
        <StatCard label="بدهی‌ها" value={<Money value={data.ap} compact />} />
        <StatCard label="فروش امروز" value={<Money value={data.salesToday} compact />} />
        <StatCard label="دریافت امروز" value={<Money value={data.receiptsToday} compact />} />
        <StatCard label="پرداخت امروز" value={<Money value={data.paymentsToday} compact />} />
        <StatCard label="هزینه امروز" value={<Money value={data.expenseToday} compact />} />
        <StatCard label="سود تقریبی دوره" value={<Money value={data.net} compact />} hint="درآمد − بهای تمام‌شده − هزینه" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="mb-4 text-sm font-medium text-navy">روند ۱۴ روز اخیر</div>
          <div className="h-56" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.series}>
                <defs>
                  <linearGradient id="s" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#071428" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#071428" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" tickFormatter={(v) => formatJalali(String(v)).slice(-5)} tick={{ fontSize: 10 }} />
                <Tooltip
                  formatter={(v) => formatRialCompact(Number(v))}
                  labelFormatter={(v) => formatJalali(String(v))}
                />
                <Area type="monotone" dataKey="sales" name="فروش" stroke="#071428" fill="url(#s)" strokeWidth={1.6} />
                <Area type="monotone" dataKey="receipts" name="دریافت" stroke="#C9A227" fill="transparent" strokeWidth={1.6} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card>
          <div className="text-sm font-medium text-navy">بزرگ‌ترین بدهکاران</div>
          <ul className="mt-3 space-y-3">
            {data.topDebtors.length ? (
              data.topDebtors.map((d) => (
                <li key={d.name} className="flex items-center justify-between text-sm">
                  <span>{d.name}</span>
                  <Money value={d.amount} compact className="text-navy" />
                </li>
              ))
            ) : (
              <li className="text-xs text-muted">مانده‌ای نیست.</li>
            )}
          </ul>
          <div className="mt-6 text-sm font-medium text-navy">بزرگ‌ترین بستانکاران</div>
          <ul className="mt-3 space-y-3">
            {data.topCreditors.length ? (
              data.topCreditors.map((d) => (
                <li key={d.name} className="flex items-center justify-between text-sm">
                  <span>{d.name}</span>
                  <Money value={d.amount} compact />
                </li>
              ))
            ) : (
              <li className="text-xs text-muted">مانده‌ای نیست.</li>
            )}
          </ul>
        </Card>
      </div>
    </div>
  );
}
