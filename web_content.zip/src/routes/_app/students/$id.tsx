"use client";

import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowRight, Printer, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { CertificateDoc } from "@/components/certificate-doc";
import { DecisionBadge, MentionBadge } from "@/components/mention-badge";
import { StudentForm } from "@/components/student-form";
import {
  deleteStudent,
  getStudent,
  issueCertificate,
  listSchools,
  listStreams,
  saveGrades,
  updateStudent,
} from "@/lib/bac/server";
import { formatScore, fullName, genderLabel } from "@/lib/bac/calc";

export const Route = createFileRoute("/_app/students/$id")({
  loader: async ({ params }) => {
    const id = Number(params.id);
    const [student, streams, schools] = await Promise.all([
      getStudent({ data: { id } }),
      listStreams(),
      listSchools(),
    ]);
    return { student, streams, schools };
  },
  component: StudentDetailPage,
});

function StudentDetailPage() {
  const { id } = Route.useParams();
  const studentId = Number(id);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const initial = Route.useLoaderData();

  const studentQuery = useQuery({
    queryKey: ["student", studentId],
    queryFn: () => getStudent({ data: { id: studentId } }),
    enabled: Number.isFinite(studentId),
    initialData: initial.student ?? undefined,
  });
  const streamsQuery = useQuery({
    queryKey: ["streams"],
    queryFn: () => listStreams(),
    initialData: initial.streams,
  });
  const schoolsQuery = useQuery({
    queryKey: ["schools"],
    queryFn: () => listSchools(),
    initialData: initial.schools,
  });

  const student = studentQuery.data;
  const [scores, setScores] = useState<Record<number, string>>({});

  useEffect(() => {
    if (!student) return;
    const next: Record<number, string> = {};
    for (const grade of student.grades) {
      next[grade.subjectId] = grade.score == null ? "" : grade.score.toFixed(2);
    }
    setScores(next);
  }, [student]);

  const saveMutation = useMutation({
    mutationFn: saveGrades,
    onSuccess: () => {
      toast.success("تم حفظ العلامات وحسم المعدل");
      queryClient.invalidateQueries({ queryKey: ["student", studentId] });
      queryClient.invalidateQueries({ queryKey: ["students"] });
      queryClient.invalidateQueries({ queryKey: ["results"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const updateMutation = useMutation({
    mutationFn: updateStudent,
    onSuccess: () => {
      toast.success("تم تحديث بيانات المترشح");
      queryClient.invalidateQueries({ queryKey: ["student", studentId] });
      queryClient.invalidateQueries({ queryKey: ["students"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const issueMutation = useMutation({
    mutationFn: issueCertificate,
    onSuccess: (res) => {
      toast.success(`صدرت الشهادة برقم ${res.certificateNumber}`);
      queryClient.invalidateQueries({ queryKey: ["student", studentId] });
      queryClient.invalidateQueries({ queryKey: ["results"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteStudent,
    onSuccess: () => {
      toast.success("حُذف ملف المترشح");
      queryClient.invalidateQueries({ queryKey: ["students"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["results"] });
      void navigate({ to: "/students" });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  if (studentQuery.isLoading) {
    return <Skeleton className="h-96 rounded-lg" />;
  }
  if (!student) {
    return (
      <Card>
        <p className="text-sm text-muted">المترشح غير موجود.</p>
        <Button asChild variant="outline" className="mt-4">
          <Link to="/students">العودة إلى القائمة</Link>
        </Button>
      </Card>
    );
  }

  const weighted = student.grades.reduce((sum, g) => {
    const raw = scores[g.subjectId];
    const score = raw === "" || raw == null ? g.score : Number(raw);
    if (score == null || Number.isNaN(score)) return sum;
    return sum + score * g.coefficient;
  }, 0);
  const liveAverage = student.totalCoefficient
    ? weighted / student.totalCoefficient
    : 0;
  const allFilled = student.grades.every((g) => {
    const raw = scores[g.subjectId];
    const score = raw === "" ? null : Number(raw);
    return score != null && !Number.isNaN(score);
  });

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <Link
            to="/students"
            className="inline-flex min-h-11 items-center gap-1 text-sm text-muted hover:text-fg"
          >
            <ArrowRight className="size-4" />
            المترشحون
          </Link>
          <h1 className="text-2xl font-semibold">
            {fullName(student.lastName, student.firstName)}
          </h1>
          <p className="mt-1 text-sm text-muted">
            رقم التسجيل {student.examNumber} · {student.streamName} · {student.sessionLabel}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {student.decision === "ناجح" ? (
            student.certificateNumber ? (
              <Button asChild>
                <Link to="/certificates/$id" params={{ id: String(student.id) }}>
                  <Printer className="size-4" />
                  عرض الشهادة
                </Link>
              </Button>
            ) : (
              <Button
                onClick={() => issueMutation.mutate({ data: { studentId: student.id } })}
                disabled={issueMutation.isPending}
              >
                إصدار الشهادة
              </Button>
            )
          ) : null}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline">
                <Trash2 className="size-4" />
                حذف
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>حذف ملف المترشح؟</AlertDialogTitle>
                <AlertDialogDescription>
                  سيُحذف المترشح وعلاماته ونتيجته. لا يمكن التراجع عن هذا الإجراء.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>إلغاء</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-danger text-primary-fg hover:opacity-90"
                  onClick={() => deleteMutation.mutate({ data: { id: student.id } })}
                >
                  تأكيد الحذف
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <section className="grid items-start gap-4 xl:grid-cols-5">
        <Card className="min-w-0 xl:col-span-2">
          <h2 className="text-base font-semibold">البيانات الشخصية</h2>
          <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-muted">الجنس</dt>
              <dd className="mt-0.5">{genderLabel(student.gender)}</dd>
            </div>
            <div>
              <dt className="text-muted">تاريخ الميلاد</dt>
              <dd className="mt-0.5 tabular-nums">{student.birthDate}</dd>
            </div>
            <div>
              <dt className="text-muted">مكان الميلاد</dt>
              <dd className="mt-0.5">{student.birthPlace}</dd>
            </div>
            <div>
              <dt className="text-muted">الثانوية</dt>
              <dd className="mt-0.5">
                {student.schoolName}
                <span className="block text-muted">{student.wilaya}</span>
              </dd>
            </div>
          </dl>
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <MentionBadge mention={student.mention} decision={student.decision} average={student.average} />
            <DecisionBadge decision={student.decision} />
            {student.average != null ? (
              <span className="text-sm font-semibold tabular-nums">
                المعدل {formatScore(student.average)}
              </span>
            ) : null}
          </div>
        </Card>

        <Card className="min-w-0 overflow-hidden xl:col-span-3">
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="text-base font-semibold">كشف النقاط</h2>
              <p className="text-sm text-muted">
                العلامات من 0 إلى 20 · المعامل الإجمالي {student.totalCoefficient}
              </p>
            </div>
            <div className="text-sm">
              المعدل الحي{" "}
              <span className="font-semibold tabular-nums">
                {allFilled ? formatScore(liveAverage) : "—"}
              </span>
            </div>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>المادة</TableHead>
                <TableHead>المعامل</TableHead>
                <TableHead>العلامة</TableHead>
                <TableHead>النقاط</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {student.grades.map((grade) => {
                const raw = scores[grade.subjectId] ?? "";
                const score = raw === "" ? null : Number(raw);
                const points =
                  score != null && !Number.isNaN(score) ? score * grade.coefficient : null;
                return (
                  <TableRow key={grade.subjectId}>
                    <TableCell className="font-medium">{grade.nameAr}</TableCell>
                    <TableCell className="tabular-nums">{grade.coefficient}</TableCell>
                    <TableCell className="w-28">
                      <Input
                        inputMode="decimal"
                        min={0}
                        max={20}
                        step="0.25"
                        value={raw}
                        onChange={(e) =>
                          setScores((prev) => ({ ...prev, [grade.subjectId]: e.target.value }))
                        }
                        className="h-10 tabular-nums"
                      />
                    </TableCell>
                    <TableCell className="tabular-nums">{formatScore(points)}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <Button
            className="mt-4"
            disabled={saveMutation.isPending || !allFilled}
            onClick={() => {
              const grades = student.grades.map((g) => ({
                subjectId: g.subjectId,
                score: Number(scores[g.subjectId]),
              }));
              if (grades.some((g) => Number.isNaN(g.score) || g.score < 0 || g.score > 20)) {
                toast.error("أدخل علامات صحيحة بين 0 و 20");
                return;
              }
              saveMutation.mutate({ data: { studentId: student.id, grades } });
            }}
          >
            {saveMutation.isPending ? "جاري الحفظ…" : "حفظ العلامات وحسم النتيجة"}
          </Button>
        </Card>
      </section>

      <Card>
        <h2 className="mb-4 text-base font-semibold">تعديل الملف</h2>
        {streamsQuery.data && schoolsQuery.data ? (
          <StudentForm
            streams={streamsQuery.data}
            schools={schoolsQuery.data}
            initial={{
              firstName: student.firstName,
              lastName: student.lastName,
              birthDate: student.birthDate,
              birthPlace: student.birthPlace,
              gender: student.gender,
              schoolId: student.schoolId,
              streamId: student.streamId,
            }}
            submitLabel="تحديث البيانات"
            pending={updateMutation.isPending}
            onSubmit={(values) =>
              updateMutation.mutate({ data: { id: student.id, ...values } })
            }
          />
        ) : (
          <Skeleton className="h-32" />
        )}
      </Card>

      {student.decision === "ناجح" && student.certificateNumber ? (
        <div className="hidden lg:block">
          <CertificateDoc student={student} />
        </div>
      ) : null}
    </div>
  );
}
