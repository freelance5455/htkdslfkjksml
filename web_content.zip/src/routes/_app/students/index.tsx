"use client";

import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Search } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DecisionBadge, MentionBadge } from "@/components/mention-badge";
import { StudentForm } from "@/components/student-form";
import {
  createStudent,
  listSchools,
  listStreams,
  listStudents,
} from "@/lib/bac/server";
import { formatScore, fullName } from "@/lib/bac/calc";

export const Route = createFileRoute("/_app/students/")({
  loader: async () => {
    const [students, streams, schools] = await Promise.all([
      listStudents({ data: {} }),
      listStreams(),
      listSchools(),
    ]);
    return { students, streams, schools };
  },
  component: StudentsPage,
});

function StudentsPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const initial = Route.useLoaderData();
  const [q, setQ] = useState("");
  const [streamId, setStreamId] = useState<string>("all");
  const [decision, setDecision] = useState<string>("all");
  const [open, setOpen] = useState(false);

  const filters = {
    q: q.trim() || undefined,
    streamId: streamId === "all" ? undefined : Number(streamId),
    decision:
      decision === "all"
        ? undefined
        : (decision as "ناجح" | "راسب" | "قيد الإدخال"),
  };

  const unfiltered = !filters.q && !filters.streamId && !filters.decision;

  const studentsQuery = useQuery({
    queryKey: ["students", filters],
    queryFn: () => listStudents({ data: filters }),
    initialData: unfiltered ? initial.students : undefined,
  });
  const streamsQuery = useQuery({
    queryKey: ["streams"],
    queryFn: () => listStreams(),
    initialData: initial.streams,
  });
  const schoolsQuery = useQuery({
    queryKey: ["schools"],
    queryFn: () => listSchools(),
    initialData: initial.schools,
  });

  const createMutation = useMutation({
    mutationFn: createStudent,
    onSuccess: (created) => {
      toast.success(`تم تسجيل المترشح برقم ${created.examNumber}`);
      queryClient.invalidateQueries({ queryKey: ["students"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
      setOpen(false);
      void navigate({ to: "/students/$id", params: { id: String(created.id) } });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold">المترشحون</h1>
          <p className="mt-1 text-sm text-muted">سجل المترشحين لشهادة البكالوريا وإدارة ملفاتهم.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="size-4" />
              تسجيل مترشح
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>مترشح جديد</DialogTitle>
              <DialogDescription>
                يُولَّد رقم التسجيل تلقائياً. بعد الحفظ يمكن إدخال العلامات.
              </DialogDescription>
            </DialogHeader>
            {streamsQuery.data && schoolsQuery.data ? (
              <StudentForm
                streams={streamsQuery.data}
                schools={schoolsQuery.data}
                submitLabel="حفظ المترشح"
                pending={createMutation.isPending}
                onSubmit={(values) => createMutation.mutate({ data: values })}
              />
            ) : (
              <Skeleton className="h-40" />
            )}
          </DialogContent>
        </Dialog>
      </div>

      <Card className="p-4">
        <div className="grid gap-3 md:grid-cols-3">
          <div className="relative md:col-span-1">
            <Search className="pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-subtle" />
            <Input
              className="pr-9"
              placeholder="بحث بالاسم أو رقم التسجيل"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <Select value={streamId} onValueChange={setStreamId}>
            <SelectTrigger>
              <SelectValue placeholder="الشعبة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الشعب</SelectItem>
              {streamsQuery.data?.map((s) => (
                <SelectItem key={s.id} value={String(s.id)}>
                  {s.nameAr}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={decision} onValueChange={setDecision}>
            <SelectTrigger>
              <SelectValue placeholder="الحسم" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الحالات</SelectItem>
              <SelectItem value="ناجح">ناجح</SelectItem>
              <SelectItem value="راسب">راسب</SelectItem>
              <SelectItem value="قيد الإدخال">قيد الإدخال</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      <Card className="min-w-0 overflow-hidden p-0">
        {studentsQuery.isLoading ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-12" />
            ))}
          </div>
        ) : !studentsQuery.data?.length ? (
          <p className="p-8 text-center text-sm text-muted">لا يوجد مترشحون مطابقون للبحث.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>رقم التسجيل</TableHead>
                <TableHead>المترشح</TableHead>
                <TableHead>الشعبة</TableHead>
                <TableHead>الثانوية</TableHead>
                <TableHead>المعدل</TableHead>
                <TableHead>التقدير</TableHead>
                <TableHead>الحسم</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {studentsQuery.data.map((student) => (
                <TableRow
                  key={student.id}
                  className="cursor-pointer"
                  onClick={() =>
                    void navigate({ to: "/students/$id", params: { id: String(student.id) } })
                  }
                >
                  <TableCell className="font-medium tabular-nums">{student.examNumber}</TableCell>
                  <TableCell>{fullName(student.lastName, student.firstName)}</TableCell>
                  <TableCell>{student.streamName}</TableCell>
                  <TableCell className="max-w-[12rem] truncate">{student.schoolName}</TableCell>
                  <TableCell className="tabular-nums">{formatScore(student.average)}</TableCell>
                  <TableCell>
                    <MentionBadge mention={student.mention} decision={student.decision} />
                  </TableCell>
                  <TableCell>
                    <DecisionBadge decision={student.decision} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
}
