import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Money, PageHeader } from "@/components/layout/page";
import { reverseOperation, softDeleteOperation } from "@/lib/accounting/actions";
import { formatJalali, OP_LABELS } from "@/lib/accounting/format";
import { useInvalidateBooks, useOperations } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/operations")({ component: OperationsPage });

function OperationsPage() {
  const [q, setQ] = useState("");
  const { data = [], isLoading } = useOperations({ q });
  const invalidate = useInvalidateBooks();

  async function onDelete(id: string, locked: boolean) {
    if (locked) {
      toast.error("روز بسته است. فقط سند اصلاحی مجاز است.");
      return;
    }
    const reason = window.prompt("دلیل حذف منطقی؟");
    if (!reason) return;
    try {
      await softDeleteOperation({ data: { id, reason } });
      toast.success("حذف منطقی شد. ردپا در حسابرسی باقی ماند.");
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    }
  }

  async function onReverse(id: string) {
    const reason = window.prompt("دلیل سند برگشتی / اصلاحی؟");
    if (!reason) return;
    try {
      const res = await reverseOperation({ data: { id, reason } });
      toast.success(`سند اصلاحی ${res.journalNumber} صادر شد`);
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    }
  }

  return (
    <div>
      <PageHeader
        title="عملیات روزانه"
        description="هر ردیف یک رویداد عملیاتی است. سند دوبل به‌صورت خودکار ساخته می‌شود. حذف فیزیکی وجود ندارد."
        actions={
          <Link to="/operations/new" className="inline-flex h-11 items-center rounded-[10px] bg-gold px-4 text-sm text-navy">
            عملیات جدید
          </Link>
        }
      />
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجو در شماره، شرح، شخص…" className="mb-4 max-w-md" />
      <div className="overflow-x-auto rounded-[24px] border border-line bg-paper">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="text-xs text-muted">
            <tr>
              <th className="px-4 py-3 text-right font-medium">شماره</th>
              <th className="px-4 py-3 text-right font-medium">تاریخ</th>
              <th className="px-4 py-3 text-right font-medium">نوع</th>
              <th className="px-4 py-3 text-right font-medium">شخص</th>
              <th className="px-4 py-3 text-left font-medium">مبلغ</th>
              <th className="px-4 py-3 text-right font-medium">سند</th>
              <th className="px-4 py-3 text-right font-medium">وضعیت</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={8} className="px-4 py-10 text-center text-muted">
                  در حال بارگذاری…
                </td>
              </tr>
            ) : null}
            {data.map((op) => (
              <tr key={op.id} className="border-t border-line">
                <td className="px-4 py-3 font-medium text-navy">{op.number}</td>
                <td className="px-4 py-3">{formatJalali(op.opDate)}</td>
                <td className="px-4 py-3">{OP_LABELS[op.opType]}</td>
                <td className="px-4 py-3">{op.partyName ?? "—"}</td>
                <td className="px-4 py-3 text-left">
                  <Money value={op.amount} compact />
                </td>
                <td className="px-4 py-3">{op.journalNumber ?? "—"}</td>
                <td className="px-4 py-3">
                  <Badge tone={op.status === "posted" ? "ok" : op.status === "deleted" ? "danger" : "warn"}>
                    {op.status === "posted" ? "ثبت‌شده" : op.status === "deleted" ? "حذف منطقی" : "برگشت‌خورده"}
                  </Badge>
                  {op.dayStatus === "closed" ? (
                    <Badge tone="navy" className="mr-1">
                      روز بسته
                    </Badge>
                  ) : null}
                </td>
                <td className="px-4 py-3">
                  {op.status === "posted" ? (
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" onClick={() => onDelete(op.id, op.dayStatus === "closed")}>
                        حذف
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => onReverse(op.id)}>
                        اصلاحی
                      </Button>
                    </div>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
