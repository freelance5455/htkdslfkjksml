import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { PageHeader } from "@/components/layout/page";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { exportBackup } from "@/lib/accounting/actions";
import { downloadJson } from "@/lib/accounting/export";
import { useBootstrap } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app/settings")({ component: SettingsPage });

function SettingsPage() {
  const boot = useBootstrap();
  async function backup() {
    const data = await exportBackup();
    downloadJson(`MR-KHORASANI-Backup-${boot.data?.fiscalYear.code ?? "1405"}`, JSON.parse(data.payload));
    toast.success("پشتیبان دانلود شد");
  }
  return (
    <div>
      <PageHeader title="تنظیمات" description="شرکت، سال مالی، پشتیبان‌گیری و فضای ابری." />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h2 className="text-sm font-medium text-navy">شرکت</h2>
          <dl className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted">نام</dt>
              <dd>{boot.data?.companyName}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">برند</dt>
              <dd>{boot.data?.companyNameEn}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">سال مالی</dt>
              <dd>{boot.data?.fiscalYear.name}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">بازه</dt>
              <dd>
                {boot.data?.fiscalYear.start_date} — {boot.data?.fiscalYear.end_date}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">واحد پول</dt>
              <dd>ریال ایران</dd>
            </div>
          </dl>
        </Card>
        <Card>
          <h2 className="text-sm font-medium text-navy">پشتیبان و همگام‌سازی</h2>
          <p className="mt-2 text-sm text-muted">
            دفاتر روی فضای ابری (پایگاه داده امن) ذخیره می‌شوند. پشتیبان JSON شامل عملیات، اسناد، اشخاص و Audit Log است.
          </p>
          <Button className="mt-5" onClick={backup}>
            دانلود پشتیبان
          </Button>
        </Card>
        <Card className="lg:col-span-2">
          <h2 className="text-sm font-medium text-navy">نقش‌ها</h2>
          <p className="mt-2 text-sm text-muted">
            در این نسخه هر کاربر دفاتر مستقل خود را دارد (مدیر سیستم). نقش‌های حسابدار، صندوقدار و ناظر برای استقرار چندکاربره شرکت قابل گسترش است.
          </p>
        </Card>
      </div>
    </div>
  );
}
