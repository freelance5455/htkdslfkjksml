import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageIntro, Tag } from "@/components/page";
import { BOOK_TOPICS, BOOKS } from "@/data/books";
import { stripArabic } from "@/lib/utils";

export const Route = createFileRoute("/library/")({
  head: () => ({ meta: [{ title: "المكتبة الإسلامية — لأنه الله" }] }),
  component: LibraryPage,
});

function LibraryPage() {
  const [query, setQuery] = useState("");
  const [topic, setTopic] = useState("الكل");
  const [level, setLevel] = useState("الكل");
  const q = stripArabic(query);
  const list = useMemo(
    () => BOOKS.filter((book) => {
      const blob = stripArabic(`${book.title} ${book.author} ${book.summary}`);
      return (!q || blob.includes(q)) && (topic === "الكل" || book.topic === topic) && (level === "الكل" || book.level === level);
    }).sort((a, b) => a.title.localeCompare(b.title, "ar")),
    [level, q, topic],
  );

  return (
    <main>
      <PageIntro
        kicker="تعريفات لا ملفات مختلقة"
        title="المكتبة الإسلامية"
        lede="كتب في الأسماء والعقيدة والتزكية والتدبر. لا تنزيل هنا للكتب المحفوظة الحقوق، ولا روابط ملفات وهمية. إن وُجد بحث في أرشيف عام فهو بحث لا ملف نستضيفه."
      />
      <section className="mx-auto max-w-6xl px-4 py-8">
        <div className="grid gap-3 md:grid-cols-3">
          <input value={query} onChange={(event) => setQuery(event.target.value)} aria-label="بحث في الكتب" placeholder="العنوان أو المؤلف" className="rounded-full border border-line bg-surface px-4 py-3 md:col-span-1" />
          <select value={topic} onChange={(event) => setTopic(event.target.value)} aria-label="موضوع الكتاب" className="rounded-full border border-line bg-surface px-4 py-3">
            <option>الكل</option>
            {BOOK_TOPICS.map((item) => <option key={item}>{item}</option>)}
          </select>
          <select value={level} onChange={(event) => setLevel(event.target.value)} aria-label="المستوى" className="rounded-full border border-line bg-surface px-4 py-3">
            <option>الكل</option>
            <option>مبتدئ</option>
            <option>متوسط</option>
            <option>متقدم</option>
          </select>
        </div>
        {list.length === 0 ? <p className="mt-6">لا كتب مطابقة.</p> : null}
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {list.map((book) => (
            <Link key={book.id} to="/library/$id" params={{ id: book.id }} className="rounded-card border border-line bg-surface p-5">
              <div className="flex gap-2"><Tag>{book.topic}</Tag><Tag>{book.level}</Tag></div>
              <h2 className="mt-3 font-display text-3xl text-primary">{book.title}</h2>
              <p className="mt-2 text-sm text-muted">{book.author}</p>
              <p className="mt-3 line-clamp-3 text-sm leading-7">{book.summary}</p>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
