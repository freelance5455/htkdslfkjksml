import { createFileRoute, Link } from "@tanstack/react-router";
import { BackButton } from "@/components/back-button";
import { AppShell, TopBar } from "@/components/layout/app-shell";
import { CATEGORY_LABEL, libraryBooks } from "@/content/catalog";
import type { LibraryBook } from "@/content/types";

export const Route = createFileRoute("/library/")({ component: LibraryHome });

const ORDER: LibraryBook["category"][] = ["hadith", "aqeedah", "fiqh", "tajweed"];

function LibraryHome() {
  return (
    <AppShell>
      <TopBar title="المكتبة الشرعية" back={<BackButton href="/" />} />
      <p className="px-5 pt-3 text-xs leading-5 text-muted-foreground">
        المتون المعروضة نُقلت من مصادر مطبوعة أو من ويكي مصدر / السُّنة، ولم يُولَّد شيء منها. ما لم يُراجع نصه بعد يظهر للطبعة القادمة.
      </p>
      <div className="space-y-6 px-4 py-4">
        {ORDER.map((cat) => {
          const books = libraryBooks.filter((b) => b.category === cat);
          return (
            <section key={cat}>
              <h2 className="mb-2 text-sm font-semibold text-muted-foreground">{CATEGORY_LABEL[cat]}</h2>
              <ul className="grid gap-2">
                {books.map((b) => (
                  <li key={b.id}>
                    {b.comingSoon ? (
                      <div className="rounded-2xl bg-card px-4 py-3.5 opacity-70 shadow-[var(--shadow-border)]">
                        <p className="font-medium">{b.title}</p>
                        <p className="text-xs text-muted-foreground">{b.author} · يُضاف بعد مراجعة النص</p>
                      </div>
                    ) : (
                      <Link
                        to="/library/$bookId"
                        params={{ bookId: b.id }}
                        className="block rounded-2xl bg-card px-4 py-3.5 shadow-[var(--shadow-border)]"
                      >
                        <p className="font-medium">{b.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {b.author} · {b.blurb}
                        </p>
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </section>
          );
        })}
      </div>
    </AppShell>
  );
}
