import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ActionBar, Tag } from "@/components/page";
import { getBook } from "@/data/books";
import { useProgress } from "@/lib/progress";

export const Route = createFileRoute("/library/$id")({
  loader: ({ params }) => {
    const book = getBook(params.id);
    if (!book) throw notFound();
    return book;
  },
  head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `${loaderData.title} — المكتبة` : "كتاب" }] }),
  component: BookPage,
});

function BookPage() {
  const book = Route.useLoaderData();
  const fav = useProgress((state) => state.fav.includes(`book:${book.id}`));
  const toggleFav = useProgress((state) => state.toggleFav);
  const copy = `${book.title}\n${book.author}\n${book.summary}\nلا ملف تنزيل على هذه المنصة.`;

  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <Link to="/library" className="text-sm text-olive">المكتبة</Link>
      <div className="mt-4 flex gap-2"><Tag>{book.topic}</Tag><Tag>{book.level}</Tag></div>
      <h1 className="mt-3 font-display text-4xl text-primary">{book.title}</h1>
      <p className="mt-2 text-muted">{book.author} · {book.era}</p>
      <div className="mt-5"><ActionBar title={book.title} text={copy} urlPath={`/library/${book.id}`} /></div>
      <button type="button" onClick={() => toggleFav(`book:${book.id}`)} className="mt-3 rounded-full border border-line px-4 py-2 text-sm" aria-pressed={fav}>
        {fav ? "في المفضلة" : "أضف إلى المفضلة"}
      </button>
      <section className="mt-8">
        <h2 className="font-display text-3xl text-primary">ملخص تعليمي</h2>
        <p className="mt-2 text-sm text-olive">من إعداد المنصة، لا يغني عن قراءة الكتاب.</p>
        <p className="mt-3 leading-8">{book.summary}</p>
      </section>
      <section className="mt-6">
        <h2 className="font-display text-3xl text-primary">الناشر والتداول</h2>
        <p className="mt-3 leading-8">{book.publisher}</p>
        <p className="mt-3 leading-8">{book.access}</p>
      </section>
      <p className="mt-6 rounded-card border border-line bg-soft p-4 text-sm leading-7">
        التنزيل غير متاح لأن المنصة لا تملك حق نشر الملف. {book.url ? "يمكن البحث عن الطبعات العامة من الزر التالي، وهو بحث خارجي لا ملف بعينه." : "اطلب الطبعة الورقية أو الرقمية المشروعة."}
      </p>
      {book.url ? <a className="mt-4 inline-block rounded-full border border-line px-4 py-2" href={book.url} rel="noreferrer">بحث خارجي عن العنوان</a> : null}
    </main>
  );
}
