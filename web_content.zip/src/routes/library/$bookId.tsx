import { createFileRoute } from "@tanstack/react-router";
import { Heart, Minus, Plus, Share2, Volume2 } from "lucide-react";
import { useEffect, useMemo } from "react";
import { toast } from "sonner";
import { BackButton } from "@/components/back-button";
import { TextLink } from "@/components/text-link";
import { AppShell } from "@/components/layout/app-shell";
import { getBook } from "@/content/catalog";
import { audioEngine } from "@/lib/audio";
import { shareText } from "@/lib/share";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

type Search = { section?: string };

export const Route = createFileRoute("/library/$bookId")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    section: typeof s.section === "string" ? s.section : undefined,
  }),
  component: BookReader,
});

function BookReader() {
  const { bookId } = Route.useParams();
  const { section } = Route.useSearch();
  const book = getBook(bookId);
  const scale = useAppStore((s) => s.settings.fontScale);
  const setScale = useAppStore((s) => s.setFontScale);
  const setLastBook = useAppStore((s) => s.setLastBook);
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);
  const favorites = useAppStore((s) => s.favorites);
  const addBookmark = useAppStore((s) => s.addBookmark);

  const sections = book?.sections ?? [];
  const current = useMemo(() => {
    if (!sections.length) return null;
    return sections.find((s) => s.id === section) ?? sections[0];
  }, [sections, section]);

  useEffect(() => {
    if (book && current && !book.comingSoon) {
      setLastBook({ bookId: book.id, sectionId: current.id, updatedAt: Date.now() });
    }
  }, [book, current, setLastBook]);

  if (!book) {
    return (
      <AppShell>
        <p className="p-8">الكتاب غير موجود</p>
      </AppShell>
    );
  }

  if (book.comingSoon || !current) {
    return (
      <AppShell>
        <header className="flex items-center gap-2 px-2 py-2">
          <BackButton href="/library" />
          <h1 className="flex-1 text-center font-semibold">{book.title}</h1>
          <span className="size-11" />
        </header>
        <p className="px-5 pt-6 text-sm leading-7 text-muted-foreground">{book.source}</p>
      </AppShell>
    );
  }

  const idx = sections.findIndex((s) => s.id === current.id);
  const favId = `${book.id}:${current.id}`;
  const isFav = favorites.some((f) => f.id === favId);

  return (
    <AppShell>
      <header className="sticky top-0 z-20 border-b border-border bg-background/90 backdrop-blur-md">
        <div className="flex items-center gap-1 px-1 py-1">
          <BackButton href="/library" />
          <div className="min-w-0 flex-1 text-center">
            <h1 className="truncate text-sm font-semibold">{book.title}</h1>
            <p className="truncate text-[11px] text-muted-foreground">{current.title}</p>
          </div>
          <button type="button" className="tap-lg size-10" onClick={() => setScale(Math.max(0.85, scale - 0.1))}>
            <Minus className="mx-auto size-4" />
          </button>
          <button type="button" className="tap-lg size-10" onClick={() => setScale(Math.min(1.6, scale + 0.1))}>
            <Plus className="mx-auto size-4" />
          </button>
        </div>
      </header>

      <article className="bg-paper px-5 py-6 pb-40">
        <h2 className="mb-4 text-lg font-semibold text-accent">{current.title}</h2>
        <div
          className="whitespace-pre-wrap leading-8 text-ink"
          style={{ fontSize: `${0.7 + scale * 0.55}rem` }}
        >
          {current.body}
        </div>
        <p className="mt-8 border-t border-border pt-4 text-[11px] leading-5 text-muted-foreground">{book.source}</p>
      </article>

      <div className="sticky bottom-[calc(5.25rem+env(safe-area-inset-bottom))] z-20 mx-3 mb-2 flex gap-2 rounded-2xl border border-border bg-card p-2 shadow-[var(--shadow-border)]">
        <button
          type="button"
          className="flex h-11 flex-1 items-center justify-center gap-1 rounded-xl bg-surface text-xs"
          onClick={() => {
            const ok = audioEngine.speak(current.body.slice(0, 4000), current.title);
            if (!ok) toast("قراءة الجهاز غير متاحة");
          }}
        >
          <Volume2 className="size-4" /> استماع
        </button>
        <button
          type="button"
          className={cn("flex size-11 items-center justify-center rounded-xl bg-surface", isFav && "text-accent")}
          onClick={() =>
            toggleFavorite({
              id: favId,
              kind: book.category === "hadith" ? "hadith" : "mutn",
              title: `${book.title} — ${current.title}`,
              text: current.body.slice(0, 280),
              href: `/library/${book.id}?section=${current.id}`,
              meta: book.author,
            })
          }
        >
          <Heart className={cn("size-4", isFav && "fill-current")} />
        </button>
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-xl bg-surface"
          onClick={() => void shareText(current.title, current.body.slice(0, 800))}
        >
          <Share2 className="size-4" />
        </button>
        <button
          type="button"
          className="flex h-11 flex-1 items-center justify-center rounded-xl bg-accent text-xs text-accent-foreground"
          onClick={() =>
            addBookmark({
              id: favId,
              label: `${book.title} — ${current.title}`,
              href: `/library/${book.id}?section=${current.id}`,
            })
          }
        >
          علامة
        </button>
      </div>

      <nav className="flex justify-between px-4 pb-4 text-sm">
        <Pager
          disabled={idx <= 0}
          href={idx > 0 ? `/library/${book.id}?section=${sections[idx - 1].id}` : undefined}
          label="السابق"
        />
        <Pager
          disabled={idx >= sections.length - 1}
          href={idx < sections.length - 1 ? `/library/${book.id}?section=${sections[idx + 1].id}` : undefined}
          label="التالي"
        />
      </nav>
    </AppShell>
  );
}

function Pager({ href, label, disabled }: { href?: string; label: string; disabled: boolean }) {
  if (disabled || !href) return <span className="opacity-30">{label}</span>;
  return (
    <TextLink href={href} className="text-accent">
      {label}
    </TextLink>
  );
}
