import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageIntro, Tag } from "@/components/page";
import { HADITH_TOPICS, HADITHS } from "@/data/hadith";
import { stripArabic } from "@/lib/utils";

export const Route = createFileRoute("/hadith/")({
  head: () => ({ meta: [{ title: "السنة النبوية — لأنه الله" }] }),
  component: HadithPage,
});

function HadithPage() {
  const [query, setQuery] = useState("");
  const [topic, setTopic] = useState("الكل");
  const q = stripArabic(query);
  const list = useMemo(
    () => HADITHS.filter((item) => {
      const blob = stripArabic(`${item.text} ${item.source} ${item.explanation}`);
      return (!q || blob.includes(q)) && (topic === "الكل" || item.topics.includes(topic));
    }),
    [q, topic],
  );

  return (
    <main>
      <PageIntro
        kicker="نصوص بدرجة معلومة"
        title="السنة النبوية"
        lede="أحاديث في معرفة الله ومحبته ومراقبته وحسن الخلق. الصحيح والحسن مميزان، ولا يُعرض حديث ضعيف على أنه صحيح."
      />
      <section className="mx-auto max-w-6xl px-4 py-8">
        <div className="grid gap-3 md:grid-cols-[1fr_auto]">
          <input value={query} onChange={(event) => setQuery(event.target.value)} aria-label="بحث في الأحاديث" placeholder="ابحث في النص" className="rounded-full border border-line bg-surface px-4 py-3" />
          <select value={topic} onChange={(event) => setTopic(event.target.value)} aria-label="موضوع الحديث" className="rounded-full border border-line bg-surface px-4 py-3">
            <option>الكل</option>
            {HADITH_TOPICS.map((item) => <option key={item}>{item}</option>)}
          </select>
        </div>
        {list.length === 0 ? <p className="mt-6">لا توجد أحاديث مطابقة في المكتبة الحالية.</p> : null}
        <div className="mt-6 grid gap-4">
          {list.map((item) => (
            <Link key={item.id} to="/hadith/$id" params={{ id: item.id }} className="rounded-card border border-line bg-surface p-5">
              <div className="flex flex-wrap gap-2"><Tag>{item.grade}</Tag>{item.topics.map((topicName) => <Tag key={topicName}>{topicName}</Tag>)}</div>
              <p className="mt-3 font-display text-2xl leading-relaxed">{item.text}</p>
              <p className="mt-3 text-sm text-muted">{item.source} · {item.number}</p>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
