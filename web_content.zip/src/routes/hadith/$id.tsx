import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ActionBar, Tag } from "@/components/page";
import { getHadith } from "@/data/hadith";
import { useProgress } from "@/lib/progress";

export const Route = createFileRoute("/hadith/$id")({
  loader: ({ params }) => {
    const hadith = getHadith(params.id);
    if (!hadith) throw notFound();
    return hadith;
  },
  head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `حديث — ${loaderData.source}` : "حديث" }] }),
  component: HadithDetail,
});

function HadithDetail() {
  const hadith = Route.useLoaderData();
  const fav = useProgress((state) => state.fav.includes(`hadith:${hadith.id}`));
  const toggleFav = useProgress((state) => state.toggleFav);
  const copy = `${hadith.text}\n${hadith.source} (${hadith.number}) — ${hadith.grade}\n${hadith.url}`;

  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <Link to="/hadith" className="text-sm text-olive">كل الأحاديث</Link>
      <div className="mt-4 flex gap-2"><Tag>{hadith.grade}</Tag></div>
      <h1 className="mt-4 font-display text-3xl leading-relaxed text-primary">{hadith.text}</h1>
      <p className="mt-4 text-sm leading-7 text-muted">{hadith.source}<br />{hadith.number}<br />{hadith.gradeNote}</p>
      <div className="mt-5"><ActionBar title="حديث نبوي" text={copy} urlPath={`/hadith/${hadith.id}`} /></div>
      <button type="button" onClick={() => toggleFav(`hadith:${hadith.id}`)} className="mt-3 rounded-full border border-line px-4 py-2 text-sm" aria-pressed={fav}>
        {fav ? "في المفضلة" : "أضف إلى المفضلة"}
      </button>
      <section className="mt-8">
        <h2 className="font-display text-3xl text-primary">شرح مبسط</h2>
        <p className="mt-2 text-sm text-olive">صياغة تعليمية، لا شرح عالم بعينه.</p>
        <p className="mt-3 leading-8">{hadith.explanation}</p>
      </section>
      <section className="mt-6 rounded-card bg-soft p-5">
        <h2 className="font-display text-3xl text-primary">فائدة عملية</h2>
        <p className="mt-3 leading-8">{hadith.benefit}</p>
      </section>
      <a className="mt-6 inline-block text-primary" href={hadith.url} rel="noreferrer">فتح الحديث في Sunnah.com</a>
    </main>
  );
}
