import { Link, createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MagnitudeLab } from "@/components/magnitude";
import { MoonLab } from "@/components/moon-lab";
import { PolarisLab } from "@/components/polaris-lab";
import { SeasonLab } from "@/components/season-lab";
import { Choice, btnGhost, btnGold } from "@/components/ui";
import { LESSONS, lessonById } from "@/data/lessons";
import { useVespera } from "@/lib/store";

export const Route = createFileRoute("/lessons/$id")({ component: LessonPage });

function LessonPage() {
  const { id } = Route.useParams();
  const lesson = lessonById(id);
  const done = useVespera((s) => s.done);
  const mark = useVespera((s) => s.markLesson);
  const [picked, setPicked] = useState<number | null>(null);

  if (!lesson) {
    return (
      <div>
        <h1 className="text-4xl text-fg">That lesson isn't on the path.</h1>
        <Link to="/" className={`${btnGhost} mt-6`}>
          Back to the path
        </Link>
      </div>
    );
  }

  const index = LESSONS.findIndex((l) => l.id === lesson.id);
  const prev = LESSONS[index - 1];
  const next = LESSONS[index + 1];
  const complete = done.includes(lesson.id);
  const right = picked === lesson.check.answer;

  return (
    <article className="mx-auto max-w-2xl">
      <p className="text-xs uppercase tracking-widest text-gold">{lesson.kicker}</p>
      <h1 className="mt-2 text-4xl text-fg md:text-5xl">{lesson.title}</h1>
      <p className="mt-3 text-lg text-muted">{lesson.lede}</p>
      <p className="mt-2 text-xs uppercase tracking-widest text-faint">{lesson.minutes} min</p>

      <div className="mt-8 grid gap-8">
        {lesson.sections.map((section) => (
          <section key={section.heading}>
            <h2 className="text-2xl text-fg">{section.heading}</h2>
            <div className="mt-3 grid gap-3">
              {section.paragraphs.map((p) => (
                <p key={p} className="text-base leading-relaxed text-muted">
                  {p}
                </p>
              ))}
            </div>
          </section>
        ))}
      </div>

      {lesson.lab && (
        <div className="mt-8">
          {lesson.lab === "magnitude" && <MagnitudeLab />}
          {lesson.lab === "polaris" && <PolarisLab />}
          {lesson.lab === "moon" && <MoonLab />}
          {lesson.lab === "seasons" && <SeasonLab />}
        </div>
      )}

      {lesson.skyCon && (
        <p className="mt-8">
          <Link to="/sky" search={{ con: lesson.skyCon }} className={btnGhost}>
            See it on the chart
          </Link>
        </p>
      )}

      {lesson.id === "worlds" && (
        <p className="mt-8">
          <Link to="/sky" search={{}} className={btnGhost}>
            Find the planets on the chart
          </Link>
        </p>
      )}

      {lesson.id === "seasons" && (
        <p className="mt-4 text-sm text-muted">
          The distance lie has its own instrument.{" "}
          <Link to="/labs" hash="scale" className="text-gold">
            Open the scale lab
          </Link>
          .
        </p>
      )}

      <section className="mt-12 border-t border-line pt-8">
        <h2 className="text-2xl text-fg">Check</h2>
        <p className="mt-3 text-lg text-fg">{lesson.check.prompt}</p>
        <div className="mt-4 grid gap-3">
          {lesson.check.options.map((opt, i) => (
            <Choice
              key={opt}
              selected={picked === i}
              locked={picked != null}
              correct={picked != null && i === lesson.check.answer}
              wrong={picked === i && i !== lesson.check.answer}
              onClick={() => {
                if (picked == null) setPicked(i);
              }}
            >
              {opt}
            </Choice>
          ))}
        </div>
        {picked != null && (
          <div className="mt-4">
            <p className="text-sm text-fg">{lesson.check.why}</p>
            <div className="mt-4 flex flex-wrap gap-3">
              {!right && (
                <button type="button" className={btnGhost} onClick={() => setPicked(null)}>
                  Try again
                </button>
              )}
              {right && !complete && (
                <button type="button" className={btnGold} onClick={() => mark(lesson.id)}>
                  Mark complete
                </button>
              )}
              {(complete || right) && next && (
                <Link to="/lessons/$id" params={{ id: next.id }} className={complete || right ? btnGhost : btnGold}>
                  Next lesson
                </Link>
              )}
            </div>
          </div>
        )}
        {complete && picked == null && <p className="mt-4 text-sm text-gold">Marked complete.</p>}
      </section>

      <div className="mt-10 flex justify-between gap-3 text-sm">
        {prev ? (
          <Link to="/lessons/$id" params={{ id: prev.id }} className="text-muted hover:text-fg">
            {prev.title}
          </Link>
        ) : (
          <span />
        )}
        {next ? (
          <Link to="/lessons/$id" params={{ id: next.id }} className="text-muted hover:text-fg">
            {next.title}
          </Link>
        ) : (
          <Link to="/quiz" className="text-gold">
            Take the quiz
          </Link>
        )}
      </div>
    </article>
  );
}
