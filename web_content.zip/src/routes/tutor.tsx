import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppFrame, PageTitle } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { useEdu } from "@/components/edu-provider";
import { t } from "@/content/copy";
import { subjects } from "@/content/catalog";
import { askTutor, getTutorThread, type TutorMessage } from "@/lib/edu.functions";
import { tx, useLocale } from "@/lib/locale";

export const Route = createFileRoute("/tutor")({ component: TutorPage });

function TutorPage() {
  return (
    <AppFrame>
      <TutorBody />
    </AppFrame>
  );
}

function TutorBody() {
  const locale = useLocale((state) => state.locale);
  const { profile } = useEdu();
  const [thread, setThread] = useState<TutorMessage[]>([]);
  const [text, setText] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;
    getTutorThread()
      .then(setThread)
      .catch(() => setThread([]));
  }, [profile]);

  async function send(message: string) {
    const trimmed = message.trim();
    if (!trimmed) {
      setError(t(locale, "emptyTutor"));
      return;
    }
    setBusy(true);
    setError(null);
    setText("");
    const optimistic: TutorMessage = { id: Date.now(), role: "user", content: trimmed };
    setThread((current) => [...current, optimistic]);
    try {
      const result = await askTutor({
        data: { message: trimmed, subjectId: subjectId || undefined },
      });
      if (!result.ok) {
        setError(t(locale, "aiDown"));
        return;
      }
      setThread((current) => [
        ...current,
        { id: result.id || Date.now() + 1, role: "assistant", content: result.reply },
      ]);
    } catch {
      setError(t(locale, "aiDown"));
    } finally {
      setBusy(false);
    }
  }

  const suggestions = [t(locale, "suggestMath"), t(locale, "suggestScience"), t(locale, "suggestAm")];

  return (
    <div>
      <PageTitle title={t(locale, "tutorTitle")} lede={t(locale, "tutorLede")} />
      <label className="mb-4 block text-sm font-semibold">
        {t(locale, "studying")}
        <select
          value={subjectId}
          onChange={(event) => setSubjectId(event.target.value)}
          className="mt-1.5 h-11 w-full rounded-md border border-line bg-card px-3 text-base"
        >
          <option value="">{t(locale, "anySubject")}</option>
          {subjects.map((subject) => (
            <option key={subject.id} value={subject.id}>
              {tx(locale, subject.title)}
            </option>
          ))}
        </select>
      </label>
      <div className="space-y-3">
        {thread.length === 0 ? <p className="text-sm text-muted">{t(locale, "suggestions")}</p> : null}
        {thread.map((message) => (
          <article
            key={`${message.id}-${message.role}-${message.content.slice(0, 12)}`}
            className={
              message.role === "user"
                ? "ml-8 rounded-2xl bg-teal px-4 py-3 text-sm text-card"
                : "mr-6 rounded-2xl border border-line bg-card px-4 py-3 text-sm"
            }
          >
            {message.content}
          </article>
        ))}
        {busy ? <p className="text-sm text-muted">{t(locale, "thinking")}</p> : null}
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {suggestions.map((suggestion) => (
          <button
            key={suggestion}
            type="button"
            disabled={busy}
            onClick={() => void send(suggestion)}
            className="min-h-11 rounded-md border border-line bg-card px-3 text-left text-sm font-semibold"
          >
            {suggestion}
          </button>
        ))}
      </div>
      <form
        className="mt-4 flex flex-col gap-2 sm:flex-row"
        onSubmit={(event) => {
          event.preventDefault();
          void send(text);
        }}
      >
        <label className="sr-only" htmlFor="tutor-message">
          {t(locale, "tutorPlaceholder")}
        </label>
        <textarea
          id="tutor-message"
          value={text}
          onChange={(event) => setText(event.target.value)}
          placeholder={t(locale, "tutorPlaceholder")}
          rows={3}
          maxLength={800}
          className="min-h-24 w-full rounded-md border border-line bg-card px-3 py-2 text-base outline-none focus:border-teal"
        />
        <Button type="submit" disabled={busy}>
          {busy ? t(locale, "working") : t(locale, "send")}
        </Button>
      </form>
      {error ? <p className="mt-2 text-sm font-semibold text-danger">{error}</p> : null}
      <p className="mt-4 text-sm text-muted">{t(locale, "tutorDisclaimer")}</p>
    </div>
  );
}
