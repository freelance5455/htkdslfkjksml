import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Btn, Page } from "@/components/ui";
import { usePrefs } from "@/lib/prefs";
import { ayahsOnPage, loadQuran, type Quran } from "@/lib/quran";

export const Route = createFileRoute("/mushaf/$page")({ component: MushafPage });

function MushafPage() {
  const page = Math.min(604, Math.max(1, Number(Route.useParams().page) || 1));
  const [q, setQ] = useState<Quran | null>(null);
  const prefs = usePrefs();
  useEffect(() => {
    void loadQuran().then(setQ);
  }, []);
  const rows = q ? ayahsOnPage(q, page) : [];
  const ayahCount = rows.length;
  return (
    <Page title={`صفحة ${page}`} subtitle="عدّ المصحف المدني الشائع، 604 صفحات." back>
      <div className="mb-3 flex gap-2">
        {page > 1 && (
          <Link to="/mushaf/$page" params={{ page: String(page - 1) }} className="inline-flex min-h-11 items-center rounded-xl border border-line px-4 text-sm">
            السابقة
          </Link>
        )}
        {page < 604 && (
          <Link to="/mushaf/$page" params={{ page: String(page + 1) }} className="inline-flex min-h-11 items-center rounded-xl border border-line px-4 text-sm">
            التالية
          </Link>
        )}
        <Btn
          tone="gold"
          onClick={() => {
            prefs.markPage(page, ayahCount);
            if (rows[0]) {
              prefs.patch({ lastRead: { surah: rows[0].surah.n, ayah: rows[0].ayah.a, page } });
            }
          }}
        >
          أتممت هذه الصفحة
        </Btn>
      </div>
      <div className="space-y-3 rounded-2xl border border-line bg-card p-4">
        {rows.map((row, i) => (
          <p key={`${row.surah.n}-${row.ayah.a}`} className="quran-text" style={{ ["--quran-scale" as string]: String(prefs.fontScale) }}>
            {(i === 0 || rows[i - 1].surah.n !== row.surah.n) && (
              <span className="mb-2 block text-center font-sans text-base font-bold text-emerald">سورة {row.surah.ar}</span>
            )}
            <Link to="/quran/$surah" params={{ surah: String(row.surah.n) }} search={{ ayah: row.ayah.a }}>
              {row.ayah.t} <span className="text-gold">﴿{row.ayah.a}﴾</span>
            </Link>
          </p>
        ))}
        {!q && <p className="text-sm text-muted">يُحمّل المصحف…</p>}
      </div>
    </Page>
  );
}
