import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { formatDuration } from "@/lib/utils";
import { formatLongDate } from "@/lib/dates";
import { SESSION_TYPE_LABEL } from "@/lib/defaults";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/sessoes/$id")({
  component: SessionDetailPage,
});

function SessionDetailPage() {
  const { id } = Route.useParams();
  const session = useAppStore((s) => s.sessions.find((x) => x.id === id));

  if (!session) {
    return (
      <div>
        <p className="text-sm text-muted-foreground">Sessão não encontrada.</p>
        <Button asChild variant="outline" className="mt-4">
          <Link to="/sessoes">Voltar</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="animate-in fade-in duration-300">
      <Button asChild variant="ghost" size="sm" className="-ml-2 mb-3">
        <Link to="/sessoes">
          <ArrowLeft /> Sessões
        </Link>
      </Button>
      <PageHeader
        kicker={formatLongDate(session.date)}
        title={SESSION_TYPE_LABEL[session.type]}
        subtitle={session.title}
        action={<Badge tone="success">Concluído</Badge>}
      />
      <div className="mb-4 grid grid-cols-2 gap-3">
        <Card className="p-4">
          <p className="text-[11px] text-muted-foreground uppercase">Duração</p>
          <p className="font-mono text-lg font-semibold tabular-nums">
            {formatDuration(session.durationSec)}
          </p>
        </Card>
        <Card className="p-4">
          <p className="text-[11px] text-muted-foreground uppercase">Séries</p>
          <p className="font-mono text-lg font-semibold tabular-nums">
            {session.exercises.reduce((a, e) => a + e.completedSets, 0)}
            /
            {session.exercises.reduce((a, e) => a + e.sets, 0)}
          </p>
        </Card>
      </div>
      <div className="space-y-3">
        {session.exercises.map((ex) => (
          <Card key={ex.id} className="p-4">
            <div className="flex items-start justify-between gap-3">
              <h3 className="font-display font-semibold">{ex.name}</h3>
              <span className="text-xs tabular-nums text-primary">
                {ex.completedSets}/{ex.sets}
              </span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">
              {ex.sets} × {ex.reps}
              {ex.load ? ` · carga ${ex.load}` : ""}
            </p>
            {ex.setLogs.length > 0 ? (
              <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
                {ex.setLogs.map((log, i) => (
                  <li key={i}>
                    Série {i + 1}: {log.reps}
                    {log.load ? ` · ${log.load}` : ""}
                  </li>
                ))}
              </ul>
            ) : null}
          </Card>
        ))}
      </div>
      {session.notes ? (
        <Card className="mt-4 p-4">
          <p className="text-[11px] text-muted-foreground uppercase">Observações</p>
          <p className="mt-1 text-sm whitespace-pre-wrap">{session.notes}</p>
        </Card>
      ) : null}
    </div>
  );
}
