import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { CATALOG, lineCents } from "@/lib/catalog";
import { brl, formatDay, toISODate, waHref } from "@/lib/format";
import { isPlausiblePixKey } from "@/lib/pix";
import type { Booking, BookingStatus } from "@/lib/store";
import { useStore } from "@/lib/store";
import { useHydrated } from "@/lib/use-hydrated";
import { encodeVitrine } from "@/lib/vitrine";
import { Button } from "@/components/button";
import { cn } from "@/lib/cn";

export const Route = createFileRoute("/negocio")({
  component: NegocioPage,
});

const JOBS = [4, 6, 8, 10, 12];

function monthKey(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function weekSeries(bookings: Booking[]) {
  const now = new Date();
  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date(now);
    date.setDate(now.getDate() - (6 - index));
    const iso = toISODate(date);
    const cents = bookings
      .filter((booking) => (booking.status === "pago" || booking.status === "concluido") && booking.date === iso)
      .reduce((sum, booking) => sum + booking.amountCents, 0);
    return { label: `${date.getDate()}/${date.getMonth() + 1}`, reais: cents / 100 };
  });
}

function averageTicket(disabled: string[], prices: Record<string, number>) {
  const active = CATALOG.filter((service) => !disabled.includes(service.id));
  if (active.length === 0) return 0;
  const tickets = active.map((service) => {
    const values = service.options.map((option) => lineCents(option.id, option.cents, prices));
    return values[Math.min(1, values.length - 1)] ?? 0;
  });
  return Math.round(tickets.reduce((sum, value) => sum + value, 0) / tickets.length);
}

function MoneyInput({ cents, onCommit }: { cents: number; onCommit: (cents: number) => void }) {
  const [text, setText] = useState(() => (cents / 100).toFixed(2).replace(".", ","));
  return (
    <input
      value={text}
      inputMode="decimal"
      aria-label="Preço em reais"
      onChange={(event) => setText(event.target.value)}
      onBlur={() => {
        const parsed = Number(text.replace(/\./g, "").replace(",", "."));
        if (!Number.isFinite(parsed) || parsed < 0 || parsed > 5000) {
          setText((cents / 100).toFixed(2).replace(".", ","));
          return;
        }
        const next = Math.round(parsed * 100);
        onCommit(next);
        setText((next / 100).toFixed(2).replace(".", ","));
      }}
      className="h-11 w-28 rounded-md border border-line bg-surface px-2 text-right tabular-nums"
    />
  );
}

function RevenueChart({ bookings }: { bookings: Booking[] }) {
  const [ready, setReady] = useState(false);
  const data = useMemo(() => weekSeries(bookings), [bookings]);
  useEffect(() => setReady(true), []);
  if (!ready) return <div className="h-48 rounded-md bg-surface-2" />;
  return (
    <div className="h-48 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis dataKey="label" tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
          <Tooltip
            cursor={{ fill: "var(--color-surface-2)" }}
            formatter={(value) => brl(Math.round(Number(value) * 100))}
            contentStyle={{
              background: "var(--color-surface)",
              border: "1px solid var(--color-line)",
              borderRadius: 12,
              color: "var(--color-fg)",
            }}
          />
          <Bar dataKey="reais" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function NegocioPage() {
  const hydrated = useHydrated();
  const business = useStore((state) => state.business);
  const disabled = useStore((state) => state.disabled);
  const prices = useStore((state) => state.prices);
  const bookings = useStore((state) => state.bookings);
  const setBusiness = useStore((state) => state.setBusiness);
  const toggleService = useStore((state) => state.toggleService);
  const setPrice = useStore((state) => state.setPrice);
  const setStatus = useStore((state) => state.setStatus);
  const scheduleNext = useStore((state) => state.scheduleNext);
  const clearDemos = useStore((state) => state.clearDemos);
  const [tab, setTab] = useState<"agenda" | "precos" | "receber">("agenda");
  const [jobs, setJobs] = useState(6);
  const [notice, setNotice] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [pinTry, setPinTry] = useState("");
  const [nextNote, setNextNote] = useState("");

  useEffect(() => {
    if (!hydrated) return;
    if (!business.pin || sessionStorage.getItem("precisa-caixa") === "1") setUnlocked(true);
  }, [hydrated, business.pin]);

  const month = monthKey();
  const confirmed = bookings.filter(
    (booking) =>
      (booking.status === "pago" || booking.status === "concluido") && booking.date.startsWith(month),
  );
  const waiting = bookings.filter((booking) => booking.status === "aguardando");
  const received = confirmed.reduce((sum, booking) => sum + booking.amountCents, 0);
  const pending = waiting.reduce((sum, booking) => sum + booking.amountCents, 0);
  const ticket = averageTicket(disabled, prices);
  const hasDemo = bookings.some((booking) => booking.demo);
  const ordered = [...bookings].sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));

  function copy(text: string, ok: string) {
    void navigator.clipboard.writeText(text).then(
      () => {
        setNotice(ok);
        window.setTimeout(() => setNotice(""), 2000);
      },
      () => setNotice("Não consegui copiar. Selecione o link na barra do navegador."),
    );
  }

  function vitrineLink() {
    const token = encodeVitrine({
      pixKey: business.pixKey.trim(),
      receiverName: business.receiverName.trim(),
      city: business.city.trim(),
      whatsapp: business.whatsapp.trim(),
      disabled,
      prices,
    });
    return `${window.location.origin}/?v=${token}`;
  }

  if (!hydrated) {
    return (
      <main className="mx-auto max-w-5xl px-4 py-10">
        <h1 className="font-display text-4xl">Caixa</h1>
        <p className="mt-2 text-muted">Abrindo os pedidos deste aparelho…</p>
      </main>
    );
  }

  if (business.pin && !unlocked) {
    return (
      <main className="mx-auto max-w-md px-4 py-16">
        <h1 className="font-display text-4xl">Caixa trancada</h1>
        <p className="mt-2 text-sm text-muted">O código fica só neste navegador. Não é uma conta online.</p>
        <form
          className="mt-6 space-y-3"
          onSubmit={(event) => {
            event.preventDefault();
            if (pinTry === business.pin) {
              sessionStorage.setItem("precisa-caixa", "1");
              setUnlocked(true);
              setNotice("");
            } else {
              setNotice("Código errado.");
            }
          }}
        >
          <input
            value={pinTry}
            onChange={(event) => setPinTry(event.target.value.replace(/\D/g, "").slice(0, 4))}
            inputMode="numeric"
            className="h-12 w-full rounded-md border border-line bg-surface px-3 tracking-widest"
            placeholder="4 dígitos"
          />
          <Button type="submit">Abrir</Button>
          {notice ? <p className="text-sm font-semibold text-accent">{notice}</p> : null}
        </form>
      </main>
    );
  }

  const pixOk = isPlausiblePixKey(business.pixKey);
  const phoneOk = business.whatsapp.replace(/\D/g, "").length >= 10;

  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      <p className="text-sm font-semibold tracking-wide text-primary uppercase">Seu ofício</p>
      <h1 className="mt-2 font-display text-4xl sm:text-5xl">Caixa</h1>
      <p className="mt-3 max-w-2xl text-muted">
        Isto não é aposta nem rendimento automático. É a agenda de serviço que as pessoas já pagam. O PIX cai na sua
        chave. Este site não vê o seu banco e não segura o valor.
      </p>

      {hasDemo ? (
        <div className="mt-6 flex flex-col gap-3 rounded-lg border border-line bg-surface p-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm">
            Os pedidos marcados como exemplo não são dinheiro seu. Servem para ver a agenda funcionando.
          </p>
          <Button variant="surface" onClick={clearDemos}>
            Apagar exemplos
          </Button>
        </div>
      ) : null}

      <div className="mt-6 flex gap-2 overflow-x-auto">
        {(
          [
            ["agenda", "Agenda"],
            ["precos", "Preços"],
            ["receber", "Receber"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={cn(
              "min-h-11 shrink-0 rounded-md px-4 text-sm font-semibold",
              tab === id ? "bg-primary text-primary-fg" : "bg-surface text-fg",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "agenda" ? (
        <div className="mt-6 space-y-6">
          <div className="grid gap-3 sm:grid-cols-3">
            <article className="rounded-lg border border-line bg-surface p-4">
              <p className="text-sm text-muted">Confirmado neste mês</p>
              <p className="mt-1 font-display text-3xl tabular-nums">{brl(received)}</p>
            </article>
            <article className="rounded-lg border border-line bg-surface p-4">
              <p className="text-sm text-muted">Ainda sem PIX marcado</p>
              <p className="mt-1 font-display text-3xl tabular-nums">{brl(pending)}</p>
            </article>
            <article className="rounded-lg border border-line bg-surface p-4">
              <p className="text-sm text-muted">Serviços pagos no mês</p>
              <p className="mt-1 font-display text-3xl tabular-nums">{confirmed.length}</p>
            </article>
          </div>

          <section className="rounded-lg border border-line bg-surface p-4">
            <h2 className="font-display text-2xl">Últimos 7 dias</h2>
            <p className="text-sm text-muted">Só entra o que você marcou como pago ou concluído.</p>
            <RevenueChart bookings={bookings} />
          </section>

          <section className="rounded-lg border border-line bg-surface-2 p-4">
            <h2 className="font-display text-2xl">Se a semana encher</h2>
            <p className="mt-1 text-sm text-muted">
              Ticket médio destes preços: {brl(ticket)}. Conta grosseira, antes de deslocamento e material.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {JOBS.map((count) => (
                <button
                  key={count}
                  type="button"
                  aria-pressed={jobs === count}
                  onClick={() => setJobs(count)}
                  className={cn(
                    "min-h-11 rounded-md px-3 text-sm font-semibold",
                    jobs === count ? "bg-primary text-primary-fg" : "bg-surface",
                  )}
                >
                  {count}/sem
                </button>
              ))}
            </div>
            <p className="mt-4 font-display text-3xl tabular-nums">{brl(ticket * jobs * 4)} no mês</p>
            <p className="mt-1 text-sm text-muted">
              Cerca de {jobs * 3} horas por semana. É ofício: alguém pede, você vai, o PIX cai.
            </p>
          </section>

          <section className="space-y-3">
            <div className="flex items-center justify-between gap-3">
              <h2 className="font-display text-2xl">Pedidos neste aparelho</h2>
              <Link to="/agendar" className="text-sm font-semibold text-primary">
                Anotar um serviço
              </Link>
            </div>
            {ordered.length === 0 ? (
              <p className="text-sm text-muted">Nada ainda. Quando um cliente agendar aqui, o pedido aparece.</p>
            ) : (
              ordered.map((booking) => (
                <article key={booking.id} className="rounded-lg border border-line bg-surface p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold">
                        {booking.serviceName}
                        {booking.demo ? <span className="ml-2 text-xs font-semibold text-muted">exemplo</span> : null}
                      </p>
                      <p className="text-sm text-muted">
                        {formatDay(booking.date)} · {booking.time} · {booking.customerName} · {booking.neighborhood}
                      </p>
                      <p className="text-sm">{booking.optionLabel}</p>
                      {booking.customerSaidPaid && booking.status === "aguardando" ? (
                        <p className="mt-1 text-sm font-semibold text-accent">Cliente avisou que pagou. Confira no banco.</p>
                      ) : null}
                    </div>
                    <p className="font-display text-2xl tabular-nums">{brl(booking.amountCents)}</p>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {booking.status === "aguardando" ? (
                      <Button onClick={() => setStatus(booking.id, "pago")}>Caiu o PIX</Button>
                    ) : null}
                    {booking.status === "pago" ? (
                      <Button onClick={() => setStatus(booking.id, "concluido")}>Serviço feito</Button>
                    ) : null}
                    {booking.status !== "cancelado" && booking.status !== "concluido" ? (
                      <Button variant="danger" onClick={() => setStatus(booking.id, "cancelado" as BookingStatus)}>
                        Cancelar
                      </Button>
                    ) : null}
                    {booking.weekly && booking.status === "concluido" ? (
                      <Button
                        variant="surface"
                        onClick={() => {
                          const next = scheduleNext(booking.id);
                          setNextNote(next ? `Próximo marcado: ${next.id}` : "O horário da outra semana já está cheio.");
                        }}
                      >
                        Semana que vem
                      </Button>
                    ) : null}
                    <Link to="/pedido/$id" params={{ id: booking.id }} className="inline-flex min-h-11 items-center px-2 text-sm font-semibold">
                      Ver cobrança
                    </Link>
                    {waHref(booking.phone, `Olá ${booking.customerName}, sobre o serviço ${booking.serviceName} (${booking.id}).`) ? (
                      <a
                        className="inline-flex min-h-11 items-center px-2 text-sm font-semibold"
                        href={waHref(
                          booking.phone,
                          `Olá ${booking.customerName}, sobre ${booking.serviceName} em ${formatDay(booking.date)} às ${booking.time}. Valor ${brl(booking.amountCents)}.`,
                        )}
                        target="_blank"
                        rel="noreferrer"
                      >
                        Chamar cliente
                      </a>
                    ) : null}
                  </div>
                </article>
              ))
            )}
            {nextNote ? <p className="text-sm font-semibold">{nextNote}</p> : null}
          </section>
        </div>
      ) : null}

      {tab === "precos" ? (
        <div className="mt-6 space-y-4">
          <p className="text-sm text-muted">
            Ajuste o que você realmente cobra. O link da vitrine leva estes preços junto.
          </p>
          {CATALOG.map((service) => {
            const off = disabled.includes(service.id);
            return (
              <section key={service.id} className="rounded-lg border border-line bg-surface p-4">
                <div className="flex items-center justify-between gap-3">
                  <h2 className="font-display text-2xl">{service.name}</h2>
                  <button type="button" className="min-h-11 text-sm font-semibold text-primary" onClick={() => toggleService(service.id)}>
                    {off ? "Ativar" : "Pausar"}
                  </button>
                </div>
                <div className={cn("mt-3 space-y-3", off && "opacity-50")}>
                  {[...service.options, ...service.extras].map((line) => (
                    <div key={line.id} className="flex items-center justify-between gap-3">
                      <span className="text-sm">{line.label}</span>
                      <MoneyInput
                        cents={lineCents(line.id, line.cents, prices)}
                        onCommit={(cents) => setPrice(line.id, cents)}
                      />
                    </div>
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      ) : null}

      {tab === "receber" ? (
        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          <form className="space-y-3 rounded-lg border border-line bg-surface p-4" onSubmit={(event) => event.preventDefault()}>
            <h2 className="font-display text-2xl">Para onde o PIX cai</h2>
            <label className="block text-sm font-semibold">
              Nome que aparece no banco
              <input
                value={business.receiverName}
                onChange={(event) => setBusiness({ receiverName: event.target.value.slice(0, 40) })}
                className="mt-1 h-12 w-full rounded-md border border-line bg-bg px-3 font-normal"
                placeholder="Ana Souza"
              />
            </label>
            <label className="block text-sm font-semibold">
              Cidade
              <input
                value={business.city}
                onChange={(event) => setBusiness({ city: event.target.value.slice(0, 30) })}
                className="mt-1 h-12 w-full rounded-md border border-line bg-bg px-3 font-normal"
                placeholder="Recife"
              />
            </label>
            <label className="block text-sm font-semibold">
              Chave PIX
              <input
                value={business.pixKey}
                onChange={(event) => setBusiness({ pixKey: event.target.value.trim().slice(0, 77) })}
                className="mt-1 h-12 w-full rounded-md border border-line bg-bg px-3 font-normal"
                placeholder="seu@email.com"
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
              />
            </label>
            <label className="block text-sm font-semibold">
              WhatsApp com DDD
              <input
                value={business.whatsapp}
                onChange={(event) => setBusiness({ whatsapp: event.target.value.slice(0, 20) })}
                className="mt-1 h-12 w-full rounded-md border border-line bg-bg px-3 font-normal"
                inputMode="tel"
                placeholder="11988887777"
              />
            </label>
            <p className="text-sm text-muted">
              {pixOk ? "Chave pronta para gerar QR." : "Use e-mail, telefone com DDD, CPF ou chave aleatória, sem espaço."}{" "}
              {phoneOk ? "Pedidos de outros celulares podem chegar neste WhatsApp." : "Sem WhatsApp, o cliente não consegue te mandar o pedido."}
            </p>
            <label className="block text-sm font-semibold">
              Código da caixa neste aparelho
              <input
                value={business.pin}
                onChange={(event) => {
                  const pin = event.target.value.replace(/\D/g, "").slice(0, 4);
                  setBusiness({ pin });
                  if (pin.length === 4) sessionStorage.setItem("precisa-caixa", "1");
                }}
                className="mt-1 h-12 w-full rounded-md border border-line bg-bg px-3 font-normal tracking-widest"
                inputMode="numeric"
                placeholder="opcional, 4 dígitos"
              />
            </label>
            {business.pin ? (
              <button
                type="button"
                className="text-sm font-semibold text-muted"
                onClick={() => {
                  sessionStorage.removeItem("precisa-caixa");
                  setUnlocked(false);
                }}
              >
                Trancar agora
              </button>
            ) : null}
          </form>

          <section className="rounded-lg border border-line bg-surface p-4">
            <h2 className="font-display text-2xl">Como começa a entrar dinheiro</h2>
            <ol className="mt-3 list-decimal space-y-2 pl-4 text-sm">
              <li>Preencha nome, cidade, chave PIX e WhatsApp.</li>
              <li>Copie o texto e mande para quem já te pede as coisas, ou publique.</li>
              <li>A pessoa escolhe o serviço, paga o QR e te manda o pedido no WhatsApp.</li>
              <li>Confira nome e valor no app do banco antes de sair.</li>
              <li>Marque “Caiu o PIX” na agenda deste aparelho para ver o mês.</li>
            </ol>
            <div className="mt-4 flex flex-col gap-2">
              <Button
                disabled={!pixOk}
                onClick={() => {
                  const link = vitrineLink();
                  const text = `Precisa de limpeza, reparo, aula ou alguém em casa? Preço fechado antes, PIX direto: ${link}`;
                  copy(text, "Texto copiado.");
                }}
              >
                Copiar texto para divulgar
              </Button>
              <Button
                variant="surface"
                disabled={!pixOk}
                onClick={() => copy(vitrineLink(), "Link copiado.")}
              >
                Copiar só o link
              </Button>
              {notice ? <p className="text-sm font-semibold">{notice}</p> : null}
              {!pixOk ? <p className="text-sm text-muted">Coloque a chave PIX para liberar o link.</p> : null}
            </div>
          </section>
        </div>
      ) : null}
    </main>
  );
}
