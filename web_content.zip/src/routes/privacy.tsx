import { createFileRoute } from "@tanstack/react-router";
import { PageIntro } from "@/components/page";

export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [{ title: "الخصوصية — لأنه الله" }] }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <main>
      <PageIntro kicker="بياناتك تبقى عندك" title="الخصوصية" lede="لا حسابات، ولا إرسال لنماذج إلى خادم هذه المنصة." />
      <article className="mx-auto max-w-3xl space-y-4 px-4 py-8 leading-8">
        <p>يُحفظ محليًا في متصفحك: المظهر، إغلاق المقدمة، الأسماء التي علّمت قراءتها، قائمة المراجعة، المفضلة، تكرار البطاقات، خطوة اليوم، وآخر نتيجة اختبار.</p>
        <p>مفتاح التخزين: li-annahu-progress وli-annahu-theme وli-annahu-intro. يمكنك مسحها من إعدادات المتصفح.</p>
        <p>نموذج الإبلاغ لا يُرسل ولا يُخزَّن. لا تُجمع بيانات أطفال ولا صورهم.</p>
        <p>الروابط الخارجية، مثل موقع الوزارة ويوتيوب ونماذجها، لها سياساتها الخاصة. مشغّل يوتيوب لا يُحمَّل إلا في صفحة الوسائط.</p>
      </article>
    </main>
  );
}
