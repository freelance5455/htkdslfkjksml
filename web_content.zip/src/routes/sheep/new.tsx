import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { SheepForm } from "@/components/forms";

export const Route = createFileRoute("/sheep/new")({
  component: NewSheepPage,
});

function NewSheepPage() {
  const navigate = useNavigate();
  return (
    <AppShell
      title="رأس جديد"
      backTo="/flock"
      action={
        <button type="submit" form="sheep-form" className="text-sm font-medium">
          حفظ
        </button>
      }
    >
      <SheepForm
        onSaved={(id) => {
          void navigate({ to: "/sheep/$id", params: { id } });
        }}
      />
    </AppShell>
  );
}
