import { useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { SheepBadges } from "@/components/sheep-bits";
import { BreedingForm, HealthForm, LambingForm, SheepForm } from "@/components/forms";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Confirm } from "@/components/ui/confirm";
import { Field } from "@/components/field";
import {
  ageLabel,
  daysFromToday,
  daysLabel,
  formatDate,
  formatInt,
  formatKg,
  HEALTH_KIND_LABEL,
  inHerd,
  isLamb,
  sexLabel,
  sheepName,
  todayIso,
} from "@/lib/flock/logic";
import { useFlock, useHydrated } from "@/lib/flock/store";

export const Route = createFileRoute("/sheep/$id")({
  component: SheepPage,
});

type Panel = "edit" | "weight" | "health" | "breed" | "lamb" | null;
type Ask = "sold" | "dead" | "delete" | "lost" | null;

function SheepPage() {
  const { id } = Route.useParams();
  const navigate = Route.useNavigate();
  const hydrated = useHydrated();
  const sheep = useFlock((s) => s.sheep);
  const breeding = useFlock((s) => s.breeding);
  const health = useFlock((s) => s.health);
  const weights = useFlock((s) => s.weights);
  const setStatus = useFlock((s) => s.setStatus);
  const removeSheep = useFlock((s) => s.removeSheep);
  const addWeight = useFlock((s) => s.addWeight);
  const removeWeight = useFlock((s) => s.removeWeight);
  const removeHealth = useFlock((s) => s.removeHealth);
  const markLost = useFlock((s) => s.markLost);
  const removeBreeding = useFlock((s) => s.removeBreeding);
  const animal = sheep.find((s) => s.id === id);
  const [panel, setPanel] = useState<Panel>(null);
  const [ask, setAsk] = useState<Ask>(null);
  const [weightDate, setWeightDate] = useState(todayIso());
  const [weightValue, setWeightValue] = useState("");
  const [weightError, setWeightError] = useState<string | null>(null);

  if (!hydrated) {
    return (
      <AppShell title="…" backTo="/flock">
        <p className="text-sm text-muted-foreground">يُفتح السجل…</p>
      </AppShell>
    );
  }

  if (!animal) {
    return (
      <AppShell title="غير موجود" backTo="/flock">
        <p className="text-sm text-muted-foreground">هذا الرأس ليس في السجل.</p>
      </AppShell>
    );
  }

  const young = isLamb(animal);
  const herd = inHerd(animal);
  const pending = breeding.find(
    (b) => b.eweId === animal.id && b.result === "pending",
  );
  const history = breeding
    .filter((b) => b.eweId === animal.id || b.ramId === animal.id)
    .slice()
    .sort((a, b) => (a.matingDate < b.matingDate ? 1 : -1));
  const animalHealth = health
    .filter((h) => h.sheepId === animal.id)
    .slice()
    .sort((a, b) => (a.date < b.date ? 1 : -1));
  const animalWeights = weights
    .filter((w) => w.sheepId === animal.id)
    .slice()
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
  const spark = animalWeights.slice().sort((a, b) => a.date.localeCompare(b.date));
  const dam = sheep.find((s) => s.id === animal.damId);
  const sire = sheep.find((s) => s.id === animal.sireId);
  const offspring = sheep.filter(
    (s) => s.damId === animal.id || s.sireId === animal.id,
  );

  function saveWeight(e: FormEvent) {
    e.preventDefault();
    const kg = Number(weightValue.replace(",", "."));
    const result = addWeight(animal!.id, weightDate, kg);
    if ("error" in result) {
      setWeightError(result.error);
      return;
    }
    setWeightValue("");
    setWeightError(null);
    setPanel(null);
  }

  return (
    <AppShell title={animal.tag} backTo="/flock">
      {panel === "edit" ? (
        <SheepForm sheepId={animal.id} onSaved={() => setPanel(null)} />
      ) : (
        <div className="flex flex-col gap-5">
          {!herd ? (
            <p className="rounded-2xl border border-border px-4 py-3 text-sm text-muted-foreground">
              هذا الرأس خارج القطيع ({animal.status === "sold" ? "مبيع" : "نافق"}).
            </p>
          ) : null}

          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-3xl font-semibold break-all tabular-nums tracking-tight">
                {animal.tag}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                {[sexLabel(animal.sex, young), animal.name, animal.breed]
                  .filter(Boolean)
                  .join(" · ")}
              </p>
            </div>
            <SheepBadges sheep={animal} breeding={breeding} />
          </div>

          <Card className="grid grid-cols-2 gap-4">
            <Fact label="العمر" value={ageLabel(animal.birthDate)} />
            <Fact label="الوزن" value={formatKg(animal.weightKg)} />
            <Fact label="الحظيرة" value={animal.pen || "—"} />
            <Fact label="الميلاد" value={formatDate(animal.birthDate)} />
          </Card>

          {animal.notes ? (
            <p className="text-sm leading-normal whitespace-pre-wrap">{animal.notes}</p>
          ) : null}

          <div className="flex flex-wrap gap-3 text-sm">
            {dam ? (
              <Link to="/sheep/$id" params={{ id: dam.id }} className="text-muted-foreground">
                الأم {sheepName(dam, "")}
              </Link>
            ) : null}
            {sire ? (
              <Link to="/sheep/$id" params={{ id: sire.id }} className="text-muted-foreground">
                الأب {sheepName(sire, "")}
              </Link>
            ) : null}
          </div>

          {pending ? (
            <Card>
              <p className="text-sm text-muted-foreground">حمل قائم</p>
              <p className="mt-1 font-medium">
                {daysLabel(daysFromToday(pending.expectedDate))}
              </p>
              <p className="text-sm text-muted-foreground">
                تلقيح {formatDate(pending.matingDate)} · تُنتظر{" "}
                {formatDate(pending.expectedDate)}
              </p>
            </Card>
          ) : null}

          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" onClick={() => setPanel("weight")}>
              تسجيل وزن
            </Button>
            <Button variant="outline" onClick={() => setPanel("health")}>
              علاج أو تطعيم
            </Button>
            {animal.sex === "ewe" && herd && !pending ? (
              <Button variant="outline" onClick={() => setPanel("breed")}>
                تلقيح
              </Button>
            ) : null}
            {pending ? (
              <Button onClick={() => setPanel("lamb")}>تسجيل ولادة</Button>
            ) : null}
            <Button variant="ghost" onClick={() => setPanel("edit")}>
              تعديل البيانات
            </Button>
          </div>

          {panel === "weight" ? (
            <Card>
              <form onSubmit={saveWeight} className="flex flex-col gap-3">
                <Field label="التاريخ" htmlFor="w-date" error={weightError ?? undefined}>
                  <Input
                    id="w-date"
                    type="date"
                    value={weightDate}
                    onChange={(e) => setWeightDate(e.target.value)}
                  />
                </Field>
                <Field label="الوزن كغ" htmlFor="w-kg">
                  <Input
                    id="w-kg"
                    inputMode="decimal"
                    value={weightValue}
                    onChange={(e) => setWeightValue(e.target.value)}
                    required
                  />
                </Field>
                <Button type="submit">حفظ الوزن</Button>
              </form>
            </Card>
          ) : null}
          {panel === "health" ? (
            <Card>
              <HealthForm
                defaultSheepId={animal.id}
                onDone={() => setPanel(null)}
              />
            </Card>
          ) : null}
          {panel === "breed" ? (
            <Card>
              <BreedingForm
                defaultEweId={animal.id}
                onDone={() => setPanel(null)}
              />
            </Card>
          ) : null}
          {panel === "lamb" && pending ? (
            <Card>
              <LambingForm breedingId={pending.id} onDone={() => setPanel(null)} />
            </Card>
          ) : null}

          <section className="flex flex-col gap-2">
            <h2 className="text-sm font-medium text-muted-foreground">الأوزان</h2>
            {spark.length >= 2 ? <Spark points={spark} /> : null}
            {animalWeights.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا أوزان مسجلة.</p>
            ) : (
              animalWeights.map((w) => (
                <div key={w.id} className="flex items-center justify-between text-sm">
                  <span className="tabular-nums">
                    {formatDate(w.date)} · {formatKg(w.kg)}
                  </span>
                  <button
                    type="button"
                    className="text-muted-foreground"
                    onClick={() => removeWeight(w.id)}
                  >
                    حذف
                  </button>
                </div>
              ))
            )}
          </section>

          <section className="flex flex-col gap-2">
            <h2 className="text-sm font-medium text-muted-foreground">الصحة</h2>
            {animalHealth.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا سجلات لهذا الرأس.</p>
            ) : (
              animalHealth.map((h) => (
                <div key={h.id} className="flex items-start justify-between gap-3 text-sm">
                  <span>
                    <span className="block font-medium">{h.title}</span>
                    <span className="text-muted-foreground">
                      {HEALTH_KIND_LABEL[h.kind]} · {formatDate(h.date)}
                    </span>
                  </span>
                  <button
                    type="button"
                    className="text-muted-foreground"
                    onClick={() => removeHealth(h.id)}
                  >
                    حذف
                  </button>
                </div>
              ))
            )}
          </section>

          <section className="flex flex-col gap-2">
            <h2 className="text-sm font-medium text-muted-foreground">التناسل</h2>
            {history.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا تلقيح مرتبط.</p>
            ) : (
              history.map((b) => {
                const otherId = b.eweId === animal.id ? b.ramId : b.eweId;
                const other = sheep.find((s) => s.id === otherId);
                const label =
                  b.result === "pending"
                    ? "قائم"
                    : b.result === "lambed"
                      ? `ولادة ${formatInt(b.lambCount ?? 0)}`
                      : "مفقود";
                return (
                  <div key={b.id} className="text-sm">
                    <p className="font-medium">
                      {formatDate(b.matingDate)} · {label}
                    </p>
                    <p className="text-muted-foreground">
                      {b.eweId === animal.id ? "الكبش" : "النعجة"}{" "}
                      {other ? sheepName(other, "") : "غير محدد"}
                      {b.result === "pending"
                        ? ` · ${formatDate(b.expectedDate)}`
                        : ""}
                    </p>
                    {b.result !== "pending" ? (
                      <button
                        type="button"
                        className="mt-1 text-muted-foreground"
                        onClick={() => removeBreeding(b.id)}
                      >
                        حذف
                      </button>
                    ) : null}
                  </div>
                );
              })
            )}
            {offspring.length > 0 ? (
              <div className="flex flex-col gap-1">
                {offspring.map((child) => (
                  <Link
                    key={child.id}
                    to="/sheep/$id"
                    params={{ id: child.id }}
                    className="text-sm text-muted-foreground"
                  >
                    مولود {child.tag}
                  </Link>
                ))}
              </div>
            ) : null}
          </section>

          <div className="flex flex-col gap-2 border-t border-border pt-4">
            {herd ? (
              <>
                <Button
                  variant="outline"
                  onClick={() =>
                    setStatus(animal.id, animal.status === "sick" ? "active" : "sick")
                  }
                >
                  {animal.status === "sick" ? "تعليم سليم" : "تعليم مريض"}
                </Button>
                <Button variant="outline" onClick={() => setAsk("sold")}>
                  تسجيل بيع
                </Button>
                <Button variant="outline" onClick={() => setAsk("dead")}>
                  تسجيل نفوق
                </Button>
              </>
            ) : (
              <Button variant="outline" onClick={() => setStatus(animal.id, "active")}>
                إعادة إلى القطيع
              </Button>
            )}
            {pending ? (
              <Button variant="ghost" onClick={() => setAsk("lost")}>
                الحمل لم يكتمل
              </Button>
            ) : null}
            <Button variant="ghost" onClick={() => setAsk("delete")}>
              حذف من السجل
            </Button>
          </div>
        </div>
      )}

      <Confirm
        open={ask === "sold"}
        onOpenChange={(open) => !open && setAsk(null)}
        title="تسجيل البيع؟"
        body="يخرج الرأس من تعداد الحظيرة ويبقى في الأرشيف."
        confirmLabel="بيع"
        onConfirm={() => {
          setStatus(animal.id, "sold");
          setAsk(null);
        }}
      />
      <Confirm
        open={ask === "dead"}
        onOpenChange={(open) => !open && setAsk(null)}
        title="تسجيل النفوق؟"
        body="يخرج الرأس من تعداد الحظيرة ويبقى في الأرشيف."
        confirmLabel="تأكيد"
        destructive
        onConfirm={() => {
          setStatus(animal.id, "dead");
          setAsk(null);
        }}
      />
      <Confirm
        open={ask === "lost"}
        onOpenChange={(open) => !open && setAsk(null)}
        title="إغلاق الحمل؟"
        body="يُعلَّم التلقيح القائم مفقوداً ولن تُحسب النعجة حاملاً."
        confirmLabel="إغلاق"
        onConfirm={() => {
          if (pending) markLost(pending.id, todayIso());
          setAsk(null);
        }}
      />
      <Confirm
        open={ask === "delete"}
        onOpenChange={(open) => !open && setAsk(null)}
        title="حذف هذا الرأس؟"
        body="تُحذف أوزانه وسجلاته الصحية وتلقيحاته. لا يمكن التراجع."
        confirmLabel="حذف"
        destructive
        onConfirm={() => {
          removeSheep(animal.id);
          void navigate({ to: "/flock" });
        }}
      />
    </AppShell>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm font-medium">{value}</p>
    </div>
  );
}

function Spark({ points }: { points: { date: string; kg: number }[] }) {
  const vals = points.map((p) => p.kg);
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const span = max - min || 1;
  const w = 320;
  const h = 88;
  const coords = points
    .map((p, i) => {
      const x = (i / (points.length - 1)) * w;
      const y = h - ((p.kg - min) / span) * (h - 12) - 6;
      return `${x},${y}`;
    })
    .join(" ");
  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      className="h-24 w-full text-foreground"
      role="img"
      aria-label="منحنى الوزن"
    >
      <polyline
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinejoin="round"
        strokeLinecap="round"
        points={coords}
      />
    </svg>
  );
}
