import { createFileRoute, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { MoonLab } from "@/components/moon-lab";
import { PolarisLab } from "@/components/polaris-lab";
import { ScaleLab } from "@/components/scale-lab";
import { SeasonLab } from "@/components/season-lab";

export const Route = createFileRoute("/labs")({ component: LabsPage });

function LabsPage() {
  const hash = useRouterState({ select: (s) => s.location.hash });
  useEffect(() => {
    const id = hash.replace(/^#/, "");
    if (!id) return;
    document.getElementById(id)?.scrollIntoView({ block: "start" });
  }, [hash]);

  return (
    <div>
      <p className="text-xs uppercase tracking-widest text-gold">Instruments</p>
      <h1 className="mt-2 max-w-xl text-4xl text-fg md:text-5xl">Three ideas the eye can check.</h1>
      <p className="mt-3 max-w-xl text-muted">
        Latitude in the pole star, the Moon's orbit, the year's tilt, and the rude truth about distance. The same latitude feeds the sky chart.
      </p>
      <div className="mt-10 grid gap-12">
        <section id="pole" className="scroll-mt-24">
          <h2 className="text-2xl text-fg">The pole</h2>
          <p className="mt-2 mb-4 max-w-xl text-sm text-muted">Polaris is not bright. It is useful, which is better. Its height is your latitude.</p>
          <PolarisLab />
        </section>
        <section id="moon" className="scroll-mt-24">
          <h2 className="text-2xl text-fg">The Moon</h2>
          <p className="mt-2 mb-4 max-w-xl text-sm text-muted">
            Drag it. New is toward the Sun, full is opposite. Earth's shadow is not involved unless the alignment is exact — that's an eclipse.
          </p>
          <MoonLab />
        </section>
        <section id="seasons" className="scroll-mt-24">
          <h2 className="text-2xl text-fg">The year</h2>
          <p className="mt-2 mb-4 max-w-xl text-sm text-muted">
            Slide from January to June at your latitude. Watch noon altitude and the length of the day. Then try the other hemisphere.
          </p>
          <SeasonLab />
        </section>
        <section id="scale" className="scroll-mt-24">
          <h2 className="text-2xl text-fg">The emptiness</h2>
          <p className="mt-2 mb-4 max-w-xl text-sm text-muted">
            Textbooks draw planets as neighbors. They aren't. Sizes first, then the same scale stretched across distance.
          </p>
          <ScaleLab />
        </section>
      </div>
    </div>
  );
}
