import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { LogoMark } from "@/components/logo";
import { Button, Input, Label } from "@/components/ui";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (isPending) {
    return (
      <main className="grid min-h-dvh place-items-center bg-navy">
        <LogoMark className="size-16" />
      </main>
    );
  }
  if (user) return <Navigate to="/" />;

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "up") {
        const res = await authClient.signUp.email({ email, password, name: name || "کاربر" });
        if (res.error) throw new Error(res.error.message);
      } else {
        const res = await authClient.signIn.email({ email, password });
        if (res.error) throw new Error(res.error.message);
      }
      window.location.href = "/";
    } catch (err) {
      setError(err instanceof Error ? err.message : "ورود ناموفق بود.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-dvh bg-navy text-paper">
      <div className="mx-auto grid min-h-dvh max-w-5xl lg:grid-cols-2">
        <section className="hidden flex-col justify-between p-10 lg:flex">
          <LogoMark className="size-14" />
          <div>
            <p className="font-display text-5xl text-gold-soft" style={{ fontFamily: "var(--font-display)" }}>
              MR,KHORASANI
            </p>
            <p className="mt-3 text-sm tracking-[0.22em] text-gold/80 uppercase">Professional Accounting System</p>
            <p className="mt-8 max-w-sm text-sm leading-7 text-paper/70">
              ثبت عملیات روزانه، سند دوبل خودکار، تراز آزمایشی، نقدینگی و کنترل بستن روز — در یک دفتر مالی قابل اتکا.
            </p>
          </div>
          <p className="text-xs text-paper/40">Financial Management & Accounting</p>
        </section>
        <section className="flex items-center justify-center bg-paper p-6 text-ink">
          <div className="w-full max-w-sm">
            <div className="mb-8 flex justify-center lg:hidden">
              <LogoMark className="size-14" />
            </div>
            <h1 className="text-center text-2xl font-semibold text-navy lg:text-right">ورود به دفتر</h1>
            <p className="mt-1 mb-6 text-center text-sm text-muted lg:text-right">MR,KHORASANI</p>
            {authEnabled ? (
              <>
                <form onSubmit={onSubmit} className="space-y-3">
                  {mode === "up" && (
                    <div>
                      <Label>نام</Label>
                      <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="نام نمایشی" />
                    </div>
                  )}
                  <div>
                    <Label>ایمیل</Label>
                    <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" dir="ltr" />
                  </div>
                  <div>
                    <Label>رمز عبور</Label>
                    <Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" dir="ltr" />
                  </div>
                  {error && <p className="text-sm text-danger">{error}</p>}
                  <Button type="submit" className="w-full" disabled={busy}>
                    {busy ? "در حال بررسی..." : mode === "in" ? "ورود" : "ایجاد حساب"}
                  </Button>
                </form>
                <button
                  type="button"
                  className="mt-3 w-full text-sm text-muted"
                  onClick={() => setMode(mode === "in" ? "up" : "in")}
                >
                  {mode === "in" ? "حساب ندارید؟ ایجاد حساب" : "حساب دارید؟ ورود"}
                </button>
                <div className="my-5 flex items-center gap-3 text-xs text-muted">
                  <span className="h-px flex-1 bg-line" />
                  یا
                  <span className="h-px flex-1 bg-line" />
                </div>
                <div className="space-y-2">
                  {GROK_PROVIDERS.map((p) => (
                    <Button
                      key={p.providerId}
                      type="button"
                      variant="secondary"
                      className="w-full"
                      onClick={() => signIn(p.providerId, { callbackURL: "/" })}
                    >
                      ادامه با {p.label}
                    </Button>
                  ))}
                </div>
              </>
            ) : (
              <p className="text-sm text-muted">ورود غیرفعال است.</p>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}
