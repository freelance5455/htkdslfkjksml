import { createFileRoute, Link } from "@tanstack/react-router";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { SignInGate } from "@/lib/auth/gates";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  return (
    <main className="grid min-h-dvh place-items-center px-6 py-12">
      <div className="w-full max-w-sm">
        <p className="font-serif text-[13px] text-brass-deep">RentDirect</p>
        <h1 className="font-serif mt-1 text-3xl font-semibold tracking-tight text-ink">Sign in</h1>
        <p className="mt-2 text-sm text-ink-soft">
          Post rooms, reveal owner numbers, and earn when a listing you shared gets rented.
        </p>
        <div className="mt-6 space-y-2.5">
          <SignInGate
            fallback={
              authEnabled ? (
                GROK_PROVIDERS.map((p) => (
                  <button
                    key={p.providerId}
                    type="button"
                    onClick={() => signIn(p.providerId, { callbackURL: "/" })}
                    className="flex min-h-11 w-full items-center justify-center rounded-md border border-line bg-card px-4 text-sm font-medium text-ink transition-opacity hover:bg-paper-alt"
                  >
                    Continue with {p.label}
                  </button>
                ))
              ) : (
                <p className="text-sm text-ink-soft">Sign-in is disabled.</p>
              )
            }
          >
            <p className="text-sm text-ink-soft">You're already signed in.</p>
            <Link to="/" search={{ tab: "browse" }} className="mt-3 inline-flex min-h-11 items-center text-sm font-medium text-brass-deep underline-offset-4 hover:underline">
              Back to rooms
            </Link>
          </SignInGate>
        </div>
        <Link to="/" search={{ tab: "browse" }} className="mt-8 inline-block text-sm text-ink-soft underline-offset-4 hover:underline">
          Browse without posting
        </Link>
      </div>
    </main>
  );
}
