import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { LanguageToggle, ScreenSkeleton } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Field, TextInput } from "@/components/ui/field";
import { useEdu } from "@/components/edu-provider";
import { t } from "@/content/copy";
import { GROK_PROVIDERS, authClient, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useLocale } from "@/lib/locale";

export const Route = createFileRoute("/login")({ component: LoginPage });

const namePattern = /^[\p{L}\p{M}\s'.-]{2,80}$/u;

function LoginPage() {
  const { user, isPending } = useCurrentUserState();
  const locale = useLocale((state) => state.locale);
  const setLocale = useLocale((state) => state.setLocale);
  const { saveStudent } = useEdu();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("up");
  const [fullName, setFullName] = useState("");
  const [grade, setGrade] = useState(6);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (isPending) return <ScreenSkeleton label={t(locale, "loading")} />;
  if (user && !busy) return <Navigate to="/" />;

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    if (password.length < 8) {
      setError(t(locale, "passwordHint"));
      return;
    }
    if (mode === "up" && !namePattern.test(fullName.trim())) {
      setError(t(locale, "nameInvalid"));
      return;
    }
    setBusy(true);
    try {
      if (mode === "up") {
        const created = await authClient.signUp.email({
          email: email.trim(),
          password,
          name: fullName.trim(),
        });
        if (created.error) {
          setError(t(locale, "signUpFailed"));
          setBusy(false);
          return;
        }
        try {
          await saveStudent({ fullName: fullName.trim(), grade, locale });
        } catch {
          sessionStorage.setItem(
            "henok-pending-profile",
            JSON.stringify({ fullName: fullName.trim(), grade }),
          );
        }
      } else {
        const signed = await authClient.signIn.email({
          email: email.trim(),
          password,
        });
        if (signed.error) {
          setError(t(locale, "signInFailed"));
          setBusy(false);
          return;
        }
      }
      await navigate({ to: "/" });
    } catch {
      setError(mode === "up" ? t(locale, "signUpFailed") : t(locale, "signInFailed"));
      setBusy(false);
    }
  }

  return (
    <div className="grid min-h-dvh md:grid-cols-2">
      <section className="band-pattern px-5 py-8 text-card md:px-10 md:py-16">
        <p className="text-sm font-semibold">{t(locale, "allGrades")}</p>
        <h1 className="mt-4 max-w-md text-3xl font-semibold tracking-tight">{t(locale, "brand")}</h1>
        <p className="mt-3 max-w-sm text-card">{t(locale, "tagline")}</p>
      </section>
      <section className="bg-paper px-4 py-6 md:px-10 md:py-16">
        <div className="mb-6 flex justify-end">
          <LanguageToggle locale={locale} onChange={setLocale} />
        </div>
        <div className="mx-auto w-full max-w-sm">
          <div className="mb-5 grid grid-cols-2 gap-2 rounded-md bg-paper-2 p-1">
            <button
              type="button"
              className={
                mode === "up"
                  ? "min-h-11 rounded-md bg-card font-semibold text-ink"
                  : "min-h-11 rounded-md font-semibold text-muted"
              }
              onClick={() => setMode("up")}
            >
              {t(locale, "createAccount")}
            </button>
            <button
              type="button"
              className={
                mode === "in"
                  ? "min-h-11 rounded-md bg-card font-semibold text-ink"
                  : "min-h-11 rounded-md font-semibold text-muted"
              }
              onClick={() => setMode("in")}
            >
              {t(locale, "signIn")}
            </button>
          </div>
          <form className="space-y-4" onSubmit={(event) => void onSubmit(event)}>
            {mode === "up" ? (
              <>
                <Field label={t(locale, "fullName")}>
                  <TextInput
                    value={fullName}
                    onChange={(event) => setFullName(event.target.value)}
                    autoComplete="name"
                    required
                  />
                </Field>
                <div>
                  <p className="mb-1.5 text-sm font-semibold">{t(locale, "grade")}</p>
                  <div className="grid grid-cols-5 gap-2">
                    {[4, 5, 6, 7, 8].map((value) => (
                      <button
                        key={value}
                        type="button"
                        aria-pressed={grade === value}
                        onClick={() => setGrade(value)}
                        className={
                          grade === value
                            ? "min-h-11 rounded-md bg-teal font-semibold text-card"
                            : "min-h-11 rounded-md border border-line bg-card font-semibold"
                        }
                      >
                        {value}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            ) : null}
            <Field label={t(locale, "email")}>
              <TextInput
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                autoComplete="email"
                required
              />
            </Field>
            <Field label={t(locale, "password")} hint={t(locale, "passwordHint")}>
              <TextInput
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                autoComplete={mode === "up" ? "new-password" : "current-password"}
                required
                minLength={8}
              />
            </Field>
            {error ? <p className="text-sm font-semibold text-danger">{error}</p> : null}
            <Button type="submit" size="block" disabled={busy}>
              {busy ? t(locale, "working") : mode === "up" ? t(locale, "createAccount") : t(locale, "signIn")}
            </Button>
          </form>
          <p className="my-4 text-center text-sm text-muted">{t(locale, "or")}</p>
          <div className="grid gap-2">
            {GROK_PROVIDERS.map((provider) => (
              <Button
                key={provider.providerId}
                variant="secondary"
                size="block"
                onClick={() => void signIn(provider.providerId, { callbackURL: "/" })}
              >
                {provider.providerId === "grok-google" ? t(locale, "continueGoogle") : t(locale, "continueX")}
              </Button>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
