import { useState, type FormEvent } from "react";
import { createFileRoute, Navigate } from "@tanstack/react-router";
import { BookOpen } from "lucide-react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { BootScreen } from "@/components/reader-app";

export const Route = createFileRoute("/login")({ component: LoginPage });

const PREVIEW_BEARER_KEY = "grok-auth.bearer-token";

function LoginPage() {
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (isPending) return <BootScreen />;
  if (user) return <Navigate to="/" />;

  async function establish(token?: string | null) {
    if (token && window.location.hostname.endsWith(".grok-sandbox.com")) {
      sessionStorage.setItem(PREVIEW_BEARER_KEY, token);
    }
    await authClient.getSession();
    window.location.assign("/");
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    const cleanEmail = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setError("Enter a valid email address.");
      return;
    }
    if (password.length < 8) {
      setError("Use a password of at least 8 characters.");
      return;
    }
    if (mode === "up" && name.trim().length < 2) {
      setError("Tell us the name you want on your profile.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "up") {
        const result = await authClient.signUp.email({
          email: cleanEmail,
          password,
          name: name.trim(),
        });
        if (result.error) throw new Error(result.error.message ?? "Could not create the account.");
        await establish(result.data?.token);
        return;
      }
      const result = await authClient.signIn.email({ email: cleanEmail, password });
      if (result.error) throw new Error(result.error.message ?? "Could not sign in.");
      await establish(result.data?.token);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed.");
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-screen lg:grid-cols-2">
      <section className="flex flex-col justify-between bg-ink px-6 py-8 text-on-ink sm:px-10 lg:px-14 lg:py-12">
        <div className="flex items-center gap-3">
          <span className="grid size-11 place-items-center rounded-2xl bg-primary text-primary-fg">
            <BookOpen className="size-5" />
          </span>
          <span className="font-display text-xl">Good Health Reader</span>
        </div>
        <div className="max-w-md py-10">
          <p className="text-xs font-semibold tracking-widest text-accent uppercase">Social e-library</p>
          <h1 className="mt-3 font-display text-4xl text-on-ink sm:text-5xl">A shelf you share, and a profile that is only yours.</h1>
          <p className="mt-4 text-base soft-on-ink">
            Sign in and we mint a unique reader ID. Then you can read and download books, post short reviews, and
            write to other readers.
          </p>
        </div>
        <p className="text-sm soft-on-ink">Books, messages, and your profile stay with the account.</p>
      </section>

      <section className="flex items-center justify-center px-4 py-10">
        <div className="lift w-full max-w-md p-6 sm:p-8">
          <h2 className="font-display text-3xl">{mode === "in" ? "Sign in" : "Create your profile"}</h2>
          <p className="mt-1 text-sm text-muted">
            {mode === "in" ? "Welcome back to the shelf." : "Your reader ID is created as soon as the account is."}
          </p>
          <div className="mt-5 grid grid-cols-2 gap-2 rounded-xl bg-paper p-1">
            <button
              type="button"
              className={`h-10 rounded-lg text-sm font-semibold ${mode === "in" ? "bg-surface text-ink" : "text-muted"}`}
              onClick={() => {
                setMode("in");
                setError("");
              }}
            >
              Sign in
            </button>
            <button
              type="button"
              className={`h-10 rounded-lg text-sm font-semibold ${mode === "up" ? "bg-surface text-ink" : "text-muted"}`}
              onClick={() => {
                setMode("up");
                setError("");
              }}
            >
              Create account
            </button>
          </div>

          {authEnabled ? (
            <form className="mt-5 space-y-3" onSubmit={(event) => void onSubmit(event)}>
              {mode === "up" && (
                <label className="block text-sm font-medium">
                  Name
                  <input
                    id="login-name"
                    className="field-input mt-1.5"
                    autoComplete="name"
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    placeholder="Amira Khan"
                  />
                </label>
              )}
              <label className="block text-sm font-medium">
                Email
                <input
                  id="login-email"
                  className="field-input mt-1.5"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="you@example.com"
                />
              </label>
              <label className="block text-sm font-medium">
                Password
                <input
                  id="login-password"
                  className="field-input mt-1.5"
                  type="password"
                  autoComplete={mode === "up" ? "new-password" : "current-password"}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="At least 8 characters"
                />
              </label>
              {error && (
                <p role="alert" className="rounded-xl bg-accent-soft px-3 py-2 text-sm text-ink">
                  {error}
                </p>
              )}
              <button id="login-submit" type="submit" className="btn btn-primary w-full" disabled={busy}>
                {busy ? "Please wait…" : mode === "in" ? "Enter the shelf" : "Create my reader ID"}
              </button>
            </form>
          ) : (
            <p className="mt-5 text-sm text-muted">Sign-in is disabled.</p>
          )}

          <div className="my-5 flex items-center gap-3 text-xs text-muted">
            <span className="h-px flex-1 bg-line" />
            or
            <span className="h-px flex-1 bg-line" />
          </div>
          <div className="space-y-2">
            {GROK_PROVIDERS.map((provider) => (
              <button
                key={provider.providerId}
                type="button"
                className="btn btn-ghost w-full"
                onClick={() => {
                  setError("");
                  void signIn(provider.providerId, { callbackURL: "/" }).catch((err: unknown) => {
                    setError(err instanceof Error ? err.message : "Sign-in failed.");
                  });
                }}
              >
                Continue with {provider.label}
              </button>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
