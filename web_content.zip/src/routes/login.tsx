import { createFileRoute, Navigate } from "@tanstack/react-router";
import { AuthPanel } from "@/components/nyala/auth-panel";
import { Splash } from "@/components/nyala/nyala-gate";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <Splash label="Menyalakan panggung…" />;
  if (user) return <Navigate to="/" />;
  return (
    <main className="grid min-h-dvh place-items-center bg-ink px-4 py-10">
      <div>
        <p className="mb-4 text-center font-display text-4xl">NYALA</p>
        <AuthPanel next="/" />
      </div>
    </main>
  );
}
