import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState } from "react";
import { BrandMark, Wordmark } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Splash } from "@/components/layout/splash";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (isPending) return <Splash message="بررسی نشست" />;
  if (user) return <Navigate to="/dashboard" />;

  async function onEmail(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === "up") {
        const res = await authClient.signUp.email({ email, password, name: name || email.split("@")[0] });
        if (res.error) throw new Error(res.error.message);
      }
      const res = await authClient.signIn.email({ email, password });
      if (res.error) throw new Error(res.error.message);
      window.location.href = "/dashboard";
    } catch (err) {
      setError(err instanceof Error ? err.message : "ورود ناموفق بود");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid min-h-dvh lg:grid-cols-[1.1fr_0.9fr]">
      <section className="relative hidden flex-col justify-between bg-navy px-12 py-12 text-cream lg:flex">
        <BrandMark className="size-12" />
        <div>
          <Wordmark light />
          <p className="mt-8 max-w-md text-sm leading-7 text-cream/70">
            ثبت عملیات روزانه، صدور خودکار سند دوبل، تراز آزمایشی، نقدینگی و بستن روز — با کنترل داخلی و ردپای حسابرسی.
          </p>
        </div>
        <div className="text-[11px] tracking-[0.2em] text-gold-2">PRECISION · CONTROL · LEDGER</div>
      </section>

      <section className="flex flex-col justify-center bg-cream px-6 py-12">
        <div className="mx-auto w-full max-w-sm">
          <div className="mb-8 flex flex-col items-center lg:hidden">
            <BrandMark className="size-12" />
            <div className="mt-4">
              <Wordmark />
            </div>
          </div>
          <h1 className="text-2xl font-semibold text-navy">ورود به سامانه</h1>
          <p className="mt-1 text-sm text-muted">برای دسترسی به دفاتر مالی وارد شوید.</p>

          {authEnabled ? (
            <>
              <form onSubmit={onEmail} className="mt-8 space-y-4">
                {mode === "up" ? (
                  <Field label="نام">
                    <Input value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
                  </Field>
                ) : null}
                <Field label="ایمیل">
                  <Input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    autoComplete="email"
                    dir="ltr"
                  />
                </Field>
                <Field label="رمز عبور">
                  <Input
                    type="password"
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete={mode === "up" ? "new-password" : "current-password"}
                    dir="ltr"
                  />
                </Field>
                {error ? <p className="text-xs text-danger">{error}</p> : null}
                <Button type="submit" variant="gold" className="w-full" disabled={busy}>
                  {busy ? "لطفاً صبر کنید…" : mode === "up" ? "ایجاد حساب و ورود" : "ورود"}
                </Button>
              </form>
              <button
                type="button"
                className="mt-3 text-xs text-muted"
                onClick={() => setMode(mode === "in" ? "up" : "in")}
              >
                {mode === "in" ? "حساب ندارید؟ ثبت‌نام کنید" : "حساب دارید؟ وارد شوید"}
              </button>

              <div className="my-6 flex items-center gap-3">
                <div className="h-px flex-1 bg-line" />
                <span className="text-[11px] text-muted">یا ورود با</span>
                <div className="h-px flex-1 bg-line" />
              </div>
              <div className="space-y-2">
                {GROK_PROVIDERS.map((p) => (
                  <Button
                    key={p.providerId}
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => signIn(p.providerId, { callbackURL: "/dashboard" })}
                  >
                    ادامه با {p.label}
                  </Button>
                ))}
              </div>
            </>
          ) : (
            <p className="mt-6 text-sm text-muted">ورود غیرفعال است.</p>
          )}
        </div>
      </section>
    </div>
  );
}
