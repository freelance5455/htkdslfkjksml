import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageIntro } from "@/components/page";
import { NAMES } from "@/data/names";
import { useProgress } from "@/lib/progress";
import { syriaDateKey } from "@/lib/utils";

export const Route = createFileRoute("/study")({
  head: () => ({ meta: [{ title: "مراجعة الأسماء — لأنه الله" }] }),
  component: StudyPage,
});

function StudyPage() {
  const saved = useProgress((state) => state.saved);
  const srs = useProgress((state) => state.srs);
  const review = useProgress((state) => state.review);
  const today = syriaDateKey();
  const queue = useMemo(() => {
    const due = NAMES.filter((name) => {
      const card = srs[name.slug];
      if (saved.includes(name.slug)) return true;
      return !card || card.due <= today;
    });
    return due.length ? due : NAMES;
  }, [saved, srs, today]);
  const [index, setIndex] = useState(0);
  const [hidden, setHidden] = useState(true);
  const name = queue[index % queue.length] ?? NAMES[0];

  function grade(value: "again" | "good" | "easy") {
    if (!name) return;
    review(name.slug, value);
    setHidden(true);
    setIndex((current) => current + 1);
  }

  return (
    <main>
      <PageIntro
        kicker="أداة تعليمية على هذا الجهاز"
        title="مراجعة الأسماء"
        lede="أخفِ المعنى وحاول تذكره. التكرار المتباعد يُحفظ محليًا، ولا يُعرض بوصفه نتيجة رسمية."
      />
      {name ? (
        <section className="mx-auto max-w-3xl px-4 py-8">
          <p className="text-sm text-muted">البطاقة {index + 1} ضمن جولة مفتوحة. المستحق اليوم يتقدم إن وُجد.</p>
          <article className="mt-4 rounded-card border border-line bg-surface p-8 text-center">
            <h2 className="font-display text-6xl text-primary">{name.ar}</h2>
            <p className="mt-2 text-muted">{name.pron}</p>
            {hidden ? (
              <button type="button" onClick={() => setHidden(false)} className="mt-8 rounded-full bg-primary px-5 py-3 text-primary-fg">
                أظهر المعنى
              </button>
            ) : (
              <div className="mt-6 text-start leading-8">
                <p>{name.mean}</p>
                <p className="mt-3 text-sm text-muted">{name.simple}</p>
                <Link to="/names/$slug" params={{ slug: name.slug }} className="mt-4 inline-block text-sm text-primary">الصفحة الكاملة</Link>
              </div>
            )}
          </article>
          <div className="mt-4 grid grid-cols-3 gap-2">
            <button type="button" onClick={() => grade("again")} className="rounded-full border border-line px-3 py-3 text-sm">أُعيده</button>
            <button type="button" onClick={() => grade("good")} className="rounded-full border border-line px-3 py-3 text-sm">أذكره</button>
            <button type="button" onClick={() => grade("easy")} className="rounded-full bg-primary px-3 py-3 text-sm text-primary-fg">أُتقنته</button>
          </div>
        </section>
      ) : null}
    </main>
  );
}
