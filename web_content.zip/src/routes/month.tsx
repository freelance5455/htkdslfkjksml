import { createFileRoute } from "@tanstack/react-router";
import { MonthView } from "@/components/planner/views/month";

type MonthSearch = { m?: string };

export const Route = createFileRoute("/month")({
  validateSearch: (search: Record<string, unknown>): MonthSearch => ({
    m: typeof search.m === "string" && /^\d{4}-\d{2}$/.test(search.m) ? search.m : undefined,
  }),
  component: function MonthRoute() {
    const { m } = Route.useSearch();
    return <MonthView initialKey={m} />;
  },
});
