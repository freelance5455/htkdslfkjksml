import { createFileRoute } from "@tanstack/react-router";
import { NyalaGate } from "@/components/nyala/nyala-gate";

export const Route = createFileRoute("/s/$roomId")({
  component: RoomPage,
});

function RoomPage() {
  const { roomId } = Route.useParams();
  return <NyalaGate roomId={roomId} />;
}
