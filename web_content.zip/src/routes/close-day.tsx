import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Button, Field, PageTitle, Textarea } from "@/components/ui";
import { JalaliDateField } from "@/components/fields";
import { closeDay, previewCloseDay, requestReopen } from "@/lib/server/books";
import { todayIso } from "@/lib/accounting/jalali";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/close-day")({ component: CloseDayPage });

function CloseDayPage() {
  const [date, setDate] = useState(todayIso());
  const [confirm, setConfirm] = useState(false);
  const [reason, setReason] = useState("");
  const qc = useQueryClient();
  const preview = useQuery({ queryKey: ["close-preview", date], queryFn: () => previewCloseDay({ data: { date } }) });
  const mut = useMutation({
    mutationFn: () => closeDay({ data: { date, confirm: true } }),
    onSuccess: (r) => {
      toast.success(`روز بسته شد. پشتیبان ${r.name}`);
      qc.invalidateQueries();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const req = useMutation({
    mutationFn: () => requestReopen({ data: { date, reason } }),
    onSuccess: (r) => toast.message(r.message),
    onError: (e: Error) => toast.error(e.message),
  });
  const p = preview.data;
  return (
    <AppShell>
      <PageTitle title="بستن روز" subtitle="پس از بستن، ویرایش مستقیم ممنوع است. اصلاح فقط با سند اصلاحی." />
      <div className="max-w-xl space-y-4">
        <Field label="تاریخ روز">
          <JalaliDateField value={date} onChange={setDate} />
        </Field>
        {p && (
          <ul className="space-y-2 rounded-xl border border-line bg-card p-4 text-sm">
            <Li ok={!p.already} text={p.already ? "این روز قبلاً بسته شده" : "روز هنوز باز است"} />
            <Li ok={p.opCount > 0} text={`تعداد عملیات: ${p.opCount}`} />
            <Li ok={p.journalCount > 0} text={`تعداد اسناد: ${p.journalCount}`} />
            <Li ok={p.unbalanced.length === 0} text={p.unbalanced.length ? `اسناد نامتوازن: ${p.unbalanced.length}` : "همه اسناد متوازن‌اند"} />
            <Li ok={p.missingSource === 0} text={p.missingSource ? "دریافت/پرداخت بدون منبع" : "منابع مالی کامل است"} />
            <Li ok={p.negative === 0} text={p.negative ? "مبلغ منفی وجود دارد" : "مبلغ منفی غیرمجاز نیست"} />
          </ul>
        )}
        <label className="flex items-start gap-2 text-sm">
          <input type="checkbox" className="mt-1" checked={confirm} onChange={(e) => setConfirm(e.target.checked)} />
          پس از بستن روز، اطلاعات این روز قابل ویرایش مستقیم نخواهد بود.
        </label>
        <Button className="w-full" disabled={!confirm || mut.isPending || !p?.ok} onClick={() => mut.mutate()}>
          بستن روز و تهیه بسته روزانه
        </Button>
        <div className="border-t border-line pt-4">
          <p className="mb-2 text-sm font-medium text-navy">درخواست اصلاح روز بسته‌شده</p>
          <Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="دلیل درخواست" />
          <Button variant="secondary" className="mt-2 w-full" onClick={() => req.mutate()}>ثبت درخواست</Button>
        </div>
      </div>
    </AppShell>
  );
}

function Li({ ok, text }: { ok: boolean; text: string }) {
  return <li className={ok ? "text-ok" : "text-danger"}>{ok ? "●" : "○"} {text}</li>;
}
