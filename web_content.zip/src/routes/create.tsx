import { useEffect } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useProjects } from "@/components/storyboard/use-projects";
import { idbPut } from "@/lib/storyboard/idb";
import { useStory } from "@/lib/storyboard/store";

export const Route = createFileRoute("/create")({
  component: Create,
});

const PENDING_KEY = "storyboard-ai-pending-create";

function Create() {
  const ready = useProjects();
  const navigate = useNavigate();

  useEffect(() => {
    if (!ready) return;
    const pending = sessionStorage.getItem(PENDING_KEY);
    if (pending) {
      sessionStorage.removeItem(PENDING_KEY);
      void navigate({ to: "/storyboards/$id", params: { id: pending }, replace: true });
      return;
    }
    const project = useStory.getState().createBlank();
    sessionStorage.setItem(PENDING_KEY, project.id);
    void idbPut(project).finally(() => {
      sessionStorage.removeItem(PENDING_KEY);
      void navigate({ to: "/storyboards/$id", params: { id: project.id }, replace: true });
    });
  }, [ready, navigate]);

  return <p className="text-sm text-muted">Menyiapkan storyboard…</p>;
}
