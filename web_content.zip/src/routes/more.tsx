import { createFileRoute, Link } from "@tanstack/react-router";
import { Page } from "@/components/ui";

export const Route = createFileRoute("/more")({ component: MorePage });

const ITEMS = [
  ["/reciters", "التلاوات", "استماع وتنزيل سور القراء"],
  ["/adhan", "الأذان", "أذان مرخّص واستيراد تسجيلاتك"],
  ["/tasbeeh", "السبحة", "عدّ وذكر"],
  ["/prophets", "قصص الأنبياء", "ما ثبت في القرآن والسنة"],
  ["/sunnah", "السنن", "مجموعة موثّقة لا ندّعي أنها ستة آلاف"],
  ["/seerah", "السيرة", "من المولد إلى الوفاة"],
  ["/names", "الأسماء الحسنى", "تسعة وتسعون مع التنبيه على السرد"],
  ["/learn", "تعليم الإسلام", "دروس مع تمييز الخلاف"],
  ["/hadith", "الحديث", "الأربعون النووية كاملة"],
  ["/companions", "الصحابة والعلماء", "تراجم مختصرة"],
  ["/qibla", "القبلة والتقويم", "اتجاه القبلة والمناسبات"],
  ["/quiz", "اختبارات", "تصحيح فوري"],
  ["/progress", "المتابعة", "وردك بلا تأنيب"],
  ["/search", "البحث", "في المحتوى المحفوظ"],
  ["/sources", "المصادر", "من أين أُخذ المحتوى"],
  ["/support", "الدعم والتواصل", "بيانات المطوّر"],
  ["/settings", "الإعدادات", "المظهر والخصوصية"],
] as const;

function MorePage() {
  return (
    <Page title="الأقسام" subtitle="موسوعة سنية تعمل على جهازك. الصوتيات الكبيرة تُنزَّل عند الحاجة.">
      <ul className="grid gap-2">
        {ITEMS.map(([to, title, sub]) => (
          <li key={to}>
            <Link to={to} className="block min-h-16 rounded-2xl border border-line bg-card px-4 py-3">
              <span className="block font-bold">{title}</span>
              <span className="text-sm text-muted">{sub}</span>
            </Link>
          </li>
        ))}
      </ul>
    </Page>
  );
}
