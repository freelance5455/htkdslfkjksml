import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { Field } from "@/components/field";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Confirm } from "@/components/ui/confirm";
import { clampGestation, parseBackup, todayIso } from "@/lib/flock/logic";
import { useFlock, useHydrated } from "@/lib/flock/store";
import type { Backup } from "@/lib/flock/types";

export const Route = createFileRoute("/more")({
  component: MorePage,
});

function MorePage() {
  const hydrated = useHydrated();
  const herdName = useFlock((s) => s.herdName);
  const gestationDays = useFlock((s) => s.gestationDays);
  const setHerdName = useFlock((s) => s.setHerdName);
  const setGestationDays = useFlock((s) => s.setGestationDays);
  const sheep = useFlock((s) => s.sheep);
  const health = useFlock((s) => s.health);
  const breeding = useFlock((s) => s.breeding);
  const weights = useFlock((s) => s.weights);
  const replaceAll = useFlock((s) => s.replaceAll);
  const clearAll = useFlock((s) => s.clearAll);
  const [draftDays, setDraftDays] = useState(String(gestationDays));
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<Backup | null>(null);
  const [clearOpen, setClearOpen] = useState(false);

  useEffect(() => {
    if (hydrated) setDraftDays(String(useFlock.getState().gestationDays));
  }, [hydrated]);

  function exportFile() {
    const payload = {
      version: 1 as const,
      exportedAt: new Date().toISOString(),
      herdName,
      gestationDays,
      sheep,
      health,
      breeding,
      weights,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `qatiee-${todayIso()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function onFile(file: File | undefined) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = parseBackup(JSON.parse(String(reader.result ?? "")));
        if (!parsed) {
          setError("الملف ليس نسخة من قطيعي.");
          return;
        }
        setError(null);
        setPending(parsed);
      } catch {
        setError("تعذّر قراءة الملف.");
      }
    };
    reader.readAsText(file);
  }

  return (
    <AppShell title="الإعدادات">
      <div className="flex flex-col gap-4">
          <Card className="flex flex-col gap-4">
            <Field label="اسم القطيع" htmlFor="herd">
              <Input
                id="herd"
                value={herdName}
                maxLength={40}
                onChange={(e) => setHerdName(e.target.value)}
                onBlur={() => setHerdName(herdName.trim() || "قطيعي")}
              />
            </Field>
            <Field
              label="مدة الحمل بالأيام"
              htmlFor="gest"
              hint="الأغنام غالباً حول 147 يوماً. تُستخدم عند تسجيل تلقيح جديد."
            >
              <Input
                id="gest"
                inputMode="numeric"
                value={draftDays}
                onChange={(e) => setDraftDays(e.target.value)}
                onBlur={() => {
                  const next = clampGestation(Number(draftDays));
                  setDraftDays(String(next));
                  setGestationDays(next);
                }}
              />
            </Field>
          </Card>

          <Card className="flex flex-col gap-3">
            <div>
              <h2 className="font-medium">نسخة على الجهاز</h2>
              <p className="mt-1 text-sm leading-normal text-muted-foreground">
                السجل محفوظ في هذا المتصفح فقط. صدّر نسخة قبل مسح بيانات
                المتصفح أو تغيير الهاتف.
              </p>
            </div>
            <Button type="button" onClick={exportFile}>
              تصدير النسخة
            </Button>
            <label className="flex h-11 items-center justify-center rounded-lg border border-border text-sm font-medium">
              استيراد نسخة
              <input
                type="file"
                accept="application/json,.json"
                className="sr-only"
                onChange={(e) => {
                  onFile(e.target.files?.[0]);
                  e.target.value = "";
                }}
              />
            </label>
            {error ? <p className="text-sm text-danger">{error}</p> : null}
          </Card>

          <Card>
            <h2 className="font-medium">كيف يُدار القطيع</h2>
            <ul className="mt-2 flex list-disc flex-col gap-2 pr-4 text-sm leading-normal text-muted-foreground">
              <li>رقم الحلقة هو معرّف الرأس. لا يتكرر.</li>
              <li>الصغار من لهم أقل من سنة حسب تاريخ الميلاد.</li>
              <li>الحامل تُحسب من تلقيح لم تُسجَّل ولادته بعد.</li>
              <li>تسجيل الولادة ينشئ المواليد ويربطهم بالأم والأب.</li>
              <li>المبيع والنافق يخرجان من التعداد ويبقيان في الأرشيف.</li>
            </ul>
          </Card>

          <Button
            type="button"
            variant="ghost"
            className="text-danger"
            onClick={() => setClearOpen(true)}
          >
            مسح السجل كله
          </Button>
        </div>

      <Confirm
        open={pending != null}
        onOpenChange={(open) => !open && setPending(null)}
        title="استبدال السجل؟"
        body={
          pending
            ? `ستُستبدل البيانات الحالية بهذه النسخة: ${pending.sheep.length} رأس.`
            : ""
        }
        confirmLabel="استبدال"
        destructive
        onConfirm={() => {
          if (pending) replaceAll(pending);
          setPending(null);
          setDraftDays(String(pending?.gestationDays ?? gestationDays));
        }}
      />
      <Confirm
        open={clearOpen}
        onOpenChange={setClearOpen}
        title="مسح كل السجل؟"
        body="تُحذف الرؤوس والسجلات من هذا الجهاز. صدّر نسخة أولاً إن كنت تحتاجها."
        confirmLabel="مسح"
        destructive
        onConfirm={() => {
          clearAll();
          setDraftDays("147");
          setClearOpen(false);
        }}
      />
    </AppShell>
  );
}
