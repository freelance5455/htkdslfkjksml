import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { NameMotif } from "@/components/motif";
import { PageIntro, ReviewBanner } from "@/components/page";
import { EVIDENCE_LABEL, REVIEW_NOTE } from "@/data/types";
import { bareName, NAME_THEMES, NAMES } from "@/data/names";
import { useProgress } from "@/lib/progress";
import { arNum, stripArabic } from "@/lib/utils";

export const Route = createFileRoute("/names/")({
  head: () => ({ meta: [{ title: "أسماء الله الحسنى — لأنه الله" }] }),
  component: NamesPage,
});

function NamesPage() {
  const [query, setQuery] = useState("");
  const [theme, setTheme] = useState("الكل");
  const [alpha, setAlpha] = useState(false);
  const [evidence, setEvidence] = useState("الكل");
  const read = useProgress((state) => state.read);
  const normalized = stripArabic(query);

  const list = useMemo(() => {
    let items = NAMES.filter((name) => {
      const blob = stripArabic(`${name.ar} ${name.mean} ${name.simple} ${name.pron}`);
      const matchesQuery = !normalized || blob.includes(normalized) || String(name.n) === query.trim();
      const matchesTheme = theme === "الكل" || name.themes.includes(theme);
      const matchesEvidence = evidence === "الكل" || name.evidence === evidence;
      return matchesQuery && matchesTheme && matchesEvidence;
    });
    if (alpha) {
      items = [...items].sort((a, b) => bareName(a.ar).localeCompare(bareName(b.ar), "ar"));
    }
    return items;
  }, [alpha, evidence, normalized, query, theme]);

  function downloadSheet() {
    const lines = [
      "أسماء الله الحسنى — قائمة تعليمية",
      REVIEW_NOTE,
      "تحديد الأسماء التسعة والتسعين بأعيانها محل بحث، والحديث الصحيح لم يسردها في الصحيحين.",
      "",
      ...NAMES.map((name) => `${name.n}. ${name.ar} — ${name.mean} [${EVIDENCE_LABEL[name.evidence]}]`),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "asma-allah-alhusna.txt";
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main>
      <PageIntro
        kicker="موسوعة تعليمية"
        title="أسماء الله الحسنى"
        lede="عرض لتسعة وتسعين اسمًا في المجموعة التعليمية المشهورة، مع التفريق بين ما ثبت في القرآن أو السنة وما ورد في السرد المختلف في رفعه. أسماء الله ليست محصورة بهذا العدد."
      />
      <div className="mx-auto max-w-6xl space-y-5 px-4 py-8">
        <ReviewBanner>{REVIEW_NOTE}</ReviewBanner>
        <div className="flex flex-wrap gap-2">
          <Link to="/study" className="rounded-full bg-primary px-4 py-2 text-sm text-primary-fg">ابدأ رحلة التعلم</Link>
          <Link to="/quiz" className="rounded-full border border-line px-4 py-2 text-sm">اختبار المعاني</Link>
          <Link to="/progress" className="rounded-full border border-line px-4 py-2 text-sm">سجل المراجعة</Link>
          <button type="button" onClick={() => window.print()} className="rounded-full border border-line px-4 py-2 text-sm">طباعة</button>
          <button type="button" onClick={downloadSheet} className="rounded-full border border-line px-4 py-2 text-sm">تنزيل القائمة</button>
        </div>
        <div className="grid gap-3 md:grid-cols-[1fr_auto_auto_auto]">
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="ابحث بالاسم أو المعنى"
            aria-label="بحث في الأسماء"
            className="rounded-full border border-line bg-surface px-4 py-3"
          />
          <select value={theme} onChange={(event) => setTheme(event.target.value)} aria-label="تصفية موضوعية" className="rounded-full border border-line bg-surface px-4 py-3">
            <option>الكل</option>
            {NAME_THEMES.map((item) => <option key={item}>{item}</option>)}
          </select>
          <select value={evidence} onChange={(event) => setEvidence(event.target.value)} aria-label="درجة الثبوت" className="rounded-full border border-line bg-surface px-4 py-3">
            <option value="الكل">كل درجات الثبوت</option>
            <option value="quran">في القرآن</option>
            <option value="sunnah">في السنة</option>
            <option value="wording">المعنى ثابت</option>
            <option value="list">السرد المختلف فيه</option>
          </select>
          <button type="button" onClick={() => setAlpha((value) => !value)} className="rounded-full border border-line px-4 py-3 text-sm" aria-pressed={alpha}>
            {alpha ? "الترتيب التعليمي" : "ترتيب أبجدي"}
          </button>
        </div>
        <p className="text-sm text-muted">{arNum(list.length)} اسمًا · قرأت {arNum(read.length)} على هذا الجهاز</p>
        {list.length === 0 ? <p className="rounded-card border border-line p-6">لا توجد أسماء مطابقة. جرّب كلمة أقصر أو أزل التصفية.</p> : null}
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((name) => (
            <Link key={name.slug} to="/names/$slug" params={{ slug: name.slug }} className="flex gap-3 rounded-card border border-line bg-surface p-3">
              <NameMotif seed={name.n} label={name.ar} className="size-20 shrink-0" />
              <span>
                <span className="text-xs text-olive">{arNum(name.n)} {read.includes(name.slug) ? "· قُرئ" : ""}</span>
                <span className="mt-1 block font-display text-3xl text-primary">{name.ar}</span>
                <span className="mt-1 block text-sm leading-6 text-muted">{name.mean}</span>
              </span>
            </Link>
          ))}
        </div>
      </div>
    </main>
  );
}
