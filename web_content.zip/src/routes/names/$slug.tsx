import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { NameMotif } from "@/components/motif";
import { ActionBar, Pager, ReviewBanner, Tag } from "@/components/page";
import { getName, getNameByNumber, relatedNames } from "@/data/names";
import { EVIDENCE_LABEL, REVIEW_NOTE } from "@/data/types";
import { useProgress } from "@/lib/progress";
import { arNum } from "@/lib/utils";

export const Route = createFileRoute("/names/$slug")({
  loader: ({ params }) => {
    const name = getName(params.slug);
    if (!name) throw notFound();
    return name;
  },
  head: ({ loaderData }) => ({
    meta: [{ title: loaderData ? `${loaderData.ar} — أسماء الله الحسنى` : "اسم من أسماء الله" }],
  }),
  component: NamePage,
});

function NamePage() {
  const name = Route.useLoaderData();
  const read = useProgress((state) => state.read.includes(name.slug));
  const saved = useProgress((state) => state.saved.includes(name.slug));
  const fav = useProgress((state) => state.fav.includes(`name:${name.slug}`));
  const markRead = useProgress((state) => state.markRead);
  const toggleSaved = useProgress((state) => state.toggleSaved);
  const toggleFav = useProgress((state) => state.toggleFav);
  const [open, setOpen] = useState(false);
  const prev = getNameByNumber(name.n - 1);
  const next = getNameByNumber(name.n + 1);
  const related = relatedNames(name);
  const copy = [
    name.ar,
    name.mean,
    name.simple,
    name.cite ? `${name.cite.quote} — ${name.cite.surah} ${name.cite.ayah}` : "",
    EVIDENCE_LABEL[name.evidence],
    "منصة لأنه الله، نحبّه ونعظّمه. الشرح تعليمي ويحتاج مراجعة متخصص.",
  ].filter(Boolean).join("\n");

  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      <nav className="text-sm text-olive">
        <Link to="/names">الأسماء الحسنى</Link>
        <span> / </span>
        <span>{name.ar}</span>
      </nav>
      <div className="mt-6 grid items-center gap-6 lg:grid-cols-[220px_1fr]">
        <NameMotif seed={name.n} label={name.ar} className="mx-auto h-52 w-full max-w-xs" />
        <div>
          <p className="text-sm text-olive">الاسم {arNum(name.n)} من {arNum(99)}</p>
          <h1 className="mt-1 font-display text-6xl text-primary md:text-7xl">{name.ar}</h1>
          <p className="mt-2 text-lg text-muted">النطق: {name.pron}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Tag>{EVIDENCE_LABEL[name.evidence]}</Tag>
            {name.themes.map((theme) => <Tag key={theme}>{theme}</Tag>)}
          </div>
        </div>
      </div>
      <p className="mt-4 text-sm leading-7 text-muted">
        الزخرفة هندسية للتأمل البصري، وليست تمثيلًا للذات الإلهية ولا نسبة منظر طبيعي إلى الله.
      </p>
      <div className="mt-5">
        <ReviewBanner>{REVIEW_NOTE}</ReviewBanner>
      </div>
      <div className="mt-5">
        <ActionBar title={name.ar} text={copy} urlPath={`/names/${name.slug}`} />
        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" onClick={() => markRead(name.slug)} className="rounded-full bg-primary px-4 py-2 text-sm text-primary-fg">
            {read ? "سُجّلت القراءة" : "أتممت قراءة هذا الاسم"}
          </button>
          <button type="button" onClick={() => toggleSaved(name.slug)} className="rounded-full border border-line px-4 py-2 text-sm" aria-pressed={saved}>
            {saved ? "في قائمة المراجعة" : "أضف إلى المراجعة"}
          </button>
          <button type="button" onClick={() => toggleFav(`name:${name.slug}`)} className="rounded-full border border-line px-4 py-2 text-sm" aria-pressed={fav}>
            {fav ? "في المفضلة" : "أضف إلى المفضلة"}
          </button>
          <button type="button" onClick={() => setOpen((value) => !value)} className="rounded-full border border-line px-4 py-2 text-sm">
            {open ? "أظهر المعنى" : "أخفِ المعنى وحاول التذكر"}
          </button>
        </div>
      </div>

      {open ? <p className="mt-6 rounded-card border border-dashed border-line p-6">المعنى مخفي. حاول استحضاره ثم أظهره.</p> : (
        <div className="mt-8 grid gap-4 lg:grid-cols-2">
          <Section title="المعنى اللغوي والشرعي">
            <p>{name.ling}</p>
            <p className="mt-3 font-medium">{name.mean}</p>
          </Section>
          <Section title="شرح مبسط">
            <p>{name.simple}</p>
          </Section>
          <Section title="لمن أراد التوسع">
            <p>{name.deep}</p>
            <p className="mt-3 text-sm text-olive">هذا التوسع صياغة تعليمية للمنصة، وليس نقلًا حرفيًا عن عالم.</p>
          </Section>
          <Section title="الدليل">
            {name.cite ? (
              <>
                <p className="ayah text-2xl text-primary">{name.cite.quote}</p>
                <p className="mt-3 text-sm">{name.cite.surah} · الآية {arNum(name.cite.ayah)}</p>
                {name.cite.note ? <p className="mt-2 text-sm text-muted">{name.cite.note}</p> : null}
                <a href={name.cite.url} className="mt-3 inline-block text-sm text-primary" rel="noreferrer">فتح الآية في مصدر التلاوة</a>
              </>
            ) : (
              <p>لم يُربط شاهد قرآني مباشر بهذه الصيغة. راجع درجة الثبوت أعلى الصفحة.</p>
            )}
          </Section>
          <Section title="أثره في القلب">
            <p>{name.heart}</p>
          </Section>
          <Section title="عمل اليوم">
            <ul className="list-disc space-y-2 pe-5">
              {name.practice.map((item) => <li key={item}>{item}</li>)}
            </ul>
          </Section>
          <Section title="سؤال للتأمل">
            <p>{name.reflect}</p>
          </Section>
          <Section title="دعاء">
            {name.dua ? (
              <>
                <p className="font-display text-2xl leading-relaxed">{name.dua.text}</p>
                <p className="mt-3 text-sm text-muted">{name.dua.note}</p>
              </>
            ) : (
              <p>لم يُثبت هنا دعاء مخصوص بهذا الاسم. يُدعى الله بأسمائه الثابتة من غير اختلاق صيغة تُنسب إلى النبي ﷺ، ومن غير دعاء بطلب الضر.</p>
            )}
          </Section>
        </div>
      )}

      <section className="mt-8">
        <h2 className="font-display text-3xl text-primary">أسماء قريبة في المعنى</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {related.map((item) => (
            <Link key={item.slug} to="/names/$slug" params={{ slug: item.slug }} className="rounded-full border border-line px-4 py-2">
              {item.ar}
            </Link>
          ))}
        </div>
      </section>
      <section className="mt-6">
        <h2 className="font-display text-3xl text-primary">المراجع</h2>
        <ul className="mt-3 list-disc space-y-1 pe-5 text-sm leading-7 text-muted">
          {name.sources.map((source) => <li key={source}>{source}</li>)}
        </ul>
      </section>
      <Pager
        prev={prev ? (
          <Link to="/names/$slug" params={{ slug: prev.slug }} className="block rounded-card border border-line bg-surface p-4">
            <span className="text-xs text-olive">السابق</span>
            <span className="mt-1 block font-display text-3xl text-primary">{prev.ar}</span>
          </Link>
        ) : null}
        next={next ? (
          <Link to="/names/$slug" params={{ slug: next.slug }} className="block rounded-card border border-line bg-surface p-4">
            <span className="text-xs text-olive">التالي</span>
            <span className="mt-1 block font-display text-3xl text-primary">{next.ar}</span>
          </Link>
        ) : null}
      />
    </main>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-card border border-line bg-surface p-5">
      <h2 className="font-display text-2xl text-primary">{title}</h2>
      <div className="mt-3 leading-8">{children}</div>
    </section>
  );
}
