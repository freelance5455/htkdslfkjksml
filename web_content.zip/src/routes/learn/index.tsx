import { Link, createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppFrame, PageTitle } from "@/components/shell";
import { SubjectGlyph } from "@/components/subject-icon";
import { useEdu } from "@/components/edu-provider";
import { t } from "@/content/copy";
import { chaptersForGrade, lessonItemId, subjects } from "@/content/catalog";
import { fill, tx, useLocale } from "@/lib/locale";
import { listPacks, type OfflinePack } from "@/lib/offline";
import { useOnline } from "@/lib/use-online";

export const Route = createFileRoute("/learn/")({ component: LearnPage });

function LearnPage() {
  return (
    <AppFrame>
      <LearnBody />
    </AppFrame>
  );
}

function LearnBody() {
  const locale = useLocale((state) => state.locale);
  const { profile, progress } = useEdu();
  const online = useOnline();
  const [packs, setPacks] = useState<OfflinePack[]>([]);
  useEffect(() => {
    listPacks().then(setPacks).catch(() => setPacks([]));
  }, []);
  if (!profile) return null;

  return (
    <div>
      <PageTitle title={t(locale, "subjects")} lede={t(locale, "tagline")} />
      {!online ? <p className="mb-4 rounded-2xl bg-danger-soft px-4 py-3 text-sm text-danger">{t(locale, "offlineBanner")}</p> : null}
      <ul className="grid gap-3 sm:grid-cols-2">
        {subjects.map((subject) => {
          const chapters = chaptersForGrade(subject, profile.grade);
          const done = chapters.filter((chapter) =>
            progress.some(
              (row) => row.kind === "lesson" && row.itemId === lessonItemId(subject.id, chapter.id) && row.completed,
            ),
          ).length;
          return (
            <li key={subject.id}>
              <Link
                to="/learn/$subjectId"
                params={{ subjectId: subject.id }}
                className="block rounded-2xl border border-line bg-card p-4"
              >
                <SubjectGlyph name={subject.icon} className="size-5 text-teal" />
                <h2 className="mt-3 text-lg font-semibold">{tx(locale, subject.title)}</h2>
                <p className="mt-1 text-sm text-muted">{tx(locale, subject.blurb)}</p>
                <p className="mt-3 text-sm font-semibold tabular-nums text-teal-deep">
                  {fill(t(locale, "chapterCount"), { n: chapters.length })} · {done}/{chapters.length}
                </p>
              </Link>
            </li>
          );
        })}
      </ul>
      <h2 className="mb-3 mt-8 text-sm font-semibold text-muted">{t(locale, "downloadedLib")}</h2>
      {packs.length === 0 ? (
        <p className="text-sm text-muted">{t(locale, "nothingDownloaded")}</p>
      ) : (
        <ul className="space-y-2">
          {packs.map((pack) => (
            <li key={pack.id} className="rounded-2xl border border-line bg-card px-4 py-3 text-sm">
              <p className="font-semibold">{pack.title}</p>
              <p className="text-muted">{t(locale, "savedDevice")}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
