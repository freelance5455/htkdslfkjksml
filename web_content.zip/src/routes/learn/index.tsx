import { createFileRoute, Link } from "@tanstack/react-router";
import { Page } from "@/components/ui";
import { LESSONS } from "@/data/learn";

export const Route = createFileRoute("/learn/")({ component: LearnHome });

function LearnHome() {
  return (
    <Page title="مركز تعليم الإسلام" subtitle="دروس مختصرة. إذا كان في المسألة خلاف معتبر ذُكر، ولا تُعرض كإجماع.">
      <ul className="space-y-2">
        {LESSONS.map((l) => (
          <li key={l.id}>
            <Link to="/learn/$id" params={{ id: l.id }} className="block rounded-2xl border border-line bg-card px-4 py-3">
              <span className="text-xs text-gold">{l.level}</span>
              <span className="block font-bold">{l.title}</span>
            </Link>
          </li>
        ))}
      </ul>
    </Page>
  );
}
