import { Link, createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppFrame } from "@/components/shell";
import { QuizRunner } from "@/components/quiz-runner";
import { Button } from "@/components/ui/button";
import { useEdu } from "@/components/edu-provider";
import { t } from "@/content/copy";
import { findChapter, lessonItemId } from "@/content/catalog";
import { tx, useLocale } from "@/lib/locale";
import { hasPack, removePack, savePack } from "@/lib/offline";
import { useOnline } from "@/lib/use-online";

export const Route = createFileRoute("/learn/$subjectId/$chapterId")({ component: ChapterPage });

function ChapterPage() {
  return (
    <AppFrame>
      <ChapterBody />
    </AppFrame>
  );
}

function ChapterBody() {
  const { subjectId, chapterId } = Route.useParams();
  const locale = useLocale((state) => state.locale);
  const { profile, progress, recordLesson, recordQuiz } = useEdu();
  const online = useOnline();
  const found = findChapter(subjectId, chapterId);
  const packId = lessonItemId(subjectId, chapterId);
  const [saved, setSaved] = useState(false);
  const [note, setNote] = useState<string | null>(null);

  useEffect(() => {
    hasPack(packId).then(setSaved).catch(() => setSaved(false));
  }, [packId]);

  if (!profile || !found.subject || !found.chapter) {
    return <p className="text-sm text-muted">{t(locale, "notFound")}</p>;
  }
  if (!found.chapter.grades.includes(profile.grade)) {
    return (
      <div>
        <p className="text-sm text-muted">{t(locale, "notFound")}</p>
        <Link to="/learn/$subjectId" params={{ subjectId }} className="mt-3 inline-flex min-h-11 items-center font-semibold text-teal-deep">
          {t(locale, "back")}
        </Link>
      </div>
    );
  }

  const chapter = found.chapter;
  const subject = found.subject;
  const read = progress.some((row) => row.kind === "lesson" && row.itemId === packId && row.completed);

  if (!online && !saved) {
    return (
      <div>
        <h1 className="text-2xl font-semibold">{tx(locale, chapter.title)}</h1>
        <p className="mt-3 text-sm text-danger">{t(locale, "needsDownload")}</p>
        <Link to="/learn" className="mt-4 inline-flex min-h-11 items-center font-semibold text-teal-deep">
          {t(locale, "back")}
        </Link>
      </div>
    );
  }

  return (
    <article>
      <Link to="/learn/$subjectId" params={{ subjectId }} className="text-sm font-semibold text-teal-deep">
        {tx(locale, subject.title)}
      </Link>
      <h1 className="mt-2 text-2xl font-semibold">{tx(locale, chapter.title)}</h1>
      <p className="mt-2 max-w-prose text-muted">{tx(locale, chapter.summary)}</p>
      <div className="mt-4 flex flex-wrap gap-2">
        <Button
          variant={saved ? "secondary" : "primary"}
          onClick={() => {
            void (async () => {
              if (saved) {
                await removePack(packId);
                setSaved(false);
              } else {
                await savePack({
                  id: packId,
                  kind: "chapter",
                  title: tx(locale, chapter.title),
                  savedAt: Date.now(),
                  payload: chapter,
                });
                setSaved(true);
              }
            })();
          }}
        >
          {saved ? t(locale, "remove") : t(locale, "download")}
        </Button>
        {saved ? <span className="inline-flex min-h-11 items-center text-sm text-muted">{t(locale, "savedDevice")}</span> : null}
      </div>
      <div className="mt-6 max-w-prose space-y-4">
        {chapter.paragraphs.map((paragraph) => (
          <p key={paragraph.en}>{tx(locale, paragraph)}</p>
        ))}
      </div>
      <div className="mt-6">
        {read ? (
          <p className="text-sm font-semibold text-teal-deep">{t(locale, "finishedReading")}</p>
        ) : (
          <Button
            variant="secondary"
            onClick={() => {
              void recordLesson(subject.id, chapter.id).then((result) => {
                setNote(result.synced ? t(locale, "finishedReading") : t(locale, "syncLater"));
              });
            }}
          >
            {t(locale, "markRead")}
          </Button>
        )}
        {note ? <p className="mt-2 text-sm text-muted">{note}</p> : null}
      </div>
      <h2 className="mb-3 mt-8 text-lg font-semibold">{t(locale, "practice")}</h2>
      <QuizRunner
        questions={chapter.questions}
        locale={locale}
        mode="all"
        submitLabel={t(locale, "checkAnswers")}
        onSubmit={(answers) => recordQuiz(subject.id, chapter.id, answers)}
      />
    </article>
  );
}
