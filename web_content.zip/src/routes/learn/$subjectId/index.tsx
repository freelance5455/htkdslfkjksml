import { Link, createFileRoute } from "@tanstack/react-router";
import { AppFrame, PageTitle } from "@/components/shell";
import { useEdu } from "@/components/edu-provider";
import { t } from "@/content/copy";
import { chaptersForGrade, findSubject, lessonItemId, quizItemId } from "@/content/catalog";
import { fill, tx, useLocale } from "@/lib/locale";

export const Route = createFileRoute("/learn/$subjectId/")({ component: SubjectPage });

function SubjectPage() {
  return (
    <AppFrame>
      <SubjectBody />
    </AppFrame>
  );
}

function SubjectBody() {
  const { subjectId } = Route.useParams();
  const locale = useLocale((state) => state.locale);
  const { profile, progress } = useEdu();
  const subject = findSubject(subjectId);
  if (!profile) return null;
  if (!subject) {
    return (
      <div>
        <PageTitle title={t(locale, "notFound")} />
        <Link to="/learn" className="text-sm font-semibold text-teal-deep">
          {t(locale, "back")}
        </Link>
      </div>
    );
  }
  const chapters = chaptersForGrade(subject, profile.grade);

  return (
    <div>
      <PageTitle title={tx(locale, subject.title)} lede={tx(locale, subject.blurb)} />
      <ol className="space-y-3">
        {chapters.map((chapter, index) => {
          const read = progress.some(
            (row) => row.kind === "lesson" && row.itemId === lessonItemId(subject.id, chapter.id) && row.completed,
          );
          const quiz = progress.find(
            (row) => row.kind === "quiz" && row.itemId === quizItemId(subject.id, chapter.id),
          );
          return (
            <li key={chapter.id}>
              <Link
                to="/learn/$subjectId/$chapterId"
                params={{ subjectId: subject.id, chapterId: chapter.id }}
                className="block rounded-2xl border border-line bg-card p-4"
              >
                <p className="text-sm font-semibold text-muted">
                  {index + 1} · {t(locale, "chapters")}
                </p>
                <h2 className="mt-1 text-lg font-semibold">{tx(locale, chapter.title)}</h2>
                <p className="mt-1 text-sm text-muted">{tx(locale, chapter.summary)}</p>
                <p className="mt-3 text-sm font-semibold text-teal-deep">
                  {!read && !quiz
                    ? t(locale, "notStarted")
                    : quiz
                      ? `${t(locale, "yourScore")} ${fill(t(locale, "outOf"), { score: quiz.score ?? 0, total: quiz.total ?? 0 })}`
                      : t(locale, "read")}
                </p>
              </Link>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
