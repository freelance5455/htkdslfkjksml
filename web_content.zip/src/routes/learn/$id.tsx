import { createFileRoute } from "@tanstack/react-router";
import { Page } from "@/components/ui";
import { LESSONS } from "@/data/learn";

export const Route = createFileRoute("/learn/$id")({ component: LessonPage });

function LessonPage() {
  const lesson = LESSONS.find((l) => l.id === Route.useParams().id);
  if (!lesson) return <Page title="غير موجود" back>لا يوجد هذا الدرس.</Page>;
  return (
    <Page title={lesson.title} subtitle={lesson.level} back>
      {lesson.sections.map((s) => (
        <section key={s.h} className="mb-4">
          <h2 className="font-bold text-emerald">{s.h}</h2>
          <p className="mt-1 text-sm leading-relaxed">{s.p}</p>
        </section>
      ))}
      <p className="text-xs text-muted">هذا تعليم عام، والنازلة الخاصة يُسأل فيها عالم.</p>
    </Page>
  );
}
