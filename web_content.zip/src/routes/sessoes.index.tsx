import { useMemo, useState } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { formatShortDate } from "@/lib/dates";
import { SESSION_TYPE_LABEL } from "@/lib/defaults";
import { useAppStore } from "@/lib/store";
import type { SessionType } from "@/lib/types";
import { cn, formatDuration } from "@/lib/utils";

export const Route = createFileRoute("/sessoes/")({ component: SessionsPage });

const FILTERS: { id: "all" | SessionType; label: string }[] = [
  { id: "all", label: "Todos" },
  { id: "muay-thai", label: "Muay Thai" },
  { id: "superior", label: "Superior" },
  { id: "inferior", label: "Inferior + Core" },
  { id: "postura", label: "Postura" },
  { id: "recuperacao", label: "Recuperação" },
];

function SessionsPage() {
  const sessions = useAppStore((s) => s.sessions);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");
  const list = useMemo(
    () => sessions.filter((s) => (filter === "all" ? true : s.type === filter)),
    [sessions, filter],
  );

  return (
    <div className="animate-in fade-in duration-300">
      <PageHeader
        kicker="Histórico"
        title="Sessões"
        subtitle="Treinos e rotinas de postura já salvos."
      />
      <div className="-mx-4 mb-4 flex gap-2 overflow-x-auto px-4 pb-1">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setFilter(f.id)}
            className={cn(
              "h-9 shrink-0 rounded-full px-3 text-xs font-medium",
              filter === f.id
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>
      {list.length === 0 ? (
        <Card className="p-6 text-sm text-muted-foreground">
          Nenhuma sessão neste filtro. Inicie um treino para registrar.
        </Card>
      ) : (
        <div className="space-y-3">
          {list.map((s) => (
            <Link
              key={s.id}
              to="/sessoes/$id"
              params={{ id: s.id }}
              className="block"
            >
              <Card className="flex items-center gap-3 p-4 transition-colors hover:border-primary/40">
                <div className="min-w-0 flex-1">
                  <p className="text-xs text-muted-foreground">
                    {formatShortDate(s.date)}
                  </p>
                  <p className="font-display font-semibold">
                    {SESSION_TYPE_LABEL[s.type]}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDuration(s.durationSec)} ·{" "}
                    {s.exercises.reduce((a, e) => a + e.completedSets, 0)} séries
                  </p>
                </div>
                <Badge tone="success">Concluído</Badge>
                <ChevronRight className="size-4 text-muted-foreground" />
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
