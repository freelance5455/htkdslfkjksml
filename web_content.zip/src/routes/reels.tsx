import { createFileRoute } from "@tanstack/react-router";
import { useSalon } from "@/lib/cutegirls/store";
import { FeedView } from "@/components/feed-view";
import { Shell } from "@/components/shell";
import { primaryBtn } from "@/components/bits";
import { useMeId } from "@/components/use-me-id";

export const Route = createFileRoute("/reels")({ component: ReelsPage });

function ReelsPage() {
  return (
    <Shell>
      <Reels />
    </Shell>
  );
}

function Reels() {
  const meId = useMeId();
  const openCompose = useSalon((s) => s.openCompose);
  if (!meId) return null;
  return (
    <div className="mx-auto w-full max-w-xl space-y-4">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-xs tracking-widest text-rose">ميمز</p>
          <h1 className="font-display text-4xl">ريلز</h1>
        </div>
        <button type="button" className={primaryBtn} onClick={() => openCompose({ kind: "reel" })}>
          نشر ميم
        </button>
      </header>
      <FeedView
        meId={meId}
        query={{ surface: "reels" }}
        variant="reel"
        emptyTitle="لا ريلز بعد"
        emptyBody="ارفع صورة ميم. تظهر للجميع في هذا الشريط."
      />
    </div>
  );
}
