import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { MoneyText } from "@/components/fields";
import { Card, PageTitle } from "@/components/ui";
import { getLiquidity } from "@/lib/server/books";
import { useQuery } from "@tanstack/react-query";

export const Route = createFileRoute("/liquidity")({ component: LiquidityPage });

function LiquidityPage() {
  const q = useQuery({ queryKey: ["liq"], queryFn: () => getLiquidity() });
  const d = q.data;
  return (
    <AppShell>
      <PageTitle title="مدیریت نقدینگی" subtitle="موجودی منابع، چک‌ها و پیش‌بینی ۷ و ۳۰ روزه" />
      {d && (
        <>
          <div className="mb-4 rounded-xl bg-navy p-5 text-paper">
            <p className="text-xs text-gold/80">جمع کل نقدینگی</p>
            <p className="mt-1 text-3xl font-semibold text-gold-soft"><MoneyText value={d.cash} className="text-gold-soft" /></p>
          </div>
          <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Card><p className="text-xs text-muted">مطالبات</p><p className="text-lg font-semibold"><MoneyText value={d.ar} /></p></Card>
            <Card><p className="text-xs text-muted">بدهی‌ها</p><p className="text-lg font-semibold"><MoneyText value={d.ap} /></p></Card>
            <Card><p className="text-xs text-muted">پیش‌بینی ۷ روز</p><p className="text-lg font-semibold"><MoneyText value={d.forecast7} /></p></Card>
            <Card><p className="text-xs text-muted">پیش‌بینی ۳۰ روز</p><p className="text-lg font-semibold"><MoneyText value={d.forecast30} /></p></Card>
          </div>
          <h2 className="mb-2 text-sm font-medium text-navy">منابع مالی</h2>
          <div className="grid gap-2 sm:grid-cols-2">
            {d.sourceBalances.map((s) => (
              <div key={s.id} className="flex items-center justify-between rounded-xl border border-line bg-card px-4 py-3">
                <span>{s.name}</span>
                <MoneyText value={s.balance} className="font-medium" />
              </div>
            ))}
          </div>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <Card>
              <p className="text-xs text-muted">چک دریافتنی ۷ / ۳۰ روز</p>
              <p className="mt-1"><MoneyText value={d.checksIn7} /> / <MoneyText value={d.checksIn30} /></p>
            </Card>
            <Card>
              <p className="text-xs text-muted">چک پرداختنی ۷ / ۳۰ روز</p>
              <p className="mt-1"><MoneyText value={d.checksOut7} /> / <MoneyText value={d.checksOut30} /></p>
            </Card>
          </div>
        </>
      )}
    </AppShell>
  );
}
