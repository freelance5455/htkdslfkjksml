import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/shell";
import { Field, Modal } from "@/components/ui";
import { CATALOG, findCatalog } from "@/lib/catalog";
import { CLASS_LABEL, KIND_LABEL, SIDE_LABEL, formatDay, formatMoney, formatQty, todayIso, uid } from "@/lib/format";
import { fxToHuf } from "@/lib/portfolio-math";
import { usePortfolio } from "@/lib/portfolio-context";
import type { AssetClass, Currency, Tx, TxSide } from "@/lib/types";

export const Route = createFileRoute("/mozgasok")({ component: Page });

function Page() {
  return (
    <Shell>
      <Ledger />
    </Shell>
  );
}

function num(value: string): number {
  const parsed = Number(value.replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(parsed) ? parsed : NaN;
}

function Ledger() {
  const { state, saveTx, deleteTx, refresh } = usePortfolio();
  const [open, setOpen] = useState(false);
  const rows = [...state.transactions].sort((a, b) => b.date.localeCompare(a.date));
  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl">Mozgások</h1>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Vétel és eladás frissíti az állományt. Osztalék és díj csak a naplóba kerül. A törlés nem számolja vissza a készletet.
          </p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>
          Új mozgás
        </button>
      </div>
      <ul className="mt-8 divide-y divide-line border-t border-line">
        {rows.map((tx) => (
          <li key={tx.id} className="grid gap-2 py-4 sm:grid-cols-[7rem_1fr_auto] sm:items-baseline">
            <p className="text-sm text-muted tabular-nums">{formatDay(tx.date)}</p>
            <div>
              <p>
                {SIDE_LABEL[tx.side]} · {tx.name} <span className="text-sm text-muted">{tx.symbol}</span>
              </p>
              <p className="text-sm text-muted">
                {state.groups.find((group) => group.id === tx.groupId)?.name} · {formatQty(tx.quantity)} × {formatMoney(tx.price, tx.currency)}
                {tx.note ? ` · ${tx.note}` : ""}
              </p>
            </div>
            <button type="button" className="btn btn-quiet justify-start text-clay sm:justify-center" onClick={() => deleteTx(tx.id)}>
              Töröl a naplóból
            </button>
          </li>
        ))}
        {rows.length === 0 ? <li className="py-10 text-sm text-muted">Még nincs mozgás.</li> : null}
      </ul>
      <TxDialog
        open={open}
        onClose={() => setOpen(false)}
        onSave={(tx, apply) => {
          saveTx(tx, apply);
          setOpen(false);
          if (apply) void refresh();
        }}
      />
    </div>
  );
}

function TxDialog({ open, onClose, onSave }: { open: boolean; onClose: () => void; onSave: (tx: Tx, apply: boolean) => void }) {
  const { state } = usePortfolio();
  const [side, setSide] = useState<TxSide>("vetel");
  const [source, setSource] = useState("VWCE");
  const [symbol, setSymbol] = useState("");
  const [name, setName] = useState("");
  const [assetClass, setAssetClass] = useState<AssetClass>("etf");
  const [currency, setCurrency] = useState<Currency>("EUR");
  const [groupId, setGroupId] = useState(state.groups[0]?.id ?? "");
  const [date, setDate] = useState(todayIso());
  const [quantity, setQuantity] = useState("");
  const [price, setPrice] = useState("");
  const [fx, setFx] = useState("");
  const [note, setNote] = useState("");
  const [apply, setApply] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setSide("vetel");
    setSource("VWCE");
    setDate(todayIso());
    setQuantity("");
    setPrice("");
    setFx("");
    setNote("");
    setApply(true);
    setError("");
    setGroupId(state.groups[0]?.id ?? "");
  }, [open, state.groups]);

  const known = source === "custom" ? undefined : findCatalog(source);
  const resolvedClass = known?.assetClass ?? assetClass;
  const resolvedCurrency = known?.currency ?? currency;

  const save = () => {
    const qty = num(quantity);
    const px = num(price);
    const fxInput = num(fx);
    const rate = Number.isFinite(fxInput) && fxInput > 0 ? fxInput : fxToHuf(resolvedCurrency, state.market.fx);
    const sym = (known?.symbol ?? symbol).trim().toUpperCase();
    if (!sym || !groupId) return setError("Szimbólum és csoport kell.");
    if (!Number.isFinite(qty) || qty < 0 || !Number.isFinite(px) || px < 0) return setError("Mennyiség és ár szám legyen.");
    onSave(
      {
        id: uid(),
        date,
        side,
        symbol: sym,
        name: name || known?.name || sym,
        assetClass: resolvedClass,
        currency: resolvedCurrency,
        groupId,
        quantity: qty,
        price: px,
        fxToHuf: resolvedCurrency === "HUF" ? 1 : rate,
        note: note.trim(),
      },
      apply && (side === "vetel" || side === "eladas"),
    );
  };

  return (
    <Modal open={open} title="Mozgás" onClose={onClose} description="A vétel súlyozza a bekerülési árat és a régi devizaárfolyamot.">
      <div className="grid gap-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Típus">
            <select className="field" value={side} onChange={(event) => setSide(event.target.value as TxSide)}>
              {(Object.keys(SIDE_LABEL) as TxSide[]).map((item) => (
                <option key={item} value={item}>
                  {SIDE_LABEL[item]}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Dátum">
            <input className="field" type="date" value={date} onChange={(event) => setDate(event.target.value)} />
          </Field>
        </div>
        <Field label="Eszköz">
          <select className="field" value={source} onChange={(event) => setSource(event.target.value)}>
            {CATALOG.map((item) => (
              <option key={item.symbol} value={item.symbol}>
                {item.symbol} · {item.name}
              </option>
            ))}
            <option value="custom">Saját</option>
          </select>
        </Field>
        {source === "custom" ? (
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Szimbólum">
              <input className="field" value={symbol} onChange={(event) => setSymbol(event.target.value)} />
            </Field>
            <Field label="Név">
              <input className="field" value={name} onChange={(event) => setName(event.target.value)} />
            </Field>
            <Field label="Osztály">
              <select className="field" value={assetClass} onChange={(event) => setAssetClass(event.target.value as AssetClass)}>
                {(Object.keys(CLASS_LABEL) as AssetClass[]).map((item) => (
                  <option key={item} value={item}>
                    {CLASS_LABEL[item]}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Deviza">
              <select className="field" value={currency} onChange={(event) => setCurrency(event.target.value as Currency)}>
                {(["HUF", "EUR", "USD", "GBP"] as Currency[]).map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
            </Field>
          </div>
        ) : null}
        <Field label="Csoport">
          <select className="field" value={groupId} onChange={(event) => setGroupId(event.target.value)}>
            {state.groups.map((group) => (
              <option key={group.id} value={group.id}>
                {group.name} · {KIND_LABEL[group.kind]}
              </option>
            ))}
          </select>
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Mennyiség">
            <input className="field tabular-nums" inputMode="decimal" value={quantity} onChange={(event) => setQuantity(event.target.value)} />
          </Field>
          <Field label={`Ár (${resolvedCurrency})`}>
            <input className="field tabular-nums" inputMode="decimal" value={price} onChange={(event) => setPrice(event.target.value)} />
          </Field>
        </div>
        {resolvedCurrency !== "HUF" ? (
          <Field label="Forintárfolyam aznap">
            <input className="field tabular-nums" inputMode="decimal" value={fx} placeholder={String(Math.round(fxToHuf(resolvedCurrency, state.market.fx)))} onChange={(event) => setFx(event.target.value)} />
          </Field>
        ) : null}
        <Field label="Megjegyzés">
          <input className="field" value={note} onChange={(event) => setNote(event.target.value)} />
        </Field>
        <label className="flex min-h-11 items-center gap-3 text-sm">
          <input type="checkbox" className="size-5 accent-pine" checked={apply} onChange={(event) => setApply(event.target.checked)} />
          Alkalmazd az állományra, ha vétel vagy eladás
        </label>
        {error ? <p className="text-sm text-clay">{error}</p> : null}
        <div className="mt-2 flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Mégse
          </button>
          <button type="button" className="btn btn-primary" onClick={save}>
            Rögzít
          </button>
        </div>
      </div>
    </Modal>
  );
}
