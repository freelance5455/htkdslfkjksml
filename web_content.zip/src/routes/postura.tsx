import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Pencil, Play } from "lucide-react";
import { toast } from "sonner";
import { LiveExerciseCard } from "@/components/exercise-card";
import { PageHeader } from "@/components/page-header";
import { WorkoutEditor } from "@/components/workout-editor";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toDateKey } from "@/lib/dates";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/postura")({ component: PosturaPage });

function PosturaPage() {
  const posture = useAppStore((s) => s.posture);
  const active = useAppStore((s) => s.activeSession);
  const startSession = useAppStore((s) => s.startSession);
  const completeSet = useAppStore((s) => s.completeSet);
  const undoSet = useAppStore((s) => s.undoSet);
  const updateLiveExercise = useAppStore((s) => s.updateLiveExercise);
  const finishSession = useAppStore((s) => s.finishSession);
  const abandonSession = useAppStore((s) => s.abandonSession);
  const setSessionNotes = useAppStore((s) => s.setSessionNotes);
  const updatePostureExercise = useAppStore((s) => s.updatePostureExercise);
  const addPostureExercise = useAppStore((s) => s.addPostureExercise);
  const removePostureExercise = useAppStore((s) => s.removePostureExercise);
  const duplicatePostureExercise = useAppStore((s) => s.duplicatePostureExercise);
  const movePostureExercise = useAppStore((s) => s.movePostureExercise);
  const restorePosture = useAppStore((s) => s.restorePosture);
  const [editing, setEditing] = useState(false);
  const [finishOpen, setFinishOpen] = useState(false);

  const live = active?.type === "postura" ? active : null;

  function start() {
    if (active && active.type !== "postura") {
      toast.error("Finalize a sessão em andamento antes de começar outra.");
      return;
    }
    startSession({
      date: toDateKey(new Date()),
      dayKey: "postura",
      exercises: posture,
      type: "postura",
      title: "Rotina de postura",
    });
    setEditing(false);
    toast.success("Rotina iniciada");
  }

  return (
    <div className="animate-in fade-in duration-300">
      <PageHeader
        kicker="Mobilidade"
        title="Postura & Mobilidade"
        subtitle="Rotina própria — não entra no treino de terça ou quinta."
        action={
          live ? null : (
            <Button
              variant={editing ? "secondary" : "outline"}
              size="sm"
              onClick={() => setEditing((v) => !v)}
            >
              <Pencil /> {editing ? "Fechar" : "Editar"}
            </Button>
          )
        }
      />

      {live ? (
        <Card className="mb-4 flex items-center justify-between gap-3 p-4">
          <div>
            <p className="text-xs text-muted-foreground">Rotina em andamento</p>
            <p className="font-mono text-lg font-semibold tabular-nums">
              {live.exercises.reduce((a, e) => a + e.completedSets, 0)}/
              {live.exercises.reduce((a, e) => a + e.sets, 0)} séries
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={abandonSession}>
              Descartar
            </Button>
            <Button size="sm" onClick={() => setFinishOpen(true)}>
              Finalizar
            </Button>
          </div>
        </Card>
      ) : editing ? null : (
        <Button className="mb-4 w-full" size="lg" onClick={start}>
          <Play /> Iniciar rotina de postura
        </Button>
      )}

      {editing && !live ? (
        <WorkoutEditor
          exercises={posture}
          handlers={{
            onUpdate: (id, patch) => updatePostureExercise(id, patch),
            onAdd: () => addPostureExercise(),
            onRemove: (id) => removePostureExercise(id),
            onDuplicate: (id) => duplicatePostureExercise(id),
            onMove: (id, dir) => movePostureExercise(id, dir),
            onRestore: () => restorePosture(),
          }}
        />
      ) : live ? (
        <div className="space-y-3">
          {live.exercises.map((ex) => (
            <LiveExerciseCard
              key={ex.id}
              exercise={ex}
              onCompleteSet={() => completeSet(ex.id)}
              onUndoSet={() => undoSet(ex.id)}
              onPatch={(patch) => updateLiveExercise(ex.id, patch)}
            />
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {posture.map((ex) => (
            <Card key={ex.id} className="p-4">
              <h3 className="font-display font-semibold">{ex.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {ex.sets} × {ex.reps} · descanso {ex.restSec}s
              </p>
              {ex.notes ? (
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {ex.notes}
                </p>
              ) : null}
            </Card>
          ))}
        </div>
      )}

      <Dialog open={finishOpen} onOpenChange={setFinishOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Finalizar rotina</DialogTitle>
            <DialogDescription>Salva como sessão de postura.</DialogDescription>
          </DialogHeader>
          <Textarea
            value={live?.notes ?? ""}
            onChange={(e) => setSessionNotes(e.target.value)}
            placeholder="Observações"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setFinishOpen(false)}>
              Voltar
            </Button>
            <Button
              onClick={() => {
                finishSession();
                setFinishOpen(false);
                toast.success("Sessão salva");
              }}
            >
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
