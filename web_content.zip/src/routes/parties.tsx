import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Button, Field, Input, Modal, PageTitle, Select, TableWrap, Td, Th } from "@/components/ui";
import { bootstrap, getPartyCard, saveParty } from "@/lib/server/books";
import { MoneyText } from "@/components/fields";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { downloadCsv } from "@/lib/utils";
import { isoToJalali } from "@/lib/accounting/jalali";

export const Route = createFileRoute("/parties")({ component: PartiesPage });

function PartiesPage() {
  const qc = useQueryClient();
  const boot = useQuery({ queryKey: ["bootstrap"], queryFn: () => bootstrap() });
  const [open, setOpen] = useState(false);
  const [cardId, setCardId] = useState<string | null>(null);
  const card = useQuery({
    queryKey: ["party", cardId],
    queryFn: () => getPartyCard({ data: { partyId: cardId! } }),
    enabled: !!cardId,
  });
  const parties = (boot.data?.parties ?? []) as Array<Record<string, unknown>>;

  return (
    <AppShell>
      <PageTitle
        title="اشخاص"
        subtitle="یک شناسه یکتا برای مشتری، تأمین‌کننده، کارمند و شریک"
        actions={<Button onClick={() => setOpen(true)}>+ شخص جدید</Button>}
      />
      <TableWrap>
        <thead>
          <tr>
            <Th>کد</Th>
            <Th>نام</Th>
            <Th>نقش</Th>
            <Th>تماس</Th>
            <Th />
          </tr>
        </thead>
        <tbody>
          {parties.map((p) => (
            <tr key={String(p.id)}>
              <Td className="tabular">{String(p.code)}</Td>
              <Td>{String(p.name)}</Td>
              <Td className="text-xs text-muted">
                {p.is_customer ? "مشتری " : ""}
                {p.is_supplier ? "تأمین‌کننده " : ""}
                {p.is_employee ? "کارمند " : ""}
                {p.is_partner ? "شریک" : ""}
              </Td>
              <Td>{String(p.mobile ?? "")}</Td>
              <Td>
                <button type="button" className="text-xs text-navy" onClick={() => setCardId(String(p.id))}>
                  کارت حساب
                </button>
              </Td>
            </tr>
          ))}
        </tbody>
      </TableWrap>
      <PartyForm
        open={open}
        onClose={() => setOpen(false)}
        onSaved={() => {
          setOpen(false);
          qc.invalidateQueries();
        }}
      />
      <Modal open={!!cardId} onClose={() => setCardId(null)} title="کارت حساب شخص">
        {card.data && (
          <div className="space-y-3">
            <p className="font-medium text-navy">{String(card.data.party.name)}</p>
            <div className="max-h-64 overflow-auto text-sm">
              {(card.data.lines as Array<Record<string, unknown>>).map((l) => (
                <div key={String(l.id)} className="flex justify-between border-b border-line py-1">
                  <span>
                    {isoToJalali(String(l.date))} — {String(l.account_name)}
                  </span>
                  <span>
                    <MoneyText value={Number(l.debit) - Number(l.credit)} />
                  </span>
                </div>
              ))}
            </div>
            <Button
              variant="secondary"
              className="w-full"
              onClick={() =>
                downloadCsv(
                  "party-card.csv",
                  ["date", "account", "debit", "credit"],
                  (card.data!.lines as Array<Record<string, unknown>>).map((l) => [
                    String(l.jalali_date),
                    String(l.account_name),
                    String(l.debit),
                    String(l.credit),
                  ]),
                )
              }
            >
              خروجی Excel
            </Button>
          </div>
        )}
      </Modal>
    </AppShell>
  );
}

function PartyForm({ open, onClose, onSaved }: { open: boolean; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [mobile, setMobile] = useState("");
  const [nationalId, setNationalId] = useState("");
  const [role, setRole] = useState("customer");
  return (
    <Modal open={open} onClose={onClose} title="ثبت شخص">
      <form
        className="space-y-3"
        onSubmit={async (e) => {
          e.preventDefault();
          try {
            const res = await saveParty({
              data: {
                name,
                code: code || `P${Date.now().toString().slice(-4)}`,
                mobile,
                nationalId,
                isCustomer: role !== "supplier",
                isSupplier: role !== "customer",
              },
            });
            if (res.duplicates?.length) toast.message("احتمال رکورد تکراری. با دقت بررسی کنید.");
            toast.success("شخص ذخیره شد.");
            onSaved();
          } catch (err) {
            toast.error(err instanceof Error ? err.message : "خطا");
          }
        }}
      >
        <Field label="نام"><Input required value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="کد"><Input value={code} onChange={(e) => setCode(e.target.value)} /></Field>
        <Field label="موبایل"><Input value={mobile} onChange={(e) => setMobile(e.target.value)} /></Field>
        <Field label="کد ملی / شناسه"><Input value={nationalId} onChange={(e) => setNationalId(e.target.value)} /></Field>
        <Field label="نوع ارتباط">
          <Select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="customer">مشتری</option>
            <option value="supplier">تأمین‌کننده</option>
            <option value="both">هر دو</option>
          </Select>
        </Field>
        <Button type="submit" className="w-full">ذخیره</Button>
      </form>
    </Modal>
  );
}
