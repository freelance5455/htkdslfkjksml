import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { DayChecklist } from "@/components/day-checklist";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/dia/$date")({ component: DayPage });

function DayPage() {
  const { date } = Route.useParams();
  return (
    <div className="animate-in fade-in duration-300">
      <Button asChild variant="ghost" size="sm" className="-ml-2 mb-4">
        <Link to="/calendario">
          <ArrowLeft /> Calendário
        </Link>
      </Button>
      <DayChecklist date={date} />
    </div>
  );
}
