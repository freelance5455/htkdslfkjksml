import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Pair, SignRow } from "@/components/pair";
import { chapterBySlug, CHAPTERS } from "@/data/curriculum";
import { questionsByChapter } from "@/data/quiz";
import { useStudy } from "@/lib/study-store";

export const Route = createFileRoute("/manuale/$slug")({
  component: ChapterPage,
  notFoundComponent: () => (
    <p>
      الفصل غير موجود. <Link to="/manuale">العودة للمنهج</Link>
    </p>
  ),
});

function ChapterPage() {
  const { slug } = Route.useParams();
  const chapter = chapterBySlug(slug);
  const markRead = useStudy((s) => s.markRead);
  const read = useStudy((s) => s.read.includes(slug));
  if (!chapter) throw notFound();
  const index = CHAPTERS.findIndex((c) => c.slug === slug);
  const prev = CHAPTERS[index - 1];
  const next = CHAPTERS[index + 1];
  const quizCount = questionsByChapter(chapter.n).length;

  return (
    <article className="space-y-6">
      <header>
        <Link to="/manuale" className="text-sm text-primary">
          كل الفصول
        </Link>
        <p className="mt-2 text-sm text-muted">
          فصل {chapter.n} من {CHAPTERS.length}
        </p>
        <h1 className="text-3xl font-semibold leading-tight">{chapter.titleAr}</h1>
        <p dir="ltr" lang="it" className="text-left text-lg text-muted">
          {chapter.titleIt}
        </p>
      </header>
      <div className="space-y-6">
        {chapter.blocks.map((block, i) => {
          if (block.k === "signs") return <SignRow key={i} ids={block.ids} />;
          if (block.k === "h") {
            return (
              <h2 key={i} className="border-t border-line pt-4 text-2xl font-semibold">
                <span dir="ltr" lang="it" className="mb-1 block text-left text-base font-medium text-muted">
                  {block.it}
                </span>
                {block.ar}
              </h2>
            );
          }
          if (block.k === "note") {
            return (
              <aside key={i} className="space-y-2 rounded-2xl bg-warn px-3 py-3 text-warn-ink">
                <Pair it={block.it} ar={block.ar} />
              </aside>
            );
          }
          return <Pair key={i} it={block.it} ar={block.ar} />;
        })}
      </div>
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => markRead(chapter.slug)}
          className="min-h-11 rounded-full bg-primary px-4 text-primary-fg"
        >
          {read ? "معلَّم كمقروء" : "علّم الفصل كمقروء"}
        </button>
        <Link
          to="/esame"
          search={{ ch: chapter.n }}
          className="inline-flex min-h-11 items-center rounded-full border border-line px-4"
        >
          تدرب على {quizCount} سؤالًا
        </Link>
      </div>
      <nav className="flex justify-between gap-3 border-t border-line pt-4 text-sm">
        {prev ? (
          <Link to="/manuale/$slug" params={{ slug: prev.slug }} className="text-primary">
            السابق: {prev.titleAr}
          </Link>
        ) : (
          <span />
        )}
        {next ? (
          <Link to="/manuale/$slug" params={{ slug: next.slug }} className="text-primary">
            التالي: {next.titleAr}
          </Link>
        ) : null}
      </nav>
    </article>
  );
}
