import { createFileRoute, Link } from "@tanstack/react-router";
import { CHAPTERS } from "@/data/curriculum";
import { useStudy } from "@/lib/study-store";

export const Route = createFileRoute("/manuale/")({ component: Manuale });

function Manuale() {
  const read = useStudy((s) => s.read);
  return (
    <div className="space-y-5">
      <header>
        <p className="text-sm text-primary">Il programma</p>
        <h1 className="text-3xl font-semibold">المنهج</h1>
        <p className="mt-2 max-w-2xl text-muted">
          خمسة وعشرون فصلًا كما تُقسَّم نظرية الامتحان. النص الإيطالي فوق، والعربي في الإطار الأخضر. أي كلمة إيطالية تُضغط.
        </p>
      </header>
      <ol className="space-y-2">
        {CHAPTERS.map((ch) => {
          const done = read.includes(ch.slug);
          return (
            <li key={ch.slug}>
              <Link
                to="/manuale/$slug"
                params={{ slug: ch.slug }}
                className="flex items-start gap-3 rounded-2xl border border-line bg-surface px-3 py-3"
              >
                <span className={`mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-full text-sm font-semibold ${done ? "bg-primary text-primary-fg" : "bg-soft text-primary"}`}>
                  {ch.n}
                </span>
                <span className="min-w-0">
                  <span dir="ltr" lang="it" className="block text-left text-sm text-muted">
                    {ch.titleIt}
                  </span>
                  <span className="block text-lg font-semibold leading-snug">{ch.titleAr}</span>
                  <span className="mt-1 block text-sm text-muted">{ch.summaryAr}</span>
                </span>
              </Link>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
