import { createFileRoute } from "@tanstack/react-router";
import { WeekView } from "@/components/planner/views/week";

export const Route = createFileRoute("/week")({
  component: WeekView,
});
