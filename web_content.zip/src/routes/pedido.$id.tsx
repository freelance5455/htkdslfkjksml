import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { brl, formatDay, waHref } from "@/lib/format";
import { useStore } from "@/lib/store";
import { useHydrated } from "@/lib/use-hydrated";
import { usePublicProfile } from "@/lib/vitrine-context";
import { PixPanel } from "@/components/pix-panel";
import { Button } from "@/components/button";

const STATUS = {
  aguardando: "Aguardando o PIX",
  pago: "PIX confirmado",
  concluido: "Serviço feito",
  cancelado: "Cancelado",
} as const;

export const Route = createFileRoute("/pedido/$id")({
  component: PedidoPage,
});

function PedidoPage() {
  const { id } = Route.useParams();
  const hydrated = useHydrated();
  const booking = useStore((state) => state.bookings.find((item) => item.id === id));
  const markCustomerPaid = useStore((state) => state.markCustomerPaid);
  const profile = usePublicProfile();
  const [sent, setSent] = useState(false);

  if (!hydrated && !profile.fromLink) {
    return (
      <main className="mx-auto max-w-3xl px-4 py-12">
        <h1 className="font-display text-4xl">Pedido</h1>
        <p className="mt-2 text-muted">Abrindo…</p>
      </main>
    );
  }

  if (!booking) {
    return (
      <main className="mx-auto max-w-3xl px-4 py-12">
        <h1 className="font-display text-4xl">Pedido {id}</h1>
        <p className="mt-3 max-w-lg text-muted">
          Não está neste aparelho. O pedido fica no celular em que foi feito. Se você é o profissional, o cliente
          precisa te mandar pelo WhatsApp.
        </p>
      </main>
    );
  }

  const message = [
    `Pedido ${booking.id} na Precisa`,
    `${booking.serviceName} — ${booking.optionLabel}`,
    booking.extras.length ? `Extras: ${booking.extras.map((extra) => extra.label).join(", ")}` : "",
    `${formatDay(booking.date)} · ${booking.time}`,
    booking.weekly ? "Quer repetir toda semana" : "",
    `Cliente: ${booking.customerName}`,
    `Tel: ${booking.phone}`,
    `Bairro: ${booking.neighborhood}`,
    booking.notes ? `Notas: ${booking.notes}` : "",
    `Valor: ${brl(booking.amountCents)}`,
  ]
    .filter(Boolean)
    .join("\n");

  const href = waHref(profile.whatsapp, message);

  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <p className="text-sm font-semibold tracking-wide text-primary uppercase">{STATUS[booking.status]}</p>
      <h1 className="mt-2 font-display text-4xl">{booking.serviceName}</h1>
      <p className="mt-2 text-muted">
        {booking.id} · {formatDay(booking.date)} · {booking.time}
      </p>

      <dl className="mt-6 grid gap-3 rounded-lg border border-line bg-surface p-5 text-sm sm:grid-cols-2">
        <div>
          <dt className="text-muted">Opção</dt>
          <dd className="font-semibold">{booking.optionLabel}</dd>
        </div>
        <div>
          <dt className="text-muted">Onde</dt>
          <dd className="font-semibold">{booking.neighborhood}</dd>
        </div>
        <div>
          <dt className="text-muted">Cliente</dt>
          <dd className="font-semibold">
            {booking.customerName} · {booking.phone}
          </dd>
        </div>
        <div>
          <dt className="text-muted">Valor</dt>
          <dd className="font-semibold tabular-nums">{brl(booking.amountCents)}</dd>
        </div>
        {booking.extras.length > 0 ? (
          <div className="sm:col-span-2">
            <dt className="text-muted">Extras</dt>
            <dd>{booking.extras.map((extra) => extra.label).join(", ")}</dd>
          </div>
        ) : null}
        {booking.notes ? (
          <div className="sm:col-span-2">
            <dt className="text-muted">Notas</dt>
            <dd>{booking.notes}</dd>
          </div>
        ) : null}
      </dl>

      {booking.status === "cancelado" ? (
        <p className="mt-6 text-muted">Este horário foi cancelado. Se ainda precisar, faça um pedido novo.</p>
      ) : (
        <div className="mt-6 space-y-4">
          <PixPanel
            pixKey={profile.pixKey}
            receiverName={profile.receiverName}
            city={profile.city}
            amountCents={booking.amountCents}
            txid={booking.id}
          />
          {href ? (
            <a
              href={href}
              target="_blank"
              rel="noreferrer"
              onClick={() => setSent(true)}
              className="inline-flex min-h-11 w-full items-center justify-center rounded-md bg-primary px-4 font-semibold text-primary-fg hover:bg-primary-deep sm:w-auto"
            >
              {sent ? "WhatsApp aberto" : "Enviar pedido no WhatsApp"}
            </a>
          ) : (
            <p className="text-sm text-muted">
              Sem WhatsApp nesta vitrine. Mostre esta tela para o profissional ou copie o PIX.
            </p>
          )}
          {booking.status === "aguardando" ? (
            <Button
              variant="surface"
              disabled={booking.customerSaidPaid}
              onClick={() => markCustomerPaid(booking.id)}
            >
              {booking.customerSaidPaid ? "Você avisou que pagou" : "Já paguei este PIX"}
            </Button>
          ) : null}
          <p className="text-sm text-muted">
            O profissional só marca como pago depois de ver o comprovante no banco. Aviso nesta tela não move dinheiro.
          </p>
        </div>
      )}
    </main>
  );
}
