import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { MoneyText } from "@/components/fields";
import { Badge, Card, PageTitle, TableWrap, Td, Th } from "@/components/ui";
import { getCrm } from "@/lib/server/books";
import { isoToJalali } from "@/lib/accounting/jalali";
import { useQuery } from "@tanstack/react-query";

export const Route = createFileRoute("/crm")({ component: CrmPage });

function CrmPage() {
  const q = useQuery({ queryKey: ["crm"], queryFn: () => getCrm() });
  const d = q.data;
  return (
    <AppShell>
      <PageTitle title="CRM مشتریان" subtitle="ارزش، مانده، رفتار پرداخت و بخش‌بندی" />
      {d && (
        <>
          <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-5">
            <K k="فعال" v={d.active} />
            <K k="غیرفعال" v={d.inactive} />
            <K k="مانده بالا" v={d.highBalance} />
            <K k="ریسک وصول" v={d.highRisk} />
            <K k="کم‌سابقه" v={d.newCount} />
          </div>
          <TableWrap>
            <thead>
              <tr>
                <Th>مشتری</Th>
                <Th>خرید</Th>
                <Th>میانگین</Th>
                <Th>دریافت</Th>
                <Th>مانده</Th>
                <Th>آخرین خرید</Th>
                <Th>وضعیت</Th>
              </tr>
            </thead>
            <tbody>
              {d.cards.map((c) => (
                <tr key={String(c.id)}>
                  <Td>
                    <div className="font-medium">{String(c.name)}</div>
                    <div className="text-xs text-muted">{String(c.mobile ?? "")}</div>
                  </Td>
                  <Td>{c.purchaseCount} / <MoneyText value={c.purchaseAmt} /></Td>
                  <Td><MoneyText value={c.avgPurchase} /></Td>
                  <Td><MoneyText value={c.received} /></Td>
                  <Td><MoneyText value={c.balance} /></Td>
                  <Td>{c.lastPurchase ? isoToJalali(String(c.lastPurchase)) : "—"}</Td>
                  <Td>
                    <Badge tone={c.risk === "high" ? "danger" : c.inactive ? "muted" : "ok"}>
                      {c.inactive ? "غیرفعال" : c.risk === "high" ? "ریسک وصول" : "فعال"}
                    </Badge>
                  </Td>
                </tr>
              ))}
            </tbody>
          </TableWrap>
        </>
      )}
    </AppShell>
  );
}

function K({ k, v }: { k: string; v: number }) {
  return (
    <Card>
      <p className="text-xs text-muted">{k}</p>
      <p className="text-xl font-semibold text-navy tabular">{v}</p>
    </Card>
  );
}
