import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";
import { Splash } from "@/components/layout/splash";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useBootstrap } from "@/lib/accounting/use-books";

export const Route = createFileRoute("/_app")({ component: AppLayout });

function AppLayout() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <Splash />;
  if (!user) return <RedirectToSignIn />;
  return (
    <BootGate>
      <AppShell>
        <Outlet />
      </AppShell>
    </BootGate>
  );
}

function BootGate({ children }: { children: React.ReactNode }) {
  const boot = useBootstrap();
  if (boot.isLoading) return <Splash message="باز کردن دفاتر سال مالی" />;
  if (boot.error) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-cream p-8 text-center">
        <div>
          <h1 className="text-lg font-semibold text-navy">خطا در بارگذاری دفاتر</h1>
          <p className="mt-2 text-sm text-muted">{boot.error.message}</p>
        </div>
      </div>
    );
  }
  return <>{children}</>;
}
