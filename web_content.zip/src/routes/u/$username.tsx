import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Youtube } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import {
  getProfile,
  listConnections,
  setFollow,
  updateProfile,
} from "@/lib/cutegirls/api";
import { compressImage } from "@/lib/cutegirls/images";
import { ROLES, type Person, type Profile, type Role } from "@/lib/cutegirls/model";
import { useSalon } from "@/lib/cutegirls/store";
import { Avatar, RolePill, fieldClass, primaryBtn, quietBtn } from "@/components/bits";
import { FeedView } from "@/components/feed-view";
import { Shell } from "@/components/shell";
import { useMeId } from "@/components/use-me-id";

export const Route = createFileRoute("/u/$username")({ component: ProfilePage });

function ProfilePage() {
  const { username } = Route.useParams();
  return (
    <Shell>
      <ProfileView username={username} />
    </Shell>
  );
}

function ProfileView({ username }: { username: string }) {
  const meId = useMeId();
  const tick = useSalon((s) => s.tick);
  const bump = useSalon((s) => s.bump);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState(false);
  const [dir, setDir] = useState<"followers" | "following" | null>(null);
  const [people, setPeople] = useState<Person[]>([]);

  useEffect(() => {
    let live = true;
    setDir(null);
    getProfile({ data: { username } })
      .then((result) => {
        if (!live) return;
        if (!result.ok) {
          setProfile(null);
          setError(result.error);
        } else {
          setError(null);
          setProfile(result.profile);
        }
      })
      .catch((err: unknown) => {
        if (live) setError(err instanceof Error ? err.message : "تعذر التحميل");
      });
    return () => {
      live = false;
    };
  }, [username, tick]);

  async function toggleFollow() {
    if (!profile) return;
    const result = await setFollow({ data: { username: profile.username, follow: !profile.isFollowing } });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setProfile({ ...profile, isFollowing: result.following, followers: result.followers });
  }

  async function openList(next: "followers" | "following") {
    if (!profile) return;
    if (dir === next) {
      setDir(null);
      return;
    }
    const result = await listConnections({ data: { username: profile.username, dir: next } });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setPeople(result.people);
    setDir(next);
  }

  if (!meId) return null;

  return (
    <div className="mx-auto w-full max-w-xl">
      {error && !profile ? <p className="text-sm text-rose">{error}</p> : null}
      {profile ? (
        <>
          <div className="overflow-hidden rounded-3xl bg-paper shadow-card">
            <div className="relative h-40 bg-rose/20 sm:h-48">
              {profile.banner ? (
                <img src={profile.banner} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="absolute inset-y-0 end-0 w-1/2 bg-ink/15" />
              )}
            </div>
            <div className="px-4 pb-5 sm:px-5">
              <div className="-mt-10 flex items-end justify-between gap-3">
                <Avatar src={profile.avatar} name={profile.username} className="size-20 border-4 border-paper text-2xl" />
                {profile.isSelf ? (
                  <button type="button" className={quietBtn} onClick={() => setEditing((v) => !v)}>
                    {editing ? "إغلاق" : "تعديل"}
                  </button>
                ) : (
                  <button type="button" className={profile.isFollowing ? quietBtn : primaryBtn} onClick={() => void toggleFollow()}>
                    {profile.isFollowing ? "إلغاء المتابعة" : "متابعة"}
                  </button>
                )}
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <h1 className="font-display text-4xl leading-none">{profile.username}</h1>
                <RolePill role={profile.role} />
              </div>
              <a
                href={profile.youtubeUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-3 inline-flex min-h-11 max-w-full items-center gap-2 rounded-full bg-ivory px-4 text-sm text-ink"
              >
                <Youtube className="size-4 shrink-0 text-rose" />
                <span className="truncate" dir="ltr">
                  {profile.youtubeUrl.replace("https://www.", "")}
                </span>
              </a>
              <p className="mt-3 whitespace-pre-wrap text-sm leading-7">{profile.bio || "لا نبذة بعد."}</p>
              <div className="mt-4 flex gap-2">
                <button type="button" className="min-h-11 rounded-2xl px-3 text-sm" onClick={() => void openList("followers")}>
                  <span className="tabular-nums font-medium">{profile.followers}</span>{" "}
                  <span className="text-mute">متابعون</span>
                </button>
                <button type="button" className="min-h-11 rounded-2xl px-3 text-sm" onClick={() => void openList("following")}>
                  <span className="tabular-nums font-medium">{profile.following}</span>{" "}
                  <span className="text-mute">يتابع</span>
                </button>
              </div>
              {profile.isSelf ? (
                <div className="mt-3 md:hidden">
                  <UserButton />
                </div>
              ) : null}
            </div>
          </div>
          {editing && profile.isSelf ? (
            <Editor
              profile={profile}
              onSaved={() => {
                setEditing(false);
                bump();
              }}
            />
          ) : null}
          {dir ? (
            <ul className="mt-3 space-y-2">
              {people.map((person) => (
                <li key={person.username}>
                  <Link
                    to="/u/$username"
                    params={{ username: person.username }}
                    className="flex min-h-14 items-center gap-3 rounded-2xl bg-paper px-3 shadow-card"
                  >
                    <Avatar src={person.avatar} name={person.username} className="size-9 text-sm" />
                    <span className="font-medium">{person.username}</span>
                    <RolePill role={person.role} />
                  </Link>
                </li>
              ))}
              {!people.length ? <li className="text-sm text-mute">لا أحد هنا بعد.</li> : null}
            </ul>
          ) : null}
          <div className="mt-4">
            <FeedView
              meId={meId}
              query={{ surface: "user", username: profile.username }}
              variant="feed"
              emptyTitle="لا منشورات"
              emptyBody="حين يُنشر شيء، يظهر هنا وللجميع."
            />
          </div>
        </>
      ) : null}
    </div>
  );
}

function Editor({ profile, onSaved }: { profile: Profile; onSaved: () => void }) {
  const [bio, setBio] = useState(profile.bio);
  const [role, setRole] = useState<Role>(profile.role);
  const [avatar, setAvatar] = useState<string | null>(profile.avatar);
  const [banner, setBanner] = useState<string | null>(profile.banner);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function pick(file: File | undefined, which: "avatar" | "banner") {
    if (!file) return;
    try {
      const data = await compressImage(file, which === "avatar" ? 512 : 1400, which === "avatar" ? 200_000 : 400_000);
      if (which === "avatar") setAvatar(data);
      else setBanner(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر قراءة الصورة");
    }
  }

  async function save(event: FormEvent) {
    event.preventDefault();
    setPending(true);
    setError(null);
    try {
      const result = await updateProfile({ data: { bio, role, avatar, banner } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      onSaved();
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={save} className="mt-3 space-y-3 rounded-3xl bg-paper p-4 shadow-card">
      <label className="block space-y-1.5 text-sm">
        <span className="text-mute">النبذة</span>
        <textarea className={`${fieldClass} min-h-24 py-3`} value={bio} maxLength={280} onChange={(e) => setBio(e.target.value)} />
      </label>
      <div className="grid grid-cols-2 gap-2">
        {ROLES.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setRole(item.id)}
            className={`min-h-11 rounded-full text-sm ${role === item.id ? "bg-rose text-paper" : "bg-ivory"}`}
          >
            {item.label}
          </button>
        ))}
      </div>
      <label className="block text-sm text-mute">
        الصورة
        <input type="file" accept="image/*" className="mt-1 block w-full text-ink" onChange={(e) => void pick(e.target.files?.[0], "avatar")} />
      </label>
      <label className="block text-sm text-mute">
        البانر
        <input type="file" accept="image/*" className="mt-1 block w-full text-ink" onChange={(e) => void pick(e.target.files?.[0], "banner")} />
      </label>
      {error ? <p className="text-sm text-rose">{error}</p> : null}
      <button className={primaryBtn} disabled={pending} type="submit">
        {pending ? "يُحفظ…" : "حفظ"}
      </button>
    </form>
  );
}
