import { createFileRoute, Link } from "@tanstack/react-router";
import { Page } from "@/components/ui";
import { SEERAH } from "@/data/seerah";

export const Route = createFileRoute("/seerah/")({ component: SeerahHome });

function SeerahHome() {
  return (
    <Page title="السيرة النبوية" subtitle="فصول موثّقة من الصحيحين وكتب السيرة المعتمدة. ما كان ظنيًا نُبه عليه.">
      <ol className="space-y-2">
        {SEERAH.map((c, i) => (
          <li key={c.id}>
            <Link to="/seerah/$id" params={{ id: c.id }} className="flex gap-3 rounded-2xl border border-line bg-card px-4 py-3">
              <span className="text-gold">{i + 1}</span>
              <span>
                <span className="block font-bold">{c.title}</span>
                <span className="text-xs text-muted">{c.period}</span>
              </span>
            </Link>
          </li>
        ))}
      </ol>
    </Page>
  );
}
