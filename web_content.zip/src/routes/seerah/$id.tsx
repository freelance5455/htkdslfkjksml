import { createFileRoute } from "@tanstack/react-router";
import { Page } from "@/components/ui";
import { SEERAH } from "@/data/seerah";
import { usePrefs } from "@/lib/prefs";

export const Route = createFileRoute("/seerah/$id")({ component: Chapter });

function Chapter() {
  const { id } = Route.useParams();
  const chapter = SEERAH.find((c) => c.id === id);
  const prefs = usePrefs();
  if (!chapter) return <Page title="غير موجود" back>لا يوجد هذا الفصل.</Page>;
  return (
    <Page title={chapter.title} subtitle={chapter.period} back>
      <button
        type="button"
        className="mb-3 text-sm font-semibold text-gold"
        onClick={() => prefs.toggleFav({ id: `seerah-${chapter.id}`, kind: "seerah", title: chapter.title, href: `/seerah/${chapter.id}` })}
      >
        حفظ
      </button>
      {chapter.body.map((p) => (
        <p key={p.slice(0, 24)} className="mb-3 text-sm leading-relaxed">
          {p}
        </p>
      ))}
      <p className="text-xs text-muted">المراجع: {chapter.sources.join(" · ")}</p>
    </Page>
  );
}
