import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { MoneyText } from "@/components/fields";
import { Button, PageTitle, TableWrap, Td, Th } from "@/components/ui";
import { bootstrap, getFinancials, getLedger, getTrialBalance } from "@/lib/server/books";
import { downloadCsv, printSection } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { formatRial } from "@/lib/accounting/format";
import { isoToJalali } from "@/lib/accounting/jalali";

export const Route = createFileRoute("/reports")({ component: ReportsPage });

const TABS = [
  { id: "tb6", label: "تراز ۶ ستونی" },
  { id: "tb2", label: "تراز ۲ ستونی" },
  { id: "pnl", label: "سود و زیان" },
  { id: "bs", label: "ترازنامه" },
  { id: "cf", label: "جریان وجوه" },
  { id: "ledger", label: "دفتر کل" },
] as const;

function ReportsPage() {
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("tb6");
  const tb = useQuery({ queryKey: ["tb"], queryFn: () => getTrialBalance({ data: { level: 4 } }) });
  const fin = useQuery({ queryKey: ["fin"], queryFn: () => getFinancials({ data: {} }) });
  const boot = useQuery({ queryKey: ["bootstrap"], queryFn: () => bootstrap() });
  const [accountId, setAccountId] = useState("");
  const ledger = useQuery({
    queryKey: ["ledger", accountId],
    queryFn: () => getLedger({ data: { accountId: accountId || undefined } }),
  });
  const company = boot.data?.company.name ?? "شرکت خراسانی";

  return (
    <AppShell>
      <PageTitle
        title="گزارش‌های حسابداری"
        subtitle={`${company} — سال مالی ${boot.data?.company.fiscalYearCode ?? ""}`}
        actions={
          <div className="flex gap-2">
            <Button variant="secondary" onClick={printSection}>PDF</Button>
            {tab.startsWith("tb") && tb.data && (
              <Button
                variant="secondary"
                onClick={() =>
                  downloadCsv(
                    "trial-balance.csv",
                    ["code", "name", "openDr", "openCr", "periodDr", "periodCr", "endDr", "endCr"],
                    tb.data.rows.map((r) => [r.code, r.name, r.openDr, r.openCr, r.periodDr, r.periodCr, r.endDr, r.endCr]),
                  )
                }
              >
                Excel
              </Button>
            )}
          </div>
        }
      />
      <div className="mb-4 flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`rounded-full px-3 py-1.5 text-sm ${tab === t.id ? "bg-navy text-paper" : "bg-paper-2 text-navy"}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {(tab === "tb6" || tab === "tb2") && tb.data && (
        <>
          <div className="mb-3 flex justify-between text-sm">
            <span>اختلاف: <MoneyText value={tb.data.diff} /></span>
            <span className={tb.data.diff === 0 ? "text-ok" : "text-danger"}>
              {tb.data.diff === 0 ? "تراز متعادل است" : "تراز نامتعادل"}
            </span>
          </div>
          <TableWrap>
            <thead>
              <tr>
                <Th>کد</Th>
                <Th>حساب</Th>
                {tab === "tb6" && <><Th>بدهکار اول دوره</Th><Th>بستانکار اول دوره</Th><Th>گردش بدهکار</Th><Th>گردش بستانکار</Th></>}
                <Th>مانده بدهکار</Th>
                <Th>مانده بستانکار</Th>
              </tr>
            </thead>
            <tbody>
              {tb.data.rows.map((r) => (
                <tr key={r.id}>
                  <Td className="tabular">{r.code}</Td>
                  <Td>{r.name}</Td>
                  {tab === "tb6" && (
                    <>
                      <Td><MoneyText value={r.openDr} /></Td>
                      <Td><MoneyText value={r.openCr} /></Td>
                      <Td><MoneyText value={r.periodDr} /></Td>
                      <Td><MoneyText value={r.periodCr} /></Td>
                    </>
                  )}
                  <Td><MoneyText value={r.endDr} /></Td>
                  <Td><MoneyText value={r.endCr} /></Td>
                </tr>
              ))}
              <tr>
                <Td /><Td className="font-semibold">جمع</Td>
                {tab === "tb6" && (
                  <>
                    <Td><MoneyText value={tb.data.totals.openDr} /></Td>
                    <Td><MoneyText value={tb.data.totals.openCr} /></Td>
                    <Td><MoneyText value={tb.data.totals.periodDr} /></Td>
                    <Td><MoneyText value={tb.data.totals.periodCr} /></Td>
                  </>
                )}
                <Td className="font-semibold"><MoneyText value={tb.data.totals.endDr} /></Td>
                <Td className="font-semibold"><MoneyText value={tb.data.totals.endCr} /></Td>
              </tr>
            </tbody>
          </TableWrap>
        </>
      )}

      {tab === "pnl" && fin.data && (
        <ReportBlock title="سود و زیان" items={[
          ...fin.data.pnl.income.map((x) => ({ ...x, side: "درآمد" })),
          ...fin.data.pnl.cogs.map((x) => ({ ...x, side: "بهای تمام‌شده" })),
          ...fin.data.pnl.expense.map((x) => ({ ...x, side: "هزینه" })),
        ]} footer={[
          ["فروش و درآمد", fin.data.pnl.incomeSum],
          ["بهای تمام‌شده", fin.data.pnl.cogsSum],
          ["سود ناخالص", fin.data.pnl.grossProfit],
          ["هزینه‌ها", fin.data.pnl.expSum],
          ["سود خالص", fin.data.pnl.net],
        ]} />
      )}

      {tab === "bs" && fin.data && (
        <ReportBlock title="ترازنامه" items={[
          ...fin.data.bs.assets.map((x) => ({ ...x, side: "دارایی" })),
          ...fin.data.bs.liab.map((x) => ({ ...x, side: "بدهی" })),
          ...fin.data.bs.equity.map((x) => ({ ...x, side: "سرمایه" })),
        ]} footer={[
          ["جمع دارایی", fin.data.bs.assetSum],
          ["جمع بدهی", fin.data.bs.liabSum],
          ["سرمایه + سود", fin.data.bs.eqSum],
          ["توازن", fin.data.bs.balanced ? 0 : 1],
        ]} />
      )}

      {tab === "cf" && fin.data && (
        <div className="grid gap-3 sm:grid-cols-3">
          <Tile k="ورود وجه" v={fin.data.cashflow.inflow} />
          <Tile k="خروج وجه" v={fin.data.cashflow.outflow} />
          <Tile k="خالص جریان" v={fin.data.cashflow.net} />
        </div>
      )}

      {tab === "ledger" && (
        <div className="space-y-3">
          <select className="h-11 rounded-md border border-line bg-card px-3 text-sm" value={accountId} onChange={(e) => setAccountId(e.target.value)}>
            <option value="">همه حساب‌ها</option>
            {(boot.data?.accounts as Array<Record<string, string>> | undefined)?.filter((a) => Number(a.level) === 4).map((a) => (
              <option key={a.id} value={a.id}>{a.code} — {a.name}</option>
            ))}
          </select>
          <TableWrap>
            <thead>
              <tr>
                <Th>تاریخ</Th>
                <Th>سند</Th>
                <Th>حساب</Th>
                <Th>شرح</Th>
                <Th>بدهکار</Th>
                <Th>بستانکار</Th>
              </tr>
            </thead>
            <tbody>
              {(ledger.data?.rows as Array<Record<string, unknown>> | undefined)?.map((r) => (
                <tr key={String(r.id)}>
                  <Td>{isoToJalali(String(r.date))}</Td>
                  <Td className="tabular">{String(r.journal_number)}</Td>
                  <Td>{String(r.account_code)} {String(r.account_name)}</Td>
                  <Td>{String(r.description)}</Td>
                  <Td><MoneyText value={r.debit} /></Td>
                  <Td><MoneyText value={r.credit} /></Td>
                </tr>
              ))}
            </tbody>
          </TableWrap>
        </div>
      )}

      <div className="print-report">
        <h1>MR,KHORASANI</h1>
        <p>{company} — {tab}</p>
        <p>تاریخ تولید: {isoToJalali(new Date().toISOString().slice(0, 10))}</p>
        {tb.data && <p>جمع بدهکار {formatRial(tb.data.totals.endDr)} / بستانکار {formatRial(tb.data.totals.endCr)}</p>}
      </div>
    </AppShell>
  );
}

function ReportBlock({
  title,
  items,
  footer,
}: {
  title: string;
  items: { code: string; name: string; amount: number; side: string }[];
  footer: [string, number][];
}) {
  return (
    <div>
      <h3 className="mb-2 font-medium text-navy">{title}</h3>
      <TableWrap>
        <thead><tr><Th>گروه</Th><Th>کد</Th><Th>نام</Th><Th>مبلغ</Th></tr></thead>
        <tbody>
          {items.map((x) => (
            <tr key={x.code}><Td>{x.side}</Td><Td className="tabular">{x.code}</Td><Td>{x.name}</Td><Td><MoneyText value={x.amount} /></Td></tr>
          ))}
          {footer.map(([k, v]) => (
            <tr key={k}><Td /><Td /><Td className="font-semibold">{k}</Td><Td className="font-semibold"><MoneyText value={v} /></Td></tr>
          ))}
        </tbody>
      </TableWrap>
    </div>
  );
}

function Tile({ k, v }: { k: string; v: number }) {
  return (
    <div className="rounded-xl border border-line bg-card p-4">
      <p className="text-xs text-muted">{k}</p>
      <p className="mt-1 text-xl font-semibold text-navy"><MoneyText value={v} /></p>
    </div>
  );
}
