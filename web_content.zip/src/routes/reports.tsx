import { createFileRoute } from "@tanstack/react-router";
import { ReportsPage } from "@/components/ministry/desk-pages";
import { AppShell } from "@/components/ministry/shell";

export const Route = createFileRoute("/reports")({
  component: function ReportsRoute() {
    return (
      <AppShell>
        <ReportsPage />
      </AppShell>
    );
  },
});
