import { createFileRoute } from "@tanstack/react-router";
import { GamesPage } from "@/features/games";

export const Route = createFileRoute("/games")({
  head: () => ({ meta: [{ title: "Games · FrameForge BOOYAH" }] }),
  component: GamesPage,
});
