import { createFileRoute } from "@tanstack/react-router";
import { BatteryCharging } from "lucide-react";
import { useEffect, useState } from "react";
import { AppShell, ScreenBody } from "@/components/vishal/app-shell";
import { IconBadge, InfoRow, Panel, ScreenHeader } from "@/components/vishal/screen-header";
import { formatDuration, subscribeBattery, type BatteryReading } from "@/lib/web-device";

export const Route = createFileRoute("/battery")({ component: BatteryPage });

function BatteryPage() {
  const [battery, setBattery] = useState<BatteryReading | null>(null);

  useEffect(() => subscribeBattery(setBattery), []);

  const percent = battery && battery.percent >= 0 ? battery.percent : null;
  const progress = percent === null ? 0 : percent / 100;
  const charging = battery?.charging ?? false;

  return (
    <AppShell>
      <ScreenBody>
        <ScreenHeader
          title="Battery Info"
          subtitle="Live reading from this device. Nothing is stored or sent."
        />
        <Panel>
          <IconBadge className={charging ? "bg-warning/15 text-warning" : "bg-primary/15 text-primary"}>
            <BatteryCharging className="size-5" />
          </IconBadge>
          <p className="mt-4 text-4xl font-bold tabular-nums tracking-tight text-fg">
            {percent === null ? "—" : `${percent}%`}
          </p>
          <p className={`text-sm ${charging ? "text-warning" : "text-muted"}`}>
            {battery?.statusLabel ?? "Reading battery…"}
          </p>
          <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-primary/15">
            <div
              className={`h-full rounded-full transition-[width] duration-300 ease-out ${charging ? "bg-warning" : "bg-primary"}`}
              style={{ width: `${Math.round(progress * 100)}%` }}
            />
          </div>
        </Panel>
        <div className="mt-3.5 flex flex-col gap-2.5">
          <InfoRow label="Status" value={battery?.statusLabel ?? "..."} />
          <InfoRow label="Power source" value={charging ? "Plugged in / charging" : "On battery"} />
          <InfoRow label="Health" value={battery?.healthLabel ?? "..."} />
          <InfoRow label="Time to full" value={formatDuration(battery?.chargingTime ?? Infinity)} />
          <InfoRow label="Time remaining" value={formatDuration(battery?.dischargingTime ?? Infinity)} />
        </div>
        {battery?.source === "unavailable" ? (
          <p className="mt-4 text-sm leading-relaxed text-muted">
            This browser does not expose battery APIs. The Android app reads the real battery on
            your phone, including health when the system provides it.
          </p>
        ) : null}
      </ScreenBody>
    </AppShell>
  );
}
