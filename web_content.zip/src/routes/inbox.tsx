import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { MediaGrid } from "@/components/media-grid";
import { MediaViewer } from "@/components/media-viewer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { INBOX_SLUG, useStarMedia, useStars, useVault, type MediaMeta } from "@/store/vault";

export const Route = createFileRoute("/inbox")({ component: InboxPage });

function InboxPage() {
  const items = useStarMedia(INBOX_SLUG);
  const stars = useStars();
  const assignMedia = useVault((s) => s.assignMedia);
  const removeMedia = useVault((s) => s.removeMedia);
  const [open, setOpen] = useState<MediaMeta | null>(null);
  const [assigning, setAssigning] = useState<MediaMeta | null>(null);
  const [q, setQ] = useState("");

  const suggestions = useMemo(() => {
    const query = q.trim().toLowerCase();
    const list = query
      ? stars.filter((s) => s.name.toLowerCase().includes(query))
      : stars.slice(0, 20);
    return list.slice(0, 24);
  }, [q, stars]);

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl px-4 pb-20 pt-4">
        <div className="mb-6 flex items-center gap-2">
          <Button variant="ghost" size="icon" asChild aria-label="Back">
            <Link to="/">
              <ArrowLeft className="size-4" />
            </Link>
          </Button>
          <p className="text-sm text-muted-foreground">Unsorted</p>
        </div>
        <h1 className="font-display text-4xl font-medium tracking-tight">Inbox</h1>
        <p className="mt-2 max-w-xl text-sm text-muted-foreground">
          Files whose names did not match a performer land here. Assign them, or import again with
          the star in the filename — like angela.white.mp4.
        </p>
        <div className="mt-8">
          <MediaGrid
            items={items}
            onOpen={setOpen}
            onAssign={setAssigning}
            onDelete={(item) => void removeMedia(item.id)}
            emptyTitle="Inbox is clear"
            emptyBody="Import files from the plus menu. Matched names file themselves; the rest wait here."
          />
        </div>
      </div>
      <MediaViewer item={open} onClose={() => setOpen(null)} />
      <Dialog open={Boolean(assigning)} onOpenChange={(o) => !o && setAssigning(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>File to a profile</DialogTitle>
            <DialogDescription>{assigning?.name}</DialogDescription>
          </DialogHeader>
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search roster" />
          <ul className="mt-3 max-h-64 overflow-y-auto">
            {suggestions.map((s) => (
              <li key={s.slug}>
                <button
                  type="button"
                  className="flex h-11 w-full items-center rounded-md px-3 text-left text-sm hover:bg-secondary"
                  onClick={async () => {
                    if (!assigning) return;
                    await assignMedia(assigning.id, s.slug);
                    setAssigning(null);
                    setQ("");
                  }}
                >
                  {s.name}
                </button>
              </li>
            ))}
          </ul>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
