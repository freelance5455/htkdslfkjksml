import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { usePortfolio } from "@/lib/portfolio-context";

export const Route = createFileRoute("/meg")({ component: Page });

const LINKS = [
  { to: "/mozgasok", title: "Mozgások", text: "Vétel, eladás, osztalék, díj." },
  { to: "/beolvasas", title: "Beolvasás", text: "Lightyear PDF, kriptotárca, CSV és mentés." },
  { to: "/dijak", title: "Előfizetések", text: "Havi szivárgás forintban és dollárban." },
] as const;

function Page() {
  const { loadSample, clearAll } = usePortfolio();
  return (
    <Shell>
      <h1 className="font-serif text-3xl">Még</h1>
      <p className="mt-1 text-sm text-muted">Ami a telefon alján külön nem fért el.</p>
      <ul className="mt-6 divide-y divide-line border-t border-line">
        {LINKS.map((link) => (
          <li key={link.to}>
            <Link to={link.to} className="flex min-h-16 flex-col justify-center py-3">
              <span className="font-medium">{link.title}</span>
              <span className="text-sm text-muted">{link.text}</span>
            </Link>
          </li>
        ))}
      </ul>
      <div className="mt-8 flex flex-wrap gap-2">
        <button type="button" className="btn btn-ghost" onClick={loadSample}>
          Minta újratöltése
        </button>
        <button type="button" className="btn btn-primary" onClick={() => confirm("Üres lapra cseréled a helyi adatot?") && clearAll()}>
          Üres lap
        </button>
      </div>
    </Shell>
  );
}
