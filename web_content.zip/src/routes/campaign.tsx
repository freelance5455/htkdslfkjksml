import { createFileRoute } from "@tanstack/react-router";
import { PageIntro, Tag } from "@/components/page";
import { CAMPAIGN, NEWS } from "@/data/campaign";

export const Route = createFileRoute("/campaign")({
  head: () => ({ meta: [{ title: "الحملة — لأنه الله" }] }),
  component: CampaignPage,
});

function CampaignPage() {
  return (
    <main>
      <PageIntro
        kicker="من المصادر العلنية"
        title="حملة «لأنه الله» في سورية"
        lede="هذه الصفحة تعرّف بالحملة كما أعلنتها وزارة الأوقاف. المنصة مستقلة، ولا تستخدم شعارًا حكوميًا، ولا تعرض فعالية مقترحة على أنها رسمية."
      />
      <section className="mx-auto max-w-4xl space-y-6 px-4 py-8">
        <article className="rounded-card border border-line bg-soft p-5 text-sm leading-7">
          الجهة المنظمة حسب الإعلان: {CAMPAIGN.organizer}. تاريخ الإطلاق المتداول: {CAMPAIGN.launched}. الموقع الرسمي للوزارة:{" "}
          <a className="text-primary" href={CAMPAIGN.officialSite} rel="noreferrer">{CAMPAIGN.officialSite}</a>
          {" "}وحسابها:{" "}
          <a className="text-primary" href={CAMPAIGN.officialAccount} rel="noreferrer">@SyMOfE</a>.
        </article>
        <section>
          <h2 className="font-display text-3xl text-primary">الأهداف المعلنة</h2>
          <ul className="mt-3 list-disc space-y-2 pe-5 leading-8">
            {CAMPAIGN.goals.map((goal) => <li key={goal}>{goal}</li>)}
          </ul>
        </section>
        <section>
          <h2 className="font-display text-3xl text-primary">ما ذُكر من البرامج</h2>
          <p className="mt-3 leading-8">{CAMPAIGN.duration}</p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {CAMPAIGN.programs.map((item) => <li key={item}><Tag>{item}</Tag></li>)}
          </ul>
          <p className="mt-4 text-sm leading-7 text-muted">{CAMPAIGN.partners}</p>
        </section>
        <section>
          <h2 className="font-display text-3xl text-primary">أرشيف الأخبار الموثقة</h2>
          <div className="mt-4 grid gap-4">
            {NEWS.map((item) => (
              <article key={item.id} className="rounded-card border border-line bg-surface p-5">
                <p className="text-xs text-olive">{item.date} · {item.kind}</p>
                <h3 className="mt-2 font-display text-2xl text-primary">{item.title}</h3>
                <p className="mt-2 leading-8">{item.summary}</p>
                <p className="mt-3 text-sm text-muted">{item.source}</p>
                <a className="mt-2 inline-block text-sm text-primary" href={item.url} rel="noreferrer">المصدر الأصلي</a>
              </article>
            ))}
          </div>
        </section>
        <p className="text-sm leading-7 text-muted">
          لا تُعرض هنا صور على أنها صور رسمية للفعالية. الصور الطبيعية في الموقع للتأمل في الخلق فقط.
        </p>
      </section>
    </main>
  );
}
