import { createFileRoute } from "@tanstack/react-router";
import { HelpPage } from "@/components/ministry/desk-pages";
import { AppShell } from "@/components/ministry/shell";

export const Route = createFileRoute("/help")({
  component: function HelpRoute() {
    return (
      <AppShell>
        <HelpPage />
      </AppShell>
    );
  },
});
