import { useMemo, useState, type FormEvent } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { Check, Copy, LoaderCircle, Send, Wallet } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NETWORK_BY_ID, shortenAddress } from "@/lib/chains";
import { audToToken, formatAud, formatToken, formatWhen, parseAud } from "@/lib/money";
import { useAudRates } from "@/lib/rates";
import { useVault, type Payout } from "@/lib/vault-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app/dashboard")({ component: DashboardPage });

const STEPS = ["Quote locked", "Routing payout", "Broadcasting", "Confirmed"] as const;

function DashboardPage() {
  return (
    <div className="space-y-4">
      <header className="rise-in space-y-1 px-1 pt-1">
        <h1 className="font-display text-3xl tracking-tight">Earnings Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Track your real income and cash out to your crypto wallet.
        </p>
      </header>
      <BalanceCards />
      <CashOutCard />
      <PayoutHistory />
    </div>
  );
}

function BalanceCards() {
  const available = useVault((s) => s.available);
  const earned = useVault((s) => s.earned);
  const cashed = useVault((s) => s.cashed);

  return (
    <div className="space-y-3">
      <Card className="rise-in rise-in-1">
        <p className="text-sm text-muted-foreground">Available balance</p>
        <p className="mt-2 font-display text-4xl leading-none tracking-tight text-success tabular-nums">
          {formatAud(available)}
        </p>
      </Card>
      <Card className="rise-in rise-in-2">
        <p className="text-sm text-muted-foreground">Total earned</p>
        <p className="mt-2 font-display text-4xl leading-none tracking-tight tabular-nums">
          {formatAud(earned)}
        </p>
      </Card>
      <Card className="rise-in rise-in-3">
        <p className="text-sm text-muted-foreground">Cash-outs</p>
        <p className="mt-2 font-display text-4xl leading-none tracking-tight tabular-nums">
          {formatAud(cashed)}
        </p>
      </Card>
    </div>
  );
}

function CashOutCard() {
  const wallet = useVault((s) => s.wallet);
  const available = useVault((s) => s.available);
  const cashOut = useVault((s) => s.cashOut);
  const confirmPayout = useVault((s) => s.confirmPayout);
  const { rates, live } = useAudRates();

  const [amount, setAmount] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [phase, setPhase] = useState<"review" | "sending" | "done">("review");
  const [step, setStep] = useState(0);
  const [active, setActive] = useState<Payout | null>(null);

  const network = wallet ? NETWORK_BY_ID[wallet.network] : null;
  const parsed = parseAud(amount);
  const quote = useMemo(() => {
    if (!wallet || !network || parsed === null) return null;
    const rate = rates[wallet.token];
    const feeAud = network.feeAud;
    if (parsed <= feeAud) return { invalid: "Amount must cover the network fee." as const };
    const gross = audToToken(parsed, rate);
    const feeToken = audToToken(feeAud, rate);
    const net = Math.max(0, gross - feeToken);
    return { rate, feeAud, gross, feeToken, net, invalid: null };
  }, [wallet, network, parsed, rates]);

  function resetDialog() {
    setPhase("review");
    setStep(0);
    setActive(null);
    setError(null);
  }

  function onOpenChange(next: boolean) {
    if (!next && phase === "sending") return;
    setOpen(next);
    if (!next) resetDialog();
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!wallet || !network) return;
    if (parsed === null) {
      setError("Enter an amount greater than 0.");
      return;
    }
    if (parsed > available) {
      setError("That is more than your available balance.");
      return;
    }
    if (!quote || quote.invalid) {
      setError(quote?.invalid ?? "Could not price this payout.");
      return;
    }
    setError(null);
    setPhase("review");
    setOpen(true);
  }

  function fillMax() {
    if (available <= 0) return;
    setAmount(available.toFixed(2));
    setError(null);
  }

  async function confirmSend() {
    if (!wallet || !network || parsed === null || !quote || quote.invalid) return;
    try {
      const payout = cashOut({
        amountAud: parsed,
        tokenAmount: quote.net,
        feeAud: quote.feeAud,
      });
      setActive(payout);
      setPhase("sending");
      for (let i = 0; i < STEPS.length; i += 1) {
        setStep(i);
        await wait(i === STEPS.length - 1 ? 520 : 420);
      }
      confirmPayout(payout.id);
      setPhase("done");
      setAmount("");
    } catch (err) {
      setPhase("review");
      setError(err instanceof Error ? err.message : "Could not send this payout.");
      setOpen(false);
    }
  }

  async function copyId(value: string) {
    try {
      await navigator.clipboard.writeText(value);
      toast.success("Copied");
    } catch {
      toast.error("Could not copy");
    }
  }

  if (!wallet || !network) {
    return (
      <Card className="rise-in rise-in-4">
        <CardTitle className="flex items-center gap-2">
          <Wallet className="size-5" strokeWidth={2} />
          Cash out to your wallet
        </CardTitle>
        <CardHint className="mt-2">
          Add a destination wallet first. Payouts convert AUD to crypto and send to that address.
        </CardHint>
        <Button asChild className="mt-5 h-12 w-full text-base">
          <Link to="/wallet">Set up wallet</Link>
        </Button>
      </Card>
    );
  }

  return (
    <>
      <Card className="rise-in rise-in-4">
        <CardTitle className="flex items-center gap-2">
          <Send className="size-5" strokeWidth={2} />
          Cash out to your wallet
        </CardTitle>
        <CardHint className="mt-2">
          Available balance: {formatAud(available)}. Payouts go to{" "}
          <span className="font-mono text-foreground">{shortenAddress(wallet.address)}</span> on{" "}
          {network.name} as {wallet.token}.
        </CardHint>

        <form onSubmit={onSubmit} className="mt-5 space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-3">
              <Label htmlFor="cashout-amount">Amount (AUD)</Label>
              <button
                type="button"
                onClick={fillMax}
                className="text-xs font-medium text-muted-foreground hover:text-foreground"
              >
                Max
              </button>
            </div>
            <Input
              id="cashout-amount"
              inputMode="decimal"
              placeholder="0.00"
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                setError(null);
              }}
            />
          </div>

          {quote && !quote.invalid && parsed !== null ? (
            <div className="rounded-2xl bg-secondary px-4 py-3 text-sm">
              <div className="flex items-center justify-between gap-3">
                <span className="text-muted-foreground">You receive</span>
                <span className="font-medium tabular-nums">{formatToken(quote.net, wallet.token)}</span>
              </div>
              <div className="mt-1 flex items-center justify-between gap-3">
                <span className="text-muted-foreground">Network fee</span>
                <span className="tabular-nums">{formatAud(quote.feeAud)}</span>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                {live ? "Live quote" : "Estimated quote"} · 1 {wallet.token} ≈ {formatAud(quote.rate)}
              </p>
            </div>
          ) : null}

          {error ? <p className="text-sm text-destructive">{error}</p> : null}

          <Button type="submit" className="h-12 w-full text-base" disabled={available <= 0}>
            Send to wallet
          </Button>
        </form>
      </Card>

      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent showClose={phase !== "sending"}>
          {phase === "review" && quote && !quote.invalid && parsed !== null ? (
            <>
              <DialogTitle>Confirm payout</DialogTitle>
              <DialogDescription>
                Convert {formatAud(parsed)} and send {wallet.token} to your {network.name} wallet.
              </DialogDescription>
              <dl className="mt-4 space-y-2.5 rounded-2xl bg-secondary px-4 py-3 text-sm">
                <Row label="You send" value={formatAud(parsed)} />
                <Row label="You receive" value={formatToken(quote.net, wallet.token)} />
                <Row label="Network" value={network.name} />
                <Row label="Fee" value={formatAud(quote.feeAud)} />
                <Row label="To" value={shortenAddress(wallet.address, 6)} mono />
              </dl>
              <Button className="mt-5 h-12 w-full text-base" onClick={() => void confirmSend()}>
                Confirm send
              </Button>
            </>
          ) : null}

          {phase === "sending" ? (
            <>
              <DialogTitle>Sending</DialogTitle>
              <DialogDescription>Keep this open while the payout is routed.</DialogDescription>
              <ol className="mt-5 space-y-3">
                {STEPS.map((label, index) => {
                  const done = index < step;
                  const current = index === step;
                  return (
                    <li key={label} className="flex items-center gap-3 text-sm">
                      <span
                        className={cn(
                          "flex size-7 items-center justify-center rounded-full",
                          done || current ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
                        )}
                      >
                        {current ? (
                          <LoaderCircle className="size-3.5 animate-spin" />
                        ) : done ? (
                          <Check className="size-3.5" />
                        ) : (
                          <span className="text-xs">{index + 1}</span>
                        )}
                      </span>
                      <span className={current ? "font-medium" : "text-muted-foreground"}>{label}</span>
                    </li>
                  );
                })}
              </ol>
            </>
          ) : null}

          {phase === "done" && active ? (
            <>
              <DialogTitle>Sent to your wallet</DialogTitle>
              <DialogDescription>
                {formatToken(active.tokenAmount, active.token)} is on the way to{" "}
                {shortenAddress(active.walletAddress)}.
              </DialogDescription>
              <div className="mt-4 space-y-2 rounded-2xl bg-secondary px-4 py-3 text-sm">
                <Row label="Amount" value={formatAud(active.amountAud)} />
                <Row label="Received" value={formatToken(active.tokenAmount, active.token)} />
                <Row label="Network" value={NETWORK_BY_ID[active.network].name} />
                <div className="flex items-start justify-between gap-3 pt-1">
                  <span className="text-muted-foreground">Transaction ID</span>
                  <button
                    type="button"
                    className="flex max-w-48 items-center gap-1.5 text-right font-mono text-xs leading-snug break-all"
                    onClick={() => void copyId(active.txId)}
                  >
                    {shortenAddress(active.txId, 8)}
                    <Copy className="size-3.5 shrink-0" />
                  </button>
                </div>
              </div>
              <Button className="mt-5 h-12 w-full text-base" onClick={() => onOpenChange(false)}>
                Done
              </Button>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </>
  );
}

function Row({
  label,
  value,
  mono,
}: {
  label: string;
  value: string;
  mono?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className={cn("font-medium tabular-nums", mono && "font-mono text-xs")}>{value}</dd>
    </div>
  );
}

function PayoutHistory() {
  const payouts = useVault((s) => s.payouts);

  return (
    <Card>
      <CardTitle>Payout history</CardTitle>
      {payouts.length === 0 ? (
        <CardHint className="mt-2">Cash-outs will appear here with a transaction ID.</CardHint>
      ) : (
        <ul className="mt-4 divide-y divide-border">
          {payouts.map((row) => (
            <li key={row.id} className="flex items-start justify-between gap-4 py-3 first:pt-0 last:pb-0">
              <div className="min-w-0">
                <p className="font-medium">
                  {formatToken(row.tokenAmount, row.token)} · {NETWORK_BY_ID[row.network].name}
                </p>
                <p className="truncate font-mono text-xs text-muted-foreground">
                  {shortenAddress(row.walletAddress, 6)}
                </p>
                <p className="text-sm text-muted-foreground">{formatWhen(row.createdAt)}</p>
              </div>
              <div className="shrink-0 text-right">
                <p className="font-medium tabular-nums">{formatAud(row.amountAud)}</p>
                <p className="text-xs text-muted-foreground capitalize">{row.status}</p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

function wait(ms: number) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}
