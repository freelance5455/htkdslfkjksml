import { useMemo, useState, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Check, Copy, PlugZap, Wallet } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  NETWORKS,
  NETWORK_BY_ID,
  TOKENS,
  connectBrowserWallet,
  hasBrowserWallet,
  validateAddress,
  type NetworkId,
  type TokenId,
} from "@/lib/chains";
import { useVault } from "@/lib/vault-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app/wallet")({ component: WalletPage });

function WalletPage() {
  const saved = useVault((s) => s.wallet);
  const setWallet = useVault((s) => s.setWallet);

  const [networkId, setNetworkId] = useState<NetworkId>(saved?.network ?? "base");
  const [token, setToken] = useState<TokenId>(saved?.token ?? "USDC");
  const [address, setAddress] = useState(saved?.address ?? "");
  const [connected, setConnected] = useState(saved?.connected ?? false);
  const [error, setError] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);

  const network = NETWORK_BY_ID[networkId];
  const tokens = network.tokens;
  const addressError = useMemo(
    () => (address.trim() ? validateAddress(address, network.addressType) : null),
    [address, network.addressType],
  );

  function pickNetwork(id: NetworkId) {
    const next = NETWORK_BY_ID[id];
    setNetworkId(id);
    setConnected(false);
    setError(null);
    if (!next.tokens.includes(token)) setToken(next.tokens[0] ?? "USDC");
  }

  async function onConnect() {
    setConnecting(true);
    setError(null);
    try {
      const next = await connectBrowserWallet(network.addressType);
      setAddress(next);
      setConnected(true);
      toast.success("Wallet connected");
    } catch (err) {
      setConnected(false);
      setError(err instanceof Error ? err.message : "Could not connect.");
    } finally {
      setConnecting(false);
    }
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const message = validateAddress(address, network.addressType);
    if (message) {
      setError(message);
      return;
    }
    if (!network.tokens.includes(token)) {
      setError("Pick a token this network supports.");
      return;
    }
    setWallet({
      address: address.trim(),
      network: networkId,
      token,
      connected,
    });
    setError(null);
    toast.success("Destination wallet saved");
  }

  async function copyAddress() {
    if (!saved) return;
    try {
      await navigator.clipboard.writeText(saved.address);
      toast.success("Address copied");
    } catch {
      toast.error("Could not copy");
    }
  }

  return (
    <div className="space-y-4">
        <header className="rise-in space-y-1 px-1 pt-1">
          <h1 className="font-display text-3xl tracking-tight">Destination wallet</h1>
          <p className="text-sm text-muted-foreground">
            Cash-outs convert AUD and send to this address on the network you choose.
          </p>
        </header>

        {saved ? (
          <Card className="rise-in rise-in-1">
            <CardTitle className="flex items-center gap-2">
              <Wallet className="size-5" />
              Saved wallet
            </CardTitle>
            <div className="mt-4 space-y-2">
              <p className="font-medium">
                {NETWORK_BY_ID[saved.network].name} · {saved.token}
                {saved.connected ? (
                  <span className="ml-2 rounded-full bg-success/15 px-2 py-0.5 text-xs font-medium text-success">
                    Connected
                  </span>
                ) : null}
              </p>
              <button
                type="button"
                onClick={() => void copyAddress()}
                className="flex w-full items-center justify-between gap-3 rounded-2xl bg-secondary px-3 py-3 text-left"
              >
                <span className="font-mono text-xs leading-relaxed break-all">{saved.address}</span>
                <Copy className="size-4 shrink-0 text-muted-foreground" />
              </button>
            </div>
          </Card>
        ) : null}

        <Card className="rise-in rise-in-2">
          <form onSubmit={onSubmit} className="space-y-5">
            <div>
              <CardTitle>{saved ? "Update wallet" : "Add a wallet"}</CardTitle>
              <CardHint className="mt-1">Pick a network, then paste an address or connect a browser wallet.</CardHint>
            </div>

            <fieldset className="space-y-2">
              <Label>Network</Label>
              <div className="grid grid-cols-2 gap-2">
                {NETWORKS.map((item) => {
                  const active = item.id === networkId;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => pickNetwork(item.id)}
                      className={cn(
                        "rounded-2xl px-3 py-3 text-left transition-colors duration-150",
                        active ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-accent",
                      )}
                    >
                      <span className="block text-sm font-medium">{item.name}</span>
                      <span className={cn("mt-0.5 block text-xs", active ? "text-primary-foreground/70" : "text-muted-foreground")}>
                        {item.hint}
                      </span>
                    </button>
                  );
                })}
              </div>
            </fieldset>

            <fieldset className="space-y-2">
              <Label>Receive as</Label>
              <div className="flex flex-wrap gap-1.5">
                {tokens.map((id) => {
                  const active = id === token;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setToken(id)}
                      className={cn(
                        "h-10 rounded-full px-4 text-sm font-medium transition-colors duration-150",
                        active ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-accent",
                      )}
                    >
                      {TOKENS[id].name}
                    </button>
                  );
                })}
              </div>
            </fieldset>

            <div className="space-y-2">
              <Label htmlFor="address">Wallet address</Label>
              <Input
                id="address"
                spellCheck={false}
                autoCapitalize="off"
                autoCorrect="off"
                placeholder={
                  network.addressType === "evm"
                    ? "0x…"
                    : network.addressType === "solana"
                      ? "Solana address"
                      : "bc1… or 1…"
                }
                value={address}
                onChange={(e) => {
                  setAddress(e.target.value);
                  setConnected(false);
                  setError(null);
                }}
                className="font-mono text-sm"
              />
              {addressError ? <p className="text-sm text-destructive">{addressError}</p> : null}
            </div>

            {hasBrowserWallet(network.addressType) ? (
              <Button
                type="button"
                variant="outline"
                className="h-12 w-full text-base"
                onClick={() => void onConnect()}
                disabled={connecting}
              >
                <PlugZap className="size-4" />
                {connecting ? "Connecting…" : "Connect browser wallet"}
              </Button>
            ) : (
              <p className="text-sm text-muted-foreground">
                No browser wallet detected on this network. Paste your address to continue.
              </p>
            )}

            {error ? <p className="text-sm text-destructive">{error}</p> : null}

            <Button type="submit" className="h-12 w-full text-base">
              <Check className="size-4" />
              Save wallet
            </Button>
          </form>
        </Card>
    </div>
  );
}
