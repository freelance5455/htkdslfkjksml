import { createFileRoute } from "@tanstack/react-router";
import { PeopleView } from "@/components/sahyog/people-view";

export const Route = createFileRoute("/people")({
  component: PeopleView,
  head: () => ({ meta: [{ title: "People · Sahyog" }] }),
});
