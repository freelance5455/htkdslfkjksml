import { createFileRoute } from "@tanstack/react-router";
import { PayView } from "@/components/sahyog/pay-view";

export const Route = createFileRoute("/pay")({
  component: PayView,
  head: () => ({ meta: [{ title: "Pay · Sahyog" }] }),
});
