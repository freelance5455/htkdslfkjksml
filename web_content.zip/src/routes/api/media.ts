import { createFileRoute } from "@tanstack/react-router";
import { isBlockedHost, openTicket } from "@/lib/media/ticket";

const BROWSER_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";

function contentDisposition(filename: string, download: boolean): string {
  const ascii = filename.replace(/[^\x20-\x7E]/g, "_") || "video.mp4";
  const kind = download ? "attachment" : "inline";
  const encoded = encodeURIComponent(filename);
  return `${kind}; filename="${ascii}"; filename*=UTF-8''${encoded}`;
}

function header(headers: Headers, name: string): string | null {
  return headers.get(name);
}

async function pull(
  ticketUrl: string,
  extra: Record<string, string>,
  range: string | null,
): Promise<Response> {
  const headers: Record<string, string> = {
    "User-Agent": BROWSER_UA,
    Accept: "*/*",
    ...extra,
  };
  if (range) headers.Range = range;
  return fetch(ticketUrl, {
    headers,
    redirect: "follow",
  });
}

async function handle(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const token = url.searchParams.get("t");
  if (!token) return new Response("Missing token", { status: 400 });

  const ticket = openTicket(token);
  if (!ticket) {
    return new Response("Link expirado. Abre o vídeo de novo.", { status: 410 });
  }
  if (isBlockedHost(ticket.url)) {
    return new Response("Blocked", { status: 400 });
  }

  const download = url.searchParams.get("dl") === "1";
  const extra: Record<string, string> = {};
  if (ticket.referer) extra.Referer = ticket.referer;

  const wantRange = request.headers.get("Range");

  let upstream: Response;
  try {
    upstream = await pull(ticket.url, extra, wantRange);
    const contentRange = header(upstream.headers, "content-range");
    if (
      wantRange &&
      (upstream.status === 416 ||
        (upstream.status === 206 && !contentRange) ||
        (!upstream.ok && upstream.status !== 206))
    ) {
      await upstream.body?.cancel().catch(() => undefined);
      upstream = await pull(ticket.url, extra, null);
    }
  } catch {
    return new Response("Falha ao baixar", { status: 502 });
  }

  if (!upstream.ok && upstream.status !== 206) {
    return new Response("Falha ao baixar", { status: 502 });
  }

  const contentRange = header(upstream.headers, "content-range");
  const status =
    upstream.status === 206 && contentRange ? 206 : upstream.status === 206 ? 200 : upstream.status;

  const out = new Headers();
  const type = ticket.mime || header(upstream.headers, "content-type") || "video/mp4";
  out.set("Content-Type", type);
  out.set("Content-Disposition", contentDisposition(ticket.filename, download));
  out.set("Cache-Control", "private, max-age=120");
  out.set("Accept-Ranges", "bytes");
  const length = header(upstream.headers, "content-length");
  if (length) out.set("Content-Length", length);
  if (status === 206 && contentRange) out.set("Content-Range", contentRange);

  if (request.method === "HEAD") {
    await upstream.body?.cancel().catch(() => undefined);
    return new Response(null, { status, headers: out });
  }

  return new Response(upstream.body, { status, headers: out });
}

export const Route = createFileRoute("/api/media")({
  server: {
    handlers: {
      GET: ({ request }) => handle(request),
      HEAD: ({ request }) => handle(request),
    },
  },
});
