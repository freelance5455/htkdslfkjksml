import { createFileRoute } from "@tanstack/react-router";
import { allow } from "@/lib/charlie/guard.server";

const MAX_BYTES = 1_500_000;

export const Route = createFileRoute("/api/hear")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        if (!allow("hear", 8, 60_000)) {
          return Response.json(
            { ok: false, error: "Listening needs a short pause. Type this one." },
            { status: 429 },
          );
        }

        const apiKey = process.env.XAI_API_KEY;
        if (!apiKey) {
          return Response.json({ ok: false, error: "Listening isn't available here." }, { status: 503 });
        }

        let form: FormData;
        try {
          form = await request.formData();
        } catch {
          return Response.json({ ok: false, error: "That recording didn't come through." }, { status: 400 });
        }

        const file = form.get("file");
        if (!(file instanceof File) || file.size === 0) {
          return Response.json({ ok: false, error: "Charlie didn't catch any audio." }, { status: 400 });
        }
        if (file.size > MAX_BYTES) {
          return Response.json({ ok: false, error: "That was a bit long. Try a shorter note." }, { status: 400 });
        }

        const outbound = new FormData();
        outbound.append("model", "grok-voice-transcribe-2.0");
        outbound.append("file", file, file.name || "speech.webm");

        const upstream = await fetch("https://api.x.ai/v1/stt", {
          method: "POST",
          headers: { Authorization: `Bearer ${apiKey}` },
          body: outbound,
        });

        if (!upstream.ok) {
          return Response.json({ ok: false, error: "Charlie couldn't make out the words." }, { status: 502 });
        }

        const payload = (await upstream.json()) as { text?: unknown };
        const text = typeof payload.text === "string" ? payload.text.trim() : "";
        if (!text) {
          return Response.json({ ok: false, error: "Charlie heard silence. Try again." }, { status: 422 });
        }

        return Response.json({ ok: true, text: text.slice(0, 2000) });
      },
    },
  },
});
