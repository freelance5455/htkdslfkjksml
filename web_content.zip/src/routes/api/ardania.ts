import { createFileRoute } from "@tanstack/react-router";
import { askArdania, serviceStatus } from "@/lib/ardania-service.server";

export const Route = createFileRoute("/api/ardania")({
  server: {
    handlers: {
      GET: async () => Response.json(serviceStatus()),
      POST: async ({ request }) => {
        let body: unknown = null;
        try {
          body = await request.json();
        } catch {
          return Response.json({ error: "Некоректний запит." }, { status: 400 });
        }
        return askArdania(body, request.signal);
      },
    },
  },
});
