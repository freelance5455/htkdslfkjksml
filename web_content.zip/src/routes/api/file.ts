import { createFileRoute } from "@tanstack/react-router";

const ALLOWED_HOSTS = new Set(["rue-cobalt.xenon.zone", "cobaltapi.cjs.nz"]);

function allowedSource(raw: string): URL | null {
  try {
    const url = new URL(raw);
    if (url.protocol !== "https:") return null;
    if (!ALLOWED_HOSTS.has(url.hostname)) return null;
    if (url.pathname !== "/tunnel" && !url.pathname.startsWith("/tunnel")) {
      return null;
    }
    return url;
  } catch {
    return null;
  }
}

function safeFilename(raw: string | null): string {
  const fallback = "puro.mp4";
  if (!raw) return fallback;
  const cleaned = raw.replace(/[/\\?%*:|"<>]/g, "-").trim();
  return cleaned.slice(0, 180) || fallback;
}

export const Route = createFileRoute("/api/file")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const params = new URL(request.url).searchParams;
        const source = params.get("src");
        if (!source) {
          return Response.json({ error: "missing src" }, { status: 400 });
        }
        const url = allowedSource(source);
        if (!url) {
          return Response.json({ error: "forbidden" }, { status: 403 });
        }

        const upstream = await fetch(url.toString(), {
          headers: {
            Accept: "*/*",
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
          },
        });

        if (!upstream.ok || !upstream.body) {
          return Response.json(
            { error: "upstream" },
            { status: upstream.status || 502 },
          );
        }

        const filename = safeFilename(params.get("name"));
        const type =
          upstream.headers.get("content-type") || "application/octet-stream";
        const headers = new Headers();
        headers.set("Content-Type", type);
        headers.set(
          "Content-Disposition",
          `attachment; filename="${filename.replace(/"/g, "")}"`,
        );
        headers.set("Cache-Control", "no-store");
        const estimated =
          upstream.headers.get("content-length") ||
          upstream.headers.get("estimated-content-length");
        if (estimated) headers.set("Estimated-Content-Length", estimated);
        if (upstream.headers.get("content-length")) {
          headers.set("Content-Length", upstream.headers.get("content-length")!);
        }

        return new Response(upstream.body, { status: 200, headers });
      },
    },
  },
});
