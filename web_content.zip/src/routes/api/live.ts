import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/live")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { handlePost } = await import("@/lib/live/live-api.server");
        return handlePost(request);
      },
      GET: async ({ request }) => {
        const { handleGet } = await import("@/lib/live/live-api.server");
        return handleGet(request);
      },
    },
  },
});
