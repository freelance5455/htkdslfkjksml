import { createFileRoute } from "@tanstack/react-router";
import { answerKalki } from "@/lib/chat.functions";

export const Route = createFileRoute("/api/kalki")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown = null;
        try {
          body = await request.json();
        } catch {
          return Response.json({ ok: false, error: "Send a message first." });
        }
        const result = await answerKalki(body);
        return Response.json(result);
      },
    },
  },
});
