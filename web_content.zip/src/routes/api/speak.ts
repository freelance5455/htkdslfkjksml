import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { allow } from "@/lib/charlie/guard.server";

const VOICES = new Set(["eve", "leo", "ara", "orion"]);

const bodySchema = z.object({
  text: z.string().trim().min(1).max(700),
  voiceId: z.string().trim().max(40),
});

function speakable(text: string): string {
  return text
    .replace(/\[\[\d+\]\]\([^)]+\)/g, "")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/[*_`#>]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 700);
}

export const Route = createFileRoute("/api/speak")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        if (!allow("speak", 10, 60_000)) {
          return Response.json(
            { ok: false, error: "Voice needs a minute. Read this one, or try again shortly." },
            { status: 429 },
          );
        }

        let json: unknown;
        try {
          json = await request.json();
        } catch {
          return Response.json({ ok: false, error: "Nothing to say." }, { status: 400 });
        }

        const parsed = bodySchema.safeParse(json);
        if (!parsed.success) {
          return Response.json({ ok: false, error: "That was too long to speak." }, { status: 400 });
        }

        const text = speakable(parsed.data.text);
        if (!text) {
          return Response.json({ ok: false, error: "Nothing to say." }, { status: 400 });
        }

        const apiKey = process.env.XAI_API_KEY;
        if (!apiKey) {
          return Response.json({ ok: false, error: "Voice isn't available here." }, { status: 503 });
        }

        const voiceId = VOICES.has(parsed.data.voiceId) ? parsed.data.voiceId : "leo";
        const upstream = await fetch("https://api.x.ai/v1/tts", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ text, voice_id: voiceId, language: "en" }),
        });

        if (!upstream.ok || !upstream.body) {
          return Response.json({ ok: false, error: "Charlie couldn't speak just now." }, { status: 502 });
        }

        return new Response(upstream.body, {
          headers: {
            "Content-Type": upstream.headers.get("content-type") || "audio/mpeg",
            "Cache-Control": "no-store",
          },
        });
      },
    },
  },
});
