import { createFileRoute } from "@tanstack/react-router";

async function post({ request }: { request: Request }) {
  const { handleAurora } = await import("@/lib/aurora/grok.server");
  return handleAurora(request);
}

export const Route = createFileRoute("/api/aurora")({
  server: { handlers: { POST: post } },
});
