import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { allow } from "@/lib/charlie/guard.server";
import { charlieInstructions } from "@/lib/charlie/prompt.server";
import type { Citation } from "@/lib/charlie/types";

const bodySchema = z.object({
  conversationId: z.string().trim().min(1).max(80),
  profile: z.object({
    name: z.string().max(80).optional(),
    notes: z.string().max(1200).optional(),
  }),
  messages: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().trim().min(1).max(4000),
      }),
    )
    .min(1)
    .max(16),
});

function sse(event: string, data: unknown): string {
  return `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
}

function hostLabel(url: string, title?: string): string {
  if (title && !/^\d+$/.test(title.trim()) && title.trim().length > 1 && title.trim().length < 80) {
    return title.trim();
  }
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "Source";
  }
}

function pushCitation(into: Map<string, string>, url: unknown, title?: unknown) {
  if (typeof url !== "string" || !/^https?:\/\//i.test(url)) return;
  const label = hostLabel(url, typeof title === "string" ? title : undefined);
  if (!into.has(url)) into.set(url, label);
}

function collectCitations(node: unknown, into: Map<string, string>) {
  if (!node || typeof node !== "object") return;
  const record = node as Record<string, unknown>;

  if (record.type === "url_citation") {
    pushCitation(into, record.url, record.title);
  }

  if (record.type === "web_search_call") {
    const action = record.action;
    if (action && typeof action === "object") {
      const sources = (action as { sources?: unknown }).sources;
      if (Array.isArray(sources)) {
        for (const source of sources) {
          if (source && typeof source === "object") {
            const item = source as { url?: unknown; title?: unknown };
            pushCitation(into, item.url, item.title);
          }
        }
      }
    }
  }

  if (Array.isArray(record.annotations)) {
    for (const ann of record.annotations) collectCitations(ann, into);
  }
  if (Array.isArray(record.content)) {
    for (const part of record.content) collectCitations(part, into);
  }
  if (Array.isArray(record.output)) {
    for (const item of record.output) collectCitations(item, into);
  }
}

function citationsOf(map: Map<string, string>): Citation[] {
  return [...map.entries()].slice(0, 6).map(([url, label]) => ({ url, label }));
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        if (!allow("chat", 16, 60_000)) {
          return Response.json(
            { ok: false, error: "Charlie needs a short breather. Try again in a minute." },
            { status: 429 },
          );
        }

        let json: unknown;
        try {
          json = await request.json();
        } catch {
          return Response.json({ ok: false, error: "That message didn't come through." }, { status: 400 });
        }

        const parsed = bodySchema.safeParse(json);
        if (!parsed.success) {
          return Response.json(
            { ok: false, error: "Keep it a little shorter and try again." },
            { status: 400 },
          );
        }

        const last = parsed.data.messages[parsed.data.messages.length - 1];
        if (last.role !== "user") {
          return Response.json({ ok: false, error: "Say something and Charlie will answer." }, { status: 400 });
        }

        const apiKey = process.env.XAI_API_KEY;
        if (!apiKey) {
          return Response.json(
            { ok: false, error: "Charlie can't think in this environment yet." },
            { status: 503 },
          );
        }

        const history = parsed.data.messages.slice(-12).map((message) => ({
          role: message.role,
          content: message.content,
        }));

        let upstream: Response;
        try {
          upstream = await fetch("https://api.x.ai/v1/responses", {
            method: "POST",
            signal: request.signal,
            headers: {
              Authorization: `Bearer ${apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: "grok-4.5",
              store: false,
              stream: true,
              temperature: 0.8,
              max_output_tokens: 700,
              max_tool_calls: 2,
              reasoning: { effort: "low" },
              prompt_cache_key: parsed.data.conversationId,
              instructions: charlieInstructions({
                name: parsed.data.profile.name ?? "",
                notes: parsed.data.profile.notes ?? "",
              }),
              tools: [{ type: "web_search" }, { type: "x_search" }],
              input: history,
            }),
          });
        } catch (error) {
          if (error instanceof DOMException && error.name === "AbortError") {
            return new Response(null, { status: 499 });
          }
          return Response.json(
            { ok: false, error: "Charlie couldn't reach the web just now." },
            { status: 502 },
          );
        }

        if (!upstream.ok || !upstream.body) {
          return Response.json(
            { ok: false, error: "Charlie stumbled. Try that once more." },
            { status: 502 },
          );
        }

        const encoder = new TextEncoder();
        const decoder = new TextDecoder();
        const citations = new Map<string, string>();
        let full = "";

        const stream = new ReadableStream({
          async start(controller) {
            const send = (event: string, data: unknown) => {
              try {
                controller.enqueue(encoder.encode(sse(event, data)));
              } catch {
                /* The client already left. */
              }
            };
            send("status", { phase: "thinking" });

            const reader = upstream.body!.getReader();
            let buffer = "";
            try {
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const blocks = buffer.split(/\r?\n\r?\n/);
                buffer = blocks.pop() ?? "";
                for (const block of blocks) {
                  const dataLines = block
                    .split(/\r?\n/)
                    .filter((line) => line.startsWith("data:"))
                    .map((line) => line.slice(5).trim());
                  if (!dataLines.length || dataLines[0] === "[DONE]") continue;
                  let payload: Record<string, unknown>;
                  try {
                    payload = JSON.parse(dataLines.join("\n")) as Record<string, unknown>;
                  } catch {
                    continue;
                  }
                  const type = typeof payload.type === "string" ? payload.type : "";
                  if (type === "response.output_item.added") {
                    const item = payload.item as { type?: string } | undefined;
                    if (item?.type === "web_search_call" || item?.type === "x_search_call") {
                      send("status", { phase: "searching" });
                    }
                    collectCitations(item, citations);
                  }
                  if (type === "response.output_text.delta" && typeof payload.delta === "string") {
                    full += payload.delta;
                    send("delta", { text: payload.delta });
                  }
                  if (type === "response.output_text.done" || type === "response.completed") {
                    collectCitations(payload, citations);
                    const response = payload.response;
                    if (response) collectCitations(response, citations);
                  }
                  if (type === "response.failed" || type === "error") {
                    send("error", { message: "Charlie couldn't finish that. Try again." });
                  }
                }
              }
            } catch (error) {
              if (!(error instanceof DOMException && error.name === "AbortError")) {
                send("error", { message: "The line dropped. Charlie kept what was already said." });
              }
            } finally {
              send("done", { text: full, citations: citationsOf(citations) });
              controller.close();
            }
          },
        });

        return new Response(stream, {
          headers: {
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
          },
        });
      },
    },
  },
});
