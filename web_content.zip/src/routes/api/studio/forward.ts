import { createFileRoute } from "@tanstack/react-router";

const HOP_BY_HOP = new Set([
  "connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailers",
  "transfer-encoding",
  "upgrade",
  "host",
  "content-length",
  "origin",
  "referer",
]);

function isBlockedHost(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/\.$/, "");
  if (!host) return true;
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) return true;
  if (host === "0.0.0.0" || host === "::" || host === "::1" || host === "[::1]") return true;
  const ipv4 = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (ipv4) {
    const parts = ipv4.slice(1).map((n) => Number(n));
    const [a, b] = parts;
    if (parts.some((n) => n > 255)) return true;
    if (a === 10 || a === 127 || a === 0) return true;
    if (a === 192 && b === 168) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 169 && b === 254) return true;
  }
  if (host.includes(":")) {
    if (host.startsWith("fc") || host.startsWith("fd") || host.startsWith("fe80")) return true;
  }
  return false;
}

export const Route = createFileRoute("/api/studio/forward")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const target = request.headers.get("x-studio-target") ?? "";
        let url: URL;
        try {
          url = new URL(target);
        } catch {
          return Response.json({ error: "Invalid target" }, { status: 400 });
        }
        if (url.protocol !== "https:" || isBlockedHost(url.hostname) || url.username || url.password) {
          return Response.json({ error: "Provider host is not allowed" }, { status: 400 });
        }

        const method = (request.headers.get("x-studio-method") ?? "POST").toUpperCase();
        const headers = new Headers();
        request.headers.forEach((value, key) => {
          const lower = key.toLowerCase();
          if (lower.startsWith("x-studio-")) return;
          if (HOP_BY_HOP.has(lower)) return;
          headers.set(key, value);
        });

        const body =
          method === "GET" || method === "HEAD" ? undefined : await request.arrayBuffer();

        try {
          const res = await fetch(url.toString(), {
            method,
            headers,
            body,
          });
          const payload = await res.arrayBuffer();
          const out = new Headers();
          const contentType = res.headers.get("content-type");
          if (contentType) out.set("content-type", contentType);
          const uploadUrl =
            res.headers.get("x-goog-upload-url") ?? res.headers.get("X-Goog-Upload-URL");
          if (uploadUrl) out.set("x-goog-upload-url", uploadUrl);
          return new Response(payload, { status: res.status, headers: out });
        } catch {
          return Response.json({ error: "Unable to reach the selected provider" }, { status: 502 });
        }
      },
    },
  },
});
