import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { REST_PRESETS } from "@/lib/defaults";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/configuracoes")({
  component: SettingsPage,
});

function SettingsPage() {
  const settings = useAppStore((s) => s.settings);
  const patchSettings = useAppStore((s) => s.patchSettings);
  const restoreSettings = useAppStore((s) => s.restoreSettings);
  const resetAllData = useAppStore((s) => s.resetAllData);
  const addExtraHabit = useAppStore((s) => s.addExtraHabit);
  const removeExtraHabit = useAppStore((s) => s.removeExtraHabit);
  const renameExtraHabit = useAppStore((s) => s.renameExtraHabit);
  const [habitName, setHabitName] = useState("");
  const [customRest, setCustomRest] = useState("");

  return (
    <div className="animate-in fade-in duration-300">
      <PageHeader
        kicker="Conta local"
        title="Configurações"
        subtitle="Tudo fica neste aparelho. Nada some ao fechar o app."
      />

      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Perfil</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 pt-3">
            <Label htmlFor="name">Nome / apelido</Label>
            <Input
              id="name"
              value={settings.name}
              onChange={(e) => patchSettings({ name: e.target.value })}
              placeholder="Como você quer ser chamado"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Preferências de treino</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-3">
            <Label>Tempo padrão de descanso</Label>
            <div className="flex flex-wrap gap-2">
              {REST_PRESETS.map((s) => (
                <Button
                  key={s}
                  size="sm"
                  variant={settings.defaultRest === s ? "default" : "secondary"}
                  onClick={() => patchSettings({ defaultRest: s })}
                >
                  {s}s
                </Button>
              ))}
            </div>
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                const n = Number(customRest);
                if (!Number.isFinite(n) || n < 0) return;
                patchSettings({ defaultRest: Math.round(n) });
                setCustomRest("");
                toast.success("Descanso padrão atualizado");
              }}
            >
              <Input
                inputMode="numeric"
                placeholder="Personalizar (segundos)"
                value={customRest}
                onChange={(e) => setCustomRest(e.target.value)}
              />
              <Button type="submit" variant="outline">
                Aplicar
              </Button>
            </form>
            <p className="text-xs text-muted-foreground">
              Atual: {settings.defaultRest}s — usado em exercícios novos.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Som e avisos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-3">
            <Row
              label="Som do cronômetro"
              checked={settings.soundEnabled}
              onChange={(v) => patchSettings({ soundEnabled: v })}
            />
            <Row
              label="Notificações visuais"
              checked={settings.notificationsEnabled}
              onChange={(v) => patchSettings({ notificationsEnabled: v })}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Tema</CardTitle>
          </CardHeader>
          <CardContent className="pt-3">
            <p className="text-sm text-muted-foreground">
              Preto + roxo neon. O visual do PROJETO 101 não muda — é o produto.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Metas</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 pt-3 sm:grid-cols-2">
            <label className="space-y-1">
              <Label>Água (ml)</Label>
              <Input
                type="number"
                min={250}
                step={50}
                value={settings.waterGoalMl}
                onChange={(e) =>
                  patchSettings({
                    waterGoalMl: Math.max(250, Number(e.target.value) || 2000),
                  })
                }
              />
            </label>
            <label className="space-y-1">
              <Label>Sono (horas)</Label>
              <Input
                type="number"
                min={4}
                max={12}
                step={0.5}
                value={settings.sleepGoalHours}
                onChange={(e) =>
                  patchSettings({
                    sleepGoalHours: Math.max(
                      4,
                      Number(e.target.value) || 8,
                    ),
                  })
                }
              />
            </label>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Hábitos extras</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-3">
            {settings.extraHabits.map((h) => (
              <div key={h.id} className="flex gap-2">
                <Input
                  value={h.name}
                  onChange={(e) => renameExtraHabit(h.id, e.target.value)}
                />
                <Button
                  variant="outline"
                  onClick={() => removeExtraHabit(h.id)}
                >
                  Remover
                </Button>
              </div>
            ))}
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                if (!habitName.trim()) return;
                addExtraHabit(habitName);
                setHabitName("");
                toast.success("Hábito adicionado");
              }}
            >
              <Input
                value={habitName}
                onChange={(e) => setHabitName(e.target.value)}
                placeholder="Novo hábito"
              />
              <Button type="submit" variant="outline">
                Adicionar
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Restaurar</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-2 pt-3 sm:flex-row">
            <Button
              variant="outline"
              onClick={() => {
                restoreSettings();
                toast.success("Configurações restauradas");
              }}
            >
              Restaurar configurações
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">Apagar todos os dados</Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Apagar o progresso?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Dias, sessões, treinos editados e hábitos voltam ao estado
                    original. Isso não tem volta.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => {
                      resetAllData();
                      toast.success("Dados apagados");
                    }}
                  >
                    Apagar
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Row({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-sm">{label}</span>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
