import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { glossEntries } from "@/data/glossary";
import { useStudy } from "@/lib/study-store";

export const Route = createFileRoute("/glossario")({ component: Glossario });

function Glossario() {
  const [q, setQ] = useState("");
  const asks = useStudy((s) => s.asks);
  const entries = useMemo(() => {
    const query = q.trim().toLowerCase();
    return glossEntries().filter((e) => {
      if (e.key.length < 4 && !e.note) return false;
      if (!query) return Boolean(e.note) || e.key.includes(" ");
      return e.key.includes(query) || e.ar.includes(q.trim());
    });
  }, [q]);

  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm text-primary">Dizionario</p>
        <h1 className="text-3xl font-semibold">القاموس</h1>
        <p className="mt-2 text-muted">
          من أي جملة في المنهج أو الامتحان اضغط الكلمة. هنا مصطلحات القيادة، وتحتُها الأسئلة التي حفظتها بعد الشرح.
        </p>
      </header>
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="ابحث: precedenza، حزام، nebbia…"
        className="min-h-11 w-full rounded-xl border border-line bg-surface px-3 outline-none focus:border-primary"
      />
      <ul className="space-y-2">
        {entries.slice(0, 80).map((e) => (
          <li key={e.key} className="rounded-2xl border border-line bg-surface px-3 py-3">
            <p dir="ltr" lang="it" className="text-left text-lg font-semibold">
              {e.key}
            </p>
            <p className="text-base">{e.ar}</p>
            {e.note ? <p className="mt-1 text-sm text-muted">{e.note}</p> : null}
          </li>
        ))}
      </ul>
      <section>
        <h2 className="text-2xl font-semibold">أسئلتي المحفوظة</h2>
        {asks.length === 0 ? (
          <p className="mt-2 text-muted">لما تضغط كلمة وتطلب شرحًا ثم تحفظه، يظهر هنا.</p>
        ) : (
          <ul className="mt-3 space-y-3">
            {asks.map((a) => (
              <li key={a.id} className="rounded-2xl bg-warn px-3 py-3 text-warn-ink">
                <p dir="ltr" lang="it" className="text-left font-semibold">
                  {a.word}
                </p>
                <p className="mt-1 text-sm">{a.question}</p>
                <p className="mt-2 text-sm leading-relaxed">{a.answer}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
