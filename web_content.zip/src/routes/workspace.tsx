import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ComponentType } from "react";
import "@/lib/nijo/ai";

type Intent = "paste" | "open" | undefined;

export const Route = createFileRoute("/workspace")({
  validateSearch: (search: Record<string, unknown>): { intent?: Intent } => ({
    intent: search.intent === "paste" || search.intent === "open" ? search.intent : undefined,
  }),
  component: WorkspacePage,
});

function WorkspacePage() {
  const { intent } = Route.useSearch();
  const [App, setApp] = useState<ComponentType<{ intent?: Intent }> | null>(null);

  useEffect(() => {
    void import("@/components/workspace/workspace-app").then((mod) => {
      setApp(() => mod.WorkspaceApp);
    });
  }, []);

  if (!App) {
    return (
      <div className="grid h-dvh place-items-center bg-bg text-sm text-muted">
        Opening workspace…
      </div>
    );
  }

  return <App intent={intent} />;
}
