import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Card, Page, fieldClass } from "@/components/ui";
import { NAWAWI } from "@/data/nawawi";
import { includesArabic } from "@/lib/arabic";
import { usePrefs } from "@/lib/prefs";

export const Route = createFileRoute("/hadith")({ component: HadithPage });

const NOTES: Record<number, string> = {
  1: "مدار الأعمال على النية.",
  2: "حديث جبريل في الإسلام والإيمان والإحسان والساعة.",
  3: "أركان الإسلام الخمس.",
  4: "مراحل خلق الإنسان وختمها بالقدر.",
  5: "من أحدث في أمرنا هذا ما ليس منه فهو رد.",
  6: "الحلال بيّن والحرام بيّن.",
  7: "الدين النصيحة.",
  8: "حرمة دم المسلم وماله وعرضه.",
  9: "تغيير المنكر باليد ثم اللسان ثم القلب.",
  10: "ما ملأ آدمي وعاءً شرًا من بطن.",
  11: "دع ما يريبك إلى ما لا يريبك.",
  12: "من حسن إسلام المرء تركه ما لا يعنيه.",
  13: "لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.",
  14: "لا يحل دم امرئ مسلم إلا بإحدى ثلاث.",
  15: "من كان يؤمن بالله واليوم الآخر فليقل خيرًا أو ليصمت.",
  16: "لا تغضب.",
  17: "إن الله كتب الإحسان على كل شيء.",
  18: "اتق الله حيثما كنت.",
  19: "احفظ الله يحفظك.",
  20: "الحياء من الإيمان.",
  21: "قل آمنت بالله ثم استقم.",
  22: "الطهور شطر الإيمان.",
  23: "يا عبادي إني حرمت الظلم على نفسي.",
  24: "البعد عن محارم الله هو الورع.",
  25: "الذهب بالذهب مثلًا بمثل، وأبواب الربا.",
  26: "كل سلامى من الناس عليه صدقة.",
  27: "البر حسن الخلق والإثم ما حاك في النفس.",
  28: "أوصيكم بتقوى الله والسمع والطاعة.",
  29: "أبواب الخير: اتق المحارم تكن أعبد الناس.",
  30: "إن الله فرض فرائض فلا تضيعوها.",
  31: "ازهد في الدنيا يحبك الله.",
  32: "لا ضرر ولا ضرار.",
  33: "البينة على المدعي واليمين على من أنكر.",
  34: "من رأى منكم منكرًا فليغيره.",
  35: "لا تحاسدوا ولا تناجشوا وكونوا إخوانًا.",
  36: "من نفّس عن مؤمن كربة.",
  37: "إن الله كتب الحسنات والسيئات.",
  38: "من عادى لي وليًا فقد آذنته بالحرب.",
  39: "إن الله تجاوز لي عن أمتي الخطأ والنسيان.",
  40: "كن في الدنيا كأنك غريب.",
  41: "لا يؤمن أحدكم حتى يكون هواه تبعًا لما جئت به.",
  42: "يا ابن آدم إنك ما دعوتني ورجوتني غفرت لك.",
};

function HadithPage() {
  const [q, setQ] = useState("");
  const prefs = usePrefs();
  const list = useMemo(() => NAWAWI.filter((h) => !q || includesArabic(h.text, q) || String(h.n) === q.trim()), [q]);
  return (
    <Page
      title="الحديث الشريف"
      subtitle="هذه النسخة تضم متن الأربعين النووية كاملًا (42 حديثًا كما في النسخ المشهورة). ليست صحيح البخاري ولا مسلم ولا السنن الأربعة بنصها؛ لم ندرجها حتى لا ننسب كتابًا ناقصًا على أنه تام، ولتفادي أحكام صحة لم نتحقق من أرقامها واحدًا واحدًا خارج هذا المتن."
    >
      <input className={fieldClass} placeholder="ابحث في المتن" value={q} onChange={(e) => setQ(e.target.value)} />
      <p className="my-2 text-xs text-muted">النووي انتقى هذه الأحاديث وغالبها في الصحيحين. الشرح سطر واحد للمعنى لا تخريجًا جديدًا.</p>
      <ul className="space-y-3">
        {list.map((h) => (
          <li key={h.n}>
            <Card>
              <div className="flex justify-between gap-2">
                <h2 className="font-bold">الحديث {h.n}</h2>
                <button type="button" className="text-sm text-gold" onClick={() => prefs.toggleFav({ id: `hadith-${h.n}`, kind: "hadith", title: `النووية ${h.n}`, text: h.text })}>
                  حفظ
                </button>
              </div>
              <p className="mt-2 text-sm leading-relaxed">{h.text}</p>
              <p className="mt-2 text-sm text-emerald">{NOTES[h.n]}</p>
              <p className="mt-1 text-xs text-muted">المصدر: متن الأربعين النووية · الراوي مذكور في المتن · الدرجة: مما استقر عند أهل العلم في هذا المجموع، وغالبها صحيح.</p>
              <button
                type="button"
                className="mt-2 min-h-11 text-sm"
                onClick={() => void navigator.clipboard.writeText(`${h.text}\n— الأربعون النووية (${h.n})`)}
              >
                نسخ
              </button>
            </Card>
          </li>
        ))}
      </ul>
    </Page>
  );
}
