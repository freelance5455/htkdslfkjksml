import { createFileRoute } from "@tanstack/react-router";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PageHeader } from "@/components/page-header";
import { StatCard } from "@/components/stat-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  PROJECT_DAYS,
  allProjectDates,
  getDayChecks,
  getDayStatus,
} from "@/lib/dates";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/estatisticas")({
  component: StatsPage,
});

function StatsPage() {
  const logs = useAppStore((s) => s.logs);
  const settings = useAppStore((s) => s.settings);
  const sessions = useAppStore((s) => s.sessions);
  const dates = allProjectDates();

  let skin = 0;
  let water = 0;
  let sleep = 0;
  let complete = 0;
  const series = dates.map((d, i) => {
    const log = logs[d];
    const c = getDayChecks(log, settings);
    if (c.skinCare) skin += 1;
    if (c.water) water += 1;
    if (c.sleep) sleep += 1;
    if (getDayStatus(log, settings) === "complete") complete += 1;
    return {
      day: i + 1,
      habitos: c.doneCount,
      agua: Math.min(settings.waterGoalMl, log?.waterMl ?? 0),
      sono: log?.sleepHours ?? 0,
    };
  });

  const treinos = sessions.filter((s) => s.type !== "postura").length;
  const postura = sessions.filter((s) => s.type === "postura").length;

  return (
    <div className="animate-in fade-in duration-300">
      <PageHeader
        kicker="Consistência"
        title="Estatísticas"
        subtitle="Progresso por hábitos e sessões. Sem peso, sem medidas."
      />
      <div className="mb-5 grid grid-cols-2 gap-3">
        <StatCard label="Dias do projeto" value={`${complete} / ${PROJECT_DAYS}`} />
        <StatCard label="Treinos realizados" value={treinos} />
        <StatCard label="Sessões de postura" value={postura} />
        <StatCard label="Dias com skin care" value={skin} />
        <StatCard label="Dias com meta de água" value={water} />
        <StatCard label="Dias com 8h de sono" value={sleep} />
        <StatCard
          label="Dias completos"
          value={complete}
          className="col-span-2"
        />
      </div>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>Hábitos por dia</CardTitle>
        </CardHeader>
        <CardContent className="h-52 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={series}>
              <CartesianGrid stroke="rgb(42 32 56)" vertical={false} />
              <XAxis
                dataKey="day"
                tick={{ fill: "#a39bb3", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "#a39bb3", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                width={28}
              />
              <Tooltip
                contentStyle={{
                  background: "#14141e",
                  border: "1px solid #2a2038",
                  borderRadius: 12,
                  fontSize: 12,
                }}
                labelFormatter={(v) => `Dia ${v}`}
              />
              <Area
                type="monotone"
                dataKey="habitos"
                stroke="#c084fc"
                fill="rgba(192,132,252,0.25)"
                strokeWidth={2}
                name="Hábitos"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Água (ml)</CardTitle>
        </CardHeader>
        <CardContent className="h-52 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={series}>
              <CartesianGrid stroke="rgb(42 32 56)" vertical={false} />
              <XAxis
                dataKey="day"
                tick={{ fill: "#a39bb3", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "#a39bb3", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                width={36}
              />
              <Tooltip
                contentStyle={{
                  background: "#14141e",
                  border: "1px solid #2a2038",
                  borderRadius: 12,
                  fontSize: 12,
                }}
                labelFormatter={(v) => `Dia ${v}`}
              />
              <Area
                type="monotone"
                dataKey="agua"
                stroke="#c084fc"
                fill="rgba(192,132,252,0.2)"
                strokeWidth={2}
                name="ml"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
