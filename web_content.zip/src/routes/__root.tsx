import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCss from "../styles.css?url";

const APP_NAME = "Aurora";

const LOCATION_LOCK = `(() => {
  const fail = (err) => {
    if (typeof err === "function") {
      err({ code: 1, message: "Location blocked", PERMISSION_DENIED: 1 });
    }
  };
  const geo = {
    getCurrentPosition(_ok, err) { fail(err); },
    watchPosition(_ok, err) { fail(err); return 0; },
    clearWatch() {}
  };
  try {
    Object.defineProperty(Navigator.prototype, "geolocation", {
      configurable: true,
      get() { return geo; }
    });
  } catch (_) {}
})();`;

export const Route = createRootRoute({
  headers: () => ({
    "Permissions-Policy": "geolocation=(), camera=(), microphone=(), display-capture=()",
    "Referrer-Policy": "no-referrer",
    "X-Content-Type-Options": "nosniff",
  }),
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      { name: "theme-color", content: "#050208" },
      {
        name: "description",
        content:
          "Aurora is an anonymous assistant. No account, location stays blocked, and a shred wipes the visit.",
      },
    ],
    links: [
      { rel: "icon", type: "image/png", href: "/aurora-icon-180.png" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600&family=Syne:wght@600;700&display=swap",
      },
    ],
  }),
  component: () => (
    <html lang="en" suppressHydrationWarning>
      <head>
        <HeadContent />
        <script dangerouslySetInnerHTML={{ __html: LOCATION_LOCK }} />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <Outlet />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
