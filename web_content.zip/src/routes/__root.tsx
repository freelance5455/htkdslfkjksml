import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { Shell } from "@/components/shell";
import { WordProvider } from "@/components/word-context";
import appCss from "../styles.css?url";

const APP_NAME = "Patente · الرخصة الإيطالية";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      {
        name: "description",
        content:
          "منهج الرخصة الإيطالية Patente B بالإيطالي والعربي، مع الإشارات وأسئلة الامتحان. تم إنشاؤه بواسطة محمد صبح.",
      },
      { name: "theme-color", content: "#0f6e56" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Literata:ital,opsz,wght@0,7..72,500;0,7..72,680;0,7..72,760;1,7..72,500&family=Noto+Naskh+Arabic:wght@500;600;700&display=swap",
      },
    ],
  }),
  component: () => (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <WordProvider>
            <Shell>
              <Outlet />
            </Shell>
          </WordProvider>
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
