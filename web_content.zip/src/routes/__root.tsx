import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { useEffect } from "react";
import { Toaster } from "sonner";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { useCaliber } from "@/lib/store";
import appCss from "../styles.css?url";

const APP_NAME = "Caliber";

function LanguageDirSync() {
  const lang = useCaliber((s) => s.lang);
  const hydrateLang = useCaliber((s) => s.hydrateLang);
  useEffect(() => {
    hydrateLang();
  }, [hydrateLang]);
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);
  return null;
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      {
        name: "description",
        content: "Hardware-tuned Free Fire sensitivity, DPI, and fire-button settings.",
      },
      { name: "theme-color", content: "#0f172a" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Rajdhani:wght@500;600;700&display=swap",
      },
    ],
  }),
  component: () => (
    <html lang="en" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body className="hex-grid antialiased">
        <PreviewHostBridge />
        <AuthProvider>
          <LanguageDirSync />
          <Outlet />
          <Toaster theme="dark" position="bottom-center" />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
