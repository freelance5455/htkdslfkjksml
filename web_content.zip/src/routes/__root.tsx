import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { Toaster } from "sonner";
import appCss from "../styles.css?url";

const APP_NAME = "رفيق";
const THEME_BOOT = `(function(){try{var s=JSON.parse(localStorage.getItem("rafeeq")||"{}");var t=(s.state&&s.state.settings&&s.state.settings.theme)||"system";var large=s.state&&s.state.settings&&s.state.settings.largeDisplay;var dark=t==="dark"||(t!=="light"&&window.matchMedia("(prefers-color-scheme: dark)").matches);var e=document.documentElement;e.lang="ar";e.dir="rtl";if(dark)e.classList.add("dark");if(large)e.classList.add("large-ui");}catch(x){}})();`;

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      { name: "description", content: "رفيق — مصحف يومي، أذكار، ومكتبة شرعية هادئة تعمل دون اتصال." },
      { name: "theme-color", content: "#1C3D32" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap",
      },
    ],
    scripts: [{ children: THEME_BOOT }],
  }),
  component: () => (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body className="antialiased">
        <PreviewHostBridge />
        <AuthProvider>
          <Outlet />
          <Toaster position="top-center" dir="rtl" richColors={false} />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
