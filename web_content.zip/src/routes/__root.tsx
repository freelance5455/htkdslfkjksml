import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCss from "../styles.css?url";

const APP_NAME = "Smart Calculator Pro";

const THEME_BOOT = `(function(){try{var raw=localStorage.getItem("scp-store");var s=raw?(JSON.parse(raw).state||{}):{};var mode=s.theme||"dark";if(mode==="system"){mode=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}var el=document.documentElement;el.dataset.mode=mode==="light"?"light":"dark";el.dataset.accent=s.accent||"gold";var meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.setAttribute("content",mode==="light"?"#f3efe6":"#12130f");}catch(e){}})();`;

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      {
        name: "description",
        content:
          "Smart Calculator Pro — scientific calculator and live world currency converter.",
      },
      { name: "theme-color", content: "#12130f" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
    scripts: [{ children: THEME_BOOT }],
  }),
  component: Root,
});

function Root() {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <Outlet />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}
