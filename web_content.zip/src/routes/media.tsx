import { createFileRoute } from "@tanstack/react-router";
import { PageIntro, Tag } from "@/components/page";
import { ANNOUNCED_MEDIA_TYPES, OFFICIAL_MEDIA } from "@/data/campaign";

export const Route = createFileRoute("/media")({
  head: () => ({ meta: [{ title: "المحاضرات والوسائط — لأنه الله" }] }),
  component: MediaPage,
});

function MediaPage() {
  return (
    <main>
      <PageIntro
        kicker="لا تسجيلات مختلقة"
        title="المحاضرات والوسائط"
        lede="تُعرض هنا المواد التي أُحيل إليها من الحساب الرسمي للوزارة. ما سوى ذلك يبقى بانتظار رابط حقيقي، ولا تُخترع أسماء شيوخ ولا روابط فيديو."
      />
      <section className="mx-auto max-w-4xl px-4 py-8">
        <article className="rounded-card border border-line bg-surface p-5">
          <div className="flex flex-wrap gap-2"><Tag>ندوة موثقة</Tag><Tag>{OFFICIAL_MEDIA.date}</Tag></div>
          <h2 className="mt-3 font-display text-3xl text-primary">{OFFICIAL_MEDIA.title}</h2>
          <p className="mt-2 text-sm text-muted">{OFFICIAL_MEDIA.speaker} · {OFFICIAL_MEDIA.publisher}</p>
          <p className="mt-3 leading-8">{OFFICIAL_MEDIA.description}</p>
          <div className="mt-4 aspect-video overflow-hidden rounded-card border border-line">
            <iframe
              className="h-full w-full"
              src={`https://www.youtube-nocookie.com/embed/${OFFICIAL_MEDIA.youtubeId}`}
              title={OFFICIAL_MEDIA.title}
              loading="lazy"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
          <a className="mt-4 inline-block text-primary" href={OFFICIAL_MEDIA.url} rel="noreferrer">الرابط الأصلي</a>
        </article>
        <h2 className="mt-10 font-display text-3xl text-primary">أنواع أعلنتها الوزارة ولم يُربط تسجيلها هنا</h2>
        <ul className="mt-4 grid gap-3">
          {ANNOUNCED_MEDIA_TYPES.map((item) => (
            <li key={item} className="rounded-card border border-dashed border-line p-4">
              <p className="font-medium">{item}</p>
              <p className="mt-1 text-sm text-muted">المحتوى لم يُضف بعد لأن التسجيل المحدد غير متاح في هذه الصفحة.</p>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
