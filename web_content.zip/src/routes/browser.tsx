import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowLeft,
  ArrowRight,
  ExternalLink,
  Home,
  Plus,
  RefreshCw,
  ShieldAlert,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SEARCH_ENGINES } from "@/lib/constants";
import { useBrowser } from "@/lib/browser-store";
import { useDownloads } from "@/lib/download-store";
import { useLibrary } from "@/lib/library-store";
import { usePlayer } from "@/lib/player-store";
import { useSettings } from "@/lib/settings-store";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/browser")({ component: BrowserPage });

const DIRECT = /\.(mp4|webm|ogg|ogv|mp3|wav|m4a|aac|flac|opus|mov|m4v)(\?|$)/i;

function BrowserPage() {
  const tabs = useBrowser((s) => s.tabs);
  const activeId = useBrowser((s) => s.activeId);
  const address = useBrowser((s) => s.address);
  const history = useBrowser((s) => s.history);
  const setAddress = useBrowser((s) => s.setAddress);
  const navigateTab = useBrowser((s) => s.navigate);
  const back = useBrowser((s) => s.back);
  const forward = useBrowser((s) => s.forward);
  const reload = useBrowser((s) => s.reload);
  const home = useBrowser((s) => s.home);
  const newTab = useBrowser((s) => s.newTab);
  const closeTab = useBrowser((s) => s.closeTab);
  const activate = useBrowser((s) => s.activate);
  const setTabMeta = useBrowser((s) => s.setTabMeta);
  const homepage = useSettings((s) => s.homepage);
  const engine = useSettings((s) => s.searchEngine);
  const remember = useSettings((s) => s.rememberHistory);
  const enqueue = useDownloads((s) => s.enqueue);
  const addUrl = useLibrary((s) => s.addUrl);
  const openPlayer = usePlayer((s) => s.open);
  const nav = useNavigate();
  const active = tabs.find((t) => t.id === activeId) ?? tabs[0];
  const prefix = SEARCH_ENGINES[engine].url;

  const go = (raw = address) => navigateTab(raw, prefix, remember);

  const playIfDirect = () => {
    if (!active) return;
    if (!DIRECT.test(active.url)) {
      toast.error("Not a direct media file. UPLAY.IND does not rip media from web pages.");
      return;
    }
    const item = addUrl(active.title || active.url, active.url, /\.(mp3|wav|m4a|aac|flac|opus)(\?|$)/i.test(active.url) ? "audio" : "video");
    openPlayer(item);
    void nav({ to: "/player/$id", params: { id: item.id } });
  };

  return (
    <div className="flex min-h-[70vh] flex-col gap-3">
      <header>
        <h1 className="font-display text-3xl font-semibold">Browser</h1>
        <p className="text-sm text-muted">
          A sandboxed page view. Camera, mic, and location are blocked. Many sites refuse to embed —
          open those externally.
        </p>
      </header>

      <div className="flex gap-1 overflow-x-auto">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => activate(t.id)}
            className={cn(
              "flex h-9 max-w-[10rem] items-center gap-1 rounded-lg px-2 text-xs",
              t.id === activeId ? "bg-secondary text-fg" : "text-muted",
            )}
          >
            <span className="truncate">{t.title || t.url}</span>
            <span
              role="button"
              tabIndex={0}
              className="rounded p-0.5 hover:bg-elevated"
              onClick={(e) => {
                e.stopPropagation();
                closeTab(t.id);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") closeTab(t.id);
              }}
            >
              <X className="size-3" />
            </span>
          </button>
        ))}
        <Button size="icon-sm" variant="ghost" onClick={newTab} aria-label="New tab">
          <Plus />
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Button size="icon" variant="ghost" onClick={back} aria-label="Back">
          <ArrowLeft />
        </Button>
        <Button size="icon" variant="ghost" onClick={forward} aria-label="Forward">
          <ArrowRight />
        </Button>
        <Button size="icon" variant="ghost" onClick={reload} aria-label="Reload">
          <RefreshCw />
        </Button>
        <Button size="icon" variant="ghost" onClick={() => home(homepage)} aria-label="Home">
          <Home />
        </Button>
        <form
          className="min-w-0 flex-1"
          onSubmit={(e) => {
            e.preventDefault();
            go();
          }}
        >
          <Input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            aria-label="Address or search"
            placeholder="Search or enter a URL"
          />
        </form>
        <Button variant="outline" onClick={playIfDirect}>
          Play URL
        </Button>
        <Button
          variant="outline"
          onClick={() => {
            if (!active) return;
            void enqueue(active.url);
            toast.message("Queued if this is a direct media file.");
          }}
        >
          Download
        </Button>
        <Button
          size="icon"
          variant="ghost"
          aria-label="Open externally"
          onClick={() => active && window.open(active.url, "_blank", "noopener,noreferrer")}
        >
          <ExternalLink />
        </Button>
      </div>

      <div className="relative min-h-[55vh] overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
        {active ? (
          <iframe
            key={active.url + String(active.loading)}
            title={active.title || "Browser tab"}
            src={active.url}
            className="size-full min-h-[55vh] bg-white"
            sandbox="allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads"
            referrerPolicy="no-referrer"
            allow=""
            onLoad={() => setTabMeta(active.id, { loading: false, title: active.url })}
            onError={() => setTabMeta(active.id, { blocked: true, loading: false })}
          />
        ) : null}
        {active?.blocked ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-surface p-6 text-center">
            <ShieldAlert className="size-8 text-primary" />
            <p className="font-medium">This page cannot be embedded</p>
            <Button
              variant="outline"
              onClick={() => window.open(active.url, "_blank", "noopener,noreferrer")}
            >
              Open externally
            </Button>
          </div>
        ) : null}
      </div>

      {remember && history.length > 0 ? (
        <section>
          <h2 className="text-sm font-medium text-muted">History on this device</h2>
          <ul className="mt-2 divide-y divide-border rounded-xl bg-surface">
            {history.slice(0, 12).map((h) => (
              <li key={h.id}>
                <button
                  type="button"
                  className="flex w-full truncate px-3 py-2 text-left text-sm hover:bg-secondary"
                  onClick={() => go(h.url)}
                >
                  {h.url}
                </button>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
