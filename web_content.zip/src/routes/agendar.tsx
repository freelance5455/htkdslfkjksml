import { useEffect, useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { CATALOG, findService, lineCents } from "@/lib/catalog";
import { brl, formatDayShort, toISODate } from "@/lib/format";
import { useStore } from "@/lib/store";
import { useHydrated } from "@/lib/use-hydrated";
import { usePublicProfile } from "@/lib/vitrine-context";
import { Button } from "@/components/button";
import { cn } from "@/lib/cn";

const TIMES = ["08:00", "10:00", "13:00", "15:00", "17:00"];

export const Route = createFileRoute("/agendar")({
  validateSearch: (search: Record<string, unknown>): { servico?: string } => {
    const servico = typeof search.servico === "string" && search.servico ? search.servico : undefined;
    return servico ? { servico } : {};
  },
  component: AgendarPage,
});

function upcomingDays() {
  const start = new Date();
  return Array.from({ length: 12 }, (_, index) => {
    const date = new Date(start);
    date.setDate(start.getDate() + index + 1);
    const iso = toISODate(date);
    return { iso, label: formatDayShort(iso) };
  });
}

function AgendarPage() {
  const { servico } = Route.useSearch();
  const navigate = useNavigate();
  const profile = usePublicProfile();
  const hydrated = useHydrated();
  const bookings = useStore((state) => state.bookings);
  const addBooking = useStore((state) => state.addBooking);
  const services = CATALOG.filter((service) => !profile.disabled.includes(service.id));
  const initial = services.some((service) => service.id === servico) ? servico : (services[0]?.id ?? "");
  const [serviceId, setServiceId] = useState(initial);
  const service = services.find((item) => item.id === serviceId) ?? services[0];
  const [optionId, setOptionId] = useState(service?.options[0]?.id ?? "");
  const [extraIds, setExtraIds] = useState<string[]>([]);
  const [days, setDays] = useState<{ iso: string; label: string }[]>([]);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [weekly, setWeekly] = useState(false);
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [neighborhood, setNeighborhood] = useState("");
  const [notes, setNotes] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const next = upcomingDays();
    setDays(next);
    setDate(next[0]?.iso ?? "");
  }, []);

  useEffect(() => {
    if (!service) return;
    if (!service.options.some((option) => option.id === optionId)) {
      setOptionId(service.options[0]?.id ?? "");
      setExtraIds([]);
    }
  }, [service, optionId]);

  const option = service?.options.find((item) => item.id === optionId) ?? service?.options[0];
  const selectedExtras = service?.extras.filter((extra) => extraIds.includes(extra.id)) ?? [];
  const total = option
    ? lineCents(option.id, option.cents, profile.prices) +
      selectedExtras.reduce((sum, extra) => sum + lineCents(extra.id, extra.cents, profile.prices), 0)
    : 0;

  const taken = useMemo(() => {
    if (!hydrated) return new Set<string>();
    return new Set(
      bookings
        .filter((booking) => !booking.demo && booking.status !== "cancelado")
        .map((booking) => `${booking.date}|${booking.time}`),
    );
  }, [bookings, hydrated]);

  function chooseService(id: string) {
    setServiceId(id);
    const next = findService(id);
    setOptionId(next?.options[0]?.id ?? "");
    setExtraIds([]);
    setError("");
  }

  function submit() {
    setError("");
    if (!service || !option) {
      setError("Escolha um serviço.");
      return;
    }
    if (!date || !time) {
      setError("Escolha o dia e a hora.");
      return;
    }
    if (taken.has(`${date}|${time}`)) {
      setError("Esse horário já tem serviço.");
      return;
    }
    if (customerName.trim().length < 3) {
      setError("Diga o nome de quem vai receber.");
      return;
    }
    if (phone.replace(/\D/g, "").length < 10) {
      setError("Telefone com DDD, para o profissional chamar.");
      return;
    }
    if (neighborhood.trim().length < 2) {
      setError("Diga o bairro.");
      return;
    }
    if (!agreed) {
      setError("Confirme que o preço e o que está incluso estão claros.");
      return;
    }
    try {
      const booking = addBooking({
        serviceId: service.id,
        optionId: option.id,
        extraIds,
        date,
        time,
        weekly,
        customerName,
        phone,
        neighborhood,
        notes,
      });
      void navigate({ to: "/pedido/$id", params: { id: booking.id } });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não deu para guardar o pedido.");
    }
  }

  if (!service || !option) {
    return (
      <main className="mx-auto max-w-3xl px-4 py-12">
        <h1 className="font-display text-4xl">Nada aberto para agendar</h1>
        <p className="mt-3 text-muted">Ative um serviço na caixa para voltar a receber pedidos.</p>
      </main>
    );
  }

  return (
    <main className="mx-auto grid max-w-5xl gap-8 px-4 py-8 lg:grid-cols-[1fr_300px]">
      <form
        className="space-y-8"
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
      >
        <div>
          <p className="text-sm font-semibold tracking-wide text-primary uppercase">Agendar</p>
          <h1 className="mt-2 font-display text-4xl">O que você precisa, e quando.</h1>
        </div>

        <fieldset>
          <legend className="font-display text-2xl">Serviço</legend>
          <div className="mt-3 grid gap-2">
            {services.map((item) => (
              <label
                key={item.id}
                className={cn(
                  "flex min-h-11 cursor-pointer items-center justify-between gap-3 rounded-md border px-3 py-3",
                  item.id === service.id ? "border-primary bg-surface" : "border-line bg-surface",
                )}
              >
                <span>
                  <span className="block font-semibold">{item.name}</span>
                  <span className="block text-sm text-muted">{item.summary}</span>
                </span>
                <input
                  type="radio"
                  name="servico"
                  checked={item.id === service.id}
                  onChange={() => chooseService(item.id)}
                />
              </label>
            ))}
          </div>
        </fieldset>

        <fieldset>
          <legend className="font-display text-2xl">Tamanho</legend>
          <div className="mt-3 grid gap-2">
            {service.options.map((item) => {
              const cents = lineCents(item.id, item.cents, profile.prices);
              return (
                <label
                  key={item.id}
                  className={cn(
                    "flex min-h-11 cursor-pointer items-center justify-between gap-3 rounded-md border px-3 py-3",
                    item.id === option.id ? "border-primary bg-surface" : "border-line",
                  )}
                >
                  <span>
                    <span className="block font-semibold">{item.label}</span>
                    <span className="block text-sm text-muted">{item.detail}</span>
                  </span>
                  <span className="flex items-center gap-3">
                    <span className="tabular-nums">{brl(cents)}</span>
                    <input
                      type="radio"
                      name="opcao"
                      checked={item.id === option.id}
                      onChange={() => setOptionId(item.id)}
                    />
                  </span>
                </label>
              );
            })}
          </div>
        </fieldset>

        {service.extras.length > 0 ? (
          <fieldset>
            <legend className="font-display text-2xl">Se precisar</legend>
            <div className="mt-3 grid gap-2">
              {service.extras.map((extra) => {
                const on = extraIds.includes(extra.id);
                return (
                  <label key={extra.id} className="flex min-h-11 items-center justify-between gap-3 rounded-md border border-line px-3 py-3">
                    <span>{extra.label}</span>
                    <span className="flex items-center gap-3">
                      <span className="tabular-nums text-sm">{brl(lineCents(extra.id, extra.cents, profile.prices))}</span>
                      <input
                        type="checkbox"
                        checked={on}
                        onChange={() =>
                          setExtraIds((current) =>
                            current.includes(extra.id)
                              ? current.filter((id) => id !== extra.id)
                              : [...current, extra.id],
                          )
                        }
                      />
                    </span>
                  </label>
                );
              })}
            </div>
          </fieldset>
        ) : null}

        <div className="rounded-md border border-line bg-surface-2 p-4 text-sm">
          <p className="font-semibold">Está incluso</p>
          <ul className="mt-2 list-disc space-y-1 pl-4">
            {service.includes.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <p className="mt-3 font-semibold">Não entra</p>
          <ul className="mt-2 list-disc space-y-1 pl-4 text-muted">
            {service.notIncluded.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>

        <fieldset>
          <legend className="font-display text-2xl">Dia</legend>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {days.map((day) => (
              <button
                key={day.iso}
                type="button"
                onClick={() => setDate(day.iso)}
                className={cn(
                  "min-h-11 rounded-md border px-2 text-sm font-semibold",
                  date === day.iso ? "border-primary bg-primary text-primary-fg" : "border-line bg-surface",
                )}
              >
                {day.label}
              </button>
            ))}
          </div>
        </fieldset>

        <fieldset>
          <legend className="font-display text-2xl">Hora</legend>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {TIMES.map((slot) => {
              const busy = taken.has(`${date}|${slot}`);
              return (
                <button
                  key={slot}
                  type="button"
                  disabled={busy}
                  onClick={() => setTime(slot)}
                  className={cn(
                    "min-h-11 rounded-md border text-sm font-semibold tabular-nums",
                    time === slot ? "border-primary bg-primary text-primary-fg" : "border-line bg-surface",
                  )}
                >
                  {busy ? "ocupado" : slot}
                </button>
              );
            })}
          </div>
        </fieldset>

        <label className="flex min-h-11 items-center gap-3 text-sm">
          <input type="checkbox" checked={weekly} onChange={(event) => setWeekly(event.target.checked)} />
          Quero repetir toda semana, se o horário continuar livre
        </label>

        <div className="grid gap-3">
          <label className="block text-sm font-semibold">
            Seu nome
            <input
              value={customerName}
              onChange={(event) => setCustomerName(event.target.value)}
              className="mt-1 h-12 w-full rounded-md border border-line bg-surface px-3 font-normal"
              autoComplete="name"
            />
          </label>
          <label className="block text-sm font-semibold">
            Telefone com DDD
            <input
              value={phone}
              onChange={(event) => setPhone(event.target.value)}
              className="mt-1 h-12 w-full rounded-md border border-line bg-surface px-3 font-normal"
              inputMode="tel"
              autoComplete="tel"
            />
          </label>
          <label className="block text-sm font-semibold">
            Bairro
            <input
              value={neighborhood}
              onChange={(event) => setNeighborhood(event.target.value)}
              className="mt-1 h-12 w-full rounded-md border border-line bg-surface px-3 font-normal"
            />
          </label>
          <label className="block text-sm font-semibold">
            Detalhe que muda o serviço
            <textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
              maxLength={280}
              rows={3}
              className="mt-1 w-full rounded-md border border-line bg-surface px-3 py-2 font-normal"
              placeholder="Ex.: tem cachorro, interfone 22, aula de matemática do 8º ano"
            />
          </label>
        </div>

        <label className="flex items-start gap-3 text-sm">
          <input
            type="checkbox"
            className="mt-1"
            checked={agreed}
            onChange={(event) => setAgreed(event.target.checked)}
          />
          <span>
            Li o que está incluso e o que fica de fora. O valor de {brl(total)} é o combinado. Cancelamento sem custo
            até 12 horas antes.
          </span>
        </label>

        {error ? (
          <p role="alert" className="text-sm font-semibold text-accent">
            {error}
          </p>
        ) : null}

        <Button type="submit" className="w-full sm:w-auto">
          Reservar por {brl(total)}
        </Button>
      </form>

      <aside className="h-fit rounded-lg border border-line bg-surface p-5 lg:sticky lg:top-24">
        <p className="text-xs font-semibold tracking-wide text-muted uppercase">Resumo</p>
        <h2 className="mt-2 font-display text-3xl">{service.name}</h2>
        <p className="mt-1 text-sm text-muted">{option.label}</p>
        {selectedExtras.length > 0 ? (
          <ul className="mt-3 space-y-1 text-sm">
            {selectedExtras.map((extra) => (
              <li key={extra.id}>{extra.label}</li>
            ))}
          </ul>
        ) : null}
        <p className="mt-4 font-display text-4xl tabular-nums text-accent">{brl(total)}</p>
        <p className="mt-3 text-sm text-muted">
          {date && time ? `${formatDayShort(date)} · ${time}` : "Escolha dia e hora"}
          {weekly ? " · toda semana" : ""}
        </p>
        <p className="mt-4 text-sm">
          O PIX sai direto para {profile.receiverName || "o profissional"}. Este site não recebe o valor.
        </p>
      </aside>
    </main>
  );
}
