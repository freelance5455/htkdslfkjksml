import { createFileRoute } from "@tanstack/react-router";
import { ChevronRight, Download, FolderOpen, Smartphone } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { AppShell, ScreenBody } from "@/components/vishal/app-shell";
import { ScreenHeader } from "@/components/vishal/screen-header";

export const Route = createFileRoute("/studio")({ component: StudioPage });

type SourceFile = { path: string; content: string };

const tree = `VishalTools/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradlew / gradlew.bat
├── gradle/wrapper/
├── README.md
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/vishal/tools/
        │   ├── MainActivity.kt
        │   ├── VishalToolsApp.kt
        │   ├── tools/
        │   └── ui/theme, components, screens
        └── res/`;

function StudioPage() {
  const [files, setFiles] = useState<SourceFile[]>([]);
  const [openPath, setOpenPath] = useState<string | null>(null);

  useEffect(() => {
    void fetch("/android-source.json")
      .then((r) => r.json())
      .then((data: { files: SourceFile[] }) => {
        const list = [...data.files].sort((a, b) => a.path.localeCompare(b.path));
        setFiles(list);
        setOpenPath(list.find((f) => f.path.endsWith("MainActivity.kt"))?.path ?? list[0]?.path ?? null);
      })
      .catch(() => setFiles([]));
  }, []);

  const active = useMemo(() => files.find((f) => f.path === openPath) ?? null, [files, openPath]);

  return (
    <AppShell>
      <ScreenBody>
        <ScreenHeader
          title="Build the Android app"
          subtitle="Download the complete Kotlin project, open it in Android Studio, then install the APK on your phone."
        />

        <a
          href="/vishal-tools-android.zip"
          download="VishalTools-android.zip"
          className="flex min-h-14 items-center justify-center gap-2 rounded-2xl bg-primary px-5 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          <Download className="size-4" />
          Download VishalTools.zip
        </a>
        <p className="mt-2 text-center text-xs text-muted">Complete Android Studio project · Kotlin + Compose</p>

        <section className="mt-6 rounded-card bg-surface p-5 shadow-[var(--shadow-border)]">
          <div className="mb-3 flex items-center gap-2 text-primary">
            <FolderOpen className="size-4" />
            <h2 className="text-sm font-semibold uppercase tracking-wider">Open in Android Studio</h2>
          </div>
          <ol className="list-decimal space-y-3 pl-5 text-sm leading-relaxed text-fg">
            <li>Install Android Studio from developer.android.com/studio if you do not have it yet.</li>
            <li>
              Unzip <span className="text-primary">VishalTools-android.zip</span>. You should see a folder named
              VishalTools that contains settings.gradle.kts.
            </li>
            <li>In Android Studio choose File → Open… and select that VishalTools folder.</li>
            <li>Wait for Gradle Sync. If it asks for a JDK, pick the bundled JBR 17.</li>
            <li>If it offers to upgrade the Android Gradle Plugin, you can accept.</li>
            <li>Start an emulator (Device Manager) or plug in a phone with USB debugging.</li>
            <li>Press the green Run button.</li>
          </ol>
        </section>

        <section className="mt-3.5 rounded-card bg-surface p-5 shadow-[var(--shadow-border)]">
          <div className="mb-3 flex items-center gap-2 text-primary">
            <Smartphone className="size-4" />
            <h2 className="text-sm font-semibold uppercase tracking-wider">Build the APK</h2>
          </div>
          <p className="text-sm leading-relaxed text-fg">
            In Android Studio go to <span className="font-medium">Build → Build Bundle(s) / APK(s) → Build APK(s)</span>.
            When it finishes, click Locate.
          </p>
          <p className="mt-3 rounded-xl bg-elevated px-3.5 py-3 font-mono text-xs leading-relaxed text-primary">
            VishalTools/app/build/outputs/apk/debug/app-debug.apk
          </p>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            Copy that file to your phone and open it to install. Android may ask you to allow installing from Files.
            That debug APK is for you — not for the Play Store.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-fg">From the Android Studio Terminal tab you can also run:</p>
          <p className="mt-2 rounded-xl bg-elevated px-3.5 py-3 font-mono text-xs text-primary">./gradlew assembleDebug</p>
          <p className="mt-2 text-xs text-muted">Windows: gradlew.bat assembleDebug</p>
        </section>

        <section className="mt-3.5 rounded-card bg-surface p-5 shadow-[var(--shadow-border)]">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-primary">What each part does</h2>
          <ul className="mt-3 space-y-2 text-sm leading-relaxed text-muted">
            <li>
              <span className="font-medium text-fg">MainActivity.kt</span> — starts the app and loads Compose.
            </li>
            <li>
              <span className="font-medium text-fg">VishalToolsApp.kt</span> — dark shell and screen navigation.
            </li>
            <li>
              <span className="font-medium text-fg">tools/</span> — reads battery, storage, device, flashlight, network.
            </li>
            <li>
              <span className="font-medium text-fg">ui/screens/</span> — one Kotlin file per tool, easier to learn.
            </li>
            <li>
              <span className="font-medium text-fg">AndroidManifest.xml</span> — only camera + network-state permissions.
            </li>
          </ul>
        </section>

        <pre className="mt-3.5 overflow-x-auto rounded-card bg-elevated p-4 text-xs leading-relaxed text-muted">
          {tree}
        </pre>

        {files.length > 0 ? (
          <section className="mt-3.5 rounded-card bg-surface p-5 shadow-[var(--shadow-border)]">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-primary">Project files</h2>
            <p className="mt-2 text-sm text-muted">Tap a file to read the complete source.</p>
            <div className="mt-3 max-h-52 overflow-y-auto rounded-xl bg-elevated">
              {files.map((file) => {
                const selected = file.path === openPath;
                return (
                  <button
                    key={file.path}
                    type="button"
                    onClick={() => setOpenPath(file.path)}
                    className={`flex w-full items-center gap-2 px-3 py-2.5 text-left text-xs ${selected ? "bg-primary/15 text-primary" : "text-muted"}`}
                  >
                    <ChevronRight className={`size-3.5 shrink-0 ${selected ? "text-primary" : "text-muted"}`} />
                    <span className="truncate font-mono">{file.path}</span>
                  </button>
                );
              })}
            </div>
            {active ? (
              <pre className="mt-3 max-h-80 overflow-auto rounded-xl bg-bg p-3 font-mono text-[11px] leading-relaxed text-muted">
                {active.content}
              </pre>
            ) : null}
          </section>
        ) : null}
      </ScreenBody>
    </AppShell>
  );
}
