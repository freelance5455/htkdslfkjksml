import { createFileRoute } from "@tanstack/react-router";
import { StudioView } from "@/components/planner/views/studio";

export const Route = createFileRoute("/studio")({
  component: StudioView,
});
