import { createFileRoute } from "@tanstack/react-router";
import { WorkView } from "@/components/sahyog/work-view";

export const Route = createFileRoute("/work")({
  component: WorkView,
  head: () => ({ meta: [{ title: "Work · Sahyog" }] }),
});
