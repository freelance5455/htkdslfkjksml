import { createFileRoute } from "@tanstack/react-router";
import { GoalsView } from "@/components/planner/views/goals";

export const Route = createFileRoute("/goals")({
  component: GoalsView,
});
