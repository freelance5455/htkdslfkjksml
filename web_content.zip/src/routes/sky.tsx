import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { CONSTELLATIONS, PLACES, STARS } from "@/data/catalog";
import { SkyChart, visibleObjects } from "@/components/sky-chart";
import { btnGhost, btnGold, btnQuiet } from "@/components/ui";
import {
  compass,
  formatAlt,
  formatCivil,
  formatDec,
  formatLat,
  formatLon,
  formatRa,
  localHour,
  localMonth,
  monthName,
  skyInstant,
  twilight,
  toAltAz,
  lstHours,
} from "@/lib/astro";
import { bodiesAt } from "@/lib/astro";
import { useVespera } from "@/lib/store";
import { useNow } from "@/lib/use-now";

export const Route = createFileRoute("/sky")({
  validateSearch: (search: Record<string, unknown>): { con?: string } =>
    typeof search.con === "string" ? { con: search.con } : {},
  component: SkyPage,
});

function formatClock(hour: number): string {
  const h24 = ((Math.floor(hour) % 24) + 24) % 24;
  const m = Math.min(59, Math.round((hour - Math.floor(hour)) * 60));
  const ampm = h24 >= 12 ? "pm" : "am";
  const hr = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${hr}:${String(m).padStart(2, "0")} ${ampm}`;
}

function SkyPage() {
  const search = Route.useSearch();
  const now = useNow();
  const lat = useVespera((s) => s.lat);
  const lon = useVespera((s) => s.lon);
  const custom = useVespera((s) => s.custom);
  const placeId = useVespera((s) => s.placeId);
  const ready = useVespera((s) => s.ready);
  const setPlace = useVespera((s) => s.setPlace);
  const setLat = useVespera((s) => s.setLat);
  const setCustom = useVespera((s) => s.setCustom);
  const clearCustom = useVespera((s) => s.clearCustom);

  const [lines, setLines] = useState(true);
  const [guides, setGuides] = useState(true);
  const [names, setNames] = useState(true);
  const [ecliptic, setEcliptic] = useState(true);
  const [focus, setFocus] = useState<string | null>(search.con ?? null);
  const [selected, setSelected] = useState<string | null>(null);
  const [play, setPlay] = useState(false);

  useEffect(() => {
    setFocus(search.con ?? null);
  }, [search.con]);

  useEffect(() => {
    if (!play) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      const s = useVespera.getState();
      const hour = (s.custom?.hour ?? localHour(new Date(), s.lon)) + 1;
      const month = s.custom?.month ?? localMonth(new Date(), s.lon);
      s.setCustom(month, hour >= 24 ? hour - 24 : hour, true);
      setPlay(false);
      return;
    }
    let frame = 0;
    let last = performance.now();
    const loop = (t: number) => {
      const dt = Math.min(0.05, (t - last) / 1000);
      last = t;
      const s = useVespera.getState();
      const month = s.custom?.month ?? localMonth(new Date(), s.lon);
      let hour = (s.custom?.hour ?? localHour(new Date(), s.lon)) + dt * 1.15;
      if (hour >= 24) hour -= 24;
      s.setCustom(month, hour, false);
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, [play]);

  if (!now || !ready) {
    return <p className="text-muted">Setting the chart to your clock.</p>;
  }

  const when = skyInstant(lon, custom, now);
  const month = custom?.month ?? localMonth(when, lon);
  const hour = custom?.hour ?? localHour(when, lon);
  const { stars, bodies } = visibleObjects(when, lat, lon);
  const lst = lstHours(when, lon);
  const sun = bodiesAt(when)[0];
  const sunPos = toAltAz(sun.ra, sun.dec, lat, lst);
  const skyNote = twilight(sunPos.alt);

  const star = STARS.find((s) => s.id === selected);
  const body = bodiesAt(when).find((b) => b.id === selected);
  const pickedAlt = star
    ? toAltAz(star.ra, star.dec, lat, lst)
    : body
      ? toAltAz(body.ra, body.dec, lat, lst)
      : null;

  const figures = new Map<string, number>();
  for (const s of stars) {
    if (s.alt > 15) figures.set(s.con, Math.max(figures.get(s.con) ?? -90, s.alt));
  }
  const figureList = [...figures.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);

  function stopPlay(save: boolean) {
    if (!play) return;
    setPlay(false);
    if (save) {
      const s = useVespera.getState();
      if (s.custom) s.setCustom(s.custom.month, s.custom.hour, true);
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-widest text-gold">Horizon chart</p>
          <h1 className="mt-2 text-4xl text-fg md:text-5xl">The sky you can actually learn.</h1>
        </div>
        <p className="max-w-sm text-sm text-muted">
          Looking up. North is at the top, east is to the right — the view facing north. Bright stars only.
        </p>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div>
          <div className="rounded-2xl border border-line bg-bg-raised p-3 sm:p-4">
            <SkyChart
              when={when}
              lat={lat}
              lon={lon}
              lines={lines}
              guides={guides}
              names={names}
              ecliptic={ecliptic}
              focus={focus}
              selected={selected}
              onSelect={setSelected}
            />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Toggle on={lines} set={setLines} label="Figures" />
            <Toggle on={guides} set={setGuides} label="Pointers" />
            <Toggle on={names} set={setNames} label="Names" />
            <Toggle on={ecliptic} set={setEcliptic} label="Ecliptic" />
            {focus && (
              <button type="button" className={btnQuiet} onClick={() => setFocus(null)}>
                Clear {CONSTELLATIONS[focus]?.name ?? "focus"}
              </button>
            )}
          </div>
          {skyNote && <p className="mt-3 text-sm text-muted">{skyNote}</p>}
        </div>

        <div className="flex flex-col gap-5">
          <section className="rounded-2xl border border-line bg-surface p-4">
            <p className="font-display text-xl text-fg">{formatCivil(when, lon)}</p>
            <p className="mt-1 text-sm text-faint">
              {formatLat(lat)} · {formatLon(lon)}
              {placeId === "guess" ? " · longitude from your timezone" : ""}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                className={btnGhost}
                onClick={() => {
                  stopPlay(false);
                  const offset = -new Date().getTimezoneOffset() / 60;
                  setPlace("guess", 40, Math.max(-180, Math.min(180, offset * 15)));
                  clearCustom();
                }}
              >
                Right now
              </button>
              <button
                type="button"
                className={play ? btnGold : btnGhost}
                onClick={() => {
                  if (play) stopPlay(true);
                  else setPlay(true);
                }}
              >
                {play ? "Pause the night" : "Play the night"}
              </button>
            </div>
            <label className="mt-4 block text-sm text-muted">
              <span className="flex justify-between">
                Hour <span className="text-fg tabular-nums">{formatClock(hour)}</span>
              </span>
              <input
                className="mt-2 w-full"
                type="range"
                min={0}
                max={24}
                step={0.25}
                value={hour}
                onChange={(e) => {
                  stopPlay(false);
                  setCustom(month, Number(e.target.value));
                }}
              />
            </label>
            <label className="mt-3 block text-sm text-muted">
              <span className="flex justify-between">
                Month <span className="text-fg">{monthName(month)}</span>
              </span>
              <input
                className="mt-2 w-full"
                type="range"
                min={1}
                max={12}
                step={1}
                value={month}
                onChange={(e) => {
                  stopPlay(false);
                  setCustom(Number(e.target.value), hour);
                }}
              />
            </label>
            <label className="mt-3 block text-sm text-muted">
              <span className="flex justify-between">
                Latitude <span className="text-fg tabular-nums">{formatLat(lat)}</span>
              </span>
              <input
                className="mt-2 w-full"
                type="range"
                min={-60}
                max={70}
                step={0.5}
                value={lat}
                onChange={(e) => {
                  setLat(Number(e.target.value));
                }}
              />
            </label>
            <div className="mt-3 flex flex-wrap gap-2">
              {PLACES.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPlace(p.id, p.lat, p.lon)}
                  className={`h-9 rounded-full border px-3 text-sm ${placeId === p.id ? "border-gold text-gold" : "border-line text-muted"}`}
                >
                  {p.name}
                </button>
              ))}
            </div>
          </section>

          <section className="rounded-2xl border border-line bg-surface p-4">
            {star && pickedAlt ? (
              <Detail
                kicker={CONSTELLATIONS[star.con]?.name ?? "Star"}
                title={star.name}
                lines={[
                  `Magnitude ${star.mag.toFixed(2)} · ${star.ly < 100 ? star.ly.toFixed(1) : Math.round(star.ly)} light-years`,
                  `${formatAlt(pickedAlt.alt)} altitude · ${compass(pickedAlt.az)}`,
                  `RA ${formatRa(star.ra)} · Dec ${formatDec(star.dec)}`,
                ]}
                body={star.fact}
                action={
                  <button type="button" className={btnGhost} onClick={() => setFocus(star.con)}>
                    Trace {CONSTELLATIONS[star.con]?.name ?? "it"}
                  </button>
                }
              />
            ) : body && pickedAlt ? (
              <Detail
                kicker={body.kind === "planet" ? "Planet" : body.kind === "moon" ? "Moon" : "Sun"}
                title={body.name}
                lines={[
                  `${formatAlt(pickedAlt.alt)} altitude · ${compass(pickedAlt.az)}`,
                  `RA ${formatRa(body.ra)} · Dec ${formatDec(body.dec)}`,
                ]}
                body={body.note}
              />
            ) : (
              <>
                <p className="text-xs uppercase tracking-widest text-gold">Tap a point</p>
                <p className="mt-2 text-sm text-muted">
                  Stars are colored by temperature: blue is hot, gold is sun-like, amber and rose are cool giants. Planets wear a ring. The dashed gold curve is the ecliptic — planets stay near it.
                </p>
              </>
            )}
          </section>

          <section>
            <h2 className="text-sm uppercase tracking-widest text-faint">Up now</h2>
            <ul className="mt-2 divide-y divide-line border-y border-line">
              {bodies
                .filter((b) => b.kind !== "sun" || b.alt > 0)
                .slice(0, 4)
                .map((b) => (
                  <li key={b.id}>
                    <button type="button" className="flex w-full items-baseline justify-between gap-3 py-2.5 text-left" onClick={() => setSelected(b.id)}>
                      <span className="text-fg">{b.name}</span>
                      <span className="text-sm text-faint tabular-nums">
                        {b.alt.toFixed(0)}° {compass(b.az)}
                      </span>
                    </button>
                  </li>
                ))}
              {stars.slice(0, 6).map((s) => (
                <li key={s.id}>
                  <button type="button" className="flex w-full items-baseline justify-between gap-3 py-2.5 text-left" onClick={() => setSelected(s.id)}>
                    <span className="text-fg">{s.name}</span>
                    <span className="text-sm text-faint tabular-nums">
                      {s.alt.toFixed(0)}° {compass(s.az)}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
            {figureList.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {figureList.map(([id]) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setFocus(focus === id ? null : id)}
                    className={`h-9 rounded-full border px-3 text-sm ${focus === id ? "border-gold text-gold" : "border-line text-muted"}`}
                  >
                    {CONSTELLATIONS[id]?.name ?? id}
                  </button>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}

function Toggle({ on, set, label }: { on: boolean; set: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={() => set(!on)}
      className={`h-10 rounded-full border px-4 text-sm ${on ? "border-gold text-gold" : "border-line text-faint"}`}
    >
      {label}
    </button>
  );
}

function Detail({
  kicker,
  title,
  lines,
  body,
  action,
}: {
  kicker: string;
  title: string;
  lines: string[];
  body: string;
  action?: ReactNode;
}) {
  return (
    <>
      <p className="text-xs uppercase tracking-widest text-gold">{kicker}</p>
      <h2 className="mt-1 text-3xl text-fg">{title}</h2>
      <ul className="mt-3 space-y-1 text-sm text-muted tabular-nums">
        {lines.map((l) => (
          <li key={l}>{l}</li>
        ))}
      </ul>
      <p className="mt-3 text-sm text-fg">{body}</p>
      {action && <div className="mt-4">{action}</div>}
    </>
  );
}
