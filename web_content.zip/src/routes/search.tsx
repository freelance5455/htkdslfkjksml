import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { InternalLink } from "@/components/internal-link";
import { PageIntro } from "@/components/page";
import { searchAll } from "@/data/search";
import { arNum } from "@/lib/utils";

export const Route = createFileRoute("/search")({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search.q === "string" ? search.q : "",
  }),
  head: () => ({ meta: [{ title: "البحث — لأنه الله" }] }),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();
  const [value, setValue] = useState(q);
  const results = searchAll(q);
  const groups = Array.from(new Set(results.map((hit) => hit.type)));

  return (
    <main>
      <PageIntro kicker="بحث داخلي" title="ابحث في المنصة" lede="يشمل الأسماء والآيات والأحاديث والكتب والمشاهد والسلوك وأخبار الحملة. لا يغادر نصوص الموقع." />
      <section className="mx-auto max-w-3xl px-4 py-8">
        <div className="flex gap-2">
          <input value={value} onChange={(event) => setValue(event.target.value)} aria-label="عبارة البحث" className="min-w-0 flex-1 rounded-full border border-line bg-surface px-4 py-3" />
          <Link to="/search" search={{ q: value }} className="rounded-full bg-primary px-5 py-3 text-primary-fg">بحث</Link>
        </div>
        {q.trim().length < 2 ? <p className="mt-6 text-muted">اكتب حرفين على الأقل.</p> : null}
        {q.trim().length >= 2 && results.length === 0 ? (
          <p className="mt-6 rounded-card border border-line p-5">لا نتائج لـ«{q}». جرّب اسمًا أو كلمة من آية أو موضوعًا مثل الرحمة.</p>
        ) : null}
        {groups.map((group) => (
          <section key={group} className="mt-8">
            <h2 className="font-display text-3xl text-primary">{group}</h2>
            <ul className="mt-3 space-y-3">
              {results.filter((hit) => hit.type === group).map((hit) => (
                <li key={`${hit.href}-${hit.title}`}>
                  <InternalLink href={hit.href} className="block rounded-card border border-line bg-surface p-4">
                    <span className="font-medium">{hit.title}</span>
                    <span className="mt-1 block text-sm leading-7 text-muted">{hit.excerpt}</span>
                  </InternalLink>
                </li>
              ))}
            </ul>
          </section>
        ))}
        {results.length > 0 ? <p className="mt-6 text-sm text-muted">{arNum(results.length)} نتيجة</p> : null}
        <p className="mt-8 text-sm leading-7">
          للسؤال بجملة كاملة استخدم <Link to="/guide" className="text-primary">دليل المحتوى</Link>. هو استرجاع للنصوص لا فتوى.
        </p>
      </section>
    </main>
  );
}
