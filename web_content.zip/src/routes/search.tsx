import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { searchUsers } from "@/lib/cutegirls/api";
import type { Person } from "@/lib/cutegirls/model";
import { Avatar, RolePill, fieldClass } from "@/components/bits";
import { Shell } from "@/components/shell";

export const Route = createFileRoute("/search")({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search.q === "string" ? search.q.slice(0, 40) : "",
  }),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();
  return (
    <Shell>
      <SearchBody initial={q} />
    </Shell>
  );
}

function SearchBody({ initial }: { initial: string }) {
  const [q, setQ] = useState(initial);
  const [people, setPeople] = useState<Person[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handle = window.setTimeout(() => {
      searchUsers({ data: { q } })
        .then((result) => {
          setPeople(result.people);
          setError(null);
        })
        .catch((err: unknown) => setError(err instanceof Error ? err.message : "تعذر البحث"));
    }, 180);
    return () => window.clearTimeout(handle);
  }, [q]);

  return (
    <div className="mx-auto w-full max-w-xl space-y-4">
      <header>
        <p className="text-xs tracking-widest text-rose">دليل</p>
        <h1 className="font-display text-4xl">بحث</h1>
      </header>
      <input
        className={`${fieldClass} h-12`}
        placeholder="اسم الحساب"
        value={q}
        dir="ltr"
        onChange={(e) => setQ(e.target.value)}
        autoFocus
      />
      {error ? <p className="text-sm text-rose">{error}</p> : null}
      <ul className="space-y-2">
        {(people ?? []).map((person) => (
          <li key={person.username}>
            <Link
              to="/u/$username"
              params={{ username: person.username }}
              className="flex min-h-16 items-center gap-3 rounded-3xl bg-paper px-3 shadow-card"
            >
              <Avatar src={person.avatar} name={person.username} />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="truncate font-medium">{person.username}</span>
                  <RolePill role={person.role} />
                </span>
                {person.bio ? <span className="block truncate text-sm text-mute">{person.bio}</span> : null}
              </span>
            </Link>
          </li>
        ))}
      </ul>
      {people && !people.length ? <p className="text-sm text-mute">لا حسابات بهذا الاسم.</p> : null}
    </div>
  );
}
