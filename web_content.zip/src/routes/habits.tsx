import { createFileRoute } from "@tanstack/react-router";
import { HabitsView } from "@/components/planner/views/habits";

export const Route = createFileRoute("/habits")({
  component: HabitsView,
});
