import { useEffect } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PlayerScreen } from "@/components/player/player-screen";
import { Button } from "@/components/ui/button";
import { useLibrary } from "@/lib/library-store";
import { usePlayer } from "@/lib/player-store";

export const Route = createFileRoute("/player/$id")({
  component: PlayerRoute,
});

function PlayerRoute() {
  const { id } = Route.useParams();
  const ready = useLibrary((s) => s.ready);
  const item = useLibrary((s) => s.items.find((i) => i.id === id));
  const currentId = usePlayer((s) => s.currentId);
  const open = usePlayer((s) => s.open);
  const items = useLibrary((s) => s.items);

  useEffect(() => {
    if (item && currentId !== item.id) {
      open(
        item,
        items.filter((i) => i.kind === item.kind),
      );
    }
  }, [item, currentId, open, items]);

  if (!ready) {
    return (
      <div className="flex h-dvh items-center justify-center bg-black text-white">
        Loading player…
      </div>
    );
  }

  if (!item) {
    return (
      <div className="flex h-dvh flex-col items-center justify-center gap-3 bg-black p-6 text-center text-white">
        <h1 className="font-display text-2xl font-semibold">Media not in library</h1>
        <p className="max-w-sm text-sm text-white/70">
          This item was removed or never saved on this device.
        </p>
        <Button asChild>
          <Link to="/">Back home</Link>
        </Button>
      </div>
    );
  }

  return <PlayerScreen item={item} />;
}
