import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ActionBar, ReviewBanner, Tag } from "@/components/page";
import { getVerse } from "@/data/verses";
import { useProgress } from "@/lib/progress";
import { arNum } from "@/lib/utils";

export const Route = createFileRoute("/quran/$id")({
  loader: ({ params }) => {
    const verse = getVerse(params.id);
    if (!verse) throw notFound();
    return verse;
  },
  head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `${loaderData.surah} — التدبر` : "آية" }] }),
  component: VersePage,
});

function VersePage() {
  const verse = Route.useLoaderData();
  const fav = useProgress((state) => state.fav.includes(`verse:${verse.id}`));
  const toggleFav = useProgress((state) => state.toggleFav);
  const copy = `${verse.text}\n${verse.surah}، الآية ${verse.ayah}\n${verse.url}`;

  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <Link to="/quran" className="text-sm text-olive">كل الآيات</Link>
      <p className="mt-4 text-sm text-olive">{verse.surah} · الآية {arNum(verse.ayah)}</p>
      <h1 className="ayah mt-3 text-primary">{verse.text}</h1>
      <div className="mt-4 flex flex-wrap gap-2">{verse.topics.map((topic) => <Tag key={topic}>{topic}</Tag>)}</div>
      <div className="mt-5"><ActionBar title={`${verse.surah} ${verse.ayah}`} text={copy} urlPath={`/quran/${verse.id}`} /></div>
      <button type="button" onClick={() => toggleFav(`verse:${verse.id}`)} className="mt-3 rounded-full border border-line px-4 py-2 text-sm" aria-pressed={fav}>
        {fav ? "في المفضلة" : "أضف إلى المفضلة"}
      </button>
      <section className="mt-8">
        <h2 className="font-display text-3xl text-primary">خلاصة التفسير</h2>
        <ReviewBanner>خلاصة معنى مستفادة من التفاسير المعتمدة كابن كثير والسعدي، بصياغة مختصرة. ليست نقلًا حرفيًا تامًا.</ReviewBanner>
        <p className="mt-3 leading-8">{verse.tafsir}</p>
      </section>
      <section className="mt-8">
        <h2 className="font-display text-3xl text-primary">تدبر تربوي</h2>
        <p className="mt-2 text-sm text-olive">صياغة هذه المنصة، وليست منسوبة إلى مفسر.</p>
        <p className="mt-3 leading-8">{verse.tadabbur}</p>
      </section>
      <section className="mt-8 rounded-card border border-line bg-soft p-5">
        <h2 className="font-display text-3xl text-primary">تطبيق</h2>
        <p className="mt-3 leading-8">{verse.practice}</p>
      </section>
      <a href={verse.url} className="mt-6 inline-block text-primary" rel="noreferrer">فتح الآية في Quran.com</a>
    </main>
  );
}
