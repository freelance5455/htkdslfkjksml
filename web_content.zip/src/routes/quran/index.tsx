import { createFileRoute, Link } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { BackButton } from "@/components/back-button";
import { AppShell, TopBar } from "@/components/layout/app-shell";
import { quranMeta } from "@/content/catalog";
import { normalizeArabic, toArabicDigits } from "@/lib/utils";

export const Route = createFileRoute("/quran/")({ component: QuranIndex });

function QuranIndex() {
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const n = normalizeArabic(q);
    if (!n) return quranMeta.surahs;
    return quranMeta.surahs.filter(
      (s) =>
        normalizeArabic(s.name).includes(n) ||
        normalizeArabic(s.shortName).includes(n) ||
        s.englishName.toLowerCase().includes(q.toLowerCase()) ||
        String(s.id) === q,
    );
  }, [q]);

  return (
    <AppShell>
      <TopBar title="القرآن الكريم" back={<BackButton href="/" />} />
      <div className="px-4 pt-3">
        <label className="flex items-center gap-2 rounded-2xl bg-card px-3 py-2 shadow-[var(--shadow-border)]">
          <Search className="size-4 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث عن سورة"
            className="h-10 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </label>
      </div>
      <ul className="mt-2 divide-y divide-border px-2 pb-6">
        {list.map((s) => (
          <li key={s.id}>
            <Link
              to="/quran/$surahId"
              params={{ surahId: String(s.id) }}
              className="flex items-center gap-3 px-3 py-3"
            >
              <span className="flex size-10 items-center justify-center rounded-lg border border-border font-quran text-sm text-accent">
                {toArabicDigits(s.id)}
              </span>
              <span className="flex-1">
                <span className="block font-quran text-lg leading-none">{s.name}</span>
                <span className="mt-1 block text-[11px] text-muted-foreground">
                  {s.type} · {toArabicDigits(s.count)} آية · ص {toArabicDigits(s.page)}
                </span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </AppShell>
  );
}
