import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Card, Page, fieldClass } from "@/components/ui";
import { dayKey } from "@/lib/arabic";
import { usePrefs } from "@/lib/prefs";
import { downloadAllTafsir, juzStart, loadQuran, type Quran } from "@/lib/quran";

export const Route = createFileRoute("/quran/")({ component: QuranHome });

function QuranHome() {
  const [q, setQ] = useState<Quran | null>(null);
  const [err, setErr] = useState("");
  const [tab, setTab] = useState<"surah" | "juz" | "plan">("surah");
  const [query, setQuery] = useState("");
  const [pageNo, setPageNo] = useState("1");
  const [tafsirProg, setTafsirProg] = useState("");
  const prefs = usePrefs();
  const khatma = prefs.khatma;

  useEffect(() => {
    void loadQuran().then(setQ).catch(() => setErr("تعذر تحميل المصحف. أعد المحاولة وأنت متصل مرة واحدة ليُحفظ في الجهاز."));
  }, []);

  const surahs = useMemo(() => {
    if (!q) return [];
    const n = query.trim();
    if (!n) return q.surahs;
    return q.surahs.filter((s) => s.ar.includes(n) || String(s.n) === n);
  }, [q, query]);

  const todayPage = useMemo(() => {
    if (!khatma) return null;
    const start = new Date(`${khatma.startDate}T00:00:00`);
    const days = Math.max(0, Math.floor((Date.now() - start.getTime()) / 86_400_000));
    return Math.min(604, khatma.startPage + days * khatma.dailyPages);
  }, [khatma]);

  return (
    <Page
      title="المصحف"
      subtitle="الرسم العثماني، 114 سورة، 6236 آية. النص من طبعة مجمع الملك فهد عبر بيانات Tanzil، ويُحفظ في جهازك بعد أول تحميل."
    >
      {err && <p className="mb-3 text-sm text-danger">{err}</p>}
      <div className="mb-3 flex gap-2">
        {(["surah", "juz", "plan"] as const).map((id) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`min-h-11 rounded-full px-4 text-sm font-semibold ${tab === id ? "bg-btn text-btn-fg" : "bg-card text-ink border border-line"}`}
          >
            {id === "surah" ? "السور" : id === "juz" ? "الأجزاء" : "الختمة"}
          </button>
        ))}
      </div>

      {tab === "surah" && (
        <>
          <input className={fieldClass} placeholder="ابحث باسم السورة" value={query} onChange={(e) => setQuery(e.target.value)} />
          <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-card">
            {surahs.map((s) => (
              <li key={s.n}>
                <Link to="/quran/$surah" params={{ surah: String(s.n) }} search={{ ayah: undefined }} className="flex min-h-14 items-center gap-3 px-3">
                  <span className="grid size-9 place-items-center rounded-full bg-gold-soft text-sm font-bold text-emerald-deep">{s.n}</span>
                  <span className="flex-1">
                    <span className="block font-bold">{s.ar}</span>
                    <span className="text-xs text-muted">{s.type} · {s.ayahs.length} آية</span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </>
      )}

      {tab === "juz" && q && (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {Array.from({ length: 30 }, (_, i) => i + 1).map((j) => {
            const start = juzStart(q, j);
            return (
              <Link
                key={j}
                to="/quran/$surah"
                params={{ surah: String(start?.surah || 1) }}
                search={{ ayah: start?.ayah }}
                className="min-h-16 rounded-2xl border border-line bg-card p-3"
              >
                <span className="block text-sm text-gold">الجزء {j}</span>
                <span className="text-sm font-semibold">{q.surahs[(start?.surah || 1) - 1].ar} : {start?.ayah}</span>
              </Link>
            );
          })}
        </div>
      )}

      {tab === "plan" && (
        <div className="space-y-3">
          <Card>
            <p className="font-bold">ورد الختمة</p>
            <p className="mt-1 text-sm text-muted">التقدم يُحسب بالصفحات التي تضغط «أتممت الصفحة» داخل المصحف. ليس في ذلك لوم، بل متابعة هادئة.</p>
            <p className="mt-2 text-sm">صفحات خُتمت: {prefs.readPages.length} / 604 ({Math.round((prefs.readPages.length / 604) * 100)}%)</p>
            {todayPage && <p className="text-sm">ورد اليوم المقترح يصل إلى الصفحة {todayPage}.</p>}
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <label className="text-sm">
                صفحات يوميًا
                <input
                  className={fieldClass}
                  type="number"
                  min={1}
                  max={40}
                  defaultValue={khatma?.dailyPages || 4}
                  id="daily-pages"
                />
              </label>
              <label className="text-sm">
                ساعة التذكير (والتطبيق مفتوح)
                <input
                  className={fieldClass}
                  type="number"
                  min={0}
                  max={23}
                  defaultValue={prefs.wardHour}
                  id="ward-hour"
                />
              </label>
            </div>
            <button
              type="button"
              className="mt-3 min-h-11 rounded-xl bg-btn px-4 text-sm font-semibold text-btn-fg"
              onClick={() => {
                const pages = Number((document.getElementById("daily-pages") as HTMLInputElement).value) || 4;
                const hour = Number((document.getElementById("ward-hour") as HTMLInputElement).value) || 8;
                prefs.patch({
                  wardHour: hour,
                  khatma: {
                    dailyPages: Math.min(40, Math.max(1, pages)),
                    startDate: dayKey(),
                    startPage: prefs.lastRead?.page || 1,
                  },
                });
              }}
            >
              حفظ الخطة
            </button>
          </Card>
          <Card>
            <p className="font-bold">انتقل إلى صفحة</p>
            <div className="mt-2 flex gap-2">
              <input className={fieldClass} inputMode="numeric" value={pageNo} onChange={(e) => setPageNo(e.target.value)} />
              <Link
                to="/mushaf/$page"
                params={{ page: String(Math.min(604, Math.max(1, Number(pageNo) || 1))) }}
                className="inline-flex min-h-11 items-center rounded-xl bg-gold px-4 text-sm font-semibold text-on-gold"
              >
                افتح
              </Link>
            </div>
          </Card>
          <Card>
            <p className="font-bold">تنزيل التفسير الميسر</p>
            <p className="mt-1 text-sm text-muted">يُجلب تفسير كل سورة ويُحفظ في الجهاز. بعد اكتماله تعمل التفاسير دون اتصال.</p>
            <button
              type="button"
              className="mt-3 min-h-11 rounded-xl border border-line px-4 text-sm font-semibold"
              onClick={() => {
                void downloadAllTafsir(
                  (done, total) => setTafsirProg(`${done} / ${total}`),
                  () => false,
                ).then(() => setTafsirProg("اكتمل حفظ التفسير"));
              }}
            >
              تنزيل التفسير كاملًا
            </button>
            {tafsirProg && <p className="mt-2 text-sm">{tafsirProg}</p>}
          </Card>
          {prefs.bookmarks.length > 0 && (
            <Card>
              <p className="font-bold">العلامات</p>
              <ul className="mt-2 space-y-1">
                {prefs.bookmarks.slice(0, 20).map((b) => (
                  <li key={`${b.surah}-${b.ayah}`}>
                    <Link to="/quran/$surah" params={{ surah: String(b.surah) }} search={{ ayah: b.ayah }} className="text-sm text-emerald">
                      سورة {b.surah} · آية {b.ayah}
                    </Link>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>
      )}
    </Page>
  );
}
