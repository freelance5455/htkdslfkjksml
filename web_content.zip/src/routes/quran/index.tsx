import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageIntro, Tag } from "@/components/page";
import { VERSE_TOPICS, VERSES } from "@/data/verses";
import { arNum, stripArabic } from "@/lib/utils";

export const Route = createFileRoute("/quran/")({
  head: () => ({ meta: [{ title: "القرآن والتدبر — لأنه الله" }] }),
  component: QuranPage,
});

function QuranPage() {
  const [query, setQuery] = useState("");
  const [topic, setTopic] = useState("الكل");
  const q = stripArabic(query);
  const list = useMemo(
    () =>
      VERSES.filter((verse) => {
        const blob = stripArabic(`${verse.surah} ${verse.text} ${verse.tafsir} ${verse.topics.join(" ")}`);
        return (!q || blob.includes(q)) && (topic === "الكل" || verse.topics.includes(topic));
      }),
    [q, topic],
  );

  return (
    <main>
      <PageIntro
        kicker="نصوص مضبوطة"
        title="القرآن الكريم والتدبر"
        lede="آيات مختارة في التعظيم والرحمة والتفكر والأخلاق. النص مفصول عن خلاصة التفسير، وخلاصة التفسير مفصولة عن التدبر التربوي الذي صاغته المنصة."
      />
      <section className="mx-auto max-w-6xl px-4 py-8">
        <div className="grid gap-3 md:grid-cols-[1fr_auto]">
          <input value={query} onChange={(event) => setQuery(event.target.value)} aria-label="بحث في الآيات" placeholder="ابحث بالسورة أو بكلمة" className="rounded-full border border-line bg-surface px-4 py-3" />
          <select value={topic} onChange={(event) => setTopic(event.target.value)} aria-label="موضوع الآية" className="rounded-full border border-line bg-surface px-4 py-3">
            <option>الكل</option>
            {VERSE_TOPICS.map((item) => <option key={item}>{item}</option>)}
          </select>
        </div>
        {list.length === 0 ? <p className="mt-6">لا توجد آيات مطابقة في هذه المجموعة.</p> : null}
        <div className="mt-6 grid gap-4">
          {list.map((verse) => (
            <Link key={verse.id} to="/quran/$id" params={{ id: verse.id }} className="rounded-card border border-line bg-surface p-5">
              <p className="text-sm text-olive">{verse.surah} · {arNum(verse.ayah)}</p>
              <p className="ayah mt-3 text-primary">{verse.text}</p>
              <div className="mt-3 flex flex-wrap gap-2">{verse.topics.map((item) => <Tag key={item}>{item}</Tag>)}</div>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
