import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Bookmark, Copy, Heart, Pause, Play, Share2 } from "lucide-react";
import { Btn } from "@/components/ui";
import { cancelAudioDownload, downloadSurah } from "@/lib/audio";
import { usePlayer, type Clip } from "@/lib/player";
import { usePrefs } from "@/lib/prefs";
import { loadQuran, loadTafsir, pageOf, type Surah } from "@/lib/quran";

export const Route = createFileRoute("/quran/$surah")({
  validateSearch: (search: Record<string, unknown>) => ({
    ayah: Number(search.ayah) || undefined,
  }),
  component: Reader,
});

function Reader() {
  const { surah: surahParam } = Route.useParams();
  const { ayah: ayahQuery } = Route.useSearch();
  const n = Number(surahParam);
  const [surah, setSurah] = useState<Surah | null>(null);
  const [tafsir, setTafsir] = useState<string[] | null>(null);
  const [open, setOpen] = useState<number | null>(ayahQuery ?? null);
  const [msg, setMsg] = useState("");
  const [dl, setDl] = useState("");
  const prefs = usePrefs();
  const player = usePlayer();
  const scale = prefs.fontScale;

  useEffect(() => {
    let alive = true;
    setSurah(null);
    setTafsir(null);
    void loadQuran().then((q) => {
      if (!alive) return;
      const s = q.surahs[n - 1];
      if (!s) return;
      setSurah(s);
      const ayah = ayahQuery && s.ayahs.some((a) => a.a === ayahQuery) ? ayahQuery : s.ayahs[0].a;
      setOpen(ayah);
      prefs.patch({
        lastRead: { surah: s.n, ayah, page: pageOf(q, s.n, ayah) },
      });
      void loadTafsir(s.n).then((t) => alive && setTafsir(t));
    });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [n]);

  useEffect(() => {
    if (!open) return;
    document.getElementById(`ayah-${open}`)?.scrollIntoView({ block: "center" });
  }, [open, surah]);

  if (!surah) {
    return <p className="px-4 py-10 text-center text-sm text-muted">يُفتح المصحف…</p>;
  }

  const clips: Clip[] = surah.ayahs.map((a) => ({
    surah: surah.n,
    ayah: a.a,
    title: `سورة ${surah.ar} · ${a.a}`,
  }));

  async function share(text: string) {
    if (navigator.share) {
      try {
        await navigator.share({ text });
        return;
      } catch {
        /* cancelled */
      }
    }
    await navigator.clipboard.writeText(text);
    setMsg("نُسخ النص");
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pt-4" style={{ ["--quran-scale" as string]: String(scale) }}>
      <button type="button" onClick={() => history.back()} className="min-h-11 text-sm font-semibold text-emerald">
        رجوع
      </button>
      <header className="mb-3 flex items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-emerald-deep">سورة {surah.ar}</h1>
          <p className="text-sm text-muted">
            {surah.type} · {surah.ayahs.length} آية
            {surah.n !== 9 ? " · بسم الله الرحمن الرحيم" : " · بلا بسملة في أولها"}
          </p>
        </div>
        <div className="flex gap-1">
          <Btn tone="ghost" className="px-3" onClick={() => prefs.setFontScale(scale - 0.1)} aria-label="تصغير">
            أ-
          </Btn>
          <Btn tone="ghost" className="px-3" onClick={() => prefs.setFontScale(scale + 0.1)} aria-label="تكبير">
            أ+
          </Btn>
        </div>
      </header>
      <div className="mb-3 flex flex-wrap gap-2">
        <Btn
          onClick={() => {
            setDl("جاري التنزيل…");
            void downloadSurah(prefs.reciterId, surah, (done, total) => setDl(`${done}/${total}`))
              .then((r) => {
                if (r === "done") {
                  prefs.markCached(prefs.reciterId, surah.n);
                  setDl("حُفظت السورة لهذا القارئ على الجهاز");
                } else setDl("أُلغي التنزيل");
              })
              .catch(() => setDl("تعذر التنزيل. تحقق من الاتصال."));
          }}
        >
          تنزيل تلاوة السورة
        </Btn>
        <Btn tone="ghost" onClick={() => cancelAudioDownload()}>
          إلغاء
        </Btn>
        <Link to="/reciters" className="inline-flex min-h-11 items-center text-sm font-semibold text-emerald">
          القارئ
        </Link>
      </div>
      {(dl || msg) && <p className="mb-2 text-sm text-muted">{dl || msg}</p>}
      <p className="mb-3 text-xs text-muted">
        التفسير الميسر تحت الآية عند فتحها. أسباب النزول ومعجم المفردات غير مضمّنين حتى لا يُذكر غير الثابت.
      </p>
      <ol className="space-y-2 pb-6">
        {surah.ayahs.map((a, index) => {
          const marked = prefs.bookmarks.some((b) => b.surah === surah.n && b.ayah === a.a);
          const favId = `ayah-${surah.n}-${a.a}`;
          const text = `${a.t} ﴿${surah.ar}: ${a.a}﴾`;
          const active = player.playlist[player.index]?.surah === surah.n && player.playlist[player.index]?.ayah === a.a && player.playing;
          return (
            <li key={a.a} id={`ayah-${a.a}`} className="rounded-2xl border border-line bg-card p-3">
              <p className="quran-text">
                {a.t} <span className="text-gold">﴿{a.a}﴾</span>
              </p>
              <p className="mt-1 text-xs text-muted">
                الجزء {a.j} · الحزب {Math.ceil(a.h / 4)} · صفحة {a.p}
                {a.sd ? " · سجدة" : ""}
              </p>
              <div className="mt-2 flex flex-wrap gap-1">
                <button type="button" className="grid size-11 place-items-center rounded-xl bg-emerald-soft" aria-label="تلاوة" onClick={() => player.playList(clips, index)}>
                  {active ? <Pause className="size-4" /> : <Play className="size-4" />}
                </button>
                <button type="button" className="grid size-11 place-items-center" aria-label="تفسير" onClick={() => setOpen(open === a.a ? null : a.a)}>
                  <span className="text-xs font-bold">تفسير</span>
                </button>
                <button type="button" className="grid size-11 place-items-center" aria-label="علامة" onClick={() => prefs.toggleBookmark(surah.n, a.a)}>
                  <Bookmark className={`size-4 ${marked ? "fill-gold text-gold" : ""}`} />
                </button>
                <button
                  type="button"
                  className="grid size-11 place-items-center"
                  aria-label="مفضلة"
                  onClick={() =>
                    prefs.toggleFav({ id: favId, kind: "ayah", title: `${surah.ar} ${a.a}`, text: a.t, href: `/quran/${surah.n}?ayah=${a.a}` })
                  }
                >
                  <Heart className={`size-4 ${prefs.favorites.some((f) => f.id === favId) ? "fill-danger text-danger" : ""}`} />
                </button>
                <button type="button" className="grid size-11 place-items-center" aria-label="نسخ" onClick={() => void navigator.clipboard.writeText(text).then(() => setMsg("نُسخت الآية"))}>
                  <Copy className="size-4" />
                </button>
                <button type="button" className="grid size-11 place-items-center" aria-label="مشاركة" onClick={() => void share(text)}>
                  <Share2 className="size-4" />
                </button>
                <Link to="/mushaf/$page" params={{ page: String(a.p) }} className="inline-flex min-h-11 items-center px-2 text-xs font-semibold text-emerald">
                  الصفحة
                </Link>
              </div>
              {open === a.a && (
                <div className="mt-2 rounded-xl bg-ivory-2 p-3 text-sm leading-relaxed">
                  <p className="mb-1 font-bold text-emerald">التفسير الميسر</p>
                  {tafsir ? tafsir[a.a - 1] : "يُحمّل التفسير… إن فشل، نزّله من فهرس المصحف وأنت متصل."}
                </div>
              )}
            </li>
          );
        })}
      </ol>
    </div>
  );
}
