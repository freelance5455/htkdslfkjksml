import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Download,
  Heart,
  Minus,
  Pause,
  Play,
  Plus,
  Repeat,
  Share2,
  Type,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { BackButton } from "@/components/back-button";
import { AppShell } from "@/components/layout/app-shell";
import { loadSurah, loadTafsir, quranMeta, type TafsirAyah } from "@/content/catalog";
import type { Ayah, Surah } from "@/content/types";
import { audioEngine, downloadSurahAyahs, getReciter } from "@/lib/audio";
import { shareText } from "@/lib/share";
import { useAppStore } from "@/lib/store";
import { cn, toArabicDigits } from "@/lib/utils";

type Search = { ayah?: number };

export const Route = createFileRoute("/quran/$surahId")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ayah: Number(s.ayah) || undefined,
  }),
  component: Reader,
});

function Reader() {
  const { surahId: raw } = Route.useParams();
  const { ayah: startAyah } = Route.useSearch();
  const surahId = Number(raw);
  const meta = quranMeta.surahs.find((s) => s.id === surahId);
  const [surah, setSurah] = useState<Surah | null>(null);
  const [active, setActive] = useState<Ayah | null>(null);
  const [tafsir, setTafsir] = useState<TafsirAyah[] | null>(null);
  const [showTafsir, setShowTafsir] = useState(false);
  const [repeat, setRepeat] = useState(1);
  const [busy, setBusy] = useState(false);
  const scale = useAppStore((s) => s.settings.quranScale);
  const setScale = useAppStore((s) => s.setQuranScale);
  const reciterId = useAppStore((s) => s.settings.reciterId);
  const setLast = useAppStore((s) => s.setLastReading);
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);
  const favorites = useAppStore((s) => s.favorites);
  const addBookmark = useAppStore((s) => s.addBookmark);
  const markDownloaded = useAppStore((s) => s.markDownloaded);
  const downloaded = useAppStore((s) => s.downloadedSurahs);
  const [playingAyah, setPlayingAyah] = useState<number | null>(null);

  useEffect(() => {
    let live = true;
    setSurah(null);
    setActive(null);
    setTafsir(null);
    setShowTafsir(false);
    void loadSurah(surahId).then((s) => {
      if (!live || !s) return;
      setSurah(s);
      const a = s.ayahs.find((x) => x.n === startAyah) ?? s.ayahs[0];
      setLast({ surahId: s.id, ayah: a.n, updatedAt: Date.now() });
    });
    return () => {
      live = false;
    };
  }, [surahId, startAyah, setLast]);

  useEffect(() => {
    if (!surah || !startAyah) return;
    const t = window.setTimeout(() => {
      document.getElementById(`ayah-${startAyah}`)?.scrollIntoView({ block: "center" });
    }, 80);
    return () => window.clearTimeout(t);
  }, [surah, startAyah]);

  useEffect(() => audioEngine.subscribe((st) => setPlayingAyah(st.ayah)), []);

  const tafsirFor = useMemo(() => {
    if (!active || !tafsir) return "";
    return tafsir.find((t) => t.n === active.n)?.t ?? "";
  }, [active, tafsir]);

  if (!meta) {
    return (
      <AppShell>
        <p className="p-8 text-center">السورة غير موجودة</p>
      </AppShell>
    );
  }

  async function openTafsir(a: Ayah) {
    setActive(a);
    setShowTafsir(true);
    if (tafsir) return;
    try {
      setTafsir(await loadTafsir(surahId));
    } catch {
      toast("تعذر تحميل التفسير. يلزم الاتصال أول مرة ثم يُحفظ.");
    }
  }

  async function play(a: Ayah, cont = false) {
    if (!surah) return;
    setLast({ surahId: surah.id, ayah: a.n, updatedAt: Date.now() });
    await audioEngine.playAyah({
      surahId: surah.id,
      ayah: a.n,
      global: a.g,
      title: surah.name,
      reciterId,
      repeat,
      continueSurah: cont ? surah : null,
    });
  }

  async function download() {
    if (!surah) return;
    setBusy(true);
    try {
      const n = await downloadSurahAyahs(getReciter(reciterId), surah);
      markDownloaded(surah.id);
      toast(n ? `تم حفظ ${toArabicDigits(n)} مقطعًا للتلاوة دون اتصال` : "تعذر التنزيل الآن");
    } finally {
      setBusy(false);
    }
  }

  const favId = active ? `ayah:${surahId}:${active.n}` : "";
  const isFav = favorites.some((f) => f.id === favId);

  return (
    <AppShell>
      <header className="sticky top-0 z-20 border-b border-border bg-paper/95 backdrop-blur-md">
        <div className="flex items-center gap-1 px-1 py-1">
          <BackButton href="/quran" />
          <div className="min-w-0 flex-1 text-center">
            <h1 className="truncate font-quran text-lg">{meta.name}</h1>
            <p className="text-[11px] text-muted-foreground">
              {meta.type} · {toArabicDigits(meta.count)} آية
            </p>
          </div>
          <div className="flex items-center">
            <button
              type="button"
              className="tap-lg size-10 text-muted-foreground"
              onClick={() => setScale(Math.max(0.9, Number((scale - 0.1).toFixed(2))))}
              aria-label="تصغير الخط"
            >
              <Minus className="mx-auto size-4" />
            </button>
            <Type className="size-4 text-muted-foreground" />
            <button
              type="button"
              className="tap-lg size-10 text-muted-foreground"
              onClick={() => setScale(Math.min(1.8, Number((scale + 0.1).toFixed(2))))}
              aria-label="تكبير الخط"
            >
              <Plus className="mx-auto size-4" />
            </button>
          </div>
        </div>
        <div className="flex items-center justify-between px-3 pb-2 text-xs text-muted-foreground">
          <Link
            to="/quran/$surahId"
            params={{ surahId: String(Math.max(1, surahId - 1)) }}
            className={cn("flex items-center gap-1 py-1", surahId <= 1 && "pointer-events-none opacity-30")}
          >
            <ChevronRight className="size-4" /> السابقة
          </Link>
          <button type="button" className="flex items-center gap-1 py-1" onClick={() => void download()} disabled={busy}>
            <Download className="size-3.5" />
            {downloaded.includes(surahId) ? "مُنزّلة" : "تنزيل التلاوة"}
          </button>
          <Link
            to="/quran/$surahId"
            params={{ surahId: String(Math.min(114, surahId + 1)) }}
            className={cn("flex items-center gap-1 py-1", surahId >= 114 && "pointer-events-none opacity-30")}
          >
            التالية <ChevronLeft className="size-4" />
          </Link>
        </div>
      </header>

      <article className="bg-paper px-4 py-6 pb-40">
        {surahId !== 9 && surahId !== 1 ? (
          <p className="mb-6 text-center font-quran text-xl text-accent">بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ</p>
        ) : null}
        {!surah ? (
          <p className="py-16 text-center text-sm text-muted-foreground">جارٍ فتح المصحف…</p>
        ) : (
          <div className="quran-text text-ink" style={{ fontSize: `${scale * 1.55}rem` }}>
            {surah.ayahs.map((a) => (
              <span
                key={a.n}
                id={`ayah-${a.n}`}
                onClick={() => {
                  setActive(a);
                  setShowTafsir(false);
                  setLast({ surahId, ayah: a.n, updatedAt: Date.now() });
                }}
                className={cn(
                  "cursor-pointer rounded-md px-0.5 transition-colors duration-[var(--motion-quick)]",
                  active?.n === a.n && "bg-surface",
                  playingAyah === a.n && "bg-muted",
                )}
              >
                {a.t}
                <span className="mx-1 inline-flex size-[1.35em] translate-y-0.5 items-center justify-center rounded-full border border-sage/40 align-middle font-sans text-[0.55em] text-sage">
                  {toArabicDigits(a.n)}
                </span>
                {a.sajda ? <span className="ms-1 align-middle text-[0.55em] text-sage">سجدة</span> : null}
              </span>
            ))}
          </div>
        )}
      </article>

      {active ? (
        <div className="sticky bottom-[calc(5.25rem+env(safe-area-inset-bottom))] z-20 mx-3 mb-2 rounded-2xl border border-border bg-card p-3 shadow-[var(--shadow-border)]">
          <div className="mb-2 flex items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              {meta.shortName} · {toArabicDigits(active.n)}
            </p>
            <button type="button" className="text-xs text-muted-foreground" onClick={() => setActive(null)}>
              إغلاق
            </button>
          </div>
          <div className="grid grid-cols-5 gap-1">
            <Tool
              label={playingAyah === active.n ? "إيقاف" : "استماع"}
              icon={playingAyah === active.n ? Pause : Play}
              onClick={() => {
                if (playingAyah === active.n) audioEngine.toggle();
                else void play(active, true);
              }}
            />
            <Tool
              label={`تكرار ${toArabicDigits(repeat)}`}
              icon={Repeat}
              onClick={() => setRepeat((r) => (r >= 7 ? 1 : r + 1))}
            />
            <Tool
              label="تفسير"
              icon={Type}
              onClick={() => void openTafsir(active)}
            />
            <Tool
              label={isFav ? "محفوظة" : "مفضلة"}
              icon={Heart}
              onClick={() =>
                toggleFavorite({
                  id: favId,
                  kind: "ayah",
                  title: `${meta.name} ${toArabicDigits(active.n)}`,
                  text: active.t,
                  href: `/quran/${surahId}?ayah=${active.n}`,
                  meta: meta.name,
                })
              }
            />
            <Tool
              label="مشاركة"
              icon={Share2}
              onClick={() => void shareText(`${meta.name} ${toArabicDigits(active.n)}`, active.t)}
            />
          </div>
          <div className="mt-2 flex gap-2">
            <button
              type="button"
              className="h-10 flex-1 rounded-xl bg-surface text-xs"
              onClick={() =>
                addBookmark({
                  id: `ayah:${surahId}:${active.n}`,
                  label: `${meta.name} — آية ${toArabicDigits(active.n)}`,
                  href: `/quran/${surahId}?ayah=${active.n}`,
                })
              }
            >
              <Bookmark className="mx-auto mb-0.5 size-3.5" />
              علامة
            </button>
            <button
              type="button"
              className="h-10 flex-1 rounded-xl bg-accent text-xs text-accent-foreground"
              onClick={() => void play(active, false)}
            >
              استماع للآية
            </button>
          </div>
          {showTafsir ? (
            <div className="mt-3 max-h-40 overflow-y-auto border-t border-border pt-2 text-sm leading-7 text-foreground">
              <p className="mb-1 text-[11px] text-muted-foreground">التفسير الميسر — مجمع الملك فهد</p>
              {tafsirFor || "جارٍ التحميل…"}
            </div>
          ) : null}
        </div>
      ) : null}
    </AppShell>
  );
}

function Tool({
  label,
  icon: Icon,
  onClick,
}: {
  label: string;
  icon: typeof Play;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className="flex flex-col items-center gap-1 rounded-xl py-2 text-[10px] text-muted-foreground hover:bg-surface">
      <Icon className="size-4" />
      {label}
    </button>
  );
}
