import { createFileRoute } from "@tanstack/react-router";
import { Search as SearchIcon } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { BackButton } from "@/components/back-button";
import { AppShell, TopBar } from "@/components/layout/app-shell";
import { TextLink } from "@/components/text-link";
import { searchAll, type SearchHit } from "@/lib/search";

export const Route = createFileRoute("/search/")({ component: SearchPage });

const FILTERS = [
  { id: "all", label: "الكل" },
  { id: "quran", label: "القرآن" },
  { id: "adhkar", label: "الأذكار" },
  { id: "dua", label: "الأدعية" },
  { id: "hadith", label: "الحديث" },
  { id: "mutn", label: "المتون" },
] as const;

function SearchPage() {
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (q.trim().length < 2) {
      setHits([]);
      return;
    }
    setLoading(true);
    const t = window.setTimeout(() => {
      void searchAll(q).then((r) => {
        setHits(r);
        setLoading(false);
      });
    }, 180);
    return () => window.clearTimeout(t);
  }, [q]);

  const shown = useMemo(
    () => (filter === "all" ? hits : hits.filter((h) => h.source === filter)),
    [hits, filter],
  );

  return (
    <AppShell>
      <TopBar title="البحث" back={<BackButton href="/" />} />
      <div className="px-4 pt-3">
        <label className="flex items-center gap-2 rounded-2xl bg-card px-3 py-2 shadow-[var(--shadow-border)]">
          <SearchIcon className="size-4 text-muted-foreground" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث في القرآن والأذكار والمتون"
            className="h-10 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </label>
        <div className="mt-3 flex gap-1 overflow-x-auto pb-1">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              className={`h-9 shrink-0 rounded-full px-3 text-xs ${filter === f.id ? "bg-accent text-accent-foreground" : "bg-surface text-muted-foreground"}`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>
      <div className="px-4 py-3">
        {loading ? <p className="py-8 text-center text-sm text-muted-foreground">جارٍ البحث…</p> : null}
        {!loading && q.trim().length >= 2 && shown.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted-foreground">لا نتائج</p>
        ) : null}
        <ul className="space-y-2">
          {shown.map((h) => (
            <li key={h.id}>
              <TextLink href={h.href} className="block rounded-2xl bg-card p-4 shadow-[var(--shadow-border)]">
                <p className="text-[11px] text-sage">{h.sourceLabel}</p>
                <p className="mt-1 font-medium">{h.title}</p>
                <p className="mt-1 line-clamp-3 text-sm leading-7 text-muted-foreground">{h.snippet}</p>
              </TextLink>
            </li>
          ))}
        </ul>
      </div>
    </AppShell>
  );
}
