import { createFileRoute } from "@tanstack/react-router";
import { Page } from "@/components/ui";
import { STORIES } from "@/data/stories";
import { usePrefs } from "@/lib/prefs";

export const Route = createFileRoute("/prophets/$id")({ component: StoryPage });

function StoryPage() {
  const { id } = Route.useParams();
  const story = STORIES.find((s) => s.id === id);
  const prefs = usePrefs();
  if (!story) return <Page title="غير موجود" back>لا توجد هذه القصة.</Page>;
  const favId = `story-${story.id}`;
  return (
    <Page title={`${story.name} ${story.honor}`} subtitle={story.summary} back>
      <button
        type="button"
        className="mb-3 min-h-11 text-sm font-semibold text-gold"
        onClick={() => prefs.toggleFav({ id: favId, kind: "story", title: story.name, href: `/prophets/${story.id}` })}
      >
        {prefs.favorites.some((f) => f.id === favId) ? "في المفضلة" : "حفظ في المفضلة"}
      </button>
      {story.sections.map((sec) => (
        <section key={sec.h} className="mb-4">
          <h2 className="font-bold text-emerald">{sec.h}</h2>
          <p className="mt-1 text-sm leading-relaxed">{sec.p}</p>
        </section>
      ))}
      <p className="text-sm"><span className="font-bold">الآيات: </span>{story.ayahs.join(" · ")}</p>
      <p className="mt-2 text-sm"><span className="font-bold">الحديث: </span>{story.hadith}</p>
      <p className="mt-2 text-xs text-muted">المراجع: {story.sources.join(" · ")}</p>
    </Page>
  );
}
