import { createFileRoute, Link } from "@tanstack/react-router";
import { Page } from "@/components/ui";
import { STORIES } from "@/data/stories";

export const Route = createFileRoute("/prophets/")({ component: ProphetsPage });

function ProphetsPage() {
  const prophets = STORIES.filter((s) => s.kind === "prophet");
  const others = STORIES.filter((s) => s.kind === "story");
  return (
    <Page title="قصص الأنبياء" subtitle="ملخصات تعليمية تقف عند القرآن والحديث الصحيح، ولا تُعرض الإسرائيليات على أنها حق.">
      <List title="الأنبياء" items={prophets} />
      <List title="قصص قرآنية" items={others} />
    </Page>
  );
}

function List({ title, items }: { title: string; items: typeof STORIES }) {
  return (
    <section className="mb-5">
      <h2 className="mb-2 text-lg font-bold text-emerald-deep">{title}</h2>
      <ul className="grid gap-2">
        {items.map((s) => (
          <li key={s.id}>
            <Link to="/prophets/$id" params={{ id: s.id }} className="block rounded-2xl border border-line bg-card px-4 py-3">
              <span className="font-bold">{s.name} {s.honor}</span>
              <span className="mt-1 block text-sm text-muted">{s.summary}</span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
