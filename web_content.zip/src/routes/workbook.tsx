import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/ministry/shell";
import { WorkbookPage } from "@/components/ministry/workbook-page";

export const Route = createFileRoute("/workbook")({
  component: function WorkbookRoute() {
    return (
      <AppShell>
        <WorkbookPage />
      </AppShell>
    );
  },
});
