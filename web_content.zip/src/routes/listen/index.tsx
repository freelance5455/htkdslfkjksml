import { createFileRoute } from "@tanstack/react-router";
import { Download, Pause, Play } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { BackButton } from "@/components/back-button";
import { AppShell, TopBar } from "@/components/layout/app-shell";
import { loadQuran, quranMeta } from "@/content/catalog";
import { adhkarLists, libraryBooks } from "@/content/catalog";
import { audioEngine, downloadSurahAyahs, getReciter, type PlayerStatus } from "@/lib/audio";
import { useAppStore } from "@/lib/store";
import { toArabicDigits } from "@/lib/utils";

export const Route = createFileRoute("/listen/")({ component: ListenPage });

function ListenPage() {
  const reciterId = useAppStore((s) => s.settings.reciterId);
  const setReciter = useAppStore((s) => s.setReciter);
  const downloaded = useAppStore((s) => s.downloadedSurahs);
  const markDownloaded = useAppStore((s) => s.markDownloaded);
  const [tab, setTab] = useState<"quran" | "adhkar" | "library">("quran");
  const [status, setStatus] = useState<PlayerStatus>(audioEngine.status);
  const [busyId, setBusyId] = useState<number | null>(null);

  useEffect(() => audioEngine.subscribe(setStatus), []);

  return (
    <AppShell>
      <TopBar title="الاستماع" back={<BackButton href="/" />} />
      <div className="px-4 pt-3">
        <label className="block text-xs text-muted-foreground">القارئ</label>
        <select
          className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm"
          value={reciterId}
          onChange={(e) => setReciter(e.target.value)}
        >
          {["alafasy", "husary", "sudais", "minshawi"].map((id) => (
            <option key={id} value={id}>
              {getReciter(id).name}
            </option>
          ))}
        </select>
        <div className="mt-3 grid grid-cols-3 gap-1 rounded-2xl bg-surface p-1">
          {(
            [
              ["quran", "القرآن"],
              ["adhkar", "الأذكار"],
              ["library", "المكتبة"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`h-10 rounded-xl text-sm ${tab === id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {tab === "quran" ? (
        <ul className="mt-2 divide-y divide-border px-2 pb-6">
          {quranMeta.surahs.map((s) => {
            const playing = status.surahId === s.id && status.playing;
            return (
              <li key={s.id} className="flex items-center gap-2 px-3 py-2.5">
                <span className="w-8 text-sm text-muted-foreground">{toArabicDigits(s.id)}</span>
                <span className="flex-1 font-quran">{s.name}</span>
                <button
                  type="button"
                  className="tap-lg size-10 text-accent"
                  aria-label="تنزيل"
                  disabled={busyId === s.id}
                  onClick={() => {
                    void (async () => {
                      setBusyId(s.id);
                      try {
                        const surah = (await loadQuran()).find((x) => x.id === s.id);
                        if (!surah) return;
                        const n = await downloadSurahAyahs(getReciter(reciterId), surah);
                        markDownloaded(s.id);
                        toast(n ? `حُفظت ${toArabicDigits(n)} آية` : "تعذر التنزيل");
                      } finally {
                        setBusyId(null);
                      }
                    })();
                  }}
                >
                  <Download className={`mx-auto size-4 ${downloaded.includes(s.id) ? "opacity-100" : "opacity-50"}`} />
                </button>
                <button
                  type="button"
                  className="tap-lg size-10 text-accent"
                  onClick={() => {
                    void (async () => {
                      if (playing) {
                        audioEngine.toggle();
                        return;
                      }
                      const surah = (await loadQuran()).find((x) => x.id === s.id);
                      if (!surah) return;
                      const first = surah.ayahs[0];
                      await audioEngine.playAyah({
                        surahId: surah.id,
                        ayah: first.n,
                        global: first.g,
                        title: surah.name,
                        reciterId,
                        continueSurah: surah,
                      });
                    })();
                  }}
                >
                  {playing ? <Pause className="mx-auto size-4" /> : <Play className="mx-auto size-4" />}
                </button>
              </li>
            );
          })}
        </ul>
      ) : null}

      {tab === "adhkar" ? (
        <ul className="mt-3 space-y-2 px-4 pb-6">
          {adhkarLists.map((l) => (
            <li key={l.id}>
              <button
                type="button"
                className="flex w-full items-center justify-between rounded-2xl bg-card px-4 py-3.5 text-right shadow-[var(--shadow-border)]"
                onClick={() => {
                  const text = l.items.map((i) => i.text).join("\n\n");
                  const ok = audioEngine.speak(text.slice(0, 4000), l.title);
                  if (!ok) toast("قراءة الجهاز غير متاحة");
                }}
              >
                <span>{l.title}</span>
                <Play className="size-4 text-accent" />
              </button>
            </li>
          ))}
        </ul>
      ) : null}

      {tab === "library" ? (
        <ul className="mt-3 space-y-2 px-4 pb-6">
          {libraryBooks
            .filter((b) => !b.comingSoon)
            .map((b) => (
              <li key={b.id}>
                <button
                  type="button"
                  className="flex w-full items-center justify-between rounded-2xl bg-card px-4 py-3.5 text-right shadow-[var(--shadow-border)]"
                  onClick={() => {
                    const text = b.sections[0]?.body ?? "";
                    const ok = audioEngine.speak(text.slice(0, 4000), b.title);
                    if (!ok) toast("قراءة الجهاز غير متاحة");
                  }}
                >
                  <span>
                    <span className="block">{b.title}</span>
                    <span className="text-xs text-muted-foreground">قراءة الجهاز للنص المتوفر</span>
                  </span>
                  <Play className="size-4 text-accent" />
                </button>
              </li>
            ))}
        </ul>
      ) : null}
    </AppShell>
  );
}
