import { createFileRoute } from "@tanstack/react-router";
import { RankOverlay } from "@/components/overlays/panels";
import { readLook } from "@/lib/live/search";

export const Route = createFileRoute("/overlay/rank")({
  validateSearch: (search: Record<string, unknown>) => readLook(search),
  component: Page,
});

function Page() {
  return <RankOverlay look={Route.useSearch()} />;
}
