import { createFileRoute } from "@tanstack/react-router";
import { GoalOverlay } from "@/components/overlays/panels";
import { readLook } from "@/lib/live/search";

type GoalSearch = ReturnType<typeof readLook> & {
  metric: "likes" | "follows" | "coins";
  goal: number;
};

function readGoal(search: Record<string, unknown>): GoalSearch {
  const goal = Number(search.goal);
  const metric = search.metric === "follows" || search.metric === "coins" ? search.metric : "likes";
  return {
    ...readLook(search),
    metric,
    goal: Number.isFinite(goal) && goal > 0 ? Math.min(goal, 10_000_000) : 5000,
  };
}

export const Route = createFileRoute("/overlay/goal")({
  validateSearch: (search: Record<string, unknown>) => readGoal(search),
  component: Page,
});

function Page() {
  const search = Route.useSearch();
  return <GoalOverlay look={search} metric={search.metric} goal={search.goal} />;
}
