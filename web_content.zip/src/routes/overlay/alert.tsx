import { createFileRoute } from "@tanstack/react-router";
import { AlertOverlay } from "@/components/overlays/panels";
import { readLook } from "@/lib/live/search";

export const Route = createFileRoute("/overlay/alert")({
  validateSearch: (search: Record<string, unknown>) => readLook(search),
  component: Page,
});

function Page() {
  return <AlertOverlay look={Route.useSearch()} />;
}
