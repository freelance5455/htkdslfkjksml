import { createFileRoute } from "@tanstack/react-router";
import { ChatOverlay } from "@/components/overlays/panels";
import { readLook } from "@/lib/live/search";

export const Route = createFileRoute("/overlay/chat")({
  validateSearch: (search: Record<string, unknown>) => readLook(search),
  component: Page,
});

function Page() {
  const look = Route.useSearch();
  return <ChatOverlay look={look} />;
}