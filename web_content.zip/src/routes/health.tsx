import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Card, PageTitle } from "@/components/ui";
import { getHealth, listAudit } from "@/lib/server/books";
import { isoToJalali } from "@/lib/accounting/jalali";
import { useQuery } from "@tanstack/react-query";

export const Route = createFileRoute("/health")({ component: HealthPage });

function HealthPage() {
  const h = useQuery({ queryKey: ["health"], queryFn: () => getHealth() });
  const a = useQuery({ queryKey: ["audit"], queryFn: () => listAudit({ data: { limit: 40 } }) });
  const d = h.data;
  return (
    <AppShell>
      <PageTitle title="سلامت سیستم" subtitle="اسناد نامتوازن، پشتیبان، روزهای باز و ردپای حسابرسی" />
      {d && (
        <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Card><p className="text-xs text-muted">عملیات امروز</p><p className="text-2xl font-semibold">{d.opsToday}</p></Card>
          <Card><p className="text-xs text-muted">اسناد امروز</p><p className="text-2xl font-semibold">{d.journalsToday}</p></Card>
          <Card><p className="text-xs text-muted">اسناد نامتوازن</p><p className="text-2xl font-semibold text-danger">{d.unbalanced.length}</p></Card>
          <Card><p className="text-xs text-muted">رویداد حسابرسی</p><p className="text-2xl font-semibold">{d.auditEvents}</p></Card>
        </div>
      )}
      <p className="mb-2 text-sm text-muted">آخرین پشتیبان: {d?.lastBackup?.name ?? "—"} {d?.todayClosed ? "— امروز بسته است" : "— امروز باز است"}</p>
      <h2 className="mb-2 text-sm font-medium text-navy">Audit Trail</h2>
      <div className="space-y-1 rounded-xl border border-line bg-card p-3 text-sm">
        {((a.data ?? []) as Array<Record<string, unknown>>).map((row) => (
          <div key={String(row.id)} className="flex justify-between gap-3 border-b border-line/60 py-1">
            <span>{String(row.action)} — {String(row.entity)}</span>
            <span className="text-xs text-muted">{isoToJalali(String(row.created_at).slice(0, 10))}</span>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
