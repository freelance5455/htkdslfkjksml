import { createFileRoute } from "@tanstack/react-router";
import { BoostPage } from "@/features/boost";

export const Route = createFileRoute("/boost")({
  head: () => ({ meta: [{ title: "Boost · FrameForge BOOYAH" }] }),
  component: BoostPage,
});
