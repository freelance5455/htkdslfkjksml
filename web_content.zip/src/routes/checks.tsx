import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { MoneyText } from "@/components/fields";
import { Badge, PageTitle, TableWrap, Td, Th } from "@/components/ui";
import { listChecks } from "@/lib/server/books";
import { isoToJalali } from "@/lib/accounting/jalali";
import { useQuery } from "@tanstack/react-query";

export const Route = createFileRoute("/checks")({ component: ChecksPage });

function ChecksPage() {
  const q = useQuery({ queryKey: ["checks"], queryFn: () => listChecks() });
  const rows = (q.data ?? []) as Array<Record<string, unknown>>;
  return (
    <AppShell>
      <PageTitle title="مدیریت چک‌ها" subtitle="اسناد دریافتنی و پرداختنی" />
      <TableWrap>
        <thead>
          <tr>
            <Th>شماره</Th>
            <Th>نوع</Th>
            <Th>شخص</Th>
            <Th>مبلغ</Th>
            <Th>سررسید</Th>
            <Th>وضعیت</Th>
          </tr>
        </thead>
        <tbody>
          {rows.map((c) => (
            <tr key={String(c.id)}>
              <Td className="tabular">{String(c.number)}</Td>
              <Td>{c.kind === "receivable" ? "دریافتنی" : "پرداختنی"}</Td>
              <Td>{String(c.party_name ?? "—")}</Td>
              <Td><MoneyText value={c.amount} /></Td>
              <Td>{c.due_date ? isoToJalali(String(c.due_date)) : "—"}</Td>
              <Td><Badge>{String(c.status)}</Badge></Td>
            </tr>
          ))}
        </tbody>
      </TableWrap>
    </AppShell>
  );
}
