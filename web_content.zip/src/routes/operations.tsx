import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { OpForm } from "@/components/op-form";
import { Badge, Button, PageTitle, TableWrap, Td, Th } from "@/components/ui";
import { MoneyText } from "@/components/fields";
import { bootstrap, deleteOperation, listOperations } from "@/lib/server/books";
import { OP_LABELS, OPERATION_TYPES, type OperationType } from "@/lib/accounting/types";
import { isoToJalali } from "@/lib/accounting/jalali";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

type Search = { type?: string };

export const Route = createFileRoute("/operations")({
  validateSearch: (s: Record<string, unknown>): Search => ({ type: typeof s.type === "string" ? s.type : undefined }),
  component: OperationsPage,
});

function OperationsPage() {
  const { type } = Route.useSearch();
  const nav = Route.useNavigate();
  const qc = useQueryClient();
  const boot = useQuery({ queryKey: ["bootstrap"], queryFn: () => bootstrap() });
  const list = useQuery({ queryKey: ["operations"], queryFn: () => listOperations({ data: { limit: 80 } }) });
  const del = useMutation({
    mutationFn: (id: string) => deleteOperation({ data: { id, reason: "حذف قبل از بستن روز" } }),
    onSuccess: () => {
      toast.success("حذف منطقی انجام شد.");
      qc.invalidateQueries();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const t = (type && OPERATION_TYPES.includes(type as OperationType) ? type : "") as OperationType | "";

  return (
    <AppShell>
      <PageTitle
        title="عملیات روزانه"
        subtitle="هر ثبت، سند دوبل و دفتر کل را به‌صورت خودکار به‌روز می‌کند."
        actions={
          t ? (
            <Button variant="secondary" onClick={() => nav({ search: {} })}>
              بازگشت به فهرست انواع
            </Button>
          ) : null
        }
      />

      {!t && (
        <div className="mb-6 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
          {OPERATION_TYPES.filter((x) => !["opening", "closing"].includes(x)).map((op) => (
            <button
              key={op}
              type="button"
              onClick={() => nav({ search: { type: op } })}
              className="rounded-xl border border-line bg-card px-3 py-4 text-right text-sm text-navy hover:border-gold"
            >
              {OP_LABELS[op]}
            </button>
          ))}
        </div>
      )}

      {t && boot.data && (
        <div className="mb-8 rounded-xl border border-line bg-card p-4">
          <OpForm
            type={t}
            parties={boot.data.parties as never}
            items={boot.data.items as never}
            sources={boot.data.sources as never}
            onDone={() => {
              nav({ search: {} });
              qc.invalidateQueries();
            }}
          />
        </div>
      )}

      <h2 className="mb-2 text-sm font-medium text-navy">آخرین عملیات</h2>
      <TableWrap>
        <thead>
          <tr>
            <Th>شماره</Th>
            <Th>تاریخ</Th>
            <Th>نوع</Th>
            <Th>شخص</Th>
            <Th>مبلغ</Th>
            <Th>سند</Th>
            <Th>وضعیت</Th>
            <Th />
          </tr>
        </thead>
        <tbody>
          {(list.data ?? []).map((row) => {
            const r = row as Record<string, unknown>;
            return (
              <tr key={String(r.id)}>
                <Td className="tabular">{String(r.number)}</Td>
                <Td>{isoToJalali(String(r.date))}</Td>
                <Td>{OP_LABELS[r.type as OperationType] ?? String(r.type)}</Td>
                <Td>{String(r.party_name ?? "—")}</Td>
                <Td>
                  <MoneyText value={r.net_amount} />
                </Td>
                <Td className="tabular">{String(r.journal_number ?? "—")}</Td>
                <Td>
                  <Badge tone={r.status === "posted" ? "ok" : "danger"}>{String(r.status)}</Badge>
                </Td>
                <Td>
                  {r.status === "posted" && (
                    <button type="button" className="text-xs text-danger" onClick={() => del.mutate(String(r.id))}>
                      حذف
                    </button>
                  )}
                </Td>
              </tr>
            );
          })}
        </tbody>
      </TableWrap>
      <p className="mt-3 text-xs text-muted">حذف فیزیکی انجام نمی‌شود. رکورد با وضعیت Deleted و ردپای حسابرسی نگه داشته می‌شود.</p>
    </AppShell>
  );
}
