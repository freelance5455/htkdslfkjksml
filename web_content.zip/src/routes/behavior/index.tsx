import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/page";
import { BEHAVIORS, DAILY_STEPS } from "@/data/behavior";
import { useProgress } from "@/lib/progress";
import { dayIndex, syriaDateKey } from "@/lib/utils";

export const Route = createFileRoute("/behavior/")({
  head: () => ({ meta: [{ title: "الإيمان والسلوك — لأنه الله" }] }),
  component: BehaviorPage,
});

function BehaviorPage() {
  const day = syriaDateKey();
  const step = DAILY_STEPS[dayIndex(DAILY_STEPS.length)] ?? DAILY_STEPS[0];
  const done = useProgress((state) => Boolean(state.steps[day]));
  const toggleStep = useProgress((state) => state.toggleStep);

  return (
    <main>
      <PageIntro
        kicker="من المعرفة إلى العمل"
        title="الإيمان والسلوك اليومي"
        lede="تعظيم الله ومحبته يظهران في الصدق والعدل والرحمة. هذا القسم لا يحكم على إيمانك ولا يقيس صلاحك."
      />
      <section className="mx-auto max-w-6xl px-4 py-8">
        <article className="rounded-card border border-line bg-soft p-6">
          <h2 className="font-display text-3xl text-primary">خطوة اليوم</h2>
          <p className="mt-3 leading-8">{step}</p>
          <button type="button" onClick={() => toggleStep(day)} className="mt-4 rounded-full bg-primary px-4 py-2 text-sm text-primary-fg" aria-pressed={done}>
            {done ? "تمّت على هذا الجهاز" : "أتممتها"}
          </button>
        </article>
        <div className="mt-6 grid gap-3 md:grid-cols-2">
          {BEHAVIORS.map((item) => (
            <Link key={item.id} to="/behavior/$slug" params={{ slug: item.id }} className="rounded-card border border-line bg-surface p-5">
              <h2 className="font-display text-3xl text-primary">{item.title}</h2>
              <p className="mt-2 text-sm leading-7 text-muted">{item.summary}</p>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
