import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { getBehavior } from "@/data/behavior";

export const Route = createFileRoute("/behavior/$slug")({
  loader: ({ params }) => {
    const item = getBehavior(params.slug);
    if (!item) throw notFound();
    return item;
  },
  head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `${loaderData.title} — السلوك` : "سلوك" }] }),
  component: BehaviorDetail,
});

function BehaviorDetail() {
  const item = Route.useLoaderData();
  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <Link to="/behavior" className="text-sm text-olive">كل الموضوعات</Link>
      <h1 className="mt-4 font-display text-4xl text-primary">{item.title}</h1>
      <p className="mt-4 leading-8">{item.summary}</p>
      <section className="mt-6 rounded-card border border-line p-5">
        <h2 className="font-display text-3xl text-primary">الدليل</h2>
        <p className="mt-3 leading-8">{item.daleel}</p>
        <p className="mt-2 text-sm text-muted">{item.source}</p>
        {item.url ? <a className="mt-3 inline-block text-primary" href={item.url} rel="noreferrer">المصدر</a> : null}
      </section>
      <section className="mt-6 rounded-card bg-soft p-5">
        <h2 className="font-display text-3xl text-primary">تطبيق واقعي</h2>
        <p className="mt-3 leading-8">{item.practice}</p>
      </section>
    </main>
  );
}
