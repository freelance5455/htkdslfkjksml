import { Link, createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppFrame, PageTitle } from "@/components/shell";
import { useEdu } from "@/components/edu-provider";
import { UserButton } from "@/lib/auth/gates";
import { t } from "@/content/copy";
import { chaptersForGrade, lessonItemId, subjects, exams } from "@/content/catalog";
import { fill, tx, useLocale } from "@/lib/locale";
import { listPacks } from "@/lib/offline";

export const Route = createFileRoute("/progress")({ component: ProgressPage });

function ProgressPage() {
  return (
    <AppFrame>
      <ProgressBody />
    </AppFrame>
  );
}

function ProgressBody() {
  const locale = useLocale((state) => state.locale);
  const { profile, progress } = useEdu();
  const [downloads, setDownloads] = useState(0);
  useEffect(() => {
    listPacks()
      .then((packs) => setDownloads(packs.length))
      .catch(() => setDownloads(0));
  }, []);
  if (!profile) return null;

  const lessonTotal = subjects.reduce(
    (sum, subject) => sum + chaptersForGrade(subject, profile.grade).length,
    0,
  );
  const lessonsDone = subjects.reduce((sum, subject) => {
    return (
      sum +
      chaptersForGrade(subject, profile.grade).filter((chapter) =>
        progress.some(
          (row) => row.kind === "lesson" && row.itemId === lessonItemId(subject.id, chapter.id) && row.completed,
        ),
      ).length
    );
  }, 0);
  const percent = lessonTotal ? Math.round((lessonsDone / lessonTotal) * 100) : 0;
  const quizzes = progress.filter((row) => row.kind === "quiz");

  return (
    <div>
      <PageTitle title={t(locale, "progressTitle")} lede={t(locale, "progressLede")} />
      <section className="rounded-2xl border border-line bg-card p-4">
        <p className="text-sm font-semibold text-muted">{t(locale, "overall")}</p>
        <p className="mt-1 text-3xl font-semibold tabular-nums">{percent}%</p>
        <div className="mt-3 h-2 overflow-hidden rounded-md bg-paper-2">
          <div className="h-full bg-teal" style={{ width: `${percent}%` }} />
        </div>
        <p className="mt-2 text-sm tabular-nums text-muted">
          {t(locale, "lessonsFinished")} {lessonsDone}/{lessonTotal}
        </p>
      </section>
      <ul className="mt-4 space-y-3">
        {subjects.map((subject) => {
          const chapters = chaptersForGrade(subject, profile.grade);
          const done = chapters.filter((chapter) =>
            progress.some(
              (row) => row.kind === "lesson" && row.itemId === lessonItemId(subject.id, chapter.id) && row.completed,
            ),
          ).length;
          const width = chapters.length ? Math.round((done / chapters.length) * 100) : 0;
          return (
            <li key={subject.id} className="rounded-2xl border border-line bg-card p-4">
              <div className="flex items-baseline justify-between gap-3">
                <h2 className="font-semibold">{tx(locale, subject.title)}</h2>
                <span className="text-sm tabular-nums text-muted">
                  {done}/{chapters.length}
                </span>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-md bg-paper-2">
                <div className="h-full bg-teal" style={{ width: `${width}%` }} />
              </div>
            </li>
          );
        })}
      </ul>
      <h2 className="mb-3 mt-8 text-sm font-semibold text-muted">{t(locale, "recentScores")}</h2>
      {quizzes.length === 0 ? (
        <p className="text-sm text-muted">{t(locale, "noProgress")}</p>
      ) : (
        <ul className="space-y-2">
          {quizzes.slice(-6).reverse().map((row) => (
            <li key={row.itemId} className="flex items-center justify-between rounded-2xl border border-line bg-card px-4 py-3 text-sm">
              <span>{labelFor(row.itemId, locale)}</span>
              <span className="font-semibold tabular-nums">
                {fill(t(locale, "outOf"), { score: row.score ?? 0, total: row.total ?? 0 })}
              </span>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-6 text-sm text-muted">
        {t(locale, "downloadedCount")}: <span className="font-semibold tabular-nums text-ink">{downloads}</span>
      </p>
      <div className="mt-4 flex flex-wrap gap-3">
        {exams.map((exam) => (
          <Link key={exam.id} to="/exams/$examId" params={{ examId: exam.id }} className="text-sm font-semibold text-teal-deep">
            {tx(locale, exam.title)}
          </Link>
        ))}
      </div>
      <div className="mt-8 md:hidden">
        <UserButton />
      </div>
    </div>
  );
}

function labelFor(itemId: string, locale: ReturnType<typeof useLocale.getState>["locale"]) {
  const [path] = itemId.split("#");
  const [subjectId, chapterId] = path.split("/");
  const subject = subjects.find((item) => item.id === subjectId);
  const chapter = subject?.chapters.find((item) => item.id === chapterId);
  if (!subject || !chapter) return itemId;
  return `${tx(locale, subject.title)} · ${tx(locale, chapter.title)}`;
}
