import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/page";
import { getName } from "@/data/names";
import { NAMES } from "@/data/names";
import { useProgress } from "@/lib/progress";
import { arNum, syriaDateKey } from "@/lib/utils";

export const Route = createFileRoute("/progress")({
  head: () => ({ meta: [{ title: "ماذا تعلمت؟ — لأنه الله" }] }),
  component: ProgressPage,
});

function ProgressPage() {
  const read = useProgress((state) => state.read);
  const saved = useProgress((state) => state.saved);
  const fav = useProgress((state) => state.fav);
  const srs = useProgress((state) => state.srs);
  const quiz = useProgress((state) => state.quiz);
  const today = syriaDateKey();
  const due = Object.entries(srs).filter(([, card]) => card.due <= today).length;

  return (
    <main>
      <PageIntro
        kicker="سجل هذا الجهاز"
        title="ماذا تعلمت؟"
        lede="لا يُنشأ هنا تقدم وهمي. الأرقام التالية هي ما فعلته أنت على هذا المتصفح فقط، ويمكن مسحها من إعدادات المتصفح."
      />
      <section className="mx-auto grid max-w-6xl gap-4 px-4 py-8 md:grid-cols-4">
        <Stat label="أسماء أتممت قراءتها" value={`${arNum(read.length)} / ${arNum(NAMES.length)}`} />
        <Stat label="في قائمة المراجعة" value={arNum(saved.length)} />
        <Stat label="بطاقات مستحقة اليوم" value={arNum(due)} />
        <Stat label="آخر اختبار" value={quiz ? `${arNum(quiz.score)} / ${arNum(quiz.total)}` : "لا يوجد"} />
      </section>
      <section className="mx-auto max-w-6xl px-4 pb-10">
        <h2 className="font-display text-3xl text-primary">قائمة المراجعة</h2>
        {saved.length === 0 ? <p className="mt-3 text-muted">لم تُضف أسماء بعد. افتح اسمًا واختر «أضف إلى المراجعة».</p> : (
          <ul className="mt-3 grid gap-2 sm:grid-cols-2">
            {saved.map((slug) => {
              const name = getName(slug);
              if (!name) return null;
              return <li key={slug}><Link to="/names/$slug" params={{ slug }} className="block rounded-card border border-line bg-surface px-4 py-3">{name.ar}</Link></li>;
            })}
          </ul>
        )}
        <h2 className="mt-8 font-display text-3xl text-primary">المفضلة</h2>
        {fav.length === 0 ? <p className="mt-3 text-muted">لا عناصر محفوظة.</p> : (
          <ul className="mt-3 space-y-2 text-sm">
            {fav.map((key) => <li key={key} className="rounded-card border border-line px-4 py-3">{labelFav(key)}</li>)}
          </ul>
        )}
        <Link to="/study" className="mt-6 inline-block rounded-full bg-primary px-5 py-3 text-primary-fg">متابعة المراجعة</Link>
      </section>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <article className="rounded-card border border-line bg-surface p-4">
      <p className="text-sm text-olive">{label}</p>
      <p className="mt-2 font-display text-3xl text-primary">{value}</p>
    </article>
  );
}

function labelFav(key: string) {
  const [type, id] = key.split(":");
  if (type === "name") return getName(id ?? "")?.ar ?? key;
  return key;
}
