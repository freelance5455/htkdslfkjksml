import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Button, PageTitle, TableWrap, Td, Th } from "@/components/ui";
import { createBackup, listBackups, restoreBackup } from "@/lib/server/books";
import { isoToJalali } from "@/lib/accounting/jalali";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

export const Route = createFileRoute("/backup")({ component: BackupPage });

function BackupPage() {
  const qc = useQueryClient();
  const list = useQuery({ queryKey: ["backups"], queryFn: () => listBackups() });
  const make = useMutation({
    mutationFn: () => createBackup(),
    onSuccess: (r) => {
      toast.success(r.name);
      const blob = new Blob([JSON.stringify(r.payload, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `${r.name}.json`;
      a.click();
      qc.invalidateQueries();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const restore = useMutation({
    mutationFn: (id: string) => restoreBackup({ data: { id } }),
    onSuccess: () => {
      toast.success("بازیابی انجام شد.");
      qc.invalidateQueries();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return (
    <AppShell>
      <PageTitle title="پشتیبان‌گیری" subtitle="پشتیبان دستی، روزانه و بازیابی" actions={<Button onClick={() => make.mutate()}>پشتیبان جدید</Button>} />
      <TableWrap>
        <thead><tr><Th>نام</Th><Th>نوع</Th><Th>زمان</Th><Th /></tr></thead>
        <tbody>
          {((list.data ?? []) as Array<Record<string, string>>).map((b) => (
            <tr key={b.id}>
              <Td>{b.name}</Td>
              <Td>{b.kind}</Td>
              <Td>{isoToJalali(String(b.created_at).slice(0, 10))}</Td>
              <Td>
                <button type="button" className="text-xs text-danger" onClick={() => restore.mutate(b.id)}>بازیابی</button>
              </Td>
            </tr>
          ))}
        </tbody>
      </TableWrap>
    </AppShell>
  );
}
