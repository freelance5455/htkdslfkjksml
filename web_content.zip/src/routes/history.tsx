import { createFileRoute } from "@tanstack/react-router";
import { HistoryPage } from "@/components/ministry/desk-pages";
import { AppShell } from "@/components/ministry/shell";

export const Route = createFileRoute("/history")({
  component: function HistoryRoute() {
    return (
      <AppShell>
        <HistoryPage />
      </AppShell>
    );
  },
});
