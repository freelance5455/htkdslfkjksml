import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/page";
import { OFFICIAL_CONTEST, SITE_ACTIVITIES } from "@/data/contests";

export const Route = createFileRoute("/contests")({
  head: () => ({ meta: [{ title: "المسابقات — لأنه الله" }] }),
  component: ContestsPage,
});

function ActivityLink({ href }: { href: string }) {
  if (href === "/quiz") return <Link to="/quiz" className="text-sm text-primary">افتح النشاط</Link>;
  if (href === "/quran") return <Link to="/quran" className="text-sm text-primary">افتح النشاط</Link>;
  if (href === "/names") return <Link to="/names" className="text-sm text-primary">افتح النشاط</Link>;
  return <Link to="/study" className="text-sm text-primary">افتح النشاط</Link>;
}

function ContestsPage() {
  return (
    <main>
      <PageIntro
        kicker="الرسمي مفصول عن التعليمي"
        title="المسابقات والأنشطة"
        lede="المسابقة التي أعلنتها الوزارة معروضة بنص إعلانها وروابطه. أنشطة هذه المنصة تدريب محلي بلا جوائز مخترعة وبلا جمع بيانات."
      />
      <section className="mx-auto grid max-w-6xl gap-6 px-4 py-8 lg:grid-cols-2">
        <article className="rounded-card border border-line bg-surface p-6">
          <p className="text-sm text-olive">مسابقة رسمية</p>
          <h2 className="mt-2 font-display text-3xl text-primary">{OFFICIAL_CONTEST.title}</h2>
          <p className="mt-2">الشعار: {OFFICIAL_CONTEST.slogan}</p>
          <p className="mt-2 text-sm text-muted">الجهة: {OFFICIAL_CONTEST.organizer}</p>
          <p className="mt-2 text-sm">أُعلنت في {OFFICIAL_CONTEST.announced} · تنتهي في {OFFICIAL_CONTEST.ends}</p>
          <h3 className="mt-4 font-medium">طريقة المشاركة كما في الإعلان</h3>
          <ol className="mt-2 list-decimal space-y-1 pe-5">
            {OFFICIAL_CONTEST.how.map((step) => <li key={step}>{step}</li>)}
          </ol>
          <h3 className="mt-4 font-medium">الجوائز المعلنة</h3>
          <ul className="mt-2 list-disc space-y-1 pe-5 text-sm leading-7">
            {OFFICIAL_CONTEST.prizes.map((prize) => <li key={prize}>{prize}</li>)}
          </ul>
          <p className="mt-3 text-sm text-muted">الفئة والشروط التفصيلية: {OFFICIAL_CONTEST.audience}</p>
          <div className="mt-4 flex flex-wrap gap-2 text-sm">
            <a className="rounded-full bg-primary px-4 py-2 text-primary-fg" href={OFFICIAL_CONTEST.formUrl} rel="noreferrer">استمارة الوزارة</a>
            <a className="rounded-full border border-line px-4 py-2" href={OFFICIAL_CONTEST.bookUrl} rel="noreferrer">ملف الأسئلة</a>
            <a className="rounded-full border border-line px-4 py-2" href={OFFICIAL_CONTEST.sourceUrl} rel="noreferrer">المنشور الأصلي</a>
          </div>
        </article>
        <article className="rounded-card border border-dashed border-line p-6">
          <p className="text-sm text-olive">أنشطة هذه المنصة · ليست رسمية</p>
          <ul className="mt-4 space-y-4">
            {SITE_ACTIVITIES.map((activity) => (
              <li key={activity.id}>
                <h3 className="font-display text-2xl text-primary">{activity.title}</h3>
                <p className="text-sm text-muted">{activity.audience}</p>
                <p className="mt-1 leading-8">{activity.detail}</p>
                <ActivityLink href={activity.href} />
              </li>
            ))}
          </ul>
        </article>
      </section>
    </main>
  );
}
