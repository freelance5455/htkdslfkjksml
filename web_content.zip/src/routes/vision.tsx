import { createFileRoute } from "@tanstack/react-router";
import { VisionView } from "@/components/planner/views/vision";

export const Route = createFileRoute("/vision")({
  component: VisionView,
});
