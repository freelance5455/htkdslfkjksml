import { Link, createFileRoute } from "@tanstack/react-router";
import { CalendarDays } from "lucide-react";
import { DayChecklist } from "@/components/day-checklist";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { toDateKey } from "@/lib/dates";

export const Route = createFileRoute("/habitos")({ component: HabitsPage });

function HabitsPage() {
  const date = toDateKey(new Date());
  return (
    <div className="animate-in fade-in duration-300">
      <PageHeader
        kicker="Hoje"
        title="Hábitos"
        subtitle="Checklist do dia. Cada data guarda o próprio registro."
        action={
          <Button asChild variant="outline" size="sm">
            <Link to="/calendario">
              <CalendarDays /> Calendário
            </Link>
          </Button>
        }
      />
      <DayChecklist date={date} />
    </div>
  );
}
