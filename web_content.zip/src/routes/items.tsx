import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { AmountInput, MoneyText } from "@/components/fields";
import { Button, Field, Input, Modal, PageTitle, TableWrap, Td, Th } from "@/components/ui";
import { bootstrap, saveItem } from "@/lib/server/books";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/items")({ component: ItemsPage });

function ItemsPage() {
  const qc = useQueryClient();
  const boot = useQuery({ queryKey: ["bootstrap"], queryFn: () => bootstrap() });
  const [open, setOpen] = useState(false);
  const items = (boot.data?.items ?? []) as Array<Record<string, unknown>>;
  return (
    <AppShell>
      <PageTitle title="کالاها" subtitle="الگوی اصلی کالا برای استفاده در فاکتور" actions={<Button onClick={() => setOpen(true)}>+ کالا</Button>} />
      <TableWrap>
        <thead>
          <tr>
            <Th>کد</Th>
            <Th>نام</Th>
            <Th>واحد</Th>
            <Th>خرید</Th>
            <Th>فروش</Th>
            <Th>بارکد</Th>
          </tr>
        </thead>
        <tbody>
          {items.map((i) => (
            <tr key={String(i.id)}>
              <Td className="tabular">{String(i.code)}</Td>
              <Td>{String(i.name)}</Td>
              <Td>{String(i.unit)}</Td>
              <Td><MoneyText value={i.purchase_price} /></Td>
              <Td><MoneyText value={i.sale_price} /></Td>
              <Td className="tabular">{String(i.barcode ?? "")}</Td>
            </tr>
          ))}
        </tbody>
      </TableWrap>
      <ItemModal
        open={open}
        onClose={() => setOpen(false)}
        onSaved={() => {
          setOpen(false);
          qc.invalidateQueries();
        }}
      />
    </AppShell>
  );
}

function ItemModal({ open, onClose, onSaved }: { open: boolean; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [barcode, setBarcode] = useState("");
  const [unit, setUnit] = useState("عدد");
  const [buy, setBuy] = useState(0);
  const [sale, setSale] = useState(0);
  return (
    <Modal open={open} onClose={onClose} title="کالای جدید">
      <form
        className="space-y-3"
        onSubmit={async (e) => {
          e.preventDefault();
          try {
            const res = await saveItem({
              data: { name, code: code || `G${Date.now().toString().slice(-4)}`, barcode, unit, purchasePrice: buy, salePrice: sale },
            });
            if (res.duplicates?.length) toast.message("احتمال کالای تکراری.");
            toast.success("کالا ذخیره شد.");
            onSaved();
          } catch (err) {
            toast.error(err instanceof Error ? err.message : "خطا");
          }
        }}
      >
        <Field label="نام"><Input required value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="کد"><Input value={code} onChange={(e) => setCode(e.target.value)} /></Field>
        <Field label="بارکد"><Input value={barcode} onChange={(e) => setBarcode(e.target.value)} /></Field>
        <Field label="واحد"><Input value={unit} onChange={(e) => setUnit(e.target.value)} /></Field>
        <Field label="قیمت خرید"><AmountInput value={buy} onChange={setBuy} /></Field>
        <Field label="قیمت فروش"><AmountInput value={sale} onChange={setSale} /></Field>
        <Button type="submit" className="w-full">ذخیره</Button>
      </form>
    </Modal>
  );
}
