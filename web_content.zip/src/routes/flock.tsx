import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { SheepCard, sortSheep } from "@/components/sheep-bits";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { FILTERS, formatInt, matchesFilter } from "@/lib/flock/logic";
import { useFlock } from "@/lib/flock/store";
import type { FlockFilter } from "@/lib/flock/types";

const ALLOWED: FlockFilter[] = [
  "all",
  "ram",
  "ewe",
  "lamb",
  "pregnant",
  "sick",
  "archive",
];

export const Route = createFileRoute("/flock")({
  validateSearch: (search: Record<string, unknown>): { f?: FlockFilter } => {
    const f = typeof search.f === "string" ? search.f : "";
    if (ALLOWED.includes(f as FlockFilter) && f !== "all") {
      return { f: f as FlockFilter };
    }
    return {};
  },
  component: FlockPage,
});

function FlockPage() {
  const { f = "all" } = Route.useSearch();
  const navigate = Route.useNavigate();
  const sheep = useFlock((s) => s.sheep);
  const breeding = useFlock((s) => s.breeding);
  const [q, setQ] = useState("");
  const query = q.trim();
  const list = sortSheep(
    sheep.filter((s) => {
      if (!matchesFilter(s, breeding, f)) return false;
      if (!query) return true;
      const blob = `${s.tag} ${s.name} ${s.breed} ${s.pen}`;
      return blob.includes(query);
    }),
  );

  return (
    <AppShell
      title="القطيع"
      action={
        <Link to="/sheep/new" className="text-sm font-medium">
          إضافة
        </Link>
      }
    >
      <div className="flex flex-col gap-4">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="رقم، اسم، سلالة، أو حظيرة"
            aria-label="بحث"
          />
          <div className="flex gap-2 overflow-x-auto pb-1">
            {FILTERS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => navigate({ search: { f: item.id } })}
                className={cn(
                  "h-9 shrink-0 rounded-full px-3 text-sm",
                  f === item.id
                    ? "bg-primary text-primary-foreground"
                    : "border border-border text-muted-foreground",
                )}
              >
                {item.label}
              </button>
            ))}
          </div>
          <p className="text-sm text-muted-foreground tabular-nums">
            {formatInt(list.length)} رأس
          </p>
          {sheep.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              القطيع فارغ. أضف أول رأس من زر الإضافة.
            </p>
          ) : list.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا نتائج.</p>
          ) : (
            <div className="flex flex-col gap-2">
              {list.map((s) => (
                <SheepCard key={s.id} sheep={s} breeding={breeding} />
              ))}
            </div>
          )}
        </div>
    </AppShell>
  );
}
