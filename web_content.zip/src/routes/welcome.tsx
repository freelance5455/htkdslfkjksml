import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { LanguageToggle, ScreenSkeleton } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Field, TextInput } from "@/components/ui/field";
import { useEdu } from "@/components/edu-provider";
import { t } from "@/content/copy";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useLocale } from "@/lib/locale";

export const Route = createFileRoute("/welcome")({ component: WelcomePage });

const namePattern = /^[\p{L}\p{M}\s'.-]{2,80}$/u;

function WelcomePage() {
  const { user, isPending } = useCurrentUserState();
  const { profile, loading, saveStudent } = useEdu();
  const locale = useLocale((state) => state.locale);
  const setLocale = useLocale((state) => state.setLocale);
  const navigate = useNavigate();
  const [fullName, setFullName] = useState(user?.displayName ?? "");
  const [grade, setGrade] = useState(6);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const raw = sessionStorage.getItem("henok-pending-profile");
    if (!raw) return;
    try {
      const pending = JSON.parse(raw) as { fullName?: string; grade?: number };
      if (pending.fullName) setFullName(pending.fullName);
      if (pending.grade) setGrade(pending.grade);
    } catch {
      sessionStorage.removeItem("henok-pending-profile");
    }
  }, []);

  if (isPending || (user && loading)) return <ScreenSkeleton label={t(locale, "loading")} />;
  if (!user) return <Navigate to="/login" />;
  if (profile) return <Navigate to="/" />;

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!namePattern.test(fullName.trim())) {
      setError(t(locale, "nameInvalid"));
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await saveStudent({ fullName: fullName.trim(), grade, locale });
      sessionStorage.removeItem("henok-pending-profile");
      await navigate({ to: "/" });
    } catch {
      setError(t(locale, "saveFailed"));
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col px-4 py-6">
      <div className="mb-8 flex items-center justify-between gap-3">
        <LanguageToggle locale={locale} onChange={setLocale} />
        <UserButton />
      </div>
      <h1 className="text-2xl font-semibold">{t(locale, "welcomeTitle")}</h1>
      <p className="mt-2 text-muted">{t(locale, "welcomeLede")}</p>
      <form className="mt-6 space-y-4" onSubmit={(event) => void onSubmit(event)}>
        <Field label={t(locale, "fullName")}>
          <TextInput value={fullName} onChange={(event) => setFullName(event.target.value)} autoComplete="name" required />
        </Field>
        <div>
          <p className="mb-1.5 text-sm font-semibold">{t(locale, "grade")}</p>
          <div className="grid grid-cols-5 gap-2">
            {[4, 5, 6, 7, 8].map((value) => (
              <button
                key={value}
                type="button"
                aria-pressed={grade === value}
                onClick={() => setGrade(value)}
                className={
                  grade === value
                    ? "min-h-11 rounded-md bg-teal font-semibold text-card"
                    : "min-h-11 rounded-md border border-line bg-card font-semibold"
                }
              >
                {value}
              </button>
            ))}
          </div>
        </div>
        {error ? <p className="text-sm font-semibold text-danger">{error}</p> : null}
        <Button type="submit" size="block" disabled={busy}>
          {busy ? t(locale, "working") : t(locale, "startLearning")}
        </Button>
      </form>
    </main>
  );
}
