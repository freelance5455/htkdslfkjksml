import { createFileRoute } from "@tanstack/react-router";
import { Play } from "@/components/roleforge/play";
import { useHydrated } from "@/lib/roleforge/store";

export const Route = createFileRoute("/partida/$id")({
  component: PartidaRoute,
});

function PartidaRoute() {
  const { id } = Route.useParams();
  const hydrated = useHydrated();
  if (!hydrated) {
    return (
      <main className="flex min-h-dvh items-center px-5">
        <p className="font-serif text-3xl">
          Role<span className="text-ember">forge</span>
        </p>
      </main>
    );
  }
  return <Play id={id} />;
}
