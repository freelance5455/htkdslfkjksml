import { createFileRoute, Link } from "@tanstack/react-router";
import { BackButton } from "@/components/back-button";
import { AppShell, TopBar } from "@/components/layout/app-shell";
import { ADHKAR_GROUPS, adhkarLists } from "@/content/catalog";
import { toArabicDigits } from "@/lib/utils";

export const Route = createFileRoute("/adhkar/")({ component: AdhkarHome });

function AdhkarHome() {
  return (
    <AppShell>
      <TopBar title="الأذكار والأدعية" back={<BackButton href="/" />} />
      <div className="space-y-6 px-4 py-4">
        {ADHKAR_GROUPS.map((g) => (
          <section key={g.id}>
            <h2 className="mb-2 text-sm font-semibold text-muted-foreground">{g.title}</h2>
            <ul className="grid gap-2">
              {g.ids.map((id) => {
                const list = adhkarLists.find((l) => l.id === id);
                if (!list) return null;
                return (
                  <li key={id}>
                    <Link
                      to="/adhkar/$listId"
                      params={{ listId: id }}
                      className="flex items-center justify-between rounded-2xl bg-card px-4 py-3.5 shadow-[var(--shadow-border)]"
                    >
                      <span>
                        <span className="block font-medium">{list.title}</span>
                        <span className="text-xs text-muted-foreground">
                          {toArabicDigits(list.items.length)} نص
                        </span>
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </section>
        ))}
        <p className="px-1 pb-4 text-[11px] leading-5 text-muted-foreground">
          المصدر: حصن المسلم من أذكار الكتاب والسنة، لسعيد بن علي بن وهف القحطاني، مع أدعية قرآنية بنص المصحف.
        </p>
      </div>
    </AppShell>
  );
}
