import { createFileRoute } from "@tanstack/react-router";
import { Heart, RotateCcw, Share2, Volume2 } from "lucide-react";
import { toast } from "sonner";
import { BackButton } from "@/components/back-button";
import { AppShell, TopBar } from "@/components/layout/app-shell";
import { getList } from "@/content/catalog";
import { audioEngine } from "@/lib/audio";
import { shareText } from "@/lib/share";
import { useAppStore } from "@/lib/store";
import { cn, toArabicDigits } from "@/lib/utils";

export const Route = createFileRoute("/adhkar/$listId")({ component: DhikrListPage });

function DhikrListPage() {
  const { listId } = Route.useParams();
  const list = getList(listId);
  const progress = useAppStore((s) => s.dhikrProgress);
  const bump = useAppStore((s) => s.bumpDhikr);
  const resetList = useAppStore((s) => s.resetListDhikr);
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);
  const favorites = useAppStore((s) => s.favorites);
  const scale = useAppStore((s) => s.settings.fontScale);

  if (!list) {
    return (
      <AppShell>
        <TopBar title="غير موجود" back={<BackButton href="/adhkar" />} />
      </AppShell>
    );
  }

  return (
    <AppShell>
      <TopBar
        title={list.title}
        back={<BackButton href="/adhkar" />}
        action={
          <button
            type="button"
            className="tap-lg text-muted-foreground"
            aria-label="إعادة العداد"
            onClick={() => resetList(list.items.map((i) => i.id))}
          >
            <RotateCcw className="size-4" />
          </button>
        }
      />
      <p className="px-5 pt-3 text-xs leading-5 text-muted-foreground">{list.blurb}</p>
      <ul className="space-y-3 px-4 py-4 pb-8">
        {list.items.map((item) => {
          const current = progress[item.id] ?? 0;
          const done = current >= item.count && item.count > 0;
          const fav = favorites.some((f) => f.id === item.id);
          return (
            <li id={item.id} key={item.id} className="rounded-[22px] bg-card p-4 shadow-[var(--shadow-border)]">
              {item.title && item.title !== list.title && item.book === "القرآن الكريم" ? (
                <p className="mb-2 text-xs text-sage">{item.title}</p>
              ) : null}
              <p className="quran-text leading-loose text-ink" style={{ fontSize: `${0.95 * scale + 0.7}rem` }}>
                {item.text}
              </p>
              <p className="mt-3 text-[11px] leading-5 text-muted-foreground">{item.source}</p>
              <div className="mt-3 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => bump(item.id, item.count)}
                  className={cn(
                    "flex h-12 flex-1 items-center justify-center rounded-2xl text-sm font-medium",
                    done ? "bg-sage text-accent-foreground" : "bg-accent text-accent-foreground",
                  )}
                >
                  {done ? "تم" : `${toArabicDigits(current)} / ${toArabicDigits(item.count)}`}
                </button>
                <IconBtn
                  label="استماع"
                  onClick={() => {
                    const ok = audioEngine.speak(item.text, list.title);
                    if (!ok) toast("قراءة الجهاز غير متاحة على هذا المتصفح");
                  }}
                >
                  <Volume2 className="size-4" />
                </IconBtn>
                <IconBtn
                  label="مفضلة"
                  onClick={() =>
                    toggleFavorite({
                      id: item.id,
                      kind: list.kind === "dua" ? "dua" : "dhikr",
                      title: list.title,
                      text: item.text,
                      href: `/adhkar/${list.id}#${item.id}`,
                      meta: item.source,
                    })
                  }
                >
                  <Heart className={cn("size-4", fav && "fill-current")} />
                </IconBtn>
                <IconBtn label="مشاركة" onClick={() => void shareText(list.title, item.text)}>
                  <Share2 className="size-4" />
                </IconBtn>
              </div>
            </li>
          );
        })}
      </ul>
    </AppShell>
  );
}

function IconBtn({
  children,
  onClick,
  label,
}: {
  children: React.ReactNode;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="tap-lg flex size-12 items-center justify-center rounded-2xl bg-surface text-foreground"
    >
      {children}
    </button>
  );
}
