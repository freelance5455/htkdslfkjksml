import { createFileRoute, Link } from "@tanstack/react-router";
import { PreviewBoard } from "@/components/storyboard/preview-board";
import { useProjects } from "@/components/storyboard/use-projects";
import { downloadScenesZip } from "@/lib/storyboard/download";
import { useStory } from "@/lib/storyboard/store";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/storyboards/$id/preview")({
  component: PreviewPage,
});

function PreviewPage() {
  const { id } = Route.useParams();
  const ready = useProjects();
  const project = useStory((state) => state.projects.find((item) => item.id === id));

  if (!ready) return <p className="text-sm text-muted">Memuat storyboard…</p>;
  if (!project || project.scenes.length === 0) {
    return (
      <div className="grid gap-3">
        <p>Belum ada scene untuk ditampilkan.</p>
        <Link to="/storyboards/$id" params={{ id }} className="text-sm font-medium underline">
          Kembali
        </Link>
      </div>
    );
  }
  const hasImages = project.scenes.some((scene) => scene.imageDataUrl);
  return (
    <div className="grid gap-4">
      <PreviewBoard project={project} />
      <Button
        variant="secondary"
        className="w-full sm:w-fit"
        disabled={!hasImages}
        onClick={() => void downloadScenesZip(project.scenes, "storyboard.zip")}
      >
        Download all
      </Button>
    </div>
  );
}
