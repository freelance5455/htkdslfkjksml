import { createFileRoute, Link } from "@tanstack/react-router";
import { Editor } from "@/components/storyboard/editor";
import { useProjects } from "@/components/storyboard/use-projects";
import { useStory } from "@/lib/storyboard/store";

export const Route = createFileRoute("/storyboards/$id/")({
  component: ProjectPage,
});

function ProjectPage() {
  const { id } = Route.useParams();
  const ready = useProjects();
  const project = useStory((state) => state.projects.find((item) => item.id === id));

  if (!ready) return <p className="text-sm text-muted">Memuat storyboard…</p>;
  if (!project) {
    return (
      <div className="grid gap-3">
        <p>Storyboard ini tidak ada.</p>
        <Link to="/storyboards" className="text-sm font-medium underline">
          My storyboards
        </Link>
      </div>
    );
  }
  return <Editor project={project} />;
}
