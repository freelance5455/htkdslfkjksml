import { useEffect } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { format } from "date-fns";
import { useProjects } from "@/components/storyboard/use-projects";
import { useStory, visibleProjects } from "@/lib/storyboard/store";

export const Route = createFileRoute("/storyboards/")({
  component: Library,
});

function Library() {
  const ready = useProjects();
  const projects = useStory((state) => state.projects);
  const pruneEmpty = useStory((state) => state.pruneEmpty);
  const remove = useStory((state) => state.remove);

  useEffect(() => {
    if (ready) pruneEmpty();
  }, [ready, pruneEmpty]);

  const list = visibleProjects(projects);

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-widest text-muted uppercase">My storyboards</p>
          <h1 className="font-display text-3xl font-medium tracking-tight">Storyboard tersimpan</h1>
        </div>
        <Link
          to="/create"
          className="inline-flex min-h-11 items-center rounded-md bg-accent px-4 text-sm font-medium text-accent-fg"
        >
          Create storyboard
        </Link>
      </div>
      <p className="max-w-xl text-sm text-muted">Tersimpan di browser ini. Buka lagi untuk regenerate scene tanpa upload ulang.</p>
      {!ready ? <p className="text-sm text-muted">Memuat…</p> : null}
      {ready && list.length === 0 ? <p className="text-sm text-muted">Belum ada storyboard.</p> : null}
      <ul className="grid gap-3 sm:grid-cols-2">
        {list.map((project) => (
          <li key={project.id} className="grid gap-3 rounded-xl border border-line bg-surface p-4">
            <Link to="/storyboards/$id" params={{ id: project.id }} className="grid gap-3">
              <span className="frame-4-5 overflow-hidden rounded-md bg-bg">
                {project.scenes.find((scene) => scene.imageDataUrl)?.imageDataUrl ? (
                  <img
                    src={project.scenes.find((scene) => scene.imageDataUrl)?.imageDataUrl ?? ""}
                    alt=""
                    className="h-full w-full object-contain"
                  />
                ) : project.refs[0] ? (
                  <img src={project.refs[0].dataUrl} alt="" className="h-full w-full object-contain" />
                ) : null}
              </span>
              <span className="grid gap-1">
                <span className="font-medium">{project.name}</span>
                <span className="text-sm text-muted">
                  {project.category} · {project.campaign} · {format(project.updatedAt, "d MMM yyyy, HH:mm")}
                </span>
              </span>
            </Link>
            <button type="button" className="text-left text-sm text-muted underline" onClick={() => remove(project.id)}>
              Hapus
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
