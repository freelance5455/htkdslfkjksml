import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useDownloads } from "@/lib/download-store";
import { formatBytes } from "@/lib/utils";
import { useState } from "react";

export const Route = createFileRoute("/downloads")({ component: DownloadsPage });

function DownloadsPage() {
  const items = useDownloads((s) => s.items);
  const enqueue = useDownloads((s) => s.enqueue);
  const pause = useDownloads((s) => s.pause);
  const resume = useDownloads((s) => s.resume);
  const cancel = useDownloads((s) => s.cancel);
  const remove = useDownloads((s) => s.remove);
  const [url, setUrl] = useState("");

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl font-semibold">Downloads</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Direct, publicly reachable media files only. No DRM stripping, no paywall bypass, no
          YouTube/Hotstar/etc. extractors. If a page URL is pasted, the download is refused.
        </p>
      </header>

      <form
        className="flex flex-col gap-2 sm:flex-row"
        onSubmit={(e) => {
          e.preventDefault();
          void enqueue(url).then((id) => {
            if (id) setUrl("");
            else toast.error("Enter a valid URL.");
          });
        }}
      >
        <Input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://example.com/video.mp4"
          aria-label="Direct media URL"
        />
        <Button type="submit">Queue</Button>
      </form>

      {items.length === 0 ? (
        <div className="rounded-xl bg-surface px-6 py-16 text-center shadow-[var(--shadow-border)]">
          <p className="font-display text-xl font-semibold">Queue is empty</p>
          <p className="mt-2 text-sm text-muted">Paste a link that points at an actual media file.</p>
        </div>
      ) : (
        <ul className="space-y-3">
          {items.map((d) => {
            const pct = d.total > 0 ? Math.round((d.received / d.total) * 100) : d.status === "done" ? 100 : 0;
            return (
              <li key={d.id} className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{d.name}</p>
                    <p className="truncate text-xs text-muted">{d.url}</p>
                  </div>
                  <span className="text-xs capitalize text-muted">{d.status}</span>
                </div>
                <Progress value={pct} className="mt-3" />
                <p className="mt-1 text-xs tabular-nums text-muted">
                  {formatBytes(d.received)}
                  {d.total ? ` / ${formatBytes(d.total)}` : ""}
                </p>
                {d.error ? <p className="mt-2 text-sm text-destructive">{d.error}</p> : null}
                <div className="mt-3 flex flex-wrap gap-2">
                  {d.status === "running" ? (
                    <Button size="sm" variant="outline" onClick={() => pause(d.id)}>
                      Pause
                    </Button>
                  ) : null}
                  {d.status === "paused" || d.status === "error" ? (
                    <Button size="sm" variant="outline" onClick={() => resume(d.id)}>
                      Retry
                    </Button>
                  ) : null}
                  {d.status === "running" || d.status === "queued" || d.status === "paused" ? (
                    <Button size="sm" variant="outline" onClick={() => cancel(d.id)}>
                      Cancel
                    </Button>
                  ) : null}
                  <Button size="sm" variant="ghost" onClick={() => remove(d.id)}>
                    Remove
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
