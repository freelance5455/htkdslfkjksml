import { createFileRoute } from "@tanstack/react-router";
import { ToolsPage } from "@/features/tools";

export const Route = createFileRoute("/tools")({
  head: () => ({ meta: [{ title: "Tools · FrameForge BOOYAH" }] }),
  component: ToolsPage,
});
