import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Card, Field, Page, fieldClass } from "@/components/ui";
import { formatClock, formatDuration, formatHijri } from "@/lib/arabic";
import { CITIES, METHODS, SALAH, computeTimes, nextSalah, placeOf, salahName, type DayTimes } from "@/lib/prayer";
import { usePrefs, type PrayerKey } from "@/lib/prefs";

export const Route = createFileRoute("/prayer")({ component: PrayerPage });

function PrayerPage() {
  const prefs = usePrefs();
  const [now, setNow] = useState<Date | null>(null);
  const [gpsMsg, setGpsMsg] = useState("");
  useEffect(() => {
    setNow(new Date());
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);
  const place = placeOf(prefs);
  const times: DayTimes | null = now
    ? computeTimes(place.lat, place.lng, now, prefs.calcMethod, prefs.madhab, prefs.adjustments)
    : null;
  const tomorrowFajr = useMemo(() => {
    if (!now) return null;
    const t = new Date(now);
    t.setDate(now.getDate() + 1);
    return computeTimes(place.lat, place.lng, t, prefs.calcMethod, prefs.madhab, prefs.adjustments).fajr;
  }, [now, place.lat, place.lng, prefs.calcMethod, prefs.madhab, prefs.adjustments]);
  const next = times && now && tomorrowFajr ? nextSalah(times, now, tomorrowFajr) : null;

  const monthRows = useMemo(() => {
    if (!now) return [];
    const days = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    return Array.from({ length: days }, (_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth(), i + 1);
      const t = computeTimes(place.lat, place.lng, d, prefs.calcMethod, prefs.madhab, prefs.adjustments);
      return { d, t };
    });
  }, [now, place.lat, place.lng, prefs.calcMethod, prefs.madhab, prefs.adjustments]);

  return (
    <Page title="مواقيت الصلاة" subtitle={`الحساب محلي على جهازك حسب ${place.label}. الطريقة قابلة للتغيير، ويمكن تعديل الدقائق يدويًا.`}>
      <Card className="mb-3">
        <p className="text-sm text-gold">القادمة · {next ? salahName(next.key) : "…"}</p>
        <p className="text-3xl font-bold">{next && now ? formatDuration(next.at.getTime() - now.getTime()) : "--:--"}</p>
        <p className="text-sm text-muted">{now ? formatHijri(now) : ""}</p>
      </Card>
      <ul className="mb-4 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-card">
        {times && (
          <>
            <Row name="الفجر" time={times.fajr} />
            <Row name="الشروق" time={times.sunrise} />
            <Row name="الظهر" time={times.dhuhr} />
            <Row name="العصر" time={times.asr} />
            <Row name="المغرب" time={times.maghrib} />
            <Row name="العشاء" time={times.isha} />
          </>
        )}
      </ul>
      <div className="grid gap-3">
        <Field label="المدينة">
          <select
            className={fieldClass}
            value={prefs.coords ? "gps" : prefs.cityId}
            onChange={(e) => {
              if (e.target.value === "gps") return;
              prefs.patch({ cityId: e.target.value, coords: null });
            }}
          >
            {prefs.coords && <option value="gps">موقعي: {prefs.coords.label}</option>}
            {CITIES.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>
        <button
          type="button"
          className="min-h-11 rounded-xl border border-line bg-card text-sm font-semibold"
          onClick={() => {
            if (!navigator.geolocation) {
              setGpsMsg("المتصفح لا يتيح الموقع.");
              return;
            }
            navigator.geolocation.getCurrentPosition(
              (pos) => {
                prefs.patch({
                  coords: {
                    lat: pos.coords.latitude,
                    lng: pos.coords.longitude,
                    label: "موقعي",
                  },
                });
                setGpsMsg("تم تحديد موقعك ويبقى على جهازك.");
              },
              () => setGpsMsg("لم يُسمح بالموقع. اختر مدينة."),
            );
          }}
        >
          استخدام موقعي
        </button>
        {gpsMsg && <p className="text-sm text-muted">{gpsMsg}</p>}
        <Field label="طريقة الحساب">
          <select className={fieldClass} value={prefs.calcMethod} onChange={(e) => prefs.patch({ calcMethod: e.target.value })}>
            {METHODS.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="المذهب في العصر">
          <select className={fieldClass} value={prefs.madhab} onChange={(e) => prefs.patch({ madhab: e.target.value as "shafi" | "hanafi" })}>
            <option value="shafi">جمهور (ظل المثل)</option>
            <option value="hanafi">حنفي (ظل المثلين)</option>
          </select>
        </Field>
      </div>
      <Card className="mt-4">
        <p className="font-bold">تعديل يدوي بالدقائق</p>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {(["fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha"] as const).map((k) => (
            <label key={k} className="text-xs">
              {salahName(k)}
              <input
                className={fieldClass}
                type="number"
                value={prefs.adjustments[k]}
                onChange={(e) =>
                  prefs.patch({ adjustments: { ...prefs.adjustments, [k]: Number(e.target.value) || 0 } })
                }
              />
            </label>
          ))}
        </div>
      </Card>
      <Card className="mt-4">
        <p className="font-bold">تنبيه كل صلاة</p>
        <p className="mt-1 text-xs text-muted">التنبيه والأذان يعملان ما دام التطبيق مفتوحًا أو في الخلفية القريبة. المتصفح لا يضمن الأذان إذا أُغلق تمامًا.</p>
        <label className="mt-2 flex min-h-11 items-center gap-2 text-sm">
          <input type="checkbox" checked={prefs.notifEnabled} onChange={(e) => prefs.patch({ notifEnabled: e.target.checked })} />
          تفعيل التنبيهات
        </label>
        {prefs.notifEnabled && (
          <button
            type="button"
            className="min-h-11 text-sm font-semibold text-emerald"
            onClick={() => void Notification.requestPermission()}
          >
            السماح بإشعارات المتصفح
          </button>
        )}
        <label className="mt-2 block text-sm">
          دقائق قبل الصلاة
          <input className={fieldClass} type="number" min={0} max={60} value={prefs.preMinutes} onChange={(e) => prefs.patch({ preMinutes: Number(e.target.value) || 0 })} />
        </label>
        <ul className="mt-2 space-y-2">
          {SALAH.map((s) => (
            <li key={s.key} className="flex items-center justify-between gap-2 text-sm">
              <span>{s.name}</span>
              <label className="flex items-center gap-1">
                <input
                  type="checkbox"
                  checked={prefs.perPrayer[s.key as PrayerKey].notify}
                  onChange={(e) =>
                    prefs.patch({
                      perPrayer: { ...prefs.perPrayer, [s.key]: { ...prefs.perPrayer[s.key as PrayerKey], notify: e.target.checked } },
                    })
                  }
                />
                تنبيه
              </label>
              <label className="flex items-center gap-1">
                <input
                  type="checkbox"
                  checked={prefs.perPrayer[s.key as PrayerKey].adhan}
                  onChange={(e) =>
                    prefs.patch({
                      perPrayer: { ...prefs.perPrayer, [s.key]: { ...prefs.perPrayer[s.key as PrayerKey], adhan: e.target.checked } },
                    })
                  }
                />
                أذان
              </label>
            </li>
          ))}
        </ul>
      </Card>
      <Card className="mt-4">
        <p className="font-bold">تقويم الشهر الميلادي الحالي</p>
        <div className="mt-2 max-h-80 overflow-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-muted">
                <th className="py-1 text-start">اليوم</th>
                <th>فجر</th>
                <th>ظهر</th>
                <th>عصر</th>
                <th>مغرب</th>
                <th>عشاء</th>
              </tr>
            </thead>
            <tbody>
              {monthRows.map((row) => (
                <tr key={row.d.toISOString()} className="border-t border-line">
                  <td className="py-1">{row.d.getDate()}</td>
                  <td className="text-center">{formatClock(row.t.fajr)}</td>
                  <td className="text-center">{formatClock(row.t.dhuhr)}</td>
                  <td className="text-center">{formatClock(row.t.asr)}</td>
                  <td className="text-center">{formatClock(row.t.maghrib)}</td>
                  <td className="text-center">{formatClock(row.t.isha)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </Page>
  );
}

function Row({ name, time }: { name: string; time: Date }) {
  return (
    <li className="flex min-h-12 items-center justify-between px-4">
      <span className="font-semibold">{name}</span>
      <span className="tabular-nums">{formatClock(time)}</span>
    </li>
  );
}
