import { createFileRoute } from "@tanstack/react-router";
import { Forge } from "@/components/roleforge/forge";

export const Route = createFileRoute("/nueva")({ component: Forge });
