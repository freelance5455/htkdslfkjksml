import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ItText } from "@/components/it-text";
import { RoadSign } from "@/components/road-sign";
import { CHAPTERS } from "@/data/curriculum";
import { QUESTIONS, type Question } from "@/data/quiz";
import { signById } from "@/data/signs";
import { useStudy } from "@/lib/study-store";

export const Route = createFileRoute("/esame")({
  validateSearch: (search: Record<string, unknown>) => {
    const n = Number(search.ch);
    return { ch: Number.isInteger(n) && n > 0 ? n : undefined };
  },
  component: Esame,
});

type Mode = "exam" | "practice" | "wrong";

function Esame() {
  const { ch } = Route.useSearch();
  const wrongIds = useStudy((s) => s.wrong);
  const rememberWrong = useStudy((s) => s.rememberWrong);
  const forgetWrong = useStudy((s) => s.forgetWrong);
  const recordExam = useStudy((s) => s.recordExam);
  const [mode, setMode] = useState<Mode>("exam");
  const [phase, setPhase] = useState<"hub" | "run" | "result">("hub");
  const [items, setItems] = useState<Question[]>([]);
  const [index, setIndex] = useState(0);
  const [picks, setPicks] = useState<Record<string, boolean | undefined>>({});
  const [show, setShow] = useState(false);
  const [left, setLeft] = useState(20 * 60);
  const finished = useRef(false);

  useEffect(() => {
    if (ch) start("practice", ch);
    // مرة واحدة عند فتح رابط الفصل
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ch]);

  useEffect(() => {
    if (phase !== "run" || mode !== "exam") return;
    const id = window.setInterval(() => {
      setLeft((s) => {
        if (s <= 1) {
          window.clearInterval(id);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [phase, mode]);

  useEffect(() => {
    if (phase === "run" && mode === "exam" && left === 0) finish();
  }, [left, phase, mode]);

  const current = items[index];
  const correctCount = items.filter((q) => picks[q.id] === q.ok).length;

  function start(next: Mode, chapter?: number) {
    let pool = QUESTIONS;
    if (next === "practice" && chapter) pool = QUESTIONS.filter((q) => q.ch === chapter);
    if (next === "wrong") pool = QUESTIONS.filter((q) => wrongIds.includes(q.id));
    const taken = next === "exam" ? shuffle(pool).slice(0, 30) : shuffle(pool);
    finished.current = false;
    setMode(next);
    setItems(taken);
    setIndex(0);
    setPicks({});
    setShow(false);
    setLeft(20 * 60);
    setPhase(taken.length ? "run" : "hub");
  }

  function choose(value: boolean) {
    if (!current) return;
    setPicks((p) => ({ ...p, [current.id]: value }));
    if (mode !== "exam") setShow(true);
  }

  function finish() {
    if (finished.current) return;
    finished.current = true;
    const wrong = items.filter((q) => picks[q.id] !== q.ok).map((q) => q.id);
    const rightIds = items.filter((q) => picks[q.id] === q.ok).map((q) => q.id);
    rememberWrong(wrong);
    rightIds.forEach((id) => forgetWrong(id));
    if (mode === "exam") recordExam(items.filter((q) => picks[q.id] === q.ok).length);
    setPhase("result");
  }

  const mm = String(Math.floor(left / 60)).padStart(2, "0");
  const ss = String(left % 60).padStart(2, "0");

  if (phase === "hub") {
    return (
      <div className="space-y-5">
        <header>
          <p className="text-sm text-primary">Quiz vero o falso</p>
          <h1 className="text-3xl font-semibold">الامتحان</h1>
          <p className="mt-2 max-w-2xl text-muted">
            الامتحان الرسمي 30 عبارة صح أو خطأ في 20 دقيقة، والنجاح بأقل من 4 أخطاء. الأسئلة هنا بأسلوب الامتحان ومكتوبة على القانون، وليست نسخة حرفية من قائمة الوزارة.
          </p>
        </header>
        <div className="grid gap-3 sm:grid-cols-2">
          <button type="button" onClick={() => start("exam")} className="rounded-2xl bg-primary p-4 text-right text-primary-fg">
            <span className="block text-2xl font-semibold">محاكاة</span>
            <span className="mt-1 block text-sm">30 سؤالًا · 20 دقيقة · بلا شرح حتى النهاية</span>
          </button>
          <button
            type="button"
            onClick={() => start("wrong")}
            className="rounded-2xl border border-line bg-surface p-4 text-right"
          >
            <span className="block text-2xl font-semibold">أخطائي</span>
            <span className="mt-1 block text-sm text-muted">{wrongIds.length} سؤالًا محفوظًا من المحاولات</span>
          </button>
        </div>
        <section>
          <h2 className="text-lg font-semibold">تدريب فوري حسب الفصل</h2>
          <ul className="mt-2 grid gap-2 sm:grid-cols-2">
            {CHAPTERS.map((c) => (
              <li key={c.n}>
                <button
                  type="button"
                  onClick={() => start("practice", c.n)}
                  className="w-full rounded-xl border border-line bg-surface px-3 py-3 text-right"
                >
                  <span className="text-sm text-muted">{c.n}</span>
                  <span className="mt-1 block font-semibold">{c.titleAr}</span>
                </button>
              </li>
            ))}
            <li>
              <button
                type="button"
                onClick={() => start("practice")}
                className="w-full rounded-xl border border-line bg-soft px-3 py-3 text-right font-semibold text-primary"
              >
                كل الأسئلة بشرح فوري
              </button>
            </li>
          </ul>
        </section>
      </div>
    );
  }

  if (phase === "result") {
    const passed = mode === "exam" ? correctCount >= 27 : correctCount === items.length;
    const misses = items.filter((q) => picks[q.id] !== q.ok);
    return (
      <div className="space-y-4">
        <p className="text-sm text-primary">{mode === "exam" ? "Simulazione" : "Allenamento"}</p>
        <h1 className="text-3xl font-semibold">{passed && mode === "exam" ? "ناجح" : mode === "exam" ? "لم تنجح" : "نتيجة التدريب"}</h1>
        <p className="text-4xl font-semibold text-primary">
          {correctCount} <span className="text-xl text-muted">/ {items.length}</span>
        </p>
        <p className="text-muted">
          {mode === "exam"
            ? passed
              ? "ثلاثة أخطاء أو أقل. هذا مستوى النجاح في الامتحان الرسمي."
              : "النجاح يحتاج 27 إجابة صحيحة على الأقل. راجع الشرح تحت."
            : "الإجابات الخاطئة انضافت إلى خانة أخطائي."}
        </p>
        <ul className="space-y-3">
          {misses.map((q) => (
            <li key={q.id} className="rounded-2xl border border-line bg-surface p-3">
              <ItText text={q.it} />
              <p className="mt-2 text-sm text-muted">{q.ar}</p>
              <p className="mt-2 text-sm">
                الصحيح: <strong>{q.ok ? "صح" : "خطأ"}</strong>
                {picks[q.id] === undefined ? " · تركتها فارغة" : ""}
              </p>
              <p className="mt-2 rounded-xl bg-soft px-3 py-2 text-sm leading-relaxed">{q.whyAr}</p>
            </li>
          ))}
        </ul>
        {misses.length === 0 ? <p className="rounded-2xl bg-soft px-3 py-3">لا أخطاء في هذه الجولة.</p> : null}
        <button type="button" onClick={() => setPhase("hub")} className="min-h-11 rounded-full bg-ink px-4 text-surface">
          العودة لقائمة الامتحان
        </button>
      </div>
    );
  }

  if (!current) return null;
  const picked = picks[current.id];
  const sign = current.signId ? signById(current.signId) : undefined;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-muted">
          {index + 1} / {items.length}
        </p>
        {mode === "exam" ? (
          <p className={`font-semibold ${left < 60 ? "text-accent" : "text-ink"}`}>
            {mm}:{ss}
          </p>
        ) : (
          <p className="text-sm text-muted">شرح بعد كل إجابة</p>
        )}
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-line">
        <div className="h-full bg-primary" style={{ width: `${((index + 1) / items.length) * 100}%` }} />
      </div>
      {current.signId ? (
        <div className="rounded-2xl border border-line bg-surface p-3">
          <RoadSign id={current.signId} className="mx-auto h-36 w-36" />
          {sign ? <p className="mt-1 text-center text-sm text-muted">{sign.nameAr}</p> : null}
        </div>
      ) : null}
      <ItText text={current.it} className="text-xl font-semibold" />
      <p className="rounded-xl bg-soft px-3 py-3 leading-relaxed">{current.ar}</p>
      <div className="grid grid-cols-2 gap-2">
        <Answer on={picked === true} tone="good" label="Vero · صح" onClick={() => choose(true)} />
        <Answer on={picked === false} tone="bad" label="Falso · خطأ" onClick={() => choose(false)} />
      </div>
      {show && picked !== undefined ? (
        <div className={`rounded-2xl px-3 py-3 ${picked === current.ok ? "bg-soft" : "bg-warn text-warn-ink"}`}>
          <p className="font-semibold">{picked === current.ok ? "إجابة صحيحة" : "إجابة خاطئة"}</p>
          <p className="mt-1 text-sm">الصحيح: {current.ok ? "صح / Vero" : "خطأ / Falso"}</p>
          <p className="mt-2 text-sm leading-relaxed">{current.whyAr}</p>
        </div>
      ) : null}
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          className="min-h-11 rounded-full border border-line px-4"
          onClick={() => {
            setShow(false);
            setIndex((n) => Math.max(0, n - 1));
          }}
          disabled={index === 0}
        >
          السابق
        </button>
        {index < items.length - 1 ? (
          <button
            type="button"
            className="min-h-11 rounded-full bg-primary px-4 text-primary-fg"
            onClick={() => {
              setShow(false);
              setIndex((n) => n + 1);
            }}
          >
            التالي
          </button>
        ) : (
          <button type="button" className="min-h-11 rounded-full bg-ink px-4 text-surface" onClick={finish}>
            إنهاء وتصحيح
          </button>
        )}
        <button type="button" className="min-h-11 rounded-full px-4 text-muted" onClick={() => setPhase("hub")}>
          خروج
        </button>
      </div>
      {mode === "exam" ? <Dots items={items} picks={picks} index={index} jump={(n) => { setIndex(n); setShow(false); }} /> : null}
    </div>
  );
}

function Answer({ label, on, onClick, tone }: { label: string; on: boolean; onClick: () => void; tone: "good" | "bad" }) {
  const active = on ? (tone === "good" ? "bg-primary text-primary-fg" : "bg-accent text-accent-fg") : "border border-line bg-surface";
  return (
    <button type="button" onClick={onClick} className={`min-h-14 rounded-2xl text-lg font-semibold ${active}`}>
      {label}
    </button>
  );
}

function Dots({
  items,
  picks,
  index,
  jump,
}: {
  items: Question[];
  picks: Record<string, boolean | undefined>;
  index: number;
  jump: (n: number) => void;
}) {
  return (
    <div className="flex flex-wrap gap-1">
      {items.map((q, n) => {
        const filled = picks[q.id] !== undefined;
        return (
          <button
            key={q.id}
            type="button"
            onClick={() => jump(n)}
            className={`h-9 w-9 rounded-full text-xs ${n === index ? "bg-ink text-surface" : filled ? "bg-soft text-primary" : "border border-line"}`}
          >
            {n + 1}
          </button>
        );
      })}
    </div>
  );
}

function shuffle<T>(list: T[]) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = a[i] as T;
    a[i] = a[j] as T;
    a[j] = tmp;
  }
  return a;
}
