import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { getCreation } from "@/data/creation";
import { getVerse } from "@/data/verses";
import { arNum } from "@/lib/utils";

export const Route = createFileRoute("/creation/$slug")({
  loader: ({ params }) => {
    const topic = getCreation(params.slug);
    if (!topic) throw notFound();
    return topic;
  },
  head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `${loaderData.title} — التأمل` : "تأمل" }] }),
  component: CreationDetail,
});

function CreationDetail() {
  const topic = Route.useLoaderData();
  const verse = getVerse(topic.ayahId);

  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <Link to="/creation" className="text-sm text-olive">كل المشاهد</Link>
      <img src={topic.image} alt={topic.alt} className="mt-4 aspect-video w-full rounded-card object-cover" width={1200} height={675} />
      <h1 className="mt-5 font-display text-4xl text-primary">{topic.title}</h1>
      <section className="mt-6">
        <h2 className="font-display text-3xl text-primary">المعلومة العلمية</h2>
        <p className="mt-3 leading-8">{topic.science}</p>
        <a className="mt-3 inline-block text-sm text-primary" href={topic.sourceUrl} rel="noreferrer">{topic.source}</a>
      </section>
      {verse ? (
        <section className="mt-6 rounded-card border border-line p-5">
          <h2 className="font-display text-3xl text-primary">آية ذات صلة</h2>
          <p className="ayah mt-3 text-primary">{verse.text}</p>
          <p className="mt-2 text-sm text-muted">{verse.surah} · {arNum(verse.ayah)}</p>
          <Link to="/quran/$id" params={{ id: verse.id }} className="mt-3 inline-block text-sm text-primary">التدبر</Link>
        </section>
      ) : null}
      <section className="mt-6">
        <h2 className="font-display text-3xl text-primary">تأمل إيماني</h2>
        <p className="mt-2 text-sm text-olive">ليس نتيجة علمية ولا تفسيرًا قطعيًا للآية.</p>
        <p className="mt-3 leading-8">{topic.reflection}</p>
      </section>
      <section className="mt-6 rounded-card bg-soft p-5">
        <h2 className="font-display text-3xl text-primary">سؤال</h2>
        <p className="mt-3 leading-8">{topic.question}</p>
        <h2 className="mt-5 font-display text-3xl text-primary">نشاط آمن</h2>
        <p className="mt-3 leading-8">{topic.activity}</p>
      </section>
    </main>
  );
}
