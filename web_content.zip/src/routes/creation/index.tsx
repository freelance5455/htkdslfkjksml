import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro } from "@/components/page";
import { CREATION } from "@/data/creation";

export const Route = createFileRoute("/creation/")({
  head: () => ({ meta: [{ title: "التأمل في الخلق — لأنه الله" }] }),
  component: CreationPage,
});

function CreationPage() {
  return (
    <main>
      <PageIntro
        kicker="علم ثم إيمان"
        title="التأمل في خلق الله"
        lede="صور لمخلوقات ومشاهد طبيعية. لا صورة منها تمثيل للخالق. المعلومة العلمية مفصولة عن التأمل الإيماني، ولا تُستخدم أرقامًا زائفة."
      />
      <section className="mx-auto grid max-w-6xl gap-4 px-4 py-8 md:grid-cols-2">
        {CREATION.map((topic) => (
          <Link key={topic.id} to="/creation/$slug" params={{ slug: topic.id }} className="overflow-hidden rounded-card border border-line bg-surface">
            <img src={topic.image} alt={topic.alt} className="h-52 w-full object-cover" loading="lazy" width={800} height={450} />
            <div className="p-5">
              <h2 className="font-display text-3xl text-primary">{topic.title}</h2>
              <p className="mt-2 line-clamp-3 text-sm leading-7 text-muted">{topic.science}</p>
            </div>
          </Link>
        ))}
      </section>
    </main>
  );
}
