import { createFileRoute } from "@tanstack/react-router";
import { DoceApp } from "@/components/doce/DoceApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <DoceApp />;
}
