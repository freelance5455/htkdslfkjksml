import { createFileRoute } from "@tanstack/react-router";
import { RadixCounter } from "@/components/radix-counter";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [
      { title: "进制计数器" },
      {
        name: "description",
        content: "自定义多个对象和进制。每个对象单独加减，数字按设定的进制书写。",
      },
    ],
  }),
});

function Home() {
  return <RadixCounter />;
}
