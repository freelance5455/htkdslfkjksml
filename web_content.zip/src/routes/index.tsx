import { createFileRoute } from "@tanstack/react-router";
import { NeonCalc } from "@/components/calc/NeonCalc";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <NeonCalc />;
}
