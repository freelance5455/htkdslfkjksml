import { createFileRoute } from "@tanstack/react-router";
import { AgoraApp } from "@/components/agora-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AgoraApp />;
}
