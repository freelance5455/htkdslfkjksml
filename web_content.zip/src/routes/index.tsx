import { createFileRoute } from "@tanstack/react-router";
import { Aether } from "@/components/aether/Aether";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Aether />;
}
