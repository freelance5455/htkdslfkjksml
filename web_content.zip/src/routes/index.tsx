import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Compass, Download, FolderOpen, Play } from "lucide-react";
import { AddMediaButton } from "@/components/add-media";
import { MediaRail } from "@/components/media-card";
import { Button } from "@/components/ui/button";
import { PUBLIC_STREAMS } from "@/lib/constants";
import { continueWatching, itemsForTab, useLibrary } from "@/lib/library-store";
import { usePlayer } from "@/lib/player-store";
import { APP_TAGLINE } from "@/lib/constants";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const items = useLibrary((s) => s.items);
  const ready = useLibrary((s) => s.ready);
  const addUrl = useLibrary((s) => s.addUrl);
  const open = usePlayer((s) => s.open);
  const navigate = useNavigate();
  const watching = continueWatching(items);
  const recent = itemsForTab(items, "recent").slice(0, 12);
  const videos = items.filter((i) => i.kind === "video").slice(0, 12);
  const music = itemsForTab(items, "music").slice(0, 12);
  const favs = itemsForTab(items, "favourites").slice(0, 12);
  const empty = items.length === 0;

  return (
    <div className="space-y-10">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-primary">UPLAY.IND</p>
          <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight md:text-5xl">Your library. Your pace.</h1>
          <p className="mt-3 max-w-xl text-muted">{APP_TAGLINE}</p>
        </div>
        <div className="hidden md:block">
          <AddMediaButton />
        </div>
      </header>

      {empty ? (
        <div className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] sm:p-10">
          <h2 className="font-display text-2xl font-semibold">
            {ready ? "Nothing here yet" : "Opening library"}
          </h2>
          <p className="mt-2 max-w-lg text-sm text-muted">
            {ready
              ? "Add files from this device, or play a direct media URL. Scanning stays on-device — nothing is uploaded."
              : "Reading the on-device index…"}
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <AddMediaButton />
            <Button variant="outline" asChild>
              <Link to="/browser">Open browser</Link>
            </Button>
          </div>
          <div className="mt-8">
            <h3 className="text-sm font-medium text-muted">Try a public-domain stream</h3>
            <ul className="mt-3 grid gap-2 sm:grid-cols-3">
              {PUBLIC_STREAMS.map((s) => (
                <li key={s.id}>
                  <button
                    type="button"
                    className="flex w-full items-center gap-3 rounded-lg bg-elevated p-3 text-left shadow-[var(--shadow-border)] transition-colors hover:bg-secondary"
                    onClick={() => {
                      const item = addUrl(s.name, s.url, s.kind);
                      open(item);
                      void navigate({ to: "/player/$id", params: { id: item.id } });
                    }}
                  >
                    <span className="flex size-10 items-center justify-center rounded-md bg-primary/15 text-primary">
                      <Play className="size-4 fill-current" />
                    </span>
                    <span>
                      <span className="block text-sm font-medium">{s.name}</span>
                      <span className="block text-xs text-muted">{s.note}</span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) : (
        <>
          <MediaRail title="Continue watching" items={watching} />
          <MediaRail title="Recently played" items={recent} />
          <MediaRail title="Videos" items={videos} />
          <MediaRail title="Music" items={music} />
          <MediaRail title="Favourites" items={favs} />
        </>
      )}

      <section className="grid gap-3 sm:grid-cols-3">
        <Quick to="/library" icon={FolderOpen} title="Library" copy="Videos, movies, music, folders" />
        <Quick to="/downloads" icon={Download} title="Downloads" copy="Direct media URLs only" />
        <Quick to="/browser" icon={Compass} title="Browser" copy="Look up pages, then play direct links" />
      </section>
    </div>
  );
}

function Quick({
  to,
  icon: Icon,
  title,
  copy,
}: {
  to: "/library" | "/downloads" | "/browser";
  icon: typeof FolderOpen;
  title: string;
  copy: string;
}) {
  return (
    <Link
      to={to}
      className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] transition-colors hover:bg-elevated"
    >
      <Icon className="size-5 text-primary" />
      <p className="mt-3 font-medium">{title}</p>
      <p className="text-sm text-muted">{copy}</p>
    </Link>
  );
}
