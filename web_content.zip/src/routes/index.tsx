import { Link, createFileRoute } from "@tanstack/react-router";
import { AppFrame, PageTitle } from "@/components/shell";
import { SubjectGlyph } from "@/components/subject-icon";
import { useEdu } from "@/components/edu-provider";
import { Button } from "@/components/ui/button";
import { t } from "@/content/copy";
import { chaptersForGrade, lessonItemId, subjects } from "@/content/catalog";
import { fill, tx, useLocale } from "@/lib/locale";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <AppFrame>
      <HomeBody />
    </AppFrame>
  );
}

function HomeBody() {
  const locale = useLocale((state) => state.locale);
  const { profile, progress } = useEdu();
  if (!profile) return null;
  const grade = profile.grade;

  let next: { subjectId: string; chapterId: string; title: string; subject: string } | null = null;
  for (const subject of subjects) {
    for (const chapter of chaptersForGrade(subject, grade)) {
      const done = progress.some(
        (row) => row.kind === "lesson" && row.itemId === lessonItemId(subject.id, chapter.id) && row.completed,
      );
      if (!done) {
        next = {
          subjectId: subject.id,
          chapterId: chapter.id,
          title: tx(locale, chapter.title),
          subject: tx(locale, subject.title),
        };
        break;
      }
    }
    if (next) break;
  }

  const examId = grade >= 7 ? "grade-8" : grade === 6 ? "grade-6" : null;

  return (
    <div>
      <PageTitle
        title={fill(t(locale, "hello"), { name: profile.fullName })}
        lede={fill(t(locale, "gradeLabel"), { grade })}
      />
      {next ? (
        <section className="rounded-2xl border border-line bg-card p-4">
          <p className="text-sm font-semibold text-teal-deep">{t(locale, "continueLearning")}</p>
          <h2 className="mt-1 text-xl font-semibold">{next.title}</h2>
          <p className="mt-1 text-sm text-muted">{next.subject}</p>
          <Button asChild className="mt-4" size="block">
            <Link to="/learn/$subjectId/$chapterId" params={{ subjectId: next.subjectId, chapterId: next.chapterId }}>
              {t(locale, "open")}
            </Link>
          </Button>
        </section>
      ) : (
        <section className="rounded-2xl border border-line bg-foam p-4">
          <h2 className="text-xl font-semibold">{t(locale, "strong")}</h2>
          <p className="mt-1 text-sm text-muted">{t(locale, "progressLede")}</p>
        </section>
      )}

      {examId ? (
        <Link
          to="/exams/$examId"
          params={{ examId }}
          className="mt-4 flex min-h-11 items-center justify-between rounded-2xl bg-teal px-4 py-3 text-card"
        >
          <span className="font-semibold">{examId === "grade-6" ? t(locale, "forYourGrade") : t(locale, "forYourGrade")}</span>
          <span className="text-sm font-semibold">{t(locale, "startExam")}</span>
        </Link>
      ) : null}

      <h2 className="mb-3 mt-8 text-sm font-semibold text-muted">{t(locale, "subjects")}</h2>
      <ul className="grid grid-cols-2 gap-3">
        {subjects.map((subject) => {
          const chapters = chaptersForGrade(subject, grade);
          const done = chapters.filter((chapter) =>
            progress.some(
              (row) => row.kind === "lesson" && row.itemId === lessonItemId(subject.id, chapter.id) && row.completed,
            ),
          ).length;
          return (
            <li key={subject.id}>
              <Link
                to="/learn/$subjectId"
                params={{ subjectId: subject.id }}
                className="flex h-full flex-col rounded-2xl border border-line bg-card p-4"
              >
                <SubjectGlyph name={subject.icon} className="size-5 text-teal" />
                <span className="mt-3 font-semibold">{tx(locale, subject.title)}</span>
                <span className="mt-1 text-sm tabular-nums text-muted">
                  {done}/{chapters.length}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
      {profile.role === "admin" ? (
        <Link to="/admin" className="mt-6 inline-flex min-h-11 items-center text-sm font-semibold text-teal-deep">
          {t(locale, "adminTitle")}
        </Link>
      ) : null}
    </div>
  );
}
