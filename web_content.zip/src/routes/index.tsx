import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { BookOpen, Clock3, Compass, Heart, Library, MoonStar } from "lucide-react";
import { Card } from "@/components/ui";
import { ADHKAR } from "@/data/adhkar";
import { NAWAWI } from "@/data/nawawi";
import { SUNAN } from "@/data/sunnah";
import { formatClock, formatDuration, formatGregorian, formatHijri } from "@/lib/arabic";
import { computeTimes, nextSalah, placeOf, salahName } from "@/lib/prayer";
import { usePrefs } from "@/lib/prefs";
import { loadQuran, type Ayah, type Surah } from "@/lib/quran";

export const Route = createFileRoute("/")({ component: Home });

const AYAH_REFS = [
  [2, 255],
  [2, 186],
  [3, 8],
  [13, 28],
  [94, 5],
  [2, 152],
  [65, 2],
  [33, 56],
  [112, 1],
  [1, 2],
];

function Home() {
  const prefs = usePrefs();
  const [now, setNow] = useState<Date | null>(null);
  const [ayah, setAyah] = useState<{ surah: Surah; ayah: Ayah } | null>(null);

  useEffect(() => {
    setNow(new Date());
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    void loadQuran().then((q) => {
      const day = Math.floor(Date.now() / 86_400_000);
      const [s, a] = AYAH_REFS[day % AYAH_REFS.length];
      const surah = q.surahs[s - 1];
      const verse = surah.ayahs.find((x) => x.a === a) || surah.ayahs[0];
      setAyah({ surah, ayah: verse });
    });
  }, []);

  const place = placeOf(prefs);
  let next: { key: string; at: Date } | null = null;
  let clock = "";
  if (now) {
    const times = computeTimes(place.lat, place.lng, now, prefs.calcMethod, prefs.madhab, prefs.adjustments);
    const tomorrow = new Date(now);
    tomorrow.setDate(now.getDate() + 1);
    const t2 = computeTimes(place.lat, place.lng, tomorrow, prefs.calcMethod, prefs.madhab, prefs.adjustments);
    next = nextSalah(times, now, t2.fajr);
    clock = formatClock(now);
  }
  const day = Math.floor(Date.now() / 86_400_000);
  const hadith = NAWAWI[day % NAWAWI.length];
  const dhikr = ADHKAR[day % ADHKAR.length];
  const sunnah = SUNAN[day % SUNAN.length];

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 pt-5">
      <section className="overflow-hidden rounded-3xl bg-emerald-deep text-btn-fg">
        <div className="space-y-2 px-5 py-6">
          <p className="text-sm text-gold">بسم الله الرحمن الرحيم</p>
          <h1 className="text-3xl font-bold">توبة</h1>
          <p className="max-w-md text-sm leading-relaxed text-gold-soft">طريقك إلى التوبة والعبادة والعلم والطمأنينة.</p>
          <p className="text-sm">{now ? `${formatHijri(now)} · ${formatGregorian(now)}` : "جاري ضبط التاريخ"}</p>
          <p className="text-xs opacity-80">المواقيت الآن حسب: {place.label}</p>
        </div>
      </section>

      <Card>
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-xs font-semibold text-gold">الصلاة القادمة</p>
            <p className="text-2xl font-bold">{next ? salahName(next.key) : "…"}</p>
            <p className="text-sm text-muted">{next && now ? `بعد ${formatDuration(next.at.getTime() - now.getTime())}` : ""}</p>
          </div>
          <div className="text-end">
            <p className="font-quran text-3xl text-emerald">{clock || "--:--"}</p>
            <Link to="/prayer" className="text-sm font-semibold text-emerald">
              المواقيت
            </Link>
          </div>
        </div>
      </Card>

      <Card>
        <p className="text-xs font-semibold text-gold">آية اليوم</p>
        {ayah ? (
          <>
            <p className="quran-text mt-2 text-ink">{ayah.ayah.t}</p>
            <p className="mt-2 text-sm text-muted">
              {ayah.surah.ar} · {ayah.ayah.a}
            </p>
            <Link to="/quran/$surah" params={{ surah: String(ayah.surah.n) }} search={{ ayah: ayah.ayah.a }} className="mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-emerald">
              فتح في المصحف
            </Link>
          </>
        ) : (
          <p className="mt-2 text-sm text-muted">يُحمّل نص الآية من المصحف المحفوظ…</p>
        )}
      </Card>

      <Card>
        <p className="text-xs font-semibold text-gold">حديث اليوم · الأربعون النووية</p>
        <p className="mt-2 text-sm leading-relaxed">{hadith.text.slice(0, 280)}{hadith.text.length > 280 ? "…" : ""}</p>
        <Link to="/hadith" className="mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-emerald">
          متن النووي
        </Link>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2">
        <Card>
          <p className="text-xs font-semibold text-gold">ذكر اليوم</p>
          <p className="mt-1 font-bold">{dhikr.title}</p>
          <p className="text-xs text-muted">{dhikr.source}</p>
          <Link to="/adhkar" className="mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-emerald">الأذكار</Link>
        </Card>
        <Card>
          <p className="text-xs font-semibold text-gold">سنة اليوم</p>
          <p className="mt-1 font-bold">{sunnah.title}</p>
          <p className="text-xs text-muted">{sunnah.grade} · {sunnah.source}</p>
          <Link to="/sunnah" className="mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-emerald">السنن</Link>
        </Card>
      </div>

      {prefs.lastRead && (
        <Card>
          <p className="text-xs font-semibold text-gold">متابعة القرآن</p>
          <p className="mt-1">آخر موضع: سورة {prefs.lastRead.surah} آية {prefs.lastRead.ayah} · صفحة {prefs.lastRead.page}</p>
          <Link
            to="/quran/$surah"
            params={{ surah: String(prefs.lastRead.surah) }}
            search={{ ayah: prefs.lastRead.ayah }}
            className="mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-emerald"
          >
            أكمل القراءة
          </Link>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-3 pb-4 sm:grid-cols-3">
        {[
          ["/quran", "المصحف", BookOpen],
          ["/reciters", "التلاوات", Library],
          ["/adhan", "الأذان", MoonStar],
          ["/tasbeeh", "السبحة", Heart],
          ["/prophets", "الأنبياء", Compass],
          ["/prayer", "المواقيت", Clock3],
        ].map(([to, label, Icon]) => (
          <Link key={String(to)} to={to as "/quran"} className="flex min-h-20 flex-col justify-between rounded-2xl border border-line bg-card p-3">
            <Icon className="size-5 text-gold" />
            <span className="font-semibold">{label as string}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
