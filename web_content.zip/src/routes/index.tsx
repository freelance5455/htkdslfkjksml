import { createFileRoute } from "@tanstack/react-router";
import { SignInGate } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Landing, ShellSkeleton } from "@/components/paperly/landing";
import { Studio } from "@/components/paperly/studio";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { isPending } = useCurrentUserState();
  if (isPending) return <ShellSkeleton />;
  return (
    <SignInGate fallback={<Landing />}>
      <Studio />
    </SignInGate>
  );
}
