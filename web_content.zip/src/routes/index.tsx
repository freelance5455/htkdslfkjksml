import { createFileRoute } from "@tanstack/react-router";
import { DersProgrami } from "@/components/ders-programi";

export const Route = createFileRoute("/")({ component: DersProgrami });
