import { createFileRoute, Link } from "@tanstack/react-router";
import { NameMotif } from "@/components/motif";
import { BEHAVIORS, DAILY_MESSAGES, DAILY_STEPS } from "@/data/behavior";
import { NEWS } from "@/data/campaign";
import { CREATION } from "@/data/creation";
import { NAMES } from "@/data/names";
import { VERSES } from "@/data/verses";
import { useProgress } from "@/lib/progress";
import { arNum, dayIndex, syriaDateKey } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "لأنّه الله، نحبّه ونعظّمه" }] }),
  component: Home,
});

function Home() {
  const verse = VERSES[dayIndex(VERSES.length)] ?? VERSES[0];
  const name = NAMES[dayIndex(NAMES.length)] ?? NAMES[0];
  const message = DAILY_MESSAGES[dayIndex(DAILY_MESSAGES.length)] ?? DAILY_MESSAGES[0];
  const step = DAILY_STEPS[dayIndex(DAILY_STEPS.length)] ?? DAILY_STEPS[0];
  const scene = CREATION[dayIndex(CREATION.length)] ?? CREATION[0];
  const behavior = BEHAVIORS[dayIndex(BEHAVIORS.length)] ?? BEHAVIORS[0];
  const day = syriaDateKey();
  const done = useProgress((state) => Boolean(state.steps[day]));
  const toggleStep = useProgress((state) => state.toggleStep);
  const readCount = useProgress((state) => state.read.length);

  return (
    <main>
      <section className="relative min-h-[78vh] overflow-hidden">
        <img
          src="/images/hero.jpg"
          alt="فجر هادئ فوق جبال مكسوة بالشجر، مشهد للتأمل في الخلق لا تمثيل للخالق"
          className="absolute inset-0 h-full w-full object-cover"
          width={1600}
          height={900}
        />
        <div className="hero-shade absolute inset-0" />
        <div className="relative mx-auto flex min-h-[78vh] max-w-6xl items-end px-4 py-12 md:py-16">
          <div className="rise max-w-3xl rounded-card border border-line bg-surface/92 p-6 md:p-10">
            <p className="text-sm font-medium text-olive">حملة دعوية للمعرفة والتعظيم</p>
            <h1 className="mt-2 font-display text-5xl leading-tight text-primary md:text-6xl">لأنّه الله، نحبّه ونعظّمه</h1>
            <p className="mt-4 font-display text-2xl leading-relaxed text-ink">كلما ازددنا معرفة بربنا، ازددنا له محبة وتعظيمًا.</p>
            <p className="mt-4 max-w-2xl leading-8 text-muted">
              منصة عربية للتعلم الهادئ: أسماء الله الحسنى، وآيات التدبر، وأحاديث صحيحة، وتأمل في الخلق، وسلوك يومي. التعريف بالحملة من مصادرها العلنية، من غير ادعاء أنها الموقع الرسمي للوزارة.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link to="/names" className="rounded-full bg-primary px-5 py-3 text-primary-fg">تعرّف إلى أسماء الله الحسنى</Link>
              <Link to="/quran" className="rounded-full border border-line bg-canvas px-5 py-3">ابدأ رحلة التدبر</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-6 lg:grid-cols-[1.4fr_0.8fr]">
          <article className="rounded-card border border-line bg-surface p-6 md:p-8">
            <p className="text-sm text-olive">آية اليوم · {verse?.surah} {verse ? arNum(verse.ayah) : ""}</p>
            <p className="ayah mt-4 text-primary">{verse?.text}</p>
            <p className="mt-4 text-sm leading-7 text-muted">{verse?.tadabbur}</p>
            {verse ? (
              <Link to="/quran/$id" params={{ id: verse.id }} className="mt-5 inline-block text-sm text-primary">التفسير والتطبيق</Link>
            ) : null}
          </article>
          <article className="rounded-card border border-line bg-soft p-6">
            <p className="text-sm text-olive">رسالة اليوم</p>
            <h2 className="mt-2 font-display text-3xl text-primary">{message?.title}</h2>
            <p className="mt-3 leading-8">{message?.text}</p>
            <p className="mt-4 text-sm text-muted">المستند: {message?.daleel}</p>
            <div className="mt-6 border-t border-line pt-4">
              <p className="text-sm text-olive">خطوة اليوم</p>
              <p className="mt-2 leading-7">{step}</p>
              <button type="button" onClick={() => toggleStep(day)} className="mt-4 rounded-full bg-primary px-4 py-2 text-sm text-primary-fg" aria-pressed={done}>
                {done ? "أُنجزت على هذا الجهاز" : "وضع علامة الإتمام"}
              </button>
              <p className="mt-2 text-xs text-muted">العلامة تُحفظ في متصفحك فقط، وليست تقييمًا لإيمانك.</p>
            </div>
          </article>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-4">
        <div className="mb-5 flex items-end justify-between gap-3">
          <h2 className="font-display text-4xl text-primary">أقسام مختارة</h2>
          <Link to="/progress" className="text-sm text-olive">ماذا تعلمت؟ {arNum(readCount)}</Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Link to="/names" className="rounded-card border border-line bg-surface p-5"><h3 className="font-display text-2xl text-primary">أسماء الله الحسنى</h3><p className="mt-2 text-sm leading-7 text-muted">تسعة وتسعون اسمًا مع بيان الثبوت والمعنى والأثر.</p></Link>
          <Link to="/quran" className="rounded-card border border-line bg-surface p-5"><h3 className="font-display text-2xl text-primary">آية وتدبر</h3><p className="mt-2 text-sm leading-7 text-muted">نص مضبوط، وخلاصة تفسير، وتدبر مفصول عنه.</p></Link>
          <Link to="/hadith" className="rounded-card border border-line bg-surface p-5"><h3 className="font-display text-2xl text-primary">حديث نبوي</h3><p className="mt-2 text-sm leading-7 text-muted">نص، ودرجة، ومصدر، وفائدة عملية.</p></Link>
          <Link to="/names/$slug" params={{ slug: name?.slug ?? "al-rahman" }} className="rounded-card border border-line bg-surface p-5"><h3 className="font-display text-2xl text-primary">اسم من الأسماء</h3><p className="mt-2 text-sm leading-7 text-muted">{name?.ar}: {name?.mean}</p></Link>
          <Link to="/creation" className="rounded-card border border-line bg-surface p-5"><h3 className="font-display text-2xl text-primary">من عجائب الخلق</h3><p className="mt-2 text-sm leading-7 text-muted">معلومة علمية مفصولة عن التأمل الإيماني.</p></Link>
          <Link to="/media" className="rounded-card border border-line bg-surface p-5"><h3 className="font-display text-2xl text-primary">محاضرة إيمانية</h3><p className="mt-2 text-sm leading-7 text-muted">ما وُثق من ندوات الحملة، وبيان ما لم يُضف.</p></Link>
          <Link to="/library" className="rounded-card border border-line bg-surface p-5"><h3 className="font-display text-2xl text-primary">كتاب يستحق القراءة</h3><p className="mt-2 text-sm leading-7 text-muted">تعريفات كتب موثوقة بلا تنزيل وهمي.</p></Link>
          <Link to="/behavior" className="rounded-card border border-line bg-surface p-5"><h3 className="font-display text-2xl text-primary">عمل صالح لهذا اليوم</h3><p className="mt-2 text-sm leading-7 text-muted">{behavior?.title}</p></Link>
          <Link to="/campaign" className="rounded-card border border-line bg-surface p-5 sm:col-span-2 lg:col-span-4"><h3 className="font-display text-2xl text-primary">أحدث أخبار الحملة</h3><p className="mt-2 text-sm leading-7 text-muted">{NEWS[0]?.title} — من المصادر العلنية، لا من أحداث مختلقة.</p></Link>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-4 py-10 lg:grid-cols-2">
        {name ? (
          <Link to="/names/$slug" params={{ slug: name.slug }} className="rounded-card border border-line bg-surface p-5">
            <p className="text-sm text-olive">اسم اليوم</p>
            <NameMotif seed={name.n} label={name.ar} className="mt-4 h-28 w-full" />
            <h3 className="mt-3 font-display text-4xl text-primary">{name.ar}</h3>
            <p className="mt-2 text-sm leading-7 text-muted">{name.mean}</p>
          </Link>
        ) : null}
        {scene ? (
          <Link to="/creation/$slug" params={{ slug: scene.id }} className="overflow-hidden rounded-card border border-line bg-surface">
            <img src={scene.image} alt={scene.alt} className="h-48 w-full object-cover" loading="lazy" width={800} height={450} />
            <div className="p-5">
              <p className="text-sm text-olive">تأمل اليوم</p>
              <h3 className="mt-1 font-display text-3xl text-primary">{scene.title}</h3>
              <p className="mt-2 text-sm leading-7 text-muted">{scene.reflection}</p>
            </div>
          </Link>
        ) : null}
      </section>
  </main>
  );
}
