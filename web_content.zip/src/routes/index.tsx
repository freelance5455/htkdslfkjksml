import { createFileRoute } from "@tanstack/react-router";
import { LumenShell } from "@/components/lumen/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <LumenShell />;
}
