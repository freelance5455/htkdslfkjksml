import { createFileRoute } from "@tanstack/react-router";
import { DriveView } from "@/components/DriveView";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <DriveView />;
}
