import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="fixed inset-0 bg-bg text-fg">
      <p className="px-5 py-6 text-sm text-muted">Memuat Kris Soundboard…</p>
      <iframe
        title="Kris Soundboard"
        src="/board.html"
        className="absolute inset-0 h-full w-full border-0 bg-bg"
      />
    </main>
  );
}
