import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { mountFront } from "@/game/main";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const game = mountFront(el);
    return () => game.destroy();
  }, []);
  return (
    <div ref={ref} className="front-root">
      <p className="boot">Точки фронта</p>
    </div>
  );
}
