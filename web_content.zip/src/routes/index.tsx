import { createFileRoute } from "@tanstack/react-router";
import { Fortpanzer } from "@/game/Fortpanzer";

export const Route = createFileRoute("/")({ component: Fortpanzer });
