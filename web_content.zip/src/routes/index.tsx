import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ComponentType } from "react";
import { Overlay } from "@/components/solar/overlay";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [Scene, setScene] = useState<ComponentType | null>(null);

  useEffect(() => {
    let live = true;
    void import("@/components/solar/scene").then((mod) => {
      if (live) setScene(() => mod.SolarScene);
    });
    return () => {
      live = false;
    };
  }, []);

  return (
    <main className="shell">
      <div className="viewport">
        {Scene ? <Scene /> : <p className="booting">A preparar o observatório…</p>}
      </div>
      <Overlay />
    </main>
  );
}
