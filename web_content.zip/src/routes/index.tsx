import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { LabShell } from "@/components/lab/LabShell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready) {
    return (
      <main className="grid h-dvh place-items-center bg-bg text-muted">
        <p className="font-mono text-sm">Apertura del banco…</p>
      </main>
    );
  }
  return <LabShell />;
}
