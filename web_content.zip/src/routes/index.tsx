import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { HOME_KINDS, POST_KINDS } from "@/lib/cutegirls/model";
import { FeedView } from "@/components/feed-view";
import { Shell } from "@/components/shell";
import { useMeId } from "@/components/use-me-id";

export const Route = createFileRoute("/")({ component: HomePage });

function HomePage() {
  return (
    <Shell>
      <HomeFeed />
    </Shell>
  );
}

function HomeFeed() {
  const meId = useMeId();
  const [kind, setKind] = useState<string>("all");
  const [scope, setScope] = useState<"all" | "following">("all");
  if (!meId) return null;
  return (
    <div className="mx-auto w-full max-w-xl space-y-4">
      <header>
        <p className="text-xs tracking-widest text-rose">الساحة</p>
        <h1 className="font-display text-4xl">ما يُقال للجميع</h1>
      </header>
      <div className="flex gap-2">
        {(["all", "following"] as const).map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => setScope(item)}
            className={`min-h-11 rounded-full px-4 text-sm ${scope === item ? "bg-ink text-paper" : "bg-paper text-mute shadow-card"}`}
          >
            {item === "all" ? "الجميع" : "أتابع"}
          </button>
        ))}
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1">
        <FilterChip active={kind === "all"} onClick={() => setKind("all")} label="الكل" />
        {HOME_KINDS.map((item) => (
          <FilterChip key={item} active={kind === item} onClick={() => setKind(item)} label={POST_KINDS[item].label} />
        ))}
      </div>
      <FeedView
        meId={meId}
        query={{ surface: "home", kind: kind === "all" ? undefined : kind, scope }}
        variant="feed"
        emptyTitle="الساحة هادئة"
        emptyBody="كن أول من ينشر فضفضة أو مسابقة أو معلومة أو نشرة."
      />
    </div>
  );
}

function FilterChip({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`min-h-11 shrink-0 rounded-full px-4 text-sm ${active ? "bg-rose text-paper" : "bg-paper text-ink shadow-card"}`}
    >
      {label}
    </button>
  );
}
