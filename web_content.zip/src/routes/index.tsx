import { Link } from "@tanstack/react-router";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight, Check } from "lucide-react";
import { CONSTELLATIONS, PLACES, STARS } from "@/data/catalog";
import { LESSONS } from "@/data/lessons";
import { bodiesAt, compass, formatCivil, formatLat, lstHours, skyInstant, toAltAz, twilight } from "@/lib/astro";
import { useVespera } from "@/lib/store";
import { useNow } from "@/lib/use-now";
import { btnGhost, btnGold } from "@/components/ui";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const done = useVespera((s) => s.done);
  const quizBest = useVespera((s) => s.quizBest);
  const next = LESSONS.find((l) => !done.includes(l.id)) ?? LESSONS[0];

  return (
    <div>
      <div className="grid items-end gap-10 lg:grid-cols-[1.35fr_0.75fr]">
        <div>
          <p className="text-xs uppercase tracking-widest text-gold">Naked eye · six lessons</p>
          <h1 className="mt-3 max-w-xl text-5xl leading-[1.05] text-fg md:text-6xl">Learn the night sky by watching it move.</h1>
          <p className="mt-4 max-w-xl text-lg text-muted">
            A horizon chart with real stars and planets, three labs, and a short course. No telescope, and no myth standing in for an explanation.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/sky" search={{}} className={btnGold}>
              Open the sky
            </Link>
            <Link to="/lessons/$id" params={{ id: next.id }} className={btnGhost}>
              {done.length === 0 ? "Start the course" : done.length === LESSONS.length ? "Review the course" : "Continue"}
            </Link>
          </div>
        </div>
        <Tonight />
      </div>

      <div className="mt-14 flex items-baseline justify-between gap-4">
        <h2 className="text-2xl text-fg">The path</h2>
        <p className="text-sm text-faint tabular-nums">
          {done.length} of {LESSONS.length}
          {quizBest != null ? ` · quiz ${quizBest}/10` : ""}
        </p>
      </div>
      <ol className="mt-2 border-b border-line">
        {LESSONS.map((lesson, i) => {
          const complete = done.includes(lesson.id);
          return (
            <li key={lesson.id} className="border-t border-line">
              <Link
                to="/lessons/$id"
                params={{ id: lesson.id }}
                className="group flex items-baseline gap-4 py-5 sm:gap-6"
              >
                <span className="w-8 font-display text-xl text-gold tabular-nums">{String(i + 1).padStart(2, "0")}</span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-2xl text-fg group-hover:text-gold">{lesson.title}</span>
                  <span className="mt-1 block text-sm text-muted">{lesson.lede}</span>
                </span>
                <span className="hidden shrink-0 text-xs uppercase tracking-widest text-faint sm:inline">{lesson.minutes} min</span>
                {complete ? (
                  <Check className="size-5 shrink-0 text-gold" aria-label="Done" />
                ) : (
                  <ArrowUpRight className="size-5 shrink-0 text-faint transition-colors group-hover:text-gold" aria-hidden />
                )}
              </Link>
            </li>
          );
        })}
      </ol>
      <p className="mt-8 max-w-xl text-sm text-faint">
        The chart defaults to 40°N and a longitude guessed from your clock. If Polaris isn't where the lesson says, change the city — the angle is the lesson.
      </p>
    </div>
  );
}

function Tonight() {
  const now = useNow();
  const lat = useVespera((s) => s.lat);
  const lon = useVespera((s) => s.lon);
  const custom = useVespera((s) => s.custom);
  const placeId = useVespera((s) => s.placeId);
  const ready = useVespera((s) => s.ready);

  if (!now || !ready) {
    return (
      <aside className="rounded-2xl border border-line bg-surface p-5">
        <p className="text-xs uppercase tracking-widest text-gold">Right now</p>
        <p className="mt-3 text-sm text-muted">Matching the chart to your clock.</p>
      </aside>
    );
  }

  const when = skyInstant(lon, custom, now);
  const lst = lstHours(when, lon);
  const sun = bodiesAt(when)[0];
  const sunAlt = toAltAz(sun.ra, sun.dec, lat, lst).alt;
  const note = twilight(sunAlt);
  const up = STARS.map((s) => ({ ...s, ...toAltAz(s.ra, s.dec, lat, lst) }))
    .filter((s) => s.alt > 20 && s.mag < 1.8)
    .sort((a, b) => b.alt - a.alt)
    .slice(0, 3);

  const cons = new Map<string, number>();
  for (const s of STARS) {
    const alt = toAltAz(s.ra, s.dec, lat, lst).alt;
    if (alt > 25) cons.set(s.con, Math.max(cons.get(s.con) ?? 0, alt));
  }
  const figures = [...cons.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([id]) => CONSTELLATIONS[id]?.name)
    .filter(Boolean);

  const place =
    placeId === "guess"
      ? `${formatLat(lat)} · longitude from your clock`
      : placeId === "custom"
        ? formatLat(lat)
        : (PLACES.find((p) => p.id === placeId)?.name ?? formatLat(lat));

  return (
    <aside className="rounded-2xl border border-line bg-surface p-5">
      <p className="text-xs uppercase tracking-widest text-gold">On the chart</p>
      <p className="mt-2 font-display text-2xl text-fg">{formatCivil(when, lon)}</p>
      <p className="mt-1 text-sm text-muted">{place}</p>
      {note ? <p className="mt-3 text-sm text-fg">{note}</p> : <p className="mt-3 text-sm text-fg">Full dark. The bright patterns are fair game.</p>}
      <ul className="mt-4 space-y-2">
        {up.map((s) => (
          <li key={s.id} className="flex items-baseline justify-between gap-3 text-sm">
            <span className="text-fg">{s.name}</span>
            <span className="text-faint tabular-nums">
              {s.alt.toFixed(0)}° {compass(s.az)}
            </span>
          </li>
        ))}
        {up.length === 0 && <li className="text-sm text-muted">No bright star is high. Try a different hour, or a darker definition of “high.”</li>}
      </ul>
      {figures.length > 0 && <p className="mt-4 text-sm text-muted">Figures up: {figures.join(", ")}.</p>}
      <Link to="/sky" search={{}} className="mt-4 inline-flex text-sm text-gold">
        Adjust time and place
      </Link>
    </aside>
  );
}
