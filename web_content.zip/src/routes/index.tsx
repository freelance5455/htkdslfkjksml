import { createFileRoute } from "@tanstack/react-router";
import { SobeApp } from "@/components/sobe/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SobeApp />;
}
