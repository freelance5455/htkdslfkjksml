import { createFileRoute } from "@tanstack/react-router";
import { MazeGame } from "@/game/MazeGame";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <MazeGame />;
}
