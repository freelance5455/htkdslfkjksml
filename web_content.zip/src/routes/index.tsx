import { createFileRoute } from "@tanstack/react-router";
import { XjoxApp } from "@/components/xjox/app";

export const Route = createFileRoute("/")({
  component: XjoxApp,
});
