import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { AzJumper } from "@/components/az-jumper";
import { StarCard } from "@/components/star-card";
import { groupByLetter, LETTERS } from "@/data/catalog";
import { useStars } from "@/store/vault";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const stars = useStars();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "library" | "saved">("all");
  const [active, setActive] = useState("A");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return stars.filter((s) => {
      if (filter === "library" && s.counts.total === 0) return false;
      if (filter === "saved" && !s.favorite) return false;
      if (q && !s.name.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [stars, query, filter]);

  const groups = useMemo(() => groupByLetter(filtered), [filtered]);
  const present = useMemo(() => new Set(groups.keys()), [groups]);

  function jump(letter: string) {
    setActive(letter);
    const el = document.getElementById(`letter-${letter}`);
    el?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <AppShell search={query} onSearch={setQuery}>
      <div className="mx-auto flex max-w-6xl gap-1 px-3 pb-16 pt-4 sm:px-4">
        <div className="min-w-0 flex-1">
          <div className="mb-5 flex flex-wrap items-end justify-between gap-3 pr-4">
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
                Performers
              </p>
              <h1 className="font-display text-4xl font-medium tracking-tight sm:text-5xl">
                The roster
              </h1>
              <p className="mt-1 text-sm text-muted-foreground">
                {filtered.length.toLocaleString()} profiles
              </p>
            </div>
            <div className="flex rounded-lg bg-secondary p-1">
              {(
                [
                  ["all", "All"],
                  ["library", "Filed"],
                  ["saved", "Saved"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setFilter(id)}
                  className={`h-9 rounded-md px-3 text-sm ${
                    filter === id ? "bg-card text-foreground" : "text-muted-foreground"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {filtered.length === 0 ? (
            <p className="py-20 text-center text-sm text-muted-foreground">No matches.</p>
          ) : (
            LETTERS.filter((L) => groups.has(L)).map((letter) => (
              <section key={letter} id={`letter-${letter}`} className="scroll-mt-28 mb-8">
                <h2 className="sticky top-[4.5rem] z-10 mb-3 bg-background/90 py-1 font-display text-3xl font-medium backdrop-blur-sm">
                  {letter}
                </h2>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 sm:gap-3 md:grid-cols-4 lg:grid-cols-5">
                  {groups.get(letter)!.map((star) => (
                    <StarCard key={star.slug} star={star} />
                  ))}
                </div>
              </section>
            ))
          )}
        </div>
        <AzJumper present={present} active={active} onJump={jump} />
      </div>
    </AppShell>
  );
}
