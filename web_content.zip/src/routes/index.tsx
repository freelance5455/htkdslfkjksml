import { createFileRoute } from "@tanstack/react-router";
import { RaceApp } from "@/components/RaceApp";

export const Route = createFileRoute("/")({ component: RaceApp });
