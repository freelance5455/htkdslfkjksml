import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Cpu, Inbox, Terminal } from "lucide-react";
import { formatDec, shr2, unixSeconds } from "@/lib/rax";
import { RegisterView } from "@/components/register-view";
import { InboxView } from "@/components/inbox-view";
import { DispatchView } from "@/components/dispatch-view";

export const Route = createFileRoute("/")({ component: Home });

type Tab = "register" | "inbox" | "dispatch";

const TABS: { id: Tab; label: string; icon: typeof Cpu }[] = [
  { id: "register", label: "Register", icon: Cpu },
  { id: "inbox", label: "Inbox", icon: Inbox },
  { id: "dispatch", label: "Dispatch", icon: Terminal },
];

function useUnixClock(): number | null {
  const [sec, setSec] = useState<number | null>(null);
  useEffect(() => {
    const tick = () => setSec(unixSeconds());
    tick();
    const id = window.setInterval(tick, 250);
    return () => window.clearInterval(id);
  }, []);
  return sec;
}

function Home() {
  const now = useUnixClock();
  const [tab, setTab] = useState<Tab>("register");
  const compact = now === null ? null : shr2(now);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="h-0.5 bg-brass" />
      <div className="mx-auto flex w-full max-w-5xl flex-col px-4 pb-16 sm:px-6">
        <header className="pt-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="font-mono text-xs tracking-widest text-brass uppercase">x86-64 desk</p>
              <h1 className="mt-1 font-mono text-4xl font-semibold tracking-widest text-fg">RAX</h1>
              <p className="mt-2 max-w-md text-sm text-muted">
                Compact message ids from a two-bit shift of the Unix clock.
              </p>
            </div>
            <dl className="grid grid-cols-2 gap-x-6 gap-y-1 text-right">
              <dt className="text-xs text-muted">Unix second</dt>
              <dd className="font-mono text-sm text-fg tabular-nums">
                {now === null ? "—" : formatDec(now)}
              </dd>
              <dt className="text-xs text-muted">shr 2</dt>
              <dd className="font-mono text-sm text-brass tabular-nums">
                {compact === null ? "—" : formatDec(compact)}
              </dd>
            </dl>
          </div>

          <div role="tablist" aria-label="Desk" className="mt-6 flex gap-1 border-b border-line">
            {TABS.map((item) => {
              const Icon = item.icon;
              const selected = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  id={`tab-${item.id}`}
                  aria-selected={selected}
                  aria-controls={`panel-${item.id}`}
                  onClick={() => setTab(item.id)}
                  className={`inline-flex min-h-11 items-center gap-2 border-b-2 px-3 text-sm ${
                    selected ? "border-brass text-fg" : "border-transparent text-muted"
                  }`}
                >
                  <Icon className="size-4" aria-hidden="true" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </header>

        <main className="pt-6" role="tabpanel" id={`panel-${tab}`} aria-labelledby={`tab-${tab}`}>
          {tab === "register" ? <RegisterView now={now} /> : null}
          {tab === "inbox" ? <InboxView now={now} /> : null}
          {tab === "dispatch" ? <DispatchView now={now} /> : null}
        </main>
      </div>
    </div>
  );
}
