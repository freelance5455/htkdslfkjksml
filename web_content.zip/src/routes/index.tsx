import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CharlieApp, CharlieFrame } from "@/components/charlie/charlie-app";
import { useCharlie } from "@/lib/charlie/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancel = false;
    void Promise.resolve(useCharlie.persist.rehydrate()).then(() => {
      if (!cancel) setReady(true);
    });
    return () => {
      cancel = true;
    };
  }, []);

  if (!ready) return <CharlieFrame />;
  return <CharlieApp />;
}
