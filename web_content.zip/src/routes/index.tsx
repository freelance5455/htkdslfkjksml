import { createFileRoute } from "@tanstack/react-router";
import { BrandHeader } from "@/components/brand-header";
import { Calculator } from "@/components/calculator";
import { MarketGuide } from "@/components/market-guide";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="mx-auto w-full max-w-5xl overflow-x-hidden px-4 pt-6 pb-16 sm:px-6 lg:grid lg:max-w-6xl lg:grid-cols-[minmax(20rem,28rem)_minmax(0,1fr)] lg:items-start lg:gap-8 lg:px-8">
      <BrandHeader />
      <MarketGuide />
      <Calculator />
    </main>
  );
}
