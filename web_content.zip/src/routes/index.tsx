import { createFileRoute } from "@tanstack/react-router";
import { PadApp } from "@/components/pad/pad-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <PadApp />;
}
