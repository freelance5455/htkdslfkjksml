import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { LibraryView } from "@/components/library-view";
import { LockScreen } from "@/components/lock-screen";
import { ReaderView } from "@/components/reader-view";
import { useVault } from "@/lib/vault-store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const hydrated = useVault((s) => s.hydrated);
  const hash = useVault((s) => s.hash);
  const unlocked = useVault((s) => s.unlocked);
  const openBookId = useVault((s) => s.openBookId);

  useEffect(() => {
    const result = useVault.persist.rehydrate();
    void Promise.resolve(result).then(() => {
      useVault.getState().hydrate();
    });
  }, []);

  if (!hydrated || !hash) return <LockScreen mode="setup" />;
  if (!unlocked) return <LockScreen mode="unlock" />;
  if (openBookId) return <ReaderView bookId={openBookId} />;
  return <LibraryView />;
}
