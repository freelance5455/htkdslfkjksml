import { createFileRoute } from "@tanstack/react-router";
import { Studio } from "@/components/eq/studio";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="min-h-dvh overflow-x-hidden bg-bg text-fg">
      <Studio />
    </main>
  );
}
