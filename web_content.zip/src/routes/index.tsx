import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { LOGO_DATA_URI } from "@/game/logo-data";

export const Route = createFileRoute("/")({
  component: Home,
});

// مراحل نمایش قبل از بازی: ۱) لوگوی بزرگ با افکت محو و مکث بیشتر ۲) صفحه لودینگ با نوار پیشرفت ۳) خود بازی
type Phase = "logoIn" | "logoHold" | "logoOut" | "loading" | "game";

const LOGO_FADE_MS = 800;   // محو شدن (کم‌رنگ به پررنگ و برعکس)
const LOGO_STAY_MS = 2400;  // مدت ماندن کامل لوگو روی صفحه

function Home() {
  const ref = useRef<HTMLDivElement>(null);
  const [phase, setPhase] = useState<Phase>("logoIn");
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    timers.push(setTimeout(() => setPhase("logoHold"), 60));
    timers.push(setTimeout(() => setPhase("logoOut"), 60 + LOGO_FADE_MS + LOGO_STAY_MS));
    timers.push(setTimeout(() => setPhase("loading"), 60 + LOGO_FADE_MS + LOGO_STAY_MS + LOGO_FADE_MS));
    return () => timers.forEach(clearTimeout);
  }, []);

  useEffect(() => {
    if (phase !== "loading") return;
    const duration = 1450;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const pct = Math.min(100, ((now - start) / duration) * 100);
      setProgress(pct);
      if (pct < 100) {
        raf = requestAnimationFrame(tick);
      } else {
        setTimeout(() => setPhase("game"), 150);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [phase]);

  useEffect(() => {
    if (phase !== "game") return;
    let cancelled = false;
    let cleanup: (() => void) | undefined;
    void import("@/game/space-runner.js").then((mod) => {
      if (cancelled || !ref.current) return;
      cleanup = (mod as { boot: (root: HTMLElement) => () => void }).boot(ref.current);
    });
    return () => {
      cancelled = true;
      cleanup?.();
    };
  }, [phase]);

  const showSplash = phase !== "game";
  const logoShown = phase === "logoHold";

  return (
    <div ref={ref} id="sr-root">
      {showSplash && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 9999,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            background: "#000",
            color: "#d6e4ff",
            fontFamily: "Tahoma, Arial, sans-serif",
            overflow: "hidden",
            boxSizing: "border-box",
            padding: "max(14px, env(safe-area-inset-top)) max(14px, env(safe-area-inset-right)) max(14px, env(safe-area-inset-bottom)) max(14px, env(safe-area-inset-left))",
          }}
        >
          {phase !== "loading" && (
            <img
              src={LOGO_DATA_URI}
              alt=""
              style={{
                width: "min(88%, 560px)",
                maxWidth: "100%",
                maxHeight: "78%",
                objectFit: "contain",
                opacity: logoShown ? 1 : 0,
                transform: logoShown ? "scale(1)" : phase === "logoIn" ? "scale(0.94)" : "scale(1.02)",
                transition: `opacity ${LOGO_FADE_MS}ms ease-in-out, transform ${LOGO_FADE_MS + LOGO_STAY_MS}ms ease-out`,
                background: "#000",
              }}
            />
          )}

          {phase === "loading" && (
            <div
              style={{
                position: "absolute",
                inset: 0,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 18,
                background: "radial-gradient(ellipse at 50% 30%, #0d1a3d 0%, #05081a 55%, #020410 100%)",
                animation: "srFadeIn 500ms ease-out",
              }}
            >
              <div
                style={{
                  fontSize: 30,
                  fontWeight: 800,
                  letterSpacing: 1,
                  textShadow: "0 0 20px rgba(77,124,255,0.65)",
                  background: "linear-gradient(90deg,#7cc7ff,#c9a4ff,#ffd447)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                🚀 دونده فضایی
              </div>
              <div style={{ fontSize: 13, color: "#9fb3e0" }}>در حال بارگذاری...</div>
              <div
                style={{
                  width: 200,
                  height: 8,
                  borderRadius: 8,
                  background: "#101d3d",
                  border: "1px solid #2c3f6e",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    width: `${progress}%`,
                    borderRadius: 8,
                    background: "linear-gradient(90deg,#4d7cff,#7cc7ff,#ffd447)",
                    boxShadow: "0 0 10px rgba(124,199,255,0.7)",
                    transition: "width 80ms linear",
                  }}
                />
              </div>
            </div>
          )}

          <style>{`@keyframes srFadeIn{from{opacity:0}to{opacity:1}}`}</style>
        </div>
      )}
    </div>
  );
}
