import { useEffect } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { listMyCommissions, listMyRooms, listRooms } from "@/lib/rooms-api";
import { captureReferral } from "@/lib/rooms-model";
import { BrowseView } from "@/components/browse-view";
import { EarningsView } from "@/components/earnings-view";
import { ListView } from "@/components/list-view";
import { cn, isUnauthorized } from "@/lib/utils";

type Tab = "browse" | "list" | "earnings";

type HomeSearch = {
  tab: Tab;
  ref?: string;
  room?: string;
};

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): HomeSearch => {
    const next: HomeSearch = {
      tab: search.tab === "list" || search.tab === "earnings" ? (search.tab as Tab) : "browse",
    };
    if (typeof search.ref === "string" && search.ref) next.ref = search.ref;
    if (typeof search.room === "string" && search.room) next.room = search.room;
    return next;
  },
  component: Home,
});

function Home() {
  const { tab, ref, room } = Route.useSearch();
  const navigate = Route.useNavigate();
  const { user, isPending } = useCurrentUserState();
  const signedIn = Boolean(user);

  useEffect(() => {
    captureReferral(ref, room);
  }, [ref, room]);

  const roomsQuery = useQuery({
    queryKey: ["rooms"],
    queryFn: () => listRooms(),
  });

  const mineQuery = useQuery({
    queryKey: ["my-rooms", user?.id],
    queryFn: () => listMyRooms(),
    enabled: signedIn,
  });

  const earnQuery = useQuery({
    queryKey: ["my-commissions", user?.id],
    queryFn: () => listMyCommissions(),
    enabled: signedIn,
    retry: (count, err) => !isUnauthorized(err) && count < 2,
  });

  function setTab(next: Tab) {
    void navigate({
      search: (prev) => ({ ...prev, tab: next }),
    });
  }

  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur-sm">
        <div className="mx-auto max-w-5xl px-5 pt-5">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="font-serif text-[26px] font-semibold tracking-tight">
                Rent<em className="italic text-brass-deep">Direct</em>
              </h1>
              <p className="mt-0.5 text-[13.5px] text-ink-soft">
                Call the owner yourself. Earn when a room you shared gets rented.
              </p>
            </div>
            <div className="flex min-h-8 items-center">
              {isPending ? (
                <div className="h-8 w-28 animate-pulse rounded-full bg-ink/10" />
              ) : user ? (
                <UserButton />
              ) : (
                <Link
                  to="/login"
                  className="inline-flex min-h-11 items-center rounded-md border border-line px-3 text-sm font-medium text-ink hover:bg-paper-alt"
                >
                  Sign in
                </Link>
              )}
            </div>
          </div>
          <nav className="mt-4 flex gap-1 overflow-x-auto" aria-label="Main">
            {(
              [
                ["browse", "Browse rooms"],
                ["list", "List a room"],
                ["earnings", "My referrals & earnings"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                className={cn(
                  "mr-5 shrink-0 border-b-2 px-1 py-2.5 text-[14.5px] font-medium whitespace-nowrap",
                  tab === id
                    ? "border-brass text-ink"
                    : "border-transparent text-ink-soft hover:text-ink",
                )}
              >
                {label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-5 pt-6 pb-20">
        {tab === "browse" ? (
          <BrowseView
            rooms={roomsQuery.data ?? []}
            loading={roomsQuery.isLoading}
            userId={user?.id ?? null}
            signedIn={signedIn}
          />
        ) : null}
        {tab === "list" ? (
          <ListView
            rooms={roomsQuery.data ?? []}
            mine={mineQuery.data ?? []}
            signedIn={signedIn}
            loadingMine={signedIn && mineQuery.isLoading}
          />
        ) : null}
        {tab === "earnings" ? (
          <EarningsView
            rows={earnQuery.data ?? []}
            signedIn={signedIn}
            loading={signedIn && earnQuery.isLoading}
          />
        ) : null}
      </main>
    </div>
  );
}
