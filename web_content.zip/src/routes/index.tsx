import { useEffect, useState, type ComponentType } from "react";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Boot() {
  return (
    <main className="grid h-dvh place-items-center bg-sky px-6 text-center text-ink">
      <div>
        <p className="text-xs font-extrabold tracking-widest text-hedge uppercase">A pocket maze</p>
        <h1 className="font-display mt-3 text-4xl leading-none">Lantern Grove</h1>
        <p className="mt-3 text-sm text-muted">Trimming the hedges…</p>
      </div>
    </main>
  );
}

function Home() {
  const [View, setView] = useState<ComponentType<{ touch: boolean }> | null>(null);
  const [touch, setTouch] = useState(false);

  useEffect(() => {
    let drop = () => {};
    let cancelled = false;
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    setTouch(coarse);
    void import("@/game/Game").then((mod) => {
      if (cancelled) return;
      return import("@/game/session").then((live) => {
        if (cancelled) return;
        live.session.touch = coarse;
        live.session.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        drop = mod.mountInput();
        setView(() => mod.Game);
      });
    });
    return () => {
      cancelled = true;
      drop();
    };
  }, []);

  if (!View) return <Boot />;
  return <View touch={touch} />;
}
