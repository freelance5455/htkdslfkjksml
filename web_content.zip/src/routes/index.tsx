import { createFileRoute } from "@tanstack/react-router";
import { RastroApp } from "@/components/rastro/rastro-app";

export const Route = createFileRoute("/")({
  component: RastroApp,
});
