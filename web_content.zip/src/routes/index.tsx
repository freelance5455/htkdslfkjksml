import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/yooyyaa/shell";
import { Mark } from "@/components/yooyyaa/mark";
import { useYooyyaa } from "@/lib/yooyyaa/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const pending = useYooyyaa.persist.rehydrate();
    void Promise.resolve(pending).finally(() => setReady(true));
  }, []);
  if (!ready) return <Splash />;
  return <Shell />;
}

function Splash() {
  return (
    <main className="grid min-h-screen place-items-center bg-bg px-6 text-fg">
      <div className="flex flex-col items-center gap-4">
        <Mark className="size-16" />
        <p className="font-display text-3xl tracking-wide">YOOYYAA</p>
      </div>
    </main>
  );
}
