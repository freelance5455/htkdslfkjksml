import { createFileRoute } from "@tanstack/react-router";
import { SchemeApp } from "@/components/scheme-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SchemeApp />;
}
