import { createFileRoute } from "@tanstack/react-router";
import { DashboardPage } from "@/components/ministry/dashboard-page";
import { AppShell } from "@/components/ministry/shell";

export const Route = createFileRoute("/")({
  component: function Home() {
    return (
      <AppShell>
        <DashboardPage />
      </AppShell>
    );
  },
});
