import { createFileRoute } from "@tanstack/react-router";
import { Library } from "@/components/roleforge/library";

export const Route = createFileRoute("/")({ component: Library });
