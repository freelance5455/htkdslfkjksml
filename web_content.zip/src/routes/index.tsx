import { createFileRoute } from "@tanstack/react-router";
import { ShawarmaGame } from "@/game/ShawarmaGame";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ShawarmaGame />;
}
