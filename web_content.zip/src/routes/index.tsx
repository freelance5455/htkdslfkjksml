import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="awrad-frame">
      <iframe
        title="أوراد وروحانيات"
        src="/awrad.html"
        className="awrad-iframe"
      />
    </main>
  );
}
