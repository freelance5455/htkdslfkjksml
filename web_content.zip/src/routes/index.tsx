import { createFileRoute } from "@tanstack/react-router";
import { SahyogApp } from "@/sahyog/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SahyogApp />;
}
