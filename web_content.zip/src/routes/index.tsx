import { createFileRoute } from "@tanstack/react-router";
import { RadixCounter } from "@/components/radix-counter";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [
      { title: "何以解忧，唯有一醉解千愁" },
      {
        name: "description",
        content: "给每样东西记喝了几口、满了几杯。",
      },
    ],
  }),
});

function Home() {
  return <RadixCounter />;
}
