import { createFileRoute, Navigate } from "@tanstack/react-router";
import { Splash } from "@/components/layout/splash";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <Splash />;
  if (user) return <Navigate to="/dashboard" />;
  return <Navigate to="/login" />;
}
