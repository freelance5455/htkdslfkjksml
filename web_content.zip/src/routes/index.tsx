import { createFileRoute } from "@tanstack/react-router";
import { Assistant } from "@/components/jarvis/assistant";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Assistant />;
}
