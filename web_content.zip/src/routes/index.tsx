import { createFileRoute } from "@tanstack/react-router";
import { TrainerApp } from "@/components/trainer-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <TrainerApp />;
}
