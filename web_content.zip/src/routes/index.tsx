import { createFileRoute } from "@tanstack/react-router";
import { RangeApp } from "@/components/range/range-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <RangeApp />;
}
