import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { isAfter as dfIsAfter, isBefore as dfIsBefore, startOfDay as dfStart } from "date-fns";
import type { ComponentType } from "react";
import {
  CalendarDays,
  ChartArea,
  ChevronRight,
  Droplets,
  Dumbbell,
  PersonStanding,
} from "lucide-react";
import { CheckItem } from "@/components/check-item";
import { PageHeader } from "@/components/page-header";
import { ProgressRing } from "@/components/progress-ring";
import { StatCard } from "@/components/stat-card";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  PROJECT_DAYS,
  PROJECT_END,
  PROJECT_START,
  WEEKDAY_LABEL,
  computeStreak,
  countHabitMarks,
  daysUntil,
  getDayChecks,
  getDayStatus,
  projectDayNumber,
  projectProgressPct,
  toDateKey,
  weekdayFromDate,
} from "@/lib/dates";
import { SESSION_TYPE_LABEL } from "@/lib/defaults";
import { motivationLine } from "@/lib/motivation";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const navigate = useNavigate();
  const today = dfStart(new Date());
  const date = toDateKey(today);
  const settings = useAppStore((s) => s.settings);
  const logs = useAppStore((s) => s.logs);
  const sessions = useAppStore((s) => s.sessions);
  const workouts = useAppStore((s) => s.workouts);
  const activeSession = useAppStore((s) => s.activeSession);
  const toggleSkinCare = useAppStore((s) => s.toggleSkinCare);
  const toggleFood = useAppStore((s) => s.toggleFood);
  const togglePostureHabit = useAppStore((s) => s.togglePostureHabit);
  const toggleWorkoutHabit = useAppStore((s) => s.toggleWorkoutHabit);

  const log = logs[date];
  const checks = getDayChecks(log, settings);
  const status = getDayStatus(log, settings);
  const dayNum = projectDayNumber(today);
  const pct = projectProgressPct(today);
  const beforeStart = dfIsBefore(today, PROJECT_START);
  const afterEnd = dfIsAfter(today, PROJECT_END);
  const untilEnd = Math.max(0, daysUntil(PROJECT_END, today));
  const untilStart = Math.max(0, daysUntil(PROJECT_START, today));
  const weekday = weekdayFromDate(today);
  const todayWorkout = workouts[weekday];
  const streak = computeStreak(logs, settings, today);

  const completedDays = Object.values(logs).filter(
    (l) => getDayStatus(l, settings) === "complete",
  ).length;
  const habitsDone = Object.values(logs).reduce(
    (acc, l) => acc + countHabitMarks(l),
    0,
  );
  const trainingSessions = sessions.filter((s) => s.type !== "postura").length;

  const quote = motivationLine({
    beforeStart,
    afterEnd,
    progressPct: pct,
    streak,
    todayComplete: status === "complete",
    todayPartial: status === "partial",
  });

  return (
    <div className="animate-in fade-in duration-300">
      <PageHeader
        kicker={settings.name ? settings.name : "Disciplina"}
        title="PROJETO 101"
        subtitle="Treino, postura e hábitos. Sem teatro."
      />

      <Card className="mb-5 overflow-hidden">
        <CardContent className="flex flex-col items-center gap-5 p-6 sm:flex-row sm:items-center">
          <ProgressRing value={pct}>
            <span className="font-display text-2xl font-semibold tabular-nums">
              {pct}%
            </span>
            <span className="text-[10px] tracking-wide text-muted-foreground uppercase">
              concluído
            </span>
          </ProgressRing>
          <div className="min-w-0 flex-1 text-center sm:text-left">
            {beforeStart ? (
              <>
                <p className="font-display text-xl font-semibold">
                  Começa em {untilStart} {untilStart === 1 ? "dia" : "dias"}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  21/09/2026 — Dia 01 de 101
                </p>
              </>
            ) : afterEnd ? (
              <>
                <p className="font-display text-xl font-semibold">Ciclo encerrado</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  101 de 101 dias · 30/12/2026
                </p>
              </>
            ) : (
              <>
                <p className="font-display text-xl font-semibold">
                  Dia {dayNum} de {PROJECT_DAYS}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  {untilEnd === 0
                    ? "Último dia do ciclo."
                    : `${untilEnd} ${untilEnd === 1 ? "dia" : "dias"} até 30/12/2026`}
                </p>
              </>
            )}
            <p className="mt-3 text-sm text-secondary-foreground">{quote}</p>
          </div>
        </CardContent>
      </Card>

      <div className="mb-5 grid grid-cols-2 gap-3">
        <StatCard label="Sequência atual" value={streak} hint="dias seguidos" />
        <StatCard
          label="Dias concluídos"
          value={completedDays}
          hint={`de ${PROJECT_DAYS}`}
        />
        <StatCard label="Hábitos concluídos" value={habitsDone} />
        <StatCard label="Sessões de treino" value={trainingSessions} />
      </div>

      <Card className="mb-5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 p-5 pb-0">
          <CardTitle>Checklist de hoje</CardTitle>
          <Link
            to="/dia/$date"
            params={{ date }}
            className="text-xs font-medium text-primary"
          >
            Abrir o dia
          </Link>
        </CardHeader>
        <CardContent className="space-y-0.5 pt-3">
          <CheckItem
            checked={checks.skinCare}
            label="Skin care"
            hint="Limpeza, hidratante e protetor"
            onToggle={() => {
              const next = !(
                log?.skinCare.cleansing &&
                log?.skinCare.moisturizer &&
                log?.skinCare.sunscreen
              );
              (["cleansing", "moisturizer", "sunscreen"] as const).forEach((k) => {
                if (Boolean(log?.skinCare[k]) !== next) toggleSkinCare(date, k);
              });
            }}
          />
          <CheckItem
            checked={checks.water}
            label="Água — 2 L"
            hint={`${log?.waterMl ?? 0} / ${settings.waterGoalMl} ml`}
            onToggle={() => navigate({ to: "/habitos" })}
          />
          <CheckItem
            checked={checks.sleep}
            label="Sono — 8 h"
            hint={
              log?.sleepHours == null
                ? "Ainda não registrado"
                : `${log.sleepHours} h registradas`
            }
            onToggle={() => navigate({ to: "/habitos" })}
          />
          <CheckItem
            checked={checks.food}
            label="Alimentação saudável"
            onToggle={() => {
              const next = !checks.food;
              (
                ["completeMeals", "fruitsVeggies", "protein", "reducedUltra"] as const
              ).forEach((k) => {
                if (Boolean(log?.food[k]) !== next) toggleFood(date, k);
              });
            }}
          />
          <CheckItem
            checked={checks.posture}
            label="Postura"
            onToggle={() => togglePostureHabit(date)}
          />
          <CheckItem
            checked={checks.workout}
            label="Treino do dia"
            hint={`${WEEKDAY_LABEL[weekday]} · ${todayWorkout.title}`}
            onToggle={() => toggleWorkoutHabit(date)}
          />
        </CardContent>
      </Card>

      <Card className="mb-5">
        <CardContent className="flex items-center gap-4 p-5">
          <div className="flex size-12 items-center justify-center rounded-xl bg-primary/15 text-primary">
            <Dumbbell className="size-5" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-medium tracking-wide text-muted-foreground uppercase">
              {WEEKDAY_LABEL[weekday]}
            </p>
            <p className="font-display text-lg font-semibold">
              {SESSION_TYPE_LABEL[todayWorkout.type]}
            </p>
            <p className="text-sm text-muted-foreground">{todayWorkout.subtitle}</p>
          </div>
          <Link
            to="/treinos/$day"
            params={{ day: weekday }}
            className={cn(buttonVariants())}
          >
            {activeSession ? "Continuar" : "Abrir"}
          </Link>
        </CardContent>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2">
        <QuickLink
          to="/calendario"
          icon={CalendarDays}
          title="Calendário"
          hint="101 dias · status de cada um"
        />
        <QuickLink
          to="/estatisticas"
          icon={ChartArea}
          title="Estatísticas"
          hint="Consistência, não estética"
        />
        <QuickLink
          to="/postura"
          icon={PersonStanding}
          title="Rotina de postura"
          hint="Separada do treino principal"
        />
        <QuickLink
          to="/habitos"
          icon={Droplets}
          title="Hábitos"
          hint="Água, sono, skin care, comida"
        />
      </div>
    </div>
  );
}

function QuickLink({
  to,
  icon: Icon,
  title,
  hint,
}: {
  to: "/calendario" | "/estatisticas" | "/postura" | "/habitos";
  icon: ComponentType<{ className?: string }>;
  title: string;
  hint: string;
}) {
  return (
    <Link to={to} className="block">
      <Card className="p-4 transition-colors hover:border-primary/40">
        <div className="flex items-center gap-3">
          <span className="flex size-10 items-center justify-center rounded-xl bg-accent text-primary">
            <Icon className="size-4" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-medium">{title}</span>
            <span className="block text-xs text-muted-foreground">{hint}</span>
          </span>
          <ChevronRight className="size-4 text-muted-foreground" />
        </div>
      </Card>
    </Link>
  );
}
