import { createFileRoute } from "@tanstack/react-router";
import { LoungeApp } from "@/components/lounge/lounge-app";
import { BootScreen, GmailSignIn } from "@/components/lounge/sign-in";
import { SignInGate } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { cleanName } from "@/lib/voice/rooms";

type Search = { r?: string };

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): Search => {
    const r = search.r;
    if (typeof r !== "string") return {};
    const clean = r.trim().slice(0, 64);
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(clean)) return {};
    return { r: clean };
  },
  component: Home,
});

function Home() {
  const { r } = Route.useSearch();
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <BootScreen />;
  const accountName = cleanName(user?.displayName || user?.primaryEmail?.split("@")[0] || "");
  return (
    <SignInGate fallback={<GmailSignIn />}>
      <LoungeApp entryRoom={r} accountName={accountName || "ضيف"} />
    </SignInGate>
  );
}
