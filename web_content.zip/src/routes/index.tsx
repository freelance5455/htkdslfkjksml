import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/features/home";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Home · FrameForge BOOYAH" }] }),
  component: HomePage,
});
