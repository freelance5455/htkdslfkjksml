import { createFileRoute } from "@tanstack/react-router";
import { ArdenApp } from "@/components/arden-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ArdenApp />;
}
