import { createFileRoute } from "@tanstack/react-router";
import { AppMain } from "@/app-main";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AppMain />;
}
