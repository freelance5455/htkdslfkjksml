import { createFileRoute } from "@tanstack/react-router";
import { ArdaniaStudio } from "@/components/ardania-studio";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <ArdaniaStudio />;
}
