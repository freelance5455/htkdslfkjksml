import { BottomNav, DesktopNav, PageFrame } from "@/components/app-shell";
import { CategoryBar } from "@/components/category-bar";
import { ChipBar } from "@/components/chip-bar";
import { ErrorBoundary } from "@/components/error-boundary";
import { FollowingList } from "@/components/following-list";
import { PostCard, PostCardSkeleton } from "@/components/post-card";
import { PullToRefresh } from "@/components/pull-to-refresh";
import { SearchPanel } from "@/components/search-panel";
import { Button } from "@/components/ui/button";
import { useCommunityFeed, type FeedTab } from "@/hooks/use-community-feed";
import { useSentinel } from "@/hooks/use-sentinel";
import { POST_SORTS, POST_TYPES, type PostSort, type TypeFilter } from "@/lib/sort";
import { useSubscriptions } from "@/lib/subscriptions";
import type { TopicId } from "@/lib/youtube/types";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2, Search } from "lucide-react";
import { useCallback, useRef, useState } from "react";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [tab, setTab] = useState<FeedTab>("community");
  const [topic, setTopic] = useState<TopicId>("all");
  const [type, setType] = useState<TypeFilter>("all");
  const [sort, setSort] = useState<PostSort>("newest");
  const subscribed = useSubscriptions((s) => s.channels);
  const subscribedIds = subscribed.map((c) => c.id);

  const feed = useCommunityFeed({
    topic,
    type,
    sort,
    subscribedIds,
    enabled: tab === "community",
  });
  const sentinel = useRef<HTMLDivElement>(null);

  const {
    posts,
    isLoading,
    isFetching,
    isFetchingNextPage,
    isError,
    hasNextPage,
    fetchNextPage,
    refetch,
  } = feed;

  const loadMore = useCallback(() => {
    if (hasNextPage && !isFetchingNextPage && !isFetching) {
      void fetchNextPage();
    }
  }, [fetchNextPage, hasNextPage, isFetching, isFetchingNextPage]);

  useSentinel(
    sentinel,
    tab === "community" && Boolean(hasNextPage && !isFetchingNextPage),
    loadMore,
  );

  const onRefresh = useCallback(async () => {
    await refetch();
  }, [refetch]);

  return (
    <PageFrame>
      <DesktopNav tab={tab} onTab={setTab} />
      <div className="flex h-full min-h-0 min-w-0 flex-1 flex-col overflow-hidden">
        <header className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur-sm">
          <div className="flex items-center gap-3 px-4 py-3">
            <div className="min-w-0 flex-1">
              <h1 className="truncate font-display text-base font-semibold tracking-tight lg:text-xl">
                {tab === "search" ? "Search channels" : tab === "following" ? "Following" : "Community"}
              </h1>
            </div>
            <Button
              type="button"
              size="icon"
              variant={tab === "search" ? "default" : "muted"}
              onClick={() => setTab("search")}
              aria-label="Search"
            >
              <Search />
            </Button>
          </div>
          {tab === "community" ? (
            <>
              <CategoryBar value={topic} onChange={setTopic} />
              <ChipBar
                ariaLabel="Post type"
                items={POST_TYPES}
                value={type}
                onChange={setType}
              />
              <ChipBar ariaLabel="Sort posts" items={POST_SORTS} value={sort} onChange={setSort} />
            </>
          ) : null}
        </header>

        {tab === "search" ? (
          <SearchPanel autoFocus />
        ) : (
          <PullToRefresh onRefresh={tab === "community" ? onRefresh : async () => undefined}>
            <div className="mx-auto w-full max-w-2xl px-4 pb-28 pt-4 lg:pb-10">
              <ErrorBoundary>
                {tab === "following" ? (
                  <FollowingList onSearch={() => setTab("search")} />
                ) : isLoading || (posts.length === 0 && isFetching) ? (
                  <div className="space-y-3">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <PostCardSkeleton key={i} />
                    ))}
                  </div>
                ) : isError ? (
                  <EmptyState
                    title="Couldn’t load posts"
                    body="Swipe down to try again."
                    actionLabel="Retry"
                    onAction={() => refetch()}
                  />
                ) : posts.length === 0 ? (
                  <EmptyState
                    title="No posts in this view"
                    body="This filter is still filling. Try All or another type."
                  />
                ) : (
                  <div className="space-y-3">
                    {posts.map((post) => (
                      <PostCard key={post.id} post={post} />
                    ))}
                  </div>
                )}

                {tab === "community" ? <div ref={sentinel} className="h-10" /> : null}
                {tab === "community" && isFetchingNextPage ? (
                  <div className="flex items-center justify-center py-6 text-muted-foreground">
                    <Loader2 className="size-5 animate-spin" />
                  </div>
                ) : null}
              </ErrorBoundary>
            </div>
          </PullToRefresh>
        )}
      </div>
      <BottomNav tab={tab} onTab={setTab} />
    </PageFrame>
  );
}

function EmptyState({
  title,
  body,
  actionLabel,
  onAction,
}: {
  title: string;
  body: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card px-6 py-12 text-center">
      <h2 className="font-display text-lg font-semibold">{title}</h2>
      <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">{body}</p>
      {actionLabel && onAction ? (
        <Button className="mt-5" onClick={onAction}>
          {actionLabel}
        </Button>
      ) : null}
    </div>
  );
}
