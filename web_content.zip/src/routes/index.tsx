import { createFileRoute } from "@tanstack/react-router";
import { MineralApp } from "@/components/mineral-app";

export const Route = createFileRoute("/")({
  component: MineralApp,
});
