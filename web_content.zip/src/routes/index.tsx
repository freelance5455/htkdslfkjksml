import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { GameRoot } from "@/ui/GameRoot";
import { BootScreen } from "@/ui/TitleScreen";

export const Route = createFileRoute("/")({
  ssr: false,
  component: Home,
});

function Home() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return <BootScreen />;
  return <GameRoot />;
}
