import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, Headphones, Heart, Library, Moon, Search, Sparkles, Sun } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { quranMeta } from "@/content/catalog";
import { useAppStore } from "@/lib/store";
import { toArabicDigits } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const SECTIONS = [
  { to: "/quran", title: "القرآن الكريم", hint: "المصحف والسور", icon: BookOpen },
  { to: "/adhkar", title: "الأذكار والأدعية", hint: "حصن المسلم", icon: Sparkles },
  { to: "/library", title: "المكتبة الشرعية", hint: "حديث · عقيدة · فقه", icon: Library },
  { to: "/listen", title: "الاستماع", hint: "تلاوة وتحميل دون اتصال", icon: Headphones },
  { to: "/favorites", title: "المفضلة", hint: "آيات ومواضع محفوظة", icon: Heart },
];

function greeting() {
  const h = new Date().getHours();
  if (h < 5) return "أذكار النوم قريبة إن شاء الله";
  if (h < 12) return "آن أذكار الصباح";
  if (h < 16) return "بارك الله وقتك";
  if (h < 19) return "آن أذكار المساء";
  return "آن أذكار المساء والنوم";
}

function Home() {
  const last = useAppStore((s) => s.lastReading);
  const theme = useAppStore((s) => s.settings.theme);
  const setTheme = useAppStore((s) => s.setTheme);
  const surah = last ? quranMeta.surahs.find((x) => x.id === last.surahId) : quranMeta.surahs[0];
  const ayah = last?.ayah ?? 1;
  const isDark = theme === "dark";

  return (
    <AppShell>
      <div className="relative overflow-hidden">
        <div className="ornament-bg pointer-events-none absolute inset-0" />
        <header className="relative flex items-center justify-between px-5 pb-2 pt-6">
          <Link
            to="/search"
            className="tap-lg flex size-11 items-center justify-center rounded-full bg-surface text-foreground"
            aria-label="بحث"
          >
            <Search className="size-5" />
          </Link>
          <div className="text-center">
            <p className="text-[11px] tracking-[0.3em] text-muted-foreground">بسم الله الرحمن الرحيم</p>
            <h1 className="font-quran text-3xl text-accent">رفيق</h1>
          </div>
          <button
            type="button"
            className="tap-lg flex size-11 items-center justify-center rounded-full bg-surface"
            aria-label="الوضع الليلي"
            onClick={() => setTheme(isDark ? "light" : "dark")}
          >
            {isDark ? <Sun className="size-5" /> : <Moon className="size-5" />}
          </button>
        </header>

        <p className="relative mb-5 px-5 text-center text-sm text-muted-foreground">{greeting()}</p>

        <section className="relative mx-4 mb-6 rounded-[28px] bg-accent p-5 text-accent-foreground shadow-[var(--shadow-border)]">
          <p className="text-xs opacity-80">موضع القراءة</p>
          <h2 className="mt-1 font-quran text-2xl">
            {surah?.name ?? "سُورَةُ ٱلْفَاتِحَةِ"}
          </h2>
          <p className="mt-1 text-sm opacity-85">
            الآية {toArabicDigits(ayah)}
            {surah ? ` · ${surah.type}` : ""}
          </p>
          <Link
            to="/quran/$surahId"
            params={{ surahId: String(surah?.id ?? 1) }}
            search={{ ayah }}
            className="mt-4 flex h-12 items-center justify-center rounded-2xl bg-accent-foreground text-sm font-semibold text-accent"
          >
            متابعة القراءة
          </Link>
        </section>
      </div>

      <section className="px-4 pb-8">
        <ul className="grid gap-2.5">
          {SECTIONS.map((s) => {
            const Icon = s.icon;
            return (
              <li key={s.to}>
                <Link
                  to={s.to}
                  className="flex items-center gap-3 rounded-2xl bg-card px-4 py-3.5 shadow-[var(--shadow-border)] transition-transform duration-[var(--motion-quick)] active:scale-[0.99]"
                >
                  <span className="flex size-11 items-center justify-center rounded-xl bg-surface text-accent">
                    <Icon className="size-5" />
                  </span>
                  <span className="flex-1">
                    <span className="block text-[15px] font-medium">{s.title}</span>
                    <span className="text-xs text-muted-foreground">{s.hint}</span>
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </section>
    </AppShell>
  );
}
