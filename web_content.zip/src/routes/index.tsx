import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { BootScreen } from "@/components/dera/boot-screen";
import { Console } from "@/components/dera/console";
import { useSafety } from "@/lib/dera/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const mode = useSafety((state) => state.mode);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let live = true;
    void Promise.resolve(useSafety.persist.rehydrate()).finally(() => {
      if (live) setReady(true);
    });
    return () => {
      live = false;
    };
  }, []);

  if (!ready || mode === null) return <BootScreen ready={ready} />;
  return <Console />;
}
