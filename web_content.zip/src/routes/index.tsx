import { createFileRoute } from "@tanstack/react-router";
import { NexorApp } from "@/components/nexor/nexor-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <NexorApp />;
}
