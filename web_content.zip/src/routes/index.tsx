import { createFileRoute } from "@tanstack/react-router";
import { Orrery } from "@/orrery/Orrery";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Orrery />;
}
