import { createFileRoute } from "@tanstack/react-router";
import { Studio } from "@/components/lv99/studio";
import { lv99Status } from "@/lib/lv99-api";

export const Route = createFileRoute("/")({
  loader: () => lv99Status(),
  component: Home,
});

function Home() {
  const status = Route.useLoaderData();
  return <Studio ready={status.ready} />;
}
