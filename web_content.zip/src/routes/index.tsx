import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  PRIORITY_LABEL,
  type Goal,
  type Priority,
  type Task,
  daysLeft,
  fa,
  loadGoals,
  moveInGroup,
  progressOf,
  saveGoals,
  seedGoals,
  sortItems,
  uid,
} from "@/lib/goals";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [ready, setReady] = useState(false);
  const [goals, setGoals] = useState<Goal[]>(seedGoals);
  const [openId, setOpenId] = useState<string | null>(null);
  const [modal, setModal] = useState<null | { kind: "goal" | "task"; id?: string }>(null);
  const [menu, setMenu] = useState<null | { scope: "goal" | "task"; id: string }>(null);
  const [drag, setDrag] = useState<null | { scope: "goal" | "task"; id: string }>(null);

  useEffect(() => {
    setGoals(loadGoals());
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) saveGoals(goals);
  }, [goals, ready]);

  const openGoal = goals.find((g) => g.id === openId) ?? null;
  const sorted = useMemo(() => sortItems(goals), [goals]);

  function patchGoal(id: string, fn: (g: Goal) => Goal) {
    setGoals((list) => list.map((g) => (g.id === id ? fn(g) : g)));
  }

  function onDropGoal(targetId: string) {
    if (!drag || drag.scope !== "goal") return;
    setGoals((list) => moveInGroup(list, drag.id, targetId));
    setDrag(null);
  }

  function onDropTask(targetId: string) {
    if (!drag || drag.scope !== "task" || !openId) return;
    patchGoal(openId, (g) => ({ ...g, tasks: moveInGroup(g.tasks, drag.id, targetId) }));
    setDrag(null);
  }

  return (
    <div className="mx-auto flex min-h-full max-w-[480px] flex-col bg-[#f5f8f9]" onClick={() => setMenu(null)}>
      <header dir="ltr" className="flex items-center justify-between border-b border-[#e7eef0] bg-white px-4 py-3">
        <button
          className="grid h-12 w-12 place-items-center rounded-2xl bg-[#12a085] text-white shadow-sm"
          onClick={(e) => {
            e.stopPropagation();
            setModal(openGoal ? { kind: "task" } : { kind: "goal" });
          }}
          aria-label="افزودن"
        >
          <Plus />
        </button>
        <h1 className="text-[26px] font-extrabold tracking-tight text-[#17323c]">
          {openGoal ? "کارها" : "اهداف"}
        </h1>
      </header>

      <main className="flex-1 px-4 pb-8">
        {openGoal ? (
          <TaskList
            goal={openGoal}
            dragId={drag?.scope === "task" ? drag.id : null}
            menuId={menu?.scope === "task" ? menu.id : null}
            onBack={() => setOpenId(null)}
            onToggle={(id) =>
              patchGoal(openGoal.id, (g) => ({
                ...g,
                tasks: g.tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)),
              }))
            }
            onPin={(id) =>
              patchGoal(openGoal.id, (g) => ({
                ...g,
                tasks: g.tasks.map((t) => (t.id === id ? { ...t, pinned: !t.pinned } : t)),
              }))
            }
            onMenu={(id) => setMenu({ scope: "task", id })}
            onEdit={(id) => setModal({ kind: "task", id })}
            onDelete={(id) =>
              patchGoal(openGoal.id, (g) => ({ ...g, tasks: g.tasks.filter((t) => t.id !== id) }))
            }
            onDragStart={(id) => setDrag({ scope: "task", id })}
            onDrop={onDropTask}
          />
        ) : sorted.length === 0 ? (
          <p className="mt-16 text-center text-[#8aa0a8]">هنوز هدفی نداری. با دکمه به‌علاوه یکی بساز.</p>
        ) : (
          <div className="mt-3 space-y-4">
            {sorted.map((goal) => (
              <GoalCard
                key={goal.id}
                goal={goal}
                dragging={drag?.scope === "goal" && drag.id === goal.id}
                menuOpen={menu?.scope === "goal" && menu.id === goal.id}
                onOpen={() => setOpenId(goal.id)}
                onMenu={() => setMenu({ scope: "goal", id: goal.id })}
                onPin={() => patchGoal(goal.id, (g) => ({ ...g, pinned: !g.pinned }))}
                onEdit={() => setModal({ kind: "goal", id: goal.id })}
                onDelete={() => setGoals((list) => list.filter((g) => g.id !== goal.id))}
                onDragStart={() => setDrag({ scope: "goal", id: goal.id })}
                onDrop={() => onDropGoal(goal.id)}
              />
            ))}
          </div>
        )}
      </main>

      {modal ? (
        <Editor
          modal={modal}
          goal={openGoal}
          goals={goals}
          onClose={() => setModal(null)}
          onSaveGoal={(data) => {
            if (modal.id) {
              patchGoal(modal.id, (g) => ({ ...g, ...data }));
            } else {
              setGoals((list) => [
                {
                  id: uid(),
                  tasks: [],
                  pinned: false,
                  order: list.length,
                  ...data,
                },
                ...list,
              ]);
            }
            setModal(null);
          }}
          onSaveTask={(data) => {
            if (!openGoal) return;
            if (modal.id) {
              patchGoal(openGoal.id, (g) => ({
                ...g,
                tasks: g.tasks.map((t) => (t.id === modal.id ? { ...t, ...data } : t)),
              }));
            } else {
              patchGoal(openGoal.id, (g) => ({
                ...g,
                tasks: [
                  ...g.tasks,
                  {
                    id: uid(),
                    done: false,
                    pinned: false,
                    order: g.tasks.length,
                    ...data,
                  },
                ],
              }));
            }
            setModal(null);
          }}
        />
      ) : null}
    </div>
  );
}

function GoalCard({
  goal,
  dragging,
  menuOpen,
  onOpen,
  onMenu,
  onPin,
  onEdit,
  onDelete,
  onDragStart,
  onDrop,
}: {
  goal: Goal;
  dragging: boolean;
  menuOpen: boolean;
  onOpen: () => void;
  onMenu: () => void;
  onPin: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onDragStart: () => void;
  onDrop: () => void;
}) {
  const pct = progressOf(goal);
  const left = daysLeft(goal.deadline);
  const done = goal.tasks.filter((t) => t.done).length;
  return (
    <article
      className={`relative rounded-[28px] bg-white px-4 py-5 shadow-[0_8px_24px_rgba(22,48,58,0.04)] ${dragging ? "drag-ghost" : ""}`}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        onDrop();
      }}
    >
      <div className="flex items-start gap-3">
        <div className="flex items-center gap-1 pt-1 text-[#b7c7cd]">
          <button
            draggable
            aria-label="جابه‌جایی"
            className="grid h-8 w-6 cursor-grab place-items-center active:cursor-grabbing"
            onDragStart={(e) => {
              e.dataTransfer.effectAllowed = "move";
              onDragStart();
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <Grip />
          </button>
          <Ring value={pct} />
        </div>
        <button className="min-w-0 flex-1 text-right" onClick={onOpen}>
          <h2 className="text-[22px] leading-8 font-extrabold text-[#17323c]">{goal.title}</h2>
          <div className="mt-2 flex flex-wrap justify-end gap-2">
            {goal.active ? <Chip tone="mint">فعال</Chip> : <Chip tone="muted">متوقف</Chip>}
            <Chip tone={goal.priority === "high" ? "rose" : goal.priority === "low" ? "muted" : "amber"}>
              {PRIORITY_LABEL[goal.priority]}
            </Chip>
            {goal.pinned ? <Chip tone="mint">پین</Chip> : null}
          </div>
        </button>
        <button
          className="grid h-8 w-8 place-items-center text-[#9eb0b6]"
          aria-label="منو"
          onClick={(e) => {
            e.stopPropagation();
            onMenu();
          }}
        >
          <Dots />
        </button>
      </div>
      <div className="mt-5 flex items-center justify-between text-[13px] text-[#8ea3aa]">
        <span>{left === null ? "بدون ددلاین" : left < 0 ? `${fa(Math.abs(left))} روز گذشته` : `${fa(left)} روز باقی‌مونده`}</span>
        <span>{pct === 0 ? "تازه آغاز شده" : `${fa(pct)}٪ پیش رفته`}</span>
      </div>
      {goal.tasks.length > 0 ? (
        <p className="mt-3 text-left text-[13px] text-[#7f969d]">
          {fa(done)} از {fa(goal.tasks.length)} مورد انجام شده
        </p>
      ) : null}
      {menuOpen ? (
        <MenuBox
          pinned={goal.pinned}
          onPin={onPin}
          onEdit={onEdit}
          onDelete={onDelete}
        />
      ) : null}
    </article>
  );
}

function TaskList({
  goal,
  dragId,
  menuId,
  onBack,
  onToggle,
  onPin,
  onMenu,
  onEdit,
  onDelete,
  onDragStart,
  onDrop,
}: {
  goal: Goal;
  dragId: string | null;
  menuId: string | null;
  onBack: () => void;
  onToggle: (id: string) => void;
  onPin: (id: string) => void;
  onMenu: (id: string) => void;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
  onDragStart: (id: string) => void;
  onDrop: (id: string) => void;
}) {
  const tasks = sortItems(goal.tasks);
  const pct = progressOf(goal);
  return (
    <div className="mt-2">
      <button className="mb-3 text-[13px] font-semibold text-[#12a085]" onClick={onBack}>
        بازگشت به اهداف
      </button>
      <div className="mb-4 rounded-[28px] bg-white p-4">
        <div className="flex items-center gap-3">
          <Ring value={pct} />
          <div>
            <h2 className="text-[20px] font-extrabold">{goal.title}</h2>
            <p className="text-[13px] text-[#8ea3aa]">{fa(pct)}٪ انجام شده</p>
          </div>
        </div>
      </div>
      {tasks.length === 0 ? (
        <p className="mt-10 text-center text-[#8aa0a8]">کاری داخل این هدف نیست. با به‌علاوه اضافه کن.</p>
      ) : (
        <div className="space-y-3">
          {tasks.map((task) => (
            <TaskRow
              key={task.id}
              task={task}
              dragging={dragId === task.id}
              menuOpen={menuId === task.id}
              onToggle={() => onToggle(task.id)}
              onPin={() => onPin(task.id)}
              onMenu={() => onMenu(task.id)}
              onEdit={() => onEdit(task.id)}
              onDelete={() => onDelete(task.id)}
              onDragStart={() => onDragStart(task.id)}
              onDrop={() => onDrop(task.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function TaskRow({
  task,
  dragging,
  menuOpen,
  onToggle,
  onPin,
  onMenu,
  onEdit,
  onDelete,
  onDragStart,
  onDrop,
}: {
  task: Task;
  dragging: boolean;
  menuOpen: boolean;
  onToggle: () => void;
  onPin: () => void;
  onMenu: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onDragStart: () => void;
  onDrop: () => void;
}) {
  const left = daysLeft(task.deadline);
  return (
    <div
      className={`relative flex items-start gap-2 rounded-2xl bg-white px-3 py-3 shadow-[0_6px_16px_rgba(22,48,58,0.04)] ${dragging ? "drag-ghost" : ""} ${task.done ? "opacity-60" : ""}`}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        onDrop();
      }}
    >
      <button
        draggable
        aria-label="جابه‌جایی کار"
        className="mt-1 grid h-8 w-6 cursor-grab place-items-center text-[#b7c7cd]"
        onDragStart={(e) => {
          e.dataTransfer.effectAllowed = "move";
          onDragStart();
        }}
      >
        <Grip />
      </button>
      <button
        aria-label={task.done ? "انجام‌نشده" : "انجام شد"}
        onClick={onToggle}
        className={`mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 ${task.done ? "border-[#12a085] bg-[#12a085] text-white" : "border-[#c5d5da]"}`}
      >
        {task.done ? "✓" : ""}
      </button>
      <div className="min-w-0 flex-1">
        <p className={`font-semibold ${task.done ? "line-through" : ""}`}>{task.title}</p>
        <p className="mt-1 text-[12px] text-[#8ea3aa]">
          {task.pinned ? "پین‌شده · " : ""}
          {left === null ? "بدون ددلاین" : left < 0 ? `${fa(Math.abs(left))} روز گذشته` : `${fa(left)} روز مانده`}
          {task.note ? ` · ${task.note}` : ""}
        </p>
      </div>
      <button className="grid h-8 w-8 place-items-center text-[#9eb0b6]" onClick={onMenu} aria-label="منوی کار">
        <Dots />
      </button>
      {menuOpen ? <MenuBox pinned={task.pinned} onPin={onPin} onEdit={onEdit} onDelete={onDelete} /> : null}
    </div>
  );
}

function MenuBox({
  pinned,
  onPin,
  onEdit,
  onDelete,
}: {
  pinned: boolean;
  onPin: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  return (
    <div
      className="absolute top-12 left-3 z-30 w-36 overflow-hidden rounded-2xl border border-[#e6eef0] bg-white text-right shadow-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <MenuItem onClick={onPin}>{pinned ? "برداشتن پین" : "پین کردن"}</MenuItem>
      <MenuItem onClick={onEdit}>ویرایش</MenuItem>
      <MenuItem danger onClick={onDelete}>
        حذف
      </MenuItem>
    </div>
  );
}

function MenuItem({
  children,
  onClick,
  danger,
}: {
  children: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      className={`block w-full px-3 py-2.5 text-[13px] font-medium hover:bg-[#f4f8f8] ${danger ? "text-[#d14343]" : "text-[#17323c]"}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
}

function Editor({
  modal,
  goal,
  goals,
  onClose,
  onSaveGoal,
  onSaveTask,
}: {
  modal: { kind: "goal" | "task"; id?: string };
  goal: Goal | null;
  goals: Goal[];
  onClose: () => void;
  onSaveGoal: (data: Pick<Goal, "title" | "priority" | "deadline" | "active">) => void;
  onSaveTask: (data: Pick<Task, "title" | "deadline" | "note">) => void;
}) {
  const existingGoal = modal.kind === "goal" ? goals.find((g) => g.id === modal.id) : undefined;
  const existingTask = modal.kind === "task" ? goal?.tasks.find((t) => t.id === modal.id) : undefined;
  const [title, setTitle] = useState(existingGoal?.title ?? existingTask?.title ?? "");
  const [deadline, setDeadline] = useState(existingGoal?.deadline ?? existingTask?.deadline ?? "");
  const [priority, setPriority] = useState<Priority>(existingGoal?.priority ?? "medium");
  const [note, setNote] = useState(existingTask?.note ?? "");
  const [active, setActive] = useState(existingGoal?.active ?? true);

  return (
    <Sheet title={modal.id ? "ویرایش" : modal.kind === "goal" ? "هدف جدید" : "کار جدید"} onClose={onClose}>
      <label className="mb-3 block text-[13px] text-[#607780]">
        عنوان
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="mt-1 w-full rounded-xl border border-[#e1ebed] bg-[#f7fbfb] px-3 py-2.5 text-[15px] text-[#17323c] outline-none"
        />
      </label>
      <label className="mb-3 block text-[13px] text-[#607780]">
        ددلاین
        <input
          type="date"
          value={deadline ?? ""}
          onChange={(e) => setDeadline(e.target.value)}
          className="mt-1 w-full rounded-xl border border-[#e1ebed] bg-[#f7fbfb] px-3 py-2.5 text-[15px] outline-none"
        />
      </label>
      {modal.kind === "goal" ? (
        <>
          <label className="mb-3 block text-[13px] text-[#607780]">
            اولویت
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as Priority)}
              className="mt-1 w-full rounded-xl border border-[#e1ebed] bg-[#f7fbfb] px-3 py-2.5 outline-none"
            >
              <option value="low">کم</option>
              <option value="medium">متوسط</option>
              <option value="high">زیاد</option>
            </select>
          </label>
          <label className="mb-4 flex items-center gap-2 text-[14px]">
            <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
            فعال
          </label>
        </>
      ) : (
        <label className="mb-4 block text-[13px] text-[#607780]">
          یادداشت
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="mt-1 w-full rounded-xl border border-[#e1ebed] bg-[#f7fbfb] px-3 py-2.5 outline-none"
            rows={3}
          />
        </label>
      )}
      <button
        className="w-full rounded-2xl bg-[#12a085] py-3 font-bold text-white"
        onClick={() => {
          if (!title.trim()) return;
          if (modal.kind === "goal") {
            onSaveGoal({ title: title.trim(), priority, deadline: deadline || null, active });
          } else {
            onSaveTask({ title: title.trim(), deadline: deadline || null, note: note.trim() });
          }
        }}
      >
        ذخیره
      </button>
    </Sheet>
  );
}

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/35" onClick={onClose}>
      <div
        className="w-full max-w-[480px] rounded-t-3xl bg-white p-5 pb-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-[18px] font-extrabold">{title}</h3>
          <button className="text-[#8aa0a8]" onClick={onClose}>
            بستن
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Ring({ value }: { value: number }) {
  const r = 26;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.min(100, Math.max(0, value)) / 100) * c;
  return (
    <svg width="72" height="72" viewBox="0 0 72 72" aria-hidden>
      <circle className="ring-track" cx="36" cy="36" r={r} fill="none" strokeWidth="6" />
      <circle
        cx="36"
        cy="36"
        r={r}
        fill="none"
        stroke="#7fd3c2"
        strokeWidth="6"
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={offset}
        transform="rotate(-90 36 36)"
      />
      <text x="36" y="40" textAnchor="middle" fontSize="13" fill="#9eb0b6" fontFamily="Vazirmatn, sans-serif">
        {fa(value)}٪
      </text>
    </svg>
  );
}

function Chip({ children, tone }: { children: ReactNode; tone: "mint" | "amber" | "muted" | "rose" }) {
  const map = {
    mint: "bg-[#d8f7ee] text-[#14967d]",
    amber: "bg-[#ffe7b8] text-[#c98412]",
    muted: "bg-[#eef3f4] text-[#6d848c]",
    rose: "bg-[#ffe1e1] text-[#d14343]",
  };
  return <span className={`rounded-lg px-2.5 py-1 text-[12px] font-semibold ${map[tone]}`}>{children}</span>;
}

function Plus() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6">
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}
function Dots() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
      <circle cx="12" cy="5" r="1.6" />
      <circle cx="12" cy="12" r="1.6" />
      <circle cx="12" cy="19" r="1.6" />
    </svg>
  );
}
function Grip() {
  return (
    <svg width="14" height="18" viewBox="0 0 14 18" fill="currentColor">
      <circle cx="4" cy="3" r="1.3" />
      <circle cx="10" cy="3" r="1.3" />
      <circle cx="4" cy="9" r="1.3" />
      <circle cx="10" cy="9" r="1.3" />
      <circle cx="4" cy="15" r="1.3" />
      <circle cx="10" cy="15" r="1.3" />
    </svg>
  );
}
