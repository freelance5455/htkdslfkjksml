import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpenText, Library, Signpost, SquareCheckBig } from "lucide-react";
import { CHAPTERS } from "@/data/curriculum";
import { CREDIT } from "@/data/credit";
import { QUESTIONS } from "@/data/quiz";
import { SIGNS } from "@/data/signs";
import { useStudy } from "@/lib/study-store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const read = useStudy((s) => s.read.length);
  const learned = useStudy((s) => s.learned.length);
  const best = useStudy((s) => s.best);
  const exams = useStudy((s) => s.exams);

  return (
    <div className="space-y-8">
      <section className="border-b border-line pb-6">
        <p className="text-sm text-primary">Teoria della patente B</p>
        <h1 className="mt-1 text-4xl font-semibold leading-tight md:text-5xl">الرخصة الإيطالية</h1>
        <p className="mt-3 max-w-2xl text-lg leading-relaxed text-muted">
          المنهج كله بالإيطالي، وتحته المعنى بالعربي. الإشارات مرسومة باسمها وشرحها، وأسئلة صح أو خطأ على طريقة الامتحان. اضغط أي كلمة إيطالية إذا أردت معناها أو سؤالاً عنها.
        </p>
        <p className="mt-4 text-base font-semibold">{CREDIT}</p>
      </section>

      <section className="grid grid-cols-3 gap-2 rounded-2xl border border-line bg-surface p-3 text-center">
        <Stat n="30" label="سؤالًا" />
        <Stat n="20" label="دقيقة" />
        <Stat n="3" label="أخطاء كحد أقصى" />
      </section>

      <section className="grid gap-3 sm:grid-cols-2">
        <Door to="/manuale" icon={BookOpenText} kicker="25 فصلًا" title="المنهج" text="من تعريفات الطريق حتى الإطارات والكحول والحوادث." />
        <Door to="/segnali" icon={Signpost} kicker={`${SIGNS.length} إشارة`} title="الإشارات" text="خطر، منع، إلزام، أولوية، أرضية، إشارات وأعمال." />
        <Door to="/esame" icon={SquareCheckBig} kicker={`${QUESTIONS.length} سؤالًا`} title="الامتحان" text="محاكاة 30 سؤالًا، أو تدريب حسب الفصل، مع الشرح بالعربي." />
        <Door to="/glossario" icon={Library} kicker="اضغط الكلمة" title="القاموس" text="معنى الكلمة، وشرح إضافي إذا سألت، وأسئلة حفظتها." />
      </section>

      <section className="grid gap-3 sm:grid-cols-3">
        <Mini label="فصول مقروءة" value={`${read} / ${CHAPTERS.length}`} />
        <Mini label="إشارات راجعتها" value={`${learned} / ${SIGNS.length}`} />
        <Mini label="أفضل محاكاة" value={best === null ? "لم تبدأ" : `${best} / 30`} hint={exams ? `${exams} محاولة` : "النجاح من 27"} />
      </section>

      <section className="rounded-2xl bg-ink px-4 py-4 text-surface">
        <h2 className="text-lg font-semibold">أرقام تسقط كثيرًا</h2>
        <ul className="mt-3 space-y-2 text-sm leading-relaxed">
          <li>السرعة: 50 داخل العمران، 90 ثانوي، 110 رئيسي، 130 أوتوسترادا. المطر: 110 و90 للأخيرين.</li>
          <li>حديث الرخصة 3 سنوات: 100 أوتوسترادا، 90 رئيسي، كحول صفر، نقاط مضاعفة، قدرة 105 كيلوواط و75 كيلوواط/طن.</li>
          <li>مسافة ثانية عند 130 حوالي 36 مترًا لا 15. تقدير الناشف: مربع عشرات السرعة.</li>
          <li>وقوف: 5 أمتار من التقاطع داخل المدينة، و15 مترًا من لوحة الحافلة إن لم تُرسم المساحة.</li>
        </ul>
      </section>
      <p className="text-sm text-muted md:hidden">{CREDIT}</p>
    </div>
  );
}

function Stat({ n, label }: { n: string; label: string }) {
  return (
    <div>
      <p className="text-2xl font-semibold text-primary">{n}</p>
      <p className="text-sm text-muted">{label}</p>
    </div>
  );
}

function Mini({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-2xl border border-line bg-surface px-4 py-3">
      <p className="text-sm text-muted">{label}</p>
      <p className="text-xl font-semibold">{value}</p>
      {hint ? <p className="text-xs text-muted">{hint}</p> : null}
    </div>
  );
}

function Door({
  to,
  icon: Icon,
  kicker,
  title,
  text,
}: {
  to: "/" | "/manuale" | "/segnali" | "/esame" | "/glossario";
  icon: typeof BookOpenText;
  kicker: string;
  title: string;
  text: string;
}) {
  return (
    <Link to={to} className="rounded-2xl border border-line bg-surface p-4 transition hover:border-primary">
      <Icon size={20} className="text-primary" aria-hidden />
      <p className="mt-3 text-xs text-muted">{kicker}</p>
      <h2 className="text-2xl font-semibold">{title}</h2>
      <p className="mt-1 text-sm leading-relaxed text-muted">{text}</p>
    </Link>
  );
}
