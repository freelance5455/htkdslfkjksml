import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [Game, setGame] = useState<null | typeof import("@/game/stage").Game>(null);
  useEffect(() => {
    let live = true;
    void import("@/game/stage").then((mod) => {
      if (live) setGame(() => mod.Game);
    });
    return () => {
      live = false;
    };
  }, []);
  if (!Game) {
    return (
      <main className="boot">
        <div>
          <p className="eyebrow">Lumenrest</p>
          <h1>Palmon</h1>
        </div>
      </main>
    );
  }
  return <Game />;
}
