import { createFileRoute } from "@tanstack/react-router";
import { CricketApp } from "@/components/cricket-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <CricketApp />;
}
