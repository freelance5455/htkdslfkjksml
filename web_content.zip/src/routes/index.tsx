import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/treino/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Shell />;
}
