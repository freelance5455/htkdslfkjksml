import { createFileRoute } from "@tanstack/react-router";
import { TodayView } from "@/components/planner/views/today";

export const Route = createFileRoute("/")({
  component: TodayView,
});
