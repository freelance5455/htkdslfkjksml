import { createFileRoute } from "@tanstack/react-router";
import { SkyChirp } from "@/components/sky-chirp";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <SkyChirp />;
}
