import { createFileRoute } from "@tanstack/react-router";
import { PuroApp } from "@/components/puro-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <PuroApp />;
}
