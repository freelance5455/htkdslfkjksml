import { createFileRoute } from "@tanstack/react-router";
import { EscapeGame } from "@/components/escape/escape-game";

export const Route = createFileRoute("/")({
  component: EscapeGame,
});
