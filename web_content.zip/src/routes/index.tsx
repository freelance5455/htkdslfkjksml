import { createFileRoute } from "@tanstack/react-router";
import { HomeScreen } from "@/components/HomeScreen";
import { ResultsShell } from "@/components/ResultsShell";
import { ScanOverlay } from "@/components/ScanOverlay";
import { useCaliber } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const phase = useCaliber((s) => s.phase);
  if (phase === "scanning") return <ScanOverlay />;
  if (phase === "results") return <ResultsShell />;
  return <HomeScreen />;
}
