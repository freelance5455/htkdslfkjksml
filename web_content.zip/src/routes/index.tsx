import { createFileRoute } from "@tanstack/react-router";
import { LakshaApp } from "@/components/laksha-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <LakshaApp />;
}
