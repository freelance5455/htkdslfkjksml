import { createFileRoute, Link } from "@tanstack/react-router";
import { format } from "date-fns";
import { useProjects } from "@/components/storyboard/use-projects";
import { useStory, visibleProjects } from "@/lib/storyboard/store";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const ready = useProjects();
  const projects = useStory((state) => state.projects);
  const recent = visibleProjects(projects).slice(0, 4);

  return (
    <div className="mx-auto grid max-w-3xl gap-8">
      <section className="grid gap-4">
        <p className="text-xs font-medium tracking-widest text-muted uppercase">Product storyboards</p>
        <h1 className="font-display text-4xl leading-tight font-medium tracking-tight sm:text-5xl">
          Foto produk yang sama, scene yang berbeda.
        </h1>
        <p className="max-w-xl text-base text-muted">
          Upload beberapa foto satu produk. Susun cerita, lalu salin prompt gambar dan prompt video tanpa mengubah bentuk produk.
        </p>
        <Link
          to="/create"
          className="inline-flex min-h-14 w-full items-center justify-center rounded-md bg-accent px-4 text-base font-medium text-accent-fg sm:w-fit"
        >
          Create storyboard
        </Link>
      </section>
      <ol className="grid gap-3 sm:grid-cols-2">
        {[
          ["01", "Upload product", "Satu sampai sepuluh foto. Semuanya satu produk."],
          ["02", "Product & story", "Kategori, campaign, gaya foto, dan jumlah scene."],
          ["03", "Generate storyboard", "Setiap scene menjaga bentuk, warna, logo, dan konstruksi."],
          ["04", "Copy & download", "Prompt gambar, prompt video, atau unduh fotonya."],
        ].map(([n, title, body]) => (
          <li key={n} className="rounded-xl border border-line bg-surface p-4">
            <p className="text-xs font-medium text-muted tabular-nums">{n}</p>
            <h2 className="mt-2 font-medium">{title}</h2>
            <p className="mt-1 text-sm text-muted">{body}</p>
          </li>
        ))}
      </ol>
      <section className="grid gap-3">
        <h2 className="font-display text-2xl font-medium tracking-tight">My storyboards</h2>
        {!ready ? <p className="text-sm text-muted">Memuat…</p> : null}
        {ready && recent.length === 0 ? (
          <p className="text-sm text-muted">Belum ada storyboard. Mulai dari foto produk.</p>
        ) : null}
        <ul className="grid gap-2">
          {recent.map((project) => (
            <li key={project.id}>
              <Link
                to="/storyboards/$id"
                params={{ id: project.id }}
                className="flex items-center gap-3 rounded-xl border border-line bg-surface p-3"
              >
                <span className="frame-1-1 block w-16 shrink-0 overflow-hidden rounded-sm bg-bg">
                  {project.refs[0] ? <img src={project.refs[0].dataUrl} alt="" className="h-full w-full object-contain" /> : null}
                </span>
                <span className="grid gap-1">
                  <span className="font-medium">{project.name}</span>
                  <span className="text-sm text-muted">
                    {project.scenes.length || project.sceneCount} scene · {format(project.updatedAt, "d MMM yyyy")}
                  </span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
