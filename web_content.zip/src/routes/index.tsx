import { createFileRoute } from "@tanstack/react-router";
import { App } from "@/components/calculator/App";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <App />;
}
