import { createFileRoute } from "@tanstack/react-router";
import { EframeApp } from "@/components/eframe/eframe-app";

export const Route = createFileRoute("/")({ component: EframeApp });
