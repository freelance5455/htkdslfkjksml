import { useCallback, useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AppsPanel } from "@/components/aegis/apps-panel";
import { CheckupPanel } from "@/components/aegis/checkup-panel";
import { FilesPanel } from "@/components/aegis/files-panel";
import { SecuredHero, Wordmark } from "@/components/aegis/secured-hero";
import { assessAppName, combineAssessment } from "@/lib/security/apps";
import { questionsFor } from "@/lib/security/audit";
import { getCheckSpecs, runSpec } from "@/lib/security/device-checks";
import { detectEnvironment, pageIsFramed } from "@/lib/security/environment";
import { clampScore, devicePercent, filesPercent } from "@/lib/security/score";
import type { Answer, DeviceReport, Environment, FileReport, LinkReport } from "@/lib/security/types";
import { cn } from "@/lib/cn";

const STORAGE_KEY = "aegis-checkup-v1";

type Tab = "device" | "apps" | "files";

type Saved = {
  report: DeviceReport | null;
  answers: Record<string, Answer>;
  files: FileReport[];
  links: LinkReport[];
  appQuery: string;
  flagIds: string[];
};

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [tab, setTab] = useState<Tab>("device");
  const [env, setEnv] = useState<Environment | null>(null);
  const [framed, setFramed] = useState(false);
  const [report, setReport] = useState<DeviceReport | null>(null);
  const [running, setRunning] = useState(false);
  const [step, setStep] = useState<string | null>(null);
  const [doneIds, setDoneIds] = useState<string[]>([]);
  const [answers, setAnswers] = useState<Record<string, Answer>>({});
  const [files, setFiles] = useState<FileReport[]>([]);
  const [links, setLinks] = useState<LinkReport[]>([]);
  const [appQuery, setAppQuery] = useState("");
  const [flagIds, setFlagIds] = useState<string[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setEnv(detectEnvironment());
    setFramed(pageIsFramed());
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as Partial<Saved>;
        if (saved.report) setReport(saved.report);
        if (saved.answers) setAnswers(saved.answers);
        if (saved.files) setFiles(saved.files);
        if (saved.links) setLinks(saved.links);
        if (typeof saved.appQuery === "string") setAppQuery(saved.appQuery);
        if (saved.flagIds) setFlagIds(saved.flagIds);
      }
    } catch {
      /* ignore a broken save */
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!loaded) return;
    const saved: Saved = { report, answers, files, links, appQuery, flagIds };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
  }, [loaded, report, answers, files, links, appQuery, flagIds]);

  const runScan = useCallback(async () => {
    setTab("device");
    setRunning(true);
    setDoneIds([]);
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const checks = [];
    for (const spec of getCheckSpecs()) {
      setStep(spec.label);
      checks.push(await runSpec(spec));
      setDoneIds((current) => [...current, spec.id]);
      if (!reduce) await new Promise((resolve) => setTimeout(resolve, 140));
    }
    const environment = detectEnvironment();
    setEnv(environment);
    const score = clampScore(checks.reduce((sum, check) => sum + check.points, 0));
    setReport({ at: Date.now(), environment, checks, score });
    setStep(null);
    setRunning(false);
  }, []);

  const questions = questionsFor(env?.os ?? report?.environment.os ?? "computer");
  const device = report ? devicePercent(report.score, answers, questions) : null;
  const assessment = useMemo(
    () => combineAssessment(assessAppName(appQuery), flagIds),
    [appQuery, flagIds],
  );
  const apps = assessment?.percent ?? null;
  const fileScore = filesPercent(files, links);

  const caption = !report
    ? ""
    : Object.keys(answers).length === 0
      ? "Browser checkup only. The questions under Device can raise or lower this."
      : "Browser checkup plus the device questions you answered.";

  return (
    <main className="mx-auto min-h-screen max-w-3xl px-4 pt-6 pb-16 sm:px-6 sm:pt-10">
      <header className="mb-6 flex items-center justify-between gap-3">
        <Wordmark />
        {env ? (
          <p className="rounded-full bg-card px-3 py-2 text-sm text-ink shadow-card">{env.osLabel}</p>
        ) : (
          <p className="text-sm text-muted">Phone or computer</p>
        )}
      </header>

      <SecuredHero
        percent={device}
        caption={caption}
        running={running}
        step={step}
        doneIds={doneIds}
        device={device}
        apps={apps}
        files={fileScore}
        onScan={() => void runScan()}
      />

      <div className="mt-6 grid grid-cols-3 gap-1 rounded-2xl bg-paper-deep p-1" role="tablist">
        {(
          [
            ["device", "Device"],
            ["apps", "Apps"],
            ["files", "Files"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={tab === id}
            onClick={() => setTab(id)}
            className={cn(
              "h-11 rounded-xl text-sm font-medium",
              tab === id ? "bg-card text-ink shadow-card" : "text-muted",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "device" ? (
        <CheckupPanel
          report={report}
          os={env?.os ?? report?.environment.os ?? null}
          answers={answers}
          onAnswer={(id, value) => setAnswers((current) => ({ ...current, [id]: value }))}
          devicePercent={device}
          framed={framed}
        />
      ) : null}

      {tab === "apps" ? (
        <AppsPanel
          query={appQuery}
          onQuery={setAppQuery}
          flagIds={flagIds}
          onToggleFlag={(id) =>
            setFlagIds((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]))
          }
          assessment={assessment}
        />
      ) : null}

      {tab === "files" ? (
        <FilesPanel
          files={files}
          links={links}
          onFiles={setFiles}
          onLinks={setLinks}
          filesPercent={fileScore}
        />
      ) : null}

      <footer className="mt-12 border-t border-line pt-6">
        <p className="max-w-xl text-sm leading-relaxed text-muted">
          90% and above means nothing Aegis could see looks harmful. A lower number always names the reason.
          This is a checkup, not a replacement for Play Protect or the protections built into the phone.
        </p>
      </footer>
    </main>
  );
}
