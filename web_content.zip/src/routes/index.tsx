import { createFileRoute } from "@tanstack/react-router";
import { LibertyDrive } from "@/components/liberty-drive";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <LibertyDrive />;
}
