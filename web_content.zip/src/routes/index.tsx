import { createFileRoute } from "@tanstack/react-router";
import { Painel } from "@/components/painel";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Painel />;
}
