import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CalendarCheck, ShieldCheck, Wallet } from "lucide-react";
import { CATALOG, lineCents, type Service } from "@/lib/catalog";
import { brl } from "@/lib/format";
import { usePublicProfile } from "@/lib/vitrine-context";
import { ServiceGlyph } from "@/components/service-icon";

export const Route = createFileRoute("/")({
  component: Home,
});

function fromPrice(service: Service, prices: Record<string, number>) {
  return Math.min(...service.options.map((option) => lineCents(option.id, option.cents, prices)));
}

function Home() {
  const profile = usePublicProfile();
  const services = CATALOG.filter((service) => !profile.disabled.includes(service.id));
  const who = profile.receiverName || "quem faz o serviço";

  return (
    <main>
      <section className="mx-auto grid max-w-5xl items-end gap-10 px-4 py-12 sm:py-16 lg:grid-cols-[1.3fr_0.7fr]">
        <div>
          <p className="text-sm font-semibold tracking-wide text-primary uppercase">Serviço de casa</p>
          <h1 className="mt-3 font-display text-4xl leading-tight font-semibold sm:text-6xl">
            Precisa de alguém em casa? O preço já está fechado.
          </h1>
          <p className="mt-5 max-w-xl text-lg text-muted">
            Limpeza, reparo, aula, pet, companhia e computador. Você escolhe o dia, vê o valor e paga por PIX direto
            para {who}. Sem taxa escondida e sem dinheiro parado no meio.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              to="/agendar"
              className="inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 font-semibold text-primary-fg hover:bg-primary-deep"
            >
              Agendar
              <ArrowRight className="size-4" />
            </Link>
            <a
              href="#seguranca"
              className="inline-flex min-h-11 items-center justify-center rounded-md border border-line bg-surface px-5 font-semibold"
            >
              Como é seguro
            </a>
          </div>
        </div>
        <aside className="rounded-lg border border-line bg-surface p-5">
          <p className="text-xs font-semibold tracking-wide text-muted uppercase">Exemplo de pedido</p>
          <p className="mt-4 font-display text-2xl">Limpeza da casa</p>
          <p className="text-sm text-muted">Casa, 4 horas · quinta, 14h</p>
          <p className="mt-4 font-display text-4xl tabular-nums text-accent">{brl(28000)}</p>
          <ul className="mt-4 space-y-2 text-sm">
            <li>Preço escrito antes de sair de casa</li>
            <li>PIX no nome de {who}</li>
            <li>Cancela até 12 horas antes, sem custo</li>
          </ul>
        </aside>
      </section>

      <section id="servicos" className="mx-auto max-w-5xl px-4 pb-4">
        <div className="flex items-end justify-between gap-4 border-b border-line pb-4">
          <h2 className="font-display text-3xl sm:text-4xl">O que dá para pedir</h2>
          <p className="hidden text-sm text-muted sm:block">Valor da visita, sem surpresa no fim.</p>
        </div>
        <ul>
          {services.map((service, index) => (
            <li key={service.id} className="border-b border-line">
              <Link
                to="/agendar"
                search={{ servico: service.id }}
                className="flex flex-col gap-3 py-5 sm:flex-row sm:items-center sm:justify-between"
              >
                <span className="flex items-start gap-4">
                  <span className="mt-1 text-sm tabular-nums text-muted">{String(index + 1).padStart(2, "0")}</span>
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-md bg-surface-2 text-primary">
                    <ServiceGlyph icon={service.icon} className="size-5" />
                  </span>
                  <span>
                    <span className="block font-display text-2xl">{service.name}</span>
                    <span className="mt-1 block max-w-lg text-sm text-muted">{service.need}</span>
                  </span>
                </span>
                <span className="pl-8 text-left sm:pl-0 sm:text-right">
                  <span className="block text-xs text-muted">a partir de</span>
                  <span className="font-display text-2xl tabular-nums">{brl(fromPrice(service, profile.prices))}</span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
        {services.length === 0 ? (
          <p className="py-8 text-muted">Nenhum serviço aberto no momento.</p>
        ) : null}
      </section>

      <section id="seguranca" className="mx-auto max-w-5xl px-4 py-12">
        <div className="rounded-lg bg-primary px-5 py-8 text-primary-fg sm:px-8">
          <div className="flex items-center gap-2 text-sm font-semibold tracking-wide uppercase">
            <ShieldCheck className="size-4" />
            Seguro dos dois lados
          </div>
          <h2 className="mt-3 max-w-xl font-display text-3xl sm:text-4xl">
            O combinado fica escrito. O dinheiro não passa por um estranho.
          </h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2">
            <p>
              <span className="block font-semibold">Preço antes</span>
              <span className="mt-1 block text-sm opacity-90">
                O que está na lista entra na conta. O que não está, fica de fora.
              </span>
            </p>
            <p>
              <span className="block font-semibold">PIX direto</span>
              <span className="mt-1 block text-sm opacity-90">
                Você confere o nome do recebedor no banco. Se for outro nome, não paga.
              </span>
            </p>
            <p>
              <span className="block font-semibold">Horário no seu nome</span>
              <span className="mt-1 block text-sm opacity-90">
                Cancelou até 12 horas antes, sem cobrança. Depois disso, o horário já foi guardado.
              </span>
            </p>
            <p>
              <span className="block font-semibold">Companhia não é saúde</span>
              <span className="mt-1 block text-sm opacity-90">
                Visita e recado. Não aplica remédio, não faz banho, não substitui enfermeiro.
              </span>
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-5xl gap-8 px-4 pb-4 sm:grid-cols-3">
        {[
          { icon: CalendarCheck, title: "Escolhe o dia", text: "Serviço, horário e o que está incluso, numa tela só." },
          { icon: Wallet, title: "Paga o valor da tela", text: "QR ou copia e cola. O comprovante fica no seu banco." },
          { icon: ShieldCheck, title: "A pessoa confirma", text: "O pedido segue no WhatsApp de quem vai fazer." },
        ].map((step) => (
          <div key={step.title} className="border-t border-line pt-4">
            <step.icon className="size-5 text-primary" />
            <h3 className="mt-3 font-display text-2xl">{step.title}</h3>
            <p className="mt-2 text-sm text-muted">{step.text}</p>
          </div>
        ))}
      </section>

      <section className="mx-auto max-w-5xl px-4 py-12">
        <div className="rounded-lg border border-line bg-surface p-6 sm:p-8">
          <p className="text-sm font-semibold tracking-wide text-accent uppercase">Para quem faz o serviço</p>
          <h2 className="mt-2 max-w-2xl font-display text-3xl sm:text-4xl">
            Um jeito simples de cobrar por trabalho que as pessoas já pagam.
          </h2>
          <p className="mt-4 max-w-2xl text-muted">
            Não é investimento, não é renda automática e este site não segura o dinheiro de ninguém. Você coloca a sua
            chave PIX, manda o link e o valor do serviço cai na sua conta. A caixa só organiza a agenda.
          </p>
          <Link
            to="/negocio"
            className="mt-6 inline-flex min-h-11 items-center font-semibold text-primary"
          >
            Abrir a caixa
            <ArrowRight className="ml-2 size-4" />
          </Link>
        </div>
      </section>
    </main>
  );
}
