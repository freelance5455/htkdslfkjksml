import { createFileRoute } from "@tanstack/react-router";
import { Bareline } from "@/components/bareline";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Bareline />;
}
