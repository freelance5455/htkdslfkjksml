import { createFileRoute } from "@tanstack/react-router";
import { FrierenShell } from "@/components/frieren/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <FrierenShell />;
}
