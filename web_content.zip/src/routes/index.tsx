import { createFileRoute } from "@tanstack/react-router";
import { FootballApp } from "@/components/football/app";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <FootballApp />;
}
