import { createFileRoute } from "@tanstack/react-router";
import { VaultApp } from "@/components/vault/vault-app";

export const Route = createFileRoute("/")({
  component: VaultApp,
});
