import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type PointerEvent, type ReactNode, type RefObject } from "react";
import { Coins, Lock, Maximize2, Settings, ShoppingBag, Star, Volume2, VolumeX, X } from "lucide-react";
import { mountKitchen, type EndInfo, type GameApi, type Hud, type Save } from "@/game/engine";

export const Route = createFileRoute("/")({ component: Home });

type Screen = "boot" | "start" | "play" | "pause" | "levels" | "shop" | "end";

const SHOP = [
  { id: "boots", name: "حذاء سريع", desc: "حركة أسرع في المطبخ", price: 120 },
  { id: "knife", name: "سكين حاد", desc: "التقطيع بضغطتين بدل ثلاث", price: 140 },
  { id: "fast", name: "موقد قوي", desc: "الطبخ ينضج أسرع", price: 180 },
  { id: "stove2", name: "مقلاة ثانية", desc: "الموقد يطهو غرضين معاً", price: 250 },
];

function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const apiRef = useRef<GameApi | null>(null);
  const [ready, setReady] = useState(false);
  const [screen, setScreen] = useState<Screen>("boot");
  const [hud, setHud] = useState<Hud | null>(null);
  const [toast, setToast] = useState("");
  const [end, setEnd] = useState<EndInfo | null>(null);
  const [save, setSave] = useState<Save | null>(null);
  const [n1, setN1] = useState("موزة");
  const [n2, setN2] = useState("جزرة");
  const named = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const api = mountKitchen(canvas, {
      onHud: setHud,
      onToast: setToast,
      onEnd: (info) => {
        setEnd(info);
        setScreen("end");
        setSave(apiRef.current?.getSave() ?? null);
      },
      onReady: () => {
        setReady(true);
        const s = apiRef.current?.getSave();
        if (s) setSave(s);
        setScreen((cur) => {
          if (new URLSearchParams(window.location.search).has("qa")) return "play";
          return cur === "boot" ? "start" : cur;
        });
      },
      onPauseToggle: () => {
        setScreen((cur) => (cur === "play" ? "pause" : cur));
      },
    });
    apiRef.current = api;
    return () => api.destroy();
  }, []);

  useEffect(() => {
    apiRef.current?.setPaused(screen !== "play");
  }, [screen]);

  useEffect(() => {
    if (!save || named.current) return;
    named.current = true;
    setN1(save.names[0]);
    setN2(save.names[1]);
  }, [save]);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(""), 2400);
    return () => window.clearTimeout(id);
  }, [toast]);

  function refresh() {
    const s = apiRef.current?.getSave();
    if (s) setSave(s);
  }

  function begin(i: number) {
    apiRef.current?.startLevel(i);
    setScreen("play");
    const el = document.documentElement;
    if (!document.fullscreenElement) void el.requestFullscreen?.().catch(() => undefined);
  }

  function goFull() {
    const el = document.documentElement;
    if (document.fullscreenElement) void document.exitFullscreen?.().catch(() => undefined);
    else void el.requestFullscreen?.().catch(() => undefined);
  }

  const stars = save?.stars ?? [];
  const firstOpen = stars.findIndex((n) => !n);
  const continueAt = firstOpen < 0 ? 39 : Math.max(0, firstOpen);
  const maxOpen = firstOpen < 0 ? 39 : firstOpen;

  return (
    <main className="game-root">
      <canvas ref={canvasRef} />

      {screen === "play" && hud ? (
        <div className="safe-top pointer-events-none absolute inset-x-0 top-0 z-10 flex justify-center px-3 pt-2">
          <div className="pointer-events-auto flex items-center gap-3 rounded-2xl border border-wood bg-cream/95 px-4 py-2 text-ink shadow-md">
            <div className="text-center">
              <div className="text-xs font-bold text-wood-dark">المرحلة {hud.level} / 40</div>
              <div className="text-lg font-extrabold leading-none">{formatTime(hud.time)}</div>
            </div>
            <div className="h-8 w-px bg-wood" />
            <div className="text-center text-sm font-bold">
              <div className="flex items-center justify-center gap-1">
                <Star className="size-4 fill-gold text-gold" />
                {hud.score}
                <span className="font-medium text-wood-dark">/ {hud.goal}</span>
              </div>
              <div className="flex items-center justify-center gap-1 text-xs">
                <Coins className="size-3 text-gold" />
                {hud.coins}
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {screen === "play" ? (
        <div className="absolute left-2 top-2 z-20 flex gap-2">
          <button type="button" className="grid size-11 place-items-center rounded-xl border border-wood bg-cream text-ink" onClick={goFull} aria-label="ملء الشاشة">
            <Maximize2 className="size-5" />
          </button>
          <button type="button" className="grid size-11 place-items-center rounded-xl border border-wood bg-cream text-ink" onClick={() => setScreen("pause")} aria-label="إيقاف">
            <Settings className="size-5" />
          </button>
        </div>
      ) : null}

      {toast && screen === "play" ? (
        <div className="pointer-events-none absolute inset-x-0 top-20 z-10 flex justify-center px-4">
          <p className="max-w-md rounded-full bg-ink/90 px-4 py-2 text-center text-sm font-bold text-cream">{toast}</p>
        </div>
      ) : null}

      {screen === "play" ? <Controls apiRef={apiRef} /> : null}

      {screen === "boot" ? (
        <Center>
          <p className="text-lg font-extrabold">يجهّز المطبخ…</p>
        </Center>
      ) : null}

      {screen === "start" ? (
        <Center>
          <Panel>
            <p className="text-xs font-extrabold tracking-widest text-wood-dark">مطبخ تعاوني</p>
            <h1 className="mt-1 text-4xl font-extrabold text-ink">فوضى المطبخ</h1>
            <p className="mt-2 text-sm leading-relaxed text-wood-dark">
              شيف الموز وشيف الجزرة في مطبخ واحد. حضّروا الطلب العائم في الممر قبل ما يخلص وقته.
            </p>
            <div className="mt-4 grid grid-cols-2 gap-2 text-start">
              <label className="text-xs font-bold">
                الشيف اليسار
                <input
                  className="mt-1 w-full rounded-xl border border-wood bg-cream px-3 py-2 text-base font-bold"
                  value={n1}
                  maxLength={12}
                  onChange={(e) => {
                    setN1(e.target.value);
                    apiRef.current?.setNames(e.target.value, n2);
                  }}
                />
              </label>
              <label className="text-xs font-bold">
                الشيف اليمين
                <input
                  className="mt-1 w-full rounded-xl border border-wood bg-cream px-3 py-2 text-base font-bold"
                  value={n2}
                  maxLength={12}
                  onChange={(e) => {
                    setN2(e.target.value);
                    apiRef.current?.setNames(n1, e.target.value);
                  }}
                />
              </label>
            </div>
            <ul className="mt-3 space-y-1 text-start text-sm leading-relaxed text-ink">
              <li>الموز: WASD وزر اليد F والرمي G والتسليم H.</li>
              <li>الجزرة: الأسهم، Enter، Shift، والنقطة.</li>
              <li>أو عصا التحكم أسفل الشاشة لكل شيف.</li>
            </ul>
            {hud ? (
              <p className="mt-3 text-sm font-bold">
                نجوم {hud.starsTotal} / 120 · أبعد مرحلة {hud.bestStage}
              </p>
            ) : null}
            <button type="button" className="mt-4 w-full rounded-xl bg-tomato px-4 py-3 text-lg font-extrabold text-cream" disabled={!ready} onClick={() => begin(continueAt)}>
              ابدأ اللعب
            </button>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button type="button" className="rounded-xl bg-wood-dark px-3 py-3 font-extrabold text-cream" onClick={() => { refresh(); setScreen("levels"); }}>
                المراحل
              </button>
              <button type="button" className="flex items-center justify-center gap-2 rounded-xl bg-gold px-3 py-3 font-extrabold text-ink" onClick={() => { refresh(); setScreen("shop"); }}>
                <ShoppingBag className="size-4" />
                المتجر
              </button>
            </div>
          </Panel>
        </Center>
      ) : null}

      {screen === "pause" ? (
        <Center>
          <Panel>
            <h2 className="text-2xl font-extrabold">توقف الطبخ</h2>
            <button type="button" className="mt-4 w-full rounded-xl bg-tomato py-3 font-extrabold text-cream" onClick={() => setScreen("play")}>
              متابعة
            </button>
            <button type="button" className="mt-2 w-full rounded-xl bg-wood-dark py-3 font-extrabold text-cream" onClick={() => begin(Math.max(0, (hud?.level ?? 1) - 1))}>
              إعادة المرحلة
            </button>
            <button type="button" className="mt-2 w-full rounded-xl bg-wood py-3 font-extrabold text-ink" onClick={() => { refresh(); setScreen("levels"); }}>
              المراحل
            </button>
            <button
              type="button"
              className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-cream py-3 font-extrabold text-ink ring-1 ring-wood"
              onClick={() => {
                const next = !(save?.sound ?? true);
                apiRef.current?.setSound(next);
                refresh();
              }}
            >
              {save?.sound === false ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
              {save?.sound === false ? "الصوت مغلق" : "الصوت يعمل"}
            </button>
            <button type="button" className="mt-2 w-full rounded-xl py-3 font-bold text-wood-dark" onClick={() => setScreen("start")}>
              القائمة
            </button>
          </Panel>
        </Center>
      ) : null}

      {screen === "levels" ? (
        <Center>
          <Panel>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-2xl font-extrabold">المراحل</h2>
              <button type="button" className="grid size-10 place-items-center rounded-xl bg-wood-dark text-cream" onClick={() => setScreen("start")} aria-label="إغلاق">
                <X className="size-5" />
              </button>
            </div>
            <div className="grid grid-cols-5 gap-2 sm:grid-cols-8">
              {Array.from({ length: 40 }, (_, i) => {
                const open = i <= maxOpen;
                const got = stars[i] || 0;
                return (
                  <button
                    key={i}
                    type="button"
                    disabled={!open}
                    className="flex flex-col items-center rounded-xl bg-cream px-1 py-2 font-extrabold text-ink ring-1 ring-wood disabled:bg-wood/40 disabled:text-wood-dark"
                    onClick={() => begin(i)}
                  >
                    {open ? <span>{i + 1}</span> : <Lock className="size-4" />}
                    <span className="mt-1 flex gap-0.5">
                      {[0, 1, 2].map((k) => (
                        <Star key={k} className={k < got ? "size-2.5 fill-gold text-gold" : "size-2.5 text-wood"} />
                      ))}
                    </span>
                  </button>
                );
              })}
            </div>
          </Panel>
        </Center>
      ) : null}

      {screen === "shop" ? (
        <Center>
          <Panel>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-2xl font-extrabold">المتجر</h2>
              <span className="flex items-center gap-1 font-extrabold">
                <Coins className="size-4 text-gold" />
                {save?.coins ?? 0}
              </span>
            </div>
            <div className="space-y-2">
              {SHOP.map((item) => {
                const has = save?.owned.includes(item.id);
                return (
                  <button
                    key={item.id}
                    type="button"
                    disabled={!!has}
                    className="flex w-full items-center justify-between rounded-xl bg-cream px-3 py-3 text-start ring-1 ring-wood disabled:opacity-70"
                    onClick={() => {
                      const ok = apiRef.current?.buy(item.id);
                      refresh();
                      if (!ok) setToast("العملات لا تكفي بعد");
                    }}
                  >
                    <span>
                      <span className="block font-extrabold">{item.name}</span>
                      <span className="block text-sm text-wood-dark">{item.desc}</span>
                    </span>
                    <span className="font-extrabold">{has ? "مملوك" : item.price}</span>
                  </button>
                );
              })}
            </div>
            {toast ? <p className="mt-3 text-sm font-bold text-tomato">{toast}</p> : null}
            <button type="button" className="mt-4 w-full rounded-xl bg-wood-dark py-3 font-extrabold text-cream" onClick={() => setScreen("start")}>
              رجوع
            </button>
          </Panel>
        </Center>
      ) : null}

      {screen === "end" && end ? (
        <Center>
          <Panel>
            <h2 className="text-2xl font-extrabold">انتهى الوقت</h2>
            <div className="mt-2 flex justify-center gap-1">
              {[0, 1, 2].map((i) => (
                <Star key={i} className={i < end.stars ? "size-8 fill-gold text-gold" : "size-8 text-wood"} />
              ))}
            </div>
            <p className="mt-2 text-xl font-extrabold">{end.score} نقطة</p>
            <p className="text-sm leading-relaxed text-wood-dark">{end.line}</p>
            <p className="mt-1 flex items-center justify-center gap-1 font-bold">
              <Coins className="size-4 text-gold" />+{end.gain} · المجموع {end.coins}
            </p>
            {end.cleared && !end.last ? (
              <button type="button" className="mt-4 w-full rounded-xl bg-tomato py-3 font-extrabold text-cream" onClick={() => begin(hud?.level ?? 1)}>
                المرحلة التالية
              </button>
            ) : null}
            <button type="button" className="mt-2 w-full rounded-xl bg-wood-dark py-3 font-extrabold text-cream" onClick={() => begin(Math.max(0, (hud?.level ?? 1) - 1))}>
              إعادة
            </button>
            <button type="button" className="mt-2 w-full rounded-xl bg-wood py-3 font-extrabold text-ink" onClick={() => { refresh(); setScreen("levels"); }}>
              المراحل
            </button>
          </Panel>
        </Center>
      ) : null}

      {typeof window !== "undefined" && window.innerHeight > window.innerWidth && screen === "start" ? (
        <p className="pointer-events-none absolute inset-x-0 bottom-3 z-20 text-center text-xs font-bold text-wood-dark">
          أدر الجهاز أفقياً ليملأ المطبخ الشاشة
        </p>
      ) : null}
    </main>
  );
}

function formatTime(s: number) {
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}

function Center({ children }: { children: ReactNode }) {
  return <div className="absolute inset-0 z-30 flex items-center justify-center bg-ink/45 p-3">{children}</div>;
}

function Panel({ children }: { children: ReactNode }) {
  return <div className="sheet overflow-auto rounded-3xl border border-gold bg-cream px-5 py-5 text-center text-ink shadow-xl">{children}</div>;
}

function Controls({ apiRef }: { apiRef: RefObject<GameApi | null> }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-2 z-20 flex items-end justify-between px-2 pb-[max(0.25rem,env(safe-area-inset-bottom))]" dir="ltr">
      <Pad
        label="موزة"
        onStick={(x, y) => apiRef.current?.setStick(0, x, y)}
        onAct={() => apiRef.current?.act(0)}
        onToss={() => apiRef.current?.toss(0)}
        onServe={() => apiRef.current?.deliver(0)}
      />
      <Pad
        label="جزرة"
        flip
        onStick={(x, y) => apiRef.current?.setStick(1, x, y)}
        onAct={() => apiRef.current?.act(1)}
        onToss={() => apiRef.current?.toss(1)}
        onServe={() => apiRef.current?.deliver(1)}
      />
    </div>
  );
}

function Pad({
  label,
  flip,
  onStick,
  onAct,
  onToss,
  onServe,
}: {
  label: string;
  flip?: boolean;
  onStick: (x: number, y: number) => void;
  onAct: () => void;
  onToss: () => void;
  onServe: () => void;
}) {
  const zone = useRef<HTMLDivElement>(null);
  const knob = useRef<HTMLDivElement>(null);
  const pid = useRef<number | null>(null);

  function place(e: PointerEvent) {
    const el = zone.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    let dx = e.clientX - r.left - r.width / 2;
    let dy = e.clientY - r.top - r.height / 2;
    const m = r.width * 0.34;
    const len = Math.hypot(dx, dy) || 1;
    if (len > m) {
      dx = (dx / len) * m;
      dy = (dy / len) * m;
    }
    if (knob.current) knob.current.style.transform = `translate(${dx}px, ${dy}px)`;
    onStick(dx / m, dy / m);
  }

  const buttons = (
    <div className="pointer-events-auto flex flex-col gap-1.5">
      <button type="button" className="act bg-tomato text-cream" onPointerDown={(e) => { e.preventDefault(); onServe(); }}>
        سلّم
      </button>
      <button type="button" className="act bg-gold text-ink" onPointerDown={(e) => { e.preventDefault(); onToss(); }}>
        مرّر
      </button>
      <button type="button" className="act bg-leaf text-cream" onPointerDown={(e) => { e.preventDefault(); onAct(); }}>
        يد
      </button>
    </div>
  );

  const joy = (
    <div
      ref={zone}
      className="joy pointer-events-auto"
      onPointerDown={(e) => {
        e.preventDefault();
        pid.current = e.pointerId;
        zone.current?.setPointerCapture(e.pointerId);
        place(e);
      }}
      onPointerMove={(e) => {
        if (e.pointerId === pid.current) place(e);
      }}
      onPointerUp={(e) => {
        if (e.pointerId !== pid.current) return;
        pid.current = null;
        if (knob.current) knob.current.style.transform = "";
        onStick(0, 0);
      }}
      onPointerCancel={() => {
        pid.current = null;
        if (knob.current) knob.current.style.transform = "";
        onStick(0, 0);
      }}
    >
      <div ref={knob} className="knob" />
    </div>
  );

  return (
    <div className="flex items-end gap-2">
      <span className="sr-only">{label}</span>
      {flip ? (
        <>
          {buttons}
          {joy}
        </>
      ) : (
        <>
          {joy}
          {buttons}
        </>
      )}
    </div>
  );
}
