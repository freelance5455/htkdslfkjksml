import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ComponentType } from "react";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [App, setApp] = useState<ComponentType | null>(null);
  useEffect(() => {
    let dead = false;
    void import("@/components/engine-app").then((m) => {
      if (!dead) setApp(() => m.EngineApp);
    });
    return () => {
      dead = true;
    };
  }, []);
  if (!App) return <Boot />;
  return <App />;
}

function Boot() {
  return (
    <main className="grid h-dvh place-items-center bg-bg text-fg">
      <div className="text-center">
        <p className="font-display text-4xl font-bold tracking-[0.18em]">ENGINE MAKER</p>
        <p className="mt-1 text-sm font-semibold tracking-widest text-accent">1.0</p>
      </div>
    </main>
  );
}
