import { createFileRoute } from "@tanstack/react-router";
import { Studio } from "@/components/aurora/studio";

export const Route = createFileRoute("/")({
  component: Studio,
});
