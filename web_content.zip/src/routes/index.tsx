import { createFileRoute } from "@tanstack/react-router";
import { WeighApp } from "@/components/weigh/app";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <WeighApp />;
}
