import { createFileRoute } from "@tanstack/react-router";
import { NyalaGate } from "@/components/nyala/nyala-gate";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <NyalaGate />;
}
