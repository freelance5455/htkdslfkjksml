import { createFileRoute } from "@tanstack/react-router";
import { AviatorApp } from "@/components/aviator-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AviatorApp />;
}
