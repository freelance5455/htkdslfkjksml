import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/dashboard";
import { Onboarding } from "@/components/onboarding";
import { ProtectionLoop } from "@/components/protection-loop";
import { ThreatDialog } from "@/components/threat-dialog";
import { useShield } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const onboarded = useShield((s) => s.onboarded);

  return (
    <>
      <ProtectionLoop />
      {onboarded ? <Dashboard /> : <Onboarding />}
      <ThreatDialog />
    </>
  );
}
