import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BatteryCharging,
  Calculator,
  Download,
  Flashlight,
  Smartphone,
  HardDrive,
  Wifi,
} from "lucide-react";
import { AppShell, ScreenBody } from "@/components/vishal/app-shell";

export const Route = createFileRoute("/")({ component: Home });

const tools = [
  {
    to: "/battery",
    title: "Battery Info",
    subtitle: "Level, charging, health",
    icon: BatteryCharging,
    tint: "text-primary bg-primary/15",
  },
  {
    to: "/storage",
    title: "Storage Info",
    subtitle: "Used, free, and total",
    icon: HardDrive,
    tint: "text-sky bg-sky/15",
  },
  {
    to: "/device",
    title: "Device Info",
    subtitle: "Model, Android, SDK",
    icon: Smartphone,
    tint: "text-primary bg-primary/15",
  },
  {
    to: "/calculator",
    title: "Calculator",
    subtitle: "Add, subtract, multiply, divide",
    icon: Calculator,
    tint: "text-warning bg-warning/15",
  },
  {
    to: "/flashlight",
    title: "Flashlight",
    subtitle: "Turn the torch on or off",
    icon: Flashlight,
    tint: "text-warning bg-warning/15",
  },
  {
    to: "/network",
    title: "Network Info",
    subtitle: "Wi-Fi or mobile status",
    icon: Wifi,
    tint: "text-primary bg-primary/15",
  },
] as const;

function Home() {
  return (
    <AppShell peek>
      <ScreenBody>
        <div className="stagger-in">
          <p className="text-sm font-medium uppercase tracking-widest text-primary">Offline utilities</p>
          <h1 className="mt-2 text-4xl font-bold leading-tight tracking-tight text-fg">Vishal Tools</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Offline utilities for your phone. Nothing is uploaded.
          </p>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <Link
                key={tool.to}
                to={tool.to}
                className="stagger-in flex min-h-44 flex-col rounded-card bg-surface p-5 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]"
              >
                <span className={`inline-flex w-fit rounded-2xl p-3 ${tool.tint}`}>
                  <Icon className="size-5" />
                </span>
                <span className="mt-4 text-sm font-semibold text-fg">{tool.title}</span>
                <span className="mt-1 text-xs leading-snug text-muted">{tool.subtitle}</span>
                <span className="mt-auto pt-3 text-sm font-semibold text-primary">Open</span>
              </Link>
            );
          })}
        </div>

        <Link
          to="/studio"
          className="stagger-in mt-4 flex min-h-14 items-center justify-between gap-3 rounded-card bg-elevated px-4 py-3 shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.96] lg:hidden"
        >
          <span>
            <span className="block text-sm font-semibold text-fg">Android Studio project</span>
            <span className="text-xs text-muted">Download Kotlin source and build an APK</span>
          </span>
          <Download className="size-5 text-primary" />
        </Link>
      </ScreenBody>
    </AppShell>
  );
}
