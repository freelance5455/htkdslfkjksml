import { createFileRoute, Link } from "@tanstack/react-router";
import { RefreshCw } from "lucide-react";
import { useMemo, useState } from "react";
import { CapitalChart, ClassChart, Donut } from "@/components/charts";
import { Shell } from "@/components/shell";
import { Segmented } from "@/components/ui";
import { CLASS_LABEL, compactHuf, formatMoney, formatNumber, formatPct, formatWhen, pnlClass } from "@/lib/format";
import { inflationLossPct } from "@/lib/inflation";
import {
  allocation,
  capitalSeries,
  classUsdSeries,
  investedToDate,
  realHuf,
  sumViews,
  viewsOf,
} from "@/lib/portfolio-math";
import { usePortfolio } from "@/lib/portfolio-context";
import type { RangeKey } from "@/lib/types";

export const Route = createFileRoute("/")({ component: Page });

function Page() {
  return (
    <Shell>
      <Overview />
    </Shell>
  );
}

function Overview() {
  const { state, refreshing, marketError, range, setRange, refresh } = usePortfolio();
  const [mode, setMode] = useState<"class" | "group">("class");
  const today = new Date().toISOString().slice(0, 10);
  const rows = useMemo(() => viewsOf(state), [state]);
  const totals = useMemo(() => sumViews(rows), [rows]);
  const buckets = useMemo(() => allocation(state, mode), [state, mode]);
  const series = useMemo(() => capitalSeries(state, today), [state, today]);
  const classes = useMemo(() => classUsdSeries(state), [state]);
  const base = state.inflationBase || state.capitalPlan.startDate;
  const real = realHuf(totals.huf, base, today);
  const loss = inflationLossPct(base, today);
  const invested = investedToDate(state.capitalPlan, today);
  const gap = totals.huf - invested;
  const ranked = [...rows].sort((a, b) => b.huf - a.huf).slice(0, 6);
  const fxRows = [...rows].filter((row) => row.holding.currency !== "HUF").sort((a, b) => Math.abs(b.fxPnlHuf) - Math.abs(a.fxPnlHuf)).slice(0, 5);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl">Áttekintés</h1>
          <p className="mt-1 text-sm text-muted">
            {state.market.fxLive ? `Élő középárfolyam, ${formatWhen(state.market.asOf)}.` : "Becsült árak, amíg a jegyzés megérkezik."}{" "}
            1 USD = {formatMoney(state.market.fx.usdHuf, "HUF", 2)}, 1 EUR = {formatMoney(state.market.fx.eurHuf, "HUF", 2)}.
          </p>
        </div>
        <button type="button" className="btn btn-ghost" onClick={() => void refresh()} disabled={refreshing}>
          <RefreshCw className={`size-4 ${refreshing ? "motion-safe:animate-spin" : ""}`} />
          {refreshing ? "Frissül" : "Árak frissítése"}
        </button>
      </div>
      {marketError ? <p className="mt-3 text-sm text-clay">{marketError}</p> : null}

      <section className="mt-8 grid gap-8 border-t border-line pt-8 sm:grid-cols-2">
        <div>
          <p className="text-sm text-muted">Forint</p>
          <p className="mt-1 font-serif text-4xl tabular-nums leading-tight sm:text-5xl">{formatMoney(totals.huf, "HUF")}</p>
        </div>
        <div className="sm:border-l sm:border-line sm:pl-8">
          <p className="text-sm text-muted">Dollár</p>
          <p className="mt-1 font-serif text-4xl tabular-nums leading-tight sm:text-5xl">{formatMoney(totals.usd, "USD")}</p>
        </div>
      </section>

      <dl className="mt-8 grid gap-6 border-t border-line pt-6 sm:grid-cols-3">
        <div>
          <dt className="text-sm text-muted">Inflációval, {base} óta</dt>
          <dd className="mt-1 font-serif text-2xl tabular-nums">{formatMoney(real, "HUF")}</dd>
          <dd className="text-sm text-muted">A forint vásárlóereje {formatNumberLoss(loss)}.</dd>
        </div>
        <div>
          <dt className="text-sm text-muted">Devizahatás</dt>
          <dd className={`mt-1 font-serif text-2xl tabular-nums ${pnlClass(totals.fxPnlHuf)}`}>{formatMoney(totals.fxPnlHuf, "HUF")}</dd>
          <dd className={`text-sm tabular-nums ${pnlClass(totals.pricePnlHuf)}`}>Árhatás {formatMoney(totals.pricePnlHuf, "HUF")}</dd>
        </div>
        <div>
          <dt className="text-sm text-muted">Befizetett tőke</dt>
          <dd className="mt-1 font-serif text-2xl tabular-nums">{formatMoney(invested, "HUF")}</dd>
          <dd className={`text-sm tabular-nums ${pnlClass(gap)}`}>
            Az érték {gap >= 0 ? "felette" : "alatta"} van: {formatMoney(gap, "HUF")}
          </dd>
        </div>
      </dl>

      <div className="mt-10 flex flex-wrap items-center justify-between gap-3">
        <Segmented<RangeKey>
          label="Időtáv"
          value={range}
          onChange={setRange}
          options={[
            { id: "6mo", label: "6 hónap" },
            { id: "1y", label: "1 év" },
            { id: "5y", label: "5 év" },
          ]}
        />
        <Segmented<"class" | "group">
          label="Megoszlás"
          value={mode}
          onChange={setMode}
          options={[
            { id: "class", label: "Osztály" },
            { id: "group", label: "Csoport" },
          ]}
        />
      </div>

      <section className="mt-6 grid items-start gap-10 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <h2 className="font-serif text-2xl">Megoszlás</h2>
          <Donut rows={buckets} />
          <ul className="mt-2 divide-y divide-line">
            {buckets.map((bucket) => {
              const pct = totals.huf ? (bucket.huf / totals.huf) * 100 : 0;
              return (
                <li key={bucket.id} className="grid grid-cols-[1fr_auto] gap-3 py-3">
                  <div>
                    <div className="flex items-baseline justify-between gap-3">
                      <span>{bucket.label}</span>
                      <span className="text-sm text-muted tabular-nums">{formatPct(pct).replace("+", "")}</span>
                    </div>
                    <div className="mt-2 h-1.5 rounded-full bg-line">
                      <div className="h-1.5 rounded-full bg-pine" style={{ width: `${Math.min(100, pct)}%` }} />
                    </div>
                  </div>
                  <div className="text-right text-sm tabular-nums">
                    <div>{compactHuf(bucket.huf)}</div>
                    <div className="text-muted">{formatMoney(bucket.usd, "USD")}</div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
        <div className="min-w-0 lg:col-span-7">
          <h2 className="font-serif text-2xl">Befizetés és érték</h2>
          <p className="mt-1 text-sm text-muted">
            A rozsda színű vonal a megadott ütem, a zöld a mai darabszám visszaszámolt értéke, plusz a mostani készpénz. Nem a régi egyenleg.
          </p>
          <div className="mt-4 overflow-hidden rounded-2xl border border-line bg-surface p-3">
            <CapitalChart rows={series} />
            <div className="mt-2 flex gap-4 px-2 text-xs text-muted">
              <span className="text-clay">Befizetett tőke</span>
              <span className="text-pine">Vagyon</span>
            </div>
          </div>
        </div>
      </section>

      <section className="mt-12">
        <h2 className="font-serif text-2xl">Eszközosztályok dollárban</h2>
        <p className="mt-1 text-sm text-muted">A most tartott ETF, részvény és kripto értéke dollárban, készpénz nélkül.</p>
        <div className="mt-4 overflow-hidden rounded-2xl border border-line bg-surface p-3">
          {classes.length ? (
            <ClassChart rows={classes} />
          ) : (
            <p className="px-2 py-16 text-sm text-muted">Az árgörbe az első sikeres frissítés után rajzolódik ki.</p>
          )}
          <div className="mt-2 flex gap-4 px-2 text-xs">
            <span className="text-pine">ETF</span>
            <span className="text-ink">Részvény</span>
            <span className="text-clay">Kripto</span>
          </div>
        </div>
      </section>

      <section className="mt-12 grid gap-10 lg:grid-cols-2">
        <div>
          <h2 className="font-serif text-2xl">Nagyobb tételek</h2>
          <ul className="mt-3 divide-y divide-line">
            {ranked.map((row) => (
              <li key={row.holding.id} className="flex items-baseline justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="truncate">
                    {row.holding.name} <span className="text-sm text-muted">{row.holding.symbol}</span>
                  </p>
                  <p className="text-sm text-muted">
                    {state.groups.find((group) => group.id === row.holding.groupId)?.name} · {CLASS_LABEL[row.holding.assetClass]}
                  </p>
                </div>
                <div className="text-right tabular-nums">
                  <p>{formatMoney(row.huf, "HUF")}</p>
                  <p className="text-sm text-muted">{formatMoney(row.usd, "USD")}</p>
                </div>
              </li>
            ))}
          </ul>
          <Link to="/eszkozok" className="mt-2 inline-flex h-11 items-center text-sm text-pine">
            Teljes állomány
          </Link>
        </div>
        <div>
          <h2 className="font-serif text-2xl">Miből jön a változás</h2>
          <p className="mt-1 text-sm text-muted">
            Az árhatás a papír saját devizájában, a beszerzéskori forintárfolyamon. A devizahatás az árfolyam elmozdulása azóta.
          </p>
          <ul className="mt-3 divide-y divide-line">
            {fxRows.map((row) => (
              <li key={row.holding.id} className="grid grid-cols-[1fr_auto_auto] gap-3 py-3 text-sm tabular-nums">
                <span className="truncate text-base">{row.holding.symbol}</span>
                <span className={pnlClass(row.pricePnlHuf)}>{compactHuf(row.pricePnlHuf)}</span>
                <span className={pnlClass(row.fxPnlHuf)}>{compactHuf(row.fxPnlHuf)}</span>
              </li>
            ))}
          </ul>
          <p className="mt-2 text-xs text-muted">Árhatás, majd devizahatás. A forintos papíroknál a deviza nulla.</p>
        </div>
      </section>
    </div>
  );
}

function formatNumberLoss(pct: number): string {
  const abs = Math.abs(pct);
  const text = formatNumber(abs, 1);
  return pct >= 0 ? `${text}%-ot csökkent` : `${text}%-ot nőtt`;
  return pct >= 0 ? `${text}%-ot csökkent` : `${text}%-ot nőtt`;
}
