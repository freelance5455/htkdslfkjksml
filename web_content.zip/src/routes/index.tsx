import { useEffect, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Check, Copy, Loader2, RotateCcw, Square, Trash2, Volume2 } from "lucide-react";
import { enqueueIncoming, retryIncoming } from "@/lib/inbox-actions";
import { LIVE_DEMOS, useInbox, type IncomingMessage } from "@/lib/inbox-store";
import { canSpeak, holdSpeech, speakArabic, stopSpeech, subscribeSpeaking, unlockSpeech } from "@/lib/speak";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const messages = useInbox((state) => state.messages);
  const activeId = useInbox((state) => state.activeId);
  const setActive = useInbox((state) => state.setActive);
  const remove = useInbox((state) => state.remove);
  const clear = useInbox((state) => state.clear);
  const [draft, setDraft] = useState("");
  const [sender, setSender] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [armClear, setArmClear] = useState(false);
  const [autoRead, setAutoRead] = useState(true);
  const [watchClip, setWatchClip] = useState(false);
  const [clipError, setClipError] = useState("");
  const [canClip, setCanClip] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [primed, setPrimed] = useState(false);
  const demoCursor = useRef(0);
  const lastSubmit = useRef({ text: "", at: 0 });
  const spokenIds = useRef(new Set<string>());
  const lastClip = useRef("");
  const readingClip = useRef(false);
  const active = messages.find((message) => message.id === activeId) ?? null;

  useEffect(() => subscribeSpeaking(setSpeaking), []);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      await useInbox.persist.rehydrate();
      if (cancelled) return;
      if (localStorage.getItem("warid-autoread") === "0") setAutoRead(false);
      if (localStorage.getItem("warid-watch") === "1") setWatchClip(true);
      setCanClip(typeof navigator.clipboard?.readText === "function");
      useInbox.getState().messages.forEach((message) => spokenIds.current.add(message.id));
      const params = new URLSearchParams(window.location.search);
      const text = params.get("text")?.trim();
      const from = params.get("from")?.trim() ?? "";
      if (text) {
        const url = new URL(window.location.href);
        url.searchParams.delete("text");
        url.searchParams.delete("from");
        window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`);
        if (from) setSender(from);
      }
      setPrimed(true);
      if (text) await enqueueIncoming(text, from);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!primed) return;
    const finished = messages.filter(
      (message) =>
        !message.sample && message.status !== "translating" && !spokenIds.current.has(message.id),
    );
    if (finished.length === 0) return;
    finished.forEach((message) => spokenIds.current.add(message.id));
    const newest = finished.find((message) => message.status === "ready" && message.arabic);
    if (autoRead && newest?.arabic) speakArabic(newest.arabic);
    else stopSpeech();
  }, [messages, primed, autoRead]);

  useEffect(() => {
    if (!primed || !watchClip) return;
    const pull = () => {
      if (document.visibilityState !== "visible") return;
      void readClipboard(false);
    };
    document.addEventListener("visibilitychange", pull);
    window.addEventListener("focus", pull);
    return () => {
      document.removeEventListener("visibilitychange", pull);
      window.removeEventListener("focus", pull);
    };
  }, [primed, watchClip]);

  useEffect(() => {
    if (!armClear) return;
    const timer = window.setTimeout(() => setArmClear(false), 3000);
    return () => window.clearTimeout(timer);
  }, [armClear]);

  function submit(text: string, from = sender) {
    const clean = text.trim();
    const now = Date.now();
    if (!clean) return;
    if (lastSubmit.current.text === clean && now - lastSubmit.current.at < 800) return;
    lastSubmit.current = { text: clean, at: now };
    lastClip.current = clean;
    holdSpeech();
    setDraft("");
    void enqueueIncoming(clean, from);
  }

  async function readClipboard(fromGesture: boolean) {
    if (readingClip.current || !navigator.clipboard?.readText) return;
    readingClip.current = true;
    try {
      const text = (await navigator.clipboard.readText()).trim();
      setClipError("");
      if (!text || text === lastClip.current) return;
      const latest = useInbox.getState().messages[0];
      if (latest && latest.original === text) {
        lastClip.current = text;
        return;
      }
      lastClip.current = text;
      if (fromGesture) holdSpeech();
      void enqueueIncoming(text);
    } catch {
      if (fromGesture) {
        setClipError("لم يُسمح بقراءة النسخ. الصق الرسالة في الخانة.");
        setWatchClip(false);
        localStorage.setItem("warid-watch", "0");
      }
    } finally {
      readingClip.current = false;
    }
  }

  function toggleAutoRead() {
    const next = !autoRead;
    setAutoRead(next);
    localStorage.setItem("warid-autoread", next ? "1" : "0");
    if (next) unlockSpeech();
    else stopSpeech();
  }

  function toggleWatch() {
    if (watchClip) {
      setWatchClip(false);
      localStorage.setItem("warid-watch", "0");
      return;
    }
    localStorage.setItem("warid-watch", "1");
    setWatchClip(true);
    void readClipboard(true);
  }

  function insertDemo() {
    const demo = LIVE_DEMOS[demoCursor.current % LIVE_DEMOS.length];
    if (!demo) return;
    demoCursor.current += 1;
    setSender(demo.sender);
    void submit(demo.text, demo.sender);
  }

  async function copyArabic(message: IncomingMessage) {
    if (!message.arabic) return;
    try {
      await navigator.clipboard.writeText(message.arabic);
      setCopiedId(message.id);
      window.setTimeout(() => {
        setCopiedId((current) => (current === message.id ? null : current));
      }, 1600);
    } catch {
      setCopiedId(null);
    }
  }

  function speak(text: string) {
    unlockSpeech();
    speakArabic(text);
  }

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
      <header className="mb-6 flex items-center gap-4">
        <div className="grid size-14 shrink-0 place-items-center rounded-card bg-ink font-display text-3xl leading-none text-paper">
          و
        </div>
        <div className="min-w-0">
          <h1 className="font-display text-4xl leading-none">وارد</h1>
          <p className="mt-2 max-w-xl text-sm leading-6 text-ink/70 sm:text-base">
            يترجم الرسالة ثم يقرأها بالعربية بصوت عالٍ، دون أن تفتح صندوق الرسائل بنفسه.
          </p>
        </div>
      </header>

      <div className="grid items-start gap-4 lg:grid-cols-3">
        <div className="contents lg:col-span-1 lg:grid lg:gap-4">
          <section className="order-0 grid gap-3 rounded-card border border-ink/10 bg-paper p-4 shadow-lift lg:order-none">
            <button
              type="button"
              role="switch"
              aria-checked={autoRead}
              onClick={toggleAutoRead}
              className="flex min-h-11 items-center justify-between gap-3 text-start"
            >
              <span>
                <span className="flex items-center gap-2 font-semibold">
                  <Volume2 className="size-4" />
                  قراءة تلقائية
                </span>
                <span className="mt-1 block text-sm leading-6 text-ink/60">
                  {autoRead ? "يقرأ الترجمة فور وصولها" : "القراءة الصوتية متوقفة"}
                </span>
              </span>
              <span
                dir="ltr"
                className={`flex h-7 w-12 shrink-0 items-center rounded-full px-0.5 ${
                  autoRead ? "justify-end bg-accent" : "justify-start bg-ink/15"
                }`}
              >
                <span className="size-6 rounded-full bg-paper" />
              </span>
            </button>
            {speaking ? (
              <button
                type="button"
                onClick={stopSpeech}
                className="inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-accent"
              >
                <Square className="size-4" />
                يقرأ الآن — إيقاف
              </button>
            ) : null}
            {canClip ? (
              <button
                type="button"
                onClick={toggleWatch}
                className="inline-flex min-h-11 items-center justify-center rounded-control border border-ink/15 px-3 text-sm font-semibold"
              >
                {watchClip ? "مراقبة النسخ تعمل" : "اقرأ ما أنسخه من الرسائل"}
              </button>
            ) : null}
            {clipError ? <p className="text-sm leading-6">{clipError}</p> : null}
            {!canSpeak() && primed ? (
              <p className="text-sm leading-6 text-ink/60">هذا المتصفح لا يدعم القراءة الصوتية.</p>
            ) : null}
            <p className="text-sm leading-6 text-ink/60">
              انسخ الرسالة من تطبيق الرسائل ثم ارجع إلى هنا. المتصفح لا يسمح بقراءة الصندوق نفسه.
            </p>
          </section>
          <form
            className="order-1 grid gap-3 rounded-card border border-ink/10 bg-paper p-4 shadow-lift lg:order-none"
            onSubmit={(event) => {
              event.preventDefault();
              void submit(draft);
            }}
          >
            <div className="grid gap-2">
              <label htmlFor="incoming" className="text-sm font-semibold">
                رسالة واردة
              </label>
              <textarea
                id="incoming"
                value={draft}
                dir="auto"
                rows={4}
                maxLength={4000}
                placeholder="الصق هنا الرسالة كما وصلتك…"
                onChange={(event) => setDraft(event.target.value)}
                onPaste={(event) => {
                  const text = event.clipboardData.getData("text").trim();
                  if (!text) return;
                  event.preventDefault();
                  void submit(text);
                }}
                className="min-h-24 w-full resize-y rounded-control border border-ink/15 bg-sand px-3 py-3 text-base leading-7 outline-none placeholder:text-ink/50 focus-visible:ring-2 focus-visible:ring-accent"
              />
            </div>
            <div className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
              <div className="grid gap-2">
                <label htmlFor="sender" className="text-sm font-semibold">
                  المرسل
                </label>
                <input
                  id="sender"
                  value={sender}
                  dir="auto"
                  maxLength={40}
                  placeholder="اختياري"
                  onChange={(event) => setSender(event.target.value)}
                  className="min-h-11 w-full rounded-control border border-ink/15 bg-sand px-3 text-base outline-none placeholder:text-ink/50 focus-visible:ring-2 focus-visible:ring-accent"
                />
              </div>
              <button
                type="submit"
                disabled={!draft.trim()}
                className="inline-flex min-h-11 items-center justify-center rounded-control bg-accent px-5 text-base font-semibold text-paper transition-opacity disabled:opacity-40"
              >
                ترجم الآن
              </button>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm text-ink/60">تُترجم فور اللصق، ومن أي لغة.</p>
              <button
                type="button"
                onClick={insertDemo}
                className="inline-flex min-h-11 items-center rounded-control border border-ink/15 px-3 text-sm font-medium"
              >
                جرّب رسالة واردة
              </button>
            </div>
          </form>

          <section className="order-3 grid gap-3 lg:order-none" aria-label="الوارد">
            <div className="flex items-center justify-between gap-3 px-1">
              <h2 className="text-base font-semibold">الوارد</h2>
              <span className="text-sm text-ink/60 tabular-nums">{messages.length}</span>
            </div>
            {messages.length === 0 ? (
              <p className="rounded-card border border-dashed border-ink/20 px-4 py-8 text-center text-sm text-ink/70">
                صندوقك فارغ. الصق أول رسالة لتبدأ.
              </p>
            ) : (
              <ul className="grid gap-2 lg:max-h-96 lg:overflow-y-auto lg:pe-1">
                {messages.map((message) => {
                  const selected = message.id === activeId;
                  const preview =
                    message.status === "ready"
                      ? message.arabic
                      : message.status === "error"
                        ? "تعذّرت الترجمة"
                        : "تُترجم الآن…";
                  return (
                    <li key={message.id}>
                      <div
                        className={`flex items-start gap-2 rounded-card border bg-paper p-3 ${
                          selected ? "border-accent shadow-lift" : "border-ink/10"
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => setActive(message.id)}
                          className="flex min-w-0 flex-1 items-start gap-3 text-start"
                        >
                          <span className="grid size-11 shrink-0 place-items-center rounded-control bg-ink font-display text-xl leading-none text-paper">
                            {monogram(message.sender)}
                          </span>
                          <span className="min-w-0">
                            <span className="flex items-center gap-2">
                              <span dir="auto" className="truncate font-semibold">
                                {message.sender}
                              </span>
                              {message.status === "translating" ? (
                                <Loader2
                                  className="size-4 shrink-0 motion-safe:animate-spin"
                                  aria-hidden
                                />
                              ) : null}
                            </span>
                            <span className="mt-1 line-clamp-2 block text-sm leading-6">
                              {preview}
                            </span>
                            <span
                              dir="auto"
                              className="mt-1 line-clamp-1 block text-sm text-ink/60"
                            >
                              {message.original}
                            </span>
                            <span className="mt-1 block text-sm text-ink/60">
                              {message.sample ? "مثال" : message.language || "جديد"}
                              {" · "}
                              <span className="tabular-nums">{message.timeLabel}</span>
                            </span>
                          </span>
                        </button>
                        <button
                          type="button"
                          aria-label={`حذف رسالة ${message.sender}`}
                          onClick={() => remove(message.id)}
                          className="grid size-11 shrink-0 place-items-center rounded-control text-ink/70 hover:bg-sand"
                        >
                          <Trash2 className="size-4" />
                        </button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
            {messages.length > 0 ? (
              <button
                type="button"
                onClick={() => {
                  if (!armClear) {
                    setArmClear(true);
                    return;
                  }
                  clear();
                  setArmClear(false);
                }}
                className="min-h-11 justify-self-start px-1 text-sm text-ink/70"
              >
                {armClear ? "تأكيد مسح السجل" : "مسح السجل"}
              </button>
            ) : null}
          </section>
        </div>

        <article
          className="order-2 grid content-start gap-5 rounded-card border border-ink/10 bg-paper p-5 shadow-lift lg:order-none lg:col-span-2 lg:sticky lg:top-6 lg:min-h-96 lg:p-7"
          aria-live="polite"
        >
          {active ? (
            <Reading
              message={active}
              copied={copiedId === active.id}
              onCopy={() => void copyArabic(active)}
              onSpeak={() => speak(active.arabic)}
              onRetry={() => void retryIncoming(active.id)}
            />
          ) : (
            <div className="grid content-center gap-2 py-10 text-center">
              <h2 className="font-display text-3xl">بانتظار رسالة</h2>
              <p className="text-sm leading-6 text-ink/70">
                الصق نصاً، أو انسخه من الرسائل وارجع إلى هنا، فيُترجم ويُقرأ.
              </p>
            </div>
          )}
        </article>
      </div>

      <p className="mt-8 text-sm leading-6 text-ink/60">
        المتصفح لا يفتح رسائل الهاتف مباشرة. انسخها أو الصقها، ويقرأ وارد الترجمة. راجع العامية والأسماء قبل أن ترد.
      </p>
    </main>
  );
}

function Reading({
  message,
  copied,
  onCopy,
  onSpeak,
  onRetry,
}: {
  message: IncomingMessage;
  copied: boolean;
  onCopy: () => void;
  onSpeak: () => void;
  onRetry: () => void;
}) {
  return (
    <>
      <header className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm text-ink/60">
            {message.sample ? "مثال محفوظ" : "الترجمة"}
            {message.language ? ` · ${message.language}` : ""}
          </p>
          <h2 dir="auto" className="mt-1 truncate text-2xl font-semibold">
            {message.sender}
          </h2>
        </div>
        <p className="shrink-0 pt-1 text-sm text-ink/60 tabular-nums">{message.timeLabel}</p>
      </header>

      {message.status === "translating" ? (
        <div className="grid gap-3 py-2" aria-label="تُترجم الآن">
          <p className="text-sm font-medium">تُترجم الآن</p>
          <div className="h-4 w-4/5 rounded-full bg-ink/10 motion-safe:animate-pulse" />
          <div className="h-4 w-full rounded-full bg-ink/10 motion-safe:animate-pulse" />
          <div className="h-4 w-2/3 rounded-full bg-ink/10 motion-safe:animate-pulse" />
        </div>
      ) : null}

      {message.status === "error" ? (
        <div className="grid gap-3">
          <p className="text-base font-medium">{message.error}</p>
          <button
            type="button"
            onClick={onRetry}
            className="inline-flex min-h-11 w-fit items-center gap-2 rounded-control bg-accent px-4 text-sm font-semibold text-paper"
          >
            <RotateCcw className="size-4" />
            إعادة المحاولة
          </button>
        </div>
      ) : null}

      {message.status === "ready" ? (
        <>
          <p className="font-display text-3xl leading-relaxed sm:text-4xl">{message.arabic}</p>
          {message.unchanged ? (
            <p className="text-sm text-ink/70">الرسالة بالعربية أصلاً، أبقينا نصها كما هو.</p>
          ) : null}
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={onCopy}
              className="inline-flex min-h-11 items-center gap-2 rounded-control bg-accent px-4 text-sm font-semibold text-paper"
            >
              {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
              {copied ? "تم النسخ" : "نسخ الترجمة"}
            </button>
            <button
              type="button"
              onClick={onSpeak}
              className="inline-flex min-h-11 items-center gap-2 rounded-control border border-ink/15 px-4 text-sm font-semibold"
            >
              <Volume2 className="size-4" />
              استماع
            </button>
          </div>
        </>
      ) : null}

      <div className="rounded-control bg-sand p-4">
        <p className="text-sm font-medium text-ink/60">النص الأصلي</p>
        <p dir="auto" className="mt-2 text-base leading-7 break-words">
          {message.original}
        </p>
      </div>
    </>
  );
}

function monogram(sender: string) {
  const letter = sender.trim().charAt(0);
  return letter ? letter.toLocaleUpperCase() : "؟";
}
