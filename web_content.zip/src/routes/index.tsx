import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Card } from "@/components/ui";
import { MoneyText } from "@/components/fields";
import { getDashboard } from "@/lib/server/books";
import { useQuery } from "@tanstack/react-query";
import { formatRial } from "@/lib/accounting/format";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const q = useQuery({ queryKey: ["dashboard"], queryFn: () => getDashboard() });
  const d = q.data;

  return (
    <AppShell>
      <div className="mb-5">
        <p className="text-xs tracking-[0.2em] text-gold uppercase">MR,KHORASANI</p>
        <h1 className="text-2xl font-semibold text-navy">داشبورد مدیریتی</h1>
        <p className="text-sm text-muted">{d?.todayJalali} — {d?.company.name}</p>
      </div>

      {q.isLoading && <p className="text-sm text-muted">در حال آماده‌سازی دفاتر...</p>}
      {q.error && <p className="text-sm text-danger">{(q.error as Error).message}</p>}

      {d && (
        <>
          <div className="mb-4 rounded-xl bg-navy p-5 text-paper">
            <p className="text-xs text-gold/80">جمع کل نقدینگی</p>
            <p className="mt-1 font-display text-4xl text-gold-soft tabular" style={{ fontFamily: "var(--font-display)" }} dir="ltr">
              {formatRial(d.cashTotal)}
            </p>
            <p className="mt-1 text-xs text-paper/60">ریال — صندوق، بانک‌ها و تنخواه</p>
          </div>

          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="مطالبات" value={d.receivables} to="/crm" />
            <Stat label="بدهی‌ها" value={d.payables} to="/reports" />
            <Stat label="فروش امروز" value={d.salesToday} to="/operations" />
            <Stat label="دریافت امروز" value={d.receiptToday} to="/operations" />
            <Stat label="پرداخت امروز" value={d.paymentToday} to="/operations" />
            <Stat label="هزینه امروز" value={d.expenseToday} to="/operations" />
            <Stat label="سود تقریبی" value={d.profit} />
            <Stat label="موجودی کالا" value={d.inventory} />
          </div>

          <Card className="mt-5">
            <h2 className="mb-3 text-sm font-medium text-navy">روند ۱۴ روزه</h2>
            <div className="h-56" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={d.series}>
                  <CartesianGrid stroke="#e8e0d4" strokeDasharray="3 3" />
                  <XAxis dataKey="jalali" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip formatter={(v: number) => formatRial(v, false)} />
                  <Line type="monotone" dataKey="sales" stroke="#0B1F3A" strokeWidth={2} dot={false} name="فروش" />
                  <Line type="monotone" dataKey="receipts" stroke="#C4A35A" strokeWidth={2} dot={false} name="دریافت" />
                  <Line type="monotone" dataKey="payments" stroke="#9B3B3B" strokeWidth={2} dot={false} name="پرداخت" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <h2 className="mt-6 mb-3 text-sm font-medium text-navy">منابع مالی</h2>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {d.sourceBalances.map((s) => (
              <Link key={s.id} to="/liquidity" className="flex items-center justify-between rounded-xl border border-line bg-card px-4 py-3">
                <div>
                  <p className="text-sm text-navy">{s.name}</p>
                  <p className="text-[11px] text-muted">{s.kind === "cash" ? "وجه نقد" : s.kind === "petty" ? "تنخواه" : "بانک"}</p>
                </div>
                <MoneyText value={s.balance} className="text-sm font-medium text-navy" />
              </Link>
            ))}
          </div>
        </>
      )}
    </AppShell>
  );
}

function Stat({ label, value, to }: { label: string; value: number; to?: string }) {
  const inner = (
    <Card>
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 text-lg font-semibold text-navy">
        <MoneyText value={value} />
      </p>
    </Card>
  );
  return to ? <Link to={to}>{inner}</Link> : inner;
}
