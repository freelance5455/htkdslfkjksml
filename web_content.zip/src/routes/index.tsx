import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="app-frame">
      <iframe
        title="أوراد وروحانيات"
        src="/awrad.html"
        className="app-frame-view"
      />
    </main>
  );
}
