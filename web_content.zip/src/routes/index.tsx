import { createFileRoute } from "@tanstack/react-router";
import { TodayView } from "@/components/sahyog/today-view";

export const Route = createFileRoute("/")({
  component: TodayView,
  head: () => ({ meta: [{ title: "Today · Sahyog" }] }),
});
