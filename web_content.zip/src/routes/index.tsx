import { createFileRoute } from "@tanstack/react-router";
import { AdminApp } from "@/admin/AdminApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AdminApp />;
}
