import { createFileRoute } from "@tanstack/react-router";
import { BubblePop } from "../components/BubblePop";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="page fixed inset-0 text-ink">
      <BubblePop />
    </main>
  );
}
