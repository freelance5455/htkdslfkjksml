import { createFileRoute } from "@tanstack/react-router";
import { QrCode } from "lucide-react";
import { QrStudio } from "@/components/qr-studio";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-xl flex-col gap-8 px-4 py-8 sm:py-14">
      <header className="flex flex-col gap-3">
        <span className="block h-1 w-12 rounded-full bg-accent" aria-hidden="true" />
        <div className="flex items-center gap-3">
          <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-ink text-surface">
            <QrCode className="size-5" aria-hidden="true" />
          </span>
          <h1 className="text-3xl font-semibold leading-tight tracking-tight">مولّد رمز QR</h1>
        </div>
        <p className="text-base text-muted">
          معاينة فورية وأنت تكتب، ثم تنزيل PNG. يُنشأ الرمز داخل المتصفح ولا يُرسل النص إلى أي خادم.
        </p>
      </header>
      <QrStudio />
    </main>
  );
}
