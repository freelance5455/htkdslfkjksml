import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Bell, CalendarClock, Layers, SlidersHorizontal, Smartphone } from "lucide-react";
import { cn } from "@/lib/cn";
import { countdown } from "@/lib/notif/model";
import { useNotifEngine } from "@/lib/notif/engine";
import { useNotifStore } from "@/lib/notif/store";
import { Composer } from "@/components/notif/composer";
import { Phone } from "@/components/notif/phone";
import { ChannelPanel, SchedulePanel, SettingsPanel } from "@/components/notif/panels";

export const Route = createFileRoute("/")({ component: Home });

type Tab = "studio" | "jadwal" | "saluran" | "atur" | "layar";

const TABS: { id: Tab; label: string; icon: typeof Bell }[] = [
  { id: "studio", label: "Buat", icon: Bell },
  { id: "jadwal", label: "Jadwal", icon: CalendarClock },
  { id: "saluran", label: "Saluran", icon: Layers },
  { id: "atur", label: "Atur", icon: SlidersHorizontal },
  { id: "layar", label: "Layar", icon: Smartphone },
];

function Home() {
  useNotifEngine();
  const [tab, setTab] = useState<Tab>("studio");
  const editNonce = useNotifStore((state) => state.editNonce);
  const flash = useNotifStore((state) => state.flash);
  const shadeCount = useNotifStore((state) => state.shade.length);
  const now = useNotifStore((state) => state.now);
  const next = useNotifStore((state) =>
    state.schedules
      .filter((item) => item.enabled)
      .slice()
      .sort((a, b) => a.fireAt - b.fireAt)[0],
  );

  useEffect(() => {
    if (editNonce) setTab("studio");
  }, [editNonce]);

  return (
    <main className="mx-auto min-h-dvh w-full max-w-6xl px-4 pb-28 pt-6 lg:pb-10">
      <p className="sr-only" aria-live="polite">
        {flash?.text ?? ""}
      </p>
      <header className="flex items-start gap-3">
        <span className="grid size-12 shrink-0 place-items-center rounded-lg bg-primary text-primary-fg">
          <Bell className="size-6" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <p className="text-xs font-semibold tracking-widest text-primary">ANDROID</p>
          <h1 className="font-display text-3xl font-semibold leading-none">Lonceng</h1>
          <p className="mt-2 max-w-xl text-sm text-muted">
            Susun notifikasi seperti di Android: saluran, prioritas, layar kunci, dan jam berapa ia muncul.
          </p>
          <p className="mt-1 text-sm text-faint">
            {shadeCount} di panel
            {next && now > 0 ? ` · berikutnya ${next.title} dalam ${countdown(next.fireAt, now)}` : ""}
          </p>
          {flash ? <p className="mt-2 text-sm font-semibold text-primary">{flash.text}</p> : null}
        </div>
      </header>

      <div className="mt-6 grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_auto]">
        <div className="min-w-0">
          <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface px-2 py-2 lg:static lg:border-0 lg:bg-transparent lg:p-0">
            <div className="mx-auto grid max-w-lg grid-cols-5 gap-1 lg:flex lg:max-w-none">
              {TABS.map((item) => {
                const Icon = item.icon;
                const active = tab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    aria-current={active ? "page" : undefined}
                    onClick={() => setTab(item.id)}
                    className={cn(
                      "flex min-h-11 flex-col items-center justify-center gap-0.5 rounded-md px-1 text-xs font-semibold lg:flex-row lg:gap-2 lg:px-3",
                      active ? "bg-primary text-primary-fg" : "text-muted",
                      item.id === "layar" && "lg:hidden",
                    )}
                  >
                    <Icon className="size-4" aria-hidden="true" />
                    {item.label}
                  </button>
                );
              })}
            </div>
          </nav>

          <div className="mt-4">
            {tab === "studio" ? <Composer /> : null}
            {tab === "jadwal" ? <SchedulePanel /> : null}
            {tab === "saluran" ? <ChannelPanel /> : null}
            {tab === "atur" ? <SettingsPanel /> : null}
            {tab === "layar" ? (
              <div className="lg:hidden">
                <Phone />
              </div>
            ) : null}
            {tab === "layar" ? (
              <p className="hidden text-sm text-muted lg:block">
                Telepon ada di samping. Ketuk jam di bilah status untuk berganti layar kunci dan panel.
              </p>
            ) : null}
          </div>
        </div>
        <aside className="sticky top-4 hidden lg:block">
          <Phone />
        </aside>
      </div>
    </main>
  );
}
