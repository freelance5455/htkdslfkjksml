import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { Card } from "@/components/ui/card";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  daysFromToday,
  daysLabel,
  formatDate,
  formatInt,
  formatKg,
  herdStats,
  sheepName,
} from "@/lib/flock/logic";
import { useFlock } from "@/lib/flock/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const herdName = useFlock((s) => s.herdName);
  const sheep = useFlock((s) => s.sheep);
  const breeding = useFlock((s) => s.breeding);
  const health = useFlock((s) => s.health);
  const weights = useFlock((s) => s.weights);
  const loadSample = useFlock((s) => s.loadSample);
  const stats = herdStats(sheep, breeding);

  const due = breeding
    .filter((b) => b.result === "pending")
    .map((b) => ({ b, ewe: sheep.find((s) => s.id === b.eweId) }))
    .filter((row) => row.ewe)
    .sort((a, b) => a.b.expectedDate.localeCompare(b.b.expectedDate));

  const activity = [
    ...health.map((h) => ({
      id: h.id,
      date: h.date,
      title: h.title,
      meta: sheepName(sheep.find((s) => s.id === h.sheepId)),
      href: h.sheepId ? h.sheepId : null,
    })),
    ...breeding.map((b) => ({
      id: b.id,
      date: b.closedDate || b.matingDate,
      title:
        b.result === "pending"
          ? "تلقيح"
          : b.result === "lambed"
            ? `ولادة · ${formatInt(b.lambCount ?? 0)}`
            : "حمل مفقود",
      meta: sheepName(
        sheep.find((s) => s.id === b.eweId),
        "نعجة",
      ),
      href: b.eweId,
    })),
    ...weights.map((w) => ({
      id: w.id,
      date: w.date,
      title: `وزن ${formatKg(w.kg)}`,
      meta: sheepName(
        sheep.find((s) => s.id === w.sheepId),
        "رأس",
      ),
      href: w.sheepId,
    })),
  ]
    .sort((a, b) => (a.date < b.date ? 1 : -1))
    .slice(0, 5);

  return (
    <AppShell
      title={herdName || "قطيعي"}
      action={
        <Link to="/sheep/new" className="text-sm font-medium">
          إضافة
        </Link>
      }
    >
      {sheep.length === 0 ? (
        <Card className="flex flex-col gap-4">
          <div>
            <h2 className="text-lg font-semibold">لا رؤوس في السجل</h2>
            <p className="mt-2 text-sm leading-normal text-muted-foreground">
              ابدأ برقم الحلقة. السجل يبقى على هذا الجهاز، ويمكنك تصدير نسخة من
              الإعدادات.
            </p>
          </div>
          <Link to="/sheep/new" className={cn(buttonVariants(), "w-full")}>
            أضف رأساً
          </Link>
          <button
            type="button"
            onClick={loadSample}
            className="h-11 text-sm text-muted-foreground"
          >
            تعبئة قطيع مثال
          </button>
        </Card>
      ) : (
        <div className="flex flex-col gap-6">
          <section>
            <p className="text-sm text-muted-foreground">في الحظيرة</p>
            <p className="mt-1 text-5xl font-semibold tabular-nums tracking-tight">
              {formatInt(stats.total)}
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              خارجها {formatInt(stats.archive)}
              {stats.avg != null ? ` · متوسط الوزن ${formatKg(stats.avg)}` : ""}
            </p>
          </section>

          <Card className="grid grid-cols-2 gap-x-4 gap-y-5">
            <Stat
              label="كباش"
              value={stats.rams}
              to="/flock"
              search={{ f: "ram" }}
            />
            <Stat
              label="نعاج"
              value={stats.ewes}
              to="/flock"
              search={{ f: "ewe" }}
            />
            <Stat
              label="صغار"
              value={stats.lambs}
              to="/flock"
              search={{ f: "lamb" }}
            />
            <Stat
              label="حوامل"
              value={stats.pregnant}
              to="/flock"
              search={{ f: "pregnant" }}
            />
          </Card>

          {stats.sick > 0 ? (
            <Link
              to="/flock"
              search={{ f: "sick" }}
              className="flex items-center justify-between rounded-2xl border border-border px-4 py-3"
            >
              <span className="text-sm text-danger">مرضى في القطيع</span>
              <span className="text-sm font-medium tabular-nums">
                {formatInt(stats.sick)}
              </span>
            </Link>
          ) : null}

          <section className="flex flex-col gap-2">
            <h2 className="text-sm font-medium text-muted-foreground">
              أقرب الولادات
            </h2>
            {due.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                لا حمل قائم. سجّل تلقيحاً من السجلات أو من بطاقة النعجة.
              </p>
            ) : (
              <Card className="px-4 py-1">
                {due.slice(0, 5).map(({ b, ewe }) => {
                  const days = daysFromToday(b.expectedDate);
                  return (
                    <Link
                      key={b.id}
                      to="/sheep/$id"
                      params={{ id: ewe!.id }}
                      className="flex items-center justify-between gap-3 border-b border-border py-3 last:border-b-0"
                    >
                      <span>
                        <span className="block font-medium tabular-nums">
                          {ewe!.tag}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {formatDate(b.expectedDate)}
                        </span>
                      </span>
                      <span
                        className={cn(
                          "text-sm tabular-nums",
                          days < 0 && "text-danger",
                        )}
                      >
                        {daysLabel(days)}
                      </span>
                    </Link>
                  );
                })}
              </Card>
            )}
          </section>

          <section className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-medium text-muted-foreground">
                آخر ما سُجّل
              </h2>
              <Link to="/log" className="text-sm text-muted-foreground">
                السجلات
              </Link>
            </div>
            {activity.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                لا سجلات بعد. الوزن والعلاج والتلقيح تظهر هنا.
              </p>
            ) : (
              <Card className="px-4 py-1">
                {activity.map((item) => {
                  const row = (
                    <>
                      <span className="min-w-0">
                        <span className="block truncate font-medium">
                          {item.title}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {item.meta}
                        </span>
                      </span>
                      <span className="shrink-0 text-sm text-muted-foreground tabular-nums">
                        {formatDate(item.date)}
                      </span>
                    </>
                  );
                  const className =
                    "flex items-center justify-between gap-3 border-b border-border py-3 last:border-b-0";
                  return item.href ? (
                    <Link
                      key={item.id}
                      to="/sheep/$id"
                      params={{ id: item.href }}
                      className={className}
                    >
                      {row}
                    </Link>
                  ) : (
                    <div key={item.id} className={className}>
                      {row}
                    </div>
                  );
                })}
              </Card>
            )}
          </section>
        </div>
      )}
    </AppShell>
  );
}

function Stat({
  label,
  value,
  to,
  search,
}: {
  label: string;
  value: number;
  to: "/flock";
  search: { f: "ram" | "ewe" | "lamb" | "pregnant" };
}) {
  return (
    <Link to={to} search={search} className="block">
      <span className="block text-sm text-muted-foreground">{label}</span>
      <span className="mt-1 block text-2xl font-semibold tabular-nums">
        {formatInt(value)}
      </span>
    </Link>
  );
}
