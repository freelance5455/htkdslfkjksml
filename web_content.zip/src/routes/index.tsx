import { createFileRoute } from "@tanstack/react-router";
import { HajiriApp } from "@/components/hajiri/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <HajiriApp />;
}
