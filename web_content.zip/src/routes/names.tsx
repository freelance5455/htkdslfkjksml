import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Card, Page, fieldClass } from "@/components/ui";
import { NAMES, NAME_NOTE } from "@/data/names";
import { includesArabic } from "@/lib/arabic";
import { usePrefs } from "@/lib/prefs";

export const Route = createFileRoute("/names")({ component: NamesPage });

function NamesPage() {
  const [q, setQ] = useState("");
  const prefs = usePrefs();
  const list = useMemo(() => NAMES.filter((n) => !q || includesArabic(`${n.name} ${n.meaning}`, q) || String(n.n) === q), [q]);
  return (
    <Page title="الأسماء الحسنى" subtitle={NAME_NOTE}>
      <input className={fieldClass} placeholder="ابحث بالاسم أو المعنى" value={q} onChange={(e) => setQ(e.target.value)} />
      <p className="my-2 text-xs text-muted">المعروض: {list.length} من {NAMES.length}</p>
      <ul className="space-y-2">
        {list.map((n) => {
          const id = `name-${n.n}`;
          return (
            <li key={n.n}>
              <Card>
                <div className="flex items-start justify-between gap-2">
                  <h2 className="font-quran text-2xl text-emerald-deep">{n.name}</h2>
                  <button type="button" className="text-sm text-gold" onClick={() => prefs.toggleFav({ id, kind: "name", title: n.name, text: n.meaning })}>
                    {prefs.favorites.some((f) => f.id === id) ? "محفوظ" : "حفظ"}
                  </button>
                </div>
                <p className="mt-1 text-sm">{n.meaning}</p>
                <p className="mt-1 text-xs text-muted">الدليل: {n.dalil}</p>
                <p className="mt-1 text-sm text-emerald">{n.benefit}</p>
              </Card>
            </li>
          );
        })}
      </ul>
    </Page>
  );
}
