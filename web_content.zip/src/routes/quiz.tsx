import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageIntro } from "@/components/page";
import { NAMES } from "@/data/names";
import type { DivineName } from "@/data/types";
import { useProgress } from "@/lib/progress";
import { arNum } from "@/lib/utils";

export const Route = createFileRoute("/quiz")({
  head: () => ({ meta: [{ title: "اختبار المعاني — لأنه الله" }] }),
  component: QuizPage,
});

type Question = { name: DivineName; options: string[]; answer: number };

function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function buildQuiz(seed: number) {
  const rand = mulberry32(seed);
  const pool = [...NAMES];
  const questions: Question[] = [];
  while (questions.length < 8 && pool.length) {
    const index = Math.floor(rand() * pool.length);
    const name = pool.splice(index, 1)[0];
    if (!name) break;
    const options = [name.mean];
    while (options.length < 4) {
      const other = NAMES[Math.floor(rand() * NAMES.length)];
      if (other && !options.includes(other.mean)) options.push(other.mean);
    }
    for (let i = options.length - 1; i > 0; i -= 1) {
      const j = Math.floor(rand() * (i + 1));
      [options[i], options[j]] = [options[j] ?? "", options[i] ?? ""];
    }
    questions.push({ name, options, answer: options.indexOf(name.mean) });
  }
  return questions;
}

function QuizPage() {
  const [seed, setSeed] = useState<number | null>(null);
  const [cursor, setCursor] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const saveQuiz = useProgress((state) => state.saveQuiz);
  const questions = seed === null ? [] : buildQuiz(seed);
  const current = questions[cursor];
  const finished = seed !== null && cursor >= questions.length;

  function choose(option: number) {
    if (!current || picked !== null) return;
    setPicked(option);
    if (option === current.answer) setScore((value) => value + 1);
  }

  function next() {
    if (!current || picked === null) return;
    const last = cursor + 1 >= questions.length;
    const finalScore = score;
    if (last) saveQuiz(finalScore, questions.length);
    setCursor((value) => value + 1);
    setPicked(null);
  }

  return (
    <main>
      <PageIntro
        kicker="نشاط تعليمي داخل المنصة"
        title="اختبار قصير في المعاني"
        lede="ليس مسابقة رسمية ولا درجة تُرسل إلى جهة. الأسئلة من شروح الموقع نفسها."
      />
      <section className="mx-auto max-w-3xl px-4 py-8">
        {seed === null ? (
          <button type="button" onClick={() => setSeed(Date.now() % 100000)} className="rounded-full bg-primary px-5 py-3 text-primary-fg">
            ابدأ ثماني أسئلة
          </button>
        ) : null}
        {current && !finished ? (
          <article className="rounded-card border border-line bg-surface p-6">
            <p className="text-sm text-olive">سؤال {arNum(cursor + 1)} من {arNum(questions.length)}</p>
            <h2 className="mt-2 font-display text-4xl text-primary">ما المعنى الأقرب لاسم {current.name.ar}؟</h2>
            <div className="mt-5 grid gap-2">
              {current.options.map((option, index) => {
                const state = picked === null ? "" : index === current.answer ? "border-primary bg-soft" : index === picked ? "border-line opacity-70" : "";
                return (
                  <button key={option} type="button" onClick={() => choose(index)} className={`rounded-card border border-line px-4 py-3 text-start leading-7 ${state}`}>
                    {option}
                  </button>
                );
              })}
            </div>
            {picked !== null ? (
              <div className="mt-4">
                <Link to="/names/$slug" params={{ slug: current.name.slug }} className="text-sm text-primary">افتح شرح الاسم</Link>
                <button type="button" onClick={next} className="ms-3 rounded-full bg-primary px-4 py-2 text-sm text-primary-fg">التالي</button>
              </div>
            ) : null}
          </article>
        ) : null}
        {finished ? (
          <article className="rounded-card border border-line bg-surface p-6">
            <h2 className="font-display text-4xl text-primary">نتيجتك على هذا الجهاز</h2>
            <p className="mt-3 text-lg">{arNum(score)} من {arNum(questions.length)}</p>
            <p className="mt-2 text-sm text-muted">هذه نتيجة تدريب، لا شهادة ولا ترتيب بين الناس.</p>
            <button type="button" onClick={() => { setSeed(Date.now() % 100000); setCursor(0); setScore(0); setPicked(null); }} className="mt-4 rounded-full border border-line px-4 py-2">
              جولة جديدة
            </button>
          </article>
        ) : null}
      </section>
    </main>
  );
}
