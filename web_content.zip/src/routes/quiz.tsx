import { Link, createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { QUIZ } from "@/data/quiz";
import { lessonById } from "@/data/lessons";
import { Choice, btnGhost, btnGold } from "@/components/ui";
import { useVespera } from "@/lib/store";

export const Route = createFileRoute("/quiz")({ component: QuizPage });

function QuizPage() {
  const setQuizBest = useVespera((s) => s.setQuizBest);
  const quizBest = useVespera((s) => s.quizBest);
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [correct, setCorrect] = useState(0);
  const [misses, setMisses] = useState<string[]>([]);
  const [done, setDone] = useState(false);

  const q = QUIZ[step];

  function choose(i: number) {
    if (picked != null || !q) return;
    setPicked(i);
    if (i === q.answer) setCorrect((c) => c + 1);
    else setMisses((m) => (m.includes(q.lesson) ? m : [...m, q.lesson]));
  }

  function next() {
    if (step + 1 >= QUIZ.length) {
      const score = correct;
      setQuizBest(score);
      setDone(true);
      return;
    }
    setStep((s) => s + 1);
    setPicked(null);
  }

  function retry() {
    setStep(0);
    setPicked(null);
    setCorrect(0);
    setMisses([]);
    setDone(false);
  }

  if (done) {
    return (
      <div className="mx-auto max-w-xl">
        <p className="text-xs uppercase tracking-widest text-gold">Score</p>
        <h1 className="mt-2 text-5xl text-fg tabular-nums">
          {correct} <span className="text-faint">/ {QUIZ.length}</span>
        </h1>
        <p className="mt-3 text-muted">
          {correct >= 8
            ? "You can trust yourself outside. Take the chart and check one thing tonight: where the full-ish Moon sits relative to sunset."
            : "A miss is a lesson you haven't worn in yet. The notes below point back at the path."}
        </p>
        {quizBest != null && <p className="mt-2 text-sm text-faint">Best so far: {quizBest} / {QUIZ.length}</p>}
        {misses.length > 0 && (
          <ul className="mt-6 space-y-2">
            {misses.map((id) => (
              <li key={id}>
                <Link to="/lessons/$id" params={{ id }} className="text-gold">
                  Review {lessonById(id)?.title ?? id}
                </Link>
              </li>
            ))}
          </ul>
        )}
        <button type="button" className={`${btnGhost} mt-8`} onClick={retry}>
          Try again
        </button>
      </div>
    );
  }

  if (!q) return null;

  return (
    <div className="mx-auto max-w-xl">
      <p className="text-xs uppercase tracking-widest text-gold">
        Question {step + 1} of {QUIZ.length}
      </p>
      <div className="mt-3 h-1 overflow-hidden rounded-full bg-surface-2">
        <div className="h-full bg-gold" style={{ width: `${(step / QUIZ.length) * 100}%` }} />
      </div>
      <h1 className="mt-6 text-3xl text-fg md:text-4xl">{q.prompt}</h1>
      <div className="mt-6 grid gap-3">
        {q.options.map((opt, i) => (
          <Choice
            key={opt}
            selected={picked === i}
            locked={picked != null}
            correct={picked != null && i === q.answer}
            wrong={picked === i && i !== q.answer}
            onClick={() => choose(i)}
          >
            {opt}
          </Choice>
        ))}
      </div>
      {picked != null && (
        <div className="mt-5">
          <p className="text-sm text-fg">{q.why}</p>
          <button type="button" className={`${btnGold} mt-4`} onClick={next}>
            {step + 1 === QUIZ.length ? "See the score" : "Next"}
          </button>
        </div>
      )}
    </div>
  );
}
