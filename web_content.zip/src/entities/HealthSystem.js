export class HealthSystem {
  constructor(player) {
    this.player = player;
  }

  getStatus() {
    if (this.player.isDead || this.player.health <= 0) return { label: 'DEAD', color: '#ff0000', ekgSpeed: 0 };
    if (this.player.health > 65) return { label: 'FINE', color: '#00ff66', ekgSpeed: 1.0 };
    if (this.player.health > 30) return { label: 'CAUTION', color: '#ffcc00', ekgSpeed: 2.0 };
    return { label: 'DANGER', color: '#ff3300', ekgSpeed: 3.5 };
  }

  useItem(item) {
    if (this.player.isDead) return false;

    if (item.id === 'herb_green') {
      this.player.heal(35);
      return true;
    }
    if (item.id === 'herb_red') {
      // Red herb alone does nothing
      return false;
    }
    if (item.id === 'herb_mixed_gr' || item.id === 'first_aid_spray') {
      this.player.heal(100);
      return true;
    }

    return false;
  }
}
