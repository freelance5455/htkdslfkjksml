import * as THREE from 'three';
import { MeshBuilder } from '../../gfx/MeshBuilder.js';
import { audioManager } from '../../audio/AudioManager.js';

export class BossAI {
  constructor(scene, startPosition) {
    this.scene = scene;
    this.mesh = MeshBuilder.createBirkinBossMesh();
    this.mesh.position.copy(startPosition);
    this.scene.add(this.mesh);

    this.health = 1200; // Multi-phase G-Birkin boss
    this.maxHealth = 1200;
    this.isAlive = true;
    this.phase = 1; // Phase 1 (Pipe swings), Phase 2 (Rage leap attack)
    this.state = 'CHASE';

    this.moveSpeed = 2.5;
    this.attackRadius = 2.2;
    this.attackCooldown = 0;
  }

  takeDamage(amount, isHeadshot) {
    if (!this.isAlive) return;

    // Shooting giant shoulder eye deals double weakness damage
    const damageDealt = isHeadshot ? amount * 2.5 : amount;
    this.health -= damageDealt;

    if (this.health <= 600 && this.phase === 1) {
      this.phase = 2; // Enrage phase!
      this.moveSpeed = 4.0;
      this.mesh.scale.set(1.2, 1.2, 1.2);
      audioManager.playZombieGroan();
    }

    if (this.health <= 0) {
      this.die();
    }
  }

  die() {
    this.isAlive = false;
    this.state = 'DEAD';
    this.mesh.rotation.x = Math.PI / 2;
    this.mesh.position.y = 0.1;
  }

  update(delta, player) {
    if (!this.isAlive) return;

    if (this.attackCooldown > 0) this.attackCooldown -= delta;

    const distToPlayer = this.mesh.position.distanceTo(player.mesh.position);

    const targetPos = player.mesh.position.clone();
    targetPos.y = this.mesh.position.y;
    this.mesh.lookAt(targetPos);

    const dir = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.mesh.rotation.y);

    if (distToPlayer <= this.attackRadius) {
      this.state = 'ATTACK';
      if (this.attackCooldown <= 0 && !player.isDead) {
        player.takeDamage(this.phase === 2 ? 60 : 35);
        audioManager.playZombieGroan();
        this.attackCooldown = this.phase === 2 ? 1.2 : 2.0;
      }
    } else {
      this.state = 'CHASE';
      this.mesh.position.add(dir.multiplyScalar(this.moveSpeed * delta));
    }
  }
}
