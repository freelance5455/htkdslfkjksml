import * as THREE from 'three';
import { MeshBuilder } from '../../gfx/MeshBuilder.js';
import { audioManager } from '../../audio/AudioManager.js';

export class MrXAI {
  constructor(scene, startPosition) {
    this.scene = scene;
    this.mesh = MeshBuilder.createMrXMesh();
    this.mesh.position.copy(startPosition);
    this.scene.add(this.mesh);

    this.health = 800; // Indestructible stalker, only temporarily stunned
    this.isAlive = true;
    this.state = 'PATROL'; // PATROL, CHASE, ATTACK, STUNNED
    this.moveSpeed = 2.2;
    this.attackRadius = 1.8;

    this.stepTimer = 0;
    this.stunTimer = 0;
    this.attackCooldown = 0;
  }

  takeDamage(amount) {
    this.health -= amount;
    if (this.health <= 0) {
      this.state = 'STUNNED';
      this.stunTimer = 12.0; // Stuns Mr. X on knee for 12 seconds
      this.health = 800; // Reset HP for when he wakes up
      this.mesh.position.y = 0;
    }
  }

  update(delta, player, isPlayerInSafeRoom = false) {
    if (this.attackCooldown > 0) this.attackCooldown -= delta;

    // Handle Stunned state
    if (this.state === 'STUNNED') {
      this.stunTimer -= delta;
      if (this.stunTimer <= 0) {
        this.state = 'CHASE';
      }
      return;
    }

    // Mr. X NEVER enters Safe Rooms!
    if (isPlayerInSafeRoom) {
      this.state = 'PATROL';
      return;
    }

    const distToPlayer = this.mesh.position.distanceTo(player.mesh.position);

    // Mr. X hears gunshots from anywhere in RPD or sees player within range
    const isPlayerSpotted = distToPlayer < 18.0;

    if (isPlayerSpotted) {
      this.state = 'CHASE';

      const targetPos = player.mesh.position.clone();
      targetPos.y = this.mesh.position.y;
      this.mesh.lookAt(targetPos);

      const dir = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.mesh.rotation.y);

      if (distToPlayer <= this.attackRadius) {
        this.state = 'ATTACK';
        if (this.attackCooldown <= 0 && !player.isDead) {
          player.takeDamage(50); // Devastating heavy punch
          audioManager.playMrXStep();
          this.attackCooldown = 2.0;
        }
      } else {
        this.mesh.position.add(dir.multiplyScalar(this.moveSpeed * delta));

        // Iconic heavy footsteps
        this.stepTimer += delta;
        if (this.stepTimer >= 0.6) {
          audioManager.playMrXStep();
          this.stepTimer = 0;
        }
      }
    } else {
      this.state = 'PATROL';
    }
  }
}
