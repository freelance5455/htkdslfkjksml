import * as THREE from 'three';
import { MeshBuilder } from '../../gfx/MeshBuilder.js';
import { audioManager } from '../../audio/AudioManager.js';

export class LickerAI {
  constructor(scene, startPosition) {
    this.scene = scene;
    this.mesh = MeshBuilder.createLickerMesh();
    this.mesh.position.copy(startPosition);
    this.scene.add(this.mesh);

    this.health = 180;
    this.isAlive = true;
    this.state = 'LISTENING'; // LISTENING, LEAP, CHASE, ATTACK, STAGGER
    this.moveSpeed = 3.8;
    this.attackRadius = 2.0;

    this.attackCooldown = 0;
    this.staggerTimer = 0;
  }

  takeDamage(amount, isHeadshot, hitDirection) {
    if (!this.isAlive) return;

    this.health -= amount;
    this.state = 'STAGGER';
    this.staggerTimer = 0.4;

    if (this.health <= 0) {
      this.die();
    }
  }

  die() {
    this.isAlive = false;
    this.state = 'DEAD';
    this.mesh.rotation.z = Math.PI; // Flip over
    this.mesh.position.y = 0.2;
  }

  update(delta, player) {
    if (!this.isAlive) return;

    if (this.attackCooldown > 0) this.attackCooldown -= delta;

    if (this.state === 'STAGGER') {
      this.staggerTimer -= delta;
      if (this.staggerTimer <= 0) this.state = 'CHASE';
      return;
    }

    const distToPlayer = this.mesh.position.distanceTo(player.mesh.position);

    // Lickers are blind! They respond to running footsteps or gunshots
    const canHearPlayer = player.isRunning || player.isAiming || distToPlayer < 3.0;

    if (canHearPlayer || this.state === 'CHASE') {
      this.state = 'CHASE';

      const targetPos = player.mesh.position.clone();
      targetPos.y = this.mesh.position.y;
      this.mesh.lookAt(targetPos);

      const dir = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.mesh.rotation.y);

      if (distToPlayer <= this.attackRadius) {
        this.state = 'ATTACK';
        if (this.attackCooldown <= 0 && !player.isDead) {
          player.takeDamage(40); // High claw damage
          audioManager.playZombieGroan();
          this.attackCooldown = 1.5;
        }
      } else {
        this.mesh.position.add(dir.multiplyScalar(this.moveSpeed * delta));
      }
    } else {
      this.state = 'LISTENING';
    }
  }
}
