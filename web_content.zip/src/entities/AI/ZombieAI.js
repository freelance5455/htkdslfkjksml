import * as THREE from 'three';
import { MeshBuilder } from '../../gfx/MeshBuilder.js';
import { audioManager } from '../../audio/AudioManager.js';

export class ZombieAI {
  constructor(scene, startPosition) {
    this.scene = scene;
    this.mesh = MeshBuilder.createZombieMesh();
    this.mesh.position.copy(startPosition);
    this.scene.add(this.mesh);

    this.health = 100;
    this.isAlive = true;
    this.state = 'IDLE'; // IDLE, WANDER, CHASE, ATTACK, STAGGER
    this.moveSpeed = 1.2;
    this.detectionRadius = 10.0;
    this.attackRadius = 1.3;

    this.groanTimer = Math.random() * 5.0;
    this.staggerTimer = 0;
    this.attackCooldown = 0;
  }

  takeDamage(amount, isHeadshot, hitDirection) {
    if (!this.isAlive) return;

    this.health -= amount;
    this.state = 'STAGGER';
    this.staggerTimer = 0.5;

    // Knockback
    if (hitDirection) {
      this.mesh.position.add(hitDirection.clone().multiplyScalar(0.3));
    }

    if (this.health <= 0) {
      this.die();
    }
  }

  die() {
    this.isAlive = false;
    this.state = 'DEAD';
    this.mesh.rotation.x = Math.PI / 2; // Fall to floor
    this.mesh.position.y = 0.1;
  }

  update(delta, player) {
    if (!this.isAlive) return;

    if (this.attackCooldown > 0) this.attackCooldown -= delta;

    // Groan Audio
    this.groanTimer -= delta;
    if (this.groanTimer <= 0) {
      if (Math.random() < 0.4) audioManager.playZombieGroan();
      this.groanTimer = 4.0 + Math.random() * 6.0;
    }

    // Stagger check
    if (this.state === 'STAGGER') {
      this.staggerTimer -= delta;
      if (this.staggerTimer <= 0) {
        this.state = 'CHASE';
      }
      return;
    }

    const distToPlayer = this.mesh.position.distanceTo(player.mesh.position);

    if (distToPlayer <= this.attackRadius) {
      // Attack Player
      this.state = 'ATTACK';
      if (this.attackCooldown <= 0 && !player.isDead) {
        player.takeDamage(25);
        this.attackCooldown = 1.8;
      }
    } else if (distToPlayer <= this.detectionRadius) {
      // Chase Player
      this.state = 'CHASE';

      // Look at player
      const targetPos = player.mesh.position.clone();
      targetPos.y = this.mesh.position.y;
      this.mesh.lookAt(targetPos);

      // Move forward
      const dir = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.mesh.rotation.y);
      this.mesh.position.add(dir.multiplyScalar(this.moveSpeed * delta));
    } else {
      this.state = 'IDLE';
    }
  }
}
