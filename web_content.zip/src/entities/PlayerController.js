import * as THREE from 'three';
import { MeshBuilder } from '../gfx/MeshBuilder.js';
import { audioManager } from '../audio/AudioManager.js';

export class PlayerController {
  constructor(scene, camera) {
    this.scene = scene;
    this.camera = camera;

    // Player Mesh
    this.mesh = MeshBuilder.createLeonMesh();
    this.scene.add(this.mesh);
    this.mesh.position.set(0, 0, 0);

    // Player bounding radius for physics collision
    this.radius = 0.45;

    // Flashlight attached to player
    this.flashlight = new THREE.SpotLight(0xfff5ea, 8.0, 18, Math.PI / 6, 0.4, 1.0);
    this.flashlight.position.set(0.2, 1.1, 0.2);
    this.flashlight.castShadow = true;
    this.mesh.add(this.flashlight);

    this.flashlightTarget = new THREE.Object3D();
    this.flashlightTarget.position.set(0.2, 1.1, 5);
    this.mesh.add(this.flashlightTarget);
    this.flashlight.target = this.flashlightTarget;

    // Movement Parameters
    this.walkSpeed = 2.8;
    this.runSpeed = 5.2;
    this.turnSpeed = 2.5;

    // Player State
    this.isAiming = false;
    this.isRunning = false;
    this.isDead = false;
    this.health = 100;
    this.status = 'FINE'; // FINE, CAUTION, DANGER
    this.flashlightOn = true;

    // Weapon & Inventory reference
    this.currentWeapon = 'handgun';
    this.ammo = {
      handgun: 15,
      handgunReserve: 30,
      shotgun: 4,
      shotgunReserve: 12,
      magnum: 6,
      magnumReserve: 6,
      knife: 100 // Durability
    };

    // Input States
    this.keys = {};
    this.setupInput();

    // Step Timer
    this.stepTimer = 0;
  }

  setupInput() {
    window.addEventListener('keydown', (e) => {
      this.keys[e.code] = true;

      if (e.code === 'KeyF') {
        this.toggleFlashlight();
      }
      if (e.code === 'KeyR') {
        this.reload();
      }
      if (e.code === 'Digit1') this.currentWeapon = 'handgun';
      if (e.code === 'Digit2') this.currentWeapon = 'shotgun';
      if (e.code === 'Digit3') this.currentWeapon = 'magnum';
      if (e.code === 'Digit4') this.currentWeapon = 'knife';
    });

    window.addEventListener('keyup', (e) => {
      this.keys[e.code] = false;
    });
  }

  toggleFlashlight() {
    this.flashlightOn = !this.flashlightOn;
    this.flashlight.visible = this.flashlightOn;
    audioManager.playUIClick();
  }

  takeDamage(amount) {
    if (this.isDead) return;

    this.health = Math.max(0, this.health - amount);
    audioManager.playZombieGroan();

    if (this.health > 60) this.status = 'FINE';
    else if (this.health > 25) this.status = 'CAUTION';
    else if (this.health > 0) this.status = 'DANGER';
    else {
      this.status = 'DEAD';
      this.isDead = true;
      this.mesh.rotation.x = -Math.PI / 2; // Fall down
    }
  }

  heal(amount) {
    if (this.isDead) return;
    this.health = Math.min(100, this.health + amount);
    if (this.health > 60) this.status = 'FINE';
    else if (this.health > 25) this.status = 'CAUTION';
    else this.status = 'DANGER';
  }

  reload() {
    const key = this.currentWeapon;
    if (key === 'knife') return;

    const reserveKey = key + 'Reserve';

    if (this.ammo[reserveKey] > 0) {
      const maxCap = key === 'handgun' ? 15 : key === 'shotgun' ? 6 : 6;
      const needed = maxCap - (this.ammo[key] || 0);
      const amountToLoad = Math.min(needed, this.ammo[reserveKey]);

      if (amountToLoad > 0) {
        this.ammo[key] += amountToLoad;
        this.ammo[reserveKey] -= amountToLoad;
        audioManager.playUIClick();
      }
    }
  }

  checkCollisions(newPos, colliders = [], doors = []) {
    const playerBox = new THREE.Box3().setFromCenterAndSize(
      new THREE.Vector3(newPos.x, 1, newPos.z),
      new THREE.Vector3(this.radius * 2, 2, this.radius * 2)
    );

    // Collide with environment walls/objects
    for (const obj of colliders) {
      const box = new THREE.Box3().setFromObject(obj);
      if (playerBox.intersectsBox(box)) {
        return true;
      }
    }

    // Collide with locked/closed doors
    for (const d of doors) {
      if (!d.isOpen) {
        const doorBox = new THREE.Box3().setFromObject(d.group);
        if (playerBox.intersectsBox(doorBox)) {
          return true;
        }
      }
    }

    return false;
  }

  update(delta, colliders = [], doors = []) {
    if (this.isDead) return;

    // Aiming toggle (Right Mouse or Shift or KeyV)
    this.isAiming = !!(this.keys['MouseRight'] || this.keys['KeyV'] || this.keys['ShiftRight']);
    this.isRunning = !!(this.keys['ShiftLeft'] || this.keys['KeyX']) && !this.isAiming;

    // Classic RE Tank Controls + Modern Third Person
    let moveForward = 0;
    let turn = 0;

    if (this.keys['KeyW'] || this.keys['ArrowUp']) moveForward += 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) moveForward -= 0.6; // Backpedal slower
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) turn += 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) turn -= 1;

    // Rotation
    if (turn !== 0) {
      this.mesh.rotation.y += turn * this.turnSpeed * delta;
    }

    // Translation with physics collision handling
    if (moveForward !== 0 && !this.isAiming) {
      const currentSpeed = (this.isRunning ? this.runSpeed : this.walkSpeed) * (this.status === 'DANGER' ? 0.6 : 1.0);
      const moveDist = moveForward * currentSpeed * delta;

      const forwardVec = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.mesh.rotation.y);
      const targetPos = this.mesh.position.clone().add(forwardVec.multiplyScalar(moveDist));

      // Validate target position with collision box check
      if (!this.checkCollisions(targetPos, colliders, doors)) {
        this.mesh.position.copy(targetPos);
      } else {
        // Try sliding X axis
        const targetPosX = this.mesh.position.clone().add(new THREE.Vector3(forwardVec.x * moveDist, 0, 0));
        if (!this.checkCollisions(targetPosX, colliders, doors)) {
          this.mesh.position.copy(targetPosX);
        } else {
          // Try sliding Z axis
          const targetPosZ = this.mesh.position.clone().add(new THREE.Vector3(0, 0, forwardVec.z * moveDist));
          if (!this.checkCollisions(targetPosZ, colliders, doors)) {
            this.mesh.position.copy(targetPosZ);
          }
        }
      }

      // Footstep Sound Timer
      this.stepTimer += delta * (this.isRunning ? 2.2 : 1.2);
      if (this.stepTimer >= 0.5) {
        audioManager.playFootstep();
        this.stepTimer = 0;
      }
    }

    // Quick Turn (S + Run key)
    if ((this.keys['KeyS'] || this.keys['ArrowDown']) && (this.keys['ShiftLeft'] || this.keys['KeyX'])) {
      this.mesh.rotation.y += Math.PI;
      this.keys['KeyS'] = false;
    }
  }
}
