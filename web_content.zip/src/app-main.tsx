import { useApp, type Screen } from "@/store/app-store";
import { useEffect } from "react";
import { BootScreen, LockScreen, TabBar, ToastHost } from "@/screens/chrome";
import { DashboardScreen } from "@/screens/dashboard";
import { GridsScreen, HistoryScreen, StatsScreen } from "@/screens/lists";
import {
  DatesScreen,
  GoldScreen,
  RadarScreen,
  SimilarScreen,
  TurboScreen,
  TwoSureScreen,
} from "@/screens/engines";
import { NumberScreen, PairDetailScreen, PairListScreen } from "@/screens/pairs";
import {
  AddDrawScreen,
  ArchiveScreen,
  AssistantScreen,
  NewsScreen,
  PredictionScreen,
  SettingsScreen,
} from "@/screens/more";

function ScreenBody({ screen }: { screen: Screen }) {
  switch (screen.id) {
    case "dashboard":
      return <DashboardScreen />;
    case "history":
      return <HistoryScreen />;
    case "grids":
      return <GridsScreen />;
    case "stats":
      return <StatsScreen />;
    case "prediction":
      return <PredictionScreen />;
    case "assistant":
      return <AssistantScreen />;
    case "gold":
      return <GoldScreen />;
    case "similar":
      return <SimilarScreen />;
    case "dates":
      return <DatesScreen />;
    case "radar":
      return <RadarScreen />;
    case "turbo2":
      return <TurboScreen />;
    case "twosure":
      return <TwoSureScreen />;
    case "sum-pairs":
      return <PairListScreen kind="sum" />;
    case "gap-pairs":
      return <PairListScreen kind="gap" />;
    case "pair":
      return <PairDetailScreen a={screen.a} b={screen.b} />;
    case "number":
      return <NumberScreen n={screen.n} />;
    case "archive":
      return <ArchiveScreen />;
    case "settings":
      return <SettingsScreen />;
    case "news":
      return <NewsScreen />;
    case "add":
      return <AddDrawScreen editDate={screen.editDate} />;
    default:
      return <DashboardScreen />;
  }
}

const TAB_IDS = new Set(["dashboard", "history", "grids", "stats", "prediction", "assistant"]);

export function AppMain() {
  const ready = useApp((s) => s.ready);
  const unlocked = useApp((s) => s.unlocked);
  const hydrate = useApp((s) => s.hydrate);
  const stack = useApp((s) => s.stack);
  const lockOnBlur = useApp((s) => s.lockOnBlur);
  const lock = useApp((s) => s.lock);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === "visible" && lockOnBlur && useApp.getState().unlocked) {
        lock();
      }
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [lockOnBlur, lock]);

  if (!ready) return <BootScreen />;
  if (!unlocked) return <LockScreen />;

  const top = stack[stack.length - 1] ?? { id: "dashboard" as const };
  const showTabs = stack.length === 1 && TAB_IDS.has(top.id);

  return (
    <div className="phone-shell text-ivory">
      <div className="phone-frame mx-auto flex min-h-dvh max-w-[430px] flex-col bg-bg">
        <div className="min-h-0 flex-1 overflow-y-auto">
          <ScreenBody screen={top} />
        </div>
        {showTabs && <TabBar />}
        <ToastHost />
      </div>
    </div>
  );
}
