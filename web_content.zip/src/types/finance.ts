export type AccountType = 'CASH' | 'BANK' | 'MFS';

export interface Account {
  id: string;
  nameBn: string;
  nameEn: string;
  type: AccountType;
  openingBalancePaisa: number; // Stored in exact integer paisa (1 BDT = 100 paisa)
  accountNumber?: string;
  institution?: string;
  createdAt: string;
  isDemo?: boolean;
}

export type TransactionType = 'SALE' | 'INCOME' | 'EXPENSE' | 'PURCHASE' | 'TRANSFER';

export interface TransactionRecord {
  id: string;
  type: TransactionType;
  amountPaisa: number; // Exact integer paisa (> 0)
  date: string; // YYYY-MM-DD
  category: string;
  accountId: string;
  toAccountId?: string; // Required only when type === 'TRANSFER'
  note: string;
  reference?: string;
  linkedDebtId?: string; // If linked to a debt disbursement/repayment, never double-counted as income/expense
  linkedSubscriptionId?: string;
  createdAt: string;
  isDemo?: boolean;
}

export type DebtDirection =
  | 'LENT' // ধার দেওয়া (Money I lent to someone -> Receivable / পাওনা)
  | 'RECEIVABLE_OTHER' // অন্যান্য পাওনা (Other money people owe me, e.g., credit sale -> Receivable / পাওনা)
  | 'BORROWED' // ধার নেওয়া (Money I borrowed from someone -> Payable / দেনা)
  | 'PAYABLE_OTHER'; // অন্যান্য দেনা (Money I owe others, e.g., supplier credit -> Payable / দেনা)

export interface RepaymentRecord {
  id: string;
  debtId: string;
  amountPaisa: number;
  date: string; // YYYY-MM-DD
  accountId?: string; // Optional account where money was received/paid
  note: string;
  createdAt: string;
}

export interface DebtRecord {
  id: string;
  direction: DebtDirection;
  contactName: string;
  phone?: string;
  principalPaisa: number; // Original amount in paisa
  date: string; // YYYY-MM-DD
  dueDate?: string; // YYYY-MM-DD
  accountId?: string; // Optional account impacted at origination
  notes: string;
  repayments: RepaymentRecord[];
  createdAt: string;
  isDemo?: boolean;
}

export type BillingCycle = 'MONTHLY' | 'YEARLY' | 'CUSTOM_DAYS';

export interface SubscriptionPaymentRecord {
  id: string;
  subscriptionId: string;
  amountPaisa: number;
  paidDate: string; // YYYY-MM-DD
  forPeriodDueDate: string; // The due date cycle this payment covered
  accountId?: string;
  transactionId?: string; // Optional linked expense transaction ID
  note: string;
}

export interface SubscriptionRecord {
  id: string;
  nameBn: string;
  nameEn: string;
  amountPaisa: number;
  cycle: BillingCycle;
  customDays?: number; // Used if cycle === 'CUSTOM_DAYS'
  nextDueDate: string; // YYYY-MM-DD
  category: string;
  defaultAccountId?: string;
  active: boolean;
  notes: string;
  paymentHistory: SubscriptionPaymentRecord[];
  createdAt: string;
  isDemo?: boolean;
}

export interface CustomCategory {
  id: string;
  nameBn: string;
  nameEn: string;
  applicableTo: ('SALE' | 'INCOME' | 'EXPENSE' | 'PURCHASE')[];
}

export interface HisabKhataBackupSchema {
  schemaVersion: 1;
  appName: 'HisabKhata';
  exportedAt: string;
  currency: 'BDT';
  accounts: Account[];
  transactions: TransactionRecord[];
  debts: DebtRecord[];
  subscriptions: SubscriptionRecord[];
  categories: CustomCategory[];
}

export type ActiveTab = 'HOME' | 'TRANSACTIONS' | 'DEBTS' | 'SUBSCRIPTIONS' | 'MORE';
