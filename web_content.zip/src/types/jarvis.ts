export type AssistantState =
  | 'sleeping'
  | 'listening'
  | 'thinking'
  | 'speaking'
  | 'error';

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  language?: string;
  status?: 'complete' | 'error';
}

export interface AssistantSettings {
  voiceEnabled: boolean;
  autoSpeak: boolean;
  selectedVoiceURI: string;
  speechRate: number; // 0.7 - 1.5
  speechPitch: number; // 0.8 - 1.3
  language: string; // 'auto', 'bn', 'en', 'hi', 'es', 'fr', 'ar', 'de', 'ja'
  userTitle: string; // 'Sir', 'Boss', 'Commander', etc.
  soundEffects: boolean;
  continuousListening: boolean;
  hapticFeedback: boolean;
  voiceBargeIn: boolean;
}

export interface ApiStatus {
  online: boolean;
  configured: boolean;
  model: string;
  persona: string;
  speechReady: boolean;
  languages: Array<{ code: string; name: string }>;
}
