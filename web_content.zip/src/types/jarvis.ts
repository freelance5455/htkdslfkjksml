export interface CalendarEvent {
  id: string;
  title: string;
  startTime: string; // ISO string e.g. 2026-10-22T10:00:00
  endTime: string;   // ISO string e.g. 2026-10-22T11:00:00
  location?: string;
  category: 'work' | 'personal' | 'ops' | 'health';
  priority: 'low' | 'normal' | 'high';
  notified?: boolean;
}

export interface Reminder {
  id: string;
  title: string;
  dueTime: string | null; // ISO string or null for anytime
  completed: boolean;
  priority: 'normal' | 'urgent';
  category: string;
  notified?: boolean;
}

export interface Contact {
  id: string;
  name: string;
  phone: string;
  role: string;
  favorite?: boolean;
}

export interface AndroidApp {
  id: string;
  name: string;
  category: 'Comms' | 'Tools' | 'Media' | 'Social' | 'Google';
  intentUrl: string;
  webFallback: string;
  iconName: string;
  color: string;
}

export interface DeviceSettings {
  flashlight: boolean;
  vibrate: boolean;
  soundMode: 'normal' | 'vibrate' | 'silent';
  nightMode: boolean;
  batterySaver: boolean;
  dnd: boolean;
  voiceFeedback: boolean;
  continuousListening: boolean;
  volume: number; // 0 to 100
  brightness: number; // 10 to 100
}

export type JarvisActionType =
  | 'ADD_EVENT'
  | 'MODIFY_EVENT'
  | 'DELETE_EVENT'
  | 'ADD_REMINDER'
  | 'MODIFY_REMINDER'
  | 'DELETE_REMINDER'
  | 'MAKE_CALL'
  | 'SEND_MESSAGE'
  | 'OPEN_APP'
  | 'TOGGLE_SETTING'
  | 'BRIEFING'
  | 'QUERY_SCHEDULE'
  | 'GENERAL_RESPONSE';

export interface JarvisAction {
  type: JarvisActionType;
  payload?: any;
}

export interface JarvisResponse {
  speechText: string;
  action: JarvisAction;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  command: string;
  response: string;
  actionType: JarvisActionType;
}
