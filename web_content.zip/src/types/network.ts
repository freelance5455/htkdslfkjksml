/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type DeviceType = 'console' | 'mobile' | 'pc' | 'tv' | 'iot' | 'network';
export type PriorityTier = 'critical' | 'high' | 'medium' | 'low';
export type RouterBrand = 'openwrt' | 'asuswrt' | 'ddwrt' | 'tplink' | 'mikrotik' | 'netgear';

export interface NetworkDevice {
  id: string;
  name: string;
  customAlias?: string;
  vendor: string;
  ip: string;
  mac: string;
  type: DeviceType;
  isOnline: boolean;
  currentDlMbps: number;
  currentUlMbps: number;
  totalUsageMb: number;
  downloadLimitMbps: number | null; // null = unlimited
  uploadLimitMbps: number | null;   // null = unlimited
  isPaused: boolean;                // Internet paused for this device
  isGamingPriority: boolean;        // High-priority gaming lane
  priorityTier: PriorityTier;
  wifiBand: '2.4GHz' | '5GHz' | '6GHz' | 'Ethernet';
  rssiDbm: number;                  // Signal strength (-30 excellent to -85 weak)
  hostname: string;
  staticIpAssigned?: boolean;
}

export interface MetricHistoryPoint {
  time: string;
  download: number;
  upload: number;
  ping: number;
  jitter: number;
}

export interface WifiChannelInfo {
  channel: number;
  band: '2.4GHz' | '5GHz';
  frequencyMhz: number;
  interferencePct: number;
  neighborCount: number;
  isRecommended?: boolean;
  isCurrent?: boolean;
}

export interface NeighborWifi {
  ssid: string;
  bssid: string;
  channel: number;
  band: '2.4GHz' | '5GHz';
  rssiDbm: number;
  security: string;
}

export interface DnsBenchmarkResult {
  name: string;
  primaryIp: string;
  secondaryIp: string;
  latencyMs: number;
  features: string;
  isCurrent?: boolean;
}

export interface GameServerPing {
  game: string;
  region: string;
  location: string;
  pingMs: number;
  status: 'optimal' | 'good' | 'moderate' | 'high';
}

export interface RouterConfig {
  brand: RouterBrand;
  ip: string;
  model: string;
  firmware: string;
  uptime: string;
  qosEngine: 'Cake (SQM)' | 'fq_codel' | 'Adaptive QoS' | 'Simple Queue';
  connectedStatus: 'connected' | 'syncing' | 'offline';
  lastSynced: string;
}
