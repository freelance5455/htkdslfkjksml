export type AttendanceMark = 'present' | 'absent';
export type ShiftType = 'day' | 'night';

export interface Worker {
  id: string;
  name: string;
  role: string;
}

export interface DailyAttendanceRecord {
  marks: Record<string, AttendanceMark>;
  submitted: boolean;
  submittedAt?: string;
}

export interface Department {
  id: string;
  name: string;
  supervisor: string;
  isPrimary?: boolean;
  workers: Worker[];
  // Keyed by YYYY-MM-DD__day / YYYY-MM-DD__night (or legacy YYYY-MM-DD)
  attendanceByDate: Record<string, DailyAttendanceRecord>;
}

export interface AppState {
  departments: Department[];
}

export interface DepartmentSummary {
  total: number;
  present: number;
  absent: number;
  unmarked: number;
  submitted: boolean;
  submittedAt?: string;
}

export interface GlobalOverview {
  totalDepartments: number;
  totalWorkers: number;
  presentToday: number;
  absentToday: number;
}
