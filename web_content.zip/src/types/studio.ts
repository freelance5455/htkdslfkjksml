export type NavSection =
  | 'dashboard'
  | 'projects'
  | 'preview'
  | 'settings'
  | 'build'
  | 'premium'
  | 'account'
  | 'account-settings'
  | 'notifications'
  | 'payments'
  | 'admin'
  | 'admin-code';

export type ThemeMode = 'dark' | 'light';

export interface UserAccount {
  id: string;
  username: string;
  email: string;
  role: 'user' | 'admin';
  avatarUrl?: string | null;
  bio?: string | null;
  themePref?: ThemeMode;
  createdAt: string;
}

export interface MembershipInfo {
  tier: 'free' | 'premium';
  isPremium: boolean;
  isLifetime: boolean;
  planCode: string;
  planName: string;
  subscriptionId: string | null;
  startedAt: string | null;
  expiresAt: string | null;
  remainingDays: number | null;
  limits: {
    maxProjects: number;
    monthlyBuilds: number;
    maxUploadMb: number;
    priorityQueue: boolean;
    premiumIcons: boolean;
    adFree: boolean;
  };
  usage: {
    projectCount: number;
    monthKey: string;
    monthlyBuildsUsed: number;
    remainingMonthlyBuilds: number;
  };
}

export interface ApkConfig {
  appName: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  iconPreset: 'nebula' | 'commerce' | 'media' | 'utility' | 'cobalt' | 'aurum' | 'custom';
  customIconPath?: string | null;
  adaptiveIconEnabled?: boolean;
  adaptiveBgColor?: string;
  customForegroundPath?: string | null;
  splashEnabled: boolean;
  splashBgColor: string;
  splashTitle: string;
  splashDurationMs: number;
  orientation: 'unspecified' | 'portrait' | 'landscape';
  fullscreen: boolean;
  statusBarVisible: boolean;
  statusBarColor: string;
  navigationBarVisible: boolean;
  navigationBarColor: string;
  internetPermission: boolean;
  offlineEnabled?: boolean;
  launchAnimation: 'fade' | 'slide' | 'scale' | 'none';
}

export interface ProjectFileEntry {
  path: string;
  size: number;
  isBinary: boolean;
}

export interface ProjectSummary {
  id: string;
  name: string;
  entry_file: string;
  total_files: number;
  total_size_bytes: number;
  config: ApkConfig;
  build_count?: number;
  last_build_status?: string | null;
  created_at: string;
  updated_at: string;
}

export interface ProjectDetail extends ProjectSummary {
  files: ProjectFileEntry[];
  htmlFiles: string[];
}

export interface BuildLogEntry {
  timestamp: string;
  stage: string;
  level: 'info' | 'success' | 'warn' | 'error';
  message: string;
}

export interface BuildJob {
  id: string;
  project_id: string;
  project_name?: string;
  app_name?: string;
  package_name?: string;
  version_name?: string;
  status: 'queued' | 'running' | 'completed_apk' | 'completed_bundle' | 'failed' | 'cancelled';
  stage: string;
  stage_index: number;
  total_stages: number;
  build_mode: string;
  artifact_filename: string | null;
  artifact_size_bytes: number;
  sha256: string | null;
  logs: BuildLogEntry[];
  error_message: string | null;
  is_priority: number;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
}

export interface SubscriptionPlan {
  id: string;
  code: string;
  name: string;
  price_try: number;
  duration_days: number | null;
  is_lifetime: number;
  description: string;
  features: string[];
  is_highlighted: number;
}

export interface SystemLimitsRow {
  tier: 'free' | 'premium';
  max_projects: number;
  monthly_builds: number;
  max_upload_mb: number;
  priority_queue: number;
  premium_icons: number;
  ad_free: number;
}

export interface PaymentRecord {
  id: string;
  user_id: string;
  user_email?: string;
  username?: string;
  plan_id: string;
  plan_name: string;
  plan_code?: string;
  provider: string;
  provider_reference: string;
  amount_try: number;
  original_amount_try?: number | null;
  discount_try?: number;
  promo_code?: string | null;
  currency: string;
  status: string;
  is_test_mode: number;
  created_at: string;
  completed_at: string | null;
}

export interface NotificationItem {
  id: string;
  user_id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  is_read: number;
  link_section: string | null;
  created_at: string;
}

export interface PromoCodeRow {
  id: string;
  code: string;
  discount_percent: number;
  max_uses: number;
  current_uses: number;
  expires_at: string | null;
  is_active: number;
  created_at: string;
}

export interface ErrorLogRow {
  id: string;
  user_id: string | null;
  user_email?: string | null;
  source: string;
  level: string;
  message: string;
  stack: string | null;
  path: string | null;
  created_at: string;
}

export interface SystemCapabilities {
  dockerAvailable: boolean;
  localGradleAvailable: boolean;
  androidSdkAvailable: boolean;
  activeCompilerMode: 'docker_gradle' | 'local_gradle' | 'bundle_only';
  summary: string;
}

export interface PaymentProviderStatus {
  provider: 'paytr' | 'iyzico' | 'test_demo';
  isLiveConfigured: boolean;
  label: string;
}
