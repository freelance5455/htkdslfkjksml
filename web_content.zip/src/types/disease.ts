export type DiseaseLanguage = 'English' | 'Hindi' | 'Marathi';

export interface DiseaseFaq {
  question: string;
  answer: string;
}

export interface DiseaseDetailContent {
  name: string;
  category: string;
  summary: string;
  whatIsIt: string;
  causes: string[];
  symptoms: string[];
  riskFactors: string[];
  prevention: string[];
  diagnosis: string[];
  treatmentOverview: string[];
  lifestyleTips: string[];
  whenToConsultDoctor: string[];
  emergencyWarningSigns: string[];
  faqs: DiseaseFaq[];
}

export interface DiseaseItem {
  id: string;
  iconName: string;
  category: 'Chronic' | 'Infectious' | 'Respiratory' | 'Vector-borne' | 'Digestive' | 'General';
  bgGradient: string;
  badgeBg: string;
  badgeText: string;
  content: {
    English: DiseaseDetailContent;
    Hindi: DiseaseDetailContent;
    Marathi: DiseaseDetailContent;
  };
}
