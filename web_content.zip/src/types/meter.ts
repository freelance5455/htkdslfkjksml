export interface MeterRecord {
  id: string;
  gda: string;
  ref: string;
  ctr: string;
  index: number;
  compt: string;
  saisie: boolean;
  nonSaisie: boolean;
  bloque: boolean;
  nouvIndex: number | null;
  hublotTaps: boolean;
  clientAbsent: boolean;
  necessiteVerification: boolean;
  sansPlombage: boolean;
  numFI: string;
  observation: string;
  // Extended location and field inspector data
  latitude?: number | null;
  longitude?: number | null;
  address?: string;
  clientName?: string;
  phone?: string;
  dateReleve?: string | null;
  photoUrl?: string | null;
}

export type MeterFilterStatus = 
  | 'all' 
  | 'saisie' 
  | 'nonSaisie' 
  | 'bloque' 
  | 'clientAbsent' 
  | 'hublotTaps'
  | 'sansPlombage' 
  | 'necessiteVerification'
  | 'withLocation'
  | 'withoutLocation';

export interface TourneeStats {
  total: number;
  saisis: number;
  nonSaisis: number;
  bloques: number;
  absents: number;
  anomalies: number;
  withGps: number;
  progressPercent: number;
}
