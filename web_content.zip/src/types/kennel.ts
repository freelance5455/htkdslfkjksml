export type CoatColor = 'fawn' | 'black' | 'gray' | 'white';
export type BodyType = 'slender' | 'chubby' | 'medium';
export type FurPattern = 'black spots' | 'striped' | 'black piebald' | 'patternless';
export type DogGender = 'female' | 'male';

export type UniqueTrait =
  | 'lazy'
  | 'active'
  | 'clingy'
  | 'solitary'
  | 'likes humans'
  | 'dislikes humans'
  | 'dislikes females'
  | 'dislikes males'
  | 'possessive of toys'
  | 'playful'
  | 'likes petting'
  | 'dislikes petting'
  | 'focused'
  | 'erratic'
  | 'calm'
  | 'reactive';

export type BoxId =
  | 'box_1' | 'box_2' | 'box_3' | 'box_4' | 'box_5' | 'box_6' | 'box_7'
  | 'box_8' | 'box_9' | 'box_10' | 'box_11' | 'box_12' | 'box_13' | 'box_14'
  | 'box_15' | 'box_16' | 'box_17' | 'box_18' | 'box_19' | 'box_20' | 'box_21';

export type HabitatLocationId = BoxId | 'outside_pen' | 'nursery_pen';
export type LocationId = HabitatLocationId | 'corridor';

export type ApproachReason = 'curiosity' | 'affection' | 'territory' | 'hunger' | 'fear';

export type PlayerAction =
  | 'look_away'
  | 'offer_palm'
  | 'playful_wrestle'
  | 'pet'
  | 'offer_kibble'
  | 'crouch'
  | 'scold'
  | 'eye_contact'
  | 'end_interaction';

export type DogSocialAction =
  | 'follow'
  | 'sniff'
  | 'growl'
  | 'pin down'
  | 'chase'
  | 'lick muzzle'
  | 'playful bow'
  | 'submit'
  | 'avoid'
  | 'mate'
  | 'reject mating'
  | 'bite'
  | 'playful ambush'
  | 'defend';

export type ObjectVerb =
  | 'climbing'
  | 'pacing'
  | 'digging'
  | 'pawing'
  | 'investigating'
  | 'biting'
  | 'breaking'
  | 'sniffing';

export interface DogStats {
  health: number;      // 0..100
  dominance: number;   // 0..100
  energy: number;      // 0..100
  intelligence: number;// 0..100
  hunger: number;      // 0..100 (higher = hungrier)
  matingDrive: number; // 0..100
  thirst: number;      // 0..100 (higher = thirstier)
  playfulness: number; // 0..100
  aggression: number;  // 0..100
  mood: number;        // 0..100 (higher = calmer/happier)
  fertility: number;   // 0..100
  stress: number;      // 0..100
}

export interface DogSkills {
  foraging: number;     // 0..100
  tracking: number;     // 0..100
  agility: number;      // 0..100
  watchfulness: number; // 0..100
  socialGrace: number;  // 0..100
}

export interface RelationshipToPlayer {
  trust: number;            // 0..100
  curiosity: number;        // 0..100
  fear: number;             // 0..100
  anger: number;            // 0..100
  stress: number;           // 0..100
  interactionCount: number;
}

export interface DogPairRelation {
  affinity: number;   // -100..100
  tension: number;    // 0..100
  isAlly: boolean;
  lastUpdatedSimSec: number;
}

export interface DogGenetics {
  coat: CoatColor;
  bodyType: BodyType;
  pattern: FurPattern;
  coatAlleles: [CoatColor, CoatColor];
  patternAlleles: [FurPattern, FurPattern];
  bodyAlleles: [BodyType, BodyType];
  patternSeed: number;
}

export interface Dog {
  id: string;
  name: string;
  gender: DogGender;
  ageSeconds: number;
  lifespanSeconds: number;
  genetics: DogGenetics;
  stats: DogStats;
  skills: DogSkills;
  traits: UniqueTrait[];
  discoveredTraits: UniqueTrait[];
  location: HabitatLocationId;
  playerRel: RelationshipToPlayer;
  pairRelations: Record<string, DogPairRelation>;
  fertilityCooldownSec: number;
  pregnantRemainingSec: number | null;
  litterSireId: string | null;
  motherId: string | null;
  fatherId: string | null;
  generation: number;
  currentBehavior: string;
  lastActivitySimSec: number;
  lastTensionSimSec: number;
  notes: string;
  origin: 'market' | 'bred' | 'starter';
}

export interface HabitatBowl {
  food: number;  // 0..100
  water: number; // 0..100
}

export interface PenObject {
  id: string;
  name: string;
  kind: 'climb' | 'dig' | 'chew' | 'fence' | 'shelter' | 'scent';
  condition: number; // 0..100
  lastInteractedText: string;
}

export interface ActivePlayerInteraction {
  dogId: string;
  location: HabitatLocationId;
  reason: ApproachReason;
  startedAtTotalSec: number;
  lastActionAtTotalSec: number;
  turns: number;
  boredom: number; // 0..100
  history: {
    id: string;
    actor: 'dog' | 'player' | 'system';
    text: string;
    timeStr: string;
  }[];
}

export interface MarketListing {
  id: string;
  dog: Dog;
  price: number;
  arrivedAtTotalSec: number;
}

export type LogCategory =
  | 'behavior'
  | 'social'
  | 'object'
  | 'care'
  | 'breeding'
  | 'interaction'
  | 'alert';

export interface LogEntry {
  id: string;
  simTimeSec: number;
  totalElapsedSec: number;
  location: HabitatLocationId;
  category: LogCategory;
  text: string;
  dogIds: string[];
}

export interface DeceasedRecord {
  id: string;
  name: string;
  gender: DogGender;
  coat: CoatColor;
  bodyType: BodyType;
  pattern: FurPattern;
  ageAtDeathSec: number;
  cause: string;
  traits: UniqueTrait[];
  generation: number;
}

export interface GameState {
  version: number;
  simClockSec: number;       // 0..86399 (resets to 00:00:00 after 24h)
  totalElapsedSec: number;   // monotonic simulation seconds
  dayCount: number;
  isPaused: boolean;
  playerLocation: LocationId;
  observingLocation: HabitatLocationId | null;
  dogs: Dog[];
  deceased: DeceasedRecord[];
  bowls: Record<HabitatLocationId, HabitatBowl>;
  penObjects: PenObject[];
  marketListings: MarketListing[];
  nextMarketRefreshSec: number;
  logs: LogEntry[];
  activeInteraction: ActivePlayerInteraction | null;
  kennelCredits: number;
  soldCount: number;
  rehomedCount: number;
  journalSelectedDogId: string | null;
  lastSavedAtMs: number;
}
