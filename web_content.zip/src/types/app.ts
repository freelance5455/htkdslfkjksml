export type EntityStatus = 'draft' | 'published';

export interface LoanPerson {
  id: string;
  name: string;
  contactNumber: string;
  openingBalance: number;
  remarks: string;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
}

export type LoanTransactionType = 'received' | 'repayment';

export interface LoanTransaction {
  id: string;
  personId: string;
  type: LoanTransactionType;
  amount: number;
  date: string;
  description: string;
  paymentMethod?: string;
  transactionRef?: string;
  remarks: string;
  createdAt: string;
  updatedAt: string;
}

export type CommitteeFrequency = 'Daily' | 'Weekly' | 'Bi-Weekly' | 'Monthly' | 'Quarterly' | 'Custom';

export interface Committee {
  id: string;
  name: string;
  personName: string;
  openingBalance: number;
  totalCommitteeAmount: number;
  installmentAmount: number;
  startDate: string;
  endDate: string;
  paymentFrequency: CommitteeFrequency;
  remarks: string;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
}

export type CommitteeTransactionType = 'installment' | 'payout';

export interface CommitteeTransaction {
  id: string;
  committeeId: string;
  personName: string;
  type: CommitteeTransactionType;
  amount: number;
  date: string;
  paymentMethod?: string;
  paymentRef?: string;
  remarks: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustomModule {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  position: number;
  visible: boolean;
  archived: boolean;
  status: EntityStatus;
  createdAt: string;
  updatedAt: string;
}

export interface CustomSubmodule {
  id: string;
  moduleId: string;
  name: string;
  icon: string;
  color: string;
  position: number;
  visible: boolean;
  archived: boolean;
  status: EntityStatus;
  createdAt: string;
  updatedAt: string;
}

export type FieldType =
  | 'text'
  | 'number'
  | 'currency'
  | 'date'
  | 'time'
  | 'dropdown'
  | 'multiselect'
  | 'checkbox'
  | 'yesno'
  | 'percentage'
  | 'formula'
  | 'notes';

export interface FieldDefinition {
  id: string;
  moduleId: string;
  submoduleId: string;
  name: string;
  label: string;
  type: FieldType;
  placeholder: string;
  defaultValue: string;
  required: boolean;
  editable: boolean;
  visible: boolean;
  position: number;
  decimalPlaces: number;
  minValue?: number;
  maxValue?: number;
  dropdownOptions: string[];
  masterListId?: string;
  color: string;
  formulaExpression?: string;
  status: EntityStatus;
  createdAt: string;
  updatedAt: string;
}

export interface MasterListOption {
  id: string;
  label: string;
  value: string;
  position: number;
}

export interface MasterList {
  id: string;
  name: string;
  description: string;
  options: MasterListOption[];
  createdAt: string;
  updatedAt: string;
}

export interface FormulaDefinition {
  id: string;
  name: string;
  moduleId: string;
  submoduleId: string;
  targetFieldId: string;
  expression: string;
  decimalPlaces: number;
  status: EntityStatus;
  createdAt: string;
  updatedAt: string;
}

export type MappingType = 'direct' | 'formula' | 'aggregate_sum' | 'aggregate_avg';

export interface FieldMapping {
  id: string;
  name: string;
  sourceModuleId: string;
  sourceSubmoduleId: string;
  sourceFieldId: string;
  destModuleId: string;
  destSubmoduleId: string;
  destFieldId: string;
  mappingType: MappingType;
  formulaExpression: string;
  status: EntityStatus;
  validationStatus: 'valid' | 'invalid';
  validationMessage?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustomRecord {
  id: string;
  moduleId: string;
  submoduleId: string;
  values: Record<string, unknown>;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
}

export type DashboardCalculationType =
  | 'sum'
  | 'count'
  | 'average'
  | 'min'
  | 'max'
  | 'remaining_balance'
  | 'custom_formula';

export interface DashboardCardConfig {
  id: string;
  title: string;
  sourceType: 'loan' | 'committee' | 'custom';
  moduleId?: string;
  submoduleId?: string;
  fieldId?: string;
  calculation: DashboardCalculationType;
  customFormula?: string;
  color: string;
  icon: string;
  position: number;
  visible: boolean;
  isSystem?: boolean;
  systemKey?: 'loan_received' | 'loan_repaid' | 'loan_remaining' | 'committee_receivable';
  status: EntityStatus;
  createdAt: string;
  updatedAt: string;
}

export interface ReportFilter {
  fieldId: string;
  operator: 'equals' | 'contains' | 'gt' | 'lt';
  value: string;
}

export interface CustomReportConfig {
  id: string;
  name: string;
  sourceType: 'loan' | 'committee' | 'custom';
  moduleId?: string;
  submoduleId?: string;
  fieldIds: string[];
  dateFieldId?: string;
  dateFrom?: string;
  dateTo?: string;
  filters: ReportFilter[];
  sortBy?: string;
  sortDir: 'asc' | 'desc';
  groupBy?: string;
  calculation: 'none' | 'sum' | 'avg' | 'min' | 'max' | 'count';
  status: EntityStatus;
  createdAt: string;
  updatedAt: string;
}

export interface ThemeConfig {
  presetId: string;
  primaryColor: string;
  secondaryColor: string;
  backgroundColor: string;
  cardColor: string;
  sidebarColor: string;
  textColor: string;
  buttonColor: string;
  loanModuleColor: string;
  committeeModuleColor: string;
}

export interface AppSettings {
  id: 'app_settings';
  appName: string;
  appSubtitle: string;
  language: 'English' | 'Urdu (Roman)';
  currency: string;
  dateFormat: 'YYYY-MM-DD' | 'DD/MM/YYYY' | 'MM/DD/YYYY' | 'DD MMM YYYY';
  numberFormat: 'en-PK' | 'en-US' | 'en-GB';
  defaultDashboardView: 'overview' | 'compact';
  layoutMode: 'auto' | 'desktop' | 'mobile';
  theme: ThemeConfig;
  updatedAt: string;
}

export type AuditAction =
  | 'RECORD_CREATED'
  | 'RECORD_EDITED'
  | 'RECORD_DELETED'
  | 'RECORD_ARCHIVED'
  | 'RECORD_RESTORED'
  | 'RECORD_PURGED'
  | 'MODULE_CREATED'
  | 'MODULE_UPDATED'
  | 'MODULE_DELETED'
  | 'SUBMODULE_CREATED'
  | 'SUBMODULE_UPDATED'
  | 'SUBMODULE_DELETED'
  | 'FIELD_CREATED'
  | 'FIELD_UPDATED'
  | 'FIELD_DELETED'
  | 'FORMULA_CHANGED'
  | 'MAPPING_CHANGED'
  | 'CARD_CHANGED'
  | 'REPORT_CHANGED'
  | 'SETTINGS_UPDATED'
  | 'BACKUP_CREATED'
  | 'DATA_RESTORED';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: AuditAction;
  entityType: string;
  entityId: string;
  summary: string;
  details?: string;
}

export type RecycleEntityType =
  | 'loanPerson'
  | 'loanTransaction'
  | 'committee'
  | 'committeeTransaction'
  | 'customRecord'
  | 'module'
  | 'submodule'
  | 'field'
  | 'report';

export interface RecycleBinItem {
  id: string;
  entityType: RecycleEntityType;
  originalId: string;
  label: string;
  payload: unknown;
  deletedAt: string;
}

export interface BackupPackage {
  schemaVersion: number;
  appId: string;
  exportedAt: string;
  data: {
    loanPersons: LoanPerson[];
    loanTransactions: LoanTransaction[];
    committees: Committee[];
    committeeTransactions: CommitteeTransaction[];
    modules: CustomModule[];
    submodules: CustomSubmodule[];
    fields: FieldDefinition[];
    masterLists: MasterList[];
    formulas: FormulaDefinition[];
    fieldMappings: FieldMapping[];
    customRecords: CustomRecord[];
    dashboardCards: DashboardCardConfig[];
    reports: CustomReportConfig[];
    settings: AppSettings;
    auditLogs: AuditLogEntry[];
    recycleBin: RecycleBinItem[];
  };
}

export type ActiveNavRoute =
  | 'dashboard'
  | 'loans'
  | 'committees'
  | 'reports'
  | 'settings'
  | 'backup'
  | 'recycle-bin'
  | 'audit-log'
  | `module:${string}`;
