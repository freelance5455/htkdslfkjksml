export type MessageRole = 'user' | 'assistant' | 'system';

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: number;
  imageBase64?: string;
  isThinking?: boolean;
}

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  createdAt: number;
  tag?: string;
}

export interface ReminderItem {
  id: string;
  text: string;
  targetTime?: string;
  isCompleted: boolean;
  createdAt: number;
}

export interface SystemTelemetry {
  batteryLevel: number;
  isCharging: boolean;
  powerSource: string;
  networkOnline: boolean;
  latencyMs: number;
  screenResolution: string;
  userAgent: string;
  isTorchActive: boolean;
}

export type ActiveTab = 'assistant' | 'vision' | 'social' | 'notes' | 'reminders' | 'tools' | 'settings';

export type SupportedLanguage = 'bn' | 'en';
