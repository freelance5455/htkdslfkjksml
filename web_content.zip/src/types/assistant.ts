/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AssistantState = 'IDLE' | 'LISTENING' | 'THINKING' | 'SPEAKING' | 'ERROR';

export type VoiceModeState =
  | 'OFF'
  | 'REQUESTING_PERMISSION'
  | 'LISTENING'
  | 'PROCESSING'
  | 'SPEAKING'
  | 'RECONNECTING'
  | 'ERROR';

export type LanguageCode = 'en-US' | 'en-GB' | 'bn-BD' | 'hi-IN';

export interface ActionPayload {
  type: 'navigation' | 'search' | 'draft' | 'calculation' | 'ai' | 'info';
  targetUrl?: string;
  query?: string;
  recipient?: string;
  draftText?: string;
  calculationResult?: string;
  expression?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  state?: AssistantState;
  action?: ActionPayload;
}

export interface AppSettings {
  voiceOutputEnabled: boolean;
  preferredLanguage: LanguageCode;
  speechRate: number;
  historyEnabled: boolean;
  soundEffectsEnabled: boolean;
}

export interface ServerStatusResponse {
  ok: boolean;
  geminiConfigured: boolean;
  model: string;
  serverTime: string;
}

export interface CommandResponse {
  spokenText: string;
  displayText: string;
  action?: ActionPayload;
  state: AssistantState;
}

export interface BatteryInfo {
  supported: boolean;
  level: number; // 0 to 100
  charging: boolean;
}
