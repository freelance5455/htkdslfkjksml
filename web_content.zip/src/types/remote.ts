export type ConnectionType = 'IR' | 'WIFI' | 'BLUETOOTH';

export type DeviceType = 'TV' | 'RECEIVER' | 'AC' | 'TV_BOX';

export type IrProtocol = 
  | 'NEC' 
  | 'NEC_EXTENDED' 
  | 'SUNPLUS' 
  | 'RC5' 
  | 'RC6' 
  | 'SONY_SIRC_12' 
  | 'SONY_SIRC_15' 
  | 'SONY_SIRC_20' 
  | 'SAMSUNG32' 
  | 'PRONTO_HEX';

export type RemoteKey =
  | 'POWER'
  | 'POWER_ON'
  | 'POWER_OFF'
  | 'MUTE'
  | 'VOL_UP'
  | 'VOL_DOWN'
  | 'CH_UP'
  | 'CH_DOWN'
  | 'UP'
  | 'DOWN'
  | 'LEFT'
  | 'RIGHT'
  | 'OK'
  | 'BACK'
  | 'HOME'
  | 'MENU'
  | 'EXIT'
  | 'INFO'
  | 'SOURCE'
  | 'NUM_0'
  | 'NUM_1'
  | 'NUM_2'
  | 'NUM_3'
  | 'NUM_4'
  | 'NUM_5'
  | 'NUM_6'
  | 'NUM_7'
  | 'NUM_8'
  | 'NUM_9'
  | 'RED'
  | 'GREEN'
  | 'YELLOW'
  | 'BLUE'
  | 'PLAY'
  | 'PAUSE'
  | 'STOP'
  | 'REWIND'
  | 'FAST_FORWARD'
  | 'SAT'
  | 'EPG'
  | 'AUDIO'
  | 'SUBTITLE'
  | 'FAV'
  | 'RECALL';

export interface RemoteDevice {
  id: string;
  name: string;
  brand: string;
  model: string;
  type: DeviceType;
  connectionType: ConnectionType;
  ipAddress?: string;
  port?: number;
  macAddress?: string;
  irProtocol?: IrProtocol;
  customAddress?: number;
  isFavorite: boolean;
  notes?: string;
}

export interface IrPatternResult {
  frequencyHz: number;
  patternMicros: number[];
  hexRepresentation: string;
  totalDurationMs: number;
  pulseCount: number;
}

export interface SunplusProfile {
  name: string;
  chipset: string;
  addressHex: string;
  description: string;
  keys: Record<string, string>; // Key -> Hex Command
}

export interface MacroAction {
  id: string;
  deviceId: string;
  key: RemoteKey;
  delayAfterMs: number;
}

export interface Macro {
  id: string;
  name: string;
  description: string;
  actions: MacroAction[];
}
