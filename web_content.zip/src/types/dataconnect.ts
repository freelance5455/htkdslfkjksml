// Tipos generados a partir del esquema Firebase Data Connect de SONÓ RADIO

export interface Organization {
  id?: string;
  name: string;
  type: string;
  status: string;
  createdAt: string | number | Date;
  expiryDate?: string | number | Date | null;
}

export interface Channel {
  id?: string | number;
  name: string;
  frequency: number | string;
  accessLevel: string;
  organization?: Organization;
}

export interface Module {
  id?: string;
  organization: Organization;
  description?: string;
}

export interface AccountStatus {
  organization: Organization;
  status: string;
  planType: 'demo_prueba' | 'premium' | 'enterprise';
  trialEndDate?: string | number | Date | null;
}

export interface DataConnectMessage {
  id?: string;
  content: string;
  timestamp: string | number | Date;
  senderId: string;
  channel: Channel;
}

// Estructura de Módulo de Cliente Demo / Premium
export interface RadioChannelItem {
  id: number;
  freq: string;
  nombre: string;
  acceso: 'libre' | 'solo_demo' | 'demo_limitado' | 'privado_modulo' | 'vista_unica' | 'limitado' | 'solo_lectura';
}

export interface ClientModuleData {
  tipo: 'demo_prueba' | 'demo_cliente' | 'premium';
  cliente_id: string;
  nombre: string;
  estado: 'activo' | 'suspendido' | 'vencido';
  creado_en?: string;
  vencimiento_demo?: string | null;
  frecuencia_base?: string;
  canales_publicos: RadioChannelItem[];
  modulo_privado: RadioChannelItem[];
  limite_usuarios?: number;
}
