export type UILanguage = 'bn' | 'en';

export type EditingLanguageScript = 'bn' | 'en' | 'ar' | 'ur' | 'fa';
export type ExportImageQuality = 'hd' | 'fullhd' | 'uhd';
export type PageSizePreset = 'a4' | 'letter' | 'legal';

export interface StudioSettings {
  defaultScript: EditingLanguageScript;
  autosaveEnabled: boolean;
  paragraphGrouping: boolean;
  autoNormalizeText: boolean;
  exportImageQuality: ExportImageQuality;
  defaultPageSize: PageSizePreset;
  defaultMaskPadding: number;
}

export type ToolMode =
  | 'edit-text'
  | 'select-region'
  | 'add-text'
  | 'highlight'
  | 'pen'
  | 'patch'
  | 'signature'
  | 'image'
  | 'shape';

export type TextAlignment = 'left' | 'center' | 'right' | 'justify';

export interface CustomFont {
  id: string;
  name: string;
  familyName: string;
  fileName: string;
  dataUrl?: string;
  bytes: Uint8Array;
  loaded: boolean;
  source?: 'uploaded' | 'device' | 'system-probe' | 'google';
}

export interface TextTokenSegment {
  text: string;
  x: number;
  width: number;
}

export interface ExtractedLineInfo {
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
  segments: TextTokenSegment[];
}

export interface DetectedPdfFont {
  rawName: string;
  displayName: string;
  matchedFontId: string;
  isBold: boolean;
  isItalic: boolean;
  hasBangla: boolean;
  hasArabic?: boolean;
  isBijoyEncoded: boolean;
  count: number;
}

export interface ExtractedTextBlock {
  id: string;
  pageId: string;
  originalText: string;
  /** Top-left coordinates in unscaled PDF points */
  x: number;
  y: number;
  width: number;
  height: number;
  fontSize: number;
  rawFontName: string;
  matchedFontId: string;
  fontWeight: 'normal' | 'bold';
  fontStyle: 'normal' | 'italic';
  color: string;
  bgColor: string;
  lineHeight: number;
  isEdited: boolean;
  isBijoySuspected: boolean;
  isRtl?: boolean;
  textAlign?: TextAlignment;
  segments?: TextTokenSegment[];
  lines?: ExtractedLineInfo[];
}

export type OverlayElement =
  | TextOverlayElement
  | PatchOverlayElement
  | ImageOverlayElement
  | ShapeOverlayElement
  | PenOverlayElement;

export interface BaseOverlay {
  id: string;
  pageId: string;
  /** Top-left coordinates in PDF points */
  x: number;
  y: number;
  width: number;
  height: number;
  opacity: number;
}

export interface TextOverlayElement extends BaseOverlay {
  kind: 'text';
  text: string;
  originalText?: string;
  sourceBlockId?: string;
  mergedBlockIds?: string[];
  originalColor?: string;
  originalFontId?: string;
  originalFontSize?: number;
  originalX?: number;
  originalY?: number;
  sourceSegments?: TextTokenSegment[];
  sourceLines?: ExtractedLineInfo[];
  isParagraph?: boolean;
  hasCustomWidth?: boolean;
  maxPageWidth?: number;
  /** Mask rectangle in PDF points to cover original PDF text underneath */
  maskRect?: {
    x: number;
    y: number;
    width: number;
    height: number;
    padding: number;
    color: string;
    enabled: boolean;
  };
  fontId: string;
  rawFontName?: string;
  fontSize: number;
  fontWeight: 'normal' | 'bold';
  fontStyle: 'normal' | 'italic';
  textAlign: TextAlignment;
  lineHeight: number;
  letterSpacing: number;
  color: string;
}

export interface PatchOverlayElement extends BaseOverlay {
  kind: 'patch';
  fillColor: string;
  borderColor: string;
  borderWidth: number;
}

export interface ImageOverlayElement extends BaseOverlay {
  kind: 'image';
  dataUrl: string;
  aspectRatio: number;
  isSignature?: boolean;
}

export interface ShapeOverlayElement extends BaseOverlay {
  kind: 'shape';
  shapeType: 'rectangle' | 'highlight' | 'line';
  fillColor: string;
  strokeColor: string;
  strokeWidth: number;
}

export interface PenOverlayElement extends BaseOverlay {
  kind: 'pen';
  /** Coordinates relative to (x, y) in PDF points */
  points: Array<{ x: number; y: number }>;
  strokeColor: string;
  strokeWidth: number;
}

export interface PdfPageModel {
  id: string;
  /** 0-based index in the original loaded PDF, or null if added blank page */
  originalPageIndex: number | null;
  widthPt: number;
  heightPt: number;
  rotation: 0 | 90 | 180 | 270;
  /** High-DPI rendered image of the original PDF page (unmodified) */
  previewDataUrl: string;
  thumbnailDataUrl: string;
  extractedBlocks: ExtractedTextBlock[];
}

export interface DocumentSnapshot {
  pages: PdfPageModel[];
  overlays: OverlayElement[];
}

export interface PdfDocumentTab {
  id: string;
  docName: string;
  originalBytes: Uint8Array | null;
  pages: PdfPageModel[];
  overlays: OverlayElement[];
  activePageId: string;
  detectedFonts: DetectedPdfFont[];
  undoStack: DocumentSnapshot[];
  redoStack: DocumentSnapshot[];
  zoom: number;
}
