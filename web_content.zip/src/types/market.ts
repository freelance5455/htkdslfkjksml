export type AssetCategory = 'all' | 'crypto' | 'forex' | 'commodity' | 'stock';

export type AppTab = 'marche' | 'graph' | 'iasignals' | 'alerte' | 'watchlist' | 'portfolio';

export type ThemeMode = 'dark' | 'light';

export interface AssetData {
  id: string;
  symbol: string;
  name: string;
  category: 'crypto' | 'forex' | 'commodity' | 'stock';
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: string;
  marketCap?: string;
  sparkline: number[];
  lastUpdated: number;
  previousPrice?: number;
  tickDirection?: 'up' | 'down' | 'neutral';
}

export type SoundEffectType = 
  | 'sonar' 
  | 'bell' 
  | 'bullish' 
  | 'bearish' 
  | 'alarm' 
  | 'kaching' 
  | 'laser' 
  | 'pulsar';

export type AppLanguage = 'fr' | 'en' | 'de' | 'es' | 'it' | 'ar';

export interface VoiceAlertPreset {
  id: string;
  title: string;
  category: 'breakout' | 'dump' | 'profit' | 'whale' | 'volatility' | 'support' | 'custom';
  language: AppLanguage;
  script: string;
  defaultChime: SoundEffectType;
  description: string;
  tag: string;
}

export interface ActiveVoiceAlert {
  id: string;
  assetId: string;
  assetSymbol: string;
  assetName: string;
  condition: 'above' | 'below' | 'pct_gain' | 'pct_loss';
  targetValue: number;
  baselinePrice: number;
  voiceScript: string;
  soundChime: SoundEffectType;
  voicePersona: 'fr-trader' | 'en-trader' | 'en-analyst' | 'de-trader' | 'es-trader' | 'it-trader' | 'ar-trader' | 'cyber';
  enabled: boolean;
  repeatMode: 'once' | 'repeat' | 'persistent';
  repeatIntervalMinutes: number; // 1, 5, 15, 30, 60
  repeatLimit: number | 'unlimited'; // 1, 3, 5, 10, 'unlimited'
  screenAlertEffect: 'flash_strobe' | 'floating_pip' | 'radar_ping' | 'standard';
  sendSystemNotification: boolean;
  createdAt: number;
  lastTriggeredAt?: number;
  triggerCount: number;
}

export interface TriggeredAlertEvent {
  id: string;
  alertId: string;
  assetSymbol: string;
  assetName: string;
  currentPrice: number;
  targetValue: number;
  condition: 'above' | 'below' | 'pct_gain' | 'pct_loss';
  voiceScript: string;
  soundChime: SoundEffectType;
  screenAlertEffect: 'flash_strobe' | 'floating_pip' | 'radar_ping' | 'standard';
  timestamp: number;
}

export interface ChartAnnotation {
  id: string;
  type: 'horizontal_line' | 'trendline' | 'text' | 'fibonacci';
  price: number;
  price2?: number;
  label: string;
  color: string;
}

export interface GeminiMarketBriefing {
  headline: string;
  spokenScript: string;
  sentiment: 'Bullish' | 'Bearish' | 'Neutral';
  fearGreedIndex: number;
  keyAdvice: string;
}

export interface GeminiAssetAnalysis {
  summary: string;
  sentiment: 'Bullish' | 'Bearish' | 'Neutral';
  supportLevel: number;
  resistanceLevel: number;
  volatilityScore: 'Low' | 'Medium' | 'High' | 'Extreme';
  recommendedAlerts: Array<{
    type: 'above' | 'below';
    targetPrice: number;
    label: string;
    voiceScript: string;
    soundChime: SoundEffectType;
  }>;
}

export interface GeminiSignal {
  id: string;
  assetSymbol: string;
  assetName: string;
  type: 'ACHAT FORT' | 'ACHAT' | 'VENTE' | 'NEUTRE';
  timeframe: string;
  confidence: number; // 0 to 100
  targetPrice: number;
  stopLossPrice: number;
  riskReward: string;
  reasoning: string;
  voiceBrief: string;
  chime: SoundEffectType;
  timestamp: number;
}

export interface PortfolioPosition {
  id: string;
  assetId: string;
  symbol: string;
  name: string;
  category: 'crypto' | 'forex' | 'commodity' | 'stock';
  amount: number;
  buyPrice: number;
  createdAt: number;
}

export interface AudioSettings {
  volume: number; // 0 to 1
  rate: number; // 0.7 to 1.5
  pitch: number; // 0.8 to 1.4
  playChimeFirst: boolean;
  masterSoundEnabled: boolean;
  selectedPersona: 'fr-trader' | 'en-trader' | 'en-analyst' | 'de-trader' | 'es-trader' | 'it-trader' | 'ar-trader' | 'cyber';
  systemNotificationsEnabled: boolean;
}
