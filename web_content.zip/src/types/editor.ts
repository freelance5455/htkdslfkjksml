export interface SourceMedia {
  id: string;
  name: string;
  url: string;
  duration: number; // in seconds
  width: number;
  height: number;
  fps: number;
  thumbnailUrl?: string;
  isSample?: boolean;
  file?: File;
}

export interface TimelineClip {
  id: string;
  mediaId: string;
  sourceIn: number; // in seconds (trim start in original media)
  sourceOut: number; // in seconds (trim end in original media)
  timelineStart: number; // in seconds (cumulative position in timeline)
  speed: number; // 0.5, 1.0, 1.5, 2.0
  volume: number; // 0.0 to 1.0
  color: string;
}

export type AspectRatioType = '16:9' | '9:16' | '1:1' | '4:5';

export interface Project {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  aspectRatio: AspectRatioType;
  resolution: '720p' | '1080p';
  clips: TimelineClip[];
  mediaMap: Record<string, SourceMedia>;
}

export interface ExportSettings {
  resolution: '720p' | '1080p';
  quality: 'standard' | 'high';
  format: 'mp4' | 'webm';
  fps: number;
}
