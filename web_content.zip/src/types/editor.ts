export type AspectRatioType = '16:9' | '9:16' | '1:1' | '4:5' | '4:3' | '3:4' | 'custom';

export interface AspectRatioPreset {
  id: string;
  name: string;
  hindiName: string;
  ratio: AspectRatioType;
  width: number;
  height: number;
  iconName: string;
  platform: string;
}

export type TrackType = 'video' | 'overlay' | 'audio' | 'text' | 'sticker';

export interface Keyframe {
  id: string;
  time: number; // in seconds relative to clip start
  x: number;    // % offset (-100 to 100)
  y: number;    // % offset (-100 to 100)
  scale: number; // 0.1 to 5
  rotation: number; // degrees
  opacity: number; // 0 to 1
}

export interface MaskConfig {
  type: 'none' | 'rectangle' | 'circle' | 'linear';
  x: number; // 0 to 100%
  y: number; // 0 to 100%
  width: number; // 0 to 100%
  height: number; // 0 to 100%
  rotation: number;
  feather: number; // 0 to 100 px
  inverted: boolean;
}

export interface ChromaKeyConfig {
  enabled: boolean;
  color: string; // hex color e.g. #00ff00
  similarity: number; // 0 to 100
  smoothness: number; // 0 to 100
  spillReduction: number; // 0 to 100
}

export interface ColorAdjustments {
  brightness: number;  // -100 to 100
  contrast: number;    // -100 to 100
  saturation: number;  // -100 to 100
  exposure: number;    // -100 to 100
  highlights: number;  // -100 to 100
  shadows: number;     // -100 to 100
  temperature: number; // -100 to 100 (warm / cool)
  tint: number;        // -100 to 100 (green / magenta)
  sharpness: number;   // 0 to 100
  vignette: number;    // 0 to 100
  grain: number;       // 0 to 100
  hue: number;         // -180 to 180 deg
}

export interface ClipFilter {
  id: string;
  name: string;
  category: string;
  intensity: number; // 0 to 100
  cssFilter?: string;
  matrix?: number[];
}

export type BlendMode =
  | 'normal'
  | 'multiply'
  | 'screen'
  | 'overlay'
  | 'darken'
  | 'lighten'
  | 'color-dodge'
  | 'difference';

export interface VisualEffect {
  id: string;
  type: string;
  name: string;
  intensity: number; // 0 to 100
  speed: number;     // 0 to 100
  param?: number;    // generic parameter (e.g. grain size, ripple freq)
}

export interface TransitionConfig {
  type:
    | 'none'
    | 'fade'
    | 'dissolve'
    | 'zoom-in'
    | 'zoom-out'
    | 'slide-left'
    | 'slide-right'
    | 'slide-up'
    | 'push'
    | 'wipe'
    | 'blur'
    | 'spin'
    | 'flash'
    | 'glitch';
  duration: number; // in seconds, default 0.5
}

export interface TextConfig {
  content: string;
  fontFamily: string;
  fontSize: number;
  color: string;
  gradient?: {
    enabled: boolean;
    start: string;
    end: string;
    angle: number;
  };
  bold: boolean;
  italic: boolean;
  alignment: 'left' | 'center' | 'right';
  letterSpacing: number;
  stroke: {
    enabled: boolean;
    color: string;
    width: number;
  };
  shadow: {
    enabled: boolean;
    color: string;
    blur: number;
    offsetX: number;
    offsetY: number;
  };
  background: {
    enabled: boolean;
    color: string;
    opacity: number;
    borderRadius: number;
    padding: number;
  };
  animation: 'none' | 'fade' | 'slide' | 'zoom' | 'typewriter' | 'bounce' | 'pop' | 'shake';
}

export interface StickerConfig {
  emojiOrUrl: string;
  isCustomImage: boolean;
  category: string;
}

export interface Clip {
  id: string;
  trackId: string;
  trackType: TrackType;
  name: string;
  type: 'video' | 'image' | 'audio' | 'text' | 'sticker';
  
  // Media source
  sourceUrl: string;
  blob?: Blob;
  thumbnailUrl?: string;

  // Timeline timing
  start: number;       // timeline start in seconds
  duration: number;    // duration on timeline in seconds
  sourceStart: number; // trim in-point in seconds
  sourceDuration: number; // raw media total duration in seconds
  speed: number;       // 0.1x to 10.0x
  reverse: boolean;

  // Spatial transforms
  x: number;          // % offset from center (-100 to 100)
  y: number;          // % offset from center (-100 to 100)
  scale: number;      // 0.1 to 5.0 (default 1.0)
  rotation: number;   // 0 to 360 deg
  opacity: number;    // 0 to 1.0 (default 1.0)
  flipH: boolean;
  flipV: boolean;
  blendMode: BlendMode;

  // Audio settings
  volume: number;     // 0.0 to 2.0 (default 1.0)
  muted: boolean;
  fadeIn: number;     // seconds
  fadeOut: number;    // seconds

  // Adjustments & Styling
  adjustments: ColorAdjustments;
  filter?: ClipFilter;
  effects: VisualEffect[];
  transition?: TransitionConfig;
  mask: MaskConfig;
  chromaKey: ChromaKeyConfig;
  keyframes: Keyframe[];

  // Sub-type specific configs
  textConfig?: TextConfig;
  stickerConfig?: StickerConfig;
}

export interface Track {
  id: string;
  name: string;
  type: TrackType;
  locked: boolean;
  visible: boolean;
  muted: boolean;
  volume: number;
}

export interface BackgroundConfig {
  type: 'color' | 'gradient' | 'blur' | 'image';
  color: string;
  gradient?: {
    start: string;
    end: string;
    angle: number;
  };
  blurAmount?: number;
  imageUrl?: string;
}

export interface Project {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  aspectRatio: AspectRatioType;
  customWidth?: number;
  customHeight?: number;
  duration: number; // total duration
  fps: number;      // 24, 25, 30, 60
  background: BackgroundConfig;
  tracks: Track[];
  clips: Clip[];
  thumbnailUrl?: string;
}

export interface ExportSettings {
  resolution: '480p' | '720p' | '1080p' | '1440p' | '4k' | '8k';
  width: number;
  height: number;
  fps: number;
  bitratePreset: 'low' | 'medium' | 'high' | 'very-high' | 'custom';
  customBitrateMbps?: number;
  format: 'mp4' | 'webm';
  includeWatermark: boolean;
}

export interface ExportedProjectRecord {
  id: string;
  projectId: string;
  projectName: string;
  videoUrl: string;
  timestamp: number;
  duration: number;
  fileSize: number; // in bytes
  resolution: string;
  fps: number;
}

export interface UserSubscription {
  isPremium: boolean;
  plan: string;
  transactionId?: string;
  purchaseDate?: number;
  expiryDate?: number;
}
