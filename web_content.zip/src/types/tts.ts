export type EngineMode = 'neural' | 'offline';

export type PersonaId = 'male' | 'female' | 'child' | 'alien' | 'monster' | 'whisper' | 'host' | 'soda';

export type ExportFormat = 'wav' | 'mp3';

export interface Language {
  code: string; // e.g. 'ta-IN'
  name: string; // 'Tamil'
  nativeName: string; // 'தமிழ்'
  flag: string; // '🇮🇳'
  category: 'indic' | 'international';
  sampleTexts: {
    title: string;
    text: string;
  }[];
}

export interface VoicePersona {
  id: PersonaId;
  name: string;
  tagline: string;
  gender: 'male' | 'female' | 'neutral' | 'fantasy';
  icon: string; // Lucide icon name or emoji
  geminiVoice: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Aoede' | 'Zephyr';
  stylePrompt: string;
  defaultPitch: number; // in semitones (-12 to 12)
  defaultSpeed: number; // 0.5 to 2.0
  dspEffects: {
    pitchShift: number;
    ringMod?: boolean;
    ringModFreq?: number;
    bassBoost?: number;
    trebleBoost?: number;
    subHarmonics?: boolean;
    highpassFilter?: number;
    echo?: boolean;
    reverbWet?: number;
    sodaSparkle?: boolean;
  };
  description: string;
}

export interface VoiceSettings {
  speed: number; // 0.25 to 3.0
  pitch: number; // -12 to 12 semitones
  stability: number; // 0 to 100%
  clarity: number; // 0 to 100%
  effects: {
    alienModulation: boolean;
    arenaEcho: boolean;
    subBassPunch: boolean;
    whisperFilter: boolean;
    sodaSparkle?: boolean;
  };
}

export interface AudioGeneration {
  id: string;
  text: string;
  language: string;
  languageName: string;
  persona: PersonaId;
  personaName: string;
  engine: EngineMode;
  speed: number;
  pitch: number;
  audioUrl: string; // blob URL or data URL
  audioBlob?: Blob;
  wavBlob?: Blob;
  mp3Blob?: Blob;
  duration: number; // in seconds
  createdAt: number;
  fileSizeEstimate: string;
}

export interface DeveloperApiKey {
  id: string;
  key: string;
  name: string;
  createdAt: number;
  lastUsed?: number;
  requestCount: number;
  rateLimit: number; // requests per minute
}

export interface ApiTestResponse {
  status: number;
  ok: boolean;
  durationMs: number;
  charCount: number;
  audioFormat: string;
  audioBase64?: string;
  headers: Record<string, string>;
  message?: string;
}

export type CloudStorageProvider = 'google-drive' | 'dropbox' | 'onedrive';

export interface CloudAccount {
  provider: CloudStorageProvider;
  name: string;
  connected: boolean;
  accountEmail?: string;
  folderName: string;
  icon: string;
  lastSync?: number;
}

export interface CloudUploadRecord {
  id: string;
  provider: CloudStorageProvider;
  fileName: string;
  fileFormat: ExportFormat;
  fileSize: string;
  fileUrl: string;
  folderPath: string;
  uploadedAt: number;
  generationId?: string;
  driveUrl?: string;
  audioBlobUrl?: string;
}

export interface CustomVoice {
  id: string;
  userId: string;
  name: string;
  description: string;
  basePersona: PersonaId;
  languageCode: string;
  speed: number;
  pitch: number;
  stability: number;
  clarity: number;
  effects: VoiceSettings['effects'];
  sampleText?: string;
  createdAt: number;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  avatar: string;
  preferredLanguage: string;
  preferredPersona: PersonaId;
  playbackSpeed: number;
  voiceSettings: VoiceSettings;
  preferredCloudStorage: CloudStorageProvider;
  autoCloudUpload: boolean;
  createdAt: number;
}

