export type TTSEngineType = 'edge-neural' | 'gemini-neural' | 'native-telugu' | 'browser-speech';

export type VoiceGender = 'male' | 'female';

export interface TTSVoice {
  id: string;
  name: string;
  teluguName: string;
  category: 'male' | 'female';
  gender: VoiceGender;
  styleTag: string;
  description: string;
  engine: TTSEngineType;
  recommendedStyles: string[];
  isNeural: boolean;
  samplePhrase?: string;
  nativeVoiceName?: string; // Engine-specific ID like 'te-IN-MohanNeural', 'te-IN-ShrutiNeural', 'Kore', 'Puck'
  pitchOffsetHz?: number;
  rateOffsetPercent?: number;
  badge?: string;
  isRealistic?: boolean;
}

export type NarrationStyleId =
  | 'normal'
  | 'storytelling'
  | 'emotional'
  | 'motivational'
  | 'cinematic'
  | 'documentary'
  | 'news'
  | 'educational'
  | 'podcast'
  | 'youtube'
  | 'suspense'
  | 'sad'
  | 'inspirational'
  | 'energetic'
  | 'calm'
  | 'serious'
  | 'devotional'
  | 'poetry'
  | 'dialogue'
  | 'whisper';

export interface NarrationStyle {
  id: NarrationStyleId;
  name: string;
  teluguName: string;
  icon: string;
  description: string;
  speedMultiplier: number;
  pitchOffset: number;
  sentencePauseMs: number;
  paragraphPauseMs: number;
  promptDirective: string;
}

export interface PronunciationRule {
  id: string;
  original: string;
  replacement: string;
  teluguPhonetic?: string;
  enabled: boolean;
  active?: boolean;
  isRegex?: boolean;
  caseSensitive?: boolean;
  notes?: string;
}

export interface VoiceSettings {
  speed: number;        // 0.5 to 2.0 (default 1.0)
  pitch: number;        // -10 to +10 (default 0)
  volume: number;       // 0 to 100% (default 100)
  sentencePause: number;// seconds (0.1 to 2.5, default 0.4)
  paragraphPause: number;// seconds (0.3 to 4.0, default 0.8)
  emphasis: 'none' | 'moderate' | 'strong' | 'dramatic';
  humanBreathing?: boolean; // Natural human breathing & micro-pauses at punctuation
  dspEffect?: 'none' | 'studio' | 'cinematic-bass' | 'vocal-warmth' | 'crisp';
}

export interface UserPreset {
  id: string;
  name: string;
  teluguName?: string;
  voiceId: string;
  narrationStyle: NarrationStyleId;
  settings: VoiceSettings;
  createdAt: string;
}

export interface AudioExportSettings {
  format: 'mp3' | 'wav';
  bitrate: 128 | 192 | 256 | 320;
  sampleRate: 24000 | 44100 | 48000;
  normalizeVolume: boolean;
}

export type AudioSettings = AudioExportSettings;

export interface TextProcessingSettings {
  autoPunctuation: boolean;
  numberPronunciation: boolean;
  englishLoanwordTransliteration: boolean;
  abbreviationHandling: boolean;
  currencyPronunciation: boolean;
}

export interface SentenceItem {
  id: string;
  text: string;
  pauseAfter: number; // seconds
  emphasis: 'normal' | 'high' | 'dramatic' | 'soft' | 'urgent';
  speed?: number;
  pitch?: number;
}

export interface TTSGenerateRequest {
  text: string;
  voiceId: string;
  engine: TTSEngineType;
  narrationStyle: NarrationStyleId;
  settings: VoiceSettings;
  audioSettings: AudioExportSettings;
  textSettings: TextProcessingSettings;
  pronunciationRules?: PronunciationRule[];
  sentences?: SentenceItem[];
}

export interface TTSGenerateResult {
  audioUrl: string;
  audioBlob: Blob;
  audioBase64: string;
  format: 'mp3' | 'wav';
  durationSec: number;
  filename: string;
  voiceUsed: string;
  engineUsed: TTSEngineType;
  narrationStyleUsed: string;
  processedText: string;
  fallbackNote?: string;
  generatedAt: string;
}

export interface HistoryItem {
  id: string;
  title?: string;
  text?: string;
  textSnippet: string;
  fullText?: string;
  voiceId: string;
  voiceName: string;
  engine?: TTSEngineType;
  narrationStyle: NarrationStyleId;
  format: 'mp3' | 'wav';
  durationSec: number;
  createdAt: string;
  audioUrl?: string;
  audioBase64?: string;
  filename: string;
  settingsSnapshot?: {
    speed: number;
    pitch: number;
    volume: number;
  };
}
