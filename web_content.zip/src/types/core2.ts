// ============================================================
// AI CREATOR STUDIO — CORE 2.0 TYPE DEFINITIONS
// PUBLISHING + SOCIAL + ANALYTICS
// ============================================================

import type { Platform } from "./index";

// --- PLATFORM PROVIDER INTERFACES ---
export type ChannelConnectionStatus = "CONNECTED" | "DISCONNECTED" | "EXPIRED" | "ERROR";

export interface SocialChannel {
  id: string;
  platform: Platform;
  name: string;
  handle?: string;
  avatarUrl?: string;
  channelId: string;
  status: ChannelConnectionStatus;
  lastSyncAt: string;
  subscriberCount: number;
  totalViews: number;
  totalVideos: number;
  scopes: string[];
  isDefault?: boolean;
  metadata?: Record<string, unknown>;
}

export interface AuthConfig {
  clientId?: string;
  clientSecret?: string;
  redirectUri?: string;
  scopes: string[];
  authUrl: string;
  tokenUrl: string;
}

export interface PublishingProvider {
  platform: Platform;
  name: string;
  version: string;
  isConfigured(): boolean;
  getMissingConfigs(): string[];
  connect(): Promise<{ authUrl: string } | { success: boolean; channel: SocialChannel }>;
  disconnect(channelId: string): Promise<boolean>;
  authenticate(code: string): Promise<SocialChannel>;
  upload(fileBlobOrUrl: string, metadata: PublishingMetadata): Promise<{ uploadId: string; videoUrl: string }>;
  publish(uploadId: string, metadata: PublishingMetadata): Promise<{ postId: string; postUrl: string }>;
  schedule(uploadId: string, metadata: PublishingMetadata, scheduledTime: string): Promise<{ jobId: string; status: string }>;
  getStatus(postIdOrJobId: string): Promise<PublishingJobStatus>;
  update(postId: string, metadata: Partial<PublishingMetadata>): Promise<boolean>;
  delete(postId: string): Promise<boolean>;
}

export interface AnalyticsProvider {
  platform: Platform;
  fetchChannelOverview(channelId: string): Promise<AggregatedAnalytics>;
  fetchVideoMetrics(postId: string): Promise<VideoAnalytics>;
  fetchRetentionCurve(postId: string): Promise<Array<{ timestampSec: number; percentRemaining: number }>>;
}

// --- METADATA & PACKAGING ---
export interface PublishingMetadata {
  title: string;
  description: string;
  tags: string[];
  hashtags: string[];
  category?: string;
  language?: string;
  isMadeForKids?: boolean;
  visibility: "PUBLIC" | "UNLISTED" | "PRIVATE";
  aspectRatio: "16:9" | "9:16" | "1:1" | "4:5";
  thumbnailUrl?: string;
  videoUrl?: string;
  subtitlesUrl?: string;
  pinnedComment?: string;
  suggestedPlaylist?: string;
  callToAction?: string;
}

// --- PUBLISHING QUEUE & JOBS ---
export type PublishingJobStatus =
  | "DRAFT"
  | "READY"
  | "SCHEDULED"
  | "PROCESSING"
  | "PUBLISHED"
  | "FAILED"
  | "CANCELLED";

export interface PublishingJob {
  id: string;
  projectId: string;
  projectTitle: string;
  platform: Platform;
  channelId: string;
  channelName: string;
  metadata: PublishingMetadata;
  status: PublishingJobStatus;
  scheduledAt?: string;
  publishedAt?: string;
  platformPostId?: string;
  platformPostUrl?: string;
  safetyStatus: "READY" | "NEEDS_REVIEW" | "BLOCKED";
  safetyNotes?: string;
  isMadeForKids: boolean;
  approvedByOwner: boolean;
  approvedAt?: string;
  error?: string;
  retryCount: number;
  createdAt: string;
  updatedAt: string;
}

export type AuditAction =
  | "CONNECT"
  | "DISCONNECT"
  | "UPLOAD"
  | "SCHEDULE"
  | "PUBLISH"
  | "CANCEL"
  | "DELETE"
  | "RETRY"
  | "APPROVE"
  | "SAFETY_CHECK";

export interface PublishingLogEntry {
  id: string;
  jobId?: string;
  projectId: string;
  projectTitle?: string;
  platform: Platform;
  channelId?: string;
  action: AuditAction;
  status: "SUCCESS" | "FAILED" | "WARNING" | "INFO";
  details: string;
  error?: string;
  platformPostId?: string;
  timestamp: string;
}

// --- SEO AGENT & TITLE GENERATOR ---
export interface TitleOption {
  id: string;
  title: string;
  ctrScore: number; // 0-100
  formula: "CURIOSITY_GAP" | "NUMBERED_LIST" | "HIGH_EMOTION" | "HOW_TO" | "QUESTION" | "SHOCK_REVELATION";
  formulaLabel: string;
  justification: string;
  characterCount: number;
}

export interface SEOChapter {
  timestamp: string;
  title: string;
}

export interface YouTubeSEOPackage {
  primaryTitle: string;
  titleOptions: TitleOption[];
  description: {
    hookSummary: string;
    chapters: SEOChapter[];
    coreDescription: string;
    linksAndResources: string[];
    callToAction: string;
    hashtags: string[];
    fullFormatted: string;
  };
  tags: string[];
  keywords: { keyword: string; searchVolume: "ALTO" | "MÉDIO" | "NICHO"; competition: "BAIXA" | "MÉDIA" | "ALTA" }[];
  hashtags: string[];
  pinnedComment: string;
  recommendedCategory: string;
  rankingAdvice: string;
}

// --- THUMBNAIL OPTIMIZER ---
export interface ThumbnailAnalysis {
  overallScore: number; // 0-100
  legibilityScore: number; // 0-100
  compositionScore: number; // 0-100
  textHookScore: number; // 0-100
  contrastRatioScore: number; // 0-100
  mobileReadability: "EXCELENTE" | "BOM" | "ATENÇÃO" | "RUIM";
  aspectRatioMatch: boolean;
  resolutionCheck: "HD_1080P" | "SD" | "4K";
  detectedElements: string[];
  recommendations: string[];
  strengths: string[];
}

// --- REPURPOSING ENGINE ---
export interface RepurposedClip {
  id: string;
  projectId: string;
  title: string;
  targetPlatform: "SHORTS" | "TIKTOK" | "REELS" | "FACEBOOK_CLIPS";
  aspectRatio: "9:16" | "1:1";
  startTimeSec: number;
  duration: number;
  hook: string;
  narrationClip: string;
  cta: string;
  caption: string;
  hashtags: string[];
  videoUrl?: string;
  thumbnailUrl?: string;
  status: "DRAFT" | "READY" | "SCHEDULED";
  createdAt: string;
}

// --- CONTENT SAFETY & COPPA ---
export interface ContentSafetyReport {
  status: "READY" | "NEEDS_REVIEW" | "BLOCKED";
  isChildrenContent: boolean;
  coppaCompliance: {
    requiresMadeForKidsTag: boolean;
    commentsDisabled: boolean;
    personalizedAdsDisabled: boolean;
    notificationsDisabled: boolean;
    confirmationReceived: boolean;
  };
  checks: {
    category: "COPYRIGHT_MUSIC" | "COMMUNITY_GUIDELINES" | "SENSITIVE_WORDS" | "CLICKBAIT_ACCURACY" | "CHILDREN_SAFETY";
    passed: boolean;
    severity: "LOW" | "MEDIUM" | "HIGH";
    notes: string;
  }[];
  overallAssessment: string;
}

// --- ANALYTICS ENGINE & AI ---
export interface VideoAnalytics {
  projectId: string;
  projectTitle: string;
  platform: Platform;
  platformPostId: string;
  thumbnailUrl?: string;
  videoUrl?: string;
  publishDate: string;
  views: number;
  watchTimeHours: number;
  avgViewDurationSec: number;
  avgViewPercentage: number;
  ctr: number; // Click-through-rate %
  likes: number;
  comments: number;
  shares: number;
  subscribersGained: number;
  engagementRate: number;
  retentionCurve: Array<{ timestampSec: number; percentRemaining: number }>;
  safetyStatus: string;
}

export interface AggregatedAnalytics {
  period: "7D" | "30D" | "90D" | "ALL";
  totalViews: number;
  totalWatchTimeHours: number;
  avgViewDurationSec: number;
  avgCTR: number;
  totalLikes: number;
  totalComments: number;
  totalShares: number;
  subscribersGained: number;
  overallEngagementRate: number;
  timeSeries: Array<{
    date: string;
    views: number;
    watchTimeHours: number;
    engagement: number;
    subscribers: number;
  }>;
  platformBreakdown: Partial<
    Record<
      Platform,
      { views: number; likes: number; shares: number; comments: number; subscribers: number }
    >
  >;
  topVideos: VideoAnalytics[];
  topShorts: VideoAnalytics[];
}

export interface AIAnalyticsQueryResponse {
  question: string;
  answer: string;
  highlightMetric?: { label: string; value: string; trend?: string };
  recommendedActions: string[];
  dataConfidence: "HIGH" | "MEDIUM" | "LIMITED_DATA";
  basedOnProjects: string[];
}
