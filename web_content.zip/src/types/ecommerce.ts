export type ScreenType = 
  | 'home' 
  | 'categories' 
  | 'pdp' 
  | 'cart' 
  | 'checkout' 
  | 'order_success' 
  | 'account' 
  | 'orders'
  | 'vendor'
  | 'export_apk';

export type AppViewMode = 'mobile_preview' | 'responsive' | 'specs_ia' | 'design_system' | 'ai_prompts' | 'export_apk';

export interface ProductVariant {
  id: string;
  name: string;
  colorHex?: string;
  inStock: boolean;
  priceModifier?: number;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  verifiedPurchase: boolean;
  variant: string;
  photos?: string[];
  likes: number;
}

export interface Vendor {
  id: string;
  name: string;
  badge: 'Mall' | 'Verified' | 'Top Seller';
  rating: number;
  positiveFeedbackPercent: number;
  shipOnTimePercent: number;
  responseTime: string;
  followersCount: string;
  joinedYear: number;
  avatar: string;
  banner: string;
  vouchers: {
    id: string;
    discount: string;
    minSpend: number;
    code: string;
  }[];
}

export interface Product {
  id: string;
  title: string;
  category: string;
  price: number;
  originalPrice: number;
  discountPercent: number;
  rating: number;
  reviewCount: number;
  soldCount: string;
  images: string[];
  colors: { id: string; name: string; hex: string }[];
  sizes: string[];
  vendorId: string;
  isFlashSale?: boolean;
  flashSoldPercent?: number;
  freeShipping?: boolean;
  specifications: { label: string; value: string }[];
  description: string;
  reviews: Review[];
}

export interface CartItem {
  id: string;
  product: Product;
  selectedColor: string;
  selectedSize: string;
  quantity: number;
  selected: boolean;
}

export interface DeliveryAddress {
  id: string;
  name: string;
  phone: string;
  addressLine: string;
  city: string;
  postalCode: string;
  isDefault: boolean;
  label: 'Home' | 'Office';
}

export interface OrderRecord {
  id: string;
  orderNumber: string;
  date: string;
  items: CartItem[];
  totalAmount: number;
  paymentMethod: string;
  status: 'Processing' | 'Shipped' | 'Out for Delivery' | 'Delivered';
  trackingNumber: string;
  address: DeliveryAddress;
}
