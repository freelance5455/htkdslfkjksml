export type VideoLanguage = 'English' | 'Hindi' | 'Marathi';

export type VideoCategory =
  | 'Disease Education'
  | 'Medicine Education'
  | 'Nutrition & Diet'
  | 'Fitness & Exercise'
  | 'Heart Health'
  | 'Diabetes Care'
  | 'Respiratory Health'
  | 'Mental Health'
  | 'Women\'s Health'
  | 'Child Health'
  | 'Senior Citizen Health'
  | 'First Aid & Emergency'
  | 'Bone & Joint Health'
  | 'Preventive Healthcare';

export interface VideoContent {
  title: string;
  description: string;
  categoryName: string;
  source: string;
  keyTakeaways: string[];
}

export interface HealthVideoItem {
  id: string;
  youtubeId: string; // YouTube Embed ID or valid HTML5 video stream
  fallbackYoutubeIds?: string[]; // Backup embeddable video IDs on same topic
  thumbnailUrl: string;
  duration: string;
  category: VideoCategory;
  categoryEmoji: string;
  lastUpdated: string;
  bgGradient: string;
  content: {
    English: VideoContent;
    Hindi: VideoContent;
    Marathi: VideoContent;
  };
}
