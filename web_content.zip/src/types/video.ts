export type VideoCategory =
  | 'trending'
  | 'movies'
  | 'series'
  | 'action'
  | 'scifi'
  | 'comedy'
  | 'drama'
  | 'documentary'
  | 'anime'
  | 'uploaded';

export interface VideoItem {
  id: string;
  title: string;
  originalTitle?: string;
  description: string;
  videoUrl: string;
  trailerUrl?: string;
  thumbnailUrl: string;
  backdropUrl?: string;
  category: VideoCategory;
  tags: string[];
  duration: number; // in seconds
  releaseYear: number;
  matchScore: number; // e.g. 98
  rating: 'All' | '13+' | '16+' | '18+';
  quality: '4K' | 'HD' | 'Full HD';
  cast?: string[];
  director?: string;
  isUploaded?: boolean;
  uploadedAt?: string;
  uploaderName?: string;
  views?: number;
  likes?: number;
  dislikes?: number;
  audioLanguage?: string;
  subtitles?: { lang: string; label: string; src?: string }[];
}

export interface WatchProgress {
  videoId: string;
  currentTime: number;
  duration: number;
  updatedAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  isKids: boolean;
}
