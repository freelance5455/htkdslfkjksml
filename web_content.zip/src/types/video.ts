export type VideoEngineId =
  | "pixverse"
  | "veo-2"
  | "dreamina-seedance-2"
  | "zsky-ai"
  | "treblo-ai"
  | "runway-gen3"
  | "luma-ray"
  | "pika-2"
  | "kling-ai"
  | "sora-sim"
  | "svd-pro";

export type CameraMotionType =
  | "STATIC_TRIPOD"
  | "PAN_LEFT"
  | "PAN_RIGHT"
  | "TILT_UP"
  | "TILT_DOWN"
  | "ZOOM_IN"
  | "ZOOM_OUT"
  | "ORBIT"
  | "DRONE_FPV"
  | "HANDHELD";

export type CameraAngle =
  | "WIDE"
  | "MEDIUM"
  | "CLOSE_UP"
  | "MACRO"
  | "OVERHEAD"
  | "DUTCH_ANGLE";

export type VisualLightingStyle =
  | "CINEMATIC"
  | "PHOTOREALISTIC"
  | "3D_PIXAR"
  | "CYBERPUNK"
  | "ANIME"
  | "VINTAGE_FILM"
  | "STUDIO_LIGHT"
  | "NATURAL_SUNLIGHT";

export interface VideoEngineConfig {
  id: VideoEngineId;
  name: string;
  provider: string;
  badge: string;
  description: string;
  highlight: string;
  iconName: string;
  color: string;
  maxDuration: number;
  defaultDuration: number;
  resolutions: string[];
  fpsOptions: number[];
  aspectRatios: ("16:9" | "9:16" | "1:1" | "4:5")[];
  supportsImageToVideo: boolean;
  supportsCameraMotion: boolean;
  supportsMotionStrength: boolean;
  estimatedCostPerSec: number;
  qualityTier: "Ultra" | "High" | "Fast";
}

export interface VideoGenerationRequest {
  engine: VideoEngineId;
  prompt: string;
  negativePrompt?: string;
  initialImageUrl?: string;
  cameraMotion: CameraMotionType;
  cameraAngle: CameraAngle;
  style: VisualLightingStyle;
  motionStrength: number; // 1 - 10
  duration: number; // in seconds (e.g. 4, 6, 10)
  aspectRatio: "16:9" | "9:16" | "1:1" | "4:5";
  resolution: "720p" | "1080p" | "4K";
  fps: number;
  seed?: number;
  sceneId?: string;
  sceneNumber?: number;
  projectId?: string;
  projectTitle?: string;
}

export interface VideoGenerationResult {
  id: string;
  videoUrl: string;
  thumbnailUrl: string;
  duration: number;
  engine: VideoEngineId;
  engineName: string;
  prompt: string;
  optimizedPrompt?: string;
  cameraMotion: CameraMotionType;
  cameraAngle: CameraAngle;
  style: VisualLightingStyle;
  aspectRatio: string;
  resolution: string;
  fps: number;
  sceneId?: string;
  sceneNumber?: number;
  projectId?: string;
  projectTitle?: string;
  status: "COMPLETED" | "FAILED" | "PROCESSING";
  createdAt: string;
  metadata?: Record<string, unknown>;
}
