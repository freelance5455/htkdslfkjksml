export interface CommunityPost {
  id: string;
  authorUid: string;
  authorId?: string;
  authorName: string;
  authorAvatar?: string;
  authorHeadline: string;
  authorLocation?: string;
  authorVerified?: boolean;
  content: string;
  imageUrl?: string;
  jobLink?: string;
  jobTitle?: string;
  jobOrganization?: string;
  tags: string[];
  isOfficialJob?: boolean;
  officialBadge?: 'Official Job' | 'Verified by Admin';
  likesCount: number;
  commentsCount: number;
  savesCount: number;
  sharesCount: number;
  createdAt: string;
  updatedAt?: string;
  likedBy?: string[]; // user UIDs who liked this post
  savedBy?: string[]; // user UIDs who saved this post
}

export interface PostComment {
  id: string;
  postId: string;
  authorUid: string;
  authorId?: string;
  authorName: string;
  authorAvatar?: string;
  authorHeadline?: string;
  content: string;
  createdAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  avatar?: string;
  headline: string;
  location: string;
  qualification: string;
  targetExams: string[];
  bio: string;
  joinedDate: string;
  postsCount: number;
  isVerified?: boolean;
}

export interface PostReport {
  id: string;
  postId: string;
  postAuthorName: string;
  reportedBy: string;
  reason: 'Fake job or scam link' | 'Misleading examination date' | 'Spam or irrelevant' | 'Inappropriate content' | 'Paid registration scam';
  details?: string;
  createdAt: string;
  status: 'PENDING' | 'RESOLVED' | 'DISMISSED';
}

export interface CreatePostInput {
  content: string;
  imageUrl?: string;
  imageFile?: File;
  jobLink?: string;
  jobTitle?: string;
  jobOrganization?: string;
  tags?: string[];
}
