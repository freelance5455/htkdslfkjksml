export interface LanguageOption {
  code: string;
  englishName: string;
  nativeName: string;
  isRtl: boolean;
  scriptFamily: 'nastaliq' | 'arabic' | 'latin' | 'devanagari' | 'cjk' | 'other';
}

export interface LiveDictationState {
  isListening: boolean;
  isConnected: boolean;
  liveRawText: string;
  interimRawText: string;
  liveTranslatedText: string;
  audioLevel: number;
  waveformBars: number[];
  errorMessage: string | null;
}

export interface WrittenParagraph {
  id: string;
  originalText: string;
  displayText: string;
  languageCode: string;
  isFinalizing?: boolean;
}
