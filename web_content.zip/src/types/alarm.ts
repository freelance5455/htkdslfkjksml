export type MediaType = 'video' | 'audio';

export interface Alarm {
  id: string;
  hour: number; // 0 - 23
  minute: number; // 0 - 59
  alarmLabel: string;
  mediaUri: string; // URL, IndexedDB blob key, or preset ID
  mediaName: string;
  mediaType: MediaType;
  mediaThumbnail?: string;
  repeatDays: number[]; // 0 = Sun, 1 = Mon, ..., 6 = Sat. Empty array = One-time alarm
  isEnabled: boolean;
  volume: number; // 0 - 100
  gradualVolumeEnabled: boolean;
  vibrationEnabled: boolean;
  snoozeDuration: number; // minutes
  createdAt: number;
  lastTriggered?: number;
}

export interface AppSettings {
  defaultVolume: number;
  defaultSnoozeDuration: number;
  gradualVolume: boolean;
  vibration: boolean;
  darkMode: boolean;
  timeFormat: '12h' | '24h';
  soundInSilentMode: boolean;
}

export interface PresetMediaItem {
  id: string;
  name: string;
  type: MediaType;
  url: string;
  thumbnail: string;
  durationStr: string;
  artistOrDesc: string;
}

export interface StoredMediaFile {
  id: string;
  name: string;
  type: MediaType;
  blob: Blob;
  size: number;
  duration: number;
  createdAt: number;
  thumbnailUrl?: string;
}
