export type TransactionType = 'expense' | 'income';

export type PaymentMode = 'cash' | 'upi' | 'card' | 'bank_transfer' | 'other';

export interface Category {
  id: string;
  nameHi: string;
  nameEn: string;
  icon: string;
  color: string;
  type: TransactionType;
  budgetLimit?: number;
  isCustom?: boolean;
}

export interface FamilyMember {
  id: string;
  name: string;
  relationHi: string;
  relationEn: string;
  avatarColor: string;
  isDefault?: boolean;
}

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  categoryId: string;
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm
  description: string;
  familyMemberId?: string;
  paymentMode: PaymentMode;
  notes?: string;
  createdAt: number;
  updatedAt: number;
}

export interface LoanRepayment {
  id: string;
  date: string;
  amount: number;
  notes?: string;
  note?: string;
}

export interface Loan {
  id: string;
  personName: string;
  phone?: string;
  type: 'borrowed' | 'lent'; // borrowed = I owe them (लिया कर्ज), lent = they owe me (दिया उधार)
  amount: number;
  date: string;
  dueDate?: string;
  status: 'pending' | 'paid' | 'partial';
  notes?: string;
  repayments: LoanRepayment[];
  createdAt: number;
  updatedAt: number;
}

export interface BillReminder {
  id: string;
  titleHi: string;
  titleEn: string;
  category: string;
  amount: number;
  dueDate: string;
  frequency: 'monthly' | 'one_time' | 'quarterly' | 'yearly';
  status: 'pending' | 'paid';
  autoLogExpense?: boolean;
  notes?: string;
  createdAt: number;
}

export interface SavingsHistoryEntry {
  id: string;
  date: string;
  amount: number;
  type: 'deposit' | 'withdraw';
  note?: string;
}

export interface SavingsGoal {
  id: string;
  titleHi: string;
  titleEn: string;
  targetAmount: number;
  currentAmount: number;
  deadline?: string;
  icon: string;
  color: string;
  history: SavingsHistoryEntry[];
  createdAt: number;
}

export interface BudgetConfig {
  month: string; // YYYY-MM
  overallBudget: number;
  categoryLimits: Record<string, number>;
}

export interface AppSettings {
  language: 'hi' | 'en';
  currency: string;
  pinLockEnabled: boolean;
  pinHash?: string;
  biometricEnabled: boolean;
  hasSeenOnboarding?: boolean;
}

export interface AppDataBackup {
  version: string;
  exportedAt: string;
  transactions: Transaction[];
  categories: Category[];
  loans: Loan[];
  bills: BillReminder[];
  savingsGoals: SavingsGoal[];
  familyMembers: FamilyMember[];
  budget: BudgetConfig;
  settings: AppSettings;
}
