export type CategoryType = 'morning' | 'evening' | 'all';
export type TabType = 'home' | 'morning_evening' | 'list' | 'prayer_times' | 'qibla' | 'favorites' | 'search' | 'settings';

export interface DhikrItem {
  id: string;
  orderNumber: number;
  category: 'morning' | 'evening';
  categoryArabic: string;
  title: string;
  text: string;
  count: number;
  note?: string;
  isQuran?: boolean;
}

export interface DhikrProgress {
  [dhikrId: string]: number;
}

export type FontSizeOption = 'sm' | 'md' | 'lg' | 'xl';
export type ArabicFontOption = 'cairo' | 'tajawal' | 'amiri' | 'uthmani';
export type MilestoneOption = '33' | '10' | 'target' | 'none';
export type ThemeMode = 'auto' | 'dark' | 'light';
export type NightReadingMode = 'auto' | 'on' | 'off';
export type NightWarmthLevel = 'mild' | 'warm' | 'deep_amber';
export type AmbientSoundType = 'none' | 'rain' | 'birds' | 'nature' | 'water' | 'night';
export type ReciterId = 'alafasy' | 'ghamdi' | 'muaiqly' | 'abdulbasit';

export interface AmbientSettings {
  enabled: boolean;
  type: AmbientSoundType;
  volume: number; // 0 to 1
  autoPlayInDhikr: boolean;
}

export interface UserSettings {
  darkMode: boolean;
  themeMode: ThemeMode;
  amoledMode?: boolean;
  fontSize: FontSizeOption;
  arabicFont: ArabicFontOption;
  vibration: boolean;
  vibrationMilestone: MilestoneOption;
  sound: boolean;
  autoAdvance: boolean;
  notificationsEnabled: boolean;
  morningNotification: boolean;
  morningNotificationTime: string;
  eveningNotification: boolean;
  eveningNotificationTime: string;
  ambientSound?: AmbientSettings;
  nightReadingMode?: NightReadingMode;
  nightWarmthLevel?: NightWarmthLevel;
  selectedReciter?: ReciterId;
}

export interface InAppNotification {
  id: string;
  title: string;
  body: string;
  category: 'morning' | 'evening';
  time: string;
  timestamp: number;
  read: boolean;
}

