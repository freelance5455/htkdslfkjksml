export type ActivityCategory = 
  | 'workout' 
  | 'skincare' 
  | 'nutrition' 
  | 'water' 
  | 'grooming' 
  | 'posture' 
  | 'sleep';

export type WorkoutType = 'Upper Body' | 'Lower Body' | 'Core' | 'Cardio' | 'Mobility' | 'Calisthenics';
export type MealType = 'breakfast' | 'morning_snack' | 'lunch' | 'evening_snack' | 'dinner';
export type SkincareRoutineType = 'morning' | 'night' | 'custom';

export interface Activity {
  id: string;
  name: string;
  category: ActivityCategory;
  scheduledTime: string; // HH:mm format, e.g. "08:30"
  description?: string;
  scheduleType: 'daily' | 'weekly' | 'custom_days';
  selectedDays: number[]; // 0: Sunday, 1: Monday, ... 6: Saturday
  reminderEnabled: boolean;
  
  // Specific detail metadata
  // Workout
  workoutCategory?: WorkoutType;
  sets?: number;
  reps?: number;
  durationMinutes?: number;
  durationSeconds?: number;
  restSeconds?: number;
  
  // Skincare
  routineType?: SkincareRoutineType;
  isOptional?: boolean;
  
  // Nutrition
  mealType?: MealType;
  calories?: number;
  protein?: number; // in grams
  quantity?: string;
  
  // Posture / Fitness
  postureDurationMinutes?: number;
  
  // Grooming
  groomingFrequency?: 'daily' | 'weekly';
}

export interface TaskRecord {
  activityId: string;
  completed: boolean;
  completedAt?: string;
  skipped?: boolean;
  customValue?: number; // e.g. custom calories or reps completed
}

export interface DayRecord {
  date: string; // YYYY-MM-DD
  tasks: Record<string, TaskRecord>; // activityId -> TaskRecord
  waterConsumedMl: number;
  waterGoalMl: number;
  sleepBedtime?: string;
  sleepWakeTime?: string;
  sleepDurationMinutes?: number;
  notes?: string;
}

export interface WeightRecord {
  id: string;
  date: string; // YYYY-MM-DD
  weightKg: number;
  bodyFatPercentage?: number;
  notes?: string;
}

export interface PhotoRecord {
  id: string;
  date: string; // YYYY-MM-DD
  dayNumber: number; // 1 - 90
  type: 'before' | 'progress' | 'after';
  angle: 'face' | 'jawline' | 'front_physique' | 'side_profile';
  imageUrl: string;
  weightKg?: number;
  notes?: string;
}

export interface UserProfile {
  name: string;
  tagline: string;
  startDate: string; // YYYY-MM-DD
  targetWeightKg: number;
  startWeightKg: number;
  currentWeightKg: number;
  waterGoalMl: number;
  calorieGoal: number;
  proteinGoalG: number;
  sleepGoalHours: number;
  darkMode: boolean;
  notificationsEnabled: boolean;
}

export interface AppState {
  profile: UserProfile;
  activities: Activity[];
  history: Record<string, DayRecord>; // YYYY-MM-DD -> DayRecord
  weightHistory: WeightRecord[];
  photos: PhotoRecord[];
  activeDate: string; // Currently inspected date (default today)
}
