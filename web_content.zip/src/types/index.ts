export interface User {
  id: string;
  name: string;
  username: string;
  email?: string;
  phone?: string;
  phoneCountryCode?: string;
  avatar: string;
  coverImage: string;
  bio: string;
  province: string;
  verified: boolean;
  isPrivate: boolean;
  isAdmin: boolean;
  isSuspended?: boolean;
  friends: string[];
  followers: string[];
  following: string[];
  blockedUsers: string[];
  friendsCount?: number;
  followersCount?: number;
  followingCount?: number;
  createdAt: string;
  lastSeenAt: string;
}

export interface Post {
  id: string;
  authorId: string;
  author?: User;
  content: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'none';
  likes: { userId: string; reaction: 'like' | 'love' | 'angola' | 'laugh' | 'fire' }[];
  comments: {
    id: string;
    authorId: string;
    author?: User;
    text: string;
    createdAt: string;
    replies?: { id: string; authorId: string; author?: User; text: string; createdAt: string }[];
  }[];
  sharesCount: number;
  savedBy: string[];
  hashtags: string[];
  province: string;
  pageId?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Story {
  id: string;
  authorId: string;
  mediaUrl?: string;
  mediaType: 'image' | 'video' | 'text';
  textContent?: string;
  backgroundGradient?: string;
  privacy: 'public' | 'friends' | 'private';
  views: { userId: string; viewedAt: string; user?: User }[];
  reactions: { userId: string; emoji: string }[];
  createdAt: string;
}

export interface StoriesGroup {
  authorId: string;
  user?: User;
  stories: Story[];
  hasUnseen: boolean;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  text: string;
  type: 'text' | 'image' | 'video' | 'audio' | 'file' | 'location' | 'contact';
  mediaUrl?: string;
  fileName?: string;
  fileSize?: string;
  audioDurationSeconds?: number;
  location?: { lat: number; lng: number; address: string };
  contact?: { name: string; phone: string };
  replyTo?: { messageId: string; text: string; senderName: string };
  reactions: { userId: string; emoji: string }[];
  status: 'sent' | 'delivered' | 'read';
  deliveredTo: string[];
  readBy: string[];
  deletedFor: string[];
  isDeletedForEveryone?: boolean;
  isPinned?: boolean;
  expiresAt?: number;
  createdAt: string;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group';
  name?: string;
  avatar?: string;
  participantIds: string[];
  adminIds?: string[];
  pinnedMessageIds?: string[];
  ephemeralTimerMinutes?: number;
  updatedAt: string;
  lastMessage?: string;
  lastMessageTime?: string;
  otherUsers?: User[];
  unreadCount?: number;
}

export interface GroupCommunity {
  id: string;
  name: string;
  description: string;
  coverImage: string;
  avatar: string;
  category: string;
  isPrivate: boolean;
  creatorId: string;
  adminIds: string[];
  memberIds: string[];
  pendingMemberIds: string[];
  rules: string[];
  province?: string;
  isMember?: boolean;
  isAdmin?: boolean;
  membersCount?: number;
  createdAt: string;
}

export interface PageProfile {
  id: string;
  name: string;
  handle: string;
  category: string;
  description: string;
  avatar: string;
  coverImage: string;
  ownerId: string;
  followers: string[];
  contactEmail: string;
  contactPhone: string;
  province: string;
  isFollowing?: boolean;
  followersCount?: number;
  metrics: {
    viewsThisWeek: number;
    reach: number;
    engagementRate: string;
  };
  createdAt: string;
}

export interface MarketplaceItem {
  id: string;
  sellerId: string;
  seller?: User;
  title: string;
  description: string;
  price: number;
  currency: 'AOA' | 'USD';
  category: string;
  province: string;
  images: string[];
  condition: 'Novo' | 'Usado como novo' | 'Bom estado';
  contactPhone: string;
  sold: boolean;
  createdAt: string;
}

export interface CallLog {
  id: string;
  callerId: string;
  receiverId: string;
  callType: 'audio' | 'video';
  status: 'completed' | 'missed' | 'rejected';
  durationSeconds: number;
  timestamp: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  fromUserId: string;
  fromUser?: User;
  type: 'like' | 'comment' | 'friend_request' | 'friend_accepted' | 'follow' | 'mention' | 'call' | 'group_invite' | 'marketplace_inquiry';
  targetId?: string;
  text: string;
  read: boolean;
  createdAt: string;
}

export interface TrendingHashtag {
  tag: string;
  count: number;
  category: string;
}

export interface TrendingTopic {
  id: string;
  title: string;
  source: string;
  category: string;
  readers: string;
  timeAgo: string;
  province: string;
}

export interface AdminStats {
  totalUsers: number;
  verifiedUsers: number;
  suspendedUsers: number;
  totalPosts: number;
  totalMessages: number;
  totalMarketplace: number;
  activeStories: number;
  totalGroups: number;
  totalPages: number;
  pendingReportsCount: number;
}
