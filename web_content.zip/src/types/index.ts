export interface Section {
  heading: string;
  headingEn?: string;
  summary: string;
  summaryEn?: string;
  bulletPoints: string[];
  bulletPointsEn?: string[];
  examples?: string[];
}

export interface KeyTerm {
  term: string;
  definition: string;
  translation: string;
  example?: string;
}

export interface Question {
  id: number;
  question: string;
  questionTranslation?: string;
  options: string[];
  correctIndex: number;
  answerKey: string; // "A" | "B" | "C" | "D"
  explanation: string;
  explanationEn?: string;
}

export interface StudyModule {
  id: string;
  title: string;
  titleEn: string;
  subject: string;
  subjectEn: string;
  grade: string;
  category: 'Afaan Oromoo' | 'Saayinsii' | 'Herrega' | 'Aadaa';
  topicSummary: string;
  topicSummaryEn?: string;
  sections: Section[];
  keyTerms: KeyTerm[];
  questions: Question[];
  examTip: string;
  examTipEn?: string;
  estimatedMinutes: number;
  isAiGenerated?: boolean;
}

export interface ModuleProgress {
  bestScore: number;
  totalQuestions: number;
  completed: boolean;
  lastAttemptDate?: string;
}

export type ProgressMap = { [moduleId: string]: ModuleProgress };

export interface QuizAttempt {
  moduleId: string;
  moduleTitle: string;
  score: number;
  total: number;
  date: string;
  answers: { [questionId: number]: number };
}

