export type UserRole = 'platform_owner' | 'org_admin' | 'sub_admin' | 'employee';

export interface SubAdminPermissions {
  manageEmployees: boolean;
  manageAttendance: boolean;
  manageVisits: boolean;
  manageTasks: boolean;
  manageLeave: boolean;
  managePerformance: boolean;
  manageAwards: boolean;
  manageReports: boolean;
  manageBranding: boolean;
  manageMessaging: boolean;
  manageImports: boolean;
  manageSecurity: boolean;
}

export interface UserProfile {
  id: string; // Auth UID
  email: string;
  displayName: string;
  role: UserRole;
  organizationId: string;
  employeeId?: string; // Linked employee ID if technician
  subAdminPermissions?: SubAdminPermissions;
  avatarUrl?: string;
  phone?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Organization {
  id: string;
  name: string;
  status: 'active' | 'suspended';
  accessCode?: string; // Legacy field for backwards compatibility
  accessPasswordHash?: string; // Salted SHA-256 hash
  accessPasswordSalt?: string; // Cryptographic salt
  hasAccessPassword?: boolean; // Indicator whether an access password/credential is set
  logoUrl?: string;
  accentColor?: string;
  createdAt: string;
  createdBy: string;
  isDeleted?: boolean;
  deletedAt?: string;
  deletedBy?: string;
  kpiSettings?: {
    attendanceWeight: number; // e.g. 25
    visitWeight: number;      // e.g. 35
    taskWeight: number;       // e.g. 25
    onTimeWeight: number;     // e.g. 15
  };
}

export type JoinRequestStatus = 'pending' | 'approved' | 'rejected' | 'cancelled';

export interface CompanyJoinRequest {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  userPhone?: string;
  orgId: string;
  orgName: string;
  status: JoinRequestStatus;
  notes?: string;
  rejectionReason?: string;
  requestedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  reviewedByName?: string;
}

export interface OwnershipTransfer {
  id: string;
  currentOwnerEmail: string;
  currentOwnerName: string;
  newOwnerName: string;
  newOwnerEmail: string;
  newOwnerPhone: string;
  token: string;
  status: 'pending' | 'accepted' | 'cancelled' | 'expired';
  createdAt: string;
  expiresAt: string;
  acceptedAt?: string;
}

export type EmploymentStatus = 'active' | 'on_leave' | 'inactive' | 'left_company' | 'suspended';

export interface LeavingDetails {
  leavingDate: string;
  reasonCategory: 'resignation' | 'retirement' | 'termination' | 'contract_ended' | 'other';
  notes?: string;
  recordedBy: string;
  recordedAt: string;
}

export interface Employee {
  id: string;
  orgId: string;
  employeeCode: string; // e.g. "EMP-1001"
  name: string;
  email: string;
  phone: string;
  department: string;
  designation: string;
  joiningDate: string;
  status: EmploymentStatus;
  managerName: string;
  territory: string;
  emergencyContact: string;
  notes?: string;
  avatarUrl?: string;
  userId?: string; // Tied to auth account
  leavingDetails?: LeavingDetails;
  createdAt: string;
  updatedAt?: string;
}

export interface AttendanceRecord {
  id: string;
  orgId: string;
  employeeId: string;
  employeeName: string;
  date: string; // YYYY-MM-DD
  checkInTime: string; // ISO
  checkOutTime?: string; // ISO
  checkInLat?: number;
  checkInLng?: number;
  checkInAddress?: string;
  checkOutLat?: number;
  checkOutLng?: number;
  checkOutAddress?: string;
  status: 'present' | 'late' | 'half_day' | 'completed';
  durationMinutes?: number;
  notes?: string;
  correctionRequest?: {
    reason: string;
    requestedCheckIn?: string;
    requestedCheckOut?: string;
    status: 'pending' | 'approved' | 'rejected';
    adminNote?: string;
    reviewedAt?: string;
  };
}

export type VisitStatus = 'scheduled' | 'en_route' | 'in_progress' | 'completed' | 'cancelled';
export type PriorityLevel = 'low' | 'medium' | 'high' | 'urgent';

export interface FieldVisit {
  id: string;
  orgId: string;
  title: string;
  customerName: string;
  customerPhone?: string;
  siteAddress: string;
  lat?: number;
  lng?: number;
  assignedEmployeeId: string;
  assignedEmployeeName: string;
  scheduledDate: string; // YYYY-MM-DD
  scheduledTime: string; // HH:mm
  priority: PriorityLevel;
  status: VisitStatus;
  startedAt?: string;
  completedAt?: string | null;
  outcomeNotes?: string;
  photoUrl?: string;
  photoInspection?: {
    inspectionSummary: string;
    detectedEquipmentOrCondition: string;
    recommendations: string;
  };
  createdAt: string;
}

export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'overdue' | 'cancelled';

export interface TaskItem {
  id: string;
  orgId: string;
  title: string;
  description?: string;
  priority: PriorityLevel;
  dueDate: string; // YYYY-MM-DD
  status: TaskStatus;
  assignedEmployeeId: string;
  assignedEmployeeName: string;
  completedAt?: string | null;
  notes?: string;
  createdAt: string;
}

export type LeaveType = 'annual' | 'sick' | 'casual' | 'emergency';
export type LeaveStatus = 'pending' | 'approved' | 'rejected';

export interface LeaveRequest {
  id: string;
  orgId: string;
  employeeId: string;
  employeeName: string;
  leaveType: LeaveType;
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  reason: string;
  status: LeaveStatus;
  adminComment?: string;
  reviewedBy?: string;
  createdAt: string;
}

export interface Award {
  id: string;
  orgId: string;
  employeeId: string;
  employeeName: string;
  title: string;
  period: string; // e.g. "September 2026"
  reason: string;
  awardedBy: string;
  date: string;
  badgeIcon?: string;
}

export interface FileAttachmentMetadata {
  id: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  storagePath: string;
  uploaderId: string;
  uploaderName?: string;
  companyId: string;
  conversationId: string;
  messageId?: string;
  uploadTimestamp: string;
  status: 'uploading' | 'completed' | 'failed' | 'cancelled';
  thumbnailUrl?: string;
  mediaCategory?: 'image' | 'video' | 'document' | 'voice';
}

export interface Message {
  id: string;
  orgId: string;
  senderId: string;
  senderName: string;
  senderRole: string;
  recipientId: string; // employeeId, 'all' or 'admin'
  content: string;
  messageType: 'text' | 'voice' | 'image' | 'document' | 'video';
  mediaUrl?: string;
  fileName?: string;
  fileSizeBytes?: number;
  mimeType?: string;
  storagePath?: string;
  fileId?: string;
  uploadStatus?: 'uploading' | 'completed' | 'failed';
  thumbnailUrl?: string;
  voiceDuration?: number;
  voiceTranscript?: string;
  read: boolean;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  orgId: string;
  orgName: string;
  submittedBy: string;
  submittedByEmail: string;
  subject: string;
  category: 'bug' | 'question' | 'feature' | 'urgent';
  description: string;
  status: 'open' | 'in_progress' | 'waiting_for_customer' | 'resolved' | 'closed';
  replies?: {
    id: string;
    sender: string;
    isPlatformStaff: boolean;
    text: string;
    createdAt: string;
  }[];
  createdAt: string;
  updatedAt: string;
}

export interface AuditLogEntry {
  id: string;
  orgId: string;
  userId: string;
  userName: string;
  userRole?: string;
  action: string;
  module: string;
  details: string;
  targetId?: string;
  targetName?: string;
  result?: 'success' | 'failure' | 'warning';
  timestamp: string;
}

export interface NotificationItem {
  id: string;
  orgId: string;
  userId: string;
  targetRole?: 'platform_owner' | 'org_admin' | 'sub_admin' | 'employee';
  title: string;
  message: string;
  type: 'visit' | 'task' | 'leave' | 'attendance' | 'award' | 'message' | 'system' | 'join_request' | 'owner';
  read: boolean;
  linkTab?: string;
  createdAt: string;
}

export interface OfflineAction {
  id: string;
  type: 'check_in' | 'check_out' | 'start_visit' | 'complete_visit' | 'update_task' | 'apply_leave' | 'send_message';
  payload: any;
  timestamp: string;
  status: 'pending' | 'syncing' | 'failed' | 'synced';
  error?: string;
}

export type ImportMode = 'add_only' | 'update_only' | 'add_and_update' | 'skip_existing';
export type ImportStatus = 'processing' | 'completed' | 'completed_with_errors' | 'failed';

export interface ImportHistoryRecord {
  id: string;
  orgId: string;
  uploadedBy: string;
  uploadedByEmail: string;
  uploadedAt: string;
  fileName: string;
  mode: ImportMode;
  totalRows: number;
  createdCount: number;
  updatedCount: number;
  skippedCount: number;
  errorCount: number;
  status: ImportStatus;
  errorSummary?: string[];
}

export interface SecuritySession {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  role: UserRole;
  orgId: string;
  deviceInfo: string;
  ipAddress?: string;
  lastActive: string;
  createdAt: string;
  isCurrent?: boolean;
}

export type LocationStatusCategory = 'live' | 'recent' | 'offline';

export interface TechnicianLocation {
  id: string; // employeeId
  orgId: string;
  employeeId: string;
  employeeName: string;
  employeeCode?: string;
  department?: string;
  phone?: string;
  lat: number;
  lng: number;
  accuracy?: number; // meters
  speed?: number;
  heading?: number;
  status: 'active' | 'on_break' | 'in_transit' | 'at_customer' | 'offline';
  currentVisitId?: string;
  currentVisitTitle?: string;
  currentCustomerName?: string;
  batteryLevel?: number;
  updatedAt: string; // ISO
}

export interface LocationHistoryPoint {
  id: string;
  orgId: string;
  employeeId: string;
  employeeName: string;
  lat: number;
  lng: number;
  accuracy?: number;
  eventType?: 'shift_active' | 'check_in' | 'check_out' | 'visit_start' | 'visit_complete' | 'waypoint';
  notes?: string;
  timestamp: string; // ISO
}
