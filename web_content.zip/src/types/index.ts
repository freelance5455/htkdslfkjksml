/**
 * Mi Biblioteca - Type Definitions (V4)
 */

export type ReadingStatus = 'POR LEER' | 'LEYENDO' | 'TERMINADO' | 'ABANDONADO' | 'RELECTURA';

export type ReaderProgressMode = 'PERCENTAGE' | 'PAGE_NUMBERS' | 'PAGES_LEFT' | 'TIME_LEFT' | 'HIDDEN';

export type AppTheme = 'dark' | 'light' | 'auto';

export type ShelfViewMode = 'shelf' | 'grid' | 'list';

export type ShelfBookSize = 'small' | 'medium' | 'large';

export type SortOption = 'title' | 'author' | 'dateAdded' | 'progress' | 'rating' | 'status';

export interface ReadingSession {
  id: string;
  bookId: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm or timestamp
  durationMinutes: number;
  startPage: number;
  endPage: number;
  pagesRead: number;
  notes?: string;
}

export interface CustomSticker {
  id: string;
  name: string;
  dataUrl: string;
  createdAt: string;
}

export interface BookQuote {
  id: string;
  bookId: string;
  bookTitle?: string;
  author?: string;
  text: string;
  page?: number;
  location?: string;
  chapter?: string;
  color: string; // hex or color token
  note?: string;
  reaction?: string; // Emoji reaction or sticker label
  customStickerId?: string;
  customStickerUrl?: string;
  favorite: boolean;
  createdAt: string;
  isSharedWithRoom?: boolean;
}

export interface BookReview {
  title?: string;
  text: string;
  rating?: number;
  createdAt: string;
  updatedAt?: string;
}

export interface BookBookmark {
  id: string;
  page: number;
  chapterTitle?: string;
  note?: string;
  createdAt: string;
}

export interface BookChapter {
  id: string;
  title: string;
  page?: number;
  pageStart?: number;
}

export interface BookFileAttachment {
  name: string;
  type: 'epub' | 'pdf';
  size: number;
  dataUrl?: string; // Stored offline in IndexedDB
  uploadedAt?: string;
  lastReadPosition?: {
    page: number;
    percentage: number;
    chapter?: string;
  };
}

export interface ReadingRecord {
  id: string;
  recordNumber: number; // 1, 2, ...
  status: ReadingStatus;
  dateStarted: string;
  dateFinished?: string;
  progress: number;
  pagesRead: number;
  totalReadingMinutes: number;
  sessions?: ReadingSession[];
  highlights?: BookHighlight[];
  annotations?: BookAnnotation[];
  quotes?: BookQuote[];
  notes?: string;
  rating?: number;
}

// Keep backward compatibility with existing RereadRecord reference
export type RereadRecord = ReadingRecord;

export interface BookHighlight {
  id: string;
  bookId: string;
  page: number;
  text: string;
  color: string;
  note?: string;
  reaction?: string;
  customStickerId?: string;
  customStickerUrl?: string;
  createdAt: string;
  isSharedWithRoom?: boolean;
}

export interface BookAnnotation {
  id: string;
  bookId: string;
  type: 'bookmark' | 'highlight' | 'note' | 'sticker' | 'quote';
  page: number;
  title?: string;
  text?: string;
  color?: string;
  reaction?: string;
  customStickerId?: string;
  customStickerUrl?: string;
  createdAt: string;
  isSharedWithRoom?: boolean;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  coverUrl?: string;
  genres: string[];
  tags: string[];
  saga?: string;
  sagaIndex?: number;
  publisher?: string;
  publishedDate?: string;
  totalPages: number;
  description?: string;
  rating: number; // 0, 0.5, 1, 1.5, ... 5
  status: ReadingStatus;
  progress: number; // 0 to 100 percentage
  pagesRead: number;
  favorite: boolean;
  collections: string[]; // collection IDs
  dateAdded: string; // ISO
  dateStarted?: string; // ISO
  dateFinished?: string; // ISO
  totalReadingMinutes: number;
  quotesCount?: number;
  notesCount?: number;
  rereadCount?: number;
  rereadHistory?: ReadingRecord[];
  readingRecords?: ReadingRecord[];
  activeReadingRecordId?: string;
  isSample?: boolean;
  sampleContent?: string; // Sample text for built-in reader demo
  chapters?: BookChapter[];
  bookmarks?: BookBookmark[];
  highlights?: BookHighlight[];
  annotations?: BookAnnotation[];
  review?: BookReview;
  fileAttachment?: BookFileAttachment;
}

export interface Collection {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
  color?: string;
}

export interface ReadingGoal {
  id: string;
  title: string;
  type: 'books_year' | 'books_month' | 'pages_year' | 'pages_month' | 'minutes_month' | 'days_month';
  target: number;
  year: number;
  month?: number; // 1-12
  createdAt: string;
}

export interface LedSettings {
  enabled: boolean;
  color: string; // hex code
  brightness: number; // 0 to 100
}

export interface ReaderSettings {
  fontSize: number; // px, e.g. 18
  fontFamily: 'serif' | 'sans' | 'mono';
  lineHeight: number; // e.g. 1.6
  margins: 'narrow' | 'normal' | 'wide';
  theme: 'dark' | 'light' | 'amoled';
  progressMode: ReaderProgressMode;
}

export interface SharedProfilePrivacy {
  showBooks: boolean;
  showFavoriteBook: boolean;
  showCurrentBook: boolean;
  showFavoriteAuthor: boolean;
  showFavoriteGenre: boolean;
  showStats: boolean;
  showActivity: boolean;
  showCollections: boolean;
  showQuotes: boolean;
}

export interface SharedProfileTheme {
  primaryColor: string; // e.g., '#8b5cf6'
  accentColor: string; // e.g., '#ec4899'
  avatarFrameColor: string;
  avatarFrameShape: 'circle' | 'rounded' | 'hexagon' | 'glow';
  bannerType: 'preset' | 'image' | 'gradient';
  bannerValue: string; // url or css gradient
  bannerBlur: number; // blur px, e.g. 20
}

export interface SharedProfileData {
  favoriteBookTitle?: string;
  favoriteBookAuthor?: string;
  favoriteBookCover?: string;
  currentBookTitle?: string;
  currentBookAuthor?: string;
  currentBookCover?: string;
  favoriteAuthor?: string;
  favoriteGenre?: string;
  theme: SharedProfileTheme;
  privacy: SharedProfilePrivacy;
}

export interface UserProfile {
  name: string;
  avatarSeed: string;
  avatarUrl?: string;
  bio?: string;
  joinedDate: string;
  sharedProfile?: SharedProfileData;
}

export interface AppSettings {
  theme: AppTheme;
  defaultView: ShelfViewMode;
  defaultSort: SortOption;
  bookSize: ShelfBookSize;
  systemAccentColor?: string; // Custom interface accent color
  led: LedSettings;
  reader: ReaderSettings;
  user: UserProfile;
}

export interface ReadingActivity {
  id: string;
  type: 'start_book' | 'progress_pages' | 'finish_book' | 'save_quote' | 'add_book' | 'reread' | 'review';
  bookId: string;
  bookTitle: string;
  author: string;
  coverUrl?: string;
  timestamp: string;
  details: string;
}

// Community & Shared Reading Rooms
export interface FriendUser {
  id: string;
  name: string;
  avatar: string;
  bio?: string;
  statusText?: string;
  isReadingNow?: boolean;
  currentBookTitle?: string;
  sharedProfile?: SharedProfileData;
}

export interface FriendRequest {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  timestamp: string;
  status: 'pending' | 'accepted' | 'rejected';
}

export interface RoomParticipant {
  userId: string;
  name: string;
  avatar: string;
  progress: number; // percentage e.g. 47
  currentPage: number;
  isReadingNow?: boolean;
  lastActive: string;
}

export interface RoomSharedItem {
  id: string;
  roomId: string;
  bookId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  type: 'highlight' | 'note' | 'quote' | 'reaction' | 'sticker';
  page: number;
  location?: string;
  text?: string;
  color?: string;
  note?: string;
  reaction?: string;
  stickerUrl?: string;
  customStickerUrl?: string;
  createdAt: string;
}

export interface RoomChatMessage {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  createdAt: string;
  replyToId?: string;
  replyToText?: string;
  reactions?: { [emoji: string]: string[] };
}

export interface RoomActivity {
  id: string;
  roomId: string;
  bookTitle: string;
  userId: string;
  userName: string;
  userAvatar: string;
  type: 'progress' | 'shared_quote' | 'shared_note' | 'shared_highlight' | 'reaction' | 'comment';
  text: string;
  timestamp: string;
  targetId?: string;
}

export interface ReadingRoom {
  id: string;
  bookId: string;
  bookTitle: string;
  bookAuthor: string;
  bookCover?: string;
  createdAt: string;
  createdBy: string;
  participants: RoomParticipant[];
  sharedItems: RoomSharedItem[];
  messages: RoomChatMessage[];
  recentActivities: RoomActivity[];
}

export interface BackupData {
  version: string;
  exportedAt: string;
  books: Book[];
  sessions: ReadingSession[];
  quotes: BookQuote[];
  collections: Collection[];
  goals: ReadingGoal[];
  settings: AppSettings;
  activities: ReadingActivity[];
  stickers?: CustomSticker[];
  rooms?: ReadingRoom[];
  friends?: FriendUser[];
}
