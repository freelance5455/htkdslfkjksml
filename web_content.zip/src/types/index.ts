export type Priority = 'high' | 'medium' | 'low';

export type TaskCategory = 'work' | 'personal' | 'health' | 'finance' | 'learning';

export interface Task {
  id: string;
  title: string;
  category: TaskCategory;
  priority: Priority;
  time: string;
  durationMinutes: number;
  completed: boolean;
  date: string; // YYYY-MM-DD
  notes?: string;
  aiSuggested?: boolean;
}

export interface Reminder {
  id: string;
  title: string;
  timeStr: string;
  category: string;
  completed: boolean;
}

export interface Goal {
  id: string;
  title: string;
  targetDate: string;
  category: string;
  progressPercentage: number;
  currentMilestone: string;
  totalMilestones: number;
  completedMilestones: number;
  color: string;
}

export interface Habit {
  id: string;
  title: string;
  frequency: string;
  streakDays: number;
  targetDaysPerWeek: number;
  completedToday: boolean;
  category: 'health' | 'productivity' | 'mindfulness' | 'learning';
  icon: string;
}

export type ExpenseCategory =
  | 'Housing'
  | 'Food & Dining'
  | 'Shopping'
  | 'Transport'
  | 'Utilities'
  | 'Wellness'
  | 'Income';

export interface Transaction {
  id: string;
  title: string;
  amount: number;
  type: 'expense' | 'income';
  category: ExpenseCategory;
  date: string;
  iconName: string;
}

export type MemoryCategory =
  | 'Preferences'
  | 'Important Notes'
  | 'Interests & Goals'
  | 'Health & Wellness';

export interface MemoryItem {
  id: string;
  title: string;
  content: string;
  category: MemoryCategory;
  dateAdded: string;
  userApproved: boolean;
  tags: string[];
}

export interface ChatAction {
  id: string;
  label: string;
  actionType: 'create_task' | 'create_reminder' | 'log_expense' | 'save_memory' | 'navigate';
  payload: any;
  executed?: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'buddy';
  text: string;
  timestamp: string;
  isVoice?: boolean;
  actions?: ChatAction[];
}

export interface UserProfile {
  name: string;
  email: string;
  avatarUrl: string;
  focusAreas: string[];
  wakeTime: string;
  bedTime: string;
  proMember: boolean;
  theme: 'light' | 'dark' | 'system';
  soundEnabled: boolean;
  voiceOutputEnabled: boolean;
  aiTone: 'friendly' | 'concise' | 'deep';
  aiProactivity: 'high' | 'balanced' | 'low';
}

export type ScreenId =
  | 'onboarding'
  | 'home'
  | 'planner'
  | 'buddy'
  | 'money'
  | 'goals'
  | 'memory'
  | 'profile';
