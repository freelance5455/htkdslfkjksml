export type WorkoutType = 
  | 'easy' 
  | 'intervals' 
  | 'tempo' 
  | 'track_reps' 
  | 'time_trial' 
  | 'recovery' 
  | 'treadmill' 
  | 'walk_cross';

export interface SplitLap {
  lapNumber: number;
  distanceMeters: number;
  durationSeconds: number;
  pace: string; // e.g. "4:32" min/km
  speedKmh: number;
}

export interface GPSCoordinate {
  lat: number;
  lng: number;
  timestamp: number;
  altitude?: number | null;
  speed?: number | null;
}

export interface Workout {
  id: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  workoutType: WorkoutType;
  title: string;
  distanceKm: number;
  distanceMeters: number;
  durationSeconds: number;
  durationFormatted: string; // mm:ss or hh:mm:ss
  avgPace: string; // min/km e.g. "4:50"
  avgSpeedKmh: number;
  rpe: number; // Rate of Perceived Exertion 1-10
  sleepHours?: number;
  sleepQuality?: number; // 1-5
  energyLevel?: number; // 1-5
  sorenessScore?: number; // 0-10
  painLocation?: string;
  notes?: string;
  weather?: string;
  splits: SplitLap[];
  routeCoordinates: GPSCoordinate[];
  coachAnalysis?: string;
  isTimeTrial?: boolean;
  timeTrialTimeFormatted?: string;
  isDemo?: boolean;
}

export interface UserProfile {
  name: string;
  age: number;
  heightCm: number;
  weightKg: number;
  experience: 'Beginner' | 'Intermediate' | 'Advanced';
  currentPb1600m: string; // e.g. "5:30"
  target1600m: string; // "4:50"
  weeklyVolumeKm: number; // e.g. 20
  trainingDaysPerWeek: number; // e.g. 5
  currentInjuries: string;
  medicalLimitations: string;
  preferredLanguage: 'Hinglish' | 'Hindi' | 'English';
  preferredTime: 'Morning' | 'Evening';
  hasCompletedOnboarding: boolean;
  isBaselineVerified: boolean;
  verifiedPb1600mDate?: string;
}

export interface WeeklyPlanDay {
  id: string; // 'mon', 'tue', etc.
  dayName: 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY' | 'SUNDAY';
  title: string;
  workoutType: WorkoutType;
  targetDurationMin: number;
  targetDistanceKm?: number;
  intensity: 'low' | 'moderate' | 'high';
  warmUp: string;
  mainWorkout: string;
  recoveryGuidance: string;
  cooldown: string;
  completed: boolean;
  completedWorkoutId?: string;
  notes?: string;
}

export interface RecoveryCheckIn {
  id: string;
  date: string;
  sleepHours: number;
  sleepQuality: number; // 1-5
  energyLevel: number; // 1-5
  sorenessScore: number; // 0-10
  painAreas: string[];
  hasSharpPain: boolean;
  readyForHardWorkout: boolean;
  notes: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  isAudioPlaying?: boolean;
}
