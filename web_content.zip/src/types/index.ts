export type ProductCategory = 
  | 'all'
  | 'ebooks'
  | 'spreadsheets'
  | 'covers3d'
  | 'ads_banners'
  | 'courses_vsl'
  | 'physical';

export type ProductType = 'digital' | 'physical';

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number; // In MZN (MT)
  originalPrice?: number;
  category: ProductCategory;
  type: ProductType;
  stock: number;
  minStockAlert: number;
  sku: string;
  image: string;
  rating: number;
  ratingCount: number;
  salesCount: number;
  features: string[];
  digitalContentUrl?: string;
  badge?: string;
  weightOrFormat?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type PaymentMethod = 'mpesa' | 'emola' | 'card' | 'bank_reference';

export interface CustomerData {
  fullName: string;
  email: string;
  phone: string;
  whatsapp: string;
  address?: string;
  city?: string;
  notes?: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  type: ProductType;
  sku: string;
}

export interface Order {
  id: string;
  transactionRef: string;
  customer: CustomerData;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'paid' | 'processing' | 'failed';
  paymentDetails?: {
    phoneOrCard?: string;
    authCode?: string;
    operatorRef?: string;
  };
  deliveryStatus: 'delivered' | 'pending_shipping' | 'ready_download';
  createdAt: string;
}

export interface StockMovement {
  id: string;
  productId: string;
  productName: string;
  type: 'sale' | 'restock' | 'adjustment' | 'return';
  quantityChange: number;
  stockBefore: number;
  stockAfter: number;
  reason: string;
  timestamp: string;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  credits: number;
  bonusCredits: number;
  isPopular?: boolean;
  accentColor: string;
  features: string[];
}

export interface MerchantPayoutSettings {
  payoutMethod: 'mpesa' | 'emola' | 'bank';
  accountHolder: string;
  mpesaNumber: string;
  emolaNumber: string;
  bankName: string;
  accountNumber: string;
  nib: string;
  autoPayout: boolean;
  gatewayProvider: 'escalepay_direct' | 'mpesa_c2b' | 'simulated';
  apiKey: string;
}

export interface PayoutTransaction {
  id: string;
  amount: number;
  method: 'mpesa' | 'emola' | 'bank';
  destination: string;
  status: 'completed' | 'processing';
  reference: string;
  requestedAt: string;
}
