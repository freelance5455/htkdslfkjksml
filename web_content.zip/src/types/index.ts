export type NavTab = 'home' | 'tournaments' | 'match-room' | 'wallet' | 'player-profile' | 'auth';

export interface TournamentMatch {
  id: string;
  matchNumber: string;
  title: string;
  mode: 'solo' | 'squad';
  map: 'Bermuda' | 'Purgatory' | 'Kalahari';
  kickoffTime: string;
  kickoffSubtext: string;
  entryFee: number;
  bountyOrPrize: string;
  bountyDescription: string;
  registeredCount: number;
  totalCapacity: number;
  statusBadge: string;
  isHot?: boolean;
  image: string;
  imageAlt: string;
}

export interface LedgerItem {
  id: string;
  title: string;
  subtitle: string;
  amount: number;
  type: 'deposit' | 'entry' | 'bounty' | 'withdrawal';
  timestamp: string;
  status?: string;
  isPositive: boolean;
}

export interface PlayerRosterItem {
  slot: string;
  ign: string;
  uid: string;
  isUser?: boolean;
  bounty: string;
  kd: string;
  status: 'READY' | 'WAITING';
}

export interface ChatMessage {
  id: string;
  sender: string;
  text: string;
  isUser: boolean;
  role?: string;
}
