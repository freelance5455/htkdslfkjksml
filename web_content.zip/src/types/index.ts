export interface User {
  id: string;
  username: string;
  fullName: string;
  role: 'admin' | 'user';
  avatarUrl: string;
  status: 'active' | 'banned';
  verifiedBlueTick: boolean;
  isTemporaryPassword?: boolean;
  createdAt: string;
  lastLoginAt: string;
  bio: string;
  online: boolean;
  lastSeen: string;
  customStatus?: string;
  banInfo?: BanRecord;
}

export interface BanRecord {
  id: string;
  userId: string;
  username: string;
  bannedBy: string;
  banType: 'temporary' | 'permanent';
  durationDays?: number;
  expiresAt?: string;
  reason: string;
  createdAt: string;
  unbannedAt?: string;
}

export interface Chat {
  id: string;
  type: 'direct' | 'group';
  participants: string[];
  name?: string;
  avatar?: string;
  description?: string;
  adminIds?: string[];
  createdAt: string;
  updatedAt: string;
  lastMessage?: {
    id: string;
    text: string;
    senderId: string;
    senderName: string;
    createdAt: string;
    mediaType?: 'image' | 'file' | 'apk';
    fileName?: string;
    fileSize?: string;
  };
  unreadCounts: Record<string, number>;
  mutedBy?: string[];
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'file' | 'apk';
  fileName?: string;
  fileSize?: string;
  replyTo?: {
    id: string;
    text: string;
    senderName: string;
  };
  readBy: string[];
  deliveredTo: string[];
  deletedFor: string[];
  isDeletedForEveryone: boolean;
  createdAt: string;
}

export interface Report {
  id: string;
  reporterId: string;
  reporterUsername: string;
  reportedUserId: string;
  reportedUsername: string;
  messageId?: string;
  chatId?: string;
  reason: string;
  evidenceSnippet?: string;
  status: 'pending' | 'action_taken' | 'dismissed';
  createdAt: string;
  reviewedAt?: string;
  resolutionNote?: string;
}

export interface VerificationRecord {
  id: string;
  userId: string;
  username: string;
  grantedBy: string;
  grantedAt: string;
  revokedAt?: string;
  note?: string;
}

export interface AuditLog {
  id: string;
  action: string;
  targetUserId?: string;
  targetUsername?: string;
  details: string;
  timestamp: string;
  adminKeyUsed?: string;
}

export interface StatusStory {
  id: string;
  userId: string;
  username: string;
  userAvatar: string;
  fullName: string;
  caption: string;
  mediaUrl?: string;
  createdAt: string;
  expiresAt: string;
  viewers: string[];
}

export interface AppSettings {
  whatsappServiceNumber: string;
  whatsappUrl: string;
  appVersion: string;
  allowNewGroups: boolean;
  allowFileSharing: boolean;
  systemNotice?: string;
}

export interface AIAgentConfig {
  name: string;
  avatarUrl: string;
  systemPrompt: string;
  knowledgeBase: string;
  isActive: boolean;
  model: string;
  lastTrainedAt?: string;
  lastTrainedBy?: string;
}

