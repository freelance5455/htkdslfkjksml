export type Category = 'All' | 'Bedding & Linens' | 'Kitchen & Dining' | 'Fragrance & Oud' | 'Bath & Wellness' | 'Living & Storage';

export type Room = 'All' | 'Bedroom' | 'Kitchen' | 'Dining Room' | 'Living Room' | 'Bathroom';

export interface Product {
  id: string;
  name: string;
  arabicSubtitle?: string;
  category: Category;
  room: Room;
  priceUsd: number;
  originalPriceUsd?: number;
  rating: number;
  reviewsCount: number;
  image: string;
  description: string;
  materials: string;
  dimensions: string;
  inStock: boolean;
  stockCount: number;
  careInstructions: string;
  features: string[];
  badge?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
}

export interface Review {
  id: string;
  productId: string;
  author: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
  verifiedPurchase: boolean;
}

export interface CustomerProfile {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
  postalCode: string;
  notes?: string;
}

export interface Order {
  id: string;
  date: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  currency: string;
  customer: CustomerProfile;
  paymentMethod: 'Cash on Delivery (COD)' | 'Direct Bank Transfer' | 'Card Payment (Simulated)';
  status: 'Confirmed' | 'Preparing' | 'Shipped' | 'Delivered';
  trackingNumber: string;
}

export interface RoomChecklistItem {
  id: string;
  room: Room;
  name: string;
  checked: boolean;
  estimatedCostUsd: number;
  productId?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'customer';
  joinedDate?: string;
}

export type CurrencyCode = 'USD' | 'PKR' | 'AED' | 'GBP' | 'EUR';

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  rate: number; // against 1 USD
  name: string;
}

