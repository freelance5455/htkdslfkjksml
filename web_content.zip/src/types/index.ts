export interface Founder {
  id?: string;
  name: string;
  role: string;
  bio: string;
  skills: string;
  avatar: string;
  socialLinks?: {
    twitter?: string;
    github?: string;
    discord?: string;
    linkedin?: string;
    email?: string;
  };
  displayOrder?: number;
  published?: boolean;
}

export interface Project {
  id: number | string;
  name: string;
  description: string;
  category: 'web' | 'design' | 'minecraft' | 'discord' | string;
  thumbnail?: string;
  tags?: string[];
  fileName?: string;
  fileData?: string;
  fileUrl?: string;
  externalUrl?: string;
  date?: string;
  published?: boolean;
  galleryImages?: string[];
  order?: number;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'web' | 'design' | 'minecraft' | 'discord' | 'branding' | string;
  imageUrl: string;
  caption?: string;
  projectId?: string | number;
  externalUrl?: string;
  displayOrder?: number;
  published?: boolean;
  createdAt?: string;
}

export interface UserAccount {
  id: string;
  email: string;
  username?: string;
  name: string;
  role: 'admin' | 'founder';
  status: 'active' | 'inactive';
  createdAt: string;
  lastLogin?: string;
  founderId?: string;
}

export interface FinancialRecord {
  id: string;
  date: string;
  description: string;
  category?: string;
  amount: number;
  type: 'gain' | 'loss';
}

export interface ProjectSubmission {
  id: string;
  submissionId: string;
  name: string;
  email: string;
  discord?: string;
  projectType: string; // Free-text input
  budget?: string;
  timeline?: string;
  description: string;
  referenceLinks?: string;
  createdAt: string;
  status: 'New' | 'In Progress' | 'Completed' | 'Archived';
  internalNotes?: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  createdAt: string;
  status: 'New' | 'Read';
}

export interface ReputationItem {
  tabKey: 'stats' | 'works' | 'trust' | 'rating' | string;
  title: string;
  badge: string;
  highlight: string; // The single main focal point
  description: string;
  detail?: string;
  command?: string;
  metrics?: [string, string][];
}

export interface ReputationData {
  stats: ReputationItem;
  works: ReputationItem;
  trust: ReputationItem;
  rating: ReputationItem;
  [key: string]: ReputationItem;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export interface AboutCard {
  title: string;
  description: string;
}

export interface ServiceProductItem {
  id: string;
  name: string;
  category: 'discord' | 'web' | 'coding' | 'bot' | 'digital-product' | 'design' | 'custom' | string;
  type: 'service' | 'product';
  description: string;
  badge?: string;
  points?: string[];
  price?: string;
  available: boolean;
  showInSelectionMenu: boolean;
  displayOrder: number;
  iconName?: string;
  downloadUrl?: string;
  createdAt: string;
  updatedAt?: string;
}

export type TicketStatus =
  | 'Pending'
  | 'In Progress'
  | 'Resolved'
  | 'Open'
  | 'Waiting for Client'
  | 'Completed'
  | 'Closed';

export interface TicketAttachment {
  id: string;
  name: string;
  url: string;
  size: number;
  mimeType: string;
  uploadedAt: string;
}

export interface TicketMessage {
  id: string;
  sender: 'client' | 'admin';
  senderName: string;
  message: string;
  attachments?: TicketAttachment[];
  createdAt: string;
}

export interface TicketStatusLog {
  status: TicketStatus;
  changedBy: string;
  changedAt: string;
  note?: string;
}

export interface SupportTicket {
  id: string;
  ticketNumber: string; // e.g. "CUBIX-0001"
  cubesId?: string; // e.g. "Cubes-1", "Cubes-2"
  clientToken: string; // Secure token issued to client
  verificationPin?: string;
  email: string;
  username: string;
  discordId: string;
  serviceProductId?: string;
  serviceProductName: string;
  requestDetails: string;
  attachments: TicketAttachment[];
  status: TicketStatus;
  internalNotes?: string; // Private internal notes, visible only to admins
  conversation: TicketMessage[];
  createdAt: string;
  updatedAt: string;
  statusHistory: TicketStatusLog[];
  emailNotificationStatus?: {
    lastSentAt?: string;
    creationEmailSent: boolean;
    lastStatusEmailSent?: string;
    error?: string;
  };
}

export interface TicketStats {
  total: number;
  open: number;
  inProgress: number;
  waitingForClient: number;
  completed: number;
  closed: number;
  monthlyTrends?: { month: string; count: number }[];
}

export interface AiChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  role?: 'user' | 'assistant';
  content?: string;
  createdAt: string;
}

export interface AiClientSession {
  cubesId: string; // e.g. "Cubes-1", "Cubes-2"
  clientNumber?: number; // 1, 2, 3...
  messages: AiChatMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface AiAssistantSettings {
  enabled: boolean;
  assistantName?: string;
  sectionTitle?: string;
  sectionDescription?: string;
  buttonText?: string;
  sectionHeading?: string;
  sectionSubtitle?: string;
  welcomeMessage: string;
  systemPrompt?: string;
  systemInstructions?: string;
  quickPrompts?: string[];
}

export interface ServiceItem {
  id: string;
  name: string;
  category: string;
  iconName?: string;
  description?: string;
  points: string[];
  displayOrder?: number;
  published?: boolean;
}

export interface SectionVisibility {
  hero?: boolean;
  reputation?: boolean;
  aiAssistant?: boolean;
  about?: boolean;
  services?: boolean;
  faq?: boolean;
  contact?: boolean;
  gallery?: boolean;
}

export interface SiteSettings {
  siteTitle: string;
  heroHeadline: string;
  heroDescription: string;
  heroSubtitle?: string;
  heroBadge?: string;
  heroPrimaryBtnText?: string;
  heroSecondaryBtnText?: string;
  aboutHeading: string;
  aboutStatement: string;
  aboutDescription: string;
  aboutCards: {
    mission: string;
    approach: string;
    whatWeBuild: string;
  };
  servicesEyebrow: string;
  servicesHeading: string;
  servicesDescription: string;
  contactEmail: string;
  contactDescription: string;
  discordUrl: string;
  ticketDiscordUrl?: string; // Discord voice channel or ticket link configured by administrator
  logoUrl: string;
  location: string;
  sectionVisibility?: SectionVisibility;
  // Custom Homepage Background Settings (Hero to Separator above About Cubix Studio)
  heroBackground?: {
    imageUrl?: string;
    position?: 'center' | 'top' | 'bottom' | string; // 'center', 'top', 'bottom'
    size?: string; // 'cover', 'contain', 'auto'
    repeat?: string; // 'no-repeat', 'repeat'
    blur?: number; // 0 to 40 px (applied only to background image layer)
    overlayOpacity?: number; // 0 to 100 percentage
    solidColor?: string; // Hex / rgb e.g. '#06101e' or '#030712'
  };
}

export type VouchStatus = 'pending' | 'approved' | 'rejected';

export interface VouchItem {
  id: string;
  name: string;
  discordUsername: string;
  productOrService: string;
  feedback: string;
  rating: number; // 1 to 5
  status: VouchStatus;
  isVerified: boolean;
  createdAt: string;
  approvedAt?: string | null;
  updatedAt: string;
}

export interface VouchStats {
  totalVouches: number;
  averageRating: number;
  formattedRating: string; // e.g. "4.8/5" or "0.0/5"
}

export interface AppData {
  founders: Founder[];
  projects: Project[];
  services?: ServiceItem[];
  serviceProducts?: ServiceProductItem[];
  supportTickets?: SupportTicket[];
  vouches?: VouchItem[];
  gallery?: GalleryItem[];
  financialRecords: FinancialRecord[];
  submissions: ProjectSubmission[];
  faqs: FaqItem[];
  settings: SiteSettings;
  reputationData: ReputationData;
  aiAssistant?: AiAssistantSettings;
  accounts?: UserAccount[];
  lastUpdated?: string;
}


