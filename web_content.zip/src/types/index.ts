export type DocumentTemplateId = 'academic' | 'business' | 'report' | 'letter' | 'notes' | 'general';

export type PageSize = 'A4' | 'Letter' | 'Legal';
export type PageOrientation = 'portrait' | 'landscape';
export type TextAlignment = 'left' | 'center' | 'right' | 'justify';

export interface PageMargins {
  top: number; // inches
  bottom: number;
  left: number;
  right: number;
}

export interface DocumentStyleSettings {
  title: string;
  templateId: DocumentTemplateId;
  fontFamily: string;
  headingFont: string;
  bodySize: number; // pt
  headingSize: number; // pt
  lineSpacing: number; // multiplier e.g. 1.15, 1.5, 2.0
  paragraphSpacing: number; // pt
  indentFirstLine: boolean;
  alignment: TextAlignment;
  pageSize: PageSize;
  orientation: PageOrientation;
  margins: PageMargins;
  includePageNumbers: boolean;
  pageNumberPosition: 'bottom-center' | 'bottom-right' | 'top-right';
  headerText: string;
  footerText: string;
  accentColor: string;
}

export interface DocumentSection {
  id: string;
  type: 'heading' | 'subheading' | 'paragraph' | 'bullet_list' | 'numbered_list' | 'quote' | 'table' | 'page_break';
  content: string; // for table: comma or pipe separated lines
  level?: number;
}

export interface StoredDocument {
  id: string;
  name: string;
  type: 'docx' | 'pdf' | 'txt' | 'png' | 'jpg';
  sizeBytes: number;
  createdAt: number;
  updatedAt: number;
  dataUrl?: string; // base64 or blob URL
  blobData?: Blob;
  previewUrl?: string;
  pageCount?: number;
  isFavorite?: boolean;
  tags?: string[];
  sourceFeature: string;
}

export interface OcrResultItem {
  id: string;
  imageName: string;
  imageDataUrl: string;
  extractedText: string;
  confidence: number;
  status: 'pending' | 'processing' | 'completed' | 'error';
  errorMessage?: string;
  language: string;
  detectedBlocks?: {
    text: string;
    type: 'paragraph' | 'heading' | 'table';
  }[];
}

export interface MergeFileItem {
  id: string;
  name: string;
  file: File;
  type: 'docx' | 'pdf';
  sizeBytes: number;
  pageCount?: number;
  previewUrl?: string;
  convertedText?: string;
}

export type MergeMode = 'editable' | 'visual_fidelity';
export type MergeOutputFormat = 'pdf' | 'docx';

export interface AiFormattingRecommendation {
  fontFamily: string;
  headingFont: string;
  bodySize: number;
  headingSize: number;
  lineSpacing: number;
  paragraphSpacing: number;
  margins: PageMargins;
  align: TextAlignment;
  indentFirstLine: boolean;
  accentColor: string;
  rationale: string;
}

export interface AiAnalysisResult {
  recommendations: AiFormattingRecommendation;
  structure: Array<{
    type: 'heading' | 'subheading' | 'paragraph' | 'list_item' | 'quote' | 'table' | 'reference';
    content: string;
    suggestedLevel?: number;
  }>;
  detectedElements: {
    headingsCount: number;
    paragraphsCount: number;
    listItemsCount: number;
    tablesCount: number;
    quotesCount: number;
    referencesCount: number;
  };
  observations: string[];
  source?: string;
  message?: string;
}

export interface AppThemeSettings {
  isDark: boolean;
  primaryColor: string; // Material You dynamic accent
  deviceMode: 'phone' | 'full'; // Pixel 8 Frame vs Adaptive Studio
  soundFeedback: boolean;
}
