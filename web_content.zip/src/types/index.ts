/**
 * TAKI-GO – Tourism By Taki
 * Core Domain Types & Models
 */

export type Language = 'ar' | 'fr' | 'en';
export type Currency = 'DZD' | 'EUR' | 'USD';

export type UserRole = 'client' | 'agency_admin' | 'agency_agent';

export interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  passportNumber?: string;
  nationality: string;
  avatarUrl: string;
  role: UserRole;
  language: Language;
  currency: Currency;
  isLoggedIn: boolean;
}

export interface FlightOffer {
  id: string;
  airline: string;
  airlineLogo: string;
  flightNumber: string;
  fromCode: string;
  fromCity: string;
  fromAirport: string;
  toCode: string;
  toCity: string;
  toAirport: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  stops: number; // 0 = Direct, 1 = 1 Stop
  stopAirport?: string;
  baggage: string;
  basePriceDZD: number;
  cabinClass: 'economy' | 'premium' | 'business' | 'first';
  refundable: boolean;
  availableSeats: number;
}

export interface HotelRoom {
  id: string;
  name: string;
  bedType: string;
  maxGuests: number;
  pricePerNightDZD: number;
  freeCancellation: boolean;
}

export interface HotelOffer {
  id: string;
  name: string;
  city: string;
  country: string;
  stars: number;
  rating: number;
  reviewCount: number;
  pricePerNightDZD: number;
  imageUrl: string;
  amenities: string[];
  distanceToCenter: string;
  address: string;
  rooms: HotelRoom[];
}

export interface VisaCountry {
  id: string;
  countryName: {
    ar: string;
    fr: string;
    en: string;
  };
  flagEmoji: string;
  visaType: string; // e.g., "e-Visa الإلكترونية", "Schengen السياحية"
  processingTime: string;
  feeDZD: number;
  feeEUR: number;
  requirements: string[];
  steps: string[];
  guaranteeRate: string;
  status: 'available' | 'high_demand' | 'easy_approval';
}

export interface TravelTrip {
  id: string;
  destinationCity: string;
  destinationCountry: string;
  startDate: string;
  endDate: string;
  status: 'upcoming' | 'in_progress' | 'completed' | 'cancelled';
  flightInfo: {
    airline: string;
    flightNumber: string;
    departureTime: string;
    origin: string;
    destination: string;
    terminal: string;
    gate: string;
    seat: string;
    boardingGroup: string;
    guardianStatus: 'on_time' | 'delayed' | 'boarding_soon' | 'gate_changed';
    statusNote: string;
  };
  hotelInfo: {
    name: string;
    address: string;
    checkIn: string;
    checkOut: string;
    roomType: string;
  };
  timeline: Array<{
    day: number;
    title: string;
    time: string;
    description: string;
    type: 'flight' | 'transfer' | 'hotel' | 'activity' | 'free_time';
  }>;
  weather: {
    temperatureC: number;
    condition: string;
    icon: string;
  };
  voucherCode: string;
}

export interface WalletDocument {
  id: string;
  title: string;
  category: 'ticket' | 'boarding_pass' | 'hotel_voucher' | 'insurance' | 'visa' | 'devis';
  documentNumber: string;
  passengerName: string;
  issueDate: string;
  expiryDate?: string;
  qrCodeData: string;
  offlineReady: boolean;
  fileSize: string;
}

export interface DevisItem {
  id: string;
  description: string;
  category: 'flight' | 'hotel' | 'transfer' | 'visa' | 'insurance' | 'activity' | 'service';
  unitPriceDZD: number;
  quantity: number;
}

export interface Devis {
  id: string;
  devisNumber: string; // e.g., "DEV-2026-0042"
  clientName: string;
  clientPhone: string;
  clientEmail: string;
  destination: string;
  travelDates: string;
  items: DevisItem[];
  subtotalDZD: number;
  agencyFeeDZD: number;
  taxRatePercent: number; // e.g. 9%
  totalDZD: number;
  status: 'draft' | 'sent' | 'approved' | 'rejected';
  createdAt: string;
  validUntil: string;
  notes: string;
  agencyNotes: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  category: 'booking' | 'flight_alert' | 'visa' | 'document' | 'promo' | 'message';
  timestamp: string;
  isRead: boolean;
  actionRoute?: string;
}

export interface AgencyClient {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  passportNumber: string;
  city: string;
  totalTrips: number;
  activeTripId?: string;
  pendingVisa?: string;
  vip: boolean;
  notes: string;
  registeredDate: string;
}
