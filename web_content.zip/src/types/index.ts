export interface Mailbox {
  id: string;
  address: string;
  username: string;
  domain: string;
  lifetimeTier: '10m' | '1h' | '24h' | '7d';
  expiresAt: string; // ISO string
  createdAt: string;
  isCustom: boolean;
  unreadCount: number;
}

export interface EmailAttachment {
  id: string;
  filename: string;
  contentType: string;
  sizeBytes: number;
  downloadUrl: string;
}

export interface EmailMessage {
  id: string;
  mailboxId: string;
  fromAddress: string;
  fromName: string;
  toAddress: string;
  subject: string;
  textPreview: string;
  htmlBody: string;
  plainText: string;
  extractedOtp: string | null;
  verificationUrl: string | null;
  isRead: boolean;
  isSpam: boolean;
  hasTrackers: boolean;
  sizeBytes: number;
  receivedAt: string;
  attachments: EmailAttachment[];
}

export interface PhoneNumber {
  id: string;
  number: string;
  countryCode: string;
  countryName: string;
  flag: string;
  provider: 'twilio' | 'telnyx' | 'mock';
  status: 'ACTIVE' | 'EXPIRING_SOON' | 'RELEASED';
  rentedAt: string;
  expiresAt: string;
  creditsCost: number;
  receivedSmsQty: number;
  refundIssued: boolean;
  carrier?: string;
}

export interface SmsMessage {
  id: string;
  phoneNumberId: string;
  fromNumber: string;
  senderName?: string;
  text: string;
  extractedOtp: string | null;
  receivedAt: string;
}

export interface CreditTransaction {
  id: string;
  amount: number;
  type: 'PURCHASE' | 'RENT_NUMBER' | 'EXTEND_NUMBER' | 'AUTO_REFUND' | 'BONUS';
  description: string;
  createdAt: string;
}

export interface AbuseReport {
  id: string;
  userId?: string;
  userEmail?: string;
  itemType: 'MESSAGE' | 'NUMBER' | 'EMAIL';
  itemId: string;
  reason: string;
  details: string;
  resolved: boolean;
  createdAt: string;
}

export interface UserAccount {
  id: string;
  email: string | null;
  role: 'USER' | 'PREMIUM' | 'ADMIN';
  isGuest: boolean;
  credits: number;
  isBanned: boolean;
  deviceId: string;
}

export interface UserSessionLog {
  id: string;
  deviceId: string;
  userName: string;
  country: string;
  flag: string;
  ip: string;
  currentTab: 'email' | 'numbers' | 'settings';
  activeMailbox?: string;
  activeNumber?: string;
  status: 'ONLINE' | 'IDLE' | 'DEPARTED';
  joinedAt: string;
  lastPingAt: string;
  departedAt?: string;
  durationMinutes: number;
  exitReason?: string;
}
