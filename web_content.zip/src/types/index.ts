export type ServiceType = 'CABLE' | 'BROADBAND' | 'COMBO';
export type CustomerStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED';
export type PaymentStatus = 'PAID' | 'UNPAID' | 'PARTIAL';
export type PaymentMethod = 'CASH' | 'UPI';
export type Language = 'en' | 'or' | 'hi';

export interface Customer {
  id: string;
  customerCode: string; // e.g., CNC-1001
  name: string;
  mobile: string;
  address: string;
  area: string;
  serviceType: ServiceType;
  planName: string;
  monthlyAmount: number;
  setupBoxNo?: string;
  ipOrMacAddress?: string;
  status: CustomerStatus;
  connectionDate: string; // YYYY-MM-DD
  previousDues: number;
  currentDues: number;
  totalOutstanding: number;
  notes?: string;
  lastWhatsAppNoticeSentAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Bill {
  id: string;
  billNumber: string; // e.g., BILL-202611-1001
  customerId: string;
  customerCode: string;
  customerName: string;
  mobile: string;
  area: string;
  serviceType: ServiceType;
  billingMonth: string; // YYYY-MM (e.g. "2026-11")
  planAmount: number;
  previousDues: number;
  totalAmount: number; // planAmount + previousDues
  paidAmount: number;
  balanceDue: number; // totalAmount - paidAmount
  status: PaymentStatus;
  generatedAt: string;
  dueDate: string;
}

export interface Payment {
  id: string;
  receiptNo: string; // e.g., RCP-2026-1008
  billId?: string;
  customerId: string;
  customerCode: string;
  customerName: string;
  mobile: string;
  amount: number;
  paymentMethod: PaymentMethod;
  upiRefNo?: string;
  paymentDate: string; // YYYY-MM-DD
  billingMonth: string; // YYYY-MM
  collectedBy: string;
  notes?: string;
  createdAt: string;
}

export interface BusinessProfile {
  name: string;
  tagline: string;
  ownerName: string;
  phone: string;
  alternatePhone?: string;
  email?: string;
  address: string;
  village: string;
  district: string;
  pincode: string;
  upiId: string;
  upiPayeeName: string;
  gstin?: string;
  receiptFooterText: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConnected: boolean;
  lastSyncedAt?: string;
  autoSync: boolean;
}

export interface ImportPreviewRow {
  rowNumber: number;
  customerCode: string;
  name: string;
  mobile: string;
  address: string;
  area: string;
  serviceType: ServiceType;
  planName: string;
  monthlyAmount: number;
  previousDues: number;
  status: CustomerStatus;
  isDuplicate: boolean;
  duplicateReason?: string;
  isValid: boolean;
  errors: string[];
}
