export interface Product {
  id: string;
  name: string;
  category: 'Men' | 'Women' | 'Kids' | 'Bags' | 'Watches' | 'Accessories' | 'Electronics' | 'Footwear' | 'Fashion' | 'Mobile' | 'Appliances' | 'Home' | 'Beauty' | 'Sports' | 'Grocery' | 'Travel' | string;
  subcategory: string;
  brand: string;
  description: string;
  images: string[];
  price: number;
  originalPrice: number;
  discount: number; // percentage
  rating: number;
  reviewsCount: number;
  stock: number;
  sizes?: string[];
  colors?: { name: string; hex: string }[];
  specifications: Record<string, string>;
  countryOfOrigin?: string; // Mandatory under Legal Metrology & DPIIT Rules
  manufacturer?: string;
  packerDetails?: string;
  netQuantity?: string;
  isFeatured?: boolean;
  isBestseller?: boolean;
  keywords?: string[];
  gender?: 'Men' | 'Women' | 'Kids' | 'Unisex';
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export interface Category {
  id: string;
  name: string;
  subtitle: string;
  image: string;
  tag: string;
}

export interface OrderDetails {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  paymentMethod: 'cod'; // Exclusively Cash on Delivery
  items: CartItem[];
  subtotal: number;
  discount: number;
  deliveryFee: number;
  total: number;
  orderId?: string;
}

export interface TrackingEvent {
  id: string;
  eventType: string;
  status: string;
  message: string;
  location?: string;
  timestamp: string;
  courierName?: string;
  awbNumber?: string;
}

export type OrderStatusType =
  | 'PENDING'
  | 'CONFIRMED'
  | 'PROCESSING'
  | 'PACKED'
  | 'READY_FOR_PICKUP'
  | 'PICKED_UP'
  | 'SHIPPED'
  | 'IN_TRANSIT'
  | 'OUT_FOR_DELIVERY'
  | 'DELIVERED'
  | 'CANCELLED'
  | 'RETURN_REQUESTED'
  | 'RETURN_APPROVED'
  | 'RETURN_PICKED_UP'
  | 'RETURNED'
  | 'REFUNDED';

export interface ReturnExchangeDetails {
  id: string;
  type: 'return' | 'exchange';
  reason: string;
  comments?: string;
  exchangeSize?: string;
  exchangeColor?: string;
  status:
    | 'REQUESTED'
    | 'APPROVED'
    | 'PICKUP_SCHEDULED'
    | 'PICKED_UP'
    | 'IN_TRANSIT'
    | 'QC_PASSED'
    | 'REFUND_INITIATED'
    | 'COMPLETED'
    | 'REJECTED';
  pickupAddress: {
    fullName: string;
    phone: string;
    street: string;
    city: string;
    state: string;
    pincode: string;
  };
  courierPartner?: string;
  awbNumber?: string;
  requestedAt: string;
  updatedAt: string;
}

export interface NotificationItem {
  id: string;
  userId?: string;
  orderId?: string;
  title: string;
  message: string;
  type: string;
  channel: 'in_app' | 'email' | 'sms' | 'whatsapp' | 'push';
  read: boolean;
  createdAt: string;
}

export type { Order } from '../context/AuthContext';
