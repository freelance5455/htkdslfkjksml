export type ExerciseCategory = 'pull' | 'push' | 'core' | 'legs' | 'backpack' | 'resistance band' | 'towel';

export type DifficultyLevel = 'beginner' | 'intermediate' | 'advanced';

export type EquipmentType = 'none' | 'pull-up bar' | 'parallettes' | 'dip bars' | 'backpack' | 'resistance band' | 'towel';

export type SetType =
  | 'normal'
  | 'warmup'
  | 'dropset'
  | 'superset'
  | 'restpause'
  | 'amrap'
  | 'tempo'
  | 'cluster';

export type TimerChimeStyle = 'singing-bowl' | 'double-pulse' | 'power-chord' | 'crisptick' | 'silent';
export type TimerHapticStyle = 'subtle-pulse' | 'double-tap' | 'heartbeat' | 'off';

export interface Exercise {
  id: string;
  name: string;
  category: ExerciseCategory;
  difficulty: DifficultyLevel;
  equipment: EquipmentType;
  description: string;
  instructions: string[];
  progressionLevel?: number;
  isHold?: boolean; // Static hold (seconds) vs dynamic reps
  defaultReps?: number;
  defaultHoldSec?: number;
  targetMuscles: string[];
  safetyNote?: string;
}

export type SetTrackingMode = 'reps' | 'time' | 'weight';

export interface WorkoutSet {
  id: string;
  setNumber: number;
  setType?: SetType;
  trackingMode?: SetTrackingMode;
  reps?: number;
  durationSec?: number;
  weightKg?: number; // 0 for pure bodyweight, or +kg (e.g., backpack weight)
  completed: boolean;
  targetReps?: number;
  targetHoldSec?: number;
  targetWeightKg?: number;
}

export interface WorkoutExercise {
  exerciseId: string;
  sets: WorkoutSet[];
  notes?: string;
  restTimeSec?: number;
  supersetWithNext?: boolean;
}

export interface Workout {
  id: string;
  name: string;
  date: string; // ISO string
  durationSec: number;
  exercises: WorkoutExercise[];
  totalSets: number;
  totalReps: number;
  notes?: string;
  prsEarned?: string[];
  prDetails?: PersonalRecord[];
  difficultyTier?: DifficultyLevel;
}

export interface CustomRoutineExercise {
  exerciseId: string;
  setsCount: number;
  defaultReps?: number;
  defaultHoldSec?: number;
  targetWeightKg?: number;
  restTimeSec: number;
  defaultSetType?: SetType;
  supersetWithNext?: boolean;
}

export interface CustomRoutine {
  id: string;
  name: string;
  description: string;
  exercises: CustomRoutineExercise[];
  estimatedDurationMin: number;
  isCustom?: boolean;
}

export interface SkillLevel {
  level: number;
  name: string;
  description: string;
  targetHoldSec: number;
  trainingExercises: string[];
  formCues: string[];
}

export interface Skill {
  id: string;
  name: string;
  subtitle: string;
  category: 'core' | 'push' | 'pull';
  currentLevel: number; // 1 to 5
  maxLevel: number;
  currentHoldSec: number;
  prHoldSec: number;
  levels: SkillLevel[];
  imagePath?: string;
}

export interface PersonalRecord {
  id: string;
  exerciseId: string;
  exerciseName: string;
  value: number;
  unit: 'reps' | 'seconds' | 'kg' | 'lbs';
  date: string;
  previousValue?: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'consistency' | 'strength' | 'skill' | 'builder';
  unlockedAt?: string;
  progress: number;
  maxProgress: number;
}

export interface UserProfile {
  id: string;
  name: string;
  athleteTitle?: string;
  bio: string;
  profileImage: string;
  createdAt: string;
  streak: number;
  totalWorkouts: number;
  totalTrainingTimeSec: number;
  totalReps: number;
  weeklyGoal: number; // e.g. 4 workouts per week
  units: 'metric' | 'imperial';
  defaultRestTimeSec: number;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  timerChimeStyle?: TimerChimeStyle;
  timerHapticStyle?: TimerHapticStyle;
  theme?: 'dark' | 'light';
}

export type HabitIconName = 'droplets' | 'stretch' | 'protein' | 'hang' | 'sleep' | 'target';

export interface DailyHabit {
  id: string;
  title: string;
  subtitle: string;
  icon: HabitIconName;
  completedDates: string[]; // Array of YYYY-MM-DD strings
  isCustom?: boolean;
}

