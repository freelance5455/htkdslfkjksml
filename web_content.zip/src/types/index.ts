export type AssistantState = 
  | 'idle' 
  | 'listening' 
  | 'thinking' 
  | 'processing' 
  | 'speaking' 
  | 'scanning' 
  | 'authenticating' 
  | 'interrupted' 
  | 'error' 
  | 'alarm';

export interface PendingTask {
  id: string;
  command: string;
  status: 'paused' | 'executing' | 'completed' | 'cancelled';
  timestamp: number;
  partialResponse?: string;
}

export interface NearbyPlace {
  id: string;
  name: string;
  category: string;
  address: string;
  distanceMeters: number;
  lat: number;
  lon: number;
  mapsUrl: string;
  isOpen?: boolean;
  liveTrafficNote?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'jarvis';
  text: string;
  timestamp: number;
  sources?: Array<{ title: string; uri: string }>;
  isCached?: boolean;
  isLocalAction?: boolean;
  blueprint?: BlueprintData;
  languageDetected?: 'en' | 'hi' | 'pa' | 'mixed';
}

export interface Contact {
  id: string;
  name: string;
  phone: string;
  relationship?: string;
}

export interface Alarm {
  id: string;
  time: string; // HH:mm format (24-hour)
  label: string;
  enabled: boolean;
  days: number[]; // 0-6 (0=Sun)
}

export interface BatteryStatus {
  supported: boolean;
  level: number; // 0 to 100
  charging: boolean;
  chargingTime: number; // in seconds
  dischargingTime: number;
}

export interface MemoryItem {
  id: string;
  key: string;
  value: string;
  createdAt: number;
}

export interface WeatherData {
  location: string;
  temperature: number;
  apparentTemperature?: number;
  humidity?: number;
  windSpeed?: number;
  isDay?: boolean;
  condition: string;
  tempMax?: number;
  tempMin?: number;
  sunrise?: string;
  sunset?: string;
  sunrise12?: string;
  sunset12?: string;
  timezone?: string;
}

export interface DiagnosticItem {
  name: string;
  status: 'operational' | 'warning' | 'error' | 'unsupported';
  message: string;
  details?: string;
}

export interface SecurityScanResult {
  url: string;
  hostname: string;
  isHttps: boolean;
  riskScore: number;
  status: 'SAFE' | 'CAUTION' | 'DANGEROUS';
  reasons: string[];
  verdict: string;
}

// Blueprint Vision Types
export interface BlueprintComponent {
  id: string;
  label: string;
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  system: string;
  desc: string;
}

export interface BlueprintSubsystem {
  name: string;
  status: string;
  description: string;
  importance?: 'High' | 'Medium' | 'Low';
}

export interface EngineSpecs {
  isVehicleOrEngine: boolean;
  displacement?: string;
  cylinderConfig?: string;
  coolingSystem?: string;
  transmissionPairing?: string;
  estimatedOutput?: string;
}

export interface BlueprintWireframeShape {
  type: 'rect' | 'circle' | 'line' | 'polygon';
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  r?: number;
  x1?: number;
  y1?: number;
  x2?: number;
  y2?: number;
  stroke: string;
  label?: string;
}

export interface BlueprintWireframe {
  schematicType: string;
  primaryDimensions: string;
  isometricAngle: string;
  schematicSummary: string;
  wireframeShapes?: BlueprintWireframeShape[];
}

export interface BlueprintData {
  objectName: string;
  category: string;
  brandModel: string;
  confidenceScore: number;
  confidenceNotes: string;
  dimensionsEstimate?: string;
  engineSpecs?: EngineSpecs;
  subsystems: BlueprintSubsystem[];
  components: BlueprintComponent[];
  blueprintWireframe: BlueprintWireframe;
  explanation: string;
  hindiExplanation?: string;
  punjabiExplanation?: string;
}
