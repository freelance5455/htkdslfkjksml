export type Language = 'english' | 'turkish';
export type Currency = 'TL' | 'USD';

export type DayOfWeek =
  | 'Pazartesi'
  | 'Salı'
  | 'Çarşamba'
  | 'Perşembe'
  | 'Cuma'
  | 'Cumartesi'
  | 'Pazar';

export interface ScheduleSlot {
  day: DayOfWeek;
  time: string; // "14:00"
  durationMinutes: number; // e.g. 60
}

export interface Student {
  id: string;
  name: string;
  phone: string;
  email?: string;
  subject: Language;
  hourlyRate: number; // e.g. 750 or 40
  currency: Currency; // 'TL' | 'USD'
  paymentFrequency: number; // Kaçıncı derste ödeme alınacak? (Örn: 4 derste bir, 1 derste bir)
  completedLessonsCount: number; // Toplam tamamlanan ders adedi
  lessonsInCurrentCycle: number; // Mevcut ödeme döngüsündeki ders sayısı (örn: 3/4)
  schedule: ScheduleSlot[];
  notes: string;
  status: 'active' | 'paused';
  createdAt: string;
}

export interface Lesson {
  id: string;
  studentId: string;
  studentName: string;
  subject: Language;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  durationMinutes: number;
  status: 'scheduled' | 'completed' | 'cancelled';
  isPaymentLesson: boolean; // Bu ders ödeme alınacak ders mi? (örn: 4. ders)
  paymentStatus: 'paid' | 'unpaid';
  rate: number;
  currency: Currency;
  cycleNumber: number; // Döngüdeki ders sırası (Örn: 4/4)
  topicNotes?: string;
  homework?: string;
}

export interface PaymentRecord {
  id: string;
  studentId: string;
  studentName: string;
  amount: number;
  currency: Currency;
  date: string; // ISO
  lessonsCovered: number;
  cycleDescription: string;
  paymentMethod: 'Nakit' | 'Banka Havalesi / EFT' | 'Kredi Kartı' | 'Diğer';
  note?: string;
}

export interface NoteEntry {
  id: string;
  studentId: string;
  studentName: string;
  title: string;
  content: string;
  category: 'Ders Notu' | 'Ödev & Görev' | 'Kelime Listesi' | 'Genel Değerlendirme';
  date: string;
}

export interface SystemAlert {
  id: string;
  type: 'payment_due' | 'lesson_soon' | 'overdue_unpaid' | 'info';
  title: string;
  message: string;
  studentId?: string;
  lessonId?: string;
  timestamp: string;
  amount?: number;
  currency?: Currency;
  isDismissed?: boolean;
}
