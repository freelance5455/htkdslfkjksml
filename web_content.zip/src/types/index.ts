export type MapName = 'Bermuda' | 'Purgatory' | 'Kalahari' | 'Alpine' | 'Nexterra';
export type GameMode = 'Battle Royale' | 'Clash Squad (4v4)' | 'Lone Wolf (1v1)';
export type PlayerRole = 'IGL' | 'Rusher' | 'Sniper' | 'Flanker' | 'Support';
export type RankTier = 'Grandmaster' | 'Master' | 'Elite Master' | 'Heroic' | 'Diamond';

export interface TeamScore {
  id: string;
  teamName: string;
  tag: string;
  kills: number;
  placementRank: number; // 1 to 12
  booyah: boolean;
  placementPoints: number;
  killPoints: number;
  totalPoints: number;
  players?: string[];
}

export interface MatchRoom {
  roomId: string;
  roomPass: string;
  map: MapName;
  mode: GameMode;
  matchNumber: number;
  roomType: 'Tournament Final' | 'Daily Scrims' | 'Guild War' | 'Custom Room';
  limitedAmmo: boolean;
  fallDamage: boolean;
  airDrop: boolean;
  defaultHp: number;
  ep: number;
  movementSpeed: number;
  notes: string;
}

export interface Player {
  id: string;
  ign: string;
  uid: string;
  role: PlayerRole;
  rank: RankTier;
  headshotRate: number; // percentage, e.g. 68.5%
  kd: number;
  favoriteGun: string;
  device: string;
  status: 'Active' | 'Sub' | 'Trial';
}

export interface DeviceSensPreset {
  id: string;
  category: 'iPhone / iOS' | 'Flagship Android' | 'Mid-Range Android' | 'Budget 90Hz' | 'PC / Emulator';
  deviceName: string;
  general: number;
  redDot: number;
  scope2x: number;
  scope4x: number;
  sniperScope: number;
  freeLook: number;
  recommendedDpi: number;
  fireButtonSize: number; // e.g., 48%
  pointerSpeed: string;
  dragTechnique: 'J-Shape Drag' | 'Straight Vertical Drag' | 'Rotation Drag' | 'Quick Scope Flick';
  description: string;
}

export interface Weapon {
  id: string;
  name: string;
  category: 'Shotgun' | 'Assault Rifle' | 'SMG' | 'Sniper' | 'Marksman Rifle' | 'Pistol';
  tier: 'S+' | 'S' | 'A' | 'B';
  damage: number; // out of 100
  rateOfFire: number; // out of 100
  range: number; // out of 100
  reloadSpeed: number; // out of 100
  magazine: number;
  accuracy: number; // out of 100
  armorPenetration: number; // out of 100
  headshotMultiplier: number;
  proTips: string;
}

export interface CharacterCombo {
  id: string;
  name: string;
  role: string;
  activeSkill: {
    character: string;
    skillName: string;
    description: string;
  };
  passiveSkills: Array<{
    character: string;
    skillName: string;
    description: string;
  }>;
  comboSynergy: string;
}

export interface HudButtonConfig {
  id: string;
  name: string;
  x: number; // % 0-100
  y: number; // % 0-100
  size: number; // px or scale
  opacity: number; // 0.1 to 1.0
  color: string;
  iconType: string;
  finger: string;
}

export interface HudPreset {
  id: string;
  name: string;
  fingers: 2 | 3 | 4;
  description: string;
  bestFor: string;
  buttons: HudButtonConfig[];
}
