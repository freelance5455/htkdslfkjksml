export type CategoryType = 'love' | 'funny' | 'stress' | 'secret' | 'campus' | 'hottake';

export interface CommentItem {
  id: string;
  authorAvatarEmoji: string;
  authorAvatarName: string;
  authorHash: string;
  content: string;
  timestamp: string;
  likes: number;
  isLiked?: boolean;
}

export interface Confession {
  id: string;
  content: string;
  category: CategoryType;
  collegeCode: string;
  collegeName: string;
  isCampusOnly: boolean;
  authorAvatarEmoji: string;
  authorAvatarName: string;
  authorHash: string; // Server-masked cryptographic hash
  timestamp: string;
  likes: number;
  dislikes: number;
  userLiked?: boolean;
  userDisliked?: boolean;
  isBookmarked?: boolean;
  commentsCount: number;
  comments: CommentItem[];
  isBoosted?: boolean;
  reportsCount: number;
  isHidden?: boolean;
  imagePreset?: string;
  views: number;
}

export interface ReferralFriend {
  id: string;
  avatarEmoji: string;
  avatarName: string;
  maskedId: string;
  joinedAt: string;
  status: 'joined' | 'verified' | 'coins_awarded';
  coinsAwarded: number;
}

export interface ReferralRewardMilestone {
  invitesRequired: number;
  badgeName: string;
  coinsReward: number;
  perkDescription: string;
  unlocked: boolean;
}

export interface User {
  id: string;
  email: string;
  phone: string;
  secretHashId: string; // Internal hidden server ID
  collegeCode: string;
  collegeName: string;
  classInfo: string;
  classUpdatedYear: number;
  avatarEmoji: string;
  avatarName: string;
  karma: number;
  secretCoins: number;
  referralCode: string;
  referralCount: number;
  badges: string[];
  isBanned: boolean;
  isVerifiedStudent: boolean;
  isCollegeAdmin?: boolean;
  isPremium: boolean;
  savedPostIds: string[];
  cooldownDaysRemaining: number;
}

export interface College {
  code: string;
  name: string;
  city: string;
  state?: string;
  district?: string;
  secretPasscode: string;
  adminHash: string;
  adminName: string;
  studentsCount: number;
  badge: string;
  createdAt: string;
}

export interface PollOption {
  id: string;
  text: string;
  votes: number;
}

export interface Poll {
  id: string;
  question: string;
  category: string;
  collegeCode: string;
  collegeName: string;
  options: PollOption[];
  totalVotes: number;
  userVotedOptionId?: string;
  expiresIn: string;
  authorAvatar: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  points: number;
}

export interface EmojiPuzzle {
  id: string;
  title: string;
  emojis: string;
  category: string;
  hint: string;
  answer: string;
  solved: boolean;
}

export interface TruthDareItem {
  id: string;
  type: 'truth' | 'dare';
  prompt: string;
  intensity: 'Mild' | 'Spicy' | 'Insane';
  category: string;
}

export interface ChatMessage {
  id: string;
  senderEmoji: string;
  senderName: string;
  text: string;
  timestamp: string;
  isOwn: boolean;
}

export interface ChatRoom {
  id: string;
  name: string;
  tag: string;
  description: string;
  activeCount: number;
  icon: string;
  gradient: string;
  messages: ChatMessage[];
}

export interface DirectWhisperMessage {
  id: string;
  sender: 'me' | 'them';
  text: string;
  timestamp: string;
}

export interface DirectWhisperConversation {
  id: string;
  confessionId: string;
  confessionSnippet: string;
  partnerEmoji: string;
  partnerName: string;
  messages: DirectWhisperMessage[];
  unread: boolean;
  updatedAt: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'like' | 'comment' | 'badge' | 'boost' | 'system';
  read: boolean;
}

export interface ReportedPost {
  id: string;
  confessionId: string;
  content: string;
  authorHash: string;
  reason: string;
  reportedAt: string;
  status: 'pending' | 'resolved' | 'removed';
}
