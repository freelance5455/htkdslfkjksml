export type WorkType = 'manhwa' | 'manga' | 'manhua' | 'comic' | 'novel';

export const WORK_TYPE_LABELS: Record<WorkType, { label: string; ar: string; flag: string }> = {
  manhwa: { label: 'مانهوا كورية', ar: 'مانهوا', flag: '🇰🇷' },
  manga: { label: 'مانجا يابانية', ar: 'مانجا', flag: '🇯🇵' },
  manhua: { label: 'مانها صينية', ar: 'مانها', flag: '🇨🇳' },
  comic: { label: 'كوميكس', ar: 'كوميكس', flag: '🌐' },
  novel: { label: 'رواية', ar: 'روايات', flag: '📖' },
};

export type TeamMemberRole = 'leader' | 'manager' | 'editor' | 'translator' | 'cleaner' | 'typesetter' | 'proofreader' | 'member';

export const TEAM_ROLE_LABELS: Record<TeamMemberRole, string> = {
  leader: 'قائد الفريق (المالك)',
  manager: 'مدير الفريق',
  editor: 'محرر أعمال',
  translator: 'مترجم',
  cleaner: 'مبيّض',
  typesetter: 'محرر نصوص (تايب)',
  proofreader: 'مدقق لغوي',
  member: 'عضو',
};

export interface TeamMember {
  uid: string;
  uniqueId?: string;
  email: string;
  displayName: string;
  photoUrl?: string;
  role: TeamMemberRole;
  joinedAt: string;
}

export type InvitationStatus = 'pending' | 'accepted' | 'declined' | 'cancelled';

export interface TeamInvitation {
  id: string;
  teamId: string;
  teamName: string;
  teamLogo?: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverUniqueId: string;
  receiverEmail: string;
  receiverName: string;
  receiverPhotoUrl?: string;
  role: TeamMemberRole;
  status: InvitationStatus;
  createdAt: string;
  updatedAt?: string;
}

export type PublicationStatus = 'draft' | 'pending_review' | 'published' | 'scheduled' | 'unpublished' | 'rejected';

export const PUBLICATION_STATUS_LABELS: Record<PublicationStatus, { label: string; ar: string; color: string; bg: string; border: string }> = {
  draft: { label: 'مسودة', ar: 'مسودة', color: 'text-amber-300', bg: 'bg-amber-950/60', border: 'border-amber-500/40' },
  pending_review: { label: 'بانتظار المراجعة', ar: 'قيد المراجعة', color: 'text-sky-300', bg: 'bg-sky-950/60', border: 'border-sky-500/40' },
  published: { label: 'منشور', ar: 'منشور علناً', color: 'text-emerald-300', bg: 'bg-emerald-950/60', border: 'border-emerald-500/40' },
  scheduled: { label: 'مجدول', ar: 'مجدول للنشر', color: 'text-purple-300', bg: 'bg-purple-950/60', border: 'border-purple-500/40' },
  unpublished: { label: 'غير منشور', ar: 'مسحوب', color: 'text-gray-400', bg: 'bg-gray-900/60', border: 'border-gray-600/40' },
  rejected: { label: 'مرفوض', ar: 'مرفوض', color: 'text-red-400', bg: 'bg-red-950/60', border: 'border-red-500/40' },
};

export interface Team {
  id: string;
  name: string;
  description: string;
  logoUrl: string;
  bannerUrl?: string;
  leaderId: string;
  leaderName: string;
  discordUrl?: string;
  telegramUrl?: string;
  websiteUrl?: string;
  members: TeamMember[];
  worksCount?: number;
  isVerified?: boolean;
  isDeleted?: boolean;
  deletedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserProfile {
  uid: string;
  uniqueId: string;
  userTag?: string;
  email: string;
  displayName: string;
  photoUrl?: string;
  bio?: string;
  role: 'user' | 'publisher' | 'team_leader' | 'admin' | 'owner';
  teamId?: string;
  isBanned?: boolean;
  banReason?: string;
  isSuspended?: boolean;
  isDeleted?: boolean;
  createdAt: string;
}

export interface AssignedMember {
  uid: string;
  displayName: string;
  role: string;
}

export interface Manhwa {
  id: string;
  title: string;
  titleOriginal?: string;
  type: WorkType;
  description: string;
  coverUrl: string;
  genres: string[];
  status: 'ongoing' | 'completed' | 'hiatus';
  publicationStatus?: PublicationStatus;
  publishedAt?: string;
  scheduledPublishAt?: string;
  rejectionReason?: string;
  isDeleted?: boolean;
  deletedAt?: string;
  author?: string;
  artist?: string;
  teamId?: string;
  teamName?: string;
  views: number;
  rating: number;
  ratingCount: number;
  publisherId: string;
  publisherName: string;
  latestChapterNumber?: number;
  latestChapterTitle?: string;
  assignedMembers?: AssignedMember[];
  allowedEditors?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Chapter {
  id: string;
  manhwaId: string;
  chapterNumber: number;
  title: string;
  pages: string[];
  pagesCount: number;
  novelContent?: string;
  teamId?: string;
  publisherId: string;
  publicationStatus?: PublicationStatus;
  isDeleted?: boolean;
  deletedAt?: string;
  views: number;
  createdAt: string;
  updatedAt: string;
}

export interface Bookmark {
  id: string;
  userId: string;
  manhwaId: string;
  manhwaTitle: string;
  manhwaCover: string;
  createdAt: string;
}

export interface Comment {
  id: string;
  chapterId: string;
  manhwaId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  content: string;
  createdAt: string;
}

export type SupportCategory = 'general' | 'team_inquiry' | 'report' | 'ownership' | 'technical';

export const SUPPORT_CATEGORY_LABELS: Record<SupportCategory, string> = {
  general: 'استفسار عام',
  team_inquiry: 'شؤون الفرق والناشرين',
  report: 'بلاغ عن محتوى مخالف',
  ownership: 'نزاع أو نقل ملكية',
  technical: 'مشكلة تقنية أو حفظ'
};

export interface SupportMessage {
  id: string;
  senderId: string;
  senderName: string; // e.g. user display name or "إدارة الموقع"
  senderAvatar?: string;
  isAdmin: boolean;
  content: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  userUniqueId: string;
  userAvatar?: string;
  subject: string;
  category: SupportCategory;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  messages: SupportMessage[];
  lastMessageAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorName: string;
  actorEmail: string;
  action: string;
  targetType: 'manhwa' | 'chapter' | 'team' | 'user' | 'support';
  targetId: string;
  targetName: string;
  details?: string;
  createdAt: string;
}

export type ViewMode = 'reader' | 'publisher' | 'teams' | 'chapter-view' | 'profile' | 'owner-admin' | 'team-studio';

export const MANHWA_GENRES = [
  'أكشن',
  'مغامرات',
  'فانتازيا',
  'رومانسي',
  'شونين',
  'فنون قتالية',
  'غموض',
  'خيال علمي',
  'دراما',
  'سحر',
  'تاريخي',
  'إثارة',
  'كوميديا',
  'حياة مدرسية',
  'قوى خارقة',
  'تناسخ أرواح',
  'أبراج وزنزانات',
  'عالم الألعاب (RPG)',
  'رعب',
  'شريحة من الحياة'
];
