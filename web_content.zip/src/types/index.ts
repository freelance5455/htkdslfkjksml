export type PlayerRole = 'admin' | 'player';

export interface Player {
  id: string;
  name: string;
  avatarUrl?: string;
  color: string;
  role: PlayerRole;
  pin?: string; // Optional simple PIN for player actions
  createdAt: string;
}

export type CategoryStatus = 'active' | 'archived';

export interface Category {
  id: string;
  name: string;
  weightGrams: number;
  status: CategoryStatus;
  createdBy: string;
  approvedBy?: string;
  safetyNotice?: string;
  isOfficialSafe: boolean; // Only <= 500g is safe for active competition
}

export interface Attempt {
  id: string;
  playerId: string;
  categoryId: string;
  localDate: string; // YYYY-MM-DD in São Paulo
  count: number;
  timestamp: string;
}

export interface DailyRecord {
  id: string; // `${playerId}_${categoryId}_${localDate}`
  playerId: string;
  categoryId: string;
  localDate: string; // YYYY-MM-DD
  bestStreak: number;
  trained: boolean; // true if player logged training (even if 0 acertos)
  attemptsCount: number;
  updatedAt: string;
}

export interface WeeklyResult {
  seasonId: string;
  categoryId: string;
  playerId: string;
  sumStreaks: number;
  daysTrained: number;
  rawAverage: number;
  formattedAverage: string; // '7.67'
  maxStreak: number;
  rank: number;
  isChampion: boolean;
  tieBreakReason?: string;
}

export interface Season {
  id: string;
  name: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  status: 'active' | 'closed';
  closedAt?: string;
  timezone: string; // America/Sao_Paulo
  snapshots?: Record<string, WeeklyResult[]>; // categoryId -> results
}

export interface HistoricalRank {
  playerId: string;
  categoryId: string;
  rawHistoricalAverage: number;
  formattedHistoricalAverage: string;
  validWeeksCount: number;
  allTimeBestStreak: number;
  rank: number;
  championTitlesCount: number;
}

export type TrickDifficulty = 'facil' | 'medio' | 'dificil' | 'lendario';
export type TrickStatus = 'draft' | 'published' | 'archived';

export interface Trick {
  id: string;
  name: string;
  description: string;
  authorId: string;
  categoryId?: string;
  difficulty: TrickDifficulty;
  status: TrickStatus;
  createdAt: string;
  publishedAt?: string;
  // Personal executions recorded by players
  executionsByPlayer: Record<string, number>;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  recordTarget: string; // e.g. "Record 200g - 2026-10-20"
  previousValue: string;
  newValue: string;
  reason: string;
  timestamp: string;
}

export interface AppState {
  players: Player[];
  categories: Category[];
  dailyRecords: DailyRecord[];
  attempts: Attempt[];
  seasons: Season[];
  currentSeasonId: string;
  tricks: Trick[];
  auditLogs: AuditLog[];
}
