export type Priority = 'high' | 'medium' | 'low';

export type TaskCategory = 'work' | 'personal' | 'study' | 'health' | 'worship' | 'routine' | 'other';

export interface Task {
  id: string;
  title: string;
  notes?: string;
  dueDate: string; // YYYY-MM-DD
  dueTime?: string; // HH:MM
  priority: Priority;
  category: TaskCategory;
  completed: boolean;
  completedAt?: string | null;
  isRoutine?: boolean;
  routineFrequency?: 'daily' | 'weekdays' | 'weekends';
  reminderSet?: boolean;
  reminderMinutesBefore?: number;
  alarmEnabled?: boolean;
  alarmMinutesBefore?: number; // 0 = at time, 5 = 5m before, 10 = 10m before, etc.
  ringtone?: string; // key of selected alarm tone
  hasAlarmRung?: boolean;
  createdAt: string;
}

export type HabitCategory = 'health' | 'fitness' | 'learning' | 'mindfulness' | 'productivity' | 'worship' | 'other';
export type HabitFrequency = 'daily' | 'weekdays' | 'weekends';

export interface Habit {
  id: string;
  title: string;
  description?: string;
  category: HabitCategory;
  frequency: HabitFrequency;
  targetCount: number; // e.g. 1 time, or 8 glasses
  unit: string; // 'times', 'glasses', 'pages', 'mins'
  color: string; // color tag
  iconName: string;
  history: Record<string, number>; // "YYYY-MM-DD" -> count completed
  currentStreak: number;
  bestStreak: number;
  createdAt: string;
}

export interface GoalMilestone {
  id: string;
  title: string;
  completed: boolean;
}

export interface Goal {
  id: string;
  title: string;
  description?: string;
  category: 'career' | 'personal' | 'spiritual' | 'health' | 'finance' | 'learning';
  targetDate: string; // YYYY-MM-DD
  progress: number; // 0 to 100
  milestones: GoalMilestone[];
  color: string;
  createdAt: string;
}

export interface DailyPrayers {
  fajr: boolean;
  dhuhr: boolean;
  asr: boolean;
  maghrib: boolean;
  isha: boolean;
  tahajjud: boolean;
  fajrTime?: string;
  dhuhrTime?: string;
  asrTime?: string;
  maghribTime?: string;
  ishaTime?: string;
  // Waqt start and end times
  fajrStart?: string;
  fajrEnd?: string;
  dhuhrStart?: string;
  dhuhrEnd?: string;
  asrStart?: string;
  asrEnd?: string;
  maghribStart?: string;
  maghribEnd?: string;
  ishaStart?: string;
  ishaEnd?: string;
  tahajjudStart?: string;
  tahajjudEnd?: string;
}

export interface QuranProgress {
  currentSurah: number; // 1 to 114
  currentAyah: number;
  pagesReadToday: number;
  dailyGoalPages: number;
  lastReadDate: string;
  totalFinishedTimes: number;
  favoriteSurah?: string;
  notes?: string;
}

export interface IslamicDhikrItem {
  id: string;
  title: string;
  arabic: string;
  meaning: string;
  targetCount: number;
  currentCount: number;
  completed: boolean;
  category: 'morning' | 'evening' | 'general' | 'sunnah';
}

export interface UserProfile {
  name: string;
  avatar: string;
  title: string;
  dailyTaskTarget: number;
  dailyHabitTarget: number;
  dailyQuranPagesTarget: number;
  language: 'en' | 'bn';
  theme: 'light' | 'dark';
  notificationsEnabled: boolean;
  soundEnabled: boolean;
}

export type ActiveTab = 'dashboard' | 'planner' | 'habits' | 'prayer' | 'profile' | 'ai';
