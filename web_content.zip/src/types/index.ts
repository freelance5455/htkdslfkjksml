/**
 * PCMART Marketplace Data Types & Interfaces
 */

export interface ProductVariant {
  id: string;
  name: string; // e.g. "Midnight Black", "8GB + 128GB", "Size M"
  sku: string;
  price: number;
  mrp: number;
  stock: number;
  image?: string;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number; // 1 to 5
  title: string;
  comment: string;
  date: string;
  verifiedPurchase: boolean;
  helpfulCount: number;
}

export interface Product {
  id: string;
  title: string;
  shortHook: string;
  description: string;
  category: string;
  brand: string;
  sellerId: string;
  sellerName: string;
  sellerRating: number;
  price: number;
  mrp: number;
  discountPercentage: number;
  rating: number;
  ratingCount: number;
  images: string[];
  videoUrl?: string; // Short video reel link
  videoThumbnail?: string;
  variants: ProductVariant[];
  selectedVariantId?: string;
  stock: number;
  inStock: boolean;
  codAvailable: boolean;
  deliveryDays: number;
  tags: string[];
  specifications: Record<string, string>;
  warranty: string;
  returnPolicy: string;
  approvalStatus: 'APPROVED' | 'PENDING' | 'REJECTED';
  isFeatured?: boolean;
  isFlashDeal?: boolean;
  reviews?: Review[];
  createdAt: string;
}

export interface VideoReel {
  id: string;
  productId: string;
  productTitle: string;
  productPrice: number;
  productImage: string;
  sellerName: string;
  caption: string;
  videoUrl: string;
  thumbnailUrl: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  durationSeconds: number;
}

export interface Seller {
  id: string;
  storeName: string;
  ownerName: string;
  email: string;
  phone: string;
  gstin: string;
  pan: string;
  city: string;
  state: string;
  rating: number;
  totalOrders: number;
  status: 'VERIFIED' | 'PENDING_APPROVAL' | 'SUSPENDED';
  commissionRate: number; // default 0.12 (12%)
  bankAccount: {
    accountNumberMasked: string;
    ifsc: string;
    bankName: string;
  };
  balanceAvailable: number;
  joinedDate: string;
}

export interface CartItem {
  productId: string;
  variantId?: string;
  variantName?: string;
  product: Product;
  quantity: number;
  priceAtAddition: number;
}

export interface Address {
  id: string;
  fullName: string;
  phoneNumber: string;
  streetAddress: string;
  landmark?: string;
  city: string;
  state: string;
  pincode: string;
  addressType: 'HOME' | 'WORK' | 'OTHER';
  isDefault: boolean;
}

export interface OrderItem {
  productId: string;
  variantId?: string;
  title: string;
  variantName?: string;
  image: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  sellerId: string;
  sellerName: string;
  status: 'CONFIRMED' | 'PACKED' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED' | 'RETURNED';
  isReviewed?: boolean;
  reviewRating?: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  deliveryFee: number;
  platformFee: number;
  totalAmount: number;
  shippingAddress: Address;
  paymentMethod: 'UPI' | 'CARD' | 'NETBANKING' | 'COD';
  paymentStatus: 'PAID' | 'PENDING_COD' | 'FAILED' | 'REFUNDED';
  paymentTransactionId?: string;
  status:
    | 'CONFIRMED'
    | 'PACKED'
    | 'SHIPPED'
    | 'OUT_FOR_DELIVERY'
    | 'DELIVERED'
    | 'CANCELLED'
    | 'RETURN_REQUESTED'
    | 'RETURNED'
    | 'REFUNDED';
  carrier?: string;
  trackingNumber?: string;
  estimatedDeliveryDate: string;
  createdAt: string;
  disputeReason?: string;
  refundAmount?: number;
}

export interface Coupon {
  code: string;
  description: string;
  discountType: 'FLAT' | 'PERCENTAGE';
  value: number;
  minOrderValue: number;
  maxDiscount?: number;
  expiryDate: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  tag: string;
  ctaText: string;
  imageUrl: string;
  backgroundColor: string;
  categoryFilter?: string;
}

export interface SettlementLedgerEntry {
  id: string;
  sellerId: string;
  sellerName: string;
  orderId: string;
  orderDate: string;
  grossAmount: number;
  commissionDeduction: number;
  pgFeeDeduction: number;
  gstDeduction: number;
  netPayout: number;
  status: 'PENDING' | 'SETTLED' | 'ON_HOLD';
  payoutDate?: string;
  utrNumber?: string;
}

export interface Dispute {
  id: string;
  orderId: string;
  customerId: string;
  customerName: string;
  sellerId: string;
  sellerName: string;
  productTitle: string;
  reason: string;
  amount: number;
  status: 'OPEN' | 'RESOLVED_REFUND' | 'RESOLVED_REJECTED';
  createdAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: string;
  role: 'ADMIN' | 'SELLER' | 'CUSTOMER' | 'SYSTEM';
  action: string;
  details: string;
}

export interface CustomerUser {
  id: string;
  name: string;
  phone: string;
  email?: string;
  isLoggedIn: boolean;
  avatar?: string;
  joinedDate?: string;
  addresses?: Address[];
}
