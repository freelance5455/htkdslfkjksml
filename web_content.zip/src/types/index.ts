export type Language = 'EN' | 'SI';

export type UserRole = 
  | 'GUEST' 
  | 'STUDENT' 
  | 'TEACHER' 
  | 'MODERATOR' 
  | 'ADMIN' 
  | 'SUPER_ADMIN';

export type Medium = 'Sinhala' | 'English' | 'Tamil';

export type PaperType = 'Past Paper' | 'Term Test' | 'Model Paper' | 'Marking Scheme' | 'Short Notes';

export type TermTest = '1st Term' | '2nd Term' | '3rd Term' | 'Final Exam' | 'N/A';

export type GradeLevel = 
  | 'Grade 6' 
  | 'Grade 7' 
  | 'Grade 8' 
  | 'Grade 9' 
  | 'G.C.E. O/L' 
  | 'G.C.E. A/L';

export type Province = 
  | 'Western' 
  | 'Central' 
  | 'Southern' 
  | 'Northern' 
  | 'Eastern' 
  | 'North Western' 
  | 'North Central' 
  | 'Uva' 
  | 'Sabaragamuwa' 
  | 'National';

export type FileFormat = 'PDF' | 'DOCX' | 'ZIP' | 'RAR';

export type ApprovalStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  coverImage?: string;
  role: UserRole;
  bio?: string;
  school?: string;
  province?: Province;
  points: number;
  level: number;
  joinedDate: string;
  followersCount: number;
  followingCount: number;
  isVerified: boolean;
  isTwoFactorEnabled: boolean;
  badges: string[];
  savedPaperIds: string[];
  likedPaperIds: string[];
  followedUserIds: string[];
}

export interface Paper {
  id: string;
  title: string;
  subject: string;
  grade: GradeLevel;
  medium: Medium;
  year: number;
  province: Province;
  school: string;
  paperType: PaperType;
  termTest: TermTest;
  hasAnswers: boolean;
  hasMarkingScheme: boolean;
  fileFormat: FileFormat;
  fileUrl: string;
  fileSize: string;
  pagesCount: number;
  downloadCount: number;
  viewsCount: number;
  uploadedDate: string;
  uploaderId: string;
  uploaderName: string;
  uploaderAvatar: string;
  uploaderRole: UserRole;
  status: ApprovalStatus;
  tags: string[];
  description?: string;
  previewPagesText?: string[];
  likesCount: number;
}

export interface PollOption {
  id: string;
  text: string;
  votes: number;
  votedUserIds: string[];
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorRole: UserRole;
  content: string;
  createdAt: string;
  likesCount: number;
  likedUserIds: string[];
  commentsCount: number;
  hashtags: string[];
  poll?: {
    question: string;
    options: PollOption[];
  };
  isPinned?: boolean;
  isAnnouncement?: boolean;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  content: string;
  createdAt: string;
  likesCount: number;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'LIKE' | 'COMMENT' | 'PAPER_APPROVED' | 'PAPER_REJECTED' | 'ANNOUNCEMENT' | 'FOLLOW';
  title: string;
  message: string;
  createdAt: string;
  isRead: boolean;
  linkUrl?: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  progress: number; // 0 to 100
  category: 'UPLOADS' | 'DOWNLOADS' | 'COMMUNITY' | 'STREAK';
}

export interface FilterState {
  grade: string;
  subject: string;
  medium: string;
  year: string;
  province: string;
  school: string;
  paperType: string;
  fileFormat: string;
  sortBy: 'newest' | 'popular' | 'trending' | 'downloads';
  searchQuery: string;
}

export interface SystemStats {
  totalPapers: number;
  totalDownloads: number;
  totalUsers: number;
  pendingApprovals: number;
  storageUsedGB: number;
  activeToday: number;
}
