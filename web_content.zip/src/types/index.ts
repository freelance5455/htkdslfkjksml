export type Language = 'gu' | 'en';

export interface UserProfile {
  id: string;
  name: string;
  businessName?: string;
  pin?: string;
  pinEnabled: boolean;
  securityQuestion?: string;
  securityAnswer?: string;
  createdAt: string;
}

export type AccountType = 'cash' | 'bank' | 'wallet' | 'other';

export interface Account {
  id: string;
  userId: string;
  name: string;
  type: AccountType;
  accountNumber?: string;
  bankName?: string;
  initialBalance: number;
  notes?: string;
  color?: string;
  isDefault?: boolean;
}

export type CategoryType = 'income' | 'expense';

export interface Category {
  id: string;
  userId?: string; // empty means global default
  nameEn: string;
  nameGu: string;
  type: CategoryType;
  icon: string;
  color: string;
  isDefault?: boolean;
}

export interface Transaction {
  id: string;
  userId: string;
  type: 'income' | 'expense';
  amount: number;
  date: string; // YYYY-MM-DD
  categoryId: string;
  accountId: string;
  title: string;
  notes?: string;
  partyName?: string;
  referenceNo?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AccountTransfer {
  id: string;
  userId: string;
  fromAccountId: string;
  toAccountId: string;
  amount: number;
  date: string;
  notes?: string;
  createdAt: string;
}

export type LoanType = 'lent' | 'borrowed'; // lent = ધીરેલ (we gave loan / Asset), borrowed = લીધેલ (we took loan / Liability)
export type InterestType = 'simple' | 'compound';
export type RatePeriod = 'yearly' | 'monthly'; // yearly = % p.a., monthly = % per month (e.g. 1.5% or 2% taka)
export type CompoundingFrequency = 'daily' | 'monthly' | 'quarterly' | 'yearly';
export type LoanStatus = 'active' | 'settled';

export interface LoanRepayment {
  id: string;
  date: string; // YYYY-MM-DD
  amount: number;
  accountId?: string; // bank or cash account where payment happened
  note?: string;
  clearedInterest?: number; // calculated at calculation time
  deductedPrincipal?: number; // calculated at calculation time
  createdAt: string;
}

export interface LoanDisbursement {
  id: string;
  date: string; // YYYY-MM-DD
  amount: number;
  accountId?: string;
  note?: string;
  createdAt: string;
}

export interface Loan {
  id: string;
  userId: string;
  type: LoanType;
  partyName: string;
  partyPhone?: string;
  partyAddress?: string;
  initialPrincipal: number;
  startDate: string; // YYYY-MM-DD - Beginning of year for interest calculation
  interestType: InterestType;
  interestRate: number; // e.g. 12% or 2% (per ratePeriod)
  ratePeriod: RatePeriod; // 'yearly' or 'monthly'
  compoundingFrequency: CompoundingFrequency; // only used if compound
  notes?: string;
  accountId?: string; // source / destination account
  status: LoanStatus;
  repayments: LoanRepayment[];
  disbursements?: LoanDisbursement[]; // additional disbursements if any
  settledDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AnniversaryYearReport {
  yearIndex: number; // 1, 2, 3...
  startDate: string;
  endDate: string;
  daysInYear: number; // 365 or 366 (leap year)
  isLeapYear: boolean;
  openingPrincipal: number;
  interestAccrued: number;
  repaymentsTotal: number;
  repaymentsToInterest: number;
  repaymentsToPrincipal: number;
  closingPrincipal: number;
  closingAccruedInterest: number;
  closingTotalDue: number;
}

export interface InterestTimelineEvent {
  id: string;
  date: string;
  type: 'start' | 'interest_accrual' | 'repayment' | 'disbursement' | 'anniversary_mark' | 'today';
  title: string;
  description: string;
  daysCount?: number;
  isLeapPeriod?: boolean;
  principalBefore: number;
  interestBefore: number;
  amountChanged?: number;
  clearedInterest?: number;
  deductedPrincipal?: number;
  principalAfter: number;
  interestAfter: number;
  totalBalanceAfter: number;
}

export interface LoanCalculationResult {
  loanId: string;
  asOfDate: string;
  currentPrincipal: number;
  currentAccruedInterest: number;
  totalBalanceRemaining: number;
  totalRepaid: number;
  totalInterestRepaid: number;
  totalPrincipalRepaid: number;
  totalInterestAccruedAllTime: number;
  isSettled: boolean;
  anniversaryYears: AnniversaryYearReport[];
  timeline: InterestTimelineEvent[];
}

export interface AppBackupData {
  version: string;
  exportedAt: string;
  users: UserProfile[];
  currentUserId: string;
  accounts: Account[];
  categories: Category[];
  transactions: Transaction[];
  transfers: AccountTransfer[];
  loans: Loan[];
  language: Language;
}
