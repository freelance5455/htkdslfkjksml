export type Language = 'en' | 'bn';

export type AdminRole = 'super_admin';
export type UserRole = 'user' | AdminRole;

export type AdminStatus = 'active' | 'disabled';

export type Permission = 
  | 'manage_tournaments'
  | 'manage_rooms'
  | 'manage_payments'
  | 'manage_results'
  | 'manage_support'
  | 'view_audit_logs'
  | 'run_security_tests';

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: AdminRole;
  status: AdminStatus;
  invitedBy: string;
  invitedAt: string;
  lastLoginAt?: string;
  mfaEnabled: boolean;
  isRootSuperAdmin?: boolean; // Strictly protects the owner X SABBIR
}

export interface User {
  id: string;
  name: string;
  phone: string;
  email: string;
  ffIgn: string; // Free Fire In-Game Name
  ffUid: string; // Free Fire UID (e.g. 293847291)
  walletBalance: number; // Total available balance
  winningsBalance: number; // Eligible for withdrawal
  depositBalance: number; // For match entries
  bonusCoins: number; // Daily login & referral rewards
  rankTier: string; // e.g. "Grandmaster", "Heroic", "Diamond IV"
  totalKills: number;
  matchesWon: number;
  matchesPlayed: number;
  avatar: string;
  role: UserRole;
  createdAt: string;
}

export type TournamentCategory = 'all' | 'solo' | 'duo' | 'squad' | 'clash_squad';
export type MatchStatus = 'upcoming' | 'ongoing' | 'completed' | 'cancelled';
export type FFMap = 'Bermuda' | 'Purgatory' | 'Kalahari' | 'Alpine' | 'Nexterra';

export type PrizePoolStatus = 'guaranteed' | 'funded' | 'planned';
export type RoomStatus = 'not_added' | 'scheduled' | 'available' | 'completed';

export interface RegisteredSlot {
  slotNumber: number;
  userId: string;
  userName: string;
  ffIgn: string;
  ffUid: string;
  teamName?: string;
  teammates?: { ign: string; uid: string }[];
  registeredAt: string;
}

export interface Tournament {
  id: string;
  title: string;
  subtitle: string;
  category: 'solo' | 'duo' | 'squad' | 'clash_squad';
  map: FFMap;
  matchType: 'Battle Royale' | 'Clash Squad 4v4';
  version: 'TPP' | 'FPP';
  scheduleTime: string; // ISO string
  registrationDeadline: string; // ISO string
  entryFee: number;
  perKill: number;
  totalPrize: number;
  prizePoolStatus: PrizePoolStatus; // 'guaranteed' | 'funded' | 'planned'
  firstPrize: number;
  secondPrize: number;
  thirdPrize: number;
  prizeDistributionRules: string;
  refundRules: string;
  totalSlots: number;
  bookedSlots: number;
  status: MatchStatus;
  bannerImage: string;
  
  // Room Management
  roomStatus: RoomStatus; // 'not_added' | 'scheduled' | 'available' | 'completed'
  roomId?: string; // Stored securely, revealed only if eligible & available
  roomPassword?: string;
  roomReleaseTime?: string; // ISO string
  
  registeredSlots: RegisteredSlot[];
  rules: string[];
}

export type AuditCategory = 'login' | 'role_change' | 'payment' | 'tournament' | 'room' | 'security_alert' | 'support';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  adminId: string;
  adminName: string;
  category: AuditCategory;
  tournamentId?: string;
  tournamentTitle?: string;
  action: string;
  status: 'success' | 'blocked' | 'warning';
  ipAddress?: string;
  changes?: {
    field: string;
    oldVal: string | number;
    newVal: string | number;
  }[];
}

export type TransactionType = 'deposit' | 'withdrawal' | 'match_entry' | 'prize_winnings' | 'bonus_credit';
export type TransactionStatus = 'completed' | 'pending' | 'rejected';

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number;
  paymentMethod?: string; // bKash, Nagad, Rocket, Wallet
  trxId?: string;
  senderNumber?: string;
  receiverNumber?: string;
  status: TransactionStatus;
  timestamp: string;
  description: string;
  balanceAfter: number;
}

export interface MatchResultStanding {
  rank: number;
  ign: string;
  teamName?: string;
  kills: number;
  prize: number;
  ffUid: string;
}

export interface MatchResult {
  id: string;
  tournamentId: string;
  matchTitle: string;
  category: string;
  map: FFMap;
  completedAt: string;
  winner: {
    ign: string;
    teamName?: string;
    kills: number;
    prize: number;
  };
  mvp: {
    ign: string;
    kills: number;
    headshots?: number;
  };
  standings: MatchResultStanding[];
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'match' | 'wallet' | 'announcement';
  isRead: boolean;
  actionUrl?: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  category: string;
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved';
  createdAt: string;
  assignedAdmin?: string;
  resolutionNote?: string;
  replies: {
    sender: 'user' | 'support';
    text: string;
    time: string;
  }[];
}

export interface LoadTestMetric {
  timestamp: string;
  concurrentUsers: number;
  requestsPerSec: number;
  p95LatencyMs: number;
  p99LatencyMs: number;
  errorRatePercent: number;
  activeDbConnections: number;
  ledgerAcidChecksPerSec: number;
  status: 'OPTIMAL' | 'DEGRADED' | 'OVERLOAD';
}

export interface AcceptanceTestItem {
  id: number;
  title: string;
  criteria: string;
  status: 'idle' | 'running' | 'passed' | 'failed';
  details: string;
  timestamp?: string;
}

export interface SecurityRBACTestItem {
  id: string;
  testName: string;
  actorRole: UserRole;
  attemptedAction: string;
  expectedResult: 'BLOCKED_403' | 'ALLOWED';
  actualResult?: 'BLOCKED_403' | 'ALLOWED';
  status: 'idle' | 'running' | 'passed' | 'failed';
  details: string;
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  ign: string;
  winnings: number;
  kills: number;
  matches: number;
  avatar: string;
}

export interface TournamentControlTestItem {
  id: string;
  title: string;
  criteria: string;
  status: 'idle' | 'running' | 'passed' | 'failed';
  details: string;
  timestamp?: string;
}

export interface SingleAdminTestItem {
  id: string;
  title: string;
  criteria: string;
  actorRole: UserRole;
  attemptedAction: string;
  expectedResult: 'ALLOWED' | 'BLOCKED_403';
  actualResult?: 'ALLOWED' | 'BLOCKED_403';
  status: 'idle' | 'running' | 'passed' | 'failed';
  details: string;
}
