export type ModelId = 
  | 'gemini-3.8-flash'
  | 'gemini-3.1-flash-lite'
  | 'gemini-3.1-pro-preview'
  | 'gemma-4-26b-a4b-it'
  | 'gemini-flash-latest'
  | 'gemini-flash-lite-latest'
  | 'gemini-pro-latest'
  | 'gemini-2.5-flash'
  | 'gemini-2.5-pro'
  | string;

export interface ModelInfo {
  id: ModelId;
  name: string;
  description: string;
  category: string;
  badge?: string;
  contextWindowTokens?: number;
  recommended?: boolean;
}

export type ThinkingLevel = 'HIGH' | 'LOW' | 'MINIMAL' | '';

export type SafetyBlockThreshold = 
  | 'BLOCK_NONE'
  | 'BLOCK_ONLY_HIGH'
  | 'BLOCK_MEDIUM_AND_ABOVE'
  | 'BLOCK_LOW_AND_ABOVE';

export interface MessageImage {
  id: string;
  name: string;
  data: string; // base64 string
  mimeType: string;
  sizeBytes?: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  images?: MessageImage[];
  tokensEstimate?: number;
  inputTokens?: number;
  outputTokens?: number;
  totalTokens?: number;
  durationMs?: number;
  isError?: boolean;
  alternatives?: string[]; // Riwayat versi alternatif / respon sebelumnya untuk fitur bolak-balik respon bot
  activeAlternativeIndex?: number; // Indeks respon aktif saat ini
}

export interface SessionTokenStats {
  totalInputTokens: number;
  totalOutputTokens: number;
  totalTokens: number;
  lastInputTokens?: number;
  lastOutputTokens?: number;
}

export interface ChatSettings {
  model: ModelId;
  systemInstruction: string;
  temperature: number; // 0.0 - 2.0
  topP: number; // 0.0 - 1.0
  topK: number; // 1 - 100
  maxOutputTokens: number; // 0 for default
  thinkingLevel: ThinkingLevel;
  contextWindow: number; // number of past messages to send (0 = all)
  streamResponse: boolean;
  botName: string;
  botAvatar: string; // Emoji, URL gambar, atau base64 foto Bot
  userName: string;
  userAvatar?: string; // Emoji, URL gambar, atau base64 foto Pengguna
  userPersona?: string; // Karakter, kepribadian, dan peran Pengguna untuk roleplay & percakapan
  fontSize: 'sm' | 'md' | 'lg';
  autoScroll: boolean;
  soundFeedback: boolean;
  theme: 'dark' | 'light' | 'system';
  
  // AI Censorship & Safety Filter Controls
  safetyFilterEnabled: boolean; // false = Nonaktifkan Sensor (BLOCK_NONE + Anti-Refusal Directive), true = Aktifkan Sensor
  safetyThreshold: SafetyBlockThreshold;
  antiRefusalBypassEnabled: boolean; // Aktifkan instruksi anti-penolakan (OpenRouter style)

  // Provider Options (Google AI Studio vs OpenRouter)
  provider: 'gemini' | 'openrouter';
  openRouterApiKey?: string;
  openRouterModel?: string;

  // Background & Wallpaper Settings
  backgroundEnabled?: boolean;
  backgroundType?: 'none' | 'preset' | 'upload' | 'generated' | 'perchance';
  backgroundImageUrl?: string;
  backgroundOpacity?: number; // 0.05 - 1.0 (default 0.25)
  backgroundBlur?: number; // 0 - 20 px (default 2)
  bubbleOpacity?: number; // 0.10 - 1.0 (default 0.85) - Tingkat tembus pandang / opasitas bubble chat
  bubbleBlur?: number; // 0 - 20 px (default 0) - Efek blur pada bubble chat (0 = jernih tanpa blur agar wallpaper terlihat jelas)
  fullScreenMode?: boolean; // Selalu mode layar penuh / Fullscreen immersif
  chatWidth?: 'standard' | 'full'; // 'standard' (max-w-4xl) atau 'full' (100% lebar penuh layar)
  enterKeyAction?: 'newline' | 'send'; // 'newline' (Enter = paragraf baru, Ctrl+Enter = kirim) atau 'send' (Enter = kirim)
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
  pinned?: boolean;
  tags?: string[];
  customSettings?: Partial<ChatSettings>;
  tokenStats?: SessionTokenStats;
}

export interface PersonaPreset {
  id: string;
  name: string;
  description: string;
  icon: string;
  systemInstruction: string;
  temperature: number;
  topP?: number;
  recommendedModel?: ModelId;
  category: 'Asisten' | 'Koding' | 'Bahasa' | 'Kreatif' | 'Bisnis' | 'Kustom';
}

export interface UserPersonaPreset {
  id: string;
  name: string;
  description: string;
  icon: string;
  persona: string;
  category: 'Roleplay' | 'Profesi' | 'Kasual' | 'Kustom';
}

export interface AvatarPreset {
  id: string;
  name: string;
  url: string;
  category: 'Sci-Fi' | 'Anime' | 'Karakter' | 'Minimalis';
}

export interface StorageStats {
  sessionCount: number;
  messageCount: number;
  totalBytes: number;
  storageQuotaBytes: number;
  usagePercentage: number;
}
