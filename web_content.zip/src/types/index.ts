export type SIMSlot = 'SIM 1' | 'SIM 2';

export type TelecomOperator = 'Jazz' | 'Telenor' | 'Zong' | 'Ufone' | 'Onic' | 'SCOM' | 'Warid';

export interface SIMConfig {
  slot: SIMSlot;
  operator: TelecomOperator;
  label?: string;
  phoneNumber?: string;
}

export interface CNICRecord {
  id: string;
  cnic: string;
  sim: string;
  time: string;
  status: 'Added' | 'Selected' | 'Demo' | 'Failed';
  province?: string;
  gender?: 'Male' | 'Female';
}

export interface SendingEntry {
  id: string;
  cnic: string;
  sim: string;
  destination: string;
  time: string;
  status: 'Demo only' | 'Sent via SMS' | 'Delivered' | 'Pending';
  rawTime: number;
}

export interface ReplyEntry {
  id: string;
  cnic: string;
  time: string;
  sim: string;
  rawText: string;
  parsedBreakdown?: {
    jazz: number;
    telenor: number;
    zong: number;
    ufone: number;
    warid?: number;
    totalVoice: number;
    totalData: number;
    totalSims: number;
  };
}

export type Language = 'ur' | 'en';
