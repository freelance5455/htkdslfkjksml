export type VisualizerMode = 'waveform' | 'spectrum' | 'circular' | 'lasers' | 'matrix';

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  bpm: number;
  genre: string;
  coverUrl: string;
  audioUrl?: string;
  synthPreset?: 'edm_anthem' | 'cyberpunk' | 'tech_house' | 'neon_trap' | 'synthwave' | 'club_energy';
  isCustom?: boolean;
}

export interface EQState {
  low: number; // -12dB to +12dB
  mid: number; // -12dB to +12dB
  high: number; // -12dB to +12dB
  filter: number; // -100 (Low-pass) to 0 (neutral) to +100 (High-pass)
}

export interface DJState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  playbackRate: number; // 0.84 to 1.16 (+-16% pitch)
  isScratching: boolean;
  bpm: number;
  beatDetected: boolean;
  crossfader: number; // -1 (A) to 0 (Center) to 1 (B)
  visualizerMode: VisualizerMode;
  stageBackdropUrl: string | null;
  isMicActive: boolean;
}
