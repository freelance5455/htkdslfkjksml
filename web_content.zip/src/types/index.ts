// Supermarket Domain Types & RBAC Definitions

export type RoleType = 'SUPER_ADMIN' | 'MANAGER' | 'CASHIER' | 'INVENTORY_MANAGER' | 'ACCOUNTANT';

export type PermissionCode =
  | 'POS_ACCESS'
  | 'POS_CREATE_SALE'
  | 'POS_HOLD_SALE'
  | 'POS_REFUND'
  | 'PRODUCT_VIEW'
  | 'PRODUCT_CREATE'
  | 'PRODUCT_EDIT'
  | 'PRODUCT_DELETE'
  | 'INVENTORY_VIEW'
  | 'INVENTORY_ADJUST'
  | 'INVENTORY_TRANSFER'
  | 'PURCHASE_VIEW'
  | 'PURCHASE_CREATE'
  | 'PURCHASE_APPROVE'
  | 'PURCHASE_RECEIVE'
  | 'SUPPLIER_MANAGE'
  | 'CUSTOMER_MANAGE'
  | 'CASH_REGISTER_MANAGE'
  | 'EXPENSES_MANAGE'
  | 'REPORT_VIEW'
  | 'REPORT_EXPORT'
  | 'USER_MANAGE'
  | 'AUDIT_LOG_VIEW'
  | 'SETTINGS_MANAGE';

export interface User {
  id: string;
  email: string;
  username: string;
  name: string;
  role: RoleType;
  branchId: string;
  phone?: string;
  active: boolean;
  failedAttempts: number;
  lockedUntil?: string | null;
  lastLoginAt?: string | null;
  createdAt: string;
}

export interface Branch {
  id: string;
  code: string;
  name: string;
  address: string;
  phone?: string;
  email?: string;
  isMain: boolean;
  active: boolean;
}

export interface Category {
  id: string;
  name: string;
  code: string;
  description?: string;
  active: boolean;
}

export interface Brand {
  id: string;
  name: string;
  description?: string;
  active: boolean;
}

export interface Product {
  id: string;
  sku: string;
  barcode: string;
  name: string;
  description?: string;
  categoryId: string;
  brandId?: string;
  costPrice: number;
  sellingPrice: number;
  wholesalePrice?: number;
  taxRate: number; // percentage, e.g. 15 for 15%
  unit: string;
  minStockLevel: number;
  maxStockLevel: number;
  reorderLevel: number;
  expiryDate?: string;
  active: boolean;
  imageUrl?: string;
  createdAt: string;
}

export interface InventoryItem {
  id: string;
  productId: string;
  branchId: string;
  quantity: number;
  updatedAt: string;
}

export type MovementType =
  | 'PURCHASE'
  | 'SALE'
  | 'SALE_RETURN'
  | 'PURCHASE_RETURN'
  | 'ADJUSTMENT_IN'
  | 'ADJUSTMENT_OUT'
  | 'DAMAGE'
  | 'EXPIRY'
  | 'TRANSFER_IN'
  | 'TRANSFER_OUT'
  | 'OPENING_BALANCE';

export interface StockMovement {
  id: string;
  productId: string;
  branchId: string;
  quantity: number; // positive or negative
  movementType: MovementType;
  referenceType?: string;
  referenceId?: string;
  previousQuantity: number;
  newQuantity: number;
  performedById: string;
  performedByName: string;
  notes?: string;
  createdAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  code: string;
  contactPerson?: string;
  phone: string;
  email?: string;
  address?: string;
  taxNumber?: string;
  active: boolean;
  notes?: string;
}

export type PurchaseStatus = 'DRAFT' | 'APPROVED' | 'RECEIVED' | 'CANCELLED';

export interface PurchaseOrderItem {
  id: string;
  productId: string;
  productName: string;
  orderedQuantity: number;
  receivedQuantity: number;
  unitCost: number;
  totalCost: number;
}

export interface PurchaseOrder {
  id: string;
  orderNumber: string;
  supplierId: string;
  branchId: string;
  status: PurchaseStatus;
  totalAmount: number;
  createdById: string;
  approvedById?: string;
  notes?: string;
  items: PurchaseOrderItem[];
  createdAt: string;
  receivedAt?: string;
}

export interface Customer {
  id: string;
  code: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  loyaltyPoints: number;
  active: boolean;
  notes?: string;
}

export type PaymentMethod = 'CASH' | 'CARD' | 'MOBILE_PAYMENT' | 'BANK_TRANSFER' | 'STORE_CREDIT';

export interface CartItem {
  product: Product;
  quantity: number;
  unitPrice: number;
  discountAmount: number;
  taxAmount: number;
  lineTotal: number;
}

export interface Sale {
  id: string;
  receiptNumber: string;
  branchId: string;
  cashierId: string;
  cashierName: string;
  customerId?: string;
  customerName?: string;
  cashSessionId?: string;
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  grandTotal: number;
  paymentMethod: PaymentMethod;
  amountTendered: number;
  changeGiven: number;
  status: 'COMPLETED' | 'HELD' | 'REFUNDED';
  notes?: string;
  items: {
    productId: string;
    productName: string;
    barcode: string;
    quantity: number;
    unitPrice: number;
    costPrice: number;
    taxRate: number;
    taxAmount: number;
    discountAmount: number;
    totalPrice: number;
  }[];
  createdAt: string;
}

export interface CashRegister {
  id: string;
  branchId: string;
  code: string;
  name: string;
  status: 'OPEN' | 'CLOSED';
}

export interface CashSession {
  id: string;
  cashRegisterId: string;
  cashierId: string;
  cashierName: string;
  openingBalance: number;
  closingBalance?: number;
  expectedCash?: number;
  actualCash?: number;
  difference?: number;
  openedAt: string;
  closedAt?: string;
  status: 'OPEN' | 'CLOSED';
  notes?: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  entity: string;
  entityId?: string;
  metadata?: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string;
}

export interface SystemSettings {
  businessName: string;
  logoUrl?: string;
  address: string;
  phone: string;
  currency: string;
  taxRateDefault: number;
  receiptFooter: string;
  lowStockThresholdDefault: number;
  allowNegativeStock: boolean;
  requireCustomerForSale: boolean;
  thermalPrinterWidth: number; // 80 or 58 mm
}
