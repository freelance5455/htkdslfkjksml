export type SessionState = 'disconnected' | 'connecting' | 'listening' | 'speaking' | 'error';

export type MoodTheme = 'cyber-rose' | 'electric-violet' | 'midnight-emerald' | 'solar-amber' | 'hyper-cyan';

export type ExpressionType = 'smirk' | 'wink' | 'laugh' | 'blush' | 'fire' | 'pout' | 'heart' | 'neutral';

export type ActionType =
  | 'openWebsite'
  | 'searchWeb'
  | 'setTimer'
  | 'takeNote'
  | 'playMusicVibe'
  | 'downloadZip'
  | 'calculateMath'
  | 'deviceControl'
  | 'changeMoodTheme'
  | 'triggerExpression';

export interface ToolCallData {
  id: string;
  name: string;
  args: {
    url?: string;
    siteName?: string;
    comment?: string;
    query?: string;
    platform?: 'google' | 'youtube' | 'wikipedia';
    seconds?: number;
    label?: string;
    text?: string;
    category?: string;
    vibe?: 'lofi' | 'ambient' | 'party' | 'alert';
    action?: string;
    expression?: string;
    calculation?: string;
    theme?: MoodTheme;
    reason?: string;
    [key: string]: any;
  };
}

export interface NoteItem {
  id: string;
  text: string;
  category?: string;
  createdAt: number;
}

export interface TimerItem {
  id: string;
  label: string;
  totalSeconds: number;
  remainingSeconds: number;
  active: boolean;
  createdAt: number;
}

export interface ExecutedAction {
  id: string;
  type: ActionType;
  timestamp: number;
  data: any;
  status: 'success' | 'blocked' | 'pending';
}

export interface ServerMessage {
  type: 'audio' | 'interrupted' | 'turnComplete' | 'toolCall' | 'error' | 'connected' | 'modelInfo';
  audio?: string; // base64 24kHz PCM
  calls?: ToolCallData[];
  message?: string;
  model?: string;
  voice?: string;
}

export interface ClientMessage {
  type: 'audio' | 'toolResponse' | 'interrupt' | 'config';
  audio?: string; // base64 16kHz PCM
  id?: string;
  name?: string;
  response?: Record<string, any>;
  voice?: string;
  model?: string;
}
