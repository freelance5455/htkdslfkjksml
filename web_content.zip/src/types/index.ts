export type ReviewRating = 'again' | 'hard' | 'good' | 'easy';

export interface Flashcard {
  id: string;
  topicId: string;
  front: string;
  back: string;
  hint?: string;
  createdAt: string;
  lastReviewedAt?: string;
  reviewCount: number;
  ratingHistory: ReviewRating[];
}

export interface ReviewHistoryEntry {
  date: string;
  rating: ReviewRating;
  stageBefore: number;
  stageAfter: number;
}

export interface Topic {
  id: string;
  title: string;
  categoryId: string;
  notes: string;
  keyConcepts: string[];
  createdAt: string; // ISO date
  lastReviewedAt?: string; // ISO date
  nextReviewDate: string; // ISO date (YYYY-MM-DD or full ISO)
  stage: number; // 0 = Day 0, 1 = Day 1, 2 = Day 3, 3 = Day 7, 4 = Day 21, 5 = Day 30, 6 = Day 60, 7 = Day 90+
  masteryScore: number; // 0 to 100
  stability: number; // Memory stability in days
  consecutiveSuccesses: number;
  history: ReviewHistoryEntry[];
  flashcards: Flashcard[];
}

export interface SubjectCategory {
  id: string;
  name: string;
  description: string;
  color: string; // hex or tailwind token
  iconName: string;
}

export interface MotivationalReminder {
  id: string;
  title: string;
  message: string;
  timeOfDay: string; // "HH:MM" e.g. "09:00"
  enabled: boolean;
  frequency: 'daily' | 'weekdays' | 'interval-study';
  type: 'quote' | 'nudge' | 'streak' | 'custom';
}

export interface StudySessionState {
  isActive: boolean;
  mode: 'focus' | 'break';
  timeLeftSeconds: number;
  totalDurationMinutes: number;
  cardsReviewedThisSession: number;
  topicsReviewedThisSession: number;
}
