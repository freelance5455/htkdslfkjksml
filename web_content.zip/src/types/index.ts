export type Language = 'en' | 'ps' | 'ur';

export type ClassLevelId =
  | 'elementary_a'
  | 'elementary_b'
  | 'pre_intermediate'
  | 'intermediate'
  | 'junior_advanced'
  | 'senior_advanced';

export type GenderSection = 'male' | 'female';

export interface ClassInfo {
  id: string;
  levelId: ClassLevelId;
  nameEn: string;
  namePs: string;
  nameUr: string;
  gender: GenderSection;
  durationMonths: number;
  durationLabelEn: string;
  durationLabelPs: string;
  durationLabelUr: string;
  startTime: string; // e.g. "08:00 AM"
  endTime: string;   // e.g. "09:30 AM"
  grammarHoursWeekly: number;
  speakingHoursWeekly: number;
  vocabListeningHoursWeekly: number;
  monthlyFeePkr: number;
  imageUrl: string;
  instructorName: string;
  roomNumber: string;
  descriptionEn: string;
  descriptionPs: string;
  descriptionUr: string;
}

export type StudentBehavior =
  | 'moral_intelligent'       // بااخلاق او هوښیار / بااخلاق اور ذہین
  | 'diligent_learner'        // سبق زده کوونکی / محنتی طالب علم
  | 'average'                 // منځنی / اوسط
  | 'needs_improvement_lazy'; // تنبل / محنت کی ضرورت

export interface AttendanceRecord {
  date: string; // YYYY-MM-DD
  status: 'present' | 'absent' | 'leave';
  notifiedWhatsApp?: boolean;
  notifiedAt?: string;
}

export interface Student {
  id: string;
  name: string;
  fatherName: string;
  whatsappNumber: string;
  classId: string;
  gender: GenderSection;
  photoUrl: string;
  position: string; // e.g., "1st Position 🥇", "2nd Position 🥈", "3rd Position 🥉", "Top 5", "Honor Roll", "None"
  behavior: StudentBehavior;
  behaviorNotes?: string;
  feeStatus: 'paid' | 'unpaid';
  feeAmount: number;
  feePaidDate?: string;
  monthlyAttendancePresentDays: number;
  monthlyTotalWorkingDays: number;
  attendanceHistory: AttendanceRecord[];
  isGraduated: boolean;
  graduationDate?: string; // YYYY-MM-DD
  graduationTime?: string; // e.g. "11:30 AM"
  graduationRemarks?: string;
  enrolledDate: string;
}

export interface ParchiQuestion {
  id: string;
  type: 'mcq' | 'fill_in_the_blank' | 'grammar_rule' | 'speaking_dialogue' | 'vocabulary' | 'translation_essay';
  prompt: string;
  options?: string[];
  correctAnswer?: string;
  marks: number;
}

export interface ParchiExam {
  id: string;
  title: string;
  classId: string;
  examType: 'weekly' | 'monthly' | 'midterm' | 'final';
  totalMarks: number;
  timeAllowed: string; // e.g. "60 Minutes"
  date: string;
  instructions: string;
  questions: ParchiQuestion[];
}

export interface SyllabusUnit {
  week: number;
  topicTitle: string;
  grammarFocus: string;
  speakingFocus: string;
  vocabularyFocus: string;
  practiceActivity: string;
}

export interface ClassSyllabus {
  classLevelId: ClassLevelId;
  titleEn: string;
  titlePs: string;
  titleUr: string;
  units: SyllabusUnit[];
}
