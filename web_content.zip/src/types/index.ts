export type UserRole = 'Admin' | 'Employee' | 'Client';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  designation: string;
  clientId?: string; // if role === 'Client'
  employeeId?: string; // if role === 'Employee'
  avatar?: string;
  phone?: string;
}

export interface Employee {
  id: string;
  employeeCode: string; // e.g. PFS-0001
  employeeName: string;
  photo?: string;
  aadhaarNumber?: string;
  panNumber?: string;
  phone: string;
  alternatePhone?: string;
  email: string;
  designation: string;
  department: string;
  joiningDate: string;
  bloodGroup?: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-' | string;
  dateOfBirth?: string;
  address?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  status: 'Active' | 'Inactive';
  createdAt: string;
}

export interface Client {
  id: string;
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  username: string;
  password?: string;
  status: 'Active' | 'Inactive';
  address: string;
  city: string;
  gstin: string;
  industry: string;
  zohoContactId?: string;
  zohoData?: Record<string, string>;
  createdAt: string;
  notes?: string;
}

export type ClientInput = Omit<Client, 'id' | 'createdAt' | 'username' | 'status'> & {
  username?: string;
  status?: 'Active' | 'Inactive';
};

export type ProjectCategory = 
  | 'Fire Alarm System' 
  | 'Hydrant & Sprinkler' 
  | 'CO2 & Clean Agent Gas' 
  | 'Extinguisher & AMC' 
  | 'TNFRS NOC Compliance';

export type ProjectPriority = 'Low' | 'Medium' | 'High' | 'Critical';

export type ProjectStatus = 'Pending' | 'In Progress' | 'Completed' | 'On Hold' | 'Overdue';

export interface ProjectMilestone {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  dueDate: string;
  completedDate?: string;
}

export interface Project {
  id: string;
  reference: string; // e.g. PHX-2026-081
  name: string; // project_name
  clientId: string;
  clientCompanyName: string;
  description: string;
  category: ProjectCategory;
  startDate: string; // start_date
  expectedCompletionDate: string; // end_date
  assignedEmployeeIds: string[]; // ppm_project_employees
  priority: ProjectPriority;
  status: ProjectStatus;
  progressPercentage: number;
  isManualProgress: boolean;
  contractValueINR: number;
  siteLocation: string; // location
  milestones: ProjectMilestone[];
  createdAt: string;
}

export type TaskStatus = 'Pending' | 'To Do' | 'In Progress' | 'Completed' | 'Overdue';

export interface Task {
  id: string;
  projectId: string;
  projectReference: string;
  title: string; // task_name
  description: string;
  assignedToEmployeeId: string; // assigned_to
  assignedToName: string;
  assignedToCode?: string; // e.g. PFS-0001
  deadline: string; // due_date
  priority: ProjectPriority;
  status: TaskStatus;
  remarks: string;
  visibleToClient: boolean;
  completedAt?: string;
  createdAt: string;
}

export interface ProgressUpdate {
  id: string;
  projectId: string;
  submittedByUserId: string;
  submittedByName: string;
  userRole: UserRole;
  timestamp: string;
  percentageReported: number;
  notes: string;
  attachmentName?: string;
  clientVisible: boolean;
}

export interface ConversationMessage {
  id: string;
  projectId: string;
  senderId: string;
  senderName: string;
  senderType: 'office' | 'client'; // matches WordPress ppm_conversations sender_type
  senderRole: UserRole;
  timestamp: string;
  type: 'text' | 'voice';
  content?: string;
  audioUrl?: string; // base64 or audio URL
  audioDurationSeconds?: number; // audio_duration
  messageType?: 'public';
  isRead: boolean; // is_read
  status: 'Sent' | 'Delivered' | 'Read';
}

export type DocumentCategory = 
  | 'Drawing'
  | 'Quotation'
  | 'Invoice'
  | 'Completion Report'
  | 'Certificate'
  | 'Site Photo'
  | 'Other'
  | 'Purchase Order'
  | 'Work Order'
  | 'CAD Drawing'
  | 'Inspection Report'
  | 'Form B NOC'
  | 'Completion Certificate'
  | 'Service Report';

export interface ProjectDocument {
  id: string;
  projectId: string;
  projectReference: string;
  title: string;
  filename: string; // document_name
  fileType: 'pdf' | 'dwg' | 'image' | 'doc';
  fileSize: string; // file_size
  category: DocumentCategory; // document_type
  uploadDate: string;
  uploadedBy: string;
  uploadedByRole: UserRole;
  accessLevel: 'Client Shared' | 'Internal Only';
  downloadUrl?: string;
  previewUrl?: string;
  previewText?: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'task' | 'project' | 'message' | 'voice' | 'document' | 'deadline';
  targetRole?: UserRole | 'All';
  targetUserId?: string;
  projectId?: string;
  taskId?: string;
  read: boolean;
  timestamp: string;
}

export interface ActivityLog {
  id: string;
  projectId: string;
  projectReference: string;
  action: string;
  details: string;
  performedBy: string;
  role: UserRole;
  timestamp: string;
}

export interface PluginSettings {
  zohoUrl: string; // ppm_zoho_url
}
