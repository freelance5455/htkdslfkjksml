export type Language = 'en' | 'hi';

export type ProductCategory = 
  | 'all'
  | 'laptops_new'
  | 'laptops_refurbished'
  | 'computers_desktops'
  | 'cctv_surveillance'
  | 'printers_toner'
  | 'accessories_networking';

export interface Product {
  id: string;
  name: {
    en: string;
    hi: string;
  };
  category: ProductCategory;
  price: number;
  originalPrice: number;
  condition: 'new' | 'refurbished' | 'boxed';
  inStock: boolean;
  featured?: boolean;
  image: string;
  specs: {
    en: string[];
    hi: string[];
  };
  warranty: {
    en: string;
    hi: string;
  };
  brand: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ServiceItem {
  id: string;
  name: {
    en: string;
    hi: string;
  };
  category: 'laptop_pc' | 'windows_software' | 'cctv' | 'dvr_nvr' | 'printer' | 'networking';
  icon: string;
  description: {
    en: string;
    hi: string;
  };
  estimatedTime: {
    en: string;
    hi: string;
  };
  startingPrice: number;
  homeServiceAvailable: boolean;
}

export interface ServiceBookingFormData {
  customerName: string;
  phoneNumber: string;
  alternatePhone?: string;
  address: string;
  serviceType: string;
  deviceType: 'Laptop' | 'Desktop PC' | 'CCTV System' | 'DVR/NVR' | 'Printer' | 'Networking / Wi-Fi' | 'Other';
  problemDescription: string;
  preferredDate: string;
  preferredTimeSlot: string;
  serviceMode: 'home_service' | 'shop_visit';
  targetWhatsAppNumber: string; // 7054304313 or 8726356413
}

export interface OrderFormData {
  customerName: string;
  phoneNumber: string;
  deliveryAddress: string;
  cityPincode: string;
  specialNotes?: string;
  targetWhatsAppNumber: string; // 7054304313 or 8726356413
}

export interface SavedOrder {
  id: string;
  timestamp: string;
  customerName: string;
  phoneNumber: string;
  deliveryAddress: string;
  cityPincode: string;
  items: {
    id: string;
    name: string;
    quantity: number;
    price: number;
  }[];
  totalAmount: number;
  status: 'Pending' | 'Contacted' | 'Dispatched' | 'Delivered' | 'Cancelled';
  assignedNumber: string;
}

export interface SavedBooking {
  id: string;
  timestamp: string;
  customerName: string;
  phoneNumber: string;
  address: string;
  deviceType: string;
  problem: string;
  serviceMode: 'home_service' | 'shop_visit';
  preferredDate: string;
  preferredSlot: string;
  status: 'Received' | 'Assigned' | 'In Progress' | 'Completed' | 'Cancelled';
  assignedNumber: string;
}

export interface ShopSettings {
  shopName: string;
  tagline: {
    en: string;
    hi: string;
  };
  phone1: string;
  phone2: string;
  addressLine1: string;
  addressLine2: string;
  cityState: string;
  pincode: string;
  landmark: string;
  openingHours: {
    en: string;
    hi: string;
  };
  googleMapsEmbedUrl: string;
  googleMapsDirectionsUrl: string;
  upiId: string;
  adminPin: string;
}
