import { Timestamp } from 'firebase/firestore';

export type LanguageCode = 'en' | 'ny';
export type ThemeMode = 'light' | 'dark';
export type UserRole = 'student' | 'instructor' | 'graduate' | 'admin';

export interface UserProfile {
  uid: string;
  fullName: string;
  username: string;
  photoUrl?: string;
  coverUrl?: string;
  bio?: string;
  location?: string;
  college?: string;
  course?: string;
  level?: string;
  role: UserRole;
  isOnline?: boolean;
  followersCount?: number;
  followingCount?: number;
  blockedUids?: string[];
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface UserPrivateInfo {
  uid: string;
  email?: string;
  phone?: string;
  language: LanguageCode;
  theme: ThemeMode;
  profileVisibility: 'public' | 'friends' | 'private';
  messagePermission?: 'friends' | 'everyone';
  subscriptionStatus: 'free' | 'active' | 'expired';
  subscriptionExpiresAt?: Timestamp | null;
  updatedAt?: Timestamp;
}

export interface PostItem {
  id: string;
  authorId: string;
  authorName: string;
  authorUsername?: string;
  authorPhoto?: string;
  authorCourse?: string;
  content: string;
  mediaUrl?: string;
  mediaType: 'none' | 'image' | 'video' | 'document';
  category: 'social' | 'educational' | 'practical' | 'announcement';
  courseTag?: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface PostComment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  text: string;
  createdAt?: Timestamp;
}

export interface FriendRequestItem {
  id: string;
  fromUid: string;
  fromName?: string;
  fromPhoto?: string;
  fromCourse?: string;
  toUid: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface FriendshipItem {
  id: string;
  userA: string;
  userB: string;
  createdAt?: Timestamp;
}

export interface StatusItem {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  type: 'text' | 'image' | 'audio';
  text?: string;
  mediaUrl?: string;
  bgColor?: string;
  privacy: 'public' | 'friends';
  viewersCount: number;
  expiresAt?: Timestamp;
  createdAt?: Timestamp;
}

export interface ChatThread {
  id: string;
  userA: string;
  userB: string;
  userAName?: string;
  userBName?: string;
  lastMessage?: string;
  lastSenderId?: string;
  updatedAt?: Timestamp;
  createdAt?: Timestamp;
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  type: 'text' | 'image' | 'audio' | 'document';
  text?: string;
  mediaUrl?: string;
  fileName?: string;
  replyPreview?: string;
  delivered: boolean;
  read: boolean;
  createdAt?: Timestamp;
}

export interface StudyGroup {
  id: string;
  name: string;
  description?: string;
  type: 'public' | 'private';
  college?: string;
  course?: string;
  creatorId: string;
  membersCount: number;
  createdAt?: Timestamp;
}

export interface GroupMember {
  id: string;
  uid: string;
  displayName?: string;
  role: 'admin' | 'moderator' | 'member';
  status: 'approved' | 'pending';
  joinedAt?: Timestamp;
}

export interface GroupMessage {
  id: string;
  groupId: string;
  senderId: string;
  senderName: string;
  type: 'text' | 'document' | 'announcement';
  text: string;
  fileName?: string;
  createdAt?: Timestamp;
}

export type LibrarySection = 'common' | 'course' | 'practical' | 'fundamentals' | 'past_paper';

export interface LibraryCourse {
  id: string;
  name: string;
  trade: string;
  college: string;
  department: string;
  qualification: string;
  level: string;
  description?: string;
  createdBy: string;
  isBuiltin?: boolean;
}

export interface LibraryMaterial {
  id: string;
  title: string;
  section: LibrarySection;
  subject: string;
  courseName?: string;
  college?: string;
  level?: string;
  year?: string;
  docType: 'notes' | 'pdf' | 'manual' | 'diagram' | 'worksheet' | 'past_paper';
  summary: string;
  contentMarkdown: string;
  fileUrl?: string;
  imagePreview?: string;
  isAuthorized: boolean;
  uploadedBy: string;
  isBuiltin?: boolean;
}

export interface NotificationItem {
  id: string;
  recipientUid: string;
  actorUid: string;
  type: 'message' | 'friend_request' | 'like' | 'comment' | 'group_invite' | 'library' | 'membership' | 'call' | 'announcement';
  title: string;
  body: string;
  read: boolean;
  createdAt?: Timestamp;
}

export interface PaymentRecord {
  id: string;
  uid: string;
  provider: 'airtel_money' | 'tnm_mpamba' | 'google_play';
  phoneMasked?: string;
  amountMwk: number;
  reference: string;
  status: 'pending' | 'confirmed' | 'failed' | 'unconfigured';
  gatewayMessage?: string;
  createdAt?: Timestamp;
}

export interface ReportItem {
  id: string;
  reporterUid: string;
  targetType: 'user' | 'post' | 'group';
  targetId: string;
  reason: string;
  status: 'open' | 'reviewed' | 'resolved';
  createdAt?: Timestamp;
}

export interface CallLogItem {
  id: string;
  callerUid: string;
  callerName?: string;
  calleeUid: string;
  calleeName?: string;
  callType: 'voice' | 'video';
  status: 'ringing' | 'active' | 'ended' | 'rejected' | 'missed';
  durationSeconds?: number;
  createdAt?: Timestamp;
}
