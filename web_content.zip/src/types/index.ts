export type Language = 'en' | 'ur';

export type MainSection =
  | 'home'
  | 'atta'
  | 'expenses'
  | 'factory'
  | 'leaves'
  | 'tasks'
  | 'personal'
  | 'loans'
  | 'committees'
  | 'accounting'
  | 'reports'
  | 'settings'
  | 'recycle_bin'
  | 'audit_log'
  | 'android_docs'
  | string; // for dynamic modules

// Atta Tracker
export interface AttaRecord {
  id: string;
  purchaseDate: string; // YYYY-MM-DD
  rate: number;
  rateUnit: 'Per Maund' | 'Per KG';
  quantityMaund: number;
  equivalentKg: number; // calculated: quantityMaund * 40
  totalAmount: number; // calculated based on rateUnit
  supplier: string;
  paymentStatus: 'Paid' | 'Partial' | 'Unpaid';
  remarks?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
}

// Household Expenses
export interface ExpenseCategory {
  id: string;
  name: string;
  nameUrdu?: string;
  icon?: string;
  color?: string;
}

export interface HouseholdExpense {
  id: string;
  date: string;
  categoryId: string;
  categoryName: string;
  description: string;
  amount: number;
  paymentMethod: string; // Cash, Bank, EasyPaisa, JazzCash, etc.
  paidTo?: string;
  remarks?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
}

// Factory: Leave Management
export type LeaveType = 'CL' | 'SL' | 'CPL Earn' | 'CPL Used';

export interface LeaveRecord {
  id: string;
  date: string;
  leaveType: LeaveType;
  numberOfDays: number;
  reason: string;
  remarks?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
}

export interface CplLot {
  id: string;
  earnDate: string;
  daysEarned: number;
  daysUsed: number;
  daysExpired: number;
  daysRemaining: number;
  expiryDate: string;
  isFullyConsumed: boolean;
  isExpired: boolean;
}

export interface LeaveSummary {
  clOpening: number;
  clUsed: number;
  clRemaining: number;
  slOpening: number;
  slUsed: number;
  slRemaining: number;
  cplEarned: number;
  cplUsed: number;
  cplExpired: number;
  cplAvailable: number;
  cplLots: CplLot[];
  upcomingExpirations: CplLot[];
}

// Factory: Office Tasks
export type TaskPriority = 'Low' | 'Normal' | 'High' | 'Urgent';
export type TaskStatus = 'Pending' | 'In Progress' | 'Complete' | 'On Hold' | 'Cancelled';

export interface OfficeTask {
  id: string;
  taskDate: string;
  taskTitle: string;
  description?: string;
  assignedPerson: string;
  dueDate: string;
  priority: TaskPriority;
  status: TaskStatus;
  completionDate?: string;
  remarks?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
}

// Personal: Loan Management (Payable & Receivable)
export type LoanType = 'Loan Received' | 'Loan Repaid';
export type ReceivableType = 'Loan Given' | 'Loan Recovered';

export interface LoanRecord {
  id: string;
  date: string;
  person: string;
  transactionType: LoanType;
  amount: number;
  paymentMethod: string;
  referenceNumber?: string;
  remarks?: string;
  isReceivable?: boolean; // if true, managed in separate Receivable ledger
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
}

// Personal: Committee Management
export type CommitteeTransactionType = 'Installment' | 'Payout';

export interface CommitteeRecord {
  id: string;
  date: string;
  committeeName: string;
  memberName: string;
  transactionType: CommitteeTransactionType;
  amount: number;
  paymentMethod: string;
  remarks?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
}

// Accounting & Ledgers
export type VoucherType = 'Receipt' | 'Payment' | 'Journal';

export interface VoucherEntry {
  accountId: string;
  accountName: string;
  debit: number;
  credit: number;
  narration?: string;
}

export interface AccountingVoucher {
  id: string;
  voucherNumber: string; // e.g. VCH-2026-0001
  date: string;
  voucherType: VoucherType;
  entries: VoucherEntry[];
  reference?: string;
  remarks?: string;
  createdAt: string;
  isDeleted?: boolean;
}

// Dynamic Builder: Custom Fields
export type FieldType =
  | 'text'
  | 'number'
  | 'decimal'
  | 'currency'
  | 'date'
  | 'time'
  | 'datetime'
  | 'dropdown'
  | 'multiselect'
  | 'checkbox'
  | 'radio'
  | 'textarea'
  | 'email'
  | 'phone'
  | 'attachment'
  | 'image'
  | 'formula'
  | 'autonumber';

export interface CustomField {
  id: string; // Permanent internal field ID (e.g. fld_qty_1)
  label: string;
  labelUrdu?: string;
  type: FieldType;
  required?: boolean;
  defaultValue?: string | number | boolean;
  placeholder?: string;
  options?: string[]; // for dropdown, multiselect, radio
  min?: number;
  max?: number;
  minLength?: number;
  maxLength?: number;
  precision?: number;
  width?: 'full' | 'half' | 'third';
  order: number;
  isHidden?: boolean;
  isReadOnly?: boolean;
  formulaExpression?: string;
  helpText?: string;
}

// Dynamic Builder: Submodules & Modules
export interface DynamicSubmodule {
  id: string;
  name: string;
  nameUrdu?: string;
  icon?: string;
  order: number;
  fields: CustomField[];
}

export interface DynamicModule {
  id: string;
  name: string;
  nameUrdu?: string;
  icon: string;
  order: number;
  group?: string;
  isHidden: boolean;
  isArchived: boolean;
  submodules: DynamicSubmodule[];
  createdAt: string;
}

// Dynamic Records
export interface DynamicRecord {
  id: string;
  moduleId: string;
  submoduleId: string;
  data: Record<string, any>; // Keyed by customField.id
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
}

// Units & Conversions
export interface UnitDefinition {
  id: string;
  name: string;
  symbol: string;
  baseUnitId?: string;
  conversionFactor: number; // e.g. 1 Maund = 40 KG -> factor 40 if base is KG
}

// Master Lists
export interface MasterItem {
  id: string;
  listType: 'supplier' | 'customer' | 'employee' | 'department' | 'payment_method' | 'location' | 'bank' | 'lender';
  name: string;
  contact?: string;
  notes?: string;
  isArchived?: boolean;
}

// Dashboard Widgets
export interface DashboardWidget {
  id: string;
  title: string;
  titleUrdu?: string;
  type: 'summary' | 'bar' | 'line' | 'pie' | 'progress';
  dataSource: 'atta' | 'expenses' | 'leaves' | 'tasks' | 'loans' | 'committees' | string;
  metric: string;
  color?: string;
  order: number;
}

// Audit Trail
export interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'RESTORE' | 'SETTINGS_CHANGE' | 'BACKUP_RESTORE';
  module: string;
  recordId?: string;
  summary: string;
  oldValues?: any;
  newValues?: any;
  user?: string;
}

// Recycle Bin
export interface RecycleBinItem {
  id: string;
  originalModule: string;
  recordId: string;
  deletedAt: string;
  recordTitle: string;
  recordData: any;
}

// App Settings
export interface AppSettings {
  language: Language;
  isDarkMode: boolean;
  appPin: string; // 4-digit PIN, empty if disabled
  isLocked: boolean;
  autoLockMinutes: number;
  currencySymbol: string;
  leaveYearStartMonth: number; // 7 = July
  leaveYearStartDay: number; // 1 = 1st
  clAnnualLimit: number; // Default 10
  slAnnualLimit: number; // Default 8
  cplExpiryDays: number; // Default 40
  defaultUnits: UnitDefinition[];
  lastBackupDate?: string;
}
