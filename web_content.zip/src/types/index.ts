export type RingState = 'repouso' | 'ouvindo' | 'pensando' | 'falando';

export type ActiveModal = 
  | 'none' 
  | 'image' 
  | 'library' 
  | 'diseases'
  | 'files' 
  | 'history' 
  | 'settings' 
  | 'admin' 
  | 'login'
  | 'change-password';

export interface VeterinaryDiseaseItem {
  id: string;
  nome: string;
  nomeCientifico?: string;
  especies: string[]; // cão, gato, cavalo, bovino, etc.
  categoria: 'Infecciosa' | 'Parasitária' | 'Metabólica' | 'Gastrointestinal' | 'Osteoarticular' | 'Tóxica' | 'Respiratória';
  gravidade: 'Urgência' | 'Alta' | 'Moderada' | 'Crônica';
  causa: string;
  transmissao?: string;
  sinaisClinicos: string[];
  diagnostico: string;
  tratamento: string;
  prevencao: string;
  notificacaoObrigatoria?: boolean;
}

export interface VeterinaryModelItem {
  id: string;
  nome: string;
  especie: string; // cão, gato, cavalo, bovino, suíno, etc.
  sistema: string; // esquelético, muscular, digestório, respiratório, cardiovascular, etc.
  arquivo: string;
  fonte: string;
  autor: string;
  licenca: string;
  descricao?: string;
}

export interface Model3DItem {
  id: string;
  name: string;
  createdAt: string;
  sizeBytes: number;
  photoCount?: number;
  sourceSpace?: string;
  customProperties?: {
    scale: number;
    rotationX: number;
    rotationY: number;
    rotationZ: number;
    colorTint: string;
    wireframe: boolean;
  };
}


export interface SketchfabSearchResult {
  uid: string;
  name: string;
  author: string;
  authorUrl: string;
  license: string;
  likes: number;
  viewCount: number;
  embedUrl: string;
  score: number;
  reason: string;
  thumbnails?: string[];
}

export interface AppSettings {
  geminiKey: string;
  geminiModel: string;
  groqKey: string;
  groqModel: string;
  groqVisionModel: string;
  trustedAuthors: string[];
  wakeWord: string;
  speechRate: number;
  speechMuted: boolean;
  ownerEmail: string;
  isPasswordChanged: boolean;
}

export interface HistoryItem {
  id: string;
  timestamp: string;
  query: string;
  response: string;
  consensusCount: number;
  totalBrains: number;
  thumbnail?: string;
  details?: {
    gemini?: string;
    groq?: string;
  };
}
