export interface ProductInput {
  name: string;
  url: string;
  category: string;
  offer: string;
  persona: string;
  tone: string;
  hookStyle: string;
  images: string[];
}

export interface SearchSource {
  title: string;
  url: string;
}

export interface SearchInsights {
  productName: string;
  brand?: string;
  category?: string;
  targetAudience?: string;
  oneLiner?: string;
  trendingHooks: string[];
  keyBenefits: string[];
  customerPainPoints: string[];
  viralAngles: string[];
  suggestedPrice?: string;
  sources?: SearchSource[];
  rawText?: string;
}

export interface ScriptBeat {
  timeRange: string;
  verbal: string;
  visualDirection: string;
  overlayText: string;
  musicStyle?: string;
}

export interface TimedCaption {
  start: number;
  end: number;
  text: string;
}

export interface UgcScript {
  title: string;
  hook: ScriptBeat;
  demo: ScriptBeat;
  cta: ScriptBeat;
  fullScript: string;
  timedCaptions: TimedCaption[];
  avatarRecommendation?: {
    type: string;
    vocalTone: string;
    suggestedVoice: string;
  };
  veoVideoPrompt?: string;
}

export interface UgcAdProject {
  id: string;
  userId: string;
  productName: string;
  productUrl?: string;
  category: string;
  productImage?: string;
  searchInsights: SearchInsights;
  script: UgcScript;
  voiceName: string;
  avatarType: string;
  audioBase64?: string;
  videoUrl?: string;
  status: 'draft' | 'grounded' | 'scripted' | 'voiced' | 'ready' | 'exported';
  createdAt: number;
}
