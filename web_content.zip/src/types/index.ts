export type NavSection =
  | 'dashboard'
  | 'home'
  | 'factory'
  | 'personal'
  | 'reports'
  | 'settings'
  | 'dynamic_settings'
  | 'backup'
  | 'recycle_bin'
  | 'audit_log'
  | `custom:${string}`;

export type ViewMode = 'desktop' | 'mobile';
export type ThemePreset = 'navy-emerald' | 'slate-teal' | 'charcoal-forest';
export type Language = 'en' | 'ur';
export type DateFormatOption = 'YYYY-MM-DD' | 'DD/MM/YYYY' | 'DD-MMM-YYYY';

export type RateUnit = 'per_maund' | 'per_kg';
export type PaymentStatus = 'Paid' | 'Pending' | 'Partial';

export interface PurchaseRecord {
  id: string;
  date: string; // YYYY-MM-DD
  rate: number;
  rateUnit: RateUnit;
  quantityMaund: number;
  equivalentKg: number;
  totalAmount: number;
  supplier: string;
  paymentStatus: PaymentStatus;
  remarks: string;
  createdAt: string;
  updatedAt: string;
}

export interface ExpenseCategory {
  id: string;
  name: string;
  active: boolean;
  order: number;
}

export interface ExpenseRecord {
  id: string;
  date: string;
  category: string;
  description: string;
  amount: number;
  paymentMethod: string;
  paidTo: string;
  remarks: string;
  createdAt: string;
  updatedAt: string;
}

export type LeaveEntryType = 'CL' | 'SL' | 'CPL_DUE' | 'CPL_USED';
export type LeaveStatus = 'Approved' | 'Pending' | 'Cancelled';

export interface LeaveRecord {
  id: string;
  date: string;
  leaveYear: string; // e.g. "2026-2027" (July 2026 - June 2027)
  employee: string;
  type: LeaveEntryType;
  days: number;
  expiryDate?: string; // Set for CPL_DUE (+40 days)
  reason: string;
  status: LeaveStatus;
  createdAt: string;
  updatedAt: string;
}

export interface LeaveYearOpening {
  leaveYear: string;
  clEntitlement: number;
  slEntitlement: number;
  clOpening: number;
  slOpening: number;
  cplOpening: number;
}

export type TaskPriority = 'Low' | 'Medium' | 'High' | 'Urgent';
export type TaskStatus = 'Pending' | 'In Progress' | 'Completed' | 'Cancelled';

export interface OfficeTaskRecord {
  id: string;
  title: string;
  description: string;
  assignedPerson: string;
  createdDate: string;
  dueDate: string;
  priority: TaskPriority;
  status: TaskStatus;
  remarks: string;
  createdAt: string;
  updatedAt: string;
}

export interface LoanPerson {
  id: string;
  name: string;
  openingBalance: number; // Amount already payable before logged transactions
  notes: string;
  createdAt: string;
}

export type LoanTransactionType = 'received' | 'repaid';

export interface LoanTransaction {
  id: string;
  personId: string;
  personName: string;
  loanDate: string;
  transactionDate: string;
  type: LoanTransactionType;
  amount: number;
  description: string;
  paymentMethod: string;
  remarks: string;
  createdAt: string;
  updatedAt: string;
}

export type CommitteeFrequency = 'Monthly' | 'Weekly' | 'Bi-Weekly' | 'Custom';
export type CommitteeDirection = 'payable' | 'receivable';

export interface CommitteeAccount {
  id: string;
  title: string;
  personOrGroup: string;
  totalAmount: number;
  installmentAmount: number;
  startDate: string;
  totalInstallments: number;
  frequency: CommitteeFrequency;
  dueDay: string;
  openingBalance: number;
  direction: CommitteeDirection;
  remarks: string;
  createdAt: string;
  updatedAt: string;
}

export type CommitteeTxType = 'Installment' | 'Payout';

export interface CommitteeTransaction {
  id: string;
  committeeId: string;
  committeeTitle: string;
  date: string;
  type: CommitteeTxType;
  amount: number;
  paymentMethod: string;
  remarks: string;
  createdAt: string;
  updatedAt: string;
}

// Dynamic Settings / App Builder types
export type CustomFieldType =
  | 'short_text'
  | 'long_text'
  | 'number'
  | 'decimal'
  | 'date'
  | 'dropdown'
  | 'multi_select'
  | 'checkbox'
  | 'formula';

export interface CustomFieldDef {
  id: string;
  key: string;
  label: string;
  type: CustomFieldType;
  required: boolean;
  defaultValue: string;
  placeholder: string;
  unit: string;
  min?: number;
  max?: number;
  options: string[]; // for dropdown / multi_select
  formula: string; // e.g. "{qty} * {rate}"
  order: number;
  visible: boolean;
  archived: boolean;
  showInForm: boolean;
  showInTable: boolean;
  showInReport: boolean;
}

export interface CustomSubmoduleDef {
  id: string;
  name: string;
  description: string;
  order: number;
  visible: boolean;
  archived: boolean;
}

export interface CustomModuleDef {
  id: string;
  name: string;
  description: string;
  icon: string;
  order: number;
  visible: boolean;
  archived: boolean;
  builtIn?: boolean;
  submodules: CustomSubmoduleDef[];
  fields: CustomFieldDef[];
  summaryFieldKey?: string;
  summaryAggregation?: 'sum' | 'count' | 'avg';
}

export interface CustomRecord {
  id: string;
  moduleId: string;
  submoduleId?: string;
  values: Record<string, string | number | boolean | string[]>;
  createdAt: string;
  updatedAt: string;
}

export interface CustomReportDef {
  id: string;
  name: string;
  moduleId: string;
  dateFieldKey?: string;
  groupByFieldKey?: string;
  sumFieldKey?: string;
  createdAt: string;
}

// Dashboard Metric Configuration
export type MetricKey =
  | 'home_expenses'
  | 'purchase_total_amount'
  | 'purchase_total_maund'
  | 'purchase_avg_rate'
  | 'factory_leave_total'
  | 'factory_cpl_avail'
  | 'factory_cpl_due'
  | 'office_tasks_open'
  | 'personal_loan_payable'
  | 'committee_balance'
  | 'total_records'
  | `custom:${string}`;

export interface DashboardCardConfig {
  id: string;
  title: string;
  primaryMetric: MetricKey;
  secondaryMetric?: MetricKey | '';
}

export interface QuickOverviewShortcut {
  id: string;
  label: string;
  targetSection: NavSection;
  targetTab?: string;
  metricKey?: MetricKey | '';
  visible: boolean;
}

export interface AppSettings {
  appName: string;
  appSubtitle: string;
  viewMode: ViewMode;
  theme: ThemePreset;
  language: Language;
  dateFormat: DateFormatOption;
  currencyLabel: string;
  maundToKg: number;
  allowNegativePurchase: boolean;
  defaultCL: number;
  defaultSL: number;
  cplExpiryDays: number;
  allowNegativeLeaveOverride: boolean;
  activeLeaveYear: string;
  confirmBeforeDelete: boolean;
  defaultEmployeeName: string;
  dashboardCards: DashboardCardConfig[];
  quickOverviewItems: QuickOverviewShortcut[];
  builtInModuleVisibility: {
    home: boolean;
    factory: boolean;
    personal: boolean;
  };
}

export type RecycleModuleType =
  | 'purchase'
  | 'expense'
  | 'leave'
  | 'task'
  | 'loan_person'
  | 'loan_tx'
  | 'committee'
  | 'committee_tx'
  | 'custom_record';

export interface RecycleBinItem {
  id: string;
  deletedAt: string;
  moduleType: RecycleModuleType;
  moduleLabel: string;
  summary: string;
  recordId: string;
  payload: unknown;
}

export type AuditAction =
  | 'Create'
  | 'Edit'
  | 'Delete'
  | 'Restore'
  | 'Permanent Delete'
  | 'Import/Restore'
  | 'Settings Change';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: AuditAction;
  module: string;
  recordRef: string;
  summary: string;
}

export interface AppDataState {
  schemaVersion: number;
  settings: AppSettings;
  purchases: PurchaseRecord[];
  expenseCategories: ExpenseCategory[];
  expenses: ExpenseRecord[];
  leaves: LeaveRecord[];
  leaveYearOpenings: LeaveYearOpening[];
  tasks: OfficeTaskRecord[];
  loanPersons: LoanPerson[];
  loanTransactions: LoanTransaction[];
  committees: CommitteeAccount[];
  committeeTransactions: CommitteeTransaction[];
  customModules: CustomModuleDef[];
  customRecords: CustomRecord[];
  customReports: CustomReportDef[];
  recycleBin: RecycleBinItem[];
  auditLog: AuditLogEntry[];
}
