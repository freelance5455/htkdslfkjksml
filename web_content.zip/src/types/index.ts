/**
 * Core type definitions for Synapse Enterprise & Campus Hub
 */

// User & Role
export type UserRole = 'admin' | 'teacher' | 'manager' | 'student' | 'employee';

export interface UserProfile {
  id: string;
  name: string;
  role: UserRole;
  title: string;
  department: string;
  avatar: string;
  email: string;
}

// 1. Communication & Calling
export interface CallParticipant {
  id: string;
  name: string;
  role: string;
  avatar: string;
  isMuted: boolean;
  isVideoOff: boolean;
  isScreenSharing?: boolean;
  isHost?: boolean;
  isHandRaised?: boolean;
}

export interface ActiveCall {
  id: string;
  title: string;
  type: 'video' | 'audio';
  category: 'office' | 'education';
  description: string;
  startedAt: string;
  participants: CallParticipant[];
}

export interface ChatAttachment {
  type: 'image' | 'file' | 'audio';
  url: string;
  name: string;
  size?: string;
  duration?: number; // for audio voice notes in seconds
}

export interface ChatMessage {
  id: string;
  channelId: string;
  senderId: string;
  senderName: string;
  senderRole: string;
  senderAvatar: string;
  text: string;
  timestamp: string;
  attachments?: ChatAttachment[];
  reactions?: Record<string, string[]>; // emoji -> array of userNames
}

export interface ChatChannel {
  id: string;
  name: string;
  isDirect: boolean;
  topic?: string;
  recipientAvatar?: string;
  unreadCount?: number;
}

// 2. E-Commerce & Ordering
export interface Product {
  id: string;
  title: string;
  category: 'Tech & Hardware' | 'Stationery & Books' | 'STEM & Robotics' | 'Office Furnishing' | 'Uniforms & Apparel';
  price: number;
  stock: number;
  sku: string;
  image: string;
  description: string;
  rating: number;
  reviewsCount: number;
  inStock: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface OrderTimelineEvent {
  status: OrderStatus;
  date: string;
  description: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerDepartment: string;
  shippingAddress: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  shippingFee: number;
  total: number;
  status: OrderStatus;
  paymentMethod: 'Credit Card' | 'Department Invoice' | 'Campus Purchase Order' | 'Cash on Delivery';
  paymentStatus: 'Paid' | 'Authorized' | 'Pending Net 30';
  orderDate: string;
  estimatedDelivery: string;
  timeline: OrderTimelineEvent[];
}

// 3. School & Education Hub
export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused';

export interface StudentAttendance {
  studentId: string;
  studentName: string;
  rollNumber: string;
  classGroup: string;
  avatar: string;
  status: AttendanceStatus;
  notes?: string;
}

export interface AssignmentSubmission {
  id: string;
  studentId: string;
  studentName: string;
  submittedAt: string;
  fileAttachment?: string;
  score?: number;
  maxScore: number;
  feedback?: string;
  status: 'submitted' | 'graded' | 'late';
}

export interface Assignment {
  id: string;
  title: string;
  subject: string;
  classGroup: string;
  teacherName: string;
  dueDate: string;
  totalMarks: number;
  instructions: string;
  attachmentName?: string;
  submissions: AssignmentSubmission[];
}

export interface SubjectGrade {
  subject: string;
  midTermMarks: number;
  finalExamMarks: number;
  assignmentMarks: number;
  totalMarks: number;
  grade: string;
  remarks: string;
}

export interface StudentReportCard {
  id: string;
  studentId: string;
  studentName: string;
  rollNumber: string;
  classGroup: string;
  academicYear: string;
  term: 'Mid-Term 2026' | 'Annual Finals 2026';
  attendancePercentage: number;
  subjects: SubjectGrade[];
  overallGPA: number;
  classRank: number;
  teacherRemarks: string;
  principalRemarks: string;
  issueDate: string;
}

export interface TimetableSlot {
  id: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';
  period: number;
  timeSlot: string;
  subject: string;
  room: string;
  teacher: string;
  classGroup: string;
  color: string;
}

// 4. Office & Professional Tools
export type TaskPriority = 'high' | 'medium' | 'low';
export type TaskStatus = 'todo' | 'in_progress' | 'in_review' | 'done';

export interface TaskSubtask {
  id: string;
  title: string;
  completed: boolean;
}

export interface TaskItem {
  id: string;
  title: string;
  project: string;
  assignee: {
    name: string;
    role: string;
    avatar: string;
  };
  priority: TaskPriority;
  status: TaskStatus;
  dueDate: string;
  description: string;
  tags: string[];
  subtasks: TaskSubtask[];
}

export interface PunchLogEntry {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  date: string;
  clockIn: string;
  clockOut?: string;
  totalHours?: number;
  status: 'on_duty' | 'completed' | 'overtime' | 'late_arrival';
  ipAddress?: string;
}

export type LeaveType = 'Annual Paid Leave' | 'Sick / Medical Leave' | 'Casual Emergency Leave' | 'Academic Research Leave';
export type LeaveRequestStatus = 'pending' | 'approved' | 'rejected';

export interface LeaveRequest {
  id: string;
  employeeName: string;
  department: string;
  leaveType: LeaveType;
  startDate: string;
  endDate: string;
  daysCount: number;
  reason: string;
  handoverTo: string;
  status: LeaveRequestStatus;
  appliedDate: string;
  reviewedBy?: string;
  reviewDate?: string;
  reviewComment?: string;
}

// 5. Money, Earnings & Wallet Hub
export type GigCategory =
  | 'Academic Tutoring'
  | 'Campus Logistics'
  | 'Technical Support'
  | 'Design & Content'
  | 'Research & Data';

export interface PaidGig {
  id: string;
  title: string;
  category: GigCategory;
  reward: number; // in USD
  posterName: string;
  posterRole: string;
  posterAvatar: string;
  posterDepartment: string;
  description: string;
  estimatedHours: string;
  deadline: string;
  status: 'available' | 'claimed' | 'completed';
  claimedBy?: string;
  completedAt?: string;
  submissionNotes?: string;
}

export type TransactionType =
  | 'gig_payout'
  | 'marketplace_sale'
  | 'tutoring_fee'
  | 'cash_withdrawal'
  | 'peer_transfer'
  | 'deposit_topup';

export interface WalletTransaction {
  id: string;
  type: TransactionType;
  title: string;
  amount: number; // positive for incoming, negative for outgoing
  timestamp: string;
  status: 'completed' | 'processing' | 'pending';
  destinationOrSource: string;
  referenceId?: string;
}
