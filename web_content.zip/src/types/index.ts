export interface ChatMessage {
  id: string;
  sender: 'user' | '002';
  text: string;
  timestamp: string;
  status?: 'sending' | 'sent' | 'error';
}

export type CompanionMood = 'optimal' | 'playful' | 'focused' | 'protective';

export type CameraPreset = 'front' | 'portrait' | 'full' | 'isometric' | 'side';

export type LightingPreset = 'cyber-neon' | 'crimson-cockpit' | 'studio' | 'deep-space';

export type NavTab = 'home' | 'chat' | 'character' | 'settings';

export interface ModelMetadata {
  name: string;
  source: 'procedural-002' | 'imported-glb';
  fileSize?: string;
  meshCount: number;
  vertexCount: number;
  triangleCount: number;
  animations: string[];
  isRigged: boolean;
  boneCount: number;
  morphTargetCount: number;
  hasBlinkSupport: boolean;
  rigDetails: string;
}

export interface AnimationControlsState {
  idleEnabled: boolean;
  blinkEnabled: boolean;
  headMovementEnabled: boolean;
  isPlayingClip: boolean;
  currentClipIndex: number;
}

export interface AndroidBridgeState {
  isAvailable: boolean;
  isAndroidWebView: boolean;
  accessibilityConsentGranted: boolean;
  version: string;
}

export type SpeechRecognitionState =
  | 'idle'
  | 'requesting_permission'
  | 'listening'
  | 'processing'
  | 'permission_denied'
  | 'unsupported'
  | 'error';

export type SpeechLanguageCode = 'en-US' | 'en-IN' | 'hi-IN';

export interface SpeechLanguageOption {
  code: SpeechLanguageCode;
  label: string;
  dialect: 'English' | 'Hinglish' | 'Hindi';
  badge: string;
}

export interface AndroidVoiceAssistantArchitecture {
  voiceInteractionServiceReady: boolean;
  userInitiatedTriggerSupported: boolean;
  backgroundAudioCapturePermitted: boolean;
  privacyIndicatorCompliant: boolean;
  installedAppIntentLauncherReady: boolean;
  explicitUserConsentActive: boolean;
}
