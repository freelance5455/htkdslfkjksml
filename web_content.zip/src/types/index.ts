export type UserRole = 'customer' | 'provider' | 'admin';

export interface User {
  id: string;
  name: string;
  phone: string;
  email: string;
  role: UserRole;
  avatar: string;
  city: string;
  area: string;
  createdAt: string;
}

export interface CustomerProfile {
  id: string;
  userId: string;
  savedAddresses: {
    id: string;
    label: string;
    area: string;
    city: string;
    fullAddress: string;
    lat: number;
    lng: number;
  }[];
  favorites: string[]; // Provider IDs
}

export interface PortfolioItem {
  id: string;
  title: string;
  description: string;
  beforePhoto?: string;
  afterPhoto: string;
  category: string;
  completedDate: string;
  approvedByAdmin: boolean;
}

export interface ProviderProfile {
  id: string;
  userId: string;
  businessName: string;
  category: string;
  subServices: string[];
  bio: string;
  visitCharge: number;
  rating: number;
  reviewCount: number;
  completedJobs: number;
  trustScore: number; // 0 - 100
  verificationStatus: 'pending' | 'verified' | 'rejected';
  verificationBadge: string;
  isAvailableNow: boolean;
  city: string;
  serviceAreas: string[];
  serviceRadiusKm: number;
  location: {
    lat: number;
    lng: number;
    areaName: string;
  };
  cnicMasked: string;
  cnicDocumentUrl?: string;
  businessProofUrl?: string;
  portfolio: PortfolioItem[];
  responseTimeMinutes: number;
  onTimePercentage: number;
  cancellationRatePercentage: number;
  weeklySchedule: {
    [key: string]: { open: string; close: string; active: boolean };
  };
  emergencyService: boolean;
}

export interface ServiceCategory {
  id: string;
  name: string;
  nameUrdu: string;
  icon: string;
  description: string;
  popular: boolean;
  emergencyEligible: boolean;
  typicalVisitCharge: number;
}

export type BookingStatus =
  | 'PENDING'
  | 'ACCEPTED'
  | 'REJECTED'
  | 'ARRIVING'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'DISPUTED';

export interface BookingStatusStep {
  status: BookingStatus;
  timestamp: string;
  note?: string;
}

export interface Booking {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  providerId: string;
  providerName: string;
  providerPhone?: string;
  providerAvatar?: string;
  categoryId: string;
  categoryName: string;
  problemDescription: string;
  photos: string[];
  preferredTime: string;
  isEmergency: boolean;
  status: BookingStatus;
  visitFee: number;
  additionalCharges?: number;
  finalBill?: number;
  platformCommissionRate: number; // e.g. 0.10 for 10%
  platformCommissionAmount?: number;
  providerEarnings?: number;
  paymentMethod: 'cash' | 'easypaisa' | 'jazzcash' | 'bank_transfer';
  paymentStatus: 'pending' | 'paid';
  location: {
    area: string;
    city: string;
    address: string;
    lat: number;
    lng: number;
  };
  notes?: string;
  cancellationReason?: string;
  statusHistory: BookingStatusStep[];
  hasReview: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  bookingId: string;
  customerId: string;
  customerName: string;
  providerId: string;
  rating: number; // 1-5
  comment: string;
  tags?: string[];
  providerResponse?: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  bookingId: string;
  senderId: string;
  senderRole: 'customer' | 'provider';
  text: string;
  timestamp: string;
  read: boolean;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  titleUrdu?: string;
  message: string;
  type: 'booking' | 'chat' | 'verification' | 'system';
  bookingId?: string;
  read: boolean;
  createdAt: string;
}

export interface UserReport {
  id: string;
  reporterId: string;
  reporterName: string;
  reporterRole: UserRole;
  targetId: string;
  targetName: string;
  targetType: 'provider' | 'customer';
  category: 'Fraud' | 'Bad behavior' | 'Unsafe' | 'Fake profile' | 'Payment issue' | 'Harassment' | 'Other';
  description: string;
  status: 'OPEN' | 'INVESTIGATING' | 'RESOLVED';
  adminNotes?: string;
  createdAt: string;
}

export interface PlatformSettings {
  commissionPercentage: number;
  emergencySurcharge: number;
  minVisitCharge: number;
  activeCity: string;
  supportedCities: string[];
}
