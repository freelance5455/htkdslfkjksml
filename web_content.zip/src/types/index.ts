export type UnitType = 'কেজি' | 'গ্রাম' | 'লিটার' | 'মিলি' | 'প্যাকেট' | 'পিস' | 'ডজন' | 'হালি' | 'বস্তা' | 'বক্স';

export type ProductCategory = 
  | 'চাল ও ডাল' 
  | 'তেল ও ঘি' 
  | 'পেঁয়াজ, আলু ও রসুন' 
  | 'মসলা ও লবণ' 
  | 'স্ন্যাক্স ও নুডলস' 
  | 'চা, চিনি ও বেকারি' 
  | 'দুগ্ধ ও ডিম' 
  | 'সাবান ও প্রসাধন' 
  | 'পানীয় ও পান মশলা' 
  | 'অন্যান্য';

export interface Product {
  id: string;
  nameBn: string;
  nameEn: string;
  category: ProductCategory;
  purchasePrice: number; // ক্রয় মূল্য (৳)
  sellPrice: number;     // বিক্রয় মূল্য (৳)
  unit: UnitType;
  stock: number;         // বর্তমান স্টক
  lowStockAlert: number; // সর্বনিম্ন স্টক সতর্কবার্তা
  barcode?: string;
  imageUrl?: string;
  description?: string;
}

export interface CartItem {
  id: string;
  productId: string;
  nameBn: string;
  nameEn: string;
  category: ProductCategory;
  purchasePrice: number;
  sellPrice: number;
  unit: UnitType;
  quantity: number;      // e.g. 2, 0.5, 1.25
  discount: number;      // per item discount (optional)
  lineTotal: number;     // (sellPrice * quantity) - discount
  lineCost: number;      // (purchasePrice * quantity)
}

export type PaymentMethod = 'CASH' | 'BKASH' | 'NAGAD' | 'DUE' | 'CARD';

export interface SaleInvoice {
  id: string;
  invoiceNo: string;
  createdAt: string;     // ISO timestamp
  customerName?: string;
  customerPhone?: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  netTotal: number;
  paidAmount: number;    // কাস্টমার যত টাকা দিল
  changeAmount: number;  // কাস্টমার ফেরত পাবে (যদি বেশি দেয়)
  dueAmount: number;     // বাকি টাকা (যদি কম দেয়)
  paymentMethod: PaymentMethod;
  cashierName: string;
  totalCost: number;     // Total cost of items sold
  grossProfit: number;   // netTotal - totalCost
  status: 'PAID' | 'PARTIAL' | 'DUE';
  notes?: string;
}

export type ExpenseCategory = 
  | 'RENT'          // দোকান ভাড়া
  | 'ELECTRICITY'   // বিদ্যুৎ বিল
  | 'SALARY'        // কর্মচারীর বেতন
  | 'TRANSPORT'     // পরিবহন ও যাতায়াত
  | 'TEA_SNACK'     // আপ্যায়ন ও চা-নাস্তা
  | 'REPAIR'        // মেরামত ও রক্ষণাবেক্ষণ
  | 'OTHER';        // অন্যান্য খরচ

export interface Expense {
  id: string;
  date: string;
  title: string;
  category: ExpenseCategory;
  amount: number;
  note?: string;
}

export interface PurchaseRecord {
  id: string;
  date: string;
  productId: string;
  productName: string;
  supplierName?: string;
  quantity: number;
  unit: UnitType;
  unitCost: number;
  totalCost: number;
  invoiceNo?: string;
  notes?: string;
}

export interface CustomerDueRecord {
  customerName: string;
  customerPhone: string;
  totalDue: number;
  invoices: {
    invoiceId: string;
    invoiceNo: string;
    date: string;
    dueAmount: number;
    subtotal?: number;
    paidAmount?: number;
    notes?: string;
    items?: CartItem[];
  }[];
  lastPaymentDate?: string;
}

export type UserRole = 'OWNER' | 'CASHIER';

export interface StoreProfile {
  name: string;
  tagline: string;
  address: string;
  phone: string;
  ownerName: string;
  currency: string;
  receiptFooterMessage: string;
  receiptWidth: '58mm' | '80mm' | 'A4';
  ownerPin: string;
}

export interface FirebaseSyncSettings {
  isConfigured: boolean;
  apiKey: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId?: string;
  lastSyncedAt?: string;
  autoSync: boolean;
}
