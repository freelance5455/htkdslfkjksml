export type TabType = 'home' | 'calculator' | 'phonecare' | 'tools' | 'about';

export type Language = 'en' | 'ur';
export type ThemeMode = 'system' | 'light' | 'dark';
export type AngleMode = 'deg' | 'rad';

export interface CalculationHistoryItem {
  id: string;
  expression: string;
  result: string;
  timestamp: number;
  category?: 'scientific' | 'financial' | 'conversion';
}

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  isPinned: boolean;
  category: string;
  createdAt: number;
  updatedAt: number;
}

export interface TodoItem {
  id: string;
  text: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  dueDate?: string;
  createdAt: number;
}

export interface ShoppingItem {
  id: string;
  name: string;
  quantity: string;
  estimatedPrice?: number;
  checked: boolean;
  category: string;
}

export interface ExpenseSplit {
  id: string;
  description: string;
  totalAmount: number;
  tipPercent: number;
  taxPercent: number;
  peopleCount: number;
  individualShares: { name: string; amount: number }[];
  date: number;
}

export interface DeviceSpecs {
  platform: string;
  userAgent: string;
  osName: string;
  osVersion: string;
  screenResolution: string;
  devicePixelRatio: number;
  colorDepth: number;
  logicalCores: number;
  deviceMemoryGb?: number;
  connectionType?: string;
  effectiveType?: string;
  downlinkMb?: number;
  rttMs?: number;
  online: boolean;
  batterySupported: boolean;
  batteryLevel?: number;
  batteryCharging?: boolean;
  chargingTime?: number;
  dischargingTime?: number;
  storageQuotaMb?: number;
  storageUsageMb?: number;
  storagePercent?: number;
  uptimeSeconds: number;
}

export interface UserSettings {
  theme: ThemeMode;
  language: Language;
  hapticFeedback: boolean;
  angleMode: AngleMode;
  saveHistory: boolean;
  maxHistoryItems: number;
  dashboardCards: {
    device: boolean;
    battery: boolean;
    storage: boolean;
    memory: boolean;
    network: boolean;
    shortcuts: boolean;
  };
}
