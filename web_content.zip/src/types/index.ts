export type Suit = 'spades' | 'hearts' | 'diamonds' | 'clubs';
export type CardRank = '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A';

export interface Card {
  id: string;
  suit: Suit;
  rank: CardRank;
  value: number; // 2..14 for ranking
}

export type PlayerPosition = 'bottom' | 'top' | 'left' | 'right';

export interface GamePlayer {
  id: string;
  name: string;
  avatar: string;
  score: number;
  team: 1 | 2; // Team 1: bottom (you) + top (partner); Team 2: left + right
  cardsCount: number;
  cards?: Card[];
  isDealer?: boolean;
  currentBid?: number | 'pass';
  tricksWonThisRound: number;
  totalRoundPoints: number;
  isReady?: boolean;
  level: number;
  title: string;
  isMuted?: boolean;
  isSpeaking?: boolean;
}

export interface BidRecord {
  playerId: string;
  bid: number | 'pass';
  bidPoints: number; // Calculated points value according to tabeona scale
}

export interface PlayedCard {
  playerId: string;
  playerPosition: PlayerPosition;
  card: Card;
}

export interface RoundTrick {
  trickNumber: number;
  cards: PlayedCard[];
  winnerPlayerId: string;
  ledSuit: Suit;
}

export interface RoundScoreRecord {
  roundNumber: number;
  declarerId: string;
  bid: number;
  bidValue: number;
  trumpSuit: Suit;
  team1Tricks: number;
  team2Tricks: number;
  team1ScoreChange: number;
  team2ScoreChange: number;
  scoresAfter: {
    bottom: number;
    top: number;
    left: number;
    right: number;
  };
}

export type GamePhase = 'dealing' | 'bidding' | 'trump_selection' | 'playing' | 'round_end' | 'game_over';

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  title: string;
  level: number;
  xp: number;
  nextLevelXp: number;
  coins: number;
  gems: number;
  realCashBalance: number; // Real Money cash balance ($ USD)
  kycVerified: boolean; // KYC / Age 18+ verification badge
  vipLevel: number;
  isVip: boolean;
  lastDailyBonusClaimDate?: string;
  dailyBonusStreak?: number; // Current streak 1..7
  phoneNumber?: string;
  phoneVerified?: boolean;
  twoFactorEnabled?: boolean;
  securityPin?: string; // 4-digit PIN for sensitive financial operations (اقتراح رقم 3)
  securityPinEnabled?: boolean;
  registeredDevices?: RegisteredDevice[];
  loginHistory?: LoginHistoryItem[];
  accountGroup: {
    groupId: string;
    accountsCount: number;
    maxAllowed: number; // 4
    accountIndex: number; // 1 to 4
  };
  role: 'OWNER' | 'ADMIN' | 'MANAGER' | 'MODERATOR' | 'CASHIER' | 'DISTRIBUTOR' | 'PLAYER';
}

export interface LoginHistoryItem {
  id: string;
  ipAddress: string;
  device: string;
  location: string;
  timestamp: string;
  status: 'SUCCESS' | 'SUSPICIOUS_BLOCKED' | 'OTP_CHALLENGED';
  actionTaken?: string;
}

export interface CashierRequest {
  id: string;
  playerId: string;
  playerName: string;
  type: 'DEPOSIT' | 'WITHDRAWAL';
  amount: number;
  currency: 'USD';
  method: 'USDT_TRC20' | 'CASHIER_DIRECT' | 'DISTRIBUTOR' | 'BANK_TRANSFER';
  walletAddressOrAccount: string;
  txHashOrReceipt?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  timestamp: string;
  processedBy?: string;
  notes?: string;
}

export type CurrencyTransferChannel =
  | 'ADMIN_TO_ACCOUNT'
  | 'ADMIN_TO_CASHIER'
  | 'CASHIER_TO_ACCOUNT';

export interface CashierAgent {
  id: string;
  name: string;
  code: string;
  branchName: string;
  avatar: string;
  status: 'ACTIVE' | 'SUSPENDED' | 'OFFLINE';
  balanceUsd: number;
  balanceCoins: number;
  balanceGems: number;
  totalTransferredToPlayers: number;
  totalReceivedFromAdmin: number;
  commissionRate: number;
  phone?: string;
}

export interface TransferVoucher {
  voucherId: string;
  channel: CurrencyTransferChannel;
  senderRole: string;
  senderName: string;
  senderId: string;
  receiverType: 'ACCOUNT' | 'CASHIER';
  receiverName: string;
  receiverId: string;
  currencyType: 'COINS' | 'GEMS' | 'REAL_USD';
  amount: number;
  fee: number;
  finalAmount: number;
  timestamp: string;
  reasonCategory: string;
  notes: string;
  auditHash: string;
  status: 'COMPLETED' | 'PENDING' | 'REJECTED';
  sourceLedgerTxId?: string;
}

export interface Friend {
  id: string;
  name: string;
  avatar: string;
  level: number;
  status: 'online' | 'in_room' | 'busy' | 'offline';
  game?: string;
  lastSeen?: string;
}

export interface RoomConfig {
  id: string;
  name: string;
  game: 'tarneeb' | 'trix' | 'chess' | 'ludo' | 'billiards' | 'backgammon';
  mode: string; // e.g. "طرنيب 41", "عادي"
  isPrivate: boolean;
  password?: string;
  stakeCoins: number;
  maxPlayers: number;
  currentPlayers: GamePlayer[];
  hostId: string;
  isLanHotspot?: boolean;
}

export interface SkinItem {
  id: string;
  name: string;
  game: string;
  category: 'card_back' | 'table_felt' | 'avatar_frame' | 'sound_pack';
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Royal';
  priceCoins?: number;
  priceGems?: number;
  previewUrl: string;
  status: 'DRAFT' | 'PUBLISHED' | 'UNPUBLISHED' | 'ARCHIVED';
  version: string; // e.g. "Royal Emerald v1"
  isOwned?: boolean;
  isEquipped?: boolean;
}

export interface TransactionRecord {
  transactionId: string;
  playerId: string;
  playerName: string;
  cashierOrAdminId: string;
  amount: number;
  currencyType: 'COINS' | 'GEMS' | 'REAL_USD';
  balanceBefore: number;
  balanceAfter: number;
  timestamp: string;
  status: 'COMPLETED' | 'PENDING' | 'REJECTED';
  sourceMethod:
    | 'REWARD'
    | 'PURCHASE'
    | 'CASHIER_TRANSFER'
    | 'GAME_FEE'
    | 'GIFT'
    | 'ADMIN_OVERRIDE'
    | 'TOURNAMENT_PRIZE'
    | 'SUBSCRIPTION';
  referenceNote: string;
  auditHash?: string;
  ipAddress?: string;
  sessionId?: string;
  ledgerSequence?: number;
  isSuspicious?: boolean;
  suspicionReason?: string;
  riskScore?: number;
}

export interface AiCheatIncident {
  caseId: string;
  playerId: string;
  playerName: string;
  riskScore: number; // 0..100
  flagReason: 'IMPOSSIBLE_MOVE' | 'COLLUSION_SUSPICION' | 'TIMING_ANOMALY' | 'MULTI_ACCOUNT_LINK' | 'SUDDEN_DISCONNECT_PATTERN';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'FLAGGED' | 'INVESTIGATING' | 'DISMISSED' | 'SANCTIONED';
  detectedAt: string;
  matchId: string;
  notes: string;
}

export interface SupportMessage {
  id: string;
  ticketId: string;
  senderType: 'PLAYER' | 'ADMIN' | 'SYSTEM';
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  senderRole?: string; // e.g. "إدارة TABEONA المركزية", "كاشير العمليات"
  text: string;
  timestamp: string;
  isRead: boolean;
  actionTaken?: {
    type: 'COMPENSATION_COINS' | 'COMPENSATION_GEMS' | 'TICKET_RESOLVED' | 'FORWARDED_TO_CASHIER' | 'ACCOUNT_VERIFIED';
    details: string;
    amount?: number;
  };
}

export type SupportCategory = 'FINANCIAL' | 'GAMEPLAY' | 'ACCOUNT' | 'TECHNICAL' | 'GENERAL';

export interface SupportTicket {
  id: string; // e.g. "TICK-8041"
  playerId: string;
  playerName: string;
  playerAvatar: string;
  playerLevel: number;
  playerVip: number;
  playerPhoneOrEmail?: string;
  category: SupportCategory;
  subject: string;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED';
  priority: 'URGENT' | 'HIGH' | 'NORMAL' | 'LOW';
  createdAt: string;
  updatedAt: string;
  assignedStaffName?: string;
  lastMessageSnippet: string;
  unreadAdminCount: number;
  unreadPlayerCount: number;
  messages: SupportMessage[];
  playerBalance?: {
    coins: number;
    gems: number;
    realCashBalance: number;
  };
}

export interface RegisteredDevice {
  id: string;
  deviceName: string;
  deviceType: 'mobile' | 'desktop' | 'tablet';
  browser: string;
  os: string;
  ipAddress: string;
  location: string;
  lastActive: string;
  isCurrent: boolean;
  isSuspicious?: boolean;
  suspicionReason?: string;
}


