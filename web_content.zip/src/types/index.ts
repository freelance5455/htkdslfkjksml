export interface StudentProfile {
  name: string;
  age: number;
  pin: string;
  school: string;
  grade: string;
  nisn: string;
  avatar: string;
  isProfileSetup: boolean;
}

export interface WalletBalance {
  wallet: number; // Saldo Uang Saku Harian
  savings: number; // Tabungan Berjangka / Leaderboard Score
}

export type PaymentMethodType = 'gopay' | 'dana' | 'bca' | 'bri' | 'mandiri' | 'bni' | 'shopeepay';

export interface PaymentProvider {
  id: PaymentMethodType;
  name: string;
  type: 'ewallet' | 'bank';
  accountTypeLabel: string;
  placeholder: string;
  color: string;
  bgLight: string;
  logoText: string;
  accountExample: string;
}

export type TransactionType = 'topup' | 'qris_payment' | 'qris_receive' | 'to_savings' | 'to_wallet';

export interface Transaction {
  id: string;
  type: TransactionType;
  title: string;
  category: 'topup' | 'canteen' | 'cooperative' | 'savings' | 'transfer' | 'class_cash' | 'other';
  amount: number;
  sourceAccount: string; // Nomor Rekening / Nomor HP GoPay/DANA
  paymentMethodName: string;
  timestamp: string;
  status: 'success' | 'pending' | 'failed';
  referenceCode: string;
  note?: string;
  merchantName?: string;
  destination: 'wallet' | 'savings';
}

export interface LeaderboardStudent {
  id: string;
  name: string;
  avatar: string;
  grade: string;
  school: string;
  savingsAmount: number;
  monthlyGrowth: number;
  badge: string;
  streakDays: number;
  isCurrentUser?: boolean;
}

export interface QrisMerchantPreset {
  id: string;
  name: string;
  category: string;
  defaultAmount: number;
  nmid: string;
  location: string;
  iconName: string;
}
