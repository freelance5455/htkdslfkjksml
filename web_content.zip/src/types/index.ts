export type SpaceType = 'adult' | 'parents';

export type LanguageCode = 'fr' | 'en' | 'es' | 'de' | 'it';

export interface UserProfile {
  id: string;
  email?: string;
  fullName?: string;
  language: LanguageCode;
  isGuest: boolean;
  createdAt: string;
}

export type ToolCategory =
  | 'crisis'
  | 'grounding'
  | 'breathing'
  | 'somatic'
  | 'hypnosis'
  | 'compassion'
  | 'parent_crisis'
  | 'co_regulation'
  | 'parent_care';

export interface ScriptStep {
  title: string;
  instruction: string;
  script: string;
  pauseDurationSeconds?: number;
  pauseNote?: string;
  somaticFocus?: string;
}

export interface RegulationTool {
  id: string;
  space: SpaceType;
  category: ToolCategory;
  titleKey: string;
  shortDescriptionKey: string;
  iconName: string;
  durationShortMin: number;
  durationFullMin: number;
  shortScript: ScriptStep[];
  fullScript: ScriptStep[];
  interactiveComponent?: 'breathing' | 'eft_adult' | 'eft_child' | 'grounding_54321';
  emergencyRelevant?: boolean;
  scientificBackgroundKey?: string;
}

export interface SessionRecord {
  id: string;
  userId: string;
  spaceType: SpaceType;
  toolId: string;
  toolTitle: string;
  durationSeconds: number;
  ratingBefore: number;
  ratingAfter: number;
  notes?: string;
  version: 'short' | 'full';
  createdAt: string;
}

export interface EmotionalLog {
  id: string;
  userId: string;
  primaryEmotion: string;
  intensityBefore: number;
  intensityAfter: number;
  context: SpaceType;
  notes?: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  isEmergencyAlert?: boolean;
  recommendedToolId?: string;
}
