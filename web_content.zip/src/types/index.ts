export interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  size: number; // bytes
  formattedSize: string;
  modified: string;
  ext?: string;
  itemsCount?: number;
  content?: string;
  permissions?: string;
}

export interface AdbStatus {
  connected: boolean;
  mode: 'disconnected' | 'wireless_pairing' | 'external_adb' | 'rootless_active';
  deviceModel: string;
  androidVersion: string;
  securityPatch: string;
  grantedPermissions: {
    systemAlertWindow: boolean;
    writeSecureSettings: boolean;
    dump: boolean;
    packageUsageStats: boolean;
  };
  lastActivatedAt?: string;
}

export interface CpuCoreMetric {
  id: number;
  name: string;
  cluster: 'efficiency' | 'performance' | 'prime';
  freqMhz: number;
  maxFreqMhz: number;
  usagePercent: number;
}

export interface SystemMetrics {
  monitoringMode: 'simple' | 'advanced_adb';
  // Simple Mode metrics
  cpuTemp: number; // Celsius
  batteryTemp: number; // Celsius
  batteryLevel: number; // percentage
  ramUsedGb: number;
  ramTotalGb: number;
  fps: number;
  fpsHistory: number[];
  cpuUsage: number; // percentage
  throttling: boolean;
  // Advanced ADB-only metrics (CPU Cores & GPU)
  gpuModel: string;
  gpuUsage: number; // %
  gpuTemp: number; // Celsius
  gpuFreqMhz: number;
  gpuMaxFreqMhz: number;
  gpuRenderer: string;
  cpuCores: CpuCoreMetric[];
  governor: string;
  thermalZoneGovernor: string;
}

export interface HudSettings {
  visible: boolean;
  expanded: boolean;
  opacity: number;
  scale: number;
  accentColor: 'white' | 'emerald' | 'cyan' | 'crimson';
  showFps: boolean;
  showCpuTemp: boolean;
  showBatteryTemp: boolean;
  showGpu: boolean;
  showRam: boolean;
  showCrosshair: boolean;
  position: { x: number; y: number };
}
