/* ============================================
   plix_ai studio — Type definitions
   ============================================ */

// --- Conversion source types ---
export type SourceType = 'zip' | 'html' | 'url' | 'pwa' | 'apk' | 'aab' | 'bundle';

export interface ImportSource {
  type: SourceType;
  label: string;
  icon: string;
  description: string;
  acceptedFormats?: string;
}

export interface UploadedFile {
  name: string;
  size: number;
  type: string;
  lastModified: number;
  dataUrl?: string;
}

export interface ImportData {
  sourceType: SourceType;
  file?: UploadedFile;
  url?: string;
  manifestUrl?: string;
  validated: boolean;
  errors: ValidationError[];
}

// --- Branding ---
export interface BrandingConfig {
  appName: string;
  displayName: string;
  packageId: string;
  versionName: string;
  versionCode: number;
  logoDataUrl?: string;
  primaryColor: string;
  accentColor: string;
  theme: 'light' | 'dark' | 'system';
  orientation: 'portrait' | 'landscape' | 'sensor' | 'unspecified';
  fullscreen: boolean;
  statusBarStyle: 'default' | 'light' | 'dark' | 'transparent';
  fontFamily: string;
}

// --- Build config ---
export type OutputFormat = 'apk' | 'aab';
export type MinSdkVersion = 21 | 23 | 24 | 26 | 28 | 30;

export interface KeystoreConfig {
  alias: string;
  password: string;
  keyPassword: string;
  cn: string;
  org: string;
  locality: string;
  state: string;
  country: string;
  validityYears: number;
  sha256Fingerprint?: string;
}

export interface Permission {
  id: string;
  name: string;
  description: string;
  dangerous: boolean;
  selected: boolean;
  category: string;
}

export interface DeepLink {
  scheme: string;
  host: string;
  pathPrefix: string;
}

export interface BuildConfig {
  outputFormat: OutputFormat;
  minSdk: MinSdkVersion;
  targetSdk: number;
  keystore: KeystoreConfig;
  permissions: Permission[];
  deepLinks: DeepLink[];
  enableJavascript: boolean;
  allowFileAccess: boolean;
  allowContentAccess: boolean;
  domStorageEnabled: boolean;
  useWideViewport: boolean;
  loadWithOverviewMode: boolean;
  supportZoom: boolean;
  hardwareAccelerated: boolean;
  mixedContentMode: 'never' | 'always' | 'compatibility';
}

// --- Build job ---
export type JobStatus =
  | 'pending'
  | 'validating'
  | 'preparing'
  | 'packaging'
  | 'signing'
  | 'uploading'
  | 'verifying'
  | 'completed'
  | 'failed'
  | 'cancelled';

export interface BuildStage {
  name: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'skipped';
  progress: number;
  message?: string;
  startedAt?: number;
  completedAt?: number;
}

export interface BuildLog {
  timestamp: number;
  level: 'info' | 'warn' | 'error' | 'debug';
  message: string;
}

export interface BuildJob {
  id: string;
  projectId: string;
  status: JobStatus;
  stages: BuildStage[];
  logs: BuildLog[];
  progress: number;
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
  artifactUrl?: string;
  artifactSize?: number;
  checksumSha256?: string;
  error?: string;
}

// --- Project ---
export type ProjectStatus = 'draft' | 'building' | 'completed' | 'failed' | 'archived';

export interface Project {
  id: string;
  name: string;
  packageId: string;
  sourceType: SourceType;
  branding: BrandingConfig;
  buildConfig: BuildConfig;
  importData: ImportData;
  status: ProjectStatus;
  lastBuildId?: string;
  createdAt: number;
  updatedAt: number;
  builds: BuildJob[];
}

// --- Templates ---
export interface Template {
  id: string;
  name: string;
  description: string;
  icon: string;
  sourceType: SourceType;
  defaultBranding: Partial<BrandingConfig>;
  tags: string[];
}

// --- Validation ---
export interface ValidationError {
  field?: string;
  message: string;
  severity: 'error' | 'warning' | 'info';
}

export interface PreflightCheck {
  id: string;
  name: string;
  description: string;
  status: 'pass' | 'fail' | 'warn' | 'skip' | 'pending';
  message?: string;
}

// --- Navigation ---
export type PageId = 'landing' | 'convert' | 'dashboard' | 'devtools' | 'settings';

export interface NavItem {
  id: PageId;
  label: string;
  icon: string;
  shortcut?: string;
}

// --- Settings ---
export interface AppSettings {
  darkMode: boolean;
  showDemoBadge: boolean;
  autoSave: boolean;
  buildNotifications: boolean;
  defaultMinSdk: MinSdkVersion;
  defaultOutputFormat: OutputFormat;
  defaultKeystoreValidity: number;
}

// --- CLI snippet ---
export interface CliSnippet {
  id: string;
  title: string;
  platform: 'github-actions' | 'gitlab-ci' | 'cli';
  code: string;
  description: string;
}