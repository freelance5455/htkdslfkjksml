export type Language = 'en' | 'am';

export type NavTab = 'solver' | 'jobs' | 'business' | 'profile';

export interface BusinessOption {
  id: string;
  title: string;
  modelSummary: string;
  pros: string[];
  cons: string[];
  operationalComplexity: 'Low' | 'Medium' | 'High';
}

export interface BudgetLineItem {
  item: string;
  costETB: string;
  essential: boolean;
}

export interface DayAction {
  dayNumber: number; // 1 to 7
  dayTitle: string;
  specificActions: string[];
  milestoneGoal: string;
}

export interface RevenueFormula {
  estimatedSalesCount: number;
  averageTransactionValueETB: number;
  commissionRatePercent: number;
  listingFeeETB: number;
  listingFeeCount?: number;
  calculationExplanation: string;
}

export interface ZeroBudgetOption {
  howToLaunchWithZeroBirr: string;
  tradeOffs: string;
}

export interface SafetyAndVerification {
  buyerVerificationSteps: string[];
  sellerVerificationSteps: string[];
  fraudPreventionGuidelines: string[];
  legalPaymentCompliance: string;
}

export interface SolvedOpportunity {
  id: string;
  originalProblem: string;
  category: string;
  opportunityTitle: string;
  tagline: string;
  createdAt: string;
  language: Language;

  // 1. Understand and analyze the exact problem
  problemAnalysis: {
    exactProblemBreakdown: string;
    rootCauses: string[];
    currentCostOfInaction: string;
  };

  // 2. Affected people and potential customers
  affectedAndCustomers: {
    affectedDemographics: string;
    payingCustomers: string[];
    whyTheyWillPay: string;
  };

  // 3. Suggest 3 specific and realistic business solutions
  candidateSolutions: BusinessOption[];

  // 4. Select the most practical solution and explain why
  recommendedSolution: {
    solutionTitle: string;
    selectionRationale: string;
    howItWorksInPractice: string;
  };

  // 5. Realistic startup budget in Ethiopian Birr (ETB) & Zero-Budget option
  startupBudget: {
    totalEstimatedETB: string;
    lineItems: BudgetLineItem[];
    lowCapitalTip: string;
    zeroBudgetOption?: ZeroBudgetOption;
  };

  // 6. How the business will generate income
  incomeModel: {
    revenueStreams: string[];
    pricingStrategyETB: string;
    paymentMethods: string[];
  };

  // 7. Estimate possible revenue and expenses (clearly labeled estimates & calculation)
  financialEstimates: {
    estimatedMonthlyRevenueETB: string;
    estimatedMonthlyExpensesETB: string;
    estimatedMonthlyNetETB: string;
    expenseBreakdown: string[];
    disclaimer: string;
    revenueFormula?: RevenueFormula;
    factsConfirmed?: string[];
    assumptionsAndEstimates?: string[];
  };

  // 8. Detailed 7-day action plan (never promise sales in 7 days)
  sevenDayActionPlan: DayAction[];

  // 9. Skills and resources required
  skillsAndResources: {
    requiredSkills: string[];
    physicalEquipment: string[];
    digitalTools: string[];
  };

  // 10. Identify risks and how to reduce them
  risksAndMitigations: {
    risk: string;
    mitigation: string;
  }[];

  // 11. Suggest ways to test market demand before investing money
  marketDemandTests: {
    testMethod: string;
    howToConduct: string;
    successSignal: string;
  }[];

  // 12. Never claim market demand is verified without evidence
  validationStatus: {
    isHypothesis: boolean;
    evidenceStatement: string;
  };

  // Buyer & Seller Safety, Verification & Safe Payments
  safetyAndVerification?: SafetyAndVerification;

  // Backward-compatibility properties
  marketOpportunity?: string;
  proposedSolution?: string;
  monetizationModel?: string[];
  stepByStepPlan?: {
    phase: string;
    duration: string;
    actions: string[];
  }[];
  requiredSkills?: string[];
  estimatedStartupBudget?: string;
  keyRisksAndMitigations?: {
    risk: string;
    mitigation: string;
  }[];
  immediateNext24Hours?: string;
}

export interface JobListing {
  id: string;
  title: string;
  titleAm: string;
  company: string;
  location: string;
  locationType: 'remote' | 'on-site' | 'hybrid';
  category: 'tech' | 'agriculture' | 'green' | 'business' | 'creative' | 'logistics';
  type: 'full-time' | 'part-time' | 'contract' | 'freelance';
  salaryRange: string;
  description: string;
  descriptionAm: string;
  requirements: string[];
  requirementsAm: string[];
  postedAt: string;
  problemSolved: string;
  problemSolvedAm: string;
}

export interface BusinessBlueprint {
  id: string;
  title: string;
  titleAm: string;
  category: 'agriculture' | 'green' | 'tech' | 'trade' | 'services' | 'micro';
  capitalRequired: 'micro' | 'low' | 'medium';
  capitalAmount: string;
  roiTimeline: string;
  demandScore: number; // 1-100
  summary: string;
  summaryAm: string;
  keySteps: string[];
  keyStepsAm: string[];
  targetAudience: string;
  targetAudienceAm: string;
}

export interface UserProfileData {
  userId: string;
  displayName: string;
  title: string;
  email: string;
  phone: string;
  location: string;
  bio: string;
  preferredLanguage: Language;
  skills: string[];
  education: string;
  experienceYears: number;
}

export interface JobApplication {
  id: string;
  jobId: string;
  jobTitle: string;
  company: string;
  appliedAt: string;
  status: 'submitted' | 'reviewing' | 'interview' | 'accepted';
  coverNote?: string;
}

export interface SystemStatus {
  app: string;
  tagline: string;
  geminiConfigured: boolean;
  firebase: {
    configured: boolean;
    projectId: string | null;
    provider: string;
  };
}
