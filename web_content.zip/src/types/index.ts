export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced';

export type CategoryName =
  | 'Mathematics'
  | 'Physics'
  | 'Chemistry'
  | 'Engineering'
  | 'Robotics'
  | 'Aerospace'
  | 'Electronics'
  | 'Statistics'
  | string;

export type LearningMode = 'student' | 'engineering';

export interface FormulaVariable {
  symbol: string;
  name: string;
  unit: string;
  description?: string;
  defaultValue?: number;
  min?: number;
  max?: number;
  step?: number;
}

export interface Formula {
  id: string;
  title: string;
  slug?: string;
  category: CategoryName;
  subcategory: string;
  formula: string; // Display LaTeX/Unicode expression: e.g. "F = m × a"
  calculationExpression?: string;
  resultVariable?: string;
  resultUnit?: string;
  expression?: string;
  solveFor?: Record<string, string>;
  variables: FormulaVariable[];
  units?: string[];
  description: string;
  studentExplanation?: string;
  engineeringExplanation?: string;
  usage?: string;
  example?: string;
  difficulty: Difficulty;
  tags: string[];
  popularity: number;
  featured?: boolean;
  published?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface Category {
  id: string;
  name: CategoryName;
  slug: string;
  description: string;
  icon: string;
  subcategories: string[];
  order?: number;
  enabled?: boolean;
}

export interface CalculationResult {
  value: number;
  formatted: string;
  unit: string;
  targetSymbol?: string;
  targetName?: string;
  steps: string[];
  error?: string;
}

export interface CalculationHistoryItem {
  id: string;
  formulaId: string;
  formulaTitle: string;
  formulaExpression: string;
  targetSymbol?: string;
  inputs: Record<string, number>;
  result: string | number;
  resultUnit: string;
  steps: string[];
  timestamp: number;
  createdAt?: string;
  userId?: string;
}

export interface SavedCalculationItem {
  id: string;
  name: string;
  formulaId: string;
  formulaTitle: string;
  formulaExpression: string;
  targetSymbol: string;
  inputs: Record<string, number>;
  result: string | number;
  resultUnit: string;
  steps: string[];
  timestamp: number;
}

export interface FavoriteItem {
  id: string;
  userId: string;
  formulaId: string;
  formulaTitle: string;
  formulaExpression: string;
  category: string;
  createdAt: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  name?: string;
  photoURL?: string;
  role: 'user' | 'admin';
  createdAt: string;
  lastLogin: string;
}

export interface FeedbackItem {
  id?: string;
  userId?: string;
  name: string;
  email: string;
  message: string;
  rating: number;
  status?: 'pending' | 'reviewed' | 'resolved';
  createdAt?: string;
}

export interface AppConfig {
  appName: string;
  appDescription?: string;
  maintenanceMode: boolean;
  allowedRegistration?: boolean;
  featuredCategory?: string;
  featuredFormulaId?: string;
  defaultTheme?: string;
  bannerMessage?: string;
}

export interface PracticeQuestion {
  id: string;
  formulaId: string;
  formulaTitle: string;
  question: string;
  given: Record<string, number>;
  targetSymbol: string;
  targetUnit: string;
  options: { label: string; value: string; isCorrect: boolean }[];
  explanation: string;
  steps: string[];
}

export interface AppSettings {
  theme: 'dark' | 'light' | 'system';
  language: 'en' | 'bn';
  learningMode: LearningMode;
  soundEnabled: boolean;
  hapticEnabled: boolean;
  showStepByStep: boolean;
  autoSaveHistory: boolean;
  scientificNotation: boolean;
}
