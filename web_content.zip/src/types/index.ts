export type Role = 'user' | 'admin';

export type ReactionType = 'like' | 'love' | 'haha' | 'wow' | 'sad' | 'angry';

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  username: string;
  bio: string;
  photoURL: string;
  coverURL?: string;
  role: Role;
  followersCount: number;
  followingCount: number;
  location?: string;
  website?: string;
  createdAt: string;
  isVerified?: boolean;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorUsername: string;
  authorPhotoURL: string;
  authorIsAdmin?: boolean;
  content: string;
  mediaType: 'none' | 'image' | 'video';
  mediaUrl?: string;
  privacy: 'public' | 'friends';
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  createdAt: string;
  userReaction?: ReactionType | null;
  isSaved?: boolean;
  flagged?: boolean;
  flagReason?: string;
}

export interface CommentItem {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorPhotoURL: string;
  text: string;
  createdAt: string;
  likesCount: number;
  userLiked?: boolean;
}

export interface Reel {
  id: string;
  authorId: string;
  authorName: string;
  authorUsername: string;
  authorPhotoURL: string;
  caption: string;
  videoUrl: string;
  soundTitle: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  createdAt: string;
  userLiked?: boolean;
  flagged?: boolean;
}

export interface Story {
  id: string;
  authorId: string;
  authorName: string;
  authorPhotoURL: string;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  recipientId: string;
  senderId: string;
  senderName: string;
  senderPhotoURL: string;
  type: 'like' | 'comment' | 'follow' | 'system';
  message: string;
  targetId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface ContentReport {
  id: string;
  reporterId: string;
  reporterName: string;
  targetType: 'post' | 'reel' | 'user';
  targetId: string;
  targetAuthorName?: string;
  reason: string;
  status: 'pending' | 'resolved';
  createdAt: string;
}
