export type Language = 'ar' | 'fr' | 'en';

export type HunterRank = 'E' | 'D' | 'C' | 'B' | 'A' | 'S';

export interface MedicalTerm {
  id: string;
  termFr: string;
  termAr: string;
  termEn: string;
  definitionFr: string;
  definitionAr: string;
  definitionEn: string;
  category: string;
  subCategory?: string;
  exampleFr: string;
  exampleAr: string;
  phonetic?: string;
  roots?: string[];
  prefixes?: string[];
  suffixes?: string[];
  acronym?: string;
  difficulty: 'beginner' | 'intermediate' | 'expert';
  clinicalTip?: string;
}

export interface RadiologyLesson {
  id: string;
  titleAr: string;
  titleFr: string;
  titleEn: string;
  category: 'xray' | 'ct' | 'mri' | 'ultrasound' | 'mammography' | 'radioprotection' | 'positioning';
  rankRequired: HunterRank;
  xpReward: number;
  readingMinutes: number;
  summaryAr: string;
  summaryFr: string;
  sections: {
    titleAr: string;
    titleFr: string;
    contentAr: string;
    contentFr: string;
    keyPoints: string[];
    warning?: string;
  }[];
  technicalParams?: {
    kv?: string;
    mas?: string;
    distance?: string;
    grid?: boolean;
    patientInstructionAr?: string;
    patientInstructionFr?: string;
  };
  scenarioQuiz?: {
    questionAr: string;
    questionFr: string;
    optionsAr: string[];
    optionsFr: string[];
    correctIndex: number;
    explanationAr: string;
    explanationFr: string;
  };
}

export interface AnatomyPart3D {
  id: string;
  nameFr: string;
  nameAr: string;
  nameEn: string;
  system: 'skeletal' | 'organ' | 'head' | 'thorax' | 'spine' | 'pelvis' | 'limbs';
  descriptionAr: string;
  descriptionFr: string;
  descriptionEn: string;
  radiographicIncidence: string;
  clinicalNoteAr: string;
  color: string;
  meshType: string;
}

export interface HunterProfile {
  name: string;
  title: string;
  level: number;
  currentXp: number;
  nextLevelXp: number;
  rank: HunterRank;
  hearts: number;
  maxHearts: number;
  lastHeartRefill: number;
  streak: number;
  lastActiveDate: string;
  coins: number;
  completedLessonIds: string[];
  masteredTermIds: string[];
  favoriteTermIds: string[];
  difficultTermIds: string[];
  mistakeQuestionIds: string[];
  achievements: {
    id: string;
    titleAr: string;
    titleFr: string;
    descAr: string;
    icon: string;
    unlocked: boolean;
    unlockedAt?: string;
  }[];
  settings: {
    language: Language;
    soundEnabled: boolean;
    voiceSpeed: number;
    showAura: boolean;
  };
}

export interface QuizQuestion {
  id: string;
  type: 'mcq' | 'true_false' | 'matching';
  questionAr: string;
  questionFr: string;
  questionEn: string;
  optionsAr: string[];
  optionsFr: string[];
  optionsEn: string[];
  correctIndex: number;
  explanationAr: string;
  explanationFr: string;
  category: string;
  rank: HunterRank;
}

export interface LeaderboardUser {
  id: string;
  name: string;
  wilaya: string;
  rank: HunterRank;
  level: number;
  xp: number;
  streak: number;
  avatarSeed: string;
  isCurrentUser?: boolean;
}
