export interface Member {
  id: string;
  name: string;
  amount: number;
  unit: string;
  index: number;
}

export interface PaymentState {
  [key: string]: {
    paid: boolean;
    paidAt?: string;
    method?: 'Cash' | 'UPI' | 'Bank' | 'Other';
    notes?: string;
  };
}

export type UnitKey = '1' | '2' | '3' | '4' | '5' | '6' | '7' | 'MISC';

export interface UnitStats {
  total: number;
  collected: number;
  pending: number;
  totalMembers: number;
  paidMembers: number;
  percentage: number;
}

export interface AIImageItem {
  id: string;
  url: string;
  prompt: string;
  type: 'generated' | 'edited';
  timestamp: string;
  aspectRatio: string;
}
