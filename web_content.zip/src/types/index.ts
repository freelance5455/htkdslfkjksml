export type AccountStatus = 'pending' | 'processing' | 'completed' | 'cancelled';

export interface InstagramAccount {
  id: string;
  username: string;
  password: string;
  followers_requested: number;
  status: AccountStatus;
  created_by: string;
  created_at: string;
  updated_at?: string;
}

export interface AppSettings {
  admin_code: string;
  app_title: string;
  app_subtitle: string;
  form_title: string;
  form_subtitle: string;
  coins_default?: number;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  isAdminUnlock?: boolean;
  actionButton?: {
    label: string;
    action: 'open_admin' | 'how_to_use' | 'select_followers';
  };
}

export interface FollowerPackage {
  count: number;
  label: string;
  costCoins: number;
  speed: string;
  retentionRate: string;
  tag?: string;
  highlight?: boolean;
}
