export type AppLanguage = 'en' | 'hi' | 'as' | 'bn';

export interface Ebook {
  id: string;
  title: string;
  subtitle: string;
  author: string;
  publisher: string;
  categoryId: string;
  subCategory: string;
  targetExam: string;
  language: 'English' | 'Hindi' | 'Assamese' | 'Bengali' | 'Bilingual (Eng/Hindi)' | 'Bilingual (Eng/Assamese)';
  price: number;
  originalPrice: number;
  discountPercent: number;
  isFree: boolean;
  isBestseller?: boolean;
  isFeatured?: boolean;
  isNewArrival?: boolean;
  isComboOffer?: boolean;
  rating: number;
  ratingCount: number;
  pageCount: number;
  fileSize: string;
  format: 'PDF' | 'EPUB' | 'Interactive HTML';
  coverGradient: string;
  coverAccent: string;
  coverBadge?: string;
  description: string;
  features: string[];
  tableOfContents: { chapterNumber: number; title: string; pages: string; isSample?: boolean }[];
  sampleContent: {
    title: string;
    chapterName: string;
    text: string;
    sampleQuestions: { q: string; a: string; explanation: string }[];
  };
  fullHtmlContent?: string;
  hasPdfUploaded: boolean;
  pdfFileName?: string;
  lastUpdated: string;
  edition: string;
  isbn?: string;
  officialSourceUrl?: string;
}

export interface Category {
  id: string;
  name: string;
  nameKey: string;
  iconName: string;
  gradient: string;
  textColor: string;
  borderAccent: string;
  count: number;
  subCategories: string[];
  description: string;
}

export interface CartItem {
  ebookId: string;
  ebook: Ebook;
  addedAt: string;
}

export interface Coupon {
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderValue: number;
  description: string;
  expiryDate: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  items: {
    ebookId: string;
    title: string;
    price: number;
    language: string;
  }[];
  subtotal: number;
  discount: number;
  couponApplied?: string;
  total: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  state: string;
  paymentMethod: 'UPI' | 'Card' | 'NetBanking' | 'Wallet' | 'Free';
  paymentStatus: 'VERIFIED_PAID' | 'DEMO_PAID' | 'PENDING' | 'FAILED';
  transactionId: string;
}

export interface ExamUpdate {
  id: string;
  title: string;
  examName: string;
  organization: string;
  category: string;
  notificationDate: string;
  lastDate?: string;
  examDate?: string;
  officialUrl: string;
  sourceNote: string;
  status: 'Notification Released' | 'Admit Card Available' | 'Exam Date Announced' | 'Result Declared';
  summary: string;
  syllabusHighlights: string[];
  lastUpdated: string;
}

export interface CurrentAffairItem {
  id: string;
  title: string;
  date: string;
  monthYear: string;
  category: 'National' | 'Assam & NE' | 'International' | 'Economy' | 'Science & Tech' | 'Sports';
  highlights: string[];
  isMonthlyPdf: boolean;
  pages: number;
  fileSize: string;
  freeDownloadable: boolean;
}

export interface MockTestQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  topic: string;
}

export interface MockTest {
  id: string;
  title: string;
  exam: string;
  durationMinutes: number;
  totalQuestions: number;
  marksPerQuestion: number;
  negativeMark: number;
  difficulty: 'Easy' | 'Moderate' | 'Advanced';
  questions: MockTestQuestion[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  state: string;
  targetExam: string;
  preferredLanguage: AppLanguage;
  joinedDate: string;
  isAdmin: boolean;
  studyStreakDays: number;
  hoursRead: number;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  linkAction?: string;
  type: 'order' | 'update' | 'offer' | 'exam';
}
