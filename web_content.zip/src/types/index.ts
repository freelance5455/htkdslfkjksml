/**
 * বিল্ডিং কন্ট্রাক্টর ও মেস ম্যানেজার - ডেটা টাইপস
 */

export type LabourRoleType = 
  | 'mess_and_site'   // মেসে থাকে ও সাইটে কাজ করে
  | 'mess_only'       // মেসে থাকে কিন্তু বাইরে নিজের কাজ খুঁজে খায়
  | 'site_only';      // সাইটে কাজ করে কিন্তু মেসে থাকে না

export interface Labour {
  id: string;
  name: string;
  phone: string;
  trade: string; // যেমন: রাজমিস্ত্রি, জোগাড়ে/হেল্পার, রড বাইন্ডার, ইত্যাদি
  roleType: LabourRoleType;
  assignedSiteId?: string;
  dailyWageRate: number; // দৈনিক মজুরি রেট (₹)
  messStayStartDate: string; // মেসে ওঠার তারিখ (YYYY-MM-DD)
  messStayEndDate?: string | null; // মেস ছাড়ার তারিখ (না ছাড়লে null)
  isActive: boolean;
  notes?: string;
  createdAt: string;
}

export interface EngineerPayment {
  id: string;
  siteId: string;
  date: string;
  amount: number;
  paymentMethod: 'cash' | 'bank' | 'upi' | 'cheque';
  receiptNo?: string;
  note?: string;
}

export interface Site {
  id: string;
  name: string;
  address: string;
  engineerName: string;
  engineerPhone: string;
  flatCommission: number; // নির্দিষ্ট ফ্ল্যাট কমিশন (টাকা/₹, শতকরা নয়)
  status: 'active' | 'completed' | 'on_hold';
  startDate: string;
  targetEndDate?: string;
  notes?: string;
}

export interface SiteAttendanceRecord {
  id: string;
  siteId: string;
  labourId: string;
  date: string;
  daysWorked: number; // e.g., 1.0, 0.5, 1.5 (পূর্ণ দিন বা হাফ দিন)
  wageRate: number; // সেদিনের রেট (₹)
  overtimeHours?: number;
  note?: string;
}

export interface LabourAdvancePayment {
  id: string;
  labourId: string;
  siteId?: string;
  date: string;
  amount: number;
  paymentMethod: 'cash' | 'upi' | 'bank';
  note?: string;
}

export type MessExpenseCategory = 
  | 'bazar'          // বাজার খরচ
  | 'gas'            // গ্যাস সিলিন্ডার
  | 'cook_salary'    // বাবুর্চির বেতন
  | 'electricity'    // বিদ্যুৎ বিল
  | 'water_repairs'  // জল ও মেরামত
  | 'other';         // অন্যান্য খরচ

export interface MessExpense {
  id: string;
  date: string;
  category: MessExpenseCategory;
  title: string;
  amount: number;
  paidBy: string; // যেমন: 'কন্ট্রাক্টর' বা 'মেস ম্যানেজার তহবিল'
  note?: string;
}

export interface MessCollection {
  id: string;
  labourId: string;
  type: 'meal_cost' | 'room_rent'; // সাপ্তাহিক খাবার খরচ বা মাসিক রুম ভাড়া সংগ্রহ
  periodLabel: string; // যেমন: '১ম সপ্তাহ (মার্চ)' বা 'মার্চ ২০২৫'
  date: string;
  amount: number;
  paymentMethod: 'cash' | 'upi';
  note?: string;
}

export interface RoomOwnerConfig {
  ownerName: string;
  ownerPhone: string;
  propertyAddress: string;
  totalRooms: number;
  perHeadMonthlyRate: number; // বাড়িওয়ালার প্রতি লেবার পিছু মাসিক ভাড়া (₹)
  billingMonth: string; // YYYY-MM
}

export interface LandlordPayment {
  id: string;
  date: string;
  amount: number;
  forMonth: string; // যেমন: "2025-03" বা "মার্চ ২০২৫"
  paymentMethod: 'cash' | 'bank' | 'upi' | 'cheque';
  receiptNo?: string;
  note?: string;
}

export interface ProRataLabourRentCalculation {
  labourId: string;
  labourName: string;
  roleType: LabourRoleType;
  phone: string;
  stayStartDate: string;
  stayEndDate: string | null;
  activeDaysInMonth: number;
  totalDaysInMonth: number;
  dailyRate: number;
  calculatedRent: number;
  collectedRent: number;
  dueRent: number;
}
