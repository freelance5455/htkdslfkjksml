// ============================================================
// AI CREATOR STUDIO — TYPE DEFINITIONS
// CORE 1.0 | SADRAQUE NGOLA
// ============================================================

// --- AUTH ---
export interface User {
  id: string;
  name: string;
  email: string;
  role: "OWNER";
  avatar?: string;
  createdAt: string;
}

// --- REQUEST ANALYSIS ---
export type ContentType =
  | "VIDEO" | "SHORT" | "REEL" | "IMAGE" | "THUMBNAIL"
  | "SCRIPT" | "STORYBOARD" | "MUSIC" | "VOICE" | "SFX"
  | "CHILDREN_VIDEO" | "YOUTUBE_VIDEO" | "TIKTOK_VIDEO"
  | "INSTAGRAM_POST" | "FACEBOOK_POST" | "PODCAST" | "COURSE";

export type Platform =
  | "YOUTUBE"
  | "TIKTOK"
  | "INSTAGRAM"
  | "FACEBOOK"
  | "FEBSPOT"
  | "RUMBLE"
  | "BILIBILI"
  | "DAILYMOTION"
  | "VIMEO"
  | "UOL_MAIS"
  | "SAPO_VIDEOS"
  | "GENERAL";
export type Language = "PT" | "PT_BR" | "PT_PT" | "EN" | "ES" | "FR" | "DE";
export type Tone = "HAPPY" | "SERIOUS" | "EDUCATIONAL" | "HUMOROUS" | "DRAMATIC" | "CALM" | "ENERGETIC" | "EMOTIONAL";
export type ContentSafetyStatus = "SAFE" | "NEEDS_REVIEW" | "BLOCKED";

export interface AgeRange {
  label: string;
  min?: number;
  max?: number;
  category: "0-2" | "1-3" | "3-5" | "5-8" | "8-12" | "TEENS" | "ADULT" | "GENERAL";
}

export interface AnalyzedRequest {
  intent: string;
  contentType: ContentType;
  topic: string;
  audience: AgeRange;
  platform: Platform;
  language: Language;
  duration?: number; // seconds
  style?: string;
  tone: Tone;
  format?: string;
  requirements: string[];
  rawInput: string;
  safetyStatus: ContentSafetyStatus;
  safetyNotes?: string;
}

// --- CONTENT BRIEF ---
export interface ContentBrief {
  id: string;
  projectId: string;
  title: string;
  objective: string;
  audience: AgeRange;
  duration: number;
  platform: Platform;
  format: string;
  style: string;
  tone: Tone;
  structure: string[];
  requiredElements: string[];
  keywords: string[];
  language: Language;
  status: "DRAFT" | "APPROVED" | "REGENERATING";
  createdAt: string;
  version: number;
}

// --- SCRIPT ---
export interface ScriptSection {
  id: string;
  type: "HOOK" | "INTRO" | "MAIN" | "TRANSITION" | "CTA" | "OUTRO";
  title: string;
  content: string;
  duration: number; // seconds
  narration?: string;
  onScreenText?: string;
}

export interface Script {
  id: string;
  projectId: string;
  title: string;
  sections: ScriptSection[];
  totalDuration: number;
  language: Language;
  tone: Tone;
  version: number;
  status: "DRAFT" | "APPROVED" | "EDITING";
  createdAt: string;
  updatedAt: string;
}

// --- STORYBOARD ---
export interface StoryboardScene {
  id: string;
  sceneNumber: number;
  duration: number;
  visualDescription: string;
  narration: string;
  dialogue?: string;
  onScreenText?: string;
  music?: string;
  soundEffects?: string[];
  cameraDirection?: string;
  imagePrompt: string;
  videoPrompt: string;
  imageUrl?: string;
  videoUrl?: string;
  status: TaskStatus;
}

export interface Storyboard {
  id: string;
  projectId: string;
  scenes: StoryboardScene[];
  totalScenes: number;
  totalDuration: number;
  version: number;
  status: "DRAFT" | "APPROVED" | "EDITING";
  createdAt: string;
}

// --- CHARACTERS ---
export interface CharacterProfile {
  id: string;
  projectId: string;
  name: string;
  description: string;
  appearance: string;
  clothing: string;
  age?: number;
  species?: string;
  colors: string[];
  visualStyle: string;
  referenceImages: string[];
}

// --- MEDIA ---
export type MediaType = "IMAGE" | "VIDEO" | "VOICE" | "MUSIC" | "SFX" | "THUMBNAIL" | "SUBTITLE" | "RENDER";
export type TaskStatus = "PENDING" | "QUEUED" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED";

export interface MediaAsset {
  id: string;
  projectId?: string;
  projectTitle?: string;
  type: MediaType;
  name: string;
  url?: string;
  thumbnailUrl?: string;
  status: TaskStatus;
  prompt?: string;
  provider?: string;
  model?: string;
  duration?: number;
  dimensions?: { width: number; height: number };
  size?: number;
  format?: string;
  metadata?: Record<string, unknown>;
  estimatedCost?: number;
  createdAt: string;
  updatedAt?: string;
}

export interface MediaPlanItem {
  sceneId: string;
  sceneNumber: number;
  resources: MediaType[];
  imagePrompt?: string;
  videoPrompt?: string;
  voiceText?: string;
  musicGenre?: string;
  sfxList?: string[];
}

export interface MediaPlan {
  id: string;
  projectId: string;
  items: MediaPlanItem[];
  totalAssets: number;
  estimatedCost: number;
  status: "DRAFT" | "APPROVED" | "GENERATING";
  createdAt: string;
}

// --- TIMELINE ---
export type TrackType = "VIDEO" | "IMAGE" | "VOICE" | "MUSIC" | "SFX" | "TEXT" | "SUBTITLE";

export interface TimelineClip {
  id: string;
  trackType: TrackType;
  assetId?: string;
  startTime: number;
  duration: number;
  volume?: number;
  fadeIn?: number;
  fadeOut?: number;
  text?: string;
  style?: Record<string, string>;
}

export interface TimelineTrack {
  id: string;
  type: TrackType;
  name: string;
  muted: boolean;
  solo: boolean;
  volume: number;
  clips: TimelineClip[];
}

export interface Timeline {
  id: string;
  projectId: string;
  tracks: TimelineTrack[];
  totalDuration: number;
  fps: number;
  resolution: { width: number; height: number };
  version: number;
  createdAt: string;
}

// --- TASKS ---
export interface AITask {
  id: string;
  projectId?: string;
  type: string;
  status: TaskStatus;
  title: string;
  description?: string;
  input?: Record<string, unknown>;
  output?: Record<string, unknown>;
  error?: string;
  retryCount: number;
  progress?: number;
  estimatedCost?: number;
  provider?: string;
  model?: string;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
}

// --- SUBTITLES ---
export interface SubtitleEntry {
  id: string;
  startTime: number;
  endTime: number;
  text: string;
  speaker?: string;
}

export interface SubtitleTrack {
  id: string;
  projectId: string;
  language: Language;
  entries: SubtitleEntry[];
  format: "SRT" | "VTT";
  embedded: boolean;
  createdAt: string;
}

// --- PROJECT ---
export type ProjectStatus =
  | "IDEA" | "BRIEFING" | "SCRIPTING" | "STORYBOARDING"
  | "MEDIA_PLANNING" | "GENERATING" | "EDITING" | "REVIEW"
  | "RENDERING" | "COMPLETED" | "FAILED";

export type OutputFormat =
  | "YOUTUBE_1080p" | "YOUTUBE_4K" | "SHORTS_1080p"
  | "TIKTOK_1080p" | "INSTAGRAM_SQUARE" | "INSTAGRAM_PORTRAIT"
  | "INSTAGRAM_LANDSCAPE" | "FACEBOOK_1080p"
  | "FEBSPOT_1080p" | "RUMBLE_1080p" | "BILIBILI_1080p"
  | "DAILYMOTION_1080p" | "VIMEO_1080p" | "UOL_MAIS_1080p" | "SAPO_VIDEOS_1080p";

export interface ProjectVersion {
  id: string;
  type: "BRIEF" | "SCRIPT" | "STORYBOARD" | "TIMELINE";
  version: number;
  data: Record<string, unknown>;
  createdAt: string;
  label?: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
  attachments?: string[];
}

import type { ContentPackage } from "./contentPackage";
import type { YouTubeSEOPackage, RepurposedClip, ThumbnailAnalysis, ContentSafetyReport } from "./core2";
export * from "./contentPackage";
export * from "./core2";

export interface Project {
  id: string;
  title: string;
  description?: string;
  status: ProjectStatus;
  contentType: ContentType;
  platform: Platform;
  outputFormats: OutputFormat[];
  thumbnail?: string;
  analyzedRequest?: AnalyzedRequest;
  brief?: ContentBrief;
  script?: Script;
  storyboard?: Storyboard;
  mediaPlan?: MediaPlan;
  timeline?: Timeline;
  assets: MediaAsset[];
  subtitles?: SubtitleTrack;
  characters: CharacterProfile[];
  tasks: AITask[];
  versions: ProjectVersion[];
  conversation: ChatMessage[];
  settings: ProjectSettings;
  tags: string[];
  contentPackage?: ContentPackage;
  seoPackage?: YouTubeSEOPackage;
  repurposedClips?: RepurposedClip[];
  thumbnailAnalysis?: ThumbnailAnalysis;
  safetyReport?: ContentSafetyReport;
  createdAt: string;
  updatedAt: string;
}

export interface ProjectSettings {
  language: Language;
  outputFormat: OutputFormat;
  targetDuration?: number;
  autoEdit: boolean;
  autoSubtitles: boolean;
  watermark: boolean;
  brandKit?: boolean;
}

// --- IDEAS ---
export interface Idea {
  id: string;
  title: string;
  description: string;
  contentType?: ContentType;
  platform?: Platform;
  tags: string[];
  status: "RAW" | "REFINED" | "CONVERTED";
  projectId?: string;
  createdAt: string;
  updatedAt: string;
}

// --- CALENDAR ---
export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  platform?: Platform;
  projectId?: string;
  status: "PLANNED" | "IN_PROGRESS" | "READY" | "PUBLISHED";
  contentType?: ContentType;
  notes?: string;
}

// --- BRAND KIT ---
export interface BrandKit {
  id: string;
  name: string;
  logo?: string;
  colors: { name: string; value: string; role: "primary" | "secondary" | "accent" | "background" }[];
  fonts: { name: string; url?: string; role: "heading" | "body" | "display" }[];
  watermark?: string;
  voiceStyle?: string;
  musicStyle?: string;
  thumbnailTemplate?: string;
  identityNotes?: string;
  updatedAt: string;
}

// --- CREATOR MEMORY ---
export interface CreatorMemory {
  language: Language;
  defaultPlatform: Platform;
  preferredStyle: string;
  preferredTone: Tone;
  defaultOutputFormat: OutputFormat;
  brandKitId?: string;
  voiceProfile?: string;
  thumbnailStyle?: string;
  contentPreferences: string[];
  updatedAt: string;
}

// --- CHANNELS ---
export interface Channel {
  id: string;
  platform: Platform;
  name: string;
  handle?: string;
  connected: boolean;
  stats?: { subscribers?: number; followers?: number; views?: number };
}

// --- COST TRACKING ---
export interface CostEntry {
  id: string;
  projectId?: string;
  taskId?: string;
  provider: string;
  model?: string;
  type: MediaType | "TEXT";
  estimatedCost: number;
  actualCost?: number;
  generationTimeMs?: number;
  createdAt: string;
}

// Export CORE 2.0 & CORE 3.0 types
export * from "./core2";
export * from "./core3";
