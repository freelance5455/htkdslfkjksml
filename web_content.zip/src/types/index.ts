export type UserRole = 'user' | 'admin';

export type MembershipTier = 'basic' | 'vip1' | 'vip2' | 'vip3' | 'vip4' | 'vip5' | 'premium' | 'pro' | 'premium100' | 'premium300';

export interface User {
  id: string;
  name: string;
  username?: string;
  email: string;
  phone?: string;
  avatar?: string;
  role: UserRole;
  isActive: boolean;
  coins: number;
  lifetimeCoins: number;
  withdrawnCoins: number;
  membershipTier: MembershipTier;
  membershipExpiresAt: string | null; // ISO Date string or null for lifetime/free
  referralCode: string;
  referredBy?: string;
  joinedAt: string;
  lastDailyCheckin?: string;
  checkinStreak: number;
  googleConnected?: boolean;
  appsUsedCount?: number;
}

export interface YouTubeVideo {
  id: string;
  youtubeId: string;
  title: string;
  channelTitle: string;
  category: string;
  durationSeconds: number;
  rewardCoins: number;
  viewsCount: string;
  thumbnailUrl: string;
  isMarathon2Hour?: boolean;
}

export interface AppTaskItem {
  id: string;
  name: string;
  developer: string;
  category: string;
  iconUrl: string;
  rating: number;
  sizeMb: number;
  downloadsCount: string;
  rewardCoins: number;
  description: string;
  surveyQuestions: {
    question: string;
    options: string[];
  }[];
}

export type SocialPlatform = 'telegram' | 'instagram' | 'twitter' | 'youtube' | 'discord' | 'facebook' | 'whatsapp' | 'reddit';

export interface SocialTaskItem {
  id: string;
  title: string;
  handle: string;
  platform: SocialPlatform;
  actionType: 'join' | 'follow' | 'subscribe' | 'like' | 'retweet';
  rewardCoins: number;
  membersCount: string;
  iconBg: string;
  targetUrl: string;
  instructions: string;
}

export type TaskCategory = 
  | 'daily_checkin'
  | 'google_tasks'
  | 'vip_task'
  | 'quiz'
  | 'survey'
  | 'external_partner'
  | 'video_demo'
  | 'game'
  | 'review'
  | 'app_download'
  | 'youtube_watch'
  | 'social_facebook';

export interface Task {
  id: string;
  title: string;
  titleBn?: string;
  description: string;
  descriptionBn?: string;
  category: TaskCategory;
  rewardCoins: number;
  rewardRupees?: number; // Equivalent INR ₹
  estimatedMinutes: number;
  dailyLimit: number; // Maximum times per user per day
  isExternal: boolean; // Flag to show "External Task" badge
  externalUrl?: string;
  externalPlatform?: string; // e.g. "Google Docs", "Partner Survey", "Feedback Portal"
  isActive: boolean;
  requiresProof?: boolean;
  proofType?: 'screenshot' | 'text' | 'code' | 'url';
  proofInstructions?: string;
  verificationKeyword?: string;
  minCompletionTimeSeconds?: number;
  vipTierRequired?: MembershipTier;
  quizQuestions?: {
    question: string;
    questionBn?: string;
    options: string[];
    correctIndex: number;
  }[];
  // App Download offer fields
  appPackageName?: string;
  appIconUrl?: string;
  appSizeMb?: number;
  appDeveloper?: string;
  appPostbackToken?: string;
  attributionProvider?: string;
  // YouTube Watch fields
  youtubeUrl?: string;
  youtubeVideoId?: string;
  requiredWatchSeconds?: number;
  youtubeThumbnailUrl?: string;
  channelTitle?: string;
  // Game fields
  gameTargetScore?: number;
  gameType?: 'coin_collector';
  createdAt: string;
}

export type PaymentStatus = 'pending' | 'approved' | 'rejected';

export interface VipPaymentRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  vipTier: MembershipTier;
  planName: string;
  amountRupees: number;
  upiId: string; // '8649883536@yapl'
  utrNumber: string; // 12-digit UTR
  screenshotUrl?: string; // Base64 data or image url
  status: PaymentStatus;
  createdAt: string;
  reviewedAt?: string;
  adminRemark?: string;
}

export interface VipTierPlan {
  id: MembershipTier;
  tierNumber: number;
  name: string;
  nameBn: string;
  taskRewardRupees: number; // e.g., ₹200, ₹400, ₹1600, ₹2000
  tasksPerDay: number; // e.g., 2
  dailyEarningsRupees: number; // e.g., ₹400, ₹800, ₹2000, ₹4000
  unlimitedWithdrawal: boolean;
  minWithdrawalRupees: number;
  badgeColor: string;
  priceRupees: number;
  features: string[];
  featuresBn: string[];
}

export interface TaskSubmission {
  id: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  taskId: string;
  taskTitle: string;
  taskCategory?: TaskCategory;
  rewardCoins: number;
  rewardRupees?: number;
  completedAt: string;
  status: 'completed' | 'pending_verification' | 'rejected';
  proofText?: string;
  proofUrl?: string;
  adminRemark?: string;
}

export interface MembershipPlan {
  id: MembershipTier;
  name: string;
  nameBn: string;
  price: number; // in INR / USD
  priceInCoins: number;
  durationDays: number;
  dailyTaskLimit: number;
  rewardMultiplier: number;
  features: string[];
  featuresBn: string[];
  badgeColor: string;
  isPopular?: boolean;
  dailyEarningRupees?: number;
}

export type WithdrawalMethod = 'upi' | 'gpay' | 'phonepe' | 'paytm' | 'bank_transfer' | 'paypal' | 'crypto_usdt' | 'mobile_recharge';

export type WithdrawalStatus = 'pending' | 'approved' | 'rejected';

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  amountCoins: number;
  amountCurrency: number;
  currency: string;
  method: WithdrawalMethod;
  accountDetails: string;
  status: WithdrawalStatus;
  requestedAt: string;
  processedAt?: string;
  transactionRef?: string;
  adminRemark?: string;
}

export type TransactionType = 
  | 'task_reward'
  | 'vip_task_reward'
  | 'game_reward'
  | 'coin_convert'
  | 'daily_checkin'
  | 'referral_bonus'
  | 'withdrawal'
  | 'membership_purchase'
  | 'admin_adjustment'
  | 'google_task_reward';

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  title: string;
  titleBn?: string;
  coins: number; // positive for credit, negative for debit
  amountRupees?: number;
  balanceAfter: number;
  timestamp: string;
  referenceId?: string;
  status: 'completed' | 'pending' | 'failed';
}

export interface NotificationItem {
  id: string;
  userId: string; // 'all' or specific user ID
  title: string;
  titleBn?: string;
  message: string;
  messageBn?: string;
  type: 'info' | 'success' | 'warning' | 'reward';
  isRead: boolean;
  createdAt: string;
  actionUrl?: string;
}

export interface ReferralRecord {
  id: string;
  referrerId: string;
  referredUserId: string;
  referredUserName: string;
  referredAt: string;
  coinsEarned: number;
  status: 'active' | 'pending';
}

export interface SystemSettings {
  appName: string;
  currencyCode: string;
  currencySymbol: string;
  coinsPerCurrencyUnit: number; // 1 Coin = ₹1 (or 100 coins = $1)
  minWithdrawalCoins: number;
  referralBonusCoins: number;
  referredUserBonusCoins: number;
  dailyCheckinBaseCoins: number; // default 12 Coins
  demoModeNotice: boolean;
  enableGoogleTasksSync: boolean;
  enableApkDownload?: boolean;
  apkDownloadUrl?: string;
  apkVersion?: string;
  apkFileSizeMb?: string;
  apkReleaseNotes?: string;
  // Custom Coins & Facebook tasks
  facebookTaskRewardCoins?: number; // 10 coins per completed FB task
  // Ad Revenue & Play Seen Admin Earnings
  adminCpmRateRupees?: number; // CPM rate e.g. ₹250 per 1000 plays
  totalPlaysSeen?: number; // Total video/ad plays seen by users
  adminTotalAdRevenueRupees?: number; // Total money earned by admin from plays
  adNetworkProvider?: string; // 'Google AdMob, Unity Ads & Direct Sponsors'
  enableAiTaskOptimization?: boolean;
  adminUpiId?: string; // Admin's UPI ID for receiving VIP payments
}

export interface GoogleTaskItem {
  id: string;
  title: string;
  notes?: string;
  status: 'needsAction' | 'completed';
  due?: string;
  updated?: string;
}

export interface GoogleTaskList {
  id: string;
  title: string;
  updated?: string;
}

export interface GameItem {
  id: string;
  title: string;
  titleBn: string;
  category: string;
  icon: string;
  description: string;
  descriptionBn: string;
  minReward: number; // in Coins / ₹
  maxReward: number; // in Coins / ₹
  playLimitPerDay: number;
  badge: string;
}

export interface AppFeedbackSubmission {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  overallRating: number; // 1 to 5
  favoriteFeature: string;
  requestedFeatures: string[];
  easeOfUse: number; // 1 to 5
  earningSatisfaction: 'very_satisfied' | 'satisfied' | 'neutral' | 'dissatisfied';
  comments: string;
  rewardCoinsEarned: number;
  submittedAt: string;
}

export interface AppInstallOffer {
  id: string;
  name: string;
  nameBn?: string;
  developer: string;
  category: string;
  iconUrl: string;
  rating: number;
  sizeMb: number;
  downloadsCount: string;
  rewardCoins: number;
  rewardRupees: number;
  payoutBadge: string;
  instructions: string[];
  instructionsBn?: string[];
  appStoreUrl: string;
  proofRequired?: string;
  status: 'available' | 'installing' | 'verifying' | 'completed';
  dailyUsageRewardCoins?: number;
  usageMinutesRequired?: number;
  usageDaysCompleted?: number;
}

export type MetalType = 'gold' | 'silver';

export interface InvestmentOrder {
  id: string;
  userId: string;
  userName: string;
  metalType: MetalType;
  orderType: 'buy' | 'sell';
  amountINR: number;
  grams: number;
  pricePerGram: number;
  couponCode?: string;
  discountINR?: number;
  screenshotUrl?: string;
  status: 'completed' | 'pending' | 'failed';
  createdAt: string;
}

export interface SupportMessage {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  subject: string;
  category: 'withdrawal' | 'task_proof' | 'kyc_gold' | 'vip_upgrade' | 'other';
  message: string;
  screenshotUrl?: string;
  status: 'open' | 'in_progress' | 'resolved';
  adminReply?: string;
  createdAt: string;
  updatedAt: string;
}

export interface MetalHolding {
  metalType: MetalType;
  grams: number;
  totalInvestedINR: number;
  currentPricePerGram: number;
}

export interface KycRecord {
  userId: string;
  fullName: string;
  dob: string;
  aadhaarMasked: string; // e.g. "XXXX-XXXX-4821"
  mobileNumber?: string; // 10-digit mobile number linked to Aadhaar for Gold purchases
  status: 'pending' | 'verified' | 'rejected';
  verifiedAt?: string;
  bankDetails?: string;
}

export interface InvestmentCoupon {
  id: string;
  code: string;
  discountPercent?: number;
  flatDiscountINR?: number;
  minInvestmentINR: number;
  usageLimit: number;
  timesUsed: number;
  isActive: boolean;
  expiresAt: string;
}

export interface PriceAlert {
  id: string;
  userId: string;
  metalType: MetalType;
  targetPrice: number;
  condition: 'above' | 'below';
  isActive: boolean;
  createdAt: string;
}

export type SipFrequency = 'daily' | 'weekly' | 'monthly';

export interface SipPlan {
  id: string;
  userId: string;
  metalType: MetalType;
  amountINR: number;
  frequency: SipFrequency;
  installmentsCompleted: number;
  totalInvestedINR: number;
  accumulatedGrams: number;
  status: 'active' | 'paused' | 'completed';
  createdAt: string;
  nextInstallmentDate: string;
}

export interface GoldMineInvestment {
  id: string;
  userId: string;
  userName: string;
  planName: string;
  investedAmountINR: number; // ₹5,000
  dailyReturnINR: number; // ₹300
  durationDays: number; // 30
  totalReturnINR: number; // ₹9,000
  currentDay: number; // e.g. Day 4 of 30
  totalClaimedINR: number;
  lastClaimDate?: string;
  status: 'active' | 'completed';
  startDate: string;
  taskWithdrawalAllowanceINR: number; // ₹1,000
  verifiedUtr?: string;
}

// -------------------------------------------------------------
// Official Legal, Licence, Bank Verification & Provider Types
// -------------------------------------------------------------

export interface CompanyRegistrationInfo {
  legalName: string;
  mcaStatus: 'Active & Verified' | 'Verification Pending' | 'Under Scrutiny';
  cinNumber: string;
  gstinNumber?: string;
  msmeNumber?: string;
  registeredAddress: string;
  incorporationDate: string;
  authorizedCapitalINR?: number;
  paidUpCapitalINR?: number;
  isOfficialVerified: boolean;
  rocOffice: string;
  mcaCheckUrl: string;
  gstCheckUrl: string;
  msmeCheckUrl: string;
  certificatePdfUrl?: string;
  certificateImageUrl?: string;
  uploadedCertificateBase64?: string;
  lastVerifiedRecordTimestamp: string;
}

export interface AppLicenceInfo {
  licenceType: string;
  licenceNumber: string;
  issuingAuthority: string;
  issueDate: string;
  expiryDate: string;
  status: 'verified' | 'pending' | 'not_registered';
  certificateUrl?: string;
  regulatoryJurisdiction: string;
  notes: string;
}

export interface SbiBankAccount {
  userId: string;
  accountHolderName: string;
  maskedAccountNumber: string; // e.g. "•••• •••• •••• 4821"
  rawAccountNumberLast4: string;
  ifscCode: string;
  bankName: string; // 'State Bank of India (SBI)'
  branchName: string;
  status: 'verified' | 'pending' | 'rejected' | 'unlinked';
  isEligibleForWithdrawal: boolean;
  linkedAt: string;
  verifiedAt?: string;
  pennyDropRef?: string;
  consentConfirmed: boolean;
}

export interface AdvancedKycData {
  userId: string;
  fullName: string;
  aadhaarNumberMasked: string; // e.g. "XXXX-XXXX-4821"
  panNumberMasked: string; // e.g. "ABCDE****F"
  dateOfBirth?: string;
  aadhaarStatus: 'verified' | 'pending' | 'rejected';
  panStatus: 'verified' | 'pending' | 'rejected';
  overallStatus: 'verified' | 'pending' | 'rejected';
  userConsentAccepted: boolean;
  authorizedProviderName: string; // 'DigiLocker / NSDL Authorized Gateway'
  submittedAt: string;
  verifiedAt?: string;
  documentProofUrl?: string;
  rejectionRemarks?: string;
}

export interface MetalProviderConfig {
  providerName: string;
  apiFeedStatus: 'connected' | 'degraded' | 'offline';
  feedSource: string; // 'IBJA National Bullion Feed / MCX Live Direct Spot'
  goldMarkupPercent: number; // e.g. 0.0%
  silverMarkupPercent: number; // e.g. 0.0%
  gstPercent: number; // 3%
  vaultInsuranceFeeRupees: number; // ₹0
  minGoldBuyINR: number; // ₹300
  minSilverBuyINR: number; // ₹200
  maxSingleOrderINR: number; // ₹500,000
  sellSpreadPercent: number; // 1.5%
  isLiveTradingEnabled: boolean;
  lastAuditSync: string;
}

