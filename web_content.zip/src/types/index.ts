export type SessionState =
  | 'DISCONNECTED'
  | 'CONNECTING'
  | 'LISTENING'
  | 'SPEAKING'
  | 'ANALYZING'
  | 'ERROR';

export type CameraState =
  | 'CAMERA_OFF'
  | 'CAMERA_REQUESTING_PERMISSION'
  | 'CAMERA_ACTIVE'
  | 'CAMERA_ERROR';

export interface PalmReadingResult {
  career: string;
  loveLife: string;
  health: string;
  future: string;
  summary: string;
  timestamp: number;
  capturedImageUrl?: string;
}

export interface ScannerStep {
  id: number;
  title: string;
  hindiTitle: string;
  description: string;
  hint: string;
  tip: string;
}

export interface AppSettings {
  geminiApiKey: string;
  theme: 'dark' | 'light';
  autoStartCamera: boolean;
  voiceLanguage: 'auto' | 'hi' | 'en' | 'mr';
}

export interface LiveMessage {
  type: 'audio' | 'interrupted' | 'text' | 'status' | 'error' | 'turn_complete' | 'palm_analysis';
  data?: string;
  text?: string;
  status?: SessionState;
  message?: string;
  reading?: PalmReadingResult;
}
