export interface Product {
  id: string;
  code: string;
  name: string;
  category: string;
  price: number;
  costPrice: number;
  stock: number;
  minStock: number;
  unit: string;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface SaleItem {
  productId: string;
  code: string;
  name: string;
  price: number;
  costPrice: number;
  quantity: number;
  subtotal: number;
}

export interface SaleTransaction {
  id: string;
  receiptNumber: string;
  timestamp: string;
  items: SaleItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paymentMethod: 'cash' | 'card' | 'ewallet';
  amountPaid: number;
  change: number;
  cashierNote?: string;
  status: 'completed' | 'refunded';
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  address: string;
  phone: string;
  email?: string;
  tin?: string; // Tax ID / Business Reg No.
  receiptHeaderNote?: string;
  receiptFooter: string;
  currency: string;
  taxRate: number; // percentage, e.g. 12 or 0
  enableSound: boolean;
  promptQuantityOnScan?: boolean;
}

export type ActiveTab = 'dashboard' | 'sale' | 'register' | 'inventory' | 'history' | 'settings';
