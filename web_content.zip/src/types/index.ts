export type Profile = {
  id: string;
  username: string;
  display_name: string;
  avatar_url?: string | null;
  bio?: string | null;
  last_seen?: string | null;
  created_at: string;
  updated_at?: string;
};

export type FriendRequestStatus = 'pending' | 'accepted' | 'rejected' | 'cancelled';

export type FriendRequest = {
  id: string;
  sender_id: string;
  receiver_id: string;
  status: FriendRequestStatus;
  created_at: string;
  sender?: Profile;
  receiver?: Profile;
};

export type Friendship = {
  id: string;
  user_id: string;
  friend_id: string;
  created_at: string;
  friend?: Profile;
};

export type BlockedUser = {
  id: string;
  blocker_id: string;
  blocked_id: string;
  created_at: string;
  blocked_profile?: Profile;
};

export type DisappearingDuration = 'off' | '5m' | '1h' | '24h' | '7d' | '30d' | '90d';
export type AutoDeleteChatDuration = 'off' | '5m';

export type Conversation = {
  id: string;
  type: 'direct' | 'group';
  name?: string | null;
  photo_url?: string | null;
  creator_id?: string | null;
  admin_ids?: string[];
  created_at: string;
  updated_at?: string;
};

export type ConversationMember = {
  id: string;
  conversation_id: string;
  user_id: string;
  created_at: string;
  cleared_at?: string | null;
  is_deleted: boolean;
  is_pinned: boolean;
  is_muted: boolean;
  disappearing_duration: DisappearingDuration;
  user?: Profile;
};

export type ConversationWithDetails = {
  id: string;
  type?: 'direct' | 'group';
  name?: string | null;
  photo_url?: string | null;
  creator_id?: string | null;
  admin_ids?: string[];
  members?: Profile[];
  otherUser: Profile;
  lastMessage?: Message | null;
  unreadCount: number;
  isPinned: boolean;
  isMuted: boolean;
  disappearingDuration: DisappearingDuration;
  autoDeleteChatDuration?: AutoDeleteChatDuration;
  autoDeleteChatStartedAt?: string | null;
  clearedAt?: string | null;
  wallpaper?: string | null;
  isOnline?: boolean;
  isTyping?: boolean;
};

export type MessageType = 'text' | 'image' | 'video' | 'file' | 'voice' | 'system';

export type Message = {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  type: MessageType;
  file_name?: string | null;
  file_size?: number | null;
  mime_type?: string | null;
  media_path?: string | null;
  reply_to_id?: string | null;
  is_view_once: boolean;
  viewed_at?: string | null;
  is_edited: boolean;
  is_deleted_everyone: boolean;
  expires_at?: string | null;
  created_at: string;
  updated_at?: string;
  
  // Client-populated relations
  reply_to_message?: Message | null;
  sender?: Profile;
  reactions?: MessageReaction[];
  is_saved?: boolean;
  is_read?: boolean;
  delivered_at?: string | null;
  read_at?: string | null;
};

export type MessageReaction = {
  id: string;
  message_id: string;
  user_id: string;
  emoji: string;
  created_at: string;
  user?: Profile;
};

export type CallType = 'voice' | 'video';
export type CallStatus = 'connected' | 'missed' | 'rejected' | 'failed' | 'cancelled';

export type CallHistoryItem = {
  id: string;
  caller_id: string;
  receiver_id: string;
  call_type: CallType;
  status: CallStatus;
  duration_seconds: number;
  started_at: string;
  ended_at?: string | null;
  created_at: string;
  caller?: Profile;
  receiver?: Profile;
};

export type ActiveCallSession = {
  callId: string;
  isCaller: boolean;
  peerUser: Profile;
  callType: CallType;
  status: 'ringing' | 'incoming' | 'connecting' | 'connected' | 'ended' | 'rejected' | 'failed';
  localStream?: MediaStream | null;
  remoteStream?: MediaStream | null;
  isMuted: boolean;
  isVideoOff: boolean;
  isSpeakerOn: boolean;
  startedAt?: Date | null;
  durationSeconds: number;
};

export type AppTheme = 'dark' | 'amoled' | 'light' | 'blue' | 'purple';

export type PrivacyAudience = 'everyone' | 'friends' | 'nobody';
export type StatusPrivacyAudience = 'friends' | 'selected' | 'nobody';

export type UserSettings = {
  theme: AppTheme;
  notifications_enabled: boolean;
  read_receipts: boolean;
  typing_indicator: boolean;
  last_seen_privacy: PrivacyAudience;
  online_status_privacy: PrivacyAudience;
  profile_photo_privacy: PrivacyAudience;
  bio_privacy: PrivacyAudience;
  status_privacy: StatusPrivacyAudience;
  selected_status_friends?: string[];
};

export type StatusStory = {
  id: string;
  user_id: string;
  media_type: 'image' | 'video' | 'text';
  content?: string | null;
  media_url?: string | null;
  background_color?: string | null;
  caption?: string | null;
  created_at: string;
  expires_at: string;
  user?: Profile;
  views?: { user_id: string; viewed_at: string; user?: Profile }[];
};

export type Report = {
  id: string;
  reporter_id: string;
  reported_user_id: string;
  message_id?: string | null;
  reason: string;
  created_at: string;
};
