/** أنواع المحتوى التعليمي — كل المحتوى يُقرأ من src/data/content.ts */

export type IconKey =
  | 'function'
  | 'atom'
  | 'flask'
  | 'dna'
  | 'book'
  | 'language'
  | 'globe'
  | 'moon';

export interface Subject {
  id: string;
  name: string;
  shortName: string;
  /** لون المادة الأساسي (HEX) */
  color: string;
  /** لون فاتح للخلفيات */
  colorSoft: string;
  icon: IconKey;
  description: string;
  /** الوزن النسبي في خطة الدراسة */
  weight: number;
  teachers: Teacher[];
  units: Unit[];
  quickReviews: Attachment[];
  pastPapers: PastPaper[];
  formulas: Attachment[];
}

export interface Teacher {
  id: string;
  subjectId: string;
  name: string;
  headline: string;
  bio: string;
  /** رابط صورة (اختياري) أو أحرف أولى عند الغياب */
  avatarUrl?: string;
  years?: number;
  style: string;
  /** قناة أو منصة تحققنا من صلتها بالمحتوى؛ لا تُعرض كرابط خروج للطالب. */
  channelUrl?: string;
  channelLabel?: string;
  /** قائمة الرفع العامة للقناة كما يعرضها YouTube؛ لا تُستخدم إلا بعد مطابقة مصدرها. */
  uploadsPlaylistId?: string;
  verifiedVideos?: VerifiedTeacherVideo[];
}

export interface VerifiedTeacherVideo {
  id: string;
  title: string;
  lessonLabel: string;
  videoId: string;
}

export interface Unit {
  id: string;
  subjectId: string;
  teacherId: string;
  title: string;
  summary: string;
  lessons: Lesson[];
}

export interface Lesson {
  id: string;
  unitId: string;
  subjectId: string;
  teacherId: string;
  title: string;
  description: string;
  /** معرّف فيديو يوتيوب (١١ حرفاً) أو رابط كامل — يُمرّر إلى extractVideoId */
  videoId: string;
  /** مدة الفيديو بالثواني */
  duration: number;
  chapters: Chapter[];
  attachments: Attachment[];
  quiz?: Quiz;
  objectives: string[];
  /** نسخ شرح بديلة لمدرّسين آخرين (نفس الدرس، فيديو مختلف) */
  alternates?: { teacherId: string; videoId: string }[];
}

export interface Chapter {
  /** الثانية التي يبدأ عندها الفصل */
  time: number;
  title: string;
}

export interface Attachment {
  id: string;
  title: string;
  kind: 'pdf' | 'summary' | 'formula' | 'exam';
  /** حجم تقريبي للعرض */
  size: string;
  /** رابط الملف؛ قد يكون مساراً داخلياً أو خارجياً */
  url: string;
  pages?: number;
}

export interface PastPaper {
  id: string;
  year: number;
  title: string;
  paper: Attachment;
  solution?: Attachment;
}

export type QuestionType = 'mcq' | 'tf';

export interface Question {
  id: string;
  type: QuestionType;
  text: string;
  options?: string[];
  /** للاختيار من متعدد: فهرس الإجابة الصحيحة */
  answerIndex?: number;
  /** لصح/خطأ */
  answerBool?: boolean;
  explanation: string;
  /** مفهوم السؤال، لعرض نقاط الضعف بدقة بعد الاختبار */
  topic?: string;
}

export interface Quiz {
  id: string;
  title: string;
  questions: Question[];
}

export type CurriculumQuestionKind = 'mcq' | 'true-false' | 'short-answer' | 'reasoning' | 'proof' | 'problem' | 'essay' | 'language-writing';
export type QuestionDifficulty = 'أساسي' | 'متوسط' | 'متقدم';

export interface RubricCriterion {
  label: string;
  points: number;
}

/** سؤال جديد مرتبط بمرجع رسمي قابل للتتبع، ويُحمّل ضمن ملف وحدة واحدة. */
export interface CurriculumQuestion {
  id: string;
  subjectId: string;
  unitId: string;
  lessonId?: string;
  topic: string;
  kind: CurriculumQuestionKind;
  difficulty: QuestionDifficulty;
  prompt: string;
  choices?: string[];
  answerIndex?: number;
  answerBool?: boolean;
  expectedAnswer?: string;
  modelAnswer?: string;
  solutionSteps?: string[];
  explanation?: string;
  rubric?: RubricCriterion[];
  maxPoints: number;
  sourceIds: string[];
  sourcePage?: number;
  sourcePages?: number[];
}

export interface CurriculumUnitInfo {
  id: string;
  subjectId: string;
  title: string;
  kind?: 'unit' | 'supplement-chapter';
  lessonTitles: string[];
  /** عدد الأسئلة المنشورة لكل درس حسب ترتيب lessonTitles */
  lessonQuestionCounts?: number[];
  questionCount: number;
  sourceIds: string[];
}

export interface CurriculumSource {
  id: string;
  title: string;
  organization: string;
  edition?: string;
  year?: number;
  url: string;
  locator?: string;
  kind: 'textbook' | 'curriculum' | 'exam' | 'answer-key' | 'official-reference';
  accessedAt: string;
}

export interface CurriculumPracticeAttempt {
  id: string;
  questionId: string;
  subjectId: string;
  unitId: string;
  topic: string;
  kind: CurriculumQuestionKind;
  correct: boolean | null;
  selfScore?: number;
  maxPoints: number;
  answeredCount: 1;
  at: number;
}

export interface WrittenAnswerRecord {
  id: string;
  questionId: string;
  subjectId: string;
  unitId: string;
  topic: string;
  response: string;
  modelAnswer: string;
  selfScore?: number;
  maxPoints: number;
  sourceIds: string[];
  sourcePage?: number;
  sourcePages?: number[];
  at: number;
}

export interface Flashcard {
  id: string;
  subjectId: string;
  front: string;
  back: string;
  tag: string;
}

export interface LibraryFile extends Attachment {
  subjectId: string;
  year?: number;
}

/* ============ أنواع حالة المستخدم (تُخزَّن محلياً) ============ */

export interface Profile {
  name: string;
  governorate: string;
  targetAverage: number;
  examDate: string;
  createdAt: string;
  /** المدرس المختار في كل مادة */
  teacherBySubject: Record<string, string>;
  onboarded: boolean;
}

export interface LessonProgress {
  lessonId: string;
  /** موضع التوقف بالثواني */
  position: number;
  /** أقصى ثانية وصل إليها الطالب */
  maxWatched: number;
  duration: number;
  completed: boolean;
  updatedAt: number;
  /** وقت أول إكمال عند بلوغ ٩٠٪؛ لا يتغير عند إعادة المشاهدة */
  completedAt?: number;
}

export interface VideoNote {
  id: string;
  lessonId: string;
  time: number;
  text: string;
  createdAt: number;
  updatedAt?: number;
}

export interface Bookmark {
  id: string;
  lessonId: string;
  time: number;
  label: string;
  createdAt: number;
}

export interface DayStat {
  /** yyyy-mm-dd */
  date: string;
  seconds: number;
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  lessonId?: string;
  subjectId: string;
  unitId?: string;
  score: number;
  total: number;
  /** الوسوم/المواضيع التي أخطأ فيها */
  weakTags: string[];
  at: number;
}

export interface FlashcardState {
  id: string;
  ease: number;
  intervalDays: number;
  due: string;
  reps: number;
  lapses: number;
  /** آخر وقت راجع فيه الطالب البطاقة، لاحتساب تحديات اليوم والأسبوع */
  reviewedAt?: number;
}

export interface PlanSession {
  id: string;
  day: 0 | 1 | 2 | 3 | 4 | 5 | 6;
  subjectId: string;
  minutes: number;
  label: string;
  done: boolean;
}

export interface StudyPlan {
  generatedAt: number;
  hoursPerDay: number;
  sessions: PlanSession[];
}

export interface Settings {
  theme: 'light' | 'dark' | 'system';
  fontScale: number;
  language: 'ar' | 'en';
  dataSaver: boolean;
  autoplayNext: boolean;
  lastRate: number;
  lastVolume: number;
}


export type ThemePalette = 'ocean' | 'forest' | 'violet' | 'rose' | 'amber';
export type TimerSkin = 'classic' | 'ring' | 'focus';

/** حقول شكل اختيارية، تبقى متوافقة مع إعدادات ونسخ احتياطية أقدم. */
export interface Settings {
  palette?: ThemePalette;
  timerSkin?: TimerSkin;
}
