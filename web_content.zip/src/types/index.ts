export type Language = 'pashto' | 'urdu' | 'english';

export type RuleCategory = 'sarf' | 'nahw';

export interface MultilingualText {
  pashto: string;
  urdu: string;
  english: string;
}

export interface RuleExample {
  arabic: string;
  pashtoTranslation: string;
  urduTranslation: string;
  englishTranslation: string;
  analysis?: MultilingualText;
}

export interface GrammarRule {
  id: string;
  category: RuleCategory;
  topicId: string;
  arabicTitle: string;
  title: MultilingualText;
  summary: MultilingualText;
  definition: MultilingualText;
  detailedRules: MultilingualText[];
  examples: RuleExample[];
  mnemonicOrNote?: MultilingualText;
  tags: string[];
}

export interface GrammarTopic {
  id: string;
  category: RuleCategory;
  arabicTitle: string;
  title: MultilingualText;
  description: MultilingualText;
  iconName: string;
  rulesCount: number;
}

export interface ConjugationForm {
  arabic: string;
  person: string; // 3rd, 2nd, 1st
  gender: string; // masculine, feminine
  number: string; // singular, dual, plural
  seghaArabic: string;
  seghaUrdu: string;
  seghaPashto: string;
  meaningPashto: string;
  meaningUrdu: string;
  meaningEnglish: string;
}

export interface VerbBab {
  id: string;
  nameArabic: string;
  pattern: string;
  category: 'thulathi_mujarrad' | 'thulathi_mazeed';
  symbolArabic?: string;
  title: MultilingualText;
  description: MultilingualText;
  characteristic: MultilingualText;
  rootLetters: string;
  past3rdMasc: string;
  present3rdMasc: string;
  masdar: string;
  amr: string;
  nahy: string;
  conjugations: {
    past: ConjugationForm[];
    present: ConjugationForm[];
    amr: ConjugationForm[];
    nahy: ConjugationForm[];
  };
}

export interface SentenceToken {
  word: string;
  roleArabic: string;
  caseState: 'marfoo' | 'mansoob' | 'majroor' | 'majzoom' | 'mabni';
  caseSign: MultilingualText;
  explanation: MultilingualText;
}

export interface AnalyzedSentence {
  id: string;
  arabicText: string;
  source?: string;
  translation: MultilingualText;
  sentenceType: MultilingualText;
  tokens: SentenceToken[];
  tarkibSummary: MultilingualText;
}

export interface QuizQuestion {
  id: string;
  category: 'sarf' | 'nahw' | 'mixed';
  question: MultilingualText;
  arabicPhrase?: string;
  options: {
    id: string;
    text: MultilingualText;
  }[];
  correctOptionId: string;
  explanation: MultilingualText;
}

export interface UserNote {
  id: string;
  userId: string;
  ruleId: string;
  ruleType: 'sarf' | 'nahw';
  noteText: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserBookmark {
  id: string;
  userId: string;
  ruleId: string;
  ruleType: 'sarf' | 'nahw';
  ruleTitle: string;
  createdAt: string;
}

export interface UserProgress {
  id: string;
  userId: string;
  ruleId: string;
  status: 'not_started' | 'studying' | 'mastered';
  updatedAt: string;
}

export interface UserQuizRecord {
  id: string;
  userId: string;
  score: number;
  total: number;
  category: 'sarf' | 'nahw' | 'mixed';
  createdAt: string;
}
