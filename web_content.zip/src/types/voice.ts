export type VoiceCategory =
  | 'all'
  | 'elevenlabs'
  | 'cartesia'
  | 'cloned'
  | 'hindi'
  | 'english'
  | 'global'
  | 'conversational'
  | 'narration'
  | 'character';

export type VoiceGender = 'Male' | 'Female' | 'Neutral';
export type VoiceProvider = 'ElevenLabs' | 'Cartesia' | 'Custom';

export interface Voice {
  id: string;
  name: string;
  gender: VoiceGender;
  category: VoiceCategory;
  provider?: VoiceProvider;
  accent: string;
  language: string;
  description: string;
  tag: string;
  avatarLetter: string;
  avatarBg: string;
  baseGeminiVoice: 'Kore' | 'Puck' | 'Fenrir' | 'Charon' | 'Zephyr';
  isCloned?: boolean;
  clonedAudioUrl?: string;
  clonedDirective?: string;
  samplePhrase: string;
}

export interface VoiceMood {
  id: string;
  label: string;
  hindiLabel: string;
  description: string;
  iconName: string;
  promptDirective: string;
}

export interface GeneratedAudioItem {
  id: string;
  text: string;
  voice: Voice;
  mood: string;
  speed: number;
  pitch: number;
  audioUrl: string;
  timestamp: number;
  durationFormatted: string;
  source: 'gemini' | 'client-neural';
}

export interface PresetText {
  id: string;
  title: string;
  lang: string;
  category: string;
  text: string;
  suggestedVoiceId: string;
  suggestedMood: string;
}
