export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  provider: 'email' | 'google';
  createdAt: number;
  plan?: 'free' | 'pro';
}

export interface UserMemory {
  id: string;
  text: string;
  createdAt: number;
}

export interface UserSettings {
  preferredModel: string;
  responseStyle: 'concise' | 'balanced' | 'detailed' | 'casual' | 'formal' | 'strict';
  defaultLanguage: string;
  customInstructions: string;
  memoryEnabled: boolean;
  confirmBeforeDelete: boolean;
  theme: 'dark' | 'light' | 'system';
  fontSize: 'small' | 'medium' | 'large';
  accentColor: 'blue' | 'cyan' | 'purple' | 'emerald';
  ttsEnabled: boolean;
  voiceName: string;
  voiceSpeed: number;
  autoPlayAudio: boolean;
  notificationsEnabled: boolean;
  notificationTypes: {
    systemUpdates: boolean;
    generationComplete: boolean;
    tips: boolean;
  };
  dataSharingEnabled: boolean;
  analyticsEnabled: boolean;
}

export interface AuthState {
  user: User | null;
  settings: UserSettings;
  memories: UserMemory[];
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}
