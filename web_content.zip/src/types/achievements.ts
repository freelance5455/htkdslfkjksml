export type AchievementCategory = 'recorde' | 'consistencia' | 'vitorias' | 'geral';
export type AchievementRarity = 'comum' | 'raro' | 'epico' | 'lendario';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  category: AchievementCategory;
  iconName: string;
  rarity: AchievementRarity;
  isUnlocked: boolean;
  progress: {
    current: number;
    max: number;
    unit?: string;
  };
  unlockedAt?: string;
}
