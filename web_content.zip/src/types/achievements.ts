import { CareerStats, LiveTelemetry, VehicleCustomization } from './game';

export type AchievementCategory = 'all' | 'milestones' | 'mastery' | 'tuning' | 'speed';
export type AchievementTier = 'bronze' | 'silver' | 'gold' | 'platinum';

export interface AchievementItem {
  id: string;
  title: string;
  description: string;
  category: 'milestones' | 'mastery' | 'tuning' | 'speed';
  tier: AchievementTier;
  iconName:
    | 'Trophy'
    | 'Flag'
    | 'Flame'
    | 'Gauge'
    | 'Zap'
    | 'Compass'
    | 'Wrench'
    | 'Award'
    | 'Sparkles'
    | 'ShieldCheck';
  target: number;
  unit: string;
  checkProgress: (
    stats: CareerStats,
    telemetry: LiveTelemetry,
    liveTotalMeters: number,
    customization: VehicleCustomization
  ) => {
    current: number;
    target: number;
    completed: boolean;
    percent: number;
    formattedProgress: string;
  };
}

export const ACHIEVEMENTS_LIST: AchievementItem[] = [
  {
    id: 'ach_first_win',
    title: 'First Victory',
    description: 'Claim your first P1 victory in an official Grand Prix race.',
    category: 'milestones',
    tier: 'gold',
    iconName: 'Trophy',
    target: 1,
    unit: 'win',
    checkProgress: (stats) => {
      const wins = stats.totalWins || 0;
      return {
        current: wins,
        target: 1,
        completed: wins >= 1,
        percent: wins >= 1 ? 100 : 0,
        formattedProgress: `${wins} / 1 Win`,
      };
    },
  },
  {
    id: 'ach_100km',
    title: '100km Driven',
    description: 'Accumulate 100 kilometers of high-speed racing distance.',
    category: 'milestones',
    tier: 'platinum',
    iconName: 'Flag',
    target: 100000,
    unit: 'km',
    checkProgress: (_stats, _telemetry, liveTotalMeters) => {
      const curKm = liveTotalMeters / 1000;
      const completed = liveTotalMeters >= 100000;
      const percent = Math.min(100, (liveTotalMeters / 100000) * 100);
      return {
        current: liveTotalMeters,
        target: 100000,
        completed,
        percent: Math.round(percent),
        formattedProgress: `${curKm.toFixed(1)} / 100.0 km`,
      };
    },
  },
  {
    id: 'ach_perfect_drift',
    title: 'Perfect Drift Session',
    description: 'Hold a continuous, high-speed power drift for at least 3.0 seconds.',
    category: 'mastery',
    tier: 'gold',
    iconName: 'Flame',
    target: 3.0,
    unit: 's',
    checkProgress: (stats, telemetry) => {
      const longest = Math.max(
        stats.longestDriftSeconds || 0,
        telemetry.driftDurationSeconds || 0,
        telemetry.maxDriftSeconds || 0
      );
      const completed = longest >= 3.0;
      const percent = Math.min(100, (longest / 3.0) * 100);
      return {
        current: longest,
        target: 3.0,
        completed,
        percent: Math.round(percent),
        formattedProgress: `${longest.toFixed(1)}s / 3.0s`,
      };
    },
  },
  {
    id: 'ach_10km',
    title: '10km Circuit Cruiser',
    description: 'Complete your first 10 kilometers of active circuit driving.',
    category: 'milestones',
    tier: 'bronze',
    iconName: 'Compass',
    target: 10000,
    unit: 'km',
    checkProgress: (_stats, _telemetry, liveTotalMeters) => {
      const curKm = liveTotalMeters / 1000;
      const completed = liveTotalMeters >= 10000;
      const percent = Math.min(100, (liveTotalMeters / 10000) * 100);
      return {
        current: liveTotalMeters,
        target: 10000,
        completed,
        percent: Math.round(percent),
        formattedProgress: `${curKm.toFixed(1)} / 10.0 km`,
      };
    },
  },
  {
    id: 'ach_speed_350',
    title: 'Speed Demon 350+',
    description: 'Shatter the 350 km/h velocity barrier in any hypercar.',
    category: 'speed',
    tier: 'silver',
    iconName: 'Gauge',
    target: 350,
    unit: 'km/h',
    checkProgress: (stats, telemetry) => {
      const peak = Math.max(stats.peakSpeedKmh || 0, telemetry.speedKmh || 0);
      const completed = peak >= 350;
      const percent = Math.min(100, (peak / 350) * 100);
      return {
        current: peak,
        target: 350,
        completed,
        percent: Math.round(percent),
        formattedProgress: `${Math.round(peak)} / 350 km/h`,
      };
    },
  },
  {
    id: 'ach_podium_5',
    title: 'Podium Regular',
    description: 'Clinch a podium finish (Top 3) in 5 or more races.',
    category: 'milestones',
    tier: 'silver',
    iconName: 'Award',
    target: 5,
    unit: 'podiums',
    checkProgress: (stats) => {
      const podiums = stats.podiums || 0;
      const completed = podiums >= 5;
      const percent = Math.min(100, (podiums / 5) * 100);
      return {
        current: podiums,
        target: 5,
        completed,
        percent: Math.round(percent),
        formattedProgress: `${podiums} / 5 Podiums`,
      };
    },
  },
  {
    id: 'ach_tuning_max',
    title: 'Apex Engineer',
    description: 'Upgrade Engine, Turbo, and Suspension all to Stage 3.',
    category: 'tuning',
    tier: 'gold',
    iconName: 'Wrench',
    target: 3,
    unit: 'parts',
    checkProgress: (_stats, _telemetry, _dist, cust) => {
      const count =
        (cust.engineStage >= 3 ? 1 : 0) +
        (cust.turboStage >= 3 ? 1 : 0) +
        (cust.suspensionStage >= 3 ? 1 : 0);
      const completed = count >= 3;
      return {
        current: count,
        target: 3,
        completed,
        percent: Math.round((count / 3) * 100),
        formattedProgress: `${count} / 3 Stages Maxed`,
      };
    },
  },
  {
    id: 'ach_world_tour',
    title: 'Grand Tourer',
    description: 'Compete across all 6 automated world circuits.',
    category: 'milestones',
    tier: 'gold',
    iconName: 'Sparkles',
    target: 6,
    unit: 'circuits',
    checkProgress: (stats) => {
      const count = stats.circuitsRaced?.length || 0;
      const completed = count >= 6;
      return {
        current: count,
        target: 6,
        completed,
        percent: Math.round((count / 6) * 100),
        formattedProgress: `${count} / 6 Circuits Raced`,
      };
    },
  },
  {
    id: 'ach_nitro_surge',
    title: 'Nitro Overdrive',
    description: 'Discharge nitro boost at full throttle 15 times.',
    category: 'speed',
    tier: 'bronze',
    iconName: 'Zap',
    target: 15,
    unit: 'boosts',
    checkProgress: (stats) => {
      const count = stats.nitroBoostCount || 0;
      const completed = count >= 15;
      return {
        current: count,
        target: 15,
        completed,
        percent: Math.min(100, Math.round((count / 15) * 100)),
        formattedProgress: `${count} / 15 Boosts`,
      };
    },
  },
  {
    id: 'ach_fast_lap',
    title: 'Flying Lap Titan',
    description: 'Record an ultra-fast lap time of under 45.0 seconds.',
    category: 'mastery',
    tier: 'platinum',
    iconName: 'ShieldCheck',
    target: 45000,
    unit: 'ms',
    checkProgress: (stats) => {
      const best = stats.bestLapMs;
      const completed = best !== null && best <= 45000;
      return {
        current: best || 0,
        target: 45000,
        completed,
        percent:
          completed ? 100 : best !== null ? Math.min(99, Math.round((45000 / best) * 100)) : 0,
        formattedProgress:
          best !== null ? `${(best / 1000).toFixed(1)}s (Target: <45.0s)` : 'No Lap Logged',
      };
    },
  },
];
