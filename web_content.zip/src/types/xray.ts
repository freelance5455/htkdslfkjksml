export type ScanStatus =
  | "queued"
  | "validating"
  | "scanning"
  | "testing_interactions"
  | "analyzing_ai"
  | "generating_prompt"
  | "completed"
  | "failed";

export interface ScanConfig {
  maxPages: number;
  maxDepth: number;
  maxInteractionsPerPage: number;
  includeMobile: boolean;
  respectRobotsTxt: boolean;
}

export interface ScanLogEntry {
  timestamp: string;
  level: "info" | "warn" | "error" | "success";
  message: string;
}

export interface ScanRecord {
  id: string;
  targetUrl: string;
  normalizedUrl: string;
  domain: string;
  status: ScanStatus;
  progressPercent: number;
  currentPage: string | null;
  pagesDiscovered: number;
  pagesAnalyzed: number;
  buttonsTested: number;
  interactionsPassed: number;
  interactionsFailed: number;
  interactionsBlocked: number;
  errorMessage: string | null;
  config: ScanConfig;
  logs: ScanLogEntry[];
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
}

export interface SectionInfo {
  tag: string;
  id: string | null;
  className: string | null;
  role: string | null;
  headingText: string | null;
  textPreview: string;
  boundingBox: { x: number; y: number; width: number; height: number } | null;
}

export interface TypographyInfo {
  fontFamily: string;
  fontSize: string;
  fontWeight: string;
  lineHeight: string;
  color: string;
  sampleTag: string;
}

export interface ColorSwatch {
  hex: string;
  rgb: string;
  usage: "background" | "text" | "accent" | "border";
  count: number;
}

export interface ImageAssetInfo {
  src: string;
  alt: string;
  width: number;
  height: number;
  naturalWidth: number;
  naturalHeight: number;
  isSvg: boolean;
}

export interface FormFieldInfo {
  name: string | null;
  type: string;
  placeholder: string | null;
  label: string | null;
  required: boolean;
  pattern: string | null;
  minLength: number | null;
  maxLength: number | null;
}

export interface FormInfo {
  action: string | null;
  method: string;
  fields: FormFieldInfo[];
  submitButtonText: string | null;
  hasCaptchaOrAuth: boolean;
}

export interface ResponsiveDiffInfo {
  desktopWidth: number;
  mobileWidth: number;
  hasHorizontalOverflowMobile: boolean;
  mobileMenuDetected: boolean;
  navCollapsedOnMobile: boolean;
  hiddenOnMobileCount: number;
  stackedLayoutDetected: boolean;
}

export interface PageAnalysis {
  id: string;
  scanId: string;
  url: string;
  path: string;
  depth: number;
  title: string;
  metaDescription: string | null;
  statusCode: number | null;
  loadTimeMs: number;
  isBlocked: boolean;
  blockReason: string | null;
  desktopScreenshotPath: string | null;
  mobileScreenshotPath: string | null;
  visibleText: string;
  headings: { level: number; text: string }[];
  navigationLinks: { text: string; href: string; isExternal: boolean }[];
  footerLinks: { text: string; href: string }[];
  sections: SectionInfo[];
  typography: TypographyInfo[];
  colors: ColorSwatch[];
  spacingMetrics: {
    containerMaxWidths: string[];
    sectionPaddings: string[];
    gridGaps: string[];
  };
  images: ImageAssetInfo[];
  svgCount: number;
  forms: FormInfo[];
  responsive: ResponsiveDiffInfo;
  consoleErrors: string[];
  networkApiEndpoints: string[];
  createdAt: string;
}

export type InteractionOutcome =
  | "navigated"
  | "modal_opened"
  | "dropdown_toggled"
  | "tab_switched"
  | "dom_mutated"
  | "validation_triggered"
  | "no_visible_change"
  | "failed"
  | "blocked_security"
  | "untested_destructive";

export interface InteractiveElementTest {
  id: string;
  scanId: string;
  pageId: string;
  pageUrl: string;
  elementType: "button" | "link" | "dropdown" | "tab" | "menu" | "form" | "input" | "other";
  selector: string;
  label: string;
  ariaLabel: string | null;
  href: string | null;
  isVisible: boolean;
  tested: boolean;
  outcome: InteractionOutcome;
  details: string;
  beforeUrl: string;
  afterUrl: string;
  consoleErrors: string[];
  durationMs: number;
}

export interface AIAnalysisReport {
  id: string;
  scanId: string;
  provider: string;
  model: string;
  executiveSummary: string;
  observedFacts: string[];
  inferredBehavior: string[];
  unverifiedOrInaccessible: string[];
  pageReports: {
    url: string;
    title: string;
    purpose: string;
    layoutSummary: string;
    keyComponents: string[];
    observedIssues: string[];
  }[];
  navigationAndJourneys: string[];
  visualDesignSystem: {
    paletteSummary: string;
    typographySummary: string;
    spacingAndLayout: string;
    componentPatterns: string[];
  };
  responsiveBehaviorSummary: string;
  observedFunctionalitySummary: string;
  backendEvidence: string[];
  createdAt: string;
}

export interface MasterPromptRecord {
  id: string;
  scanId: string;
  version: number;
  refinementInstruction: string | null;
  promptText: string;
  characterCount: number;
  provider: string;
  model: string;
  createdAt: string;
}

export interface FullScanDetails {
  scan: ScanRecord;
  pages: PageAnalysis[];
  interactions: InteractiveElementTest[];
  report: AIAnalysisReport | null;
  prompts: MasterPromptRecord[];
}
