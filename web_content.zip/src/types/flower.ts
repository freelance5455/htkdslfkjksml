export type FlowerCategory =
  | "Atirgullar"
  | "Lolalar va piyozgullar"
  | "Bog‘ gullari"
  | "Xona va orxideya gullari"
  | "Yovvoyi va dala gullari"
  | "Ekzotik va tropik gullar"
  | "O‘zbekiston tog‘ gullari";

export type FlowerColor =
  | "Pushti"
  | "Qizil"
  | "Oq"
  | "Sariq"
  | "Binafsha"
  | "Ko‘k"
  | "To‘q sariq"
  | "Aralash";

export interface FlowerEntry {
  id: string;
  uzName: string;
  enName: string;
  latinName: string;
  wikiQuery: string;
  family: string;
  category: FlowerCategory;
  color: FlowerColor;
  season: string;
  origin: string;
  fragrance: string;
  meaning: string;
  care: string;
  description: string;
  fallbackImage: string;
}

/**
 * Compact botanical tuple:
 * [uzName, enName, latinName, wikiQuery, family, category, color, season, origin, fragrance, meaning, traitUz]
 */
export type CompactFlowerTuple = [
  string,
  string,
  string,
  string,
  string,
  FlowerCategory,
  FlowerColor,
  string,
  string,
  string,
  string
];

export const FALLBACK_IMAGES_BY_CATEGORY: Record<FlowerCategory, string> = {
  "Atirgullar": "/src/assets/images/category_roses_peonies_1795169659425.jpg",
  "Bog‘ gullari": "/src/assets/images/category_roses_peonies_1795169659425.jpg",
  "Lolalar va piyozgullar": "/src/assets/images/category_tulips_spring_1795169660371.jpg",
  "Xona va orxideya gullari": "/src/assets/images/category_exotic_orchids_1795169660472.jpg",
  "Ekzotik va tropik gullar": "/src/assets/images/category_exotic_orchids_1795169660472.jpg",
  "Yovvoyi va dala gullari": "/src/assets/images/category_wildflowers_meadow_1795169660491.jpg",
  "O‘zbekiston tog‘ gullari": "/src/assets/images/category_wildflowers_meadow_1795169660491.jpg",
};

const CARE_TEMPLATES: Record<FlowerCategory, string> = {
  "Atirgullar":
    "Kundalik 6 soatdan kam bo‘lmagan quyosh nuri, unumdor va namlikni yaxshi o‘tkazuvchi tuproq hamda muntazam ildizdan sug‘orishni yoqtiradi.",
  "Lolalar va piyozgullar":
    "Kuzda salqin va yumshoq tuproqqa ekiladi; bahorda yorug‘ quyosh va mo‘tadil namlikda yirik hamda tiniq gul ochadi.",
  "Bog‘ gullari":
    "Ochiq yoki yarim soyali bog‘ maydonlarida, chirindiga boy tuproqda va shamoldan himoyalangan joyda uzoq yillar barq urib o‘sadi.",
  "Xona va orxideya gullari":
    "Tarqoq yorqin yorug‘lik, havo namligi va ildiz chirishidan saqlaydigan yengil substrat hamda iliq suv bilan purkashni xush ko‘radi.",
  "Yovvoyi va dala gullari":
    "Tabiiy quyoshli ochiq maydonlarga moslashgan; ortiqcha o‘g‘it talab qilmaydi va qurg‘oqchilikka ancha chidamli.",
  "Ekzotik va tropik gullar":
    "Issiq harorat (+18°C dan yuqori), yuqori namlik va yorqin, ammo to‘g‘ridan-to‘g‘ri kuydirmaydigan quyosh nurini talab qiladi.",
  "O‘zbekiston tog‘ gullari":
    "Quruq va toshloq tog‘ yonbag‘irlariga xos bo‘lib, yaxshi drenajli tuproq, bahorgi yomg‘ir namligi va mo‘l quyoshda go‘zal gullaydi.",
};

export function hydrateFlowerTuple(
  tuple: CompactFlowerTuple,
  index: number
): FlowerEntry {
  const [
    uzName,
    enName,
    latinName,
    wikiQuery,
    family,
    category,
    color,
    season,
    origin,
    fragrance,
    meaning,
  ] = tuple;

  const slug = latinName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

  return {
    id: `${slug}-${index}`,
    uzName,
    enName,
    latinName,
    wikiQuery,
    family,
    category,
    color,
    season,
    origin,
    fragrance,
    meaning,
    care: CARE_TEMPLATES[category],
    description: `${uzName} (${latinName}) — ${family} oilasiga mansub nafis gul turi. Asl vatani ${origin} bo‘lib, asosan ${season.toLowerCase()} faslida ${color.toLowerCase()} tusdagi gulbarglari bilan ajralib turadi. ${fragrance} ifori bilan bog‘ va guldastalarga o‘zgacha ko‘rk bag‘ishlaydi. Gul tilida u «${meaning.toLowerCase()}» ma’nosini anglatadi.`,
    fallbackImage: FALLBACK_IMAGES_BY_CATEGORY[category],
  };
}

export const ALL_CATEGORIES: Array<"Barchasi" | FlowerCategory> = [
  "Barchasi",
  "Atirgullar",
  "Lolalar va piyozgullar",
  "Bog‘ gullari",
  "Xona va orxideya gullari",
  "Yovvoyi va dala gullari",
  "Ekzotik va tropik gullar",
  "O‘zbekiston tog‘ gullari",
];

export const ALL_COLORS: Array<"Barcha ranglar" | FlowerColor> = [
  "Barcha ranglar",
  "Pushti",
  "Qizil",
  "Oq",
  "Sariq",
  "Binafsha",
  "Ko‘k",
  "To‘q sariq",
  "Aralash",
];
