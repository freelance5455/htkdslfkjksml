export const PARTNER_NAMES = ['Abo Jan', 'Hassan', 'Sajjad Khan'] as const;

export type PartnerName = (typeof PARTNER_NAMES)[number];

export const TAX_RATE = 0.0015;
export const STORAGE_KEY = 'ublFundData';

export interface HistoryEntry {
  date: string;
  title: string;
  detail: string;
  amount: number;
}

export interface FundData {
  balances: [number, number, number];
  totalProfit: number;
  totalTax: number;
  history: HistoryEntry[];
}

export type TransactionFilter = 'all' | 'profit' | 'withdrawal';

export interface StatusMessage {
  text: string;
  tone: 'success' | 'error';
}
