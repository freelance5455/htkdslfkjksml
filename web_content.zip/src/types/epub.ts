export interface EpubHighlight {
  id: string;
  bookId: string;
  cfiRange: string;
  text: string;
  color: string;
  note?: string;
  createdAt: number;
}

export interface EpubTocItem {
  id: string;
  label: string;
  href: string;
  subitems?: EpubTocItem[];
}

export interface SavedBookRecord {
  id: string;
  fileName: string;
  title: string;
  author: string;
  buffer: ArrayBuffer;
  savedAt: number;
  fileSize: number;
}

export interface ReadingProgressRecord {
  bookId: string;
  cfi: string;
  percentage: number;
  chapterTitle?: string;
  updatedAt: number;
}
