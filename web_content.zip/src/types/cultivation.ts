/**
 * Amazing Sect Cultivation - Core Domain Types (Expanded v3)
 */

export type Season = 'Spring' | 'Summer' | 'Autumn' | 'Winter';

export type SectAlignment = 
  | 'Righteous Orthodox' 
  | 'Demonic Blood Cult' 
  | 'Buddhic Zen' 
  | 'Cloud Mist Neutral' 
  | 'Imperial Court';

export type SectStability = 'Unstable' | 'Fluctuating' | 'Steady' | 'Flourishing' | 'Ascendant';

export type SpiritRootType = 
  | 'Metal' 
  | 'Wood' 
  | 'Water' 
  | 'Fire' 
  | 'Earth' 
  | 'Thunder' 
  | 'Ice' 
  | 'Wind' 
  | 'Yin-Yang' 
  | 'Chaos'
  | 'Heavenly'
  | 'Immortal';

export type TalentTier = 'Poor' | 'Lazy' | 'Mediocre' | 'Talented' | 'Prodigy' | 'Innate';
export type SpiritRootPurity = TalentTier; // Compatibility alias

export type SkinTone = 'Fair Jade' | 'Warm Honey' | 'Sun Bronze';
export type ClothingColor =
  | 'Azure'
  | 'Gold'
  | 'Crimson'
  | 'Pine'
  | 'Ebon'
  | 'Celestial Violet'
  | 'Astral Jade'
  | 'Primordial Obsidian'
  | 'Phoenix Scarlet'
  | 'Heavenly White';

export type AvatarAuraEffect =
  | 'None'
  | 'Azure Thunder'
  | 'Golden Lightning'
  | 'Void Sparks'
  | 'Celestial Flame';

export type MythicalFormType =
  | 'None'
  | 'Thunder Sovereign'
  | 'Immortal Beast';

export type BgmTheme = 'epic' | 'serene' | 'bambooMist' | 'celestialCourt' | 'starlightAscent';
export type GraphicsQuality = 'low' | 'medium' | 'high';
export type DiscipleExpression = 'Serene' | 'Smile' | 'Fierce' | 'Stoic' | 'Smirk';

export type CultivationPathType =
  | 'Qi Cultivator'
  | 'Body Cultivator'
  | 'Sword Cultivator'
  | 'Soul Cultivator'
  | 'Alchemy Dao';

export type DiscipleEmotion =
  | 'Serene'
  | 'Inspired'
  | 'Determined'
  | 'Cautious'
  | 'Anxious'
  | 'Envious'
  | 'Melancholic'
  | 'Arrogant';

export type BondLevel = 1 | 2 | 3 | 4 | 5;

export interface DailyDivinationResult {
  id: string;
  dateStr: string;
  hexagramName: string;
  omenTier: 'Supreme Auspicious' | 'Great Fortune' | 'Auspicious' | 'Balanced Dao';
  poem: string;
  effectLabel: string;
  buffType: 'stones_surge' | 'qi_rain' | 'tribulation_blessing' | 'pill_miracle' | 'merit_decree' | 'combat_awakening';
  appliedAt: number;
}

export interface DailyCheckInState {
  lastClaimDate: string; // YYYY-MM-DD
  streakCount: number; // 0..7+
  totalClaims: number;
}

export type ConstitutionType = 
  | 'Mortal Bone'
  | 'Innate Sword Embryo'
  | 'Ancient Desolate Sacred Physique'
  | 'Pure Yang Divine Body'
  | 'Pure Yin Sacred Body'
  | 'Nine Heavens Phoenix Body'
  | 'Five Elements Dao Body'
  | 'Void Spiritual Constitution'
  | 'Clear Jade Physique'
  | 'Nether Void Body';

export interface ConstitutionEffect {
  name: ConstitutionType;
  title: string;
  positive: string[];
  negative: string[];
  combatBonus: number;
  qiCostMultiplier: number;
  stressVulnerability: number; // multiplier e.g. 1.2 = +20%
}

export type SocialBackground = 
  | 'Imperial Clan Scion'
  | 'Extinct Clan Orphan'
  | 'Wandering Rogue Cultivator'
  | 'Mountain Village Mortal'
  | 'Merchant Guild Heir'
  | 'Ancient Aristocrat Prodigy'
  | 'Daoist Temple Acolyte';

export type DiscipleRank = 
  | 'Outer' 
  | 'Inner' 
  | 'Direct' 
  | 'Elder' 
  | 'Grand Elder'
  | 'Sect Leader';

export type DiscipleStatus = 
  | 'Idle' 
  | 'Cultivation' 
  | 'Commission' 
  | 'Expedition' 
  | 'Alchemy' 
  | 'Breakthrough' 
  | 'Tribulation'
  | 'Tournament';

export type RelationType = 
  | 'Lover'
  | 'Confidant'
  | 'Master-Disciple'
  | 'Adoptive Parent'
  | 'Son/Daughter'
  | 'Sworn Sibling'
  | 'Friend'
  | 'Acquainted'
  | 'Rival'
  | 'Grudge';

export interface DiscipleRelation {
  targetId: string;
  type: RelationType;
  level?: BondLevel; // 1: Unknown, 2: Acquaintance, 3: Trusted, 4: Devoted, 5: Inseparable
  affinity: number; // -100 to 100
  jealousy: number; // 0 to 100
  grudgeReason?: string;
}

export type EquipmentSlot = 'clothing' | 'weapon' | 'item' | 'companion';
export type EquipmentTier = 'Mortal' | 'Spiritual' | 'Earth' | 'Heaven' | 'Divine';

export interface EquipmentItem {
  id: string;
  name: string;
  slot: EquipmentSlot;
  tier: EquipmentTier;
  minRealmIndex: number; // Required realm to equip
  combatBonus: number;
  cultivationRateBonus: number; // % bonus, e.g. 15 for +15%
  defenseBonus: number;
  description: string;
  element?: SpiritRootType;
}

export type ChampionTitle = 'Champion I' | 'Champion II' | 'Champion S';

export interface CoreMemory {
  id: string;
  year: number;
  season?: Season;
  title?: string;
  event?: string;
  impact?: 'Positive' | 'Negative' | 'Neutral';
  impactText?: string;
  category?: 
    | 'TournamentVictory' 
    | 'TournamentLoss' 
    | 'TribulationSurvival' 
    | 'Breakthrough' 
    | 'BondFormed' 
    | 'BondReversed' 
    | 'InvasionHeroism';
  traitAcquired?: string;
  traitShaped?: string;
  personalityShift?: string;
  timestamp?: number;
}

export interface RealmDefinition {
  id: string;
  name: string;
  majorRealm: string;
  subStage: string;
  order: number;
  qiRequired: number;
  lifespanBonus: number;
  combatPower: number;
  prestigeYield: number;
  requiresTribulation: boolean;
  tribulationLightningPower?: number;
}

export interface Disciple {
  id: string;
  name: string;
  gender: 'Male' | 'Female';
  age: number;
  lifespan: number;
  currentRealmIndex: number; // references REALMS
  cultivationExp: number;
  maxExp: number;
  talent: number; // 1 to 100
  talentTier: TalentTier;
  spiritRootPurity?: string; // Backwards compatible
  temperament: 'Calm' | 'Arrogant' | 'Benevolent' | 'Ruthless' | 'Carefree' | 'Loyal';
  preference: 'Combat' | 'Alchemy' | 'Meditation' | 'Social' | 'Exploration';
  spiritRoot: SpiritRootType;
  constitution: ConstitutionType;
  background: SocialBackground;
  rank: DiscipleRank;
  status: DiscipleStatus;
  contribution: number;
  loyalty: number; // 0 to 100
  morale: number; // 0 to 100
  stress: number; // 0 to 100
  combatPower: number;
  maxHp?: number;
  currentHp?: number;
  maxQiEnergy?: number;
  currentQiEnergy?: number;
  isFavorite?: boolean; // Max 3 favorites allowed
  championTitle?: ChampionTitle;
  qiBurstUntil?: number; // Active timestamp for 50% cultivation boost
  soulProtected?: boolean; // Soul Lantern Destiny Protection Seal active
  soulResonanceUntil?: number; // Timestamp until soul flame resonance boost expires
  appearanceIndex?: number;
  skinTone?: SkinTone;
  clothingColor?: ClothingColor;
  hairColor?: string;
  expression?: DiscipleExpression;
  auraEffect?: AvatarAuraEffect;
  mythicalForm?: MythicalFormType;
  equippedItems: {
    clothing?: EquipmentItem;
    weapon?: EquipmentItem;
    item?: EquipmentItem;
    companion?: EquipmentItem;
  };
  relations: DiscipleRelation[];
  biography: string[];
  coreMemories: CoreMemory[];
  avatarStyle: {
    robeColor: string;
    hairColor: string;
    auraColor: string;
    accessory: string;
    appearanceIndex?: number; // 0-11
    skinTone?: SkinTone;
    clothingColor?: string;
    expression?: DiscipleExpression;
    auraEffect?: AvatarAuraEffect;
    mythicalForm?: MythicalFormType;
  };
  assignedBuildingId?: string;
  expeditionId?: string;
  recruitedYear?: number;
  masterId?: string; // Family tree lineage
  cultivationType?: CultivationPathType; // Body Cultivators skip Heavenly Lightning Tribulations
  emotion?: DiscipleEmotion;
  personalAlignment?: SectAlignment;
  breakthroughReadySinceYear?: number;
  negativeTraits?: string[];
  breakthroughFailures?: number;
}

export interface SectResources {
  spiritStones: number;
  qi: number;
  pills: number;
  merit: number; // Merits count as Sect Reputation
}

export interface ResourceRates {
  spiritStonesRate: number;
  qiRate: number;
  pillsRate: number;
  meritRate: number;
}

export interface Building {
  id: string;
  name: string;
  description: string;
  level: number;
  maxLevel: number;
  baseCost: { spiritStones: number; qi?: number; merit?: number };
  costMultiplier: number;
  assignedDisciples: string[];
  maxDisciples: number;
  effectDescription: string;
  type: 'hall' | 'array' | 'mine' | 'alchemy' | 'scripture' | 'discipline' | 'tribulation' | 'garden' | 'forge';
  unlocked: boolean;
  unlockRequirement?: {
    minHallLevel?: number;
    minPrestige?: number;
    description: string;
  };
}

export interface SecretRealm {
  id: string;
  name: string;
  dangerLevel: 'Safe' | 'Moderate' | 'Dangerous' | 'Perilous' | 'Calamitous';
  minRealmIndex: number;
  recommendedPower: number;
  durationSeconds: number;
  description: string;
  drops: string[];
  potentialStones: number;
  potentialPills: number;
  potentialMerit: number;
}

export interface NeighborSect {
  id: string;
  name: string;
  leaderName: string;
  alignment: SectAlignment;
  strength: number;
  reputation: number; // -100 to 100
  attitude: 'Hostile' | 'Wary' | 'Neutral' | 'Respectful' | 'Allied';
  specialty: string;
  territoryPoints: number;
  cooldownUntil?: number;
}

export interface ChronicleEvent {
  id: string;
  year: number;
  season: Season;
  category: 'Breakthrough' | 'Tribulation' | 'Expedition' | 'Relation' | 'Diplomacy' | 'Sect' | 'Merchant' | 'Divine' | 'Crisis' | 'Tournament';
  title: string;
  details: string;
  timestamp: number;
  significance: 'normal' | 'major' | 'divine' | 'calamity';
}

export type MerchantTier = 'Mortal' | 'Spiritual' | 'Earth' | 'Heaven' | 'Divine';

export interface MerchantItem {
  id: string;
  name: string;
  tier: MerchantTier;
  type: 'Pill' | 'Talisman' | 'Artifact' | 'Manual' | 'Elixir';
  rarity: 'Common' | 'Spiritual' | 'Earth' | 'Heaven' | 'Divine';
  description: string;
  price: number;
  currency: 'spiritStones' | 'merit';
  effect: string;
  stock: number;
}

export interface DynamicSectEventChoice {
  text: string;
  outcomeText: string;
  effect: {
    spiritStones?: number;
    qi?: number;
    pills?: number;
    merit?: number;
    alignmentShift?: SectAlignment;
    admitDisciple?: boolean;
    loyaltyChange?: number;
  };
}

export interface DynamicSectEvent {
  id: string;
  title: string;
  category: 'Opportunity' | 'Encounter' | 'Crisis' | 'Petition';
  description: string;
  expiresAt: number;
  totalDurationSeconds: number;
  choices: DynamicSectEventChoice[];
}

export interface AlignmentQuest {
  id: string;
  title: string;
  description: string;
  requirementDesc: string;
  completed: boolean;
  rewardDesc: string;
}

export interface SectAlignmentData {
  chosen: boolean;
  currentAlignment: SectAlignment;
  canChange: boolean;
  quests: Record<SectAlignment, AlignmentQuest[]>;
}

export interface DivinePetition {
  id: string;
  discipleId: string;
  discipleName: string;
  title: string;
  concernText: string;
  type: 'Resource' | 'Dilemma' | 'Confession' | 'Suggestion';
  resolved: boolean;
}

export type TournamentCategory = 
  | 'InnerPromotion'      // Promotion directly to inner disciple
  | 'ElderChallenge'       // Challenging sect grand/elders
  | 'LeaderChallenge'      // Challenging sect leader
  | 'AllSectsUniversal';   // Tournament for All sects (can challenge regardless of realm)

export interface TournamentBooster {
  id: string;
  name: string;
  description: string;
  effect?: string;
  effectDescription?: string;
  cost: number;
  hpBonus: number;
  energyBonus: number;
  powerMultiplier: number;
}

export interface TournamentFighter {
  id: string;
  name: string;
  rank: DiscipleRank;
  currentRealmIndex: number;
  combatPower: number;
  maxHp: number;
  currentHp: number;
  maxEnergy: number;
  currentEnergy: number;
  spiritRoot: SpiritRootType;
  talentTier?: TalentTier;
  constitution?: ConstitutionType;
  gender: 'Male' | 'Female';
  avatarStyle: {
    robeColor: string;
    hairColor: string;
    auraColor: string;
    accessory: string;
    appearanceIndex?: number;
    skinTone?: SkinTone;
    clothingColor?: string;
    expression?: DiscipleExpression;
    auraEffect?: AvatarAuraEffect;
    mythicalForm?: MythicalFormType;
  };
  isForeign?: boolean;
  sectName?: string;
  alignment?: SectAlignment;
  championTitle?: ChampionTitle;
  booster?: TournamentBooster;
  winProbability?: number; // Dev Mode stats
  roundsWon?: number;
}

export interface TournamentMatchLog {
  round?: number;
  turn: number;
  attacker: string;
  defender: string;
  skillName?: string;
  actionText: string;
  damage: number;
  elementalAdvantage?: boolean;
  crit?: boolean;
  statusEffectApplied?: string;
  effectApplied?: 'Burn' | 'Freeze' | 'Stun' | 'Shield' | 'QiDrain';
  defenderHpRemaining: number;
  attackerEnergyRemaining?: number;
}

export interface IncursionInvader {
  id: string;
  name: string;
  leaderName: string;
  sectName: string;
  isMonster?: boolean;
  threatPower: number;
  strength?: number;
  combatPower?: number;
  combatPowerBefore: number;
  combatPowerAfter: number;
  hpBefore: number;
  hpAfter: number;
  spiritRoot: SpiritRootType;
  constitution: ConstitutionType;
  talentTier: TalentTier;
  lootStones: number;
  lootPills: number;
}

export interface SectSector {
  id: string;
  name: string;
  region: string;
  description: string;
  level: number;
  maxLevel: number;
  unlocked: boolean;
  minHallLevel: number;
  unlockCostStones: number;
  unlockCostMerit: number;
  upgradeBaseStones: number;
  bonusType: 'stones' | 'qi' | 'combat' | 'cultivation' | 'defense' | 'pills';
  bonusValuePerLevel: number;
  bonusLabel: string;
  guardianDiscipleId?: string;
  controlPercent: number;
}

export interface SeasonalEventChoice {
  text: string;
  outcomeText: string;
  effect: {
    spiritStones?: number;
    qi?: number;
    pills?: number;
    merit?: number;
    prestige?: number;
    allExp?: number;
    allCombat?: number;
    allMorale?: number;
    allStress?: number;
    admitDisciple?: boolean;
  };
}

export interface SeasonalEventItem {
  id: string;
  title: string;
  category: 'Opportunity' | 'Encounter' | 'Sector' | 'Tribulation' | 'Crisis' | 'TournamentNotice';
  description: string;
  choices: SeasonalEventChoice[];
}

