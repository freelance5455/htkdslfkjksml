import { Timestamp } from 'firebase/firestore';

export type ProductGender = 'Men' | 'Women' | 'Unisex';

export type OrderStatus =
  | 'Pending'
  | 'Confirmed'
  | 'Processing'
  | 'Shipped'
  | 'Delivered'
  | 'Cancelled';

export type PaymentStatus = 'Pending' | 'Paid' | 'Refunded';

export type PaymentMethod = 'Cash on Delivery';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  discountPrice: number;
  category: string;
  gender: ProductGender;
  sizes: string[];
  colors: string[];
  stock: number;
  imageUrl: string;
  isNewArrival: boolean;
  isBestSeller: boolean;
  isActive: boolean;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  displayOrder: number;
  isActive: boolean;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface CartItem {
  productId: string;
  name: string;
  imageUrl: string;
  category: string;
  price: number;
  discountPrice: number;
  effectivePrice: number;
  selectedSize: string;
  selectedColor: string;
  quantity: number;
  maxStock: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  phone: string;
  location?: string;
  address: string;
  city: string;
  pinCode: string;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  status: OrderStatus;
  itemCount: number;
  totalQuantity: number;
  subtotal: number;
  shippingFee: number;
  totalAmount: number;
  primaryProductName: string;
  primaryProductImage: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface OrderItem {
  id: string;
  orderId: string;
  userId: string;
  productId: string;
  productName: string;
  productImage: string;
  selectedSize: string;
  selectedColor: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  phone?: string;
  location?: string;
  address?: string;
  city?: string;
  pinCode?: string;
  role: 'customer';
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface AdminUser {
  uid: string;
  email: string;
  name: string;
  role: 'admin';
  addedBy: string;
  createdAt?: Timestamp;
}

export interface StoreSettings {
  storeName: string;
  storeAddress?: string;
  supportEmail: string;
  announcementText: string;
  freeShippingThreshold: number;
  standardShippingFee: number;
  onlinePaymentEnabled: boolean;
  updatedAt?: Timestamp;
}

export type AppView =
  | 'home'
  | 'men'
  | 'women'
  | 'new-arrivals'
  | 'best-sellers'
  | 'account'
  | 'admin-login'
  | 'admin-dashboard';

export type AdminSection =
  | 'dashboard'
  | 'add-product'
  | 'all-products'
  | 'manage-orders'
  | 'customers'
  | 'categories'
  | 'order-history'
  | 'settings';
