// ============================================================
// AI CREATOR STUDIO — YOUTUBE AI, DINHEIRO & FUTURO
// MÓDULO MASTER: TYPE DEFINITIONS
// ============================================================

export type YouTubeNichePreset =
  | "AI_FUTURO"
  | "DINHEIRO_NEGOCIOS"
  | "TECNOLOGIA"
  | "IA_PEQUENOS_NEGOCIOS"
  | "STARTUPS"
  | "ROBOTICA_FUTURO"
  | "CUSTOM";

export type TrendRanking = "HOT" | "CRESCENTE" | "OPORTUNIDADE" | "EVERGREEN" | "ALTO_RISCO";

export type VideoFormatType = "SHORT" | "QUICK_VIDEO" | "LONG_VIDEO" | "DOCUMENTARY";

export type ClaimVerificationStatus = "CONFIRMADA" | "PRECISA_VERIFICACAO" | "NAO_CONFIRMADA";

export type ClaimCategory = "FATO" | "OPINIAO" | "PREVISAO" | "ESTIMATIVA" | "ALEGACAO_TERCEIROS";

export type AvatarMode = "FACELESS" | "VOICE_ONLY" | "AVATAR" | "AVATAR_SCREEN_RECORDING" | "AVATAR_B_ROLL";

export type VisualElementType = "AVATAR" | "GRAPHIC" | "IMAGE" | "VIDEO_BROLL" | "SCREEN_RECORDING" | "ANIMATION" | "INFOGRAPHIC";

export type CopyrightStatus = "USO_AUTORIZADO" | "VERIFICAR_LICENCA" | "NAO_UTILIZAR";

export type AiDisclosureLevel = "NAO_NECESSARIO" | "RECOMENDADO" | "OBRIGATORIO";

export type RiskLevel = "BAIXO" | "MEDIO" | "ALTO";

export type AutomationLevel = "MANUAL" | "SEMI_AUTOMATICO" | "AUTOMATICO";
export type AutomationMode = AutomationLevel;
export type ChannelPresetType = YouTubeNichePreset;
export type VideoPacing = "ULTRA_DYNAMIC" | "BALANCED" | "DOCUMENTARY_CALM";
export type SubtitleStylePreset = "BOLD_YELLOW" | "CLEAN_WHITE" | "TECH_CYAN" | "KINETIC_BOUNCE";

export type TargetLanguage = "PT" | "EN" | "ES" | "FR";

// --- CANAL DO YOUTUBE (CHANNEL FACTORY) ---
export interface YouTubeChannelProject {
  id: string;
  name: string;
  handle: string;
  logoUrl: string;
  bannerUrl: string;
  description: string;
  language: TargetLanguage;
  targetAudience: string;
  countryRegion: string;
  niche: string;
  subNiche: string;
  preset: YouTubeNichePreset;
  visualIdentity: {
    primaryColor: string;
    accentColor: string;
    fontFamily: string;
    visualStyle: string; // "Cyber Dark", "Clean Tech", "Fintech Minimal", "Documentary Gold"
    badgeStyle: string;
  };
  defaultVoice: {
    id: string;
    name: string;
    provider: "ELEVENLABS" | "GEMINI_TTS";
    tone: string;
  };
  avatarConfig?: {
    enabled: boolean;
    style: "REALISTIC" | "STYLIZED_3D" | "MINIMAL_CYBER" | "HOLOGRAM";
    characterName: string;
    avatarUrl: string;
    defaultMode: AvatarMode;
  };
  editingStyle: {
    pacing: "ULTRA_DYNAMIC" | "BALANCED" | "DOCUMENTARY_CALM";
    transitions: string;
    musicGenre: string;
    subtitleStyle: "BOLD_YELLOW" | "CLEAN_WHITE" | "TECH_CYAN" | "KINETIC_BOUNCE";
  };
  publishingFrequency: {
    longVideosPerWeek: number;
    shortsPerWeek: number;
    preferredDays: string[];
    preferredTime: string; // e.g. "18:00"
  };
  goals: {
    primaryGoal: "SUBSCRIBERS" | "ADSENSE_REVENUE" | "COMMUNITY_AUTHORITY" | "AFFILIATE_SALES";
    targetSubscribers: number;
    targetMonthlyViews: number;
  };
  automationLevel: AutomationLevel;
  automationMode?: AutomationLevel;
  createdAt: string;
  updatedAt: string;
}

// --- AI TREND RESEARCHER ---
export interface TrendSourceItem {
  name: string;
  url: string;
  sourceType: "PAPER" | "TECH_PRESS" | "EARNINGS_REPORT" | "OFFICIAL_DOC" | "MARKET_INDEX";
  credibilityScore: number; // 0-100
  publishedDate: string;
  snippet: string;
}

export interface TrendTopic {
  id: string;
  title: string;
  nicheCategory: string;
  summary: string;
  ranking: TrendRanking;
  scores: {
    viralScore: number; // 0-100
    searchVolumeScore: number; // 0-100
    retentionPotential: number; // 0-100
    monetizationScore: number; // 0-100
    competitionScore: number; // 0-100 (100 = very high competition, 20 = blue ocean)
    productionEase: number; // 0-100
    recencyScore: number; // 0-100
    credibilityScore: number; // 0-100
  };
  overallOpportunityScore: number; // 0-100
  verifiedSources: TrendSourceItem[];
  suggestedAngles: string[];
  suggestedFormats: VideoFormatType[];
  factChecked: boolean;
  tags: string[];
  discoveredAt: string;
}

// --- IDEA GENERATOR ---
export interface YouTubeVideoIdea {
  id: string;
  channelId: string;
  provisionalTitle: string;
  alternativeTitles: string[];
  editorialAngle: string;
  targetAudience: string;
  hook: string;
  summary: string;
  videoType: VideoFormatType;
  recommendedDurationMinutes: number;
  shortsExtractionPotential: number; // e.g. 3, 5, 8, 10
  suggestedSources: string[];
  searchPotential: number; // 0-100
  monetizationPotential: number; // 0-100
  nonClickbaitAssurance: boolean;
  trendRefId?: string;
  createdAt: string;
}

// --- FACT CHECK ENGINE ---
export interface FactCheckClaim {
  id: string;
  claimText: string;
  category: ClaimCategory;
  status: ClaimVerificationStatus;
  evidenceExplanation: string;
  sources: { title: string; url: string; reliability: string }[];
  isNumericalStat: boolean;
  moneyClaimRisk: boolean;
}

export interface FactCheckReport {
  id: string;
  totalClaimsChecked: number;
  confirmedCount: number;
  needsVerificationCount: number;
  unconfirmedCount: number;
  overallStatus: "APROVADO" | "REVISAR" | "REJEITADO";
  claims: FactCheckClaim[];
  auditedAt: string;
}

// --- ORIGINALITY & CONTENT PROTECTION ENGINE ---
export interface OriginalityAudit {
  id: string;
  similarityToPreviousContentPercent: number; // 0-100 (lower is better)
  uniqueValueScore: number; // 0-100 (higher is better)
  duplicatePhrasesFound: string[];
  repeatedHookPatterns: string[];
  repeatedStructurePattern: boolean;
  riskStatus: "ORIGINAL_EXCELENTE" | "ORIGINAL_BOM" | "RISCO_MODERADO_REPETICAO" | "CONTEUDO_REPETITIVO_BLOQUEADO";
  editorialRecommendation: string;
  valueAddChecklist: {
    deepResearch: boolean;
    educationalContext: boolean;
    comparativeAnalysis: boolean;
    realWorldExamples: boolean;
    originalSynthesisConclusion: boolean;
  };
}

// --- MONEY CONTENT SAFETY ---
export interface MoneyContentSafetyAudit {
  isMoneyRelated: boolean;
  prohibitedTermsDetected: string[];
  educationalLanguageScore: number; // 0-100
  hasMandatoryRiskDisclaimer: boolean;
  disclaimerText: string;
  safetyStatus: "SEGURO_EDUCATIVO" | "NECESSITA_AJUSTE_LINGUAGEM" | "BLOQUEADO_PROMESSA_ENGANOSA";
  suggestedReplacements: { prohibited: string; safeAlternative: string }[];
}

// --- SCRIPT ENGINE (7-PHASE STRUCTURAL SCRIPT) ---
export interface ScriptScenePhase {
  id: string;
  phase: "HOOK" | "CONTEXTO" | "DESENVOLVIMENTO" | "EXEMPLOS" | "ANALISE" | "CONCLUSAO" | "CTA";
  sceneNumber: number;
  title: string;
  narrationText: string;
  onScreenText: string;
  visualPrompt: string;
  visualType: VisualElementType;
  avatarAction?: "SPEAKING_TO_CAMERA" | "SIDE_POINTING" | "VOICEOVER_HIDDEN" | "REACTION_NOD";
  durationSeconds: number;
  transition: string;
  backgroundMusicCue: string;
  soundEffectCue?: string;
  factCheckClaimIds: string[];
}

export interface YouTubeMasterScript {
  id: string;
  channelId: string;
  title: string;
  formatType: VideoFormatType;
  totalDurationSeconds: number;
  phases: ScriptScenePhase[];
  moneySafety: MoneyContentSafetyAudit;
  factCheck: FactCheckReport;
  originality: OriginalityAudit;
  avatarMode: AvatarMode;
  targetLanguage: TargetLanguage;
  status: "DRAFT" | "READY_FOR_PRODUCTION" | "PRODUCING" | "COMPLETED";
  createdAt: string;
  updatedAt: string;
}

// --- SHORTS FACTORY ---
export interface ExtractedShortClip {
  id: string;
  parentScriptId: string;
  shortNumber: number;
  title: string;
  hookText: string;
  contextText: string;
  developmentText: string;
  conclusionText: string;
  ctaText: string;
  durationSeconds: number; // 30-60s
  aspectRatio: "9:16";
  subtitlesPreset: string;
  visualCues: string[];
  viralHookScore: number; // 0-100
  standaloneQualityScore: number; // 0-100
  scheduledAt?: string;
}

// --- THUMBNAIL FACTORY ---
export interface ThumbnailConcept {
  id: string;
  variantNumber: number;
  conceptTitle: string;
  visualDescription: string;
  foregroundSubject: string; // e.g. "Avatar com expressão surpresa segurando gráfico holográfico"
  backgroundImagePrompt: string;
  bigTextOverlay: string; // 3-4 palavras de alto impacto
  textColor: string;
  scores: {
    clarity: number; // 0-100
    curiosity: number; // 0-100
    readabilityMobile: number; // 0-100
    contrast: number; // 0-100
    emotionExpression: number; // 0-100
    relevance: number; // 0-100
    brandIdentityCohesion: number; // 0-100
  };
  overallScore: number; // 0-100
  imageUrl: string;
  abTestRecommended: boolean;
}

// --- TITLE OPTIMIZER & SEO ENGINE ---
export interface TitleOptimizationResult {
  variants: {
    id: string;
    title: string;
    seoScore: number; // 0-100
    curiosityScore: number; // 0-100
    clarityScore: number; // 0-100
    predictedCtrPercent: number; // e.g. 8.4%
    nonMisleadingCheck: boolean;
    abTestBucket: "A" | "B" | "C" | "D" | "E";
  }[];
  seoMetadata: {
    description: string;
    chapters: { timestamp: string; label: string }[];
    hashtags: string[];
    tags: string[];
    primaryKeywords: string[];
    pinnedComment: string;
    recommendedPlaylist: string;
  };
}

// --- COPYRIGHT & RIGHTS GUARD ---
export interface CopyrightResourceCheck {
  id: string;
  resourceType: "MUSIC" | "VIDEO_CLIP" | "IMAGE" | "VOICE" | "AVATAR" | "LOGO";
  resourceName: string;
  licenseSource: string; // e.g. "AI Creator Studio Synth Royalty-Free Library", "Creative Commons CC-BY 4.0", "Comprado Envato"
  status: CopyrightStatus;
  proofMetadata?: string;
  notes: string;
}

// --- YOUTUBE COMPLIANCE AUDIT REPORT & QUALITY GATE ---
export interface YouTubeComplianceReport {
  id: string;
  scriptId: string;
  channelId: string;
  originalityScore: number; // 0-100
  viewerValueScore: number; // 0-100
  repetitivenessScore: number; // 0-100 (lower is better)
  copyrightRisk: RiskLevel;
  aiDisclosureStatus: AiDisclosureLevel;
  monetizationRisk: RiskLevel;
  factCheckPassed: boolean;
  qualityGateStatus: "APROVADO_PARA_PUBLICACAO" | "HUMAN_REVIEW_REQUIRED" | "BLOQUEADO";
  gateReasons: string[];
  complianceDisclaimer: string; // "Avaliação interna de conformidade de risco. Não constitui garantia legal de monetização do YouTube."
  generatedAt: string;
}

// --- CONTENT CALENDAR AI ---
export interface YouTubeCalendarSlot {
  id: string;
  channelId: string;
  dayOfWeek: "SEGUNDA" | "TERCA" | "QUARTA" | "QUINTA" | "SEXTA" | "SABADO" | "DOMINGO";
  dateIso: string;
  contentType: VideoFormatType;
  themePillar: string;
  suggestedTitle: string;
  estimatedProductionMinutes: number;
  status: "PLANEJADO" | "EM_PRODUCAO" | "PRONTO_PARA_REVISAO" | "AGENDADO" | "PUBLICADO";
  linkedProjectId?: string;
  bestTimeSlot: string;
}

// --- CHANNEL ANALYTICS & LEARNING LOOP ---
export interface YouTubeChannelAnalytics {
  channelId: string;
  period: "LAST_7_DAYS" | "LAST_28_DAYS" | "LAST_90_DAYS";
  metrics: {
    totalViews: number;
    viewsGrowthPct: number;
    watchTimeHours: number;
    subscribersGained: number;
    avgCtrPercent: number;
    avgViewDurationSeconds: number;
    shortsViews: number;
    estimatedRevenueUsd: number;
    impressionsTotal: number;
    engagementRatePercent: number;
  };
  topPerformingVideo: {
    title: string;
    views: number;
    ctr: number;
    duration: string;
    topic: string;
  };
  topPerformingShort: {
    title: string;
    views: number;
    retentionPct: number;
    topic: string;
  };
  topicRetentionComparison: {
    topic: string;
    avgRetentionPct: number;
    avgCtr: number;
    sampleSize: number;
  }[];
  aiExplanations: string[];
  aiStrategicRecommendations: string[];
  updatedAt: string;
}

// --- MULTILINGUAL PACKAGE ---
export interface MultilingualAdaptation {
  id: string;
  sourceScriptId: string;
  languages: {
    lang: TargetLanguage;
    localizedTitle: string;
    localizedHook: string;
    localizedDescription: string;
    culturalContextAdjustments: string;
    localizedVoiceName: string;
    status: "PRONTO" | "REVISADO" | "EXPORTADO";
  }[];
}
