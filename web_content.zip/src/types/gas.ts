export type BuildingType = 'residential' | 'commercial';

export type GasType = 'natural_gas_h' | 'natural_gas_l';

export interface GasAppliance {
  id: string;
  name: string;
  category: 'cooking' | 'heating' | 'water_heating' | 'commercial_cooking' | 'commercial_baking' | 'other';
  powerKw: number;
  flowRateM3h: number; // Computed or manually overridden
  quantity: number;
  enabled: boolean;
  notes?: string;
}

export interface GasFittings {
  elbows90: number; // كوع 90 درجة
  elbows45: number; // كوع 45 درجة
  tees: number; // تفرع تي
  valves: number; // صمام غاز
  customEquivalentLength: number; // أطوال مكافئة إضافية
}

export interface GasParameters {
  buildingType: BuildingType;
  gasType: GasType;
  relativeDensity: number; // d = 0.60 for Natural Gas
  calorificValueKwh: number; // PCS (default 10.5 kWh/m³)
  supplyPressureMbar: number; // 20 or 21 mbar
  maxAllowablePressureDropMbar: number; // typically 1.0 mbar (DTU 61.1)
  pipeLengthM: number; // الطول الهندسي للأنبوب بالمتر
  fittings: GasFittings;
  diversityFactorMode: 'auto' | 'manual';
  manualDiversityPercent: number; // 100% means all running together
  maxVelocityMps: number; // 5 m/s residential, 10 m/s commercial
}

export interface CopperPipeDimension {
  nominal: string; // e.g., "16/18"
  internalDiameterMm: number; // D_int
  externalDiameterMm: number; // D_ext
  thicknessMm: number;
  standard: string;
}

export type PipeStatus = 'recommended' | 'valid' | 'warning_velocity' | 'rejected_dp' | 'rejected_both';

export interface PipeCalculationResult {
  pipe: CopperPipeDimension;
  fittingsEqLengthM: number;
  totalEqLengthM: number;
  pressureDropMbar: number; // ΔP
  pressureDropRatioPercent: number; // (ΔP / ΔP_max) * 100
  velocityMps: number; // V
  isPressureDropValid: boolean;
  isVelocityValid: boolean;
  status: PipeStatus;
  statusTextAr: string;
  statusColor: string;
  isOptimal: boolean;
}

export type GasMeterCode = 'G1.6' | 'G2.5' | 'G4' | 'G6' | 'G10' | 'G16' | 'G25' | 'G40' | 'G65';

export interface GasMeterModel {
  code: GasMeterCode;
  qNom: number; // m³/h
  qMax: number; // m³/h
  qMin: number; // m³/h
  maxPowerKwApprox: number;
  connectionSize: string; // e.g. "DN20 (3/4\")"
  centerDistanceMm: number; // Entre-axe e.g. 110mm, 250mm
  typicalApplicationAr: string;
  isSuitable: boolean;
  loadPercentage: number; // (Q_sim / Qmax) * 100
}

export interface CalculationSummary {
  totalInstalledPowerKw: number;
  totalNominalFlowM3h: number;
  diversityFactor: number;
  simultaneousFlowM3h: number;
  straightLengthM: number;
  fittingsEquivalentLengthM: number;
  totalEquivalentLengthM: number;
  recommendedPipe: CopperPipeDimension | null;
  recommendedMeter: GasMeterModel | null;
  optimalResult: PipeCalculationResult | null;
  allPipeResults: PipeCalculationResult[];
  allMeterModels: GasMeterModel[];
}

export interface GasBranch {
  id: string;
  name: string;
  applianceIds: string[];
  pipeLengthM: number;
  fittings: GasFittings;
  recommendedPipe?: CopperPipeDimension | null;
  pressureDropMbar?: number;
  velocityMps?: number;
}

export interface SavedGasProject {
  id: string;
  title: string;
  clientName: string;
  buildingType: BuildingType;
  address?: string;
  date: string;
  appliances: GasAppliance[];
  parameters: GasParameters;
  branches?: GasBranch[];
  notes?: string;
}
