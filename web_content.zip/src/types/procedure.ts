export type ProcedureViewLayout = 'detailed' | 'grid2col' | 'compact';

export interface ProcedureStep {
  id: string;
  stepNumber: number;
  title: string;
  instruction: string;
  photoUrl?: string;
  photoCaption?: string;
  photoTag?: string;
  safetyNotice?: string;
}

export interface WorkProcedureReport {
  id: string;
  code: string; // es. "SOP-SFL-014"
  title: string; // es. "Specifica Operativa: Ciclo Sabbiatura e Verniciatura a Liquido C5M"
  revision: string; // es. "Rev. 01"
  date: string;
  author: string;
  department: 'Sabbiatura' | 'Verniciatura a Liquido' | 'Manutenzione Impianti' | 'Controllo Qualità & DFT' | 'Sicurezza & DPI';
  scope: string; // Campo di applicazione / Obiettivo
  equipmentAndPpe: string; // Attrezzature necessarie & DPI
  preferredLayout: ProcedureViewLayout;
  steps: ProcedureStep[];
  status: 'bozza' | 'approvata' | 'in_revisione';
  createdAt: string;
  updatedAt: string;
}
