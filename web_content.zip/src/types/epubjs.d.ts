declare module 'epubjs' {
  export interface NavItem {
    id: string;
    href: string;
    label: string;
    subitems?: NavItem[];
  }

  export interface BookMetadata {
    title: string;
    creator: string;
    description: string;
    pubdate: string;
    publisher: string;
    identifier: string;
    language: string;
    rights: string;
    modified_date: string;
  }

  export interface DisplayOptions {
    width?: string | number;
    height?: string | number;
    flow?: 'paginated' | 'scrolled' | 'scrolled-doc';
    spread?: 'none' | 'always' | 'auto';
    minSpreadWidth?: number;
    allowScriptedContent?: boolean;
  }

  export interface LocationData {
    start: {
      cfi: string;
      percentage: number;
      displayed: {
        page: number;
        total: number;
      };
      index: number;
      href: string;
    };
    end: {
      cfi: string;
      percentage: number;
      displayed: {
        page: number;
        total: number;
      };
      index: number;
      href: string;
    };
    atStart?: boolean;
    atEnd?: boolean;
  }

  export interface Rendition {
    display: (target?: string | number) => Promise<any>;
    next: () => Promise<any>;
    prev: () => Promise<any>;
    destroy: () => void;
    resize: (width?: number | string, height?: number | string) => void;
    currentLocation: () => LocationData;
    location: LocationData;
    getRange: (cfi: string) => Range;
    hooks: {
      content: {
        register: (callback: (contents: any) => void) => void;
      };
    };
    on: (event: string, callback: (...args: any[]) => void) => void;
    off: (event: string, callback: (...args: any[]) => void) => void;
    themes: {
      register: (name: string, styles: any) => void;
      select: (name: string) => void;
      fontSize: (size: string) => void;
      font: (font: string) => void;
      default: (styles: any) => void;
    };
    annotations: {
      add: (
        type: string,
        cfiRange: string,
        data?: any,
        cb?: (e: any) => void,
        className?: string,
        styles?: Record<string, string>
      ) => any;
      remove: (cfiRange: string, type?: string) => void;
      highlight: (
        cfiRange: string,
        data?: any,
        cb?: (e: any) => void,
        className?: string,
        styles?: Record<string, string>
      ) => any;
      underline: (cfiRange: string, data?: any, cb?: (e: any) => void) => any;
      mark: (cfiRange: string, data?: any, cb?: (e: any) => void) => any;
    };
  }

  export interface Book {
    ready: Promise<any>;
    renderTo: (element: HTMLElement | string, options?: DisplayOptions) => Rendition;
    loaded: {
      metadata: Promise<BookMetadata>;
      navigation: Promise<{ toc: NavItem[] }>;
      spine: Promise<{ spineItems: any[] }>;
    };
    locations: {
      generate: (charsPerPage?: number) => Promise<string[]>;
      cfiFromPercentage: (percentage: number) => string;
      percentageFromCfi: (cfi: string) => number;
      length: () => number;
      total: number;
    };
    destroy: () => void;
  }

  export default function ePub(
    urlOrData: string | ArrayBuffer | Uint8Array,
    options?: any
  ): Book;
}
