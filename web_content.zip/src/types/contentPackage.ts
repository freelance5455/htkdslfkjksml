import type { Platform } from "@/types";

export interface PlatformMetadata {
  platform: Platform;
  title: string;
  description: string;
  tags: string[];
  category: string;
  categoryId?: string;
  hashtags: string[];
  targetAudienceLabel: string;
  contentRating: "ALL_AGES" | "KIDS" | "TEEN" | "MATURE";
  visibility: "PUBLIC" | "UNLISTED" | "PRIVATE";
  callToAction: string;
  pinnedComment?: string;
  suggestedPlaylist?: string;
  optimalPostingTimes?: string[];
  aspectRatio: string;
  characterCounts: {
    titleLength: number;
    titleMax: number;
    descriptionLength: number;
    descriptionMax: number;
    tagsCount: number;
    tagsMax: number;
  };
}

export interface ContentPackage {
  id: string;
  projectId: string;
  projectTitle: string;
  version: number;
  createdAt: string;
  updatedAt: string;
  
  // Platform specific publishing kits
  primaryPlatform: Platform;
  packages: Record<Platform, PlatformMetadata>;

  // SEO & Distribution Assets
  masterSummary: string;
  keywords: string[];
  thumbnailHeadline: string;
  thumbnailSubheadline?: string;
  captionsSrtSnippet?: string;
  audioTrackName?: string;
  
  // Readiness Checklist
  readinessScore: number; // 0 - 100
  checklist: {
    hasTitle: boolean;
    hasDescription: boolean;
    hasTags: boolean;
    hasCategory: boolean;
    hasThumbnail: boolean;
    hasVideoAssets: boolean;
    isSafeForMonetization: boolean;
  };
}

export interface BuildPackageOptions {
  customTitle?: string;
  customDescription?: string;
  additionalTags?: string[];
  selectedCategory?: string;
  targetPlatforms?: Platform[];
  includeTimestamps?: boolean;
  includeBrandCallout?: boolean;
}
