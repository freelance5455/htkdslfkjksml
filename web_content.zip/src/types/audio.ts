export type AudioEngineId =
  | "gemini-tts"
  | "elevenlabs-prime"
  | "vibes-ai"
  | "musicful-ai"
  | "openai-tts-hd"
  | "cosyvoice-pro"
  | "lyria-music"
  | "suno-audio";

export type AudioVoiceId =
  | "kore"
  | "puck"
  | "fenrir"
  | "charon"
  | "zephyr"
  | "adam"
  | "rachel"
  | "josh"
  | "antoni"
  | "bella"
  | "alloy"
  | "echo"
  | "fable"
  | "onyx"
  | "nova"
  | "shimmer"
  | "vibes-serena"
  | "vibes-orion"
  | "musicful-harmony";

export type VoiceGender = "MALE" | "FEMALE" | "NEUTRAL";

export type VoiceTone =
  | "DOCUMENTARY_NARRATOR"
  | "ENERGETIC_YOUTUBER"
  | "DRAMATIC_CINEMATIC"
  | "CALM_MEDITATIVE"
  | "AUTHORITATIVE_NEWS"
  | "FRIENDLY_CONVERSATIONAL"
  | "STORYTELLER_FANTASY"
  | "CORPORATE_POLISHED";

export type AcousticEnvironment =
  | "DRY_STUDIO"
  | "PODCAST_ROOM"
  | "AUDITORIUM_REVERB"
  | "VINTAGE_RADIO"
  | "TELEPHONE"
  | "OUTDOOR_AMBIENT";

export type MusicGenre =
  | "CINEMATIC_ORCHESTRAL"
  | "LOFI_CHILL"
  | "SYNTHWAVE_CYBERPUNK"
  | "CORPORATE_TECH"
  | "DYNAMIC_TRAP"
  | "ACOUSTIC_EMOTIONAL"
  | "EPIC_TRAILER"
  | "AMBIENT_ELECTRONIC";

export type SoundEffectType =
  | "WHOOSH_TRANSITION"
  | "CINEMATIC_IMPACT"
  | "DIGITAL_GLITCH"
  | "SOFT_CHIME"
  | "RISER_BUILDUP"
  | "POP_NOTIFICATION";

export interface VoicePreset {
  id: AudioVoiceId;
  name: string;
  engine: AudioEngineId;
  gender: VoiceGender;
  language: string;
  accent: string;
  previewUrl?: string;
  description: string;
  recommendedFor: string;
}

export interface AudioEngineConfig {
  id: AudioEngineId;
  name: string;
  provider: string;
  badge: string;
  type: "TTS" | "MUSIC" | "SFX";
  description: string;
  highlight: string;
  color: string;
  supportsEmotionControl: boolean;
  supportsPitchControl: boolean;
  supportsMultiSpeaker: boolean;
  estimatedCostPerMinute: number;
  qualityTier: "Ultra" | "High" | "Fast";
}

export interface TTSGenerationOptions {
  text: string;
  engine: AudioEngineId;
  voiceId: AudioVoiceId;
  tone: VoiceTone;
  language: string;
  speechRate: number; // 0.5 to 2.0
  pitch?: number; // -10 to +10
  stability?: number; // 0 to 1
  acousticEnvironment?: AcousticEnvironment;
  sceneId?: string;
  sceneNumber?: number;
  sectionTitle?: string;
  projectId?: string;
  projectTitle?: string;
}

export interface MusicGenerationOptions {
  genre: MusicGenre;
  prompt?: string;
  duration: number; // in seconds
  tempo?: "SLOW" | "MEDIUM" | "UPBEAT" | "VERY_FAST";
  intensity?: "BACKGROUND" | "BALANCED" | "POWERFUL";
  projectId?: string;
  sceneId?: string;
}

export interface SoundEffectGenerationOptions {
  type: SoundEffectType;
  prompt?: string;
  duration?: number;
  sceneId?: string;
}

export interface AudioGenerationResult {
  id: string;
  type: "TTS" | "MUSIC" | "SFX";
  audioUrl: string;
  engine: AudioEngineId;
  engineName: string;
  title: string;
  text?: string;
  voiceId?: AudioVoiceId;
  voiceName?: string;
  tone?: VoiceTone;
  duration: number; // seconds
  sceneId?: string;
  sceneNumber?: number;
  projectId?: string;
  status: "COMPLETED" | "FAILED";
  createdAt: string;
  metadata?: {
    sampleRate: number;
    bitrate: string;
    format: "wav" | "mp3";
    charactersCount?: number;
    speechRate?: number;
  };
}
