export type AudioFormat = 'mp3' | 'ogg' | 'wav' | 'flac' | 'm4a' | 'aac' | 'unknown';

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  url: string;
  blob?: Blob;
  coverUrl: string;
  format: AudioFormat;
  sampleRate: number; // e.g. 44100, 48000, 96000
  bitDepth?: number; // e.g. 16, 24, 32
  fileSize?: number;
  folderPath: string; // e.g. "Musica/Synthwave/"
  dateAdded: number;
  isFavorite: boolean;
  isBuiltIn?: boolean;
}

export interface Playlist {
  id: string;
  name: string;
  trackIds: string[];
  createdAt: number;
  description?: string;
}

export type DynamicFxMode =
  | 'pump'          // Sidechain rhythmic ducking/pumping
  | 'autofilter'    // Beat-synchronized lowpass/bandpass sweep
  | 'gater'         // Rhythmic tempo stutter/chop
  | 'autopan'       // 3D stereo panner oscillating on beat
  | 'subpunch'      // Transient harmonic sub-bass exciter on downbeats
  | 'reverbbreath'; // Surround reverb opening up with rhythm dynamics

export type ReverbRoomSize = 'small' | 'studio' | 'hall' | 'cathedral';

export interface DSPSettings {
  eqBands: number[]; // 10 bands gains in dB (-12 to +12)
  preAmp: number; // dB (-12 to +12)
  
  // Bass Boost
  bassBoost: number; // 0 to 100%
  bassFreq: number; // 50 to 120 Hz
  bassDrive: number; // 0 to 100% (harmonic saturation)
  
  // Surround & Reverb
  surroundReverb: number; // 0 to 100% wet
  reverbRoom: ReverbRoomSize;
  stereoWidth: number; // 0 to 200%
  
  // Dynamic Rhythm FX (Real-time beat-synced DSP audio modifications)
  dynamicRhythmFx: boolean;
  dynamicFxMode: DynamicFxMode;
  dynamicFxIntensity: number; // 0 to 100%
  dynamicFxDivision: '1/1' | '1/2' | '1/4' | '1/8';
  dynamicFxSensitivity: number; // 0.1 to 1.0
  
  // Tone & Pitch (Grave a Agudo)
  pitchShift: number; // -12 to +12 semitones (grave a agudo)
  preservePitchWithSpeed: boolean; // toggle
  toneTilt: number; // -100 (Ultra Grave/Oscuro) to +100 (Ultra Agudo/Cristalino)

  // Visual dynamic reaction
  reactiveVisualFx: boolean;
  
  eqPreset: string;
}

export interface RhythmState {
  bpm: number;
  isBeat: boolean;
  beatStrength: number; // 0 to 1
  instantEnergy: number;
  averageEnergy: number;
  tempoConfidence: number;
}

export type SortField = 'title' | 'artist' | 'album' | 'duration' | 'dateAdded';
export type SortDirection = 'asc' | 'desc';

export type VisualizerMode = 'spectre' | 'waves' | 'bars' | 'aura';
