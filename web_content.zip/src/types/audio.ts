export interface AudioMetadata {
  name: string;
  size: number;
  formattedSize: string;
  duration: number;
  formattedDuration: string;
  format: 'MP3' | 'WAV' | 'M4A' | 'OGG' | 'FLAC' | 'AAC' | 'OTHER';
  mimeType: string;
  sampleRate: number;
  channels: number;
  waveformPeaks: number[];
  rmsDb?: number;
  peakDb?: number;
  lastModified?: number;
  file: File;
  audioUrl: string;
  dspVocalMeasurements?: TechnicalVocalMeasurements;
}

export interface DemoSample {
  id: string;
  title: string;
  subtitle: string;
  format: 'WAV' | 'MP3' | 'M4A';
  durationSec: number;
  bpm: number;
  genre: string;
  isVocalDemo?: boolean;
}

export interface TechnicalVocalMeasurements {
  f0RangeHz: string;
  f0AverageHz: number | null;
  pitchRangeSemitones: string;
  vocalStabilityJitter: string;
  vocalIntensityRmsDb: string;
  spectralCharacteristics: string;
  sampleRateNote: string;
  sampleRateDistinctionNote?: string;
}

export interface VoiceAnalysisReport {
  hasVoice: boolean;
  limitationNote?: string;

  // A. Resumo vocal
  sectionA_resumoVocal: {
    overview: string;
    keyHighlights: string[];
    vocalProfileSummary: string;
  };

  // B. Timbre e registro
  sectionB_timbreRegistro: {
    perceptualClassification: string;
    perceivedPresentation: string;
    timbreDescriptors: string[];
    timbreDescription: string;
    resonanceAndProjection: string;
    articulationAndClarity: string;
    speechVsSingingPitchNote: string;
  };

  // C. Textura e rouquidão
  sectionC_texturaRouquidao: {
    roughnessClassification: string;
    textureAndPerceivedIntensity: string;
    vocalCharacteristicsVsEffects: string;
  };

  // D. Emoção e interpretação
  sectionD_emocaoInterpretacao: {
    transmittedEmotions: string[];
    vocalDynamicsAndExpressiveness: string;
    pausesAndBreathing: string;
    vibratoAndArticulation: string;
    intensityChanges: string;
  };

  // E. Naturalidade e indícios de síntese artificial
  sectionE_naturalidadeIndiciosIA: {
    observableSignsClassification: 'Indícios Fracos' | 'Indícios Moderados' | 'Indícios Fortes' | 'Inconclusivos';
    classificationExplanation: string;
    timbreAndIntensityVariations: string;
    breathingAndArticulationNaturalness: string;
    noteTransitionsAndContinuity: string;
    vibratoUniformity: string;
    pronunciationAndArtifacts: string;
    autotuneAndStudioEffectsImpact: string;
    limitationsOfEvaluation: string;
  };

  // Análise Técnica Complementar (Item 5)
  sectionComplementar_dsp: {
    f0RangeHz: string;
    f0AverageHz: number | null;
    pitchRangeSemitones: string;
    vocalStabilityJitter: string;
    vocalIntensityRmsDb: string;
    sampleRateDistinctionNote: string;
    spectralCharacteristics: string;
  };

  // F. Características vocais recomendadas para recriação (Diretrizes para Suno)
  sectionF_caracteristicasRecriacao: {
    timbreType: string;
    textureAndRoughness: string;
    perceivedVocalRegister: string;
    interpretationAndEmotion: string;
    deliveryAndPhrasing: string;
    desirableEffectsAndProcessingLevel: string;
  };

  // G. Prompt vocal completo em inglês
  sectionG_promptCompletoIngles: string;

  // H. Prompt vocal curto em inglês
  sectionH_promptCurtoIngles: string;

  // Versões em português
  promptsPortugues: {
    promptCompleto: string;
    promptCurto: string;
  };
}
