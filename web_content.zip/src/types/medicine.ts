export type MedicineLanguage = 'English' | 'Hindi' | 'Marathi';

export type MedicineCategory =
  | 'Antibiotics'
  | 'Pain Relievers'
  | 'Fever Medicines'
  | 'Cold & Cough Medicines'
  | 'Blood Pressure Medicines'
  | 'Diabetes Medicines'
  | 'Vitamins & Supplements'
  | 'Anti-Allergy Medicines'
  | 'Digestive Medicines'
  | 'Antifungal Medicines'
  | 'Antibiotic Ointments'
  | 'Asthma Medicines';

export interface MedicineFaq {
  question: string;
  answer: string;
}

export interface MedicineDetailContent {
  name: string;
  genericName: string;
  brandNames: string[];
  categoryName: string;
  description: string;
  uses: string[];
  howItWorks: string;
  recommendedDosage: string;
  howToTake: string;
  foodRelation: string; // e.g., "After Food", "Before Food", "With or without food"
  missedDoseAdvice: string;
  overdoseInformation: string;
  commonSideEffects: string[];
  seriousSideEffects: string[];
  warningsPrecautions: string[];
  pregnancyInfo: string;
  breastfeedingInfo: string;
  drivingWarning: string;
  alcoholInteraction: string;
  drugInteractions: string[];
  storageInstructions: string;
  faqs: MedicineFaq[];
}

export interface MedicineItem {
  id: string;
  category: MedicineCategory;
  categoryIcon: string;
  bgGradient: string;
  badgeBg: string;
  badgeText: string;
  content: {
    English: MedicineDetailContent;
    Hindi: MedicineDetailContent;
    Marathi: MedicineDetailContent;
  };
}
