export type LedgerGroupType =
  | 'Current Assets'
  | 'Bank Accounts'
  | 'Cash-in-hand'
  | 'Sundry Debtors'
  | 'Current Liabilities'
  | 'Sundry Creditors'
  | 'Duties & Taxes'
  | 'Fixed Assets'
  | 'Capital Account'
  | 'Sales Accounts'
  | 'Purchase Accounts'
  | 'Direct Expenses'
  | 'Indirect Expenses'
  | 'Direct Incomes'
  | 'Indirect Incomes'
  | 'Loans (Liability)';

export interface Ledger {
  id: string;
  name: string;
  group: LedgerGroupType;
  openingBalance: number;
  openingBalanceType: 'Dr' | 'Cr';
  currentBalance: number; // calculated dynamically
  currentBalanceType: 'Dr' | 'Cr';
  gstin?: string;
  phone?: string;
  email?: string;
  address?: string;
  state?: string;
  isSystem?: boolean;
}

export interface StockItem {
  id: string;
  name: string;
  category: string;
  unit: string; // e.g. Nos, Pcs, Kgs, Box
  hsnCode: string;
  gstRate: number; // 0, 5, 12, 18, 28
  openingQty: number;
  openingRate: number;
  standardSellingRate: number;
  currentQty: number;
}

export type VoucherType =
  | 'sales'      // F8
  | 'purchase'   // F9
  | 'payment'    // F5
  | 'receipt'    // F6
  | 'contra'     // F4
  | 'journal'    // F7
  | 'debit_note' // Alt+F5
  | 'credit_note'; // Alt+F6

export interface VoucherItemRow {
  id: string;
  itemId: string;
  itemName: string;
  qty: number;
  rate: number;
  unit: string;
  amount: number;
  gstRate: number;
  hsnCode?: string;
}

export interface VoucherAccountRow {
  id: string;
  ledgerId: string;
  ledgerName: string;
  type: 'Dr' | 'Cr';
  amount: number;
}

export interface Voucher {
  id: string;
  voucherNumber: string;
  voucherType: VoucherType;
  date: string; // YYYY-MM-DD
  referenceNo?: string;
  
  // For Invoice-style Vouchers (Sales / Purchase)
  partyLedgerId?: string;
  partyLedgerName?: string;
  salesPurchaseLedgerId?: string;
  salesPurchaseLedgerName?: string;
  items?: VoucherItemRow[];
  isInterstate?: boolean; // IGST vs CGST+SGST
  
  // Taxes for Invoice
  taxableAmount: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  roundOff: number;
  totalAmount: number;

  // For Financial Vouchers (Payment, Receipt, Contra, Journal)
  rows?: VoucherAccountRow[];

  narration: string;
  createdAt: string;
}

export interface Company {
  id: string;
  name: string;
  legalTradeName?: string;
  gstin: string;
  panNumber: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
  email: string;
  currencySymbol: string;
  financialYearStart: string; // e.g. 2026-04-01
  financialYearEnd: string;   // e.g. 2027-03-31
  booksBeginningFrom: string;
}

export type ActiveScreen =
  | 'gateway'
  | 'daybook'
  | 'vouchers'
  | 'balancesheet'
  | 'profitloss'
  | 'trialbalance'
  | 'stocksummary'
  | 'ledgers'
  | 'ledger_statement'
  | 'gst_reports'
  | 'invoice_preview'
  | 'settings';
