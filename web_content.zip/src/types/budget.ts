export type Currency = 'RM';

export type TransactionType = 'expense' | 'income';

export type ExpenseCategory = 'food' | 'transport' | 'coffee' | 'groceries' | 'bills' | 'shopping' | 'other';

export interface Transaction {
  id: string;
  type: TransactionType;
  title: string;
  amount: number;
  category: ExpenseCategory;
  date: string; // ISO string
}

export interface Commitment {
  id: string;
  name: string; // e.g. SPayLater, Celcom Phone Bill, Time Internet
  amount: number;
  dueDate: string; // Flexible e.g. "15th of every month", "Every Friday", "Last day of month"
  isPaidThisCycle: boolean;
  notes?: string;
}

export interface Debt {
  id: string;
  person: string; // e.g. Amir, Zack
  amount: number;
  type: 'i_owe' | 'they_owe';
  reason: string; // e.g. Hotpot dinner split
  isSettled: boolean;
  dueDate?: string;
}

export interface SavingsGoal {
  id: string;
  title: string; // e.g. Laptop Fund
  targetAmount: number; // e.g. 2500
  currentAmount: number; // e.g. 300
}

export type LoanCategory =
  | 'PayLater'
  | 'Device Installment'
  | 'Education'
  | 'Vehicle'
  | 'Personal Loan'
  | 'Family Debt'
  | 'Friend Debt'
  | 'Subscription Contract'
  | 'Others';

export type InstallmentType = '0% Interest' | 'Interest Applied' | 'Custom';

export interface Loan {
  id: string;
  name: string; // e.g. SPayLater, Shopee PayLater, Laptop Loan, Phone Installment
  totalAmount: number; // e.g. 1200
  durationMonths: number; // e.g. 12
  monthlyPayment: number; // Base or adjusted monthly payment
  category: LoanCategory;
  startDate: string; // ISO string
  paidMonths: number; // e.g. 0
  dueDate: string; // Flexible text e.g. "15th of every month", "Every Friday"
  isPaidThisCycle: boolean;
  installmentType: InstallmentType;
  additionalMonthlyCharge?: number;
  interestPercentage?: number;
  customNotes?: string;
}

export type IncomeFrequency = 'daily' | 'weekly' | 'monthly';

export interface PoketSafeData {
  currentMoney: number; // Cash / bank right now (RM)
  incomeFrequency: IncomeFrequency; // Daily, Weekly, Monthly
  incomeAmount: number; // Amount per frequency
  currency: 'RM'; // Fixed to RM
  transactions: Transaction[];
  commitments: Commitment[];
  debts: Debt[];
  savings: SavingsGoal[];
  loans: Loan[]; // Active loans & installment plans
}
