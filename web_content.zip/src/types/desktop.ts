export type WindowState = 'normal' | 'minimized' | 'maximized';

export interface WindowPosition {
  x: number;
  y: number;
}

export interface WindowSize {
  width: number;
  height: number;
}

export interface AppWindow {
  id: string;
  appId: string;
  title: string;
  icon: string;
  state: WindowState;
  position: WindowPosition;
  size: WindowSize;
  zIndex: number;
  minWidth?: number;
  minHeight?: number;
}

export interface DesktopAppDefinition {
  id: string;
  name: string;
  icon: string; // Lucide icon name or image url
  category: 'System' | 'Development' | 'Productivity' | 'Utilities' | 'Media' | 'AI';
  description: string;
  defaultWidth?: number;
  defaultHeight?: number;
  pinnedToTaskbar?: boolean;
  pinnedToStart?: boolean;
}

export interface CustomAppIconData {
  dataUrl: string; // Base64 data URL
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  densityDrawables: {
    mdpi: string;    // 48x48
    hdpi: string;    // 72x72
    xhdpi: string;   // 96x96
    xxhdpi: string;  // 144x144
    xxxhdpi: string; // 192x192
  };
  adaptiveRoundDataUrl: string;
}

export interface FileItem {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'folder';
  sizeBytes?: number;
  updatedAt: string;
  content?: string;
  extension?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type?: 'info' | 'success' | 'warning' | 'error';
}

export interface BuildDiagnosticInfo {
  hasJava: boolean;
  javaVersion: string | null;
  hasGradle: boolean;
  gradleVersion: string | null;
  hasAndroidSdk: boolean;
  androidHome: string | null;
  platform: string;
  cloudBuildAvailable: boolean;
  message: string;
}
