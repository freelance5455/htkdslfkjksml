export type MedicineType =
  | 'Tablet'
  | 'Capsule'
  | 'Syrup'
  | 'Injection'
  | 'Drops'
  | 'Cream'
  | 'Inhaler'
  | 'Others';

export type FrequencyType =
  | 'Once Daily'
  | 'Twice Daily'
  | 'Three Times Daily'
  | 'Four Times Daily'
  | 'Custom Schedule';

export type DoseStatus = 'pending' | 'taken' | 'snoozed' | 'skipped' | 'missed';

export type FeelingEffect = 'better' | 'no_change' | 'worse';

export type ReminderLanguage = 'English' | 'Hindi' | 'Marathi';

export interface MedicineItem {
  id: string;
  name: string;
  type: MedicineType;
  strength: string; // e.g. "500mg", "10ml"
  reason?: string; // e.g. "High Blood Pressure"
  doctorName?: string; // e.g. "Dr. R. K. Sharma"
  frequency: FrequencyType;
  times: string[]; // e.g. ["08:00", "20:00"]
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  totalQuantity: number; // e.g. 30
  dosePerTime: number; // e.g. 1
  remainingQuantity: number; // e.g. 24
  isActive: boolean;
  createdAt: string;
}

export interface DoseRecord {
  id: string;
  medicineId: string;
  medicineName: string;
  medicineType: MedicineType;
  strength: string;
  dosePerTime: number;
  scheduledTime: string; // e.g. "08:00 AM"
  time24h: string; // e.g. "08:00"
  scheduledDate: string; // YYYY-MM-DD
  status: DoseStatus;
  feelingEffect?: FeelingEffect;
  actionTime?: string; // ISO string when taken/snoozed/skipped
  snoozedUntil?: string; // HH:MM or ISO
  reason?: string;
  doctorName?: string;
}
