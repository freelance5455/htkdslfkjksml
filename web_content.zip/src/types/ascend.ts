export type ModuleId =
  | 'home'
  | 'character'
  | 'skills'
  | 'goals'
  | 'habits'
  | 'planner'
  | 'tasks'
  | 'projects'
  | 'missions'
  | 'focus'
  | 'journal'
  | 'second-brain'
  | 'analytics'
  | 'xp-settings'
  | 'settings';

export interface NavItemConfig {
  id: ModuleId;
  label: string;
  icon: string;
  group: 'Overview' | 'Execution' | 'Progression' | 'Mind & Review' | 'System';
  visible: boolean;
  pinned: boolean;
  order: number;
}

export interface CustomTheme {
  id: string;
  name: string;
  mode: 'light' | 'dark';
  bgCanvas: string;
  bgSurface: string;
  bgElevated: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  borderSubtle: string;
  accentPrimary: string;
}

export interface TypographyConfig {
  headingFont: string;
  subheadingFont: string;
  bodyFont: string;
  taskFont: string;
  notesFont: string;
  characterFont: string;
  journalFont: string;
  handwritingFont: string;
  headingWeight: '500' | '600' | '700' | '800';
  bodyScale: number;
  useHandwritingInJournal: boolean;
  useHandwritingInNotes: boolean;
}

export type WidgetId =
  | 'character-card'
  | 'habit-tracker'
  | 'task-list'
  | 'goal-progress'
  | 'daily-missions'
  | 'focus-timer'
  | 'xp-overview'
  | 'weekly-stats'
  | 'recent-achievements'
  | 'journal-shortcut';

export interface DashboardWidgetConfig {
  id: WidgetId;
  title: string;
  visible: boolean;
  size: 'compact' | 'wide' | 'full';
  order: number;
}

export interface CharacterAttribute {
  id: string;
  code: string; // e.g., INT, DIS, FOC
  name: string;
  description: string;
  icon: string;
  color: string;
  baseScore: number; // starting/manual baseline
  xpEarned: number; // transparent XP accumulated via linked habits, tasks, goals, skills, focus
  xpPerPoint: number; // transparent rule: e.g., 100 XP = +1 attribute level
  visible: boolean;
  isCustom?: boolean;
  order: number;
}

export interface LifeDomain {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  targetHoursPerWeek: number;
  loggedHours: number;
  order: number;
  isCustom?: boolean;
}

export interface CharacterTitle {
  id: string;
  name: string;
  description: string;
  requiredLevel: number;
  unlocked: boolean;
  isCustom?: boolean;
}

export interface CharacterProfile {
  name: string;
  tagline: string;
  archetype: string;
  customArchetypeDescription: string;
  avatarIcon: string;
  bannerStyle: string;
  activeTitleId: string;
  joinedDate: string;
}

export interface GoalMilestone {
  id: string;
  title: string;
  completed: boolean;
  xpReward: number;
}

export interface GoalItem {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: string;
  color: string;
  startDate: string;
  targetDate: string;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Active' | 'Completed' | 'Paused' | 'Archived';
  manualProgress?: number;
  milestones: GoalMilestone[];
  notes: string;
  attributeIds: string[];
  domainId?: string;
  xpReward: number;
  completedAt?: string;
}

export type HabitType = 'yes_no' | 'numeric' | 'count' | 'duration' | 'checklist';

export interface HabitChecklistItem {
  id: string;
  text: string;
}

export interface HabitItem {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  category: string;
  type: HabitType;
  targetValue: number; // 1 for yes_no, e.g., 4 for hours, 30 for questions, 20 for pages
  unit: string; // 'hours', 'questions', 'pages', 'mins', 'sessions'
  checklistItems?: HabitChecklistItem[];
  scheduleType: 'daily' | 'weekdays' | 'custom_days';
  scheduledDays: number[]; // 0=Sun .. 6=Sat
  reminderTime?: string;
  startDate: string;
  targetDate?: string;
  xpReward: number;
  attributeIds: string[];
  domainId?: string;
  linkedGoalId?: string;
  status: 'Active' | 'Paused' | 'Archived';
  order: number;
  // History keyed by YYYY-MM-DD -> numeric progress value (where >= targetValue means completed)
  history: Record<string, number>;
}

export interface SubtaskItem {
  id: string;
  title: string;
  completed: boolean;
}

export interface TaskItem {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  scheduledTime?: string; // e.g., "09:00"
  durationMinutes?: number;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  category: string;
  status: 'To-do' | 'In progress' | 'Completed' | 'Cancelled' | 'Archived';
  subtasks: SubtaskItem[];
  notes: string;
  recurrence: 'None' | 'Daily' | 'Weekly' | 'Weekdays';
  linkedGoalId?: string;
  linkedProjectId?: string;
  attributeIds: string[];
  xpReward: number;
  completedAt?: string;
}

export interface ProjectMilestone {
  id: string;
  title: string;
  completed: boolean;
}

export interface ProjectItem {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  color: string;
  startDate: string;
  deadline: string;
  status: 'Planning' | 'Active' | 'On Hold' | 'Completed' | 'Archived';
  priority: 'Low' | 'Medium' | 'High';
  milestones: ProjectMilestone[];
  notes: string;
  linkedGoalId?: string;
  xpReward: number;
}

export interface RoutineActivity {
  id: string;
  title: string;
  timeSlot: string;
  durationMinutes: number;
  linkedHabitId?: string;
  completedDates: string[]; // YYYY-MM-DD
}

export interface RoutineItem {
  id: string;
  name: string;
  period: 'Morning' | 'Afternoon' | 'Evening' | 'Night' | 'Study' | 'Custom';
  icon: string;
  repeatingDays: number[];
  activities: RoutineActivity[];
}

export interface PlannerBlock {
  id: string;
  date: string; // YYYY-MM-DD
  startTime: string; // "08:00"
  endTime: string; // "09:30"
  title: string;
  category: 'Deep Work' | 'Study' | 'Habit' | 'Task' | 'Routine' | 'Health' | 'Break';
  linkedTaskId?: string;
  linkedHabitId?: string;
  completed: boolean;
  notes?: string;
}

export interface SkillNode {
  id: string;
  branch: string; // Intellect, Discipline, Physical, Creativity, Social, Wisdom, or custom
  name: string;
  description: string;
  icon: string;
  tier: 1 | 2 | 3;
  parentSkillId?: string;
  currentLevel: number;
  maxLevel: number;
  xpInvested: number;
  xpPerLevel: number;
  unlockRequirementText: string;
  unlocked: boolean;
  attributeIds: string[];
  xpRewardOnLevelUp: number;
}

export interface EducationChapter {
  id: string;
  title: string;
  completed: boolean;
  practiceQuestionsSolved: number;
  revisionCount: number;
}

export interface EducationSubject {
  id: string;
  name: string;
  category: string;
  icon: string;
  color: string;
  targetHours: number;
  loggedHours: number;
  attributeIds: string[];
  linkedSkillId?: string;
  xpPerHour: number;
  chapters: EducationChapter[];
}

export interface MissionItem {
  id: string;
  name: string;
  description: string;
  type: 'Daily' | 'Weekly' | 'Monthly' | 'Goal' | 'Learning' | 'Habit' | 'Custom';
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Mythic';
  deadline: string;
  targetCount: number;
  currentCount: number;
  unit: string;
  xpReward: number;
  linkedHabitId?: string;
  linkedGoalId?: string;
  linkedTaskId?: string;
  attributeIds: string[];
  status: 'Active' | 'Completed' | 'Paused' | 'Archived';
}

export interface RewardItem {
  id: string;
  name: string;
  description: string;
  category: 'Leisure' | 'Book & Learning' | 'Celebration' | 'Hobby' | 'Custom';
  icon: string;
  unlockRequirementText: string;
  requiredXp?: number;
  linkedGoalId?: string;
  linkedMissionId?: string;
  unlocked: boolean;
  redeemed: boolean;
  unlockedDate?: string;
}

export interface AchievementItem {
  id: string;
  name: string;
  description: string;
  category: 'Habit' | 'Goal' | 'Learning' | 'Focus' | 'Skill' | 'Consistency' | 'Character' | 'Custom';
  icon: string;
  unlockConditionText: string;
  unlocked: boolean;
  unlockedDate?: string;
  xpReward: number;
  isCustom?: boolean;
}

export interface JournalEntry {
  id: string;
  date: string;
  title: string;
  type: 'Daily' | 'Weekly' | 'Monthly' | 'Gratitude' | 'Reflection' | 'Free Writing';
  mood: 'Focused' | 'Energized' | 'Calm' | 'Reflective' | 'Determined' | 'Neutral';
  content: string;
  gratitudeList: string[];
  lessonsLearned: string;
  tags: string[];
  pinned: boolean;
  useHandwriting: boolean;
}

export interface SecondBrainNote {
  id: string;
  title: string;
  category: 'Note' | 'Idea' | 'Resource' | 'Book Note' | 'Learning Note';
  folder: string;
  content: string;
  tags: string[];
  pinned: boolean;
  updatedAt: string;
  linkedGoalId?: string;
  linkedProjectId?: string;
  linkedSkillId?: string;
  linkedSubjectId?: string;
  useHandwriting?: boolean;
}

export interface VisionBoardItem {
  id: string;
  title: string;
  pillar: string;
  statement: string;
  targetTimeframe: string;
  icon: string;
  accentColor: string;
  linkedGoalId?: string;
  achieved: boolean;
}

export interface FocusSessionRecord {
  id: string;
  date: string;
  timestamp: string;
  label: string;
  mode: 'Pomodoro' | 'Stopwatch' | 'Custom';
  durationMinutes: number;
  linkedGoalId?: string;
  linkedTaskId?: string;
  linkedSubjectId?: string;
  xpEarned: number;
}

export interface FocusConfig {
  pomodoroMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  sessionsBeforeLongBreak: number;
  customTimerMinutes: number;
  soundEnabled: boolean;
  xpPer25MinSession: number;
}

export interface XPSettingsConfig {
  xpEnabled: boolean;
  autoXpEnabled: boolean;
  startingLevel: number;
  startingXp: number;
  xpPerLevelBase: number;
  levelFormula: 'linear' | 'progressive'; // linear: level * xpPerLevelBase; progressive: base * level * 1.15
  maxLevel: number;
  defaultHabitXp: number;
  defaultTaskXp: number;
  defaultGoalXp: number;
  defaultMilestoneXp: number;
  defaultMissionXp: number;
  defaultFocusXp: number;
  defaultSkillXp: number;
  defaultLearningHourXp: number;
  streakBonusEnabled: boolean;
  streakBonusXpPerDay: number;
  levelUpNotifications: boolean;
}

export interface XPTransaction {
  id: string;
  activityId: string;
  activityType:
    | 'habit'
    | 'task'
    | 'goal'
    | 'milestone'
    | 'mission'
    | 'focus'
    | 'skill'
    | 'education'
    | 'achievement'
    | 'manual';
  xpAmount: number; // positive when earned, or reversed when undone
  date: string; // YYYY-MM-DD
  timestamp: string; // HH:mm:ss
  reason: string;
  relatedRecordTitle: string;
  attributeIds: string[];
}

export interface WeeklyReviewRecord {
  id: string;
  weekStartDate: string;
  wins: string;
  challenges: string;
  keyLesson: string;
  nextWeekFocus: string;
  disciplineRating: number; // 1-10
  completedAt: string;
}

export interface AscendState {
  activeModule: ModuleId;
  activeThemeId: string;
  themes: CustomTheme[];
  typography: TypographyConfig;
  navigation: NavItemConfig[];
  dashboardWidgets: DashboardWidgetConfig[];
  character: CharacterProfile;
  attributes: CharacterAttribute[];
  domains: LifeDomain[];
  titles: CharacterTitle[];
  goals: GoalItem[];
  goalCategories: string[];
  habits: HabitItem[];
  tasks: TaskItem[];
  projects: ProjectItem[];
  routines: RoutineItem[];
  plannerBlocks: PlannerBlock[];
  skills: SkillNode[];
  skillBranches: string[];
  subjects: EducationSubject[];
  missions: MissionItem[];
  rewards: RewardItem[];
  achievements: AchievementItem[];
  journalEntries: JournalEntry[];
  weeklyReviews: WeeklyReviewRecord[];
  notes: SecondBrainNote[];
  visionBoard: VisionBoardItem[];
  focusConfig: FocusConfig;
  focusSessions: FocusSessionRecord[];
  xpSettings: XPSettingsConfig;
  xpTransactions: XPTransaction[];
}
