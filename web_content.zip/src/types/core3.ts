// ============================================================
// AI CREATOR STUDIO — CORE 3.0 TYPE DEFINITIONS
// AI AUTOPILOT + CONTENT INTELLIGENCE
// ============================================================

import type { Platform, ContentType, Tone, Project } from "./index";
import type { VideoAnalytics, AggregatedAnalytics } from "./core2";

// --- AUTOPILOT MODES & STATUS ---
export type AutopilotMode = "MANUAL" | "ASSISTED" | "AUTOPILOT";

export interface AutopilotConfig {
  mode: AutopilotMode;
  emergencyStop: boolean;
  autoApproveGeneration: boolean; // Script & storyboard
  autoApproveEditing: boolean;    // Timeline & cuts
  autoApproveRender: boolean;     // Image/Audio/Video rendering
  autoApprovePublishing: boolean; // CRITICAL: strictly requires explicit owner approval
  maxConcurrentWorkflows: number;
  dailyBudgetLimitUsd: number;
  weeklyBudgetLimitUsd: number;
  monthlyBudgetLimitUsd: number;
  lastActiveAt: string;
}

// --- CREATOR GOALS ---
export type GoalType =
  | "GROW_AUDIENCE"
  | "INCREASE_VIEWS"
  | "IMPROVE_RETENTION"
  | "INCREASE_ENGAGEMENT"
  | "BUILD_BRAND"
  | "IMPROVE_CONSISTENCY";

export interface CreatorGoal {
  id: string;
  type: GoalType;
  title: string;
  description: string;
  targetMetric: string;
  currentValue: number;
  targetValue: number;
  unit: string;
  deadline?: string;
  progressPercent: number;
  active: boolean;
  priority: "HIGH" | "MEDIUM" | "LOW";
  initiatives: string[];
  createdAt: string;
  updatedAt: string;
}

// --- CONTENT STRATEGY & PILLARS ---
export interface ContentPillar {
  id: string;
  name: string;
  description: string;
  targetAudience: string;
  recommendedTone: Tone;
  targetSharePercent: number; // e.g. 40% of channel content
  recommendedFormats: string[];
  sampleTopics: string[];
  color: string;
}

export interface PlatformStrategy {
  platform: Platform;
  targetFrequencyPerWeek: number;
  bestPostingTimes: string[];
  primaryFormat: string;
  objective: string;
  hooksAdvice: string;
}

export interface ContentStrategy {
  id: string;
  title: string;
  niche: string;
  targetAudienceSummary: string;
  primaryGoal: GoalType;
  pillars: ContentPillar[];
  platformStrategies: PlatformStrategy[];
  weeklyCadence: {
    longformVideos: number;
    shortsReels: number;
    communityPosts: number;
  };
  keyDifferentiators: string[];
  updatedAt: string;
}

// --- SMART IDEAS & CALENDAR ---
export interface StrategicIdea {
  id: string;
  title: string;
  concept: string;
  pillarId?: string;
  pillarName?: string;
  audience: string;
  format: string;
  platform: Platform;
  contentType: ContentType;
  priority: "HIGH" | "MEDIUM" | "LOW";
  reason: string; // Strategic justification based on past performance or trend
  estimatedProductionTimeMin: number;
  status: "BACKLOG" | "PLANNED" | "IN_PRODUCTION" | "COMPLETED" | "DISCARDED";
  targetPublishDate?: string;
  score: number; // 0-100 potential impact
  createdAt: string;
}

export interface CalendarSlot {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  platform: Platform;
  format: string;
  pillarName: string;
  suggestedIdea?: StrategicIdea;
  projectId?: string;
  projectTitle?: string;
  status: "OPEN" | "ASSIGNED" | "PRODUCED" | "SCHEDULED" | "PUBLISHED";
}

// --- CONTENT SERIES & CONTINUITY ---
export interface SeriesCharacter {
  id: string;
  name: string;
  role: string;
  visualPromptAnchor: string;
  voiceId?: string;
  voiceName?: string;
  avatarUrl?: string;
  personalityTraits: string[];
}

export interface ContentSeries {
  id: string;
  title: string;
  description: string;
  targetAudience: string;
  visualStyleGuide: string;
  voiceToneGuide: string;
  musicThemeGuide: string;
  brandingRules: string[];
  characters: SeriesCharacter[];
  episodeCount: number;
  publishedEpisodesCount: number;
  episodes: Array<{
    episodeNumber: number;
    title: string;
    synopsis: string;
    projectId?: string;
    status: "PLANNED" | "IN_PROGRESS" | "READY" | "PUBLISHED";
    publishedAt?: string;
  }>;
  createdAt: string;
  updatedAt: string;
}

export interface ContinuityReport {
  isConsistent: boolean;
  score: number; // 0-100
  checks: {
    characterDesign: { passed: boolean; details: string };
    visualStyle: { passed: boolean; details: string };
    voiceTone: { passed: boolean; details: string };
    musicIdentity: { passed: boolean; details: string };
    brandingConsistency: { passed: boolean; details: string };
  };
  recommendations: string[];
}

// --- CREATIVE DIRECTOR & QUALITY SCORER ---
export interface QualityDimension {
  name: string;
  score: number; // 0-10
  weight: number;
  status: "EXCELLENT" | "GOOD" | "NEEDS_IMPROVEMENT" | "CRITICAL";
  feedback: string;
  recommendation: string;
}

export interface ContentQualityScore {
  overallScore: number; // 0-100
  level: "EXCELLENT" | "SOLID" | "NEEDS_POLISH" | "UNFINISHED";
  dimensions: {
    hook: QualityDimension;
    story: QualityDimension;
    audio: QualityDimension;
    visual: QualityDimension;
    pacing: QualityDimension;
    thumbnail: QualityDimension;
    title: QualityDimension;
    seo: QualityDimension;
    brand: QualityDimension;
  };
  criticalFixes: string[];
  polishSuggestions: string[];
  disclaimer: string; // Explains this is an AI craft evaluation, not a guarantee of external algorithm results
}

export interface HookVariant {
  id: string;
  formula: "CURIOSITY_LOOP" | "HIGH_STAKES_QUESTION" | "VISUAL_PATTERN_INTERRUPT" | "BOLD_STATEMENT" | "STORY_MICRO_DRAMA";
  formulaLabel: string;
  hookText: string;
  visualDirection: string;
  estimatedRetentionScore: number; // 0-100
  targetAudienceAppeal: string;
}

// --- PERFORMANCE LEARNING & PATTERNS ---
export interface LearnedInsight {
  id: string;
  category: "DURATION" | "TOPIC" | "HOOK" | "POSTING_TIME" | "FORMAT" | "RETENTION";
  title: string;
  finding: string;
  confidencePercent: number;
  supportingData: string;
  causalityVsCorrelationNote: string;
  suggestedAction: string;
  isActionable: boolean;
  discoveredAt: string;
}

export interface PerformancePattern {
  bestPerformingDurationSec: number;
  topPerformingTopics: string[];
  highestRetentionHookPattern: string;
  averageAudienceRetention: number;
  averageCtr: number;
  bestDayOfWeek: string;
  bestTimeSlot: string;
}

// --- EXPANDED CREATOR MEMORY ---
export type MemoryCategory =
  | "CREATOR"
  | "BRAND"
  | "PROJECT"
  | "CONTENT"
  | "PERFORMANCE"
  | "PREFERENCE";

export interface MemoryEntry {
  id: string;
  category: MemoryCategory;
  key: string;
  title: string;
  value: string;
  tags: string[];
  confidence: number;
  source: "USER_INPUT" | "PERFORMANCE_ANALYSIS" | "AI_LEARNED";
  createdAt: string;
  updatedAt: string;
}

// --- AUTOMATION WORKFLOWS ---
export type WorkflowStepType =
  | "IDEA_TO_SCRIPT"
  | "SCRIPT_TO_STORYBOARD"
  | "STORYBOARD_TO_MEDIA"
  | "MEDIA_TO_EDIT"
  | "EDIT_TO_RENDER"
  | "RENDER_TO_PUBLISH";

export type WorkflowStatusType = "PENDING" | "RUNNING" | "WAITING_APPROVAL" | "COMPLETED" | "STOPPED" | "FAILED";

export interface WorkflowJob {
  id: string;
  title: string;
  projectId?: string;
  ideaId?: string;
  steps: Array<{
    step: WorkflowStepType;
    label: string;
    status: WorkflowStatusType;
    requiresApproval: boolean;
    approved: boolean;
    outputSummary?: string;
    startedAt?: string;
    completedAt?: string;
    error?: string;
  }>;
  currentStepIndex: number;
  status: WorkflowStatusType;
  initiatedBy: "USER" | "AUTOPILOT";
  createdAt: string;
  updatedAt: string;
}

// --- BUDGET & COST CONTROL ---
export interface BudgetSpendLog {
  id: string;
  timestamp: string;
  provider: "GEMINI" | "IMAGEN" | "ELEVENLABS" | "VIDEO_RENDER" | "SYSTEM";
  model: string;
  action: string;
  estimatedCostUsd: number;
  actualCostUsd: number;
  tokensOrUnits: number;
  projectId?: string;
}

export interface BudgetStatus {
  dailyUsedUsd: number;
  dailyLimitUsd: number;
  weeklyUsedUsd: number;
  weeklyLimitUsd: number;
  monthlyUsedUsd: number;
  monthlyLimitUsd: number;
  isLimitReached: boolean;
  spendHistory: BudgetSpendLog[];
}

// --- NOTIFICATIONS & ALERTS ---
export type NotificationType =
  | "GENERATION_COMPLETED"
  | "RENDER_COMPLETED"
  | "PUBLISH_READY"
  | "PUBLISH_FAILED"
  | "QUALITY_WARNING"
  | "BUDGET_WARNING"
  | "PERFORMANCE_ALERT"
  | "AUTOPILOT_ACTION";

export interface SystemNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  severity: "INFO" | "SUCCESS" | "WARNING" | "CRITICAL";
  read: boolean;
  linkUrl?: string;
  actionLabel?: string;
  createdAt: string;
}

// --- RECOMMENDATION ENGINE ---
export interface ActionRecommendation {
  id: string;
  title: string;
  description: string;
  impact: "HIGH" | "MEDIUM" | "LOW";
  confidencePercent: number;
  effort: "LOW" | "MEDIUM" | "HIGH";
  category: "GROWTH" | "CONTENT" | "SEO" | "CONSISTENCY" | "OPTIMIZATION";
  actionType: "CREATE_PROJECT" | "OPTIMIZE_THUMBNAIL" | "SCHEDULE_SERIES" | "REPURPOSE_SHORTS" | "APPLY_STRATEGY";
  payload?: Record<string, unknown>;
  createdAt: string;
}

// --- DAILY BRIEF & WEEKLY REPORT ---
export interface DailyBriefData {
  date: string;
  greeting: string;
  priorities: Array<{ id: string; text: string; done: boolean; type: string }>;
  pendingProjects: Project[];
  scheduledToday: Array<{ id: string; title: string; time: string; platform: Platform }>;
  recentAlerts: string[];
  topIdeaForToday?: StrategicIdea;
  aiAdvice: string;
}

export interface WeeklyReportData {
  weekLabel: string;
  totalProducedCount: number;
  totalPublishedCount: number;
  totalViewsGenerated: number;
  averageRetentionPercent: number;
  averageCtrPercent: number;
  bestPerformingPost?: { title: string; platform: Platform; views: number; ctr: number };
  worstPerformingPost?: { title: string; platform: Platform; views: number; dropoffReason: string };
  growthSummary: string;
  keyLearnings: string[];
  nextWeekRecommendations: string[];
}

// --- NLP COMMAND CENTER ---
export interface NLPCommandResult {
  understoodIntent: string;
  mode: AutopilotMode;
  actionTaken: "STRATEGY_GENERATED" | "IDEAS_CREATED" | "PROJECT_PRODUCED" | "CALENDAR_PLANNED" | "PERFORMANCE_ANALYZED" | "SHORTS_REPURPOSED" | "SAFETY_STOPPED" | "ANSWER_ONLY";
  summary: string;
  details?: Record<string, unknown>;
  suggestedFollowUps: string[];
  requiresConfirmation?: boolean;
  confirmationPrompt?: string;
}
