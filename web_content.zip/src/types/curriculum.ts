export type LearningCategory = 'urdu' | 'english' | 'math';

export interface UrduLetterItem {
  id: string;
  letter: string;
  nameUrdu: string;
  nameLatin: string;
  wordUrdu: string;
  wordTranslit: string;
  wordEnglish: string;
  emoji: string;
  soundDescription: string;
  rhymeUrdu: string;
  color: string;
}

export interface EnglishLetterItem {
  id: string;
  upper: string;
  lower: string;
  phonic: string;
  word: string;
  wordUrdu: string;
  emoji: string;
  sentence: string;
  color: string;
}

export interface NumberItem {
  id: string;
  number: number;
  urduDigit: string;
  wordEnglish: string;
  wordUrdu: string;
  wordUrduTranslit: string;
  emoji: string;
  color: string;
  funFact: string;
}

export interface QuizQuestion {
  id: string;
  category: LearningCategory;
  questionUrdu: string;
  questionEnglish: string;
  targetItem: string;
  options: {
    label: string;
    sublabel?: string;
    emoji?: string;
    isCorrect: boolean;
  }[];
  explanationUrdu: string;
}
