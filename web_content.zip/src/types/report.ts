export type OperationalStatus = 'completato' | 'in_corso' | 'in_revisione' | 'critico';
export type Priority = 'bassa' | 'media' | 'alta' | 'urgente';
export type Shift = 'mattina' | 'pomeriggio' | 'notte' | 'giornaliero';

export type ImageTag = 'Prima Intervento' | 'Durante' | 'Dopo Intervento' | 'Anomalia / Danno' | 'Conferma / Verbale' | 'DDT / Scheda Tecnica' | 'Altro';

export interface ReportImage {
  id: string;
  url: string;
  caption: string;
  tag: ImageTag;
  uploadedAt: string;
  fileName?: string;
  sizeBytes?: number;
}

export interface MetricFieldDef {
  key: string;
  label: string;
  type: 'number' | 'text' | 'select';
  unit?: string;
  options?: string[];
  defaultValue?: string | number;
}

export interface Sector {
  id: string;
  name: string;
  shortCode: string;
  description: string;
  iconName: string;
  badgeColor: string; // for UI color theme (e.g. indigo, emerald, amber, rose, cyan, etc.)
  metricFields: MetricFieldDef[];
  isCustom?: boolean;
}

export interface OperationalReport {
  id: string;
  protocolNumber: string; // e.g. "REP-2026-081"
  title: string;
  sectorId: string;
  timestamp: string; // ISO string
  shift: Shift;
  operatorName: string;
  operatorRole: string;
  status: OperationalStatus;
  priority: Priority;
  location: string;
  description: string;
  correctiveActions?: string;
  metrics: Record<string, string | number>;
  images: ReportImage[];
  tags: string[];
  supervisorSignoff?: {
    signed: boolean;
    supervisorName?: string;
    signedAt?: string;
    notes?: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface ReportFilterOptions {
  searchQuery: string;
  sectorId: string; // 'all' or specific sector
  status: string; // 'all' or specific status
  priority: string; // 'all' or specific priority
  shift: string; // 'all' or specific shift
  dateFrom: string;
  dateTo: string;
  onlyWithImages: boolean;
  sortBy: 'date-desc' | 'date-asc' | 'priority' | 'status' | 'title';
}
