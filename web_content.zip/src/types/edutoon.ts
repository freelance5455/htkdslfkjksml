export type LanguageCode = 'en' | 'hi';

export type AuthProviderType = 'google' | 'phone';

export type ClassLevel = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;

export interface StudentProfile {
  uid: string;
  displayName: string;
  selectedClass: number; // 0 if unselected, 1-10 once selected
  classLocked: boolean;
  academicSession: string;
  language: LanguageCode | '';
  authProvider: AuthProviderType;
  photoURL: string;
  completedNoteIds: string[];
  completedVideoIds: string[];
  createdAt: unknown;
  updatedAt: unknown;
}

export interface StudentPrivateContact {
  uid: string;
  email: string;
  phoneNumber: string;
  updatedAt: unknown;
}

export interface Subject {
  id: string;
  classLevel: ClassLevel;
  titleEn: string;
  titleHi: string;
  descriptionEn: string;
  descriptionHi: string;
  accentHex: string;
  iconKey: 'math' | 'science' | 'evs' | 'english' | 'hindi' | 'social' | 'gk';
}

export interface NoteSection {
  heading: string;
  body: string;
  keyFormulaOrPoint?: string;
}

export interface ChapterNote {
  id: string;
  subjectId: string;
  classLevel: ClassLevel;
  language: LanguageCode;
  chapterNumber: number;
  title: string;
  summary: string;
  readTimeMinutes: number;
  sections: NoteSection[];
  practiceQuestion: {
    question: string;
    answer: string;
  };
  isCustom?: boolean;
  mediaUrl?: string;
}

export type VisualSceneKind =
  | 'numberline'
  | 'fraction'
  | 'geometry'
  | 'plant'
  | 'solar'
  | 'atom'
  | 'force'
  | 'circuit'
  | 'grammar'
  | 'map';

export interface AnimatedScene {
  id: string;
  title: string;
  caption: string;
  visualKind: VisualSceneKind;
  highlightValue: string;
  durationSec: number;
}

export interface ChapterVideo {
  id: string;
  subjectId: string;
  classLevel: ClassLevel;
  language: LanguageCode;
  chapterNumber: number;
  title: string;
  summary: string;
  durationLabel: string;
  durationSec: number;
  scenes: AnimatedScene[];
  isCustom?: boolean;
  mediaUrl?: string;
}

export interface SavedNoteRecord {
  uid: string;
  noteId: string;
  subjectId: string;
  classLevel: number;
  language: LanguageCode;
  title: string;
  chapterNumber: number;
  savedAt: unknown;
}

export interface NoteDownloadRecord {
  uid: string;
  noteId: string;
  subjectId: string;
  classLevel: number;
  language: LanguageCode;
  title: string;
  chapterNumber: number;
  fileName: string;
  downloadedAt: unknown;
}

export interface RecentNoteRecord {
  uid: string;
  noteId: string;
  subjectId: string;
  classLevel: number;
  language: LanguageCode;
  title: string;
  chapterNumber: number;
  openedAt: unknown;
}

export interface VideoHistoryRecord {
  uid: string;
  videoId: string;
  subjectId: string;
  classLevel: number;
  language: LanguageCode;
  title: string;
  chapterNumber: number;
  progressPercent: number;
  completed: boolean;
  updatedAt: unknown;
}

export type ReportStatus = 'pending' | 'approved' | 'rejected';

export interface ClassChangeReport {
  id: string;
  studentId: string;
  studentName: string;
  currentClass: number;
  requestedClass: number;
  reason: string;
  status: ReportStatus;
  adminNote: string;
  reviewedBy: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export type AnnouncementCategory = 'Exam' | 'Content' | 'Schedule' | 'General';

export interface Announcement {
  id: string;
  title: string;
  body: string;
  category: AnnouncementCategory;
  targetClass: number; // 0 = All classes, 1-10 = specific class
  authorId: string;
  authorName: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface CustomLesson {
  id: string;
  type: 'note' | 'video';
  classLevel: ClassLevel;
  language: LanguageCode;
  subjectId: string;
  chapterNumber: number;
  title: string;
  summary: string;
  content: string;
  durationLabel: string;
  mediaUrl: string;
  authorId: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export type UserRole = 'student' | 'admin';

export type PortalMode = 'student' | 'admin';

export interface CustomSubject {
  id: string;
  slug: string;
  titleEn: string;
  titleHi: string;
  descriptionEn: string;
  descriptionHi: string;
  minClass: number;
  maxClass: number;
  accentHex: string;
  iconKey: Subject['iconKey'];
  authorId: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface QuizQuestion {
  id: string;
  prompt: string;
  options: [string, string, string, string];
  correctIndex: 0 | 1 | 2 | 3;
  explanation: string;
}

export interface Quiz {
  id: string;
  classLevel: ClassLevel;
  language: LanguageCode;
  subjectId: string;
  chapterNumber: number;
  title: string;
  description: string;
  timeLimitMinutes: number;
  questions: QuizQuestion[];
  authorId: string;
  createdAt: unknown;
  updatedAt: unknown;
}

export interface QuizAttempt {
  id: string;
  studentId: string;
  quizId: string;
  quizTitle: string;
  subjectId: string;
  classLevel: ClassLevel;
  score: number;
  totalQuestions: number;
  percentage: number;
  updatedAt: unknown;
}

export type AppScreen =
  | 'home'
  | 'subjects'
  | 'subject-detail'
  | 'saved'
  | 'downloads'
  | 'announcements'
  | 'profile';
