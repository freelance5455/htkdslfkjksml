export type ProviderId = 'google' | 'groq' | 'openrouter' | 'zhipu' | 'openai' | 'anthropic';

export interface ModelOption {
  id: string;
  label: string;
  provider: ProviderId;
  tier: 'Free' | 'Paid';
  isCustom?: boolean;
}

export type ApiKeysMap = Record<ProviderId, string>;

export interface AttachmentItem {
  id: string;
  name: string;
  mimeType: string;
  size: number;
  kind: 'image' | 'text';
  content: string; // text content or base64 without data URL prefix
  previewUrl?: string; // data URL for image thumbnail preview
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: number;
  modelLabel?: string;
  attachments?: AttachmentItem[];
  syncedFiles?: string[];
  error?: string;
  isStreaming?: boolean;
}

export interface WorkspaceFile {
  path: string;
  content: string;
  language: string;
  updatedAt: number;
}

export type CodeSegment =
  | { type: 'markdown'; text: string }
  | { type: 'code'; language: string; filePath: string | null; code: string; isClosed: boolean };
