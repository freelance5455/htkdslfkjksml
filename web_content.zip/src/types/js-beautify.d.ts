declare module "js-beautify" {
  export function js(code: string, options?: Record<string, unknown>): string;
  export function css(code: string, options?: Record<string, unknown>): string;
  export function html(code: string, options?: Record<string, unknown>): string;
}
