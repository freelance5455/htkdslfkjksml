export type ClimbingStyle = 'Top Rope' | 'Lead' | 'Bouldering' | 'Auto-Belay';

export type ClimbOutcome = 'Onsite' | 'Flash' | 'Redpoint' | 'Attempt';

export type WallAngle = 'Slab' | 'Vertical' | 'Overhang' | 'Roof';

export type ChecklistCategory = 'Safety' | 'Equipment' | 'Technique' | 'Sign-Off';

export type CriterionStatus = 'Not Started' | 'In Progress' | 'Completed';

export type NICASLevelNumber = 1 | 2 | 3 | 4 | 5;

export interface ClimbingClub {
  id: string;
  name: string;
  location: string;
  region: string;
  wallTypes: ClimbingStyle[];
  isOfficialNicasCentre: boolean;
  notes?: string;
  phone?: string;
  mobile?: string;
  email?: string;
  contactEmail?: string; // backwards compatibility
  website?: string;
}

export type TrainingNoteCategory = 'Technique' | 'Safety' | 'Conditioning' | 'Assessment' | 'General';

export interface TrainingNote {
  id: string;
  title: string;
  content: string;
  date: string;
  category: TrainingNoteCategory;
  isPinned?: boolean;
  isCompleted?: boolean;
  createdAt: number;
}

export interface ClimbEntry {
  id: string;
  date: string; // YYYY-MM-DD
  routeName: string;
  style: ClimbingStyle;
  grade: string;
  wallAngle: WallAngle;
  outcome: ClimbOutcome;
  clubId: string;
  notes: string;
  attemptsCount?: number;
  sessionRef?: string;
  createdAt: number;
}

export interface ChecklistItem {
  id: string;
  level: NICASLevelNumber;
  category: ChecklistCategory;
  title: string;
  description: string;
  status: CriterionStatus;
  signOffDate?: string;
  instructorName?: string;
  instructorNotes?: string;
  verified: boolean;
}

export interface CandidateProfile {
  candidateName: string;
  candidateNumber: string;
  age?: number | '';
  dateOfBirth?: string;
  schemeTrack: 'NICAS Roped Climbing' | 'NICAS Bouldering' | 'Combined';
  homeClubId: string;
  currentLevel: NICASLevelNumber;
  targetLevel: NICASLevelNumber;
  leadInstructor: string;
  startDate: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  medicalNotes?: string;
}

export const BOULDERING_GRADES = [
  'VB', 'V0', 'V1', 'V2', 'V3', 'V4', 'V5', 'V6', 'V7', 'V8', 'V9', 'V10+'
] as const;

export const ROPED_GRADES = [
  '3', '4', '4+', '5a', '5b', '5c', '6a', '6a+', '6b', '6b+', '6c', '6c+', '7a', '7a+', '7b', '7b+', '7c', '8a+'
] as const;

export const NICAS_LEVEL_TITLES: Record<NICASLevelNumber, { title: string; subtitle: string; description: string }> = {
  1: {
    title: 'Level 1: New Climber',
    subtitle: 'Foundation Safety & Induction',
    description: 'Covers essential wall etiquette, warming up, basic footwear/harness awareness, and basic movement technique.'
  },
  2: {
    title: 'Level 2: Foundation Climber',
    subtitle: 'Knot Tying & Safe Belaying',
    description: 'Focuses on the re-threaded figure of eight knot with stopper, controlled belaying with a ground anchor, and safe lowering.'
  },
  3: {
    title: 'Level 3: Technical Climber',
    subtitle: 'Movement Precision & Route Reading',
    description: 'Develops footwork precision (flagging, smearing, edging), tactical rests, balance, and route planning on varied angles.'
  },
  4: {
    title: 'Level 4: Lead Climber',
    subtitle: 'Leading Technique & Dynamic Belay',
    description: 'Introduces clipping sequences, safe clipping stances, lead fall dynamics, active lead belaying, and lead climber ethics.'
  },
  5: {
    title: 'Level 5: Advanced & Performance',
    subtitle: 'Training, Tactical Mastery & Mentorship',
    description: 'Covers periodized indoor training, injury prevention, advanced tactical route reading, steep roof climbing, and logging experience.'
  }
};
