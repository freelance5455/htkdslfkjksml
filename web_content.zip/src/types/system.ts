export type SystemPhase = 'STARTUP' | 'PROFILE_SELECT' | 'HOME';

export type HomeTileId =
  | 'game-store'
  | 'game-library'
  | 'search'
  | 'settings'
  | 'profile';

export type HomeOverlay =
  | 'NONE'
  | 'GAME_STORE'
  | 'GAME_LIBRARY'
  | 'SEARCH'
  | 'SETTINGS'
  | 'PROFILE';

export type WallpaperId =
  | 'blue-wavy-symbols'
  | 'red-horns'
  | 'green-wave'
  | 'pink-wave'
  | 'yellow-wave'
  | 'brown-wave'
  | 'spiked-loops'
  | 'abyssal-prism'
  | 'arctic-aurora'
  | 'monochrome-horizon'
  | 'cyber-grid'
  | 'obsidian-starfield'
  | 'violet-vortex'
  | 'crimson-eclipse'
  | 'teal-circuit'
  | 'midnight-crystal';

export type ScreenReaderVoiceId = 'maya-us';

export interface VoiceOption {
  id: ScreenReaderVoiceId;
  name: string;
  regionLabel: string;
  description: string;
  badge: string;
}

export const VOICE_OPTIONS: VoiceOption[] = [
  {
    id: 'maya-us',
    name: 'Maya (US English)',
    regionLabel: 'en-US · Soft-Voiced Studio',
    description:
      'US English, soft-voiced, calm African American female accessibility screen reader',
    badge: 'System Voice',
  },
];

export interface WallpaperOption {
  id: WallpaperId;
  name: string;
  subtitle: string;
  baseColor: string;
  accentHex: string;
}

export interface SystemSettings {
  wallpaperId: WallpaperId;
  masterVolume: number; // 0 to 1
  musicEnabled: boolean;
  musicVolume: number; // 0 to 1
  sfxEnabled: boolean;
  sfxVolume: number; // 0 to 1
  startupAudioEnabled: boolean;
  screenReaderEnabled: boolean;
  screenReaderVolume: number; // 0 to 1
  screenReaderVoiceId: ScreenReaderVoiceId;
  screenReaderRate: number; // 0.75 to 1.35
  screenReaderHintsEnabled: boolean;
  doubleTapDelayMs: number;
}

export interface ProfileProgression {
  level: number;
  xp: number;
  xpToNext: number;
  sessionsCount: number;
  wallpapersTried: WallpaperId[];
  unlockedMilestones: string[];
  installedGameIds: string[];
  lastActiveAt: string;
}

export interface Profile {
  id: string;
  name: string;
  avatarUrl: string;
  gamesCount: number;
  createdAt: string;
  settings: SystemSettings;
  progression: ProfileProgression;
}

export interface AvatarOption {
  id: string;
  label: string;
  url: string;
}

export const AVATAR_OPTIONS: AvatarOption[] = [
  {
    id: 'gold-knight',
    label: 'Obsidian Visor',
    url: '/src/assets/images/avatar_gold_knight_1794663485741.jpg',
  },
  {
    id: 'astral-fox',
    label: 'Golden Kitsune',
    url: '/src/assets/images/avatar_astral_fox_1794663486089.jpg',
  },
  {
    id: 'void-owl',
    label: 'Titanium Owl',
    url: '/src/assets/images/avatar_void_owl_1794663486022.jpg',
  },
  {
    id: 'nebula-pilot',
    label: 'Astral Pilot',
    url: '/src/assets/images/avatar_nebula_pilot_1794663487978.jpg',
  },
  {
    id: 'ghost-emblem',
    label: 'Spectral Ghost',
    url: '/src/assets/images/ghost_games_avatar_1794662695113.jpg',
  },
];

export const DEFAULT_SETTINGS: SystemSettings = {
  wallpaperId: 'blue-wavy-symbols',
  masterVolume: 0.85,
  musicEnabled: true,
  musicVolume: 0.55,
  sfxEnabled: true,
  sfxVolume: 0.85,
  startupAudioEnabled: true,
  screenReaderEnabled: true,
  screenReaderVolume: 0.9,
  screenReaderVoiceId: 'maya-us',
  screenReaderRate: 1.0,
  screenReaderHintsEnabled: true,
  doubleTapDelayMs: 450,
};

export function createDefaultProgression(
  initialWallpaper: WallpaperId = 'blue-wavy-symbols'
): ProfileProgression {
  return {
    level: 1,
    xp: 25,
    xpToNext: 100,
    sessionsCount: 1,
    wallpapersTried: [initialWallpaper],
    unlockedMilestones: ['System Awakened'],
    installedGameIds: [],
    lastActiveAt: new Date().toISOString(),
  };
}

export const DEFAULT_PROFILES: Profile[] = [
  {
    id: 'ghost-games',
    name: 'Ghost Games',
    avatarUrl: '/src/assets/images/ghost_games_avatar_1794662695113.jpg',
    gamesCount: 0,
    createdAt: '2026-01-01T00:00:00.000Z',
    settings: { ...DEFAULT_SETTINGS },
    progression: createDefaultProgression(DEFAULT_SETTINGS.wallpaperId),
  },
];

export const WALLPAPER_OPTIONS: WallpaperOption[] = [
  {
    id: 'blue-wavy-symbols',
    name: 'Cobalt Console Waves',
    subtitle: 'Blue wavy ribbons with square, triangle & circle symbols',
    baseColor: '#04122b',
    accentHex: '#38bdf8',
  },
  {
    id: 'red-horns',
    name: 'Crimson Horns',
    subtitle: 'Deep scarlet waves with stylized glowing horns',
    baseColor: '#220509',
    accentHex: '#fb7185',
  },
  {
    id: 'green-wave',
    name: 'Emerald Tide',
    subtitle: 'Rich emerald & forest green layered waves',
    baseColor: '#041c12',
    accentHex: '#34d399',
  },
  {
    id: 'pink-wave',
    name: 'Rose Pulse',
    subtitle: 'Luminous magenta and soft pink flowing waves',
    baseColor: '#240718',
    accentHex: '#f472b6',
  },
  {
    id: 'yellow-wave',
    name: 'Solar Amber',
    subtitle: 'Warm golden yellow sweeping wave bands',
    baseColor: '#211804',
    accentHex: '#facc15',
  },
  {
    id: 'brown-wave',
    name: 'Mahogany Drift',
    subtitle: 'Warm espresso, umber, and bronze silk waves',
    baseColor: '#1b1109',
    accentHex: '#d69e6e',
  },
  {
    id: 'spiked-loops',
    name: 'Spiked Loops',
    subtitle: 'Sharp spiked wave crests woven into rhythmic loops',
    baseColor: '#070b1a',
    accentHex: '#818cf8',
  },
  {
    id: 'abyssal-prism',
    name: 'Abyssal Prism',
    subtitle: 'Faceted deep-sea cyan and midnight blue geometry',
    baseColor: '#04141d',
    accentHex: '#22d3ee',
  },
  {
    id: 'arctic-aurora',
    name: 'Arctic Aurora',
    subtitle: 'Tranquil polar light ribbons over dark slate',
    baseColor: '#050f1e',
    accentHex: '#2dd4bf',
  },
  {
    id: 'monochrome-horizon',
    name: 'Slate Horizon',
    subtitle: 'Architectural dark steel curves with cool blue trim',
    baseColor: '#090c12',
    accentHex: '#94a3b8',
  },
  {
    id: 'cyber-grid',
    name: 'Neon Horizon Grid',
    subtitle: 'Perspective synth grid horizon under a cobalt arc',
    baseColor: '#06081c',
    accentHex: '#60a5fa',
  },
  {
    id: 'obsidian-starfield',
    name: 'Deep Space Nebula',
    subtitle: 'Ink-black starfield with luminous sapphire nebula clouds',
    baseColor: '#030612',
    accentHex: '#7dd3fc',
  },
  {
    id: 'violet-vortex',
    name: 'Violet Vortex',
    subtitle: 'Swirling royal amethyst & electric blue orbital rings',
    baseColor: '#120624',
    accentHex: '#a78bfa',
  },
  {
    id: 'crimson-eclipse',
    name: 'Crimson Eclipse',
    subtitle: 'Volcanic obsidian shadow with a glowing solar corona',
    baseColor: '#160408',
    accentHex: '#f87171',
  },
  {
    id: 'teal-circuit',
    name: 'Circuit Matrix',
    subtitle: 'Precision dark slate PCB traces and glowing teal nodes',
    baseColor: '#04161a',
    accentHex: '#2dd4bf',
  },
  {
    id: 'midnight-crystal',
    name: 'Midnight Crystal',
    subtitle: 'Faceted sapphire crystal shards over deep midnight',
    baseColor: '#050c1f',
    accentHex: '#38bdf8',
  },
];
