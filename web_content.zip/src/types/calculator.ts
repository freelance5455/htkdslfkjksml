export type Operation = '+' | '-' | '×' | '÷' | '%';

export type Language = 'ur' | 'en';
export type NumeralSystem = 'western' | 'eastern'; // 123 vs ۱۲۳

export interface HistoryItem {
  id: string;
  expression: string;
  result: string;
  timestamp: number;
}

export type ActiveTab = 'standard' | 'percentage' | 'units';

export interface UnitCategory {
  id: string;
  nameUr: string;
  nameEn: string;
  units: {
    id: string;
    nameUr: string;
    nameEn: string;
    toBase: (val: number) => number;
    fromBase: (val: number) => number;
  }[];
}
