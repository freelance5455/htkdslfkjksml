export type CalculatorMode = 'regular' | 'scientific';
export type AngleMode = 'DEG' | 'RAD';

export interface HistoryItem {
  id: string;
  expression: string;
  result: string;
  rawResult: string;
  mode: CalculatorMode;
  angleMode: AngleMode;
  timestamp: number;
}
