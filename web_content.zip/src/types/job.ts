export type JobSector = 'Government' | 'Private';

export type JobStatus = 
  | 'DRAFT' 
  | 'PENDING' 
  | 'VERIFIED' 
  | 'PUBLISHED' 
  | 'EXPIRED' 
  | 'REJECTED';

export type JobCategory = 
  | 'All'
  | 'Government Jobs'
  | 'Private Jobs'
  | 'Latest Jobs'
  | 'Jobs Near Me'
  | 'ITI Jobs'
  | 'Diploma Jobs'
  | 'Graduate Jobs'
  | 'Railway Jobs'
  | 'Banking Jobs'
  | 'Defence Jobs'
  | 'Apprenticeship Jobs';

export interface JobPosting {
  id: string;
  title: string;
  organization: string;
  orgLogo?: string;
  sector: JobSector;
  category: JobCategory[];
  state: string;
  district: string;
  qualification: string;
  experience?: string;
  ageLimit: string;
  salary: string;
  vacancies: number;
  openingDate?: string; // YYYY-MM-DD
  closingDate?: string; // YYYY-MM-DD
  expiryDate?: string;  // Application deadline / expiry date (YYYY-MM-DD)
  lastDate: string;     // YYYY-MM-DD (legacy / display)
  postDate: string;
  description: string;
  selectionProcess: string[];
  requiredDocuments?: string[];
  officialNotificationUrl?: string; // PDF or official gazette link
  officialApplicationLink: string;
  officialSource: string;
  sourceUrl?: string;
  applicationFee: string;
  lastVerifiedDate?: string;
  status: JobStatus;
  isFeatured?: boolean;
  isUrgent?: boolean;
  isLatest?: boolean;
  experienceRequired?: string;
  demoDataBadge: boolean;
  likesCount?: number;
  likedBy?: string[];
  savesCount?: number;
  sharesCount?: number;
  viewsCount?: number;
  applicationsCount?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface StateInfo {
  name: string;
  code: string;
  isUT?: boolean;
  districts: string[];
  capital?: string;
  coordinates?: { lat: number; lng: number };
}

export interface FilterState {
  searchQuery: string;
  selectedState: string;
  selectedDistrict: string;
  selectedCategory: JobCategory;
  selectedSector: 'All' | JobSector;
  qualificationFilter: string;
  salaryFilter?: string;
  onlyFreshers?: boolean;
}

export type ReportReason = 
  | 'Fake job' 
  | 'Wrong information' 
  | 'Expired job' 
  | 'Broken link' 
  | 'Duplicate job' 
  | 'Scam';

export interface JobReport {
  id: string;
  jobId: string;
  jobTitle: string;
  organization: string;
  reason: ReportReason;
  details?: string;
  reportedBy?: string;
  userEmail?: string;
  createdAt: string;
  status: 'PENDING' | 'RESOLVED' | 'DISMISSED';
}

export interface JobAlertPreference {
  id?: string;
  userId: string;
  userEmail?: string;
  states: string[];
  districts: string[];
  categories: JobCategory[];
  qualifications: string[];
  fcmToken?: string;
  enabled: boolean;
  updatedAt: string;
}

export interface AdminUser {
  uid: string;
  email: string;
  displayName?: string;
  role: 'admin' | 'superadmin' | 'editor';
  createdAt: string;
}

/**
 * Safely extracts the application deadline / expiry date from a job posting.
 * Checks expiryDate, closingDate, and lastDate in sequence.
 * Returns null if no valid date string is set (Requirement 10).
 */
export function getJobExpiryDate(job?: Partial<JobPosting> | null): string | null {
  if (!job) return null;
  const raw = job.expiryDate || job.closingDate || job.lastDate;
  if (!raw || typeof raw !== 'string') return null;
  const trimmed = raw.trim();
  return trimmed || null;
}

/**
 * Automatically determines whether a job is expired by comparing its expiry date with the current date.
 * Handles jobs without an expiry date safely without causing errors (returns false).
 */
export function isJobExpired(job?: Partial<JobPosting> | null): boolean {
  if (!job) return false;
  if (job.status === 'EXPIRED') return true;

  const expiryStr = getJobExpiryDate(job);
  if (!expiryStr) return false;

  try {
    const todayStr = new Date().toISOString().split('T')[0]; // Current date: YYYY-MM-DD

    // Fast comparison for ISO YYYY-MM-DD format
    if (/^\d{4}-\d{2}-\d{2}$/.test(expiryStr)) {
      return expiryStr < todayStr;
    }

    // Generic date parsing fallback
    const parsed = new Date(expiryStr);
    if (isNaN(parsed.getTime())) {
      return false; // Safely ignore non-parseable dates
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const expDate = new Date(parsed);
    expDate.setHours(23, 59, 59, 999);

    return expDate.getTime() < today.getTime();
  } catch {
    return false;
  }
}
