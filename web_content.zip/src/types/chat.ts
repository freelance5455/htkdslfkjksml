export type ActionType =
  | 'whatsapp'
  | 'youtube'
  | 'device_lock'
  | 'phone_call'
  | 'google_search'
  | 'generate_image'
  | 'start_timer'
  | 'flashlight'
  | 'battery_status'
  | 'open_url';

export interface ActionPayload {
  type: ActionType;
  title: string;
  description: string;
  params: Record<string, any>;
  url?: string;
  nativeUrl?: string;
  autoExecute?: boolean;
  executed?: boolean;
}

export interface ThinkingProcess {
  summary?: string;
  steps: string[];
  durationSec: number;
}

export interface ActiveTask {
  type: 'whatsapp' | 'call' | 'youtube' | 'timer' | 'search';
  step: 'awaiting_contact' | 'awaiting_message' | 'ready_to_send' | 'idle';
  contactName?: string;
  phone?: string;
  message?: string;
  query?: string;
}

export interface UserPermissions {
  whatsapp: boolean;
  youtube: boolean;
  deviceControl: boolean;
  microphone: boolean;
  geminiAi: boolean;
  haptics: boolean;
  alwaysAskBeforeAction: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  thinking?: ThinkingProcess;
  action?: ActionPayload;
  actionStatus?: 'executed' | 'pending' | 'denied';
  imageUrl?: string;
}

export interface DeviceTelemetry {
  batteryLevel?: number;
  isCharging?: boolean;
  isOnline: boolean;
  connectionType?: string;
  screenResolution: string;
}
