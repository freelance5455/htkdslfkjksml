export type GeminiModelId = 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite';
export type ThinkingPreset = 'AUTO' | 'LOW' | 'MEDIUM' | 'HIGH';
export type ThemeMode = 'dark' | 'light';
export type RefineMode = 'simplify' | 'shorter' | 'hinglish' | 'steps';

export interface Attachment {
  id: string;
  name: string;
  mimeType: string;
  data: string; // base64 string without data URL prefix
  previewUrl: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  at: number;
  model?: GeminiModelId;
  attachments?: Attachment[];
  isError?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  followUps?: string[];
  created: number;
  updated: number;
}

export interface AppSettings {
  model: GeminiModelId;
  thinkingLevel: ThinkingPreset;
  personality: string;
  theme: ThemeMode;
  remember: boolean;
}

export const DEFAULT_PERSONALITY =
  'You are CB AI, a friendly, funny, helpful assistant created by Code Bracker. Speak naturally in Hinglish when the user uses Hinglish. Be respectful, clear, encouraging and honest. Use light humour when suitable. Never pretend to know something you do not know.';

export const PERSONALITY_PRESETS: Array<{ label: string; prompt: string }> = [
  {
    label: 'Friendly & Hinglish (Default)',
    prompt: DEFAULT_PERSONALITY,
  },
  {
    label: 'Concise Coding Partner',
    prompt:
      'You are CB AI by Code Bracker acting as a senior engineering partner. Give crisp, practical answers, clean code examples, and point out edge cases briefly without fluff.',
  },
  {
    label: 'Patient Study Buddy',
    prompt:
      'You are CB AI by Code Bracker acting as an encouraging tutor. Break down tough concepts with everyday analogies, check understanding gently, and support Hinglish if asked.',
  },
];

export const DEFAULT_SETTINGS: AppSettings = {
  model: 'gemini-4-hydrogen',
  thinkingLevel: 'AUTO',
  personality: DEFAULT_PERSONALITY,
  theme: 'dark',
  remember: true,
};
