export type MessageRole = 'user' | 'assistant' | 'system';

export interface Attachment {
  id: string;
  name: string;
  type: 'image' | 'excel' | 'csv' | 'document' | 'pdf' | 'audio' | 'apk' | 'binary';
  mimeType: string;
  size: number;
  dataUrl?: string; // base64 or preview
  textContent?: string;
  sheetData?: {
    sheetNames: string[];
    summary: string;
    sampleRows: Record<string, any>[];
    totalRows: number;
    totalColumns: number;
  };
}

export interface GeneratedImage {
  url: string;
  prompt: string;
  aspectRatio?: string;
  timestamp: number;
}

export interface GroundingSource {
  title?: string;
  url?: string;
  snippet?: string;
}

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: number;
  model?: string;
  attachments?: Attachment[];
  groundingSources?: GroundingSource[];
  thoughtProcess?: string;
  isVoiceInput?: boolean;
  audioUrl?: string;
  generatedImages?: GeneratedImage[];
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
  pinned?: boolean;
}

export type ModelType =
  | 'gemini-3.1-flash-lite'
  | 'gemini-3.5-flash'
  | 'gemini-3.1-pro-preview'
  | 'gemini-3.8-flash';

export interface ModelOption {
  id: ModelType;
  name: string;
  nameAr: string;
  descAr: string;
  badgeAr: string;
  supportsGrounding?: boolean;
  supportsThinking?: boolean;
}

export interface ImageGenParams {
  prompt: string;
  aspectRatio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4' | '21:9';
  imageSize: '1K' | '2K' | '4K';
  style: string;
  negativePrompt?: string;
}
