export type AppPage = "welcome" | "chat" | "history" | "settings" | "about";

export type ThemePreference = "light" | "dark" | "system";

export type LanguagePreference = "auto" | "en" | "bn" | "hi";

export interface ImageAttachment {
  mimeType: string;
  data: string; // raw base64
  previewUrl: string; // data URL for rendering
  name: string;
  sizeBytes: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  image?: {
    mimeType: string;
    data: string;
    name?: string;
  };
  createdAt: number;
  error?: string;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
}

export interface AppSettings {
  theme: ThemePreference;
  language: LanguagePreference;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  mode: "demo" | "google";
}

export interface ServerHealth {
  aiConfigured: boolean;
  googleAuthConfigured: boolean;
  googleClientId: string | null;
  model: string;
}
