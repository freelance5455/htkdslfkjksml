export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  image?: {
    data: string; // base64 string
    mimeType: string;
    previewUrl?: string;
  };
  isStreaming?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
}

export interface ApiStatus {
  status: string;
  hasApiKey: boolean;
  model: string;
  appName: string;
  arabicSupport: boolean;
}
