/**
 * Types for دفتر الجرد والأرباح (Iraqi Pharmacy Wholesale Ledger)
 */

export interface MedicineItem {
  id: string;
  barcode: string;
  name: string;
  scientificName?: string;
  unit: string; // باكيت, علبة, شريط, قارورة, كرتونة
  minStockAlert: number;
  addedByUid?: string;
  addedByName?: string;
}

export interface PurchaseItem {
  id: string;
  date: string; // YYYY-MM-DD
  supplier: string; // اسم المذخر / المورد
  barcode: string;
  medicineName: string;
  qty: number;
  unitPrice: number; // سعر الشراء للوحدة (بالدينار العراقي)
  totalAmount: number; // qty * unitPrice
  expiryDate: string; // YYYY-MM-DD
  amountPaid: number; // المدفوع كاش
  remainingUnpaid: number; // totalAmount - amountPaid
  notes?: string;
  createdAt: number;
  addedByUid?: string;
  addedByName?: string;
}

export interface SaleItem {
  id: string;
  date: string; // YYYY-MM-DD
  buyer: string; // اسم الصيدلية أو العميل
  barcode: string;
  medicineName: string;
  qty: number;
  unitPrice: number; // سعر البيع للوحدة
  totalAmount: number; // qty * unitPrice
  avgCostAtSale: number; // تكلفة الوحدة وقت البيع
  amountPaid: number; // المدفوع نقداً
  remainingUnpaid: number; // totalAmount - amountPaid
  nearestExpiryBatch?: string; // تاريخ الوجبة الأقرب انتهاءً
  notes?: string;
  createdAt: number;
  addedByUid?: string;
  addedByName?: string;
}

export type ExpenseType =
  | 'نقل وشحن'
  | 'إيجار المذخر'
  | 'كهرباء ومولد'
  | 'رواتب موظفين'
  | 'ضيافة ونثريات'
  | 'تالف ومنتهي'
  | 'صيانة ومعدات'
  | 'أخرى';

export interface ExpenseItem {
  id: string;
  date: string; // YYYY-MM-DD
  type: ExpenseType;
  amount: number;
  note: string;
  createdAt: number;
  addedByUid?: string;
  addedByName?: string;
}

export interface DebtPayment {
  id: string;
  partyType: 'buyer' | 'supplier'; // صيدلية زبون أم مذخر مورد
  partyName: string;
  date: string; // YYYY-MM-DD
  amount: number;
  type: 'receipt' | 'payment'; // قبض من زبون / دفع لمورد
  note?: string;
  createdAt: number;
  addedByUid?: string;
  addedByName?: string;
}

export type ActivityActionType =
  | 'add_purchase'
  | 'add_sale'
  | 'add_expense'
  | 'add_payment'
  | 'edit_medicine'
  | 'delete_record'
  | 'sync_seed';

export interface ActivityLogItem {
  id: string;
  actionType: ActivityActionType;
  title: string;
  details: string;
  amount: number;
  actorUid: string;
  actorName: string;
  createdAtMs: number;
}

export interface BatchInfo {
  purchaseId: string;
  expiryDate: string;
  originalQty: number;
  remainingQty: number;
  unitPrice: number;
  supplier: string;
}

export interface MedicineStock {
  barcode: string;
  name: string;
  unit: string;
  totalBought: number;
  totalSold: number;
  remaining: number;
  averageCost: number; // Average cost per unit
  stockValue: number; // remaining * averageCost
  minStockAlert: number;
  batches: BatchInfo[];
  nearestExpiry: string | null;
  daysToExpiry: number | null;
  isLowStock: boolean;
  isExpired: boolean;
  isNearExpiry: boolean; // within 90 days
}

export interface MedicineProfitItem {
  medicineName: string;
  barcode: string;
  qtySold: number;
  revenue: number;
  cogs: number;
  grossProfit: number;
  marginPercent: number;
}

export interface ProfitReportResult {
  periodLabel: string;
  startDate: string;
  endDate: string;
  totalSales: number;
  cogs: number; // Cost of goods sold based on average cost
  grossProfit: number;
  totalExpenses: number;
  netProfit: number;
  profitMarginPercent: number;
  medicineProfits: MedicineProfitItem[];
}

export interface PartyDebtSummary {
  partyName: string;
  partyType: 'buyer' | 'supplier';
  totalInvoiced: number;
  totalPaid: number;
  balanceRemaining: number; // How much owed
  lastTransactionDate: string;
}

export interface AppDatabase {
  version: number;
  updatedAt: string;
  currency: string;
  medicines: MedicineItem[];
  purchases: PurchaseItem[];
  sales: SaleItem[];
  expenses: ExpenseItem[];
  payments: DebtPayment[];
  minStockOverrides: Record<string, number>; // barcode -> minStock
  activityLogs?: ActivityLogItem[];
}
