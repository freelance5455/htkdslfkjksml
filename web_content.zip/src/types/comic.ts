export type ComicArchiveFormat = 'cbz' | 'cbr' | 'zip' | 'rar';

export type ReadingMode = 'vertical' | 'paged-vertical' | 'horizontal-ltr' | 'horizontal-rtl';

export type ScreenOrientationMode = 'free' | 'portrait' | 'portrait-reverse' | 'landscape';

export type FitMode = 'fit-width' | 'fit-height' | 'fit-screen' | 'custom';

export type PageTransition = 'slide' | 'fade' | 'curl' | 'zoom' | 'stack' | 'none';

export type ColorMode = 'light' | 'dark' | 'amoled';

export interface TocBookmark {
  pageIndex: number;
  title: string;
  type?: string;
  source: 'pages-bookmark' | 'bookmarks-tag' | 'user';
}

export interface ComicPageInfo {
  imageIndex: number;
  type?: string;
  bookmark?: string;
  imageWidth?: number;
  imageHeight?: number;
  imageSize?: number;
  key?: string;
}

export interface ComicInfoMetadata {
  title?: string;
  series?: string;
  number?: string;
  count?: number;
  volume?: number;
  alternateSeries?: string;
  summary?: string;
  notes?: string;
  year?: number;
  month?: number;
  day?: number;
  writer?: string;
  penciller?: string;
  inker?: string;
  colorist?: string;
  letterer?: string;
  coverArtist?: string;
  editor?: string;
  publisher?: string;
  imprint?: string;
  genre?: string;
  tags?: string;
  web?: string;
  pageCount?: number;
  languageISO?: string;
  format?: string;
  blackAndWhite?: string;
  manga?: string;
  ageRating?: string;
  communityRating?: number;
  storyArc?: string;
  seriesGroup?: string;
  pages: ComicPageInfo[];
  toc: TocBookmark[];
  rawXml?: string;
}

export type ReadStatus = 'unread' | 'reading' | 'completed';

export interface ComicEntry {
  id: string;
  syncKey?: string;
  fileName: string;
  displayTitle: string;
  folderId: string;
  folderName: string;
  relativePath: string;
  format: ComicArchiveFormat;
  fileSize: number;
  lastModified: number;
  pageCount: number;
  coverBlob?: Blob;
  comicInfo?: ComicInfoMetadata;
  currentPage: number;
  scrollProgress: number; // 0..1 overall completion ratio
  scrollOffsetY?: number; // exact vertical scrollTop px
  scrollRatio?: number; // 0..1 normalized scroll position in vertical container
  readStatus?: ReadStatus;
  lastReadAt?: number;
  updatedAt?: number;
  syncDirty?: boolean;
  addedAt: number;
  isOfflineCached: boolean;
  isSample?: boolean;
  userBookmarks: TocBookmark[];
  fileHandle?: FileSystemFileHandle;
  imageFormatsFound: string[];
}

export interface SyncedComicRecord {
  syncKey: string;
  fileName: string;
  displayTitle: string;
  pageCount: number;
  currentPage: number;
  scrollProgress: number;
  scrollOffsetY: number;
  scrollRatio: number;
  readStatus: ReadStatus;
  lastReadAt: number;
  updatedAt: number;
  userBookmarks: TocBookmark[];
}

export interface CloudSyncManifest {
  version: 1;
  lastSyncedAt: number;
  deviceLabel: string;
  records: Record<string, SyncedComicRecord>;
}

export interface LibraryFolder {
  id: string;
  name: string;
  sourceType: 'fs-access' | 'upload' | 'sample';
  comicCount: number;
  lastScannedAt: number;
  handle?: FileSystemDirectoryHandle;
  permissionState?: 'granted' | 'prompt' | 'denied';
}

export interface ReaderSettings {
  readingMode: ReadingMode;
  orientationMode: ScreenOrientationMode;
  pageTransition: PageTransition;
  fitMode: FitMode;
  customZoom: number; // percentage 50..250
  marginLeft: number; // percentage 0..30
  marginRight: number; // percentage 0..30
  marginLinked: boolean;
  pageGap: number; // px 0..32
  readerBg: string;
  hardwareAccel: boolean;
  sliceLongStrips: boolean;
  showPageNumberHud: boolean;
  keepScreenAwake: boolean;
}

export interface AppThemeSettings {
  colorMode: ColorMode;
  accentColor: string;
  gridDensity: 'comfortable' | 'compact';
}

export interface ArchivePageDescriptor {
  index: number;
  name: string;
  ext: string;
  size: number;
}

export interface DecodedTile {
  url: string;
  width: number;
  height: number;
}

export interface DecodedPageAsset {
  index: number;
  name: string;
  ext: string;
  width: number;
  height: number;
  wasSliced: boolean;
  tiles: DecodedTile[];
  revoke: () => void;
}
