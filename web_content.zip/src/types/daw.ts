export type ViewMode = 'playlist' | 'pianoroll' | 'stepseq' | 'play' | 'mixer';

export type InstrumentType = 'synth' | 'drums' | 'bass' | 'keys';

export type DrumSoundType = 
  | 'kick' 
  | 'snare' 
  | 'clap' 
  | 'hihat_closed' 
  | 'hihat_open' 
  | 'sub808' 
  | 'perc' 
  | 'cowbell';

export interface SynthConfig {
  osc1Type: OscillatorType;
  osc2Type: OscillatorType;
  detune: number; // in cents -50 to 50
  osc2Mix: number; // 0 to 1
  filterCutoff: number; // 100 to 12000 Hz
  filterRes: number; // 0.1 to 15
  filterType: BiquadFilterType;
  attack: number; // 0.005 to 2.0s
  decay: number; // 0.05 to 2.0s
  sustain: number; // 0 to 1
  release: number; // 0.05 to 3.0s
  glide: number; // 0 to 0.5s
}

export interface TrackFx {
  eqLow: number; // -12 to +12 dB
  eqMid: number; // -12 to +12 dB
  eqHigh: number; // -12 to +12 dB
  delayTime: number; // 0.05 to 0.8s
  delayFeedback: number; // 0 to 0.85
  delayMix: number; // 0 to 1
  reverbDecay: number; // 0.5 to 5.0s
  reverbMix: number; // 0 to 1
  distortionDrive: number; // 0 to 10
  distortionMix: number; // 0 to 1
}

export interface Note {
  id: string;
  pitch: number; // MIDI number 36-84 (C2 to C6)
  startBeat: number; // beat relative to clip start (e.g. 0, 0.25, 0.5)
  durationBeats: number; // in beats (e.g. 0.25, 0.5, 1, 2)
  velocity: number; // 0.1 to 1.0
}

export interface DrumStep {
  step: number; // 0 to 15 (or 31)
  drum: DrumSoundType;
  velocity: number; // 0.1 to 1.0
}

export interface Clip {
  id: string;
  trackId: string;
  name: string;
  startBeat: number; // beat in the song (0, 4, 8, 12, etc.)
  durationBeats: number; // total length in beats (usually 4 or 8)
  color: string;
  notes?: Note[]; // for melody/synth/bass/keys
  drumSteps?: DrumStep[]; // for drum tracks
}

export interface Track {
  id: string;
  name: string;
  type: InstrumentType;
  color: string;
  volume: number; // 0 to 1.2, default 0.8
  pan: number; // -1 to 1, default 0
  muted: boolean;
  soloed: boolean;
  synthConfig: SynthConfig;
  fx: TrackFx;
  clips: Clip[];
}

export interface Project {
  id: string;
  name: string;
  bpm: number; // 60 to 220
  timeSignature: [number, number]; // [4, 4]
  swing: number; // 0 to 50%
  masterVolume: number; // 0 to 1.2
  loopStart: number; // in beats
  loopEnd: number; // in beats
  isLooping: boolean;
  tracks: Track[];
}

export interface ScaleDefinition {
  name: string;
  intervals: number[]; // semitone offsets from root
}

export const SCALES: Record<string, ScaleDefinition> = {
  minor: { name: 'Natural Minor (Aeolian)', intervals: [0, 2, 3, 5, 7, 8, 10] },
  major: { name: 'Major (Ionian)', intervals: [0, 2, 4, 5, 7, 9, 11] },
  pentatonic_minor: { name: 'Minor Pentatonic', intervals: [0, 3, 5, 7, 10] },
  blues: { name: 'Blues Scale', intervals: [0, 3, 5, 6, 7, 10] },
  harmonic_minor: { name: 'Harmonic Minor', intervals: [0, 2, 3, 5, 7, 8, 11] },
  dorian: { name: 'Dorian', intervals: [0, 2, 3, 5, 7, 9, 10] },
  phrygian: { name: 'Phrygian (Trap Dark)', intervals: [0, 1, 3, 5, 7, 8, 10] },
};

export const DRUM_VOICES: { id: DrumSoundType; name: string; color: string; key: string }[] = [
  { id: 'kick', name: '808 Kick', color: '#ff5722', key: '1' },
  { id: 'snare', name: 'Punch Snare', color: '#00bcd4', key: '2' },
  { id: 'clap', name: 'Trap Clap', color: '#e91e63', key: '3' },
  { id: 'hihat_closed', name: 'Closed Hat', color: '#ffb300', key: '4' },
  { id: 'hihat_open', name: 'Open Hat', color: '#ffca28', key: '5' },
  { id: 'sub808', name: '808 Sub Boom', color: '#9c27b0', key: '6' },
  { id: 'perc', name: 'Perc Hit', color: '#4caf50', key: '7' },
  { id: 'cowbell', name: '808 Cowbell', color: '#00e676', key: '8' },
];

export const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

export function midiToNoteName(midi: number): string {
  const octave = Math.floor(midi / 12) - 1;
  const note = NOTE_NAMES[midi % 12];
  return `${note}${octave}`;
}

export function midiToFrequency(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}
