export type CivilizationId = 'iberos' | 'romanos' | 'godos' | 'celtas';

export interface Civilization {
  id: CivilizationId;
  name: string;
  motto: string;
  description: string;
  leaderTitle: string;
  bonuses: {
    foodBonus: number;
    woodBonus: number;
    stoneBonus: number;
    goldBonus: number;
    infantryBonus: number;
    archerBonus: number;
    cavalryBonus: number;
    defenseBonus: number;
  };
  color: string;
  badge: string;
}

export type ResourceType = 'food' | 'wood' | 'stone' | 'gold';

export interface Resources {
  food: number;
  wood: number;
  stone: number;
  gold: number;
}

export interface ResourceRates {
  foodPerHour: number;
  woodPerHour: number;
  stonePerHour: number;
  goldPerHour: number;
}

export type BuildingType =
  | 'townHall'
  | 'farm'
  | 'lumberMill'
  | 'quarry'
  | 'goldMine'
  | 'warehouse'
  | 'granary'
  | 'barracks'
  | 'university'
  | 'wall'
  | 'parliament'
  | 'tavern'
  | 'hospital'
  | 'houses';

export interface BuildingInfo {
  type: BuildingType;
  name: string;
  description: string;
  category: 'resources' | 'infrastructure' | 'military' | 'civic';
  icon: string;
  baseCost: Resources;
  costMultiplier: number;
  baseTimeSeconds: number;
  timeMultiplier: number;
  effectDescription: (level: number) => string;
}

export interface ConstructionQueueItem {
  id: string;
  buildingType: BuildingType;
  targetLevel: number;
  startTime: number;
  durationMs: number;
  finishTime: number;
}

export type TechType =
  | 'cropRotation'
  | 'ironAxes'
  | 'deepQuarry'
  | 'coinage'
  | 'ironArmor'
  | 'compositeBow'
  | 'horseBreeding'
  | 'siegeEngines'
  | 'espionageNetwork'
  | 'stoneFortification'
  | 'medicinalHerbs'
  | 'fieldSurgery'
  | 'battlefieldSanitation';

export interface TechInfo {
  type: TechType;
  name: string;
  branch: 'economy' | 'military' | 'defense' | 'medicine';
  description: string;
  maxLevel?: number;
  baseCost: Resources;
  costMultiplier: number;
  baseTimeSeconds: number;
  effectDescription: (level: number) => string;
}

export interface ResearchQueueItem {
  id: string;
  techType: TechType;
  targetLevel: number;
  startTime: number;
  durationMs: number;
  finishTime: number;
}

export type UnitType =
  | 'militia'
  | 'swordsman'
  | 'archer'
  | 'crossbowman'
  | 'lightCavalry'
  | 'knight'
  | 'batteringRam'
  | 'catapult'
  | 'spy';

export interface UnitInfo {
  type: UnitType;
  name: string;
  category: 'infantry' | 'ranged' | 'cavalry' | 'siege' | 'covert';
  description: string;
  attack: number;
  defense: number;
  speed: number;
  lootCapacity: number;
  cost: Resources;
  trainingTimeSeconds: number;
  upkeepFoodPerHour: number;
  requiredBuildingLevel: { building: BuildingType; level: number };
}

export interface TrainingQueueItem {
  id: string;
  unitType: UnitType;
  totalCount: number;
  trainedCount: number;
  unitTimeMs: number;
  startTime: number;
  finishTime: number;
}

export type FoodLevel = 'scant' | 'normal' | 'generous' | 'feast';
export type WarFooting = 'peace' | 'alert' | 'war';
export type MilitaryStrategy = 'balanced' | 'offensive' | 'defensive' | 'flank';
export type TacticalFormation = 'balanced' | 'wedge' | 'phalanx' | 'line' | 'envelopment';
export type EquipmentType =
  | 'toledoSteel'
  | 'compositeArmor'
  | 'fireArrows'
  | 'reinforcedShields'
  | 'warhorseBarding';

export interface EquipmentInfo {
  type: EquipmentType;
  name: string;
  category: 'weapons' | 'armor' | 'siege' | 'cavalry';
  description: string;
  icon: string;
  cost: Resources;
  costMultiplier: number;
  bonusDescription: (level: number) => string;
  maxLevel: number;
}

export interface WorkerAllocation {
  farmers: number;
  woodcutters: number;
  miners: number;
  mintWorkers: number;
}

export interface BattleReport {
  id: string;
  timestamp: number;
  targetTerritoryId: string;
  targetName: string;
  victory: boolean;
  attackerCasualties: Partial<Record<UnitType, number>>;
  attackerDead?: Partial<Record<UnitType, number>>;
  attackerWounded?: Partial<Record<UnitType, number>>;
  defenderCasualties: Partial<Record<UnitType, number>>;
  lootCaptured: Resources;
  gloryGained: number;
  summary: string;
}

export interface SpyReport {
  id: string;
  timestamp: number;
  targetTerritoryId: string;
  targetName: string;
  success: boolean;
  detected: boolean;
  enemyGarrison?: Partial<Record<UnitType, number>>;
  enemyResources?: Resources;
  wallLevel?: number;
  summary: string;
}

export interface Territory {
  id: string;
  name: string;
  x: number;
  y: number;
  zone: string;
  type: 'barbarian' | 'kingdom' | 'abandoned' | 'resource_sanctuary' | 'player_castle';
  defenseLevel: number;
  garrison: Partial<Record<UnitType, number>>;
  loot: Resources;
  gloryReward: number;
  isConquered: boolean;
  ownerName?: string;
  ownerUserId?: string;
  ownerCivilization?: CivilizationId;
  castleName?: string;
  population?: number;
  isRealPlayer?: boolean;
  distance?: number;
  description: string;
}

export type PvPChallengeStatus = 'pending' | 'accepted' | 'declined' | 'completed' | 'cancelled';

export interface PvPChallenge {
  id: string;
  challengerId: string;
  challengerKingdomName: string;
  challengerCastleName: string;
  challengerCivilization: CivilizationId;
  challengerGlory: number;
  defenderId: string;
  defenderKingdomName: string;
  defenderCastleName: string;
  defenderCivilization: CivilizationId;
  defenderGlory: number;
  status: PvPChallengeStatus;
  scheduledTime: number;
  scheduledDateLabel: string;
  preparationHours: number;
  goldStake: number;
  message: string;
  replyMessage?: string;
  distance: number;
  createdAt: number;
  updatedAt: number;
  battleReport?: BattleReport;
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  category: 'construction' | 'economy' | 'military' | 'expansion';
  targetValue: number;
  currentValue: number;
  rewardGlory: number;
  rewardResources: Partial<Resources>;
  isCompleted: boolean;
  isClaimed: boolean;
}

export interface PopulationHistoryPoint {
  month: string;
  year?: number;
  population: number;
  capacity: number;
  military: number;
  recruits: number;
  growthRate?: number;
}

export interface Kingdom {
  id: string;
  userId?: string;
  ownerUid?: string;
  kingdomName: string;
  castleName: string;
  civilization: CivilizationId;
  createdAt: number;
  lastTickTimestamp: number;
  lastUpdated?: number;
  gloryPoints: number;
  seasonNumber: number;
  resources: Resources;
  taxRate: number;
  foodLevel: FoodLevel;
  warFooting: WarFooting;
  militaryStrategy: MilitaryStrategy;
  formation: TacticalFormation;
  equipment: Record<EquipmentType, number>;
  workerAllocation: WorkerAllocation;
  buildings: Record<BuildingType, number>;
  technologies: Record<TechType, number>;
  army: Record<UnitType, number>;
  woundedArmy?: Partial<Record<UnitType, number>>;
  constructionQueue: ConstructionQueueItem[];
  researchQueue: ResearchQueueItem[];
  trainingQueue: TrainingQueueItem[];
  battleReports: BattleReport[];
  spyReports: SpyReport[];
  conqueredTerritories: string[];
  claimedChallenges: string[];
  population: number;
  populationHistory?: PopulationHistoryPoint[];
}
