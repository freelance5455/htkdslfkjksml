export type QuizLanguage = 'English' | 'Hindi' | 'Marathi';

export type QuizDifficulty = 'Beginner' | 'Intermediate' | 'Advanced';

export interface QuizQuestionContent {
  question: string;
  options: string[]; // Exactly 4 options
  correctAnswer: number; // 0, 1, 2, or 3
  explanation: string;
}

export interface QuizQuestion {
  id: string;
  content: Record<QuizLanguage, QuizQuestionContent>;
}

export interface QuizCategoryMeta {
  id: string;
  emoji: string;
  iconBg: string;
  badgeBg: string;
  nameEn: string;
  nameHi: string;
  nameMr: string;
  descriptionEn: string;
  descriptionHi: string;
  descriptionMr: string;
}

export interface QuizLevelMeta {
  level: QuizDifficulty;
  emoji: string;
  badgeColor: string;
  totalQuestions: number;
  estimatedMinutes: number;
  nameEn: string;
  nameHi: string;
  nameMr: string;
}

export interface QuizResultRecord {
  id: string;
  categoryId: string;
  categoryName: string;
  level: QuizDifficulty;
  score: number;
  totalQuestions: number;
  percentage: number;
  correctAnswers: number;
  wrongAnswers: number;
  timeTakenSeconds: number;
  performanceRating: 'Excellent' | 'Very Good' | 'Good' | 'Needs Improvement';
  completedAt: string; // ISO string
}

export interface UserQuizProgress {
  completedQuizzesCount: number;
  highestScorePercentage: number;
  averageScorePercentage: number;
  totalQuizTimeSeconds: number;
  lastAttempt?: {
    quizTitle: string;
    scorePercentage: number;
    completedAt: string;
  };
  quizHistory: QuizResultRecord[];
}
