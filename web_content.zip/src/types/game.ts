/**
 * Nông Trại Diệu Kỳ (Pixel Farm RPG) - Types & Models
 */

export type Tier = 1 | 2 | 3 | 4 | 5;

export type TimeOfDay = 'dawn' | 'day' | 'golden' | 'dusk' | 'night' | 'midnight';

export type WeatherType = 'sunny' | 'rainy' | 'foggy' | 'stormy' | 'rainbow';

export type ZoneId = 1 | 2 | 3 | 4 | 5 | 6 | 7;

export type SpeciesCategory =
  | 'crop_grain'
  | 'crop_vegetable'
  | 'crop_flower'
  | 'crop_herb'
  | 'fruit_tree'
  | 'mushroom'
  | 'animal'
  | 'aquatic'
  | 'bee';

export interface Species {
  id: string;
  name: string;
  category: SpeciesCategory;
  tier: Tier;
  icon: string;
  description: string;
  growthTime: number; // in seconds (for game simulation)
  unlockLevel: number;
  seedBuyPrice: number; // Gold to buy seed/young (0 if bred only)
  harvestProductId: string;
  harvestProductName: string;
  harvestProductIcon: string;
  harvestBaseYield: number;
  baseSellPrice: number;
  baseExp: number;
  favoriteFoodId?: string; // for animals/aquatic
  breedingParents?: [string, string]; // for Tier 4 and Tier 5 breeding
  breedingCatalysts?: { itemId: string; count: number }[];
  breedingMasteryRequired?: number; // e.g. 20-50 harvests
  specialBuff?: string;
}

export interface SoilPlot {
  id: number;
  unlocked: boolean;
  tilled: boolean;
  watered: boolean;
  fertilizerType: 'none' | 'organic' | 'growth' | 'crystal'; // none, hữu cơ +50-100%, kích thích tốc độ, tinh thể đột biến
  plantedSpeciesId: string | null;
  plantedAt: number | null; // timestamp ms
  readyAt: number | null; // timestamp ms
  stage: number; // 0: empty, 1: seed, 2: growing, 3: ripe
  isGoldenQuality?: boolean;
}

export interface AnimalPen {
  speciesId: string;
  count: number; // 1 to 10 max
  hunger: number; // 0 to 100% (must be 100% to produce)
  satisfaction: number; // 0 to 100% (resets on harvest)
  affection: number; // 0 to 100% (permanent, does not reset)
  isPetToday: boolean;
  startedProducingAt: number | null;
  readyAt: number | null;
  butlerActive: boolean;
  lastButlerActionAt?: number;
}

export interface AquaticTank {
  speciesId: string;
  count: number; // 1 to 10 max
  waterZone: 'freshwater' | 'shallow_sea' | 'moonlight_lake';
  hunger: number; // 0 to 100%
  favoriteFoodLevel: number; // 0 to 100% (milestones 25%, 50%, 75%, 100% -> +20% yield)
  startedProducingAt: number | null;
  readyAt: number | null;
}

export interface OrchardSlot {
  id: number;
  type: 'fruit_tree' | 'mushroom';
  speciesId: string | null;
  plantedAt: number | null;
  readyAt: number | null;
  isRipe: boolean;
}

export interface BeeHive {
  id: number;
  beeSpeciesId: string; // 10 species
  startedProducingAt: number;
  readyAt: number;
  isReady: boolean;
}

export interface CraftingRecipe {
  id: string;
  name: string;
  machineId: MachineType;
  tier: Tier;
  icon: string;
  description: string;
  inputs: { itemId: string; count: number }[];
  outputItemId: string;
  outputCount: number;
  craftTimeSeconds: number;
  expPerUnit: number;
  unlockLevel: number;
  isSpecial?: boolean;
  requiredShipFormula?: boolean;
}

export type MachineType =
  | 'bakery'
  | 'juice_jam'
  | 'dairy'
  | 'loom'
  | 'brewery'
  | 'perfume'
  | 'alchemy'
  | 'jewelry'
  | 'gourmet'
  | 'feed_mixer'
  | 'fertilizer_tower';

export interface ActiveCraftBatch {
  id: string;
  recipeId: string;
  quantity: number;
  startedAt: number;
  finishAt: number;
  expTotal: number;
}

export interface MerchantOrder {
  id: string;
  itemId: string;
  itemName: string;
  itemIcon: string;
  countRequired: number;
  rewardGold: number;
  rewardJade: number;
  rewardExpRatio: number; // 0.08 to 0.15 of current level exp
  fulfilled: boolean;
}

export interface MerchantShip {
  docked: boolean;
  arrivedAt: number;
  leavesAt: number;
  nextArrivalAt: number;
  orders: MerchantOrder[];
  droppedFormulaId: string | null;
  formulaClaimed: boolean;
}

export interface InventoryItem {
  id: string;
  name: string;
  categoryTab: 1 | 2 | 3 | 4 | 5 | 6;
  tier: Tier;
  icon: string;
  count: number;
  locked: boolean;
  sellPrice: number;
  isGoldenQuality?: boolean;
}

export interface PlayerStats {
  level: number;
  currentExp: number;
  gold: number;
  jade: number;
  timeSpeed: 1 | 2 | 5 | 10;
  isRealtimeSync: boolean;
  keepTenUnitsActive: boolean; // Auto keep 10 units when bulk selling
  simulatedTimeMs: number;
  weather: WeatherType;
  timeOfDay: TimeOfDay;
  lastSavedTimestamp: number;
  unlockedRecipes: string[];
  speciesMastery: Record<string, number>; // speciesId -> total harvest count
  beeGachaPityCount: number; // 0 to 5, at 5 (6th try) guaranteed 100%
  aquaticAeratorOn: boolean;
  aquaticFilterDurability: number; // 0 to 100
  aquaticMineralMudReady: number; // collected sludge
  claimedAlmanacMilestones: number[]; // e.g. [10, 25, 50, 75, 100]
}

export interface OfflineReport {
  awaySeconds: number;
  cropsGrown: number;
  animalsReady: number;
  aquaticsReady: number;
  orchardHarvests: number;
  craftsCompleted: number;
  butlerHarvests: number;
  expGained: number;
  goldGained: number;
  notes: string[];
}
