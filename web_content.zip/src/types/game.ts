/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type * as THREE from 'three';

export type GameState = 'LOADING' | 'TITLE' | 'PLAYING' | 'PAUSED' | 'VICTORY' | 'GAMEOVER';

export type WeaponType = 'PISTOL' | 'RIFLE' | 'SHOTGUN';

export interface WeaponStats {
  id: WeaponType;
  name: string;
  damage: number;
  fireRate: number; // shots per second
  magSize: number;
  currentMag: number;
  reserveAmmo: number;
  maxReserve: number;
  reloadTime: number; // seconds
  range: number;
  spread: number;
  pellets: number;
  automatic: boolean;
}

export type ZombieType = 'WALKER' | 'RUNNER' | 'BRUTE';

export interface ZombieEntity {
  id: string;
  type: ZombieType;
  mesh: THREE.Group;
  health: number;
  maxHealth: number;
  speed: number;
  damage: number;
  attackRange: number;
  attackCooldown: number;
  lastAttackTime: number;
  state: 'IDLE' | 'CHASING' | 'ATTACKING' | 'HIT' | 'DEAD';
  hitTimer: number;
  deathTimer: number;
  rotationY: number;
  animTime: number;
  height: number;
}

export interface PickupEntity {
  id: string;
  type: 'AMMO' | 'MEDKIT' | 'SAMPLE' | 'WEAPON_RIFLE' | 'WEAPON_SHOTGUN';
  mesh: THREE.Group;
  position: [number, number, number];
  collected: boolean;
  pulseTime: number;
}

export interface ExplosiveBarrelEntity {
  id: string;
  mesh: THREE.Group;
  position: [number, number, number];
  health: number;
  exploded: boolean;
}

export interface ObjectiveStep {
  id: string;
  title: string;
  description: string;
  current: number;
  target: number;
  completed: boolean;
  icon: 'crosshair' | 'box' | 'radio' | 'shield' | 'zap';
}

export interface ParticleEffect {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  color: THREE.Color;
  size: number;
  life: number;
  maxLife: number;
}

export interface GameSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  sfxVolume: number;
  mouseSensitivity: number;
  graphicsQuality: 'LOW' | 'MEDIUM' | 'HIGH';
  showTouchControls: boolean;
}
