export type TimeSlotId = 'morning' | 'afternoon' | 'primetime' | 'latenight';

export interface TimeSlotConfig {
  id: TimeSlotId;
  label: string;
  timeRange: string;
  idealGenres: ProgramGenre[];
  audiencePotential: number; // Multiplier on overall TV watchers at that hour
  icon: string;
}

export type ProgramGenre =
  | 'novela'
  | 'jornalismo'
  | 'auditorio'
  | 'reality'
  | 'esporte'
  | 'desenho'
  | 'fofoca'
  | 'filme';

export interface GenreDetails {
  id: ProgramGenre;
  name: string;
  description: string;
  baseCost: number;
  basePotential: number;
  bestSlots: TimeSlotId[];
  icon: string;
  color: string;
}

export interface Talent {
  id: string;
  name: string;
  role: 'Apresentador' | 'Âncora' | 'Atriz / Ator' | 'Humorista' | 'Comentarista';
  charisma: number; // 1-100
  reputation: number; // 1-100
  salary: number; // Weekly R$
  scandalRisk: number; // % chance of triggering backstage events
  isHired: boolean;
  avatarBg: string;
  avatarEmoji: string;
  catchphrase: string;
}

export interface TVProgram {
  id: string;
  title: string;
  genre: ProgramGenre;
  assignedSlot: TimeSlotId | null;
  assignedTalentId: string | null;
  quality: number; // 1-100
  hype: number; // 1-100
  episodesAired: number;
  productionCost: number;
  seasonTotal: number;
  ratingAverage: number;
  isLive: boolean;
  activeScriptLevel: number;
  isLicensed?: boolean;
  sourceChannelId?: string; // If produced by a subsidiary channel (e.g. canal de notícias pago)
  sourceChannelName?: string;
}

export interface DayScheduleGrid {
  morning: string | null;
  afternoon: string | null;
  primetime: string | null;
  latenight: string | null;
}

export type WeeklySchedule = Record<number, DayScheduleGrid>;
export type WeeklySponsors = Record<number, DayScheduleGrid>;

export type SubsidiaryChannelType =
  | 'noticias'
  | 'esportes'
  | 'infantil'
  | 'filmes'
  | 'jovem';

export interface SubsidiaryChannel {
  id: string;
  name: string;
  type: SubsidiaryChannelType;
  isUnlocked: boolean;
  unlockCost: number;
  subscribers: number;
  dailyRevenuePerSubscriber: number;
  qualityLevel: number; // 1-5
  upgradeCost: number;
  description: string;
  tagline: string;
  iconEmoji: string;
  color: string;
  badge: string;
  synergyPerks: string[];
  syndicatedShows: TVProgram[];
  isSimulcastActive?: boolean;
}

export interface PurchasableFormat {
  id: string;
  title: string;
  genre: ProgramGenre;
  originCountry: string;
  licenseCost: number;
  perSlotCost: number;
  initialQuality: number;
  description: string;
  episodesCount: number;
  isPurchased: boolean;
}

export interface StationDirector {
  id: string;
  role:
    | 'Diretor de Programação'
    | 'Diretor Comercial'
    | 'Diretor de Jornalismo'
    | 'Diretor Artístico'
    | 'Diretor de Teledramaturgia & Séries';
  name: string;
  description: string;
  salary: number; // daily salary
  isHired: boolean;
  isAutoActive: boolean;
  efficiency: number; // 1-100
  avatarEmoji: string;
}

export interface ProductionProposal {
  id: string;
  title: string;
  genre: ProgramGenre;
  synopsis: string;
  directorName: string;
  estimatedQuality: number;
  productionCost: number;
  seasonTotal: number;
  recommendedSlot: TimeSlotId;
  suggestedTalentId: string | null;
  hype: number;
  setupCost: number;
}

export interface Sponsor {
  id: string;
  name: string;
  productType: string;
  payoutPerSlot: number;
  targetRating: number; // min points in IBOPE required
  contractDaysRemaining: number;
  penaltyOnFail: number;
  isActive: boolean;
  logoColor: string;
  assignedSlot: TimeSlotId | null;
}

export interface StationUpgrade {
  id: string;
  name: string;
  category: 'antena' | 'estudio' | 'tecnologia' | 'jornalismo';
  level: number;
  maxLevel: number;
  cost: number;
  description: string;
  bonusText: string;
  icon: string;
}

export interface RivalNetwork {
  id: string;
  name: string;
  color: string;
  rating: number;
  currentShow: string;
  share: number;
}

export interface StationEventChoice {
  text: string;
  effectDescription: string;
  apply: (state: any) => { message: string; moneyDelta?: number; ibopeDelta?: number; repDelta?: number };
}

export interface StationEvent {
  id: string;
  title: string;
  description: string;
  category: 'breaking' | 'backstage' | 'sponsor' | 'tech';
  icon: string;
  choices: StationEventChoice[];
}

export interface DayReport {
  day: number;
  weekday: string;
  revenue: number;
  expenses: number;
  netProfit: number;
  avgIbope: number;
  peakIbope: number;
  ranking: number;
  notableEvent?: string;
}

export interface FinancialStats {
  commercialRevenue: number;
  licensingCosts: number;
  productionCosts: number;
  payrollCosts: number;
  directorSalaries: number;
  penaltiesPaid: number;
  netProfit: number;
}
