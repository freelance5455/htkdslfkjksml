export type FruitType = 'none' | 'rubber' | 'flame' | 'light' | 'magma' | 'ice' | 'buddha';

export interface FruitSkill {
  id: string;
  name: string;
  key: 'Z' | 'X' | 'C' | 'V' | 'F';
  requiredMastery: number;
  energyCost: number;
  cooldown: number; // in seconds
  description: string;
  icon: string;
  damageMultiplier: number;
  isMobility?: boolean;
}

export interface FruitData {
  id: FruitType;
  name: string;
  rarity: 'Common' | 'Uncommon' | 'Rare' | 'Legendary' | 'Mythical';
  color: string;
  glowColor: string;
  price: number;
  description: string;
  skills: FruitSkill[];
}

export type WeaponType = 'combat' | 'katana' | 'dual_katana' | 'saber';

export interface WeaponData {
  id: WeaponType;
  name: string;
  type: 'melee' | 'sword';
  damage: number;
  price: number;
  description: string;
  color: string;
}

export interface PlayerStats {
  level: number;
  exp: number;
  maxExp: number;
  beli: number;
  gems: number;
  statPoints: number;
  meleeStat: number;
  defenseStat: number;
  swordStat: number;
  fruitStat: number;
  
  maxHealth: number;
  health: number;
  maxEnergy: number;
  energy: number;

  equippedFruit: FruitType;
  fruitMastery: number;
  equippedWeapon: WeaponType;
  
  hasHaki: boolean;
  hakiActive: boolean;
  observationActive: boolean;
  observationDodges: number;
  maxObservationDodges: number;
  isBuddhaTransformed: boolean;
  
  inventory: Array<{
    id: string;
    type: 'fruit' | 'weapon';
    itemKey: string;
    name: string;
    rarity?: string;
  }>;
}

export interface Quest {
  id: string;
  islandId: string;
  npcName: string;
  title: string;
  targetEnemyType: string;
  targetCount: number;
  currentCount: number;
  rewardBeli: number;
  rewardExp: number;
  minLevel: number;
  isActive: boolean;
  isCompleted: boolean;
}

export interface Enemy {
  id: string;
  name: string;
  type: string;
  level: number;
  maxHealth: number;
  health: number;
  damage: number;
  bounty: number;
  expReward: number;
  beliReward: number;
  respawnTime: number;
  spawnPoint: { x: number; y: number; z: number };
  position: { x: number; y: number; z: number };
  rotationY: number;
  isBoss?: boolean;
  attackCooldown: number;
  aggroRange: number;
  attackRange: number;
  state: 'idle' | 'chase' | 'attack' | 'dead';
  mesh?: any;
  deadTimer?: number;
}

export interface FloatingDamage {
  id: string;
  text: string;
  x: number;
  y: number;
  z: number;
  vy: number;
  opacity: number;
  color: string;
  isCrit: boolean;
  type?: 'outgoing' | 'incoming' | 'dodge' | 'heal';
  createdAt?: number;
}

export interface MinimapObjective {
  title: string;
  targetType: string;
  x: number;
  z: number;
  distance: number;
}

export interface MinimapData {
  playerPos: { x: number; y: number; z: number };
  playerYaw: number;
  currentIsland: IslandInfo | null;
  questObjective: MinimapObjective | null;
  enemies: Array<{ id: string; x: number; z: number; isBoss?: boolean; isDead: boolean }>;
  boatPos: { x: number; z: number } | null;
}

export interface BossTargetInfo {
  id: string;
  name: string;
  type: string;
  level: number;
  health: number;
  maxHealth: number;
  isBoss: boolean;
  distance: number;
  islandName?: string;
}

export interface IslandInfo {
  id: string;
  name: string;
  levelReq: string;
  x: number;
  z: number;
  radius: number;
  color: string;
  description: string;
  hasFruitDealer?: boolean;
  hasBoatDealer?: boolean;
}
