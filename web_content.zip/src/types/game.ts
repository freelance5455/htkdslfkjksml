export type Rarity = 'common' | 'rare' | 'epic' | 'legendary' | 'mythic';

export type GraphicsQuality = 'low' | 'medium' | 'high' | 'maximum';

export type MenuTab =
  | 'home'
  | 'worlds'
  | 'heroes'
  | 'generator'
  | 'shop'
  | 'inventory'
  | 'skills'
  | 'quests'
  | 'achievements'
  | 'settings';

export type WeaponVisualType =
  | 'katana'
  | 'glaive'
  | 'dual_plasma'
  | 'frost_halberd'
  | 'phoenix_greatsword'
  | 'infinity_scythe';

export type HeroHairStyle =
  | 'spiky_shinobi'
  | 'elven_braid'
  | 'cyber_bob'
  | 'flowing_empress'
  | 'dragon_wild'
  | 'astral_sovereign';

export interface HeroVisualPalette {
  hairMain: string;
  hairTip: string;
  eyeColor: string;
  skinTone: string;
  coatPrimary: string;
  coatSecondary: string;
  trimGold: string;
  scarfColor: string;
  weaponGlow: string;
  weaponCore: string;
  hairStyle: HeroHairStyle;
  weaponType: WeaponVisualType;
  hasElfEars?: boolean;
  hasTiara?: boolean;
  hasCyberVisor?: boolean;
  hasInfinityHalo?: boolean;
}

export interface HeroAbilityDef {
  name: string;
  description: string;
  cooldown: number; // seconds
  damageMultiplier: number;
  effectType:
    | 'crescent_wave'
    | 'eclipse_rush'
    | 'spirit_arrows'
    | 'verdant_hurricane'
    | 'overdrive_pulse'
    | 'neon_judgement'
    | 'permafrost_lance'
    | 'absolute_zero'
    | 'inferno_breaker'
    | 'dragon_supernova'
    | 'void_singularity'
    | 'infinity_requiem';
}

export interface HeroUnlockRequirement {
  coinsCost: number;
  requiredWorldCleared?: number; // 1..6
  requiredQuestsCompleted?: number;
  requiredPlayerLevel?: number;
  requiredAchievements?: number;
  summaryText: string;
}

export interface HeroStats {
  maxHp: number;
  attack: number;
  defense: number;
  critChance: number; // 0.05 = 5%
  cooldownReduction: number; // 0..0.45
  moveSpeed: number;
}

export interface HeroDef {
  id: string;
  name: string;
  title: string;
  rarity: Rarity;
  element: string;
  fightingStyle: string;
  lore: string;
  portrait: string;
  palette: HeroVisualPalette;
  baseStats: HeroStats;
  skill1: HeroAbilityDef;
  skill2: HeroAbilityDef; // Ultimate
  passiveName: string;
  passiveDescription: string;
  unlockReq: HeroUnlockRequirement;
  baseUpgradeCost: number;
}

export type ItemCategory =
  | 'weapon'
  | 'armor'
  | 'accessory'
  | 'outfit'
  | 'pet'
  | 'cosmetic'
  | 'consumable';

export interface GameItemDef {
  id: string;
  name: string;
  category: ItemCategory;
  rarity: Rarity;
  description: string;
  priceCoins: number;
  iconSymbol: string;
  accentColor: string;
  statsBonus?: Partial<HeroStats>;
  // For outfits
  outfitColors?: {
    coatPrimary: string;
    coatSecondary: string;
    scarfColor: string;
    trimGold: string;
  };
  // For pets
  petVisual?: {
    bodyColor: string;
    glowColor: string;
    species: 'kitsune' | 'fairy' | 'drake' | 'owl';
    passiveText: string;
  };
  // For cosmetics
  auraStyle?: 'starlight' | 'shadow_flame' | 'golden_runes' | 'sakura';
}

export interface PlatformDef {
  x: number;
  y: number;
  w: number;
  h: number;
  style?: 'ground' | 'floating' | 'secret' | 'bridge';
}

export interface EnemySpawnDef {
  id: string;
  x: number;
  y: number;
  archetype:
    | 'imp'
    | 'wolf'
    | 'treant_elite'
    | 'cyber_drone'
    | 'cyber_hound'
    | 'mecha_elite'
    | 'frost_wisp'
    | 'yeti'
    | 'cryo_elite'
    | 'magma_crawler'
    | 'cinder_wraith'
    | 'obsidian_elite'
    | 'gargoyle'
    | 'phantom_duelist'
    | 'executioner_elite'
    | 'astral_sentinel'
    | 'nebula_seraph'
    | 'void_archon';
  name: string;
  isElite?: boolean;
  patrolMinX: number;
  patrolMaxX: number;
}

export interface HazardDef {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  type: 'thorns' | 'electric_arc' | 'icicles' | 'lava_geyser' | 'void_spikes' | 'cosmic_rift';
  damage: number;
  periodic?: boolean; // turns on/off with warning
}

export interface BossDef {
  id: string;
  name: string;
  title: string;
  maxHp: number;
  attack: number;
  defense: number;
  phases: number; // 2 or 3
  primaryColor: string;
  secondaryColor: string;
  glowColor: string;
  visualType:
    | 'sylvan_warden'
    | 'omega_valkyrie'
    | 'frost_wyrm'
    | 'molten_titan'
    | 'shadow_sovereign'
    | 'chronos_infinitum';
  rewardCoins: number;
  rewardXp: number;
  guaranteedDropItemId?: string;
}

export interface WorldDef {
  id: number; // 1..6
  slug: string;
  name: string;
  subtitle: string;
  description: string;
  recommendedLevel: number;
  musicTrack: 'forest' | 'cyber' | 'frozen' | 'volcanic' | 'shadow' | 'celestial';
  length: number; // total world horizontal length in px
  bossArenaStartX: number;
  skyTop: string;
  skyBottom: string;
  accentColor: string;
  groundColor: string;
  groundTrim: string;
  ambientType: 'fireflies' | 'neon_rain' | 'snow' | 'embers' | 'shadow_ash' | 'starlight';
  platforms: PlatformDef[];
  enemies: EnemySpawnDef[];
  hazards: HazardDef[];
  checkpointX: number;
  checkpointY: number;
  secretChest: {
    x: number;
    y: number;
    rewardCoins: number;
    rewardItemId?: string;
    hint: string;
  };
  boss: BossDef;
  clearRewardCoins: number;
  clearRewardXp: number;
}

export interface QuestDef {
  id: string;
  title: string;
  description: string;
  metric:
    | 'enemiesDefeated'
    | 'bossesDefeated'
    | 'worldsClearedCount'
    | 'secretsFoundCount'
    | 'maxComboReached'
    | 'heroesUnlockedCount'
    | 'skillUpgradesBought'
    | 'coinsEarnedTotal';
  target: number;
  rewardCoins: number;
  rewardXp: number;
  rewardSkillPoints?: number;
}

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  icon: string;
  metric:
    | 'enemiesDefeated'
    | 'bossesDefeated'
    | 'worldsClearedCount'
    | 'secretsFoundCount'
    | 'heroesUnlockedCount'
    | 'playerLevel'
    | 'world6Cleared'
    | 'mythicUnlocked';
  target: number;
  rewardCoins: number;
  rewardSkillPoints: number;
}

export interface SkillUpgradesState {
  attackRank: number;
  defenseRank: number;
  healthRank: number;
  cooldownRank: number;
  specialRank: number;
}

export interface ActiveCheckpointSave {
  worldId: number;
  x: number;
  y: number;
}

export interface SaveData {
  version: number;
  coins: number;
  xp: number;
  playerLevel: number;
  skillPoints: number;
  selectedHeroId: string;
  unlockedHeroIds: string[];
  heroLevels: Record<string, number>;
  skillUpgrades: SkillUpgradesState;
  ownedItemIds: string[];
  potionsCount: number;
  equippedWeaponId: string | null;
  equippedArmorId: string | null;
  equippedAccessoryId: string | null;
  equippedOutfitId: string | null;
  equippedPetId: string | null;
  equippedCosmeticId: string | null;
  unlockedWorldMax: number; // 1..6
  completedWorlds: number[];
  worldStars: Record<number, number>; // 1..3 stars
  secretsFoundWorlds: number[];
  activeCheckpoint: ActiveCheckpointSave | null;
  statsTracker: {
    enemiesDefeated: number;
    bossesDefeated: number;
    maxComboReached: number;
    coinsEarnedTotal: number;
    skillUpgradesBought: number;
  };
  claimedQuestIds: string[];
  claimedAchievementIds: string[];
  settings: {
    musicVolume: number; // 0..1
    sfxVolume: number; // 0..1
    graphicsQuality: GraphicsQuality;
    showTouchControls: boolean;
    touchControlScale: number; // 0.85 .. 1.2
  };
}
