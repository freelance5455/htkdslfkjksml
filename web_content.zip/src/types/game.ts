export type DisciplineId = 'chonk' | 'jump' | 'stack';

export type GameMode = 'hub' | 'countdown' | 'playing' | 'result';

export type AccessoryId = 'none' | 'crown' | 'headband' | 'shades' | 'bowtie';

export interface AccessoryOption {
  id: AccessoryId;
  name: string;
  description: string;
  emoji: string;
}

export interface DisciplineConfig {
  id: DisciplineId;
  code: string;
  title: string;
  shortTitle: string;
  guinnessCategory: string;
  targetScore: number;
  unit: string;
  previousHolder: string;
  previousLocation: string;
  description: string;
  controlsHint: string;
  accentColor: string;
  iconName: 'scale' | 'rocket' | 'layers';
}

export interface RecordEntry {
  disciplineId: DisciplineId;
  bestScore: number;
  isRecordBroken: boolean;
  brokenAt: string | null;
  attempts: number;
  rankTitle: string;
}

export interface FloatingPopup {
  id: number;
  text: string;
  subtext?: string;
  x: number; // percentage 10..90
  y: number; // percentage 15..80
  color: 'gold' | 'emerald' | 'crimson' | 'white';
}

export interface LiveTelemetry {
  currentScore: number;
  targetScore: number;
  timeLeft: number; // seconds or -1 if untimed/phase-based
  combo: number;
  phaseText: string;
  subStatusText: string;
  /** For Jump discipline power meter (0..1) */
  powerGauge?: number;
  /** For Jump discipline phase ('charge' | 'flight' | 'landed') */
  jumpPhase?: 'charge' | 'flight' | 'landed';
  /** For Stack discipline tower tilt (-1..1) */
  towerTilt?: number;
  /** For Stack discipline current item name */
  nextItemName?: string;
  /** For Stack discipline remaining lives/misses allowed */
  livesLeft?: number;
}
