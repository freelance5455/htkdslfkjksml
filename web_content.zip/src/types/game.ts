/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type CharacterId = 'jake' | 'tricky' | 'rex';

export type PowerUpType = 'magnet' | 'jetpack' | 'sneakers' | 'multiplier' | 'shield';

export type GameState = 'menu' | 'playing' | 'paused' | 'gameover';

export interface CharacterDef {
  id: CharacterId;
  name: string;
  tagline: string;
  cost: number;
  unlocked: boolean;
  colors: {
    skin: number;
    shirt: number;
    pants: number;
    shoes: number;
    hat: number;
    hair: number;
    accent: number;
  };
  bonusStat: string;
}

export interface ActivePowerUp {
  type: PowerUpType;
  duration: number;
  remaining: number;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  target: number;
  progress: number;
  completed: boolean;
  claimed: boolean;
  rewardCoins: number;
  type: 'coins_single' | 'distance_single' | 'jump_barriers' | 'slide_obstacles' | 'collect_powerups' | 'score_single';
}

export interface GameSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  showTouchControls: boolean;
  highQuality: boolean;
}

export interface PlayerStats {
  totalCoins: number;
  highScore: number;
  bestDistance: number;
  gamesPlayed: number;
  selectedCharacter: CharacterId;
  unlockedCharacters: CharacterId[];
  missions: Mission[];
}

export interface RunSummary {
  score: number;
  coins: number;
  distance: number;
  multiplier: number;
  newHighScore: boolean;
  completedMissions: string[];
}
