export type CellColor = 
  | 'cyan' 
  | 'blue' 
  | 'purple' 
  | 'emerald' 
  | 'amber' 
  | 'ruby' 
  | 'coral'
  | 'violet'
  | 'prism';

export type GameMode = 'CLASSIC' | 'RUSH' | 'BOMB';

export type ThemeId = 'cosmic' | 'cyber' | 'emerald' | 'supernova';

export interface GridCell {
  filled: boolean;
  color: CellColor | null;
  clearing?: boolean;
  clearTimestamp?: number;
  isBomb?: boolean;
  bombCountdown?: number;
  isFrozen?: boolean;
}

export interface ShapeDefinition {
  id: string;
  name: string;
  matrix: number[][]; // 1 = block, 0 = empty
  color: CellColor;
  width: number;
  height: number;
  cellCount: number;
}

export interface PlacedPieceItem {
  shape: ShapeDefinition;
  used: boolean;
  id: string;
}

export interface DragState {
  piece: ShapeDefinition;
  pieceIndex: number;
  initialX: number;
  initialY: number;
  currentX: number;
  currentY: number;
  gridRow: number | null;
  gridCol: number | null;
  isValidPlacement: boolean;
  clearedLinesPreview: { rows: number[]; cols: number[] };
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: number;
  progress?: number;
  maxProgress?: number;
}

export interface GameStats {
  highScore: number;
  rushHighScore: number;
  bombHighScore: number;
  gamesPlayed: number;
  totalLinesCleared: number;
  highestCombo: number;
  totalBlocksPlaced: number;
  bombsDefused: number;
  perfectClears: number;
  achievements: Achievement[];
}

export type BlockVisualEffect = 'crystalline' | 'neon' | 'metallic' | 'obsidian';

export interface AudioSettings {
  sfxVolume: number;
  sfxEnabled: boolean;
  musicVolume: number;
  musicEnabled: boolean;
  touchOffsetEnabled: boolean;
  hapticsEnabled: boolean;
  activeTheme: ThemeId;
  activeBlockStyle: BlockVisualEffect;
}

export interface ScoreFloater {
  id: string;
  text: string;
  x: number;
  y: number;
  color: string;
  isCombo?: boolean;
  subtext?: string;
}

export type PowerUpType = 'HAMMER' | 'REROLL' | 'BOMB_BLAST';

export interface PowerUpState {
  hammerCount: number;
  rerollCount: number;
  bombBlastCount: number;
  activePowerUp: PowerUpType | null;
}

export type ScreenState = 'HOME' | 'PLAY' | 'HOW_TO_PLAY' | 'SETTINGS' | 'ACHIEVEMENTS';
