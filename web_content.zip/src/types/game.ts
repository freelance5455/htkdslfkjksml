export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export interface Point {
  x: number; // grid col (0 .. gridCols - 1)
  y: number; // grid row (0 .. gridRows - 1)
}

export interface Arrow {
  id: string;
  points: Point[]; // Sequence of grid vertices from tail to head
  row: number; // head y
  col: number; // head x
  direction: Direction; // heading of the arrowhead at points[points.length - 1]
  isEscaping?: boolean;
  isHinted?: boolean;
  isInvalid?: boolean;
  recoilOffset?: { x: number; y: number };
}

export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced' | 'Master' | 'Ultimate';

export interface Level {
  id: number;
  gridRows: number;
  gridCols: number;
  arrows: Arrow[];
  difficulty: Difficulty;
  optimalMoves: number;
  parTimeSec: number;
}

export interface MoveStep {
  arrowId: string;
  direction: Direction;
}

export interface LevelProgress {
  stars: number;
  bestTimeSec: number;
  bestMoves: number;
  completedAt: string;
}

export interface GameSettings {
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  animationSpeed: 'normal' | 'fast';
  contrastTheme: 'paper_light' | 'pure_black' | 'charcoal';
}

export interface UserProgress {
  currentLevel: number;
  completedLevels: Record<number, LevelProgress>;
  totalStars: number;
  totalScore: number;
  settings: GameSettings;
  lastUpdated: string;
  pendingSync?: boolean;
}

export interface AuthUser {
  uid: string;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
  isGuest: boolean;
}

export interface GameStats {
  moves: number;
  lives: number;
  hintsUsed: number;
  timeSec: number;
}
