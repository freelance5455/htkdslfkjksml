export type WorldId =
  | 'tower'
  | 'lava'
  | 'plaza'
  | 'obby-ez'
  | 'santai'
  | 'indo-voice'
  | 'indo-hangout'
  | 'pickbux-gratis'
  | 'custom';

export type LightingPreset = 'day' | 'sunset' | 'night';

export type CameraMode = 'third' | 'first';

export type HatStyle =
  | 'cap'
  | 'helmet'
  | 'crown'
  | 'party'
  | 'domino'
  | 'beanie'
  | 'headphones'
  | 'wizard'
  | 'horns'
  | 'none';

export type ShoeStyle = 'none' | 'sneakers' | 'boots' | 'gold' | 'cyber' | 'flame';

export type AccessoryEffect = 'none' | 'fire' | 'lightning' | 'galaxy' | 'rainbow' | 'sparkle';

export type AvatarBgStyle = 'studio' | 'dark' | 'sunset' | 'ocean';

export type IdleAnimStyle = 'default' | 'cool' | 'bounce' | 'ninja' | 'hero' | 'sleepy';

export type WalkAnimStyle = 'default' | 'ninja' | 'robot' | 'hero' | 'bouncy';

export type JumpAnimStyle = 'default' | 'flip' | 'superhero' | 'float';

export type HairStyle =
  | 'none'
  | 'spiky'
  | 'messy'
  | 'long'
  | 'ponytail'
  | 'mohawk'
  | 'bob'
  | 'curly';

export type UgcSlot = 'head' | 'hair' | 'back' | 'hand' | 'aura';

export interface UgcItemAttachment {
  id: string;
  name: string;
  slot: UgcSlot;
  parts: StudioPart[];
}

export type MakeupStyle = 'none' | 'blush' | 'lipstick' | 'goth' | 'stars' | 'kawaii';

export type FootTrailStyle = 'none' | 'fire' | 'lightning' | 'hearts' | 'pixel' | 'rainbow' | 'galaxy';

export type FaceExpression =
  | 'auto'
  | 'happy'
  | 'cool'
  | 'angry'
  | 'surprised'
  | 'wink'
  | 'heart_eyes'
  | 'sleepy';

export type EmoteId = 'wave' | 'dance' | 'clap' | 'spin' | 'salute' | 'sit';

export interface UserAccount {
  id: string;
  username: string;
  email: string;
  password: string;
}

export interface AvatarConfig {
  skinColor: string;
  shirtColor: string;
  pantsColor: string;
  hairStyle: HairStyle;
  hairColor: string;
  hatColor: string;
  hatStyle: HatStyle;
  shoeColor: string;
  shoeStyle: ShoeStyle;
  effect: AccessoryEffect;
  footTrail?: FootTrailStyle;
  faceExpression?: FaceExpression;
  makeup: MakeupStyle;
  bodyScale: number;
  hasWings: boolean;
  hasSword: boolean;
  headless: boolean;
  bgStyle: AvatarBgStyle;
  idleAnim: IdleAnimStyle;
  walkAnim: WalkAnimStyle;
  jumpAnim: JumpAnimStyle;
  ugcAttachment?: UgcItemAttachment | null;
}

export interface GameStats {
  stage: number;
  totalStages: number;
  coins: number;
  totalCoins: number;
  elapsedSeconds: number;
  falls: number;
  completed: boolean;
  health: number;
}

export type PlatformKind = 'normal' | 'moving' | 'bounce' | 'checkpoint' | 'finish' | 'hazard' | 'grass' | 'road';

export interface PlatformDef {
  id: string;
  x: number;
  y: number;
  z: number;
  w: number;
  h: number;
  d: number;
  color: string;
  kind: PlatformKind;
  stageIndex?: number;
  moveAxis?: 'x' | 'y' | 'z';
  moveRange?: number;
  moveSpeed?: number;
  movePhase?: number;
  bounceVelocity?: number;
  rx?: number;
  ry?: number;
  rz?: number;
}

export interface SweeperDef {
  id: string;
  x: number;
  y: number;
  z: number;
  length: number;
  thickness: number;
  speed: number;
  color: string;
}

export interface CoinDef {
  id: string;
  x: number;
  y: number;
  z: number;
}

export interface PropTreeDef {
  x: number;
  y: number;
  z: number;
  scale: number;
  leafColor: string;
}

export interface PropBuildingDef {
  x: number;
  y: number;
  z: number;
  w: number;
  h: number;
  d: number;
  wallColor: string;
  roofColor: string;
}

export interface WorldConfig {
  id: WorldId;
  name: string;
  subtitle: string;
  creator: string;
  likes: string;
  activePlayers: number;
  category: 'trending' | 'new' | 'popular' | 'hangout';
  thumbTheme: 'rainbow' | 'lava' | 'plaza' | 'pickbux' | 'voice' | 'hangout' | 'santai' | 'obbyez';
  spawn: [number, number, number];
  fallY: number;
  seaY: number;
  seaColor: string;
  seaEmissive: string;
  isLavaSea: boolean;
  platforms: PlatformDef[];
  sweepers: SweeperDef[];
  coins: CoinDef[];
  trees: PropTreeDef[];
  buildings: PropBuildingDef[];
}

export type CatalogCategory =
  | 'bundle'
  | 'hair'
  | 'hat'
  | 'ugc'
  | 'idle'
  | 'walk'
  | 'jump'
  | 'emote'
  | 'makeup'
  | 'shirt'
  | 'pants'
  | 'shoes'
  | 'accessory'
  | 'trail'
  | 'expression'
  | 'background';

export interface CatalogItem {
  id: string;
  name: string;
  creator: string;
  verified?: boolean;
  price: number;
  category: CatalogCategory;
  letter: string;
  accentColor: string;
  badgeText?: string;
  description?: string;
  applyPatch: Partial<AvatarConfig>;
  unlockEmoteId?: EmoteId;
  previewMode?: 'idle' | 'walk' | 'jump' | 'emote';
  previewEmote?: EmoteId;
  ugcAttachment?: UgcItemAttachment;
  tradable?: boolean;
}

export interface NotificationItem {
  id: string;
  text: string;
  time: string;
  read: boolean;
}

export interface FriendProfile {
  id: string;
  name: string;
  username: string;
  joined: string;
  friendsCount: number;
  followersCount: number;
  followingCount: number;
  online: boolean;
  avatar: AvatarConfig;
  ownedAccessoryIds?: string[];
  messages: { sender: 'them' | 'me'; text: string; time: string }[];
}

export interface CommunityItem {
  id: string;
  name: string;
  members: number;
  description: string;
  logoUrl?: string;
  creator?: string;
  joined: boolean;
}

export interface StudioPart {
  id: string;
  name: string;
  shape: 'box' | 'cylinder' | 'sphere';
  x: number;
  y: number;
  z: number;
  sx: number;
  sy: number;
  sz: number;
  rx?: number;
  ry?: number;
  rz?: number;
  color: string;
  kind: 'normal' | 'bounce' | 'checkpoint' | 'finish' | 'hazard';
}

export interface StudioScript {
  id: string;
  name: string;
  enabled: boolean;
  targetPartId: string;
  code: string;
}

export type AppRoute =
  | 'home'
  | 'top'
  | 'avatar'
  | 'chat'
  | 'favorites'
  | 'notifications'
  | 'buy-pickbux'
  | 'settings'
  | 'communities'
  | 'inventory'
  | 'creator'
  | 'studio'
  | 'ugc-studio'
  | 'play';
