export type FinishType = 'metallic' | 'matte' | 'titanium' | 'iridescent' | 'carbon';
export type AeroPreset = 'street' | 'gt3' | 'widebody';
export type CameraMode = 'chase' | 'cockpit' | 'overhead' | 'orbit';
export type GamePhase = 'title' | 'countdown' | 'playing' | 'paused' | 'victory' | 'replay';
export type NetworkMode = 'offline' | 'multiplayer';
export type CinematicCameraAngle = 'broadcast' | 'drone' | 'bumper' | 'orbit' | 'wheel';

export interface ReplayActorSnapshot {
  id: string;
  x: number;
  y: number;
  z: number;
  heading: number;
  pitch: number;
  roll: number;
  steerAngle: number;
  driftAngle: number;
  speedKmh: number;
  isBraking: boolean;
  isNitro: boolean;
  lap: number;
  trackT: number;
  lateralOffset: number;
}

export interface ReplaySnapshot {
  timeOffset: number; // in seconds relative to start of buffer (0..30)
  actors: ReplayActorSnapshot[];
}

export interface ReplayPlaybackState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  playbackSpeed: number; // 0.5, 1.0, 2.0
  cameraAngle: CinematicCameraAngle;
}

export interface HypercarSpec {
  id: string;
  name: string;
  manufacturer: string;
  category: 'Hypercar / LMH' | 'LMGT3 / GT3' | 'GT2 / GT4';
  liveryName: string;
  year: number;
  powertrain: string;
  horsepower: number;
  topSpeedKmh: number;
  accel0to100: number; // seconds
  handlingRating: number; // 1-100
  nitroEfficiency: number; // 1-100
  defaultPaintHex: string;
  defaultFinish: FinishType;
  defaultRimHex: string;
  defaultCaliperHex: string;
  chassisLength: number;
  chassisWidth: number;
  roofHeight: number;
  bodyStyle:
    | 'lmh'
    | 'lmdh'
    | 'bolide'
    | 'gt3-mid'
    | 'gt3-front'
    | 'porsche-gt3'
    | 'gt4-coupe'
    | 'valkyrie'
    | 'gtr'
    | 'veloce'
    | 'taycan'
    | 'jesko';
}

export interface VehicleCustomization {
  carId: string;
  paintHex: string;
  finishType: FinishType;
  rimHex: string;
  caliperHex: string;
  aeroPreset: AeroPreset;
  engineStage: number; // 1..3
  turboStage: number; // 1..3
  suspensionStage: number; // 1..3
  explodedView: number; // 0..1
}

export interface RaceParticipant {
  id: string;
  name: string;
  controlType: 'local-p1' | 'local-p2' | 'ai-bot' | 'remote-peer';
  carId: string;
  paintHex: string;
  finishType: FinishType;
  rimHex: string;
  caliperHex: string;
  aeroPreset: AeroPreset;
  skillRating: number; // 0.65 .. 1.05 for AI speed multiplier
  lap: number;
  trackProgress: number; // 0..1
  totalDistance: number;
  lateralOffset: number;
  speedKmh: number;
  finished: boolean;
  finishTimeMs: number | null;
}

export interface LevelConfig {
  id: string;
  index: number;
  name: string;
  subtitle: string;
  location: string;
  laps: number;
  trackWidth: number;
  skyColorHex: string;
  fogColorHex: string;
  fogDensity: number;
  groundColorHex: string;
  asphaltColorHex: string;
  curbPrimaryHex: string;
  curbSecondaryHex: string;
  sunColorHex: string;
  sunIntensity: number;
  hemiSkyHex: string;
  hemiGroundHex: string;
  treeColorHex: string;
  rockColorHex: string;
  accentLightHex: string;
  difficultyMultiplier: number;
  waypoints: Array<[number, number, number]>;
}

export interface LiveTelemetry {
  speedKmh: number;
  rpm: number;
  gear: number;
  nitroAmount: number; // 0..100
  isDrifting: boolean;
  isNitroActive: boolean;
  lap: number;
  totalLaps: number;
  position: number;
  totalRacers: number;
  elapsedMs: number;
  bestLapMs: number | null;
  trackProgress: number;
  sessionDistanceMeters: number;
  driftDurationSeconds?: number;
  maxDriftSeconds?: number;
  p2SpeedKmh?: number;
  p2Position?: number;
  standings: Array<{
    id: string;
    name: string;
    controlType: RaceParticipant['controlType'];
    lap: number;
    progress: number;
    speedKmh: number;
    finished: boolean;
    finishTimeMs: number | null;
    paintHex: string;
  }>;
}

export interface CareerRaceRecord {
  id: string;
  levelName: string;
  carName: string;
  position: number;
  totalRacers: number;
  finishTimeMs: number;
  distanceMeters: number;
  timestamp: number;
}

export interface CareerStats {
  driverAge?: number;
  driverCountry?: string;
  driverNumber?: string;
  driverTeam?: string;
  baseDistanceMeters: number;
  totalRaces: number;
  totalWins: number;
  podiums: number;
  finishPositionsSum: number;
  peakSpeedKmh: number;
  bestLapMs: number | null;
  longestDriftSeconds?: number;
  circuitsRaced?: string[];
  nitroBoostCount?: number;
  unlockedAchievements?: Record<string, number>;
  recentRaces: CareerRaceRecord[];
}

export const HYPERCARS: HypercarSpec[] = [
  {
    id: 'mclaren-720s-lmgt3-evo',
    name: 'McLaren 720S LMGT3 Evo',
    manufacturer: 'McLaren Motorsport',
    category: 'LMGT3 / GT3',
    liveryName: 'United Autosports WEC Works #59',
    year: 2024,
    powertrain: '4.0L M840T Twin-Turbo V8 Dry-Sump',
    horsepower: 615,
    topSpeedKmh: 312,
    accel0to100: 2.7,
    handlingRating: 96,
    nitroEfficiency: 92,
    defaultPaintHex: '#FF6B00',
    defaultFinish: 'metallic',
    defaultRimHex: '#0F172A',
    defaultCaliperHex: '#FF6B00',
    chassisLength: 4.54,
    chassisWidth: 2.04,
    roofHeight: 1.16,
    bodyStyle: 'gt3-mid',
  },
  {
    id: 'am-valkyrie-lmh',
    name: 'Aston Martin Valkyrie LMH',
    manufacturer: 'Aston Martin',
    category: 'Hypercar / LMH',
    liveryName: 'The Heart of Racing Works #007',
    year: 2025,
    powertrain: '6.5L Cosworth Naturally Aspirated V12 (10,500 RPM) + E-Motor',
    horsepower: 1000,
    topSpeedKmh: 345,
    accel0to100: 2.2,
    handlingRating: 99,
    nitroEfficiency: 92,
    defaultPaintHex: '#064E3B',
    defaultFinish: 'metallic',
    defaultRimHex: '#D4AF37',
    defaultCaliperHex: '#84CC16',
    chassisLength: 4.88,
    chassisWidth: 2.06,
    roofHeight: 1.05,
    bodyStyle: 'lmh',
  },
  {
    id: 'bmw-m-hybrid-v8-lmdh',
    name: 'BMW M Hybrid V8 LMDh',
    manufacturer: 'BMW M Motorsport',
    category: 'Hypercar / LMH',
    liveryName: 'BMW Team WRT / RLL Works #25',
    year: 2024,
    powertrain: '4.0L Twin-Turbo P66/3 V8 + Bosch Hybrid Motor',
    horsepower: 670,
    topSpeedKmh: 342,
    accel0to100: 2.3,
    handlingRating: 98,
    nitroEfficiency: 94,
    defaultPaintHex: '#1E293B',
    defaultFinish: 'carbon',
    defaultRimHex: '#E2E8F0',
    defaultCaliperHex: '#38BDF8',
    chassisLength: 4.95,
    chassisWidth: 2.05,
    roofHeight: 1.05,
    bodyStyle: 'lmdh',
  },
  {
    id: 'bugatti-bolide',
    name: 'Bugatti Bolide',
    manufacturer: 'Bugatti',
    category: 'Hypercar / LMH',
    liveryName: 'Atelier Molsheim French Racing Blue #01',
    year: 2024,
    powertrain: '8.0L Quad-Turbo W16 (1,850 Nm Dry Sump)',
    horsepower: 1825,
    topSpeedKmh: 380,
    accel0to100: 2.1,
    handlingRating: 96,
    nitroEfficiency: 99,
    defaultPaintHex: '#2563EB',
    defaultFinish: 'metallic',
    defaultRimHex: '#0F172A',
    defaultCaliperHex: '#38BDF8',
    chassisLength: 4.75,
    chassisWidth: 2.08,
    roofHeight: 0.99,
    bodyStyle: 'bolide',
  },
  {
    id: 'ferrari-296-gt3',
    name: 'Ferrari 296 GT3',
    manufacturer: 'Ferrari AF Corse',
    category: 'LMGT3 / GT3',
    liveryName: 'AF Corse Nürburgring 24H Winner #30',
    year: 2024,
    powertrain: '3.0L 120° Twin-Turbo Hot-V V6 (7,800 RPM)',
    horsepower: 600,
    topSpeedKmh: 308,
    accel0to100: 2.8,
    handlingRating: 96,
    nitroEfficiency: 91,
    defaultPaintHex: '#DC2626',
    defaultFinish: 'metallic',
    defaultRimHex: '#E2E8F0',
    defaultCaliperHex: '#FACC15',
    chassisLength: 4.56,
    chassisWidth: 2.05,
    roofHeight: 1.17,
    bodyStyle: 'gt3-mid',
  },
  {
    id: 'ferrari-296-lmgt3',
    name: 'Ferrari 296 LMGT3',
    manufacturer: 'Ferrari AF Corse',
    category: 'LMGT3 / GT3',
    liveryName: 'Vista AF Corse Le Mans 24H #55',
    year: 2024,
    powertrain: '3.0L 120° Twin-Turbo V6 FIA LMGT3 Spec',
    horsepower: 595,
    topSpeedKmh: 306,
    accel0to100: 2.85,
    handlingRating: 95,
    nitroEfficiency: 90,
    defaultPaintHex: '#991B1B',
    defaultFinish: 'metallic',
    defaultRimHex: '#CBD5E1',
    defaultCaliperHex: '#EF4444',
    chassisLength: 4.56,
    chassisWidth: 2.05,
    roofHeight: 1.17,
    bodyStyle: 'gt3-mid',
  },
  {
    id: 'porsche-911-gt3r-992',
    name: 'Porsche GT3 R (Type 992)',
    manufacturer: 'Porsche Motorsport',
    category: 'LMGT3 / GT3',
    liveryName: 'Manthey EMA "Grello" #911',
    year: 2024,
    powertrain: '4.2L Water-Cooled Flat-6 Boxer (9,250 RPM)',
    horsepower: 565,
    topSpeedKmh: 308,
    accel0to100: 2.8,
    handlingRating: 97,
    nitroEfficiency: 93,
    defaultPaintHex: '#EAB308',
    defaultFinish: 'metallic',
    defaultRimHex: '#1E293B',
    defaultCaliperHex: '#EF4444',
    chassisLength: 4.62,
    chassisWidth: 2.04,
    roofHeight: 1.22,
    bodyStyle: 'porsche-gt3',
  },
  {
    id: 'lamborghini-huracan-gt3-evo2',
    name: 'Lamborghini Huracan LMGT3 Evo2',
    manufacturer: 'Lamborghini Squadra Corse',
    category: 'LMGT3 / GT3',
    liveryName: 'Iron Lynx Squadra Corse #63',
    year: 2024,
    powertrain: '5.2L Naturally Aspirated V10 Roof-Scoop Airbox',
    horsepower: 610,
    topSpeedKmh: 310,
    accel0to100: 2.75,
    handlingRating: 95,
    nitroEfficiency: 92,
    defaultPaintHex: '#16A34A',
    defaultFinish: 'metallic',
    defaultRimHex: '#0F172A',
    defaultCaliperHex: '#22C55E',
    chassisLength: 4.55,
    chassisWidth: 2.05,
    roofHeight: 1.16,
    bodyStyle: 'gt3-mid',
  },
  {
    id: 'mercedes-amg-gt3-evo',
    name: 'Mercedes-AMG GT3 EVO',
    manufacturer: 'Mercedes-AMG Motorsport',
    category: 'LMGT3 / GT3',
    liveryName: 'Mercedes-AMG Team GruppeM Racing #99',
    year: 2024,
    powertrain: '6.2L Naturally Aspirated M159 Dry-Sump V8',
    horsepower: 585,
    topSpeedKmh: 303,
    accel0to100: 2.95,
    handlingRating: 94,
    nitroEfficiency: 89,
    defaultPaintHex: '#475569',
    defaultFinish: 'matte',
    defaultRimHex: '#F59E0B',
    defaultCaliperHex: '#F59E0B',
    chassisLength: 4.74,
    chassisWidth: 2.05,
    roofHeight: 1.23,
    bodyStyle: 'gt3-front',
  },
  {
    id: 'bmw-m4-gt3-evo',
    name: 'BMW M4 GT3 EVO',
    manufacturer: 'BMW M Motorsport',
    category: 'LMGT3 / GT3',
    liveryName: 'BMW Team WRT Works #46',
    year: 2025,
    powertrain: '3.0L P58 Twin-Turbo Straight-Six Dry-Sump',
    horsepower: 590,
    topSpeedKmh: 302,
    accel0to100: 2.9,
    handlingRating: 94,
    nitroEfficiency: 89,
    defaultPaintHex: '#F8FAFC',
    defaultFinish: 'metallic',
    defaultRimHex: '#1E293B',
    defaultCaliperHex: '#3B82F6',
    chassisLength: 4.79,
    chassisWidth: 2.04,
    roofHeight: 1.24,
    bodyStyle: 'gt3-front',
  },
  {
    id: 'corvette-z06-gt3r',
    name: 'Chevrolet Corvette Z06 GT3.R',
    manufacturer: 'Chevrolet Racing',
    category: 'LMGT3 / GT3',
    liveryName: 'Corvette Racing Pratt Miller Factory #3',
    year: 2024,
    powertrain: '5.5L LT6.R Flat-Plane Crank NA V8',
    horsepower: 600,
    topSpeedKmh: 304,
    accel0to100: 2.8,
    handlingRating: 94,
    nitroEfficiency: 91,
    defaultPaintHex: '#EAB308',
    defaultFinish: 'metallic',
    defaultRimHex: '#0F172A',
    defaultCaliperHex: '#EF4444',
    chassisLength: 4.68,
    chassisWidth: 2.04,
    roofHeight: 1.2,
    bodyStyle: 'gt3-mid',
  },
  {
    id: 'audi-r8-gt3-evo2',
    name: 'Audi R8 LMS GT3 Evo II',
    manufacturer: 'Audi Sport',
    category: 'LMGT3 / GT3',
    liveryName: 'Audi Sport Team Phoenix #1',
    year: 2024,
    powertrain: '5.2L Naturally Aspirated V10 Mid-Ship',
    horsepower: 585,
    topSpeedKmh: 305,
    accel0to100: 2.9,
    handlingRating: 95,
    nitroEfficiency: 90,
    defaultPaintHex: '#CBD5E1',
    defaultFinish: 'matte',
    defaultRimHex: '#EF4444',
    defaultCaliperHex: '#EF4444',
    chassisLength: 4.58,
    chassisWidth: 2.02,
    roofHeight: 1.18,
    bodyStyle: 'gt3-mid',
  },
  {
    id: 'am-vantage-lmgt3',
    name: 'Aston Martin Vantage AMR LMGT3',
    manufacturer: 'Aston Martin',
    category: 'LMGT3 / GT3',
    liveryName: "Vantage D'station AMR Works #777",
    year: 2024,
    powertrain: '4.0L Twin-Turbo V8 Dry-Sump',
    horsepower: 535,
    topSpeedKmh: 298,
    accel0to100: 3.1,
    handlingRating: 93,
    nitroEfficiency: 88,
    defaultPaintHex: '#0284C7',
    defaultFinish: 'metallic',
    defaultRimHex: '#1E293B',
    defaultCaliperHex: '#F59E0B',
    chassisLength: 4.6,
    chassisWidth: 2.04,
    roofHeight: 1.24,
    bodyStyle: 'gt3-front',
  },
  {
    id: 'ford-mustang-lmgt3',
    name: 'Ford Mustang LMGT3',
    manufacturer: 'Ford Performance',
    category: 'LMGT3 / GT3',
    liveryName: 'Proton Competition WEC Factory #77',
    year: 2024,
    powertrain: '5.4L Coyote-Derived Naturally Aspirated V8',
    horsepower: 580,
    topSpeedKmh: 301,
    accel0to100: 3.0,
    handlingRating: 92,
    nitroEfficiency: 89,
    defaultPaintHex: '#1E3A8A',
    defaultFinish: 'metallic',
    defaultRimHex: '#E2E8F0',
    defaultCaliperHex: '#EF4444',
    chassisLength: 4.82,
    chassisWidth: 2.04,
    roofHeight: 1.25,
    bodyStyle: 'gt3-front',
  },
  {
    id: 'lexus-rcf-lmgt3',
    name: 'Lexus RC F LMGT3',
    manufacturer: 'Lexus Racing',
    category: 'LMGT3 / GT3',
    liveryName: 'Akkodis ASP Team Works #87',
    year: 2024,
    powertrain: '5.4L Naturally Aspirated Quad-Cam 32V V8',
    horsepower: 570,
    topSpeedKmh: 299,
    accel0to100: 3.1,
    handlingRating: 93,
    nitroEfficiency: 88,
    defaultPaintHex: '#F97316',
    defaultFinish: 'metallic',
    defaultRimHex: '#1E293B',
    defaultCaliperHex: '#F97316',
    chassisLength: 4.71,
    chassisWidth: 2.03,
    roofHeight: 1.23,
    bodyStyle: 'gt3-front',
  },
  {
    id: 'maserati-mc20-gt2',
    name: 'Maserati MC20 GT2',
    manufacturer: 'Maserati Corse',
    category: 'GT2 / GT4',
    liveryName: 'Maserati Corse LP Racing #1',
    year: 2024,
    powertrain: '3.0L Nettuno 90° Twin-Turbo V6 Twin-Spark',
    horsepower: 621,
    topSpeedKmh: 312,
    accel0to100: 2.7,
    handlingRating: 95,
    nitroEfficiency: 91,
    defaultPaintHex: '#38BDF8',
    defaultFinish: 'matte',
    defaultRimHex: '#0F172A',
    defaultCaliperHex: '#0284C7',
    chassisLength: 4.67,
    chassisWidth: 2.04,
    roofHeight: 1.18,
    bodyStyle: 'gt3-mid',
  },
  {
    id: 'bmw-m4-gt4-evo',
    name: 'BMW M4 GT4 EVO',
    manufacturer: 'BMW M Motorsport',
    category: 'GT2 / GT4',
    liveryName: 'Turner Motorsport Factory #96',
    year: 2025,
    powertrain: '3.0L S58 Twin-Turbo 6-Cylinder',
    horsepower: 500,
    topSpeedKmh: 290,
    accel0to100: 3.3,
    handlingRating: 91,
    nitroEfficiency: 87,
    defaultPaintHex: '#F59E0B',
    defaultFinish: 'metallic',
    defaultRimHex: '#0F172A',
    defaultCaliperHex: '#F59E0B',
    chassisLength: 4.75,
    chassisWidth: 2.02,
    roofHeight: 1.26,
    bodyStyle: 'gt4-coupe',
  },
  {
    id: 'bmw-m2-racing',
    name: 'BMW M2 Racing',
    manufacturer: 'BMW M Motorsport',
    category: 'GT2 / GT4',
    liveryName: 'BMW M Motorsport Trophy #22',
    year: 2025,
    powertrain: '3.0L BMW M TwinPower Turbo Inline-6',
    horsepower: 450,
    topSpeedKmh: 282,
    accel0to100: 3.5,
    handlingRating: 91,
    nitroEfficiency: 86,
    defaultPaintHex: '#2563EB',
    defaultFinish: 'metallic',
    defaultRimHex: '#0F172A',
    defaultCaliperHex: '#3B82F6',
    chassisLength: 4.52,
    chassisWidth: 1.96,
    roofHeight: 1.28,
    bodyStyle: 'gt4-coupe',
  },
  {
    id: 'maserati-granturismo-gt4',
    name: 'Maserati GranTurismo GT4',
    manufacturer: 'Maserati Corse',
    category: 'GT2 / GT4',
    liveryName: 'Maserati Trofeo Cup #33',
    year: 2024,
    powertrain: '4.7L Naturally Aspirated Ferrari-Built V8',
    horsepower: 488,
    topSpeedKmh: 288,
    accel0to100: 3.4,
    handlingRating: 90,
    nitroEfficiency: 87,
    defaultPaintHex: '#0369A1',
    defaultFinish: 'metallic',
    defaultRimHex: '#CBD5E1',
    defaultCaliperHex: '#EF4444',
    chassisLength: 4.88,
    chassisWidth: 2.02,
    roofHeight: 1.27,
    bodyStyle: 'gt4-coupe',
  },
];

export const PAINT_SWATCHES = [
  { name: 'Rosso Corsa', hex: '#DC2626' },
  { name: 'AMR Racing Green', hex: '#064E3B' },
  { name: 'Papaya Orange', hex: '#EA580C' },
  { name: 'French Racing Blue', hex: '#2563EB' },
  { name: 'Grello Fluro Yellow', hex: '#EAB308' },
  { name: 'Verde Mantis', hex: '#16A34A' },
  { name: 'Alpine Glacier White', hex: '#F8FAFC' },
  { name: 'Stealth Carbon Black', hex: '#1E293B' },
];

export const RIM_SWATCHES = [
  { name: 'Forged Motorsport Silver', hex: '#E2E8F0' },
  { name: 'Gold Magnesium', hex: '#D4AF37' },
  { name: 'Satin Bronze Works', hex: '#B45309' },
  { name: 'Matte Track Black', hex: '#0F172A' },
];

export const AUTOMATED_LEVELS: LevelConfig[] = [
  {
    id: 'alpine-dawn',
    index: 0,
    name: '01. Thunderbolt International Raceway',
    subtitle: 'FIA Grade-1 stadium main straight, glass pit complex, high-speed mountain valley sweepers & hairpin',
    location: 'Thunderbolt GP · 4.35 km Circuit',
    laps: 3,
    trackWidth: 18,
    skyColorHex: '#3b82f6',
    fogColorHex: '#93c5fd',
    fogDensity: 0.00045,
    groundColorHex: '#3f5232',
    asphaltColorHex: '#252a32',
    curbPrimaryHex: '#EF4444',
    curbSecondaryHex: '#F8FAFC',
    sunColorHex: '#FFFBEB',
    sunIntensity: 2.6,
    hemiSkyHex: '#BAE6FD',
    hemiGroundHex: '#334155',
    treeColorHex: '#1b4332',
    rockColorHex: '#64748B',
    accentLightHex: '#F59E0B',
    difficultyMultiplier: 0.9,
    waypoints: [
      [0, 0, 0],
      [0, 0, -520],
      [110, 4, -920],
      [340, 10, -1120],
      [680, 14, -1040],
      [880, 10, -720],
      [740, 6, -380],
      [940, 8, -40],
      [860, 4, 340],
      [580, 2, 620],
      [260, 0, 580],
      [40, 0, 380],
    ],
  },
  {
    id: 'red-rock-canyon',
    index: 1,
    name: '02. Sierra Mountain Highway Pass',
    subtitle: 'Misty monolith rock cliffs, golden-hour conifer forest slopes & sweeping multi-lane valley bends',
    location: 'Sierra Ridge · 4.48 km Pass',
    laps: 3,
    trackWidth: 18.5,
    skyColorHex: '#c08457',
    fogColorHex: '#d6a786',
    fogDensity: 0.00055,
    groundColorHex: '#6b5a35',
    asphaltColorHex: '#23252a',
    curbPrimaryHex: '#F59E0B',
    curbSecondaryHex: '#FEF3C7',
    sunColorHex: '#FDE68A',
    sunIntensity: 2.7,
    hemiSkyHex: '#FED7AA',
    hemiGroundHex: '#451A03',
    treeColorHex: '#263c21',
    rockColorHex: '#78716c',
    accentLightHex: '#F97316',
    difficultyMultiplier: 0.95,
    waypoints: [
      [0, 0, 0],
      [-40, 2, -560],
      [140, 12, -980],
      [520, 18, -1180],
      [920, 12, -940],
      [1040, 6, -480],
      [760, 5, -140],
      [960, 3, 280],
      [680, 0, 640],
      [300, 0, 660],
      [35, 0, 390],
    ],
  },
  {
    id: 'riviera-coastal',
    index: 2,
    name: '03. Azure Riviera Grand Prix',
    subtitle: 'Sunny Mediterranean stadium harbor straight, coastal cliffside chicanes & panoramic hairpins',
    location: 'Côte d’Azur · 4.22 km GP',
    laps: 4,
    trackWidth: 17.5,
    skyColorHex: '#0284c7',
    fogColorHex: '#7dd3fc',
    fogDensity: 0.00042,
    groundColorHex: '#2d4a36',
    asphaltColorHex: '#222830',
    curbPrimaryHex: '#EF4444',
    curbSecondaryHex: '#F8FAFC',
    sunColorHex: '#FEF08A',
    sunIntensity: 2.6,
    hemiSkyHex: '#7DD3FC',
    hemiGroundHex: '#1E293B',
    treeColorHex: '#14532d',
    rockColorHex: '#64748B',
    accentLightHex: '#06B6D4',
    difficultyMultiplier: 1.0,
    waypoints: [
      [0, 0, 0],
      [0, 0, -580],
      [210, 6, -960],
      [620, 12, -1080],
      [960, 10, -780],
      [760, 5, -360],
      [1020, 2, 40],
      [780, 0, 480],
      [480, 0, 640],
      [180, 0, 580],
      [20, 0, 360],
    ],
  },
  {
    id: 'neo-tokyo-express',
    index: 3,
    name: '04. Bayshore Twilight Wangan GP',
    subtitle: 'High-speed expressway straightaways, illuminated stadium gantries & sweeping bayshore S-curves',
    location: 'Tokyo Bay · 4.55 km Loop',
    laps: 4,
    trackWidth: 17.5,
    skyColorHex: '#1e293b',
    fogColorHex: '#334155',
    fogDensity: 0.0005,
    groundColorHex: '#1e2b24',
    asphaltColorHex: '#1c212b',
    curbPrimaryHex: '#06B6D4',
    curbSecondaryHex: '#F8FAFC',
    sunColorHex: '#93C5FD',
    sunIntensity: 2.2,
    hemiSkyHex: '#38BDF8',
    hemiGroundHex: '#0F172A',
    treeColorHex: '#1e3a2f',
    rockColorHex: '#475569',
    accentLightHex: '#06B6D4',
    difficultyMultiplier: 1.04,
    waypoints: [
      [0, 0, 0],
      [0, 0, -620],
      [180, 8, -1020],
      [540, 14, -1160],
      [900, 10, -920],
      [1020, 5, -460],
      [720, 2, -140],
      [880, 0, 240],
      [640, 0, 600],
      [310, 0, 640],
      [30, 0, 360],
    ],
  },
  {
    id: 'apex-finale-ring',
    index: 4,
    name: '05. Eifel Nordschleife 24H Gauntlet',
    subtitle: 'Legendary forest endurance circuit with towering cliffside valleys, Carousel banking & elite AI field',
    location: 'Nürburgring Sector · 4.78 km',
    laps: 5,
    trackWidth: 17,
    skyColorHex: '#2563eb',
    fogColorHex: '#93c5fd',
    fogDensity: 0.00048,
    groundColorHex: '#283d27',
    asphaltColorHex: '#1f242c',
    curbPrimaryHex: '#EF4444',
    curbSecondaryHex: '#F8FAFC',
    sunColorHex: '#FDE68A',
    sunIntensity: 2.5,
    hemiSkyHex: '#93C5FD',
    hemiGroundHex: '#1E293B',
    treeColorHex: '#143622',
    rockColorHex: '#57534e',
    accentLightHex: '#EF4444',
    difficultyMultiplier: 1.08,
    waypoints: [
      [0, 0, 0],
      [0, 0, -660],
      [190, 10, -1080],
      [580, 18, -1240],
      [1010, 12, -980],
      [1120, 6, -520],
      [800, 4, -200],
      [1020, 2, 200],
      [760, 0, 600],
      [420, 0, 700],
      [140, 0, 580],
      [20, 0, 360],
    ],
  },
];
