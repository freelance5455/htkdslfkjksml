export type ItemId =
  | 'wood'
  | 'stone'
  | 'fiber'
  | 'coal'
  | 'iron'
  | 'berry'
  | 'apple'
  | 'cooked_berry'
  | 'cooked_apple'
  | 'wooden_axe'
  | 'stone_axe'
  | 'stone_pickaxe'
  | 'wooden_sword'
  | 'torch'
  | 'campfire'
  | 'chest'
  | 'wood_wall'
  | 'wood_floor'
  | 'wood_door';

export type ItemCategory = 'resource' | 'food' | 'tool' | 'weapon' | 'building' | 'placeable';

export interface ItemDefinition {
  id: ItemId;
  name: string;
  nameAr: string;
  category: ItemCategory;
  descriptionAr: string;
  stackable: boolean;
  maxStack: number;
  durability?: number;
  maxDurability?: number;
  damage?: number;
  gatherPowerWood?: number;
  gatherPowerStone?: number;
  hungerRestore?: number;
  energyRestore?: number;
  healthRestore?: number;
  lightRadius?: number;
}

export interface InventorySlot {
  item: ItemId | null;
  count: number;
  durability?: number;
}

export interface RecipeRequirement {
  item: ItemId;
  count: number;
}

export interface CraftingRecipe {
  id: string;
  output: ItemId;
  outputCount: number;
  nameAr: string;
  category: 'tools' | 'survival' | 'building' | 'cooking';
  requirements: RecipeRequirement[];
  requiresCampfire?: boolean;
}

export type Direction = 'down' | 'up' | 'left' | 'right';

export type PlayerAction = 'idle' | 'walk' | 'run' | 'swim' | 'attack' | 'dodge' | 'gather' | 'hurt' | 'death';

export interface PlayerState {
  x: number;
  y: number;
  vx: number;
  vy: number;
  direction: Direction;
  action: PlayerAction;
  actionTimer: number;
  animFrame: number;
  animTimer: number;
  health: number;
  maxHealth: number;
  hunger: number;
  maxHunger: number;
  energy: number;
  maxEnergy: number;
  speed: number;
  isDead: boolean;
  isRunning: boolean;
  isSwimming: boolean;
  isDodging: boolean;
  dodgeTimer: number;
  dodgeCooldown: number;
  isInvulnerable: boolean;
  selectedHotbarIndex: number;
  activeTool: ItemId | null;
  attackCooldown: number;
  hurtFlashTimer: number;
  xp: number;
  level: number;
  skillPoints: number;
  skills: Record<string, number>;
}

export type BiomeType = 'forest' | 'dense_forest' | 'rocky' | 'beach' | 'wetland';

export type TileType =
  | 'grass'
  | 'grass_dense'
  | 'dirt'
  | 'sand'
  | 'water'
  | 'deep_water'
  | 'stone_path'
  | 'cave_floor';

export interface Tile {
  type: TileType;
  walkable: boolean;
  variant: number;
  biome?: BiomeType;
}

export type ResourceType =
  | 'tree_oak'
  | 'tree_pine'
  | 'tree_birch'
  | 'rock'
  | 'rock_iron'
  | 'rock_coal'
  | 'bush_berry'
  | 'flower';

export interface ResourceNode {
  id: string;
  type: ResourceType;
  x: number;
  y: number;
  health: number;
  maxHealth: number;
  harvested: boolean;
  regrowTimer?: number;
  shakeTimer?: number;
  width: number;
  height: number;
}

export type EnemyType =
  | 'slime'
  | 'wolf'
  | 'night_creature'
  | 'deer'
  | 'rabbit'
  | 'boar'
  | 'goat'
  | 'chicken'
  | 'duck'
  | 'bird'
  | 'fish'
  | 'frog'
  | 'bear'
  | 'wild_boar'
  | 'croc'
  | 'golden_deer';

export type EnemyAIState =
  | 'idle'
  | 'patrol'
  | 'wander'
  | 'eat'
  | 'drink'
  | 'detect'
  | 'chase'
  | 'attack'
  | 'sleep'
  | 'hurt'
  | 'flee'
  | 'dead';

export interface CreatureDrop {
  item: ItemId;
  count: number;
  chance: number;
}

export interface Enemy {
  id: string;
  type: EnemyType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  health: number;
  maxHealth: number;
  damage: number;
  speed: number;
  detectionRange: number;
  attackRange: number;
  attackCooldown: number;
  state: EnemyAIState;
  stateTimer: number;
  patrolTarget: { x: number; y: number } | null;
  spawnPoint: { x: number; y: number };
  direction: Direction;
  animFrame: number;
  animTimer: number;
  hurtTimer: number;
  detectTimer?: number;
  width: number;
  height: number;
  isHerbivore?: boolean;
  isAquatic?: boolean;
  isRare?: boolean;
  isAggroOnHit?: boolean;
  drops?: CreatureDrop[];
  displayNameAr?: string;
}

export type WeatherType = 'clear' | 'cloudy' | 'rain' | 'storm';

export interface PointOfInterest {
  id: string;
  type: 'ruins' | 'abandoned_camp' | 'hidden_spring' | 'ore_cluster';
  x: number;
  y: number;
  nameAr: string;
  descAr: string;
  discovered: boolean;
}

export type SkillBranch = 'survival' | 'combat' | 'exploration' | 'gathering' | 'crafting' | 'aquatic';

export interface SkillDefinition {
  id: string;
  branch: SkillBranch;
  nameAr: string;
  descAr: string;
  iconId: string;
  maxRank: number;
  requiredPoints: number;
  requiredLevel: number;
  prerequisiteId?: string;
  effectType: string;
  effectValuePerRank: number;
}

export type BuildingType =
  | 'wood_floor'
  | 'wood_wall'
  | 'wood_door'
  | 'campfire'
  | 'chest';

export interface Building {
  id: string;
  type: BuildingType;
  tileX: number;
  tileY: number;
  health: number;
  maxHealth: number;
  isOpen?: boolean; // for doors
  storage?: (InventorySlot | null)[]; // for chests
  fuelTimer?: number; // for campfire
}

export interface DroppedItem {
  id: string;
  item: ItemId;
  count: number;
  x: number;
  y: number;
  spawnTime: number;
  pickupDelay: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  alpha: number;
  shape?: 'pixel' | 'circle' | 'leaf' | 'spark' | 'smoke' | 'rain' | 'ripple';
}

export interface DamageNumber {
  id: string;
  text: string;
  x: number;
  y: number;
  color: string;
  life: number;
  maxLife: number;
}

export interface Milestone {
  id: string;
  titleAr: string;
  descriptionAr: string;
  icon: string;
  completed: boolean;
  completedAt?: number;
}

export interface GameStats {
  daysSurvived: number;
  resourcesCollected: number;
  enemiesDefeated: number;
  itemsCrafted: number;
  structuresBuilt: number;
}

export interface SaveGameData {
  version: number;
  seed: number;
  timeOfDay: number; // 0 to 1440 minutes
  dayCount: number;
  player: PlayerState;
  inventory: (InventorySlot | null)[];
  buildings: Building[];
  resources: ResourceNode[];
  stats: GameStats;
  milestones: Milestone[];
  weather?: WeatherType;
  discoveredPOIs?: string[];
}

export type SkillId =
  | 'vitality'
  | 'endurance'
  | 'iron_stomach'
  | 'thick_skin'
  | 'heavy_strike'
  | 'critical_strike'
  | 'swift_blade'
  | 'nimble_dodge'
  | 'pathfinder'
  | 'marathon_runner'
  | 'keen_vision'
  | 'treasure_hunter'
  | 'lumberjack'
  | 'master_miner'
  | 'bountiful_yield'
  | 'lucky_prospector'
  | 'frugal_crafting'
  | 'reinforced_tools'
  | 'fortified_walls'
  | 'swimmer_lungs'
  | 'swift_fin'
  | 'aquatic_hunter';


