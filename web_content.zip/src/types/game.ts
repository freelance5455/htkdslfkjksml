export type GamePhase = 'title' | 'playing' | 'paused' | 'wasted';

export type CameraMode = 'third_person' | 'first_person' | 'cinematic';

export type WeatherType = 'clear' | 'golden' | 'overcast' | 'rain';

export type DistrictId =
  | 'clifton'
  | 'dha'
  | 'saddar'
  | 'lyari'
  | 'korangi'
  | 'gulshan'
  | 'tariq_road'
  | 'shahrah_e_faisal'
  | 'burns_road'
  | 'sea_view'
  | 'mazar_e_quaid'
  | 'karachi_port';

export type VehicleType =
  | 'mehran'
  | 'alto'
  | 'civic'
  | 'corolla'
  | 'land_cruiser'
  | 'bus'
  | 'rickshaw'
  | 'motorcycle'
  | 'truck'
  | 'boat';

export type CharacterId = 'zain' | 'ayesha' | 'bilal' | 'tariq' | 'sana';

export type ClothingStyle = 'shalwar_kameez' | 'kurta_waistcoat' | 'ajrak_street' | 'modern_casual';

export type FacialHairStyle = 'none' | 'stubble' | 'beard';

export interface CharacterCustomization {
  style: ClothingStyle;
  primaryColor: string;
  secondaryColor: string;
  accessory: 'none' | 'sunglasses' | 'cap' | 'sindhi_cap';
  facialHair?: FacialHairStyle;
  skinTone?: string;
}

export type MissionCategory = 'story' | 'driving' | 'racing' | 'business' | 'police' | 'activity';

export interface MissionDef {
  id: string;
  title: string;
  category: MissionCategory;
  district: DistrictId;
  description: string;
  rewardCash: number;
  startPos: { x: number; z: number };
  waypoints: { x: number; z: number; label: string; radius?: number }[];
  requiredVehicle?: VehicleType;
  timeLimitSec?: number;
  wantedOnStart?: number;
}

export interface VehicleSpec {
  type: VehicleType;
  name: string;
  category: 'car' | 'suv' | 'public' | 'bike' | 'truck' | 'boat';
  price: number;
  topSpeed: number; // m/s (1 m/s = 3.6 km/h)
  acceleration: number;
  braking: number;
  handling: number;
  mass: number;
  defaultColor: string;
  length: number;
  width: number;
  height: number;
  seatOffset: { x: number; y: number; z: number };
}

export interface DistrictDef {
  id: DistrictId;
  name: string;
  tagline: string;
  x: number;
  z: number;
  radius: number;
  color: string;
}

export type PlaceType =
  | 'dealership'
  | 'bike_shop'
  | 'mall'
  | 'restaurant'
  | 'clothing'
  | 'property'
  | 'phone_shop'
  | 'home'
  | 'bank';

export interface BankTransaction {
  id: string;
  label: string;
  amount: number;
  type: 'deposit' | 'withdraw' | 'interest' | 'loan' | 'repay';
  time: string;
}

export type CarControlMode = 'buttons' | 'wheel' | 'joystick';

export type PhoneModelId = 'lite' | 'pro_5g' | 'creator_max';

export interface VehicleTuning {
  color: string;
  engineLevel: number; // 1..3
  handlingLevel: number; // 1..3
}

export interface PlaceDef {
  id: string;
  name: string;
  type: PlaceType;
  district: DistrictId;
  x: number;
  z: number;
  price?: number;
  incomePerMin?: number;
  description: string;
}

export interface YouTubeVideo {
  id: string;
  title: string;
  category: 'Vlog' | 'Car Review' | 'Street Race' | 'Police Chase' | 'Sea View';
  thumbnailDataUrl: string;
  videoUrl?: string; // In-session blob URL for recorded WebGL video playback
  durationSec: number;
  views: number;
  likes: number;
  earnedCash: number;
  unclaimedCash: number;
  publishedAt: string;
  district: string;
}

export interface YouTubeChannel {
  created: boolean;
  channelName: string;
  customerId: string;
  bio: string;
  avatarColor: string;
  avatarDataUrl?: string;
  subscribers: number;
  totalViews: number;
  totalEarned: number;
  videos: YouTubeVideo[];
}

export interface RecordedClipDraft {
  thumbnailDataUrl: string;
  videoUrl?: string;
  durationSec: number;
  actionScore: number;
  district: string;
}

export interface HudSnapshot {
  health: number;
  maxHealth: number;
  stamina: number;
  cash: number;
  wantedLevel: number;
  wantedCooldown: number;
  district: DistrictDef;
  speedKmh: number;
  inVehicle: VehicleType | null;
  vehicleName: string | null;
  isSwimming: boolean;
  cameraMode: CameraMode;
  timeOfDay: number; // 0..24
  weather: WeatherType;
  playerX: number;
  playerZ: number;
  playerYaw: number;
  isRecordingVideo: boolean;
  recordingSeconds: number;
  nearbyPrompt: {
    action: string;
    label: string;
    kind: 'vehicle' | 'place' | 'mission';
    id?: string;
  } | null;
  activeMission: {
    id: string;
    title: string;
    objective: string;
    waypointIndex: number;
    totalWaypoints: number;
    timeLeft: number | null;
    targetX: number;
    targetZ: number;
  } | null;
  waypoint: { x: number; z: number; label: string } | null;
  radarBlips: {
    x: number;
    z: number;
    kind: 'vehicle' | 'police' | 'place' | 'mission';
  }[];
}

export interface SaveData {
  version: number;
  cash: number;
  activeCharacter: CharacterId;
  customizations: Record<CharacterId, CharacterCustomization>;
  ownedProperties: string[];
  ownedVehicles: VehicleType[];
  completedMissions: string[];
  timeOfDay: number;
  weather: WeatherType;
  playerPos: { x: number; y: number; z: number };
  phoneModel: PhoneModelId;
  phoneThemeColor: string;
  carControlMode: CarControlMode;
  vehicleTuning: Partial<Record<VehicleType, VehicleTuning>>;
  bankBalance: number;
  bankAccountNo: string;
  bankLoan: number;
  bankTransactions: BankTransaction[];
  youtube: YouTubeChannel;
  stats: {
    missionsCompleted: number;
    distanceDrivenKm: number;
    earningsTotal: number;
  };
}
