/**
 * Core game types and interfaces for Subway Mom Runner 3D
 */

export type GameState = 'TITLE' | 'PLAYING' | 'PAUSED' | 'GAMEOVER' | 'VICTORY';

export type GameMode = 'ENDLESS' | 'LEVELS' | 'MULTIPLAYER';

export type PlayerAction = 'JUMP' | 'ROLL' | 'LEFT' | 'RIGHT' | 'BOARD';

export interface CharacterItem {
  id: number;
  name: string;
  arabicName: string;
  gender: 'boy' | 'girl' | 'special';
  category: string;
  rarity: 'عادي' | 'نادر' | 'ملحمي' | 'أسطوري';
  unlocked: boolean;
  cost: number;
  costType: 'coins' | 'gems';
  speedBonus: number;
  coinBonus: number;
  description: string;
  colors: {
    skin: string;
    shirt: string;
    pants: string;
    shoes: string;
    hair: string;
    accessory?: string;
  };
}

export interface HoverboardItem {
  id: string;
  name: string;
  speedMultiplier: number;
  unlocked: boolean;
  cost: number;
  description: string;
  primaryColor: string;
  trailColor: string;
  hasSparks: boolean;
}

export interface BackpackItem {
  id: string;
  name: string;
  bonus: string;
  unlocked: boolean;
  cost: number;
  primaryColor: string;
  isJetpack?: boolean;
}

export interface UpgradeItem {
  id: string;
  name: string;
  level: number;
  maxLevel: number;
  baseCost: number;
  description: string;
  iconName: string;
}

export interface DailyMission {
  id: string;
  title: string;
  target: number;
  current: number;
  rewardCoins: number;
  rewardGems: number;
  completed: boolean;
  claimed: boolean;
  type: 'coins' | 'distance' | 'jump' | 'slide' | 'hoverboard' | 'dodge';
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  completed: boolean;
  rewardGems: number;
  icon: string;
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  score: number;
  country: string;
  flag: string;
  avatarId: number;
  date: string;
}

export interface LevelConfig {
  id: number;
  title: string;
  subtitle: string;
  targetDistance: number;
  targetCoins: number;
  skyColor: number;
  fogColor: number;
  roadColor: number;
  buildingStyle: 'oriental' | 'downtown' | 'coastal' | 'highway';
  unlocked: boolean;
  stars: number;
}

export interface ActivePowerups {
  magnet: number; // remaining seconds
  multiplier: number;
  jetpack: number;
  sneakers: number;
  hoverboard: boolean;
}

export interface PlayerStats {
  coins: number;
  gems: number;
  highScore: number;
  selectedCharacterId: number;
  selectedBoardId: string;
  selectedBackpackId: string;
  unlockedCharacters: number[];
  unlockedBoards: string[];
  unlockedBackpacks: string[];
  completedLevels: number[];
  levelStars: Record<number, number>;
  upgrades: Record<string, number>;
  currentLevel: number;
  gamepadVibration: boolean;
  musicVolume: number;
  sfxVolume: number;
  showOnScreenButtons: boolean;
  customKeyBindings: {
    jump: string;
    slide: string;
    left: string;
    right: string;
    board: string;
    pause: string;
  };
}

export interface MultiplayerPeerState {
  id: string;
  name: string;
  distance: number;
  score: number;
  lane: number;
  y: number;
  characterId: number;
  isAlive: boolean;
  timestamp: number;
}
