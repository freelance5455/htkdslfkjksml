export type GameMode = 'classic' | 'time_challenge' | 'endless' | 'daily';

export type ScreenState =
  | 'TITLE'
  | 'LEVEL_SELECT'
  | 'PLAYING'
  | 'PAUSED'
  | 'VICTORY'
  | 'GAME_OVER'
  | 'SHOP'
  | 'ACHIEVEMENTS'
  | 'SETTINGS'
  | 'DAILY_CALENDAR'
  | 'HOW_TO_PLAY';

export type ColorId =
  | 'red'
  | 'blue'
  | 'green'
  | 'yellow'
  | 'purple'
  | 'orange'
  | 'cyan'
  | 'pink';

export type SpecialTileType =
  | 'bomb'
  | 'rainbow'
  | 'ice'
  | 'locked'
  | 'multiplier'
  | 'portal';

export interface Coordinate {
  r: number;
  c: number;
}

export interface SpecialTile {
  type: SpecialTileType;
  r: number;
  c: number;
  value?: number; // e.g. 2x, 3x for multiplier
  iceHealth?: number; // hits needed
  isUnlocked?: boolean;
  targetPortal?: Coordinate; // for portal pairing
}

export interface ColorNodePair {
  color: ColorId;
  start: Coordinate;
  end: Coordinate;
}

export interface LevelConfig {
  id: number | string;
  worldIndex: number;
  name: string;
  rows: number;
  cols: number;
  pairs: ColorNodePair[];
  specialTiles?: SpecialTile[];
  maxMoves: number;
  parMoves: number;
  timeLimit?: number; // for time challenge
}

export interface CellState {
  r: number;
  c: number;
  color: ColorId | null; // If this cell is an endpoint
  isEndpoint: boolean;
  endpointIndex?: 0 | 1;
  pathColor: ColorId | null; // Color of the path currently occupying this cell
  specialTile?: SpecialTile;
  isCovered?: boolean;
}

export interface ThemeConfig {
  id: string;
  name: string;
  description: string;
  price: number;
  bgGradient: string;
  boardBg: string;
  gridLineColor: string;
  cellBg: string;
  cellHoverBg: string;
  colors: Record<ColorId, {
    hex: string;
    rgb: string;
    glow: string;
    symbol: string;
    label: string;
  }>;
}

export interface NodeSkinConfig {
  id: string;
  name: string;
  description: string;
  price: number;
  style: 'orb' | 'gem' | 'glyph' | 'minimal';
}

export interface BoosterInventory {
  hint: number;
  extraMoves: number;
  colorClear: number;
  shuffle: number;
  undo: number;
}

export interface PlayerStats {
  levelsCompleted: number;
  perfectLevels: number;
  starsCollected: number;
  totalCoins: number;
  totalMovesMade: number;
  totalPathsCompleted: number;
  highestCombo: number;
  timeChallengeHighScore: number;
  endlessHighScore: number;
  dailyStreak: number;
  lastDailyDate: string;
}

export interface SaveData {
  stats: PlayerStats;
  levelProgress: Record<string | number, {
    completed: boolean;
    stars: number;
    highScore: number;
    fewestMoves: number;
  }>;
  dailyCompletions: Record<string, {
    completed: boolean;
    stars: number;
    score: number;
  }>;
  unlockedThemes: string[];
  activeThemeId: string;
  unlockedSkins: string[];
  activeSkinId: string;
  boosters: BoosterInventory;
  achievements: Record<string, boolean>;
  settings: {
    sound: boolean;
    music: boolean;
    colorblindMode: boolean;
    reducedMotion: boolean;
    haptics: boolean;
  };
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
  decay: number;
  shape?: 'circle' | 'star' | 'square';
}
