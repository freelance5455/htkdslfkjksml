export type ColorId =
  | 'red'
  | 'blue'
  | 'green'
  | 'yellow'
  | 'orange'
  | 'purple'
  | 'pink'
  | 'cyan'
  | 'teal'
  | 'lime'
  | 'magenta'
  | 'violet'
  | 'skyBlue'
  | 'deepBlue'
  | 'coral'
  | 'turquoise';

export interface LiquidColorInfo {
  id: ColorId;
  name: string;
  baseHex: string;
  topHighlight: string;
  bottomShadow: string;
  glowHex: string;
  symbol: string; // for colorblind mode
  particleColor: string;
}

export interface Tube {
  id: string;
  layers: ColorId[]; // from bottom (index 0) to top (index length-1). Max 4.
  maxCapacity: 4;
  isLocked?: boolean; // unlocks when a tube is completed
  hiddenCount?: number; // number of bottom layers that are hidden (mystery)
}

export type SpecialChallengeType =
  | 'normal'
  | 'limitedMoves'
  | 'noUndo'
  | 'timeChallenge'
  | 'mystery'
  | 'lockedTube';

export interface LevelData {
  levelNumber: number;
  colorsCount: number;
  tubesCount: number;
  initialTubes: ColorId[][];
  threeStarMoves: number;
  twoStarMoves: number;
  specialType: SpecialChallengeType;
  timeLimitSeconds?: number;
  maxMoves?: number;
}

export interface PourAnimationState {
  sourceIndex: number;
  destinationIndex: number;
  color: ColorId;
  units: number;
  startTime: number;
  durationMs: number;
  sourceStartPos: { x: number; y: number };
  destStartPos: { x: number; y: number };
}

export interface LevelProgress {
  stars: number; // 0-3
  bestMoves: number;
  completed: boolean;
}

export interface UserSaveData {
  coins: number;
  currentUnlockedLevel: number;
  levelProgress: Record<number, LevelProgress>;
  equippedLocation: string;
  equippedTube: string;
  equippedLiquid: string;
  unlockedLocations: string[];
  unlockedTubes: string[];
  unlockedLiquids: string[];
  hintsCount: number;
  undosCount: number;
  extraTubesCount: number;
  spinsCount: number;
  lastDailyClaimDate: string; // YYYY-MM-DD
  lastDailySpinDate?: string; // YYYY-MM-DD
  dailyStreak: number;
  dailyChallengeCompletedDate: string; // YYYY-MM-DD
  extraDailyChallengeAttempts?: number;
  dailyChallengeBonusIndex?: number;
  settings: {
    sound: boolean;
    music: boolean;
    haptics: boolean;
    colorblind: boolean;
    soundVolume?: number; // 0.0 to 1.0
    musicVolume?: number; // 0.0 to 1.0
  };
}

export interface LocationTheme {
  id: string;
  name: string;
  price: number;
  bgGradient: string;
  ambientParticles: string;
  pedestalColor: string;
  textColor: string;
  description: string;
}

export interface TubeTheme {
  id: string;
  name: string;
  price: number;
  borderStyle: string;
  glassGradient: string;
  rimColor: string;
  highlightGlow: string;
  description: string;
}

export interface LiquidTheme {
  id: string;
  name: string;
  price: number;
  effect: string;
  description: string;
}

export interface ShopItem {
  id: string;
  name: string;
  type: 'location' | 'tube' | 'liquid';
  price: number;
  description: string;
  previewGradient?: string;
  bgClass?: string;
}

