export type Language = 'hinglish' | 'english';

export type CharacterId = 'ayush' | 'arav' | 'akshhara' | 'ripin' | 'anjeeta';

export interface DialogueNode {
  speaker: CharacterId;
  speakerName: {
    hinglish: string;
    english: string;
  };
  text: {
    hinglish: string;
    english: string;
  };
  emotion?: 'happy' | 'arguing' | 'funny' | 'thinking' | 'proud' | 'shocked';
  choices?: {
    id: string;
    label: {
      hinglish: string;
      english: string;
    };
    nextIndex: number;
    points?: number;
    isCorrect?: boolean;
    feedback?: {
      hinglish: string;
      english: string;
    };
  }[];
}

export interface Mission {
  id: number;
  title: {
    hinglish: string;
    english: string;
  };
  subtitle: {
    hinglish: string;
    english: string;
  };
  description: {
    hinglish: string;
    english: string;
  };
  location: string;
  targetItems: string[];
  totalObjectives: number;
  introDialogue: DialogueNode[];
  completeDialogue: DialogueNode[];
  cutsceneSummary: {
    hinglish: string;
    english: string;
  };
}

export interface PlayerStats {
  coins: number;
  stars: number;
  unlockedLevel: number;
  currentLevel: number;
  soundEnabled: boolean;
  musicEnabled: boolean;
  language: Language;
}

export interface InteractableTarget {
  id: string;
  type: 'character' | 'item' | 'furniture';
  name: string;
  position: [number, number, number];
  characterId?: CharacterId;
  actionText: string;
}
