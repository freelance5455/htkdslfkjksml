export type Language = 'pt-BR' | 'es' | 'en';
export type ThemeMode = 'dark' | 'light';
export type PlayerPosition = 'GOL' | 'ZAG' | 'VOL' | 'MEI' | 'ATA';
export type Formation = '4-3-3' | '4-4-2' | '3-5-2';
export type WeatherType = 'day' | 'night' | 'rain';
export type Difficulty = 'amateur' | 'professional' | 'legendary';
export type CameraPreset = 'tv' | 'tele' | 'endToEnd';
export type TouchMode = 'auto' | 'on' | 'off';

export type CrestPattern = 'stripes' | 'halves' | 'sash' | 'cross' | 'chevron' | 'solid';
export type CrestIcon = 'crown' | 'eagle' | 'star' | 'flame' | 'shield' | 'anchor';
export type HairStyle = 'short' | 'fade' | 'afro' | 'mohawk' | 'long' | 'bald';

export interface KitConfig {
  primaryColor: string;
  secondaryColor: string;
  shortsColor: string;
  pattern: CrestPattern;
}

export interface Player {
  id: string;
  name: string;
  position: PlayerPosition;
  number: number;
  ovr: number;
  pac: number;
  sho: number;
  pas: number;
  dri: number;
  def: number;
  phy: number;
  nationality: string;
  hairStyle?: HairStyle;
  hairColor?: string;
  cardTier?: 'gold' | 'totw' | 'icon' | 'hero';
}

export interface Club {
  id: string;
  name: string;
  abbr: string;
  league: 'brasileirao' | 'europe' | 'custom';
  primaryColor: string;
  secondaryColor: string;
  pattern: CrestPattern;
  icon: CrestIcon;
  homeKit?: KitConfig;
  awayKit?: KitConfig;
  stadium: string;
  ovr: number;
  att: number;
  mid: number;
  def: number;
  players: Player[];
}

export interface StadiumOption {
  id: string;
  name: string;
  city: string;
  capacity: string;
  turfTone: string;
}

export interface MatchConfig {
  homeClubId: string;
  awayClubId: string;
  homeKitVariant?: 'home' | 'away';
  awayKitVariant?: 'home' | 'away';
  stadiumId: string;
  weather: WeatherType;
  durationMinutes: number;
  difficulty: Difficulty;
  formation: Formation;
  careerMatchId?: string;
}

export interface MatchStats {
  homeScore: number;
  awayScore: number;
  homeShots: number;
  awayShots: number;
  homeOnTarget: number;
  awayOnTarget: number;
  homePossession: number;
  awayPossession: number;
  homePasses: number;
  awayPasses: number;
  scorers: Array<{
    team: 'home' | 'away';
    playerName: string;
    minute: number;
  }>;
}

export interface CareerStanding {
  clubId: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  gf: number;
  ga: number;
  points: number;
}

export interface CareerFixture {
  id: string;
  round: number;
  homeClubId: string;
  awayClubId: string;
  played: boolean;
  homeScore?: number;
  awayScore?: number;
}

export interface CareerState {
  clubId: string;
  league: 'brasileirao' | 'europe';
  season: number;
  currentRound: number;
  trainingPoints: number;
  standings: CareerStanding[];
  fixtures: CareerFixture[];
}

export interface FutState {
  coins: number;
  clubName: string;
  formation: Formation;
  lineupIds: string[]; // 11 player IDs
  inventory: Array<Player & { clubId: string; clubName: string; league: Club['league'] }>;
}

export interface AudioSettings {
  musicEnabled: boolean;
  sfxEnabled: boolean;
  commentaryEnabled: boolean;
  volume: number;
  trackIndex: number;
}

export type CommentaryEvent =
  | 'kickoff'
  | 'pass'
  | 'shot_danger'
  | 'save'
  | 'post'
  | 'goal_home'
  | 'goal_away'
  | 'halftime'
  | 'fulltime';
