export type FoodGroupId = 'vegetables' | 'fruits' | 'grains' | 'protein' | 'dairy';

export interface FoodGroupInfo {
  id: FoodGroupId;
  name: string;
  shortName: string;
  color: string;
  accentColor: string;
  gradient: string;
  bgLight: string;
  icon: string;
  emoji: string;
  tagline: string;
  teenFocus: string;
  teenWhy: string;
  recommendedServings: {
    girls: string;
    boys: string;
    servingExamples: string[];
  };
  keyNutrients: string[];
  topFoods: { name: string; emoji: string; highlight: string }[];
  teenProTip: string;
}

export interface Question {
  id: string;
  foodGroup: FoodGroupId | 'all';
  category: 'fundamentals' | 'teen_growth' | 'sports_energy' | 'myth_busters' | 'plate_balance';
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  teenTip: string;
  xp: number;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface FoodItem {
  id: string;
  name: string;
  emoji: string;
  groupId: FoodGroupId;
  servingSize: string;
  funFact: string;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'quest' | 'streak' | 'blitz' | 'mastery';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

export interface AvatarConfig {
  gender: 'teen_boy' | 'teen_girl' | 'teen_neutral';
  skinTone: string;
  hairStyle: string;
  headwear: string;
  outfit: string;
  expression: 'happy' | 'confident' | 'focused' | 'starry';
}

export interface ShopItem {
  id: string;
  name: string;
  description: string;
  price: number;
  type: 'powerup' | 'headwear' | 'outfit' | 'theme';
  icon: string;
  unlocked?: boolean;
}

export interface PlayerStats {
  totalQuestionsAnswered: number;
  correctAnswers: number;
  blitzHighScore: number;
  platesBuilt: number;
  questsCompleted: number;
  dailyStreak: number;
  lastPlayedDate: string;
}

export interface PlayerState {
  xp: number;
  level: number;
  coins: number;
  streak: number;
  badges: string[];
  unlockedLevels: string[];
  inventory: Record<string, number>;
  avatar: AvatarConfig;
  stats: PlayerStats;
}
