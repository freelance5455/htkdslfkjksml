export interface MilestoneBonus {
  count: number;
  speedMultiplier: number;
  profitMultiplier: number;
  label: string;
}

export interface VentureConfig {
  id: string;
  name: string;
  subtitle: string;
  category: string;
  description: string;
  iconName: string;
  baseCost: number;
  costFactor: number;
  baseRevenue: number;
  baseTimeSec: number;
  colorScheme: {
    accent: string;
    border: string;
    bgGlow: string;
    progressBar: string;
  };
  manager: {
    name: string;
    title: string;
    cost: number;
    quote: string;
    avatarInitials: string;
    avatarColor: string;
  };
  milestones: MilestoneBonus[];
}

export interface VentureState {
  count: number;
  managerHired: boolean;
  progress: number; // 0 to 1
  isRunning: boolean;
  lastRunStart: number; // timestamp
}

export interface Upgrade {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  cost: number;
  currency: 'GOLD' | 'ARCHON';
  targetVentureId: string | 'ALL';
  multiplier: number;
  type: 'PROFIT' | 'SPEED' | 'ARCHON_POWER';
  purchased: boolean;
  lore: string;
  requiredVentureCount?: {
    ventureId: string;
    count: number;
  };
}

export interface RealmAchievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  rewardText: string;
  unlocked: boolean;
  condition: (state: GameSaveState) => boolean;
}

export interface GameSaveState {
  gold: number;
  lifetimeGold: number;
  archons: number;
  lifetimeArchons: number;
  archonBoostPercent: number; // default 2%
  ventures: Record<string, VentureState>;
  purchasedUpgrades: string[];
  unlockedAchievements: string[];
  totalClicks: number;
  ascensionsCount: number;
  lastSavedTime: number;
  numberFormat: 'SUFFIX' | 'SCIENTIFIC';
  soundEnabled: boolean;
  soundVolume: number;
  musicEnabled?: boolean;
  musicVolume?: number;
}

export interface CustomIconRecord {
  ventureId?: string;
  guildmasterId?: string;
  id?: string;
  url: string;
  filename: string;
  name?: string;
  size?: number;
  mimeType?: string;
  updatedAt?: string;
}

export interface CustomIconPreset {
  name: string;
  url: string;
  filename: string;
}

