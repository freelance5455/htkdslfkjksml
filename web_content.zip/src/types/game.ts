export type TileType = 0 | 1 | 2; // 0 = FLOOR, 1 = WALL, 2 = PORTAL

export interface Point {
  x: number;
  y: number;
}

export type HidingType = 'crate' | 'bush' | 'shelter' | 'container';

export interface HidingSpot {
  id: string;
  gridX: number;
  gridY: number;
  x: number; // pixel center
  y: number; // pixel center
  type: HidingType;
  isOccupied: boolean;
  isFake: boolean; // TRUE for Fake Bush (no protection), FALSE for Real Bush (safe immunity)
  revealed?: boolean; // True once tested by player
}

export interface ClimbableWall {
  id: string;
  gridX: number;
  gridY: number;
  sideA: Point; // walkable grid cell before climbing
  sideB: Point; // walkable grid cell on other side
  direction: 'horizontal' | 'vertical';
  isUsed: boolean;
}

export type ChickenAIState = 'patrol' | 'chase' | 'investigate' | 'confused';

export interface Chicken {
  id: string;
  x: number; // pixel coordinates
  y: number;
  vx: number;
  vy: number;
  speed: number;
  state: ChickenAIState;
  patrolRoute: Point[];
  patrolIdx: number;
  path: Point[];
  lastKnownPlayerPos: Point | null;
  investigateTimeRemaining: number;
  alertAnimationTime: number;
  facing: 'left' | 'right' | 'up' | 'down';
  animTick: number;
  colorVariant: number;
  squawkBubble: string | null;
  squawkTimer: number;
  repathTimer?: number;
}

export interface Player {
  x: number; // pixel coordinates
  y: number;
  vx: number;
  vy: number;
  speed: number;
  isHiding: boolean; // True when safely concealed in a REAL bush
  isAtFakeBush?: boolean; // True when inside a FAKE bush (no protection)
  hiddenInSpotId: string | null;
  facing: 'left' | 'right' | 'up' | 'down';
  animTick: number;
  path: Point[]; // waypoints in pixel coordinates
  isPlacingLadder: boolean;
  ladderTimeRemaining: number; // exactly 5.0s countdown
  activeLadderWall: ClimbableWall | null;
  laddersAvailable: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  type: 'dust' | 'feather' | 'sparkle' | 'wood' | 'portal';
}

export interface Camera {
  x: number;
  y: number;
  zoom: number;
}

export type GameState = 'menu' | 'playing' | 'paused' | 'victory' | 'gameover';

export type GameDifficulty = 'easy' | 'normal' | 'hard';

export interface Crystal {
  id: string;
  gridX: number;
  gridY: number;
  x: number;
  y: number;
  color: string;
  glowColor: string;
  name: string;
  collected: boolean;
  cornerName: 'Top-Right' | 'Bottom-Left' | 'Bottom-Right';
}

export interface MazeData {
  width: number;
  height: number;
  tiles: TileType[][];
  portalGrid: Point;
  playerStartGrid: Point;
  safePath: Point[]; // The guaranteed chicken-free path from start to portal
  hidingSpots: HidingSpot[];
  climbableWalls: ClimbableWall[];
  initialChickens: Chicken[];
  crystals: Crystal[];
  portalUnlocked: boolean;
}

export interface GameStats {
  timeElapsed: number;
  chaseCount: number;
  hidesUsed: number;
  laddersUsed: number;
  crystalsCollected: number;
  totalCrystals: number;
  difficulty: GameDifficulty;
  score: number;
}

export interface HighScoreRecord {
  id: string;
  date: string;
  timeSeconds: number;
  difficulty: GameDifficulty;
  score: number;
}
