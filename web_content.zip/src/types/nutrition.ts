export type NutritionLanguage = 'English' | 'Hindi' | 'Marathi';

export type NutritionCategory =
  | 'Disease-wise Diet'
  | 'Healthy Eating'
  | 'Weight Management'
  | 'High Protein Diet'
  | 'Heart Healthy Diet'
  | 'Diabetes Diet'
  | 'High Blood Pressure Diet'
  | 'Kidney Friendly Diet'
  | 'Liver Friendly Diet'
  | 'Low Cholesterol Diet'
  | 'Pregnancy Nutrition'
  | 'Child Nutrition'
  | 'Senior Citizen Nutrition'
  | 'Vitamins & Minerals'
  | 'Hydration Guide';

export interface NutritionFaq {
  question: string;
  answer: string;
}

export interface DiseaseDietDetail {
  diseaseName: string;
  summary: string;
  foodsToEat: string[];
  foodsToAvoid: string[];
  recommendedFruits: string[];
  recommendedVegetables: string[];
  recommendedDrinks: string[];
  proteinSources: string[];
  healthySnacks: string[];
  mealTimingTips: string[];
  lifestyleAdvice: string[];
  faqs: NutritionFaq[];
}

export interface VitaminMineralDetail {
  name: string;
  benefits: string[];
  foodSources: string[];
  deficiencySymptoms: string[];
  dailyRequirement: string;
}

export interface WeightManagementDetail {
  title: string;
  bmiInfo: string;
  dietTips: string[];
  recommendedFoods: string[];
  foodsToLimit: string[];
}

export interface HydrationDetail {
  dailyWaterIntake: string;
  hydrationTips: string[];
  electrolytesAndOrs: string;
  signsOfDehydration: string[];
}

export interface NutritionDetailContent {
  title: string;
  categoryName: string;
  summary: string;
  // Specific payload types based on category
  diseaseDiet?: DiseaseDietDetail;
  vitaminMineral?: VitaminMineralDetail;
  weightManagement?: WeightManagementDetail;
  hydration?: HydrationDetail;
}

export interface NutritionItem {
  id: string;
  category: NutritionCategory;
  categoryEmoji: string;
  bgGradient: string;
  badgeBg: string;
  badgeText: string;
  content: {
    English: NutritionDetailContent;
    Hindi: NutritionDetailContent;
    Marathi: NutritionDetailContent;
  };
}
