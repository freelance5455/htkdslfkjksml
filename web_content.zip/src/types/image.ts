export type ImageEngineId =
  | "imagen-3"
  | "midjourney-v6"
  | "flux-1-pro"
  | "openart-ai"
  | "meta-imagine"
  | "dalle-3"
  | "sd-3-5-large"
  | "gemini-flash-image";

export type ImageAspectRatio = "16:9" | "9:16" | "1:1" | "4:5" | "3:2" | "21:9";

export type ImageResolution = "1024x1024" | "1080p" | "2K" | "4K";

export type ImageCameraLens =
  | "16MM_WIDE"
  | "35MM_CINEMA"
  | "50MM_PRIME"
  | "85MM_PORTRAIT"
  | "100MM_MACRO"
  | "200MM_TELEPHOTO"
  | "FISHEYE";

export type ImageLightingSetup =
  | "GOLDEN_HOUR"
  | "STUDIO_SOFTBOX"
  | "NEON_CYBERPUNK"
  | "DRAMATIC_RIM"
  | "OVERCAST_NATURAL"
  | "CHIAROSCURO"
  | "VOLUMETRIC_SUNBEAMS"
  | "BIOLUMINESCENT";

export type ImageVisualStyle =
  | "PHOTOREALISTIC"
  | "CINEMATIC"
  | "3D_OCTANE"
  | "CONCEPT_ART"
  | "ANIME_STUDIO"
  | "OIL_PAINTING"
  | "EDITORIAL_FASHION"
  | "MINIMALIST_VECTOR"
  | "CYBERPUNK_NEON";

export interface ImageEngineConfig {
  id: ImageEngineId;
  name: string;
  provider: string;
  badge: string;
  description: string;
  highlight: string;
  color: string;
  maxResolution: string;
  defaultAspectRatio: ImageAspectRatio;
  aspectRatios: ImageAspectRatio[];
  supportsInpainting: boolean;
  supportsNegativePrompt: boolean;
  supportsTextRendering: boolean;
  estimatedCostPerImage: number;
  qualityTier: "Ultra" | "High" | "Fast";
}

export interface ImageGenerationOptions {
  prompt: string;
  negativePrompt?: string;
  optimizedPrompt?: string;
  engine: ImageEngineId;
  aspectRatio: ImageAspectRatio;
  resolution: ImageResolution;
  style: ImageVisualStyle;
  lens: ImageCameraLens;
  lighting: ImageLightingSetup;
  guidanceScale?: number;
  samplingSteps?: number;
  seed?: number;
  sceneId?: string;
  sceneNumber?: number;
  projectId?: string;
  projectTitle?: string;
  isThumbnail?: boolean;
}

export interface ImageGenerationResult {
  id: string;
  imageUrl: string;
  thumbnailUrl?: string;
  engine: ImageEngineId;
  engineName: string;
  prompt: string;
  optimizedPrompt?: string;
  negativePrompt?: string;
  aspectRatio: ImageAspectRatio;
  resolution: ImageResolution;
  style: ImageVisualStyle;
  lens: ImageCameraLens;
  lighting: ImageLightingSetup;
  sceneId?: string;
  sceneNumber?: number;
  projectId?: string;
  projectTitle?: string;
  isThumbnail?: boolean;
  status: "COMPLETED" | "FAILED";
  createdAt: string;
  metadata?: {
    renderEngine: string;
    seed: number;
    renderTimeSec: string;
    guidanceScale: number;
    samplingSteps: number;
    modelChecksum?: string;
  };
}

export interface ImagePromptOptimizationResult {
  prompt: string;
  negativePrompt: string;
  photographyDirectives: string;
  lightingSetup: string;
  engineSpecificKeywords: string[];
}
