export type MythLanguage = 'English' | 'Hindi' | 'Marathi';

export interface MythContent {
  myth: string;
  fact: string;
  explanation: string;
  healthTip: string;
  reference: string;
}

export interface MythItem {
  id: string;
  categoryId: string;
  tags: string[];
  content: Record<MythLanguage, MythContent>;
}

export interface MythCategoryMeta {
  id: string;
  emoji: string;
  iconBg: string;
  badgeBg: string;
  nameEn: string;
  nameHi: string;
  nameMr: string;
  descriptionEn: string;
  descriptionHi: string;
  descriptionMr: string;
}
