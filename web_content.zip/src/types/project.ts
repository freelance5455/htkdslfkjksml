import { VideoSegment, SplitMode } from '../utils/videoMath';

export type { VideoSegment, SplitMode };

export type AspectRatioType = 'original' | '9:16' | '16:9' | '1:1' | '4:5';

export type FilterType = 'normal' | 'cinematic' | 'vibrant' | 'gold' | 'bw' | 'vintage' | 'warm';

export interface TextOverlay {
  id: string;
  text: string;
  position: 'top' | 'center' | 'bottom';
  fontSize: number; // in px
  color: string;
  bgColor: string;
  hasBackground: boolean;
  isSubtitle?: boolean;
}

export interface VideoProject {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  videoUrl: string;
  videoFileName: string;
  duration: number;
  width: number;
  height: number;
  aspectRatio: AspectRatioType;
  blurBackground: boolean;
  filter: FilterType;
  brightness: number; // 0.5 to 1.5, default 1
  contrast: number;   // 0.5 to 1.5, default 1
  saturation: number; // 0 to 2, default 1
  speed: number;      // 0.5 to 2, default 1
  volume: number;     // 0 to 1, default 1
  isMuted: boolean;
  watermarkText: string;
  textOverlays: TextOverlay[];
  templateId?: string;
  ttsAudioUrl?: string;
  splitSettings?: {
    mode: SplitMode;
    value: number;
  };
}

export interface VideoTemplate {
  id: string;
  nameAr: string;
  nameEn: string;
  category: 'social' | 'creative' | 'business' | 'news_sports';
  descriptionAr: string;
  descriptionEn: string;
  aspectRatio: AspectRatioType;
  blurBackground: boolean;
  filter: FilterType;
  defaultTitle: string;
  badgeText: string;
  accentColor: string;
  bgGradient: string;
  features: string[];
}

export interface AIExecutionPlan {
  summaryArabic: string;
  summaryEnglish: string;
  actions: {
    split: {
      enabled: boolean;
      mode: 'duration' | 'count' | 'none';
      value: number;
    };
    aspectRatio: AspectRatioType;
    blurBackground: boolean;
    title: string;
    subtitles: string;
    filter: FilterType;
    speed: number;
    volume: number;
    watermarkText: string;
    templateId: string;
  };
}
