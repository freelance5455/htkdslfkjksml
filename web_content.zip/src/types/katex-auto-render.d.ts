declare module 'katex/contrib/auto-render' {
  interface RenderOptions {
    delimiters?: { left: string; right: string; display: boolean }[];
    throwOnError?: boolean;
    strict?: boolean | string | ((errorCode: string, errorMsg: string) => string | boolean);
    ignoredTags?: string[];
    errorCallback?: (msg: string, err: Error) => void;
  }
  export default function renderMathInElement(element: HTMLElement, options?: RenderOptions): void;
}
