export interface TikTokAuthor {
  id: string;
  unique_id: string;
  nickname: string;
  avatar: string;
}

export interface TikTokMusic {
  id: string;
  title: string;
  author: string;
  album: string;
  play_url: string;
  duration: number;
}

export interface TikTokVideoData {
  id: string;
  title: string;
  cover: string;
  origin_cover?: string;
  duration: number;
  play: string;
  wmplay?: string;
  hdplay?: string;
  size?: number;
  wm_size?: number;
  hd_size?: number;
  music?: string;
  music_info?: TikTokMusic;
  play_count?: number;
  digg_count?: number;
  comment_count?: number;
  share_count?: number;
  download_count?: number;
  author: TikTokAuthor;
  images?: string[];
  create_time?: number;
}

export interface HistoryItem {
  id: string;
  title: string;
  cover: string;
  authorName: string;
  authorUsername: string;
  playUrl: string;
  downloadedAt: number;
}

export type SupportedLanguage = 'en' | 'ur' | 'hi' | 'es' | 'ar';
