export type FlashlightMode = 'main' | 'screen' | 'strobe' | 'sos' | 'hazard';

export interface LightColorPreset {
  id: string;
  name: string;
  czDescription: string;
  hex: string;
  glowColor: string;
  textColor: string;
  category: 'neon' | 'standard' | 'night' | 'tactical' | 'emergency';
}

export const LIGHT_COLOR_PRESETS: LightColorPreset[] = [
  {
    id: 'neon-cyan',
    name: 'Neon Cyan',
    czDescription: 'Ikonický neonový paprsek NeonBeam s vysokým kontrastem',
    hex: '#00F0FF',
    glowColor: 'rgba(0, 240, 255, 0.65)',
    textColor: '#021319',
    category: 'neon',
  },
  {
    id: 'cool-white',
    name: 'Ultra White',
    czDescription: '6500K · Maximální luminační výkon a jasné bílé světlo',
    hex: '#FFFFFF',
    glowColor: 'rgba(255, 255, 255, 0.7)',
    textColor: '#000000',
    category: 'standard',
  },
  {
    id: 'neon-amber',
    name: 'Neon Amber',
    czDescription: 'Zlatý neonový paprsek šetrný k očím',
    hex: '#FFB703',
    glowColor: 'rgba(255, 183, 3, 0.65)',
    textColor: '#261500',
    category: 'neon',
  },
  {
    id: 'warm-candle',
    name: 'Teplá svíčka',
    czDescription: '2200K · Měkké relaxační ambientní světlo',
    hex: '#FF9500',
    glowColor: 'rgba(255, 149, 0, 0.6)',
    textColor: '#291200',
    category: 'standard',
  },
  {
    id: 'oled-red',
    name: 'OLED Noční červená',
    czDescription: 'Zachovává přizpůsobení nočnímu vidění (neruší spánek)',
    hex: '#FF0033',
    glowColor: 'rgba(255, 0, 51, 0.75)',
    textColor: '#FFFFFF',
    category: 'night',
  },
  {
    id: 'tactical-emerald',
    name: 'Taktická zelená',
    czDescription: 'Čtení map potmě bez odrazu a oslnění okolí',
    hex: '#00FF66',
    glowColor: 'rgba(0, 255, 102, 0.65)',
    textColor: '#00260f',
    category: 'tactical',
  },
  {
    id: 'cyber-magenta',
    name: 'Cyber Magenta',
    czDescription: 'Výrazný neonový purpur pro párty a ambientní osvětlení',
    hex: '#E024FF',
    glowColor: 'rgba(224, 36, 255, 0.65)',
    textColor: '#FFFFFF',
    category: 'neon',
  },
  {
    id: 'hazard-yellow',
    name: 'Výstražná žlutá',
    czDescription: 'Vysoká pronikavost v mlze a nouzová signalizace',
    hex: '#FFEE00',
    glowColor: 'rgba(255, 238, 0, 0.7)',
    textColor: '#2e2700',
    category: 'emergency',
  },
];
