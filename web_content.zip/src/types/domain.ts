export type OperationalStatus = 'completato' | 'in_corso' | 'in_revisione' | 'critico';
export type MaintenanceOutcome = 'positivo' | 'negativo' | 'in_attesa_collaudo';
export type MaintenancePlantLine =
  | 'LINEA 1'
  | 'LINEA 2'
  | 'LINEA 3'
  | 'LINEA 4'
  | 'LINEA 6'
  | 'POLIN'
  | 'ALTRO';

export type MaintenanceType =
  | 'Programmata Ordinaria'
  | 'Riparazione Guasto Straordinaria'
  | 'Sostituzione Ugelli / Tubazioni'
  | 'Revisione Pompa Airless / Pistoni'
  | 'Sostituzione Filtri a Maniche / Cartucce'
  | 'Taratura Pressioni e Manometri'
  | 'Altro';

export interface SparePartUsed {
  id: string;
  code: string;
  description: string;
  quantity: number;
  unit: string; // 'pz', 'kg', 'm', 'kit', 'l'
  notes?: string;
}

export interface MaintenanceReport {
  id: string;
  protocolNumber: string; // e.g. "MAN-2026-0042"
  date: string; // YYYY-MM-DD
  time?: string;
  plantName: MaintenancePlantLine | string; // Nome Impianto: LINEA 1, LINEA 2, LINEA 3
  equipmentServiced: string; // Attrezzatura revisionata (campo descrittivo manuale)
  interventionType: MaintenanceType;
  outcome: MaintenanceOutcome;
  timeSpentHours: number;
  timeSpentMinutes: number;
  description: string;
  spareParts: SparePartUsed[];
  operatorName: string;
  supervisorName?: string;
  images: MaintenanceImage[];
  createdAt: string;
  updatedAt: string;
}

export interface MaintenanceImage {
  id: string;
  url: string;
  caption: string;
  tag: 'Guasto / Anomalia' | 'Pezzo Usurato' | 'Ricambio Installato' | 'Impianto Ripristinato' | 'Collaudo Finale';
  uploadedAt: string;
  fileName?: string;
}

// ======================== PAINTING REPORT SPEC ========================

export interface WeatherCondition {
  date: string;
  airTemperature: number; // °C
  surfaceTemperature: number; // °C
  relativeHumidity: number; // %
  dewPoint: number; // °C (Calcolato automaticamente)
  isDeltaOk: boolean; // T_surface >= DewPoint + 3°C
  statusText: 'OK' | 'NON CONFORME (Rischio Condensa)';
}

export interface CoatingLayer {
  id: string;
  coatNumber: number;
  coatType: '1 - PRIMER' | '2 - INTERMEDIATE' | '3 - INTERMEDIATE' | '4 - FINISH';
  requiredDftUm: number; // REQ'D DFT XX µm
  paintName: string;
  batchCompA: string;
  batchCompB: string;
  color: string;
  applicationMethod: 'AIRLESS' | 'Misto Aria / Airmix' | 'Tazza a Gravità' | 'Rullo / Pennello';
  date: string;
  airTemp: number; // °C
  relativeHumidity: number; // %
  surfaceTemp: number; // °C
  dewPoint: number; // Calcolato automaticamente
  dftMeasured: {
    min: number; // µm
    med: number; // µm
    max: number; // µm
  };
  visualCheck: 'OK' | 'KO' | 'N.A.';
  dftCheck: 'OK' | 'KO' | 'N.A.';
  pullOffTest: string; // e.g. "OK", "> 5 MPa", "N.A."
}

export interface PaintingReport {
  id: string;
  reportNumber: string; // es. "2026/089/PRD"
  date: string;
  documentRev: string; // "MOD. RV-U Rev 0 del 12/04/2013"

  // DATI IDENTIFICATIVI / Identification Data
  client: string; // CLIENTE
  subSupplier: string; // SUBFORNITORE (es. Sfiller Sabbiatura & Verniciatura)
  jobSerialNumber: string; // COMMESSA-MATRICOLA
  purchaseOrderNumber: string; // N.ORDINE-POS.
  itemName: string; // DENOMINAZIONE ITEM

  // PREPARAZIONE SUPERFICIALE / Surface Preparation
  surfacePreparationStd: string; // default "ISO 8501-3"
  abrasiveTypeMesh: string; // default "Garnet"
  abrasiveContaminants: string; // default "Dry, clean and free from oil, grease and other contaminants"
  incisionProfile: string; // RUGOSITÀ, es. "MEDIUM G", "50 µm"
  blastCleaningGrade: string; // PULIZIA SUPERFICIALE, es. "S.A. 2 1/2"
  dustTestingGrade: string; // CONTAMINAZIONE POLVERE, es. "1 - ISO 8502-3"
  surfacePrepWeather: WeatherCondition;

  // VERNICIATURA / Coating
  paintingSpecification: string; // SPECIFICA DI VERNICIATURA
  paintSystem: string; // CICLO
  layers: CoatingLayer[];

  // NOTE / Remarks & Instruments
  instrumentNotes: string; // es. Spessimetro PosiTector 6000...
  generalRemarks?: string;

  // COLLAUDO & FIRME / Signoffs
  signoffs: {
    companyInspection: {
      name: string;
      date: string;
      signed: boolean;
    };
    qualityControl: {
      name: string;
      date: string;
      signed: boolean;
    };
    inspectionAgency?: {
      name: string;
      date?: string;
      signed?: boolean;
    };
    customerInspector?: {
      name: string;
      date?: string;
      signed?: boolean;
    };
  };

  // FOTOGRAFIE ALLEGATE
  images: PaintingReportImage[];

  createdAt: string;
  updatedAt: string;
}

export interface PaintingReportImage {
  id: string;
  url: string;
  caption: string;
  stage: 'Preparazione Superficiale SA 2.5' | 'Profilo Rugosità' | 'Primer' | 'Intermedio' | 'Finitura' | 'Controllo DFT / Collaudo';
  uploadedAt: string;
  fileName?: string;
}

// ======================== PROCEDURE & REPORT LIBERI (BLOCCHI PERSONALIZZATI) ========================

export type ProcedureBlockType = 'title' | 'text' | 'photo' | 'signature';

export interface ProcedureBlock {
  id: string;
  type: ProcedureBlockType;
  // Per tipo 'title' (Titolo di sezione / intestazione)
  titleText?: string;
  subtitleText?: string;
  // Per tipo 'text' (Didascalia / Istruzione / Testo libero)
  bodyText?: string;
  // Per tipo 'photo' (Foto con didascalia)
  photoUrl?: string;
  photoCaption?: string;
  photoTag?: string;
  // Per tipo 'signature' (Spazio per la firma con il dito su canvas)
  signatureDataUrl?: string; // Base64 PNG drawn on touch canvas
  signerName?: string;
  signerRole?: string;
  signedAt?: string;
}

export type ProcedureCategory =
  | 'Procedura Operativa'
  | 'Scheda Tecnica Libera'
  | 'Report Fotografico Ispezione'
  | 'Istruzione di Lavoro'
  | 'Verbale di Consegna & Firma'
  | 'Non Conformità & Riparazione'
  | 'Altro';

export type ProcedureLayout =
  | 'report_and_run' // Formato Report & Run standard (schede step con foto e didascalie numerate)
  | 'grid_2col' // Griglia a 2 colonne (Foto + Didascalia a fronte)
  | 'photo_compact' // Griglia compatta 3x (Album fotografico numerato con didascalie)
  | 'technical_table'; // Tabella tecnica di lavorazione

export interface ProcedureImage {
  id: string;
  photoNumber: number; // Numerazione progressiva (1, 2, 3, 4...)
  url: string;
  caption: string; // Didascalina in ordine numerico
  tag?: 'Evidenza Conforme' | 'Dettaglio Tecnico' | 'Non Conformità' | 'Prima Lavorazione' | 'Durante Lavorazione' | 'Collaudo Finale' | 'Altro';
  uploadedAt: string;
}

export interface ProcedureStep {
  id: string;
  stepNumber: number; // Ordine numerico (1, 2, 3...)
  title: string; // Titolo fase / step
  description: string; // Descrizione istruzioni
  checkpoints?: string; // Parametri tecnici e criteri accettazione
  compliance?: 'conforme' | 'non_conforme' | 'in_corso' | 'na';
  images: ProcedureImage[];
}

export interface ProcedureReport {
  id: string;
  code: string; // es. "DOC-2026-004" o "SOP-01"
  title: string; // Titolo procedura o scheda libera
  category: ProcedureCategory | string;
  plantLine?: MaintenancePlantLine | string;
  client?: string;
  jobOrder?: string;
  date: string;
  revision: string; // es. "Rev. 00", "Rev. 01"
  status: 'bozza' | 'approvato' | 'in_revisione' | 'archiviato';
  author: string;
  approver?: string;
  scope?: string; // Scopo / Obiettivo opzionale
  safetyNotes?: string; // DPI e precauzioni opzionali
  preferredLayout?: ProcedureLayout; // Scegliere il formato a video
  // I blocchi componibili liberamente dall'utente in qualsiasi ordine e quantità
  blocks?: ProcedureBlock[];
  // Retrocompatibilità per step legacy
  steps?: ProcedureStep[];
  createdAt: string;
  updatedAt: string;
}

