export interface SecurityOptions {
  lockTaskMode: boolean;
  flagSecure: boolean;
  blockSplitScreen: boolean;
  detectFloatingApps: boolean;
  muteAudio: boolean;
  blockBackNavigation: boolean;
  clearDataOnExit: boolean;
  kioskSoundAlarm: boolean;
  requireToken: boolean;
  examToken: string;
}

export interface ExambroConfig {
  appName: string;
  schoolName: string;
  examTitle: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  examUrl: string;
  exitPin: string;
  durationMinutes: number;
  maxViolationsBeforeLock: number;
  allowedDomains: string[];
  security: SecurityOptions;
}

export type ViolationType =
  | 'TAB_SWITCH'
  | 'FULLSCREEN_EXIT'
  | 'SHORTCUT_BLOCKED'
  | 'FOCUS_LOST'
  | 'SPLIT_SCREEN'
  | 'CONTEXT_MENU';

export interface ViolationEvent {
  id: string;
  timestamp: string;
  type: ViolationType;
  detail: string;
}

export const DEFAULT_EXAMBRO_CONFIG: ExambroConfig = {
  appName: 'Exambro MTs Inayatul Marzuki',
  schoolName: 'MTs Inayatul Marzuki',
  examTitle: 'Asesmen Akhir Semester Tahun 2026-2027',
  packageName: 'sch.id.mtsinayatulmarzuki.exambro',
  versionName: '1.0.0',
  versionCode: 1,
  examUrl:
    'https://ulanganmtsinayatulmarzuki.blogspot.com/2026/11/asesmen-akhir-sesmester-tahun-2026-2027.html',
  exitPin: '202611',
  durationMinutes: 90,
  maxViolationsBeforeLock: 3,
  allowedDomains: [
    'ulanganmtsinayatulmarzuki.blogspot.com',
    'docs.google.com',
    'forms.gle',
    'accounts.google.com',
    'googleusercontent.com',
    'gstatic.com',
  ],
  security: {
    lockTaskMode: true,
    flagSecure: true,
    blockSplitScreen: true,
    detectFloatingApps: true,
    muteAudio: true,
    blockBackNavigation: true,
    clearDataOnExit: true,
    kioskSoundAlarm: true,
    requireToken: false,
    examToken: 'IM2026',
  },
};
