export type AccentColor = 'emerald' | 'blue' | 'violet' | 'rose' | 'amber';

export interface UserProfile {
  name: string;
  avatar: string;
  goal: string;
}

export interface AccentColorDef {
  id: AccentColor;
  name: string;
  primary: string; // hex
  lightBg: string;
  border: string;
  gradient: string;
}

export const ACCENT_COLORS: AccentColorDef[] = [
  {
    id: 'emerald',
    name: 'زمردي',
    primary: '#10b981',
    lightBg: 'rgba(16, 185, 129, 0.15)',
    border: 'rgba(16, 185, 129, 0.35)',
    gradient: 'from-emerald-500 to-teal-400',
  },
  {
    id: 'blue',
    name: 'أزرق',
    primary: '#3b82f6',
    lightBg: 'rgba(59, 130, 246, 0.15)',
    border: 'rgba(59, 130, 246, 0.35)',
    gradient: 'from-blue-500 to-cyan-400',
  },
  {
    id: 'violet',
    name: 'بنفسجي',
    primary: '#8b5cf6',
    lightBg: 'rgba(139, 92, 246, 0.15)',
    border: 'rgba(139, 92, 246, 0.35)',
    gradient: 'from-violet-500 to-purple-400',
  },
  {
    id: 'rose',
    name: 'وردي',
    primary: '#f43f5e',
    lightBg: 'rgba(244, 63, 94, 0.15)',
    border: 'rgba(244, 63, 94, 0.35)',
    gradient: 'from-rose-500 to-pink-400',
  },
  {
    id: 'amber',
    name: 'ذهبي',
    primary: '#f59e0b',
    lightBg: 'rgba(245, 158, 11, 0.15)',
    border: 'rgba(245, 158, 11, 0.35)',
    gradient: 'from-amber-500 to-yellow-400',
  },
];
