export type AssetType = 'OTC' | 'MARKET';

export interface Asset {
  id: string;
  symbol: string;
  name: string;
  type: AssetType;
  payout: number; // e.g. 94 for 94%
  currentPrice: number;
  decimals: number;
  volatility: number;
  category: 'Forex' | 'Crypto' | 'Commodity' | 'Indices';
  isHot?: boolean;
}

export type Timeframe = '5s' | '30s' | '1 Minute' | '2 Minutes' | '3 Minutes' | '5 Minutes' | '10 Minutes' | '15 Minutes';

export interface IndicatorConfig {
  rsi: {
    enabled: boolean;
    period: number;
    overbought: number;
    oversold: number;
    weight: number;
  };
  bollingerBands: {
    enabled: boolean;
    period: number;
    stdDev: number;
    weight: number;
  };
  macd: {
    enabled: boolean;
    fastPeriod: number;
    slowPeriod: number;
    signalPeriod: number;
    weight: number;
  };
  emaCross: {
    enabled: boolean;
    fastPeriod: number;
    slowPeriod: number;
    trendPeriod: number;
    weight: number;
  };
  stochastic: {
    enabled: boolean;
    kPeriod: number;
    dPeriod: number;
    overbought: number;
    oversold: number;
    weight: number;
  };
  supportResistance: {
    enabled: boolean;
    lookbackCandles: number;
    weight: number;
  };
  candlestickPatterns: {
    enabled: boolean;
    checkHammer: boolean;
    checkEngulfing: boolean;
    checkPinBar: boolean;
    weight: number;
  };
}

export interface BotSettings {
  strongSniperMode99: boolean; // "Giving a strong single bot 99%"
  autoExecute: boolean;
  stakeAmount: number;
  martingaleMode: 'none' | '1_step' | '2_step';
  martingaleMultiplier: number;
  stopLossAmount: number;
  takeProfitAmount: number;
  quotexWebhookUrl: string;
  quotexAccountId: string;
  soundEnabled: boolean;
  minConfidenceThreshold: number; // e.g. 90%
  fastAnalysis: boolean; // Ultra-fast signal calculation
}

export interface TriggeredIndicator {
  name: string;
  status: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  value: string;
  note: string;
  confluenceMet: boolean;
}

export interface QuantumSignal {
  id: string;
  pair: string;
  assetType: AssetType;
  direction: 'UP' | 'DOWN';
  action: 'BUY (LONG)' | 'SELL (PUT)';
  timeframe: Timeframe;
  strength: number; // 1 to 5
  confidence: number; // e.g. 99.2%
  isStrongSniper99: boolean;
  entryCandleTime: string; // e.g. "21:55:00"
  expiryTime: string; // e.g. "21:56:00"
  entryInSeconds: number;
  tradeEndsInSeconds: number;
  targetPrice: number;
  candlestickPattern: string;
  trend: string;
  keyPriceLevel: string;
  summaryInstruction: string;
  howToFollow: string;
  indicators: TriggeredIndicator[];
  createdAt: number;
  // Deep Market Intelligence Additions
  supportLevel?: number;
  resistanceLevel?: number;
  buyerPressure?: number; // e.g. 24%
  sellerPressure?: number; // e.g. 76%
  marketRegime?: 'STRONG_TREND' | 'REVERSAL_ZONE' | 'RANGING_SIDEWAYS' | 'BREAKOUT';
  marketRegimeLabel?: string;
  trendStrengthScore?: number; // 0-100
  mtfConfirmation?: {
    timeframe5s: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    timeframe1m: 'BULLISH' | 'BEARISH';
    timeframe5m: 'BULLISH' | 'BEARISH';
  };
  wickRejectionScore?: string;
  orderFlowBias?: string;
  isTradeSafe?: boolean;
  qualityGrade?: 'A+' | 'A' | 'B' | 'WAIT';
  safetyMarginZone?: string;
  mtgStepAdvice?: string;
  confluenceChecks?: { name: string; passed: boolean; detail: string }[];
}

export interface TradeOrder {
  id: string;
  signalId?: string;
  pair: string;
  direction: 'UP' | 'DOWN';
  action: 'BUY (LONG)' | 'SELL (PUT)';
  timeframe: Timeframe;
  entryPrice: number;
  currentPrice: number;
  exitPrice?: number;
  stake: number;
  payoutPercent: number;
  potentialProfit: number;
  actualProfit?: number;
  status: 'OPEN' | 'WON' | 'LOST';
  openedAt: number;
  expiresAt: number;
  secondsRemaining: number;
  isSniper99: boolean;
  mode: 'DEMO' | 'WEBHOOK';
}

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}
