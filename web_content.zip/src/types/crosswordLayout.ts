export type LayoutDirection = 'across' | 'down';

export interface LayoutCellCoordinate {
  row: number;
  col: number;
}

export interface CrosswordLayoutCell {
  row: number;
  column: number;
  isBlocked: boolean;
  letter: string; // Normalized character if playable cell, or empty string if blocked
  acrossWordId?: string;
  downWordId?: string;
  clueNumber?: number;
}

export interface CrosswordLayoutWord {
  id: string;
  clue: string;
  answer: string;
  normalizedAnswer: string;
  direction: LayoutDirection;
  startRow: number;
  startColumn: number;
  length: number;
  cells: LayoutCellCoordinate[];
  number: number;
  reversed?: boolean;
}

export interface CrosswordLayoutClue {
  id: string;
  number: number;
  direction: LayoutDirection;
  clue: string;
  answer: string;
}

export interface CrosswordLayout {
  gridRows: number;
  gridColumns: number;
  cells: CrosswordLayoutCell[];
  words: CrosswordLayoutWord[];
  blackCells: LayoutCellCoordinate[];
  clues: CrosswordLayoutClue[];
  metadata?: {
    totalWords: number;
    placedWords: number;
    intersectionsCount: number;
    blackCellsCount: number;
    generatedAt: string;
  };
}

export interface ValidationItem {
  key: string;
  label: string;
  passed: boolean;
  message?: string;
}

export interface ValidationResult {
  isValid: boolean;
  statusMessage: 'VALID GOLDEN LAYOUT' | 'INVALID LAYOUT';
  items: ValidationItem[];
  stats: {
    wordsCount: number;
    placedCount: number;
    intersectionsCount: number;
    gridSize: string;
    blackCellsCount: number;
    isConnected: boolean;
    unintendedWordsCount: number;
  };
}
