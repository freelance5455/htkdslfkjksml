export type Direction = 'horizontal' | 'vertical';

export interface GridPosition {
  row: number;
  col: number;
}

export interface CrosswordWord {
  id: string; // e.g. "h_1", "v_2"
  number: number; // Clue number in newspaper grid
  direction: Direction;
  clue: string;
  answer: string; // Authoritative Arabic answer (e.g. "عراق")
  startPos: GridPosition;
  length: number;
  reversed?: boolean; // If true, player enters letters in reverse order
}

export type CrosswordQuestion = CrosswordWord;

export interface GridCell {
  row: number;
  col: number;
  isBlocked: boolean;
  number?: number; // Clue start number shown in top-corner
  horizontalWordId?: string;
  verticalWordId?: string;
  userChar: string;
  status?: 'correct' | 'incorrect' | 'unchecked';
}

export interface Stage {
  id: number;
  title: string;
  gridSize: {
    rows: number;
    cols: number;
  };
  questions: CrosswordQuestion[]; // Exactly 25 questions per stage
  blockedCells: GridPosition[];
}

export interface StageProgress {
  stageId: number;
  completed: boolean;
  userAnswers: { [cellKey: string]: string }; // "row_col": "char"
  completedQuestionIds: string[];
  lastPlayedTimestamp: number;
  hintsUsed?: number; // Number of hints used in current stage session (0 to 3)
  bestStars?: number; // Highest star rating achieved for this stage (0 to 3)
}

export interface PlayerSettings {
  sound: boolean;
  effects: boolean;
  vibration: boolean;
}

export interface PlayerProgress {
  unlockedStageId: number; // Highest unlocked stage (1 to 50)
  currentStageId: number;  // Last played stage
  stageProgresses: { [stageId: number]: StageProgress };
  settings: PlayerSettings;
}
