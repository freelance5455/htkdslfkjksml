export type Language = 'bn' | 'en';

export type TabId = 'routine' | 'pomodoro' | 'timer' | 'stats' | 'blocker' | 'alarms';

export type DayFilter =
  | 'all'
  | 'প্রতিদিন'
  | 'শনিবার'
  | 'রবিবার'
  | 'সোমবার'
  | 'মঙ্গলবার'
  | 'বুধবার'
  | 'বৃহস্পতিবার'
  | 'শুক্রবার';

export interface RoutineItem {
  id: string;
  day: Exclude<DayFilter, 'all'>;
  startTime: string;
  endTime: string;
  subject: string;
  topic: string;
  completed: boolean;
  createdAt: number;
}

export type PomodoroPhase = 'study' | 'shortBreak' | 'longBreak';

export interface AlarmSlot {
  id: number; // 1 to 20
  name: string;
  time: string; // HH:MM (24h)
  enabled: boolean;
  repeat: 'daily' | 'once';
  lastTriggeredDateKey?: string;
}

export interface LapRecord {
  id: number;
  lapTimeMs: number;
  totalTimeMs: number;
}

export interface RingingAlert {
  id: string;
  title: string;
  subtitle: string;
  kind: 'alarm' | 'pomodoro' | 'timer';
  alarmId?: number;
}

export type WallpaperId = 'aurora' | 'emerald' | 'twilight';

export interface BlockedAppItem {
  id: string;
  name: string;
  category: string;
  blocked: boolean;
  isCustom?: boolean;
}

export type DailyStudyLog = Record<string, number>; // YYYY-MM-DD -> total seconds studied

export interface DailyBreakdownEntry {
  timer: number; // seconds Timer/Stopwatch ran
  pomodoro: number; // seconds Pomodoro ran
}

export type DailyStudyBreakdown = Record<string, DailyBreakdownEntry>;

