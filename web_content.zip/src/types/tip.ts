export type TipLanguage = 'English' | 'Hindi' | 'Marathi';

export interface TipContent {
  title: string;
  tip: string;
  explanation: string;
  benefits: string[];
  recommendedFrequency: string;
  source: string;
}

export interface HealthTipItem {
  id: string;
  categoryId: string;
  tags: string[];
  content: Record<TipLanguage, TipContent>;
}

export interface TipCategoryMeta {
  id: string;
  emoji: string;
  iconBg: string;
  badgeBg: string;
  nameEn: string;
  nameHi: string;
  nameMr: string;
  descriptionEn: string;
  descriptionHi: string;
  descriptionMr: string;
}
