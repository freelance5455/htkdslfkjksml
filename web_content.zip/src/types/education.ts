export type AgeGroup = '5-7' | '8-10';
export type EducationTab = 'letters' | 'math' | 'science' | 'stories' | 'videos' | 'quiz' | 'quizzes' | 'whiteboard';

export interface ChildProfile {
  name: string;
  age?: number;
  ageGroup: AgeGroup;
  avatar?: string;
  stars?: number;
  starsCount: number;
  soundEnabled: boolean;
  completedLessons?: string[];
  completedActivities?: string[];
  currentLevel?: number;
  badges?: Badge[];
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
}

export interface LetterData {
  letter: string;
  name: string;
  transliteration: string;
  withFatha: string;
  withDamma: string;
  withKasra: string;
  withSukun: string;
  exampleWord: string;
  exampleTashkeel: string;
  exampleEmoji: string;
  exampleMeaning: string;
  color: string;
}

export interface WordData {
  id: string;
  word: string;
  tashkeel: string;
  category: 'animals' | 'fruits' | 'nature' | 'professions' | 'home';
  categoryAr: string;
  emoji: string;
  meaning: string;
  letters: string[];
  ageGroup: AgeGroup;
}

export interface SentenceExercise {
  id: string;
  sentence: string;
  words: string[];
  scrambledWords: string[];
  meaning: string;
  emoji: string;
  ageGroup: AgeGroup;
}

export type MathMode = 'counting' | 'addition' | 'subtraction' | 'multiplication' | 'place_value';

export interface PlaceValueProblem {
  id: string;
  number: number;
  thousands: number;
  hundreds: number;
  tens: number;
  units: number;
  question: string;
  highlightedPlace: 'units' | 'tens' | 'hundreds' | 'thousands';
  options: number[];
  correctAnswer: number;
  explanation: string;
}

export interface ScienceLesson {
  id: string;
  title: string;
  category: 'space' | 'body' | 'plants' | 'animals' | 'experiments' | 'matter';
  categoryAr: string;
  icon: string;
  coverColor: string;
  ageGroup: AgeGroup;
  summary: string;
  sections: {
    heading: string;
    text: string;
    details?: string[];
    visualType?: 'diagram' | 'cards' | 'experiment';
    visualItems?: { name: string; icon: string; desc: string }[];
  }[];
  interactiveFact: string;
  quizQuestion: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
}

export interface StoryPage {
  text: string;
  audioNarration: string;
  illustration: string;
  sceneEmoji: string;
}

export interface Story {
  id: string;
  title: string;
  category: string;
  ageGroup: AgeGroup;
  moral: string;
  coverEmoji: string;
  pages: StoryPage[];
  questions: {
    question: string;
    options: string[];
    correctIndex: number;
    rewardStars: number;
  }[];
}

export interface VideoItem {
  id: string;
  title: string;
  category: 'letters' | 'math' | 'science' | 'stories';
  categoryAr: string;
  duration: string;
  youtubeId: string;
  embedUrl: string;
  thumbnailEmoji: string;
  description: string;
  keyPoints: string[];
  ageGroup: AgeGroup;
}

export interface QuizItem {
  id: string;
  category: 'letters' | 'words' | 'math' | 'science' | 'general';
  categoryAr: string;
  question: string;
  visualEmoji?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  ageGroup: AgeGroup;
}
