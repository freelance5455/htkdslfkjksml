// ============================================================
// AI CREATOR STUDIO — CORE 4.0 TYPE DEFINITIONS
// ADVANCED CREATOR INTELLIGENCE + CONTENT FACTORY
// PROPRIETÁRIO: SADRAQUE NGOLA
// ============================================================

import type { Platform, ContentType, Tone, Language, Project, OutputFormat } from "./index";
import type { VideoAnalytics } from "./core2";
import type { AutopilotMode, CreatorGoal } from "./core3";

// --- 1. CONTENT FACTORY 11-STAGE PIPELINE ---
export type ContentFactoryStage =
  | "IDEAS"
  | "PLANNED"
  | "SCRIPT"
  | "STORYBOARD"
  | "PRODUCTION"
  | "EDITING"
  | "REVIEW"
  | "READY"
  | "SCHEDULED"
  | "PUBLISHED"
  | "ANALYTICS";

export interface ContentDNA {
  id: string;
  topic: string;
  tone: Tone;
  style: string;
  visualTheme: string;
  voiceProfile: {
    provider: "ELEVENLABS" | "OPENAI" | "AZURE" | "LOCAL_TTS";
    voiceId: string;
    voiceName: string;
    pitch: number;
    speed: number;
    emotion: string;
  };
  pacing: "FAST" | "BALANCED" | "CINEMATIC_SLOW";
  format: OutputFormat;
  targetAudience: string;
  branding: {
    primaryColor: string;
    secondaryColor: string;
    fontHeading: string;
    fontBody: string;
    logoPosition: "TOP_RIGHT" | "TOP_LEFT" | "BOTTOM_RIGHT" | "WATERMARK_CENTER";
    ctaPhrase: string;
  };
  repetitionProtectionHash?: string;
}

export interface ContentVariation {
  id: string;
  variantType: "TITLE" | "THUMBNAIL" | "HOOK" | "OPENING";
  variantKey: "A" | "B" | "C";
  content: string;
  previewUrl?: string;
  predictedCtrScore?: number;
  predictedRetentionScore?: number;
  isWinningVariant?: boolean;
}

export interface ContentFactoryItem {
  id: string;
  projectId?: string;
  seriesId?: string;
  universeId?: string;
  title: string;
  stage: ContentFactoryStage;
  dna: ContentDNA;
  targetPlatform: Platform;
  variations: {
    titles: ContentVariation[];
    thumbnails: ContentVariation[];
    hooks: ContentVariation[];
    openings: ContentVariation[];
  };
  sampleQualityGate?: ContentQualityGate;
  batchJobId?: string;
  thumbnailUrl?: string;
  videoDurationSec?: number;
  scheduledFor?: string;
  publishedUrl?: string;
  publishedAt?: string;
  analytics?: {
    views: number;
    retentionPercent: number;
    ctr: number;
    shares: number;
    revenueUsd?: number;
  };
  brandConsistencyScore: number;
  continuityChecked: boolean;
  createdAt: string;
  updatedAt: string;
}

// --- 2. BATCH PRODUCTION ENGINE ---
export type BatchSize = 5 | 10 | 20 | 50;

export interface BatchProductionJob {
  id: string;
  title: string;
  universeId?: string;
  seriesId?: string;
  batchSize: BatchSize;
  status: "DRAFT" | "CONFIRMATION_REQUIRED" | "SAMPLE_EVALUATION" | "IN_PROGRESS" | "COMPLETED" | "PAUSED" | "CANCELLED";
  estimatedCostUsd: number;
  actualCostUsd: number;
  approvedByOwner: boolean;
  targetPlatforms: Platform[];
  items: ContentFactoryItem[];
  sampleItemId?: string;
  qualityGateStatus: "PENDING" | "APPROVED" | "REJECTED";
  progressPercent: number;
  currentStepDescription: string;
  logs: string[];
  createdAt: string;
  updatedAt: string;
}

// --- 3. BRAND CONSISTENCY ENGINE ---
export interface BrandConsistencyAudit {
  id: string;
  itemId: string;
  overallScore: number; // 0-100
  checks: {
    logoPresentAndAligned: boolean;
    primaryColorAdherence: boolean;
    fontFamilyMatch: boolean;
    toneConsistency: boolean;
    voiceProfileMatch: boolean;
    visualStyleUniformity: boolean;
    thumbnailGuidelineMatch: boolean;
    callToActionPresence: boolean;
  };
  detectedDeviations: string[];
  suggestions: string[];
  passed: boolean;
  auditedAt: string;
}

// --- 4. CHARACTER UNIVERSE & WORLD BUILDING ---
export interface CharacterRelationship {
  targetCharacterId: string;
  targetCharacterName: string;
  relationType: "FRIEND" | "MENTOR" | "RIVAL" | "FAMILY" | "PET" | "ASSISTANT";
  notes: string;
}

export interface CharacterProfile {
  id: string;
  universeId: string;
  name: string;
  role: "PROTAGONIST" | "SIDEKICK" | "ANTAGONIST" | "MENTOR" | "NARRATOR";
  profile: string;
  appearance: {
    description: string;
    clothing: string;
    distinctiveFeatures: string[];
    colorPalette: string[];
    artStyle: string;
  };
  voice: {
    provider: string;
    voiceId: string;
    voiceName: string;
    accent: string;
    speechPattern: string;
  };
  personality: {
    traits: string[];
    catchphrases: string[];
    fears: string[];
    goals: string[];
  };
  relationships: CharacterRelationship[];
  referenceImages: string[];
  history: string[];
  episodeAppearancesCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface LocationWorld {
  id: string;
  name: string;
  description: string;
  visualMood: string;
  lightingStyle: string;
  referenceImages: string[];
}

export interface WorldBuildingUniverse {
  id: string;
  name: string;
  description: string;
  genre: "KIDS_ANIMATION" | "SCI_FI_TECH" | "BUSINESS_DOCS" | "FANTASY" | "DAILY_EDUCATIONAL";
  targetAgeGroup: string;
  characters: CharacterProfile[];
  locations: LocationWorld[];
  rules: string[]; // e.g. "Animals can talk, no modern tech, friendly resolution in every episode"
  visualStyle: {
    artEngine: string; // e.g. "3D Pixar Style, Vibrance 100, Soft Rim Lighting"
    renderPromptPrefix: string;
    aspectRatio: string;
  };
  musicStyle: {
    genre: string;
    instruments: string[];
    tempoBpm: number;
    mood: string;
  };
  storyStyle: {
    structure: string; // "Setup -> Playful Conflict -> Discovery -> Moral Lesson -> Song Finale"
    pacing: string;
  };
  seriesCount: number;
  createdAt: string;
}

// --- 5. STORY CONTINUITY ENGINE ---
export interface StoryContinuityReport {
  id: string;
  universeId: string;
  currentEpisodeId: string;
  previousEpisodeIds: string[];
  isContinuityPreserved: boolean;
  score: number; // 0-100
  checks: {
    characterAppearanceConsistency: boolean;
    characterVoiceConsistency: boolean;
    loreAndRulesAdherence: boolean;
    timelineOrderCorrect: boolean;
    retainedPropsAndStatus: boolean;
  };
  flaggedDiscrepancies: string[];
  autoCorrectSuggestions: string[];
  auditedAt: string;
}

// --- 6. CONTENT QUALITY GATE ---
export interface ContentQualityGate {
  id: string;
  batchJobId?: string;
  sampleItemId: string;
  overallScore: number; // 0-100
  dimensions: {
    originality: number;
    retentionPotential: number;
    narrativeClarity: number;
    brandAlignment: number;
    audioVisualFidelity: number;
    complianceSafety: number;
  };
  evaluationSummary: string;
  recommendations: string[];
  status: "PENDING_SAMPLE" | "SAMPLE_APPROVED" | "SAMPLE_REJECTED" | "BATCH_APPROVED";
  evaluatedAt: string;
}

// --- 7. COST OPTIMIZATION & PROVIDER FALLBACK ---
export type ProviderCapability = "TEXT_LLM" | "IMAGE_GEN" | "VIDEO_GEN" | "AUDIO_TTS" | "MUSIC_GEN";

export interface ProviderComparisonOption {
  providerName: string;
  modelOrVoice: string;
  costPerUnitUsd: number;
  estimatedCostForTaskUsd: number;
  qualityScore: number; // 1-10
  speedScore: number; // 1-10
  availability: "AVAILABLE" | "DEGRADED" | "OFFLINE" | "NOT_CONFIGURED";
  isRecommended: boolean;
  costChangeRequiresAuthorization: boolean;
}

export interface CostOptimizationRecommendation {
  taskType: ProviderCapability;
  currentConfiguredProvider: string;
  suggestedProvider: string;
  estimatedSavingsPercent: number;
  reason: string;
  options: ProviderComparisonOption[];
}

export interface ProviderFallbackEvent {
  id: string;
  timestamp: string;
  primaryProvider: string;
  fallbackProvider: string;
  capability: ProviderCapability;
  errorReason: string;
  status: "FALLBACK_SUCCESS" | "FALLBACK_FAILED";
  recoveredDataSummary: string;
}

// --- 8. CREATOR COPILOT & CREATIVE MEMORY ---
export type CopilotQueryIntent =
  | "WHAT_TO_CREATE_TODAY"
  | "WHICH_PROJECT_LATE"
  | "WHAT_WORKED_THIS_WEEK"
  | "WHAT_TO_IMPROVE"
  | "WHAT_TO_BATCH_PRODUCE"
  | "GENERAL_INSTRUCTION";

export interface CreatorCopilotMessage {
  id: string;
  sender: "USER" | "COPILOT" | "SYSTEM";
  text: string;
  suggestedActions?: {
    label: string;
    actionType: string;
    payload?: Record<string, unknown>;
  }[];
  contextData?: Record<string, unknown>;
  timestamp: string;
}

export interface CreativeMemoryItem {
  id: string;
  category: "SUCCESSFUL_IDEA" | "SUCCESSFUL_HOOK" | "SUCCESSFUL_TITLE" | "SUCCESSFUL_THUMBNAIL" | "SUCCESSFUL_FORMAT" | "SUCCESSFUL_SERIES";
  title: string;
  textSnippet: string;
  topic: string;
  audience: string;
  performanceScore: number;
  realMetrics: {
    views?: number;
    ctr?: number;
    retention?: number;
  };
  whyItWorked: string;
  extractedPattern: string;
  recordedAt: string;
}

// --- 9. SMART REPURPOSING ---
export type RepurposedTarget =
  | "YOUTUBE_SHORTS"
  | "TIKTOK"
  | "INSTAGRAM_REELS"
  | "FACEBOOK_REELS"
  | "QUOTE_CLIPS"
  | "TEASERS_TRAILER"
  | "COMMUNITY_POST";

export interface RepurposedClipItem {
  id: string;
  targetFormat: RepurposedTarget;
  title: string;
  aspectRatio: string;
  hook: string;
  caption: string;
  hashtags: string[];
  suggestedMusicMood: string;
  durationSec: number;
  startSecondInSource: number;
  endSecondInSource: number;
  status: "READY" | "GENERATING" | "EXPORTED";
}

export interface SmartRepurposingPlan {
  id: string;
  sourceProjectId: string;
  sourceTitle: string;
  sourceDurationSec: number;
  clips: RepurposedClipItem[];
  generatedCount: number;
  createdAt: string;
}

// --- 10. CONTENT ARCHIVE & AI NATURAL SEARCH ---
export interface ContentArchiveRecord {
  id: string;
  projectId: string;
  title: string;
  universeName?: string;
  seriesName?: string;
  characters: string[];
  topics: string[];
  tags: string[];
  format: string;
  audience: string;
  views: number;
  retentionPercent: number;
  ctr: number;
  thumbnailUrl: string;
  publishedDate: string;
  summary: string;
}

export interface AISearchResult {
  query: string;
  matchingRecords: ContentArchiveRecord[];
  interpretedIntent: string;
  insightsFound: string[];
}

// --- 11. CREATOR KNOWLEDGE GRAPH ---
export type KnowledgeNodeType =
  | "PROJECT"
  | "CHARACTER"
  | "TOPIC"
  | "VIDEO"
  | "PLATFORM"
  | "PERFORMANCE"
  | "IDEA"
  | "SERIES"
  | "UNIVERSE";

export interface KnowledgeGraphNode {
  id: string;
  label: string;
  type: KnowledgeNodeType;
  metric?: string;
  thumbnailUrl?: string;
  color?: string;
}

export interface KnowledgeGraphEdge {
  id: string;
  source: string;
  target: string;
  relation: string; // e.g. "FEATURES_CHARACTER", "BELONGS_TO_SERIES", "PUBLISHED_ON", "INSPIRED_BY"
}

export interface CreatorKnowledgeGraphData {
  nodes: KnowledgeGraphNode[];
  edges: KnowledgeGraphEdge[];
}

// --- 12. EXPERIMENT MANAGER ---
export type ExperimentType =
  | "HOOK_AB"
  | "TITLE_ABC"
  | "THUMBNAIL_ABC"
  | "FORMAT_COMPARISON"
  | "DURATION_TEST"
  | "SCHEDULE_TIMING";

export interface ExperimentVariant {
  key: "A" | "B" | "C";
  label: string;
  content: string;
  thumbnailUrl?: string;
  sampleImpressions: number;
  clicks: number;
  retentionPercent: number;
  ctr: number;
  isWinner?: boolean;
}

export interface ContentExperiment {
  id: string;
  title: string;
  type: ExperimentType;
  targetItemId: string;
  status: "DRAFT" | "RUNNING" | "CONCLUDED";
  variants: ExperimentVariant[];
  confidenceScorePercent: number;
  winningVariantKey?: "A" | "B" | "C";
  conclusionSummary?: string;
  startedAt?: string;
  concludedAt?: string;
}

// --- 13. LEARNING LOOP (7 STAGES) ---
export interface LearningLoopCycle {
  id: string;
  currentStage: "CONTENT" | "PUBLISH" | "DATA" | "ANALYSIS" | "LEARNING" | "RECOMMENDATION" | "NEW_CONTENT";
  insightsGathered: string[];
  recommendedAdjustments: string[];
  appliedToNextBatch: boolean;
  lastUpdated: string;
}

// --- 14. AUTONOMY LEVELS (0 to 5) & EMERGENCY STOP ---
export type AutonomyLevel = 0 | 1 | 2 | 3 | 4 | 5;

export interface AutonomyLevelDetails {
  level: AutonomyLevel;
  name: string;
  description: string;
  requiresExplicitAuthorization: boolean;
  permissions: {
    canSuggest: boolean;
    canDraftScript: boolean;
    canRenderMedia: boolean;
    canSchedule: boolean;
    canPublishDirectly: boolean;
    canAutoTriggerBatch: boolean;
  };
}

export interface EmergencyStopState {
  isActive: boolean;
  triggeredAt?: string;
  triggeredBy: string;
  reason?: string;
  haltedOperations: {
    generation: boolean;
    editing: boolean;
    rendering: boolean;
    publishing: boolean;
    autopilot: boolean;
  };
  preservedProjectsCount: number;
}

// --- 15. GLOBAL ACTIVITY LOG & SYSTEM HEALTH ---
export type ActivityLogCategory =
  | "AI"
  | "GENERATION"
  | "EDITING"
  | "RENDERING"
  | "PUBLISHING"
  | "AUTOPILOT"
  | "BUDGET"
  | "PROVIDER"
  | "ERRORS"
  | "QUALITY_GATE"
  | "BATCH";

export interface GlobalActivityLogEntry {
  id: string;
  timestamp: string;
  category: ActivityLogCategory;
  level: "INFO" | "SUCCESS" | "WARNING" | "ERROR";
  actor: string; // e.g. "AI_AUTOPILOT", "SADRAQUE_NGOLA", "FALLBACK_ENGINE"
  message: string;
  metadata?: Record<string, unknown>;
}

export type HealthStatusValue = "ONLINE" | "WARNING" | "ERROR" | "NOT_CONFIGURED";

export interface ServiceHealthItem {
  name: string;
  serviceCategory: "AI_PROVIDERS" | "MEDIA_PROVIDERS" | "STORAGE" | "DATABASE" | "PUBLISHING_APIS" | "JOB_QUEUE";
  status: HealthStatusValue;
  latencyMs: number;
  details: string;
  lastCheckedAt: string;
}

export interface SystemHealthOverview {
  overallStatus: HealthStatusValue;
  services: ServiceHealthItem[];
  activeWorkers: number;
  queueDepth: number;
  errorRateLastHour: number;
  lastHealthCheck: string;
}
