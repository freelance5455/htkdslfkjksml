export interface PageContent {
  title: string;
  url: string;
  icon?: string;
  category?: string;
  summary?: string;
  readTime?: string;
  sections?: {
    heading?: string;
    paragraphs: string[];
    quote?: string;
    list?: string[];
  }[];
  interactiveType?: 'duckduckgo' | 'eff_test' | 'privacy_guides' | 'hackernews' | 'article';
}

export interface Tab {
  id: string;
  title: string;
  url: string;
  favicon?: string;
  isIncognito: boolean;
  themeColor: string;
  trackersBlocked: number;
  cookiesBlocked: number;
  fingerprintsBlocked: number;
  isSecure: boolean;
  isLoading: boolean;
  history: string[];
  historyIndex: number;
  content?: PageContent;
  readerMode: boolean;
  desktopMode: boolean;
  scriptsEnabled: boolean;
  shieldsEnabled: boolean;
}

export interface BlockedItem {
  id: string;
  name: string;
  domain: string;
  category: 'Advertising' | 'Analytics' | 'Fingerprinting' | 'Social Tracker' | 'Session Replay';
  risk: 'High' | 'Medium' | 'Low';
}

export interface PrivacyConfig {
  shieldsActive: boolean;
  blockTrackers: boolean;
  blockFingerprinting: boolean;
  blockThirdPartyCookies: boolean;
  blockScripts: boolean;
  enforceHttps: boolean;
  blockPopups: boolean;
  gpcSignal: boolean;
  dohProvider: 'Cloudflare (1.1.1.1)' | 'Quad9 (9.9.9.9)' | 'Mullvad DNS' | 'AdGuard Privacy';
  torRouting: boolean;
  clearOnExit: boolean;
  biometricLock: boolean;
  searchEngine: 'DuckDuckGo' | 'Brave Search' | 'Startpage' | 'SearXNG';
}

export interface Bookmark {
  id: string;
  title: string;
  url: string;
  icon: string;
  category: string;
}

export interface DownloadFile {
  id: string;
  name: string;
  size: string;
  date: string;
  status: 'safe' | 'scanned' | 'quarantined';
  hash: string;
}
