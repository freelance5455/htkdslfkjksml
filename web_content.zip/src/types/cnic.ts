export type CnicStatusType = 'valid' | 'duplicate' | 'invalid_length' | 'invalid_region' | 'invalid_characters';

export interface CnicRecord {
  id: string;
  originalInput: string;
  cnicRaw: string;
  cnicFormatted: string;
  isValid: boolean;
  status: string;
  statusType: CnicStatusType;
  provinceCode: string | null;
  provinceName: string;
  divisionCode: string | null;
  districtCode: string | null;
  tehsilCode: string | null;
  unionCouncilCode: string | null;
  familySerial: string | null;
  genderDigit: number | null;
  gender: 'Male' | 'Female' | 'Unknown';
  timestamp: string;
  duplicateIndices?: number[];
}

export interface CnicBatchStats {
  total: number;
  valid: number;
  duplicate: number;
  invalid: number;
  maleCount: number;
  femaleCount: number;
  provinceDistribution: Record<string, number>;
}
