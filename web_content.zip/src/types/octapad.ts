export type BankId = 'A' | 'B';

export type ZoneSplitMode = 'single' | 'split-v' | 'split-h' | 'center-rim';

export type PlaybackMode = 'one-shot' | 'gate' | 'loop';

export type VelocityMode = 'fixed' | 'radial' | 'vertical';

export type PadLayoutType = 'grid' | 'freeform';

export type GridArrangement = 'auto' | '2x4' | '4x2';

export type SidebarPosition = 'right' | 'bottom' | 'left' | 'top';

export type SidebarRotation = 0 | 90 | -90 | 180;

export interface PadZoneConfig {
  id: 'primary' | 'secondary';
  label: string;
  soundId: string;
  soundName: string;
  isCustom: boolean;
  volume: number; // 0 to 1.2
  pitch: number; // -12 to +12 semitones
  pan: number; // -1 to +1
  playbackMode: PlaybackMode;
  chokeGroup: number; // 0 = none, 1..4 = mute group
  startOffset: number; // 0 to 1 normalized
  endOffset: number; // 0 to 1 normalized
  accentColor: string; // hex color for hit flash
  muted?: boolean;
}

export interface PadLayoutRect {
  x: number; // percentage 0..90
  y: number; // percentage 0..90
  w: number; // percentage 10..100
  h: number; // percentage 10..100
}

export interface PadConfig {
  index: number; // 0..7
  keyHint: string; // keyboard trigger e.g. 'Q', 'W', etc.
  splitMode: ZoneSplitMode;
  splitRatio: number; // 0.25 to 0.75
  rimThickness: number; // 0.18 to 0.45 (for center-rim mode)
  hitboxInset: number; // 0 to 18 px deadzone around pad edge
  velocityMode: VelocityMode;
  layoutRect: PadLayoutRect;
  zones: [PadZoneConfig, PadZoneConfig];
}

export interface KitPreset {
  id: string;
  name: string;
  category: string;
  isBuiltIn: boolean;
  layoutType: PadLayoutType;
  gridArrangement?: GridArrangement;
  padGap: number; // px (2..22)
  padRadius: number; // px (4..28)
  showLabels: boolean;
  showKeyHints: boolean;
  masterVolume: number; // 0..1.2
  bankA: PadConfig[];
  bankB: PadConfig[];
  updatedAt: number;
}

export interface StoredSound {
  id: string;
  name: string;
  mimeType: string;
  size: number;
  duration: number;
  data: ArrayBuffer;
  createdAt: number;
}

export interface BuiltInSoundMeta {
  id: string;
  name: string;
  category: 'Timli & Folk' | 'Acoustic Kit' | '808 & Trap' | 'Electro & Perc';
  color: string;
}

export interface TriggerEvent {
  padIndex: number;
  zoneId: 'primary' | 'secondary';
  velocity: number;
  timestamp: number;
}
