export type SourceMode = 'url' | 'html' | 'code';

export type ScreenOrientation = 'unspecified' | 'portrait' | 'landscape';

export type AndroidPermissionKey =
  | 'INTERNET'
  | 'ACCESS_NETWORK_STATE'
  | 'CAMERA'
  | 'RECORD_AUDIO'
  | 'ACCESS_FINE_LOCATION'
  | 'READ_MEDIA_IMAGES'
  | 'VIBRATE'
  | 'POST_NOTIFICATIONS';

export interface HtmlAssetFile {
  path: string;
  contentBase64: string;
  mimeType: string;
  size: number;
}

export interface BillingProduct {
  sku: string;
  type: 'inapp' | 'consumable' | 'subs';
  label: string;
  priceDisplay: string;
  currencyAmount?: number;
}

export interface SplashConfig {
  enabled: boolean;
  backgroundColor: string;
  textColor: string;
  headline: string;
  tagline: string;
  durationMs: number;
  showSpinner: boolean;
  logoScale: 'sm' | 'md' | 'lg';
  customLogoBase64Png?: string;
}

export interface DeveloperProfile {
  developerName: string;
  supportEmail: string;
  websiteUrl: string;
  privacyPolicyUrl: string;
  termsUrl: string;
  githubUrl: string;
  xTwitterUrl: string;
  youtubeUrl: string;
  discordUrl: string;
  instagramUrl: string;
  tiktokUrl: string;
  includeAboutPageInAssets: boolean;
}

export interface ApkBuildConfig {
  sourceMode: SourceMode;
  websiteUrl: string;
  rawHtmlCode: string;
  htmlEntryFile: string;
  htmlFiles: HtmlAssetFile[];
  appName: string;
  packageId: string;
  versionName: string;
  versionCode: number;
  minSdkVersion: number;
  targetSdkVersion: number;
  themeColor: string;
  statusBarStyle: 'light' | 'dark';
  orientation: ScreenOrientation;
  fullscreen: boolean;
  enableJavaScript: boolean;
  enableDomStorage: boolean;
  enableZoomControls: boolean;
  pullToRefresh: boolean;
  allowCleartextTraffic: boolean;
  customUserAgent: string;
  permissions: AndroidPermissionKey[];
  iconBase64Png?: string;
  signingOrg: string;
  signingAlias: string;
  // Splash Screen
  splash: SplashConfig;
  // Monetization & Launch Events
  enablePlayBilling: boolean;
  enableRemoveAds: boolean;
  removeAdsSku: string;
  removeAdsPrice: string;
  currencyName: string;
  billingProducts: BillingProduct[];
  enableAdMob: boolean;
  adMobAppId: string;
  adMobBannerUnitId: string;
  adMobInterstitialUnitId: string;
  adMobRewardedUnitId: string;
  showBottomBanner: boolean;
  enableLaunchEvents: boolean;
  enableFirebaseAnalytics: boolean;
  launchWebhookUrl: string;
  customLaunchEvents: string[];
  // Developer & Social Links
  developer: DeveloperProfile;
}

export interface UrlInspectionResult {
  finalUrl: string;
  title: string;
  description: string;
  themeColor: string | null;
  faviconUrl: string | null;
  faviconBase64Png: string | null;
  suggestedPackageId: string;
  isHttps: boolean;
  frameBlocked: boolean;
  frameHeaderReason: string | null;
  statusCode: number;
}

export interface BuildArtifactSummary {
  id: string;
  createdAt: string;
  appName: string;
  packageId: string;
  versionName: string;
  versionCode: number;
  sourceMode: SourceMode;
  sourceTarget: string;
  apkSizeBytes: number;
  gradleSizeBytes: number;
  sha256: string;
  signingFingerprint: string;
  manifestXmlPreview: string;
  entries: { path: string; sizeBytes: number; compression: string }[];
  builtOffline?: boolean;
  apkBlobUrl?: string;
  gradleBlobUrl?: string;
}
