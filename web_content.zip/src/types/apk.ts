export interface AppConfig {
  appName: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  companyName: string;
  authorEmail: string;
  websiteUrl: string;
  orientation: 'portrait' | 'landscape' | 'sensor';
  themeColor: string;
  backgroundColor: string;
  fullscreen: boolean;
  enableHardwareAcceleration: boolean;
  enablePullToRefresh: boolean;
  enableZoomControls: boolean;
  enableCleartextTraffic: boolean;
  splashDuration: number; // in seconds
  showSplash: boolean;
  deepLinkScheme: string;
  permissions: {
    internet: boolean;
    networkState: boolean;
    camera: boolean;
    storage: boolean;
    audio: boolean;
    location: boolean;
    vibrate: boolean;
    wakeLock: boolean;
    notifications: boolean;
  };
}

export interface AppIconConfig {
  type: 'upload' | 'generate';
  uploadedImage: string | null; // data URL or null
  bgColor: string;
  bgGradient: string;
  symbol: string;
  symbolColor: string;
  shape: 'squircle' | 'circle' | 'rounded' | 'square';
  badgeText: string;
  fontSize: number;
}

export interface WebFile {
  name: string;
  path: string;
  content: string | Uint8Array;
  isBinary: boolean;
  size: number;
}

export type InputMode = 'zip' | 'html' | 'url' | 'samples';

export interface BuildLog {
  timestamp: string;
  step: string;
  status: 'pending' | 'active' | 'done' | 'error';
  details?: string;
}

export interface GeneratedApkResult {
  apkBlob: Blob;
  apkFileName: string;
  apkSize: number;
  projectZipBlob: Blob;
  projectFileName: string;
  buildDate: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  appName: string;
  companyName: string;
  sha256Fingerprint: string;
  sha1Fingerprint: string;
  md5Fingerprint: string;
  manifestXml: string;
  iconDataUrl: string;
  filesCount: number;
}
