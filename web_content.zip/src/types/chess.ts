export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
export type PieceColor = 'w' | 'b';

export type GameMode = 'ai' | 'local' | 'online' | 'puzzle' | 'practice';
export type AiDifficulty = 'beginner' | 'easy' | 'medium' | 'hard' | 'expert';

export type BoardStyle = 'classic' | 'wooden' | 'marble' | 'glass' | 'futuristic';
export type PieceStyle = 'classic' | 'modern' | 'fantasy' | 'metal';
export type AppTheme = 'dark' | 'light' | 'blue' | 'green';

export interface TimeControlConfig {
  id: string;
  name: string;
  category: 'bullet' | 'blitz' | 'rapid' | 'untimed';
  initialSeconds: number;
  incrementSeconds: number;
}

export interface GameSettings {
  boardStyle: BoardStyle;
  pieceStyle: PieceStyle;
  theme: AppTheme;
  soundEnabled: boolean;
  musicEnabled: boolean;
  showLegalMoves: boolean;
  autoQueen: boolean;
  cameraAutoRotate: boolean;
  perspective: 'white' | 'black' | 'auto';
  timeControlSeconds: number;
  incrementSeconds: number;
  aiSpeed: 'fast' | 'normal' | 'realistic';
}

export interface PlayerInfo {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  title?: string;
  isAi?: boolean;
  color: PieceColor;
}

export interface MoveRecord {
  san: string;
  from: string;
  to: string;
  piece: PieceType;
  color: PieceColor;
  captured?: PieceType;
  promotion?: PieceType;
  fen: string;
  timeRemaining?: number;
}

export interface MatchResult {
  winner: PieceColor | 'draw';
  reason: 'checkmate' | 'stalemate' | 'timeout' | 'resignation' | 'draw_agreement' | 'repetition' | 'insufficient_material';
  scoreDeltaWhite: number;
  scoreDeltaBlack: number;
}

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  title: string;
  totalGames: number;
  wins: number;
  losses: number;
  draws: number;
  ratingHistory: { date: string; rating: number }[];
  achievements: Achievement[];
  completedPuzzles: string[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
  progress?: number;
  maxProgress?: number;
}

export interface Puzzle {
  id: string;
  title: string;
  category: 'tactics' | 'mate-in-1' | 'mate-in-2' | 'fork' | 'pin' | 'endgame';
  difficulty: 'Easy' | 'Medium' | 'Hard';
  fen: string;
  moves: string[]; // Solution UCI moves (e.g. ['e2e4', 'e7e5'])
  description: string;
  hint: string;
  rating: number;
}

export interface OpeningLesson {
  id: string;
  name: string;
  eco: string;
  movesText: string;
  moves: string[];
  description: string;
  keyIdeas: string[];
}

export type MoveClassification =
  | 'brilliant'
  | 'great'
  | 'best'
  | 'excellent'
  | 'good'
  | 'inaccuracy'
  | 'mistake'
  | 'blunder'
  | 'missed_win'
  | 'book';

export interface CandidateLine {
  multipv: number;
  depth: number;
  scoreCp: number;
  scoreMate?: number;
  evalPawns: string;
  whiteScoreCp: number;
  pvMoves: string[];
  pvSan: string[];
  bestMove: string;
  bestMoveSan: string;
}

export interface StockfishAnalysisResult {
  fen: string;
  depth: number;
  seldepth: number;
  nodes: number;
  nps: number;
  timeMs: number;
  bestMove: string;
  bestMoveSan: string;
  sourceSquare: string;
  targetSquare: string;
  scoreCp: number;
  scoreMate?: number;
  whiteScoreCp: number;
  evalText: string;
  winProbability: number;
  lines: CandidateLine[];
}

export interface ReviewedMove {
  ply: number;
  moveNumber: number;
  san: string;
  uci: string;
  color: PieceColor;
  fenBefore: string;
  fenAfter: string;
  evalBefore: number;
  evalAfter: number;
  evalDiff: number;
  classification: MoveClassification;
  bestMove: string;
  bestMoveSan: string;
  bestAlternativeLine?: string[];
  explanation: string;
  explanationMarathi?: string;
  explanationHindi?: string;
  tacticalMotif?: string;
  piecesAttacked?: string[];
  threatsCreated?: string[];
  kingSafetyChange?: 'improves' | 'worsens' | 'neutral';
}

export interface GameReviewReport {
  id: string;
  date: string;
  whitePlayer: string;
  blackPlayer: string;
  whiteAccuracy: number;
  blackAccuracy: number;
  whiteClassificationCounts: Record<MoveClassification, number>;
  blackClassificationCounts: Record<MoveClassification, number>;
  moves: ReviewedMove[];
  turningPoints: { ply: number; description: string; evalSwing: number }[];
  summaryText: string;
}

export type TacticalTheme =
  | 'fork'
  | 'pin'
  | 'skewer'
  | 'discovered_attack'
  | 'double_check'
  | 'mate_in_1'
  | 'mate_in_2'
  | 'mate_in_3'
  | 'deflection'
  | 'removing_defender'
  | 'winning_material'
  | 'endgame_tactic';

export interface TacticalPuzzle {
  id: string;
  title: string;
  theme: TacticalTheme;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  rating: number;
  fen: string;
  playerSide: PieceColor;
  moves: string[];
  description: string;
  hint: string;
  explanation: string;
  explanationMarathi?: string;
  explanationHindi?: string;
}

export interface PuzzleAttempt {
  puzzleId: string;
  theme: TacticalTheme;
  success: boolean;
  timeSpentSeconds: number;
  date: string;
}

export interface TrainingModule {
  id: string;
  title: string;
  category: 'tactics' | 'calculation' | 'openings' | 'endgames' | 'blunder_review' | 'king_safety';
  durationMinutes: number;
  completed: boolean;
  targetCount: number;
  completedCount: number;
  description: string;
}

export interface TrainingDay {
  dayName: string;
  dayShort: string;
  modules: TrainingModule[];
  completed: boolean;
}

export interface PersonalizedTrainingPlan {
  id: string;
  createdAt: string;
  targetRating: number;
  weeklyGoalMinutes: number;
  focusWeaknesses: string[];
  days: TrainingDay[];
}

export interface OpeningContinuation {
  san: string;
  uci: string;
  name?: string;
  gamesCount: number;
  whiteWinRate: number;
  drawRate: number;
  blackWinRate: number;
}

export interface OpeningEntry {
  eco: string;
  name: string;
  fen: string;
  moves: string[];
  movesSan: string[];
  continuations: OpeningContinuation[];
  description: string;
  strategicGoals: string[];
}

export interface EndgameLesson {
  id: string;
  title: string;
  category: 'king_pawn' | 'rook' | 'checkmate_technique' | 'defense_draw';
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  initialFen: string;
  playerSide: PieceColor;
  targetGoal: string;
  solutionMoves: string[];
  hints: string[];
  explanation: string;
}

export interface EngineSettings {
  engineVersion: string;
  searchDepth: number;
  timeLimitMs: number;
  multiPv: number;
  showEvalBar: boolean;
  showBestMoveArrow: boolean;
  showEngineThinking: boolean;
  autoGameReview: boolean;
  language: 'en' | 'mr' | 'hi';
}

export interface OnlineLobbyPlayer {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  status: 'online' | 'in-game';
  country?: string;
}

// ==========================================
// COMPETITIVE TOURNAMENTS & PAIRING TYPES
// ==========================================

export type TournamentFormat = 'swiss' | 'arena' | 'single_elimination' | 'double_elimination';
export type TournamentStatus = 'registration' | 'waiting' | 'live' | 'completed' | 'cancelled';
export type TournamentTimeControl = 'bullet' | 'blitz' | 'rapid' | 'custom';
export type TournamentPairingResult =
  | 'pending'
  | '1-0'
  | '0-1'
  | '1/2-1/2'
  | 'bye'
  | 'white_forfeit'
  | 'black_forfeit'
  | 'double_forfeit';

export interface TournamentPairing {
  id: string;
  tournamentId: string;
  roundNumber: number;
  boardNumber: number;
  whiteId: string;
  whiteName: string;
  whiteRating: number;
  blackId?: string;
  blackName?: string;
  blackRating?: number;
  isBye: boolean;
  gameId?: string;
  result: TournamentPairingResult;
  whiteScore: number;
  blackScore: number;
}

export interface TournamentParticipant {
  id: string;
  tournamentId: string;
  playerId: string;
  playerName: string;
  playerRating: number;
  avatar?: string;
  seed: number;
  checkedIn: boolean;
  score: number;
  tieBreakBuchholz: number;
  tieBreakSonnebornBerger: number;
  wins: number;
  draws: number;
  losses: number;
  streak: number;
  isEliminated: boolean;
  withdrawn: boolean;
  registeredAt: string;
}

export interface TournamentRound {
  id: string;
  tournamentId: string;
  roundNumber: number;
  status: 'pending' | 'active' | 'completed';
  pairings: TournamentPairing[];
  startedAt?: string;
  completedAt?: string;
}

export interface TournamentItem {
  id: string;
  title: string;
  description: string;
  bannerUrl?: string;
  format: TournamentFormat;
  organizerId: string;
  organizerName: string;
  timeControlType: TournamentTimeControl;
  initialSeconds: number;
  incrementSeconds: number;
  maxParticipants: number;
  minRating: number;
  maxRating: number;
  isRated: boolean;
  isPrivate: boolean;
  accessCode?: string;
  rulesDescription: string;
  totalRounds: number;
  currentRound: number;
  durationMinutes?: number;
  registrationStartAt: string;
  registrationEndAt: string;
  scheduledStartAt: string;
  actualStartAt?: string;
  completedAt?: string;
  status: TournamentStatus;
  winnerId?: string;
  winnerName?: string;
  participants: TournamentParticipant[];
  rounds: TournamentRound[];
}

// ==========================================
// DAILY CHALLENGES & MISSIONS
// ==========================================

export type DailyChallengeCategory =
  | 'tactics'
  | 'mate_in_2'
  | 'endgame'
  | 'opening_quiz'
  | 'best_move'
  | 'find_defence';

export interface DailyChallenge {
  id: string;
  challengeDate: string; // YYYY-MM-DD
  title: string;
  category: DailyChallengeCategory;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  fen: string;
  solutionMoves: string[]; // UCI format e.g. ["e2e4", "e7e5"]
  explanation: string;
  rewardXp: number;
  rewardTitle?: string;
  attemptsAllowed: number;
  hints?: string[];
}

export interface ChallengeCompletion {
  challengeId: string;
  completed: boolean;
  attemptsCount: number;
  timeSeconds: number;
  xpAwarded: number;
  completedAt: string;
}

// ==========================================
// ACHIEVEMENTS & PROGRESSION
// ==========================================

export type AchievementCategory = 'combat' | 'progression' | 'tournaments' | 'tactics' | 'mastery';

export interface AchievementItem {
  id: string;
  name: string;
  description: string;
  category: AchievementCategory;
  icon: string;
  rewardXp: number;
  rewardBadge?: string;
  targetCount: number;
  progress: number;
  isUnlocked: boolean;
  unlockedAt?: string;
}

export interface PlayerProgression {
  xp: number;
  level: number;
  levelTitle: string;
  xpToNextLevel: number;
  currentLevelProgressPercent: number;
  streakDays: number;
  maxStreakDays: number;
  unlockedThemes: string[];
  unlockedPieceStyles: string[];
}

// ==========================================
// ANTI-CHEAT & FAIR PLAY
// ==========================================

export interface FairPlayAnalysis {
  id: string;
  gameId: string;
  userId: string;
  userName: string;
  acpl: number;
  engineSimilarity: number;
  blunderCount: number;
  moveTimeVariance: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  flagReasons: string[];
  isReviewed: boolean;
  createdAt: string;
}

export type ReportCategory = 'suspected_engine' | 'stalling' | 'abandonment' | 'harassment' | 'other';

export interface UserReport {
  id: string;
  reporterId: string;
  reporterName: string;
  reportedId: string;
  reportedName: string;
  gameId?: string;
  category: ReportCategory;
  notes: string;
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
  createdAt: string;
}

export interface ModerationAction {
  id: string;
  targetUserId: string;
  targetUserName: string;
  actionType: 'warning' | 'temporary_ban' | 'permanent_ban' | 'rating_adjustment' | 'unban';
  reason: string;
  expiresAt?: string;
  createdAt: string;
  createdBy: string;
}

// ==========================================
// NOTIFICATIONS & NOTIFICATION SETTINGS
// ==========================================

export type NotificationType =
  | 'tournament_pairing'
  | 'tournament_start'
  | 'match_invite'
  | 'daily_challenge'
  | 'achievement_unlocked'
  | 'moderation_notice'
  | 'friend_request';

export interface NotificationItem {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, any>;
  isRead: boolean;
  createdAt: string;
}

export interface NotificationSettings {
  tournamentAlerts: boolean;
  matchInvites: boolean;
  dailyReminder: boolean;
  achievementSounds: boolean;
  systemNotices: boolean;
}

// ==========================================
// LEADERBOARD TYPES
// ==========================================

export type LeaderboardCategory = 'bullet' | 'blitz' | 'rapid' | 'overall' | 'puzzle' | 'tournament';
export type LeaderboardTimeframe = 'all_time' | 'monthly' | 'weekly';
export type LeaderboardScope = 'global' | 'country' | 'friends';

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  username: string;
  avatar: string;
  rating: number;
  ratingBullet: number;
  ratingBlitz: number;
  ratingRapid: number;
  ratingPuzzle: number;
  totalGames: number;
  wins: number;
  losses: number;
  draws: number;
  winRate: number;
  country: string;
  title?: string;
  streak: number;
  isUser?: boolean;
}


