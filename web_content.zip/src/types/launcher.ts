export interface AppItem {
  id: string;
  title: string;
  subtitle: string;
  packageName: string;
  deepLinkUri: string;
  webFallbackUrl: string;
  accentColor: string;
  iconBgGradient: string;
  brandKey: string;
  order: number;
  custom?: boolean;
}

export type TvInputSource = 'hdmi1' | 'hdmi2' | 'hdmi3' | 'tuner';

export interface LauncherSettings {
  performanceMode: boolean;
  soundEffects: boolean;
  soundVolume: number;
  activeInput: TvInputSource;
  connectedWifiSsid: string;
}

export type FocusZone = 'dock' | 'topbar';
export type NavigationDirection = 'up' | 'down' | 'left' | 'right';
