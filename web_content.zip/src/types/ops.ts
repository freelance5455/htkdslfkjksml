import { Timestamp } from 'firebase/firestore';

export const ADMIN_EMAIL = 'lulnazi12@gmail.com';

export type UserRole = 'admin' | 'employee';
export type EmployeeDivision = 'Gudang & Packing' | 'Host Live' | 'Konten Kreator';
export type UserDivision = 'Administrator' | EmployeeDivision;
export type HostLiveShift = 'Shift 1' | 'Shift 2';
export type EmployeeShift = '' | HostLiveShift;
export type AttendanceStatus =
  | 'Hadir Tepat Waktu'
  | 'Terlambat'
  | 'Izin'
  | 'Sakit'
  | 'Tanpa Keterangan';
export type StoreName =
  | 'Tiga Rekan ID (TikTok)'
  | 'Veelo Store ID (TikTok)'
  | 'Tiga Rekan ID (Shopee)';
export type ComplaintType =
  | 'Barang Rusak'
  | 'Salah Kirim / Kurang'
  | 'Terlambat Kurir'
  | 'Pengajuan Retur / Refund'
  | 'Lainnya';
export type ComplaintStatus =
  | 'Baru Masuk'
  | 'Sedang Dicek Gudang'
  | 'Menunggu Penggantian'
  | 'Selesai';
export type NoteCategory = 'Restock' | 'Promo' | 'Kurir' | 'Komplain' | 'Umum';
export type WorkspaceResourceType = 'sheet' | 'doc' | 'drive' | 'chat';
export type InviteStatus = 'pending' | 'accepted' | 'revoked';

export const STORE_NAMES: StoreName[] = [
  'Tiga Rekan ID (TikTok)',
  'Veelo Store ID (TikTok)',
  'Tiga Rekan ID (Shopee)',
];
export const EMPLOYEE_DIVISIONS: EmployeeDivision[] = [
  'Gudang & Packing',
  'Host Live',
  'Konten Kreator',
];
export const HOST_LIVE_SHIFTS: HostLiveShift[] = ['Shift 1', 'Shift 2'];
export const ATTENDANCE_STATUSES: AttendanceStatus[] = [
  'Hadir Tepat Waktu',
  'Terlambat',
  'Izin',
  'Sakit',
  'Tanpa Keterangan',
];
export const COMPLAINT_TYPES: ComplaintType[] = [
  'Barang Rusak',
  'Salah Kirim / Kurang',
  'Terlambat Kurir',
  'Pengajuan Retur / Refund',
  'Lainnya',
];
export const COMPLAINT_STATUSES: ComplaintStatus[] = [
  'Baru Masuk',
  'Sedang Dicek Gudang',
  'Menunggu Penggantian',
  'Selesai',
];
export const NOTE_CATEGORIES: NoteCategory[] = ['Restock', 'Promo', 'Kurir', 'Komplain', 'Umum'];

// Synchronized verbatim with firebase-blueprint.json & firestore.rules
export const FIELD_LIMITS = {
  idRegex: /^[a-zA-Z0-9_-]+$/,
  idMaxLength: 128,
  orderCodeMin: 3,
  orderCodeMax: 40,
  customerNameMax: 120,
  descriptionMax: 500,
  resolutionNotesMax: 500,
  picNameMax: 120,
  skuMin: 2,
  skuMax: 40,
  productNameMax: 160,
  categoryMax: 60,
  warehouseLocationMax: 80,
  noteTitleMax: 120,
  noteContentMax: 2000,
  checklistMaxItems: 20,
  checklistItemMaxLength: 200,
  storeNameMax: 120,
  linkExternalIdMax: 200,
  linkTitleMax: 200,
  linkUrlMax: 500,
  employeeNameMax: 120,
  emailMax: 200,
  phoneMax: 40,
  inviteNotesMax: 300,
  workDateRegex: /^\d{4}-\d{2}-\d{2}$/,
  lateMinutesMax: 720,
  workTaskMax: 240,
  attendanceNotesMax: 500,
} as const;

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  role: UserRole;
  division: UserDivision;
  active: boolean;
  inviteId: string;
  storeName: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface EmployeeInvite {
  id: string;
  inviteCode: string;
  employeeName: string;
  email: string;
  division: EmployeeDivision;
  shift?: EmployeeShift;
  status: InviteStatus;
  notes: string;
  claimedUid: string;
  createdBy: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface EmployeeRecord {
  id: string;
  ownerId: string;
  employeeName: string;
  email: string;
  division: EmployeeDivision;
  phone: string;
  shift: EmployeeShift;
  status: 'Aktif' | 'Nonaktif';
  notes: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface ComplaintRecord {
  id: string;
  ownerId: string;
  orderCode: string;
  store: StoreName;
  customerName: string;
  complaintType: ComplaintType;
  description: string;
  resolutionNotes: string;
  status: ComplaintStatus;
  picName: string;
  assignedEmails: string[];
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface InventoryItem {
  id: string;
  ownerId: string;
  store: StoreName;
  sku: string;
  productName: string;
  category: string;
  stock: number;
  minStock: number;
  unitPrice: number;
  warehouseLocation: string;
  teamEmails: string[];
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface OpsNote {
  id: string;
  ownerId: string;
  title: string;
  content: string;
  category: NoteCategory;
  pinned: boolean;
  checklist: string[];
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface WorkspaceLink {
  id: string;
  ownerId: string;
  resourceType: WorkspaceResourceType;
  externalId: string;
  title: string;
  url: string;
  createdAt?: Timestamp;
}

export interface AttendanceLog {
  id: string;
  ownerId: string;
  employeeName: string;
  employeeEmail: string;
  division: EmployeeDivision;
  workDate: string;
  shift: EmployeeShift;
  attendanceStatus: AttendanceStatus;
  lateMinutes: number;
  workTask: string;
  notes: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface ConfirmDialogState {
  open: boolean;
  title: string;
  description: string;
  confirmLabel: string;
  variant?: 'primary' | 'danger';
  details?: string[];
  onConfirm: () => Promise<void> | void;
}
