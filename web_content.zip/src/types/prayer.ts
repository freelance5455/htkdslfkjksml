export type PrayerName = 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';

export interface DailySchedule {
  date: string; // e.g., '2026-10-08'
  day: number; // 1 to 31
  month: number; // 10
  year: number; // 2026
  fajr: string; // '04:38'
  sunrise: string; // '05:53' (informational only)
  dhuhr: string; // '11:46'
  asr: string; // '15:09'
  maghrib: string; // '17:39'
  isha: string; // '18:54'
}

export interface NightTimings {
  firstThird: string;
  midnight: string;
  lastThird: string;
  maghrib: string;
  fajr: string;
  nightDurationMinutes: number;
}

export type AdhanVoice =
  | 'makkah'
  | 'madinah'
  | 'alaqsa'
  | 'fajr_special'
  | 'melodic_bayati'
  | 'soft_serene';

export type AlarmTone =
  | 'sacred_bell'
  | 'crystal_chime'
  | 'radiant_gong'
  | 'gentle_acoustic'
  | 'dawn_alarm'
  | 'vibrant_chime';

export interface PrayerSettings {
  timeFormat: '12h' | '24h';
  alarmDelayMinutes: number; // default: 10. allowed: 0, 5, 10, 15, 20
  adhanVoice: AdhanVoice;
  alarmTone: AlarmTone;
  volume: number; // 0 to 100
  timeZone: 'Asia/Dhaka' | 'local';
  
  // Independent ON/OFF toggles for Adhan
  adhanEnabled: {
    fajr: boolean;
    dhuhr: boolean;
    asr: boolean;
    maghrib: boolean;
    isha: boolean;
  };

  // Independent ON/OFF toggles for Salah Alarm
  alarmEnabled: {
    fajr: boolean;
    dhuhr: boolean;
    asr: boolean;
    maghrib: boolean;
    isha: boolean;
  };
}

export interface NextPrayerInfo {
  prayerName: PrayerName | 'sunrise';
  label: string;
  targetTime: string; // '11:46'
  targetDate: Date;
  isAlarm: boolean; // true if the immediate next trigger is a Salah reminder alarm
  timeRemainingMs: number;
  formattedCountdown: string;
  progressPercent: number;
}

export interface ActiveAlarmState {
  type: 'adhan' | 'salah_alarm';
  prayerName: PrayerName;
  prayerLabel: string;
  timeString: string;
  scheduledAlarmTime?: string;
  delayMinutes?: number;
}
