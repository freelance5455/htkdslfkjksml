export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'disconnecting';

export type ProtocolType = 'wireguard' | 'openvpn_udp' | 'openvpn_tcp' | 'ikev2' | 'shadowsocks';

export type DNSType = 'cloudflare' | 'google' | 'adguard' | 'quad9' | 'custom';

export type RegionFilter = 'all' | 'asia' | 'europe' | 'americas' | 'specialized';

export interface VpnServer {
  id: string;
  country: string;
  countryBn: string;
  city: string;
  cityBn: string;
  countryCode: string; // ISO 2-letter for flag
  flag: string;
  ip: string;
  ping: number; // in ms
  load: number; // percentage 0-100
  region: 'asia' | 'europe' | 'americas';
  isP2P: boolean;
  isStreaming: boolean;
  isFastest?: boolean;
  coordinates: { x: number; y: number }; // Relative coordinates 0-100% on world map
}

export interface TrafficStats {
  downloadSpeed: number; // in KB/s or MB/s
  uploadSpeed: number;
  totalDownloaded: number; // in MB
  totalUploaded: number;
  sessionTime: number; // in seconds
}

export interface VpnSettings {
  protocol: ProtocolType;
  killSwitch: boolean;
  dnsProtection: DNSType;
  autoConnectOnWifi: boolean;
  blockAdsAndMalware: boolean;
  splitTunneling: boolean;
  splitTunnelApps: string[];
}

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'success' | 'warn' | 'error';
  message: string;
}

export interface LeakCheckResult {
  originalIp: string;
  originalIsp: string;
  originalLocation: string;
  vpnIp: string;
  vpnIsp: string;
  vpnLocation: string;
  dnsLeaksDetected: boolean;
  dnsServers: string[];
  webrtcProtected: boolean;
  encryptionCipher: string;
  ipMasked: boolean;
}
