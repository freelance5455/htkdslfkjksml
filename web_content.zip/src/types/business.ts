export type PaymentMethod = 'Cash' | 'bKash' | 'Nagad' | 'Bank' | 'Due';

export type ProductCategory =
  | 'LCD/Display'
  | 'Touch/Glass'
  | 'Battery'
  | 'Charging Ribbon'
  | 'Housing/Body'
  | 'Camera'
  | 'IC/Motherboard Parts'
  | 'Tools'
  | 'Other';

export type BrandName =
  | 'Samsung'
  | 'Xiaomi / Redmi'
  | 'Oppo'
  | 'Vivo'
  | 'Realme'
  | 'Apple'
  | 'Infinix'
  | 'Tecno'
  | 'OnePlus'
  | 'Honor / Huawei'
  | 'Motorola'
  | 'Nokia'
  | 'Other';

export interface BusinessProfile {
  id: string;
  businessName: string;
  ownerName: string;
  ownerPhoto: string; // Base64 or URL
  businessLogo: string; // Base64 or URL
  phone: string;
  address: string;
  currency: string;
  isSetupCompleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  brand: BrandName;
  modelNumber: string;
  supportedModels: string;
  condition: 'New' | 'Used';
  frontPhoto: string;
  backPhoto: string;
  stockQuantity: number;
  purchasePrice: number;
  retailPrice: number;
  wholesalePrice: number;
  alertLimit: number;
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
}

export interface StockAddLog {
  id: string;
  productId: string;
  productName: string;
  addedQuantity: number;
  purchasePrice: number;
  supplierNote?: string;
  date: string;
  time: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  phone2?: string;
  whatsapp?: string;
  address: string;
  photo?: string;
  totalPurchases: number;
  totalPaid: number;
  currentDue: number;
  createdAt: string;
  isDeleted?: boolean;
}

export interface CartItem {
  productId: string;
  productName: string;
  category: ProductCategory;
  brand: BrandName;
  modelNumber: string;
  frontPhoto?: string;
  quantity: number;
  purchasePrice: number;
  unitPrice: number;
  priceType: 'Retail' | 'Wholesale' | 'Custom';
  totalPrice: number;
  profit: number;
}

export interface SaleInvoice {
  id: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  items: CartItem[];
  totalProducts: number;
  totalQuantity: number;
  totalSalesAmount: number;
  totalPurchaseAmount: number;
  grossProfit: number;
  discount: number;
  finalPayableAmount: number;
  netProfit: number;
  paymentMethod: PaymentMethod;
  paidAmount: number;
  dueAmount: number;
  dueDate?: string;
  date: string;
  time: string;
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
  returnedQuantities?: { [productId: string]: number };
}

export interface DueCollection {
  id: string;
  customerId: string;
  customerName: string;
  invoiceId?: string;
  invoiceNumber?: string;
  amount: number;
  paymentMethod: PaymentMethod;
  date: string;
  time: string;
  note?: string;
}

export interface ProductReturn {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  invoiceId: string;
  invoiceNumber: string;
  productId: string;
  productName: string;
  brand: string;
  model: string;
  quantity: number;
  unitPrice: number;
  returnAmount: number;
  profitAdjustment: number;
  refundMethod: 'Cash' | 'bKash' | 'Nagad' | 'Bank' | 'Deduct Due';
  reason?: string;
  date: string;
  time: string;
}

export interface Expense {
  id: string;
  category: string;
  description: string;
  amount: number;
  paymentMethod: PaymentMethod;
  date: string;
  time: string;
  note?: string;
}

export interface FinancialTransaction {
  id: string;
  type: 'Sale' | 'Due Collection' | 'Return' | 'Expense' | 'Stock In';
  refId: string; // Invoice ID, DueCollection ID, Return ID, or Expense ID
  invoiceNumber?: string;
  customerName?: string;
  amount: number;
  paid: number;
  due: number;
  paymentMethod: PaymentMethod;
  description: string;
  date: string;
  time: string;
}

export interface TopSellingProductItem {
  productId: string;
  productName: string;
  category: ProductCategory;
  brand: BrandName;
  modelNumber: string;
  frontPhoto?: string;
  quantitySold: number;
  totalSalesValue: number;
  currentStock: number;
  alertLimit: number;
  purchasePrice: number;
  retailPrice: number;
  wholesalePrice: number;
  replenishmentUrgency: 'critical' | 'warning' | 'caution' | 'healthy';
  replenishmentLabel: string;
  replenishmentRecommendation: string;
  // Trend indicators vs previous month
  lastMonthQuantitySold: number;
  growthPercentage: number; // e.g. 25 for +25%, -10 for -10%
  growthDirection: 'up' | 'down' | 'neutral' | 'new';
  growthLabel: string; // formatted text e.g. "+25%", "-10%", "New"
}

export interface QuickReportSummary {
  monthName: string;
  monthKey: string; // e.g. "2026-09"
  year: number;
  topProducts: TopSellingProductItem[];
  totalUnitsSoldInMonth: number;
  totalSalesValueInMonth: number;
  totalProductsSoldInMonth: number;
}
