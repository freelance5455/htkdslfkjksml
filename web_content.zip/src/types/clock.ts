export type FontStyle = 'jetbrains' | 'orbitron' | 'jakarta' | 'bebas' | 'segment' | 'vt323';

export interface ClockTheme {
  id: string;
  name: string;
  description: string;
  category: 'oled' | 'retro' | 'cyber' | 'minimal' | 'vintage';
  background: string;
  surfaceBg: string;
  border: string;
  textPrimary: string;
  textSecondary: string;
  textAccent: string;
  segmentUnlit: string;
  glowColor: string;
  displayGlow: boolean;
  fontStyle: FontStyle;
  pattern: 'none' | 'dots' | 'grid' | 'scanlines';
}

export type AlarmSoundId = 'chime' | 'digital' | 'marimba' | 'radar' | 'zen' | 'energetic';

export interface Alarm {
  id: string;
  time: string; // HH:mm format (24h), e.g. "07:30"
  label: string;
  enabled: boolean;
  days: number[]; // 0 = Sun, 1 = Mon, ..., 6 = Sat. Empty array = once / today or tomorrow
  sound: AlarmSoundId;
  volume: number; // 0.1 to 1.0
  snoozeDurationMinutes: number; // 5, 10, 15
  createdAt: number;
  lastTriggeredDate?: string; // YYYY-MM-DD to avoid double triggering in same minute
}

export interface ClockSettings {
  hour12: boolean;
  showSeconds: boolean;
  showDate: boolean;
  showMilliseconds: boolean;
  showTimezone: boolean;
  blinkColons: boolean;
  hourlyChime: boolean;
  brightness: number; // 10 to 100
  activeThemeId: string;
  customTheme?: Partial<ClockTheme>;
  soundEnabled: boolean;
  timezone: string; // 'local' or IANA timezone string e.g. 'America/New_York'
}

export interface ActiveAlarmTrigger {
  alarm: Alarm;
  triggeredAt: number;
}
