export interface Song {
  id: string;
  title: string;
  artist: string;
  artistId?: string;
  album: string;
  duration: number; // in seconds
  coverUrl: string;
  audioUrl: string;
  youtubeId?: string; // YouTube Video / Music Track ID
  lyrics: LyricLine[];
  genre: string;
  mood: string;
  bpm: number;
  plays: number;
  liked?: boolean;
  downloaded?: boolean;
  year?: number;
}

export interface LyricLine {
  time: number; // in seconds
  text: string;
}

export interface Playlist {
  id: string;
  title: string;
  description: string;
  coverUrl: string;
  songs: Song[];
  isCustom?: boolean;
  createdAt?: string;
}

export interface Artist {
  id: string;
  name: string;
  avatarUrl: string;
  subscribers: string;
  bio: string;
  monthlyListeners: string;
  topSongs: Song[];
}

export type PlaybackMode = 'repeat-off' | 'repeat-all' | 'repeat-one';

export type VibeMode = 'same-wave' | 'discover-different' | 'familiar' | 'upbeat' | 'chill' | 'same-artist';

export interface EqualizerPreset {
  id: string;
  name: string;
  bands: [number, number, number, number, number]; // 60Hz, 230Hz, 910Hz, 3.6kHz, 14kHz (in dB, -12 to +12)
  bassBoost?: number; // 0 to 10
  reverb?: number; // 0 to 10
}
