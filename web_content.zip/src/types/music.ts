export interface LyricLine {
  time: number; // in seconds
  text: string;
}

export interface SongColorTheme {
  from: string;
  via?: string;
  to: string;
  accent: string;
}

export interface Song {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  album: string;
  albumId: string;
  albumArt: string;
  duration: string;
  durationSec: number;
  genre: 'Chill' | 'Romantic' | 'Workout' | 'Party' | 'Sad' | 'Focus' | 'Lo-Fi' | 'Bollywood' | 'Bengali' | 'English';
  releaseDate: string;
  lyrics: LyricLine[];
  isLiked?: boolean;
  playCount: number;
  bpm: number;
  colorTheme: SongColorTheme;
  isDownloaded?: boolean;
  downloadProgress?: number; // 0 to 100
  downloadSizeMb?: number;
  synthPreset: 'synthwave' | 'lofi' | 'ambient' | 'acoustic' | 'pop' | 'dance' | 'bengali';
}

export interface Artist {
  id: string;
  name: string;
  image: string;
  bio: string;
  followers: string;
  monthlyListeners: string;
  genres: string[];
  topSongIds: string[];
  colorTheme: SongColorTheme;
  verified?: boolean;
}

export interface Album {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  cover: string;
  releaseDate: string;
  year: string;
  songIds: string[];
  colorTheme: SongColorTheme;
}

export interface Playlist {
  id: string;
  title: string;
  description: string;
  cover: string;
  creator: string;
  songIds: string[];
  isPublic: boolean;
  createdAt: string;
  colorTheme: SongColorTheme;
  isCustom?: boolean;
}

export interface UserSettings {
  darkMode: boolean;
  audioQuality: 'Auto' | 'Low' | 'Normal' | 'High' | 'Very High';
  downloadQuality: 'Normal' | 'High' | 'Lossless';
  notifications: boolean;
  dataSaver: boolean;
  language: 'English' | 'Bengali' | 'Hindi' | 'Spanish';
  crossfadeSec: number;
  equalizerPreset: 'Bass Boost' | 'Vocal' | 'Electronic' | 'Rock' | 'Acoustic' | 'Flat';
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  stats: {
    playlists: number;
    likedSongs: number;
    following: number;
    followers: number;
  };
  settings: UserSettings;
}

export type NavTab = 'home' | 'search' | 'library' | 'downloads' | 'profile';
export type LibraryTab = 'playlists' | 'liked' | 'albums' | 'artists' | 'recent';
export type RepeatMode = 'off' | 'all' | 'one';
