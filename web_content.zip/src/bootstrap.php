<?php
declare(strict_types=1);
session_start();
$envFile = dirname(__DIR__).'/.env';
if (!is_file($envFile)) { http_response_code(500); exit('Configure .env first.'); }
$env = parse_ini_file($envFile, false, INI_SCANNER_RAW) ?: [];
function envv(string $key, ?string $default=null): ?string { global $env; return $env[$key] ?? $default; }
function db(): PDO {
 static $pdo;
 if (!$pdo) {
  $dsn='mysql:host='.envv('DB_HOST','127.0.0.1').';port='.envv('DB_PORT','3306').';dbname='.envv('DB_NAME').';charset=utf8mb4';
  $pdo=new PDO($dsn,envv('DB_USER'),envv('DB_PASS'),[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
 }
 return $pdo;
}
function e(?string $s): string { return htmlspecialchars($s ?? '',ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function require_auth(): void { if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; } }
function csrf(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function check_csrf(): void { if(!hash_equals(csrf(),$_POST['csrf']??'')){http_response_code(419);exit('Invalid request token');} }
function app_key(): string { $k=envv('APP_KEY',''); if(strlen($k)<32) throw new RuntimeException('APP_KEY must be at least 32 characters'); return hash('sha256',$k,true); }
function encrypt_secret(string $plain): string { $iv=random_bytes(12); $tag=''; $cipher=openssl_encrypt($plain,'aes-256-gcm',app_key(),OPENSSL_RAW_DATA,$iv,$tag); return base64_encode($iv.$tag.$cipher); }
function decrypt_secret(string $encoded): string { $raw=base64_decode($encoded,true); if($raw===false||strlen($raw)<29) return ''; $plain=openssl_decrypt(substr($raw,28),'aes-256-gcm',app_key(),OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16)); return $plain===false?'':$plain; }
