// Horloge de match : le temps est injecté par l'appelant pour rester testable.
// Règle de jeu demandée : 20 secondes de réflexion par tour.
// À expiration, le joueur perd la main ; aucune pièce n’est retirée.
export const DEFAULT_SECONDS_PER_TURN = 20;

export function createTurnClock(secondsPerTurn = DEFAULT_SECONDS_PER_TURN) {
  if (!Number.isFinite(secondsPerTurn) || secondsPerTurn <= 0) throw new Error('Durée de tour invalide');
  return { secondsPerTurn, remainingMs: Math.round(secondsPerTurn * 1000), deadlineAt: null, running: false, expired: false, turns: 0 };
}

export function startTurnClock(clock, now = Date.now()) {
  if (!Number.isFinite(now)) throw new Error('Horodatage invalide');
  if (clock.expired) return clock;
  clock.remainingMs = Math.round(clock.secondsPerTurn * 1000);
  clock.deadlineAt = now + clock.remainingMs;
  clock.running = true;
  return clock;
}

export function pauseTurnClock(clock, now = Date.now()) {
  if (!clock.running) return clock;
  clock.remainingMs = Math.max(0, clock.deadlineAt - now);
  clock.running = false;
  clock.deadlineAt = null;
  if (clock.remainingMs === 0) clock.expired = true;
  return clock;
}

export function remainingTurnMs(clock, now = Date.now()) {
  if (clock.expired) return 0;
  if (!clock.running) return Math.max(0, clock.remainingMs);
  return Math.max(0, clock.deadlineAt - now);
}

export function completeTurnClock(clock, now = Date.now()) {
  if (clock.expired || remainingTurnMs(clock, now) <= 0) {
    clock.remainingMs = 0;
    clock.running = false;
    clock.deadlineAt = null;
    clock.expired = true;
    return { accepted: false, expired: true, clock };
  }
  clock.turns += 1;
  clock.remainingMs = Math.max(0, clock.deadlineAt - now);
  clock.running = false;
  clock.deadlineAt = null;
  return { accepted: true, expired: false, clock };
}

export function expireTurnClock(clock) {
  clock.remainingMs = 0;
  clock.deadlineAt = null;
  clock.running = false;
  clock.expired = true;
  return clock;
}

// Prépare l'horloge pour le camp suivant après un coup ou une perte de main.
// Ne démarre pas le décompte : l'appelant le lance quand ce camp est prêt à jouer.
export function passTurnClock(clock) {
  clock.expired = false;
  clock.running = false;
  clock.deadlineAt = null;
  clock.remainingMs = Math.round(clock.secondsPerTurn * 1000);
  return clock;
}
