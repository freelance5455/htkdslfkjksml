/**
 * GODEX P4.8 — Universal Cinematic Camera, Optical Simulation & Shot Intelligence Test Suite
 * 
 * Tests and empirically validates:
 * 1. Camera Body & Cine Lens Physical Specifications Database
 * 2. Deterministic Optical Physics (FOV, DOF, Hyperfocal, CoC Zeiss Formula, Bokeh Circle)
 * 3. Anamorphic Lens Physics & Squeeze Factor
 * 4. Spatial Camera Continuity Rule Engine (180° Action Axis, 30° Jump Cut, Motion Vector Collision)
 * 5. Prompt-to-Camera Intelligence Semantic Parsing & Multi-Attribute Extraction
 * 6. 3D Spatial Trajectory Interpolation & Waypoint Generation
 * 7. Multi-Shot Sequence Planning with Optical Specs & Continuity Auditing
 * 8. Zero-Fabrication & Epistemic Truth Classification Invariant
 */

import { CAMERA_BODIES, CINE_LENSES } from './creative/camera/cameraBodiesAndLenses';
import { OpticalSimulationEngine } from './creative/camera/opticalSimulationEngine';
import { CameraContinuityEngine } from './creative/camera/cameraContinuityEngine';
import { PromptCameraExtractor } from './creative/camera/promptCameraExtractor';
import { CameraControlEngine } from './creative/cameraControlEngine';
import { ShotPlanningEngine } from './creative/shotPlanningEngine';
import { CameraShotSpec, CameraPose3D, CameraKinematics } from './creative/camera/cinematicCameraTypes';

export interface P48TestResult {
  suite: string;
  name: string;
  passed: boolean;
  message?: string;
  latencyMs: number;
  data?: any;
}

export interface P48TestReport {
  total: number;
  passed: number;
  failed: number;
  results: P48TestResult[];
  durationMs: number;
}

export class UniversalAppBuilderP48Test {
  private static instance: UniversalAppBuilderP48Test | null = null;
  private opticalEngine: OpticalSimulationEngine;
  private continuityEngine: CameraContinuityEngine;
  private promptExtractor: PromptCameraExtractor;
  private cameraControl: CameraControlEngine;
  private shotPlanner: ShotPlanningEngine;

  private constructor() {
    this.opticalEngine = OpticalSimulationEngine.getInstance();
    this.continuityEngine = CameraContinuityEngine.getInstance();
    this.promptExtractor = PromptCameraExtractor.getInstance();
    this.cameraControl = CameraControlEngine.getInstance();
    this.shotPlanner = ShotPlanningEngine.getInstance();
  }

  public static getInstance(): UniversalAppBuilderP48Test {
    if (!UniversalAppBuilderP48Test.instance) {
      UniversalAppBuilderP48Test.instance = new UniversalAppBuilderP48Test();
    }
    return UniversalAppBuilderP48Test.instance;
  }

  public async runAllTests(): Promise<P48TestReport> {
    const startTime = performance.now();
    const results: P48TestResult[] = [];

    // --- TEST 1: Camera Body & Lens Database Integrity ---
    results.push(this.testCameraBodiesAndLensesDatabase());

    // --- TEST 2: Optical Physics FOV Calculations (Full Frame vs Super35 vs IMAX) ---
    results.push(this.testFieldOfViewPhysics());

    // --- TEST 3: Depth of Field & Hyperfocal Distance Calculations ---
    results.push(this.testDepthOfFieldPhysics());

    // --- TEST 4: Anamorphic Lens Physics & Squeeze Factor ---
    results.push(this.testAnamorphicOptics());

    // --- TEST 5: Camera Continuity 180-Degree Axis Rule Enforcement ---
    results.push(this.testContinuity180DegreeAxisRule());

    // --- TEST 6: Camera Continuity 30-Degree Jump Cut Detection ---
    results.push(this.testContinuity30DegreeJumpCutRule());

    // --- TEST 7: Prompt-to-Camera Intelligence Multi-Attribute Extraction ---
    results.push(this.testPromptCameraExtractor());

    // --- TEST 8: 3D Spatial Trajectory & Waypoint Kinematics ---
    results.push(this.testCameraTrajectoryWaypoints());

    // --- TEST 9: Multi-Shot Cinematic Planning Engine ---
    results.push(this.testCinematicShotPlanner());

    // --- TEST 10: Epistemic Truth & Invariant Verification ---
    results.push(this.testEpistemicTruthInvariant());

    const durationMs = Number((performance.now() - startTime).toFixed(2));
    const passed = results.filter(r => r.passed).length;
    const failed = results.length - passed;

    return {
      total: results.length,
      passed,
      failed,
      results,
      durationMs
    };
  }

  // 1. Camera Body & Lens DB Verification
  private testCameraBodiesAndLensesDatabase(): P48TestResult {
    const t0 = performance.now();
    const bodyKeys = Object.keys(CAMERA_BODIES);
    const lensKeys = Object.keys(CINE_LENSES);

    if (bodyKeys.length < 5) {
      return {
        suite: 'P4.8 Camera Hardware DB',
        name: 'Database Completeness',
        passed: false,
        message: `Expected at least 5 camera bodies, found ${bodyKeys.length}`,
        latencyMs: performance.now() - t0
      };
    }

    if (lensKeys.length < 5) {
      return {
        suite: 'P4.8 Camera Hardware DB',
        name: 'Lens Completeness',
        passed: false,
        message: `Expected at least 5 cine lenses, found ${lensKeys.length}`,
        latencyMs: performance.now() - t0
      };
    }

    // Verify ARRI LF and RED Raptor have valid physical sensor dimensions
    const arriLF = CAMERA_BODIES['arri-alexa-mini-lf'];
    const redRaptor = CAMERA_BODIES['red-v-raptor-vv'];

    const passed = arriLF.sensorWidthMm > 35 && redRaptor.sensorWidthMm > 40 && arriLF.baseDynamicRangeStops >= 14;

    return {
      suite: 'P4.8 Camera Hardware DB',
      name: 'Camera & Lens Specification Integrity',
      passed,
      message: passed ? `Validated ${bodyKeys.length} camera bodies and ${lensKeys.length} cine lenses` : 'Sensor dimension check failed',
      latencyMs: performance.now() - t0
    };
  }

  // 2. Field of View Physics
  private testFieldOfViewPhysics(): P48TestResult {
    const t0 = performance.now();
    const fullFrame = CAMERA_BODIES['generic-cinema-35mm']; // 36x24mm
    const super35 = CAMERA_BODIES['arri-alexa-35']; // 27.99x19.22mm

    // For a 50mm lens on 36mm sensor: FOV_H = 2 * atan(36 / (2 * 50)) = 2 * atan(0.36) = ~39.6°
    const fovFF = this.opticalEngine.calculateFieldOfView(fullFrame, 50);
    const fovS35 = this.opticalEngine.calculateFieldOfView(super35, 50);

    const ffWithinRange = fovFF.horizontalDeg >= 38 && fovFF.horizontalDeg <= 41;
    const s35Narrower = fovS35.horizontalDeg < fovFF.horizontalDeg;

    const passed = ffWithinRange && s35Narrower && fovFF.focalLength35mmEquivalentMm === 50;

    return {
      suite: 'P4.8 Optical Physics',
      name: 'Field of View Trigonometric Calculations',
      passed,
      message: passed ? `50mm FF FOV: ${fovFF.horizontalDeg}°, S35 FOV: ${fovS35.horizontalDeg}°` : 'FOV trigonometry calculation out of bounds',
      latencyMs: performance.now() - t0
    };
  }

  // 3. Depth of Field Physics
  private testDepthOfFieldPhysics(): P48TestResult {
    const t0 = performance.now();
    const fullFrame = CAMERA_BODIES['generic-cinema-35mm'];

    // Test at 50mm, f/2.0, focus distance 2.0 meters
    const dof = this.opticalEngine.calculateDepthOfField(50, 2.0, 2.0, fullFrame);

    // Hyperfocal distance: H = (50^2)/(2.0 * 0.025) + 50 = (2500 / 0.05) + 50 = 50,050mm = 50.05m
    const hyperfocalValid = dof.hyperfocalDistanceMeters > 40 && dof.hyperfocalDistanceMeters < 65;
    const nearLimitValid = dof.nearLimitMeters > 1.8 && dof.nearLimitMeters < 2.0;
    const farLimitValid = (dof.farLimitMeters as number) > 2.0 && (dof.farLimitMeters as number) < 2.3;
    const cocValid = dof.cocMm > 0.02 && dof.cocMm < 0.035;

    const passed = hyperfocalValid && nearLimitValid && farLimitValid && cocValid;

    return {
      suite: 'P4.8 Optical Physics',
      name: 'Depth of Field, Hyperfocal & Zeiss CoC',
      passed,
      message: passed ? `DOF @ 2m: [${dof.nearLimitMeters}m - ${dof.farLimitMeters}m], H: ${dof.hyperfocalDistanceMeters}m, CoC: ${dof.cocMm}mm` : 'DOF calculation error',
      latencyMs: performance.now() - t0
    };
  }

  // 4. Anamorphic Optics
  private testAnamorphicOptics(): P48TestResult {
    const t0 = performance.now();
    const arriLF = CAMERA_BODIES['arri-alexa-mini-lf'];

    const fovAnamorphic = this.opticalEngine.calculateFieldOfView(arriLF, 50, 2.0);
    const fovSpherical = this.opticalEngine.calculateFieldOfView(arriLF, 50, 1.0);

    // With 2x anamorphic squeeze, horizontal FOV expands significantly
    const passed = fovAnamorphic.horizontalDeg > fovSpherical.horizontalDeg * 1.6;

    return {
      suite: 'P4.8 Optical Physics',
      name: 'Anamorphic Squeeze & Horizontal FOV Expansion',
      passed,
      message: passed ? `Anamorphic 2x FOV: ${fovAnamorphic.horizontalDeg}° vs Spherical: ${fovSpherical.horizontalDeg}°` : 'Anamorphic squeeze failed',
      latencyMs: performance.now() - t0
    };
  }

  // 5. 180-Degree Action Axis Rule
  private testContinuity180DegreeAxisRule(): P48TestResult {
    const t0 = performance.now();
    const fullFrame = CAMERA_BODIES['generic-cinema-35mm'];
    const lens50 = CINE_LENSES['zeiss-supreme-50'];
    const opticalParams = this.opticalEngine.computeOpticalParameters(fullFrame, lens50, 50, 2.0, 2.0);

    // Create Shot 1 on the left side (pan -45°)
    const shot1: CameraShotSpec = {
      shotId: 'shot-1',
      sceneId: 'scene-test',
      shotNumber: 1,
      archetype: 'MS',
      name: 'Shot 1 Left',
      durationSec: 3,
      cameraBody: fullFrame,
      lens: lens50,
      focalLengthMm: 50,
      apertureFStop: 2.0,
      focusDistanceMeters: 2.0,
      shutterAngleDeg: 180,
      iso: 800,
      fps: 24,
      whiteBalanceKelvin: 5600,
      whiteBalanceTint: 0,
      pose: { heightMeters: 1.6, distanceToSubjectMeters: 2.0, panDeg: -45, tiltDeg: 0, rollDeg: 0 },
      kinematics: { movementType: 'STATIC', intensity: 1, speedCurve: 'LINEAR', velocityMetersPerSec: 0 },
      composition: { rule: 'RULE_OF_THIRDS', subjectScreenX: 0.5, subjectScreenY: 0.5, headroomPercent: 15, leadRoomPercent: 20 },
      lightingSetup: 'Standard',
      subjectDescription: 'Character A',
      opticalSimulation: opticalParams,
      transitionIntent: 'DIRECT_CUT',
      provenance: {
        shotId: 'shot-1',
        generationTimestamp: Date.now(),
        cameraBodyId: fullFrame.id,
        cameraBodyName: fullFrame.name,
        lensId: lens50.id,
        lensName: lens50.name,
        focalLengthMm: 50,
        apertureFStop: 2.0,
        fps: 24,
        shutterAngleDeg: 180,
        iso: 800,
        resolution: '1080p',
        aspectRatio: '16:9',
        engineClassification: 'LOCAL_DETERMINISTIC',
        deterministicCalculationsVerified: true
      }
    };

    // Create Shot 2 crossing the 180 axis (pan +145°, total difference 190° > 170°)
    const shot2: CameraShotSpec = {
      ...shot1,
      shotId: 'shot-2',
      shotNumber: 2,
      name: 'Shot 2 Crossed Axis',
      pose: { heightMeters: 1.6, distanceToSubjectMeters: 2.0, panDeg: 145, tiltDeg: 0, rollDeg: 0 }
    };

    const report = this.continuityEngine.auditSequenceContinuity([shot1, shot2]);
    const foundAxisIssue = report.issues.some(i => i.issueCode === 'AXIS_CROSSING_180');

    const passed = foundAxisIssue && !report.passed;

    return {
      suite: 'P4.8 Camera Continuity',
      name: '180-Degree Action Axis Rule Enforcement',
      passed,
      message: passed ? `Correctly detected 180° axis violation (Delta Pan: 190°)` : 'Failed to catch 180-degree axis crossing',
      latencyMs: performance.now() - t0
    };
  }

  // 6. 30-Degree Jump Cut Rule
  private testContinuity30DegreeJumpCutRule(): P48TestResult {
    const t0 = performance.now();
    const fullFrame = CAMERA_BODIES['generic-cinema-35mm'];
    const lens50 = CINE_LENSES['zeiss-supreme-50'];
    const opticalParams = this.opticalEngine.computeOpticalParameters(fullFrame, lens50, 50, 2.0, 2.0);

    // Shot 1
    const shot1: CameraShotSpec = {
      shotId: 'shot-1',
      sceneId: 'scene-test',
      shotNumber: 1,
      archetype: 'MS',
      name: 'Shot 1',
      durationSec: 3,
      cameraBody: fullFrame,
      lens: lens50,
      focalLengthMm: 50,
      apertureFStop: 2.0,
      focusDistanceMeters: 2.0,
      shutterAngleDeg: 180,
      iso: 800,
      fps: 24,
      whiteBalanceKelvin: 5600,
      whiteBalanceTint: 0,
      pose: { heightMeters: 1.6, distanceToSubjectMeters: 2.0, panDeg: 0, tiltDeg: 0, rollDeg: 0 },
      kinematics: { movementType: 'STATIC', intensity: 1, speedCurve: 'LINEAR', velocityMetersPerSec: 0 },
      composition: { rule: 'RULE_OF_THIRDS', subjectScreenX: 0.5, subjectScreenY: 0.5, headroomPercent: 15, leadRoomPercent: 20 },
      lightingSetup: 'Standard',
      subjectDescription: 'Character A',
      opticalSimulation: opticalParams,
      transitionIntent: 'DIRECT_CUT',
      provenance: {
        shotId: 'shot-1',
        generationTimestamp: Date.now(),
        cameraBodyId: fullFrame.id,
        cameraBodyName: fullFrame.name,
        lensId: lens50.id,
        lensName: lens50.name,
        focalLengthMm: 50,
        apertureFStop: 2.0,
        fps: 24,
        shutterAngleDeg: 180,
        iso: 800,
        resolution: '1080p',
        aspectRatio: '16:9',
        engineClassification: 'LOCAL_DETERMINISTIC',
        deterministicCalculationsVerified: true
      }
    };

    // Shot 2 with only 8° difference and same focal length (Jump Cut!)
    const shot2: CameraShotSpec = {
      ...shot1,
      shotId: 'shot-2',
      shotNumber: 2,
      name: 'Shot 2 Subtle Shift',
      pose: { heightMeters: 1.6, distanceToSubjectMeters: 2.0, panDeg: 8, tiltDeg: 0, rollDeg: 0 }
    };

    const report = this.continuityEngine.auditSequenceContinuity([shot1, shot2]);
    const foundJumpCut = report.issues.some(i => i.issueCode === 'JUMP_CUT_30_DEGREE');

    const passed = foundJumpCut;

    return {
      suite: 'P4.8 Camera Continuity',
      name: '30-Degree Jump Cut Detection',
      passed,
      message: passed ? `Detected jarring jump cut with 8° angle delta` : 'Failed to catch 30-degree jump cut',
      latencyMs: performance.now() - t0
    };
  }

  // 7. Prompt Camera Extraction
  private testPromptCameraExtractor(): P48TestResult {
    const t0 = performance.now();
    const prompt = 'Dramatic extreme close up of cyberpunk android, 85mm lens, f/1.4 aperture, slow dolly in, shot on ARRI Alexa';
    
    const extraction = this.promptExtractor.extractCameraIntent(prompt);

    const focalPassed = extraction.focalLengthMm === 85;
    const aperturePassed = extraction.apertureFStop === 1.4;
    const archetypePassed = extraction.archetype === 'ECU';
    const movementPassed = extraction.cameraMovement === 'DOLLY_IN';
    const cameraHintPassed = extraction.cameraBodyHint?.includes('ARRI');

    const passed = focalPassed && aperturePassed && archetypePassed && movementPassed && cameraHintPassed;

    return {
      suite: 'P4.8 Prompt Intelligence',
      name: 'Semantic Prompt Camera Intent Extraction',
      passed,
      message: passed ? `Extracted: ${extraction.focalLengthMm}mm, f/${extraction.apertureFStop}, ${extraction.archetype}, ${extraction.cameraMovement}, ${extraction.cameraBodyHint}` : 'Extraction mismatch',
      latencyMs: performance.now() - t0
    };
  }

  // 8. 3D Spatial Trajectory Waypoints
  private testCameraTrajectoryWaypoints(): P48TestResult {
    const t0 = performance.now();
    const initialPose: CameraPose3D = {
      heightMeters: 1.6,
      distanceToSubjectMeters: 3.0,
      panDeg: 0,
      tiltDeg: 0,
      rollDeg: 0
    };

    const kinematics: CameraKinematics = {
      movementType: 'DOLLY_IN',
      intensity: 6,
      speedCurve: 'EASE_IN_OUT',
      velocityMetersPerSec: 0.6
    };

    const waypoints = this.cameraControl.generateTrajectoryWaypoints(initialPose, kinematics, 4.0, 50, 10);

    const countValid = waypoints.length === 11; // 0 to 10 inclusive
    const startAtZero = waypoints[0].progressPercent === 0;
    const endAtOne = waypoints[10].progressPercent === 1;
    const dollyInMovedCloser = waypoints[10].pose.distanceToSubjectMeters < initialPose.distanceToSubjectMeters;

    const passed = countValid && startAtZero && endAtOne && dollyInMovedCloser;

    return {
      suite: 'P4.8 3D Kinematics',
      name: 'Spatial Trajectory Waypoint Generation & Easing',
      passed,
      message: passed ? `Generated ${waypoints.length} waypoints, distance moved: ${initialPose.distanceToSubjectMeters}m -> ${waypoints[10].pose.distanceToSubjectMeters}m` : 'Waypoint interpolation failed',
      latencyMs: performance.now() - t0
    };
  }

  // 9. Cinematic Shot Planner
  private testCinematicShotPlanner(): P48TestResult {
    const t0 = performance.now();
    const scenePlan = this.shotPlanner.planCinematicScene({
      prompt: 'Cinematic wide establishing shot of desert ruins, slow pan right',
      durationSec: 10,
      cameraMovement: 'PAN_RIGHT',
      aspectRatio: '16:9',
      resolution: '1080p'
    });

    const hasShots = scenePlan.shots.length >= 2;
    const hasContinuity = scenePlan.continuityReport !== null && typeof scenePlan.continuityReport.score === 'number';
    const allHaveOptical = scenePlan.shots.every(s => s.opticalSimulation && s.opticalSimulation.fov && s.opticalSimulation.dof);

    const passed = hasShots && hasContinuity && allHaveOptical;

    return {
      suite: 'P4.8 Cinematic Planning',
      name: 'Multi-Shot Scene Decomposition & Optical Spec Generation',
      passed,
      message: passed ? `Generated ${scenePlan.shots.length} shots with continuity score ${scenePlan.continuityReport.score}/100` : 'Scene planning failed',
      latencyMs: performance.now() - t0
    };
  }

  // 10. Epistemic Truth & Invariant Verification
  private testEpistemicTruthInvariant(): P48TestResult {
    const t0 = performance.now();
    const scenePlan = this.shotPlanner.planCinematicScene({
      prompt: 'Cinematic portrait',
      durationSec: 6,
      aspectRatio: '16:9',
      resolution: '1080p'
    });

    const firstShot = scenePlan.shots[0];
    const passed = firstShot &&
      firstShot.provenance.engineClassification === 'LOCAL_DETERMINISTIC' &&
      firstShot.provenance.deterministicCalculationsVerified === true;

    return {
      suite: 'P4.8 Epistemic Invariants',
      name: 'Zero-Fabrication & Truth Classification Invariant',
      passed,
      message: passed ? `Verified LOCAL_DETERMINISTIC classification and provenance integrity` : 'Truth classification mismatch',
      latencyMs: performance.now() - t0
    };
  }
}

export async function runUniversalAppBuilderP48Tests(): Promise<P48TestReport> {
  const tester = UniversalAppBuilderP48Test.getInstance();
  return tester.runAllTests();
}
