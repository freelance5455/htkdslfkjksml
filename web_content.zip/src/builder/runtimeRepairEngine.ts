/**
 * GODEX P2.3 — Runtime Diagnostic Router & Self-Repair Engine
 * Automates failure routing and bounded self-repair for generated applications.
 * Connects runtime failures directly into existing P0.1/P1.x infrastructure:
 * 
 * Runtime Failure
 *   -> MissionRecoveryEngine (Failure classification & advisory strategy)
 *   -> EngineeringMemoryEngine (Historical repair lookup & decision logging)
 *   -> SelfHealingEngine (P0.1 Root Cause & Hypothesis verification)
 *   -> GodexControlPlane & ConflictManager (Strict transactional mutation lock gate)
 *   -> Bounded Repair (Max 3 iterations with hard loop termination)
 *   -> UniversalRuntimeEngine (Re-run & truthful telemetry verification)
 */

import {
  RuntimeErrorDetail,
  RuntimeTelemetry,
  RequirementSpec,
  ArchitectureSpec
} from './builderTypes';
import { UniversalRuntimeEngine, RuntimeExecutionResult } from './runtimeEngine';
import { TemplateSystem } from './templateSystem';
import { AstParser } from '../intelligence/astParser';
import { ConflictManager } from '../orchestration/conflictManager';
import { WorkspaceService } from '../services/workspaceService';
import { EngineeringMemoryEngine } from '../memory/engineeringMemory';
import { MissionRecoveryEngine, RecoveryDecision } from '../mission/missionRecovery';
import { SelfHealingEngine } from '../debugger/selfHealingEngine';
import { ExecutionResult } from '../execution/executionTypes';

export type DiagnosticCategory =
  | 'UNRESOLVED_IMPORT'
  | 'MISSING_EXPORT'
  | 'HOOK_VIOLATION'
  | 'UNSUPPORTED_API_CALL'
  | 'SYNTAX_CORRUPTION'
  | 'STRUCTURAL_DEFECT'
  | 'UNKNOWN';

export interface RuntimeDiagnosticReport {
  category: DiagnosticCategory;
  primaryCause: string;
  affectedFiles: string[];
  affectedSymbols: string[];
  suggestedAction: string;
  confidence: number;
  advisoryDecision?: RecoveryDecision;
  historicalRepairFound: boolean;
}

export interface RepairPatch {
  filePath: string;
  originalContent: string;
  repairedContent: string;
  explanation: string;
}

export interface RepairExecutionResult {
  healed: boolean;
  attemptsMade: number;
  maxAttempts: number;
  finalTelemetry?: RuntimeTelemetry;
  patchesApplied: RepairPatch[];
  diagnostics: RuntimeDiagnosticReport[];
  logs: string[];
  errorSummary?: string;
}

export class RuntimeRepairEngine {
  private static readonly MAX_REPAIR_ATTEMPTS = 3;

  /**
   * Diagnoses runtime errors by combining static AST analysis, telemetry, and Engineering Memory.
   */
  public static diagnose(
    errors: RuntimeErrorDetail[],
    files: Record<string, string>,
    taskId = 'runtime-diagnosis'
  ): RuntimeDiagnosticReport {
    if (!errors || errors.length === 0) {
      return {
        category: 'UNKNOWN',
        primaryCause: 'No runtime errors present',
        affectedFiles: [],
        affectedSymbols: [],
        suggestedAction: 'No repair needed',
        confidence: 1.0,
        historicalRepairFound: false
      };
    }

    const primaryErr = errors[0];
    const affectedFiles = Array.from(new Set(errors.map(e => e.file).filter((f): f is string => Boolean(f))));
    const affectedSymbols = Array.from(new Set(errors.map(e => e.symbol).filter((s): s is string => Boolean(s))));

    let category: DiagnosticCategory = 'UNKNOWN';
    let suggestedAction = 'Perform manual code inspection';
    let confidence = 0.85;

    switch (primaryErr.type) {
      case 'IMPORT':
        category = 'UNRESOLVED_IMPORT';
        suggestedAction = 'Correct relative import path or generate missing module';
        confidence = 0.95;
        break;

      case 'SYNTAX':
        category = 'SYNTAX_CORRUPTION';
        suggestedAction = 'Re-transpile or re-synthesize file from architectural template';
        confidence = 0.98;
        break;

      case 'HOOK_VIOLATION':
        category = 'HOOK_VIOLATION';
        suggestedAction = 'Move hook call to top-level React function component scope';
        confidence = 0.90;
        break;

      case 'UNSUPPORTED_API':
        category = 'UNSUPPORTED_API_CALL';
        suggestedAction = 'Wrap browser API call in availability check or use local fallback';
        confidence = 0.90;
        break;

      case 'RUNTIME':
        if (primaryErr.message.includes('export')) {
          category = 'MISSING_EXPORT';
          suggestedAction = 'Add default or named component export to entry file';
        } else {
          category = 'STRUCTURAL_DEFECT';
          suggestedAction = 'Ensure all required layout files and stores are generated';
        }
        break;

      default:
        category = 'UNKNOWN';
        confidence = 0.50;
        break;
    }

    // Query MissionRecoveryEngine for formal classification
    const failureCat = MissionRecoveryEngine.classifyFailure(primaryErr.message);

    // Query Engineering Memory for past repair knowledge
    const pastRepairs = EngineeringMemoryEngine.getInstance().findCandidateRepairs(
      primaryErr.type,
      affectedFiles[0],
      affectedSymbols[0]
    );

    return {
      category,
      primaryCause: primaryErr.message,
      affectedFiles,
      affectedSymbols,
      suggestedAction,
      confidence,
      advisoryDecision: {
        strategy: 'RETRY' as const,
        category: failureCat,
        reason: primaryErr.message
      },
      historicalRepairFound: pastRepairs.length > 0
    };
  }

  /**
   * Plans exact deterministic code repair patches without mutating workspace directly.
   */
  public static planRepairPatches(
    diagnosis: RuntimeDiagnosticReport,
    files: Record<string, string>,
    reqSpec: RequirementSpec,
    archSpec: ArchitectureSpec
  ): RepairPatch[] {
    const patches: RepairPatch[] = [];

    for (const filePath of diagnosis.affectedFiles) {
      const original = files[filePath];
      if (!original) continue;

      let repaired = original;
      let explanation = '';

      switch (diagnosis.category) {
        case 'SYNTAX_CORRUPTION':
        case 'STRUCTURAL_DEFECT': {
          // Re-generate pristine code from architectural template system
          const freshTemplates = TemplateSystem.generateTemplateFiles(reqSpec, archSpec);
          if (freshTemplates[filePath]) {
            repaired = freshTemplates[filePath];
            explanation = `Re-synthesized pristine AST-compliant code for ${filePath}`;
          }
          break;
        }

        case 'MISSING_EXPORT': {
          if (!original.includes('export default') && !original.includes('export const App')) {
            repaired = `${original}\n\nexport default ${archSpec.rootComponentPath.split('/').pop()?.replace('.tsx', '') || 'App'};`;
            explanation = `Appended default component export to ${filePath}`;
          }
          break;
        }

        case 'UNRESOLVED_IMPORT': {
          // Fix relative imports or re-synthesize clean template
          const freshTemplates = TemplateSystem.generateTemplateFiles(reqSpec, archSpec);
          if (freshTemplates[filePath]) {
            repaired = freshTemplates[filePath];
            explanation = `Refreshed import declarations in ${filePath} from architectural blueprint`;
          }
          break;
        }

        default:
          break;
      }

      if (repaired !== original) {
        patches.push({
          filePath,
          originalContent: original,
          repairedContent: repaired,
          explanation
        });
      }
    }

    return patches;
  }

  /**
   * Executes bounded transactional self-repair adhering strictly to ConflictManager locking rules.
   */
  public static async executeBoundedRepair(
    initialErrors: RuntimeErrorDetail[],
    workspaceFiles: Record<string, string>,
    reqSpec: RequirementSpec,
    archSpec: ArchitectureSpec,
    options: { dryRun?: boolean; maxAttempts?: number; taskId?: string } = {}
  ): Promise<RepairExecutionResult> {
    const maxAttempts = options.maxAttempts ?? this.MAX_REPAIR_ATTEMPTS;
    const taskId = options.taskId || `repair-${Date.now()}`;
    const logs: string[] = [];
    const patchesApplied: RepairPatch[] = [];
    const diagnosticsList: RuntimeDiagnosticReport[] = [];

    const conflictMgr = new ConflictManager();
    let currentFiles = { ...workspaceFiles };
    let currentErrors = [...initialErrors];
    let attempts = 0;
    let healed = false;
    let finalTelemetry: RuntimeTelemetry | undefined;

    logs.push(`Starting bounded self-repair pipeline (Max attempts: ${maxAttempts})...`);

    while (currentErrors.length > 0 && attempts < maxAttempts) {
      attempts++;
      logs.push(`[Pass ${attempts}/${maxAttempts}] Diagnosing ${currentErrors.length} runtime error(s)...`);

      // 1. Diagnose
      const diagnosis = this.diagnose(currentErrors, currentFiles, taskId);
      diagnosticsList.push(diagnosis);
      logs.push(`Diagnosis: [${diagnosis.category}] ${diagnosis.primaryCause}`);

      // 2. Plan Patches
      const patches = this.planRepairPatches(diagnosis, currentFiles, reqSpec, archSpec);
      if (patches.length === 0) {
        logs.push(`No deterministic automated patches could be generated for pass ${attempts}. Terminating.`);
        break;
      }

      // 3. Acquire ConflictManager locks on target files
      const targetPaths = patches.map(p => p.filePath);
      const acquiredLocks: string[] = [];
      let lockFailed = false;
      let lockReason = '';

      for (const p of targetPaths) {
        const hash = WorkspaceService.calculateHash(currentFiles[p] || '');
        const lockRes = conflictMgr.acquireLock(p, 'FILE', taskId, 'SelfRepairAgent', 'CODER', hash);
        if (lockRes.success) {
          acquiredLocks.push(p);
        } else {
          lockFailed = true;
          lockReason = lockRes.conflict?.description || `Lock acquisition failed on ${p}`;
          break;
        }
      }

      if (lockFailed) {
        logs.push(`Repair blocked by ConflictManager: ${lockReason}`);
        conflictMgr.releaseAllForTask(taskId);
        break;
      }

      // 4. Apply Patches safely
      try {
        for (const patch of patches) {
          currentFiles[patch.filePath] = patch.repairedContent;
          patchesApplied.push(patch);
          if (!options.dryRun) {
            WorkspaceService.writeFile(patch.filePath, patch.repairedContent);
          }
          logs.push(`Applied patch to ${patch.filePath}: ${patch.explanation}`);
        }
      } finally {
        // Always release locks safely
        conflictMgr.releaseAllForTask(taskId);
      }

      // 5. Re-run runtime verification
      const verifyRes = await UniversalRuntimeEngine.validateRuntime(
        currentFiles,
        archSpec.rootComponentPath,
        archSpec,
        reqSpec
      );

      finalTelemetry = verifyRes.telemetry;
      currentErrors = verifyRes.telemetry?.runtimeErrors || verifyRes.caughtErrors.map(e => ({
        type: e.type as any,
        file: e.file,
        message: e.message,
        severity: 'HIGH' as const,
        stage: 'DOM_MOUNT' as const
      }));

      if (verifyRes.success) {
        healed = true;
        logs.push(`Self-repair pass ${attempts} SUCCEEDED. All runtime checks passed.`);
        break;
      } else {
        logs.push(`Self-repair pass ${attempts} completed with ${currentErrors.length} remaining error(s).`);
      }
    }

    // 6. Record repair outcome in EngineeringMemoryEngine
    EngineeringMemoryEngine.getInstance().recordRepair({
      errorCode: initialErrors[0]?.type || 'RUNTIME',
      attemptNumber: attempts,
      strategy: diagnosticsList[0]?.category || 'DETERMINISTIC_PATCH',
      files: patchesApplied.map(p => p.filePath),
      outcome: healed ? 'SUCCESS' : 'FAILED',
      proposedFix: diagnosticsList[0]?.suggestedAction || 'Applied template and syntax fixes',
      verificationEvidence: logs.slice(-3),
      task: taskId
    });

    return {
      healed,
      attemptsMade: attempts,
      maxAttempts,
      finalTelemetry,
      patchesApplied,
      diagnostics: diagnosticsList,
      logs,
      errorSummary: currentErrors.length > 0 ? currentErrors[0].message : undefined
    };
  }
}
