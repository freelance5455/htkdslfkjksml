/**
 * GODEX P3.1 — Architecture Contract Engine
 * Defines and verifies structural architectural contracts, component boundaries,
 * data flow pipelines, public interfaces, and system invariants.
 */

import { ArchitectureContract, ArchitectureComponentSpec } from './builderTypes';
import { AstParser } from '../intelligence/astParser';

export class ArchitectureContractEngine {
  /**
   * Formulates an architecture contract for a given application objective.
   */
  public static formulateContract(
    title: string,
    components?: ArchitectureComponentSpec[]
  ): ArchitectureContract {
    const contractId = `arch-contract-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

    const defaultComponents: ArchitectureComponentSpec[] = components || [
      {
        name: 'RootApplication',
        path: 'src/App.tsx',
        layer: 'UI',
        publicInterfaces: [{ name: 'App', signature: '(): JSX.Element', description: 'Root component render tree' }],
        dependencies: ['src/types.ts'],
        dependents: ['src/main.tsx']
      },
      {
        name: 'TypesAndContracts',
        path: 'src/types.ts',
        layer: 'DATA',
        publicInterfaces: [{ name: 'DomainEntities', signature: 'export interface ...', description: 'Core domain TypeScript definitions' }],
        dependencies: [],
        dependents: ['src/App.tsx']
      }
    ];

    const dataFlowDiagram = [
      {
        source: 'UserEvents / UI Controls',
        destination: 'State Management / React Hooks',
        payloadType: 'Dispatched Action / State Setter',
        syncType: 'SYNC' as const
      },
      {
        source: 'State Store',
        destination: 'Pure Presentational Components',
        payloadType: 'Props / Observable Context',
        syncType: 'SYNC' as const
      },
      {
        source: 'Async Effects / Engines',
        destination: 'State Updaters',
        payloadType: 'Promise / Async Data Packet',
        syncType: 'ASYNC' as const
      }
    ];

    const invariants = [
      'Zero circular imports across project modules',
      'Unidirectional data flow from state stores to presentation components',
      'No raw API keys or hardcoded credentials in client bundles',
      'All interactive elements declare unique identifiers for accessibility and telemetry',
      'No silent click handlers or unrendered placeholder stubs'
    ];

    return {
      contractId,
      title,
      targetStack: {
        framework: 'React 18',
        language: 'TypeScript 5.x',
        styling: 'Tailwind CSS',
        runtime: 'Vite / Browser Container',
        stateManager: 'React Context & Custom Hooks'
      },
      components: defaultComponents,
      dataFlowDiagram,
      invariants,
      verified: true
    };
  }

  /**
   * Verifies that the workspace conforms to the architecture contract.
   */
  public static verifyCompliance(
    contract: ArchitectureContract,
    files: Record<string, string>
  ): {
    compliant: boolean;
    missingComponents: string[];
    violatedInvariants: string[];
    details: string[];
  } {
    const missingComponents: string[] = [];
    const violatedInvariants: string[] = [];
    const details: string[] = [];

    // 1. Verify existence of planned components
    for (const comp of contract.components) {
      if (!files[comp.path] && !files[`/${comp.path}`]) {
        missingComponents.push(comp.path);
        details.push(`Component missing from workspace: ${comp.path}`);
      }
    }

    // 2. Verify invariant: No API keys in files
    for (const [path, content] of Object.entries(files)) {
      if (
        content.includes('sk_live_') ||
        content.includes('AIzaSy') ||
        content.includes('ghp_') ||
        content.includes('PRIVATE_KEY')
      ) {
        violatedInvariants.push(`Hardcoded credentials detected in ${path}`);
        details.push(`Security invariant violation in ${path}: contains raw secret/API key`);
      }
    }

    // 3. Verify invariant: Clean AST validation
    for (const comp of contract.components) {
      const code = files[comp.path] || files[`/${comp.path}`];
      if (code) {
        const errors = AstParser.validateSyntax(code, comp.path);
        if (errors.length > 0) {
          violatedInvariants.push(`Syntax errors in component ${comp.path}`);
          details.push(`AST syntax violation in ${comp.path}: ${errors[0].message}`);
        }
      }
    }

    const compliant = missingComponents.length === 0 && violatedInvariants.length === 0;

    return {
      compliant,
      missingComponents,
      violatedInvariants,
      details
    };
  }
}
