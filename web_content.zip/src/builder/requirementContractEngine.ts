/**
 * GODEX P3.1 — Requirement Contract Engine
 * Transforms natural-language objectives into unambiguous, bidirectional requirement contracts.
 * Enforces mandatory coverage across Functional, UI, State, Data, Runtime, Security,
 * Performance, and Verification pillars.
 */

import { RequirementContract, RequirementContractItem, RequirementCategory } from './builderTypes';

export class RequirementContractEngine {
  /**
   * Formulates a structured Requirement Contract from an objective string.
   */
  public static formulateContract(objective: string, categoryHint?: string): RequirementContract {
    const contractId = `req-contract-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const items: RequirementContractItem[] = [];
    const lowerObj = objective.toLowerCase();

    // 1. Functional Requirement
    items.push({
      id: 'REQ-FUNC-01',
      category: 'FUNCTIONAL',
      title: 'Core Domain Execution & Workflow',
      specification: `Implement primary domain business logic and state transitions corresponding to: "${objective}".`,
      verificationCriteria: 'All primary user workflows execute with deterministic outputs and zero unhandled exceptions.',
      priority: 'CRITICAL',
      targetComponents: ['src/App.tsx', 'src/types.ts'],
      mappedTaskIds: ['task-code'],
      satisfied: false
    });

    // 2. UI Requirement
    items.push({
      id: 'REQ-UI-01',
      category: 'UI',
      title: 'Responsive & Accessible Layout Interface',
      specification: 'Render a modern, high-contrast, accessible UI structure with responsive layouts and designated control IDs.',
      verificationCriteria: 'Interactive DOM elements mount properly with accessible touch/click targets and structured hierarchy.',
      priority: 'HIGH',
      targetComponents: ['src/App.tsx'],
      mappedTaskIds: ['task-code', 'task-verify'],
      satisfied: false
    });

    // 3. State Management Requirement
    items.push({
      id: 'REQ-STATE-01',
      category: 'STATE',
      title: 'Predictable State Machine & Lifecycle Transitions',
      specification: 'Maintain unambiguous client state without infinite render loops, stale closures, or unhandled null mutations.',
      verificationCriteria: 'State transitions correctly on user events; initial state hydration completes cleanly.',
      priority: 'HIGH',
      targetComponents: ['src/App.tsx'],
      mappedTaskIds: ['task-code'],
      satisfied: false
    });

    // 4. Data Layer Requirement
    items.push({
      id: 'REQ-DATA-01',
      category: 'DATA',
      title: 'Schema Integrity & Type Safety',
      specification: 'Provide strong TypeScript type definitions and schema interfaces for all domain entities.',
      verificationCriteria: 'TypeScript compile verification passes with 0 type errors across all entity schemas.',
      priority: 'CRITICAL',
      targetComponents: ['src/types.ts'],
      mappedTaskIds: ['task-arch', 'task-code'],
      satisfied: false
    });

    // 5. Runtime Requirement
    items.push({
      id: 'REQ-RUN-01',
      category: 'RUNTIME',
      title: 'Container & Browser Compatibility',
      specification: 'Operate within standard browser sandbox and container environments without runtime crashes.',
      verificationCriteria: 'Mounts in virtual/real DOM environment with failureClassification=NONE.',
      priority: 'CRITICAL',
      targetComponents: ['src/main.tsx', 'src/App.tsx'],
      mappedTaskIds: ['task-verify'],
      satisfied: false
    });

    // 6. Security Requirement
    items.push({
      id: 'REQ-SEC-01',
      category: 'SECURITY',
      title: 'Secret Leakage Prevention & Injection Defense',
      specification: 'Ensure zero hardcoded secret keys, credentials, or dangerous unsanitized innerHTML injections.',
      verificationCriteria: 'Automated security boundary scanner reports 0 leaked tokens and 0 security violations.',
      priority: 'CRITICAL',
      targetComponents: ['*'],
      mappedTaskIds: ['task-verify', 'task-rel'],
      satisfied: false
    });

    // 7. Performance Requirement
    items.push({
      id: 'REQ-PERF-01',
      category: 'PERFORMANCE',
      title: 'Render Optimization & Lightweight Footprint',
      specification: 'Maintain responsive rendering with zero unbounded loops or unnecessary re-renders.',
      verificationCriteria: 'Execution engine reports mounting latency under 500ms and smooth interaction loops.',
      priority: 'MEDIUM',
      targetComponents: ['src/App.tsx'],
      mappedTaskIds: ['task-verify'],
      satisfied: false
    });

    // 8. Verification Requirement
    items.push({
      id: 'REQ-VERIF-01',
      category: 'VERIFICATION',
      title: 'Multi-Tier Automated Test & Epistemic Honesty',
      specification: 'Pass multi-tier verification (unit, component, integration) without simulated or fabricated pass flags.',
      verificationCriteria: 'Multi-tier test suite passes 100% with live AST and DOM validation.',
      priority: 'CRITICAL',
      targetComponents: ['src/test/'],
      mappedTaskIds: ['task-test', 'task-rel'],
      satisfied: false
    });

    // Add category-specific requirements if applicable
    if (lowerObj.includes('dashboard') || categoryHint === 'SAAS_DASHBOARD') {
      items.push({
        id: 'REQ-SPEC-SAAS',
        category: 'FUNCTIONAL',
        title: 'Analytical Metric Aggregation & Visualization',
        specification: 'Render real-time summary KPI cards, filtered time-series data, and status indicators.',
        verificationCriteria: 'Summary metrics compute correctly from entity dataset with responsive filtering.',
        priority: 'HIGH',
        targetComponents: ['src/components/MetricCard.tsx', 'src/App.tsx'],
        mappedTaskIds: ['task-code'],
        satisfied: false
      });
    }

    if (lowerObj.includes('media') || lowerObj.includes('creative') || categoryHint === 'CREATIVE_MEDIA_APP') {
      items.push({
        id: 'REQ-SPEC-MEDIA',
        category: 'RUNTIME',
        title: 'Creative Media Timeline & Layer Composition',
        specification: 'Render multi-track canvas/audio timeline with layer controls and honest engine capability status.',
        verificationCriteria: 'Media timeline renders tracks; unsupported generative video reports REQUIRES_ENGINE.',
        priority: 'HIGH',
        targetComponents: ['src/components/Timeline.tsx', 'src/App.tsx'],
        mappedTaskIds: ['task-code'],
        satisfied: false
      });
    }

    const totalRequirements = items.length;
    const satisfiedCount = items.filter(i => i.satisfied).length;
    const coveragePercent = Math.round((satisfiedCount / totalRequirements) * 100);

    return {
      contractId,
      objective,
      createdAt: Date.now(),
      items,
      totalRequirements,
      satisfiedCount,
      coveragePercent,
      immutable: true
    };
  }

  /**
   * Evaluates the satisfaction state of requirement items given workspace and execution evidence.
   */
  public static evaluateSatisfaction(
    contract: RequirementContract,
    evidence: {
      typecheckPassed: boolean;
      buildPassed: boolean;
      runtimeMounted: boolean;
      testsPassed: boolean;
      securityPassed: boolean;
      filesPresent: string[];
    }
  ): RequirementContract {
    const updatedItems = contract.items.map(item => {
      let satisfied = false;
      let reason = '';

      switch (item.category) {
        case 'FUNCTIONAL':
          satisfied = evidence.runtimeMounted && evidence.testsPassed;
          reason = satisfied ? 'Functional requirements verified by DOM mount and test suite.' : 'Tests or runtime failed.';
          break;
        case 'UI':
          satisfied = evidence.runtimeMounted;
          reason = satisfied ? 'UI successfully mounted in virtual DOM.' : 'UI failed to mount.';
          break;
        case 'STATE':
          satisfied = evidence.runtimeMounted && evidence.testsPassed;
          reason = satisfied ? 'State machine initialized without exceptions.' : 'State exceptions occurred.';
          break;
        case 'DATA':
          satisfied = evidence.typecheckPassed;
          reason = satisfied ? 'TypeScript typecheck passed with 0 errors.' : 'Typecheck reported errors.';
          break;
        case 'RUNTIME':
          satisfied = evidence.buildPassed && evidence.runtimeMounted;
          reason = satisfied ? 'Build and runtime execution passed cleanly.' : 'Runtime error encountered.';
          break;
        case 'SECURITY':
          satisfied = evidence.securityPassed;
          reason = satisfied ? 'Zero hardcoded secrets or unsafe injections found.' : 'Security violation detected.';
          break;
        case 'PERFORMANCE':
          satisfied = evidence.runtimeMounted;
          reason = satisfied ? 'Execution completed within acceptable duration limits.' : 'Execution exceeded timeout.';
          break;
        case 'VERIFICATION':
          satisfied = evidence.testsPassed && evidence.typecheckPassed && evidence.buildPassed;
          reason = satisfied ? 'All verification gates completed with truthful evidence.' : 'Verification incomplete.';
          break;
        default:
          satisfied = evidence.runtimeMounted;
          reason = satisfied ? 'Verified.' : 'Pending verification.';
      }

      return {
        ...item,
        satisfied,
        evidence: reason
      };
    });

    const satisfiedCount = updatedItems.filter(i => i.satisfied).length;
    const coveragePercent = Math.round((satisfiedCount / updatedItems.length) * 100);

    return {
      ...contract,
      items: updatedItems,
      satisfiedCount,
      coveragePercent
    };
  }
}
