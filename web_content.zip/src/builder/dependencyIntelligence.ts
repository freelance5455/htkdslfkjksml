/**
 * GODEX P2.0 — Dependency Intelligence Engine
 * Grounded dependency analyzer that inspects the actual package.json manifest.
 * Enforces Hard Constraints:
 * 1. Spend ₹0
 * 2. Do not add unnecessary npm packages
 * 3. Prefer browser-native APIs and already-installed packages (lucide-react, motion, canvas-confetti, jszip, etc.)
 * 4. Record explicit deterministic rationale for every decision.
 */

import { DependencyAuditReport, DependencyRequirement } from './builderTypes';

export class DependencyIntelligenceEngine {
  // Hardcoded baseline of pre-installed packages in this workspace
  private static readonly PRE_INSTALLED_PACKAGES: Set<string> = new Set([
    'react',
    'react-dom',
    'lucide-react',
    'motion',
    'canvas-confetti',
    'jszip',
    'express',
    'dotenv',
    '@google/genai',
    '@tailwindcss/vite',
    'tailwindcss',
    'typescript',
    'vite',
    'tsx',
    'esbuild'
  ]);

  // Catalog of common unnecessary packages and their browser/local alternatives
  private static readonly UNNECESSARY_PACKAGE_ALTERNATIVES: Record<string, { alternative: string; reason: string }> = {
    'uuid': {
      alternative: 'crypto.randomUUID()',
      reason: 'Browser standard Web Crypto API provides native RFC4122 v4 UUIDs without dependencies.'
    },
    'nanoid': {
      alternative: 'Math.random().toString(36).slice(2, 10)',
      reason: 'Standard alphanumeric string generator is zero-dependency.'
    },
    'lodash': {
      alternative: 'Standard ES6+ Array/Object methods (map, filter, reduce, Object.entries)',
      reason: 'Modern JavaScript features replace utility packages natively.'
    },
    'moment': {
      alternative: 'Intl.DateTimeFormat and standard Date methods',
      reason: 'Native Intl APIs handle date formatting and localization without bloat.'
    },
    'dayjs': {
      alternative: 'Native Date and Intl.RelativeTimeFormat',
      reason: 'Native browser APIs provide time and date calculations.'
    },
    'axios': {
      alternative: 'Standard fetch() API with async/await',
      reason: 'Window.fetch is native in modern browsers with full Promise support.'
    },
    'clsx': {
      alternative: 'Simple template literals or array .filter(Boolean).join(" ")',
      reason: 'Tailwind class composition is straightforward with native strings.'
    },
    'tailwind-merge': {
      alternative: 'Deterministic class organization and modular Tailwind prefixes',
      reason: 'Clean architectural design avoids overlapping class conflicts.'
    },
    'howler': {
      alternative: 'Web Audio API (AudioContext / HTML5 Audio element)',
      reason: 'Browser AudioContext provides low-latency synthesis and sample playback.'
    },
    'chart.js': {
      alternative: 'HTML5 Canvas 2D or SVG procedural charts',
      reason: 'Custom SVG/Canvas charts are faster, responsive, and zero-dependency.'
    },
    'recharts': {
      alternative: 'Custom SVG responsive chart components',
      reason: 'Lightweight SVG components provide full control over rendering and aesthetics.'
    },
    'framer-motion': {
      alternative: 'motion (motion/react v12)',
      reason: 'motion v12 is already installed in the workspace.'
    }
  };

  /**
   * Checks if a package is already installed in the workspace.
   */
  public static isPackageInstalled(packageName: string): boolean {
    const cleanName = packageName.toLowerCase().trim();
    return this.PRE_INSTALLED_PACKAGES.has(cleanName);
  }

  /**
   * Evaluates a list of suggested dependencies and produces an authoritative audit report.
   */
  public static auditDependencies(
    suggestedPackages: string[] = [],
    workspacePackageJsonContent?: string
  ): DependencyAuditReport {
    const installedList = Array.from(this.PRE_INSTALLED_PACKAGES);
    const requiredNew: string[] = [];
    const avoided: Array<{ requested: string; reason: string; builtInReplacement: string }> = [];
    const recommendations: string[] = [];

    // Parse package.json if provided
    let declaredDeps = new Set(this.PRE_INSTALLED_PACKAGES);
    if (workspacePackageJsonContent) {
      try {
        const parsed = JSON.parse(workspacePackageJsonContent);
        const deps = Object.keys(parsed.dependencies || {});
        const devDeps = Object.keys(parsed.devDependencies || {});
        declaredDeps = new Set([...deps, ...devDeps, ...this.PRE_INSTALLED_PACKAGES]);
      } catch {
        // Fallback to pre-installed set
      }
    }

    for (const pkg of suggestedPackages) {
      const clean = pkg.toLowerCase().trim();
      if (!clean) continue;

      if (declaredDeps.has(clean)) {
        recommendations.push(`Use pre-installed package "${clean}".`);
        continue;
      }

      // Check if this package is unnecessary and has a native alternative
      if (this.UNNECESSARY_PACKAGE_ALTERNATIVES[clean]) {
        const alt = this.UNNECESSARY_PACKAGE_ALTERNATIVES[clean];
        avoided.push({
          requested: clean,
          reason: alt.reason,
          builtInReplacement: alt.alternative
        });
        recommendations.push(`Avoided installing "${clean}": Use ${alt.alternative} (${alt.reason})`);
      } else {
        // Only mark as required new if genuinely needed and not replaceable
        requiredNew.push(clean);
        recommendations.push(`External package "${clean}" required if functionality cannot be built with native APIs.`);
      }
    }

    return {
      installedDependencies: installedList,
      requiredNewDependencies: requiredNew,
      unnecessaryDependenciesAvoided: avoided,
      isClean: requiredNew.length === 0,
      recommendations
    };
  }

  /**
   * Generates dependency requirements for an app specification.
   */
  public static resolveRequirements(
    neededCapabilities: string[]
  ): DependencyRequirement[] {
    const reqs: DependencyRequirement[] = [];

    // Core React
    reqs.push({
      name: 'react',
      required: true,
      isPreInstalled: true,
      rationale: 'Core rendering runtime.'
    });

    // Icons
    reqs.push({
      name: 'lucide-react',
      required: true,
      isPreInstalled: true,
      rationale: 'Clean vector iconography system.'
    });

    // Animation if motion requested
    if (neededCapabilities.some(c => c.toLowerCase().includes('animat') || c.toLowerCase().includes('motion') || c.toLowerCase().includes('transition'))) {
      reqs.push({
        name: 'motion',
        required: true,
        isPreInstalled: true,
        rationale: 'Hardware-accelerated layout and entry animations.'
      });
    }

    // Zip export if requested
    if (neededCapabilities.some(c => c.toLowerCase().includes('zip') || c.toLowerCase().includes('export') || c.toLowerCase().includes('archive'))) {
      reqs.push({
        name: 'jszip',
        required: true,
        isPreInstalled: true,
        rationale: 'Client-side ZIP archiving.'
      });
    }

    // Confetti if celebration requested
    if (neededCapabilities.some(c => c.toLowerCase().includes('confetti') || c.toLowerCase().includes('game') || c.toLowerCase().includes('reward'))) {
      reqs.push({
        name: 'canvas-confetti',
        required: true,
        isPreInstalled: true,
        rationale: 'Visual particle rewards.'
      });
    }

    return reqs;
  }
}
