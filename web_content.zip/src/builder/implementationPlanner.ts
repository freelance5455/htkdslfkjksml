/**
 * GODEX P2.0 — Universal Implementation Planner
 * Decomposes architecture specifications into an executable, dependency-ordered TaskGraph DAG.
 * Reuses the existing Phase 6 TaskGraph & Phase 9 MissionManager infrastructure.
 */

import { RequirementSpec, ArchitectureSpec } from './builderTypes';
import { OrchestrationTask, AgentRoleType, RiskLevel } from '../orchestration/orchestrationTypes';

export class ImplementationPlanner {
  /**
   * Decomposes the planned architecture into an executable DAG of OrchestrationTasks.
   */
  public static decomposeTasks(
    missionId: string,
    reqSpec: RequirementSpec,
    archSpec: ArchitectureSpec
  ): OrchestrationTask[] {
    const tasks: OrchestrationTask[] = [];

    // 1. Task: ARCHITECT - System Design & Capability Boundary Alignment
    const tArchId = `task-1-arch-${Date.now()}`;
    tasks.push({
      id: tArchId,
      title: `Architect: Modular System Architecture for ${reqSpec.appName}`,
      description: `Formalize architecture specifications across ${archSpec.pages.length} views and ${archSpec.components.length} components. Establish capability boundaries for ${reqSpec.externalEngineRequirements.length} external requirements.`,
      role: 'ARCHITECT',
      status: 'READY',
      dependencies: [],
      targetFiles: [archSpec.typesFilePath, archSpec.rootComponentPath],
      priority: 'CRITICAL',
      assignedAgentId: 'agent-architect',
      risk: 'LOW',
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    });

    // 2. Task: RESEARCHER - Dependency & Symbol Indexing
    const tResId = `task-2-res-${Date.now()}`;
    tasks.push({
      id: tResId,
      title: `Researcher: Dependency & Symbol Extraction for ${reqSpec.appName}`,
      description: `Audit workspace dependencies (pre-installed: react, lucide-react, motion) and ensure zero unnecessary packages are requested. Extract type symbols for data entities.`,
      role: 'RESEARCHER',
      status: 'QUEUED',
      dependencies: [{ taskId: tArchId, type: 'HARD' }],
      targetFiles: [archSpec.typesFilePath],
      priority: 'HIGH',
      assignedAgentId: 'agent-researcher',
      risk: 'LOW',
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    });

    // 3. Task: CODER (Types & Data Models)
    const tTypesId = `task-3-types-${Date.now()}`;
    tasks.push({
      id: tTypesId,
      title: `Coder: Implement TypeScript Types & Interfaces`,
      description: `Create ${archSpec.typesFilePath} with complete type definitions for entities (${reqSpec.dataRequirements.entities.map(e => e.name).join(', ')}), component props, and state interfaces.`,
      role: 'CODER',
      status: 'QUEUED',
      dependencies: [{ taskId: tResId, type: 'HARD' }],
      targetFiles: [archSpec.typesFilePath],
      priority: 'CRITICAL',
      assignedAgentId: 'agent-coder',
      risk: 'LOW',
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 3,
      createdAt: Date.now()
    });

    // 4. Task: CODER (Services & State Management)
    const tServicesId = `task-4-services-store-${Date.now()}`;
    const serviceFiles = archSpec.services.map(s => s.filePath);
    if (archSpec.stateManagement.storeFilePath) {
      serviceFiles.push(archSpec.stateManagement.storeFilePath);
    }
    tasks.push({
      id: tServicesId,
      title: `Coder: Implement Data Services & State Management`,
      description: `Create data services (${archSpec.services.map(s => s.name).join(', ')}) with LocalStorage persistence and state hooks.`,
      role: 'CODER',
      status: 'QUEUED',
      dependencies: [{ taskId: tTypesId, type: 'HARD' }],
      targetFiles: serviceFiles,
      priority: 'HIGH',
      assignedAgentId: 'agent-coder',
      risk: 'MEDIUM',
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 3,
      createdAt: Date.now()
    });

    // 5. Task: CODER (Subcomponents & UI Elements)
    const tComponentsId = `task-5-components-${Date.now()}`;
    const componentFiles = archSpec.components
      .filter(c => !c.isRootOrPage)
      .map(c => c.filePath);
    tasks.push({
      id: tComponentsId,
      title: `Coder: Implement Modular UI Subcomponents`,
      description: `Build modular components (${archSpec.components.filter(c => !c.isRootOrPage).map(c => c.name).join(', ')}) with Tailwind styling and Lucide icons.`,
      role: 'CODER',
      status: 'QUEUED',
      dependencies: [{ taskId: tServicesId, type: 'HARD' }],
      targetFiles: componentFiles,
      priority: 'HIGH',
      assignedAgentId: 'agent-coder',
      risk: 'MEDIUM',
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 3,
      createdAt: Date.now()
    });

    // 6. Task: CODER (Views & Root App Integration)
    const tViewsId = `task-6-views-app-root-${Date.now()}`;
    const viewFiles = archSpec.pages.map(p => `${archSpec.appSlug}/views/${p.componentRef}.tsx`);
    viewFiles.push(archSpec.rootComponentPath);
    tasks.push({
      id: tViewsId,
      title: `Coder: Implement Page Views & Root App Container`,
      description: `Construct page views (${archSpec.pages.map(p => p.name).join(', ')}) and wire into ${archSpec.rootComponentPath} with responsive navigation.`,
      role: 'CODER',
      status: 'QUEUED',
      dependencies: [{ taskId: tComponentsId, type: 'HARD' }],
      targetFiles: viewFiles,
      priority: 'CRITICAL',
      assignedAgentId: 'agent-coder',
      risk: 'HIGH',
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 3,
      createdAt: Date.now()
    });

    // 7. Task: REVIEWER (Security & Anti-Slop Code Review)
    const tReviewId = `task-7-review-${Date.now()}`;
    tasks.push({
      id: tReviewId,
      title: `Reviewer: Independent Security & AST Quality Review`,
      description: `Scan generated codebase for hardcoded secrets, syntax violations, anti-slop visual compliance, and circular references.`,
      role: 'REVIEWER',
      status: 'QUEUED',
      dependencies: [{ taskId: tViewsId, type: 'HARD' }],
      targetFiles: [archSpec.rootComponentPath, ...serviceFiles],
      priority: 'HIGH',
      assignedAgentId: 'agent-reviewer',
      risk: 'LOW',
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    });

    // 8. Task: TESTER (Unit & Integration Test Suite)
    const tTestId = `task-8-test-${Date.now()}`;
    tasks.push({
      id: tTestId,
      title: `Tester: Execute Automated Test Suite & State Roundtrips`,
      description: `Run unit tests for state stores and component mount verification.`,
      role: 'TESTER',
      status: 'QUEUED',
      dependencies: [{ taskId: tReviewId, type: 'HARD' }],
      targetFiles: [archSpec.rootComponentPath],
      priority: 'HIGH',
      assignedAgentId: 'agent-tester',
      risk: 'LOW',
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    });

    // 9. Task: VERIFIER (Final 6-Pillar Evidence Verification)
    const tVerifyId = `task-9-verify-${Date.now()}`;
    tasks.push({
      id: tVerifyId,
      title: `Verifier: Final Multi-Pillar Evidence Dossier Compilation`,
      description: `Execute static typechecking (tsc), build bundle verification, runtime checks, and compile the final evidence score.`,
      role: 'VERIFIER',
      status: 'QUEUED',
      dependencies: [{ taskId: tTestId, type: 'HARD' }],
      targetFiles: [archSpec.rootComponentPath, archSpec.typesFilePath],
      priority: 'CRITICAL',
      assignedAgentId: 'agent-verifier',
      risk: 'LOW',
      artifactsProduced: [],
      attemptCount: 0,
      maxRetries: 2,
      createdAt: Date.now()
    });

    return tasks;
  }
}
