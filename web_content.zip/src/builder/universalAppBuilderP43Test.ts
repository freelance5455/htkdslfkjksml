/**
 * GODEX P4.3 — Production VFX Core Verification Suite
 * 
 * Tests for deterministic keying, vector masks, rotoscoping,
 * 2D motion tracking, clean-plate object removal, cinematic effects,
 * multi-layer timeline compositing, quality analyzer, and truthful evidence.
 */

import { KeyingEngine } from './creative/vfx/keyingEngine';
import { MaskingEngine } from './creative/vfx/maskingEngine';
import { RotoscopingEngine } from './creative/vfx/rotoscopingEngine';
import { MotionTrackingEngine } from './creative/vfx/motionTrackingEngine';
import { ObjectRemovalEngine } from './creative/vfx/objectRemovalEngine';
import { ParticleEffectsEngine } from './creative/vfx/particleEffectsEngine';
import { CompositingEngine } from './creative/vfx/compositingEngine';
import { VfxQualityAnalyzer } from './creative/vfx/vfxQualityAnalyzer';
import { VfxTimelineEngine } from './creative/vfx/vfxTimelineEngine';
import { VfxExecutionController } from './creative/vfx/vfxExecutionController';
import { VfxEngineRegistry } from './creative/vfx/vfxEngineRegistry';
import { VfxMask } from './creative/vfx/vfxTypes';

export interface P43TestResult {
  suite: string;
  total: number;
  passed: number;
  failed: number;
  failures: string[];
  durationMs: number;
}

export async function runP43VfxCoreTests(): Promise<P43TestResult> {
  const startTime = performance.now();
  let passed = 0;
  let failed = 0;
  const failures: string[] = [];

  const assert = (condition: boolean, testName: string) => {
    if (condition) {
      passed++;
    } else {
      failed++;
      failures.push(testName);
      console.error(`❌ [P4.3 FAIL] ${testName}`);
    }
  };

  const keyingEngine = KeyingEngine.getInstance();
  const maskingEngine = MaskingEngine.getInstance();
  const rotoEngine = RotoscopingEngine.getInstance();
  const trackingEngine = MotionTrackingEngine.getInstance();
  const removalEngine = ObjectRemovalEngine.getInstance();
  const effectsEngine = ParticleEffectsEngine.getInstance();
  const compositingEngine = CompositingEngine.getInstance();
  const qualityAnalyzer = VfxQualityAnalyzer.getInstance();
  const timelineEngine = VfxTimelineEngine.getInstance();
  const executionController = VfxExecutionController.getInstance();
  const registry = VfxEngineRegistry.getInstance();

  const width = 100;
  const height = 100;

  // ----------------------------------------------------
  // TEST 1: CHROMA KEYING & DESPILL SUPPRESSION
  // ----------------------------------------------------
  {
    // Create a 100x100 buffer with pure green screen on left half, subject on right half
    const rgba = new Uint8ClampedArray(width * height * 4);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = (y * width + x) * 4;
        if (x < 50) {
          // Pure green screen background
          rgba[idx] = 0;
          rgba[idx + 1] = 255;
          rgba[idx + 2] = 0;
          rgba[idx + 3] = 255;
        } else {
          // Foreground skin subject
          rgba[idx] = 220;
          rgba[idx + 1] = 160;
          rgba[idx + 2] = 120;
          rgba[idx + 3] = 255;
        }
      }
    }

    const keyParams = keyingEngine.getDefaultParameters('GREEN_SCREEN');
    keyParams.tolerance = 40;
    keyParams.feather = 0;
    keyParams.spillSuppression = 80;

    const res = keyingEngine.processKeying(rgba, width, height, keyParams);

    assert(res.metrics.transparentRatio > 0, 'Keying: green screen pixels identified and keyed');
    assert(res.alphaData.length === width * height, 'Keying: generated valid alpha matte buffer');
    assert(res.despilledData !== undefined && res.despilledData[3] === 0, 'Keying: keyed green pixel is transparent');
    assert(res.despilledData !== undefined && res.despilledData[(50 * width + 75) * 4 + 3] === 255, 'Keying: foreground subject maintains opacity');
  }

  // ----------------------------------------------------
  // TEST 2: VECTOR MASKS & BOOLEAN MODES
  // ----------------------------------------------------
  {
    const mask1: VfxMask = {
      id: 'm1',
      name: 'Rect Mask',
      enabled: true,
      inverted: false,
      mode: 'ADD',
      shapeType: 'RECTANGLE',
      points: [{ x: 10, y: 10 }, { x: 50, y: 50 }],
      opacity: 1,
      feather: 0,
      expansion: 0,
      keyframed: false
    };

    const mask2: VfxMask = {
      id: 'm2',
      name: 'Subtract Mask',
      enabled: true,
      inverted: false,
      mode: 'SUBTRACT',
      shapeType: 'RECTANGLE',
      points: [{ x: 20, y: 20 }, { x: 40, y: 40 }],
      opacity: 1,
      feather: 0,
      expansion: 0,
      keyframed: false
    };

    const matte = maskingEngine.rasterizeMasks([mask1, mask2], width, height);

    // Pixel (15, 15) is inside mask1 and outside mask2 -> 255
    const p1 = matte[15 * width + 15];
    assert(p1 === 255, 'Masks: ADD mode includes rectangle region');

    // Pixel (25, 25) is inside mask2 (SUBTRACT) -> 0
    const p2 = matte[25 * width + 25];
    assert(p2 === 0, 'Masks: SUBTRACT mode correctly cuts out overlapping hole');
  }

  // ----------------------------------------------------
  // TEST 3: ROTOSCOPING KEYFRAME INTERPOLATION
  // ----------------------------------------------------
  {
    const rotoMask: VfxMask = {
      id: 'roto-1',
      name: 'Tracking Mask',
      enabled: true,
      inverted: false,
      mode: 'ADD',
      shapeType: 'POLYGON',
      points: [{ x: 10, y: 10 }, { x: 30, y: 10 }, { x: 30, y: 30 }, { x: 10, y: 30 }],
      opacity: 1,
      feather: 2,
      expansion: 0,
      keyframed: true
    };

    const track = rotoEngine.createRotoTrack(rotoMask, 0);
    // Keyframe at frame 10 with shifted points
    rotoEngine.addKeyframe(rotoMask.id, 10, [
      { x: 20, y: 20 }, { x: 40, y: 20 }, { x: 40, y: 40 }, { x: 20, y: 40 }
    ], 2, 0);

    const evalMaskF5 = rotoEngine.evaluateMaskAtFrame(rotoMask, 5);
    // Midpoint at frame 5 should be approximately x: 15, y: 15
    assert(evalMaskF5.points[0].x >= 14 && evalMaskF5.points[0].x <= 16, 'Rotoscoping: smooth interpolation at frame 5');
  }

  // ----------------------------------------------------
  // TEST 4: 2D MOTION TRACKING (TEMPLATE NCC)
  // ----------------------------------------------------
  {
    const tracker = trackingEngine.initializeTracker('Feature_1', { x: 20, y: 20, width: 20, height: 20 }, 0, 16);

    const prevBuf = new Uint8ClampedArray(width * height * 4);
    const currBuf = new Uint8ClampedArray(width * height * 4);
    // Draw a high contrast white square at (25, 25) in prev, (27, 26) in curr
    for (let dy = 0; dy < 10; dy++) {
      for (let dx = 0; dx < 10; dx++) {
        const pIdx = ((25 + dy) * width + (25 + dx)) * 4;
        prevBuf[pIdx] = 255;
        prevBuf[pIdx + 1] = 255;
        prevBuf[pIdx + 2] = 255;
        prevBuf[pIdx + 3] = 255;

        const cIdx = ((26 + dy) * width + (27 + dx)) * 4;
        currBuf[cIdx] = 255;
        currBuf[cIdx + 1] = 255;
        currBuf[cIdx + 2] = 255;
        currBuf[cIdx + 3] = 255;
      }
    }

    const trackRes = trackingEngine.trackFeaturePoint(tracker, {
      prevFrameData: prevBuf,
      currentFrameData: currBuf,
      width,
      height,
      frameNumber: 1
    });

    assert(trackRes.status === 'TRACKED', 'Motion Tracking: successfully tracked feature point');
    assert(trackRes.confidence >= 40, 'Motion Tracking: high confidence correlation score');
  }

  // ----------------------------------------------------
  // TEST 5: OBJECT REMOVAL (CLEAN-PLATE RECONSTRUCTION)
  // ----------------------------------------------------
  {
    const curr = new Uint8ClampedArray(width * height * 4);
    curr.fill(100);
    // Draw unwanted red object at (50, 50)
    for (let dy = -5; dy <= 5; dy++) {
      for (let dx = -5; dx <= 5; dx++) {
        const idx = ((50 + dy) * width + (50 + dx)) * 4;
        curr[idx] = 255;
        curr[idx + 1] = 0;
        curr[idx + 2] = 0;
      }
    }

    // Mask covering the red object
    const maskMatte = new Uint8ClampedArray(width * height);
    for (let dy = -6; dy <= 6; dy++) {
      for (let dx = -6; dx <= 6; dx++) {
        maskMatte[(50 + dy) * width + (50 + dx)] = 255;
      }
    }

    const neighbor = new Uint8ClampedArray(width * height * 4);
    for (let i = 0; i < width * height; i++) {
      neighbor[i * 4] = 100;
      neighbor[i * 4 + 1] = 100;
      neighbor[i * 4 + 2] = 100;
      neighbor[i * 4 + 3] = 255;
    }

    const removeRes = removalEngine.processDeterministicRemoval(
      curr,
      maskMatte,
      [neighbor],
      width,
      height,
      {
        mode: 'TEMPORAL_CLEAN_PLATE',
        maskId: 'test-mask',
        sampleFrameRadius: 5,
        feather: 4,
        blendEdge: true,
        useNeuralIfAvailable: false
      }
    );

    assert(removeRes.success === true, 'Object Removal: completed clean-plate repair');
    assert(removeRes.truthClassification === 'LOCAL_DETERMINISTIC', 'Object Removal: truthful deterministic classification');
    const repairedIdx = (50 * width + 50) * 4;
    assert(removeRes.processedData[repairedIdx] === 100, 'Object Removal: red object replaced by clean plate');
  }

  // ----------------------------------------------------
  // TEST 6: CINEMATIC EFFECTS & COLOR GRADING
  // ----------------------------------------------------
  {
    const imgBuf = new Uint8ClampedArray(width * height * 4);
    imgBuf.fill(128);

    const fxParams = effectsEngine.getDefaultEffects();
    fxParams.glowEnabled = true;
    fxParams.glowIntensity = 2.0;
    fxParams.colorGradingEnabled = true;
    fxParams.temperature = 20;

    const fxOutput = effectsEngine.applyCinematicEffects(imgBuf, width, height, fxParams);

    assert(fxOutput.length === imgBuf.length, 'Cinematic Effects: valid output buffer size');
    assert(fxOutput[0] !== 128 || fxOutput[2] !== 128, 'Cinematic Effects: color grading applied to channels');
  }

  // ----------------------------------------------------
  // TEST 7: TIMELINE COMPOSITING & TRUTH EVIDENCE
  // ----------------------------------------------------
  {
    const timeline = timelineEngine.createTimeline('Test Timeline', 24, 30, { width, height });
    const layer1 = timelineEngine.addLayer(timeline.tracks[0].id, {
      name: 'Layer A',
      type: 'SOLID_COLOR',
      meta: { color: '#FF0000' },
      blendMode: 'normal'
    });

    const layerBuffers = new Map<string, Uint8ClampedArray>();
    const b1 = new Uint8ClampedArray(width * height * 4);
    b1.fill(255);
    layerBuffers.set(layer1.id, b1);

    const frameRes = executionController.renderFrame(timeline, 0, layerBuffers);

    assert(frameRes.buffer.length === width * height * 4, 'Timeline: rendered composite frame buffer');
    assert(frameRes.evidence.isVerified === true, 'Timeline: generated verified telemetry evidence');
    assert(frameRes.evidence.truthClassification === 'LOCAL_DETERMINISTIC', 'Timeline: truthful LOCAL_DETERMINISTIC status');
    assert(frameRes.evidence.qualityMetrics.overallVfxQualityScore > 0, 'Timeline: valid overall VFX quality score');
  }

  // ----------------------------------------------------
  // TEST 8: ZERO FABRICATION TRUTHFUL CONTRACTS
  // ----------------------------------------------------
  {
    // Ensure neural remote engine is marked unavailable without simulated fabrication
    const neuralEngine = registry.getEngine('vfx-neural-remote');
    assert(neuralEngine !== undefined, 'Registry: neural remote engine declared');
    
    // In disconnected state, neural inpainting must return REQUIRES_ENGINE and not fake results
    const fakeNeuralRes = await removalEngine.executeNeuralInpainting(
      new Uint8ClampedArray(width * height * 4),
      new Uint8ClampedArray(width * height),
      width,
      height
    );

    assert(
      fakeNeuralRes.truthClassification === 'REQUIRES_ENGINE' || fakeNeuralRes.truthClassification === 'REAL_ENGINE',
      'Zero-Fabrication: truthful classification enforced without synthetic fabrication'
    );
  }

  const durationMs = performance.now() - startTime;

  return {
    suite: 'GODEX P4.3 Production VFX Core',
    total: passed + failed,
    passed,
    failed,
    failures,
    durationMs: Math.round(durationMs * 100) / 100
  };
}
