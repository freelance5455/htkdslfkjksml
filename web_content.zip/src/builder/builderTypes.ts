/**
 * GODEX P2.0 — Universal App Builder Core Types
 * Authoritative type definitions for requirements, architecture, capability boundaries,
 * dependency intelligence, and generated application verification.
 */

export type AppCategory = 
  | 'SAAS_DASHBOARD'
  | 'AI_CREATIVE_STUDIO'
  | 'MULTIPLAYER_GAME'
  | 'E_COMMERCE'
  | 'DEVELOPER_TOOL'
  | 'PRODUCTIVITY_APP'
  | 'MEDIA_EDITOR'
  | 'PORTFOLIO_LANDING'
  | 'AUDIO_SYNTHESIZER'
  | 'ANALYTICS_PLATFORM'
  | 'WORKSPACE_TOOL'
  | 'VIDEO_EDITOR'
  | 'IMAGE_EDITOR'
  | 'ANIMATION_EDITOR'
  | 'AUDIO_WORKSTATION'
  | 'STORYBOARD_APP'
  | 'NODE_CREATIVE_APP'
  | 'VFX_COMPOSITOR'
  | 'MOTION_GRAPHICS'
  | 'PRODUCTION_MANAGER'
  | 'CUSTOM_SPA';

export type CapabilityStatus = 
  | 'SUPPORTED'
  | 'AVAILABLE_LOCALLY'
  | 'AVAILABLE_THROUGH_EXISTING_ENGINE'
  | 'REQUIRES_ENGINE'
  | 'LOCAL_AVAILABLE'
  | 'LOCAL_LIMITED'
  | 'EXTERNAL_ENGINE_REQUIRED'
  | 'UNAVAILABLE'
  | 'UNVERIFIED';

export type CapabilityCategory =
  | 'CORE_UI'
  | 'STATE_PERSISTENCE'
  | 'CREATIVE_AI'
  | 'REALTIME_NETWORKING'
  | 'MEDIA_PROCESSING'
  | 'GRAPHICS_CANVAS'
  | 'AUDIO_SYNTHESIS'
  | 'DATA_VISUALIZATION';

export interface CapabilityRegistryEntry {
  id: string;
  name: string;
  category: CapabilityCategory;
  status: CapabilityStatus;
  description: string;
  engineRequiredName?: string;
  localFallbackDescription?: string;
  evidence?: string;
}

export interface FunctionalRequirement {
  id: string;
  name: string;
  description: string;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  acceptanceCriteria: string[];
  capabilityCategory: CapabilityCategory;
}

export interface NonFunctionalRequirements {
  responsive: boolean;
  wcagCompliance: boolean;
  maxLoadTimeMs: number;
  offlineCapable: boolean;
  touchOptimized: boolean;
}

export interface UIRequirements {
  layoutArchetype: string;
  pages: string[];
  colorPaletteHint: string;
  keyComponents: string[];
  viewports: Array<'MOBILE' | 'TABLET' | 'DESKTOP' | 'WIDE'>;
}

export interface DataEntityField {
  type: string;
  required: boolean;
  description?: string;
}

export interface DataEntity {
  name: string;
  fields: Record<string, DataEntityField>;
  persistence: 'LOCAL_STORAGE' | 'MEMORY' | 'INDEXED_DB' | 'API';
  initialSeedCount: number;
}

export interface ExternalEngineRequirement {
  capabilityId: string;
  name: string;
  status: CapabilityStatus;
  requiredEngineName: string;
  localFallbackPossible: boolean;
  fallbackStrategy?: string;
}

export interface DependencyRequirement {
  name: string;
  required: boolean;
  isPreInstalled: boolean;
  rationale: string;
  suggestedAlternative?: string;
}

export interface RequirementRisk {
  category: 'COMPLEXITY' | 'BROWSER_SUPPORT' | 'PERFORMANCE' | 'MISSING_ENGINE' | 'SECURITY';
  description: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  mitigation: string;
}

export interface ProductGoal {
  id: string;
  goal: string;
  targetOutcome: string;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
}

export interface UserRoleSpec {
  role: string;
  description: string;
  permissions: string[];
  isDefault?: boolean;
}

export interface WorkflowSpec {
  id: string;
  name: string;
  description: string;
  steps: string[];
  validationRules: string[];
  triggerAction: string;
}

export interface InteractionSpec {
  id: string;
  trigger: string;
  action: string;
  outcome: string;
  feedbackType?: 'TOAST' | 'MODAL' | 'INLINE_STATUS' | 'SOUND' | 'ANIMATION';
}

export interface ValidationRuleSpec {
  field: string;
  rule: string;
  errorMessage: string;
  required: boolean;
}

export interface SecurityRequirementSpec {
  authRequired: boolean;
  sanitizedInputs: string[];
  sensitiveDataMasking: boolean;
  clientRoleGuards: boolean;
  notes?: string;
}

export interface StateRequirementSpec {
  localStates: string[];
  sharedStates: string[];
  persistentKeys: string[];
  computedProperties: string[];
}

export type CompositeFeatureType =
  | 'AUTHENTICATION_UI'
  | 'METRICS_DASHBOARD'
  | 'CRUD_DATA_TABLE'
  | 'ADVANCED_FILTERS'
  | 'MODAL_WORKFLOWS'
  | 'ANALYTICS_CHARTS'
  | 'SETTINGS_CONFIG'
  | 'AUDIT_LOGS'
  | 'CANVAS_WORKSPACE'
  | 'AUDIO_SYNTHESIZER'
  | 'MEDIA_TIMELINE'
  | 'MEDIA_BROWSER'
  | 'PREVIEW_VIEWPORT'
  | 'INSPECTOR_PANEL'
  | 'LAYER_SYSTEM'
  | 'EFFECTS_RACK'
  | 'AUDIO_MIXER'
  | 'CAPTION_SUBTITLES'
  | 'RENDER_QUEUE'
  | 'GENERATION_QUEUE'
  | 'NODE_GRAPH'
  | 'KEYFRAME_ANIMATOR'
  | 'STORYBOARD_CANVAS'
  | 'HISTORY_UNDO_REDO'
  | 'EXPORT_IMPORT'
  | 'DETAIL_DRAWER';

export interface RequirementSpec {
  applicationType: AppCategory;
  appName: string;
  appSlug: string;
  summary: string;
  productGoals?: ProductGoal[];
  userRoles?: UserRoleSpec[];
  compositeFeatures?: CompositeFeatureType[];
  workflows?: WorkflowSpec[];
  interactions?: InteractionSpec[];
  validationRules?: ValidationRuleSpec[];
  securityRequirements?: SecurityRequirementSpec;
  stateRequirements?: StateRequirementSpec;
  functionalRequirements: FunctionalRequirement[];
  nonFunctionalRequirements: NonFunctionalRequirements;
  uiRequirements: UIRequirements;
  dataRequirements: {
    entities: DataEntity[];
    primaryPersistence: 'LOCAL_STORAGE' | 'MEMORY' | 'INDEXED_DB' | 'API';
  };
  runtimeRequirements: {
    browserApis: string[];
    webWorkers: boolean;
    canvasRequired: boolean;
    audioRequired: boolean;
    webGlRequired: boolean;
  };
  externalEngineRequirements: ExternalEngineRequirement[];
  dependencyRequirements: DependencyRequirement[];
  verificationRequirements: string[];
  risks: RequirementRisk[];
  rawPrompt: string;
}

export interface ComponentSpec {
  name: string;
  filePath: string;
  purpose: string;
  props: Record<string, string>;
  isRootOrPage: boolean;
  subComponents?: string[];
  dependencies: string[];
}

export interface ServiceSpec {
  name: string;
  filePath: string;
  purpose: string;
  methods: Array<{ name: string; signature: string; description: string }>;
}

export interface ArchitectureSpec {
  appSlug: string;
  rootComponentPath: string;
  typesFilePath: string;
  pages: Array<{
    id: string;
    name: string;
    path: string;
    description: string;
    componentRef: string;
  }>;
  components: ComponentSpec[];
  services: ServiceSpec[];
  compositeModules?: string[];
  layoutStructure?: {
    header: boolean;
    sidebar: boolean;
    drawer: boolean;
    bottomNav: boolean;
    modals: string[];
  };
  stateManagement: {
    type: 'REACT_STATE' | 'CONTEXT' | 'CUSTOM_HOOK_STORE';
    storeFilePath?: string;
    globalStateProperties: string[];
  };
  dataLayer: {
    modelsFilePath: string;
    mockDataFilePath?: string;
    persistenceAdapter: string;
  };
  backendRequirements: {
    required: boolean;
    reason: string;
    apiEndpoints: string[];
  };
  runtimeRequirements: string[];
  integrations: string[];
  testingStrategy: {
    unitTests: string[];
    astIntegrity: boolean;
    typecheck: boolean;
    runtimeVerification: string[];
  };
}

export interface DependencyAuditReport {
  installedDependencies: string[];
  requiredNewDependencies: string[];
  unnecessaryDependenciesAvoided: Array<{ requested: string; reason: string; builtInReplacement: string }>;
  isClean: boolean;
  recommendations: string[];
}

export interface UniversalAppBuildOptions {
  autonomyLevel?: 'AUTONOMOUS' | 'CONTROLLED' | 'SUPERVISED';
  dryRun?: boolean;
  onProgress?: (stage: string, progress: number, details: string) => void;
  targetDirectory?: string;
}

export interface GeneratedAppVerificationDossier {
  overallPassed: boolean;
  verificationScore: number;
  typecheckPassed: boolean;
  buildPassed: boolean;
  astPassed: boolean;
  securityPassed: boolean;
  runtimeExecutionPassed: boolean;
  capabilityCompliancePassed: boolean;
  checkedFilesCount: number;
  violations: string[];
  logs: string[];
  timestamp: number;
}

export interface GeneratedFileMetadata {
  path: string;
  sizeBytes: number;
  astValid: boolean;
  role: 'ENTRY_POINT' | 'TYPE_DEFINITION' | 'SERVICE' | 'STATE_STORE' | 'COMPONENT' | 'VIEW' | 'DATA_MOCK' | 'TEST';
  hash: string;
}

export type EpistemicPillarStatus = 'KNOWN_VERIFIED' | 'INFERRED' | 'UNKNOWN';

export type CanonicalCapabilityStatus = 'AVAILABLE' | 'REQUIRES_ENGINE' | 'UNAVAILABLE';

export interface VerificationPillarResult {
  pillarName: string;
  status: EpistemicPillarStatus;
  passed: boolean;
  evidence: string;
}

export type RuntimeErrorStage = 'TRANSPILE' | 'IMPORT_RESOLUTION' | 'HOOK_INIT' | 'DOM_MOUNT' | 'EVENT_LOOP' | 'UNKNOWN';

export interface RuntimeErrorDetail {
  type: 'SYNTAX' | 'TYPE' | 'RUNTIME' | 'IMPORT' | 'SECURITY' | 'HOOK_VIOLATION' | 'UNSUPPORTED_API';
  file?: string;
  symbol?: string;
  message: string;
  stack?: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  stage: RuntimeErrorStage;
}

export interface ResolvedImport {
  sourceFile: string;
  specifier: string;
  resolvedPath?: string;
  isInternal: boolean;
  isExternal: boolean;
  status: 'RESOLVED' | 'UNRESOLVED' | 'CIRCULAR';
}

export interface AppRouteSpec {
  path: string;
  name: string;
  componentFile: string;
  isProtected?: boolean;
  rolesAllowed?: string[];
}

export interface AppAssetSpec {
  id: string;
  name: string;
  type: 'SVG_ICON' | 'MOCK_DATA' | 'AUDIO_SYNTH' | 'CANVAS_TEXTURE' | 'MEDIA_CLIP';
  path?: string;
  isGeneratedLocally: boolean;
}

export interface RuntimeTelemetry {
  startupStatus: 'INITIALIZING' | 'MOUNTED' | 'FAILED' | 'UNKNOWN';
  mountStatus: 'MOUNTED_CLEAN' | 'MOUNT_ERROR' | 'UNRESOLVED_IMPORT' | 'SYNTAX_BLOCKED' | 'UNKNOWN';
  runtimeErrors: RuntimeErrorDetail[];
  affectedFiles: string[];
  affectedSymbols: string[];
  executionDurationMs: number;
  failedInitializationStage: RuntimeErrorStage | 'NONE';
  dependencyImportFailures: Array<{ specifier: string; fromFile: string; reason: string }>;
  browserApisAudited: Array<{ api: string; available: boolean; status: CanonicalCapabilityStatus }>;
  lastVerifiedAt: number;
}

export interface GeneratedAppContract {
  applicationIdentity: {
    id: string;
    name: string;
    slug: string;
    category: AppCategory;
    version: string;
    createdAt: number;
  };
  requirementSpec: RequirementSpec;
  architectureSpec: ArchitectureSpec;
  generatedFileManifest: Record<string, GeneratedFileMetadata>;
  entryPoint: string;
  runtimeType?: 'REACT_SPA' | 'BROWSER_HYBRID' | 'CANVAS_ANIMATION' | 'AUDIO_DSP' | 'WORKFLOW_TOOL' | 'CREATIVE_STUDIO';
  requiredBrowserApis?: string[];
  requiredPackages?: string[];
  resolvedImports?: ResolvedImport[];
  routes?: AppRouteSpec[];
  assets?: AppAssetSpec[];
  environmentRequirements?: {
    nodeEnv?: string;
    httpsRequired?: boolean;
    webWorkersSupported?: boolean;
    storageQuotaMb?: number;
  };
  capabilities?: Record<string, CanonicalCapabilityStatus>;
  runtimeRequirements: {
    browserApis: string[];
    webWorkers: boolean;
    canvasRequired: boolean;
    audioRequired: boolean;
    webGlRequired: boolean;
  };
  compositeFeatures?: string[];
  unsupportedCapabilities?: string[];
  externalEngineRequirements?: ExternalEngineRequirement[];
  dependencyRequirements: DependencyRequirement[];
  capabilityRequirements: Record<string, CapabilityStatus>;
  verificationRequirements?: string[];
  telemetry?: RuntimeTelemetry;
  generationStatus: 'PLANNING' | 'SYNTHESIZING' | 'MUTATING' | 'VERIFYING' | 'REPAIRING' | 'COMPLETED' | 'FAILED' | 'BLOCKED';
  verificationStatus: {
    overallPassed: boolean;
    verificationScore: number;
    pillars: Record<string, VerificationPillarResult>;
  };
  errors: string[];
  warnings: string[];
  evidence: string[];
}

export interface UniversalAppBuildResult {
  success: boolean;
  missionId: string;
  requirementSpec: RequirementSpec;
  architectureSpec: ArchitectureSpec;
  generatedFiles: Record<string, string>;
  generatedApp: GeneratedAppContract;
  taskSummary: {
    total: number;
    completed: number;
    failed: number;
  };
  capabilityMatrix: Record<string, CapabilityStatus>;
  verificationDossier: GeneratedAppVerificationDossier;
  executionResult?: ExecutionResult;
  executionVerification?: ExecutionVerificationReport;
  summaryMessage: string;
}

// ============================================================================
// GODEX P2.4 — CREATIVE & MEDIA DATA MODEL CONTRACTS
// ============================================================================

export interface MediaAsset {
  id: string;
  name: string;
  type: 'VIDEO' | 'AUDIO' | 'IMAGE' | 'TEXT' | 'VECTOR' | '3D_MODEL';
  uri: string;
  sizeBytes: number;
  durationSeconds?: number;
  resolution?: { width: number; height: number; aspectRatio: string };
  mimeType: string;
  tags: string[];
  createdAt: number;
}

export interface Keyframe {
  id: string;
  time: number;
  property: string;
  value: number | string;
  interpolation: 'LINEAR' | 'BEZIER' | 'HOLD' | 'EXPONENTIAL';
}

export interface CreativeEffect {
  id: string;
  name: string;
  type: 'COLOR_GRADE' | 'BLUR' | 'VIGNETTE' | 'CHROMA_KEY' | 'GLITCH' | 'FILM_GRAIN' | 'DISTORTION';
  isEnabled: boolean;
  parameters: Record<string, number | string | boolean>;
}

export interface CreativeTransition {
  id: string;
  name: string;
  type: 'CROSS_DISSOLVE' | 'FADE_BLACK' | 'WIPE' | 'SLIDE' | 'ZOOM' | 'WHIP_PAN';
  durationSeconds: number;
  easing: 'LINEAR' | 'EASE_IN' | 'EASE_OUT' | 'EASE_IN_OUT';
}

export interface MediaClip {
  id: string;
  trackId: string;
  assetId: string;
  name: string;
  startTime: number;
  duration: number;
  offsetStart: number;
  trimIn: number;
  trimOut: number;
  speed: number;
  volume: number;
  opacity: number;
  blendMode: 'normal' | 'multiply' | 'screen' | 'overlay' | 'darken' | 'lighten';
  effects: CreativeEffect[];
  keyframes: Keyframe[];
}

export interface MediaTrack {
  id: string;
  name: string;
  type: 'VIDEO' | 'AUDIO' | 'OVERLAY' | 'SUBTITLE' | 'EFFECT';
  order: number;
  isMuted: boolean;
  isSolo: boolean;
  isLocked: boolean;
  isHidden: boolean;
  volume: number;
  clips: MediaClip[];
}

export interface MediaTimeline {
  id: string;
  projectId: string;
  duration: number;
  currentTime: number;
  fps: number;
  tracks: MediaTrack[];
  selectedClipIds: string[];
  isPlaying: boolean;
  zoomLevel: number;
  loop: boolean;
}

export interface CreativeLayer {
  id: string;
  name: string;
  type: 'RASTER' | 'VECTOR' | 'TEXT' | 'ADJUSTMENT' | 'GROUP';
  isVisible: boolean;
  isLocked: boolean;
  opacity: number;
  blendMode: 'normal' | 'multiply' | 'screen' | 'overlay' | 'darken' | 'lighten' | 'color-dodge';
  zIndex: number;
  transform: { x: number; y: number; scaleX: number; scaleY: number; rotation: number };
  filters: Record<string, number>;
}

export interface CreativeShot {
  id: string;
  name: string;
  order: number;
  duration: number;
  cameraAngle?: string;
  prompt?: string;
  clipIds: string[];
}

export interface CreativeScene {
  id: string;
  name: string;
  order: number;
  duration: number;
  shots: CreativeShot[];
  transitionOut?: CreativeTransition;
}

export interface CreativeProject {
  id: string;
  title: string;
  description: string;
  fps: number;
  duration: number;
  resolution: { width: number; height: number; aspectRatio: string };
  sampleRate: number;
  scenes: CreativeScene[];
  timeline: MediaTimeline;
  assets: MediaAsset[];
  layers: CreativeLayer[];
  createdAt: number;
  updatedAt: number;
}

export interface RenderJob {
  id: string;
  projectId: string;
  title: string;
  format: 'MP4' | 'WEBM' | 'GIF' | 'PNG_SEQUENCE' | 'WAV' | 'PRORES';
  resolution: string;
  fps: number;
  status: 'QUEUED' | 'RENDERING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  progress: number; // 0 to 100
  outputUrl?: string;
  error?: string;
  startedAt?: number;
  completedAt?: number;
}

export interface CreativeNodePort {
  id: string;
  name: string;
  type: 'INPUT' | 'OUTPUT';
  dataType: 'IMAGE' | 'VIDEO' | 'AUDIO' | 'VALUE' | 'COLOR' | 'GEOMETRY';
}

export interface CreativeNode {
  id: string;
  label: string;
  type: 'SOURCE' | 'EFFECT' | 'BLEND' | 'COLOR_GRADE' | 'TRANSFORM' | 'GENERATOR' | 'OUTPUT';
  position: { x: number; y: number };
  inputs: CreativeNodePort[];
  outputs: CreativeNodePort[];
  parameters: Record<string, any>;
  state: 'IDLE' | 'PROCESSING' | 'READY' | 'ERROR';
}

export interface CreativeConnection {
  id: string;
  sourceNodeId: string;
  sourcePortId: string;
  targetNodeId: string;
  targetPortId: string;
}

export interface CreativeNodeGraph {
  id: string;
  name: string;
  nodes: CreativeNode[];
  connections: CreativeConnection[];
  activeNodeId?: string;
}

export interface GenerationRequest {
  id: string;
  prompt: string;
  negativePrompt?: string;
  mode: 'TEXT_TO_VIDEO' | 'IMAGE_TO_VIDEO' | 'VIDEO_TO_VIDEO' | 'TEXT_TO_IMAGE' | 'IMAGE_EDIT' | 'AUDIO_GENERATION';
  parameters: {
    width?: number;
    height?: number;
    fps?: number;
    durationSeconds?: number;
    seed?: number;
    steps?: number;
    guidanceScale?: number;
    modelName?: string;
    sourceAssetUrl?: string;
  };
  requestedEngine?: string;
}

export interface GenerationProgress {
  jobId: string;
  stage: 'QUEUED' | 'INFERENCE' | 'POST_PROCESSING' | 'EXPORTING' | 'DONE' | 'FAILED';
  percent: number;
  message: string;
}

export interface GenerationResult {
  jobId: string;
  status: 'SUCCESS' | 'REQUIRES_ENGINE' | 'FAILED';
  outputUrl?: string;
  executionDurationMs: number;
  metadata: Record<string, any>;
  fallbackUsed: boolean;
  epistemicNote: string;
}

export interface GenerationError {
  jobId: string;
  code: 'ENGINE_ABSENT' | 'QUOTA_EXCEEDED' | 'UNSUPPORTED_DIMENSIONS' | 'GPU_OUT_OF_MEMORY' | 'TIMEOUT';
  message: string;
  requiredEngineName?: string;
}

export interface GenerationEngine {
  id: string;
  name: string;
  supportedModes: Array<'TEXT_TO_VIDEO' | 'IMAGE_TO_VIDEO' | 'VIDEO_TO_VIDEO' | 'TEXT_TO_IMAGE' | 'IMAGE_EDIT' | 'AUDIO_GENERATION'>;
  status: CanonicalCapabilityStatus;
  isLocal: boolean;
  description: string;
}

// ============================================================================
// GODEX P2.8 — UNIVERSAL EXECUTION CONTRACT & LIFECYCLE TYPES
// ============================================================================

export type ApplicationLifecycleState =
  | 'CREATE'
  | 'ANALYZE'
  | 'PLAN'
  | 'GENERATE'
  | 'MUTATE'
  | 'BUILD'
  | 'MOUNT'
  | 'EXECUTE'
  | 'VERIFY'
  | 'REPAIR_IF_REQUIRED'
  | 'RE_VERIFY'
  | 'RELEASE'
  | 'FAILED_UNRESOLVED';

export type FailureClassification =
  | 'SYNTAX'
  | 'IMPORT'
  | 'IMPORT_MISSING'
  | 'TYPE_MISMATCH'
  | 'RUNTIME_EXCEPTION'
  | 'DOM_MOUNT_ERROR'
  | 'ENGINE_UNAVAILABLE'
  | 'TIMEOUT'
  | 'RESOURCE_EXCEEDED'
  | 'CONFLICT_LOCK_FAILED'
  | 'SECURITY_VIOLATION'
  | 'NONE';

export interface ApplicationSpec {
  appName: string;
  category: AppCategory;
  entryPoint: string;
  rootComponentPath: string;
  fileManifest: Record<string, string>;
  environmentVariables: Record<string, string>;
  packageDependencies: string[];
  requiredEngines: string[];
  metadata: {
    createdAt: number;
    description: string;
    version: string;
  };
}

export interface ExecutionPlanStage {
  stage: ApplicationLifecycleState;
  order: number;
  description: string;
  estimatedDurationMs: number;
  requiredResources: {
    memoryMb: number;
    requiresGpu: boolean;
  };
}

export interface ExecutionPlan {
  planId: string;
  appName: string;
  stages: ExecutionPlanStage[];
  timeoutMs: number;
  maxRetries: number;
  isolationLevel: 'SANDBOX' | 'PROCESS' | 'THREAD';
  requiredEngines: string[];
  createdAt: number;
}

export interface RuntimeEnvironmentDiscovery {
  timestamp: number;
  browserContext: boolean;
  domAvailable: boolean;
  canvas2dAvailable: boolean;
  webglAvailable: boolean;
  webAudioAvailable: boolean;
  localStorageAvailable: boolean;
  indexedDbAvailable: boolean;
  viteAvailable: boolean;
  typescriptAvailable: boolean;
  activeLocalEngines: string[];
  configuredRemoteEngines: string[];
  availableMemoryMb: number;
  maxConcurrentJobs: number;
}

export interface RuntimeDiagnosticEntry {
  type: 'INFO' | 'WARNING' | 'ERROR' | 'PERFORMANCE' | 'TELEMETRY';
  category: 'IMPORT' | 'SYNTAX' | 'STATE' | 'RENDER' | 'EVENT' | 'SECURITY' | 'ENGINE';
  message: string;
  filePath?: string;
  lineNumber?: number;
  stack?: string;
  timestamp: number;
}

export interface ExecutionJob {
  id: string;
  applicationSpec: ApplicationSpec;
  plan: ExecutionPlan;
  currentState: ApplicationLifecycleState;
  startedAt: number;
  timeoutAt: number;
  cancellationToken: { isCancelled: () => boolean };
  diagnostics: RuntimeDiagnosticEntry[];
  stateTransitions: Array<{ state: ApplicationLifecycleState; timestamp: number; note?: string }>;
}

export interface ExecutionResult {
  jobId: string;
  appName: string;
  status: 'SUCCESS' | 'FAILED' | 'REPAIRED' | 'REQUIRES_ENGINE' | 'CANCELLED' | 'TIMEOUT';
  exitCode: number;
  stdout: string[];
  stderr: string[];
  durationMs: number;
  generatedFiles: Record<string, string>;
  runtimeDiagnostics: RuntimeDiagnosticEntry[];
  failureClassification: FailureClassification;
  lifecycleHistory: Array<{ state: ApplicationLifecycleState; timestamp: number; note?: string }>;
  evidenceLog: string[];
}

export interface ExecutionVerificationReport {
  overallPassed: boolean;
  verificationScore: number;
  pillars: {
    codeStructure: boolean;
    typeSafety: boolean;
    componentMount: boolean;
    stateInitialization: boolean;
    eventHandling: boolean;
    dataFlow: boolean;
    securityIntegrity: boolean;
  };
  simulatedInteractionsCount: number;
  interactionPassRate: number;
  epistemicTruthfulnessVerified: boolean;
  evidenceLog: string[];
  repairedOnRun: boolean;
  repairAttempts: number;
}

// ==========================================
// GODEX P3.1 REAL-WORLD EXECUTION & PROOF TYPES
// ==========================================

export interface ProjectBaseline {
  timestamp: number;
  fingerprint: string;
  totalFiles: number;
  files: string[];
  entryPoints: {
    mainTsx?: string;
    indexHtml?: string;
    rootComponent?: string;
    serverEntry?: string;
  };
  detectedCommands: {
    buildCmd: string;
    testCmd: string;
    lintCmd: string;
    devCmd: string;
  };
  dependencies: Record<string, string>;
  devDependencies: Record<string, string>;
  existingTests: string[];
  baselineCheckpointId: string;
  astValidFileCount: number;
  initialDiagnosticCount: number;
}

export type RequirementCategory =
  | 'FUNCTIONAL'
  | 'UI'
  | 'STATE'
  | 'DATA'
  | 'RUNTIME'
  | 'SECURITY'
  | 'PERFORMANCE'
  | 'VERIFICATION';

export interface RequirementContractItem {
  id: string;
  category: RequirementCategory;
  title: string;
  specification: string;
  verificationCriteria: string;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  targetComponents: string[];
  mappedTaskIds: string[];
  satisfied: boolean;
  evidence?: string;
}

export interface RequirementContract {
  contractId: string;
  objective: string;
  createdAt: number;
  items: RequirementContractItem[];
  totalRequirements: number;
  satisfiedCount: number;
  coveragePercent: number;
  immutable: boolean;
}

export interface ArchitectureComponentSpec {
  name: string;
  path: string;
  layer: 'UI' | 'STATE' | 'SERVICE' | 'DATA' | 'UTIL' | 'ENGINE';
  publicInterfaces: Array<{
    name: string;
    signature: string;
    description: string;
  }>;
  dependencies: string[];
  dependents: string[];
}

export interface ArchitectureContract {
  contractId: string;
  title: string;
  targetStack: {
    framework: string;
    language: string;
    styling: string;
    runtime: string;
    stateManager: string;
  };
  components: ArchitectureComponentSpec[];
  dataFlowDiagram: Array<{
    source: string;
    destination: string;
    payloadType: string;
    syncType: 'SYNC' | 'ASYNC' | 'EVENT';
  }>;
  invariants: string[];
  verified: boolean;
}

export interface ExecutionEvidence {
  evidenceId: string;
  operation: string;
  taskId?: string;
  command?: string;
  files: string[];
  startTime: number;
  endTime: number;
  durationMs: number;
  exitCode: number;
  stdout: string[];
  stderr: string[];
  diagnostics: RuntimeDiagnosticEntry[];
  artifacts: string[];
  verificationStatus: 'PASSED' | 'FAILED' | 'REPAIRED' | 'WARNED' | 'BLOCKED';
  proofDetails: string;
}

export type EngineCapabilityStatus =
  | 'BROWSER_NATIVE'
  | 'AVAILABLE_LOCALLY'
  | 'CONNECTED_ENGINE'
  | 'REQUIRES_ENGINE'
  | 'REQUIRES_CONFIGURATION'
  | 'UNAVAILABLE'
  | 'FAILED'
  | 'NOT_VERIFIED';

export interface EngineCapabilityProof {
  capabilityId: string;
  name: string;
  category: 'AUDIO' | 'IMAGE' | 'VIDEO' | 'PHYSICS' | 'CODE' | 'DATA' | 'AI';
  status: EngineCapabilityStatus;
  isUsable: boolean;
  healthCheckPassed: boolean;
  endpointOrNativeFeature: string;
  notes: string;
  latencyMs: number;
}

export interface ReleaseProof {
  releaseId: string;
  missionId: string;
  generatedAt: number;
  state: 'READY' | 'BLOCKED';
  requirementCoverage: {
    total: number;
    satisfied: number;
    percentage: number;
    unsatisfiedRequirements: string[];
  };
  architectureStatus: {
    contractVerified: boolean;
    violatedInvariants: string[];
  };
  modifiedFiles: string[];
  typecheckResult: {
    passed: boolean;
    errorsCount: number;
    details: string[];
  };
  testResult: {
    passed: boolean;
    total: number;
    passedCount: number;
    failedCount: number;
    durationMs: number;
  };
  buildResult: {
    passed: boolean;
    exitCode: number;
    outputSummary: string;
  };
  runtimeResult: {
    mountedSuccessfully: boolean;
    domNodesCount: number;
    errorsCaptured: number;
  };
  securityResult: {
    passed: boolean;
    secretsLeaked: number;
    injectionsFound: number;
    violations: string[];
  };
  regressionResult: {
    passed: boolean;
    regressionsFound: number;
    affectedSuitesCount: number;
  };
  unresolvedUnknownItems: string[];
  releaseBlockers: string[];
  auditHash: string;
}

export interface MutationPatch {
  filePath: string;
  newContent: string;
  operation: 'CREATE' | 'UPDATE' | 'DELETE' | 'MODIFY';
}

export type ProofMissionCategory =
  | 'SAAS_DASHBOARD'
  | 'CRUD_DATA_APP'
  | 'DEV_TOOL'
  | 'PRODUCTIVITY_APP'
  | 'INTERACTIVE_APP'
  | 'CREATIVE_MEDIA_APP';

export interface RealProjectMission {
  id: string;
  objective: string;
  category: ProofMissionCategory;
  status: 'INITIALIZING' | 'PLANNING' | 'EXECUTING' | 'TESTING' | 'REPAIRING' | 'VERIFYING' | 'COMPLETED' | 'BLOCKED' | 'FAILED' | 'CANCELLED';
  baseline: ProjectBaseline;
  requirements: RequirementContract;
  architecture: ArchitectureContract;
  taskDAG: any;
  impactAssessment: any;
  transactions: any[];
  executionEvidences: ExecutionEvidence[];
  engineCapabilities: EngineCapabilityProof[];
  testResults?: any;
  regressionResults?: {
    originalTestPassed: boolean;
    affectedPassRate: number;
    dependentPassRate: number;
    fullSuitePassRate: number;
  };
  releaseProof?: ReleaseProof;
  currentStepDescription: string;
  retryAttempts: number;
  maxRetryBudget: number;
  startTime: number;
  endTime?: number;
  isCancelled: boolean;
}




