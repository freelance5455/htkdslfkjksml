/**
 * GODEX P3.0 — Safe Multi-File Mutation Engine
 * Enforces atomic ConflictManager acquisition, pre-change checkpoints,
 * AST syntax validation, and instant transactional rollbacks.
 */

import { ConflictManager } from '../orchestration/conflictManager';
import { AstParser } from '../intelligence/astParser';

export interface FileMutationPatch {
  filePath: string;
  newContent: string;
  operation: 'CREATE' | 'UPDATE' | 'DELETE' | 'MODIFY';
}

export type MutationPatch = FileMutationPatch;

export interface MutationTransaction {
  transactionId: string;
  taskId: string;
  agentId: string;
  patches: FileMutationPatch[];
  preMutationFiles: Record<string, string>;
  acquiredLocks: string[];
  status: 'PENDING' | 'COMMITTED' | 'ROLLED_BACK' | 'FAILED';
  error?: string;
  timestamp: number;
}

export class SafeMultiFileMutator {
  private static transactionHistory: MutationTransaction[] = [];

  public static async executeTransaction(
    taskId: string,
    agentId: string,
    patches: FileMutationPatch[],
    currentWorkspace: Record<string, string>
  ): Promise<{
    success: boolean;
    mutatedWorkspace: Record<string, string>;
    transaction: MutationTransaction;
    error?: string;
  }> {
    const transactionId = `tx-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const conflictManager = ConflictManager.getInstance();
    const acquiredLocks: string[] = [];
    const preMutationFiles: Record<string, string> = {};

    // 1. Snapshot affected files for atomic rollback
    for (const patch of patches) {
      preMutationFiles[patch.filePath] = currentWorkspace[patch.filePath] || '';
    }

    // 2. Atomically acquire all locks via ConflictManager
    for (const patch of patches) {
      const fingerprint = computeSimpleFingerprint(preMutationFiles[patch.filePath]);
      const lockRes = conflictManager.acquireLock(
        patch.filePath,
        'FILE',
        taskId,
        agentId,
        'CODER',
        fingerprint
      );

      if (!lockRes.success) {
        // Rollback all previously acquired locks in this transaction
        for (const lockedPath of acquiredLocks) {
          conflictManager.releaseLock(lockedPath, taskId);
        }

        const tx: MutationTransaction = {
          transactionId,
          taskId,
          agentId,
          patches,
          preMutationFiles,
          acquiredLocks: [],
          status: 'FAILED',
          error: `Resource lock conflict on ${patch.filePath}: ${lockRes.conflict?.description}`,
          timestamp: Date.now()
        };
        this.transactionHistory.push(tx);

        return {
          success: false,
          mutatedWorkspace: currentWorkspace,
          transaction: tx,
          error: tx.error
        };
      }
      acquiredLocks.push(patch.filePath);
    }

    // 3. Draft mutated workspace in isolated copy
    const candidateWorkspace = { ...currentWorkspace };
    for (const patch of patches) {
      if (patch.operation === 'DELETE') {
        delete candidateWorkspace[patch.filePath];
      } else {
        candidateWorkspace[patch.filePath] = patch.newContent;
      }
    }

    // 4. Validate syntax and AST integrity on all mutated files
    for (const patch of patches) {
      if (patch.operation !== 'DELETE' && (patch.filePath.endsWith('.tsx') || patch.filePath.endsWith('.ts'))) {
        const syntaxErrors = AstParser.validateSyntax(patch.newContent, patch.filePath);
        if (syntaxErrors.length > 0) {
          // Syntax violation: Trigger immediate atomic rollback
          for (const lockedPath of acquiredLocks) {
            conflictManager.releaseLock(lockedPath, taskId);
          }

          const tx: MutationTransaction = {
            transactionId,
            taskId,
            agentId,
            patches,
            preMutationFiles,
            acquiredLocks,
            status: 'ROLLED_BACK',
            error: `Syntax validation failed on ${patch.filePath}: ${syntaxErrors.map(e => e.message).join(', ')}`,
            timestamp: Date.now()
          };
          this.transactionHistory.push(tx);

          return {
            success: false,
            mutatedWorkspace: currentWorkspace,
            transaction: tx,
            error: tx.error
          };
        }
      }
    }

    // 5. Commit mutations and release locks
    for (const lockedPath of acquiredLocks) {
      conflictManager.releaseLock(lockedPath, taskId);
    }

    const successfulTx: MutationTransaction = {
      transactionId,
      taskId,
      agentId,
      patches,
      preMutationFiles,
      acquiredLocks,
      status: 'COMMITTED',
      timestamp: Date.now()
    };
    this.transactionHistory.push(successfulTx);

    return {
      success: true,
      mutatedWorkspace: candidateWorkspace,
      transaction: successfulTx
    };
  }

  public static rollbackTransaction(
    transaction: MutationTransaction,
    currentWorkspace: Record<string, string>
  ): Record<string, string> {
    const rolledBackWorkspace = { ...currentWorkspace };
    for (const [filePath, originalContent] of Object.entries(transaction.preMutationFiles)) {
      if (!originalContent) {
        delete rolledBackWorkspace[filePath];
      } else {
        rolledBackWorkspace[filePath] = originalContent;
      }
    }
    transaction.status = 'ROLLED_BACK';
    return rolledBackWorkspace;
  }

  public static getHistory(): MutationTransaction[] {
    return [...this.transactionHistory];
  }

  public static planRepairDag(
    diagnosis: {
      classification: string;
      rootCause: string;
      suggestedFix: string;
      affectedNodeId?: string;
      confidenceScore: number;
    },
    workspace: Record<string, string>
  ): {
    strategy: string;
    rollbackStrategy: string;
    repairSteps: Array<{
      targetFile: string;
      action: 'PATCH_SYNTAX' | 'ADD_IMPORT' | 'INJECT_TYPE';
      description: string;
    }>;
  } {
    const repairSteps: Array<{
      targetFile: string;
      action: 'PATCH_SYNTAX' | 'ADD_IMPORT' | 'INJECT_TYPE';
      description: string;
    }> = [];

    if (diagnosis.classification === 'SYNTAX') {
      repairSteps.push({
        targetFile: 'src/App.tsx',
        action: 'PATCH_SYNTAX',
        description: 'Auto-close unterminated JSX tag or statement bracket.'
      });
    } else if (diagnosis.classification === 'IMPORT') {
      repairSteps.push({
        targetFile: 'src/App.tsx',
        action: 'ADD_IMPORT',
        description: 'Add missing import definition.'
      });
    } else {
      repairSteps.push({
        targetFile: 'src/types.ts',
        action: 'INJECT_TYPE',
        description: 'Define missing interface type.'
      });
    }

    return {
      strategy: `MINIMAL_SURGICAL_REPAIR_${diagnosis.classification}`,
      rollbackStrategy: 'ATOMIC_CHECKPOINT_RESTORE',
      repairSteps
    };
  }
}

function computeSimpleFingerprint(content: string): string {
  let hash = 0;
  for (let i = 0; i < content.length; i++) {
    const char = content.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(16).padStart(8, '0');
}
