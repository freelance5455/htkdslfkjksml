/**
 * GODEX P5.1 — Real Generation Bring-Up & End-to-End Proof Test Suite
 * 
 * Tests the complete epistemic truth, zero-fabrication diagnostics,
 * engine reachability probing, hardware profiling, container signature validation,
 * and execution proof layer across all execution modes.
 */

import { ProductionProjectFactory } from './creative/production/productionProjectFactory';
import { ProductionExecutionController } from './creative/production/productionExecutionController';
import { ProductionProofEngine } from './creative/production/productionProofEngine';
import { ProductionPreflightEngine } from './creative/production/productionPreflightEngine';
import { ProductionQualityGate } from './creative/production/productionQualityGate';
import { ProductionRecoveryEngine } from './creative/production/productionRecoveryEngine';
import {
  ProductionProject,
  ProductionExecutionProof,
  EpistemicTruthClassification
} from './creative/production/productionTypes';

export interface P51TestResult {
  id: string;
  name: string;
  passed: boolean;
  durationMs: number;
  details?: string;
  error?: string;
}

export interface P51TestSuiteReport {
  totalTests: number;
  passedTests: number;
  failedTests: number;
  results: P51TestResult[];
}

export class UniversalAppBuilderP51Test {
  public static async runAllTests(): Promise<P51TestSuiteReport> {
    const results: P51TestResult[] = [];
    const runTest = async (id: string, name: string, fn: () => Promise<void> | void) => {
      const start = Date.now();
      try {
        await fn();
        results.push({
          id,
          name,
          passed: true,
          durationMs: Date.now() - start
        });
      } catch (err: any) {
        results.push({
          id,
          name,
          passed: false,
          durationMs: Date.now() - start,
          error: err.message || String(err)
        });
      }
    };

    const proofEngine = ProductionProofEngine.getInstance();
    const execController = ProductionExecutionController.getInstance();
    const preflightEngine = ProductionPreflightEngine.getInstance();
    const qualityGate = ProductionQualityGate.getInstance();
    const recoveryEngine = ProductionRecoveryEngine.getInstance();

    // Test 1: Proof Engine Singleton
    await runTest('P51-01', 'Proof Engine Singleton Initialization', () => {
      if (!proofEngine) throw new Error('Proof engine instance is null');
      const inst2 = ProductionProofEngine.getInstance();
      if (proofEngine !== inst2) throw new Error('Singleton instance mismatch');
    });

    // Test 2: Hardware Capability Profiling
    await runTest('P51-02', 'Hardware Capability Profiler Execution', () => {
      const profile = proofEngine.getHardwareProfile();
      if (!profile) throw new Error('Hardware profile missing');
      if (typeof profile.cpuCores !== 'number' || profile.cpuCores <= 0) {
        throw new Error(`Invalid CPU cores: ${profile.cpuCores}`);
      }
      if (profile.maxTextureSize < 2048) {
        throw new Error(`Max texture size unreasonably low: ${profile.maxTextureSize}`);
      }
      if (typeof profile.mobileSafe !== 'boolean') {
        throw new Error('mobileSafe flag must be boolean');
      }
    });

    // Test 3: Browser-Native Engine Reachability
    await runTest('P51-03', 'Browser-Native Engine Reachability Probe', async () => {
      const status = await proofEngine.probeEngineReachability('engine-browser-native');
      if (status !== 'REACHABLE') {
        throw new Error(`Browser native engine should always be REACHABLE, got ${status}`);
      }
    });

    // Test 4: Offline ComfyUI Engine Probe (Truthful Handling)
    await runTest('P51-04', 'ComfyUI Engine Reachability Probe Handling', async () => {
      const status = await proofEngine.probeEngineReachability('engine-comfyui-local');
      if (status !== 'UNREACHABLE' && status !== 'NOT_CONFIGURED' && status !== 'REACHABLE') {
        throw new Error(`Unexpected reachability status: ${status}`);
      }
    });

    // Test 5: WebM EBML Binary Container Magic Validation
    await runTest('P51-05', 'WebM EBML Header Signature Validation', () => {
      const validWebM = new Uint8Array([0x1A, 0x45, 0xDF, 0xA3, 0x01, 0x00, 0x00, 0x00]);
      const valid = proofEngine.validateContainerSignature(validWebM, 'video/webm');
      if (!valid) throw new Error('Valid EBML header failed validation');

      const invalidWebM = new Uint8Array([0x00, 0x00, 0x00, 0x00]);
      const invalidResult = proofEngine.validateContainerSignature(invalidWebM, 'video/webm');
      if (invalidResult) throw new Error('Invalid EBML header falsely passed validation');
    });

    // Test 6: MP4 Box Header Signature Validation
    await runTest('P51-06', 'MP4 Box Header Signature Validation', () => {
      // 0x00, 0x00, 0x00, 0x20, 'f', 't', 'y', 'p', 'i', 's', 'o', 'm'
      const validMp4 = new Uint8Array([
        0x00, 0x00, 0x00, 0x20,
        0x66, 0x74, 0x79, 0x70,
        0x69, 0x73, 0x6F, 0x6D
      ]);
      const valid = proofEngine.validateContainerSignature(validMp4, 'video/mp4');
      if (!valid) throw new Error('Valid MP4 ftyp header failed validation');
    });

    // Test 7: Epistemic Truth Classification for Local Deterministic
    await runTest('P51-07', 'Epistemic Classification: Local Deterministic', () => {
      const classification = proofEngine.classifyGenerationOutcome(
        'engine-browser-native',
        'REACHABLE',
        1024,
        true,
        'LOCAL_DETERMINISTIC_COMPLETED'
      );
      if (classification !== 'LOCAL_DETERMINISTIC') {
        throw new Error(`Expected LOCAL_DETERMINISTIC, got ${classification}`);
      }
    });

    // Test 8: Epistemic Truth Classification for Unreachable Engine
    await runTest('P51-08', 'Epistemic Classification: Unreachable Real Engine', () => {
      const classification = proofEngine.classifyGenerationOutcome(
        'engine-comfyui-local',
        'UNREACHABLE',
        0,
        false,
        'REQUIRES_ENGINE'
      );
      if (classification !== 'REQUIRES_ENGINE') {
        throw new Error(`Expected REQUIRES_ENGINE, got ${classification}`);
      }
    });

    // Test 9: Epistemic Truth Classification for Real Neural Generation
    await runTest('P51-09', 'Epistemic Classification: Real Neural Completed', () => {
      const classification = proofEngine.classifyGenerationOutcome(
        'engine-comfyui-local',
        'REACHABLE',
        50000,
        true,
        'REAL_NEURAL_COMPLETED'
      );
      if (classification !== 'REAL_NEURAL_GENERATED') {
        throw new Error(`Expected REAL_NEURAL_GENERATED, got ${classification}`);
      }
    });

    // Test 10: Anti-Fabrication Integrity Check Fails on Fake Neural Claim
    await runTest('P51-10', 'Anti-Fabrication Check: Rejects Fake Neural Claim', () => {
      const isIntegrityPassed = proofEngine.verifyProofIntegrity({
        epistemicTruthClassification: 'REAL_NEURAL_GENERATED',
        actualEngineReachability: 'UNREACHABLE',
        outputSizeBytes: 1000,
        containerSignatureValid: true,
        qualityGateScore: 95
      });
      if (isIntegrityPassed) {
        throw new Error('Integrity check falsely passed on unreachable neural claim (Fabrication violation)');
      }
    });

    // Test 11: Anti-Fabrication Integrity Check Fails on 0 Output Bytes
    await runTest('P51-11', 'Anti-Fabrication Check: Rejects Zero Bytes on Generated Claim', () => {
      const isIntegrityPassed = proofEngine.verifyProofIntegrity({
        epistemicTruthClassification: 'REAL_NEURAL_GENERATED',
        actualEngineReachability: 'REACHABLE',
        outputSizeBytes: 0,
        containerSignatureValid: false,
        qualityGateScore: 90
      });
      if (isIntegrityPassed) {
        throw new Error('Integrity check falsely passed with 0 output bytes');
      }
    });

    // Test 12: Anti-Fabrication Integrity Passes on Valid Local Output
    await runTest('P51-12', 'Anti-Fabrication Check: Validates Local Deterministic Truthfully', () => {
      const isIntegrityPassed = proofEngine.verifyProofIntegrity({
        epistemicTruthClassification: 'LOCAL_DETERMINISTIC',
        actualEngineReachability: 'REACHABLE',
        outputSizeBytes: 4096,
        containerSignatureValid: true,
        qualityGateScore: 92
      });
      if (!isIntegrityPassed) {
        throw new Error('Valid local deterministic output failed integrity audit');
      }
    });

    // Test 13: End-to-End Pipeline in LOCAL_DETERMINISTIC Mode
    await runTest('P51-13', 'E2E Execution: Browser-Native Deterministic Test Path', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const result = await execController.executeProductionPipeline(project, {
        executionMode: 'LOCAL_DETERMINISTIC',
        skipPreflight: false
      });

      if (!result.success) {
        throw new Error(`Execution failed: ${result.error}`);
      }
      if (result.statusCode !== 'LOCAL_DETERMINISTIC_COMPLETED') {
        throw new Error(`Expected LOCAL_DETERMINISTIC_COMPLETED, got ${result.statusCode}`);
      }
      if (!result.proof) {
        throw new Error('Execution result missing proof object');
      }
      if (result.proof.epistemicTruthClassification !== 'LOCAL_DETERMINISTIC') {
        throw new Error(`Expected proof classification LOCAL_DETERMINISTIC, got ${result.proof.epistemicTruthClassification}`);
      }
      if (!result.proof.containerSignatureValid) {
        throw new Error('Proof container signature must be valid');
      }
      if (!result.proof.integrityVerified) {
        throw new Error('Proof integrity verification failed');
      }
    });

    // Test 14: End-to-End Pipeline in REAL_NEURAL Mode against Unreachable Engine
    await runTest('P51-14', 'E2E Execution: Truthful REQUIRES_ENGINE on Offline ComfyUI', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const result = await execController.executeProductionPipeline(project, {
        executionMode: 'REAL_NEURAL',
        targetEngineId: 'engine-comfyui-local',
        selectedModelId: 'flux-1-dev'
      });

      // If ComfyUI is offline in environment, it must truthfully return REQUIRES_ENGINE
      const reachability = await proofEngine.probeEngineReachability('engine-comfyui-local');
      if (reachability !== 'REACHABLE') {
        if (result.success) {
          throw new Error('Real neural execution should NOT succeed when engine is unreachable');
        }
        if (result.statusCode !== 'REQUIRES_ENGINE') {
          throw new Error(`Expected statusCode REQUIRES_ENGINE, got ${result.statusCode}`);
        }
        if (result.proof.outputSizeBytes !== 0) {
          throw new Error(`Output size must be 0 when engine is unreachable, got ${result.proof.outputSizeBytes}`);
        }
        if (!result.proof.diagnostics?.connectionGuidance) {
          throw new Error('Proof must contain connection guidance diagnostics');
        }
      }
    });

    // Test 15: Proof Subscription Dispatch
    await runTest('P51-15', 'Production Proof Subscription & Emission', async () => {
      let receivedProof: ProductionExecutionProof | null = null;
      const unsub = execController.subscribeProof((p) => {
        receivedProof = p;
      });

      const project = ProductionProjectFactory.createCinematicProject();
      await execController.executeProductionPipeline(project, {
        executionMode: 'LOCAL_DETERMINISTIC'
      });

      unsub();
      if (!receivedProof) {
        throw new Error('Subscriber did not receive execution proof');
      }
      if (receivedProof.proofId.length === 0) {
        throw new Error('Received empty proof ID');
      }
    });

    // Test 16: Project & Timeline Hash Inclusion in Proof
    await runTest('P51-16', 'Proof Deterministic Cryptographic Hashes', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const result = await execController.executeProductionPipeline(project, {
        executionMode: 'LOCAL_DETERMINISTIC'
      });

      const expectedProjectHash = recoveryEngine.computeProjectHash(project);
      if (result.proof.projectHash !== expectedProjectHash) {
        throw new Error(`Project hash mismatch in proof: ${result.proof.projectHash} vs ${expectedProjectHash}`);
      }
      if (!result.proof.timelineHash || result.proof.timelineHash.length === 0) {
        throw new Error('Timeline hash missing from proof');
      }
    });

    // Test 17: Measured A/V Sync Drift Bounds in Proof
    await runTest('P51-17', 'Measured A/V Sync Drift Bounds in Proof', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const result = await execController.executeProductionPipeline(project, {
        executionMode: 'LOCAL_DETERMINISTIC'
      });

      if (typeof result.proof.measuredAvSyncDriftMs !== 'number') {
        throw new Error('measuredAvSyncDriftMs must be a number');
      }
      if (result.proof.measuredAvSyncDriftMs > 45) {
        throw new Error(`A/V sync drift exceeded broadcast standard: ${result.proof.measuredAvSyncDriftMs}ms > 45ms`);
      }
    });

    // Test 18: Quality Gate Integration in Proof
    await runTest('P51-18', 'Quality Gate 15-Axis Evaluation in Proof', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const result = await execController.executeProductionPipeline(project, {
        executionMode: 'LOCAL_DETERMINISTIC'
      });

      if (result.proof.qualityGateScore < 80) {
        throw new Error(`Quality gate score below passing threshold: ${result.proof.qualityGateScore}`);
      }
      if (result.proof.qualityVerdict !== 'PASS' && result.proof.qualityVerdict !== 'PASS_WITH_WARNINGS') {
        throw new Error(`Unexpected quality verdict: ${result.proof.qualityVerdict}`);
      }
    });

    // Test 19: Preflight Failure Blocks Proof Generation Safely
    await runTest('P51-19', 'Preflight Failure Proof Generation', async () => {
      const badProject: ProductionProject = {
        ...ProductionProjectFactory.createCinematicProject(),
        scenes: [] // Empty scenes triggers preflight failure
      };

      const result = await execController.executeProductionPipeline(badProject, {
        executionMode: 'LOCAL_DETERMINISTIC',
        skipPreflight: false
      });

      if (result.success) {
        throw new Error('Pipeline should fail when preflight fails');
      }
      if (result.statusCode !== 'PREFLIGHT_FAILED') {
        throw new Error(`Expected PREFLIGHT_FAILED, got ${result.statusCode}`);
      }
      if (result.proof.epistemicTruthClassification !== 'PREFLIGHT_FAILED') {
        throw new Error(`Expected proof classification PREFLIGHT_FAILED, got ${result.proof.epistemicTruthClassification}`);
      }
    });

    // Test 20: Memory Estimation & Mobile Safe Constraint
    await runTest('P51-20', 'Mobile Safe Memory Allocation Boundary', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const preflight = await preflightEngine.auditProject(project);

      if (preflight.resourceEstimate.ramMb > 256) {
        throw new Error(`RAM estimate exceeded mobile safe limit: ${preflight.resourceEstimate.ramMb} MB > 256 MB`);
      }
      if (!preflight.resourceEstimate.mobileSafe) {
        throw new Error('mobileSafe flag was false on standard 1080p cinematic project');
      }
    });

    // Test 21: Checkpoint Recovery Preservation with P5.1
    await runTest('P51-21', 'Checkpoint Generation & Hash Matching', () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const chk = recoveryEngine.saveCheckpoint(project, 'GENERATING');
      if (!chk.checkpointId || chk.checkpointId.length === 0) {
        throw new Error('Invalid checkpoint ID');
      }
      const restored = recoveryEngine.loadCheckpoint(chk.checkpointId);
      if (!restored) throw new Error('Failed to load saved checkpoint');
      if (restored.projectHash !== chk.projectHash) {
        throw new Error('Restored checkpoint hash mismatch');
      }
    });

    // Test 22: Execution Cancellation Handling
    await runTest('P51-22', 'Pipeline Cancellation Graceful Handling', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      // Start pipeline and immediately cancel
      const execPromise = execController.executeProductionPipeline(project, {
        executionMode: 'LOCAL_DETERMINISTIC'
      });
      execController.cancelExecution();

      const result = await execPromise;
      if (result.success) {
        // In fast local runs, it might complete or cancel cleanly; both are handled
      } else {
        if (result.statusCode !== 'CANCELLED' && result.statusCode !== 'FAILED') {
          throw new Error(`Unexpected status on cancellation: ${result.statusCode}`);
        }
      }
    });

    // Test 23: Audit Trail Provenance Tagging
    await runTest('P51-23', 'Audit Trail Provenance Accuracy', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const result = await execController.executeProductionPipeline(project, {
        executionMode: 'LOCAL_DETERMINISTIC'
      });

      const trail = result.project.evidence.auditTrail;
      if (!trail || trail.length === 0) {
        throw new Error('Audit trail is empty');
      }
      for (const entry of trail) {
        if (entry.provenance === 'REAL_ENGINE') {
          throw new Error('Audit trail claimed REAL_ENGINE in local deterministic mode (Fabrication violation)');
        }
      }
    });

    // Test 24: Proof Retrieval via Controller Getter
    await runTest('P51-24', 'Controller getLastExecutionProof Getter', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      await execController.executeProductionPipeline(project, {
        executionMode: 'LOCAL_DETERMINISTIC'
      });

      const lastProof = execController.getLastExecutionProof();
      if (!lastProof) {
        throw new Error('getLastExecutionProof returned null after execution');
      }
      if (lastProof.proofId.length === 0) {
        throw new Error('lastProof has empty proofId');
      }
    });

    // Test 25: 11-Discipline Preflight Full Verification
    await runTest('P51-25', '11-Discipline Preflight Completeness', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const preflight = await preflightEngine.auditProject(project);

      const requiredCategories = ['TIMELINE', 'ASSET', 'CAMERA', 'ENGINE', 'VFX', 'AUDIO', 'COLOR', 'CODEC'];
      for (const cat of requiredCategories) {
        const found = preflight.checks.some(c => c.category === cat);
        if (!found) throw new Error(`Preflight missing checks for required discipline: ${cat}`);
      }
    });

    const passedTests = results.filter(r => r.passed).length;
    const failedTests = results.filter(r => !r.passed).length;

    return {
      totalTests: results.length,
      passedTests,
      failedTests,
      results
    };
  }
}
