/**
 * GODEX P2.3 Test Suite — Universal Runtime, Execution & Verification Intelligence
 * 20 Deterministic Test Cases covering:
 * - Runtime Contract generation & structure
 * - Root mount detection & JSX validation
 * - Import resolution graph & broken package traps
 * - Hook rules & runtime exception safety
 * - 3-state Capability intelligence (AVAILABLE / REQUIRES_ENGINE / UNAVAILABLE)
 * - Failure diagnosis & MissionRecoveryEngine routing
 * - ConflictManager mutex lock protection during repairs
 * - Bounded self-repair loop with max 3 iterations
 * - Epistemic honesty & truthful telemetry
 * - Full end-to-end builder execution
 */

import { UniversalAppBuilder } from './universalAppBuilder';
import { UniversalRuntimeEngine } from './runtimeEngine';
import { RuntimeRepairEngine } from './runtimeRepairEngine';
import { CapabilityRegistry } from './capabilityRegistry';
import { RequirementEngine } from './requirementEngine';
import { ArchitecturePlanner } from './architecturePlanner';
import { TemplateSystem } from './templateSystem';
import { ConflictManager } from '../orchestration/conflictManager';
import { EngineeringMemoryEngine } from '../memory/engineeringMemory';
import { MissionRecoveryEngine } from '../mission/missionRecovery';
import { AstParser } from '../intelligence/astParser';
import { WorkspaceService } from '../services/workspaceService';

export interface P23TestCaseResult {
  id: string;
  name: string;
  category: string;
  passed: boolean;
  durationMs: number;
  evidence: string;
}

export interface P23TestSuiteReport {
  timestamp: number;
  totalTests: number;
  passedTests: number;
  failedTests: number;
  successRate: number;
  allPassed: boolean;
  results: P23TestCaseResult[];
  logs: string[];
}

export class UniversalAppBuilderP23TestSuite {
  public static async runAllTests(
    onProgress?: (current: number, total: number, testName: string) => void
  ): Promise<P23TestSuiteReport> {
    const results: P23TestCaseResult[] = [];
    const logs: string[] = [];
    const startTime = Date.now();

    const tests = [
      { id: 'P23-01', name: 'Contract Generation Integrity & Metadata', fn: this.test01_ContractGeneration },
      { id: 'P23-02', name: 'Entry-Point Detection & Root Export Signatures', fn: this.test02_EntryPointDetection },
      { id: 'P23-03', name: 'Mount Structure & JSX Tree Validation', fn: this.test03_MountStructureValidation },
      { id: 'P23-04', name: 'Import Resolution & Relative Path Trapping', fn: this.test04_ImportResolutionTrapping },
      { id: 'P23-05', name: 'External Package Import Verification', fn: this.test05_ExternalPackageVerification },
      { id: 'P23-06', name: 'React Hook Rules & Conditional Hook Trapping', fn: this.test06_HookRuleTrapping },
      { id: 'P23-07', name: 'Capability AVAILABLE Classification', fn: this.test07_CapabilityAvailable },
      { id: 'P23-08', name: 'Capability REQUIRES_ENGINE Classification', fn: this.test08_CapabilityRequiresEngine },
      { id: 'P23-09', name: 'Capability UNAVAILABLE Boundary Enforcement', fn: this.test09_CapabilityUnavailable },
      { id: 'P23-10', name: 'Failure Diagnosis & Category Classification', fn: this.test10_FailureDiagnosisClassification },
      { id: 'P23-11', name: 'MissionRecoveryEngine Advisory Strategy Routing', fn: this.test11_MissionRecoveryRouting },
      { id: 'P23-12', name: 'Deterministic Patch Planning for Corrupted Files', fn: this.test12_DeterministicPatchPlanning },
      { id: 'P23-13', name: 'ConflictManager Mutex Protection in Repair', fn: this.test13_ConflictManagerMutexProtection },
      { id: 'P23-14', name: 'Bounded Repair Loop Termination (Max 3 Passes)', fn: this.test14_BoundedRepairLoopTermination },
      { id: 'P23-15', name: 'Post-Repair Successful Re-Verification Cycle', fn: this.test15_PostRepairReVerification },
      { id: 'P23-16', name: 'Truthful Telemetry Startup & Mount Capture', fn: this.test16_TruthfulTelemetryCapture },
      { id: 'P23-17', name: 'Epistemic Honesty (No Fabricated Flags)', fn: this.test17_EpistemicHonestyVerification },
      { id: 'P23-18', name: 'Creative Studio Timeline & Asset Contract', fn: this.test18_CreativeStudioContract },
      { id: 'P23-19', name: 'Engineering Memory Repair Event Persistence', fn: this.test19_EngineeringMemoryPersistence },
      { id: 'P23-20', name: 'End-to-End Build, Mount & Verification Pipeline', fn: this.test20_EndToEndPipeline }
    ];

    for (let i = 0; i < tests.length; i++) {
      const t = tests[i];
      if (onProgress) {
        onProgress(i + 1, tests.length, t.name);
      }
      const tStart = Date.now();
      try {
        const result = await t.fn();
        const durationMs = Date.now() - tStart;
        results.push({
          id: t.id,
          name: t.name,
          category: 'Runtime Intelligence',
          passed: result.passed,
          durationMs,
          evidence: result.evidence
        });
        logs.push(`[${result.passed ? 'PASS' : 'FAIL'}] ${t.id}: ${t.name} (${durationMs}ms) - ${result.evidence}`);
      } catch (err: any) {
        const durationMs = Date.now() - tStart;
        results.push({
          id: t.id,
          name: t.name,
          category: 'Runtime Intelligence',
          passed: false,
          durationMs,
          evidence: `Unhandled Exception: ${err.message}`
        });
        logs.push(`[FAIL] ${t.id}: ${t.name} (${durationMs}ms) - Unhandled Exception: ${err.message}`);
      }
    }

    const passedTests = results.filter(r => r.passed).length;
    const totalTests = results.length;
    const failedTests = totalTests - passedTests;
    const successRate = totalTests > 0 ? (passedTests / totalTests) * 100 : 0;
    const allPassed = failedTests === 0;

    return {
      timestamp: Date.now(),
      totalTests,
      passedTests,
      failedTests,
      successRate,
      allPassed,
      results,
      logs
    };
  }

  // 1. Contract Generation Integrity
  private static async test01_ContractGeneration(): Promise<{ passed: boolean; evidence: string }> {
    const req = RequirementEngine.analyze('Build a real-time team task management board with filter tags and status columns');
    const arch = ArchitecturePlanner.plan(req);
    const files = TemplateSystem.generateTemplateFiles(req, arch);
    const contract = UniversalRuntimeEngine.generateContract(req, arch, files);

    const valid = 
      Boolean(contract.entryPoint) &&
      contract.routes !== undefined && contract.routes.length > 0 &&
      contract.assets !== undefined && contract.assets.length > 0 &&
      contract.capabilities !== undefined &&
      contract.runtimeRequirements !== undefined &&
      Object.keys(contract.generatedFileManifest).length === Object.keys(files).length;

    return {
      passed: valid,
      evidence: `Contract generated with ${contract.routes?.length} routes, ${contract.assets?.length} assets, and ${Object.keys(contract.generatedFileManifest).length} files manifest.`
    };
  }

  // 2. Entry-Point Detection
  private static async test02_EntryPointDetection(): Promise<{ passed: boolean; evidence: string }> {
    const validFiles: Record<string, string> = {
      'src/apps/test/App.tsx': `import React from 'react'; export function App() { return <div>App Root</div>; } export default App;`
    };
    const validRes = await UniversalRuntimeEngine.validateRuntime(validFiles, 'src/apps/test/App.tsx');

    const invalidFiles: Record<string, string> = {
      'src/apps/test/App.tsx': `import React from 'react'; const internalVar = 42;`
    };
    const invalidRes = await UniversalRuntimeEngine.validateRuntime(invalidFiles, 'src/apps/test/App.tsx');

    const passed = validRes.success && !invalidRes.success && invalidRes.caughtErrors.some(e => e.message.includes('export'));
    return {
      passed,
      evidence: `Correctly passed valid export (${validRes.success}) and caught missing export in invalid entry (${invalidRes.caughtErrors[0]?.message}).`
    };
  }

  // 3. Mount Structure Validation
  private static async test03_MountStructureValidation(): Promise<{ passed: boolean; evidence: string }> {
    const req = RequirementEngine.analyze('Build an analytics dashboard with charts and table metrics');
    const arch = ArchitecturePlanner.plan(req);
    const files = TemplateSystem.generateTemplateFiles(req, arch);

    const runtimeRes = await UniversalRuntimeEngine.validateRuntime(files, arch.rootComponentPath, arch, req);
    const passed = runtimeRes.mountedSuccessfully && runtimeRes.telemetry?.mountStatus === 'MOUNTED_CLEAN';

    return {
      passed,
      evidence: `Mount validation status: ${runtimeRes.telemetry?.mountStatus} across ${arch.pages.length} pages.`
    };
  }

  // 4. Import Resolution & Relative Path Trapping
  private static async test04_ImportResolutionTrapping(): Promise<{ passed: boolean; evidence: string }> {
    const brokenFiles: Record<string, string> = {
      'src/apps/test/App.tsx': `import React from 'react';\nimport { NonExistentService } from './services/nonExistent';\nexport default function App() { return <div>Test</div>; }`
    };

    const res = await UniversalRuntimeEngine.validateRuntime(brokenFiles, 'src/apps/test/App.tsx');
    const importErr = res.caughtErrors.find(e => e.type === 'IMPORT');
    const passed = !res.success && Boolean(importErr) && res.telemetry?.dependencyImportFailures.length! > 0;

    return {
      passed,
      evidence: `Correctly trapped unresolved relative import: "${importErr?.message}".`
    };
  }

  // 5. External Package Import Verification
  private static async test05_ExternalPackageVerification(): Promise<{ passed: boolean; evidence: string }> {
    const validPkgFiles: Record<string, string> = {
      'src/apps/test/App.tsx': `import React from 'react';\nimport { motion } from 'motion/react';\nimport { Check } from 'lucide-react';\nexport default function App() { return <div>OK</div>; }`
    };
    const validRes = await UniversalRuntimeEngine.validateRuntime(validPkgFiles, 'src/apps/test/App.tsx');

    const fakePkgFiles: Record<string, string> = {
      'src/apps/test/App.tsx': `import React from 'react';\nimport { fakeThing } from 'completely-made-up-package-12345';\nexport default function App() { return <div>Fake</div>; }`
    };
    const fakeRes = await UniversalRuntimeEngine.validateRuntime(fakePkgFiles, 'src/apps/test/App.tsx');

    const passed = validRes.success && !fakeRes.success && fakeRes.caughtErrors.some(e => e.message.includes('completely-made-up-package'));
    return {
      passed,
      evidence: `Valid packages accepted; ungrounded package caught: "${fakeRes.caughtErrors[0]?.message}".`
    };
  }

  // 6. React Hook Rules Trapping
  private static async test06_HookRuleTrapping(): Promise<{ passed: boolean; evidence: string }> {
    const hookViolationFiles: Record<string, string> = {
      'src/apps/test/App.tsx': `import React, { useState } from 'react';
export default function App() {
  const flag = true;
  if (flag) {
    const [count, setCount] = useState(0);
  }
  return <div>Violation</div>;
}`
    };

    const res = await UniversalRuntimeEngine.validateRuntime(hookViolationFiles, 'src/apps/test/App.tsx');
    const hookErr = res.caughtErrors.find(e => e.type === 'HOOK_VIOLATION');
    const passed = !res.success && Boolean(hookErr);

    return {
      passed,
      evidence: `Correctly trapped conditional React Hook violation: "${hookErr?.message}".`
    };
  }

  // 7. Capability AVAILABLE Classification
  private static async test07_CapabilityAvailable(): Promise<{ passed: boolean; evidence: string }> {
    const canvasStatus = CapabilityRegistry.getCanonicalStatus('cap-canvas-2d');
    const audioStatus = CapabilityRegistry.getCanonicalStatus('cap-web-audio');
    const speechStatus = CapabilityRegistry.getCanonicalStatus('cap-speech-synthesis');
    const reactStatus = CapabilityRegistry.getCanonicalStatus('cap-react19-spa');

    const passed =
      canvasStatus === 'AVAILABLE' &&
      audioStatus === 'AVAILABLE' &&
      speechStatus === 'AVAILABLE' &&
      reactStatus === 'AVAILABLE';

    return {
      passed,
      evidence: `All local APIs correctly evaluated as AVAILABLE: Canvas2D (${canvasStatus}), Audio (${audioStatus}), Speech (${speechStatus}), React (${reactStatus}).`
    };
  }

  // 8. Capability REQUIRES_ENGINE Classification
  private static async test08_CapabilityRequiresEngine(): Promise<{ passed: boolean; evidence: string }> {
    const videoStatus = CapabilityRegistry.getCanonicalStatus('cap-text-to-video-diffusion');
    const imageStatus = CapabilityRegistry.getCanonicalStatus('cap-text-to-image-diffusion');
    const gameServerStatus = CapabilityRegistry.getCanonicalStatus('cap-dedicated-game-server');

    const passed =
      videoStatus === 'REQUIRES_ENGINE' &&
      imageStatus === 'REQUIRES_ENGINE' &&
      gameServerStatus === 'REQUIRES_ENGINE';

    return {
      passed,
      evidence: `External compute capabilities correctly identified as REQUIRES_ENGINE: Video Diffusion (${videoStatus}), Image Diffusion (${imageStatus}), Dedicated Game Server (${gameServerStatus}).`
    };
  }

  // 9. Capability UNAVAILABLE Boundary Enforcement
  private static async test09_CapabilityUnavailable(): Promise<{ passed: boolean; evidence: string }> {
    const kernelStatus = CapabilityRegistry.getCanonicalStatus('Direct GPU kernel register access');
    const socketStatus = CapabilityRegistry.getCanonicalStatus('Raw POSIX socket bypass');
    const driverStatus = CapabilityRegistry.getCanonicalStatus('Local C++ driver hardware flashing');

    const passed =
      kernelStatus === 'UNAVAILABLE' &&
      socketStatus === 'UNAVAILABLE' &&
      driverStatus === 'UNAVAILABLE';

    return {
      passed,
      evidence: `Unsupported native/kernel operations correctly rejected as UNAVAILABLE: Kernel (${kernelStatus}), POSIX socket (${socketStatus}), Driver (${driverStatus}).`
    };
  }

  // 10. Failure Diagnosis & Category Classification
  private static async test10_FailureDiagnosisClassification(): Promise<{ passed: boolean; evidence: string }> {
    const importErr = [{
      type: 'IMPORT' as const,
      file: 'src/apps/test/App.tsx',
      message: 'Unresolved relative import "./components/Missing"',
      severity: 'HIGH' as const,
      stage: 'IMPORT_RESOLUTION' as const
    }];
    const diag = RuntimeRepairEngine.diagnose(importErr, {});

    const passed = diag.category === 'UNRESOLVED_IMPORT' && diag.affectedFiles.includes('src/apps/test/App.tsx');
    return {
      passed,
      evidence: `Diagnostic category resolved to [${diag.category}] with confidence ${diag.confidence}.`
    };
  }

  // 11. MissionRecoveryEngine Advisory Strategy Routing
  private static async test11_MissionRecoveryRouting(): Promise<{ passed: boolean; evidence: string }> {
    const syntaxErr = [{
      type: 'SYNTAX' as const,
      file: 'src/apps/test/App.tsx',
      message: 'Syntax error: Unexpected token',
      severity: 'CRITICAL' as const,
      stage: 'TRANSPILE' as const
    }];
    const diag = RuntimeRepairEngine.diagnose(syntaxErr, { 'src/apps/test/App.tsx': 'const x =' });

    const passed = Boolean(diag.advisoryDecision) && diag.advisoryDecision?.strategy !== undefined;
    return {
      passed,
      evidence: `Advisory decision received: strategy=${diag.advisoryDecision?.strategy}, category=${diag.advisoryDecision?.category}.`
    };
  }

  // 12. Deterministic Patch Planning
  private static async test12_DeterministicPatchPlanning(): Promise<{ passed: boolean; evidence: string }> {
    const req = RequirementEngine.analyze('Build a soundboard audio mixer');
    const arch = ArchitecturePlanner.plan(req);
    const files = TemplateSystem.generateTemplateFiles(req, arch);

    const corruptedPath = arch.rootComponentPath;
    const corruptedFiles = {
      ...files,
      [corruptedPath]: 'export default function App() { return <div>Broken JSX'
    };

    const diag = RuntimeRepairEngine.diagnose([
      {
        type: 'SYNTAX',
        file: corruptedPath,
        message: 'Syntax error: Unterminated JSX contents',
        severity: 'CRITICAL',
        stage: 'TRANSPILE'
      }
    ], corruptedFiles);

    const patches = RuntimeRepairEngine.planRepairPatches(diag, corruptedFiles, req, arch);
    const passed = patches.length > 0 && patches[0].filePath === corruptedPath && AstParser.validateSyntax(corruptedPath, patches[0].repairedContent).length === 0;

    return {
      passed,
      evidence: `Planned ${patches.length} patch(es). Repaired code passed AST syntax validation cleanly.`
    };
  }

  // 13. ConflictManager Mutex Protection
  private static async test13_ConflictManagerMutexProtection(): Promise<{ passed: boolean; evidence: string }> {
    const conflictMgr = ConflictManager.getInstance();
    const hash = WorkspaceService.calculateHash('export default function App() {}');
    const lock1 = conflictMgr.acquireLock('src/apps/test/App.tsx', 'FILE', 'task-repair-1', 'RepairWorker1', 'CODER', hash);
    const lock2 = conflictMgr.acquireLock('src/apps/test/App.tsx', 'FILE', 'task-repair-2', 'RepairWorker2', 'CODER', hash);

    const passed = lock1.success && !lock2.success;
    conflictMgr.releaseAllForTask('task-repair-1');
    const lock3 = conflictMgr.acquireLock('src/apps/test/App.tsx', 'FILE', 'task-repair-2', 'RepairWorker2', 'CODER', hash);

    const fullyPassed = passed && lock3.success;
    conflictMgr.releaseAllForTask('task-repair-2');

    return {
      passed: fullyPassed,
      evidence: `ConflictManager blocked conflicting lock2 (${!lock2.success}) and safely allowed lock3 after release (${lock3.success}).`
    };
  }

  // 14. Bounded Repair Loop Termination
  private static async test14_BoundedRepairLoopTermination(): Promise<{ passed: boolean; evidence: string }> {
    const req = RequirementEngine.analyze('Build a simple note taker');
    const arch = ArchitecturePlanner.plan(req);

    // Unrepairable error in non-existent file
    const unrepairableErrors = [{
      type: 'UNSUPPORTED_API' as const,
      file: 'src/unknown/Phantom.tsx',
      message: 'Unsupported native hardware register',
      severity: 'CRITICAL' as const,
      stage: 'DOM_MOUNT' as const
    }];

    const result = await RuntimeRepairEngine.executeBoundedRepair(
      unrepairableErrors,
      {},
      req,
      arch,
      { maxAttempts: 3 }
    );

    const passed = result.attemptsMade <= 3 && !result.healed;
    return {
      passed,
      evidence: `Bounded repair terminated cleanly after ${result.attemptsMade} attempt(s) (Max: ${result.maxAttempts}) without infinite looping.`
    };
  }

  // 15. Post-Repair Successful Re-Verification Cycle
  private static async test15_PostRepairReVerification(): Promise<{ passed: boolean; evidence: string }> {
    const req = RequirementEngine.analyze('Build a recipe organizer with search and ingredient checkboxes');
    const arch = ArchitecturePlanner.plan(req);
    const validFiles = TemplateSystem.generateTemplateFiles(req, arch);

    // Corrupt one file with broken syntax
    const targetFile = arch.rootComponentPath;
    const damagedFiles = {
      ...validFiles,
      [targetFile]: 'export default function App() { return <div>Broken JSX without closing tag;'
    };

    const initialVerify = await UniversalRuntimeEngine.validateRuntime(damagedFiles, targetFile, arch, req);
    const repairOutcome = await RuntimeRepairEngine.executeBoundedRepair(
      initialVerify.telemetry?.runtimeErrors || [],
      damagedFiles,
      req,
      arch,
      { dryRun: true, maxAttempts: 3 }
    );

    const passed = !initialVerify.success && repairOutcome.healed && repairOutcome.finalTelemetry?.startupStatus === 'MOUNTED';
    return {
      passed,
      evidence: `Initial verification caught failure (${!initialVerify.success}). Post-repair telemetry status: ${repairOutcome.finalTelemetry?.startupStatus}.`
    };
  }

  // 16. Truthful Telemetry Capture
  private static async test16_TruthfulTelemetryCapture(): Promise<{ passed: boolean; evidence: string }> {
    const req = RequirementEngine.analyze('Build a customer support ticket portal');
    const arch = ArchitecturePlanner.plan(req);
    const files = TemplateSystem.generateTemplateFiles(req, arch);

    const res = await UniversalRuntimeEngine.validateRuntime(files, arch.rootComponentPath, arch, req);
    const tel = res.telemetry;

    const valid =
      Boolean(tel) &&
      tel?.startupStatus === 'MOUNTED' &&
      tel?.mountStatus === 'MOUNTED_CLEAN' &&
      tel?.failedInitializationStage === 'NONE' &&
      tel?.browserApisAudited.length > 0 &&
      tel?.executionDurationMs >= 0;

    return {
      passed: valid,
      evidence: `Telemetry captured: startup=${tel?.startupStatus}, mount=${tel?.mountStatus}, auditedApis=${tel?.browserApisAudited.length}, duration=${tel?.executionDurationMs}ms.`
    };
  }

  // 17. Epistemic Honesty Verification
  private static async test17_EpistemicHonestyVerification(): Promise<{ passed: boolean; evidence: string }> {
    const req = RequirementEngine.analyze('Build a video generation app with AI prompt to video');
    const arch = ArchitecturePlanner.plan(req);
    const files = TemplateSystem.generateTemplateFiles(req, arch);
    const contract = UniversalRuntimeEngine.generateContract(req, arch, files);

    // External AI video generation MUST NOT be claimed as native available
    const videoCapability = contract.capabilities?.['cap-text-to-video-diffusion'];
    const unsupportedList = contract.unsupportedCapabilities || [];

    const passed = videoCapability === 'REQUIRES_ENGINE' && unsupportedList.length > 0;
    return {
      passed,
      evidence: `Epistemic boundary intact: Video Diffusion status is [${videoCapability}], unsupportedCapabilities contains: "${unsupportedList[0]}".`
    };
  }

  // 18. Creative Studio Contract Support
  private static async test18_CreativeStudioContract(): Promise<{ passed: boolean; evidence: string }> {
    const req = RequirementEngine.analyze('Build a canvas drawing animation studio with web audio synthesizer');
    const arch = ArchitecturePlanner.plan(req);
    const files = TemplateSystem.generateTemplateFiles(req, arch);
    const contract = UniversalRuntimeEngine.generateContract(req, arch, files);

    const hasCanvas = contract.runtimeRequirements.canvasRequired;
    const hasAudio = contract.runtimeRequirements.audioRequired;
    const hasCanvasAsset = contract.assets?.some(a => a.type === 'CANVAS_TEXTURE');
    const hasAudioAsset = contract.assets?.some(a => a.type === 'AUDIO_SYNTH');

    const passed = hasCanvas && hasAudio && hasCanvasAsset && hasAudioAsset;
    return {
      passed,
      evidence: `Creative Studio requirements verified: Canvas=${hasCanvas}, Audio=${hasAudio}, CanvasAsset=${hasCanvasAsset}, AudioAsset=${hasAudioAsset}.`
    };
  }

  // 19. Engineering Memory Persistence
  private static async test19_EngineeringMemoryPersistence(): Promise<{ passed: boolean; evidence: string }> {
    const memEngine = EngineeringMemoryEngine.getInstance();
    const repairCountBefore = memEngine.getStore().getEntriesByType('REPAIR').length;

    memEngine.recordRepair({
      errorCode: 'RUNTIME',
      attemptNumber: 1,
      strategy: 'DETERMINISTIC_PATCH',
      files: ['src/apps/test/App.tsx'],
      outcome: 'SUCCESS',
      proposedFix: 'Fixed missing export',
      verificationEvidence: ['Mount check passed'],
      task: 'task-test-p23'
    });

    const repairCountAfter = memEngine.getStore().getEntriesByType('REPAIR').length;
    const passed = repairCountAfter > repairCountBefore;

    return {
      passed,
      evidence: `Engineering Memory successfully stored repair event (Repairs: ${repairCountBefore} -> ${repairCountAfter}).`
    };
  }

  // 20. End-to-End Build & Execution Pipeline
  private static async test20_EndToEndPipeline(): Promise<{ passed: boolean; evidence: string }> {
    const prompt = 'Build a modern fitness streak and habit tracker with weekly progress charts';

    const result = await UniversalAppBuilder.buildApp(prompt, {}, { dryRun: true });
    const passed =
      result.success &&
      result.verificationDossier.overallPassed &&
      result.generatedApp.entryPoint === result.architectureSpec.rootComponentPath &&
      result.generatedApp.verificationStatus.overallPassed &&
      Object.keys(result.generatedFiles).length >= 5;

    return {
      passed,
      evidence: `Built "${result.generatedApp.applicationIdentity.name}" with ${Object.keys(result.generatedFiles).length} files, score ${result.verificationDossier.verificationScore}/100, status ${result.generatedApp.generationStatus}.`
    };
  }
}

export async function runUniversalAppBuilderP23TestSuite(): Promise<P23TestSuiteReport> {
  return UniversalAppBuilderP23TestSuite.runAllTests();
}

if (typeof process !== 'undefined' && process.argv && process.argv[1] && process.argv[1].includes('universalAppBuilderP23Test')) {
  console.log('=== RUNNING GODEX P2.3 UNIVERSAL RUNTIME & REPAIR TEST SUITE (20 TESTS) ===');
  UniversalAppBuilderP23TestSuite.runAllTests().then(report => {
    console.log(`\nP2.3 Results: ${report.passedTests}/${report.totalTests} passed (${report.successRate}%).`);
    for (const r of report.results) {
      console.log(`  [${r.passed ? 'PASS' : 'FAIL'}] ${r.id}: ${r.name} (${r.durationMs}ms) - ${r.evidence}`);
    }
    if (!report.allPassed) {
      console.error(`\n❌ P2.3 TEST SUITE FAILED (${report.failedTests} failures)`);
      process.exit(1);
    } else {
      console.log(`\n✅ ALL ${report.totalTests} P2.3 TESTS PASSED CLEANLY`);
      process.exit(0);
    }
  }).catch(err => {
    console.error('Fatal error in P2.3 test execution:', err);
    process.exit(1);
  });
}

