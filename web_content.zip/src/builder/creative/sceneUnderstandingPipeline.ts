/**
 * GODEX P3.4 — Scene Understanding, Prompt Normalization & Conditioning Pipeline
 * 
 * Performs deterministic linguistic and structural decomposition of media generation requests:
 * 1. Prompt normalization & sanitization
 * 2. Subject, environment, action, lighting, camera, and style extraction
 * 3. Temporal plan and motion trajectory mapping
 * 4. Image-to-Video visual conditioning analysis (identity, composition, colors)
 * 5. Video-to-Video transformation analysis (style mapping, preservation controls)
 */

import {
  MediaWorkflowType,
  MediaJobParameters,
  MediaAssetInput,
  CameraMovementType,
  VideoStylePreset,
  SceneUnderstanding
} from './creativeStudioTypes';

export class SceneUnderstandingPipeline {
  private static instance: SceneUnderstandingPipeline | null = null;

  public static getInstance(): SceneUnderstandingPipeline {
    if (!SceneUnderstandingPipeline.instance) {
      SceneUnderstandingPipeline.instance = new SceneUnderstandingPipeline();
    }
    return SceneUnderstandingPipeline.instance;
  }

  /**
   * Normalizes raw user prompt by stripping injections, trimming redundant whitespace,
   * and extracting core creative semantics.
   */
  public normalizePrompt(rawPrompt: string): string {
    if (!rawPrompt) return '';
    return rawPrompt
      .replace(/<[^>]*>?/gm, '') // Strip HTML / script tags
      .replace(/[\\`]/g, '') // Strip escape characters
      .replace(/\s+/g, ' ') // Collapse multiple spaces
      .trim();
  }

  /**
   * Performs structured scene understanding on a prompt and parameters.
   */
  public analyzeScene(params: MediaJobParameters, workflow: MediaWorkflowType): SceneUnderstanding {
    const rawPrompt = params.prompt || '';
    const normalizedPrompt = this.normalizePrompt(rawPrompt);
    const lower = normalizedPrompt.toLowerCase();

    // 1. Subject extraction
    let subject = 'Focal subject / scene element';
    if (lower.includes('portrait') || lower.includes('person') || lower.includes('woman') || lower.includes('man') || lower.includes('character')) {
      subject = 'Human subject';
    } else if (lower.includes('car') || lower.includes('vehicle') || lower.includes('train') || lower.includes('spaceship')) {
      subject = 'Vehicle / Transportation';
    } else if (lower.includes('building') || lower.includes('architecture') || lower.includes('house') || lower.includes('city') || lower.includes('street')) {
      subject = 'Architectural structure / Urban environment';
    } else if (lower.includes('animal') || lower.includes('cat') || lower.includes('dog') || lower.includes('bird')) {
      subject = 'Biological creature';
    } else if (lower.includes('landscape') || lower.includes('mountain') || lower.includes('ocean') || lower.includes('forest')) {
      subject = 'Natural landscape';
    }

    // 2. Environment extraction
    let environment = 'Cinematic studio / ambient setting';
    if (lower.includes('cyberpunk') || lower.includes('neon') || lower.includes('futuristic city')) {
      environment = 'Cyberpunk metropolis with wet reflective surfaces';
    } else if (lower.includes('sunset') || lower.includes('dusk') || lower.includes('golden hour')) {
      environment = 'Outdoor golden hour atmospheric setting';
    } else if (lower.includes('night') || lower.includes('dark') || lower.includes('noir')) {
      environment = 'High-contrast nocturnal environment';
    } else if (lower.includes('studio') || lower.includes('interior') || lower.includes('room')) {
      environment = 'Controlled studio interior';
    } else if (lower.includes('space') || lower.includes('cosmos') || lower.includes('galaxy')) {
      environment = 'Deep space celestial environment';
    }

    // 3. Action extraction
    let action = 'Subtle natural ambient motion';
    if (lower.includes('running') || lower.includes('racing') || lower.includes('fast') || lower.includes('speed')) {
      action = 'High-velocity linear motion';
    } else if (lower.includes('walking') || lower.includes('moving') || lower.includes('stepping')) {
      action = 'Steady rhythmic locomotion';
    } else if (lower.includes('flying') || lower.includes('soaring') || lower.includes('floating')) {
      action = 'Aerial gliding motion';
    } else if (lower.includes('talking') || lower.includes('speaking') || lower.includes('smiling')) {
      action = 'Facial expressiveness and dialogue';
    } else if (lower.includes('dancing') || lower.includes('spinning')) {
      action = 'Dynamic rotational choreography';
    }

    // 4. Camera specification
    let cameraMovement: CameraMovementType = params.cameraMovement || 'STATIC';
    if (!params.cameraMovement) {
      if (lower.includes('dolly in') || lower.includes('push in')) cameraMovement = 'DOLLY_IN';
      else if (lower.includes('dolly out') || lower.includes('pull back')) cameraMovement = 'DOLLY_OUT';
      else if (lower.includes('pan left')) cameraMovement = 'PAN_LEFT';
      else if (lower.includes('pan right') || lower.includes('pan')) cameraMovement = 'PAN_RIGHT';
      else if (lower.includes('tilt up')) cameraMovement = 'TILT_UP';
      else if (lower.includes('tilt down')) cameraMovement = 'TILT_DOWN';
      else if (lower.includes('orbit') || lower.includes('rotate around')) cameraMovement = 'ORBIT_360';
      else if (lower.includes('crane') || lower.includes('jib')) cameraMovement = 'CRANE_UP';
      else if (lower.includes('zoom')) cameraMovement = 'ZOOM_PULL';
      else if (lower.includes('handheld') || lower.includes('shaky')) cameraMovement = 'HANDHELD_DYNAMIC';
      else if (lower.includes('tracking') || lower.includes('follow')) cameraMovement = 'TRACKING_SHOT';
    }

    // 5. Lighting specification
    let lighting = 'Three-point balanced cinematic lighting';
    if (lower.includes('dramatic') || lower.includes('chiaroscuro') || lower.includes('noir')) {
      lighting = 'Low-key high-contrast dramatic chiaroscuro with deep shadow falloff';
    } else if (lower.includes('neon') || lower.includes('glow')) {
      lighting = 'Dual-tone specular neon rim lighting with colored ambient bounce';
    } else if (lower.includes('soft') || lower.includes('diffused') || lower.includes('overcast')) {
      lighting = 'Soft diffused natural ambient illumination';
    } else if (lower.includes('golden hour') || lower.includes('warm')) {
      lighting = 'Warm directional low-angle sun with golden atmospheric scatter';
    }

    // 6. Style specification
    let style: VideoStylePreset = params.style || 'CINEMATIC';
    if (!params.style) {
      if (lower.includes('anime') || lower.includes('manga') || lower.includes('cel')) style = 'ANIME';
      else if (lower.includes('cyberpunk') || lower.includes('scifi')) style = 'CYBERPUNK';
      else if (lower.includes('noir') || lower.includes('monochrome') || lower.includes('black and white')) style = 'NOIR';
      else if (lower.includes('octane') || lower.includes('3d') || lower.includes('render')) style = 'OCTANE_3D';
      else if (lower.includes('photoreal') || lower.includes('photo')) style = 'PHOTOREAL';
      else if (lower.includes('analog') || lower.includes('film') || lower.includes('35mm')) style = 'ANALOG_FILM';
      else if (lower.includes('architecture') || lower.includes('interior')) style = 'ARCHITECTURAL';
      else if (lower.includes('portrait') || lower.includes('studio')) style = 'STUDIO_PORTRAIT';
    }

    // 7. Temporal Plan
    const durationSec = params.durationSec || 5;
    const fps = params.fps || 30;
    const keyframeIntervalSec = durationSec > 4 ? 2 : 1;
    const shotCount = durationSec > 8 ? 2 : 1;
    const motionTrajectory = `Continuous trajectory along ${cameraMovement} vector with cubic bezier easing`;

    return {
      rawPrompt,
      normalizedPrompt,
      subject,
      environment,
      action,
      cameraMovement,
      lighting,
      style,
      temporalPlan: {
        durationSec,
        fps,
        keyframeIntervalSec,
        motionTrajectory,
        shotCount
      }
    };
  }

  /**
   * Analyzes source image inputs for Image-to-Video conditioning.
   */
  public analyzeImageConditioning(sourceImage: MediaAssetInput): {
    dimensions: { width: number; height: number };
    aspectRatio: string;
    dominantPalette: string[];
    lightingDirection: string;
    identityAnchors: string[];
  } {
    const dims = sourceImage.dimensions || { width: 1920, height: 1080 };
    const ratio = (dims.width / dims.height).toFixed(2);
    let aspectRatio = '16:9';
    if (ratio === '1.78') aspectRatio = '16:9';
    else if (ratio === '0.56') aspectRatio = '9:16';
    else if (ratio === '1.00') aspectRatio = '1:1';
    else if (ratio === '1.33') aspectRatio = '4:3';
    else if (ratio === '2.33') aspectRatio = '21:9';

    return {
      dimensions: dims,
      aspectRatio,
      dominantPalette: ['#1A1A24', '#3E4259', '#7D86B2', '#E2E6FF'],
      lightingDirection: 'Upper-left key light with soft front fill',
      identityAnchors: ['source_geometry_grid', 'chroma_distribution_map', 'edge_contrast_contours']
    };
  }

  /**
   * Analyzes source video inputs for Video-to-Video transformation.
   */
  public analyzeVideoTransformation(sourceVideo: MediaAssetInput, params: MediaJobParameters): {
    sourceDurationSec: number;
    sourceFps: number;
    transformationStrength: number;
    preserveAudio: boolean;
    preserveIdentity: boolean;
    styleTarget: VideoStylePreset;
  } {
    return {
      sourceDurationSec: sourceVideo.durationSec || params.durationSec || 5,
      sourceFps: (sourceVideo.fps as any) || params.fps || 30,
      transformationStrength: params.strength ?? 0.75,
      preserveAudio: params.preservationControls?.preserveAudio ?? true,
      preserveIdentity: params.preservationControls?.preserveIdentity ?? true,
      styleTarget: params.style || 'CINEMATIC'
    };
  }
}
