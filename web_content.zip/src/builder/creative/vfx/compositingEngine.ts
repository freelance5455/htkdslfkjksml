/**
 * GODEX P4.3 — Compositing Engine
 * 
 * High-performance multi-layer 2D affine compositor, non-destructive layer stack,
 * Porter-Duff and color blend modes, vector mask clipping, and alpha matting.
 */

import { VfxLayer, VfxBlendMode, VfxTransform } from './vfxTypes';
import { MaskingEngine } from './maskingEngine';
import { KeyingEngine } from './keyingEngine';
import { ParticleEffectsEngine } from './particleEffectsEngine';

export class CompositingEngine {
  private static instance: CompositingEngine | null = null;

  public static getInstance(): CompositingEngine {
    if (!CompositingEngine.instance) {
      CompositingEngine.instance = new CompositingEngine();
    }
    return CompositingEngine.instance;
  }

  /**
   * Composites a stack of layers into a master output buffer
   */
  public compositeLayers(
    layers: VfxLayer[],
    layerBuffers: Map<string, Uint8ClampedArray>,
    width: number,
    height: number,
    currentFrame: number = 0
  ): Uint8ClampedArray {
    const masterBuffer = new Uint8ClampedArray(width * height * 4);
    // Initialize transparent/black
    masterBuffer.fill(0);

    const maskingEngine = MaskingEngine.getInstance();
    const keyingEngine = KeyingEngine.getInstance();
    const effectsEngine = ParticleEffectsEngine.getInstance();

    // Filter visible layers active at current frame
    const activeLayers = layers.filter(l => {
      if (!l.visible) return false;
      const inRange = currentFrame >= l.startFrame && currentFrame < (l.startFrame + l.durationFrames);
      return inRange;
    });

    const hasSolo = activeLayers.some(l => l.solo);
    const renderLayers = hasSolo ? activeLayers.filter(l => l.solo) : activeLayers;

    for (const layer of renderLayers) {
      let layerData = layerBuffers.get(layer.id);
      
      // If solid color layer and no buffer provided, generate on the fly
      if (!layerData && layer.type === 'SOLID_COLOR') {
        layerData = this.generateSolidColorBuffer(layer, width, height);
      }

      if (!layerData) continue;

      let processedLayerData = new Uint8ClampedArray(layerData.length);
      processedLayerData.set(layerData);

      // 1. Apply Keying if configured on layer
      if (layer.keying) {
        const keyResult = keyingEngine.processKeying(
          processedLayerData,
          layer.dimensions.width || width,
          layer.dimensions.height || height,
          layer.keying
        );
        processedLayerData = keyResult.despilledData || processedLayerData;
      }

      // 2. Apply Vector Masks if configured
      if (layer.masks && layer.masks.length > 0) {
        const maskMatte = maskingEngine.rasterizeMasks(
          layer.masks,
          layer.dimensions.width || width,
          layer.dimensions.height || height
        );
        const pCount = (layer.dimensions.width || width) * (layer.dimensions.height || height);
        for (let i = 0; i < pCount; i++) {
          const mAlpha = maskMatte[i] / 255;
          processedLayerData[i * 4 + 3] = Math.round(processedLayerData[i * 4 + 3] * mAlpha);
        }
      }

      // 3. Apply Cinematic Effects & Color Grading
      if (layer.effects) {
        processedLayerData = effectsEngine.applyCinematicEffects(
          processedLayerData,
          layer.dimensions.width || width,
          layer.dimensions.height || height,
          layer.effects
        );
      }

      // 4. Blend processed layer into Master Buffer with Transform & Opacity
      this.blendLayerOntoMaster(
        masterBuffer,
        processedLayerData,
        width,
        height,
        layer.dimensions.width || width,
        layer.dimensions.height || height,
        layer.transform,
        layer.blendMode
      );
    }

    return masterBuffer;
  }

  /**
   * Blends a single source layer onto the master canvas with 2D transform and blend mode
   */
  public blendLayerOntoMaster(
    dest: Uint8ClampedArray,
    src: Uint8ClampedArray,
    destW: number,
    destH: number,
    srcW: number,
    srcH: number,
    transform: VfxTransform,
    blendMode: VfxBlendMode
  ): void {
    const opacity = Math.max(0, Math.min(1, transform.opacity));
    if (opacity <= 0) return;

    const posX = transform.position.x;
    const posY = transform.position.y;
    const scaleX = transform.scale.x || 1.0;
    const scaleY = transform.scale.y || 1.0;
    const rotRad = (transform.rotationDeg * Math.PI) / 180;
    const cosR = Math.cos(-rotRad);
    const sinR = Math.sin(-rotRad);
    const ancX = transform.anchorPoint.x || srcW / 2;
    const ancY = transform.anchorPoint.y || srcH / 2;

    // Iterate over destination bounding area
    for (let dy = 0; dy < destH; dy++) {
      const destRow = dy * destW * 4;
      for (let dx = 0; dx < destW; dx++) {
        // Inverse transform from dest (dx, dy) to src (sx, sy)
        const relX = dx - posX;
        const relY = dy - posY;

        const rotX = relX * cosR - relY * sinR;
        const rotY = relX * sinR + relY * cosR;

        const sx = Math.round(rotX / scaleX + ancX);
        const sy = Math.round(rotY / scaleY + ancY);

        if (sx >= 0 && sx < srcW && sy >= 0 && sy < srcH) {
          const srcIdx = (sy * srcW + sx) * 4;
          const destIdx = destRow + dx * 4;

          const sr = src[srcIdx];
          const sg = src[srcIdx + 1];
          const sb = src[srcIdx + 2];
          const sa = (src[srcIdx + 3] / 255) * opacity;

          if (sa <= 0) continue;

          const dr = dest[destIdx];
          const dg = dest[destIdx + 1];
          const db = dest[destIdx + 2];
          const da = dest[destIdx + 3] / 255;

          // Apply Color Blend Mode
          const blendedRgb = this.applyBlendMode(sr, sg, sb, dr, dg, db, blendMode);

          // Alpha Compositing (Porter-Duff Over)
          const outA = sa + da * (1 - sa);
          if (outA > 0) {
            dest[destIdx] = Math.round((blendedRgb.r * sa + dr * da * (1 - sa)) / outA);
            dest[destIdx + 1] = Math.round((blendedRgb.g * sa + dg * da * (1 - sa)) / outA);
            dest[destIdx + 2] = Math.round((blendedRgb.b * sa + db * da * (1 - sa)) / outA);
            dest[destIdx + 3] = Math.round(outA * 255);
          }
        }
      }
    }
  }

  /**
   * High performance calculation of Photoshop & Porter-Duff blend modes
   */
  public applyBlendMode(
    sr: number, sg: number, sb: number,
    dr: number, dg: number, db: number,
    mode: VfxBlendMode
  ): { r: number; g: number; b: number } {
    switch (mode) {
      case 'multiply':
        return {
          r: Math.round((sr * dr) / 255),
          g: Math.round((sg * dg) / 255),
          b: Math.round((sb * db) / 255)
        };
      case 'screen':
        return {
          r: Math.round(255 - ((255 - sr) * (255 - dr)) / 255),
          g: Math.round(255 - ((255 - sg) * (255 - dg)) / 255),
          b: Math.round(255 - ((255 - sb) * (255 - db)) / 255)
        };
      case 'overlay':
        return {
          r: dr < 128 ? Math.round((2 * sr * dr) / 255) : Math.round(255 - (2 * (255 - sr) * (255 - dr)) / 255),
          g: dg < 128 ? Math.round((2 * sg * dg) / 255) : Math.round(255 - (2 * (255 - sg) * (255 - dg)) / 255),
          b: db < 128 ? Math.round((2 * sb * db) / 255) : Math.round(255 - (2 * (255 - sb) * (255 - db)) / 255)
        };
      case 'add':
        return {
          r: Math.min(255, sr + dr),
          g: Math.min(255, sg + dg),
          b: Math.min(255, sb + db)
        };
      case 'subtract':
        return {
          r: Math.max(0, dr - sr),
          g: Math.max(0, dg - sg),
          b: Math.max(0, db - sb)
        };
      case 'difference':
        return {
          r: Math.abs(dr - sr),
          g: Math.abs(dg - sg),
          b: Math.abs(db - sb)
        };
      case 'darken':
        return {
          r: Math.min(sr, dr),
          g: Math.min(sg, dg),
          b: Math.min(sb, db)
        };
      case 'lighten':
        return {
          r: Math.max(sr, dr),
          g: Math.max(sg, dg),
          b: Math.max(sb, db)
        };
      case 'normal':
      default:
        return { r: sr, g: sg, b: sb };
    }
  }

  private generateSolidColorBuffer(layer: VfxLayer, width: number, height: number): Uint8ClampedArray {
    const buf = new Uint8ClampedArray(width * height * 4);
    const hex = layer.meta?.color || '#000000';
    const clean = hex.replace('#', '');
    const r = parseInt(clean.substring(0, 2), 16) || 0;
    const g = parseInt(clean.substring(2, 4), 16) || 0;
    const b = parseInt(clean.substring(4, 6), 16) || 0;

    const len = buf.length;
    for (let i = 0; i < len; i += 4) {
      buf[i] = r;
      buf[i + 1] = g;
      buf[i + 2] = b;
      buf[i + 3] = 255;
    }
    return buf;
  }
}
