/**
 * GODEX P4.3 — Rotoscoping Engine
 * 
 * Frame-accurate rotoscoping, temporal mask keyframe interpolation,
 * motion-guided mask propagation, and edge feather refinement.
 */

import { VfxMask, MaskPoint, TrackPoint } from './vfxTypes';
import { MaskingEngine } from './maskingEngine';

export interface RotoKeyframe {
  frame: number;
  points: MaskPoint[];
  feather?: number;
  expansion?: number;
  opacity?: number;
}

export interface RotoTrack {
  maskId: string;
  maskName: string;
  keyframes: RotoKeyframe[];
  shapeType: 'POLYGON' | 'BEZIER' | 'RECTANGLE' | 'ELLIPSE';
  motionTrackId?: string;
}

export class RotoscopingEngine {
  private static instance: RotoscopingEngine | null = null;
  private tracks: Map<string, RotoTrack> = new Map();

  public static getInstance(): RotoscopingEngine {
    if (!RotoscopingEngine.instance) {
      RotoscopingEngine.instance = new RotoscopingEngine();
    }
    return RotoscopingEngine.instance;
  }

  public createRotoTrack(mask: VfxMask, currentFrame: number): RotoTrack {
    const track: RotoTrack = {
      maskId: mask.id,
      maskName: mask.name,
      keyframes: [
        {
          frame: currentFrame,
          points: mask.points.map(p => ({ ...p })),
          feather: mask.feather,
          expansion: mask.expansion,
          opacity: mask.opacity
        }
      ],
      shapeType: mask.shapeType === 'FREEHAND' ? 'POLYGON' : mask.shapeType
    };
    this.tracks.set(mask.id, track);
    return track;
  }

  public addKeyframe(maskId: string, frame: number, points: MaskPoint[], feather?: number, expansion?: number): void {
    let track = this.tracks.get(maskId);
    if (!track) {
      track = {
        maskId,
        maskName: `Roto_${maskId.substring(0, 5)}`,
        keyframes: [],
        shapeType: 'POLYGON'
      };
      this.tracks.set(maskId, track);
    }

    const existingIndex = track.keyframes.findIndex(k => k.frame === frame);
    const keyframe: RotoKeyframe = {
      frame,
      points: points.map(p => ({ ...p })),
      feather,
      expansion
    };

    if (existingIndex >= 0) {
      track.keyframes[existingIndex] = keyframe;
    } else {
      track.keyframes.push(keyframe);
      track.keyframes.sort((a, b) => a.frame - b.frame);
    }
  }

  /**
   * Evaluates the interpolated mask at any target frame
   */
  public evaluateMaskAtFrame(mask: VfxMask, frame: number): VfxMask {
    const track = this.tracks.get(mask.id);
    if (!track || track.keyframes.length === 0) {
      return mask;
    }

    const kfs = track.keyframes;
    // Exact match or single keyframe
    const exact = kfs.find(k => k.frame === frame);
    if (exact) {
      return {
        ...mask,
        points: exact.points.map(p => ({ ...p })),
        feather: exact.feather !== undefined ? exact.feather : mask.feather,
        expansion: exact.expansion !== undefined ? exact.expansion : mask.expansion
      };
    }

    // Before first keyframe
    if (frame <= kfs[0].frame) {
      return {
        ...mask,
        points: kfs[0].points.map(p => ({ ...p })),
        feather: kfs[0].feather !== undefined ? kfs[0].feather : mask.feather,
        expansion: kfs[0].expansion !== undefined ? kfs[0].expansion : mask.expansion
      };
    }

    // After last keyframe
    if (frame >= kfs[kfs.length - 1].frame) {
      const last = kfs[kfs.length - 1];
      return {
        ...mask,
        points: last.points.map(p => ({ ...p })),
        feather: last.feather !== undefined ? last.feather : mask.feather,
        expansion: last.expansion !== undefined ? last.expansion : mask.expansion
      };
    }

    // Interpolate between two surrounding keyframes
    let prevIndex = 0;
    for (let i = 0; i < kfs.length - 1; i++) {
      if (frame >= kfs[i].frame && frame < kfs[i + 1].frame) {
        prevIndex = i;
        break;
      }
    }

    const kfA = kfs[prevIndex];
    const kfB = kfs[prevIndex + 1];
    const t = (frame - kfA.frame) / (kfB.frame - kfA.frame);
    // Smooth cosine easing
    const smoothT = 0.5 * (1 - Math.cos(t * Math.PI));

    const numPoints = Math.min(kfA.points.length, kfB.points.length);
    const interpolatedPoints: MaskPoint[] = [];

    for (let p = 0; p < numPoints; p++) {
      const pA = kfA.points[p];
      const pB = kfB.points[p];
      interpolatedPoints.push({
        x: pA.x + (pB.x - pA.x) * smoothT,
        y: pA.y + (pB.y - pA.y) * smoothT,
        handleIn: pA.handleIn && pB.handleIn ? {
          x: pA.handleIn.x + (pB.handleIn.x - pA.handleIn.x) * smoothT,
          y: pA.handleIn.y + (pB.handleIn.y - pA.handleIn.y) * smoothT
        } : undefined,
        handleOut: pA.handleOut && pB.handleOut ? {
          x: pA.handleOut.x + (pB.handleOut.x - pA.handleOut.x) * smoothT,
          y: pA.handleOut.y + (pB.handleOut.y - pA.handleOut.y) * smoothT
        } : undefined
      });
    }

    const interpolatedFeather = (kfA.feather ?? mask.feather) + ((kfB.feather ?? mask.feather) - (kfA.feather ?? mask.feather)) * smoothT;
    const interpolatedExpansion = (kfA.expansion ?? mask.expansion) + ((kfB.expansion ?? mask.expansion) - (kfA.expansion ?? mask.expansion)) * smoothT;

    return {
      ...mask,
      points: interpolatedPoints,
      feather: interpolatedFeather,
      expansion: interpolatedExpansion
    };
  }

  /**
   * Propagate mask points forward using motion track offsets
   */
  public propagateWithMotionTrack(
    maskId: string,
    motionPoints: TrackPoint[],
    referenceFrame: number
  ): void {
    const track = this.tracks.get(maskId);
    if (!track || track.keyframes.length === 0) return;

    const refKf = track.keyframes.find(k => k.frame === referenceFrame) || track.keyframes[0];
    const refMotion = motionPoints.find(m => m.frame === referenceFrame);
    if (!refMotion) return;

    for (const motion of motionPoints) {
      if (motion.frame === referenceFrame || motion.status !== 'TRACKED') continue;

      const dx = motion.x - refMotion.x;
      const dy = motion.y - refMotion.y;

      const newPoints = refKf.points.map(p => ({
        ...p,
        x: p.x + dx,
        y: p.y + dy,
        handleIn: p.handleIn ? { x: p.handleIn.x + dx, y: p.handleIn.y + dy } : undefined,
        handleOut: p.handleOut ? { x: p.handleOut.x + dx, y: p.handleOut.y + dy } : undefined
      }));

      this.addKeyframe(maskId, motion.frame, newPoints, refKf.feather, refKf.expansion);
    }
  }
}
