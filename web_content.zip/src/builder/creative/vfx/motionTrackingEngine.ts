/**
 * GODEX P4.3 — Motion Tracking Engine
 * 
 * High-performance deterministic 2D feature-point tracker, bounding-box object tracker,
 * template correlation, tracking confidence scoring, and camera motion estimation foundation.
 */

import { MotionTrackingData, TrackPoint } from './vfxTypes';

export interface TrackingStepInput {
  currentFrameData: Uint8ClampedArray;
  prevFrameData: Uint8ClampedArray;
  width: number;
  height: number;
  frameNumber: number;
}

export class MotionTrackingEngine {
  private static instance: MotionTrackingEngine | null = null;

  public static getInstance(): MotionTrackingEngine {
    if (!MotionTrackingEngine.instance) {
      MotionTrackingEngine.instance = new MotionTrackingEngine();
    }
    return MotionTrackingEngine.instance;
  }

  /**
   * Create a new tracking tracker for a bounding region
   */
  public initializeTracker(
    name: string,
    initialRegion: { x: number; y: number; width: number; height: number },
    startFrame: number = 0,
    searchRadius: number = 32
  ): MotionTrackingData {
    const centerX = initialRegion.x + initialRegion.width / 2;
    const centerY = initialRegion.y + initialRegion.height / 2;

    return {
      id: `track-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name,
      targetRegion: initialRegion,
      searchRadius,
      trackPoints: [
        {
          frame: startFrame,
          x: centerX,
          y: centerY,
          confidence: 100,
          status: 'TRACKED'
        }
      ],
      avgConfidence: 100,
      isLost: false,
      trackingType: 'POINT'
    };
  }

  /**
   * Detects salient feature points (corners/high-contrast spots) inside a search box
   */
  public detectFeatures(
    rgbaData: Uint8ClampedArray,
    width: number,
    height: number,
    region: { x: number; y: number; width: number; height: number }
  ): Array<{ x: number; y: number; score: number }> {
    const features: Array<{ x: number; y: number; score: number }> = [];
    const minX = Math.max(1, Math.floor(region.x));
    const maxX = Math.min(width - 2, Math.ceil(region.x + region.width));
    const minY = Math.max(1, Math.floor(region.y));
    const maxY = Math.min(height - 2, Math.ceil(region.y + region.height));

    const step = 4;
    for (let y = minY; y < maxY; y += step) {
      for (let x = minX; x < maxX; x += step) {
        // Compute horizontal and vertical gradients (Sobel 3x3)
        const getLuma = (px: number, py: number) => {
          const idx = (py * width + px) * 4;
          return 0.299 * rgbaData[idx] + 0.587 * rgbaData[idx + 1] + 0.114 * rgbaData[idx + 2];
        };

        const gx = (getLuma(x + 1, y - 1) + 2 * getLuma(x + 1, y) + getLuma(x + 1, y + 1)) -
                   (getLuma(x - 1, y - 1) + 2 * getLuma(x - 1, y) + getLuma(x - 1, y + 1));
        const gy = (getLuma(x - 1, y + 1) + 2 * getLuma(x, y + 1) + getLuma(x + 1, y + 1)) -
                   (getLuma(x - 1, y - 1) + 2 * getLuma(x, y - 1) + getLuma(x + 1, y - 1));

        const score = Math.sqrt(gx * gx + gy * gy);
        if (score > 60) {
          features.push({ x, y, score });
        }
      }
    }

    return features.sort((a, b) => b.score - a.score).slice(0, 20);
  }

  /**
   * Tracks a feature point from previous frame to current frame using Normalized Cross-Correlation (NCC)
   */
  public trackFeaturePoint(
    tracker: MotionTrackingData,
    input: TrackingStepInput,
    confidenceThreshold: number = 40
  ): TrackPoint {
    const prevPoint = tracker.trackPoints[tracker.trackPoints.length - 1];
    if (!prevPoint) {
      return {
        frame: input.frameNumber,
        x: tracker.targetRegion.x + tracker.targetRegion.width / 2,
        y: tracker.targetRegion.y + tracker.targetRegion.height / 2,
        confidence: 0,
        status: 'LOST'
      };
    }

    const searchR = tracker.searchRadius;
    const patchSize = 8; // 16x16 patch
    const startX = Math.round(prevPoint.x);
    const startY = Math.round(prevPoint.y);

    let bestScore = -Infinity;
    let bestX = startX;
    let bestY = startY;

    const getPixelLuma = (data: Uint8ClampedArray, px: number, py: number) => {
      const clampedX = Math.max(0, Math.min(input.width - 1, px));
      const clampedY = Math.max(0, Math.min(input.height - 1, py));
      const idx = (clampedY * input.width + clampedX) * 4;
      return 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
    };

    // Extract reference patch mean
    let refSum = 0;
    let refCount = 0;
    for (let dy = -patchSize; dy <= patchSize; dy++) {
      for (let dx = -patchSize; dx <= patchSize; dx++) {
        refSum += getPixelLuma(input.prevFrameData, startX + dx, startY + dy);
        refCount++;
      }
    }
    const refMean = refSum / refCount;

    // Search around previous point
    for (let sy = -searchR; sy <= searchR; sy += 2) {
      const candY = startY + sy;
      if (candY - patchSize < 0 || candY + patchSize >= input.height) continue;

      for (let sx = -searchR; sx <= searchR; sx += 2) {
        const candX = startX + sx;
        if (candX - patchSize < 0 || candX + patchSize >= input.width) continue;

        // Compute NCC
        let num = 0;
        let denRef = 0;
        let denCand = 0;

        for (let dy = -patchSize; dy <= patchSize; dy += 2) {
          for (let dx = -patchSize; dx <= patchSize; dx += 2) {
            const refVal = getPixelLuma(input.prevFrameData, startX + dx, startY + dy) - refMean;
            const candVal = getPixelLuma(input.currentFrameData, candX + dx, candY + dy) - refMean;
            num += refVal * candVal;
            denRef += refVal * refVal;
            denCand += candVal * candVal;
          }
        }

        const denom = Math.sqrt(denRef * denCand);
        const ncc = denom > 0.0001 ? num / denom : 0;

        if (ncc > bestScore) {
          bestScore = ncc;
          bestX = candX;
          bestY = candY;
        }
      }
    }

    // Convert NCC score (-1 to 1) to Confidence 0-100
    const confidence = Math.max(0, Math.min(100, Math.round(((bestScore + 1) / 2) * 100)));
    const isTracked = confidence >= confidenceThreshold && bestScore > 0.1;

    const newPoint: TrackPoint = {
      frame: input.frameNumber,
      x: isTracked ? bestX : prevPoint.x,
      y: isTracked ? bestY : prevPoint.y,
      confidence,
      status: isTracked ? 'TRACKED' : 'LOST'
    };

    tracker.trackPoints.push(newPoint);
    
    // Recalculate average confidence
    const totalConf = tracker.trackPoints.reduce((acc, p) => acc + p.confidence, 0);
    tracker.avgConfidence = Math.round(totalConf / tracker.trackPoints.length);
    if (!isTracked && !tracker.isLost) {
      tracker.isLost = true;
      tracker.lostAtFrame = input.frameNumber;
    } else if (isTracked) {
      tracker.isLost = false;
    }

    return newPoint;
  }

  /**
   * Estimates Camera Motion / 2D affine delta (dx, dy) across sequential frames
   */
  public estimateCameraMotion(
    prevFrameData: Uint8ClampedArray,
    currentFrameData: Uint8ClampedArray,
    width: number,
    height: number
  ): { dx: number; dy: number; confidence: number } {
    // Sample 5 distributed grid points
    const sampleGrid = [
      { x: width * 0.25, y: height * 0.25 },
      { x: width * 0.75, y: height * 0.25 },
      { x: width * 0.50, y: height * 0.50 },
      { x: width * 0.25, y: height * 0.75 },
      { x: width * 0.75, y: height * 0.75 }
    ];

    let sumDx = 0;
    let sumDy = 0;
    let validCount = 0;

    for (const pt of sampleGrid) {
      const tracker = this.initializeTracker('grid_pt', { x: pt.x - 16, y: pt.y - 16, width: 32, height: 32 }, 0, 20);
      const res = this.trackFeaturePoint(tracker, {
        prevFrameData,
        currentFrameData,
        width,
        height,
        frameNumber: 1
      }, 35);

      if (res.status === 'TRACKED') {
        sumDx += (res.x - pt.x);
        sumDy += (res.y - pt.y);
        validCount++;
      }
    }

    if (validCount === 0) {
      return { dx: 0, dy: 0, confidence: 0 };
    }

    return {
      dx: sumDx / validCount,
      dy: sumDy / validCount,
      confidence: Math.round((validCount / sampleGrid.length) * 100)
    };
  }
}
