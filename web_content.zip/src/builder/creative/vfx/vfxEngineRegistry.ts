/**
 * GODEX P4.3 — VFX Engine Registry
 * 
 * Manages runtime discovery, hardware capability probing, and execution dispatch
 * for deterministic browser/local DSP engines vs external neural inpainting/matting services.
 * 
 * Truth Invariant:
 * Deterministic Canvas/OffscreenCanvas/DSP transforms are classified as LOCAL_DETERMINISTIC.
 * Real Neural engines (ComfyUI / segment-anything / inpainting) are classified as REAL_ENGINE.
 * Disconnected neural features are classified as REQUIRES_ENGINE (never simulated).
 */

import { VfxTruthClassification } from './vfxTypes';

export interface VfxEngineCapability {
  id: string;
  name: string;
  type: 'LOCAL_CANVAS_DSP' | 'WEBGL_ACCELERATED' | 'WEBGPU_COMPUTE' | 'NEURAL_REMOTE';
  truthClassification: VfxTruthClassification;
  supportedOperations: string[];
  maxResolution: { width: number; height: number };
  maxFps: number;
  available: boolean;
  statusMessage: string;
}

export class VfxEngineRegistry {
  private static instance: VfxEngineRegistry | null = null;
  private engines: Map<string, VfxEngineCapability> = new Map();

  private constructor() {
    this.registerStandardEngines();
  }

  public static getInstance(): VfxEngineRegistry {
    if (!VfxEngineRegistry.instance) {
      VfxEngineRegistry.instance = new VfxEngineRegistry();
    }
    return VfxEngineRegistry.instance;
  }

  private registerStandardEngines(): void {
    // 1. High-Performance Deterministic 2D/Canvas DSP Engine (Always available in standard JS/DOM)
    const isOffscreenSupported = typeof OffscreenCanvas !== 'undefined';
    this.engines.set('vfx-dsp-canvas', {
      id: 'vfx-dsp-canvas',
      name: 'GODEX High-Precision Deterministic DSP Compositor',
      type: 'LOCAL_CANVAS_DSP',
      truthClassification: 'LOCAL_DETERMINISTIC',
      supportedOperations: [
        'CHROMA_KEY',
        'LUMA_KEY',
        'POLYGON_MASK',
        'BEZIER_MASK',
        'ALPHA_COMPOSITING',
        '2D_TRANSFORM',
        'GLOW_BLOOM',
        'VIGNETTE',
        'LENS_DISTORTION',
        'CHROMATIC_ABERRATION',
        'COLOR_GRADING',
        'PARTICLE_SIMULATION',
        'FEATURE_TRACKING_2D',
        'TEMPORAL_CLEAN_PLATE'
      ],
      maxResolution: { width: 3840, height: 2160 },
      maxFps: 60,
      available: true,
      statusMessage: isOffscreenSupported 
        ? 'OffscreenCanvas & TypedArray DSP vectorization active' 
        : 'HTML5 2D Context operational'
    });

    // 2. WebGL 2.0 Shader Accelerator
    let webglAvailable = false;
    try {
      if (typeof document !== 'undefined') {
        const canvas = document.createElement('canvas');
        webglAvailable = !!(canvas.getContext('webgl2') || canvas.getContext('webgl'));
      }
    } catch {
      webglAvailable = false;
    }

    this.engines.set('vfx-webgl-shader', {
      id: 'vfx-webgl-shader',
      name: 'Hardware WebGL 2.0 Shader Pipeline',
      type: 'WEBGL_ACCELERATED',
      truthClassification: 'LOCAL_DETERMINISTIC',
      supportedOperations: [
        'ALPHA_COMPOSITING',
        'COLOR_GRADING',
        'BLOOM_CONVOLUTION',
        'CHROMATIC_ABERRATION',
        'LENS_DISTORTION'
      ],
      maxResolution: { width: 4096, height: 4096 },
      maxFps: 60,
      available: webglAvailable,
      statusMessage: webglAvailable 
        ? 'Hardware GPU GLSL Shader Acceleration Ready' 
        : 'WebGL context unavailable on host environment'
    });

    // 3. WebGPU Compute Shader Engine
    const webgpuAvailable = typeof navigator !== 'undefined' && 'gpu' in navigator && (navigator as any).gpu !== undefined;
    this.engines.set('vfx-webgpu-compute', {
      id: 'vfx-webgpu-compute',
      name: 'WebGPU Native WGSL Compute Matrix',
      type: 'WEBGPU_COMPUTE',
      truthClassification: 'LOCAL_DETERMINISTIC',
      supportedOperations: [
        'OPTICAL_FLOW_MATRIX',
        'FAST_GAUSSIAN_TENSOR',
        'NEURAL_FEATURE_EMBEDDING'
      ],
      maxResolution: { width: 4096, height: 4096 },
      maxFps: 60,
      available: webgpuAvailable,
      statusMessage: webgpuAvailable 
        ? 'WebGPU Compute Core Active' 
        : 'WebGPU unavailable on current browser host'
    });

    // 4. Remote Neural Inpainting & Matting Engine (ComfyUI / SAM)
    this.engines.set('vfx-neural-remote', {
      id: 'vfx-neural-remote',
      name: 'ComfyUI Deep Inpainting & Segment-Anything Bridge',
      type: 'NEURAL_REMOTE',
      truthClassification: 'REAL_ENGINE',
      supportedOperations: [
        'NEURAL_OBJECT_REMOVAL',
        'NEURAL_MATTING_ROTO',
        'DEPTH_MAP_ESTIMATION'
      ],
      maxResolution: { width: 2048, height: 2048 },
      maxFps: 30,
      available: false, // Discovered on connect
      statusMessage: 'Neural endpoint disconnected. Requires local ComfyUI instance.'
    });
  }

  public getEngines(): VfxEngineCapability[] {
    return Array.from(this.engines.values());
  }

  public getEngine(id: string): VfxEngineCapability | undefined {
    return this.engines.get(id);
  }

  public isOperationSupported(op: string): boolean {
    return Array.from(this.engines.values()).some(e => e.available && e.supportedOperations.includes(op));
  }

  public setNeuralEngineAvailability(available: boolean, endpointUrl?: string): void {
    const engine = this.engines.get('vfx-neural-remote');
    if (engine) {
      engine.available = available;
      engine.statusMessage = available
        ? `Connected to local neural VFX worker (${endpointUrl || '127.0.0.1:8188'})`
        : 'Neural endpoint disconnected. Requires local ComfyUI instance.';
    }
  }
}
