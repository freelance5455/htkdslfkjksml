/**
 * GODEX P4.3 — Production VFX Core & Timeline Types
 * 
 * Authoritative data models for professional visual effects, compositing,
 * chroma keying, rotoscoping, motion tracking, object removal, timeline management,
 * and deterministic cinematic effects.
 */

export type VfxTruthClassification =
  | 'REAL_ENGINE'
  | 'LOCAL_DETERMINISTIC'
  | 'SIMULATION'
  | 'UNAVAILABLE'
  | 'REQUIRES_ENGINE'
  | 'NOT_VERIFIED';

export type VfxBlendMode =
  | 'normal'
  | 'multiply'
  | 'screen'
  | 'overlay'
  | 'darken'
  | 'lighten'
  | 'color-dodge'
  | 'color-burn'
  | 'hard-light'
  | 'soft-light'
  | 'difference'
  | 'exclusion'
  | 'hue'
  | 'saturation'
  | 'color'
  | 'luminosity'
  | 'add'
  | 'subtract';

export type KeyingMethod =
  | 'GREEN_SCREEN'
  | 'BLUE_SCREEN'
  | 'COLOR_DIFFERENCE'
  | 'LUMA_KEY'
  | 'DELTA_CHROMA';

export interface KeyingParameters {
  method: KeyingMethod;
  keyColor: string; // Hex or rgb
  tolerance: number; // 0 - 100
  smoothness: number; // 0 - 100
  edgeChoke: number; // -50 to +50 px
  feather: number; // 0 - 50 px
  spillSuppression: number; // 0 - 100
  shadowPreservation: number; // 0 - 100
  clipBlack: number; // 0 - 100
  clipWhite: number; // 0 - 100
  despillHue: 'NEUTRAL' | 'BACKGROUND_MATCH' | 'WARM';
}

export interface MaskPoint {
  x: number;
  y: number;
  handleIn?: { x: number; y: number };
  handleOut?: { x: number; y: number };
}

export type MaskShapeType = 'POLYGON' | 'BEZIER' | 'RECTANGLE' | 'ELLIPSE' | 'FREEHAND';
export type MaskMode = 'ADD' | 'SUBTRACT' | 'INTERSECT' | 'DIFFERENCE';

export interface VfxMask {
  id: string;
  name: string;
  enabled: boolean;
  inverted: boolean;
  mode: MaskMode;
  shapeType: MaskShapeType;
  points: MaskPoint[];
  opacity: number; // 0 - 1
  feather: number; // 0 - 100 px
  expansion: number; // -100 to +100 px
  keyframed: boolean;
}

export interface TrackPoint {
  frame: number;
  x: number;
  y: number;
  confidence: number; // 0 - 100
  status: 'TRACKED' | 'LOST' | 'OCCLUDED' | 'INTERPOLATED';
}

export interface MotionTrackingData {
  id: string;
  name: string;
  targetRegion: { x: number; y: number; width: number; height: number };
  searchRadius: number;
  trackPoints: TrackPoint[];
  avgConfidence: number;
  isLost: boolean;
  lostAtFrame?: number;
  trackingType: 'POINT' | 'OBJECT_BOX' | 'PLANAR' | 'CAMERA_MOTION';
}

export interface ObjectRemovalParameters {
  mode: 'TEMPORAL_CLEAN_PLATE' | 'SPATIAL_PATCH_MATCH' | 'NEURAL_INPAINTING';
  maskId: string;
  sampleFrameRadius: number; // e.g. 5 frames before/after
  feather: number;
  blendEdge: boolean;
  useNeuralIfAvailable: boolean;
}

export interface CinematicVfxParameters {
  // Glow & Bloom
  glowEnabled: boolean;
  glowThreshold: number; // 0 - 1
  glowIntensity: number; // 0 - 5
  glowRadius: number; // 0 - 100 px
  glowColor?: string;

  // Vignette
  vignetteEnabled: boolean;
  vignetteAmount: number; // 0 - 1
  vignetteFeather: number; // 0 - 1
  vignetteRoundness: number; // 0 - 1

  // Lens & Optics
  lensDistortionEnabled: boolean;
  distortionK1: number; // -1 to +1 (barrel / pincushion)
  chromaticAberrationEnabled: boolean;
  aberrationOffsetPx: number; // 0 - 20 px
  
  // Motion Blur
  motionBlurEnabled: boolean;
  shutterAngle: number; // 0 - 360 deg
  motionSamples: number; // 2 - 16

  // Color Grading
  colorGradingEnabled: boolean;
  temperature: number; // -100 to +100
  tint: number; // -100 to +100
  exposure: number; // -5 to +5 EV
  contrast: number; // -100 to +100
  saturation: number; // -100 to +100
  lift: { r: number; g: number; b: number }; // Shadows
  gamma: { r: number; g: number; b: number }; // Midtones
  gain: { r: number; g: number; b: number }; // Highlights

  // Depth-based haze (requires depth map)
  depthHazeEnabled: boolean;
  hazeDensity: number; // 0 - 1
  hazeColor: string;
  hazeStartDepth: number; // 0 - 1
}

export interface ParticleSystemParameters {
  enabled: boolean;
  preset: 'EMBERS' | 'SPARKS' | 'DUST' | 'RAIN' | 'SNOW' | 'BOKEH_ORBS';
  particleCount: number; // 10 - 500
  speed: number;
  directionDeg: number;
  gravity: number;
  turbulence: number;
  sizeMin: number;
  sizeMax: number;
  lifetimeSec: number;
  colorStart: string;
  colorEnd: string;
  blendMode: VfxBlendMode;
}

export interface VfxTransform {
  position: { x: number; y: number };
  scale: { x: number; y: number };
  rotationDeg: number;
  anchorPoint: { x: number; y: number };
  opacity: number; // 0 - 1
}

export type KeyframeInterpolation = 'LINEAR' | 'EASE_IN' | 'EASE_OUT' | 'EASE_IN_OUT' | 'BEZIER' | 'HOLD';

export interface VfxKeyframe<T = any> {
  id: string;
  frame: number;
  value: T;
  interpolation: KeyframeInterpolation;
}

export interface VfxAnimatableProperty<T = any> {
  property: string;
  currentValue: T;
  keyframes: VfxKeyframe<T>[];
}

export type VfxLayerType = 
  | 'VIDEO'
  | 'IMAGE'
  | 'SOLID_COLOR'
  | 'ADJUSTMENT'
  | 'MASK'
  | 'PARTICLES'
  | 'TEXT_TITLE'
  | 'CAMERA_TRACK';

export interface VfxLayer {
  id: string;
  name: string;
  type: VfxLayerType;
  visible: boolean;
  locked: boolean;
  solo: boolean;
  startFrame: number;
  durationFrames: number;
  sourceUrl?: string;
  sourceAssetId?: string;
  dimensions: { width: number; height: number };
  transform: VfxTransform;
  blendMode: VfxBlendMode;
  keying?: KeyingParameters;
  masks: VfxMask[];
  effects: CinematicVfxParameters;
  particles?: ParticleSystemParameters;
  trackingData?: MotionTrackingData[];
  objectRemoval?: ObjectRemovalParameters;
  animatedProperties: Record<string, VfxAnimatableProperty>;
  meta?: Record<string, any>;
}

export interface VfxTimelineTrack {
  id: string;
  name: string;
  type: 'VIDEO' | 'VFX' | 'AUDIO' | 'MASK';
  muted: boolean;
  locked: boolean;
  layers: VfxLayer[];
}

export interface VfxTimeline {
  id: string;
  name: string;
  fps: number; // 24, 25, 30, 60
  totalFrames: number;
  currentFrame: number;
  resolution: { width: number; height: number };
  tracks: VfxTimelineTrack[];
  inPointFrame: number;
  outPointFrame: number;
  isPlaying: boolean;
  loop: boolean;
}

export interface VfxQualityMetrics {
  alphaEdgeSharpness: number; // 0 - 100
  spillLeakageScore: number; // 0 - 100 (lower is better)
  contrastRatio: number;
  signalToNoiseRatioDb: number;
  motionTrackingConfidence: number; // 0 - 100
  matteIntegrityScore: number; // 0 - 100
  overallVfxQualityScore: number; // 0 - 100
}

export interface VfxExecutionEvidence {
  executionId: string;
  timestamp: number;
  operation: string;
  engineId: string;
  engineName: string;
  truthClassification: VfxTruthClassification;
  durationMs: number;
  inputDimensions: { width: number; height: number };
  outputDimensions: { width: number; height: number };
  qualityMetrics: VfxQualityMetrics;
  parametersApplied: Record<string, any>;
  logs: string[];
  warnings: string[];
  requiresEngineReason?: string;
  isVerified: boolean;
}

export interface VfxProcessingJob {
  jobId: string;
  name: string;
  targetTimelineId: string;
  frameRange: { start: number; end: number };
  layersToRender: string[];
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED' | 'REQUIRES_ENGINE';
  progressPercent: number;
  currentFrame: number;
  totalFrames: number;
  evidence?: VfxExecutionEvidence;
  error?: string;
}
