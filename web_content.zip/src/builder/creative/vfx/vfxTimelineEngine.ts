/**
 * GODEX P4.3 — Unified VFX Timeline Engine
 * 
 * Timeline model, multi-track orchestration (Video, VFX, Masks, Audio),
 * keyframe animation & interpolation, non-destructive undo/redo history,
 * and frame range management.
 */

import {
  VfxTimeline,
  VfxTimelineTrack,
  VfxLayer,
  VfxKeyframe,
  KeyframeInterpolation,
  VfxTransform
} from './vfxTypes';
import { ParticleEffectsEngine } from './particleEffectsEngine';

export class VfxTimelineEngine {
  private static instance: VfxTimelineEngine | null = null;
  private currentTimeline: VfxTimeline | null = null;
  private historyStack: VfxTimeline[] = [];
  private redoStack: VfxTimeline[] = [];

  public static getInstance(): VfxTimelineEngine {
    if (!VfxTimelineEngine.instance) {
      VfxTimelineEngine.instance = new VfxTimelineEngine();
    }
    return VfxTimelineEngine.instance;
  }

  /**
   * Create a fresh empty professional VFX timeline
   */
  public createTimeline(
    name: string = 'GODEX Master VFX Sequence',
    fps: number = 24,
    totalFrames: number = 120,
    resolution: { width: number; height: number } = { width: 1920, height: 1080 }
  ): VfxTimeline {
    const videoTrack: VfxTimelineTrack = {
      id: 'track-video-main',
      name: 'Video 1 (Background)',
      type: 'VIDEO',
      muted: false,
      locked: false,
      layers: []
    };

    const vfxTrack: VfxTimelineTrack = {
      id: 'track-vfx-foreground',
      name: 'VFX 1 (Foreground & Keys)',
      type: 'VFX',
      muted: false,
      locked: false,
      layers: []
    };

    const maskTrack: VfxTimelineTrack = {
      id: 'track-masks',
      name: 'Masks & Rotoscoping',
      type: 'MASK',
      muted: false,
      locked: false,
      layers: []
    };

    const audioTrack: VfxTimelineTrack = {
      id: 'track-audio-master',
      name: 'Audio 1 (Master Mix)',
      type: 'AUDIO',
      muted: false,
      locked: false,
      layers: []
    };

    const timeline: VfxTimeline = {
      id: `timeline-${Date.now()}`,
      name,
      fps,
      totalFrames,
      currentFrame: 0,
      resolution,
      tracks: [vfxTrack, videoTrack, maskTrack, audioTrack],
      inPointFrame: 0,
      outPointFrame: totalFrames - 1,
      isPlaying: false,
      loop: true
    };

    this.currentTimeline = timeline;
    this.historyStack = [JSON.parse(JSON.stringify(timeline))];
    this.redoStack = [];
    return timeline;
  }

  public getTimeline(): VfxTimeline {
    if (!this.currentTimeline) {
      return this.createTimeline();
    }
    return this.currentTimeline;
  }

  public setTimeline(timeline: VfxTimeline): void {
    this.saveHistory();
    this.currentTimeline = timeline;
  }

  /**
   * Add layer to specific track
   */
  public addLayer(trackId: string, layer: Partial<VfxLayer>): VfxLayer {
    this.saveHistory();
    const timeline = this.getTimeline();
    const track = timeline.tracks.find(t => t.id === trackId) || timeline.tracks[0];

    const effectsEngine = ParticleEffectsEngine.getInstance();

    const fullLayer: VfxLayer = {
      id: layer.id || `layer-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: layer.name || 'New Layer',
      type: layer.type || 'IMAGE',
      visible: layer.visible !== undefined ? layer.visible : true,
      locked: !!layer.locked,
      solo: !!layer.solo,
      startFrame: layer.startFrame !== undefined ? layer.startFrame : 0,
      durationFrames: layer.durationFrames || timeline.totalFrames,
      sourceUrl: layer.sourceUrl,
      sourceAssetId: layer.sourceAssetId,
      dimensions: layer.dimensions || { ...timeline.resolution },
      transform: layer.transform || {
        position: { x: timeline.resolution.width / 2, y: timeline.resolution.height / 2 },
        scale: { x: 1, y: 1 },
        rotationDeg: 0,
        anchorPoint: { x: (layer.dimensions?.width || timeline.resolution.width) / 2, y: (layer.dimensions?.height || timeline.resolution.height) / 2 },
        opacity: 1
      },
      blendMode: layer.blendMode || 'normal',
      keying: layer.keying,
      masks: layer.masks || [],
      effects: layer.effects || effectsEngine.getDefaultEffects(),
      particles: layer.particles,
      trackingData: layer.trackingData,
      objectRemoval: layer.objectRemoval,
      animatedProperties: layer.animatedProperties || {},
      meta: layer.meta || {}
    };

    track.layers.push(fullLayer);
    return fullLayer;
  }

  public removeLayer(layerId: string): boolean {
    this.saveHistory();
    const timeline = this.getTimeline();
    let removed = false;
    for (const track of timeline.tracks) {
      const idx = track.layers.findIndex(l => l.id === layerId);
      if (idx >= 0) {
        track.layers.splice(idx, 1);
        removed = true;
        break;
      }
    }
    return removed;
  }

  public updateLayer(layerId: string, updates: Partial<VfxLayer>): VfxLayer | null {
    this.saveHistory();
    const timeline = this.getTimeline();
    for (const track of timeline.tracks) {
      const layer = track.layers.find(l => l.id === layerId);
      if (layer) {
        Object.assign(layer, updates);
        return layer;
      }
    }
    return null;
  }

  public getAllLayers(): VfxLayer[] {
    const timeline = this.getTimeline();
    const all: VfxLayer[] = [];
    for (const track of timeline.tracks) {
      if (!track.muted) {
        all.push(...track.layers);
      }
    }
    return all;
  }

  /**
   * Keyframe Interpolation for dynamic animated properties
   */
  public interpolateValue<T = any>(
    keyframes: VfxKeyframe<T>[],
    frame: number,
    defaultValue: T
  ): T {
    if (!keyframes || keyframes.length === 0) return defaultValue;
    if (keyframes.length === 1) return keyframes[0].value;

    const sorted = [...keyframes].sort((a, b) => a.frame - b.frame);
    if (frame <= sorted[0].frame) return sorted[0].value;
    if (frame >= sorted[sorted.length - 1].frame) return sorted[sorted.length - 1].value;

    let prev = sorted[0];
    let next = sorted[1];
    for (let i = 0; i < sorted.length - 1; i++) {
      if (frame >= sorted[i].frame && frame <= sorted[i + 1].frame) {
        prev = sorted[i];
        next = sorted[i + 1];
        break;
      }
    }

    if (prev.frame === next.frame) return prev.value;

    const t = (frame - prev.frame) / (next.frame - prev.frame);
    const easedT = this.applyEasing(t, prev.interpolation);

    if (typeof prev.value === 'number' && typeof next.value === 'number') {
      return ((prev.value as number) + ((next.value as number) - (prev.value as number)) * easedT) as unknown as T;
    }

    if (typeof prev.value === 'object' && prev.value !== null && typeof next.value === 'object' && next.value !== null) {
      const res: any = Array.isArray(prev.value) ? [] : {};
      for (const k of Object.keys(prev.value)) {
        const valA = (prev.value as any)[k];
        const valB = (next.value as any)[k];
        if (typeof valA === 'number' && typeof valB === 'number') {
          res[k] = valA + (valB - valA) * easedT;
        } else {
          res[k] = easedT > 0.5 ? valB : valA;
        }
      }
      return res as T;
    }

    return easedT > 0.5 ? next.value : prev.value;
  }

  private applyEasing(t: number, mode: KeyframeInterpolation): number {
    switch (mode) {
      case 'EASE_IN':
        return t * t;
      case 'EASE_OUT':
        return t * (2 - t);
      case 'EASE_IN_OUT':
      case 'BEZIER':
        return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
      case 'HOLD':
        return 0;
      case 'LINEAR':
      default:
        return t;
    }
  }

  /**
   * Evaluates transformed layer properties at a specific target frame
   */
  public evaluateLayerAtFrame(layer: VfxLayer, frame: number): VfxLayer {
    const evaluated = { ...layer };
    if (layer.animatedProperties) {
      if (layer.animatedProperties.opacity) {
        evaluated.transform = {
          ...evaluated.transform,
          opacity: this.interpolateValue(
            layer.animatedProperties.opacity.keyframes,
            frame,
            layer.transform.opacity
          )
        };
      }
      if (layer.animatedProperties.position) {
        evaluated.transform = {
          ...evaluated.transform,
          position: this.interpolateValue(
            layer.animatedProperties.position.keyframes,
            frame,
            layer.transform.position
          )
        };
      }
      if (layer.animatedProperties.scale) {
        evaluated.transform = {
          ...evaluated.transform,
          scale: this.interpolateValue(
            layer.animatedProperties.scale.keyframes,
            frame,
            layer.transform.scale
          )
        };
      }
      if (layer.animatedProperties.rotation) {
        evaluated.transform = {
          ...evaluated.transform,
          rotationDeg: this.interpolateValue(
            layer.animatedProperties.rotation.keyframes,
            frame,
            layer.transform.rotationDeg
          )
        };
      }
    }
    return evaluated;
  }

  // Non-destructive Undo / Redo History
  private saveHistory(): void {
    if (this.currentTimeline) {
      this.historyStack.push(JSON.parse(JSON.stringify(this.currentTimeline)));
      if (this.historyStack.length > 50) this.historyStack.shift();
      this.redoStack = [];
    }
  }

  public undo(): boolean {
    if (this.historyStack.length > 1) {
      const current = this.historyStack.pop();
      if (current) this.redoStack.push(current);
      const prev = this.historyStack[this.historyStack.length - 1];
      if (prev) {
        this.currentTimeline = JSON.parse(JSON.stringify(prev));
        return true;
      }
    }
    return false;
  }

  public redo(): boolean {
    if (this.redoStack.length > 0) {
      const next = this.redoStack.pop();
      if (next) {
        this.historyStack.push(JSON.parse(JSON.stringify(next)));
        this.currentTimeline = JSON.parse(JSON.stringify(next));
        return true;
      }
    }
    return false;
  }
}
