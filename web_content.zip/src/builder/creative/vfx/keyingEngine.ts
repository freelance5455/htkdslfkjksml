/**
 * GODEX P4.3 — Keying Engine
 * 
 * High-performance deterministic chroma keying, luma keying, despill suppression,
 * edge refinement (erosion, dilation, Gaussian feathering), and alpha matte integrity analysis.
 */

import { KeyingParameters, KeyingMethod } from './vfxTypes';

export interface KeyingExecutionResult {
  alphaData: Uint8ClampedArray; // Extracted alpha mask (0-255 per pixel)
  despilledData?: Uint8ClampedArray; // RGB with spill suppressed
  metrics: {
    meanAlpha: number;
    opaqueRatio: number;
    transparentRatio: number;
    edgeFringeScore: number;
    spillSuppressedRatio: number;
  };
  durationMs: number;
}

export class KeyingEngine {
  private static instance: KeyingEngine | null = null;

  public static getInstance(): KeyingEngine {
    if (!KeyingEngine.instance) {
      KeyingEngine.instance = new KeyingEngine();
    }
    return KeyingEngine.instance;
  }

  /**
   * Default production keying parameters
   */
  public getDefaultParameters(method: KeyingMethod = 'GREEN_SCREEN'): KeyingParameters {
    return {
      method,
      keyColor: method === 'BLUE_SCREEN' ? '#0000FF' : '#00FF00',
      tolerance: 40,
      smoothness: 15,
      edgeChoke: 0,
      feather: 2,
      spillSuppression: 75,
      shadowPreservation: 20,
      clipBlack: 10,
      clipWhite: 90,
      despillHue: 'NEUTRAL'
    };
  }

  /**
   * Parse hex or rgb color to RGB tuple
   */
  public parseColor(colorStr: string): { r: number; g: number; b: number } {
    if (colorStr.startsWith('#')) {
      const hex = colorStr.replace('#', '');
      if (hex.length === 3) {
        return {
          r: parseInt(hex[0] + hex[0], 16),
          g: parseInt(hex[1] + hex[1], 16),
          b: parseInt(hex[2] + hex[2], 16)
        };
      }
      return {
        r: parseInt(hex.substring(0, 2), 16) || 0,
        g: parseInt(hex.substring(2, 4), 16) || 0,
        b: parseInt(hex.substring(4, 6), 16) || 0
      };
    }
    const match = colorStr.match(/\d+/g);
    if (match && match.length >= 3) {
      return {
        r: Number(match[0]),
        g: Number(match[1]),
        b: Number(match[2])
      };
    }
    return { r: 0, g: 255, b: 0 }; // Default green
  }

  /**
   * Performs pixel-level chroma extraction on RGBA pixel array.
   */
  public processKeying(
    rgbaData: Uint8ClampedArray,
    width: number,
    height: number,
    params: KeyingParameters
  ): KeyingExecutionResult {
    const startTime = performance.now();
    const pixelCount = width * height;
    const alphaData = new Uint8ClampedArray(pixelCount);
    const despilledData = new Uint8ClampedArray(rgbaData.length);
    despilledData.set(rgbaData);

    const keyRgb = this.parseColor(params.keyColor);
    const isGreen = params.method === 'GREEN_SCREEN' || (keyRgb.g > keyRgb.r && keyRgb.g > keyRgb.b);
    const isBlue = params.method === 'BLUE_SCREEN' || (keyRgb.b > keyRgb.r && keyRgb.b > keyRgb.g);

    const tolerance = Math.max(0.01, params.tolerance / 100);
    const smoothness = Math.max(0.01, params.smoothness / 100);
    const spillFactor = params.spillSuppression / 100;
    const clipBlack = params.clipBlack / 100;
    const clipWhite = Math.max(clipBlack + 0.05, params.clipWhite / 100);

    let totalAlpha = 0;
    let opaquePixels = 0;
    let transparentPixels = 0;
    let spillPixelsSuppressed = 0;

    for (let i = 0; i < pixelCount; i++) {
      const idx = i * 4;
      const r = rgbaData[idx];
      const g = rgbaData[idx + 1];
      const b = rgbaData[idx + 2];
      const srcAlpha = rgbaData[idx + 3] / 255;

      let keyDiff = 0;
      if (params.method === 'LUMA_KEY') {
        // Luminance keying: Y = 0.299R + 0.587G + 0.114B
        const luma = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        const targetLuma = (0.299 * keyRgb.r + 0.587 * keyRgb.g + 0.114 * keyRgb.b) / 255;
        keyDiff = Math.abs(luma - targetLuma);
      } else if (isGreen) {
        // Industry-standard Color Difference Green Key:
        // Key signal = max(0, G - max(R, B))
        const maxOther = Math.max(r, b);
        const greenDiff = (g - maxOther) / 255;
        keyDiff = Math.max(0, greenDiff);
      } else if (isBlue) {
        // Color Difference Blue Key:
        const maxOther = Math.max(r, g);
        const blueDiff = (b - maxOther) / 255;
        keyDiff = Math.max(0, blueDiff);
      } else {
        // Euclidean RGB distance key
        const dr = (r - keyRgb.r) / 255;
        const dg = (g - keyRgb.g) / 255;
        const db = (b - keyRgb.b) / 255;
        const dist = Math.sqrt(dr * dr + dg * dg + db * db) / 1.732; // Normalised to 0-1
        keyDiff = 1 - dist;
      }

      // Compute raw alpha from difference & tolerance
      let rawAlpha = 1.0;
      if (keyDiff > tolerance) {
        rawAlpha = 0.0;
      } else if (keyDiff > (tolerance - smoothness)) {
        // Smooth transition zone
        const t = (keyDiff - (tolerance - smoothness)) / smoothness;
        rawAlpha = 1.0 - t;
      }

      // Clip Black & Clip White levels
      if (rawAlpha < clipBlack) {
        rawAlpha = 0;
      } else if (rawAlpha > clipWhite) {
        rawAlpha = 1;
      } else {
        rawAlpha = (rawAlpha - clipBlack) / (clipWhite - clipBlack);
      }

      // Preserve shadows
      if (params.shadowPreservation > 0 && rawAlpha < 1.0) {
        const luma = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        if (luma < 0.3) {
          const shadowBoost = ((0.3 - luma) / 0.3) * (params.shadowPreservation / 100);
          rawAlpha = Math.min(1.0, rawAlpha + shadowBoost * 0.5);
        }
      }

      const finalAlpha = Math.round(Math.min(1, Math.max(0, rawAlpha * srcAlpha)) * 255);
      alphaData[i] = finalAlpha;

      totalAlpha += finalAlpha;
      if (finalAlpha === 255) opaquePixels++;
      if (finalAlpha === 0) transparentPixels++;

      // Despill Algorithm
      if (spillFactor > 0) {
        if (isGreen && g > Math.max(r, b)) {
          const maxRB = Math.max(r, b);
          const excess = g - maxRB;
          const adjustedG = Math.round(g - excess * spillFactor);
          despilledData[idx + 1] = Math.max(0, adjustedG);

          if (params.despillHue === 'BACKGROUND_MATCH') {
            despilledData[idx] = Math.min(255, Math.round(r + excess * 0.2 * spillFactor));
            despilledData[idx + 2] = Math.min(255, Math.round(b + excess * 0.2 * spillFactor));
          }
          spillPixelsSuppressed++;
        } else if (isBlue && b > Math.max(r, g)) {
          const maxRG = Math.max(r, g);
          const excess = b - maxRG;
          const adjustedB = Math.round(b - excess * spillFactor);
          despilledData[idx + 2] = Math.max(0, adjustedB);
          spillPixelsSuppressed++;
        }
      }
      despilledData[idx + 3] = finalAlpha;
    }

    // Apply Edge Choke (Erode/Dilate) if requested
    let refinedAlpha = alphaData;
    if (params.edgeChoke !== 0) {
      refinedAlpha = this.applyMorphology(refinedAlpha, width, height, params.edgeChoke);
    }

    // Apply Feathering (Gaussian Blur on Alpha channel)
    if (params.feather > 0) {
      refinedAlpha = this.applyFeather(refinedAlpha, width, height, params.feather);
    }

    // Update final despilled alpha channel with refined alpha
    for (let i = 0; i < pixelCount; i++) {
      despilledData[i * 4 + 3] = refinedAlpha[i];
    }

    const durationMs = performance.now() - startTime;

    return {
      alphaData: refinedAlpha,
      despilledData,
      metrics: {
        meanAlpha: Math.round((totalAlpha / (pixelCount * 255)) * 100),
        opaqueRatio: Math.round((opaquePixels / pixelCount) * 100),
        transparentRatio: Math.round((transparentPixels / pixelCount) * 100),
        edgeFringeScore: Math.round((1 - (opaquePixels + transparentPixels) / pixelCount) * 100),
        spillSuppressedRatio: Math.round((spillPixelsSuppressed / pixelCount) * 100)
      },
      durationMs: Math.round(durationMs * 100) / 100
    };
  }

  /**
   * Morphological Erosion (negative choke) or Dilation (positive choke)
   */
  public applyMorphology(
    alpha: Uint8ClampedArray,
    width: number,
    height: number,
    radiusPx: number
  ): Uint8ClampedArray {
    const output = new Uint8ClampedArray(alpha.length);
    const r = Math.min(10, Math.abs(Math.round(radiusPx)));
    const isErode = radiusPx < 0;

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        let extreme = isErode ? 255 : 0;
        for (let dy = -r; dy <= r; dy++) {
          const py = Math.min(height - 1, Math.max(0, y + dy));
          for (let dx = -r; dx <= r; dx++) {
            const px = Math.min(width - 1, Math.max(0, x + dx));
            const val = alpha[py * width + px];
            if (isErode) {
              if (val < extreme) extreme = val;
            } else {
              if (val > extreme) extreme = val;
            }
          }
        }
        output[y * width + x] = extreme;
      }
    }
    return output;
  }

  /**
   * Fast Separable Box/Gaussian Blur for Alpha Feathering
   */
  public applyFeather(
    alpha: Uint8ClampedArray,
    width: number,
    height: number,
    featherRadius: number
  ): Uint8ClampedArray {
    const radius = Math.min(25, Math.max(1, Math.round(featherRadius)));
    const temp = new Float32Array(alpha.length);
    const output = new Uint8ClampedArray(alpha.length);

    // Horizontal pass
    for (let y = 0; y < height; y++) {
      let sum = 0;
      let count = 0;
      const rowOffset = y * width;

      for (let x = -radius; x <= radius; x++) {
        const px = Math.min(width - 1, Math.max(0, x));
        sum += alpha[rowOffset + px];
        count++;
      }

      for (let x = 0; x < width; x++) {
        temp[rowOffset + x] = sum / count;
        const removePx = Math.max(0, x - radius);
        const addPx = Math.min(width - 1, x + radius + 1);
        sum += alpha[rowOffset + addPx] - alpha[rowOffset + removePx];
      }
    }

    // Vertical pass
    for (let x = 0; x < width; x++) {
      let sum = 0;
      let count = 0;

      for (let y = -radius; y <= radius; y++) {
        const py = Math.min(height - 1, Math.max(0, y));
        sum += temp[py * width + x];
        count++;
      }

      for (let y = 0; y < height; y++) {
        output[y * width + x] = Math.round(sum / count);
        const removePy = Math.max(0, y - radius);
        const addPy = Math.min(height - 1, y + radius + 1);
        sum += temp[addPy * width + x] - temp[removePy * width + x];
      }
    }

    return output;
  }
}
