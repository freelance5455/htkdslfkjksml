/**
 * GODEX P4.3 — Particle & Cinematic Effects Engine
 * 
 * High-performance deterministic DSP effects:
 * Glow, Bloom, Vignette, Lens Distortion, Chromatic Aberration,
 * Motion Blur, 3-Way Color Wheels, Depth-based Fog, and Procedural Particles.
 */

import { CinematicVfxParameters, ParticleSystemParameters, VfxBlendMode } from './vfxTypes';

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  life: number;
  maxLife: number;
  color: string;
  alpha: number;
}

export class ParticleEffectsEngine {
  private static instance: ParticleEffectsEngine | null = null;
  private particlePool: Map<string, Particle[]> = new Map();

  public static getInstance(): ParticleEffectsEngine {
    if (!ParticleEffectsEngine.instance) {
      ParticleEffectsEngine.instance = new ParticleEffectsEngine();
    }
    return ParticleEffectsEngine.instance;
  }

  public getDefaultEffects(): CinematicVfxParameters {
    return {
      glowEnabled: false,
      glowThreshold: 0.7,
      glowIntensity: 1.5,
      glowRadius: 20,
      vignetteEnabled: false,
      vignetteAmount: 0.4,
      vignetteFeather: 0.5,
      vignetteRoundness: 0.8,
      lensDistortionEnabled: false,
      distortionK1: 0.05,
      chromaticAberrationEnabled: false,
      aberrationOffsetPx: 4,
      motionBlurEnabled: false,
      shutterAngle: 180,
      motionSamples: 6,
      colorGradingEnabled: false,
      temperature: 0,
      tint: 0,
      exposure: 0,
      contrast: 0,
      saturation: 0,
      lift: { r: 0, g: 0, b: 0 },
      gamma: { r: 0, g: 0, b: 0 },
      gain: { r: 0, g: 0, b: 0 },
      depthHazeEnabled: false,
      hazeDensity: 0.5,
      hazeColor: '#6080A0',
      hazeStartDepth: 0.3
    };
  }

  /**
   * Apply entire chain of deterministic cinematic effects
   */
  public applyCinematicEffects(
    rgbaData: Uint8ClampedArray,
    width: number,
    height: number,
    params: CinematicVfxParameters,
    depthMapData?: Uint8ClampedArray
  ): Uint8ClampedArray {
    let result = new Uint8ClampedArray(rgbaData.length);
    result.set(rgbaData);

    // 1. Color Grading & 3-Way Color Wheels
    if (params.colorGradingEnabled) {
      result = this.applyColorGrading(result, width, height, params);
    }

    // 2. Depth Haze / Atmospheric Fog
    if (params.depthHazeEnabled && depthMapData) {
      result = this.applyDepthHaze(result, depthMapData, width, height, params);
    }

    // 3. Glow & Bloom
    if (params.glowEnabled && params.glowIntensity > 0) {
      result = this.applyGlowBloom(result, width, height, params.glowThreshold, params.glowIntensity, params.glowRadius);
    }

    // 4. Chromatic Aberration
    if (params.chromaticAberrationEnabled && params.aberrationOffsetPx > 0) {
      result = this.applyChromaticAberration(result, width, height, params.aberrationOffsetPx);
    }

    // 5. Lens Distortion (Barrel / Pincushion)
    if (params.lensDistortionEnabled && Math.abs(params.distortionK1) > 0.001) {
      result = this.applyLensDistortion(result, width, height, params.distortionK1);
    }

    // 6. Vignette
    if (params.vignetteEnabled && params.vignetteAmount > 0) {
      result = this.applyVignette(result, width, height, params.vignetteAmount, params.vignetteFeather, params.vignetteRoundness);
    }

    return result;
  }

  /**
   * Color Grading with Color Temperature, Tint, Lift/Gamma/Gain, Contrast, Saturation
   */
  public applyColorGrading(
    data: Uint8ClampedArray,
    width: number,
    height: number,
    params: CinematicVfxParameters
  ): Uint8ClampedArray {
    const output = new Uint8ClampedArray(data.length);
    const tempK = params.temperature / 100;
    const tintK = params.tint / 100;
    const expK = Math.pow(2, params.exposure);
    const contrastK = (params.contrast + 100) / 100;
    const satK = (params.saturation + 100) / 100;

    const liftR = params.lift.r / 100;
    const liftG = params.lift.g / 100;
    const liftB = params.lift.b / 100;

    const gainR = 1 + params.gain.r / 100;
    const gainG = 1 + params.gain.g / 100;
    const gainB = 1 + params.gain.b / 100;

    const len = data.length;
    for (let i = 0; i < len; i += 4) {
      let r = data[i] / 255;
      let g = data[i + 1] / 255;
      let b = data[i + 2] / 255;
      const a = data[i + 3];

      // Exposure
      r *= expK;
      g *= expK;
      b *= expK;

      // Color Temp & Tint
      r += tempK * 0.15;
      b -= tempK * 0.15;
      g += tintK * 0.15;

      // Lift / Gain (Shadows / Highlights)
      r = r * gainR + liftR;
      g = g * gainG + liftG;
      b = b * gainB + liftB;

      // Contrast around midpoint 0.5
      r = (r - 0.5) * contrastK + 0.5;
      g = (g - 0.5) * contrastK + 0.5;
      b = (b - 0.5) * contrastK + 0.5;

      // Saturation
      const luma = 0.299 * r + 0.587 * g + 0.114 * b;
      r = luma + (r - luma) * satK;
      g = luma + (g - luma) * satK;
      b = luma + (b - luma) * satK;

      output[i] = Math.max(0, Math.min(255, Math.round(r * 255)));
      output[i + 1] = Math.max(0, Math.min(255, Math.round(g * 255)));
      output[i + 2] = Math.max(0, Math.min(255, Math.round(b * 255)));
      output[i + 3] = a;
    }

    return output;
  }

  /**
   * Glow & Bloom (Threshold extraction + Gaussian Blur + Additive synthesis)
   */
  public applyGlowBloom(
    data: Uint8ClampedArray,
    width: number,
    height: number,
    threshold: number,
    intensity: number,
    radius: number
  ): Uint8ClampedArray {
    const pixelCount = width * height;
    const threshData = new Uint8ClampedArray(data.length);

    // Extract highlight pixels above threshold
    for (let i = 0; i < pixelCount; i++) {
      const idx = i * 4;
      const r = data[idx] / 255;
      const g = data[idx + 1] / 255;
      const b = data[idx + 2] / 255;
      const luma = 0.299 * r + 0.587 * g + 0.114 * b;

      if (luma > threshold) {
        const excess = (luma - threshold) / (1 - threshold);
        threshData[idx] = Math.round(data[idx] * excess);
        threshData[idx + 1] = Math.round(data[idx + 1] * excess);
        threshData[idx + 2] = Math.round(data[idx + 2] * excess);
        threshData[idx + 3] = 255;
      }
    }

    // Box blur the extracted highlights
    const blurred = this.blurRgba(threshData, width, height, Math.max(2, Math.min(40, radius)));
    const output = new Uint8ClampedArray(data.length);

    // Add blurred highlights to original
    for (let i = 0; i < pixelCount; i++) {
      const idx = i * 4;
      output[idx] = Math.min(255, data[idx] + Math.round(blurred[idx] * intensity));
      output[idx + 1] = Math.min(255, data[idx + 1] + Math.round(blurred[idx + 1] * intensity));
      output[idx + 2] = Math.min(255, data[idx + 2] + Math.round(blurred[idx + 2] * intensity));
      output[idx + 3] = data[idx + 3];
    }

    return output;
  }

  /**
   * Chromatic Aberration (Radial RGB channel displacement)
   */
  public applyChromaticAberration(
    data: Uint8ClampedArray,
    width: number,
    height: number,
    offsetPx: number
  ): Uint8ClampedArray {
    const output = new Uint8ClampedArray(data.length);
    const cx = width / 2;
    const cy = height / 2;
    const maxDist = Math.sqrt(cx * cx + cy * cy);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = (y * width + x) * 4;
        const dx = (x - cx) / maxDist;
        const dy = (y - cy) / maxDist;

        // Red shifted outward
        const rx = Math.min(width - 1, Math.max(0, Math.round(x + dx * offsetPx)));
        const ry = Math.min(height - 1, Math.max(0, Math.round(y + dy * offsetPx)));
        const rIdx = (ry * width + rx) * 4;

        // Blue shifted inward
        const bx = Math.min(width - 1, Math.max(0, Math.round(x - dx * offsetPx)));
        const by = Math.min(height - 1, Math.max(0, Math.round(y - dy * offsetPx)));
        const bIdx = (by * width + bx) * 4;

        output[idx] = data[rIdx]; // Red from outward
        output[idx + 1] = data[idx + 1]; // Green centered
        output[idx + 2] = data[bIdx + 2]; // Blue from inward
        output[idx + 3] = data[idx + 3];
      }
    }

    return output;
  }

  /**
   * Lens Distortion (Polynomial radial mapping)
   */
  public applyLensDistortion(
    data: Uint8ClampedArray,
    width: number,
    height: number,
    k1: number
  ): Uint8ClampedArray {
    const output = new Uint8ClampedArray(data.length);
    const cx = width / 2;
    const cy = height / 2;
    const rMax = Math.sqrt(cx * cx + cy * cy);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = (y * width + x) * 4;
        const nx = (x - cx) / rMax;
        const ny = (y - cy) / rMax;
        const r2 = nx * nx + ny * ny;

        // Distortion factor: 1 + k1 * r^2
        const factor = 1 + k1 * r2;
        const srcX = Math.round(cx + nx * factor * rMax);
        const srcY = Math.round(cy + ny * factor * rMax);

        if (srcX >= 0 && srcX < width && srcY >= 0 && srcY < height) {
          const sIdx = (srcY * width + srcX) * 4;
          output[idx] = data[sIdx];
          output[idx + 1] = data[sIdx + 1];
          output[idx + 2] = data[sIdx + 2];
          output[idx + 3] = data[sIdx + 3];
        } else {
          output[idx] = 0;
          output[idx + 1] = 0;
          output[idx + 2] = 0;
          output[idx + 3] = 255;
        }
      }
    }

    return output;
  }

  /**
   * Vignette (Smooth radial luminance falloff)
   */
  public applyVignette(
    data: Uint8ClampedArray,
    width: number,
    height: number,
    amount: number,
    feather: number,
    roundness: number
  ): Uint8ClampedArray {
    const output = new Uint8ClampedArray(data.length);
    const cx = width / 2;
    const cy = height / 2;
    const rx = cx * (1 + (1 - roundness));
    const ry = cy * (1 + (1 - roundness));

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = (y * width + x) * 4;
        const dx = (x - cx) / rx;
        const dy = (y - cy) / ry;
        const dist = Math.sqrt(dx * dx + dy * dy);

        // Smooth cosine falloff
        let attenuation = 1.0;
        const startR = 1.0 - feather;
        if (dist > startR) {
          const t = Math.min(1.0, (dist - startR) / Math.max(0.01, feather));
          attenuation = 1.0 - t * amount;
        }

        output[idx] = Math.round(data[idx] * attenuation);
        output[idx + 1] = Math.round(data[idx + 1] * attenuation);
        output[idx + 2] = Math.round(data[idx + 2] * attenuation);
        output[idx + 3] = data[idx + 3];
      }
    }

    return output;
  }

  /**
   * Depth Haze / Atmospheric Fog from genuine Depth Map data
   */
  public applyDepthHaze(
    data: Uint8ClampedArray,
    depthMap: Uint8ClampedArray,
    width: number,
    height: number,
    params: CinematicVfxParameters
  ): Uint8ClampedArray {
    const output = new Uint8ClampedArray(data.length);
    const hazeColor = this.parseHexColor(params.hazeColor || '#6080A0');
    const density = Math.max(0, Math.min(1, params.hazeDensity));
    const startDepth = Math.max(0, Math.min(1, params.hazeStartDepth));

    const pixelCount = width * height;
    for (let i = 0; i < pixelCount; i++) {
      const idx = i * 4;
      const depth = depthMap[idx] / 255; // 0 = close, 1 = far

      let fogFactor = 0;
      if (depth > startDepth) {
        fogFactor = Math.min(1.0, ((depth - startDepth) / (1 - startDepth)) * density);
      }

      output[idx] = Math.round(data[idx] * (1 - fogFactor) + hazeColor.r * fogFactor);
      output[idx + 1] = Math.round(data[idx + 1] * (1 - fogFactor) + hazeColor.g * fogFactor);
      output[idx + 2] = Math.round(data[idx + 2] * (1 - fogFactor) + hazeColor.b * fogFactor);
      output[idx + 3] = data[idx + 3];
    }

    return output;
  }

  /**
   * Fast Separable Box Blur for RGBA buffers
   */
  private blurRgba(data: Uint8ClampedArray, width: number, height: number, radius: number): Uint8ClampedArray {
    const r = Math.min(30, Math.max(1, Math.round(radius)));
    const temp = new Float32Array(data.length);
    const output = new Uint8ClampedArray(data.length);

    // Horizontal
    for (let y = 0; y < height; y++) {
      let rSum = 0, gSum = 0, bSum = 0, count = 0;
      const rowOffset = y * width * 4;

      for (let x = -r; x <= r; x++) {
        const px = Math.min(width - 1, Math.max(0, x)) * 4;
        rSum += data[rowOffset + px];
        gSum += data[rowOffset + px + 1];
        bSum += data[rowOffset + px + 2];
        count++;
      }

      for (let x = 0; x < width; x++) {
        const px = x * 4;
        temp[rowOffset + px] = rSum / count;
        temp[rowOffset + px + 1] = gSum / count;
        temp[rowOffset + px + 2] = bSum / count;

        const remPx = Math.max(0, x - r) * 4;
        const addPx = Math.min(width - 1, x + r + 1) * 4;
        rSum += data[rowOffset + addPx] - data[rowOffset + remPx];
        gSum += data[rowOffset + addPx + 1] - data[rowOffset + remPx + 1];
        bSum += data[rowOffset + addPx + 2] - data[rowOffset + remPx + 2];
      }
    }

    // Vertical
    for (let x = 0; x < width; x++) {
      let rSum = 0, gSum = 0, bSum = 0, count = 0;
      const colPx = x * 4;

      for (let y = -r; y <= r; y++) {
        const py = Math.min(height - 1, Math.max(0, y));
        const idx = py * width * 4 + colPx;
        rSum += temp[idx];
        gSum += temp[idx + 1];
        bSum += temp[idx + 2];
        count++;
      }

      for (let y = 0; y < height; y++) {
        const idx = y * width * 4 + colPx;
        output[idx] = Math.round(rSum / count);
        output[idx + 1] = Math.round(gSum / count);
        output[idx + 2] = Math.round(bSum / count);
        output[idx + 3] = data[idx + 3];

        const remPy = Math.max(0, y - r);
        const addPy = Math.min(height - 1, y + r + 1);
        const remIdx = remPy * width * 4 + colPx;
        const addIdx = addPy * width * 4 + colPx;

        rSum += temp[addIdx] - temp[remIdx];
        gSum += temp[addIdx + 1] - temp[remIdx + 1];
        bSum += temp[addIdx + 2] - temp[remIdx + 2];
      }
    }

    return output;
  }

  private parseHexColor(hex: string): { r: number; g: number; b: number } {
    const clean = hex.replace('#', '');
    return {
      r: parseInt(clean.substring(0, 2), 16) || 128,
      g: parseInt(clean.substring(2, 4), 16) || 128,
      b: parseInt(clean.substring(4, 6), 16) || 128
    };
  }

  /**
   * Procedural Particle Simulation Step (Embers, Sparks, Dust, Rain)
   */
  public updateParticles(
    systemId: string,
    params: ParticleSystemParameters,
    width: number,
    height: number,
    deltaTimeSec: number
  ): Particle[] {
    let pool = this.particlePool.get(systemId);
    if (!pool) {
      pool = [];
      this.particlePool.set(systemId, pool);
    }

    const rad = (params.directionDeg * Math.PI) / 180;
    const baseVx = Math.cos(rad) * params.speed;
    const baseVy = Math.sin(rad) * params.speed;

    // Spawn new particles if below count
    while (pool.length < params.particleCount) {
      const startX = params.preset === 'RAIN' || params.preset === 'SNOW'
        ? Math.random() * width
        : width / 2 + (Math.random() - 0.5) * 200;
      const startY = params.preset === 'RAIN' || params.preset === 'SNOW'
        ? 0
        : height / 2 + (Math.random() - 0.5) * 200;

      pool.push({
        x: startX,
        y: startY,
        vx: baseVx + (Math.random() - 0.5) * params.turbulence * 50,
        vy: baseVy + (Math.random() - 0.5) * params.turbulence * 50,
        size: params.sizeMin + Math.random() * (params.sizeMax - params.sizeMin),
        life: 0,
        maxLife: Math.max(0.5, params.lifetimeSec * (0.8 + Math.random() * 0.4)),
        color: params.colorStart,
        alpha: 1.0
      });
    }

    // Update positions & lifetime
    for (let i = pool.length - 1; i >= 0; i--) {
      const p = pool[i];
      p.life += deltaTimeSec;
      if (p.life >= p.maxLife) {
        pool.splice(i, 1);
        continue;
      }

      p.vy += params.gravity * deltaTimeSec * 100;
      p.x += p.vx * deltaTimeSec;
      p.y += p.vy * deltaTimeSec;
      p.alpha = Math.max(0, 1 - (p.life / p.maxLife));
    }

    return pool;
  }
}
