/**
 * GODEX P4.3 — Masking Engine
 * 
 * High-performance vector mask rasterizer for polygon, rectangle, ellipse,
 * and Bézier spline masks with feathering, expansion/erosion, and Boolean combining modes.
 */

import { VfxMask, MaskPoint, MaskMode } from './vfxTypes';
import { KeyingEngine } from './keyingEngine';

export class MaskingEngine {
  private static instance: MaskingEngine | null = null;

  public static getInstance(): MaskingEngine {
    if (!MaskingEngine.instance) {
      MaskingEngine.instance = new MaskingEngine();
    }
    return MaskingEngine.instance;
  }

  /**
   * Generates a 0-255 Uint8ClampedArray matte from a list of vector masks.
   */
  public rasterizeMasks(
    masks: VfxMask[],
    width: number,
    height: number
  ): Uint8ClampedArray {
    const pixelCount = width * height;
    const finalMatte = new Uint8ClampedArray(pixelCount);

    const activeMasks = masks.filter(m => m.enabled);
    if (activeMasks.length === 0) {
      // If no masks active, return full opacity (255)
      finalMatte.fill(255);
      return finalMatte;
    }

    // Default start state based on first mask mode
    if (activeMasks[0].mode === 'SUBTRACT') {
      finalMatte.fill(255);
    } else {
      finalMatte.fill(0);
    }

    const keyingEngine = KeyingEngine.getInstance();

    for (const mask of activeMasks) {
      let maskMatte = this.rasterizeSingleMask(mask, width, height);

      // Expansion / Erosion
      if (mask.expansion !== 0) {
        maskMatte = keyingEngine.applyMorphology(maskMatte, width, height, mask.expansion);
      }

      // Feathering
      if (mask.feather > 0) {
        maskMatte = keyingEngine.applyFeather(maskMatte, width, height, mask.feather);
      }

      // Invert
      if (mask.inverted) {
        for (let i = 0; i < pixelCount; i++) {
          maskMatte[i] = 255 - maskMatte[i];
        }
      }

      // Apply Mask Opacity
      if (mask.opacity < 1.0) {
        const op = Math.max(0, Math.min(1, mask.opacity));
        for (let i = 0; i < pixelCount; i++) {
          maskMatte[i] = Math.round(maskMatte[i] * op);
        }
      }

      // Combine with final matte according to mask mode
      this.combineMattes(finalMatte, maskMatte, mask.mode);
    }

    return finalMatte;
  }

  /**
   * Rasterize a single geometric mask shape into an alpha array (0 or 255)
   */
  private rasterizeSingleMask(
    mask: VfxMask,
    width: number,
    height: number
  ): Uint8ClampedArray {
    const matte = new Uint8ClampedArray(width * height);

    if (mask.shapeType === 'RECTANGLE' && mask.points.length >= 2) {
      const p1 = mask.points[0];
      const p2 = mask.points[1];
      const minX = Math.max(0, Math.min(p1.x, p2.x));
      const maxX = Math.min(width - 1, Math.max(p1.x, p2.x));
      const minY = Math.max(0, Math.min(p1.y, p2.y));
      const maxY = Math.min(height - 1, Math.max(p1.y, p2.y));

      for (let y = minY; y <= maxY; y++) {
        const rowOffset = y * width;
        for (let x = minX; x <= maxX; x++) {
          matte[rowOffset + x] = 255;
        }
      }
      return matte;
    }

    if (mask.shapeType === 'ELLIPSE' && mask.points.length >= 2) {
      const center = mask.points[0];
      const radiusPoint = mask.points[1];
      const rx = Math.abs(radiusPoint.x - center.x) || 50;
      const ry = Math.abs(radiusPoint.y - center.y) || 50;

      const minX = Math.max(0, Math.floor(center.x - rx));
      const maxX = Math.min(width - 1, Math.ceil(center.x + rx));
      const minY = Math.max(0, Math.floor(center.y - ry));
      const maxY = Math.min(height - 1, Math.ceil(center.y + ry));

      for (let y = minY; y <= maxY; y++) {
        const dy = (y - center.y) / ry;
        const rowOffset = y * width;
        for (let x = minX; x <= maxX; x++) {
          const dx = (x - center.x) / rx;
          if (dx * dx + dy * dy <= 1.0) {
            matte[rowOffset + x] = 255;
          }
        }
      }
      return matte;
    }

    // Default: Polygon / Bézier Raycasting
    if (mask.points.length < 3) {
      return matte;
    }

    const points = mask.points;
    const n = points.length;

    // Find bounding box
    let minX = width;
    let maxX = 0;
    let minY = height;
    let maxY = 0;

    for (const p of points) {
      if (p.x < minX) minX = Math.max(0, Math.floor(p.x));
      if (p.x > maxX) maxX = Math.min(width - 1, Math.ceil(p.x));
      if (p.y < minY) minY = Math.max(0, Math.floor(p.y));
      if (p.y > maxY) maxY = Math.min(height - 1, Math.ceil(p.y));
    }

    // Raycasting point-in-polygon inside bounding box
    for (let y = minY; y <= maxY; y++) {
      const rowOffset = y * width;
      for (let x = minX; x <= maxX; x++) {
        let inside = false;
        for (let i = 0, j = n - 1; i < n; j = i++) {
          const xi = points[i].x;
          const yi = points[i].y;
          const xj = points[j].x;
          const yj = points[j].y;

          const intersect = ((yi > y) !== (yj > y)) &&
            (x < ((xj - xi) * (y - yi)) / (yj - yi) + xi);
          if (intersect) inside = !inside;
        }

        if (inside) {
          matte[rowOffset + x] = 255;
        }
      }
    }

    return matte;
  }

  /**
   * Combine two matte buffers based on Boolean Mask Mode
   */
  private combineMattes(
    target: Uint8ClampedArray,
    incoming: Uint8ClampedArray,
    mode: MaskMode
  ): void {
    const len = target.length;
    for (let i = 0; i < len; i++) {
      const a = target[i];
      const b = incoming[i];

      switch (mode) {
        case 'ADD':
          target[i] = Math.min(255, a + b);
          break;
        case 'SUBTRACT':
          target[i] = Math.max(0, a - b);
          break;
        case 'INTERSECT':
          target[i] = Math.round((a * b) / 255);
          break;
        case 'DIFFERENCE':
          target[i] = Math.abs(a - b);
          break;
      }
    }
  }
}
