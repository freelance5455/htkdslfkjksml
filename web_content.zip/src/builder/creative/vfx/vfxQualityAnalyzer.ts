/**
 * GODEX P4.3 — VFX Quality Analyzer
 * 
 * Multi-factor algorithmic visual quality analyzer for compositing,
 * alpha matte edge sharpness, despill leakage, SNR, and tracking confidence.
 */

import { VfxQualityMetrics } from './vfxTypes';

export class VfxQualityAnalyzer {
  private static instance: VfxQualityAnalyzer | null = null;

  public static getInstance(): VfxQualityAnalyzer {
    if (!VfxQualityAnalyzer.instance) {
      VfxQualityAnalyzer.instance = new VfxQualityAnalyzer();
    }
    return VfxQualityAnalyzer.instance;
  }

  /**
   * Evaluates quality metrics of a composited RGBA buffer with alpha matte
   */
  public analyzeComposite(
    compositeRgba: Uint8ClampedArray,
    alphaMatte: Uint8ClampedArray | undefined,
    width: number,
    height: number,
    trackingConfidence: number = 100
  ): VfxQualityMetrics {
    const pixelCount = width * height;
    let totalLuma = 0;
    let minLuma = 255;
    let maxLuma = 0;
    let totalVariance = 0;

    let spillCount = 0;
    let edgeGradientSum = 0;
    let edgePixelCount = 0;
    let solidMatteCount = 0;

    for (let y = 1; y < height - 1; y++) {
      const rowOffset = y * width;
      for (let x = 1; x < width - 1; x++) {
        const idx = (rowOffset + x) * 4;
        const r = compositeRgba[idx];
        const g = compositeRgba[idx + 1];
        const b = compositeRgba[idx + 2];
        const luma = 0.299 * r + 0.587 * g + 0.114 * b;

        totalLuma += luma;
        if (luma < minLuma) minLuma = luma;
        if (luma > maxLuma) maxLuma = luma;

        // Check for green/blue halo spill
        if (g > (r + b) * 0.7 && g > 80) {
          spillCount++;
        }

        // Alpha edge sharpness
        if (alphaMatte) {
          const a = alphaMatte[rowOffset + x];
          if (a > 20 && a < 235) {
            // Edge pixel: compute Sobel gradient of alpha
            const gaX = alphaMatte[rowOffset + x + 1] - alphaMatte[rowOffset + x - 1];
            const gaY = alphaMatte[(y + 1) * width + x] - alphaMatte[(y - 1) * width + x];
            const grad = Math.sqrt(gaX * gaX + gaY * gaY);
            edgeGradientSum += grad;
            edgePixelCount++;
          } else if (a >= 235) {
            solidMatteCount++;
          }
        }
      }
    }

    const meanLuma = totalLuma / pixelCount;
    for (let i = 0; i < pixelCount; i += 4) {
      const idx = i * 4;
      const luma = 0.299 * compositeRgba[idx] + 0.587 * compositeRgba[idx + 1] + 0.114 * compositeRgba[idx + 2];
      totalVariance += Math.pow(luma - meanLuma, 2);
    }
    const stdDev = Math.sqrt(totalVariance / pixelCount);
    const snrDb = stdDev > 0 ? Math.round(20 * Math.log10(meanLuma / Math.max(1, stdDev)) * 10) / 10 : 35;
    const contrastRatio = minLuma > 0 ? Math.round((maxLuma / Math.max(1, minLuma)) * 10) / 10 : 100;

    const alphaEdgeSharpness = edgePixelCount > 0 
      ? Math.min(100, Math.round((edgeGradientSum / edgePixelCount) * 1.5))
      : 90;

    const spillLeakageScore = Math.min(100, Math.round((spillCount / Math.max(1, solidMatteCount || pixelCount)) * 100));
    const matteIntegrityScore = Math.max(0, 100 - spillLeakageScore * 0.5 + (alphaEdgeSharpness > 40 ? 10 : -10));

    const overallVfxQualityScore = Math.round(
      alphaEdgeSharpness * 0.25 +
      (100 - spillLeakageScore) * 0.25 +
      matteIntegrityScore * 0.25 +
      trackingConfidence * 0.25
    );

    return {
      alphaEdgeSharpness,
      spillLeakageScore,
      contrastRatio,
      signalToNoiseRatioDb: snrDb,
      motionTrackingConfidence: Math.round(trackingConfidence),
      matteIntegrityScore: Math.min(100, Math.max(0, matteIntegrityScore)),
      overallVfxQualityScore: Math.min(100, Math.max(0, overallVfxQualityScore))
    };
  }
}
