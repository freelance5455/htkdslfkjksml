/**
 * GODEX P4.2 — Professional Generative Media Presets
 * 
 * 14 Real, non-cosmetic production presets that configure actual generative engine parameters:
 * CFG scale, guidance steps, denoise strength, motion bucket ID, sampler, scheduler, camera defaults,
 * and negative constraints.
 */

import {
  VideoStylePreset,
  CameraMovementType,
  ResolutionPreset,
  AspectRatioType
} from './creativeStudioTypes';

export interface GenerationPresetDefinition {
  id: VideoStylePreset;
  name: string;
  category: 'CINEMATIC' | 'COMMERCIAL' | 'ARTISTIC' | 'REALISM' | 'GENRE';
  description: string;
  parameters: {
    cfgScale: number;
    guidanceSteps: number;
    strength: number; // Denoise for img2vid / vid2vid
    motionBucketId: number; // SVD motion parameter (1-255)
    samplerName: 'euler_ancestral' | 'dpmpp_2m' | 'dpmpp_sde' | 'euler' | 'ddim' | 'uni_pc';
    scheduler: 'karras' | 'exponential' | 'normal' | 'sgm_uniform';
    recommendedFps: 24 | 30 | 60;
    recommendedDurationSec: number;
    recommendedAspectRatio: AspectRatioType;
    recommendedResolution: ResolutionPreset;
    defaultCameraMovement: CameraMovementType;
    subjectMotionIntensity: number; // 1 to 10
  };
  promptEnhancements: {
    styleCues: string[];
    lightingCues: string[];
    lensCues: string[];
    negativeCues: string[];
  };
}

export const GENERATION_PRESETS: Record<VideoStylePreset, GenerationPresetDefinition> = {
  CINEMATIC: {
    id: 'CINEMATIC',
    name: 'Cinematic Panavision',
    category: 'CINEMATIC',
    description: 'Anamorphic 35mm film rendering with natural optical falloff and deep cinematic dynamic range.',
    parameters: {
      cfgScale: 7.5,
      guidanceSteps: 30,
      strength: 0.75,
      motionBucketId: 127,
      samplerName: 'dpmpp_2m',
      scheduler: 'karras',
      recommendedFps: 24,
      recommendedDurationSec: 5,
      recommendedAspectRatio: '21:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'DOLLY_IN',
      subjectMotionIntensity: 6
    },
    promptEnhancements: {
      styleCues: ['35mm anamorphic lens', 'cinematic color grading', 'subtle film grain', 'cinematic depth of field'],
      lightingCues: ['chiaroscuro lighting', 'soft rim lighting', 'golden hour atmospheric haze'],
      lensCues: ['50mm prime f/1.4', 'anamorphic bokeh'],
      negativeCues: ['cgi look', 'oversaturated', 'flat lighting', 'cheap video look']
    }
  },
  FILM: {
    id: 'FILM',
    name: '35mm Celluloid Film',
    category: 'CINEMATIC',
    description: 'Authentic Kodak Vision3 celluloid texture with rich halation and gentle natural grain.',
    parameters: {
      cfgScale: 7.0,
      guidanceSteps: 28,
      strength: 0.70,
      motionBucketId: 110,
      samplerName: 'euler_ancestral',
      scheduler: 'karras',
      recommendedFps: 24,
      recommendedDurationSec: 4,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'HANDHELD',
      subjectMotionIntensity: 5
    },
    promptEnhancements: {
      styleCues: ['Kodak Vision3 500T', 'authentic 35mm celluloid', 'fine organic grain', 'halation on highlights'],
      lightingCues: ['natural tungsten and daylight mix', 'gentle highlight roll-off'],
      lensCues: ['vintage Cooke speed panchro lens', 'natural micro-contrast'],
      negativeCues: ['digital sharpness', 'plastic skin', 'harsh digital clipping']
    }
  },
  COMMERCIAL: {
    id: 'COMMERCIAL',
    name: 'High-End Commercial',
    category: 'COMMERCIAL',
    description: 'Pristine, ultra-clean studio lighting with razor-sharp macro detail and vibrant brand tonality.',
    parameters: {
      cfgScale: 8.0,
      guidanceSteps: 35,
      strength: 0.80,
      motionBucketId: 140,
      samplerName: 'dpmpp_sde',
      scheduler: 'karras',
      recommendedFps: 30,
      recommendedDurationSec: 4,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '4K',
      defaultCameraMovement: 'ORBIT',
      subjectMotionIntensity: 7
    },
    promptEnhancements: {
      styleCues: ['commercial studio grade', 'ultra-clean high fidelity', 'impeccable product photography'],
      lightingCues: ['diffused softbox key light', 'precision edge highlight', 'clean shadow gradient'],
      lensCues: ['85mm macro lens f/2.8', 'tack sharp focus'],
      negativeCues: ['dust', 'grain', 'dirty lens', 'motion blur on product', 'inconsistent lighting']
    }
  },
  MUSIC_VIDEO: {
    id: 'MUSIC_VIDEO',
    name: 'Dynamic Music Video',
    category: 'ARTISTIC',
    description: 'Rhythmic high-velocity camera sweeps with bold neon edge fills and dynamic motion trajectories.',
    parameters: {
      cfgScale: 8.5,
      guidanceSteps: 32,
      strength: 0.82,
      motionBucketId: 180,
      samplerName: 'dpmpp_2m',
      scheduler: 'exponential',
      recommendedFps: 60,
      recommendedDurationSec: 6,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'ORBIT_360',
      subjectMotionIntensity: 9
    },
    promptEnhancements: {
      styleCues: ['stylized music video aesthetic', 'high kinetic energy', 'volumetric fog', 'bold color contrast'],
      lightingCues: ['saturated neon split-lighting', 'strobe backlighting', 'atmospheric haze laser beams'],
      lensCues: ['ultra-wide 16mm fish-eye perspective', 'motion speed streaks'],
      negativeCues: ['static composition', 'boring lighting', 'sluggish motion', 'underexposed sludge']
    }
  },
  DOCUMENTARY: {
    id: 'DOCUMENTARY',
    name: 'Natural Documentary',
    category: 'REALISM',
    description: 'Unfiltered observational realism with authentic environmental ambient lighting and natural motion.',
    parameters: {
      cfgScale: 6.5,
      guidanceSteps: 25,
      strength: 0.65,
      motionBucketId: 90,
      samplerName: 'euler',
      scheduler: 'normal',
      recommendedFps: 24,
      recommendedDurationSec: 8,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'PAN_RIGHT',
      subjectMotionIntensity: 4
    },
    promptEnhancements: {
      styleCues: ['observational documentary style', 'unfiltered realism', 'natural human behavior'],
      lightingCues: ['available natural light', 'overcast diffuse sky', 'real-world ambient balance'],
      lensCues: ['telephoto 70-200mm compression', 'candid focal plane'],
      negativeCues: ['artificial glamor', 'heavy makeup', 'stage lighting', 'staged pose']
    }
  },
  ANIME: {
    id: 'ANIME',
    name: 'Anime Masterpiece',
    category: 'ARTISTIC',
    description: 'Hand-drawn Japanese studio aesthetic with vivid cel shading, vibrant palettes, and stylized keyframes.',
    parameters: {
      cfgScale: 8.0,
      guidanceSteps: 28,
      strength: 0.85,
      motionBucketId: 150,
      samplerName: 'euler_ancestral',
      scheduler: 'karras',
      recommendedFps: 24,
      recommendedDurationSec: 5,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'ZOOM_IN',
      subjectMotionIntensity: 7
    },
    promptEnhancements: {
      styleCues: ['Makoto Shinkai aesthetic', 'crisp cel shading', 'detailed anime lineart', 'expressive key animation'],
      lightingCues: ['radiant sun flare', 'vibrant sky gradients', 'soft watercolor background illumination'],
      lensCues: ['anime cinematic framing', 'dramatic wide perspective'],
      negativeCues: ['3d cgi render', 'photorealistic skin texture', 'western cartoon', 'blurry lineart']
    }
  },
  REALISTIC: {
    id: 'REALISTIC',
    name: 'Hyper-Realistic Raw',
    category: 'REALISM',
    description: 'Raw unedited photograph with natural skin micro-textures, authentic subsurface scattering, and true optics.',
    parameters: {
      cfgScale: 7.0,
      guidanceSteps: 30,
      strength: 0.72,
      motionBucketId: 100,
      samplerName: 'dpmpp_2m',
      scheduler: 'karras',
      recommendedFps: 30,
      recommendedDurationSec: 4,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '4K',
      defaultCameraMovement: 'STATIC',
      subjectMotionIntensity: 4
    },
    promptEnhancements: {
      styleCues: ['raw unedited photograph', 'detailed skin pores', 'natural imperfections', 'subsurface scattering'],
      lightingCues: ['natural diffused window light', 'accurate shadows', 'balanced exposure'],
      lensCues: ['Canon 50mm f/1.2L lens', 'optical sharpness with subtle falloff'],
      negativeCues: ['airbrushed', 'plastic skin', 'oversharpened', 'ai smooth look', 'cgi']
    }
  },
  CYBERPUNK: {
    id: 'CYBERPUNK',
    name: 'Cyberpunk Dystopia',
    category: 'GENRE',
    description: 'Futuristic high-contrast neon metropolis with rain-slicked reflective surfaces and holographic glow.',
    parameters: {
      cfgScale: 9.0,
      guidanceSteps: 35,
      strength: 0.85,
      motionBucketId: 160,
      samplerName: 'dpmpp_sde',
      scheduler: 'karras',
      recommendedFps: 30,
      recommendedDurationSec: 5,
      recommendedAspectRatio: '21:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'TRUCK_RIGHT',
      subjectMotionIntensity: 8
    },
    promptEnhancements: {
      styleCues: ['cyberpunk 2077 aesthetic', 'holographic UI elements', 'wet pavement reflections', 'futuristic urban density'],
      lightingCues: ['cyan and magenta dual-tone neon', 'volumetric street steam', 'dark moody shadow corridors'],
      lensCues: ['anamorphic lens with horizontal blue flare'],
      negativeCues: ['pastoral', 'bright daylight', 'clean vintage', 'low contrast']
    }
  },
  PORTRAIT: {
    id: 'PORTRAIT',
    name: 'Studio Portraiture',
    category: 'COMMERCIAL',
    description: 'Intimate studio portrait featuring creamy 85mm bokeh, catchlights, and exquisite facial detail.',
    parameters: {
      cfgScale: 7.5,
      guidanceSteps: 30,
      strength: 0.70,
      motionBucketId: 80,
      samplerName: 'dpmpp_2m',
      scheduler: 'karras',
      recommendedFps: 24,
      recommendedDurationSec: 4,
      recommendedAspectRatio: '9:16',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'DOLLY_IN',
      subjectMotionIntensity: 3
    },
    promptEnhancements: {
      styleCues: ['editorial portraiture', 'eye catchlights', 'creamy background separation', 'natural hair strands'],
      lightingCues: ['beauty dish key light', 'subtle silver reflector fill', 'hair separation rim light'],
      lensCues: ['85mm portrait lens f/1.4', 'shallow depth of field'],
      negativeCues: ['distorted facial anatomy', 'bad eyes', 'flat flash lighting', 'plastic skin']
    }
  },
  PRODUCT: {
    id: 'PRODUCT',
    name: 'Product Showcase',
    category: 'COMMERCIAL',
    description: '360 turntable display with controlled specular highlights, material reflections, and crisp isolation.',
    parameters: {
      cfgScale: 8.0,
      guidanceSteps: 32,
      strength: 0.78,
      motionBucketId: 110,
      samplerName: 'dpmpp_2m',
      scheduler: 'karras',
      recommendedFps: 30,
      recommendedDurationSec: 5,
      recommendedAspectRatio: '1:1',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'ORBIT',
      subjectMotionIntensity: 5
    },
    promptEnhancements: {
      styleCues: ['luxury product turntable', 'specular highlight tracking', 'premium material finishes (matte, gloss, metal)'],
      lightingCues: ['overhead gradient light strip', 'subtle floor reflection'],
      lensCues: ['100mm macro lens', 'infinite focus on subject plane'],
      negativeCues: ['fingerprints', 'dust specks', 'blurry edges', 'distorted geometry']
    }
  },
  ARCHITECTURAL: {
    id: 'ARCHITECTURAL',
    name: 'Architectural Visualization',
    category: 'REALISM',
    description: 'Architectural tilt-shift perspective with straight vertical lines, accurate structural materials, and ambient daylight.',
    parameters: {
      cfgScale: 7.5,
      guidanceSteps: 32,
      strength: 0.70,
      motionBucketId: 70,
      samplerName: 'euler',
      scheduler: 'karras',
      recommendedFps: 24,
      recommendedDurationSec: 6,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '4K',
      defaultCameraMovement: 'TRUCK_LEFT',
      subjectMotionIntensity: 2
    },
    promptEnhancements: {
      styleCues: ['Architectural Digest feature', 'pure vertical alignment', 'accurate material textures (brushed concrete, warm timber, glass)'],
      lightingCues: ['golden hour ray tracing', 'soft ambient sky bounce', 'linear interior architectural lighting'],
      lensCues: ['24mm tilt-shift perspective control lens', 'zero barrel distortion'],
      negativeCues: ['tilted converging verticals', 'warped walls', 'fuzzy textures', 'unrealistic scale']
    }
  },
  ACTION: {
    id: 'ACTION',
    name: 'High-Impact Action',
    category: 'GENRE',
    description: 'Explosive kinetic momentum with dynamic whip pans, high shutter speed, and debris/particle propagation.',
    parameters: {
      cfgScale: 8.5,
      guidanceSteps: 35,
      strength: 0.85,
      motionBucketId: 210,
      samplerName: 'dpmpp_2m',
      scheduler: 'exponential',
      recommendedFps: 60,
      recommendedDurationSec: 4,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'TRACKING',
      subjectMotionIntensity: 10
    },
    promptEnhancements: {
      styleCues: ['high-octane action sequence', 'motion particle debris', 'dynamic physics trajectory', 'shutter angle 90 degrees'],
      lightingCues: ['high-contrast drama', 'explosive firelight glints', 'harsh direct sunlight'],
      lensCues: ['wide 24mm tracking camera', 'dynamic motion blur'],
      negativeCues: ['frozen rigid poses', 'sluggish movement', 'soft focus on key subject']
    }
  },
  HORROR: {
    id: 'HORROR',
    name: 'Psychological Horror',
    category: 'GENRE',
    description: 'Eerie, oppressive low-key shadows, desaturated palettes, uncanny slow creeping dolly movements.',
    parameters: {
      cfgScale: 8.0,
      guidanceSteps: 30,
      strength: 0.78,
      motionBucketId: 100,
      samplerName: 'euler_ancestral',
      scheduler: 'karras',
      recommendedFps: 24,
      recommendedDurationSec: 6,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'DOLLY_OUT',
      subjectMotionIntensity: 4
    },
    promptEnhancements: {
      styleCues: ['atmospheric psychological horror', 'uncanny composition', 'grimy textures', 'subtle liminal space'],
      lightingCues: ['underexposed moonlight', 'single flickering bulb', 'dense claustrophobic shadows'],
      lensCues: ['distorted wide lens with vignetting', 'aberration at edges'],
      negativeCues: ['cheerful colors', 'flat daylight', 'clean cute aesthetics']
    }
  },
  SCI_FI: {
    id: 'SCI_FI',
    name: 'Hard Sci-Fi',
    category: 'GENRE',
    description: 'Meticulous aerospace engineering detail, zero-gravity physics, starfield illumination, and HUD interfaces.',
    parameters: {
      cfgScale: 8.0,
      guidanceSteps: 32,
      strength: 0.80,
      motionBucketId: 130,
      samplerName: 'dpmpp_2m',
      scheduler: 'karras',
      recommendedFps: 30,
      recommendedDurationSec: 5,
      recommendedAspectRatio: '21:9',
      recommendedResolution: '4K',
      defaultCameraMovement: 'CRANE',
      subjectMotionIntensity: 6
    },
    promptEnhancements: {
      styleCues: ['hard science fiction', 'spacecraft modular plating', 'realistic orbital physics', 'tactile mechanical switches'],
      lightingCues: ['stark unmitigated solar key light', 'cool interior console glow', 'deep space pitch-black contrast'],
      lensCues: ['IMAX 70mm anamorphic lens', 'subtle chromatic dispersion'],
      negativeCues: ['fantasy magic', 'cartoony spaceships', 'mushy geometry', 'fog in hard vacuum']
    }
  },
  // Backward compatibility aliases
  PHOTOREAL: {
    id: 'PHOTOREAL',
    name: 'Photorealistic',
    category: 'REALISM',
    description: 'Alias for Hyper-Realistic Raw preset.',
    parameters: {
      cfgScale: 7.0,
      guidanceSteps: 30,
      strength: 0.72,
      motionBucketId: 100,
      samplerName: 'dpmpp_2m',
      scheduler: 'karras',
      recommendedFps: 30,
      recommendedDurationSec: 4,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'STATIC',
      subjectMotionIntensity: 4
    },
    promptEnhancements: {
      styleCues: ['raw photograph', 'photorealistic textures'],
      lightingCues: ['natural lighting'],
      lensCues: ['50mm prime lens'],
      negativeCues: ['cgi', 'drawing', 'painting']
    }
  },
  OCTANE_3D: {
    id: 'OCTANE_3D',
    name: 'Octane 3D Render',
    category: 'ARTISTIC',
    description: 'High-end raytraced 3D visual with sub-surface ray casting.',
    parameters: {
      cfgScale: 8.5,
      guidanceSteps: 35,
      strength: 0.85,
      motionBucketId: 150,
      samplerName: 'dpmpp_sde',
      scheduler: 'karras',
      recommendedFps: 30,
      recommendedDurationSec: 4,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'ORBIT',
      subjectMotionIntensity: 7
    },
    promptEnhancements: {
      styleCues: ['Octane render', 'Redshift raytracing', '3d digital art'],
      lightingCues: ['global illumination', 'caustics'],
      lensCues: ['35mm raytraced camera'],
      negativeCues: ['blurry', 'flat 2d', 'low poly']
    }
  },
  NOIR: {
    id: 'NOIR',
    name: 'Classic Film Noir',
    category: 'CINEMATIC',
    description: 'Black-and-white high contrast chiaroscuro with venetian blind shadows.',
    parameters: {
      cfgScale: 7.5,
      guidanceSteps: 28,
      strength: 0.75,
      motionBucketId: 90,
      samplerName: 'dpmpp_2m',
      scheduler: 'karras',
      recommendedFps: 24,
      recommendedDurationSec: 5,
      recommendedAspectRatio: '4:3',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'PAN_LEFT',
      subjectMotionIntensity: 3
    },
    promptEnhancements: {
      styleCues: ['classic film noir', 'black and white', '1940s Hollywood cinema'],
      lightingCues: ['dramatic chiaroscuro', 'venetian blind shadow patterns', 'harsh hard light'],
      lensCues: ['vintage 50mm lens'],
      negativeCues: ['color', 'saturated', 'modern flat lighting']
    }
  },
  STUDIO_PORTRAIT: {
    id: 'STUDIO_PORTRAIT',
    name: 'Studio Portrait (Legacy)',
    category: 'COMMERCIAL',
    description: 'Studio portraiture alias.',
    parameters: {
      cfgScale: 7.5,
      guidanceSteps: 30,
      strength: 0.70,
      motionBucketId: 80,
      samplerName: 'dpmpp_2m',
      scheduler: 'karras',
      recommendedFps: 24,
      recommendedDurationSec: 4,
      recommendedAspectRatio: '9:16',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'DOLLY_IN',
      subjectMotionIntensity: 3
    },
    promptEnhancements: {
      styleCues: ['studio portraiture'],
      lightingCues: ['softbox lighting'],
      lensCues: ['85mm portrait lens'],
      negativeCues: ['bad eyes', 'low quality']
    }
  },
  ANALOG_FILM: {
    id: 'ANALOG_FILM',
    name: 'Analog Film (Legacy)',
    category: 'CINEMATIC',
    description: 'Celluloid analog film alias.',
    parameters: {
      cfgScale: 7.0,
      guidanceSteps: 28,
      strength: 0.70,
      motionBucketId: 110,
      samplerName: 'euler_ancestral',
      scheduler: 'karras',
      recommendedFps: 24,
      recommendedDurationSec: 4,
      recommendedAspectRatio: '16:9',
      recommendedResolution: '1080p',
      defaultCameraMovement: 'HANDHELD',
      subjectMotionIntensity: 5
    },
    promptEnhancements: {
      styleCues: ['analog film', 'film grain'],
      lightingCues: ['natural lighting'],
      lensCues: ['vintage lens'],
      negativeCues: ['digital cgi']
    }
  }
};

export class GenerationPresetManager {
  public static getPreset(presetId: VideoStylePreset): GenerationPresetDefinition {
    return GENERATION_PRESETS[presetId] || GENERATION_PRESETS.CINEMATIC;
  }

  public static getAllPresets(): GenerationPresetDefinition[] {
    // Return primary 14 presets
    const primaryKeys: VideoStylePreset[] = [
      'CINEMATIC', 'FILM', 'COMMERCIAL', 'MUSIC_VIDEO', 'DOCUMENTARY',
      'ANIME', 'REALISTIC', 'CYBERPUNK', 'PORTRAIT', 'PRODUCT',
      'ARCHITECTURAL', 'ACTION', 'HORROR', 'SCI_FI'
    ];
    return primaryKeys.map(k => GENERATION_PRESETS[k]);
  }
}
