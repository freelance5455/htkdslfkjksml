/**
 * GODEX P4.4 — Production Audio-Visual (AV) Synchronization Engine
 * 
 * Frame-accurate synchronization between Video/VFX Timeline and Audio Timeline:
 * - Frame ↔ Timestamp mathematical mapping (24, 25, 30, 60 FPS)
 * - Sub-frame time calculations: timeSec = frameNumber / fps
 * - Marker alignment & verification (Cues, Beats, SFX Hits, Transitions)
 * - Clock drift detection and latency compensation
 * - Structured AvSyncReport generation for epistemic verification
 */

import {
  AudioSyncMarker,
  AudioTimeline,
  AvSyncReport
} from './audioTypes';

export class AudioSyncEngine {
  private static instance: AudioSyncEngine | null = null;

  public static getInstance(): AudioSyncEngine {
    if (!AudioSyncEngine.instance) {
      AudioSyncEngine.instance = new AudioSyncEngine();
    }
    return AudioSyncEngine.instance;
  }

  /**
   * Convert frame number to exact timestamp in seconds at specified FPS
   */
  public frameToTimeSec(frame: number, fps: number = 24): number {
    const safeFps = Math.max(1, fps);
    return Math.max(0, frame) / safeFps;
  }

  /**
   * Convert timestamp in seconds to nearest frame number at specified FPS
   */
  public timeSecToFrame(timeSec: number, fps: number = 24): number {
    const safeFps = Math.max(1, fps);
    return Math.round(Math.max(0, timeSec) * safeFps);
  }

  /**
   * Compute exact sample index in PCM buffer for a given video frame
   */
  public frameToSampleIndex(frame: number, fps: number = 24, sampleRate: number = 44100): number {
    const timeSec = this.frameToTimeSec(frame, fps);
    return Math.floor(timeSec * sampleRate);
  }

  /**
   * Compute exact frame number from audio PCM sample index
   */
  public sampleIndexToFrame(sampleIndex: number, sampleRate: number = 44100, fps: number = 24): number {
    const timeSec = sampleIndex / sampleRate;
    return this.timeSecToFrame(timeSec, fps);
  }

  /**
   * Creates an audio sync marker aligned to a specific video frame
   */
  public createMarkerAtFrame(
    frameNumber: number,
    name: string,
    type: AudioSyncMarker['type'] = 'SFX_HIT',
    fps: number = 24,
    color?: string
  ): AudioSyncMarker {
    const timeSec = this.frameToTimeSec(frameNumber, fps);
    const defaultColor = type === 'SFX_HIT' ? '#EF4444' : type === 'BEAT' ? '#3B82F6' : type === 'TRANSITION' ? '#F59E0B' : '#10B981';

    return {
      id: `marker-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      frameNumber,
      timeSec: Math.round(timeSec * 10000) / 10000,
      name,
      type,
      color: color || defaultColor
    };
  }

  /**
   * Generates a comprehensive AV synchronization diagnostics report
   */
  public evaluateSynchronization(
    timeline: AudioTimeline,
    vfxTotalFrames: number,
    vfxFps: number
  ): AvSyncReport {
    const effectiveFps = vfxFps || timeline.fps || 24;
    const vfxDurationSec = vfxTotalFrames / effectiveFps;
    const audioDurationSec = timeline.durationSec;

    const durationDeltaSec = Math.abs(vfxDurationSec - audioDurationSec);
    const frameToTimeDriftMs = Math.round(durationDeltaSec * 1000 * 10) / 10;

    let unalignedCount = 0;
    const markerDetails = (timeline.syncMarkers || []).map(m => {
      const expectedTime = this.frameToTimeSec(m.frameNumber, effectiveFps);
      const driftMs = Math.abs(m.timeSec - expectedTime) * 1000;
      const isAligned = driftMs < 20.0; // Less than 20ms drift threshold (< 1/2 frame at 24fps)

      if (!isAligned) unalignedCount++;

      return {
        markerId: m.id,
        markerName: m.name,
        targetFrame: m.frameNumber,
        targetTimeSec: expectedTime,
        driftMs: Math.round(driftMs * 10) / 10,
        isAligned
      };
    });

    // Detect Audio Events (Clips placed on timeline)
    let detectedAudioEventsCount = 0;
    for (const track of timeline.tracks) {
      detectedAudioEventsCount += track.clips.length;
    }

    let alignmentScore = 100;
    if (frameToTimeDriftMs > 100) {
      alignmentScore -= Math.min(40, (frameToTimeDriftMs - 100) / 10);
    }
    if (unalignedCount > 0) {
      alignmentScore -= Math.min(30, unalignedCount * 5);
    }

    const syncStatus: AvSyncReport['syncStatus'] = 
      frameToTimeDriftMs > 250 || unalignedCount > 3 ? 'DRIFT_DETECTED' :
      frameToTimeDriftMs > 2000 ? 'OUT_OF_BOUNDS' : 'SYNCHRONIZED';

    return {
      fps: effectiveFps,
      totalFrames: vfxTotalFrames,
      timelineDurationSec: Math.round(vfxDurationSec * 100) / 100,
      audioDurationSec: Math.round(audioDurationSec * 100) / 100,
      frameToTimeDriftMs,
      syncStatus,
      unalignedMarkersCount: unalignedCount,
      detectedAudioEventsCount,
      avAlignmentScore: Math.max(0, Math.min(100, Math.round(alignmentScore))),
      markerDetails
    };
  }

  /**
   * Generates a musical / rhythmic beat grid markers at target BPM and time signature
   */
  public generateBeatGrid(
    bpm: number = 120,
    durationSec: number = 5.0,
    fps: number = 24
  ): AudioSyncMarker[] {
    const beatIntervalSec = 60.0 / Math.max(30, Math.min(bpm, 300));
    const totalBeats = Math.floor(durationSec / beatIntervalSec);
    const markers: AudioSyncMarker[] = [];

    for (let b = 0; b < totalBeats; b++) {
      const timeSec = b * beatIntervalSec;
      const frameNumber = this.timeSecToFrame(timeSec, fps);
      const isDownbeat = (b % 4) === 0;

      markers.push({
        id: `beat-${b}-${Date.now()}`,
        frameNumber,
        timeSec: Math.round(timeSec * 1000) / 1000,
        name: isDownbeat ? `Bar ${Math.floor(b / 4) + 1}.1` : `Beat ${(b % 4) + 1}`,
        type: 'BEAT',
        color: isDownbeat ? '#3B82F6' : '#60A5FA'
      });
    }

    return markers;
  }
}
