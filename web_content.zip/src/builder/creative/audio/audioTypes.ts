/**
 * GODEX P4.4 — Production SFX / Audio Intelligence & AV Synchronization Core Types
 * 
 * Authoritative data models for professional procedural sound design,
 * Web Audio DSP processing, multi-track audio mixing, mastering chain,
 * AV frame-to-timestamp synchronization, and truthful epistemic telemetry.
 */

export type AudioTruthClassification =
  | 'LOCAL_DETERMINISTIC'
  | 'REAL_ENGINE'
  | 'REQUIRES_ENGINE'
  | 'MODEL_UNAVAILABLE'
  | 'UNAVAILABLE'
  | 'FAILED'
  | 'COMPLETED';

export type AudioTrackType =
  | 'SFX'
  | 'FOLEY'
  | 'DIALOGUE'
  | 'AMBIENCE'
  | 'MUSIC_BED'
  | 'MASTER_BUS';

export type SfxCategory =
  | 'IMPACT'
  | 'WHOOSH'
  | 'RISER'
  | 'HIT'
  | 'EXPLOSION'
  | 'WIND'
  | 'RAIN'
  | 'AMBIENCE'
  | 'MECHANICAL_HUM'
  | 'FOOTSTEPS'
  | 'UI_SOUND'
  | 'CINEMATIC_TRANSITION'
  | 'CUSTOM_SYNTH';

export type NoiseType = 'WHITE' | 'PINK' | 'BROWNIAN';

export type FilterType = 'LOWPASS' | 'HIGHPASS' | 'BANDPASS' | 'NOTCH' | 'PEAKING';

export interface SfxSynthesisParameters {
  category: SfxCategory;
  durationSec: number; // 0.1s to 30.0s
  sampleRate: number; // 22050, 44100, 48000
  pitchHz: number; // 20Hz - 20000Hz
  endPitchHz?: number; // Pitch envelope sweep destination
  noiseType?: NoiseType;
  filterType?: FilterType;
  filterCutoffHz?: number; // 20Hz - 20000Hz
  filterResonance?: number; // 0.1 - 20.0 Q
  attackSec: number;
  decaySec: number;
  sustainLevel: number; // 0.0 - 1.0
  releaseSec: number;
  distortionAmount?: number; // 0.0 - 1.0
  reverbMix?: number; // 0.0 - 1.0
  delayMix?: number; // 0.0 - 1.0
  delayTimeSec?: number;
  stereoSpread?: number; // 0.0 - 1.0
  seed?: number;
}

export interface AudioFilterSettings {
  enabled: boolean;
  type: FilterType;
  cutoffHz: number;
  q: number;
  gainDb: number;
}

export interface AudioEqSettings {
  enabled: boolean;
  lowGainDb: number; // -24 to +24 dB (< 250Hz)
  midGainDb: number; // -24 to +24 dB (250Hz - 4kHz)
  highGainDb: number; // -24 to +24 dB (> 4kHz)
  lowFreqHz: number;
  midFreqHz: number;
  highFreqHz: number;
}

export interface AudioCompressorSettings {
  enabled: boolean;
  thresholdDb: number; // -60 to 0 dB
  ratio: number; // 1.0 to 20.0
  attackMs: number; // 0.1 to 100 ms
  releaseMs: number; // 10 to 1000 ms
  makeupGainDb: number; // 0 to 24 dB
  kneeDb: number; // 0 to 12 dB
}

export interface AudioLimiterSettings {
  enabled: boolean;
  ceilingDb: number; // -12 to 0 dB
  releaseMs: number; // 5 to 500 ms
  softClip: boolean;
}

export interface AudioDuckingSettings {
  enabled: boolean;
  sourceTrackId: string; // e.g. DIALOGUE track triggers ducking
  duckAmountDb: number; // e.g. -12 dB
  attackMs: number;
  releaseMs: number;
  thresholdDb: number;
}

export interface AudioEffectChain {
  gainDb: number; // -60 to +12 dB
  pan: number; // -1.0 (Left) to +1.0 (Right)
  eq: AudioEqSettings;
  compressor: AudioCompressorSettings;
  limiter: AudioLimiterSettings;
  ducking?: AudioDuckingSettings;
  reverbMix: number; // 0.0 to 1.0
  delayMix: number; // 0.0 to 1.0
  delayTimeSec: number;
  delayFeedback: number;
}

export interface AudioSyncMarker {
  id: string;
  frameNumber: number;
  timeSec: number;
  name: string;
  type: 'CUE' | 'BEAT' | 'SFX_HIT' | 'TRANSITION' | 'DIALOGUE_START';
  color: string;
}

export interface AudioClip {
  id: string;
  name: string;
  trackId: string;
  startTimeSec: number;
  durationSec: number;
  sourceOffsetSec: number;
  category: SfxCategory;
  synthesisParams?: SfxSynthesisParameters;
  rawPcmData?: Float32Array; // Left/Mono channel
  rawPcmDataRight?: Float32Array; // Right channel (stereo)
  sampleRate: number;
  channels: 1 | 2;
  volume: number; // 0.0 to 2.0 (1.0 = 0dB)
  pan: number; // -1.0 to 1.0
  muted: boolean;
  solo: boolean;
  fadeInSec: number;
  fadeOutSec: number;
  effectsChain: AudioEffectChain;
  markers: AudioSyncMarker[];
  waveformPoints?: number[]; // Downsampled peaks for UI rendering (e.g. 100 points)
  meta?: Record<string, any>;
}

export interface AudioTimelineTrack {
  id: string;
  name: string;
  type: AudioTrackType;
  muted: boolean;
  solo: boolean;
  locked: boolean;
  volume: number; // 0.0 to 2.0
  pan: number; // -1.0 to 1.0
  effects: AudioEffectChain;
  clips: AudioClip[];
  color: string;
}

export interface AudioTimeline {
  id: string;
  name: string;
  fps: 24 | 25 | 30 | 60;
  sampleRate: number; // 44100 or 48000
  totalFrames: number;
  durationSec: number;
  currentFrame: number;
  currentTimeSec: number;
  isPlaying: boolean;
  loop: boolean;
  tracks: AudioTimelineTrack[];
  masterBus: {
    volume: number;
    pan: number;
    eq: AudioEqSettings;
    compressor: AudioCompressorSettings;
    limiter: AudioLimiterSettings;
  };
  syncMarkers: AudioSyncMarker[];
}

export interface AvSyncReport {
  fps: number;
  totalFrames: number;
  timelineDurationSec: number;
  audioDurationSec: number;
  frameToTimeDriftMs: number;
  syncStatus: 'SYNCHRONIZED' | 'DRIFT_DETECTED' | 'OUT_OF_BOUNDS';
  unalignedMarkersCount: number;
  detectedAudioEventsCount: number;
  avAlignmentScore: number; // 0 - 100
  markerDetails: {
    markerId: string;
    markerName: string;
    targetFrame: number;
    targetTimeSec: number;
    driftMs: number;
    isAligned: boolean;
  }[];
}

export interface AudioQualityMetrics {
  rmsDb: number; // Root Mean Square in dBFS (-90 to 0)
  peakDb: number; // Peak amplitude in dBFS (-90 to 0)
  clippingCount: number; // Samples hitting >= 0.9999 or <= -0.9999
  silenceRatio: number; // Fraction of audio below -60 dBFS (0.0 - 1.0)
  dynamicRangeDb: number; // Difference between Peak and RMS / noise floor
  spectralBalanceScore: number; // 0 - 100 (Energy balance across low/mid/high bands)
  channelBalanceDb: number; // Left vs Right energy offset (0 dB = balanced)
  synchronizationDriftMs: number; // Max drift against video frames
  sampleRate: number;
  channelCount: number;
  durationSec: number;
  overallAudioQualityScore: number; // 0 - 100
  isClippingDetected: boolean;
  isCorrupt: boolean;
  integrityPassed: boolean;
}

export interface AudioExecutionEvidence {
  executionId: string;
  timestamp: number;
  operation: string;
  engineId: string;
  engineName: string;
  truthClassification: AudioTruthClassification;
  durationMs: number;
  sampleRate: number;
  channelCount: number;
  durationSec: number;
  qualityMetrics: AudioQualityMetrics;
  parametersApplied: Record<string, any>;
  logs: string[];
  warnings: string[];
  requiresEngineReason?: string;
  isVerified: boolean;
}

export interface AudioProcessingJob {
  jobId: string;
  name: string;
  targetTimelineId: string;
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED' | 'REQUIRES_ENGINE';
  progressPercent: number;
  evidence?: AudioExecutionEvidence;
  error?: string;
}

export interface HardwareAudioCapabilities {
  webAudioSupported: boolean;
  audioContextState: 'running' | 'suspended' | 'closed' | 'unavailable';
  sampleRate: number;
  maxChannelCount: number;
  offlineAudioContextSupported: boolean;
  baseLatencyMs?: number;
  dspSynthesizerAvailable: boolean;
  neuralAudioEngineStatus: 'REQUIRES_ENGINE' | 'REAL_ENGINE' | 'UNAVAILABLE';
}
