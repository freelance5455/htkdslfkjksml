/**
 * GODEX P4.4 — Audio Quality Analyzer & Truth Gate
 * 
 * Provides rigorous quality gates for audio assets and mixes.
 * Generates verified telemetry and enforces the Zero-Fabrication invariant.
 */

import {
  AudioQualityMetrics,
  AudioExecutionEvidence,
  AudioTruthClassification
} from './audioTypes';
import { AudioAnalysisEngine } from './audioAnalysisEngine';

export class AudioQualityAnalyzer {
  private static instance: AudioQualityAnalyzer | null = null;

  public static getInstance(): AudioQualityAnalyzer {
    if (!AudioQualityAnalyzer.instance) {
      AudioQualityAnalyzer.instance = new AudioQualityAnalyzer();
    }
    return AudioQualityAnalyzer.instance;
  }

  /**
   * Analyzes an audio buffer and returns structured quality metrics
   */
  public analyzeBuffer(
    leftPcm: Float32Array,
    rightPcm?: Float32Array,
    sampleRate: number = 44100
  ): AudioQualityMetrics {
    return AudioAnalysisEngine.getInstance().analyzeAudioBuffer(leftPcm, rightPcm, sampleRate);
  }

  /**
   * Generates authoritative execution evidence for an audio operation
   */
  public createEvidence(
    operation: string,
    engineId: string,
    engineName: string,
    classification: AudioTruthClassification,
    durationMs: number,
    leftPcm: Float32Array,
    rightPcm?: Float32Array,
    sampleRate: number = 44100,
    parametersApplied: Record<string, any> = {},
    requiresEngineReason?: string
  ): AudioExecutionEvidence {
    const analysis = this.analyzeBuffer(leftPcm, rightPcm, sampleRate);
    const logs: string[] = [];
    const warnings: string[] = [];

    logs.push(`[${new Date().toISOString()}] Audio Operation: ${operation}`);
    logs.push(`Engine: ${engineName} (${classification})`);
    logs.push(`Sample Rate: ${sampleRate}Hz, Channels: ${rightPcm ? 2 : 1}, Duration: ${analysis.durationSec}s`);
    logs.push(`Peak: ${analysis.peakDb} dBFS, RMS: ${analysis.rmsDb} dBFS, Dynamic Range: ${analysis.dynamicRangeDb} dB`);
    logs.push(`Integrity: ${analysis.integrityPassed ? 'PASS' : 'FAIL'}, Quality Score: ${analysis.overallAudioQualityScore}/100`);

    if (analysis.isClippingDetected) {
      warnings.push(`Detected ${analysis.clippingCount} clipped samples exceeding 0 dBFS.`);
    }

    if (analysis.silenceRatio > 0.9) {
      warnings.push(`High silence ratio (${Math.round(analysis.silenceRatio * 100)}%) detected.`);
    }

    return {
      executionId: `audio-exec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      operation,
      engineId,
      engineName,
      truthClassification: classification,
      durationMs: Math.round(durationMs * 100) / 100,
      sampleRate,
      channelCount: rightPcm ? 2 : 1,
      durationSec: analysis.durationSec,
      qualityMetrics: analysis,
      parametersApplied,
      logs,
      warnings,
      requiresEngineReason,
      isVerified: analysis.integrityPassed && !analysis.isCorrupt
    };
  }
}
