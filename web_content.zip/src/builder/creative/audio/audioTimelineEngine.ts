/**
 * GODEX P4.4 — Unified Multi-Track Audio Timeline Engine
 * 
 * Manages full audio timeline hierarchy:
 * - Dedicated tracks (SFX, Foley, Dialogue, Ambience, Music Bed, Master Bus)
 * - Clip placement, splitting, trimming, gain staging, pan, and effects
 * - Non-destructive Undo / Redo history
 * - Master AV timeline synchronization integration
 */

import {
  AudioTimeline,
  AudioTimelineTrack,
  AudioClip,
  AudioSyncMarker,
  AudioEffectChain
} from './audioTypes';
import { SfxGenerationEngine } from './sfxGenerationEngine';
import { AudioSyncEngine } from './audioSyncEngine';

export class AudioTimelineEngine {
  private static instance: AudioTimelineEngine | null = null;
  private currentTimeline: AudioTimeline | null = null;
  private historyStack: AudioTimeline[] = [];
  private redoStack: AudioTimeline[] = [];

  public static getInstance(): AudioTimelineEngine {
    if (!AudioTimelineEngine.instance) {
      AudioTimelineEngine.instance = new AudioTimelineEngine();
    }
    return AudioTimelineEngine.instance;
  }

  /**
   * Creates a fresh multi-track audio timeline
   */
  public createTimeline(
    name: string = 'GODEX Master Audio Sequence',
    fps: 24 | 25 | 30 | 60 = 24,
    totalFrames: number = 120,
    sampleRate: number = 44100
  ): AudioTimeline {
    const durationSec = totalFrames / fps;

    const defaultEffects: AudioEffectChain = {
      gainDb: 0,
      pan: 0,
      eq: {
        enabled: false,
        lowGainDb: 0,
        midGainDb: 0,
        highGainDb: 0,
        lowFreqHz: 250,
        midFreqHz: 2500,
        highFreqHz: 6000
      },
      compressor: {
        enabled: false,
        thresholdDb: -16,
        ratio: 3.0,
        attackMs: 10,
        releaseMs: 100,
        makeupGainDb: 0,
        kneeDb: 3
      },
      limiter: {
        enabled: true,
        ceilingDb: -0.5,
        releaseMs: 50,
        softClip: true
      },
      reverbMix: 0,
      delayMix: 0,
      delayTimeSec: 0.2,
      delayFeedback: 0.3
    };

    const sfxTrack: AudioTimelineTrack = {
      id: 'track-audio-sfx',
      name: 'SFX & Impacts',
      type: 'SFX',
      muted: false,
      solo: false,
      locked: false,
      volume: 1.0,
      pan: 0,
      effects: { ...defaultEffects },
      clips: [],
      color: '#EC4899' // Pink
    };

    const foleyTrack: AudioTimelineTrack = {
      id: 'track-audio-foley',
      name: 'Foley & Movement',
      type: 'FOLEY',
      muted: false,
      solo: false,
      locked: false,
      volume: 1.0,
      pan: 0,
      effects: { ...defaultEffects },
      clips: [],
      color: '#F59E0B' // Amber
    };

    const dialogueTrack: AudioTimelineTrack = {
      id: 'track-audio-dialogue',
      name: 'Dialogue & Vocals',
      type: 'DIALOGUE',
      muted: false,
      solo: false,
      locked: false,
      volume: 1.0,
      pan: 0,
      effects: {
        ...defaultEffects,
        compressor: {
          ...defaultEffects.compressor,
          enabled: true,
          thresholdDb: -18,
          ratio: 4.0,
          makeupGainDb: 2
        }
      },
      clips: [],
      color: '#10B981' // Emerald
    };

    const ambienceTrack: AudioTimelineTrack = {
      id: 'track-audio-ambience',
      name: 'Ambience & Atmos',
      type: 'AMBIENCE',
      muted: false,
      solo: false,
      locked: false,
      volume: 0.8,
      pan: 0,
      effects: { ...defaultEffects, reverbMix: 0.2 },
      clips: [],
      color: '#6366F1' // Indigo
    };

    const musicTrack: AudioTimelineTrack = {
      id: 'track-audio-music',
      name: 'Music Bed',
      type: 'MUSIC_BED',
      muted: false,
      solo: false,
      locked: false,
      volume: 0.75,
      pan: 0,
      effects: { ...defaultEffects },
      clips: [],
      color: '#8B5CF6' // Purple
    };

    const timeline: AudioTimeline = {
      id: `audio-timeline-${Date.now()}`,
      name,
      fps,
      sampleRate,
      totalFrames,
      durationSec,
      currentFrame: 0,
      currentTimeSec: 0,
      isPlaying: false,
      loop: true,
      tracks: [sfxTrack, foleyTrack, dialogueTrack, ambienceTrack, musicTrack],
      masterBus: {
        volume: 1.0,
        pan: 0,
        eq: { ...defaultEffects.eq, enabled: true },
        compressor: { ...defaultEffects.compressor, enabled: true },
        limiter: { ...defaultEffects.limiter, enabled: true }
      },
      syncMarkers: []
    };

    this.currentTimeline = timeline;
    this.historyStack = [JSON.parse(JSON.stringify(timeline))];
    this.redoStack = [];
    return timeline;
  }

  public getTimeline(): AudioTimeline {
    if (!this.currentTimeline) {
      return this.createTimeline();
    }
    return this.currentTimeline;
  }

  public setTimeline(timeline: AudioTimeline): void {
    this.saveHistory();
    this.currentTimeline = timeline;
  }

  /**
   * Adds an audio clip to a specified track
   */
  public addClip(trackId: string, clip: AudioClip): AudioClip {
    this.saveHistory();
    const timeline = this.getTimeline();
    const track = timeline.tracks.find(t => t.id === trackId) || timeline.tracks[0];
    
    // Assign track ID to clip
    clip.trackId = track.id;
    track.clips.push(clip);

    return clip;
  }

  /**
   * Removes a clip by ID
   */
  public removeClip(clipId: string): boolean {
    this.saveHistory();
    const timeline = this.getTimeline();
    let removed = false;

    for (const track of timeline.tracks) {
      const idx = track.clips.findIndex(c => c.id === clipId);
      if (idx >= 0) {
        track.clips.splice(idx, 1);
        removed = true;
        break;
      }
    }

    return removed;
  }

  /**
   * Updates clip properties
   */
  public updateClip(clipId: string, updates: Partial<AudioClip>): AudioClip | null {
    this.saveHistory();
    const timeline = this.getTimeline();

    for (const track of timeline.tracks) {
      const clip = track.clips.find(c => c.id === clipId);
      if (clip) {
        Object.assign(clip, updates);
        return clip;
      }
    }

    return null;
  }

  /**
   * Adds a sync marker to the timeline
   */
  public addSyncMarker(marker: AudioSyncMarker): AudioSyncMarker {
    this.saveHistory();
    const timeline = this.getTimeline();
    timeline.syncMarkers.push(marker);
    return marker;
  }

  /**
   * Removes a sync marker
   */
  public removeSyncMarker(markerId: string): boolean {
    this.saveHistory();
    const timeline = this.getTimeline();
    const idx = timeline.syncMarkers.findIndex(m => m.id === markerId);
    if (idx >= 0) {
      timeline.syncMarkers.splice(idx, 1);
      return true;
    }
    return false;
  }

  /**
   * Seed authentic demonstration sound effects across tracks
   */
  public seedDemoClips(): void {
    const sfxEngine = SfxGenerationEngine.getInstance();
    const timeline = this.getTimeline();

    const sfxTrack = timeline.tracks.find(t => t.type === 'SFX');
    const ambienceTrack = timeline.tracks.find(t => t.type === 'AMBIENCE');

    if (sfxTrack && sfxTrack.clips.length === 0) {
      // 1. Cinematic Impact at Frame 12 (0.5s)
      const impactParams = sfxEngine.getDefaultParameters('IMPACT');
      const impactClip = sfxEngine.createAudioClipFromParams('Cinematic Impact', sfxTrack.id, 0.5, impactParams);
      sfxTrack.clips.push(impactClip);

      // 2. Whoosh Transition at Frame 48 (2.0s)
      const whooshParams = sfxEngine.getDefaultParameters('WHOOSH');
      const whooshClip = sfxEngine.createAudioClipFromParams('Energy Whoosh', sfxTrack.id, 2.0, whooshParams);
      sfxTrack.clips.push(whooshClip);
    }

    if (ambienceTrack && ambienceTrack.clips.length === 0) {
      // 3. Cyber Ambient Bed at Frame 0 (0.0s)
      const atmosParams = sfxEngine.getDefaultParameters('AMBIENCE');
      atmosParams.durationSec = Math.min(5.0, timeline.durationSec);
      const atmosClip = sfxEngine.createAudioClipFromParams('Cyber Atmos Bed', ambienceTrack.id, 0.0, atmosParams);
      ambienceTrack.clips.push(atmosClip);
    }

    // Seed Sync Markers
    if (timeline.syncMarkers.length === 0) {
      const syncEngine = AudioSyncEngine.getInstance();
      timeline.syncMarkers.push(syncEngine.createMarkerAtFrame(12, 'Primary Impact Hit', 'SFX_HIT', timeline.fps));
      timeline.syncMarkers.push(syncEngine.createMarkerAtFrame(48, 'Scene Transition', 'TRANSITION', timeline.fps));
    }
  }

  // Non-destructive Undo / Redo
  private saveHistory(): void {
    if (this.currentTimeline) {
      this.historyStack.push(JSON.parse(JSON.stringify(this.currentTimeline)));
      if (this.historyStack.length > 50) this.historyStack.shift();
      this.redoStack = [];
    }
  }

  public undo(): boolean {
    if (this.historyStack.length > 1) {
      const current = this.historyStack.pop();
      if (current) this.redoStack.push(current);
      const prev = this.historyStack[this.historyStack.length - 1];
      if (prev) {
        this.currentTimeline = JSON.parse(JSON.stringify(prev));
        return true;
      }
    }
    return false;
  }

  public redo(): boolean {
    if (this.redoStack.length > 0) {
      const next = this.redoStack.pop();
      if (next) {
        this.historyStack.push(JSON.parse(JSON.stringify(next)));
        this.currentTimeline = JSON.parse(JSON.stringify(next));
        return true;
      }
    }
    return false;
  }
}
