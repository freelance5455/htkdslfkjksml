/**
 * GODEX P4.0 — Generation Recovery & Fault Handling Engine
 * 
 * Analyzes runtime failures, network timeouts, out-of-memory errors, and missing dependencies
 * to produce actionable diagnostic remediation paths and bounded recovery attempts.
 * 
 * Invariants:
 * - Never enters an infinite retry loop (max 1 automatic recovery attempt).
 * - Enforces zero-fabrication: Never attempts to fake missing models or hardware.
 */

import {
  MediaWorkflowType,
  MediaJobParameters,
  CreativeExecutionErrorCode,
  MediaJob
} from './creativeStudioTypes';
import { AssemblyComposition } from './mediaAssemblyTypes';
import { HardwareAuditReport } from './hardwareAuditor';

export interface RenderRecoveryDiagnostic {
  rootCause: 
    | 'ENGINE_DISCONNECT'
    | 'MEMORY_PRESSURE'
    | 'TIMEOUT'
    | 'CANCELLED'
    | 'CORRUPT_ASSET'
    | 'CONTAINER_INVALID'
    | 'AV_SYNC_DRIFT'
    | 'VFX_FAILURE'
    | 'AUDIO_FAILURE'
    | 'EXPORT_FAILURE'
    | 'UNKNOWN';
  canRecover: boolean;
  shouldRetry: boolean;
  epistemicClassification: 'REAL_ENGINE' | 'LOCAL_DETERMINISTIC' | 'REQUIRES_ENGINE' | 'UNAVAILABLE';
  remedyDescription: string;
  actionableSteps: string[];
}

export interface RecoveryActionPlan {
  shouldRetry: boolean;
  errorCode: CreativeExecutionErrorCode;
  rootCause: 'NETWORK_DISCONNECT' | 'VRAM_OOM' | 'MISSING_NODE' | 'MISSING_MODEL' | 'TIMEOUT' | 'OUTPUT_CORRUPT' | 'UNKNOWN';
  remedyDescription: string;
  actionableSteps: string[];
  adjustedParameters?: Partial<MediaJobParameters>;
}

export class GenerationRecoveryEngine {
  private static instance: GenerationRecoveryEngine | null = null;
  private retryAttempts = new Map<string, number>();

  public static getInstance(): GenerationRecoveryEngine {
    if (!GenerationRecoveryEngine.instance) {
      GenerationRecoveryEngine.instance = new GenerationRecoveryEngine();
    }
    return GenerationRecoveryEngine.instance;
  }

  /**
   * Diagnoses an error message and generates a concrete remediation plan.
   */
  public diagnoseAndPlanRecovery(
    jobId: string,
    workflow: MediaWorkflowType,
    errorMsg: string,
    params: MediaJobParameters,
    hardware?: HardwareAuditReport
  ): RecoveryActionPlan {
    const attempts = this.retryAttempts.get(jobId) || 0;
    const lower = errorMsg.toLowerCase();

    // 1. Network / Disconnection
    if (lower.includes('econnrefused') || lower.includes('failed to fetch') || lower.includes('not reachable') || lower.includes('requires a connected')) {
      return {
        shouldRetry: false,
        errorCode: 'REQUIRES_ENGINE',
        rootCause: 'NETWORK_DISCONNECT',
        remedyDescription: 'ComfyUI inference server is not responding at the configured endpoint.',
        actionableSteps: [
          'Verify ComfyUI is running on 127.0.0.1:8188.',
          'Start ComfyUI using: python main.py --listen 127.0.0.1 --port 8188 --enable-cors-header',
          'Check firewall or network permissions.'
        ]
      };
    }

    // 2. Out of Memory (VRAM OOM)
    if (lower.includes('out of memory') || lower.includes('cuda out of memory') || lower.includes('vram exhausted') || lower.includes('allocation on device')) {
      const canDownscale = params.resolution === '4K' || params.resolution === '1080p';
      const adjustedRes = params.resolution === '4K' ? '1080p' : '720p';

      if (canDownscale && attempts < 1) {
        this.retryAttempts.set(jobId, attempts + 1);
        return {
          shouldRetry: true,
          errorCode: 'RESOURCE_EXHAUSTED',
          rootCause: 'VRAM_OOM',
          remedyDescription: `GPU VRAM exhausted during execution. Automatically downscaling from ${params.resolution} to ${adjustedRes}.`,
          actionableSteps: [
            `Downscaling target resolution to ${adjustedRes}.`,
            'Reducing guidance steps to 20 for memory safety.',
            'Consider launching ComfyUI with --lowvram or --medvram flags.'
          ],
          adjustedParameters: {
            resolution: adjustedRes,
            guidanceSteps: Math.min(20, params.guidanceSteps || 25)
          }
        };
      }

      return {
        shouldRetry: false,
        errorCode: 'RESOURCE_LIMIT',
        rootCause: 'VRAM_OOM',
        remedyDescription: 'Host GPU has insufficient VRAM to complete the requested neural generation.',
        actionableSteps: [
          'Switch to 720p resolution preset.',
          'Enable ComfyUI low VRAM mode (--lowvram).',
          'Close background VRAM-intensive applications.'
        ]
      };
    }

    // 3. Missing Custom Node
    if (lower.includes('node not found') || lower.includes('unknown class_type') || lower.includes('missing custom node') || lower.includes('class_type')) {
      const nodeMatch = errorMsg.match(/class_type\s+['"]?([A-Za-z0-9_]+)['"]?/i);
      const nodeName = nodeMatch ? nodeMatch[1] : 'required custom node';

      return {
        shouldRetry: false,
        errorCode: 'REQUIRES_ENGINE',
        rootCause: 'MISSING_NODE',
        remedyDescription: `ComfyUI missing custom node: ${nodeName}`,
        actionableSteps: [
          `Open ComfyUI-Manager -> Install Custom Nodes.`,
          `Search and install the package containing '${nodeName}'.`,
          'Restart ComfyUI server after node installation.'
        ]
      };
    }

    // 4. Missing Model Checkpoint
    if (lower.includes('model not found') || lower.includes('checkpoint not found') || lower.includes('safetensors not found') || lower.includes('file not found')) {
      return {
        shouldRetry: false,
        errorCode: 'REQUIRES_ENGINE',
        rootCause: 'MISSING_MODEL',
        remedyDescription: 'The requested neural checkpoint or LoRA model file was not found in ComfyUI models/ directory.',
        actionableSteps: [
          'Verify model files are located in ComfyUI/models/checkpoints or models/upscale_models.',
          'Trigger ModelManager refresh from Studio Diagnostics.',
          'Download standard SDXL base or SVD model checkpoints.'
        ]
      };
    }

    // 5. Execution Timeout
    if (lower.includes('timeout') || lower.includes('timed out')) {
      return {
        shouldRetry: false,
        errorCode: 'TIMEOUT',
        rootCause: 'TIMEOUT',
        remedyDescription: 'Generation job exceeded timeout threshold while waiting for ComfyUI execution completion.',
        actionableSteps: [
          'Check ComfyUI server console logs for queue stalls.',
          'Reduce duration or resolution for faster compute.',
          'Verify host GPU is not throttled or overloaded.'
        ]
      };
    }

    // 6. Generic / Unknown Error
    return {
      shouldRetry: false,
      errorCode: 'EXECUTION_ERROR',
      rootCause: 'UNKNOWN',
      remedyDescription: `Execution failed: ${errorMsg}`,
      actionableSteps: [
        'Inspect ComfyUI terminal output for Python tracebacks.',
        'Validate input parameters and media assets.',
        'Retry job with default parameters.'
      ]
    };
  }

  public clearRetryRecord(jobId: string): void {
    this.retryAttempts.delete(jobId);
  }

  /**
   * Diagnoses error message and returns an actionable recovery plan.
   */
  public diagnoseAndPlan(
    errorMsg: string,
    workflow: MediaWorkflowType,
    params: Partial<MediaJobParameters> = {},
    engineId?: string
  ): {
    category: 'OOM_VRAM' | 'DISCONNECTED_ENGINE' | 'MISSING_NODE' | 'TIMEOUT' | 'UNKNOWN';
    canRecover: boolean;
    action: string;
    adjustedParameters?: Partial<MediaJobParameters>;
    diagnostics: string[];
  } {
    const lower = errorMsg.toLowerCase();
    const currentRes = params.resolution || '4K';

    if (lower.includes('out of memory') || lower.includes('cuda out of memory') || lower.includes('oom') || lower.includes('vram')) {
      const newRes = currentRes === '4K' ? '1080p' : '720p';
      return {
        category: 'OOM_VRAM',
        canRecover: true,
        action: 'DOWNSCALE_RESOLUTION',
        adjustedParameters: {
          ...params,
          resolution: newRes,
          durationSec: params.durationSec ? Math.min(params.durationSec, 5) : 5
        },
        diagnostics: [`GPU Out-of-Memory detected. Downscaling resolution from ${currentRes} to ${newRes}.`]
      };
    }

    if (lower.includes('disconnected') || lower.includes('connection refused') || lower.includes('econnrefused') || lower.includes('requires')) {
      return {
        category: 'DISCONNECTED_ENGINE',
        canRecover: false,
        action: 'PROMPT_ENGINE_ENDPOINT',
        adjustedParameters: params,
        diagnostics: ['Engine endpoint is offline or disconnected.']
      };
    }

    if (lower.includes('missing node') || lower.includes('node not found') || lower.includes('custom node')) {
      return {
        category: 'MISSING_NODE',
        canRecover: false,
        action: 'INSTALL_REQUIRED_CUSTOM_NODES',
        adjustedParameters: params,
        diagnostics: ['Required ComfyUI custom nodes are missing from local environment.']
      };
    }

    return {
      category: 'UNKNOWN',
      canRecover: false,
      action: 'FALLBACK_BROWSER_NATIVE',
      adjustedParameters: params,
      diagnostics: [errorMsg]
    };
  }

  /**
   * P4.6: Diagnoses render pipeline failures and determines deterministic remediation.
   */
  public diagnoseRenderFailure(
    errorMsg: string,
    composition: AssemblyComposition,
    retryAttempt: number = 0
  ): RenderRecoveryDiagnostic {
    const lower = errorMsg.toLowerCase();
    const canRetry = retryAttempt < 2;

    if (lower.includes('requires_engine') || lower.includes('connected') || lower.includes('remote') || lower.includes('comfyui')) {
      return {
        rootCause: 'ENGINE_DISCONNECT',
        canRecover: false,
        shouldRetry: false,
        epistemicClassification: 'REQUIRES_ENGINE',
        remedyDescription: 'Operation requires external neural rendering engine which is disconnected.',
        actionableSteps: [
          'Verify ComfyUI server is running on 127.0.0.1:8188.',
          'Check neural pipeline connection settings in Diagnostics.',
          'Fallback to local procedural DSP synthesis where available.'
        ]
      };
    }

    if (lower.includes('out of memory') || lower.includes('memory') || lower.includes('allocation') || lower.includes('resource_limit')) {
      return {
        rootCause: 'MEMORY_PRESSURE',
        canRecover: canRetry,
        shouldRetry: canRetry,
        epistemicClassification: 'LOCAL_DETERMINISTIC',
        remedyDescription: 'System memory pressure detected during frame rendering or audio mixing pass.',
        actionableSteps: [
          'Enforce chunked batch processing with smaller frame batches (6-12 frames).',
          'Release intermediate audio and video buffers after each stage.',
          'Consider reducing resolution from 4K to 1080p if memory exceeds host ceiling.'
        ]
      };
    }

    if (lower.includes('timeout') || lower.includes('timed out')) {
      return {
        rootCause: 'TIMEOUT',
        canRecover: canRetry,
        shouldRetry: canRetry,
        epistemicClassification: 'LOCAL_DETERMINISTIC',
        remedyDescription: 'Render stage exceeded maximum execution deadline.',
        actionableSteps: [
          'Increase stage timeout budget for long-duration compositions.',
          'Resume execution from last recorded stage checkpoint.'
        ]
      };
    }

    if (lower.includes('cancelled') || lower.includes('aborted')) {
      return {
        rootCause: 'CANCELLED',
        canRecover: false,
        shouldRetry: false,
        epistemicClassification: 'LOCAL_DETERMINISTIC',
        remedyDescription: 'Render operation was cancelled by user signal.',
        actionableSteps: [
          'Checkpoint state preserved. Render can be resumed when requested.'
        ]
      };
    }

    if (lower.includes('corrupt') || lower.includes('nan') || lower.includes('infinity')) {
      return {
        rootCause: 'CORRUPT_ASSET',
        canRecover: false,
        shouldRetry: false,
        epistemicClassification: 'LOCAL_DETERMINISTIC',
        remedyDescription: 'Corrupt audio or video sample stream detected with NaN/Infinity values.',
        actionableSteps: [
          'Inspect audio oscillator and gain staging parameters.',
          'Ensure master limiter ceiling is configured properly (-0.5 dBFS).'
        ]
      };
    }

    if (lower.includes('drift') || lower.includes('av sync') || lower.includes('sync')) {
      return {
        rootCause: 'AV_SYNC_DRIFT',
        canRecover: canRetry,
        shouldRetry: canRetry,
        epistemicClassification: 'LOCAL_DETERMINISTIC',
        remedyDescription: 'Sub-frame audio-video timing drift exceeded tolerance threshold.',
        actionableSteps: [
          'Re-align audio sample boundaries using RenderTimelineEngine frame quantization.'
        ]
      };
    }

    if (lower.includes('vfx') || lower.includes('keying') || lower.includes('matte')) {
      return {
        rootCause: 'VFX_FAILURE',
        canRecover: canRetry,
        shouldRetry: canRetry,
        epistemicClassification: 'LOCAL_DETERMINISTIC',
        remedyDescription: 'VFX compositing or particle rasterization error.',
        actionableSteps: [
          'Validate alpha matte coordinates and particle bounds.'
        ]
      };
    }

    if (lower.includes('export') || lower.includes('encoder') || lower.includes('container') || lower.includes('mux')) {
      return {
        rootCause: 'EXPORT_FAILURE',
        canRecover: false,
        shouldRetry: false,
        epistemicClassification: 'LOCAL_DETERMINISTIC',
        remedyDescription: 'Media container muxing or codec binary serialization failure.',
        actionableSteps: [
          'Switch to WAV or WebM browser-native export container.'
        ]
      };
    }

    return {
      rootCause: 'UNKNOWN',
      canRecover: canRetry,
      shouldRetry: canRetry,
      epistemicClassification: 'LOCAL_DETERMINISTIC',
      remedyDescription: `Render failure: ${errorMsg}`,
      actionableSteps: [
        'Inspect timeline tracks for invalid parameters.',
        'Review diagnostic logs and retry from checkpoint.'
      ]
    };
  }
}
