/**
 * GODEX P4.8 — Keyframe & Multi-Shot Planning Engine
 * 
 * Coordinates multi-shot narrative consistency, shot sequencing,
 * and physical cinematic camera specifications:
 * - Scene decomposition into structured shots
 * - Physical camera bodies, lenses, focal lengths, aperture, and focus distance
 * - Optical simulation parameter generation (FOV, DOF, CoC, Bokeh, Distortion, Vignette)
 * - Keyframe prompt guidance & reference anchors
 * - Spatial continuity validation across multi-shot sequences
 * - Temporal assembly transition strategies
 */

import {
  ShotPlan,
  MediaJobParameters,
  CameraMovementType,
  VideoStylePreset
} from './creativeStudioTypes';
import {
  CameraShotSpec,
  ShotArchetype,
  CameraContinuityReport
} from './camera/cinematicCameraTypes';
import { CAMERA_BODIES, CINE_LENSES } from './camera/cameraBodiesAndLenses';
import { OpticalSimulationEngine } from './camera/opticalSimulationEngine';
import { CameraContinuityEngine } from './camera/cameraContinuityEngine';
import { PromptCameraExtractor } from './camera/promptCameraExtractor';

export class ShotPlanningEngine {
  private static instance: ShotPlanningEngine | null = null;
  private opticalEngine: OpticalSimulationEngine;
  private continuityEngine: CameraContinuityEngine;
  private promptExtractor: PromptCameraExtractor;

  private constructor() {
    this.opticalEngine = OpticalSimulationEngine.getInstance();
    this.continuityEngine = CameraContinuityEngine.getInstance();
    this.promptExtractor = PromptCameraExtractor.getInstance();
  }

  public static getInstance(): ShotPlanningEngine {
    if (!ShotPlanningEngine.instance) {
      ShotPlanningEngine.instance = new ShotPlanningEngine();
    }
    return ShotPlanningEngine.instance;
  }

  /**
   * Plans a structured multi-shot sequence for a given duration (Legacy P3.4 compatibility).
   */
  public planScene(params: MediaJobParameters, totalDurationSec: number = 6): ShotPlan {
    const sceneId = `scene-${Date.now().toString(36)}`;
    const style: VideoStylePreset = params.style || 'CINEMATIC';
    const primaryCamera: CameraMovementType = params.cameraMovement || 'DOLLY_IN';

    const numShots = totalDurationSec > 8 ? 2 : 1;
    const shotDuration = totalDurationSec / numShots;

    const shots = [];
    for (let i = 0; i < numShots; i++) {
      const shotNumber = i + 1;
      const cameraMovement: CameraMovementType = i === 0 ? primaryCamera : 'TRACKING_SHOT';
      const keyframes = [
        {
          timestampSec: 0,
          promptGuide: `Shot ${shotNumber} start: ${params.prompt || 'Scene establishing framing'}`
        },
        {
          timestampSec: shotDuration / 2,
          promptGuide: `Shot ${shotNumber} midpoint: peak action / movement`
        },
        {
          timestampSec: shotDuration,
          promptGuide: `Shot ${shotNumber} resolution: settling framing`
        }
      ];

      shots.push({
        shotId: `${sceneId}-shot-${shotNumber}`,
        shotNumber,
        durationSec: shotDuration,
        cameraMovement,
        subjectFocus: 'Primary focal character / asset',
        lighting: 'Three-point key lighting balanced with ambient fill',
        keyframes,
        continuityRules: {
          character: 'Consistent identity anchor with reference facial embedding',
          wardrobe: 'Maintained color and silhouette across shot boundaries',
          environment: 'Coherent spatial geometry and lighting direction',
          lighting: 'Matched key-to-fill ratio and color temperature',
          colorPalette: ['#1C1C24', '#424866', '#8A96C2', '#FFFFFF']
        }
      });
    }

    return {
      sceneId,
      shots,
      totalDurationSec,
      temporalAssemblyStrategy: numShots > 1 ? 'MOTION_MATCH' : 'DIRECT_CUT'
    };
  }

  /**
   * Plans a comprehensive cinematic multi-shot sequence with complete physical camera,
   * lens, optical simulation, and spatial continuity parameters.
   */
  public planCinematicScene(
    params: MediaJobParameters,
    options?: {
      cameraBodyId?: string;
      lensId?: string;
      focalLengthMm?: number;
      apertureFStop?: number;
      focusDistanceMeters?: number;
      iso?: number;
      totalDurationSec?: number;
    }
  ): {
    sceneId: string;
    shots: CameraShotSpec[];
    continuityReport: CameraContinuityReport;
    totalDurationSec: number;
  } {
    const sceneId = `cine-scene-${Date.now().toString(36)}`;
    const rawPrompt = params.prompt || '';
    const totalDurationSec = options?.totalDurationSec || params.durationSec || 6;

    // 1. Extract natural language intent from prompt
    const promptExtraction = this.promptExtractor.extractCameraIntent(rawPrompt);

    // 2. Resolve Camera Body
    const cameraBodyId = options?.cameraBodyId || (
      promptExtraction.cameraBodyHint?.toLowerCase().includes('red') ? 'red-v-raptor-vv' :
      promptExtraction.cameraBodyHint?.toLowerCase().includes('imax') ? 'imax-65mm-15perf' :
      promptExtraction.cameraBodyHint?.toLowerCase().includes('sony') ? 'sony-venice-2' :
      'arri-alexa-mini-lf'
    );
    const cameraBody = CAMERA_BODIES[cameraBodyId] || this.opticalEngine.getDefaultCamera();

    // 3. Resolve Lens & Focal length
    const resolvedFocalLength = options?.focalLengthMm || (
      typeof promptExtraction.focalLengthMm === 'number' ? promptExtraction.focalLengthMm :
      (params.cameraMovement === 'ORBIT_360' || params.cameraMovement === 'DOLLY_OUT') ? 24 :
      50
    );

    const lensId = options?.lensId || (
      resolvedFocalLength <= 21 ? 'leica-summicron-c-21' :
      resolvedFocalLength <= 28 ? 'arri-master-prime-18' :
      resolvedFocalLength <= 35 ? 'arri-master-prime-35' :
      resolvedFocalLength <= 60 ? 'zeiss-supreme-50' :
      resolvedFocalLength <= 85 ? 'cooke-s4i-85' :
      'arri-macro-100'
    );
    const lens = CINE_LENSES[lensId] || this.opticalEngine.getDefaultLens();

    // 4. Resolve Aperture & Focus
    const apertureFStop = options?.apertureFStop || (
      typeof promptExtraction.apertureFStop === 'number' ? promptExtraction.apertureFStop :
      lens.maxApertureFStop || 2.0
    );

    const focusDistanceMeters = options?.focusDistanceMeters || 2.5;
    const iso = options?.iso || 800;

    // 5. Determine Number of Shots (1 to 3 depending on duration)
    const numShots = totalDurationSec >= 12 ? 3 : totalDurationSec >= 6 ? 2 : 1;
    const shotDuration = totalDurationSec / numShots;

    const shots: CameraShotSpec[] = [];

    // Archetype progression for multi-shot
    const archetypeProgression: ShotArchetype[] = [
      (promptExtraction.archetype !== 'UNKNOWN' ? promptExtraction.archetype : 'MS'),
      'MCU',
      'CU'
    ];

    for (let i = 0; i < numShots; i++) {
      const shotNumber = i + 1;
      const shotArchetype = archetypeProgression[i] || 'MS';

      // Slight focal length progression for coherent cinematography
      const shotFocalLength = i === 0 ? resolvedFocalLength :
        (i === 1 ? Math.min(85, Math.round(resolvedFocalLength * 1.5)) :
        Math.min(100, Math.round(resolvedFocalLength * 2.0)));

      const shotMovement: CameraMovementType = i === 0
        ? (params.cameraMovement || (promptExtraction.cameraMovement !== 'UNKNOWN' ? promptExtraction.cameraMovement : 'DOLLY_IN'))
        : (i === 1 ? 'TRACKING_SHOT' : 'STATIC');

      const shotFocusDistance = Math.max(0.8, focusDistanceMeters - (i * 0.6));

      const opticalParams = this.opticalEngine.computeOpticalParameters(
        cameraBody,
        lens,
        shotFocalLength,
        apertureFStop,
        shotFocusDistance,
        iso
      );

      const shotSpec: CameraShotSpec = {
        shotId: `${sceneId}-shot-${shotNumber}`,
        sceneId,
        shotNumber,
        archetype: shotArchetype,
        name: `Shot ${shotNumber} — ${shotArchetype} (${shotFocalLength}mm f/${apertureFStop})`,
        durationSec: shotDuration,
        cameraBody,
        lens,
        focalLengthMm: shotFocalLength,
        apertureFStop,
        focusDistanceMeters: shotFocusDistance,
        shutterAngleDeg: cameraBody.defaultShutterAngleDeg,
        iso,
        fps: 24,
        whiteBalanceKelvin: 5600,
        whiteBalanceTint: 0,
        pose: {
          heightMeters: 1.6 - (i * 0.1),
          distanceToSubjectMeters: shotFocusDistance,
          panDeg: i === 0 ? 0 : (i === 1 ? -12 : 8),
          tiltDeg: i === 0 ? -2 : 0,
          rollDeg: 0
        },
        kinematics: {
          movementType: shotMovement,
          intensity: params.subjectMotionIntensity || 5,
          speedCurve: 'EASE_IN_OUT',
          velocityMetersPerSec: 0.4
        },
        composition: {
          rule: 'RULE_OF_THIRDS',
          subjectScreenX: i === 1 ? 0.6 : 0.5,
          subjectScreenY: 0.5,
          headroomPercent: 18,
          leadRoomPercent: 25
        },
        lightingSetup: 'Cinematic three-point lighting (5600K Key, 4300K Fill, 6500K Rim)',
        subjectDescription: rawPrompt || 'Cinematic Subject',
        opticalSimulation: opticalParams,
        transitionIntent: i === 0 ? 'DIRECT_CUT' : 'MATCH_CUT',
        provenance: {
          shotId: `${sceneId}-shot-${shotNumber}`,
          generationTimestamp: Date.now(),
          cameraBodyId: cameraBody.id,
          cameraBodyName: cameraBody.name,
          lensId: lens.id,
          lensName: lens.name,
          focalLengthMm: shotFocalLength,
          apertureFStop,
          fps: 24,
          shutterAngleDeg: cameraBody.defaultShutterAngleDeg,
          iso,
          resolution: params.resolution || '1080p',
          aspectRatio: params.aspectRatio || '16:9',
          engineClassification: 'LOCAL_DETERMINISTIC',
          deterministicCalculationsVerified: true
        }
      };

      shots.push(shotSpec);
    }

    // 6. Audit Multi-Shot Spatial Continuity
    const continuityReport = this.continuityEngine.auditSequenceContinuity(shots);

    return {
      sceneId,
      shots,
      continuityReport,
      totalDurationSec
    };
  }
}
