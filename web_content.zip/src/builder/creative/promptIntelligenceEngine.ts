/**
 * GODEX P4.2 — Prompt Intelligence Engine & Structured Prompt Planner
 * 
 * Performs deterministic lexical semantic extraction to structure any natural language prompt
 * into a professional multi-dimensional cinematography generation plan:
 * 1. Subject
 * 2. Environment
 * 3. Action
 * 4. Lighting
 * 5. Camera trajectory
 * 6. Optical Lens
 * 7. Composition
 * 8. Kinetic Motion
 * 9. Temporal Behavior
 * 10. Art Style
 * 11. Color Grading Palette
 * 12. Atmosphere & Particles
 * 13. Negative Constraints
 * 
 * Invariants:
 * - Preserves the user's original raw prompt untouched.
 * - Enriches graph synthesis without overriding explicit user directives.
 */

import {
  StructuredGenerationPlan,
  VideoStylePreset,
  CameraMovementType
} from './creativeStudioTypes';
import { GENERATION_PRESETS } from './generationPresets';
import { PromptCameraExtractor } from './camera/promptCameraExtractor';
import { PromptCameraExtraction } from './camera/cinematicCameraTypes';

export class PromptIntelligenceEngine {
  private static instance: PromptIntelligenceEngine | null = null;
  private cameraExtractor: PromptCameraExtractor;

  private constructor() {
    this.cameraExtractor = PromptCameraExtractor.getInstance();
  }

  public static getInstance(): PromptIntelligenceEngine {
    if (!PromptIntelligenceEngine.instance) {
      PromptIntelligenceEngine.instance = new PromptIntelligenceEngine();
    }
    return PromptIntelligenceEngine.instance;
  }

  /**
   * Directly extracts structured camera and optical intent from natural language.
   */
  public extractPromptCamera(rawPrompt: string): PromptCameraExtraction {
    return this.cameraExtractor.extractCameraIntent(rawPrompt);
  }

  /**
   * Plans and breaks down a raw user prompt into a structured generation blueprint.
   */
  public analyzeAndPlan(
    rawPrompt: string,
    preset?: VideoStylePreset,
    explicitCamera?: CameraMovementType
  ): StructuredGenerationPlan {
    const text = (rawPrompt || '').trim();
    const lower = text.toLowerCase();

    // 1. Detect Subject
    const subject = this.extractSubject(text, lower);

    // 2. Detect Environment
    const environment = this.extractEnvironment(text, lower);

    // 3. Detect Action
    const action = this.extractAction(text, lower);

    // 4. Detect Lighting
    const lighting = this.extractLighting(text, lower, preset);

    // 5. Detect Camera & Lens
    const camera = this.extractCamera(text, lower, explicitCamera);
    const lens = this.extractLens(text, lower, preset);

    // 6. Detect Composition & Framing
    const composition = this.extractComposition(text, lower);

    // 7. Detect Motion & Temporal Dynamics
    const motion = this.extractMotion(text, lower);
    const temporalBehavior = this.extractTemporalBehavior(text, lower);

    // 8. Style & Palette
    const style = this.extractStyle(text, lower, preset);
    const color = this.extractColor(text, lower, preset);
    const atmosphere = this.extractAtmosphere(text, lower);

    // 9. Negative Constraints
    const negativeConstraints = this.generateNegativeConstraints(lower, preset);

    // 10. Suggested Preset
    const suggestedPreset = preset || this.detectBestPreset(lower);

    return {
      originalPrompt: rawPrompt,
      subject,
      environment,
      action,
      lighting,
      camera,
      lens,
      composition,
      motion,
      temporalBehavior,
      style,
      color,
      atmosphere,
      negativeConstraints,
      suggestedPreset
    };
  }

  /**
   * Synthesizes an optimized, enriched prompt string for diffusion CLIP encoders.
   */
  public buildEnrichedPrompt(plan: StructuredGenerationPlan): string {
    const elements: string[] = [];

    if (plan.subject) elements.push(plan.subject);
    if (plan.action) elements.push(plan.action);
    if (plan.environment) elements.push(plan.environment);
    if (plan.composition) elements.push(plan.composition);
    if (plan.lighting) elements.push(plan.lighting);
    if (plan.camera) elements.push(plan.camera);
    if (plan.lens) elements.push(plan.lens);
    if (plan.color) elements.push(plan.color);
    if (plan.atmosphere) elements.push(plan.atmosphere);
    if (plan.style) elements.push(plan.style);

    return elements.filter(Boolean).join(', ');
  }

  // --- Private Extraction Helpers ---

  private extractSubject(text: string, lower: string): string {
    if (!text) return 'Cinematic subject';
    // Match common subject markers
    const subjectPatterns = [
      /(?:a|an|the)\s+([a-zA-Z0-9\s-]+?)(?:\s+(?:in|at|on|walking|running|standing|sitting|flying|looking|with|under|over|surrounded)|$|,)/i,
      /^([a-zA-Z0-9\s-]+?)(?:\s+(?:in|at|on|walking|running|standing|sitting)|$|,)/i
    ];

    for (const pattern of subjectPatterns) {
      const match = text.match(pattern);
      if (match && match[1] && match[1].trim().length > 2) {
        return match[1].trim();
      }
    }

    const firstClause = text.split(/[,.;]/)[0]?.trim();
    return firstClause || text;
  }

  private extractEnvironment(text: string, lower: string): string {
    const envKeywords = [
      'cyberpunk city', 'neon metropolis', 'futuristic skyline', 'dense forest',
      'misty mountains', 'desert dunes', 'ocean waves', 'underwater reef',
      'modern minimalist apartment', 'cozy coffee shop', 'abandoned warehouse',
      'space station interior', 'deep space', 'alien planet', 'sunset beach',
      'rainy alleyway', 'historic cathedral', 'art studio', 'industrial laboratory'
    ];

    for (const kw of envKeywords) {
      if (lower.includes(kw)) {
        return kw;
      }
    }

    const inMatch = text.match(/(?:in|at|on|inside|surrounded by)\s+(?:a\s+|an\s+|the\s+)?([a-zA-Z0-9\s-]+?)(?:,|\.|$)/i);
    if (inMatch && inMatch[1] && inMatch[1].trim().length > 3) {
      return inMatch[1].trim();
    }

    return 'Cinematic environment with detailed background architecture';
  }

  private extractAction(text: string, lower: string): string {
    const actionKeywords = [
      'walking towards camera', 'running at full speed', 'looking out window',
      'turning around slowly', 'floating in zero gravity', 'exploding into particles',
      'dancing gracefully', 'holding an artifact', 'speaking intensely',
      'transforming dynamically', 'breathing softly', 'glancing sideways'
    ];

    for (const kw of actionKeywords) {
      if (lower.includes(kw)) {
        return kw;
      }
    }

    const verbMatch = text.match(/\b(walking|running|standing|sitting|flying|floating|moving|turning|looking|gazing|reaching|speaking|shouting|falling)\b[a-zA-Z0-9\s-]*/i);
    if (verbMatch) {
      return verbMatch[0].trim();
    }

    return 'Subtle natural lifelike motion';
  }

  private extractLighting(text: string, lower: string, preset?: VideoStylePreset): string {
    if (lower.includes('golden hour')) return 'Warm golden hour sunlight with soft long shadows';
    if (lower.includes('neon') || lower.includes('cyberpunk')) return 'High-contrast dual-tone neon backlighting (cyan & magenta)';
    if (lower.includes('chiaroscuro') || lower.includes('dramatic')) return 'Dramatic chiaroscuro high-contrast rim lighting';
    if (lower.includes('softbox') || lower.includes('studio')) return 'Diffused commercial studio softbox lighting with subtle fill';
    if (lower.includes('overcast') || lower.includes('natural')) return 'Soft overcast daylight with natural ambient roll-off';
    if (lower.includes('moonlight') || lower.includes('night')) return 'Cool cinematic moonlight with subtle rim illumination';

    if (preset && GENERATION_PRESETS[preset]) {
      return GENERATION_PRESETS[preset].promptEnhancements.lightingCues.join(', ');
    }

    return 'Volumetric cinematic lighting with soft rim accent';
  }

  private extractCamera(text: string, lower: string, explicitCamera?: CameraMovementType): string {
    if (explicitCamera && explicitCamera !== 'STATIC') {
      const formatted = explicitCamera.replace(/_/g, ' ').toLowerCase();
      return `Controlled cinematic ${formatted} camera motion`;
    }

    if (lower.includes('dolly in') || lower.includes('push in')) return 'Smooth dolly-in camera movement';
    if (lower.includes('dolly out') || lower.includes('pull out')) return 'Smooth dolly-out camera movement';
    if (lower.includes('orbit') || lower.includes('360')) return 'Sweeping circular orbit trajectory';
    if (lower.includes('pan left')) return 'Steady horizontal left pan';
    if (lower.includes('pan right')) return 'Steady horizontal right pan';
    if (lower.includes('tilt up')) return 'Vertical tilt-up movement';
    if (lower.includes('tilt down')) return 'Vertical tilt-down movement';
    if (lower.includes('crane') || lower.includes('jib')) return 'High-angle crane elevation move';
    if (lower.includes('tracking') || lower.includes('follow')) return 'Dynamic tracking shot following subject velocity';
    if (lower.includes('handheld')) return 'Organic natural handheld camera motion with subtle human sway';

    return 'Smooth steady stabilized camera framing';
  }

  private extractLens(text: string, lower: string, preset?: VideoStylePreset): string {
    if (lower.includes('anamorphic')) return '35mm anamorphic prime lens with optical oval bokeh';
    if (lower.includes('wide angle') || lower.includes('16mm') || lower.includes('24mm')) return 'Wide 24mm f/2.0 cinematic lens with expansive perspective';
    if (lower.includes('macro') || lower.includes('close up')) return '100mm macro prime lens f/2.8 with tack-sharp focal plane';
    if (lower.includes('telephoto') || lower.includes('85mm')) return '85mm portrait prime lens f/1.4 with creamy background separation';
    if (lower.includes('fisheye')) return '12mm ultra-wide fisheye lens';

    if (preset && GENERATION_PRESETS[preset]) {
      return GENERATION_PRESETS[preset].promptEnhancements.lensCues.join(', ');
    }

    return '50mm prime f/1.4 lens with natural optical depth of field';
  }

  private extractComposition(text: string, lower: string): string {
    if (lower.includes('rule of thirds')) return 'Rule of thirds composition with leading visual lines';
    if (lower.includes('centered') || lower.includes('symmetric')) return 'Perfect symmetrical central framing';
    if (lower.includes('extreme close up') || lower.includes('macro')) return 'Extreme close-up macro composition focusing on micro-details';
    if (lower.includes('wide shot') || lower.includes('establishing')) return 'Grand wide establishing composition with expansive scale';
    if (lower.includes('low angle')) return 'Intimidating low-angle heroic perspective';
    if (lower.includes('high angle') || lower.includes('bird eye')) return 'High-angle birds-eye perspective';

    return 'Cinematic rule-of-thirds framing with clear foreground/background depth';
  }

  private extractMotion(text: string, lower: string): string {
    if (lower.includes('fast') || lower.includes('explosion') || lower.includes('action')) {
      return 'High kinetic energy with fluid acceleration curves and motion clarity';
    }
    if (lower.includes('slow motion') || lower.includes('slow-mo')) {
      return 'Gentle ultra-slow motion temporal rendering (sub-frame interpolation)';
    }
    return 'Organic natural motion with balanced velocity and zero stutter';
  }

  private extractTemporalBehavior(text: string, lower: string): string {
    return 'Rigid geometric temporal stability, strict identity preservation across frames, flicker-free optical flow';
  }

  private extractStyle(text: string, lower: string, preset?: VideoStylePreset): string {
    if (preset && GENERATION_PRESETS[preset]) {
      return GENERATION_PRESETS[preset].promptEnhancements.styleCues.join(', ');
    }
    if (lower.includes('anime') || lower.includes('manga')) return 'High quality modern anime illustration style';
    if (lower.includes('3d') || lower.includes('render')) return 'Raytraced 3D render with physically based shading';
    return 'Masterpiece photorealistic cinematography, 8k resolution, award-winning visual production';
  }

  private extractColor(text: string, lower: string, preset?: VideoStylePreset): string {
    if (lower.includes('neon') || lower.includes('cyberpunk')) return 'Vibrant cyan, magenta, and deep indigo palette with high saturation';
    if (lower.includes('monochrome') || lower.includes('black and white') || lower.includes('noir')) return 'High-contrast monochrome black & white with smooth silver tonality';
    if (lower.includes('pastel')) return 'Soft pastel tones with gentle low-saturation harmony';
    if (lower.includes('warm') || lower.includes('golden')) return 'Warm amber and golden hues with rich deep shadows';
    if (lower.includes('cool') || lower.includes('winter') || lower.includes('space')) return 'Cool steel blues and stark white accents';

    return 'Professionally balanced cinematic color grading with rich dynamic range';
  }

  private extractAtmosphere(text: string, lower: string): string {
    if (lower.includes('fog') || lower.includes('mist')) return 'Volumetric fog and atmospheric haze particles';
    if (lower.includes('rain') || lower.includes('wet')) return 'Rain droplets with specular ground reflections';
    if (lower.includes('dust') || lower.includes('particles')) return 'Floating dust motes catching beam light';
    if (lower.includes('smoke') || lower.includes('steam')) return 'Gentle curling steam and atmospheric density';

    return 'Clean crisp atmosphere with subtle optical air density';
  }

  private generateNegativeConstraints(lower: string, preset?: VideoStylePreset): string {
    const baseNegatives = [
      'low quality', 'blurry', 'distorted anatomy', 'extra limbs', 'missing limbs',
      'temporal jitter', 'flicker', 'compression artifacts', 'warping faces',
      'low resolution', 'pixelated', 'duplicate objects', 'oversaturated plastic skin'
    ];

    if (preset && GENERATION_PRESETS[preset]) {
      baseNegatives.push(...GENERATION_PRESETS[preset].promptEnhancements.negativeCues);
    }

    return Array.from(new Set(baseNegatives)).join(', ');
  }

  private detectBestPreset(lower: string): VideoStylePreset {
    if (lower.includes('anime') || lower.includes('manga') || lower.includes('cel shaded')) return 'ANIME';
    if (lower.includes('cyberpunk') || lower.includes('neon') || lower.includes('sci-fi city')) return 'CYBERPUNK';
    if (lower.includes('product') || lower.includes('bottle') || lower.includes('watch') || lower.includes('shoe')) return 'PRODUCT';
    if (lower.includes('portrait') || lower.includes('face') || lower.includes('headshot')) return 'PORTRAIT';
    if (lower.includes('architecture') || lower.includes('building') || lower.includes('interior design')) return 'ARCHITECTURAL';
    if (lower.includes('action') || lower.includes('fight') || lower.includes('chase') || lower.includes('explosion')) return 'ACTION';
    if (lower.includes('horror') || lower.includes('scary') || lower.includes('creepy') || lower.includes('dark monster')) return 'HORROR';
    if (lower.includes('space') || lower.includes('spaceship') || lower.includes('orbit') || lower.includes('astronaut')) return 'SCI_FI';
    if (lower.includes('documentary') || lower.includes('wildlife') || lower.includes('nature report')) return 'DOCUMENTARY';
    if (lower.includes('commercial') || lower.includes('ad ') || lower.includes('brand')) return 'COMMERCIAL';
    if (lower.includes('music video') || lower.includes('rhythm')) return 'MUSIC_VIDEO';
    if (lower.includes('film') || lower.includes('celluloid') || lower.includes('35mm grain')) return 'FILM';
    if (lower.includes('raw photo') || lower.includes('photoreal')) return 'REALISTIC';

    return 'CINEMATIC';
  }
}
