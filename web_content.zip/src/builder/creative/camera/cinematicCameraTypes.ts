/**
 * GODEX P4.8 — Cinematic Camera, Lens & Optical System Types
 * 
 * Production-grade physical camera and optical simulation definitions:
 * - Camera bodies, sensor dimensions, crop factors, native ISOs, dynamic range
 * - Cine prime and zoom lens profiles, focal lengths, aperture T/f-stops, anamorphic squeeze
 * - Optical physics (field of view, depth of field, hyperfocal distance, CoC, bokeh, distortion)
 * - Cinematic shot archetypes (ECU, CU, MCU, MS, MLS, LS, ELS, OTS, POV, etc.)
 * - 3D camera pose, orientation, kinematics and spatial trajectories
 * - Camera continuity validation models and provenance records
 */

import {
  CameraMovementType,
  SpeedCurveType,
  ExecutionTruthClassification,
  ResolutionPreset,
  AspectRatioType
} from '../creativeStudioTypes';

export type SensorFormat =
  | 'FULL_FRAME'           // 36.00 x 24.00 mm (1.00x crop)
  | 'SUPER_35'             // 24.89 x 18.66 mm (~1.44x crop)
  | 'LARGE_FORMAT_ARRI_LF' // 36.70 x 25.54 mm (0.98x crop)
  | 'VISTAVISION_RED_VV'   // 40.96 x 21.60 mm (0.88x crop)
  | 'IMAX_65MM_15PERF'     // 70.41 x 52.63 mm (0.43x crop)
  | 'MEDIUM_FORMAT_GFX'    // 43.80 x 32.90 mm (0.79x crop)
  | 'MICRO_FOUR_THIRDS'    // 17.30 x 13.00 mm (2.00x crop)
  | 'ACADEMY_35MM'         // 22.00 x 16.00 mm (1.63x crop)
  | 'STANDARD_16MM';       // 10.26 x 7.49 mm (3.41x crop)

export type LensType =
  | 'PRIME_SPHERICAL'
  | 'PRIME_ANAMORPHIC'
  | 'CINE_ZOOM'
  | 'VINTAGE_PRIME'
  | 'MACRO_CINE'
  | 'ULTRA_WIDE_EXPANSIVE'
  | 'TELEPHOTO_COMPRESSION';

export type ShotArchetype =
  | 'ECU'         // Extreme Close-Up (eyes, ring, micro detail)
  | 'CU'          // Close-Up (face filling frame)
  | 'MCU'         // Medium Close-Up (head and shoulders)
  | 'MS'          // Medium Shot (waist up)
  | 'MLS'         // Medium Long Shot / Cowboy (mid-thigh up)
  | 'LS'          // Long Shot (full subject height visible)
  | 'ELS'         // Extreme Long Shot (subject dwarfed by landscape/world)
  | 'OTS'         // Over-The-Shoulder (dialogue perspective)
  | 'POV'         // Point of View (first-person subjective)
  | 'TRACKING'    // Tracking / Moving subject follow
  | 'DOLLY'       // Dolly push/pull depth shift
  | 'CRANE'       // Sweeping elevated crane / jib
  | 'ORBIT'       // Circular orbital arc
  | 'HANDHELD';   // Kinetic handheld human sway

export interface CameraBodyProfile {
  id: string;
  name: string;
  manufacturer: 'ARRI' | 'RED' | 'SONY' | 'BLACKMAGIC' | 'IMAX' | 'CANON' | 'PANAVISION' | 'GENERIC_CINE';
  sensorFormat: SensorFormat;
  sensorWidthMm: number;
  sensorHeightMm: number;
  sensorDiagonalMm: number;
  cropFactorVsFullFrame: number;
  nativeIso: number[];
  baseDynamicRangeStops: number;
  defaultShutterAngleDeg: number;
  supportedFrameRates: number[];
  colorScience: string;
}

export interface LensProfile {
  id: string;
  name: string;
  lensType: LensType;
  manufacturer: string;
  focalLengthMm: number;
  isZoom: boolean;
  zoomRangeMm?: [number, number];
  maxApertureFStop: number; // e.g. 1.3
  minApertureFStop: number; // e.g. 22.0
  anamorphicSqueezeRatio: number; // 1.0 for spherical, 1.33, 1.5, 1.8, 2.0 for anamorphic
  apertureBlades: number; // e.g. 9 or 11 (determines bokeh roundness)
  distortionK1: number; // Radial barrel/pincushion coefficient (-0.1 to +0.1)
  distortionK2: number;
  chromaticAberrationPx: number; // Lateral dispersion at 1080p frame edge
  vignetteStrength: number; // 0.0 to 1.0 (falloff at corners)
  flaringCharacter: 'CLEAN_COATED' | 'ANAMORPHIC_BLUE_STREAK' | 'VINTAGE_WARM_HALATION' | 'NEUTRAL';
}

export interface FieldOfViewCalculation {
  horizontalDeg: number;
  verticalDeg: number;
  diagonalDeg: number;
  focalLength35mmEquivalentMm: number;
  cropFactor: number;
}

export interface DepthOfFieldCalculation {
  focusDistanceMeters: number;
  focalLengthMm: number;
  apertureFStop: number;
  sensorFormat: SensorFormat;
  cocMm: number; // Circle of Confusion (e.g. 0.029mm for 35mm FF)
  hyperfocalDistanceMeters: number;
  nearLimitMeters: number;
  farLimitMeters: number | 'INFINITY';
  totalDofMeters: number | 'INFINITY';
  inFrontPercent: number; // % of total DOF in front of subject
  behindPercent: number;  // % of total DOF behind subject
  bokehDiameterAtInfinityMm: number; // Physical blur disc size
}

export interface OpticalSimulationParams {
  fov: FieldOfViewCalculation;
  dof: DepthOfFieldCalculation;
  anamorphicSqueeze: number;
  lensDistortion: {
    k1: number;
    k2: number;
    anamorphicStretch: number;
  };
  chromaticAberration: {
    radialOffsetPx: number;
    dispersionCurve: 'LINEAR' | 'QUADRATIC';
  };
  vignette: {
    intensity: number;
    radius: number;
    smoothness: number;
  };
  grainSimulation: {
    isoLevel: number;
    grainSizePx: number;
    intensity: number;
  };
}

export interface CameraPose3D {
  heightMeters: number; // Vertical height above ground (0.3m low, 1.6m eye, 3m+ high)
  distanceToSubjectMeters: number; // Subject distance (0.5m close, 3m medium, 15m+ long)
  panDeg: number; // Yaw (-180° to +180°)
  tiltDeg: number; // Pitch (-90° looking down to +90° looking up)
  rollDeg: number; // Dutch angle roll (-45° to +45°)
}

export interface CameraKinematics {
  movementType: CameraMovementType;
  intensity: number; // 1 to 10
  speedCurve: SpeedCurveType;
  velocityMetersPerSec?: number;
  angularVelocityDegPerSec?: number;
  handheldFrequencyHz?: number;
  handheldAmplitudePx?: number;
  craneElevateDeltaMeters?: number;
  orbitArcDegrees?: number;
}

export interface ShotCompositionGuide {
  rule: 'RULE_OF_THIRDS' | 'GOLDEN_RATIO' | 'CENTERED_SYMMETRY' | 'LEADING_LINES' | 'FRAME_WITHIN_FRAME' | 'QUADRANT';
  subjectScreenX: number; // 0.0 (left) to 1.0 (right), 0.5 center
  subjectScreenY: number; // 0.0 (top) to 1.0 (bottom), 0.5 center
  headroomPercent: number; // 0-50%
  leadRoomPercent: number; // Direction of gaze space
}

export interface CameraShotProvenance {
  shotId: string;
  generationTimestamp: number;
  cameraBodyId: string;
  cameraBodyName: string;
  lensId: string;
  lensName: string;
  focalLengthMm: number;
  apertureFStop: number;
  fps: number;
  shutterAngleDeg: number;
  iso: number;
  resolution: ResolutionPreset;
  aspectRatio: AspectRatioType;
  engineClassification: ExecutionTruthClassification;
  modelIdentifier?: string;
  seed?: number;
  deterministicCalculationsVerified: boolean;
}

export interface CameraShotSpec {
  shotId: string;
  sceneId: string;
  shotNumber: number;
  archetype: ShotArchetype;
  name: string;
  durationSec: number;
  cameraBody: CameraBodyProfile;
  lens: LensProfile;
  focalLengthMm: number;
  apertureFStop: number;
  focusDistanceMeters: number;
  shutterAngleDeg: number;
  iso: number;
  fps: 24 | 25 | 30 | 48 | 60 | 120;
  whiteBalanceKelvin: number;
  whiteBalanceTint: number;
  pose: CameraPose3D;
  kinematics: CameraKinematics;
  composition: ShotCompositionGuide;
  lightingSetup: string;
  subjectDescription: string;
  opticalSimulation: OpticalSimulationParams;
  transitionIntent: 'DIRECT_CUT' | 'J_CUT' | 'L_CUT' | 'MATCH_CUT' | 'WHIP_PAN' | 'SMASH_CUT' | 'DISSOLVE';
  provenance: CameraShotProvenance;
}

export type ContinuityWarningSeverity = 'INFO' | 'WARNING' | 'CRITICAL';

export interface CameraContinuityIssue {
  issueCode: 
    | 'AXIS_CROSSING_180' 
    | 'JUMP_CUT_30_DEGREE' 
    | 'FOCAL_LENGTH_JUMP' 
    | 'SCREEN_DIRECTION_FLIP' 
    | 'HORIZON_MISMATCH' 
    | 'MOTION_VECTOR_COLLISION' 
    | 'FOCUS_DISCONTINUITY' 
    | 'EXPOSURE_MISMATCH';
  severity: ContinuityWarningSeverity;
  shotFromIndex: number;
  shotToIndex: number;
  shotFromId: string;
  shotToId: string;
  title: string;
  description: string;
  recommendation: string;
  metricDelta: number | string;
}

export interface CameraContinuityReport {
  passed: boolean;
  score: number; // 0 to 100
  totalShots: number;
  issues: CameraContinuityIssue[];
  summary: string;
  verifiedAt: number;
}

export interface PromptCameraExtraction {
  hasCameraIntent: boolean;
  archetype: ShotArchetype | 'UNKNOWN';
  focalLengthMm: number | 'UNKNOWN';
  apertureFStop: number | 'UNKNOWN';
  cameraMovement: CameraMovementType | 'UNKNOWN';
  cameraBodyHint?: string;
  lightingHint?: string;
  focusHint?: string;
  confidence: {
    overall: number; // 0.0 to 1.0
    focalLength: number;
    movement: number;
    archetype: number;
    aperture: number;
  };
  rawMatches: string[];
}
