/**
 * GODEX P4.8 — Prompt to Camera Intelligence Extractor
 * 
 * Performs deterministic cinematic semantic analysis on natural language prompts
 * to extract structured optical camera intent:
 * - Focal lengths (e.g. "85mm", "24mm prime", "telephoto compression", "wide-angle")
 * - Aperture / Depth of Field intent (e.g. "f/1.4", "shallow DOF", "creamy bokeh", "deep focus f/11")
 * - Camera movement (e.g. "slow dolly in", "whip pan", "crane ascend", "handheld run")
 * - Shot archetypes (e.g. "close-up", "extreme close-up", "medium shot", "establishing wide", "POV", "over the shoulder")
 * - Camera bodies & formats (e.g. "Arri Alexa", "35mm anamorphic", "IMAX 65mm", "Sony Venice")
 * - Focus targets & lighting hints
 * 
 * Invariants:
 * - Honest Epistemic Truth: Assigns explicit confidence values and 'UNKNOWN' when ambiguous.
 * - Never hallucinates camera attributes not supported by text evidence.
 */

import { CameraMovementType } from '../creativeStudioTypes';
import { PromptCameraExtraction, ShotArchetype } from './cinematicCameraTypes';

export class PromptCameraExtractor {
  private static instance: PromptCameraExtractor | null = null;

  public static getInstance(): PromptCameraExtractor {
    if (!PromptCameraExtractor.instance) {
      PromptCameraExtractor.instance = new PromptCameraExtractor();
    }
    return PromptCameraExtractor.instance;
  }

  /**
   * Parses natural language prompt text and extracts structured camera intent.
   */
  public extractCameraIntent(rawPrompt: string): PromptCameraExtraction {
    const text = (rawPrompt || '').trim();
    const lower = text.toLowerCase();
    const matches: string[] = [];

    if (!text) {
      return {
        hasCameraIntent: false,
        archetype: 'UNKNOWN',
        focalLengthMm: 'UNKNOWN',
        apertureFStop: 'UNKNOWN',
        cameraMovement: 'UNKNOWN',
        confidence: {
          overall: 0.0,
          focalLength: 0.0,
          movement: 0.0,
          archetype: 0.0,
          aperture: 0.0
        },
        rawMatches: []
      };
    }

    // 1. Extract Focal Length
    const { focalLengthMm, focalConfidence, focalMatch } = this.parseFocalLength(lower);
    if (focalMatch) matches.push(focalMatch);

    // 2. Extract Aperture / DOF Intent
    const { apertureFStop, apertureConfidence, apertureMatch } = this.parseAperture(lower);
    if (apertureMatch) matches.push(apertureMatch);

    // 3. Extract Shot Archetype
    const { archetype, archetypeConfidence, archetypeMatch } = this.parseArchetype(lower);
    if (archetypeMatch) matches.push(archetypeMatch);

    // 4. Extract Camera Movement
    const { cameraMovement, movementConfidence, movementMatch } = this.parseMovement(lower);
    if (movementMatch) matches.push(movementMatch);

    // 5. Extract Camera Body / Format Hint
    const cameraBodyHint = this.parseCameraBodyHint(lower);
    if (cameraBodyHint) matches.push(`Camera: ${cameraBodyHint}`);

    // 6. Extract Focus Hint
    const focusHint = this.parseFocusHint(lower);
    if (focusHint) matches.push(`Focus: ${focusHint}`);

    // 7. Calculate Overall Confidence
    const detectedFactors = [
      focalConfidence > 0 ? 1 : 0,
      apertureConfidence > 0 ? 1 : 0,
      archetypeConfidence > 0 ? 1 : 0,
      movementConfidence > 0 ? 1 : 0,
      cameraBodyHint ? 1 : 0
    ].reduce((a, b) => a + b, 0);

    const overallConfidence = Number((
      (focalConfidence * 0.25) +
      (apertureConfidence * 0.25) +
      (archetypeConfidence * 0.25) +
      (movementConfidence * 0.25)
    ).toFixed(2));

    const hasCameraIntent = detectedFactors > 0;

    return {
      hasCameraIntent,
      archetype,
      focalLengthMm,
      apertureFStop,
      cameraMovement,
      cameraBodyHint,
      focusHint,
      confidence: {
        overall: hasCameraIntent ? Math.max(0.3, overallConfidence) : 0.0,
        focalLength: focalConfidence,
        movement: movementConfidence,
        archetype: archetypeConfidence,
        aperture: apertureConfidence
      },
      rawMatches: matches
    };
  }

  // --- Private Semantic Parsers ---

  private parseFocalLength(lower: string): { focalLengthMm: number | 'UNKNOWN'; focalConfidence: number; focalMatch?: string } {
    // Explicit mm regex (e.g. "85mm", "24 mm", "50mm prime", "f=35mm")
    const explicitMatch = lower.match(/\b(?:f\s*=\s*)?(\d{2,3})\s*mm\b/);
    if (explicitMatch) {
      const val = parseInt(explicitMatch[1], 10);
      if (val >= 10 && val <= 800) {
        return {
          focalLengthMm: val,
          focalConfidence: 0.95,
          focalMatch: `${val}mm focal length`
        };
      }
    }

    // Keyword heuristics
    if (lower.includes('fisheye') || lower.includes('ultra-wide') || lower.includes('ultra wide')) {
      return { focalLengthMm: 14, focalConfidence: 0.85, focalMatch: '14mm ultra-wide lens' };
    }
    if (lower.includes('wide angle') || lower.includes('wide-angle') || lower.includes('expansive view')) {
      return { focalLengthMm: 24, focalConfidence: 0.80, focalMatch: '24mm wide angle lens' };
    }
    if (lower.includes('portrait lens') || lower.includes('portrait prime') || lower.includes('headshot')) {
      return { focalLengthMm: 85, focalConfidence: 0.85, focalMatch: '85mm portrait prime' };
    }
    if (lower.includes('macro') || lower.includes('micro detail') || lower.includes('extreme close')) {
      return { focalLengthMm: 100, focalConfidence: 0.80, focalMatch: '100mm macro lens' };
    }
    if (lower.includes('telephoto') || lower.includes('telephoto compression') || lower.includes('compressed background')) {
      return { focalLengthMm: 135, focalConfidence: 0.80, focalMatch: '135mm telephoto lens' };
    }
    if (lower.includes('standard prime') || lower.includes('human eye perspective')) {
      return { focalLengthMm: 50, focalConfidence: 0.75, focalMatch: '50mm standard prime' };
    }

    return { focalLengthMm: 'UNKNOWN', focalConfidence: 0.0 };
  }

  private parseAperture(lower: string): { apertureFStop: number | 'UNKNOWN'; apertureConfidence: number; apertureMatch?: string } {
    // Explicit f-stop (e.g. "f/1.4", "f1.8", "t/2.0", "f/2.8", "f/11")
    const explicitMatch = lower.match(/\b[ft]\/?\s*([0-9]+(?:\.[0-9]+)?)\b/);
    if (explicitMatch) {
      const val = parseFloat(explicitMatch[1]);
      if (val >= 0.7 && val <= 32.0) {
        return {
          apertureFStop: val,
          apertureConfidence: 0.95,
          apertureMatch: `f/${val} aperture`
        };
      }
    }

    // Semantic DOF heuristics
    if (lower.includes('shallow depth of field') || lower.includes('shallow dof') || lower.includes('blurry background') || lower.includes('creamy bokeh') || lower.includes('bokeh circles')) {
      return { apertureFStop: 1.4, apertureConfidence: 0.85, apertureMatch: 'f/1.4 shallow depth of field' };
    }
    if (lower.includes('deep focus') || lower.includes('deep dof') || lower.includes('everything in focus') || lower.includes('sharp from foreground to horizon')) {
      return { apertureFStop: 11.0, apertureConfidence: 0.85, apertureMatch: 'f/11 deep focus' };
    }
    if (lower.includes('moderate depth of field') || lower.includes('natural focus')) {
      return { apertureFStop: 4.0, apertureConfidence: 0.70, apertureMatch: 'f/4.0 balanced focus' };
    }

    return { apertureFStop: 'UNKNOWN', apertureConfidence: 0.0 };
  }

  private parseArchetype(lower: string): { archetype: ShotArchetype | 'UNKNOWN'; archetypeConfidence: number; archetypeMatch?: string } {
    if (lower.includes('extreme close up') || lower.includes('extreme close-up') || lower.includes('ecu') || lower.includes('macro detail')) {
      return { archetype: 'ECU', archetypeConfidence: 0.90, archetypeMatch: 'Extreme Close-Up (ECU)' };
    }
    if (lower.includes('close up') || lower.includes('close-up') || lower.includes('tight shot') || lower.includes('face shot')) {
      return { archetype: 'CU', archetypeConfidence: 0.90, archetypeMatch: 'Close-Up (CU)' };
    }
    if (lower.includes('medium close up') || lower.includes('medium close-up') || lower.includes('mcu') || lower.includes('bust shot') || lower.includes('head and shoulders')) {
      return { archetype: 'MCU', archetypeConfidence: 0.85, archetypeMatch: 'Medium Close-Up (MCU)' };
    }
    if (lower.includes('medium shot') || lower.includes('waist up') || lower.includes('mid shot')) {
      return { archetype: 'MS', archetypeConfidence: 0.85, archetypeMatch: 'Medium Shot (MS)' };
    }
    if (lower.includes('medium long shot') || lower.includes('cowboy shot') || lower.includes('mls') || lower.includes('three-quarter shot')) {
      return { archetype: 'MLS', archetypeConfidence: 0.85, archetypeMatch: 'Medium Long Shot (MLS)' };
    }
    if (lower.includes('extreme long shot') || lower.includes('extreme wide shot') || lower.includes('els') || lower.includes('birds eye landscape')) {
      return { archetype: 'ELS', archetypeConfidence: 0.90, archetypeMatch: 'Extreme Long Shot (ELS)' };
    }
    if (lower.includes('long shot') || lower.includes('wide shot') || lower.includes('establishing shot') || lower.includes('full body')) {
      return { archetype: 'LS', archetypeConfidence: 0.85, archetypeMatch: 'Long Shot (LS)' };
    }
    if (lower.includes('over the shoulder') || lower.includes('ots')) {
      return { archetype: 'OTS', archetypeConfidence: 0.95, archetypeMatch: 'Over-The-Shoulder (OTS)' };
    }
    if (lower.includes('point of view') || lower.includes('pov shot') || lower.includes('first person') || lower.includes('first-person')) {
      return { archetype: 'POV', archetypeConfidence: 0.95, archetypeMatch: 'Point of View (POV)' };
    }
    if (lower.includes('tracking shot') || lower.includes('following subject')) {
      return { archetype: 'TRACKING', archetypeConfidence: 0.85, archetypeMatch: 'Tracking Shot' };
    }
    if (lower.includes('dolly in') || lower.includes('dolly out') || lower.includes('dolly shot') || lower.includes('push in')) {
      return { archetype: 'DOLLY', archetypeConfidence: 0.85, archetypeMatch: 'Dolly Shot' };
    }
    if (lower.includes('crane shot') || lower.includes('jib shot') || lower.includes('boom up')) {
      return { archetype: 'CRANE', archetypeConfidence: 0.85, archetypeMatch: 'Crane Shot' };
    }
    if (lower.includes('orbit') || lower.includes('360')) {
      return { archetype: 'ORBIT', archetypeConfidence: 0.85, archetypeMatch: 'Orbital Arc Shot' };
    }
    if (lower.includes('handheld') || lower.includes('camera shake') || lower.includes('shaky cam')) {
      return { archetype: 'HANDHELD', archetypeConfidence: 0.85, archetypeMatch: 'Handheld Kinetic Shot' };
    }

    return { archetype: 'UNKNOWN', archetypeConfidence: 0.0 };
  }

  private parseMovement(lower: string): { cameraMovement: CameraMovementType | 'UNKNOWN'; movementConfidence: number; movementMatch?: string } {
    if (lower.includes('slow dolly in') || lower.includes('dolly in') || lower.includes('push in')) {
      return { cameraMovement: 'DOLLY_IN', movementConfidence: 0.90, movementMatch: 'Dolly In' };
    }
    if (lower.includes('dolly out') || lower.includes('pull out') || lower.includes('pull back')) {
      return { cameraMovement: 'DOLLY_OUT', movementConfidence: 0.90, movementMatch: 'Dolly Out' };
    }
    if (lower.includes('pan left')) {
      return { cameraMovement: 'PAN_LEFT', movementConfidence: 0.90, movementMatch: 'Pan Left' };
    }
    if (lower.includes('pan right') || lower.includes('horizontal pan')) {
      return { cameraMovement: 'PAN_RIGHT', movementConfidence: 0.90, movementMatch: 'Pan Right' };
    }
    if (lower.includes('tilt up')) {
      return { cameraMovement: 'TILT_UP', movementConfidence: 0.90, movementMatch: 'Tilt Up' };
    }
    if (lower.includes('tilt down')) {
      return { cameraMovement: 'TILT_DOWN', movementConfidence: 0.90, movementMatch: 'Tilt Down' };
    }
    if (lower.includes('truck left')) {
      return { cameraMovement: 'TRUCK_LEFT', movementConfidence: 0.90, movementMatch: 'Truck Left' };
    }
    if (lower.includes('truck right') || lower.includes('lateral track')) {
      return { cameraMovement: 'TRUCK_RIGHT', movementConfidence: 0.90, movementMatch: 'Truck Right' };
    }
    if (lower.includes('360 orbit') || lower.includes('orbit 360') || lower.includes('orbit around')) {
      return { cameraMovement: 'ORBIT_360', movementConfidence: 0.90, movementMatch: '360° Orbit' };
    }
    if (lower.includes('crane up') || lower.includes('crane ascend') || lower.includes('boom up')) {
      return { cameraMovement: 'CRANE_UP', movementConfidence: 0.90, movementMatch: 'Crane Up' };
    }
    if (lower.includes('crane down') || lower.includes('boom down')) {
      return { cameraMovement: 'CRANE_DOWN', movementConfidence: 0.90, movementMatch: 'Crane Down' };
    }
    if (lower.includes('zoom pull') || lower.includes('crash zoom') || lower.includes('snap zoom')) {
      return { cameraMovement: 'ZOOM_PULL', movementConfidence: 0.90, movementMatch: 'Zoom Pull' };
    }
    if (lower.includes('tracking shot') || lower.includes('tracking run') || lower.includes('follow shot')) {
      return { cameraMovement: 'TRACKING_SHOT', movementConfidence: 0.85, movementMatch: 'Tracking Shot' };
    }
    if (lower.includes('handheld dynamic') || lower.includes('handheld run')) {
      return { cameraMovement: 'HANDHELD_DYNAMIC', movementConfidence: 0.90, movementMatch: 'Handheld Dynamic' };
    }
    if (lower.includes('static') || lower.includes('tripod') || lower.includes('locked off') || lower.includes('still camera')) {
      return { cameraMovement: 'STATIC', movementConfidence: 0.90, movementMatch: 'Static Tripod' };
    }

    return { cameraMovement: 'UNKNOWN', movementConfidence: 0.0 };
  }

  private parseCameraBodyHint(lower: string): string | undefined {
    if (lower.includes('arri') || lower.includes('alexa') || lower.includes('logc')) return 'ARRI Alexa';
    if (lower.includes('red camera') || lower.includes('v-raptor') || lower.includes('redcode')) return 'RED V-Raptor';
    if (lower.includes('sony venice') || lower.includes('fx9') || lower.includes('s-log')) return 'Sony Venice';
    if (lower.includes('imax') || lower.includes('65mm')) return 'IMAX 65mm 15-Perf';
    if (lower.includes('35mm film') || lower.includes('anamorphic') || lower.includes('kodak')) return '35mm Film Anamorphic';
    if (lower.includes('blackmagic') || lower.includes('braw')) return 'Blackmagic URSA';
    return undefined;
  }

  private parseFocusHint(lower: string): string | undefined {
    if (lower.includes('rack focus')) return 'Rack focus transition between foreground and background';
    if (lower.includes('focus on eyes') || lower.includes('eyes sharp')) return 'Tack-sharp eye focus';
    if (lower.includes('foreground blurred') || lower.includes('out of focus foreground')) return 'Out-of-focus foreground bokeh frame';
    return undefined;
  }
}
