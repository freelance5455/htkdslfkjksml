/**
 * GODEX P4.8 — Camera Continuity Validation Engine
 * 
 * Conducts multi-shot spatial, focal, vector, and axis continuity audits:
 * 1. 180-Degree Rule / Camera-Axis Crossing Detection
 * 2. 30-Degree Rule / Jump Cut Prevention
 * 3. Focal Length Continuity & Compression Discontinuities
 * 4. Screen Direction & Motion Vector Consistency
 * 5. Horizon / Dutch Angle Alignment
 * 6. Focus Transition Plausibility
 * 
 * Invariants:
 * - 100% Deterministic rule engine
 * - Returns structured diagnostic reports with severity ratings and director recommendations.
 */

import {
  CameraShotSpec,
  CameraContinuityReport,
  CameraContinuityIssue
} from './cinematicCameraTypes';

export class CameraContinuityEngine {
  private static instance: CameraContinuityEngine | null = null;

  public static getInstance(): CameraContinuityEngine {
    if (!CameraContinuityEngine.instance) {
      CameraContinuityEngine.instance = new CameraContinuityEngine();
    }
    return CameraContinuityEngine.instance;
  }

  /**
   * Evaluates continuity across an ordered sequence of shots.
   */
  public auditSequenceContinuity(shots: CameraShotSpec[]): CameraContinuityReport {
    const issues: CameraContinuityIssue[] = [];

    if (!shots || shots.length <= 1) {
      return {
        passed: true,
        score: 100,
        totalShots: shots ? shots.length : 0,
        issues: [],
        summary: 'Single shot sequence: No inter-shot continuity constraints violated.',
        verifiedAt: Date.now()
      };
    }

    for (let i = 0; i < shots.length - 1; i++) {
      const shotA = shots[i];
      const shotB = shots[i + 1];

      // 1. 180-Degree Rule / Axis Crossing
      this.check180DegreeAxis(shotA, shotB, i, i + 1, issues);

      // 2. 30-Degree Rule / Jump Cut
      this.check30DegreeRule(shotA, shotB, i, i + 1, issues);

      // 3. Focal Length Jump
      this.checkFocalLengthContinuity(shotA, shotB, i, i + 1, issues);

      // 4. Horizon / Dutch Angle Consistency
      this.checkHorizonContinuity(shotA, shotB, i, i + 1, issues);

      // 5. Motion Vector Collision
      this.checkMotionVectorCollision(shotA, shotB, i, i + 1, issues);

      // 6. Focus Discontinuity
      this.checkFocusContinuity(shotA, shotB, i, i + 1, issues);
    }

    // Score computation: Start at 100, deduct for issues
    let score = 100;
    for (const issue of issues) {
      if (issue.severity === 'CRITICAL') score -= 25;
      else if (issue.severity === 'WARNING') score -= 12;
      else if (issue.severity === 'INFO') score -= 5;
    }
    score = Math.max(0, Math.min(100, score));

    const passed = score >= 70 && !issues.some(iss => iss.severity === 'CRITICAL');

    const summary = issues.length === 0
      ? `Sequence of ${shots.length} shots exhibits flawless spatial, optical, and motion continuity.`
      : `Continuity Audit: ${issues.length} observation(s) detected. Score: ${score}/100. ${passed ? 'Compliant with minor notes.' : 'Review recommended before final render.'}`;

    return {
      passed,
      score,
      totalShots: shots.length,
      issues,
      summary,
      verifiedAt: Date.now()
    };
  }

  // --- Private Continuity Audit Rules ---

  private check180DegreeAxis(
    shotA: CameraShotSpec,
    shotB: CameraShotSpec,
    idxA: number,
    idxB: number,
    issues: CameraContinuityIssue[]
  ): void {
    const panA = shotA.pose.panDeg;
    const panB = shotB.pose.panDeg;
    const delta = Math.abs(panA - panB);

    // 180° Action Axis Violation occurs when:
    // a) Large angular flip (>160°) occurs between successive shots of the same subject/scene
    // b) Or OTS / dialogue coverage switches signs across the action line (panA > 15 && panB < -15 or vice-versa with delta > 75°)
    const isOTS = shotA.archetype === 'OTS' && shotB.archetype === 'OTS';
    const isSignFlip = (panA > 15 && panB < -15) || (panA < -15 && panB > 15);
    const isMajorAxisCrossing = delta >= 160 || (isOTS && isSignFlip && delta > 75);

    if (isMajorAxisCrossing) {
      issues.push({
        issueCode: 'AXIS_CROSSING_180',
        severity: 'CRITICAL',
        shotFromIndex: idxA,
        shotToIndex: idxB,
        shotFromId: shotA.shotId,
        shotToId: shotB.shotId,
        title: '180-Degree Action Axis Crossing Detected',
        description: `Shot ${idxA + 1} (${shotA.name}, Pan: ${panA}°) and Shot ${idxB + 1} (${shotB.name}, Pan: ${panB}°) cross the 180-degree imaginary line of action, which will disorient viewers about screen direction.`,
        recommendation: 'Keep camera on the same side of the character interaction axis, or insert a neutral POV / frontal establishing shot between them.',
        metricDelta: `${delta}° angular axis shift`
      });
    }
  }

  private check30DegreeRule(
    shotA: CameraShotSpec,
    shotB: CameraShotSpec,
    idxA: number,
    idxB: number,
    issues: CameraContinuityIssue[]
  ): void {
    // Jump cut happens when same subject is shown with <30° angular change and <20% focal change
    const deltaPan = Math.abs(shotA.pose.panDeg - shotB.pose.panDeg);
    const deltaTilt = Math.abs(shotA.pose.tiltDeg - shotB.pose.tiltDeg);
    const angularDiff = Math.sqrt(deltaPan * deltaPan + deltaTilt * deltaTilt);

    const focalRatio = Math.max(shotA.focalLengthMm, shotB.focalLengthMm) / Math.max(1, Math.min(shotA.focalLengthMm, shotB.focalLengthMm));
    const isSameArchetype = shotA.archetype === shotB.archetype;

    if (angularDiff < 25 && focalRatio < 1.25 && isSameArchetype && shotA.archetype !== 'POV') {
      issues.push({
        issueCode: 'JUMP_CUT_30_DEGREE',
        severity: 'WARNING',
        shotFromIndex: idxA,
        shotToIndex: idxB,
        shotFromId: shotA.shotId,
        shotToId: shotB.shotId,
        title: '30-Degree Rule Jump Cut Risk',
        description: `Shot ${idxA + 1} and Shot ${idxB + 1} have nearly identical camera angle (${angularDiff.toFixed(1)}° delta) and focal length (${shotA.focalLengthMm}mm vs ${shotB.focalLengthMm}mm). Cutting between them will appear as an unintentional temporal glitch.`,
        recommendation: 'Change the camera angle by at least 30 degrees, or alter shot scale by at least 2 steps (e.g. Wide Shot to Close-Up).',
        metricDelta: `${angularDiff.toFixed(1)}° angle / ${((focalRatio - 1) * 100).toFixed(0)}% focal change`
      });
    }
  }

  private checkFocalLengthContinuity(
    shotA: CameraShotSpec,
    shotB: CameraShotSpec,
    idxA: number,
    idxB: number,
    issues: CameraContinuityIssue[]
  ): void {
    const minF = Math.min(shotA.focalLengthMm, shotB.focalLengthMm);
    const maxF = Math.max(shotA.focalLengthMm, shotB.focalLengthMm);
    const ratio = maxF / Math.max(1, minF);

    // Extreme jump: e.g. 14mm to 135mm (ratio > 6.0)
    if (ratio > 5.0 && shotA.transitionIntent === 'DIRECT_CUT') {
      issues.push({
        issueCode: 'FOCAL_LENGTH_JUMP',
        severity: 'INFO',
        shotFromIndex: idxA,
        shotToIndex: idxB,
        shotFromId: shotA.shotId,
        shotToId: shotB.shotId,
        title: 'High Optical Compression Disparity',
        description: `Dramatic focal length transition from ${shotA.focalLengthMm}mm to ${shotB.focalLengthMm}mm (${ratio.toFixed(1)}x ratio) produces stark background compression differences.`,
        recommendation: 'Ensure this extreme optical contrast is a deliberate dramatic choice or utilize an intermediate transition.',
        metricDelta: `${shotA.focalLengthMm}mm → ${shotB.focalLengthMm}mm (${ratio.toFixed(1)}x)`
      });
    }
  }

  private checkHorizonContinuity(
    shotA: CameraShotSpec,
    shotB: CameraShotSpec,
    idxA: number,
    idxB: number,
    issues: CameraContinuityIssue[]
  ): void {
    const rollA = shotA.pose.rollDeg;
    const rollB = shotB.pose.rollDeg;
    const rollDelta = Math.abs(rollA - rollB);

    if (rollDelta > 12.0) {
      issues.push({
        issueCode: 'HORIZON_MISMATCH',
        severity: 'WARNING',
        shotFromIndex: idxA,
        shotToIndex: idxB,
        shotFromId: shotA.shotId,
        shotToId: shotB.shotId,
        title: 'Dutch Angle Horizon Discontinuity',
        description: `Camera roll differs by ${rollDelta.toFixed(1)}° (Shot ${idxA + 1}: ${rollA}°, Shot ${idxB + 1}: ${rollB}°), causing a jarring horizon tilt shift across the cut.`,
        recommendation: 'Align camera horizon roll unless portraying intentional psychological instability.',
        metricDelta: `${rollDelta.toFixed(1)}° roll delta`
      });
    }
  }

  private checkMotionVectorCollision(
    shotA: CameraShotSpec,
    shotB: CameraShotSpec,
    idxA: number,
    idxB: number,
    issues: CameraContinuityIssue[]
  ): void {
    const moveA = shotA.kinematics.movementType;
    const moveB = shotB.kinematics.movementType;

    const isLeftMoveA = moveA === 'PAN_LEFT' || moveA === 'TRUCK_LEFT';
    const isRightMoveB = moveB === 'PAN_RIGHT' || moveB === 'TRUCK_RIGHT';
    const isRightMoveA = moveA === 'PAN_RIGHT' || moveA === 'TRUCK_RIGHT';
    const isLeftMoveB = moveB === 'PAN_LEFT' || moveB === 'TRUCK_LEFT';

    if ((isLeftMoveA && isRightMoveB) || (isRightMoveA && isLeftMoveB)) {
      if (shotA.kinematics.intensity > 5 && shotB.kinematics.intensity > 5) {
        issues.push({
          issueCode: 'MOTION_VECTOR_COLLISION',
          severity: 'WARNING',
          shotFromIndex: idxA,
          shotToIndex: idxB,
          shotFromId: shotA.shotId,
          shotToId: shotB.shotId,
          title: 'Opposing Lateral Motion Vector Collision',
          description: `Shot ${idxA + 1} (${moveA}) moves laterally in direct opposition to Shot ${idxB + 1} (${moveB}) at high speed, creating abrupt kinetic whiplash across the edit.`,
          recommendation: 'Maintain continuous screen motion direction across cuts or settle the camera prior to transitioning.',
          metricDelta: `${moveA} → ${moveB}`
        });
      }
    }
  }

  private checkFocusContinuity(
    shotA: CameraShotSpec,
    shotB: CameraShotSpec,
    idxA: number,
    idxB: number,
    issues: CameraContinuityIssue[]
  ): void {
    const distA = shotA.focusDistanceMeters;
    const distB = shotB.focusDistanceMeters;
    const delta = Math.abs(distA - distB);

    // If both shots have very shallow depth of field (e.g. f/1.4) and focus distance changes >10x
    if (shotA.apertureFStop <= 2.0 && shotB.apertureFStop <= 2.0 && delta > 8.0 && Math.min(distA, distB) < 1.0) {
      issues.push({
        issueCode: 'FOCUS_DISCONTINUITY',
        severity: 'INFO',
        shotFromIndex: idxA,
        shotToIndex: idxB,
        shotFromId: shotA.shotId,
        shotToId: shotB.shotId,
        title: 'Macro/Deep Focal Plane Shift',
        description: `Focal distance shifts from ${distA}m to ${distB}m with shallow depth of field (f/${shotA.apertureFStop} & f/${shotB.apertureFStop}).`,
        recommendation: 'Consider a rack focus transition or verify viewer attention settles naturally on the new focal plane.',
        metricDelta: `${distA}m → ${distB}m`
      });
    }
  }
}
