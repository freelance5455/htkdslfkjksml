/**
 * GODEX P4.8 — Camera Bodies and Cine Lenses Database
 * 
 * Physical specifications for industry-standard cinema cameras and lenses.
 * All dimensions, crop factors, and optical coefficients are strictly grounded
 * in real-world cinematography engineering.
 */

import { CameraBodyProfile, LensProfile } from './cinematicCameraTypes';

// Standard 35mm Full-Frame reference diagonal (36x24mm) = 43.27 mm
export const FULL_FRAME_35MM_DIAGONAL_MM = Math.sqrt(36.0 * 36.0 + 24.0 * 24.0); // 43.2666 mm

export const CAMERA_BODIES: Record<string, CameraBodyProfile> = {
  'arri-alexa-mini-lf': {
    id: 'arri-alexa-mini-lf',
    name: 'ARRI Alexa Mini LF (Large Format)',
    manufacturer: 'ARRI',
    sensorFormat: 'LARGE_FORMAT_ARRI_LF',
    sensorWidthMm: 36.70,
    sensorHeightMm: 25.54,
    sensorDiagonalMm: Math.sqrt(36.70 * 36.70 + 25.54 * 25.54), // 44.71 mm
    cropFactorVsFullFrame: Number((FULL_FRAME_35MM_DIAGONAL_MM / Math.sqrt(36.70 * 36.70 + 25.54 * 25.54)).toFixed(3)), // 0.968
    nativeIso: [800],
    baseDynamicRangeStops: 14.5,
    defaultShutterAngleDeg: 180,
    supportedFrameRates: [23.976, 24, 25, 29.97, 30, 48, 60],
    colorScience: 'ARRI REVEAL Color Science (LogC4 / ARRIRAW)'
  },
  'arri-alexa-35': {
    id: 'arri-alexa-35',
    name: 'ARRI Alexa 35 (Super 35 4K)',
    manufacturer: 'ARRI',
    sensorFormat: 'SUPER_35',
    sensorWidthMm: 27.99,
    sensorHeightMm: 19.22,
    sensorDiagonalMm: Math.sqrt(27.99 * 27.99 + 19.22 * 19.22), // 33.95 mm
    cropFactorVsFullFrame: Number((FULL_FRAME_35MM_DIAGONAL_MM / Math.sqrt(27.99 * 27.99 + 19.22 * 19.22)).toFixed(3)), // 1.274
    nativeIso: [800, 3200],
    baseDynamicRangeStops: 17.0,
    defaultShutterAngleDeg: 180,
    supportedFrameRates: [23.976, 24, 25, 29.97, 30, 48, 60, 120],
    colorScience: 'ARRI REVEAL Color Science (LogC4)'
  },
  'red-v-raptor-vv': {
    id: 'red-v-raptor-vv',
    name: 'RED V-Raptor 8K (VistaVision)',
    manufacturer: 'RED',
    sensorFormat: 'VISTAVISION_RED_VV',
    sensorWidthMm: 40.96,
    sensorHeightMm: 21.60,
    sensorDiagonalMm: Math.sqrt(40.96 * 40.96 + 21.60 * 21.60), // 46.31 mm
    cropFactorVsFullFrame: Number((FULL_FRAME_35MM_DIAGONAL_MM / Math.sqrt(40.96 * 40.96 + 21.60 * 21.60)).toFixed(3)), // 0.934
    nativeIso: [800],
    baseDynamicRangeStops: 17.0,
    defaultShutterAngleDeg: 180,
    supportedFrameRates: [24, 25, 30, 60, 120],
    colorScience: 'RED IPP2 Image Processing Pipeline (REDCODE RAW)'
  },
  'sony-venice-2': {
    id: 'sony-venice-2',
    name: 'Sony Venice 2 8K (Full Frame)',
    manufacturer: 'SONY',
    sensorFormat: 'FULL_FRAME',
    sensorWidthMm: 36.20,
    sensorHeightMm: 24.10,
    sensorDiagonalMm: Math.sqrt(36.20 * 36.20 + 24.10 * 24.10), // 43.49 mm
    cropFactorVsFullFrame: Number((FULL_FRAME_35MM_DIAGONAL_MM / Math.sqrt(36.20 * 36.20 + 24.10 * 24.10)).toFixed(3)), // 0.995
    nativeIso: [800, 3200],
    baseDynamicRangeStops: 16.0,
    defaultShutterAngleDeg: 180,
    supportedFrameRates: [23.976, 24, 25, 29.97, 30, 48, 60, 90],
    colorScience: 'Sony S-Gamut3.Cine / S-Log3 (X-OCN)'
  },
  'blackmagic-ursa-12k': {
    id: 'blackmagic-ursa-12k',
    name: 'Blackmagic URSA Mini Pro 12K (Super 35)',
    manufacturer: 'BLACKMAGIC',
    sensorFormat: 'SUPER_35',
    sensorWidthMm: 27.03,
    sensorHeightMm: 14.25,
    sensorDiagonalMm: Math.sqrt(27.03 * 27.03 + 14.25 * 14.25), // 30.54 mm
    cropFactorVsFullFrame: Number((FULL_FRAME_35MM_DIAGONAL_MM / Math.sqrt(27.03 * 27.03 + 14.25 * 14.25)).toFixed(3)), // 1.417
    nativeIso: [800, 3200],
    baseDynamicRangeStops: 14.0,
    defaultShutterAngleDeg: 180,
    supportedFrameRates: [24, 25, 30, 60, 120],
    colorScience: 'Blackmagic Gen 5 Color Science (BRAW)'
  },
  'imax-65mm-15perf': {
    id: 'imax-65mm-15perf',
    name: 'IMAX 65mm 15-Perf Film Camera',
    manufacturer: 'IMAX',
    sensorFormat: 'IMAX_65MM_15PERF',
    sensorWidthMm: 70.41,
    sensorHeightMm: 52.63,
    sensorDiagonalMm: Math.sqrt(70.41 * 70.41 + 52.63 * 52.63), // 87.91 mm
    cropFactorVsFullFrame: Number((FULL_FRAME_35MM_DIAGONAL_MM / Math.sqrt(70.41 * 70.41 + 52.63 * 52.63)).toFixed(3)), // 0.492
    nativeIso: [250, 500],
    baseDynamicRangeStops: 15.5,
    defaultShutterAngleDeg: 172.8,
    supportedFrameRates: [24],
    colorScience: 'Kodak Vision3 500T / 250D Photochemical Celluloid'
  },
  'generic-cinema-35mm': {
    id: 'generic-cinema-35mm',
    name: 'Industry Standard 35mm Full Frame (36x24)',
    manufacturer: 'GENERIC_CINE',
    sensorFormat: 'FULL_FRAME',
    sensorWidthMm: 36.00,
    sensorHeightMm: 24.00,
    sensorDiagonalMm: FULL_FRAME_35MM_DIAGONAL_MM,
    cropFactorVsFullFrame: 1.000,
    nativeIso: [800],
    baseDynamicRangeStops: 15.0,
    defaultShutterAngleDeg: 180,
    supportedFrameRates: [23.976, 24, 25, 29.97, 30, 60],
    colorScience: 'ACEScc Rec.709 / Linear ACES AP0'
  },
  'micro-four-thirds': {
    id: 'micro-four-thirds',
    name: 'Micro Four Thirds (M4/3 17.3x13mm)',
    manufacturer: 'PANAVISION',
    sensorFormat: 'MICRO_FOUR_THIRDS',
    sensorWidthMm: 17.30,
    sensorHeightMm: 13.00,
    sensorDiagonalMm: Math.sqrt(17.30 * 17.30 + 13.00 * 13.00), // 21.64 mm
    cropFactorVsFullFrame: 2.000,
    nativeIso: [400, 3200],
    baseDynamicRangeStops: 13.0,
    defaultShutterAngleDeg: 180,
    supportedFrameRates: [24, 25, 30, 60],
    colorScience: 'V-Log / Rec.709'
  }
};

export const CINE_LENSES: Record<string, LensProfile> = {
  'arri-master-prime-18': {
    id: 'arri-master-prime-18',
    name: 'ARRI Master Prime 18mm T1.3',
    lensType: 'ULTRA_WIDE_EXPANSIVE',
    manufacturer: 'ARRI / Zeiss',
    focalLengthMm: 18,
    isZoom: false,
    maxApertureFStop: 1.3,
    minApertureFStop: 22.0,
    anamorphicSqueezeRatio: 1.0,
    apertureBlades: 9,
    distortionK1: -0.018, // Mild barrel
    distortionK2: 0.002,
    chromaticAberrationPx: 0.8,
    vignetteStrength: 0.25,
    flaringCharacter: 'CLEAN_COATED'
  },
  'arri-master-prime-35': {
    id: 'arri-master-prime-35',
    name: 'ARRI Master Prime 35mm T1.3',
    lensType: 'PRIME_SPHERICAL',
    manufacturer: 'ARRI / Zeiss',
    focalLengthMm: 35,
    isZoom: false,
    maxApertureFStop: 1.3,
    minApertureFStop: 22.0,
    anamorphicSqueezeRatio: 1.0,
    apertureBlades: 9,
    distortionK1: -0.005,
    distortionK2: 0.001,
    chromaticAberrationPx: 0.4,
    vignetteStrength: 0.15,
    flaringCharacter: 'CLEAN_COATED'
  },
  'zeiss-supreme-50': {
    id: 'zeiss-supreme-50',
    name: 'Zeiss Supreme Prime 50mm T1.5',
    lensType: 'PRIME_SPHERICAL',
    manufacturer: 'Zeiss',
    focalLengthMm: 50,
    isZoom: false,
    maxApertureFStop: 1.5,
    minApertureFStop: 22.0,
    anamorphicSqueezeRatio: 1.0,
    apertureBlades: 11,
    distortionK1: -0.002,
    distortionK2: 0.000,
    chromaticAberrationPx: 0.2,
    vignetteStrength: 0.10,
    flaringCharacter: 'CLEAN_COATED'
  },
  'cooke-s4i-85': {
    id: 'cooke-s4i-85',
    name: 'Cooke S4/i 85mm T2.0 (The Cooke Look)',
    lensType: 'TELEPHOTO_COMPRESSION',
    manufacturer: 'Cooke Optics',
    focalLengthMm: 85,
    isZoom: false,
    maxApertureFStop: 2.0,
    minApertureFStop: 22.0,
    anamorphicSqueezeRatio: 1.0,
    apertureBlades: 9,
    distortionK1: 0.003, // Slight pincushion
    distortionK2: 0.000,
    chromaticAberrationPx: 0.5,
    vignetteStrength: 0.20,
    flaringCharacter: 'VINTAGE_WARM_HALATION'
  },
  'canon-k35-vintage-85': {
    id: 'canon-k35-vintage-85',
    name: 'Canon K35 Vintage 85mm T1.4 (Oscar Winner 1976)',
    lensType: 'VINTAGE_PRIME',
    manufacturer: 'Canon Cinema',
    focalLengthMm: 85,
    isZoom: false,
    maxApertureFStop: 1.4,
    minApertureFStop: 16.0,
    anamorphicSqueezeRatio: 1.0,
    apertureBlades: 15,
    distortionK1: 0.008,
    distortionK2: -0.001,
    chromaticAberrationPx: 1.8,
    vignetteStrength: 0.35,
    flaringCharacter: 'VINTAGE_WARM_HALATION'
  },
  'arri-master-anamorphic-50': {
    id: 'arri-master-anamorphic-50',
    name: 'ARRI Master Anamorphic 50mm T1.9 (2x Squeeze)',
    lensType: 'PRIME_ANAMORPHIC',
    manufacturer: 'ARRI / Zeiss',
    focalLengthMm: 50,
    isZoom: false,
    maxApertureFStop: 1.9,
    minApertureFStop: 22.0,
    anamorphicSqueezeRatio: 2.0, // 2x horizontal squeeze -> oval bokeh
    apertureBlades: 11,
    distortionK1: -0.025, // Characteristic anamorphic curvature
    distortionK2: 0.006,
    chromaticAberrationPx: 1.4,
    vignetteStrength: 0.30,
    flaringCharacter: 'ANAMORPHIC_BLUE_STREAK'
  },
  'angenieux-optimo-24-290': {
    id: 'angenieux-optimo-24-290',
    name: 'Angenieux Optimo 24-290mm T2.8 Cine Zoom',
    lensType: 'CINE_ZOOM',
    manufacturer: 'Angenieux',
    focalLengthMm: 75,
    isZoom: true,
    zoomRangeMm: [24, 290],
    maxApertureFStop: 2.8,
    minApertureFStop: 22.0,
    anamorphicSqueezeRatio: 1.0,
    apertureBlades: 9,
    distortionK1: -0.012,
    distortionK2: 0.002,
    chromaticAberrationPx: 0.9,
    vignetteStrength: 0.22,
    flaringCharacter: 'CLEAN_COATED'
  },
  'arri-macro-100': {
    id: 'arri-macro-100',
    name: 'ARRI Master Macro 100mm T2.0 (1:1 Close-Up)',
    lensType: 'MACRO_CINE',
    manufacturer: 'ARRI / Zeiss',
    focalLengthMm: 100,
    isZoom: false,
    maxApertureFStop: 2.0,
    minApertureFStop: 32.0,
    anamorphicSqueezeRatio: 1.0,
    apertureBlades: 9,
    distortionK1: 0.000, // Near zero distortion
    distortionK2: 0.000,
    chromaticAberrationPx: 0.1,
    vignetteStrength: 0.08,
    flaringCharacter: 'CLEAN_COATED'
  },
  'leica-summicron-c-21': {
    id: 'leica-summicron-c-21',
    name: 'Leica Summicron-C 21mm T2.0',
    lensType: 'ULTRA_WIDE_EXPANSIVE',
    manufacturer: 'Leitz Cine',
    focalLengthMm: 21,
    isZoom: false,
    maxApertureFStop: 2.0,
    minApertureFStop: 22.0,
    anamorphicSqueezeRatio: 1.0,
    apertureBlades: 11,
    distortionK1: -0.014,
    distortionK2: 0.002,
    chromaticAberrationPx: 0.6,
    vignetteStrength: 0.18,
    flaringCharacter: 'CLEAN_COATED'
  }
};
