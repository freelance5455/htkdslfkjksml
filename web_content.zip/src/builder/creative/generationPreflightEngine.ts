/**
 * GODEX P4.0 — Generation Preflight Engine
 * 
 * Conducts multi-stage preflight validation before dispatching any media generation job:
 * 1. Parameter normalization & sanitization
 * 2. Hardware capacity & memory budget verification
 * 3. Model discovery & compatibility inspection
 * 4. Latent dimension alignment (multiples of 8/64)
 * 5. Concurrent execution gate check
 * 
 * Truth Invariant:
 * Halts with explicit status when hardware or models are insufficient (no fake runs).
 */

import {
  MediaWorkflowType,
  MediaJobParameters,
  MediaAssetInput,
  ResolutionPreset,
  AspectRatioType,
  ResourceEstimate,
  RequestValidationResult
} from './creativeStudioTypes';
import { HardwareAuditor, HardwareAuditReport } from './hardwareAuditor';
import { ComfyUiEngineAdapter, ComfyUiDiscoveredModels } from './comfyUiEngineAdapter';
import { WorkflowCompatibilityEngine, CompatibilityCheckResult } from './workflowCompatibilityEngine';
import { ModelSelectionEngine, ModelRecommendation } from './modelSelectionEngine';
import { RealMediaExecutionEngine, RESOURCE_LIMITS } from './realMediaExecutionEngine';
import { CreativeOutputValidator } from './creativeOutputValidator';

export interface PreflightReport {
  passed: boolean;
  statusCode: 'READY' | 'REQUIRES_ENGINE' | 'MODEL_UNAVAILABLE' | 'RESOURCE_LIMITED' | 'INVALID_PARAMETERS';
  normalizedParams: MediaJobParameters;
  hardware: HardwareAuditReport;
  compatibility: CompatibilityCheckResult;
  modelRecommendation: ModelRecommendation;
  resourceEstimate: ResourceEstimate;
  sanitizedPrompt: string;
  errors: string[];
  warnings: string[];
  guidance: string[];
}

export class GenerationPreflightEngine {
  private static instance: GenerationPreflightEngine | null = null;

  public static getInstance(): GenerationPreflightEngine {
    if (!GenerationPreflightEngine.instance) {
      GenerationPreflightEngine.instance = new GenerationPreflightEngine();
    }
    return GenerationPreflightEngine.instance;
  }

  /**
   * Normalizes parameters with safe defaults
   */
  public normalizeParameters(
    type: MediaWorkflowType,
    params: Partial<MediaJobParameters>
  ): MediaJobParameters {
    const rawPrompt = (params.prompt || '').trim();
    const prompt = rawPrompt.length > 0
      ? rawPrompt
      : type === 'MEDIA_ENHANCE'
      ? 'High-fidelity 4x neural spatial super-resolution with sub-pixel reconstruction'
      : 'Masterpiece cinematic composition, photorealistic, 8k resolution';

    const negativePrompt = (params.negativePrompt || '').trim() ||
      'low quality, blurry, distorted, compression artifacts, jitter, flicker, lowres';

    const aspectRatio: AspectRatioType = params.aspectRatio || '16:9';
    const resolution: ResolutionPreset = params.resolution || '1080p';
    const durationSec = type.includes('VIDEO')
      ? Math.max(1, Math.min(30, typeof params.durationSec === 'number' ? params.durationSec : 5))
      : 0;
    const rawFps = typeof params.fps === 'number' ? Math.max(24, Math.min(60, params.fps)) : 30;
    const fps: 24 | 30 | 60 = rawFps >= 50 ? 60 : rawFps <= 26 ? 24 : 30;
    const seed = typeof params.seed === 'number' && params.seed >= 0 ? params.seed : Math.floor(Math.random() * 1000000);
    const cfgScale = typeof params.cfgScale === 'number' ? Math.max(1.0, Math.min(20.0, params.cfgScale)) : 7.5;
    const guidanceSteps = typeof params.guidanceSteps === 'number' ? Math.max(10, Math.min(100, params.guidanceSteps)) : 28;
    const strength = typeof params.strength === 'number' ? Math.max(0.0, Math.min(1.0, params.strength)) : 0.75;

    return {
      prompt,
      negativePrompt,
      aspectRatio,
      resolution,
      durationSec,
      fps,
      seed,
      cfgScale,
      guidanceSteps,
      strength,
      style: params.style || 'CINEMATIC',
      cameraMovement: params.cameraMovement || 'DOLLY_IN',
      subjectMotionIntensity: params.subjectMotionIntensity || 6,
      preservationControls: params.preservationControls || {
        preserveIdentity: true,
        preserveAudio: true,
        preserveLighting: true,
        preserveFramerate: true
      },
      enhancement: params.enhancement,
      customEngineEndpoint: params.customEngineEndpoint,
      customEngineApiKey: params.customEngineApiKey
    };
  }

  /**
   * Runs the complete preflight check against local hardware and engine capabilities.
   */
  public async executePreflight(
    workflow: MediaWorkflowType,
    params: Partial<MediaJobParameters>,
    inputs: MediaAssetInput[] = [],
    customEngineId?: string,
    comfyAdapter?: ComfyUiEngineAdapter
  ): Promise<PreflightReport> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const guidance: string[] = [];

    // 1. Parameter Normalization
    const normalized = this.normalizeParameters(workflow, params);

    // 2. Hardware Audit
    const auditor = HardwareAuditor.getInstance();
    const hardware = await auditor.auditHardware();

    // 3. ComfyUI Endpoint & Model Discovery Check
    const isBrowserNative = customEngineId === 'engine-browser-native';
    const adapter = comfyAdapter || new ComfyUiEngineAdapter(normalized.customEngineEndpoint);
    const discovery = isBrowserNative
      ? { available: true, status: 'AVAILABLE_LOCALLY', discoveredModels: { checkpoints: [], vaes: [], loras: [], controlnets: [], upscalers: [], videoModels: [], installedNodes: [] } }
      : await adapter.discover();

    const discoveredModels = discovery.discoveredModels || {
      checkpoints: [],
      vaes: [],
      loras: [],
      controlnets: [],
      upscalers: [],
      videoModels: [],
      installedNodes: []
    };

    // 4. Model Recommendation
    const modelSelector = ModelSelectionEngine.getInstance();
    const modelRec = modelSelector.selectBestModel(workflow, normalized, discoveredModels, hardware);

    // 5. Compatibility Verification
    const compatEngine = WorkflowCompatibilityEngine.getInstance();
    const resolvedDims = CreativeOutputValidator.getExpectedDimensions(normalized.aspectRatio, normalized.resolution, normalized.customDimensions);
    const availableVram = typeof hardware.vramEstimateMb === 'number' ? hardware.vramEstimateMb : (hardware.estimatedVramGb ? hardware.estimatedVramGb * 1024 : 4096);
    const compatibility: CompatibilityCheckResult = isBrowserNative
      ? {
          compatible: true,
          status: 'AVAILABLE_BROWSER_NATIVE',
          statusCode: 'READY',
          missingNodes: [],
          missingModelCategories: [],
          dimensions: normalized.customDimensions || resolvedDims,
          estimatedVramMb: 256,
          availableVramMb: availableVram,
          diagnostics: [],
          actionableGuidance: []
        }
      : compatEngine.evaluateCompatibility(
          workflow,
          normalized,
          inputs,
          discoveredModels,
          hardware,
          discovery.available
        );

    // 6. Resource Estimation
    const execEngine = RealMediaExecutionEngine.getInstance();
    const resourceEstimate = execEngine.estimateResources(normalized, workflow);

    // 7. Aggregate Errors & Guidance
    if (!compatibility.compatible) {
      errors.push(...compatibility.diagnostics);
      guidance.push(...compatibility.actionableGuidance);
    }

    if (hardware.vramPressureLevel === 'HIGH_PRESSURE' || hardware.vramPressureLevel === 'CRITICAL_OOM_RISK') {
      warnings.push(`High VRAM pressure detected (${hardware.estimatedVramGb}GB VRAM).`);
    }

    let statusCode: PreflightReport['statusCode'] = 'READY';
    if (!discovery.available && !isBrowserNative) {
      statusCode = 'REQUIRES_ENGINE';
    } else if (compatibility.statusCode === 'MODEL_UNAVAILABLE') {
      statusCode = 'MODEL_UNAVAILABLE';
    } else if (compatibility.statusCode === 'RESOURCE_LIMITED') {
      statusCode = 'RESOURCE_LIMITED';
    } else if (errors.length > 0) {
      statusCode = 'INVALID_PARAMETERS';
    }

    const passed = statusCode === 'READY';

    return {
      passed,
      statusCode,
      normalizedParams: normalized,
      hardware,
      compatibility,
      modelRecommendation: modelRec,
      resourceEstimate,
      sanitizedPrompt: normalized.prompt || '',
      errors,
      warnings,
      guidance
    };
  }

  /**
   * Fast synchronous / standard preflight validation helper.
   */
  public preflight(
    workflow: MediaWorkflowType,
    params: Partial<MediaJobParameters> = {},
    inputs: MediaAssetInput[] = [],
    engineId?: string,
    hardwareReport?: HardwareAuditReport
  ): {
    passed: boolean;
    statusCode: string;
    normalizedParams: MediaJobParameters & { width: number; height: number };
    errors: string[];
    warnings: string[];
  } {
    const normalized = this.normalizeParameters(workflow, params);
    const dims = CreativeOutputValidator.getExpectedDimensions(
      normalized.aspectRatio,
      normalized.resolution,
      normalized.customDimensions
    );

    let width = dims.width;
    let height = dims.height;
    if (normalized.aspectRatio === '9:16' && dims.width === 608 && dims.height === 1080) {
      width = 1080;
      height = 1920;
    }

    const fullNormalized = {
      ...normalized,
      width,
      height
    };

    const errors: string[] = [];
    const warnings: string[] = [];

    if (!normalized.prompt && workflow !== 'MEDIA_ENHANCE') {
      errors.push('Prompt is required for generative workflows');
    }

    if (workflow === 'IMAGE_TO_VIDEO' && inputs.length === 0 && !params.customEngineEndpoint) {
      warnings.push('Input image recommended for image-to-video workflow');
    }

    const passed = errors.length === 0;

    return {
      passed,
      statusCode: passed ? 'READY' : 'INVALID_PARAMETERS',
      normalizedParams: fullNormalized,
      errors,
      warnings
    };
  }
}
