/**
 * GODEX P4.8 — Camera & Cinematic Control Engine
 * 
 * Manages 16 distinct cinematic camera trajectories, speed curves, framing transitions,
 * physical 3D kinematics, and converts them into concrete neural engine parameters
 * (SVD motion bucket IDs, AnimateDiff Camera LoRA matrix embeddings, and WanVideo camera vectors).
 */

import {
  CameraMovementType,
  CameraTrajectoryPlan,
  SpeedCurveType
} from './creativeStudioTypes';
import {
  CameraPose3D,
  CameraKinematics,
  FieldOfViewCalculation
} from './camera/cinematicCameraTypes';
import { OpticalSimulationEngine } from './camera/opticalSimulationEngine';

export interface CameraMotionDefinition {
  type: CameraMovementType;
  label: string;
  category: 'HORIZONTAL' | 'VERTICAL' | 'DEPTH' | 'ORBITAL' | 'DYNAMIC' | 'STATIONARY';
  description: string;
  defaultIntensity: number; // 1-10
  defaultSpeedCurve: SpeedCurveType;
  defaultStartFraming: string;
  defaultEndFraming: string;
  svdMotionBucketBase: number;
  cameraLoraVector: { pan: number; tilt: number; zoom: number; roll: number };
  defaultVelocityMps: number;
  defaultAngularVelocityDegSec: number;
}

export interface CameraTrajectoryWaypoint {
  timestampSec: number;
  progressPercent: number; // 0.0 to 1.0
  pose: CameraPose3D;
  fovHorizontalDeg: number;
}

export const CAMERA_MOTION_DEFINITIONS: Record<CameraMovementType, CameraMotionDefinition> = {
  STATIC: {
    type: 'STATIC',
    label: 'Locked-Off Static Tripod',
    category: 'STATIONARY',
    description: 'Rock-solid tripod lock with zero camera displacement, focusing entirely on internal subject motion.',
    defaultIntensity: 1,
    defaultSpeedCurve: 'LINEAR',
    defaultStartFraming: 'Medium wide shot',
    defaultEndFraming: 'Medium wide shot',
    svdMotionBucketBase: 60,
    cameraLoraVector: { pan: 0, tilt: 0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 0.0
  },
  PAN_LEFT: {
    type: 'PAN_LEFT',
    label: 'Pan Left',
    category: 'HORIZONTAL',
    description: 'Horizontal rotation of the camera from right to left on a fixed vertical axis.',
    defaultIntensity: 5,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Right-weighted frame',
    defaultEndFraming: 'Left-weighted frame',
    svdMotionBucketBase: 120,
    cameraLoraVector: { pan: -1.0, tilt: 0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 8.0
  },
  PAN_RIGHT: {
    type: 'PAN_RIGHT',
    label: 'Pan Right',
    category: 'HORIZONTAL',
    description: 'Horizontal rotation of the camera from left to right on a fixed vertical axis.',
    defaultIntensity: 5,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Left-weighted frame',
    defaultEndFraming: 'Right-weighted frame',
    svdMotionBucketBase: 120,
    cameraLoraVector: { pan: 1.0, tilt: 0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 8.0
  },
  PAN: {
    type: 'PAN',
    label: 'Pan (Smooth Sweep)',
    category: 'HORIZONTAL',
    description: 'Smooth panoramic horizontal sweep.',
    defaultIntensity: 5,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Wide shot',
    defaultEndFraming: 'Wide shot',
    svdMotionBucketBase: 120,
    cameraLoraVector: { pan: 0.8, tilt: 0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 8.0
  },
  TILT_UP: {
    type: 'TILT_UP',
    label: 'Tilt Up',
    category: 'VERTICAL',
    description: 'Vertical rotation pointing the optical axis upwards, revealing towering vertical scale.',
    defaultIntensity: 5,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Ground level',
    defaultEndFraming: 'Skyline / Zenith',
    svdMotionBucketBase: 115,
    cameraLoraVector: { pan: 0, tilt: 1.0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 6.0
  },
  TILT: {
    type: 'TILT',
    label: 'Tilt (Vertical Sweep)',
    category: 'VERTICAL',
    description: 'Smooth vertical tilt sweep on a fixed axis.',
    defaultIntensity: 5,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Eye level',
    defaultEndFraming: 'Elevated or low framing',
    svdMotionBucketBase: 115,
    cameraLoraVector: { pan: 0, tilt: 0.8, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 6.0
  },
  TILT_DOWN: {
    type: 'TILT_DOWN',
    label: 'Tilt Down',
    category: 'VERTICAL',
    description: 'Vertical rotation pointing the optical axis downwards to reveal ground elements.',
    defaultIntensity: 5,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Sky level',
    defaultEndFraming: 'Ground level',
    svdMotionBucketBase: 115,
    cameraLoraVector: { pan: 0, tilt: -1.0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 6.0
  },
  DOLLY: {
    type: 'DOLLY',
    label: 'Dolly Track',
    category: 'DEPTH',
    description: 'Physical displacement moving camera along optical depth axis.',
    defaultIntensity: 6,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Medium establishing',
    defaultEndFraming: 'Dynamic framing',
    svdMotionBucketBase: 140,
    cameraLoraVector: { pan: 0, tilt: 0, zoom: 0.8, roll: 0 },
    defaultVelocityMps: 0.5,
    defaultAngularVelocityDegSec: 0.0
  },
  DOLLY_IN: {
    type: 'DOLLY_IN',
    label: 'Dolly In (Push Forward)',
    category: 'DEPTH',
    description: 'Physical displacement moving camera forward in 3D space towards subject, expanding background parallax.',
    defaultIntensity: 6,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Wide establishing',
    defaultEndFraming: 'Intimate close-up',
    svdMotionBucketBase: 140,
    cameraLoraVector: { pan: 0, tilt: 0, zoom: 1.0, roll: 0 },
    defaultVelocityMps: 0.6,
    defaultAngularVelocityDegSec: 0.0
  },
  DOLLY_OUT: {
    type: 'DOLLY_OUT',
    label: 'Dolly Out (Pull Back)',
    category: 'DEPTH',
    description: 'Physical displacement moving camera backward in 3D space away from subject, revealing broader scene context.',
    defaultIntensity: 6,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Close-up',
    defaultEndFraming: 'Wide establishing',
    svdMotionBucketBase: 140,
    cameraLoraVector: { pan: 0, tilt: 0, zoom: -1.0, roll: 0 },
    defaultVelocityMps: 0.6,
    defaultAngularVelocityDegSec: 0.0
  },
  TRUCK: {
    type: 'TRUCK',
    label: 'Truck (Lateral Dolly)',
    category: 'HORIZONTAL',
    description: 'Lateral translation along horizontal track.',
    defaultIntensity: 5,
    defaultSpeedCurve: 'LINEAR',
    defaultStartFraming: 'Origin framing',
    defaultEndFraming: 'Translated framing',
    svdMotionBucketBase: 130,
    cameraLoraVector: { pan: 0.6, tilt: 0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.7,
    defaultAngularVelocityDegSec: 0.0
  },
  TRUCK_LEFT: {
    type: 'TRUCK_LEFT',
    label: 'Truck Left (Lateral Track)',
    category: 'HORIZONTAL',
    description: 'Physical lateral camera translation to the left along track, showcasing deep foreground-background parallax.',
    defaultIntensity: 5,
    defaultSpeedCurve: 'LINEAR',
    defaultStartFraming: 'Right origin',
    defaultEndFraming: 'Left destination',
    svdMotionBucketBase: 130,
    cameraLoraVector: { pan: -0.8, tilt: 0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.8,
    defaultAngularVelocityDegSec: 0.0
  },
  TRUCK_RIGHT: {
    type: 'TRUCK_RIGHT',
    label: 'Truck Right (Lateral Track)',
    category: 'HORIZONTAL',
    description: 'Physical lateral camera translation to the right along track, showcasing deep foreground-background parallax.',
    defaultIntensity: 5,
    defaultSpeedCurve: 'LINEAR',
    defaultStartFraming: 'Left origin',
    defaultEndFraming: 'Right destination',
    svdMotionBucketBase: 130,
    cameraLoraVector: { pan: 0.8, tilt: 0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.8,
    defaultAngularVelocityDegSec: 0.0
  },
  ORBIT: {
    type: 'ORBIT',
    label: 'Orbital Arc Track',
    category: 'ORBITAL',
    description: 'Circular orbital arc around the focal point maintaining locked distance while revealing 360-degree environmental depth.',
    defaultIntensity: 7,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Front 45° angle',
    defaultEndFraming: 'Opposing 45° profile',
    svdMotionBucketBase: 160,
    cameraLoraVector: { pan: 1.5, tilt: 0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.5,
    defaultAngularVelocityDegSec: 15.0
  },
  ORBIT_360: {
    type: 'ORBIT_360',
    label: 'Orbital 360° Arc',
    category: 'ORBITAL',
    description: 'Complete 360-degree rotational orbit around the subject showcasing full dimensional form.',
    defaultIntensity: 8,
    defaultSpeedCurve: 'LINEAR',
    defaultStartFraming: 'Direct front',
    defaultEndFraming: 'Direct front (full revolution)',
    svdMotionBucketBase: 180,
    cameraLoraVector: { pan: 2.0, tilt: 0, zoom: 0, roll: 0 },
    defaultVelocityMps: 0.5,
    defaultAngularVelocityDegSec: 30.0
  },
  CRANE: {
    type: 'CRANE',
    label: 'Crane / Jib Elevation',
    category: 'VERTICAL',
    description: 'Sweeping vertical crane arm motion elevating high above the scene.',
    defaultIntensity: 7,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Eye-level intimate',
    defaultEndFraming: 'High-angle god-view',
    svdMotionBucketBase: 145,
    cameraLoraVector: { pan: 0, tilt: 1.5, zoom: -0.5, roll: 0 },
    defaultVelocityMps: 0.7,
    defaultAngularVelocityDegSec: 5.0
  },
  CRANE_UP: {
    type: 'CRANE_UP',
    label: 'Crane Ascend',
    category: 'VERTICAL',
    description: 'Ascending crane sweep expanding perspective to overhead view.',
    defaultIntensity: 7,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Low ground plane',
    defaultEndFraming: 'Elevated overhead view',
    svdMotionBucketBase: 145,
    cameraLoraVector: { pan: 0, tilt: 1.5, zoom: -0.5, roll: 0 },
    defaultVelocityMps: 0.7,
    defaultAngularVelocityDegSec: 5.0
  },
  CRANE_DOWN: {
    type: 'CRANE_DOWN',
    label: 'Crane Descend',
    category: 'VERTICAL',
    description: 'Descending crane swoop settling gently down towards eye-level.',
    defaultIntensity: 7,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'High overhead',
    defaultEndFraming: 'Close eye-level',
    svdMotionBucketBase: 145,
    cameraLoraVector: { pan: 0, tilt: -1.5, zoom: 0.5, roll: 0 },
    defaultVelocityMps: 0.7,
    defaultAngularVelocityDegSec: 5.0
  },
  ZOOM: {
    type: 'ZOOM',
    label: 'Optical Zoom',
    category: 'DEPTH',
    description: 'Focal length change altering perspective compression without moving the physical camera.',
    defaultIntensity: 6,
    defaultSpeedCurve: 'SMOOTH_RAMP',
    defaultStartFraming: 'Wide angle',
    defaultEndFraming: 'Telephoto compression',
    svdMotionBucketBase: 130,
    cameraLoraVector: { pan: 0, tilt: 0, zoom: 1.5, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 0.0
  },
  ZOOM_PULL: {
    type: 'ZOOM_PULL',
    label: 'Crash Zoom / Snap Pull',
    category: 'DYNAMIC',
    description: 'Rapid high-speed zoom snap instantly locking onto key narrative detail.',
    defaultIntensity: 8,
    defaultSpeedCurve: 'EXPONENTIAL',
    defaultStartFraming: 'Wide shot',
    defaultEndFraming: 'Extreme close up',
    svdMotionBucketBase: 175,
    cameraLoraVector: { pan: 0, tilt: 0, zoom: 2.0, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 0.0
  },
  ZOOM_IN: {
    type: 'ZOOM_IN',
    label: 'Zoom In',
    category: 'DEPTH',
    description: 'Gradual telephoto zoom compression towards subject.',
    defaultIntensity: 6,
    defaultSpeedCurve: 'SMOOTH_RAMP',
    defaultStartFraming: 'Medium shot',
    defaultEndFraming: 'Tight portrait',
    svdMotionBucketBase: 130,
    cameraLoraVector: { pan: 0, tilt: 0, zoom: 1.3, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 0.0
  },
  ZOOM_OUT: {
    type: 'ZOOM_OUT',
    label: 'Zoom Out',
    category: 'DEPTH',
    description: 'Gradual wide angle zoom opening the framing.',
    defaultIntensity: 6,
    defaultSpeedCurve: 'SMOOTH_RAMP',
    defaultStartFraming: 'Close-up',
    defaultEndFraming: 'Wide shot',
    svdMotionBucketBase: 130,
    cameraLoraVector: { pan: 0, tilt: 0, zoom: -1.3, roll: 0 },
    defaultVelocityMps: 0.0,
    defaultAngularVelocityDegSec: 0.0
  },
  TRACKING: {
    type: 'TRACKING',
    label: 'Subject Tracking Shot',
    category: 'DYNAMIC',
    description: 'Matched velocity tracking maintaining constant relative distance to moving subject.',
    defaultIntensity: 7,
    defaultSpeedCurve: 'LINEAR',
    defaultStartFraming: 'Subject in motion',
    defaultEndFraming: 'Subject in motion',
    svdMotionBucketBase: 150,
    cameraLoraVector: { pan: 0, tilt: 0, zoom: 0.4, roll: 0 },
    defaultVelocityMps: 1.2,
    defaultAngularVelocityDegSec: 0.0
  },
  TRACKING_SHOT: {
    type: 'TRACKING_SHOT',
    label: 'Tracking Shot (Dynamic)',
    category: 'DYNAMIC',
    description: 'Kinetic subject-following trajectory.',
    defaultIntensity: 7,
    defaultSpeedCurve: 'LINEAR',
    defaultStartFraming: 'Subject follow',
    defaultEndFraming: 'Subject follow',
    svdMotionBucketBase: 150,
    cameraLoraVector: { pan: 0, tilt: 0, zoom: 0.4, roll: 0 },
    defaultVelocityMps: 1.2,
    defaultAngularVelocityDegSec: 0.0
  },
  HANDHELD: {
    type: 'HANDHELD',
    label: 'Handheld Organic',
    category: 'DYNAMIC',
    description: 'Subtle organic human breathing and hand tremors adding documentary realism.',
    defaultIntensity: 4,
    defaultSpeedCurve: 'LINEAR',
    defaultStartFraming: 'Medium close-up',
    defaultEndFraming: 'Medium close-up',
    svdMotionBucketBase: 110,
    cameraLoraVector: { pan: 0.2, tilt: 0.2, zoom: 0, roll: 0.2 },
    defaultVelocityMps: 0.1,
    defaultAngularVelocityDegSec: 1.5
  },
  HANDHELD_DYNAMIC: {
    type: 'HANDHELD_DYNAMIC',
    label: 'Handheld Dynamic Run',
    category: 'DYNAMIC',
    description: 'Vigorous kinetic handheld motion simulating running alongside subject in high tension.',
    defaultIntensity: 8,
    defaultSpeedCurve: 'EXPONENTIAL',
    defaultStartFraming: 'Kinetic run',
    defaultEndFraming: 'High-energy motion',
    svdMotionBucketBase: 190,
    cameraLoraVector: { pan: 0.6, tilt: 0.6, zoom: 0.2, roll: 0.8 },
    defaultVelocityMps: 1.5,
    defaultAngularVelocityDegSec: 4.0
  },
  DEPTH_AWARE_MOVEMENT: {
    type: 'DEPTH_AWARE_MOVEMENT',
    label: 'Depth-Aware Multi-Axis Parallax',
    category: 'ORBITAL',
    description: 'Advanced compound trajectory with simultaneous dolly and pan producing maximum 3D parallax.',
    defaultIntensity: 8,
    defaultSpeedCurve: 'EASE_IN_OUT',
    defaultStartFraming: 'Layered foreground/subject/background',
    defaultEndFraming: 'Sweeping depth perspective transformation',
    svdMotionBucketBase: 170,
    cameraLoraVector: { pan: 1.2, tilt: 0.4, zoom: 0.8, roll: 0.1 },
    defaultVelocityMps: 0.8,
    defaultAngularVelocityDegSec: 10.0
  }
};

export class CameraControlEngine {
  private static instance: CameraControlEngine | null = null;
  private opticalEngine: OpticalSimulationEngine;

  private constructor() {
    this.opticalEngine = OpticalSimulationEngine.getInstance();
  }

  public static getInstance(): CameraControlEngine {
    if (!CameraControlEngine.instance) {
      CameraControlEngine.instance = new CameraControlEngine();
    }
    return CameraControlEngine.instance;
  }

  /**
   * Plans the camera trajectory and calculates concrete engine parameters.
   */
  public planTrajectory(
    movement: CameraMovementType = 'DOLLY_IN',
    intensity: number = 6,
    speedCurve: SpeedCurveType = 'EASE_IN_OUT'
  ): CameraTrajectoryPlan {
    const def = CAMERA_MOTION_DEFINITIONS[movement] || CAMERA_MOTION_DEFINITIONS.DOLLY_IN;
    const clampedIntensity = Math.max(1, Math.min(10, intensity));

    // Calculate SVD motion bucket ID (scale from base with intensity multiplier)
    const intensityFactor = clampedIntensity / 5.0; // 0.2 to 2.0
    const calculatedMotionBucket = Math.round(
      Math.max(10, Math.min(255, def.svdMotionBucketBase * intensityFactor))
    );

    // Calculate scaled LoRA vector
    const scaledLora = {
      pan: Number((def.cameraLoraVector.pan * intensityFactor).toFixed(2)),
      tilt: Number((def.cameraLoraVector.tilt * intensityFactor).toFixed(2)),
      zoom: Number((def.cameraLoraVector.zoom * intensityFactor).toFixed(2)),
      roll: Number((def.cameraLoraVector.roll * intensityFactor).toFixed(2))
    };

    return {
      movement,
      motionIntensity: clampedIntensity,
      speedCurve,
      startFraming: def.defaultStartFraming,
      endFraming: def.defaultEndFraming,
      supportedByEngine: true,
      engineParameters: {
        motionBucketId: calculatedMotionBucket,
        cameraLoraVector: scaledLora,
        speedCurve
      }
    };
  }

  /**
   * Generates a smooth 3D spatial trajectory waypoint list over the duration.
   */
  public generateTrajectoryWaypoints(
    initialPose: CameraPose3D,
    kinematics: CameraKinematics,
    durationSec: number,
    focalLengthMm: number = 50,
    steps: number = 10
  ): CameraTrajectoryWaypoint[] {
    const waypoints: CameraTrajectoryWaypoint[] = [];
    const def = CAMERA_MOTION_DEFINITIONS[kinematics.movementType] || CAMERA_MOTION_DEFINITIONS.STATIC;
    const defaultCam = this.opticalEngine.getDefaultCamera();
    const fovCalc = this.opticalEngine.calculateFieldOfView(defaultCam, focalLengthMm);

    for (let i = 0; i <= steps; i++) {
      const progress = i / steps;
      const time = Number((progress * durationSec).toFixed(2));

      // Ease in out interpolation curve
      let eased = progress;
      if (kinematics.speedCurve === 'EASE_IN_OUT') {
        eased = progress < 0.5 ? 2 * progress * progress : 1 - Math.pow(-2 * progress + 2, 2) / 2;
      } else if (kinematics.speedCurve === 'EXPONENTIAL') {
        eased = Math.pow(progress, 2);
      }

      const intensityMult = (kinematics.intensity || 5) / 5.0;

      // Compute spatial displacement based on movement type
      let deltaHeight = 0;
      let deltaDist = 0;
      let deltaPan = 0;
      let deltaTilt = 0;
      let deltaRoll = 0;

      switch (kinematics.movementType) {
        case 'DOLLY_IN':
          deltaDist = -eased * 1.5 * intensityMult;
          break;
        case 'DOLLY_OUT':
          deltaDist = eased * 1.5 * intensityMult;
          break;
        case 'PAN_LEFT':
          deltaPan = -eased * 20.0 * intensityMult;
          break;
        case 'PAN_RIGHT':
        case 'PAN':
          deltaPan = eased * 20.0 * intensityMult;
          break;
        case 'TILT_UP':
          deltaTilt = eased * 15.0 * intensityMult;
          break;
        case 'TILT_DOWN':
          deltaTilt = -eased * 15.0 * intensityMult;
          break;
        case 'CRANE':
        case 'CRANE_UP':
          deltaHeight = eased * 2.0 * intensityMult;
          deltaTilt = -eased * 10.0 * intensityMult;
          break;
        case 'CRANE_DOWN':
          deltaHeight = -eased * 1.5 * intensityMult;
          deltaTilt = eased * 10.0 * intensityMult;
          break;
        case 'ORBIT':
        case 'ORBIT_360':
          deltaPan = eased * (kinematics.movementType === 'ORBIT_360' ? 360 : 60) * intensityMult;
          break;
        case 'HANDHELD':
        case 'HANDHELD_DYNAMIC': {
          const freq = kinematics.movementType === 'HANDHELD_DYNAMIC' ? 4 : 2;
          const amp = kinematics.movementType === 'HANDHELD_DYNAMIC' ? 0.8 : 0.2;
          deltaPan = Math.sin(time * freq) * amp * intensityMult;
          deltaTilt = Math.cos(time * freq * 1.3) * (amp * 0.7) * intensityMult;
          deltaRoll = Math.sin(time * freq * 0.7) * (amp * 0.5) * intensityMult;
          break;
        }
      }

      const waypointPose: CameraPose3D = {
        heightMeters: Number(Math.max(0.1, initialPose.heightMeters + deltaHeight).toFixed(2)),
        distanceToSubjectMeters: Number(Math.max(0.2, initialPose.distanceToSubjectMeters + deltaDist).toFixed(2)),
        panDeg: Number((initialPose.panDeg + deltaPan).toFixed(1)),
        tiltDeg: Number((initialPose.tiltDeg + deltaTilt).toFixed(1)),
        rollDeg: Number((initialPose.rollDeg + deltaRoll).toFixed(1))
      };

      waypoints.push({
        timestampSec: time,
        progressPercent: progress,
        pose: waypointPose,
        fovHorizontalDeg: fovCalc.horizontalDeg
      });
    }

    return waypoints;
  }

  public getMotionDefinition(movement: CameraMovementType): CameraMotionDefinition {
    return CAMERA_MOTION_DEFINITIONS[movement] || CAMERA_MOTION_DEFINITIONS.DOLLY_IN;
  }

  public getAllMovements(): CameraMotionDefinition[] {
    const uniqueKeys: CameraMovementType[] = [
      'STATIC', 'PAN_LEFT', 'PAN_RIGHT', 'TILT_UP', 'TILT_DOWN',
      'DOLLY_IN', 'DOLLY_OUT', 'TRUCK_LEFT', 'TRUCK_RIGHT',
      'ORBIT', 'CRANE', 'ZOOM', 'TRACKING', 'HANDHELD'
    ];
    return uniqueKeys.map(k => CAMERA_MOTION_DEFINITIONS[k]);
  }
}
