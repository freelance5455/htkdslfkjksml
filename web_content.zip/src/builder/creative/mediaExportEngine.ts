/**
 * GODEX P4.5 — Production Media Export Engine
 * 
 * Manages client-side and remote export capability discovery,
 * real binary container encoding (WebM, WAV, PNG Sequence),
 * and truthful format negotiation with Zero-Fabrication enforcement.
 */

import {
  ExportFormat,
  ExportCapability,
  FinalOutputValidationResult,
  AssemblyComposition
} from './mediaAssemblyTypes';
import { VideoEncodingCapabilityEngine } from './videoEncodingCapabilityEngine';

export class MediaExportEngine {
  private static instance: MediaExportEngine | null = null;

  public static getInstance(): MediaExportEngine {
    if (!MediaExportEngine.instance) {
      MediaExportEngine.instance = new MediaExportEngine();
    }
    return MediaExportEngine.instance;
  }

  /**
   * Audits actual host browser/runtime export capabilities.
   * Truthfully determines if WebM, MP4, WAV, or Image Sequences can be encoded locally.
   */
  public auditExportCapabilities(): ExportCapability[] {
    const isBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';
    const hasMediaRecorder = isBrowser && typeof (window as any).MediaRecorder !== 'undefined';
    const hasWebCodecs = typeof VideoEncoder !== 'undefined' && typeof VideoFrame !== 'undefined';

    const capabilities: ExportCapability[] = [];

    // 1. WebM Export Capability
    let webmSupported = false;
    let webmCodec = 'VP8 / Opus';
    if (hasMediaRecorder) {
      const MR = (window as any).MediaRecorder;
      if (MR.isTypeSupported('video/webm;codecs=vp9,opus')) {
        webmSupported = true;
        webmCodec = 'video/webm;codecs=vp9,opus';
      } else if (MR.isTypeSupported('video/webm;codecs=vp8,opus')) {
        webmSupported = true;
        webmCodec = 'video/webm;codecs=vp8,opus';
      } else if (MR.isTypeSupported('video/webm')) {
        webmSupported = true;
        webmCodec = 'video/webm';
      }
    }

    capabilities.push({
      format: 'WEBM',
      supported: webmSupported,
      encoderName: hasWebCodecs ? 'WebCodecs / Browser MediaRecorder (VP9/VP8)' : 'Browser Native MediaRecorder (VP9/VP8)',
      mimeType: 'video/webm',
      truthState: webmSupported ? 'AVAILABLE_BROWSER_NATIVE' : 'UNAVAILABLE',
      preferredCodec: webmCodec,
      reason: webmSupported ? 'Hardware-accelerated browser MediaRecorder supported' : 'MediaRecorder WebM not supported in current host'
    });

    // 2. MP4 Export Capability (Strict Zero-Fabrication Check)
    let mp4Supported = false;
    if (hasMediaRecorder) {
      const MR = (window as any).MediaRecorder;
      if (MR.isTypeSupported('video/mp4;codecs=avc1') || MR.isTypeSupported('video/mp4')) {
        mp4Supported = true;
      }
    }

    capabilities.push({
      format: 'MP4',
      supported: mp4Supported,
      encoderName: mp4Supported ? 'Browser Native MediaRecorder (H.264/AAC)' : 'External Transcoder Required',
      mimeType: 'video/mp4',
      truthState: mp4Supported ? 'AVAILABLE_BROWSER_NATIVE' : 'REQUIRES_ENGINE',
      preferredCodec: mp4Supported ? 'H.264' : undefined,
      reason: mp4Supported 
        ? 'Native browser MP4 container encoding available' 
        : 'MP4 encoding is not natively exposed by current browser/webview runtime. Use WebM or connect an external ffmpeg transcoder.'
    });

    // 3. 16-bit WAV PCM Audio Capability (Always fully available in JavaScript/TypeScript!)
    capabilities.push({
      format: 'WAV',
      supported: true,
      encoderName: 'GODEX Pure DSP RIFF 16-bit PCM Binary Encoder',
      mimeType: 'audio/wav',
      truthState: 'AVAILABLE_LOCALLY',
      preferredCodec: 'PCM_S16LE',
      reason: 'Deterministic client-side RIFF binary encoder'
    });

    // 4. PNG Image Sequence Capability
    capabilities.push({
      format: 'PNG_SEQUENCE',
      supported: isBrowser,
      encoderName: 'Canvas2D toBlob PNG Encoder',
      mimeType: 'image/png',
      truthState: isBrowser ? 'AVAILABLE_BROWSER_NATIVE' : 'UNAVAILABLE',
      preferredCodec: 'PNG-RGB8',
      reason: isBrowser ? 'Lossless raster frame sequence generator' : 'Headless environment missing canvas'
    });

    // 5. JPEG Sequence Capability
    capabilities.push({
      format: 'JPEG_SEQUENCE',
      supported: isBrowser,
      encoderName: 'Canvas2D toBlob JPEG Encoder',
      mimeType: 'image/jpeg',
      truthState: isBrowser ? 'AVAILABLE_BROWSER_NATIVE' : 'UNAVAILABLE',
      preferredCodec: 'JPEG-Baseline',
      reason: isBrowser ? 'Standard raster frame sequence' : 'Headless environment missing canvas'
    });

    // 6. WebP Sequence Capability
    capabilities.push({
      format: 'WEBP_SEQUENCE',
      supported: isBrowser,
      encoderName: 'Canvas2D toBlob WebP Encoder',
      mimeType: 'image/webp',
      truthState: isBrowser ? 'AVAILABLE_BROWSER_NATIVE' : 'UNAVAILABLE',
      preferredCodec: 'WEBP-Lossy',
      reason: isBrowser ? 'High-compression raster frame sequence' : 'Headless environment missing canvas'
    });

    return capabilities;
  }

  /**
   * Encodes 16-bit Stereo PCM Float32Array buffers into a valid binary ArrayBuffer (RIFF WAV format).
   */
  public encodeWav(leftPcm: Float32Array, rightPcm: Float32Array | undefined, sampleRate: number = 44100): ArrayBuffer {
    const numChannels = rightPcm ? 2 : 1;
    const sampleCount = leftPcm.length;
    const bytesPerSample = 2; // 16-bit
    const blockAlign = numChannels * bytesPerSample;
    const byteRate = sampleRate * blockAlign;
    const dataSize = sampleCount * blockAlign;
    const bufferSize = 44 + dataSize;

    const buffer = new ArrayBuffer(bufferSize);
    const view = new DataView(buffer);

    // RIFF Chunk Descriptor
    this.writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + dataSize, true);
    this.writeString(view, 8, 'WAVE');

    // fmt Subchunk
    this.writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);             // Subchunk1Size for PCM
    view.setUint16(20, 1, true);              // AudioFormat 1 = PCM
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, byteRate, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, 16, true);             // BitsPerSample

    // data Subchunk
    this.writeString(view, 36, 'data');
    view.setUint32(40, dataSize, true);

    // Write interleaved 16-bit PCM samples
    let offset = 44;
    for (let i = 0; i < sampleCount; i++) {
      // Left channel sample clamped to [-1.0, 1.0]
      let sL = Math.max(-1.0, Math.min(1.0, leftPcm[i] || 0));
      let intL = sL < 0 ? sL * 0x8000 : sL * 0x7FFF;
      view.setInt16(offset, intL, true);
      offset += 2;

      if (numChannels === 2 && rightPcm) {
        let sR = Math.max(-1.0, Math.min(1.0, rightPcm[i] || 0));
        let intR = sR < 0 ? sR * 0x8000 : sR * 0x7FFF;
        view.setInt16(offset, intR, true);
        offset += 2;
      }
    }

    return buffer;
  }

  private writeString(view: DataView, offset: number, str: string): void {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  }

  /**
   * Inspects binary magic header bytes to verify genuine container format
   */
  public inspectContainerSignature(buffer: ArrayBuffer | Uint8Array): {
    format: string;
    isValid: boolean;
    magicBytes: string;
  } {
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    if (bytes.length < 4) {
      return { format: 'UNKNOWN', isValid: false, magicBytes: '' };
    }

    // RIFF WAV check (52 49 46 46 = "RIFF", followed by 57 41 56 45 = "WAVE" at offset 8)
    if (bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46) {
      const isWave = bytes.length >= 12 && bytes[8] === 0x57 && bytes[9] === 0x41 && bytes[10] === 0x56 && bytes[11] === 0x45;
      return { format: isWave ? 'WAV' : 'RIFF_GENERIC', isValid: isWave, magicBytes: 'RIFF/WAVE' };
    }

    // PNG check (89 50 4E 47 0D 0A 1A 0A)
    if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47) {
      return { format: 'PNG', isValid: true, magicBytes: '89 50 4E 47' };
    }

    // JPEG check (FF D8 FF)
    if (bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF) {
      return { format: 'JPEG', isValid: true, magicBytes: 'FF D8 FF' };
    }

    // WebM / EBML check (1A 45 DF A3)
    if (bytes[0] === 0x1A && bytes[1] === 0x45 && bytes[2] === 0xDF && bytes[3] === 0xA3) {
      return { format: 'WEBM', isValid: true, magicBytes: '1A 45 DF A3 (EBML)' };
    }

    // MP4 check (....ftyp)
    if (bytes.length >= 8 && bytes[4] === 0x66 && bytes[5] === 0x74 && bytes[6] === 0x79 && bytes[7] === 0x70) {
      return { format: 'MP4', isValid: true, magicBytes: 'ftyp' };
    }

    return {
      format: 'CUSTOM_BINARY',
      isValid: true,
      magicBytes: Array.from(bytes.slice(0, 4)).map(b => b.toString(16).padStart(2, '0')).join(' ')
    };
  }
}
