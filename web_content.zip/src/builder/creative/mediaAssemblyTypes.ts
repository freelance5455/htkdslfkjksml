/**
 * GODEX P4.5 — Production Media Assembly, Render Pipeline & Export Types
 * 
 * Defines authoritative interfaces and state machines for assembling:
 * VIDEO + VFX + SFX + FOLEY + DIALOGUE + AMBIENCE + MUSIC
 * into timeline-aware final media assets with empirical verification.
 */

export type AssemblyTrackCategory = 
  | 'VIDEO'
  | 'VFX'
  | 'SFX'
  | 'FOLEY'
  | 'DIALOGUE'
  | 'AMBIENCE'
  | 'MUSIC'
  | 'OVERLAY';

export type AssemblyTruthClassification =
  | 'REAL_ENGINE'
  | 'LOCAL_DETERMINISTIC'
  | 'BROWSER_NATIVE'
  | 'SIMULATION'
  | 'REQUIRES_ENGINE'
  | 'UNAVAILABLE'
  | 'NOT_MEASURED';

export type AssemblyAssetEvidenceState = 
  | 'VERIFIED_SOURCE'
  | 'SYNTHESIZED_LOCAL_DSP'
  | 'SYNTHESIZED_CANVAS_PROCEDURAL'
  | 'IMPORTED_BINARY'
  | 'UNVERIFIED'
  | 'REQUIRES_REMOTE_ENGINE';

export interface AssemblyTransform {
  x: number;          // Pixel offset X
  y: number;          // Pixel offset Y
  scaleX: number;     // 1.0 = 100%
  scaleY: number;     // 1.0 = 100%
  rotationDeg: number;// 0-360 degrees
  anchorX?: number;   // 0.5 = center
  anchorY?: number;   // 0.5 = center
}

export interface AssemblyAsset {
  assetId: string;
  name: string;
  sourceRef: string;
  category: AssemblyTrackCategory;
  startTimeSec: number;
  durationSec: number;
  inPointSec?: number;
  outPointSec?: number;
  frameRate?: number;
  sampleRate?: number;
  gain: number;               // 0.0 to 2.0 (1.0 = unity)
  pan?: number;               // -1.0 (L) to +1.0 (R)
  transform: AssemblyTransform;
  opacity: number;            // 0.0 to 1.0
  blendMode?: 'normal' | 'multiply' | 'screen' | 'overlay' | 'add';
  enabled: boolean;
  trackId: string;
  vfxConfig?: {
    keyingColor?: string;
    keyingTolerance?: number;
    despillStrength?: number;
    maskPolygon?: { x: number; y: number }[];
    trackingPoints?: { frame: number; x: number; y: number }[];
    particleSystemId?: string;
    lutEffect?: string;
  };
  audioConfig?: {
    sfxCategory?: string;
    pitchHz?: number;
    reverbMix?: number;
    delayMix?: number;
    eqLowGainDb?: number;
    eqMidGainDb?: number;
    eqHighGainDb?: number;
    compressorThresholdDb?: number;
    rawPcmLeft?: Float32Array;
    rawPcmRight?: Float32Array;
  };
  evidenceState: AssemblyAssetEvidenceState;
  metadata?: Record<string, any>;
}

export interface AssemblyTrack {
  id: string;
  name: string;
  category: AssemblyTrackCategory;
  muted: boolean;
  solo: boolean;
  locked: boolean;
  gainDb: number;
  pan: number;
  order: number;
  assets: AssemblyAsset[];
}

export type TransitionType = 
  | 'CUT'
  | 'CROSSFADE'
  | 'WIPE_LEFT'
  | 'WIPE_RIGHT'
  | 'DIP_TO_BLACK'
  | 'DIP_TO_WHITE'
  | 'LUMA_DISSOLVE';

export interface AssemblyTransition {
  id: string;
  type: TransitionType;
  fromClipId: string;
  toClipId: string;
  startTimeSec: number;
  durationSec: number;
  curve?: 'LINEAR' | 'EASE_IN_OUT' | 'EXPONENTIAL';
}

export interface ColorGradeConfig {
  lut?: string;
  temperature?: number;    // -100 to +100
  tint?: number;           // -100 to +100
  exposure?: number;       // -2.0 to +2.0 EV
  contrast?: number;       // 0.5 to 2.0
  saturation?: number;     // 0.0 to 2.0
  vignette?: number;       // 0.0 to 1.0
  filmGrain?: number;      // 0.0 to 1.0
}

export interface AssemblyComposition {
  id: string;
  name: string;
  fps: 23.976 | 24 | 25 | 29.97 | 30 | 60;
  sampleRate: number;
  width: number;
  height: number;
  totalDurationSec: number;
  tracks: AssemblyTrack[];
  transitions: AssemblyTransition[];
  colorGrade?: ColorGradeConfig;
  masterGainDb: number;
  masterLimiterCeilingDb: number;
}

export interface ResolvedFrameAssetLayer {
  assetId: string;
  category: AssemblyTrackCategory;
  sourceRef: string;
  relativeTimeSec: number;
  clipFrameIndex: number;
  transform: AssemblyTransform;
  opacity: number;
  blendMode: string;
  vfxConfig?: Record<string, any>;
  transitionFactor?: number;
}

export interface ResolvedFramePlan {
  frameIndex: number;
  timestampSec: number;
  layers: ResolvedFrameAssetLayer[];
  activeTransition?: {
    type: TransitionType;
    progress: number;
    fromClipId: string;
    toClipId: string;
  };
  appliedColorGrade?: ColorGradeConfig;
}

export interface ResolvedAudioPassPlan {
  trackId: string;
  category: AssemblyTrackCategory;
  startSample: number;
  sampleCount: number;
  gain: number;
  pan: number;
  assetId: string;
  audioConfig?: Record<string, any>;
}

export interface RenderPlan {
  planId: string;
  compositionId: string;
  compositionName: string;
  totalFrames: number;
  totalAudioSamples: number;
  frameRate: number;
  sampleRate: number;
  dimensions: { width: number; height: number };
  totalDurationSec: number;
  resolvedFrames: ResolvedFramePlan[];
  resolvedAudioPasses: ResolvedAudioPassPlan[];
  estimatedMemoryMb: number;
  truthClassification: AssemblyTruthClassification;
  createdAt: number;
}

export type RenderLifecycleState =
  | 'QUEUED'
  | 'PREFLIGHT'
  | 'RESOURCE_CHECK'
  | 'ASSEMBLING'
  | 'VIDEO_RENDER'
  | 'VFX_COMPOSITE'
  | 'AUDIO_MIX'
  | 'AUDIO_VIDEO_MUX'
  | 'OUTPUT_VALIDATION'
  | 'QUALITY_GATE'
  | 'COMPLETED'
  | 'PREFLIGHT_FAILED'
  | 'RESOURCE_LIMIT'
  | 'ENGINE_REQUIRED'
  | 'MODEL_UNAVAILABLE'
  | 'RENDER_FAILED'
  | 'MUX_FAILED'
  | 'OUTPUT_INVALID'
  | 'QUALITY_GATE_FAILED'
  | 'CANCELLED';

export interface RenderProgressTelemetry {
  renderId: string;
  state: RenderLifecycleState;
  percent: number;               // 0 to 100
  currentFrame: number;
  totalFrames: number;
  processedAudioSamples: number;
  totalAudioSamples: number;
  elapsedMs: number;
  estimatedRemainingMs: number;
  currentPhaseDetail: string;
  memoryUsedMb: number;
  isIndeterminate: boolean;
  actualRenderedFrames?: number;
  currentFps?: number;
  batchIndex?: number;
  totalBatches?: number;
  memoryBudgetMb?: number;
  memoryPressureState?: 'SAFE' | 'WARNING_HIGH_MEMORY' | 'CRITICAL_EXCEEDS_BUDGET';
  encoderStatus?: string;
  vfxStatus?: string;
  audioStatus?: string;
  validationStatus?: string;
}

export type ExportFormat = 
  | 'WEBM'
  | 'MP4'
  | 'WAV'
  | 'PNG_SEQUENCE'
  | 'JPEG_SEQUENCE'
  | 'WEBP_SEQUENCE';

export type AdaptiveRenderProfile =
  | 'MOBILE_SAFE'
  | 'MOBILE_HIGH'
  | 'TABLET'
  | 'DESKTOP'
  | 'DESKTOP_HIGH'
  | '4K_CAPABLE';

export type AspectRatioPreset = '16:9' | '9:16' | '1:1' | '21:9' | '4:3';

export type CheckpointAction = 'RESUME_RENDER' | 'RESTART_FAILED_STAGE' | 'CANCEL_RENDER';

export interface ExportCapability {
  format: ExportFormat;
  supported: boolean;
  encoderName: string;
  mimeType: string;
  truthState: 'AVAILABLE_BROWSER_NATIVE' | 'AVAILABLE_LOCALLY' | 'REQUIRES_ENGINE' | 'UNAVAILABLE';
  reason?: string;
  preferredCodec?: string;
}

export interface FinalOutputValidationResult {
  valid: boolean;
  containerSignature: string;
  mimeType: string;
  byteSize: number;
  dimensions: { width: number; height: number };
  fps: number;
  durationSec: number;
  frameCount: number;
  hasAudioTrack: boolean;
  sampleRate: number;
  channels: number;
  avDriftMs: number;
  isCorrupt: boolean;
  isTruncated: boolean;
  blackFramePercentage: number;
  frozenFramePercentage: number;
  isClippingDetected: boolean;
  excessiveSilencePercentage: number;
  temporalDefectCount: number;
  details: string[];
}

export interface ScorecardItem {
  name: string;
  score: number; // 0 to 100
  status: 'PASS' | 'WARN' | 'FAIL' | 'NOT_MEASURED';
  rationale: string;
  measured: boolean;
}

export interface FinalQualityScorecard {
  overallScore: number;
  passedGate: boolean;
  verdict: 'ACCEPT' | 'REJECT' | 'NEEDS_REFINEMENT';
  categories: {
    videoIntegrity: ScorecardItem;
    frameContinuity?: ScorecardItem;
    temporalConsistency: ScorecardItem;
    subjectConsistency: ScorecardItem;
    motionQuality: ScorecardItem;
    vfxIntegrity: ScorecardItem;
    audioIntegrity: ScorecardItem;
    avSync: ScorecardItem;
    containerIntegrity: ScorecardItem;
    resolutionCompliance?: ScorecardItem;
    fpsCompliance?: ScorecardItem;
    durationCompliance?: ScorecardItem;
    outputCompleteness: ScorecardItem;
    encoderIntegrity?: ScorecardItem;
    memoryIntegrity?: ScorecardItem;
  };
  summary: string;
  qualityGateMessage: string;
}

export interface RenderCheckpoint {
  checkpointId: string;
  compositionId: string;
  renderId: string;
  timelineHash: string;
  currentStage: RenderLifecycleState;
  completedFrames: number;
  totalFrames: number;
  completedFrameRange: { start: number; end: number };
  completedAudioRanges: { startSample: number; endSample: number }[];
  completedVfxRanges: { startFrame: number; endFrame: number }[];
  engineIdentity: string;
  modelIdentity?: string;
  outputFormat: ExportFormat;
  resolution: { width: number; height: number };
  fps: number;
  sampleRate: number;
  timestamp: number;
  resourceState: 'SAFE' | 'WARNING' | 'CRITICAL';
  validationState: 'VALID' | 'INVALID' | 'UNVERIFIED';
  checkpointMetadata?: Record<string, any>;
}

export interface RenderResourceEstimate {
  estimatedRamMb: number;
  estimatedVramMb: number | 'UNKNOWN';
  frameBufferSizeMb: number;
  audioBufferSizeMb: number;
  intermediateAssetsMb: number;
  maxSafeConcurrency: number;
  is4KGuarded: boolean;
  isLongDurationGuarded: boolean;
  resourceSafetyState: 'SAFE' | 'WARNING_HIGH_MEMORY' | 'CRITICAL_EXCEEDS_BUDGET' | 'RESOURCE_LIMIT';
  recommendations: string[];
}

export interface FinalRenderEvidence {
  renderId: string;
  compositionId: string;
  compositionName: string;
  sourceAssets: AssemblyAsset[];
  renderPlan: RenderPlan;
  engineUsed: string;
  engineTruthClassification: AssemblyTruthClassification;
  requiresEngineReason?: string;
  actualOutputMetadata: {
    mimeType: string;
    containerSignature: string;
    sizeBytes: number;
    dimensions: { width: number; height: number };
    fps: number;
    durationSec: number;
    frameCount: number;
    hasAudio: boolean;
    audioSampleRate?: number;
    audioChannels?: number;
    uri?: string;
    dataUrl?: string;
    blobUrl?: string;
  };
  validationResults: FinalOutputValidationResult;
  qualityMetrics: FinalQualityScorecard;
  timingMetrics: {
    queuedAt: number;
    startedAt: number;
    completedAt: number;
    totalDurationMs: number;
    frameRenderLatencyMs: number;
    vfxCompositeLatencyMs: number;
    audioMixLatencyMs: number;
    muxLatencyMs: number;
  };
  resourceMetrics: {
    peakMemoryMb: number;
    cpuCoresUtilized: number;
    hardwareClassification: string;
  };
  errors: string[];
  warnings: string[];
  completionState: RenderLifecycleState;
}

export interface TimelineValidationReport {
  totalDurationSec: number;
  totalFrames: number;
  audioSampleCount: number;
  expectedVsActualDurationDeltaMs: number;
  maxAvDriftMs: number;
  frameAlignmentConfidence: number; // 0 to 100%
  fps: number;
  sampleRate: number;
  isValid: boolean;
  issues: string[];
  clipCount: number;
  layerCount: number;
}
