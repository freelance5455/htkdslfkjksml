/**
 * GODEX P4.6 — Production Render Resource Governor
 * 
 * Manages RAM/VRAM resource planning, frame buffer sizing, intermediate asset allocation,
 * 4K guards, mobile memory boundaries, concurrency limits, buffer disposal, and render locking.
 * 
 * Invariants:
 * - Never fabricates VRAM metrics when unavailable (returns 'UNKNOWN').
 * - Prevents duplicate concurrent renders for the same composition.
 * - Guards mobile runtime (< 256MB) and protects high-resolution / long-duration renders.
 */

import { AssemblyComposition, RenderResourceEstimate } from './mediaAssemblyTypes';
import { HardwareAuditor, HardwareAuditReport } from './hardwareAuditor';

export class RenderResourceGovernor {
  private static instance: RenderResourceGovernor | null = null;
  private activeRenderLocks: Map<string, string> = new Map(); // compositionId -> renderId

  public static getInstance(): RenderResourceGovernor {
    if (!RenderResourceGovernor.instance) {
      RenderResourceGovernor.instance = new RenderResourceGovernor();
    }
    return RenderResourceGovernor.instance;
  }

  /**
   * Evaluates memory and compute requirements for an assembly composition.
   */
  public async estimateResources(
    composition: AssemblyComposition,
    hwAudit?: HardwareAuditReport
  ): Promise<RenderResourceEstimate> {
    const report = hwAudit || await HardwareAuditor.getInstance().auditHardware();

    const bytesPerPixel = 4; // RGBA 8-bit
    const singleFrameBytes = composition.width * composition.height * bytesPerPixel;
    const singleFrameMb = singleFrameBytes / (1024 * 1024);

    // Dynamic buffered frame count (lower on mobile/high-res, higher on standard)
    const is4K = composition.width >= 3840 || composition.height >= 2160;
    const bufferedFrames = is4K ? 4 : 12;
    const frameBufferSizeMb = Math.round(singleFrameMb * bufferedFrames * 100) / 100;

    // Audio buffer calculation (Float32 stereo: 2 channels * 4 bytes per sample)
    const audioSampleCount = Math.round(composition.totalDurationSec * composition.sampleRate);
    const audioBytes = audioSampleCount * 2 * 4;
    const audioBufferSizeMb = Math.round((audioBytes / (1024 * 1024)) * 100) / 100;

    // Intermediate VFX layers
    const vfxLayers = composition.tracks
      .filter(t => t.category === 'VFX' || t.category === 'OVERLAY')
      .reduce((sum, t) => sum + t.assets.length, 0);
    const intermediateAssetsMb = Math.round(singleFrameMb * Math.max(1, vfxLayers) * 2 * 100) / 100;

    const baseEngineOverheadMb = 32;
    const totalEstimatedRamMb = Math.round((frameBufferSizeMb + audioBufferSizeMb + intermediateAssetsMb + baseEngineOverheadMb) * 10) / 10;

    const isLongDuration = composition.totalDurationSec >= 30.0;
    const cpuCores = report.cpuCores || 2;
    const maxSafeConcurrency = Math.min(4, Math.max(1, cpuCores - 1));

    // VRAM estimate (Only if WebGPU detected with concrete limits; otherwise 'UNKNOWN')
    let estimatedVramMb: number | 'UNKNOWN' = 'UNKNOWN';
    if (report.webGpuClassification === 'WEBGPU_AVAILABLE' && report.computeLimits?.maxBufferSizeMb) {
      estimatedVramMb = Math.min(report.computeLimits.maxBufferSizeMb, Math.round(singleFrameMb * 8));
    }

    const recommendations: string[] = [];
    let safetyState: RenderResourceEstimate['resourceSafetyState'] = 'SAFE';

    // Mobile Memory Guard (< 256MB safe ceiling)
    if (totalEstimatedRamMb > 512) {
      safetyState = 'CRITICAL_EXCEEDS_BUDGET';
      recommendations.push('Memory estimate exceeds 512MB. Enable slice-based chunking.');
    } else if (totalEstimatedRamMb > 180 || is4K) {
      safetyState = 'WARNING_HIGH_MEMORY';
      recommendations.push('High memory workload detected. Limiting frame buffer pipeline.');
    }

    if (is4K) {
      recommendations.push('4K Ultra HD composition: Enforcing chunked rendering (12 frames/batch).');
    }

    if (isLongDuration) {
      recommendations.push(`Long-duration timeline (${composition.totalDurationSec.toFixed(1)}s): Incremental audio mix active.`);
    }

    return {
      estimatedRamMb: totalEstimatedRamMb,
      estimatedVramMb,
      frameBufferSizeMb,
      audioBufferSizeMb,
      intermediateAssetsMb,
      maxSafeConcurrency,
      is4KGuarded: is4K,
      isLongDurationGuarded: isLongDuration,
      resourceSafetyState: safetyState,
      recommendations
    };
  }

  /**
   * Acquires a mutex lock for the composition to prevent duplicate concurrent renders.
   */
  public acquireRenderLock(compositionId: string, renderId: string): boolean {
    if (this.activeRenderLocks.has(compositionId)) {
      const activeLock = this.activeRenderLocks.get(compositionId);
      if (activeLock === renderId) {
        return true;
      }
      return false;
    }
    this.activeRenderLocks.set(compositionId, renderId);
    return true;
  }

  /**
   * Releases the mutex lock for a composition.
   */
  public releaseRenderLock(compositionId: string, renderId?: string): void {
    if (renderId) {
      if (this.activeRenderLocks.get(compositionId) === renderId) {
        this.activeRenderLocks.delete(compositionId);
      }
    } else {
      this.activeRenderLocks.delete(compositionId);
    }
  }

  /**
   * Checks if a composition is currently locked.
   */
  public isLocked(compositionId: string): boolean {
    return this.activeRenderLocks.has(compositionId);
  }

  /**
   * Computes the optimal frame chunk batch size for responsive yielding.
   */
  public getOptimalChunkSize(composition: AssemblyComposition): number {
    const is4K = composition.width >= 3840 || composition.height >= 2160;
    if (is4K) return 6;
    if (composition.width >= 1920 || composition.height >= 1080) return 12;
    return 24;
  }

  /**
   * Disposes and dereferences large temporary typed arrays and buffers.
   */
  public cleanupBuffers(...buffers: (Float32Array | Uint8Array | ArrayBuffer | null | undefined)[]): void {
    for (let i = 0; i < buffers.length; i++) {
      buffers[i] = null;
    }
  }
}
