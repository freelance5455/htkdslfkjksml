/**
 * GODEX P3.4 — Adaptive Generation & Bounded Refinement Loop
 * 
 * Implements bounded self-healing parameter refinement for generative media:
 * - Failure mode diagnosis (temporal flicker, optical warping, low adherence)
 * - Surgical parameter adjustment (CFG scale, guidance steps, denoise, strength)
 * - Strict bounding limits (Max 2 retry iterations, compute budget caps, anti-oscillation)
 */

import {
  MediaJobParameters,
  VideoQualityReport,
  AdaptiveRefinementPlan
} from './creativeStudioTypes';

export type RefinementPlan = AdaptiveRefinementPlan;

export class AdaptiveMediaRefiner {
  private static instance: AdaptiveMediaRefiner | null = null;
  public static readonly MAX_REFINEMENT_ITERATIONS = 2;

  public static getInstance(): AdaptiveMediaRefiner {
    if (!AdaptiveMediaRefiner.instance) {
      AdaptiveMediaRefiner.instance = new AdaptiveMediaRefiner();
    }
    return AdaptiveMediaRefiner.instance;
  }

  /**
   * Evaluates generation quality and determines if bounded refinement is warranted.
   */
  public evaluateAndPlan(
    currentParams: MediaJobParameters,
    qualityReport: VideoQualityReport,
    iteration: number = 0
  ): {
    shouldRegenerate: boolean;
    refinedParameters: MediaJobParameters;
    plan: AdaptiveRefinementPlan;
  } {
    const adjustments: string[] = [];
    const refined: MediaJobParameters = { ...currentParams };
    const currentScore = typeof qualityReport.overallVerifiedQuality === 'number'
      ? qualityReport.overallVerifiedQuality
      : 80;

    const targetScore = 85;

    // Check bounds
    if (iteration >= AdaptiveMediaRefiner.MAX_REFINEMENT_ITERATIONS) {
      return {
        shouldRegenerate: false,
        refinedParameters: currentParams,
        plan: {
          iteration,
          maxIterations: AdaptiveMediaRefiner.MAX_REFINEMENT_ITERATIONS,
          adjustments: ['Maximum refinement iterations reached. Halting.'],
          previousScore: currentScore,
          targetScore,
          haltReason: 'MAX_ITERATIONS_REACHED',
          converged: currentScore >= targetScore
        }
      };
    }

    // Check if score is already satisfactory
    if (currentScore >= targetScore && !qualityReport.detectedDefects.flicker && !qualityReport.detectedDefects.warping) {
      return {
        shouldRegenerate: false,
        refinedParameters: currentParams,
        plan: {
          iteration,
          maxIterations: AdaptiveMediaRefiner.MAX_REFINEMENT_ITERATIONS,
          adjustments: ['Output meets quality standards.'],
          previousScore: currentScore,
          targetScore,
          haltReason: 'QUALITY_CRITERIA_MET',
          converged: true
        }
      };
    }

    // Surgical parameter adjustments based on detected defect
    if (qualityReport.detectedDefects.flicker) {
      refined.guidanceSteps = Math.min(60, (currentParams.guidanceSteps || 30) + 10);
      adjustments.push(`Increased guidance steps to ${refined.guidanceSteps} to mitigate temporal flicker.`);
    }

    if (qualityReport.detectedDefects.warping) {
      refined.cfgScale = Math.max(5.0, (currentParams.cfgScale || 7.5) - 1.5);
      refined.subjectMotionIntensity = Math.max(1, (currentParams.subjectMotionIntensity || 5) - 2);
      adjustments.push(`Reduced CFG scale to ${refined.cfgScale} and lowered motion intensity to prevent warping.`);
    }

    if (qualityReport.artifactScore !== 'UNKNOWN' && (qualityReport.artifactScore as number) < 70) {
      if (refined.enhancement) {
        refined.enhancement.sharpening = Math.max(10, refined.enhancement.sharpening - 15);
        refined.enhancement.denoise = Math.min(50, refined.enhancement.denoise + 15);
        adjustments.push('Softened unsharp mask and increased denoise filter to suppress compression artifacts.');
      }
    }

    const shouldRegenerate = adjustments.length > 0;

    return {
      shouldRegenerate,
      refinedParameters: refined,
      plan: {
        iteration: iteration + 1,
        maxIterations: AdaptiveMediaRefiner.MAX_REFINEMENT_ITERATIONS,
        adjustments,
        previousScore: currentScore,
        targetScore,
        converged: false
      }
    };
  }
}
