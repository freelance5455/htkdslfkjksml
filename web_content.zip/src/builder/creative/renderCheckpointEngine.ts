/**
 * GODEX P4.6 — Production Render Checkpoint & Resume Engine
 * 
 * Manages incremental render checkpoints, deterministic timeline hashing,
 * compatibility validation, stale checkpoint rejection, and safe resume states.
 * 
 * Invariants:
 * - Deterministically validates timeline hash before allowing a resume.
 * - Never silently resumes using changed or stale project data.
 * - Preserves verified sub-frame checkpoints across lifecycle stages.
 */

import {
  AssemblyComposition,
  RenderCheckpoint,
  ExportFormat,
  RenderLifecycleState,
  CheckpointAction
} from './mediaAssemblyTypes';

export class RenderCheckpointEngine {
  private static instance: RenderCheckpointEngine | null = null;
  private checkpoints: Map<string, RenderCheckpoint> = new Map(); // compositionId -> RenderCheckpoint
  private readonly STORAGE_KEY_PREFIX = 'godex_render_checkpoint_';
  private visibilityListenerInstalled = false;
  private backgroundedTime: number | null = null;

  public static getInstance(): RenderCheckpointEngine {
    if (!RenderCheckpointEngine.instance) {
      RenderCheckpointEngine.instance = new RenderCheckpointEngine();
      RenderCheckpointEngine.instance.initVisibilityMonitor();
    }
    return RenderCheckpointEngine.instance;
  }

  private initVisibilityMonitor(): void {
    if (this.visibilityListenerInstalled || typeof document === 'undefined') return;
    this.visibilityListenerInstalled = true;

    try {
      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          this.backgroundedTime = Date.now();
        } else {
          if (this.backgroundedTime) {
            const suspendedMs = Date.now() - this.backgroundedTime;
            this.backgroundedTime = null;
            if (suspendedMs > 5000) {
              console.warn(`Tab returned from background suspension (${suspendedMs}ms). Checkpoints preserved for safe resume.`);
            }
          }
        }
      });
    } catch {
      // Non-browser or test runner environment
    }
  }

  /**
   * Calculates a deterministic cryptographic-grade timeline hash for a composition.
   */
  public calculateTimelineHash(composition: AssemblyComposition): string {
    const parts: string[] = [
      composition.id,
      composition.name,
      `${composition.width}x${composition.height}`,
      `${composition.fps}fps`,
      `${composition.sampleRate}hz`,
      `dur:${composition.totalDurationSec.toFixed(3)}`,
      `gain:${composition.masterGainDb}`,
      `limiter:${composition.masterLimiterCeilingDb}`
    ];

    if (composition.colorGrade) {
      parts.push(`cg:${JSON.stringify(composition.colorGrade)}`);
    }

    // Hash tracks and assets
    for (const track of composition.tracks) {
      parts.push(`tr:${track.id}:${track.category}:m=${track.muted}:g=${track.gainDb}:p=${track.pan}`);
      for (const asset of track.assets) {
        parts.push(`as:${asset.assetId}:${asset.startTimeSec.toFixed(3)}:${asset.durationSec.toFixed(3)}:g=${asset.gain}:p=${asset.pan || 0}:en=${asset.enabled}`);
        if (asset.vfxConfig) {
          parts.push(`vfx:${JSON.stringify(asset.vfxConfig)}`);
        }
        if (asset.audioConfig) {
          parts.push(`aud:${JSON.stringify(asset.audioConfig)}`);
        }
      }
    }

    // Hash transitions
    for (const tr of composition.transitions) {
      parts.push(`trans:${tr.id}:${tr.type}:${tr.fromClipId}->${tr.toClipId}:${tr.startTimeSec.toFixed(3)}:${tr.durationSec.toFixed(3)}`);
    }

    const payload = parts.join('|');
    
    // Deterministic 32-bit FNV-1a hash with hex representation
    let hash = 0x811c9dc5;
    for (let i = 0; i < payload.length; i++) {
      hash ^= payload.charCodeAt(i);
      hash = Math.imul(hash, 0x01000193);
    }
    
    const hex = (hash >>> 0).toString(16).padStart(8, '0');
    return `tlhash-${hex}-${payload.length}`;
  }

  /**
   * Creates a new checkpoint record for an active render stage.
   */
  public createCheckpoint(
    composition: AssemblyComposition,
    renderId: string,
    stage: RenderLifecycleState,
    completedFrames: number,
    totalFrames: number,
    outputFormat: ExportFormat,
    options?: {
      completedAudioRanges?: { startSample: number; endSample: number }[];
      completedVfxRanges?: { startFrame: number; endFrame: number }[];
      engineIdentity?: string;
      modelIdentity?: string;
      resourceState?: 'SAFE' | 'WARNING' | 'CRITICAL';
      validationState?: 'VALID' | 'INVALID' | 'UNVERIFIED';
      metadata?: Record<string, any>;
    }
  ): RenderCheckpoint {
    const timelineHash = this.calculateTimelineHash(composition);
    const checkpointId = `chk-${composition.id}-${renderId}-${stage}-${Date.now()}`;

    const checkpoint: RenderCheckpoint = {
      checkpointId,
      compositionId: composition.id,
      renderId,
      timelineHash,
      currentStage: stage,
      completedFrames,
      totalFrames,
      completedFrameRange: { start: 0, end: completedFrames },
      completedAudioRanges: options?.completedAudioRanges || [{ startSample: 0, endSample: Math.round(composition.totalDurationSec * composition.sampleRate) }],
      completedVfxRanges: options?.completedVfxRanges || [{ startFrame: 0, endFrame: completedFrames }],
      engineIdentity: options?.engineIdentity || 'engine-godex-media-assembly',
      modelIdentity: options?.modelIdentity,
      outputFormat,
      resolution: { width: composition.width, height: composition.height },
      fps: composition.fps,
      sampleRate: composition.sampleRate,
      timestamp: Date.now(),
      resourceState: options?.resourceState || 'SAFE',
      validationState: options?.validationState || 'VALID',
      checkpointMetadata: options?.metadata
    };

    this.saveCheckpoint(checkpoint);
    return checkpoint;
  }

  /**
   * Saves a checkpoint to memory and local persistence.
   */
  public saveCheckpoint(checkpoint: RenderCheckpoint): void {
    this.checkpoints.set(checkpoint.compositionId, checkpoint);

    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem(
          `${this.STORAGE_KEY_PREFIX}${checkpoint.compositionId}`,
          JSON.stringify(checkpoint)
        );
      } catch (err) {
        // Safe failover if quota exceeded
        console.warn('Could not persist render checkpoint to localStorage:', err);
      }
    }
  }

  /**
   * Retrieves the active or cached checkpoint for a composition.
   */
  public getCheckpoint(compositionId: string): RenderCheckpoint | null {
    if (this.checkpoints.has(compositionId)) {
      return this.checkpoints.get(compositionId)!;
    }

    if (typeof localStorage !== 'undefined') {
      try {
        const item = localStorage.getItem(`${this.STORAGE_KEY_PREFIX}${compositionId}`);
        if (item) {
          const parsed = JSON.parse(item) as RenderCheckpoint;
          this.checkpoints.set(compositionId, parsed);
          return parsed;
        }
      } catch (err) {
        console.warn('Failed to read checkpoint from storage:', err);
      }
    }

    return null;
  }

  /**
   * Validates if an existing checkpoint is strictly compatible with the current composition.
   */
  public validateCheckpointCompatibility(
    checkpoint: RenderCheckpoint,
    currentComposition: AssemblyComposition,
    targetFormat: ExportFormat
  ): { compatible: boolean; reason?: string } {
    if (checkpoint.compositionId !== currentComposition.id) {
      return {
        compatible: false,
        reason: `Checkpoint composition ID (${checkpoint.compositionId}) does not match current project (${currentComposition.id}).`
      };
    }

    const currentHash = this.calculateTimelineHash(currentComposition);
    if (checkpoint.timelineHash !== currentHash) {
      return {
        compatible: false,
        reason: 'Stale checkpoint rejected: Composition timeline, tracks, or clips have been modified since checkpoint was recorded.'
      };
    }

    if (checkpoint.resolution.width !== currentComposition.width || checkpoint.resolution.height !== currentComposition.height) {
      return {
        compatible: false,
        reason: `Resolution mismatch: Checkpoint is ${checkpoint.resolution.width}x${checkpoint.resolution.height}, but current is ${currentComposition.width}x${currentComposition.height}.`
      };
    }

    if (checkpoint.fps !== currentComposition.fps) {
      return {
        compatible: false,
        reason: `Framerate mismatch: Checkpoint FPS (${checkpoint.fps}) does not match current FPS (${currentComposition.fps}).`
      };
    }

    if (checkpoint.outputFormat !== targetFormat) {
      return {
        compatible: false,
        reason: `Format mismatch: Checkpoint target format (${checkpoint.outputFormat}) does not match requested format (${targetFormat}).`
      };
    }

    return { compatible: true };
  }

  /**
   * Clears a checkpoint for a composition.
   */
  public clearCheckpoint(compositionId: string): void {
    this.checkpoints.delete(compositionId);
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.removeItem(`${this.STORAGE_KEY_PREFIX}${compositionId}`);
      } catch (e) {
        // Ignore
      }
    }
  }

  /**
   * Lists all cached checkpoints.
   */
  public getAllCheckpoints(): RenderCheckpoint[] {
    return Array.from(this.checkpoints.values());
  }

  /**
   * Executes a user or system recovery action on an active/staged checkpoint.
   */
  public executeRecoveryAction(
    action: CheckpointAction,
    composition: AssemblyComposition,
    targetFormat: ExportFormat
  ): {
    success: boolean;
    checkpoint: RenderCheckpoint | null;
    message: string;
    restartStage?: RenderLifecycleState;
  } {
    const existing = this.getCheckpoint(composition.id);
    if (!existing) {
      return {
        success: false,
        checkpoint: null,
        message: 'No recorded checkpoint found for this composition.'
      };
    }

    if (action === 'CANCEL_RENDER') {
      this.clearCheckpoint(composition.id);
      return {
        success: true,
        checkpoint: null,
        message: 'Active render checkpoint cancelled and cache cleared.'
      };
    }

    const compat = this.validateCheckpointCompatibility(existing, composition, targetFormat);
    if (!compat.compatible) {
      return {
        success: false,
        checkpoint: existing,
        message: `Recovery action rejected: ${compat.reason}`
      };
    }

    if (action === 'RESUME_RENDER') {
      return {
        success: true,
        checkpoint: existing,
        message: `Safe to resume from stage ${existing.currentStage} (frame ${existing.completedFrames}/${existing.totalFrames}).`
      };
    }

    if (action === 'RESTART_FAILED_STAGE') {
      // Revert checkpoint to prior safe stage
      let restartStage: RenderLifecycleState = 'PREFLIGHT';
      if (existing.currentStage === 'AUDIO_VIDEO_MUX' || existing.currentStage === 'OUTPUT_VALIDATION') {
        restartStage = 'AUDIO_MIX';
      } else if (existing.currentStage === 'VFX_COMPOSITE') {
        restartStage = 'VIDEO_RENDER';
      }

      existing.currentStage = restartStage;
      this.saveCheckpoint(existing);

      return {
        success: true,
        checkpoint: existing,
        restartStage,
        message: `Reset checkpoint stage to ${restartStage} for clean retry.`
      };
    }

    return {
      success: false,
      checkpoint: null,
      message: `Unknown checkpoint action: ${action}`
    };
  }
}
