/**
 * GODEX P4.5 — Frame-Accurate Render Timeline Engine
 * 
 * Provides deterministic frame ↔ timestamp ↔ audio sample mapping,
 * sub-frame timing resolution, transition curve evaluation,
 * and comprehensive timeline drift validation across standard frame rates:
 * 23.976, 24, 25, 29.97, 30, 60 FPS.
 */

import {
  AssemblyComposition,
  AssemblyTrack,
  AssemblyAsset,
  AssemblyTransition,
  ResolvedFramePlan,
  ResolvedFrameAssetLayer,
  TimelineValidationReport,
  TransitionType
} from './mediaAssemblyTypes';

export class RenderTimelineEngine {
  private static instance: RenderTimelineEngine | null = null;

  public static getInstance(): RenderTimelineEngine {
    if (!RenderTimelineEngine.instance) {
      RenderTimelineEngine.instance = new RenderTimelineEngine();
    }
    return RenderTimelineEngine.instance;
  }

  /**
   * Convert frame index to precise seconds timestamp.
   * Uses high-precision rational arithmetic to eliminate cumulative floating-point drift.
   */
  public frameToTimestamp(frameIndex: number, fps: number): number {
    if (frameIndex <= 0 || fps <= 0) return 0;
    // Handle NTSC drop-frame approximations deterministically
    if (Math.abs(fps - 23.976) < 0.01) {
      return (frameIndex * 1001) / 24000;
    }
    if (Math.abs(fps - 29.97) < 0.01) {
      return (frameIndex * 1001) / 30000;
    }
    return frameIndex / fps;
  }

  /**
   * Convert timestamp in seconds to exact frame index with deterministic rounding.
   */
  public timestampToFrame(timestampSec: number, fps: number): number {
    if (timestampSec <= 0 || fps <= 0) return 0;
    if (Math.abs(fps - 23.976) < 0.01) {
      return Math.floor((timestampSec * 24000) / 1001 + 1e-6);
    }
    if (Math.abs(fps - 29.97) < 0.01) {
      return Math.floor((timestampSec * 30000) / 1001 + 1e-6);
    }
    return Math.floor(timestampSec * fps + 1e-6);
  }

  /**
   * Convert timestamp to exact audio sample index.
   */
  public timestampToSample(timestampSec: number, sampleRate: number = 44100): number {
    if (timestampSec <= 0 || sampleRate <= 0) return 0;
    return Math.floor(timestampSec * sampleRate);
  }

  /**
   * Convert audio sample index to timestamp in seconds.
   */
  public sampleToTimestamp(sampleIndex: number, sampleRate: number = 44100): number {
    if (sampleIndex <= 0 || sampleRate <= 0) return 0;
    return sampleIndex / sampleRate;
  }

  /**
   * Calculate total frame count for a composition.
   */
  public calculateTotalFrames(durationSec: number, fps: number): number {
    if (durationSec <= 0 || fps <= 0) return 0;
    return Math.round(durationSec * fps);
  }

  /**
   * Evaluates transition progression factor (0.0 to 1.0) for a given timestamp.
   */
  public evaluateTransitionProgress(
    transition: AssemblyTransition,
    currentTimestampSec: number
  ): number | null {
    const start = transition.startTimeSec;
    const end = start + transition.durationSec;
    if (currentTimestampSec < start || currentTimestampSec > end) {
      return null;
    }
    if (transition.durationSec <= 0) return 1.0;
    const rawProgress = Math.max(0, Math.min(1.0, (currentTimestampSec - start) / transition.durationSec));

    switch (transition.curve) {
      case 'EASE_IN_OUT':
        // Smooth Hermite / S-Curve
        return rawProgress * rawProgress * (3 - 2 * rawProgress);
      case 'EXPONENTIAL':
        return Math.pow(rawProgress, 2);
      case 'LINEAR':
      default:
        return rawProgress;
    }
  }

  /**
   * Resolves active asset layers for a specific frame in the timeline.
   */
  public resolveFrameLayers(
    composition: AssemblyComposition,
    frameIndex: number
  ): ResolvedFramePlan {
    const timestampSec = this.frameToTimestamp(frameIndex, composition.fps);
    const layers: ResolvedFrameAssetLayer[] = [];
    let activeTransition: ResolvedFramePlan['activeTransition'] = undefined;

    // Check transitions
    for (const trans of composition.transitions) {
      const progress = this.evaluateTransitionProgress(trans, timestampSec);
      if (progress !== null) {
        activeTransition = {
          type: trans.type,
          progress,
          fromClipId: trans.fromClipId,
          toClipId: trans.toClipId
        };
        break;
      }
    }

    // Sort tracks by order (lower order = background, higher order = foreground)
    const sortedTracks = [...composition.tracks].sort((a, b) => a.order - b.order);

    for (const track of sortedTracks) {
      if (track.muted) continue;

      for (const asset of track.assets) {
        if (!asset.enabled) continue;

        const assetStart = asset.startTimeSec;
        const assetEnd = assetStart + asset.durationSec;

        if (timestampSec >= assetStart && timestampSec < assetEnd) {
          const relativeTimeSec = timestampSec - assetStart;
          const inPointOffset = asset.inPointSec || 0;
          const sourceEffectiveTime = relativeTimeSec + inPointOffset;
          const clipFrameRate = asset.frameRate || composition.fps;
          const clipFrameIndex = Math.floor(sourceEffectiveTime * clipFrameRate);

          let transitionFactor = 1.0;
          if (activeTransition) {
            if (activeTransition.fromClipId === asset.assetId) {
              transitionFactor = 1.0 - activeTransition.progress;
            } else if (activeTransition.toClipId === asset.assetId) {
              transitionFactor = activeTransition.progress;
            }
          }

          layers.push({
            assetId: asset.assetId,
            category: asset.category,
            sourceRef: asset.sourceRef,
            relativeTimeSec,
            clipFrameIndex,
            transform: asset.transform,
            opacity: asset.opacity * (track.category === 'VIDEO' ? transitionFactor : 1.0),
            blendMode: asset.blendMode || 'normal',
            vfxConfig: asset.vfxConfig,
            transitionFactor
          });
        }
      }
    }

    return {
      frameIndex,
      timestampSec,
      layers,
      activeTransition,
      appliedColorGrade: composition.colorGrade
    };
  }

  /**
   * Generates a timeline validation report checking for drift, frame overlap, and duration consistency.
   */
  public validateTimeline(composition: AssemblyComposition): TimelineValidationReport {
    const issues: string[] = [];
    const totalFrames = this.calculateTotalFrames(composition.totalDurationSec, composition.fps);
    const audioSampleCount = this.timestampToSample(composition.totalDurationSec, composition.sampleRate);
    
    let maxAssetEndSec = 0;
    let clipCount = 0;
    let layerCount = 0;

    for (const track of composition.tracks) {
      for (const asset of track.assets) {
        clipCount++;
        layerCount++;
        const assetEnd = asset.startTimeSec + asset.durationSec;
        if (assetEnd > maxAssetEndSec) {
          maxAssetEndSec = assetEnd;
        }

        if (asset.durationSec <= 0) {
          issues.push(`Asset '${asset.name}' (${asset.assetId}) has zero or negative duration.`);
        }
        if (asset.startTimeSec < 0) {
          issues.push(`Asset '${asset.name}' (${asset.assetId}) has negative start time.`);
        }
      }
    }

    const durationDeltaMs = Math.abs(composition.totalDurationSec - maxAssetEndSec) * 1000;
    if (durationDeltaMs > 100 && maxAssetEndSec > composition.totalDurationSec) {
      issues.push(`Timeline assets extend beyond composition boundary by ${durationDeltaMs.toFixed(1)}ms.`);
    }

    // Audio-Video sub-sample / sub-frame drift calculation
    const calculatedDurationFromFrames = this.frameToTimestamp(totalFrames, composition.fps);
    const calculatedDurationFromSamples = this.sampleToTimestamp(audioSampleCount, composition.sampleRate);
    const avDriftMs = Math.abs(calculatedDurationFromFrames - calculatedDurationFromSamples) * 1000;

    const frameAlignmentConfidence = Math.max(0, Math.min(100, 100 - avDriftMs * 2));
    const isValid = issues.length === 0;

    return {
      totalDurationSec: composition.totalDurationSec,
      totalFrames,
      audioSampleCount,
      expectedVsActualDurationDeltaMs: durationDeltaMs,
      maxAvDriftMs: avDriftMs,
      frameAlignmentConfidence,
      fps: composition.fps,
      sampleRate: composition.sampleRate,
      isValid,
      issues,
      clipCount,
      layerCount
    };
  }
}
