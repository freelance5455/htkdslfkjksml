/**
 * GODEX P3.2 — Creative Studio & Real Media Generation Core Types
 * Authoritative models for unified media pipelines:
 * Text-to-Image, Image-to-Video, Text-to-Video, Video-to-Video, Media Enhancement.
 */

export type MediaWorkflowType = 
  | 'TEXT_TO_IMAGE' 
  | 'IMAGE_TO_VIDEO' 
  | 'TEXT_TO_VIDEO' 
  | 'VIDEO_TO_VIDEO' 
  | 'MEDIA_ENHANCE';

export type CreativeStudioTab = 
  | 'production'
  | 'generate' 
  | 'enhance' 
  | 'camera'
  | 'color'
  | 'vfx'
  | 'audio'
  | 'sfx'
  | 'assembly'
  | 'export'
  | 'editor' 
  | 'history' 
  | 'benchmark';

export type MediaJobStatus = 
  | 'PENDING'
  | 'QUEUED' 
  | 'VALIDATING' 
  | 'ENGINE_DISCOVERY'
  | 'ENGINE_SELECTED'
  | 'INITIALIZING'
  | 'READY' 
  | 'RUNNING' 
  | 'FINALIZING'
  | 'VALIDATING_OUTPUT'
  | 'QUALITY_ANALYSIS'
  | 'REFINING'
  | 'CANCELLING' 
  | 'COMPLETED' 
  | 'FAILED' 
  | 'CANCELLED' 
  | 'BLOCKED'
  | 'REQUIRES_ENGINE'
  | 'RESOURCE_LIMIT'
  | 'TIMEOUT'
  | 'INVALID_OUTPUT';

export type OutputVerificationStatus =
  | 'VERIFIED'
  | 'UNKNOWN'
  | 'FAILED';

export type CreativeExecutionErrorCode =
  | 'INVALID_PARAMETERS'
  | 'REQUIRES_ENGINE'
  | 'RESOURCE_EXHAUSTED'
  | 'RESOURCE_LIMIT'
  | 'TIMEOUT'
  | 'CORRUPT_OUTPUT'
  | 'INVALID_OUTPUT'
  | 'CANCELLED'
  | 'BLOCKED'
  | 'EXECUTION_ERROR';

export type EngineAvailabilityState = 
  | 'AVAILABLE'
  | 'AVAILABLE_LOCALLY' 
  | 'AVAILABLE_BROWSER_NATIVE' 
  | 'AVAILABLE_CONNECTED_ENGINE' 
  | 'REQUIRES_ENGINE' 
  | 'UNAVAILABLE' 
  | 'FAILED' 
  | 'UNKNOWN';

export type ExecutionTruthClassification =
  | 'REAL_NEURAL'
  | 'REAL_ENGINE'
  | 'LOCAL_DETERMINISTIC'
  | 'SIMULATION'
  | 'UNAVAILABLE'
  | 'REQUIRES_ENGINE'
  | 'FAILED';

export interface RealNeuralGenerationContract {
  contractId: string;
  workflowType: MediaWorkflowType;
  engineId: string;
  engineName: string;
  modelId: string;
  inputAssets: MediaAssetInput[];
  prompt?: string;
  negativePrompt?: string;
  resolution: ResolutionPreset;
  aspectRatio: AspectRatioType;
  dimensions: { width: number; height: number };
  fps?: number;
  durationSec?: number;
  seed?: number;
  generationParameters: Record<string, any>;
  executionId: string;
  startTimestamp: number;
  endTimestamp?: number;
  actualEngineState: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'REQUIRES_ENGINE' | 'UNAVAILABLE';
  outputReferences: MediaAssetOutput[];
  validationEvidence?: OutputValidationResult;
  failureReason?: string;
  truthClassification: ExecutionTruthClassification;
}

export type VideoStylePreset = 
  | 'CINEMATIC' 
  | 'FILM'
  | 'COMMERCIAL'
  | 'MUSIC_VIDEO'
  | 'DOCUMENTARY'
  | 'ANIME'
  | 'REALISTIC'
  | 'CYBERPUNK' 
  | 'PORTRAIT'
  | 'PRODUCT'
  | 'ARCHITECTURAL'
  | 'ACTION'
  | 'HORROR'
  | 'SCI_FI'
  | 'PHOTOREAL' 
  | 'OCTANE_3D' 
  | 'NOIR' 
  | 'STUDIO_PORTRAIT' 
  | 'ANALOG_FILM';

export type CameraMovementType = 
  | 'STATIC' 
  | 'PAN_LEFT' 
  | 'PAN_RIGHT' 
  | 'PAN'
  | 'TILT_UP' 
  | 'TILT_DOWN' 
  | 'TILT'
  | 'DOLLY_IN' 
  | 'DOLLY_OUT' 
  | 'DOLLY'
  | 'TRUCK_LEFT'
  | 'TRUCK_RIGHT'
  | 'TRUCK'
  | 'ORBIT'
  | 'ORBIT_360' 
  | 'CRANE'
  | 'CRANE_UP' 
  | 'CRANE_DOWN'
  | 'ZOOM'
  | 'ZOOM_PULL' 
  | 'ZOOM_IN'
  | 'ZOOM_OUT'
  | 'TRACKING'
  | 'TRACKING_SHOT'
  | 'HANDHELD'
  | 'HANDHELD_DYNAMIC'
  | 'DEPTH_AWARE_MOVEMENT';

export type AspectRatioType = '16:9' | '9:16' | '1:1' | '4:3' | '21:9';

export type ResolutionPreset = '720p' | '1080p' | '4K' | 'CUSTOM';

export interface MediaAssetInput {
  id: string;
  name: string;
  uri: string;
  type: 'IMAGE' | 'VIDEO' | 'AUDIO';
  mimeType: string;
  sizeBytes: number;
  dimensions?: { width: number; height: number };
  durationSec?: number;
  fps?: number;
  dataUrl?: string;
}

export interface MediaAssetOutput {
  id: string;
  name: string;
  uri: string;
  mimeType: string;
  type: 'IMAGE' | 'VIDEO' | 'AUDIO';
  dimensions: { width: number; height: number };
  durationSec?: number;
  fps?: number;
  sizeBytes: number;
  generatedAt: number;
  dataUrl?: string;
  thumbnailUrl?: string;
}

export interface MediaEnhancementParameters {
  resolutionScale: number; // 1.0, 1.5, 2.0, 4.0
  sharpening: number; // 0 to 100
  denoise: number; // 0 to 100
  exposure: number; // -100 to +100
  contrast: number; // -100 to +100
  saturation: number; // -100 to +100
  temperature: number; // -100 to +100 (warm/cool)
  highlights: number; // -100 to +100
  shadows: number; // -100 to +100
  gamma: number; // 0.2 to 3.0 (default 1.0)
  crop?: { x: number; y: number; width: number; height: number };
  aspectRatioConvert?: AspectRatioType;
  interpolationMethod: 'NEAREST_NEIGHBOR' | 'BILINEAR' | 'BICUBIC' | 'NEURAL_INTERPOLATION';
}

export interface MediaJobParameters {
  prompt?: string;
  negativePrompt?: string;
  aspectRatio: AspectRatioType;
  resolution: ResolutionPreset;
  customDimensions?: { width: number; height: number };
  durationSec?: number;
  fps?: 24 | 30 | 60;
  seed?: number;
  strength?: number; // 0.0 to 1.0 for image/video transformations
  style?: VideoStylePreset;
  cameraMovement?: CameraMovementType;
  subjectMotionIntensity?: number; // 1 to 10
  cfgScale?: number; // 1.0 to 20.0
  guidanceSteps?: number; // 10 to 100
  preservationControls?: {
    preserveIdentity: boolean;
    preserveAudio: boolean;
    preserveLighting: boolean;
    preserveFramerate: boolean;
  };
  enhancement?: MediaEnhancementParameters;
  customEngineEndpoint?: string;
  customEngineApiKey?: string;
}

export interface CreativeEngineCapability {
  capabilityId: string;
  name: string;
  supportedWorkflows: MediaWorkflowType[];
  status: EngineAvailabilityState;
  supportedResolutions: ResolutionPreset[];
  supportedFps: Array<24 | 30 | 60>;
  supportedAspectRatios: AspectRatioType[];
  maxDurationSec: number;
  requiresGpu: boolean;
  isFreeLocal: boolean;
  description: string;
}

export interface ResourceEstimate {
  estimatedVramGb: number;
  estimatedComputeTimeMs: number;
  estimatedMemoryMb: number;
  gpuAccelerationRecommended: boolean;
  freeTierCompatible: boolean;
}

export interface RequestValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  sanitizedPrompt: string;
  recommendedEngineId?: string;
}

export interface OutputValidationResult {
  valid: boolean;
  verificationStatus?: OutputVerificationStatus;
  dimensionsMatch: boolean;
  fpsMatch: boolean;
  temporalConsistencyScore: number; // 0 to 100
  promptAdherenceScore: number; // 0 to 100
  identityPreservationScore: number; // 0 to 100
  motionQualityScore: number; // 0 to 100
  visualQualityScore: number; // 0 to 100
  artifactRatePercent: number; // 0% to 100%
  flickerScore: number; // 0 to 100 (lower is better)
  compositionStabilityScore: number; // 0 to 100
  mediaFormatDetails?: {
    container: string;
    codec?: string;
    byteSize: number;
    dimensions: { width: number; height: number };
    durationSec?: number;
    fps?: number;
    frameCount?: number;
    hasAudio?: boolean;
    decodeSuccess: boolean;
  };
  details: string[];
}

export interface MediaJobProgress {
  stage: string;
  percent: number | null; // null if unmeasurable (Free-first/Truthful)
  message: string;
  currentFrame?: number;
  totalFrames?: number;
}

export interface MediaJob {
  jobId: string;
  type: MediaWorkflowType;
  inputAssets: MediaAssetInput[];
  parameters: MediaJobParameters;
  engine: {
    id: string;
    name: string;
    status: EngineAvailabilityState;
    isLocal: boolean;
  };
  status: MediaJobStatus;
  progress: number | null;
  progressStage?: string;
  startedAt: number;
  completedAt?: number;
  cancelledAt?: number;
  error?: string;
  errorCode?: CreativeExecutionErrorCode;
  outputAssets: MediaAssetOutput[];
  validation?: OutputValidationResult;
  executionEvidence: {
    durationMs: number;
    engineUsed: string;
    deterministic: boolean;
    truthStatus: string;
    classification?: ExecutionTruthClassification;
    logs: string[];
  };
}

export interface CreativeBenchmarkMetrics {
  promptAdherence: number;
  temporalConsistency: number;
  identityPreservation: number;
  motionQuality: number;
  visualQuality: number;
  artifactRate: number;
  flickerScore: number;
  compositionStability: number;
  outputResolution: string;
  generationLatencyMs: number;
  sampleCount: number;
}

export interface SceneUnderstanding {
  rawPrompt: string;
  normalizedPrompt: string;
  subject: string;
  environment: string;
  action: string;
  cameraMovement: CameraMovementType;
  lighting: string;
  style: VideoStylePreset;
  temporalPlan: {
    durationSec: number;
    fps: 24 | 30 | 60;
    keyframeIntervalSec: number;
    motionTrajectory: string;
    shotCount: number;
  };
}

export interface TemporalConsistencyReport {
  subjectDriftScore: number; // 0 to 100
  identityDriftScore: number; // 0 to 100
  geometryInstabilityScore: number; // 0 to 100 (lower is better)
  textureFlickerScore: number; // 0 to 100 (lower is better)
  lightingFlickerScore: number; // 0 to 100 (lower is better)
  backgroundInstabilityScore: number; // 0 to 100 (lower is better)
  cameraMotionDiscontinuityScore: number; // 0 to 100 (lower is better)
  objectDisappearanceCount: number;
  opticalFlowConsistencyScore: number; // 0 to 100
  overallTemporalScore: number; // 0 to 100
  techniquesUsed: string[];
  limitationsHonestNotice?: string;
}

export interface SubjectConsistencyProfile {
  subjectId: string;
  dominantColors: string[];
  clothingDescription?: string;
  bodyProportions?: string;
  keyAccessories: string[];
  faceEmbeddingDetected: boolean;
  identityPreservationConfidence: number; // 0 to 100
  guaranteed: boolean;
  honestyNote: string;
}

export interface MotionQualityReport {
  naturalAcceleration: boolean;
  naturalDeceleration: boolean;
  cameraTrajectoryContinuity: number; // 0 to 100
  objectVelocityContinuity: number; // 0 to 100
  limbDeformationDetected: boolean;
  unnaturalWarpingScore: number; // 0 to 100 (lower is better)
  frameDuplicationCount: number;
  suddenJumpCount: number;
  motionScore: number; // 0 to 100
  flaggedSequences: Array<{ startSec: number; endSec: number; issue: string }>;
}

export interface VideoQualityReport {
  resolution: string;
  fps: number | 'UNKNOWN';
  durationSec: number | 'UNKNOWN';
  codec: string | 'UNKNOWN';
  audio: string | 'UNKNOWN';
  temporalConsistency: number | 'UNKNOWN';
  subjectConsistency: number | 'UNKNOWN';
  motionQuality: number | 'UNKNOWN';
  artifactScore: number | 'UNKNOWN';
  overallVerifiedQuality: number | 'UNKNOWN';
  detectedDefects: {
    blur: boolean;
    compressionArtifacts: boolean;
    ringing: boolean;
    aliasing: boolean;
    flicker: boolean;
    ghosting: boolean;
    warping: boolean;
    blackFrames: boolean;
    frozenFrames: boolean;
    corruptFrames: boolean;
  };
  details: string[];
}

export interface ShotPlan {
  sceneId: string;
  shots: Array<{
    shotId: string;
    shotNumber: number;
    durationSec: number;
    cameraMovement: CameraMovementType;
    subjectFocus: string;
    lighting: string;
    keyframes: Array<{ timestampSec: number; promptGuide: string; referenceFrameIndex?: number }>;
    continuityRules: {
      character: string;
      wardrobe: string;
      environment: string;
      lighting: string;
      colorPalette: string[];
    };
  }>;
  totalDurationSec: number;
  temporalAssemblyStrategy: 'DIRECT_CUT' | 'CROSS_DISSOLVE' | 'MOTION_MATCH';
}

export interface AdaptiveRefinementPlan {
  iteration: number;
  maxIterations: number;
  adjustments: string[];
  previousScore: number;
  targetScore: number;
  haltReason?: string;
  converged: boolean;
}

export interface BenchmarkComparisonResult {
  metric: string;
  systemValue: number | 'NOT_MEASURED';
  referenceValue?: number | 'NOT_MEASURED';
  unit: string;
  status: 'EMPIRICAL_MEASURED' | 'NOT_MEASURED' | 'ESTIMATED';
  confidence: number;
}

export type HardwareGpuClassification = 
  | 'GPU_AVAILABLE' 
  | 'GPU_SOFTWARE_FALLBACK'
  | 'GPU_UNAVAILABLE' 
  | 'UNKNOWN';

export type WebGpuClassification = 
  | 'WEBGPU_AVAILABLE' 
  | 'WEBGPU_UNSUPPORTED'
  | 'WEBGPU_FLAG_DISABLED'
  | 'WEBGPU_UNAVAILABLE' 
  | 'UNKNOWN';

export type HardwareAccelerationClassification = 
  | 'HARDWARE_ACCELERATION_AVAILABLE' 
  | 'HARDWARE_ACCELERATION_UNAVAILABLE' 
  | 'UNKNOWN';

export interface HardwareAuditReport {
  gpuClassification: HardwareGpuClassification;
  webGpuClassification: WebGpuClassification;
  hardwareAcceleration: HardwareAccelerationClassification;
  gpuVendor: string;
  gpuModel: string;
  gpuName?: string;
  totalVramGb?: number;
  freeVramGb?: number;
  isSupportedGpu?: boolean;
  hasWebGpu?: boolean;
  hardwareTier?: 'DISCRETE_HIGH_VRAM' | 'DISCRETE_MID_VRAM' | 'DISCRETE_LOW_VRAM' | 'INTEGRATED_WEBGPU' | 'CPU_ONLY';
  vramPressureLevel?: 'LOW' | 'MEDIUM' | 'HIGH_PRESSURE' | 'CRITICAL_OOM_RISK';
  vramEstimateMb: number | 'UNKNOWN';
  estimatedVramGb: number;
  webGlVersion: 'WebGL 2.0' | 'WebGL 1.0' | 'UNAVAILABLE';
  webGpuAvailable?: boolean;
  webGlAvailable?: boolean;
  webAssembly: {
    available?: boolean;
    supported: boolean;
    simd: boolean;
    threads: boolean;
    bigInt: boolean;
  };
  cpuCores: number;
  systemMemoryGb: number | 'UNKNOWN';
  estimatedSystemRamGb?: number;
  quantizationSupport?: {
    fp32: boolean;
    fp16: boolean;
    int8: boolean;
    int4: boolean;
  };
  computeLimits: {
    maxTextureSize: number;
    maxComputeWorkgroupSize?: number;
    maxBufferSizeMb?: number;
    maxRenderBufferSize?: number;
  };
  supportedTextureFormats: string[];
  detectionEvidence: string[];
  detectedHostDevice?: string;
  isMobileDevice?: boolean;
  isVivoDevice?: boolean;
  memoryArchitecture?: 'UNIFIED_MEMORY_UMA' | 'DISCRETE_VRAM' | 'UNKNOWN';
  isDefinitivePhysicalVerification?: boolean;
  verificationMethod?: 'BROWSER_WEBGL_HEURISTIC' | 'PHYSICAL_NATIVE_DEVICE' | 'HEADLESS_CONTAINER';
  timestamp: number;
}

export interface NeuralRuntimeInfo {
  type: 'WEBGPU_NEURAL' | 'WASM_NEURAL' | 'LOCAL_INFERENCE_SERVER' | 'LOCAL_DIFFUSION' | 'LOCAL_VIDEO_GEN' | 'CONFIGURED_EXTERNAL';
  name: string;
  endpoint?: string;
  status: 'ACTIVE_AVAILABLE' | 'REQUIRES_ENGINE' | 'UNAVAILABLE';
  device: 'GPU' | 'CPU' | 'NPU' | 'UNAVAILABLE';
  supportedWorkflows: MediaWorkflowType[];
  detectedModels: string[];
  latencyMs?: number;
  evidence: string;
}

export interface NeuralRuntimeDiscoveryReport {
  runtimes: NeuralRuntimeInfo[];
  activeNeuralEngineAvailable: boolean;
  primaryNeuralBackend: 'GPU' | 'CPU' | 'NONE';
  classification: ExecutionTruthClassification;
  discoveryEvidence: string[];
  missingComponentNotice?: string;
}

export interface NeuralModelMetadata {
  modelId: string;
  name: string;
  format: 'ONNX' | 'GGUF' | 'SAFETENSORS' | 'TENSORRT' | 'DIFFUSERS' | 'WASM_TENSOR';
  sizeBytes: number;
  loadTimeMs: number;
  memoryConsumptionMb: number;
  deviceBackend: 'WEBGPU' | 'CUDA' | 'DIRECTML' | 'CPU_WASM' | 'NONE';
  supportedWorkflows: MediaWorkflowType[];
  supportedResolutions: ResolutionPreset[];
  supportedFps: number[];
  contextLimits: {
    maxSequenceLength?: number;
    maxBatchSize?: number;
    maxDimension?: number;
  };
  loaded: boolean;
  loadError?: string;
}

export interface NeuralGenerationEvidence {
  hardwareDetected?: any;
  runtimeUsed?: string;
  modelExecuted?: string;
  engine?: string;
  model?: string;
  backend?: string;
  device?: string;
  executionStart?: number;
  executionEnd?: number;
  runtimeDurationMs?: number;
  measuredInferenceLatencyMs?: number;
  executionProof?: string;
  outputSizeBytes?: number;
  resolution?: string;
  fps?: number;
  durationSec?: number;
  codecContainer?: string;
  validationResult?: OutputValidationResult;
  truthClassification: ExecutionTruthClassification;
  inferenceProven?: boolean;
  deviceConfirmed?: boolean;
  memoryUsedMb?: number;
  generationLogs?: string[];
}

export type MetricCertainty = 'MEASURED' | 'ESTIMATED' | 'NOT_MEASURED';

export interface QualityFactorMeasurement {
  score: number; // 0 to 100
  certainty: MetricCertainty;
  rationale: string;
}

export interface CreativeQualityReportP42 {
  temporalConsistency: QualityFactorMeasurement;
  subjectConsistency: QualityFactorMeasurement;
  motionSmoothness: QualityFactorMeasurement;
  sharpness: QualityFactorMeasurement;
  artifactRate: QualityFactorMeasurement;
  flicker: QualityFactorMeasurement;
  structuralStability: QualityFactorMeasurement;
  exposureStability: QualityFactorMeasurement;
  colorStability: QualityFactorMeasurement;
  frameIntegrity: QualityFactorMeasurement;
  containerIntegrity: QualityFactorMeasurement;
  overallScore: QualityFactorMeasurement;
  passedQualityGate: boolean;
  qualityGateMessage: string;
  refinementRecommended: boolean;
  refinementCycle: number;
}

export interface StructuredGenerationPlan {
  originalPrompt: string;
  subject: string;
  environment: string;
  action: string;
  lighting: string;
  camera: string;
  lens: string;
  composition: string;
  motion: string;
  temporalBehavior: string;
  style: string;
  color: string;
  atmosphere: string;
  negativeConstraints: string;
  suggestedPreset?: VideoStylePreset;
}

export type SpeedCurveType = 'LINEAR' | 'EASE_IN_OUT' | 'EXPONENTIAL' | 'SMOOTH_RAMP';

export interface CameraTrajectoryPlan {
  movement: CameraMovementType;
  motionIntensity: number; // 1 to 10
  speedCurve: SpeedCurveType;
  startFraming: string;
  endFraming: string;
  supportedByEngine: boolean;
  engineParameters?: Record<string, any>;
}

export type ModelTruthState = 
  | 'AVAILABLE' 
  | 'SELECTED' 
  | 'INCOMPATIBLE' 
  | 'MISSING_DEPENDENCY' 
  | 'INSUFFICIENT_MEMORY' 
  | 'REQUIRES_ENGINE' 
  | 'UNAVAILABLE';

export type ComfyUiConnectionState = 
  | 'CONNECTED' 
  | 'UNREACHABLE' 
  | 'TIMEOUT' 
  | 'INVALID_RESPONSE';

