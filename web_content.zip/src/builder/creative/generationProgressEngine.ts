/**
 * GODEX P4.0 — Generation Progress & Event Engine
 * 
 * Manages verifiable progress state transitions and telemetry events for neural media generation.
 * Enforces Zero-Fake-Progress rule: Never fabricates artificial percentage jumps.
 * 
 * Lifecycle States:
 * QUEUED → PREFLIGHT → SUBMITTED → RUNNING → RETRIEVING → VALIDATING → QUALITY_ANALYSIS → REFINEMENT → COMPLETED
 * 
 * Terminal / Guard States:
 * FAILED, CANCELLED, TIMEOUT, REQUIRES_ENGINE, MODEL_UNAVAILABLE, RESOURCE_LIMITED
 */

import {
  MediaJobStatus,
  MediaJobProgress,
  ExecutionTruthClassification
} from './creativeStudioTypes';

export type GenerationProgressStage =
  | 'QUEUED'
  | 'PREFLIGHT'
  | 'SUBMITTED'
  | 'RUNNING'
  | 'RETRIEVING'
  | 'VALIDATING'
  | 'QUALITY_ANALYSIS'
  | 'REFINEMENT'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED'
  | 'TIMEOUT'
  | 'REQUIRES_ENGINE'
  | 'MODEL_UNAVAILABLE'
  | 'RESOURCE_LIMITED';

export interface ProgressEventPayload {
  jobId: string;
  stage: GenerationProgressStage;
  percent: number | null;
  message: string;
  timestamp: number;
  currentStep?: number;
  totalSteps?: number;
  currentFrame?: number;
  totalFrames?: number;
  activeNodeId?: string;
  activeNodeTitle?: string;
  executionTruth: ExecutionTruthClassification;
  logs: string[];
}

export type ProgressEventListener = (event: ProgressEventPayload) => void;

export class GenerationProgressEngine {
  private static instance: GenerationProgressEngine | null = null;
  private listeners: Set<ProgressEventListener> = new Set();
  private jobEvents = new Map<string, ProgressEventPayload[]>();

  public static getInstance(): GenerationProgressEngine {
    if (!GenerationProgressEngine.instance) {
      GenerationProgressEngine.instance = new GenerationProgressEngine();
    }
    return GenerationProgressEngine.instance;
  }

  public subscribe(listener: ProgressEventListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /**
   * Emits a truthful progress state transition.
   */
  public emitProgress(
    jobId: string,
    stage: GenerationProgressStage,
    message: string,
    percent: number | null = null,
    meta?: Partial<ProgressEventPayload>
  ): ProgressEventPayload {
    const existingEvents = this.jobEvents.get(jobId) || [];
    const event: ProgressEventPayload = {
      jobId,
      stage,
      percent,
      message,
      timestamp: Date.now(),
      executionTruth: meta?.executionTruth || 'REAL_ENGINE',
      currentStep: meta?.currentStep,
      totalSteps: meta?.totalSteps,
      currentFrame: meta?.currentFrame,
      totalFrames: meta?.totalFrames,
      activeNodeId: meta?.activeNodeId,
      activeNodeTitle: meta?.activeNodeTitle,
      logs: [
        ...(meta?.logs || []),
        `[${new Date().toISOString()}] [${stage}] ${message}${percent !== null ? ` (${percent}%)` : ''}`
      ]
    };

    existingEvents.push(event);
    this.jobEvents.set(jobId, existingEvents);

    for (const listener of this.listeners) {
      try {
        listener(event);
      } catch (err) {
        console.error('Error in progress event listener:', err);
      }
    }

    return event;
  }

  public getEventsForJob(jobId: string): ProgressEventPayload[] {
    return [...(this.jobEvents.get(jobId) || [])];
  }

  public clearJobEvents(jobId: string): void {
    this.jobEvents.delete(jobId);
  }

  /**
   * Converts ComfyUI progress event into structured stage
   */
  public mapComfyUiStep(
    jobId: string,
    step: number,
    totalSteps: number,
    nodeTitle?: string
  ): ProgressEventPayload {
    const percent = Math.round((step / Math.max(1, totalSteps)) * 100);
    const message = `Executing latent diffusion step ${step}/${totalSteps}${nodeTitle ? ` [${nodeTitle}]` : ''}`;

    return this.emitProgress(jobId, 'RUNNING', message, percent, {
      currentStep: step,
      totalSteps,
      activeNodeTitle: nodeTitle,
      executionTruth: 'REAL_NEURAL'
    });
  }
}
