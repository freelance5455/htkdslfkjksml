/**
 * GODEX P5.12 — Local Engine Authority & Hardware-Aware Video Pipeline
 * 
 * Establishes LOCAL-FIRST engine authority across the GODEX production ecosystem:
 * Production Controller -> Local GPU/Engine -> Local Model Discovery -> Generation -> Validation -> CV / Forensic Evaluation -> Director Loop.
 * 
 * Epistemic Law & Hardware Capability Lock:
 * 1. LOCAL_NEURAL_VIDEO_STATUS = BLOCKED when:
 *    - Dedicated VRAM = 0 MB (Intel UHD Graphics UMA)
 *    - Compatible neural runtime is unavailable
 *    - Model weights are absent
 *    - Memory pre-flight fails
 * 2. SEPARATE NEURAL GENERATION FROM DETERMINISTIC RENDERING:
 *    - Browser-Native Canvas/WebCodecs/DSP is classified strictly as DETERMINISTIC_MEDIA_RENDERER.
 *    - It is NEVER classified or labeled as an AI Video Generator, Neural Diffusion Engine, or Local AI Model.
 *    - Generation metadata must report `generationType: 'DETERMINISTIC_RENDER'`, not `'NEURAL_AI'`.
 * 3. Kaggle is strictly an OPTIONAL / MANUAL / FALLBACK worker and is NEVER automatically invoked.
 */

import { LocalHardwareProfiler, LocalHardwareProfile } from './localHardwareProfile';

export type LocalNeuralVideoStatus = 'BLOCKED' | 'READY' | 'READY_WITH_LIMITS' | 'NOT_PROBED';
export type LocalMediaRenderingStatus = 'AVAILABLE' | 'UNAVAILABLE';

export type LocalEngineState =
  | 'ENGINE_DISCOVERY'
  | 'LOCAL_GPU_NEURAL_BLOCKED'
  | 'LOCAL_RENDERER_AVAILABLE'
  | 'LOCAL_GPU_RUNTIME_MISSING'
  | 'LOCAL_GPU_MODEL_NOT_INSTALLED'
  | 'LOCAL_GPU_INSUFFICIENT_MEMORY'
  | 'LOCAL_GPU_HARDWARE_INSUFFICIENT'
  | 'LOCAL_GPU_READY'
  | 'LOCAL_GPU_GENERATING'
  | 'LOCAL_GPU_ENGINE_UNAVAILABLE'
  | 'ENGINE_READY'
  | 'MODEL_READY'
  | 'MODEL_NOT_INSTALLED'
  | 'INSUFFICIENT_VRAM'
  | 'HARDWARE_INSUFFICIENT'
  | 'RUNTIME_MISSING'
  | 'ENGINE_START_FAILED'
  | 'GENERATION_RUNNING'
  | 'GENERATION_COMPLETED'
  | 'GENERATION_FAILED'
  | 'OUTPUT_INVALID'
  | 'LOCAL_ENGINE_UNAVAILABLE'
  | 'REQUIRES_ENGINE';

export type CandidateModelStatus =
  | 'SUPPORTED'
  | 'SUPPORTED_WITH_LIMITS'
  | 'MODEL_NOT_INSTALLED'
  | 'INSUFFICIENT_VRAM'
  | 'RUNTIME_MISSING'
  | 'DRIVER_INCOMPATIBLE'
  | 'HARDWARE_BLOCKED'
  | 'UNKNOWN';

export type EngineTechnologyCategory =
  | 'DETERMINISTIC_MEDIA_RENDERER'
  | 'NEURAL_DIFFUSION_MODEL'
  | 'NEURAL_TRANSFORMER_MODEL'
  | 'HARDWARE_MEDIA_TRANSCODER';

export interface CandidateVideoModel {
  modelId: string;
  name: string;
  technologyCategory: EngineTechnologyCategory;
  runtime: 'ComfyUI' | 'PyTorch' | 'WebGPU' | 'WebCodecs/Canvas' | 'ONNX Runtime Web' | 'DirectML';
  minVramGb: number;
  expectedVramGb: number;
  imageToVideo: boolean;
  textToVideo: boolean;
  expectedResolution: string;
  expectedFrameCount: number;
  expectedDurationSec: number;
  status: CandidateModelStatus;
  isAiNeural: boolean;
  notes: string;
}

export interface LocalEngineDiscoveryReport {
  engineId: string;
  engineName: string;
  state: LocalEngineState;
  localNeuralVideoStatus: LocalNeuralVideoStatus;
  localMediaRenderingStatus: LocalMediaRenderingStatus;
  hardwareProfile: LocalHardwareProfile;
  reachable: boolean;
  endpoint?: string;
  discoveredModels: string[];
  candidateModels: CandidateVideoModel[];
  activeModel?: string;
  failureReason?: string;
  recommendation: string;
}

export class LocalEngineAuthority {
  private static instance: LocalEngineAuthority | null = null;
  private profiler: LocalHardwareProfiler;
  private currentState: LocalEngineState = 'LOCAL_GPU_RUNTIME_MISSING';
  private neuralStatus: LocalNeuralVideoStatus = 'BLOCKED';
  private renderingStatus: LocalMediaRenderingStatus = 'AVAILABLE';
  private lastReport: LocalEngineDiscoveryReport | null = null;

  private constructor() {
    this.profiler = LocalHardwareProfiler.getInstance();
  }

  public static getInstance(): LocalEngineAuthority {
    if (!LocalEngineAuthority.instance) {
      LocalEngineAuthority.instance = new LocalEngineAuthority();
    }
    return LocalEngineAuthority.instance;
  }

  /**
   * Evaluates the full matrix of candidate video generation models against
   * the real laptop hardware profile (Intel Core i3-1215U / Intel UHD Graphics / 8 GB RAM / 0 MB Dedicated VRAM).
   */
  public evaluateCandidateModels(
    profile: LocalHardwareProfile,
    comfyOnline: boolean,
    installedComfyModels: string[]
  ): CandidateVideoModel[] {
    const isIntegrated = profile.gpu.type === 'INTEGRATED' || profile.gpu.dedicatedVramMb === 0;
    const hasCuda = profile.gpu.cudaSupported;

    return [
      {
        modelId: 'browser-native-canvas-dsp',
        name: 'Browser-Native Deterministic Media Renderer (Canvas2D / WebGL / DSP)',
        technologyCategory: 'DETERMINISTIC_MEDIA_RENDERER',
        runtime: 'WebCodecs/Canvas',
        minVramGb: 0,
        expectedVramGb: 0,
        imageToVideo: true,
        textToVideo: true,
        expectedResolution: '1280x720 (720p) / 1920x1080 (1080p)',
        expectedFrameCount: 96,
        expectedDurationSec: 4.0,
        status: 'SUPPORTED',
        isAiNeural: false,
        notes: 'DETERMINISTIC_MEDIA_RENDERER: Runs natively in-browser on Intel UHD + CPU via WebGL/Canvas2D and WebAudio. Zero VRAM requirement. Non-neural procedural graphics & compositing.'
      },
      {
        modelId: 'intel-quicksync-transcoder',
        name: 'Intel Quick Sync Hardware Media Transcoder',
        technologyCategory: 'HARDWARE_MEDIA_TRANSCODER',
        runtime: 'WebCodecs/Canvas',
        minVramGb: 0,
        expectedVramGb: 0,
        imageToVideo: false,
        textToVideo: false,
        expectedResolution: '1920x1080 (1080p)',
        expectedFrameCount: 240,
        expectedDurationSec: 10.0,
        status: profile.gpu.quickSyncVideoSupported ? 'SUPPORTED' : 'RUNTIME_MISSING',
        isAiNeural: false,
        notes: 'Hardware-accelerated AVC/H.264 encode/decode using Intel 12th Gen Media Engine. Non-neural.'
      },
      {
        modelId: 'svd-xt-1.1',
        name: 'Stable Video Diffusion (SVD-XT 1.1)',
        technologyCategory: 'NEURAL_DIFFUSION_MODEL',
        runtime: 'ComfyUI',
        minVramGb: 8,
        expectedVramGb: 12,
        imageToVideo: true,
        textToVideo: false,
        expectedResolution: '1024x576',
        expectedFrameCount: 25,
        expectedDurationSec: 4.0,
        status: !comfyOnline
          ? 'RUNTIME_MISSING'
          : isIntegrated
          ? 'INSUFFICIENT_VRAM'
          : installedComfyModels.some(m => m.toLowerCase().includes('svd'))
          ? 'SUPPORTED_WITH_LIMITS'
          : 'MODEL_NOT_INSTALLED',
        isAiNeural: true,
        notes: 'Neural diffusion model. Requires 8-12 GB dedicated VRAM. Intel UHD has 0 MB dedicated VRAM (UMA shared).'
      },
      {
        modelId: 'animatediff-v3',
        name: 'AnimateDiff Motion Module v3 (SD 1.5 backbone)',
        technologyCategory: 'NEURAL_DIFFUSION_MODEL',
        runtime: 'ComfyUI',
        minVramGb: 6,
        expectedVramGb: 8,
        imageToVideo: true,
        textToVideo: true,
        expectedResolution: '512x512 / 768x512',
        expectedFrameCount: 16,
        expectedDurationSec: 2.0,
        status: !comfyOnline
          ? 'RUNTIME_MISSING'
          : isIntegrated
          ? 'INSUFFICIENT_VRAM'
          : installedComfyModels.some(m => m.toLowerCase().includes('animatediff'))
          ? 'SUPPORTED_WITH_LIMITS'
          : 'MODEL_NOT_INSTALLED',
        isAiNeural: true,
        notes: 'Neural diffusion model. Requires 6-8 GB dedicated VRAM. High latency / out-of-memory risk on 8 GB system RAM.'
      },
      {
        modelId: 'ltx-video-distilled',
        name: 'Lightricks LTX-Video Distilled (DiT)',
        technologyCategory: 'NEURAL_TRANSFORMER_MODEL',
        runtime: 'ComfyUI',
        minVramGb: 12,
        expectedVramGb: 16,
        imageToVideo: true,
        textToVideo: true,
        expectedResolution: '768x512 / 1280x720',
        expectedFrameCount: 97,
        expectedDurationSec: 4.0,
        status: !comfyOnline
          ? 'RUNTIME_MISSING'
          : isIntegrated
          ? 'INSUFFICIENT_VRAM'
          : installedComfyModels.some(m => m.toLowerCase().includes('ltx'))
          ? 'SUPPORTED_WITH_LIMITS'
          : 'MODEL_NOT_INSTALLED',
        isAiNeural: true,
        notes: 'Neural Diffusion Transformer. Requires high dedicated VRAM (>12GB).'
      },
      {
        modelId: 'wan-2.1-t2v-1.3b',
        name: 'Wan2.1-T2V-1.3B (Compact Video DiT)',
        technologyCategory: 'NEURAL_TRANSFORMER_MODEL',
        runtime: 'ComfyUI',
        minVramGb: 8,
        expectedVramGb: 10,
        imageToVideo: false,
        textToVideo: true,
        expectedResolution: '832x480',
        expectedFrameCount: 81,
        expectedDurationSec: 5.0,
        status: !comfyOnline
          ? 'RUNTIME_MISSING'
          : isIntegrated
          ? 'INSUFFICIENT_VRAM'
          : installedComfyModels.some(m => m.toLowerCase().includes('wan'))
          ? 'SUPPORTED_WITH_LIMITS'
          : 'MODEL_NOT_INSTALLED',
        isAiNeural: true,
        notes: 'Compact Neural Video DiT. Requires 8-10 GB dedicated VRAM.'
      },
      {
        modelId: 'damo-vilab-t2v-1.7b',
        name: 'ModelScope / DAMO-VILAB Text-to-Video 1.7B',
        technologyCategory: 'NEURAL_DIFFUSION_MODEL',
        runtime: 'PyTorch',
        minVramGb: 8,
        expectedVramGb: 12,
        imageToVideo: false,
        textToVideo: true,
        expectedResolution: '256x256 / 512x512',
        expectedFrameCount: 16,
        expectedDurationSec: 2.0,
        status: !hasCuda ? 'DRIVER_INCOMPATIBLE' : 'INSUFFICIENT_VRAM',
        isAiNeural: true,
        notes: 'PyTorch CUDA kernel required. CUDA is unsupported on Intel integrated graphics.'
      }
    ];
  }

  /**
   * Discovers local engine capabilities with zero synthetic fabrication.
   * Strictly separates LOCAL_NEURAL_VIDEO_BLOCKED from LOCAL_MEDIA_RENDERING_AVAILABLE.
   */
  public async discoverLocalEngine(): Promise<LocalEngineDiscoveryReport> {
    this.currentState = 'ENGINE_DISCOVERY';
    const profile = await this.profiler.getProfile();

    let comfyOnline = false;
    let discoveredModels: string[] = [];
    let endpoint = 'http://127.0.0.1:8188';

    // Probe ComfyUI port 8188
    if (typeof fetch !== 'undefined') {
      try {
        const timeoutSignal = AbortSignal.timeout(600);
        const res = await fetch(`${endpoint}/system_stats`, { signal: timeoutSignal });
        if (res.ok) {
          comfyOnline = true;
          try {
            const modelRes = await fetch(`${endpoint}/object_info`, { signal: AbortSignal.timeout(800) });
            if (modelRes.ok) {
              const data = await modelRes.json();
              if (data && typeof data === 'object') {
                const ksampler = data.KSampler?.input?.required?.model?.[0];
                if (Array.isArray(ksampler)) {
                  discoveredModels = ksampler;
                }
              }
            }
          } catch {
            // object_info optional probe
          }
        }
      } catch {
        comfyOnline = false;
      }
    }

    const candidateModels = this.evaluateCandidateModels(profile, comfyOnline, discoveredModels);

    // Determine state
    let state: LocalEngineState;
    let neuralStatus: LocalNeuralVideoStatus = 'BLOCKED';
    let renderingStatus: LocalMediaRenderingStatus = 'AVAILABLE';
    let failureReason: string | undefined;
    let recommendation: string;

    if (comfyOnline) {
      if (discoveredModels.length > 0) {
        state = 'LOCAL_GPU_READY';
        neuralStatus = 'READY';
        recommendation = `Local ComfyUI is online at ${endpoint} with ${discoveredModels.length} models installed.`;
      } else {
        state = 'LOCAL_GPU_MODEL_NOT_INSTALLED';
        neuralStatus = 'BLOCKED';
        failureReason = 'Model Weights Missing: ComfyUI is reachable on 127.0.0.1:8188, but no video diffusion model checkpoints (.safetensors) were found in models/checkpoints folder.';
        recommendation = 'Download LTX-Video, SVD, or Wan2.1 checkpoints into your ComfyUI/models/checkpoints folder.';
      }
    } else {
      // ComfyUI runtime is offline.
      // Report accurate runtime offline state rather than falsely blaming shared UMA memory.
      state = 'LOCAL_GPU_RUNTIME_MISSING';
      neuralStatus = 'BLOCKED';
      failureReason = 'Local Neural Runtime Offline: No diffusion inference server responding on http://127.0.0.1:8188. (Local video diffusion requires ComfyUI or an initialized WebGPU/ONNX neural worker with model weights).';
      recommendation = 'Deterministic Media Rendering is AVAILABLE (60 FPS WebCodecs/Canvas). To enable local neural AI video, launch ComfyUI on http://127.0.0.1:8188 with LTX-Video, SVD, or Wan2.1 checkpoints.';
    }

    this.currentState = state;
    this.neuralStatus = neuralStatus;
    this.renderingStatus = renderingStatus;

    const report: LocalEngineDiscoveryReport = {
      engineId: comfyOnline ? 'engine-comfyui-local' : 'engine-browser-native',
      engineName: comfyOnline ? 'Local ComfyUI Diffusion Server' : 'Deterministic Media Renderer (Browser Native)',
      state,
      localNeuralVideoStatus: neuralStatus,
      localMediaRenderingStatus: renderingStatus,
      hardwareProfile: profile,
      reachable: comfyOnline || true, // Browser native renderer is available
      endpoint: comfyOnline ? endpoint : undefined,
      discoveredModels,
      candidateModels,
      activeModel: discoveredModels[0] || 'browser-native-canvas-dsp',
      failureReason,
      recommendation
    };

    this.lastReport = report;
    return report;
  }

  public getCurrentState(): LocalEngineState {
    return this.currentState;
  }

  public getNeuralStatus(): LocalNeuralVideoStatus {
    return this.neuralStatus;
  }

  public getRenderingStatus(): LocalMediaRenderingStatus {
    return this.renderingStatus;
  }

  public getLastReport(): LocalEngineDiscoveryReport | null {
    return this.lastReport;
  }
}
