/**
 * GODEX P5.4 — Real Execution Capability Verifier
 * 
 * Verifies live execution readiness and maps every creative generation workflow
 * (T2I, I2I, T2V, I2V, V2V, MEDIA_ENHANCE, IMAGE_SEQUENCE, AUDIO/SFX)
 * to its exact, non-fabricated runtime backend:
 * 
 * 1. REAL_ENGINE_AVAILABLE — Actual reachable neural server (e.g. ComfyUI / Local WebGPU cluster) with target model loaded.
 * 2. BROWSER_NATIVE_AVAILABLE — Hardware-accelerated browser pipeline (Canvas2D / WebGL2 / WebGPU / WebAudio / WebCodecs).
 * 3. LOCAL_DETERMINISTIC_AVAILABLE — Procedural synthesis / test pipeline without neural simulation.
 * 4. REQUIRES_ENGINE — Workflow demands a neural backend but no real engine is online.
 * 5. MODEL_UNAVAILABLE — Engine is reachable but requested checkpoint / model is absent.
 * 6. PREFLIGHT_FAILED — Workload exceeds physical limits or preflight checks.
 * 7. OUTPUT_INVALID — Payload failed container / decoder validation.
 * 8. QUALITY_GATE_FAILED — 15-axis quality scorecard failed threshold.
 * 
 * Strict Epistemic Invariants:
 * - NEVER convert deterministic execution into a REAL_ENGINE claim.
 * - NEVER fabricate GPU, VRAM, or model presence.
 * - Explicitly classify all fallbacks.
 */

import {
  EpistemicTruthClassification,
  ActualGenerationStatus,
  ActualEngineReachability
} from './productionTypes';
import { ProductionRuntimeCapabilityEngine, ProductionRuntimeCapabilityMatrix } from './productionRuntimeCapabilityEngine';
import { CreativeEngineRegistry } from '../creativeEngineRegistry';
import { ComfyUiEngineAdapter } from '../comfyUiEngineAdapter';
import { RemoteNeuralVideoEngineAdapter } from '../remoteNeuralVideoAdapter';

export type CreativeGenerationMode =
  | 'T2I'
  | 'I2I'
  | 'T2V'
  | 'I2V'
  | 'V2V'
  | 'MEDIA_ENHANCE'
  | 'IMAGE_SEQUENCE'
  | 'AUDIO'
  | 'SFX';

export type ExecutionCapabilityStatus =
  | 'REAL_ENGINE_AVAILABLE'
  | 'BROWSER_NATIVE_AVAILABLE'
  | 'LOCAL_DETERMINISTIC_AVAILABLE'
  | 'REQUIRES_ENGINE'
  | 'MODEL_UNAVAILABLE'
  | 'PREFLIGHT_FAILED'
  | 'OUTPUT_INVALID'
  | 'QUALITY_GATE_FAILED';

export interface GenerationModeCapabilityResult {
  mode: CreativeGenerationMode;
  status: ExecutionCapabilityStatus;
  epistemicClassification: EpistemicTruthClassification;
  targetEngineId: string;
  targetModelId?: string;
  executableBackend: 'COMFYUI_NEURAL' | 'REMOTE_NEURAL_ZEROGPU' | 'BROWSER_NATIVE_CANVAS' | 'BROWSER_NATIVE_WEBAUDIO' | 'LOCAL_DETERMINISTIC_PROCEDURAL' | 'NONE';
  reachability: ActualEngineReachability;
  reason: string;
  recommendedAction?: string;
}

export class RealExecutionCapabilityVerifier {
  private static instance: RealExecutionCapabilityVerifier | null = null;
  private capabilityEngine = ProductionRuntimeCapabilityEngine.getInstance();
  private engineRegistry = CreativeEngineRegistry.getInstance();
  private comfyAdapter = ComfyUiEngineAdapter.getInstance();
  private remoteNeuralAdapter = RemoteNeuralVideoEngineAdapter.getInstance();

  public static getInstance(): RealExecutionCapabilityVerifier {
    if (!RealExecutionCapabilityVerifier.instance) {
      RealExecutionCapabilityVerifier.instance = new RealExecutionCapabilityVerifier();
    }
    return RealExecutionCapabilityVerifier.instance;
  }

  /**
   * Evaluates the empirical execution readiness for a given creative generation mode.
   */
  public async verifyModeCapability(
    mode: CreativeGenerationMode,
    options: {
      requestedEngineId?: string;
      requestedModelId?: string;
      forceDeterministic?: boolean;
    } = {}
  ): Promise<GenerationModeCapabilityResult> {
    const {
      requestedEngineId,
      requestedModelId,
      forceDeterministic = false
    } = options;

    const runtimeMatrix = await this.capabilityEngine.probeCapabilities();

    // 1. Explicit deterministic override
    if (forceDeterministic || requestedEngineId === 'engine-browser-native' || requestedEngineId === 'engine-deterministic') {
      const isAudio = mode === 'AUDIO' || mode === 'SFX';
      return {
        mode,
        status: 'LOCAL_DETERMINISTIC_AVAILABLE',
        epistemicClassification: 'LOCAL_DETERMINISTIC_OUTPUT',
        targetEngineId: requestedEngineId || 'engine-deterministic',
        targetModelId: requestedModelId || 'deterministic-procedural',
        executableBackend: isAudio ? 'BROWSER_NATIVE_WEBAUDIO' : 'LOCAL_DETERMINISTIC_PROCEDURAL',
        reachability: 'LOCAL_ONLY',
        reason: 'Local deterministic execution pipeline active. Operates with zero external engine dependency.'
      };
    }

    // 2. Check ComfyUI / External Neural Engine
    const isComfyTarget = !requestedEngineId || requestedEngineId.includes('comfy') || requestedEngineId === 'engine-comfyui';
    if (isComfyTarget) {
      try {
        const discovery = await this.comfyAdapter.discover();
        const isOnline = discovery.available;
        if (isOnline) {
          // Check if model is available
          if (requestedModelId) {
            const models = this.comfyAdapter.getDiscoveredModels();
            const allDiscovered = [
              ...models.checkpoints,
              ...models.videoModels,
              ...models.upscalers,
              ...models.loras,
              ...models.controlnets
            ];
            const modelFound = allDiscovered.some(m => m === requestedModelId || m.includes(requestedModelId));
            if (!modelFound && allDiscovered.length > 0) {
              return {
                mode,
                status: 'MODEL_UNAVAILABLE',
                epistemicClassification: 'MODEL_UNAVAILABLE',
                targetEngineId: 'engine-comfyui',
                targetModelId: requestedModelId,
                executableBackend: 'NONE',
                reachability: 'REACHABLE',
                reason: `ComfyUI engine is online, but model '${requestedModelId}' was not found in active model checkpoints.`,
                recommendedAction: 'Install model checkpoint to ComfyUI models directory or select an available model.'
              };
            }
          }

          return {
            mode,
            status: 'REAL_ENGINE_AVAILABLE',
            epistemicClassification: 'REAL_ENGINE_OUTPUT',
            targetEngineId: 'engine-comfyui',
            targetModelId: requestedModelId || 'sd_xl_base_1.0.safetensors',
            executableBackend: 'COMFYUI_NEURAL',
            reachability: 'REACHABLE',
            reason: 'Real ComfyUI neural backend is reachable and ready for genuine generative execution.'
          };
        }
      } catch {
        // Engine probe threw or timed out
      }
    }

    // 2b. Check Remote Neural ZeroGPU Engine (LTX-Video Distilled Diffusion Transformer)
    const isRemoteNeuralTarget = requestedEngineId === 'engine-remote-neural-free' ||
      requestedEngineId === 'engine-ltx-video' ||
      requestedEngineId === 'engine-wan2.1' ||
      (!requestedEngineId && (mode === 'T2V' || mode === 'I2V' || mode === 'V2V'));

    if (isRemoteNeuralTarget) {
      try {
        const remoteDiscovery = await this.remoteNeuralAdapter.discover();
        if (remoteDiscovery.available) {
          return {
            mode,
            status: 'REAL_ENGINE_AVAILABLE',
            epistemicClassification: 'REAL_ENGINE_OUTPUT',
            targetEngineId: 'engine-remote-neural-free',
            targetModelId: requestedModelId || 'Lightricks/LTX-Video-Distilled',
            executableBackend: 'REMOTE_NEURAL_ZEROGPU',
            reachability: 'REACHABLE',
            reason: 'Remote ZeroGPU Neural Video Engine (LTX-Video Distilled) is reachable and verified.'
          };
        }
      } catch {
        // Remote neural probe threw
      }
    }

    // 3. Check Browser-Native Hardware Acceleration capabilities
    const hasCanvas2d = runtimeMatrix.capabilities.canvas2d.usable;
    const hasAudio = runtimeMatrix.capabilities.audioContext.usable;
    const hasWebCodecs = runtimeMatrix.capabilities.webcodecs.usable;
    const hasWebGpu = runtimeMatrix.capabilities.webgpu.usable;

    if (mode === 'AUDIO' || mode === 'SFX') {
      if (hasAudio) {
        return {
          mode,
          status: 'BROWSER_NATIVE_AVAILABLE',
          epistemicClassification: 'BROWSER_NATIVE_OUTPUT',
          targetEngineId: 'engine-web-audio',
          targetModelId: 'web-audio-synth',
          executableBackend: 'BROWSER_NATIVE_WEBAUDIO',
          reachability: 'LOCAL_ONLY',
          reason: 'Browser-native Web Audio DSP synthesis engine is usable for waveform rendering.'
        };
      }
    } else if (mode === 'IMAGE_SEQUENCE' || mode === 'T2I' || mode === 'I2I' || mode === 'MEDIA_ENHANCE') {
      if (hasCanvas2d || hasWebGpu) {
        return {
          mode,
          status: 'BROWSER_NATIVE_AVAILABLE',
          epistemicClassification: 'BROWSER_NATIVE_OUTPUT',
          targetEngineId: 'engine-browser-canvas',
          targetModelId: 'procedural-canvas-pipeline',
          executableBackend: 'BROWSER_NATIVE_CANVAS',
          reachability: 'LOCAL_ONLY',
          reason: 'Browser-native Canvas2D / WebGPU procedural rasterizer is usable.'
        };
      }
    }

    // 4. Fallback to REQUIRES_ENGINE if neural execution was specifically requested
    if (requestedEngineId && requestedEngineId !== 'engine-browser-native') {
      return {
        mode,
        status: 'REQUIRES_ENGINE',
        epistemicClassification: 'REQUIRES_ENGINE',
        targetEngineId: requestedEngineId,
        targetModelId: requestedModelId,
        executableBackend: 'NONE',
        reachability: 'UNREACHABLE',
        reason: `Required neural engine '${requestedEngineId}' is offline. No synthetic frames were fabricated.`,
        recommendedAction: 'Start local ComfyUI server at http://127.0.0.1:8188 or switch to deterministic test mode.'
      };
    }

    // 5. Default Deterministic Procedural Availability
    return {
      mode,
      status: 'LOCAL_DETERMINISTIC_AVAILABLE',
      epistemicClassification: 'LOCAL_DETERMINISTIC_OUTPUT',
      targetEngineId: 'engine-deterministic',
      targetModelId: 'procedural-synthesizer',
      executableBackend: 'LOCAL_DETERMINISTIC_PROCEDURAL',
      reachability: 'LOCAL_ONLY',
      reason: 'Deterministic browser-native test path is active. Truthfully labeled with zero neural fabrication.'
    };
  }

  /**
   * Audits all 8 generation modes simultaneously.
   */
  public async auditAllModes(options: {
    requestedEngineId?: string;
    forceDeterministic?: boolean;
  } = {}): Promise<Record<CreativeGenerationMode, GenerationModeCapabilityResult>> {
    const modes: CreativeGenerationMode[] = [
      'T2I',
      'I2I',
      'T2V',
      'I2V',
      'V2V',
      'MEDIA_ENHANCE',
      'IMAGE_SEQUENCE',
      'AUDIO',
      'SFX'
    ];

    const results = {} as Record<CreativeGenerationMode, GenerationModeCapabilityResult>;
    for (const mode of modes) {
      results[mode] = await this.verifyModeCapability(mode, options);
    }
    return results;
  }
}
