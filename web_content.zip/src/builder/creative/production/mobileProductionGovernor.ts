/**
 * GODEX P5.2 — Mobile-First Production Governor
 * 
 * Implements strict runtime governance, memory pressure mitigation,
 * frame batching, resolution scaling, thermal-safe execution policies,
 * WebGL context-loss protection, and background-tab suspension handling.
 * 
 * Truth Invariant:
 * Does not claim 4K or high-spec capability merely because the canvas or screen
 * can display large dimensions. Empirically clamps workloads to safe budgets.
 */

import { ProductionRuntimeCapabilityMatrix } from './productionRuntimeCapabilityEngine';

export type GovernorAdaptiveProfile =
  | 'MOBILE_SAFE'
  | 'MOBILE_BALANCED'
  | 'MOBILE_HIGH'
  | 'TABLET'
  | 'DESKTOP'
  | 'DESKTOP_HIGH';

export interface MobileGovernorPolicy {
  profile: GovernorAdaptiveProfile;
  maxResolution: {
    width: number;
    height: number;
  };
  maxFps: number;
  maxShotDurationSec: number;
  maxProjectDurationSec: number;
  maxVramUsageMb: number;
  maxRamBudgetMb: number;
  renderBatchFrameCount: number;
  downscaleFactor: number;
  enableThermalThrottling: boolean;
  throttleIntervalMs: number;
  allowSimultaneousTracks: number;
  audioSampleRateHz: number;
  requiresProgressiveFlushing: boolean;
}

export interface RuntimeMemoryStatus {
  currentHeapMb?: number;
  limitHeapMb?: number;
  pressureLevel: 'NORMAL' | 'MODERATE' | 'CRITICAL';
  recommendedAction: 'CONTINUE' | 'THROTTLE' | 'DOWNGRADE_RESOLUTION' | 'ABORT_TO_PREVENT_CRASH';
}

export class MobileProductionGovernor {
  private static instance: MobileProductionGovernor | null = null;
  private isTabBackgrounded = false;
  private contextLossCount = 0;
  private abortSignalFired = false;

  constructor() {
    this.initLifecycleListeners();
  }

  public static getInstance(): MobileProductionGovernor {
    if (!MobileProductionGovernor.instance) {
      MobileProductionGovernor.instance = new MobileProductionGovernor();
    }
    return MobileProductionGovernor.instance;
  }

  private initLifecycleListeners(): void {
    if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
      document.addEventListener('visibilitychange', () => {
        this.isTabBackgrounded = document.hidden;
      });
    }
  }

  /**
   * Returns active governor policy based on ambient device environment or safe defaults.
   */
  public getActivePolicy(): MobileGovernorPolicy {
    const isBrowser = typeof window !== 'undefined' && typeof navigator !== 'undefined';
    const hwConcurrency = isBrowser ? (navigator.hardwareConcurrency || 4) : 4;
    const memoryEstimateMb = isBrowser && (navigator as any).deviceMemory ? (navigator as any).deviceMemory * 1024 : 1024;
    
    return this.resolvePolicy({
      hardwareConcurrency: hwConcurrency,
      memoryEstimateMb,
      maxTextureDimension: 4096,
      capabilities: {
        webgpu: { usable: false },
        webcodecs: { usable: typeof VideoEncoder !== 'undefined' }
      }
    } as any);
  }

  /**
   * Determine the optimal adaptive policy based on empirical capability matrix.
   */
  public resolvePolicy(matrix: ProductionRuntimeCapabilityMatrix): MobileGovernorPolicy {
    const hwConcurrency = matrix.hardwareConcurrency || 4;
    const maxTex = matrix.maxTextureDimension || 4096;
    const hasWebGPU = matrix.capabilities?.webgpu?.usable ?? false;
    const hasWebCodecs = matrix.capabilities?.webcodecs?.usable ?? false;
    const memoryMb = matrix.memoryEstimateMb || 1024;

    // Determine Governor Profile
    let profile: GovernorAdaptiveProfile = 'MOBILE_SAFE';

    if (hasWebGPU && hwConcurrency >= 8 && memoryMb >= 4096 && maxTex >= 8192) {
      profile = 'DESKTOP_HIGH';
    } else if (hwConcurrency >= 6 && memoryMb >= 3000 && maxTex >= 4096) {
      profile = 'DESKTOP';
    } else if (hwConcurrency >= 4 && memoryMb >= 2048 && maxTex >= 4096) {
      profile = 'TABLET';
    } else if (hwConcurrency >= 4 && memoryMb >= 1500 && maxTex >= 2048) {
      profile = 'MOBILE_HIGH';
    } else if (hwConcurrency >= 2 && memoryMb >= 1000) {
      profile = 'MOBILE_BALANCED';
    } else {
      profile = 'MOBILE_SAFE';
    }

    switch (profile) {
      case 'DESKTOP_HIGH':
        return {
          profile,
          maxResolution: { width: 3840, height: 2160 },
          maxFps: 60,
          maxShotDurationSec: 60,
          maxProjectDurationSec: 300,
          maxVramUsageMb: 4096,
          maxRamBudgetMb: 3072,
          renderBatchFrameCount: 30,
          downscaleFactor: 1.0,
          enableThermalThrottling: false,
          throttleIntervalMs: 0,
          allowSimultaneousTracks: 8,
          audioSampleRateHz: 48000,
          requiresProgressiveFlushing: false
        };

      case 'DESKTOP':
        return {
          profile,
          maxResolution: { width: 1920, height: 1080 },
          maxFps: 60,
          maxShotDurationSec: 30,
          maxProjectDurationSec: 180,
          maxVramUsageMb: 2048,
          maxRamBudgetMb: 1536,
          renderBatchFrameCount: 15,
          downscaleFactor: 1.0,
          enableThermalThrottling: false,
          throttleIntervalMs: 0,
          allowSimultaneousTracks: 8,
          audioSampleRateHz: 48000,
          requiresProgressiveFlushing: false
        };

      case 'TABLET':
        return {
          profile,
          maxResolution: { width: 1920, height: 1080 },
          maxFps: 30,
          maxShotDurationSec: 20,
          maxProjectDurationSec: 120,
          maxVramUsageMb: 1024,
          maxRamBudgetMb: 1024,
          renderBatchFrameCount: 10,
          downscaleFactor: 1.0,
          enableThermalThrottling: true,
          throttleIntervalMs: 8,
          allowSimultaneousTracks: 6,
          audioSampleRateHz: 48000,
          requiresProgressiveFlushing: true
        };

      case 'MOBILE_HIGH':
        return {
          profile,
          maxResolution: { width: 1280, height: 720 },
          maxFps: 30,
          maxShotDurationSec: 15,
          maxProjectDurationSec: 60,
          maxVramUsageMb: 768,
          maxRamBudgetMb: 768,
          renderBatchFrameCount: 5,
          downscaleFactor: 1.0,
          enableThermalThrottling: true,
          throttleIntervalMs: 16,
          allowSimultaneousTracks: 4,
          audioSampleRateHz: 48000,
          requiresProgressiveFlushing: true
        };

      case 'MOBILE_BALANCED':
        return {
          profile,
          maxResolution: { width: 1280, height: 720 },
          maxFps: 24,
          maxShotDurationSec: 10,
          maxProjectDurationSec: 45,
          maxVramUsageMb: 512,
          maxRamBudgetMb: 512,
          renderBatchFrameCount: 4,
          downscaleFactor: 0.75,
          enableThermalThrottling: true,
          throttleIntervalMs: 25,
          allowSimultaneousTracks: 3,
          audioSampleRateHz: 44100,
          requiresProgressiveFlushing: true
        };

      case 'MOBILE_SAFE':
      default:
        return {
          profile: 'MOBILE_SAFE',
          maxResolution: { width: 854, height: 480 },
          maxFps: 24,
          maxShotDurationSec: 8,
          maxProjectDurationSec: 30,
          maxVramUsageMb: 256,
          maxRamBudgetMb: 384,
          renderBatchFrameCount: 2,
          downscaleFactor: 0.5,
          enableThermalThrottling: true,
          throttleIntervalMs: 40,
          allowSimultaneousTracks: 2,
          audioSampleRateHz: 44100,
          requiresProgressiveFlushing: true
        };
    }
  }

  /**
   * Monitor live memory pressure and recommend actions.
   */
  public checkMemoryPressure(policy: MobileGovernorPolicy): RuntimeMemoryStatus {
    let currentHeapMb: number | undefined;
    let limitHeapMb: number | undefined;

    if (typeof performance !== 'undefined' && (performance as any).memory) {
      const mem = (performance as any).memory;
      currentHeapMb = Math.round(mem.usedJSHeapSize / (1024 * 1024));
      limitHeapMb = Math.round(mem.jsHeapSizeLimit / (1024 * 1024));
    }

    if (currentHeapMb !== undefined && limitHeapMb !== undefined) {
      const ratio = currentHeapMb / limitHeapMb;
      if (ratio > 0.85 || currentHeapMb > policy.maxRamBudgetMb * 1.2) {
        return {
          currentHeapMb,
          limitHeapMb,
          pressureLevel: 'CRITICAL',
          recommendedAction: 'ABORT_TO_PREVENT_CRASH'
        };
      } else if (ratio > 0.70 || currentHeapMb > policy.maxRamBudgetMb * 0.9) {
        return {
          currentHeapMb,
          limitHeapMb,
          pressureLevel: 'MODERATE',
          recommendedAction: 'DOWNGRADE_RESOLUTION'
        };
      }
    }

    return {
      currentHeapMb,
      limitHeapMb,
      pressureLevel: 'NORMAL',
      recommendedAction: 'CONTINUE'
    };
  }

  /**
   * Clamp requested resolution and FPS to the governor limits.
   */
  public clampRenderSpec(
    reqWidth: number,
    reqHeight: number,
    reqFps: number,
    policy: MobileGovernorPolicy
  ): { width: number; height: number; fps: number; wasClamped: boolean; clampReason?: string } {
    let width = reqWidth;
    let height = reqHeight;
    let fps = Math.min(reqFps, policy.maxFps);
    let wasClamped = false;
    let clampReason: string | undefined;

    if (width > policy.maxResolution.width || height > policy.maxResolution.height) {
      const scale = Math.min(
        policy.maxResolution.width / width,
        policy.maxResolution.height / height
      );
      width = Math.round(width * scale);
      height = Math.round(height * scale);
      // Ensure even dimensions for video codecs (H.264/VP9/WebM)
      if (width % 2 !== 0) width -= 1;
      if (height % 2 !== 0) height -= 1;

      wasClamped = true;
      clampReason = `Resolution clamped from ${reqWidth}x${reqHeight} to ${width}x${height} for profile ${policy.profile}`;
    }

    if (reqFps > policy.maxFps) {
      wasClamped = true;
      clampReason = (clampReason ? clampReason + '; ' : '') + `FPS clamped from ${reqFps} to ${fps}`;
    }

    return { width, height, fps, wasClamped, clampReason };
  }

  public recordContextLoss(): void {
    this.contextLossCount++;
  }

  public getContextLossCount(): number {
    return this.contextLossCount;
  }

  public isBackgrounded(): boolean {
    return this.isTabBackgrounded;
  }
}
