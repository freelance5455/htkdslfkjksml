/**
 * GODEX P5.0 — Production Orchestration & Creative Workstation Types
 * 
 * Authoritative unified data structures for full production pipeline:
 * SCRIPT / IDEA → PROJECT → SCENE → SHOT → CAMERA → MEDIA GENERATION →
 * VFX → AUDIO/SFX → TIMELINE ASSEMBLY → COLOR → CINEMATIC FINISHING →
 * FINAL RENDER → OUTPUT VALIDATION → QUALITY GATE → EXPORT
 * 
 * Maintains ZERO-FABRICATION & EPISTEMIC-TRUTH invariants.
 */

import {
  MediaWorkflowType,
  CameraMovementType,
  VideoStylePreset
} from '../creativeStudioTypes';
import {
  AssemblyTrackCategory,
  AssemblyTruthClassification
} from '../mediaAssemblyTypes';
import { ColorGradingState } from '../color/colorTypes';

// ============================================================================
// 1. PRODUCTION EXECUTION LIFECYCLE STATES
// ============================================================================

export type ProductionExecutionStage =
  | 'IDLE'
  | 'PREFLIGHT'
  | 'PLANNING'
  | 'RESOURCE_CHECK'
  | 'GENERATING'
  | 'VFX'
  | 'AUDIO'
  | 'ASSEMBLY'
  | 'COLOR'
  | 'FINISHING'
  | 'FINAL_RENDER'
  | 'VALIDATION'
  | 'QUALITY_GATE'
  | 'EXPORT'
  | 'COMPLETED'
  | 'PAUSED'
  | 'CANCELLED'
  | 'FAILED'
  | 'RECOVERING'
  | 'RESUME_AVAILABLE'
  | 'REQUIRES_ENGINE';

export type ProductionPreflightStatus =
  | 'READY'
  | 'WARNING'
  | 'PREFLIGHT_FAILED'
  | 'REQUIRES_ENGINE'
  | 'MODEL_UNAVAILABLE'
  | 'RESOURCE_LIMIT'
  | 'UNSUPPORTED_EXPORT';

export type ProductionShotStatus =
  | 'PLANNED'
  | 'READY'
  | 'GENERATING'
  | 'GENERATED'
  | 'VFX_APPLIED'
  | 'AUDIO_ATTACHED'
  | 'ASSEMBLED'
  | 'GRADED'
  | 'VERIFIED'
  | 'REQUIRES_ENGINE'
  | 'FAILED';

export type QualityGateVerdict =
  | 'PASS'
  | 'PASS_WITH_WARNINGS'
  | 'BLOCKED';

// ============================================================================
// 2. SHOT-LEVEL PRODUCTION CONTRACT
// ============================================================================

export interface ShotProductionSpec {
  shotId: string;
  sceneId: string;
  prompt: string;
  negativePrompt?: string;
  durationSec: number;
  fps: number;
  aspectRatio: string;
  resolution: {
    width: number;
    height: number;
  };
  // Physical Camera Parameters
  cameraBody: string;
  lens: string;
  focalLengthMm: number;
  apertureTStop: number;
  focusDistanceMeters: number;
  cameraMovement: CameraMovementType;
  lightingIntent: string;
  // Generation & Model Target
  generationWorkflow: MediaWorkflowType;
  selectedModelId: string;
  seed?: number;
  // Multi-Engine Requirements
  vfxRequirements: {
    enabled: boolean;
    preset?: string;
    intensity?: number;
    layers?: string[];
  };
  audioRequirements: {
    sfx?: string[];
    foley?: string[];
    musicStyle?: string;
    ambiencePreset?: string;
  };
  colorIntent: {
    lookPreset?: string;
    temperatureKelvin?: number;
    tint?: number;
    exposureEV?: number;
    contrast?: number;
  };
  continuityRequirements: {
    subjectAnchorPrompt?: string;
    matchPreviousShotFocalLength?: boolean;
    matchPreviousLighting?: boolean;
    maintainAxisAngle?: number;
  };
}

export interface ProductionShot {
  id: string;
  shotNumber: number;
  sceneId: string;
  title: string;
  description: string;
  spec: ShotProductionSpec;
  status: ProductionShotStatus;
  generatedAssetId?: string;
  renderedOutputRef?: string;
  vfxLayerRefs: string[];
  audioLayerRefs: string[];
  provenance: AssemblyTruthClassification;
  metadata: {
    plannedAt: number;
    executedAt?: number;
    engineUsed?: string;
    renderTimeMs?: number;
    fileSizeBytes?: number;
  };
}

// ============================================================================
// 3. SCENE & PROJECT MODELS
// ============================================================================

export interface ProductionScene {
  id: string;
  sceneNumber: number;
  name: string;
  description: string;
  targetDurationSec: number;
  lightingIntent: string;
  colorPaletteIntent: string;
  continuityNotes: string;
  shots: ProductionShot[];
  status: 'DRAFT' | 'READY' | 'IN_PROGRESS' | 'COMPLETED' | 'BLOCKED';
}

export interface MasterTimelineSpecification {
  id: string;
  fps: number;
  width: number;
  height: number;
  totalDurationSec: number;
  tracks: {
    video: string[];
    vfx: string[];
    overlay: string[];
    dialogue: string[];
    sfx: string[];
    foley: string[];
    ambience: string[];
    music: string[];
  };
  markers: Array<{
    id: string;
    timeSec: number;
    label: string;
    type: 'SCENE_START' | 'BEAT' | 'TRANSITION' | 'VFX_CUE';
  }>;
}

export interface ColorFinishingSettings {
  colorSpace: string;
  gradingState: ColorGradingState;
  filmGrainEnabled: boolean;
  filmGrainIntensity: number;
  vignetteEnabled: boolean;
  vignetteAmount: number;
  lensDistortionCorrection: boolean;
  chromaticAberrationSubtle: boolean;
}

export interface ProductionRenderSettings {
  targetResolution: { width: number; height: number };
  targetFps: number;
  targetBitrateKbps: number;
  antialiasing: boolean;
  colorDepthBits: 8 | 10 | 16;
  audioSampleRateHz: 44100 | 48000;
  audioChannels: 1 | 2;
  masterLimiterDb: number;
}

export interface ProductionExportSettings {
  containerFormat: 'WEBM' | 'MP4' | 'WAV' | 'PNG_SEQUENCE' | 'JPEG_SEQUENCE' | 'WEBP_SEQUENCE';
  videoCodec: string;
  audioCodec: string;
  includeEvidenceDossier: boolean;
  includeTimelineReport: boolean;
}

export interface ProductionVerificationEvidence {
  preflightPassed: boolean;
  qualityGateScore: number;
  continuityScore: number;
  colorIntegrityScore: number;
  audioSyncDriftMs: number;
  classification: AssemblyTruthClassification;
  auditTrail: Array<{
    stage: string;
    timestamp: number;
    status: string;
    details: string;
    provenance: AssemblyTruthClassification;
  }>;
}

export interface ProductionProject {
  id: string;
  title: string;
  concept: string;
  script: string;
  stylePreset: VideoStylePreset;
  scenes: ProductionScene[];
  masterTimeline: MasterTimelineSpecification;
  colorFinishing: ColorFinishingSettings;
  renderSettings: ProductionRenderSettings;
  exportSettings: ProductionExportSettings;
  evidence: ProductionVerificationEvidence;
  createdAt: number;
  updatedAt: number;
  projectHash: string;
}

// ============================================================================
// 4. PRODUCTION DEPENDENCY GRAPH (DAG)
// ============================================================================

export type ProductionNodeType =
  | 'PROJECT_INIT'
  | 'SCRIPT_PARSER'
  | 'SCENE_PLANNER'
  | 'SHOT_PLANNER'
  | 'CAMERA_SPECIFIER'
  | 'MEDIA_GENERATOR'
  | 'VFX_COMPOSITOR'
  | 'AUDIO_SYNTHESIZER'
  | 'TIMELINE_ASSEMBLER'
  | 'COLOR_GRADER'
  | 'CINEMATIC_FINISHER'
  | 'FINAL_RENDERER'
  | 'OUTPUT_VALIDATOR'
  | 'QUALITY_GATE'
  | 'MEDIA_EXPORTER';

export interface ProductionNode {
  id: string;
  type: ProductionNodeType;
  name: string;
  dependencies: string[]; // Node IDs that must complete first
  status: 'PENDING' | 'READY' | 'RUNNING' | 'COMPLETED' | 'SKIPPED' | 'FAILED' | 'BLOCKED' | 'REQUIRES_ENGINE';
  sceneId?: string;
  shotId?: string;
  progressPercent: number;
  error?: string;
  resultRef?: any;
}

export interface ProductionGraph {
  nodes: Map<string, ProductionNode>;
  executionOrder: string[];
  parallelBatches: string[][];
}

// ============================================================================
// 5. PREFLIGHT & QUALITY REPORT TYPES
// ============================================================================

export interface PreflightCheckItem {
  id: string;
  category: 'ASSET' | 'CAMERA' | 'MODEL' | 'ENGINE' | 'VFX' | 'AUDIO' | 'TIMELINE' | 'MEMORY' | 'CODEC' | 'COLOR' | 'SYNC';
  name: string;
  passed: boolean;
  status: 'PASS' | 'WARN' | 'FAIL' | 'REQUIRES_ENGINE';
  message: string;
  requiredEngine?: string;
}

export interface ProductionPreflightReport {
  status: ProductionPreflightStatus;
  checks: PreflightCheckItem[];
  resourceEstimate: {
    ramMb: number;
    durationEstimateSec: number;
    totalFrames: number;
    isMobileSafe: boolean;
    mobileSafe: boolean;
  };
  honestyStatement: string;
  timestamp: number;
}

export interface QualityCategoryScore {
  score: number;
  status: 'PASS' | 'WARN' | 'FAIL';
  note: string;
}

export interface ProductionQualityGateReport {
  verdict: QualityGateVerdict;
  overallScore: number;
  categories: {
    videoIntegrity: QualityCategoryScore;
    frameContinuity: QualityCategoryScore;
    temporalConsistency: QualityCategoryScore;
    subjectConsistency: QualityCategoryScore;
    cameraContinuity: QualityCategoryScore;
    vfxIntegrity: QualityCategoryScore;
    audioIntegrity: QualityCategoryScore;
    avSync: QualityCategoryScore;
    colorIntegrity: QualityCategoryScore;
    dynamicRangeCompliance: QualityCategoryScore;
    containerIntegrity: QualityCategoryScore;
    resolutionCompliance: QualityCategoryScore;
    fpsCompliance: QualityCategoryScore;
    outputCompleteness: QualityCategoryScore;
    resourceSafety: QualityCategoryScore;
  };
  reasons: string[];
  timestamp: number;
}

// ============================================================================
// 6. REAL PROGRESS TELEMETRY & RECOVERY
// ============================================================================

export interface ProductionProgressTelemetry {
  overallProgress: number | 'PROGRESS_UNAVAILABLE';
  currentStage: ProductionExecutionStage;
  currentSceneId?: string;
  currentShotId?: string;
  currentAssetId?: string;
  currentEngine: string;
  elapsedTimeMs: number;
  estimatedRemainingTimeMs?: number;
  memoryUsageMb?: number;
  renderFrame: number;
  totalFrames: number;
  warnings: string[];
  errors: string[];
  verificationStatus: 'PENDING' | 'IN_PROGRESS' | 'PASSED' | 'FAILED';
}

export interface ProductionCheckpoint {
  checkpointId: string;
  projectId: string;
  projectHash: string;
  timelineHash: string;
  stage: ProductionExecutionStage;
  completedSceneIds: string[];
  completedShotIds: string[];
  completedAssets: Record<string, any>;
  renderSettings: ProductionRenderSettings;
  exportSettings: ProductionExportSettings;
  timestamp: number;
}

// ============================================================================
// 7. P5.1 PRODUCTION EXECUTION PROOF & EPISTEMIC TRUTH
// ============================================================================

export type EpistemicTruthClassification =
  | 'REAL_NEURAL_GENERATED'
  | 'REAL_ENGINE_OUTPUT'
  | 'REAL_COLAB_ENGINE_OUTPUT'
  | 'REAL_KAGGLE_ENGINE_OUTPUT'
  | 'LOCAL_DETERMINISTIC'
  | 'LOCAL_DETERMINISTIC_OUTPUT'
  | 'BROWSER_NATIVE'
  | 'BROWSER_NATIVE_OUTPUT'
  | 'BROWSER_NATIVE_DETERMINISTIC'
  | 'BROWSER_NATIVE_MEDIA'
  | 'LOCAL_NEURAL_ENGINE'
  | 'REMOTE_NEURAL_ENGINE'
  | 'REQUIRES_ENGINE'
  | 'COLAB_ENGINE_UNAVAILABLE'
  | 'COLAB_GPU_UNAVAILABLE'
  | 'KAGGLE_ENGINE_UNAVAILABLE'
  | 'KAGGLE_GPU_UNAVAILABLE'
  | 'KAGGLE_MODEL_UNAVAILABLE'
  | 'KAGGLE_GENERATION_FAILED'
  | 'KAGGLE_RUNTIME_TERMINATED'
  | 'MODEL_RESOURCE_INSUFFICIENT'
  | 'MODEL_UNAVAILABLE'
  | 'HARDWARE_UNSUPPORTED'
  | 'PREFLIGHT_FAILED'
  | 'OUTPUT_INVALID'
  | 'QUALITY_GATE_FAILED'
  | 'ENGINE_DISCONNECTED'
  | 'CANCELLED'
  | 'FAILED'
  | 'UNVERIFIED'
  | 'NOT_VERIFIED';

export type ActualEngineReachability =
  | 'REACHABLE'
  | 'UNREACHABLE'
  | 'LOCAL_ONLY'
  | 'NOT_CONFIGURED';

export type ActualGenerationStatus =
  | 'REAL_NEURAL_COMPLETED'
  | 'REAL_ENGINE_OUTPUT'
  | 'REAL_COLAB_ENGINE_OUTPUT'
  | 'REAL_KAGGLE_ENGINE_OUTPUT'
  | 'LOCAL_DETERMINISTIC_COMPLETED'
  | 'LOCAL_DETERMINISTIC_OUTPUT'
  | 'BROWSER_NATIVE_OUTPUT'
  | 'BROWSER_NATIVE_DETERMINISTIC'
  | 'BROWSER_NATIVE_MEDIA'
  | 'LOCAL_NEURAL_ENGINE'
  | 'REMOTE_NEURAL_ENGINE'
  | 'REQUIRES_ENGINE'
  | 'COLAB_ENGINE_UNAVAILABLE'
  | 'COLAB_GPU_UNAVAILABLE'
  | 'KAGGLE_ENGINE_UNAVAILABLE'
  | 'KAGGLE_GPU_UNAVAILABLE'
  | 'KAGGLE_MODEL_UNAVAILABLE'
  | 'KAGGLE_GENERATION_FAILED'
  | 'KAGGLE_RUNTIME_TERMINATED'
  | 'MODEL_RESOURCE_INSUFFICIENT'
  | 'MODEL_UNAVAILABLE'
  | 'HARDWARE_UNSUPPORTED'
  | 'PREFLIGHT_FAILED'
  | 'OUTPUT_INVALID'
  | 'QUALITY_GATE_FAILED'
  | 'ENGINE_DISCONNECTED'
  | 'MEMORY_PRESSURE'
  | 'UNSUPPORTED_CODEC'
  | 'TIMEOUT'
  | 'CANCELLED'
  | 'FAILED';

export type ProductionPreviewBridgeState =
  | 'IDLE'
  | 'PREFLIGHT'
  | 'WAITING_FOR_ENGINE'
  | 'QUEUED'
  | 'RUNNING'
  | 'RETRIEVING_OUTPUT'
  | 'VALIDATING_OUTPUT'
  | 'QUALITY_GATE'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED'
  | 'REQUIRES_ENGINE';

export interface ProductionRuntimeExecutionContract {
  executionId: string;
  projectId: string;
  timelineHash: string;
  engineId: string;
  workflowType: MediaWorkflowType;
  modelId: string;
  inputAssets: string[];
  outputTarget: string;
  requestedResolution: {
    width: number;
    height: number;
  };
  requestedFPS: number;
  durationSec: number;
  executionMode:
    | 'BROWSER_NATIVE_DETERMINISTIC'
    | 'BROWSER_NATIVE_MEDIA'
    | 'LOCAL_NEURAL_ENGINE'
    | 'REMOTE_NEURAL_ENGINE'
    | 'REQUIRES_ENGINE';
  capabilityEvidence: {
    deviceTier: string;
    maxTextureDimension: number;
    hardwareConcurrency: number;
    webgpuAvailable: boolean;
    webgl2Available: boolean;
  };
  preflightEvidence: {
    passed: boolean;
    preflightStatus: ProductionPreflightStatus;
    resourceEstimateRamMb: number;
  };
  timestamps: {
    created: number;
    started?: number;
    completed?: number;
  };
  cancellationSignal: boolean;
  retryCount: number;
  maxRetries: number;
}

export interface ProductionExecutionProof {
  proofId: string;
  timestamp: number;
  prompt: string;
  projectId: string;
  projectHash: string;
  timelineHash: string;
  sceneIds: string[];
  shotIds: string[];
  selectedModel: string;
  selectedEngine: string;
  actualEngineReachability: ActualEngineReachability;
  actualHardwareCapability: {
    gpuName?: string;
    vramFreeMb?: number;
    ramMb: number;
    webglMaxTextureSize: number;
    concurrency: number;
    isMobileSafe: boolean;
  };
  actualGenerationStatus: ActualGenerationStatus;
  actualOutputBytes: number;
  outputSizeBytes: number;
  outputMimeType: string;
  containerSignatureValid: boolean;
  integrityVerified: boolean;
  dimensions: {
    width: number;
    height: number;
  };
  fps: number;
  durationSec: number;
  qualityScore: {
    overall: number;
    verdict: QualityGateVerdict;
    breakdown: Record<string, number>;
  };
  qualityGateScore: number;
  qualityVerdict: QualityGateVerdict;
  vfxEvidence: {
    enabled: boolean;
    preset?: string;
    particleCount: number;
    webglKeyerActive: boolean;
    passes: string[];
  };
  audioEvidence: {
    sampleRateHz: number;
    channels: number;
    durationSec: number;
    peakAmplitudeDb: number;
    stemsSynthesized: string[];
  };
  avSyncEvidence: {
    measuredDriftMs: number;
    frameAligned: boolean;
    maxAllowedDriftMs: number;
  };
  measuredAvSyncDriftMs: number;
  exportEvidence: {
    containerFormat: string;
    binarySignature: string;
    byteLength: number;
    checksum: string;
    probedMuxerSupported: boolean;
  };
  epistemicTruthClassification: EpistemicTruthClassification;
  generationMode?: 'NATIVE_NEURAL' | 'MULTI_CLIP_ASSEMBLY' | 'DETERMINISTIC_SYNTHETIC' | 'UNVERIFIED';
  quotaState?: 'AVAILABLE' | 'ZERO_GPU_QUOTA_LIMIT' | 'RATE_LIMITED' | 'UNAUTHENTICATED';
  authenticationState?: 'AUTHENTICATED' | 'NOT_AUTHENTICATED';
  computeProvider?: 'KAGGLE' | 'HUGGING_FACE' | 'GOOGLE_COLAB' | 'LOCAL';
  executionProvider?: string;
  kaggleEvidence?: {
    workerSessionId?: string;
    gpuName?: string;
    gpuMemory?: string;
    cudaVersion?: string;
    driverVersion?: string;
    torchVersion?: string;
    torchCudaAvailable?: boolean;
    modelName?: string;
    modelVersion?: string;
    inferenceTimeMs?: number;
    runtimeState?: string;
  };
  colabEvidence?: {
    workerSessionId?: string;
    gpuName?: string;
    gpuMemory?: string;
    cudaVersion?: string;
    driverVersion?: string;
    torchVersion?: string;
    modelName?: string;
    inferenceTimeMs?: number;
    runtimeState?: string;
  };
  huggingFaceUsed?: boolean;
  googleColabUsed?: boolean;
  cacheFallbackUsed?: boolean;
  staticFallbackUsed?: boolean;
  multiClipProvenance?: MultiClipMasterProvenance;
  visualContentEvidence?: VisualContentMetrics;
  diagnostics?: {
    failureReason?: string;
    connectionGuidance?: string;
    recoveryActionTaken?: string;
  };
}

// ============================================================================
// 6. GODEX P5.8 & P5.8.1 EXTENDED CINEMATIC NEURAL TYPES
// ============================================================================

export interface MultiClipProofItem {
  shotId: string;
  jobId: string;
  engineId: string;
  modelId: string;
  durationSec: number;
  measuredDurationSec?: number;
  frameCount?: number;
  firstFrameHash?: string;
  middleFrameHash?: string;
  lastFrameHash?: string;
  uniqueFramesCount?: number;
  resolution: { width: number; height: number };
  fps: number;
  byteSize: number;
  sha256: string;
  validationResult: 'VALID_MP4' | 'INVALID_CONTAINER' | 'FAILED';
  prompt: string;
}

export type TemporalIntegrityStatus =
  | 'VERIFIED_UNIQUE'
  | 'DUPLICATE_SOURCE_MEDIA'
  | 'DUPLICATE_TEMPORAL_CONTENT'
  | 'INVALID_TEMPORAL_DURATION'
  | 'NEURAL_SOURCE_DURATION_INSUFFICIENT'
  | 'FAILED';

export type VisualContentIntegrityStatus =
  | 'VERIFIED_REAL_VISUAL'
  | 'SMPTE_COLOR_BARS_DETECTED'
  | 'TEST_PATTERN_DETECTED'
  | 'SOLID_COLOR_PLACEHOLDER'
  | 'BLACK_FRAMES_DETECTED'
  | 'STATIC_FROZEN_MEDIA'
  | 'DIAGNOSTIC_FRAMES_DETECTED'
  | 'INVALID_VISUAL_OUTPUT';

export interface VisualContentMetrics {
  sampledFramesCount: number;
  spatialVariance: number;
  minSpatialVariance: number;
  temporalVariance: number;
  meanLuma: number;
  flatnessRatioH: number;
  flatnessRatioV: number;
  primaryColorRatio: number;
  isColorBarPattern: boolean;
  isTestPattern: boolean;
  isSolidOrBlack: boolean;
  isStaticOrFrozen: boolean;
  perceptualHashes: string[];
  visualIntegrityStatus: VisualContentIntegrityStatus;
  rejectionReason?: string;
  visualValidationPassed: boolean;
}

export interface MultiClipMasterProvenance {
  masterJobId: string;
  clips: MultiClipProofItem[];
  assemblyMethod: 'FFMPEG_BINARY_CONCAT_DEMUX' | 'DEMUX_MUX_ASSEMBLY';
  totalAssembledClips: number;
  calculatedDurationSec: number;
  measuredDurationSec: number;
  durationMatch: boolean;
  temporalOrderVerified: boolean;
  duplicateSourceDetected?: boolean;
  duplicateTemporalContentDetected?: boolean;
  insufficientDurationDetected?: boolean;
  temporalUniquenessVerified?: boolean;
  masterFrameCount?: number;
  masterUniqueFrames?: number;
  temporalIntegrityStatus?: TemporalIntegrityStatus;
  rejectionReason?: string;
}

export type GenerationModeType =
  | 'NATIVE_NEURAL'
  | 'MULTI_CLIP_ASSEMBLY'
  | 'DETERMINISTIC_SYNTHETIC'
  | 'UNVERIFIED';

export type ZeroGpuQuotaState =
  | 'AVAILABLE'
  | 'ZERO_GPU_QUOTA_LIMIT'
  | 'EXHAUSTED'
  | 'RATE_LIMITED'
  | 'UNAUTHENTICATED'
  | 'UNKNOWN';

export type AuthenticationState =
  | 'AUTHENTICATED'
  | 'NOT_AUTHENTICATED'
  | 'UNKNOWN';

export type ContinuityMethod =
  | 'PROMPT_CONSTRAINED'
  | 'REFERENCE_CONDITIONED';

export interface ShotContinuityMetadata {
  environment: string;
  lighting: string;
  weather: string;
  dominantColors: string[];
  subjectDescription: string;
  cameraDirection: string;
  lensIntent: string;
  timeOfDay: string;
  visualStyle: string;
  continuityMethod: ContinuityMethod;
}

export interface CinematicShotPlan {
  shotId: string;
  shotNumber: number;
  title: string;
  prompt: string;
  negativePrompt: string;
  cameraDescription: string;
  movement: CameraMovementType;
  lighting: string;
  environment: string;
  duration: number;
  resolution: { width: number; height: number };
  fps: number;
  seed: number;
  continuityMetadata: ShotContinuityMetadata;
  generationStatus: 'PENDING' | 'GENERATING' | 'COMPLETED' | 'FAILED';
  mediaUrl?: string;
  byteSize?: number;
  sha256?: string;
  error?: string;
}

export interface RealNeuralExecutionReceipt {
  requestId: string;
  engine: string;
  space: string;
  endpoint: string;
  submittedTimestamp: number;
  completedTimestamp?: number;
  backendResponseStatus: 'COMPLETED' | 'QUOTA_EXHAUSTED' | 'RATE_LIMITED' | 'FAILED' | 'REJECTED_VISUAL_VALIDATION' | 'UNREACHABLE';
  jobId?: string;
  eventId?: string;
  mediaType: string;
  byteSize: number;
  sourceRef: string;
  actualDuration: number;
  frameCount: number;
  resolution: { width: number; height: number };
  fps: number;
  sha256: string;
  visualValidationResult?: VisualContentMetrics;
  error?: string;
  isCachedFallback?: boolean;
}

export interface AuthoritativeNeuralEngineStatus {
  provider: string;
  space: string;
  endpoint: string;
  engineName: string;
  engineId: string;
  modelId: string;
  endpointReachability: 'ONLINE' | 'OFFLINE' | 'UNREACHABLE';
  authenticationState: AuthenticationState;
  quotaState: ZeroGpuQuotaState;
  queueState: 'NORMAL' | 'RATE_LIMITED' | 'QUEUE_BACKLOG';
  lastSuccessfulGeneration: {
    timestamp: number;
    requestId: string;
    jobId: string;
    durationSec: number;
    sha256: string;
  } | null;
  lastFailedGeneration: {
    timestamp: number;
    requestId: string;
    reason: string;
    quotaState: ZeroGpuQuotaState;
  } | null;
  failureReason: string | null;
  estimatedRetryInfo: string | null;
  engineAvailable: boolean;
  modelAvailable: boolean;
  supportedDurations: number[];
  supportedResolutions: Array<{ label: string; width: number; height: number }>;
  supportedFps: number[];
  generationModesSupported: GenerationModeType[];
  serverMessage?: string;
}

export interface CapabilityProbeResult extends AuthoritativeNeuralEngineStatus {}

