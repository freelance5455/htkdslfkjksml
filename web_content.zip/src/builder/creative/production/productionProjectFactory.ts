/**
 * GODEX P5.0 — Production Project Factory & Template System
 * 
 * Provides deterministic templates and project bootstrapping:
 * - Default Cinematic Production Project
 * - Multi-Scene / Multi-Shot Film Spec
 * - 8-Track Master Timeline initialization
 * - Camera, Lens, VFX, and Color Grading default calibrations
 */

import {
  ProductionProject,
  ProductionScene,
  ProductionShot,
  ShotProductionSpec
} from './productionTypes';
import { VideoStylePreset } from '../creativeStudioTypes';
import { CinematicColorGradingEngine } from '../color/cinematicColorGradingEngine';
import { AutonomousProductionPlan } from './autonomousCreativeDirector';
import { AutonomousShotSequencePlan } from './autonomousShotPlanner';

export class ProductionProjectFactory {
  /**
   * Creates a fully structured ProductionProject directly from Autonomous Director & Shot Plans.
   */
  public static createFromAutonomousPlan(
    plan: AutonomousProductionPlan,
    shotSequence: AutonomousShotSequencePlan
  ): ProductionProject {
    const projectId = plan.id;
    const sceneId1 = `scene_${projectId}_01`;

    const shots: ProductionShot[] = shotSequence.shots.map((plannedShot, idx) => {
      const shotSpec: ShotProductionSpec = {
        shotId: plannedShot.shotId,
        sceneId: sceneId1,
        prompt: plannedShot.prompt,
        negativePrompt: plannedShot.negativePrompt,
        durationSec: plannedShot.durationSec,
        fps: plannedShot.fps,
        aspectRatio: plannedShot.aspectRatio,
        resolution: plannedShot.resolution,
        cameraBody: plannedShot.camera.cameraBody,
        lens: plannedShot.camera.lens,
        focalLengthMm: plannedShot.camera.focalLengthMm,
        apertureTStop: plannedShot.camera.apertureTStop,
        focusDistanceMeters: plannedShot.camera.focusDistanceMeters,
        cameraMovement: plannedShot.camera.movement,
        lightingIntent: plannedShot.continuity.lightingSignature,
        generationWorkflow: 'TEXT_TO_VIDEO',
        selectedModelId: plannedShot.selectedModel,
        seed: 42000 + idx * 7,
        vfxRequirements: {
          enabled: plannedShot.vfx.enabled,
          preset: plannedShot.vfx.cinematicEffects[0] || 'ATMOSPHERIC_MIST',
          intensity: plannedShot.vfx.intensity,
          layers: plannedShot.vfx.cinematicEffects
        },
        audioRequirements: {
          sfx: plannedShot.audio.sfxStems,
          foley: plannedShot.audio.foleyStems,
          musicStyle: plannedShot.audio.musicTrack,
          ambiencePreset: plannedShot.audio.ambienceTrack
        },
        colorIntent: {
          lookPreset: plannedShot.color.lookPreset,
          temperatureKelvin: plannedShot.color.temperatureKelvin,
          tint: plannedShot.color.tint,
          exposureEV: 0.0,
          contrast: 1.12
        },
        continuityRequirements: {
          subjectAnchorPrompt: plannedShot.continuity.characterIdentityAnchor,
          matchPreviousShotFocalLength: idx > 0,
          matchPreviousLighting: true,
          maintainAxisAngle: plannedShot.continuity.axisAngleDegrees
        }
      };

      const shot: ProductionShot = {
        id: plannedShot.shotId,
        shotNumber: plannedShot.shotNumber,
        sceneId: sceneId1,
        title: plannedShot.title,
        description: plannedShot.prompt,
        spec: shotSpec,
        status: 'READY',
        vfxLayerRefs: plannedShot.vfx.cinematicEffects,
        audioLayerRefs: plannedShot.audio.sfxStems,
        provenance: plannedShot.generationMode === 'REAL_NEURAL' ? 'REAL_ENGINE' : (plannedShot.generationMode === 'BROWSER_NATIVE_MEDIA' ? 'BROWSER_NATIVE' : 'LOCAL_DETERMINISTIC'),
        metadata: {
          plannedAt: shotSequence.plannedAt
        }
      };

      return shot;
    });

    const scene: ProductionScene = {
      id: sceneId1,
      sceneNumber: 1,
      name: plan.title.value || 'Cinematic Sequence',
      description: plan.narrativeIntent.value || 'Autonomous production scene sequence.',
      targetDurationSec: shotSequence.totalDurationSec,
      lightingIntent: plan.lightingIntent.value,
      colorPaletteIntent: plan.colorRequirements.value.lookPreset,
      continuityNotes: `Continuity score target: ${shotSequence.continuityIntegrityScore}%. ${shotSequence.limitationsExposed.join(' ')}`,
      shots,
      status: 'READY'
    };

    const markers = shots.map((s, idx) => {
      let timeSec = 0;
      for (let j = 0; j < idx; j++) {
        timeSec += shots[j].spec.durationSec;
      }
      return {
        id: `mk_${s.id}`,
        timeSec,
        label: `${s.id} Start`,
        type: (idx === 0 ? 'SCENE_START' : 'TRANSITION') as 'SCENE_START' | 'TRANSITION'
      };
    });

    const project: ProductionProject = {
      id: projectId,
      title: plan.title.value,
      concept: plan.creativeIntent.value,
      script: `INT/EXT. AUTONOMOUS PRODUCTION - CONTINUOUS\n\n${plan.creativeIntent.value}\n\n${plan.narrativeIntent.value}`,
      stylePreset: plan.genreStyle.value,
      scenes: [scene],
      masterTimeline: {
        id: `tl-${projectId}`,
        fps: plan.deliveryRequirements.value.fps,
        width: plan.deliveryRequirements.value.resolution.width,
        height: plan.deliveryRequirements.value.resolution.height,
        totalDurationSec: shotSequence.totalDurationSec,
        tracks: {
          video: ['track_vid_1'],
          vfx: ['track_vfx_1'],
          overlay: [],
          dialogue: [],
          sfx: ['track_sfx_1'],
          foley: ['track_foley_1'],
          ambience: ['track_ambience_1'],
          music: ['track_music_1']
        },
        markers
      },
      colorFinishing: {
        colorSpace: 'sRGB',
        gradingState: CinematicColorGradingEngine.getDefaultState(),
        filmGrainEnabled: true,
        filmGrainIntensity: plan.colorRequirements.value.filmGrainIntensity || 0.12,
        vignetteEnabled: true,
        vignetteAmount: 0.18,
        lensDistortionCorrection: true,
        chromaticAberrationSubtle: true
      },
      renderSettings: {
        targetResolution: plan.deliveryRequirements.value.resolution,
        targetFps: plan.deliveryRequirements.value.fps,
        targetBitrateKbps: 8000,
        antialiasing: true,
        colorDepthBits: 8,
        audioSampleRateHz: 48000,
        audioChannels: 2,
        masterLimiterDb: -0.1
      },
      exportSettings: {
        containerFormat: plan.deliveryRequirements.value.containerFormat,
        videoCodec: plan.deliveryRequirements.value.videoCodec,
        audioCodec: plan.deliveryRequirements.value.audioCodec,
        includeEvidenceDossier: true,
        includeTimelineReport: true
      },
      evidence: {
        preflightPassed: false,
        qualityGateScore: 0,
        continuityScore: shotSequence.continuityIntegrityScore,
        colorIntegrityScore: 0,
        audioSyncDriftMs: 0,
        classification: 'LOCAL_DETERMINISTIC',
        auditTrail: []
      },
      createdAt: plan.generatedAt,
      updatedAt: Date.now(),
      projectHash: ''
    };

    return project;
  }
  /**
   * Creates a structured cinematic production project.
   */
  public static createCinematicProject(
    title: string = 'Cinematic Odyssey',
    concept: string = 'A lone explorer reaches an ancient cyberpunk monolith at dusk.',
    style: VideoStylePreset = 'CINEMATIC'
  ): ProductionProject {
    const projectId = `proj-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;
    const sceneId1 = `scene-${Date.now().toString(36)}-01`;

    const shot1Spec: ShotProductionSpec = {
      shotId: `shot-${sceneId1}-01`,
      sceneId: sceneId1,
      prompt: 'Wide cinematic establishing shot of an ancient neon monolith towering over a misty dusk valley, volumetric light beams, 8k resolution, photorealistic.',
      negativePrompt: 'blurry, oversaturated, low quality, cartoon, watermark, distorted, shaky',
      durationSec: 4.0,
      fps: 24,
      aspectRatio: '2.39:1',
      resolution: { width: 1920, height: 1080 },
      cameraBody: 'ARRI_ALEXA_35',
      lens: 'COOKE_S4_I_35MM',
      focalLengthMm: 35,
      apertureTStop: 2.0,
      focusDistanceMeters: 25.0,
      cameraMovement: 'PAN_RIGHT',
      lightingIntent: 'DUSK_VOLUMETRIC_SUNSET',
      generationWorkflow: 'TEXT_TO_VIDEO',
      selectedModelId: 'hunyuan-video-t2v',
      seed: 42891,
      vfxRequirements: {
        enabled: true,
        preset: 'ATMOSPHERIC_FOG_VOLUMETRIC',
        intensity: 0.7,
        layers: ['mist_particle_01', 'volumetric_beam_01']
      },
      audioRequirements: {
        sfx: ['low_dusk_wind', 'distant_synth_drone'],
        foley: ['footsteps_gravel'],
        musicStyle: 'ambient_cinematic_brass',
        ambiencePreset: 'cyberpunk_valley_wind'
      },
      colorIntent: {
        lookPreset: 'TEAL_AND_ORANGE',
        temperatureKelvin: 5200,
        tint: -2,
        exposureEV: 0.1,
        contrast: 1.15
      },
      continuityRequirements: {
        subjectAnchorPrompt: 'monolith_explorer_dusk',
        matchPreviousShotFocalLength: false,
        matchPreviousLighting: true,
        maintainAxisAngle: 45
      }
    };

    const shot2Spec: ShotProductionSpec = {
      shotId: `shot-${sceneId1}-02`,
      sceneId: sceneId1,
      prompt: 'Close-up over the shoulder shot of the explorer gazing up at glowing glyphs etched into the monolith surface, anamorphic lens flare, sharp focus.',
      negativePrompt: 'blurry, oversaturated, cartoon, low contrast',
      durationSec: 3.5,
      fps: 24,
      aspectRatio: '2.39:1',
      resolution: { width: 1920, height: 1080 },
      cameraBody: 'ARRI_ALEXA_35',
      lens: 'ZEISS_MASTER_PRIME_50MM',
      focalLengthMm: 50,
      apertureTStop: 1.4,
      focusDistanceMeters: 1.8,
      cameraMovement: 'DOLLY_IN',
      lightingIntent: 'GLOWING_NEON_RIM',
      generationWorkflow: 'TEXT_TO_VIDEO',
      selectedModelId: 'hunyuan-video-t2v',
      seed: 42892,
      vfxRequirements: {
        enabled: true,
        preset: 'GLYPH_ENERGY_PARTICLES',
        intensity: 0.8,
        layers: ['glyph_glow_mask']
      },
      audioRequirements: {
        sfx: ['energy_hum_high', 'monolith_pulse'],
        foley: ['suit_movement_leather'],
        ambiencePreset: 'energy_field_low_rumble'
      },
      colorIntent: {
        lookPreset: 'TEAL_AND_ORANGE',
        temperatureKelvin: 5400,
        tint: 0,
        exposureEV: 0.0,
        contrast: 1.2
      },
      continuityRequirements: {
        subjectAnchorPrompt: 'monolith_explorer_dusk',
        matchPreviousShotFocalLength: false,
        matchPreviousLighting: true,
        maintainAxisAngle: 60
      }
    };

    const shot1: ProductionShot = {
      id: shot1Spec.shotId,
      shotNumber: 1,
      sceneId: sceneId1,
      title: 'Scene 1 / Shot 1: Establishing Dusk Monolith',
      description: 'Wide panoramic view of the ancient structure in mist.',
      spec: shot1Spec,
      status: 'READY',
      vfxLayerRefs: ['vfx_fog_01'],
      audioLayerRefs: ['sfx_wind_01', 'music_drone_01'],
      provenance: 'LOCAL_DETERMINISTIC',
      metadata: {
        plannedAt: Date.now()
      }
    };

    const shot2: ProductionShot = {
      id: shot2Spec.shotId,
      shotNumber: 2,
      sceneId: sceneId1,
      title: 'Scene 1 / Shot 2: Close-up Explorer & Glyphs',
      description: 'Close optical perspective on illuminated glyphs.',
      spec: shot2Spec,
      status: 'READY',
      vfxLayerRefs: ['vfx_glyph_01'],
      audioLayerRefs: ['sfx_pulse_01'],
      provenance: 'LOCAL_DETERMINISTIC',
      metadata: {
        plannedAt: Date.now()
      }
    };

    const scene1: ProductionScene = {
      id: sceneId1,
      sceneNumber: 1,
      name: 'Arrival at the Dusk Monolith',
      description: 'The protagonist approaches the ancient technological landmark as dusk falls.',
      targetDurationSec: 7.5,
      lightingIntent: 'Golden hour twilight with volumetric sky beams and cyan neon glyph contrast.',
      colorPaletteIntent: 'Deep teal shadows, golden amber highlights, cyan neon accents.',
      continuityNotes: 'Camera tracks from West to East. Keep protagonist on screen-left to preserve 180° line.',
      shots: [shot1, shot2],
      status: 'READY'
    };

    const project: ProductionProject = {
      id: projectId,
      title,
      concept,
      script: `SCENE 1 - EXT. DUSK VALLEY - EVENING\n\nMist rolls across the twilight basin. A towering monolith of dark metallic alloy reflects the last amber rays of the dying sun.\n\nThe EXPLORER steps into frame, breathing steady within the thermal suit. The glyphs on the surface begin to resonate with soft cyan luminance.`,
      stylePreset: style,
      scenes: [scene1],
      masterTimeline: {
        id: `tl-${projectId}`,
        fps: 24,
        width: 1920,
        height: 1080,
        totalDurationSec: 7.5,
        tracks: {
          video: ['track_vid_1'],
          vfx: ['track_vfx_1'],
          overlay: [],
          dialogue: [],
          sfx: ['track_sfx_1'],
          foley: ['track_foley_1'],
          ambience: ['track_ambience_1'],
          music: ['track_music_1']
        },
        markers: [
          { id: 'mk_1', timeSec: 0, label: 'Scene 1 Start', type: 'SCENE_START' },
          { id: 'mk_2', timeSec: 4.0, label: 'Shot 2 Cut', type: 'TRANSITION' },
          { id: 'mk_3', timeSec: 5.5, label: 'Glyph Activation', type: 'VFX_CUE' }
        ]
      },
      colorFinishing: {
        colorSpace: 'sRGB',
        gradingState: CinematicColorGradingEngine.getDefaultState(),
        filmGrainEnabled: true,
        filmGrainIntensity: 0.18,
        vignetteEnabled: true,
        vignetteAmount: 0.22,
        lensDistortionCorrection: true,
        chromaticAberrationSubtle: true
      },
      renderSettings: {
        targetResolution: { width: 1920, height: 1080 },
        targetFps: 24,
        targetBitrateKbps: 8000,
        antialiasing: true,
        colorDepthBits: 8,
        audioSampleRateHz: 48000,
        audioChannels: 2,
        masterLimiterDb: -0.1
      },
      exportSettings: {
        containerFormat: 'WEBM',
        videoCodec: 'VP9',
        audioCodec: 'Opus',
        includeEvidenceDossier: true,
        includeTimelineReport: true
      },
      evidence: {
        preflightPassed: false,
        qualityGateScore: 0,
        continuityScore: 0,
        colorIntegrityScore: 0,
        audioSyncDriftMs: 0,
        classification: 'LOCAL_DETERMINISTIC',
        auditTrail: []
      },
      createdAt: Date.now(),
      updatedAt: Date.now(),
      projectHash: ''
    };

    return project;
  }
}
