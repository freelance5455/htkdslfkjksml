/**
 * GODEX P5.5 — Autonomous Creative Production & End-to-End Delivery Test Suite
 * 
 * Comprehensive 30+ test cases validating:
 * - AutonomousCreativeDirector: 19-dimensional intent analysis & epistemic tag tracking
 * - AutonomousShotPlanner: Deterministic shot IDs, optical profiles, continuity anchors & disclaimers
 * - AutonomousEngineModelRouter: Reachability checking, device capabilities, zero-fabrication routing
 * - AutonomousProductionDagOrchestrator: Dynamic DAG task compilation, dependency execution, retries & reports
 * - ProductionProjectFactory: Unified project generation from autonomous director plan & shot sequences
 * - ProductionExecutionController: Full autonomous end-to-end orchestration & verifiable proof dossiers
 * - Zero-Fabrication Enforcement: Inferred vs specified parameter clarity and model reachability truth
 */

import { AutonomousCreativeDirector, EpistemicallyTracked } from './autonomousCreativeDirector';
import { AutonomousShotPlanner, AutonomousShotSequencePlan } from './autonomousShotPlanner';
import { AutonomousEngineModelRouter, RouteEvaluationResult } from './autonomousEngineRouter';
import { AutonomousProductionDagOrchestrator, ProductionDagTask } from './autonomousProductionDag';
import { ProductionProjectFactory } from './productionProjectFactory';
import { ProductionExecutionController } from './productionExecutionController';
import { RealExecutionCapabilityVerifier } from './realExecutionCapabilityVerifier';

export interface TestCaseResult {
  name: string;
  passed: boolean;
  error?: string;
  durationMs: number;
}

export class P55AutonomousCreativeProductionTestSuite {
  private director: AutonomousCreativeDirector;
  private planner: AutonomousShotPlanner;
  private router: AutonomousEngineModelRouter;
  private controller: ProductionExecutionController;

  constructor() {
    this.director = AutonomousCreativeDirector.getInstance();
    this.planner = AutonomousShotPlanner.getInstance();
    this.router = AutonomousEngineModelRouter.getInstance();
    this.controller = ProductionExecutionController.getInstance();
  }

  public static async runAllTests(): Promise<{ passed: number; failed: number; results: TestCaseResult[] }> {
    const suite = new P55AutonomousCreativeProductionTestSuite();
    const results: TestCaseResult[] = [];

    const tests: Array<{ name: string; fn: () => Promise<void> | void }> = [
      // -----------------------------------------------------------------
      // 1. Autonomous Creative Director Intent Analysis Tests
      // -----------------------------------------------------------------
      {
        name: 'P5.5-DIR-01: Director extracts user-specified genre and style tokens',
        fn: () => suite.testDirectorStyleExtraction()
      },
      {
        name: 'P5.5-DIR-02: Director extracts user-specified shot count accurately',
        fn: () => suite.testDirectorShotCountExtraction()
      },
      {
        name: 'P5.5-DIR-03: Director parses lens and focal length specifications',
        fn: () => suite.testDirectorLensExtraction()
      },
      {
        name: 'P5.5-DIR-04: Director parses camera movement and angle tokens',
        fn: () => suite.testDirectorCameraMovementExtraction()
      },
      {
        name: 'P5.5-DIR-05: Director extracts lighting, time-of-day, and mood conditions',
        fn: () => suite.testDirectorLightingAndMood()
      },
      {
        name: 'P5.5-DIR-06: Director extracts color grading and LUT keywords',
        fn: () => suite.testDirectorColorLookExtraction()
      },
      {
        name: 'P5.5-DIR-07: Director extracts audio, dialogue, and foley intent',
        fn: () => suite.testDirectorAudioExtraction()
      },
      {
        name: 'P5.5-DIR-08: Director extracts VFX keywords and requirements',
        fn: () => suite.testDirectorVfxExtraction()
      },
      {
        name: 'P5.5-DIR-09: Director calculates accurate epistemic summary (user vs inferred vs default)',
        fn: () => suite.testDirectorEpistemicSummary()
      },
      {
        name: 'P5.5-DIR-10: Director generates deterministic plan IDs from prompt hash',
        fn: () => suite.testDirectorDeterministicPlanId()
      },

      // -----------------------------------------------------------------
      // 2. Autonomous Shot Planner Tests
      // -----------------------------------------------------------------
      {
        name: 'P5.5-SHOT-01: Shot Planner generates deterministic shot sequence with SHOT_XXX IDs',
        fn: () => suite.testShotPlannerSequenceGeneration()
      },
      {
        name: 'P5.5-SHOT-02: Shot Planner assigns distinct camera angles across multiple shots',
        fn: () => suite.testShotPlannerCameraProgression()
      },
      {
        name: 'P5.5-SHOT-03: Shot Planner configures optical parameters and depth-of-field per shot',
        fn: () => suite.testShotPlannerOpticalSpecs()
      },
      {
        name: 'P5.5-SHOT-04: Shot Planner sets up lighting cues and lighting schemes per shot',
        fn: () => suite.testShotPlannerLightingCues()
      },
      {
        name: 'P5.5-SHOT-05: Shot Planner creates audio cues and foley prompts matching scene context',
        fn: () => suite.testShotPlannerAudioCues()
      },
      {
        name: 'P5.5-SHOT-06: Shot Planner sets up VFX specifications per shot',
        fn: () => suite.testShotPlannerVfxSpecs()
      },
      {
        name: 'P5.5-SHOT-07: Shot Planner injects truthful continuity limitation disclaimers',
        fn: () => suite.testShotPlannerContinuityDisclaimers()
      },
      {
        name: 'P5.5-SHOT-08: Shot Planner assigns character visual anchors without fabricating identity locks',
        fn: () => suite.testShotPlannerCharacterAnchors()
      },

      // -----------------------------------------------------------------
      // 3. Autonomous Engine & Model Router Tests
      // -----------------------------------------------------------------
      {
        name: 'P5.5-ROUT-01: Router evaluates AUTO mode and chooses valid engine fallback',
        fn: () => suite.testRouterAutoModeSelection()
      },
      {
        name: 'P5.5-ROUT-02: Router blocks REAL_NEURAL when engine is unreachable (REQUIRES_ENGINE)',
        fn: () => suite.testRouterNeuralUnreachableBlocks()
      },
      {
        name: 'P5.5-ROUT-03: Router selects LOCAL_DETERMINISTIC without claiming neural generation',
        fn: () => suite.testRouterLocalDeterministicSelection()
      },
      {
        name: 'P5.5-ROUT-04: Router detects unavailable model IDs truthfully (MODEL_UNAVAILABLE)',
        fn: () => suite.testRouterModelUnavailableDetection()
      },
      {
        name: 'P5.5-ROUT-05: Router injects transparent zero-fabrication disclaimers into route evaluation',
        fn: () => suite.testRouterZeroFabricationDisclaimers()
      },
      {
        name: 'P5.5-ROUT-06: Router matches requested resolution and framerate to engine capability',
        fn: () => suite.testRouterResolutionCapabilityMatching()
      },

      // -----------------------------------------------------------------
      // 4. Autonomous Production DAG Orchestrator Tests
      // -----------------------------------------------------------------
      {
        name: 'P5.5-DAG-01: DAG Orchestrator compiles complete task graph from Director Plan',
        fn: () => suite.testDagCompilation()
      },
      {
        name: 'P5.5-DAG-02: DAG Orchestrator resolves task dependencies in correct topological order',
        fn: () => suite.testDagDependencyOrdering()
      },
      {
        name: 'P5.5-DAG-03: DAG Orchestrator executes tasks sequentially and updates task state',
        fn: () => suite.testDagTaskExecution()
      },
      {
        name: 'P5.5-DAG-04: DAG Orchestrator isolates task failures and supports retry policies',
        fn: () => suite.testDagRetryPolicy()
      },
      {
        name: 'P5.5-DAG-05: DAG Orchestrator generates complete execution report with task telemetry',
        fn: () => suite.testDagReportGeneration()
      },

      // -----------------------------------------------------------------
      // 5. Production Project Factory & End-to-End Controller Tests
      // -----------------------------------------------------------------
      {
        name: 'P5.5-E2E-01: Factory creates ProductionProject from Autonomous Plan & Shot Sequence',
        fn: () => suite.testFactoryCreateFromAutonomousPlan()
      },
      {
        name: 'P5.5-E2E-02: Controller orchestrates full autonomous production pipeline',
        fn: () => suite.testControllerAutonomousPipeline()
      },
      {
        name: 'P5.5-E2E-03: Controller generates complete execution proof with autonomous metadata',
        fn: () => suite.testControllerProofGeneration()
      },
      {
        name: 'P5.5-E2E-04: Controller halts and reports REQUIRES_ENGINE when offline neural mode requested',
        fn: () => suite.testControllerOfflineNeuralRejection()
      },
      {
        name: 'P5.5-E2E-05: Controller preserves epistemic truth classification end-to-end',
        fn: () => suite.testControllerEpistemicPreservation()
      }
    ];

    for (const test of tests) {
      const start = Date.now();
      try {
        await test.fn();
        results.push({
          name: test.name,
          passed: true,
          durationMs: Date.now() - start
        });
      } catch (err: any) {
        results.push({
          name: test.name,
          passed: false,
          error: err.message || String(err),
          durationMs: Date.now() - start
        });
      }
    }

    const passed = results.filter(r => r.passed).length;
    const failed = results.filter(r => !r.passed).length;
    return { passed, failed, results };
  }

  // -----------------------------------------------------------------
  // Implementations
  // -----------------------------------------------------------------

  private testDirectorStyleExtraction(): void {
    const prompt = 'Epic scifi noir cyberpunk detective walking through rainy alleys in neo tokyo';
    const plan = this.director.analyzePrompt(prompt);

    if (plan.genreStyle.value !== 'CYBERPUNK' && plan.genreStyle.value !== 'NOIR') {
      throw new Error(`Expected CYBERPUNK or NOIR style, got ${plan.genreStyle.value}`);
    }
    if (plan.genreStyle.source !== 'USER_SPECIFIED') {
      throw new Error(`Expected style source to be USER_SPECIFIED, got ${plan.genreStyle.source}`);
    }
  }

  private testDirectorShotCountExtraction(): void {
    const prompt = 'Cinematic sequence of 3 shots depicting a spaceship launch';
    const plan = this.director.analyzePrompt(prompt);

    if (plan.shotCount.value !== 3) {
      throw new Error(`Expected shotCount 3, got ${plan.shotCount.value}`);
    }
    if (plan.shotCount.source !== 'USER_SPECIFIED') {
      throw new Error(`Expected shotCount source USER_SPECIFIED, got ${plan.shotCount.source}`);
    }

    const prompt2 = 'A quick single shot of an ocean wave';
    const plan2 = this.director.analyzePrompt(prompt2);
    if (plan2.shotCount.value !== 1) {
      throw new Error(`Expected shotCount 1, got ${plan2.shotCount.value}`);
    }
  }

  private testDirectorLensExtraction(): void {
    const prompt = 'Shot on anamorphic 35mm lens, shallow depth of field, wide aperture';
    const plan = this.director.analyzePrompt(prompt);

    const hasAnamorphic = plan.lenses.value.some(l => l.toUpperCase().includes('ANAMORPHIC'));
    if (!hasAnamorphic) {
      throw new Error(`Expected ANAMORPHIC lens, got ${JSON.stringify(plan.lenses.value)}`);
    }
    const has35mm = plan.focalCharacteristics.value.some(f => f.focalLengthMm === 35);
    if (!has35mm) {
      throw new Error(`Expected 35mm focal length, got ${JSON.stringify(plan.focalCharacteristics.value)}`);
    }
    if (plan.lenses.source !== 'USER_SPECIFIED') {
      throw new Error(`Expected lenses source USER_SPECIFIED, got ${plan.lenses.source}`);
    }
  }

  private testDirectorCameraMovementExtraction(): void {
    const prompt = 'Drone aerial shot tracking overhead with orbit movement';
    const plan = this.director.analyzePrompt(prompt);

    const hasMovement = plan.cameraMovements.value.some(m => m === 'ORBIT' || m === 'TRACKING_SHOT' || m === 'CRANE');
    if (!hasMovement) {
      throw new Error(`Expected tracking/orbit camera movement, got ${JSON.stringify(plan.cameraMovements.value)}`);
    }
    if (plan.cameraMovements.source !== 'USER_SPECIFIED') {
      throw new Error(`Expected cameraMovements source USER_SPECIFIED, got ${plan.cameraMovements.source}`);
    }
  }

  private testDirectorLightingAndMood(): void {
    const prompt = 'Dramatic golden hour sunset with volumetric fog and moody contrast';
    const plan = this.director.analyzePrompt(prompt);

    const timeOfDay = plan.environment.value.timeOfDay.toUpperCase();
    const lightingIntent = plan.lightingIntent.value.toUpperCase();
    if (!timeOfDay.includes('GOLDEN') && !timeOfDay.includes('SUNSET') && !lightingIntent.includes('GOLDEN') && !lightingIntent.includes('SUNSET')) {
      throw new Error(`Expected GOLDEN_HOUR time of day, got ${timeOfDay} / ${lightingIntent}`);
    }
    if (plan.environment.source !== 'USER_SPECIFIED' && plan.lightingIntent.source !== 'USER_SPECIFIED') {
      throw new Error(`Expected lighting/environment source USER_SPECIFIED`);
    }
  }

  private testDirectorColorLookExtraction(): void {
    const prompt = 'Moody thriller look with teal and orange color grade and film grain';
    const plan = this.director.analyzePrompt(prompt);

    const preset = plan.colorRequirements.value.lookPreset.toUpperCase();
    if (!preset.includes('TEAL')) {
      throw new Error(`Expected TEAL look preset, got ${plan.colorRequirements.value.lookPreset}`);
    }
    if (plan.colorRequirements.source !== 'USER_SPECIFIED') {
      throw new Error(`Expected colorRequirements source USER_SPECIFIED, got ${plan.colorRequirements.source}`);
    }
  }

  private testDirectorAudioExtraction(): void {
    const prompt = 'Thunderous storm with heavy rain ambient foley, synth drone score, and radio voiceover dialogue';
    const plan = this.director.analyzePrompt(prompt);

    const hasFoley = plan.audioRequirements.value.foleyCues.length > 0 || plan.audioRequirements.value.ambiencePreset.length > 0;
    const hasDialogue = plan.audioRequirements.value.dialoguePrompts.length > 0;
    if (!hasFoley) {
      throw new Error('Expected foley/ambience cues to be extracted');
    }
    if (!hasDialogue) {
      throw new Error('Expected dialogue prompts to be extracted');
    }
    if (plan.audioRequirements.source !== 'USER_SPECIFIED') {
      throw new Error(`Expected audioRequirements source USER_SPECIFIED, got ${plan.audioRequirements.source}`);
    }
  }

  private testDirectorVfxExtraction(): void {
    const prompt = 'Action explosion scene with laser sparks, smoke simulation, and chromatic aberration';
    const plan = this.director.analyzePrompt(prompt);

    if (!plan.vfxRequirements.value.enabled && plan.vfxRequirements.value.cinematicEffects.length === 0) {
      throw new Error('Expected vfxRequirements to be enabled with effects');
    }
    if (plan.vfxRequirements.value.cinematicEffects.length === 0) {
      throw new Error('Expected extracted cinematic effects');
    }
    if (plan.vfxRequirements.source !== 'USER_SPECIFIED') {
      throw new Error(`Expected vfxRequirements source USER_SPECIFIED, got ${plan.vfxRequirements.source}`);
    }
  }

  private testDirectorEpistemicSummary(): void {
    const prompt = 'Cyberpunk 35mm dusk shot';
    const plan = this.director.analyzePrompt(prompt);

    const summary = plan.epistemicSummary;
    if (summary.userSpecifiedCount <= 0) {
      throw new Error(`Expected userSpecifiedCount > 0, got ${summary.userSpecifiedCount}`);
    }
    if (summary.defaultCount <= 0) {
      throw new Error(`Expected defaultCount > 0, got ${summary.defaultCount}`);
    }
  }

  private testDirectorDeterministicPlanId(): void {
    const prompt = 'A tranquil mountain lake at sunrise';
    const plan1 = this.director.analyzePrompt(prompt);
    const plan2 = this.director.analyzePrompt(prompt);

    if (plan1.id !== plan2.id) {
      throw new Error(`Expected identical id for identical prompt, got ${plan1.id} vs ${plan2.id}`);
    }
  }

  private testShotPlannerSequenceGeneration(): void {
    const plan = this.director.analyzePrompt('A futuristic city flyover, 2 shots');
    const sequence = this.planner.planShots(plan);

    if (sequence.shots.length !== 2) {
      throw new Error(`Expected 2 shots in sequence, got ${sequence.shots.length}`);
    }
    if (sequence.shots[0].shotId !== 'SHOT_001' || sequence.shots[1].shotId !== 'SHOT_002') {
      throw new Error(`Expected SHOT_001 & SHOT_002, got ${sequence.shots[0].shotId}, ${sequence.shots[1].shotId}`);
    }
  }

  private testShotPlannerCameraProgression(): void {
    const plan = this.director.analyzePrompt('Cinematic narrative with 3 shots');
    const sequence = this.planner.planShots(plan);

    const shot1 = sequence.shots[0];
    const shot2 = sequence.shots[1];
    const shot3 = sequence.shots[2];

    if (shot1.camera.movement === shot2.camera.movement && shot2.camera.movement === shot3.camera.movement) {
      // Check that camera angles or focal lengths vary
      if (shot1.camera.focalLengthMm === shot2.camera.focalLengthMm && shot2.camera.focalLengthMm === shot3.camera.focalLengthMm) {
        throw new Error('Expected variation in camera progression across multi-shot sequence');
      }
    }
  }

  private testShotPlannerOpticalSpecs(): void {
    const plan = this.director.analyzePrompt('Cinematic 50mm lens portrait, 1 shot');
    const sequence = this.planner.planShots(plan);
    const shot = sequence.shots[0];

    if (!shot.camera.lens || !shot.camera.sensorSize) {
      throw new Error('Expected lens and sensor size in shot camera spec');
    }
    if (shot.camera.focalLengthMm !== 50) {
      throw new Error(`Expected 50mm focal length, got ${shot.camera.focalLengthMm}`);
    }
  }

  private testShotPlannerLightingCues(): void {
    const plan = this.director.analyzePrompt('Golden hour sunset scene, 1 shot');
    const sequence = this.planner.planShots(plan);
    const shot = sequence.shots[0];

    if (!shot.lighting.scheme || !shot.lighting.timeOfDay) {
      throw new Error('Expected lighting scheme and time of day in shot lighting spec');
    }
  }

  private testShotPlannerAudioCues(): void {
    const plan = this.director.analyzePrompt('Sci-fi lab with ambient drones and computer beeps, 1 shot');
    const sequence = this.planner.planShots(plan);
    const shot = sequence.shots[0];

    if (!shot.audio.ambienceTrack && shot.audio.sfxStems.length === 0) {
      throw new Error('Expected ambienceTrack or sfxStems in shot audio spec');
    }
  }

  private testShotPlannerVfxSpecs(): void {
    const plan = this.director.analyzePrompt('Laser battle with smoke and particle sparks, 1 shot');
    const sequence = this.planner.planShots(plan);
    const shot = sequence.shots[0];

    if (shot.vfx.cinematicEffects.length === 0 && !shot.vfx.enabled) {
      throw new Error('Expected non-empty cinematicEffects or enabled VFX spec');
    }
  }

  private testShotPlannerContinuityDisclaimers(): void {
    const plan = this.director.analyzePrompt('Character walking from street into room, 2 shots');
    const sequence = this.planner.planShots(plan);

    if (sequence.shots[1].continuity.knownLimitations.length === 0) {
      throw new Error('Expected truthful continuity limitations for multi-shot sequence');
    }
  }

  private testShotPlannerCharacterAnchors(): void {
    const plan = this.director.analyzePrompt('Detective in trench coat standing under lamp, 2 shots');
    const sequence = this.planner.planShots(plan);

    const shot2 = sequence.shots[1];
    if (!shot2.continuity.characterIdentityAnchor && !shot2.continuity.wardrobeDescription && !shot2.continuity.environmentAnchor) {
      throw new Error('Expected anchor attributes for continuity tracking');
    }
  }

  private async testRouterAutoModeSelection(): Promise<void> {
    const route = await this.router.evaluateRoute({
      requestedWorkflow: 'TEXT_TO_VIDEO',
      requestedMode: 'AUTO',
      resolution: { width: 1920, height: 1080 },
      fps: 24,
      durationSec: 4
    });

    if (!route.selectedEngineId || !route.selectedModelId) {
      throw new Error('Router failed to select engine and model in AUTO mode');
    }
    if (route.executionMode !== 'REAL_NEURAL' && route.executionMode !== 'LOCAL_DETERMINISTIC' && route.executionMode !== 'BROWSER_NATIVE_MEDIA') {
      throw new Error(`Unexpected executionMode: ${route.executionMode}`);
    }
  }

  private async testRouterNeuralUnreachableBlocks(): Promise<void> {
    // If comfyui is unreachable, requesting REAL_NEURAL should return REQUIRES_ENGINE or fallback
    const route = await this.router.evaluateRoute({
      requestedWorkflow: 'TEXT_TO_VIDEO',
      requestedMode: 'REAL_NEURAL',
      requestedEngineId: 'engine-comfyui-local',
      requestedModelId: 'flux-1-dev'
    });

    if (route.executionMode === 'REAL_NEURAL' && route.reachability === 'UNREACHABLE') {
      throw new Error('Router claimed REAL_NEURAL when engine is unreachable (Violation of Zero-Fabrication Law)');
    }
    if (route.reachability === 'UNREACHABLE' && route.routeState !== 'REQUIRES_ENGINE') {
      throw new Error(`Expected routeState REQUIRES_ENGINE when unreachable, got ${route.routeState}`);
    }
  }

  private async testRouterLocalDeterministicSelection(): Promise<void> {
    const route = await this.router.evaluateRoute({
      requestedWorkflow: 'TEXT_TO_VIDEO',
      requestedMode: 'LOCAL_DETERMINISTIC'
    });

    if (route.executionMode !== 'LOCAL_DETERMINISTIC') {
      throw new Error(`Expected LOCAL_DETERMINISTIC, got ${route.executionMode}`);
    }
    if (route.routeState !== 'LOCAL_DETERMINISTIC_AVAILABLE' && route.routeState !== 'BROWSER_NATIVE_AVAILABLE') {
      throw new Error(`Unexpected routeState: ${route.routeState}`);
    }
  }

  private async testRouterModelUnavailableDetection(): Promise<void> {
    const route = await this.router.evaluateRoute({
      requestedWorkflow: 'TEXT_TO_VIDEO',
      requestedMode: 'REAL_NEURAL',
      requestedModelId: 'non-existent-neural-model-xyz'
    });

    if (route.routeState !== 'MODEL_UNAVAILABLE' && route.routeState !== 'REQUIRES_ENGINE') {
      throw new Error(`Expected MODEL_UNAVAILABLE or REQUIRES_ENGINE for non-existent model, got ${route.routeState}`);
    }
  }

  private async testRouterZeroFabricationDisclaimers(): Promise<void> {
    const route = await this.router.evaluateRoute({
      requestedWorkflow: 'TEXT_TO_VIDEO',
      requestedMode: 'AUTO'
    });

    if (route.truthfulDisclaimers.length === 0) {
      throw new Error('Expected non-empty truthfulDisclaimers in route evaluation');
    }
  }

  private async testRouterResolutionCapabilityMatching(): Promise<void> {
    const route = await this.router.evaluateRoute({
      requestedWorkflow: 'TEXT_TO_VIDEO',
      requestedMode: 'AUTO',
      resolution: { width: 3840, height: 2160 },
      fps: 60,
      durationSec: 10
    });

    if (!route.devicePolicy) {
      throw new Error('Expected devicePolicy in route evaluation');
    }
  }

  private testDagCompilation(): void {
    const orchestrator = new AutonomousProductionDagOrchestrator();
    const plan = this.director.analyzePrompt('Cyberpunk city, 2 shots');
    const shotSequence = this.planner.planShots(plan);

    const tasks = orchestrator.compileDag(plan, shotSequence);
    const graph = orchestrator.getGraph();

    if (tasks.length === 0) {
      throw new Error('DAG compilation resulted in 0 tasks');
    }
    if (graph.entryTaskIds.length === 0) {
      throw new Error('DAG compilation has no entry task IDs');
    }
    if (!graph.terminalTaskId) {
      throw new Error('DAG compilation has no terminal task ID');
    }
  }

  private testDagDependencyOrdering(): void {
    const orchestrator = new AutonomousProductionDagOrchestrator();
    const plan = this.director.analyzePrompt('Cyberpunk city, 2 shots');
    const shotSequence = this.planner.planShots(plan);

    const tasks = orchestrator.compileDag(plan, shotSequence);
    const intentTask = tasks.find(t => t.role === 'DIRECTOR');
    const deliveryTask = tasks.find(t => t.role === 'DELIVERY_OFFICER');

    if (!intentTask || !deliveryTask) {
      throw new Error('Missing core DAG tasks');
    }
    if (intentTask.dependencyIds.length !== 0) {
      throw new Error('DIRECTOR task should have 0 dependencies');
    }
    if (deliveryTask.dependencyIds.length === 0) {
      throw new Error('DELIVERY_OFFICER task should depend on previous tasks');
    }
  }

  private async testDagTaskExecution(): Promise<void> {
    const orchestrator = new AutonomousProductionDagOrchestrator();
    const plan = this.director.analyzePrompt('Cyberpunk city, 1 shot');
    const shotSequence = this.planner.planShots(plan);

    orchestrator.compileDag(plan, shotSequence);
    const report = await orchestrator.executeDag();

    if (!report.isSuccess) {
      throw new Error(`DAG execution failed: ${report.criticalErrors.join(', ')}`);
    }
    if (report.completedTasks !== report.totalTasks) {
      throw new Error(`Expected all tasks completed, got ${report.completedTasks}/${report.totalTasks}`);
    }
  }

  private async testDagRetryPolicy(): Promise<void> {
    const orchestrator = new AutonomousProductionDagOrchestrator();
    const plan = this.director.analyzePrompt('Cyberpunk city, 1 shot');
    const shotSequence = this.planner.planShots(plan);

    orchestrator.compileDag(plan, shotSequence);
    const task = orchestrator.getTask('TASK_SHOT_01_GEN');

    if (!task) throw new Error('Task TASK_SHOT_01_GEN is not found in compiled DAG');
    task.maxRetries = 2;
    if (task.maxRetries !== 2) {
      throw new Error('Failed to configure retry policy');
    }
  }

  private async testDagReportGeneration(): Promise<void> {
    const orchestrator = new AutonomousProductionDagOrchestrator();
    const plan = this.director.analyzePrompt('Cyberpunk city, 1 shot');
    const shotSequence = this.planner.planShots(plan);

    orchestrator.compileDag(plan, shotSequence);
    await orchestrator.executeDag();
    const report = orchestrator.generateReport();

    if (!report.projectId) {
      throw new Error('Missing projectId in report');
    }
    if (report.tasks.length === 0) {
      throw new Error('Missing task summaries in report');
    }
  }

  private testFactoryCreateFromAutonomousPlan(): void {
    const plan = this.director.analyzePrompt('Cinematic dusk shot, 2 shots');
    const shotSequence = this.planner.planShots(plan);

    const project = ProductionProjectFactory.createFromAutonomousPlan(plan, shotSequence);

    if (!project.id || !project.title) {
      throw new Error('Factory produced invalid ProductionProject');
    }
    if (project.scenes.length === 0 || project.scenes[0].shots.length !== 2) {
      throw new Error(`Expected 2 shots in scene, got ${project.scenes[0]?.shots?.length}`);
    }
  }

  private async testControllerAutonomousPipeline(): Promise<void> {
    const prompt = 'Cinematic dusk shot of a neon spire in mist, 35mm lens, teal and orange grade, 2 shots';
    const result = await this.controller.executeAutonomousProduction(prompt, {
      executionMode: 'LOCAL_DETERMINISTIC'
    });

    if (!result.success) {
      throw new Error(`Autonomous production failed: ${result.error}`);
    }
    if (!result.autonomousPlan || !result.shotSequence || !result.dagReport) {
      throw new Error('Result missing autonomous metadata');
    }
    if (result.statusCode !== 'LOCAL_DETERMINISTIC_COMPLETED' && result.statusCode !== 'REAL_ENGINE_OUTPUT') {
      throw new Error(`Unexpected statusCode: ${result.statusCode}`);
    }
  }

  private async testControllerProofGeneration(): Promise<void> {
    const prompt = 'Anamorphic portrait of a stargazing pilot, 1 shot';
    const result = await this.controller.executeAutonomousProduction(prompt, {
      executionMode: 'LOCAL_DETERMINISTIC'
    });

    if (!result.proof) {
      throw new Error('Result missing execution proof');
    }
    if (!result.proof.proofId || !result.proof.timestamp) {
      throw new Error('Invalid execution proof structure');
    }
    if (result.proof.epistemicTruthClassification !== 'LOCAL_DETERMINISTIC' && result.proof.epistemicTruthClassification !== 'REAL_NEURAL_GENERATED') {
      throw new Error(`Unexpected epistemic classification: ${result.proof.epistemicTruthClassification}`);
    }
  }

  private async testControllerOfflineNeuralRejection(): Promise<void> {
    const prompt = 'Epic space battle, 1 shot';
    const result = await this.controller.executeAutonomousProduction(prompt, {
      executionMode: 'REAL_NEURAL',
      targetEngineId: 'engine-comfyui-local',
      selectedModelId: 'flux-1-dev'
    });

    // If ComfyUI is offline in this environment, it must truthfully reject with REQUIRES_ENGINE or MODEL_UNAVAILABLE
    // It must NOT fabricate synthetic frames as neural generation
    if (result.statusCode === 'REAL_ENGINE_OUTPUT') {
      const modeResult = await RealExecutionCapabilityVerifier.getInstance().verifyModeCapability('T2I', {
        requestedEngineId: 'engine-comfyui-local',
        requestedModelId: 'flux-1-dev'
      });
      if (modeResult.reachability !== 'REACHABLE') {
        throw new Error('Zero-fabrication violation: Claimed REAL_ENGINE_OUTPUT when ComfyUI is offline');
      }
    }
  }

  private async testControllerEpistemicPreservation(): Promise<void> {
    const prompt = 'Sunset mountain peak, 1 shot';
    const result = await this.controller.executeAutonomousProduction(prompt, {
      executionMode: 'LOCAL_DETERMINISTIC'
    });

    if (result.proof.epistemicTruthClassification === 'REAL_NEURAL_GENERATED') {
      throw new Error('Zero-fabrication violation: Classified LOCAL_DETERMINISTIC as REAL_NEURAL_GENERATED');
    }
  }
}
