/**
 * GODEX P5.0 — Production Graph / DAG Engine
 * 
 * Implements a deterministic production dependency graph:
 * SCRIPT → SCENE PLAN → SHOT PLAN → CAMERA SPEC → (GENERATION || VFX || AUDIO) →
 * TIMELINE ASSEMBLY → COLOR GRADING → FINISHING → FINAL RENDER → VALIDATION → QUALITY GATE → EXPORT
 * 
 * Supports parallel execution branches for independent stages and verifies prerequisite satisfaction.
 */

import {
  ProductionProject,
  ProductionGraph,
  ProductionNode,
  ProductionNodeType
} from './productionTypes';

export class ProductionGraphEngine {
  private static instance: ProductionGraphEngine | null = null;

  private constructor() {}

  public static getInstance(): ProductionGraphEngine {
    if (!ProductionGraphEngine.instance) {
      ProductionGraphEngine.instance = new ProductionGraphEngine();
    }
    return ProductionGraphEngine.instance;
  }

  /**
   * Compiles a deterministic production dependency DAG from a ProductionProject.
   */
  public compileGraph(project: ProductionProject): ProductionGraph {
    const nodes = new Map<string, ProductionNode>();

    // 1. Root: Project Init
    const initId = 'node_init';
    nodes.set(initId, {
      id: initId,
      type: 'PROJECT_INIT',
      name: `Initialize Project: ${project.title}`,
      dependencies: [],
      status: 'READY',
      progressPercent: 100
    });

    // 2. Script Parser / Narrative Structuring
    const scriptId = 'node_script';
    nodes.set(scriptId, {
      id: scriptId,
      type: 'SCRIPT_PARSER',
      name: 'Script & Narrative Structuring',
      dependencies: [initId],
      status: 'PENDING',
      progressPercent: 0
    });

    // 3. Scene Planning
    const sceneNodes: string[] = [];
    project.scenes.forEach((scene) => {
      const sceneNodeId = `node_scene_${scene.id}`;
      sceneNodes.push(sceneNodeId);
      nodes.set(sceneNodeId, {
        id: sceneNodeId,
        type: 'SCENE_PLANNER',
        name: `Scene ${scene.sceneNumber}: ${scene.name}`,
        dependencies: [scriptId],
        status: 'PENDING',
        sceneId: scene.id,
        progressPercent: 0
      });
    });

    // 4. Shot Planning & Camera Specifications per Scene
    const shotGenerationNodes: string[] = [];
    const vfxNodes: string[] = [];
    const audioNodes: string[] = [];

    project.scenes.forEach((scene) => {
      const sceneNodeId = `node_scene_${scene.id}`;

      scene.shots.forEach((shot) => {
        // Shot Planner Node
        const shotNodeId = `node_shot_${shot.id}`;
        nodes.set(shotNodeId, {
          id: shotNodeId,
          type: 'SHOT_PLANNER',
          name: `Shot ${scene.sceneNumber}.${shot.shotNumber}: ${shot.title}`,
          dependencies: [sceneNodeId],
          status: 'PENDING',
          sceneId: scene.id,
          shotId: shot.id,
          progressPercent: 0
        });

        // Camera Specifier Node
        const cameraNodeId = `node_camera_${shot.id}`;
        nodes.set(cameraNodeId, {
          id: cameraNodeId,
          type: 'CAMERA_SPECIFIER',
          name: `Camera Spec: ${shot.spec.cameraBody} (${shot.spec.focalLengthMm}mm T${shot.spec.apertureTStop})`,
          dependencies: [shotNodeId],
          status: 'PENDING',
          sceneId: scene.id,
          shotId: shot.id,
          progressPercent: 0
        });

        // Media Generation Node (Branch A)
        const genNodeId = `node_gen_${shot.id}`;
        shotGenerationNodes.push(genNodeId);
        nodes.set(genNodeId, {
          id: genNodeId,
          type: 'MEDIA_GENERATOR',
          name: `Generate Media: ${shot.spec.generationWorkflow}`,
          dependencies: [cameraNodeId],
          status: 'PENDING',
          sceneId: scene.id,
          shotId: shot.id,
          progressPercent: 0
        });

        // VFX Layer Node (Branch B - depends on generation or can run parallel template prep)
        const vfxNodeId = `node_vfx_${shot.id}`;
        vfxNodes.push(vfxNodeId);
        nodes.set(vfxNodeId, {
          id: vfxNodeId,
          type: 'VFX_COMPOSITOR',
          name: `VFX Composition: ${shot.spec.vfxRequirements.enabled ? (shot.spec.vfxRequirements.preset || 'ACTIVE') : 'PASSTHROUGH'}`,
          dependencies: [genNodeId],
          status: 'PENDING',
          sceneId: scene.id,
          shotId: shot.id,
          progressPercent: 0
        });

        // Audio Synthesis Node (Branch C - independent branch parallel to generation/vfx)
        const audioNodeId = `node_audio_${shot.id}`;
        audioNodes.push(audioNodeId);
        nodes.set(audioNodeId, {
          id: audioNodeId,
          type: 'AUDIO_SYNTHESIZER',
          name: `Audio & Foley: ${shot.spec.audioRequirements.sfx?.join(', ') || 'PROCEDURAL'}`,
          dependencies: [cameraNodeId], // Audio can start planning as soon as camera/timing is locked
          status: 'PENDING',
          sceneId: scene.id,
          shotId: shot.id,
          progressPercent: 0
        });
      });
    });

    // 5. Timeline Assembly (Convergence of VFX + Audio + Media across all shots)
    const assemblyDependencies = [...vfxNodes, ...audioNodes];
    if (assemblyDependencies.length === 0) {
      assemblyDependencies.push(scriptId);
    }

    const assemblyId = 'node_timeline_assembly';
    nodes.set(assemblyId, {
      id: assemblyId,
      type: 'TIMELINE_ASSEMBLER',
      name: 'Master Timeline Multi-Track Assembly (8 Tracks)',
      dependencies: assemblyDependencies,
      status: 'PENDING',
      progressPercent: 0
    });

    // 6. Color Grading
    const colorId = 'node_color_grading';
    nodes.set(colorId, {
      id: colorId,
      type: 'COLOR_GRADER',
      name: `Color Grading & Normalization (${project.colorFinishing.colorSpace})`,
      dependencies: [assemblyId],
      status: 'PENDING',
      progressPercent: 0
    });

    // 7. Cinematic Finishing
    const finishingId = 'node_cinematic_finishing';
    nodes.set(finishingId, {
      id: finishingId,
      type: 'CINEMATIC_FINISHER',
      name: '14-Stage Cinematic Optical Finishing & Grain',
      dependencies: [colorId],
      status: 'PENDING',
      progressPercent: 0
    });

    // 8. Final Render
    const renderId = 'node_final_render';
    nodes.set(renderId, {
      id: renderId,
      type: 'FINAL_RENDERER',
      name: `Final Render Orchestration (${project.renderSettings.targetResolution.width}x${project.renderSettings.targetResolution.height} @ ${project.renderSettings.targetFps}fps)`,
      dependencies: [finishingId],
      status: 'PENDING',
      progressPercent: 0
    });

    // 9. Output Validation
    const validationId = 'node_output_validation';
    nodes.set(validationId, {
      id: validationId,
      type: 'OUTPUT_VALIDATOR',
      name: 'Deterministic Output Validation & Container Inspection',
      dependencies: [renderId],
      status: 'PENDING',
      progressPercent: 0
    });

    // 10. Quality Gate (14-Factor Multi-Analyzer)
    const qualityGateId = 'node_quality_gate';
    nodes.set(qualityGateId, {
      id: qualityGateId,
      type: 'QUALITY_GATE',
      name: 'Production Quality Gate Verification',
      dependencies: [validationId],
      status: 'PENDING',
      progressPercent: 0
    });

    // 11. Media Export
    const exportId = 'node_media_export';
    nodes.set(exportId, {
      id: exportId,
      type: 'MEDIA_EXPORTER',
      name: `Media Export Governance (${project.exportSettings.containerFormat})`,
      dependencies: [qualityGateId],
      status: 'PENDING',
      progressPercent: 0
    });

    // Calculate topological order and parallel batches
    const { executionOrder, parallelBatches } = this.calculateTopologicalOrder(nodes);

    return {
      nodes,
      executionOrder,
      parallelBatches
    };
  }

  /**
   * Kahn's algorithm for topological sorting and grouping parallel layers.
   */
  private calculateTopologicalOrder(nodes: Map<string, ProductionNode>): {
    executionOrder: string[];
    parallelBatches: string[][];
  } {
    const inDegree = new Map<string, number>();
    const adjacency = new Map<string, string[]>();

    nodes.forEach((node, id) => {
      inDegree.set(id, node.dependencies.length);
      adjacency.set(id, []);
    });

    nodes.forEach((node, id) => {
      node.dependencies.forEach((dep) => {
        if (adjacency.has(dep)) {
          adjacency.get(dep)!.push(id);
        }
      });
    });

    const queue: string[] = [];
    inDegree.forEach((deg, id) => {
      if (deg === 0) {
        queue.push(id);
      }
    });

    const executionOrder: string[] = [];
    const parallelBatches: string[][] = [];

    let currentLevel = [...queue];

    while (currentLevel.length > 0) {
      parallelBatches.push(currentLevel);
      const nextLevel: string[] = [];

      for (const nodeId of currentLevel) {
        executionOrder.push(nodeId);
        const children = adjacency.get(nodeId) || [];

        for (const childId of children) {
          const currentDeg = inDegree.get(childId)! - 1;
          inDegree.set(childId, currentDeg);
          if (currentDeg === 0) {
            nextLevel.push(childId);
          }
        }
      }

      currentLevel = nextLevel;
    }

    if (executionOrder.length !== nodes.size) {
      throw new Error(`Cycle detected in production DAG. Resolved ${executionOrder.length}/${nodes.size} nodes.`);
    }

    return {
      executionOrder,
      parallelBatches
    };
  }

  /**
   * Returns the topological execution order of nodes in the graph.
   */
  public getTopologicalOrder(graph: ProductionGraph): string[] {
    return graph.executionOrder;
  }
}
