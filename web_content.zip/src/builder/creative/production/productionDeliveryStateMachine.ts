/**
 * GODEX P5.4 — Production Delivery State Machine
 * 
 * Enforces authoritative, deterministic lifecycle transitions for production delivery:
 * IDLE → PREFLIGHT → CAPABILITY_CHECK → READY → EXECUTING → RETRIEVING →
 * INGESTING → VALIDATING → POST_PROCESSING → ASSEMBLING → RENDERING →
 * QUALITY_GATE → DELIVERING → PLAYABLE → COMPLETED
 * 
 * Terminal / Failure States:
 * REQUIRES_ENGINE, MODEL_UNAVAILABLE, PREFLIGHT_FAILED, EXECUTION_FAILED,
 * OUTPUT_INVALID, QUALITY_GATE_FAILED, CANCELLED
 * 
 * Invariants:
 * 1. Zero illegal state skips: You cannot transition to PLAYABLE without VALIDATING.
 * 2. Strict terminal state handling: Failure states cannot transition forward without reset.
 * 3. Immutable audit history: Every transition records timestamp, trigger, and metadata.
 */

export type DeliveryState =
  | 'IDLE'
  | 'PREFLIGHT'
  | 'CAPABILITY_CHECK'
  | 'READY'
  | 'EXECUTING'
  | 'RETRIEVING'
  | 'INGESTING'
  | 'VALIDATING'
  | 'POST_PROCESSING'
  | 'ASSEMBLING'
  | 'RENDERING'
  | 'QUALITY_GATE'
  | 'DELIVERING'
  | 'PLAYABLE'
  | 'COMPLETED'
  // Terminal / Failure States
  | 'REQUIRES_ENGINE'
  | 'MODEL_UNAVAILABLE'
  | 'PREFLIGHT_FAILED'
  | 'EXECUTION_FAILED'
  | 'OUTPUT_INVALID'
  | 'QUALITY_GATE_FAILED'
  | 'CANCELLED';

export interface StateTransitionRecord {
  transitionId: string;
  fromState: DeliveryState;
  toState: DeliveryState;
  timestamp: number;
  reason?: string;
  metadata?: Record<string, any>;
}

export type DeliveryStateChangeListener = (
  currentState: DeliveryState,
  previousState: DeliveryState,
  record: StateTransitionRecord
) => void;

export class ProductionDeliveryStateMachine {
  private static instance: ProductionDeliveryStateMachine | null = null;
  private currentState: DeliveryState = 'IDLE';
  private transitionHistory: StateTransitionRecord[] = [];
  private listeners: Set<DeliveryStateChangeListener> = new Set();

  /**
   * Explicit adjacency list of legal forward, retry, and failure transitions.
   */
  private static readonly LEGAL_TRANSITIONS: Record<DeliveryState, DeliveryState[]> = {
    IDLE: ['PREFLIGHT', 'CAPABILITY_CHECK', 'READY', 'CANCELLED'],
    PREFLIGHT: ['CAPABILITY_CHECK', 'READY', 'PREFLIGHT_FAILED', 'REQUIRES_ENGINE', 'MODEL_UNAVAILABLE', 'CANCELLED'],
    CAPABILITY_CHECK: ['READY', 'REQUIRES_ENGINE', 'MODEL_UNAVAILABLE', 'PREFLIGHT_FAILED', 'CANCELLED'],
    READY: ['EXECUTING', 'PREFLIGHT', 'CANCELLED', 'IDLE'],
    EXECUTING: ['RETRIEVING', 'INGESTING', 'EXECUTION_FAILED', 'REQUIRES_ENGINE', 'MODEL_UNAVAILABLE', 'CANCELLED'],
    RETRIEVING: ['INGESTING', 'VALIDATING', 'EXECUTION_FAILED', 'CANCELLED'],
    INGESTING: ['VALIDATING', 'OUTPUT_INVALID', 'EXECUTION_FAILED', 'CANCELLED'],
    VALIDATING: ['POST_PROCESSING', 'ASSEMBLING', 'RENDERING', 'OUTPUT_INVALID', 'QUALITY_GATE_FAILED', 'CANCELLED'],
    POST_PROCESSING: ['ASSEMBLING', 'RENDERING', 'VALIDATING', 'EXECUTION_FAILED', 'CANCELLED'],
    ASSEMBLING: ['RENDERING', 'QUALITY_GATE', 'VALIDATING', 'EXECUTION_FAILED', 'CANCELLED'],
    RENDERING: ['QUALITY_GATE', 'VALIDATING', 'DELIVERING', 'EXECUTION_FAILED', 'CANCELLED'],
    QUALITY_GATE: ['DELIVERING', 'PLAYABLE', 'QUALITY_GATE_FAILED', 'OUTPUT_INVALID', 'CANCELLED'],
    DELIVERING: ['PLAYABLE', 'COMPLETED', 'OUTPUT_INVALID', 'CANCELLED'],
    PLAYABLE: ['COMPLETED', 'IDLE', 'READY', 'DELIVERING'],
    COMPLETED: ['IDLE', 'READY', 'PREFLIGHT'],
    
    // Terminal / Failure States (Can only transition to IDLE / READY upon user reset or retry)
    REQUIRES_ENGINE: ['IDLE', 'READY', 'PREFLIGHT'],
    MODEL_UNAVAILABLE: ['IDLE', 'READY', 'PREFLIGHT'],
    PREFLIGHT_FAILED: ['IDLE', 'READY', 'PREFLIGHT'],
    EXECUTION_FAILED: ['IDLE', 'READY', 'PREFLIGHT'],
    OUTPUT_INVALID: ['IDLE', 'READY', 'PREFLIGHT'],
    QUALITY_GATE_FAILED: ['IDLE', 'READY', 'PREFLIGHT'],
    CANCELLED: ['IDLE', 'READY', 'PREFLIGHT']
  };

  public static getInstance(): ProductionDeliveryStateMachine {
    if (!ProductionDeliveryStateMachine.instance) {
      ProductionDeliveryStateMachine.instance = new ProductionDeliveryStateMachine();
    }
    return ProductionDeliveryStateMachine.instance;
  }

  public getCurrentState(): DeliveryState {
    return this.currentState;
  }

  public getTransitionHistory(): ReadonlyArray<StateTransitionRecord> {
    return [...this.transitionHistory];
  }

  public isTerminal(): boolean {
    return [
      'COMPLETED',
      'REQUIRES_ENGINE',
      'MODEL_UNAVAILABLE',
      'PREFLIGHT_FAILED',
      'EXECUTION_FAILED',
      'OUTPUT_INVALID',
      'QUALITY_GATE_FAILED',
      'CANCELLED'
    ].includes(this.currentState);
  }

  public isFailure(): boolean {
    return [
      'REQUIRES_ENGINE',
      'MODEL_UNAVAILABLE',
      'PREFLIGHT_FAILED',
      'EXECUTION_FAILED',
      'OUTPUT_INVALID',
      'QUALITY_GATE_FAILED'
    ].includes(this.currentState);
  }

  /**
   * Validates whether a proposed transition is legal from the current state.
   */
  public canTransitionTo(targetState: DeliveryState): boolean {
    const allowed = ProductionDeliveryStateMachine.LEGAL_TRANSITIONS[this.currentState] || [];
    return allowed.includes(targetState);
  }

  /**
   * Alias for transitionTo.
   */
  public transition(targetState: DeliveryState, reason?: string, metadata?: Record<string, any>): StateTransitionRecord {
    return this.transitionTo(targetState, reason, metadata);
  }

  /**
   * Attempts to transition to a new delivery state.
   * Throws Error if the transition is illegal to maintain zero-fabrication invariants.
   */
  public transitionTo(targetState: DeliveryState, reason?: string, metadata?: Record<string, any>): StateTransitionRecord {
    if (this.currentState === targetState) {
      // No-op transition
      const noopRecord: StateTransitionRecord = {
        transitionId: `trans_${Date.now()}_noop`,
        fromState: this.currentState,
        toState: targetState,
        timestamp: Date.now(),
        reason: reason || 'State reaffirmed',
        metadata
      };
      return noopRecord;
    }

    if (!this.canTransitionTo(targetState)) {
      throw new Error(
        `[ProductionDeliveryStateMachine] Illegal delivery state transition from '${this.currentState}' to '${targetState}'. Reason: ${reason || 'Unspecified'}`
      );
    }

    const previousState = this.currentState;
    this.currentState = targetState;

    const record: StateTransitionRecord = {
      transitionId: `trans_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      fromState: previousState,
      toState: targetState,
      timestamp: Date.now(),
      reason,
      metadata
    };

    this.transitionHistory.push(record);

    // Notify listeners
    this.listeners.forEach(listener => {
      try {
        listener(this.currentState, previousState, record);
      } catch (err) {
        console.error('[ProductionDeliveryStateMachine] Error in state listener:', err);
      }
    });

    return record;
  }

  /**
   * Resets the delivery state machine back to IDLE.
   */
  public reset(reason = 'Manual reset'): void {
    const previousState = this.currentState;
    this.currentState = 'IDLE';
    const record: StateTransitionRecord = {
      transitionId: `trans_${Date.now()}_reset`,
      fromState: previousState,
      toState: 'IDLE',
      timestamp: Date.now(),
      reason
    };
    this.transitionHistory.push(record);
    this.listeners.forEach(listener => {
      try {
        listener('IDLE', previousState, record);
      } catch (err) {
        console.error('[ProductionDeliveryStateMachine] Error in reset listener:', err);
      }
    });
  }

  public subscribe(listener: DeliveryStateChangeListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
}
