/**
 * GODEX P5.11 — Local Hardware Capability Profile & Resource Guard
 * 
 * Authoritative target profile for local laptop execution:
 * - CPU: Intel Core i3-1215U (12th Gen, 6 cores [2P + 4E], 8 threads, up to 4.40 GHz, AVX2)
 * - RAM: 8 GB DDR4 3200 MHz (expandable to 16 GB)
 * - Storage: 512 GB SSD
 * - GPU: Intel integrated UHD Graphics (Vendor: Intel, Type: INTEGRATED, VRAM: 0 MB, CUDA: false, NVIDIA: false)
 * - Media Subsystem: Intel Quick Sync Video media acceleration
 * 
 * Safety & Resource Guard Invariants:
 * 1. Zero CUDA/NVIDIA Assumption: Never assumes discrete VRAM or CUDA compute.
 * 2. Bounded Concurrency: Max 1 heavy local job concurrently to avoid memory exhaustion.
 * 3. Epistemic Truth: Heavy neural video generation that requires large VRAM is truthfully
 *    classified as LOCAL_ENGINE_UNAVAILABLE / REQUIRES_ENGINE (never faked or silently substituted).
 * 4. Safe Resource Allocation: Protects the 8 GB RAM environment against memory runaway.
 */

import { HardwareAuditor } from '../hardwareAuditor';

export interface PhysicalRuntimeDetails {
  deviceCategory: 'MOBILE' | 'DESKTOP' | 'HEADLESS_SERVER';
  deviceModel: string;
  gpuModel: string;
  gpuVendor: string;
  isMobileDevice: boolean;
  isVivoDevice: boolean;
  cpuCores: number | 'UNKNOWN';
  systemRamGb: number | 'UNKNOWN';
  memoryArchitecture: 'UNIFIED_MEMORY_UMA' | 'DISCRETE_VRAM' | 'UNKNOWN';
}

export interface LocalHardwareProfile {
  profileId: 'LOCAL_INTEL_UHD_PROFILE';
  deviceName: string;
  targetProfileType?: 'TARGET_WORKSTATION_PROFILE';
  physicalRuntime?: PhysicalRuntimeDetails;
  cpu: {
    model: string;
    architecture: string;
    generation: string;
    cores: number;
    threads: number;
    maxClockGhz: number;
    avx2Supported: boolean;
  };
  ram: {
    installedGb: number;
    type: string;
    speedMhz: number;
    expandableMaxGb: number;
    safeAllocationLimitMb: number;
  };
  storage: {
    type: string;
    capacityGb: number;
  };
  gpu: {
    vendor: string;
    type: 'INTEGRATED';
    name: string;
    dedicatedVramMb: number;
    cudaSupported: boolean;
    nvidiaGpu: boolean;
    quickSyncVideoSupported: boolean;
  };
  runtimeCapabilities: {
    webGpuDetected: boolean;
    wasmSupported: boolean;
    wasmSimdSupported: boolean;
    hardwareConcurrency: number;
    quickSyncDetected: boolean;
  };
  resourceLimits: {
    maxConcurrentHeavyJobs: number;
    maxSafeFrameBufferSizeMb: number;
    maxSafeVideoDurationSec: number;
    recommendedMaxResolution: { width: number; height: number };
    maxFps: number;
  };
  activeEngines: {
    localCpu: boolean;
    localWebGpu: boolean;
    localMediaEngine: boolean;
    browserNative: boolean;
  };
  disabledEngines: string[];
}

export class LocalHardwareProfiler {
  private static instance: LocalHardwareProfiler | null = null;
  private cachedProfile: LocalHardwareProfile | null = null;

  public static getInstance(): LocalHardwareProfiler {
    if (!LocalHardwareProfiler.instance) {
      LocalHardwareProfiler.instance = new LocalHardwareProfiler();
    }
    return LocalHardwareProfiler.instance;
  }

  /**
   * Returns the authoritative local hardware profile with dynamic runtime checks.
   */
  public async getProfile(forceRefresh = false): Promise<LocalHardwareProfile> {
    if (this.cachedProfile && !forceRefresh) {
      return this.cachedProfile;
    }

    const isBrowser = typeof window !== 'undefined';
    const concurrency = isBrowser && typeof navigator !== 'undefined'
      ? (navigator.hardwareConcurrency || 8)
      : 8;

    // Detect WebGPU dynamically if in browser
    let webGpuDetected = false;
    if (isBrowser && typeof navigator !== 'undefined' && 'gpu' in navigator && (navigator as any).gpu) {
      try {
        const timeout = new Promise<null>(resolve => setTimeout(() => resolve(null), 300));
        const adapterPromise = (navigator as any).gpu.requestAdapter().catch(() => null);
        const adapter = await Promise.race([adapterPromise, timeout]);
        webGpuDetected = Boolean(adapter);
      } catch {
        webGpuDetected = false;
      }
    }

    // Detect WASM and SIMD dynamically
    const wasmSupported = typeof WebAssembly !== 'undefined';
    let wasmSimd = false;
    if (wasmSupported) {
      try {
        wasmSimd = WebAssembly.validate(new Uint8Array([
          0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
          0x01, 0x05, 0x01, 0x60, 0x00, 0x01, 0x7b,
          0x03, 0x02, 0x01, 0x00,
          0x0a, 0x0a, 0x01, 0x08, 0x00, 0xfd, 0x0c, 0x00, 0x00, 0x00, 0x00, 0x0b
        ]));
      } catch {
        wasmSimd = false;
      }
    }

    // Check media codec support (Intel Quick Sync compatible codecs)
    let quickSyncMedia = true;
    if (isBrowser && typeof MediaSource !== 'undefined') {
      quickSyncMedia = MediaSource.isTypeSupported('video/mp4; codecs="avc1.42E01E, mp4a.40.2"') ||
        MediaSource.isTypeSupported('video/webm; codecs="vp8, vorbis"');
    }

    const auditor = HardwareAuditor.getInstance();
    const hwReport = auditor.getCachedReport() || await auditor.auditHardware().catch(() => null);

    const physicalRuntime: PhysicalRuntimeDetails = {
      deviceCategory: hwReport?.isMobileDevice ? 'MOBILE' : (isBrowser ? 'DESKTOP' : 'HEADLESS_SERVER'),
      deviceModel: hwReport?.detectedHostDevice || (isBrowser ? 'Browser Client' : 'Headless Server / Container'),
      gpuModel: hwReport?.gpuModel || 'Generic Display Adapter',
      gpuVendor: hwReport?.gpuVendor || 'Generic Vendor',
      isMobileDevice: Boolean(hwReport?.isMobileDevice),
      isVivoDevice: Boolean(hwReport?.isVivoDevice),
      cpuCores: hwReport?.cpuCores ?? (isBrowser && typeof navigator !== 'undefined' ? (navigator.hardwareConcurrency || 'UNKNOWN') : 'UNKNOWN'),
      systemRamGb: hwReport?.systemMemoryGb ?? 'UNKNOWN',
      memoryArchitecture: hwReport?.memoryArchitecture || 'UNKNOWN'
    };

    this.cachedProfile = {
      profileId: 'LOCAL_INTEL_UHD_PROFILE',
      deviceName: 'Intel Core i3-1215U / Intel UHD Graphics Workstation',
      targetProfileType: 'TARGET_WORKSTATION_PROFILE',
      physicalRuntime,
      cpu: {
        model: 'Intel Core i3-1215U',
        architecture: 'x86_64 (Alder Lake-U)',
        generation: '12th Generation',
        cores: 6, // 2 Performance + 4 Efficient
        threads: 8,
        maxClockGhz: 4.40,
        avx2Supported: true
      },
      ram: {
        installedGb: 8,
        type: 'DDR4',
        speedMhz: 3200,
        expandableMaxGb: 16,
        safeAllocationLimitMb: 4096 // 50% limit to preserve OS and browser headroom
      },
      storage: {
        type: 'SSD',
        capacityGb: 512
      },
      gpu: {
        vendor: 'Intel',
        type: 'INTEGRATED',
        name: 'Intel UHD Graphics',
        dedicatedVramMb: 0,
        cudaSupported: false,
        nvidiaGpu: false,
        quickSyncVideoSupported: quickSyncMedia
      },
      runtimeCapabilities: {
        webGpuDetected,
        wasmSupported,
        wasmSimdSupported: wasmSimd,
        hardwareConcurrency: concurrency,
        quickSyncDetected: quickSyncMedia
      },
      resourceLimits: {
        maxConcurrentHeavyJobs: 1,
        maxSafeFrameBufferSizeMb: 512,
        maxSafeVideoDurationSec: 60,
        recommendedMaxResolution: { width: 1920, height: 1080 },
        maxFps: 30
      },
      activeEngines: {
        localCpu: true,
        localWebGpu: webGpuDetected,
        localMediaEngine: true,
        browserNative: true
      },
      disabledEngines: [
        'KAGGLE_GPU',
        'GOOGLE_COLAB_GPU',
        'HUGGINGFACE_ZEROGPU',
        'NVIDIA_CUDA_T4',
        'NVIDIA_CUDA_P100',
        'NVIDIA_CUDA_A100',
        'NVIDIA_CUDA_L4',
        'GEMINI_ACTIVE_DEPENDENCY'
      ]
    };

    return this.cachedProfile;
  }
}

/**
 * Resource Guard for bounded local memory and execution safety
 */
export class LocalResourceGuard {
  private static instance: LocalResourceGuard | null = null;
  private activeHeavyJobCount = 0;
  private maxConcurrentHeavyJobs = 1;
  private activeJobIds = new Set<string>();

  public static getInstance(): LocalResourceGuard {
    if (!LocalResourceGuard.instance) {
      LocalResourceGuard.instance = new LocalResourceGuard();
    }
    return LocalResourceGuard.instance;
  }

  /**
   * Evaluates if a media job can safely execute within local 8GB RAM / Intel UHD limits.
   */
  public evaluateLocalExecutionSafety(params: {
    workflow: string;
    durationSec?: number;
    resolution?: { width: number; height: number };
    fps?: number;
    isNeuralModel?: boolean;
  }): {
    safe: boolean;
    classification: 'SAFE_FOR_LOCAL_EXECUTION' | 'LOCAL_RESOURCE_LIMIT' | 'LOCAL_ENGINE_UNAVAILABLE' | 'REQUIRES_ENGINE';
    reason: string;
    truthfulGuidance: string;
  } {
    const { workflow, durationSec = 4, resolution = { width: 1280, height: 720 }, isNeuralModel = false } = params;

    // 1. Guard against heavy neural video generation models that require dedicated VRAM
    if (isNeuralModel || workflow === 'TEXT_TO_VIDEO' || workflow === 'IMAGE_TO_VIDEO') {
      return {
        safe: false,
        classification: 'LOCAL_ENGINE_UNAVAILABLE',
        reason: 'Large neural video diffusion models require dedicated high-VRAM discrete GPU (e.g. 16GB+ VRAM). The local Intel UHD Graphics integrated GPU is configured for deterministic media composition and hardware-accelerated transcoding only.',
        truthfulGuidance: 'To run neural video diffusion, connect an external compute endpoint or use deterministic canvas/DSP composition locally.'
      };
    }

    // 2. Check concurrency guard
    if (this.activeHeavyJobCount >= this.maxConcurrentHeavyJobs) {
      return {
        safe: false,
        classification: 'LOCAL_RESOURCE_LIMIT',
        reason: `Maximum concurrent local heavy jobs (${this.maxConcurrentHeavyJobs}) reached on 8GB RAM workstation. Job queued to protect system responsiveness.`,
        truthfulGuidance: 'Wait for current local media processing to finish before starting a new job.'
      };
    }

    // 3. Check extreme resolution limits (> 4K)
    if (resolution.width > 3840 || resolution.height > 2160) {
      return {
        safe: false,
        classification: 'LOCAL_RESOURCE_LIMIT',
        reason: `Requested resolution (${resolution.width}x${resolution.height}) exceeds safe 8GB RAM frame buffer limit. Recommended max resolution is 1080p.`,
        truthfulGuidance: 'Reduce output resolution to 1080p (1920x1080) or 720p (1280x720).'
      };
    }

    return {
      safe: true,
      classification: 'SAFE_FOR_LOCAL_EXECUTION',
      reason: 'Job parameters verified within Intel Core i3-1215U / 8GB RAM resource envelope.',
      truthfulGuidance: 'Local CPU + Intel UHD media acceleration active.'
    };
  }

  public acquireJobSlot(jobId: string): boolean {
    if (this.activeHeavyJobCount >= this.maxConcurrentHeavyJobs) {
      return false;
    }
    this.activeHeavyJobCount++;
    this.activeJobIds.add(jobId);
    return true;
  }

  public releaseJobSlot(jobId: string): void {
    if (this.activeJobIds.has(jobId)) {
      this.activeJobIds.delete(jobId);
      this.activeHeavyJobCount = Math.max(0, this.activeHeavyJobCount - 1);
    }
  }

  public getActiveJobCount(): number {
    return this.activeHeavyJobCount;
  }
}
