/**
 * GODEX P5.5 — Autonomous Engine & Model Router
 * 
 * Determines deterministic execution routes across 6 authoritative questions:
 * 1. Is the required capability available?
 * 2. Is the engine reachable?
 * 3. Is the model available?
 * 4. Is the workflow compatible?
 * 5. Is the device capable?
 * 6. Can the output be validated?
 * 
 * Evaluates route state:
 * - REAL_ENGINE_AVAILABLE
 * - BROWSER_NATIVE_AVAILABLE
 * - LOCAL_DETERMINISTIC_AVAILABLE
 * - REQUIRES_ENGINE
 * - MODEL_UNAVAILABLE
 * - PREFLIGHT_FAILED
 * - DEVICE_LIMITATION
 * 
 * Epistemic Law: Never silently substitute deterministic output for neural output without truthful classification.
 */

import { ComfyUiEngineAdapter } from '../comfyUiEngineAdapter';
import { RemoteNeuralVideoEngineAdapter } from '../remoteNeuralVideoAdapter';
import { GoogleColabGpuEngineAdapter } from '../googleColabEngineAdapter';
import { GoogleKaggleGpuEngineAdapter } from '../googleKaggleEngineAdapter';
import { ProductionRuntimeCapabilityEngine, ProductionRuntimeCapabilityMatrix } from './productionRuntimeCapabilityEngine';
import { MobileProductionGovernor, MobileGovernorPolicy } from './mobileProductionGovernor';
import { RealExecutionCapabilityVerifier } from './realExecutionCapabilityVerifier';
import { MediaWorkflowType } from '../creativeStudioTypes';

export type ProductionRouteState =
  | 'REAL_ENGINE_AVAILABLE'
  | 'BROWSER_NATIVE_AVAILABLE'
  | 'LOCAL_DETERMINISTIC_AVAILABLE'
  | 'REQUIRES_ENGINE'
  | 'MODEL_UNAVAILABLE'
  | 'PREFLIGHT_FAILED'
  | 'DEVICE_LIMITATION';

export interface RouteEvaluationRequest {
  requestedWorkflow: MediaWorkflowType;
  requestedMode?: 'AUTO' | 'REAL_NEURAL' | 'LOCAL_DETERMINISTIC' | 'BROWSER_NATIVE_MEDIA';
  requestedEngineId?: string;
  requestedModelId?: string;
  resolution?: { width: number; height: number };
  fps?: number;
  durationSec?: number;
}

export interface RouteEvaluationResult {
  routeState: ProductionRouteState;
  selectedEngineId: string;
  selectedModelId: string;
  executionMode: 'REAL_NEURAL' | 'LOCAL_DETERMINISTIC' | 'BROWSER_NATIVE_MEDIA';
  isNeuralReal: boolean;
  reachability: 'REACHABLE' | 'UNREACHABLE' | 'LOCAL_ONLY' | 'NOT_CONFIGURED';
  devicePolicy: MobileGovernorPolicy;
  justification: string;
  truthfulDisclaimers: string[];
  capabilitiesEvaluated: {
    capabilityAvailable: boolean;
    engineReachable: boolean;
    modelAvailable: boolean;
    workflowCompatible: boolean;
    deviceCapable: boolean;
    outputValidatable: boolean;
  };
}

export class AutonomousEngineModelRouter {
  private static instance: AutonomousEngineModelRouter | null = null;
  private comfyAdapter: ComfyUiEngineAdapter;
  private remoteNeuralAdapter: RemoteNeuralVideoEngineAdapter;
  private capabilityEngine: ProductionRuntimeCapabilityEngine;
  private mobileGovernor: MobileProductionGovernor;
  private capabilityVerifier: RealExecutionCapabilityVerifier;

  private constructor() {
    this.comfyAdapter = ComfyUiEngineAdapter.getInstance();
    this.remoteNeuralAdapter = RemoteNeuralVideoEngineAdapter.getInstance();
    this.capabilityEngine = ProductionRuntimeCapabilityEngine.getInstance();
    this.mobileGovernor = MobileProductionGovernor.getInstance();
    this.capabilityVerifier = RealExecutionCapabilityVerifier.getInstance();
  }

  public static getInstance(): AutonomousEngineModelRouter {
    if (!AutonomousEngineModelRouter.instance) {
      AutonomousEngineModelRouter.instance = new AutonomousEngineModelRouter();
    }
    return AutonomousEngineModelRouter.instance;
  }

  /**
   * Evaluates the routing decision deterministically with strict zero-fabrication guarantees.
   */
  public async evaluateRoute(request: RouteEvaluationRequest): Promise<RouteEvaluationResult> {
    const {
      requestedWorkflow,
      requestedMode = 'AUTO',
      requestedEngineId,
      requestedModelId,
      resolution = { width: 1920, height: 1080 },
      fps = 24,
      durationSec = 4
    } = request;

    // 1. Probe runtime hardware & Mobile Governor
    const runtimeMatrix = await this.capabilityEngine.probeCapabilities();
    const governorPolicy = this.mobileGovernor.resolvePolicy(runtimeMatrix);

    // 2. Check Device Capability constraints
    const memStatus = this.mobileGovernor.checkMemoryPressure(governorPolicy);
    const isDeviceCapable = memStatus.pressureLevel !== 'CRITICAL' &&
      resolution.width <= governorPolicy.maxResolution.width &&
      resolution.height <= governorPolicy.maxResolution.height &&
      fps <= governorPolicy.maxFps;

    if (!isDeviceCapable && memStatus.pressureLevel === 'CRITICAL') {
      return {
        routeState: 'DEVICE_LIMITATION',
        selectedEngineId: 'engine-browser-native',
        selectedModelId: 'deterministic-canvas-vfx',
        executionMode: 'LOCAL_DETERMINISTIC',
        isNeuralReal: false,
        reachability: 'LOCAL_ONLY',
        devicePolicy: governorPolicy,
        justification: `Device RAM memory pressure is CRITICAL (${memStatus.currentHeapMb}MB / ${memStatus.limitHeapMb}MB). Resource allocation gated.`,
        truthfulDisclaimers: ['Mobile Governor prevented device crash by applying hardware limitation gate.'],
        capabilitiesEvaluated: {
          capabilityAvailable: true,
          engineReachable: true,
          modelAvailable: true,
          workflowCompatible: true,
          deviceCapable: false,
          outputValidatable: true
        }
      };
    }

    // 3. Evaluate Target Engine & Reachability
    const isKaggleTarget = requestedEngineId === 'engine-kaggle-gpu' ||
      requestedEngineId === 'kaggle' ||
      requestedEngineId === 'KAGGLE_GPU' ||
      requestedEngineId === 'KAGGLE_ONLY' ||
      (requestedMode as string) === 'KAGGLE_ONLY';
    const isColabTarget = requestedEngineId === 'engine-google-colab-gpu' ||
      requestedEngineId === 'colab' ||
      requestedEngineId === 'GOOGLE_COLAB_GPU';
    const isComfyTarget = requestedEngineId === 'engine-comfyui' ||
      requestedEngineId === 'engine-comfyui-local';
    const isRemoteTarget = requestedEngineId === 'engine-remote-neural-free' ||
      requestedEngineId === 'engine-ltx-video' ||
      requestedEngineId === 'engine-wan2.1';
    const isNeuralRequested = requestedMode === 'REAL_NEURAL' ||
      (requestedMode as string) === 'KAGGLE_ONLY';

    let kaggleOnline = false;
    let kaggleDiscovery: any = null;
    let colabOnline = false;
    let colabDiscovery: any = null;
    let comfyOnline = false;
    let remoteOnline = false;
    let modelFound = false;
    let discoveredModelsList: string[] = [];

    // Explicit Kaggle Dedicated GPU Route (Only if explicitly targeted by user)
    if (isKaggleTarget) {
      try {
        kaggleDiscovery = await GoogleKaggleGpuEngineAdapter.getInstance().discover();
        kaggleOnline = kaggleDiscovery.available;
      } catch {
        kaggleOnline = false;
      }

      if (kaggleOnline) {
        return {
          routeState: 'REAL_ENGINE_AVAILABLE',
          selectedEngineId: 'engine-kaggle-gpu',
          selectedModelId: kaggleDiscovery?.modelName || 'damo-vilab/text-to-video-ms-1.7b',
          executionMode: 'REAL_NEURAL',
          isNeuralReal: true,
          reachability: 'REACHABLE',
          devicePolicy: governorPolicy,
          justification: `Kaggle dedicated GPU worker verified online (${kaggleDiscovery?.gpuName}, ${kaggleDiscovery?.gpuMemory}) with model '${kaggleDiscovery?.modelName}'.`,
          truthfulDisclaimers: ['Dedicated Kaggle GPU interactive worker active. Zero fallback to Hugging Face, Colab, or cached media.'],
          capabilitiesEvaluated: {
            capabilityAvailable: true,
            engineReachable: true,
            modelAvailable: true,
            workflowCompatible: true,
            deviceCapable: isDeviceCapable,
            outputValidatable: true
          }
        };
      } else {
        return {
          routeState: 'REQUIRES_ENGINE',
          selectedEngineId: 'engine-kaggle-gpu',
          selectedModelId: requestedModelId || 'damo-vilab/text-to-video-ms-1.7b',
          executionMode: 'REAL_NEURAL',
          isNeuralReal: true,
          reachability: 'UNREACHABLE',
          devicePolicy: governorPolicy,
          justification: 'Kaggle GPU worker is offline. Launch the worker notebook (godex_kaggle_gpu_worker.ipynb) in Kaggle Notebook environment to connect.',
          truthfulDisclaimers: [
            'Target compute engine is Kaggle Dedicated GPU.',
            'No active Kaggle worker heartbeat received within timeout threshold.',
            'Zero fallback to Hugging Face, Google Colab, or cached mock media.'
          ],
          capabilitiesEvaluated: {
            capabilityAvailable: false,
            engineReachable: false,
            modelAvailable: false,
            workflowCompatible: true,
            deviceCapable: isDeviceCapable,
            outputValidatable: true
          }
        };
      }
    }

    if (isColabTarget) {
      try {
        colabDiscovery = await GoogleColabGpuEngineAdapter.getInstance().discover();
        colabOnline = colabDiscovery.available;
      } catch {
        colabOnline = false;
      }

      if (colabOnline) {
        return {
          routeState: 'REAL_ENGINE_AVAILABLE',
          selectedEngineId: 'engine-google-colab-gpu',
          selectedModelId: colabDiscovery?.modelName || 'damo-vilab/text-to-video-ms-1.7b',
          executionMode: 'REAL_NEURAL',
          isNeuralReal: true,
          reachability: 'REACHABLE',
          devicePolicy: governorPolicy,
          justification: `Google Colab dedicated GPU worker verified online (${colabDiscovery?.gpuName}, ${colabDiscovery?.gpuMemory}) with model '${colabDiscovery?.modelName}'.`,
          truthfulDisclaimers: ['Dedicated Google Colab GPU interactive worker active. Zero external fallback.'],
          capabilitiesEvaluated: {
            capabilityAvailable: true,
            engineReachable: true,
            modelAvailable: true,
            workflowCompatible: true,
            deviceCapable: isDeviceCapable,
            outputValidatable: true
          }
        };
      } else {
        return {
          routeState: 'REQUIRES_ENGINE',
          selectedEngineId: 'engine-google-colab-gpu',
          selectedModelId: requestedModelId || 'colab-neural-video',
          executionMode: 'REAL_NEURAL',
          isNeuralReal: true,
          reachability: 'UNREACHABLE',
          devicePolicy: governorPolicy,
          justification: 'Google Colab GPU worker is offline. Launch the worker notebook in Google Colab to connect.',
          truthfulDisclaimers: [
            'Target engine is Google Colab GPU.',
            'No active worker heartbeat received within timeout threshold.',
            'Zero fallback to Hugging Face or cached mock data.'
          ],
          capabilitiesEvaluated: {
            capabilityAvailable: false,
            engineReachable: false,
            modelAvailable: false,
            workflowCompatible: true,
            deviceCapable: isDeviceCapable,
            outputValidatable: true
          }
        };
      }
    }

    if (isComfyTarget || (isNeuralRequested && !isRemoteTarget)) {
      try {
        const discovery = await this.comfyAdapter.discover();
        comfyOnline = discovery.available;
        if (comfyOnline) {
          const models = this.comfyAdapter.getDiscoveredModels();
          discoveredModelsList = [
            ...models.checkpoints,
            ...models.videoModels,
            ...models.upscalers,
            ...models.loras,
            ...models.controlnets
          ];
          if (requestedModelId) {
            modelFound = discoveredModelsList.some(m => m === requestedModelId || m.includes(requestedModelId));
          } else {
            modelFound = discoveredModelsList.length > 0;
          }
        }
      } catch {
        comfyOnline = false;
        modelFound = false;
      }
    }

    if (isRemoteTarget || (isNeuralRequested && !comfyOnline)) {
      try {
        const remoteDiscovery = await this.remoteNeuralAdapter.discover();
        remoteOnline = remoteDiscovery.available;
        const supportedRemoteModels = ['Lightricks/LTX-Video-Distilled', 'LTX-Video-Distilled', 'Wan-AI/Wan2.1-T2V-14B', 'Wan2.1', 'THUDM/CogVideoX-5B', 'CogVideoX-5B'];
        if (requestedModelId) {
          modelFound = supportedRemoteModels.some(m => m.toLowerCase().includes(requestedModelId.toLowerCase()) || requestedModelId.toLowerCase().includes(m.toLowerCase()));
        } else {
          modelFound = true;
        }
      } catch {
        remoteOnline = false;
        modelFound = false;
      }
    }

    // 4. Resolve Route Decision
    // Case 1: ComfyUI is online and verified
    if (comfyOnline && (requestedMode === 'REAL_NEURAL' || (requestedMode === 'AUTO' && modelFound))) {
      const activeModel = requestedModelId || (discoveredModelsList[0] || 'flux-1-dev');
      return {
        routeState: 'REAL_ENGINE_AVAILABLE',
        selectedEngineId: 'engine-comfyui-local',
        selectedModelId: activeModel,
        executionMode: 'REAL_NEURAL',
        isNeuralReal: true,
        reachability: 'REACHABLE',
        devicePolicy: governorPolicy,
        justification: `ComfyUI neural engine online at http://127.0.0.1:8188 with model '${activeModel}'.`,
        truthfulDisclaimers: ['Real neural engine route active.'],
        capabilitiesEvaluated: {
          capabilityAvailable: true,
          engineReachable: true,
          modelAvailable: true,
          workflowCompatible: true,
          deviceCapable: isDeviceCapable,
          outputValidatable: true
        }
      };
    }

    // Case 1b: User explicitly requested an unknown model on neural engine
    if (requestedMode === 'REAL_NEURAL' && requestedModelId && !modelFound) {
      return {
        routeState: 'MODEL_UNAVAILABLE',
        selectedEngineId: isRemoteTarget ? 'engine-remote-neural-free' : 'engine-comfyui-local',
        selectedModelId: requestedModelId,
        executionMode: 'LOCAL_DETERMINISTIC',
        isNeuralReal: false,
        reachability: remoteOnline || comfyOnline ? 'REACHABLE' : 'UNREACHABLE',
        devicePolicy: governorPolicy,
        justification: `Requested neural model '${requestedModelId}' is not available or recognized on active neural clusters.`,
        truthfulDisclaimers: [
          `Model '${requestedModelId}' unavailable on server.`,
          'Zero synthetic neural frames fabricated.'
        ],
        capabilitiesEvaluated: {
          capabilityAvailable: true,
          engineReachable: remoteOnline || comfyOnline,
          modelAvailable: false,
          workflowCompatible: true,
          deviceCapable: isDeviceCapable,
          outputValidatable: true
        }
      };
    }

    // Case 2: Remote ZeroGPU Neural Video Engine (LTX-Video Distilled) is online and verified
    if (remoteOnline && (requestedMode === 'REAL_NEURAL' || isRemoteTarget || (requestedMode === 'AUTO' && requestedWorkflow === 'TEXT_TO_VIDEO'))) {
      const activeModel = requestedModelId || 'Lightricks/LTX-Video-Distilled';
      return {
        routeState: 'REAL_ENGINE_AVAILABLE',
        selectedEngineId: 'engine-remote-neural-free',
        selectedModelId: activeModel,
        executionMode: 'REAL_NEURAL',
        isNeuralReal: true,
        reachability: 'REACHABLE',
        devicePolicy: governorPolicy,
        justification: `Remote ZeroGPU Neural Video Engine online with model '${activeModel}'.`,
        truthfulDisclaimers: [
          'Real neural video generation pipeline active.',
          'Zero synthetic frames fabricated. Outputs verified against ISO/IEC 14496-14 MP4 container specifications.'
        ],
        capabilitiesEvaluated: {
          capabilityAvailable: true,
          engineReachable: true,
          modelAvailable: true,
          workflowCompatible: true,
          deviceCapable: isDeviceCapable,
          outputValidatable: true
        }
      };
    }

    // Case 3: User explicitly requested REAL_NEURAL but all neural engines are unreachable
    if (requestedMode === 'REAL_NEURAL' && !comfyOnline && !remoteOnline) {
      return {
        routeState: 'REQUIRES_ENGINE',
        selectedEngineId: requestedEngineId || 'engine-remote-neural-free',
        selectedModelId: requestedModelId || 'LTX-Video-Distilled',
        executionMode: 'LOCAL_DETERMINISTIC',
        isNeuralReal: false,
        reachability: 'UNREACHABLE',
        devicePolicy: governorPolicy,
        justification: `Neural execution requested, but all neural endpoints are offline.`,
        truthfulDisclaimers: [
          'Neural engine offline. Zero synthetic neural frames will be fabricated.',
          'Start local ComfyUI server or ensure remote cluster connectivity.'
        ],
        capabilitiesEvaluated: {
          capabilityAvailable: true,
          engineReachable: false,
          modelAvailable: false,
          workflowCompatible: true,
          deviceCapable: isDeviceCapable,
          outputValidatable: true
        }
      };
    }

    // Case D: Browser Native Media synthesis
    if (requestedMode === 'BROWSER_NATIVE_MEDIA') {
      return {
        routeState: 'BROWSER_NATIVE_AVAILABLE',
        selectedEngineId: 'engine-browser-native',
        selectedModelId: 'browser-native-canvas-webaudio',
        executionMode: 'BROWSER_NATIVE_MEDIA',
        isNeuralReal: false,
        reachability: 'LOCAL_ONLY',
        devicePolicy: governorPolicy,
        justification: 'Browser-native WebCodecs/OffscreenCanvas/WebAudio media synthesis pipeline.',
        truthfulDisclaimers: ['Client-side native browser media pipeline. No external neural models invoked.'],
        capabilitiesEvaluated: {
          capabilityAvailable: true,
          engineReachable: true,
          modelAvailable: true,
          workflowCompatible: true,
          deviceCapable: isDeviceCapable,
          outputValidatable: true
        }
      };
    }

    // Case E: Local Deterministic / Standard Offline Safe Execution
    return {
      routeState: 'LOCAL_DETERMINISTIC_AVAILABLE',
      selectedEngineId: 'engine-browser-native',
      selectedModelId: 'deterministic-canvas-vfx',
      executionMode: 'LOCAL_DETERMINISTIC',
      isNeuralReal: false,
      reachability: 'LOCAL_ONLY',
      devicePolicy: governorPolicy,
      justification: 'Local deterministic 60fps canvas & DSP audio synthesis engine.',
      truthfulDisclaimers: [
        'Local deterministic generation mode active.',
        'Zero external GPU or paid cloud API calls required.'
      ],
      capabilitiesEvaluated: {
        capabilityAvailable: true,
        engineReachable: true,
        modelAvailable: true,
        workflowCompatible: true,
        deviceCapable: isDeviceCapable,
        outputValidatable: true
      }
    };
  }
}
