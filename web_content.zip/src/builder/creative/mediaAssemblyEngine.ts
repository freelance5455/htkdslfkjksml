/**
 * GODEX P4.5 — Production Media Assembly Engine
 * 
 * Unifies multi-track media streams:
 * VIDEO + VFX + SFX + FOLEY + DIALOGUE + AMBIENCE + MUSIC + OVERLAY
 * into a deterministic, frame-accurate render plan.
 */

import {
  AssemblyComposition,
  AssemblyTrack,
  AssemblyAsset,
  AssemblyTransition,
  RenderPlan,
  ResolvedAudioPassPlan,
  AssemblyTrackCategory,
  AssemblyTruthClassification
} from './mediaAssemblyTypes';
import { RenderTimelineEngine } from './renderTimelineEngine';

export class MediaAssemblyEngine {
  private static instance: MediaAssemblyEngine | null = null;
  private currentComposition: AssemblyComposition | null = null;

  public static getInstance(): MediaAssemblyEngine {
    if (!MediaAssemblyEngine.instance) {
      MediaAssemblyEngine.instance = new MediaAssemblyEngine();
    }
    return MediaAssemblyEngine.instance;
  }

  /**
   * Create a fresh multi-track production composition
   */
  public createComposition(
    name: string = 'GODEX Master Production Assembly',
    fps: 23.976 | 24 | 25 | 29.97 | 30 | 60 = 24,
    sampleRate: number = 44100,
    width: number = 1920,
    height: number = 1080,
    totalDurationSec: number = 5.0
  ): AssemblyComposition {
    const tracks: AssemblyTrack[] = [
      { id: 'track-video-main', name: 'Video 1 (Base Footage)', category: 'VIDEO', muted: false, solo: false, locked: false, gainDb: 0, pan: 0, order: 0, assets: [] },
      { id: 'track-vfx-composite', name: 'VFX 1 (Particles & Keys)', category: 'VFX', muted: false, solo: false, locked: false, gainDb: 0, pan: 0, order: 1, assets: [] },
      { id: 'track-overlay-graphics', name: 'Overlay 1 (Titles & Badges)', category: 'OVERLAY', muted: false, solo: false, locked: false, gainDb: 0, pan: 0, order: 2, assets: [] },
      { id: 'track-dialogue', name: 'Dialogue (Center / Voice)', category: 'DIALOGUE', muted: false, solo: false, locked: false, gainDb: 0, pan: 0, order: 3, assets: [] },
      { id: 'track-sfx', name: 'SFX (Hits & Risers)', category: 'SFX', muted: false, solo: false, locked: false, gainDb: 0, pan: 0, order: 4, assets: [] },
      { id: 'track-foley', name: 'Foley (Footsteps & Props)', category: 'FOLEY', muted: false, solo: false, locked: false, gainDb: 0, pan: 0, order: 5, assets: [] },
      { id: 'track-ambience', name: 'Ambience (Stereo Environment)', category: 'AMBIENCE', muted: false, solo: false, locked: false, gainDb: -4, pan: 0, order: 6, assets: [] },
      { id: 'track-music', name: 'Music Bed (Score)', category: 'MUSIC', muted: false, solo: false, locked: false, gainDb: -6, pan: 0, order: 7, assets: [] }
    ];

    const composition: AssemblyComposition = {
      id: `comp-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name,
      fps,
      sampleRate,
      width,
      height,
      totalDurationSec,
      tracks,
      transitions: [],
      colorGrade: {
        exposure: 0,
        contrast: 1.05,
        saturation: 1.1,
        vignette: 0.15,
        temperature: 0,
        tint: 0
      },
      masterGainDb: 0,
      masterLimiterCeilingDb: -0.5
    };

    this.currentComposition = composition;
    return composition;
  }

  /**
   * Get the active composition
   */
  public getCurrentComposition(): AssemblyComposition {
    if (!this.currentComposition) {
      return this.createComposition();
    }
    return this.currentComposition;
  }

  /**
   * Set the active composition
   */
  public setCurrentComposition(comp: AssemblyComposition): void {
    this.currentComposition = comp;
  }

  /**
   * Adds an asset to a designated track in the composition
   */
  public addAssetToTrack(
    composition: AssemblyComposition,
    trackId: string,
    asset: AssemblyAsset
  ): AssemblyComposition {
    const track = composition.tracks.find(t => t.id === trackId);
    if (!track) {
      throw new Error(`Track with ID '${trackId}' not found in composition.`);
    }

    // Ensure asset has correct trackId
    asset.trackId = trackId;
    track.assets.push(asset);

    // Auto-expand composition duration if asset extends beyond current duration
    const assetEnd = asset.startTimeSec + asset.durationSec;
    if (assetEnd > composition.totalDurationSec) {
      composition.totalDurationSec = Math.ceil(assetEnd);
    }

    return { ...composition };
  }

  /**
   * Resolves audio passes across all audio tracks
   */
  public resolveAudioPasses(composition: AssemblyComposition): ResolvedAudioPassPlan[] {
    const passes: ResolvedAudioPassPlan[] = [];
    const timelineEngine = RenderTimelineEngine.getInstance();
    const audioCategories: AssemblyTrackCategory[] = ['SFX', 'FOLEY', 'DIALOGUE', 'AMBIENCE', 'MUSIC'];

    for (const track of composition.tracks) {
      if (track.muted || !audioCategories.includes(track.category)) continue;

      for (const asset of track.assets) {
        if (!asset.enabled) continue;

        const startSample = timelineEngine.timestampToSample(asset.startTimeSec, composition.sampleRate);
        const sampleCount = timelineEngine.timestampToSample(asset.durationSec, composition.sampleRate);
        const trackLinearGain = Math.pow(10, track.gainDb / 20);
        const effectiveGain = asset.gain * trackLinearGain;

        passes.push({
          trackId: track.id,
          category: asset.category,
          startSample,
          sampleCount,
          gain: effectiveGain,
          pan: asset.pan ?? track.pan ?? 0,
          assetId: asset.assetId,
          audioConfig: asset.audioConfig
        });
      }
    }

    return passes;
  }

  /**
   * Compiles the complete deterministic Render Plan for video, VFX, and audio execution.
   */
  public compileRenderPlan(composition: AssemblyComposition): RenderPlan {
    const timelineEngine = RenderTimelineEngine.getInstance();
    const totalFrames = timelineEngine.calculateTotalFrames(composition.totalDurationSec, composition.fps);
    const totalAudioSamples = timelineEngine.timestampToSample(composition.totalDurationSec, composition.sampleRate);

    const resolvedFrames = [];
    for (let f = 0; f < totalFrames; f++) {
      resolvedFrames.push(timelineEngine.resolveFrameLayers(composition, f));
    }

    const resolvedAudioPasses = this.resolveAudioPasses(composition);

    // Calculate approximate RAM requirement:
    // RGBA frame (width * height * 4 bytes) * buffer pool (4 frames) + 32-bit Float stereo audio PCM
    const frameByteSize = composition.width * composition.height * 4;
    const audioByteSize = totalAudioSamples * 2 * 4; // Stereo Float32
    const totalBytes = (frameByteSize * 6) + audioByteSize;
    const estimatedMemoryMb = Math.round(totalBytes / (1024 * 1024));

    // Truth classification evaluation:
    // Browser-native Canvas 2D + Web Audio DSP = BROWSER_NATIVE
    let truthClassification: AssemblyTruthClassification = 'BROWSER_NATIVE';
    const hasNeuralAsset = composition.tracks.some(t => 
      t.assets.some(a => a.evidenceState === 'REQUIRES_REMOTE_ENGINE')
    );
    if (hasNeuralAsset) {
      truthClassification = 'REQUIRES_ENGINE';
    }

    return {
      planId: `plan-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      compositionId: composition.id,
      compositionName: composition.name,
      totalFrames,
      totalAudioSamples,
      frameRate: composition.fps,
      sampleRate: composition.sampleRate,
      dimensions: { width: composition.width, height: composition.height },
      totalDurationSec: composition.totalDurationSec,
      resolvedFrames,
      resolvedAudioPasses,
      estimatedMemoryMb,
      truthClassification,
      createdAt: Date.now()
    };
  }

  /**
   * Seeds a rich demonstration multi-track composition with sample media across all 7 layers.
   */
  public seedDemoProductionComposition(): AssemblyComposition {
    const comp = this.createComposition('Cinematic Nebula Odyssey', 24, 44100, 1920, 1080, 4.0);

    // 1. Base Video Clip (Deep space nebula timelapse)
    this.addAssetToTrack(comp, 'track-video-main', {
      assetId: 'asset-video-nebula',
      name: 'Deep Space Nebula 4K Plate',
      sourceRef: 'procedural:space-nebula-timelapse',
      category: 'VIDEO',
      startTimeSec: 0,
      durationSec: 4.0,
      gain: 0,
      transform: { x: 0, y: 0, scaleX: 1.0, scaleY: 1.0, rotationDeg: 0 },
      opacity: 1.0,
      enabled: true,
      trackId: 'track-video-main',
      evidenceState: 'SYNTHESIZED_CANVAS_PROCEDURAL'
    });

    // 2. VFX Particle Layer (Stardust emitter & lens flare)
    this.addAssetToTrack(comp, 'track-vfx-composite', {
      assetId: 'asset-vfx-stardust',
      name: 'Anamorphic Stardust Emitter',
      sourceRef: 'vfx:particle-system-stardust',
      category: 'VFX',
      startTimeSec: 0.5,
      durationSec: 3.5,
      gain: 0,
      transform: { x: 0, y: 0, scaleX: 1.0, scaleY: 1.0, rotationDeg: 0 },
      opacity: 0.85,
      blendMode: 'screen',
      enabled: true,
      trackId: 'track-vfx-composite',
      vfxConfig: {
        particleSystemId: 'emitter-cosmic-sparkle',
        keyingTolerance: 0.2
      },
      evidenceState: 'SYNTHESIZED_CANVAS_PROCEDURAL'
    });

    // 3. Overlay Title Graphic
    this.addAssetToTrack(comp, 'track-overlay-graphics', {
      assetId: 'asset-overlay-badge',
      name: 'Cinematic HUD Title Card',
      sourceRef: 'overlay:hud-title-badge',
      category: 'OVERLAY',
      startTimeSec: 0.8,
      durationSec: 2.5,
      gain: 0,
      transform: { x: 0, y: -40, scaleX: 1.0, scaleY: 1.0, rotationDeg: 0 },
      opacity: 0.95,
      blendMode: 'normal',
      enabled: true,
      trackId: 'track-overlay-graphics',
      evidenceState: 'SYNTHESIZED_CANVAS_PROCEDURAL'
    });

    // 4. SFX Sub-Bass Boom & Impact
    this.addAssetToTrack(comp, 'track-sfx', {
      assetId: 'asset-sfx-sub-impact',
      name: 'Sub-Bass Quantum Impact',
      sourceRef: 'sfx:procedural-impact',
      category: 'SFX',
      startTimeSec: 0.8,
      durationSec: 2.0,
      gain: 0.95,
      pan: 0,
      transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotationDeg: 0 },
      opacity: 1,
      enabled: true,
      trackId: 'track-sfx',
      audioConfig: {
        sfxCategory: 'IMPACT',
        pitchHz: 65,
        reverbMix: 0.35,
        eqLowGainDb: 3
      },
      evidenceState: 'SYNTHESIZED_LOCAL_DSP'
    });

    // 5. Foley UI Click & Warp Trigger
    this.addAssetToTrack(comp, 'track-foley', {
      assetId: 'asset-foley-click',
      name: 'Holographic Interface Actuation',
      sourceRef: 'foley:ui-actuate',
      category: 'FOLEY',
      startTimeSec: 0.85,
      durationSec: 0.4,
      gain: 0.7,
      pan: 0.2,
      transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotationDeg: 0 },
      opacity: 1,
      enabled: true,
      trackId: 'track-foley',
      audioConfig: {
        sfxCategory: 'UI_SOUND',
        pitchHz: 1200
      },
      evidenceState: 'SYNTHESIZED_LOCAL_DSP'
    });

    // 6. Dialogue AI Voice Callout
    this.addAssetToTrack(comp, 'track-dialogue', {
      assetId: 'asset-dialogue-prompt',
      name: 'Commander Dispatch Vocal',
      sourceRef: 'dialogue:synth-vocal',
      category: 'DIALOGUE',
      startTimeSec: 1.2,
      durationSec: 2.2,
      gain: 1.0,
      pan: 0,
      transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotationDeg: 0 },
      opacity: 1,
      enabled: true,
      trackId: 'track-dialogue',
      audioConfig: {
        sfxCategory: 'TONE_BURST',
        pitchHz: 220,
        compressorThresholdDb: -14
      },
      evidenceState: 'SYNTHESIZED_LOCAL_DSP'
    });

    // 7. Ambience Deep Drone Bed
    this.addAssetToTrack(comp, 'track-ambience', {
      assetId: 'asset-ambience-space',
      name: 'Cosmic Resonance Room Tone',
      sourceRef: 'ambience:deep-space',
      category: 'AMBIENCE',
      startTimeSec: 0,
      durationSec: 4.0,
      gain: 0.6,
      pan: 0,
      transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotationDeg: 0 },
      opacity: 1,
      enabled: true,
      trackId: 'track-ambience',
      audioConfig: {
        sfxCategory: 'WHOOSH',
        pitchHz: 80,
        reverbMix: 0.5
      },
      evidenceState: 'SYNTHESIZED_LOCAL_DSP'
    });

    // 8. Music Bed Orchestral Score
    this.addAssetToTrack(comp, 'track-music', {
      assetId: 'asset-music-synthwave',
      name: 'Harmonic Synthwave Soundtrack',
      sourceRef: 'music:harmonic-synth',
      category: 'MUSIC',
      startTimeSec: 0,
      durationSec: 4.0,
      gain: 0.5,
      pan: 0,
      transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotationDeg: 0 },
      opacity: 1,
      enabled: true,
      trackId: 'track-music',
      audioConfig: {
        sfxCategory: 'TONE_BURST',
        pitchHz: 440,
        delayMix: 0.25
      },
      evidenceState: 'SYNTHESIZED_LOCAL_DSP'
    });

    this.currentComposition = comp;
    return comp;
  }
}
