/**
 * GODEX P4.9 — Cinematic Curves Engine
 * 
 * High-precision tone and color curve manipulation:
 * - Master RGB curve
 * - Individual Red, Green, Blue channel curves
 * - Luma curve (luminance-weighted tone control)
 * - Fritsch-Carlson Monotone Cubic Spline Interpolation (guarantees monotonicity without overshoot)
 * - Sub-millisecond 256-entry 1D LUT evaluation cache
 * - Real-time 256-bin histogram computation (Luma, R, G, B)
 */

import { CurvePoint, CurvesData } from './colorTypes';

export class CurvesEngine {
  private static instance: CurvesEngine | null = null;

  public static getInstance(): CurvesEngine {
    if (!CurvesEngine.instance) {
      CurvesEngine.instance = new CurvesEngine();
    }
    return CurvesEngine.instance;
  }

  /**
   * Returns default linear curves.
   */
  public static getDefaultCurves(): CurvesData {
    return {
      master: [{ x: 0, y: 0 }, { x: 1, y: 1 }],
      red: [{ x: 0, y: 0 }, { x: 1, y: 1 }],
      green: [{ x: 0, y: 0 }, { x: 1, y: 1 }],
      blue: [{ x: 0, y: 0 }, { x: 1, y: 1 }],
      luma: [{ x: 0, y: 0 }, { x: 1, y: 1 }]
    };
  }

  // =========================================================================
  // 1. MONOTONE CUBIC SPLINE INTERPOLATION (FRITSCH-CARLSON)
  // =========================================================================

  /**
   * Evaluates a curve given an array of control points at normalized input x [0, 1].
   */
  public evaluateCurve(points: CurvePoint[], x: number): number {
    const clampedX = Math.max(0, Math.min(1, x));

    if (!points || points.length === 0) return clampedX;
    if (points.length === 1) return Math.max(0, Math.min(1, points[0].y));

    // Ensure points are sorted by X
    const sorted = [...points].sort((a, b) => a.x - b.x);

    // Boundary conditions
    if (clampedX <= sorted[0].x) return Math.max(0, Math.min(1, sorted[0].y));
    if (clampedX >= sorted[sorted.length - 1].x) {
      return Math.max(0, Math.min(1, sorted[sorted.length - 1].y));
    }

    // Linear interpolation for 2 points
    if (sorted.length === 2) {
      const p0 = sorted[0];
      const p1 = sorted[1];
      const t = (clampedX - p0.x) / (p1.x - p0.x || 0.0001);
      return Math.max(0, Math.min(1, p0.y + t * (p1.y - p0.y)));
    }

    // Monotone cubic spline for 3+ points
    const n = sorted.length;
    const xs = sorted.map(p => p.x);
    const ys = sorted.map(p => p.y);

    // Calculate secants
    const dxs: number[] = [];
    const dys: number[] = [];
    const slopes: number[] = [];
    for (let i = 0; i < n - 1; i++) {
      const dx = xs[i + 1] - xs[i] || 0.0001;
      const dy = ys[i + 1] - ys[i];
      dxs.push(dx);
      dys.push(dy);
      slopes.push(dy / dx);
    }

    // Calculate tangents (m)
    const m: number[] = new Array(n).fill(0);
    m[0] = slopes[0];
    m[n - 1] = slopes[n - 2];
    for (let i = 1; i < n - 1; i++) {
      if (slopes[i - 1] * slopes[i] <= 0) {
        m[i] = 0;
      } else {
        m[i] = (slopes[i - 1] + slopes[i]) / 2;
      }
    }

    // Fritsch-Carlson monotonicity condition
    for (let i = 0; i < n - 1; i++) {
      if (Math.abs(dys[i]) < 1e-9) {
        m[i] = 0;
        m[i + 1] = 0;
      } else {
        const alpha = m[i] / slopes[i];
        const beta = m[i + 1] / slopes[i];
        const dist = alpha * alpha + beta * beta;
        if (dist > 9) {
          const tau = 3 / Math.sqrt(dist);
          m[i] = tau * alpha * slopes[i];
          m[i + 1] = tau * beta * slopes[i];
        }
      }
    }

    // Find the bounding segment
    let k = 0;
    for (let i = 0; i < n - 1; i++) {
      if (clampedX >= xs[i] && clampedX <= xs[i + 1]) {
        k = i;
        break;
      }
    }

    // Cubic Hermite basis functions
    const h = dxs[k];
    const t = (clampedX - xs[k]) / h;
    const t2 = t * t;
    const t3 = t2 * t;

    const h00 = 2 * t3 - 3 * t2 + 1;
    const h10 = t3 - 2 * t2 + t;
    const h01 = -2 * t3 + 3 * t2;
    const h11 = t3 - t2;

    const y = h00 * ys[k] + h10 * h * m[k] + h01 * ys[k + 1] + h11 * h * m[k + 1];
    return Math.max(0, Math.min(1, y));
  }

  // =========================================================================
  // 2. FAST 256-ENTRY 1D LOOKUP TABLE (LUT) GENERATION
  // =========================================================================

  /**
   * Generates a 256-entry lookup table [0..255] for ultra-fast per-pixel application.
   */
  public generate1DLut(points: CurvePoint[]): Float32Array {
    const lut = new Float32Array(256);
    for (let i = 0; i < 256; i++) {
      const normalizedInput = i / 255.0;
      lut[i] = this.evaluateCurve(points, normalizedInput);
    }
    return lut;
  }

  /**
   * Generates combined channel LUTs for Master, R, G, B, and Luma.
   */
  public generateCombinedLuts(curves: CurvesData): {
    master: Float32Array;
    red: Float32Array;
    green: Float32Array;
    blue: Float32Array;
    luma: Float32Array;
  } {
    return {
      master: this.generate1DLut(curves.master),
      red: this.generate1DLut(curves.red),
      green: this.generate1DLut(curves.green),
      blue: this.generate1DLut(curves.blue),
      luma: this.generate1DLut(curves.luma)
    };
  }

  // =========================================================================
  // 3. HISTOGRAM ANALYSIS
  // =========================================================================

  /**
   * Computes a 256-bin histogram for Luma, R, G, and B from pixel byte buffer.
   */
  public computeHistogram(
    rgbaData: Uint8ClampedArray | Uint8Array,
    stride: number = 4
  ): {
    luma: number[];
    red: number[];
    green: number[];
    blue: number[];
    totalSamples: number;
  } {
    const lumaBins = new Array(256).fill(0);
    const redBins = new Array(256).fill(0);
    const greenBins = new Array(256).fill(0);
    const blueBins = new Array(256).fill(0);

    const step = Math.max(4, stride * 4);
    let sampleCount = 0;

    for (let i = 0; i < rgbaData.length; i += step) {
      const r = rgbaData[i];
      const g = rgbaData[i + 1];
      const b = rgbaData[i + 2];

      // ITU-R BT.709 relative luma in 0..255
      const y = Math.round(0.2126 * r + 0.7152 * g + 0.0722 * b);
      const clampedY = Math.max(0, Math.min(255, y));

      redBins[r]++;
      greenBins[g]++;
      blueBins[b]++;
      lumaBins[clampedY]++;
      sampleCount++;
    }

    return {
      luma: lumaBins,
      red: redBins,
      green: greenBins,
      blue: blueBins,
      totalSamples: sampleCount
    };
  }
}
