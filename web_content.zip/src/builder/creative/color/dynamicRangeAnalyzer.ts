/**
 * GODEX P4.9 — Dynamic Range & HDR Luminance Analyzer
 * 
 * Objective mathematical image signal & dynamic range analysis:
 * - Minimum, maximum, mean, median luminance
 * - Percentiles: p1, p5, p50, p95, p99
 * - Highlight clipping percentage (>98% / 250)
 * - Shadow crushing percentage (<2% / 5)
 * - Scene dynamic range estimation in stops (EV)
 * - RMS contrast & luminance variance
 * - Vectorscope skin-tone line (I-axis) detection and stability scoring
 * - Frame-to-frame color drift measurement (Delta E & Luma drift)
 */

import { DynamicRangeMetrics, ColorQualityDossier } from './colorTypes';
import { CurvesEngine } from './curvesEngine';

export class DynamicRangeAnalyzer {
  private static instance: DynamicRangeAnalyzer | null = null;

  public static getInstance(): DynamicRangeAnalyzer {
    if (!DynamicRangeAnalyzer.instance) {
      DynamicRangeAnalyzer.instance = new DynamicRangeAnalyzer();
    }
    return DynamicRangeAnalyzer.instance;
  }

  /**
   * Analyzes an image byte buffer (RGBA) and computes comprehensive dynamic range metrics.
   */
  public analyzeDynamicRange(
    rgbaData: Uint8ClampedArray | Uint8Array,
    sampleStride: number = 4
  ): DynamicRangeMetrics {
    const curvesEngine = CurvesEngine.getInstance();
    const hist = curvesEngine.computeHistogram(rgbaData, sampleStride);
    const totalSamples = hist.totalSamples || 1;

    let minLuma = 1.0;
    let maxLuma = 0.0;
    let sumLuma = 0;
    let sumLumaSq = 0;
    let highlightClipCount = 0;
    let shadowCrushCount = 0;
    let skinTonePixelCount = 0;
    let skinToneHueSum = 0;

    // Collect sampled luminance values for percentile extraction
    const lumaSamples: number[] = [];
    const step = Math.max(4, sampleStride * 4);

    for (let i = 0; i < rgbaData.length; i += step) {
      const r = rgbaData[i];
      const g = rgbaData[i + 1];
      const b = rgbaData[i + 2];

      const normR = r / 255.0;
      const normG = g / 255.0;
      const normB = b / 255.0;

      // Rec.709 relative luma [0, 1]
      const luma = 0.2126 * normR + 0.7152 * normG + 0.0722 * normB;

      if (luma < minLuma) minLuma = luma;
      if (luma > maxLuma) maxLuma = luma;

      sumLuma += luma;
      sumLumaSq += luma * luma;

      if (normR >= 0.98 || normG >= 0.98 || normB >= 0.98 || luma >= 0.98) {
        highlightClipCount++;
      }
      if (normR <= 0.02 && normG <= 0.02 && normB <= 0.02) {
        shadowCrushCount++;
      }

      // Skin Tone Vectorscope Check (YCbCr I-line axis)
      // Standard skin-tone region: Cb in [-40, -5], Cr in [10, 45] relative to 128
      const cb = -0.1687 * r - 0.3313 * g + 0.500 * b;
      const cr = 0.500 * r - 0.4187 * g - 0.0813 * b;
      const hueAngleDeg = ((Math.atan2(cr, cb) * 180) / Math.PI + 360) % 360;

      // Vectorscope skin-line is centered around 105° - 135° (with Cr > 0 and Cb < 0)
      if (hueAngleDeg >= 105 && hueAngleDeg <= 140 && luma >= 0.15 && luma <= 0.85) {
        skinTonePixelCount++;
        skinToneHueSum += hueAngleDeg;
      }

      lumaSamples.push(luma);
    }

    // Sort sampled luminance to calculate exact percentiles
    lumaSamples.sort((a, b) => a - b);
    const n = lumaSamples.length || 1;

    const p1Luma = lumaSamples[Math.floor(0.01 * (n - 1))] ?? 0;
    const p5Luma = lumaSamples[Math.floor(0.05 * (n - 1))] ?? 0;
    const medianLuma = lumaSamples[Math.floor(0.50 * (n - 1))] ?? 0;
    const p95Luma = lumaSamples[Math.floor(0.95 * (n - 1))] ?? 1;
    const p99Luma = lumaSamples[Math.floor(0.99 * (n - 1))] ?? 1;

    const meanLuma = sumLuma / n;
    const variance = Math.max(0, sumLumaSq / n - meanLuma * meanLuma);
    const rmsContrast = Math.sqrt(variance);

    // Dynamic Range calculation in EV stops: log2(L_max / max(0.001, L_min))
    const effectiveMin = Math.max(0.002, p1Luma > 0.001 ? p1Luma : minLuma);
    const effectiveMax = Math.min(1.0, Math.max(effectiveMin * 1.5, p99Luma));
    const dynamicRangeStops = parseFloat((Math.log2(effectiveMax / effectiveMin)).toFixed(2));

    const highlightClippingPercent = parseFloat(((highlightClipCount / n) * 100).toFixed(2));
    const shadowCrushPercent = parseFloat(((shadowCrushCount / n) * 100).toFixed(2));

    // Skin Tone Stability Score: high if skin pixels fall cleanly on the vector axis
    let skinToneStabilityScore = 90;
    if (skinTonePixelCount > 50) {
      const avgHue = skinToneHueSum / skinTonePixelCount;
      const hueDeviation = Math.abs(avgHue - 120); // 120° is nominal center
      skinToneStabilityScore = Math.max(20, Math.min(100, Math.round(100 - hueDeviation * 2.5)));
    }

    return {
      minLuma: parseFloat(minLuma.toFixed(4)),
      maxLuma: parseFloat(maxLuma.toFixed(4)),
      meanLuma: parseFloat(meanLuma.toFixed(4)),
      medianLuma: parseFloat(medianLuma.toFixed(4)),
      p1Luma: parseFloat(p1Luma.toFixed(4)),
      p5Luma: parseFloat(p5Luma.toFixed(4)),
      p95Luma: parseFloat(p95Luma.toFixed(4)),
      p99Luma: parseFloat(p99Luma.toFixed(4)),
      dynamicRangeStops: Math.min(16, Math.max(1, dynamicRangeStops)),
      highlightClippingPercent,
      shadowCrushPercent,
      rmsContrast: parseFloat(rmsContrast.toFixed(4)),
      skinTonePixelCount,
      skinToneStabilityScore,
      histogram: {
        luma: hist.luma,
        red: hist.red,
        green: hist.green,
        blue: hist.blue,
        totalSamples: hist.totalSamples
      }
    };
  }

  /**
   * Compares two frames to measure frame-to-frame luminance and color drift.
   */
  public measureFrameColorDrift(
    frameA: Uint8ClampedArray | Uint8Array,
    frameB: Uint8ClampedArray | Uint8Array,
    stride: number = 16
  ): {
    meanDeltaE: number;
    lumaDriftPercent: number;
    driftSeverity: 'NEGLIGIBLE' | 'ACCEPTABLE' | 'NOTICEABLE' | 'SEVERE';
  } {
    const minLen = Math.min(frameA.length, frameB.length);
    const step = Math.max(4, stride * 4);
    let totalDelta = 0;
    let totalLumaDiff = 0;
    let samples = 0;

    for (let i = 0; i < minLen; i += step) {
      const rA = frameA[i] / 255.0;
      const gA = frameA[i + 1] / 255.0;
      const bA = frameA[i + 2] / 255.0;

      const rB = frameB[i] / 255.0;
      const gB = frameB[i + 1] / 255.0;
      const bB = frameB[i + 2] / 255.0;

      const lumaA = 0.2126 * rA + 0.7152 * gA + 0.0722 * bA;
      const lumaB = 0.2126 * rB + 0.7152 * gB + 0.0722 * bB;

      const colorDist = Math.sqrt(
        Math.pow(rA - rB, 2) + Math.pow(gA - gB, 2) + Math.pow(bA - bB, 2)
      );

      totalDelta += colorDist;
      totalLumaDiff += Math.abs(lumaA - lumaB);
      samples++;
    }

    const avgDist = samples > 0 ? (totalDelta / samples) * 100 : 0;
    const lumaDrift = samples > 0 ? (totalLumaDiff / samples) * 100 : 0;

    let severity: 'NEGLIGIBLE' | 'ACCEPTABLE' | 'NOTICEABLE' | 'SEVERE' = 'NEGLIGIBLE';
    if (avgDist > 25 || lumaDrift > 20) severity = 'SEVERE';
    else if (avgDist > 12 || lumaDrift > 10) severity = 'NOTICEABLE';
    else if (avgDist > 5 || lumaDrift > 4) severity = 'ACCEPTABLE';

    return {
      meanDeltaE: parseFloat(avgDist.toFixed(2)),
      lumaDriftPercent: parseFloat(lumaDrift.toFixed(2)),
      driftSeverity: severity
    };
  }
}
