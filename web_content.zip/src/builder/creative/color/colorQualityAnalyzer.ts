/**
 * GODEX P4.9 — Color Quality Analyzer
 * 
 * Comprehensive objective image signal & color quality inspection:
 * - Highlight clipping percentage (<0.98 vs >=0.98)
 * - Black crush percentage (<=0.02)
 * - Mean saturation & chroma variance
 * - Luminance variance & RMS contrast
 * - Frame-to-frame color & luma drift
 * - White balance neutral drift
 * - Out-of-gamut coordinate violations
 * - Actionable quality scoring & recommendations
 */

import { ColorQualityDossier, RGBColor } from './colorTypes';
import { ColorManagementEngine } from './colorManagementEngine';
import { DynamicRangeAnalyzer } from './dynamicRangeAnalyzer';

export class ColorQualityAnalyzer {
  private static instance: ColorQualityAnalyzer | null = null;
  private colorMgmt: ColorManagementEngine;
  private drAnalyzer: DynamicRangeAnalyzer;

  constructor() {
    this.colorMgmt = ColorManagementEngine.getInstance();
    this.drAnalyzer = DynamicRangeAnalyzer.getInstance();
  }

  public static getInstance(): ColorQualityAnalyzer {
    if (!ColorQualityAnalyzer.instance) {
      ColorQualityAnalyzer.instance = new ColorQualityAnalyzer();
    }
    return ColorQualityAnalyzer.instance;
  }

  /**
   * Conducts full empirical color quality inspection on an image byte buffer.
   */
  public evaluateColorQuality(
    rgbaData: Uint8ClampedArray | Uint8Array,
    width: number,
    height: number,
    sampleStride: number = 4
  ): ColorQualityDossier {
    const totalPixels = (width * height) || (rgbaData.length / 4);
    const dr = this.drAnalyzer.analyzeDynamicRange(rgbaData, sampleStride);

    let sumSat = 0;
    let sumSatSq = 0;
    let outOfGamutCount = 0;
    let neutralCastSum = 0;
    let neutralSampleCount = 0;
    let sampleCount = 0;

    const step = Math.max(4, sampleStride * 4);

    for (let i = 0; i < rgbaData.length; i += step) {
      const r = rgbaData[i] / 255.0;
      const g = rgbaData[i + 1] / 255.0;
      const b = rgbaData[i + 2] / 255.0;

      const maxVal = Math.max(r, g, b);
      const minVal = Math.min(r, g, b);
      const chroma = maxVal - minVal;
      const sat = maxVal > 0.001 ? chroma / maxVal : 0;

      sumSat += sat;
      sumSatSq += sat * sat;

      // Check gamut coordinates
      if (r < 0 || r > 1 || g < 0 || g > 1 || b < 0 || b > 1) {
        outOfGamutCount++;
      }

      // Neutral gray consistency (luma between 0.3 and 0.7, low chroma)
      const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      if (luma >= 0.3 && luma <= 0.7 && chroma < 0.08) {
        const castDist = Math.sqrt(Math.pow(r - g, 2) + Math.pow(g - b, 2));
        neutralCastSum += castDist;
        neutralSampleCount++;
      }

      sampleCount++;
    }

    const meanSat = sampleCount > 0 ? sumSat / sampleCount : 0;
    const satVar = sampleCount > 0 ? Math.max(0, sumSatSq / sampleCount - meanSat * meanSat) : 0;
    const outOfGamutPercent = sampleCount > 0 ? (outOfGamutCount / sampleCount) * 100 : 0;

    const avgNeutralCast = neutralSampleCount > 0 ? neutralCastSum / neutralSampleCount : 0;
    const wbConsistency = Math.max(0, Math.min(100, Math.round(100 - avgNeutralCast * 400)));

    // Score deduction math
    let gradeScore = 100;
    const recommendations: string[] = [];

    if (dr.highlightClippingPercent > 5.0) {
      gradeScore -= Math.min(25, Math.round(dr.highlightClippingPercent * 2));
      recommendations.push(`Highlight clipping is high (${dr.highlightClippingPercent}%). Lower Exposure or apply Highlight Recovery.`);
    }

    if (dr.shadowCrushPercent > 8.0) {
      gradeScore -= Math.min(20, Math.round(dr.shadowCrushPercent * 1.5));
      recommendations.push(`Shadow crushing detected (${dr.shadowCrushPercent}%). Lift blacks or adjust contrast pivot.`);
    }

    if (outOfGamutPercent > 0.5) {
      gradeScore -= 30;
      recommendations.push(`Out-of-gamut colors detected (${outOfGamutPercent.toFixed(1)}%). Enable gamut clamping.`);
    }

    if (meanSat > 0.85) {
      gradeScore -= 10;
      recommendations.push('Overall saturation is extremely high. Consider pulling back Master Saturation.');
    }

    let verdict: 'EXCELLENT' | 'GOOD' | 'WARNING_CLIPPING' | 'CRITICAL_GAMUT_VIOLATION' = 'EXCELLENT';
    if (outOfGamutPercent > 1.0) {
      verdict = 'CRITICAL_GAMUT_VIOLATION';
    } else if (dr.highlightClippingPercent > 10.0 || dr.shadowCrushPercent > 15.0) {
      verdict = 'WARNING_CLIPPING';
    } else if (gradeScore < 80) {
      verdict = 'GOOD';
    }

    if (recommendations.length === 0) {
      recommendations.push('Color balance, dynamic range, and gamut parameters are within cinematic broadcast tolerances.');
    }

    return {
      totalPixelsAnalyzed: totalPixels,
      clippingPercent: dr.highlightClippingPercent,
      blackCrushPercent: dr.shadowCrushPercent,
      highlightClippingPercent: dr.highlightClippingPercent,
      meanSaturation: parseFloat(meanSat.toFixed(3)),
      colorVariance: parseFloat(satVar.toFixed(4)),
      luminanceVariance: parseFloat((dr.rmsContrast * dr.rmsContrast).toFixed(4)),
      frameColorDrift: 0.0, // Populated in multi-frame sequences
      whiteBalanceConsistency: wbConsistency,
      subjectColorDrift: dr.skinToneStabilityScore,
      outOfGamutPercent: parseFloat(outOfGamutPercent.toFixed(2)),
      overallGradeScore: Math.max(0, gradeScore),
      verdict,
      recommendations
    };
  }
}
