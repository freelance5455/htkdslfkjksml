/**
 * GODEX P4.9 — Production Color Presets
 * 
 * Deterministic, broadcast-grade color grading presets:
 * - NATURAL: Clean colorimetry with neutral balance and true skin tones
 * - CINEMATIC: Blockbuster contrast, teal shadows, amber skin tones, and gentle highlight roll-off
 * - FILMIC: Kodak Vision3 emulation with 35mm grain, organic S-curve, and lifted blacks
 * - DOCUMENTARY: Naturalistic neutrality, linear shadow latitude, and true-to-life saturation
 * - NOIR: Deep 35mm silver Tri-X monochrome with pronounced contrast and moody highlights
 * - WARM_FILM: 3200K tungsten vintage warmth with golden highlights and soft chocolate shadows
 * - COOL_NIGHT: Low-key moonlight with indigo shadows, crisp cyan highlights, and muted midtones
 * - HIGH_CONTRAST: Punchy commercial look with crisp blacks and vibrant primary separation
 * - SOFT_FILM: Pastel cine look with lowered contrast, lifted toe, and soft halation
 * - DESATURATED: Gritty, bleached realism with desaturated chroma and textured midtones
 */

import { ColorPresetId, ColorGradingState } from './colorTypes';
import { CinematicColorGradingEngine } from './cinematicColorGradingEngine';

export interface ProductionColorPreset {
  id: ColorPresetId;
  name: string;
  category: 'BROADCAST' | 'CINEMATIC' | 'VINTAGE' | 'COMMERCIAL';
  description: string;
  state: Partial<ColorGradingState>;
}

export class ColorPresets {
  public static readonly PRESETS: Record<ColorPresetId, ProductionColorPreset> = {
    NATURAL: {
      id: 'NATURAL',
      name: 'Natural Broadcast (Rec.709)',
      category: 'BROADCAST',
      description: 'Accurate colorimetry with calibrated neutral balance, 1.0 contrast, and true skin tones.',
      state: {
        workingColorSpace: 'Rec709',
        outputColorSpace: 'Rec709',
        primary: {
          exposureEV: 0.0,
          contrast: 1.0,
          contrastPivot: 0.435,
          temperatureKelvin: 5600,
          tint: 0.0,
          saturation: 1.0,
          vibrance: 0.0,
          highlights: 0.0,
          shadows: 0.0,
          whites: 0.0,
          blacks: 0.0,
          midtoneDetail: 0.0,
          hueRotationDeg: 0.0,
          wheels: {
            lift: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 },
            gamma: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 },
            gain: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 },
            offset: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 }
          }
        },
        lookPreset: 'NONE',
        filmGrain: {
          enabled: false,
          intensity: 0.0,
          format: '35mm',
          lumaWeighting: true,
          frameConsistent: false,
          temporalSeed: 1001,
          chromaGrain: 0.0
        }
      }
    },
    CINEMATIC: {
      id: 'CINEMATIC',
      name: 'Modern Hollywood Cinematic',
      category: 'CINEMATIC',
      description: 'Rich dynamic range with teal-tinted shadows, warm golden skin tones, and soft highlight roll-off.',
      state: {
        workingColorSpace: 'LinearRGB',
        outputColorSpace: 'sRGB',
        primary: {
          exposureEV: 0.1,
          contrast: 1.15,
          contrastPivot: 0.45,
          temperatureKelvin: 5400,
          tint: 2.0,
          saturation: 1.05,
          vibrance: 0.15,
          highlights: -15,
          shadows: 10,
          whites: 5,
          blacks: -5,
          midtoneDetail: 12,
          hueRotationDeg: 0.0,
          wheels: {
            lift: { angleDeg: 195, magnitude: 0.12, masterLuma: -0.05, r: -0.08, g: 0.02, b: 0.10 },
            gamma: { angleDeg: 35, magnitude: 0.05, masterLuma: 0.02, r: 0.04, g: 0.02, b: -0.03 },
            gain: { angleDeg: 40, magnitude: 0.08, masterLuma: 0.05, r: 0.07, g: 0.04, b: -0.06 },
            offset: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 }
          }
        },
        lookPreset: 'TEAL_AND_ORANGE',
        filmGrain: {
          enabled: true,
          intensity: 0.18,
          format: '35mm',
          lumaWeighting: true,
          frameConsistent: false,
          temporalSeed: 2002,
          chromaGrain: 0.05
        },
        opticalFinish: {
          bloomEnabled: true,
          bloomIntensity: 0.12,
          bloomThreshold: 0.82,
          bloomRadius: 8,
          halationEnabled: true,
          halationIntensity: 0.15,
          halationRadius: 4,
          vignetteEnabled: true,
          vignetteAmount: 0.20,
          vignetteFeather: 0.6,
          vignetteRoundness: 0.8,
          chromaticAberration: 0.04,
          lensSoftness: 0.0,
          sharpening: 0.15
        }
      }
    },
    FILMIC: {
      id: 'FILMIC',
      name: 'Kodak Vision3 35mm Stock',
      category: 'CINEMATIC',
      description: 'Physical film print emulation with subtle red halation, organic grain, and soft shoulder highlights.',
      state: {
        workingColorSpace: 'LinearRGB',
        outputColorSpace: 'sRGB',
        primary: {
          exposureEV: 0.0,
          contrast: 1.08,
          contrastPivot: 0.42,
          temperatureKelvin: 5200,
          tint: -1.0,
          saturation: 1.08,
          vibrance: 0.1,
          highlights: -20,
          shadows: 15,
          whites: 0,
          blacks: 8,
          midtoneDetail: 8,
          hueRotationDeg: 0,
          wheels: {
            lift: { angleDeg: 120, magnitude: 0.04, masterLuma: 0.04, r: -0.02, g: 0.03, b: -0.01 },
            gamma: { angleDeg: 30, magnitude: 0.06, masterLuma: 0.0, r: 0.05, g: 0.02, b: -0.04 },
            gain: { angleDeg: 45, magnitude: 0.06, masterLuma: -0.02, r: 0.05, g: 0.03, b: -0.05 },
            offset: { angleDeg: 0, magnitude: 0, masterLuma: 0.02, r: 0.01, g: 0.01, b: 0.0 }
          }
        },
        lookPreset: 'KODAK_VISION',
        filmGrain: {
          enabled: true,
          intensity: 0.28,
          format: '35mm',
          lumaWeighting: true,
          frameConsistent: false,
          temporalSeed: 3003,
          chromaGrain: 0.12
        },
        opticalFinish: {
          bloomEnabled: true,
          bloomIntensity: 0.10,
          bloomThreshold: 0.85,
          bloomRadius: 6,
          halationEnabled: true,
          halationIntensity: 0.25,
          halationRadius: 5,
          vignetteEnabled: true,
          vignetteAmount: 0.18,
          vignetteFeather: 0.5,
          vignetteRoundness: 0.7,
          chromaticAberration: 0.05,
          lensSoftness: 0.05,
          sharpening: 0.10
        }
      }
    },
    DOCUMENTARY: {
      id: 'DOCUMENTARY',
      name: 'Desaturated Documentary',
      category: 'BROADCAST',
      description: 'Muted, authentic realism with extended shadow latitude, honest skin tones, and neutral contrast.',
      state: {
        workingColorSpace: 'Rec709',
        outputColorSpace: 'Rec709',
        primary: {
          exposureEV: -0.1,
          contrast: 1.02,
          contrastPivot: 0.40,
          temperatureKelvin: 5600,
          tint: 0.0,
          saturation: 0.82,
          vibrance: -0.05,
          highlights: -10,
          shadows: 8,
          whites: -5,
          blacks: 5,
          midtoneDetail: 15,
          hueRotationDeg: 0,
          wheels: {
            lift: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 },
            gamma: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 },
            gain: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 },
            offset: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 }
          }
        },
        lookPreset: 'DESATURATED_DOC',
        filmGrain: {
          enabled: true,
          intensity: 0.10,
          format: '16mm',
          lumaWeighting: true,
          frameConsistent: false,
          temporalSeed: 4004,
          chromaGrain: 0.0
        }
      }
    },
    NOIR: {
      id: 'NOIR',
      name: 'Classic 35mm Noir Monochrome',
      category: 'VINTAGE',
      description: 'Deep Kodak Tri-X black-and-white curve with rich shadows, sparkling silver highlights, and textured grain.',
      state: {
        workingColorSpace: 'LinearRGB',
        outputColorSpace: 'sRGB',
        primary: {
          exposureEV: 0.0,
          contrast: 1.35,
          contrastPivot: 0.45,
          temperatureKelvin: 5600,
          tint: 0.0,
          saturation: 0.0,
          vibrance: 0.0,
          highlights: 15,
          shadows: -20,
          whites: 10,
          blacks: -15,
          midtoneDetail: 25,
          hueRotationDeg: 0,
          wheels: {
            lift: { angleDeg: 0, magnitude: 0, masterLuma: -0.1, r: 0, g: 0, b: 0 },
            gamma: { angleDeg: 0, magnitude: 0, masterLuma: 0.05, r: 0, g: 0, b: 0 },
            gain: { angleDeg: 0, magnitude: 0, masterLuma: 0.1, r: 0, g: 0, b: 0 },
            offset: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 }
          }
        },
        lookPreset: 'NOIR_CLASSIC',
        filmGrain: {
          enabled: true,
          intensity: 0.35,
          format: '35mm',
          lumaWeighting: true,
          frameConsistent: false,
          temporalSeed: 5005,
          chromaGrain: 0.0
        },
        opticalFinish: {
          bloomEnabled: true,
          bloomIntensity: 0.15,
          bloomThreshold: 0.75,
          bloomRadius: 10,
          halationEnabled: false,
          halationIntensity: 0.0,
          halationRadius: 0,
          vignetteEnabled: true,
          vignetteAmount: 0.35,
          vignetteFeather: 0.6,
          vignetteRoundness: 0.8,
          chromaticAberration: 0.0,
          lensSoftness: 0.05,
          sharpening: 0.20
        }
      }
    },
    WARM_FILM: {
      id: 'WARM_FILM',
      name: 'Kodachrome 3200K Warmth',
      category: 'VINTAGE',
      description: 'Golden hour vintage film grade with amber midtones, warm chocolate shadows, and glowing highlights.',
      state: {
        workingColorSpace: 'LinearRGB',
        outputColorSpace: 'sRGB',
        primary: {
          exposureEV: 0.15,
          contrast: 1.12,
          contrastPivot: 0.42,
          temperatureKelvin: 4200,
          tint: 5.0,
          saturation: 1.15,
          vibrance: 0.2,
          highlights: -10,
          shadows: 15,
          whites: 5,
          blacks: 5,
          midtoneDetail: 10,
          hueRotationDeg: 0,
          wheels: {
            lift: { angleDeg: 45, magnitude: 0.08, masterLuma: 0.02, r: 0.06, g: 0.03, b: -0.04 },
            gamma: { angleDeg: 40, magnitude: 0.10, masterLuma: 0.03, r: 0.08, g: 0.05, b: -0.06 },
            gain: { angleDeg: 50, magnitude: 0.12, masterLuma: 0.02, r: 0.10, g: 0.06, b: -0.08 },
            offset: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 }
          }
        },
        lookPreset: 'WARM_FILM',
        filmGrain: {
          enabled: true,
          intensity: 0.25,
          format: '35mm',
          lumaWeighting: true,
          frameConsistent: false,
          temporalSeed: 6006,
          chromaGrain: 0.1
        },
        opticalFinish: {
          bloomEnabled: true,
          bloomIntensity: 0.18,
          bloomThreshold: 0.78,
          bloomRadius: 10,
          halationEnabled: true,
          halationIntensity: 0.30,
          halationRadius: 6,
          vignetteEnabled: true,
          vignetteAmount: 0.22,
          vignetteFeather: 0.5,
          vignetteRoundness: 0.7,
          chromaticAberration: 0.06,
          lensSoftness: 0.08,
          sharpening: 0.12
        }
      }
    },
    COOL_NIGHT: {
      id: 'COOL_NIGHT',
      name: 'Moonlight Cool Night',
      category: 'CINEMATIC',
      description: 'Cold low-key nocturnal atmosphere with cyan highlights, deep indigo shadows, and subdued skin chroma.',
      state: {
        workingColorSpace: 'LinearRGB',
        outputColorSpace: 'sRGB',
        primary: {
          exposureEV: -0.25,
          contrast: 1.20,
          contrastPivot: 0.40,
          temperatureKelvin: 7800,
          tint: -5.0,
          saturation: 0.78,
          vibrance: -0.1,
          highlights: 10,
          shadows: -15,
          whites: 0,
          blacks: -10,
          midtoneDetail: 18,
          hueRotationDeg: 0,
          wheels: {
            lift: { angleDeg: 220, magnitude: 0.15, masterLuma: -0.08, r: -0.10, g: -0.02, b: 0.12 },
            gamma: { angleDeg: 205, magnitude: 0.08, masterLuma: -0.02, r: -0.06, g: 0.02, b: 0.08 },
            gain: { angleDeg: 190, magnitude: 0.10, masterLuma: 0.04, r: -0.04, g: 0.05, b: 0.09 },
            offset: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 }
          }
        },
        lookPreset: 'COOL_NIGHT',
        filmGrain: {
          enabled: true,
          intensity: 0.22,
          format: '35mm',
          lumaWeighting: true,
          frameConsistent: false,
          temporalSeed: 7007,
          chromaGrain: 0.05
        },
        opticalFinish: {
          bloomEnabled: true,
          bloomIntensity: 0.15,
          bloomThreshold: 0.80,
          bloomRadius: 8,
          halationEnabled: false,
          halationIntensity: 0.0,
          halationRadius: 0,
          vignetteEnabled: true,
          vignetteAmount: 0.30,
          vignetteFeather: 0.6,
          vignetteRoundness: 0.8,
          chromaticAberration: 0.08,
          lensSoftness: 0.02,
          sharpening: 0.18
        }
      }
    },
    HIGH_CONTRAST: {
      id: 'HIGH_CONTRAST',
      name: 'High Impact Commercial',
      category: 'COMMERCIAL',
      description: 'Bold commercial look with deep black floor, punchy specular highlights, and saturated primaries.',
      state: {
        workingColorSpace: 'LinearRGB',
        outputColorSpace: 'sRGB',
        primary: {
          exposureEV: 0.05,
          contrast: 1.35,
          contrastPivot: 0.46,
          temperatureKelvin: 5600,
          tint: 0.0,
          saturation: 1.20,
          vibrance: 0.25,
          highlights: 10,
          shadows: -15,
          whites: 15,
          blacks: -15,
          midtoneDetail: 20,
          hueRotationDeg: 0,
          wheels: {
            lift: { angleDeg: 0, magnitude: 0, masterLuma: -0.08, r: 0, g: 0, b: 0 },
            gamma: { angleDeg: 0, magnitude: 0, masterLuma: 0.0, r: 0, g: 0, b: 0 },
            gain: { angleDeg: 0, magnitude: 0, masterLuma: 0.08, r: 0, g: 0, b: 0 },
            offset: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 }
          }
        },
        lookPreset: 'HIGH_CONTRAST',
        filmGrain: {
          enabled: false,
          intensity: 0.0,
          format: '35mm',
          lumaWeighting: true,
          frameConsistent: false,
          temporalSeed: 8008,
          chromaGrain: 0.0
        },
        opticalFinish: {
          bloomEnabled: true,
          bloomIntensity: 0.10,
          bloomThreshold: 0.88,
          bloomRadius: 6,
          halationEnabled: false,
          halationIntensity: 0.0,
          halationRadius: 0,
          vignetteEnabled: true,
          vignetteAmount: 0.15,
          vignetteFeather: 0.5,
          vignetteRoundness: 0.8,
          chromaticAberration: 0.02,
          lensSoftness: 0.0,
          sharpening: 0.25
        }
      }
    },
    SOFT_FILM: {
      id: 'SOFT_FILM',
      name: 'Soft Highlight Rolloff (Pastel Cine)',
      category: 'CINEMATIC',
      description: 'Dreamy low-contrast film curve with lifted shadow milk, soft highlight compression, and pastel skin tones.',
      state: {
        workingColorSpace: 'LinearRGB',
        outputColorSpace: 'sRGB',
        primary: {
          exposureEV: 0.1,
          contrast: 0.92,
          contrastPivot: 0.40,
          temperatureKelvin: 5400,
          tint: 2.0,
          saturation: 0.95,
          vibrance: 0.05,
          highlights: -30,
          shadows: 25,
          whites: -10,
          blacks: 15,
          midtoneDetail: -10,
          hueRotationDeg: 0,
          wheels: {
            lift: { angleDeg: 0, magnitude: 0, masterLuma: 0.08, r: 0.02, g: 0.02, b: 0.03 },
            gamma: { angleDeg: 40, magnitude: 0.04, masterLuma: 0.04, r: 0.03, g: 0.02, b: -0.02 },
            gain: { angleDeg: 0, magnitude: 0, masterLuma: -0.05, r: 0, g: 0, b: 0 },
            offset: { angleDeg: 0, magnitude: 0, masterLuma: 0.02, r: 0.01, g: 0.01, b: 0.01 }
          }
        },
        lookPreset: 'SOFT_HIGHLIGHT_ROLLOFF',
        filmGrain: {
          enabled: true,
          intensity: 0.15,
          format: '65mm',
          lumaWeighting: true,
          frameConsistent: false,
          temporalSeed: 9009,
          chromaGrain: 0.05
        },
        opticalFinish: {
          bloomEnabled: true,
          bloomIntensity: 0.22,
          bloomThreshold: 0.70,
          bloomRadius: 14,
          halationEnabled: true,
          halationIntensity: 0.18,
          halationRadius: 5,
          vignetteEnabled: true,
          vignetteAmount: 0.12,
          vignetteFeather: 0.6,
          vignetteRoundness: 0.8,
          chromaticAberration: 0.03,
          lensSoftness: 0.12,
          sharpening: 0.05
        }
      }
    },
    DESATURATED: {
      id: 'DESATURATED',
      name: 'Bleached Combat Realism',
      category: 'COMMERCIAL',
      description: 'Gritty, desaturated war/action film look with high midtone clarity and restrained palette.',
      state: {
        workingColorSpace: 'LinearRGB',
        outputColorSpace: 'sRGB',
        primary: {
          exposureEV: 0.0,
          contrast: 1.25,
          contrastPivot: 0.44,
          temperatureKelvin: 5800,
          tint: -2.0,
          saturation: 0.55,
          vibrance: -0.2,
          highlights: 5,
          shadows: -10,
          whites: 10,
          blacks: -8,
          midtoneDetail: 30,
          hueRotationDeg: 0,
          wheels: {
            lift: { angleDeg: 0, magnitude: 0, masterLuma: -0.05, r: 0, g: 0, b: 0 },
            gamma: { angleDeg: 0, magnitude: 0, masterLuma: 0.0, r: 0, g: 0, b: 0 },
            gain: { angleDeg: 0, magnitude: 0, masterLuma: 0.05, r: 0, g: 0, b: 0 },
            offset: { angleDeg: 0, magnitude: 0, masterLuma: 0, r: 0, g: 0, b: 0 }
          }
        },
        lookPreset: 'BLEACH_BYPASS',
        filmGrain: {
          enabled: true,
          intensity: 0.30,
          format: '16mm',
          lumaWeighting: true,
          frameConsistent: false,
          temporalSeed: 1010,
          chromaGrain: 0.0
        },
        opticalFinish: {
          bloomEnabled: false,
          bloomIntensity: 0.0,
          bloomThreshold: 0.85,
          bloomRadius: 0,
          halationEnabled: false,
          halationIntensity: 0.0,
          halationRadius: 0,
          vignetteEnabled: true,
          vignetteAmount: 0.28,
          vignetteFeather: 0.5,
          vignetteRoundness: 0.7,
          chromaticAberration: 0.05,
          lensSoftness: 0.0,
          sharpening: 0.25
        }
      }
    }
  };

  /**
   * Applies a preset onto a base color grading state, returning a cloned updated state.
   */
  public static applyPreset(baseState: ColorGradingState, presetId: ColorPresetId): ColorGradingState {
    const preset = ColorPresets.PRESETS[presetId] || ColorPresets.PRESETS.NATURAL;
    const def = CinematicColorGradingEngine.getDefaultState();

    return {
      ...def,
      ...preset.state,
      activePresetId: presetId,
      provenance: {
        engineClassification: 'LOCAL_DETERMINISTIC',
        deterministicCalculationsVerified: true,
        timestamp: Date.now(),
        lutApplied: preset.state.lookPreset !== 'NONE'
      }
    };
  }
}
