/**
 * GODEX P4.9 — Professional Color Science, Cinematic Finishing & Final Image Pipeline Types
 * 
 * Strict typed definitions for:
 * - Color Spaces & Transfer Functions
 * - Primary & Secondary Color Grading
 * - 3-Way Lift/Gamma/Gain Color Wheels
 * - Spline Curves (Master, RGB, Luma)
 * - Cinematic Looks & Emulations
 * - Dynamic Range & HDR Luminance Metrics
 * - Skin-Tone Protection & Vectorscope Analysis
 * - Procedural Film Grain & Optical Finishing
 * - Quality Dossiers & Zero-Fabrication Invariants
 */

export type ColorSpaceType = 
  | 'sRGB' 
  | 'Rec709' 
  | 'DisplayP3' 
  | 'LinearRGB' 
  | 'CineonLog' 
  | 'ARRI_LogC3';

export type TransferFunctionType = 
  | 'sRGB' 
  | 'Rec709' 
  | 'Gamma22' 
  | 'Gamma24' 
  | 'Linear' 
  | 'LogC3' 
  | 'Cineon';

export type ColorQualityLevel = 
  | 'MOBILE_SAFE' 
  | 'MOBILE_HIGH' 
  | 'TABLET' 
  | 'DESKTOP' 
  | 'DESKTOP_HIGH';

export interface RGBColor {
  r: number; // 0.0 - 1.0
  g: number; // 0.0 - 1.0
  b: number; // 0.0 - 1.0
}

export interface ColorWheelAdjustment {
  angleDeg: number;       // 0 to 360 degrees (Hue)
  magnitude: number;      // 0.0 to 1.0 (Saturation/Strength)
  masterLuma: number;     // -1.0 to +1.0 (Luma/Offset offset)
  r: number;              // -1.0 to +1.0
  g: number;              // -1.0 to +1.0
  b: number;              // -1.0 to +1.0
}

export interface ThreeWayColorWheels {
  lift: ColorWheelAdjustment;   // Shadows
  gamma: ColorWheelAdjustment;  // Midtones
  gain: ColorWheelAdjustment;   // Highlights
  offset: ColorWheelAdjustment; // Global Pedestal
}

export interface PrimaryGradingParams {
  exposureEV: number;       // -4.0 to +4.0 EV stops (default 0)
  contrast: number;         // 0.0 to 2.5 (default 1.0)
  contrastPivot: number;    // 0.0 to 1.0 (default 0.435)
  temperatureKelvin: number;// 2000K to 12000K (default 5600K, delta from neutral)
  tint: number;             // -100 to +100 (Green < 0, Magenta > 0)
  saturation: number;       // 0.0 to 2.0 (default 1.0)
  vibrance: number;         // -1.0 to +1.0 (default 0.0)
  highlights: number;       // -100 to +100 (recovery / boost)
  shadows: number;          // -100 to +100 (lift / crush)
  whites: number;           // -100 to +100 (white clip point)
  blacks: number;           // -100 to +100 (black clip point)
  midtoneDetail: number;    // -100 to +100 (micro-contrast)
  hueRotationDeg: number;   // 0 to 360 degrees (default 0)
  wheels: ThreeWayColorWheels;
}

export interface CurvePoint {
  x: number; // 0.0 to 1.0 (Input)
  y: number; // 0.0 to 1.0 (Output)
}

export interface CurvesData {
  master: CurvePoint[];
  red: CurvePoint[];
  green: CurvePoint[];
  blue: CurvePoint[];
  luma: CurvePoint[];
}

export type LookPresetType = 
  | 'NONE'
  | 'FILMIC_CONTRAST'
  | 'BLEACH_BYPASS'
  | 'TEAL_AND_ORANGE'
  | 'NOIR_CLASSIC'
  | 'WARM_FILM'
  | 'COOL_NIGHT'
  | 'HIGH_CONTRAST'
  | 'SOFT_HIGHLIGHT_ROLLOFF'
  | 'DESATURATED_DOC'
  | 'KODAK_VISION'
  | 'CYBERPUNK_NEON';

export type ColorPresetId = 
  | 'NATURAL'
  | 'CINEMATIC'
  | 'FILMIC'
  | 'DOCUMENTARY'
  | 'NOIR'
  | 'WARM_FILM'
  | 'COOL_NIGHT'
  | 'HIGH_CONTRAST'
  | 'SOFT_FILM'
  | 'DESATURATED';

export type FilmGrainFormat = '16mm' | '35mm' | '65mm';

export interface FilmGrainOptions {
  enabled: boolean;
  intensity: number;          // 0.0 to 1.0 (default 0.25)
  format: FilmGrainFormat;    // Grain size & pattern
  lumaWeighting: boolean;     // Film physics: grain denser in midtones/shadows than blown highlights
  frameConsistent: boolean;   // True for static noise, false for temporal seed variation
  temporalSeed: number;       // Seed for deterministic procedural noise
  chromaGrain: number;        // 0.0 (monochrome grain) to 1.0 (color noise)
}

export interface OpticalFinishOptions {
  bloomEnabled: boolean;
  bloomIntensity: number;       // 0.0 to 1.0
  bloomThreshold: number;       // 0.6 to 1.0
  bloomRadius: number;          // 2 to 32 pixels
  halationEnabled: boolean;
  halationIntensity: number;    // 0.0 to 1.0 (red highlight edge dispersion)
  halationRadius: number;       // 1 to 16 pixels
  vignetteEnabled: boolean;
  vignetteAmount: number;       // 0.0 to 1.0
  vignetteFeather: number;      // 0.1 to 1.0
  vignetteRoundness: number;    // 0.0 to 1.0
  chromaticAberration: number;  // 0.0 to 1.0 (subtle lens fringe)
  lensSoftness: number;         // 0.0 to 1.0 (diffuse glow)
  sharpening: number;           // 0.0 to 1.0 (edge-preserving unsharp mask)
}

export interface SkinToneProtectionOptions {
  enabled: boolean;
  centerHueDeg: number;         // Default ~115° on vectorscope (I-line axis)
  hueToleranceDeg: number;      // Tolerance window (default ±25°)
  maxShiftFactor: number;       // 0.0 (full lock) to 1.0 (allow grade)
  highlightPreserveThreshold: number; // Prevent skin blowout
}

export interface DynamicRangeMetrics {
  minLuma: number;              // 0.0 to 1.0
  maxLuma: number;              // 0.0 to 1.0
  meanLuma: number;             // 0.0 to 1.0
  medianLuma: number;           // 0.0 to 1.0
  p1Luma: number;               // 1st percentile
  p5Luma: number;               // 5th percentile
  p95Luma: number;              // 95th percentile
  p99Luma: number;              // 99th percentile
  dynamicRangeStops: number;    // Estimated scene dynamic range in stops (EV)
  highlightClippingPercent: number; // % pixels > 0.98
  shadowCrushPercent: number;       // % pixels < 0.02
  rmsContrast: number;          // Standard deviation of luminance
  skinTonePixelCount: number;
  skinToneStabilityScore: number; // 0 - 100
  histogram: {
    luma: number[];             // 256 bins
    red: number[];
    green: number[];
    blue: number[];
    totalSamples?: number;
  };
}

export interface ColorQualityDossier {
  totalPixelsAnalyzed: number;
  clippingPercent: number;
  blackCrushPercent: number;
  highlightClippingPercent: number;
  meanSaturation: number;
  colorVariance: number;
  luminanceVariance: number;
  frameColorDrift: number;      // Delta E / Luma drift between frames
  whiteBalanceConsistency: number; // 0 - 100
  subjectColorDrift: number;    // 0 - 100 stability
  outOfGamutPercent: number;
  overallGradeScore: number;    // 0 - 100
  verdict: 'EXCELLENT' | 'GOOD' | 'WARNING_CLIPPING' | 'CRITICAL_GAMUT_VIOLATION';
  recommendations: string[];
}

export interface ColorGradingState {
  version: 'P4.9';
  workingColorSpace: ColorSpaceType;
  outputColorSpace: ColorSpaceType;
  primary: PrimaryGradingParams;
  curves: CurvesData;
  lookPreset: LookPresetType;
  skinToneProtection: SkinToneProtectionOptions;
  filmGrain: FilmGrainOptions;
  opticalFinish: OpticalFinishOptions;
  activePresetId?: ColorPresetId;
  provenance: {
    engineClassification: 'LOCAL_DETERMINISTIC';
    deterministicCalculationsVerified: boolean;
    timestamp: number;
    lutApplied: boolean;
  };
}
