/**
 * GODEX P4.0 — Neural Model Selection Engine
 * 
 * Selects the optimal installed/discovered model for a given workflow based on:
 * - Workflow type (T2I, I2V, T2V, V2V, Enhance)
 * - Target resolution & FPS
 * - Host VRAM / RAM budget
 * - Tensor formats & node compatibility
 * 
 * Invariants:
 * - Never invents or hallucinates models.
 * - Always provides explicit rationale for model recommendation.
 */

import {
  MediaWorkflowType,
  MediaJobParameters,
  NeuralModelMetadata,
  ModelTruthState
} from './creativeStudioTypes';
import { ModelManager } from './modelManager';
import { ComfyUiDiscoveredModels } from './comfyUiEngineAdapter';
import { HardwareAuditReport } from './hardwareAuditor';

export interface ModelRecommendation {
  modelId: string;
  name: string;
  modelName: string;
  workflow: MediaWorkflowType;
  category: 'CHECKPOINT' | 'SVD' | 'WAN_VIDEO' | 'ANIMATEDIFF' | 'UPSCALER' | 'LORA' | 'CONTROLNET';
  isLocalDiscovered: boolean;
  score: number; // 0 to 100
  confidence: number;
  estimatedVramMb: number;
  vramRequiredGb: number;
  truthState: ModelTruthState;
  requiredModelFamily: 'SDXL' | 'FLUX' | 'SD15' | 'SVD' | 'WAN21' | 'ANIMATEDIFF' | 'REAL_ESRGAN' | 'GENERIC';
  supportedResolutions: Array<'720p' | '1080p' | '4K'>;
  supportedFps: Array<24 | 30 | 60>;
  supportedPrecisions: Array<'fp16' | 'fp8' | 'bf16' | 'fp32'>;
  missingDependencies: string[];
  rationale: string;
  suggestedVae?: string;
  suggestedLora?: string;
}

export class ModelSelectionEngine {
  private static instance: ModelSelectionEngine | null = null;

  public static getInstance(): ModelSelectionEngine {
    if (!ModelSelectionEngine.instance) {
      ModelSelectionEngine.instance = new ModelSelectionEngine();
    }
    return ModelSelectionEngine.instance;
  }

  /**
   * Recommends the best available model for a target workflow and parameters.
   */
  public selectBestModel(
    workflow: MediaWorkflowType,
    params: MediaJobParameters,
    discovered: ComfyUiDiscoveredModels,
    hardware: HardwareAuditReport
  ): ModelRecommendation {
    const availableVramMb = (hardware.estimatedVramGb || hardware.totalVramGb || 8) * 1024;
    const is4K = params.resolution === '4K';
    const modelManager = ModelManager.getInstance();
    const catalog = modelManager.getAllModels();

    // 1. Check Discovered ComfyUI Models First (True Local Inference)
    if (workflow === 'TEXT_TO_IMAGE' || workflow === 'VIDEO_TO_VIDEO') {
      if (discovered.checkpoints && discovered.checkpoints.length > 0) {
        // Find preferred checkpoint (Flux, SDXL, or SD1.5)
        const flux = discovered.checkpoints.find(c => c.toLowerCase().includes('flux'));
        const sdxl = discovered.checkpoints.find(c => c.toLowerCase().includes('sdxl') || c.toLowerCase().includes('base'));
        const sd15 = discovered.checkpoints.find(c => c.toLowerCase().includes('1.5') || c.toLowerCase().includes('v1-5'));

        let selected = discovered.checkpoints[0];
        let family: ModelRecommendation['requiredModelFamily'] = 'SDXL';
        let rationale = `Discovered local checkpoint '${selected}'`;
        let estVram = 6144;
        let precisions: Array<'fp16' | 'fp8' | 'bf16' | 'fp32'> = ['fp16', 'fp32'];

        if (flux && availableVramMb >= 12288) {
          selected = flux;
          family = 'FLUX';
          rationale = `High-capacity Flux model selected for peak quality with ${hardware.estimatedVramGb || 16}GB VRAM`;
          estVram = 12288;
          precisions = ['fp8', 'bf16', 'fp16'];
        } else if (sdxl && availableVramMb >= 8192) {
          selected = sdxl;
          family = 'SDXL';
          rationale = `SDXL base model selected for optimal prompt adherence and high resolution`;
          estVram = 8192;
          precisions = ['fp16', 'fp32'];
        } else if (sd15) {
          selected = sd15;
          family = 'SD15';
          rationale = `SD1.5 checkpoint selected for fast, memory-safe execution (${estVram}MB VRAM)`;
          estVram = 4096;
          precisions = ['fp16', 'fp32'];
        }

        const suggestedVae = discovered.vaes?.length > 0 ? discovered.vaes[0] : undefined;
        const suggestedLora = discovered.loras?.length > 0 ? discovered.loras[0] : undefined;

        const truthState: ModelTruthState = estVram > availableVramMb ? 'INSUFFICIENT_MEMORY' : 'SELECTED';

        return {
          modelId: selected,
          name: selected,
          modelName: selected,
          workflow,
          category: 'CHECKPOINT',
          isLocalDiscovered: true,
          score: 95,
          confidence: 0.95,
          estimatedVramMb: estVram,
          vramRequiredGb: Math.round(estVram / 1024),
          truthState,
          requiredModelFamily: family,
          supportedResolutions: family === 'SD15' ? ['720p'] : ['720p', '1080p', '4K'],
          supportedFps: [24, 30],
          supportedPrecisions: precisions,
          missingDependencies: [],
          rationale,
          suggestedVae,
          suggestedLora
        };
      }
    }

    if (workflow === 'IMAGE_TO_VIDEO') {
      const svd = discovered.videoModels?.find(m => m.toLowerCase().includes('svd')) ||
        discovered.checkpoints?.find(m => m.toLowerCase().includes('svd'));

      if (svd) {
        const estVram = 8192;
        const truthState: ModelTruthState = estVram > availableVramMb ? 'INSUFFICIENT_MEMORY' : 'SELECTED';
        return {
          modelId: svd,
          name: svd,
          modelName: svd,
          workflow,
          category: 'SVD',
          isLocalDiscovered: true,
          score: 94,
          confidence: 0.94,
          estimatedVramMb: estVram,
          vramRequiredGb: 8,
          truthState,
          requiredModelFamily: 'SVD',
          supportedResolutions: ['720p', '1080p'],
          supportedFps: [24, 30],
          supportedPrecisions: ['fp16'],
          missingDependencies: [],
          rationale: `Stable Video Diffusion (SVD) image conditioning pipeline selected for temporal motion consistency.`
        };
      }
    }

    if (workflow === 'TEXT_TO_VIDEO') {
      const t2v = discovered.videoModels?.find(m => m.toLowerCase().includes('wan') || m.toLowerCase().includes('animate')) ||
        discovered.checkpoints?.find(m => m.toLowerCase().includes('animate'));

      if (t2v) {
        const estVram = 12288;
        const truthState: ModelTruthState = estVram > availableVramMb ? 'INSUFFICIENT_MEMORY' : 'SELECTED';
        const isWan = t2v.toLowerCase().includes('wan');
        return {
          modelId: t2v,
          name: t2v,
          modelName: t2v,
          workflow,
          category: 'WAN_VIDEO',
          isLocalDiscovered: true,
          score: 90,
          confidence: 0.90,
          estimatedVramMb: estVram,
          vramRequiredGb: 12,
          truthState,
          requiredModelFamily: isWan ? 'WAN21' : 'ANIMATEDIFF',
          supportedResolutions: ['720p', '1080p'],
          supportedFps: [24, 30],
          supportedPrecisions: ['fp16', 'bf16'],
          missingDependencies: [],
          rationale: `Discovered local video model '${t2v}' selected for text-driven video generation.`
        };
      }
    }

    if (workflow === 'MEDIA_ENHANCE') {
      if (discovered.upscalers && discovered.upscalers.length > 0) {
        const ultraSharp = discovered.upscalers.find(u => u.toLowerCase().includes('ultrasharp'));
        const esrgan = discovered.upscalers.find(u => u.toLowerCase().includes('esrgan'));
        const selected = ultraSharp || esrgan || discovered.upscalers[0];
        const estVram = is4K ? 3072 : 1024;

        return {
          modelId: selected,
          name: selected,
          modelName: selected,
          workflow,
          category: 'UPSCALER',
          isLocalDiscovered: true,
          score: 98,
          confidence: 0.98,
          estimatedVramMb: estVram,
          vramRequiredGb: is4K ? 3 : 1,
          truthState: 'SELECTED',
          requiredModelFamily: 'REAL_ESRGAN',
          supportedResolutions: ['720p', '1080p', '4K'],
          supportedFps: [24, 30, 60],
          supportedPrecisions: ['fp32', 'fp16'],
          missingDependencies: [],
          rationale: `High-fidelity neural upscaler '${selected}' selected for sub-pixel super-resolution.`
        };
      }
    }

    // 2. Fall back to Registered Manifest Catalog
    const compatibleInCatalog = catalog.filter(m => m.supportedWorkflows.includes(workflow));
    if (compatibleInCatalog.length > 0) {
      const best = compatibleInCatalog.sort((a, b) => {
        const aFit = (a.memoryConsumptionMb || 1024) <= availableVramMb;
        const bFit = (b.memoryConsumptionMb || 1024) <= availableVramMb;
        if (aFit && !bFit) return -1;
        if (!aFit && bFit) return 1;
        return (b.memoryConsumptionMb || 0) - (a.memoryConsumptionMb || 0);
      })[0];

      const estMb = best.memoryConsumptionMb || 2048;
      const isMemSafe = estMb <= availableVramMb;

      return {
        modelId: best.modelId,
        name: best.name,
        modelName: best.name,
        workflow,
        category: workflow === 'MEDIA_ENHANCE' ? 'UPSCALER' : 'CHECKPOINT',
        isLocalDiscovered: false,
        score: 80,
        confidence: 0.85,
        estimatedVramMb: estMb,
        vramRequiredGb: Math.round(estMb / 1024) || 2,
        truthState: isMemSafe ? 'AVAILABLE' : 'INSUFFICIENT_MEMORY',
        requiredModelFamily: 'GENERIC',
        supportedResolutions: ['720p', '1080p'],
        supportedFps: [24, 30],
        supportedPrecisions: ['fp16', 'fp32'],
        missingDependencies: [],
        rationale: `Standard registered manifest '${best.name}' recommended for ${workflow}.`
      };
    }

    // 3. Fallback when no models discovered
    return {
      modelId: 'sdxl-base-v1.0',
      name: 'SDXL Base v1.0 (Standard Recommended)',
      modelName: 'SDXL Base v1.0',
      workflow,
      category: 'CHECKPOINT',
      isLocalDiscovered: false,
      score: 70,
      confidence: 0.80,
      estimatedVramMb: 8192,
      vramRequiredGb: 8,
      truthState: 'REQUIRES_ENGINE',
      requiredModelFamily: 'SDXL',
      supportedResolutions: ['720p', '1080p'],
      supportedFps: [24, 30],
      supportedPrecisions: ['fp16'],
      missingDependencies: ['ComfyUI Server (127.0.0.1:8188)'],
      rationale: 'No local ComfyUI engine discovered. Start local ComfyUI to enable real neural generation.'
    };
  }

  /**
   * Evaluates the truth state and compatibility for a specific model selection.
   */
  public evaluateModelCompatibility(
    workflow: MediaWorkflowType,
    params: MediaJobParameters,
    discovered: ComfyUiDiscoveredModels,
    hardware: HardwareAuditReport,
    requestedModelId?: string
  ): {
    compatible: boolean;
    truthState: ModelTruthState;
    missingDependencies: string[];
    vramAdequate: boolean;
    rationale: string;
  } {
    const availableVramMb = (hardware.estimatedVramGb || hardware.totalVramGb || 8) * 1024;
    const recommendation = this.selectBestModel(workflow, params, discovered, hardware);

    if (recommendation.truthState === 'REQUIRES_ENGINE') {
      return {
        compatible: false,
        truthState: 'REQUIRES_ENGINE',
        missingDependencies: ['ComfyUI Server (127.0.0.1:8188)'],
        vramAdequate: true,
        rationale: 'Local neural inference server is offline.'
      };
    }

    if (recommendation.truthState === 'INSUFFICIENT_MEMORY') {
      return {
        compatible: false,
        truthState: 'INSUFFICIENT_MEMORY',
        missingDependencies: [],
        vramAdequate: false,
        rationale: `Model requires ${recommendation.vramRequiredGb}GB VRAM, but host has ${hardware.estimatedVramGb || 4}GB.`
      };
    }

    return {
      compatible: true,
      truthState: recommendation.truthState,
      missingDependencies: recommendation.missingDependencies,
      vramAdequate: recommendation.estimatedVramMb <= availableVramMb,
      rationale: recommendation.rationale
    };
  }
}
