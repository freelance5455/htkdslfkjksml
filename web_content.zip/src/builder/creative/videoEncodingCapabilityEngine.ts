/**
 * GODEX P4.7 — Video Encoding Capability Engine
 * 
 * Conducts empirical codec inspection, hardware acceleration discovery,
 * and truthful format negotiation across WebCodecs VideoEncoder and MediaRecorder.
 * 
 * Invariants:
 * - Never claims MP4 / H.264 is natively supported unless empirical browser API validates it.
 * - Truthfully reports SUPPORTED_OUTPUT = WEBM with explicit explanations when MP4 is unavailable.
 * - Emits REQUIRES_ENGINE when no browser-native video encoder exists.
 */

import { ExportCapability, ExportFormat } from './mediaAssemblyTypes';

export interface CodecInspectionResult {
  codecId: string;
  name: string;
  mimeType: string;
  container: 'WEBM' | 'MP4' | 'WAV' | 'IMAGE_SEQUENCE';
  videoCodec: string;
  audioCodec?: string;
  isSupported: boolean;
  encoderType: 'WEBCODECS' | 'MEDIA_RECORDER' | 'CANVAS_IMAGE' | 'DSP_BINARY' | 'NONE';
  hardwareAccelerated: boolean | 'UNKNOWN';
  truthState: 'AVAILABLE_BROWSER_NATIVE' | 'AVAILABLE_LOCALLY' | 'REQUIRES_ENGINE' | 'UNAVAILABLE';
  reason: string;
}

export interface VideoEncoderAuditReport {
  timestamp: number;
  webCodecsAvailable: boolean;
  webCodecsSupported: boolean;
  mediaRecorderAvailable: boolean;
  primaryVideoFormat: ExportFormat;
  recommendedFormat: ExportFormat;
  supportedFormats: ExportFormat[];
  allCapabilities: CodecInspectionResult[];
  codecs: CodecInspectionResult[];
  hardwareAccelerationTested: boolean;
  summary: string;
}

export type VideoCodecAuditReport = VideoEncoderAuditReport;

export class VideoEncodingCapabilityEngine {
  private static instance: VideoEncodingCapabilityEngine | null = null;
  private cachedAudit: VideoEncoderAuditReport | null = null;

  public static getInstance(): VideoEncodingCapabilityEngine {
    if (!VideoEncodingCapabilityEngine.instance) {
      VideoEncodingCapabilityEngine.instance = new VideoEncodingCapabilityEngine();
    }
    return VideoEncodingCapabilityEngine.instance;
  }

  /**
   * Alias for auditVideoEncoders
   */
  public async auditVideoEncoding(forceRefresh: boolean = false): Promise<VideoEncoderAuditReport> {
    return this.auditVideoEncoders(forceRefresh);
  }

  /**
   * Conducts exhaustive empirical probing of host video encoding capabilities.
   */
  public async auditVideoEncoders(forceRefresh: boolean = false): Promise<VideoEncoderAuditReport> {
    if (this.cachedAudit && !forceRefresh) {
      return this.cachedAudit;
    }

    const isBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';
    const hasMediaRecorder = isBrowser && typeof (window as any).MediaRecorder !== 'undefined';
    const hasWebCodecs = typeof VideoEncoder !== 'undefined' && typeof VideoFrame !== 'undefined';

    const results: CodecInspectionResult[] = [];
    const supportedFormats: ExportFormat[] = [];

    // 1. WebCodecs Hardware Acceleration Probe (async)
    let webCodecsHwAccel = false;
    let webCodecsVp9Supported = false;
    let webCodecsAvcSupported = false;

    if (hasWebCodecs) {
      try {
        const vp9Config = {
          codec: 'vp09.00.10.08',
          width: 1920,
          height: 1080,
          bitrate: 3_000_000,
          framerate: 30,
          hardwareAcceleration: 'prefer-hardware' as const
        };
        const vp9Check = await VideoEncoder.isConfigSupported(vp9Config);
        webCodecsVp9Supported = !!vp9Check.supported;
        if (vp9Check.config?.hardwareAcceleration === 'prefer-hardware') {
          webCodecsHwAccel = true;
        }

        const avcConfig = {
          codec: 'avc1.42001E', // Baseline profile
          width: 1920,
          height: 1080,
          bitrate: 3_000_000,
          framerate: 30,
          hardwareAcceleration: 'prefer-hardware' as const
        };
        const avcCheck = await VideoEncoder.isConfigSupported(avcConfig).catch(() => ({ supported: false }));
        webCodecsAvcSupported = !!avcCheck.supported;
      } catch (e) {
        console.warn('WebCodecs config probe failed:', e);
      }
    }

    // 2. WebM / VP9 Inspection
    let webmVp9Supported = false;
    if (hasMediaRecorder) {
      const MR = (window as any).MediaRecorder;
      webmVp9Supported = MR.isTypeSupported('video/webm;codecs=vp9,opus');
    }
    const webmSupported = webmVp9Supported || (hasMediaRecorder && (window as any).MediaRecorder.isTypeSupported('video/webm')) || webCodecsVp9Supported;

    if (webmSupported) {
      supportedFormats.push('WEBM');
    }

    results.push({
      codecId: 'webm-vp9',
      name: 'WebM (VP9 + Opus)',
      mimeType: 'video/webm;codecs=vp9,opus',
      container: 'WEBM',
      videoCodec: 'VP9',
      audioCodec: 'Opus',
      isSupported: webmSupported,
      encoderType: hasWebCodecs && webCodecsVp9Supported ? 'WEBCODECS' : hasMediaRecorder ? 'MEDIA_RECORDER' : 'NONE',
      hardwareAccelerated: webCodecsHwAccel ? true : 'UNKNOWN',
      truthState: webmSupported ? 'AVAILABLE_BROWSER_NATIVE' : 'UNAVAILABLE',
      reason: webmSupported
        ? `Native WebM encoding verified via ${hasWebCodecs && webCodecsVp9Supported ? 'WebCodecs VideoEncoder (Hardware Preferred)' : 'MediaRecorder API'}`
        : 'WebM encoding not supported in host environment.'
    });

    // 3. MP4 / H.264 Inspection (STRICT TRUTH - Never fabricate!)
    let mp4MediaRecorderSupported = false;
    if (hasMediaRecorder) {
      const MR = (window as any).MediaRecorder;
      mp4MediaRecorderSupported = MR.isTypeSupported('video/mp4;codecs=avc1') || MR.isTypeSupported('video/mp4');
    }
    const mp4Supported = mp4MediaRecorderSupported || webCodecsAvcSupported;

    if (mp4Supported) {
      supportedFormats.push('MP4');
    }

    results.push({
      codecId: 'mp4-avc1',
      name: 'MP4 (H.264 / AVC1)',
      mimeType: 'video/mp4;codecs=avc1',
      container: 'MP4',
      videoCodec: 'H.264 (AVC1)',
      audioCodec: 'AAC',
      isSupported: mp4Supported,
      encoderType: mp4Supported ? (webCodecsAvcSupported ? 'WEBCODECS' : 'MEDIA_RECORDER') : 'NONE',
      hardwareAccelerated: mp4Supported && webCodecsHwAccel ? true : 'UNKNOWN',
      truthState: mp4Supported ? 'AVAILABLE_BROWSER_NATIVE' : 'REQUIRES_ENGINE',
      reason: mp4Supported
        ? 'Native browser MP4 container encoding available'
        : 'MP4 container encoding is not natively exposed by current browser/webview runtime. Use WebM or connect an external ffmpeg transcoder.'
    });

    // 4. 16-bit WAV PCM Audio (Always natively available in JS/TS DSP!)
    supportedFormats.push('WAV');
    results.push({
      codecId: 'audio-wav',
      name: 'WAV Linear PCM',
      mimeType: 'audio/wav',
      container: 'WAV',
      videoCodec: 'NONE',
      audioCodec: 'PCM 16-bit LE',
      isSupported: true,
      encoderType: 'DSP_BINARY',
      hardwareAccelerated: false,
      truthState: 'AVAILABLE_LOCALLY',
      reason: 'Deterministic in-memory RIFF binary encoder'
    });

    // 5. PNG Image Sequence
    supportedFormats.push('PNG_SEQUENCE');
    results.push({
      codecId: 'seq-png',
      name: 'PNG Frame Sequence',
      mimeType: 'image/png',
      container: 'IMAGE_SEQUENCE',
      videoCodec: 'PNG Raster',
      isSupported: isBrowser,
      encoderType: isBrowser ? 'CANVAS_IMAGE' : 'NONE',
      hardwareAccelerated: 'UNKNOWN',
      truthState: isBrowser ? 'AVAILABLE_BROWSER_NATIVE' : 'UNAVAILABLE',
      reason: isBrowser ? 'Lossless raster frame sequence generator' : 'Headless environment missing Canvas2D'
    });

    // 6. JPEG Image Sequence
    supportedFormats.push('JPEG_SEQUENCE');
    results.push({
      codecId: 'seq-jpeg',
      name: 'JPEG Frame Sequence',
      mimeType: 'image/jpeg',
      container: 'IMAGE_SEQUENCE',
      videoCodec: 'JPEG Raster',
      isSupported: isBrowser,
      encoderType: isBrowser ? 'CANVAS_IMAGE' : 'NONE',
      hardwareAccelerated: 'UNKNOWN',
      truthState: isBrowser ? 'AVAILABLE_BROWSER_NATIVE' : 'UNAVAILABLE',
      reason: isBrowser ? 'Compressed raster frame sequence generator' : 'Headless environment missing Canvas2D'
    });

    const primaryVideoFormat: ExportFormat = webmSupported ? 'WEBM' : mp4Supported ? 'MP4' : 'WAV';

    const summary = `Primary: ${primaryVideoFormat} | WebM: ${webmSupported ? 'Native' : 'Unavailable'} | MP4: ${mp4Supported ? 'Native' : 'Requires Engine'} | WebCodecs: ${hasWebCodecs ? 'Present' : 'Absent'} | MediaRecorder: ${hasMediaRecorder ? 'Present' : 'Absent'}`;

    const report: VideoEncoderAuditReport = {
      timestamp: Date.now(),
      webCodecsAvailable: hasWebCodecs,
      webCodecsSupported: hasWebCodecs,
      mediaRecorderAvailable: hasMediaRecorder,
      primaryVideoFormat,
      recommendedFormat: primaryVideoFormat,
      supportedFormats,
      allCapabilities: results,
      codecs: results,
      hardwareAccelerationTested: hasWebCodecs,
      summary
    };

    this.cachedAudit = report;
    return report;
  }

  /**
   * Retrieves the best codec inspection result for a given format.
   */
  public getBestCodecForFormat(format: ExportFormat): CodecInspectionResult {
    const report = this.cachedAudit;
    const all = report ? report.allCapabilities : [];
    
    if (format === 'WEBM') {
      const found = all.find(c => c.container === 'WEBM');
      if (found) return found;
      return {
        codecId: 'webm-vp9',
        name: 'WebM (VP9 + Opus)',
        mimeType: 'video/webm;codecs=vp9,opus',
        container: 'WEBM',
        videoCodec: 'VP9',
        audioCodec: 'Opus',
        isSupported: false,
        encoderType: 'NONE',
        hardwareAccelerated: 'UNKNOWN',
        truthState: 'UNAVAILABLE',
        reason: 'WebM encoder not probed yet or unavailable'
      };
    }

    if (format === 'MP4') {
      const found = all.find(c => c.container === 'MP4');
      if (found) return found;
      return {
        codecId: 'mp4-avc1',
        name: 'MP4 (H.264 / AVC1)',
        mimeType: 'video/mp4;codecs=avc1',
        container: 'MP4',
        videoCodec: 'H.264 (AVC1)',
        audioCodec: 'AAC',
        isSupported: false,
        encoderType: 'NONE',
        hardwareAccelerated: 'UNKNOWN',
        truthState: 'REQUIRES_ENGINE',
        reason: 'MP4 encoder not natively available without external transcoder'
      };
    }

    return {
      codecId: 'audio-wav',
      name: 'WAV Linear PCM',
      mimeType: 'audio/wav',
      container: 'WAV',
      videoCodec: 'NONE',
      audioCodec: 'PCM 16-bit LE',
      isSupported: true,
      encoderType: 'DSP_BINARY',
      hardwareAccelerated: false,
      truthState: 'AVAILABLE_LOCALLY',
      reason: 'Deterministic in-memory RIFF binary encoder'
    };
  }

  /**
   * Converts audit results into standardized ExportCapability items.
   */
  public toExportCapabilities(report: VideoEncoderAuditReport): ExportCapability[] {
    return report.allCapabilities.map(c => {
      let format: ExportFormat = 'WEBM';
      if (c.container === 'MP4') format = 'MP4';
      else if (c.container === 'WAV') format = 'WAV';
      else if (c.mimeType === 'image/png') format = 'PNG_SEQUENCE';
      else if (c.mimeType === 'image/jpeg') format = 'JPEG_SEQUENCE';

      return {
        format,
        supported: c.isSupported,
        encoderName: `${c.encoderType === 'WEBCODECS' ? 'WebCodecs Hardware Encoder' : c.encoderType === 'MEDIA_RECORDER' ? 'Browser Native MediaRecorder' : c.encoderType === 'DSP_BINARY' ? 'GODEX DSP RIFF Encoder' : 'Canvas2D Rasterizer'} (${c.videoCodec || c.audioCodec})`,
        mimeType: c.mimeType,
        truthState: c.truthState,
        reason: c.reason,
        preferredCodec: c.videoCodec || c.audioCodec
      };
    });
  }
}
