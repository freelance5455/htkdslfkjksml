/**
 * GODEX P4.7 — Mobile Render Adaptation & Adaptive Profile Governor
 * 
 * Manages runtime adaptation of render parameters for mobile devices, constrained
 * browsers, and ultra-high-end workstations.
 * 
 * Features:
 * - Dynamic Profile Selection: MOBILE_SAFE, MOBILE_HIGH, TABLET, DESKTOP, DESKTOP_HIGH, 4K_CAPABLE
 * - Aspect Ratio & Resolution Presets (16:9, 9:16 Portrait, 1:1 Square, 21:9 Ultrawide, 4:3)
 * - Safe Fallback Chains with explicit reasons (Never silently downgrades)
 * - Frame Batch Sizing & Memory-Aware Release
 * - Adaptive Concurrency & Chunked DSP Audio Sizing
 */

import {
  AdaptiveRenderProfile,
  AspectRatioPreset,
  AssemblyComposition
} from './mediaAssemblyTypes';
import { DeviceCapabilityProfile, DeviceCapabilityProfiler } from './deviceCapabilityProfiler';

export interface AdaptivePlanConfig {
  profile: AdaptiveRenderProfile;
  resolution: { width: number; height: number };
  aspectRatio: AspectRatioPreset;
  fps: number;
  frameBatchSize: number;
  maxAudioChunkSec: number;
  maxSafeConcurrency: number;
  vfxComplexity: 'FULL' | 'REDUCED' | 'MINIMAL';
  isDowngraded: boolean;
  downgradeReason?: string;
  recommendedMemoryLimitMb: number;
}

export class MobileRenderAdapter {
  private static instance: MobileRenderAdapter | null = null;

  public static getInstance(): MobileRenderAdapter {
    if (!MobileRenderAdapter.instance) {
      MobileRenderAdapter.instance = new MobileRenderAdapter();
    }
    return MobileRenderAdapter.instance;
  }

  /**
   * Resolves standard resolution dimensions for a given aspect ratio and tier.
   */
  public getResolutionForTier(
    aspectRatio: AspectRatioPreset,
    tier: '4K' | '1080p' | '720p' | '480p'
  ): { width: number; height: number } {
    switch (aspectRatio) {
      case '16:9':
        if (tier === '4K') return { width: 3840, height: 2160 };
        if (tier === '1080p') return { width: 1920, height: 1080 };
        if (tier === '720p') return { width: 1280, height: 720 };
        return { width: 854, height: 480 };

      case '9:16':
        if (tier === '4K') return { width: 2160, height: 3840 };
        if (tier === '1080p') return { width: 1080, height: 1920 };
        if (tier === '720p') return { width: 720, height: 1280 };
        return { width: 480, height: 854 };

      case '1:1':
        if (tier === '4K') return { width: 2160, height: 2160 };
        if (tier === '1080p') return { width: 1080, height: 1080 };
        if (tier === '720p') return { width: 720, height: 720 };
        return { width: 480, height: 480 };

      case '21:9':
        if (tier === '4K') return { width: 3840, height: 1645 };
        if (tier === '1080p') return { width: 2560, height: 1080 };
        if (tier === '720p') return { width: 1920, height: 816 };
        return { width: 1120, height: 480 };

      case '4:3':
        if (tier === '4K') return { width: 2880, height: 2160 };
        if (tier === '1080p') return { width: 1440, height: 1080 };
        if (tier === '720p') return { width: 960, height: 720 };
        return { width: 640, height: 480 };
    }
  }

  /**
   * Derives the aspect ratio preset from composition dimensions.
   */
  public detectAspectRatio(width: number, height: number): AspectRatioPreset {
    const ratio = width / height;
    if (Math.abs(ratio - 16 / 9) < 0.05) return '16:9';
    if (Math.abs(ratio - 9 / 16) < 0.05) return '9:16';
    if (Math.abs(ratio - 1.0) < 0.05) return '1:1';
    if (Math.abs(ratio - 21 / 9) < 0.1 || Math.abs(ratio - 2.37) < 0.1) return '21:9';
    if (Math.abs(ratio - 4 / 3) < 0.05) return '4:3';
    return ratio >= 1.0 ? '16:9' : '9:16';
  }

  /**
   * Evaluates requested composition settings against empirical device capabilities
   * and computes a safe, non-crashing execution profile.
   */
  public adaptComposition(
    composition: AssemblyComposition,
    customProfile?: AdaptiveRenderProfile,
    customAspect?: AspectRatioPreset
  ): AdaptivePlanConfig {
    const profiler = DeviceCapabilityProfiler.getInstance();
    // Use cached profile if available or fallback
    const profile = customProfile || 'DESKTOP';
    const aspectRatio = customAspect || this.detectAspectRatio(composition.width, composition.height);

    let frameBatchSize = 16;
    let maxAudioChunkSec = 5.0;
    let maxSafeConcurrency = 2;
    let vfxComplexity: 'FULL' | 'REDUCED' | 'MINIMAL' = 'FULL';
    let recommendedMemoryLimitMb = 512;
    let isDowngraded = false;
    let downgradeReason: string | undefined = undefined;

    let targetTier: '4K' | '1080p' | '720p' | '480p' = '1080p';
    const reqPixels = composition.width * composition.height;

    if (reqPixels >= 3840 * 2160 * 0.9) targetTier = '4K';
    else if (reqPixels >= 1920 * 1080 * 0.9) targetTier = '1080p';
    else if (reqPixels >= 1280 * 720 * 0.9) targetTier = '720p';
    else targetTier = '480p';

    switch (profile) {
      case 'MOBILE_SAFE':
        frameBatchSize = 4;
        maxAudioChunkSec = 1.0;
        maxSafeConcurrency = 1;
        vfxComplexity = 'MINIMAL';
        recommendedMemoryLimitMb = 128;
        if (targetTier === '4K' || targetTier === '1080p') {
          targetTier = '720p';
          isDowngraded = true;
          downgradeReason = 'MOBILE_SAFE profile enforced 720p limit to prevent mobile browser memory exhaustion (< 128MB budget).';
        }
        break;

      case 'MOBILE_HIGH':
        frameBatchSize = 8;
        maxAudioChunkSec = 2.0;
        maxSafeConcurrency = 1;
        vfxComplexity = 'REDUCED';
        recommendedMemoryLimitMb = 256;
        if (targetTier === '4K') {
          targetTier = '1080p';
          isDowngraded = true;
          downgradeReason = 'MOBILE_HIGH profile downscaled 4K to 1080p to prevent mobile GPU context loss.';
        }
        break;

      case 'TABLET':
        frameBatchSize = 12;
        maxAudioChunkSec = 3.0;
        maxSafeConcurrency = 2;
        vfxComplexity = 'FULL';
        recommendedMemoryLimitMb = 384;
        if (targetTier === '4K') {
          targetTier = '1080p';
          isDowngraded = true;
          downgradeReason = 'TABLET profile downscaled 4K to 1080p to ensure continuous 60fps rasterization.';
        }
        break;

      case 'DESKTOP':
        frameBatchSize = 16;
        maxAudioChunkSec = 5.0;
        maxSafeConcurrency = 2;
        vfxComplexity = 'FULL';
        recommendedMemoryLimitMb = 768;
        if (targetTier === '4K') {
          targetTier = '1080p';
          isDowngraded = true;
          downgradeReason = 'Standard DESKTOP profile adjusted 4K to 1080p. Select 4K_CAPABLE profile to render at native 3840x2160.';
        }
        break;

      case 'DESKTOP_HIGH':
        frameBatchSize = 24;
        maxAudioChunkSec = 10.0;
        maxSafeConcurrency = 3;
        vfxComplexity = 'FULL';
        recommendedMemoryLimitMb = 1536;
        break;

      case '4K_CAPABLE':
        frameBatchSize = 32;
        maxAudioChunkSec = 10.0;
        maxSafeConcurrency = 4;
        vfxComplexity = 'FULL';
        recommendedMemoryLimitMb = 3072;
        targetTier = '4K';
        break;
    }

    const resolution = this.getResolutionForTier(aspectRatio, targetTier);

    return {
      profile,
      resolution,
      aspectRatio,
      fps: composition.fps,
      frameBatchSize,
      maxAudioChunkSec,
      maxSafeConcurrency,
      vfxComplexity,
      isDowngraded,
      downgradeReason,
      recommendedMemoryLimitMb
    };
  }

  /**
   * Returns a modified AssemblyComposition object adapted for a specific render profile.
   */
  public adaptCompositionForProfile(
    composition: AssemblyComposition,
    profile: AdaptiveRenderProfile
  ): AssemblyComposition {
    const plan = this.adaptComposition(composition, profile);
    return {
      ...composition,
      width: plan.resolution.width,
      height: plan.resolution.height,
      fps: (profile === 'MOBILE_SAFE' ? Math.min(composition.fps, 24) : composition.fps) as any
    };
  }

  /**
   * Applies an aspect ratio preset and produces an adapted composition for the given profile.
   */
  public applyAspectRatioPreset(
    composition: AssemblyComposition,
    preset: AspectRatioPreset,
    profile: AdaptiveRenderProfile = 'DESKTOP'
  ): AssemblyComposition {
    const plan = this.adaptComposition(composition, profile, preset);
    return {
      ...composition,
      width: plan.resolution.width,
      height: plan.resolution.height,
      fps: (profile === 'MOBILE_SAFE' ? Math.min(composition.fps, 24) : composition.fps) as any
    };
  }
}

