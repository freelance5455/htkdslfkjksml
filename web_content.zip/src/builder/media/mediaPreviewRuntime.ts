/**
 * GODEX P2.5 — Media Preview Runtime
 * Synchronized playback clock and real browser media preview controller.
 * Enforces Truth-First Invariants: Never reports PLAYING unless active clock loop is running.
 */

import {
  PlaybackEngineState,
  PlaybackClockEvent,
  PlaybackEventListener,
  TimelineStateData
} from './mediaTypes';
import { TimelineEngine } from './timelineEngine';

export interface PreviewRuntimeOptions {
  fps?: number;
  loop?: boolean;
  playbackRate?: number;
  onTimeUpdate?: (event: PlaybackClockEvent) => void;
  onStateChange?: (state: PlaybackEngineState) => void;
}

export class MediaPreviewRuntime {
  private timeline: TimelineStateData;
  private state: PlaybackEngineState = 'IDLE';
  private currentTime: number = 0;
  private playbackRate: number = 1.0;
  private loop: boolean = false;
  private fps: number = 30;
  private listeners: Set<PlaybackEventListener> = new Set();
  
  private animationFrameId: number | null = null;
  private intervalId: any | null = null;
  private lastTickTimestamp: number = 0;

  constructor(initialTimeline?: TimelineStateData, options?: PreviewRuntimeOptions) {
    this.timeline = initialTimeline || TimelineEngine.createEmptyTimeline();
    this.fps = options?.fps || this.timeline.fps || 30;
    this.loop = options?.loop ?? this.timeline.loop ?? false;
    this.playbackRate = options?.playbackRate ?? 1.0;

    if (options?.onTimeUpdate) {
      this.listeners.add(options.onTimeUpdate);
    }
  }

  /**
   * Updates reference to the timeline state.
   */
  public setTimeline(timeline: TimelineStateData): void {
    this.timeline = timeline;
    this.fps = timeline.fps || this.fps;
    if (this.currentTime > timeline.duration && timeline.duration > 0) {
      this.seek(timeline.duration);
    }
  }

  public getTimeline(): TimelineStateData {
    return this.timeline;
  }

  public getState(): PlaybackEngineState {
    return this.state;
  }

  public getCurrentTime(): number {
    return this.currentTime;
  }

  public getCurrentFrame(): number {
    return TimelineEngine.timeToFrame(this.currentTime, this.fps);
  }

  public getDuration(): number {
    return this.timeline.duration;
  }

  public getFps(): number {
    return this.fps;
  }

  public getPlaybackRate(): number {
    return this.playbackRate;
  }

  public isPlaying(): boolean {
    return this.state === 'PLAYING';
  }

  public isLooping(): boolean {
    return this.loop;
  }

  /**
   * Starts playback clock.
   */
  public play(): boolean {
    if (this.timeline.duration <= 0) {
      this.state = 'IDLE';
      this.emitClockEvent();
      return false;
    }

    // If at end, wrap back to start
    if (this.currentTime >= this.timeline.duration) {
      this.currentTime = 0;
    }

    this.state = 'PLAYING';
    this.lastTickTimestamp = Date.now();

    this.stopTicker();
    this.startTicker();
    this.emitClockEvent();
    return true;
  }

  /**
   * Pauses playback clock.
   */
  public pause(): void {
    this.state = 'PAUSED';
    this.stopTicker();
    this.emitClockEvent();
  }

  /**
   * Toggles play / pause state.
   */
  public togglePlay(): boolean {
    if (this.state === 'PLAYING') {
      this.pause();
      return false;
    } else {
      return this.play();
    }
  }

  /**
   * Seeks to exact time in seconds.
   */
  public seek(seconds: number): void {
    const clamped = Math.max(0, Math.min(this.timeline.duration, seconds));
    this.currentTime = Number(clamped.toFixed(4));
    
    if (this.currentTime >= this.timeline.duration && this.state === 'PLAYING' && !this.loop) {
      this.pause();
      this.state = 'ENDED';
    }

    this.emitClockEvent();
  }

  /**
   * Steps forward or backward by an integer number of frames.
   */
  public stepFrames(frameCount: number): void {
    if (this.state === 'PLAYING') {
      this.pause();
    }

    const currentFrame = this.getCurrentFrame();
    const targetFrame = Math.max(0, currentFrame + frameCount);
    const targetTime = TimelineEngine.frameToTime(targetFrame, this.fps);
    this.seek(targetTime);
  }

  public setPlaybackRate(rate: number): void {
    this.playbackRate = Math.max(0.25, Math.min(8.0, rate));
  }

  public setLoop(loop: boolean): void {
    this.loop = loop;
  }

  public addListener(listener: PlaybackEventListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  public removeListener(listener: PlaybackEventListener): void {
    this.listeners.delete(listener);
  }

  /**
   * Manually steps clock for deterministic testing or simulated frame advances.
   */
  public advanceTimeManual(deltaSeconds: number): void {
    if (this.timeline.duration <= 0) return;

    this.currentTime += deltaSeconds * this.playbackRate;

    if (this.currentTime >= this.timeline.duration) {
      if (this.loop) {
        this.currentTime = this.currentTime % this.timeline.duration;
      } else {
        this.currentTime = this.timeline.duration;
        this.state = 'ENDED';
        this.stopTicker();
      }
    }

    this.emitClockEvent();
  }

  private startTicker(): void {
    if (typeof window !== 'undefined' && typeof window.requestAnimationFrame === 'function') {
      const loop = () => {
        if (this.state !== 'PLAYING') return;

        const now = Date.now();
        const deltaMs = now - this.lastTickTimestamp;
        this.lastTickTimestamp = now;

        const deltaSecs = deltaMs / 1000;
        this.advanceTimeManual(deltaSecs);

        if (this.state === 'PLAYING') {
          this.animationFrameId = window.requestAnimationFrame(loop);
        }
      };
      this.animationFrameId = window.requestAnimationFrame(loop);
    } else {
      // Node/headless fallback interval
      const intervalMs = Math.round(1000 / this.fps);
      this.intervalId = setInterval(() => {
        if (this.state !== 'PLAYING') return;
        const deltaSecs = intervalMs / 1000;
        this.advanceTimeManual(deltaSecs);
      }, intervalMs);
    }
  }

  private stopTicker(): void {
    if (this.animationFrameId !== null && typeof window !== 'undefined') {
      window.cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    if (this.intervalId !== null) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  private emitClockEvent(): void {
    const activeClips = TimelineEngine.getClipsAtTime(this.timeline, this.currentTime);
    const event: PlaybackClockEvent = {
      currentTime: this.currentTime,
      currentFrame: this.getCurrentFrame(),
      fps: this.fps,
      duration: this.timeline.duration,
      state: this.state,
      activeClipIds: activeClips.map(a => a.clip.id)
    };

    for (const listener of this.listeners) {
      try {
        listener(event);
      } catch (err) {
        console.error('Error in playback clock event listener:', err);
      }
    }
  }

  public dispose(): void {
    this.stopTicker();
    this.listeners.clear();
    this.state = 'IDLE';
  }
}
