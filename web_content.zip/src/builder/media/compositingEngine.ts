/**
 * GODEX P2.5 — Creative Compositing Engine
 * Multi-layer alpha compositing, blend modes, 2D transforms, filter stacks,
 * text overlays, and audio channel gain/pan DSP calculations.
 */

import {
  CompositorLayerData,
  LayerBlendMode,
  LayerTransform,
  LayerFilterStack,
  TextOverlaySpec
} from './mediaTypes';

export class CompositingEngine {
  /**
   * Maps creative blend modes to standard HTML5 Canvas globalCompositeOperation strings.
   */
  public static mapBlendModeToCompositeOp(blendMode: LayerBlendMode): GlobalCompositeOperation {
    switch (blendMode) {
      case 'multiply':
        return 'multiply';
      case 'screen':
        return 'screen';
      case 'overlay':
        return 'overlay';
      case 'darken':
        return 'darken';
      case 'lighten':
        return 'lighten';
      case 'color-dodge':
        return 'color-dodge';
      case 'color-burn':
        return 'color-burn';
      case 'hard-light':
        return 'hard-light';
      case 'soft-light':
        return 'soft-light';
      case 'difference':
        return 'difference';
      case 'exclusion':
        return 'exclusion';
      case 'normal':
      default:
        return 'source-over';
    }
  }

  /**
   * Generates a CSS / Canvas 2D filter string from filter parameters.
   */
  public static buildFilterString(filters: Partial<LayerFilterStack>): string {
    const parts: string[] = [];

    if (filters.brightness !== undefined && filters.brightness !== 100) {
      parts.push(`brightness(${Math.max(0, filters.brightness)}%)`);
    }
    if (filters.contrast !== undefined && filters.contrast !== 100) {
      parts.push(`contrast(${Math.max(0, filters.contrast)}%)`);
    }
    if (filters.saturation !== undefined && filters.saturation !== 100) {
      parts.push(`saturate(${Math.max(0, filters.saturation)}%)`);
    }
    if (filters.blur !== undefined && filters.blur > 0) {
      parts.push(`blur(${Math.max(0, filters.blur)}px)`);
    }
    if (filters.grayscale !== undefined && filters.grayscale > 0) {
      parts.push(`grayscale(${Math.min(100, Math.max(0, filters.grayscale))}%)`);
    }
    if (filters.invert !== undefined && filters.invert > 0) {
      parts.push(`invert(${Math.min(100, Math.max(0, filters.invert))}%)`);
    }
    if (filters.sepia !== undefined && filters.sepia > 0) {
      parts.push(`sepia(${Math.min(100, Math.max(0, filters.sepia))}%)`);
    }
    if (filters.hueRotate !== undefined && filters.hueRotate !== 0) {
      parts.push(`hue-rotate(${filters.hueRotate}deg)`);
    }

    return parts.length > 0 ? parts.join(' ') : 'none';
  }

  /**
   * Creates a default layer transform object.
   */
  public static createDefaultTransform(): LayerTransform {
    return {
      x: 0,
      y: 0,
      scaleX: 1.0,
      scaleY: 1.0,
      rotation: 0,
      anchorX: 0.5,
      anchorY: 0.5
    };
  }

  /**
   * Creates a default layer filter stack.
   */
  public static createDefaultFilters(): LayerFilterStack {
    return {
      brightness: 100,
      contrast: 100,
      saturation: 100,
      blur: 0,
      grayscale: 0,
      invert: 0,
      sepia: 0,
      hueRotate: 0,
      opacity: 1.0
    };
  }

  /**
   * Creates a structured compositor layer.
   */
  public static createLayer(
    name: string,
    type: CompositorLayerData['type'],
    options?: Partial<CompositorLayerData>
  ): CompositorLayerData {
    return {
      id: `layer-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      name,
      type,
      isVisible: options?.isVisible ?? true,
      isLocked: options?.isLocked ?? false,
      opacity: options?.opacity ?? 1.0,
      blendMode: options?.blendMode ?? 'normal',
      zIndex: options?.zIndex ?? 0,
      transform: options?.transform ?? this.createDefaultTransform(),
      filters: options?.filters ?? this.createDefaultFilters(),
      textSpec: options?.textSpec,
      sourceUri: options?.sourceUri,
      canvasDrawer: options?.canvasDrawer
    };
  }

  /**
   * Sorts and filters layers ready for compositing render pass.
   */
  public static getVisibleRenderStack(layers: CompositorLayerData[]): CompositorLayerData[] {
    return [...layers]
      .filter(l => l.isVisible && l.opacity > 0)
      .sort((a, b) => a.zIndex - b.zIndex);
  }

  /**
   * Renders a layer stack onto a 2D canvas context.
   */
  public static renderStack(
    ctx: CanvasRenderingContext2D,
    layers: CompositorLayerData[],
    width: number,
    height: number
  ): void {
    ctx.save();
    ctx.clearRect(0, 0, width, height);

    const renderStack = this.getVisibleRenderStack(layers);

    for (const layer of renderStack) {
      ctx.save();

      // Set global alpha and blend mode
      ctx.globalAlpha = Math.max(0, Math.min(1.0, layer.opacity * (layer.filters.opacity ?? 1.0)));
      ctx.globalCompositeOperation = this.mapBlendModeToCompositeOp(layer.blendMode);

      // Apply CSS / Canvas filters if supported
      const filterStr = this.buildFilterString(layer.filters);
      if (filterStr !== 'none' && 'filter' in ctx) {
        try {
          ctx.filter = filterStr;
        } catch {
          // Fallback if browser context rejects filter string
        }
      }

      // Apply 2D transforms around anchor
      const tf = layer.transform;
      const posX = tf.x <= 1.0 && tf.x >= 0 ? tf.x * width : tf.x;
      const posY = tf.y <= 1.0 && tf.y >= 0 ? tf.y * height : tf.y;

      ctx.translate(posX, posY);
      if (tf.rotation !== 0) {
        ctx.rotate((tf.rotation * Math.PI) / 180);
      }
      if (tf.scaleX !== 1.0 || tf.scaleY !== 1.0) {
        ctx.scale(tf.scaleX, tf.scaleY);
      }

      // Render layer content based on type
      switch (layer.type) {
        case 'TEXT':
          if (layer.textSpec) {
            this.renderTextOverlay(ctx, layer.textSpec);
          }
          break;

        case 'SOLID_COLOR':
          ctx.fillStyle = layer.sourceUri || '#6366f1';
          ctx.fillRect(-width * tf.anchorX, -height * tf.anchorY, width, height);
          break;

        case 'CANVAS_DRAW':
          if (layer.canvasDrawer) {
            layer.canvasDrawer(ctx, width, height);
          }
          break;

        default:
          // Placeholder raster frame if no direct ImageElement available
          ctx.fillStyle = 'rgba(99, 102, 241, 0.15)';
          ctx.fillRect(-100, -60, 200, 120);
          ctx.strokeStyle = '#818cf8';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(-100, -60, 200, 120);
          break;
      }

      ctx.restore();
    }

    ctx.restore();
  }

  /**
   * Renders a text overlay onto the canvas context.
   */
  public static renderTextOverlay(ctx: CanvasRenderingContext2D, spec: TextOverlaySpec): void {
    ctx.save();
    const fontSize = spec.fontSize || 24;
    const fontFamily = spec.fontFamily || 'Inter, sans-serif';
    const fontWeight = spec.fontWeight || 'bold';
    ctx.font = `${fontWeight} ${fontSize}px ${fontFamily}`;
    ctx.textAlign = spec.textAlign || 'center';
    ctx.textBaseline = 'middle';

    const text = spec.text || '';
    const metrics = ctx.measureText(text);
    const textWidth = metrics.width;
    const textHeight = fontSize * 1.2;

    // Optional background box
    if (spec.backgroundColor) {
      const padding = spec.backgroundPadding ?? 8;
      const bgX = spec.textAlign === 'center' ? -textWidth / 2 - padding : spec.textAlign === 'right' ? -textWidth - padding : -padding;
      const bgY = -textHeight / 2 - padding;
      const bgW = textWidth + padding * 2;
      const bgH = textHeight + padding * 2;

      ctx.fillStyle = spec.backgroundColor;
      if (spec.borderRadius && spec.borderRadius > 0 && typeof ctx.roundRect === 'function') {
        ctx.beginPath();
        ctx.roundRect(bgX, bgY, bgW, bgH, spec.borderRadius);
        ctx.fill();
      } else {
        ctx.fillRect(bgX, bgY, bgW, bgH);
      }
    }

    // Optional stroke
    if (spec.strokeColor && (spec.strokeWidth ?? 0) > 0) {
      ctx.strokeStyle = spec.strokeColor;
      ctx.lineWidth = spec.strokeWidth!;
      ctx.strokeText(text, 0, 0);
    }

    // Text fill
    ctx.fillStyle = spec.color || '#ffffff';
    ctx.fillText(text, 0, 0);

    ctx.restore();
  }

  // ==========================================================================
  // AUDIO DSP / CHANNEL MIXING FORMULAS
  // ==========================================================================

  /**
   * Converts linear amplitude gain (0.0 to 2.0) to decibels (dB).
   */
  public static gainToDb(gain: number): number {
    if (gain <= 0.0001) return -96.0; // Digital floor
    const db = 20 * Math.log10(gain);
    return Number(db.toFixed(1));
  }

  /**
   * Converts decibels (dB) to linear amplitude gain.
   */
  public static dbToGain(db: number): number {
    if (db <= -96.0) return 0.0;
    const gain = Math.pow(10, db / 20);
    return Number(gain.toFixed(4));
  }

  /**
   * Calculates stereo pan gain coefficients using constant power panning law.
   * Pan range: -1.0 (Full Left) to +1.0 (Full Right), 0.0 (Center).
   */
  public static calculatePanGains(pan: number): { leftGain: number; rightGain: number } {
    const clampedPan = Math.max(-1.0, Math.min(1.0, pan));
    // Angle in radians from 0 (Left) to PI/2 (Right)
    const angle = ((clampedPan + 1.0) / 2.0) * (Math.PI / 2);
    const leftGain = Math.cos(angle);
    const rightGain = Math.sin(angle);
    return {
      leftGain: Number(leftGain.toFixed(4)),
      rightGain: Number(rightGain.toFixed(4))
    };
  }
}
