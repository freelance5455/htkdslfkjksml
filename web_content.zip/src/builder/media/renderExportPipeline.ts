/**
 * GODEX P2.5 — Render & Export Job Pipeline
 * Manages the full lifecycle of media rendering and export jobs:
 * QUEUED -> RUNNING -> COMPLETED / FAILED / CANCELLED.
 * Enforces Truth-First Invariant: Never fabricates render output if failed or cancelled.
 */

import {
  RenderJobSpec,
  RenderJobProgress,
  RenderJobStatus,
  RenderJobExecutionResult
} from './mediaTypes';

export type RenderProgressListener = (progress: RenderJobProgress) => void;

export class RenderExportPipeline {
  private jobs: Map<string, RenderJobSpec> = new Map();
  private jobStatuses: Map<string, RenderJobProgress> = new Map();
  private cancellationTokens: Map<string, boolean> = new Map();
  private listeners: Map<string, Set<RenderProgressListener>> = new Map();

  /**
   * Enqueues a new render job.
   */
  public enqueueJob(spec: Omit<RenderJobSpec, 'id'> & { id?: string }): RenderJobProgress {
    const jobId = spec.id || `render-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const fullSpec: RenderJobSpec = {
      ...spec,
      id: jobId
    };

    const totalFrames = Math.max(1, Math.round(fullSpec.durationSeconds * fullSpec.fps));

    const progress: RenderJobProgress = {
      jobId,
      status: 'QUEUED',
      progressPercent: 0,
      currentFrame: 0,
      totalFrames,
      fpsRenderRate: 0,
      estimatedTimeRemainingSeconds: Math.ceil(totalFrames / (fullSpec.fps * 2))
    };

    this.jobs.set(jobId, fullSpec);
    this.jobStatuses.set(jobId, progress);
    this.cancellationTokens.set(jobId, false);

    return progress;
  }

  /**
   * Retrieves the current progress and status of a job.
   */
  public getJobProgress(jobId: string): RenderJobProgress | undefined {
    return this.jobStatuses.get(jobId);
  }

  /**
   * Cancels a running or queued job.
   */
  public cancelJob(jobId: string): boolean {
    const progress = this.jobStatuses.get(jobId);
    if (!progress) return false;

    if (progress.status === 'COMPLETED' || progress.status === 'FAILED' || progress.status === 'CANCELLED') {
      return false;
    }

    this.cancellationTokens.set(jobId, true);
    progress.status = 'CANCELLED';
    progress.completedAt = Date.now();
    this.emitProgress(jobId, progress);
    return true;
  }

  /**
   * Executes a render job cooperatively, tracking progress and cancellation.
   */
  public async executeRenderJob(
    jobId: string,
    renderFrameFn?: (frame: number, totalFrames: number) => Promise<void> | void
  ): Promise<RenderJobExecutionResult> {
    const spec = this.jobs.get(jobId);
    const progress = this.jobStatuses.get(jobId);

    if (!spec || !progress) {
      throw new Error(`Job "${jobId}" not found in render queue.`);
    }

    const startTime = Date.now();
    progress.status = 'RUNNING';
    progress.startedAt = startTime;
    this.emitProgress(jobId, progress);

    const totalFrames = progress.totalFrames;

    try {
      for (let frame = 1; frame <= totalFrames; frame++) {
        // Check for cancellation
        if (this.cancellationTokens.get(jobId) === true) {
          progress.status = 'CANCELLED';
          progress.completedAt = Date.now();
          this.emitProgress(jobId, progress);
          return {
            jobId,
            status: 'CANCELLED',
            durationSeconds: (Date.now() - startTime) / 1000,
            totalFramesRendered: frame - 1,
            outputSizeBytes: 0,
            executionDurationMs: Date.now() - startTime,
            cancelled: true
          };
        }

        // Render individual frame if function provided
        if (renderFrameFn) {
          await renderFrameFn(frame, totalFrames);
        }

        // Update progress
        const percent = Number(((frame / totalFrames) * 100).toFixed(1));
        const elapsedSecs = (Date.now() - startTime) / 1000;
        const fpsRenderRate = elapsedSecs > 0 ? Number((frame / elapsedSecs).toFixed(1)) : 0;
        const remainingFrames = totalFrames - frame;
        const estimatedRemaining = fpsRenderRate > 0 ? Number((remainingFrames / fpsRenderRate).toFixed(1)) : 0;

        progress.currentFrame = frame;
        progress.progressPercent = percent;
        progress.fpsRenderRate = fpsRenderRate;
        progress.estimatedTimeRemainingSeconds = estimatedRemaining;

        // Emit at 10% intervals or frame boundaries
        if (frame % Math.max(1, Math.floor(totalFrames / 10)) === 0 || frame === totalFrames) {
          this.emitProgress(jobId, progress);
        }
      }

      // Mark completed
      const totalElapsedMs = Date.now() - startTime;
      const estimatedSizeBytes = Math.round(spec.resolution.width * spec.resolution.height * 0.15 * spec.durationSeconds);
      const outputUrl = `blob:render-output://${spec.id}.${spec.format.toLowerCase()}`;

      progress.status = 'COMPLETED';
      progress.progressPercent = 100.0;
      progress.currentFrame = totalFrames;
      progress.completedAt = Date.now();
      progress.outputUrl = outputUrl;
      progress.outputSizeBytes = estimatedSizeBytes;
      this.emitProgress(jobId, progress);

      return {
        jobId,
        status: 'COMPLETED',
        durationSeconds: spec.durationSeconds,
        totalFramesRendered: totalFrames,
        outputSizeBytes: estimatedSizeBytes,
        outputUrl,
        executionDurationMs: totalElapsedMs,
        cancelled: false
      };
    } catch (err: any) {
      progress.status = 'FAILED';
      progress.error = err.message || 'Render pipeline encounter fatal error.';
      progress.completedAt = Date.now();
      this.emitProgress(jobId, progress);

      return {
        jobId,
        status: 'FAILED',
        durationSeconds: 0,
        totalFramesRendered: progress.currentFrame,
        outputSizeBytes: 0,
        executionDurationMs: Date.now() - startTime,
        error: progress.error,
        cancelled: false
      };
    }
  }

  public addProgressListener(jobId: string, listener: RenderProgressListener): () => void {
    if (!this.listeners.has(jobId)) {
      this.listeners.set(jobId, new Set());
    }
    this.listeners.get(jobId)!.add(listener);
    return () => {
      this.listeners.get(jobId)?.delete(listener);
    };
  }

  private emitProgress(jobId: string, progress: RenderJobProgress): void {
    const jobListeners = this.listeners.get(jobId);
    if (jobListeners) {
      for (const listener of jobListeners) {
        try {
          listener({ ...progress });
        } catch (err) {
          console.error(`Error in render progress listener for ${jobId}:`, err);
        }
      }
    }
  }
}
