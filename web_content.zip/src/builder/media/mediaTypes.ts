/**
 * GODEX P2.5 — Real Creative Media Runtime Types
 * Authoritative type definitions for media asset ingestion, timeline sequencing,
 * preview playback, creative compositing, image processing, and render export pipelines.
 */

import { CapabilityStatus } from '../builderTypes';

// ============================================================================
// 1. MEDIA ASSET TYPES
// ============================================================================

export type AssetType = 'VIDEO' | 'AUDIO' | 'IMAGE' | 'VECTOR' | 'TEXT' | '3D_MODEL' | 'UNKNOWN';

export type AssetLifecycleStatus = 'INITIALIZING' | 'ANALYZING' | 'READY' | 'CORRUPT' | 'UNSUPPORTED';

export interface AssetResolution {
  width: number;
  height: number;
  aspectRatio: string; // e.g. '16:9', '9:16', '1:1', '4:3', '21:9'
}

export interface MediaAssetMetadata {
  durationSeconds?: number;
  resolution?: AssetResolution;
  frameRate?: number;
  sampleRate?: number;
  audioChannels?: number;
  bitrateKbps?: number;
  codec?: string;
  hasAlphaChannel?: boolean;
  colorSpace?: string;
}

export interface MediaAssetRecord {
  id: string;
  name: string;
  type: AssetType;
  uri: string;
  mimeType: string;
  sizeBytes: number;
  status: AssetLifecycleStatus;
  metadata: MediaAssetMetadata;
  tags: string[];
  isBrowserPlayable: boolean;
  createdAt: number;
  updatedAt: number;
  errorMessage?: string;
}

export interface AssetInspectionResult {
  valid: boolean;
  asset?: MediaAssetRecord;
  status: AssetLifecycleStatus;
  mimeType: string;
  sizeBytes: number;
  isBrowserSupported: boolean;
  capabilityStatus: CapabilityStatus;
  errors: string[];
  warnings: string[];
  epistemicNote?: string;
}

// ============================================================================
// 2. TIMELINE TYPES
// ============================================================================

export type TrackType = 'VIDEO' | 'AUDIO' | 'OVERLAY' | 'SUBTITLE' | 'EFFECT' | 'GRAPHICS';

export interface TimelineClipData {
  id: string;
  trackId: string;
  assetId: string;
  name: string;
  startTime: number; // Timestamp on timeline in seconds
  duration: number;  // Duration on timeline in seconds
  offsetStart: number; // Source start offset (trimIn)
  trimIn: number;     // Left trim point in source seconds
  trimOut: number;    // Right trim point in source seconds
  speed: number;      // 0.25 to 16.0
  volume: number;     // 0.0 to 2.0 (1.0 = 0dB)
  opacity: number;    // 0 to 100
  blendMode: 'normal' | 'multiply' | 'screen' | 'overlay' | 'darken' | 'lighten' | 'color-dodge';
  effects: TimelineEffect[];
  keyframes: TimelineKeyframe[];
}

export interface TimelineTrackData {
  id: string;
  name: string;
  type: TrackType;
  order: number;
  isMuted: boolean;
  isSolo: boolean;
  isLocked: boolean;
  isHidden: boolean;
  volume: number; // 0.0 to 2.0
  pan: number;    // -1.0 (Left) to +1.0 (Right)
  clips: TimelineClipData[];
}

export interface TimelineEffect {
  id: string;
  type: 'COLOR_GRADE' | 'BLUR' | 'VIGNETTE' | 'CHROMA_KEY' | 'GLITCH' | 'FILM_GRAIN' | 'TRANSFORM' | 'EQ';
  name: string;
  isEnabled: boolean;
  parameters: Record<string, number | string | boolean>;
}

export interface TimelineKeyframe {
  id: string;
  time: number; // Seconds relative to clip start
  property: string;
  value: number | string;
  interpolation: 'LINEAR' | 'BEZIER' | 'HOLD' | 'EXPONENTIAL';
}

export interface TimelineStateData {
  id: string;
  projectId: string;
  duration: number; // Total calculated sequence length in seconds
  currentTime: number; // Playhead position in seconds
  fps: number; // 24, 25, 30, 60
  tracks: TimelineTrackData[];
  selectedClipIds: string[];
  selectedTrackId?: string;
  isPlaying: boolean;
  zoomLevel: number; // 0.1 to 10.0
  loop: boolean;
  inPoint?: number;
  outPoint?: number;
}

// ============================================================================
// 3. PREVIEW & PLAYBACK RUNTIME TYPES
// ============================================================================

export type PlaybackEngineState = 'IDLE' | 'PLAYING' | 'PAUSED' | 'BUFFERING' | 'ENDED' | 'ERROR';

export interface PlaybackClockEvent {
  currentTime: number;
  currentFrame: number;
  fps: number;
  duration: number;
  state: PlaybackEngineState;
  activeClipIds: string[];
}

export type PlaybackEventListener = (event: PlaybackClockEvent) => void;

// ============================================================================
// 4. COMPOSITING & LAYER TYPES
// ============================================================================

export type LayerBlendMode = 
  | 'normal' 
  | 'multiply' 
  | 'screen' 
  | 'overlay' 
  | 'darken' 
  | 'lighten' 
  | 'color-dodge' 
  | 'color-burn' 
  | 'hard-light' 
  | 'soft-light' 
  | 'difference' 
  | 'exclusion';

export interface LayerTransform {
  x: number;       // Normalized or pixel X
  y: number;       // Normalized or pixel Y
  scaleX: number;  // 1.0 = 100%
  scaleY: number;  // 1.0 = 100%
  rotation: number; // In degrees (-360 to +360)
  anchorX: number; // 0.5 = center
  anchorY: number; // 0.5 = center
}

export interface LayerFilterStack {
  brightness: number; // 100 = default (%)
  contrast: number;   // 100 = default (%)
  saturation: number; // 100 = default (%)
  blur: number;       // 0 = default (px)
  grayscale: number;  // 0 = default (%)
  invert: number;     // 0 = default (%)
  sepia: number;      // 0 = default (%)
  hueRotate: number;  // 0 = default (deg)
  opacity: number;    // 1.0 = 100%
}

export interface TextOverlaySpec {
  text: string;
  fontFamily: string;
  fontSize: number;
  fontWeight: 'normal' | 'bold' | '600' | '800';
  color: string;
  textAlign: 'left' | 'center' | 'right';
  strokeColor?: string;
  strokeWidth?: number;
  backgroundColor?: string;
  backgroundPadding?: number;
  borderRadius?: number;
}

export interface CompositorLayerData {
  id: string;
  name: string;
  type: 'IMAGE' | 'VIDEO_FRAME' | 'TEXT' | 'VECTOR' | 'SOLID_COLOR' | 'CANVAS_DRAW';
  isVisible: boolean;
  isLocked: boolean;
  opacity: number; // 0.0 to 1.0
  blendMode: LayerBlendMode;
  zIndex: number;
  transform: LayerTransform;
  filters: LayerFilterStack;
  textSpec?: TextOverlaySpec;
  sourceUri?: string;
  canvasDrawer?: (ctx: CanvasRenderingContext2D, width: number, height: number) => void;
}

// ============================================================================
// 5. IMAGE PROCESSING TYPES
// ============================================================================

export interface CropRectangle {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface ColorAdjustmentParameters {
  brightness: number; // -100 to +100 (0 = neutral)
  contrast: number;   // -100 to +100 (0 = neutral)
  saturation: number; // -100 to +100 (0 = neutral)
  exposure: number;   // -100 to +100 (0 = neutral)
  temperature: number;// -100 (cool/blue) to +100 (warm/amber)
  tint: number;       // -100 (green) to +100 (magenta)
  vignette: number;   // 0 to 100
}

export interface ImageProcessingExportOptions {
  format: 'image/png' | 'image/jpeg' | 'image/webp';
  quality?: number; // 0.1 to 1.0 (for jpeg/webp)
  targetWidth?: number;
  targetHeight?: number;
  maintainAspectRatio?: boolean;
}

export interface ProcessedImageResult {
  success: boolean;
  dataUrl?: string;
  blob?: Blob;
  width: number;
  height: number;
  format: string;
  sizeBytes: number;
  executionDurationMs: number;
  error?: string;
}

// ============================================================================
// 6. RENDER & EXPORT JOB TYPES
// ============================================================================

export type RenderJobStatus = 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';

export type RenderExportFormat = 'MP4' | 'WEBM' | 'GIF' | 'PNG_SEQUENCE' | 'WAV' | 'PNG' | 'JPEG' | 'WEBP';

export interface RenderJobSpec {
  id: string;
  projectId: string;
  title: string;
  format: RenderExportFormat;
  resolution: { width: number; height: number; aspectRatio: string };
  fps: number;
  durationSeconds: number;
  includeAudio: boolean;
  quality: 'DRAFT' | 'STANDARD' | 'HIGH' | 'MAXIMUM';
}

export interface RenderJobProgress {
  jobId: string;
  status: RenderJobStatus;
  progressPercent: number; // 0.0 to 100.0
  currentFrame: number;
  totalFrames: number;
  fpsRenderRate: number;
  estimatedTimeRemainingSeconds: number;
  startedAt?: number;
  completedAt?: number;
  outputUrl?: string;
  outputSizeBytes?: number;
  error?: string;
}

export interface RenderJobExecutionResult {
  jobId: string;
  status: RenderJobStatus;
  durationSeconds: number;
  totalFramesRendered: number;
  outputSizeBytes: number;
  outputUrl?: string;
  outputBlob?: Blob;
  executionDurationMs: number;
  error?: string;
  cancelled: boolean;
}
