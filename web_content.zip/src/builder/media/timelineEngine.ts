/**
 * GODEX P2.5 — Real Timeline Engine
 * Multi-track non-linear editing timeline state and sequencing engine.
 * Handles deterministic frame math, clip trimming, track isolation, and playback sequencing.
 */

import {
  TimelineStateData,
  TimelineTrackData,
  TimelineClipData,
  TrackType
} from './mediaTypes';

export class TimelineEngine {
  /**
   * Initializes a clean empty timeline state.
   */
  public static createEmptyTimeline(projectId: string = 'proj-default', fps: number = 30): TimelineStateData {
    return {
      id: `timeline-${Date.now().toString(36)}`,
      projectId,
      duration: 0,
      currentTime: 0,
      fps,
      tracks: [
        {
          id: 'track-v1',
          name: 'Video 1',
          type: 'VIDEO',
          order: 0,
          isMuted: false,
          isSolo: false,
          isLocked: false,
          isHidden: false,
          volume: 1.0,
          pan: 0,
          clips: []
        },
        {
          id: 'track-a1',
          name: 'Audio 1',
          type: 'AUDIO',
          order: 1,
          isMuted: false,
          isSolo: false,
          isLocked: false,
          isHidden: false,
          volume: 1.0,
          pan: 0,
          clips: []
        }
      ],
      selectedClipIds: [],
      isPlaying: false,
      zoomLevel: 1.0,
      loop: false
    };
  }

  /**
   * Converts seconds timestamp to exact integer frame index.
   */
  public static timeToFrame(seconds: number, fps: number = 30): number {
    if (seconds <= 0 || isNaN(seconds)) return 0;
    return Math.floor(seconds * fps);
  }

  /**
   * Converts integer frame index to exact seconds timestamp.
   */
  public static frameToTime(frame: number, fps: number = 30): number {
    if (frame <= 0 || isNaN(frame) || fps <= 0) return 0;
    return frame / fps;
  }

  /**
   * Formats seconds into SMPTE timecode (HH:MM:SS:FF) or human-readable format.
   */
  public static formatTimecode(seconds: number, fps: number = 30, format: 'SMPTE' | 'COMPACT' = 'SMPTE'): string {
    const totalFrames = this.timeToFrame(seconds, fps);
    const ff = totalFrames % fps;
    const totalSecs = Math.floor(seconds);
    const ss = totalSecs % 60;
    const totalMins = Math.floor(totalSecs / 60);
    const mm = totalMins % 60;
    const hh = Math.floor(totalMins / 60);

    const pad = (n: number, z = 2) => String(n).padStart(z, '0');

    if (format === 'COMPACT') {
      return `${pad(mm)}:${pad(ss)}.${pad(ff)}`;
    }
    return `${pad(hh)}:${pad(mm)}:${pad(ss)}:${pad(ff)}`;
  }

  /**
   * Calculates total sequence duration based on the furthest ending clip across all tracks.
   */
  public static calculateTotalDuration(tracks: TimelineTrackData[]): number {
    let maxEnd = 0;
    for (const track of tracks) {
      for (const clip of track.clips) {
        const clipEnd = clip.startTime + clip.duration;
        if (clipEnd > maxEnd) {
          maxEnd = clipEnd;
        }
      }
    }
    return Math.max(0, Number(maxEnd.toFixed(3)));
  }

  /**
   * Adds a new track to the timeline.
   */
  public static addTrack(
    timeline: TimelineStateData,
    name: string,
    type: TrackType
  ): TimelineStateData {
    const newTrack: TimelineTrackData = {
      id: `track-${type.toLowerCase()}-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 5)}`,
      name: name || `${type} Track ${timeline.tracks.length + 1}`,
      type,
      order: timeline.tracks.length,
      isMuted: false,
      isSolo: false,
      isLocked: false,
      isHidden: false,
      volume: 1.0,
      pan: 0,
      clips: []
    };

    const nextTracks = [...timeline.tracks, newTrack];
    return {
      ...timeline,
      tracks: nextTracks,
      duration: this.calculateTotalDuration(nextTracks)
    };
  }

  /**
   * Removes a track by ID.
   */
  public static removeTrack(timeline: TimelineStateData, trackId: string): TimelineStateData {
    const nextTracks = timeline.tracks
      .filter(t => t.id !== trackId)
      .map((t, idx) => ({ ...t, order: idx }));

    return {
      ...timeline,
      tracks: nextTracks,
      selectedTrackId: timeline.selectedTrackId === trackId ? undefined : timeline.selectedTrackId,
      duration: this.calculateTotalDuration(nextTracks)
    };
  }

  /**
   * Updates track properties (mute, solo, lock, hide, volume, pan, name).
   */
  public static updateTrack(
    timeline: TimelineStateData,
    trackId: string,
    updates: Partial<Omit<TimelineTrackData, 'id' | 'clips'>>
  ): TimelineStateData {
    const nextTracks = timeline.tracks.map(t => {
      if (t.id !== trackId) return t;
      return {
        ...t,
        ...updates
      };
    });

    return {
      ...timeline,
      tracks: nextTracks
    };
  }

  /**
   * Adds a clip to a specific track.
   */
  public static addClip(
    timeline: TimelineStateData,
    trackId: string,
    clipInput: {
      assetId: string;
      name: string;
      startTime: number;
      duration: number;
      offsetStart?: number;
      trimIn?: number;
      trimOut?: number;
      speed?: number;
      volume?: number;
      opacity?: number;
      blendMode?: TimelineClipData['blendMode'];
    }
  ): TimelineStateData {
    const targetTrack = timeline.tracks.find(t => t.id === trackId);
    if (!targetTrack) {
      throw new Error(`Target track "${trackId}" does not exist in timeline.`);
    }

    if (targetTrack.isLocked) {
      throw new Error(`Cannot add clip to locked track "${targetTrack.name}".`);
    }

    const duration = Math.max(0.1, clipInput.duration);
    const startTime = Math.max(0, clipInput.startTime);

    const newClip: TimelineClipData = {
      id: `clip-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      trackId,
      assetId: clipInput.assetId,
      name: clipInput.name || 'Untitled Clip',
      startTime,
      duration,
      offsetStart: clipInput.offsetStart ?? 0,
      trimIn: clipInput.trimIn ?? 0,
      trimOut: clipInput.trimOut ?? duration,
      speed: Math.max(0.25, Math.min(16.0, clipInput.speed ?? 1.0)),
      volume: Math.max(0.0, Math.min(2.0, clipInput.volume ?? 1.0)),
      opacity: Math.max(0, Math.min(100, clipInput.opacity ?? 100)),
      blendMode: clipInput.blendMode ?? 'normal',
      effects: [],
      keyframes: []
    };

    const nextTracks = timeline.tracks.map(t => {
      if (t.id !== trackId) return t;
      // Insert and sort by startTime
      const nextClips = [...t.clips, newClip].sort((a, b) => a.startTime - b.startTime);
      return {
        ...t,
        clips: nextClips
      };
    });

    return {
      ...timeline,
      tracks: nextTracks,
      duration: this.calculateTotalDuration(nextTracks)
    };
  }

  /**
   * Trims a clip's boundaries (in-point, out-point, duration).
   */
  public static trimClip(
    timeline: TimelineStateData,
    clipId: string,
    options: {
      trimIn?: number;
      trimOut?: number;
      newStartTime?: number;
      newDuration?: number;
    }
  ): TimelineStateData {
    let found = false;
    const nextTracks = timeline.tracks.map(track => {
      const clipIndex = track.clips.findIndex(c => c.id === clipId);
      if (clipIndex === -1) return track;

      found = true;
      if (track.isLocked) {
        throw new Error(`Cannot trim clip in locked track "${track.name}".`);
      }

      const clip = track.clips[clipIndex];
      const trimIn = options.trimIn !== undefined ? Math.max(0, options.trimIn) : clip.trimIn;
      const trimOut = options.trimOut !== undefined ? Math.max(trimIn + 0.05, options.trimOut) : clip.trimOut;
      const duration = options.newDuration !== undefined 
        ? Math.max(0.05, options.newDuration) 
        : (options.trimIn !== undefined || options.trimOut !== undefined) 
          ? (trimOut - trimIn) 
          : clip.duration;
      const startTime = options.newStartTime !== undefined ? Math.max(0, options.newStartTime) : clip.startTime;

      const updatedClip: TimelineClipData = {
        ...clip,
        startTime,
        duration,
        trimIn,
        trimOut,
        offsetStart: trimIn
      };

      const nextClips = [...track.clips];
      nextClips[clipIndex] = updatedClip;
      nextClips.sort((a, b) => a.startTime - b.startTime);

      return {
        ...track,
        clips: nextClips
      };
    });

    if (!found) {
      throw new Error(`Clip "${clipId}" not found in timeline.`);
    }

    return {
      ...timeline,
      tracks: nextTracks,
      duration: this.calculateTotalDuration(nextTracks)
    };
  }

  /**
   * Splits a clip at a given timestamp into two distinct sequential clips.
   */
  public static splitClip(
    timeline: TimelineStateData,
    clipId: string,
    splitTimeSeconds: number
  ): TimelineStateData {
    let found = false;
    const nextTracks = timeline.tracks.map(track => {
      const clip = track.clips.find(c => c.id === clipId);
      if (!clip) return track;

      found = true;
      if (track.isLocked) {
        throw new Error(`Cannot split clip in locked track "${track.name}".`);
      }

      const relativeSplit = splitTimeSeconds - clip.startTime;
      if (relativeSplit <= 0.05 || relativeSplit >= clip.duration - 0.05) {
        // Split point is outside or too close to edges
        return track;
      }

      const firstPartDuration = relativeSplit;
      const secondPartDuration = clip.duration - relativeSplit;

      const firstClip: TimelineClipData = {
        ...clip,
        id: `${clip.id}-p1`,
        duration: firstPartDuration,
        trimOut: clip.trimIn + firstPartDuration
      };

      const secondClip: TimelineClipData = {
        ...clip,
        id: `${clip.id}-p2`,
        name: `${clip.name} (Part 2)`,
        startTime: clip.startTime + firstPartDuration,
        duration: secondPartDuration,
        trimIn: clip.trimIn + firstPartDuration,
        trimOut: clip.trimOut,
        offsetStart: clip.trimIn + firstPartDuration
      };

      const nextClips = track.clips
        .filter(c => c.id !== clipId)
        .concat([firstClip, secondClip])
        .sort((a, b) => a.startTime - b.startTime);

      return {
        ...track,
        clips: nextClips
      };
    });

    if (!found) {
      throw new Error(`Clip "${clipId}" not found for split.`);
    }

    return {
      ...timeline,
      tracks: nextTracks,
      duration: this.calculateTotalDuration(nextTracks)
    };
  }

  /**
   * Removes a clip from the timeline.
   */
  public static removeClip(timeline: TimelineStateData, clipId: string): TimelineStateData {
    const nextTracks = timeline.tracks.map(track => ({
      ...track,
      clips: track.clips.filter(c => c.id !== clipId)
    }));

    return {
      ...timeline,
      tracks: nextTracks,
      selectedClipIds: timeline.selectedClipIds.filter(id => id !== clipId),
      duration: this.calculateTotalDuration(nextTracks)
    };
  }

  /**
   * Returns all active clips at a specific timestamp, respecting mute/solo/hide states.
   */
  public static getClipsAtTime(
    timeline: TimelineStateData,
    timestampSeconds: number
  ): Array<{ track: TimelineTrackData; clip: TimelineClipData; localTimeSeconds: number }> {
    const active: Array<{ track: TimelineTrackData; clip: TimelineClipData; localTimeSeconds: number }> = [];
    const hasSolo = timeline.tracks.some(t => t.isSolo);

    for (const track of timeline.tracks) {
      if (hasSolo && !track.isSolo) continue;
      if (track.isMuted || track.isHidden) continue;

      for (const clip of track.clips) {
        const clipEnd = clip.startTime + clip.duration;
        if (timestampSeconds >= clip.startTime && timestampSeconds < clipEnd) {
          const localTimeSeconds = (timestampSeconds - clip.startTime) * clip.speed + clip.trimIn;
          active.push({ track, clip, localTimeSeconds });
        }
      }
    }

    return active;
  }
}
