/**
 * GODEX P2.5 — Creative Capability Bridge
 * Formal classification and boundary enforcement between local browser capabilities,
 * browser-native Web APIs, and external cloud engine requirements.
 */

import { CapabilityStatus, CanonicalCapabilityStatus } from '../builderTypes';

export type CreativeExecutionDomain = 'BROWSER_LOCAL' | 'WEB_API_NATIVE' | 'REMOTE_GPU_CLUSTER' | 'UNSUPPORTED_SANDBOX';

export interface CreativeCapabilityEvaluation {
  id: string;
  name: string;
  domain: CreativeExecutionDomain;
  status: CapabilityStatus;
  canonicalStatus: CanonicalCapabilityStatus;
  isExecutableInSandbox: boolean;
  requiredEngineName?: string;
  localAlternative: string;
  truthfulDisclosure: string;
}

export class CreativeCapabilityBridge {
  private static readonly CAPABILITY_MAP: Record<string, CreativeCapabilityEvaluation> = {
    // 1. Timeline & Sequencing
    'media-timeline': {
      id: 'media-timeline',
      name: 'Multi-Track Non-Linear Video/Audio Timeline',
      domain: 'BROWSER_LOCAL',
      status: 'AVAILABLE_LOCALLY',
      canonicalStatus: 'AVAILABLE',
      isExecutableInSandbox: true,
      localAlternative: 'Deterministic TypeScript timeline state & playhead math.',
      truthfulDisclosure: 'Full timeline sequencing, trimming, and track isolation execute natively in-memory.'
    },

    // 2. Asset Ingestion
    'media-assets': {
      id: 'media-assets',
      name: 'Media Asset Pipeline & Metadata Extraction',
      domain: 'BROWSER_LOCAL',
      status: 'AVAILABLE_LOCALLY',
      canonicalStatus: 'AVAILABLE',
      isExecutableInSandbox: true,
      localAlternative: 'Blob URLs, FileReader API, and header MIME inspection.',
      truthfulDisclosure: 'Client-side file inspection and browser-supported codec decoding.'
    },

    // 3. 2D Compositing
    'layer-compositor': {
      id: 'layer-compositor',
      name: 'Alpha Layer Compositor & Blend Modes',
      domain: 'BROWSER_LOCAL',
      status: 'AVAILABLE_LOCALLY',
      canonicalStatus: 'AVAILABLE',
      isExecutableInSandbox: true,
      localAlternative: 'Canvas 2D globalCompositeOperation and CSS mix-blend-mode.',
      truthfulDisclosure: 'Runs real-time in client browser using standard 2D canvas context.'
    },

    // 4. Image Processing
    'image-processing': {
      id: 'image-processing',
      name: 'Canvas Image Crop, Resize & Color Adjustment',
      domain: 'BROWSER_LOCAL',
      status: 'AVAILABLE_LOCALLY',
      canonicalStatus: 'AVAILABLE',
      isExecutableInSandbox: true,
      localAlternative: 'Canvas 2D ImageData pixel array manipulation.',
      truthfulDisclosure: 'Pixel-level image manipulation and export (PNG/JPEG/WEBP) run locally in browser.'
    },

    // 5. Audio DSP
    'audio-mixer': {
      id: 'audio-mixer',
      name: 'Web Audio DSP Channel Mixer & dB Metering',
      domain: 'WEB_API_NATIVE',
      status: 'AVAILABLE_LOCALLY',
      canonicalStatus: 'AVAILABLE',
      isExecutableInSandbox: true,
      localAlternative: 'Web Audio API GainNodes, StereoPannerNodes, and AnalyserNodes.',
      truthfulDisclosure: 'Acoustic math, gain-to-dB conversion, and pan laws run natively in browser.'
    },

    // 6. Preview Playback
    'preview-playback': {
      id: 'preview-playback',
      name: 'Synchronized Preview Playback Runtime',
      domain: 'WEB_API_NATIVE',
      status: 'AVAILABLE_LOCALLY',
      canonicalStatus: 'AVAILABLE',
      isExecutableInSandbox: true,
      localAlternative: 'requestAnimationFrame clock ticker with HTML5 Media synchronization.',
      truthfulDisclosure: 'Accurate frame clock with play/pause/seek controls and truthful state emission.'
    },

    // 7. Render Queue
    'render-export': {
      id: 'render-export',
      name: 'Client-Side Render & Export Queue',
      domain: 'BROWSER_LOCAL',
      status: 'AVAILABLE_LOCALLY',
      canonicalStatus: 'AVAILABLE',
      isExecutableInSandbox: true,
      localAlternative: 'Canvas frame-by-frame snapshot capture and blob generation.',
      truthfulDisclosure: 'Real job state machine (QUEUED -> RUNNING -> COMPLETED/CANCELLED) runs in browser.'
    },

    // 8. Remote Video Diffusion (AI)
    'text-to-video-diffusion': {
      id: 'text-to-video-diffusion',
      name: 'Generative Text-to-Video Diffusion Model',
      domain: 'REMOTE_GPU_CLUSTER',
      status: 'REQUIRES_ENGINE',
      canonicalStatus: 'REQUIRES_ENGINE',
      isExecutableInSandbox: false,
      requiredEngineName: 'Cloud Spatio-Temporal Video Diffusion Pipeline (Veo / Runway API)',
      localAlternative: 'Procedural canvas keyframe simulator & camera pan/zoom shader.',
      truthfulDisclosure: 'High-compute spatio-temporal video diffusion rendering requires remote tensor cluster.'
    },

    // 9. Remote Image Diffusion (AI)
    'text-to-image-diffusion': {
      id: 'text-to-image-diffusion',
      name: 'Generative Text-to-Image Diffusion Model',
      domain: 'REMOTE_GPU_CLUSTER',
      status: 'REQUIRES_ENGINE',
      canonicalStatus: 'REQUIRES_ENGINE',
      isExecutableInSandbox: false,
      requiredEngineName: 'Cloud Diffusion Image Inference Cluster (Imagen 3 / SDXL)',
      localAlternative: 'Procedural SVG/Canvas artistic generation engine.',
      truthfulDisclosure: 'High-resolution latent diffusion image synthesis requires dedicated model accelerator.'
    },

    // 10. Direct Hardware Drivers
    'gpu-kernel-drivers': {
      id: 'gpu-kernel-drivers',
      name: 'Direct GPU Hardware Kernel Driver Access',
      domain: 'UNSUPPORTED_SANDBOX',
      status: 'UNAVAILABLE',
      canonicalStatus: 'UNAVAILABLE',
      isExecutableInSandbox: false,
      localAlternative: 'Standard WebGL2 / WebGPU shaders where browser allows.',
      truthfulDisclosure: 'Low-level kernel hardware driver registers cannot be accessed inside web sandbox.'
    }
  };

  /**
   * Evaluates a creative capability key.
   */
  public static evaluate(capabilityId: string): CreativeCapabilityEvaluation {
    const match = this.CAPABILITY_MAP[capabilityId];
    if (match) return match;

    return {
      id: capabilityId,
      name: capabilityId,
      domain: 'BROWSER_LOCAL',
      status: 'SUPPORTED',
      canonicalStatus: 'AVAILABLE',
      isExecutableInSandbox: true,
      localAlternative: 'Standard browser client execution.',
      truthfulDisclosure: 'Generic browser capability.'
    };
  }

  /**
   * Returns all creative capability evaluations.
   */
  public static getAllEvaluations(): CreativeCapabilityEvaluation[] {
    return Object.values(this.CAPABILITY_MAP);
  }
}
