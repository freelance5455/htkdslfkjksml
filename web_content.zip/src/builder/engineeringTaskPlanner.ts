/**
 * GODEX P3.0 — Engineering Task Planner & Autonomous Role Orchestrator
 * Decomposes high-level objectives into deterministic DAG task graphs
 * with specialized roles, affected file sets, and rollback criteria.
 */

export type EngineeringRole = 
  | 'ARCHITECT' 
  | 'RESEARCHER' 
  | 'CODER' 
  | 'DEBUGGER' 
  | 'TESTER' 
  | 'REVIEWER' 
  | 'VERIFIER' 
  | 'RELEASE_ENGINEER';

export type TaskStatus = 
  | 'PENDING' 
  | 'READY' 
  | 'RUNNING' 
  | 'COMPLETED' 
  | 'FAILED' 
  | 'BLOCKED' 
  | 'SKIPPED';

export interface EngineeringTask {
  id: string;
  title: string;
  objective: string;
  role: EngineeringRole;
  inputs: Record<string, unknown>;
  outputs?: Record<string, unknown>;
  dependencies: string[]; // Task IDs that must complete first
  affectedFiles: string[];
  risk: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  verificationCriteria: string[];
  rollbackStrategy: 'RESTORE_CHECKPOINT' | 'DISCARD_PATCH' | 'NONE';
  status: TaskStatus;
  evidence?: string;
  durationMs?: number;
}

export interface TaskGraphPlan {
  planId: string;
  objective: string;
  tasks: Record<string, EngineeringTask>;
  executionOrder: string[]; // Topologically sorted task IDs
  estimatedRisk: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  createdAt: number;
}

export class EngineeringTaskPlanner {
  public static planObjective(
    objective: string,
    context?: {
      targetFiles?: string[];
      affectedFiles?: string[];
      isRepair?: boolean;
    }
  ): TaskGraphPlan {
    const planId = `plan-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const tasks: Record<string, EngineeringTask> = {};
    const targetFiles = context?.targetFiles || ['src/App.tsx'];
    const affectedFiles = context?.affectedFiles || targetFiles;

    if (context?.isRepair) {
      // 1. Debugger Root Cause
      tasks['task-dbg'] = {
        id: 'task-dbg',
        title: 'Root Cause Diagnosis & Failure Localization',
        objective: 'Analyze runtime telemetry, stack trace, and AST failure site to determine deterministic root cause',
        role: 'DEBUGGER',
        inputs: { objective, targetFiles },
        dependencies: [],
        affectedFiles: targetFiles,
        risk: 'LOW',
        verificationCriteria: ['Root cause classified', 'Failure site isolated'],
        rollbackStrategy: 'NONE',
        status: 'READY'
      };

      // 2. Minimal Safe Coder Patch
      tasks['task-code'] = {
        id: 'task-code',
        title: 'Surgical Patch Application',
        objective: 'Apply bounded surgical code edit through ConflictManager and create pre-mutation checkpoint',
        role: 'CODER',
        inputs: { diagnosisTaskId: 'task-dbg' },
        dependencies: ['task-dbg'],
        affectedFiles: targetFiles,
        risk: 'MEDIUM',
        verificationCriteria: ['Syntax valid', 'No unresolved imports'],
        rollbackStrategy: 'RESTORE_CHECKPOINT',
        status: 'PENDING'
      };

      // 3. Tester Regression
      tasks['task-test'] = {
        id: 'task-test',
        title: 'Targeted & Regression Test Execution',
        objective: 'Execute targeted test suite against mutated files and verify zero regression across existing tests',
        role: 'TESTER',
        inputs: { codeTaskId: 'task-code' },
        dependencies: ['task-code'],
        affectedFiles: targetFiles,
        risk: 'LOW',
        verificationCriteria: ['Targeted tests pass', 'Regression suite green'],
        rollbackStrategy: 'RESTORE_CHECKPOINT',
        status: 'PENDING'
      };

      // 4. Verifier
      tasks['task-verify'] = {
        id: 'task-verify',
        title: '6-Pillar Evidence Verification',
        objective: 'Audit AST integrity, typecheck, build, security, and runtime mount state',
        role: 'VERIFIER',
        inputs: { testTaskId: 'task-test' },
        dependencies: ['task-test'],
        affectedFiles,
        risk: 'LOW',
        verificationCriteria: ['All 6 pillars pass with 100% confidence'],
        rollbackStrategy: 'RESTORE_CHECKPOINT',
        status: 'PENDING'
      };
    } else {
      // Standard Comprehensive Engineering Objective
      // 1. ARCHITECT
      tasks['task-arch'] = {
        id: 'task-arch',
        title: 'System Architecture & Schema Decomposition',
        objective: `Analyze requirements for "${objective}" and formulate modular architecture and component contracts`,
        role: 'ARCHITECT',
        inputs: { objective },
        dependencies: [],
        affectedFiles: ['src/types.ts', ...targetFiles],
        risk: 'LOW',
        verificationCriteria: ['Component hierarchy established', 'Type definitions declared'],
        rollbackStrategy: 'NONE',
        status: 'READY'
      };

      // 2. RESEARCHER
      tasks['task-res'] = {
        id: 'task-res',
        title: 'Dependency & Knowledge Graph Probing',
        objective: 'Inspect project symbols, dependencies, and potential blast radius for proposed architecture',
        role: 'RESEARCHER',
        inputs: { archTaskId: 'task-arch' },
        dependencies: ['task-arch'],
        affectedFiles: targetFiles,
        risk: 'LOW',
        verificationCriteria: ['Import dependencies mapped', 'No conflicting symbols'],
        rollbackStrategy: 'NONE',
        status: 'PENDING'
      };

      // 3. CODER
      tasks['task-code'] = {
        id: 'task-code',
        title: 'Safe Multi-File Code Synthesis & Mutation',
        objective: 'Synthesize cohesive TypeScript/React modules through ConflictManager under strict concurrency locks',
        role: 'CODER',
        inputs: { archTaskId: 'task-arch', resTaskId: 'task-res' },
        dependencies: ['task-arch', 'task-res'],
        affectedFiles: targetFiles,
        risk: 'MEDIUM',
        verificationCriteria: ['Clean AST syntax', 'Valid exports and typed props'],
        rollbackStrategy: 'RESTORE_CHECKPOINT',
        status: 'PENDING'
      };

      // 4. REVIEWER
      tasks['task-rev'] = {
        id: 'task-rev',
        title: 'Independent AST & Security Diff Audit',
        objective: 'Audit synthesized code diff against security boundaries, anti-slop rules, and performance guidelines',
        role: 'REVIEWER',
        inputs: { codeTaskId: 'task-code' },
        dependencies: ['task-code'],
        affectedFiles: targetFiles,
        risk: 'LOW',
        verificationCriteria: ['No security violations', 'Zero unneeded dependencies'],
        rollbackStrategy: 'RESTORE_CHECKPOINT',
        status: 'PENDING'
      };

      // 5. TESTER
      tasks['task-test'] = {
        id: 'task-test',
        title: 'Test Suite Execution & Assertion Probing',
        objective: 'Execute targeted component mount tests, interactive handlers, and state lifecycle assertions',
        role: 'TESTER',
        inputs: { revTaskId: 'task-rev' },
        dependencies: ['task-rev'],
        affectedFiles: targetFiles,
        risk: 'LOW',
        verificationCriteria: ['100% targeted tests pass', 'Clean event handler bindings'],
        rollbackStrategy: 'RESTORE_CHECKPOINT',
        status: 'PENDING'
      };

      // 6. VERIFIER
      tasks['task-verify'] = {
        id: 'task-verify',
        title: 'Holistic 6-Pillar Evidence Verification',
        objective: 'Perform exhaustive typecheck, build validation, runtime mounting, and regression verification',
        role: 'VERIFIER',
        inputs: { testTaskId: 'task-test' },
        dependencies: ['task-test'],
        affectedFiles,
        risk: 'LOW',
        verificationCriteria: ['All verification pillars score green', 'DOM mounted successfully'],
        rollbackStrategy: 'RESTORE_CHECKPOINT',
        status: 'PENDING'
      };

      // 7. RELEASE_ENGINEER
      tasks['task-rel'] = {
        id: 'task-rel',
        title: 'Release Preparation & Readiness Verification',
        objective: 'Compile final release dossier, update changelog metadata, and verify production deployment gates',
        role: 'RELEASE_ENGINEER',
        inputs: { verifyTaskId: 'task-verify' },
        dependencies: ['task-verify'],
        affectedFiles: ['metadata.json', 'package.json'],
        risk: 'LOW',
        verificationCriteria: ['Build passes in production mode', 'Release marked READY'],
        rollbackStrategy: 'NONE',
        status: 'PENDING'
      };
    }

    const executionOrder = topologicalSort(tasks);

    return {
      planId,
      objective,
      tasks,
      executionOrder,
      estimatedRisk: targetFiles.length > 5 ? 'HIGH' : 'MEDIUM',
      createdAt: Date.now()
    };
  }

  public static async executeTaskGraph(
    plan: TaskGraphPlan,
    executor: (task: EngineeringTask) => Promise<{ success: boolean; evidence?: string; outputs?: Record<string, unknown> }>
  ): Promise<{ success: boolean; completedTasks: string[]; failedTask?: string; plan: TaskGraphPlan }> {
    const completedTasks: string[] = [];

    for (const taskId of plan.executionOrder) {
      const task = plan.tasks[taskId];
      if (!task) continue;

      // Check if dependencies are met
      const depsSatisfied = task.dependencies.every(dId => completedTasks.includes(dId));
      if (!depsSatisfied) {
        task.status = 'BLOCKED';
        return { success: false, completedTasks, failedTask: taskId, plan };
      }

      task.status = 'RUNNING';
      const start = Date.now();
      try {
        const result = await executor(task);
        task.durationMs = Date.now() - start;
        if (result.success) {
          task.status = 'COMPLETED';
          task.evidence = result.evidence;
          task.outputs = result.outputs;
          completedTasks.push(taskId);
        } else {
          task.status = 'FAILED';
          task.evidence = result.evidence || 'Task execution reported failure';
          return { success: false, completedTasks, failedTask: taskId, plan };
        }
      } catch (err: any) {
        task.status = 'FAILED';
        task.evidence = err.message || String(err);
        task.durationMs = Date.now() - start;
        return { success: false, completedTasks, failedTask: taskId, plan };
      }
    }

    return { success: true, completedTasks, plan };
  }
}

function topologicalSort(tasks: Record<string, EngineeringTask>): string[] {
  const result: string[] = [];
  const visited = new Set<string>();
  const visiting = new Set<string>();

  function visit(taskId: string) {
    if (visiting.has(taskId)) {
      throw new Error(`Cycle detected in Task DAG involving task "${taskId}".`);
    }
    if (visited.has(taskId)) return;

    visiting.add(taskId);
    const task = tasks[taskId];
    if (task) {
      for (const depId of task.dependencies) {
        if (tasks[depId]) {
          visit(depId);
        }
      }
    }
    visiting.delete(taskId);
    visited.add(taskId);
    result.push(taskId);
  }

  for (const taskId of Object.keys(tasks)) {
    if (!visited.has(taskId)) {
      visit(taskId);
    }
  }

  return result;
}
