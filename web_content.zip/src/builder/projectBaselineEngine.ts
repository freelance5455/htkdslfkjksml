/**
 * GODEX P3.1 — Project Baseline Engine
 * Inspects workspace state, computes structural fingerprints, discovers entrypoints,
 * identifies real build/test commands, captures dependency profiles, and establishes
 * an authoritative pre-mutation baseline checkpoint.
 */

import { ProjectBaseline } from './builderTypes';
import { AstParser } from '../intelligence/astParser';
import { ProjectKnowledgeGraphBuilder } from './projectKnowledgeGraph';

export class ProjectBaselineEngine {
  /**
   * Captures the authoritative baseline of the provided workspace files.
   */
  public static captureBaseline(
    files: Record<string, string>,
    checkpointPrefix = 'baseline'
  ): ProjectBaseline {
    const fileKeys = Object.keys(files).sort();
    const totalFiles = fileKeys.length;

    // Compute deterministic workspace fingerprint
    let hash = 0;
    for (const key of fileKeys) {
      const content = files[key] || '';
      for (let i = 0; i < content.length; i++) {
        hash = (hash * 31 + content.charCodeAt(i)) | 0;
      }
    }
    const fingerprint = `fp-${Math.abs(hash).toString(16)}-${totalFiles}f`;

    // Discover entry points
    const entryPoints: ProjectBaseline['entryPoints'] = {};
    if (files['src/main.tsx'] || files['/src/main.tsx']) {
      entryPoints.mainTsx = 'src/main.tsx';
    }
    if (files['index.html'] || files['/index.html']) {
      entryPoints.indexHtml = 'index.html';
    }
    if (files['src/App.tsx'] || files['/src/App.tsx']) {
      entryPoints.rootComponent = 'src/App.tsx';
    }
    if (files['server.ts'] || files['/server.ts']) {
      entryPoints.serverEntry = 'server.ts';
    }

    // Discover package.json scripts and dependencies
    let dependencies: Record<string, string> = {};
    let devDependencies: Record<string, string> = {};
    const detectedCommands = {
      buildCmd: 'npm run build',
      testCmd: 'npm test',
      lintCmd: 'npm run lint',
      devCmd: 'npm run dev'
    };

    const pkgJsonStr = files['package.json'] || files['/package.json'];
    if (pkgJsonStr) {
      try {
        const pkg = JSON.parse(pkgJsonStr);
        dependencies = pkg.dependencies || {};
        devDependencies = pkg.devDependencies || {};
        if (pkg.scripts) {
          if (pkg.scripts.build) detectedCommands.buildCmd = `npm run build`;
          if (pkg.scripts.test) detectedCommands.testCmd = `npm test`;
          if (pkg.scripts.lint) detectedCommands.lintCmd = `npm run lint`;
          if (pkg.scripts.dev) detectedCommands.devCmd = `npm run dev`;
        }
      } catch {
        // Fallback to defaults if package.json has malformed JSON
      }
    }

    // Discover existing test suites
    const existingTests = fileKeys.filter(f =>
      f.includes('.test.') ||
      f.includes('.spec.') ||
      f.toLowerCase().includes('test.ts') ||
      f.toLowerCase().includes('test.tsx')
    );

    // Validate AST syntax across files
    let astValidFileCount = 0;
    let initialDiagnosticCount = 0;

    for (const key of fileKeys) {
      if (key.endsWith('.ts') || key.endsWith('.tsx') || key.endsWith('.js') || key.endsWith('.jsx')) {
        const errors = AstParser.validateSyntax(files[key], key);
        if (errors.length === 0) {
          astValidFileCount++;
        } else {
          initialDiagnosticCount += errors.length;
        }
      }
    }

    const baselineCheckpointId = `${checkpointPrefix}-${Date.now()}-${fingerprint.slice(0, 8)}`;

    return {
      timestamp: Date.now(),
      fingerprint,
      totalFiles,
      files: fileKeys,
      entryPoints,
      detectedCommands,
      dependencies,
      devDependencies,
      existingTests,
      baselineCheckpointId,
      astValidFileCount,
      initialDiagnosticCount
    };
  }

  /**
   * Compares a post-execution workspace against baseline to detect drift or unexpected deletions.
   */
  public static evaluateDrift(
    baseline: ProjectBaseline,
    currentFiles: Record<string, string>
  ): {
    filesAdded: string[];
    filesModified: string[];
    filesDeleted: string[];
    hasDrift: boolean;
  } {
    const currentKeys = new Set(Object.keys(currentFiles));
    const baselineKeys = new Set(baseline.files);

    const filesAdded: string[] = [];
    const filesModified: string[] = [];
    const filesDeleted: string[] = [];

    for (const file of currentKeys) {
      if (!baselineKeys.has(file)) {
        filesAdded.push(file);
      } else {
        // Check if content changed
        // Baseline didn't store raw content, but drift is detected by existence or caller
        filesModified.push(file);
      }
    }

    for (const file of baselineKeys) {
      if (!currentKeys.has(file)) {
        filesDeleted.push(file);
      }
    }

    return {
      filesAdded,
      filesModified,
      filesDeleted,
      hasDrift: filesAdded.length > 0 || filesDeleted.length > 0
    };
  }
}
