/**
 * GODEX P3.1 — Real Application Proof Suite
 * Provides deterministic proof blueprints and validation fixtures for representative application classes:
 * A. SaaS Analytics Dashboard
 * B. CRUD / Relational Data Application
 * C. Developer Tooling & AST Inspector
 * D. Productivity & Task Management System
 * E. Interactive Canvas Physics Simulation
 * F. Creative Multi-Track Media Studio & DSP Pipeline
 */

import { ProofMissionCategory } from './builderTypes';

export interface ApplicationProofSpec {
  category: ProofMissionCategory;
  name: string;
  objective: string;
  files: Record<string, string>;
  expectedComponentCount: number;
  expectedInterfaceNames: string[];
}

export class RealApplicationProofSuite {
  /**
   * Generates a concrete, fully functioning workspace implementation for a given proof application category.
   */
  public static getProofSpec(category: ProofMissionCategory): ApplicationProofSpec {
    switch (category) {
      case 'SAAS_DASHBOARD':
        return {
          category: 'SAAS_DASHBOARD',
          name: 'Nexus Cloud Analytics Dashboard',
          objective: 'Build an enterprise SaaS analytics dashboard with real-time KPI cards, time-series telemetry charts, and filterable data tables.',
          expectedComponentCount: 3,
          expectedInterfaceNames: ['MetricRecord', 'TimePoint', 'DashboardFilter'],
          files: {
            'src/types.ts': `
export interface MetricRecord {
  id: string;
  name: string;
  value: number;
  change: number;
  period: string;
}

export interface TimePoint {
  timestamp: number;
  activeUsers: number;
  revenue: number;
  serverLoad: number;
}

export interface DashboardFilter {
  dateRange: '24h' | '7d' | '30d' | '90d';
  environment: 'production' | 'staging';
}
`,
            'src/components/MetricCard.tsx': `
import React from 'react';
import { MetricRecord } from '../types';

export const MetricCard: React.FC<{ metric: MetricRecord }> = ({ metric }) => {
  return (
    <div id={\`metric-\${metric.id}\`} className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-white">
      <div className="text-xs text-slate-400 font-medium uppercase">{metric.name}</div>
      <div className="text-2xl font-bold mt-1">\${metric.value.toLocaleString()}</div>
      <div className={\`text-xs mt-2 font-mono \${metric.change >= 0 ? 'text-emerald-400' : 'text-rose-400'}\`}>
        {metric.change >= 0 ? '+' : ''}{metric.change}% vs last {metric.period}
      </div>
    </div>
  );
};
`,
            'src/App.tsx': `
import React, { useState } from 'react';
import { MetricRecord, DashboardFilter } from './types';
import { MetricCard } from './components/MetricCard';

export function App() {
  const [filter, setFilter] = useState<DashboardFilter>({ dateRange: '7d', environment: 'production' });
  const [metrics] = useState<MetricRecord[]>([
    { id: 'm1', name: 'Monthly Recurring Revenue', value: 48250, change: 12.4, period: 'month' },
    { id: 'm2', name: 'Active Subscriptions', value: 1420, change: 8.1, period: 'month' },
    { id: 'm3', name: 'System Availability', value: 99.98, change: 0.02, period: 'month' }
  ]);

  return (
    <div id="saas-dashboard-root" className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <header className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Nexus Analytics Dashboard</h1>
          <p className="text-sm text-slate-400">Real-time enterprise metrics & telemetry</p>
        </div>
        <div className="flex gap-2">
          <button id="btn-refresh" className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-semibold">
            Refresh Data
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {metrics.map(m => (
          <MetricCard key={m.id} metric={m} />
        ))}
      </div>
    </div>
  );
}
`
          }
        };

      case 'CRUD_DATA_APP':
        return {
          category: 'CRUD_DATA_APP',
          name: 'Inventory Entity Management System',
          objective: 'Build a relational CRUD inventory management tool with search filtering, form validations, and transactional entity mutations.',
          expectedComponentCount: 2,
          expectedInterfaceNames: ['InventoryItem', 'ItemCategory'],
          files: {
            'src/types.ts': `
export interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  category: 'ELECTRONICS' | 'FURNITURE' | 'APPAREL';
  quantity: number;
  unitPrice: number;
  updatedAt: number;
}
`,
            'src/App.tsx': `
import React, { useState } from 'react';
import { InventoryItem } from './types';

export function App() {
  const [items, setItems] = useState<InventoryItem[]>([
    { id: 'inv-1', sku: 'SKU-001', name: 'Ergonomic Desk Chair', category: 'FURNITURE', quantity: 24, unitPrice: 299, updatedAt: Date.now() },
    { id: 'inv-2', sku: 'SKU-002', name: '4K Ultra-Wide Monitor', category: 'ELECTRONICS', quantity: 15, unitPrice: 650, updatedAt: Date.now() }
  ]);
  const [search, setSearch] = useState('');
  const [newItemName, setNewItemName] = useState('');

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;
    const newItem: InventoryItem = {
      id: \`inv-\${Date.now()}\`,
      sku: \`SKU-\${Math.floor(Math.random() * 900 + 100)}\`,
      name: newItemName,
      category: 'ELECTRONICS',
      quantity: 1,
      unitPrice: 100,
      updatedAt: Date.now()
    };
    setItems(prev => [newItem, ...prev]);
    setNewItemName('');
  };

  const handleDelete = (id: string) => {
    setItems(prev => prev.filter(i => i.id !== id));
  };

  const filtered = items.filter(i => i.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div id="crud-app-root" className="min-h-screen bg-neutral-900 text-white p-6 font-sans">
      <h1 className="text-xl font-bold mb-4">Inventory Entity Manager</h1>
      <form onSubmit={handleAddItem} className="flex gap-2 mb-4">
        <input
          id="input-item-name"
          value={newItemName}
          onChange={e => setNewItemName(e.target.value)}
          placeholder="New Item Name"
          className="px-3 py-1.5 rounded bg-neutral-800 border border-neutral-700 text-sm"
        />
        <button id="btn-add-item" type="submit" className="px-3 py-1.5 rounded bg-emerald-600 text-sm font-medium">
          Add Entity
        </button>
      </form>
      <input
        id="input-search"
        value={search}
        onChange={e => setSearch(e.target.value)}
        placeholder="Filter items..."
        className="w-full px-3 py-1.5 rounded bg-neutral-800 border border-neutral-700 text-sm mb-4"
      />
      <div className="space-y-2">
        {filtered.map(item => (
          <div key={item.id} id={\`item-\${item.id}\`} className="flex justify-between items-center p-3 rounded bg-neutral-800">
            <div>
              <div className="font-semibold text-sm">{item.name}</div>
              <div className="text-xs text-neutral-400">{item.sku} • {item.category} • \${item.unitPrice}</div>
            </div>
            <button id={\`btn-del-\${item.id}\`} onClick={() => handleDelete(item.id)} className="text-xs text-rose-400 hover:underline">
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
`
          }
        };

      case 'DEV_TOOL':
        return {
          category: 'DEV_TOOL',
          name: 'AST Code Transformer & Regex Inspector',
          objective: 'Build a developer workbench for real-time AST syntax parsing, regular expression matching, and diff visualization.',
          expectedComponentCount: 2,
          expectedInterfaceNames: ['TokenMatch', 'SyntaxDiagnostic'],
          files: {
            'src/types.ts': `
export interface TokenMatch {
  index: number;
  text: string;
  group: string;
}

export interface SyntaxDiagnostic {
  line: number;
  column: number;
  message: string;
  severity: 'error' | 'warning';
}
`,
            'src/App.tsx': `
import React, { useState } from 'react';
import { TokenMatch } from './types';

export function App() {
  const [pattern, setPattern] = useState('(\\\\w+)@(\\\\w+\\\\.\\\\w+)');
  const [testText, setTestText] = useState('Contact support@godex.ai or team@google.com');
  const [matches, setMatches] = useState<TokenMatch[]>([]);

  const handleTest = () => {
    try {
      const regex = new RegExp(pattern, 'g');
      const results: TokenMatch[] = [];
      let m: RegExpExecArray | null;
      while ((m = regex.exec(testText)) !== null) {
        results.push({ index: m.index, text: m[0], group: m[1] || '' });
      }
      setMatches(results);
    } catch {
      setMatches([]);
    }
  };

  return (
    <div id="devtool-root" className="min-h-screen bg-slate-900 text-slate-100 p-6 font-mono">
      <h1 className="text-lg font-bold mb-3 text-cyan-400">Regex AST Inspector</h1>
      <div className="space-y-3">
        <input
          id="input-regex"
          value={pattern}
          onChange={e => setPattern(e.target.value)}
          className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-sm text-amber-300"
          placeholder="Regular Expression Pattern"
        />
        <textarea
          id="input-sample-text"
          value={testText}
          onChange={e => setTestText(e.target.value)}
          className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-sm h-24"
          placeholder="Test input string..."
        />
        <button id="btn-eval" onClick={handleTest} className="px-4 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-xs font-bold">
          Execute Token Inspection
        </button>
        <div id="matches-container" className="p-3 bg-slate-950 rounded border border-slate-800">
          <div className="text-xs text-slate-400 mb-1">Matches Found: {matches.length}</div>
          {matches.map((m, i) => (
            <div key={i} className="text-xs text-emerald-400">Match #{i + 1}: "{m.text}" (idx: {m.index})</div>
          ))}
        </div>
      </div>
    </div>
  );
}
`
          }
        };

      case 'PRODUCTIVITY_APP':
        return {
          category: 'PRODUCTIVITY_APP',
          name: 'Agile Kanban & Sprint Board',
          objective: 'Build a high-productivity sprint board with column workflows, task priority badges, and checklist state tracking.',
          expectedComponentCount: 2,
          expectedInterfaceNames: ['TaskCard', 'ColumnType'],
          files: {
            'src/types.ts': `
export type ColumnType = 'TODO' | 'IN_PROGRESS' | 'DONE';

export interface TaskCard {
  id: string;
  title: string;
  column: ColumnType;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  points: number;
}
`,
            'src/App.tsx': `
import React, { useState } from 'react';
import { TaskCard, ColumnType } from './types';

export function App() {
  const [tasks, setTasks] = useState<TaskCard[]>([
    { id: 't-1', title: 'Implement safe transactional mutator', column: 'DONE', priority: 'HIGH', points: 5 },
    { id: 't-2', title: 'Integrate release readiness evaluation', column: 'IN_PROGRESS', priority: 'HIGH', points: 3 },
    { id: 't-3', title: 'Deploy verified production bundle', column: 'TODO', priority: 'MEDIUM', points: 2 }
  ]);

  const moveTask = (id: string, nextCol: ColumnType) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, column: nextCol } : t));
  };

  const columns: ColumnType[] = ['TODO', 'IN_PROGRESS', 'DONE'];

  return (
    <div id="kanban-root" className="min-h-screen bg-neutral-950 text-neutral-200 p-6 font-sans">
      <h1 className="text-xl font-bold mb-4">Sprint Delivery Board</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {columns.map(col => (
          <div key={col} className="p-3 bg-neutral-900 rounded-xl border border-neutral-800">
            <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-3">{col}</h2>
            <div className="space-y-2">
              {tasks.filter(t => t.column === col).map(task => (
                <div key={task.id} id={\`task-\${task.id}\`} className="p-3 bg-neutral-800 rounded-lg text-sm">
                  <div className="font-semibold">{task.title}</div>
                  <div className="flex justify-between items-center mt-2 text-xs text-neutral-400">
                    <span className="font-mono">{task.points} pts</span>
                    <div className="flex gap-1">
                      {col !== 'DONE' && (
                        <button id={\`btn-advance-\${task.id}\`} onClick={() => moveTask(task.id, col === 'TODO' ? 'IN_PROGRESS' : 'DONE')} className="text-blue-400 hover:underline">
                          Advance →
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
`
          }
        };

      case 'INTERACTIVE_APP':
        return {
          category: 'INTERACTIVE_APP',
          name: '2D Particle & Collision Physics Simulator',
          objective: 'Build an interactive 2D canvas physics simulator with particle emitters, velocity integration, and bounding collision loops.',
          expectedComponentCount: 2,
          expectedInterfaceNames: ['Particle', 'PhysicsConfig'],
          files: {
            'src/types.ts': `
export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
}

export interface PhysicsConfig {
  gravity: number;
  friction: number;
  elasticity: number;
}
`,
            'src/App.tsx': `
import React, { useState, useEffect, useRef } from 'react';
import { Particle, PhysicsConfig } from './types';

export function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [particlesCount, setParticlesCount] = useState(25);
  const [config] = useState<PhysicsConfig>({ gravity: 0.15, friction: 0.99, elasticity: 0.75 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let particles: Particle[] = Array.from({ length: particlesCount }, () => ({
      x: Math.random() * 300 + 50,
      y: Math.random() * 100 + 20,
      vx: (Math.random() - 0.5) * 4,
      vy: Math.random() * 2,
      radius: Math.random() * 4 + 3,
      color: '#38bdf8'
    }));

    let animId: number;
    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (const p of particles) {
        p.vy += config.gravity;
        p.vx *= config.friction;
        p.vy *= config.friction;
        p.x += p.vx;
        p.y += p.vy;

        // Floor collision
        if (p.y + p.radius > canvas.height) {
          p.y = canvas.height - p.radius;
          p.vy = -p.vy * config.elasticity;
        }
        // Wall collision
        if (p.x - p.radius < 0 || p.x + p.radius > canvas.width) {
          p.vx = -p.vx * config.elasticity;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.fill();
      }
      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [particlesCount, config]);

  return (
    <div id="physics-app-root" className="min-h-screen bg-black text-cyan-400 p-6 font-mono">
      <h1 className="text-lg font-bold mb-3">2D Particle Physics Engine</h1>
      <div className="flex gap-3 items-center mb-3">
        <button id="btn-spawn" onClick={() => setParticlesCount(c => c + 10)} className="px-3 py-1 bg-cyan-700 text-white rounded text-xs">
          Spawn +10 Particles
        </button>
        <span className="text-xs text-neutral-400">Active Particles: {particlesCount}</span>
      </div>
      <canvas id="physics-canvas" ref={canvasRef} width={400} height={250} className="border border-cyan-900 rounded-lg bg-neutral-950" />
    </div>
  );
}
`
          }
        };

      case 'CREATIVE_MEDIA_APP':
        return {
          category: 'CREATIVE_MEDIA_APP',
          name: 'Multi-Track Media Studio & DSP Pipeline',
          objective: 'Build a creative multi-track timeline studio with audio waveform synthesizer, video layer compositing, and truthful engine status.',
          expectedComponentCount: 3,
          expectedInterfaceNames: ['MediaTrack', 'LayerClip', 'EngineStatus'],
          files: {
            'src/types.ts': `
export interface LayerClip {
  id: string;
  title: string;
  startSec: number;
  durationSec: number;
  type: 'AUDIO' | 'VIDEO' | 'EFFECT';
}

export interface MediaTrack {
  id: string;
  name: string;
  clips: LayerClip[];
  muted: boolean;
}
`,
            'src/components/TimelineTrack.tsx': `
import React from 'react';
import { MediaTrack } from '../types';

export const TimelineTrack: React.FC<{ track: MediaTrack }> = ({ track }) => {
  return (
    <div id={\`track-\${track.id}\`} className="flex items-center gap-3 p-2 bg-neutral-900 border border-neutral-800 rounded">
      <div className="w-24 text-xs font-semibold text-neutral-300 truncate">{track.name}</div>
      <div className="flex-1 h-8 bg-neutral-950 rounded relative overflow-hidden flex items-center px-2">
        {track.clips.map(clip => (
          <div key={clip.id} className="h-6 px-2 rounded bg-indigo-600 text-[10px] text-white flex items-center font-mono">
            {clip.title} ({clip.durationSec}s)
          </div>
        ))}
      </div>
    </div>
  );
};
`,
            'src/App.tsx': `
import React, { useState } from 'react';
import { MediaTrack } from './types';
import { TimelineTrack } from './components/TimelineTrack';

export function App() {
  const [tracks] = useState<MediaTrack[]>([
    { id: 'trk-1', name: 'Audio Master', muted: false, clips: [{ id: 'c1', title: 'Synthesized Beat', startSec: 0, durationSec: 12, type: 'AUDIO' }] },
    { id: 'trk-2', name: 'Canvas Video', muted: false, clips: [{ id: 'c2', title: 'Procedural Waveform', startSec: 0, durationSec: 12, type: 'VIDEO' }] }
  ]);

  return (
    <div id="creative-studio-root" className="min-h-screen bg-neutral-950 text-neutral-100 p-6 font-sans">
      <header className="mb-4 flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold">GODEX Creative Media Studio</h1>
          <p className="text-xs text-neutral-400">Non-linear video compositor & Web Audio DSP</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
            BROWSER_NATIVE
          </span>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-950 text-amber-300 border border-amber-800" title="Diffusion Video requires external GPU daemon">
            DIFFUSION: REQUIRES_ENGINE
          </span>
        </div>
      </header>

      <div className="space-y-3">
        {tracks.map(t => (
          <TimelineTrack key={t.id} track={t} />
        ))}
      </div>
    </div>
  );
}
`
          }
        };
    }
  }
}
