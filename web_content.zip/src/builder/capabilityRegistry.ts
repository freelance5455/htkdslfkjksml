/**
 * GODEX P2.1 — Deterministic Capability Registry
 * Explicitly separates what GODEX can execute natively from external engine requirements.
 * Enforces the Truth-First invariant: Never claim remote GPU AI diffusion or dedicated
 * cloud servers work locally unless genuine infrastructure exists.
 * 
 * Accurately categorizes creative workflows:
 * - text-to-image (EXTERNAL_ENGINE_REQUIRED / REQUIRES_ENGINE)
 * - image-to-image (EXTERNAL_ENGINE_REQUIRED / REQUIRES_ENGINE)
 * - text-to-video (EXTERNAL_ENGINE_REQUIRED / REQUIRES_ENGINE)
 * - image-to-video (EXTERNAL_ENGINE_REQUIRED / REQUIRES_ENGINE)
 * - video-to-video (EXTERNAL_ENGINE_REQUIRED / REQUIRES_ENGINE)
 * - audio generation (LOCAL_AVAILABLE via Web Audio API)
 * - speech synthesis (LOCAL_AVAILABLE via Web Speech API)
 * - speech recognition (LOCAL_LIMITED / EXTERNAL_ENGINE_REQUIRED)
 * - image processing (LOCAL_AVAILABLE via Canvas 2D & WebGL)
 * - video processing (LOCAL_AVAILABLE via HTML5 Video & Canvas 2D frame capture)
 */

import { CapabilityRegistryEntry, CapabilityStatus, CapabilityCategory, RequirementSpec, CanonicalCapabilityStatus } from './builderTypes';

export class CapabilityRegistry {
  private static readonly REGISTRY: CapabilityRegistryEntry[] = [
    // 1. Core UI & Rendering
    {
      id: 'cap-react19-spa',
      name: 'React 19 Interactive Single Page Application',
      category: 'CORE_UI',
      status: 'SUPPORTED',
      description: 'Native React 19 functional components, hooks, concurrent features, and sub-second reactivity.',
      evidence: 'React 19 installed and bundled in Vite workspace.'
    },
    {
      id: 'cap-tailwind-styling',
      name: 'Tailwind CSS Universal Styling',
      category: 'CORE_UI',
      status: 'SUPPORTED',
      description: 'Utility-first responsive layouts, theme variables, and anti-slop aesthetic constraints.',
      evidence: 'Tailwind CSS v4 JIT engine configured.'
    },
    {
      id: 'cap-motion-animations',
      name: 'Hardware Accelerated Fluid Animations',
      category: 'CORE_UI',
      status: 'SUPPORTED',
      description: 'Smooth layout animations, route transitions, and physics spring gestures using Motion.',
      evidence: 'motion (v12) package active in workspace.'
    },
    {
      id: 'cap-lucide-icons',
      name: 'Vector Iconography System',
      category: 'CORE_UI',
      status: 'SUPPORTED',
      description: 'High-clarity vector icons for navigation, status, metrics, and actions.',
      evidence: 'lucide-react package installed.'
    },

    // 2. State & Persistence
    {
      id: 'cap-local-storage',
      name: 'Client-Side Key-Value Persistence',
      category: 'STATE_PERSISTENCE',
      status: 'LOCAL_AVAILABLE',
      description: 'Persistent local storage across browser reloads for user preferences and application state.',
      evidence: 'Browser Window.localStorage API available natively.'
    },
    {
      id: 'cap-indexed-db',
      name: 'IndexedDB Structured Document Store',
      category: 'STATE_PERSISTENCE',
      status: 'LOCAL_AVAILABLE',
      description: 'High-capacity client-side relational/document storage for offline-first assets and projects.',
      evidence: 'Browser Window.indexedDB API available natively.'
    },
    {
      id: 'cap-cloud-sql',
      name: 'Relational Cloud SQL / PostgreSQL Database',
      category: 'STATE_PERSISTENCE',
      status: 'EXTERNAL_ENGINE_REQUIRED',
      description: 'Server-side multi-tenant relational database with strict ACID guarantees.',
      engineRequiredName: 'Cloud SQL / PostgreSQL Instance',
      localFallbackDescription: 'Simulated in-memory relational store with local storage sync.'
    },

    // 3. Graphics & Visual Media
    {
      id: 'cap-canvas-2d',
      name: 'HTML5 2D Graphics Canvas Engine',
      category: 'GRAPHICS_CANVAS',
      status: 'LOCAL_AVAILABLE',
      description: 'High-performance pixel manipulation, particle systems, charts, image filters, and procedural drawings.',
      evidence: 'HTML5 Canvas 2D Rendering Context available natively.'
    },
    {
      id: 'cap-webgl',
      name: 'WebGL Hardware Shader Pipeline',
      category: 'GRAPHICS_CANVAS',
      status: 'LOCAL_AVAILABLE',
      description: 'GPU-accelerated vertex/fragment shaders for real-time visual effects and 3D scenes.',
      evidence: 'WebGL2RenderingContext native browser API.'
    },
    {
      id: 'cap-image-processing',
      name: 'Local Image Processing & Filter Engine',
      category: 'MEDIA_PROCESSING',
      status: 'LOCAL_AVAILABLE',
      description: 'Pixel-level image filters, convolution, cropping, resize, and histogram analysis.',
      evidence: 'Canvas 2D ImageData and WebGL fragment shaders native to browser.'
    },
    {
      id: 'cap-video-processing',
      name: 'Local Video Frame Capture & Timeline Compositor',
      category: 'MEDIA_PROCESSING',
      status: 'LOCAL_AVAILABLE',
      description: 'Frame-by-frame video extraction, playback rate modulation, and canvas overlays.',
      evidence: 'HTML5 VideoElement and Canvas 2D captureStream APIs native to browser.'
    },
    {
      id: 'cap-video-timeline',
      name: 'Interactive Multi-Track Video Timeline',
      category: 'MEDIA_PROCESSING',
      status: 'LOCAL_AVAILABLE',
      description: 'Multi-track timeline sequencing, keyframing, trimming, and scrubbing.',
      evidence: 'Client-side React state model and Canvas 2D / DOM timeline visualization.'
    },
    {
      id: 'cap-media-browser',
      name: 'Local Media Asset Bin & Inspector',
      category: 'MEDIA_PROCESSING',
      status: 'LOCAL_AVAILABLE',
      description: 'Asset cataloging, metadata extraction, category filtering, and thumbnail generation.',
      evidence: 'Browser Blob URLs, FileReader, and in-memory asset store.'
    },
    {
      id: 'cap-layer-compositor',
      name: 'Multi-Layer Alpha Compositor',
      category: 'MEDIA_PROCESSING',
      status: 'LOCAL_AVAILABLE',
      description: 'Layer hierarchy, alpha masking, blend modes, and CSS/Canvas filter pipelines.',
      evidence: 'Canvas 2D globalCompositeOperation and CSS mix-blend-mode.'
    },
    {
      id: 'cap-node-graph-engine',
      name: 'Node-Based Creative Graph Pipeline',
      category: 'MEDIA_PROCESSING',
      status: 'LOCAL_AVAILABLE',
      description: 'Visual dataflow node graph editor with live parameter propagation.',
      evidence: 'Custom SVG canvas connection routing and topological execution engine.'
    },
    {
      id: 'cap-render-export-queue',
      name: 'Client-Side Media Render & Export Queue',
      category: 'MEDIA_PROCESSING',
      status: 'LOCAL_AVAILABLE',
      description: 'Client-side frame sequencing, render queue dispatch, and export downloading.',
      evidence: 'Canvas 2D toDataURL / toBlob and browser file download APIs.'
    },
    {
      id: 'cap-ai-generation-queue',
      name: 'AI Inference Job Queue & Status Monitor',
      category: 'CREATIVE_AI',
      status: 'LOCAL_AVAILABLE',
      description: 'Job queuing, progress estimation, parameter management, and honest engine status reporting.',
      evidence: 'Local job scheduler with explicit remote engine requirement boundaries.'
    },
    {
      id: 'cap-gpu-hardware-driver',
      name: 'Direct Kernel / GPU Hardware Driver Access',
      category: 'MEDIA_PROCESSING',
      status: 'UNAVAILABLE',
      description: 'Direct low-level kernel driver and hardware register manipulation.',
      evidence: 'Not possible inside web browser security sandbox.'
    },
    {
      id: 'cap-zip-export',
      name: 'Client-Side Project Archive Archiver',
      category: 'DATA_VISUALIZATION',
      status: 'AVAILABLE_THROUGH_EXISTING_ENGINE',
      description: 'Bundling multi-file workspaces and media assets into downloadable .zip archives.',
      evidence: 'jszip package installed.'
    },
    {
      id: 'cap-confetti-fx',
      name: 'Particle Visual Reward Effects',
      category: 'GRAPHICS_CANVAS',
      status: 'AVAILABLE_THROUGH_EXISTING_ENGINE',
      description: 'Celebratory particle burst animations for completion and gaming events.',
      evidence: 'canvas-confetti package installed.'
    },

    // 4. Audio Synthesis & DSP
    {
      id: 'cap-web-audio',
      name: 'Web Audio Synthesizer & DSP Processing',
      category: 'AUDIO_SYNTHESIS',
      status: 'LOCAL_AVAILABLE',
      description: 'Procedural sine/sawtooth sound generation, frequency filters, envelopes, and real-time audio playback.',
      evidence: 'Browser AudioContext / Web Audio API available natively.'
    },
    {
      id: 'cap-speech-synthesis',
      name: 'Browser Text-to-Speech Voice Engine',
      category: 'AUDIO_SYNTHESIS',
      status: 'LOCAL_AVAILABLE',
      description: 'Synthesized voice playback with pitch, rate, and voice profile controls.',
      evidence: 'Browser window.speechSynthesis API available natively.'
    },

    // 5. Creative AI & Generative Workflows
    {
      id: 'cap-gemini-text',
      name: 'Gemini Generative Text & Reasoning Model',
      category: 'CREATIVE_AI',
      status: 'AVAILABLE_THROUGH_EXISTING_ENGINE',
      description: 'Server-side reasoning, prompt generation, code completion, and narrative synthesis.',
      evidence: '@google/genai package installed in server environment.'
    },
    {
      id: 'cap-text-to-image-diffusion',
      name: 'High-Resolution Text-to-Image Diffusion',
      category: 'CREATIVE_AI',
      status: 'EXTERNAL_ENGINE_REQUIRED',
      description: 'Deep neural network image generation from descriptive text prompts (e.g. Imagen 3 / SDXL).',
      engineRequiredName: 'Cloud Imagen / Stable Diffusion GPU Inference Cluster',
      localFallbackDescription: 'Procedural SVG/Canvas artistic generation engine with high-fidelity vector composition.'
    },
    {
      id: 'cap-image-to-image-diffusion',
      name: 'Neural Image-to-Image Style Transfer & Inpainting',
      category: 'CREATIVE_AI',
      status: 'EXTERNAL_ENGINE_REQUIRED',
      description: 'Latent-space image restyling, depth-conditioned editing, and inpainting.',
      engineRequiredName: 'Cloud Diffusion Inpainting GPU Engine',
      localFallbackDescription: 'Local Canvas 2D procedural blend modes and kernel convolution filters.'
    },
    {
      id: 'cap-text-to-video-diffusion',
      name: 'Generative Text-to-Video Diffusion',
      category: 'CREATIVE_AI',
      status: 'EXTERNAL_ENGINE_REQUIRED',
      description: 'High-compute spatio-temporal video diffusion rendering (e.g. Runway Gen-3, Sora, Veo).',
      engineRequiredName: 'Cloud Video Diffusion Tensor Pipeline (Veo / Runway API)',
      localFallbackDescription: 'Canvas procedural keyframe interpolation, camera pan/zoom shader simulator, and motion timelines.'
    },
    {
      id: 'cap-image-to-video-diffusion',
      name: 'Image-to-Video Motion Synthesis',
      category: 'CREATIVE_AI',
      status: 'EXTERNAL_ENGINE_REQUIRED',
      description: 'Animating static visual inputs through temporal diffusion models.',
      engineRequiredName: 'Cloud Video Diffusion Tensor Cluster',
      localFallbackDescription: 'Procedural parallax panning, zoom transforms, and 2.5D displacement mapping in WebGL.'
    },
    {
      id: 'cap-video-to-video-diffusion',
      name: 'Video-to-Video Neural Restyling',
      category: 'CREATIVE_AI',
      status: 'EXTERNAL_ENGINE_REQUIRED',
      description: 'Spatio-temporal neural restyling across full video frame sequences.',
      engineRequiredName: 'Cloud Video-to-Video Neural Render Pipeline',
      localFallbackDescription: 'Real-time WebGL shader filter passes over video elements.'
    },
    {
      id: 'cap-speech-to-text',
      name: 'Neural Speech-to-Text Transcription',
      category: 'CREATIVE_AI',
      status: 'EXTERNAL_ENGINE_REQUIRED',
      description: 'Server-side automatic speech recognition (Whisper / Cloud Speech API).',
      engineRequiredName: 'Cloud Speech-to-Text / Whisper Model Server',
      localFallbackDescription: 'Browser Web Speech API (webkitSpeechRecognition) when available locally.'
    },

    // 6. Networking & Multiplayer
    {
      id: 'cap-local-broadcast',
      name: 'Cross-Tab Local Multiplayer Synchronization',
      category: 'REALTIME_NETWORKING',
      status: 'LOCAL_AVAILABLE',
      description: 'Real-time state sharing across browser tabs/windows without external servers.',
      evidence: 'Browser BroadcastChannel API available natively.'
    },
    {
      id: 'cap-dedicated-game-server',
      name: 'Authoritative Multiplayer Dedicated Server',
      category: 'REALTIME_NETWORKING',
      status: 'EXTERNAL_ENGINE_REQUIRED',
      description: 'Low-latency server-authoritative tick rate synchronization and matchmaker.',
      engineRequiredName: 'Dedicated WebSocket/UDP Game Server Backend',
      localFallbackDescription: 'Local simulated AI opponents and Peer-to-Peer BroadcastChannel networking.'
    }
  ];

  /**
   * Retrieves the complete list of system capabilities with their honest status.
   */
  public static getAllCapabilities(): CapabilityRegistryEntry[] {
    return [...this.REGISTRY];
  }

  /**
   * Finds a capability by ID.
   */
  public static getCapabilityById(id: string): CapabilityRegistryEntry | undefined {
    return this.REGISTRY.find(c => c.id === id);
  }

  /**
   * Evaluates a capability request string against the registry.
   */
  public static evaluateCapability(capabilityQuery: string): CapabilityRegistryEntry {
    const query = capabilityQuery.toLowerCase().trim();

    const exact = this.REGISTRY.find(c => c.id.toLowerCase() === query || c.name.toLowerCase() === query);
    if (exact) {
      return exact;
    }

    if (query.includes('timeline') || query.includes('track') || query.includes('scrub')) {
      return this.REGISTRY.find(c => c.id === 'cap-video-timeline')!;
    }
    if (query.includes('asset') || query.includes('media bin') || query.includes('media browser')) {
      return this.REGISTRY.find(c => c.id === 'cap-media-browser')!;
    }
    if (query.includes('layer') || query.includes('compositor') || query.includes('blend mode')) {
      return this.REGISTRY.find(c => c.id === 'cap-layer-compositor')!;
    }
    if (query.includes('node') || query.includes('graph') || query.includes('flow chart')) {
      return this.REGISTRY.find(c => c.id === 'cap-node-graph-engine')!;
    }
    if (query.includes('render') && (query.includes('queue') || query.includes('export') || query.includes('format'))) {
      return this.REGISTRY.find(c => c.id === 'cap-render-export-queue')!;
    }
    if (query.includes('kernel') || query.includes('driver') || query.includes('hardware register')) {
      return this.REGISTRY.find(c => c.id === 'cap-gpu-hardware-driver')!;
    }
    if (query.includes('video') && (query.includes('generate') || query.includes('diffusion') || query.includes('runway') || query.includes('sora') || query.includes('veo'))) {
      return this.REGISTRY.find(c => c.id === 'cap-text-to-video-diffusion')!;
    }
    if (query.includes('video') && query.includes('image to video')) {
      return this.REGISTRY.find(c => c.id === 'cap-image-to-video-diffusion')!;
    }
    if (query.includes('video') && query.includes('video to video')) {
      return this.REGISTRY.find(c => c.id === 'cap-video-to-video-diffusion')!;
    }
    if (query.includes('video') && (query.includes('filter') || query.includes('timeline') || query.includes('playback'))) {
      return this.REGISTRY.find(c => c.id === 'cap-video-processing')!;
    }
    if (query.includes('image') && (query.includes('generate') || query.includes('diffusion') || query.includes('midjourney') || query.includes('imagen'))) {
      return this.REGISTRY.find(c => c.id === 'cap-text-to-image-diffusion')!;
    }
    if (query.includes('image') && (query.includes('filter') || query.includes('crop') || query.includes('pixel') || query.includes('edit'))) {
      return this.REGISTRY.find(c => c.id === 'cap-image-processing')!;
    }
    if (query.includes('multiplayer') && (query.includes('server') || query.includes('authoritative') || query.includes('backend'))) {
      return this.REGISTRY.find(c => c.id === 'cap-dedicated-game-server')!;
    }
    if (query.includes('audio') || query.includes('synth') || query.includes('sound')) {
      return this.REGISTRY.find(c => c.id === 'cap-web-audio')!;
    }
    if (query.includes('speech') || query.includes('tts') || query.includes('voice')) {
      return this.REGISTRY.find(c => c.id === 'cap-speech-synthesis')!;
    }
    if (query.includes('canvas') || query.includes('draw') || query.includes('filter') || query.includes('2d')) {
      return this.REGISTRY.find(c => c.id === 'cap-canvas-2d')!;
    }
    if (query.includes('database') || query.includes('sql') || query.includes('postgres')) {
      return this.REGISTRY.find(c => c.id === 'cap-cloud-sql')!;
    }

    // Default to supported React SPA capability
    return this.REGISTRY.find(c => c.id === 'cap-react19-spa')!;
  }

  /**
   * Translates internal capability status to canonical 3-state enum:
   * AVAILABLE | REQUIRES_ENGINE | UNAVAILABLE
   */
  public static getCanonicalStatus(idOrQuery: string): CanonicalCapabilityStatus {
    const lower = idOrQuery.toLowerCase();

    // Check explicitly unavailable hardware/OS features
    if (
      lower.includes('kernel') ||
      lower.includes('hardware register') ||
      lower.includes('raw posix socket') ||
      lower.includes('c++ driver') ||
      lower.includes('unsupported_native')
    ) {
      return 'UNAVAILABLE';
    }

    const entry = this.getCapabilityById(idOrQuery) || this.evaluateCapability(idOrQuery);
    if (!entry) return 'UNAVAILABLE';

    if (
      entry.status === 'REQUIRES_ENGINE' ||
      entry.status === 'EXTERNAL_ENGINE_REQUIRED'
    ) {
      return 'REQUIRES_ENGINE';
    }

    if (
      entry.status === 'SUPPORTED' ||
      entry.status === 'LOCAL_AVAILABLE' ||
      entry.status === 'AVAILABLE_LOCALLY' ||
      entry.status === 'AVAILABLE_THROUGH_EXISTING_ENGINE'
    ) {
      return 'AVAILABLE';
    }

    return 'UNAVAILABLE';
  }

  /**
   * Returns true if the capability is available natively in the browser/workspace.
   */
  public static isCapabilityAvailable(idOrQuery: string): boolean {
    return this.getCanonicalStatus(idOrQuery) === 'AVAILABLE';
  }

  /**
   * Returns true if the capability requires an external engine/GPU tensor cluster.
   */
  public static requiresExternalEngine(idOrQuery: string): boolean {
    return this.getCanonicalStatus(idOrQuery) === 'REQUIRES_ENGINE';
  }

  /**
   * Returns true if the capability is completely unavailable in the browser environment.
   */
  public static isCapabilityUnavailable(idOrQuery: string): boolean {
    return this.getCanonicalStatus(idOrQuery) === 'UNAVAILABLE';
  }

  /**
   * Deep classification of a feature query into canonical status, entry, and honest fallback advice.
   */
  public static classifyCapability(query: string): {
    canonicalStatus: CanonicalCapabilityStatus;
    entry: CapabilityRegistryEntry;
    isTruthful: boolean;
    fallbackAdvice: string;
  } {
    const canonicalStatus = this.getCanonicalStatus(query);
    const entry = this.evaluateCapability(query);

    let fallbackAdvice = 'Execute natively within React/Browser runtime.';
    if (canonicalStatus === 'REQUIRES_ENGINE') {
      fallbackAdvice = entry.localFallbackDescription || 'Render interactive procedural canvas/audio simulation with honest engine status badge.';
    } else if (canonicalStatus === 'UNAVAILABLE') {
      fallbackAdvice = 'Feature cannot run in browser sandbox. Restrict workflow or provide client-side mock abstraction.';
    }

    return {
      canonicalStatus,
      entry,
      isTruthful: true,
      fallbackAdvice
    };
  }

  /**
   * Audits the entire requirement specification against honest capability boundaries.
   */
  public static auditCapabilitiesForSpec(spec: RequirementSpec): {
    supported: string[];
    availableLocally: string[];
    availableViaPackage: string[];
    requiresEngine: CapabilityRegistryEntry[];
    allCapabilitiesGrounded: boolean;
  } {
    const supported: string[] = [];
    const availableLocally: string[] = [];
    const availableViaPackage: string[] = [];
    const requiresEngine: CapabilityRegistryEntry[] = [];

    // Check runtime requirements
    if (spec.runtimeRequirements.canvasRequired) {
      availableLocally.push('HTML5 Canvas 2D Engine');
    }
    if (spec.runtimeRequirements.audioRequired) {
      availableLocally.push('Web Audio Synthesizer');
    }
    if (spec.runtimeRequirements.webGlRequired) {
      availableLocally.push('WebGL Shader Pipeline');
    }

    // Check external engine requirements
    for (const ext of spec.externalEngineRequirements) {
      const entry = this.getCapabilityById(ext.capabilityId) || {
        id: ext.capabilityId,
        name: ext.name,
        category: 'CREATIVE_AI' as const,
        status: ext.status,
        description: `External engine requirement: ${ext.requiredEngineName}`,
        engineRequiredName: ext.requiredEngineName,
        localFallbackDescription: ext.fallbackStrategy
      };

      if (ext.status === 'REQUIRES_ENGINE' || ext.status === 'EXTERNAL_ENGINE_REQUIRED') {
        requiresEngine.push(entry);
      } else if (ext.status === 'AVAILABLE_THROUGH_EXISTING_ENGINE') {
        availableViaPackage.push(ext.name);
      } else if (ext.status === 'AVAILABLE_LOCALLY' || ext.status === 'LOCAL_AVAILABLE') {
        availableLocally.push(ext.name);
      } else {
        supported.push(ext.name);
      }
    }

    // Always include core React UI support
    supported.push('React 19 + TypeScript + Tailwind CSS');

    return {
      supported,
      availableLocally,
      availableViaPackage,
      requiresEngine,
      allCapabilitiesGrounded: true
    };
  }
}
