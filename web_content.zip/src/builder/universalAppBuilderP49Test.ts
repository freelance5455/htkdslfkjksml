/**
 * GODEX P4.9 — Universal App Builder Test Suite
 * 
 * Comprehensive empirical test suite for P4.9 Professional Color Science & Cinematic Finishing:
 * 
 * 1. Color Management & Chromaticity Math (sRGB, Rec.709, Display P3, Linear RGB, ARRI LogC3, Cineon)
 * 2. EOTF / OETF Non-Linear Transfer Functions (Gamma 2.2, Rec.709 OETF, sRGB EOTF)
 * 3. Monotone Cubic Spline (Fritsch-Carlson) Interpolation & 256-Entry LUT Generation
 * 4. Primary Color Grading Math (Exposure EV, Temperature Kelvin, Tint, 3-Way Wheels, Sat/Vibrance)
 * 5. Procedural Cinematic Looks (Teal & Orange, Bleach Bypass, Noir, Film Print, Cyberpunk)
 * 6. Standard .cube 3D LUT Format Parser & Validator
 * 7. Dynamic Range & Signal Metrics Analyzer (Luma EV stops, Percentiles, Clipping & Crushing)
 * 8. Objective Color Quality Dossier (Gamut violations, White-Balance Neutrality, Scorecard)
 * 9. Vectorscope Skin-Tone Corridor Extraction & Protection Math
 * 10. 14-Stage Unified Cinematic Finishing Pipeline Execution
 * 11. Production Color Presets Application & State Immutability
 * 12. Frame-to-Frame Color & Luminance Drift Measurement
 */

import { ColorManagementEngine } from './creative/color/colorManagementEngine';
import { CurvesEngine } from './creative/color/curvesEngine';
import { CinematicColorGradingEngine } from './creative/color/cinematicColorGradingEngine';
import { LookManagementEngine } from './creative/color/lookManagementEngine';
import { DynamicRangeAnalyzer } from './creative/color/dynamicRangeAnalyzer';
import { ColorQualityAnalyzer } from './creative/color/colorQualityAnalyzer';
import { ColorPresets } from './creative/color/colorPresets';
import { CinematicFinishingPipeline } from './creative/cinematicFinishingPipeline';
import { SubjectConsistencyTracker } from './creative/subjectConsistencyTracker';

export interface P49TestResult {
  suite: string;
  name: string;
  passed: boolean;
  message?: string;
  latencyMs: number;
}

export async function runUniversalAppBuilderP49Tests(): Promise<{
  total: number;
  passed: number;
  failed: number;
  results: P49TestResult[];
}> {
  const results: P49TestResult[] = [];

  const runTest = async (suite: string, name: string, fn: () => Promise<void> | void) => {
    const tStart = performance.now();
    try {
      await fn();
      results.push({
        suite,
        name,
        passed: true,
        latencyMs: parseFloat((performance.now() - tStart).toFixed(2))
      });
    } catch (err: any) {
      results.push({
        suite,
        name,
        passed: false,
        message: err?.message || String(err),
        latencyMs: parseFloat((performance.now() - tStart).toFixed(2))
      });
    }
  };

  // =========================================================================
  // SUITE 1: COLOR MANAGEMENT & CHROMATICITY MATH
  // =========================================================================
  await runTest('ColorManagement', 'Color Space Chromaticities and Gamut Definition', () => {
    const cm = ColorManagementEngine.getInstance();
    const srgb = cm.getColorSpaceDefinition('sRGB');
    const p3 = cm.getColorSpaceDefinition('DisplayP3');
    const rec709 = cm.getColorSpaceDefinition('Rec709');

    if (!srgb || !p3 || !rec709) throw new Error('Failed to retrieve color space definitions');
    if (srgb.whitePoint.x !== 0.3127 || srgb.whitePoint.y !== 0.3290) throw new Error('D65 White point mismatch in sRGB');
    if (p3.primaries.r.x !== 0.680 || p3.primaries.r.y !== 0.320) throw new Error('Display P3 red primary coordinate mismatch');
  });

  await runTest('ColorManagement', 'EOTF / OETF Linear & Gamma Transfer Functions', () => {
    const cm = ColorManagementEngine.getInstance();
    // Test sRGB roundtrip
    const gammaIn = 0.5;
    const linear = cm.srgbToLinear(gammaIn);
    const gammaOut = cm.linearToSrgb(linear);
    if (Math.abs(gammaIn - gammaOut) > 0.001) {
      throw new Error(`sRGB EOTF/OETF roundtrip error: in=${gammaIn}, out=${gammaOut}`);
    }

    // Test pure black and pure white
    if (cm.srgbToLinear(0.0) !== 0.0) throw new Error('sRGB black point must map to 0.0');
    if (cm.srgbToLinear(1.0) !== 1.0) throw new Error('sRGB white point must map to 1.0');
  });

  await runTest('ColorManagement', 'Color Space Conversion: sRGB to Display P3 to Linear', () => {
    const cm = ColorManagementEngine.getInstance();
    const rgb = { r: 0.8, g: 0.2, b: 0.1 };
    const p3 = cm.convertColorSpace(rgb, 'sRGB', 'DisplayP3');
    const linear = cm.convertColorSpace(p3, 'DisplayP3', 'LinearRGB');

    if (p3.r < 0 || p3.r > 1 || p3.g < 0 || p3.g > 1 || p3.b < 0 || p3.b > 1) {
      throw new Error('Converted P3 color out of range');
    }
    if (linear.r <= 0 || linear.g < 0) {
      throw new Error('Linear RGB conversion invalid');
    }
  });

  await runTest('ColorManagement', 'Logarithmic Curve Transforms: ARRI LogC3 & Cineon', () => {
    const cm = ColorManagementEngine.getInstance();
    const linearMidGray = 0.18; // 18% reflective gray
    const logC3 = cm.convertColorSpace({ r: linearMidGray, g: linearMidGray, b: linearMidGray }, 'LinearRGB', 'ARRI_LogC3');
    // 18% gray in LogC3 is roughly ~0.39-0.40
    if (logC3.r < 0.35 || logC3.r > 0.45) {
      throw new Error(`LogC3 18% middle-gray value unexpected: ${logC3.r}`);
    }
  });

  await runTest('ColorManagement', 'Browser Color Capability Probing', () => {
    const cm = ColorManagementEngine.getInstance();
    const probe = cm.probeBrowserColorCapabilities();
    if (!probe.classification || probe.classification !== 'LOCAL_DETERMINISTIC') {
      throw new Error('Browser probing provenance classification must be LOCAL_DETERMINISTIC');
    }
  });

  // =========================================================================
  // SUITE 2: MONOTONE CUBIC SPLINE & CURVES ENGINE
  // =========================================================================
  await runTest('CurvesEngine', 'Fritsch-Carlson Monotone Spline Evaluation', () => {
    const ce = CurvesEngine.getInstance();
    const points = [
      { x: 0.0, y: 0.0 },
      { x: 0.25, y: 0.15 }, // Toe lift / dip
      { x: 0.75, y: 0.85 }, // Shoulder
      { x: 1.0, y: 1.0 }
    ];

    const y0 = ce.evaluateCurve(points, 0.0);
    const yMid = ce.evaluateCurve(points, 0.5);
    const y1 = ce.evaluateCurve(points, 1.0);

    if (Math.abs(y0 - 0.0) > 0.001) throw new Error(`Curve at x=0 must be 0.0, got ${y0}`);
    if (Math.abs(y1 - 1.0) > 0.001) throw new Error(`Curve at x=1 must be 1.0, got ${y1}`);
    if (yMid <= 0.15 || yMid >= 0.85) throw new Error(`Curve midtone monotonicity error: yMid=${yMid}`);
  });

  await runTest('CurvesEngine', '256-Entry 1D LUT Generation', () => {
    const ce = CurvesEngine.getInstance();
    const curves = CurvesEngine.getDefaultCurves();
    const luts = ce.generateCombinedLuts(curves);

    if (luts.master.length !== 256 || luts.red.length !== 256 || luts.luma.length !== 256) {
      throw new Error('LUT table size must be exactly 256 entries');
    }
    if (luts.master[0] !== 0.0 || luts.master[255] !== 1.0) {
      throw new Error('Default master LUT boundary error');
    }
  });

  await runTest('CurvesEngine', '256-Bin RGB & Luma Histogram Calculation', () => {
    const ce = CurvesEngine.getInstance();
    const testData = new Uint8ClampedArray(64 * 64 * 4);
    for (let i = 0; i < testData.length; i += 4) {
      testData[i] = 128;     // R
      testData[i + 1] = 100; // G
      testData[i + 2] = 200; // B
      testData[i + 3] = 255; // A
    }

    const hist = ce.computeHistogram(testData, 1);
    if (hist.totalSamples !== 64 * 64) throw new Error('Histogram total samples count mismatch');
    if (hist.red[128] !== 64 * 64) throw new Error('Red histogram peak must be at bin 128');
    if (hist.green[100] !== 64 * 64) throw new Error('Green histogram peak must be at bin 100');
    if (hist.blue[200] !== 64 * 64) throw new Error('Blue histogram peak must be at bin 200');
  });

  // =========================================================================
  // SUITE 3: PRIMARY COLOR GRADING & 3-WAY WHEELS MATH
  // =========================================================================
  await runTest('PrimaryGrading', 'Exposure EV Stops Scaling', () => {
    const ge = CinematicColorGradingEngine.getInstance();
    const defaultState = CinematicColorGradingEngine.getDefaultState();

    // +1 EV should double input linear intensity
    const gradePlus1 = ge.gradeRGB(0.25, 0.25, 0.25, { ...defaultState.primary, exposureEV: 1.0 }, defaultState.skinToneProtection);
    if (Math.abs(gradePlus1.r - 0.5) > 0.01) {
      throw new Error(`+1 EV exposure must double intensity: expected 0.5, got ${gradePlus1.r}`);
    }

    // -1 EV should halve input linear intensity
    const gradeMinus1 = ge.gradeRGB(0.5, 0.5, 0.5, { ...defaultState.primary, exposureEV: -1.0 }, defaultState.skinToneProtection);
    if (Math.abs(gradeMinus1.r - 0.25) > 0.01) {
      throw new Error(`-1 EV exposure must halve intensity: expected 0.25, got ${gradeMinus1.r}`);
    }
  });

  await runTest('PrimaryGrading', 'White Balance (Temperature & Tint)', () => {
    const ge = CinematicColorGradingEngine.getInstance();
    const defaultState = CinematicColorGradingEngine.getDefaultState();

    // 3200K (Warm / Tungsten) should increase Red and decrease Blue
    const warmGrade = ge.gradeRGB(0.5, 0.5, 0.5, { ...defaultState.primary, temperatureKelvin: 3200 }, defaultState.skinToneProtection);
    if (warmGrade.r <= warmGrade.b) {
      throw new Error(`Warm temperature must have Red > Blue: R=${warmGrade.r}, B=${warmGrade.b}`);
    }

    // 7500K (Cool / Sky) should increase Blue and decrease Red
    const coolGrade = ge.gradeRGB(0.5, 0.5, 0.5, { ...defaultState.primary, temperatureKelvin: 7500 }, defaultState.skinToneProtection);
    if (coolGrade.b <= coolGrade.r) {
      throw new Error(`Cool temperature must have Blue > Red: R=${coolGrade.r}, B=${coolGrade.b}`);
    }
  });

  await runTest('PrimaryGrading', '3-Way Color Wheels (Lift, Gamma, Gain, Offset)', () => {
    const ge = CinematicColorGradingEngine.getInstance();
    const state = CinematicColorGradingEngine.getDefaultState();

    // Blue Lift should primarily affect shadow pixels (e.g. 0.05) and have negligible effect on highlights (0.95)
    state.primary.wheels.lift = { angleDeg: 240, magnitude: 0.3, masterLuma: 0, r: -0.1, g: -0.1, b: 0.2 };

    const shadowGraded = ge.gradeRGB(0.05, 0.05, 0.05, state.primary, state.skinToneProtection);
    const highlightGraded = ge.gradeRGB(0.95, 0.95, 0.95, state.primary, state.skinToneProtection);

    if (shadowGraded.b <= 0.05) throw new Error('Blue lift must elevate shadow blue channel');
    if (Math.abs(highlightGraded.b - 0.95) > 0.05) throw new Error('Lift must not heavily distort highlights');
  });

  // =========================================================================
  // SUITE 4: PROCEDURAL CINEMATIC LOOKS & .CUBE PARSER
  // =========================================================================
  await runTest('LookManagement', 'Built-in Look Transforms & Determinism', () => {
    const lm = LookManagementEngine.getInstance();
    const neutralPixel = { r: 0.5, g: 0.5, b: 0.5 };

    // Bleach Bypass must increase contrast and reduce saturation
    const bb = lm.applyLookToRGB(neutralPixel.r, neutralPixel.g, neutralPixel.b, 'BLEACH_BYPASS', false);
    if (bb.r < 0 || bb.r > 1) throw new Error('Bleach bypass out of bounds');

    // Noir Classic must produce identical R, G, B channels
    const noir = lm.applyLookToRGB(0.7, 0.4, 0.2, 'NOIR_CLASSIC', false);
    if (Math.abs(noir.r - noir.g) > 0.001 || Math.abs(noir.g - noir.b) > 0.001) {
      throw new Error(`Monochrome noir must have R == G == B: R=${noir.r}, G=${noir.g}, B=${noir.b}`);
    }
  });

  await runTest('LookManagement', 'Standard .cube 3D LUT Parser & Validator', () => {
    const lm = LookManagementEngine.getInstance();
    const cubeSample = `
# Title
TITLE "Test3DLut"
LUT_3D_SIZE 2
DOMAIN_MIN 0.0 0.0 0.0
DOMAIN_MAX 1.0 1.0 1.0
0.0 0.0 0.0
1.0 0.0 0.0
0.0 1.0 0.0
1.0 1.0 0.0
0.0 0.0 1.0
1.0 0.0 1.0
0.0 1.0 1.0
1.0 1.0 1.0
`;
    const parsed = lm.parseCubeLut(cubeSample);
    if (!parsed.valid) throw new Error(`LUT parsing failed: ${parsed.errorMessage}`);
    if (parsed.size !== 2) throw new Error(`LUT size mismatch: expected 2, got ${parsed.size}`);
    if (parsed.tableData?.length !== 2 * 2 * 2 * 3) throw new Error('Parsed table data length mismatch');
  });

  // =========================================================================
  // SUITE 5: DYNAMIC RANGE & SIGNAL METRICS ANALYZER
  // =========================================================================
  await runTest('DynamicRange', 'Dynamic Range EV Stops & Percentile Calculation', () => {
    const dra = DynamicRangeAnalyzer.getInstance();
    const buffer = new Uint8ClampedArray(100 * 100 * 4);

    // Populate with smooth linear gradient from black (0) to white (255)
    for (let i = 0; i < buffer.length; i += 4) {
      const v = Math.min(255, Math.round((i / (buffer.length - 4)) * 255));
      buffer[i] = v;
      buffer[i + 1] = v;
      buffer[i + 2] = v;
      buffer[i + 3] = 255;
    }

    const metrics = dra.analyzeDynamicRange(buffer, 1);
    if (metrics.minLuma !== 0.0) throw new Error(`Min luma must be 0.0, got ${metrics.minLuma}`);
    if (metrics.maxLuma !== 1.0) throw new Error(`Max luma must be 1.0, got ${metrics.maxLuma}`);
    if (metrics.dynamicRangeStops < 6.0) throw new Error(`Linear gradient dynamic range must be >= 6 stops, got ${metrics.dynamicRangeStops}`);
  });

  await runTest('DynamicRange', 'Highlight Clipping & Shadow Crushing Detection', () => {
    const dra = DynamicRangeAnalyzer.getInstance();
    const clippedBuffer = new Uint8ClampedArray(100 * 100 * 4);

    // 25% blown highlights, 25% crushed shadows, 50% midtones
    for (let i = 0; i < clippedBuffer.length; i += 4) {
      const idx = i / 4;
      if (idx < 2500) {
        clippedBuffer[i] = 255; clippedBuffer[i + 1] = 255; clippedBuffer[i + 2] = 255; // Clip
      } else if (idx < 5000) {
        clippedBuffer[i] = 0; clippedBuffer[i + 1] = 0; clippedBuffer[i + 2] = 0; // Crush
      } else {
        clippedBuffer[i] = 128; clippedBuffer[i + 1] = 128; clippedBuffer[i + 2] = 128; // Midtone
      }
      clippedBuffer[i + 3] = 255;
    }

    const metrics = dra.analyzeDynamicRange(clippedBuffer, 1);
    if (Math.abs(metrics.highlightClippingPercent - 25.0) > 1.0) {
      throw new Error(`Highlight clipping percent mismatch: expected ~25%, got ${metrics.highlightClippingPercent}%`);
    }
    if (Math.abs(metrics.shadowCrushPercent - 25.0) > 1.0) {
      throw new Error(`Shadow crush percent mismatch: expected ~25%, got ${metrics.shadowCrushPercent}%`);
    }
  });

  // =========================================================================
  // SUITE 6: OBJECTIVE COLOR QUALITY DOSSIER & VALIDATION
  // =========================================================================
  await runTest('QualityAnalyzer', 'Color Quality Dossier & Out-of-Gamut Scoring', () => {
    const cqa = ColorQualityAnalyzer.getInstance();
    const cleanBuffer = new Uint8ClampedArray(50 * 50 * 4);
    for (let i = 0; i < cleanBuffer.length; i += 4) {
      cleanBuffer[i] = 128; cleanBuffer[i + 1] = 128; cleanBuffer[i + 2] = 128; cleanBuffer[i + 3] = 255;
    }

    const dossier = cqa.evaluateColorQuality(cleanBuffer, 50, 50, 1);
    if (dossier.overallGradeScore < 90) {
      throw new Error(`Neutral clean buffer score must be >= 90, got ${dossier.overallGradeScore}`);
    }
    if (dossier.verdict !== 'EXCELLENT') {
      throw new Error(`Expected verdict EXCELLENT, got ${dossier.verdict}`);
    }
  });

  // =========================================================================
  // SUITE 7: UNIFIED 14-STAGE CINEMATIC FINISHING PIPELINE
  // =========================================================================
  await runTest('FinishingPipeline', '14-Stage Unified Pipeline Execution & Integrity', () => {
    const pipeline = CinematicFinishingPipeline.getInstance();
    const width = 64;
    const height = 64;
    const buffer = new Uint8ClampedArray(width * height * 4);
    for (let i = 0; i < buffer.length; i += 4) {
      buffer[i] = 150; buffer[i + 1] = 120; buffer[i + 2] = 90; buffer[i + 3] = 255;
    }

    const res = pipeline.executePipeline(buffer, width, height);
    if (res.report.totalStagesExecuted !== 14) {
      throw new Error(`Pipeline must execute 14 stages, got ${res.report.totalStagesExecuted}`);
    }
    if (res.report.classification !== 'LOCAL_DETERMINISTIC') {
      throw new Error('Pipeline classification must be LOCAL_DETERMINISTIC');
    }
    if (res.processedData.length !== buffer.length) {
      throw new Error('Output buffer size mismatch');
    }
  });

  await runTest('FinishingPipeline', 'Production Presets Application & State Verification', () => {
    const defaultState = CinematicColorGradingEngine.getDefaultState();
    const cinematicState = ColorPresets.applyPreset(defaultState, 'CINEMATIC');
    const noirState = ColorPresets.applyPreset(defaultState, 'NOIR');

    if (cinematicState.lookPreset !== 'TEAL_AND_ORANGE') {
      throw new Error('Cinematic preset must configure TEAL_AND_ORANGE look');
    }
    if (noirState.primary.saturation !== 0.0) {
      throw new Error('Noir preset must configure 0.0 saturation');
    }
  });

  // =========================================================================
  // SUITE 8: SUBJECT COLOR DRIFT & SKIN-TONE CONTINUITY
  // =========================================================================
  await runTest('SubjectColorDrift', 'Frame-to-Frame Skin Tone Corridor Measurement', () => {
    const sct = SubjectConsistencyTracker.getInstance();
    const frameA = new Uint8ClampedArray(32 * 32 * 4);
    const frameB = new Uint8ClampedArray(32 * 32 * 4);

    // Fill with typical skin tone (R=210, G=140, B=105)
    for (let i = 0; i < frameA.length; i += 4) {
      frameA[i] = 210; frameA[i + 1] = 140; frameA[i + 2] = 105; frameA[i + 3] = 255;
      frameB[i] = 212; frameB[i + 1] = 138; frameB[i + 2] = 107; frameB[i + 3] = 255;
    }

    const drift = sct.evaluateSubjectColorDrift(frameA, frameB);
    if (!drift.skinTonePreserved) throw new Error('Skin tone preservation must pass for identical skin frames');
    if (drift.colorDriftScore < 95) throw new Error(`Color drift score should be high (>95), got ${drift.colorDriftScore}`);
  });

  const total = results.length;
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    total,
    passed,
    failed,
    results
  };
}
