/**
 * GODEX P5.3 — Playable Media Delivery & Output Ingestion Test Suite
 * 
 * Verifies:
 * 1. PlayableMediaDeliveryEngine singleton, registry, and memory lifecycle (Object URL creation & revocation)
 * 2. ProductionOutputIngestionEngine binary magic byte validation (WebM, WAV, PNG, MP4)
 * 3. Rejection of corrupted, truncated, and mismatched binary payloads
 * 4. Deterministic playable media synthesis (valid EBML WebM, RIFF WAV, PNG containers)
 * 5. Frame-accurate playback math, SMPTE timecode conversions (24/25/30/60 fps)
 * 6. Playback transport controls (play, pause, seek, step frame, speed, volume, loop)
 * 7. End-to-end integration from ProductionExecutionController -> Ingestion -> Delivery Engine
 * 8. Epistemic truth invariance under REAL_NEURAL (REQUIRES_ENGINE without fake media)
 * 9. Epistemic truth invariance under LOCAL_DETERMINISTIC (valid browser-native media)
 * 10. Memory pressure governor integration and resource protection
 */

import { PlayableMediaDeliveryEngine, PlayableMediaAsset } from './creative/production/playableMediaDeliveryEngine';
import { ProductionOutputIngestionEngine } from './creative/production/productionOutputIngestionEngine';
import { ProductionExecutionController } from './creative/production/productionExecutionController';
import { ProductionProjectFactory } from './creative/production/productionProjectFactory';
import { ProductionProofEngine } from './creative/production/productionProofEngine';
import { MobileProductionGovernor } from './creative/production/mobileProductionGovernor';
import { ProductionRuntimeCapabilityEngine } from './creative/production/productionRuntimeCapabilityEngine';
import { EpistemicTruthClassification, ActualGenerationStatus } from './creative/production/productionTypes';

export interface P53TestResult {
  id: string;
  name: string;
  passed: boolean;
  durationMs: number;
  details?: string;
  error?: string;
}

export interface P53TestSuiteReport {
  totalTests: number;
  passedTests: number;
  failedTests: number;
  results: P53TestResult[];
}

export class UniversalAppBuilderP53Test {
  public static async runAllTests(): Promise<P53TestSuiteReport> {
    const results: P53TestResult[] = [];

    const runTest = async (id: string, name: string, fn: () => Promise<void> | void) => {
      const start = Date.now();
      try {
        await fn();
        results.push({
          id,
          name,
          passed: true,
          durationMs: Date.now() - start
        });
      } catch (err: any) {
        results.push({
          id,
          name,
          passed: false,
          durationMs: Date.now() - start,
          error: err.message || String(err)
        });
      }
    };

    const deliveryEngine = PlayableMediaDeliveryEngine.getInstance();
    const ingestionEngine = ProductionOutputIngestionEngine.getInstance();
    const execController = ProductionExecutionController.getInstance();
    const proofEngine = ProductionProofEngine.getInstance();
    const mobileGovernor = MobileProductionGovernor.getInstance();
    const capabilityEngine = ProductionRuntimeCapabilityEngine.getInstance();

    // ------------------------------------------------------------------------
    // GROUP 1: ENGINE INITIALIZATION & SINGLETONS
    // ------------------------------------------------------------------------
    await runTest('P53-01', 'PlayableMediaDeliveryEngine Singleton Integrity', () => {
      if (!deliveryEngine) throw new Error('Delivery engine is null');
      const inst2 = PlayableMediaDeliveryEngine.getInstance();
      if (deliveryEngine !== inst2) throw new Error('Delivery engine is not singleton');
    });

    await runTest('P53-02', 'ProductionOutputIngestionEngine Singleton Integrity', () => {
      if (!ingestionEngine) throw new Error('Ingestion engine is null');
      const inst2 = ProductionOutputIngestionEngine.getInstance();
      if (ingestionEngine !== inst2) throw new Error('Ingestion engine is not singleton');
    });

    // ------------------------------------------------------------------------
    // GROUP 2: DETERMINISTIC BINARY SYNTHESIS & MAGIC BYTE VALIDATION
    // ------------------------------------------------------------------------
    await runTest('P53-03', 'Generate Valid WebM Binary Container', () => {
      const webmBytes = deliveryEngine.generateDeterministicPlayableMedia({
        format: 'WEBM',
        width: 1280,
        height: 720,
        durationSec: 2.0,
        fps: 24
      });

      if (!webmBytes || webmBytes.byteLength < 32) {
        throw new Error(`WebM binary length insufficient: ${webmBytes?.byteLength || 0}`);
      }

      // Check EBML Header Magic Bytes (0x1A 0x45 0xDF 0xA3)
      if (
        webmBytes[0] !== 0x1a ||
        webmBytes[1] !== 0x45 ||
        webmBytes[2] !== 0xdf ||
        webmBytes[3] !== 0xa3
      ) {
        throw new Error('WebM magic bytes mismatch (expected 1A 45 DF A3)');
      }
    });

    await runTest('P53-04', 'Generate Valid WAV RIFF PCM Container', () => {
      const wavBytes = deliveryEngine.generateDeterministicPlayableMedia({
        format: 'WAV',
        durationSec: 1.0,
        sampleRate: 48000
      });

      if (!wavBytes || wavBytes.byteLength < 44) {
        throw new Error(`WAV binary length insufficient: ${wavBytes?.byteLength || 0}`);
      }

      // Check RIFF Magic Bytes ('R' 'I' 'F' 'F' ... 'W' 'A' 'V' 'E')
      const riffHeader = String.fromCharCode(wavBytes[0], wavBytes[1], wavBytes[2], wavBytes[3]);
      const waveHeader = String.fromCharCode(wavBytes[8], wavBytes[9], wavBytes[10], wavBytes[11]);
      if (riffHeader !== 'RIFF' || waveHeader !== 'WAVE') {
        throw new Error(`WAV header mismatch: riff=${riffHeader}, wave=${waveHeader}`);
      }
    });

    await runTest('P53-05', 'Generate Valid PNG Image Container', () => {
      const pngBytes = deliveryEngine.generateDeterministicPlayableMedia({
        format: 'PNG',
        width: 1920,
        height: 1080
      });

      if (!pngBytes || pngBytes.byteLength < 8) {
        throw new Error(`PNG binary length insufficient: ${pngBytes?.byteLength || 0}`);
      }

      // Check PNG Magic Bytes (89 50 4E 47 0D 0A 1A 0A)
      if (
        pngBytes[0] !== 0x89 ||
        pngBytes[1] !== 0x50 ||
        pngBytes[2] !== 0x4e ||
        pngBytes[3] !== 0x47 ||
        pngBytes[4] !== 0x0d ||
        pngBytes[5] !== 0x0a ||
        pngBytes[6] !== 0x1a ||
        pngBytes[7] !== 0x0a
      ) {
        throw new Error('PNG magic signature mismatch');
      }
    });

    // ------------------------------------------------------------------------
    // GROUP 3: PRODUCTION OUTPUT INGESTION ENGINE VALIDATION CHECKS
    // ------------------------------------------------------------------------
    await runTest('P53-06', 'Ingestion Engine Validates WebM Container', async () => {
      const webmBytes = deliveryEngine.generateDeterministicPlayableMedia({
        format: 'WEBM',
        width: 1280,
        height: 720,
        durationSec: 2.5,
        fps: 24
      });

      const receipt = await ingestionEngine.ingestAndValidate(webmBytes, {
        expectedFormat: 'WEBM',
        minWidth: 640,
        minHeight: 360
      });

      if (!receipt.valid) {
        throw new Error(`Ingestion validation failed: ${receipt.defectsDetected.join('; ')}`);
      }
      if (receipt.format !== 'WEBM') {
        throw new Error(`Detected format mismatch: ${receipt.format}`);
      }
    });

    await runTest('P53-07', 'Ingestion Engine Validates WAV Container', async () => {
      const wavBytes = deliveryEngine.generateDeterministicPlayableMedia({
        format: 'WAV',
        durationSec: 2.0,
        sampleRate: 48000
      });

      const receipt = await ingestionEngine.ingestAndValidate(wavBytes, {
        expectedFormat: 'WAV'
      });

      if (!receipt.valid) {
        throw new Error(`WAV Ingestion validation failed: ${receipt.defectsDetected.join('; ')}`);
      }
      if (receipt.format !== 'WAV') {
        throw new Error(`Detected format mismatch: ${receipt.format}`);
      }
    });

    await runTest('P53-08', 'Ingestion Engine Rejects Truncated / Corrupted Payload', async () => {
      // 8 bytes of garbage
      const corruptedBytes = new Uint8Array([0x00, 0x01, 0x02, 0x03, 0xFF, 0xEE, 0xDD, 0xCC]);
      const receipt = await ingestionEngine.ingestAndValidate(corruptedBytes, {
        expectedFormat: 'WEBM'
      });

      if (receipt.valid) {
        throw new Error('Ingestion engine should have rejected corrupted payload');
      }
      if (receipt.defectsDetected.length === 0) {
        throw new Error('Expected failure reasons in receipt');
      }
    });

    await runTest('P53-09', 'Ingestion Engine Rejects Empty or Zero-Length Payload', async () => {
      const emptyBytes = new Uint8Array(0);
      const receipt = await ingestionEngine.ingestAndValidate(emptyBytes, {
        expectedFormat: 'WEBM'
      });

      if (receipt.valid) {
        throw new Error('Ingestion engine should have rejected empty payload');
      }
    });

    // ------------------------------------------------------------------------
    // GROUP 4: PLAYABLE MEDIA ASSET REGISTRY & MEMORY LIFECYCLE
    // ------------------------------------------------------------------------
    await runTest('P53-10', 'Register Media Payload & Create Object URL Asset', async () => {
      const webmBytes = deliveryEngine.generateDeterministicPlayableMedia({
        format: 'WEBM',
        width: 1920,
        height: 1080,
        durationSec: 3.0,
        fps: 24
      });

      const asset = await deliveryEngine.registerMediaPayload({
        executionId: 'exec_test_001',
        projectId: 'project_test_001',
        title: 'Cinematic Test Scene',
        bytes: webmBytes,
        mimeType: 'video/webm',
        expectedFormat: 'WEBM',
        dimensions: { width: 1920, height: 1080 },
        durationSec: 3.0,
        fps: 24,
        truthClassification: 'LOCAL_DETERMINISTIC'
      });

      if (!asset.id) throw new Error('Asset ID missing');
      if (!asset.objectUrl) throw new Error('Object URL missing');
      if (asset.sizeBytes !== webmBytes.byteLength) throw new Error('Size mismatch');
      if (asset.truthClassification !== 'LOCAL_DETERMINISTIC') {
        throw new Error(`Truth classification mismatch: ${asset.truthClassification}`);
      }

      const active = deliveryEngine.getActiveAsset();
      if (!active || active.id !== asset.id) {
        throw new Error('Active asset was not set correctly');
      }
    });

    await runTest('P53-11', 'List, Retrieve, and Query Assets', async () => {
      const assets = deliveryEngine.listAssets();
      if (assets.length === 0) throw new Error('Asset list should not be empty');
      const retrieved = deliveryEngine.getAsset(assets[0].id);
      if (!retrieved || retrieved.id !== assets[0].id) {
        throw new Error('Failed to retrieve asset by ID');
      }
    });

    await runTest('P53-12', 'Revoke Specific Media Asset & Free Memory', async () => {
      const assets = deliveryEngine.listAssets();
      const targetId = assets[0].id;
      const revoked = deliveryEngine.revokeMediaAsset(targetId);
      if (!revoked) throw new Error('Revocation returned false');
      const queryAfter = deliveryEngine.getAsset(targetId);
      if (queryAfter !== null) throw new Error('Asset still exists after revocation');
    });

    await runTest('P53-13', 'Revoke All Media Assets Bulk Memory Cleanup', async () => {
      // Register 3 test assets
      for (let i = 0; i < 3; i++) {
        const bytes = deliveryEngine.generateDeterministicPlayableMedia({ format: 'WAV', durationSec: 0.5 });
        await deliveryEngine.registerMediaPayload({
          executionId: `exec_bulk_${i}`,
          projectId: `proj_bulk_${i}`,
          title: `Bulk Audio ${i}`,
          bytes,
          mimeType: 'audio/wav',
          truthClassification: 'LOCAL_DETERMINISTIC'
        });
      }

      if (deliveryEngine.listAssets().length < 3) throw new Error('Failed to register bulk assets');
      deliveryEngine.revokeAllMediaAssets();
      if (deliveryEngine.listAssets().length !== 0) throw new Error('Media registry not cleared');
      if (deliveryEngine.getActiveAsset() !== null) throw new Error('Active asset not cleared');
    });

    // ------------------------------------------------------------------------
    // GROUP 5: FRAME-ACCURATE TIMECODE & PLAYBACK MATH
    // ------------------------------------------------------------------------
    await runTest('P53-14', 'SMPTE Timecode Format 24 FPS', () => {
      const tc0 = deliveryEngine.formatTimecode(0, 24);
      if (tc0 !== '00:00:00:00') throw new Error(`Expected 00:00:00:00, got ${tc0}`);

      const tc1Sec = deliveryEngine.formatTimecode(1.0, 24);
      if (tc1Sec !== '00:00:01:00') throw new Error(`Expected 00:00:01:00, got ${tc1Sec}`);

      const tcComplex = deliveryEngine.formatTimecode(3665.5, 24); // 1h 1m 5s 12frames
      if (tcComplex !== '01:01:05:12') throw new Error(`Expected 01:01:05:12, got ${tcComplex}`);
    });

    await runTest('P53-15', 'SMPTE Timecode Format 30 FPS and 60 FPS', () => {
      const tc30 = deliveryEngine.formatTimecode(0.5, 30);
      if (tc30 !== '00:00:00:15') throw new Error(`Expected 00:00:00:15 at 30fps, got ${tc30}`);

      const tc60 = deliveryEngine.formatTimecode(0.75, 60);
      if (tc60 !== '00:00:00:45') throw new Error(`Expected 00:00:00:45 at 60fps, got ${tc60}`);
    });

    // ------------------------------------------------------------------------
    // GROUP 6: TRANSPORT CONTROLS & STATE ENGINE
    // ------------------------------------------------------------------------
    await runTest('P53-16', 'Transport Play, Pause, and Toggle State', async () => {
      // Register an asset to establish active state
      const bytes = deliveryEngine.generateDeterministicPlayableMedia({ format: 'WEBM', durationSec: 10.0, fps: 24 });
      await deliveryEngine.registerMediaPayload({
        executionId: 'exec_transport_test',
        projectId: 'proj_transport',
        title: 'Transport Test Video',
        bytes,
        mimeType: 'video/webm',
        durationSec: 10.0,
        fps: 24,
        truthClassification: 'LOCAL_DETERMINISTIC'
      });

      deliveryEngine.play();
      if (!deliveryEngine.getPlaybackState().isPlaying) throw new Error('isPlaying should be true');

      deliveryEngine.pause();
      if (deliveryEngine.getPlaybackState().isPlaying) throw new Error('isPlaying should be false');

      deliveryEngine.togglePlay();
      if (!deliveryEngine.getPlaybackState().isPlaying) throw new Error('togglePlay should set isPlaying true');
      deliveryEngine.pause();
    });

    await runTest('P53-17', 'Transport Seek to Time & Seek to Frame', () => {
      deliveryEngine.seekToTime(4.5);
      const s1 = deliveryEngine.getPlaybackState();
      if (s1.currentTimeSec !== 4.5) throw new Error(`Seek time mismatch: ${s1.currentTimeSec}`);
      if (s1.currentFrame !== Math.floor(4.5 * 24)) throw new Error(`Frame mismatch: ${s1.currentFrame}`);

      deliveryEngine.seekToFrame(48); // Exactly 2.0 seconds at 24fps
      const s2 = deliveryEngine.getPlaybackState();
      if (s2.currentFrame !== 48) throw new Error(`Seek frame mismatch: ${s2.currentFrame}`);
      if (s2.currentTimeSec !== 2.0) throw new Error(`Seek time calculated incorrectly: ${s2.currentTimeSec}`);
    });

    await runTest('P53-18', 'Transport Step Frame Forward and Backward', () => {
      deliveryEngine.seekToFrame(10);
      deliveryEngine.stepFrame(1);
      if (deliveryEngine.getPlaybackState().currentFrame !== 11) throw new Error('Step +1 failed');

      deliveryEngine.stepFrame(-5);
      if (deliveryEngine.getPlaybackState().currentFrame !== 6) throw new Error('Step -5 failed');
    });

    await runTest('P53-19', 'Transport Volume, Muting, Looping, and Speed', () => {
      deliveryEngine.setVolume(0.75);
      if (deliveryEngine.getPlaybackState().volume !== 0.75) throw new Error('Volume mismatch');

      deliveryEngine.setMuted(true);
      if (!deliveryEngine.getPlaybackState().isMuted) throw new Error('Mute failed');

      deliveryEngine.setLooping(true);
      if (!deliveryEngine.getPlaybackState().isLooping) throw new Error('Loop failed');

      deliveryEngine.setPlaybackSpeed(1.5);
      if (deliveryEngine.getPlaybackState().playbackSpeed !== 1.5) throw new Error('Speed mismatch');
    });

    // ------------------------------------------------------------------------
    // GROUP 7: END-TO-END ORCHESTRATION PIPELINE INTEGRATION
    // ------------------------------------------------------------------------
    await runTest('P53-20', 'Pipeline LOCAL_DETERMINISTIC Produces PlayableMediaAsset', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const result = await execController.executeProductionPipeline(project, {
        executionMode: 'LOCAL_DETERMINISTIC'
      });

      if (!result.success) {
        throw new Error(`Pipeline failed: ${result.error || result.statusCode}`);
      }
      if (!result.playableAsset) {
        throw new Error('Pipeline completed successfully but no PlayableMediaAsset was created');
      }
      if (result.playableAsset.truthClassification !== 'LOCAL_DETERMINISTIC') {
        throw new Error(`Truth classification mismatch: ${result.playableAsset.truthClassification}`);
      }
      if (!result.playableAsset.objectUrl) {
        throw new Error('PlayableMediaAsset objectUrl is empty');
      }
    });

    await runTest('P53-21', 'Pipeline REAL_NEURAL Truthfully Reports REQUIRES_ENGINE When Offline', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const result = await execController.executeProductionPipeline(project, {
        executionMode: 'REAL_NEURAL',
        targetEngineId: 'engine-comfyui-local'
      });

      // If ComfyUI is offline, it must return REQUIRES_ENGINE and not fabricate
      if (result.statusCode === 'REQUIRES_ENGINE') {
        if (result.playableAsset) {
          throw new Error('REQUIRES_ENGINE must not fabricate a playable media asset');
        }
        if (result.proof.epistemicTruthClassification !== 'REQUIRES_ENGINE') {
          throw new Error(`Proof truth classification mismatch: ${result.proof.epistemicTruthClassification}`);
        }
      } else if (result.statusCode === 'REAL_NEURAL_COMPLETED') {
        // In the event ComfyUI is actually running
        if (!result.playableAsset) throw new Error('Real neural completed but no asset created');
        if (result.playableAsset.truthClassification !== 'REAL_NEURAL_GENERATED') {
          throw new Error('Real neural output mismatch');
        }
      }
    });

    // ------------------------------------------------------------------------
    // GROUP 8: MOBILE PRODUCTION GOVERNOR & HARDWARE PROFILE PROTECTION
    // ------------------------------------------------------------------------
    await runTest('P53-22', 'Mobile Governor Policy Clamping Check', async () => {
      const matrix = await capabilityEngine.probeCapabilities();
      const policy = mobileGovernor.resolvePolicy(matrix);
      if (!policy.profile) throw new Error('Policy profile missing');
      if (policy.maxResolution.width <= 0 || policy.maxResolution.height <= 0) {
        throw new Error('Invalid clamped resolution limit');
      }

      // Test spec clamping
      const clamped = mobileGovernor.clampRenderSpec(3840, 2160, 60, policy);
      if (clamped.width > policy.maxResolution.width) {
        throw new Error(`Clamped width ${clamped.width} exceeds policy max ${policy.maxResolution.width}`);
      }
      if (clamped.fps > policy.maxFps) {
        throw new Error(`Clamped fps ${clamped.fps} exceeds policy max ${policy.maxFps}`);
      }
    });

    await runTest('P53-23', 'Memory Pressure Check', () => {
      const policy = mobileGovernor.resolvePolicy({
        timestamp: Date.now(),
        environment: 'BROWSER',
        empiricalDeviceTier: 'TIER_3_DESKTOP_PRO',
        hardwareConcurrency: 8,
        devicePixelRatio: 2,
        maxTextureDimension: 16384,
        memoryEstimateMb: 8192,
        capabilities: {} as any,
        supportedMimeTypes: {
          videoWebm: true,
          videoMp4: true,
          imagePng: true,
          imageJpeg: true,
          imageWebp: true,
          audioWav: true,
          audioWebm: true
        }
      });

      const memCheck = mobileGovernor.checkMemoryPressure(policy);
      if (!memCheck.pressureLevel) throw new Error('Pressure level missing');
    });

    // ------------------------------------------------------------------------
    // GROUP 9: PROOF ENGINE INTEGRITY & ZERO FABRICATION
    // ------------------------------------------------------------------------
    await runTest('P53-24', 'Execution Proof Container Signature & Integrity Check', async () => {
      const project = ProductionProjectFactory.createCinematicProject();
      const qualityReport = execController.getLastQualityReport() || {
        verdict: 'PASS' as const,
        overallScore: 98,
        categories: {} as any,
        reasons: [],
        timestamp: Date.now()
      };

      const webmBytes = deliveryEngine.generateDeterministicPlayableMedia({ format: 'WEBM' });
      const proof = await proofEngine.generateProof({
        project,
        qualityReport,
        generationStatus: 'LOCAL_DETERMINISTIC_COMPLETED',
        selectedEngineId: 'engine-browser-native',
        selectedModelId: 'deterministic-canvas-vfx',
        outputBytes: webmBytes,
        outputMimeType: 'video/webm'
      });

      if (!proof.containerSignatureValid) {
        throw new Error('Container signature was reported invalid on genuine WebM');
      }
      if (!proof.integrityVerified) {
        throw new Error('Proof integrity was not verified');
      }
      if (proof.epistemicTruthClassification !== 'LOCAL_DETERMINISTIC') {
        throw new Error(`Expected LOCAL_DETERMINISTIC classification, got ${proof.epistemicTruthClassification}`);
      }
    });

    await runTest('P53-25', 'Full Zero-Fabrication Pipeline Telemetry Consistency', () => {
      const lastProof = execController.getLastExecutionProof();
      if (!lastProof) throw new Error('Last execution proof is null');
      if (!lastProof.proofId) throw new Error('Proof ID is missing');
      if (typeof lastProof.outputSizeBytes !== 'number') throw new Error('outputSizeBytes is invalid');
    });

    const passedTests = results.filter(r => r.passed).length;
    const failedTests = results.filter(r => !r.passed).length;

    return {
      totalTests: results.length,
      passedTests,
      failedTests,
      results
    };
  }
}
