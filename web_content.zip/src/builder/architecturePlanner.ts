/**
 * GODEX P2.0 — Architecture Planning Engine
 * Converts structured RequirementSpecs into concrete, modular file and component architectures.
 * Enforces Architectural Invariants:
 * - Declare Types Early in a dedicated types file.
 * - Split components into modular, focused files (no monolithic App.tsx bloat).
 * - Anti-Slop layout constraints: clear visual hierarchy, 16px+ padding, mathematical border radii.
 * - Grounded in actual workspace tools: React 19, TypeScript, Tailwind CSS, Lucide icons, Motion.
 */

import { RequirementSpec, ArchitectureSpec, ComponentSpec, ServiceSpec } from './builderTypes';

export class ArchitecturePlanner {
  /**
   * Plans the complete modular architecture for an application specification.
   */
  public static plan(spec: RequirementSpec): ArchitectureSpec {
    const slug = spec.appSlug;
    const baseDir = `src/apps/${slug}`;

    const typesFilePath = `${baseDir}/types.ts`;
    const rootComponentPath = `${baseDir}/${this.pascalCase(spec.appName)}App.tsx`;

    // 1. Pages
    const pages = spec.uiRequirements.pages.map((pageName, idx) => ({
      id: `page-${idx + 1}-${this.slugify(pageName)}`,
      name: pageName,
      path: idx === 0 ? '/' : `/${this.slugify(pageName)}`,
      description: `View container for ${pageName}`,
      componentRef: `${this.pascalCase(pageName)}View`
    }));

    // 2. Composite Modules & Layout Structure
    const compositeModules = spec.compositeFeatures || ['METRICS_DASHBOARD', 'CRUD_DATA_TABLE', 'MODAL_WORKFLOWS', 'SETTINGS_CONFIG'];
    const layoutStructure = {
      header: true,
      sidebar: pages.length > 2,
      drawer: compositeModules.includes('DETAIL_DRAWER'),
      bottomNav: false,
      modals: ['RecordModal', ...(compositeModules.includes('EXPORT_IMPORT') ? ['ExportModal'] : [])]
    };

    // 3. Services
    const services = this.planServices(spec, baseDir);

    // 4. Components
    const components = this.planComponents(spec, baseDir, rootComponentPath, pages, compositeModules);

    // 5. State Management
    const stateManagement = {
      type: 'CUSTOM_HOOK_STORE' as const,
      storeFilePath: `${baseDir}/use${this.pascalCase(spec.appName)}Store.ts`,
      globalStateProperties: [
        'activePage',
        'activeRole',
        'items',
        'isLoading',
        'searchQuery',
        'activeFilters',
        'selectedItem',
        'isModalOpen',
        'isDrawerOpen',
        'telemetryLogs',
        'toastNotification'
      ]
    };

    // 6. Data Layer
    const dataLayer = {
      modelsFilePath: typesFilePath,
      mockDataFilePath: `${baseDir}/initialData.ts`,
      persistenceAdapter: 'LocalStorageStateAdapter'
    };

    // 7. Backend Requirements
    const backendRequirements = {
      required: spec.externalEngineRequirements.some(e => e.status === 'REQUIRES_ENGINE'),
      reason: spec.externalEngineRequirements.length > 0 
        ? 'External API bridging for high-compute AI diffusion/dedicated servers.'
        : 'Client-side SPA architecture with local storage persistence.',
      apiEndpoints: spec.externalEngineRequirements.map(e => `/api/${this.slugify(e.name)}`)
    };

    // 8. Testing Strategy
    const testingStrategy = {
      unitTests: [
        `${baseDir}/__tests__/stateStore.test.ts`,
        `${baseDir}/__tests__/dataValidation.test.ts`
      ],
      astIntegrity: true,
      typecheck: true,
      runtimeVerification: [
        'Component mount verification',
        'Layout responsiveness verification',
        'State persistence roundtrip test',
        'Role permissions switch test',
        'Modal workflow lifecycle test'
      ]
    };

    return {
      appSlug: slug,
      rootComponentPath,
      typesFilePath,
      pages,
      components,
      services,
      compositeModules,
      layoutStructure,
      stateManagement,
      dataLayer,
      backendRequirements,
      runtimeRequirements: spec.runtimeRequirements.browserApis,
      integrations: spec.externalEngineRequirements.map(e => e.name),
      testingStrategy
    };
  }

  private static planServices(spec: RequirementSpec, baseDir: string): ServiceSpec[] {
    const services: ServiceSpec[] = [];

    // Core Data & State Service
    services.push({
      name: `${this.pascalCase(spec.appName)}DataService`,
      filePath: `${baseDir}/services/${this.camelCase(spec.appName)}DataService.ts`,
      purpose: 'Handles CRUD operations, query filtering, and local persistence synchronization.',
      methods: [
        { name: 'getItems', signature: '(): Promise<any[]>', description: 'Retrieves all items from storage' },
        { name: 'saveItem', signature: '(item: any): Promise<any>', description: 'Saves or updates an item' },
        { name: 'deleteItem', signature: '(id: string): Promise<boolean>', description: 'Removes an item by ID' },
        { name: 'exportArchive', signature: '(): Promise<Blob>', description: 'Exports data as JSON or ZIP' }
      ]
    });

    // Specialized services based on category
    if (spec.applicationType === 'AI_CREATIVE_STUDIO') {
      services.push({
        name: 'CreativePipelineEngine',
        filePath: `${baseDir}/services/creativePipelineEngine.ts`,
        purpose: 'Coordinates video diffusion generation requests, keyframe interpolation, and canvas shaders.',
        methods: [
          { name: 'dispatchGeneration', signature: '(params: any): Promise<any>', description: 'Dispatches video diffusion job with local fallback simulator' },
          { name: 'renderCanvasFrame', signature: '(ctx: CanvasRenderingContext2D, progress: number): void', description: 'Draws procedural shader animation frames' }
        ]
      });
    } else if (spec.applicationType === 'AUDIO_SYNTHESIZER') {
      services.push({
        name: 'AudioSynthesisService',
        filePath: `${baseDir}/services/audioSynthesisService.ts`,
        purpose: 'Wraps Web Audio API for polyphonic oscillator voices, ADSR envelopes, and sequencer clocks.',
        methods: [
          { name: 'playNote', signature: '(freq: number, duration?: number): void', description: 'Triggers a synth note voice' },
          { name: 'setEnvelope', signature: '(adsr: any): void', description: 'Updates Attack, Decay, Sustain, Release' },
          { name: 'startSequencer', signature: '(bpm: number, onStep: (step: number) => void): void', description: 'Starts 16-step clock timer' }
        ]
      });
    } else if (spec.applicationType === 'MULTIPLAYER_GAME') {
      services.push({
        name: 'GameNetworkEngine',
        filePath: `${baseDir}/services/gameNetworkEngine.ts`,
        purpose: 'Manages cross-tab BroadcastChannel networking and simulated AI opponent decision trees.',
        methods: [
          { name: 'broadcastPlayerState', signature: '(state: any): void', description: 'Sends local player position to other tabs' },
          { name: 'onRemotePlayerUpdate', signature: '(callback: (state: any) => void): () => void', description: 'Listens for remote player packets' },
          { name: 'getBotAction', signature: '(gameState: any): any', description: 'Computes autonomous opponent action' }
        ]
      });
    }

    return services;
  }

  private static planComponents(
    spec: RequirementSpec, 
    baseDir: string, 
    rootPath: string, 
    pages: ArchitectureSpec['pages'],
    compositeModules: string[] = []
  ): ComponentSpec[] {
    const components: ComponentSpec[] = [];

    // Subcomponents list for Root App
    const subCompNames = ['NavigationHeader', ...pages.map(p => p.componentRef)];
    if (compositeModules.includes('METRICS_DASHBOARD')) subCompNames.push('MetricsGrid');
    if (compositeModules.includes('CRUD_DATA_TABLE')) subCompNames.push('DataTable');
    if (compositeModules.includes('MODAL_WORKFLOWS')) subCompNames.push('RecordModal');
    if (compositeModules.includes('DETAIL_DRAWER')) subCompNames.push('DetailDrawer');
    if (compositeModules.includes('ANALYTICS_CHARTS')) subCompNames.push('AnalyticsChartCard');
    if (compositeModules.includes('SETTINGS_CONFIG')) subCompNames.push('SettingsPanel');
    if (compositeModules.includes('AUDIT_LOGS')) subCompNames.push('AuditLogViewer');
    if (compositeModules.includes('EXPORT_IMPORT')) subCompNames.push('ExportModal');
    if (compositeModules.includes('CANVAS_WORKSPACE')) subCompNames.push('InteractiveCanvas');
    if (compositeModules.includes('AUDIO_SYNTHESIZER')) subCompNames.push('AudioControls');
    if (compositeModules.includes('MEDIA_TIMELINE')) subCompNames.push('TimelineEditor');
    if (compositeModules.includes('MEDIA_BROWSER')) subCompNames.push('MediaBrowser');
    if (compositeModules.includes('PREVIEW_VIEWPORT')) subCompNames.push('PreviewViewport');
    if (compositeModules.includes('INSPECTOR_PANEL')) subCompNames.push('InspectorPanel');
    if (compositeModules.includes('LAYER_SYSTEM')) subCompNames.push('LayerSystem');
    if (compositeModules.includes('EFFECTS_RACK')) subCompNames.push('EffectsRack');
    if (compositeModules.includes('AUDIO_MIXER')) subCompNames.push('AudioMixer');
    if (compositeModules.includes('CAPTION_SUBTITLES')) subCompNames.push('CaptionSubtitles');
    if (compositeModules.includes('RENDER_QUEUE')) subCompNames.push('RenderQueue');
    if (compositeModules.includes('GENERATION_QUEUE')) subCompNames.push('GenerationQueue');
    if (compositeModules.includes('NODE_GRAPH')) subCompNames.push('NodeGraph');
    if (compositeModules.includes('KEYFRAME_ANIMATOR')) subCompNames.push('KeyframeAnimator');
    if (compositeModules.includes('STORYBOARD_CANVAS')) subCompNames.push('StoryboardCanvas');
    if (compositeModules.includes('HISTORY_UNDO_REDO')) subCompNames.push('HistoryControls');

    // Root App Component
    components.push({
      name: `${this.pascalCase(spec.appName)}App`,
      filePath: rootPath,
      purpose: 'Top-level application container coordinating navigation, global store, active view, and modal dialogs.',
      props: {},
      isRootOrPage: true,
      subComponents: subCompNames,
      dependencies: ['react', 'lucide-react', 'motion/react']
    });

    // Navigation Header
    components.push({
      name: 'NavigationHeader',
      filePath: `${baseDir}/components/NavigationHeader.tsx`,
      purpose: 'Application header with brand logo, title, view tabs, search input, role switcher, and primary action buttons.',
      props: {
        activePage: 'string',
        onNavigate: '(pageId: string) => void',
        searchQuery: 'string',
        onSearchChange: '(q: string) => void',
        activeRole: 'string',
        onRoleChange: '(role: string) => void',
        onOpenNewModal: '() => void'
      },
      isRootOrPage: false,
      dependencies: ['lucide-react']
    });

    // Composite Subcomponents
    if (compositeModules.includes('METRICS_DASHBOARD')) {
      components.push({
        name: 'MetricsGrid',
        filePath: `${baseDir}/components/MetricsGrid.tsx`,
        purpose: 'Adaptive KPI grid with visual indicators, deltas, and trend badges.',
        props: { metrics: 'MetricCardItem[]' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('CRUD_DATA_TABLE')) {
      components.push({
        name: 'DataTable',
        filePath: `${baseDir}/components/DataTable.tsx`,
        purpose: 'Interactive sortable table with search filtering, status chips, row actions, and pagination.',
        props: {
          items: 'any[]',
          searchQuery: 'string',
          onSelectItem: '(id: string) => void',
          onDeleteItem: '(id: string) => void',
          onEditItem: '(item: any) => void'
        },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('MODAL_WORKFLOWS')) {
      components.push({
        name: 'RecordModal',
        filePath: `${baseDir}/components/RecordModal.tsx`,
        purpose: 'Form dialog for creating and updating data records with live schema validation.',
        props: {
          isOpen: 'boolean',
          initialData: 'any',
          onClose: '() => void',
          onSubmit: '(data: any) => void'
        },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('DETAIL_DRAWER')) {
      components.push({
        name: 'DetailDrawer',
        filePath: `${baseDir}/components/DetailDrawer.tsx`,
        purpose: 'Slide-out drawer providing full metadata inspection, audit events, and inline quick actions.',
        props: {
          isOpen: 'boolean',
          item: 'any',
          onClose: '() => void',
          onDelete: '(id: string) => void'
        },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('ANALYTICS_CHARTS')) {
      components.push({
        name: 'AnalyticsChartCard',
        filePath: `${baseDir}/components/AnalyticsChartCard.tsx`,
        purpose: 'Custom responsive SVG time-series and distribution charts with hover tooltips.',
        props: { title: 'string', data: 'any[]', metricType: 'string' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('SETTINGS_CONFIG')) {
      components.push({
        name: 'SettingsPanel',
        filePath: `${baseDir}/components/SettingsPanel.tsx`,
        purpose: 'Workspace configuration for user preferences, role permissions, and local storage management.',
        props: { onResetData: '() => void', onExport: '() => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('AUDIT_LOGS')) {
      components.push({
        name: 'AuditLogViewer',
        filePath: `${baseDir}/components/AuditLogViewer.tsx`,
        purpose: 'Chronological timeline of system events, user actions, and state mutations.',
        props: { logs: 'ActivityLogItem[]' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('EXPORT_IMPORT')) {
      components.push({
        name: 'ExportModal',
        filePath: `${baseDir}/components/ExportModal.tsx`,
        purpose: 'Modal for exporting and restoring workspace state as JSON data archives.',
        props: { isOpen: 'boolean', onClose: '() => void', onExport: '() => void', onImport: '(json: string) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('CANVAS_WORKSPACE')) {
      components.push({
        name: 'InteractiveCanvas',
        filePath: `${baseDir}/components/InteractiveCanvas.tsx`,
        purpose: 'High-performance HTML5 Canvas viewport for procedural graphics and animations.',
        props: { activeTool: 'string', isPlaying: 'boolean' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('AUDIO_SYNTHESIZER')) {
      components.push({
        name: 'AudioControls',
        filePath: `${baseDir}/components/AudioControls.tsx`,
        purpose: 'Audio synthesis controls for waveforms, ADSR parameters, and step sequencing.',
        props: { isPlaying: 'boolean', bpm: 'number', onBpmChange: '(bpm: number) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('MEDIA_TIMELINE')) {
      components.push({
        name: 'TimelineEditor',
        filePath: `${baseDir}/components/TimelineEditor.tsx`,
        purpose: 'Sequence track timeline with playhead scrubbing, keyframe markers, and zoom.',
        props: { currentTime: 'number', duration: 'number', onSeek: '(time: number) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('MEDIA_BROWSER')) {
      components.push({
        name: 'MediaBrowser',
        filePath: `${baseDir}/components/MediaBrowser.tsx`,
        purpose: 'Asset bin with categorized media cards, search filters, and import dropzone.',
        props: { assets: 'any[]', onSelectAsset: '(asset: any) => void', onImportAsset: '(asset: any) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('PREVIEW_VIEWPORT')) {
      components.push({
        name: 'PreviewViewport',
        filePath: `${baseDir}/components/PreviewViewport.tsx`,
        purpose: 'High-performance video/animation viewport with transport controls, aspect ratio picker, and timecode.',
        props: { isPlaying: 'boolean', currentTime: 'number', duration: 'number', onTogglePlay: '() => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('INSPECTOR_PANEL')) {
      components.push({
        name: 'InspectorPanel',
        filePath: `${baseDir}/components/InspectorPanel.tsx`,
        purpose: 'Properties inspector for modifying transforms, opacities, filters, and layer parameters.',
        props: { selectedItem: 'any', onUpdateProperty: '(key: string, value: any) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('LAYER_SYSTEM')) {
      components.push({
        name: 'LayerSystem',
        filePath: `${baseDir}/components/LayerSystem.tsx`,
        purpose: 'Visual layer stack manager with visibility toggles, lock states, blend modes, and reordering.',
        props: { layers: 'any[]', activeLayerId: 'string', onSelectLayer: '(id: string) => void', onToggleVisibility: '(id: string) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('EFFECTS_RACK')) {
      components.push({
        name: 'EffectsRack',
        filePath: `${baseDir}/components/EffectsRack.tsx`,
        purpose: 'Filter and post-processing rack with color grading sliders, blur, vignette, and presets.',
        props: { effects: 'any[]', onToggleEffect: '(id: string) => void', onUpdateParam: '(effectId: string, param: string, val: any) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('AUDIO_MIXER')) {
      components.push({
        name: 'AudioMixer',
        filePath: `${baseDir}/components/AudioMixer.tsx`,
        purpose: 'Multi-channel audio mixing console with volume faders, pan knobs, and mute/solo toggles.',
        props: { tracks: 'any[]', onVolumeChange: '(trackId: string, vol: number) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('RENDER_QUEUE')) {
      components.push({
        name: 'RenderQueue',
        filePath: `${baseDir}/components/RenderQueue.tsx`,
        purpose: 'Export and render job manager with progress bars, status indicators, and format selectors.',
        props: { jobs: 'any[]', onStartRender: '(format: string) => void', onCancelJob: '(id: string) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('GENERATION_QUEUE')) {
      components.push({
        name: 'GenerationQueue',
        filePath: `${baseDir}/components/GenerationQueue.tsx`,
        purpose: 'AI inference job dispatcher and monitor with honest capability disclosure.',
        props: { jobs: 'any[]', onDispatchJob: '(req: any) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    if (compositeModules.includes('NODE_GRAPH')) {
      components.push({
        name: 'NodeGraph',
        filePath: `${baseDir}/components/NodeGraph.tsx`,
        purpose: 'Interactive visual dataflow graph editor with connected operator nodes.',
        props: { graph: 'any', onSelectNode: '(id: string) => void', onAddNode: '(type: string) => void' },
        isRootOrPage: false,
        dependencies: ['lucide-react']
      });
    }

    // Generate Page Views
    for (const page of pages) {
      components.push({
        name: page.componentRef,
        filePath: `${baseDir}/views/${page.componentRef}.tsx`,
        purpose: page.description,
        props: {
          store: 'any',
          onAction: '(action: string, payload?: any) => void'
        },
        isRootOrPage: true,
        dependencies: ['react', 'lucide-react', 'motion/react']
      });
    }

    // Key UI Components (if any additional custom ones specified)
    for (const keyComp of spec.uiRequirements.keyComponents) {
      if (!components.some(c => c.name === keyComp)) {
        components.push({
          name: keyComp,
          filePath: `${baseDir}/components/${keyComp}.tsx`,
          purpose: `Specialized UI component: ${keyComp}`,
          props: {
            data: 'any',
            onChange: '(val: any) => void'
          },
          isRootOrPage: false,
          dependencies: ['lucide-react']
        });
      }
    }

    return components;
  }

  private static pascalCase(str: string): string {
    return str
      .replace(/[^a-zA-Z0-9]+/g, ' ')
      .split(' ')
      .filter(Boolean)
      .map(w => w.charAt(0).toUpperCase() + w.slice(1))
      .join('');
  }

  private static camelCase(str: string): string {
    const pc = this.pascalCase(str);
    return pc.charAt(0).toLowerCase() + pc.slice(1);
  }

  private static slugify(str: string): string {
    return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  }
}
