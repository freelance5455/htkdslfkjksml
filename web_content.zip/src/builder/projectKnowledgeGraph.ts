/**
 * GODEX P3.0 — Project Knowledge Graph & Deep Intelligence Engine
 * Constructs live, truthful graph representations of multi-file repositories.
 * Epistemically tracks confidence levels: KNOWN | INFERRED | LIKELY | UNKNOWN.
 */

export type KnowledgeConfidence = 'KNOWN' | 'INFERRED' | 'LIKELY' | 'UNKNOWN';

export type ProjectNodeType = 
  | 'FILE' 
  | 'COMPONENT' 
  | 'MODULE' 
  | 'SERVICE' 
  | 'HOOK' 
  | 'STORE' 
  | 'ROUTE' 
  | 'INTERFACE' 
  | 'TYPE' 
  | 'TEST' 
  | 'CONFIG' 
  | 'PACKAGE' 
  | 'ENV_VARIABLE';

export interface ProjectGraphNode {
  id: string;
  name: string;
  type: ProjectNodeType;
  filePath: string;
  confidence: KnowledgeConfidence;
  metadata: {
    exports?: string[];
    imports?: string[];
    dependencies?: string[];
    loc?: number;
    description?: string;
    isEntryPoint?: boolean;
    stateHandlers?: string[];
    routePath?: string;
    runtimeTarget?: 'BROWSER' | 'NODE' | 'UNIVERSAL';
  };
}

export interface ProjectGraphEdge {
  id: string;
  source: string;
  target: string;
  relation: 
    | 'IMPORTS' 
    | 'EXPORTS' 
    | 'CALLS' 
    | 'RENDERS' 
    | 'USES_STATE' 
    | 'DEPENDS_ON' 
    | 'TESTS' 
    | 'CONFIGURES';
  confidence: KnowledgeConfidence;
}

export interface ProjectKnowledgeGraph {
  nodes: Record<string, ProjectGraphNode>;
  edges: ProjectGraphEdge[];
  summary: {
    totalFiles: number;
    totalComponents: number;
    totalServices: number;
    totalRoutes: number;
    totalTests: number;
    entryPoints: string[];
    packageDependencies: string[];
    environmentRequirements: string[];
    framework: string;
  };
  indexedAt: number;
}

export class ProjectKnowledgeGraphBuilder {
  public static buildGraph(
    files: Record<string, string>,
    packageJsonContent?: string
  ): ProjectKnowledgeGraph {
    const nodes: Record<string, ProjectGraphNode> = {};
    const edges: ProjectGraphEdge[] = [];
    const entryPoints: string[] = [];
    const packageDependencies: string[] = [];
    const envRequirements: string[] = [];
    let framework = 'React (Vite)';

    // 1. Parse package.json if present
    if (packageJsonContent || files['package.json']) {
      try {
        const pkg = JSON.parse(packageJsonContent || files['package.json']);
        const allDeps = { ...pkg.dependencies, ...pkg.devDependencies };
        for (const [dep, ver] of Object.entries(allDeps)) {
          packageDependencies.push(dep);
          const pkgId = `pkg:${dep}`;
          nodes[pkgId] = {
            id: pkgId,
            name: dep,
            type: 'PACKAGE',
            filePath: 'package.json',
            confidence: 'KNOWN',
            metadata: { description: `Version: ${ver}` }
          };
        }
        if (pkg.dependencies?.['next']) framework = 'Next.js';
        else if (pkg.dependencies?.['vue']) framework = 'Vue';
        else if (pkg.dependencies?.['express']) framework = 'Express Fullstack';
      } catch {
        // Fallback gracefully
      }
    }

    // 2. Scan and index source files
    for (const [filePath, content] of Object.entries(files)) {
      const isTest = filePath.includes('.test.') || filePath.includes('.spec.') || filePath.startsWith('test/');
      const isConfig = filePath.endsWith('.json') || filePath.endsWith('.config.ts') || filePath.endsWith('.config.js');
      const isEntry = filePath === 'src/main.tsx' || filePath === 'src/index.tsx' || filePath === 'server.ts' || filePath === 'index.html';

      if (isEntry) entryPoints.push(filePath);

      // Create File Node
      const fileNodeId = `file:${filePath}`;
      nodes[fileNodeId] = {
        id: fileNodeId,
        name: filePath.split('/').pop() || filePath,
        type: isTest ? 'TEST' : isConfig ? 'CONFIG' : 'FILE',
        filePath,
        confidence: 'KNOWN',
        metadata: {
          loc: content.split('\n').length,
          isEntryPoint: isEntry,
          runtimeTarget: filePath.includes('server') ? 'NODE' : 'BROWSER'
        }
      };

      // Extract environment variables
      const envMatches = content.matchAll(/process\.env\.([A-Z0-9_]+)|import\.meta\.env\.([A-Z0-9_]+)/g);
      for (const m of envMatches) {
        const envVar = m[1] || m[2];
        if (envVar && !envRequirements.includes(envVar)) {
          envRequirements.push(envVar);
          const envId = `env:${envVar}`;
          if (!nodes[envId]) {
            nodes[envId] = {
              id: envId,
              name: envVar,
              type: 'ENV_VARIABLE',
              filePath,
              confidence: 'KNOWN',
              metadata: {}
            };
          }
          edges.push({
            id: `edge:${fileNodeId}->${envId}`,
            source: fileNodeId,
            target: envId,
            relation: 'DEPENDS_ON',
            confidence: 'KNOWN'
          });
        }
      }

      // Extract Component and Hook definitions
      if (filePath.endsWith('.tsx') || filePath.endsWith('.jsx')) {
        const compMatches = content.matchAll(/export (?:default )?(?:function|const) ([A-Z][a-zA-Z0-9_]*)/g);
        for (const cm of compMatches) {
          const compName = cm[1];
          const compId = `comp:${filePath}:${compName}`;
          nodes[compId] = {
            id: compId,
            name: compName,
            type: 'COMPONENT',
            filePath,
            confidence: 'KNOWN',
            metadata: {
              description: `React Component in ${filePath}`
            }
          };
          edges.push({
            id: `edge:${fileNodeId}->${compId}`,
            source: fileNodeId,
            target: compId,
            relation: 'EXPORTS',
            confidence: 'KNOWN'
          });
        }

        const hookMatches = content.matchAll(/export (?:const|function) (use[A-Z][a-zA-Z0-9_]*)/g);
        for (const hm of hookMatches) {
          const hookName = hm[1];
          const hookId = `hook:${filePath}:${hookName}`;
          nodes[hookId] = {
            id: hookId,
            name: hookName,
            type: 'HOOK',
            filePath,
            confidence: 'KNOWN',
            metadata: {}
          };
          edges.push({
            id: `edge:${fileNodeId}->${hookId}`,
            source: fileNodeId,
            target: hookId,
            relation: 'EXPORTS',
            confidence: 'KNOWN'
          });
        }
      }

      // Extract Services & Store hooks
      if (filePath.includes('service') || filePath.includes('Service') || filePath.includes('api')) {
        const srvMatches = content.matchAll(/export (?:const|class) ([a-zA-Z0-9_]+Service|[A-Z][a-zA-Z0-9_]*Api)/g);
        for (const sm of srvMatches) {
          const srvName = sm[1];
          const srvId = `srv:${filePath}:${srvName}`;
          nodes[srvId] = {
            id: srvId,
            name: srvName,
            type: 'SERVICE',
            filePath,
            confidence: 'KNOWN',
            metadata: {}
          };
          edges.push({
            id: `edge:${fileNodeId}->${srvId}`,
            source: fileNodeId,
            target: srvId,
            relation: 'EXPORTS',
            confidence: 'KNOWN'
          });
        }
      }

      // Extract Interfaces and Types
      const typeMatches = content.matchAll(/export (?:interface|type) ([A-Z][a-zA-Z0-9_]*)/g);
      for (const tm of typeMatches) {
        const typeName = tm[1];
        const typeId = `type:${filePath}:${typeName}`;
        nodes[typeId] = {
          id: typeId,
          name: typeName,
          type: 'INTERFACE',
          filePath,
          confidence: 'KNOWN',
          metadata: {}
        };
        edges.push({
          id: `edge:${fileNodeId}->${typeId}`,
          source: fileNodeId,
          target: typeId,
          relation: 'EXPORTS',
          confidence: 'KNOWN'
        });
      }

      // Extract Routes
      const routeMatches = content.matchAll(/path:\s*['"]([^'"]+)['"]|app\.(get|post|put|delete)\(['"]([^'"]+)['"]/g);
      for (const rm of routeMatches) {
        const routePath = rm[1] || rm[3];
        if (routePath) {
          const routeId = `route:${routePath}`;
          if (!nodes[routeId]) {
            nodes[routeId] = {
              id: routeId,
              name: routePath,
              type: 'ROUTE',
              filePath,
              confidence: 'INFERRED',
              metadata: { routePath }
            };
          }
          edges.push({
            id: `edge:${fileNodeId}->${routeId}`,
            source: fileNodeId,
            target: routeId,
            relation: 'RENDERS',
            confidence: 'INFERRED'
          });
        }
      }

      // Extract Imports and wire edges
      const importMatches = content.matchAll(/import\s+(?:(?:\{[^}]*\}|\*\s+as\s+[a-zA-Z0-9_]+|[a-zA-Z0-9_]+)\s+from\s+)?['"]([^'"]+)['"]/g);
      for (const im of importMatches) {
        const impSource = im[1];
        if (impSource.startsWith('.')) {
          // Relative file import
          const resolved = resolveRelativePath(filePath, impSource, Object.keys(files));
          if (resolved) {
            const targetFileNodeId = `file:${resolved}`;
            edges.push({
              id: `edge:${fileNodeId}->${targetFileNodeId}`,
              source: fileNodeId,
              target: targetFileNodeId,
              relation: 'IMPORTS',
              confidence: 'KNOWN'
            });
          } else {
            // Unresolved relative import -> UNKNOWN confidence
            const ghostId = `file:unresolved:${impSource}`;
            if (!nodes[ghostId]) {
              nodes[ghostId] = {
                id: ghostId,
                name: impSource,
                type: 'FILE',
                filePath: impSource,
                confidence: 'UNKNOWN',
                metadata: { description: 'Unresolved import reference' }
              };
            }
            edges.push({
              id: `edge:${fileNodeId}->${ghostId}`,
              source: fileNodeId,
              target: ghostId,
              relation: 'IMPORTS',
              confidence: 'UNKNOWN'
            });
          }
        } else {
          // Package import
          const pkgId = `pkg:${impSource}`;
          if (!nodes[pkgId]) {
            nodes[pkgId] = {
              id: pkgId,
              name: impSource,
              type: 'PACKAGE',
              filePath: 'package.json',
              confidence: 'LIKELY',
              metadata: { description: 'Inferred external package import' }
            };
          }
          edges.push({
            id: `edge:${fileNodeId}->${pkgId}`,
            source: fileNodeId,
            target: pkgId,
            relation: 'IMPORTS',
            confidence: 'KNOWN'
          });
        }
      }
    }

    const totalFiles = Object.keys(files).length;
    const totalComponents = Object.values(nodes).filter(n => n.type === 'COMPONENT').length;
    const totalServices = Object.values(nodes).filter(n => n.type === 'SERVICE').length;
    const totalRoutes = Object.values(nodes).filter(n => n.type === 'ROUTE').length;
    const totalTests = Object.values(nodes).filter(n => n.type === 'TEST').length;

    return {
      nodes,
      edges,
      summary: {
        totalFiles,
        totalComponents,
        totalServices,
        totalRoutes,
        totalTests,
        entryPoints,
        packageDependencies,
        environmentRequirements: envRequirements,
        framework
      },
      indexedAt: Date.now()
    };
  }

  public static querySymbols(
    graph: ProjectKnowledgeGraph,
    query: string,
    typeFilter?: ProjectNodeType
  ): ProjectGraphNode[] {
    const q = query.toLowerCase();
    return Object.values(graph.nodes).filter(node => {
      if (typeFilter && node.type !== typeFilter) return false;
      return node.name.toLowerCase().includes(q) || node.filePath.toLowerCase().includes(q);
    });
  }

  public static getDependencies(
    graph: ProjectKnowledgeGraph,
    nodeId: string
  ): ProjectGraphNode[] {
    const outgoing = graph.edges.filter(e => e.source === nodeId);
    return outgoing.map(e => graph.nodes[e.target]).filter(Boolean);
  }

  public static getDependents(
    graph: ProjectKnowledgeGraph,
    nodeId: string
  ): ProjectGraphNode[] {
    const incoming = graph.edges.filter(e => e.target === nodeId);
    return incoming.map(e => graph.nodes[e.source]).filter(Boolean);
  }
}

function resolveRelativePath(currentFile: string, importPath: string, allFiles: string[]): string | null {
  const currentParts = currentFile.split('/');
  currentParts.pop(); // Remove filename
  const importParts = importPath.split('/');

  for (const part of importParts) {
    if (part === '.') continue;
    if (part === '..') {
      currentParts.pop();
    } else {
      currentParts.push(part);
    }
  }

  const candidateBase = currentParts.join('/');
  const extensions = ['', '.ts', '.tsx', '.js', '.jsx', '/index.ts', '/index.tsx'];

  for (const ext of extensions) {
    const full = candidateBase + ext;
    if (allFiles.includes(full)) return full;
  }

  return null;
}
