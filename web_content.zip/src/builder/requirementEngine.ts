/**
 * GODEX P2.0 — Requirement Intelligence Engine
 * Transforms complex natural language software requests into structured, unambiguous RequirementSpecs.
 * Enforces Hard Constraints:
 * - Do not invent requirements silently.
 * - Ground requirements in prompt semantics and actual workspace capabilities.
 * - Identify external engine dependencies honestly.
 */

import { 
  RequirementSpec, 
  AppCategory, 
  FunctionalRequirement, 
  NonFunctionalRequirements, 
  UIRequirements, 
  DataEntity, 
  ExternalEngineRequirement, 
  RequirementRisk,
  ProductGoal,
  UserRoleSpec,
  CompositeFeatureType,
  WorkflowSpec,
  InteractionSpec,
  ValidationRuleSpec,
  SecurityRequirementSpec,
  StateRequirementSpec
} from './builderTypes';
import { CapabilityRegistry } from './capabilityRegistry';
import { DependencyIntelligenceEngine } from './dependencyIntelligence';

export class RequirementEngine {
  /**
   * Analyzes a user's natural language request and generates a complete, structured RequirementSpec.
   */
  public static analyze(userPrompt: string): RequirementSpec {
    const rawPrompt = userPrompt.trim();
    const appType = this.classifyAppCategory(rawPrompt);
    const appName = this.deriveAppName(rawPrompt, appType);
    const appSlug = this.slugify(appName);

    // 1. Functional Requirements
    const functionalRequirements = this.extractFunctionalRequirements(rawPrompt, appType);

    // 2. Non-Functional Requirements
    const nonFunctionalRequirements: NonFunctionalRequirements = {
      responsive: true,
      wcagCompliance: true,
      maxLoadTimeMs: 1500,
      offlineCapable: !rawPrompt.toLowerCase().includes('live server'),
      touchOptimized: true
    };

    // 3. UI Requirements
    const uiRequirements = this.extractUIRequirements(rawPrompt, appType);

    // 4. Data Requirements
    const dataRequirements = this.extractDataRequirements(rawPrompt, appType);

    // 5. Runtime Requirements
    const runtimeRequirements = this.extractRuntimeRequirements(rawPrompt, appType);

    // 6. External Engine Requirements
    const externalEngineRequirements = this.extractExternalEngineRequirements(rawPrompt, appType);

    // 7. Composite Features
    const compositeFeatures = this.extractCompositeFeatures(rawPrompt, appType);

    // 8. Product Goals & Roles
    const productGoals = this.extractProductGoals(rawPrompt, appType);
    const userRoles = this.extractUserRoles(rawPrompt, appType);

    // 9. Workflows & Interactions
    const workflows = this.extractWorkflows(rawPrompt, appType, compositeFeatures);
    const interactions = this.extractInteractions(rawPrompt, appType, compositeFeatures);

    // 10. Validation & Security & State
    const validationRules = this.extractValidationRules(rawPrompt, dataRequirements.entities);
    const securityRequirements = this.extractSecurityRequirements(rawPrompt, appType, userRoles);
    const stateRequirements = this.extractStateRequirements(rawPrompt, appType, dataRequirements.entities, compositeFeatures);

    // 11. Dependency Requirements
    const neededCaps = functionalRequirements.map(f => f.name).concat(uiRequirements.keyComponents);
    const dependencyRequirements = DependencyIntelligenceEngine.resolveRequirements(neededCaps);

    // 12. Verification Requirements
    const verificationRequirements = [
      'TypeScript Static Typecheck (tsc --noEmit) with 0 errors',
      'AST Syntax & Clean Import Integrity across all generated files',
      'React 19 Component Tree Mount & Error Boundary Verification',
      'Tailwind CSS Class JIT Extraction & Style Resolution',
      'Security Sanitizer: Zero hardcoded secrets, keys, or credentials',
      'Capability Boundary Compliance: Zero ungrounded engine claims',
      'State Flow & Modal Interaction Contract Integrity'
    ];

    // 13. Risk Analysis
    const risks = this.extractRisks(rawPrompt, appType, externalEngineRequirements);

    // 14. Summary
    const summary = this.generateSummary(appName, appType, functionalRequirements, externalEngineRequirements);

    return {
      applicationType: appType,
      appName,
      appSlug,
      summary,
      productGoals,
      userRoles,
      compositeFeatures,
      workflows,
      interactions,
      validationRules,
      securityRequirements,
      stateRequirements,
      functionalRequirements,
      nonFunctionalRequirements,
      uiRequirements,
      dataRequirements,
      runtimeRequirements,
      externalEngineRequirements,
      dependencyRequirements,
      verificationRequirements,
      risks,
      rawPrompt
    };
  }

  /**
   * Classifies the primary category of the application.
   */
  private static classifyAppCategory(prompt: string): AppCategory {
    const p = prompt.toLowerCase();

    if (p.includes('video') || p.includes('runway') || p.includes('sora') || p.includes('animation') || p.includes('image gen') || p.includes('creative studio')) {
      return 'AI_CREATIVE_STUDIO';
    }
    if (p.includes('game') || p.includes('arcade') || p.includes('multiplayer') || p.includes('chess') || p.includes('rpg') || p.includes('puzzle')) {
      return 'MULTIPLAYER_GAME';
    }
    if (p.includes('intelligence platform') || p.includes('analytics intelligence') || p.includes('analytics platform')) {
      return 'ANALYTICS_PLATFORM';
    }
    if (p.includes('inventory') || p.includes('inventory management') || p.includes('workspace tool')) {
      return 'WORKSPACE_TOOL';
    }
    if (p.includes('analytics') || p.includes('dashboard') || p.includes('metrics') || p.includes('saas') || p.includes('kpi') || p.includes('telemetry')) {
      return 'SAAS_DASHBOARD';
    }
    if (p.includes('store') || p.includes('shop') || p.includes('e-commerce') || p.includes('cart') || p.includes('checkout') || p.includes('product')) {
      return 'E_COMMERCE';
    }
    if (p.includes('editor') || p.includes('markdown') || p.includes('code') || p.includes('debugger') || p.includes('ide') || p.includes('compiler')) {
      return 'DEVELOPER_TOOL';
    }
    if (p.includes('synth') || p.includes('audio') || p.includes('sound') || p.includes('music') || p.includes('beat') || p.includes('sequencer')) {
      return 'AUDIO_SYNTHESIZER';
    }
    if (p.includes('task') || p.includes('todo') || p.includes('notes') || p.includes('kanban') || p.includes('calendar') || p.includes('planner')) {
      return 'PRODUCTIVITY_APP';
    }
    if (p.includes('portfolio') || p.includes('landing') || p.includes('showcase') || p.includes('agency')) {
      return 'PORTFOLIO_LANDING';
    }
    if (p.includes('photo') || p.includes('canvas') || p.includes('paint') || p.includes('drawing') || p.includes('filter')) {
      return 'MEDIA_EDITOR';
    }

    return 'CUSTOM_SPA';
  }

  /**
   * Derives a clean, professional application name.
   */
  private static deriveAppName(prompt: string, category: AppCategory): string {
    // Check if user specified a name in quotes
    const quoteMatch = prompt.match(/["']([^"']+)["']/);
    if (quoteMatch && quoteMatch[1] && quoteMatch[1].length < 30) {
      return quoteMatch[1];
    }

    // Category-based naming
    switch (category) {
      case 'SAAS_DASHBOARD':
        return 'Pulse Analytics Studio';
      case 'ANALYTICS_PLATFORM':
        return 'Vortex Intelligence Platform';
      case 'WORKSPACE_TOOL':
        return 'OmniWorkspace Manager';
      case 'AI_CREATIVE_STUDIO':
        return 'Godex Creative Studio';
      case 'MULTIPLAYER_GAME':
        return 'Nexus Arena';
      case 'E_COMMERCE':
        return 'Aura Commerce';
      case 'DEVELOPER_TOOL':
        return 'DevCraft Inspector';
      case 'AUDIO_SYNTHESIZER':
        return 'SonicWave Synthesizer';
      case 'PRODUCTIVITY_APP':
        return 'FlowState Organizer';
      case 'PORTFOLIO_LANDING':
        return 'Horizon Portfolio';
      case 'MEDIA_EDITOR':
        return 'PixelForge Studio';
      default:
        return 'Godex Universal App';
    }
  }

  private static slugify(name: string): string {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'app';
  }

  /**
   * Extracts functional requirements based on domain.
   */
  private static extractFunctionalRequirements(prompt: string, category: AppCategory): FunctionalRequirement[] {
    const p = prompt.toLowerCase();
    const reqs: FunctionalRequirement[] = [];

    switch (category) {
      case 'SAAS_DASHBOARD':
        reqs.push({
          id: 'fn-metrics-overview',
          name: 'Executive KPI Metrics Grid',
          description: 'Live interactive cards for MRR, active users, conversion rate, and churn with trend badges.',
          priority: 'CRITICAL',
          acceptanceCriteria: ['Displays 4 key metrics with delta indicators', 'Responds to date range filter'],
          capabilityCategory: 'DATA_VISUALIZATION'
        });
        reqs.push({
          id: 'fn-revenue-chart',
          name: 'Time-Series Revenue & Activity Visualizer',
          description: 'Custom responsive SVG area/bar chart showing historical performance across configurable time windows.',
          priority: 'HIGH',
          acceptanceCriteria: ['Renders smooth curve chart without external heavy charting libraries', 'Hover tooltip displays exact date/amount'],
          capabilityCategory: 'DATA_VISUALIZATION'
        });
        reqs.push({
          id: 'fn-data-table',
          name: 'Filterable Transactions & Customers Table',
          description: 'Searchable, paginated data grid with status filters, sorting, and CSV export.',
          priority: 'HIGH',
          acceptanceCriteria: ['Instant text search filter', 'Status dropdown filter (Active, Pending, Failed)', 'Sort by column header'],
          capabilityCategory: 'CORE_UI'
        });
        reqs.push({
          id: 'fn-realtime-feed',
          name: 'Live Telemetry Activity Feed',
          description: 'Stream of recent user actions, signups, and alerts with timestamped badges.',
          priority: 'MEDIUM',
          acceptanceCriteria: ['Simulates realistic incoming activity ticks', 'Color-coded event severity'],
          capabilityCategory: 'STATE_PERSISTENCE'
        });
        break;

      case 'AI_CREATIVE_STUDIO':
        reqs.push({
          id: 'fn-prompt-studio',
          name: 'Prompt Formulation & Generation Controls',
          description: 'Multimodal prompt composer with style selectors, aspect ratios, motion strength, and negative prompts.',
          priority: 'CRITICAL',
          acceptanceCriteria: ['Prompt input with character counter and preset prompt enhancers', 'Aspect ratio selector (16:9, 9:16, 1:1, 4:3)', 'Motion intensity slider (1-10)'],
          capabilityCategory: 'CREATIVE_AI'
        });
        reqs.push({
          id: 'fn-timeline-editor',
          name: 'Keyframe Motion & Video Track Timeline',
          description: 'Interactive sequence timeline with play/pause, scrub slider, clip trimming, and transition markers.',
          priority: 'HIGH',
          acceptanceCriteria: ['Interactive playback scrubber with current timestamp', 'Keyframe track visualization', 'Zoom in/out controls'],
          capabilityCategory: 'MEDIA_PROCESSING'
        });
        reqs.push({
          id: 'fn-canvas-preview',
          name: 'Hardware-Accelerated Canvas Previewer',
          description: 'HTML5 Canvas 2D/WebGL preview viewport with real-time procedural motion shaders and video filters.',
          priority: 'HIGH',
          acceptanceCriteria: ['Canvas renders fluid animated preview', 'Filter adjustments (Brightness, Contrast, Saturation, Vignette) applied live'],
          capabilityCategory: 'GRAPHICS_CANVAS'
        });
        reqs.push({
          id: 'fn-asset-gallery',
          name: 'Generated Asset Gallery & Export Center',
          description: 'Dossier of generated clips, images, and project files with download, duplicate, and metadata inspection.',
          priority: 'MEDIUM',
          acceptanceCriteria: ['Card grid with video/image thumbnail preview', 'Inspect prompt metadata modal', 'Export as ZIP or individual file'],
          capabilityCategory: 'CORE_UI'
        });
        break;

      case 'MULTIPLAYER_GAME':
        reqs.push({
          id: 'fn-game-canvas',
          name: 'Real-Time 60FPS Game Engine Canvas',
          description: 'Smooth game loop with collision detection, keyboard/touch input bindings, and particle effects.',
          priority: 'CRITICAL',
          acceptanceCriteria: ['60FPS requestAnimationFrame game loop', 'Responsive touch/keyboard controls (WASD, Arrow keys, Space)', 'Collision physics'],
          capabilityCategory: 'GRAPHICS_CANVAS'
        });
        reqs.push({
          id: 'fn-multiplayer-sync',
          name: 'Cross-Tab Local Networking & AI Opponents',
          description: 'Synchronizes game state across open browser tabs via BroadcastChannel with intelligent bot fallbacks.',
          priority: 'HIGH',
          acceptanceCriteria: ['Real-time sync between 2 open tabs', 'Autonomous AI bot player when solo'],
          capabilityCategory: 'REALTIME_NETWORKING'
        });
        reqs.push({
          id: 'fn-leaderboard-score',
          name: 'Score Counter & Persistent Leaderboard',
          description: 'Tracks current score, high score, combo multipliers, and stores leaderboard in LocalStorage.',
          priority: 'HIGH',
          acceptanceCriteria: ['Live score HUD with combo multiplier', 'Persistent top 10 leaderboard'],
          capabilityCategory: 'STATE_PERSISTENCE'
        });
        break;

      case 'AUDIO_SYNTHESIZER':
        reqs.push({
          id: 'fn-synth-engine',
          name: 'Web Audio Oscillator & Filter Engine',
          description: 'Polyphonic synthesizer with selectable wave forms (Sine, Square, Sawtooth, Triangle), ADSR envelope, and Low-Pass filter.',
          priority: 'CRITICAL',
          acceptanceCriteria: ['Low-latency AudioContext sound generation', 'ADSR sliders (Attack, Decay, Sustain, Release)', 'Cutoff and Resonance filter controls'],
          capabilityCategory: 'AUDIO_SYNTHESIS'
        });
        reqs.push({
          id: 'fn-piano-keyboard',
          name: 'Interactive Virtual Musical Keyboard',
          description: 'Responsive piano keys with mouse, touch, and computer keyboard bindings (QWERTY layout).',
          priority: 'HIGH',
          acceptanceCriteria: ['2-octave piano keyboard with white and black keys', 'Active note highlight feedback'],
          capabilityCategory: 'CORE_UI'
        });
        reqs.push({
          id: 'fn-step-sequencer',
          name: '16-Step Pattern Sequencer & Drum Machine',
          description: 'Grid sequencer for beats and melodies with BPM tempo slider, play/stop, and preset patterns.',
          priority: 'HIGH',
          acceptanceCriteria: ['16-step grid with active beat indicator', 'BPM slider (60-180 BPM)', 'Clear and randomize pattern buttons'],
          capabilityCategory: 'STATE_PERSISTENCE'
        });
        break;

      default:
        reqs.push({
          id: 'fn-core-workspace',
          name: 'Interactive Primary Workspace View',
          description: 'Central interface with full state management, responsive layout, and action controls.',
          priority: 'CRITICAL',
          acceptanceCriteria: ['Renders core application components', 'Maintains responsive layout across viewports'],
          capabilityCategory: 'CORE_UI'
        });
        reqs.push({
          id: 'fn-data-management',
          name: 'Data CRUD & State Persistence',
          description: 'Create, read, update, delete records with instant client-side persistence.',
          priority: 'HIGH',
          acceptanceCriteria: ['Add/edit/delete items with instant UI update', 'Persists to LocalStorage'],
          capabilityCategory: 'STATE_PERSISTENCE'
        });
        reqs.push({
          id: 'fn-search-filter',
          name: 'Instant Search & Categorization',
          description: 'Real-time filtering of items with category tags and sorting.',
          priority: 'MEDIUM',
          acceptanceCriteria: ['Live search filter', 'Category chip selection'],
          capabilityCategory: 'CORE_UI'
        });
        break;
    }

    return reqs;
  }

  /**
   * Extracts UI layout and structural requirements.
   */
  private static extractUIRequirements(prompt: string, category: AppCategory): UIRequirements {
    switch (category) {
      case 'SAAS_DASHBOARD':
        return {
          layoutArchetype: 'MULTI_PANEL_DASHBOARD',
          pages: ['Overview', 'Analytics', 'Customers', 'Billing', 'Settings'],
          colorPaletteHint: 'High-contrast neutral dark slate with emerald and cyan indicators',
          keyComponents: ['MetricsGrid', 'RevenueAreaChart', 'TransactionTable', 'ActivityFeed', 'DateRangePicker'],
          viewports: ['MOBILE', 'TABLET', 'DESKTOP', 'WIDE']
        };

      case 'AI_CREATIVE_STUDIO':
        return {
          layoutArchetype: 'CREATIVE_TIMELINE_STUDIO',
          pages: ['Studio', 'Timeline Editor', 'Assets', 'Render Queue', 'Settings'],
          colorPaletteHint: 'Deep obsidian backdrop with violet and amber accents',
          keyComponents: ['PromptComposer', 'VideoCanvasPreview', 'TimelineScrubber', 'AssetGrid', 'ParameterPanel'],
          viewports: ['MOBILE', 'TABLET', 'DESKTOP', 'WIDE']
        };

      case 'MULTIPLAYER_GAME':
        return {
          layoutArchetype: 'FULLSCREEN_GAME_ARENA',
          pages: ['Game Arena', 'Lobby & Matchmaking', 'Leaderboard', 'Controls Guide'],
          colorPaletteHint: 'Vibrant neon cyberpunk aesthetic with electric blue and crimson accents',
          keyComponents: ['GameEngineCanvas', 'ScoreHUD', 'CrossTabSyncIndicator', 'ControlsOverlay', 'LeaderboardModal'],
          viewports: ['MOBILE', 'TABLET', 'DESKTOP']
        };

      case 'AUDIO_SYNTHESIZER':
        return {
          layoutArchetype: 'HARDWARE_RACK_SYNTHESIZER',
          pages: ['Synthesizer', 'Step Sequencer', 'Effects Rack', 'Preset Library'],
          colorPaletteHint: 'Dark brushed aluminum with vintage amber LED indicators',
          keyComponents: ['OscillatorBank', 'FilterEnvelopeControls', 'VirtualPianoKeys', 'StepSequencerGrid', 'MasterVolumeMeter'],
          viewports: ['TABLET', 'DESKTOP', 'WIDE']
        };

      default:
        return {
          layoutArchetype: 'MODULAR_APPLICATION_LAYOUT',
          pages: ['Main View', 'Details', 'Settings'],
          colorPaletteHint: 'Clean high-contrast neutral with indigo accents',
          keyComponents: ['HeaderBar', 'MainContentGrid', 'SidebarFilters', 'ActionToolbar', 'StatusIndicator'],
          viewports: ['MOBILE', 'TABLET', 'DESKTOP', 'WIDE']
        };
    }
  }

  /**
   * Extracts data entities and persistence structures.
   */
  private static extractDataRequirements(prompt: string, category: AppCategory): {
    entities: DataEntity[];
    primaryPersistence: 'LOCAL_STORAGE' | 'MEMORY' | 'INDEXED_DB' | 'API';
  } {
    const entities: DataEntity[] = [];

    switch (category) {
      case 'SAAS_DASHBOARD':
        entities.push({
          name: 'MetricSummary',
          fields: {
            id: { type: 'string', required: true },
            label: { type: 'string', required: true },
            value: { type: 'string', required: true },
            changePercent: { type: 'number', required: true },
            isPositive: { type: 'boolean', required: true },
            period: { type: 'string', required: true }
          },
          persistence: 'LOCAL_STORAGE',
          initialSeedCount: 4
        });
        entities.push({
          name: 'TransactionRecord',
          fields: {
            id: { type: 'string', required: true },
            customerName: { type: 'string', required: true },
            amount: { type: 'number', required: true },
            currency: { type: 'string', required: true },
            status: { type: 'string', required: true },
            timestamp: { type: 'number', required: true }
          },
          persistence: 'LOCAL_STORAGE',
          initialSeedCount: 15
        });
        break;

      case 'AI_CREATIVE_STUDIO':
      case 'VIDEO_EDITOR':
      case 'MEDIA_EDITOR':
        entities.push({
          name: 'CreativeProject',
          fields: {
            id: { type: 'string', required: true },
            title: { type: 'string', required: true },
            prompt: { type: 'string', required: true },
            aspectRatio: { type: 'string', required: true },
            durationSeconds: { type: 'number', required: true },
            motionScore: { type: 'number', required: true },
            status: { type: 'string', required: true },
            createdAt: { type: 'number', required: true }
          },
          persistence: 'LOCAL_STORAGE',
          initialSeedCount: 4
        });
        entities.push({
          name: 'MediaAsset',
          fields: {
            id: { type: 'string', required: true },
            name: { type: 'string', required: true },
            type: { type: 'string', required: true },
            uri: { type: 'string', required: true },
            sizeBytes: { type: 'number', required: true },
            durationSeconds: { type: 'number', required: false },
            mimeType: { type: 'string', required: true },
            createdAt: { type: 'number', required: true }
          },
          persistence: 'LOCAL_STORAGE',
          initialSeedCount: 6
        });
        entities.push({
          name: 'RenderJob',
          fields: {
            id: { type: 'string', required: true },
            projectId: { type: 'string', required: true },
            title: { type: 'string', required: true },
            format: { type: 'string', required: true },
            resolution: { type: 'string', required: true },
            fps: { type: 'number', required: true },
            status: { type: 'string', required: true },
            progress: { type: 'number', required: true }
          },
          persistence: 'LOCAL_STORAGE',
          initialSeedCount: 3
        });
        break;

      case 'MULTIPLAYER_GAME':
        entities.push({
          name: 'LeaderboardEntry',
          fields: {
            id: { type: 'string', required: true },
            playerName: { type: 'string', required: true },
            score: { type: 'number', required: true },
            wave: { type: 'number', required: true },
            timestamp: { type: 'number', required: true }
          },
          persistence: 'LOCAL_STORAGE',
          initialSeedCount: 10
        });
        break;

      default:
        entities.push({
          name: 'AppItem',
          fields: {
            id: { type: 'string', required: true },
            title: { type: 'string', required: true },
            category: { type: 'string', required: true },
            status: { type: 'string', required: true },
            updatedAt: { type: 'number', required: true }
          },
          persistence: 'LOCAL_STORAGE',
          initialSeedCount: 6
        });
        break;
    }

    return {
      entities,
      primaryPersistence: 'LOCAL_STORAGE'
    };
  }

  /**
   * Identifies browser runtime requirements.
   */
  private static extractRuntimeRequirements(prompt: string, category: AppCategory): {
    browserApis: string[];
    webWorkers: boolean;
    canvasRequired: boolean;
    audioRequired: boolean;
    webGlRequired: boolean;
  } {
    const p = prompt.toLowerCase();
    const isGame = category === 'MULTIPLAYER_GAME';
    const isCreative = category === 'AI_CREATIVE_STUDIO';
    const isAudio = category === 'AUDIO_SYNTHESIZER' || p.includes('audio') || p.includes('synth') || p.includes('sound') || p.includes('music');
    const isMedia = category === 'MEDIA_EDITOR' || p.includes('canvas') || p.includes('draw') || p.includes('paint');

    const apis = ['Window.localStorage', 'Window.requestAnimationFrame'];
    if (isGame || isCreative || isMedia || p.includes('canvas')) apis.push('HTMLCanvasElement.getContext("2d")');
    if (isAudio) apis.push('Window.AudioContext');
    if (isGame) apis.push('Window.BroadcastChannel');

    return {
      browserApis: apis,
      webWorkers: false,
      canvasRequired: isGame || isCreative || isMedia || p.includes('canvas'),
      audioRequired: isAudio,
      webGlRequired: isCreative || isGame
    };
  }

  /**
   * Detects external engine requirements and evaluates availability honestly.
   */
  private static extractExternalEngineRequirements(prompt: string, category: AppCategory): ExternalEngineRequirement[] {
    const p = prompt.toLowerCase();
    const reqs: ExternalEngineRequirement[] = [];

    if (p.includes('video') || p.includes('runway') || p.includes('sora') || category === 'AI_CREATIVE_STUDIO') {
      reqs.push({
        capabilityId: 'cap-text-to-video-diffusion',
        name: 'Generative Video Diffusion Tensor Model',
        status: 'REQUIRES_ENGINE',
        requiredEngineName: 'Cloud Video Diffusion GPU Cluster (Veo / Runway API)',
        localFallbackPossible: true,
        fallbackStrategy: 'Procedural HTML5 Canvas keyframe motion animator & WebGL shader simulator with motion presets.'
      });
    }

    if (p.includes('image') && (p.includes('midjourney') || p.includes('diffusion') || p.includes('sdxl'))) {
      reqs.push({
        capabilityId: 'cap-text-to-image-diffusion',
        name: 'Text-to-Image Diffusion Engine',
        status: 'REQUIRES_ENGINE',
        requiredEngineName: 'Cloud Imagen / Stable Diffusion XL GPU Cluster',
        localFallbackPossible: true,
        fallbackStrategy: 'Procedural SVG/Canvas compositional generator with high-resolution vector assets.'
      });
    }

    if (category === 'MULTIPLAYER_GAME' && p.includes('dedicated server')) {
      reqs.push({
        capabilityId: 'cap-dedicated-game-server',
        name: 'Authoritative Multiplayer Dedicated Server',
        status: 'REQUIRES_ENGINE',
        requiredEngineName: 'Dedicated WebSocket/UDP Server Backend',
        localFallbackPossible: true,
        fallbackStrategy: 'Local Cross-Tab BroadcastChannel networking + Autonomous Bot AI player.'
      });
    }

    return reqs;
  }

  /**
   * Identifies project risks and concrete mitigations.
   */
  private static extractRisks(
    prompt: string, 
    category: AppCategory, 
    externalEngines: ExternalEngineRequirement[]
  ): RequirementRisk[] {
    const risks: RequirementRisk[] = [];

    // Missing external engine risk
    const requiresEngine = externalEngines.filter(e => e.status === 'REQUIRES_ENGINE');
    if (requiresEngine.length > 0) {
      risks.push({
        category: 'MISSING_ENGINE',
        description: `External GPU diffusion cluster (${requiresEngine.map(e => e.requiredEngineName).join(', ')}) is not locally present.`,
        severity: 'MEDIUM',
        mitigation: 'Implement clean typed API interface boundary and active local procedural simulation engine with honest capability disclosure.'
      });
    }

    // Canvas performance risk
    if (category === 'MULTIPLAYER_GAME' || category === 'AI_CREATIVE_STUDIO') {
      risks.push({
        category: 'PERFORMANCE',
        description: 'High frequency rendering loops may drop frames on lower-end devices.',
        severity: 'LOW',
        mitigation: 'Use requestAnimationFrame delta timing, offscreen canvas double buffering, and debounced resize observers.'
      });
    }

    // Audio context permissions
    if (category === 'AUDIO_SYNTHESIZER') {
      risks.push({
        category: 'BROWSER_SUPPORT',
        description: 'Modern browsers block AudioContext instantiation until first user gesture.',
        severity: 'LOW',
        mitigation: 'Guard AudioContext initialization behind explicit user interaction button (e.g. "Start Synthesizer" or first key press).'
      });
    }

    return risks;
  }

  /**
   * Extracts composite feature modules based on prompt and category.
   */
  private static extractCompositeFeatures(prompt: string, category: AppCategory): CompositeFeatureType[] {
    const p = prompt.toLowerCase();
    const features = new Set<CompositeFeatureType>();

    // Baseline essentials
    features.add('METRICS_DASHBOARD');
    features.add('CRUD_DATA_TABLE');
    features.add('ADVANCED_FILTERS');
    features.add('MODAL_WORKFLOWS');
    features.add('SETTINGS_CONFIG');
    features.add('AUDIT_LOGS');
    features.add('DETAIL_DRAWER');

    // Authentication / RBAC
    if (p.includes('auth') || p.includes('role') || p.includes('login') || p.includes('user') || p.includes('admin') || p.includes('permission') || category === 'SAAS_DASHBOARD' || category === 'E_COMMERCE') {
      features.add('AUTHENTICATION_UI');
    }

    // Analytics / Charts
    if (p.includes('chart') || p.includes('graph') || p.includes('visual') || p.includes('metric') || p.includes('analytics') || p.includes('kpi') || category === 'SAAS_DASHBOARD') {
      features.add('ANALYTICS_CHARTS');
    }

    // Export / Import
    if (p.includes('export') || p.includes('import') || p.includes('download') || p.includes('csv') || p.includes('json') || p.includes('backup') || category === 'SAAS_DASHBOARD' || category === 'DEVELOPER_TOOL') {
      features.add('EXPORT_IMPORT');
    }

    // Canvas Workspace
    if (p.includes('canvas') || p.includes('draw') || p.includes('paint') || p.includes('shader') || p.includes('video') || p.includes('game') || category === 'AI_CREATIVE_STUDIO' || category === 'MULTIPLAYER_GAME' || category === 'MEDIA_EDITOR') {
      features.add('CANVAS_WORKSPACE');
    }

    // Audio Synthesizer
    if (p.includes('audio') || p.includes('sound') || p.includes('synth') || p.includes('music') || p.includes('beat') || category === 'AUDIO_SYNTHESIZER') {
      features.add('AUDIO_SYNTHESIZER');
    }

    // Media Timeline
    if (p.includes('timeline') || p.includes('track') || p.includes('video') || p.includes('clip') || p.includes('sequence') || category === 'AI_CREATIVE_STUDIO' || category === 'VIDEO_EDITOR') {
      features.add('MEDIA_TIMELINE');
    }

    // Media Browser / Asset Bin
    if (p.includes('asset') || p.includes('media bin') || p.includes('browser') || p.includes('library') || p.includes('import') || category === 'AI_CREATIVE_STUDIO' || category === 'VIDEO_EDITOR') {
      features.add('MEDIA_BROWSER');
    }

    // Preview Viewport
    if (p.includes('preview') || p.includes('player') || p.includes('viewport') || p.includes('aspect') || category === 'AI_CREATIVE_STUDIO' || category === 'VIDEO_EDITOR' || category === 'IMAGE_EDITOR') {
      features.add('PREVIEW_VIEWPORT');
    }

    // Inspector Panel
    if (p.includes('inspector') || p.includes('properties') || p.includes('transform') || p.includes('parameter') || category === 'AI_CREATIVE_STUDIO' || category === 'VIDEO_EDITOR' || category === 'IMAGE_EDITOR') {
      features.add('INSPECTOR_PANEL');
    }

    // Layer System
    if (p.includes('layer') || p.includes('blend') || p.includes('composite') || p.includes('stack') || category === 'IMAGE_EDITOR' || category === 'AI_CREATIVE_STUDIO') {
      features.add('LAYER_SYSTEM');
    }

    // Effects Rack
    if (p.includes('effect') || p.includes('filter') || p.includes('grade') || p.includes('lut') || p.includes('vignette') || category === 'AI_CREATIVE_STUDIO' || category === 'VIDEO_EDITOR' || category === 'IMAGE_EDITOR') {
      features.add('EFFECTS_RACK');
    }

    // Audio Mixer
    if (p.includes('mixer') || p.includes('volume') || p.includes('pan') || p.includes('fader') || category === 'AUDIO_WORKSTATION' || category === 'AUDIO_SYNTHESIZER') {
      features.add('AUDIO_MIXER');
    }

    // Captions & Subtitles
    if (p.includes('caption') || p.includes('subtitle') || p.includes('transcript') || p.includes('teleprompter')) {
      features.add('CAPTION_SUBTITLES');
    }

    // Render Queue / Export Pipeline
    if (p.includes('render') || p.includes('queue') || p.includes('encode') || p.includes('export') || category === 'AI_CREATIVE_STUDIO' || category === 'VIDEO_EDITOR') {
      features.add('RENDER_QUEUE');
    }

    // AI Generation Queue
    if (p.includes('diffusion') || p.includes('generation') || p.includes('ai') || p.includes('model') || p.includes('prompt') || category === 'AI_CREATIVE_STUDIO') {
      features.add('GENERATION_QUEUE');
    }

    // Node Graph Editor
    if (p.includes('node') || p.includes('graph') || p.includes('dataflow') || p.includes('flow chart') || category === 'NODE_CREATIVE_APP') {
      features.add('NODE_GRAPH');
    }

    // Keyframe Animator
    if (p.includes('keyframe') || p.includes('animate') || p.includes('easing') || p.includes('curve') || category === 'ANIMATION_EDITOR') {
      features.add('KEYFRAME_ANIMATOR');
    }

    // Storyboard Canvas
    if (p.includes('storyboard') || p.includes('shot') || p.includes('scene') || category === 'STORYBOARD_APP') {
      features.add('STORYBOARD_CANVAS');
    }

    // Undo / Redo History
    if (p.includes('undo') || p.includes('redo') || p.includes('history') || category === 'AI_CREATIVE_STUDIO' || category === 'VIDEO_EDITOR' || category === 'IMAGE_EDITOR') {
      features.add('HISTORY_UNDO_REDO');
    }

    return Array.from(features);
  }

  /**
   * Extracts concrete product goals.
   */
  private static extractProductGoals(prompt: string, category: AppCategory): ProductGoal[] {
    const goals: ProductGoal[] = [
      {
        id: 'goal-1',
        goal: 'Deliver a high-responsiveness interactive workspace',
        targetOutcome: 'Instant state updates and smooth visual transitions with zero layout shift',
        priority: 'HIGH'
      },
      {
        id: 'goal-2',
        goal: 'Provide comprehensive data manipulation and filtering',
        targetOutcome: 'Users can search, filter by multiple criteria, and perform full CRUD operations',
        priority: 'HIGH'
      },
      {
        id: 'goal-3',
        goal: 'Ensure epistemic integrity and capability honesty',
        targetOutcome: 'All UI controls and indicators faithfully represent actual runtime capabilities',
        priority: 'MEDIUM'
      }
    ];

    if (category === 'SAAS_DASHBOARD') {
      goals.push({
        id: 'goal-saas-1',
        goal: 'Enable executive-level operational visibility',
        targetOutcome: 'Aggregated KPI metrics and trend analysis across all key business dimensions',
        priority: 'HIGH'
      });
    } else if (category === 'AI_CREATIVE_STUDIO') {
      goals.push({
        id: 'goal-creative-1',
        goal: 'Provide intuitive prompt formulation and procedural preview generation',
        targetOutcome: 'Users can construct rich generation prompts and preview procedural animations locally',
        priority: 'HIGH'
      });
    } else if (category === 'MULTIPLAYER_GAME') {
      goals.push({
        id: 'goal-game-1',
        goal: 'Deliver 60 FPS real-time interactive game loop with responsive controls',
        targetOutcome: 'Smooth canvas rendering with collision mechanics and persistent high score tracking',
        priority: 'HIGH'
      });
    }

    return goals;
  }

  /**
   * Extracts user roles and role-based permissions.
   */
  private static extractUserRoles(prompt: string, category: AppCategory): UserRoleSpec[] {
    return [
      {
        role: 'Admin',
        description: 'Full workspace administration, data modification, and configuration control',
        permissions: ['read', 'create', 'update', 'delete', 'export', 'admin_config'],
        isDefault: true
      },
      {
        role: 'Editor',
        description: 'Operational user with data creation and update privileges',
        permissions: ['read', 'create', 'update', 'export'],
        isDefault: false
      },
      {
        role: 'Viewer',
        description: 'Read-only analyst with filtering and inspection privileges',
        permissions: ['read', 'export'],
        isDefault: false
      }
    ];
  }

  /**
   * Extracts multi-step workflows.
   */
  private static extractWorkflows(prompt: string, category: AppCategory, features: CompositeFeatureType[]): WorkflowSpec[] {
    const workflows: WorkflowSpec[] = [
      {
        id: 'wf-create-record',
        name: 'Record Creation & Validation Flow',
        description: 'Multi-step workflow for drafting, validating, and committing new data records.',
        steps: ['Open Form Modal', 'Enter Required Fields', 'Run Schema Validation', 'Persist to Store', 'Trigger Audit Log & Notification'],
        validationRules: ['Primary name/title must not be empty', 'Numeric attributes must be non-negative'],
        triggerAction: 'CLICK_NEW_RECORD_BUTTON'
      },
      {
        id: 'wf-filter-inspect',
        name: 'Search, Filter & Inspection Flow',
        description: 'Workflow for querying datasets and inspecting record details in drawer.',
        steps: ['Enter Query in Search Bar', 'Apply Category Filter', 'Select Row in Data Grid', 'Render Inspection Drawer'],
        validationRules: ['Query string sanitized of unsafe characters'],
        triggerAction: 'INPUT_SEARCH_QUERY'
      }
    ];

    if (features.includes('EXPORT_IMPORT')) {
      workflows.push({
        id: 'wf-export-data',
        name: 'Data Export & Backup Workflow',
        description: 'Packages workspace state into structured JSON/CSV for client download.',
        steps: ['Collect Store Records', 'Serialize to Formatted JSON', 'Generate Data URI Blob', 'Trigger Browser Download'],
        validationRules: ['State must contain at least 1 record to export'],
        triggerAction: 'CLICK_EXPORT_BUTTON'
      });
    }

    return workflows;
  }

  /**
   * Extracts user interaction contracts.
   */
  private static extractInteractions(prompt: string, category: AppCategory, features: CompositeFeatureType[]): InteractionSpec[] {
    return [
      {
        id: 'int-search',
        trigger: 'Search Input Change',
        action: 'Debounced filter application against in-memory dataset',
        outcome: 'Table and metrics instantly update to matching subset',
        feedbackType: 'INLINE_STATUS'
      },
      {
        id: 'int-create',
        trigger: 'Submit Create Modal',
        action: 'Validate payload and append to state store',
        outcome: 'New record visible in table with success toast notification',
        feedbackType: 'TOAST'
      },
      {
        id: 'int-select-row',
        trigger: 'Table Row Click',
        action: 'Set selectedItemId in store',
        outcome: 'Slide out DetailDrawer with full metadata and actions',
        feedbackType: 'MODAL'
      },
      {
        id: 'int-switch-role',
        trigger: 'User Role Dropdown Select',
        action: 'Update activeRole and recompute permission matrix',
        outcome: 'UI adapts available action buttons according to role permissions',
        feedbackType: 'TOAST'
      }
    ];
  }

  /**
   * Extracts validation rules for data entities.
   */
  private static extractValidationRules(prompt: string, entities: DataEntity[]): ValidationRuleSpec[] {
    const rules: ValidationRuleSpec[] = [];

    for (const entity of entities) {
      for (const [fieldName, field] of Object.entries(entity.fields)) {
        if (field.required) {
          rules.push({
            field: `${entity.name}.${fieldName}`,
            rule: field.type === 'number' ? 'value !== undefined && !isNaN(value)' : 'typeof value === "string" && value.trim().length > 0',
            errorMessage: `${fieldName} is required and must be valid`,
            required: true
          });
        }
      }
    }

    return rules;
  }

  /**
   * Extracts security requirements.
   */
  private static extractSecurityRequirements(prompt: string, category: AppCategory, roles: UserRoleSpec[]): SecurityRequirementSpec {
    return {
      authRequired: true,
      sanitizedInputs: ['searchQuery', 'name', 'title', 'description', 'prompt', 'category'],
      sensitiveDataMasking: true,
      clientRoleGuards: true,
      notes: 'All form inputs are trimmed and sanitized against XSS. Role-based client guards restrict mutation actions.'
    };
  }

  /**
   * Extracts comprehensive state management requirements.
   */
  private static extractStateRequirements(
    prompt: string,
    category: AppCategory,
    entities: DataEntity[],
    features: CompositeFeatureType[]
  ): StateRequirementSpec {
    const localStates = ['isModalOpen', 'isDrawerOpen', 'activeTab', 'draftFormState', 'toastMessage'];
    const sharedStates = ['activeRole', 'searchQuery', 'activeFilter', 'selectedItemId', 'records', 'metrics', 'auditLogs'];
    const persistentKeys = ['savedRecords', 'userPreferences', 'activeRole', 'auditHistory'];
    const computedProperties = ['filteredRecords', 'totalRecordCount', 'activeMetricTotals', 'canCreateRecord', 'canDeleteRecord'];

    if (features.includes('CANVAS_WORKSPACE')) {
      sharedStates.push('canvasState', 'playbackPlaying', 'selectedTool');
      computedProperties.push('canvasFrameCount');
    }

    if (features.includes('AUDIO_SYNTHESIZER')) {
      sharedStates.push('audioActive', 'currentBpm', 'selectedWaveform', 'activeStep');
    }

    return {
      localStates,
      sharedStates,
      persistentKeys,
      computedProperties
    };
  }

  private static generateSummary(
    appName: string, 
    category: AppCategory, 
    functional: FunctionalRequirement[], 
    external: ExternalEngineRequirement[]
  ): string {
    const fnList = functional.map(f => f.name).join(', ');
    const extNote = external.length > 0 
      ? ` Note: ${external.length} capability requiring external engines has been isolated with local procedural fallback.`
      : '';
    return `Engineered ${appName} as a production-grade ${category.replace(/_/g, ' ')} application featuring ${fnList}.${extNote}`;
  }
}
