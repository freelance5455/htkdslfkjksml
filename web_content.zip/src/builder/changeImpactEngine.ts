/**
 * GODEX P3.0 — Change Impact Engine
 * Analyzes exact ripple effects and blast radii before code modifications.
 * Guarantees zero unintended side effects and protects unrelated modules.
 */

import { ProjectKnowledgeGraph, ProjectKnowledgeGraphBuilder } from './projectKnowledgeGraph';

export type ChangeRiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface FileChangeTarget {
  filePath: string;
  operation: 'CREATE' | 'MODIFY' | 'DELETE' | 'UPDATE';
  description?: string;
}

export interface AffectedModule {
  filePath: string;
  reason: string;
  risk: ChangeRiskLevel;
  relationship: 'DIRECT_IMPORT' | 'INDIRECT_IMPORT' | 'TYPE_CONSUMER' | 'STATE_DEPENDENCY' | 'TEST_RUNNER';
}

export interface ChangeImpactReport {
  targetFiles: string[];
  affectedFiles: AffectedModule[];
  dependentFiles: string[];
  importedSymbols: string[];
  publicInterfaces: string[];
  stateDependencies: string[];
  runtimeDependencies: string[];
  testsLikelyAffected: string[];
  buildImplications: {
    requiresRebuild: boolean;
    riskLevel: ChangeRiskLevel;
    potentialTypecheckImpact: boolean;
    warnings: string[];
  };
  unrelatedFilesProtected: string[];
  overallRisk: ChangeRiskLevel;
  timestamp: number;
}

export class ChangeImpactEngine {
  public static analyzeChangeImpact(
    targets: FileChangeTarget[],
    workspaceFiles: Record<string, string>,
    knowledgeGraph?: ProjectKnowledgeGraph
  ): ChangeImpactReport {
    const graph = knowledgeGraph || ProjectKnowledgeGraphBuilder.buildGraph(workspaceFiles);
    const targetFilePaths = targets.map(t => t.filePath);
    
    const affectedFilesMap = new Map<string, AffectedModule>();
    const dependentFilesSet = new Set<string>();
    const importedSymbolsSet = new Set<string>();
    const publicInterfacesSet = new Set<string>();
    const stateDepsSet = new Set<string>();
    const runtimeDepsSet = new Set<string>();
    const testsAffectedSet = new Set<string>();
    const warnings: string[] = [];

    for (const target of targets) {
      const fileNodeId = `file:${target.filePath}`;
      const fileContent = workspaceFiles[target.filePath] || '';

      // Extract public interfaces and exported symbols from target
      const exportedMatches = fileContent.matchAll(/export (?:interface|type|class|const|function) ([a-zA-Z0-9_]+)/g);
      for (const m of exportedMatches) {
        publicInterfacesSet.add(m[1]);
      }

      // Extract imported symbols
      const importMatches = fileContent.matchAll(/import \{([^}]+)\} from/g);
      for (const m of importMatches) {
        m[1].split(',').forEach(s => importedSymbolsSet.add(s.trim()));
      }

      // Check state management dependencies
      if (fileContent.includes('useState') || fileContent.includes('useReducer') || fileContent.includes('createContext') || fileContent.includes('zustand') || fileContent.includes('redux')) {
        stateDepsSet.add(target.filePath);
      }

      // Check runtime dependencies
      if (fileContent.includes('fetch(') || fileContent.includes('axios') || fileContent.includes('process.env') || fileContent.includes('window.') || fileContent.includes('document.')) {
        runtimeDepsSet.add(target.filePath);
      }

      // Find Direct and Indirect Dependents from Knowledge Graph
      const directDependents = ProjectKnowledgeGraphBuilder.getDependents(graph, fileNodeId);
      for (const dep of directDependents) {
        if (!targetFilePaths.includes(dep.filePath)) {
          dependentFilesSet.add(dep.filePath);
          const isTest = dep.type === 'TEST' || dep.filePath.includes('.test.') || dep.filePath.includes('.spec.');
          if (isTest) {
            testsAffectedSet.add(dep.filePath);
          }
          
          affectedFilesMap.set(dep.filePath, {
            filePath: dep.filePath,
            reason: `Directly imports ${target.filePath}`,
            risk: dep.filePath === 'src/App.tsx' || dep.filePath === 'server.ts' ? 'HIGH' : 'MEDIUM',
            relationship: isTest ? 'TEST_RUNNER' : 'DIRECT_IMPORT'
          });

          // Second-degree indirect dependents
          const indirectDependents = ProjectKnowledgeGraphBuilder.getDependents(graph, dep.id);
          for (const ind of indirectDependents) {
            if (!targetFilePaths.includes(ind.filePath) && !affectedFilesMap.has(ind.filePath)) {
              dependentFilesSet.add(ind.filePath);
              affectedFilesMap.set(ind.filePath, {
                filePath: ind.filePath,
                reason: `Indirectly depends via ${dep.filePath}`,
                risk: 'LOW',
                relationship: 'INDIRECT_IMPORT'
              });
            }
          }
        }
      }

      // Also check all test files if they reference the component by name
      const targetBase = target.filePath.split('/').pop()?.replace(/\.(tsx?|jsx?)$/, '') || '';
      for (const [fPath, fContent] of Object.entries(workspaceFiles)) {
        if ((fPath.includes('.test.') || fPath.includes('.spec.') || fPath.startsWith('test/')) && !targetFilePaths.includes(fPath)) {
          if (fContent.includes(targetBase)) {
            testsAffectedSet.add(fPath);
            if (!affectedFilesMap.has(fPath)) {
              affectedFilesMap.set(fPath, {
                filePath: fPath,
                reason: `Test references component/module ${targetBase}`,
                risk: 'MEDIUM',
                relationship: 'TEST_RUNNER'
              });
            }
          }
        }
      }
    }

    // Determine protected unrelated files
    const allWorkspacePaths = Object.keys(workspaceFiles);
    const affectedOrTargetPaths = new Set([...targetFilePaths, ...affectedFilesMap.keys()]);
    const unrelatedFilesProtected = allWorkspacePaths.filter(p => !affectedOrTargetPaths.has(p));

    // Determine overall risk
    let overallRisk: ChangeRiskLevel = 'LOW';
    if (targetFilePaths.some(p => p === 'package.json' || p === 'server.ts' || p === 'vite.config.ts')) {
      overallRisk = 'CRITICAL';
      warnings.push('Modifying core configuration / server entry point carries system-wide impact.');
    } else if (affectedFilesMap.size > 5 || targetFilePaths.includes('src/App.tsx')) {
      overallRisk = 'HIGH';
      warnings.push('High blast radius: changes propagate across multiple active modules.');
    } else if (affectedFilesMap.size > 0 || publicInterfacesSet.size > 0) {
      overallRisk = 'MEDIUM';
    }

    return {
      targetFiles: targetFilePaths,
      affectedFiles: Array.from(affectedFilesMap.values()),
      dependentFiles: Array.from(dependentFilesSet),
      importedSymbols: Array.from(importedSymbolsSet),
      publicInterfaces: Array.from(publicInterfacesSet),
      stateDependencies: Array.from(stateDepsSet),
      runtimeDependencies: Array.from(runtimeDepsSet),
      testsLikelyAffected: Array.from(testsAffectedSet),
      buildImplications: {
        requiresRebuild: true,
        riskLevel: overallRisk,
        potentialTypecheckImpact: publicInterfacesSet.size > 0 || targetFilePaths.some(p => p.endsWith('.ts') || p.endsWith('.tsx')),
        warnings
      },
      unrelatedFilesProtected,
      overallRisk,
      timestamp: Date.now()
    };
  }
}
