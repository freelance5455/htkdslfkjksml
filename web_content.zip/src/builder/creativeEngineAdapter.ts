/**
 * GODEX P2.0 — Creative Engine Adapter
 * Handles AI and creative application workflows:
 * Text->Image, Image->Image, Text->Video, Image->Video, Audio Synthesis, Multimodal pipelines.
 * 
 * Enforces the Truth-First Invariant:
 * - If external high-compute diffusion GPUs are not present in workspace, reports REQUIRES_ENGINE.
 * - Provides high-fidelity client-side procedural canvas rendering and Web Audio synthesis
 *   as an explicit, honest local fallback rather than faking remote server inference.
 */

import { ExternalEngineRequirement, CapabilityStatus } from './builderTypes';
import { CapabilityRegistry } from './capabilityRegistry';

export interface CreativePipelineJob {
  id: string;
  type: 'TEXT_TO_IMAGE' | 'IMAGE_TO_IMAGE' | 'TEXT_TO_VIDEO' | 'IMAGE_TO_VIDEO' | 'AUDIO_SYNTH' | 'MULTIMODAL';
  prompt: string;
  parameters: {
    aspectRatio?: '16:9' | '9:16' | '1:1' | '4:3';
    durationSeconds?: number;
    motionIntensity?: number; // 1-10
    seed?: number;
    style?: string;
  };
  status: 'QUEUED' | 'PROCESSING' | 'COMPLETED' | 'FALLBACK_LOCAL_RENDERED' | 'REQUIRES_ENGINE';
  outputUrl?: string;
  metadata: Record<string, any>;
  createdAt: number;
}

export class CreativeEngineAdapter {
  /**
   * Evaluates if a creative workflow can execute locally or requires an external engine.
   */
  public static evaluateWorkflow(type: CreativePipelineJob['type']): {
    status: CapabilityStatus;
    engineName?: string;
    localSimulationSupported: boolean;
    description: string;
  } {
    switch (type) {
      case 'TEXT_TO_VIDEO':
      case 'IMAGE_TO_VIDEO':
        return {
          status: 'REQUIRES_ENGINE',
          engineName: 'Cloud Spatio-Temporal Video Diffusion Cluster (e.g. Veo / Runway Gen-3)',
          localSimulationSupported: true,
          description: 'High-compute spatio-temporal video diffusion rendering requires remote tensor cluster.'
        };

      case 'TEXT_TO_IMAGE':
      case 'IMAGE_TO_IMAGE':
        return {
          status: 'REQUIRES_ENGINE',
          engineName: 'Cloud Image Diffusion Model (e.g. Imagen 3 / SDXL GPU cluster)',
          localSimulationSupported: true,
          description: 'High-resolution diffusion image synthesis requires dedicated model accelerator.'
        };

      case 'AUDIO_SYNTH':
        return {
          status: 'AVAILABLE_LOCALLY',
          localSimulationSupported: true,
          description: 'Web Audio API provides native hardware-accelerated DSP synthesis in the browser.'
        };

      case 'MULTIMODAL':
        return {
          status: 'AVAILABLE_THROUGH_EXISTING_ENGINE',
          engineName: 'Gemini Multimodal API (@google/genai)',
          localSimulationSupported: true,
          description: 'Multimodal prompt understanding and reasoning using Gemini SDK.'
        };

      default:
        return {
          status: 'SUPPORTED',
          localSimulationSupported: true,
          description: 'Standard client-side animation and procedural rendering.'
        };
    }
  }

  /**
   * Generates a procedural canvas animation frame for local creative preview simulation.
   * Enables full UI interactivity and keyframe scrub testing without pretending to run remote GPUs.
   */
  public static renderProceduralMotionFrame(
    canvas: HTMLCanvasElement | null,
    progress: number, // 0.0 to 1.0
    promptText: string,
    aspectRatio: string = '16:9'
  ): void {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // 1. Clear background with dynamic cinematic dark gradient
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    const hueOffset = Math.floor(progress * 60);
    gradient.addColorStop(0, `hsl(${220 + hueOffset}, 30%, 10%)`);
    gradient.addColorStop(0.5, `hsl(${260 + hueOffset}, 40%, 15%)`);
    gradient.addColorStop(1, `hsl(${200 + hueOffset}, 35%, 8%)`);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // 2. Draw cinematic procedural grid & camera motion lines
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
    ctx.lineWidth = 1;
    const gridCount = 12;
    const panOffset = (progress * 40) % (width / gridCount);
    for (let x = panOffset; x < width; x += width / gridCount) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    // 3. Draw central dynamic generative particle / visual waveform
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) * 0.28;
    const waveCount = 48;

    ctx.beginPath();
    for (let i = 0; i <= waveCount; i++) {
      const angle = (i / waveCount) * Math.PI * 2;
      const wave = Math.sin(angle * 6 + progress * Math.PI * 4) * 16 * Math.sin(progress * Math.PI);
      const r = radius + wave;
      const x = centerX + Math.cos(angle) * r;
      const y = centerY + Math.sin(angle) * r;

      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.closePath();
    ctx.fillStyle = 'rgba(124, 58, 237, 0.25)';
    ctx.fill();
    ctx.strokeStyle = '#a78bfa';
    ctx.lineWidth = 2;
    ctx.stroke();

    // 4. Draw HUD timecode and prompt watermark
    ctx.fillStyle = '#f8fafc';
    ctx.font = '12px ui-monospace, SFMono-Regular, monospace';
    const timecode = `TC ${(progress * 5).toFixed(2)}s / 5.00s`;
    ctx.fillText(timecode, 16, height - 16);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '11px sans-serif';
    const truncatedPrompt = promptText.length > 45 ? `${promptText.slice(0, 42)}...` : promptText;
    ctx.fillText(`PROMPT: "${truncatedPrompt || 'Cinematic sequence'}"`, 16, 24);

    // 5. Draw simulation indicator badge
    ctx.fillStyle = 'rgba(234, 179, 8, 0.2)';
    ctx.fillRect(width - 170, 12, 154, 22);
    ctx.strokeStyle = '#eab308';
    ctx.strokeRect(width - 170, 12, 154, 22);
    ctx.fillStyle = '#fef08a';
    ctx.font = '10px sans-serif';
    ctx.fillText('LOCAL MOTION PREVIEW', width - 160, 27);

    ctx.restore();
  }
}
