/**
 * GODEX P0 — App Building End-to-End Verification & Regression Test Suite
 * Validates that real natural-language app building requests (English, Hindi, Hinglish)
 * flow from intent classification to authoritative control-plane execution,
 * generate genuine non-placeholder application code, pass AST syntax validation,
 * produce verified deliverables, and preserve read-only operations.
 */

import { GodexControlPlane } from '../godex/godexControlPlane';
import { IntentClassifier } from '../intelligence/intentClassifier';
import { AstParser } from '../intelligence/astParser';
import { LocalEngineBrainProvider } from '../intelligence/aiProvider';
import { ContextPack } from '../intelligence/contextTypes';

export interface AppBuildingTestResult {
  name: string;
  passed: boolean;
  details?: string;
  error?: string;
}

export class AppBuildingVerificationTest {
  public static async runSuite(): Promise<{
    passedCount: number;
    totalCount: number;
    results: AppBuildingTestResult[];
  }> {
    const results: AppBuildingTestResult[] = [];

    const createDisposableWorkspace = (): Record<string, string> => ({
      'src/App.tsx': 'import React from "react"; export default function App() { return <div>Initial Sandbox</div>; }',
      'package.json': JSON.stringify({ name: 'disposable-sandbox', version: '1.0.0' }, null, 2)
    });

    // Test 1: Hinglish Notes App Creation ("Ek Notes app bana do")
    try {
      const prompt = 'Ek Notes app bana do';
      const route = IntentClassifier.classifyChatRoute(prompt);
      if (route.route !== 'ENGINEERING_ACTION' || route.intent !== 'IMPLEMENT') {
        throw new Error(`Expected ENGINEERING_ACTION/IMPLEMENT but got route: ${route.route}, intent: ${route.intent}`);
      }

      const workspace = createDisposableWorkspace();
      const cp = GodexControlPlane.getInstance();
      const opResult = await cp.executeOperation(prompt, workspace);

      if (!opResult.success) {
        throw new Error(`executeOperation failed: ${opResult.summary}`);
      }
      if (!opResult.newFiles['src/App.tsx']) {
        throw new Error('src/App.tsx was not produced in newFiles');
      }
      if (!opResult.newFiles['src/App.tsx'].includes('NoteItem') && !opResult.newFiles['src/App.tsx'].includes('notes')) {
        throw new Error('src/App.tsx does not contain genuine Notes application code');
      }

      const syntaxIssues = AstParser.validateSyntax(opResult.newFiles['src/App.tsx']);
      if (syntaxIssues.length > 0) {
        throw new Error(`AST syntax validation failed with ${syntaxIssues.length} issues: ${syntaxIssues.map(i => i.message).join('; ')}`);
      }

      if (opResult.operationState.tests?.overallStatus !== 'PASS') {
        throw new Error(`Verification tests failed with status: ${opResult.operationState.tests?.overallStatus}`);
      }

      results.push({
        name: 'P0-APP-01: Hinglish Notes App ("Ek Notes app bana do") creates genuine verified Notes application',
        passed: true,
        details: `Created artifact "${opResult.operationState.artifact?.name}" with ${opResult.newFiles['src/App.tsx'].length} bytes of valid code.`
      });
    } catch (err: any) {
      results.push({
        name: 'P0-APP-01: Hinglish Notes App ("Ek Notes app bana do") creates genuine verified Notes application',
        passed: false,
        error: err.message
      });
    }

    // Test 2: Hindi General App Directive ("Mere liye ek app bana ke deh")
    try {
      const prompt = 'Mere liye ek app bana ke deh';
      const route = IntentClassifier.classifyChatRoute(prompt);
      if (route.route !== 'ENGINEERING_ACTION' || route.intent !== 'IMPLEMENT') {
        throw new Error(`Expected ENGINEERING_ACTION/IMPLEMENT but got route: ${route.route}, intent: ${route.intent}`);
      }

      const workspace = createDisposableWorkspace();
      const cp = GodexControlPlane.getInstance();
      const opResult = await cp.executeOperation(prompt, workspace);

      if (!opResult.success) {
        throw new Error(`executeOperation failed: ${opResult.summary}`);
      }
      const artifactName = opResult.operationState.artifact?.name || '';
      if (artifactName.toLowerCase().includes('mere liye')) {
        throw new Error(`Artifact name "${artifactName}" leaked conversational directive words instead of clean branding`);
      }

      const syntaxIssues = AstParser.validateSyntax(opResult.newFiles['src/App.tsx']);
      if (syntaxIssues.length > 0) {
        throw new Error(`AST syntax validation failed: ${syntaxIssues.map(i => i.message).join('; ')}`);
      }

      results.push({
        name: 'P0-APP-02: Hindi App Directive ("Mere liye ek app bana ke deh") routes to engineering and generates clean workspace studio',
        passed: true,
        details: `Clean artifact name "${artifactName}", zero stopword leakage, AST verified.`
      });
    } catch (err: any) {
      results.push({
        name: 'P0-APP-02: Hindi App Directive ("Mere liye ek app bana ke deh") routes to engineering and generates clean workspace studio',
        passed: false,
        error: err.message
      });
    }

    // Test 3: Music Player App ("Build me a music player app")
    try {
      const prompt = 'Build me a music player app';
      const route = IntentClassifier.classifyChatRoute(prompt);
      if (route.route !== 'ENGINEERING_ACTION') {
        throw new Error(`Expected ENGINEERING_ACTION but got ${route.route}`);
      }

      const workspace = createDisposableWorkspace();
      const cp = GodexControlPlane.getInstance();
      const opResult = await cp.executeOperation(prompt, workspace);

      if (!opResult.success) {
        throw new Error(`executeOperation failed: ${opResult.summary}`);
      }
      const appCode = opResult.newFiles['src/App.tsx'] || '';
      if (!appCode.includes('TrackItem') || !appCode.includes('isPlaying') || !appCode.includes('tracks')) {
        throw new Error('src/App.tsx does not contain genuine Music Player application code');
      }

      const syntaxIssues = AstParser.validateSyntax(appCode);
      if (syntaxIssues.length > 0) {
        throw new Error(`AST syntax issues: ${syntaxIssues.map(i => i.message).join('; ')}`);
      }

      results.push({
        name: 'P0-APP-03: Music Player ("Build me a music player app") creates interactive audio studio with playback controls',
        passed: true,
        details: `Created "${opResult.operationState.artifact?.name}" with tracklist, scrubber, and audio visualizer.`
      });
    } catch (err: any) {
      results.push({
        name: 'P0-APP-03: Music Player ("Build me a music player app") creates interactive audio studio with playback controls',
        passed: false,
        error: err.message
      });
    }

    // Test 4: Business Website ("Create a website for my business")
    try {
      const prompt = 'Create a website for my business';
      const route = IntentClassifier.classifyChatRoute(prompt);
      if (route.route !== 'ENGINEERING_ACTION') {
        throw new Error(`Expected ENGINEERING_ACTION but got ${route.route}`);
      }

      const workspace = createDisposableWorkspace();
      const cp = GodexControlPlane.getInstance();
      const opResult = await cp.executeOperation(prompt, workspace);

      if (!opResult.success) {
        throw new Error(`executeOperation failed: ${opResult.summary}`);
      }
      const appCode = opResult.newFiles['src/App.tsx'] || '';
      if (!appCode.includes('pricingTiers') || !appCode.includes('services') || !appCode.includes('Apex Enterprise')) {
        throw new Error('src/App.tsx does not contain genuine Business Website code');
      }

      const syntaxIssues = AstParser.validateSyntax(appCode);
      if (syntaxIssues.length > 0) {
        throw new Error(`AST syntax issues: ${syntaxIssues.map(i => i.message).join('; ')}`);
      }

      results.push({
        name: 'P0-APP-04: Business Website ("Create a website for my business") creates showcase with services, pricing, and contact form',
        passed: true,
        details: `Created "${opResult.operationState.artifact?.name}" with interactive pricing and lead form.`
      });
    } catch (err: any) {
      results.push({
        name: 'P0-APP-04: Business Website ("Create a website for my business") creates showcase with services, pricing, and contact form',
        passed: false,
        error: err.message
      });
    }

    // Test 5: Read-Only Preservation
    try {
      const readOnlyPrompt = 'Inspect the codebase without modifying any files';
      const route = IntentClassifier.classifyChatRoute(readOnlyPrompt);
      if (route.route !== 'READ_ONLY_ENGINEERING_QUERY') {
        throw new Error(`Expected READ_ONLY_ENGINEERING_QUERY but got ${route.route}`);
      }

      const symbolPrompt = 'Where is GodexControlPlane?';
      const symbolRoute = IntentClassifier.classifyChatRoute(symbolPrompt);
      if (symbolRoute.route !== 'READ_ONLY_ENGINEERING_QUERY' && symbolRoute.route !== 'CONVERSATIONAL') {
        throw new Error(`Symbol inspection should not trigger mutation, got ${symbolRoute.route}`);
      }

      results.push({
        name: 'P0-APP-05: Read-only queries strictly preserved without mutating workspace',
        passed: true,
        details: 'Verified explicit read-only verbs and file location queries remain non-mutating.'
      });
    } catch (err: any) {
      results.push({
        name: 'P0-APP-05: Read-only queries strictly preserved without mutating workspace',
        passed: false,
        error: err.message
      });
    }

    // Test 6: Truthful Error Reporting on Missing Files or Non-existent Targets
    try {
      const cp = GodexControlPlane.getInstance();
      const emptyWorkspace: Record<string, string> = {};
      const res = await cp.executeOperation('Update nonexistent file', emptyWorkspace, {
        activeFile: 'src/missing_file.tsx'
      });

      if (res.success || !res.summary.includes('FAILED')) {
        throw new Error('Expected operation to fail truthfully for non-existent target file');
      }

      results.push({
        name: 'P0-APP-06: Truthful error reporting on missing file targets without fabricating success',
        passed: true,
        details: `Reported: ${res.summary}`
      });
    } catch (err: any) {
      results.push({
        name: 'P0-APP-06: Truthful error reporting on missing file targets without fabricating success',
        passed: false,
        error: err.message
      });
    }

    // Test 7: Friendly greeting stays conversational instead of triggering repository analysis.
    try {
      const prompt = 'Hey how are you?';
      const route = IntentClassifier.classifyChatRoute(prompt);
      if (route.route !== 'CONVERSATIONAL') {
        throw new Error(`Expected CONVERSATIONAL but got ${route.route}`);
      }
      const pack = {
        taskIntent: 'GENERAL',
        taskExtraction: { goal: prompt, requestedAction: 'GENERAL', entities: [], constraints: [], rawPrompt: prompt },
        relevantFiles: [], relevantSymbols: [], warnings: []
      } as unknown as ContextPack;
      const response = new LocalEngineBrainProvider().generateDeterministicGroundedResponse(prompt, pack);
      if (!/doing well|thanks for asking/i.test(response.answer) || /workspace analysis|NovaApp|ActivityItem|ProjectItem/i.test(response.answer)) {
        throw new Error(`Greeting fallback was not natural/clean: ${response.answer}`);
      }
      results.push({ name: 'P0-APP-07: Greeting receives a natural conversational response without stale workspace symbols', passed: true });
    } catch (err: any) {
      results.push({ name: 'P0-APP-07: Greeting receives a natural conversational response without stale workspace symbols', passed: false, error: err.message });
    }

    // Test 8: A corrective follow-up such as "I said how are you" remains conversational.
    try {
      const prompt = 'I said how are you';
      const route = IntentClassifier.classifyChatRoute(prompt);
      if (route.route !== 'CONVERSATIONAL') throw new Error(`Expected CONVERSATIONAL but got ${route.route}`);
      const pack = {
        taskIntent: 'GENERAL',
        taskExtraction: { goal: prompt, requestedAction: 'GENERAL', entities: [], constraints: [], rawPrompt: prompt },
        relevantFiles: [], relevantSymbols: [], warnings: []
      } as unknown as ContextPack;
      const response = new LocalEngineBrainProvider().generateDeterministicGroundedResponse(prompt, pack);
      if (!/doing well|thanks for asking/i.test(response.answer) || /Workspace Analysis|NovaApp|ActivityItem|ProjectItem/i.test(response.answer)) {
        throw new Error(`Corrective follow-up produced an unrelated answer: ${response.answer}`);
      }
      results.push({ name: 'P0-APP-08: Corrective conversational follow-up does not fall back to Workspace Analysis', passed: true });
    } catch (err: any) {
      results.push({ name: 'P0-APP-08: Corrective conversational follow-up does not fall back to Workspace Analysis', passed: false, error: err.message });
    }

    // Test 9: Explicit repository inspection still selects the read-only route.
    try {
      const route = IntentClassifier.classifyChatRoute('Inspect the codebase');
      if (route.route !== 'READ_ONLY_ENGINEERING_QUERY') {
        throw new Error(`Expected READ_ONLY_ENGINEERING_QUERY but got ${route.route}`);
      }
      results.push({ name: 'P0-APP-09: Explicit workspace inspection remains read-only', passed: true });
    } catch (err: any) {
      results.push({ name: 'P0-APP-09: Explicit workspace inspection remains read-only', passed: false, error: err.message });
    }

    // Test 10: Generic Hinglish app requests never inherit the old Nova fallback title.
    try {
      const { synthesizeDomainApplication } = await import('../intelligence/domainSynthesizer');
      const result = synthesizeDomainApplication('Mere liye ek app bana ke deh', {});
      if (!result || !result.files['src/App.tsx']) throw new Error('Expected a generated application scaffold');
      if (/nova workspace studio|novaapp/i.test(result.name + '\n' + result.files['src/App.tsx'])) {
        throw new Error(`Generic app request inherited stale Nova branding: ${result.name}`);
      }
      if (!/generic starter scaffold/i.test(result.description + ' ' + result.summary)) {
        throw new Error('Fallback generation did not clearly disclose that this is a generic scaffold');
      }
      results.push({ name: 'P0-APP-10: Generic Hinglish app scaffold avoids Nova default branding and states limitations', passed: true });
    } catch (err: any) {
      results.push({ name: 'P0-APP-10: Generic Hinglish app scaffold avoids Nova default branding and states limitations', passed: false, error: err.message });
    }

    const passedCount = results.filter(r => r.passed).length;
    return {
      passedCount,
      totalCount: results.length,
      results
    };
  }
}
