/* Terms of Use / Privacy Policy: acceptance gate, reader, footer, and the owner's "legal status" panel. */
(function (root) {
  "use strict";
  var UI = root.AN_UI, h = UI.h, t = UI.t;
  var KEY = "acconova.terms";
  function cfg() { return root.AN_LEGAL_CONFIG || {}; }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { } }
  var mem = null; /* when storage is blocked, acceptance lasts for this page view only */

  UI.legalAccepted = function () {
    var raw = lsGet(KEY) || mem, rec = null; try { rec = raw && JSON.parse(raw); } catch (e) { }
    return !!(rec && rec.v === String(cfg().version));
  };
  UI.legalRecord = function () { try { return JSON.parse(lsGet(KEY) || mem || "null"); } catch (e) { return null; } };
  function accept() { var rec = JSON.stringify({ v: String(cfg().version), at: new Date().toISOString(), lang: UI.lang }); mem = rec; lsSet(KEY, rec); }
  UI.legalMissing = function () { var c = cfg(); return ["owner", "email", "jurisdiction", "refundPolicy"].filter(function (k) { return !String(c[k] || "").trim(); }); };

  var PH = { owner: "owner", email: "email", jurisdiction: "jurisdiction", refund: "refundPolicy", version: "version", effective: "effective" };
  function fill(text) {
    var c = cfg(), out = document.createDocumentFragment(), re = /\{(\w+)\}/g, last = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > last) out.appendChild(document.createTextNode(text.slice(last, m.index)));
      var key = PH[m[1]], val = key ? String(c[key] || "").trim() : "";
      if (val) out.appendChild(document.createTextNode(val)); else out.appendChild(h("mark", { class: "ph", text: "[" + m[1] + "]" }));
      last = re.lastIndex;
    }
    if (last < text.length) out.appendChild(document.createTextNode(text.slice(last)));
    return out;
  }
  function doc(kind) {
    var D = (root.AN_LEGAL[UI.lang] && root.AN_LEGAL[UI.lang][kind]) || root.AN_LEGAL.en[kind];
    var box = h("article", { class: "legal-doc", lang: root.AN_LEGAL[UI.lang] && root.AN_LEGAL[UI.lang][kind] ? UI.lang : "en", dir: root.AN_LEGAL[UI.lang] && root.AN_LEGAL[UI.lang][kind] ? null : "ltr" });
    box.appendChild(h("h3", { text: D.title })); var intro = h("p", { class: "muted" }); intro.appendChild(fill(D.intro)); box.appendChild(intro);
    D.sections.forEach(function (s) { box.appendChild(h("h4", { text: s[0] })); for (var i = 1; i < s.length; i++) { var p = h("p"); p.appendChild(fill(s[i])); box.appendChild(p); } });
    return box;
  }
  UI.openLegal = function (kind) {
    var body = h("div"), m;
    function show(k) { UI.clear(body); body.appendChild(h("div", { class: "seg legal-tabs", role: "group" }, ["terms", "privacy"].map(function (x) { return h("button", { type: "button", "aria-pressed": x === k ? "true" : "false", onclick: function () { show(x); } }, t("legal_" + x)); }))); body.appendChild(doc(k)); }
    show(kind || "terms");
    m = UI.modal({ title: t("legalTitle"), wide: true, body: body, footer: [h("button", { class: "btn", type: "button", onclick: function () { m.close(); } }, t("close"))], noFocus: true });
  };

  UI.legalGate = function () {
    var chk = h("input", { type: "checkbox", id: "legalChk" }), go = h("button", { class: "btn", type: "button", disabled: true, onclick: function () { accept(); UI.render(); } }, t("legalContinue"));
    chk.addEventListener("change", function () { go.disabled = !chk.checked; });
    return h("div", { class: "onboard-wrap" }, h("section", { class: "card onboard" }, h("h2", { text: t("legalTitle") }), h("p", { class: "muted", text: t("legalGateIntro") }),
      h("div", { class: "actions" }, h("button", { class: "btn sec", type: "button", onclick: function () { UI.openLegal("terms"); } }, t("legal_terms")), h("button", { class: "btn sec", type: "button", onclick: function () { UI.openLegal("privacy"); } }, t("legal_privacy"))),
      h("label", { class: "check", for: "legalChk" }, chk, h("span", { text: t("legalAgree") })), h("div", { class: "actions" }, go)));
  };
  UI.legalFooter = function () {
    return h("footer", { class: "foot" }, h("span", { text: "AccoNova" }), h("button", { class: "link", type: "button", onclick: function () { UI.openLegal("terms"); } }, t("legal_terms")), h("span", { "aria-hidden": "true", text: "·" }), h("button", { class: "link", type: "button", onclick: function () { UI.openLegal("privacy"); } }, t("legal_privacy")), h("span", { class: "muted small", text: "v" + cfg().version }));
  };
  UI.legalStatus = function (box) {
    var miss = UI.legalMissing(), rec = UI.legalRecord(), c = cfg();
    box.appendChild(h("section", { class: "card" }, h("h3", { text: t("legalTitle") }),
      miss.length ? h("p", { class: "form-error", text: t("legalMissing", { list: miss.join(", ") }) }) : h("p", {}, UI.badge(t("legalComplete"), "ok")),
      h("p", { class: "muted", text: t("legalHowTo") }),
      h("dl", { class: "meta" }, h("dt", { text: t("legalVersion") }), h("dd", { text: String(c.version) + " · " + c.effective }), h("dt", { text: t("legalAccepted") }), h("dd", { text: rec ? (UI.fmt.dateTime ? UI.fmt.dateTime(new Date(rec.at).getTime()) : rec.at) : "—" })),
      h("div", { class: "actions" }, h("button", { class: "btn sec", type: "button", onclick: function () { UI.openLegal("terms"); } }, t("legal_terms")), h("button", { class: "btn sec", type: "button", onclick: function () { UI.openLegal("privacy"); } }, t("legal_privacy"))),
      h("p", { class: "note", text: t("legalLawyer") })));
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
