import { VisualScriptNode, VisualScriptConnection } from '../types';

export const INITIAL_VISUAL_SCRIPT_NODES: VisualScriptNode[] = [
  {
    id: 'node_trigger',
    title: 'Player Enters Trigger',
    type: 'event',
    x: 40,
    y: 60,
    inputs: [],
    outputs: ['Out', 'PlayerRef'],
    params: { triggerTag: 'Zone_Outpost', radius: 4.0 },
  },
  {
    id: 'node_condition',
    title: 'Check Condition',
    type: 'condition',
    x: 280,
    y: 70,
    inputs: ['In', 'Condition'],
    outputs: ['True', 'False'],
    params: { variable: 'hasKeycard', operator: '==', value: true },
  },
  {
    id: 'node_anim',
    title: 'Play Animation / SFX',
    type: 'action',
    x: 520,
    y: 40,
    inputs: ['In'],
    outputs: ['Done'],
    params: { soundType: 'synth_bell', pitch: 1.2 },
  },
  {
    id: 'node_mission',
    title: 'Update Mission',
    type: 'action',
    x: 740,
    y: 50,
    inputs: ['In'],
    outputs: ['Done'],
    params: { missionId: 'DISCOVER_OUTPOST', status: 'COMPLETED' },
  },
  {
    id: 'node_reward',
    title: 'Reward Player',
    type: 'action',
    x: 960,
    y: 60,
    inputs: ['In'],
    outputs: [],
    params: { experience: 250, credits: 100 },
  },
];

export const INITIAL_VISUAL_SCRIPT_CONNECTIONS: VisualScriptConnection[] = [
  {
    id: 'conn_1',
    fromNodeId: 'node_trigger',
    fromOutput: 'Out',
    toNodeId: 'node_condition',
    toInput: 'In',
  },
  {
    id: 'conn_2',
    fromNodeId: 'node_condition',
    fromOutput: 'True',
    toNodeId: 'node_anim',
    toInput: 'In',
  },
  {
    id: 'conn_3',
    fromNodeId: 'node_anim',
    fromOutput: 'Done',
    toNodeId: 'node_mission',
    toInput: 'In',
  },
  {
    id: 'conn_4',
    fromNodeId: 'node_mission',
    fromOutput: 'Done',
    toNodeId: 'node_reward',
    toInput: 'In',
  },
];

export const SAMPLE_SCRIPTS: Record<string, string> = {
  'CharacterController.ts': `// DAVIENGINE Script Component: CharacterController
// Runs automatically during Game Mode

export class CharacterController {
  public speed = 8.0;
  public jumpForce = 9.5;

  public onStart(entity: EngineObject) {
    console.log("[DAVIENGINE Script] Initialized Character on", entity.name);
  }

  public onUpdate(entity: EngineObject, delta: number) {
    // Custom logic evaluated each frame
  }

  public onTriggerEnter(other: EngineObject) {
    console.log("Trigger collision with:", other.name);
  }
}
`,
  'RotatingBeacon.ts': `// DAVIENGINE Script Component: RotatingBeacon
// Rotates an object smoothly along its Y axis

export class RotatingBeacon {
  public rotationSpeed = 45; // deg/sec

  public onUpdate(entity: EngineObject, delta: number) {
    entity.transform.rotation.y = (entity.transform.rotation.y + this.rotationSpeed * delta) % 360;
  }
}
`,
  'PatrolAI.ts': `// DAVIENGINE Script Component: PatrolAI
// Simple waypoint navigation behavior for NPCs

export class PatrolAI {
  public patrolRadius = 15;
  public waypointIndex = 0;

  public onUpdate(entity: EngineObject, delta: number) {
    // Patrol state logic
  }
}
`,
};
