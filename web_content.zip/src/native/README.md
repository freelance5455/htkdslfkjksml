# MeshLink — native Android build

Offline P2P messenger on the **Google Nearby Connections API**.
Radios: **Bluetooth LE + Wi-Fi Direct** (P2P_CLUSTER) — works over **hotspot**.
No internet, no SIM, no server.

## Build

```bash
flutter create meshlink --platforms android
cd meshlink
# replace pubspec.yaml, android/app/src/main/AndroidManifest.xml
# and the whole lib/ folder with the files from this kit
flutter pub get
flutter run          # two or more PHYSICAL Android phones
```

- minSdkVersion 23 in android/app/build.gradle
- Emulators cannot do BLE / Wi-Fi Direct — use real devices
- Over hotspot: Nearby Connections uses Wi-Fi Direct plus the local
  Wi-Fi network, so phones joined to the same hotspot link up directly.

## How the mesh works

1. Every phone advertises AND discovers at the same time (P2P_CLUSTER).
2. Every packet carries: senderId, targetId, messageId, TTL = 10, payload.
3. A phone that is not the target re-broadcasts the packet to all its
   other peers with TTL - 1 (hop-by-hop relay).
4. Every phone keeps a seen-set of messageIds — duplicates are dropped,
   so loops and broadcast storms are impossible.
5. The receiver fires an ack packet back through the mesh: the sender's
   single check becomes a double check, with the true hop count.
