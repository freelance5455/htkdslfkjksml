import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:uuid/uuid.dart';

import '../models/chat_message.dart';
import '../models/mesh_packet.dart';

class Peer {
  final String endpointId;
  String name;
  String? stableId;
  Peer(this.endpointId, this.name, {this.stableId});
}

/// ---------------------------------------------------------------------------
/// Discovery, connections and the hop-by-hop relay engine on top of the
/// Google Nearby Connections API (P2P_CLUSTER = BLE + Wi-Fi Direct/hotspot).
///
///  1. Every device advertises AND discovers at the same time, so any two
///     MeshLink phones in radio range link up automatically.
///  2. Every packet: { senderId, targetId, messageId, TTL = 10, payload }.
///  3. A device receiving a packet it is not the target of re-broadcasts it
///     to every connected peer except the sender, with TTL - 1 (relay).
///  4. A seen-set of messageIds kills loops and broadcast storms.
///  5. Receivers fire an ack back through the mesh: single check -> double.
/// ---------------------------------------------------------------------------
class MeshService extends ChangeNotifier {
  static const String serviceId = 'com.meshlink.mesh';
  static const Strategy strategy = Strategy.P2P_CLUSTER;
  static const int seenCap = 5000;

  final String myId = const Uuid().v4();
  final String myName = 'Device-${1000 + Random().nextInt(9000)}';

  final Map<String, Peer> peers = {};
  final Map<String, String> discovered = {};
  final Map<String, String> directory = {}; // stableId -> display name
  bool advertising = false;
  bool discovering = false;

  final Set<String> _seen = <String>{};
  final List<String> _seenOrder = [];

  final List<ChatMessage> messages = [];
  final Map<String, ChatMessage> _byId = {};
  final List<String> activity = [];

  // ------------------------------ lifecycle -------------------------------

  Future<void> start() async {
    try {
      await Nearby().stopAllEndpoints();
    } catch (_) {}
    await Future.wait([_startAdvertising(), _startDiscovery()]);
    _log('radio on — advertising + discovering (P2P_CLUSTER)');
  }

  Future<void> _startAdvertising() async {
    try {
      advertising = await Nearby().startAdvertising(
        myName,
        strategy,
        serviceId: serviceId,
        onConnectionInitiated: _onConnectionInitiated,
        onConnectionResult: _onConnectionResult,
        onDisconnected: _onDisconnected,
      );
    } catch (e) {
      _log('advertising failed: $e');
    }
    notifyListeners();
  }

  Future<void> _startDiscovery() async {
    try {
      discovering = await Nearby().startDiscovery(
        myName,
        strategy,
        serviceId: serviceId,
        onEndpointFound: (id, name, sid) {
          discovered[id] = name;
          _log('radar: $name spotted');
          notifyListeners();
        },
        onEndpointLost: (id) {
          discovered.remove(id);
          notifyListeners();
        },
      );
    } catch (e) {
      _log('discovery failed: $e');
    }
    notifyListeners();
  }

  void _onConnectionInitiated(String endpointId, ConnectionInfo info) {
    discovered[endpointId] = info.endpointName;
    Nearby().acceptConnection(
      endpointId,
      // (the plugin really spells the parameter "onPayLoadRecieved")
      onPayLoadRecieved: _onPayloadReceived,
      onPayloadTransferUpdate: (payloadId, update) {},
    );
  }

  void _onConnectionResult(String endpointId, Status status) {
    if (status == Status.CONNECTED) {
      peers[endpointId] = Peer(endpointId, discovered[endpointId] ?? 'Peer');
      discovered.remove(endpointId);
      _log('${peers[endpointId]!.name} joined the mesh');
      sayHello();
    } else {
      discovered.remove(endpointId);
      _log('connection ${status == Status.REJECTED ? 'rejected' : 'failed'}');
    }
    notifyListeners();
  }

  void _onDisconnected(String endpointId) {
    final p = peers.remove(endpointId);
    if (p != null) _log('${p.name} left the mesh');
    notifyListeners();
  }

  Future<void> connectTo(String endpointId) async {
    try {
      await Nearby().requestConnection(
        myName,
        endpointId,
        onConnectionInitiated: _onConnectionInitiated,
        onConnectionResult: _onConnectionResult,
        onDisconnected: _onDisconnected,
      );
    } catch (e) {
      _log('request failed: $e');
    }
  }

  // ------------------------------- sending --------------------------------

  void sayHello() {
    final hello = MeshPacket.create(
      senderId: myId,
      senderName: myName,
      targetId: MeshPacket.broadcast,
      type: MeshPacket.tHello,
      payload: myName,
    );
    _remember(hello.messageId);
    _flood(hello);
  }

  ChatMessage sendText({required String targetId, required String text}) {
    final packet = MeshPacket.create(
      senderId: myId,
      senderName: myName,
      targetId: targetId,
      type: MeshPacket.tText,
      payload: text,
    );
    final msg = ChatMessage(
      id: packet.messageId,
      senderId: myId,
      senderName: myName,
      targetId: targetId,
      text: text,
      outgoing: true,
      status: MsgStatus.sending,
      time: DateTime.now(),
    );
    _pushMessage(msg);
    _remember(packet.messageId);
    _flood(packet).then((_) {
      msg.status = MsgStatus.sent;
      notifyListeners();
    });
    return msg;
  }

  /// Send a packet to every connected peer (optionally skipping one).
  Future<void> _flood(MeshPacket packet, {String? except}) async {
    final bytes = packet.toBytes();
    for (final endpointId in peers.keys.toList()) {
      if (endpointId == except) continue;
      try {
        await Nearby().sendBytesPayload(endpointId, bytes);
      } catch (e) {
        _log('send to $endpointId failed');
      }
    }
  }

  // ------------------------------ receiving -------------------------------

  void _onPayloadReceived(String fromEndpoint, Payload payload) {
    if (payload.type != PayloadType.BYTES) return;
    final packet = MeshPacket.tryFromBytes(payload.bytes);
    if (packet == null) return;

    directory[packet.senderId] = packet.senderName;
    for (final p in peers.values) {
      if (p.name == packet.senderName && p.stableId == null) {
        p.stableId = packet.senderId;
      }
    }

    // (1) LOOP PREVENTION — already seen this messageId? Drop it.
    if (_seen.contains(packet.messageId)) return;
    _remember(packet.messageId);

    final addressedToMe = packet.targetId == myId;
    final isBroadcast = packet.targetId == MeshPacket.broadcast;
    final forMe = addressedToMe || isBroadcast;

    // (2) Deliver locally.
    if (forMe) _deliver(packet);

    // (3) RELAY — targeted packets not for me, plus broadcast flooding.
    final shouldRelay = packet.ttl > 1 && (isBroadcast || !addressedToMe);
    if (shouldRelay) {
      final relayed = packet.forRelay();
      _log('relay ${packet.type} for ${packet.senderName} — TTL ${relayed.ttl}, hop ${relayed.hops}');
      _flood(relayed, except: fromEndpoint);
    } else if (!addressedToMe && !isBroadcast) {
      _log('TTL expired — dropped ${packet.type} for ${packet.senderName}');
    }
    notifyListeners();
  }

  void _deliver(MeshPacket packet) {
    switch (packet.type) {
      case MeshPacket.tHello:
        _log('${packet.senderName} is on the mesh');
        break;

      case MeshPacket.tAck:
        final original = _byId[packet.payload];
        if (original != null && original.outgoing) {
          original.status = MsgStatus.delivered;
          original.hops = packet.hops;
          _log('${original.text.length > 12 ? '${original.text.substring(0, 12)}…' : original.text} delivered — ${packet.hops} hop(s)');
        }
        break;

      case MeshPacket.tText:
        _pushMessage(ChatMessage(
          id: packet.messageId,
          senderId: packet.senderId,
          senderName: packet.senderName,
          targetId: packet.targetId,
          text: packet.payload,
          outgoing: false,
          status: MsgStatus.delivered,
          hops: packet.hops,
          time: DateTime.now(),
        ));
        if (packet.targetId == myId) {
          final ack = MeshPacket.create(
            senderId: myId,
            senderName: myName,
            targetId: packet.senderId,
            type: MeshPacket.tAck,
            payload: packet.messageId,
          );
          _remember(ack.messageId);
          _flood(ack);
        }
        break;
    }
  }

  // ------------------------------- helpers --------------------------------

  void _remember(String messageId) {
    if (_seen.add(messageId)) {
      _seenOrder.add(messageId);
      if (_seenOrder.length > seenCap) _seen.remove(_seenOrder.removeAt(0));
    }
  }

  void _pushMessage(ChatMessage m) {
    messages.add(m);
    _byId[m.id] = m;
  }

  void _log(String line) {
    activity.insert(0, line);
    if (activity.length > 40) activity.removeLast();
    debugPrint('[mesh] $line');
  }

  List<ChatMessage> threadFor(String targetKey) {
    final isRoom = targetKey == MeshPacket.broadcast;
    return messages
        .where((m) => isRoom
            ? m.isBroadcast
            : (m.targetId == targetKey ||
                (m.senderId == targetKey && !m.isBroadcast)))
        .toList();
  }

  String nameOf(String stableId) =>
      directory[stableId] ?? (stableId == myId ? myName : 'Peer');
}
