import 'package:permission_handler/permission_handler.dart';

/// Requests every permission MeshLink needs, in one call, on launch:
/// Bluetooth scan/connect/advertise, location (BLE scan gate on 6-11),
/// nearby Wi-Fi devices (Wi-Fi Direct on 13+).
class PermissionService {
  static Future<Map<Permission, PermissionStatus>> requestAll() async {
    return [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.bluetoothAdvertise,
      Permission.locationWhenInUse,
      Permission.nearbyWifiDevices,
    ].request();
  }

  /// The mesh cannot start without these two. On Android < 12 the Bluetooth
  /// runtime permissions don't exist and report granted automatically.
  static bool meshReady(Map<Permission, PermissionStatus> s) {
    bool ok(Permission p) {
      final v = s[p];
      return v == PermissionStatus.granted || v == PermissionStatus.limited;
    }

    return ok(Permission.bluetoothConnect) && ok(Permission.locationWhenInUse);
  }

  static Future<void> openSettings() => openAppSettings();
}
