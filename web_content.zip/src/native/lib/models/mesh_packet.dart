import 'dart:convert';
import 'dart:typed_data';

import 'package:uuid/uuid.dart';

/// The single unit of data that travels through the mesh.
/// Fields: senderId, targetId, messageId, TTL (=10), hops, type, payload.
class MeshPacket {
  static const String broadcast = 'BROADCAST';
  static const int initialTtl = 10;

  static const String tText = 'text';
  static const String tAck = 'ack';
  static const String tHello = 'hello';

  final String senderId;
  final String senderName;
  final String targetId;
  final String messageId;
  final int ttl;
  final int hops;
  final String type;
  final String payload;

  const MeshPacket({
    required this.senderId,
    required this.senderName,
    required this.targetId,
    required this.messageId,
    required this.ttl,
    required this.type,
    required this.payload,
    this.hops = 0,
  });

  factory MeshPacket.create({
    required String senderId,
    required String senderName,
    required String targetId,
    required String type,
    String payload = '',
    int ttl = initialTtl,
  }) {
    return MeshPacket(
      senderId: senderId,
      senderName: senderName,
      targetId: targetId,
      messageId: const Uuid().v4(),
      ttl: ttl,
      type: type,
      payload: payload,
    );
  }

  /// Relay copy: same messageId (dedup stays intact), TTL - 1, hops + 1.
  MeshPacket forRelay() => MeshPacket(
        senderId: senderId,
        senderName: senderName,
        targetId: targetId,
        messageId: messageId,
        ttl: ttl - 1,
        hops: hops + 1,
        type: type,
        payload: payload,
      );

  Map<String, dynamic> toJson() => {
        's': senderId, 'sn': senderName, 't': targetId, 'm': messageId,
        'ttl': ttl, 'h': hops, 'ty': type, 'p': payload,
      };

  factory MeshPacket.fromJson(Map<String, dynamic> j) => MeshPacket(
        senderId: j['s'] as String,
        senderName: (j['sn'] as String?) ?? 'Peer',
        targetId: j['t'] as String,
        messageId: j['m'] as String,
        ttl: j['ttl'] as int,
        hops: (j['h'] as int?) ?? 0,
        type: j['ty'] as String,
        payload: (j['p'] as String?) ?? '',
      );

  Uint8List toBytes() => Uint8List.fromList(utf8.encode(jsonEncode(toJson())));

  static MeshPacket? tryFromBytes(Uint8List? bytes) {
    if (bytes == null || bytes.isEmpty) return null;
    try {
      return MeshPacket.fromJson(
          jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }
}
