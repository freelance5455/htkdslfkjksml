import 'mesh_packet.dart';

enum MsgStatus { sending, sent, delivered }

class ChatMessage {
  final String id; // == MeshPacket.messageId (acks find their message by this)
  final String senderId;
  final String senderName;
  final String targetId;
  String text;
  final bool outgoing;
  MsgStatus status;
  int hops;
  DateTime time;

  ChatMessage({
    required this.id,
    required this.senderId,
    required this.senderName,
    required this.targetId,
    required this.text,
    required this.outgoing,
    required this.time,
    this.status = MsgStatus.sent,
    this.hops = 0,
  });

  bool get isBroadcast => targetId == MeshPacket.broadcast;
}
