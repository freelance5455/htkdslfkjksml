import 'package:flutter/material.dart';

import '../core/permission_service.dart';

/// First screen: explains and requests every permission in one tap.
class PermissionsGate extends StatefulWidget {
  final Future<void> Function() onAllGranted;
  const PermissionsGate({super.key, required this.onAllGranted});

  @override
  State<PermissionsGate> createState() => _PermissionsGateState();
}

class _PermissionsGateState extends State<PermissionsGate> {
  bool _busy = false;
  bool _failed = false;

  static const _rows = [
    (Icons.bluetooth, 'Bluetooth', 'BLE discovery, linking and advertising'),
    (Icons.wifi, 'Wi-Fi / Nearby devices', 'Wi-Fi Direct and hotspot lanes'),
    (Icons.location_on, 'Location', 'Android gate for BLE scanning'),
  ];

  Future<void> _request() async {
    setState(() {
      _busy = true;
      _failed = false;
    });
    final statuses = await PermissionService.requestAll();
    if (!mounted) return;
    setState(() => _busy = false);
    if (PermissionService.meshReady(statuses)) {
      await widget.onAllGranted();
    } else {
      setState(() => _failed = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 24),
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF2E9BFF), Color(0xFF0A6CFF)],
                  ),
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF0A6CFF).withOpacity(0.35),
                      blurRadius: 24,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: const Icon(Icons.hub, color: Colors.white, size: 34),
              ),
              const SizedBox(height: 28),
              const Text(
                'MeshLink',
                style: TextStyle(
                  fontSize: 34,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF0B2447),
                  letterSpacing: -1,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Offline messaging on the Google Nearby Connections API.\n'
                'Bluetooth + Wi-Fi Direct / hotspot. No internet, no SIM, no server.',
                style: TextStyle(fontSize: 15, height: 1.5, color: Colors.blueGrey.shade600),
              ),
              const SizedBox(height: 32),
              const Text(
                'PERMISSIONS — REQUESTED AUTOMATICALLY',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.4,
                  color: Color(0xFF0A6CFF),
                ),
              ),
              const SizedBox(height: 12),
              ..._rows.map(
                (r) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 7),
                  child: Row(
                    children: [
                      Icon(r.$1, size: 20, color: const Color(0xFF0A6CFF)),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Text(
                          r.$2,
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF0B2447),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Text(
                          r.$3,
                          style: TextStyle(fontSize: 12.5, color: Colors.blueGrey.shade500),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const Spacer(),
              if (_failed)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline, size: 18, color: Colors.redAccent),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Bluetooth and Location are required for the mesh.',
                          style: TextStyle(fontSize: 12.5, color: Colors.red.shade400),
                        ),
                      ),
                      TextButton(
                        onPressed: PermissionService.openSettings,
                        child: const Text('Open settings'),
                      ),
                    ],
                  ),
                ),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: FilledButton(
                  onPressed: _busy ? null : _request,
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF0A6CFF),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    elevation: 6,
                    shadowColor: const Color(0xFF0A6CFF).withOpacity(0.45),
                  ),
                  child: _busy
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
                      : const Text(
                          'Grant and start the mesh',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                        ),
                ),
              ),
              const SizedBox(height: 18),
            ],
          ),
        ),
      ),
    );
  }
}
