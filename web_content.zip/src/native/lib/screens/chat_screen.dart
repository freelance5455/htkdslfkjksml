import 'package:flutter/material.dart';

import '../core/mesh_service.dart';
import '../models/chat_message.dart';
import '../models/mesh_packet.dart';

/// WhatsApp-style conversation. targetKey is a peer's stable id, or
/// MeshPacket.broadcast for the Everyone room.
class ChatScreen extends StatefulWidget {
  final MeshService mesh;
  final String targetKey;
  final String title;

  const ChatScreen({
    super.key,
    required this.mesh,
    required this.targetKey,
    required this.title,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();

  bool get isBroadcast => widget.targetKey == MeshPacket.broadcast;

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _jumpToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  void _send() {
    final text = _input.text.trim();
    if (text.isEmpty) return;
    widget.mesh.sendText(targetId: widget.targetKey, text: text);
    _input.clear();
    _jumpToEnd();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.mesh,
      builder: (context, _) {
        final thread = widget.mesh.threadFor(widget.targetKey);
        _jumpToEnd();

        return Scaffold(
          appBar: AppBar(
            title: Row(
              children: [
                CircleAvatar(
                  radius: 17,
                  backgroundColor: const Color(0xFF0A6CFF).withOpacity(0.12),
                  child: Icon(
                    isBroadcast ? Icons.groups : Icons.person,
                    size: 19,
                    color: const Color(0xFF0A6CFF),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.title,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                      Text(
                        'via mesh · ${widget.mesh.peers.length} peer(s) connected · offline',
                        style: TextStyle(fontSize: 11, color: Colors.blueGrey.shade500),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          body: Column(
            children: [
              if (widget.mesh.activity.isNotEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  color: const Color(0xFF0A6CFF).withOpacity(0.06),
                  child: Text(
                    widget.mesh.activity.first,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontFamily: 'monospace', fontSize: 11, color: Color(0xFF0A6CFF)),
                  ),
                ),
              Expanded(
                child: ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  itemCount: thread.length,
                  itemBuilder: (_, i) => _bubble(thread[i]),
                ),
              ),
              _inputBar(),
            ],
          ),
        );
      },
    );
  }

  Widget _bubble(ChatMessage m) {
    final mine = m.outgoing;
    final showSender = !mine && isBroadcast;

    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.76),
        decoration: BoxDecoration(
          color: mine ? const Color(0xFF0A6CFF) : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(mine ? 16 : 4),
            bottomRight: Radius.circular(mine ? 4 : 16),
          ),
          border: mine ? null : Border.all(color: Colors.blue.shade100),
          boxShadow: [
            BoxShadow(
              color: (mine ? const Color(0xFF0A6CFF) : const Color(0xFF0B2447))
                  .withOpacity(mine ? 0.25 : 0.06),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (showSender)
              Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text(m.senderName,
                    style: const TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF0A6CFF))),
              ),
            Text(
              m.text,
              style: TextStyle(
                fontSize: 14.5,
                height: 1.35,
                color: mine ? Colors.white : const Color(0xFF0B2447),
              ),
            ),
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '${m.time.hour.toString().padLeft(2, '0')}:${m.time.minute.toString().padLeft(2, '0')}',
                  style: TextStyle(
                      fontSize: 10,
                      color: mine ? Colors.white70 : Colors.blueGrey.shade400),
                ),
                if (!mine && m.hops > 0) ...[
                  const SizedBox(width: 6),
                  Icon(Icons.route, size: 11, color: Colors.blueGrey.shade400),
                  Text(' ${m.hops} hop${m.hops == 1 ? '' : 's'} via mesh',
                      style: TextStyle(fontSize: 10, color: Colors.blueGrey.shade400)),
                ],
                if (mine) ...[
                  const SizedBox(width: 5),
                  if (m.status == MsgStatus.sending)
                    const Icon(Icons.schedule, size: 12, color: Colors.white70)
                  else if (m.status == MsgStatus.delivered)
                    const Icon(Icons.done_all, size: 13, color: Color(0xFF9CFFD8))
                  else
                    const Icon(Icons.done, size: 12, color: Colors.white70),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _inputBar() {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Colors.blue.shade50)),
        ),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _input,
                minLines: 1,
                maxLines: 4,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                decoration: InputDecoration(
                  hintText: 'Message — travels hop by hop…',
                  hintStyle: TextStyle(color: Colors.blueGrey.shade300),
                  filled: true,
                  fillColor: Colors.blue.shade50.withOpacity(0.6),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 52,
              height: 52,
              child: FilledButton(
                onPressed: _send,
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF0A6CFF),
                  shape: const CircleBorder(),
                  elevation: 4,
                  shadowColor: const Color(0xFF0A6CFF).withOpacity(0.4),
                ),
                child: const Icon(Icons.send_rounded, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
