import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/mesh_service.dart';
import '../models/mesh_packet.dart';
import 'chat_screen.dart';

/// Home screen: BLE / Wi-Fi radar, discovered devices, connected peers,
/// the Everyone broadcast room and the live mesh activity feed.
class DiscoveryScreen extends StatefulWidget {
  final MeshService mesh;
  const DiscoveryScreen({super.key, required this.mesh});

  @override
  State<DiscoveryScreen> createState() => _DiscoveryScreenState();
}

class _DiscoveryScreenState extends State<DiscoveryScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _sweep;

  @override
  void initState() {
    super.initState();
    _sweep = AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat();
  }

  @override
  void dispose() {
    _sweep.dispose();
    super.dispose();
  }

  void _openChat(String targetKey, String title) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            ChatScreen(mesh: widget.mesh, targetKey: targetKey, title: title),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.mesh,
      builder: (context, _) {
        final mesh = widget.mesh;
        final found = mesh.discovered.entries.toList();
        final linked = mesh.peers.values.toList();

        return Scaffold(
          appBar: AppBar(
            title: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('MeshLink',
                    style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                Text('offline mesh messenger',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500)),
              ],
            ),
            actions: [
              Container(
                margin: const EdgeInsets.only(right: 14),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: linked.isEmpty
                      ? Colors.blueGrey.shade50
                      : const Color(0xFF0A6CFF).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(
                    color: linked.isEmpty
                        ? Colors.blueGrey.shade200
                        : const Color(0xFF0A6CFF).withOpacity(0.4),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: linked.isEmpty
                            ? Colors.blueGrey.shade300
                            : const Color(0xFF0A6CFF),
                      ),
                    ),
                    const SizedBox(width: 7),
                    Text(
                      '${linked.length} peer${linked.length == 1 ? '' : 's'} connected',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        color: linked.isEmpty ? Colors.blueGrey.shade600 : const Color(0xFF0A6CFF),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
            children: [
              SizedBox(
                height: 230,
                child: AnimatedBuilder(
                  animation: _sweep,
                  builder: (_, __) => CustomPaint(
                    painter: _RadarPainter(sweep: _sweep.value, blips: found.length),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Center(
                child: Text(
                  mesh.advertising || mesh.discovering
                      ? 'scanning over BLE + Wi-Fi Direct…'
                      : 'radio idle',
                  style: TextStyle(fontSize: 12, color: Colors.blueGrey.shade500),
                ),
              ),
              const SizedBox(height: 20),

              if (found.isNotEmpty) ...[
                _sectionTitle('NEARBY — TAP TO LINK'),
                ...found.map(
                  (e) => Card(
                    elevation: 0,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: BorderSide(color: Colors.blue.shade100),
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.blue.shade50,
                        child: Icon(Icons.phonelink_ring, color: Colors.blue.shade700),
                      ),
                      title: Text(e.value, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: const Text('tap to request a mesh link'),
                      trailing: FilledButton(
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF0A6CFF),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: () => mesh.connectTo(e.key),
                        child: const Text('Link'),
                      ),
                    ),
                  ),
                ),
              ],

              _sectionTitle('YOUR MESH — ${linked.length} LINKED'),
              Card(
                elevation: 0,
                color: const Color(0xFF0A6CFF),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  onTap: () => _openChat(MeshPacket.broadcast, 'Everyone'),
                  leading: const CircleAvatar(
                    backgroundColor: Colors.white24,
                    child: Icon(Icons.groups, color: Colors.white),
                  ),
                  title: const Text('Everyone',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                  subtitle: Text(
                    'broadcast room — every device on the mesh, hop by hop',
                    style: TextStyle(color: Colors.white.withOpacity(0.75), fontSize: 12),
                  ),
                  trailing: const Icon(Icons.chevron_right, color: Colors.white),
                ),
              ),
              const SizedBox(height: 8),
              if (linked.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Text(
                    'No peers linked yet. Open MeshLink on another phone —\nit appears on the radar automatically (Bluetooth or Wi-Fi / hotspot).',
                    style: TextStyle(fontSize: 13, color: Colors.blueGrey.shade500, height: 1.5),
                  ),
                )
              else
                ...linked.map(
                  (p) => Card(
                    elevation: 0,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: BorderSide(color: Colors.blue.shade100),
                    ),
                    child: ListTile(
                      onTap: () => _openChat(p.stableId ?? p.endpointId, p.name),
                      leading: CircleAvatar(
                        backgroundColor: const Color(0xFF0A6CFF).withOpacity(0.12),
                        child: Text(
                          p.name.isNotEmpty ? p.name[0].toUpperCase() : '?',
                          style: const TextStyle(
                              color: Color(0xFF0A6CFF), fontWeight: FontWeight.w800),
                        ),
                      ),
                      title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: const Text('linked · direct lane'),
                      trailing:
                          const Icon(Icons.chevron_right, color: Colors.black26),
                    ),
                  ),
                ),

              _sectionTitle('MESH ACTIVITY'),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFF0B2447),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (mesh.activity.isEmpty)
                      const Text('Quiet for now. Packets will show up here.',
                          style: TextStyle(
                              fontFamily: 'monospace', fontSize: 12, color: Colors.white38))
                    else
                      ...mesh.activity.take(7).map(
                            (l) => Padding(
                              padding: const EdgeInsets.symmetric(vertical: 2),
                              child: Text(l,
                                  style: const TextStyle(
                                      fontFamily: 'monospace',
                                      fontSize: 11.5,
                                      color: Color(0xFF9CC8FF),
                                      height: 1.45)),
                            ),
                          ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _sectionTitle(String s) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 18, 0, 10),
        child: Text(
          s,
          style: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.3,
            color: Color(0xFF0A6CFF),
          ),
        ),
      );
}

class _RadarPainter extends CustomPainter {
  final double sweep;
  final int blips;
  _RadarPainter({required this.sweep, required this.blips});

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2 - 6;

    final ringPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = const Color(0xFF0A6CFF).withOpacity(0.18);
    for (var i = 1; i <= 3; i++) {
      canvas.drawCircle(c, r * i / 3, ringPaint);
    }

    final wedge = Paint()
      ..shader = SweepGradient(
        startAngle: sweep * 2 * math.pi - 1.1,
        endAngle: sweep * 2 * math.pi,
        colors: [
          const Color(0xFF0A6CFF).withOpacity(0),
          const Color(0xFF0A6CFF).withOpacity(0.28),
        ],
      ).createShader(Rect.fromCircle(center: c, radius: r));
    canvas.drawCircle(c, r, wedge);

    canvas.drawCircle(c, 6, Paint()..color = const Color(0xFF0A6CFF));
    for (var i = 0; i < blips; i++) {
      final angle = (i * 2.39996) + sweep * 0.6;
      final dist = r * (0.35 + 0.55 * (((i * 37) % 10) / 10));
      final p = c + Offset(math.cos(angle), math.sin(angle)) * dist;
      canvas.drawCircle(p, 5, Paint()..color = const Color(0xFF2E9BFF));
    }
  }

  @override
  bool shouldRepaint(covariant _RadarPainter old) =>
      old.sweep != sweep || old.blips != blips;
}
