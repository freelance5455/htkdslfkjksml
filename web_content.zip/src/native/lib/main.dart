import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/mesh_service.dart';
import 'core/permission_service.dart';
import 'screens/discovery_screen.dart';
import 'screens/permissions_gate.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(statusBarColor: Colors.transparent),
  );
  runApp(const MeshLinkApp());
}

class MeshLinkApp extends StatefulWidget {
  const MeshLinkApp({super.key});

  @override
  State<MeshLinkApp> createState() => _MeshLinkAppState();
}

class _MeshLinkAppState extends State<MeshLinkApp> {
  final MeshService mesh = MeshService();
  bool _ready = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MeshLink',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0A6CFF),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF2F7FF),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF2F7FF),
          foregroundColor: Color(0xFF0B2447),
          elevation: 0,
          centerTitle: false,
          titleTextStyle: TextStyle(
            color: Color(0xFF0B2447),
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      home: _ready
          ? DiscoveryScreen(mesh: mesh)
          : PermissionsGate(onAllGranted: () async {
              await mesh.start(); // advertise + discover at the same time
              setState(() => _ready = true);
            }),
    );
  }
}


