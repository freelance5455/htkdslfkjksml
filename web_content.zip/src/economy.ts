// Single source of truth for top-up packages.
// IMPORTANT: firestore.rules (validTopupPackage) must contain the same table.
export const TOPUP_PACKAGES = [
  { id: 'p50',  price: 50,  coins: 5000,  flowers: 250 },
  { id: 'p100', price: 100, coins: 12000, flowers: 600 },
  { id: 'p250', price: 250, coins: 30000, flowers: 1500 }
] as const;

export const VODAFONE_CASH_NUMBER = '01066257254';

// Display only. The server (functions/config.js) is the authority for these numbers.
export const WITHDRAWAL_RULES = {
  EGP_PER_EARNING: 0.01,
  MIN_EARNINGS: 10000,
  MIN_ACCOUNT_AGE_DAYS: 7
};
