let ctx: AudioContext | null = null
let muted = false
let lastHit = 0

export function setMuted(next: boolean) {
  muted = next
  if (muted && ctx && ctx.state === "running") void ctx.suspend()
  if (!muted && ctx && ctx.state === "suspended") void ctx.resume()
}

export function unlockAudio() {
  if (typeof window === "undefined") return
  if (!ctx) ctx = new AudioContext()
  if (!muted && ctx.state === "suspended") void ctx.resume()
}

function beep(freq: number, dur: number, gain: number, type: OscillatorType, slide = 0) {
  if (!ctx || muted || ctx.state !== "running") return
  const t = ctx.currentTime
  const o = ctx.createOscillator()
  const g = ctx.createGain()
  o.type = type
  o.frequency.setValueAtTime(Math.max(40, freq), t)
  const endFreq = Math.max(40, freq + slide)
  o.frequency.exponentialRampToValueAtTime(endFreq, t + dur)
  g.gain.setValueAtTime(gain, t)
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
  o.connect(g)
  g.connect(ctx.destination)
  o.start(t)
  o.stop(t + dur + 0.02)
}

export function playFling(speed: number) {
  const s = Math.min(1, speed / 700)
  beep(160 + s * 240, 0.11, 0.025 + s * 0.02, "sine", -70)
}

export function playHit(speed: number) {
  if (!ctx || muted || ctx.state !== "running") return
  const t = ctx.currentTime
  if (t - lastHit < 0.05) return
  lastHit = t
  const s = Math.min(1, speed / 450)
  beep(78 + s * 50, 0.08, 0.022 + s * 0.028, "triangle", -36)
}

export function playMerge() {
  beep(64, 0.2, 0.04, "sine", -28)
}
