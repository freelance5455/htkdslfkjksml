// Symplectic N-body playground. Velocity Verlet + Plummer softening stays
// stable for orbits; collisions are resolved outside the force law so a
// close pass can slingshot instead of exploding.

export const G = 400
export const SOFT = 6
export const AIM_SECONDS = 1
export const MAX_BODIES = 40
export const TRAIL_CAP = 280
const STEP = 1 / 240
const MAX_STEPS = 28
const SLOP = 0.75
const ESCAPE2 = 16000 * 16000
const SPEED_CULL2 = 7000 * 7000

export type PresetId = "dust" | "moon" | "planet" | "giant" | "star" | "hole"
export type Kind = "rock" | "gas" | "star" | "hole"
export type CollisionMode = "bounce" | "merge"

export type Preset = {
  id: PresetId
  label: string
  mass: number
  kind: Kind
  color: string
  core: string
}

export const PRESET_LIST: readonly Preset[] = [
  { id: "dust", label: "Dust", mass: 2.5, kind: "rock", color: "#a8aeb6", core: "#eef1f3" },
  { id: "moon", label: "Moon", mass: 26, kind: "rock", color: "#c4bbb0", core: "#f4f0ea" },
  { id: "planet", label: "Planet", mass: 150, kind: "rock", color: "#6f8f86", core: "#e7f1ed" },
  { id: "giant", label: "Giant", mass: 820, kind: "gas", color: "#8496aa", core: "#e8eef4" },
  { id: "star", label: "Star", mass: 7000, kind: "star", color: "#f7f4ee", core: "#ffffff" },
  { id: "hole", label: "Hole", mass: 26000, kind: "hole", color: "#050506", core: "#14161c" },
]

const PRESET_MAP = Object.fromEntries(PRESET_LIST.map((p) => [p.id, p])) as Record<PresetId, Preset>

export function getPreset(id: PresetId): Preset {
  return PRESET_MAP[id]
}

export type ScenarioId = "star" | "binary" | "eight" | "sling" | "system" | "swarm"

export const SCENARIOS: readonly { id: ScenarioId; label: string }[] = [
  { id: "star", label: "1 star" },
  { id: "binary", label: "Binary" },
  { id: "eight", label: "Figure 8" },
  { id: "sling", label: "Slingshot" },
  { id: "system", label: "System" },
  { id: "swarm", label: "Swarm" },
]

export type Body = {
  id: number
  preset: PresetId
  kind: Kind
  x: number
  y: number
  vx: number
  vy: number
  ax: number
  ay: number
  mass: number
  radius: number
  color: string
  core: string
  trail: Float32Array
  trailWrite: number
  trailFill: number
}

export type SimEvent = {
  type: "bounce" | "merge"
  x: number
  y: number
  speed: number
}

export type Sim = {
  bodies: Body[]
  g: number
  nextId: number
  time: number
  mode: CollisionMode
  trails: boolean
  emit: boolean
  events: SimEvent[]
  minSep: number
  maxSpeed: number
  acc: number
  step: number
}

export type Ghost = {
  id: number | null
  x: number
  y: number
  vx: number
  vy: number
  preset: PresetId
}

export function clamp(n: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, n))
}

export function radiusFromMass(mass: number, kind: Kind): number {
  const density = kind === "hole" ? 12 : kind === "star" ? 0.62 : kind === "gas" ? 0.05 : 0.058
  const r = Math.cbrt(Math.max(mass, 0.001) / density)
  const lo = kind === "hole" ? 10 : kind === "star" ? 16 : kind === "gas" ? 14 : 2.6
  const hi = kind === "hole" ? 22 : kind === "star" ? 38 : kind === "gas" ? 54 : 36
  return clamp(r, lo, hi)
}

function emptySim(): Sim {
  return {
    bodies: [],
    g: G,
    nextId: 1,
    time: 0,
    mode: "bounce",
    trails: true,
    emit: true,
    events: [],
    minSep: Infinity,
    maxSpeed: 0,
    acc: 0,
    step: 0,
  }
}

function bodyFrom(
  id: number,
  presetId: PresetId,
  x: number,
  y: number,
  vx: number,
  vy: number,
  overrides?: { mass?: number; radius?: number },
): Body {
  const p = PRESET_MAP[presetId]
  const mass = overrides?.mass ?? p.mass
  const radius = overrides?.radius ?? radiusFromMass(mass, p.kind)
  return {
    id,
    preset: presetId,
    kind: p.kind,
    x,
    y,
    vx,
    vy,
    ax: 0,
    ay: 0,
    mass,
    radius,
    color: p.color,
    core: p.core,
    trail: new Float32Array(TRAIL_CAP * 2),
    trailWrite: 0,
    trailFill: 0,
  }
}

function take(sim: Sim, preset: PresetId, x: number, y: number, vx: number, vy: number, overrides?: { mass?: number; radius?: number }): Body {
  return bodyFrom(sim.nextId++, preset, x, y, vx, vy, overrides)
}

function balance(bodies: Body[]) {
  let m = 0
  let cx = 0
  let cy = 0
  let px = 0
  let py = 0
  for (const b of bodies) {
    m += b.mass
    cx += b.mass * b.x
    cy += b.mass * b.y
    px += b.mass * b.vx
    py += b.mass * b.vy
  }
  if (m <= 0) return
  cx /= m
  cy /= m
  px /= m
  py /= m
  for (const b of bodies) {
    b.x -= cx
    b.y -= cy
    b.vx -= px
    b.vy -= py
  }
}

function mulberry32(seed: number) {
  let s = seed >>> 0
  return () => {
    s = (s + 0x6d2b79f5) | 0
    let t = Math.imul(s ^ (s >>> 15), 1 | s)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// Chenciner–Montgomery figure-eight, time-reversed IC (G = 1, m = 1).
// Length-scaled into the sandbox so the same periodic orbit reads on screen.
const FIG8_PERIOD_UNITS = 6.32591398
const FIG8_S = 220
const FIG8_M = 2200

export function figureEightPeriod(g = G): number {
  const tScale = Math.sqrt((FIG8_S * FIG8_S * FIG8_S) / (g * FIG8_M))
  return FIG8_PERIOD_UNITS * tScale
}

function buildScenario(sim: Sim, id: ScenarioId): Body[] {
  if (id === "star") {
    return [take(sim, "star", 0, 0, 0, 0)]
  }

  if (id === "binary") {
    const m = 4600
    const d = 300
    const v = Math.sqrt((G * m) / (2 * d))
    const bodies = [
      take(sim, "star", -d / 2, 0, 0, -v, { mass: m, radius: 20 }),
      take(sim, "star", d / 2, 0, 0, v, { mass: m, radius: 20 }),
    ]
    balance(bodies)
    return bodies
  }

  if (id === "eight") {
    const tScale = Math.sqrt((FIG8_S * FIG8_S * FIG8_S) / (G * FIG8_M))
    const vScale = FIG8_S / tScale
    const raw: Array<[number, number, number, number]> = [
      [0.97000436, -0.24308753, 0.466203685, 0.43236573],
      [-0.97000436, 0.24308753, 0.466203685, 0.43236573],
      [0, 0, -0.93240737, -0.86473146],
    ]
    const bodies = raw.map(([x, y, vx, vy]) =>
      take(sim, "planet", x * FIG8_S, y * FIG8_S, vx * vScale, vy * vScale, {
        mass: FIG8_M,
        radius: 7,
      }),
    )
    balance(bodies)
    return bodies
  }

  if (id === "sling") {
    const starMass = 14000
    const star = take(sim, "star", 0, 0, 0, 0, { mass: starMass })
    const comet = take(sim, "moon", -720, 96, 188, 6, { mass: 14, radius: 6 })
    const bodies = [star, comet]
    balance(bodies)
    return bodies
  }

  if (id === "swarm") {
    const rng = mulberry32(42)
    const starMass = 9000
    const bodies = [take(sim, "star", 0, 0, 0, 0, { mass: starMass })]
    for (let i = 0; i < 8; i++) {
      const ang = rng() * Math.PI * 2
      const r = 160 + rng() * 360
      const mass = 6 + rng() * 40
      const preset: PresetId = mass < 14 ? "dust" : "moon"
      const v = Math.sqrt((G * (starMass + mass)) / r) * (0.88 + rng() * 0.2)
      bodies.push(
        take(sim, preset, Math.cos(ang) * r, Math.sin(ang) * r, -Math.sin(ang) * v, Math.cos(ang) * v, {
          mass,
        }),
      )
    }
    balance(bodies)
    return bodies
  }

  // system — wide, nested orbits. Spacing stays outside each Hill sphere so the
  // dance holds until the player flings something through it.
  const starMass = 11000
  const star = take(sim, "star", 0, 0, 0, 0, { mass: starMass })
  const bodies = [star]
  const planets: Array<{ preset: PresetId; mass: number; r: number; ang: number }> = [
    { preset: "planet", mass: 42, r: 150, ang: 0.4 },
    { preset: "planet", mass: 68, r: 290, ang: 2.5 },
    { preset: "giant", mass: 210, r: 620, ang: 4.5 },
  ]
  for (const spec of planets) {
    const v = Math.sqrt((G * (starMass + spec.mass)) / spec.r)
    const x = Math.cos(spec.ang) * spec.r
    const y = Math.sin(spec.ang) * spec.r
    bodies.push(take(sim, spec.preset, x, y, -Math.sin(spec.ang) * v, Math.cos(spec.ang) * v, { mass: spec.mass }))
  }
  balance(bodies)
  return bodies
}

export function loadScenario(sim: Sim, id: ScenarioId) {
  sim.bodies = buildScenario(sim, id)
  sim.time = 0
  sim.acc = 0
  sim.step = 0
  sim.events.length = 0
  sim.minSep = Infinity
  sim.maxSpeed = 0
  computeAccel(sim)
}

export function createSim(): Sim {
  const sim = emptySim()
  loadScenario(sim, "system")
  sim.emit = false
  for (let i = 0; i < 100; i++) advanceSim(sim, 1 / 60, 1)
  sim.emit = true
  sim.events.length = 0
  return sim
}

export function clearBodies(sim: Sim) {
  sim.bodies.length = 0
  sim.time = 0
  sim.acc = 0
  sim.step = 0
  sim.events.length = 0
  sim.minSep = Infinity
  sim.maxSpeed = 0
}

export function addBody(
  sim: Sim,
  preset: PresetId,
  x: number,
  y: number,
  vx: number,
  vy: number,
): Body | null {
  if (sim.bodies.length >= MAX_BODIES) return null
  const speed = Math.hypot(vx, vy)
  if (speed > 1400) {
    const s = 1400 / speed
    vx *= s
    vy *= s
  }
  const b = take(sim, preset, x, y, vx, vy)
  sim.bodies.push(b)
  computeAccel(sim)
  return b
}

export function removeBody(sim: Sim, id: number) {
  const i = sim.bodies.findIndex((b) => b.id === id)
  if (i >= 0) sim.bodies.splice(i, 1)
  computeAccel(sim)
}

export function setBodyVelocity(sim: Sim, id: number, vx: number, vy: number) {
  const b = sim.bodies.find((body) => body.id === id)
  if (!b) return
  const speed = Math.hypot(vx, vy)
  if (speed > 1400) {
    const s = 1400 / speed
    vx *= s
    vy *= s
  }
  b.vx = vx
  b.vy = vy
  let max = 0
  for (const body of sim.bodies) {
    const sp = body.vx * body.vx + body.vy * body.vy
    if (sp > max) max = sp
  }
  sim.maxSpeed = Math.sqrt(max)
}

export function computeAccel(sim: Sim) {
  const bodies = sim.bodies
  const n = bodies.length
  let minSep = Infinity
  let maxSpeed2 = 0
  for (let i = 0; i < n; i++) {
    const b = bodies[i]
    b.ax = 0
    b.ay = 0
    const sp = b.vx * b.vx + b.vy * b.vy
    if (sp > maxSpeed2) maxSpeed2 = sp
  }
  sim.maxSpeed = Math.sqrt(maxSpeed2)
  const g = sim.g
  const soft2 = SOFT * SOFT
  for (let i = 0; i < n; i++) {
    const a = bodies[i]
    for (let j = i + 1; j < n; j++) {
      const b = bodies[j]
      const dx = b.x - a.x
      const dy = b.y - a.y
      const d2 = dx * dx + dy * dy
      const dist = Math.sqrt(d2)
      if (dist < minSep) minSep = dist
      const inv = 1 / Math.sqrt(d2 + soft2)
      const inv3 = inv * inv * inv
      const s = g * inv3
      const sax = s * b.mass * dx
      const say = s * b.mass * dy
      a.ax += sax
      a.ay += say
      b.ax -= s * a.mass * dx
      b.ay -= s * a.mass * dy
    }
  }
  sim.minSep = minSep
}

function chooseSub(sim: Sim, step: number): number {
  let n = 1
  const speedStep = sim.maxSpeed * step
  if (speedStep > 5) n = Math.ceil(speedStep / 5)
  const bodies = sim.bodies
  for (let i = 0; i < bodies.length; i++) {
    const a = bodies[i]
    for (let j = i + 1; j < bodies.length; j++) {
      const b = bodies[j]
      const dx = b.x - a.x
      const dy = b.y - a.y
      const dist2 = dx * dx + dy * dy
      if (dist2 > 200 * 200) continue
      const dist = Math.sqrt(dist2) || 0.001
      const dvx = b.vx - a.vx
      const dvy = b.vy - a.vy
      const closing = -((dx * dvx + dy * dvy) / dist)
      const rel = Math.hypot(dvx, dvy)
      const budget = Math.max(2.4, dist * 0.1)
      const need = Math.ceil((Math.max(closing, rel * 0.35) * step) / budget)
      if (need > n) n = need
    }
  }
  return clamp(n, 1, 8)
}

function cull(sim: Sim) {
  const bodies = sim.bodies
  let w = 0
  for (let i = 0; i < bodies.length; i++) {
    const b = bodies[i]
    const ok =
      Number.isFinite(b.x) &&
      Number.isFinite(b.y) &&
      Number.isFinite(b.vx) &&
      Number.isFinite(b.vy) &&
      b.x * b.x + b.y * b.y < ESCAPE2 &&
      b.vx * b.vx + b.vy * b.vy < SPEED_CULL2
    if (ok) bodies[w++] = b
  }
  bodies.length = w
}

function mergePair(sim: Sim, i: number, j: number) {
  const bodies = sim.bodies
  const a = bodies[i]
  const b = bodies[j]
  const big = a.mass >= b.mass ? a : b
  const small = big === a ? b : a
  const mass = a.mass + b.mass
  const rel = Math.hypot(a.vx - b.vx, a.vy - b.vy)
  big.x = (a.x * a.mass + b.x * b.mass) / mass
  big.y = (a.y * a.mass + b.y * b.mass) / mass
  big.vx = (a.vx * a.mass + b.vx * b.mass) / mass
  big.vy = (a.vy * a.mass + b.vy * b.mass) / mass
  const prevKind = big.kind
  const otherKind = small.kind
  let kind: Kind = prevKind
  if (prevKind === "hole" || otherKind === "hole" || mass >= 18000) kind = "hole"
  else if (prevKind === "star" || otherKind === "star" || mass >= 3600) kind = "star"
  else if (prevKind === "gas" || otherKind === "gas" || mass >= 520) kind = "gas"
  else kind = "rock"
  if (kind !== prevKind) {
    const id: PresetId = kind === "hole" ? "hole" : kind === "star" ? "star" : kind === "gas" ? "giant" : "planet"
    const p = PRESET_MAP[id]
    big.preset = id
    big.color = p.color
    big.core = p.core
  }
  big.kind = kind
  big.mass = mass
  big.radius = radiusFromMass(mass, kind)
  const idx = bodies.indexOf(small)
  if (idx >= 0) bodies.splice(idx, 1)
  if (sim.emit && rel > 18) sim.events.push({ type: "merge", x: big.x, y: big.y, speed: rel })
}

function bouncePair(sim: Sim, a: Body, b: Body) {
  let dx = b.x - a.x
  let dy = b.y - a.y
  let dist = Math.hypot(dx, dy)
  if (dist < 1e-6) {
    dx = 1
    dy = 0
    dist = 1
  }
  const pen = a.radius + b.radius - dist
  const nx = dx / dist
  const ny = dy / dist
  const invA = 1 / a.mass
  const invB = 1 / b.mass
  const inv = invA + invB
  const corrMag = ((pen - SLOP) / inv) * 1
  if (corrMag > 0) {
    a.x -= nx * corrMag * invA
    a.y -= ny * corrMag * invA
    b.x += nx * corrMag * invB
    b.y += ny * corrMag * invB
  }
  const rvn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny
  if (rvn >= 0) return
  const impact = -rvn
  const e = impact < 36 ? 0.25 : 0.86
  const j = ((1 + e) * impact) / inv
  a.vx -= j * nx * invA
  a.vy -= j * ny * invA
  b.vx += j * nx * invB
  b.vy += j * ny * invB
  if (sim.emit && impact > 26) {
    sim.events.push({ type: "bounce", x: (a.x + b.x) * 0.5, y: (a.y + b.y) * 0.5, speed: impact })
  }
}

function resolveCollisions(sim: Sim) {
  const bodies = sim.bodies
  const merging = sim.mode === "merge"
  const iterations = merging ? 3 : 5
  for (let iter = 0; iter < iterations; iter++) {
    let bi = -1
    let bj = -1
    let best = SLOP
    for (let i = 0; i < bodies.length; i++) {
      const a = bodies[i]
      for (let j = i + 1; j < bodies.length; j++) {
        const b = bodies[j]
        const dx = b.x - a.x
        const dy = b.y - a.y
        const dist = Math.hypot(dx, dy) || 0.0001
        const pen = a.radius + b.radius - dist
        if (pen > best) {
          best = pen
          bi = i
          bj = j
        }
      }
    }
    if (bi < 0) return
    if (merging) mergePair(sim, bi, bj)
    else bouncePair(sim, bodies[bi], bodies[bj])
  }
}

function stepSim(sim: Sim, h: number) {
  const bodies = sim.bodies
  for (let i = 0; i < bodies.length; i++) {
    const b = bodies[i]
    b.vx += b.ax * h * 0.5
    b.vy += b.ay * h * 0.5
    b.x += b.vx * h
    b.y += b.vy * h
  }
  resolveCollisions(sim)
  computeAccel(sim)
  const live = sim.bodies
  for (let i = 0; i < live.length; i++) {
    const b = live[i]
    b.vx += b.ax * h * 0.5
    b.vy += b.ay * h * 0.5
  }
  cull(sim)
  sim.time += h
}

function recordTrails(sim: Sim) {
  if (!sim.trails) return
  const cap = TRAIL_CAP
  for (const b of sim.bodies) {
    if (b.trail.length < cap * 2) continue
    const w = b.trailWrite
    b.trail[w * 2] = b.x
    b.trail[w * 2 + 1] = b.y
    b.trailWrite = (w + 1) % cap
    if (b.trailFill < cap) b.trailFill++
  }
}

export function advanceSim(sim: Sim, frameDt: number, timeScale: number) {
  sim.acc += Math.min(Math.max(frameDt, 0), 0.05) * Math.max(0, timeScale)
  let n = 0
  while (sim.acc >= STEP && n < MAX_STEPS) {
    const sub = chooseSub(sim, STEP)
    const h = STEP / sub
    for (let i = 0; i < sub; i++) stepSim(sim, h)
    sim.step += 1
    if ((sim.step & 1) === 0) recordTrails(sim)
    sim.acc -= STEP
    n += 1
  }
  if (n >= MAX_STEPS) sim.acc = 0
}

export function energyOf(sim: Sim): number {
  const bodies = sim.bodies
  let e = 0
  const soft2 = SOFT * SOFT
  for (let i = 0; i < bodies.length; i++) {
    const a = bodies[i]
    e += 0.5 * a.mass * (a.vx * a.vx + a.vy * a.vy)
    for (let j = i + 1; j < bodies.length; j++) {
      const b = bodies[j]
      const dx = b.x - a.x
      const dy = b.y - a.y
      const dist = Math.sqrt(dx * dx + dy * dy + soft2)
      e -= (sim.g * a.mass * b.mass) / dist
    }
  }
  return e
}

export function forecast(sim: Sim, ghost: Ghost, seconds = 2): number[] {
  const bodies = sim.bodies.map((b) => ({
    ...b,
    trail: b.trail,
    ax: 0,
    ay: 0,
  }))
  let subjectId: number
  if (ghost.id == null) {
    const born = bodyFrom(-1, ghost.preset, ghost.x, ghost.y, ghost.vx, ghost.vy)
    bodies.push(born)
    subjectId = -1
  } else {
    const found = bodies.find((b) => b.id === ghost.id)
    if (!found) return []
    found.vx = ghost.vx
    found.vy = ghost.vy
    subjectId = ghost.id
  }
  const crowded = bodies.length > 18
  const horizon = crowded ? 1.15 : seconds
  const clone: Sim = {
    ...sim,
    bodies,
    events: [],
    emit: false,
    trails: false,
    acc: 0,
    minSep: Infinity,
    maxSpeed: 0,
  }
  computeAccel(clone)
  const subject = clone.bodies.find((b) => b.id === subjectId)
  if (!subject) return []
  const path = [subject.x, subject.y]
  const slices = crowded ? 14 : 26
  const slice = horizon / slices
  for (let s = 0; s < slices; s++) {
    let left = slice
    while (left > 1e-8) {
      const chunk = Math.min(0.05, left)
      advanceSim(clone, chunk, 1)
      left -= chunk
    }
    const b = clone.bodies.find((body) => body.id === subjectId)
    if (!b) break
    path.push(b.x, b.y)
  }
  return path
}

export function frameOf(bodies: Body[], w: number, h: number): { x: number; y: number; zoom: number } {
  if (bodies.length === 0) return { x: 0, y: 0, zoom: 1 }
  if (bodies.length === 1) return { x: bodies[0].x, y: bodies[0].y, zoom: 1 }
  let minX = Infinity
  let maxX = -Infinity
  let minY = Infinity
  let maxY = -Infinity
  for (const b of bodies) {
    minX = Math.min(minX, b.x - b.radius)
    maxX = Math.max(maxX, b.x + b.radius)
    minY = Math.min(minY, b.y - b.radius)
    maxY = Math.max(maxY, b.y + b.radius)
  }
  const bw = Math.max(120, maxX - minX)
  const bh = Math.max(120, maxY - minY)
  const zoom = clamp(Math.min((w - 72) / bw, (h - 200) / bh), 0.22, 2.2)
  return { x: (minX + maxX) / 2, y: (minY + maxY) / 2, zoom }
}

export function formatSimTime(t: number): string {
  const clamped = Math.max(0, t)
  const m = Math.floor(clamped / 60)
  const s = clamped - m * 60
  const whole = Math.floor(s)
  const frac = Math.floor((s - whole) * 10)
  return `${m}:${whole.toString().padStart(2, "0")}.${frac}`
}
