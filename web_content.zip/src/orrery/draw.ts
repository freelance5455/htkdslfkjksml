import { TRAIL_CAP, type Body, type PresetId, type Sim } from "./sim"

export type StarDot = { u: number; v: number; r: number; a: number; phase: number }

export type View = {
  w: number
  h: number
  camX: number
  camY: number
  zoom: number
  shakeX: number
  shakeY: number
  reduce: boolean
  trails: boolean
}

export type Spark = { x: number; y: number; life: number; max: number; r: number }

export type DragDraw = {
  kind: "new" | "body"
  x0: number
  y0: number
  x1: number
  y1: number
  color: string
  core: string
  radius: number
  moved: boolean
  speed: number
}

export function createStarfield(count: number, seed: number): StarDot[] {
  let s = seed >>> 0
  const rnd = () => {
    s = (s + 0x6d2b79f5) | 0
    let t = Math.imul(s ^ (s >>> 15), 1 | s)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
  const stars: StarDot[] = []
  for (let i = 0; i < count; i++) {
    stars.push({
      u: rnd(),
      v: rnd(),
      r: rnd() < 0.92 ? 0.6 : 1.3,
      a: 0.18 + rnd() * 0.45,
      phase: rnd() * Math.PI * 2,
    })
  }
  return stars
}

function darken(hex: string): string {
  const n = Number.parseInt(hex.slice(1), 16)
  const r = Math.round(((n >> 16) & 255) * 0.38)
  const g = Math.round(((n >> 8) & 255) * 0.38)
  const b = Math.round((n & 255) * 0.38)
  return `rgb(${r} ${g} ${b})`
}

function worldToScreen(x: number, y: number, view: View) {
  return {
    x: (x - view.camX) * view.zoom + view.w / 2 + view.shakeX,
    y: (y - view.camY) * view.zoom + view.h / 2 + view.shakeY,
  }
}

function drawTrail(ctx: CanvasRenderingContext2D, body: Body, view: View, frac: number, alpha: number, width: number) {
  const count = Math.max(2, Math.floor(body.trailFill * frac))
  if (body.trailFill < 2 || count < 2) return
  const start = (body.trailWrite - body.trailFill + TRAIL_CAP) % TRAIL_CAP
  const from = body.trailFill - count
  ctx.beginPath()
  let started = false
  for (let i = from; i < body.trailFill; i++) {
    const idx = (start + i) % TRAIL_CAP
    const p = worldToScreen(body.trail[idx * 2], body.trail[idx * 2 + 1], view)
    if (!started) {
      ctx.moveTo(p.x, p.y)
      started = true
    } else ctx.lineTo(p.x, p.y)
  }
  ctx.strokeStyle = hexAlpha(body.color, alpha)
  ctx.lineWidth = width
  ctx.stroke()
}

function hexAlpha(hex: string, alpha: number): string {
  const n = Number.parseInt(hex.slice(1), 16)
  const r = (n >> 16) & 255
  const g = (n >> 8) & 255
  const b = n & 255
  return `rgba(${r}, ${g}, ${b}, ${alpha})`
}

function drawBody(ctx: CanvasRenderingContext2D, body: Body, view: View, time: number) {
  const p = worldToScreen(body.x, body.y, view)
  const r = Math.max(1.5, body.radius * view.zoom)
  if (p.x < -r * 6 || p.y < -r * 6 || p.x > view.w + r * 6 || p.y > view.h + r * 6) return

  if (body.kind === "hole") {
    const lens = ctx.createRadialGradient(p.x, p.y, r, p.x, p.y, r * 5.2)
    lens.addColorStop(0, "rgba(0, 0, 0, 0)")
    lens.addColorStop(0.45, "rgba(210, 216, 224, 0.06)")
    lens.addColorStop(1, "rgba(0, 0, 0, 0)")
    ctx.fillStyle = lens
    ctx.beginPath()
    ctx.arc(p.x, p.y, r * 5.2, 0, Math.PI * 2)
    ctx.fill()

    ctx.save()
    ctx.translate(p.x, p.y)
    ctx.rotate(view.reduce ? 0.4 : time * 0.35 + body.id)
    ctx.scale(1, 0.36)
    ctx.beginPath()
    ctx.arc(0, 0, r * 2.35, 0, Math.PI * 2)
    ctx.strokeStyle = "rgba(214, 220, 228, 0.5)"
    ctx.lineWidth = 1.6
    ctx.stroke()
    ctx.restore()

    ctx.beginPath()
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2)
    ctx.fillStyle = "#050506"
    ctx.fill()
    ctx.lineWidth = 1
    ctx.strokeStyle = "rgba(244, 244, 245, 0.72)"
    ctx.stroke()
    return
  }

  if (body.kind === "star") {
    const pulse = view.reduce ? 0.42 : 0.34 + 0.08 * Math.sin(time * 1.5 + body.id)
    const glow = ctx.createRadialGradient(p.x, p.y, r * 0.2, p.x, p.y, r * 3.6)
    glow.addColorStop(0, `rgba(255, 252, 246, ${0.22 + pulse * 0.35})`)
    glow.addColorStop(0.4, "rgba(247, 244, 238, 0.08)")
    glow.addColorStop(1, "rgba(247, 244, 238, 0)")
    ctx.fillStyle = glow
    ctx.beginPath()
    ctx.arc(p.x, p.y, r * 3.6, 0, Math.PI * 2)
    ctx.fill()
  }

  if (body.kind === "gas") {
    ctx.save()
    ctx.translate(p.x, p.y)
    ctx.rotate(-0.45)
    ctx.scale(1, 0.34)
    ctx.beginPath()
    ctx.arc(0, 0, r * 1.72, 0, Math.PI * 2)
    ctx.strokeStyle = "rgba(232, 236, 241, 0.38)"
    ctx.lineWidth = Math.max(1, r * 0.06)
    ctx.stroke()
    ctx.restore()
  }

  const g = ctx.createRadialGradient(p.x - r * 0.34, p.y - r * 0.38, r * 0.08, p.x + r * 0.1, p.y + r * 0.15, r)
  g.addColorStop(0, body.core)
  g.addColorStop(0.5, body.color)
  g.addColorStop(1, darken(body.color))
  ctx.beginPath()
  ctx.arc(p.x, p.y, r, 0, Math.PI * 2)
  ctx.fillStyle = g
  ctx.fill()

  if (body.kind === "gas") {
    ctx.save()
    ctx.beginPath()
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2)
    ctx.clip()
    ctx.fillStyle = "rgba(8, 10, 14, 0.2)"
    for (let i = -1; i <= 1; i++) {
      ctx.fillRect(p.x - r, p.y + i * r * 0.42 - r * 0.07, r * 2, Math.max(1, r * 0.1))
    }
    ctx.restore()
  }
}

function drawArrow(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number) {
  const ang = Math.atan2(y1 - y0, x1 - x0)
  ctx.beginPath()
  ctx.moveTo(x0, y0)
  ctx.lineTo(x1, y1)
  const head = 9
  ctx.moveTo(x1, y1)
  ctx.lineTo(x1 - head * Math.cos(ang - 0.45), y1 - head * Math.sin(ang - 0.45))
  ctx.moveTo(x1, y1)
  ctx.lineTo(x1 - head * Math.cos(ang + 0.45), y1 - head * Math.sin(ang + 0.45))
  ctx.stroke()
}

export function renderScene(
  ctx: CanvasRenderingContext2D,
  sim: Sim,
  view: View,
  extras: {
    stars: StarDot[]
    path: number[] | null
    drag: DragDraw | null
    selectedId: number | null
    sparks: Spark[]
    dpr: number
  },
) {
  const { dpr } = extras
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
  ctx.clearRect(0, 0, view.w, view.h)
  ctx.fillStyle = "#0a0a0b"
  ctx.fillRect(0, 0, view.w, view.h)

  ctx.fillStyle = "#d5d8de"
  for (const star of extras.stars) {
    const twinkle = view.reduce ? star.a : star.a * (0.75 + 0.25 * Math.sin(sim.time * 1.3 + star.phase))
    ctx.globalAlpha = twinkle
    ctx.beginPath()
    ctx.arc(star.u * view.w, star.v * view.h, star.r, 0, Math.PI * 2)
    ctx.fill()
  }
  ctx.globalAlpha = 1

  const vignette = ctx.createRadialGradient(
    view.w / 2,
    view.h / 2,
    Math.min(view.w, view.h) * 0.35,
    view.w / 2,
    view.h / 2,
    Math.max(view.w, view.h) * 0.72,
  )
  vignette.addColorStop(0, "rgba(0, 0, 0, 0)")
  vignette.addColorStop(1, "rgba(0, 0, 0, 0.38)")
  ctx.fillStyle = vignette
  ctx.fillRect(0, 0, view.w, view.h)

  if (view.trails) {
    ctx.lineCap = "round"
    ctx.lineJoin = "round"
    for (const body of sim.bodies) {
      const width = Math.max(1, Math.min(2.6, body.radius * view.zoom * 0.14))
      drawTrail(ctx, body, view, 1, body.kind === "hole" ? 0.14 : 0.18, width)
      drawTrail(ctx, body, view, 0.28, body.kind === "hole" ? 0.35 : 0.55, width)
    }
  }

  if (extras.path && extras.path.length >= 4) {
    ctx.save()
    ctx.setLineDash([2, 7])
    ctx.lineWidth = 1
    ctx.strokeStyle = "rgba(244, 244, 245, 0.45)"
    ctx.beginPath()
    const p0 = worldToScreen(extras.path[0], extras.path[1], view)
    ctx.moveTo(p0.x, p0.y)
    for (let i = 2; i < extras.path.length; i += 2) {
      const p = worldToScreen(extras.path[i], extras.path[i + 1], view)
      ctx.lineTo(p.x, p.y)
    }
    ctx.stroke()
    ctx.restore()
  }

  for (const body of sim.bodies) drawBody(ctx, body, view, sim.time)

  if (extras.selectedId != null) {
    const body = sim.bodies.find((b) => b.id === extras.selectedId)
    if (body) {
      const p = worldToScreen(body.x, body.y, view)
      const r = Math.max(1.5, body.radius * view.zoom)
      ctx.beginPath()
      ctx.arc(p.x, p.y, r + 5, 0, Math.PI * 2)
      ctx.strokeStyle = "rgba(244, 244, 245, 0.8)"
      ctx.lineWidth = 1
      ctx.stroke()
    }
  }

  ctx.fillStyle = "#f4f4f5"
  for (const spark of extras.sparks) {
    const p = worldToScreen(spark.x, spark.y, view)
    ctx.globalAlpha = Math.max(0, spark.life / spark.max) * 0.85
    ctx.beginPath()
    ctx.arc(p.x, p.y, spark.r, 0, Math.PI * 2)
    ctx.fill()
  }
  ctx.globalAlpha = 1

  if (sim.bodies.length >= 2) {
    let m = 0
    let cx = 0
    let cy = 0
    for (const b of sim.bodies) {
      m += b.mass
      cx += b.mass * b.x
      cy += b.mass * b.y
    }
    if (m > 0) {
      const p = worldToScreen(cx / m, cy / m, view)
      ctx.strokeStyle = "rgba(244, 244, 245, 0.35)"
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.moveTo(p.x - 5, p.y)
      ctx.lineTo(p.x + 5, p.y)
      ctx.moveTo(p.x, p.y - 5)
      ctx.lineTo(p.x, p.y + 5)
      ctx.stroke()
    }
  }

  const drag = extras.drag
  if (!drag) return

  const a = worldToScreen(drag.x0, drag.y0, view)
  const b = worldToScreen(drag.x1, drag.y1, view)
  if (drag.kind === "new") {
    const r = Math.max(1.5, drag.radius * view.zoom)
    ctx.beginPath()
    ctx.arc(a.x, a.y, r, 0, Math.PI * 2)
    ctx.fillStyle = hexAlpha(drag.color, 0.35)
    ctx.fill()
    ctx.strokeStyle = "rgba(244, 244, 245, 0.7)"
    ctx.lineWidth = 1
    ctx.setLineDash([3, 4])
    ctx.stroke()
    ctx.setLineDash([])
  }
  if (!drag.moved) return
  ctx.strokeStyle = "rgba(244, 244, 245, 0.85)"
  ctx.lineWidth = 1.25
  drawArrow(ctx, a.x, a.y, b.x, b.y)
  ctx.font = "12px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace"
  ctx.fillStyle = "rgba(244, 244, 245, 0.86)"
  ctx.fillText(`${Math.round(drag.speed)}/s`, b.x + 10, b.y - 8)
}

export type { PresetId }
