import { useCallback, useEffect, useRef, useState } from "react"
import { clsx } from "clsx"
import { Hand, LocateFixed, Minus, Pause, Play, Plus, Volume2, VolumeX } from "lucide-react"
import { playFling, playHit, playMerge, setMuted, unlockAudio } from "./audio"
import { createStarfield, renderScene, type DragDraw, type Spark, type StarDot } from "./draw"
import {
  AIM_SECONDS,
  MAX_BODIES,
  PRESET_LIST,
  SCENARIOS,
  addBody,
  advanceSim,
  clearBodies,
  clamp,
  createSim,
  energyOf,
  forecast,
  formatSimTime,
  frameOf,
  getPreset,
  loadScenario,
  radiusFromMass,
  removeBody,
  setBodyVelocity,
  type Body,
  type CollisionMode,
  type PresetId,
  type ScenarioId,
  type Sim,
} from "./sim"

type Tool = "throw" | "pan"
type Drag =
  | { type: "pan"; lastX: number; lastY: number }
  | {
      type: "new" | "body"
      id: number | null
      x0: number
      y0: number
      x: number
      y: number
      sx0: number
      sy0: number
      moved: boolean
    }

type Pinch = { dist0: number; zoom0: number }

type Stats = {
  count: number
  time: string
  speed: string
  label: string
}

const ZOOM_MIN = 0.22
const ZOOM_MAX = 3.5
const SETTINGS_KEY = "orrery-settings-v1"

const iconBtn =
  "inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-md border border-fg/15 bg-elevated text-fg transition-colors duration-150 ease-out hover:bg-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40 disabled:opacity-40"
const textBtn =
  "inline-flex h-11 shrink-0 items-center justify-center rounded-md border border-fg/15 bg-elevated px-3 text-sm font-medium text-fg transition-colors duration-150 ease-out hover:bg-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40 disabled:opacity-40"

function screenToWorld(sx: number, sy: number, camX: number, camY: number, zoom: number, w: number, h: number) {
  return {
    x: (sx - w / 2) / zoom + camX,
    y: (sy - h / 2) / zoom + camY,
  }
}

function pickBody(bodies: Body[], x: number, y: number, zoom: number): Body | null {
  for (let i = bodies.length - 1; i >= 0; i--) {
    const b = bodies[i]
    const reach = Math.max(b.radius, 22 / zoom)
    if (Math.hypot(b.x - x, b.y - y) <= reach) return b
  }
  return null
}

function limitVelocity(vx: number, vy: number) {
  const speed = Math.hypot(vx, vy)
  if (speed <= 1400) return { vx, vy, speed }
  const s = 1400 / speed
  return { vx: vx * s, vy: vy * s, speed: 1400 }
}

declare global {
  interface Window {
    __orrery?: {
      ready: boolean
      count: () => number
      time: () => number
      energy: () => number
      bodies: () => Array<{ id: number; preset: PresetId; x: number; y: number; vx: number; vy: number; mass: number; r: number }>
      load: (id: ScenarioId) => void
      fling: (preset: PresetId, x: number, y: number, vx: number, vy: number) => number | null
    }
  }
}

export function Orrery() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const simRef = useRef<Sim | null>(null)
  if (simRef.current == null) simRef.current = createSim()
  const sim = simRef.current

  const camRef = useRef({ x: 0, y: 0, zoom: 1, needsFit: true })
  const sizeRef = useRef<{ w: number; h: number } | null>(null)
  const reduceRef = useRef(false)

  const [preset, setPreset] = useState<PresetId>("planet")
  const [timeScale, setTimeScale] = useState(1)
  const [trails, setTrails] = useState(true)
  const [mode, setMode] = useState<CollisionMode>("bounce")
  const [mute, setMute] = useState(false)
  const [paused, setPaused] = useState(false)
  const [tool, setTool] = useState<Tool>("throw")
  const [scenario, setScenario] = useState<string>("system")
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const [count, setCount] = useState(sim.bodies.length)
  const [stats, setStats] = useState<Stats>(() => ({
    count: sim.bodies.length,
    time: formatSimTime(sim.time),
    speed: "—",
    label: "Speed",
  }))

  const ui = useRef({
    preset,
    timeScale,
    trails,
    mode,
    paused,
    tool,
    selectedId,
    count,
  })
  ui.current = { preset, timeScale, trails, mode, paused, tool, selectedId, count }

  const readStats = useCallback((): Stats => {
    const live = simRef.current
    if (!live) return { count: 0, time: "0:00.0", speed: "—", label: "—" }
    const sel = live.bodies.find((b) => b.id === ui.current.selectedId)
    return {
      count: live.bodies.length,
      time: formatSimTime(live.time),
      speed: sel ? `${Math.round(Math.hypot(sel.vx, sel.vy))}/s` : "—",
      label: sel ? getPreset(sel.preset).label : "Speed",
    }
  }, [])

  const publishStats = useCallback(
    (nextCount?: number) => {
      const next = readStats()
      setStats((prev) =>
        prev.count === next.count && prev.time === next.time && prev.speed === next.speed && prev.label === next.label
          ? prev
          : next,
      )
      if (nextCount != null) setCount(nextCount)
      else setCount(next.count)
    },
    [readStats],
  )

  const fitCamera = useCallback((snapUser: boolean) => {
    const live = simRef.current
    const size = sizeRef.current
    if (!live || !size) {
      camRef.current.needsFit = true
      return
    }
    const framed = frameOf(live.bodies, size.w, size.h)
    camRef.current.x = framed.x
    camRef.current.y = framed.y
    camRef.current.zoom = framed.zoom
    camRef.current.needsFit = false
    if (snapUser) camRef.current.needsFit = false
  }, [])

  const applyScenario = useCallback(
    (id: ScenarioId) => {
      const live = simRef.current
      if (!live) return
      loadScenario(live, id)
      setScenario(id)
      setSelectedId(null)
      fitCamera(true)
      publishStats(live.bodies.length)
    },
    [fitCamera, publishStats],
  )

  const zoomBy = useCallback((factor: number) => {
    const cam = camRef.current
    const size = sizeRef.current
    const previous = cam.zoom
    cam.zoom = clamp(previous * factor, ZOOM_MIN, ZOOM_MAX)
    if (!size) return
    const before = screenToWorld(size.w / 2, size.h / 2, cam.x, cam.y, previous, size.w, size.h)
    const after = screenToWorld(size.w / 2, size.h / 2, cam.x, cam.y, cam.zoom, size.w, size.h)
    cam.x += before.x - after.x
    cam.y += before.y - after.y
  }, [])

  const noticeTimer = useRef(0)
  const flash = useCallback((message: string) => {
    setNotice(message)
    window.clearTimeout(noticeTimer.current)
    noticeTimer.current = window.setTimeout(() => setNotice(null), 2200)
  }, [])

  useEffect(() => {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY)
      if (!raw) return
      const parsed = JSON.parse(raw) as {
        timeScale?: number
        trails?: boolean
        mode?: CollisionMode
        mute?: boolean
        preset?: PresetId
      }
      if (typeof parsed.timeScale === "number") setTimeScale(clamp(parsed.timeScale, 0.2, 4))
      if (typeof parsed.trails === "boolean") setTrails(parsed.trails)
      if (parsed.mode === "bounce" || parsed.mode === "merge") setMode(parsed.mode)
      if (typeof parsed.mute === "boolean") setMute(parsed.mute)
      if (parsed.preset && PRESET_LIST.some((p) => p.id === parsed.preset)) setPreset(parsed.preset)
    } catch {
      /* ignore broken settings */
    }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem(
        SETTINGS_KEY,
        JSON.stringify({ version: 1, timeScale, trails, mode, mute, preset }),
      )
    } catch {
      /* ignore quota */
    }
  }, [timeScale, trails, mode, mute, preset])

  useEffect(() => {
    setMuted(mute)
  }, [mute])

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)")
    const apply = () => {
      reduceRef.current = mq.matches
    }
    apply()
    mq.addEventListener("change", apply)
    return () => mq.removeEventListener("change", apply)
  }, [])

  useEffect(() => {
    const live = simRef.current
    if (!live) return
    window.__orrery = {
      ready: true,
      count: () => simRef.current?.bodies.length ?? 0,
      time: () => simRef.current?.time ?? 0,
      energy: () => (simRef.current ? energyOf(simRef.current) : 0),
      bodies: () =>
        simRef.current?.bodies.map((b) => ({
          id: b.id,
          preset: b.preset,
          x: b.x,
          y: b.y,
          vx: b.vx,
          vy: b.vy,
          mass: b.mass,
          r: b.radius,
        })) ?? [],
      load: (id) => applyScenario(id),
      fling: (presetId, x, y, vx, vy) => {
        const current = simRef.current
        if (!current) return null
        const born = addBody(current, presetId, x, y, vx, vy)
        setScenario("")
        setSelectedId(born?.id ?? null)
        publishStats(current.bodies.length)
        return born?.id ?? null
      },
    }
    return () => {
      delete window.__orrery
    }
  }, [applyScenario, publishStats])

  useEffect(() => {
    const canvas = canvasRef.current
    const live = simRef.current
    if (!canvas || !live) return

    const stars: StarDot[] = createStarfield(150, 11)
    const sparks: Spark[] = []
    const sparkPool: Array<Spark & { vx: number; vy: number }> = []
    let drag: Drag | null = null
    let pinch: Pinch | null = null
    const pointers = new Map<number, { x: number; y: number }>()
    let trauma = 0
    let raf = 0
    let last = performance.now()
    let statAcc = 0

    const resize = () => {
      const w = canvas.clientWidth
      const h = canvas.clientHeight
      sizeRef.current = { w, h }
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      const bw = Math.max(1, Math.round(w * dpr))
      const bh = Math.max(1, Math.round(h * dpr))
      if (canvas.width !== bw || canvas.height !== bh) {
        canvas.width = bw
        canvas.height = bh
      }
      if (camRef.current.needsFit && w > 0 && h > 0) {
        const framed = frameOf(live.bodies, w, h)
        camRef.current.x = framed.x
        camRef.current.y = framed.y
        camRef.current.zoom = framed.zoom
        camRef.current.needsFit = false
      }
      return dpr
    }

    const localOf = (clientX: number, clientY: number) => {
      const rect = canvas.getBoundingClientRect()
      return {
        x: clientX - rect.left,
        y: clientY - rect.top,
        w: rect.width,
        h: rect.height,
      }
    }

    const worldOf = (clientX: number, clientY: number) => {
      const local = localOf(clientX, clientY)
      const cam = camRef.current
      return {
        ...screenToWorld(local.x, local.y, cam.x, cam.y, cam.zoom, local.w, local.h),
        local,
      }
    }

    const burst = (x: number, y: number, speed: number) => {
      const n = Math.min(16, 4 + Math.floor(speed / 90))
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2
        const s = 18 + Math.random() * (30 + speed * 0.12)
        const life = 0.22 + Math.random() * 0.28
        sparkPool.push({
          x,
          y,
          vx: Math.cos(a) * s,
          vy: Math.sin(a) * s,
          life,
          max: life,
          r: 1 + Math.random() * 1.4,
        })
      }
      if (sparkPool.length > 180) sparkPool.splice(0, sparkPool.length - 180)
    }

    const onDown = (e: PointerEvent) => {
      if (e.button !== 0 && e.button !== 1 && e.button !== 2) return
      unlockAudio()
      canvas.setPointerCapture(e.pointerId)
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY })
      if (pointers.size >= 2) {
        drag = null
        const pts = [...pointers.values()]
        pinch = {
          dist0: Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y) || 1,
          zoom0: camRef.current.zoom,
        }
        return
      }
      if (e.button === 1 || e.button === 2 || ui.current.tool === "pan") {
        drag = { type: "pan", lastX: e.clientX, lastY: e.clientY }
        return
      }
      const world = worldOf(e.clientX, e.clientY)
      const hit = pickBody(live.bodies, world.x, world.y, camRef.current.zoom)
      if (hit) {
        setSelectedId(hit.id)
        drag = {
          type: "body",
          id: hit.id,
          x0: hit.x,
          y0: hit.y,
          x: world.x,
          y: world.y,
          sx0: e.clientX,
          sy0: e.clientY,
          moved: false,
        }
      } else {
        setSelectedId(null)
        drag = {
          type: "new",
          id: null,
          x0: world.x,
          y0: world.y,
          x: world.x,
          y: world.y,
          sx0: e.clientX,
          sy0: e.clientY,
          moved: false,
        }
      }
    }

    const updatePinch = () => {
      if (!pinch || pointers.size < 2) return
      const pts = [...pointers.values()]
      const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y) || 1
      const midX = (pts[0].x + pts[1].x) / 2
      const midY = (pts[0].y + pts[1].y) / 2
      const local = localOf(midX, midY)
      const cam = camRef.current
      const before = screenToWorld(local.x, local.y, cam.x, cam.y, cam.zoom, local.w, local.h)
      cam.zoom = clamp(pinch.zoom0 * (dist / pinch.dist0), ZOOM_MIN, ZOOM_MAX)
      const after = screenToWorld(local.x, local.y, cam.x, cam.y, cam.zoom, local.w, local.h)
      cam.x += before.x - after.x
      cam.y += before.y - after.y
    }

    const onMove = (e: PointerEvent) => {
      if (!pointers.has(e.pointerId)) return
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY })
      if (pointers.size >= 2) {
        updatePinch()
        return
      }
      if (!drag) return
      if (drag.type === "pan") {
        const cam = camRef.current
        cam.x -= (e.clientX - drag.lastX) / cam.zoom
        cam.y -= (e.clientY - drag.lastY) / cam.zoom
        drag.lastX = e.clientX
        drag.lastY = e.clientY
        return
      }
      const world = worldOf(e.clientX, e.clientY)
      drag.x = world.x
      drag.y = world.y
      if (Math.hypot(e.clientX - drag.sx0, e.clientY - drag.sy0) > 8) drag.moved = true
    }

    const onUp = (e: PointerEvent) => {
      pointers.delete(e.pointerId)
      if (pointers.size < 2) pinch = null
      if (pointers.size >= 1) {
        drag = null
        return
      }
      const finished = drag
      drag = null
      if (!finished || finished.type === "pan") return
      if (finished.type === "new") {
        let vx = 0
        let vy = 0
        if (finished.moved) {
          const limited = limitVelocity((finished.x - finished.x0) / AIM_SECONDS, (finished.y - finished.y0) / AIM_SECONDS)
          vx = limited.vx
          vy = limited.vy
        }
        const born = addBody(live, ui.current.preset, finished.x0, finished.y0, vx, vy)
        if (!born) {
          flash(`The field is full — ${MAX_BODIES} worlds is the limit.`)
          return
        }
        setSelectedId(born.id)
        setScenario("")
        publishStats(live.bodies.length)
        if (finished.moved) {
          playFling(Math.hypot(vx, vy))
          if (!reduceRef.current) trauma = Math.min(1, trauma + 0.12)
        }
        return
      }
      if (!finished.moved || finished.id == null) return
      const body = live.bodies.find((b) => b.id === finished.id)
      if (!body) return
      const limited = limitVelocity((finished.x - body.x) / AIM_SECONDS, (finished.y - body.y) / AIM_SECONDS)
      setBodyVelocity(live, body.id, limited.vx, limited.vy)
      playFling(limited.speed)
      if (!reduceRef.current) trauma = Math.min(1, trauma + 0.1)
      publishStats()
    }

    const onWheel = (e: WheelEvent) => {
      e.preventDefault()
      const local = localOf(e.clientX, e.clientY)
      const cam = camRef.current
      const before = screenToWorld(local.x, local.y, cam.x, cam.y, cam.zoom, local.w, local.h)
      cam.zoom = clamp(cam.zoom * Math.exp(-e.deltaY * 0.00115), ZOOM_MIN, ZOOM_MAX)
      const after = screenToWorld(local.x, local.y, cam.x, cam.y, cam.zoom, local.w, local.h)
      cam.x += before.x - after.x
      cam.y += before.y - after.y
    }

    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null
      const tag = target?.tagName
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || target?.isContentEditable) return
      if (e.code === "Space") {
        e.preventDefault()
        setPaused((v) => !v)
        return
      }
      if (e.code === "Backspace" || e.code === "Delete") {
        const id = ui.current.selectedId
        if (id == null || !simRef.current) return
        e.preventDefault()
        removeBody(simRef.current, id)
        setSelectedId(null)
        setScenario("")
        publishStats()
        return
      }
      if (e.code.startsWith("Digit")) {
        const index = Number(e.code.slice(5)) - 1
        if (index >= 0 && index < PRESET_LIST.length) setPreset(PRESET_LIST[index].id)
        return
      }
      if (e.code === "BracketLeft") setTimeScale((v) => clamp(Math.round((v - 0.2) * 10) / 10, 0.2, 4))
      if (e.code === "BracketRight") setTimeScale((v) => clamp(Math.round((v + 0.2) * 10) / 10, 0.2, 4))
      if (e.code === "KeyT") setTrails((v) => !v)
      if (e.code === "KeyH") setTool((v) => (v === "pan" ? "throw" : "pan"))
      if (e.code === "KeyM") setMute((v) => !v)
      if (e.code === "KeyF") {
        const size = sizeRef.current
        const current = simRef.current
        if (!size || !current) return
        const framed = frameOf(current.bodies, size.w, size.h)
        camRef.current.x = framed.x
        camRef.current.y = framed.y
        camRef.current.zoom = framed.zoom
      }
      if (e.code === "Minus" || e.code === "NumpadSubtract") zoomBy(1 / 1.15)
      if (e.code === "Equal" || e.code === "NumpadAdd") zoomBy(1.15)
    }

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000)
      last = now
      const dpr = resize()
      const size = sizeRef.current
      const ctx = canvas.getContext("2d")
      if (!size || !ctx || size.w < 2 || size.h < 2) {
        raf = requestAnimationFrame(frame)
        return
      }
      const holding = drag != null && drag.type !== "pan"
      const running = !ui.current.paused && !holding && !document.hidden
      live.mode = ui.current.mode
      live.trails = ui.current.trails
      if (running) advanceSim(live, dt, ui.current.timeScale)

      for (const event of live.events) {
        burst(event.x, event.y, event.speed)
        if (!reduceRef.current) trauma = Math.min(1, trauma + Math.min(0.5, event.speed / 900))
        if (event.type === "merge") playMerge()
        else playHit(event.speed)
      }
      live.events.length = 0
      trauma = Math.max(0, trauma - dt * 1.7)

      for (let i = sparkPool.length - 1; i >= 0; i--) {
        const spark = sparkPool[i]
        spark.life -= dt
        if (spark.life <= 0) {
          sparkPool.splice(i, 1)
          continue
        }
        spark.x += spark.vx * dt
        spark.y += spark.vy * dt
      }
      sparks.length = 0
      for (const spark of sparkPool) sparks.push(spark)

      if (ui.current.selectedId != null && !live.bodies.some((b) => b.id === ui.current.selectedId)) {
        ui.current.selectedId = null
        setSelectedId(null)
      }

      let path: number[] | null = null
      let dragDraw: DragDraw | null = null
      const active = drag
      if (active && active.type !== "pan") {
        const presetNow = getPreset(ui.current.preset)
        if (active.type === "new") {
          const limited = active.moved
            ? limitVelocity((active.x - active.x0) / AIM_SECONDS, (active.y - active.y0) / AIM_SECONDS)
            : { vx: 0, vy: 0, speed: 0 }
          dragDraw = {
            kind: "new",
            x0: active.x0,
            y0: active.y0,
            x1: active.x,
            y1: active.y,
            color: presetNow.color,
            core: presetNow.core,
            radius: radiusFromMass(presetNow.mass, presetNow.kind),
            moved: active.moved,
            speed: limited.speed,
          }
          if (active.moved) {
            path = forecast(live, {
              id: null,
              x: active.x0,
              y: active.y0,
              vx: limited.vx,
              vy: limited.vy,
              preset: ui.current.preset,
            })
          }
        } else if (active.id != null) {
          const body = live.bodies.find((b) => b.id === active.id)
          if (body) {
            const limited = active.moved
              ? limitVelocity((active.x - body.x) / AIM_SECONDS, (active.y - body.y) / AIM_SECONDS)
              : { vx: body.vx, vy: body.vy, speed: Math.hypot(body.vx, body.vy) }
            dragDraw = {
              kind: "body",
              x0: body.x,
              y0: body.y,
              x1: active.moved ? active.x : body.x + body.vx * AIM_SECONDS,
              y1: active.moved ? active.y : body.y + body.vy * AIM_SECONDS,
              color: body.color,
              core: body.core,
              radius: body.radius,
              moved: active.moved,
              speed: limited.speed,
            }
            if (active.moved) {
              path = forecast(live, {
                id: body.id,
                x: body.x,
                y: body.y,
                vx: limited.vx,
                vy: limited.vy,
                preset: body.preset,
              })
            }
          }
        }
      }

      const shake = reduceRef.current ? 0 : trauma * trauma
      const cam = camRef.current
      renderScene(
        ctx,
        live,
        {
          w: size.w,
          h: size.h,
          camX: cam.x,
          camY: cam.y,
          zoom: cam.zoom,
          shakeX: shake * 14 * Math.sin(now * 0.061),
          shakeY: shake * 10 * Math.cos(now * 0.047),
          reduce: reduceRef.current,
          trails: ui.current.trails,
        },
        { stars, path, drag: dragDraw, selectedId: ui.current.selectedId, sparks, dpr },
      )

      statAcc += dt
      if (statAcc > 0.2) {
        statAcc = 0
        const next = readStats()
        setStats((prev) =>
          prev.count === next.count && prev.time === next.time && prev.speed === next.speed && prev.label === next.label
            ? prev
            : next,
        )
        setCount((prev) => (prev === next.count ? prev : next.count))
      }

      raf = requestAnimationFrame(frame)
    }

    resize()
    raf = requestAnimationFrame(frame)
    canvas.addEventListener("pointerdown", onDown)
    canvas.addEventListener("pointermove", onMove)
    canvas.addEventListener("pointerup", onUp)
    canvas.addEventListener("pointercancel", onUp)
    canvas.addEventListener("wheel", onWheel, { passive: false })
    const onContext = (e: Event) => e.preventDefault()
    canvas.addEventListener("contextmenu", onContext)
    window.addEventListener("keydown", onKey)
    const ro = new ResizeObserver(() => resize())
    ro.observe(canvas)

    return () => {
      cancelAnimationFrame(raf)
      canvas.removeEventListener("pointerdown", onDown)
      canvas.removeEventListener("pointermove", onMove)
      canvas.removeEventListener("pointerup", onUp)
      canvas.removeEventListener("pointercancel", onUp)
      canvas.removeEventListener("wheel", onWheel)
      canvas.removeEventListener("contextmenu", onContext)
      window.removeEventListener("keydown", onKey)
      ro.disconnect()
    }
  }, [flash, publishStats, readStats, zoomBy])

  const scaleLabel = timeScale < 1 ? `${timeScale.toFixed(2)}×` : `${timeScale.toFixed(timeScale < 10 ? 1 : 0)}×`

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-fg select-none">
      <canvas
        ref={canvasRef}
        className={clsx("absolute inset-0 h-full w-full touch-none", tool === "pan" ? "cursor-grab" : "cursor-crosshair")}
        aria-label="Orbital sandbox. Drag to fling a world."
      />
      <div className="pointer-events-none absolute inset-0 flex flex-col justify-between gap-3 p-3 sm:p-4">
        <header className="pointer-events-none flex flex-col gap-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-medium tracking-wide text-muted">Orbital sandbox</p>
              <h1 className="mt-1 font-display text-3xl leading-none tracking-tight text-fg sm:text-4xl">Orrery</h1>
            </div>
            <div className="flex items-start gap-3 sm:gap-4">
              <dl className="flex gap-3 sm:gap-4">
                <div>
                  <dt className="text-xs text-muted">Bodies</dt>
                  <dd className="font-mono text-sm tabular-nums text-fg">{stats.count}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted">{paused ? "Paused" : "Time"}</dt>
                  <dd className="font-mono text-sm tabular-nums text-fg">{stats.time}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted">{stats.label}</dt>
                  <dd className="font-mono text-sm tabular-nums text-fg">{stats.speed}</dd>
                </div>
              </dl>
              <button
                type="button"
                className={clsx(iconBtn, "pointer-events-auto")}
                aria-label={mute ? "Unmute" : "Mute"}
                aria-pressed={mute}
                onClick={() => {
                  unlockAudio()
                  setMute((v) => !v)
                }}
              >
                {mute ? <VolumeX className="size-4" aria-hidden /> : <Volume2 className="size-4" aria-hidden />}
              </button>
            </div>
          </div>
          {notice ? (
            <p
              role="status"
              className="w-fit rounded-md border border-fg/15 bg-elevated px-3 py-2 text-sm text-fg"
            >
              {notice}
            </p>
          ) : null}
        </header>

        {count === 0 ? (
          <div className="pointer-events-none flex flex-1 items-center justify-center px-4">
            <div className="max-w-sm rounded-xl border border-fg/15 bg-elevated p-4 text-center">
              <p className="text-sm leading-relaxed text-fg">Drag to fling a world into the field.</p>
              <p className="mt-2 text-xs leading-relaxed text-muted">
                The arrow is one second of motion, before gravity bends it.
              </p>
            </div>
          </div>
        ) : (
          <div className="flex-1" />
        )}

        <footer className="pointer-events-auto mx-auto flex w-full max-w-3xl flex-col gap-2 rounded-xl border border-fg/15 bg-elevated p-3">
          <div className="flex items-center gap-3">
            <span className="w-12 shrink-0 text-xs text-muted">Mass</span>
            <div className="chip-row flex min-w-0 flex-1 gap-2 overflow-x-auto" role="radiogroup" aria-label="Mass">
              {PRESET_LIST.map((item, index) => {
                const on = preset === item.id
                return (
                  <button
                    key={item.id}
                    type="button"
                    role="radio"
                    aria-checked={on}
                    className={clsx(
                      "h-11 shrink-0 rounded-full px-3 text-sm font-medium transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40",
                      on ? "bg-fg text-bg" : "border border-fg/15 bg-bg text-fg hover:bg-subtle",
                    )}
                    onClick={() => setPreset(item.id)}
                  >
                    <span className="sr-only">{index + 1} </span>
                    {item.label}
                  </button>
                )
              })}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="w-12 shrink-0 text-xs text-muted">Scene</span>
            <div className="chip-row flex min-w-0 flex-1 gap-2 overflow-x-auto" role="radiogroup" aria-label="Scene">
              {SCENARIOS.map((item) => {
                const on = scenario === item.id
                return (
                  <button
                    key={item.id}
                    type="button"
                    role="radio"
                    aria-checked={on}
                    className={clsx(
                      "h-11 shrink-0 rounded-full px-3 text-sm font-medium transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40",
                      on ? "bg-fg text-bg" : "border border-fg/15 bg-bg text-fg hover:bg-subtle",
                    )}
                    onClick={() => applyScenario(item.id)}
                  >
                    {item.label}
                  </button>
                )
              })}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <label className="flex min-w-0 flex-1 items-center gap-3">
              <span className="w-12 shrink-0 text-xs text-muted">Time</span>
              <input
                className="time-slider min-w-0 flex-1"
                type="range"
                min={0.2}
                max={4}
                step={0.1}
                value={timeScale}
                aria-label="Time scale"
                onChange={(e) => setTimeScale(Number(e.target.value))}
              />
              <span className="w-12 shrink-0 text-right font-mono text-sm tabular-nums text-fg">{scaleLabel}</span>
            </label>
            <button
              type="button"
              className={iconBtn}
              aria-label={paused ? "Play" : "Pause"}
              onClick={() => setPaused((v) => !v)}
            >
              {paused ? <Play className="size-4" aria-hidden /> : <Pause className="size-4" aria-hidden />}
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              className={clsx(textBtn, trails && "bg-subtle")}
              aria-pressed={trails}
              onClick={() => setTrails((v) => !v)}
            >
              Trails
            </button>
            <div className="flex h-11 items-center gap-1 rounded-md border border-fg/15 bg-bg p-1" role="radiogroup" aria-label="Collision">
              {(["bounce", "merge"] as const).map((item) => (
                <button
                  key={item}
                  type="button"
                  role="radio"
                  aria-checked={mode === item}
                  className={clsx(
                    "h-full rounded-sm px-3 text-sm font-medium capitalize transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40",
                    mode === item ? "bg-fg text-bg" : "text-fg hover:bg-subtle",
                  )}
                  onClick={() => setMode(item)}
                >
                  {item}
                </button>
              ))}
            </div>
            <button
              type="button"
              className={clsx(textBtn, tool === "pan" && "bg-fg text-bg hover:bg-fg")}
              aria-pressed={tool === "pan"}
              onClick={() => setTool((v) => (v === "pan" ? "throw" : "pan"))}
            >
              <Hand className="mr-1.5 size-4" aria-hidden />
              Pan
            </button>
            <button type="button" className={iconBtn} aria-label="Zoom out" onClick={() => zoomBy(1 / 1.15)}>
              <Minus className="size-4" aria-hidden />
            </button>
            <button type="button" className={iconBtn} aria-label="Zoom in" onClick={() => zoomBy(1.15)}>
              <Plus className="size-4" aria-hidden />
            </button>
            <button type="button" className={iconBtn} aria-label="Frame all worlds" onClick={() => fitCamera(true)}>
              <LocateFixed className="size-4" aria-hidden />
            </button>
            <button
              type="button"
              className={textBtn}
              disabled={selectedId == null}
              onClick={() => {
                const current = simRef.current
                if (!current || selectedId == null) return
                removeBody(current, selectedId)
                setSelectedId(null)
                setScenario("")
                publishStats()
              }}
            >
              Remove
            </button>
            <button
              type="button"
              className={textBtn}
              onClick={() => {
                const current = simRef.current
                if (!current) return
                clearBodies(current)
                setScenario("")
                setSelectedId(null)
                publishStats(0)
              }}
            >
              Clear
            </button>
          </div>
          <p className="text-xs leading-relaxed text-faint">
            {tool === "pan"
              ? "Drag to move the view. Scroll or pinch to zoom."
              : "Drag empty space to add a world. Drag a world to fling it. The arrow is one second of flight."}
          </p>
        </footer>
      </div>
    </main>
  )
}
