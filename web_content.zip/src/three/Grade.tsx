import {
  Bloom,
  BrightnessContrast,
  EffectComposer,
  HueSaturation,
  Vignette,
} from "@react-three/postprocessing";
import { BlendFunction } from "postprocessing";
import { useThree } from "@react-three/fiber";
import { useStore } from "../lib/store";

/**
 * Per-map cinematic colour grade.
 *
 * Each map gets its own contrast / saturation / bloom recipe so the mood reads
 * instantly: warm and soft at home, cold and crushed at night, hot and dusty on
 * Mars. Kept deliberately cheap — no depth-of-field or SSAO, so mobile GPUs are
 * unaffected.
 */
type Recipe = {
  brightness: number;
  contrast: number;
  hue: number;
  saturation: number;
  bloom: number;
  bloomThreshold: number;
  vignette: number;
};

/**
 * Grading philosophy: keep the image CRISP.
 *
 * Bloom only touches genuinely emissive pixels (high threshold), so neon signs
 * glow but ordinary lit surfaces stay sharp. Vignette is light and lives only
 * here — the old CSS vignette/grain overlays were stacking on top of this and
 * were the real cause of the muddy, out-of-focus look.
 */
const RECIPES: Record<string, Recipe> = {
  home: {
    brightness: 0.0,
    contrast: 0.15,
    hue: 0.0,
    saturation: 0.14,
    bloom: 0.44,
    bloomThreshold: 0.83,
    vignette: 0.28,
  },
  gym: {
    brightness: 0.0,
    contrast: 0.15,
    hue: 0.0,
    saturation: 0.06,
    bloom: 0.12,
    bloomThreshold: 0.95,
    vignette: 0.22,
  },
  street: {
    brightness: 0.01,
    contrast: 0.14,
    hue: 0.0,
    saturation: 0.09,
    bloom: 0.1,
    bloomThreshold: 0.96,
    vignette: 0.2,
  },
  night: {
    brightness: 0.0,
    contrast: 0.16,
    hue: -0.02,
    saturation: 0.14,
    // lamps and windows are emissive, so they still pop at a high threshold
    bloom: 0.4,
    bloomThreshold: 0.85,
    vignette: 0.32,
  },
  jail: {
    brightness: 0.0,
    contrast: 0.15,
    hue: -0.01,
    saturation: -0.2,
    bloom: 0.1,
    bloomThreshold: 0.95,
    vignette: 0.34,
  },
  space: {
    brightness: 0.0,
    contrast: 0.16,
    hue: 0.0,
    saturation: 0.12,
    bloom: 0.44,
    bloomThreshold: 0.83,
    vignette: 0.3,
  },
  mars: {
    brightness: 0.01,
    contrast: 0.15,
    hue: 0.01,
    saturation: 0.16,
    bloom: 0.22,
    bloomThreshold: 0.9,
    vignette: 0.26,
  },
  // neon arcade — the one place a little extra glow belongs
  wheel: {
    brightness: 0.0,
    contrast: 0.15,
    hue: 0.0,
    saturation: 0.16,
    bloom: 0.5,
    bloomThreshold: 0.82,
    vignette: 0.28,
  },
};

export function Grade() {
  const map = useStore((s) => s.map);
  const { size } = useThree();

  // phones get a lighter stack so the frame rate holds
  const low = size.width < 520;
  const r = RECIPES[map] ?? RECIPES.home;

  return (
    <EffectComposer multisampling={low ? 2 : 4} enableNormalPass={false}>
      <Bloom
        intensity={r.bloom}
        luminanceThreshold={r.bloomThreshold}
        luminanceSmoothing={0.08}
        mipmapBlur
        radius={0.4}
      />
      <HueSaturation hue={r.hue} saturation={r.saturation} />
      <BrightnessContrast brightness={r.brightness} contrast={r.contrast} />
      <Vignette
        offset={0.42}
        darkness={r.vignette}
        eskil={false}
        blendFunction={BlendFunction.NORMAL}
      />
    </EffectComposer>
  );
}
