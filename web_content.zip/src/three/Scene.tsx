import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { ContactShadows, AdaptiveDpr } from "@react-three/drei";
import { useEffect, useRef } from "react";
import * as THREE from "three";
import { Chick } from "./Chick";
import { GradientEnv } from "./GradientEnv";
import { useStore } from "../lib/store";
import { useLayout } from "../lib/layout";
import { GymEnv, HomeEnv, JailEnv, NightEnv, StreetEnv } from "./Envs";
import { MarsScene } from "./MarsScene";
import { Grade } from "./Grade";
import { WheelScene } from "./WheelScene";
import { Backdrop3D } from "./Backdrop3D";

function CameraRig() {
  const { camera } = useThree();
  const target = useRef(new THREE.Vector3(0, 0.1, 0));
  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    camera.position.x = THREE.MathUtils.damp(camera.position.x, state.pointer.x * 0.45, 3, dt);
    camera.position.y = THREE.MathUtils.damp(camera.position.y, 0.28 + state.pointer.y * 0.28, 3, dt);
    camera.lookAt(target.current);
  });
  return null;
}

/** Keeps the chick nicely framed between the headline and the bottom UI. */
function ChickRig() {
  const { size, camera } = useThree();
  const world = useStore((s) => s.map);
  const hud = useLayout();
  const narrow = size.width < 640;
  // pull back in the busy job scenes so the whole world is readable
  const envScale = world === "home" ? 0.82 : world === "gym" ? 0.72 : 0.62;

  const fov = "fov" in camera ? (camera.fov as number) : 40;
  const worldHeight = 2 * Math.tan((fov * Math.PI) / 360) * camera.position.length();
  const pxPerUnit = size.height / worldHeight;

  // measured heights of the overlay blocks (kept in sync with Overlay.tsx)
  // real, measured HUD heights (+ a little breathing room)
  const topUI = hud.top + 8;
  const bottomUI = hud.bottom + 8;
  const freePx = Math.max(110, size.height - topUI - bottomUI);
  // leave head-room for the speech bubble above the chick
  const chickPx = Math.min(freePx * 0.7, narrow ? 360 : 460);

  const scale =
    THREE.MathUtils.clamp(chickPx / (2.78 * pxPerUnit), 0.38, 1.08) * envScale;
  const centerPx = (topUI + (size.height - bottomUI)) / 2;
  const groupY = (size.height / 2 - centerPx) / pxPerUnit - 0.62 * scale;

  const group = useRef<THREE.Group>(null);
  useEffect(() => {
    group.current?.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true;
        o.receiveShadow = true;
      }
    });
  }, []);

  return (
    <group position={[0, groupY, 0]} scale={scale}>
      {/* the room / street lives in the same space so the floors line up */}
      <Environments />
      <group ref={group}>
        <Chick />
      </group>
      <ContactShadows
        position={[0, -1.19, 0]}
        opacity={0.6}
        scale={6.4}
        blur={2.8}
        far={2.4}
        resolution={512}
        color="#4A2404"
        frames={Infinity}
      />
    </group>
  );
}

/** Soft out-of-focus orbs that add depth behind the chick. */
function Dust() {
  const group = useRef<THREE.Group>(null);
  const items = useRef(
    Array.from({ length: 12 }, (_, i) => ({
      x: (Math.random() - 0.5) * 12,
      y: (Math.random() - 0.5) * 5.5,
      z: -5 - Math.random() * 3,
      r: 0.18 + Math.random() * 0.5,
      speed: 0.14 + Math.random() * 0.26,
      phase: i * 1.9,
      o: 0.14 + Math.random() * 0.2,
    })),
  );

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const g = group.current;
    if (!g) return;
    g.children.forEach((child, i) => {
      const it = items.current[i];
      child.position.y = it.y + Math.sin(t * it.speed + it.phase) * 0.7;
      child.position.x = it.x + Math.cos(t * it.speed * 0.7 + it.phase) * 0.4;
    });
  });

  return (
    <group ref={group}>
      {items.current.map((it, i) => (
        <mesh key={i} position={[it.x, it.y, it.z]}>
          <sphereGeometry args={[it.r, 16, 12]} />
          <meshBasicMaterial color="#fffaf0" transparent opacity={it.o} depthWrite={false} />
        </mesh>
      ))}
    </group>
  );
}

export function Scene() {
  return (
    <Canvas
      dpr={[1, 2]}
      shadows="soft"
      gl={{
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.15,
        outputColorSpace: THREE.SRGBColorSpace,
      }}
      camera={{ position: [0, 0.28, 5.1], fov: 40 }}
      style={{ position: "absolute", inset: 0 }}
    >
      <CameraRig />
      <AdaptiveDpr pixelated={false} />
      <GradientEnv intensity={1.15} />

      <Backdrop3D />
      <Lighting />
      <Stage />
      <HomeDust />
      <Grade />
    </Canvas>
  );
}

/** The floating orbs only belong to the cosy home scene. */
function HomeDust() {
  const world = useStore((s) => s.map);
  if (world !== "home") return null;
  return <Dust />;
}

/** Lighting rig that shifts with the current world. */
/**
 * Cinematic three-point rig.
 *
 * Every map gets a warm/cool split: a strong key from one side, a dim fill from
 * the other, and a bright rim behind the subject to separate it from the
 * backdrop. That separation is what makes the render read as "lit" rather than
 * "flat".
 */
type Rig = {
  ambient: [string, number];
  key: { pos: [number, number, number]; color: string; intensity: number };
  fill: { pos: [number, number, number]; color: string; intensity: number };
  rim: { pos: [number, number, number]; color: string; intensity: number };
  bounce?: { pos: [number, number, number]; color: string; intensity: number; distance: number };
  hemi?: [string, string, number];
};

const RIGS: Record<string, Rig> = {
  home: {
    ambient: ["#B9A8E8", 0.24],
    key: { pos: [3.4, 4.8, 4.0], color: "#FFF2E2", intensity: 2.2 },
    fill: { pos: [-4.2, 1.8, 2.6], color: "#00E5FF", intensity: 0.8 },
    rim: { pos: [-2.4, 3.2, -5.0], color: "#FF2D95", intensity: 3.0 },
    bounce: { pos: [0, -2.2, 2.2], color: "#C77DFF", intensity: 5, distance: 8 },
    hemi: ["#C9A8FF", "#150C28", 0.5],
  },
  gym: {
    ambient: ["#E8EEF8", 0.2],
    key: { pos: [3.2, 5.4, 3.4], color: "#FFFFFF", intensity: 3.0 },
    fill: { pos: [-4.0, 2.0, 2.8], color: "#8FB6FF", intensity: 0.85 },
    rim: { pos: [-1.8, 3.8, -5.0], color: "#A98BFF", intensity: 3.0 },
    bounce: { pos: [0, -2.2, 2.0], color: "#C9D6FF", intensity: 5, distance: 7 },
  },
  street: {
    ambient: ["#FFF6E2", 0.26],
    key: { pos: [4.0, 5.6, 3.6], color: "#FFF7E0", intensity: 3.0 },
    fill: { pos: [-4.2, 2.2, 3.0], color: "#A9CCFF", intensity: 0.9 },
    rim: { pos: [-2.4, 3.6, -5.4], color: "#FFD9A0", intensity: 2.2 },
    bounce: { pos: [0, -2.4, 2.2], color: "#C8B79A", intensity: 5, distance: 8 },
  },
  night: {
    ambient: ["#5C6E9E", 0.1],
    key: { pos: [3.4, 4.4, 3.0], color: "#7E93D8", intensity: 0.85 },
    fill: { pos: [-4.0, 1.6, 2.4], color: "#3E4C7A", intensity: 0.4 },
    // hot sodium rim is what sells the noir look
    rim: { pos: [-2.2, 3.2, -4.6], color: "#FFB25E", intensity: 4.2 },
  },
  jail: {
    ambient: ["#9FB2C8", 0.16],
    key: { pos: [2.6, 5.6, 2.4], color: "#E4EEFA", intensity: 2.2 },
    fill: { pos: [-3.6, 1.4, 2.2], color: "#5D6C82", intensity: 0.45 },
    rim: { pos: [-1.6, 3.0, -4.4], color: "#8FA6C4", intensity: 2.8 },
  },
  space: {
    ambient: ["#8FA6DE", 0.12],
    key: { pos: [4.4, 4.6, 4.0], color: "#FFFFFF", intensity: 2.6 },
    fill: { pos: [-4.2, 1.6, 2.2], color: "#4B5C92", intensity: 0.35 },
    rim: { pos: [-2.0, 2.6, -5.0], color: "#7FA8FF", intensity: 3.4 },
    hemi: ["#8FA8E0", "#0A0E1C", 0.5],
  },
  wheel: {
    ambient: ["#C9A8FF", 0.26],
    key: { pos: [3.0, 4.6, 4.0], color: "#FFE9FF", intensity: 1.9 },
    fill: { pos: [-4.0, 1.8, 2.6], color: "#00E5FF", intensity: 0.9 },
    rim: { pos: [-2.2, 3.2, -4.8], color: "#FF2D95", intensity: 3.4 },
    hemi: ["#C77DFF", "#1A0B2E", 0.8],
  },
  mars: {
    ambient: ["#FFD2AE", 0.3],
    key: { pos: [5.0, 6.0, 3.2], color: "#FFE3BC", intensity: 3.2 },
    fill: { pos: [-4.4, 1.8, 2.6], color: "#8FA8E0", intensity: 0.5 },
    rim: { pos: [-2.6, 3.2, -5.2], color: "#FF9A5E", intensity: 3.6 },
    hemi: ["#FFC08A", "#8E3110", 0.9],
  },
};

function Lighting() {
  const world = useStore((s) => s.map);
  const rig = RIGS[world] ?? RIGS.home;

  return (
    <>
      <ambientLight color={rig.ambient[0]} intensity={rig.ambient[1]} />

      {/* key — the only shadow caster, so shadows stay crisp and cheap */}
      <directionalLight
        position={rig.key.pos}
        color={rig.key.color}
        intensity={rig.key.intensity}
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-bias={-0.0012}
        shadow-normalBias={0.02}
        shadow-camera-left={-6}
        shadow-camera-right={6}
        shadow-camera-top={6}
        shadow-camera-bottom={-6}
      />

      {/* fill — cool, soft, opposite the key */}
      <directionalLight
        position={rig.fill.pos}
        color={rig.fill.color}
        intensity={rig.fill.intensity}
      />

      {/* rim — behind the subject, carves the silhouette out of the backdrop */}
      <directionalLight
        position={rig.rim.pos}
        color={rig.rim.color}
        intensity={rig.rim.intensity}
      />

      {rig.bounce && (
        <pointLight
          position={rig.bounce.pos}
          color={rig.bounce.color}
          intensity={rig.bounce.intensity}
          distance={rig.bounce.distance}
        />
      )}

      {rig.hemi && <hemisphereLight args={rig.hemi} />}
    </>
  );
}

/** Either the everyday chick rig, or the Mars expedition. */
function Stage() {
  const map = useStore((s) => s.map);
  if (map === "space" || map === "mars") return <MarsScene />;
  if (map === "wheel") return <WheelScene />;
  return <ChickRig />;
}

function Environments() {
  const world = useStore((s) => s.map);
  switch (world) {
    case "street":
      return <StreetEnv />;
    case "night":
      return <NightEnv />;
    case "jail":
      return <JailEnv />;
    case "gym":
      return <GymEnv />;
    case "space":
    case "mars":
    case "wheel":
      return null;
    default:
      return <HomeEnv />;
  }
}
