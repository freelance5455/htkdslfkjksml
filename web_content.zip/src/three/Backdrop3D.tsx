import { useEffect, useMemo } from "react";
import * as THREE from "three";
import { useStore } from "../lib/store";

/**
 * A skydome rendered *inside* the scene rather than as a CSS layer.
 *
 * This matters for the grade: bloom, contrast and the vignette can only act on
 * pixels the composer actually owns. With the gradient in 3D the whole frame is
 * graded as one image, which is what makes it read cinematically instead of a
 * lit subject floating on a flat CSS background.
 */
type Sky = {
  /** bottom → horizon → top */
  stops: [string, string, string];
  /** subtle warm/cool glow behind the subject */
  glow: string;
};

const SKIES: Record<string, Sky> = {
  home: { stops: ["#0E0820", "#1C1038", "#2E1A52"], glow: "#8B3FBF" },
  gym: { stops: ["#3A4252", "#6E7C93", "#AFC0D6"], glow: "#8FA7CC" },
  street: { stops: ["#C9A583", "#E8D6B8", "#BFD8F0"], glow: "#FFE7BE" },
  night: { stops: ["#0C1020", "#1B2340", "#2E3A63"], glow: "#3C4A80" },
  jail: { stops: ["#22262E", "#3A414C", "#59636F"], glow: "#4E5966" },
  space: { stops: ["#05070F", "#0B1020", "#161E38"], glow: "#1E2A4D" },
  wheel: { stops: ["#14082A", "#2A1052", "#4A1D7A"], glow: "#C77DFF" },
  mars: { stops: ["#4A1E0C", "#A8501F", "#E8A063"], glow: "#FF9A5E" },
};

const VERT = /* glsl */ `
  varying vec3 vPos;
  void main() {
    vPos = position;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const FRAG = /* glsl */ `
  varying vec3 vPos;
  uniform vec3 low;
  uniform vec3 mid;
  uniform vec3 high;
  uniform vec3 glow;

  void main() {
    // normalised height across the dome
    float h = clamp(vPos.y / 30.0 + 0.5, 0.0, 1.0);

    // two-stage ramp: low -> mid -> high
    vec3 col = h < 0.5
      ? mix(low, mid, smoothstep(0.0, 0.5, h))
      : mix(mid, high, smoothstep(0.5, 1.0, h));

    // soft radial glow behind the subject, centred slightly above the horizon
    float d = length(vec2(vPos.x, vPos.y - 2.0)) / 26.0;
    col += glow * (1.0 - smoothstep(0.0, 1.0, d)) * 0.28;

    gl_FragColor = vec4(col, 1.0);
    #include <colorspace_fragment>
  }
`;

export function Backdrop3D() {
  const map = useStore((s) => s.map);
  const sky = SKIES[map] ?? SKIES.home;

  const material = useMemo(() => {
    return new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        low: { value: new THREE.Color(sky.stops[0]) },
        mid: { value: new THREE.Color(sky.stops[1]) },
        high: { value: new THREE.Color(sky.stops[2]) },
        glow: { value: new THREE.Color(sky.glow) },
      },
    });
    // rebuilt whenever the palette changes
  }, [sky.stops, sky.glow]);

  // release the previous dome's GPU program when the map changes
  useEffect(() => () => material.dispose(), [material]);

  return (
    <mesh material={material} renderOrder={-1000} frustumCulled={false}>
      <sphereGeometry args={[60, 32, 24]} />
    </mesh>
  );
}
