import { useFrame } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { strokeTextGeometry } from "./strokeFont";

/**
 * A real neon sign: the word is swept tube geometry (bent glass), lit by an
 * emissive core, wrapped in a translucent outer tube for the halo, and backed
 * by actual point lights so it spills colour onto the room. No decals, no
 * painted textures.
 */
export function NeonSign({
  text = "Jeeko",
  position = [0, 0, 0],
  scale = 1,
  color = "#FF2D95",
  color2 = "#00E5FF",
}: {
  text?: string;
  position?: [number, number, number];
  scale?: number;
  color?: string;
  color2?: string;
}) {
  const core = useRef<THREE.MeshStandardMaterial>(null);
  const halo = useRef<THREE.MeshBasicMaterial>(null);
  const lamp = useRef<THREE.PointLight>(null);
  const flickerRef = useRef(1);

  const tube = useMemo(() => strokeTextGeometry(text, 0.052, 10), [text]);
  const glow = useMemo(() => strokeTextGeometry(text, 0.1, 8), [text]);

  useEffect(
    () => () => {
      tube.geometry.dispose();
      glow.geometry.dispose();
    },
    [tube, glow],
  );

  useFrame((state) => {
    const t = state.clock.elapsedTime;

    // gentle breathing plus an occasional authentic gas flicker
    const breathe = 0.88 + Math.sin(t * 1.7) * 0.12;
    const spark = Math.sin(t * 37) > 0.97 || Math.sin(t * 53 + 1.2) > 0.985 ? 0.45 : 1;
    flickerRef.current = THREE.MathUtils.lerp(flickerRef.current, breathe * spark, 0.4);
    const v = flickerRef.current;

    if (core.current) core.current.emissiveIntensity = 4.2 * v;
    if (halo.current) halo.current.opacity = 0.26 * v;
    if (lamp.current) lamp.current.intensity = 13 * v;
  });

  const w = tube.width;

  return (
    <group position={position} scale={scale}>
      {/* ---- backing board ---- */}
      <mesh position={[0, 0.06, -0.16]} castShadow receiveShadow>
        <boxGeometry args={[w + 0.9, 1.5, 0.14]} />
        <meshStandardMaterial color="#141024" roughness={0.72} metalness={0.28} />
      </mesh>
      {/* board bevel */}
      <mesh position={[0, 0.06, -0.09]}>
        <boxGeometry args={[w + 0.72, 1.32, 0.02]} />
        <meshStandardMaterial color="#1E1734" roughness={0.55} metalness={0.4} />
      </mesh>

      {/* ---- marquee bulbs around the frame ---- */}
      <FrameBulbs w={w + 0.82} h={1.42} />

      {/* ---- the glowing word ---- */}
      <group position={[0, 0.06, 0]}>
        {/* soft halo shell */}
        <mesh geometry={glow.geometry}>
          <meshBasicMaterial
            ref={halo}
            color={color}
            transparent
            opacity={0.2}
            depthWrite={false}
            toneMapped={false}
          />
        </mesh>
        {/* glass core */}
        <mesh geometry={tube.geometry} castShadow>
          <meshStandardMaterial
            ref={core}
            color="#FFFFFF"
            emissive={color}
            emissiveIntensity={3.4}
            roughness={0.22}
            metalness={0.1}
            toneMapped={false}
          />
        </mesh>
      </group>

      {/* ---- accent underline tube ---- */}
      <mesh position={[0, -0.56, 0]} rotation={[0, 0, Math.PI / 2]}>
        <capsuleGeometry args={[0.035, w * 0.86, 4, 10]} />
        <meshStandardMaterial
          color="#FFFFFF"
          emissive={color2}
          emissiveIntensity={2.6}
          roughness={0.25}
          toneMapped={false}
        />
      </mesh>

      {/* ---- light spill into the room ---- */}
      <pointLight ref={lamp} position={[0, 0.1, 0.7]} intensity={10} distance={7} color={color} />
      <pointLight position={[0, -0.5, 0.5]} intensity={4} distance={4.5} color={color2} />
    </group>
  );
}

/** Chasing bulbs running around the sign frame. */
function FrameBulbs({ w, h }: { w: number; h: number }) {
  const group = useRef<THREE.Group>(null);

  const spots = useMemo(() => {
    const out: [number, number][] = [];
    const nx = Math.max(6, Math.round(w / 0.3));
    const ny = Math.max(3, Math.round(h / 0.3));
    for (let i = 0; i < nx; i++) {
      const x = -w / 2 + (w * i) / (nx - 1);
      out.push([x, h / 2]);
      out.push([x, -h / 2]);
    }
    for (let i = 1; i < ny - 1; i++) {
      const y = -h / 2 + (h * i) / (ny - 1);
      out.push([-w / 2, y]);
      out.push([w / 2, y]);
    }
    return out;
  }, [w, h]);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (!group.current) return;
    group.current.children.forEach((c, i) => {
      const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
      // a wave chasing around the frame
      m.emissiveIntensity = 0.35 + Math.max(0, Math.sin(t * 3.4 - i * 0.55)) * 3.1;
    });
  });

  return (
    <group ref={group} position={[0, 0.06, 0.02]}>
      {spots.map(([x, y], i) => (
        <mesh key={i} position={[x, y, 0]}>
          <sphereGeometry args={[0.045, 10, 8]} />
          <meshStandardMaterial
            color="#FFF6D8"
            emissive="#FFD166"
            emissiveIntensity={2}
            toneMapped={false}
          />
        </mesh>
      ))}
    </group>
  );
}
