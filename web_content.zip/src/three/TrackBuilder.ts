import * as THREE from 'three';
import { LevelConfig } from '../types/game';

export interface BuiltTrack {
  group: THREE.Group;
  curve: THREE.CatmullRomCurve3;
  totalLength: number;
  trackWidth: number;
  boostPads: Array<{ t: number; lateral: number; position: THREE.Vector3 }>;
  dispose: () => void;
}

const _up = new THREE.Vector3(0, 1, 0);
const _tangent = new THREE.Vector3();
const _binormal = new THREE.Vector3();
const _normal = new THREE.Vector3();
const _pt = new THREE.Vector3();
const _dummy = new THREE.Object3D();
const _color = new THREE.Color();

function createSkyDomeTexture(skyHex: string, fogHex: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Vertical sky gradient from zenith to misty horizon
  const grad = ctx.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0, skyHex);
  grad.addColorStop(0.48, fogHex);
  grad.addColorStop(0.58, fogHex);
  grad.addColorStop(1, '#1e293b');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 1024, 512);

  // Soft realistic cumulus clouds across upper hemisphere (y: 60..240)
  for (let i = 0; i < 65; i++) {
    const cx = (i * 97) % 1024;
    const cy = 65 + ((i * 53) % 155);
    const rx = 45 + ((i * 29) % 85);
    const ry = 14 + ((i * 19) % 26);

    const cloudGrad = ctx.createRadialGradient(cx, cy, 4, cx, cy, rx);
    cloudGrad.addColorStop(0, 'rgba(255, 255, 255, 0.52)');
    cloudGrad.addColorStop(0.5, 'rgba(248, 250, 252, 0.24)');
    cloudGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = cloudGrad;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(1, ry / rx);
    ctx.beginPath();
    ctx.arc(0, 0, rx, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Distant mountain silhouette band along the horizon (y: 245..285)
  ctx.fillStyle = 'rgba(51, 65, 85, 0.35)';
  ctx.beginPath();
  ctx.moveTo(0, 285);
  for (let x = 0; x <= 1024; x += 32) {
    const peak = 252 + Math.sin(x * 0.018) * 14 + Math.cos(x * 0.045) * 9;
    ctx.lineTo(x, peak);
  }
  ctx.lineTo(1024, 285);
  ctx.closePath();
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createProceduralAsphaltTexture(
  renderer: THREE.WebGLRenderer,
  asphaltHex: string,
  curbPrimaryHex: string,
  curbSecondaryHex: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  // Base asphalt grain
  ctx.fillStyle = asphaltHex;
  ctx.fillRect(0, 0, 1024, 1024);

  // High-density aggregate stone micro-texture
  for (let i = 0; i < 10000; i++) {
    const x = Math.random() * 1024;
    const y = Math.random() * 1024;
    const isLight = Math.random() > 0.52;
    ctx.fillStyle = isLight ? 'rgba(255,255,255,0.045)' : 'rgba(0,0,0,0.08)';
    ctx.fillRect(x, y, 2 + Math.random() * 2, 2 + Math.random() * 2);
  }

  // Dark Continuous Rubbered Racing Line Groove
  const grooveGrad = ctx.createLinearGradient(0, 0, 1024, 0);
  grooveGrad.addColorStop(0, 'rgba(0,0,0,0)');
  grooveGrad.addColorStop(0.32, 'rgba(10, 12, 16, 0.38)');
  grooveGrad.addColorStop(0.5, 'rgba(5, 7, 10, 0.58)');
  grooveGrad.addColorStop(0.68, 'rgba(10, 12, 16, 0.38)');
  grooveGrad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grooveGrad;
  ctx.fillRect(0, 0, 1024, 1024);

  // Left & Right FIA Rumble Kerbs
  const stripeCount = 16;
  const stripeH = 1024 / stripeCount;
  for (let i = 0; i < stripeCount; i++) {
    ctx.fillStyle = i % 2 === 0 ? curbPrimaryHex : curbSecondaryHex;
    ctx.fillRect(0, i * stripeH, 42, stripeH);
    ctx.fillRect(1024 - 42, i * stripeH, 42, stripeH);
  }

  // Crisp White FIA Track Boundary Edge Lines (like Photo 1)
  ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
  ctx.fillRect(46, 0, 12, 1024);
  ctx.fillRect(1024 - 58, 0, 12, 1024);

  // Subtle Highway / Multi-Lane Dashed Guidelines (like Photo 2)
  ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
  for (let i = 0; i < 8; i++) {
    ctx.fillRect(507, i * 128 + 28, 10, 68);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(1, 320);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
  return texture;
}

/**
 * Replicates the exact Checkered Start/Finish Line + Yellow Transponder Line +
 * "THUNDERBOLT MOTOR RACEWAY" Painted Asphalt Stencil from Reference Photo 1!
 */
function createStartFinishAsphaltDecalTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, 1024, 1024);

  // 1. White Border Lines around Checkered Box (Bottom of texture = Start Line)
  ctx.fillStyle = '#F8FAFC';
  ctx.fillRect(20, 620, 984, 14);
  ctx.fillRect(20, 960, 984, 14);

  // 2. 4-Row Black & White Checkered Start/Finish Pad (y: 634..960)
  const rows = 4;
  const cols = 16;
  const cellW = 984 / cols;
  const cellH = (960 - 634) / rows;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      ctx.fillStyle = (r + c) % 2 === 0 ? '#F8FAFC' : '#0f1319';
      ctx.fillRect(20 + c * cellW, 634 + r * cellH, cellW, cellH);
    }
  }

  // 3. Vibrant Yellow Timing Transponder Line across the middle of the Checkered Pad (Exact Photo 1 detail!)
  ctx.fillStyle = '#FACC15';
  ctx.fillRect(20, 786, 984, 22);

  // 4. Giant Painted Asphalt Typography ahead of Start Line ("THUNDERBOLT MOTOR RACEWAY")
  ctx.save();
  // Red & Dark Checkered Speed Blocks on Left
  ctx.fillStyle = '#DC2626';
  ctx.fillRect(75, 220, 68, 42);
  ctx.fillRect(55, 360, 88, 52);
  ctx.fillStyle = '#111827';
  ctx.fillRect(155, 220, 56, 42);
  ctx.fillRect(85, 285, 64, 48);
  ctx.fillRect(165, 285, 64, 48);

  // Giant Charcoal Stencil Letters on Asphalt
  ctx.fillStyle = 'rgba(17, 24, 39, 0.78)';
  ctx.font = 'italic 900 94px "Chakra Petch", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('THUNDERBOLT', 575, 305);

  ctx.font = 'italic 900 66px "Chakra Petch", sans-serif';
  ctx.fillText('M O T O R   R A C E W A Y', 575, 395);
  ctx.restore();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

/**
 * Replicates the Black Overhead "SPEED" Flame/Turbo Billboard from Reference Photo 1
 */
function createSpeedGantryTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 192;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#07090d';
  ctx.fillRect(0, 0, 1024, 192);

  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 8;
  ctx.strokeRect(4, 4, 1016, 184);

  for (const cx of [270, 754]) {
    // Red racing flame & turbo wheel emblem
    ctx.fillStyle = '#DC2626';
    ctx.beginPath();
    ctx.moveTo(cx - 165, 96);
    ctx.quadraticCurveTo(cx - 110, 35, cx - 45, 55);
    ctx.lineTo(cx - 45, 135);
    ctx.quadraticCurveTo(cx - 115, 145, cx - 165, 96);
    ctx.fill();

    // Wheel circle
    ctx.beginPath();
    ctx.arc(cx - 55, 98, 34, 0, Math.PI * 2);
    ctx.fillStyle = '#991B1B';
    ctx.fill();
    ctx.strokeStyle = '#EF4444';
    ctx.lineWidth = 4;
    ctx.stroke();

    // Bold "SPEED" typography
    ctx.fillStyle = '#CBD5E1';
    ctx.font = 'italic 900 54px "Chakra Petch", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText('SPEED', cx - 10, 108);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createSponsorBannerTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  const sponsors = [
    { name: 'THUNDERBOLT', bg: '#F8FAFC', text: '#0F172A' },
    { name: 'GRAND PRIX', bg: '#DC2626', text: '#F8FAFC' },
    { name: 'ANTARCTIC', bg: '#0284C7', text: '#F8FAFC' },
    { name: 'SPEED', bg: '#090D16', text: '#EF4444' },
    { name: 'PIRELLI', bg: '#FACC15', text: '#DC2626' },
    { name: 'BREMBO', bg: '#991B1B', text: '#F8FAFC' },
  ];

  const w = 1024 / sponsors.length;
  sponsors.forEach((sp, idx) => {
    ctx.fillStyle = sp.bg;
    ctx.fillRect(idx * w, 0, w, 128);

    ctx.strokeStyle = 'rgba(0,0,0,0.2)';
    ctx.lineWidth = 4;
    ctx.strokeRect(idx * w + 3, 3, w - 6, 122);

    ctx.font = 'italic 900 28px "Chakra Petch", sans-serif';
    ctx.fillStyle = sp.text;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(sp.name, idx * w + w / 2, 64);
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(8, 1);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

/**
 * Silver Diamond Chain-Link Debris Catch Fence Texture (Matches Photo 1 Trackside Fencing!)
 */
function createChainlinkFenceTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, 256, 256);

  // Diagonal wire mesh
  ctx.strokeStyle = 'rgba(203, 213, 225, 0.65)';
  ctx.lineWidth = 2;
  const step = 16;
  for (let i = -256; i < 512; i += step) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i + 256, 256);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(i + 256, 0);
    ctx.lineTo(i, 256);
    ctx.stroke();
  }

  // Vertical fence posts & horizontal tension bars
  ctx.fillStyle = '#94a3b8';
  ctx.fillRect(0, 0, 12, 256);
  ctx.fillRect(0, 0, 256, 10);
  ctx.fillRect(0, 124, 256, 6);
  ctx.fillRect(0, 246, 256, 10);

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(28, 1);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Red & Blue Stadium Bucket Seats + Standing Spectator Crowd (Matches Photo 1 Grandstand!)
 */
function createGrandstandSeatingTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  // Concrete step background
  ctx.fillStyle = '#475569';
  ctx.fillRect(0, 0, 512, 256);

  // Alternating Red & Blue Stadium Seating Blocks
  for (let row = 0; row < 8; row++) {
    const y = row * 32;
    ctx.fillStyle = '#334155';
    ctx.fillRect(0, y, 512, 8);

    for (let col = 0; col < 32; col++) {
      const x = col * 16;
      const isBlueBlock = col >= 8 && col < 22;
      ctx.fillStyle = isBlueBlock ? '#1d4ed8' : '#dc2626';
      ctx.fillRect(x + 2, y + 8, 12, 20);

      // Spectator figure in seat
      if ((row + col * 3) % 2 === 0) {
        const shirtColors = ['#f8fafc', '#facc15', '#38bdf8', '#ef4444', '#10b981', '#f97316'];
        ctx.fillStyle = shirtColors[(row * 7 + col * 5) % shirtColors.length];
        ctx.fillRect(x + 4, y + 6, 8, 14);
        ctx.fillStyle = '#fcd34d';
        ctx.beginPath();
        ctx.arc(x + 8, y + 4, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(5, 1);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function sampleTrackFrame(
  curve: THREE.CatmullRomCurve3,
  t: number,
  outPos: THREE.Vector3,
  outTangent: THREE.Vector3,
  outRight: THREE.Vector3
) {
  const wrappedT = ((t % 1) + 1) % 1;
  curve.getPointAt(wrappedT, outPos);
  curve.getTangentAt(wrappedT, outTangent).normalize();
  outRight.crossVectors(outTangent, _up).normalize();
}

export function buildLevelTrack(
  level: LevelConfig,
  renderer: THREE.WebGLRenderer,
  isSoftwareGl: boolean
): BuiltTrack {
  const group = new THREE.Group();
  const disposables: Array<{ dispose: () => void }> = [];

  const points = level.waypoints.map(([x, y, z]) => new THREE.Vector3(x, y, z));
  const curve = new THREE.CatmullRomCurve3(points, true, 'catmullrom', 0.5);
  const totalLength = curve.getLength();

  // 0. Realistic Atmospheric Sky Dome with Cumulus Clouds & Horizon Mountains
  const skyDomeGeo = new THREE.SphereGeometry(2500, 32, 20);
  const skyDomeTex = createSkyDomeTexture(level.skyColorHex, level.fogColorHex);
  const skyDomeMat = new THREE.MeshBasicMaterial({
    map: skyDomeTex,
    side: THREE.BackSide,
    fog: false,
    depthWrite: false,
  });
  const skyDome = new THREE.Mesh(skyDomeGeo, skyDomeMat);
  skyDome.position.set(350, 0, -250);
  group.add(skyDome);
  disposables.push(skyDomeGeo, skyDomeTex, skyDomeMat);

  // 1. Expansive Natural Valley Terrain Plane (8,000m x 8,000m)
  const groundGeo = new THREE.PlaneGeometry(8000, 8000);
  const groundMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(level.groundColorHex),
    roughness: 0.94,
    metalness: 0.04,
  });
  const groundMesh = new THREE.Mesh(groundGeo, groundMat);
  groundMesh.rotation.x = -Math.PI / 2;
  groundMesh.position.y = -0.18;
  groundMesh.receiveShadow = !isSoftwareGl;
  group.add(groundMesh);
  disposables.push(groundGeo, groundMat);

  // 2. High-Resolution 900-Segment Continuous Track Ribbon along the ~4.5 km Grand Prix Circuit
  const segments = 900;
  const halfW = level.trackWidth * 0.5;
  const positions = new Float32Array((segments + 1) * 2 * 3);
  const normals = new Float32Array((segments + 1) * 2 * 3);
  const uvs = new Float32Array((segments + 1) * 2 * 2);
  const indices: number[] = [];

  for (let i = 0; i <= segments; i++) {
    const u = i / segments;
    curve.getPointAt(u % 1, _pt);
    curve.getTangentAt(u % 1, _tangent).normalize();
    _binormal.crossVectors(_tangent, _up).normalize();
    _normal.crossVectors(_binormal, _tangent).normalize();

    const leftX = _pt.x - _binormal.x * halfW;
    const leftY = _pt.y + 0.04;
    const leftZ = _pt.z - _binormal.z * halfW;

    const rightX = _pt.x + _binormal.x * halfW;
    const rightY = _pt.y + 0.04;
    const rightZ = _pt.z + _binormal.z * halfW;

    const vIdx = i * 6;
    positions[vIdx] = leftX;
    positions[vIdx + 1] = leftY;
    positions[vIdx + 2] = leftZ;
    positions[vIdx + 3] = rightX;
    positions[vIdx + 4] = rightY;
    positions[vIdx + 5] = rightZ;

    normals[vIdx] = 0;
    normals[vIdx + 1] = 1;
    normals[vIdx + 2] = 0;
    normals[vIdx + 3] = 0;
    normals[vIdx + 4] = 1;
    normals[vIdx + 5] = 0;

    const uvIdx = i * 4;
    uvs[uvIdx] = 0;
    uvs[uvIdx + 1] = u;
    uvs[uvIdx + 2] = 1;
    uvs[uvIdx + 3] = u;

    if (i < segments) {
      const a = i * 2;
      const b = i * 2 + 1;
      const c = (i + 1) * 2;
      const d = (i + 1) * 2 + 1;
      indices.push(a, b, c, b, d, c);
    }
  }

  const roadGeo = new THREE.BufferGeometry();
  roadGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  roadGeo.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
  roadGeo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  roadGeo.setIndex(indices);
  roadGeo.computeBoundingSphere();

  const asphaltTex = createProceduralAsphaltTexture(
    renderer,
    level.asphaltColorHex,
    level.curbPrimaryHex,
    level.curbSecondaryHex
  );
  const roadMat = new THREE.MeshStandardMaterial({
    map: asphaltTex,
    roughness: 0.54,
    metalness: 0.14,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });

  const roadMesh = new THREE.Mesh(roadGeo, roadMat);
  roadMesh.receiveShadow = !isSoftwareGl;
  group.add(roadMesh);
  disposables.push(roadGeo, roadMat, asphaltTex);

  // 3. Continuous Double-Sided W-Beam Steel Highway & Circuit Guardrails (320 segments per side)
  const armcoCount = 320;
  const armcoRailGeo = new THREE.BoxGeometry(0.22, 0.82, (totalLength / armcoCount) * 0.92);
  const armcoMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    metalness: 0.82,
    roughness: 0.3,
  });

  const armcoInstanced = new THREE.InstancedMesh(armcoRailGeo, armcoMat, armcoCount * 2);
  armcoInstanced.castShadow = !isSoftwareGl;
  armcoInstanced.receiveShadow = !isSoftwareGl;

  for (let i = 0; i < armcoCount; i++) {
    const t = i / armcoCount;
    const right = new THREE.Vector3();
    sampleTrackFrame(curve, t, _pt, _tangent, right);

    // Left guardrail
    const leftPos = _pt.clone().addScaledVector(right, -halfW - 1.5);
    _dummy.position.set(leftPos.x, _pt.y + 0.45, leftPos.z);
    _dummy.lookAt(leftPos.clone().add(_tangent));
    _dummy.scale.set(1, 1, 1);
    _dummy.updateMatrix();
    armcoInstanced.setMatrixAt(i * 2, _dummy.matrix);

    // Right guardrail
    const rightPos = _pt.clone().addScaledVector(right, halfW + 1.5);
    _dummy.position.set(rightPos.x, _pt.y + 0.45, rightPos.z);
    _dummy.lookAt(rightPos.clone().add(_tangent));
    _dummy.scale.set(1, 1, 1);
    _dummy.updateMatrix();
    armcoInstanced.setMatrixAt(i * 2 + 1, _dummy.matrix);
  }
  armcoInstanced.instanceMatrix.needsUpdate = true;
  armcoInstanced.computeBoundingSphere();
  group.add(armcoInstanced);
  disposables.push(armcoRailGeo, armcoMat);

  // 4. THUNDERBOLT MOTOR RACEWAY STADIUM COMPLEX ON MAIN STRAIGHT (Matches Reference Photo 1!)
  const startGroup = new THREE.Group();
  curve.getPointAt(0, _pt);
  curve.getTangentAt(0, _tangent).normalize();
  startGroup.position.copy(_pt);
  startGroup.lookAt(_pt.clone().add(_tangent));

  const steelMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    metalness: 0.85,
    roughness: 0.25,
  });
  const concreteMat = new THREE.MeshStandardMaterial({
    color: 0x64748b,
    roughness: 0.75,
    metalness: 0.1,
  });
  const darkMetalMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.7,
    roughness: 0.35,
  });

  // 4A. Checkered Start/Finish Pad + Yellow Transponder Line + "THUNDERBOLT MOTOR RACEWAY" Asphalt Decal
  const startDecalGeo = new THREE.PlaneGeometry(level.trackWidth * 0.9, 26);
  const startDecalTex = createStartFinishAsphaltDecalTexture();
  const startDecalMat = new THREE.MeshBasicMaterial({
    map: startDecalTex,
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -3,
    polygonOffsetUnits: -3,
  });
  const startDecalMesh = new THREE.Mesh(startDecalGeo, startDecalMat);
  startDecalMesh.rotation.x = -Math.PI / 2;
  startDecalMesh.position.set(0, 0.08, 12);
  startGroup.add(startDecalMesh);
  disposables.push(startDecalGeo, startDecalTex, startDecalMat);

  // 4B. Overhead Steel Truss Starting Gantry + "SPEED" Billboard + Dual 5-Light Green/Red Signal Pods
  const gantrySpan = level.trackWidth + 5.0;
  const gantryHeight = 8.6;
  const pylonGeo = new THREE.BoxGeometry(0.45, gantryHeight, 0.45);
  const leftPylon = new THREE.Mesh(pylonGeo, steelMat);
  leftPylon.position.set(-gantrySpan * 0.5, gantryHeight * 0.5, 16);
  const rightPylon = new THREE.Mesh(pylonGeo, steelMat);
  rightPylon.position.set(gantrySpan * 0.5, gantryHeight * 0.5, 16);

  const topTrussGeo = new THREE.BoxGeometry(gantrySpan + 0.6, 0.38, 0.45);
  const topTrussUpper = new THREE.Mesh(topTrussGeo, steelMat);
  topTrussUpper.position.set(0, gantryHeight, 16);
  const topTrussLower = new THREE.Mesh(topTrussGeo, steelMat);
  topTrussLower.position.set(0, gantryHeight - 2.3, 16);

  // Large Black "SPEED" Flame/Turbo Billboard mounted inside the Gantry Frame
  const speedBoardGeo = new THREE.BoxGeometry(gantrySpan - 2.2, 2.1, 0.25);
  const speedBoardTex = createSpeedGantryTexture();
  const speedBoardMat = new THREE.MeshStandardMaterial({
    map: speedBoardTex,
    roughness: 0.3,
  });
  const speedBoard = new THREE.Mesh(speedBoardGeo, speedBoardMat);
  speedBoard.position.set(0, gantryHeight - 1.15, 16);
  startGroup.add(leftPylon, rightPylon, topTrussUpper, topTrussLower, speedBoard);
  disposables.push(pylonGeo, topTrussGeo, speedBoardGeo, speedBoardTex, speedBoardMat);

  // Suspended Signal Bar with Two Pods of 5 Glowing Green Race Lights (● ● ● ● ●   ● ● ● ● ●)
  const signalBarGeo = new THREE.BoxGeometry(10.5, 0.18, 0.18);
  const signalBar = new THREE.Mesh(signalBarGeo, steelMat);
  signalBar.position.set(0, gantryHeight - 2.9, 16);
  startGroup.add(signalBar);

  const lightHousingGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.36, 14);
  lightHousingGeo.rotateX(Math.PI / 2);
  const greenLensGeo = new THREE.SphereGeometry(0.19, 12, 12);
  const greenSignalMat = new THREE.MeshStandardMaterial({
    color: 0x22c55e,
    emissive: 0x16a34a,
    emissiveIntensity: 3.8,
    roughness: 0.15,
  });

  for (const podCenter of [-2.6, 2.6]) {
    for (let l = -2; l <= 2; l++) {
      const lx = podCenter + l * 0.56;
      const housing = new THREE.Mesh(lightHousingGeo, darkMetalMat);
      housing.position.set(lx, gantryHeight - 3.3, 16);
      const lens = new THREE.Mesh(greenLensGeo, greenSignalMat);
      lens.position.set(lx, gantryHeight - 3.3, 15.84);
      startGroup.add(housing, lens);
    }
  }
  disposables.push(signalBarGeo, lightHousingGeo, greenLensGeo, greenSignalMat);

  // 4C. Trackside Chain-Link Debris Catch Fencing + Concrete Base Walls + Colorful Sponsor Hoardings
  const straightLen = 280;
  const fenceWallGeo = new THREE.BoxGeometry(0.5, 1.1, straightLen);
  const sponsorStripGeo = new THREE.PlaneGeometry(straightLen, 1.0);
  const sponsorTex = createSponsorBannerTexture();
  const sponsorMat = new THREE.MeshStandardMaterial({
    map: sponsorTex,
    roughness: 0.4,
  });

  const fenceMeshGeo = new THREE.PlaneGeometry(straightLen, 3.2);
  const fenceTex = createChainlinkFenceTexture();
  const fenceMat = new THREE.MeshBasicMaterial({
    map: fenceTex,
    transparent: true,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  for (const side of [-1, 1]) {
    const wallX = side * (halfW + 1.6);
    const wall = new THREE.Mesh(fenceWallGeo, concreteMat);
    wall.position.set(wallX, 0.55, 45);

    const hoarding = new THREE.Mesh(sponsorStripGeo, sponsorMat);
    hoarding.position.set(wallX - side * 0.27, 0.58, 45);
    hoarding.rotation.y = side === 1 ? -Math.PI / 2 : Math.PI / 2;

    const catchFence = new THREE.Mesh(fenceMeshGeo, fenceMat);
    catchFence.position.set(wallX, 2.65, 45);
    catchFence.rotation.y = side === 1 ? -Math.PI / 2 : Math.PI / 2;

    startGroup.add(wall, hoarding, catchFence);
  }
  disposables.push(fenceWallGeo, sponsorStripGeo, sponsorTex, sponsorMat, fenceMeshGeo, fenceTex, fenceMat);

  // 4D. Left Side: Multi-Story Pit Lane Garages + Sloped Blue Glass VIP Suites + Race Control Tower
  const pitBuildingGroup = new THREE.Group();
  pitBuildingGroup.position.set(-halfW - 11.5, 0, 45);

  // Ground-floor Pit Garages
  const garageBlockGeo = new THREE.BoxGeometry(12, 4.5, 180);
  const garageBlock = new THREE.Mesh(garageBlockGeo, concreteMat);
  garageBlock.position.set(0, 2.25, 0);
  pitBuildingGroup.add(garageBlock);

  // Sloped 2nd-Story Reflective Sky-Blue Glass Curtain Wall (Exact Photo 1 left building!)
  const blueGlassMat = new THREE.MeshPhysicalMaterial({
    color: 0x38bdf8,
    metalness: 0.35,
    roughness: 0.08,
    clearcoat: 1.0,
  });
  const glassFacadeGeo = new THREE.BoxGeometry(11.5, 3.8, 176);
  const glassFacade = new THREE.Mesh(glassFacadeGeo, blueGlassMat);
  glassFacade.position.set(0.8, 6.2, 0);
  glassFacade.rotation.z = -0.18;
  pitBuildingGroup.add(glassFacade);

  // 4-Story Concrete & Glass Race Control Tower with Cantilevered Roof
  const towerCoreGeo = new THREE.BoxGeometry(14, 17.5, 22);
  const towerCore = new THREE.Mesh(towerCoreGeo, concreteMat);
  towerCore.position.set(-1.5, 8.75, -18);
  const towerRoofGeo = new THREE.BoxGeometry(17, 0.5, 26);
  const towerRoof = new THREE.Mesh(towerRoofGeo, darkMetalMat);
  towerRoof.position.set(0, 17.6, -18);
  pitBuildingGroup.add(towerCore, towerRoof);

  startGroup.add(pitBuildingGroup);
  disposables.push(garageBlockGeo, blueGlassMat, glassFacadeGeo, towerCoreGeo, towerRoofGeo);

  // 4E. Right Side: Massive Multi-Tier Concrete Spectator Grandstand with Red/Blue Seats & Roof
  const grandstandGroup = new THREE.Group();
  grandstandGroup.position.set(halfW + 15.5, 0, 55);

  const gsDeckGeo = new THREE.BoxGeometry(18, 9.5, 210);
  const gsDeck = new THREE.Mesh(gsDeckGeo, concreteMat);
  gsDeck.position.set(2, 4.75, 0);

  // Sloped Red & Blue Stadium Seating Bank facing the track
  const seatingGeo = new THREE.PlaneGeometry(206, 11.5);
  const seatingTex = createGrandstandSeatingTexture();
  const seatingMat = new THREE.MeshBasicMaterial({ map: seatingTex });
  const seatingBank = new THREE.Mesh(seatingGeo, seatingMat);
  seatingBank.position.set(-4.2, 5.4, 0);
  seatingBank.rotation.y = -Math.PI / 2;
  seatingBank.rotation.x = 0.42;

  // Upper Concrete Cantilevered Stadium Roof + Support Columns
  const gsRoofGeo = new THREE.BoxGeometry(22, 0.85, 214);
  const gsRoof = new THREE.Mesh(gsRoofGeo, concreteMat);
  gsRoof.position.set(0, 15.2, 0);
  gsRoof.rotation.z = 0.14;

  const colGeo = new THREE.CylinderGeometry(0.32, 0.32, 10.5, 8);
  for (let z = -90; z <= 90; z += 30) {
    const col = new THREE.Mesh(colGeo, darkMetalMat);
    col.position.set(-5.5, 10.2, z);
    col.rotation.z = -0.15;
    grandstandGroup.add(col);
  }

  grandstandGroup.add(gsDeck, seatingBank, gsRoof);
  startGroup.add(grandstandGroup);
  disposables.push(gsDeckGeo, seatingGeo, seatingTex, seatingMat, gsRoofGeo, colGeo);

  // 4F. Down-Track Yellow & Red Secondary Sponsor Bridge + Tall Red/White Timing Pylon Tower
  const bridgeZ = 185;
  const bridgeBeamGeo = new THREE.BoxGeometry(gantrySpan + 4, 2.0, 1.8);
  const bridgeYellowMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.4 });
  const bridgeRedMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.4 });
  const bridgeLeft = new THREE.Mesh(
    new THREE.BoxGeometry((gantrySpan + 4) * 0.5, 2.0, 1.8),
    bridgeYellowMat
  );
  bridgeLeft.position.set(-(gantrySpan + 4) * 0.25, 7.2, bridgeZ);
  const bridgeRight = new THREE.Mesh(
    new THREE.BoxGeometry((gantrySpan + 4) * 0.5, 2.0, 1.8),
    bridgeRedMat
  );
  bridgeRight.position.set((gantrySpan + 4) * 0.25, 7.2, bridgeZ);

  // Tall Red/White Vertical Leaderboard Pylon Tower in the background
  const pylonTowerGeo = new THREE.BoxGeometry(2.8, 26, 2.8);
  const pylonTower = new THREE.Mesh(pylonTowerGeo, bridgeRedMat);
  pylonTower.position.set(halfW + 9, 13, 240);

  startGroup.add(bridgeLeft, bridgeRight, pylonTower);
  group.add(startGroup);
  disposables.push(bridgeBeamGeo, bridgeYellowMat, bridgeRedMat, pylonTowerGeo, steelMat, concreteMat, darkMetalMat);

  // 5. Distance Braking Marker Boards (300m, 200m, 150m, 100m, 50m)
  const markerDistances = [0.08, 0.1, 0.115, 0.13, 0.145];
  const boardGeo = new THREE.BoxGeometry(0.14, 1.2, 1.6);
  const boardMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.4 });
  const postGeo = new THREE.CylinderGeometry(0.05, 0.05, 1.5, 8);

  markerDistances.forEach((mt) => {
    const mPos = new THREE.Vector3();
    const mTan = new THREE.Vector3();
    const mRight = new THREE.Vector3();
    sampleTrackFrame(curve, mt, mPos, mTan, mRight);

    const bp = mPos.addScaledVector(mRight, halfW + 2.6);
    const board = new THREE.Mesh(boardGeo, boardMat);
    board.position.set(bp.x, mPos.y + 1.25, bp.z);
    board.lookAt(bp.clone().add(mTan));

    const post = new THREE.Mesh(postGeo, steelMat);
    post.position.set(bp.x, mPos.y + 0.7, bp.z);
    group.add(board, post);
  });
  disposables.push(boardGeo, boardMat, postGeo);

  // 6. Nitro Boost Chevron Pads along the 4.5 km Circuit
  const boostPads: Array<{ t: number; lateral: number; position: THREE.Vector3 }> = [];
  const boostTs = [0.12, 0.24, 0.38, 0.52, 0.68, 0.84];
  const padGeo = new THREE.PlaneGeometry(3.2, 8.5);
  const padMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4,
    emissive: 0x06b6d4,
    emissiveIntensity: 2.4,
    roughness: 0.2,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });

  boostTs.forEach((bt, idx) => {
    const lat = idx % 2 === 0 ? -halfW * 0.35 : halfW * 0.35;
    const pos = new THREE.Vector3();
    const tan = new THREE.Vector3();
    const right = new THREE.Vector3();
    sampleTrackFrame(curve, bt, pos, tan, right);
    pos.addScaledVector(right, lat);

    const padMesh = new THREE.Mesh(padGeo, padMat);
    padMesh.position.set(pos.x, pos.y + 0.08, pos.z);
    const lookTarget = pos.clone().add(tan);
    padMesh.lookAt(lookTarget.x, pos.y + 0.08, lookTarget.z);
    padMesh.rotateX(-Math.PI / 2);
    group.add(padMesh);

    boostPads.push({ t: bt, lateral: lat, position: pos });
  });
  disposables.push(padGeo, padMat);

  // 7. Realistic Multi-Tiered Conifer / Pine Trees along Mountain Slopes (Matches Reference Photo 2!)
  const treeCount = 260;
  const trunkGeo = new THREE.CylinderGeometry(0.28, 0.45, 3.8, 7);
  trunkGeo.translate(0, 1.9, 0);
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x3e2723, roughness: 0.92 });

  // 3-Tiered Pine Tree Foliage (Lower, Middle, and Upper Conifer Branches)
  const tier1Geo = new THREE.ConeGeometry(2.8, 4.4, 7);
  tier1Geo.translate(0, 4.4, 0);
  const tier2Geo = new THREE.ConeGeometry(2.2, 4.0, 7);
  tier2Geo.translate(0, 6.8, 0);
  const tier3Geo = new THREE.ConeGeometry(1.5, 3.6, 7);
  tier3Geo.translate(0, 9.0, 0);

  const crownMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(level.treeColorHex),
    roughness: 0.82,
  });

  const trunkInstanced = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
  const tier1Instanced = new THREE.InstancedMesh(tier1Geo, crownMat, treeCount);
  const tier2Instanced = new THREE.InstancedMesh(tier2Geo, crownMat, treeCount);
  const tier3Instanced = new THREE.InstancedMesh(tier3Geo, crownMat, treeCount);
  trunkInstanced.castShadow = !isSoftwareGl;
  tier1Instanced.castShadow = !isSoftwareGl;
  tier2Instanced.castShadow = !isSoftwareGl;
  tier3Instanced.castShadow = !isSoftwareGl;

  for (let i = 0; i < treeCount; i++) {
    // Keep main stadium straight (t < 0.06 or t > 0.94) clear of close trees
    const rawT = (i / treeCount) % 1;
    const t = rawT < 0.06 ? rawT + 0.07 : rawT > 0.94 ? rawT - 0.07 : rawT;
    const side = i % 2 === 0 ? 1 : -1;
    const distFromCenter = halfW + 16 + ((i * 29) % 85);
    const right = new THREE.Vector3();
    sampleTrackFrame(curve, t, _pt, _tangent, right);

    const tx = _pt.x + right.x * side * distFromCenter;
    const tz = _pt.z + right.z * side * distFromCenter;
    const scale = 0.85 + ((i * 41) % 65) / 100;

    _dummy.position.set(tx, _pt.y - 0.15, tz);
    _dummy.rotation.set(0, (i * 1.3) % (Math.PI * 2), 0);
    _dummy.scale.setScalar(scale);
    _dummy.updateMatrix();

    trunkInstanced.setMatrixAt(i, _dummy.matrix);
    tier1Instanced.setMatrixAt(i, _dummy.matrix);
    tier2Instanced.setMatrixAt(i, _dummy.matrix);
    tier3Instanced.setMatrixAt(i, _dummy.matrix);

    _color.set(level.treeColorHex);
    _color.offsetHSL(0, 0, (((i * 13) % 22) - 11) * 0.005);
    tier1Instanced.setColorAt(i, _color);
    tier2Instanced.setColorAt(i, _color);
    tier3Instanced.setColorAt(i, _color);
  }
  [trunkInstanced, tier1Instanced, tier2Instanced, tier3Instanced].forEach((inst) => {
    inst.instanceMatrix.needsUpdate = true;
    if (inst.instanceColor) inst.instanceColor.needsUpdate = true;
    inst.computeBoundingSphere();
    group.add(inst);
  });
  disposables.push(trunkGeo, trunkMat, tier1Geo, tier2Geo, tier3Geo, crownMat);

  // 8. Towering Sculpted Mountain Monolith Cliffs & Valley Rock Outcrops (Matches Photo 2!)
  const cliffCount = 110;
  const cliffGeo = new THREE.DodecahedronGeometry(12.0, 1);
  cliffGeo.translate(0, 6.5, 0);
  const cliffMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(level.rockColorHex),
    roughness: 0.9,
    metalness: 0.06,
  });
  const cliffInstanced = new THREE.InstancedMesh(cliffGeo, cliffMat, cliffCount);

  for (let i = 0; i < cliffCount; i++) {
    const rawT = ((i + 0.5) / cliffCount) % 1;
    const t = rawT < 0.07 ? rawT + 0.08 : rawT > 0.93 ? rawT - 0.08 : rawT;
    const side = i % 2 === 0 ? -1 : 1;
    const isGiantMonolith = i % 7 === 0;
    const dist = halfW + (isGiantMonolith ? 68 : 34) + ((i * 37) % 90);
    const right = new THREE.Vector3();
    sampleTrackFrame(curve, t, _pt, _tangent, right);

    _dummy.position.set(_pt.x + right.x * side * dist, _pt.y - 1.5, _pt.z + right.z * side * dist);
    _dummy.rotation.set((i * 0.35) % 0.6, (i * 1.7) % 6, 0);
    const s = isGiantMonolith
      ? 2.8 + ((i * 19) % 180) / 100
      : 0.9 + ((i * 23) % 130) / 100;
    _dummy.scale.set(s * 1.45, s * (isGiantMonolith ? 2.4 : 1.15), s * 1.35);
    _dummy.updateMatrix();
    cliffInstanced.setMatrixAt(i, _dummy.matrix);

    _color.set(level.rockColorHex);
    _color.offsetHSL(0, 0, (((i * 7) % 18) - 9) * 0.008);
    cliffInstanced.setColorAt(i, _color);
  }
  cliffInstanced.instanceMatrix.needsUpdate = true;
  if (cliffInstanced.instanceColor) cliffInstanced.instanceColor.needsUpdate = true;
  cliffInstanced.computeBoundingSphere();
  group.add(cliffInstanced);
  disposables.push(cliffGeo, cliffMat);

  return {
    group,
    curve,
    totalLength,
    trackWidth: level.trackWidth,
    boostPads,
    dispose: () => {
      disposables.forEach((d) => d.dispose());
    },
  };
}
