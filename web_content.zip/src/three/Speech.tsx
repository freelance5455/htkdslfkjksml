import { Html } from "@react-three/drei";
import { useStore } from "../lib/store";

/**
 * Jeeko's speech bubble — anchored above the head in 3D so it always
 * follows him between maps.
 */
export function Speech() {
  const say = useStore((s) => s.say);
  if (!say) return null;

  return (
    <Html center position={[0, 2.35, 0]} distanceFactor={7} zIndexRange={[20, 10]}>
      <div key={say.id} className="pop pointer-events-none relative select-none">
        <div className="max-w-[230px] rounded-2xl bg-white/95 px-3.5 py-2 text-center text-[13px] leading-5 font-black text-amber-950 shadow-[0_10px_30px_-12px_rgba(80,45,5,0.8)]">
          {say.text}
        </div>
        <div className="absolute left-1/2 h-0 w-0 -translate-x-1/2 border-x-[9px] border-t-[11px] border-x-transparent border-t-white/95" />
      </div>
    </Html>
  );
}
