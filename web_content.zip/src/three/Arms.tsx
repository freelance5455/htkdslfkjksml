import { useMemo } from "react";
import { itemById } from "../lib/catalog";
import { shade } from "./textures";

/**
 * A little hand on the tip of each wing.
 *
 * Jeeko is a chick, so this is a stubby four-digit hand rather than a human
 * one: a soft palm, three forward fingers and an opposed thumb, each with two
 * joints so it looks articulated rather than a blob with spikes. It lives
 * inside the wing group, so it inherits every wing animation for free.
 */
export function Hand({
  side,
  color,
  /** sleeve colour when a suit is worn, so the cuff matches */
  cuff,
}: {
  side: -1 | 1;
  color: string;
  cuff?: string | null;
}) {
  const sleeve = cuff ? itemById(cuff) : undefined;
  const cuffColor = sleeve?.slot === "suit" ? shade(sleeve.tint, -0.16) : null;

  // three fingers fanned across the palm, plus a thumb
  const fingers = useMemo(
    () =>
      [-1, 0, 1].map((i) => ({
        // splay outward and slightly down
        spread: i * 0.34,
        tilt: 0.1 + Math.abs(i) * 0.16,
        len: i === 0 ? 0.115 : 0.098,
      })),
    [],
  );

  const skin = (
    <meshPhysicalMaterial
      color={color}
      roughness={0.72}
      metalness={0}
      sheen={1}
      sheenRoughness={0.5}
      sheenColor={shade(color, 0.35)}
      clearcoat={0.16}
      clearcoatRoughness={0.9}
    />
  );

  return (
    /* wing tip sits near (side*0.16, -0.52) inside the wing group */
    <group position={[side * 0.17, -0.5, 0.06]} rotation={[0.22, 0, side * -0.18]}>
      {/* palm */}
      <mesh scale={[0.085, 0.095, 0.07]} castShadow>
        <sphereGeometry args={[1, 16, 12]} />
        {skin}
      </mesh>

      {/* fingers: two phalanges each */}
      {fingers.map((f, i) => (
        <group
          key={i}
          position={[side * f.spread * 0.06, -0.07, 0.01 + Math.abs(f.spread) * 0.01]}
          rotation={[f.tilt, 0, side * f.spread * 0.8]}
        >
          <mesh position={[0, -f.len / 2, 0]} castShadow>
            <capsuleGeometry args={[0.021, f.len * 0.55, 3, 7]} />
            {skin}
          </mesh>
          <group position={[0, -f.len * 0.82, 0]} rotation={[0.3, 0, 0]}>
            <mesh position={[0, -f.len * 0.3, 0]} castShadow>
              <capsuleGeometry args={[0.019, f.len * 0.42, 3, 7]} />
              {skin}
            </mesh>
            {/* soft nail */}
            <mesh position={[0, -f.len * 0.56, 0.012]} scale={[1, 1.3, 0.5]}>
              <sphereGeometry args={[0.014, 8, 6]} />
              <meshStandardMaterial color={shade(color, -0.3)} roughness={0.45} />
            </mesh>
          </group>
        </group>
      ))}

      {/* opposed thumb */}
      <group
        position={[side * -0.07, -0.03, 0.03]}
        rotation={[0.35, 0, side * 1.15]}
      >
        <mesh position={[0, -0.04, 0]} castShadow>
          <capsuleGeometry args={[0.022, 0.05, 3, 7]} />
          {skin}
        </mesh>
        <mesh position={[0, -0.085, 0.012]} rotation={[0.4, 0, 0]} castShadow>
          <capsuleGeometry args={[0.02, 0.042, 3, 7]} />
          {skin}
        </mesh>
      </group>

      {/* sleeve cuff overlapping the wrist when dressed */}
      {cuffColor && (
        <mesh position={[0, 0.05, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.082, 0.03, 8, 18]} />
          <meshStandardMaterial color={cuffColor} roughness={0.95} />
        </mesh>
      )}
    </group>
  );
}
