import * as THREE from 'three';
import { AeroPreset, FinishType, HYPERCARS, HypercarSpec } from '../types/game';

export interface CarRig {
  root: THREE.Group;
  chassisGroup: THREE.Group;
  bodyShell: THREE.Group;
  canopyGroup: THREE.Group;
  engineBlockGroup: THREE.Group;
  splitterGroup: THREE.Group;
  wingGroup: THREE.Group;
  wheelFL: THREE.Group;
  wheelFR: THREE.Group;
  wheelRL: THREE.Group;
  wheelRR: THREE.Group;
  wheelSpinners: THREE.Object3D[];
  paintMaterials: THREE.MeshPhysicalMaterial[];
  rimMaterials: THREE.MeshPhysicalMaterial[];
  caliperMaterials: THREE.MeshStandardMaterial[];
  brakeLightMaterial: THREE.MeshStandardMaterial;
  nitroFlameLeft: THREE.Mesh;
  nitroFlameRight: THREE.Mesh;
  contactShadow: THREE.Mesh;
  nametagSprite?: THREE.Sprite;
  currentExploded: number;
}

let cachedShadowTexture: THREE.CanvasTexture | null = null;
let cachedTireSidewallTexture: THREE.CanvasTexture | null = null;
let cachedRadiatorGrilleTexture: THREE.CanvasTexture | null = null;
const liveryTextureCache = new Map<string, THREE.CanvasTexture>();
const windshieldTextureCache = new Map<string, THREE.CanvasTexture>();

function getContactShadowTexture(): THREE.CanvasTexture {
  if (cachedShadowTexture) return cachedShadowTexture;
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(128, 256, 28, 128, 256, 126);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.95)');
  grad.addColorStop(0.55, 'rgba(0, 0, 0, 0.68)');
  grad.addColorStop(0.84, 'rgba(0, 0, 0, 0.25)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 512);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  cachedShadowTexture = tex;
  return tex;
}

function getTireSidewallTexture(): THREE.CanvasTexture {
  if (cachedTireSidewallTexture) return cachedTireSidewallTexture;
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#0d0f13';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle rubber sidewall rings
  ctx.strokeStyle = 'rgba(255,255,255,0.04)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(256, 256, 234, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(256, 256, 192, 0, Math.PI * 2);
  ctx.stroke();

  // Curved yellow GOODYEAR sidewall stencils (top and bottom arcs)
  ctx.save();
  ctx.translate(256, 256);
  ctx.fillStyle = '#FACC15';
  ctx.font = '900 28px "Chakra Petch", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  const brand = 'GOODYEAR';
  const radius = 212;
  const angleSpread = 0.72;
  for (let pass = 0; pass < 2; pass++) {
    const baseAngle = pass === 0 ? -Math.PI / 2 : Math.PI / 2;
    for (let i = 0; i < brand.length; i++) {
      const frac = i / (brand.length - 1) - 0.5;
      const a = baseAngle + frac * angleSpread;
      ctx.save();
      ctx.rotate(a + Math.PI / 2);
      ctx.fillText(brand[i], 0, -radius);
      ctx.restore();
    }
  }

  ctx.fillStyle = '#F8FAFC';
  ctx.font = 'bold 14px sans-serif';
  ctx.fillText('EAGLE', -212, 0);
  ctx.fillText('310/710-18', 212, 0);
  ctx.restore();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  cachedTireSidewallTexture = tex;
  return tex;
}

function getRadiatorGrilleTexture(): THREE.CanvasTexture {
  if (cachedRadiatorGrilleTexture) return cachedRadiatorGrilleTexture;
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#06080c';
  ctx.fillRect(0, 0, 512, 128);

  // Fine dark radiator core fins & honeycomb mesh
  ctx.strokeStyle = '#181e29';
  ctx.lineWidth = 1.5;
  for (let x = 0; x < 512; x += 8) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + 6, 128);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x + 6, 0);
    ctx.lineTo(x, 128);
    ctx.stroke();
  }

  // Subtle aluminum radiator core behind dark mesh
  const grad = ctx.createLinearGradient(90, 0, 422, 0);
  grad.addColorStop(0, 'rgba(15,23,42,0.15)');
  grad.addColorStop(0.5, 'rgba(148,163,184,0.22)');
  grad.addColorStop(1, 'rgba(15,23,42,0.15)');
  ctx.fillStyle = grad;
  ctx.fillRect(96, 14, 320, 100);

  // Outer carbon bezel frame
  ctx.strokeStyle = '#0b0e14';
  ctx.lineWidth = 12;
  ctx.strokeRect(0, 0, 512, 128);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  cachedRadiatorGrilleTexture = tex;
  return tex;
}

function extractRaceNumber(liveryName: string): string {
  const m = liveryName.match(/#(\d+)/);
  return m ? m[1] : '59';
}

function getWindshieldTexture(spec: HypercarSpec, primaryHex: string): THREE.CanvasTexture {
  const key = `${spec.id}_${primaryHex}`;
  if (windshieldTextureCache.has(key)) return windshieldTextureCache.get(key)!;

  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Deep smoked motorsport polycarbonate windshield glass with sky sheen
  const glassGrad = ctx.createLinearGradient(0, 110, 0, 512);
  glassGrad.addColorStop(0, '#162032');
  glassGrad.addColorStop(0.35, '#0c1320');
  glassGrad.addColorStop(1, '#060911');
  ctx.fillStyle = glassGrad;
  ctx.fillRect(0, 0, 1024, 512);

  // Subtle diagonal specular reflection streak across windshield
  ctx.fillStyle = 'rgba(255, 255, 255, 0.045)';
  ctx.beginPath();
  ctx.moveTo(180, 118);
  ctx.lineTo(310, 118);
  ctx.lineTo(190, 512);
  ctx.lineTo(70, 512);
  ctx.closePath();
  ctx.fill();

  // Glowing FIA WEC LED Position & Number Display Panel (Top-Right inside glass)
  ctx.fillStyle = '#070a10';
  ctx.fillRect(210, 144, 86, 54);
  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 3;
  ctx.strokeRect(210, 144, 86, 54);
  ctx.fillStyle = '#FACC15';
  ctx.font = '900 32px "Chakra Petch", monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(extractRaceNumber(spec.liveryName), 253, 173);

  // Vibrant Top Sunstrip Visor Banner (Matches McLaren yellow/orange sunstrip in photo!)
  const sunstripGrad = ctx.createLinearGradient(0, 0, 1024, 0);
  sunstripGrad.addColorStop(0, primaryHex);
  sunstripGrad.addColorStop(0.5, '#FFB800');
  sunstripGrad.addColorStop(1, primaryHex);
  ctx.fillStyle = sunstripGrad;
  ctx.fillRect(0, 0, 1024, 112);

  // Crisp black separator line below sunstrip
  ctx.fillStyle = '#080b10';
  ctx.fillRect(0, 108, 1024, 7);

  // Bold Manufacturer Sunstrip Typography (e.g., "McLaren", "FERRARI", "PORSCHE")
  const brandTitle = spec.manufacturer
    .replace(/Motorsport|AF Corse|Squadra Corse|Racing|Sport|Corse/gi, '')
    .trim()
    .toUpperCase();
  ctx.fillStyle = '#090b10';
  ctx.font = 'italic 900 54px "Chakra Petch", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(brandTitle || 'McLAREN', 512, 56);

  // Black ceramic frit border around windshield perimeter
  ctx.strokeStyle = '#07090e';
  ctx.lineWidth = 24;
  ctx.strokeRect(0, 0, 1024, 512);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  windshieldTextureCache.set(key, tex);
  return tex;
}

/**
 * Generates a high-resolution 2048x2048 Works Motorsport Livery Texture
 * Calibrated to our multi-crease GT3 / LMH bodywork UVs:
 * - U in [0.27 .. 0.73] = Flat Center Hood, Roof & Rear Engine Deck
 * - U in [0.14 .. 0.27] & [0.73 .. 0.86] = Raised Widebody Fender Crowns
 * - U in [0.00 .. 0.14] & [0.86 .. 1.00] = Vertical Chiseled Doors & Side Fenders
 */
function getMotorsportLiveryTexture(spec: HypercarSpec, primaryHex: string): THREE.CanvasTexture {
  const cacheKey = `${spec.id}_${primaryHex}_v2`;
  if (liveryTextureCache.has(cacheKey)) return liveryTextureCache.get(cacheKey)!;

  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 2048;
  const ctx = canvas.getContext('2d')!;

  const raceNum = extractRaceNumber(spec.liveryName);
  const isHypercar = spec.category === 'Hypercar / LMH';
  const classBg = isHypercar ? '#DC2626' : '#047857'; // Red for LMH, Emerald Green for WEC LMGT3
  const classLabel = isHypercar ? 'HYPERCAR' : 'LMGT3';

  // 1. Base Satin Carbon-Fiber Bodywork Background (#12151c)
  ctx.fillStyle = '#12151c';
  ctx.fillRect(0, 0, 2048, 2048);

  // Fine diagonal carbon-fiber weave pattern
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.028)';
  ctx.lineWidth = 2;
  for (let k = -2048; k < 4096; k += 14) {
    ctx.beginPath();
    ctx.moveTo(k, 0);
    ctx.lineTo(k + 2048, 2048);
    ctx.stroke();
  }

  // 2. Primary Works Livery Color Zones (Center Hood V-Wedge, Roof Spine, Lower Rocker Wedges)
  ctx.fillStyle = primaryHex;

  // Center Hood V-Shaped Wedge (Narrow at front nose Y=0, widening along hood crease to Y=740)
  ctx.beginPath();
  ctx.moveTo(760, 0);
  ctx.lineTo(1288, 0);
  ctx.lineTo(1460, 740);
  ctx.lineTo(1480, 1420);
  ctx.lineTo(1320, 2048);
  ctx.lineTo(728, 2048);
  ctx.lineTo(568, 1420);
  ctx.lineTo(588, 740);
  ctx.closePath();
  ctx.fill();

  // High-Contrast Racing Pinstripe bordering the Center Hood V-Wedge
  ctx.strokeStyle = '#FACC15';
  ctx.lineWidth = 8;
  ctx.stroke();

  // Outer Front Bumper Flicks & Lower Door Rocker Wedges (U: 0..240 and 1808..2048)
  ctx.fillStyle = primaryHex;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(310, 0);
  ctx.lineTo(220, 480);
  ctx.lineTo(195, 1600);
  ctx.lineTo(320, 2048);
  ctx.lineTo(0, 2048);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(2048, 0);
  ctx.lineTo(1738, 0);
  ctx.lineTo(1828, 480);
  ctx.lineTo(1853, 1600);
  ctx.lineTo(1728, 2048);
  ctx.lineTo(2048, 2048);
  ctx.closePath();
  ctx.fill();

  // 3. Recessed Carbon Hood Radiator Extraction Vent (Y: 280..510, X: 770..1278)
  ctx.fillStyle = '#070a0f';
  ctx.beginPath();
  ctx.moveTo(790, 285);
  ctx.lineTo(1258, 285);
  ctx.lineTo(1305, 510);
  ctx.lineTo(743, 510);
  ctx.closePath();
  ctx.fill();

  // Internal hood radiator louver slats
  ctx.strokeStyle = '#1e2636';
  ctx.lineWidth = 9;
  for (let y = 340; y <= 490; y += 26) {
    ctx.beginPath();
    ctx.moveTo(770, y);
    ctx.lineTo(1278, y);
    ctx.stroke();
  }

  ctx.strokeStyle = '#2d3748';
  ctx.lineWidth = 5;
  ctx.stroke();

  // Bold White "RICHARD MILLE" Sponsor Header on Hood Vent Leading Edge
  ctx.fillStyle = '#F8FAFC';
  ctx.font = '900 36px "Chakra Petch", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('RICHARD MILLE', 1024, 314);

  // 4. Nose Emblem, "Q8" Logo, & Tow Strap Marker on Front Nose (Y: 85..245)
  ctx.fillStyle = '#090c12';
  ctx.font = '900 36px "Chakra Petch", sans-serif';
  ctx.fillText('Q8', 972, 205);
  ctx.beginPath();
  ctx.arc(1054, 205, 22, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = primaryHex;
  ctx.beginPath();
  ctx.arc(1050, 205, 13, 0, Math.PI * 2);
  ctx.fill();

  // Manufacturer nose crest
  ctx.fillStyle = '#090c12';
  ctx.fillRect(974, 108, 100, 28);
  ctx.fillStyle = '#F8FAFC';
  ctx.font = 'bold 17px "Chakra Petch", sans-serif';
  ctx.fillText(spec.manufacturer.split(' ')[0].toUpperCase(), 1024, 123);

  // Red "TOW" arrow marker
  ctx.fillStyle = '#EF4444';
  ctx.fillRect(900, 68, 52, 20);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 12px sans-serif';
  ctx.fillText('TOW ▾', 926, 79);

  // 5. Front Fender Crowns: "DK Engineering" Script & WEC Fender Number Plate
  for (const side of [-1, 1]) {
    const cx = side === -1 ? 430 : 1618;
    // Wheel arch top louver vents
    ctx.fillStyle = '#07090e';
    ctx.fillRect(cx - 80, 380, 160, 155);
    ctx.fillStyle = '#1e2736';
    for (let ly = 394; ly < 525; ly += 20) {
      ctx.fillRect(cx - 70, ly, 140, 8);
    }

    // Diagonal "DK Engineering" decal along front fender headlight brow
    ctx.save();
    ctx.translate(side === -1 ? 470 : 1578, 250);
    ctx.rotate(side === -1 ? -0.38 : 0.38);
    ctx.fillStyle = '#F8FAFC';
    ctx.font = 'italic 900 32px "Chakra Petch", sans-serif';
    ctx.fillText('DK', -54, 0);
    ctx.font = 'bold 20px "Chakra Petch", sans-serif';
    ctx.fillText('Engineering', 28, 2);
    ctx.restore();
  }

  // Front Right Fender WEC Number Plate (#59)
  ctx.save();
  ctx.translate(1618, 460);
  ctx.fillStyle = classBg;
  ctx.fillRect(-68, -42, 136, 84);
  ctx.strokeStyle = '#FFFFFF';
  ctx.lineWidth = 5;
  ctx.strokeRect(-68, -42, 136, 84);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 50px "Chakra Petch", sans-serif';
  ctx.fillText(raceNum, 0, 4);
  ctx.restore();

  // 6. Vertical Side Doors (U: 0..280 & 1768..2048): WEC LMGT3 #59 Number Panels & Sponsors
  for (const side of [-1, 1]) {
    const doorX = side === -1 ? 150 : 1898;

    // Diagonal "RICHARD MILLE" along upper door beltline
    ctx.save();
    ctx.translate(side === -1 ? 255 : 1793, 890);
    ctx.rotate(side === -1 ? -Math.PI / 2 : Math.PI / 2);
    ctx.fillStyle = '#F8FAFC';
    ctx.font = '900 30px "Chakra Petch", sans-serif';
    ctx.fillText('RICHARD MILLE', 0, 0);
    ctx.restore();

    // Official FIA WEC Door Number Box
    ctx.save();
    ctx.translate(doorX, 1060);
    ctx.rotate(side === -1 ? -Math.PI / 2 : Math.PI / 2);

    // Yellow DHL Endurance Top Header
    ctx.fillStyle = '#FACC15';
    ctx.fillRect(-115, -92, 230, 30);
    ctx.fillStyle = '#DC2626';
    ctx.font = 'italic 900 22px "Chakra Petch", sans-serif';
    ctx.fillText('DHL', 0, -76);

    // Green LMGT3 / Red HYPERCAR Main Box
    ctx.fillStyle = classBg;
    ctx.fillRect(-115, -62, 230, 140);
    ctx.strokeStyle = '#F8FAFC';
    ctx.lineWidth = 5;
    ctx.strokeRect(-115, -62, 230, 140);

    ctx.fillStyle = '#F8FAFC';
    ctx.font = 'bold 18px "Chakra Petch", sans-serif';
    ctx.fillText(classLabel, -64, -38);

    ctx.font = '900 96px "Chakra Petch", sans-serif';
    ctx.fillText(raceNum, 18, 16);

    // GOODYEAR & DK Engineering on lower rocker skirt
    ctx.fillStyle = '#F8FAFC';
    ctx.font = 'italic 900 26px "Chakra Petch", sans-serif';
    ctx.fillText('GOODYEAR', -120, 108);
    ctx.fillStyle = '#090c12';
    ctx.font = 'bold 22px "Chakra Petch", sans-serif';
    ctx.fillText('DK Engineering', 85, 108);
    ctx.restore();
  }

  // 7. Crisp Panel Shut-Lines (Hood seam & door seams)
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.72)';
  ctx.lineWidth = 4;
  ctx.strokeRect(560, 90, 928, 560);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  liveryTextureCache.set(cacheKey, tex);
  return tex;
}

export function configurePaintMaterial(
  mat: THREE.MeshPhysicalMaterial,
  paintHex: string,
  finishType: FinishType
) {
  if (mat.map) {
    mat.color.set('#ffffff');
  } else {
    mat.color.set(paintHex);
  }
  mat.anisotropy = 0;
  mat.iridescence = 0;

  switch (finishType) {
    case 'metallic':
      mat.metalness = mat.map ? 0.38 : 0.78;
      mat.roughness = 0.16;
      mat.clearcoat = 1.0;
      mat.clearcoatRoughness = 0.04;
      break;
    case 'matte':
      mat.metalness = 0.2;
      mat.roughness = 0.45;
      mat.clearcoat = 0.2;
      mat.clearcoatRoughness = 0.35;
      break;
    case 'titanium':
      mat.metalness = mat.map ? 0.48 : 0.88;
      mat.roughness = 0.18;
      mat.anisotropy = 0.8;
      mat.anisotropyRotation = Math.PI / 4;
      mat.clearcoat = 0.9;
      mat.clearcoatRoughness = 0.08;
      break;
    case 'iridescent':
      mat.metalness = mat.map ? 0.42 : 0.8;
      mat.roughness = 0.14;
      mat.clearcoat = 1.0;
      mat.clearcoatRoughness = 0.03;
      mat.iridescence = 0.95;
      mat.iridescenceIOR = 1.48;
      mat.iridescenceThicknessRange = [180, 480];
      break;
    case 'carbon':
      if (!mat.map) mat.color.set('#151b24');
      mat.metalness = 0.45;
      mat.roughness = 0.24;
      mat.clearcoat = 1.0;
      mat.clearcoatRoughness = 0.05;
      break;
  }
  mat.needsUpdate = true;
}

function createNametagSprite(name: string, accentHex: string): THREE.Sprite {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 64;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = 'rgba(7, 9, 14, 0.88)';
  ctx.beginPath();
  ctx.roundRect(8, 8, 240, 48, 8);
  ctx.fill();

  ctx.strokeStyle = accentHex;
  ctx.lineWidth = 2.5;
  ctx.stroke();

  ctx.font = 'bold 20px "Chakra Petch", sans-serif';
  ctx.fillStyle = '#F8FAFC';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(name.slice(0, 18).toUpperCase(), 128, 32);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.SpriteMaterial({
    map: texture,
    transparent: true,
    depthWrite: false,
  });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(2.4, 0.6, 1);
  sprite.position.set(0, 2.05, 0);
  return sprite;
}

/**
 * Builds the Chiseled, Low-Slung Lower Supercar / GT3 Bodywork (Beltline & Below).
 * Uses split crease vertices along the fender shoulder and hood edges so the car has
 * razor-sharp automotive character lines and taut flat planes (ZERO egg/blob rounding!).
 * Crucially, the center section stays at beltline/cockpit-sill level (y ≈ 0.55m) so the
 * wide supercar greenhouse sits cleanly on top without any Z-fighting or dome bulging.
 */
function buildSculptedGTBodyGeometry(spec: HypercarSpec): THREE.BufferGeometry {
  const halfL = spec.chassisLength * 0.5;
  const halfW = spec.chassisWidth * 0.5;
  const bStyle = spec.bodyStyle;
  const isFrontEngine = bStyle === 'gt3-front' || bStyle === 'gt4-coupe';
  const isPrototype = bStyle === 'lmh' || bStyle === 'lmdh' || bStyle === 'bolide';

  const numZ = 40;
  // 16 transverse profile stations across the car with duplicated crease nodes for sharp edges:
  // 0: Left bottom rocker sill
  // 1: Left vertical door / wheel flare outer face
  // 2: Left outer fender shoulder crease (side normal)
  // 3: Left outer fender shoulder crease (top normal)
  // 4: Left fender crown peak
  // 5: Left inner fender-to-hood crease (fender normal)
  // 6: Left inner fender-to-hood crease (hood normal)
  // 7: Centerline (X = 0)
  // 8: Right inner hood-to-fender crease (hood normal)
  // 9: Right inner hood-to-fender crease (fender normal)
  // 10: Right fender crown peak
  // 11: Right outer fender shoulder crease (top normal)
  // 12: Right outer fender shoulder crease (side normal)
  // 13: Right vertical door / wheel flare outer face
  // 14: Right bottom rocker sill
  const uCoords = [
    0.0,
    0.13,
    0.14,
    0.14,
    0.21,
    0.27,
    0.27,
    0.5,
    0.73,
    0.73,
    0.79,
    0.86,
    0.86,
    0.87,
    1.0,
  ];
  const numX = uCoords.length;

  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const zwf = -halfL * 0.56; // front wheel center Z
  const zwr = halfL * 0.55;  // rear wheel center Z
  const archR = 0.415;       // crisp wheel arch radius

  for (let i = 0; i < numZ; i++) {
    const t = i / (numZ - 1); // 0 at front nose tip, 1 at rear tail
    const z = -halfL + t * 2 * halfL;

    // 1. Wide, Planted GT3 Plan-View Width Envelope
    let wMult = 1.0;
    let noseRoundIn = 1.0;
    if (t < 0.06) {
      // Swept-back aerodynamic GT3 front bumper corners (wide flat center, curved corners)
      const nt = t / 0.06;
      wMult = 0.84 + Math.sin(nt * (Math.PI / 2)) * 0.15;
      noseRoundIn = 0.86 + nt * 0.14;
    } else if (t < 0.34) {
      // Muscular front widebody fender flare
      const ft = (t - 0.06) / 0.28;
      wMult = 0.99 + Math.sin(ft * Math.PI) * 0.03;
    } else if (t < 0.62) {
      // Sculpted inward dihedral door waist between wheels
      const dt = (t - 0.34) / 0.28;
      wMult = 1.0 - Math.sin(dt * Math.PI) * 0.075;
    } else if (t < 0.88) {
      // Wide muscular rear GT3 haunches
      const rt = (t - 0.62) / 0.26;
      const rearFlare = bStyle === 'porsche-gt3' ? 0.065 : 0.045;
      wMult = 0.98 + Math.sin(rt * Math.PI) * rearFlare;
    } else {
      // Crisp rear diffuser tail taper
      const tt = (t - 0.88) / 0.12;
      wMult = 1.0 - tt * 0.09;
    }

    const curW = halfW * wMult;

    // 2. Center Deck Height (Flat low nose -> Recessed Hood Vent -> Flat Cockpit Sill -> Rear Engine Deck)
    // NEVER rises into the roof so there is ZERO egg dome!
    let centerY = 0.24;
    if (t < 0.06) {
      // Sleek front bumper leading edge above splitter
      centerY = 0.21 + (t / 0.06) * 0.07;
    } else if (t < 0.33) {
      // Raked GT3 front hood with deep recessed radiator extractor duct in the middle
      const ht = (t - 0.06) / 0.27;
      const baseHoodY = 0.28 + ht * (isFrontEngine ? 0.33 : 0.28);
      const inVent = ht > 0.24 && ht < 0.78;
      const ventDepth = inVent
        ? (isPrototype ? -0.09 : -0.065) * Math.sin(((ht - 0.24) / 0.54) * Math.PI)
        : 0;
      centerY = baseHoodY + ventDepth;
    } else if (t < 0.72) {
      // Flat cockpit tub / engine bay floor underneath the greenhouse
      centerY = 0.56;
    } else if (t < 0.92) {
      // Sloped rear engine bay deck between the rear fenders
      const et = (t - 0.72) / 0.2;
      centerY = 0.56 - et * 0.08;
    } else {
      // Rear tail fascia above diffuser
      const rt = (t - 0.92) / 0.08;
      centerY = 0.48 - rt * 0.06;
    }

    // 3. Inner Hood-Edge Height (Before stepping up to the Fender Crown)
    let hoodEdgeY = centerY;
    if (t >= 0.06 && t < 0.33) {
      const ht = (t - 0.06) / 0.27;
      hoodEdgeY = 0.29 + ht * (isFrontEngine ? 0.33 : 0.28);
    }

    // 4. Muscular GT3 Fender Crown & Door Beltline Height
    let fenderCrownY = 0.30;
    let outerShoulderY = 0.28;
    if (t < 0.06) {
      const nt = t / 0.06;
      fenderCrownY = 0.22 + nt * 0.09;
      outerShoulderY = 0.20 + nt * 0.09;
    } else if (t < 0.35) {
      // Front wheel arch fender haunch (sleek low slope over front wheels, flat-topped)
      const ft = (t - 0.06) / 0.29;
      const archCurve = Math.sin(ft * Math.PI);
      fenderCrownY = 0.31 + Math.pow(ft, 0.75) * 0.28 + archCurve * 0.065;
      outerShoulderY = fenderCrownY - 0.025;
    } else if (t < 0.60) {
      // Crisp horizontal door beltline below side windows
      const dt = (t - 0.35) / 0.25;
      fenderCrownY = 0.59 - Math.sin(dt * Math.PI) * 0.025;
      outerShoulderY = fenderCrownY - 0.02;
    } else if (t < 0.90) {
      // Powerful rear fender haunch over rear wheels
      const rt = (t - 0.60) / 0.30;
      const rearHump = Math.sin(rt * Math.PI) * 0.085;
      fenderCrownY = 0.59 - rt * 0.04 + rearHump;
      outerShoulderY = fenderCrownY - 0.025;
    } else {
      // Rear tail deck edge
      const tt = (t - 0.90) / 0.10;
      fenderCrownY = 0.55 - tt * 0.06;
      outerShoulderY = fenderCrownY - 0.02;
    }

    // 5. Circular Wheel Arch Cutouts along the Lower Side Flank
    let archLift = 0;
    const distWf = Math.abs(z - zwf);
    if (distWf < archR) {
      archLift = Math.sqrt(Math.max(0, archR * archR - distWf * distWf)) * 0.95;
    }
    const distWr = Math.abs(z - zwr);
    if (distWr < archR) {
      archLift = Math.max(
        archLift,
        Math.sqrt(Math.max(0, archR * archR - distWr * distWr)) * 0.98
      );
    }

    const sillY = Math.max(0.085, 0.085 + archLift);
    const doorScallopIn = t > 0.35 && t < 0.61 ? Math.sin(((t - 0.35) / 0.26) * Math.PI) * 0.075 : 0;

    // Transverse X coordinates (Right side positive)
    const xHoodEdge = curW * 0.48 * noseRoundIn;
    const xFenderInner = curW * 0.53 * noseRoundIn;
    const xFenderCrown = curW * 0.74 * noseRoundIn;
    const xOuterShoulder = curW * 0.95;
    const xSideFlank = curW * 1.0 - doorScallopIn;
    const xSill = curW * 0.97 - doorScallopIn * 0.5;

    const sideVertY = THREE.MathUtils.lerp(sillY, outerShoulderY, 0.38);

    const rowPoints: Array<[number, number]> = [
      [-xSill, sillY],                   // 0: Left sill
      [-xSideFlank, sideVertY],          // 1: Left lower door / arch lip
      [-xOuterShoulder, outerShoulderY], // 2: Left shoulder crease (side)
      [-xOuterShoulder, outerShoulderY], // 3: Left shoulder crease (top)
      [-xFenderCrown, fenderCrownY],     // 4: Left fender crown
      [-xFenderInner, fenderCrownY],     // 5: Left inner fender ridge
      [-xHoodEdge, hoodEdgeY],           // 6: Left hood edge
      [0, centerY],                      // 7: Centerline
      [xHoodEdge, hoodEdgeY],            // 8: Right hood edge
      [xFenderInner, fenderCrownY],      // 9: Right inner fender ridge
      [xFenderCrown, fenderCrownY],      // 10: Right fender crown
      [xOuterShoulder, outerShoulderY],  // 11: Right shoulder crease (top)
      [xOuterShoulder, outerShoulderY],  // 12: Right shoulder crease (side)
      [xSideFlank, sideVertY],           // 13: Right lower door / arch lip
      [xSill, sillY],                    // 14: Right sill
    ];

    for (let j = 0; j < numX; j++) {
      positions.push(rowPoints[j][0], rowPoints[j][1], z);
      uvs.push(uCoords[j], 1 - t);
    }
  }

  // Connect longitudinal quads, skipping degenerate zero-area crease pairs (2->3, 5->6, 8->9, 11->12)
  // Wait: we DO connect 5->6 and 8->9 so the inner fender step wall is a solid vertical bevel face!
  // We skip ONLY 2->3 and 11->12 where the vertex position is identical (hard normal split at outer shoulder).
  const activeCols = [0, 1, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13];
  for (let i = 0; i < numZ - 1; i++) {
    for (const j of activeCols) {
      const p1 = i * numX + j;
      const p2 = (i + 1) * numX + j;
      const p3 = (i + 1) * numX + (j + 1);
      const p4 = i * numX + (j + 1);
      indices.push(p1, p2, p3, p1, p3, p4);
    }
  }

  // Front Bumper Lower Valance Closure (Clean flat vertical nose drop to splitter at z = -halfL)
  const frontValanceCenterIdx = positions.length / 3;
  positions.push(0, 0.14, -halfL + 0.02);
  uvs.push(0.5, 0.99);
  for (const j of activeCols) {
    indices.push(frontValanceCenterIdx, j, j + 1);
  }

  // Rear Tail Fascia Closure
  const rearCenterIdx = positions.length / 3;
  positions.push(0, 0.26, halfL - 0.01);
  uvs.push(0.5, 0.01);
  const lastRowStart = (numZ - 1) * numX;
  for (const j of activeCols) {
    indices.push(rearCenterIdx, lastRowStart + j + 1, lastRowStart + j);
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/**
 * Builds the Authentic Wide, Flat-Planed GT3 / Supercar Greenhouse Assembly:
 * - Wide, flatly-raked wrap-around Windshield with Sunstrip Banner & WEC LED Number Box
 * - 3D Painted A-Pillars & Roof Cantrails (in primary livery accent color, just like McLaren #59!)
 * - Low, wide, taut Roof Panel with Carbon Roof Intake Scoop & 3 Telemetry Antennas
 * - Angled Left & Right Trapezoidal Door Windows + B-Pillars + Interior FIA Roll Cage & Bucket Seat
 * - Rear C-Pillar Flying Buttresses framing a Recessed Carbon Louvered Mid-Engine Deck
 */
function populateSupercarGreenhouse(
  canopyGroup: THREE.Group,
  spec: HypercarSpec,
  glassMat: THREE.Material,
  paintMat: THREE.Material,
  accentPaintMat: THREE.Material,
  carbonMat: THREE.Material,
  darkTrimMat: THREE.Material,
  chromeMat: THREE.Material,
  caliperMat: THREE.Material
) {
  const halfL = spec.chassisLength * 0.5;
  const halfW = spec.chassisWidth * 0.5;
  const bStyle = spec.bodyStyle;
  const isFrontEngine = bStyle === 'gt3-front' || bStyle === 'gt4-coupe';
  const isPrototype = bStyle === 'lmh' || bStyle === 'lmdh' || bStyle === 'bolide';

  // Keep roof low, wide, and sleek (never tall or egg-like)
  const roofH = isPrototype
    ? Math.min(spec.roofHeight, 1.0)
    : Math.min(spec.roofHeight, 1.08);
  const beltY = 0.565;

  const cabShiftZ = isFrontEngine ? 0.14 : isPrototype ? -0.06 : 0.0;
  const windBaseZ = -halfL * 0.34 + cabShiftZ;
  const windTopZ = -halfL * 0.03 + cabShiftZ;
  const roofRearZ = halfL * 0.24 + cabShiftZ;
  const deckRearZ = halfL * 0.84;

  const wBaseHalf = halfW * (isPrototype ? 0.68 : 0.78); // Wide supercar windshield base!
  const wTopHalf = halfW * (isPrototype ? 0.56 : 0.65);  // Wide roof header!
  const wRearHalf = halfW * (isPrototype ? 0.50 : 0.60);

  // 1. Wide, Flatly-Raked Wrap-Around Windshield Visor (12x6 grid with gentle 3.5cm arch)
  const wCols = 13;
  const wRows = 6;
  const wPos: number[] = [];
  const wUvs: number[] = [];
  const wIdx: number[] = [];

  for (let r = 0; r < wRows; r++) {
    const vr = r / (wRows - 1); // 0 at base (cowl), 1 at top (roof header)
    const rowWidth = THREE.MathUtils.lerp(wBaseHalf, wTopHalf, vr);
    const rowBaseZ = THREE.MathUtils.lerp(windBaseZ, windTopZ, vr);
    const rowBaseY = THREE.MathUtils.lerp(beltY, roofH, vr);

    for (let c = 0; c < wCols; c++) {
      const uc = (c / (wCols - 1)) * 2 - 1; // -1 (left) to +1 (right)
      const x = uc * rowWidth;
      // Gentle, realistic wrap-around curvature in Z and subtle 3cm crown in Y (NOT a dome!)
      const zWrap = (1 - uc * uc) * -0.09;
      const yArch = (1 - uc * uc) * 0.032;
      wPos.push(x, rowBaseY + yArch, rowBaseZ + zWrap);
      wUvs.push(c / (wCols - 1), vr);
    }
  }

  for (let r = 0; r < wRows - 1; r++) {
    for (let c = 0; c < wCols - 1; c++) {
      const p1 = r * wCols + c;
      const p2 = (r + 1) * wCols + c;
      const p3 = (r + 1) * wCols + (c + 1);
      const p4 = r * wCols + (c + 1);
      wIdx.push(p1, p3, p2, p1, p4, p3);
    }
  }

  const windshieldGeo = new THREE.BufferGeometry();
  windshieldGeo.setAttribute('position', new THREE.Float32BufferAttribute(wPos, 3));
  windshieldGeo.setAttribute('uv', new THREE.Float32BufferAttribute(wUvs, 2));
  windshieldGeo.setIndex(wIdx);
  windshieldGeo.computeVertexNormals();

  const windshieldMesh = new THREE.Mesh(windshieldGeo, glassMat);
  windshieldMesh.renderOrder = 5;
  canopyGroup.add(windshieldMesh);

  // 2. Wide, Low, Taut Roof Panel (Painted in Primary Works Color)
  const rCols = 9;
  const rRows = 5;
  const rPos: number[] = [];
  const rUvs: number[] = [];
  const rIdx: number[] = [];

  for (let r = 0; r < rRows; r++) {
    const vr = r / (rRows - 1);
    const rowWidth = THREE.MathUtils.lerp(wTopHalf, wRearHalf, vr);
    const z = THREE.MathUtils.lerp(windTopZ, roofRearZ, vr);
    const yBase = roofH - vr * 0.015;

    for (let c = 0; c < rCols; c++) {
      const uc = (c / (rCols - 1)) * 2 - 1;
      const x = uc * rowWidth;
      const yArch = (1 - uc * uc) * 0.028;
      const zWrap = (1 - uc * uc) * -0.09 * (1 - vr);
      rPos.push(x, yBase + yArch, z + zWrap);
      rUvs.push(0.35 + (c / (rCols - 1)) * 0.3, 0.55 - vr * 0.15);
    }
  }

  for (let r = 0; r < rRows - 1; r++) {
    for (let c = 0; c < rCols - 1; c++) {
      const p1 = r * rCols + c;
      const p2 = (r + 1) * rCols + c;
      const p3 = (r + 1) * rCols + (c + 1);
      const p4 = r * rCols + (c + 1);
      rIdx.push(p1, p2, p3, p1, p3, p4);
    }
  }

  const roofGeo = new THREE.BufferGeometry();
  roofGeo.setAttribute('position', new THREE.Float32BufferAttribute(rPos, 3));
  roofGeo.setAttribute('uv', new THREE.Float32BufferAttribute(rUvs, 2));
  roofGeo.setIndex(rIdx);
  roofGeo.computeVertexNormals();
  const roofMesh = new THREE.Mesh(roofGeo, accentPaintMat);
  canopyGroup.add(roofMesh);

  // 3. 3D Painted A-Pillars, Roof Cantrails, Side Door Windows & Rear C-Pillar Flying Buttresses
  const sideGlassMat = new THREE.MeshPhysicalMaterial({
    color: 0x0b111d,
    metalness: 0.25,
    roughness: 0.06,
    clearcoat: 1.0,
    transparent: true,
    opacity: 0.9,
    side: THREE.DoubleSide,
  });

  for (const side of [-1, 1]) {
    // 3A. Bold Painted A-Pillar Strut framing the windshield (Signature McLaren/GT3 orange/primary pillar!)
    const aPillarLen = Math.hypot(
      wBaseHalf - wTopHalf,
      roofH - beltY,
      windTopZ - windBaseZ
    );
    const aPillarGeo = new THREE.BoxGeometry(0.065, 0.045, aPillarLen + 0.04);
    const aPillar = new THREE.Mesh(aPillarGeo, accentPaintMat);
    aPillar.position.set(
      side * ((wBaseHalf + wTopHalf) * 0.5 + 0.01),
      (beltY + roofH) * 0.5 + 0.01,
      (windBaseZ + windTopZ) * 0.5
    );
    aPillar.lookAt(
      side * wTopHalf,
      roofH + 0.01,
      windTopZ
    );
    canopyGroup.add(aPillar);

    // 3B. Painted Roof Side Cantrail above the door glass
    const cantrailLen = roofRearZ - windTopZ + 0.06;
    const cantrail = new THREE.Mesh(
      new THREE.BoxGeometry(0.065, 0.04, cantrailLen),
      accentPaintMat
    );
    cantrail.position.set(
      side * ((wTopHalf + wRearHalf) * 0.5 + 0.01),
      roofH - 0.005,
      (windTopZ + roofRearZ) * 0.5
    );
    cantrail.rotation.y = side * 0.08;
    canopyGroup.add(cantrail);

    // 3C. Angled Trapezoidal Side Door Window (Connects A-pillar & roof rail down to door beltline)
    const winPos = new Float32Array([
      side * wBaseHalf, beltY, windBaseZ,                     // 0: Front bottom corner
      side * (wBaseHalf * 1.04), beltY, roofRearZ + 0.18,     // 1: Rear bottom corner
      side * wRearHalf, roofH - 0.015, roofRearZ,             // 2: Rear top corner
      side * wTopHalf, roofH, windTopZ,                       // 3: Front top corner
    ]);
    const winIdx = side === 1 ? [0, 1, 2, 0, 2, 3] : [0, 2, 1, 0, 3, 2];
    const winGeo = new THREE.BufferGeometry();
    winGeo.setAttribute('position', new THREE.BufferAttribute(winPos, 3));
    winGeo.setIndex(winIdx);
    winGeo.computeVertexNormals();
    const sideWindow = new THREE.Mesh(winGeo, sideGlassMat);
    canopyGroup.add(sideWindow);

    // Vertical Black B-Pillar Post & Rear Quarter Window Intake Louver
    const bPillar = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.44, 0.07), darkTrimMat);
    bPillar.position.set(
      side * ((wRearHalf + wBaseHalf) * 0.5),
      (beltY + roofH) * 0.5,
      roofRearZ + 0.02
    );
    bPillar.rotation.z = -side * 0.34;
    canopyGroup.add(bPillar);

    // 3D. Sweeping Rear C-Pillar Flying Buttress Fin (Connects roof rear corner to rear haunches)
    const buttressPos = new Float32Array([
      side * wRearHalf, roofH - 0.015, roofRearZ,              // 0: Top front (at roof)
      side * (wBaseHalf * 1.04), beltY, roofRearZ + 0.16,      // 1: Bottom front (at beltline)
      side * (halfW * 0.64), beltY + 0.02, deckRearZ,          // 2: Bottom rear (at tail)
      side * (halfW * 0.54), beltY + 0.09, deckRearZ - 0.08,   // 3: Top rear crest
    ]);
    const bIndices = side === 1 ? [0, 1, 2, 0, 2, 3] : [0, 2, 1, 0, 3, 2];
    const buttressGeo = new THREE.BufferGeometry();
    buttressGeo.setAttribute('position', new THREE.BufferAttribute(buttressPos, 3));
    buttressGeo.setIndex(bIndices);
    buttressGeo.computeVertexNormals();
    const buttressMesh = new THREE.Mesh(buttressGeo, accentPaintMat);
    canopyGroup.add(buttressMesh);
  }

  // 4. Recessed Dark Carbon Rear Engine Bay Deck & 3D Heat-Extractor Louvers (Between Flying Buttresses)
  const deckLen = deckRearZ - roofRearZ;
  const engineDeck = new THREE.Mesh(
    new THREE.BoxGeometry(wRearHalf * 1.85, 0.04, deckLen),
    carbonMat
  );
  engineDeck.position.set(0, (roofH + beltY) * 0.5 - 0.04, (roofRearZ + deckRearZ) * 0.5);
  engineDeck.rotation.x = 0.32;
  canopyGroup.add(engineDeck);

  // 6 Angled Carbon Slotted Engine Cover Louvers
  for (let l = 0; l < 6; l++) {
    const frac = l / 5;
    const lz = THREE.MathUtils.lerp(roofRearZ + 0.14, deckRearZ - 0.14, frac);
    const ly = THREE.MathUtils.lerp(roofH - 0.08, beltY + 0.04, frac);
    const louver = new THREE.Mesh(
      new THREE.BoxGeometry(wRearHalf * 1.45, 0.022, 0.075),
      darkTrimMat
    );
    louver.position.set(0, ly, lz);
    louver.rotation.x = -0.18;
    canopyGroup.add(louver);
  }

  // 5. Interior Cockpit Details (FIA Steel Roll Cage, Racing Bucket Seat & GT Steering Wheel)
  const rollBarGeo = new THREE.CylinderGeometry(0.02, 0.02, wTopHalf * 1.8, 8);
  rollBarGeo.rotateZ(Math.PI / 2);
  const crossBar = new THREE.Mesh(rollBarGeo, chromeMat);
  crossBar.position.set(0, roofH - 0.06, windTopZ + 0.06);
  canopyGroup.add(crossBar);

  const dashBulkhead = new THREE.Mesh(
    new THREE.BoxGeometry(wBaseHalf * 1.7, 0.14, 0.32),
    darkTrimMat
  );
  dashBulkhead.position.set(0, beltY + 0.05, windBaseZ + 0.18);
  canopyGroup.add(dashBulkhead);

  // Racing Steering Wheel Yoke with Red Top Center Marker
  const wheelYoke = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.018, 8, 16), caliperMat);
  wheelYoke.position.set(-0.26, beltY + 0.14, windBaseZ + 0.34);
  wheelYoke.rotation.x = -0.35;
  canopyGroup.add(wheelYoke);

  // 6. Single Center-Parked Motorsport Windshield Wiper Arm & Blade
  const wiperGroup = new THREE.Group();
  const wiperArm = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.48, 0.016), darkTrimMat);
  const wiperBlade = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.44, 0.014), darkTrimMat);
  wiperBlade.position.set(0.012, 0.06, 0.008);
  wiperGroup.add(wiperArm, wiperBlade);
  wiperGroup.position.set(-0.04, (beltY + roofH) * 0.5 + 0.03, (windBaseZ + windTopZ) * 0.5 - 0.04);
  wiperGroup.rotation.x = -0.92;
  wiperGroup.rotation.z = -0.08;
  canopyGroup.add(wiperGroup);

  // 7. Roof Intake Airbox Scoop & 3 Vertical Black Telemetry Whip Antennas (Exact McLaren GT3 Evo Roof Rig!)
  const roofScoop = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.055, 0.32), carbonMat);
  roofScoop.position.set(0, roofH + 0.035, windTopZ + 0.22);
  const roofScoopLip = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.02, 0.06), chromeMat);
  roofScoopLip.position.set(0, roofH + 0.045, windTopZ + 0.07);
  canopyGroup.add(roofScoop, roofScoopLip);

  const antGeo = new THREE.CylinderGeometry(0.0025, 0.005, 0.38, 6);
  const ant1 = new THREE.Mesh(antGeo, darkTrimMat);
  ant1.position.set(0, roofH + 0.21, windTopZ + 0.34);
  const ant2 = new THREE.Mesh(antGeo, darkTrimMat);
  ant2.position.set(-0.14, roofH + 0.17, roofRearZ - 0.05);
  const ant3 = new THREE.Mesh(antGeo, darkTrimMat);
  ant3.position.set(0.14, roofH + 0.15, windTopZ + 0.18);
  canopyGroup.add(ant1, ant2, ant3);

  // 8. Sculpted Aerodynamic Swan-Neck Side Mirrors in Vibrant Primary Livery Color
  for (const side of [-1, 1]) {
    const mirrorGroup = new THREE.Group();
    const housingGeo = new THREE.BoxGeometry(0.19, 0.085, 0.12);
    const housing = new THREE.Mesh(housingGeo, accentPaintMat);

    // Aerodynamic twin stalks connecting mirror to door shoulder
    const stalkUpper = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.015, 0.028), accentPaintMat);
    stalkUpper.position.set(-side * 0.1, -0.01, -0.01);
    stalkUpper.rotation.z = side * 0.16;

    const stalkLower = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.012, 0.022), darkTrimMat);
    stalkLower.position.set(-side * 0.1, -0.04, 0.01);
    stalkLower.rotation.z = side * 0.26;

    mirrorGroup.add(housing, stalkUpper, stalkLower);
    mirrorGroup.position.set(side * (halfW * 0.89), beltY + 0.15, windBaseZ + 0.22);
    mirrorGroup.rotation.y = -side * 0.18;
    canopyGroup.add(mirrorGroup);
  }

  // 9. LMH / LMDh / Bolide Carbon Dorsal Shark Fin
  if (isPrototype) {
    const finShape = new THREE.Shape();
    finShape.moveTo(0, 0);
    finShape.lineTo(0, 0.42);
    finShape.lineTo(1.75, 0.38);
    finShape.lineTo(1.95, 0);
    finShape.lineTo(0, 0);
    const finGeo = new THREE.ExtrudeGeometry(finShape, { steps: 1, depth: 0.026, bevelEnabled: false });
    finGeo.center();
    finGeo.rotateY(Math.PI / 2);
    const finMesh = new THREE.Mesh(finGeo, carbonMat);
    finMesh.position.set(0, roofH + 0.06, (roofRearZ + deckRearZ) * 0.5);
    canopyGroup.add(finMesh);
  }
}

export function buildHypercarRig(options: {
  carId: string;
  paintHex: string;
  finishType: FinishType;
  rimHex: string;
  caliperHex: string;
  aeroPreset: AeroPreset;
  isSoftwareGl: boolean;
  driverName?: string;
}): CarRig {
  const spec: HypercarSpec =
    HYPERCARS.find((c) => c.id === options.carId) || HYPERCARS[0];

  const root = new THREE.Group();
  const chassisGroup = new THREE.Group();
  root.add(chassisGroup);

  // Primary UV-Mapped Works Livery Material (McLaren / GT3 / LMH multi-color decals + carbon)
  const liveryTex = getMotorsportLiveryTexture(spec, options.paintHex);
  const paintMat = new THREE.MeshPhysicalMaterial({
    map: liveryTex,
  });
  configurePaintMaterial(paintMat, options.paintHex, options.finishType);

  // Solid Primary Accent Paint Material (for A-Pillars, Roof, Wing Underside, Endplates, Mirror Caps & Splitter Lip)
  const accentPaintMat = new THREE.MeshPhysicalMaterial();
  configurePaintMaterial(accentPaintMat, options.paintHex, options.finishType);

  const carbonMat = new THREE.MeshPhysicalMaterial({
    color: 0x10141c,
    metalness: 0.5,
    roughness: 0.24,
    clearcoat: 0.9,
    clearcoatRoughness: 0.08,
  });

  const darkTrimMat = new THREE.MeshStandardMaterial({
    color: 0x06080c,
    roughness: 0.85,
    metalness: 0.15,
  });

  const chromeMat = new THREE.MeshPhysicalMaterial({
    color: 0xe2e8f0,
    metalness: 0.95,
    roughness: 0.12,
    clearcoat: 0.8,
  });

  const rimMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(options.rimHex),
    metalness: 0.88,
    roughness: 0.18,
    clearcoat: 0.9,
  });

  const caliperMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(options.caliperHex),
    roughness: 0.22,
    metalness: 0.55,
  });

  // Windshield Material with Manufacturer Sunstrip Banner ("McLaren", etc.) & WEC Number LED
  const windshieldTex = getWindshieldTexture(spec, options.paintHex);
  const glassMat = new THREE.MeshPhysicalMaterial({
    map: windshieldTex,
    color: 0xffffff,
    metalness: 0.18,
    roughness: 0.05,
    clearcoat: 1.0,
    clearcoatRoughness: 0.02,
    transparent: true,
    opacity: 0.97,
  });

  const headlightMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: 0xf8fafc,
    emissiveIntensity: 6.2,
    roughness: 0.04,
  });

  const fogLightMat = new THREE.MeshStandardMaterial({
    color: 0xfef08a,
    emissive: 0xfef08a,
    emissiveIntensity: 4.0,
    roughness: 0.1,
  });

  const brakeLightMat = new THREE.MeshStandardMaterial({
    color: 0xff0000,
    emissive: 0xef4444,
    emissiveIntensity: 3.4,
    roughness: 0.12,
  });

  const fiaRainLightMat = new THREE.MeshStandardMaterial({
    color: 0xff0000,
    emissive: 0xff0000,
    emissiveIntensity: 5.0,
    roughness: 0.08,
  });

  // 1. Grounded Contact Shadow
  const shadowGeo = new THREE.PlaneGeometry(spec.chassisWidth * 1.4, spec.chassisLength * 1.3);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: getContactShadowTexture(),
    transparent: true,
    opacity: 0.72,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const contactShadow = new THREE.Mesh(shadowGeo, shadowMat);
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.02;
  root.add(contactShadow);

  const bodyShell = new THREE.Group();
  chassisGroup.add(bodyShell);

  const canopyGroup = new THREE.Group();
  chassisGroup.add(canopyGroup);

  const engineBlockGroup = new THREE.Group();
  chassisGroup.add(engineBlockGroup);

  const splitterGroup = new THREE.Group();
  chassisGroup.add(splitterGroup);

  const wingGroup = new THREE.Group();
  chassisGroup.add(wingGroup);

  const halfL = spec.chassisLength * 0.5;
  const halfW = spec.chassisWidth * 0.5;

  // 2. Sculpted, Chiseled GT3 / LMH Lower Bodywork (Zero Egg Curvature!)
  const hullGeo = buildSculptedGTBodyGeometry(spec);
  const hullMesh = new THREE.Mesh(hullGeo, paintMat);
  hullMesh.castShadow = !options.isSoftwareGl;
  hullMesh.receiveShadow = !options.isSoftwareGl;
  bodyShell.add(hullMesh);

  // Dark Inner Wheel-Well Arch Liners & Underbody Flat Floor (Eliminates see-through gaps around wheels)
  const underbodyFloor = new THREE.Mesh(
    new THREE.BoxGeometry(spec.chassisWidth * 0.92, 0.05, spec.chassisLength * 0.88),
    darkTrimMat
  );
  underbodyFloor.position.set(0, 0.11, 0);
  bodyShell.add(underbodyFloor);

  // Side Carbon Rocker Skirts, Primary Accent Pinstripe & Front-Wheel Aero Bargeboards (Exact McLaren #59 detail!)
  for (const side of [-1, 1]) {
    const skirtCarbon = new THREE.Mesh(
      new THREE.BoxGeometry(0.14, 0.045, spec.chassisLength * 0.54),
      carbonMat
    );
    skirtCarbon.position.set(side * (halfW * 0.98), 0.085, 0.02);

    const skirtLip = new THREE.Mesh(
      new THREE.BoxGeometry(0.15, 0.018, spec.chassisLength * 0.54),
      accentPaintMat
    );
    skirtLip.position.set(side * (halfW * 0.99), 0.065, 0.02);

    // Vertical Orange/Accent Aero Bargeboard behind front wheel arch (Visible in McLaren #59 reference photo!)
    const bargeboard = new THREE.Mesh(
      new THREE.BoxGeometry(0.03, 0.24, 0.22),
      accentPaintMat
    );
    bargeboard.position.set(side * (halfW * 0.985), 0.21, -halfL * 0.34);

    // Dihedral Door Side Air-Intake Scoop Blade in front of rear wheel arch
    const intakeScoop = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.34, 0.28),
      carbonMat
    );
    intakeScoop.position.set(side * (halfW * 0.94), 0.36, halfL * 0.26);
    intakeScoop.rotation.y = side * 0.18;

    // 3D Raised Front Fender Wheel-Arch Carbon Louver Slats
    const louverHousing = new THREE.Mesh(
      new THREE.BoxGeometry(0.22, 0.018, 0.34),
      carbonMat
    );
    louverHousing.position.set(side * (halfW * 0.72), 0.625, -halfL * 0.56);
    louverHousing.rotation.x = 0.14;

    bodyShell.add(skirtCarbon, skirtLip, bargeboard, intakeScoop, louverHousing);
  }

  // 3. Wide, Flat-Planed Supercar Greenhouse (Windshield, Painted A-Pillars, Roof, Side Glass & Flying Buttresses)
  populateSupercarGreenhouse(
    canopyGroup,
    spec,
    glassMat,
    paintMat,
    accentPaintMat,
    carbonMat,
    darkTrimMat,
    chromeMat,
    caliperMat
  );

  // 4. Internal Twin-Turbo V8 / V6 / V12 Powertrain Block
  const engineCore = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.30, 0.86), chromeMat);
  engineCore.position.set(0, 0.42, 0.72);
  engineBlockGroup.add(engineCore);

  const plenumGeo = new THREE.CylinderGeometry(0.085, 0.085, 0.74, 12);
  plenumGeo.rotateX(Math.PI / 2);
  const plenumL = new THREE.Mesh(plenumGeo, caliperMat);
  plenumL.position.set(-0.18, 0.58, 0.72);
  const plenumR = new THREE.Mesh(plenumGeo, caliperMat);
  plenumR.position.set(0.18, 0.58, 0.72);
  engineBlockGroup.add(plenumL, plenumR);

  // 5. Front Aero Fascia: Wide Carbon Splitter, Vibrant Accent Leading Lip, Recessed Radiator Cavity with 3D Steel X-Braces, Fog Pods & Flush Headlights
  const splitSpan = options.aeroPreset === 'widebody' ? spec.chassisWidth * 1.05 : spec.chassisWidth * 1.02;
  const splitterShape = new THREE.Shape();
  splitterShape.moveTo(-splitSpan * 0.5, 0);
  splitterShape.quadraticCurveTo(0, -0.26, splitSpan * 0.5, 0);
  splitterShape.lineTo(splitSpan * 0.48, 0.48);
  splitterShape.lineTo(-splitSpan * 0.48, 0.48);
  splitterShape.closePath();

  const splitterGeo = new THREE.ExtrudeGeometry(splitterShape, {
    depth: 0.032,
    bevelEnabled: true,
    bevelThickness: 0.01,
    bevelSize: 0.014,
    bevelSegments: 2,
  });
  splitterGeo.center();
  splitterGeo.rotateX(Math.PI / 2);
  const splitterMesh = new THREE.Mesh(splitterGeo, carbonMat);
  splitterMesh.position.set(0, 0.072, -halfL + 0.15);
  splitterGroup.add(splitterMesh);

  // Vibrant Primary-Colored Splitter Leading-Edge Pinstripe Lip (Signature McLaren #59 orange lip!)
  const lipStripGeo = new THREE.ExtrudeGeometry(splitterShape, {
    depth: 0.015,
    bevelEnabled: false,
  });
  lipStripGeo.center();
  lipStripGeo.rotateX(Math.PI / 2);
  const lipStripMesh = new THREE.Mesh(lipStripGeo, accentPaintMat);
  lipStripMesh.scale.set(1.012, 1, 1.012);
  lipStripMesh.position.set(0, 0.056, -halfL + 0.14);
  splitterGroup.add(lipStripMesh);

  // Recessed Front Lower Radiator Mouth (Tucked cleanly under the nose edge — never sticking out!)
  const grilleWidth = spec.chassisWidth * 0.54;
  const grilleHeight = 0.19;
  const grilleZ = -halfL + 0.08;
  const grilleY = 0.185;

  const grilleMat = new THREE.MeshStandardMaterial({
    map: getRadiatorGrilleTexture(),
    roughness: 0.5,
    metalness: 0.45,
  });
  const grilleBox = new THREE.Mesh(
    new THREE.BoxGeometry(grilleWidth, grilleHeight, 0.09),
    grilleMat
  );
  grilleBox.position.set(0, grilleY, grilleZ);
  splitterGroup.add(grilleBox);

  // Physical 3D Stainless-Steel Tubular X-Brace Truss Bars inside the Front Radiator Mouth (Exact McLaren #59 detail!)
  const braceRadius = 0.0075;
  const braceLen = 0.34;
  const braceGeo = new THREE.CylinderGeometry(braceRadius, braceRadius, braceLen, 8);
  for (const side of [-1, 1]) {
    const bx = side * (grilleWidth * 0.23);
    const bar1 = new THREE.Mesh(braceGeo, chromeMat);
    bar1.position.set(bx, grilleY, grilleZ - 0.048);
    bar1.rotation.z = 0.92;

    const bar2 = new THREE.Mesh(braceGeo, chromeMat);
    bar2.position.set(bx, grilleY, grilleZ - 0.048);
    bar2.rotation.z = -0.92;
    splitterGroup.add(bar1, bar2);
  }
  // Center vertical radiator support post
  const centerPost = new THREE.Mesh(
    new THREE.CylinderGeometry(0.009, 0.009, grilleHeight, 8),
    darkTrimMat
  );
  centerPost.position.set(0, grilleY, grilleZ - 0.05);
  splitterGroup.add(centerPost);

  // Twin Vertical Endurance LED Fog-Light Pods flanking the Lower Grille
  for (const side of [-1, 1]) {
    const podX = side * (grilleWidth * 0.5 + 0.075);
    const podHousing = new THREE.Mesh(new THREE.BoxGeometry(0.105, 0.175, 0.08), darkTrimMat);
    podHousing.position.set(podX, grilleY, grilleZ);
    splitterGroup.add(podHousing);

    for (let b = -1; b <= 1; b++) {
      const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 8), fogLightMat);
      bulb.position.set(podX, grilleY + b * 0.045, grilleZ - 0.042);
      splitterGroup.add(bulb);
    }
  }

  // Flush-Contoured Aerodynamic Headlight Assemblies & Stacked Twin Carbon Dive Planes (NO protruding brick boxes!)
  for (const side of [-1, 1]) {
    const hlGroup = new THREE.Group();

    // Ultra-low-profile dark carbon aerodynamic teardrop bezel contoured flush to the fender slope
    const bezelGeo = new THREE.BoxGeometry(0.36, 0.036, 0.26);
    const bezelMesh = new THREE.Mesh(bezelGeo, darkTrimMat);

    // Piercing primary horizontal LED DRL blade
    const ledBladeGeo = new THREE.BoxGeometry(0.32, 0.022, 0.08);
    const ledBlade = new THREE.Mesh(ledBladeGeo, headlightMat);
    ledBlade.position.set(0, 0.014, -0.05);

    // Inner & outer high-intensity bi-LED projector lenses
    const lensGeo = new THREE.SphereGeometry(0.028, 12, 8);
    lensGeo.scale(1.2, 0.55, 1.2);
    const lensOuter = new THREE.Mesh(lensGeo, headlightMat);
    lensOuter.position.set(side * 0.07, 0.015, 0.02);
    const lensInner = new THREE.Mesh(lensGeo, headlightMat);
    lensInner.position.set(-side * 0.06, 0.015, 0.03);

    hlGroup.add(bezelMesh, ledBlade, lensOuter, lensInner);
    // Positioned and pitched to lie 100% FLUSH on the front fender slope!
    hlGroup.position.set(side * (halfW * 0.72), 0.365, -halfL * 0.85);
    hlGroup.rotation.x = 0.29;
    hlGroup.rotation.y = -side * 0.24;
    hlGroup.rotation.z = -side * 0.08;
    splitterGroup.add(hlGroup);

    // Stacked Twin Carbon Dive Planes (Canards) with Vibrant Primary Accent Trim on Front Bumper Corners
    for (let c = 0; c < 2; c++) {
      const canard = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.014, 0.24), carbonMat);
      canard.position.set(
        side * (halfW * 0.93),
        0.20 + c * 0.085,
        -halfL * 0.86 + c * 0.04
      );
      canard.rotation.z = -side * 0.24;
      canard.rotation.x = 0.20;

      const canardEdge = new THREE.Mesh(new THREE.BoxGeometry(0.175, 0.01, 0.028), accentPaintMat);
      canardEdge.position.set(
        side * (halfW * 0.935),
        0.20 + c * 0.085,
        -halfL * 0.86 + c * 0.04 - 0.11
      );
      canardEdge.rotation.z = -side * 0.24;
      splitterGroup.add(canard, canardEdge);
    }
  }

  // 6. Rear 3D LED Taillight Ribbon, Multi-Strake Carbon Diffuser, FIA Rain Light & Titanium Exhausts
  const rearRibbon = new THREE.Mesh(
    new THREE.BoxGeometry(spec.chassisWidth * 0.88, 0.044, 0.06),
    brakeLightMat
  );
  rearRibbon.position.set(0, 0.50, halfL - 0.02);
  splitterGroup.add(rearRibbon);

  const diffuserMesh = new THREE.Mesh(
    new THREE.BoxGeometry(spec.chassisWidth * 0.92, 0.18, 0.42),
    carbonMat
  );
  diffuserMesh.position.set(0, 0.17, halfL - 0.1);
  splitterGroup.add(diffuserMesh);

  for (let s = -2; s <= 2; s++) {
    if (s === 0) continue;
    const strake = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.16, 0.46), carbonMat);
    strake.position.set(s * 0.3, 0.15, halfL - 0.08);
    splitterGroup.add(strake);
  }

  const fiaRain = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.07, 0.04), fiaRainLightMat);
  fiaRain.position.set(0, 0.19, halfL + 0.02);
  splitterGroup.add(fiaRain);

  const exhaustGeo = new THREE.CylinderGeometry(0.062, 0.062, 0.22, 16);
  exhaustGeo.rotateX(Math.PI / 2);
  const exLeft = new THREE.Mesh(exhaustGeo, chromeMat);
  exLeft.position.set(-0.32, 0.36, halfL + 0.04);
  const exRight = new THREE.Mesh(exhaustGeo, chromeMat);
  exRight.position.set(0.32, 0.36, halfL + 0.04);
  splitterGroup.add(exLeft, exRight);

  // Nitro Exhaust Flame Cones
  const flameGeo = new THREE.ConeGeometry(0.09, 0.72, 12);
  flameGeo.rotateX(Math.PI / 2);
  const flameMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.9,
    depthWrite: false,
  });
  const nitroFlameLeft = new THREE.Mesh(flameGeo, flameMat);
  nitroFlameLeft.position.set(-0.32, 0.36, halfL + 0.44);
  nitroFlameLeft.visible = false;

  const nitroFlameRight = new THREE.Mesh(flameGeo, flameMat);
  nitroFlameRight.position.set(0.32, 0.36, halfL + 0.44);
  nitroFlameRight.visible = false;
  splitterGroup.add(nitroFlameLeft, nitroFlameRight);

  // 7. Towering Top-Mounted Swan-Neck GT3 Rear Wing with Vibrant Painted Underside & Endplates
  if (options.aeroPreset !== 'street') {
    const wingSpan =
      options.aeroPreset === 'widebody' ? spec.chassisWidth * 1.1 : spec.chassisWidth * 1.02;
    const wingY = Math.min(spec.roofHeight, 1.08) + 0.12;
    const wingZ = halfL - 0.16;

    // Top Carbon Airfoil Surface
    const wingTopBlade = new THREE.Mesh(
      new THREE.BoxGeometry(wingSpan, 0.02, 0.36),
      carbonMat
    );
    wingTopBlade.position.set(0, wingY + 0.01, wingZ);
    wingTopBlade.rotation.x = 0.12;

    // Bright Primary-Colored (Papaya Orange / Team Livery) Wing Underside
    const wingBottomBlade = new THREE.Mesh(
      new THREE.BoxGeometry(wingSpan * 0.99, 0.02, 0.35),
      accentPaintMat
    );
    wingBottomBlade.position.set(0, wingY - 0.008, wingZ);
    wingBottomBlade.rotation.x = 0.12;

    // Leading-Edge Black Gurney Strip
    const wingLip = new THREE.Mesh(
      new THREE.BoxGeometry(wingSpan, 0.026, 0.036),
      darkTrimMat
    );
    wingLip.position.set(0, wingY - 0.01, wingZ - 0.17);
    wingGroup.add(wingTopBlade, wingBottomBlade, wingLip);

    // Tall Angled Swan-Neck Pylons & Top-Mount Gooseneck Hooks
    for (const side of [-1, 1]) {
      const px = side * 0.38;
      const strut = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.62, 0.13), darkTrimMat);
      strut.position.set(px, wingY - 0.25, wingZ - 0.08);
      strut.rotation.x = -0.22;

      const hook = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.10, 0.24), darkTrimMat);
      hook.position.set(px, wingY + 0.045, wingZ - 0.04);

      const bracket = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.042, 0.085), chromeMat);
      bracket.position.set(px, wingY + 0.034, wingZ + 0.02);

      wingGroup.add(strut, hook, bracket);
    }

    // Large Contoured Wing Endplates in Vibrant Primary Livery Color
    const endplateGeo = new THREE.BoxGeometry(0.026, 0.32, 0.48);
    const epL = new THREE.Mesh(endplateGeo, accentPaintMat);
    epL.position.set(-wingSpan * 0.5, wingY - 0.04, wingZ + 0.02);
    const epR = new THREE.Mesh(endplateGeo, accentPaintMat);
    epR.position.set(wingSpan * 0.5, wingY - 0.04, wingZ + 0.02);
    wingGroup.add(epL, epR);
  } else {
    const duckMesh = new THREE.Mesh(
      new THREE.BoxGeometry(spec.chassisWidth * 0.85, 0.08, 0.25),
      accentPaintMat
    );
    duckMesh.position.set(0, 0.64, halfL - 0.12);
    duckMesh.rotation.x = 0.22;
    wingGroup.add(duckMesh);
  }

  // 8. Deep-Dish GT3 Center-Lock Wheels with Goodyear Sidewall Lettering & Rounded Tire Shoulders
  const tireTreadMat = new THREE.MeshStandardMaterial({
    color: 0x0e1015,
    roughness: 0.85,
    metalness: 0.05,
  });

  const tireSidewallMat = new THREE.MeshStandardMaterial({
    map: getTireSidewallTexture(),
    roughness: 0.72,
    metalness: 0.05,
  });

  const rotorMat = new THREE.MeshStandardMaterial({
    color: 0x64748b,
    metalness: 0.92,
    roughness: 0.2,
  });

  const centerNutMatL = new THREE.MeshPhysicalMaterial({
    color: 0xef4444,
    metalness: 0.92,
    roughness: 0.15,
  });
  const centerNutMatR = new THREE.MeshPhysicalMaterial({
    color: 0x3b82f6,
    metalness: 0.92,
    roughness: 0.15,
  });

  const wheelSpinners: THREE.Object3D[] = [];

  function createGT3WheelAssembly(isLeft: boolean, isRear: boolean): THREE.Group {
    const wheelHolder = new THREE.Group();
    const spinner = new THREE.Group();

    const radius = isRear ? 0.365 : 0.35;
    const width = isRear ? 0.34 : 0.30;

    // Multi-material Cylinder: [tread, outer sidewall, inner sidewall]
    const tireGeo = new THREE.CylinderGeometry(radius, radius, width, 32);
    tireGeo.rotateZ(Math.PI / 2);
    const tireMesh = new THREE.Mesh(tireGeo, [
      tireTreadMat,
      tireSidewallMat,
      tireSidewallMat,
    ]);
    tireMesh.castShadow = !options.isSoftwareGl;
    spinner.add(tireMesh);

    // Outer Rim Flange Ring
    const rimLipGeo = new THREE.RingGeometry(radius * 0.64, radius * 0.72, 28);
    rimLipGeo.rotateY(isLeft ? -Math.PI / 2 : Math.PI / 2);
    const rimLipMesh = new THREE.Mesh(rimLipGeo, rimMat);
    rimLipMesh.position.x = isLeft ? -width * 0.5 - 0.003 : width * 0.5 + 0.003;
    spinner.add(rimLipMesh);

    // Deep-Dish Recessed Dark Barrel
    const barrelGeo = new THREE.CylinderGeometry(radius * 0.66, radius * 0.66, width * 0.96, 24);
    barrelGeo.rotateZ(Math.PI / 2);
    const barrelMesh = new THREE.Mesh(barrelGeo, darkTrimMat);
    spinner.add(barrelMesh);

    // 10-Spoke GT3 Forged Twin-Spoke Spider
    const spokeGeo = new THREE.BoxGeometry(0.024, radius * 1.32, 0.025);
    for (let s = 0; s < 5; s++) {
      const spokeA = new THREE.Mesh(spokeGeo, rimMat);
      spokeA.position.x = isLeft ? -width * 0.44 : width * 0.44;
      spokeA.rotation.x = (s * Math.PI) / 5 + 0.08;

      const spokeB = new THREE.Mesh(spokeGeo, rimMat);
      spokeB.position.x = isLeft ? -width * 0.44 : width * 0.44;
      spokeB.rotation.x = (s * Math.PI) / 5 - 0.08;
      spinner.add(spokeA, spokeB);
    }

    // Center-Lock Hub & Anodized Nut
    const hubGeo = new THREE.CylinderGeometry(0.072, 0.072, width + 0.015, 16);
    hubGeo.rotateZ(Math.PI / 2);
    const hubMesh = new THREE.Mesh(hubGeo, chromeMat);
    spinner.add(hubMesh);

    const nutGeo = new THREE.CylinderGeometry(0.04, 0.04, width + 0.028, 12);
    nutGeo.rotateZ(Math.PI / 2);
    const nutMesh = new THREE.Mesh(nutGeo, isLeft ? centerNutMatL : centerNutMatR);
    spinner.add(nutMesh);

    // Cross-Drilled Steel/Carbon Brake Rotor & AP Racing / Brembo Caliper
    const rotorGeo = new THREE.CylinderGeometry(radius * 0.58, radius * 0.58, 0.04, 24);
    rotorGeo.rotateZ(Math.PI / 2);
    const rotorMesh = new THREE.Mesh(rotorGeo, rotorMat);
    wheelHolder.add(rotorMesh);

    const caliperGeo = new THREE.BoxGeometry(0.09, 0.24, 0.15);
    const caliperMesh = new THREE.Mesh(caliperGeo, caliperMat);
    caliperMesh.position.set(isLeft ? -0.08 : 0.08, 0.06, -0.15);
    wheelHolder.add(caliperMesh);

    wheelHolder.add(spinner);
    wheelSpinners.push(spinner);
    return wheelHolder;
  }

  // Wheels tucked flush with the widebody GT3 fender arches
  const wheelFL = createGT3WheelAssembly(true, false);
  wheelFL.position.set(-halfW * 0.87, 0.35, -halfL * 0.56);

  const wheelFR = createGT3WheelAssembly(false, false);
  wheelFR.position.set(halfW * 0.87, 0.35, -halfL * 0.56);

  const wheelRL = createGT3WheelAssembly(true, true);
  wheelRL.position.set(-halfW * 0.88, 0.365, halfL * 0.55);

  const wheelRR = createGT3WheelAssembly(false, true);
  wheelRR.position.set(halfW * 0.88, 0.365, halfL * 0.55);

  root.add(wheelFL, wheelFR, wheelRL, wheelRR);

  let nametagSprite: THREE.Sprite | undefined;
  if (options.driverName) {
    nametagSprite = createNametagSprite(options.driverName, options.paintHex);
    root.add(nametagSprite);
  }

  return {
    root,
    chassisGroup,
    bodyShell,
    canopyGroup,
    engineBlockGroup,
    splitterGroup,
    wingGroup,
    wheelFL,
    wheelFR,
    wheelRL,
    wheelRR,
    wheelSpinners,
    paintMaterials: [paintMat, accentPaintMat],
    rimMaterials: [rimMat],
    caliperMaterials: [caliperMat],
    brakeLightMaterial: brakeLightMat,
    nitroFlameLeft,
    nitroFlameRight,
    contactShadow,
    nametagSprite,
    currentExploded: 0,
  };
}

export function updateCarExplodedView(
  rig: CarRig,
  targetExploded: number,
  dt: number,
  spec: HypercarSpec
) {
  rig.currentExploded = THREE.MathUtils.damp(rig.currentExploded, targetExploded, 8, dt);
  const e = rig.currentExploded;

  const halfL = spec.chassisLength * 0.5;
  const halfW = spec.chassisWidth * 0.5;

  rig.canopyGroup.position.set(0, e * 1.15, 0);
  rig.bodyShell.position.set(0, e * 0.42, 0);
  rig.engineBlockGroup.position.set(0, e * 0.85, e * 0.35);
  rig.splitterGroup.position.set(0, -e * 0.14, -e * 0.6);
  rig.wingGroup.position.set(0, e * 0.82, e * 0.68);

  rig.wheelFL.position.set(-halfW * 0.87 - e * 0.78, 0.35, -halfL * 0.56 - e * 0.22);
  rig.wheelFR.position.set(halfW * 0.87 + e * 0.78, 0.35, -halfL * 0.56 - e * 0.22);
  rig.wheelRL.position.set(-halfW * 0.88 - e * 0.78, 0.365, halfL * 0.55 + e * 0.22);
  rig.wheelRR.position.set(halfW * 0.88 + e * 0.78, 0.365, halfL * 0.55 + e * 0.22);
}
