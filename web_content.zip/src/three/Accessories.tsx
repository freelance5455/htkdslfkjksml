import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { itemById } from "../lib/catalog";
import { demonTexture, shade } from "./textures";

const byId = (id: string | null) => itemById(id);

function Fabric({ color, rough = 0.72 }: { color: string; rough?: number }) {
  return <meshPhysicalMaterial color={color} roughness={rough} metalness={0} sheen={0.7} sheenColor="#ffffff" />;
}
function Shiny({ color, rough = 0.18, metal = 1 }: { color: string; rough?: number; metal?: number }) {
  return <meshStandardMaterial color={color} roughness={rough} metalness={metal} envMapIntensity={1.4} />;
}

/* ================================================================== */
/*  HATS — anchored on top of the head (head radius 0.64)              */
/* ================================================================== */
export function Hat({ id }: { id: string | null }) {
  const item = byId(id);
  const group = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!group.current) return;
    const t = state.clock.elapsedTime;
    group.current.rotation.z = Math.sin(t * 1.4) * 0.035;
  });

  if (!item) return null;
  const c = item.tint;
  const c2 = item.tint2 ?? "#ffffff";

  return (
    <group ref={group} position={[0, 0.5, 0]}>
      {item.id === "beanie" && (
        <group position={[0, 0.03, 0]}>
          <mesh position={[0, 0.08, 0]} scale={[1, 0.86, 1]}>
            <sphereGeometry args={[0.52, 28, 20, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <Fabric color={c} />
          </mesh>
          <mesh position={[0, 0.06, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.5, 0.085, 14, 34]} />
            <Fabric color={c2} />
          </mesh>
          <mesh position={[0, 0.5, 0]}>
            <sphereGeometry args={[0.13, 20, 16]} />
            <Fabric color={c2} rough={0.85} />
          </mesh>
        </group>
      )}

      {item.id === "cap" && (
        <group position={[0, 0.02, 0]}>
          <mesh position={[0, 0.05, 0]} scale={[1, 0.72, 1]}>
            <sphereGeometry args={[0.52, 28, 20, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <Fabric color={c} />
          </mesh>
          <mesh position={[0, 0.07, 0.4]} rotation={[0.12, 0, 0]} scale={[1, 0.16, 1]}>
            <cylinderGeometry args={[0.34, 0.34, 0.42, 24, 1, false, -Math.PI / 2, Math.PI]} />
            <Fabric color={c2} />
          </mesh>
          <mesh position={[0, 0.38, 0]}>
            <sphereGeometry args={[0.06, 14, 12]} />
            <Fabric color={c2} />
          </mesh>
        </group>
      )}

      {item.id === "party" && (
        <group position={[0, 0.05, 0]} rotation={[0.1, 0, 0.14]}>
          <mesh position={[0, 0.34, 0]}>
            <coneGeometry args={[0.32, 0.78, 26]} />
            <Fabric color={c} rough={0.45} />
          </mesh>
          {[0.12, 0.32, 0.52].map((y, i) => (
            <mesh key={i} position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.31 - i * 0.083, 0.022, 10, 26]} />
              <Fabric color={c2} rough={0.4} />
            </mesh>
          ))}
          <mesh position={[0, 0.78, 0]}>
            <sphereGeometry args={[0.1, 18, 14]} />
            <Fabric color={c2} rough={0.6} />
          </mesh>
        </group>
      )}

      {item.id === "tophat" && (
        <group position={[0, 0.04, 0]} rotation={[0.05, 0, -0.08]}>
          <mesh position={[0, 0.02, 0]}>
            <cylinderGeometry args={[0.56, 0.58, 0.06, 32]} />
            <Fabric color={c} rough={0.5} />
          </mesh>
          <mesh position={[0, 0.32, 0]}>
            <cylinderGeometry args={[0.35, 0.36, 0.58, 32]} />
            <Fabric color={c} rough={0.5} />
          </mesh>
          <mesh position={[0, 0.12, 0]}>
            <cylinderGeometry args={[0.368, 0.372, 0.1, 32]} />
            <Fabric color={c2} rough={0.45} />
          </mesh>
        </group>
      )}

      {(item.id === "horns_devil" || item.id === "horns_demon") && (
        <Horns molten={item.id === "horns_demon"} c={c} c2={c2} />
      )}

      {item.id === "halo" && <Halo c={c} c2={c2} />}

      {item.id === "crown" && (
        <group position={[0, 0.08, 0]}>
          <mesh>
            <cylinderGeometry args={[0.42, 0.44, 0.2, 26, 1, true]} />
            <Shiny color={c} rough={0.22} />
          </mesh>
          <mesh position={[0, -0.1, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.43, 0.035, 12, 28]} />
            <Shiny color={c} />
          </mesh>
          {Array.from({ length: 7 }).map((_, i) => {
            const a = (i / 7) * Math.PI * 2;
            return (
              <group key={i} position={[Math.cos(a) * 0.42, 0.1, Math.sin(a) * 0.42]}>
                <mesh position={[0, 0.09, 0]}>
                  <coneGeometry args={[0.075, 0.2, 12]} />
                  <Shiny color={c} />
                </mesh>
                <mesh position={[0, 0.22, 0]}>
                  <icosahedronGeometry args={[0.045, 0]} />
                  <meshPhysicalMaterial
                    color={c2}
                    roughness={0.05}
                    metalness={0.1}
                    transmission={0.6}
                    thickness={0.3}
                  />
                </mesh>
              </group>
            );
          })}
        </group>
      )}
    </group>
  );
}

/* ================================================================== */
/*  GLASSES — sit in front of the eyes (eyes at y 0.12, z 0.575)       */
/* ================================================================== */
export function Glasses({ id }: { id: string | null }) {
  const item = byId(id);
  if (!item) return null;
  const c = item.tint;
  const c2 = item.tint2 ?? "#ffffff";

  const Lens = ({ x }: { x: number }) => (
    <group position={[x, 0, 0]}>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.145, 0.024, 12, 26]} />
        <Shiny color={c} rough={0.3} metal={0.7} />
      </mesh>
      <mesh>
        <circleGeometry args={[0.142, 26]} />
        <meshPhysicalMaterial
          color={c2}
          roughness={0.06}
          metalness={0}
          transmission={0.75}
          thickness={0.1}
          transparent
          opacity={0.72}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );

  return (
    <group position={[0, 0.13, 0.6]}>
      {item.id === "round" && (
        <>
          <Lens x={0.215} />
          <Lens x={-0.215} />
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.016, 0.016, 0.15, 10]} />
            <Shiny color={c} rough={0.3} metal={0.7} />
          </mesh>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 0.37, 0.02, -0.13]} rotation={[0, s * 1.0, 0]}>
              <cylinderGeometry args={[0.014, 0.014, 0.26, 8]} />
              <Shiny color={c} rough={0.3} metal={0.7} />
            </mesh>
          ))}
        </>
      )}

      {item.id === "shades" && (
        <>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 0.2, 0.01, 0]} rotation={[0, s * -0.12, s * 0.06]}>
              <boxGeometry args={[0.3, 0.19, 0.05]} />
              <meshPhysicalMaterial
                color={c}
                roughness={0.08}
                metalness={0.2}
                clearcoat={1}
                clearcoatRoughness={0.05}
              />
            </mesh>
          ))}
          <mesh position={[0, 0.03, 0]}>
            <boxGeometry args={[0.13, 0.045, 0.045]} />
            <Shiny color={c2} rough={0.25} metal={0.5} />
          </mesh>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 0.37, 0.04, -0.13]} rotation={[0, s * 1.0, 0]}>
              <boxGeometry args={[0.03, 0.04, 0.28]} />
              <Shiny color={c2} rough={0.3} metal={0.4} />
            </mesh>
          ))}
        </>
      )}

      {item.id === "retro" && (
        <>
          {[
            { x: 0.215, col: c },
            { x: -0.215, col: c2 },
          ].map((l, i) => (
            <group key={i} position={[l.x, 0, 0]}>
              <mesh rotation={[Math.PI / 2, 0, 0]}>
                <torusGeometry args={[0.15, 0.03, 10, 4]} />
                <Fabric color="#2A2A33" rough={0.35} />
              </mesh>
              <mesh>
                <circleGeometry args={[0.145, 4]} />
                <meshPhysicalMaterial
                  color={l.col}
                  transmission={0.7}
                  thickness={0.1}
                  roughness={0.05}
                  transparent
                  opacity={0.78}
                  side={THREE.DoubleSide}
                />
              </mesh>
            </group>
          ))}
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <boxGeometry args={[0.035, 0.13, 0.035]} />
            <Fabric color="#2A2A33" rough={0.35} />
          </mesh>
        </>
      )}

      {item.id === "visor_cyber" && <CyberVisor c={c} c2={c2} />}
      {item.id === "shades_holo" && <HoloShades c={c} c2={c2} />}

      {item.id === "vr" && (
        <>
          <mesh position={[0, 0.02, 0.02]}>
            <boxGeometry args={[0.66, 0.29, 0.19]} />
            <meshPhysicalMaterial color={c} roughness={0.35} metalness={0.25} clearcoat={0.6} />
          </mesh>
          <mesh position={[0, 0.02, 0.125]}>
            <boxGeometry args={[0.6, 0.22, 0.02]} />
            <meshStandardMaterial
              color={c2}
              emissive={c2}
              emissiveIntensity={1.6}
              roughness={0.2}
            />
          </mesh>
          <mesh position={[0, 0.02, -0.12]} rotation={[0, 0, 0]}>
            <torusGeometry args={[0.42, 0.035, 10, 24, Math.PI]} />
            <Fabric color="#23242B" rough={0.6} />
          </mesh>
        </>
      )}
    </group>
  );
}

/* ================================================================== */
/*  NECK — worn between head and body (body group space)               */
/* ================================================================== */
export function Neck({ id }: { id: string | null }) {
  const item = byId(id);
  const bell = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (!bell.current) return;
    bell.current.rotation.z = Math.sin(state.clock.elapsedTime * 3.1) * 0.22;
  });

  if (!item) return null;
  const c = item.tint;
  const c2 = item.tint2 ?? "#ffffff";

  return (
    <group position={[0, 0.52, 0.12]}>
      {item.id === "bowtie" && (
        <group position={[0, -0.06, 0.84]} rotation={[0.25, 0, 0]}>
          <mesh position={[0.14, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
            <coneGeometry args={[0.12, 0.19, 4]} />
            <Fabric color={c} rough={0.5} />
          </mesh>
          <mesh position={[-0.14, 0, 0]} rotation={[0, 0, -Math.PI / 2]}>
            <coneGeometry args={[0.12, 0.19, 4]} />
            <Fabric color={c} rough={0.5} />
          </mesh>
          <mesh>
            <sphereGeometry args={[0.055, 16, 12]} />
            <Fabric color={c2} rough={0.45} />
          </mesh>
        </group>
      )}

      {item.id === "scarf" && (
        <group position={[0, -0.06, 0]}>
          {/* ring sized to sit ON the body surface, not inside it */}
          <mesh rotation={[Math.PI / 2, 0, 0]} scale={[1, 1, 0.94]} castShadow>
            <torusGeometry args={[0.9, 0.12, 14, 34]} />
            <Fabric color={c} rough={0.85} />
          </mesh>
          {/* trailing end hangs down the front */}
          <mesh position={[0.34, -0.3, 0.72]} rotation={[0.26, 0.24, 0.2]} castShadow>
            <boxGeometry args={[0.2, 0.46, 0.1]} />
            <Fabric color={c} rough={0.85} />
          </mesh>
          <mesh position={[0.37, -0.54, 0.78]} rotation={[0.26, 0.24, 0.2]}>
            <boxGeometry args={[0.2, 0.09, 0.1]} />
            <Fabric color={c2} rough={0.85} />
          </mesh>
        </group>
      )}

      {item.id === "bell" && (
        <group position={[0, -0.08, 0]}>
          <mesh rotation={[Math.PI / 2, 0, 0]} scale={[1, 1, 0.94]} castShadow>
            <torusGeometry args={[0.89, 0.07, 12, 34]} />
            <Fabric color={c} rough={0.5} />
          </mesh>
          {/* bell hangs off the front of the collar */}
          <mesh ref={bell} position={[0, -0.13, 0.84]} castShadow>
            <sphereGeometry args={[0.11, 20, 16]} />
            <Shiny color={c2} rough={0.16} />
          </mesh>
        </group>
      )}

      {item.id === "chain" && (
        <group position={[0, -0.08, 0]}>
          {Array.from({ length: 26 }).map((_, i) => {
            const a = (i / 26) * Math.PI * 2;
            const r = 0.89;
            return (
              <mesh
                key={i}
                position={[Math.cos(a) * r, Math.sin(a) * 0.08 - 0.02, Math.sin(a) * r * 0.94]}
                rotation={[0, -a, 0]}
                castShadow
              >
                <torusGeometry args={[0.05, 0.018, 8, 14]} />
                <Shiny color={c} rough={0.14} />
              </mesh>
            );
          })}
          {/* pendant sits proud of the chest */}
          <mesh position={[0, -0.22, 0.88]} rotation={[0.2, 0, 0]} castShadow>
            <icosahedronGeometry args={[0.11, 0]} />
            <Shiny color={c2} rough={0.1} />
          </mesh>
        </group>
      )}
    </group>
  );
}

/* ================================================================== */
/*  BUDDY — held / worn extras                                         */
/* ================================================================== */
export function Buddy({ id }: { id: string | null }) {
  const item = byId(id);
  const float = useRef<THREE.Group>(null);
  const wingsRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!float.current) return;
    const t = state.clock.elapsedTime;
    float.current.position.y = Math.sin(t * 1.3) * 0.1;
    float.current.rotation.z = Math.sin(t * 0.9) * 0.12;
  });

  useFrame((state) => {
    if (!wingsRef.current) return;
    const t = state.clock.elapsedTime;
    // slow angelic flap
    wingsRef.current.children.forEach((c, i) => {
      const sd = i === 0 ? -1 : 1;
      c.rotation.y = sd * (0.3 + Math.sin(t * 1.6) * 0.22);
    });
  });

  const swirl = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = 128;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, 128, 128);
    ctx.strokeStyle = "#FF4D6D";
    ctx.lineWidth = 13;
    for (let i = -6; i < 12; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 20, 0);
      ctx.lineTo(i * 20 + 128, 128);
      ctx.stroke();
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, []);

  if (!item) return null;
  const c = item.tint;
  const c2 = item.tint2 ?? "#ffffff";

  return (
    <>
      {item.id === "candy" && (
        <group position={[0.95, -0.5, 0.5]} rotation={[0, 0, -0.3]}>
          <mesh position={[0, 0.2, 0]}>
            <cylinderGeometry args={[0.028, 0.028, 0.62, 10]} />
            <Fabric color="#F6E7CB" rough={0.6} />
          </mesh>
          <mesh position={[0, 0.62, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.24, 0.24, 0.06, 30]} />
            {swirl ? (
              <meshStandardMaterial map={swirl} roughness={0.12} metalness={0} />
            ) : (
              <meshStandardMaterial color={c} roughness={0.12} />
            )}
          </mesh>
        </group>
      )}

      {item.id === "balloon" && (
        <group position={[0.85, 0.6, 0.2]}>
          <group ref={float}>
            <mesh position={[0, 0.95, 0]} scale={[1, 1.18, 1]}>
              <sphereGeometry args={[0.36, 26, 20]} />
              <meshPhysicalMaterial
                color={c}
                roughness={0.12}
                metalness={0}
                clearcoat={1}
                clearcoatRoughness={0.08}
                transmission={0.15}
                thickness={0.4}
              />
            </mesh>
            <mesh position={[0, 0.53, 0]}>
              <coneGeometry args={[0.06, 0.1, 10]} />
              <Fabric color={c} rough={0.2} />
            </mesh>
            <mesh position={[0, 0.16, 0]}>
              <cylinderGeometry args={[0.008, 0.008, 0.72, 6]} />
              <meshStandardMaterial color={c2} roughness={0.6} />
            </mesh>
          </group>
        </group>
      )}

      {item.id === "backpack" && (
        /* pushed clear of the body (radius ~0.94 in Z) so it reads as a pack
           on the back instead of being swallowed by the belly */
        <group position={[0, -0.04, -1.1]} rotation={[0.12, 0, 0]}>
          {/* main bag */}
          <mesh scale={[1, 1.02, 0.64]} castShadow>
            <sphereGeometry args={[0.42, 24, 18]} />
            <Fabric color={c} rough={0.78} />
          </mesh>
          {/* front pocket (faces away from the chick) */}
          <mesh position={[0, -0.12, -0.24]} scale={[0.82, 0.58, 0.5]} castShadow>
            <sphereGeometry args={[0.34, 20, 14]} />
            <Fabric color={c2} rough={0.7} />
          </mesh>
          {/* buckle */}
          <mesh position={[0, -0.12, -0.42]}>
            <boxGeometry args={[0.12, 0.08, 0.05]} />
            <Fabric color="#3A3A44" rough={0.5} />
          </mesh>
          {/* top handle */}
          <mesh position={[0, 0.5, -0.02]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.11, 0.028, 8, 16, Math.PI]} />
            <Fabric color={c2} rough={0.8} />
          </mesh>
          {/* shoulder straps — arc forward OVER the body surface */}
          {[-1, 1].map((sd) => (
            <group key={sd} position={[sd * 0.3, 0.26, 0.18]} rotation={[0, sd * -0.34, 0]}>
              <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
                <torusGeometry args={[0.52, 0.055, 8, 24, Math.PI * 0.78]} />
                <Fabric color={c} rough={0.8} />
              </mesh>
            </group>
          ))}
        </group>
      )}

      {item.id === "wings_demon" && <DemonWings c={c} c2={c2} />}

      {item.id === "wings" && (
        /* anchored behind the shoulders; each wing is a fan of feathers that
           sweeps up and outward so it is always fully visible */
        <group ref={wingsRef} position={[0, 0.46, -0.92]}>
          {[-1, 1].map((sd) => (
            <group key={sd} rotation={[0.22, sd * 0.3, sd * -0.26]}>
              {[0, 1, 2, 3, 4].map((r) => {
                const spread = r / 4;
                return (
                  <mesh
                    key={r}
                    position={[
                      sd * (0.22 + spread * 0.82),
                      0.5 - spread * 0.92,
                      -spread * 0.16,
                    ]}
                    rotation={[0, 0, sd * (-0.5 - spread * 0.5)]}
                    scale={[0.2, 0.62 - spread * 0.17, 0.08]}
                    castShadow
                  >
                    <sphereGeometry args={[1, 16, 12]} />
                    <meshPhysicalMaterial
                      color={r % 2 === 0 ? c : c2}
                      roughness={0.55}
                      sheen={1}
                      sheenColor="#ffffff"
                      transparent
                      opacity={0.96}
                    />
                  </mesh>
                );
              })}
            </group>
          ))}
        </group>
      )}
    </>
  );
}


/* ================================================================== */
/*  RARE PIECES — wheel-only                                           */
/* ================================================================== */

/**
 * Horns rooted on the scalp.
 *
 * The head is an ellipsoid of radii (0.64, 0.6208, 0.6336) and the Hat group
 * sits at y = 0.5 in head space, so a horn planted at x = ±0.30 must start at
 * y ≈ 0.048 locally — the previous +0.24 left them hovering in mid-air.
 */
function Horns({ molten, c, c2 }: { molten: boolean; c: string; c2: string }) {
  const glow = useRef<THREE.MeshStandardMaterial[]>([]);
  const tex = useMemo(() => (molten ? demonTexture() : null), [molten]);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    glow.current.forEach((m, i) => {
      if (m) m.emissiveIntensity = 1.3 + Math.sin(t * 2.6 + i * 0.8) * 0.8;
    });
  });

  const SEGS = 9;
  const HEAD: [number, number, number] = [0.64, 0.6208, 0.6336];

  return (
    <group>
      {[-1, 1].map((sd) => {
        // plant the root exactly on the scalp surface
        const rootX = sd * 0.3;
        const rootZ = -0.04;
        const k = Math.sqrt(
          Math.max(0, 1 - (rootX / HEAD[0]) ** 2 - (rootZ / HEAD[2]) ** 2),
        );
        const rootY = HEAD[1] * k - 0.5; // convert to Hat-group space

        return (
          <group key={sd} position={[rootX, rootY, rootZ]} rotation={[-0.22, 0, sd * 0.3]}>
            {/* fleshy base where the horn meets the fuzz */}
            <mesh scale={[1, 0.5, 1]}>
              <sphereGeometry args={[0.115, 16, 12]} />
              <meshStandardMaterial
                color={molten ? "#3A0A0A" : shade(c, -0.3)}
                roughness={0.85}
              />
            </mesh>

            {Array.from({ length: SEGS }).map((_, i) => {
              const p = i / (SEGS - 1);
              // taper + curl outward and back
              const r = 0.108 * (1 - p * 0.88);
              const y = p * 0.5;
              const x = sd * p * p * 0.24;
              const z = -p * p * 0.22;
              return (
                <group key={i} position={[x, y, z]} rotation={[-p * 0.6, 0, sd * p * 0.6]}>
                  <mesh castShadow>
                    <coneGeometry args={[r, 0.12, 16]} />
                    {molten ? (
                      <meshStandardMaterial
                        ref={(m) => {
                          if (m) glow.current[i + (sd > 0 ? SEGS : 0)] = m;
                        }}
                        map={tex}
                        color="#5E0C0C"
                        emissive="#FF3B1F"
                        emissiveIntensity={1.4}
                        roughness={0.62}
                        metalness={0.25}
                      />
                    ) : (
                      <meshPhysicalMaterial
                        color={shade(c, -p * 0.25)}
                        roughness={0.28}
                        clearcoat={0.9}
                        clearcoatRoughness={0.16}
                        sheen={0.8}
                        sheenColor={c2}
                      />
                    )}
                  </mesh>
                  {/* growth ridge around each segment */}
                  {i < SEGS - 2 && (
                    <mesh position={[0, -0.05, 0]} rotation={[Math.PI / 2, 0, 0]}>
                      <torusGeometry args={[r * 1.02, r * 0.16, 6, 14]} />
                      <meshStandardMaterial
                        color={molten ? "#240404" : shade(c, -0.38)}
                        roughness={0.7}
                        emissive={molten ? "#FF5A1F" : "#000000"}
                        emissiveIntensity={molten ? 0.8 : 0}
                      />
                    </mesh>
                  )}
                </group>
              );
            })}

            {/* sharp tip */}
            <mesh position={[sd * 0.24, 0.56, -0.22]} rotation={[-0.6, 0, sd * 0.6]}>
              <coneGeometry args={[0.026, 0.1, 12]} />
              <meshStandardMaterial
                color={molten ? "#FFB03A" : shade(c, 0.3)}
                emissive={molten ? "#FF7A1F" : "#000000"}
                emissiveIntensity={molten ? 1.6 : 0}
                roughness={0.3}
              />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

/** Floating, slowly bobbing ring of light. */
function Halo({ c, c2 }: { c: string; c2: string }) {
  const g = useRef<THREE.Group>(null);
  const mat = useRef<THREE.MeshStandardMaterial>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (g.current) {
      g.current.position.y = 0.62 + Math.sin(t * 1.5) * 0.05;
      g.current.rotation.y = t * 0.7;
      g.current.rotation.z = Math.sin(t * 0.9) * 0.08;
    }
    if (mat.current) mat.current.emissiveIntensity = 2.2 + Math.sin(t * 2.6) * 0.7;
  });

  return (
    <group ref={g} position={[0, 0.62, 0]}>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.4, 0.05, 14, 40]} />
        <meshStandardMaterial
          ref={mat}
          color={c}
          emissive={c2}
          emissiveIntensity={2.4}
          roughness={0.25}
          metalness={0.6}
        />
      </mesh>
      {/* soft bloom disc */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.3, 0.56, 32]} />
        <meshBasicMaterial color={c2} transparent opacity={0.16} depthWrite={false} side={THREE.DoubleSide} />
      </mesh>
      <pointLight color={c2} intensity={4} distance={2.4} />
    </group>
  );
}

/** Wrap-around visor: curved shell, inset lens, vents and a scan sweep. */
function CyberVisor({ c, c2 }: { c: string; c2: string }) {
  const scan = useRef<THREE.Mesh>(null);
  const lens = useRef<THREE.MeshStandardMaterial>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (scan.current) {
      scan.current.position.x = Math.sin(t * 1.6) * 0.22;
      const m = scan.current.material as THREE.MeshBasicMaterial;
      m.opacity = 0.55 + Math.sin(t * 6) * 0.3;
    }
    if (lens.current) lens.current.emissiveIntensity = 1.5 + Math.sin(t * 2.4) * 0.4;
  });

  return (
    <group position={[0, 0.02, 0.06]}>
      {/* curved housing that wraps the brow */}
      <mesh position={[0, 0.05, -0.02]} scale={[0.62, 0.19, 0.3]} castShadow>
        <sphereGeometry args={[1, 32, 18]} />
        <meshPhysicalMaterial
          color={c}
          roughness={0.24}
          metalness={0.85}
          clearcoat={1}
          clearcoatRoughness={0.08}
        />
      </mesh>

      {/* inset lens band, sitting just proud of the housing */}
      <mesh position={[0, -0.02, 0.12]} scale={[0.55, 0.115, 0.2]}>
        <sphereGeometry args={[1, 32, 16]} />
        <meshPhysicalMaterial
          ref={lens as never}
          color="#04140F"
          emissive={c2}
          emissiveIntensity={1.6}
          roughness={0.08}
          metalness={0.2}
          clearcoat={1}
          transmission={0.25}
          thickness={0.2}
        />
      </mesh>

      {/* HUD tick marks inside the lens */}
      {[-0.3, -0.15, 0, 0.15, 0.3].map((x, i) => (
        <mesh key={x} position={[x * 0.55, -0.02, 0.3]}>
          <boxGeometry args={[0.012, i === 2 ? 0.05 : 0.03, 0.005]} />
          <meshBasicMaterial color={c2} toneMapped={false} transparent opacity={0.8} />
        </mesh>
      ))}

      {/* sweeping scan bar */}
      <mesh ref={scan} position={[0, -0.02, 0.31]}>
        <boxGeometry args={[0.05, 0.075, 0.005]} />
        <meshBasicMaterial color="#ffffff" toneMapped={false} transparent opacity={0.8} />
      </mesh>

      {/* cooling vents on the brow */}
      {[-1, 1].map((sd) =>
        [0, 1, 2].map((i) => (
          <mesh key={`${sd}${i}`} position={[sd * (0.34 + i * 0.05), 0.14, 0.06]}>
            <boxGeometry args={[0.022, 0.05, 0.03]} />
            <meshStandardMaterial color={shade(c, -0.4)} roughness={0.5} metalness={0.7} />
          </mesh>
        )),
      )}

      {/* temples hugging the head */}
      {[-1, 1].map((sd) => (
        <group key={sd}>
          <mesh position={[sd * 0.52, 0.04, -0.18]} rotation={[0, sd * 0.95, 0]} castShadow>
            <boxGeometry args={[0.028, 0.07, 0.36]} />
            <meshStandardMaterial color={shade(c, 0.15)} roughness={0.28} metalness={0.9} />
          </mesh>
          {/* status LED */}
          <mesh position={[sd * 0.5, 0.1, -0.04]}>
            <sphereGeometry args={[0.02, 8, 6]} />
            <meshBasicMaterial color={c2} toneMapped={false} />
          </mesh>
        </group>
      ))}

      <pointLight position={[0, 0, 0.4]} intensity={1.6} distance={1.6} color={c2} />
    </group>
  );
}

/** Iridescent shield glasses with a real frame, bridge and nose pads. */
function HoloShades({ c, c2 }: { c: string; c2: string }) {
  const lens = useRef<THREE.MeshPhysicalMaterial>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (lens.current) {
      // the iridescent film shifts as the light moves
      lens.current.iridescenceIOR = 1.6 + Math.sin(t * 0.8) * 0.55;
      lens.current.iridescenceThicknessRange = [100, 400 + Math.sin(t * 1.1) * 200];
    }
  });

  const Lens = ({ sd }: { sd: number }) => (
    <group position={[sd * 0.23, 0, 0.02]} rotation={[0, sd * -0.2, 0]}>
      {/* frame */}
      <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
        <torusGeometry args={[0.16, 0.022, 12, 28]} />
        <meshStandardMaterial color={c} roughness={0.22} metalness={0.92} />
      </mesh>
      {/* glass */}
      <mesh scale={[1, 1, 0.35]}>
        <sphereGeometry args={[0.158, 26, 18]} />
        <meshPhysicalMaterial
          ref={sd < 0 ? lens : undefined}
          color="#101018"
          roughness={0.05}
          metalness={0.35}
          clearcoat={1}
          clearcoatRoughness={0.02}
          iridescence={1}
          iridescenceIOR={1.9}
          iridescenceThicknessRange={[100, 500]}
          transmission={0.45}
          thickness={0.25}
          transparent
          opacity={0.9}
        />
      </mesh>
      {/* crisp specular glint */}
      <mesh position={[sd * -0.05, 0.06, 0.075]} rotation={[0, 0, sd * 0.5]} scale={[1, 0.42, 1]}>
        <circleGeometry args={[0.038, 14]} />
        <meshBasicMaterial color="#ffffff" transparent opacity={0.75} toneMapped={false} />
      </mesh>
    </group>
  );

  return (
    <group position={[0, 0.02, 0.42]}>
      <Lens sd={-1} />
      <Lens sd={1} />

      {/* bridge */}
      <mesh position={[0, 0.03, 0.02]} rotation={[0, 0, Math.PI / 2]}>
        <capsuleGeometry args={[0.016, 0.1, 4, 8]} />
        <meshStandardMaterial color={c} roughness={0.2} metalness={0.95} />
      </mesh>
      {/* brow bar */}
      <mesh position={[0, 0.13, 0]} rotation={[0, 0, Math.PI / 2]}>
        <capsuleGeometry args={[0.02, 0.46, 4, 10]} />
        <meshStandardMaterial color={c2} roughness={0.25} metalness={0.9} />
      </mesh>
      {/* nose pads */}
      {[-1, 1].map((sd) => (
        <mesh key={sd} position={[sd * 0.055, -0.05, 0.05]}>
          <sphereGeometry args={[0.022, 8, 6]} />
          <meshStandardMaterial color="#E8E8F0" roughness={0.3} transparent opacity={0.8} />
        </mesh>
      ))}
      {/* temples */}
      {[-1, 1].map((sd) => (
        <mesh key={sd} position={[sd * 0.42, 0.05, -0.16]} rotation={[0, sd * 1.05, 0]} castShadow>
          <boxGeometry args={[0.022, 0.045, 0.34]} />
          <meshStandardMaterial color={c} roughness={0.24} metalness={0.92} />
        </mesh>
      ))}
    </group>
  );
}

/**
 * Demon wings — large, menacing, and cheap to render.
 *
 * Performance notes (the previous version stuttered badly):
 *  - the membrane component was declared *inside* the parent, so React saw a
 *    brand-new component type each render and remounted all eight panels,
 *    rebuilding their geometry and shaders every time;
 *  - each panel used `transmission`, which forces an extra scene render pass.
 * Both are gone: geometry is shared and memoised, materials are opaque, and
 * the whole wing animates by mutating transforms only.
 */

/** one membrane panel — hoisted so React keeps its identity */
function Membrane({
  sd,
  i,
  a,
  b,
  color,
  glow,
  map,
}: {
  sd: number;
  i: number;
  a: [number, number];
  b: [number, number];
  color: string;
  glow: string;
  map: THREE.Texture;
}) {
  const mx = (a[0] + b[0]) / 2;
  const my = (a[1] + b[1]) / 2;
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const len = Math.hypot(dx, dy);
  const ang = Math.atan2(dy, dx);

  return (
    <mesh
      position={[sd * mx, my, -0.04 - i * 0.02]}
      rotation={[0, 0, sd > 0 ? ang : Math.PI - ang]}
      scale={[len * 0.52, 0.3 + i * 0.04, 0.03]}
      castShadow
    >
      <sphereGeometry args={[1, 14, 10]} />
      <meshStandardMaterial
        map={map}
        color={color}
        roughness={0.66}
        metalness={0.1}
        emissive={glow}
        emissiveIntensity={0.22}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

/** finger bone + claw, also hoisted */
function Finger({
  sd,
  tip,
  onMat,
}: {
  sd: number;
  tip: [number, number];
  onMat: (m: THREE.MeshStandardMaterial | null) => void;
}) {
  const ex = 0.56;
  const ey = 0.56;
  const dx = tip[0] - ex;
  const dy = tip[1] - ey;
  const len = Math.hypot(dx, dy);
  const ang = Math.atan2(dy, dx);
  const rot = sd > 0 ? ang - Math.PI / 2 : Math.PI / 2 - ang;

  return (
    <group>
      <mesh position={[sd * (ex + dx / 2), ey + dy / 2, -0.02]} rotation={[0, 0, rot]} castShadow>
        <capsuleGeometry args={[0.028, len - 0.06, 3, 6]} />
        <meshStandardMaterial ref={onMat} color="#2A0505" emissive="#FF3B1F" emissiveIntensity={1.6} roughness={0.5} />
      </mesh>
      <mesh position={[sd * tip[0], tip[1], -0.02]} rotation={[0, 0, rot]} castShadow>
        <coneGeometry args={[0.034, 0.14, 8]} />
        <meshStandardMaterial color="#E8E0D4" roughness={0.35} />
      </mesh>
    </group>
  );
}

/** finger tips, fanning out and down */
const WING_TIPS: [number, number][] = [
  [0.95, 0.92],
  [1.42, 0.42],
  [1.5, -0.2],
  [1.18, -0.74],
];

function DemonWings({ c, c2 }: { c: string; c2: string }) {
  const root = useRef<THREE.Group>(null);
  const veins = useRef<(THREE.MeshStandardMaterial | null)[]>([]);
  const tex = useMemo(() => demonTexture(), []);
  const membraneColor = useMemo(() => shade(c, 0.05), [c]);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (root.current) {
      const beat = Math.sin(t * 1.5);
      root.current.children.forEach((ch, i) => {
        const sd = i === 0 ? -1 : 1;
        ch.rotation.y = sd * (0.42 + beat * 0.34);
        ch.rotation.z = sd * beat * 0.12;
      });
      root.current.position.y = 0.5 + Math.sin(t * 1.5 + 0.4) * 0.05;
    }
    const pulse = 1.6 + Math.sin(t * 3.4) * 0.9;
    for (let i = 0; i < veins.current.length; i++) {
      const m = veins.current[i];
      if (m) m.emissiveIntensity = pulse;
    }
  });

  return (
    <group ref={root} position={[0, 0.5, -0.86]}>
      {[-1, 1].map((sd) => (
        <group key={sd} rotation={[0.16, sd * 0.42, 0]}>
          {/* shoulder */}
          <mesh position={[sd * 0.16, 0.1, 0]} castShadow>
            <sphereGeometry args={[0.12, 12, 9]} />
            <meshStandardMaterial color="#2A0505" roughness={0.6} metalness={0.2} />
          </mesh>

          {/* upper arm */}
          <mesh position={[sd * 0.36, 0.34, 0]} rotation={[0, 0, sd * -0.75]} castShadow>
            <capsuleGeometry args={[0.05, 0.42, 3, 7]} />
            <meshStandardMaterial
              ref={(m) => {
                veins.current[sd > 0 ? 8 : 9] = m;
              }}
              color="#2A0505"
              emissive={c2}
              emissiveIntensity={1.6}
              roughness={0.5}
            />
          </mesh>

          {/* elbow */}
          <mesh position={[sd * 0.56, 0.56, 0]}>
            <sphereGeometry args={[0.07, 10, 8]} />
            <meshStandardMaterial color="#1E0303" roughness={0.55} />
          </mesh>

          {/* membranes first, bones on top */}
          {WING_TIPS.slice(0, -1).map((tip, i) => (
            <Membrane
              key={i}
              sd={sd}
              i={i}
              a={tip}
              b={WING_TIPS[i + 1]}
              color={membraneColor}
              glow={c2}
              map={tex}
            />
          ))}
          <Membrane
            sd={sd}
            i={3}
            a={[0.2, 0.1]}
            b={WING_TIPS[3]}
            color={membraneColor}
            glow={c2}
            map={tex}
          />

          {WING_TIPS.map((tip, i) => (
            <Finger
              key={i}
              sd={sd}
              tip={tip}
              onMat={(m) => {
                veins.current[i + (sd > 0 ? 0 : 4)] = m;
              }}
            />
          ))}
        </group>
      ))}
    </group>
  );
}
