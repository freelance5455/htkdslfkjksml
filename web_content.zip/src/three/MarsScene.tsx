import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { store, useStore, MARS_HP } from "../lib/store";
import { FIGHT_SECONDS, FLIGHT_SECONDS, WEAPONS } from "../lib/world";
import { marsInput, resetMarsInput } from "../lib/marsInput";
import { chirp, thud, zap } from "../lib/sound";
import { Chick } from "./Chick";
import { useLayout } from "../lib/layout";

/* ================================================================== */
/*  STARFIELD — streaks past to sell the speed                         */
/* ================================================================== */
function StarField({
  count = 380,
  /** >0 climbing, <0 descending, 0 = still */
  speed,
}: {
  count?: number;
  speed: number;
}) {
  const pts = useRef<THREE.Points>(null);

  const { positions, sizes } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 34;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 34;
      positions[i * 3 + 2] = -Math.random() * 26 - 1;
      sizes[i] = 0.04 + Math.random() * 0.12;
    }
    return { positions, sizes };
  }, [count]);

  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    g.setAttribute("size", new THREE.BufferAttribute(sizes, 1));
    return g;
  }, [positions, sizes]);

  useEffect(() => () => geo.dispose(), [geo]);

  useFrame((_, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    if (!pts.current || speed === 0) return;
    const attr = pts.current.geometry.attributes.position as THREE.BufferAttribute;
    const arr = attr.array as Float32Array;
    for (let i = 0; i < count; i++) {
      // climbing pushes stars down past the camera, descending pulls them up
      arr[i * 3 + 1] -= speed * dt;
      if (speed > 0 && arr[i * 3 + 1] < -17) {
        arr[i * 3 + 1] = 17;
        arr[i * 3] = (Math.random() - 0.5) * 34;
      } else if (speed < 0 && arr[i * 3 + 1] > 17) {
        arr[i * 3 + 1] = -17;
        arr[i * 3] = (Math.random() - 0.5) * 34;
      }
    }
    attr.needsUpdate = true;
  });

  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial
        color="#ffffff"
        size={0.11}
        sizeAttenuation
        transparent
        opacity={0.92}
        depthWrite={false}
      />
    </points>
  );
}

/** Long vertical streaks — only while the rocket is really moving. */
function SpeedLines({ active, dir }: { active: boolean; dir: number }) {
  const g = useRef<THREE.Group>(null);
  const lines = useMemo(
    () =>
      Array.from({ length: 26 }, () => ({
        x: (Math.random() - 0.5) * 16,
        y: (Math.random() - 0.5) * 22,
        z: -2 - Math.random() * 10,
        len: 1.2 + Math.random() * 2.6,
        sp: 16 + Math.random() * 22,
      })),
    [],
  );

  useFrame((_, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    if (!g.current) return;
    g.current.visible = active;
    if (!active) return;
    g.current.children.forEach((c, i) => {
      const l = lines[i];
      l.y -= l.sp * dir * dt;
      if (dir > 0 && l.y < -13) l.y = 13;
      if (dir < 0 && l.y > 13) l.y = -13;
      c.position.set(l.x, l.y, l.z);
    });
  });

  return (
    <group ref={g} visible={false}>
      {lines.map((l, i) => (
        <mesh key={i} position={[l.x, l.y, l.z]}>
          <boxGeometry args={[0.022, l.len, 0.022]} />
          <meshBasicMaterial color="#CFE8FF" transparent opacity={0.5} depthWrite={false} />
        </mesh>
      ))}
    </group>
  );
}

/* ================================================================== */
/*  ROCKET — carries Jeeko up and down                                 */
/* ================================================================== */
function Rocket({
  mode,
  children,
}: {
  mode: "up" | "down" | "crash";
  children?: React.ReactNode;
}) {
  const root = useRef<THREE.Group>(null);
  const flame = useRef<THREE.Mesh>(null);
  const flame2 = useRef<THREE.Mesh>(null);
  const smoke = useRef<THREE.Group>(null);

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    const t = state.clock.elapsedTime;

    if (root.current) {
      // engine rumble + a slow roll
      const shake = mode === "crash" ? 0.13 : 0.035;
      root.current.position.x = Math.sin(t * 26) * shake;
      root.current.position.y = Math.sin(t * 31) * shake * 0.7;
      root.current.rotation.z =
        mode === "crash"
          ? Math.sin(t * 3.4) * 0.5 + Math.PI
          : mode === "down"
            ? Math.PI + Math.sin(t * 1.2) * 0.05
            : Math.sin(t * 1.1) * 0.05;
      root.current.rotation.y = t * 0.25;
    }

    // flickering exhaust
    const f = 0.72 + Math.abs(Math.sin(t * 34)) * 0.5;
    if (flame.current) {
      flame.current.scale.set(1, f, 1);
      flame.current.position.y = -1.06 - f * 0.24;
    }
    if (flame2.current) {
      const f2 = 0.55 + Math.abs(Math.cos(t * 41)) * 0.45;
      flame2.current.scale.set(1, f2, 1);
      flame2.current.position.y = -1.0 - f2 * 0.16;
    }

    if (smoke.current) {
      smoke.current.children.forEach((c, i) => {
        const ph = (t * 0.85 + i * 0.2) % 1;
        c.position.set(
          Math.sin(i * 2.3) * ph * 0.9,
          -1.3 - ph * 5.2,
          Math.cos(i * 1.7) * ph * 0.9,
        );
        const sc = 0.22 + ph * 0.75;
        c.scale.setScalar(sc);
        const m = (c as THREE.Mesh).material as THREE.MeshBasicMaterial;
        m.opacity = (1 - ph) * 0.4;
      });
      void dt;
    }
  });

  return (
    <group ref={root}>
      {/* nose */}
      <mesh position={[0, 1.16, 0]} castShadow>
        <coneGeometry args={[0.42, 0.86, 24]} />
        <meshStandardMaterial color="#E63946" roughness={0.35} metalness={0.45} />
      </mesh>
      {/* body */}
      <mesh position={[0, 0.2, 0]} castShadow>
        <cylinderGeometry args={[0.42, 0.46, 1.06, 24]} />
        <meshStandardMaterial color="#F1FAEE" roughness={0.3} metalness={0.6} />
      </mesh>
      {/* stripe */}
      <mesh position={[0, 0.5, 0]}>
        <cylinderGeometry args={[0.425, 0.435, 0.16, 24]} />
        <meshStandardMaterial color="#457B9D" roughness={0.35} metalness={0.5} />
      </mesh>
      {/* porthole */}
      <mesh position={[0, 0.18, 0.43]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.15, 0.15, 0.04, 20]} />
        <meshPhysicalMaterial
          color="#8ECAE6"
          roughness={0.05}
          metalness={0.2}
          clearcoat={1}
          emissive="#4CC9F0"
          emissiveIntensity={0.5}
        />
      </mesh>
      {/* engine bell */}
      <mesh position={[0, -0.46, 0]}>
        <cylinderGeometry args={[0.46, 0.34, 0.28, 20]} />
        <meshStandardMaterial color="#495057" roughness={0.4} metalness={0.85} />
      </mesh>
      {/* fins */}
      {[0, 1, 2].map((i) => {
        const a = (i / 3) * Math.PI * 2;
        return (
          <mesh
            key={i}
            position={[Math.cos(a) * 0.42, -0.4, Math.sin(a) * 0.42]}
            rotation={[0, -a, 0.32]}
            castShadow
          >
            <boxGeometry args={[0.06, 0.62, 0.42]} />
            <meshStandardMaterial color="#E63946" roughness={0.4} metalness={0.5} />
          </mesh>
        );
      })}

      {/* exhaust */}
      <mesh ref={flame} position={[0, -1.2, 0]}>
        <coneGeometry args={[0.3, 1.25, 18]} />
        <meshBasicMaterial color="#FFB703" transparent opacity={0.95} depthWrite={false} />
      </mesh>
      <mesh ref={flame2} position={[0, -1.1, 0]}>
        <coneGeometry args={[0.17, 0.85, 16]} />
        <meshBasicMaterial color="#FFF3B0" transparent opacity={0.95} depthWrite={false} />
      </mesh>
      <pointLight position={[0, -1.3, 0]} intensity={22} distance={9} color="#FFB703" />

      {/* smoke trail */}
      <group ref={smoke}>
        {Array.from({ length: 9 }).map((_, i) => (
          <mesh key={i}>
            <sphereGeometry args={[1, 10, 8]} />
            <meshBasicMaterial color="#D9D9D9" transparent opacity={0.3} depthWrite={false} />
          </mesh>
        ))}
      </group>

      {children}
    </group>
  );
}

/* ================================================================== */
/*  FLIGHT — 13s ascent / descent with Earth & Mars in view            */
/* ================================================================== */
function Flight({ mode }: { mode: "up" | "down" | "crash" }) {
  const startedAt = useStore((s) => s.mars?.startedAt ?? 0);
  const earth = useRef<THREE.Group>(null);
  const mars = useRef<THREE.Group>(null);
  const up = mode === "up";

  useFrame(() => {
    const p = Math.min(1, (Date.now() - startedAt) / (FLIGHT_SECONDS * 1000));
    // Earth shrinks away on the climb, swells on the way back
    const eP = up ? p : 1 - p;
    if (earth.current) {
      earth.current.position.set(2.6, -4.6 - eP * 7.5, -9);
      const s = THREE.MathUtils.lerp(2.9, 0.45, eP);
      earth.current.scale.setScalar(s);
    }
    if (mars.current) {
      const mP = up ? p : 1 - p;
      mars.current.position.set(-2.9, 5.4 - mP * 4.4, -11);
      mars.current.scale.setScalar(THREE.MathUtils.lerp(0.4, 2.2, mP));
    }
  });

  return (
    <group>
      <StarField speed={up ? 13 : -13} />
      <SpeedLines active dir={up ? 1 : -1} />

      {/* Earth */}
      <group ref={earth}>
        <mesh>
          <sphereGeometry args={[1, 32, 24]} />
          <meshStandardMaterial color="#2A6FDB" roughness={0.85} />
        </mesh>
        <mesh rotation={[0.4, 0.6, 0]}>
          <sphereGeometry args={[1.012, 24, 18]} />
          <meshStandardMaterial color="#3FA34D" roughness={0.9} transparent opacity={0.62} />
        </mesh>
        <mesh>
          <sphereGeometry args={[1.06, 24, 18]} />
          <meshBasicMaterial color="#9FD4FF" transparent opacity={0.16} depthWrite={false} />
        </mesh>
      </group>

      {/* Mars */}
      <group ref={mars}>
        <mesh>
          <sphereGeometry args={[1, 30, 22]} />
          <meshStandardMaterial color="#C1440E" roughness={0.95} />
        </mesh>
        <mesh position={[0.25, 0.4, 0.8]}>
          <sphereGeometry args={[0.22, 14, 12]} />
          <meshStandardMaterial color="#8C3208" roughness={1} />
        </mesh>
        <mesh position={[0, 0.94, 0.2]}>
          <sphereGeometry args={[0.2, 14, 12]} />
          <meshStandardMaterial color="#F0E6D2" roughness={1} />
        </mesh>
      </group>

      {/* the rocket with Jeeko riding it */}
      <group position={[0, -0.15, 0]} scale={0.92}>
        <Rocket mode={mode}>
          {/* cancel the rocket's flip so Jeeko always rides upright */}
          <group position={[0, 1.62, 0]} rotation={[0, 0, mode === "up" ? 0 : Math.PI]} scale={0.42}>
            <Chick />
          </group>
        </Rocket>
      </group>
    </group>
  );
}

/* ================================================================== */
/*  MARS SURFACE — rusty dust, craters, rocks, two moons               */
/* ================================================================== */
function MarsGround() {
  const craters = useMemo(
    () =>
      Array.from({ length: 9 }, (_, i) => ({
        x: Math.sin(i * 2.7) * (2.4 + (i % 4) * 1.5),
        z: -1.4 + Math.cos(i * 1.9) * (1.6 + (i % 3) * 1.1),
        r: 0.42 + ((i * 37) % 7) * 0.14,
      })),
    [],
  );
  const rocks = useMemo(
    () =>
      Array.from({ length: 16 }, (_, i) => ({
        x: Math.cos(i * 1.37) * (2 + (i % 6) * 1.3),
        z: -2.6 + Math.sin(i * 2.11) * 2.3,
        s: 0.1 + ((i * 53) % 5) * 0.07,
        r: i * 0.7,
      })),
    [],
  );

  return (
    <group>
      {/* dusty plain */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.2, 0]} receiveShadow>
        <circleGeometry args={[26, 56]} />
        <meshStandardMaterial color="#B4541F" roughness={1} />
      </mesh>
      {/* darker patch under the action */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.19, 0]} receiveShadow>
        <circleGeometry args={[7.5, 48]} />
        <meshStandardMaterial color="#A44A19" roughness={1} />
      </mesh>

      {/* craters — a sunken disc with a raised rim */}
      {craters.map((c, i) => (
        <group key={i} position={[c.x, -1.19, c.z]}>
          <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
            <circleGeometry args={[c.r, 26]} />
            <meshStandardMaterial color="#7E3711" roughness={1} />
          </mesh>
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.004, 0]} receiveShadow>
            <ringGeometry args={[c.r * 0.55, c.r * 0.8, 26]} />
            <meshStandardMaterial color="#6B2E0D" roughness={1} />
          </mesh>
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.008, 0]}>
            <ringGeometry args={[c.r, c.r * 1.16, 28]} />
            <meshStandardMaterial color="#C96A32" roughness={1} />
          </mesh>
        </group>
      ))}

      {/* scattered rocks */}
      {rocks.map((r, i) => (
        <mesh
          key={i}
          position={[r.x, -1.2 + r.s * 0.5, r.z]}
          rotation={[r.r, r.r * 1.7, r.r * 0.4]}
          scale={[r.s, r.s * 0.72, r.s]}
          castShadow
          receiveShadow
        >
          <dodecahedronGeometry args={[1, 0]} />
          <meshStandardMaterial color="#8A3F14" roughness={1} />
        </mesh>
      ))}

      {/* distant mesas */}
      {[-13, -7.5, 6.5, 12.5].map((x, i) => (
        <mesh key={x} position={[x, -1.2 + (1.1 + i * 0.32) / 2, -14]} castShadow>
          <cylinderGeometry args={[2.1 + i * 0.3, 3 + i * 0.5, 1.1 + i * 0.32, 7]} />
          <meshStandardMaterial color="#8E3D15" roughness={1} />
        </mesh>
      ))}

      {/* dusty haze on the horizon */}
      <mesh position={[0, 1.6, -18]}>
        <planeGeometry args={[70, 12]} />
        <meshBasicMaterial color="#D98E4F" transparent opacity={0.3} depthWrite={false} />
      </mesh>
    </group>
  );
}

function MarsSky() {
  return (
    <group>
      <StarField count={300} speed={0} />
      {/* Phobos & Deimos */}
      <mesh position={[-6.5, 6.2, -16]}>
        <sphereGeometry args={[0.52, 18, 14]} />
        <meshStandardMaterial color="#C9BFB4" roughness={1} />
      </mesh>
      <mesh position={[7.4, 7.6, -18]}>
        <sphereGeometry args={[0.3, 14, 12]} />
        <meshStandardMaterial color="#9E9086" roughness={1} />
      </mesh>
      {/* Earth as a pale blue dot */}
      <mesh position={[4.2, 4.4, -17]}>
        <sphereGeometry args={[0.14, 14, 12]} />
        <meshBasicMaterial color="#8FD3FF" />
      </mesh>
    </group>
  );
}

/** Jeeko standing on Mars next to his parked rocket. */
function MarsSurface() {
  const flag = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (flag.current) {
      flag.current.rotation.y = Math.sin(state.clock.elapsedTime * 2.1) * 0.24;
    }
  });

  return (
    <group>
      <MarsSky />
      <MarsGround />

      {/* parked rocket */}
      <group position={[2.9, -0.18, -1.6]} scale={0.72} rotation={[0, 0.5, 0.06]}>
        <mesh position={[0, 1.16, 0]}>
          <coneGeometry args={[0.42, 0.86, 22]} />
          <meshStandardMaterial color="#E63946" roughness={0.35} metalness={0.45} />
        </mesh>
        <mesh position={[0, 0.2, 0]}>
          <cylinderGeometry args={[0.42, 0.46, 1.06, 22]} />
          <meshStandardMaterial color="#F1FAEE" roughness={0.3} metalness={0.6} />
        </mesh>
        <mesh position={[0, -0.46, 0]}>
          <cylinderGeometry args={[0.46, 0.34, 0.28, 18]} />
          <meshStandardMaterial color="#495057" roughness={0.4} metalness={0.85} />
        </mesh>
        {[0, 1, 2].map((i) => {
          const a = (i / 3) * Math.PI * 2;
          return (
            <mesh
              key={i}
              position={[Math.cos(a) * 0.42, -0.4, Math.sin(a) * 0.42]}
              rotation={[0, -a, 0.32]}
            >
              <boxGeometry args={[0.06, 0.62, 0.42]} />
              <meshStandardMaterial color="#E63946" roughness={0.4} metalness={0.5} />
            </mesh>
          );
        })}
      </group>

      {/* Jeeko's flag */}
      <group position={[-2.6, -1.2, -0.6]}>
        <mesh position={[0, 0.7, 0]}>
          <cylinderGeometry args={[0.035, 0.035, 1.4, 10]} />
          <meshStandardMaterial color="#D9D9D9" roughness={0.4} metalness={0.7} />
        </mesh>
        <mesh ref={flag} position={[0.32, 1.24, 0]}>
          <planeGeometry args={[0.62, 0.4]} />
          <meshStandardMaterial color="#FFC629" roughness={0.8} side={THREE.DoubleSide} />
        </mesh>
      </group>

      <Chick />
    </group>
  );
}

/* ================================================================== */
/*  ALIEN                                                              */
/* ================================================================== */
type AlienState = {
  id: number;
  x: number;
  z: number;
  hp: number;
  max: number;
  speed: number;
  dead: boolean;
  deadAt: number;
  hitAt: number;
  bob: number;
};

function Alien({ a }: { a: AlienState }) {
  const g = useRef<THREE.Group>(null);
  const legL = useRef<THREE.Mesh>(null);
  const legR = useRef<THREE.Mesh>(null);
  const body = useRef<THREE.Group>(null);
  const pips = useRef<THREE.Group>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (!g.current) return;
    g.current.position.set(a.x, -1.2, a.z);

    if (pips.current) {
      pips.current.visible = !a.dead && a.max > 1;
      pips.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshBasicMaterial;
        m.color.set(i < a.hp ? "#4CE86F" : "#3A3F48");
      });
    }

    if (a.dead) {
      const age = (performance.now() - a.deadAt) / 500;
      g.current.rotation.z = Math.min(Math.PI / 2, age * 2.6);
      g.current.position.y = -1.2 + Math.min(0.16, age * 0.4);
      const s = Math.max(0.001, 1 - age * 0.55);
      g.current.scale.setScalar(s);
      return;
    }

    g.current.rotation.z = 0;
    g.current.scale.setScalar(1);
    const swing = Math.sin(t * 9 + a.bob) * 0.55;
    if (legL.current) legL.current.rotation.x = swing;
    if (legR.current) legR.current.rotation.x = -swing;
    g.current.position.y = -1.2 + Math.abs(Math.sin(t * 9 + a.bob)) * 0.05;

    // flash red briefly when hit
    if (body.current) {
      const since = performance.now() - a.hitAt;
      const flash = since < 140 ? 1 : 0;
      body.current.children.forEach((c) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial | undefined;
        if (m && m.emissive) m.emissiveIntensity = flash * 1.8;
      });
    }
  });

  return (
    <group ref={g}>
      {/* legs — black suit */}
      <mesh ref={legL} position={[0.1, 0.26, 0]} castShadow>
        <capsuleGeometry args={[0.062, 0.28, 3, 6]} />
        <meshStandardMaterial color="#14151A" roughness={0.65} metalness={0.25} />
      </mesh>
      <mesh ref={legR} position={[-0.1, 0.26, 0]} castShadow>
        <capsuleGeometry args={[0.062, 0.28, 3, 6]} />
        <meshStandardMaterial color="#14151A" roughness={0.65} metalness={0.25} />
      </mesh>
      {/* boots */}
      <mesh position={[0.1, 0.06, 0.04]}>
        <boxGeometry args={[0.14, 0.1, 0.2]} />
        <meshStandardMaterial color="#0B0C10" roughness={0.5} metalness={0.4} />
      </mesh>
      <mesh position={[-0.1, 0.06, 0.04]}>
        <boxGeometry args={[0.14, 0.1, 0.2]} />
        <meshStandardMaterial color="#0B0C10" roughness={0.5} metalness={0.4} />
      </mesh>

      <group ref={body}>
        {/* torso in a detailed black suit */}
        <mesh position={[0, 0.66, 0]} castShadow>
          <capsuleGeometry args={[0.19, 0.3, 4, 10]} />
          <meshStandardMaterial
            color="#1A1B22"
            roughness={0.5}
            metalness={0.45}
            emissive="#FF2D2D"
            emissiveIntensity={0}
          />
        </mesh>
        {/* chest plate + glowing core */}
        <mesh position={[0, 0.7, 0.17]}>
          <boxGeometry args={[0.22, 0.2, 0.06]} />
          <meshStandardMaterial color="#26272F" roughness={0.35} metalness={0.7} />
        </mesh>
        <mesh position={[0, 0.7, 0.21]}>
          <circleGeometry args={[0.045, 14]} />
          <meshStandardMaterial
            color="#7CFF9E"
            emissive="#4CE86F"
            emissiveIntensity={2.2}
            roughness={0.2}
          />
        </mesh>
        {/* shoulder pads */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 0.21, 0.82, 0]} castShadow>
            <sphereGeometry args={[0.085, 8, 6]} />
            <meshStandardMaterial color="#2B2D36" roughness={0.4} metalness={0.65} />
          </mesh>
        ))}
        {/* arms */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 0.24, 0.64, 0.02]} rotation={[0, 0, s * 0.28]} castShadow>
            <capsuleGeometry args={[0.052, 0.24, 3, 6]} />
            <meshStandardMaterial color="#14151A" roughness={0.6} metalness={0.3} />
          </mesh>
        ))}
        {/* green hands */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 0.3, 0.46, 0.04]}>
            <sphereGeometry args={[0.055, 8, 6]} />
            <meshStandardMaterial color="#63D471" roughness={0.7} />
          </mesh>
        ))}
        {/* belt */}
        <mesh position={[0, 0.46, 0]}>
          <cylinderGeometry args={[0.2, 0.2, 0.07, 12]} />
          <meshStandardMaterial color="#0E0F14" roughness={0.4} metalness={0.7} />
        </mesh>
      </group>

      {/* big oval green head */}
      <mesh position={[0, 1.08, 0]} scale={[1, 1.34, 0.92]} castShadow>
        <sphereGeometry args={[0.23, 16, 12]} />
        <meshStandardMaterial color="#6FE07C" roughness={0.55} />
      </mesh>
      {/* huge black almond eyes */}
      {[-1, 1].map((s) => (
        <mesh
          key={s}
          position={[s * 0.1, 1.12, 0.19]}
          rotation={[0, 0, s * -0.42]}
          scale={[1, 1.7, 0.55]}
        >
          <sphereGeometry args={[0.062, 10, 8]} />
          <meshPhysicalMaterial
            color="#07080C"
            roughness={0.04}
            clearcoat={1}
            clearcoatRoughness={0.03}
          />
        </mesh>
      ))}
      {/* tiny mouth slit + antenna */}
      <mesh position={[0, 0.965, 0.2]}>
        <boxGeometry args={[0.07, 0.012, 0.01]} />
        <meshBasicMaterial color="#1C3B22" />
      </mesh>
      <mesh position={[0, 1.42, 0]}>
        <cylinderGeometry args={[0.012, 0.012, 0.16, 5]} />
        <meshStandardMaterial color="#2B2D36" metalness={0.8} roughness={0.3} />
      </mesh>
      <mesh position={[0, 1.52, 0]}>
        <sphereGeometry args={[0.035, 8, 6]} />
        <meshStandardMaterial color="#7CFF9E" emissive="#4CE86F" emissiveIntensity={2.4} />
      </mesh>

      {/* health pips */}
      <group ref={pips} position={[0, 1.72, 0]} visible={a.max > 1}>
        {Array.from({ length: a.max }).map((_, i) => (
          <mesh key={i} position={[(i - (a.max - 1) / 2) * 0.1, 0, 0]}>
            <boxGeometry args={[0.075, 0.05, 0.02]} />
            <meshBasicMaterial color="#4CE86F" />
          </mesh>
        ))}
      </group>
    </group>
  );
}

/* ================================================================== */
/*  FIGHT — 13s battle, Jeeko right, aliens stream in from the left    */
/* ================================================================== */
function Fight({ laneMin, laneMax }: { laneMin: number; laneMax: number }) {
  const spawnX = laneMin - 1.6;
  const weaponId = useStore((s) => s.marsWeapon);
  const weapon = WEAPONS.find((w) => w.id === weaponId) ?? WEAPONS[2];

  const chickRef = useRef<THREE.Group>(null);
  const bulletsRef = useRef<THREE.Group>(null);
  const muzzle = useRef<THREE.PointLight>(null);

  // everything the loop mutates lives in refs — zero re-renders while fighting
  const sim = useRef({
    x: laneMax,
    hp: MARS_HP,
    kills: 0,
    lastShot: 0,
    spawnAt: 0,
    nextId: 1,
    ended: false,
    startedAt: performance.now(),
    lastSync: 0,
    hurtAt: 0,
  });
  const aliens = useRef<AlienState[]>([]);
  const bullets = useRef<{ id: number; x: number; z: number; dmg: number }[]>([]);

  // rebuild on mount
  useEffect(() => {
    resetMarsInput();
    sim.current = {
      x: laneMax,
      hp: MARS_HP,
      kills: 0,
      lastShot: 0,
      spawnAt: 0,
      nextId: 1,
      ended: false,
      startedAt: performance.now(),
      lastSync: 0,
      hurtAt: 0,
    };
    aliens.current = [];
    bullets.current = [];
    return () => resetMarsInput();
    // intentionally mount-only: a resize must never restart the battle
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // re-renders only ~5x/sec so newly spawned aliens get mounted
  const [, setRenderTick] = useState(0);

  useFrame((_state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    const now = performance.now();
    const S = sim.current;
    if (S.ended) return;

    const elapsed = (now - S.startedAt) / 1000;

    /* ---- movement ---- */
    const dir = (marsInput.right ? 1 : 0) - (marsInput.left ? 1 : 0);
    S.x = THREE.MathUtils.clamp(S.x + dir * 3.1 * dt, laneMin, laneMax);
    if (chickRef.current) {
      chickRef.current.position.x = S.x;
      chickRef.current.position.y = Math.abs(Math.sin(now / 90)) * (dir ? 0.05 : 0.015);
      // knock-back flash
      const hurt = now - S.hurtAt;
      chickRef.current.rotation.z = hurt < 260 ? Math.sin(hurt / 18) * 0.22 : 0;
    }

    /* ---- shooting ---- */
    const wantsFire = marsInput.firing || marsInput.fire > 0;
    if (wantsFire && now - S.lastShot > weapon.cooldown) {
      S.lastShot = now;
      marsInput.fire = 0;
      if (bullets.current.length < 24) {
        bullets.current.push({ id: S.nextId++, x: S.x - 0.45, z: 0, dmg: weapon.dmg });
      }
      zap();
      if (muzzle.current) muzzle.current.intensity = 16;
    }
    if (muzzle.current) {
      muzzle.current.intensity = THREE.MathUtils.damp(muzzle.current.intensity, 0, 9, dt);
      muzzle.current.position.set(S.x - 0.5, -0.55, 0);
    }

    /* ---- spawning: ramps up over the 13s ---- */
    const pressure = 0.52 - Math.min(0.34, elapsed * 0.028);
    if (now > S.spawnAt && aliens.current.filter((a) => !a.dead).length < 12) {
      S.spawnAt = now + pressure * 1000;
      const tough = Math.random() < Math.min(0.55, elapsed / 15);
      const max = tough ? 3 : Math.random() < 0.5 ? 2 : 1;
      aliens.current.push({
        id: S.nextId++,
        x: spawnX - Math.random() * 2.2,
        z: -0.52 + Math.random() * 1.04,
        hp: max,
        max,
        speed: 1.7 + Math.random() * 1.25,
        dead: false,
        deadAt: 0,
        hitAt: 0,
        bob: Math.random() * 6,
      });
    }

    /* ---- bullets ---- */
    for (let i = bullets.current.length - 1; i >= 0; i--) {
      const b = bullets.current[i];
      b.x -= weapon.speed * dt;
      if (b.x < spawnX - 1.5) {
        bullets.current.splice(i, 1);
        continue;
      }
      // hit test against the nearest living alien
      for (const a of aliens.current) {
        if (a.dead) continue;
        if (Math.abs(a.x - b.x) < 0.42 && Math.abs(a.z - b.z) < 0.75) {
          a.hp -= b.dmg;
          a.hitAt = now;
          bullets.current.splice(i, 1);
          if (a.hp <= 0) {
            a.dead = true;
            a.deadAt = now;
            S.kills++;
            chirp(1);
          }
          break;
        }
      }
    }

    /* ---- aliens advance & attack ---- */
    for (const a of aliens.current) {
      if (a.dead) continue;
      a.x += a.speed * dt;
      // reached Jeeko → punch and vanish
      if (a.x > S.x - 0.55) {
        a.dead = true;
        a.deadAt = now;
        S.hp -= 1;
        S.hurtAt = now;
        thud();
        if (S.hp <= 0) {
          S.hp = 0;
          S.ended = true;
          store.marsEndFight(false, 0, S.kills);
          return;
        }
      }
    }
    // reap corpses
    if (aliens.current.length > 14) {
      aliens.current = aliens.current.filter((a) => !a.dead || now - a.deadAt < 700);
    }

    /* ---- move the rendered bullets ---- */
    if (bulletsRef.current) {
      const kids = bulletsRef.current.children;
      for (let i = 0; i < kids.length; i++) {
        const b = bullets.current[i];
        kids[i].visible = !!b;
        if (b) kids[i].position.set(b.x, -0.55, b.z);
      }
    }

    /* ---- telemetry (throttled) ---- */
    if (now - S.lastSync > 180) {
      S.lastSync = now;
      store.marsSync(S.hp, S.kills);
      setRenderTick(now);
    }

    /* ---- time up → survived ---- */
    if (elapsed >= FIGHT_SECONDS) {
      S.ended = true;
      store.marsEndFight(true, S.hp, S.kills);
    }
  });

  return (
    <group>
      <MarsSky />
      <MarsGround />

      {/* Jeeko, facing the horde */}
      <group ref={chickRef} position={[laneMax, 0, 0]} rotation={[0, -Math.PI / 2, 0]}>
        <Chick />
      </group>

      <pointLight ref={muzzle} intensity={0} distance={5} color={weapon.color} />

      {/* bullet pool */}
      <group ref={bulletsRef}>
        {Array.from({ length: 24 }).map((_, i) => (
          <mesh key={i} visible={false} rotation={[0, 0, Math.PI / 2]}>
            <capsuleGeometry args={[0.055, 0.22, 4, 8]} />
            <meshBasicMaterial color={weapon.color} />
          </mesh>
        ))}
      </group>

      {aliens.current.map((a) => (
        <Alien key={a.id} a={a} />
      ))}
    </group>
  );
}

/* ================================================================== */
/*  ROOT                                                               */
/* ================================================================== */
export function MarsScene() {
  const phase = useStore((s) => s.mars?.phase ?? null);
  const { size, camera } = useThree();
  const hud = useLayout();

  /**
   * Everything is framed from the *measured* free space, so the rocket and the
   * whole alien lane stay on screen from a 360px phone up to a desktop.
   */
  const frame = useMemo(() => {
    const fov = "fov" in camera ? (camera.fov as number) : 40;
    const dist = camera.position.length() || 5.1;
    const worldH = 2 * Math.tan((fov * Math.PI) / 360) * dist;
    const worldW = worldH * (size.width / Math.max(1, size.height));
    const pxPerUnit = size.height / worldH;

    const topUI = hud.top + 8;
    const bottomUI = hud.bottom + 8;
    const freePx = Math.max(120, size.height - topUI - bottomUI);
    const centerPx = (topUI + (size.height - bottomUI)) / 2;
    const centerY = (size.height / 2 - centerPx) / pxPerUnit;

    // --- fight: fit ~4 chick-heights of lane across the screen ---
    const fightScale = THREE.MathUtils.clamp(worldW / 10.8, 0.17, 0.42);
    const halfW = worldW / fightScale / 2;
    const laneMax = halfW - 1.0;
    const laneMin = -halfW + 1.4;

    // --- flight / surface: fit the rocket (≈4.6 units tall) in the gap ---
    const freeUnits = freePx / pxPerUnit;
    const tripScale = THREE.MathUtils.clamp(freeUnits / 5.6, 0.3, 0.95);

    return { fightScale, laneMin, laneMax, tripScale, centerY };
  }, [size.width, size.height, hud.top, hud.bottom, camera]);

  if (!phase) return null;

  if (phase === "fight") {
    return (
      <group position={[0, frame.centerY - 0.1, 0]} scale={frame.fightScale}>
        <Fight laneMin={frame.laneMin} laneMax={frame.laneMax} />
      </group>
    );
  }

  const content =
    phase === "launch" ? (
      <Flight mode="up" />
    ) : phase === "return" ? (
      <Flight mode="down" />
    ) : phase === "crash" ? (
      <Flight mode="crash" />
    ) : (
      <MarsSurface />
    );

  return (
    <group position={[0, frame.centerY - 0.25, 0]} scale={frame.tripScale}>
      {content}
    </group>
  );
}
