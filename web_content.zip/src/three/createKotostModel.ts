import * as THREE from 'three';
import { AccessoryId } from '../types/game';

export interface KotostRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  bodyMesh: THREE.Mesh;
  faceGroup: THREE.Group;
  leftEye: THREE.Group;
  rightEye: THREE.Group;
  leftPupil: THREE.Group;
  rightPupil: THREE.Group;
  leftEyelid: THREE.Mesh;
  rightEyelid: THREE.Mesh;
  leftEar: THREE.Group;
  rightEar: THREE.Group;
  mouthMesh: THREE.Mesh;
  leftPaw: THREE.Group;
  rightPaw: THREE.Group;
  tailGroup: THREE.Group;
  headTopAnchor: THREE.Object3D;
  accessories: Record<AccessoryId, THREE.Object3D | null>;
  setAccessory: (id: AccessoryId) => void;
}

/**
 * Generates a high-resolution procedural Calico fur texture mapped specifically
 * to match the viral spherical "Котость" cat photo:
 * - Fluffy white front bib/chest
 * - Dark charcoal-black face mask + white nose stripe + orange chin
 * - Ginger-orange & black patches on flanks and back
 */
function createCalicoFurTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  // Base rich ginger-orange coat
  ctx.fillStyle = '#E07422';
  ctx.fillRect(0, 0, 1024, 1024);

  // Helper to paint soft feathered fur blobs
  const paintFurPatch = (
    cx: number,
    cy: number,
    rx: number,
    ry: number,
    color: string,
    strands = 220
  ) => {
    const grad = ctx.createRadialGradient(cx, cy, Math.min(rx, ry) * 0.25, cx, cy, Math.max(rx, ry));
    grad.addColorStop(0, color);
    grad.addColorStop(0.72, color);
    grad.addColorStop(1, 'rgba(0,0,0,0)');

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(rx / Math.max(rx, ry), ry / Math.max(rx, ry));
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(0, 0, Math.max(rx, ry), 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Paint furry edge strokes
    ctx.strokeStyle = color;
    ctx.lineCap = 'round';
    for (let i = 0; i < strands; i++) {
      const angle = (i / strands) * Math.PI * 2 + (Math.random() - 0.5) * 0.1;
      const dist = 0.65 + Math.random() * 0.35;
      const x1 = cx + Math.cos(angle) * rx * (dist - 0.15);
      const y1 = cy + Math.sin(angle) * ry * (dist - 0.15);
      const x2 = cx + Math.cos(angle) * rx * (dist + 0.08);
      const y2 = cy + Math.sin(angle) * ry * (dist + 0.08) + 8;
      ctx.lineWidth = 2.5 + Math.random() * 3.5;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }
  };

  // In Three.js SphereGeometry UV mapping:
  // u = 0.5 is depending on rotation; we orient the sphere so u = 0.5, v = 0.5 is dead-center FRONT!
  // Wait: in standard Three.js SphereGeometry, phi starts at 0 (+X) and goes around:
  // u = 0.25 is +Z (Front) if unrotated, OR if we rotate the mesh Y by -Math.PI/2, then u = 0.5 is +Z (Front)!
  // Let's rotate the body mesh by -Math.PI / 2 on Y so that u = 0.5 (x = 512) is dead-center FRONT (+Z)!
  // And v = 0 (y = 0 on canvas if flipY=false, or y = 0 is TOP in canvas 2D). In CanvasTexture, y = 0 is TOP (north pole, head) and y = 1024 is BOTTOM (south pole, paws)!

  // 1. Back & side charcoal-black patches
  paintFurPatch(150, 480, 240, 280, '#181513', 300);
  paintFurPatch(880, 520, 230, 260, '#181513', 300);
  paintFurPatch(512, 180, 320, 170, '#1A1715', 350); // Dark cap over head & ears

  // 2. Viewer-left (Cat's right shoulder): bold charcoal-black patch above ginger flank
  paintFurPatch(340, 420, 155, 165, '#181513', 260);
  // Viewer-left lower rich ginger patch
  paintFurPatch(310, 660, 170, 200, '#D96B1B', 260);

  // 3. Viewer-right (Cat's left flank): bright ginger-orange upper shoulder + black mid-stripe + ginger hip
  paintFurPatch(690, 410, 165, 150, '#E8832E', 260);
  paintFurPatch(700, 570, 145, 105, '#171412', 240);
  paintFurPatch(685, 740, 165, 150, '#D96B1B', 240);

  // 4. Center Front Lush Fluffy White Bib / Chest & Belly (x = 512, y = 460..960)
  paintFurPatch(512, 620, 175, 290, '#FFFDF9', 450);
  paintFurPatch(495, 780, 195, 210, '#FFFBF5', 380);
  paintFurPatch(512, 470, 140, 130, '#FFFDF9', 320);

  // 5. Subtle warm cream-white fur texture layering on chest
  paintFurPatch(512, 560, 120, 160, '#F5EFE6', 180);
  paintFurPatch(512, 540, 105, 135, '#FFFFFF', 220);

  // 6. Head & Forehead markings (around y = 140..330, x = 512)
  // Dark mask around eyes
  paintFurPatch(435, 250, 95, 85, '#141210', 180);
  paintFurPatch(590, 250, 95, 85, '#141210', 180);
  // Touch of ginger on top center forehead
  paintFurPatch(500, 145, 58, 48, '#D97724', 110);
  // Crisp white vertical blaze between the eyes leading to muzzle
  paintFurPatch(512, 265, 26, 75, '#FFFDF9', 120);
  // White muzzle base
  paintFurPatch(512, 330, 82, 55, '#FFFDF9', 180);
  // Warm golden-ginger chin right below mouth!
  paintFurPatch(512, 395, 65, 42, '#E5852E', 140);

  // 7. Global fine fur hair strokes across the entire coat for tactile softness
  ctx.lineCap = 'round';
  for (let i = 0; i < 6500; i++) {
    const x = Math.random() * 1024;
    const y = Math.random() * 1024;
    // Sample pixel color or add subtle highlight/shadow hair
    const isLight = i % 2 === 0;
    ctx.strokeStyle = isLight ? 'rgba(255, 252, 245, 0.13)' : 'rgba(20, 15, 10, 0.11)';
    ctx.lineWidth = 1.5 + Math.random() * 2;
    const len = 8 + Math.random() * 12;
    const angle = Math.PI / 2 + (Math.random() - 0.5) * 0.45;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(angle) * len, y + Math.sin(angle) * len);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

export function createKotostModel(): KotostRig {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const furTexture = createCalicoFurTexture();

  // Custom deformed sphere geometry so the bottom sits snugly and the lower belly is extra chubby
  const sphereGeo = new THREE.SphereGeometry(1.35, 64, 64);
  const posAttr = sphereGeo.attributes.position;
  const vertex = new THREE.Vector3();

  for (let i = 0; i < posAttr.count; i++) {
    vertex.fromBufferAttribute(posAttr, i);
    // Normalize height (-1.35 to +1.35)
    const ny = vertex.y / 1.35;

    // Make the lower belly wider and pear-shaped like the photo
    const bellyFactor = ny < 0.2 ? 1.0 + Math.cos((ny + 0.25) * 1.6) * 0.14 : 1.0 - (ny - 0.2) * 0.06;
    vertex.x *= bellyFactor * 1.12;
    vertex.z *= bellyFactor * 1.1;

    // Flatten the bottom slightly so it rests like a plush loaf-sphere on the floor
    if (vertex.y < -1.02) {
      vertex.y = -1.02 + (vertex.y + 1.02) * 0.22;
    }

    // Slightly flatten the very top of the head between the ears (just like the photo!)
    if (vertex.y > 1.18) {
      vertex.y = 1.18 + (vertex.y - 1.18) * 0.45;
    }

    posAttr.setXYZ(i, vertex.x, vertex.y, vertex.z);
  }
  sphereGeo.computeVertexNormals();

  const bodyMat = new THREE.MeshStandardMaterial({
    map: furTexture,
    roughness: 0.78,
    metalness: 0.02,
  });

  const bodyMesh = new THREE.Mesh(sphereGeo, bodyMat);
  // Rotate -90 deg on Y so UV u=0.5 faces +Z (camera front)
  bodyMesh.rotation.y = -Math.PI / 2;
  bodyMesh.position.y = 1.08;
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = true;
  bodyGroup.add(bodyMesh);

  // Face Group anchored on the upper front of the sphere
  const faceGroup = new THREE.Group();
  faceGroup.position.set(0, 1.72, 1.14);
  // Tilt slightly upward like the shocked upward gaze in the reference photo!
  faceGroup.rotation.x = -0.24;
  bodyGroup.add(faceGroup);

  // Helper to create one giant saucer eye
  const createSaucerEye = (side: -1 | 1) => {
    const eyeGroup = new THREE.Group();
    eyeGroup.position.set(side * 0.34, 0.14, 0.06);
    eyeGroup.rotation.y = side * 0.18;
    eyeGroup.rotation.x = -0.08;

    // Dark velvety eye socket rim
    const rimGeo = new THREE.SphereGeometry(0.245, 32, 32);
    rimGeo.scale(1.0, 1.0, 0.42);
    const rimMat = new THREE.MeshStandardMaterial({ color: '#0F0D0C', roughness: 0.6 });
    const rimMesh = new THREE.Mesh(rimGeo, rimMat);
    eyeGroup.add(rimMesh);

    // Bright lime-green-yellow iris ring (#C7E365)
    const irisGeo = new THREE.SphereGeometry(0.225, 32, 32);
    irisGeo.scale(1.0, 1.0, 0.45);
    const irisMat = new THREE.MeshStandardMaterial({
      color: '#C7E365',
      emissive: '#4D6B14',
      emissiveIntensity: 0.22,
      roughness: 0.2,
    });
    const irisMesh = new THREE.Mesh(irisGeo, irisMat);
    irisMesh.position.z = 0.018;
    eyeGroup.add(irisMesh);

    // Enormous dilated obsidian pupil group (allows eye tracking & dilation!)
    const pupilGroup = new THREE.Group();
    pupilGroup.position.z = 0.042;
    eyeGroup.add(pupilGroup);

    const pupilGeo = new THREE.SphereGeometry(0.188, 32, 32);
    pupilGeo.scale(1.0, 1.0, 0.38);
    const pupilMat = new THREE.MeshStandardMaterial({
      color: '#050507',
      roughness: 0.08,
      metalness: 0.1,
    });
    const pupilMesh = new THREE.Mesh(pupilGeo, pupilMat);
    pupilGroup.add(pupilMesh);

    // Primary crisp studio window highlight (top-left of eye)
    const glint1Geo = new THREE.SphereGeometry(0.052, 16, 16);
    glint1Geo.scale(1.0, 1.2, 0.3);
    const glintMat = new THREE.MeshBasicMaterial({ color: '#FFFFFF' });
    const glint1 = new THREE.Mesh(glint1Geo, glintMat);
    glint1.position.set(-0.065, 0.068, 0.072);
    pupilGroup.add(glint1);

    // Secondary smaller catchlight (bottom-right)
    const glint2Geo = new THREE.SphereGeometry(0.025, 12, 12);
    const glint2 = new THREE.Mesh(glint2Geo, glintMat);
    glint2.position.set(0.068, -0.055, 0.072);
    pupilGroup.add(glint2);

    // Blinking eyelid mesh (hidden via scaleY when open)
    const lidGeo = new THREE.SphereGeometry(0.252, 24, 24);
    lidGeo.scale(1.02, 1.02, 0.48);
    const lidMat = new THREE.MeshStandardMaterial({ color: '#181512', roughness: 0.8 });
    const lidMesh = new THREE.Mesh(lidGeo, lidMat);
    lidMesh.position.z = 0.02;
    lidMesh.scale.set(1, 0.001, 1);
    eyeGroup.add(lidMesh);

    return { eyeGroup, pupilGroup, lidMesh };
  };

  const leftEyeObj = createSaucerEye(-1);
  const rightEyeObj = createSaucerEye(1);
  faceGroup.add(leftEyeObj.eyeGroup);
  faceGroup.add(rightEyeObj.eyeGroup);

  // White Forehead Blaze Stripe & Puffy White Whisker Pads (Muzzle)
  const whiteFurMat = new THREE.MeshStandardMaterial({ color: '#FFFDF9', roughness: 0.82 });

  // Bridge stripe between eyes
  const blazeGeo = new THREE.CapsuleGeometry(0.048, 0.22, 8, 16);
  const blazeMesh = new THREE.Mesh(blazeGeo, whiteFurMat);
  blazeMesh.position.set(0, 0.14, 0.1);
  blazeMesh.scale.set(1.0, 1.0, 0.55);
  faceGroup.add(blazeMesh);

  // Left & Right Puffy Muzzle Cheeks
  const cheekGeo = new THREE.SphereGeometry(0.165, 24, 24);
  const leftCheek = new THREE.Mesh(cheekGeo, whiteFurMat);
  leftCheek.position.set(-0.11, -0.09, 0.13);
  leftCheek.scale.set(1.25, 0.92, 0.85);
  faceGroup.add(leftCheek);

  const rightCheek = new THREE.Mesh(cheekGeo, whiteFurMat);
  rightCheek.position.set(0.11, -0.09, 0.13);
  rightCheek.scale.set(1.25, 0.92, 0.85);
  faceGroup.add(rightCheek);

  // Warm Ginger-Orange Chin Tuft right underneath the white muzzle (signature feature in photo!)
  const chinMat = new THREE.MeshStandardMaterial({ color: '#E5852E', roughness: 0.85 });
  const chinGeo = new THREE.SphereGeometry(0.14, 20, 20);
  const chinMesh = new THREE.Mesh(chinGeo, chinMat);
  chinMesh.position.set(0, -0.22, 0.09);
  chinMesh.scale.set(1.35, 0.78, 0.75);
  faceGroup.add(chinMesh);

  // Cute Pink-and-Black Spotted Nose (exact match to photo!)
  const noseGroup = new THREE.Group();
  noseGroup.position.set(0, -0.01, 0.25);
  faceGroup.add(noseGroup);

  const pinkNoseMat = new THREE.MeshStandardMaterial({ color: '#F472B6', roughness: 0.4 });
  const darkNoseMat = new THREE.MeshStandardMaterial({ color: '#18130F', roughness: 0.45 });

  const noseMainGeo = new THREE.SphereGeometry(0.068, 20, 20);
  const noseMain = new THREE.Mesh(noseMainGeo, pinkNoseMat);
  noseMain.scale.set(1.3, 0.88, 0.75);
  noseGroup.add(noseMain);

  // Dark spot on right nostril & tip (matching the reference photo's speckled nose)
  const spotGeo = new THREE.SphereGeometry(0.042, 16, 16);
  const noseSpotRight = new THREE.Mesh(spotGeo, darkNoseMat);
  noseSpotRight.position.set(0.035, -0.008, 0.025);
  noseGroup.add(noseSpotRight);

  const noseSpotLeft = new THREE.Mesh(spotGeo, darkNoseMat);
  noseSpotLeft.scale.set(0.7, 0.7, 0.7);
  noseSpotLeft.position.set(-0.038, -0.012, 0.02);
  noseGroup.add(noseSpotLeft);

  // Expressive little mouth (opens when chomping treats!)
  const mouthGeo = new THREE.SphereGeometry(0.065, 16, 16);
  const mouthMat = new THREE.MeshBasicMaterial({ color: '#4C1D24' });
  const mouthMesh = new THREE.Mesh(mouthGeo, mouthMat);
  mouthMesh.position.set(0, -0.145, 0.21);
  mouthMesh.scale.set(1.2, 0.22, 0.4);
  faceGroup.add(mouthMesh);

  // Delicate White Whiskers fanning out from the muzzle cheeks
  const whiskerMat = new THREE.MeshBasicMaterial({ color: '#FFFBF5', transparent: true, opacity: 0.85 });
  const createWhiskers = (side: -1 | 1) => {
    for (let i = 0; i < 5; i++) {
      const len = 0.48 + (i % 2) * 0.08;
      const wGeo = new THREE.CylinderGeometry(0.003, 0.008, len, 6);
      const wMesh = new THREE.Mesh(wGeo, whiskerMat);
      wMesh.position.set(side * (0.28 + len * 0.38), -0.08 - i * 0.026, 0.14 - i * 0.01);
      wMesh.rotation.z = side * (Math.PI / 2 + 0.12 + i * 0.07);
      wMesh.rotation.y = -side * (0.22 + i * 0.04);
      faceGroup.add(wMesh);
    }
  };
  createWhiskers(-1);
  createWhiskers(1);

  // Tiny Folded Calico Ears tucked low into the spherical silhouette
  const createFoldedEar = (side: -1 | 1) => {
    const earGroup = new THREE.Group();
    earGroup.position.set(side * 0.56, 2.15, 0.52);
    earGroup.rotation.z = -side * 0.58;
    earGroup.rotation.x = 0.22;
    earGroup.rotation.y = side * 0.35;

    const earGeo = new THREE.ConeGeometry(0.22, 0.32, 24);
    earGeo.scale(1.1, 0.85, 0.55);
    const earMat = new THREE.MeshStandardMaterial({
      color: side === -1 ? '#1B1815' : '#3A2E25',
      roughness: 0.85,
    });
    const earMesh = new THREE.Mesh(earGeo, earMat);
    earMesh.castShadow = true;
    earGroup.add(earMesh);

    return earGroup;
  };

  const leftEar = createFoldedEar(-1);
  const rightEar = createFoldedEar(1);
  bodyGroup.add(leftEar);
  bodyGroup.add(rightEar);

  // Stubby White Marshmallow Paws peeking out at the bottom front
  const createPaw = (side: -1 | 1) => {
    const pawGroup = new THREE.Group();
    pawGroup.position.set(side * 0.48, 0.12, 1.05);
    pawGroup.rotation.y = side * 0.15;

    const pawGeo = new THREE.SphereGeometry(0.24, 24, 24);
    pawGeo.scale(1.18, 0.52, 1.25);
    const pawMesh = new THREE.Mesh(pawGeo, whiteFurMat);
    pawMesh.castShadow = true;
    pawMesh.receiveShadow = true;
    pawGroup.add(pawMesh);

    // 3 little toe divisions
    const toeGeo = new THREE.SphereGeometry(0.085, 14, 14);
    toeGeo.scale(0.9, 0.7, 1.2);
    for (let t = -1; t <= 1; t++) {
      const toe = new THREE.Mesh(toeGeo, whiteFurMat);
      toe.position.set(t * 0.085, -0.01, 0.2);
      pawGroup.add(toe);
    }

    return pawGroup;
  };

  const leftPaw = createPaw(-1);
  const rightPaw = createPaw(1);
  root.add(leftPaw);
  root.add(rightPaw);

  // Fluffy Calico Tail in the back
  const tailGroup = new THREE.Group();
  tailGroup.position.set(0, 0.32, -1.25);
  bodyGroup.add(tailGroup);

  const tailGeo = new THREE.CapsuleGeometry(0.16, 0.55, 12, 20);
  const tailMat = new THREE.MeshStandardMaterial({ color: '#1A1715', roughness: 0.85 });
  const tailMesh = new THREE.Mesh(tailGeo, tailMat);
  tailMesh.rotation.x = -0.85;
  tailMesh.position.set(0, 0.15, -0.2);
  tailMesh.castShadow = true;
  tailGroup.add(tailMesh);

  // Anchor right on top of the flat head for Head-Stacking Discipline & Crown!
  const headTopAnchor = new THREE.Object3D();
  headTopAnchor.position.set(0, 2.34, 0.22);
  bodyGroup.add(headTopAnchor);

  // ==========================================
  // EQUIPABLE 3D GUINNESS ACCESSORIES
  // ==========================================
  const accessories: Record<AccessoryId, THREE.Object3D | null> = {
    none: null,
    crown: null,
    headband: null,
    shades: null,
    bowtie: null,
  };

  // 1. Golden Guinness Crown
  const crownGroup = new THREE.Group();
  crownGroup.position.set(0, 2.32, 0.34);
  crownGroup.rotation.x = -0.12;
  const goldMat = new THREE.MeshStandardMaterial({
    color: '#FACC15',
    metalness: 0.75,
    roughness: 0.22,
    emissive: '#B45309',
    emissiveIntensity: 0.15,
  });
  const crownBase = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.3, 0.18, 24), goldMat);
  crownGroup.add(crownBase);

  const velvetGeo = new THREE.SphereGeometry(0.28, 20, 16);
  velvetGeo.scale(1, 0.65, 1);
  const velvetMat = new THREE.MeshStandardMaterial({ color: '#E11D48', roughness: 0.6 });
  const velvetCap = new THREE.Mesh(velvetGeo, velvetMat);
  velvetCap.position.y = 0.05;
  crownGroup.add(velvetCap);

  // Crown spikes + gems
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    const spike = new THREE.Mesh(new THREE.ConeGeometry(0.065, 0.18, 12), goldMat);
    spike.position.set(Math.cos(angle) * 0.3, 0.16, Math.sin(angle) * 0.3);
    crownGroup.add(spike);

    const gemMat = new THREE.MeshStandardMaterial({
      color: i % 2 === 0 ? '#10B981' : '#E11D48',
      roughness: 0.1,
      metalness: 0.3,
    });
    const gem = new THREE.Mesh(new THREE.SphereGeometry(0.036, 12, 12), gemMat);
    gem.position.set(Math.cos(angle) * 0.32, 0.0, Math.sin(angle) * 0.32);
    crownGroup.add(gem);
  }
  crownGroup.visible = false;
  bodyGroup.add(crownGroup);
  accessories.crown = crownGroup;

  // 2. Athletic Headband ("ТЫГЫДЫК")
  const headbandGroup = new THREE.Group();
  headbandGroup.position.set(0, 2.08, 0.22);
  headbandGroup.rotation.x = 0.22;
  const bandMat = new THREE.MeshStandardMaterial({ color: '#E11D48', roughness: 0.5 });
  const bandTorus = new THREE.Mesh(new THREE.TorusGeometry(0.84, 0.068, 16, 48), bandMat);
  bandTorus.rotation.x = Math.PI / 2;
  bandTorus.scale.set(1.04, 1.02, 1.0);
  headbandGroup.add(bandTorus);
  headbandGroup.visible = false;
  bodyGroup.add(headbandGroup);
  accessories.headband = headbandGroup;

  // 3. Supersonic Visor Shades
  const shadesGroup = new THREE.Group();
  shadesGroup.position.set(0, 0.16, 0.24);
  const visorMat = new THREE.MeshStandardMaterial({
    color: '#0284C7',
    metalness: 0.9,
    roughness: 0.08,
    emissive: '#38BDF8',
    emissiveIntensity: 0.25,
  });
  const leftLens = new THREE.Mesh(new THREE.SphereGeometry(0.23, 24, 24), visorMat);
  leftLens.scale.set(1.15, 0.75, 0.35);
  leftLens.position.set(-0.34, 0, 0);
  shadesGroup.add(leftLens);

  const rightLens = new THREE.Mesh(new THREE.SphereGeometry(0.23, 24, 24), visorMat);
  rightLens.scale.set(1.15, 0.75, 0.35);
  rightLens.position.set(0.34, 0, 0);
  shadesGroup.add(rightLens);

  const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.045, 0.06), goldMat);
  bridge.position.set(0, 0.09, 0.05);
  shadesGroup.add(bridge);
  shadesGroup.visible = false;
  faceGroup.add(shadesGroup);
  accessories.shades = shadesGroup;

  // 4. Golden Gala Bowtie
  const bowtieGroup = new THREE.Group();
  bowtieGroup.position.set(0, 1.22, 1.38);
  bowtieGroup.rotation.x = -0.15;
  const bowMat = new THREE.MeshStandardMaterial({
    color: '#F59E0B',
    roughness: 0.3,
    metalness: 0.5,
  });
  const leftWing = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.26, 16), bowMat);
  leftWing.rotation.z = -Math.PI / 2;
  leftWing.scale.set(1, 1, 0.45);
  leftWing.position.x = -0.11;
  bowtieGroup.add(leftWing);

  const rightWing = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.26, 16), bowMat);
  rightWing.rotation.z = Math.PI / 2;
  rightWing.scale.set(1, 1, 0.45);
  rightWing.position.x = 0.11;
  bowtieGroup.add(rightWing);

  const knot = new THREE.Mesh(new THREE.SphereGeometry(0.065, 16, 16), goldMat);
  bowtieGroup.add(knot);
  bowtieGroup.visible = false;
  bodyGroup.add(bowtieGroup);
  accessories.bowtie = bowtieGroup;

  const setAccessory = (id: AccessoryId) => {
    (Object.keys(accessories) as AccessoryId[]).forEach((key) => {
      const obj = accessories[key];
      if (obj) obj.visible = key === id;
    });
  };

  return {
    root,
    bodyGroup,
    bodyMesh,
    faceGroup,
    leftEye: leftEyeObj.eyeGroup,
    rightEye: rightEyeObj.eyeGroup,
    leftPupil: leftEyeObj.pupilGroup,
    rightPupil: rightEyeObj.pupilGroup,
    leftEyelid: leftEyeObj.lidMesh,
    rightEyelid: rightEyeObj.lidMesh,
    leftEar,
    rightEar,
    mouthMesh,
    leftPaw,
    rightPaw,
    tailGroup,
    headTopAnchor,
    accessories,
    setAccessory,
  };
}
