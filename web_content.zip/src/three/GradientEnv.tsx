import { useThree } from "@react-three/fiber";
import { useEffect } from "react";
import * as THREE from "three";

/**
 * Builds a warm studio environment procedurally (no network HDRI) and feeds it
 * to scene.environment, so the plush materials pick up soft reflections.
 */
export function GradientEnv({ intensity = 0.9 }: { intensity?: number }) {
  const { scene, gl } = useThree();

  useEffect(() => {
    const size = 512;
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size / 2;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // sky → horizon → warm floor
    const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    grad.addColorStop(0, "#fffdf6");
    grad.addColorStop(0.38, "#ffe7bd");
    grad.addColorStop(0.56, "#ffcf96");
    grad.addColorStop(1, "#c97b3c");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // key light blob (upper right)
    const key = ctx.createRadialGradient(
      canvas.width * 0.72,
      canvas.height * 0.18,
      0,
      canvas.width * 0.72,
      canvas.height * 0.18,
      canvas.height * 0.52,
    );
    key.addColorStop(0, "rgba(255,255,255,1)");
    key.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = key;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // cool fill (left) keeps the yellow from going flat
    const fill = ctx.createRadialGradient(
      canvas.width * 0.2,
      canvas.height * 0.34,
      0,
      canvas.width * 0.2,
      canvas.height * 0.34,
      canvas.height * 0.55,
    );
    fill.addColorStop(0, "rgba(198,226,255,0.75)");
    fill.addColorStop(1, "rgba(198,226,255,0)");
    ctx.fillStyle = fill;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const tex = new THREE.CanvasTexture(canvas);
    tex.mapping = THREE.EquirectangularReflectionMapping;
    tex.colorSpace = THREE.SRGBColorSpace;

    const pmrem = new THREE.PMREMGenerator(gl);
    pmrem.compileEquirectangularShader();
    const env = pmrem.fromEquirectangular(tex).texture;

    scene.environment = env;
    scene.environmentIntensity = intensity;

    tex.dispose();
    pmrem.dispose();

    return () => {
      scene.environment = null;
      env.dispose();
    };
  }, [scene, gl, intensity]);

  return null;
}
