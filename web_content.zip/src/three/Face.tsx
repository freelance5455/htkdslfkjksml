import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";
import type { Mood } from "../lib/store";

/** Per-mood facial targets. */
export const FACE: Record<
  Mood,
  {
    browAngle: number;
    browY: number;
    lid: number;
    mouth: number;
    /** 1 = wide happy arc eyes */
    arc: number;
    sweat: number;
    lean: number;
    blushO: number;
  }
> = {
  neutral: { browAngle: 0, browY: 0.26, lid: 1, mouth: 0, arc: 0, sweat: 0, lean: 0, blushO: 0.38 },
  happy: { browAngle: -0.18, browY: 0.3, lid: 1, mouth: 0.55, arc: 1, sweat: 0, lean: -0.06, blushO: 0.62 },
  angry: { browAngle: 0.62, browY: 0.19, lid: 0.78, mouth: 0.8, arc: 0, sweat: 0.35, lean: 0.16, blushO: 0.7 },
  tired: { browAngle: -0.42, browY: 0.21, lid: 0.34, mouth: 0.22, arc: 0, sweat: 0.55, lean: 0.1, blushO: 0.3 },
  eating: { browAngle: -0.1, browY: 0.28, lid: 0.6, mouth: 1, arc: 0.4, sweat: 0, lean: -0.04, blushO: 0.55 },
  refuse: { browAngle: 0.5, browY: 0.2, lid: 0.6, mouth: 0.35, arc: 0, sweat: 0.2, lean: 0.06, blushO: 0.5 },
  flex: { browAngle: 0.34, browY: 0.24, lid: 0.66, mouth: 0.9, arc: 0, sweat: 0.8, lean: -0.1, blushO: 0.75 },
};

/** Angry / tired eyebrows that sit above the eyes. */
export function Brows({ mood }: { mood: Mood }) {
  const l = useRef<THREE.Mesh>(null);
  const r = useRef<THREE.Mesh>(null);
  const cur = useRef({ a: 0, y: 0.26, o: 0 });

  useFrame((_, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    const t = FACE[mood];
    // brows only show for expressive moods
    const targetO = mood === "neutral" ? 0 : 1;
    cur.current.a = THREE.MathUtils.damp(cur.current.a, t.browAngle, 8, dt);
    cur.current.y = THREE.MathUtils.damp(cur.current.y, t.browY, 8, dt);
    cur.current.o = THREE.MathUtils.damp(cur.current.o, targetO, 8, dt);

    const { a, y, o } = cur.current;
    if (l.current) {
      l.current.position.y = y;
      l.current.rotation.z = -a;
      l.current.scale.setScalar(Math.max(0.001, o));
      (l.current.material as THREE.MeshBasicMaterial).opacity = o;
    }
    if (r.current) {
      r.current.position.y = y;
      r.current.rotation.z = a;
      r.current.scale.setScalar(Math.max(0.001, o));
      (r.current.material as THREE.MeshBasicMaterial).opacity = o;
    }
  });

  return (
    <group position={[0, 0, 0.02]}>
      <mesh ref={l} position={[0.215, 0.26, 0.58]}>
        <boxGeometry args={[0.17, 0.038, 0.03]} />
        <meshBasicMaterial color="#3A2409" transparent />
      </mesh>
      <mesh ref={r} position={[-0.215, 0.26, 0.58]}>
        <boxGeometry args={[0.17, 0.038, 0.03]} />
        <meshBasicMaterial color="#3A2409" transparent />
      </mesh>
    </group>
  );
}

/** Happy "^ ^" arcs that fade in over the eyes. */
export function HappyArcs({ mood }: { mood: Mood }) {
  const g = useRef<THREE.Group>(null);
  const o = useRef(0);

  useFrame((_, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    o.current = THREE.MathUtils.damp(o.current, FACE[mood].arc, 9, dt);
    if (!g.current) return;
    g.current.visible = o.current > 0.03;
    g.current.scale.setScalar(Math.max(0.001, o.current));
  });

  return (
    <group ref={g}>
      {[0.215, -0.215].map((x) => (
        <mesh key={x} position={[x, 0.14, 0.635]} rotation={[0, 0, 0]}>
          <torusGeometry args={[0.085, 0.022, 8, 18, Math.PI]} />
          <meshBasicMaterial color="#3A2409" />
        </mesh>
      ))}
    </group>
  );
}

/** Sweat droplets that pop off the head when tired or straining. */
export function Sweat({ mood }: { mood: Mood }) {
  const drops = useRef<(THREE.Mesh | null)[]>([]);
  const amount = useRef(0);

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    const t = state.clock.elapsedTime;
    amount.current = THREE.MathUtils.damp(amount.current, FACE[mood].sweat, 5, dt);
    const a = amount.current;

    drops.current.forEach((m, i) => {
      if (!m) return;
      const phase = (t * 0.9 + i * 0.37) % 1;
      const visible = a > 0.05 && phase < 0.85;
      m.visible = visible;
      if (!visible) return;
      const side = i % 2 === 0 ? 1 : -1;
      m.position.set(
        side * (0.42 + (i % 3) * 0.06),
        0.42 - phase * 0.75,
        0.24 - (i % 3) * 0.12,
      );
      const s = a * (0.9 - phase * 0.5);
      m.scale.set(s, s * 1.5, s);
      (m.material as THREE.MeshPhysicalMaterial).opacity = a * (1 - phase);
    });
  });

  return (
    <group>
      {Array.from({ length: 6 }).map((_, i) => (
        <mesh key={i} ref={(el) => void (drops.current[i] = el)} visible={false}>
          <sphereGeometry args={[0.055, 12, 10]} />
          <meshPhysicalMaterial
            color="#9FD8FF"
            roughness={0.05}
            transmission={0.8}
            thickness={0.2}
            transparent
            opacity={0.8}
            depthWrite={false}
          />
        </mesh>
      ))}
    </group>
  );
}

/** Angry steam puffs from the sides of the head. */
export function AngrySteam({ mood }: { mood: Mood }) {
  const g = useRef<THREE.Group>(null);
  const o = useRef(0);

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    const t = state.clock.elapsedTime;
    o.current = THREE.MathUtils.damp(o.current, mood === "angry" ? 1 : 0, 5, dt);
    if (!g.current) return;
    g.current.visible = o.current > 0.05;
    g.current.children.forEach((c, i) => {
      const phase = (t * 1.3 + i * 0.5) % 1;
      const side = i < 3 ? 1 : -1;
      c.position.set(side * (0.55 + phase * 0.25), 0.35 + phase * 0.55, -0.05);
      const s = o.current * (0.12 + phase * 0.18);
      c.scale.setScalar(s);
      const mat = (c as THREE.Mesh).material as THREE.MeshBasicMaterial;
      mat.opacity = o.current * (1 - phase) * 0.55;
    });
  });

  return (
    <group ref={g} visible={false}>
      {Array.from({ length: 6 }).map((_, i) => (
        <mesh key={i}>
          <sphereGeometry args={[1, 10, 8]} />
          <meshBasicMaterial color="#ffffff" transparent opacity={0.4} depthWrite={false} />
        </mesh>
      ))}
    </group>
  );
}
