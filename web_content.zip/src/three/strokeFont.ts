import * as THREE from "three";

/**
 * A monoline stroke font expressed as real 3D curves.
 *
 * Letters are defined as centre-lines, then swept with TubeGeometry. That gives
 * genuine geometry — a neon sign is literally a bent glass tube, and embroidery
 * is literally a raised thread, so the same data drives both. Nothing here is a
 * painted texture.
 *
 * Coordinate space: x grows right, baseline at y = 0, cap height y = 1.
 */

type Stroke = [number, number][];

/** samples an ellipse arc into a polyline */
function arc(
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  from: number,
  to: number,
  steps = 22,
): Stroke {
  const out: Stroke = [];
  for (let i = 0; i <= steps; i++) {
    const a = ((from + (to - from) * (i / steps)) * Math.PI) / 180;
    out.push([cx + Math.cos(a) * rx, cy + Math.sin(a) * ry]);
  }
  return out;
}

type Glyph = { w: number; strokes: Stroke[] };

const GLYPHS: Record<string, Glyph> = {
  /* ---------------- uppercase ---------------- */
  J: {
    w: 0.54,
    strokes: [[[0.5, 1], [0.5, 0.28]], arc(0.25, 0.28, 0.25, 0.28, 0, -180, 18)],
  },
  N: {
    w: 0.62,
    strokes: [[[0, 0], [0, 1]], [[0, 1], [0.62, 0]], [[0.62, 0], [0.62, 1]]],
  },
  V: { w: 0.62, strokes: [[[0, 1], [0.31, 0], [0.62, 1]]] },
  /* small caps used to build a genuine ™ */
  T: { w: 0.46, strokes: [[[0, 1], [0.46, 1]], [[0.23, 1], [0.23, 0]]] },
  M: {
    w: 0.7,
    strokes: [[[0, 0], [0, 1]], [[0, 1], [0.35, 0.42]], [[0.35, 0.42], [0.7, 1]], [[0.7, 1], [0.7, 0]]],
  },

  /* ---------------- lowercase ---------------- */
  e: {
    w: 0.54,
    strokes: [
      // crossbar, then the bowl sweeping up over the top and round to the tail
      [[0.52, 0.3], [0.03, 0.3]],
      arc(0.27, 0.3, 0.25, 0.28, 0, 310, 26),
    ],
  },
  k: {
    w: 0.54,
    strokes: [[[0, 0], [0, 1]], [[0.5, 0.56], [0.04, 0.2]], [[0.17, 0.31], [0.52, 0]]],
  },
  o: { w: 0.56, strokes: [arc(0.28, 0.28, 0.26, 0.28, 0, 360, 30)] },
  w: {
    w: 0.74,
    strokes: [[[0, 0.56], [0.17, 0], [0.37, 0.42], [0.57, 0], [0.74, 0.56]]],
  },
  i: { w: 0.16, strokes: [[[0.08, 0], [0.08, 0.56]], [[0.08, 0.76], [0.08, 0.79]]] },
  s: {
    w: 0.48,
    strokes: [
      [
        ...arc(0.24, 0.43, 0.2, 0.14, 20, 180, 12),
        ...arc(0.24, 0.15, 0.2, 0.15, 180, 340, 12),
      ],
    ],
  },
  n: {
    w: 0.54,
    strokes: [[[0, 0], [0, 0.56]], arc(0.27, 0.3, 0.27, 0.26, 180, 0, 16), [[0.54, 0.3], [0.54, 0]]],
  },
};

const SPACE = 0.24;
const GAP = 0.1;

export type StrokeGeo = { geo: THREE.TubeGeometry; key: string };

/**
 * Builds tube geometry for a word.
 * @param text        characters to render (must exist in GLYPHS)
 * @param thickness   tube radius, in em units
 * @param radialSegs  cross-section resolution
 */
export function buildStrokeText(text: string, thickness = 0.055, radialSegs = 8) {
  const geos: THREE.TubeGeometry[] = [];
  let cursor = 0;

  for (const ch of text) {
    if (ch === " ") {
      cursor += SPACE;
      continue;
    }
    const g = GLYPHS[ch];
    if (!g) {
      cursor += SPACE;
      continue;
    }

    for (const stroke of g.strokes) {
      if (stroke.length < 2) continue;
      const pts = stroke.map(([x, y]) => new THREE.Vector3(cursor + x, y, 0));

      // a 2-point stroke is a straight segment; longer ones get smoothed
      const curve =
        pts.length === 2
          ? new THREE.CatmullRomCurve3(pts, false, "catmullrom", 0)
          : new THREE.CatmullRomCurve3(pts, false, "centripetal", 0.4);

      const segs = Math.max(12, Math.min(90, pts.length * 6));
      geos.push(new THREE.TubeGeometry(curve, segs, thickness, radialSegs, false));

      // round the ends so joints never show a hard cut
      const cap = new THREE.SphereGeometry(thickness, radialSegs, 6);
      const a = cap.clone();
      a.translate(pts[0].x, pts[0].y, pts[0].z);
      const b = cap.clone();
      const last = pts[pts.length - 1];
      b.translate(last.x, last.y, last.z);
      geos.push(a as unknown as THREE.TubeGeometry, b as unknown as THREE.TubeGeometry);
      cap.dispose();
    }
    cursor += g.w + GAP;
  }

  return { geos, width: Math.max(0, cursor - GAP) };
}

/** Merges the strokes into one geometry, centred on its own bounding box. */
export function strokeTextGeometry(text: string, thickness = 0.055, radialSegs = 8) {
  const { geos, width } = buildStrokeText(text, thickness, radialSegs);
  if (!geos.length) return { geometry: new THREE.BufferGeometry(), width: 0 };

  // manual merge keeps the dependency surface small
  let total = 0;
  for (const g of geos) total += g.attributes.position.count;

  const pos = new Float32Array(total * 3);
  const nor = new Float32Array(total * 3);
  const idx: number[] = [];
  let vo = 0;

  for (const g of geos) {
    const p = g.attributes.position.array as ArrayLike<number>;
    const n = g.attributes.normal.array as ArrayLike<number>;
    const count = g.attributes.position.count;
    pos.set(p as ArrayLike<number>, vo * 3);
    nor.set(n as ArrayLike<number>, vo * 3);
    const gi = g.index;
    if (gi) {
      for (let i = 0; i < gi.count; i++) idx.push(gi.getX(i) + vo);
    } else {
      for (let i = 0; i < count; i++) idx.push(i + vo);
    }
    vo += count;
    g.dispose();
  }

  const out = new THREE.BufferGeometry();
  out.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  out.setAttribute("normal", new THREE.BufferAttribute(nor, 3));
  out.setIndex(idx);
  out.computeBoundingBox();

  // centre horizontally and on the x-height so it mounts predictably
  out.translate(-width / 2, -0.28, 0);
  out.computeBoundingSphere();

  return { geometry: out, width };
}
