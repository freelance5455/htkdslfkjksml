import { Html } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";

/** Golden dumbbell gripped by the wing during gym reps. */
export function HeldDumbbell({ show }: { show: boolean }) {
  const g = useRef<THREE.Group>(null);
  const o = useRef(0);

  useFrame((_, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    o.current = THREE.MathUtils.damp(o.current, show ? 1 : 0, 9, dt);
    if (!g.current) return;
    g.current.visible = o.current > 0.02;
    g.current.scale.setScalar(Math.max(0.001, o.current));
  });

  return (
    <group ref={g} visible={false} position={[-0.18, -0.54, 0.42]} rotation={[0, 0, Math.PI / 2]}>
      <mesh castShadow>
        <cylinderGeometry args={[0.032, 0.032, 0.46, 12]} />
        <meshStandardMaterial color="#C9CDD2" roughness={0.25} metalness={0.9} />
      </mesh>
      {[-0.21, 0.21].map((y) => (
        <mesh key={y} position={[0, y, 0]} castShadow>
          <cylinderGeometry args={[0.145, 0.145, 0.12, 20]} />
          <meshStandardMaterial color="#F2C14E" roughness={0.2} metalness={1} />
        </mesh>
      ))}
    </group>
  );
}

/** Street broom held during the sweeping shift. */
export function HeldBroom({ show }: { show: boolean }) {
  const g = useRef<THREE.Group>(null);
  const o = useRef(0);

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    o.current = THREE.MathUtils.damp(o.current, show ? 1 : 0, 8, dt);
    if (!g.current) return;
    g.current.visible = o.current > 0.02;
    g.current.scale.setScalar(Math.max(0.001, o.current));
    // gentle sweeping motion
    g.current.rotation.z = -0.45 + Math.sin(state.clock.elapsedTime * 2.6) * 0.22;
  });

  return (
    <group ref={g} visible={false} position={[-0.2, -0.24, 0.46]}>
      {/* handle */}
      <mesh position={[0, -0.3, 0]} castShadow>
        <cylinderGeometry args={[0.032, 0.032, 1.5, 10]} />
        <meshStandardMaterial color="#B07A42" roughness={0.8} />
      </mesh>
      {/* bristle block */}
      <mesh position={[0, -1.02, 0.08]} rotation={[0.25, 0, 0]} castShadow>
        <boxGeometry args={[0.44, 0.1, 0.16]} />
        <meshStandardMaterial color="#7A4E24" roughness={0.85} />
      </mesh>
      {/* bristles */}
      {Array.from({ length: 9 }).map((_, i) => (
        <mesh key={i} position={[-0.18 + i * 0.045, -1.15, 0.12]} rotation={[0.25, 0, 0]} castShadow>
          <cylinderGeometry args={[0.014, 0.01, 0.24, 6]} />
          <meshStandardMaterial color="#D9A441" roughness={0.95} />
        </mesh>
      ))}
    </group>
  );
}

/**
 * The food item being eaten — floats up to the beak, gets nibbled, then
 * disappears with a couple of crumbs.
 */
export function HeldFood({ emoji, startedAt }: { emoji: string | null; startedAt: number }) {
  const g = useRef<THREE.Group>(null);
  const crumbs = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!g.current) return;
    if (!emoji) {
      g.current.visible = false;
      return;
    }
    const p = Math.min(1, (Date.now() - startedAt) / 2600);
    g.current.visible = p < 0.98;

    // 0.0-0.35 lift to the beak, 0.35-0.85 nibble, 0.85-1 gone
    const lift = Math.min(1, p / 0.35);
    const easeLift = 1 - Math.pow(1 - lift, 3);
    const shrink = p < 0.35 ? 1 : Math.max(0.05, 1 - (p - 0.35) / 0.55);

    g.current.position.set(
      THREE.MathUtils.lerp(0.75, 0.04, easeLift),
      THREE.MathUtils.lerp(-0.55, 1.02, easeLift),
      THREE.MathUtils.lerp(0.5, 0.82, easeLift),
    );
    g.current.scale.setScalar(0.5 * shrink);
    g.current.rotation.z = Math.sin(state.clock.elapsedTime * 9) * 0.12 * (p > 0.35 ? 1 : 0.3);

    if (crumbs.current) {
      crumbs.current.visible = p > 0.4;
      crumbs.current.children.forEach((c, i) => {
        const ph = ((p - 0.4) * 2.4 + i * 0.3) % 1;
        c.position.set(
          (i % 2 === 0 ? 1 : -1) * ph * 0.4,
          1.0 - ph * 1.1,
          0.7 + (i % 3) * 0.06,
        );
        c.scale.setScalar(Math.max(0.001, (1 - ph) * 0.06));
      });
    }
  });

  return (
    <>
      <group ref={g} visible={false}>
        <Html center distanceFactor={5} zIndexRange={[5, 0]}>
          <span className="pointer-events-none text-5xl select-none drop-shadow-lg">{emoji}</span>
        </Html>
      </group>
      <group ref={crumbs} visible={false}>
        {Array.from({ length: 5 }).map((_, i) => (
          <mesh key={i}>
            <sphereGeometry args={[1, 6, 5]} />
            <meshStandardMaterial color="#C98E3F" roughness={0.9} />
          </mesh>
        ))}
      </group>
    </>
  );
}

/** Black burglar outfit: mask over the eyes + a striped loot sack. */
export function BurglarKit({ show }: { show: boolean }) {
  const g = useRef<THREE.Group>(null);
  const o = useRef(0);

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    o.current = THREE.MathUtils.damp(o.current, show ? 1 : 0, 8, dt);
    if (!g.current) return;
    g.current.visible = o.current > 0.02;
    g.current.scale.setScalar(Math.max(0.001, o.current));
    g.current.position.y = Math.sin(state.clock.elapsedTime * 2) * 0.02;
  });

  return (
    <group ref={g} visible={false}>
      {/* beanie */}
      <mesh position={[0, 1.52, 0.02]} scale={[1, 0.72, 1]} castShadow>
        <sphereGeometry args={[0.56, 22, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial color="#1A1A20" roughness={0.9} />
      </mesh>
      <mesh position={[0, 1.5, 0.02]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.53, 0.075, 12, 28]} />
        <meshStandardMaterial color="#26262E" roughness={0.9} />
      </mesh>
      {/* eye mask band */}
      <mesh position={[0, 1.12, 0.46]} rotation={[0.06, 0, 0]}>
        <boxGeometry args={[0.92, 0.2, 0.4]} />
        <meshStandardMaterial color="#15151A" roughness={0.85} />
      </mesh>
      {/* loot sack on the back */}
      <group position={[-0.24, 0.22, -0.82]} rotation={[0.2, 0.3, 0.25]}>
        <mesh castShadow>
          <sphereGeometry args={[0.36, 20, 16]} />
          <meshStandardMaterial color="#3A3A44" roughness={0.95} />
        </mesh>
        <mesh position={[0, 0.34, 0]}>
          <cylinderGeometry args={[0.11, 0.16, 0.2, 12]} />
          <meshStandardMaterial color="#2B2B33" roughness={0.95} />
        </mesh>
      </group>
    </group>
  );
}

/** Striped prison uniform + handcuffs. */
export function PrisonKit({ show }: { show: boolean }) {
  const g = useRef<THREE.Group>(null);
  const o = useRef(0);

  useFrame((_, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    o.current = THREE.MathUtils.damp(o.current, show ? 1 : 0, 7, dt);
    if (!g.current) return;
    g.current.visible = o.current > 0.02;
    g.current.scale.setScalar(Math.max(0.001, o.current));
  });

  return (
    <group ref={g} visible={false}>
      {/* prison stripes wrapped round the body */}
      {[-0.42, -0.14, 0.14, 0.42].map((y, i) => (
        <mesh key={i} position={[0, y, 0]} scale={[1.015, 1, 0.96]}>
          <cylinderGeometry args={[0.99, 0.99, 0.12, 30, 1, true]} />
          <meshStandardMaterial color="#1E1E26" roughness={0.95} side={THREE.DoubleSide} />
        </mesh>
      ))}
      {/* cap */}
      <mesh position={[0, 1.5, 0]} scale={[1, 0.6, 1]} castShadow>
        <sphereGeometry args={[0.52, 20, 14, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial color="#E8E6E1" roughness={0.9} />
      </mesh>
      <mesh position={[0, 1.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.5, 0.06, 10, 26]} />
        <meshStandardMaterial color="#2A2A32" roughness={0.9} />
      </mesh>
      {/* number plate */}
      <mesh position={[0, 0.3, 0.94]} rotation={[0, 0, 0]}>
        <planeGeometry args={[0.42, 0.18]} />
        <meshStandardMaterial color="#F2F0EB" roughness={0.95} />
      </mesh>
      {/* handcuffs in front */}
      <group position={[0, -0.12, 0.86]} rotation={[0.3, 0, 0]}>
        {[-0.16, 0.16].map((x) => (
          <mesh key={x} position={[x, 0, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
            <torusGeometry args={[0.13, 0.032, 10, 20]} />
            <meshStandardMaterial color="#A8AEB6" roughness={0.3} metalness={0.95} />
          </mesh>
        ))}
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.022, 0.022, 0.2, 8]} />
          <meshStandardMaterial color="#98A0A8" roughness={0.3} metalness={0.95} />
        </mesh>
      </group>
    </group>
  );
}

/**
 * The 3D smartphone Jeeko raises before the UI appears. The wing lifts it up
 * and the glass screen glows once it is "on".
 */
export function HeldPhone({ show, lit }: { show: boolean; lit: boolean }) {
  const g = useRef<THREE.Group>(null);
  const glow = useRef<THREE.MeshStandardMaterial>(null);
  const o = useRef(0);
  const on = useRef(0);

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    const t = state.clock.elapsedTime;
    o.current = THREE.MathUtils.damp(o.current, show ? 1 : 0, 7, dt);
    on.current = THREE.MathUtils.damp(on.current, lit ? 1 : 0, 6, dt);

    if (g.current) {
      g.current.visible = o.current > 0.02;
      g.current.scale.setScalar(Math.max(0.001, o.current));
      // rises from the hip up in front of the chest
      g.current.position.set(
        THREE.MathUtils.lerp(-0.1, -0.2, o.current),
        THREE.MathUtils.lerp(-0.78, -0.05, o.current),
        THREE.MathUtils.lerp(0.42, 0.92, o.current),
      );
      g.current.rotation.set(
        THREE.MathUtils.lerp(0.9, 0.34, o.current),
        -0.22 + Math.sin(t * 1.4) * 0.03,
        THREE.MathUtils.lerp(0.5, 0.12, o.current),
      );
    }
    if (glow.current) {
      glow.current.emissiveIntensity = 0.15 + on.current * 1.9;
    }
  });

  return (
    <group ref={g} visible={false}>
      {/* body */}
      <mesh castShadow>
        <boxGeometry args={[0.34, 0.62, 0.035]} />
        <meshPhysicalMaterial color="#2B2F3A" roughness={0.3} metalness={0.7} clearcoat={0.8} />
      </mesh>
      {/* glass */}
      <mesh position={[0, 0, 0.023]}>
        <boxGeometry args={[0.3, 0.56, 0.006]} />
        <meshStandardMaterial
          ref={glow}
          color="#BFE9FF"
          emissive="#7FD4FF"
          emissiveIntensity={0.15}
          roughness={0.12}
        />
      </mesh>
      {/* camera bump */}
      <mesh position={[-0.1, 0.22, -0.028]}>
        <boxGeometry args={[0.1, 0.1, 0.018]} />
        <meshStandardMaterial color="#1A1D25" roughness={0.4} metalness={0.6} />
      </mesh>
      {/* home pill */}
      <mesh position={[0, -0.25, 0.026]}>
        <boxGeometry args={[0.1, 0.012, 0.004]} />
        <meshBasicMaterial color="#8FA0B5" />
      </mesh>
    </group>
  );
}

/** Blaster gripped by the wing during the alien fight. */
export function HeldGun({
  show,
  color,
  flip = false,
}: {
  show: boolean;
  color: string;
  /** mirror onto the left wing (used in the side-on Mars fight) */
  flip?: boolean;
}) {
  const g = useRef<THREE.Group>(null);
  const o = useRef(0);

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    o.current = THREE.MathUtils.damp(o.current, show ? 1 : 0, 9, dt);
    if (!g.current) return;
    g.current.visible = o.current > 0.02;
    g.current.scale.setScalar(Math.max(0.001, o.current));
    // slight ready-stance bob
    g.current.position.y = -0.34 + Math.sin(state.clock.elapsedTime * 2.2) * 0.015;
  });

  return (
    <group
      ref={g}
      visible={false}
      position={[flip ? 0.16 : -0.16, -0.4, 0.62]}
      rotation={[0, 0, flip ? 0.18 : -0.18]}
    >
      {/* grip */}
      <mesh position={[0, -0.1, 0]} rotation={[0, 0, 0.3]} castShadow>
        <boxGeometry args={[0.08, 0.2, 0.09]} />
        <meshStandardMaterial color="#2B2D36" roughness={0.5} metalness={0.6} />
      </mesh>
      {/* body */}
      <mesh position={[0, 0.04, 0.12]} castShadow>
        <boxGeometry args={[0.11, 0.14, 0.42]} />
        <meshStandardMaterial color="#454A56" roughness={0.35} metalness={0.8} />
      </mesh>
      {/* barrel */}
      <mesh position={[0, 0.05, 0.38]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <cylinderGeometry args={[0.045, 0.05, 0.26, 12]} />
        <meshStandardMaterial color="#6B7280" roughness={0.25} metalness={0.95} />
      </mesh>
      {/* glowing energy cell + muzzle ring */}
      <mesh position={[0, 0.12, 0.06]}>
        <boxGeometry args={[0.06, 0.05, 0.16]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={2.2} />
      </mesh>
      <mesh position={[0, 0.05, 0.52]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.055, 0.016, 8, 16]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={2.6} />
      </mesh>
    </group>
  );
}

/** Clear pressure dome worn off-world. */
export function SpaceHelmet({ show }: { show: boolean }) {
  const g = useRef<THREE.Group>(null);
  const o = useRef(0);

  useFrame((_, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    o.current = THREE.MathUtils.damp(o.current, show ? 1 : 0, 7, dt);
    if (!g.current) return;
    g.current.visible = o.current > 0.02;
    g.current.scale.setScalar(Math.max(0.001, o.current));
  });

  return (
    <group ref={g} visible={false}>
      {/* glass dome */}
      <mesh position={[0, 0.06, 0.02]}>
        <sphereGeometry args={[0.82, 24, 18]} />
        <meshPhysicalMaterial
          color="#CFE9FF"
          roughness={0.03}
          metalness={0}
          transmission={0.92}
          thickness={0.25}
          transparent
          opacity={0.32}
          clearcoat={1}
          side={THREE.DoubleSide}
        />
      </mesh>
      {/* neck ring */}
      <mesh position={[0, -0.5, 0.02]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.6, 0.075, 10, 26]} />
        <meshStandardMaterial color="#D8DEE9" roughness={0.3} metalness={0.85} />
      </mesh>
      {/* antenna */}
      <mesh position={[0.52, 0.58, -0.1]} rotation={[0, 0, -0.35]}>
        <cylinderGeometry args={[0.016, 0.016, 0.26, 6]} />
        <meshStandardMaterial color="#9AA3B2" metalness={0.9} roughness={0.25} />
      </mesh>
      <mesh position={[0.6, 0.72, -0.12]}>
        <sphereGeometry args={[0.045, 8, 6]} />
        <meshStandardMaterial color="#FF5D5D" emissive="#FF3B3B" emissiveIntensity={2} />
      </mesh>
    </group>
  );
}
