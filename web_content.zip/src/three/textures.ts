import * as THREE from "three";

/**
 * Procedural surface textures (wool, canvas, gloss, leather, galaxy, neon…).
 *
 * These only describe the *material* — the NewVision™ brand is modelled as real
 * embroidered geometry in Suit.tsx, never painted in here.
 */

const SIZE = 512;
const cache = new Map<string, THREE.CanvasTexture>();

function canvas() {
  const c = document.createElement("canvas");
  c.width = c.height = SIZE;
  return c;
}

function finish(c: HTMLCanvasElement, repeat = 1) {
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.anisotropy = 4;
  return tex;
}

/* ------------------------------------------------------------------ */
/*  brand mark                                                         */
/* ------------------------------------------------------------------ */
type BrandStyle = "stitch" | "print" | "gloss" | "deboss" | "glow";

/** Draws NewVision™ so it looks manufactured into the surface. */
function brandMark(
  ctx: CanvasRenderingContext2D,
  style: BrandStyle,
  accent: string,
  x = SIZE / 2,
  y = SIZE / 2,
  scale = 1,
) {
  const fs = 54 * scale;
  ctx.save();
  ctx.translate(x, y);
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.font = `800 ${fs}px ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif`;

  const text = "NewVision";
  const tmW = ctx.measureText(text).width;

  if (style === "stitch") {
    // knitted-in: a dark sunken line with a lighter thread highlight below
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillText(text, 0, 1.5);
    ctx.globalAlpha = 0.85;
    ctx.fillStyle = accent;
    ctx.fillText(text, 0, 0);
    // dashed stitching along the baseline
    ctx.globalAlpha = 0.5;
    ctx.strokeStyle = accent;
    ctx.lineWidth = 2.4 * scale;
    ctx.setLineDash([5 * scale, 5 * scale]);
    ctx.beginPath();
    ctx.moveTo(-tmW / 2, fs * 0.46);
    ctx.lineTo(tmW / 2, fs * 0.46);
    ctx.stroke();
    ctx.setLineDash([]);
  } else if (style === "gloss") {
    // shiny plate: vertical metallic ramp + crisp edge
    const g = ctx.createLinearGradient(0, -fs / 2, 0, fs / 2);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(0.45, accent);
    g.addColorStop(0.55, "#ffffff");
    g.addColorStop(1, accent);
    ctx.globalAlpha = 0.95;
    ctx.fillStyle = g;
    ctx.fillText(text, 0, 0);
    ctx.globalAlpha = 0.6;
    ctx.lineWidth = 1.6 * scale;
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.strokeText(text, 0, 0);
  } else if (style === "deboss") {
    // pressed into leather: dark core, light top bevel
    ctx.globalAlpha = 0.7;
    ctx.fillStyle = "rgba(255,255,255,0.28)";
    ctx.fillText(text, 0, -2);
    ctx.globalAlpha = 0.85;
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillText(text, 0, 0);
  } else if (style === "glow") {
    // neon tube lettering
    ctx.globalAlpha = 1;
    ctx.shadowColor = accent;
    ctx.shadowBlur = 26 * scale;
    ctx.fillStyle = "#ffffff";
    ctx.fillText(text, 0, 0);
    ctx.shadowBlur = 12 * scale;
    ctx.fillStyle = accent;
    ctx.fillText(text, 0, 0);
    ctx.shadowBlur = 0;
  } else {
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = accent;
    ctx.fillText(text, 0, 0);
  }

  // ™ sits up on the shoulder of the word
  ctx.globalAlpha = style === "glow" ? 1 : 0.75;
  ctx.font = `700 ${fs * 0.32}px ui-sans-serif, system-ui, sans-serif`;
  ctx.fillStyle = style === "gloss" || style === "glow" ? "#ffffff" : accent;
  ctx.fillText("™", tmW / 2 + fs * 0.2, -fs * 0.26);
  ctx.restore();
}

/* ------------------------------------------------------------------ */
/*  surfaces                                                           */
/* ------------------------------------------------------------------ */
function fill(ctx: CanvasRenderingContext2D, base: string, shade: string) {
  const g = ctx.createLinearGradient(0, 0, 0, SIZE);
  g.addColorStop(0, base);
  g.addColorStop(1, shade);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, SIZE, SIZE);
}

/** Chunky knitted wool — visible fibres and a ribbed weave. */
export function woolTexture(base: string, accent: string, brand = false) {
  const key = `wool|${base}|${accent}|${brand}`;
  const hit = cache.get(key);
  if (hit) return hit;

  const c = canvas();
  const ctx = c.getContext("2d")!;
  const dark = shade(base, -0.22);
  fill(ctx, base, dark);

  // knit V-stitches
  ctx.lineWidth = 3;
  for (let y = 0; y < SIZE; y += 16) {
    for (let x = 0; x < SIZE; x += 16) {
      const o = (y / 16) % 2 === 0 ? 0 : 8;
      ctx.strokeStyle = `rgba(255,255,255,0.10)`;
      ctx.beginPath();
      ctx.moveTo(x + o, y + 13);
      ctx.lineTo(x + o + 8, y + 3);
      ctx.lineTo(x + o + 16, y + 13);
      ctx.stroke();
      ctx.strokeStyle = `rgba(0,0,0,0.14)`;
      ctx.beginPath();
      ctx.moveTo(x + o, y + 15);
      ctx.lineTo(x + o + 8, y + 5);
      ctx.lineTo(x + o + 16, y + 15);
      ctx.stroke();
    }
  }

  // loose fibres for fuzz
  for (let i = 0; i < 2600; i++) {
    const x = Math.random() * SIZE;
    const y = Math.random() * SIZE;
    const a = Math.random() * Math.PI * 2;
    const l = 2 + Math.random() * 5;
    ctx.strokeStyle = Math.random() > 0.5 ? "rgba(255,255,255,0.14)" : "rgba(0,0,0,0.12)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l);
    ctx.stroke();
  }

  if (brand) brandMark(ctx, "stitch", accent);
  const tex = finish(c);
  cache.set(key, tex);
  return tex;
}

/** Tight woven cotton / canvas. */
export function fabricTexture(base: string, accent: string, brand = false) {
  const key = `fab|${base}|${accent}|${brand}`;
  const hit = cache.get(key);
  if (hit) return hit;

  const c = canvas();
  const ctx = c.getContext("2d")!;
  fill(ctx, base, shade(base, -0.16));

  ctx.lineWidth = 1;
  for (let i = 0; i < SIZE; i += 4) {
    ctx.strokeStyle = "rgba(255,255,255,0.06)";
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, SIZE);
    ctx.stroke();
    ctx.strokeStyle = "rgba(0,0,0,0.06)";
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(SIZE, i);
    ctx.stroke();
  }
  for (let i = 0; i < 1400; i++) {
    ctx.fillStyle = Math.random() > 0.5 ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)";
    ctx.fillRect(Math.random() * SIZE, Math.random() * SIZE, 2, 2);
  }

  if (brand) brandMark(ctx, "print", accent);
  const tex = finish(c);
  cache.set(key, tex);
  return tex;
}

/** Polished latex / patent finish with a sweeping highlight. */
export function glossTexture(base: string, accent: string, brand = false) {
  const key = `gloss|${base}|${accent}|${brand}`;
  const hit = cache.get(key);
  if (hit) return hit;

  const c = canvas();
  const ctx = c.getContext("2d")!;
  fill(ctx, shade(base, 0.1), shade(base, -0.3));

  const g = ctx.createLinearGradient(0, 0, SIZE, SIZE);
  g.addColorStop(0, "rgba(255,255,255,0)");
  g.addColorStop(0.42, "rgba(255,255,255,0.34)");
  g.addColorStop(0.5, "rgba(255,255,255,0.5)");
  g.addColorStop(0.58, "rgba(255,255,255,0.28)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, SIZE, SIZE);

  if (brand) brandMark(ctx, "gloss", accent);
  const tex = finish(c);
  cache.set(key, tex);
  return tex;
}

/** Grained leather with a debossed mark. */
export function leatherTexture(base: string, accent: string, brand = false) {
  const key = `leather|${base}|${accent}|${brand}`;
  const hit = cache.get(key);
  if (hit) return hit;

  const c = canvas();
  const ctx = c.getContext("2d")!;
  fill(ctx, base, shade(base, -0.3));

  for (let i = 0; i < 5000; i++) {
    const x = Math.random() * SIZE;
    const y = Math.random() * SIZE;
    const r = 1 + Math.random() * 3;
    ctx.fillStyle = Math.random() > 0.5 ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.14)";
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  if (brand) brandMark(ctx, "deboss", accent);
  const tex = finish(c);
  cache.set(key, tex);
  return tex;
}

/** Deep space nebula — scrolled in the shader for a flowing cosmos. */
export function galaxyTexture() {
  const key = "galaxy";
  const hit = cache.get(key);
  if (hit) return hit;

  const c = canvas();
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#0A0620";
  ctx.fillRect(0, 0, SIZE, SIZE);

  // nebula clouds
  const clouds: [string, number][] = [
    ["#4C1D95", 150],
    ["#7C3AED", 120],
    ["#DB2777", 110],
    ["#0EA5E9", 100],
    ["#F59E0B", 70],
  ];
  clouds.forEach(([col, r]) => {
    for (let i = 0; i < 7; i++) {
      const x = Math.random() * SIZE;
      const y = Math.random() * SIZE;
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, col + "aa");
      g.addColorStop(1, col + "00");
      ctx.fillStyle = g;
      ctx.fillRect(x - r, y - r, r * 2, r * 2);
    }
  });

  // stars
  for (let i = 0; i < 900; i++) {
    const x = Math.random() * SIZE;
    const y = Math.random() * SIZE;
    const r = Math.random() * 1.7;
    ctx.fillStyle = `rgba(255,255,255,${0.35 + Math.random() * 0.65})`;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  // a few bright ones with flare
  for (let i = 0; i < 26; i++) {
    const x = Math.random() * SIZE;
    const y = Math.random() * SIZE;
    const g = ctx.createRadialGradient(x, y, 0, x, y, 9);
    g.addColorStop(0, "rgba(255,255,255,0.95)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x - 9, y - 9, 18, 18);
  }

  const tex = finish(c);
  cache.set(key, tex);
  return tex;
}

/** Glowing circuit / neon grid. */
export function neonTexture(accent: string) {
  const key = `neon|${accent}`;
  const hit = cache.get(key);
  if (hit) return hit;

  const c = canvas();
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#07080F";
  ctx.fillRect(0, 0, SIZE, SIZE);

  ctx.shadowColor = accent;
  ctx.shadowBlur = 14;
  ctx.strokeStyle = accent;
  ctx.lineWidth = 2.5;
  for (let i = 0; i < SIZE; i += 64) {
    ctx.globalAlpha = 0.85;
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, SIZE);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(SIZE, i);
    ctx.stroke();
  }
  // brighter nodes
  ctx.globalAlpha = 1;
  for (let x = 0; x < SIZE; x += 64) {
    for (let y = 0; y < SIZE; y += 64) {
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.shadowBlur = 0;

  const tex = finish(c);
  cache.set(key, tex);
  return tex;
}

/** Hellish molten cracks. */
export function demonTexture() {
  const key = "demon";
  const hit = cache.get(key);
  if (hit) return hit;

  const c = canvas();
  const ctx = c.getContext("2d")!;
  fill(ctx, "#2A0505", "#120202");

  ctx.lineCap = "round";
  for (let i = 0; i < 46; i++) {
    let x = Math.random() * SIZE;
    let y = Math.random() * SIZE;
    ctx.shadowColor = "#FF4500";
    ctx.shadowBlur = 16;
    ctx.strokeStyle = i % 3 === 0 ? "#FFB03A" : "#FF3B1F";
    ctx.lineWidth = 1 + Math.random() * 2.6;
    ctx.beginPath();
    ctx.moveTo(x, y);
    for (let k = 0; k < 7; k++) {
      x += (Math.random() - 0.5) * 62;
      y += (Math.random() - 0.5) * 62;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  ctx.shadowBlur = 0;

  const tex = finish(c);
  cache.set(key, tex);
  return tex;
}

/** Iridescent holographic sweep. */
export function holoTexture() {
  const key = "holo";
  const hit = cache.get(key);
  if (hit) return hit;

  const c = canvas();
  const ctx = c.getContext("2d")!;
  const g = ctx.createLinearGradient(0, 0, SIZE, SIZE);
  [
    "#FF6EC7",
    "#FFB86B",
    "#F9F871",
    "#6EE7B7",
    "#5AC8FA",
    "#A78BFA",
    "#FF6EC7",
  ].forEach((col, i, arr) => g.addColorStop(i / (arr.length - 1), col));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, SIZE, SIZE);

  // interference banding
  ctx.globalAlpha = 0.16;
  for (let i = 0; i < SIZE; i += 7) {
    ctx.fillStyle = i % 14 === 0 ? "#ffffff" : "#000000";
    ctx.fillRect(0, i, SIZE, 3);
  }
  ctx.globalAlpha = 1;

  const tex = finish(c);
  cache.set(key, tex);
  return tex;
}

/* ------------------------------------------------------------------ */
export function shade(hex: string, amt: number) {
  const c = new THREE.Color(hex);
  if (amt >= 0) c.lerp(new THREE.Color("#ffffff"), amt);
  else c.lerp(new THREE.Color("#000000"), -amt);
  return `#${c.getHexString()}`;
}

/** Texture picked by garment finish. */
export function finishTexture(
  kind: "wool" | "fabric" | "gloss" | "leather",
  base: string,
  accent: string,
) {
  if (kind === "wool") return woolTexture(base, accent);
  if (kind === "gloss") return glossTexture(base, accent);
  if (kind === "leather") return leatherTexture(base, accent);
  return fabricTexture(base, accent);
}
