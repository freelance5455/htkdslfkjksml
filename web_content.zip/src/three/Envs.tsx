import { useFrame } from "@react-three/fiber";
import { useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { store, useStore } from "../lib/store";
import { NeonSign } from "./NeonSign";
import { chirp } from "../lib/sound";

/* ================================================================== */
/*  shared ground                                                      */
/* ================================================================== */
function Floor({ color, y = -1.2 }: { color: string; y?: number }) {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, y, 0]} receiveShadow>
      <circleGeometry args={[9, 48]} />
      <meshStandardMaterial color={color} roughness={0.9} />
    </mesh>
  );
}

/* ================================================================== */
/*  HOME — the chick's room, full of clickable props                   */
/* ================================================================== */
/**
 * HOME — a neon-lit lounge.
 *
 * Built from the same vocabulary as the arcade: a dark reflective floor, glow
 * strips, wall tubes and a real neon sign, so the two spaces feel like one
 * world. The chick reads clearly because the backdrop is dark and the rim
 * lighting separates it.
 */
export function HomeEnv() {
  const strips = useRef<THREE.MeshStandardMaterial[]>([]);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    strips.current.forEach((m, i) => {
      if (m) m.emissiveIntensity = 1.9 + Math.sin(t * 1.6 + i * 1.1) * 0.7;
    });
  });

  const NEON = ["#FF2D95", "#00E5FF", "#C77DFF", "#7CFFCB"];

  return (
    <group>
      {/* ---------- floor ---------- */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.2, 0]} receiveShadow>
        <circleGeometry args={[22, 52]} />
        <meshStandardMaterial color="#16102A" roughness={0.34} metalness={0.55} />
      </mesh>

      {/* glowing floor rings echo the arcade */}
      {[2.4, 3.8, 5.4].map((r, i) => (
        <mesh key={r} rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.19, 0]}>
          <ringGeometry args={[r, r + 0.05, 56]} />
          <meshStandardMaterial
            color={NEON[i % NEON.length]}
            emissive={NEON[i % NEON.length]}
            emissiveIntensity={1.9}
            toneMapped={false}
          />
        </mesh>
      ))}

      {/* soft rug under the chick */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.185, 0.1]} receiveShadow>
        <circleGeometry args={[1.85, 44]} />
        <meshStandardMaterial color="#2A1E45" roughness={0.92} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.18, 0.1]}>
        <ringGeometry args={[1.6, 1.72, 44]} />
        <meshStandardMaterial
          color="#C77DFF"
          emissive="#C77DFF"
          emissiveIntensity={1.1}
          toneMapped={false}
        />
      </mesh>

      {/* ---------- back wall ---------- */}
      <mesh position={[0, 1.8, -4.6]} receiveShadow>
        <boxGeometry args={[20, 7.4, 0.3]} />
        <meshStandardMaterial color="#120E22" roughness={0.8} />
      </mesh>

      {/* panel seams give the wall scale */}
      {[-6.2, -3.1, 3.1, 6.2].map((x) => (
        <mesh key={x} position={[x, 1.8, -4.43]}>
          <boxGeometry args={[0.05, 6.4, 0.02]} />
          <meshStandardMaterial color="#241B3E" roughness={0.7} />
        </mesh>
      ))}

      {/* ---------- the neon sign ---------- */}
      <NeonSign position={[0, 1.5, -4.3]} scale={1.15} color="#FF2D95" color2="#00E5FF" />

      {/* ---------- vertical wall tubes ---------- */}
      {[-7.4, -5.6, 5.6, 7.4].map((x, i) => (
        <mesh key={x} position={[x, 1.5, -4.35]}>
          <capsuleGeometry args={[0.055, 3.6, 4, 10]} />
          <meshStandardMaterial
            ref={(m) => {
              if (m) strips.current[i] = m;
            }}
            color="#FFFFFF"
            emissive={NEON[i % NEON.length]}
            emissiveIntensity={1.8}
            toneMapped={false}
          />
        </mesh>
      ))}

      {/* ---------- couch on the left ---------- */}
      <group position={[-3.4, -1.2, -1.4]} rotation={[0, 0.45, 0]}>
        <mesh position={[0, 0.42, 0]} castShadow receiveShadow>
          <boxGeometry args={[2.1, 0.45, 0.9]} />
          <meshStandardMaterial color="#3A2456" roughness={0.9} />
        </mesh>
        <mesh position={[0, 0.82, -0.38]} castShadow>
          <boxGeometry args={[2.1, 0.8, 0.22]} />
          <meshStandardMaterial color="#452A66" roughness={0.9} />
        </mesh>
        {[-0.95, 0.95].map((x) => (
          <mesh key={x} position={[x, 0.66, 0]} castShadow>
            <boxGeometry args={[0.22, 0.75, 0.9]} />
            <meshStandardMaterial color="#452A66" roughness={0.9} />
          </mesh>
        ))}
        {/* under-glow */}
        <mesh position={[0, 0.14, 0.2]}>
          <boxGeometry args={[1.9, 0.03, 0.03]} />
          <meshStandardMaterial color="#FF2D95" emissive="#FF2D95" emissiveIntensity={2} toneMapped={false} />
        </mesh>
      </group>

      {/* ---------- shelf + plant on the right ---------- */}
      <group position={[3.5, -1.2, -1.6]} rotation={[0, -0.4, 0]}>
        <mesh position={[0, 0.55, 0]} castShadow receiveShadow>
          <boxGeometry args={[1.5, 0.08, 0.6]} />
          <meshStandardMaterial color="#2E2148" roughness={0.75} />
        </mesh>
        <mesh position={[0, 1.15, 0]} castShadow receiveShadow>
          <boxGeometry args={[1.5, 0.08, 0.6]} />
          <meshStandardMaterial color="#2E2148" roughness={0.75} />
        </mesh>
        {[-0.68, 0.68].map((x) => (
          <mesh key={x} position={[x, 0.7, 0]} castShadow>
            <boxGeometry args={[0.1, 1.4, 0.6]} />
            <meshStandardMaterial color="#241A3A" roughness={0.8} />
          </mesh>
        ))}
        {/* shelf glow strips */}
        {[0.6, 1.2].map((y) => (
          <mesh key={y} position={[0, y, 0.3]}>
            <boxGeometry args={[1.36, 0.02, 0.02]} />
            <meshStandardMaterial color="#00E5FF" emissive="#00E5FF" emissiveIntensity={2} toneMapped={false} />
          </mesh>
        ))}
        {/* potted plant */}
        <mesh position={[0.45, 1.32, 0]} castShadow>
          <cylinderGeometry args={[0.16, 0.12, 0.26, 12]} />
          <meshStandardMaterial color="#8C5A3C" roughness={0.9} />
        </mesh>
        {[0, 1, 2, 3].map((i) => {
          const a = (i / 4) * Math.PI * 2;
          return (
            <mesh
              key={i}
              position={[0.45 + Math.cos(a) * 0.13, 1.56, Math.sin(a) * 0.13]}
              rotation={[Math.cos(a) * 0.5, 0, Math.sin(a) * 0.5]}
              castShadow
            >
              <sphereGeometry args={[0.13, 10, 8]} />
              <meshStandardMaterial color="#2F7D4F" roughness={0.85} />
            </mesh>
          );
        })}
      </group>

      {/* ---------- hanging pendant lamps ---------- */}
      {[-1.9, 1.9].map((x, i) => (
        <group key={x} position={[x, 2.5, -2.2]}>
          <mesh position={[0, 0.8, 0]}>
            <cylinderGeometry args={[0.012, 0.012, 1.6, 6]} />
            <meshStandardMaterial color="#3A3352" roughness={0.6} />
          </mesh>
          <mesh castShadow>
            <coneGeometry args={[0.3, 0.34, 16, 1, true]} />
            <meshStandardMaterial color="#2A2142" roughness={0.5} metalness={0.6} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[0, -0.16, 0]}>
            <sphereGeometry args={[0.1, 12, 10]} />
            <meshStandardMaterial
              color="#FFF3C4"
              emissive={i === 0 ? "#FFD166" : "#7CFFCB"}
              emissiveIntensity={2.6}
              toneMapped={false}
            />
          </mesh>
          <pointLight
            position={[0, -0.4, 0]}
            intensity={6.5}
            distance={5.5}
            color={i === 0 ? "#FFD166" : "#7CFFCB"}
          />
        </group>
      ))}
    </group>
  );
}

/* ================================================================== */
/*  GYM — bench, weights and a mirror                                  */
/* ================================================================== */
export function GymEnv() {
  return (
    <group>
      <Floor color="#5A6472" />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.19, 0]} receiveShadow>
        <circleGeometry args={[2.6, 40]} />
        <meshStandardMaterial color="#3F4854" roughness={0.95} />
      </mesh>
      {/* mirror wall */}
      <mesh position={[0, 0.4, -2.6]} receiveShadow>
        <boxGeometry args={[6, 3.2, 0.14]} />
        <meshPhysicalMaterial
          color="#AFC6D6"
          roughness={0.08}
          metalness={0.7}
          clearcoat={1}
        />
      </mesh>
      {/* weight plates stacked */}
      {[-2.3, 2.3].map((x) => (
        <group key={x} position={[x, -1.2, -1]}>
          {[0, 1, 2].map((i) => (
            <mesh key={i} position={[0, 0.1 + i * 0.16, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
              <cylinderGeometry args={[0.3 - i * 0.04, 0.3 - i * 0.04, 0.14, 22]} />
              <meshStandardMaterial color="#2B3138" roughness={0.5} metalness={0.6} />
            </mesh>
          ))}
        </group>
      ))}
      {/* bench */}
      <group position={[1.5, -1.2, 0.9]} rotation={[0, -0.4, 0]}>
        <mesh position={[0, 0.42, 0]} castShadow receiveShadow>
          <boxGeometry args={[1.1, 0.14, 0.44]} />
          <meshStandardMaterial color="#B03A2E" roughness={0.7} />
        </mesh>
        {[-0.45, 0.45].map((x) => (
          <mesh key={x} position={[x, 0.2, 0]} castShadow>
            <boxGeometry args={[0.1, 0.4, 0.34]} />
            <meshStandardMaterial color="#2B3138" roughness={0.5} metalness={0.5} />
          </mesh>
        ))}
      </group>
    </group>
  );
}

/* ================================================================== */
/*  STREET — daytime sweeping job, trash falls from the sky            */
/* ================================================================== */
type Litter = {
  id: number;
  x: number;
  z: number;
  y: number;
  vy: number;
  kind: number;
  landed: boolean;
  landedAt: number;
  taken: boolean;
  takenAt: number;
};
const LITTER_COLORS = ["#E4572E", "#2F80ED", "#27AE60", "#F2C14E", "#9B59B6"];

export function StreetEnv() {
  const play = useStore((s) => s.play);
  const [items, setItems] = useState<Litter[]>([]);
  const next = useRef(0);
  const spawnAt = useRef(0);
  const active = !!play && !play.over;

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    const t = state.clock.elapsedTime;

    if (active && t > spawnAt.current && items.length < 8) {
      spawnAt.current = t + 0.55 + Math.random() * 0.45;
      setItems((prev) => [
        ...prev,
        {
          id: next.current++,
          x: -2.4 + Math.random() * 4.8,
          z: 0.2 + Math.random() * 1.8,
          y: 4 + Math.random() * 1.5,
          vy: 0,
          kind: Math.floor(Math.random() * LITTER_COLORS.length),
          landed: false,
          landedAt: 0,
          taken: false,
          takenAt: 0,
        },
      ]);
    }

    setItems((prev) => {
      if (!prev.length) return prev;
      let changed = false;
      const out: Litter[] = [];
      for (const it of prev) {
        if (it.taken) {
          const age = (performance.now() - it.takenAt) / 420;
          if (age >= 1) {
            changed = true;
            continue;
          }
          changed = true;
          // arc into Jeeko's broom
          out.push({ ...it, x: it.x * (1 - age), z: it.z * (1 - age), y: it.y + age * 1.1 });
          continue;
        }
        if (it.landed) {
          // litter blows away a few seconds after it lands
          if (t - it.landedAt > 5) {
            changed = true;
            continue;
          }
          out.push(it);
          continue;
        }
        const vy = it.vy - 7 * dt;
        const y = it.y + vy * dt;
        changed = true;
        out.push(
          y <= -1.05 ? { ...it, y: -1.05, vy: 0, landed: true, landedAt: t } : { ...it, y, vy },
        );
      }
      return changed ? out : prev;
    });
  });

  const grab = (id: number) => {
    setItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, taken: true, takenAt: performance.now() } : i)),
    );
    store.scorePlay(60);
    chirp(0.9);
  };

  return (
    <group>
      {/* road */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.2, 0]} receiveShadow>
        <planeGeometry args={[26, 7]} />
        <meshStandardMaterial color="#57606A" roughness={0.95} />
      </mesh>
      {/* lane dashes */}
      {Array.from({ length: 11 }).map((_, i) => (
        <mesh
          key={i}
          rotation={[-Math.PI / 2, 0, 0]}
          position={[-10 + i * 2, -1.19, -2.1]}
          receiveShadow
        >
          <planeGeometry args={[1.1, 0.16]} />
          <meshStandardMaterial color="#E8E4D9" roughness={0.85} />
        </mesh>
      ))}
      {/* sidewalk */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.16, 2.3]} receiveShadow>
        <planeGeometry args={[26, 2.4]} />
        <meshStandardMaterial color="#B8B2A4" roughness={0.95} />
      </mesh>
      {/* buildings behind */}
      {Array.from({ length: 9 }).map((_, i) => {
        const h = 2.4 + ((i * 37) % 5) * 0.8;
        return (
          <mesh key={i} position={[-8 + i * 2.1, -1.2 + h / 2, -5.2]} castShadow>
            <boxGeometry args={[1.7, h, 1.6]} />
            <meshStandardMaterial
              color={["#C9A88B", "#D9BFA0", "#B5977C", "#E0CBB0"][i % 4]}
              roughness={0.9}
            />
          </mesh>
        );
      })}
      {/* bins */}
      {[-3.6, 3.6].map((x) => (
        <group key={x} position={[x, -1.2, 1.4]}>
          <mesh position={[0, 0.34, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.3, 0.26, 0.68, 16]} />
            <meshStandardMaterial color="#2F7D4F" roughness={0.7} />
          </mesh>
          <mesh position={[0, 0.71, 0]} castShadow>
            <cylinderGeometry args={[0.33, 0.33, 0.07, 16]} />
            <meshStandardMaterial color="#25603D" roughness={0.65} />
          </mesh>
        </group>
      ))}

      {/* falling / landed litter */}
      {items.map((it) => (
        <group
          key={it.id}
          position={[it.x, it.y, it.z]}
          scale={it.taken ? Math.max(0.05, 1 - (performance.now() - it.takenAt) / 420) : 1}
          onPointerDown={(e) => {
            e.stopPropagation();
            if (!it.taken) grab(it.id);
          }}
          onPointerOver={() => (document.body.style.cursor = "pointer")}
          onPointerOut={() => (document.body.style.cursor = "auto")}
        >
          {/* generous transparent hit sphere (reliable for raycasting) */}
          <mesh>
            <sphereGeometry args={[0.62, 10, 8]} />
            <meshBasicMaterial transparent opacity={0} depthWrite={false} />
          </mesh>
          {/* soft glow so it reads as clickable */}
          <mesh scale={1.5}>
            <sphereGeometry args={[0.22, 12, 10]} />
            <meshBasicMaterial color="#FFF3C4" transparent opacity={0.22} depthWrite={false} />
          </mesh>
          <mesh castShadow rotation={[it.id * 0.7, it.id * 1.1, it.id * 0.4]}>
            <boxGeometry args={[0.3, 0.34, 0.24]} />
            <meshStandardMaterial color={LITTER_COLORS[it.kind]} roughness={0.6} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

/* ================================================================== */
/*  NIGHT — heist street with walking pedestrians + police car         */
/* ================================================================== */
type Walker = { id: number; x: number; dir: number; z: number; color: string; speed: number; taken: boolean };
const COATS = ["#4A5568", "#7B341E", "#2C5282", "#553C9A", "#285E61"];

function Pedestrian({
  w,
  onSteal,
}: {
  w: Walker;
  onSteal: (id: number) => void;
}) {
  const g = useRef<THREE.Group>(null);
  const legL = useRef<THREE.Mesh>(null);
  const legR = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const swing = Math.sin(t * 7 + w.id) * 0.5;
    if (legL.current) legL.current.rotation.x = swing;
    if (legR.current) legR.current.rotation.x = -swing;
    if (g.current) g.current.position.y = -1.2 + Math.abs(Math.sin(t * 7 + w.id)) * 0.04;
  });

  return (
    <group
      ref={g}
      position={[w.x, -1.2, w.z]}
      rotation={[0, w.dir > 0 ? Math.PI / 2 : -Math.PI / 2, 0]}
      onPointerDown={(e) => {
        e.stopPropagation();
        onSteal(w.id);
      }}
      onPointerOver={() => (document.body.style.cursor = "pointer")}
      onPointerOut={() => (document.body.style.cursor = "auto")}
    >
      {/* legs */}
      <mesh ref={legL} position={[0.09, 0.28, 0]} castShadow>
        <capsuleGeometry args={[0.07, 0.3, 4, 8]} />
        <meshStandardMaterial color="#2D3748" roughness={0.8} />
      </mesh>
      <mesh ref={legR} position={[-0.09, 0.28, 0]} castShadow>
        <capsuleGeometry args={[0.07, 0.3, 4, 8]} />
        <meshStandardMaterial color="#2D3748" roughness={0.8} />
      </mesh>
      {/* torso */}
      <mesh position={[0, 0.72, 0]} castShadow>
        <capsuleGeometry args={[0.19, 0.34, 6, 12]} />
        <meshStandardMaterial color={w.color} roughness={0.75} />
      </mesh>
      {/* head */}
      <mesh position={[0, 1.08, 0]} castShadow>
        <sphereGeometry args={[0.16, 18, 14]} />
        <meshStandardMaterial color="#E0B08B" roughness={0.7} />
      </mesh>
      {/* money bulge in the pocket */}
      <mesh position={[0.14, 0.62, 0.1]}>
        <boxGeometry args={[0.1, 0.12, 0.05]} />
        <meshStandardMaterial color="#5AA469" emissive="#2F6B3D" emissiveIntensity={0.5} roughness={0.6} />
      </mesh>
      {/* transparent hit capsule */}
      <mesh position={[0, 0.66, 0]}>
        <capsuleGeometry args={[0.42, 0.9, 4, 10]} />
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>
      {/* money glow marks them as a target */}
      <mesh position={[0.14, 0.62, 0.12]} scale={2.2}>
        <sphereGeometry args={[0.08, 10, 8]} />
        <meshBasicMaterial color="#8CF5A8" transparent opacity={0.25} depthWrite={false} />
      </mesh>
    </group>
  );
}

function PoliceCar({ show }: { show: boolean }) {
  const g = useRef<THREE.Group>(null);
  const light = useRef<THREE.Group>(null);
  const x = useRef(-11);

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    const t = state.clock.elapsedTime;
    x.current = THREE.MathUtils.damp(x.current, show ? 0.4 : -11, 2.2, dt);
    if (g.current) {
      g.current.position.x = x.current;
      g.current.visible = x.current > -10;
    }
    if (light.current) {
      light.current.children.forEach((c, i) => {
        const on = Math.sin(t * 9 + i * Math.PI) > 0;
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = on ? 3.4 : 0.15;
      });
    }
  });

  return (
    <group ref={g} position={[-11, -1.2, 2.1]} visible={false}>
      <mesh position={[0, 0.36, 0]} castShadow>
        <boxGeometry args={[1.9, 0.44, 0.84]} />
        <meshPhysicalMaterial color="#F2F4F7" roughness={0.3} metalness={0.4} clearcoat={0.8} />
      </mesh>
      <mesh position={[-0.1, 0.68, 0]} castShadow>
        <boxGeometry args={[0.95, 0.36, 0.78]} />
        <meshPhysicalMaterial color="#2C3E60" roughness={0.25} metalness={0.5} clearcoat={0.9} />
      </mesh>
      <group ref={light} position={[-0.1, 0.92, 0]}>
        <mesh position={[0.16, 0, 0]}>
          <boxGeometry args={[0.24, 0.11, 0.3]} />
          <meshStandardMaterial color="#E53E3E" emissive="#E53E3E" emissiveIntensity={2} />
        </mesh>
        <mesh position={[-0.16, 0, 0]}>
          <boxGeometry args={[0.24, 0.11, 0.3]} />
          <meshStandardMaterial color="#3182CE" emissive="#3182CE" emissiveIntensity={2} />
        </mesh>
      </group>
      {[-0.62, 0.62].map((wx) =>
        [-0.42, 0.42].map((wz) => (
          <mesh key={`${wx}${wz}`} position={[wx, 0.16, wz]} rotation={[Math.PI / 2, 0, 0]} castShadow>
            <cylinderGeometry args={[0.17, 0.17, 0.12, 14]} />
            <meshStandardMaterial color="#1A202C" roughness={0.85} />
          </mesh>
        )),
      )}
    </group>
  );
}

export function NightEnv() {
  const play = useStore((s) => s.play);
  const jailUntil = useStore((s) => s.jailUntil);
  const [walkers, setWalkers] = useState<Walker[]>([]);
  const [siren, setSiren] = useState(false);
  const next = useRef(0);
  const spawnAt = useRef(0);
  const active = !!play && !play.over && jailUntil < Date.now();

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    const t = state.clock.elapsedTime;

    if (active && t > spawnAt.current && walkers.length < 5) {
      spawnAt.current = t + 0.9 + Math.random() * 0.7;
      const dir = Math.random() < 0.5 ? 1 : -1;
      setWalkers((prev) => [
        ...prev,
        {
          id: next.current++,
          x: dir > 0 ? -6.5 : 6.5,
          dir,
          z: 1.0 + Math.random() * 1.2,
          color: COATS[Math.floor(Math.random() * COATS.length)],
          speed: 0.9 + Math.random() * 0.6,
          taken: false,
        },
      ]);
    }

    setWalkers((prev) => {
      if (!prev.length) return prev;
      const out = prev
        .map((w) => ({ ...w, x: w.x + w.dir * w.speed * dt }))
        .filter((w) => w.x > -7.5 && w.x < 7.5);
      return out;
    });
  });

  const steal = (id: number) => {
    const p = store.get().play;
    if (!p || p.over) return;
    setWalkers((prev) => prev.filter((w) => w.id !== id));
    const risk = Math.min(72, 5 + p.score * 6);
    if (Math.random() * 100 < risk) {
      setSiren(true);
      store.endPlay(false);
      window.setTimeout(() => {
        store.arrest(90);
        setSiren(false);
      }, 1600);
      return;
    }
    store.scorePlay(180 + Math.floor(Math.random() * 240));
    chirp(1);
  };

  const lamps = useMemo(() => [-4.5, -1.5, 1.5, 4.5], []);

  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.2, 0]} receiveShadow>
        <planeGeometry args={[30, 9]} />
        <meshStandardMaterial color="#2A3042" roughness={0.9} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.17, 1.6]} receiveShadow>
        <planeGeometry args={[30, 3]} />
        <meshStandardMaterial color="#3A4156" roughness={0.92} />
      </mesh>

      {/* night buildings with lit windows */}
      {Array.from({ length: 10 }).map((_, i) => {
        const h = 3 + ((i * 53) % 6) * 0.7;
        return (
          <group key={i} position={[-9 + i * 2, -1.2, -5]}>
            <mesh position={[0, h / 2, 0]} castShadow>
              <boxGeometry args={[1.6, h, 1.5]} />
              <meshStandardMaterial color="#1E2436" roughness={0.95} />
            </mesh>
            {Array.from({ length: 6 }).map((_, k) => (
              <mesh key={k} position={[-0.4 + (k % 2) * 0.8, 0.7 + Math.floor(k / 2) * 0.85, 0.77]}>
                <planeGeometry args={[0.32, 0.42]} />
                <meshStandardMaterial
                  color="#FFD98A"
                  emissive="#FFC15E"
                  emissiveIntensity={(i + k) % 3 === 0 ? 0.1 : 1.5}
                />
              </mesh>
            ))}
          </group>
        );
      })}

      {/* street lamps */}
      {lamps.map((x) => (
        <group key={x} position={[x, -1.2, -1.8]}>
          <mesh position={[0, 1.3, 0]} castShadow>
            <cylinderGeometry args={[0.05, 0.07, 2.6, 10]} />
            <meshStandardMaterial color="#2B3242" roughness={0.7} metalness={0.4} />
          </mesh>
          <mesh position={[0, 2.6, 0.2]}>
            <sphereGeometry args={[0.17, 14, 12]} />
            <meshStandardMaterial color="#FFE9B0" emissive="#FFD98A" emissiveIntensity={2.6} />
          </mesh>
          <pointLight position={[0, 2.5, 0.3]} intensity={6} distance={6} color="#FFD98A" />
        </group>
      ))}

      {walkers.map((w) => (
        <Pedestrian key={w.id} w={w} onSteal={steal} />
      ))}

      <PoliceCar show={siren || jailUntil > Date.now()} />
    </group>
  );
}

/* ================================================================== */
/*  JAIL — barred cell, the chick cannot leave until released          */
/* ================================================================== */
export function JailEnv() {
  return (
    <group>
      <Floor color="#4C4A46" />
      {/* back wall */}
      <mesh position={[0, 0.7, -2.4]} receiveShadow>
        <boxGeometry args={[7, 4, 0.3]} />
        <meshStandardMaterial color="#5C5A55" roughness={0.95} />
      </mesh>
      {/* brick lines */}
      {Array.from({ length: 7 }).map((_, i) => (
        <mesh key={i} position={[0, -0.9 + i * 0.52, -2.24]}>
          <boxGeometry args={[6.9, 0.03, 0.02]} />
          <meshStandardMaterial color="#46443F" roughness={1} />
        </mesh>
      ))}
      {/* barred window on the back wall */}
      <mesh position={[-1.9, 1.35, -2.2]}>
        <boxGeometry args={[1, 0.8, 0.08]} />
        <meshStandardMaterial color="#1C2530" roughness={0.9} />
      </mesh>
      {[-0.3, 0, 0.3].map((x) => (
        <mesh key={x} position={[-1.9 + x, 1.35, -2.14]}>
          <cylinderGeometry args={[0.035, 0.035, 0.8, 8]} />
          <meshStandardMaterial color="#8C929B" roughness={0.45} metalness={0.8} />
        </mesh>
      ))}

      {/* front cell bars */}
      <group position={[0, 0, 1.85]}>
        {Array.from({ length: 11 }).map((_, i) => (
          <mesh key={i} position={[-3 + i * 0.6, 0.55, 0]} castShadow>
            <cylinderGeometry args={[0.055, 0.055, 3.6, 12]} />
            <meshStandardMaterial color="#9BA3AD" roughness={0.4} metalness={0.85} />
          </mesh>
        ))}
        {[-1.05, 2.25].map((y) => (
          <mesh key={y} position={[0, y, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.07, 0.07, 6.4, 12]} />
            <meshStandardMaterial color="#8C929B" roughness={0.4} metalness={0.85} />
          </mesh>
        ))}
      </group>

      {/* bunk */}
      <group position={[2.1, -1.2, -1.2]} rotation={[0, -0.3, 0]}>
        <mesh position={[0, 0.5, 0]} castShadow receiveShadow>
          <boxGeometry args={[1.5, 0.12, 0.7]} />
          <meshStandardMaterial color="#6E6A62" roughness={0.85} />
        </mesh>
        <mesh position={[0, 0.62, 0]} castShadow>
          <boxGeometry args={[1.4, 0.14, 0.62]} />
          <meshStandardMaterial color="#8A8578" roughness={0.95} />
        </mesh>
        {[-0.64, 0.64].map((x) => (
          <mesh key={x} position={[x, 0.24, 0]}>
            <boxGeometry args={[0.08, 0.48, 0.62]} />
            <meshStandardMaterial color="#5A574F" roughness={0.8} metalness={0.3} />
          </mesh>
        ))}
      </group>

      {/* harsh overhead light */}
      <pointLight position={[0, 2.6, 0]} intensity={14} distance={9} color="#DCE6F0" />
      <spotLight
        position={[0, 3.2, 1]}
        angle={0.8}
        penumbra={0.7}
        intensity={18}
        distance={12}
        color="#C9D6E4"
        castShadow
      />
    </group>
  );
}
