import { useFrame, type ThreeEvent } from "@react-three/fiber";
import { useImperativeHandle, useMemo, useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { mergeVertices } from "three/examples/jsm/utils/BufferGeometryUtils.js";

type Poke = {
  x: number;
  y: number;
  z: number;
  t0: number;
  amp: number;
  s2: number; // spread squared
};

export type SoftBlobHandle = {
  /** Poke using a point in world space. */
  pokeWorld: (point: THREE.Vector3, amp?: number, spread?: number) => void;
  /** Poke using a direction in local space (will be projected on the surface). */
  pokeDir: (dir: THREE.Vector3, amp?: number, spread?: number) => void;
  mesh: THREE.Mesh | null;
};

type Props = {
  radius?: number;
  detail?: number;
  position?: [number, number, number];
  rotation?: [number, number, number];
  scale?: [number, number, number] | number;
  /** idle breathing / jelly wobble amplitude */
  idle?: number;
  /** default poke depth */
  depth?: number;
  /** default poke spread (how much of the surface reacts) */
  spread?: number;
  /** how fast the jelly settles down */
  damping?: number;
  /** oscillation speed of the jelly */
  springiness?: number;
  interactive?: boolean;
  onPoke?: (world: THREE.Vector3, strength: number) => void;
  children: ReactNode;
  ref?: RefObject<SoftBlobHandle | null>;
};

const MAX_POKES = 8;
const tmp = new THREE.Vector3();

/** Lighter meshes on phones / weak GPUs so the jelly stays at 60fps. */
const LOW_POWER =
  typeof window !== "undefined" &&
  (window.innerWidth < 768 || (navigator.hardwareConcurrency ?? 8) <= 4);

export function SoftBlob({
  radius = 1,
  detail = 12,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  scale = 1,
  idle = 0.012,
  depth = 0.3,
  spread = 0.55,
  damping = 3.2,
  springiness = 13,
  interactive = true,
  onPoke,
  children,
  ref,
}: Props) {
  const meshRef = useRef<THREE.Mesh>(null);
  const pokes = useRef<Poke[]>([]);
  const lastMove = useRef(0);
  const clockTime = useRef(0);

  const geometry = useMemo(() => {
    // icosahedron "detail" = edge subdivisions → faces = 20 * (detail + 1)^2
    const lod = LOW_POWER ? Math.max(5, Math.round(detail * 0.62)) : detail;
    const src = new THREE.IcosahedronGeometry(radius, lod);
    src.deleteAttribute("uv"); // weld every seam so the jelly stays perfectly smooth
    const g = mergeVertices(src);
    g.computeVertexNormals();
    g.computeBoundingSphere();
    if (g.boundingSphere) g.boundingSphere.radius *= 1.35;
    return g;
  }, [radius, detail]);

  const base = useMemo(
    () => Float32Array.from(geometry.attributes.position.array as ArrayLike<number>),
    [geometry],
  );

  const addPoke = (local: THREE.Vector3, amp: number, sp: number, time: number) => {
    const l = local.length() || 1;
    // project the poke point onto the rest-surface so it reads as a surface dent
    const p: Poke = {
      x: (local.x / l) * radius,
      y: (local.y / l) * radius,
      z: (local.z / l) * radius,
      t0: time,
      amp,
      s2: (sp * radius) * (sp * radius),
    };
    pokes.current.push(p);
    if (pokes.current.length > MAX_POKES) pokes.current.shift();
  };

  useImperativeHandle(ref, () => ({
    mesh: meshRef.current,
    pokeWorld(point, amp = depth, sp = spread) {
      const m = meshRef.current;
      if (!m) return;
      addPoke(m.worldToLocal(point.clone()), amp, sp, clockTime.current);
    },
    pokeDir(dir, amp = depth, sp = spread) {
      addPoke(tmp.copy(dir), amp, sp, clockTime.current);
    },
  }));

  const handleDown = (e: ThreeEvent<PointerEvent>) => {
    if (!interactive) return;
    e.stopPropagation();
    const m = meshRef.current;
    if (!m) return;
    addPoke(m.worldToLocal(e.point.clone()), depth, spread, clockTime.current);
    onPoke?.(e.point.clone(), 1);
  };

  const handleMove = (e: ThreeEvent<PointerEvent>) => {
    if (!interactive) return;
    if (e.buttons === 0 && e.pointerType === "mouse") return; // only while dragging with a mouse
    const now = clockTime.current;
    if (now - lastMove.current < 0.085) return;
    lastMove.current = now;
    e.stopPropagation();
    const m = meshRef.current;
    if (!m) return;
    addPoke(m.worldToLocal(e.point.clone()), depth * 0.5, spread * 0.85, now);
    onPoke?.(e.point.clone(), 0.45);
  };

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    clockTime.current = t;
    const mesh = meshRef.current;
    if (!mesh) return;

    const list = pokes.current;
    for (let i = list.length - 1; i >= 0; i--) {
      if (t - list[i].t0 > 2.6) list.splice(i, 1);
    }

    const attr = geometry.attributes.position as THREE.BufferAttribute;
    const arr = attr.array as Float32Array;
    const n = arr.length;

    // volume-preservation: pushing in somewhere makes the rest bulge out a touch
    let bulge = 0;
    for (let k = 0; k < list.length; k++) {
      const age = t - list[k].t0;
      bulge += list[k].amp * Math.exp(-damping * age) * Math.cos(age * springiness) * 0.22;
    }

    const idleA = idle * radius;

    for (let i = 0; i < n; i += 3) {
      const bx = base[i];
      const by = base[i + 1];
      const bz = base[i + 2];
      const len = Math.sqrt(bx * bx + by * by + bz * bz) || 1;
      const nx = bx / len;
      const ny = by / len;
      const nz = bz / len;

      // gentle idle jelly breathing
      let d =
        idleA *
        (Math.sin(bx * 2.3 + t * 1.45) * 0.6 +
          Math.cos(by * 2.9 - t * 1.15) * 0.5 +
          Math.sin(bz * 2.1 + t * 0.85) * 0.4);

      d += bulge;

      for (let k = 0; k < list.length; k++) {
        const p = list[k];
        const dx = bx - p.x;
        const dy = by - p.y;
        const dz = bz - p.z;
        const d2 = dx * dx + dy * dy + dz * dz;
        const fall = Math.exp(-d2 / p.s2);
        if (fall < 0.004) continue;
        const age = t - p.t0;
        d -= p.amp * fall * Math.exp(-damping * age) * Math.cos(age * springiness);
      }

      // keep the blob from ever folding through itself
      if (d < -0.52 * radius) d = -0.52 * radius;
      else if (d > 0.35 * radius) d = 0.35 * radius;

      arr[i] = bx + nx * d;
      arr[i + 1] = by + ny * d;
      arr[i + 2] = bz + nz * d;
    }

    attr.needsUpdate = true;
    geometry.computeVertexNormals();
  });

  return (
    <mesh
      ref={meshRef}
      geometry={geometry}
      position={position}
      rotation={rotation}
      scale={scale}
      castShadow
      receiveShadow
      onPointerDown={interactive ? handleDown : undefined}
      onPointerMove={interactive ? handleMove : undefined}
      onPointerOver={
        interactive
          ? () => {
              document.body.style.cursor = "grab";
            }
          : undefined
      }
      onPointerOut={
        interactive
          ? () => {
              document.body.style.cursor = "auto";
            }
          : undefined
      }
    >
      {children}
    </mesh>
  );
}
