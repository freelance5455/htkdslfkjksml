import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { SoftBlob, type SoftBlobHandle } from "./SoftBlob";
import { chirp, yawn } from "../lib/sound";
import { store, useStore, moodOf, isSleeping } from "../lib/store";
import { CATALOG, itemById } from "../lib/catalog";
import { Buddy, Glasses, Hat, Neck } from "./Accessories";
import { AngrySteam, Brows, FACE, HappyArcs, Sweat } from "./Face";
import {
  BurglarKit,
  HeldBroom,
  HeldDumbbell,
  HeldFood,
  HeldGun,
  HeldPhone,
  PrisonKit,
  SpaceHelmet,
} from "./Held";
import { WEAPONS } from "../lib/world";
import { Speech } from "./Speech";
import { Sleeve, Suit } from "./Suit";
import { Hand } from "./Arms";
import { demonTexture, galaxyTexture, holoTexture, neonTexture } from "./textures";

const BEAK = "#FF9412";
const FOOT = "#FB8B13";
const BLUSH = "#FF8E77";

/** Derives the body / highlight / wing shades from the equipped colour. */
const ANIMATED: Record<string, "galaxy" | "neon" | "demon" | "holo"> = {
  c_galaxy: "galaxy",
  c_neon: "neon",
  c_demon: "demon",
  c_holo: "holo",
};

function usePalette() {
  const colorId = useStore((s) => s.equipped.color);
  return useMemo(() => {
    const item = itemById(colorId) ?? CATALOG[0];
    const body = new THREE.Color(item.tint);
    const light = new THREE.Color(item.tint2 ?? item.tint);
    const wing = body.clone().multiplyScalar(0.88);
    return {
      body: `#${body.getHexString()}`,
      light: `#${light.getHexString()}`,
      wing: `#${wing.getHexString()}`,
      anim: ANIMATED[colorId ?? ""] ?? null,
      accent: item.tint2 ?? item.tint,
    };
  }, [colorId]);
}

/** Body skin: animated for legendary colours, plush otherwise. */
function Skin({ pal, tone }: { pal: ReturnType<typeof usePalette>; tone: "body" | "light" | "wing" }) {
  if (pal.anim) {
    return <AnimatedPlush kind={pal.anim} color={pal[tone]} accent={pal.accent} />;
  }
  return <PlushMaterial color={pal[tone]} rough={tone === "light" ? 0.7 : 0.68} />;
}

/** Legendary colours animate — the weave drifts and the glow breathes. */
function AnimatedPlush({
  kind,
  color,
  accent,
}: {
  kind: "galaxy" | "neon" | "demon" | "holo";
  color: string;
  accent: string;
}) {
  const mat = useRef<THREE.MeshPhysicalMaterial>(null);
  const tex = useMemo(() => {
    if (kind === "galaxy") return galaxyTexture();
    if (kind === "demon") return demonTexture();
    if (kind === "holo") return holoTexture();
    return neonTexture(color);
  }, [kind, color]);

  // each legendary finish gets its own animation character, not just a hue spin
  useFrame((state) => {
    const m = mat.current;
    if (!m) return;
    const t = state.clock.elapsedTime;

    if (m.map) {
      if (kind === "galaxy") {
        // slow parallax drift, like looking into deep space
        m.map.offset.x = (t * 0.017) % 1;
        m.map.offset.y = (t * 0.008) % 1;
        m.map.rotation = Math.sin(t * 0.08) * 0.12;
      } else if (kind === "demon") {
        // lava creeps upward and pulses
        m.map.offset.y = (-t * 0.035) % 1;
        m.map.offset.x = Math.sin(t * 0.4) * 0.02;
      } else if (kind === "holo") {
        m.map.offset.x = (t * 0.06) % 1;
      } else {
        m.map.offset.y = (-t * 0.09) % 1;
      }
    }

    switch (kind) {
      case "galaxy": {
        // stars twinkle; the nebula breathes
        const pulse = 0.55 + Math.sin(t * 0.9) * 0.18 + Math.sin(t * 2.7) * 0.06;
        m.emissiveIntensity = pulse;
        m.iridescenceIOR = 1.5 + Math.sin(t * 0.5) * 0.35;
        m.clearcoatRoughness = 0.18 + Math.sin(t * 0.7) * 0.08;
        break;
      }
      case "neon": {
        // travelling colour wave with a sharp crest, not a flat cycle
        const h = (t * 0.07) % 1;
        m.emissive.setHSL(h, 1, 0.58);
        m.color.setHSL((h + 0.5) % 1, 0.85, 0.42);
        m.emissiveIntensity = 1.3 + Math.pow(Math.max(0, Math.sin(t * 2.1)), 3) * 1.5;
        break;
      }
      case "demon": {
        // embers flare irregularly, like a fire
        const flare =
          Math.sin(t * 3.1) * 0.4 + Math.sin(t * 7.3) * 0.2 + Math.sin(t * 13.7) * 0.1;
        m.emissiveIntensity = 1.15 + flare;
        m.emissive.setHSL(0.035 + Math.sin(t * 1.7) * 0.012, 1, 0.5);
        break;
      }
      case "holo": {
        // the film shifts with view angle — driven by real iridescence
        m.iridescenceIOR = 1.7 + Math.sin(t * 0.9) * 0.6;
        m.iridescenceThicknessRange = [120, 420 + Math.sin(t * 1.3) * 260];
        m.emissiveIntensity = 0.3 + Math.sin(t * 1.6) * 0.14;
        break;
      }
    }
  });

  return (
    <meshPhysicalMaterial
      ref={mat}
      map={tex}
      emissiveMap={tex}
      emissive={accent}
      emissiveIntensity={0.8}
      roughness={kind === "holo" ? 0.12 : kind === "neon" ? 0.26 : 0.48}
      metalness={kind === "holo" ? 0.75 : kind === "galaxy" ? 0.42 : 0.24}
      clearcoat={kind === "demon" ? 0.2 : 0.85}
      clearcoatRoughness={kind === "holo" ? 0.05 : 0.22}
      iridescence={kind === "holo" || kind === "galaxy" ? 1 : 0}
      iridescenceIOR={1.8}
      iridescenceThicknessRange={[120, 480]}
      sheen={kind === "demon" ? 0.6 : 0.3}
      sheenColor={accent}
      envMapIntensity={1.45}
      toneMapped={kind === "neon" ? false : true}
    />
  );
}

/** Velvety plush look: soft sheen + a hint of clearcoat, no plastic hotspots. */
function PlushMaterial({ color, rough = 0.68 }: { color: string; rough?: number }) {
  return (
    <meshPhysicalMaterial
      color={color}
      roughness={rough}
      metalness={0}
      clearcoat={0.18}
      clearcoatRoughness={0.92}
      sheen={1}
      sheenRoughness={0.42}
      sheenColor="#FFF0C2"
      envMapIntensity={1.05}
    />
  );
}

export function Chick() {
  const pal = usePalette();
  const equipped = useStore((s) => s.equipped);
  const mood = useStore(moodOf);
  const world = useStore((s) => s.map);
  const eating = useStore((s) => s.eating);
  const repTick = useStore((s) => s.pet.reps + s.repsSinceFood * 100);
  const phone = useStore((s) => s.phone);
  const spinning = useStore((s) => s.wheel?.phase === "spinning");
  const offWorld = useStore((s) => s.map === "space" || s.map === "mars");
  const fighting = useStore((s) => s.mars?.phase === "fight");
  const gunColor = useStore(
    (s) => WEAPONS.find((w) => w.id === s.marsWeapon)?.color ?? "#4CC9F0",
  );
  const root = useRef<THREE.Group>(null);
  const bodyGroup = useRef<THREE.Group>(null);
  const headGroup = useRef<THREE.Group>(null);
  const wingL = useRef<THREE.Group>(null);
  const wingR = useRef<THREE.Group>(null);
  const eyeL = useRef<THREE.Group>(null);
  const eyeR = useRef<THREE.Group>(null);
  const beakUp = useRef<THREE.Mesh>(null);
  const beakDown = useRef<THREE.Mesh>(null);
  const tuft = useRef<THREE.Group>(null);

  const body = useRef<SoftBlobHandle>(null);
  const head = useRef<SoftBlobHandle>(null);

  const s = useRef({
    squash: 0,
    squashV: 0,
    hop: 0,
    hopV: 0,
    flap: 0,
    beak: 0,
    spin: 0,
    blinkAt: 2.5,
    blink: 0,
    yaw: 0,
    pitch: 0,
    sleep: 0,
    lean: 0,
    mouth: 0,
    lidT: 1,
    lift: 0,
    lastRep: -1,
    shake: 0,
    squint: 0,
    hold: 0,
    reachUp: 0,
  });

  const react = (strength: number, world?: THREE.Vector3, count = true) => {
    const st = s.current;
    const hard = strength >= 0.9;

    // a real tap runs the click-to-earn machine
    let accepted = true;
    if (hard && count) {
      const r = store.tap();
      accepted = r === "point" || r === "set";
      if (!accepted) st.shake = 1; // shake the head "no"
    } else {
      accepted = !isSleeping(store.get());
    }
    const k = accepted ? strength : strength * 0.14;

    st.squashV -= 9 * k;
    st.hopV += 5.5 * k;
    st.flap = Math.min(1.2, st.flap + k * 0.9);
    st.beak = Math.min(1, st.beak + k);
    if (world) st.spin += world.x * 0.05 * k;

    if (!accepted) {
      if (hard) yawn();
      return;
    }
    if (hard) {
      chirp(1);
      st.blinkAt = Math.min(st.blinkAt, 0.001); // happy squint
    } else if (Math.random() < 0.35) {
      chirp(0.5);
    }
  };

  const pokeBody = (world: THREE.Vector3, strength: number) => react(strength, world);

  /** Rigid details (beak, eyes, feet) forward their poke into the nearest soft part. */
  const forward = (target: "head" | "body") => (e: { point: THREE.Vector3; stopPropagation: () => void }) => {
    e.stopPropagation();
    const handle = target === "head" ? head.current : body.current;
    handle?.pokeWorld(e.point.clone(), 0.26, 0.6);
    react(1, e.point);
  };

  const lastTickle = useRef(0);

  useFrame((state, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    const t = state.clock.elapsedTime;
    const st = s.current;

    // the "tickle me" button in the UI pokes a random spot
    const shared = store.get();
    if (shared.tickles !== lastTickle.current) {
      lastTickle.current = shared.tickles;
      const dir = new THREE.Vector3(
        (Math.random() - 0.5) * 1.6,
        Math.random() * 0.9 - 0.25,
        0.55 + Math.random() * 0.7,
      ).normalize();
      if (Math.random() < 0.45) head.current?.pokeDir(dir, 0.24, 0.6);
      else body.current?.pokeDir(dir, 0.34, 0.58);
      react(0.55, undefined, false);
    }

    // --- timers / nap ---------------------------------------------------
    store.tick();
    const napping = isSleeping(shared);
    st.sleep = THREE.MathUtils.damp(st.sleep, napping ? 1 : 0, 2.6, dt);
    const awake = 1 - st.sleep;

    // --- expression + pose blending -------------------------------------
    const face = FACE[mood];
    st.lean = THREE.MathUtils.damp(st.lean, face.lean, 5, dt);
    st.mouth = THREE.MathUtils.damp(st.mouth, face.mouth, 7, dt);
    st.lidT = THREE.MathUtils.damp(st.lidT, face.lid, 8, dt);

    // one-shot dumbbell rep triggered from the UI
    if (repTick !== st.lastRep) {
      st.lastRep = repTick;
      if (world === "gym" && mood !== "angry") st.lift = 1;
    }
    st.lift = Math.max(0, st.lift - dt * 1.7);
    st.shake = Math.max(0, st.shake - dt * 1.25);
    // ease the lift into a smooth up-down curve
    const liftCurve = Math.sin(Math.min(1, 1 - st.lift) * Math.PI);

    // --- springs -------------------------------------------------------
    st.squashV = THREE.MathUtils.clamp(st.squashV + (-120 * st.squash - 9.5 * st.squashV) * dt, -13, 13);
    st.squash = THREE.MathUtils.clamp(st.squash + st.squashV * dt, -0.8, 0.8);
    st.hopV = THREE.MathUtils.clamp(st.hopV + (-70 * st.hop - 7 * st.hopV) * dt, -9, 9);
    st.hop = THREE.MathUtils.clamp(st.hop + st.hopV * dt, -1, 1);
    st.flap = THREE.MathUtils.damp(st.flap, 0, 2.6, dt);
    st.beak = THREE.MathUtils.damp(st.beak, 0, 3.4, dt);
    st.spin = THREE.MathUtils.damp(st.spin, 0, 2, dt);

    // --- look at the pointer -------------------------------------------
    const targetYaw = state.pointer.x * 0.42 + st.spin;
    const targetPitch = -state.pointer.y * 0.16;
    st.yaw = THREE.MathUtils.damp(st.yaw, targetYaw, 4, dt);
    st.pitch = THREE.MathUtils.damp(st.pitch, targetPitch, 4, dt);

    // slow, deep breathing while napping
    const breathe = Math.sin(t * (1.15 - st.sleep * 0.55)) * (0.045 + st.sleep * 0.05);

    if (root.current) {
      root.current.position.y =
        breathe + st.hop * 0.16 - st.sleep * 0.12 - liftCurve * 0.07;
      root.current.rotation.y = st.yaw * 0.55 * awake + Math.sin(t * 0.42) * 0.05;
      root.current.rotation.z = Math.sin(t * 0.63) * 0.02 + st.squash * 0.02 + st.sleep * 0.07;
      // lean forward when angry / back when proud
      root.current.rotation.x = st.lean + liftCurve * 0.1;
    }

    if (bodyGroup.current) {
      const sq = st.squash;
      const nap = st.sleep * 0.09;
      bodyGroup.current.scale.set(
        1 - sq * 0.14 + nap,
        1 + sq * 0.2 - nap * 1.2,
        1 - sq * 0.14 + nap,
      );
    }

    if (headGroup.current) {
      // secondary motion: the head lags behind the body squash; droops when asleep
      headGroup.current.rotation.x =
        st.pitch * 0.8 * awake -
        st.squash * 0.1 +
        Math.sin(t * 1.5) * 0.012 +
        st.sleep * 0.26 +
        st.hold * 0.3;
      // "no" head shake when Jeeko refuses a tap
      headGroup.current.rotation.y =
        st.yaw * 0.5 * awake + Math.sin(t * 22) * st.shake * 0.42;
      headGroup.current.rotation.z =
        Math.sin(t * 0.9) * 0.025 + st.squashV * 0.006 + st.sleep * 0.16;
      headGroup.current.position.y = 1.0 + st.squash * 0.08 - st.sleep * 0.1;
    }

    if (tuft.current) {
      tuft.current.rotation.z = Math.sin(t * 2.1) * 0.18 - st.squashV * 0.012;
      tuft.current.rotation.x = Math.cos(t * 1.7) * 0.12 + st.sleep * 0.5;
    }

    const flapAngle = st.flap * Math.sin(t * 24) * 0.85;
    const droop = st.sleep * 0.38;
    // gym: the right wing curls the dumbbell UP AND FORWARD (around X, not Z,
    // otherwise the weight sweeps sideways straight through the belly)
    const curl = liftCurve * 1.45;
    // phone: hold the wing up in front of the chest
    st.hold = THREE.MathUtils.damp(st.hold, phone ? 1 : 0, 6, dt);
    const holdArm = st.hold * 1.15;
    // wheel: reach up and give it a shove, then keep the wing raised
    st.reachUp = THREE.MathUtils.damp(st.reachUp, spinning ? 1 : 0, 5, dt);
    const shove = st.reachUp * (1.5 + Math.sin(t * 9) * 0.22);
    // angry: wings planted on the hips
    const hips = mood === "angry" ? 0.55 : 0;
    // eating: the left wing reaches out for the snack
    const reach = mood === "eating" ? 0.75 : 0;

    if (wingL.current) {
      wingL.current.rotation.z =
        0.22 + flapAngle + Math.sin(t * 1.3) * 0.05 - droop - hips - reach + shove;
      wingL.current.rotation.x = -st.flap * 0.2 - reach * 0.35 - st.reachUp * 0.3;
    }
    if (wingR.current) {
      // a small outward flare keeps the arm clear of the body while curling
      wingR.current.rotation.z =
        -0.22 - flapAngle - Math.sin(t * 1.3) * 0.05 + droop + hips + holdArm - curl * 0.16;
      wingR.current.rotation.x = -st.flap * 0.2 - curl - st.hold * 0.4;
    }

    if (beakUp.current && beakDown.current) {
      // slow sleepy breathing through the beak
      const snore = st.sleep * (0.5 + Math.sin(t * 1.1) * 0.5) * 0.3;
      // chewing while eating, strain-gape while lifting
      const chew = mood === "eating" ? (0.5 + Math.sin(t * 13) * 0.5) * 0.45 : 0;
      const open = st.mouth * 0.34 + chew + liftCurve * 0.3;
      beakUp.current.rotation.x = Math.PI / 2 - 0.07 - st.beak * 0.3 - snore * 0.4 - open * 0.45;
      beakDown.current.rotation.x = Math.PI / 2 + 0.1 + st.beak * 0.34 + snore + open;
    }

    // --- blinking -------------------------------------------------------
    st.blinkAt -= dt;
    if (st.blinkAt <= 0) {
      st.blink = 0.16;
      st.blinkAt = 2.4 + Math.random() * 3.6;
    }
    st.blink = Math.max(0, st.blink - dt);
    const lidScale = st.blink > 0 ? 0.12 : st.lidT;
    // only a genuine impact squints, and only briefly — the body keeps
    // wobbling long after a tap, so reading |squash| directly left the eyes
    // permanently half-shut
    st.squint = Math.max(0, st.squint - dt * 3.4);
    if (st.squashV < -5) st.squint = 1;
    const squint = 1 - st.squint * 0.42;
    // happy arcs replace the pupils, so shrink them away for that mood
    const hidden = FACE[mood].arc > 0.5 ? 0.08 : 1;
    const eyeY = THREE.MathUtils.lerp(lidScale * squint * hidden, 0.08, st.sleep);
    if (eyeL.current) eyeL.current.scale.y = THREE.MathUtils.damp(eyeL.current.scale.y, eyeY, 22, dt);
    if (eyeR.current) eyeR.current.scale.y = THREE.MathUtils.damp(eyeR.current.scale.y, eyeY, 22, dt);
  });

  return (
    <group ref={root} position={[0, -0.05, 0]} dispose={null}>
      <group ref={bodyGroup}>
        {/* ---------------- body ---------------- */}
        <SoftBlob
          ref={body}
          radius={1}
          detail={16}
          scale={[1, 0.96, 0.94]}
          depth={0.3}
          spread={0.52}
          idle={0.014}
          onPoke={pokeBody}
        >
          <Skin pal={pal} tone="body" />
        </SoftBlob>

        {/* equipped body gear */}
        {world !== "jail" && world !== "night" && <Suit id={equipped.suit} />}
        {world !== "jail" && <Neck id={equipped.neck} />}
        {world === "home" && <Buddy id={equipped.buddy} />}

        {/* job outfits */}
        <BurglarKit show={world === "night"} />
        <PrisonKit show={world === "jail"} />

        {/* sweat / steam reactions */}
        <Sweat mood={mood} />
        <AngrySteam mood={mood} />

        {/* ---------------- tail ---------------- */}
        <mesh position={[0, 0.36, -0.88]} rotation={[-0.55, 0, 0]} onPointerDown={forward("body")}>
          <sphereGeometry args={[0.26, 24, 18]} />
          <meshPhysicalMaterial color={pal.wing} roughness={0.7} sheen={1} sheenColor="#FFF0B8" />
        </mesh>

        {/* ---------------- wings ---------------- */}
        <group ref={wingL} position={[0.85, 0.07, 0.02]}>
          <SoftBlob
            radius={0.44}
            detail={9}
            position={[0.16, -0.1, 0]}
            scale={[0.45, 1.02, 0.72]}
            depth={0.22}
            spread={0.62}
            idle={0.02}
            onPoke={pokeBody}
          >
            <Skin pal={pal} tone="light" />
          </SoftBlob>

          {/* sleeve rides the wing so it bends with it */}
          {world !== "jail" && world !== "night" && <Sleeve id={equipped.suit} side={1} />}
          <Hand side={1} color={pal.light} cuff={equipped.suit} />

          {/* the fight is shown side-on, so the blaster rides the wing that
              faces the camera — otherwise it hides behind the body */}
          <HeldGun show={!!fighting} color={gunColor} flip />
        </group>
        <group ref={wingR} position={[-0.85, 0.07, 0.02]}>
          <SoftBlob
            radius={0.44}
            detail={9}
            position={[-0.16, -0.1, 0]}
            scale={[0.45, 1.02, 0.72]}
            depth={0.22}
            spread={0.62}
            idle={0.02}
            onPoke={pokeBody}
          >
            <Skin pal={pal} tone="light" />
          </SoftBlob>

          {world !== "jail" && world !== "night" && <Sleeve id={equipped.suit} side={-1} />}
          <Hand side={-1} color={pal.light} cuff={equipped.suit} />

          {/* tools gripped by the right wing */}
          <HeldDumbbell show={world === "gym"} />
          <HeldBroom show={world === "street"} />
          <HeldPhone show={!!phone} lit={phone === "open"} />
        </group>

        {/* ---------------- head ---------------- */}
        <group ref={headGroup} position={[0, 1.0, 0.04]}>
          <SoftBlob
            ref={head}
            radius={0.64}
            detail={14}
            scale={[1, 0.97, 0.99]}
            depth={0.2}
            spread={0.5}
            idle={0.012}
            onPoke={pokeBody}
          >
            <Skin pal={pal} tone="light" />
          </SoftBlob>

          {/* tuft of hair */}
          <group ref={tuft} position={[0, 0.55, -0.02]}>
            <mesh position={[0, 0.1, 0]} onPointerDown={forward("head")}>
              <sphereGeometry args={[0.075, 16, 12]} />
              <meshPhysicalMaterial color={pal.body} roughness={0.65} sheen={1} />
            </mesh>
            <mesh position={[0.035, 0.21, -0.07]}>
              <sphereGeometry args={[0.058, 16, 12]} />
              <meshPhysicalMaterial color={pal.body} roughness={0.65} sheen={1} />
            </mesh>
            <mesh position={[0.085, 0.3, -0.17]}>
              <sphereGeometry args={[0.042, 14, 10]} />
              <meshPhysicalMaterial color={pal.body} roughness={0.65} sheen={1} />
            </mesh>
          </group>

          {/* eyes */}
          <group ref={eyeL} position={[0.215, 0.12, 0.575]}>
            <mesh onPointerDown={forward("head")}>
              <sphereGeometry args={[0.088, 24, 18]} />
              <meshPhysicalMaterial color="#2A1806" roughness={0.08} clearcoat={1} clearcoatRoughness={0.05} />
            </mesh>
            <mesh position={[0.034, 0.04, 0.072]}>
              <sphereGeometry args={[0.031, 14, 12]} />
              <meshBasicMaterial color="#ffffff" />
            </mesh>
            <mesh position={[-0.036, -0.036, 0.072]}>
              <sphereGeometry args={[0.016, 12, 10]} />
              <meshBasicMaterial color="#ffffff" />
            </mesh>
          </group>
          <group ref={eyeR} position={[-0.215, 0.12, 0.575]}>
            <mesh onPointerDown={forward("head")}>
              <sphereGeometry args={[0.088, 24, 18]} />
              <meshPhysicalMaterial color="#2A1806" roughness={0.08} clearcoat={1} clearcoatRoughness={0.05} />
            </mesh>
            <mesh position={[0.034, 0.04, 0.072]}>
              <sphereGeometry args={[0.031, 14, 12]} />
              <meshBasicMaterial color="#ffffff" />
            </mesh>
            <mesh position={[-0.036, -0.036, 0.072]}>
              <sphereGeometry args={[0.016, 12, 10]} />
              <meshBasicMaterial color="#ffffff" />
            </mesh>
          </group>

          {/* blush */}
          <mesh position={[0.404, -0.07, 0.489]} rotation={[0, 0.55, 0]} scale={[1, 0.68, 0.28]}>
            <sphereGeometry args={[0.125, 18, 14]} />
            <meshBasicMaterial color={BLUSH} transparent opacity={0.38} depthWrite={false} />
          </mesh>
          <mesh position={[-0.404, -0.07, 0.489]} rotation={[0, -0.55, 0]} scale={[1, 0.68, 0.28]}>
            <sphereGeometry args={[0.125, 18, 14]} />
            <meshBasicMaterial color={BLUSH} transparent opacity={0.38} depthWrite={false} />
          </mesh>

          {/* pressure dome worn in space and on Mars */}
          <SpaceHelmet show={offWorld} />

          {/* facial expression layers */}
          <Brows mood={mood} />
          <HappyArcs mood={mood} />

          {/* equipped head gear (hidden while a job outfit is on) */}
          {world !== "night" && world !== "jail" && (
            <>
              <Hat id={equipped.hat} />
              <Glasses id={equipped.glasses} />
            </>
          )}

          {/* beak */}
          <group position={[0, -0.05, 0.58]}>
            <mesh ref={beakUp} position={[0, 0.035, 0.05]} rotation={[Math.PI / 2, 0, 0]} onPointerDown={forward("head")}>
              <coneGeometry args={[0.135, 0.26, 20]} />
              <meshPhysicalMaterial color={BEAK} roughness={0.35} clearcoat={0.6} />
            </mesh>
            <mesh ref={beakDown} position={[0, -0.035, 0.045]} rotation={[Math.PI / 2, 0, 0]} onPointerDown={forward("head")}>
              <coneGeometry args={[0.115, 0.21, 20]} />
              <meshPhysicalMaterial color="#E5761A" roughness={0.4} clearcoat={0.5} />
            </mesh>
          </group>
        </group>
      </group>

      <Speech />

      {/* snack flying up to the beak */}
      <HeldFood emoji={eating?.emoji ?? null} startedAt={eating?.at ?? 0} />

      {/* ---------------- feet ---------------- */}
      {[-1, 1].map((side) => (
        <group key={side} position={[side * 0.32, -0.96, 0.18]} rotation={[0, side * 0.16, 0]}>
          <mesh position={[0, 0.06, 0]} onPointerDown={forward("body")}>
            <cylinderGeometry args={[0.055, 0.06, 0.16, 12]} />
            <meshStandardMaterial color={FOOT} roughness={0.45} />
          </mesh>
          {[-0.42, 0, 0.42].map((a, i) => (
            <group key={i} rotation={[0, a, 0]}>
              <mesh position={[0, -0.025, 0.1]} rotation={[Math.PI / 2, 0, 0]}>
                <capsuleGeometry args={[0.036, 0.14, 4, 10]} />
                <meshStandardMaterial color={FOOT} roughness={0.45} />
              </mesh>
            </group>
          ))}
        </group>
      ))}
    </group>
  );
}
