import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { store, useStore } from "../lib/store";
import { SEGMENTS, SEG_ANGLE, SEG_COUNT } from "../lib/wheel";
import { useLayout } from "../lib/layout";
import { Chick } from "./Chick";
import { boop } from "../lib/sound";

const WHEEL_R = 1.9;
const SPIN_MS = 5200;

/** cubic ease-out — fast launch, long glide, soft stop */
const ease = (p: number) => 1 - Math.pow(1 - p, 3.2);

/* ================================================================== */
/*  wheel face texture — wedges, labels, studs                         */
/* ================================================================== */
function useWheelTexture() {
  return useMemo(() => {
    const S = 2048; // high res so the labels stay sharp up close
    const c = document.createElement("canvas");
    c.width = c.height = S;
    const ctx = c.getContext("2d")!;
    const mid = S / 2;
    const R = S / 2 - 14;

    ctx.clearRect(0, 0, S, S);

    SEGMENTS.forEach((seg, i) => {
      const a0 = i * SEG_ANGLE - Math.PI / 2;
      const a1 = a0 + SEG_ANGLE;

      ctx.beginPath();
      ctx.moveTo(mid, mid);
      ctx.arc(mid, mid, R, a0, a1);
      ctx.closePath();

      // flat, saturated wedge — no dark falloff, so text always has contrast
      ctx.fillStyle = seg.color;
      ctx.fill();

      // subtle inner shading only near the hub, never behind the label
      const g = ctx.createRadialGradient(mid, mid, 0, mid, mid, R);
      g.addColorStop(0, "rgba(0,0,0,0.45)");
      g.addColorStop(0.3, "rgba(0,0,0,0.08)");
      g.addColorStop(1, "rgba(255,255,255,0.07)");
      ctx.fillStyle = g;
      ctx.fill();

      // crisp divider
      ctx.strokeStyle = "rgba(255,255,255,0.9)";
      ctx.lineWidth = 5;
      ctx.stroke();

      /* ---- label: always upright, dark plate behind it ---- */
      const am = a0 + SEG_ANGLE / 2;
      const lr = R * 0.66;
      const lx = mid + Math.cos(am) * lr;
      const ly = mid + Math.sin(am) * lr;

      ctx.save();
      ctx.translate(lx, ly);
      // rotate to face outward, flipping on the lower half so nothing is upside-down
      let rot = am + Math.PI / 2;
      const deg = ((rot * 180) / Math.PI) % 360;
      if (deg > 90 && deg < 270) rot += Math.PI;
      ctx.rotate(rot);

      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      // rounded dark plate guarantees legibility on every wedge colour
      const pw = 250;
      const ph = 132;
      ctx.fillStyle = "rgba(8,10,18,0.72)";
      ctx.beginPath();
      ctx.roundRect(-pw / 2, -ph / 2, pw, ph, 26);
      ctx.fill();
      ctx.strokeStyle = seg.glow;
      ctx.lineWidth = 4;
      ctx.stroke();

      ctx.font = "700 64px ui-sans-serif, system-ui, sans-serif";
      ctx.fillStyle = "#ffffff";
      ctx.fillText(seg.emoji, 0, -30);

      ctx.font = "900 46px Vazirmatn, ui-sans-serif, system-ui, sans-serif";
      ctx.fillStyle = "#ffffff";
      ctx.fillText(seg.short, 0, 36);
      ctx.restore();
    });

    // outer rim
    ctx.beginPath();
    ctx.arc(mid, mid, R, 0, Math.PI * 2);
    ctx.strokeStyle = "#FFD166";
    ctx.lineWidth = 20;
    ctx.stroke();

    // hub
    ctx.beginPath();
    ctx.arc(mid, mid, R * 0.15, 0, Math.PI * 2);
    ctx.fillStyle = "#12161F";
    ctx.fill();
    ctx.strokeStyle = "#FFD166";
    ctx.lineWidth = 10;
    ctx.stroke();

    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 16;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.magFilter = THREE.LinearFilter;
    return tex;
  }, []);
}

/* ================================================================== */
/*  the wheel                                                          */
/* ================================================================== */
function Wheel() {
  const phase = useStore((s) => s.wheel?.phase ?? "idle");
  const target = useStore((s) => s.wheel?.target ?? 0);
  const startedAt = useStore((s) => s.wheel?.startedAt ?? 0);

  const disc = useRef<THREE.Group>(null);
  const pointer = useRef<THREE.Group>(null);
  const tex = useWheelTexture();

  const from = useRef(0);
  const settled = useRef(true);
  const lastTick = useRef(0);

  // remember where the wheel stopped so the next spin continues smoothly
  useEffect(() => {
    if (phase === "spinning") {
      from.current = disc.current?.rotation.z ?? 0;
      settled.current = false;
    }
  }, [phase, startedAt]);

  useEffect(() => () => tex.dispose(), [tex]);

  useFrame((state) => {
    const d = disc.current;
    if (!d) return;
    const t = state.clock.elapsedTime;

    if (phase === "spinning") {
      const p = Math.min(1, (Date.now() - startedAt) / SPIN_MS);
      d.rotation.z = from.current + (target - from.current) * ease(p);

      // pointer flicks as each stud passes
      const idx = Math.floor(d.rotation.z / SEG_ANGLE);
      if (idx !== lastTick.current) {
        lastTick.current = idx;
        if (pointer.current) pointer.current.rotation.z = 0.42;
        if (p < 0.96) boop();
      }

      if (p >= 1 && !settled.current) {
        settled.current = true;
        store.settleWheel();
      }
    } else {
      // gentle idle drift
      d.rotation.z += 0.0016;
    }

    if (pointer.current) {
      pointer.current.rotation.z = THREE.MathUtils.damp(pointer.current.rotation.z, 0, 12, 1 / 60);
    }
    void t;
  });

  const studs = useMemo(() => Array.from({ length: SEG_COUNT }, (_, i) => i), []);

  return (
    <group position={[0, 0.55, -0.6]}>
      {/* back plate glow */}
      <mesh position={[0, 0, -0.22]}>
        <circleGeometry args={[WHEEL_R * 1.14, 48]} />
        <meshStandardMaterial color="#120A26" emissive="#3B1D6E" emissiveIntensity={0.9} />
      </mesh>

      {/* spinning disc */}
      <group ref={disc}>
        {/* rotated so the cylinder axis points at the camera */}
        <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[WHEEL_R, WHEEL_R, 0.16, 64]} />
          <meshStandardMaterial color="#0B0E18" roughness={0.6} metalness={0.4} />
        </mesh>
        {/* printed face — circleGeometry already faces +Z */}
        <mesh position={[0, 0, 0.085]}>
          <circleGeometry args={[WHEEL_R, 64]} />
          <meshStandardMaterial
            map={tex}
            roughness={0.5}
            metalness={0.05}
            toneMapped={false}
          />
        </mesh>
        {/* rim studs */}
        {studs.map((i) => {
          const a = i * SEG_ANGLE;
          return (
            <mesh key={i} position={[Math.cos(a) * WHEEL_R, Math.sin(a) * WHEEL_R, 0.1]}>
              <sphereGeometry args={[0.055, 10, 8]} />
              <meshStandardMaterial
                color="#FFF3C4"
                emissive="#FFD166"
                emissiveIntensity={2.4}
                toneMapped={false}
              />
            </mesh>
          );
        })}
        {/* hub cap */}
        <mesh position={[0, 0, 0.12]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.2, 0.2, 0.12, 20]} />
          <meshStandardMaterial color="#FFD166" roughness={0.2} metalness={1} />
        </mesh>
      </group>

      {/* fixed pointer at the top */}
      <group ref={pointer} position={[0, WHEEL_R + 0.12, 0.16]}>
        <mesh rotation={[0, 0, Math.PI]} castShadow>
          <coneGeometry args={[0.14, 0.42, 16]} />
          <meshStandardMaterial
            color="#FF4D6D"
            emissive="#FF4D6D"
            emissiveIntensity={1.4}
            roughness={0.25}
            metalness={0.6}
          />
        </mesh>
        <mesh position={[0, 0.16, 0]}>
          <sphereGeometry args={[0.1, 14, 12]} />
          <meshStandardMaterial color="#FFE9A8" emissive="#FFD166" emissiveIntensity={2} />
        </mesh>
      </group>

      {/* stand */}
      <mesh position={[0, -WHEEL_R - 0.7, -0.1]} castShadow>
        <cylinderGeometry args={[0.14, 0.22, 1.4, 14]} />
        <meshStandardMaterial color="#2A2F3E" roughness={0.4} metalness={0.7} />
      </mesh>
      <mesh position={[0, -WHEEL_R - 1.36, -0.1]} receiveShadow>
        <cylinderGeometry args={[0.7, 0.85, 0.14, 22]} />
        <meshStandardMaterial color="#1B1F2C" roughness={0.5} metalness={0.6} />
      </mesh>
    </group>
  );
}

/* ================================================================== */
/*  neon arcade                                                        */
/* ================================================================== */
function Arcade() {
  const tubes = useRef<THREE.MeshStandardMaterial[]>([]);
  const bulbs = useRef<THREE.Group>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    tubes.current.forEach((m, i) => {
      if (m) m.emissiveIntensity = 2.1 + Math.sin(t * 2 + i * 1.3) * 0.85;
    });
    if (bulbs.current) {
      bulbs.current.children.forEach((c, i) => {
        const on = Math.sin(t * 4 + i * 0.55) > -0.2;
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = on ? 2.6 : 0.2;
      });
    }
  });

  const neonColors = ["#FF2D95", "#00E5FF", "#FFD166", "#7CFFCB", "#C77DFF"];

  return (
    <group>
      {/* floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.2, 0]} receiveShadow>
        <circleGeometry args={[20, 48]} />
        <meshStandardMaterial color="#140C24" roughness={0.42} metalness={0.5} />
      </mesh>
      {/* glowing floor rings */}
      {[2.6, 4.2, 5.8].map((r, i) => (
        <mesh key={r} rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.19, 0]}>
          <ringGeometry args={[r, r + 0.06, 56]} />
          <meshStandardMaterial
            color={neonColors[i % neonColors.length]}
            emissive={neonColors[i % neonColors.length]}
            emissiveIntensity={1.6}
            toneMapped={false}
          />
        </mesh>
      ))}

      {/* back wall */}
      <mesh position={[0, 1.6, -4.4]} receiveShadow>
        <boxGeometry args={[18, 7, 0.3]} />
        <meshStandardMaterial color="#120E22" roughness={0.75} />
      </mesh>

      {/* neon tubes on the wall */}
      {[-5.4, -3.8, 3.8, 5.4].map((x, i) => (
        <mesh key={x} position={[x, 1.5, -4.2]}>
          <boxGeometry args={[0.12, 4.4, 0.12]} />
          <meshStandardMaterial
            ref={(m) => {
              if (m) tubes.current[i] = m;
            }}
            color={neonColors[i % neonColors.length]}
            emissive={neonColors[i % neonColors.length]}
            emissiveIntensity={2}
            toneMapped={false}
          />
        </mesh>
      ))}

      {/* marquee arch of bulbs over the wheel */}
      <group ref={bulbs}>
        {Array.from({ length: 17 }).map((_, i) => {
          const a = Math.PI * (0.08 + (i / 16) * 0.84);
          return (
            <mesh key={i} position={[Math.cos(a) * 3.5, 0.6 + Math.sin(a) * 3.1, -3.4]}>
              <sphereGeometry args={[0.09, 10, 8]} />
              <meshStandardMaterial
                color="#FFF3C4"
                emissive="#FFD166"
                emissiveIntensity={2.4}
                toneMapped={false}
              />
            </mesh>
          );
        })}
      </group>

      {/* side arcade cabinets */}
      {[-4.6, 4.6].map((x) => (
        <group key={x} position={[x, -1.2, -2.2]} rotation={[0, x > 0 ? -0.5 : 0.5, 0]}>
          <mesh position={[0, 0.9, 0]} castShadow>
            <boxGeometry args={[1.1, 1.8, 0.8]} />
            <meshStandardMaterial color="#1C1533" roughness={0.55} metalness={0.35} />
          </mesh>
          <mesh position={[0, 1.3, 0.42]} rotation={[-0.18, 0, 0]}>
            <planeGeometry args={[0.8, 0.6]} />
            <meshStandardMaterial
              color="#2AF5FF"
              emissive="#00E5FF"
              emissiveIntensity={1.5}
              toneMapped={false}
            />
          </mesh>
          <mesh position={[0, 1.86, 0]}>
            <boxGeometry args={[1.16, 0.12, 0.86]} />
            <meshStandardMaterial
              color="#FF2D95"
              emissive="#FF2D95"
              emissiveIntensity={1.8}
              toneMapped={false}
            />
          </mesh>
        </group>
      ))}

      {/* accent lights */}
      <pointLight position={[0, 2.4, 1.6]} intensity={20} distance={12} color="#C77DFF" />
      <pointLight position={[-3.4, 0.6, 1.2]} intensity={11.5} distance={8.5} color="#00E5FF" />
      <pointLight position={[3.4, 0.6, 1.2]} intensity={11.5} distance={8.5} color="#FF2D95" />
    </group>
  );
}

/* ================================================================== */
/*  confetti on a win                                                  */
/* ================================================================== */
function Confetti({ on }: { on: boolean }) {
  const g = useRef<THREE.Group>(null);
  const bits = useMemo(
    () =>
      Array.from({ length: 60 }, () => ({
        x: (Math.random() - 0.5) * 6,
        y: 2 + Math.random() * 3,
        z: -1 + Math.random() * 2.4,
        vy: -1.2 - Math.random() * 1.6,
        rot: Math.random() * 6,
        spin: (Math.random() - 0.5) * 6,
        c: ["#FF2D95", "#00E5FF", "#FFD166", "#7CFFCB", "#C77DFF"][
          Math.floor(Math.random() * 5)
        ],
      })),
    [],
  );
  const started = useRef(0);

  useEffect(() => {
    if (on) started.current = performance.now();
  }, [on]);

  useFrame((_, rawDelta) => {
    const dt = Math.min(rawDelta, 1 / 30);
    if (!g.current) return;
    g.current.visible = on;
    if (!on) return;
    const age = (performance.now() - started.current) / 1000;
    g.current.children.forEach((c, i) => {
      const b = bits[i];
      const y = b.y + b.vy * age;
      c.position.set(b.x + Math.sin(age * 2 + i) * 0.3, y, b.z);
      c.rotation.z = b.rot + b.spin * age;
      c.visible = y > -1.2;
    });
    void dt;
  });

  return (
    <group ref={g} visible={false}>
      {bits.map((b, i) => (
        <mesh key={i}>
          <planeGeometry args={[0.11, 0.16]} />
          <meshStandardMaterial
            color={b.c}
            emissive={b.c}
            emissiveIntensity={1.2}
            side={THREE.DoubleSide}
            toneMapped={false}
          />
        </mesh>
      ))}
    </group>
  );
}

/* ================================================================== */
/*  root                                                               */
/* ================================================================== */
export function WheelScene() {
  const phase = useStore((s) => s.wheel?.phase ?? "idle");
  const prize = useStore((s) => s.wheel?.prize ?? null);
  const { size, camera } = useThree();
  const hud = useLayout();

  const chick = useRef<THREE.Group>(null);
  const armAt = useRef(0);
  const spinning = phase === "spinning";

  useEffect(() => {
    if (spinning) armAt.current = performance.now();
  }, [spinning]);

  // celebration hop once a prize is revealed
  useFrame((state) => {
    if (!chick.current) return;
    const t = state.clock.elapsedTime;
    if (phase === "result" && prize && prize.kind !== "nothing") {
      chick.current.position.y = Math.abs(Math.sin(t * 7.5)) * 0.34;
      chick.current.rotation.z = Math.sin(t * 7.5) * 0.12;
    } else {
      chick.current.position.y = THREE.MathUtils.damp(chick.current.position.y, 0, 6, 1 / 60);
      chick.current.rotation.z = THREE.MathUtils.damp(chick.current.rotation.z, 0, 6, 1 / 60);
    }
  });

  // frame the wheel + chick inside the measured free space
  const frame = useMemo(() => {
    const fov = "fov" in camera ? (camera.fov as number) : 40;
    const dist = camera.position.length() || 5.1;
    const worldH = 2 * Math.tan((fov * Math.PI) / 360) * dist;
    const worldW = worldH * (size.width / Math.max(1, size.height));
    const pxPerUnit = size.height / worldH;

    const topUI = hud.top + 8;
    const bottomUI = hud.bottom + 8;
    const freePx = Math.max(120, size.height - topUI - bottomUI);
    const centerPx = (topUI + (size.height - bottomUI)) / 2;
    const centerY = (size.height / 2 - centerPx) / pxPerUnit;

    // the composition is ~6.6 units tall and ~7 wide
    const scale = THREE.MathUtils.clamp(
      Math.min(freePx / pxPerUnit / 6.6, worldW / 7.4),
      0.22,
      0.7,
    );
    return { scale, centerY };
  }, [size.width, size.height, hud.top, hud.bottom, camera]);

  return (
    <group position={[0, frame.centerY - 0.35, 0]} scale={frame.scale}>
      <Arcade />
      <Wheel />
      <Confetti on={phase === "result" && !!prize && prize.kind !== "nothing"} />

      {/* Jeeko stands to the side, reaching up to the wheel while it spins */}
      <group ref={chick} position={[2.5, -0.1, 1.1]} rotation={[0, -0.42, 0]}>
        <Chick />
      </group>
    </group>
  );
}
