import * as THREE from 'three';
import { STACK_ITEMS_CATALOG } from '../data/disciplines';

function createOakFloorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#C88D54';
  ctx.fillRect(0, 0, 512, 512);

  // Draw warm wood planks and grain matching the photo floor
  const plankCount = 8;
  const plankH = 512 / plankCount;
  for (let i = 0; i < plankCount; i++) {
    const y = i * plankH;
    ctx.fillStyle = i % 2 === 0 ? '#C68B53' : '#BA7E46';
    ctx.fillRect(0, y, 512, plankH - 2);

    // Subtle wood grain lines
    ctx.strokeStyle = 'rgba(110, 62, 24, 0.18)';
    ctx.lineWidth = 2;
    for (let g = 0; g < 10; g++) {
      const gy = y + 4 + Math.random() * (plankH - 8);
      ctx.beginPath();
      ctx.moveTo(0, gy);
      ctx.bezierCurveTo(170, gy + (Math.random() - 0.5) * 8, 340, gy + (Math.random() - 0.5) * 8, 512, gy);
      ctx.stroke();
    }

    // Plank seam
    ctx.fillStyle = '#8F5828';
    ctx.fillRect(0, y + plankH - 2, 512, 2);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(8, 8);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export interface StageEnvironment {
  sceneGroup: THREE.Group;
  trophies: Record<'chonk' | 'jump' | 'stack', THREE.Group>;
  skyTowerGroup: THREE.Group;
  jumpClouds: THREE.Mesh[];
  updateTrophies: (unlocked: Record<'chonk' | 'jump' | 'stack', boolean>, time: number) => void;
}

export function createStageEnvironment(): StageEnvironment {
  const sceneGroup = new THREE.Group();

  // 1. Warm Oak Hardwood Floor (matching the reference photo!)
  const floorTex = createOakFloorTexture();
  const floorGeo = new THREE.CircleGeometry(28, 64);
  const floorMat = new THREE.MeshStandardMaterial({
    map: floorTex,
    roughness: 0.55,
    metalness: 0.05,
  });
  const floorMesh = new THREE.Mesh(floorGeo, floorMat);
  floorMesh.rotation.x = -Math.PI / 2;
  floorMesh.receiveShadow = true;
  sceneGroup.add(floorMesh);

  // 2. Official Guinness Circular Arena Rug / Rim under Котость
  const ringGeo = new THREE.RingGeometry(1.75, 1.98, 64);
  const goldMat = new THREE.MeshStandardMaterial({
    color: '#F59E0B',
    metalness: 0.65,
    roughness: 0.25,
    side: THREE.DoubleSide,
  });
  const ringMesh = new THREE.Mesh(ringGeo, goldMat);
  ringMesh.rotation.x = -Math.PI / 2;
  ringMesh.position.y = 0.008;
  sceneGroup.add(ringMesh);

  // Soft dark-blue velvet inner stage mat
  const innerMatGeo = new THREE.CircleGeometry(1.75, 64);
  const innerMat = new THREE.MeshStandardMaterial({
    color: '#1E293B',
    roughness: 0.85,
  });
  const innerCircle = new THREE.Mesh(innerMatGeo, innerMat);
  innerCircle.rotation.x = -Math.PI / 2;
  innerCircle.position.y = 0.005;
  innerCircle.receiveShadow = true;
  sceneGroup.add(innerCircle);

  // 3. Background Left: Warm Wooden Dresser / Chest of Drawers (just like the reference photo!)
  const dresserGroup = new THREE.Group();
  dresserGroup.position.set(-4.2, 0, -4.8);
  dresserGroup.rotation.y = 0.28;

  const woodChestMat = new THREE.MeshStandardMaterial({ color: '#9A5B25', roughness: 0.65 });
  const darkWoodMat = new THREE.MeshStandardMaterial({ color: '#5C3211', roughness: 0.7 });

  const chestBody = new THREE.Mesh(new THREE.BoxGeometry(2.8, 2.4, 1.4), woodChestMat);
  chestBody.position.y = 1.2;
  chestBody.castShadow = true;
  chestBody.receiveShadow = true;
  dresserGroup.add(chestBody);

  const chestTop = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.16, 1.55), darkWoodMat);
  chestTop.position.y = 2.45;
  dresserGroup.add(chestTop);

  // Drawers & little dark knobs
  for (let d = 0; d < 2; d++) {
    const drawer = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.92, 0.08), woodChestMat);
    drawer.position.set(0, 0.72 + d * 1.05, 0.72);
    dresserGroup.add(drawer);

    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 12), darkWoodMat);
    knob.position.set(0, 0.72 + d * 1.05, 0.78);
    dresserGroup.add(knob);
  }

  // Potted houseplant on top of the dresser (matching top-left of the photo!)
  const potMat = new THREE.MeshStandardMaterial({ color: '#1F2937', roughness: 0.5 });
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.24, 0.55, 20), potMat);
  pot.position.set(-0.6, 2.8, 0);
  dresserGroup.add(pot);

  const leafMat = new THREE.MeshStandardMaterial({ color: '#15803D', roughness: 0.6 });
  for (let l = 0; l < 5; l++) {
    const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.26, 16, 16), leafMat);
    leaf.scale.set(0.8, 1.5, 0.5);
    const a = (l / 5) * Math.PI * 2;
    leaf.position.set(-0.6 + Math.cos(a) * 0.18, 3.25, Math.sin(a) * 0.18);
    leaf.rotation.z = Math.cos(a) * 0.4;
    dresserGroup.add(leaf);
  }

  sceneGroup.add(dresserGroup);

  // 4. Background Right: Bright Sunlit Window Frame (matching right side of the photo!)
  const windowGroup = new THREE.Group();
  windowGroup.position.set(4.5, 2.6, -5.2);
  windowGroup.rotation.y = -0.25;

  const frameMat = new THREE.MeshStandardMaterial({ color: '#F8FAFC', roughness: 0.4 });
  const glassMat = new THREE.MeshBasicMaterial({ color: '#E0F2FE' });

  const windowFrame = new THREE.Mesh(new THREE.BoxGeometry(3.2, 4.6, 0.2), frameMat);
  windowGroup.add(windowFrame);

  const windowGlass = new THREE.Mesh(new THREE.PlaneGeometry(2.8, 4.2), glassMat);
  windowGlass.position.z = 0.11;
  windowGroup.add(windowGlass);

  sceneGroup.add(windowGroup);

  // 5. Three Official Guinness World Record Trophy Pedestals behind Котость
  const createTrophyPedestal = (x: number, z: number, labelColor: string) => {
    const group = new THREE.Group();
    group.position.set(x, 0, z);

    const pedMat = new THREE.MeshStandardMaterial({ color: '#1E293B', roughness: 0.4, metalness: 0.2 });
    const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.48, 0.75, 24), pedMat);
    ped.position.y = 0.375;
    ped.castShadow = true;
    ped.receiveShadow = true;
    group.add(ped);

    const trimRing = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.08, 24), goldMat);
    trimRing.position.y = 0.74;
    group.add(trimRing);

    // Golden Trophy Cup on top (glows & spins when record is broken!)
    const trophyGroup = new THREE.Group();
    trophyGroup.position.y = 1.05;
    group.add(trophyGroup);

    const cupBase = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 0.14, 20), goldMat);
    trophyGroup.add(cupBase);

    const cupStem = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.24, 16), goldMat);
    cupStem.position.y = 0.16;
    trophyGroup.add(cupStem);

    const cupBowl = new THREE.Mesh(new THREE.SphereGeometry(0.24, 24, 24), goldMat);
    cupBowl.position.y = 0.42;
    cupBowl.scale.set(1, 1.15, 1);
    trophyGroup.add(cupBowl);

    const badgeStar = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.11, 0),
      new THREE.MeshStandardMaterial({
        color: labelColor,
        emissive: labelColor,
        emissiveIntensity: 0.6,
        roughness: 0.2,
      })
    );
    badgeStar.position.set(0, 0.44, 0.22);
    trophyGroup.add(badgeStar);

    sceneGroup.add(group);
    return trophyGroup;
  };

  const trophies = {
    chonk: createTrophyPedestal(-2.35, -1.75, '#F59E0B'),
    jump: createTrophyPedestal(0, -2.55, '#10B981'),
    stack: createTrophyPedestal(2.35, -1.75, '#E11D48'),
  };

  // 6. Vertical Sky Tower Landmarks & Bouncy Clouds for Discipline 2 (Mega-Jump)
  const skyTowerGroup = new THREE.Group();
  sceneGroup.add(skyTowerGroup);

  const jumpClouds: THREE.Mesh[] = [];
  const cloudMat = new THREE.MeshStandardMaterial({
    color: '#FFFDF9',
    emissive: '#38BDF8',
    emissiveIntensity: 0.15,
    roughness: 0.7,
  });
  const goldOrbMat = new THREE.MeshStandardMaterial({
    color: '#FACC15',
    emissive: '#F59E0B',
    emissiveIntensity: 0.45,
    metalness: 0.6,
    roughness: 0.2,
  });

  // Create 35 bouncy clouds / golden yarn boosters up to 90 meters (in 3D units, 1m = 0.55 units)
  for (let i = 1; i <= 36; i++) {
    const isGoldenBooster = i % 3 === 0;
    const mesh = new THREE.Mesh(
      isGoldenBooster ? new THREE.OctahedronGeometry(0.45, 1) : new THREE.SphereGeometry(0.55, 20, 16),
      isGoldenBooster ? goldOrbMat : cloudMat
    );
    if (!isGoldenBooster) {
      mesh.scale.set(1.45, 0.55, 1.1);
    }
    const heightMeters = i * 2.4;
    const yPos = heightMeters * 0.55;
    const xPos = Math.sin(i * 1.7) * 2.1;
    mesh.position.set(xPos, yPos, 0);
    mesh.userData = { isGoldenBooster, heightMeters, baseX: xPos, phase: i * 0.8 };
    skyTowerGroup.add(mesh);
    jumpClouds.push(mesh);
  }

  // Guinness 45m World Record Golden Blimp / Banner Ring in the sky!
  const recordBannerY = 45 * 0.55;
  const recordArch = new THREE.Mesh(
    new THREE.TorusGeometry(3.2, 0.16, 16, 64),
    new THREE.MeshStandardMaterial({
      color: '#FACC15',
      emissive: '#F59E0B',
      emissiveIntensity: 0.5,
      metalness: 0.8,
      roughness: 0.2,
    })
  );
  recordArch.position.set(0, recordBannerY, -0.5);
  skyTowerGroup.add(recordArch);

  const updateTrophies = (unlocked: Record<'chonk' | 'jump' | 'stack', boolean>, time: number) => {
    (['chonk', 'jump', 'stack'] as const).forEach((key, idx) => {
      const t = trophies[key];
      if (unlocked[key]) {
        t.visible = true;
        t.scale.setScalar(1.0 + Math.sin(time * 3 + idx) * 0.06);
        t.rotation.y = time * 1.4 + idx;
        t.position.y = 1.12 + Math.sin(time * 2.5 + idx) * 0.06;
      } else {
        t.visible = true;
        t.scale.setScalar(0.55);
        t.rotation.y = 0;
        t.position.y = 0.92;
      }
    });
  };

  return {
    sceneGroup,
    trophies,
    skyTowerGroup,
    jumpClouds,
    updateTrophies,
  };
}

/**
 * Creates a 3D stackable item mesh for Discipline 3 ("Башня На Голове")
 */
export function createStackItemMesh(itemIndex: number): {
  mesh: THREE.Group;
  height: number;
  radius: number;
  name: string;
} {
  const spec = STACK_ITEMS_CATALOG[itemIndex % STACK_ITEMS_CATALOG.length];
  const group = new THREE.Group();

  const mainMat = new THREE.MeshStandardMaterial({
    color: spec.color,
    roughness: 0.35,
    metalness: spec.shape === 'trophy' ? 0.75 : 0.15,
  });
  const goldTrimMat = new THREE.MeshStandardMaterial({
    color: '#FDE047',
    roughness: 0.25,
    metalness: 0.7,
  });

  if (spec.shape === 'cylinder') {
    const cyl = new THREE.Mesh(
      new THREE.CylinderGeometry(spec.radius, spec.radius, spec.height, 28),
      mainMat
    );
    cyl.castShadow = true;
    cyl.receiveShadow = true;
    group.add(cyl);

    // Decorative label band
    const band = new THREE.Mesh(
      new THREE.CylinderGeometry(spec.radius * 1.01, spec.radius * 1.01, spec.height * 0.45, 28),
      goldTrimMat
    );
    group.add(band);
  } else if (spec.shape === 'box') {
    const box = new THREE.Mesh(
      new THREE.BoxGeometry(spec.radius * 1.75, spec.height, spec.radius * 1.35),
      mainMat
    );
    box.castShadow = true;
    box.receiveShadow = true;
    group.add(box);

    const spine = new THREE.Mesh(
      new THREE.BoxGeometry(spec.radius * 1.78, spec.height * 0.35, spec.radius * 1.38),
      goldTrimMat
    );
    group.add(spine);
  } else if (spec.shape === 'sphere') {
    const sph = new THREE.Mesh(new THREE.SphereGeometry(spec.radius * 0.85, 24, 24), mainMat);
    sph.scale.set(1.15, spec.height / (spec.radius * 1.7), 1.15);
    sph.castShadow = true;
    group.add(sph);
  } else {
    // Trophy
    const cup = new THREE.Mesh(
      new THREE.CylinderGeometry(spec.radius * 0.9, spec.radius * 0.55, spec.height, 24),
      goldTrimMat
    );
    cup.castShadow = true;
    group.add(cup);
  }

  return {
    mesh: group,
    height: spec.height,
    radius: spec.radius,
    name: spec.name,
  };
}
