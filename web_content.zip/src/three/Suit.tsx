import { useFrame } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { itemById } from "../lib/catalog";
import { shade } from "./textures";
import { strokeTextGeometry } from "./strokeFont";

/**
 * Garments are modelled, not painted.
 *
 * The body is an ellipsoid of radii (1, 0.96, 0.94). Every shell here is that
 * same ellipsoid scaled up by SHELL, then trimmed with theta limits — so the
 * cloth follows the chick exactly and the plush can never burst through it.
 * (The previous version squashed Y to 0.82, which is why the chest poked out.)
 */
const BODY: [number, number, number] = [1, 0.96, 0.94];
const SHELL = 1.06;
const R: [number, number, number] = [BODY[0] * SHELL, BODY[1] * SHELL, BODY[2] * SHELL];

/** y (in body space) -> polar angle on the unit sphere */
const thetaAt = (y: number) => Math.acos(THREE.MathUtils.clamp(y / R[1], -1, 1));

const NECK_Y = 0.56;
const HEM_Y = -0.92;
const TH_TOP = thetaAt(NECK_Y);
const TH_LEN = thetaAt(HEM_Y) - TH_TOP;

/** ring radii of the shell at a given height, used to seat trims exactly */
function ringAt(y: number) {
  const s = Math.sin(thetaAt(y));
  return { x: R[0] * s, z: R[2] * s };
}

/* ------------------------------------------------------------------ */
/*  embroidered NewVision™ — real raised thread, not a texture         */
/* ------------------------------------------------------------------ */
function Embroidery({ color, metal = false }: { color: string; metal?: boolean }) {
  const word = useMemo(() => strokeTextGeometry("New Vision", 0.05, 6), []);
  // a genuine TM, not a stray letter
  const tm = useMemo(() => strokeTextGeometry("TM", 0.05, 5), []);

  /**
   * Wrap the lettering around the chest.
   *
   * A flat plane of text on a sphere reads as a sticker, so each vertex is
   * pushed out to the garment surface: its local x becomes an angle around the
   * body and its y becomes a height, exactly like thread following the weave.
   */
  const curved = useMemo(() => {
    const g = word.geometry.clone();
    const pos = g.attributes.position as THREE.BufferAttribute;
    const SCALE = 0.3;
    const CY = 0.06;       // chest height
    const SPREAD = 1.15;   // how far round the body the word wraps

    for (let i = 0; i < pos.count; i++) {
      const lx = pos.getX(i) * SCALE;
      const ly = pos.getY(i) * SCALE + CY;
      const lz = pos.getZ(i) * SCALE;

      const ang = (lx / R[0]) * SPREAD;
      // radius of the garment at this height, plus the thread's own relief
      const t = THREE.MathUtils.clamp(ly / R[1], -1, 1);
      const ring = Math.sqrt(Math.max(0.04, 1 - t * t));
      const out = 1.012 + lz * 1.6;

      pos.setXYZ(
        i,
        Math.sin(ang) * R[0] * ring * out,
        ly,
        Math.cos(ang) * R[2] * ring * out,
      );
    }
    pos.needsUpdate = true;
    g.computeVertexNormals();
    return g;
  }, [word]);

  const curvedTm = useMemo(() => {
    const g = tm.geometry.clone();
    const pos = g.attributes.position as THREE.BufferAttribute;
    // ™ is small and rides on the shoulder of the last letter
    const SCALE = 0.085;
    const CX = 0.3 * (word.width / 2) + 0.055;
    const CY = 0.155;
    for (let i = 0; i < pos.count; i++) {
      const lx = pos.getX(i) * SCALE + CX;
      const ly = pos.getY(i) * SCALE + CY;
      const lz = pos.getZ(i) * SCALE;
      const ang = (lx / R[0]) * 1.15;
      const t = THREE.MathUtils.clamp(ly / R[1], -1, 1);
      const ring = Math.sqrt(Math.max(0.04, 1 - t * t));
      const out = 1.012 + lz * 1.6;
      pos.setXYZ(i, Math.sin(ang) * R[0] * ring * out, ly, Math.cos(ang) * R[2] * ring * out);
    }
    pos.needsUpdate = true;
    g.computeVertexNormals();
    return g;
  }, [tm, word.width]);

  useEffect(
    () => () => {
      word.geometry.dispose();
      tm.geometry.dispose();
      curved.dispose();
      curvedTm.dispose();
    },
    [word, tm, curved, curvedTm],
  );

  return (
    <group>
      <mesh geometry={curved} castShadow>
        <meshStandardMaterial
          color={color}
          roughness={metal ? 0.3 : 0.82}
          metalness={metal ? 0.85 : 0.04}
          envMapIntensity={metal ? 1.4 : 0.4}
        />
      </mesh>
      <mesh geometry={curvedTm} castShadow>
        <meshStandardMaterial
          color={color}
          roughness={metal ? 0.32 : 0.82}
          metalness={metal ? 0.8 : 0.04}
        />
      </mesh>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/*  ribbed trim — a real torus of knitted ribs                         */
/* ------------------------------------------------------------------ */
function Rib({
  y,
  color,
  tube = 0.075,
  ribs = 34,
  wool,
}: {
  y: number;
  color: string;
  tube?: number;
  ribs?: number;
  wool: boolean;
}) {
  const { x, z } = ringAt(y);
  const rad = (x + z) / 2;

  return (
    <group position={[0, y, 0]} scale={[x / rad, 1, z / rad]}>
      <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
        <torusGeometry args={[rad, tube, 12, 40]} />
        <meshStandardMaterial
          color={color}
          roughness={wool ? 0.95 : 0.5}
          metalness={wool ? 0 : 0.2}
        />
      </mesh>
      {/* individual knit ribs so it reads as cuffed fabric */}
      {Array.from({ length: ribs }).map((_, i) => {
        const a = (i / ribs) * Math.PI * 2;
        return (
          <mesh
            key={i}
            position={[Math.cos(a) * rad, 0, Math.sin(a) * rad]}
            rotation={[0, -a, 0]}
          >
            <boxGeometry args={[0.018, tube * 2.1, tube * 0.5]} />
            <meshStandardMaterial color={shade(color, -0.3)} roughness={0.95} />
          </mesh>
        );
      })}
    </group>
  );
}

/* ------------------------------------------------------------------ */
/*  main garment                                                       */
/* ------------------------------------------------------------------ */
export function Suit({ id }: { id: string | null }) {
  const item = itemById(id);
  const hood = useRef<THREE.Group>(null);
  const strings = useRef<THREE.Group>(null);
  const shimmer = useRef<THREE.MeshPhysicalMaterial>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (hood.current) hood.current.rotation.x = Math.sin(t * 1.1) * 0.05;
    if (strings.current) strings.current.rotation.x = Math.sin(t * 1.6) * 0.09;
    if (shimmer.current) {
      // iridescent pieces drift their sheen
      shimmer.current.iridescenceIOR = 1.5 + Math.sin(t * 0.9) * 0.4;
    }
  });

  if (!item || item.slot !== "suit") return null;

  const kind = item.finish ?? "fabric";
  const base = item.tint;
  const accent = item.tint2 ?? "#ffffff";
  const wool = kind === "wool";
  const gloss = kind === "gloss";
  const leather = kind === "leather";
  const galaxy = item.id === "hoodie_galaxy";

  /** shared cloth material — the look comes from shading, not a printed map */
  const cloth = (
    <meshPhysicalMaterial
      color={base}
      roughness={wool ? 0.97 : gloss ? 0.16 : leather ? 0.42 : 0.85}
      metalness={gloss ? 0.4 : leather ? 0.1 : 0}
      clearcoat={gloss ? 1 : leather ? 0.55 : 0}
      clearcoatRoughness={gloss ? 0.07 : 0.35}
      sheen={wool ? 1 : 0.2}
      sheenRoughness={wool ? 0.95 : 0.4}
      sheenColor={wool ? shade(base, 0.4) : "#ffffff"}
      envMapIntensity={gloss ? 1.6 : leather ? 1 : 0.45}
      emissive={galaxy ? accent : "#000000"}
      emissiveIntensity={galaxy ? 0.28 : 0}
    />
  );

  const neck = ringAt(NECK_Y);

  return (
    <group>
      {/* ---------- torso: the body ellipsoid, trimmed at neck and hem ---------- */}
      <mesh scale={R} castShadow receiveShadow>
        <sphereGeometry args={[1, 56, 40, 0, Math.PI * 2, TH_TOP, TH_LEN]} />
        {cloth}
      </mesh>
      {/* inner face so the neck opening has thickness */}
      <mesh scale={[R[0] * 0.985, R[1] * 0.985, R[2] * 0.985]}>
        <sphereGeometry args={[1, 40, 28, 0, Math.PI * 2, TH_TOP, TH_LEN]} />
        <meshStandardMaterial color={shade(base, -0.5)} side={THREE.BackSide} roughness={0.95} />
      </mesh>

      {/* ---------- knitted collar and hem ---------- */}
      <Rib y={NECK_Y} color={shade(base, wool ? 0.06 : -0.15)} tube={0.075} wool={wool} />
      <Rib y={HEM_Y + 0.03} color={shade(base, -0.16)} tube={0.065} ribs={30} wool={wool} />

      {/* ---------- hood, draped down the back ---------- */}
      <group ref={hood} position={[0, 0.4, -0.6]}>
        <mesh position={[0, 0.2, -0.34]} scale={[0.72, 0.6, 0.52]} castShadow>
          <sphereGeometry args={[1, 32, 22]} />
          {cloth}
        </mesh>
        {/* rolled opening around the neck */}
        <mesh position={[0, 0.4, 0.04]} rotation={[1.25, 0, 0]}>
          <torusGeometry args={[0.56, 0.1, 12, 32]} />
          <meshPhysicalMaterial
            color={shade(base, 0.08)}
            roughness={wool ? 0.96 : 0.3}
            metalness={gloss ? 0.35 : 0}
            sheen={wool ? 1 : 0}
            sheenColor={shade(base, 0.4)}
          />
        </mesh>
        {/* dark lining seen inside the opening */}
        <mesh position={[0, 0.36, 0.0]} rotation={[1.25, 0, 0]}>
          <circleGeometry args={[0.5, 28]} />
          <meshStandardMaterial color={shade(base, -0.62)} roughness={1} side={THREE.DoubleSide} />
        </mesh>
      </group>

      {/* ---------- kangaroo pocket, hugging the belly ---------- */}
      <group position={[0, -0.44, 0]}>
        <mesh scale={[R[0] * 1.012, R[1] * 1.012, R[2] * 1.012]} position={[0, 0.44, 0]}>
          <sphereGeometry
            args={[1, 40, 20, Math.PI * 0.34, Math.PI * 0.32, thetaAt(-0.3), thetaAt(-0.78) - thetaAt(-0.3)]}
          />
          {cloth}
        </mesh>
        {/* pocket mouth shadow */}
        <mesh scale={[R[0] * 1.018, R[1] * 1.018, R[2] * 1.018]} position={[0, 0.44, 0]}>
          <sphereGeometry
            args={[1, 40, 4, Math.PI * 0.34, Math.PI * 0.32, thetaAt(-0.3), 0.05]}
          />
          <meshBasicMaterial color="#000000" transparent opacity={0.35} side={THREE.DoubleSide} />
        </mesh>
      </group>

      {/* ---------- drawstrings hanging from the collar ---------- */}
      <group ref={strings} position={[0, NECK_Y - 0.04, neck.z * 0.82]}>
        {[-1, 1].map((s) => (
          <group key={s} position={[s * 0.16, 0, 0]}>
            <mesh position={[0, -0.17, 0.02]} rotation={[0, 0, s * 0.07]} castShadow>
              <capsuleGeometry args={[0.018, 0.3, 4, 7]} />
              <meshStandardMaterial color={shade(base, wool ? 0.42 : 0.25)} roughness={0.9} />
            </mesh>
            <mesh position={[0, -0.35, 0.03]}>
              <cylinderGeometry args={[0.028, 0.028, 0.06, 10]} />
              <meshStandardMaterial color={accent} roughness={0.35} metalness={0.7} />
            </mesh>
          </group>
        ))}
      </group>

      {/* ---------- zip for the technical fabrics ---------- */}
      {(gloss || leather) && (
        <>
          <mesh position={[0, -0.16, R[2] * 0.985]} scale={[0.03, 1.0, 0.012]}>
            <boxGeometry args={[1, 1, 1]} />
            <meshStandardMaterial color={accent} roughness={0.3} metalness={0.95} />
          </mesh>
          <mesh position={[0, 0.24, R[2] * 1.0]} castShadow>
            <boxGeometry args={[0.055, 0.085, 0.03]} />
            <meshStandardMaterial color={accent} roughness={0.22} metalness={1} />
          </mesh>
        </>
      )}

      {/* ---------- iridescent overlay for the galaxy piece ---------- */}
      {galaxy && (
        <mesh scale={[R[0] * 1.004, R[1] * 1.004, R[2] * 1.004]}>
          <sphereGeometry args={[1, 48, 32, 0, Math.PI * 2, TH_TOP, TH_LEN]} />
          <meshPhysicalMaterial
            ref={shimmer}
            color="#2A1B5E"
            roughness={0.1}
            metalness={0.4}
            iridescence={1}
            iridescenceIOR={1.8}
            transparent
            opacity={0.5}
          />
        </mesh>
      )}

      {/* ---------- the brand, embroidered in real thread ---------- */}
      <Embroidery color={accent} metal={gloss || leather} />
    </group>
  );
}

/* ------------------------------------------------------------------ */
/*  sleeve — mounted inside a wing group so it moves with the wing     */
/* ------------------------------------------------------------------ */
export function Sleeve({ id, side }: { id: string | null; side: -1 | 1 }) {
  const item = itemById(id);
  if (!item || item.slot !== "suit") return null;

  const kind = item.finish ?? "fabric";
  const base = item.tint;
  const wool = kind === "wool";
  const gloss = kind === "gloss";

  // the wing blob lives at (±0.16, -0.1, 0) with radii (0.198, 0.449, 0.317)
  const cx = side * 0.16;

  return (
    <group>
      {/* sleeve shell, a touch larger than the wing */}
      <mesh position={[cx, -0.1, 0]} scale={[0.23, 0.48, 0.35]} castShadow>
        <sphereGeometry args={[1, 26, 20]} />
        <meshPhysicalMaterial
          color={base}
          roughness={wool ? 0.97 : gloss ? 0.16 : 0.85}
          metalness={gloss ? 0.4 : 0}
          clearcoat={gloss ? 1 : 0}
          sheen={wool ? 1 : 0.2}
          sheenRoughness={0.95}
          sheenColor={wool ? shade(base, 0.4) : "#ffffff"}
          envMapIntensity={gloss ? 1.5 : 0.45}
        />
      </mesh>

      {/* ribbed cuff at the wing tip */}
      <group position={[cx, -0.5, 0]}>
        <mesh rotation={[Math.PI / 2, 0, 0]} scale={[1, 1, 1.5]} castShadow>
          <torusGeometry args={[0.145, 0.05, 10, 24]} />
          <meshStandardMaterial color={shade(base, -0.16)} roughness={0.95} />
        </mesh>
        {Array.from({ length: 16 }).map((_, i) => {
          const a = (i / 16) * Math.PI * 2;
          return (
            <mesh
              key={i}
              position={[Math.cos(a) * 0.145, 0, Math.sin(a) * 0.22]}
              rotation={[0, -a, 0]}
            >
              <boxGeometry args={[0.014, 0.1, 0.02]} />
              <meshStandardMaterial color={shade(base, -0.34)} roughness={0.95} />
            </mesh>
          );
        })}
      </group>
    </group>
  );
}
