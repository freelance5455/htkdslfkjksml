import React, { useState, useEffect } from "react";
import { ActiveTab, Note } from "./types";
import { AdaptiveLayoutWrapper } from "./components/AdaptiveLayoutWrapper";
import { ThemeStateController, ThemeState } from "./utils/themeStateController";
import { NoteFlowThemeStyle } from "./utils/themeTokens";
import { ThemeAndInterfaceSettings } from "./components/ThemeAndInterfaceSettings";
import {
  MinimalistCard,
  TerminalLogCard,
  CyberpunkGlowCard,
  MindMapNodeWidget,
  EnterprisePKMDashboard
} from "./components/ThemeCardComponents";

/**
 * MainApp - Cross-Platform Application Entry Point
 * Designed for Android, iOS, Windows, macOS, and Huawei HMS/HarmonyOS.
 * Provides lag-free responsive breakpoint adaptation and atomic theme state management.
 */
export const MainApp: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>("home");
  const [themeState, setThemeState] = useState<ThemeState>(
    ThemeStateController.getState()
  );

  useEffect(() => {
    const unsubscribe = ThemeStateController.subscribe((newState) => {
      setThemeState(newState);
    });
    return unsubscribe;
  }, []);

  const dummyNotes: Partial<Note>[] = [
    {
      id: "note-1",
      title: "NoteFlow Cross-Platform Mimari",
      content: "GMS bağımsız Huawei HMS desteği ve sıfır UI re-render maliyetli design token yapısı.",
      category: "Yazılım Mimarisi",
      updatedAt: new Date().toISOString(),
    },
    {
      id: "note-2",
      title: "Mobil Performans Notu",
      content: "Lazy loading ve optimize edilmiş breakpoint geçişleri ile dondurmayan arayüz.",
      category: "Performans",
      updatedAt: new Date(Date.now() - 3600000).toISOString(),
    },
  ];

  return (
    <AdaptiveLayoutWrapper
      activeTab={activeTab}
      setActiveTab={setActiveTab}
      notes={dummyNotes as Note[]}
    >
      <div className="w-full max-w-7xl mx-auto space-y-6">
        {activeTab === "profile" || activeTab === "settings" ? (
          <ThemeAndInterfaceSettings />
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-lg font-black text-slate-900 dark:text-white">
                  Not Çalışma Alanı ({themeState.currentTheme})
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Etkin Tema: {themeState.currentTheme} | Akıllı Düzen
                </p>
              </div>
            </div>

            {/* Dynamic Rendering Based on Active Theme Tokens */}
            {themeState.currentTheme === NoteFlowThemeStyle.Minimalist && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {dummyNotes.map((n) => (
                  <MinimalistCard
                    key={n.id}
                    title={n.title}
                    content={n.content}
                    category={n.category}
                  />
                ))}
              </div>
            )}

            {themeState.currentTheme === NoteFlowThemeStyle.Terminal && (
              <div className="grid grid-cols-1 gap-4">
                {dummyNotes.map((n) => (
                  <TerminalLogCard
                    key={n.id}
                    title={`${n.title}.sh`}
                    content={`[INFO] ${n.content}\n[OK] Thread completed cleanly on HMS.`}
                  />
                ))}
              </div>
            )}

            {themeState.currentTheme === NoteFlowThemeStyle.CyberpunkGlow && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {dummyNotes.map((n) => (
                  <CyberpunkGlowCard
                    key={n.id}
                    title={n.title}
                    content={n.content}
                    category={n.category}
                    isPinned={true}
                  />
                ))}
              </div>
            )}

            {themeState.currentTheme === NoteFlowThemeStyle.MindMap && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {dummyNotes.map((n) => (
                  <MindMapNodeWidget
                    key={n.id}
                    title={n.title}
                    content={n.content}
                  />
                ))}
              </div>
            )}

            {themeState.currentTheme === NoteFlowThemeStyle.EnterprisePKM && (
              <EnterprisePKMDashboard notes={dummyNotes} />
            )}
          </div>
        )}
      </div>
    </AdaptiveLayoutWrapper>
  );
};

export default MainApp;
