import { useState, type FormEvent } from "react";
import { avisosIniciales, categorias, type Aviso } from "../data";
import { Reveal, SectionHead } from "../lib/ui";

const colorDe = (c: string) => categorias.find((x) => x.nombre === c)?.color ?? "#6b6357";

export default function Tablon() {
  const [avisos, setAvisos] = useState<Aviso[]>(avisosIniciales);
  const [cat, setCat] = useState("Otro");
  const [titulo, setTitulo] = useState("");
  const [texto, setTexto] = useState("");
  const [autor, setAutor] = useState("");
  const [error, setError] = useState("");

  function publicar(e: FormEvent) {
    e.preventDefault();
    if (titulo.trim().length < 4 || texto.trim().length < 10) {
      setError("Ponle un título y al menos una frase al aviso: el tablón no admite postales en blanco.");
      return;
    }
    if (!autor.trim()) {
      setError("Dinos quién lo cuelga: firma o barrio, para saber de dónde viene.");
      return;
    }
    const id = Date.now();
    const fecha = new Date().toLocaleDateString("es-ES", {
      day: "2-digit",
      month: "short",
    });
    setAvisos((a) => [
      { id, cat, titulo: titulo.trim(), texto: texto.trim(), autor: autor.trim(), fecha, nuevo: true },
      ...a,
    ]);
    setTitulo("");
    setTexto("");
    setError("");
    setCat("Otro");
  }

  return (
    <section id="tablon" className="relative bg-cal">
      <div className="border-y border-tinta/15">
        <img
          src="images/mercado.jpg"
          alt="Mercadillo semanal de San Fulgencio un martes por la mañana"
          className="h-44 w-full object-cover object-[50%_62%] sm:h-60"
        />
      </div>

      <div className="mx-auto w-full max-w-[1440px] px-5 py-16 sm:px-8 lg:px-14 lg:py-24">
        <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
          <SectionHead
            eyebrow="La sección que la tiene usted"
            titulo="Tablón de anuncios"
            entrada="Sin cuenta, sin algoritmo y sin permiso de nadie. Escribe tu aviso y aparece aquí mismo, arriba del todo, tal y como se pegaría en el tablón del bar."
          />
          <p className="display tabular shrink-0 text-[clamp(2.6rem,6vw,4.5rem)] font-black leading-none text-naranja">
            {String(avisos.length).padStart(2, "0")}
            <span className="block text-right text-[0.7rem] font-normal tracking-[0.2em] text-taupe uppercase">
              avisos colgados
            </span>
          </p>
        </div>

        <div className="mt-12 grid gap-10 lg:grid-cols-[minmax(0,25rem)_minmax(0,1fr)] lg:gap-14">
          {/* --- formulario --- */}
          <div className="lg:sticky lg:top-24 lg:self-start">
            <form
              onSubmit={publicar}
              className="border border-tinta/20 bg-cal2 p-5 shadow-[6px_6px_0_rgba(15,22,38,0.12)] sm:p-6"
            >
              <p className="label text-tinta">Pega tu aviso</p>

              <fieldset className="mt-5">
                <legend className="mb-2 text-[0.72rem] font-semibold tracking-[0.14em] text-taupe uppercase">
                  Categoría
                </legend>
                <div className="flex flex-wrap gap-2">
                  {categorias.map((c) => {
                    const on = c.nombre === cat;
                    return (
                      <button
                        type="button"
                        key={c.nombre}
                        onClick={() => setCat(c.nombre)}
                        aria-pressed={on}
                        className={`label rounded-none border px-3 py-2 transition ${
                          on
                            ? "border-transparent text-cal"
                            : "border-tinta/25 text-tinta/70 hover:border-tinta/60 hover:text-tinta"
                        }`}
                        style={on ? { backgroundColor: c.color } : undefined}
                      >
                        {c.nombre}
                      </button>
                    );
                  })}
                </div>
              </fieldset>

              <label className="mt-5 block text-[0.72rem] font-semibold tracking-[0.14em] text-taupe uppercase">
                Título
                <input
                  value={titulo}
                  onChange={(e) => setTitulo(e.target.value)}
                  maxLength={80}
                  placeholder="Corte de agua el jueves"
                  className="mt-2 w-full border-0 border-b-2 border-tinta/25 bg-transparent pb-2 font-display text-[1.15rem] font-semibold text-tinta placeholder:text-taupe/60 focus:border-naranja focus:outline-none"
                />
              </label>

              <label className="mt-5 block text-[0.72rem] font-semibold tracking-[0.14em] text-taupe uppercase">
                Mensaje
                <textarea
                  value={texto}
                  onChange={(e) => setTexto(e.target.value)}
                  rows={4}
                  maxLength={320}
                  placeholder="Cuéntale al pueblo qué pasa, dónde y cuándo."
                  className="mt-2 w-full resize-none border-0 border-b-2 border-tinta/25 bg-transparent pb-2 text-[0.95rem] leading-relaxed text-tinta placeholder:text-taupe/60 focus:border-naranja focus:outline-none"
                />
              </label>

              <label className="mt-5 block text-[0.72rem] font-semibold tracking-[0.14em] text-taupe uppercase">
                Firma o barrio
                <input
                  value={autor}
                  onChange={(e) => setAutor(e.target.value)}
                  maxLength={40}
                  placeholder="Amparo, calle Mayor"
                  className="mt-2 w-full border-0 border-b-2 border-tinta/25 bg-transparent pb-2 text-[0.95rem] text-tinta placeholder:text-taupe/60 focus:border-naranja focus:outline-none"
                />
              </label>

              <p
                role="status"
                aria-live="polite"
                className={`mt-4 min-h-[2.5rem] text-[0.82rem] leading-snug ${
                  error ? "text-alerta" : "text-taupe"
                }`}
              >
                {error || "Se publica al instante en tu navegador. Nada sale de este equipo."}
              </p>

              <button
                type="submit"
                className="label mt-1 w-full cursor-pointer bg-tinta px-5 py-4 text-cal transition hover:bg-naranja"
              >
                Colgar en el tablón
              </button>
            </form>
          </div>

          {/* --- avisos --- */}
          <ul className="grid gap-4 sm:grid-cols-2">
            {avisos.length === 0 && (
              <li className="border-2 border-dashed border-tinta/25 p-10 text-center sm:col-span-2">
                <p className="display text-2xl font-black text-tinta">El tablón está limpio.</p>
                <p className="mt-2 text-sm text-taupe">
                  Se ha ido el mundo entero. Sé el primero en pegar un aviso.
                </p>
              </li>
            )}
            {avisos.map((a, i) => (
              <Reveal
                as="li"
                key={a.id}
                delay={Math.min(i, 5) * 60}
                className={`h-full ${a.nuevo ? "pin-in" : ""}`}
              >
                <article className="group flex h-full flex-col border border-tinta/20 bg-white/60 p-5 transition hover:-translate-y-1 hover:border-tinta/50 hover:shadow-[5px_5px_0_rgba(15,22,38,0.1)]">
                  <div className="flex items-center justify-between gap-3">
                    <span
                      className="label px-2 py-1 text-cal"
                      style={{ backgroundColor: colorDe(a.cat) }}
                    >
                      {a.cat}
                    </span>
                    <span className="label text-taupe">{a.fecha}</span>
                  </div>
                  <h3 className="display mt-4 text-[1.35rem] leading-[1.1] font-black text-tinta">
                    {a.titulo}
                  </h3>
                  <p className="mt-3 flex-1 text-[0.94rem] leading-relaxed text-tinta/75">
                    {a.texto}
                  </p>
                  <div className="mt-5 flex items-end justify-between gap-3 border-t border-tinta/15 pt-3">
                    <p className="text-[0.78rem] text-taupe italic">— {a.autor}</p>
                    <button
                      onClick={() => setAvisos((list) => list.filter((x) => x.id !== a.id))}
                      className="label cursor-pointer text-taupe transition hover:text-alerta"
                      aria-label={`Retirar el aviso: ${a.titulo}`}
                    >
                      Retirar
                    </button>
                  </div>
                </article>
              </Reveal>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
