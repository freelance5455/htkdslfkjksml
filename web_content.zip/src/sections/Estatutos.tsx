import { useState } from "react";
import { Reveal } from "../lib/ui";

type Articulo = {
  num: string;
  titulo: string;
  texto: string[];
};

type Capitulo = {
  num: string;
  titulo: string;
  articulos: Articulo[];
};

const estatutos: Capitulo[] = [
  {
    num: "I",
    titulo: "Denominación, naturaleza, domicilio y ámbito",
    articulos: [
      {
        num: "1",
        titulo: "Denominación y naturaleza",
        texto: [
          "Con el nombre de «Unidos por San Fulgencio» (en adelante, UpSF) se constituye un partido político de ámbito local al amparo de lo dispuesto en la Ley Orgánica 6/2002, de 27 de junio, de Partidos Políticos, y de los artículos 6 y 23 de la Constitución Española.",
          "UpSF es una organización democrática, sin ánimo de lucro, dotada de personalidad jurídica propia y plena capacidad de obrar para el cumplimiento de sus fines.",
        ],
      },
      {
        num: "2",
        titulo: "Domicilio social",
        texto: [
          "El domicilio social del partido se establece en el término municipal de San Fulgencio, provincia de Alicante, Comunitat Valenciana. El órgano de dirección podrá cambiar el domicilio social dentro del mismo municipio mediante acuerdo motivado, que deberá comunicarse en el plazo de treinta días al Registro de Partidos Políticos del Ministerio del Interior.",
        ],
      },
      {
        num: "3",
        titulo: "Ámbito de actuación",
        texto: [
          "UpSF desarrolla su actividad exclusivamente en el ámbito del municipio de San Fulgencio y, en su caso, en el de la comarca de la Vega Baja del Segura cuando los intereses del municipio así lo requieran.",
          "Los presentes estatutos son de aplicación a todos los afiliados y órganos del partido.",
        ],
      },
    ],
  },
  {
    num: "II",
    titulo: "Fines y principios",
    articulos: [
      {
        num: "4",
        titulo: "Fines del partido",
        texto: [
          "Son fines de Unidos por San Fulgencio:",
          "a) Representar democráticamente a todos los vecinos del municipio, con independencia de su nacionalidad de origen, en el marco de los derechos reconocidos por la legislación española y europea.",
          "b) Promover la transparencia en la gestión de los recursos públicos municipales y exigir la rendición de cuentas de los cargos electos.",
          "c) Impulsar el desarrollo económico sostenible del municipio, con especial atención a la agricultura de regadío, el turismo residencial responsable y la protección del patrimonio natural.",
          "d) Fomentar la convivencia y la integración entre la población de origen español y la de origen extranjero que reside en el término municipal.",
          "e) Defender los intereses del municipio ante las instituciones autonómicas, provinciales y nacionales.",
        ],
      },
      {
        num: "5",
        titulo: "Principios de actuación",
        texto: [
          "La actuación del partido se rige por los principios de democracia interna, igualdad entre sus miembros, transparencia en la gestión y rendición de cuentas ante la ciudadanía.",
          "UpSF rechaza cualquier forma de discriminación por razón de sexo, origen nacional, religión, edad, orientación sexual o cualquier otra condición personal o social.",
          "El partido se compromete a publicar sus cuentas anuales y a facilitar el acceso de cualquier afiliado a la información relevante sobre la organización.",
        ],
      },
    ],
  },
  {
    num: "III",
    titulo: "Afiliación",
    articulos: [
      {
        num: "6",
        titulo: "Requisitos de afiliación",
        texto: [
          "Podrán afiliarse a UpSF las personas físicas que reúnan los siguientes requisitos:",
          "a) Ser mayor de dieciocho años.",
          "b) Estar empadronadas en el municipio de San Fulgencio o tener un vínculo documentado con el municipio.",
          "c) No estar afiliadas a otro partido político.",
          "d) No haber sido expulsadas de UpSF salvo que haya transcurrido el plazo de inhabilitación establecido en el expediente sancionador.",
        ],
      },
      {
        num: "7",
        titulo: "Derechos de los afiliados",
        texto: [
          "Todo afiliado tiene derecho a:",
          "a) Participar en las actividades del partido y en sus procesos de toma de decisiones.",
          "b) Elegir y ser elegido para los órganos de gobierno del partido.",
          "c) Recibir información puntual sobre la actividad del partido.",
          "d) Presentar propuestas, sugerencias y enmiendas a los órganos correspondientes.",
          "e) Ser oído antes de que se adopte cualquier medida disciplinaria que le afecte.",
        ],
      },
      {
        num: "8",
        titulo: "Deberes de los afiliados",
        texto: [
          "Todo afiliado queda obligado a:",
          "a) Respetar los presentes estatutos y los acuerdos adoptados por los órganos del partido.",
          "b) Contribuir económicamente al sostenimiento del partido mediante el pago de la cuota establecida.",
          "c) Desempeñar leal y eficazmente las responsabilidades que le sean encomendadas.",
          "d) Respetar la imagen y el crédito del partido en su actuación pública.",
        ],
      },
      {
        num: "9",
        titulo: "Baja y pérdida de la condición de afiliado",
        texto: [
          "La condición de afiliado se perderá por: renuncia voluntaria comunicada por escrito, impago de la cuota durante más de doce meses, afiliación a otro partido político o expulsión acordada conforme al régimen disciplinario previsto en el Capítulo VII.",
        ],
      },
    ],
  },
  {
    num: "IV",
    titulo: "Organización y órganos de gobierno",
    articulos: [
      {
        num: "10",
        titulo: "Órganos del partido",
        texto: [
          "Los órganos de gobierno y representación de UpSF son:",
          "a) La Asamblea General de Afiliados, órgano soberano del partido.",
          "b) La Junta Directiva, órgano permanente de dirección y gestión.",
          "c) La Presidencia, máxima representación individual del partido.",
          "d) La Secretaría General, responsable de la coordinación interna y la administración.",
          "e) La Tesorería, responsable de la gestión económica y la contabilidad.",
        ],
      },
      {
        num: "11",
        titulo: "Asamblea General de Afiliados",
        texto: [
          "La Asamblea General es el órgano supremo del partido. Se reunirá con carácter ordinario al menos una vez al año, y con carácter extraordinario cuando lo convoque la Junta Directiva o lo solicite al menos el veinte por ciento de los afiliados.",
          "Le corresponde a la Asamblea: aprobar y modificar los estatutos, elegir a los miembros de la Junta Directiva, aprobar el programa político y los presupuestos anuales, y disolver el partido.",
          "Los acuerdos se adoptan por mayoría simple de los afiliados presentes o representados, salvo en los casos de modificación de estatutos o disolución, que requieren mayoría de dos tercios.",
        ],
      },
      {
        num: "12",
        titulo: "Junta Directiva",
        texto: [
          "La Junta Directiva es el órgano de dirección permanente entre Asambleas. Estará compuesta por un mínimo de cinco y un máximo de quince miembros, elegidos por la Asamblea General por un período de cuatro años.",
          "Se reunirá con carácter ordinario al menos una vez al mes y adoptará sus acuerdos por mayoría simple de los asistentes.",
          "Le corresponde: ejecutar los acuerdos de la Asamblea, gestionar el partido, convocar la Asamblea General y presentar candidaturas electorales.",
        ],
      },
      {
        num: "13",
        titulo: "Presidencia",
        texto: [
          "El Presidente o Presidenta representa legalmente al partido, preside la Junta Directiva y la Asamblea General, y vela por el cumplimiento de los estatutos.",
          "Será elegido por la Asamblea General por sufragio directo y secreto de los afiliados, por un período de cuatro años, con un máximo de dos mandatos consecutivos.",
        ],
      },
    ],
  },
  {
    num: "V",
    titulo: "Régimen económico",
    articulos: [
      {
        num: "14",
        titulo: "Recursos económicos",
        texto: [
          "El partido se financia mediante:",
          "a) Las cuotas de los afiliados, cuyo importe será fijado anualmente por la Junta Directiva.",
          "b) Las donaciones y aportaciones de personas físicas, dentro de los límites establecidos por la legislación sobre financiación de partidos políticos.",
          "c) Las subvenciones públicas a las que tenga derecho conforme a la ley.",
          "d) Los rendimientos de su patrimonio y actividades propias.",
        ],
      },
      {
        num: "15",
        titulo: "Transparencia y control",
        texto: [
          "UpSF llevará una contabilidad detallada de sus ingresos y gastos. Las cuentas anuales serán auditadas y puestas a disposición de los afiliados y, en la medida que exija la ley, del público en general.",
          "Ningún cargo del partido podrá comprometer fondos del mismo sin autorización expresa de la Tesorería y de la Presidencia de forma conjunta.",
        ],
      },
    ],
  },
  {
    num: "VI",
    titulo: "Proceso electoral interno",
    articulos: [
      {
        num: "16",
        titulo: "Candidaturas a elecciones municipales",
        texto: [
          "La elaboración de las listas electorales corresponde a la Asamblea General, que las aprobará mediante votación secreta entre los afiliados con derecho a voto.",
          "Todo afiliado con una antigüedad mínima de seis meses podrá presentar su candidatura a integrar la lista electoral, siempre que cumpla los requisitos legales aplicables.",
          "La Junta Directiva garantizará que las listas reflejen la diversidad del municipio en cuanto a género, origen y ámbito territorial.",
        ],
      },
    ],
  },
  {
    num: "VII",
    titulo: "Régimen disciplinario",
    articulos: [
      {
        num: "17",
        titulo: "Infracciones",
        texto: [
          "Se consideran infracciones muy graves: el incumplimiento reiterado y deliberado de los estatutos, la revelación de información confidencial del partido, la vulneración del código ético y el comportamiento contrario a los principios de no discriminación del artículo 5.",
          "Se consideran infracciones graves: el incumplimiento de los acuerdos de los órganos del partido, la falta de respeto a otros afiliados y el impago reiterado de cuotas.",
          "Se consideran infracciones leves: las faltas de asistencia injustificadas y el incumplimiento de las obligaciones menores establecidas en el reglamento interno.",
        ],
      },
      {
        num: "18",
        titulo: "Sanciones y procedimiento",
        texto: [
          "Las sanciones aplicables serán, en función de la gravedad: apercibimiento escrito, suspensión temporal de derechos de afiliado por un período de entre uno y doce meses, o expulsión del partido.",
          "Ninguna sanción se aplicará sin la apertura previa de un expediente disciplinario, en el que el afiliado afectado tendrá derecho a ser escuchado y a presentar las alegaciones que estime oportunas.",
          "Contra la resolución disciplinaria cabrá recurso ante la Asamblea General en el plazo de quince días desde su notificación.",
        ],
      },
    ],
  },
  {
    num: "VIII",
    titulo: "Modificación de estatutos y disolución",
    articulos: [
      {
        num: "19",
        titulo: "Modificación de estatutos",
        texto: [
          "Los presentes estatutos podrán ser modificados por la Asamblea General mediante acuerdo adoptado con el voto favorable de al menos dos tercios de los afiliados presentes o representados.",
          "Toda propuesta de modificación deberá ser comunicada a los afiliados con al menos treinta días de antelación a la celebración de la Asamblea.",
        ],
      },
      {
        num: "20",
        titulo: "Disolución",
        texto: [
          "La disolución del partido se acordará por la Asamblea General con el voto favorable de las dos terceras partes de los afiliados, o por resolución judicial firme en los términos previstos en la Ley Orgánica de Partidos Políticos.",
          "En caso de disolución, el patrimonio del partido, una vez satisfechas las deudas pendientes, se destinará a una entidad de carácter social o cultural radicada en el municipio de San Fulgencio, según acuerde la propia Asamblea de disolución.",
        ],
      },
      {
        num: "21",
        titulo: "Entrada en vigor",
        texto: [
          "Los presentes estatutos entrarán en vigor desde la fecha de su inscripción en el Registro de Partidos Políticos del Ministerio del Interior, una vez cumplidos los trámites legalmente previstos.",
        ],
      },
    ],
  },
];

export default function Estatutos() {
  const [abierto, setAbierto] = useState<string | null>("I");

  return (
    <section id="estatutos" className="bg-cal scroll-mt-20 min-h-screen">
      {/* Cabecera */}
      <div className="bg-verde text-cal">
        <div className="mx-auto w-full max-w-[1440px] px-5 pt-28 pb-16 sm:px-8 lg:px-14">
          <Reveal>
            <p className="label text-brasa">Documento fundacional</p>
            <h1 className="display mt-4 text-[clamp(2.8rem,8vw,6.5rem)] font-black leading-[0.88] tracking-[-0.03em] text-cal">
              Estatutos
              <br />
              <em className="text-naranja not-italic">del partido</em>
            </h1>
            <p className="mt-6 max-w-2xl text-[1.0625rem] leading-relaxed text-cal/80">
              Los estatutos son la ley interna del partido: definen qué somos, cómo tomamos
              decisiones, cómo nos financiamos y cómo garantizamos los derechos de cada afiliado.
              Versión aprobada por la Asamblea General fundacional de Unidos por San Fulgencio.
            </p>
          </Reveal>

          {/* Meta ficha */}
          <Reveal delay={120}>
            <div className="mt-10 flex flex-wrap gap-6 border-t border-cal/25 pt-7">
              {[
                { k: "Capítulos", v: "VIII" },
                { k: "Artículos", v: "21" },
                { k: "Vigencia", v: "2025" },
                { k: "Inscripción", v: "Pendiente · Min. Interior" },
              ].map((f) => (
                <div key={f.k} className="border-l-2 border-naranja pl-4">
                  <p className="display tabular text-[1.6rem] font-black leading-none text-cal">
                    {f.v}
                  </p>
                  <p className="label mt-1 text-cal/60">{f.k}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>

      {/* Contenido acordeón */}
      <div className="mx-auto w-full max-w-[1440px] px-5 py-16 sm:px-8 lg:px-14 lg:py-24">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)] lg:gap-16">
          {/* Índice lateral sticky */}
          <nav className="lg:sticky lg:top-24 lg:self-start" aria-label="Índice de capítulos">
            <p className="label text-taupe">Índice</p>
            <ul className="mt-4 space-y-1">
              {estatutos.map((cap) => (
                <li key={cap.num}>
                  <button
                    onClick={() => setAbierto(cap.num === abierto ? null : cap.num)}
                    className={`w-full text-left px-3 py-3 border-l-4 transition text-[0.9rem] leading-snug ${
                      abierto === cap.num
                        ? "border-naranja bg-naranja/10 font-semibold text-tinta"
                        : "border-transparent text-tinta/60 hover:border-tinta/30 hover:text-tinta"
                    }`}
                  >
                    <span className="label mr-2 text-naranja">Cap. {cap.num}</span>
                    {cap.titulo}
                  </button>
                </li>
              ))}
            </ul>

            {/* Aviso legal */}
            <div className="mt-8 border border-dashed border-tinta/25 p-4">
              <p className="text-[0.78rem] leading-relaxed text-taupe">
                Documento de estatutos del partido político Unidos por San Fulgencio (UpSF),
                redactado conforme a la Ley Orgánica 6/2002 de Partidos Políticos.
                Pendiente de inscripción en el Registro de Partidos Políticos.
              </p>
            </div>
          </nav>

          {/* Capítulos */}
          <div className="space-y-3">
            {estatutos.map((cap) => {
              const isOpen = abierto === cap.num;
              return (
                <Reveal key={cap.num}>
                  <div className={`border ${isOpen ? "border-naranja/40" : "border-tinta/20"} transition-colors`}>
                    <button
                      onClick={() => setAbierto(isOpen ? null : cap.num)}
                      className="w-full cursor-pointer px-6 py-5 text-left flex items-center justify-between gap-4 hover:bg-cal2/60 transition"
                      aria-expanded={isOpen}
                    >
                      <div>
                        <span className="label text-naranja">Capítulo {cap.num}</span>
                        <p className="display mt-1 text-[1.3rem] font-black leading-tight text-tinta">
                          {cap.titulo}
                        </p>
                      </div>
                      <span
                        className={`shrink-0 text-naranja text-2xl transition-transform ${isOpen ? "rotate-45" : ""}`}
                        aria-hidden="true"
                      >
                        +
                      </span>
                    </button>

                    {isOpen && (
                      <div className="border-t border-naranja/20 px-6 pb-8 pt-6">
                        <div className="space-y-8">
                          {cap.articulos.map((art) => (
                            <div key={art.num} className="grid gap-4 sm:grid-cols-[4rem_minmax(0,1fr)]">
                              <div className="pt-1">
                                <span className="display tabular text-[2.2rem] font-black leading-none text-naranja/40">
                                  {art.num.padStart(2, "0")}
                                </span>
                              </div>
                              <div>
                                <h3 className="display text-[1.1rem] font-black text-tinta">
                                  Art. {art.num}. {art.titulo}
                                </h3>
                                <div className="mt-3 space-y-2">
                                  {art.texto.map((p, pi) => (
                                    <p
                                      key={pi}
                                      className="text-[0.95rem] leading-relaxed text-tinta/75"
                                    >
                                      {p}
                                    </p>
                                  ))}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
