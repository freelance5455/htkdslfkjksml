import { useState, type FormEvent } from "react";
import { Reveal, SectionHead } from "../lib/ui";

type Campo = "nombre" | "email" | "telefono" | "asunto" | "mensaje";
type Errores = Partial<Record<Campo, string>>;

const ASUNTOS = [
  "Propuesta ciudadana",
  "Sugerencia de mejora",
  "Consulta sobre el programa",
  "Quiero afiliarme",
  "Colaborar con UpSF",
  "Problema en el municipio",
  "Otro",
];

// 👉 Sustituye esta dirección por la definitiva cuando la tengas
const CORREO_DESTINO = "contacto@upsanfulgencio.es";

function validar(form: {
  nombre: string;
  email: string;
  asunto: string;
  mensaje: string;
}): Errores {
  const e: Errores = {};
  if (form.nombre.trim().length < 2) e.nombre = "Dinos tu nombre para saber a quién escribimos.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
    e.email = "Necesitamos un correo válido para responderte.";
  if (!form.asunto) e.asunto = "Elige el asunto más parecido a tu consulta.";
  if (form.mensaje.trim().length < 20)
    e.mensaje = "Cuéntanos un poco más: necesitamos al menos una frase completa.";
  return e;
}

export default function Contacto() {
  const [nombre, setNombre] = useState("");
  const [email, setEmail] = useState("");
  const [telefono, setTelefono] = useState("");
  const [asunto, setAsunto] = useState("");
  const [mensaje, setMensaje] = useState("");
  const [errores, setErrores] = useState<Errores>({});
  const [enviado, setEnviado] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const err = validar({ nombre, email, asunto, mensaje });
    setErrores(err);
    if (Object.keys(err).length > 0) return;

    // Construir mailto: como enlace de respaldo
    const cuerpo = encodeURIComponent(
      `Nombre: ${nombre}\nTeléfono: ${telefono || "—"}\n\n${mensaje}`
    );
    const sub = encodeURIComponent(`[UpSF] ${asunto} — ${nombre}`);
    window.location.href = `mailto:${CORREO_DESTINO}?subject=${sub}&body=${cuerpo}`;
    setEnviado(true);
  }

  function campo(
    label: string,
    id: Campo,
    value: string,
    onChange: (v: string) => void,
    extra?: { type?: string; required?: boolean; placeholder?: string }
  ) {
    return (
      <div>
        <label htmlFor={id} className="block text-[0.72rem] font-semibold tracking-[0.14em] text-taupe uppercase">
          {label}
          {extra?.required !== false && (
            <span className="ml-1 text-naranja" aria-label="campo obligatorio">*</span>
          )}
        </label>
        <input
          id={id}
          type={extra?.type ?? "text"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={extra?.placeholder}
          className={`mt-2 w-full border-0 border-b-2 bg-transparent pb-2 text-[0.95rem] text-tinta placeholder:text-taupe/50 focus:outline-none transition ${
            errores[id]
              ? "border-alerta focus:border-alerta"
              : "border-tinta/25 focus:border-naranja"
          }`}
        />
        {errores[id] && (
          <p role="alert" className="mt-1 text-[0.78rem] text-alerta">
            {errores[id]}
          </p>
        )}
      </div>
    );
  }

  return (
    <section id="contacto" className="bg-cal scroll-mt-20 min-h-screen">
      {/* Cabecera */}
      <div className="bg-verde text-cal">
        <div className="mx-auto w-full max-w-[1440px] px-5 pt-28 pb-16 sm:px-8 lg:px-14">
          <Reveal>
            <p className="label text-brasa">Escríbenos</p>
            <h1 className="display mt-4 text-[clamp(2.8rem,8vw,6.5rem)] font-black leading-[0.88] tracking-[-0.03em] text-cal">
              Contacto
            </h1>
            <p className="mt-6 max-w-2xl text-[1.0625rem] leading-relaxed text-cal/80">
              Tus ideas y sugerencias son el motor de este proyecto. Cuéntanos qué mejorarías en el
              municipio, qué problema no encuentra solución o cómo te gustaría colaborar con UpSF.
              Respondemos a todos los mensajes.
            </p>
          </Reveal>
        </div>
      </div>

      <div className="mx-auto w-full max-w-[1440px] px-5 py-16 sm:px-8 lg:px-14 lg:py-24">
        <div className="grid gap-14 lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)] lg:gap-20">

          {/* Formulario */}
          <div>
            {enviado ? (
              <Reveal>
                <div className="border-2 border-naranja bg-naranja/5 p-10 text-center">
                  <span className="text-5xl" role="img" aria-label="Mensaje enviado">☀️</span>
                  <h2 className="display mt-6 text-[2rem] font-black text-tinta">
                    ¡Mensaje recibido!
                  </h2>
                  <p className="mt-3 text-[1rem] leading-relaxed text-tinta/70">
                    Tu cliente de correo ha abierto el mensaje listo para enviar.
                    En cuanto lo enviemos, te responderemos a{" "}
                    <strong className="text-tinta">{email}</strong> lo antes posible.
                  </p>
                  <button
                    onClick={() => {
                      setNombre(""); setEmail(""); setTelefono("");
                      setAsunto(""); setMensaje(""); setEnviado(false);
                    }}
                    className="label mt-8 inline-block cursor-pointer bg-tinta px-8 py-4 text-cal hover:bg-naranja transition"
                  >
                    Enviar otro mensaje
                  </button>
                </div>
              </Reveal>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-8">
                <Reveal>
                  <SectionHead
                    eyebrow="Formulario de contacto"
                    titulo="Tu voz importa"
                    entrada="Rellena el formulario con tu consulta, propuesta o idea. Se abrirá tu cliente de correo con el mensaje preparado para enviarlo."
                  />
                </Reveal>

                <Reveal delay={80}>
                  <div className="grid gap-8 sm:grid-cols-2">
                    {campo("Tu nombre", "nombre", nombre, setNombre, { placeholder: "Amparo Martínez" })}
                    {campo("Tu correo electrónico", "email", email, setEmail, {
                      type: "email",
                      placeholder: "amparo@ejemplo.com",
                    })}
                  </div>
                </Reveal>

                <Reveal delay={120}>
                  <div className="grid gap-8 sm:grid-cols-2">
                    {campo("Teléfono (opcional)", "telefono", telefono, setTelefono, {
                      type: "tel",
                      required: false,
                      placeholder: "966 79 42 00",
                    })}
                    <div>
                      <label htmlFor="asunto" className="block text-[0.72rem] font-semibold tracking-[0.14em] text-taupe uppercase">
                        Asunto <span className="ml-1 text-naranja" aria-label="campo obligatorio">*</span>
                      </label>
                      <select
                        id="asunto"
                        value={asunto}
                        onChange={(e) => setAsunto(e.target.value)}
                        className={`mt-2 w-full border-0 border-b-2 bg-transparent pb-2 text-[0.95rem] text-tinta focus:outline-none transition appearance-none cursor-pointer ${
                          errores.asunto
                            ? "border-alerta"
                            : "border-tinta/25 focus:border-naranja"
                        }`}
                      >
                        <option value="">— Elige una opción —</option>
                        {ASUNTOS.map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                      {errores.asunto && (
                        <p role="alert" className="mt-1 text-[0.78rem] text-alerta">
                          {errores.asunto}
                        </p>
                      )}
                    </div>
                  </div>
                </Reveal>

                <Reveal delay={160}>
                  <div>
                    <label htmlFor="mensaje" className="block text-[0.72rem] font-semibold tracking-[0.14em] text-taupe uppercase">
                      Tu mensaje o propuesta <span className="ml-1 text-naranja" aria-label="campo obligatorio">*</span>
                    </label>
                    <textarea
                      id="mensaje"
                      value={mensaje}
                      onChange={(e) => setMensaje(e.target.value)}
                      rows={6}
                      maxLength={1200}
                      placeholder="Cuéntanos con detalle tu idea, propuesta o problema. Cuanto más concreto seas, mejor podremos ayudarte."
                      className={`mt-2 w-full resize-none border-0 border-b-2 bg-transparent pb-2 text-[0.95rem] leading-relaxed text-tinta placeholder:text-taupe/50 focus:outline-none transition ${
                        errores.mensaje
                          ? "border-alerta"
                          : "border-tinta/25 focus:border-naranja"
                      }`}
                    />
                    <div className="mt-1 flex items-start justify-between gap-4">
                      {errores.mensaje ? (
                        <p role="alert" className="text-[0.78rem] text-alerta">{errores.mensaje}</p>
                      ) : (
                        <p className="text-[0.78rem] text-taupe">Mínimo 20 caracteres.</p>
                      )}
                      <p className="label shrink-0 text-taupe">{mensaje.length} / 1200</p>
                    </div>
                  </div>
                </Reveal>

                <Reveal delay={200}>
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
                    <button
                      type="submit"
                      className="label cursor-pointer bg-tinta px-8 py-4 text-cal transition hover:bg-naranja"
                    >
                      Enviar mensaje →
                    </button>
                    <p className="text-[0.78rem] leading-snug text-taupe">
                      Se abrirá tu aplicación de correo con el mensaje preparado.
                      Tu dirección será{" "}
                      <span className="text-tinta">{CORREO_DESTINO}</span>.
                    </p>
                  </div>
                </Reveal>
              </form>
            )}
          </div>

          {/* Columna lateral de info */}
          <Reveal delay={80} className="lg:sticky lg:top-24 lg:self-start">
            <div className="space-y-6">
              <div className="border border-tinta/20 bg-cal2 p-6">
                <p className="label text-naranja">Ayuntamiento</p>
                <p className="display mt-3 text-[1.3rem] font-black text-tinta">
                  San Fulgencio
                </p>
                <div className="mt-4 space-y-2 text-[0.92rem] text-tinta/70">
                  <p>Plaza Constitución, 26</p>
                  <p>03177 San Fulgencio · Alicante</p>
                  <a href="tel:+34966794201" className="block font-semibold text-tinta hover:text-naranja transition">
                    966 79 42 01
                  </a>
                  <a href="https://www.sanfulgencio.es" target="_blank" rel="noopener noreferrer"
                    className="block hover:text-naranja transition">
                    sanfulgencio.es
                  </a>
                </div>
              </div>

              <div className="border border-tinta/20 bg-cal2 p-6">
                <p className="label text-naranja">Escríbenos directamente</p>
                <p className="mt-3 text-[0.9rem] leading-relaxed text-tinta/70">
                  Si prefieres escribirnos directamente sin el formulario:
                </p>
                <a
                  href={`mailto:${CORREO_DESTINO}`}
                  className="mt-3 block text-[0.95rem] font-semibold text-tinta hover:text-naranja transition break-all"
                >
                  {CORREO_DESTINO}
                </a>
              </div>

              <div className="border border-naranja/40 bg-naranja/5 p-6">
                <p className="label text-naranja">¿Quieres unirte a UpSF?</p>
                <p className="mt-3 text-[0.9rem] leading-relaxed text-tinta/70">
                  Si quieres formar parte del equipo o afiliarte al partido, escríbenos
                  indicando «Quiero afiliarme» en el asunto. Es el primer paso.
                </p>
              </div>

              <div className="border border-tinta/15 p-6">
                <p className="label text-taupe">Horario de atención</p>
                <div className="mt-4 space-y-2 text-[0.88rem] text-tinta/70">
                  <div className="flex justify-between">
                    <span>Lunes – Viernes</span>
                    <span className="font-semibold text-tinta">10:00 – 14:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tardes</span>
                    <span className="font-semibold text-tinta">17:00 – 19:30</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sábados</span>
                    <span className="font-semibold text-tinta">10:00 – 13:00</span>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
