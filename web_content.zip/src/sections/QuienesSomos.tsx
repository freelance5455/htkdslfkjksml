import { Reveal, SectionHead } from "../lib/ui";

type Miembro = {
  nombre: string;
  cargo: string;
  bio: string;
  pendiente?: boolean;
};

const miembros: Miembro[] = [
  {
    nombre: "Alain García Baeza",
    cargo: "Fundador y candidato a la Alcaldía",
    bio: "Vecino de San Fulgencio comprometido con el progreso del municipio y la participación ciudadana. Impulsor del proyecto Unidos por San Fulgencio para dar voz a todos los residentes del término, independientemente de su origen.",
  },
  {
    nombre: "Conchi García Baeza",
    cargo: "Responsable de Comunicación",
    bio: "Pieza clave en la construcción del proyecto UpSF. Trabaja para que la información llegue a todos los vecinos de forma clara, transparente y en los idiomas del municipio.",
  },
  {
    nombre: "Por confirmar",
    cargo: "—",
    bio: "Este puesto estará ocupado próximamente. Si quieres formar parte del equipo de Unidos por San Fulgencio, escríbenos a través del formulario de contacto.",
    pendiente: true,
  },
  {
    nombre: "Por confirmar",
    cargo: "—",
    bio: "Este puesto estará ocupado próximamente. Si quieres formar parte del equipo de Unidos por San Fulgencio, escríbenos a través del formulario de contacto.",
    pendiente: true,
  },
  {
    nombre: "Por confirmar",
    cargo: "—",
    bio: "Este puesto estará ocupado próximamente. Si quieres formar parte del equipo de Unidos por San Fulgencio, escríbenos a través del formulario de contacto.",
    pendiente: true,
  },
  {
    nombre: "Por confirmar",
    cargo: "—",
    bio: "Este puesto estará ocupado próximamente. Si quieres formar parte del equipo de Unidos por San Fulgencio, escríbenos a través del formulario de contacto.",
    pendiente: true,
  },
];

function Inicial({ nombre, pendiente }: { nombre: string; pendiente?: boolean }) {
  if (pendiente) {
    return (
      <div className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-dashed border-tinta/30">
        <span className="label text-tinta/40">?</span>
      </div>
    );
  }
  const partes = nombre.split(" ");
  const iniciales = partes.length >= 2 ? partes[0][0] + partes[1][0] : partes[0][0];
  return (
    <div className="flex h-20 w-20 items-center justify-center rounded-full bg-naranja/15 border-2 border-naranja/40">
      <span
        className="display text-[1.6rem] font-black leading-none select-none"
        style={{ color: "var(--color-naranja)" }}
      >
        {iniciales.toUpperCase()}
      </span>
    </div>
  );
}

export default function QuienesSomos() {
  return (
    <section id="quienes-somos" className="bg-cal scroll-mt-20">
      {/* Hero interior */}
      <div className="bg-verde text-cal">
        <div className="mx-auto w-full max-w-[1440px] px-5 pt-28 pb-16 sm:px-8 lg:px-14">
          <Reveal>
            <p className="label text-brasa">El equipo</p>
            <h1 className="display mt-4 text-[clamp(2.8rem,8vw,6.5rem)] font-black leading-[0.88] tracking-[-0.03em] text-cal">
              Quiénes
              <br />
              <em className="text-naranja not-italic">somos</em>
            </h1>
            <p className="mt-6 max-w-2xl text-[1.0625rem] leading-relaxed text-cal/80">
              Unidos por San Fulgencio es un proyecto vecinal que nace de la convicción de que el
              municipio merece una representación honesta, cercana y de puertas abiertas. Somos
              vecinos de San Fulgencio — de aquí de siempre y de los que llegaron hace años — que
              decidimos dar un paso adelante.
            </p>
          </Reveal>
        </div>
      </div>

      {/* Grid de miembros */}
      <div className="mx-auto w-full max-w-[1440px] px-5 py-16 sm:px-8 lg:px-14 lg:py-24">
        <Reveal>
          <SectionHead
            eyebrow="Nuestro equipo · 2025"
            titulo="Las personas detrás del proyecto"
            entrada="Seis vecinos que ponen nombre y cara. Transparencia desde el primer día."
          />
        </Reveal>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {miembros.map((m, i) => (
            <Reveal key={m.nombre + i} delay={i * 70}>
              <article
                className={`flex h-full flex-col p-6 border transition ${
                  m.pendiente
                    ? "border-dashed border-tinta/25 bg-cal2/60"
                    : "border-tinta/20 bg-white/70 hover:-translate-y-1 hover:border-naranja/50 hover:shadow-[4px_4px_0_rgba(192,144,51,0.15)]"
                }`}
              >
                <div className="flex items-center gap-4">
                  <Inicial nombre={m.nombre} pendiente={m.pendiente} />
                  <div>
                    <h3
                      className={`display text-[1.15rem] font-black leading-tight ${
                        m.pendiente ? "text-tinta/40" : "text-tinta"
                      }`}
                    >
                      {m.nombre}
                    </h3>
                    <p
                      className={`label mt-1 ${
                        m.pendiente ? "text-tinta/30" : "text-naranja"
                      }`}
                    >
                      {m.cargo}
                    </p>
                  </div>
                </div>
                <p
                  className={`mt-5 flex-1 text-[0.94rem] leading-relaxed ${
                    m.pendiente ? "text-tinta/40 italic" : "text-tinta/75"
                  }`}
                >
                  {m.bio}
                </p>
                {!m.pendiente && (
                  <div className="mt-5 border-t border-tinta/15 pt-4">
                    <a
                      href="#contacto"
                      className="label text-naranja hover:text-tinta transition"
                    >
                      Contactar →
                    </a>
                  </div>
                )}
              </article>
            </Reveal>
          ))}
        </div>

        {/* Valores */}
        <Reveal>
          <div className="mt-20 border-t border-tinta/20 pt-14">
            <p className="label text-taupe">Lo que nos une</p>
            <div className="mt-8 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {[
                {
                  icono: "☀️",
                  t: "Transparencia",
                  d: "Cuentas claras, decisiones explicadas y puertas abiertas.",
                },
                {
                  icono: "🤝",
                  t: "Inclusión",
                  d: "El municipio es de todos: españoles, británicos, alemanes y de cualquier origen.",
                },
                {
                  icono: "🌱",
                  t: "Sostenibilidad",
                  d: "Proteger la vega, las salinas y el patrimonio natural del Segura.",
                },
                {
                  icono: "📣",
                  t: "Participación",
                  d: "Las ideas de los vecinos no son sugerencias: son el programa.",
                },
              ].map((v) => (
                <div
                  key={v.t}
                  className="border-t-4 border-naranja pt-5"
                >
                  <span className="text-3xl" role="img" aria-label={v.t}>
                    {v.icono}
                  </span>
                  <h3 className="display mt-3 text-[1.25rem] font-black text-tinta">{v.t}</h3>
                  <p className="mt-2 text-[0.9rem] leading-relaxed text-tinta/70">{v.d}</p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
