import { initializeSeasonCompetitions } from './season-competitions.js';
import { applyPromotionRelegation, activateExpansions, standings } from './league.js';
import { validateState } from './store.js';

function seasonFixtures(state, season) {
  return state.calendar.fixtures.filter(f => Number(f.season) === Number(season));
}
function isSeasonResolved(state, season) {
  return seasonFixtures(state, season).every(f => f.status === 'played' || f.status === 'cancelled');
}
function resetClubSeasonStats(club) {
  Object.assign(club, { played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, points: 0 });
  club.competitionStats = {};
}
function resetCompetitionForNextSeason(competition) {
  competition.season = null;
  competition.status = 'pending';
  competition.phase = 'pending';
  competition.championId = null;
  competition.rounds = [];
  competition.fixtures = [];
  competition.groups = [];
  competition.format = null;
  competition.fixturesGenerated = false;
}

/** Clôture administrative et ouverture automatique de la saison suivante.
 * Les résultats et les rencontres historiques restent conservés dans le calendrier.
 */
export function startNextSeason(state) {
  const completedSeason = Number(state.season || 1);
  const existing = state.history?.seasons?.find(row => row.season === completedSeason);
  if (existing?.transitionedTo === completedSeason + 1) {
    return { advanced: false, reason: 'already-transitioned', season: state.season };
  }
  if (state.dameOr?.seasons?.[completedSeason]?.status !== 'completed') {
    return { advanced: false, reason: 'dame-or-not-closed', season: state.season };
  }
  if (!isSeasonResolved(state, completedSeason)) {
    return { advanced: false, reason: 'pending-fixtures', season: state.season,
      pendingFixtureIds: seasonFixtures(state, completedSeason).filter(f => f.status !== 'played' && f.status !== 'cancelled').map(f => f.id) };
  }

  state.history ??= { seasons: [], awards: [], notices: [] };
  state.history.seasons ??= [];
  const table = state.divisions.filter(d => d.status === 'active').map(division => ({
    divisionId: division.id,
    divisionName: division.name,
    standings: standings(division).map((club, index) => ({
      rank: index + 1, clubId: club.id, clubName: club.name,
      played: club.played, won: club.won, drawn: club.drawn, lost: club.lost,
      gf: club.gf, ga: club.ga, points: club.points
    }))
  }));
  const archive = existing || { season: completedSeason };
  archive.completedAtDay = state.calendar.currentDay;
  archive.divisions = table;
  archive.dameOrWinnerId = state.dameOr.seasons[completedSeason].winnerId ?? null;
  archive.transitionedTo = completedSeason + 1;
  if (!existing) state.history.seasons.push(archive);

  const movements = applyPromotionRelegation(state);
  state.season = completedSeason + 1;
  state.day = 1;
  state.phase = 'regular-season';
  for (const division of state.divisions) for (const club of division.clubs) resetClubSeasonStats(club);

  // Le moteur prépare les divisions prévues à cette échéance, sans intervention du manager.
  activateExpansions(state);

  // On conserve toutes les anciennes rencontres comme archives, mais on remet à zéro
  // le calendrier opérationnel et les compétitions pour que l'application les régénère.
  state.calendar.currentDay = 1;
  state.calendar.currentDate = { season: state.season, seasonDay: 1 };
  state.calendar.competitionEvents = [];
  state.calendar.officialCalendars = {};
  state.calendar.lunarThursdays = [];
  state.calendar.generatedCalendar = null;
  state.calendar.scheduleValidation = null;
  state.calendar.lastGeneratedSeason = null;
  state.calendar.processedFixtureIds ??= [];
  for (const competition of state.competitions || []) resetCompetitionForNextSeason(competition);
  initializeSeasonCompetitions(state);
  state.history.notices ??= [];
  state.history.notices.push({ season: state.season, type: 'season-opened', text: `La saison ${state.season} est automatiquement ouverte.`, movements });
  validateState(state);
  return { advanced: true, completedSeason, season: state.season, movements,
    fixturesGenerated: seasonFixtures(state, state.season).length, divisions: state.divisions.filter(d => d.status === 'active').map(d => d.id) };
}
