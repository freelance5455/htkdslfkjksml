import { Bookmark, Download, Film, Loader2, RotateCcw, Save, Share2, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button, Field, Modal, Section, Segmented, TextInput } from "../../components/ui";
import { db } from "../../lib/db";
import { bitrateFor, exportRealtime, exportWebCodecs, hasWebCodecs, projectDuration, videoSupport, type ExportJob, type ExportResult } from "../../lib/exporter";
import type { BgSource } from "../../lib/renderer";
import { canvasSize, getTemplate, reId } from "../../lib/templates";
import type { Aspect, Background, Project, SavedDesign } from "../../lib/types";
import { deepClone, downloadBlob, fmtBytes, fmtTime, uid } from "../../lib/util";
import type { Updater } from "../state";

interface PP {
  project: Project;
  update: Updater;
  saveNow: () => Promise<void>;
  captureThumb: () => string | undefined;
  toast: (m: string) => void;
}

export function ProjectPanel({ project, update, saveNow, captureThumb, toast }: PP) {
  const [designs, setDesigns] = useState<SavedDesign[]>([]);
  const [dname, setDname] = useState("");
  useEffect(() => {
    db.listDesigns().then((l) => setDesigns(l.sort((a, b) => b.createdAt - a.createdAt)));
  }, []);

  const saveDesign = async () => {
    const d: SavedDesign = {
      id: uid(),
      name: dname.trim() || `${project.name} look`,
      createdAt: Date.now(),
      thumbnail: captureThumb(),
      templateId: project.templateId,
      background: deepClone(project.background),
      effects: deepClone(project.effects),
      layers: deepClone(project.layers),
    };
    await db.putDesign(d);
    setDesigns((l) => [d, ...l]);
    setDname("");
    toast("Saved to Saved Designs");
  };

  return (
    <div>
      <Section title="Project">
        <Field label="Name">
          <TextInput value={project.name} onChange={(e) => update((p) => ({ ...p, name: e.target.value }), "name")} />
        </Field>
        <Field label="Canvas aspect ratio">
          <Segmented
            value={project.aspect}
            onChange={(v: Aspect) => update((p) => ({ ...p, aspect: v }))}
            options={[
              { value: "16:9", label: "16:9" },
              { value: "9:16", label: "9:16" },
              { value: "1:1", label: "1:1" },
              { value: "4:5", label: "4:5" },
            ]}
          />
        </Field>
        <p className="text-[11px] text-zinc-500">Positions are stored as percentages, so layers keep their place when you change the aspect ratio. Resize them afterwards if needed.</p>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="primary" size="sm" onClick={async () => (await saveNow(), toast("Project saved"))}>
            <Save size={14} /> Save now
          </Button>
          <Button
            variant="soft"
            size="sm"
            onClick={() => {
              const t = getTemplate(project.templateId);
              if (!t) return;
              update((p) => ({ ...p, layers: reId(deepClone(t.layers)), background: deepClone(t.background), effects: deepClone(t.effects) }));
              toast("Reset to template look (undo available)");
            }}
          >
            <RotateCcw size={14} /> Reset look
          </Button>
        </div>
      </Section>
      <Section title="Saved designs">
        <div className="flex gap-2">
          <TextInput placeholder="Design name" value={dname} onChange={(e) => setDname(e.target.value)} />
          <Button variant="soft" size="sm" onClick={saveDesign}>
            <Bookmark size={14} /> Save
          </Button>
        </div>
        <p className="text-[11px] text-zinc-500">Saves layers, background and effects (not audio or lyrics) as a reusable look.</p>
        {designs.length === 0 && <p className="text-xs text-zinc-500">Nothing saved yet.</p>}
        <div className="grid grid-cols-2 gap-2">
          {designs.map((d) => (
            <button
              key={d.id}
              onClick={() => {
                update((p) => ({ ...p, layers: reId(deepClone(d.layers)), background: deepClone(d.background), effects: deepClone(d.effects) }));
                toast(`Applied “${d.name}”`);
              }}
              className="overflow-hidden rounded-xl border border-white/10 bg-ink-700 text-left hover:border-accent"
            >
              <div className="aspect-video bg-ink-600">{d.thumbnail && <img src={d.thumbnail} alt="" className="h-full w-full object-cover" />}</div>
              <div className="truncate px-2 py-1.5 text-xs">{d.name}</div>
            </button>
          ))}
        </div>
      </Section>
    </div>
  );
}

// -------------------------------------------------------------- export

async function makeBgGetter(bg: Background): Promise<{ get: (t: number) => Promise<BgSource>; dispose: () => void }> {
  const none = { get: async () => null as BgSource, dispose: () => {} };
  if (!bg.mediaId || (bg.type !== "image" && bg.type !== "video")) return none;
  const rec = await db.getMedia(bg.mediaId);
  if (!rec) return none;
  const url = URL.createObjectURL(rec.blob);
  if (bg.type === "image") {
    const img = new Image();
    await new Promise<void>((res, rej) => {
      img.onload = () => res();
      img.onerror = () => rej(new Error("Background image failed to load"));
      img.src = url;
    });
    return { get: async () => img, dispose: () => URL.revokeObjectURL(url) };
  }
  const v = document.createElement("video");
  v.muted = true;
  v.playsInline = true;
  v.preload = "auto";
  v.src = url;
  await new Promise<void>((res, rej) => {
    v.onloadeddata = () => res();
    v.onerror = () => rej(new Error("Background video failed to load"));
  });
  return {
    get: async (t: number) => {
      const target = t % (v.duration || 1);
      if (Math.abs(v.currentTime - target) > 0.001) {
        await new Promise<void>((res) => {
          const h = () => {
            v.removeEventListener("seeked", h);
            res();
          };
          v.addEventListener("seeked", h);
          v.currentTime = target;
          setTimeout(res, 1500);
        });
      }
      return v;
    },
    dispose: () => URL.revokeObjectURL(url),
  };
}

interface EP {
  project: Project;
  update: Updater;
  getBuffer: () => Promise<AudioBuffer | null>;
  toast: (m: string) => void;
}

export function ExportPanel({ project, update, getBuffer }: EP) {
  const s = project.export;
  const [open, setOpen] = useState(false);
  const [sup, setSup] = useState<Record<number, boolean>>({});
  const [h265, setH265] = useState(true);
  const duration = projectDuration(project);
  const [W, H] = canvasSize(project.aspect, s.resolution);
  const set = (patch: Partial<Project["export"]>) => update((p) => ({ ...p, export: { ...p.export, ...patch } }));

  useEffect(() => {
    let alive = true;
    (async () => {
      const out: Record<number, boolean> = {};
      for (const r of [720, 1080, 1440, 2160]) {
        const [w, h] = canvasSize(project.aspect, r);
        out[r] = await videoSupport(s.codec, w, h, s.fps);
      }
      const [w, h] = canvasSize(project.aspect, s.resolution);
      const h5 = await videoSupport("h265", w, h, s.fps);
      if (alive) {
        setSup(out);
        setH265(h5);
      }
    })();
    return () => {
      alive = false;
    };
  }, [s.codec, s.fps, s.resolution, project.aspect]);

  const wc = hasWebCodecs();
  const br = bitrateFor(s, W, H);
  const est = (br * duration) / 8 + 192000 * duration / 8;
  const resOpt = (r: 720 | 1080 | 1440 | 2160, label: string) => ({ value: r, label, disabled: wc && sup[r] === false, title: wc && sup[r] === false ? "Not supported by this device's encoder" : undefined });

  return (
    <div>
      <Section title="Video export">
        <Field label="Resolution" hint={`${W}×${H}`}>
          <Segmented value={s.resolution} onChange={(v) => set({ resolution: v })} options={[resOpt(720, "720p"), resOpt(1080, "1080p"), resOpt(1440, "1440p"), resOpt(2160, "4K")]} />
        </Field>
        {wc && Object.values(sup).some((v) => v === false) && <p className="text-[11px] text-amber-300/80">Greyed-out sizes are not supported by this device’s {s.codec === "h264" ? "H.264" : "H.265"} encoder at {s.fps} fps.</p>}
        <Field label="Frame rate">
          <Segmented value={s.fps} onChange={(v) => set({ fps: v })} options={[24, 30, 60].map((v) => ({ value: v as 24 | 30 | 60, label: v + " fps" }))} />
        </Field>
        <Field label="Codec (MP4)">
          <Segmented value={s.codec} onChange={(v) => set({ codec: v })} options={[{ value: "h264", label: "H.264" }, { value: "h265", label: "H.265 / HEVC", disabled: wc && !h265 && s.codec !== "h265" }]} />
        </Field>
        <Field label="Quality">
          <Segmented value={s.quality} onChange={(v) => set({ quality: v })} options={[{ value: "standard", label: "Standard" }, { value: "high", label: "High" }, { value: "max", label: "Maximum" }]} />
        </Field>
        <div className="rounded-xl bg-ink-700 p-3 text-xs text-zinc-400">
          <div className="flex justify-between"><span>Length</span><span className="text-zinc-200">{fmtTime(duration, true)} · {Math.round(duration * s.fps)} frames</span></div>
          <div className="flex justify-between"><span>Video bitrate</span><span className="text-zinc-200">{(br / 1e6).toFixed(1)} Mbps</span></div>
          <div className="flex justify-between"><span>Estimated size</span><span className="text-zinc-200">~{fmtBytes(est)}</span></div>
          <div className="flex justify-between"><span>Audio</span><span className="text-zinc-200">AAC 192 kbps stereo</span></div>
        </div>
        {!wc && <p className="rounded-lg bg-amber-500/10 p-3 text-xs text-amber-300">WebCodecs isn’t available in this browser. Export will record in real time (up to 1080p), and the screen must stay on.</p>}
        {s.resolution >= 1440 && <p className="text-[11px] text-zinc-500">High resolutions need lots of RAM because the MP4 is assembled in memory. Short clips are safest on phones.</p>}
        <Button variant="primary" size="lg" className="w-full" onClick={() => setOpen(true)}>
          <Film size={18} /> Render MP4
        </Button>
      </Section>
      {open && <ExportDialog project={project} getBuffer={getBuffer} onClose={() => setOpen(false)} />}
    </div>
  );
}

type Phase = "idle" | "running" | "done" | "error";

function ExportDialog({ project, getBuffer, onClose }: { project: Project; getBuffer: () => Promise<AudioBuffer | null>; onClose: () => void }) {
  const [phase, setPhase] = useState<Phase>("idle");
  const [prog, setProg] = useState({ frame: 0, total: 1, fraction: 0, eta: 0, phase: "" });
  const [result, setResult] = useState<ExportResult | null>(null);
  const [url, setUrl] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const ac = useRef<AbortController | null>(null);
  const wc = hasWebCodecs();

  useEffect(
    () => () => {
      if (url) URL.revokeObjectURL(url);
    },
    [url]
  );
  useEffect(() => () => ac.current?.abort(), []);

  const run = async (realtime: boolean) => {
    setPhase("running");
    setErr("");
    setProg({ frame: 0, total: 1, fraction: 0, eta: 0, phase: "Preparing…" });
    const ctrl = new AbortController();
    ac.current = ctrl;
    let bgg: Awaited<ReturnType<typeof makeBgGetter>> | null = null;
    try {
      const audio = await getBuffer();
      bgg = await makeBgGetter(project.background);
      const job: ExportJob = { project, audio, getBg: bgg.get, signal: ctrl.signal, onProgress: setProg };
      const res = realtime || !wc ? await exportRealtime(job) : await exportWebCodecs(job);
      setResult(res);
      setUrl(URL.createObjectURL(res.blob));
      setPhase("done");
    } catch (e) {
      if ((e as DOMException).name === "AbortError") {
        setPhase("idle");
      } else {
        setErr((e as Error).message || String(e));
        setPhase("error");
      }
    } finally {
      bgg?.dispose();
    }
  };

  const fileName = () => `${project.name.replace(/[^\w\- ]+/g, "").trim() || "visualizer"}-${result?.width}x${result?.height}.${result?.ext ?? "mp4"}`;

  const share = async () => {
    if (!result) return;
    const f = new File([result.blob], fileName(), { type: result.mime.split(";")[0] });
    const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
    if (nav.canShare?.({ files: [f] })) {
      try {
        await nav.share({ files: [f], title: project.name });
      } catch {
        /* cancelled */
      }
    } else downloadBlob(result.blob, fileName());
  };

  return (
    <Modal open onClose={() => phase !== "running" && onClose()} title="Render video">
      {phase === "idle" && (
        <div className="space-y-4">
          <p className="text-sm text-zinc-400">
            {wc
              ? "Frames are rendered offline, frame-by-frame, from the real FFT of your audio, then encoded on-device to MP4 (H.264/H.265 + AAC). Audio and video timestamps come from the same clock, so they stay in sync. Keep this tab open."
              : "Real-time capture mode: the project plays once while the browser records it. Keep the tab visible until finished."}
          </p>
          <div className="flex justify-end gap-2">
            <Button onClick={onClose}>Close</Button>
            <Button variant="primary" onClick={() => run(false)}>
              <Film size={16} /> Start rendering
            </Button>
          </div>
        </div>
      )}
      {phase === "running" && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm">
            <Loader2 size={16} className="animate-spin text-accent" /> {prog.phase}
          </div>
          <div className="h-3 overflow-hidden rounded-full bg-ink-600">
            <div className="grad-bg h-full transition-all" style={{ width: `${Math.round(prog.fraction * 100)}%` }} />
          </div>
          <div className="flex justify-between text-xs text-zinc-400">
            <span>
              {Math.round(prog.fraction * 100)}% · frame {prog.frame}/{prog.total}
            </span>
            <span>ETA {fmtTime(prog.eta)}</span>
          </div>
          <div className="flex justify-end">
            <Button variant="danger" onClick={() => ac.current?.abort()}>
              <X size={16} /> Cancel rendering
            </Button>
          </div>
        </div>
      )}
      {phase === "error" && (
        <div className="space-y-4">
          <p className="rounded-xl bg-red-500/10 p-3 text-sm text-red-300">{err}</p>
          <div className="flex flex-wrap justify-end gap-2">
            <Button onClick={onClose}>Close</Button>
            <Button variant="soft" onClick={() => setPhase("idle")}>
              Back
            </Button>
            <Button variant="soft" onClick={() => run(true)}>
              Try real-time recording (≤1080p)
            </Button>
          </div>
        </div>
      )}
      {phase === "done" && result && url && (
        <div className="space-y-4">
          <video src={url} controls className="w-full rounded-xl bg-black" style={{ maxHeight: "50vh" }} />
          <div className="text-xs text-zinc-400">
            {result.width}×{result.height} · {fmtTime(result.seconds, true)} · {fmtBytes(result.blob.size)} · {result.ext.toUpperCase()} via {result.method === "webcodecs" ? "WebCodecs (offline, frame-exact)" : "real-time recorder"}
          </div>
          <div className="flex flex-wrap justify-end gap-2">
            <Button onClick={onClose}>Done</Button>
            <Button variant="soft" onClick={share}>
              <Share2 size={16} /> Share / save to gallery
            </Button>
            <Button variant="primary" onClick={() => downloadBlob(result.blob, fileName())}>
              <Download size={16} /> Download
            </Button>
          </div>
          <p className="text-[11px] text-zinc-500">Download saves into your device’s Downloads folder; “Share” lets Android save it straight to Photos/Gallery.</p>
        </div>
      )}
    </Modal>
  );
}
