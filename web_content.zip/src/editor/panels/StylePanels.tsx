import { Image as ImageIcon, Music, RotateCcw, Scissors, Video } from "lucide-react";
import { useState } from "react";
import { Button, ColorField, Field, Section, Segmented, Select, Slider } from "../../components/ui";
import { db } from "../../lib/db";
import { audioFromFile, DEMO_DURATION } from "../../lib/projects";
import { defaultBg, defaultEffects } from "../../lib/templates";
import type { Background, Effects, Project } from "../../lib/types";
import { fmtTime, pickFile } from "../../lib/util";
import type { Updater } from "../state";

export function BackgroundPanel({ project, update, toast }: { project: Project; update: Updater; toast: (m: string) => void }) {
  const bg = project.background;
  const set = (patch: Partial<Background>, key?: string) => update((p) => ({ ...p, background: { ...p.background, ...patch } }), key ?? "bg-" + Object.keys(patch).join());
  const media = bg.type === "image" || bg.type === "video";

  const importMedia = async (kind: "image" | "video") => {
    const f = await pickFile(kind === "image" ? "image/*" : "video/*");
    if (!f) return;
    try {
      const rec = await db.addMedia(f, kind);
      set({ type: kind, mediaId: rec.id, mediaName: rec.name }, "bg-media");
      toast(`${kind === "image" ? "Image" : "Video"} imported`);
    } catch (e) {
      toast("Import failed: " + (e as Error).message);
    }
  };

  return (
    <div>
      <Section title="Background type">
        <Segmented
          value={bg.type}
          onChange={(v) => set({ type: v }, "bg-type")}
          options={[
            { value: "solid", label: "Solid" },
            { value: "gradient", label: "Gradient" },
            { value: "image", label: "Image" },
            { value: "video", label: "Video" },
            { value: "animated", label: "Animated" },
          ]}
        />
        {(bg.type === "solid" || bg.type === "gradient" || bg.type === "animated" || media) && <ColorField label={bg.type === "solid" || media ? "Colour (behind media)" : "Colour 1"} value={bg.color} onChange={(v) => set({ color: v })} />}
        {(bg.type === "gradient" || bg.type === "animated") && <ColorField label="Colour 2" value={bg.color2} onChange={(v) => set({ color2: v })} />}
        {(bg.type === "gradient" || bg.type === "animated") && <Slider label="Gradient angle" value={bg.angle} min={0} max={360} step={1} onChange={(v) => set({ angle: v })} format={(v) => v + "°"} />}
        {bg.type === "animated" && (
          <Field label="Animation">
            <Select
              value={bg.animStyle}
              onChange={(v) => set({ animStyle: v })}
              options={[
                { value: "aurora", label: "Aurora (bass-reactive)" },
                { value: "pulse", label: "Pulse rings" },
                { value: "stars", label: "Twinkling stars" },
                { value: "grid", label: "Retro grid" },
              ]}
            />
          </Field>
        )}
        {media && (
          <div className="grid grid-cols-2 gap-2">
            <Button variant="soft" size="sm" onClick={() => importMedia("image")}>
              <ImageIcon size={14} /> Image…
            </Button>
            <Button variant="soft" size="sm" onClick={() => importMedia("video")}>
              <Video size={14} /> Video…
            </Button>
          </div>
        )}
        {media && !bg.mediaId && <p className="rounded-lg bg-white/5 p-3 text-xs text-zinc-400">Choose a {bg.type} from your gallery / storage. Files stay on this device.</p>}
        {media && bg.mediaId && <p className="truncate text-xs text-zinc-500">Using: {bg.mediaName}</p>}
      </Section>

      <Section title="Adjust" right={<button onClick={() => set(defaultBg({ type: bg.type, color: bg.color, color2: bg.color2, mediaId: bg.mediaId, mediaName: bg.mediaName, animStyle: bg.animStyle, angle: bg.angle }), "bg-reset")} className="flex items-center gap-1 text-[11px] text-zinc-500 hover:text-white"><RotateCcw size={11} /> Reset</button>}>
        {media && (
          <>
            <Segmented value={bg.fit} onChange={(v) => set({ fit: v })} options={[{ value: "cover", label: "Fill (crop)" }, { value: "contain", label: "Fit" }]} />
            <Slider label="Scale / crop zoom" value={bg.scale} min={0.5} max={4} onChange={(v) => set({ scale: v })} format={(v) => v.toFixed(2) + "×"} />
            <Slider label="Position X" value={bg.offsetX} min={-1} max={1} onChange={(v) => set({ offsetX: v })} />
            <Slider label="Position Y" value={bg.offsetY} min={-1} max={1} onChange={(v) => set({ offsetY: v })} />
            <Slider label="Blur" value={bg.blur} min={0} max={40} step={1} onChange={(v) => set({ blur: v })} format={(v) => v + " px"} />
            <Slider label="Opacity" value={bg.opacity} min={0} max={1} onChange={(v) => set({ opacity: v })} format={(v) => Math.round(v * 100) + "%"} />
            <Slider label="Bass zoom (audio reactive)" value={bg.reactiveZoom} min={0} max={1} onChange={(v) => set({ reactiveZoom: v })} />
          </>
        )}
        <Slider label="Darken overlay" value={bg.dim} min={0} max={0.9} onChange={(v) => set({ dim: v })} format={(v) => Math.round(v * 100) + "%"} />
      </Section>
    </div>
  );
}

const FX: { key: keyof Effects; label: string; hint: string }[] = [
  { key: "neonGlow", label: "Neon glow (bloom)", hint: "" },
  { key: "rgb", label: "RGB split", hint: "" },
  { key: "glitch", label: "Glitch (beat-triggered)", hint: "" },
  { key: "blur", label: "Blur", hint: "" },
  { key: "motionBlur", label: "Motion blur (trails)", hint: "" },
  { key: "lightRays", label: "Light rays", hint: "" },
  { key: "particles", label: "Floating particles", hint: "" },
  { key: "waveDistortion", label: "Wave distortion", hint: "" },
  { key: "flash", label: "Beat flash", hint: "" },
  { key: "vignette", label: "Vignette", hint: "" },
];

export function EffectsPanel({ project, update }: { project: Project; update: Updater }) {
  const e = project.effects;
  const set = (patch: Partial<Effects>) => update((p) => ({ ...p, effects: { ...p.effects, ...patch } }), "fx-" + Object.keys(patch).join());
  return (
    <div>
      <Section title="Visual effects" right={<button onClick={() => update((p) => ({ ...p, effects: defaultEffects() }))} className="flex items-center gap-1 text-[11px] text-zinc-500 hover:text-white"><RotateCcw size={11} /> Reset all</button>}>
        {FX.map((f) => (
          <Slider key={f.key} label={f.label} value={e[f.key] as number} min={0} max={1} onChange={(v) => set({ [f.key]: v } as Partial<Effects>)} format={(v) => Math.round(v * 100) + "%"} />
        ))}
        <ColorField label="Light ray colour" value={e.rayColor} onChange={(v) => set({ rayColor: v })} />
        <ColorField label="Particle colour" value={e.particleColor} onChange={(v) => set({ particleColor: v })} />
        <p className="text-[11px] text-zinc-500">Flash, glitch and rays are driven by detected beats in the actual audio.</p>
      </Section>
      <Section title="Color correction">
        <Slider label="Brightness" value={e.brightness} min={0.4} max={1.8} onChange={(v) => set({ brightness: v })} format={(v) => v.toFixed(2)} />
        <Slider label="Contrast" value={e.contrast} min={0.4} max={1.8} onChange={(v) => set({ contrast: v })} format={(v) => v.toFixed(2)} />
        <Slider label="Saturation" value={e.saturation} min={0} max={2.5} onChange={(v) => set({ saturation: v })} format={(v) => v.toFixed(2)} />
        <Slider label="Hue shift" value={e.hue} min={-180} max={180} step={1} onChange={(v) => set({ hue: v })} format={(v) => v + "°"} />
      </Section>
    </div>
  );
}

interface AudioProps {
  project: Project;
  update: Updater;
  duration: number;
  getTime: () => number;
  toast: (m: string) => void;
  loading: boolean;
}

export function AudioPanel({ project, update, getTime, toast, loading }: AudioProps) {
  const a = project.audio;
  const [busy, setBusy] = useState(false);
  const setA = (patch: Partial<Project["audio"]>, key?: string) => update((p) => ({ ...p, audio: { ...p.audio, ...patch } }), key ?? "audio-" + Object.keys(patch).join());
  const full = a.fileDuration || DEMO_DURATION;

  const importAudio = async () => {
    const f = await pickFile("audio/*,.mp3,.wav,.m4a,.aac,.flac,.ogg");
    if (!f) return;
    setBusy(true);
    try {
      const { audio } = await audioFromFile(f);
      update((p) => ({ ...p, audio }));
      toast("Audio imported & analysed");
    } catch (e) {
      toast((e as Error).message);
    }
    setBusy(false);
  };

  return (
    <div>
      <Section title="Audio track">
        <div className="flex items-center gap-3 rounded-xl bg-ink-700 p-3">
          <span className="grid h-10 w-10 place-items-center rounded-lg grad-bg text-white">
            <Music size={18} />
          </span>
          <div className="min-w-0">
            <div className="truncate text-sm font-medium">{a.demo ? "Built-in demo track" : a.name}</div>
            <div className="text-xs text-zinc-500">{loading ? "Decoding…" : `${fmtTime(full, true)} · analysed with FFT`}</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="primary" size="sm" onClick={importAudio} disabled={busy}>
            {busy ? "Decoding…" : "Import song"}
          </Button>
          <Button variant="soft" size="sm" onClick={() => update((p) => ({ ...p, audio: { mediaId: null, demo: true, name: "Built-in demo track", fileDuration: DEMO_DURATION, trimStart: 0, trimEnd: DEMO_DURATION, volume: p.audio.volume } }))}>
            Use demo track
          </Button>
        </div>
        <p className="text-[11px] text-zinc-500">MP3, WAV, M4A/AAC, FLAC and OGG are supported where the device decoder allows it.</p>
      </Section>
      <Section title="Trim" right={<Scissors size={13} className="text-zinc-500" />}>
        <Slider label="Start" value={a.trimStart} min={0} max={Math.max(0.2, a.trimEnd - 0.5)} step={0.05} onChange={(v) => setA({ trimStart: v })} format={(v) => fmtTime(v, true)} />
        <Slider label="End" value={a.trimEnd} min={Math.min(full, a.trimStart + 0.5)} max={full} step={0.05} onChange={(v) => setA({ trimEnd: v })} format={(v) => fmtTime(v, true)} />
        <div className="grid grid-cols-2 gap-2">
          <Button variant="soft" size="sm" onClick={() => setA({ trimStart: Math.min(a.trimEnd - 0.5, a.trimStart + getTime()) }, "trim")}>
            Start = playhead
          </Button>
          <Button variant="soft" size="sm" onClick={() => setA({ trimEnd: Math.max(a.trimStart + 0.5, a.trimStart + getTime()) }, "trim")}>
            End = playhead
          </Button>
        </div>
        <p className="text-xs text-zinc-500">Output length: {fmtTime(a.trimEnd - a.trimStart, true)}. Changing the trim moves the whole timeline (lyrics and layer times are relative to the trim start).</p>
        <Button variant="ghost" size="sm" onClick={() => setA({ trimStart: 0, trimEnd: full }, "trim")}>
          Reset trim
        </Button>
      </Section>
      <Section title="Volume">
        <Slider label="Playback & export volume" value={a.volume} min={0} max={1} onChange={(v) => setA({ volume: v })} format={(v) => Math.round(v * 100) + "%"} />
      </Section>
    </div>
  );
}
