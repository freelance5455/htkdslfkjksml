import { AlignLeft, ArrowDown, ArrowUp, Copy, Eye, EyeOff, Trash2, Type, Waves } from "lucide-react";
import { useState } from "react";
import { ColorField, Field, IconBtn, Modal, Section, Segmented, Select, Slider, Toggle, Button } from "../../components/ui";
import { lyr, txt, vis } from "../../lib/templates";
import { FONTS, VIS_STYLES, type Layer, type LyricsLayer, type Project, type TextLayer, type TextStyle, type VisualizerLayer } from "../../lib/types";
import { deepClone, uid } from "../../lib/util";
import { cn } from "../../utils/cn";
import { updateLayer, type Updater } from "../state";

interface Props {
  project: Project;
  update: Updater;
  selectedId: string | null;
  select: (id: string | null) => void;
  duration: number;
}

const TEXT_KINDS: { kind: TextLayer["kind"]; label: string; text: string; size: number }[] = [
  { kind: "title", label: "Song title", text: "Song Title", size: 64 },
  { kind: "artist", label: "Artist name", text: "Artist Name", size: 36 },
  { kind: "album", label: "Album name", text: "Album Name", size: 32 },
  { kind: "custom", label: "Custom text", text: "Your text", size: 56 },
  { kind: "info", label: "Additional info", text: "Out now on all platforms", size: 28 },
];

export function LayersPanel({ project, update, selectedId, select, duration }: Props) {
  const [addVis, setAddVis] = useState(false);
  const [addText, setAddText] = useState(false);
  const layers = [...project.layers].reverse();
  const sel = project.layers.find((l) => l.id === selectedId) ?? null;

  const add = (l: Layer) => {
    update((p) => ({ ...p, layers: [...p.layers, l] }));
    select(l.id);
  };
  const move = (id: string, dir: 1 | -1) =>
    update((p) => {
      const i = p.layers.findIndex((l) => l.id === id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= p.layers.length) return p;
      const a = [...p.layers];
      [a[i], a[j]] = [a[j], a[i]];
      return { ...p, layers: a };
    });
  const dup = (l: Layer) => {
    const c = { ...deepClone(l), id: uid(), name: l.name + " copy", x: Math.min(1, l.x + 0.03), y: Math.min(1, l.y + 0.03) } as Layer;
    add(c);
  };
  const del = (id: string) => {
    update((p) => ({ ...p, layers: p.layers.filter((l) => l.id !== id) }));
    if (selectedId === id) select(null);
  };

  return (
    <div>
      <Section title="Add element">
        <div className="grid grid-cols-3 gap-2">
          <Button variant="soft" size="sm" onClick={() => setAddVis(true)}>
            <Waves size={14} /> Visualizer
          </Button>
          <Button variant="soft" size="sm" onClick={() => setAddText(true)}>
            <Type size={14} /> Text
          </Button>
          <Button variant="soft" size="sm" onClick={() => add(lyr({ name: "Lyrics" }))}>
            <AlignLeft size={14} /> Lyrics
          </Button>
        </div>
      </Section>

      <Section title={`Layers (${layers.length})`}>
        {layers.length === 0 && <p className="text-xs text-zinc-500">No layers yet — add a visualizer or text.</p>}
        <div className="space-y-1.5">
          {layers.map((l, idx) => (
            <div
              key={l.id}
              onClick={() => select(l.id)}
              className={cn("flex cursor-pointer items-center gap-1 rounded-xl border px-2 py-1.5 transition", selectedId === l.id ? "border-accent bg-accent/10" : "border-white/5 bg-ink-700 hover:bg-ink-600")}
            >
              <IconBtn
                className="!h-7 !w-7"
                onClick={(e) => {
                  e.stopPropagation();
                  update((p) => updateLayer(p, l.id, { visible: !l.visible }));
                }}
              >
                {l.visible ? <Eye size={14} /> : <EyeOff size={14} className="text-zinc-600" />}
              </IconBtn>
              <span className="text-zinc-500">{l.type === "visualizer" ? <Waves size={14} /> : l.type === "lyrics" ? <AlignLeft size={14} /> : <Type size={14} />}</span>
              <span className="min-w-0 flex-1 truncate px-1 text-sm">{l.name}</span>
              <IconBtn className="!h-7 !w-7" disabled={idx === 0} onClick={(e) => (e.stopPropagation(), move(l.id, 1))} title="Bring forward">
                <ArrowUp size={14} />
              </IconBtn>
              <IconBtn className="!h-7 !w-7" disabled={idx === layers.length - 1} onClick={(e) => (e.stopPropagation(), move(l.id, -1))} title="Send backward">
                <ArrowDown size={14} />
              </IconBtn>
              <IconBtn className="!h-7 !w-7" onClick={(e) => (e.stopPropagation(), dup(l))} title="Duplicate">
                <Copy size={14} />
              </IconBtn>
              <IconBtn className="!h-7 !w-7 hover:!text-red-400" onClick={(e) => (e.stopPropagation(), del(l.id))} title="Delete">
                <Trash2 size={14} />
              </IconBtn>
            </div>
          ))}
        </div>
      </Section>

      {sel ? <Inspector layer={sel} update={update} duration={duration} /> : <p className="p-4 text-xs text-zinc-500">Select a layer (here, on the timeline or by tapping it in the preview) to edit its properties. Drag in the preview to move, drag the round handle to resize.</p>}

      <Modal open={addVis} onClose={() => setAddVis(false)} title="Add visualizer">
        <div className="grid grid-cols-2 gap-2">
          {VIS_STYLES.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                const ref = project.layers.find((l): l is VisualizerLayer => l.type === "visualizer");
                add(vis({ style: s.id, name: s.label, color1: ref?.color1 ?? "#00f0ff", color2: ref?.color2 ?? "#ff00e5", y: 0.5 }));
                setAddVis(false);
              }}
              className="rounded-xl border border-white/10 bg-ink-700 px-3 py-3 text-left text-sm hover:border-accent"
            >
              {s.label}
            </button>
          ))}
        </div>
      </Modal>
      <Modal open={addText} onClose={() => setAddText(false)} title="Add text">
        <div className="space-y-2">
          {TEXT_KINDS.map((k) => (
            <button
              key={k.kind}
              onClick={() => {
                add(txt({ kind: k.kind, name: k.label, text: k.text, fontSize: k.size, y: 0.5 }));
                setAddText(false);
              }}
              className="w-full rounded-xl border border-white/10 bg-ink-700 px-4 py-3 text-left text-sm hover:border-accent"
            >
              {k.label}
            </button>
          ))}
        </div>
      </Modal>
    </div>
  );
}

function Inspector({ layer, update, duration }: { layer: Layer; update: Updater; duration: number }) {
  const set = (patch: Partial<Layer>, key?: string) => update((p) => updateLayer(p, layer.id, patch), key ?? `${layer.id}-${Object.keys(patch).join()}`);
  return (
    <>
      <Section title="Selected layer">
        <Field label="Name">
          <input value={layer.name} onChange={(e) => set({ name: e.target.value })} className="w-full rounded-xl border border-white/10 bg-ink-700 px-3 py-2 text-sm outline-none focus:border-accent" />
        </Field>
      </Section>
      <Section title="Transform">
        <Slider label="Position X" value={layer.x} min={-0.2} max={1.2} step={0.005} onChange={(v) => set({ x: v })} format={(v) => Math.round(v * 100) + "%"} />
        <Slider label="Position Y" value={layer.y} min={-0.2} max={1.2} step={0.005} onChange={(v) => set({ y: v })} format={(v) => Math.round(v * 100) + "%"} />
        <Slider label="Scale" value={layer.scale} min={0.1} max={4} step={0.01} onChange={(v) => set({ scale: v })} format={(v) => v.toFixed(2) + "×"} />
        <Slider label="Rotation" value={layer.rotation} min={-180} max={180} step={1} onChange={(v) => set({ rotation: v })} format={(v) => v + "°"} />
        <Slider label="Opacity" value={layer.opacity} min={0} max={1} onChange={(v) => set({ opacity: v })} format={(v) => Math.round(v * 100) + "%"} />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Start (s)">
            <input type="number" min={0} max={duration} step={0.1} value={layer.start} onChange={(e) => set({ start: Math.max(0, parseFloat(e.target.value) || 0) })} className="w-full rounded-xl border border-white/10 bg-ink-700 px-3 py-2 text-sm outline-none" />
          </Field>
          <Field label="End (0 = end)">
            <input type="number" min={0} max={duration} step={0.1} value={layer.end} onChange={(e) => set({ end: Math.max(0, parseFloat(e.target.value) || 0) })} className="w-full rounded-xl border border-white/10 bg-ink-700 px-3 py-2 text-sm outline-none" />
          </Field>
        </div>
      </Section>
      {layer.type === "visualizer" && <VisControls L={layer} set={set as (p: Partial<VisualizerLayer>) => void} />}
      {layer.type === "text" && (
        <>
          <Section title="Content">
            <Field label="Text">
              <textarea value={layer.text} onChange={(e) => set({ text: e.target.value })} rows={2} className="w-full resize-none rounded-xl border border-white/10 bg-ink-700 px-3 py-2 text-sm outline-none focus:border-accent" />
            </Field>
            <Field label="Type">
              <Select value={layer.kind} onChange={(v) => set({ kind: v } as Partial<TextLayer>)} options={TEXT_KINDS.map((k) => ({ value: k.kind, label: k.label }))} />
            </Field>
          </Section>
          <TextControls L={layer} set={set as (p: Partial<TextStyle>) => void} />
        </>
      )}
      {layer.type === "lyrics" && (
        <>
          <Section title="Lyric transition">
            <Segmented
              value={layer.transition}
              onChange={(v) => set({ transition: v } as Partial<LyricsLayer>)}
              options={[
                { value: "none", label: "None" },
                { value: "fade", label: "Fade" },
                { value: "slideUp", label: "Slide" },
                { value: "zoom", label: "Zoom" },
                { value: "typewriter", label: "Type" },
              ]}
            />
            <Toggle label="Show next line (dimmed)" value={layer.showNext} onChange={(v) => set({ showNext: v } as Partial<LyricsLayer>)} />
            <ColorField label="Lyric background box" value={layer.boxColor} onChange={(v) => set({ boxColor: v } as Partial<LyricsLayer>)} />
            <Slider label="Box opacity" value={layer.boxOpacity} min={0} max={1} onChange={(v) => set({ boxOpacity: v } as Partial<LyricsLayer>)} />
          </Section>
          <TextControls L={layer} set={set as (p: Partial<TextStyle>) => void} lyrics />
        </>
      )}
    </>
  );
}

function VisControls({ L, set }: { L: VisualizerLayer; set: (p: Partial<VisualizerLayer>) => void }) {
  return (
    <>
      <Section title="Visualizer">
        <Field label="Style">
          <Select value={L.style} onChange={(v) => set({ style: v })} options={VIS_STYLES.map((s) => ({ value: s.id, label: s.label }))} />
        </Field>
        <Segmented
          value={L.colorMode}
          onChange={(v) => set({ colorMode: v })}
          options={[
            { value: "solid", label: "Solid" },
            { value: "gradient", label: "Gradient" },
            { value: "rainbow", label: "Rainbow" },
          ]}
        />
        <ColorField label="Primary colour" value={L.color1} onChange={(v) => set({ color1: v })} />
        {L.colorMode !== "solid" && L.colorMode !== "rainbow" && <ColorField label="Secondary colour" value={L.color2} onChange={(v) => set({ color2: v })} />}
        <Slider label="Bars / density" value={L.bars} min={16} max={128} step={2} onChange={(v) => set({ bars: v })} format={(v) => String(v)} />
        <Slider label="Thickness" value={L.thickness} min={0.1} max={1} onChange={(v) => set({ thickness: v })} />
        <Slider label="Sensitivity" value={L.amp} min={0.2} max={2.5} onChange={(v) => set({ amp: v })} format={(v) => v.toFixed(2) + "×"} />
        <Slider label="Smoothing" value={L.smoothing} min={0} max={1} onChange={(v) => set({ smoothing: v })} />
        <Slider label="Glow" value={L.glow} min={0} max={1} onChange={(v) => set({ glow: v })} />
        <Slider label="Circle size / inner radius" value={L.inner} min={0.3} max={1.8} onChange={(v) => set({ inner: v })} />
        <Slider label="Spin speed" value={L.spin} min={-90} max={90} step={1} onChange={(v) => set({ spin: v })} format={(v) => v + "°/s"} />
        <Slider label="Beat pulse (scale)" value={L.reactiveScale} min={0} max={1} onChange={(v) => set({ reactiveScale: v })} />
        <Toggle label="Rounded bars" value={L.rounded} onChange={(v) => set({ rounded: v })} />
      </Section>
    </>
  );
}

function TextControls({ L, set, lyrics }: { L: TextStyle; set: (p: Partial<TextStyle>) => void; lyrics?: boolean }) {
  return (
    <Section title="Typography">
      <Field label="Font family">
        <Select value={L.fontFamily} onChange={(v) => set({ fontFamily: v })} options={FONTS.map((f) => ({ value: f, label: f }))} />
      </Field>
      <Slider label="Font size" value={L.fontSize} min={12} max={260} step={1} onChange={(v) => set({ fontSize: v })} format={(v) => v + " px"} />
      <div className="grid grid-cols-2 gap-2">
        <Segmented value={L.bold ? "b" : "n"} onChange={(v) => set({ bold: v === "b" })} options={[{ value: "n", label: "Regular" }, { value: "b", label: "Bold" }]} />
        <Segmented value={L.italic ? "i" : "n"} onChange={(v) => set({ italic: v === "i" })} options={[{ value: "n", label: "Upright" }, { value: "i", label: "Italic" }]} />
      </div>
      <Segmented
        value={L.align}
        onChange={(v) => set({ align: v })}
        options={[
          { value: "left", label: "Left" },
          { value: "center", label: "Center" },
          { value: "right", label: "Right" },
        ]}
      />
      <ColorField label="Colour" value={L.color} onChange={(v) => set({ color: v })} />
      <Toggle label="Gradient text" value={L.gradient} onChange={(v) => set({ gradient: v })} />
      {L.gradient && <ColorField label="Gradient end colour" value={L.color2} onChange={(v) => set({ color2: v })} />}
      <Slider label="Letter spacing" value={L.letterSpacing} min={-5} max={40} step={0.5} onChange={(v) => set({ letterSpacing: v })} format={(v) => v + " px"} />
      <Slider label="Shadow" value={L.shadow} min={0} max={1} onChange={(v) => set({ shadow: v })} />
      <Slider label="Outline width" value={L.outline} min={0} max={14} step={0.5} onChange={(v) => set({ outline: v })} format={(v) => v + " px"} />
      {L.outline > 0 && <ColorField label="Outline colour" value={L.outlineColor} onChange={(v) => set({ outlineColor: v })} />}
      <Slider label="Glow" value={L.glow} min={0} max={1} onChange={(v) => set({ glow: v })} />
      {L.glow > 0 && <ColorField label="Glow colour" value={L.glowColor} onChange={(v) => set({ glowColor: v })} />}
      <Field label={lyrics ? "Continuous motion" : "Animation"}>
        <Select
          value={L.anim}
          onChange={(v) => set({ anim: v })}
          options={(lyrics
            ? [
                ["none", "None"],
                ["pulse", "Beat pulse"],
                ["bounce", "Beat bounce"],
                ["float", "Float"],
              ]
            : [
                ["none", "None"],
                ["fade", "Fade in/out"],
                ["slideUp", "Slide up"],
                ["zoom", "Zoom in"],
                ["typewriter", "Typewriter"],
                ["pulse", "Beat pulse"],
                ["bounce", "Beat bounce"],
                ["float", "Float"],
              ]
          ).map(([value, label]) => ({ value: value as TextStyle["anim"], label }))}
        />
      </Field>
    </Section>
  );
}

