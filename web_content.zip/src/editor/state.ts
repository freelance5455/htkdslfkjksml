import { useCallback, useRef, useState, useSyncExternalStore } from "react";
import type { Layer, Project } from "../lib/types";

interface Hist {
  past: Project[];
  present: Project | null;
  future: Project[];
  lastKey: string;
  lastT: number;
}

export type Updater = (fn: (p: Project) => Project, key?: string) => void;

export function useHistory() {
  const h = useRef<Hist>({ past: [], present: null, future: [], lastKey: "", lastT: 0 });
  const [, force] = useState(0);
  const bump = () => force((n) => n + 1);

  const reset = useCallback((p: Project) => {
    h.current = { past: [], present: p, future: [], lastKey: "", lastT: 0 };
    bump();
  }, []);

  const update: Updater = useCallback((fn, key) => {
    const c = h.current;
    if (!c.present) return;
    const next = fn(c.present);
    if (next === c.present) return;
    const now = Date.now();
    if (key && key === c.lastKey && now - c.lastT < 900) {
      c.present = next;
    } else {
      c.past.push(c.present);
      if (c.past.length > 120) c.past.shift();
      c.present = next;
      c.future = [];
    }
    c.lastKey = key ?? "";
    c.lastT = now;
    bump();
  }, []);

  const undo = useCallback(() => {
    const c = h.current;
    if (!c.past.length || !c.present) return;
    c.future.push(c.present);
    c.present = c.past.pop()!;
    c.lastKey = "";
    bump();
  }, []);
  const redo = useCallback(() => {
    const c = h.current;
    if (!c.future.length || !c.present) return;
    c.past.push(c.present);
    c.present = c.future.pop()!;
    c.lastKey = "";
    bump();
  }, []);

  return { project: h.current.present, update, undo, redo, reset, canUndo: h.current.past.length > 0, canRedo: h.current.future.length > 0 };
}

export function updateLayer(p: Project, id: string, patch: Partial<Layer>): Project {
  return { ...p, layers: p.layers.map((l) => (l.id === id ? ({ ...l, ...patch } as Layer) : l)) };
}

/** Tiny external store so the playhead can update at 20 Hz without re-rendering the whole editor. */
export class TimeStore {
  t = 0;
  private ls = new Set<() => void>();
  set(t: number) {
    this.t = t;
    this.ls.forEach((l) => l());
  }
  sub = (cb: () => void) => {
    this.ls.add(cb);
    return () => this.ls.delete(cb);
  };
}

export function useTime(store: TimeStore) {
  return useSyncExternalStore(store.sub, () => store.t);
}
