import { Eye, EyeOff, Film, Music, Type, Waves, AlignLeft } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import type { Layer, Project } from "../lib/types";
import { clamp, fmtTime } from "../lib/util";
import { cn } from "../utils/cn";
import { useTime, type TimeStore, type Updater } from "./state";
import { updateLayer } from "./state";

interface Props {
  project: Project;
  duration: number;
  store: TimeStore;
  peaks: Float32Array | null;
  onSeek: (t: number) => void;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  update: Updater;
  zoom: number;
}

const LABEL_W = 112;
const ROW = 30;

function PeaksSvg({ peaks, from, to, total }: { peaks: Float32Array; from: number; to: number; total: number }) {
  const d = useMemo(() => {
    const n = 900;
    const a = (from / total) * peaks.length;
    const b = (to / total) * peaks.length;
    const pts: string[] = [];
    const top: string[] = [];
    for (let i = 0; i < n; i++) {
      const s = Math.floor(a + ((b - a) * i) / n);
      const e = Math.max(s + 1, Math.floor(a + ((b - a) * (i + 1)) / n));
      let m = 0;
      for (let k = s; k < e && k < peaks.length; k++) m = Math.max(m, peaks[k]);
      const h = Math.min(1, m * 1.15) * 13;
      top.push(`${i},${15 - h}`);
      pts.unshift(`${i},${15 + h}`);
    }
    return `M${top.join("L")}L${pts.join("L")}Z`;
  }, [peaks, from, to, total]);
  return (
    <svg viewBox="0 0 900 30" preserveAspectRatio="none" className="pointer-events-none h-full w-full">
      <path d={d} fill="url(#wf)" />
      <defs>
        <linearGradient id="wf" x1="0" x2="1">
          <stop offset="0" stopColor="var(--accent)" />
          <stop offset="1" stopColor="var(--accent2)" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function LayerIcon({ l }: { l: Layer }) {
  return l.type === "visualizer" ? <Waves size={13} /> : l.type === "lyrics" ? <AlignLeft size={13} /> : <Type size={13} />;
}

export function Timeline({ project, duration, store, peaks, onSeek, selectedId, onSelect, update, zoom }: Props) {
  const scroller = useRef<HTMLDivElement>(null);
  const [w, setW] = useState(600);
  const t = useTime(store);

  useEffect(() => {
    const el = scroller.current!;
    const ro = new ResizeObserver(() => setW(el.clientWidth));
    ro.observe(el);
    setW(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const width = Math.max(w, w * zoom);
  const pps = width / Math.max(0.1, duration);
  const x = (s: number) => s * pps;

  // ruler step
  const steps = [0.5, 1, 2, 5, 10, 15, 30, 60, 120];
  const step = steps.find((s) => s * pps >= 56) ?? 120;
  const ticks: number[] = [];
  for (let s = 0; s <= duration + 0.001; s += step) ticks.push(s);

  const seekFromEvent = (e: React.PointerEvent) => {
    const r = scroller.current!.getBoundingClientRect();
    const px = e.clientX - r.left + scroller.current!.scrollLeft;
    onSeek(clamp(px / pps, 0, duration));
  };
  const scrubbing = useRef(false);

  // keep playhead visible while playing
  useEffect(() => {
    const el = scroller.current;
    if (!el || zoom <= 1) return;
    const px = t * pps;
    if (px < el.scrollLeft || px > el.scrollLeft + el.clientWidth - 40) el.scrollLeft = Math.max(0, px - 60);
  }, [t, pps, zoom]);

  const dragBar = (e: React.PointerEvent, l: Layer, mode: "move" | "start" | "end") => {
    e.stopPropagation();
    onSelect(l.id);
    const startX = e.clientX;
    const s0 = l.start;
    const e0 = l.end > 0 ? l.end : duration;
    (e.target as Element).setPointerCapture(e.pointerId);
    const mv = (ev: PointerEvent) => {
      const d = (ev.clientX - startX) / pps;
      let ns = s0,
        ne = e0;
      if (mode === "move") {
        const len = e0 - s0;
        ns = clamp(s0 + d, 0, duration - len);
        ne = ns + len;
      } else if (mode === "start") ns = clamp(s0 + d, 0, e0 - 0.2);
      else ne = clamp(e0 + d, s0 + 0.2, duration);
      update((p) => updateLayer(p, l.id, { start: Math.round(ns * 20) / 20, end: ne >= duration - 0.01 ? 0 : Math.round(ne * 20) / 20 }), "tl-" + l.id);
    };
    const up = () => {
      window.removeEventListener("pointermove", mv);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", mv);
    window.addEventListener("pointerup", up);
  };

  const layersTop = [...project.layers].reverse();
  const a = project.audio;
  const rows = 3 + layersTop.length;

  return (
    <div className="flex min-h-0 flex-1 overflow-y-auto border-t border-white/5 bg-ink-900">
      {/* labels */}
      <div className="sticky left-0 z-20 shrink-0 border-r border-white/5 bg-ink-900" style={{ width: LABEL_W }}>
        <div style={{ height: 24 }} className="border-b border-white/5 px-2 text-[10px] leading-6 text-zinc-500">
          Tracks
        </div>
        <div style={{ height: ROW }} className="flex items-center gap-1.5 px-2 text-[11px] text-zinc-300">
          <Music size={13} className="text-accent" /> <span className="truncate">Audio</span>
        </div>
        <div style={{ height: ROW }} className="flex items-center gap-1.5 px-2 text-[11px] text-zinc-300">
          <Film size={13} className="text-sky-400" /> <span className="truncate">Background</span>
        </div>
        {layersTop.map((l) => (
          <div
            key={l.id}
            style={{ height: ROW }}
            onClick={() => onSelect(l.id)}
            className={cn("flex cursor-pointer items-center gap-1.5 px-2 text-[11px]", selectedId === l.id ? "bg-white/10 text-white" : "text-zinc-400 hover:bg-white/5")}
          >
            <button
              onClick={(e) => {
                e.stopPropagation();
                update((p) => updateLayer(p, l.id, { visible: !l.visible }));
              }}
              className="text-zinc-500 hover:text-white"
            >
              {l.visible ? <Eye size={13} /> : <EyeOff size={13} />}
            </button>
            <LayerIcon l={l} />
            <span className="truncate">{l.name}</span>
          </div>
        ))}
      </div>

      {/* tracks */}
      <div ref={scroller} className="relative min-w-0 flex-1 overflow-x-auto overflow-y-hidden">
        <div
          className="relative"
          style={{ width, height: 24 + rows * ROW }}
          onPointerDown={(e) => {
            if (!(e.target as HTMLElement).dataset.row) return;
            scrubbing.current = true;
            (e.target as Element).setPointerCapture(e.pointerId);
            seekFromEvent(e);
            onSelect(null);
          }}
          onPointerMove={(e) => scrubbing.current && seekFromEvent(e)}
          onPointerUp={() => (scrubbing.current = false)}
        >
          {/* ruler */}
          <div
            className="sticky top-0 h-6 cursor-col-resize select-none border-b border-white/5 bg-ink-800"
            style={{ width }}
            onPointerDown={(e) => {
              scrubbing.current = true;
              (e.target as Element).setPointerCapture(e.pointerId);
              seekFromEvent(e);
            }}
            onPointerMove={(e) => scrubbing.current && seekFromEvent(e)}
            onPointerUp={() => (scrubbing.current = false)}
          >
            {ticks.map((s) => (
              <div key={s} className="absolute top-0 h-full border-l border-white/10 pl-1 text-[10px] leading-6 text-zinc-500" style={{ left: x(s) }}>
                {fmtTime(s)}
              </div>
            ))}
          </div>

          {/* audio */}
          <div data-row="1" className="relative border-b border-white/[0.03]" style={{ height: ROW }}>
            <div data-row="1" className="absolute inset-y-1 left-0 overflow-hidden rounded-md bg-accent/10 ring-1 ring-accent/30" style={{ width: x(duration) }}>
              {peaks && a.fileDuration > 0 ? <PeaksSvg peaks={peaks} from={a.trimStart} to={a.trimEnd > a.trimStart ? a.trimEnd : a.fileDuration} total={a.fileDuration} /> : null}
            </div>
          </div>
          {/* background */}
          <div data-row="1" className="relative border-b border-white/[0.03]" style={{ height: ROW }}>
            <div data-row="1" className="absolute inset-y-1 left-0 flex items-center overflow-hidden rounded-md bg-sky-500/15 px-2 text-[10px] text-sky-300 ring-1 ring-sky-400/30" style={{ width: x(duration) }}>
              {project.background.type}
              {project.background.mediaName ? ` · ${project.background.mediaName}` : ""}
            </div>
          </div>
          {/* layers */}
          {layersTop.map((l) => {
            const s = l.start;
            const e = l.end > 0 ? Math.min(l.end, duration) : duration;
            const lines = l.type === "lyrics" ? project.lyrics : [];
            return (
              <div key={l.id} data-row="1" className="relative border-b border-white/[0.03]" style={{ height: ROW }}>
                <div
                  onPointerDown={(ev) => dragBar(ev, l, "move")}
                  className={cn(
                    "absolute inset-y-1 cursor-grab touch-none overflow-hidden rounded-md text-[10px] ring-1",
                    l.type === "visualizer" ? "bg-fuchsia-500/20 ring-fuchsia-400/40" : l.type === "lyrics" ? "bg-emerald-500/15 ring-emerald-400/40" : "bg-amber-500/15 ring-amber-400/40",
                    !l.visible && "opacity-40",
                    selectedId === l.id && "ring-2 !ring-white"
                  )}
                  style={{ left: x(s), width: Math.max(8, x(e - s)) }}
                >
                  {lines.map((ln) => (
                    <div
                      key={ln.id}
                      title={ln.text}
                      className="absolute inset-y-1.5 truncate rounded bg-emerald-400/50 px-1 text-[9px] leading-3 text-emerald-950"
                      style={{ left: x(ln.start - s), width: Math.max(3, x(ln.end - ln.start) - 1) }}
                    >
                      {ln.text}
                    </div>
                  ))}
                  {l.type !== "lyrics" && <span className="pointer-events-none px-2 leading-[22px] text-zinc-200">{l.name}</span>}
                  <div onPointerDown={(ev) => dragBar(ev, l, "start")} className="absolute inset-y-0 left-0 w-2.5 cursor-ew-resize bg-white/20 hover:bg-white/50" />
                  <div onPointerDown={(ev) => dragBar(ev, l, "end")} className="absolute inset-y-0 right-0 w-2.5 cursor-ew-resize bg-white/20 hover:bg-white/50" />
                </div>
              </div>
            );
          })}
          {/* playhead */}
          <div className="pointer-events-none absolute top-0 z-10 h-full w-px bg-white" style={{ left: x(t) }}>
            <div className="absolute -left-[5px] top-0 h-0 w-0 border-x-[5px] border-t-[8px] border-x-transparent border-t-white" />
          </div>
        </div>
      </div>
    </div>
  );
}
