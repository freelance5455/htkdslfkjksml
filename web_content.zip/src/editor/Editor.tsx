import { AlignLeft, ArrowLeft, Check, Film, Image as ImageIcon, Layers, Loader2, Music, Pause, Play, Redo2, Save, Settings2, SkipBack, Sparkles, Undo2, ZoomIn } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { IconBtn, Toast } from "../components/ui";
import { Analyzer, AudioPlayer, computePeaks, newFrame } from "../lib/audio";
import { db } from "../lib/db";
import { projectDuration } from "../lib/exporter";
import { loadFonts } from "../lib/fonts";
import { getProjectAudio } from "../lib/projects";
import { Renderer, type BgSource } from "../lib/renderer";
import { PREVIEW_SIDE, getSettings, useSettings } from "../lib/settings";
import { canvasSize } from "../lib/templates";
import { clamp, fmtTime } from "../lib/util";
import { cn } from "../utils/cn";
import { Preview } from "./Preview";
import { TimeStore, updateLayer, useHistory, useTime } from "./state";
import { Timeline } from "./Timeline";
import { LayersPanel } from "./panels/LayersPanel";
import { LyricsPanel } from "./panels/LyricsPanel";
import { ExportPanel, ProjectPanel } from "./panels/ProjectExport";
import { AudioPanel, BackgroundPanel, EffectsPanel } from "./panels/StylePanels";

const TABS = [
  { id: "layers", label: "Layers", icon: Layers },
  { id: "background", label: "Background", icon: ImageIcon },
  { id: "effects", label: "Effects", icon: Sparkles },
  { id: "audio", label: "Audio", icon: Music },
  { id: "lyrics", label: "Lyrics", icon: AlignLeft },
  { id: "project", label: "Project", icon: Settings2 },
  { id: "export", label: "Export", icon: Film },
] as const;
type Tab = (typeof TABS)[number]["id"];

function TimeLabel({ store, duration }: { store: TimeStore; duration: number }) {
  const t = useTime(store);
  return (
    <span className="font-mono text-xs tabular-nums text-zinc-300">
      {fmtTime(t, true)} <span className="text-zinc-600">/ {fmtTime(duration, true)}</span>
    </span>
  );
}

function SeekBar({ store, duration, onSeek }: { store: TimeStore; duration: number; onSeek: (t: number) => void }) {
  const t = useTime(store);
  return <input type="range" min={0} max={duration} step={0.01} value={t} onChange={(e) => onSeek(parseFloat(e.target.value))} className="min-w-0 flex-1" />;
}

export function Editor({ projectId, onExit }: { projectId: string; onExit: () => void }) {
  const hist = useHistory();
  const { project, update, undo, redo, canUndo, canRedo, reset } = hist;
  const settings = useSettings();

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<Renderer | null>(null);
  const playerRef = useRef<AudioPlayer | null>(null);
  const analyzerRef = useRef<Analyzer | null>(null);
  const bufferRef = useRef<AudioBuffer | null>(null);
  const bgRef = useRef<BgSource>(null);
  const store = useRef(new TimeStore()).current;
  const needs = useRef(true);
  const projectRef = useRef(project);
  projectRef.current = project;
  const playingRef = useRef(false);
  const thumbRef = useRef<string | undefined>(undefined);
  const initialRef = useRef<unknown>(null);

  const [playing, setPlaying] = useState(false);
  const [tab, setTab] = useState<Tab>("layers");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [peaks, setPeaks] = useState<Float32Array | null>(null);
  const [audioLoading, setAudioLoading] = useState(true);
  const [audioError, setAudioError] = useState("");
  const [zoom, setZoom] = useState(1);
  const [saveState, setSaveState] = useState<"saved" | "dirty" | "saving">("saved");
  const [msg, setMsg] = useState<string | null>(null);
  const [missing, setMissing] = useState(false);
  const [fontsReady, setFontsReady] = useState(false);
  const toastTimer = useRef<number | undefined>(undefined);

  const toast = useCallback((m: string) => {
    setMsg(m);
    clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setMsg(null), 2600);
  }, []);

  const duration = project ? Math.max(0.1, projectDuration(project)) : 30;
  const durRef = useRef(duration);
  durRef.current = duration;

  // ------------------------------------------------ load project
  useEffect(() => {
    let alive = true;
    db.getProject(projectId).then((p) => {
      if (!alive) return;
      if (!p) return setMissing(true);
      thumbRef.current = p.thumbnail;
      initialRef.current = p;
      reset(p);
    });
    loadFonts().then(() => alive && setFontsReady(true));
    return () => {
      alive = false;
    };
  }, [projectId, reset]);

  // ------------------------------------------------ audio player lifecycle
  useEffect(() => {
    const pl = new AudioPlayer();
    playerRef.current = pl;
    pl.onEnded = () => {
      playingRef.current = false;
      setPlaying(false);
      store.set(durRef.current);
      needs.current = true;
    };
    return () => {
      pl.dispose();
      playerRef.current = null;
    };
  }, [store]);

  // ------------------------------------------------ audio buffer + analysis
  const audioKey = project ? `${project.audio.demo}-${project.audio.mediaId}` : "";
  useEffect(() => {
    const p = projectRef.current;
    if (!p) return;
    let alive = true;
    setAudioLoading(true);
    setAudioError("");
    getProjectAudio(p)
      .then((buf) => {
        if (!alive) return;
        bufferRef.current = buf;
        analyzerRef.current = buf ? new Analyzer(buf) : null;
        playerRef.current?.setBuffer(buf);
        playingRef.current = false;
        setPlaying(false);
        setPeaks(buf ? computePeaks(buf) : null);
        if (!buf) setAudioError("The audio file for this project is missing. Import a song in the Audio tab.");
        else if (p.audio.fileDuration === 0 || p.audio.trimEnd <= p.audio.trimStart) update((pp) => ({ ...pp, audio: { ...pp.audio, fileDuration: buf.duration, trimStart: 0, trimEnd: buf.duration } }));
        needs.current = true;
        setAudioLoading(false);
      })
      .catch((e) => {
        if (!alive) return;
        setAudioError((e as Error).message || "Audio decode failed");
        setAudioLoading(false);
      });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audioKey, !!project]);

  useEffect(() => {
    playerRef.current?.setVolume(project?.audio.volume ?? 1);
  }, [project?.audio.volume]);

  // trimming pauses and clamps
  const trimKey = project ? `${project.audio.trimStart}-${project.audio.trimEnd}` : "";
  useEffect(() => {
    if (playingRef.current) {
      playerRef.current?.pause();
      playingRef.current = false;
      setPlaying(false);
    }
    if (store.t > durRef.current) store.set(durRef.current);
    needs.current = true;
  }, [trimKey, store]);

  // ------------------------------------------------ background media (image / video)
  const bgKey = project ? `${project.background.type}-${project.background.mediaId}` : "";
  useEffect(() => {
    const bg = projectRef.current?.background;
    bgRef.current = null;
    needs.current = true;
    if (!bg || !bg.mediaId || (bg.type !== "image" && bg.type !== "video")) return;
    let alive = true;
    let url = "";
    db.getMedia(bg.mediaId).then((rec) => {
      if (!rec || !alive) return;
      url = URL.createObjectURL(rec.blob);
      if (bg.type === "image") {
        const img = new Image();
        img.onload = () => {
          if (alive) {
            bgRef.current = img;
            needs.current = true;
          }
        };
        img.src = url;
      } else {
        const v = document.createElement("video");
        v.muted = true;
        v.loop = true;
        v.playsInline = true;
        v.preload = "auto";
        v.onloadeddata = () => {
          if (!alive) return;
          bgRef.current = v;
          needs.current = true;
          if (playingRef.current) v.play().catch(() => {});
        };
        v.onseeked = () => (needs.current = true);
        v.src = url;
      }
    });
    return () => {
      alive = false;
      if (url) URL.revokeObjectURL(url);
      const v = bgRef.current as HTMLVideoElement | null;
      if (v && "pause" in v) v.pause();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bgKey, !!project]);

  useEffect(() => {
    needs.current = true;
  }, [project, fontsReady, settings.previewQuality]);

  // ------------------------------------------------ transport
  const syncVideo = (t: number, play: boolean) => {
    const v = bgRef.current as HTMLVideoElement | null;
    if (!v || !("currentTime" in v) || !(v as HTMLVideoElement).duration) return;
    try {
      v.currentTime = t % v.duration;
      if (play) v.play().catch(() => {});
      else v.pause();
    } catch {
      /* ignore */
    }
  };

  const seek = useCallback(
    (t: number) => {
      const p = projectRef.current;
      if (!p) return;
      t = clamp(t, 0, durRef.current);
      store.set(t);
      needs.current = true;
      if (playingRef.current) playerRef.current?.seek(p.audio.trimStart + t);
      syncVideo(t, playingRef.current);
    },
    [store]
  );

  const togglePlay = useCallback(async () => {
    const p = projectRef.current;
    const pl = playerRef.current;
    if (!p || !pl || !bufferRef.current) return;
    if (playingRef.current) {
      pl.pause();
      playingRef.current = false;
      setPlaying(false);
      syncVideo(store.t, false);
    } else {
      let t = store.t;
      if (t >= durRef.current - 0.05) t = 0;
      store.set(t);
      await pl.play(p.audio.trimStart + t, p.audio.trimEnd > p.audio.trimStart ? p.audio.trimEnd : bufferRef.current.duration);
      playingRef.current = true;
      setPlaying(true);
      syncVideo(t, true);
    }
  }, [store]);

  // ------------------------------------------------ render loop
  useEffect(() => {
    if (!project || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const r = new Renderer(canvas);
    rendererRef.current = r;
    const frame = newFrame();
    let raf = 0;
    let tick = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const p = projectRef.current;
      if (!p) return;
      const [W, H] = canvasSize(p.aspect, PREVIEW_SIDE[getSettings().previewQuality]);
      if (W !== r.W || H !== r.H) {
        r.resize(W, H);
        needs.current = true;
      }
      const pl = playerRef.current;
      let t = store.t;
      if (playingRef.current && pl) {
        t = clamp(pl.position - p.audio.trimStart, 0, durRef.current);
        if (++tick % 3 === 0) store.set(t);
        else store.t = t;
      } else if (!needs.current) return;
      needs.current = false;
      const an = analyzerRef.current;
      if (an) an.frame(p.audio.trimStart + t, frame);
      r.render({ background: p.background, effects: p.effects, layers: p.layers, lyrics: p.lyrics }, t, frame, bgRef.current);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      rendererRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [!!project, store]);

  // ------------------------------------------------ saving
  const captureThumb = useCallback(() => {
    const c = canvasRef.current;
    if (!c || !c.width) return thumbRef.current;
    try {
      const t = document.createElement("canvas");
      t.width = 360;
      t.height = Math.round((360 * c.height) / c.width);
      t.getContext("2d")!.drawImage(c, 0, 0, t.width, t.height);
      return t.toDataURL("image/jpeg", 0.72);
    } catch {
      return thumbRef.current;
    }
  }, []);

  const saveNow = useCallback(async () => {
    const p = projectRef.current;
    if (!p) return;
    setSaveState("saving");
    const thumbnail = captureThumb();
    thumbRef.current = thumbnail;
    await db.putProject({ ...p, updatedAt: Date.now(), thumbnail });
    setSaveState("saved");
  }, [captureThumb]);

  useEffect(() => {
    if (!project || project === initialRef.current) return;
    setSaveState("dirty");
    if (!getSettings().autosave) return;
    const id = window.setTimeout(saveNow, 900);
    return () => clearTimeout(id);
  }, [project, saveNow]);

  const exitRef = useRef(saveNow);
  exitRef.current = saveNow;
  useEffect(
    () => () => {
      // flush on unmount (route change)
      if (projectRef.current && projectRef.current !== initialRef.current) exitRef.current();
    },
    []
  );

  // ------------------------------------------------ keyboard
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const tg = e.target as HTMLElement;
      const typing = tg.tagName === "INPUT" || tg.tagName === "TEXTAREA" || tg.tagName === "SELECT";
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        e.shiftKey ? redo() : undo();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") {
        e.preventDefault();
        redo();
      } else if (!typing && e.code === "Space") {
        e.preventDefault();
        togglePlay();
      } else if (!typing && (e.key === "Delete" || e.key === "Backspace") && selectedId) {
        update((p) => ({ ...p, layers: p.layers.filter((l) => l.id !== selectedId) }));
        setSelectedId(null);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [undo, redo, togglePlay, selectedId, update]);

  const getBuffer = useCallback(async () => {
    if (bufferRef.current) return bufferRef.current;
    const p = projectRef.current;
    return p ? getProjectAudio(p) : null;
  }, []);

  if (missing)
    return (
      <div className="grid h-full place-items-center text-zinc-400">
        <div className="text-center">
          <p>This project no longer exists.</p>
          <button onClick={onExit} className="mt-3 text-accent underline">
            Back
          </button>
        </div>
      </div>
    );
  if (!project)
    return (
      <div className="grid h-full place-items-center">
        <Loader2 className="animate-spin text-accent" />
      </div>
    );

  return (
    <div className="flex h-dvh flex-col bg-ink-950">
      {/* top bar */}
      <header className="flex h-13 shrink-0 items-center gap-1 border-b border-white/5 bg-ink-900 px-2 py-1.5">
        <IconBtn
          onClick={async () => {
            if (playingRef.current) playerRef.current?.pause();
            await saveNow();
            onExit();
          }}
          title="Back to dashboard"
        >
          <ArrowLeft size={18} />
        </IconBtn>
        <div className="min-w-0 flex-1 px-1">
          <div className="truncate text-sm font-semibold">{project.name}</div>
          <div className="flex items-center gap-1 text-[10px] text-zinc-500">
            {saveState === "saving" ? <Loader2 size={10} className="animate-spin" /> : saveState === "saved" ? <Check size={10} className="text-emerald-400" /> : <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />}
            {saveState === "saved" ? "All changes saved" : saveState === "saving" ? "Saving…" : getSettings().autosave ? "Unsaved…" : "Unsaved changes"}
          </div>
        </div>
        <IconBtn onClick={undo} disabled={!canUndo} title="Undo (Ctrl+Z)">
          <Undo2 size={18} />
        </IconBtn>
        <IconBtn onClick={redo} disabled={!canRedo} title="Redo (Ctrl+Y)">
          <Redo2 size={18} />
        </IconBtn>
        <IconBtn onClick={async () => (await saveNow(), toast("Project saved"))} title="Save">
          <Save size={18} />
        </IconBtn>
        <button onClick={() => setTab("export")} className="grad-bg ml-1 flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold text-white">
          <Film size={14} /> Export
        </button>
      </header>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        {/* stage */}
        <div className="flex min-h-0 flex-1 flex-col">
          <Preview
            canvasRef={canvasRef}
            rendererRef={rendererRef}
            project={project}
            selectedId={selectedId}
            onSelect={(id) => {
              setSelectedId(id);
              if (id) setTab("layers");
            }}
            onMove={(id, x, y) => update((p) => updateLayer(p, id, { x, y }), "drag-" + id)}
            onScale={(id, s) => update((p) => updateLayer(p, id, { scale: Math.round(s * 100) / 100 }), "scale-" + id)}
          />
          {audioError && <div className="bg-red-500/10 px-3 py-1.5 text-xs text-red-300">{audioError}</div>}
          {/* transport */}
          <div className="flex shrink-0 items-center gap-2 border-t border-white/5 bg-ink-900 px-2 py-1.5">
            <IconBtn onClick={() => seek(0)} title="To start">
              <SkipBack size={16} />
            </IconBtn>
            <button onClick={togglePlay} disabled={audioLoading || !!audioError} className="grad-bg grid h-10 w-10 shrink-0 place-items-center rounded-full text-white shadow-lg disabled:opacity-40" title="Play / pause (Space)">
              {audioLoading ? <Loader2 size={18} className="animate-spin" /> : playing ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
            </button>
            <TimeLabel store={store} duration={duration} />
            <SeekBar store={store} duration={duration} onSeek={seek} />
            <ZoomIn size={14} className="hidden text-zinc-500 sm:block" />
            <input type="range" min={1} max={10} step={0.1} value={zoom} onChange={(e) => setZoom(parseFloat(e.target.value))} className="hidden !w-20 sm:block" title="Timeline zoom" />
          </div>
          <div className="flex h-[132px] shrink-0 flex-col lg:h-[220px]">
            <Timeline project={project} duration={duration} store={store} peaks={peaks} onSeek={seek} selectedId={selectedId} onSelect={(id) => (setSelectedId(id), id && setTab("layers"))} update={update} zoom={zoom} />
          </div>
        </div>

        {/* side panel */}
        <aside className="flex h-[44%] shrink-0 flex-col border-t border-white/5 bg-ink-800 lg:h-auto lg:w-[380px] lg:border-l lg:border-t-0">
          <div className="no-scrollbar flex shrink-0 overflow-x-auto border-b border-white/5">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn("flex min-w-[64px] flex-1 flex-col items-center gap-1 px-2 py-2 text-[10px] font-medium transition", tab === t.id ? "border-b-2 border-accent text-white" : "border-b-2 border-transparent text-zinc-500 hover:text-zinc-200")}
              >
                <t.icon size={16} />
                {t.label}
              </button>
            ))}
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto pb-10">
            {tab === "layers" && <LayersPanel project={project} update={update} selectedId={selectedId} select={setSelectedId} duration={duration} />}
            {tab === "background" && <BackgroundPanel project={project} update={update} toast={toast} />}
            {tab === "effects" && <EffectsPanel project={project} update={update} />}
            {tab === "audio" && <AudioPanel project={project} update={update} duration={duration} getTime={() => store.t} toast={toast} loading={audioLoading} />}
            {tab === "lyrics" && <LyricsPanel project={project} update={update} duration={duration} store={store} seek={seek} playing={playing} togglePlay={togglePlay} select={setSelectedId} toast={toast} />}
            {tab === "project" && <ProjectPanel project={project} update={update} saveNow={saveNow} captureThumb={captureThumb} toast={toast} />}
            {tab === "export" && <ExportPanel project={project} update={update} getBuffer={getBuffer} toast={toast} />}
          </div>
        </aside>
      </div>
      <Toast msg={msg} />
    </div>
  );
}
