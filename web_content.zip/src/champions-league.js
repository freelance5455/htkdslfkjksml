import { recordResult } from './calendar.js';
import { scheduleCompetitionCalendar } from './competition-calendar.js';

export const CHAMPIONS_LEAGUE_ID = 'champions-league';
export const CHAMPIONS_LEAGUE_NAME = 'Champions League Galactique';
const GROUP_LABELS = ['Groupe A','Groupe B','Groupe C','Groupe D','Groupe E','Groupe F','Groupe G','Groupe H'];
const KNOCKOUT_LABELS = { 7:'Huitièmes de finale', 8:'Quarts de finale', 9:'Demi-finales', 10:'Finale' };

function hash(text){let h=2166136261;for(const ch of String(text)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function ordered(ids,seed){return [...ids].sort((a,b)=>hash(`${seed}|${a}`)-hash(`${seed}|${b}`)||a.localeCompare(b));}
function clubs(state){return state.divisions.filter(d=>d.status==='active').flatMap(d=>d.clubs);}
function levelOf(club){if(Number.isFinite(Number(club.lvl)))return Number(club.lvl);const squad=club.damistes||[];return squad.length?squad.reduce((n,p)=>n+(Number(p.level)||0),0)/squad.length:0;}
function rankClubs(state){return clubs(state).slice().sort((a,b)=>(Number(b.points)||0)-(Number(a.points)||0)||levelOf(b)-levelOf(a));}
function makeFixture(state,round,home,away,index,label){return{id:`S${state.season}:${CHAMPIONS_LEAGUE_ID}:R${round}:${index}:${home}:${away}`,season:state.season,divisionId:null,competitionId:CHAMPIONS_LEAGUE_ID,competitionName:CHAMPIONS_LEAGUE_NAME,round,roundLabel:label,home,away,venueType:'neutral',homeAdvantage:false,status:'scheduled',score:null,playedAt:null,arenaId:'terrestrial'};}
function pushRound(state,cup,roundNumber,label,fixtures,participants){const row={number:roundNumber,label,participants:[...participants],fixtureIds:fixtures.map(f=>f.id),completed:false,advancedClubIds:[]};cup.rounds.push(row);cup.fixtures.push(...row.fixtureIds);state.calendar.fixtures.push(...fixtures);scheduleCompetitionCalendar(state);return fixtures;}
function buildGroups(state,entrants){
  const groups=GROUP_LABELS.map(name=>({name,teams:[],table:[],rounds:[]}));
  // Répartition en serpentin, identique au principe du tirage V116 : un club de chaque chapeau par groupe.
  entrants.forEach((club,index)=>{const band=Math.floor(index/8),column=index%8,group=band%2===0?column:7-column;groups[group].teams[band]=club;});
  const base=[[[0,3],[1,2]],[[0,2],[3,1]],[[0,1],[2,3]]];
  for(const group of groups){
    group.table=group.teams.map(id=>({clubId:id,played:0,won:0,drawn:0,lost:0,goalsFor:0,goalsAgainst:0,points:0}));
    const first=base.map((pairs,index)=>pairs.map((pair,matchIndex)=>makeFixture(state,index+1,group.teams[pair[0]],group.teams[pair[1]],groups.indexOf(group)*2+matchIndex+1,`Phase de groupes — ${group.name} — journée ${index+1}`)));
    const returnLeg=base.map((pairs,index)=>pairs.map((pair,matchIndex)=>makeFixture(state,index+4,group.teams[pair[1]],group.teams[pair[0]],groups.indexOf(group)*2+matchIndex+1,`Phase de groupes — ${group.name} — journée ${index+4}`)));
    group.rounds=[...first,...returnLeg];
  }
  return groups;
}
function updateGroupTable(state,group){
  const map=new Map(group.table.map(row=>[row.clubId,row]));
  for(const row of group.table)Object.assign(row,{played:0,won:0,drawn:0,lost:0,goalsFor:0,goalsAgainst:0,points:0});
  for(const fixture of group.rounds.flat()){
    if(fixture.status!=='played')continue;
    const [hs,as]=fixture.score,home=map.get(fixture.home),away=map.get(fixture.away);
    home.played++;away.played++;home.goalsFor+=hs;home.goalsAgainst+=as;away.goalsFor+=as;away.goalsAgainst+=hs;
    if(hs>as){home.won++;home.points+=3;away.lost++;}else if(hs<as){away.won++;away.points+=3;home.lost++;}else{home.drawn++;away.drawn++;home.points++;away.points++;}
  }
  group.table.sort((a,b)=>b.points-a.points||((b.goalsFor-b.goalsAgainst)-(a.goalsFor-a.goalsAgainst))||b.goalsFor-a.goalsFor);
}
function createKnockoutRound(state,cup,entrants,roundNumber){
  const label=KNOCKOUT_LABELS[roundNumber];
  if(!label)throw new Error('Phase finale Champions League inconnue');
  let pairs=[];
  if(roundNumber===7){for(let i=0;i<8;i++)pairs.push([entrants[i],entrants[15-i]]);}
  else for(let i=0;i<entrants.length;i+=2)pairs.push([entrants[i],entrants[i+1]]);
  const fixtures=pairs.map(([home,away],i)=>makeFixture(state,roundNumber,home,away,i+1,label));
  return pushRound(state,cup,roundNumber,label,fixtures,entrants);
}

/** Format historique V116 : 32 clubs, 8 groupes, 6 journées aller-retour, top 2 puis tableau à 16. */
export function createChampionsLeagueSeason(state){
  const cup=state.competitions.find(c=>c.id===CHAMPIONS_LEAGUE_ID);if(!cup)throw new Error('Champions League absente du registre');
  if(cup.season===state.season&&cup.status!=='pending'&&cup.groups?.length===8)return[];
  const ranked=rankClubs(state);if(ranked.length<32)throw new Error(`La Champions League exige 32 clubs actifs ; ${ranked.length} disponibles actuellement`);
  const entrants=ranked.slice(0,32).map(c=>c.id);const groups=buildGroups(state,entrants);
  cup.season=state.season;cup.status='in-progress';cup.format={type:'groups-then-knockout',entrants:32,hats:4,clubsPerHat:8,groups:8,clubsPerGroup:4,groupMatchesPerClub:6,qualifiedPerGroup:2,knockoutLegs:1,smallFinal:false,totalMatches:111,source:'V116-static-audit'};cup.championId=null;cup.groups=groups;cup.rounds=[];cup.fixtures=[];cup.phase='groups';cup.groupRound=1;
  const firstRound=groups.flatMap(g=>g.rounds[0]);
  pushRound(state,cup,1,'Phase de groupes — journée 1',firstRound,entrants);
  // Les cinq autres journées sont inscrites dès le départ au calendrier central.
  for(let day=2;day<=6;day++)pushRound(state,cup,day,`Phase de groupes — journée ${day}`,groups.flatMap(g=>g.rounds[day-1]),entrants);
  return cup.rounds.flatMap(r=>r.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)));
}

function completeRound(state,cup,round){
  round.completed=true;
  if(round.number<=6){
    for(const group of cup.groups)updateGroupTable(state,group);
    cup.groupRound=round.number+1;
    if(round.number===6){
      const qualified=cup.groups.flatMap(group=>group.table.slice(0,2).map(row=>row.clubId));
      if(qualified.length!==16)throw new Error('La phase de groupes doit produire exactement 16 qualifiés');
      round.advancedClubIds=qualified;cup.phase='knockout';createKnockoutRound(state,cup,qualified,7);
    }else round.advancedClubIds=cup.groups.flatMap(group=>group.table.slice(0,2).map(row=>row.clubId));
    return;
  }
  round.advancedClubIds=round.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)?.winnerId).filter(Boolean);
  if(round.number===10){cup.phase='completed';cup.status='completed';cup.championId=round.advancedClubIds[0]||null;cup.completedAtSeason=state.season;return;}
  createKnockoutRound(state,cup,round.advancedClubIds,round.number+1);
}

export function resolveChampionsLeagueDraw(fixture,winnerId=null){if(winnerId)return winnerId;return hash(`${fixture.id}|V116-tie-break`) % 2 ? fixture.home : fixture.away;}
export function recordChampionsLeagueResult(state,fixtureId,homeScore,awayScore,{winnerId=null,matchDetails={}}={}){
  const fixture=state.calendar.fixtures.find(f=>f.id===fixtureId&&f.competitionId===CHAMPIONS_LEAGUE_ID);if(!fixture)throw new Error('Rencontre Champions League introuvable');
  if(fixture.status==='played'||state.calendar.processedFixtureIds.includes(fixtureId))return{accepted:false,nextFixtures:[]};
  if(![homeScore,awayScore].every(n=>Number.isInteger(n)&&n>=0))throw new Error('Score Champions League invalide');
  const cup=state.competitions.find(c=>c.id===CHAMPIONS_LEAGUE_ID),round=cup.rounds.find(r=>r.fixtureIds.includes(fixtureId));if(!round)throw new Error('Journée Champions League introuvable');
  if(round.number>=7){if(homeScore===awayScore)winnerId=resolveChampionsLeagueDraw(fixture,winnerId);else winnerId=homeScore>awayScore?fixture.home:fixture.away;if(![fixture.home,fixture.away].includes(winnerId))throw new Error('Vainqueur absent de la rencontre');}
  const accepted=recordResult(state,fixtureId,homeScore,awayScore,matchDetails);if(!accepted)return{accepted:false,nextFixtures:[]};
  fixture.matchDetails={...matchDetails,winnerId:round.number>=7?winnerId:null,tieBreak:round.number>=7&&homeScore===awayScore?'V116-deterministic-draw-decision':null};if(round.number>=7)fixture.winnerId=winnerId;
  if(!round.fixtureIds.every(id=>state.calendar.fixtures.find(f=>f.id===id)?.status==='played'))return{accepted:true,nextFixtures:[]};
  const before=new Set(cup.fixtures);completeRound(state,cup,round);const nextIds=cup.fixtures.filter(id=>!before.has(id));return{accepted:true,nextFixtures:nextIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).filter(Boolean)};
}

export function getChampionsLeagueStatus(state){const cup=state.competitions.find(c=>c.id===CHAMPIONS_LEAGUE_ID);if(!cup)return null;const round=cup.rounds?.find(r=>!r.completed)||cup.rounds?.at(-1)||null;return{name:CHAMPIONS_LEAGUE_NAME,status:cup.status,phase:cup.phase||'pending',participantCount:cup.format?.entrants||0,groupCount:cup.format?.groups||0,round:round?.number||0,roundLabel:round?.label||'À venir',pendingFixtures:round?.fixtureIds.filter(id=>state.calendar.fixtures.find(f=>f.id===id)?.status!=='played').length||0,championId:cup.championId||null,totalMatches:cup.format?.totalMatches||0};}
export function validateChampionsLeague(state){const cup=state.competitions.find(c=>c.id===CHAMPIONS_LEAGUE_ID);if(!cup)throw new Error('Champions League manquante');if(cup.status==='in-progress'||cup.status==='completed'){
  if(cup.format?.entrants!==32||cup.groups?.length!==8||cup.groups.some(g=>g.teams.length!==4||g.rounds.length!==6))throw new Error('Structure des groupes Champions League invalide');
  if(cup.groups.reduce((n,g)=>n+g.rounds.flat().length,0)!==96)throw new Error('La phase de groupes doit contenir 96 rencontres');
  if(new Set(cup.fixtures).size!==cup.fixtures.length)throw new Error('Rencontre dupliquée dans la Champions League');
  for(const id of cup.fixtures)if(!state.calendar.fixtures.some(f=>f.id===id&&f.competitionId===CHAMPIONS_LEAGUE_ID))throw new Error(`Rencontre absente du calendrier central : ${id}`);
  const clubs=cup.groups.flatMap(g=>g.teams);if(new Set(clubs).size!==32)throw new Error('Un club apparaît plusieurs fois dans les groupes Champions League');
  if(cup.status==='completed'&&(cup.fixtures.length!==111||!cup.championId))throw new Error('Palmarès Champions League incomplet');
}return true;}
