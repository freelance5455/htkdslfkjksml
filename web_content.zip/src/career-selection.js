import { CAREER_MODES } from './career.js';

/** Catalogue de sélection 5.0-D : 24 galaxies et 60 emplacements de clubs.
 * Les 24 emplacements des Ligues C/D restent verrouillés jusqu'à l'activation réelle
 * de leur division. Aucun faux club n'est injecté dans les championnats.
 */
export function getCareerSelectionCatalog(state) {
  const galaxies = (state?.world?.galaxies || []).map((galaxy, index) => ({
    id: `galaxy-${String(index + 1).padStart(2, '0')}`,
    name: galaxy.name,
    icon: galaxy.icon,
    level: galaxy.level,
    available: true
  }));
  const activeByDivision = new Map((state?.divisions || []).map(division => [division.id, division]));
  const clubs = [];
  for (const divisionId of ['super-league', 'ligue-a', 'ligue-b', 'ligue-c', 'ligue-d']) {
    const division = activeByDivision.get(divisionId);
    const isFutureDivision = divisionId === 'ligue-c' || divisionId === 'ligue-d';
    const unlockSeason = divisionId === 'ligue-c' ? 3 : divisionId === 'ligue-d' ? 5 : 1;
    for (let index = 0; index < 12; index++) {
      const slot = index + 1;
      const clubId = `${divisionId}-${String(slot).padStart(2, '0')}`;
      const club = division?.clubs?.[index] || (state?.world?.clubCatalog || []).find(item => item.id === clubId) || null;
      const available = Boolean(club && division?.status === 'active');
      clubs.push({
        id: club?.id || `${divisionId}-${String(slot).padStart(2, '0')}`,
        name: club?.name || `${division?.name || divisionId} · Emplacement ${String(slot).padStart(2, '0')}`,
        divisionId,
        divisionName: division?.name || divisionId,
        slot,
        available,
        locked: !available,
        unlockSeason: isFutureDivision ? unlockSeason : null,
        status: available ? 'available' : 'locked'
      });
    }
  }
  return { galaxies, clubs, modes: CAREER_MODES.map(mode => ({ ...mode })), counts: { galaxies: galaxies.length, clubs: clubs.length, availableClubs: clubs.filter(club => club.available).length, lockedClubs: clubs.filter(club => club.locked).length } };
}

export function validateCareerSelection(state, { galaxyId, clubId, mode }) {
  const catalog = getCareerSelectionCatalog(state);
  const galaxy = catalog.galaxies.find(item => item.id === galaxyId);
  if (!galaxy) throw new Error('Choisis une galaxie parmi les 24 galaxies officielles.');
  if (!catalog.modes.some(item => item.id === mode)) throw new Error('Mode de carrière invalide.');
  if (mode === 'unemployed') return { galaxy, club: null, mode };
  const club = catalog.clubs.find(item => item.id === clubId);
  if (!club || !club.available) {
    const locked = catalog.clubs.find(item => item.id === clubId);
    if (locked?.locked) throw new Error(`Ce club est verrouillé jusqu’à l’ouverture de sa division (saison ${locked.unlockSeason || 'à déterminer'}).`);
    throw new Error('Choisis un club actuellement disponible parmi les 60 emplacements.');
  }
  return { galaxy, club, mode };
}
