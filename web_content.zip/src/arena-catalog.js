import { VISUAL_ARENAS } from './legacy-catalog.js';

const THEMES = [
  { name:'Orion', style:'orbital', capacity:25000, colors:['#20c8ff','#8057ff'], feature:'Dôme orbital et anneaux lumineux' },
  { name:'Véga', style:'crystal', capacity:32000, colors:['#54e6ff','#5b78ff'], feature:'Gradins de cristal bleu' },
  { name:'Sirius', style:'solar', capacity:40000, colors:['#ffc45e','#ff6b46'], feature:'Couronne solaire et tribunes dorées' },
  { name:'Andromède', style:'nebula', capacity:28000, colors:['#d17cff','#35c9ff'], feature:'Voûte de nébuleuse' },
  { name:'Cassiopée', style:'royal', capacity:50000, colors:['#f4d16a','#9a78ff'], feature:'Architecture impériale' },
  { name:'Pégase', style:'sky', capacity:22000, colors:['#8cecff','#f4f8ff'], feature:'Arène aérienne suspendue' },
  { name:'Centaure', style:'volcanic', capacity:36000, colors:['#ff9856','#f0cf74'], feature:'Anneau de lave décoratif' },
  { name:'Lyre', style:'jungle', capacity:18000, colors:['#67e6a1','#49b9c9'], feature:'Jardins bioluminescents' },
  { name:'Nébuleuse', style:'cyber', capacity:30000, colors:['#43f4e7','#b36cff'], feature:'Façade cybernétique' },
  { name:'Atlas', style:'imperial', capacity:60000, colors:['#ffdb73','#67aaff'], feature:'Grand colisée galactique' },
  { name:'Phoenix', style:'comet', capacity:45000, colors:['#ff785e','#ffc45e'], feature:'Toiture en aile de comète' }
];

export function getClubArenaCatalog(state) {
  const catalog = state?.world?.clubCatalog || [];
  const active = (state?.divisions || []).flatMap(d => d.clubs || []);
  const clubsById = new Map([...catalog, ...active].map(c => [c.id, c]));
  const galaxies = state?.world?.galaxies || [];
  const slots = state?.world?.clubArenaSlots || Array.from({length:60},(_,i)=>({slot:i+1,id:`club-arena-${String(i+1).padStart(2,'0')}`}));
  return slots.map((slot,index) => {
    const clubId = slot.assignedClubId || catalog[index]?.id || `${['super-league','ligue-a','ligue-b','ligue-c','ligue-d'][Math.floor(index/12)]}-${String(index%12+1).padStart(2,'0')}`;
    const club = clubsById.get(clubId) || catalog[index] || null;
    const theme = THEMES[index % THEMES.length];
    const galaxyId = club?.damistes?.[0]?.originGalaxyId || galaxies[index % Math.max(1,galaxies.length)]?.id || null;
    const galaxy = galaxies.find(g => g.id === galaxyId) || galaxies[index % Math.max(1,galaxies.length)] || null;
    const facilities = club?.facilities || {};
    return {
      id:slot.id || `club-arena-${String(index+1).padStart(2,'0')}`,
      slot:index+1,
      clubId:club?.id || clubId,
      clubName:club?.name || `Club ${index+1}`,
      divisionId:club?.divisionId || ['super-league','ligue-a','ligue-b','ligue-c','ligue-d'][Math.floor(index/12)],
      divisionName:club?.division || ['Super League','Ligue A','Ligue B','Ligue C','Ligue D'][Math.floor(index/12)],
      galaxyId:galaxy?.id || galaxyId,
      galaxyName:galaxy?.name || 'Galaxie non attribuée',
      name:`Arène ${theme.name} ${String(Math.floor(index/THEMES.length)+1).padStart(2,'0')}`,
      style:theme.style,
      capacity:Number(facilities.arenaCapacity || club?.arenaCapacity || theme.capacity),
      level:Number(facilities.arenaLevel || club?.arenaLevel || 1),
      colors:theme.colors,
      feature:theme.feature,
      visualVariant:VISUAL_ARENAS[index % VISUAL_ARENAS.length],
      active:Boolean(club && (club.catalogStatus !== 'locked' || active.some(c=>c.id===club.id))),
      locked:Boolean(club?.catalogStatus === 'locked' && !active.some(c=>c.id===club.id))
    };
  });
}

export function validateClubArenaCatalog(state) {
  const arenas=getClubArenaCatalog(state);
  if(arenas.length!==60 || new Set(arenas.map(a=>a.id)).size!==60 || new Set(arenas.map(a=>a.clubId)).size!==60) throw new Error('Le catalogue des 60 arènes doit associer exactement une arène à chacun des 60 clubs.');
  return true;
}
