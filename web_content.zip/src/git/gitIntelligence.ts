/**
 * GODEX Phase 7 - Unified Git Intelligence Subsystem
 * Answers deep queries regarding file histories, commit semantic mappings,
 * change lineage, risk assessments, and associated engineering memories.
 */

import { 
  GitRepositoryState, 
  GitCommitEntry, 
  CommitAnalysis, 
  FileHistoryEntry, 
  BranchInfo, 
  GitIntelligenceSummary 
} from './gitTypes';
import { GitRepositoryStateEngine } from './gitRepositoryState';
import { GitHistoryIndexer } from './gitHistoryIndexer';
import { GitCommitAnalyzer } from './gitCommitAnalyzer';
import { GitBranchAnalyzer } from './gitBranchAnalyzer';
import { GitChangeMapper } from './gitChangeMapper';
import { MemoryStore } from '../memory/memoryStore';

export class GitIntelligence {
  private static instance: GitIntelligence | null = null;

  private constructor() {}

  public static getInstance(): GitIntelligence {
    if (!GitIntelligence.instance) {
      GitIntelligence.instance = new GitIntelligence();
    }
    return GitIntelligence.instance;
  }

  /**
   * Retrieves overall repository state.
   */
  public getRepositoryState(workspaceFiles?: Record<string, string>): GitRepositoryState {
    return GitRepositoryStateEngine.getRepositoryState(workspaceFiles);
  }

  /**
   * Returns complete Git Intelligence summary for dashboards.
   */
  public getSummary(workspaceFiles?: Record<string, string>): GitIntelligenceSummary {
    const repoState = this.getRepositoryState(workspaceFiles);
    const commits = GitHistoryIndexer.getCommits(20);
    const branches = GitBranchAnalyzer.getBranches();

    return {
      repoState,
      totalIndexedCommits: commits.length,
      branches,
      recentCommits: commits,
      activeChangedFiles: [...repoState.modifiedFiles, ...repoState.stagedFiles, ...repoState.untrackedFiles]
    };
  }

  /**
   * Performs deep semantic analysis on a specific commit.
   */
  public analyzeCommit(hash: string, workspaceFiles?: Record<string, string>): CommitAnalysis | null {
    const commit = GitHistoryIndexer.getCommit(hash);
    if (!commit) return null;
    return GitCommitAnalyzer.analyzeCommit(commit, workspaceFiles);
  }

  /**
   * Retrieves comprehensive historical evolution of a specific file.
   */
  public getFileHistory(
    filePath: string,
    workspaceFiles?: Record<string, string>,
    store: MemoryStore = MemoryStore.getInstance()
  ): FileHistoryEntry[] {
    const commits = GitHistoryIndexer.getCommitsForFile(filePath);
    const history: FileHistoryEntry[] = [];

    commits.forEach(c => {
      const commitAnalysis = GitCommitAnalyzer.analyzeCommit(c, workspaceFiles, store);
      const isVerified = commitAnalysis.verificationEvidence.length > 0;
      const failureIntroduced = commitAnalysis.relatedFailures.length > 0;
      const repairApplied = commitAnalysis.relatedRepairs.length > 0;

      // Extract symbols affected in this file
      let symbolsInFile: string[] = [];
      if (workspaceFiles && workspaceFiles[filePath]) {
        symbolsInFile = GitChangeMapper.extractSymbolsForFile(filePath, workspaceFiles[filePath]);
      }

      history.push({
        commitHash: c.hash,
        shortHash: c.shortHash,
        date: c.date,
        author: c.author,
        message: c.message,
        changeType: c.parentHashes.length === 0 ? 'ADDED' : 'MODIFIED',
        linesChanged: {
          added: Math.round(c.insertions / Math.max(1, c.changedFiles.length)),
          deleted: Math.round(c.deletions / Math.max(1, c.changedFiles.length))
        },
        affectedSymbols: symbolsInFile.length > 0 ? symbolsInFile.slice(0, 4) : ['UNKNOWN'],
        relatedTasks: commitAnalysis.relatedTasks,
        verified: isVerified,
        failureIntroduced,
        repairApplied
      });
    });

    return history;
  }

  /**
   * Retrieves all branches.
   */
  public getBranches(): BranchInfo[] {
    return GitBranchAnalyzer.getBranches();
  }

  /**
   * Retrieves recent commits list.
   */
  public getRecentCommits(limit = 15): GitCommitEntry[] {
    return GitHistoryIndexer.getCommits(limit);
  }
}
