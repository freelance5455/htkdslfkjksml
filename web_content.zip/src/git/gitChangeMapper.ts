/**
 * GODEX Phase 7 - Git Change-to-Symbol Mapper
 * Uses Phase 1 AST Parser to map line-level changes to exact semantic symbols
 * (functions, classes, interfaces, types).
 * Invariant: If a symbol mapping cannot be verified, returns UNKNOWN.
 */

import { AstParser } from '../intelligence/astParser';

export interface SymbolSpanMapping {
  symbolName: string;
  kind: string;
  startLine: number;
  endLine: number;
  isExported: boolean;
}

export class GitChangeMapper {
  /**
   * Maps a set of modified line numbers in a file to the enclosing AST symbols.
   */
  public static mapLinesToSymbols(
    filePath: string,
    fileContent: string,
    changedLines: number[]
  ): string[] {
    if (!fileContent || changedLines.length === 0) {
      return ['UNKNOWN'];
    }

    try {
      const ast = AstParser.parse(filePath, fileContent);
      if (!ast || !ast.symbols || ast.symbols.length === 0) {
        return ['UNKNOWN'];
      }

      const matchedSymbols = new Set<string>();

      // Check each changed line against symbol ranges
      changedLines.forEach(lineNum => {
        let found = false;

        for (const sym of ast.symbols) {
          const start = sym.line;
          const end = sym.endLine || start + 20; // Default estimate if endLine not populated

          if (lineNum >= start && lineNum <= end) {
            matchedSymbols.add(sym.name);
            found = true;
          }
        }

        if (!found) {
          // If at file level or comments outside declarations
          matchedSymbols.add('FileLevelDeclaration');
        }
      });

      const result = Array.from(matchedSymbols);
      return result.length > 0 ? result : ['UNKNOWN'];
    } catch {
      return ['UNKNOWN'];
    }
  }

  /**
   * Extracts symbols from a file for commit inspection.
   */
  public static extractSymbolsForFile(filePath: string, fileContent: string): string[] {
    try {
      const ast = AstParser.parse(filePath, fileContent);
      if (!ast || !ast.symbols) return [];
      return ast.symbols.map(s => s.name);
    } catch {
      return [];
    }
  }
}
