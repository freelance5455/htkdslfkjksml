/**
 * GODEX Phase 7 - Git Diff Analyzer
 * Analyzes modifications, line additions, line deletions, and maps them to architectural layers.
 */

import { GitDiffSummary } from './gitTypes';
import { DiffGenerator } from '../coding/diffGenerator';

export class GitDiffAnalyzer {
  /**
   * Compares two sets of files (e.g. before/after commit or current workspace vs base)
   */
  public static analyzeFileSetDiff(
    baseFiles: Record<string, string>,
    currentFiles: Record<string, string>
  ): GitDiffSummary {
    const baseKeys = new Set(Object.keys(baseFiles));
    const currKeys = new Set(Object.keys(currentFiles));

    const filesAdded: string[] = [];
    const filesDeleted: string[] = [];
    const filesModified: string[] = [];
    let totalInsertions = 0;
    let totalDeletions = 0;
    const layers = new Set<string>();

    // Detect added and modified
    currKeys.forEach(path => {
      if (!baseKeys.has(path)) {
        filesAdded.push(path);
        const lines = (currentFiles[path] || '').split('\n').length;
        totalInsertions += lines;
        this.addLayer(path, layers);
      } else if (currentFiles[path] !== baseFiles[path]) {
        filesModified.push(path);
        const diff = DiffGenerator.compute(path, baseFiles[path], currentFiles[path]);
        totalInsertions += diff.additions;
        totalDeletions += diff.deletions;
        this.addLayer(path, layers);
      }
    });

    // Detect deleted
    baseKeys.forEach(path => {
      if (!currKeys.has(path)) {
        filesDeleted.push(path);
        const lines = (baseFiles[path] || '').split('\n').length;
        totalDeletions += lines;
        this.addLayer(path, layers);
      }
    });

    return {
      filesAdded,
      filesDeleted,
      filesModified,
      filesRenamed: [],
      totalInsertions,
      totalDeletions,
      affectedSymbols: [],
      affectedLayers: Array.from(layers)
    };
  }

  private static addLayer(path: string, layers: Set<string>): void {
    if (path.includes('components/') || path.includes('views/')) layers.add('ui');
    else if (path.includes('services/')) layers.add('services');
    else if (path.includes('intelligence/')) layers.add('intelligence');
    else if (path.includes('execution/')) layers.add('execution');
    else if (path.includes('debugger/')) layers.add('debugger');
    else if (path.includes('orchestration/')) layers.add('orchestration');
    else if (path.includes('memory/')) layers.add('memory');
    else if (path.includes('git/')) layers.add('git');
    else layers.add('core');
  }
}
