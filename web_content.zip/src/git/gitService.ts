/**
 * GODEX Phase 7 - Git Service
 * Safe, read-only git operations for repository status, commit logs, and diff generation.
 */

import { GitRepositoryState, GitCommitEntry } from './gitTypes';
import { GitRepositoryStateEngine } from './gitRepositoryState';
import { GitHistoryIndexer } from './gitHistoryIndexer';

export class GitService {
  /**
   * Returns current read-only working tree repository state.
   */
  public static getStatus(files?: Record<string, string>): GitRepositoryState {
    return GitRepositoryStateEngine.getRepositoryState(files);
  }

  /**
   * Retrieves bounded commit history log.
   */
  public static getLog(limit = 20): GitCommitEntry[] {
    return GitHistoryIndexer.getCommits(limit);
  }

  /**
   * Shows a specific commit by hash.
   */
  public static getCommit(hash: string): GitCommitEntry | undefined {
    return GitHistoryIndexer.getCommit(hash);
  }
}
