/**
 * GODEX Phase 7 - Git Commit Analyzer
 * Synthesizes deep semantic analysis for commits: affected symbols,
 * architectural layers, associated task IDs, risk, and verification evidence.
 */

import { GitCommitEntry, CommitAnalysis } from './gitTypes';
import { GitChangeMapper } from './gitChangeMapper';
import { MemoryStore } from '../memory/memoryStore';

export class GitCommitAnalyzer {
  /**
   * Performs in-depth semantic analysis on a git commit.
   */
  public static analyzeCommit(
    commit: GitCommitEntry,
    projectFiles?: Record<string, string>,
    store: MemoryStore = MemoryStore.getInstance()
  ): CommitAnalysis {
    const layers = new Set<string>();
    const symbols = new Set<string>();

    // 1. Identify Architectural Layers
    commit.changedFiles.forEach(file => {
      if (file.includes('components/') || file.includes('views/')) layers.add('ui');
      else if (file.includes('services/')) layers.add('services');
      else if (file.includes('intelligence/')) layers.add('intelligence');
      else if (file.includes('execution/')) layers.add('execution');
      else if (file.includes('debugger/')) layers.add('debugger');
      else if (file.includes('orchestration/')) layers.add('orchestration');
      else if (file.includes('memory/')) layers.add('memory');
      else if (file.includes('git/')) layers.add('git');
      else if (file.includes('coding/')) layers.add('coding');
      else layers.add('core');

      // 2. Extract AST Symbols if file content is available
      if (projectFiles && projectFiles[file]) {
        const fileSyms = GitChangeMapper.extractSymbolsForFile(file, projectFiles[file]);
        fileSyms.slice(0, 5).forEach(s => symbols.add(s));
      }
    });

    // 3. Extract Related Task IDs from commit message (e.g. TASK-ORCH-6 or #42)
    const taskMatches = commit.message.match(/TASK-[A-Z0-9_-]+|#[0-9]+/gi) || [];
    const relatedTasks = Array.from(new Set(taskMatches.map(t => t.replace('#', 'TASK-'))));

    // 4. Query Related Memories from MemoryStore
    const relatedMemories = store.getEntriesByCommit(commit.hash);
    const relatedFailures: string[] = [];
    const relatedRepairs: string[] = [];
    const verificationEvidence: string[] = [];

    relatedMemories.forEach(mem => {
      if (mem.type === 'FAILURE') {
        relatedFailures.push(mem.content);
      } else if (mem.type === 'REPAIR') {
        relatedRepairs.push(mem.content);
      } else if (mem.type === 'VERIFICATION') {
        verificationEvidence.push(...mem.evidence);
      }
    });

    // 5. Evaluate Risk Level
    let risk: 'LOW' | 'MEDIUM' | 'HIGH' = 'LOW';
    if (commit.changedFiles.length > 5 || commit.insertions + commit.deletions > 400 || layers.has('core')) {
      risk = 'HIGH';
    } else if (commit.changedFiles.length > 2 || commit.insertions + commit.deletions > 150) {
      risk = 'MEDIUM';
    }

    const symbolsArray = Array.from(symbols);

    return {
      commitId: commit.hash,
      shortHash: commit.shortHash,
      message: commit.message,
      author: commit.author,
      date: commit.date,
      filesChanged: commit.changedFiles,
      symbolsAffected: symbolsArray.length > 0 ? symbolsArray : ['UNKNOWN'],
      architecturalLayers: Array.from(layers),
      risk,
      relatedTasks,
      relatedFailures,
      relatedRepairs,
      verificationEvidence,
      epistemicStatus: symbolsArray.length > 0 ? 'KNOWN' : 'LIKELY'
    };
  }
}
