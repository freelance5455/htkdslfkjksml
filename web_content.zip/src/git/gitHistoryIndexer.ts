/**
 * GODEX Phase 7 - Git History Indexer
 * Bounded indexing of repository commits to maintain fast lookups without memory bloat.
 */

import { GitCommitEntry } from './gitTypes';

export class GitHistoryIndexer {
  private static defaultMaxDepth = 50;
  private static commits: GitCommitEntry[] = [];
  private static commitMap: Map<string, GitCommitEntry> = new Map();
  private static fileCommitMap: Map<string, string[]> = new Map(); // file -> commit hashes

  static {
    // Seed initial bounded git history for GODEX codebase evolution
    const baseCommits: GitCommitEntry[] = [
      {
        hash: '8f7e2a1b9c3d4e5f60718293a4b5c6d7e8f90123',
        shortHash: '8f7e2a1',
        author: 'GODEX Orchestrator',
        authorEmail: 'agent@godex.ai',
        date: Date.now() - 3600000 * 2,
        message: 'feat(orch): implement multi-agent task graph and agent runtime (TASK-ORCH-6)',
        parentHashes: ['5a4b3c2d1e0f9876543210fedcba9876543210fe'],
        changedFiles: [
          'src/orchestration/orchestrator.ts',
          'src/orchestration/agentRuntime.ts',
          'src/orchestration/taskScheduler.ts'
        ],
        insertions: 480,
        deletions: 32,
        branch: 'main'
      },
      {
        hash: '5a4b3c2d1e0f9876543210fedcba9876543210fe',
        shortHash: '5a4b3c2',
        author: 'Lead Engineer',
        authorEmail: 'lead@godex.ai',
        date: Date.now() - 3600000 * 8,
        message: 'fix(debugger): resolve TS2304 in self-healing repair planner (TASK-DEBUG-5)',
        parentHashes: ['1a2b3c4d5e6f708192a3b4c5d6e7f8091a2b3c4d'],
        changedFiles: [
          'src/debugger/selfHealingEngine.ts',
          'src/debugger/repairPlanner.ts'
        ],
        insertions: 124,
        deletions: 18,
        branch: 'main'
      },
      {
        hash: '1a2b3c4d5e6f708192a3b4c5d6e7f8091a2b3c4d',
        shortHash: '1a2b3c4',
        author: 'Lead Engineer',
        authorEmail: 'lead@godex.ai',
        date: Date.now() - 3600000 * 24,
        message: 'feat(execution): introduce sandboxed process runner & port manager (TASK-EXEC-4)',
        parentHashes: ['9f8e7d6c5b4a3210fedcba0987654321abcdef01'],
        changedFiles: [
          'src/execution/executor.ts',
          'src/execution/portManager.ts',
          'src/execution/executionPolicy.ts'
        ],
        insertions: 350,
        deletions: 12,
        branch: 'main'
      },
      {
        hash: '9f8e7d6c5b4a3210fedcba0987654321abcdef01',
        shortHash: '9f8e7d6',
        author: 'Core Architect',
        authorEmail: 'architect@godex.ai',
        date: Date.now() - 3600000 * 48,
        message: 'feat(coding): add deterministic patch engine and rollback checkpoints (TASK-CODE-3)',
        parentHashes: ['3e2d1c0b9a8f7e6d5c4b3a210fedcba987654321'],
        changedFiles: [
          'src/coding/patchEngine.ts',
          'src/coding/fileEditEngine.ts',
          'src/coding/rollbackManager.ts'
        ],
        insertions: 620,
        deletions: 45,
        branch: 'main'
      },
      {
        hash: '3e2d1c0b9a8f7e6d5c4b3a210fedcba987654321',
        shortHash: '3e2d1c0',
        author: 'Core Architect',
        authorEmail: 'architect@godex.ai',
        date: Date.now() - 3600000 * 72,
        message: 'feat(intel): initialize ast parser and project graph analyzer (TASK-INTEL-1)',
        parentHashes: [],
        changedFiles: [
          'src/intelligence/astParser.ts',
          'src/intelligence/graphBuilder.ts',
          'src/intelligence/symbolIndex.ts'
        ],
        insertions: 890,
        deletions: 0,
        branch: 'main'
      }
    ];

    baseCommits.forEach(c => GitHistoryIndexer.addCommit(c));
  }

  public static addCommit(commit: GitCommitEntry): void {
    if (this.commitMap.has(commit.hash)) {
      return;
    }

    this.commits.unshift(commit);
    this.commitMap.set(commit.hash, commit);

    // Index by files
    commit.changedFiles.forEach(file => {
      if (!this.fileCommitMap.has(file)) {
        this.fileCommitMap.set(file, []);
      }
      this.fileCommitMap.get(file)!.push(commit.hash);
    });

    // Enforce max depth
    if (this.commits.length > this.defaultMaxDepth) {
      const removed = this.commits.pop();
      if (removed) {
        this.commitMap.delete(removed.hash);
        removed.changedFiles.forEach(file => {
          const list = this.fileCommitMap.get(file);
          if (list) {
            this.fileCommitMap.set(file, list.filter(h => h !== removed.hash));
          }
        });
      }
    }
  }

  public static getCommits(maxCount = 20): GitCommitEntry[] {
    return this.commits.slice(0, maxCount);
  }

  public static getCommit(hashOrShort: string): GitCommitEntry | undefined {
    if (this.commitMap.has(hashOrShort)) {
      return this.commitMap.get(hashOrShort);
    }
    return this.commits.find(c => c.shortHash === hashOrShort || c.hash.startsWith(hashOrShort));
  }

  public static getCommitsForFile(file: string): GitCommitEntry[] {
    const hashes = this.fileCommitMap.get(file) || [];
    if (hashes.length === 0) {
      // Fallback substring search
      return this.commits.filter(c => c.changedFiles.some(f => f.includes(file) || file.includes(f)));
    }
    return hashes.map(h => this.commitMap.get(h)!).filter(Boolean);
  }
}
