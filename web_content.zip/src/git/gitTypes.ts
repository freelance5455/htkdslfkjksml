/**
 * GODEX Phase 7 - Git Intelligence Types
 * Data contracts for read-only Git repository state, bounded commit history,
 * file history, diff analytics, AST symbol mapping, and branch inspection.
 */

import { EpistemicStatus } from '../memory/memoryTypes';

export interface GitRepositoryState {
  currentBranch: string;
  headCommitHash: string;
  headShortHash: string;
  isWorkingTreeClean: boolean;
  modifiedFiles: string[];
  stagedFiles: string[];
  untrackedFiles: string[];
  aheadCount: number;
  behindCount: number;
  isGitRepo: boolean;
  epistemicStatus: EpistemicStatus;
  lastChecked: number;
}

export interface GitCommitEntry {
  hash: string;
  shortHash: string;
  author: string;
  authorEmail?: string;
  date: number;
  message: string;
  parentHashes: string[];
  changedFiles: string[];
  insertions: number;
  deletions: number;
  branch?: string;
  tags?: string[];
}

export interface CommitAnalysis {
  commitId: string;
  shortHash: string;
  message: string;
  author: string;
  date: number;
  filesChanged: string[];
  symbolsAffected: string[];
  architecturalLayers: string[];
  risk: 'LOW' | 'MEDIUM' | 'HIGH';
  relatedTasks: string[];
  relatedFailures: string[];
  relatedRepairs: string[];
  verificationEvidence: string[];
  epistemicStatus: EpistemicStatus;
}

export interface FileHistoryEntry {
  commitHash: string;
  shortHash: string;
  date: number;
  author: string;
  message: string;
  changeType: 'ADDED' | 'MODIFIED' | 'DELETED' | 'RENAMED';
  linesChanged: {
    added: number;
    deleted: number;
  };
  affectedSymbols: string[];
  relatedTasks: string[];
  verified: boolean;
  failureIntroduced?: boolean;
  repairApplied?: boolean;
}

export interface GitDiffSummary {
  filesAdded: string[];
  filesDeleted: string[];
  filesModified: string[];
  filesRenamed: Array<{ from: string; to: string }>;
  totalInsertions: number;
  totalDeletions: number;
  affectedSymbols: string[];
  affectedLayers: string[];
}

export interface BranchInfo {
  name: string;
  isCurrent: boolean;
  upstreamBranch?: string;
  ahead: number;
  behind: number;
  lastCommitHash: string;
  lastCommitMessage: string;
  lastCommitDate: number;
}

export interface GitIntelligenceSummary {
  repoState: GitRepositoryState;
  totalIndexedCommits: number;
  branches: BranchInfo[];
  recentCommits: GitCommitEntry[];
  activeChangedFiles: string[];
}
