"""Gabungkan src/*.js + assets/ menjadi satu file index.html (offline, tanpa server).
Jalankan:  python3 src/build.py     (dari folder project)"""
import base64, json, glob, os
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
mime={'webp':'image/webp','jpg':'image/jpeg','png':'image/png'}
assets={}
for f in sorted(glob.glob(root+'/assets/*/*.*')):
    k,ext=os.path.splitext(os.path.basename(f)); ext=ext[1:]
    assets[k]='data:%s;base64,%s'%(mime[ext],base64.b64encode(open(f,'rb').read()).decode())
js=''.join(open(root+'/src/'+n,encoding='utf8').read() for n in ['1-data-audio.js','2-gameplay.js','3-render.js','3b-rig-anim.js','4-ui-input-main.js'])
fm=open(root+'/assets/framemeta.json',encoding='utf8').read()
html=open(root+'/src/template.html',encoding='utf8').read().replace('__GAME__',js.replace('__ASSETS__',json.dumps(assets)).replace('__FRAMEMETA__',fm))
open(root+'/index.html','w',encoding='utf8').write(html)
open(root+'/android/www/index.html','w',encoding='utf8').write(html)
print('OK ->',root+'/index.html',len(html)//1024,'KB')
