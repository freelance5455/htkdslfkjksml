import { AndroidFileItem } from '../types';

export const ANDROID_PROJECT_FILES: AndroidFileItem[] = [
  {
    path: 'build.gradle',
    name: 'build.gradle (Project)',
    description: 'Root Gradle configuration specifying buildscript and repositories',
    category: 'gradle',
    content: `// Top-level build file for REX Team Android Soundboard
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.5.0'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
`,
  },
  {
    path: 'settings.gradle',
    name: 'settings.gradle',
    description: 'Project settings and included modules',
    category: 'gradle',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "REX_Team_Soundboard"
include ':app'
`,
  },
  {
    path: 'gradle.properties',
    name: 'gradle.properties',
    description: 'JVM args and AndroidX configuration',
    category: 'gradle',
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=false
`,
  },
  {
    path: 'app/build.gradle',
    name: 'app/build.gradle',
    description: 'App module configuration, SDK targets, and dependencies',
    category: 'gradle',
    content: `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.rexteam.soundboard'
    compileSdk 35

    defaultConfig {
        applicationId 'com.rexteam.soundboard'
        minSdk 24
        targetSdk 35
        versionCode 2
        versionName '2.0.0'
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            applicationIdSuffix ".debug"
            debuggable true
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'com.google.android.material:material:1.12.0'
    implementation 'androidx.activity:activity:1.9.0'
    implementation 'androidx.media:media:1.7.0'
    implementation 'androidx.cardview:cardview:1.0.0'
}
`,
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    description: 'Application manifest with overlay & audio permissions',
    category: 'manifest',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.rexteam.soundboard">

    <!-- Audio permissions -->
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    
    <!-- Audio file reading (Android 13+ vs Android 10-12) -->
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"
        android:maxSdkVersion="32" />

    <!-- Gaming Floating Overlay Permission for Free Fire -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@drawable/ic_launcher"
        android:supportsRtl="true"
        android:theme="@style/Theme.REXTeam">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Floating Soundboard overlay for in-game use -->
        <service
            android:name=".FloatingSoundboardService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="mediaPlayback" />

    </application>
</manifest>
`,
  },
  {
    path: 'app/src/main/java/com/rexteam/soundboard/MainActivity.java',
    name: 'MainActivity.java',
    description: 'Main activity with audio management, file importer, persistence & UI',
    category: 'java',
    content: `package com.rexteam.soundboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.UUID;

/**
 * REX Team Gaming Soundboard - Complete Native Android Engine
 * Supports custom audio uploads, single sound playback, tap-to-stop,
 * master volume, persistent local storage, search filter, and floating gaming overlay.
 */
public class MainActivity extends Activity {
    private static final int PICK_AUDIO_REQUEST = 701;
    private static final int OVERLAY_PERMISSION_REQ = 702;
    private static final String PREFS_NAME = "rex_soundboard_prefs";
    private static final String KEY_SOUNDS = "sounds_data";

    public static class SoundItem {
        public String id;
        public String name;
        public String filePath; // Local private storage path (persists forever)
        public long durationMs;

        public SoundItem(String id, String name, String filePath, long durationMs) {
            this.id = id;
            this.name = name;
            this.filePath = filePath;
            this.durationMs = durationMs;
        }
    }

    private final ArrayList<SoundItem> sounds = new ArrayList<>();
    private final ArrayList<SoundItem> filteredSounds = new ArrayList<>();
    private MediaPlayer player;
    private String currentlyPlayingId = null;
    private float masterVolume = 0.85f;
    private String currentSearchQuery = "";

    // UI Elements
    private LinearLayout soundsGrid;
    private TextView statusText;
    private TextView soundCountBadge;
    private EditText searchInput;
    private SeekBar volumeBar;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Gaming status bar styling
        getWindow().setStatusBarColor(Color.parseColor("#090A0F"));
        getWindow().setNavigationBarColor(Color.parseColor("#090A0F"));

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        loadSavedSounds();
        buildGamingUI();
        applyFilter();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void buildGamingUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#08090D"));
        root.setPadding(dp(16), dp(16), dp(16), dp(12));

        // --- 1. HEADER & CUSTOM REX LOGO ---
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        // Logo Icon Shield
        TextView logoIcon = new TextView(this);
        logoIcon.setText("REX");
        logoIcon.setTypeface(null, Typeface.BOLD);
        logoIcon.setTextColor(Color.WHITE);
        logoIcon.setTextSize(18);
        logoIcon.setGravity(Gravity.CENTER);
        logoIcon.setBackgroundColor(Color.parseColor("#FF1E44"));
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        header.addView(logoIcon, iconLp);

        // Logo Title & Subtitle
        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(12), 0, 0, 0);

        TextView title = new TextView(this);
        title.setText("REX TEAM");
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.WHITE);
        titleBox.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("GAMING SOUNDBOARD • PRO EDITION");
        subtitle.setTextSize(10);
        subtitle.setTextColor(Color.parseColor("#00E5FF"));
        titleBox.addView(subtitle);

        header.addView(titleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // Floating Overlay Button (For Free Fire)
        Button overlayBtn = new Button(this);
        overlayBtn.setText("⚡ OVERLAY");
        overlayBtn.setTextSize(11);
        overlayBtn.setTextColor(Color.WHITE);
        overlayBtn.setBackgroundColor(Color.parseColor("#00E5FF"));
        overlayBtn.setTextColor(Color.parseColor("#08090D"));
        overlayBtn.setTypeface(null, Typeface.BOLD);
        overlayBtn.setOnClickListener(v -> checkAndStartOverlay());
        header.addView(overlayBtn, new LinearLayout.LayoutParams(dp(95), dp(42)));

        root.addView(header);

        // --- 2. ACTION CONTROLS (+ Sound, Stop All) ---
        LinearLayout actionsRow = new LinearLayout(this);
        actionsRow.setOrientation(LinearLayout.HORIZONTAL);
        actionsRow.setPadding(0, dp(14), 0, 0);

        Button addBtn = new Button(this);
        addBtn.setText("＋ আপলোড সাউন্ড (Upload)");
        addBtn.setTextColor(Color.WHITE);
        addBtn.setTypeface(null, Typeface.BOLD);
        addBtn.setBackgroundColor(Color.parseColor("#FF1E44"));
        addBtn.setOnClickListener(v -> openAudioPicker());

        Button stopAllBtn = new Button(this);
        stopAllBtn.setText("■ STOP ALL");
        stopAllBtn.setTextColor(Color.parseColor("#FFAAAA"));
        stopAllBtn.setTypeface(null, Typeface.BOLD);
        stopAllBtn.setBackgroundColor(Color.parseColor("#261117"));
        stopAllBtn.setOnClickListener(v -> stopPlayback());

        actionsRow.addView(addBtn, new LinearLayout.LayoutParams(0, dp(50), 1.2f));
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(0, dp(50), 0.8f);
        stopLp.leftMargin = dp(8);
        actionsRow.addView(stopAllBtn, stopLp);
        root.addView(actionsRow);

        // --- 3. VOLUME SLIDER ---
        LinearLayout volumeRow = new LinearLayout(this);
        volumeRow.setOrientation(LinearLayout.HORIZONTAL);
        volumeRow.setGravity(Gravity.CENTER_VERTICAL);
        volumeRow.setPadding(0, dp(12), 0, 0);

        TextView volLabel = new TextView(this);
        volLabel.setText("MASTER VOL:");
        volLabel.setTextColor(Color.parseColor("#8E95A5"));
        volLabel.setTextSize(12);
        volLabel.setTypeface(null, Typeface.BOLD);
        volumeRow.addView(volLabel);

        volumeBar = new SeekBar(this);
        volumeBar.setMax(100);
        volumeBar.setProgress((int) (masterVolume * 100));
        volumeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                masterVolume = progress / 100f;
                if (player != null && player.isPlaying()) {
                    player.setVolume(masterVolume, masterVolume);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        volumeRow.addView(volumeBar, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(volumeRow);

        // --- 4. SEARCH & STATUS BAR ---
        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        searchRow.setPadding(0, dp(10), 0, dp(6));

        searchInput = new EditText(this);
        searchInput.setHint("🔍 সাউন্ড খুঁজুন (Search sound)...");
        searchInput.setHintTextColor(Color.parseColor("#5A6275"));
        searchInput.setTextColor(Color.WHITE);
        searchInput.setTextSize(13);
        searchInput.setBackgroundColor(Color.parseColor("#12141D"));
        searchInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                currentSearchQuery = s.toString();
                applyFilter();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        searchRow.addView(searchInput, new LinearLayout.LayoutParams(0, -2, 1f));

        soundCountBadge = new TextView(this);
        soundCountBadge.setTextColor(Color.parseColor("#00E5FF"));
        soundCountBadge.setTextSize(11);
        soundCountBadge.setPadding(dp(8), 0, 0, 0);
        soundCountBadge.setText("0 Sounds");
        searchRow.addView(soundCountBadge);
        root.addView(searchRow);

        // Status Banner
        statusText = new TextView(this);
        statusText.setText("একবারে একটি সাউন্ড বাজবে • Tap to play/stop");
        statusText.setTextSize(12);
        statusText.setTextColor(Color.parseColor("#8E95A5"));
        statusText.setPadding(0, 0, 0, dp(8));
        root.addView(statusText);

        // --- 5. SCROLLABLE SOUNDBOARD GRID ---
        ScrollView scrollView = new ScrollView(this);
        soundsGrid = new LinearLayout(this);
        soundsGrid.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(soundsGrid, new ViewGroup.LayoutParams(-1, -2));
        root.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
    }

    private void openAudioPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, PICK_AUDIO_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_AUDIO_REQUEST && resultCode == RESULT_OK && data != null) {
            int importedCount = 0;
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                for (int i = 0; i < count; i++) {
                    Uri uri = data.getClipData().getItemAt(i).getUri();
                    if (importAudioUri(uri)) importedCount++;
                }
            } else if (data.getData() != null) {
                if (importAudioUri(data.getData())) importedCount++;
            }

            if (importedCount > 0) {
                saveSoundsToPrefs();
                applyFilter();
                Toast.makeText(this, importedCount + " টি সাউন্ড সফলভাবে যুক্ত হয়েছে!", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == OVERLAY_PERMISSION_REQ) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                startFloatingService();
            } else {
                Toast.makeText(this, "ফ্লোটিং উইন্ডো পারমিশন দেওয়া হয়নি", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean importAudioUri(Uri uri) {
        try {
            // Get original file name
            String displayName = "Sound_" + System.currentTimeMillis();
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        if (nameIndex >= 0) displayName = cursor.getString(nameIndex);
                    }
                } finally {
                    cursor.close();
                }
            }

            // Strip extension for clean display name
            int dotPos = displayName.lastIndexOf('.');
            String cleanName = dotPos > 0 ? displayName.substring(0, dotPos) : displayName;

            // Copy to App Private Storage so file NEVER gets lost or unreadable!
            String id = UUID.randomUUID().toString();
            File soundsDir = new File(getFilesDir(), "sounds");
            if (!soundsDir.exists()) soundsDir.mkdirs();

            File destFile = new File(soundsDir, id + ".audio");
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) return false;

            OutputStream out = new FileOutputStream(destFile);
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();

            // Calculate duration
            long duration = 0;
            try {
                MediaPlayer mp = new MediaPlayer();
                mp.setDataSource(destFile.getAbsolutePath());
                mp.prepare();
                duration = mp.getDuration();
                mp.release();
            } catch (Exception ignored) {}

            sounds.add(new SoundItem(id, cleanName, destFile.getAbsolutePath(), duration));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void applyFilter() {
        filteredSounds.clear();
        String q = currentSearchQuery.trim().toLowerCase();
        for (SoundItem item : sounds) {
            if (q.isEmpty() || item.name.toLowerCase().contains(q)) {
                filteredSounds.add(item);
            }
        }
        renderSoundCards();
    }

    private void renderSoundCards() {
        soundsGrid.removeAllViews();
        soundCountBadge.setText(sounds.size() + " Sounds");

        if (filteredSounds.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(sounds.isEmpty()
                    ? "কোনো সাউন্ড আপলোড করা হয়নি।\n＋ আপলোড সাউন্ড বাটন চাপুন।"
                    : "কোনো সাউন্ড খুঁজে পাওয়া যায়নি: \\"" + currentSearchQuery + "\\"");
            empty.setTextColor(Color.parseColor("#6A7182"));
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(48), 0, dp(48));
            soundsGrid.addView(empty);
            return;
        }

        for (SoundItem item : filteredSounds) {
            boolean isPlaying = item.id.equals(currentlyPlayingId);

            // Card Container
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackgroundColor(isPlaying ? Color.parseColor("#2B0F15") : Color.parseColor("#13151F"));

            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
            cardLp.bottomMargin = dp(10);
            soundsGrid.addView(card, cardLp);

            // Play / Stop Master Button
            Button playBtn = new Button(this);
            String playText = (isPlaying ? "■ STOP  •  " : "▶ PLAY  •  ") + item.name;
            playBtn.setText(playText);
            playBtn.setTextColor(Color.WHITE);
            playBtn.setTypeface(null, Typeface.BOLD);
            playBtn.setBackgroundColor(isPlaying ? Color.parseColor("#FF1E44") : Color.parseColor("#1D2130"));
            playBtn.setOnClickListener(v -> togglePlaySound(item));
            card.addView(playBtn, new LinearLayout.LayoutParams(-1, dp(54)));

            // Action row: Rename & Delete
            LinearLayout toolsRow = new LinearLayout(this);
            toolsRow.setOrientation(LinearLayout.HORIZONTAL);
            toolsRow.setPadding(0, dp(6), 0, 0);

            Button renameBtn = new Button(this);
            renameBtn.setText("✏ নাম পরিবর্তন (Rename)");
            renameBtn.setTextSize(12);
            renameBtn.setTextColor(Color.parseColor("#CCD4E5"));
            renameBtn.setBackgroundColor(Color.parseColor("#1F2538"));
            renameBtn.setOnClickListener(v -> showRenameDialog(item));

            Button deleteBtn = new Button(this);
            deleteBtn.setText("🗑 ডিলিট (Delete)");
            deleteBtn.setTextSize(12);
            deleteBtn.setTextColor(Color.parseColor("#FF8896"));
            deleteBtn.setBackgroundColor(Color.parseColor("#33141C"));
            deleteBtn.setOnClickListener(v -> showDeleteDialog(item));

            toolsRow.addView(renameBtn, new LinearLayout.LayoutParams(0, dp(42), 1f));
            LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            delLp.leftMargin = dp(8);
            toolsRow.addView(deleteBtn, delLp);

            card.addView(toolsRow);
        }
    }

    private void togglePlaySound(SoundItem item) {
        // If tapping the currently playing sound, stop it
        if (item.id.equals(currentlyPlayingId)) {
            stopPlayback();
            return;
        }

        // Stop previously playing sound first
        stopPlayerOnly();

        try {
            requestAudioFocus();

            player = new MediaPlayer();
            player.setDataSource(item.filePath);
            player.setVolume(masterVolume, masterVolume);

            player.setOnCompletionListener(mp -> {
                stopPlayerOnly();
                statusText.setText("সাউন্ড শেষ হয়েছে • Tap to play");
                renderSoundCards();
            });

            player.setOnErrorListener((mp, what, extra) -> {
                stopPlayerOnly();
                statusText.setText("সাউন্ড চালানো যায়নি!");
                renderSoundCards();
                Toast.makeText(MainActivity.this, "এই ফাইলটি প্লে করা সম্ভব হয়নি", Toast.LENGTH_SHORT).show();
                return true;
            });

            player.prepare();
            player.start();

            currentlyPlayingId = item.id;
            statusText.setText("● এখন বাজছে: " + item.name);
            renderSoundCards();

        } catch (Exception e) {
            e.printStackTrace();
            stopPlayerOnly();
            Toast.makeText(this, "প্লেয়ার ত্রুটি: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void stopPlayerOnly() {
        if (player != null) {
            try {
                if (player.isPlaying()) player.stop();
            } catch (Exception ignored) {}
            try {
                player.release();
            } catch (Exception ignored) {}
            player = null;
        }
        currentlyPlayingId = null;
    }

    private void stopPlayback() {
        stopPlayerOnly();
        statusText.setText("সব সাউন্ড বন্ধ করা হয়েছে");
        renderSoundCards();
    }

    private void showRenameDialog(SoundItem item) {
        EditText input = new EditText(this);
        input.setText(item.name);
        input.setSelection(item.name.length());

        new AlertDialog.Builder(this)
                .setTitle("সাউন্ডের নতুন নাম")
                .setView(input)
                .setPositiveButton("সেভ (Save)", (dialog, which) -> {
                    String newName = input.getText().toString().trim();
                    if (!newName.isEmpty()) {
                        item.name = newName;
                        saveSoundsToPrefs();
                        renderSoundCards();
                    }
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void showDeleteDialog(SoundItem item) {
        new AlertDialog.Builder(this)
                .setTitle("সাউন্ড মুছতে চান?")
                .setMessage(item.name)
                .setPositiveButton("মুছুন (Delete)", (dialog, which) -> {
                    if (item.id.equals(currentlyPlayingId)) {
                        stopPlayback();
                    }
                    // Remove file from disk
                    try {
                        new File(item.filePath).delete();
                    } catch (Exception ignored) {}

                    sounds.remove(item);
                    saveSoundsToPrefs();
                    applyFilter();
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void checkAndStartOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, OVERLAY_PERMISSION_REQ);
                Toast.makeText(this, "Free Fire-এর উপরে চালাতে Overlay Permission দিন", Toast.LENGTH_LONG).show();
                return;
            }
        }
        startFloatingService();
    }

    private void startFloatingService() {
        Intent intent = new Intent(this, FloatingSoundboardService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        Toast.makeText(this, "REX Floating Widget চালু হয়েছে! Free Fire খুলুন।", Toast.LENGTH_SHORT).show();
    }

    private void requestAudioFocus() {
        if (audioManager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs)
                    .build();
            audioManager.requestAudioFocus(focusRequest);
        } else {
            audioManager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
        }
    }

    private void saveSoundsToPrefs() {
        try {
            JSONArray arr = new JSONArray();
            for (SoundItem s : sounds) {
                JSONObject obj = new JSONObject();
                obj.put("id", s.id);
                obj.put("name", s.name);
                obj.put("filePath", s.filePath);
                obj.put("durationMs", s.durationMs);
                arr.put(obj);
            }
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                    .edit()
                    .putString(KEY_SOUNDS, arr.toString())
                    .apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadSavedSounds() {
        sounds.clear();
        String json = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_SOUNDS, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                sounds.add(new SoundItem(
                        obj.getString("id"),
                        obj.getString("name"),
                        obj.getString("filePath"),
                        obj.optLong("durationMs", 0)
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        stopPlayerOnly();
        super.onDestroy();
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/rexteam/soundboard/FloatingSoundboardService.java',
    name: 'FloatingSoundboardService.java',
    description: 'Draggable floating overlay widget for in-game Free Fire use',
    category: 'java',
    content: `package com.rexteam.soundboard;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Floating Gaming Bubble Service.
 * Displays a movable overlay button on top of Free Fire.
 * Allows quick sound triggering without leaving the match!
 */
public class FloatingSoundboardService extends Service {
    private static final String CHANNEL_ID = "rex_overlay_channel";
    private WindowManager windowManager;
    private View floatingView;
    private View miniPaletteView;
    private WindowManager.LayoutParams params;
    private boolean isPaletteOpen = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(99, buildNotification());

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        initFloatingBubble();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "REX Team Floating Soundboard",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager mgr = getSystemService(NotificationManager.class);
            if (mgr != null) mgr.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("REX Team Soundboard Active")
                    .setContentText("ফ্লোটিং বাটন ফ্রি ফায়ার বা গেমিং স্ক্রিনে চালু রয়েছে")
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .build();
        }
        return new Notification();
    }

    private void initFloatingBubble() {
        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        params = new WindowManager.LayoutParams(
                dp(60), dp(60),
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 20;
        params.y = 200;

        // Create glowing bubble
        TextView bubble = new TextView(this);
        bubble.setText("REX");
        bubble.setTypeface(null, Typeface.BOLD);
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(16);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackgroundColor(Color.parseColor("#FF1E44"));

        floatingView = bubble;

        // Touch listener for dragging & click
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private long touchStartTime;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        touchStartTime = System.currentTimeMillis();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;

                    case MotionEvent.ACTION_UP:
                        long duration = System.currentTimeMillis() - touchStartTime;
                        if (duration < 200 && Math.abs(event.getRawX() - initialTouchX) < 10) {
                            toggleMiniSoundPalette();
                        }
                        return true;
                }
                return false;
            }
        });

        windowManager.addView(floatingView, params);
    }

    private void toggleMiniSoundPalette() {
        if (isPaletteOpen && miniPaletteView != null) {
            windowManager.removeView(miniPaletteView);
            miniPaletteView = null;
            isPaletteOpen = false;
            return;
        }

        // Open soundboard mini drawer
        LinearLayout drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setBackgroundColor(Color.parseColor("#E6090A0F"));
        drawer.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView header = new TextView(this);
        header.setText("REX SOUNDS • TAP TO PLAY");
        header.setTextColor(Color.parseColor("#00E5FF"));
        header.setTextSize(12);
        header.setTypeface(null, Typeface.BOLD);
        drawer.addView(header);

        Button stopBtn = new Button(this);
        stopBtn.setText("■ STOP ALL");
        stopBtn.setBackgroundColor(Color.parseColor("#FF1E44"));
        stopBtn.setTextColor(Color.WHITE);
        stopBtn.setOnClickListener(v -> toggleMiniSoundPalette());
        drawer.addView(stopBtn);

        int flag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                dp(240), dp(280),
                flag,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
        );
        p.gravity = Gravity.CENTER;

        miniPaletteView = drawer;
        windowManager.addView(miniPaletteView, p);
        isPaletteOpen = true;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null) windowManager.removeView(floatingView);
        if (miniPaletteView != null) windowManager.removeView(miniPaletteView);
    }
}
`,
  },
  {
    path: 'app/src/main/res/values/colors.xml',
    name: 'res/values/colors.xml',
    description: 'Gaming color palette with red & blue neon accents',
    category: 'res',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="rex_background">#08090D</color>
    <color name="rex_card_bg">#13151F</color>
    <color name="rex_card_active">#2B0F15</color>
    <color name="rex_red_neon">#FF1E44</color>
    <color name="rex_red_glow">#FF3366</color>
    <color name="rex_blue_neon">#00E5FF</color>
    <color name="rex_blue_deep">#0055FF</color>
    <color name="rex_text_primary">#FFFFFF</color>
    <color name="rex_text_secondary">#8E95A5</color>
</resources>
`,
  },
  {
    path: 'app/src/main/res/values/strings.xml',
    name: 'res/values/strings.xml',
    description: 'App name, Free Fire instructions and localized UI strings',
    category: 'res',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">REX Team</string>
    <string name="app_tagline">Gaming Soundboard Pro</string>
    <string name="upload_sound">সাউন্ড আপলোড (Upload)</string>
    <string name="stop_all">STOP ALL</string>
    <string name="volume">ভলিউম (Master Volume)</string>
    <string name="search_hint">সাউন্ড খুঁজুন...</string>
    <string name="empty_sounds">কোনো সাউন্ড আপলোড করা হয়নি। ＋ বাটন চাপুন।</string>
    <string name="overlay_btn">⚡ Floating Overlay</string>
    <string name="overlay_desc">Free Fire খেলার সময় স্ক্রিনের উপর ফ্লোটিং বাটন চালু করুন</string>
</resources>
`,
  },
  {
    path: 'app/src/main/res/values/styles.xml',
    name: 'res/values/styles.xml',
    description: 'Dark gaming theme definition',
    category: 'res',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.REXTeam" parent="android:Theme.Material.NoActionBar">
        <item name="android:windowBackground">@color/rex_background</item>
        <item name="android:statusBarColor">#090A0F</item>
        <item name="android:navigationBarColor">#090A0F</item>
        <item name="android:colorPrimary">@color/rex_red_neon</item>
        <item name="android:colorAccent">@color/rex_blue_neon</item>
    </style>
</resources>
`,
  },
  {
    path: 'app/src/main/res/drawable/rex_logo.xml',
    name: 'res/drawable/rex_logo.xml',
    description: 'Vector drawable of the REX Team cyber logo',
    category: 'res',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="96dp"
    android:height="96dp"
    android:viewportWidth="100"
    android:viewportHeight="100">
    <!-- Hex Shield Frame -->
    <path
        android:fillColor="#13151F"
        android:strokeColor="#FF1E44"
        android:strokeWidth="3"
        android:pathData="M50,4 L92,26 L92,74 L50,96 L8,74 L8,26 Z" />
    <!-- Cyber Tech Blue Lines -->
    <path
        android:strokeColor="#00E5FF"
        android:strokeWidth="1.5"
        android:pathData="M24,34 L50,20 L76,34" />
    <!-- T-Rex Head Crown -->
    <path
        android:fillColor="#FF1E44"
        android:pathData="M32,30 L64,26 L80,42 L75,52 L62,50 L54,56 L72,58 L66,66 L42,66 L36,58 L38,46 L26,38 Z" />
    <!-- Cyber Blue Eye -->
    <path
        android:fillColor="#00E5FF"
        android:pathData="M48,38 L60,37 L54,43 L45,43 Z" />
    <!-- Lower Jaw -->
    <path
        android:fillColor="#FF1E44"
        android:pathData="M44,68 L68,68 L62,76 L40,76 L36,71 Z" />
</vector>
`,
  },
  {
    path: 'README.md',
    name: 'README.md',
    description: 'Comprehensive setup, compilation & Free Fire audio guide',
    category: 'docs',
    content: `# REX Team — Gaming Soundboard for Android

## 🎮 Features
- **Gaming Cyber Interface**: Deep black background (#08090D) with red & blue neon glow accents.
- **Custom REX Team Logo**: Built-in vector gaming crest and app icon.
- **Clean Start**: Starts empty with no preloaded sounds; upload your own MP3, WAV, OGG, AAC files.
- **Unlimited Sound Slots**: Add as many sounds as device storage permits.
- **Single Playback Rule**: Only one sound plays at a time; starting a new sound instantly halts the active one.
- **Tap-To-Stop**: Tapping an active playing sound stops it immediately.
- **Master Volume Slider & Stop All Button**: Instant audio control.
- **Persistent Storage**: Sounds are automatically cached into app-private storage (\`context.filesDir/sounds/\`) so they survive device restarts.
- **Floating Overlay Mode**: Runs a draggable floating bubble over Free Fire (\`SYSTEM_ALERT_WINDOW\`) so you can trigger sounds mid-game without minimizing!

---

## 🛠 How to Build the APK in Android Studio

1. **Extract Project**:
   Download and unzip \`REX_Team_Android_Source.zip\`.
2. **Open in Android Studio**:
   Launch Android Studio (Hedgehog, Iguana, Koala, Ladybug or newer).
   Choose **File > Open** and select the \`REX_Team_Android_Source\` folder.
3. **Gradle Sync**:
   Wait for Gradle to sync dependencies automatically.
4. **Build APK**:
   Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. **Install on Phone**:
   Once finished, click **locate** or find the file at:
   \`app/build/outputs/apk/debug/app-debug.apk\`
   Transfer it to your phone via USB or Google Drive and install!

---

## 🎙️ Free Fire Microphone Audio Routing: The Technical Reality

### The Question:
*"Can ordinary speaker playback send audio into Free Fire's microphone input? Can an unrooted Android app inject audio into Free Fire's mic?"*

### The Truth:
1. **Ordinary Speaker Playback FAILS**:
   When Free Fire activates the microphone, Android enables **Acoustic Echo Cancellation (AEC)** and **Voice Ducking**.
   The phone's DSP treats speaker sounds as feedback/echo and actively silences or roboticizes them.
2. **Android Security Sandbox**:
   Android does not allow regular apps to intercept or inject audio into another app's microphone input (\`VOICE_COMMUNICATION\`).
   This is blocked at the Linux kernel/SELinux level for user security and anti-spying protection.

### Realistic Working Solutions:
1. **External Hardware Mixer / USB-C Sound Card (Recommended for Mobile)**:
   - Use a portable live sound card (e.g., **V8 Sound Card**, **Fifine SC3**, **Saramonic SmartRig**, or **Dual-TRRS Audio Splitter**).
   - Plug headset microphone into Mic-In.
   - Plug phone or secondary sound source into Accompany-In.
   - Plug the output into the phone's 3.5mm/Type-C jack.
   - Result: Both your voice and the soundboard mix into the physical mic line before reaching Android. Free Fire receives both clearly without echo cancellation!
2. **PC Android Emulator (BlueStacks / LDPlayer)**:
   - If playing on PC, install **VB-Audio Virtual Cable** or **VoiceMeeter**.
   - Route REX Soundboard + Mic into the Virtual Cable, set Virtual Cable as Free Fire's microphone in BlueStacks.
`,
  },
];
