// Standalone single-file entry — mounts the full SPA with zero framework
// runtime (no Next.js, no module fetching). Bundled by scripts/build-single.mjs
// into ONE self-contained index.html that opens via file:// / double-click.
import { createRoot } from "react-dom/client";
import App from "./App";

const el = document.getElementById("root");
if (el) {
  createRoot(el).render(<App />);
}
