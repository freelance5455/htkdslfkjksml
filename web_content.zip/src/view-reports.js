/* Reports: trial balance, general ledger, P&L, balance sheet, AR/AP ageing. CSV export + print. */
(function (root) {
  "use strict";
  var UI = root.AN_UI, h = UI.h, t = UI.t, F = UI.fmt, J = root.AN_J, AN = root.AN;
  var IDS = ["tb", "gl", "pl", "bs", "ar", "ap", "vat"];

  function plain(v, cur) { var co = UI.co(), d = (co.currencies[cur || co.baseCurrency] || { decimals: 2 }).decimals; return AN.formatMinor(v, d, "en-US").replace(/,/g, "").replace("‎", ""); }
  function isoDate(iso) { return iso || ""; }
  function aname(a) { return UI.accName(a); }

  UI.views.reports = function (box) {
    var co = UI.co(), plan = UI.store.planOf(co), st = UI.sub.rep = UI.sub.rep || { id: "tb" };
    var tabs = h("div", { class: "subtabs", role: "tablist" }, IDS.map(function (id) {
      var locked = plan.reports.indexOf(id) < 0;
      return h("button", { class: "subtab" + (st.id === id ? " on" : ""), type: "button", role: "tab", "aria-selected": st.id === id ? "true" : "false", onclick: function () { st.id = id; UI.render(); } }, t("rep_" + id), locked ? UI.icon("lock") : null);
    }));
    var area = h("div");
    box.appendChild(h("section", { class: "card" }, h("h2", { text: t("tabReports") }), tabs, area));
    if (plan.reports.indexOf(st.id) < 0) {
      area.appendChild(h("div", { class: "locked" }, UI.icon("lock"), h("p", { text: t("reportLocked", { plan: t("plan_pro") }) }), UI.can("plan.manage") ? h("button", { class: "btn", type: "button", onclick: function () { UI.go("settings", "plan"); } }, t("seePlans")) : null));
      return;
    }
    var today = UI.store.today(), fy = UI.store.currentFiscalYear(co), ps = Object.keys(co.periods).map(function (k) { return co.periods[k]; }).filter(function (p) { return p.year === fy; }).sort(function (a, b) { return a.month - b.month; });
    var defFrom = ps.length ? ps[0].start : today.slice(0, 4) + "-01-01", defTo = ps.length ? ps[ps.length - 1].end : today.slice(0, 4) + "-12-31";
    var from = UI.dateInput(st.from || defFrom), to = UI.dateInput(st.to || defTo), asOf = UI.dateInput(st.asOf || today);
    var accSel = UI.accountSelect(co, null, st.acc || co.sys.BANK); accSel.firstChild && accSel.removeChild(accSel.firstChild);
    var out = h("div", { class: "report-out print-area" }), cur = null;
    var controls = h("div", { class: "toolbar wrap" });
    if (st.id === "gl") controls.appendChild(UI.field(t("account"), accSel));
    if (st.id === "gl" || st.id === "pl" || st.id === "vat") { controls.appendChild(UI.field(t("from"), from.el)); controls.appendChild(UI.field(t("to"), to.el)); } else controls.appendChild(UI.field(t("asOf"), asOf.el));
    var run = h("button", { class: "btn", type: "button", onclick: show }, t("showReport"));
    var csvBtn = h("button", { class: "btn sec", type: "button", onclick: function () { if (cur) UI.download(UI.fileName(st.id, "csv"), AN.toCsv(cur.csv, true), "text/csv;charset=utf-8"); } }, UI.icon("download"), "CSV");
    var printBtn = h("button", { class: "btn sec", type: "button", onclick: function () { UI.printNode(); } }, UI.icon("print"), t("printPdf"));
    controls.appendChild(h("div", { class: "field" }, h("label", { html: "&nbsp;" }), h("div", { class: "actions" }, run, csvBtn, printBtn)));
    area.appendChild(controls); area.appendChild(out);

    function show() {
      st.from = from.get() || st.from; st.to = to.get() || st.to; st.asOf = asOf.get() || st.asOf; st.acc = accSel.value;
      var d1 = from.get(), d2 = to.get(), d3 = asOf.get();
      try {
        if ((st.id === "gl" || st.id === "pl" || st.id === "vat") && (!d1 || !d2)) throw { code: "BAD_DATE" };
        if (st.id !== "gl" && st.id !== "pl" && st.id !== "vat" && !d3) throw { code: "BAD_DATE" };
        if (d1 && d2 && d1 > d2) throw { code: "BAD_RANGE" };
        cur = BUILD[st.id]({ from: d1, to: d2, asOf: d3, acc: accSel.value });
        UI.clear(out); out.appendChild(h("div", { class: "print-head" }, h("h3", { text: co.name }), h("div", { class: "muted", text: cur.title }), h("div", { class: "muted small", text: t("baseCurrencyIs", { c: F.cur(co.baseCurrency) }) }))); out.appendChild(cur.node);
      } catch (e) { UI.clear(out); out.appendChild(h("div", { class: "form-error", text: UI.errMsg(e) })); cur = null; }
    }
    show();
  };

  function sectionRows(rows, label) { return [h("tr", { class: "sec" }, h("td", { colspan: 2, text: label }))].concat(rows); }
  function twoCol(rows) { return h("div", { class: "tw" }, h("table", { class: "tbl rep" }, h("tbody", {}, rows))); }
  function line(label, v, cls) { return h("tr", { class: cls || "" }, h("td", { text: label }), h("td", { class: "end" }, UI.base(v))); }

  var BUILD = {
    vat: function (p) {
      var r = UI.store.vatSummary(UI.ctx, p.from, p.to), csv = [[t("accountName"), t("amount")]], rows = [];
      [["vatSales", r.taxableSales], ["vatPurchases", r.taxablePurchases]].forEach(function (x) { rows.push(line(t(x[0]), x[1])); csv.push([t(x[0]), plain(x[1])]); });
      rows.push(line(t("vatOutput"), r.outputTax, "sub")); csv.push([t("vatOutput"), plain(r.outputTax)]);
      rows.push(line(t("vatInput"), r.inputTax, "sub")); csv.push([t("vatInput"), plain(r.inputTax)]);
      rows.push(line(r.netDue >= 0 ? t("vatDue") : t("vatRefund"), Math.abs(r.netDue), "grand")); csv.push([r.netDue >= 0 ? t("vatDue") : t("vatRefund"), plain(Math.abs(r.netDue))]);
      return { title: t("rep_vat") + " — " + F.date(p.from) + " → " + F.date(p.to), node: h("div", {}, twoCol(rows), h("p", { class: "muted small", text: t("vatNote") })), csv: csv };
    },
    tb: function (p) {
      var co = UI.co(), r = UI.store.trialBalance(UI.ctx, p.asOf), csv = [[t("code"), t("accountName"), t("debit"), t("credit")]];
      var rows = r.rows.map(function (x) { csv.push([x.account.code, aname(x.account), plain(x.debit), plain(x.credit)]); return [UI.codeNum(x.account.code), aname(x.account), x.debit ? UI.base(x.debit) : "", x.credit ? UI.base(x.credit) : ""]; });
      csv.push(["", t("total"), plain(r.totalDebit), plain(r.totalCredit)]);
      var foot = h("tfoot", {}, h("tr", { class: "grand" }, h("td", {}), h("td", { text: t("total") }), h("td", { class: "end" }, UI.base(r.totalDebit)), h("td", { class: "end" }, UI.base(r.totalCredit))));
      var node = h("div", {}, UI.table([{ label: t("code") }, { label: t("accountName") }, { label: t("debit"), cls: "end" }, { label: t("credit"), cls: "end" }], rows, { foot: foot }), h("p", {}, UI.badge(r.balanced ? t("balancedOk") : t("notBalanced"), r.balanced ? "ok" : "bad")));
      if (!rows.length) node = UI.empty(t("noData"));
      return { title: t("rep_tb") + " — " + t("asOf") + " " + F.date(p.asOf), node: node, csv: csv };
    },
    gl: function (p) {
      var co = UI.co(), r = UI.store.generalLedger(UI.ctx, p.acc, p.from, p.to), csv = [[t("date"), t("number"), t("memo"), t("debit"), t("credit"), t("balance")], [isoDate(p.from), "", t("openingBalance"), "", "", plain(r.opening)]];
      var rows = [[F.date(p.from), "", h("b", { text: t("openingBalance") }), "", "", UI.base(r.opening)]].concat(r.rows.map(function (x) { csv.push([x.date, x.entryId, x.memo, plain(x.debit), plain(x.credit), plain(x.balance)]); return [F.date(x.date), h("button", { class: "link", type: "button", onclick: function () { UI.entryView(x.entryId); } }, x.entryId), x.memo, x.debit ? UI.base(x.debit) : "", x.credit ? UI.base(x.credit) : "", UI.base(x.balance)]; }));
      csv.push(["", "", t("closingBalance"), plain(r.totalDebit), plain(r.totalCredit), plain(r.closing)]);
      var foot = h("tfoot", {}, h("tr", { class: "grand" }, h("td", {}), h("td", {}), h("td", { text: t("closingBalance") }), h("td", { class: "end" }, UI.base(r.totalDebit)), h("td", { class: "end" }, UI.base(r.totalCredit)), h("td", { class: "end" }, UI.base(r.closing))));
      return { title: t("rep_gl") + " — " + UI.accountLabel(r.account) + " — " + F.date(p.from) + " → " + F.date(p.to), node: UI.table([{ label: t("date") }, { label: t("number") }, { label: t("memo") }, { label: t("debit"), cls: "end" }, { label: t("credit"), cls: "end" }, { label: t("balance"), cls: "end" }], rows, { foot: foot }), csv: csv };
    },
    pl: function (p) {
      var r = UI.store.profitLoss(UI.ctx, p.from, p.to), csv = [[t("accountName"), t("amount")]], rows = [];
      rows = rows.concat(sectionRows(r.revenue.map(function (x) { csv.push([aname(x.account), plain(x.amount)]); return line(UI.codeNum(x.account.code) + " · " + aname(x.account), x.amount); }), t("type_revenue")));
      rows.push(line(t("totalRevenue"), r.totalRevenue, "sub")); csv.push([t("totalRevenue"), plain(r.totalRevenue)]);
      rows = rows.concat(sectionRows(r.expenses.map(function (x) { csv.push([aname(x.account), plain(x.amount)]); return line(UI.codeNum(x.account.code) + " · " + aname(x.account), x.amount); }), t("type_expense")));
      rows.push(line(t("totalExpenses"), r.totalExpenses, "sub")); csv.push([t("totalExpenses"), plain(r.totalExpenses)]);
      rows.push(line(r.netIncome >= 0 ? t("netProfit") : t("netLoss"), r.netIncome, "grand")); csv.push([t("netIncome"), plain(r.netIncome)]);
      return { title: t("rep_pl") + " — " + F.date(p.from) + " → " + F.date(p.to), node: twoCol(rows), csv: csv };
    },
    bs: function (p) {
      var r = UI.store.balanceSheet(UI.ctx, p.asOf), csv = [[t("accountName"), t("amount")]], rows = [];
      function sec(list, label, total, totalLabel) {
        rows = rows.concat(sectionRows(list.map(function (x) { csv.push([aname(x.account), plain(x.amount)]); return line(UI.codeNum(x.account.code) + " · " + aname(x.account), x.amount); }), label));
        if (total != null) { rows.push(line(totalLabel, total, "sub")); csv.push([totalLabel, plain(total)]); }
      }
      sec(r.assets, t("type_asset"), r.totalAssets, t("totalAssets")); sec(r.liabilities, t("type_liability"), r.totalLiabilities, t("totalLiabilities"));
      sec(r.equity, t("type_equity"), null); rows.push(line(t("currentEarnings"), r.currentEarnings)); csv.push([t("currentEarnings"), plain(r.currentEarnings)]);
      rows.push(line(t("totalEquity"), r.totalEquity, "sub")); csv.push([t("totalEquity"), plain(r.totalEquity)]);
      rows.push(line(t("liabPlusEquity"), r.totalLiabilities + r.totalEquity, "grand")); csv.push([t("liabPlusEquity"), plain(r.totalLiabilities + r.totalEquity)]);
      return { title: t("rep_bs") + " — " + t("asOf") + " " + F.date(p.asOf), node: h("div", {}, twoCol(rows), h("p", {}, UI.badge(r.balanced ? t("balancedOk") : t("notBalanced"), r.balanced ? "ok" : "bad"))), csv: csv };
    },
    ar: function (p) { return aging("sale", p); },
    ap: function (p) { return aging("purchase", p); }
  };
  function aging(kind, p) {
    var co = UI.co(), r = UI.store.aging(UI.ctx, kind, p.asOf), csv = [[t("number"), t("contact"), t("due"), t("daysOverdue"), t("remaining"), "Currency", t("remainingBase"), t("bucket")]];
    var rows = r.rows.map(function (x) { var c = co.contacts[x.contactId]; csv.push([x.invoice.number, c ? c.name : "", x.invoice.dueDate, x.daysOverdue, plain(x.remaining, x.invoice.currency), x.invoice.currency, plain(x.remainingBase), x.bucket]); return [x.invoice.number, c ? c.name : "—", F.date(x.invoice.dueDate), F.int(x.daysOverdue), UI.amount(x.remaining, x.invoice.currency), UI.base(x.remainingBase), t("b_" + x.bucket)]; });
    var b = r.buckets, sum = h("div", { class: "kpis small" }, ["current", "d30", "d60", "d90", "d90p"].map(function (k) { return h("div", { class: "kpi static" }, h("span", { class: "kpi-l", text: t("b_" + k) }), h("span", { class: "kpi-v" }, UI.base(b[k]))); }));
    csv.push(["", t("total"), "", "", "", "", plain(r.total), ""]);
    var foot = h("tfoot", {}, h("tr", { class: "grand" }, h("td", { colspan: 5, text: t("total") }), h("td", { class: "end" }, UI.base(r.total)), h("td")));
    var node = rows.length ? h("div", {}, sum, UI.table([{ label: t("number") }, { label: t("contact") }, { label: t("due") }, { label: t("daysOverdue"), cls: "end" }, { label: t("remaining"), cls: "end" }, { label: t("remainingBase"), cls: "end" }, { label: t("bucket") }], rows, { foot: foot })) : UI.empty(t("noData"));
    return { title: (kind === "sale" ? t("rep_ar") : t("rep_ap")) + " — " + t("asOf") + " " + F.date(p.asOf), node: node, csv: csv };
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
