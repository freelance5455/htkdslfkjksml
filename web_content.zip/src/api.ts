import { Quiz, Question } from './types';

export interface GenerateAIParams {
  topic?: string;
  text?: string;
  image?: {
    mimeType: string;
    data: string; // base64
  };
  count?: number;
  subjectName?: string;
  difficulty?: string;
}

export async function checkServerStatus(): Promise<{ status: string; geminiConfigured: boolean; message: string }> {
  try {
    const res = await fetch('/api/status');
    if (!res.ok) throw new Error('Status endpoint failed');
    return await res.json();
  } catch (err) {
    console.error('API Status check failed:', err);
    return { status: 'offline', geminiConfigured: false, message: 'Server connection failed' };
  }
}

export async function fetchQuizzes(): Promise<Quiz[]> {
  try {
    const res = await fetch('/api/quizzes');
    if (!res.ok) throw new Error('Failed to fetch quizzes');
    const data = await res.json();
    return data.quizzes || [];
  } catch (err) {
    console.warn('Backend fetch failed, checking localStorage fallback:', err);
    const local = localStorage.getItem('proquiz_app_data');
    if (local) {
      try {
        const parsed = JSON.parse(local);
        return parsed.quizzes || [];
      } catch (e) {}
    }
    return [];
  }
}

export async function saveQuizToApi(quiz: Quiz): Promise<Quiz> {
  // Sync to localStorage
  try {
    const local = localStorage.getItem('proquiz_app_data');
    let localData: { quizzes: Quiz[] } = { quizzes: [] };
    if (local) {
      try {
        localData = JSON.parse(local);
      } catch (e) {}
    }
    const idx = localData.quizzes.findIndex((q) => q.id === quiz.id);
    if (idx >= 0) {
      localData.quizzes[idx] = quiz;
    } else {
      localData.quizzes.unshift(quiz);
    }
    localStorage.setItem('proquiz_app_data', JSON.stringify(localData));
  } catch (e) {
    console.warn('Local storage sync warning:', e);
  }

  // Save to backend
  const res = await fetch('/api/quizzes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(quiz),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || 'क्विज़ सेव नहीं हो सकी');
  }

  const data = await res.json();
  return data.quiz;
}

export async function deleteQuizFromApi(id: string): Promise<boolean> {
  try {
    // delete locally
    const local = localStorage.getItem('proquiz_app_data');
    if (local) {
      try {
        const localData = JSON.parse(local);
        localData.quizzes = (localData.quizzes || []).filter((q: Quiz) => q.id !== id);
        localStorage.setItem('proquiz_app_data', JSON.stringify(localData));
      } catch (e) {}
    }

    const res = await fetch(`/api/quizzes/${id}`, { method: 'DELETE' });
    return res.ok;
  } catch (e) {
    console.error('Delete error:', e);
    return false;
  }
}

export async function generateQuestionsAI(params: GenerateAIParams): Promise<Question[]> {
  const res = await fetch('/api/gemini/generate-questions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'AI प्रश्न निर्माण विफल रहा।');
  }

  return data.questions || [];
}
