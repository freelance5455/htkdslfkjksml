/* ==========================================================================
   planner.js — برنامه روزانه/هفتگی، تقویم، ضد ازدحام، بازآرایی تطبیقی، گزارش‌ها
   ========================================================================== */

import { todayKey, dateKey, startOfWeek, addDays, uid, round, clamp, daysBetween, faDate, weekdayIndex, jalaliMonthGrid, toJalali, J_MONTHS, currentMonthKey, addMonthsKey, monthKeyOf, toFaDigits, sum, fmtCompact } from '../utils.js';
import { financeMetrics, monthActuals, doNothingVsPlan } from './financial-engine.js';
import { computeScore, taskCompletionRate } from './scoring-engine.js';
import { currentMonthPlan, todayBigMove, recalibrate } from './roadmap-engine.js';

const TASK_CAT_META = {
  'مهم‌ترین اقدام': { icon: '🔥', color: 'gold' },
  'یادگیری': { icon: '📚', color: 'blue' },
  'اقدام مالی': { icon: '💰', color: 'green' },
  'اقدام درآمدی': { icon: '💼', color: 'gold' },
  'عادت': { icon: '🧠', color: 'blue' },
  'مرور و برنامه‌ریزی': { icon: '📊', color: '' },
  'بدهی': { icon: '📉', color: '' },
  'پس‌انداز': { icon: '🪣', color: 'green' },
  'فروش': { icon: '🤝', color: 'gold' },
  'مهارت': { icon: '🎯', color: 'blue' },
  'سایر': { icon: '•', color: '' },
};
export function taskCatMeta(cat) { return TASK_CAT_META[cat] || TASK_CAT_META['سایر']; }

/* ------------------------------------------------------------ روز/مأموریت */
export function ensureDay(state, key) {
  const k = key || todayKey();
  if (!state.plan.days) state.plan.days = {};
  if (!state.plan.days[k]) {
    const gen = generateTasks(state, k);
    state.plan.days[k] = {
      date: k, tasks: gen.tasks || [], dropped: gen.dropped || 0, cap: gen.cap || 5,
      bigMove: null, notes: '', createdAt: Date.now(),
    };
    const big = todayBigMove(state);
    state.plan.days[k].bigMove = big;
    const bm = state.plan.days[k].tasks.find((t) => t.cat === 'مهم‌ترین اقدام');
    if (bm) { bm.title = big.title; bm.impact = big.impact || 90; }
  }
  return state.plan.days[k];
}

/** تولید کارهای روز بر اساس مسیر، وضعیت مالی، عادت‌ها و ضدازدحام (حداکثر ۵ کار) */
export function generateTasks(state, key) {
  const m = financeMetrics(state);
  const monthPlan = currentMonthPlan(state);
  const pathId = state.plan.pathId;
  const freeHours = +state.profile.freeHours || 1;
  const out = [];

  out.push({ id: uid('t'), title: todayBigMove(state).title, cat: 'مهم‌ترین اقدام', minutes: 45, impact: 92, done: false, priority: 1 });

  const learn = (state.skills || [])[0];
  out.push({
    id: uid('t'),
    title: learn ? ('۶۰ دقیقه تمرین هدفمند مهارت «' + learn.title + '» (سطح ' + (learn.level || 1) + ')') : '۶۰ دقیقه یادگیری یک مهارت درآمدزا',
    cat: 'یادگیری', minutes: 60, impact: 80, done: false, priority: 2,
  });

  if (m.negativeFlow) {
    out.push({ id: uid('t'), title: 'ثبت همه هزینه‌های امروز و پیدا کردن یک هزینه قابل حذف', cat: 'اقدام مالی', minutes: 15, impact: 85, done: false, priority: 3 });
  } else if (m.savingsRate < 0.15) {
    out.push({ id: uid('t'), title: 'انتقال درصد پس‌انداز تعیین‌شده به حساب جدا (حتی مبلغ کوچک)', cat: 'پس‌انداز', minutes: 10, impact: 82, done: false, priority: 3 });
  } else {
    out.push({ id: uid('t'), title: 'ثبت هزینه‌های امروز (۳۰ ثانیه) و بررسی انحراف از بودجه', cat: 'اقدام مالی', minutes: 8, impact: 60, done: false, priority: 4 });
  }

  if (m.debtToIncome > 0.25) {
    out.push({ id: uid('t'), title: 'پرداخت/برنامه‌ریزی پرداخت بدهی با اولویت بالاترین نرخ بهره', cat: 'بدهی', minutes: 20, impact: 84, done: false, priority: 3 });
  } else {
    out.push({
      id: uid('t'),
      title: pathId === 'freelancing' || pathId === 'service_business' || pathId === 'trade_business'
        ? '۳ اقدام فروش: تماس یا پیام به مشتری بالقوه'
        : 'یک اقدام درآمدزا: پیشنهاد خدمت/محصول یا مذاکره افزایش درآمد',
      cat: 'اقدام درآمدی', minutes: 45, impact: 88, done: false, priority: 3,
    });
  }

  const habit = habitTop(state);
  out.push({
    id: uid('t'),
    title: habit ? ('عادت: ' + habit.title) : '۱۰ دقیقه مرور هدف و مأموریت شخصی',
    cat: habit ? 'عادت' : 'مرور و برنامه‌ریزی', minutes: habit ? (habit.minutes || 15) : 10, impact: 55, done: false, priority: 5,
  });

  if (monthPlan && monthPlan.tasks && monthPlan.tasks.length) {
    const mi = (new Date().getDate() % monthPlan.tasks.length);
    out.push({ id: uid('t'), title: 'هدف این ماه: ' + monthPlan.tasks[mi], cat: 'مرور و برنامه‌ریزی', minutes: 25, impact: 70, done: false, priority: 6 });
  }

  // ضد ازدحام: کاهش بر اساس زمان آزاد و عملکرد
  const tc = taskCompletionRate(state, 7);
  let cap = freeHours >= 3 ? 6 : freeHours >= 2 ? 5 : freeHours >= 1 ? 4 : 3;
  if (tc < 0.4) cap = Math.max(2, cap - 2);
  if (tc > 0.9) cap = Math.min(7, cap + 1);
  const dropped = out.length - cap;
  const tasks = out.sort((a, b) => a.priority - b.priority).slice(0, cap);
  tasks.forEach((t, i) => { t.priority = i + 1; });
  return { tasks, dropped: Math.max(0, dropped), cap };
}

export function habitTop(state) {
  const habits = (state.habits || []).slice();
  if (!habits.length) return null;
  return habits.map((h) => ({ ...h, imp: habitImpact(state, h) })).sort((a, b) => b.imp - a.imp)[0];
}

/* ------------------------------------------------------- تقویم و زمان‌بندی */
export function calendarFor(state, jy, jm, selectedKey) {
  const cells = jalaliMonthGrid(jy, jm, selectedKey);
  return cells.map((c) => {
    if (c.empty) return c;
    const day = (state.plan.days || {})[c.key];
    const tasks = day ? day.tasks : [];
    const done = tasks.filter((t) => t.done).length;
    const dot = tasks.length === 0 ? null : done === tasks.length ? '' : done > 0 ? 'gold' : 'red';
    const isRest = (state.plan.restDays || []).indexOf(weekdayIndex(c.key)) > -1;
    return { ...c, count: tasks.length, done, dot, rest: isRest, plan: day ? day.plan || [] : [] };
  });
}

/** جدول زمان‌بندی روز با ساعت شروع واقعی */
export function timeBlocks(state, key) {
  const day = (state.plan.days || {})[key];
  if (!day || !day.tasks.length) return [];
  const freeHours = Math.max(1, +state.profile.freeHours || 1);
  const startHour = +state.profile.dayStartHour || 8;
  const rest = (state.plan.restDays || []);
  const isRest = rest.indexOf(weekdayIndex(key)) > -1;
  let cursor = startHour + (isRest ? 4 : 0);
  const totalMinutes = day.tasks.reduce((a, b) => a + (+b.minutes || 30), 0);
  const scale = clamp((freeHours * 60) / Math.max(30, totalMinutes), 0.4, 2.2);
  return day.tasks.map((t) => {
    const minutes = Math.max(10, Math.round((+t.minutes || 30) * scale));
    const block = { time: pad2(cursor) + ':' + '00', title: t.title, cat: t.cat, minutes, done: t.done, id: t.id };
    cursor += Math.max(1, Math.round(minutes / 60));
    return block;
  });
}
function pad2(n) { return String(n).padStart(2, '0'); }

/* ------------------------------------------------------------- هفته / ماه */
export function weekTasks(state, weekStartKey) {
  const ws = weekStartKey || startOfWeek(todayKey());
  const days = [];
  for (let i = 0; i < 7; i++) {
    const key = addDays(ws, i);
    const day = (state.plan.days || {})[key];
    days.push({ key, fa: faDate(key, { withWeekday: true, withYear: false }), tasks: day ? day.tasks : [], rest: (state.plan.restDays || []).indexOf(weekdayIndex(key)) > -1 });
  }
  return { weekStart: ws, days };
}

export function generateWeek(state) {
  const ws = startOfWeek(todayKey());
  const created = [];
  for (let i = 0; i < 7; i++) {
    const key = addDays(ws, i);
    if ((state.plan.restDays || []).indexOf(weekdayIndex(key)) > -1) continue;
    if (!(state.plan.days || {})[key]) { ensureDay(state, key); created.push(key); }
  }
  return { weekStart: ws, created };
}

export function weeklyReview(state) {
  const ws = startOfWeek(todayKey());
  let total = 0, done = 0, cats = {};
  for (let i = 0; i < 7; i++) {
    const key = addDays(ws, i);
    const day = (state.plan.days || {})[key];
    if (!day) continue;
    day.tasks.forEach((t) => { total++; cats[t.cat] = (cats[t.cat] || 0) + 1; if (t.done) done++; });
  }
  const m = financeMetrics(state);
  const tx = (state.finance.transactions || []).filter((t) => monthKeyOf(t.date) >= ws.slice(0, 7));
  const incomeCreated = sum(tx.filter((t) => t.type === 'income' && t.kind !== 'salary'), (t) => t.amount);
  const rate = total ? done / total : 0;
  const coach = [
    { q: 'این هفته چه کردی؟', a: done + ' از ' + total + ' کار برنامه‌ریزی‌شده انجام شد (' + Math.round(rate * 100) + '٪).' },
    { q: 'کجا شکست خوردی؟', a: rate < 0.5 ? 'بیشترین شکست در دسته «' + worstCat(cats) + '» بود؛ احتمالاً حجم کار بیش از زمان واقعی تو بود.' : 'شکست جدی وجود ندارد؛ فقط پیوستگی را حفظ کن.' },
    { q: 'چه چیزی یاد گرفتی؟', a: 'مهارت فعال: ' + ((state.skills || [])[0] ? (state.skills[0].title + ' — سطح ' + (state.skills[0].level || 1)) : 'هنوز مهارتی ثبت نشده') },
    { q: 'چقدر درآمد ایجاد کردی؟', a: incomeCreated > 0 ? fmtCompact(incomeCreated, state.profile) + ' درآمد خارج از درآمد اصلی ثبت شد.' : 'درآمد جدیدی ثبت نشده؛ هفته بعد یک اقدام فروش بیشتر لازم است.' },
    { q: 'هفته بعد چه چیزی باید تغییر کند؟', a: nextWeekChange(state, rate, m) },
  ];
  return { weekStart: ws, total, done, rate, incomeCreated, coach, cats };
}

function worstCat(cats) {
  const keys = Object.keys(cats);
  if (!keys.length) return 'اقدام درآمدی';
  return keys.sort((a, b) => cats[b] - cats[a])[0];
}
function nextWeekChange(state, rate, m) {
  if (m.negativeFlow) return 'قبل از هر چیز، یک هزینه ثابت را حذف کن؛ جریان نقدی منفی اولویت اول است.';
  if (rate < 0.4) return 'تعداد کارهای روزانه را به ۳ کاهش بده و فقط «مهم‌ترین اقدام» را محور بگیر.';
  if (rate > 0.85) return 'یک چالش بالاتر اضافه کن: مثلاً دو برابر شدن تعداد تماس‌های فروش در هفته.';
  if (m.incomeStreams < 2) return '۴ ساعت ثابت هفته را برای ساخت منبع درآمد دوم رزرو کن.';
  return 'روی تبدیل درآمد جانبی به سیستم تکرارپذیر تمرکز کن.';
}

export function monthlyReview(state, mk) {
  const key = mk || currentMonthKey();
  const act = monthActuals(state, key);
  const score = computeScore(state);
  const prevScore = (state.finance.snapshots || []).filter((s) => s.month < key).slice(-1)[0];
  const scoreDelta = prevScore ? score.total - prevScore.score : 0;
  const month = (state.plan.monthlyReviews || []).find((r) => r.month === key);
  const taskRate = taskCompletionRate(state, 30) * 100;
  const best = bestPerformance(act, state);
  const mistake = biggestMistake(act, state);
  const opportunity = nextMonthOpportunity(act, state);
  const actions = threeActions(act, state, score);
  return {
    month: key, act, score: score.total, scoreDelta, taskRate: Math.round(taskRate),
    best, mistake, opportunity, actions, answers: month ? month.answers : null,
  };
}

function bestPerformance(act, state) {
  if (act.delta.income > 0.05) return 'رشد درآمد ' + Math.round(act.delta.income * 100) + '٪ نسبت به ماه قبل.';
  if (act.delta.expense < -0.03) return 'کاهش ' + Math.abs(Math.round(act.delta.expense * 100)) + '٪ در هزینه‌ها.';
  if (act.savingsRate >= 0.2) return 'نرخ پس‌انداز سالم (' + Math.round(act.savingsRate * 100) + '٪).';
  return 'ثبت منظم داده‌های مالی — پایه هر بهبود.';
}
function biggestMistake(act, state) {
  if (act.current.expense > act.current.income && act.current.income > 0) return 'هزینه بیشتر از درآمد شد؛ جریان نقدی منفی.';
  if (act.delta.expense > 0.1) return 'هزینه‌ها ' + Math.round(act.delta.expense * 100) + '٪ رشد کرد؛ رشد هزینه بیش از رشد درآمد.';
  if (act.savingsRate < 0.1) return 'نرخ پس‌انداز پایین ماند؛ سیستم پس‌انداز خودکار نداری.';
  if (state.finance.transactions.length < 5) return 'ثبت نکردن هزینه‌ها؛ بدون داده، تحلیل ممکن نیست.';
  return 'عدم تبدیل پس‌انداز به دارایی درآمدزا.';
}
function nextMonthOpportunity(act, state) {
  const m = financeMetrics(state);
  if (m.negativeFlow) return 'کاهش هزینه ثابت: هر کاهش، هر ماه تکرار می‌شود.';
  if (m.incomeStreams < 2) return 'راه‌اندازی منبع درآمد دوم با مهارت فعلی.';
  if (m.debtToIncome > 0.3) return 'تسریع بازپرداخت بدهی با بهره بالا (بازده تضمینی).';
  if (m.savingsRate >= 0.2) return 'انتقال پس‌انداز به دارایی درآمدزا و شروع سرمایه‌گذاری منظم.';
  return 'افزایش نرخ پس‌انداز ۵ درصدی با حذف یک هزینه غیرضروری.';
}
function threeActions(act, state, score) {
  const m = act.planned;
  const out = [];
  if (act.current.income < m.income * 0.8) out.push('افزایش درآمد ماه به حداقل ' + Math.round(m.income * 0.8) + ' با یک اقدام فروش هفتگی.');
  if (act.current.expense > m.expense) out.push('کاهش هزینه به سقف بودجه ' + Math.round(m.expense) + ' با حذف دو قلم غیرضروری.');
  if (act.savingsRate < 0.15) out.push('تنظیم انتقال خودکار پس‌انداز ۱۵٪ در روز دریافت درآمد.');
  if ((state.finance.transactions || []).length < 8) out.push('ثبت روزانه هزینه‌ها برای یک ماه کامل.');
  if (score < 400) out.push('تمرکز روی یک مهارت درآمدزا برای ۹۰ روز.');
  if (out.length < 3) out.push('بازبینی ماهانه نقشه راه و به‌روزرسانی هدف.');
  return out.slice(0, 3);
}

/* --------------------------------------------------- بازآرایی تطبیقی برنامه */
export function adaptiveReschedule(state) {
  const tk = todayKey();
  const overdue = [];
  Object.keys(state.plan.days || {}).forEach((k) => {
    if (k >= tk) return;
    (state.plan.days[k].tasks || []).forEach((t) => { if (!t.done) overdue.push({ ...t, from: k }); });
  });
  if (!overdue.length) return { moved: 0, message: 'کار عقب‌افتاده‌ای نداری. اجرای تمیزی داشته‌ای.' };

  const cap = Math.max(2, (+state.profile.freeHours || 1) >= 2 ? 3 : 2);
  const sorted = overdue.sort((a, b) => (b.impact || 50) - (a.impact || 50));
  const moved = sorted.slice(0, cap);
  const dropped = sorted.length - moved.length;
  const today = ensureDay(state, tk);
  moved.forEach((t) => {
    if (today.tasks.some((x) => x.title === t.title)) return;
    today.tasks.push({ ...t, id: uid('t'), rescheduled: true });
  });
  today.tasks = today.tasks.sort((a, b) => (b.impact || 50) - (a.impact || 50)).slice(0, Math.max(cap + 1, 4));
  // کارهای عقب‌افتاده اضافی: به روزهای بعدی پخش می‌شوند
  let cursor = addDays(tk, 1);
  sorted.slice(cap).forEach((t, i) => {
    if (i % 2 === 1) cursor = addDays(cursor, 1);
    const d = ensureDay(state, cursor);
    if (d.tasks.length < 6) d.tasks.push({ ...t, id: uid('t'), rescheduled: true });
  });
  const message = 'امروز ' + moved.length + ' کار عقب‌افتاده در اولویت قرار گرفت' +
    (dropped > 0 ? ' و ' + dropped + ' کار کم‌اهمیت‌تر به روزهای بعد منتقل شد' : '') +
    '. برنامه هفته طوری تنظیم شد که بدون فشار غیرمنطقی عقب‌ماندگی جبران شود.';
  return { moved: moved.length, dropped, message };
}

/* ------------------------------------------------------- شبیه‌ساز «چه می‌شود» */
export function futureScenarios(state) {
  const cmp = doNothingVsPlan(state, [1, 3, 5, 10, 20]);
  return cmp;
}

export function monthLabel(mk) {
  const [gy, gm] = mk.split('-').map(Number);
  const j = toJalali(new Date(gy, gm - 1, 15));
  return J_MONTHS[j.jm - 1] + ' ' + toFaDigits(j.jy);
}

export function daysLeftInMonth() {
  const tk = todayKey();
  const j = toJalali(new Date());
  const len = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 30][j.jm - 1] || 30;
  return Math.max(0, len - j.jd);
}

export function ensureSnapshot(state) {
  const mk = currentMonthKey();
  state.finance.snapshots = state.finance.snapshots || [];
  const last = state.finance.snapshots[state.finance.snapshots.length - 1];
  const score = computeScore(state);
  const m = financeMetrics(state);
  if (!last || last.month !== mk) {
    state.finance.snapshots.push({
      id: uid('snap'), month: mk, at: todayKey(),
      netWorth: m.netWorth, assets: m.assetsTotal, debts: m.debtTotal,
      income: m.income, expenses: m.expense, savings: m.savings,
      investable: m.investable, score: score.total,
    });
    if (state.finance.snapshots.length > 36) state.finance.snapshots = state.finance.snapshots.slice(-36);
  } else {
    last.netWorth = m.netWorth; last.assets = m.assetsTotal; last.debts = m.debtTotal;
    last.income = m.income; last.expenses = m.expense; last.savings = m.savings;
    last.investable = m.investable; last.score = score.total; last.at = todayKey();
  }
  return state.finance.snapshots;
}

export function seriesFromSnapshots(state) {
  const snaps = (state.finance.snapshots || []).slice(-12);
  return snaps.map((s) => ({ label: monthLabel(s.month), netWorth: s.netWorth, assets: s.assets, debts: s.debts, score: s.score, income: s.income, expenses: s.expenses, savings: s.savings, investable: s.investable }));
}

export function nextGoalDeadlineDays(state) {
  const g = (state.goals || []).find((x) => !x.done && x.deadline);
  if (!g) return null;
  return { goal: g, days: daysBetween(todayKey(), g.deadline) };
}

export function streakGuard(state) {
  const tk = todayKey();
  if (state.streak.lastActiveDay === tk) return state.streak;
  const diff = state.streak.lastActiveDay ? daysBetween(state.streak.lastActiveDay, tk) : 999;
  if (diff === 1) state.streak.current = (state.streak.current || 0) + 1;
  else if (diff > 1) state.streak.current = 1;
  else state.streak.current = Math.max(1, state.streak.current || 1);
  state.streak.lastActiveDay = tk;
  state.streak.best = Math.max(state.streak.best || 0, state.streak.current);
  state.streak.history = (state.streak.history || []).filter((d) => d !== tk);
  state.streak.history.push(tk);
  if (state.streak.history.length > 400) state.streak.history = state.streak.history.slice(-400);
  return state.streak;
}

export function activeDaysCount(state) {
  return ((state.streak && state.streak.history) || []).length;
}

export function weekPercentDone(state) {
  const wt = weekTasks(state);
  let total = 0, done = 0;
  wt.days.forEach((d) => { d.tasks.forEach((t) => { total++; if (t.done) done++; }); });
  return total ? { percent: Math.round((done / total) * 100), total, done } : { percent: 0, total: 0, done: 0 };
}

export function round2(n) { return round(n, 2); }
export function clamp01(n) { return clamp(n, 0, 1); }
export function dateKeyExport() { return dateKey; }
