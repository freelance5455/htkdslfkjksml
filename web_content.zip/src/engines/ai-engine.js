/* ==========================================================================
   ai-engine.js — Offline Financial Intelligence Engine
   Rule Engine + Decision Tree + Scoring + Recommendation + Personalization
   هیچ درخواست شبکه‌ای در این فایل وجود ندارد.
   ========================================================================== */

import { financeMetrics, freedomCalc, projectWealth, debtPlan } from './financial-engine.js';
import { computeScore, skillScore, taskCompletionRate, goalProbability, topLimiters } from './scoring-engine.js';
import { discoverPaths, chooseBest, reversePlan, goalRealism, PATHS } from './roadmap-engine.js';
import { habitImpact, suggestHabits, weeklyCompletion } from './habit-engine.js';
import { CONCEPTS, WISDOM, PRINCIPLE_PACKS, DECISION_PRESETS } from '../knowledge/concepts.js';
import { BOOKS } from '../knowledge/books.js';
import { fmtCompact, pct, round, clamp, todayKey, pickStable, daysBetween, esc } from '../utils.js';

/* ------------------------------------------------------------ ۱) Context */
export function buildContext(state) {
  const m = financeMetrics(state);
  const score = computeScore(state);
  const goal = (state.goals || []).find((g) => !g.done) || (state.goals || [])[0] || null;
  return {
    state, metrics: m, score,
    age: +state.profile.age || 30,
    income: m.income, expenses: m.expense, assets: m.assetsTotal, debt: m.debtTotal, netWorth: m.netWorth,
    skills: state.profile.skills || [], skillScore: skillScore(state),
    experience: +state.profile.experienceYears || 0,
    time: +state.profile.freeHours || 1, riskTolerance: +state.profile.riskTolerance || 50,
    goal, deadlineMonths: goal && goal.deadline ? Math.max(1, Math.round(daysBetween(todayKey(), goal.deadline) / 30)) : 24,
    progress: (state.plan.roadmap && state.plan.roadmap.months) ? state.plan.roadmap.months.filter((x) => x.done).length : 0,
    habits: state.habits || [], taskCompletion: taskCompletionRate(state),
    streak: (state.streak && state.streak.current) || 0,
    previousDecisions: state.decisions || [],
    previousResults: (state.plan.monthlyReviews || []),
    path: state.plan.pathId || null,
    currencyLabel: state.profile.currency === 'OTHER' ? (state.profile.currencyLabel || 'واحد') : '',
  };
}

/* --------------------------------------------------- ۲) Rule Engine چندلایه */
const RULES = [
  { id: 'r_negative', layer: 1, when: (c) => c.metrics.negativeFlow, priority: 'expense_control', title: 'کنترل هزینه (اولویت مطلق)', why: 'هزینه ماهانه از درآمد بیشتر است؛ تا این اصلاح نشود هیچ مسیر دیگری پایدار نمی‌شود.', actions: ['سه هزینه بزرگ ماه را فهرست و کاهش بده', 'یک هزینه ثابت را حذف کن', 'قانون ۲۴ ساعت برای خرید غیرضروری'] },
  { id: 'r_zero_income', layer: 1, when: (c) => c.income <= 0, priority: 'income_creation', title: 'ساخت اولین جریان درآمد', why: 'بدون درآمد، برنامه‌ریزی مالی فقط محاسبه روی کاغذ است.', actions: ['یک خدمت مشخص با قیمت مشخص تعریف کن', '۲۰ مشتری احتمالی لیست کن', 'روزی ۵ تماس/پیام'] },
  { id: 'r_saving_system', layer: 2, when: (c) => !c.metrics.negativeFlow && c.metrics.savingsRate < 0.1, priority: 'saving_system', title: 'ساخت سیستم پس‌انداز', why: 'نرخ پس‌انداز زیر ۱۰٪ است؛ سرعت انباشت تقریباً صفر است.', actions: ['انتقال خودکار پس‌انداز در روز دریافت درآمد', 'حذف یک هزینه غیرضروری ماهانه', 'هدف موقت: ۱۰٪ سپس ۲۰٪'] },
  { id: 'r_debt', layer: 2, when: (c) => c.metrics.debtToIncome > 0.3, priority: 'debt_attack', title: 'حمله به بدهی پرهزینه', why: 'بیش از ۳۰٪ درآمد صرف قسط می‌شود؛ پرداخت بدهی، بازده تضمینی است.', actions: ['فهرست بدهی‌ها با نرخ بهره', 'انتخاب روش بهمن/گلوله برفی', 'یک درآمد جانبی برای پرداخت اضافه'] },
  { id: 'r_emergency', layer: 2, when: (c) => c.metrics.runwayMonths < 3, priority: 'emergency_fund', title: 'ساخت صندوق اضطراری', why: 'کمتر از ۳ ماه هزینه نقد داری؛ هر شوک، برنامه را می‌شکند.', actions: ['محاسبه هزینه یک ماه', 'انتقال به حساب جدا', 'پر کردن تا سه ماه'] },
  { id: 'r_skill', layer: 3, when: (c) => c.metrics.savingsRate >= 0.1 && c.skillScore < 55, priority: 'skill_development', title: 'ساخت مهارت نادر', why: 'پس‌انداز شکل گرفته اما مهارت درآمدزا کمیاب نیست؛ سقف درآمد پایین می‌ماند.', actions: ['انتخاب یک مهارت پرتقاضا', 'برنامه ۹۰ روزه یادگیری', 'ساخت سه نمونه‌کار'] },
  { id: 'r_income_accel', layer: 3, when: (c) => c.skillScore > 65 && c.goal && c.metrics.income < (c.goal.custom && c.goal.custom.monthlyIncomeTarget ? c.goal.custom.monthlyIncomeTarget : c.metrics.income * 1.4), priority: 'income_acceleration', title: 'شتاب‌دهنده درآمد', why: 'مهارت کافی داری اما درآمد پایین‌تر از پتانسیل است؛ مسئله قیمت‌گذاری و فروش است.', actions: ['قیمت/دستمزد را با داده بازار بازتعریف کن', 'یک خدمت جانبی بساز', 'درخواست جلسه با تصمیم‌گیر'] },
  { id: 'r_second_income', layer: 3, when: (c) => c.metrics.incomeStreams < 2 && c.time >= 1, priority: 'second_income', title: 'ساخت منبع درآمد دوم', why: 'درآمد تک‌منبعی، شکننده است و رشد مرکب را کند می‌کند.', actions: ['۴ ساعت هفته را رزرو کن', 'یک خدمت مشخص با قیمت مشخص', 'اولین مشتری را با قیمت آغازین ببند'] },
  { id: 'r_invest_start', layer: 4, when: (c) => c.metrics.savingsRate >= 0.15 && c.metrics.runwayMonths >= 3 && c.metrics.investable <= c.metrics.annualExpense, priority: 'invest_start', title: 'شروع سرمایه‌گذاری منظم', why: 'پس‌انداز و سپر نقدی کافی است؛ پول باید کار کند وگرنه تورم آن را می‌خورد.', actions: ['تخصیص دارایی را بنویس', 'مبلغ ماهانه ثابت تعیین کن', 'قانون بازبینی ماهانه'] },
  { id: 'r_business', layer: 4, when: (c) => c.metrics.incomeStreams >= 2 && c.skillScore >= 60 && c.time >= 2, priority: 'business_build', title: 'تبدیل خدمت به سیستم', why: 'دو منبع درآمد و مهارت کافی داری؛ مرحله بعد ساخت سیستم مقیاس‌پذیر است.', actions: ['مستندسازی فرایند', 'واگذاری بخش اجرا', 'قیمت‌گذاری سه سطحی'] },
  { id: 'r_freedom', layer: 5, when: (c) => c.metrics.investable > c.metrics.annualExpense * 0.8, priority: 'freedom_plan', title: 'برنامه استقلال مالی', why: 'سرمایه تو نزدیک به هزینه سالانه است؛ مسیر استقلال مالی واقع‌بینانه شده است.', actions: ['محاسبه سرمایه موردنیاز', 'بهینه‌سازی نرخ برداشت', 'مرور فصلی سبد'] },
  { id: 'r_execution', layer: 0, when: (c) => c.taskCompletion < 0.4, priority: 'execution_fix', title: 'اصلاح اجرا (نه دانش)', why: 'کمتر از ۴۰٪ کارهای برنامه‌ریزی‌شده انجام می‌شود؛ مشکل، کمبود اطلاعات نیست.', actions: ['کارهای روز را به ۳ مورد کاهش بده', 'فقط یک کار غالب در روز', 'زمان مشخص در تقویم'] },
  { id: 'r_time', layer: 1, when: (c) => c.time < 1, priority: 'time_recovery', title: 'بازیابی زمان', why: 'بدون زمان آزاد، هیچ مسیری اجرا نمی‌شود.', actions: ['یک فعالیت کم‌ارزش روزانه را حذف کن', 'بلوک ۶۰ دقیقه‌ای ثابت بساز', 'کارهای ۱۰ دلاری را حذف/واگذار کن'] },
  { id: 'r_network', layer: 4, when: (c) => c.metrics.savingsRate >= 0.1 && c.skillScore >= 55, priority: 'network', title: 'گسترش شبکه ارتباطی', why: 'فرصت‌های پردرآمد بیشتر از شبکه ارتباطی می‌آید تا از تبلیغ.', actions: ['هفته‌ای یک ارتباط تازه', 'انتشار یک محتوای آموزشی', 'درخواست معرفی از مشتری راضی'] },
];

export function priorities(state) {
  const c = buildContext(state);
  const hits = RULES.filter((r) => { try { return r.when(c); } catch (e) { return false; } });
  const ordered = hits.sort((a, b) => a.layer - b.layer);
  const result = ordered.map((r, i) => ({ ...r, rank: i + 1 }));
  if (!result.length) {
    result.push({ id: 'r_growth', layer: 5, rank: 1, priority: 'accelerate', title: 'شتاب دادن به مسیر فعلی', why: 'پایه‌های مالی تو سالم است؛ اکنون سرعت رشد درآمد و سرمایه‌گذاری را بالا ببر.', actions: ['افزایش ۲۰٪ قیمت/درآمد', 'افزایش نرخ پس‌انداز ۵٪', 'بازبینی سبد دارایی‌ها'] });
  }
  return { context: c, priorities: result.slice(0, 5), primary: result[0] };
}

/* --------------------------------------------- ۳) Recommendation Engine */
export function recommendations(state) {
  const c = buildContext(state);
  const m = c.metrics;
  const out = [];
  const push = (o) => out.push({
    ...o,
    score: Math.round(o.impact * 0.45 + (100 - o.difficulty) * 0.2 + (100 - o.risk) * 0.15 + o.probability * 0.2),
  });

  if (m.negativeFlow) push({ id: 'cut_fixed', title: 'حذف یک هزینه ثابت ماهانه', why: 'هر کاهش ثابت، هر ماه تکرار می‌شود.', impact: 92, difficulty: 45, cost: 0, risk: 5, time: '۱ روز', probability: 85, skillReq: 'کم', actions: ['فهرست هزینه‌های ثابت', 'حذف یا کاهش یکی', 'به‌روزرسانی پروفایل'] });
  if (m.savingsRate < 0.15) push({ id: 'auto_save', title: 'تنظیم پس‌انداز خودکار', why: 'سیستم جایگزین اراده می‌شود.', impact: 85, difficulty: 25, cost: 0, risk: 5, time: '۱ روز', probability: 90, skillReq: 'کم', actions: ['درصد را تعیین کن', 'انتقال خودکار بساز', 'ماه اول را ثبت کن'] });
  if (m.debtToIncome > 0.25) push({ id: 'debt_method', title: 'اجرای روش بهمن/گلوله برفی', why: 'بازده تضمینی معادل نرخ بهره بدهی.', impact: 88, difficulty: 50, cost: 0, risk: 10, time: '۱ هفته', probability: 75, skillReq: 'کم', actions: ['مرتب‌سازی بدهی‌ها', 'انتخاب روش', 'مبلغ اضافه تعیین کن'] });
  if (c.skillScore < 60) push({ id: 'skill_90', title: '۹۰ روز تمرین یک مهارت پردرآمد', why: 'مهارت نادر، بیشترین اهرم افزایش درآمد بدون سرمایه است.', impact: 95, difficulty: 65, cost: 0, risk: 15, time: '۹۰ روز', probability: 65, skillReq: 'متوسط', actions: ['انتخاب مهارت', 'برنامه ۹۰ روزه', 'سه نمونه‌کار'] });
  if (m.incomeStreams < 2) push({ id: 'side_service', title: 'راه‌اندازی یک خدمت مشخص', why: 'سریع‌ترین راه درآمد دوم با مهارت فعلی.', impact: 90, difficulty: 55, cost: 0, risk: 25, time: '۲ تا ۸ هفته', probability: 65, skillReq: 'متوسط', actions: ['تعریف خدمت و قیمت', '۲۰ مشتری احتمالی', '۵ تماس روزانه'] });
  if (m.runwayMonths < 3) push({ id: 'emergency_3m', title: 'پر کردن صندوق اضطراری تا ۳ ماه', why: 'سپر نقدی، شرط پذیرش هر ریسک است.', impact: 80, difficulty: 50, cost: 0, risk: 5, time: '۳ تا ۹ ماه', probability: 70, skillReq: 'کم', actions: ['محاسبه هزینه ماه', 'حساب جدا', 'پرداخت ماهانه'] });
  if (m.savingsRate >= 0.15 && m.runwayMonths >= 3) push({ id: 'invest_auto', title: 'سرمایه‌گذاری منظم با مبلغ ثابت', why: 'تبدیل پس‌انداز به دارایی درآمدزا.', impact: 88, difficulty: 40, cost: 0, risk: 40, time: 'بلندمدت', probability: 70, skillReq: 'متوسط', actions: ['تخصیص دارایی', 'مبلغ ثابت ماهانه', 'بازبینی ماهانه'] });
  if (c.skillScore >= 55) push({ id: 'price_up', title: 'افزایش ۱۰ تا ۲۵٪ قیمت/درآمد', why: 'شاید سریع‌ترین رشد درآمد بدون کار اضافه.', impact: 82, difficulty: 45, cost: 0, risk: 20, time: '۲ هفته', probability: 55, skillReq: 'متوسط', actions: ['تحقیق قیمت بازار', 'آماده کردن سه دلیل کمیتی', 'مذاکره'] });
  push({ id: 'weekly_review', title: 'بازبینی هفتگی ۲۰ دقیقه‌ای', why: 'بیشترین بازده در برنامه‌ریزی با کمترین هزینه.', impact: 70, difficulty: 15, cost: 0, risk: 0, time: '۲۰ دقیقه', probability: 92, skillReq: 'کم', actions: ['مرور کارهای هفته', 'اعداد هفته', 'تعیین کار غالب هفته بعد'] });

  return out.sort((a, b) => b.score - a.score);
}

export function oneBigMove(state) {
  const p = priorities(state);
  const pr = p.primary;
  const day = (state.plan.days || {})[todayKey()];
  if (day && day.bigMove) return { ...day.bigMove, reason: pr.why };
  const map = {
    expense_control: { title: 'سه هزینه بزرگ این ماه را پیدا کن و یکی را حذف کن', cat: 'اقدام مالی', minutes: 25, impact: 92 },
    income_creation: { title: 'یک خدمت مشخص با قیمت مشخص بنویس و به ۵ نفر پیام بده', cat: 'اقدام درآمدی', minutes: 45, impact: 95 },
    saving_system: { title: 'درصد پس‌انداز خودکار را تعیین و یک انتقال انجام بده', cat: 'پس‌انداز', minutes: 20, impact: 88 },
    debt_attack: { title: 'بدهی با بالاترین نرخ بهره را علامت بزن و مبلغ اضافه تعیین کن', cat: 'بدهی', minutes: 25, impact: 88 },
    emergency_fund: { title: 'مبلغ هزینه یک ماه را محاسبه و به حساب جدا منتقل کن', cat: 'اقدام مالی', minutes: 20, impact: 85 },
    skill_development: { title: '۶۰ دقیقه تمرین هدفمند روی مهارت انتخابی + ساخت یک نمونه‌کار', cat: 'مهارت', minutes: 60, impact: 92 },
    income_acceleration: { title: 'قیمت/درآمد را بازتعریف کن و جلسه مذاکره را زمان‌بندی کن', cat: 'اقدام درآمدی', minutes: 40, impact: 90 },
    second_income: { title: '۴ ساعت هفته را برای درآمد دوم رزرو و اولین پیشنهاد را بفرست', cat: 'درآمد دوم', minutes: 45, impact: 88 },
    invest_start: { title: 'تخصیص دارایی را بنویس و اولین مبلغ ثابت ماهانه را تعیین کن', cat: 'اقدام مالی', minutes: 30, impact: 82 },
    business_build: { title: 'فرایند اصلی کار را مستند کن تا قابل واگذاری شود', cat: 'کسب‌وکار', minutes: 45, impact: 80 },
    freedom_plan: { title: 'سرمایه موردنیاز استقلال مالی را محاسبه و برنامه برداشت را بنویس', cat: 'اقدام مالی', minutes: 30, impact: 78 },
    execution_fix: { title: 'کارهای امروز را به ۳ مورد کاهش بده و یک کار غالب انتخاب کن', cat: 'مرور و برنامه‌ریزی', minutes: 10, impact: 86 },
    time_recovery: { title: 'یک فعالیت کم‌ارزش روزانه را حذف و ۶۰ دقیقه آزاد کن', cat: 'مرور و برنامه‌ریزی', minutes: 15, impact: 84 },
    network: { title: 'با یک متخصص جدید ارتباط بگیر و یک محتوای آموزشی منتشر کن', cat: 'شبکه', minutes: 30, impact: 70 },
    accelerate: { title: 'نرخ پس‌انداز را ۵٪ و قیمت را ۱۰٪ بالا ببر', cat: 'اقدام مالی', minutes: 30, impact: 80 },
  }[pr.priority] || { title: 'یک اقدام کوچک مشخص برای مسیر فعلی انجام بده', cat: 'مرور و برنامه‌ریزی', minutes: 30, impact: 70 };
  return { ...map, reason: pr.why };
}

/* --------------------------------------------------- ۴) Risk Engine */
export function riskWarnings(state) {
  const c = buildContext(state);
  const m = c.metrics;
  const w = [];
  if (m.negativeFlow) w.push({ level: 'high', text: 'جریان نقدی منفی: هر سرمایه‌گذاری یا ریسک جدید فعلاً ممنوع است.' });
  if (m.runwayMonths < 1) w.push({ level: 'high', text: 'هیچ نقدینگی اضطراری نداری؛ هر حادثه کوچک برنامه را می‌شکند.' });
  if (m.debtToIncome > 0.4) w.push({ level: 'high', text: 'قسط‌ها بیش از ۴۰٪ درآمد است؛ ریسک نقدینگی بالا.' });
  if (m.assetsTotal > 0 && m.investable / Math.max(1, m.assetsTotal) > 0.85 && c.riskTolerance < 40) w.push({ level: 'medium', text: 'تمرکز بالای دارایی در یک نوع؛ تنوع را بررسی کن.' });
  if (c.time < 1) w.push({ level: 'medium', text: 'زمان آزاد ناکافی: برنامه باید به یک کار روزانه کاهش یابد.' });
  if ((state.finance.incomes || []).filter((i) => i.kind === 'investment').length === 0 && m.investable > m.annualExpense) w.push({ level: 'low', text: 'سرمایه راکد: بخشی از آن ارزش واقعی خود را با تورم از دست می‌دهد.' });
  w.push({ level: 'info', text: 'برنامه هیچ وعده قطعی نمی‌دهد؛ همه اعداد مدل‌سازی داخلی هستند و تصمیم نهایی با تو است.' });
  return w;
}

/* ------------------------------------------------------- ۵) Chat Engine */
const INTENTS = [
  { id: 'income', kw: ['درآمد', 'پول بیشتر', 'دو برابر', 'افزایش درآمد', 'دستمزد', 'حقوق', 'میخوام بیشتر'], pack: 'income' },
  { id: 'debt', kw: ['بدهی', 'وام', 'قسط', 'قرض', 'بدهی‌ام'], pack: 'debt' },
  { id: 'expense', kw: ['هزینه', 'خرج', 'بودجه', 'مصرف'], pack: 'saving' },
  { id: 'saving', kw: ['پس‌انداز', 'ذخیره', 'نرخ پس‌انداز'], pack: 'saving' },
  { id: 'skill', kw: ['مهارت', 'چی یاد', 'تخصص', 'بیشترین بازده', 'roi'], pack: 'skills' },
  { id: 'stuck', kw: ['پیشرفت نمی', 'چرا پیشرفت', 'گیر کردم', 'انگیزه ندارم', 'خسته', 'تنبل'], pack: 'habits' },
  { id: 'business', kw: ['کسب‌وکار', 'بیزنس', 'شرکت', 'کار خودم', 'مغازه', 'ایده'], pack: 'business' },
  { id: 'invest', kw: ['سرمایه‌گذاری', 'سهام', 'طلا', 'ملک', 'بورس', 'کجا بگذارم'], pack: 'investing' },
  { id: 'freedom', kw: ['استقلال مالی', 'بازنشستگی', 'چقدر سرمایه', 'بازنشسته'], pack: 'networth' },
  { id: 'networth', kw: ['خالص ثروت', 'دارایی', 'net worth'], pack: 'networth' },
  { id: 'month', kw: ['این ماه', 'چه کاری انجام', 'برنامه این ماه', 'امروز چی'], pack: 'time' },
  { id: 'habit', kw: ['عادت', 'استمرار', 'پیوسته'], pack: 'habits' },
  { id: 'sales', kw: ['فروش', 'مشتری', 'تماس', 'بازاریابی'], pack: 'sales' },
  { id: 'price', kw: ['قیمت', 'قیمت‌گذاری', 'چند بفروشم'], pack: 'business' },
  { id: 'negotiate', kw: ['مذاکره', 'حقوقم را', 'افزایش حقوق'], pack: 'negotiation' },
  { id: 'risk', kw: ['ریسک', 'خطرناک', 'امن'], pack: 'risk' },
  { id: 'psychology', kw: ['حس', 'احساس', 'وسوسه', 'خرید احساسی', 'فکر'], pack: 'psychology' },
  { id: 'career', kw: ['شغل', 'کارمند', 'کارفرما', 'ارتقا', 'رزومه'], pack: 'career' },
];

export function ask(state, question) {
  const c = buildContext(state);
  const m = c.metrics;
  const q = String(question || '').trim();
  const ql = q.toLowerCase();
  const money = (n) => fmtCompact(n, state.profile);

  // تشخیص عدد در سؤال («۱۰۰ میلیون پول دارم»)
  const numMatch = ql.match(/(\d+)\s*(میلیارد|میلیون|هزار)?/);
  const num = numMatch ? parseFloat(numMatch[1]) * (numMatch[2] === 'میلیارد' ? 1e9 : numMatch[2] === 'میلیون' ? 1e6 : numMatch[2] === 'هزار' ? 1e3 : 1) : null;

  let intent = null;
  let best = 0;
  INTENTS.forEach((it) => {
    const hits = it.kw.filter((k) => ql.indexOf(k.toLowerCase()) > -1).length;
    if (hits > best) { best = hits; intent = it; }
  });

  if (!intent) {
    // جست‌وجوی پایگاه دانش
    const found = CONCEPTS.filter((cn) => (cn.title + ' ' + cn.body + ' ' + cn.tags.join(' ')).toLowerCase().split(' ').some((w) => w.length > 3 && ql.indexOf(w.toLowerCase()) > -1)).slice(0, 3);
    if (found.length) {
      return {
        text: buildKnowledgeAnswer(state, q, found, c),
        actions: [{ label: 'افزودن کار امروز: مرور این مفاهیم', task: { title: 'مرور ' + found.length + ' مفهوم مالی و انتخاب یک اقدام', cat: 'یادگیری', minutes: 25 } }],
        sources: found.map((f) => f.title),
      };
    }
    return {
      text: buildDiagnosisAnswer(state, c, q),
      actions: [{ label: 'افزودن کار غالب امروز', task: oneBigMove(state) }],
      sources: [],
    };
  }

  const p = priorities(state);
  let text = '';
  let actions = [];

  switch (intent.id) {
    case 'income': {
      const gap = c.goal && c.goal.custom && c.goal.custom.monthlyIncomeTarget ? c.goal.custom.monthlyIncomeTarget - m.income : m.income * 0.5;
      const best2 = chooseBest(state);
      text = '<h5>وضعیت تو</h5><p>درآمد فعلی: <b>' + money(m.income) + '</b> — هزینه: ' + money(m.expense) + ' — نرخ پس‌انداز: ' + pct(m.savingsRate) + '</p>' +
        '<h5>تشخیص</h5><p>درآمد = تقاضا × کمیابی × اثبات. برای افزایش ' + money(gap) + ' در ماه، سه مسیر واقعی داری:</p><ol>' +
        '<li><b>قیمت/دستمزد:</b> اگر مهارت داری، ۱۰ تا ۲۵٪ افزایش با مذاکره — سریع‌ترین راه، ریسک کم.</li>' +
        '<li><b>خدمت جانبی:</b> ' + (m.incomeStreams < 2 ? 'الان تک‌منبعی هستی؛ یک خدمت مشخص با قیمت مشخص بساز.' : 'منبع دوم داری؛ آن را سیستم‌مند کن.') + '</li>' +
        '<li><b>تخصص نادر:</b> ترکیب دو مهارت (' + (c.skills.slice(0, 2).join(' + ') || 'مهارت فعلی + فروش') + ') که قیمتش بالاتر است.</li></ol>' +
        '<h5>بهترین مسیر برای تو</h5><p>' + esc(best2.text) + '</p>' +
        '<h5>عدد هدف</h5><p>برای رسیدن به درآمد ' + money(m.income + Math.max(0, gap)) + '، ماهانه ' + money(Math.max(0, gap) / 3) + ' رشد تدریجی در سه ماه کافی است. این یعنی ' + Math.ceil(Math.max(0, gap) / 3 / 30) + ' واحد فروش بیشتر یا یک مذاکره موفق.</p>' +
        '<p class="tiny">' + esc(BOOKS.slice(0, 1)[0].fa ? 'منبع داخلی: ' + (PRINCIPLE_PACKS.income[0]) : '') + '</p>';
      actions = [
        { label: 'افزودن: تعریف خدمت + ۵ پیام', task: { title: 'یک خدمت مشخص با قیمت بنویس و به ۵ مشتری احتمالی پیام بده', cat: 'اقدام درآمدی', minutes: 45 } },
        { label: 'افزودن: تمرین مذاکره', task: { title: 'سه دلیل کمیتی برای افزایش قیمت/حقوق آماده کن', cat: 'اقدام درآمدی', minutes: 30 } },
      ];
      break;
    }
    case 'debt': {
      const dp = debtPlan(state, Math.max(0, m.savings) * 0.3);
      text = '<h5>وضعیت بدهی</h5><p>مجموع بدهی: <b>' + money(m.debtTotal) + '</b> — قسط ماهانه: ' + money(m.monthlyDebtPayment) + ' — نسبت به درآمد: ' + pct(m.debtToIncome) + '</p>';
      if (dp.hasDebt) {
        text += '<h5>مقایسه دو روش</h5><table class="tbl"><tr><th>روش</th><th class="n">مدت</th><th class="n">سود کل</th></tr>' +
          '<tr><td>بهمن (بالاترین بهره)</td><td class="n">' + dp.avalanche.months + ' ماه</td><td class="n">' + money(dp.avalanche.totalInterest) + '</td></tr>' +
          '<tr><td>گلوله برفی (کوچک‌ترین)</td><td class="n">' + dp.snowball.months + ' ماه</td><td class="n">' + money(dp.snowball.totalInterest) + '</td></tr></table>' +
          '<h5>پیشنهاد برای تو</h5><p>' + esc(dp.why) + '</p>' +
          '<p>ترتیب پرداخت: ' + dp[dp.recommended].orderNames.map(esc).join(' ← ') + '</p>';
      } else {
        text += '<p>بدهی فعالی ثبت نشده. اگر بدهی داری، اول آن را در «ثروت من» وارد کن تا محاسبه دقیق انجام شود.</p>';
      }
      text += '<p class="tiny">نکته: پرداخت بدهی، بازدهی معادل نرخ بهره آن دارد و بدون ریسک است.</p>';
      actions = [{ label: 'افزودن: مرتب‌سازی بدهی‌ها', task: { title: 'فهرست بدهی‌ها را بر اساس نرخ بهره مرتب کن و مبلغ اضافه ماهانه تعیین کن', cat: 'بدهی', minutes: 25 } }];
      break;
    }
    case 'expense': case 'saving': {
      const top = m.expenseByCat.slice(0, 3);
      text = '<h5>تحلیل هزینه</h5><p>هزینه ماهانه: <b>' + money(m.expense) + '</b> — ضروری: ' + money(m.essential) + ' — اختیاری: ' + money(m.discretionary) + '</p>' +
        (top.length ? '<ol>' + top.map((t) => '<li>' + esc(t.category) + ': <b>' + money(t.amount) + '</b></li>').join('') + '</ol>' : '<p>هنوز هزینه‌ای ثبت نکرده‌ای؛ اول اعداد واقعی را وارد کن.</p>') +
        '<h5>سه اقدام مؤثر</h5><ol>' +
        '<li>پس‌انداز خودکار ' + (m.savingsRate < 0.15 ? 'از صفر شروع کن با ۵٪' : 'را ۵٪ بالا ببر') + ' در روز دریافت درآمد.</li>' +
        '<li>برای هر خرید غیرضروری ۲۴ ساعت تأخیر بگذار؛ بیشتر خریدهای احساسی حذف می‌شوند.</li>' +
        '<li>یک هزینه ثابت را حذف یا کاهش بده — اثر آن هر ماه تکرار می‌شود.</li></ol>' +
        '<h5>عدد واقع‌بینانه</h5><p>با کاهش ' + money(Math.max(m.discretionary * 0.3, m.expense * 0.05)) + ' در ماه، پس‌انداز سالانه ' + money(Math.max(m.discretionary * 0.3, m.expense * 0.05) * 12) + ' بیشتر می‌شود.</p>';
      actions = [{ label: 'افزودن: ثبت هزینه امروز', task: { title: 'همه هزینه‌های امروز را ثبت کن و یک قلم قابل حذف علامت بزن', cat: 'اقدام مالی', minutes: 10 } }];
      break;
    }
    case 'skill': {
      const roi = skillROI(state);
      text = '<h5>بازده مهارت‌ها (ROI)</h5><ol>' + roi.slice(0, 4).map((r, i) => '<li><b>' + esc(r.title) + '</b> — ROI تقریبی: ' + r.roi + '/100 — ' + esc(r.reason) + '</li>').join('') + '</ol>' +
        '<h5>چرا این‌ها</h5><p>سن: ' + c.age + '، تخصص: ' + (c.skills.join('، ') || 'ثبت نشده') + '، زمان آزاد: ' + c.time + ' ساعت، امتیاز مهارت: ' + c.skillScore + '/100.</p>' +
        '<p>قانون: یک مهارت را تا سطح «فروش‌پذیر» ببر، بعد مهارت دوم. تمرین هدفمند روی ضعف، سریع‌ترین رشد است.</p>';
      actions = [{ label: 'افزودن: ۶۰ دقیقه تمرین', task: { title: '۶۰ دقیقه تمرین هدفمند مهارت «' + roi[0].title + '»', cat: 'مهارت', minutes: 60 } }];
      break;
    }
    case 'stuck': {
      const tc = Math.round(c.taskCompletion * 100);
      text = '<h5>داده‌های واقعی</h5><p>نرخ انجام کارها: <b>' + tc + '٪</b> — زنجیره: ' + c.streak + ' روز — تعداد کار روزانه: ' + (((state.plan.days || {})[todayKey()] || { tasks: [] }).tasks.length) + '</p>' +
        '<h5>تشخیص صریح</h5><p>' + (tc < 50 ? 'مشکل تو کمبود اطلاعات نیست؛ تبدیل اطلاعات به اقدام است. برنامه‌ات بزرگ‌تر از زمان واقعی توست.' : 'اجرای خوبی داری؛ مشکل احتمالاً در «مسیر» است نه در «نظم». مسیر انتخابی با شرایط تو هم‌راستا نیست.') + '</p>' +
        '<h5>اصلاح فوری</h5><ol><li>امروز فقط یک کار غالب انجام بده.</li><li>کارها را به نسخه ۲ دقیقه‌ای تبدیل کن تا شروع کنی.</li><li>قانون «هرگز دو روز پشت سر هم» را اجرا کن.</li></ol>' +
        '<p>' + esc(pickStable(['آرزو برای ثروت، سیستم نمی‌سازد؛ سیستم روزانه می‌سازد.', 'پیشرفت، حاصل روزهای معمولی تکرارشده است.', 'یک قدم امروز، بهتر از برنامه ده‌ساله بدون اجرا است.'], q)) + '</p>';
      actions = [{ label: 'کاهش کارهای امروز', task: { title: 'کارهای امروز را به ۳ مورد کاهش بده و یک کار غالب انتخاب کن', cat: 'مرور و برنامه‌ریزی', minutes: 10 } }];
      break;
    }
    case 'business': {
      const ideas = businessIdeas(state);
      text = '<h5>سه ایده متناسب با شرایط تو</h5><ol>' + ideas.slice(0, 3).map((i2) => '<li><b>' + esc(i2.title) + '</b> — امتیاز تناسب ' + i2.score + '٪<br><span class="tiny">' + esc(i2.why) + '</span></li>').join('') + '</ol>' +
        '<h5>طرح اولین ایده</h5><ul>' +
        '<li><b>مشتری هدف:</b> ' + esc(ideas[0].persona) + '</li>' +
        '<li><b>بازار:</b> ' + esc(ideas[0].market) + '</li>' +
        '<li><b>مدل درآمدی:</b> ' + esc(ideas[0].model) + '</li>' +
        '<li><b>هزینه شروع تخمینی:</b> ' + money(ideas[0].cost) + '</li>' +
        '<li><b>MVP:</b> ' + esc(ideas[0].mvp) + '</li>' +
        '<li><b>ریسک‌ها:</b> ' + ideas[0].risks.map(esc).join('، ') + '</li></ul>' +
        '<h5>برنامه ۳۰ روزه</h5><ol>' + ideas[0].plan30.map((x, i) => '<li>هفته ' + (i + 1) + ': ' + esc(x) + '</li>').join('') + '</ol>' +
        '<h5>برنامه جذب اولین مشتری</h5><p>' + esc(ideas[0].firstCustomer) + '</p>' +
        '<p class="tiny">اینها فرضیه‌اند، نه تضمین. با کوچک‌ترین آزمون واقعی شروع کن.</p>';
      actions = [{ label: 'افزودن: مصاحبه با ۳ مشتری', task: { title: 'مصاحبه با ۳ مشتری بالقوه درباره مسئله «' + ideas[0].title + '»', cat: 'اقدام درآمدی', minutes: 60 } }];
      break;
    }
    case 'invest': {
      const fc = freedomCalc(state);
      text = '<h5>وضعیت سرمایه‌گذاری</h5><p>سرمایه قابل سرمایه‌گذاری: <b>' + money(m.investable) + '</b> — صندوق اضطراری: ' + m.runwayMonths + ' ماه هزینه</p>' +
        '<h5>چارچوب تصمیم (نه توصیه خرید/فروش)</h5><ol>' +
        '<li>اول صندوق اضطراری ۳ ماهه؛ تا آن زمان ریسک جدید نگیر.</li>' +
        '<li>تخصیص دارایی بنویس: نقد / درآمدزا / رشد — و سقف ریسک (حداکثر ۱۰٪ سرمایه در ریسک بالا).</li>' +
        '<li>برای هر دارایی: هزینه، نقدشوندگی، ریسک غیرقابل بازگشت و نقطه خروج را مشخص کن.</li>' +
        '<li>بازبینی ماهانه، نه روزانه؛ واکنش به نوسان کوتاه‌مدت، بازده را می‌خورد.</li></ol>' +
        '<h5>سه سناریو</h5><p>در شبیه‌ساز ثروت، سناریوهای محافظه‌کارانه/متعادل/تهاجمی را با فرض‌های خودت مقایسه کن. نتیجه، مدل‌سازی است نه پیش‌بینی.</p>' +
        '<p>سرمایه موردنیاز برای استقلال مالی فعلی: <b>' + money(fc.requiredCapital) + '</b> (نرخ برداشت ' + fc.swr + '٪).</p>';
      actions = [{ label: 'افزودن: نوشتن تخصیص دارایی', task: { title: 'تخصیص دارایی (نقد/درآمدزا/رشد) را بنویس و سقف ریسک تعیین کن', cat: 'اقدام مالی', minutes: 30 } }];
      break;
    }
    case 'freedom': case 'networth': {
      const fc = freedomCalc(state);
      text = '<h5>خالص ثروت</h5><p>دارایی ' + money(m.assetsTotal) + ' − بدهی ' + money(m.debtTotal) + ' = <b>' + money(m.netWorth) + '</b></p>' +
        '<h5>استقلال مالی</h5><ul>' +
        '<li>هزینه سالانه: ' + money(fc.annualExpense) + '</li>' +
        '<li>سرمایه موردنیاز (نرخ برداشت ' + fc.swr + '٪): <b>' + money(fc.requiredCapital) + '</b></li>' +
        '<li>درآمد غیرفعال فعلی (تخمینی): ' + money(fc.passiveIncome) + ' در ماه</li>' +
        '<li>فاصله تا هدف: ' + money(fc.gap) + '</li>' +
        '<li>زمان تخمینی با پس‌انداز فعلی: <b>' + fc.years + ' سال</b></li></ul>' +
        '<p>با افزایش نرخ پس‌انداز ۱۰٪ و کاهش هزینه ثابت، این زمان به‌طور محسوس کم می‌شود؛ در بخش استقلال مالی می‌توانی فرض‌ها را تغییر بدهی.</p>' +
        '<p class="tiny">' + esc('این اعداد مدل‌سازی داخلی‌اند، نه تضمین آینده.') + '</p>';
      actions = [{ label: 'افزودن: انتقال ماهانه', task: { title: 'مبلغ ثابت ماهانه سرمایه‌گذاری را تعیین و یک انتقال انجام بده', cat: 'اقدام مالی', minutes: 20 } }];
      break;
    }
    case 'month': {
      const rp = reversePlan(state, c.goal);
      text = '<h5>برنامه این ماه</h5><p>مسیر فعال: <b>' + esc((state.plan.pathId ? (PATHS.find((x) => x.id === state.plan.pathId) || {}).fa : 'انتخاب نشده')) + '</b></p>' +
        '<ol><li>هدف ماه: پس‌انداز ' + money(rp.weekly * 4.3) + ' (معادل ' + money(rp.neededMonthlySaving) + ' برای هدف بزرگ)</li>' +
        '<li>هدف مهارت: ' + esc(rp.skillNeeded) + '</li>' +
        '<li>هدف فروش: ' + (m.incomeStreams < 2 ? 'بستن اولین سفارش درآمد دوم' : 'افزایش ۲۰٪ حجم فروش') + '</li>' +
        '<li>هدف مالی: ثبت کامل هزینه‌ها و بازبینی ماهانه</li></ol>' +
        '<h5>چهار هفته</h5><ol>' + monthWeeks(state).map((w, i) => '<li><b>هفته ' + (i + 1) + ':</b> ' + esc(w) + '</li>').join('') + '</ol>';
      actions = [{ label: 'افزودن: کار غالب امروز', task: oneBigMove(state) }];
      break;
    }
    case 'habit': {
      const sug = suggestHabits(state).slice(0, 3);
      text = '<h5>عادت‌های با بیشترین اثر برای تو</h5><ol>' + sug.map((s) => '<li>' + s.icon + ' <b>' + esc(s.title) + '</b> — اثر مالی: ' + s.impact + '/100 (' + esc(s.cat) + ')</li>').join('') + '</ol>' +
        '<p>نرخ انجام عادت‌های هفته: <b>' + Math.round(weeklyCompletion(state) * 100) + '٪</b></p>' +
        '<h5>چطور شروع کنم</h5><ol><li>نسخه دو دقیقه‌ای تعریف کن.</li><li>به یک روتین موجود بچسبان.</li><li>قانون «هرگز دو روز پشت سر هم».</li></ol>';
      actions = [{ label: 'افزودن: عادت پیشنهادی', task: { title: 'عادت «' + sug[0].title + '» را امروز در نسخه ۲ دقیقه‌ای انجام بده', cat: 'عادت', minutes: 5 } }];
      break;
    }
    case 'sales': {
      text = '<h5>سیستم فروش ساده</h5><ol>' +
        '<li>لیست ۲۰ مشتری احتمالی بنویس (نام، مسئله، کانال).</li>' +
        '<li>۵ تماس/پیام در روز — قیف با تعداد پر می‌شود.</li>' +
        '<li>۵ سؤال کشف نیاز آماده کن؛ اول مسئله، بعد راه‌حل.</li>' +
        '<li>سه سطح قیمت آماده کن و اول قیمت را تو بگو.</li>' +
        '<li>برای هر پیشنهاد ۳ پیگیری زمان‌بندی‌شده بگذار.</li></ol>' +
        '<h5>عدد واقع‌بینانه</h5><p>با نرخ تبدیل ۵ تا ۱۰٪، از ۱۰۰ تماس ۵ تا ۱۰ مذاکره و ۱ تا ۳ فروش به دست می‌آید. پس تعداد تماس هفته‌ات را اول افزایش بده، بعد کیفیت را.</p>';
      actions = [{ label: 'افزودن: ۵ تماس امروز', task: { title: '۵ تماس/پیام با مشتری بالقوه انجام بده و نتیجه را ثبت کن', cat: 'فروش', minutes: 45 } }];
      break;
    }
    case 'price': {
      text = '<h5>قیمت‌گذاری بر اساس ارزش</h5><p>قیمت = ارزش مالی حل مسئله برای مشتری، نه هزینه تو + حاشیه.</p><ol>' +
        '<li>ارزش مالی حل مسئله را برای مشتری تخمین بزن (صرفه‌جویی/درآمد جدید).</li>' +
        '<li>سه سطح قیمت بساز: پایه / استاندارد / کامل.</li>' +
        '<li>یک تضمین هوشمند اضافه کن تا ریسک خرید کم شود.</li>' +
        '<li>قیمت را با رقبا مقایسه نکن؛ با ارزش مقایسه کن.</li></ol>' +
        '<p>اگر قیمت فعلی کمتر از ' + money(m.income * 0.05) + ' است، احتمالاً ارزش پیشنهادت کاملاً منتقل نشده.</p>';
      actions = [{ label: 'افزودن: ساخت سه سطح قیمت', task: { title: 'سه سطح قیمت برای خدمت/محصول خود تعریف کن', cat: 'اقدام درآمدی', minutes: 30 } }];
      break;
    }
    case 'negotiate': case 'career': {
      text = '<h5>مذاکره حقوق/قیمت</h5><ol>' +
        '<li>سه دستاورد کمیتی از کار خود بنویس (درآمد ایجادشده، هزینه کاهش‌یافته، زمان صرفه‌جویی‌شده).</li>' +
        '<li>محدوده پرداخت بازار را تحقیق کن.</li>' +
        '<li>دو گزینه جایگزین (BATNA) داشته باش.</li>' +
        '<li>اول عدد را تو بگو، بالاتر از هدف، با توجیه.</li>' +
        '<li>اگر جواب منفی بود، مسیر جایگزین بگیر: ارتقا، تغییر واحد، پروژه بیرونی.</li></ol>' +
        '<p>با افزایش ' + pct(0.2) + ' درآمد، ماهانه ' + money(m.income * 0.2) + ' بیشتر می‌شود — بدون کار اضافه.</p>';
      actions = [{ label: 'افزودن: آماده‌سازی مذاکره', task: { title: 'سه دستاورد کمیتی و محدوده حقوق بازار را آماده کن', cat: 'اقدام درآمدی', minutes: 40 } }];
      break;
    }
    case 'risk': {
      const w = riskWarnings(state);
      text = '<h5>هشدارهای ریسک فعلی</h5><ul>' + w.map((x) => '<li>' + esc(x.text) + '</li>').join('') + '</ul>' +
        '<h5>قوانین ریسک</h5><ol><li>ریسک غیرقابل بازگشت نپذیر.</li><li>بدترین حالت را قبل از اقدام بنویس.</li><li>حجم ریسک متناسب با صندوق اضطراری.</li><li>نقطه خروج را قبل از ورود تعیین کن.</li></ol>';
      actions = [{ label: 'افزودن: تحلیل بدترین حالت', task: { title: 'برای یک تصمیم مالی، بدترین حالت و شرط توقف را مکتوب کن', cat: 'مرور و برنامه‌ریزی', minutes: 20 } }];
      break;
    }
    case 'psychology': {
      text = '<h5>رفتار مالی</h5><p>رفتار، مهم‌تر از هوش است. سه خطای رایج:</p><ol>' +
        '<li><b>حساب‌داری ذهنی:</b> پولی که «جای خاصی» خرج می‌شود، کمتر حساب می‌شود.</li>' +
        '<li><b>سوگیری تازه‌گرایی:</b> رویداد اخیر بیش از حد وزن می‌گیرد.</li>' +
        '<li><b>خرید احساسی:</b> بدون تأخیر و بدون بودجه.</li></ol>' +
        '<h5>راهکار</h5><p>قانون ۲۴ ساعت + ثبت همه هزینه‌ها + تعریف نقطه «کافی».</p>';
      actions = [{ label: 'افزودن: قانون ۲۴ ساعت', task: { title: 'لیست آرزوها را بنویس و ۲۴ ساعت بعد دوباره بررسی کن', cat: 'اقدام مالی', minutes: 10 } }];
      break;
    }
    default: break;
  }
  if (!text) text = buildDiagnosisAnswer(state, c, q);
  return { text, actions, sources: intent ? [intent.pack] : [] };
}

function buildDiagnosisAnswer(state, c, q) {
  const m = c.metrics;
  const money = (n) => fmtCompact(n, state.profile);
  const p = priorities(state);
  return '<h5>تحلیل وضعیت تو</h5><p>درآمد ' + money(m.income) + '، هزینه ' + money(m.expense) + '، خالص ثروت ' + money(m.netWorth) +
    '، نرخ پس‌انداز ' + pct(m.savingsRate) + '، امتیاز مالی ' + c.score.total + '/1000</p>' +
    '<h5>اولویت فعلی: ' + esc(p.primary.title) + '</h5><p>' + esc(p.primary.why) + '</p>' +
    '<ol>' + p.primary.actions.map((a) => '<li>' + esc(a) + '</li>').join('') + '</ol>' +
    '<p>اگر سؤال دقیق‌تری داری، آن را با عدد بنویس؛ مثلاً «با ۱۰۰ میلیون پول چه کار کنم؟»</p>';
}

function buildKnowledgeAnswer(state, q, found, c) {
  const money = (n) => fmtCompact(n, state.profile);
  return '<h5>پاسخ از پایگاه دانش داخلی</h5>' + found.map((f) => '<p><b>' + esc(f.title) + '</b> (' + f.type + ')<br>' + esc(f.body) + '<br><span class="tiny">اجرا: ' + esc(f.apply) + '</span></p>').join('') +
    '<h5>در وضعیت تو</h5><p>با درآمد ' + money(c.metrics.income) + ' و نرخ پس‌انداز ' + pct(c.metrics.savingsRate) + '، مهم‌ترین اقدام امروز: ' + esc(oneBigMove(state).title) + '</p>';
}

export function monthWeeks(state) {
  const m = financeMetrics(state);
  if (m.negativeFlow) return ['حذف یک هزینه ثابت', 'ثبت روزانه هزینه‌ها', 'شروع یک خدمت جانبی', 'بازبینی اعداد و تنظیم برنامه'];
  if (m.savingsRate < 0.15) return ['تنظیم پس‌انداز خودکار', 'کاهش یک هزینه غیرضروری', 'یک اقدام فروش', 'بازبینی هفتگی'];
  if (m.incomeStreams < 2) return ['تعریف خدمت و قیمت', '۲۰ مشتری احتمالی + تماس‌ها', 'بستن اولین سفارش', 'تبدیل سفارش به تکرار'];
  return ['افزایش قیمت/درآمد ۱۰٪', 'مستندسازی فرایند', 'انتقال پس‌انداز به دارایی درآمدزا', 'بازبینی ماهانه و تنظیم مسیر'];
}

/* ------------------------------------------------ ۶) Career/Skill Engine */
export function skillROI(state) {
  const c = buildContext(state);
  const skills = c.skills.length ? c.skills : ['برنامه‌نویسی', 'فروش', 'بازاریابی', 'طراحی', 'محتوا'];
  const demand = {
    'برنامه‌نویسی': 95, 'هوش مصنوعی': 98, 'فروش': 92, 'بازاریابی': 85, 'طراحی': 78, 'محتوا': 80,
    'مالی': 82, 'مدیریت': 75, 'سرمایه‌گذاری': 80, 'برق صنعتی': 72, 'مکانیک': 70, 'تعمیرات': 74,
    'تولید': 66, 'کشاورزی': 60, 'معدن': 62, 'ساختمان': 68, 'تجارت': 78, 'آموزش': 70, 'پزشکی': 88,
    'مهندسی': 76, 'خدمات': 64, 'سایر': 55,
  };
  const tracked = (state.skills || []);
  return skills.map((s) => {
    const d = demand[s] != null ? demand[s] : 65;
    const rec = tracked.find((t) => t.title === s);
    const level = rec ? (rec.level || 1) : 1;
    const rarity = clamp(d * (0.6 + level * 0.1), 0, 100);
    const fit = clamp(40 + (c.skills.indexOf(s) > -1 ? 25 : 0) + (c.time >= 2 ? 10 : 0) + (c.age <= 35 ? 8 : 0), 10, 100);
    const roi = clamp(Math.round(rarity * 0.5 + fit * 0.5), 5, 100);
    return {
      title: s, demand: Math.round(d), level, rarity: Math.round(rarity), fit: Math.round(fit), roi,
      reason: roi > 70 ? 'تقاضای بالا و تناسب خوب با شرایط تو؛ سریع‌ترین بازده.' : roi > 50 ? 'منطقی است اما نیاز به تمرین منظم و اثبات عملی دارد.' : 'اولویت پایین‌تر؛ بهتر است روی مهارت پردرآمدتر تمرکز کنی.',
    };
  }).sort((a, b) => b.roi - a.roi);
}

export function skillTree(state) {
  const roi = skillROI(state);
  return roi.slice(0, 6).map((s) => ({
    title: s.title, level: s.level, demand: s.demand, roi: s.roi,
    steps: [
      { lvl: 1, fa: 'آشنایی', need: '۱۵ ساعت یادگیری ساخت‌یافته' },
      { lvl: 2, fa: 'اجرای ساده', need: '۳ پروژه کوچک واقعی' },
      { lvl: 3, fa: 'کیفیت قابل فروش', need: '۱۰ پروژه + بازخورد' },
      { lvl: 4, fa: 'تخصص', need: 'نمونه‌کار برجسته + مرجع بودن' },
      { lvl: 5, fa: 'درآمد بالا', need: 'قیمت‌گذاری بالا + مشتری تکرارشونده' },
      { lvl: 6, fa: 'کسب‌وکار', need: 'سیستم + تیم یا محصول' },
    ],
  }));
}

/* -------------------------------------------------- ۷) Business Engine */
const BUSINESS_IDEAS = [
  { title: 'خدمات تخصصی مبتنی بر مهارت (پروژه‌ای)', tags: ['برنامه‌نویسی', 'طراحی', 'محتوا', 'تعمیرات', 'برق صنعتی', 'مکانیک', 'مالی', 'آموزش'], costK: 2, model: 'دریافت حق‌الزحمه پروژه‌ای', why: 'کمترین سرمایه، سریع‌ترین جریان نقدی.' },
  { title: 'کسب‌وکار خدماتی محلی', tags: ['خدمات', 'ساختمان', 'تعمیرات', 'کشاورزی', 'برق صنعتی'], costK: 8, model: 'قرارداد ماهانه/سرویس دوره‌ای', why: 'مشتری تکرارشونده و درآمد قابل پیش‌بینی.' },
  { title: 'فروش و توزیع محصول پرگردش', tags: ['تجارت', 'فروش', 'تولید'], costK: 30, model: 'حاشیه سود روی گردش سرمایه', why: 'مقیاس‌پذیر اگر شبکه فروش داشته باشی.' },
  { title: 'محتوا و دوره آموزشی تخصصی', tags: ['آموزش', 'محتوا', 'هوش مصنوعی', 'برنامه‌نویسی'], costK: 1, model: 'فروش دوره/اشتراک', why: 'اهرم رسانه‌ای، سود بالا پس از ساخت.' },
  { title: 'خدمات پشتیبانی و نگهداری صنعتی', tags: ['برق صنعتی', 'مکانیک', 'مهندسی', 'تعمیرات'], costK: 12, model: 'قرارداد نگهداری ماهانه (AMC)', why: 'درآمد ماهانه ثابت و ماندگاری مشتری بالا.' },
  { title: 'پرورش و تولید محلی', tags: ['کشاورزی', 'تولید'], costK: 25, model: 'فروش مستقیم + قرارداد با فروشنده', why: 'دارایی فیزیکی تولیدکننده درآمد.' },
  { title: 'آژانس کوچک خدمات دیجیتال', tags: ['بازاریابی', 'محتوا', 'طراحی', 'برنامه‌نویسی'], costK: 4, model: 'پکیج ماهانه (Retainer)', why: 'درآمد تکرارشونده با تیم کوچک.' },
  { title: 'خدمات مالی و مشاوره شخصی', tags: ['مالی', 'سرمایه‌گذاری', 'مدیریت'], costK: 1, model: 'حق مشاوره/پلن ماهانه', why: 'هزینه ثابت نزدیک صفر.' },
];

export function businessIdeas(state, opts = {}) {
  const c = buildContext(state);
  const skills = c.skills.length ? c.skills : ['خدمات'];
  return BUSINESS_IDEAS.map((b) => {
    const hits = b.tags.filter((t) => skills.indexOf(t) > -1).length;
    const cost = Math.round(b.costK * 1e6 * (state.profile.currency === 'USD' ? 0.02 : 1));
    const capitalOk = c.metrics.liquid >= cost || cost < c.metrics.income * 2;
    let score = 30 + hits * 22 + (capitalOk ? 18 : -12) + (c.time >= 2 ? 10 : 0) + (c.riskTolerance >= 55 ? 8 : -6);
    if (c.metrics.negativeFlow && cost > c.metrics.liquid) score -= 15;
    score = clamp(score, 8, 97);
    return {
      ...b, cost, score: clamp(Math.round(score), 5, 98),
      market: b.tags[0] + ' — بازار ' + (hits ? 'موجود در شبکه تو' : 'جدید و نیازمند تحقیق'),
      persona: 'فرد/کسب‌وکاری که مسئله «' + b.tags[0] + '» برایش هزینه یا زمان می‌سازد و توان پرداخت دارد.',
      mvp: 'یک نسخه قابل فروش در ۷ روز: یک خدمت مشخص، قیمت مشخص، یک مشتری واقعی.',
      risks: ['عدم تقاضای کافی در ناحیه هدف', 'کمبود سرمایه در گردش', 'وابستگی کامل به زمان خودت'],
      plan30: ['مصاحبه با ۵ مشتری بالقوه و ثبت مسئله دقیق', 'تعریف عرضه و سه سطح قیمت', 'ساخت MVP و ارائه به ۳ نفر', 'اجرای یک کانال جذب مشتری و اندازه‌گیری نرخ تبدیل'],
      firstCustomer: '۲۰ نام از شبکه فعلی بنویس، ۵ پیام شخصی‌سازی‌شده در روز بفرست و به ۳ نفر پیشنهاد آزمایشی با قیمت آغازین بده.',
    };
  }).sort((a, b) => b.score - a.score);
}

/* -------------------------------------------- ۸) تصمیم‌یار «جای من بودی» */
export function decide(state, inputs) {
  const c = buildContext(state);
  const m = c.metrics;
  const money = (n) => fmtCompact(n, state.profile);
  const cash = +inputs.cash || 0;
  const incomeGoal = +inputs.incomeGoal || 0;
  const horizon = +inputs.horizon || 12;
  const lines = [];
  lines.push('<h5>فرضیات</h5><p>نقد: ' + money(cash || m.liquid) + ' — درآمد: ' + money(m.income) + ' — هزینه: ' + money(m.expense) + ' — بدهی: ' + money(m.debtTotal) + ' — ریسک‌پذیری: ' + c.riskTolerance + '/100</p>');

  if (m.negativeFlow) {
    lines.push('<h5>اگر جای تو بودم</h5><p>اول جریان نقدی. هیچ سرمایه‌گذاری یا ریسکی شروع نمی‌کردم تا هزینه کمتر از درآمد شود.</p><ol><li>سه هزینه بزرگ را کاهش بده.</li><li>درآمد را در ۶۰ روز افزایش بده (خدمت جانبی).</li><li>بعد سراغ صندوق اضطراری برو.</li></ol>');
  } else if (m.runwayMonths < 3) {
    lines.push('<h5>اگر جای تو بودم</h5><p>اول سپر نقدی سه‌ماهه می‌ساختم: ' + money(m.expense * 3 - m.liquid) + ' باقی مانده است.</p>');
  } else if (m.debtToIncome > 0.3) {
    const dp = debtPlan(state);
    lines.push('<h5>اگر جای تو بودم</h5><p>بدهی با بهره بالا را می‌بستم (' + esc(dp.why) + '). بازده پرداخت بدهی تضمینی است.</p>');
  } else if (cash > m.expense * 6 && m.savingsRate >= 0.15) {
    lines.push('<h5>اگر جای تو بودم</h5><p>با نقدی ' + money(cash) + ': ۳ ماه هزینه را نقد نگه می‌داشتم، سپس بخشی را به دارایی درآمدزا و بخشی را به ساخت منبع درآمد دوم (مهارت + ابزار) تخصیص می‌دادم. هیچ بخشی را در یک دارایی واحد قفل نمی‌کردم.</p>');
  } else if (incomeGoal > m.income) {
    const rp = reversePlan(state, { targetAmount: m.netWorth, deadline: null });
    const gap = incomeGoal - m.income;
    lines.push('<h5>مسیر رسیدن از ' + money(m.income) + ' به ' + money(incomeGoal) + '</h5><ol>' +
      '<li>فاصله: ' + money(gap) + ' در ماه.</li>' +
      '<li>' + esc(rp.skillNeeded) + '</li>' +
      '<li>وسیله: ' + esc(rp.vehicleNeeded) + '</li>' +
      '<li>اولین اقدام: ' + esc(oneBigMove(state).title) + '</li></ol>');
  } else {
    lines.push('<h5>اگر جای تو بودم</h5><p>پایه‌ها سالم است؛ تمرکز را روی افزایش درآمد و تبدیل پس‌انداز به دارایی درآمدزا می‌گذاشتم.</p>');
  }
  lines.push('<h5>سه اقدام مشخص</h5><ol>' + p.primary.actions.map((a) => '<li>' + esc(a) + '</li>').join('') + '</ol>');
  lines.push('<p class="tiny">این پاسخ حاصل قوانین داخلی برنامه است؛ تصمیم نهایی و مسئولیت آن با تو است.</p>');
  return { text: lines.join(''), horizon };
}

/* ---------------------------------------------------- ۹) Daily Wisdom */
export function wisdomToday(state) {
  const w = pickStable(WISDOM, todayKey() + (state.profile.id || ''));
  return { ...w, source: 'پایگاه دانش داخلی' };
}

export function wisdomList() { return WISDOM; }

/* ------------------------------------------- ۱۰) گزارش مربی (هفته/ماه) */
export function coachMessage(state, kind) {
  const c = buildContext(state);
  const m = c.metrics;
  const money = (n) => fmtCompact(n, state.profile);
  if (kind === 'week') {
    const tc = Math.round(c.taskCompletion * 100);
    return 'این هفته ' + tc + '٪ از کارهای برنامه‌ریزی‌شده انجام شد. ' +
      (m.negativeFlow ? 'اولویت مطلق: جریان نقدی منفی است.' : m.savingsRate < 0.1 ? 'نرخ پس‌انداز پایین است؛ سیستم بساز نه اراده.' : 'اعداد سالم است؛ روی افزایش درآمد تمرکز کن.') +
      ' کار غالب فردا: ' + oneBigMove(state).title;
  }
  return 'امتیاز مالی تو ' + c.score.total + '/1000 است. سه عامل محدودکننده: ' +
    c.score.limiters.map((l) => l.label).join('، ') + '. با شرایط فعلی تو، مهم‌ترین کار بعدی: ' + oneBigMove(state).title;
}

export function presetsForDecisions() { return DECISION_PRESETS; }
export function conceptSearch(q) {
  const term = String(q || '').toLowerCase();
  if (!term) return [];
  return CONCEPTS.filter((c) => (c.title + c.body + c.tags.join(' ')).toLowerCase().indexOf(term) > -1).slice(0, 12);
}
export function goalProbabilityFor(state, goal) { return goalProbability(state, goal, buildContext(state)); }
export function realismFor(state, goal) { return goalRealism(state, goal); }
export function limiterList(state) {
  const c = buildContext(state);
  return topLimiters(state, c.score.components, c.metrics, c.taskCompletion);
}
export function projectionFor(state, opts) { return projectWealth(opts); }
export function pathList() { return PATHS; }
export function conceptCount() { return CONCEPTS.length; }
export function bookCount() { return BOOKS.length; }
export function clampExport(n, a, b) { return clamp(n, a, b); }
export function roundExport(n, d) { return round(n, d); }
