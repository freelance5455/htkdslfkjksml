/**
 * WHITE ROOM OS — Persistent Wall-Clock Timer Engine
 * Supports: Start, Pause, Resume, Finish, Cancel, Reset.
 * Survives: Page refresh, tab switching, app backgrounding, and temporary interruptions.
 * Uses wall-clock epoch timestamps persisted to both IndexedDB and localStorage snapshot.
 */

const TIMER_ID = 'active_timer';
const LS_SNAPSHOT_KEY = 'WHITE_ROOM_OS_TIMER_SNAPSHOT_V1';

export function createIdleTimerState() {
  return {
    id: TIMER_ID,
    taskId: null,
    taskTitle: '',
    skillId: null,
    status: 'idle',
    plannedDurationSec: 0,
    startedAtIso: null,
    finishedAtIso: null,
    lastResumedEpochMs: null,
    lastPausedEpochMs: null,
    accumulatedActiveMs: 0,
    accumulatedPauseMs: 0,
    energy: 7,
    difficulty: 5,
    notes: '',
    updatedAtIso: new Date().toISOString(),
  };
}

export class PersistentTimerEngine {
  constructor(db) {
    this.db = db;
  }

  _saveLocalFallback(state) {
    try {
      if (typeof globalThis !== 'undefined' && globalThis.localStorage) {
        globalThis.localStorage.setItem(LS_SNAPSHOT_KEY, JSON.stringify(state));
      }
    } catch (_) {
      // Ignore storage quota / security errors in restricted environments
    }
  }

  _readLocalFallback() {
    try {
      if (typeof globalThis !== 'undefined' && globalThis.localStorage) {
        const raw = globalThis.localStorage.getItem(LS_SNAPSHOT_KEY);
        return raw ? JSON.parse(raw) : null;
      }
    } catch (_) {
      return null;
    }
    return null;
  }

  async getState() {
    const idbState = await this.db.get('timer_state', TIMER_ID);
    const lsState = this._readLocalFallback();

    if (idbState && lsState) {
      // Prefer whichever snapshot has the more recent updatedAtIso timestamp
      const idbTime = Date.parse(idbState.updatedAtIso || 0);
      const lsTime = Date.parse(lsState.updatedAtIso || 0);
      const winner = lsTime > idbTime ? lsState : idbState;
      if (lsTime > idbTime) {
        await this.db.put('timer_state', winner);
      }
      return winner;
    }

    if (idbState) return idbState;
    if (lsState) {
      await this.db.put('timer_state', lsState);
      return lsState;
    }

    const idle = createIdleTimerState();
    await this.db.put('timer_state', idle);
    this._saveLocalFallback(idle);
    return idle;
  }

  async _persist(nextState) {
    nextState.updatedAtIso = new Date().toISOString();
    const saved = await this.db.put('timer_state', nextState);
    this._saveLocalFallback(saved);
    return saved;
  }

  async start(task, nowEpochMs = Date.now()) {
    if (!task || !task.id) {
      throw new Error('Cannot start timer without a valid task');
    }
    const plannedDurationSec = Math.max(60, Number(task.plannedDurationMin || 25) * 60);
    const nextState = {
      id: TIMER_ID,
      taskId: task.id,
      taskTitle: task.title,
      skillId: task.skillId || null,
      status: 'running',
      plannedDurationSec,
      startedAtIso: new Date(nowEpochMs).toISOString(),
      finishedAtIso: null,
      lastResumedEpochMs: nowEpochMs,
      lastPausedEpochMs: null,
      accumulatedActiveMs: 0,
      accumulatedPauseMs: 0,
      energy: 7,
      difficulty: 5,
      notes: '',
      updatedAtIso: new Date(nowEpochMs).toISOString(),
    };

    // Mark task in_progress if it exists in DB
    const existingTask = await this.db.get('tasks', task.id);
    if (existingTask && existingTask.status === 'pending') {
      await this.db.put('tasks', { ...existingTask, status: 'in_progress' });
    }

    return this._persist(nextState);
  }

  async pause(nowEpochMs = Date.now()) {
    const state = await this.getState();
    if (state.status !== 'running') {
      return state;
    }
    const deltaActive = Math.max(0, nowEpochMs - (state.lastResumedEpochMs || nowEpochMs));
    const nextState = {
      ...state,
      status: 'paused',
      accumulatedActiveMs: state.accumulatedActiveMs + deltaActive,
      lastResumedEpochMs: null,
      lastPausedEpochMs: nowEpochMs,
    };
    return this._persist(nextState);
  }

  async resume(nowEpochMs = Date.now()) {
    const state = await this.getState();
    if (state.status !== 'paused') {
      return state;
    }
    const deltaPause = Math.max(0, nowEpochMs - (state.lastPausedEpochMs || nowEpochMs));
    const nextState = {
      ...state,
      status: 'running',
      accumulatedPauseMs: state.accumulatedPauseMs + deltaPause,
      lastPausedEpochMs: null,
      lastResumedEpochMs: nowEpochMs,
    };
    return this._persist(nextState);
  }

  async finish(nowEpochMs = Date.now()) {
    const state = await this.getState();
    if (state.status !== 'running' && state.status !== 'paused') {
      return state;
    }
    let totalActiveMs = state.accumulatedActiveMs;
    let totalPauseMs = state.accumulatedPauseMs;

    if (state.status === 'running' && state.lastResumedEpochMs) {
      totalActiveMs += Math.max(0, nowEpochMs - state.lastResumedEpochMs);
    } else if (state.status === 'paused' && state.lastPausedEpochMs) {
      totalPauseMs += Math.max(0, nowEpochMs - state.lastPausedEpochMs);
    }

    const nextState = {
      ...state,
      status: 'finished',
      accumulatedActiveMs: totalActiveMs,
      accumulatedPauseMs: totalPauseMs,
      lastResumedEpochMs: null,
      lastPausedEpochMs: null,
      finishedAtIso: new Date(nowEpochMs).toISOString(),
    };
    return this._persist(nextState);
  }

  async cancel(nowEpochMs = Date.now()) {
    const state = await this.getState();
    let totalActiveMs = state.accumulatedActiveMs;
    let totalPauseMs = state.accumulatedPauseMs;
    if (state.status === 'running' && state.lastResumedEpochMs) {
      totalActiveMs += Math.max(0, nowEpochMs - state.lastResumedEpochMs);
    } else if (state.status === 'paused' && state.lastPausedEpochMs) {
      totalPauseMs += Math.max(0, nowEpochMs - state.lastPausedEpochMs);
    }

    const nextState = {
      ...state,
      status: 'cancelled',
      accumulatedActiveMs: totalActiveMs,
      accumulatedPauseMs: totalPauseMs,
      lastResumedEpochMs: null,
      lastPausedEpochMs: null,
      finishedAtIso: new Date(nowEpochMs).toISOString(),
    };
    return this._persist(nextState);
  }

  async reset() {
    const idle = createIdleTimerState();
    return this._persist(idle);
  }

  computeLiveMetrics(state, nowEpochMs = Date.now()) {
    if (!state) {
      return {
        status: 'idle',
        elapsedActiveSec: 0,
        elapsedPauseSec: 0,
        remainingSec: 0,
        progressPct: 0,
      };
    }

    let activeMs = state.accumulatedActiveMs || 0;
    let pauseMs = state.accumulatedPauseMs || 0;

    if (state.status === 'running' && state.lastResumedEpochMs) {
      activeMs += Math.max(0, nowEpochMs - state.lastResumedEpochMs);
    } else if (state.status === 'paused' && state.lastPausedEpochMs) {
      pauseMs += Math.max(0, nowEpochMs - state.lastPausedEpochMs);
    }

    const elapsedActiveSec = Math.floor(activeMs / 1000);
    const elapsedPauseSec = Math.floor(pauseMs / 1000);
    const plannedSec = state.plannedDurationSec || 0;
    const remainingSec = Math.max(0, plannedSec - elapsedActiveSec);
    const progressPct =
      plannedSec > 0 ? Math.min(100, Math.round((elapsedActiveSec / plannedSec) * 100)) : 0;

    return {
      status: state.status,
      taskId: state.taskId,
      taskTitle: state.taskTitle,
      skillId: state.skillId,
      plannedDurationSec: plannedSec,
      elapsedActiveSec,
      elapsedPauseSec,
      remainingSec,
      progressPct,
      startedAtIso: state.startedAtIso,
      finishedAtIso: state.finishedAtIso,
    };
  }
}
