/**
 * WHITE ROOM OS — Isolated Spaced Repetition Scheduling Engine (Phase 3)
 * Decoupled and replaceable scheduling strategy for Flashcards and Objective Retention Reviews.
 * Does not hard-code database logic; accepts a pluggable strategy function if needed in future phases.
 */

export function addDaysIsoDate(dateStr, days) {
  const base = dateStr ? new Date(`${dateStr}T12:00:00Z`) : new Date();
  base.setUTCDate(base.getUTCDate() + Math.max(0, Math.round(days)));
  return base.toISOString().slice(0, 10);
}

/**
 * Default adaptive interval strategy (replaceable).
 * Inputs:
 *  - recallScore: 0..100 (actual recall performance)
 *  - confidence: 0..100 (self-reported confidence)
 *  - difficulty: 1..10 (item difficulty)
 *  - previousInterval: number of days
 *  - repetitionCount: consecutive successful reviews
 *  - easeFactor: multiplier (default 2.3)
 *  - reviewDate: YYYY-MM-DD
 */
export function defaultSpacedRepetitionStrategy({
  recallScore = 80,
  confidence = 75,
  difficulty = 5,
  previousInterval = 0,
  repetitionCount = 0,
  easeFactor = 2.3,
  reviewDate = new Date().toISOString().slice(0, 10),
}) {
  const passed = Number(recallScore) >= 70;
  const normDifficulty = Math.max(1, Math.min(10, Number(difficulty || 5)));

  // Detect overconfidence penalty (high confidence but low/mediocre recall)
  const overconfidenceGap = Number(confidence) - Number(recallScore);
  const overconfidencePenalty = overconfidenceGap >= 25 ? 0.25 : 0;

  // Adjust ease factor bounded between 1.3 and 2.8
  const scoreQuality = (Number(recallScore) - 60) / 40; // -1.5 .. +1.0
  const difficultyDrag = (normDifficulty - 5) * 0.04;
  const nextEaseFactor = Number(
    Math.max(
      1.3,
      Math.min(2.8, easeFactor + scoreQuality * 0.18 - difficultyDrag - overconfidencePenalty)
    ).toFixed(2)
  );

  let nextInterval = 1;
  let nextRepetitionCount = 0;
  let retentionState = 'LEARNING';

  if (!passed) {
    nextInterval = 1;
    nextRepetitionCount = 0;
    retentionState = repetitionCount > 0 ? 'LAPSED' : 'LEARNING';
  } else {
    nextRepetitionCount = repetitionCount + 1;
    if (nextRepetitionCount === 1) {
      nextInterval = recallScore >= 90 ? 2 : 1;
      retentionState = 'REVIEW';
    } else if (nextRepetitionCount === 2) {
      nextInterval = recallScore >= 90 ? 5 : 3;
      retentionState = 'REVIEW';
    } else {
      const base = Math.max(3, previousInterval || 3);
      nextInterval = Math.min(120, Math.max(base + 1, Math.round(base * nextEaseFactor)));
      retentionState = nextInterval >= 14 && recallScore >= 85 ? 'RETAINED' : 'REVIEW';
    }
  }

  const nextReviewDate = addDaysIsoDate(reviewDate, nextInterval);

  return {
    passed,
    interval: nextInterval,
    repetitionCount: nextRepetitionCount,
    easeFactor: nextEaseFactor,
    nextReviewDate,
    retentionState,
    metacognitiveMismatch: overconfidenceGap >= 25,
    calibrationDelta: Number((Number(confidence) - Number(recallScore)).toFixed(1)),
  };
}

export class SpacedRepetitionScheduler {
  constructor(strategyFn = defaultSpacedRepetitionStrategy) {
    this.strategyFn = strategyFn;
  }

  setStrategy(customStrategyFn) {
    if (typeof customStrategyFn !== 'function') {
      throw new Error('Spaced repetition strategy must be a function');
    }
    this.strategyFn = customStrategyFn;
  }

  scheduleNextReview(params) {
    return this.strategyFn(params);
  }

  isOverdue(nextReviewDate, currentDateStr = new Date().toISOString().slice(0, 10)) {
    if (!nextReviewDate) return true;
    return String(nextReviewDate) <= String(currentDateStr);
  }
}
