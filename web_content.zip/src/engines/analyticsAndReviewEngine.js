/**
 * WHITE ROOM OS — Phase 6 Reporting, Analytics, Performance Trends & Review Engine
 *
 * Transforms persisted database records from Phases 1–5 into an evidence-based performance
 * analysis system that:
 *  A. Measures development & progress trends per Goal, Capability, Skill, and Subskill
 *  B. Keeps all 9 performance dimensions distinct (Activity, Learning, Competence, Mastery,
 *     Retention, Consistency, Workload, Errors, Execution) with zero double-counting
 *  C. Analyzes scheduling, planned-vs-actual time, estimation errors, overload & recovery
 *  D. Identifies error patterns, remediation outcomes, and downstream prerequisite bottlenecks
 *  E. Evaluates Goals against their ambitious targets (never silently lowering targets or fabricating forecasts)
 *  F. Generates and persists Daily, Weekly, and Monthly Reviews with immutable snapshots & user notes
 *  G. Exports verified JSON, RFC-4180 CSV, and Markdown reports
 *
 * Strictly Read-Only for analytics: never mutates source records during analysis.
 */

import {
  LEARNING_EVIDENCE_TYPES,
  COMPETENCE_EVIDENCE_TYPES,
  RETENTION_EVIDENCE_TYPES,
} from './skillEngine.js';
import {
  addDaysToDate,
  calculateAvailableTimeAndBuffers,
  validateWorkloadAndRecovery,
} from './priorityEngine.js';

/**
 * RFC-4180 compliant CSV cell escaping.
 * Safely handles commas, double quotes, newlines, carriage returns, Arabic text, and special characters.
 */
export function escapeCsvCell(value) {
  if (value === null || value === undefined) return '';
  const str = String(value);
  if (
    str.includes(',') ||
    str.includes('"') ||
    str.includes('\n') ||
    str.includes('\r') ||
    str.startsWith(' ') ||
    str.endsWith(' ')
  ) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Extracts a consistent UTC YYYY-MM-DD date string from any persisted record.
 */
export function extractRecordDateStr(record) {
  if (!record || typeof record !== 'object') return null;
  const raw =
    record.date ||
    record.reviewDate ||
    record.weekStartDate ||
    record.finishedAtIso ||
    record.timestamp ||
    record.lastMasteredAt ||
    record.createdAt ||
    record.updatedAt ||
    null;
  if (!raw || typeof raw !== 'string') return null;
  const match = raw.match(/^(\d{4}-\d{2}-\d{2})/);
  if (match) return match[1];
  const parsed = Date.parse(raw);
  if (!Number.isNaN(parsed)) {
    return new Date(parsed).toISOString().slice(0, 10);
  }
  return null;
}

/**
 * Resolves deterministic UTC date boundaries (startDate, endDate, periodKey, dayCount)
 * for daily, weekly, monthly, or custom date ranges.
 */
export function resolvePeriodBoundaries(periodType = 'daily', referenceDate = '2026-10-14', customEndDate = null) {
  const cleanRef =
    typeof referenceDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(referenceDate)
      ? referenceDate
      : '2026-10-14';

  if (periodType === 'daily') {
    return {
      periodType: 'daily',
      periodKey: `daily_${cleanRef}`,
      startDate: cleanRef,
      endDate: cleanRef,
      dayCount: 1,
    };
  }

  if (periodType === 'weekly') {
    const startDate = cleanRef;
    const endDate = addDaysToDate(startDate, 6);
    return {
      periodType: 'weekly',
      periodKey: `weekly_${startDate}_${endDate}`,
      startDate,
      endDate,
      dayCount: 7,
    };
  }

  if (periodType === 'monthly') {
    const [y, m] = cleanRef.slice(0, 7).split('-').map(Number);
    const lastDay = new Date(Date.UTC(y, m, 0)).getUTCDate();
    const monthPrefix = `${String(y).padStart(4, '0')}-${String(m).padStart(2, '0')}`;
    const startDate = `${monthPrefix}-01`;
    const endDate = `${monthPrefix}-${String(lastDay).padStart(2, '0')}`;
    return {
      periodType: 'monthly',
      periodKey: `monthly_${monthPrefix}`,
      startDate,
      endDate,
      dayCount: lastDay,
    };
  }

  const startDate = cleanRef;
  const endDate =
    customEndDate && /^\d{4}-\d{2}-\d{2}$/.test(customEndDate) && customEndDate >= startDate
      ? customEndDate
      : startDate;
  const dayCount =
    Math.max(
      1,
      Math.round((Date.parse(`${endDate}T12:00:00Z`) - Date.parse(`${startDate}T12:00:00Z`)) / 86400000) + 1
    );

  return {
    periodType: 'custom',
    periodKey: `custom_${startDate}_${endDate}`,
    startDate,
    endDate,
    dayCount,
  };
}

export function isDateWithinRange(dateStr, startDate = null, endDate = null) {
  if (!startDate && !endDate) return true;
  if (!dateStr) return false;
  if (startDate && dateStr < startDate) return false;
  if (endDate && dateStr > endDate) return false;
  return true;
}

export const NINE_DIMENSIONS_METADATA = Object.freeze({
  activity: {
    key: 'activity',
    labelAr: '1. النشاط والالتزام الزمني (Activity)',
    labelEn: 'Activity',
    unit: '%',
    definition:
      'نسبة المهام المكتملة وحجم دقائق الدراسة والتدريب الفعلي المسجلة مقارنة بالسقف المستهدف.',
    denominatorDescription:
      'إجمالي المهام المجدولة + دقائق التدريب المستهدفة للمهارات النشطة (أو null عند عدم وجود مهام أو أهداف).',
    exclusions:
      'يستبعد درجات الاختبارات، حالات الإتقان (Mastery)، وفحوصات الاحتفاظ (Retention). ساعات الدراسة لا تُحسب ككفاءة.',
    limitations:
      'يقيس الجهد المبذول والوقت المستثمر فقط ولا يثبت الفهم أو الإتقان.',
  },
  learning: {
    key: 'learning',
    labelAr: '2. التقدم التعلمي والاستيعاب (Learning)',
    labelEn: 'Learning',
    unit: '%',
    definition:
      'نسبة وحدات المنهج المكتملة، جلسات التعلم النشطة، وأدلة الفهم/الشرح الذاتي (Learning & Feynman Evidence).',
    denominatorDescription:
      'إجمالي وحدات المنهج والأهداف التعلمية والأدلة التعلمية المطلوبة.',
    exclusions:
      'يستبعد اختبارات الإتقان النهائية وفحوصات الاحتفاظ طويلة المدى (Zero Double-Counting).',
    limitations:
      'يعكس التعرض والمعالجة النشطة للمحتوى قبل التحقق المستقل تحت ضغط الاختبار.',
  },
  competence: {
    key: 'competence',
    labelAr: '3. الكفاءة التطبيقية المحققة (Competence)',
    labelEn: 'Competence',
    unit: '%',
    definition:
      'متوسط الأداء والدقة في محاولات الاختبار الفعلي والعروض العملية المستقلة مطروحاً منه أثر الأخطاء المفتوحة.',
    denominatorDescription:
      'إجمالي محاولات الاختبار (test_attempts) وأدلة الكفاءة التطبيقية المسجلة (أو null إذا لم يُجرَ أي تقييم).',
    exclusions:
      'يستبعد ساعات المشاهدة، المهام المكتملة بدون تقييم، وفحوصات الصيانة بعد الإتقان.',
    limitations:
      'يتطلب محاولة اختبار واحدة على الأقل؛ عند عدم وجود اختبارات تكون القيمة null (بيانات غير كافية) وليست 0% مضللة.',
  },
  mastery: {
    key: 'mastery',
    labelAr: '4. الإتقان وبوابات العبور (Mastery)',
    labelEn: 'Mastery',
    unit: '%',
    definition:
      'نسبة استيفاء معايير بوابات الإتقان القابلة للتكوين للمهارات والمهارات الفرعية، مع حفظ سجل الإتقان التاريخي.',
    denominatorDescription:
      'إجمالي معايير بوابات الإتقان للمهارات المشمولة في التحليل.',
    exclusions:
      'لا يعتمد على إتمام المهام وحده، ولا يخلط بين الإتقان التاريخي والاحتفاظ الحالي.',
    limitations:
      'يتطلب استيفاء جميع شروط البوابة (الدرجة، الدقة، الاستمرارية، الأدلة التخصصية، وخلو الأخطاء المفتوحة).',
  },
  retention: {
    key: 'retention',
    labelAr: '5. الاحتفاظ طويل المدى (Retention)',
    labelEn: 'Retention',
    unit: '%',
    definition:
      'أداء الاسترجاع المؤجل وفحوصات الصيانة الدورية للمهارات والأهداف بعد إتقانها.',
    denominatorDescription:
      'إجمالي فحوصات الاحتفاظ (reviews) وأدلة الصيانة المسجلة (أو null عند عدم وجود فحوصات احتفاظ).',
    exclusions:
      'يستبعد اختبارات الاكتساب الأولي ومجرد فتح البطاقات بدون درجة أداء.',
    limitations:
      'يقيس ثبات الكفاءة عبر الزمن؛ تراجع الاحتفاظ يطلق مسار إعادة تعلم دون مسح حقيقة الإتقان التاريخي.',
  },
  consistency: {
    key: 'consistency',
    labelAr: '6. الاستمرارية والانتظام (Consistency)',
    labelEn: 'Consistency',
    unit: '%',
    definition:
      'نسبة الأيام التي شَهِدت نشاطاً فعلياً موثقاً (مهمة منجزة، جلسة تعلم، أو سجل أداء) خلال الفترة المحددة.',
    denominatorDescription:
      'إجمالي عدد أيام الفترة التحليلية (أو عدد الأيام منذ أول نشاط مسجل).',
    exclusions:
      'لا يحتسب الأيام التي خُططت فيها مهام دون تنفيذ فعلي.',
    limitations:
      'في الفترات القصيرة جداً (أقل من 3 أيام) يكون المؤشر أولياً.',
  },
  workload: {
    key: 'workload',
    labelAr: '7. توازن الحمل والالتزام بالوقت (Workload)',
    labelEn: 'Workload',
    unit: '%',
    definition:
      'نسبة الدقائق المنفذة فعلياً إلى الدقائق المخططة ضمن السقف الآمن، مع رصد أيام الحمل الزائد (Overload).',
    denominatorDescription:
      'إجمالي الدقائق المخططة للمهام في الفترة (أو null إذا لم توجد دقائق مخططة).',
    exclusions:
      'لا يكافئ تجاوز السقف الصحي اليومي أو تقليص ساعات النوم.',
    limitations:
      'النسبة الأعلى من 100% قد تشير إلى خطأ في تقدير الوقت (Underestimation) أو حمل زائد.',
  },
  errors: {
    key: 'errors',
    labelAr: '8. معالجة الأخطاء وإغلاق الفجوات (Errors)',
    labelEn: 'Errors',
    unit: '%',
    definition:
      'نسبة الأخطاء التي تمت معالجتها وإغلاقها عبر إعادة اختبار محققة من إجمالي الأخطاء المسجلة.',
    denominatorDescription:
      'إجمالي الأخطاء المسجلة في الفترة/النطاق (أو null عند عدم تسجيل أي أخطاء).',
    exclusions:
      'لا تُعتبر الأخطاء مغلقة بمجرد إنشاء خطة علاجية دون اجتياز إعادة الاختبار.',
    limitations:
      'عدم وجود أخطاء مسجلة عند غياب الاختبارات يعني غياب الفحص التشخيصي وليس الكمال.',
  },
  execution: {
    key: 'execution',
    labelAr: '9. كفاءة التنفيذ اليومي (Execution)',
    labelEn: 'Execution',
    unit: '%',
    definition:
      'نسبة المهام المكتملة كلياً من إجمالي المهام المجدولة (مع تفصيل الإنجاز الجزئي، التخطي، وإعادة الجدولة).',
    denominatorDescription:
      'إجمالي المهام المجدولة غير المؤجلة في النطاق (أو null عند عدم وجود مهام).',
    exclusions:
      'المهام المؤجلة تلقائياً لحماية الـ Buffer لا تُحسب كفشل تنفيذي.',
    limitations:
      'يقيس الانضباط التنفيذي اليومي ويجب قراءته مع مؤشر الكفاءة (Competence).',
  },
});

export class AnalyticsAndReviewEngine {
  constructor(db, engines = {}) {
    this.db = db;
    this.skillEngine = engines.skillEngine;
    this.learningEngine = engines.learningEngine;
    this.schedulerEngine = engines.schedulerEngine;
    this.diagnosticsEngine = engines.diagnosticsEngine;
    this.performanceEngine = engines.performanceEngine;
    this.timeEngine = engines.timeEngine;
  }

  /**
   * Loads an immutable deep-cloned snapshot of all relevant stores so analytics calculations
   * are guaranteed 100% read-only and never mutate source records.
   */
  async _loadReadOnlySnapshot(filters = {}) {
    if (filters && filters._preloadedSnap) return filters._preloadedSnap;
    const {
      startDate = null,
      endDate = null,
      goalId = null,
      capabilityId = null,
      skillId = null,
    } = filters;

    const [
      visions,
      goals,
      capabilities,
      skills,
      subskills,
      curriculum,
      resources,
      evidence,
      tests,
      testAttempts,
      remediations,
      reviews,
      learningObjectives,
      learningSessions,
      recallAttempts,
      flashcards,
      feynmanEntries,
      learningPaths,
      scheduleConfigList,
      tasks,
      dailyPlans,
      weeklyPlans,
      timeBlocks,
      executionHistory,
      performanceLogs,
      errors,
      diagnosticAssessments,
      masteryHistory,
      periodicReviews,
    ] = await Promise.all([
      this.db.getAll('visions'),
      this.db.getAll('goals'),
      this.db.getAll('capabilities'),
      this.db.getAll('skills'),
      this.db.getAll('subskills'),
      this.db.getAll('curriculum'),
      this.db.getAll('resources'),
      this.db.getAll('evidence'),
      this.db.getAll('tests'),
      this.db.getAll('test_attempts'),
      this.db.getAll('remediations'),
      this.db.getAll('reviews'),
      this.db.getAll('learning_objectives'),
      this.db.getAll('learning_sessions'),
      this.db.getAll('recall_attempts'),
      this.db.getAll('flashcards'),
      this.db.getAll('feynman_entries'),
      this.db.getAll('learning_paths'),
      this.db.getAll('schedule_config'),
      this.db.getAll('tasks'),
      this.db.getAll('daily_plans'),
      this.db.getAll('weekly_plans'),
      this.db.getAll('time_blocks'),
      this.db.getAll('execution_history'),
      this.db.getAll('performance_logs'),
      this.db.getAll('errors'),
      this.db.getAll('diagnostic_assessments'),
      this.db.getAll('mastery_history'),
      this.db.getAll('periodic_reviews'),
    ]);

    // Filter skills/goals/capabilities by entity filters
    const filteredGoals = goals.filter((g) => {
      if (goalId && g.id !== goalId) return false;
      if (capabilityId && g.capabilityId !== capabilityId) return false;
      return true;
    });
    const allowedGoalIds = new Set(filteredGoals.map((g) => g.id));

    const filteredSkills = skills.filter((s) => {
      if (skillId && s.id !== skillId) return false;
      if (capabilityId && s.capabilityId !== capabilityId) return false;
      if (goalId && s.goalId !== goalId && !allowedGoalIds.has(s.goalId)) return false;
      return true;
    });
    const allowedSkillIds = new Set(filteredSkills.map((s) => s.id));

    const matchSkillAndDate = (rec, requireSkillMatch = true) => {
      if (requireSkillMatch && (skillId || capabilityId || goalId)) {
        if (rec.skillId && !allowedSkillIds.has(rec.skillId)) return false;
        if (!rec.skillId && goalId && rec.goalId !== goalId) return false;
      }
      if (startDate || endDate) {
        const dStr = extractRecordDateStr(rec);
        if (!isDateWithinRange(dStr, startDate, endDate)) return false;
      }
      return true;
    };

    const matchSkillOnly = (rec) => {
      if (skillId || capabilityId || goalId) {
        if (rec.skillId && !allowedSkillIds.has(rec.skillId)) return false;
      }
      return true;
    };

    return structuredClone({
      filters: { startDate, endDate, goalId, capabilityId, skillId },
      allSkills: skills,
      allSubskills: subskills,
      allGoals: goals,
      allObjectives: learningObjectives,
      visions,
      goals: filteredGoals,
      capabilities: capabilities.filter((c) => !capabilityId || c.id === capabilityId),
      skills: filteredSkills,
      subskills: subskills.filter(matchSkillOnly),
      curriculum: curriculum.filter(matchSkillOnly),
      resources: resources.filter(matchSkillOnly),
      evidence: evidence.filter((r) => matchSkillAndDate(r, true)),
      allSkillEvidence: evidence.filter(matchSkillOnly),
      tests: tests.filter(matchSkillOnly),
      testAttempts: testAttempts.filter((r) => matchSkillAndDate(r, true)),
      allSkillTestAttempts: testAttempts.filter(matchSkillOnly),
      remediations: remediations.filter((r) => matchSkillAndDate(r, true)),
      allSkillRemediations: remediations.filter(matchSkillOnly),
      reviews: reviews.filter((r) => matchSkillAndDate(r, true)),
      allSkillReviews: reviews.filter(matchSkillOnly),
      learningObjectives: learningObjectives.filter(matchSkillOnly),
      learningSessions: learningSessions.filter((r) => matchSkillAndDate(r, true)),
      recallAttempts: recallAttempts.filter((r) => matchSkillAndDate(r, true)),
      flashcards: flashcards.filter(matchSkillOnly),
      feynmanEntries: feynmanEntries.filter((r) => matchSkillAndDate(r, true)),
      learningPaths: learningPaths.filter(matchSkillOnly),
      scheduleConfig: scheduleConfigList[0] || {
        collegeDays: ['Saturday', 'Tuesday', 'Thursday'],
        collegeStart: '06:00',
        collegeEnd: '18:00',
        sleepHours: 7.5,
        mealsAndPrayerHours: 1.5,
        otherCommitmentsHours: 1.0,
        bufferRatio: 0.2,
        maxDailyWorkloadMin: 360,
        maxCollegeDayWorkloadMin: 110,
      },
      tasks: tasks.filter((r) => matchSkillAndDate(r, Boolean(skillId || capabilityId || goalId))),
      dailyPlans: dailyPlans.filter((p) => isDateWithinRange(p.date, startDate, endDate)),
      weeklyPlans,
      timeBlocks: timeBlocks.filter((b) => isDateWithinRange(b.date, startDate, endDate)),
      executionHistory: executionHistory.filter((r) =>
        matchSkillAndDate(r, Boolean(skillId || capabilityId || goalId))
      ),
      performanceLogs: performanceLogs.filter((r) =>
        matchSkillAndDate(r, Boolean(skillId || capabilityId || goalId))
      ),
      errors: errors.filter((r) => matchSkillAndDate(r, true)),
      allSkillErrors: errors.filter(matchSkillOnly),
      diagnosticAssessments: diagnosticAssessments.filter((r) => matchSkillAndDate(r, true)),
      masteryHistory: masteryHistory.filter((r) => matchSkillAndDate(r, true)),
      allSkillMasteryHistory: masteryHistory.filter(matchSkillOnly),
      periodicReviews,
    });
  }

  // =========================================================================
  // 4A. DEVELOPMENT AND PROGRESS TRENDS
  // =========================================================================

  _computeSeriesTrend(observations = []) {
    const sorted = [...observations]
      .filter((o) => typeof o.value === 'number' && !Number.isNaN(o.value))
      .sort((a, b) => String(a.dateOrIso || '').localeCompare(String(b.dateOrIso || '')));

    const count = sorted.length;
    if (count === 0) {
      return {
        observationCount: 0,
        baseline: null,
        latest: null,
        changeSinceBaseline: null,
        historicalTrend: 'INSUFFICIENT_DATA',
        recentTrend: 'INSUFFICIENT_DATA',
        points: [],
      };
    }

    const first = sorted[0];
    const last = sorted[count - 1];

    if (count === 1) {
      return {
        observationCount: 1,
        baseline: { value: first.value, date: first.dateOrIso, source: first.source },
        latest: { value: last.value, date: last.dateOrIso, source: last.source },
        changeSinceBaseline: null,
        historicalTrend: 'INSUFFICIENT_DATA',
        recentTrend: 'INSUFFICIENT_DATA',
        points: sorted,
      };
    }

    const histDelta = Number((last.value - first.value).toFixed(2));
    const historicalTrend =
      histDelta >= 3 ? 'IMPROVING' : histDelta <= -3 ? 'DECLINING' : 'STABLE';

    const recentSlice = sorted.slice(-Math.min(3, count));
    const recentDelta = Number(
      (recentSlice[recentSlice.length - 1].value - recentSlice[0].value).toFixed(2)
    );
    const recentTrend =
      recentDelta >= 3 ? 'IMPROVING' : recentDelta <= -3 ? 'DECLINING' : 'STABLE';

    return {
      observationCount: count,
      baseline: { value: first.value, date: first.dateOrIso, source: first.source },
      latest: { value: last.value, date: last.dateOrIso, source: last.source },
      changeSinceBaseline: histDelta,
      historicalTrend,
      recentTrend,
      points: sorted,
    };
  }

  async analyzeDevelopmentTrends(filters = {}) {
    const snap = await this._loadReadOnlySnapshot(filters);
    const skillTrends = [];
    const subskillTrends = [];
    const goalTrends = [];
    const capabilityTrends = [];

    for (const sk of snap.skills) {
      const skAttempts = snap.testAttempts.filter((a) => a.skillId === sk.id);
      const skRecalls = snap.recallAttempts.filter((r) => r.skillId === sk.id);
      const skReviews = snap.reviews.filter((rv) => rv.skillId === sk.id);
      const skSessions = snap.learningSessions.filter((ls) => ls.skillId === sk.id);
      const skTasks = snap.tasks.filter(
        (t) => t.skillId === sk.id && (t.status === 'completed' || t.status === 'partially_completed')
      );
      const skLogs = snap.performanceLogs.filter((l) => l.skillId === sk.id);

      const assessmentObs = [
        ...skAttempts.map((a) => ({
          value: Number(a.score),
          accuracy: Number(a.accuracy),
          dateOrIso: a.timestamp || extractRecordDateStr(a),
          source: a.isRetest ? 'retest_attempt' : 'test_attempt',
          id: a.id,
        })),
        ...skReviews.map((rv) => ({
          value: Number(rv.score),
          accuracy: Number(rv.score),
          dateOrIso: rv.reviewDate,
          source: 'retention_review',
          id: rv.id,
        })),
        ...skRecalls.map((rc) => ({
          value: Number(rc.correctness),
          accuracy: Number(rc.correctness),
          dateOrIso: rc.timestamp || extractRecordDateStr(rc),
          source: 'recall_attempt',
          id: rc.id,
        })),
      ];

      const trendInfo = this._computeSeriesTrend(assessmentObs);

      const activityDates = [
        ...skTasks.map((t) => extractRecordDateStr(t)),
        ...skSessions.map((s) => extractRecordDateStr(s)),
        ...skLogs.map((l) => extractRecordDateStr(l)),
        ...(sk.metrics?.lastPracticedDate ? [sk.metrics.lastPracticedDate] : []),
      ]
        .filter(Boolean)
        .sort();

      const assessmentDates = [
        ...skAttempts.map((a) => extractRecordDateStr(a)),
        ...skReviews.map((rv) => extractRecordDateStr(rv)),
      ]
        .filter(Boolean)
        .sort();

      const lastActivityAt =
        activityDates.length > 0 ? activityDates[activityDates.length - 1] : null;
      const lastMeaningfulAssessmentAt =
        assessmentDates.length > 0 ? assessmentDates[assessmentDates.length - 1] : null;

      const hasDirectTestMeasurement = skAttempts.length > 0 || skReviews.length > 0;
      const measuredScore = hasDirectTestMeasurement ? trendInfo.latest?.value ?? null : null;

      const isSufficient = trendInfo.observationCount >= 2 && hasDirectTestMeasurement;

      skillTrends.push({
        entityType: 'skill',
        id: sk.id,
        name: sk.nameAr || sk.name,
        capabilityId: sk.capabilityId,
        goalId: sk.goalId || null,
        configuredTarget: {
          targetLevel: sk.targetLevel,
          minTestScore: sk.masteryCriteria?.minTestScore ?? 85,
          minAccuracy: sk.masteryCriteria?.minAccuracy ?? 80,
          requiredEvidenceCount: sk.masteryCriteria?.requiredEvidenceCount ?? 1,
          requiredEvidenceTypes: sk.masteryCriteria?.requiredEvidenceTypes || [],
        },
        currentMeasuredState: {
          status: sk.status,
          currentRetentionStatus: sk.currentRetentionStatus || 'UNMASTERED',
          historicalMasteryAchieved: Boolean(sk.historicalMasteryAchieved),
          directlyMeasuredScore: measuredScore,
          measurementBasis: hasDirectTestMeasurement
            ? 'DIRECT_ASSESSMENT'
            : 'UNMEASURED_NO_TEST_ATTEMPTS',
          configuredCurrentLevel: hasDirectTestMeasurement ? sk.currentLevel : null,
          estimatedIndicatorProgress: sk.progress || null,
        },
        baseline: trendInfo.baseline,
        changeSinceBaseline: trendInfo.changeSinceBaseline,
        recentTrend: trendInfo.recentTrend,
        historicalTrend: trendInfo.historicalTrend,
        observationCount: trendInfo.observationCount,
        observations: trendInfo.points,
        lastActivityAt,
        lastMeaningfulAssessmentAt,
        evidenceSufficiency: {
          isSufficient,
          status: isSufficient
            ? 'SUFFICIENT_EVIDENCE'
            : trendInfo.observationCount === 0
            ? 'NO_OBSERVATIONS'
            : 'INSUFFICIENT_OBSERVATIONS',
          reason: isSufficient
            ? `مدعوم بـ (${trendInfo.observationCount}) قياسات أداء فعلية.`
            : `البيانات غير كافية لاستخلاص اتجاه موثوق (عدد القياسات: ${trendInfo.observationCount}، يتطلب قياسين على الأقل مع اختبار فعلي).`,
        },
      });
    }

    for (const sub of snap.subskills) {
      const subAttempts = snap.testAttempts.filter((a) => a.subskillId === sub.id);
      const subReviews = snap.reviews.filter((rv) => rv.subskillId === sub.id);
      const obs = [
        ...subAttempts.map((a) => ({
          value: Number(a.score),
          dateOrIso: a.timestamp || extractRecordDateStr(a),
          source: 'test_attempt',
        })),
        ...subReviews.map((rv) => ({
          value: Number(rv.score),
          dateOrIso: rv.reviewDate,
          source: 'retention_review',
        })),
      ];
      const tInfo = this._computeSeriesTrend(obs);
      const hasDirect = subAttempts.length > 0 || subReviews.length > 0;
      subskillTrends.push({
        entityType: 'subskill',
        id: sub.id,
        skillId: sub.skillId,
        name: sub.name,
        configuredTarget: {
          minTestScore: sub.masteryCriteria?.minTestScore ?? 85,
          minAccuracy: sub.masteryCriteria?.minAccuracy ?? 80,
        },
        currentMeasuredState: {
          masteryState: sub.masteryState,
          currentRetentionStatus: sub.currentRetentionStatus || 'UNMASTERED',
          historicalMasteryAchieved: Boolean(sub.historicalMasteryAchieved),
          directlyMeasuredScore: hasDirect ? tInfo.latest?.value ?? null : null,
          measurementBasis: hasDirect ? 'DIRECT_ASSESSMENT' : 'UNMEASURED',
        },
        baseline: tInfo.baseline,
        changeSinceBaseline: tInfo.changeSinceBaseline,
        recentTrend: tInfo.recentTrend,
        historicalTrend: tInfo.historicalTrend,
        observationCount: tInfo.observationCount,
        lastMeaningfulAssessmentAt: tInfo.latest?.date || null,
        evidenceSufficiency: {
          isSufficient: tInfo.observationCount >= 2 && hasDirect,
          status: tInfo.observationCount >= 2 && hasDirect ? 'SUFFICIENT_EVIDENCE' : 'INSUFFICIENT_DATA',
        },
      });
    }

    for (const goal of snap.goals) {
      const linkedSkills = skillTrends.filter(
        (st) => st.goalId === goal.id || st.capabilityId === goal.capabilityId
      );
      const totalObs = linkedSkills.reduce((s, st) => s + st.observationCount, 0);
      const masteredCount = linkedSkills.filter(
        (st) =>
          st.currentMeasuredState.status === 'MASTERED' ||
          st.currentMeasuredState.status === 'MAINTENANCE'
      ).length;
      goalTrends.push({
        entityType: 'goal',
        id: goal.id,
        title: goal.title,
        capabilityId: goal.capabilityId,
        configuredTarget: {
          targetDate: goal.targetDate || null,
          requiredSkillsCount: linkedSkills.length,
          status: goal.status,
        },
        currentMeasuredState: {
          progressPct: goal.progressPct,
          masteredSkillsCount: masteredCount,
          totalLinkedSkills: linkedSkills.length,
        },
        observationCount: totalObs,
        evidenceSufficiency: {
          isSufficient: totalObs >= 2,
          status: totalObs >= 2 ? 'SUFFICIENT_EVIDENCE' : 'INSUFFICIENT_DATA',
        },
      });
    }

    for (const cap of snap.capabilities) {
      const capSkills = skillTrends.filter((st) => st.capabilityId === cap.id);
      const totalObs = capSkills.reduce((s, st) => s + st.observationCount, 0);
      capabilityTrends.push({
        entityType: 'capability',
        id: cap.id,
        name: cap.nameAr || cap.name,
        linkedSkillsCount: capSkills.length,
        observationCount: totalObs,
        evidenceSufficiency: {
          isSufficient: totalObs >= 2,
          status: totalObs >= 2 ? 'SUFFICIENT_EVIDENCE' : 'INSUFFICIENT_DATA',
        },
      });
    }

    return {
      isEmpty:
        snap.skills.length === 0 &&
        snap.testAttempts.length === 0 &&
        snap.tasks.length === 0,
      skills: skillTrends,
      subskills: subskillTrends,
      goals: goalTrends,
      capabilities: capabilityTrends,
    };
  }

  // =========================================================================
  // 4B. 9 DISTINCT PERFORMANCE DIMENSIONS (ZERO DOUBLE-COUNTING & ZERO-DENOMINATOR SAFE)
  // =========================================================================

  async computeNineDimensions(filters = {}) {
    const snap = await this._loadReadOnlySnapshot(filters);

    // Disjoint Evidence Partitioning (Zero Double-Counting)
    const learningEvidence = [];
    const competenceEvidence = [];
    const retentionEvidence = [];

    for (const ev of snap.evidence) {
      const evType = String(ev.type || 'training').toLowerCase();
      if (RETENTION_EVIDENCE_TYPES.includes(evType)) {
        retentionEvidence.push(ev);
      } else if (COMPETENCE_EVIDENCE_TYPES.includes(evType) || ev.independentApplication) {
        competenceEvidence.push(ev);
      } else {
        learningEvidence.push(ev);
      }
    }

    // 1. ACTIVITY: completed tasks & logged duration vs planned/target
    const activeTasks = snap.tasks.filter(
      (t) => t.status !== 'deferred' && t.status !== 'cancelled'
    );
    const completedTasksCount = activeTasks.filter((t) => t.status === 'completed').length;
    const loggedMinutesFromLogs = snap.performanceLogs.reduce(
      (s, l) => s + Math.round((l.actualDurationSec || 0) / 60),
      0
    );
    const loggedMinutesFromSessions = snap.learningSessions.reduce(
      (s, ls) => s + Number(ls.actualDurationMin || 0),
      0
    );
    const totalActiveMinutes = loggedMinutesFromLogs + loggedMinutesFromSessions;
    const activityDenominator = activeTasks.length;
    const activityValue =
      activityDenominator > 0
        ? Math.min(100, Math.round((completedTasksCount / activityDenominator) * 100))
        : totalActiveMinutes > 0
        ? Math.min(100, Math.round((totalActiveMinutes / 120) * 100))
        : null;

    // 2. LEARNING: curriculum units + learning objectives + learningEvidence (excludes tests & retention)
    const totalCurr = snap.curriculum.length;
    const completedCurr = snap.curriculum.filter((c) => c.completed).length;
    const totalObjs = snap.learningObjectives.length;
    const progressedObjs = snap.learningObjectives.filter(
      (o) => !['LOCKED', 'NOT_STARTED'].includes(o.status)
    ).length;
    const learningDenominator = totalCurr + totalObjs + learningEvidence.length;
    const learningNumerator = completedCurr + progressedObjs + learningEvidence.length;
    const learningValue =
      learningDenominator > 0
        ? Math.min(100, Math.round((learningNumerator / learningDenominator) * 100))
        : null;

    // 3. COMPETENCE: test_attempts + competenceEvidence minus open error penalty (null when denominator is 0!)
    const attemptsCount = snap.testAttempts.length;
    const competenceDenominator = attemptsCount + competenceEvidence.length;
    let competenceValue = null;
    if (competenceDenominator > 0) {
      const avgAttemptPerf =
        attemptsCount > 0
          ? snap.testAttempts.reduce(
              (s, a) => s + (Number(a.score || 0) * 0.6 + Number(a.accuracy || a.score || 0) * 0.4),
              0
            ) / attemptsCount
          : null;
      const avgCompEvPerf =
        competenceEvidence.length > 0
          ? competenceEvidence.reduce((s, e) => s + Number(e.qualityScore || 80), 0) /
            competenceEvidence.length
          : null;
      const rawComp =
        avgAttemptPerf !== null && avgCompEvPerf !== null
          ? avgAttemptPerf * 0.75 + avgCompEvPerf * 0.25
          : avgAttemptPerf !== null
          ? avgAttemptPerf
          : avgCompEvPerf;
      const openErrorsCount = snap.errors.filter((e) => e.status !== 'resolved').length;
      competenceValue = Math.max(0, Math.min(100, Math.round(rawComp - openErrorsCount * 8)));
    }

    // 4. MASTERY: current mastery state & gate satisfaction vs total skills/subskills
    const totalEntitiesForMastery = snap.skills.length + snap.subskills.length;
    const masteredSkillsCount = snap.skills.filter(
      (s) => s.status === 'MASTERED' || s.status === 'MAINTENANCE'
    ).length;
    const masteredSubsCount = snap.subskills.filter(
      (sub) => sub.masteryState === 'MASTERED' || sub.masteryState === 'MAINTENANCE'
    ).length;
    const historicalMasterySkillsCount = snap.skills.filter(
      (s) =>
        s.historicalMasteryAchieved ||
        s.status === 'MASTERED' ||
        s.status === 'MAINTENANCE'
    ).length;
    const masteryValue =
      totalEntitiesForMastery > 0
        ? Math.min(
            100,
            Math.round(((masteredSkillsCount + masteredSubsCount) / totalEntitiesForMastery) * 100)
          )
        : null;

    // 5. RETENTION: post-mastery reviews & retentionEvidence (null when 0 retention checks exist!)
    const retentionDenominator = snap.reviews.length + retentionEvidence.length;
    let retentionValue = null;
    if (retentionDenominator > 0) {
      const totalRetScore =
        snap.reviews.reduce((s, r) => s + Number(r.score || 0), 0) +
        retentionEvidence.reduce((s, e) => s + Number(e.qualityScore || 80), 0);
      retentionValue = Math.min(100, Math.round(totalRetScore / retentionDenominator));
    }

    // 6. CONSISTENCY: distinct active days with recorded work / total days in window
    const activeDatesSet = new Set(
      [
        ...snap.tasks
          .filter((t) => t.status === 'completed' || t.status === 'partially_completed')
          .map((t) => extractRecordDateStr(t)),
        ...snap.learningSessions.map((ls) => extractRecordDateStr(ls)),
        ...snap.performanceLogs.map((l) => extractRecordDateStr(l)),
        ...snap.testAttempts.map((a) => extractRecordDateStr(a)),
        ...snap.reviews.map((r) => extractRecordDateStr(r)),
      ].filter(Boolean)
    );
    let periodDays = 0;
    if (filters.startDate && filters.endDate) {
      periodDays = resolvePeriodBoundaries('custom', filters.startDate, filters.endDate).dayCount;
    } else if (activeDatesSet.size > 0) {
      const sortedDates = [...activeDatesSet].sort();
      periodDays = resolvePeriodBoundaries(
        'custom',
        sortedDates[0],
        sortedDates[sortedDates.length - 1]
      ).dayCount;
    }
    const consistencyValue =
      periodDays > 0
        ? Math.min(100, Math.round((activeDatesSet.size / periodDays) * 100))
        : null;

    // 7. WORKLOAD: actual minutes vs planned minutes
    const plannedMinutes = activeTasks.reduce(
      (s, t) => s + Number(t.plannedDurationMin || 0),
      0
    );
    const actualTaskMinutes = activeTasks
      .filter((t) => t.status === 'completed' || t.status === 'partially_completed')
      .reduce((s, t) => s + Number(t.actualDurationMin ?? t.plannedDurationMin ?? 0), 0);
    const effectiveActualMinutes = Math.max(actualTaskMinutes, loggedMinutesFromLogs);
    const workloadValue =
      plannedMinutes > 0
        ? Math.min(150, Math.round((effectiveActualMinutes / plannedMinutes) * 100))
        : null;

    // 8. ERRORS: resolved errors / total errors
    const totalErrors = snap.errors.length;
    const resolvedErrors = snap.errors.filter((e) => e.status === 'resolved').length;
    const openErrors = totalErrors - resolvedErrors;
    const errorsResolutionValue =
      totalErrors > 0 ? Math.round((resolvedErrors / totalErrors) * 100) : null;

    // 9. EXECUTION: completed tasks / total scheduled tasks
    const partialTasksCount = activeTasks.filter(
      (t) => t.status === 'partially_completed'
    ).length;
    const skippedTasksCount = activeTasks.filter((t) => t.status === 'skipped').length;
    const rescheduledTasksCount = snap.tasks.filter(
      (t) => Boolean(t.rescheduledFromTaskId || t.rescheduledFromDate)
    ).length;
    const executionValue =
      activeTasks.length > 0
        ? Math.round((completedTasksCount / activeTasks.length) * 100)
        : null;

    const dimensions = {
      activity: {
        ...NINE_DIMENSIONS_METADATA.activity,
        value: activityValue,
        numerator: completedTasksCount,
        denominator: activityDenominator,
        totalActiveMinutes,
        isDirectlyMeasured: activityDenominator > 0 || totalActiveMinutes > 0,
        statusLabel:
          activityValue === null ? 'Insufficient data (لا توجد مهام مسجلة)' : `${activityValue}%`,
      },
      learning: {
        ...NINE_DIMENSIONS_METADATA.learning,
        value: learningValue,
        numerator: learningNumerator,
        denominator: learningDenominator,
        completedSessionsCount: snap.learningSessions.length,
        progressedObjectivesCount: progressedObjs,
        isDirectlyMeasured: learningDenominator > 0,
        statusLabel:
          learningValue === null ? 'Insufficient data (لا توجد وحدات تعلم)' : `${learningValue}%`,
      },
      competence: {
        ...NINE_DIMENSIONS_METADATA.competence,
        value: competenceValue,
        numerator: attemptsCount,
        denominator: competenceDenominator,
        isDirectlyMeasured: competenceDenominator > 0,
        statusLabel:
          competenceValue === null
            ? 'Insufficient data (لم تُسجل اختبارات بعد)'
            : `${competenceValue}%`,
      },
      mastery: {
        ...NINE_DIMENSIONS_METADATA.mastery,
        value: masteryValue,
        numerator: masteredSkillsCount + masteredSubsCount,
        denominator: totalEntitiesForMastery,
        currentMasteredSkillsCount: masteredSkillsCount,
        historicalMasterySkillsCount,
        isDirectlyMeasured: totalEntitiesForMastery > 0,
        statusLabel:
          masteryValue === null
            ? 'Insufficient data (لا توجد مهارات مسجلة)'
            : `${masteryValue}%`,
      },
      retention: {
        ...NINE_DIMENSIONS_METADATA.retention,
        value: retentionValue,
        numerator: snap.reviews.filter((r) => r.passed !== false).length,
        denominator: retentionDenominator,
        isDirectlyMeasured: retentionDenominator > 0,
        statusLabel:
          retentionValue === null
            ? 'Insufficient data (لا توجد فحوصات احتفاظ)'
            : `${retentionValue}%`,
      },
      consistency: {
        ...NINE_DIMENSIONS_METADATA.consistency,
        value: consistencyValue,
        numerator: activeDatesSet.size,
        denominator: periodDays,
        activeDates: [...activeDatesSet].sort(),
        isDirectlyMeasured: periodDays > 0,
        statusLabel:
          consistencyValue === null
            ? 'Insufficient data (لا توجد أيام نشاط)'
            : `${consistencyValue}% (${activeDatesSet.size}/${periodDays} يوم)`,
      },
      workload: {
        ...NINE_DIMENSIONS_METADATA.workload,
        value: workloadValue,
        numerator: effectiveActualMinutes,
        denominator: plannedMinutes,
        plannedMinutes,
        actualMinutes: effectiveActualMinutes,
        isDirectlyMeasured: plannedMinutes > 0,
        statusLabel:
          workloadValue === null
            ? 'Insufficient data (لا يوجد حمل مخطط)'
            : `${workloadValue}% (${effectiveActualMinutes}/${plannedMinutes} د)`,
      },
      errors: {
        ...NINE_DIMENSIONS_METADATA.errors,
        value: errorsResolutionValue,
        numerator: resolvedErrors,
        denominator: totalErrors,
        openErrorsCount: openErrors,
        resolvedErrorsCount: resolvedErrors,
        isDirectlyMeasured: totalErrors > 0,
        statusLabel:
          errorsResolutionValue === null
            ? 'No recorded errors (0 أخطاء مسجلة)'
            : `${errorsResolutionValue}% محلول (${resolvedErrors}/${totalErrors})`,
      },
      execution: {
        ...NINE_DIMENSIONS_METADATA.execution,
        value: executionValue,
        numerator: completedTasksCount,
        denominator: activeTasks.length,
        completedTasksCount,
        partialTasksCount,
        skippedTasksCount,
        rescheduledTasksCount,
        isDirectlyMeasured: activeTasks.length > 0,
        statusLabel:
          executionValue === null
            ? 'Insufficient data (لا توجد مهام مجدولة)'
            : `${executionValue}% (${completedTasksCount}/${activeTasks.length} مكتمل)`,
      },
    };

    const evidencePartitionAudit = {
      totalEvidenceRecords: snap.evidence.length,
      learningEvidenceIds: learningEvidence.map((e) => e.id),
      competenceEvidenceIds: competenceEvidence.map((e) => e.id),
      retentionEvidenceIds: retentionEvidence.map((e) => e.id),
      zeroDoubleCountingVerified:
        learningEvidence.length + competenceEvidence.length + retentionEvidence.length ===
        snap.evidence.length,
    };

    return {
      dimensions,
      evidencePartitionAudit,
    };
  }

  // =========================================================================
  // 4C. SCHEDULING AND EXECUTION ANALYSIS
  // =========================================================================

  async analyzeSchedulingAndExecution(filters = {}) {
    const snap = await this._loadReadOnlySnapshot(filters);
    const activeTasks = snap.tasks.filter(
      (t) => t.status !== 'deferred' && t.status !== 'cancelled'
    );
    const deferredTasks = snap.tasks.filter((t) => t.status === 'deferred');

    const completed = activeTasks.filter((t) => t.status === 'completed');
    const partial = activeTasks.filter((t) => t.status === 'partially_completed');
    const skipped = activeTasks.filter((t) => t.status === 'skipped');
    const rescheduled = snap.tasks.filter(
      (t) => Boolean(t.rescheduledFromTaskId || t.rescheduledFromDate)
    );

    const plannedMinutes = activeTasks.reduce(
      (s, t) => s + Number(t.plannedDurationMin || 0),
      0
    );
    const completedOrPartialPlannedMin = [...completed, ...partial].reduce(
      (s, t) => s + Number(t.plannedDurationMin || 0),
      0
    );
    const actualMinutes = [...completed, ...partial].reduce(
      (s, t) => s + Number(t.actualDurationMin ?? t.plannedDurationMin ?? 0),
      0
    );

    const estimationVarianceMin =
      completed.length + partial.length > 0
        ? actualMinutes - completedOrPartialPlannedMin
        : null;
    const estimationErrorPct =
      completedOrPartialPlannedMin > 0
        ? Number(
            (((actualMinutes - completedOrPartialPlannedMin) / completedOrPartialPlannedMin) * 100).toFixed(1)
          )
        : null;

    // Group by date to analyze daily workload vs configured limits & overload patterns
    const tasksByDate = {};
    for (const t of activeTasks) {
      const d = t.date || extractRecordDateStr(t);
      if (!d) continue;
      if (!tasksByDate[d]) tasksByDate[d] = [];
      tasksByDate[d].push(t);
    }

    const dailyBreakdown = [];
    let overloadDaysCount = 0;
    let daysWithoutRecoveryCount = 0;
    let daysWherePlanningExceededActualCount = 0;

    for (const [dateStr, dayTasks] of Object.entries(tasksByDate).sort(([a], [b]) =>
      a.localeCompare(b)
    )) {
      const budget = calculateAvailableTimeAndBuffers(
        snap.scheduleConfig,
        dateStr,
        7,
        snap.timeBlocks.filter((b) => b.date === dateStr)
      );
      const check = validateWorkloadAndRecovery(dayTasks, budget, snap.scheduleConfig);
      const dayPlannedMin = dayTasks.reduce(
        (s, t) => s + Number(t.plannedDurationMin || 0),
        0
      );
      const dayActualMin = dayTasks
        .filter((t) => t.status === 'completed' || t.status === 'partially_completed')
        .reduce((s, t) => s + Number(t.actualDurationMin ?? t.plannedDurationMin ?? 0), 0);

      if (check.isOverloaded) overloadDaysCount++;
      if (!check.hasRecoveryTask && dayPlannedMin >= 90) daysWithoutRecoveryCount++;
      if (dayPlannedMin > 0 && dayActualMin < dayPlannedMin * 0.7) {
        daysWherePlanningExceededActualCount++;
      }

      dailyBreakdown.push({
        date: dateStr,
        isCollegeDay: budget.isCollegeDay,
        safeCeilingMin: budget.schedulableWorkMin,
        bufferMin: budget.bufferMin,
        plannedMinutes: dayPlannedMin,
        actualMinutes: dayActualMin,
        isOverloaded: check.isOverloaded,
        hasRecoveryTask: check.hasRecoveryTask,
        completedCount: dayTasks.filter((t) => t.status === 'completed').length,
        totalCount: dayTasks.length,
      });
    }

    // Recurring causes of missed/skipped/partial tasks
    const causeCounts = {};
    for (const t of [...skipped, ...partial]) {
      const diagCauses = t.diagnosis?.diagnosedCauses || [];
      if (diagCauses.length > 0) {
        for (const c of diagCauses) {
          const code = String(c).split(':')[0].trim();
          causeCounts[code] = (causeCounts[code] || 0) + 1;
        }
      } else if (t.skipReason) {
        causeCounts[t.skipReason] = (causeCounts[t.skipReason] || 0) + 1;
      } else {
        causeCounts.UNSPECIFIED_INTERRUPTION = (causeCounts.UNSPECIFIED_INTERRUPTION || 0) + 1;
      }
    }

    const recurringMissCauses = Object.entries(causeCounts)
      .map(([cause, count]) => ({ cause, count }))
      .sort((a, b) => b.count - a.count);

    // Performance differences across College Days vs Focus Days (only when >= 2 observations exist)
    const collegeDaysData = dailyBreakdown.filter((d) => d.isCollegeDay);
    const focusDaysData = dailyBreakdown.filter((d) => !d.isCollegeDay);
    const dayTypeComparison =
      collegeDaysData.length >= 1 && focusDaysData.length >= 1
        ? {
            status: 'MEASURED',
            collegeDayAvgActualMin: Math.round(
              collegeDaysData.reduce((s, d) => s + d.actualMinutes, 0) / collegeDaysData.length
            ),
            focusDayAvgActualMin: Math.round(
              focusDaysData.reduce((s, d) => s + d.actualMinutes, 0) / focusDaysData.length
            ),
          }
        : {
            status: 'INSUFFICIENT_DATA',
            reason: 'يتطلب بيانات تنفيذ في يوم كلية ويوم تركيز حر على الأقل للمقارنة.',
          };

    const planningExceedsDemonstratedCapacity =
      dailyBreakdown.length >= 2 &&
      daysWherePlanningExceededActualCount >= Math.ceil(dailyBreakdown.length * 0.6);

    // Recommendations that respect capacity, recovery, prerequisites, and NEVER recommend compensatory overloading!
    const recommendations = [];
    if (planningExceedsDemonstratedCapacity) {
      recommendations.push({
        type: 'REDUCE_PLANNED_LOAD_TO_CAPACITY',
        title: 'مواءمة التخطيط مع السعة الفعلية المثبتة (بدون تكديس تعويضي)',
        explanation:
          'يتجاوز الحمل المخطط السعة المنفذة فعلياً بشكل متكرر؛ يُوصى بخفض الدقائق المخططة يومياً بنسبة 20–25% وتثبيت 20% Buffer دون ترحيل عقابي للمهام الفائتة.',
      });
    }
    if (overloadDaysCount > 0) {
      recommendations.push({
        type: 'ELIMINATE_OVERLOAD',
        title: 'إزالة الحمل الزائد وحماية ساعات النوم',
        explanation: `تم رصد (${overloadDaysCount}) يوم يتجاوز السقف الآمن؛ يجب تأجيل المهام الثانوية بدلاً من تقليص النوم أو الاستشفاء.`,
      });
    }
    if (skipped.length > 0 || partial.length > 0) {
      recommendations.push({
        type: 'STEP_DOWN_TASK_GRANULARITY',
        title: 'تقليص حجم خطوة المهام المتعثرة (Micro-Sessions 25 د)',
        explanation:
          'بدلاً من مضاعفة حمل الغد لتعويض المهام المتخطاة، قم بتقسيم المهمة إلى جلسة قصيرة (25 دقيقة) ضمن السقف الطبيعي لليوم القادم.',
      });
    }

    return {
      plannedMinutes,
      actualMinutes,
      estimationVarianceMin,
      estimationErrorPct,
      counts: {
        totalScheduled: activeTasks.length,
        completed: completed.length,
        partiallyCompleted: partial.length,
        skipped: skipped.length,
        rescheduled: rescheduled.length,
        deferredForBufferProtection: deferredTasks.length,
      },
      rates: {
        completionRatePct:
          activeTasks.length > 0 ? Math.round((completed.length / activeTasks.length) * 100) : null,
        partialRatePct:
          activeTasks.length > 0 ? Math.round((partial.length / activeTasks.length) * 100) : null,
        skipRatePct:
          activeTasks.length > 0 ? Math.round((skipped.length / activeTasks.length) * 100) : null,
      },
      recurringMissCauses,
      overloadDaysCount,
      daysWithoutRecoveryCount,
      planningExceedsDemonstratedCapacity,
      dayTypeComparison,
      dailyBreakdown,
      recommendations,
    };
  }

  // =========================================================================
  // 4D. ERROR AND BOTTLENECK ANALYSIS (OBSERVED FACTS VS. HYPOTHESES)
  // =========================================================================

  async analyzeErrorsAndBottlenecks(filters = {}) {
    const snap = await this._loadReadOnlySnapshot(filters);
    const skillMap = {};
    for (const s of snap.allSkills) skillMap[s.id] = s;

    // 1. Recurring error categories
    const categoryCounts = {};
    for (const err of snap.errors) {
      const cat = err.taxonomyCategory || err.category || 'unknown_unclassified';
      categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;
    }
    const recurringErrorCategories = Object.entries(categoryCounts)
      .map(([category, count]) => ({ category, count }))
      .sort((a, b) => b.count - a.count);

    // 2. Unresolved errors
    const unresolvedErrors = snap.errors.filter((e) => e.status !== 'resolved');

    // 3. Skills with repeated errors
    const errorsBySkill = {};
    for (const err of snap.errors) {
      if (!errorsBySkill[err.skillId]) errorsBySkill[err.skillId] = [];
      errorsBySkill[err.skillId].push(err);
    }
    const skillsWithRepeatedErrors = [];
    for (const [sId, sErrs] of Object.entries(errorsBySkill)) {
      const maxFailures = sErrs.reduce((m, e) => Math.max(m, Number(e.failureCount || 1)), 0);
      if (sErrs.length >= 2 || maxFailures >= 2) {
        skillsWithRepeatedErrors.push({
          skillId: sId,
          skillName: skillMap[sId]?.nameAr || skillMap[sId]?.name || sId,
          totalErrorRecords: sErrs.length,
          unresolvedCount: sErrs.filter((e) => e.status !== 'resolved').length,
          maxFailureCount: maxFailures,
          categories: [...new Set(sErrs.map((e) => e.category))],
        });
      }
    }

    // 4. Remediation outcomes & retest comparisons
    const remediationOutcomes = [];
    for (const rem of snap.remediations) {
      const linkedErr = snap.allSkillErrors.find((e) => e.id === rem.errorId);
      const initialAttempt = linkedErr?.linkedTestAttemptId
        ? snap.allSkillTestAttempts.find((a) => a.id === linkedErr.linkedTestAttemptId)
        : null;
      const retestAttempts = snap.allSkillTestAttempts
        .filter((a) => a.remediationId === rem.id || (a.isRetest && a.linkedErrorId === rem.errorId))
        .sort((a, b) => String(a.timestamp).localeCompare(String(b.timestamp)));

      const latestRetest =
        retestAttempts.length > 0 ? retestAttempts[retestAttempts.length - 1] : null;
      const initialScore = initialAttempt ? Number(initialAttempt.score) : null;
      const retestScore = latestRetest ? Number(latestRetest.score) : null;
      const scoreDelta =
        initialScore !== null && retestScore !== null ? retestScore - initialScore : null;

      remediationOutcomes.push({
        remediationId: rem.id,
        errorId: rem.errorId,
        skillId: rem.skillId,
        skillName: skillMap[rem.skillId]?.nameAr || rem.skillId,
        remediationType: rem.remediationType || 'general',
        status: rem.status,
        initialScore,
        retestScore,
        scoreDelta,
        retestPassed: latestRetest ? Boolean(latestRetest.passed) : null,
        outcomeClassification: !latestRetest
          ? 'PENDING_RETEST'
          : latestRetest.passed && (scoreDelta === null || scoreDelta > 0)
          ? 'IMPROVED_AND_VERIFIED'
          : scoreDelta !== null && scoreDelta > 0
          ? 'PARTIAL_IMPROVEMENT_NOT_YET_PASSED'
          : 'NO_IMPROVEMENT_ESCALATION_NEEDED',
      });
    }

    // 5. Skills blocked by missing prerequisites
    const prerequisiteBlockedSkills = snap.skills
      .filter((s) => s.status === 'LOCKED' || (s.prerequisites || []).some((pId) => {
        const p = skillMap[pId];
        return !p || (p.status !== 'MASTERED' && p.status !== 'MAINTENANCE');
      }))
      .map((s) => ({
        skillId: s.id,
        skillName: s.nameAr || s.name,
        status: s.status,
        unmetPrerequisiteIds: (s.prerequisites || []).filter((pId) => {
          const p = skillMap[pId];
          return !p || (p.status !== 'MASTERED' && p.status !== 'MAINTENANCE');
        }),
      }));

    // 6. Skills with activity but insufficient assessment evidence
    const activityWithoutAssessmentSkills = [];
    for (const sk of snap.skills) {
      const skAttempts = snap.allSkillTestAttempts.filter((a) => a.skillId === sk.id);
      const skCompEv = snap.allSkillEvidence.filter(
        (e) =>
          e.skillId === sk.id &&
          (COMPETENCE_EVIDENCE_TYPES.includes(String(e.type || '').toLowerCase()) ||
            e.independentApplication)
      );
      const skTasksDone = snap.tasks.filter(
        (t) => t.skillId === sk.id && t.status === 'completed'
      ).length;
      const totalMinutes =
        (sk.metrics?.totalStudyMinutes || 0) + (sk.metrics?.totalPracticeMinutes || 0);

      if ((totalMinutes > 0 || skTasksDone > 0) && skAttempts.length === 0 && skCompEv.length === 0) {
        activityWithoutAssessmentSkills.push({
          skillId: sk.id,
          skillName: sk.nameAr || sk.name,
          totalPracticeAndStudyMinutes: totalMinutes,
          completedTasksCount: skTasksDone,
          testAttemptsCount: 0,
          warning:
            'يوجد نشاط ودقائق دراسة مسجلة، لكن لا يوجد أي اختبار أو دليل كفاءة تطبيقي لإثبات الفهم الفعلي.',
        });
      }
    }

    // 7. Skills whose recent performance or retention has deteriorated
    const deterioratedSkills = [];
    for (const sk of snap.skills) {
      const isRetentionDecay =
        sk.currentRetentionStatus === 'RETENTION_DECAY_RELEARNING';
      const skReviews = snap.allSkillReviews
        .filter((r) => r.skillId === sk.id)
        .sort((a, b) => String(a.reviewDate).localeCompare(String(b.reviewDate)));
      const failedLatestReview =
        skReviews.length > 0 && skReviews[skReviews.length - 1].passed === false;

      if (isRetentionDecay || failedLatestReview) {
        deterioratedSkills.push({
          skillId: sk.id,
          skillName: sk.nameAr || sk.name,
          historicalMasteryAchieved: Boolean(sk.historicalMasteryAchieved),
          currentRetentionStatus: sk.currentRetentionStatus,
          latestReviewScore:
            skReviews.length > 0 ? skReviews[skReviews.length - 1].score : null,
        });
      }
    }

    // 8. Bottlenecks affecting multiple downstream skills, subskills, objectives, or goals
    const downstreamBottlenecks = [];
    for (const sk of snap.allSkills) {
      if (sk.status === 'MASTERED' || sk.status === 'MAINTENANCE') continue;
      const dependentSkills = snap.allSkills.filter((other) =>
        (other.prerequisites || []).includes(sk.id)
      );
      const dependentGoals = snap.allGoals.filter(
        (g) => g.id === sk.goalId || g.capabilityId === sk.capabilityId
      );
      const skOpenErrors = unresolvedErrors.filter((e) => e.skillId === sk.id);

      if (dependentSkills.length > 0 || skOpenErrors.length > 0) {
        downstreamBottlenecks.push({
          bottleneckSkillId: sk.id,
          bottleneckSkillName: sk.nameAr || sk.name,
          status: sk.status,
          openErrorsCount: skOpenErrors.length,
          blockedDownstreamSkillIds: dependentSkills.map((d) => d.id),
          blockedDownstreamSkillNames: dependentSkills.map((d) => d.nameAr || d.name),
          affectedGoalIds: dependentGoals.map((g) => g.id),
          impactScore: dependentSkills.length * 30 + skOpenErrors.length * 20 + dependentGoals.length * 10,
        });
      }
    }
    downstreamBottlenecks.sort((a, b) => b.impactScore - a.impactScore);

    // Separate Observed Facts from Hypotheses with explicit supporting evidence & uncertainty
    const observedFacts = [];
    const inferredHypotheses = [];

    if (unresolvedErrors.length > 0) {
      observedFacts.push(
        `يوجد (${unresolvedErrors.length}) خطأ غير محلول مسجل في قاعدة البيانات.`
      );
    }
    if (prerequisiteBlockedSkills.length > 0) {
      observedFacts.push(
        `يوجد (${prerequisiteBlockedSkills.length}) مهارة مقفلة (LOCKED) لعدم استيفاء متطلباتها السابقة.`
      );
    }
    if (activityWithoutAssessmentSkills.length > 0) {
      observedFacts.push(
        `يوجد (${activityWithoutAssessmentSkills.length}) مهارة تحتوي على دقائق دراسة/نشاط ولكن بدون أي محاولة اختبار (0 Test Attempts).`
      );
      inferredHypotheses.push({
        hypothesis:
          'احتمال الاعتماد على الاستهلاك السلبي للمصادر أو التدريب غير المختبر دون قياس موضوعي للكفاءة.',
        supportingEvidence: activityWithoutAssessmentSkills.map(
          (s) => `${s.skillName}: ${s.totalPracticeAndStudyMinutes} دقيقة، 0 اختبارات`
        ),
        uncertaintyNote:
          'هذا استنتاج محتمل من غياب سجلات الاختبار وليس دليلاً قاطعاً على عدم الفهم؛ يتطلب إجراء اختبار تشخيصي للتحقق.',
      });
    }
    if (skillsWithRepeatedErrors.length > 0) {
      inferredHypotheses.push({
        hypothesis:
          'احتمال أن المهام التصحيحية السابقة لم تعالج السبب الجذري للخطأ أو تتطلب خفض حجم الخطوة التدريبية.',
        supportingEvidence: skillsWithRepeatedErrors.map(
          (s) => `${s.skillName}: ${s.totalErrorRecords} أخطاء (أقصى تكرار فشل: ${s.maxFailureCount})`
        ),
        uncertaintyNote:
          'الترابط بين تكرار الخطأ ونوع العلاج هو فرضية عمل ولا يثبت السببية بمفرده دون إعادة اختبار محققة.',
      });
    }

    return {
      skillsWithRepeatedErrors,
      recurringErrorCategories,
      unresolvedErrors,
      remediationOutcomes,
      prerequisiteBlockedSkills,
      activityWithoutAssessmentSkills,
      deterioratedSkills,
      downstreamBottlenecks,
      observedFacts,
      inferredHypotheses,
      hasSufficientDiagnosticEvidence:
        snap.errors.length > 0 || snap.testAttempts.length > 0 || snap.diagnosticAssessments.length > 0,
    };
  }

  // =========================================================================
  // 4E. GOAL AND TARGET ANALYSIS (PRESERVING AMBITIOUS TARGETS & HONEST FORECASTING)
  // =========================================================================

  async analyzeGoalsAndTargets(filters = {}) {
    const snap = await this._loadReadOnlySnapshot(filters);
    const goalAnalyses = [];

    for (const goal of snap.goals) {
      const linkedSkills = snap.allSkills.filter(
        (s) => s.goalId === goal.id || s.capabilityId === goal.capabilityId
      );
      const linkedObjectives = snap.allObjectives.filter(
        (o) => o.goalId === goal.id || o.capabilityId === goal.capabilityId
      );

      const missingPrerequisites = [];
      const stalledSkills = [];
      const evidenceGaps = [];

      for (const sk of linkedSkills) {
        if (sk.status === 'LOCKED') {
          missingPrerequisites.push({
            skillId: sk.id,
            skillName: sk.nameAr || sk.name,
            unmetPrerequisites: sk.prerequisites || [],
          });
        }
        const skAttempts = snap.allSkillTestAttempts.filter((a) => a.skillId === sk.id);
        const skErrors = snap.allSkillErrors.filter(
          (e) => e.skillId === sk.id && e.status !== 'resolved'
        );
        if (skErrors.length > 0) {
          stalledSkills.push({
            skillId: sk.id,
            skillName: sk.nameAr || sk.name,
            reason: `${skErrors.length} أخطاء مفتوحة تمنع عبور بوابة الإتقان`,
          });
        }
        const skEv = snap.allSkillEvidence.filter((e) => e.skillId === sk.id);
        const reqEv = sk.masteryCriteria?.requiredEvidenceCount || 1;
        if (skEv.length < reqEv || skAttempts.length === 0) {
          evidenceGaps.push({
            skillId: sk.id,
            skillName: sk.nameAr || sk.name,
            recordedEvidenceCount: skEv.length,
            requiredEvidenceCount: reqEv,
            recordedTestsCount: skAttempts.length,
          });
        }
      }

      // Defensible Completion Forecast check:
      // Requires >= 2 mastery/test observations across distinct dates with positive velocity.
      const goalHistoryDates = [
        ...snap.allSkillMasteryHistory
          .filter((mh) => linkedSkills.some((s) => s.id === mh.skillId))
          .map((mh) => extractRecordDateStr(mh)),
        ...snap.allSkillTestAttempts
          .filter((a) => a.passed && linkedSkills.some((s) => s.id === a.skillId))
          .map((a) => extractRecordDateStr(a)),
      ]
        .filter(Boolean)
        .sort();

      const uniqueProgressDates = [...new Set(goalHistoryDates)];
      const masteredCount = linkedSkills.filter(
        (s) => s.status === 'MASTERED' || s.status === 'MAINTENANCE'
      ).length;
      const totalRequired = Math.max(1, linkedSkills.length);
      const measuredMasteryRatioPct = Math.round((masteredCount / totalRequired) * 100);

      let completionForecast = {
        canForecast: false,
        status: 'INSUFFICIENT_DATA',
        estimatedCompletionDate: null,
        label: 'Insufficient data (بيانات تاريخية غير كافية للتنبؤ الموثوق بتاريخ الإنجاز)',
      };

      if (masteredCount === totalRequired && linkedSkills.length > 0) {
        completionForecast = {
          canForecast: true,
          status: 'TARGET_ACHIEVED',
          estimatedCompletionDate: uniqueProgressDates[uniqueProgressDates.length - 1] || null,
          label: 'تم تحقيق جميع المهارات المرتبطة بالهدف (Target Achieved)',
        };
      } else if (uniqueProgressDates.length >= 2 && masteredCount > 0) {
        const firstDate = uniqueProgressDates[0];
        const lastDate = uniqueProgressDates[uniqueProgressDates.length - 1];
        const elapsedDays = Math.max(
          1,
          Math.round(
            (Date.parse(`${lastDate}T12:00:00Z`) - Date.parse(`${firstDate}T12:00:00Z`)) /
              86400000
          )
        );
        const daysPerSkill = elapsedDays / masteredCount;
        const remainingSkills = totalRequired - masteredCount;
        const estRemainingDays = Math.ceil(daysPerSkill * remainingSkills);
        const estDate = addDaysToDate(lastDate, estRemainingDays);
        completionForecast = {
          canForecast: true,
          status: 'ESTIMATED_FROM_HISTORICAL_VELOCITY',
          estimatedCompletionDate: estDate,
          estimatedRemainingDays: estRemainingDays,
          label: `تقدير مبني على سرعة الإتقان المسجلة: ~${estRemainingDays} يوم (${estDate})`,
        };
      }

      goalAnalyses.push({
        goalId: goal.id,
        title: goal.title,
        status: goal.status,
        configuredTargetDate: goal.targetDate || null,
        configuredProgressPct: goal.progressPct,
        measuredSkillMasteryPct: measuredMasteryRatioPct,
        milestones: {
          totalSkills: linkedSkills.length,
          masteredSkills: masteredCount,
          totalObjectives: linkedObjectives.length,
          masteredObjectives: linkedObjectives.filter(
            (o) => o.status === 'MASTERED' || o.status === 'MAINTENANCE'
          ).length,
        },
        missingPrerequisites,
        stalledSkills,
        evidenceGaps,
        completionForecast,
      });
    }

    return {
      goals: goalAnalyses,
    };
  }

  // =========================================================================
  // 5. DAILY, WEEKLY, AND MONTHLY REVIEWS (LIVE DRAFT + PERSISTED HISTORY)
  // =========================================================================

  async generateReviewDraft(periodType = 'daily', referenceDate = '2026-10-14') {
    const bounds = resolvePeriodBoundaries(periodType, referenceDate);
    const filters = {
      startDate: bounds.startDate,
      endDate: bounds.endDate,
    };

    const snap = await this._loadReadOnlySnapshot(filters);
    const shared = { ...filters, _preloadedSnap: snap };
    const [nineDims, trends, execAnalysis, errorAnalysis, goalAnalysis] =
      await Promise.all([
        this.computeNineDimensions(shared),
        this.analyzeDevelopmentTrends(shared),
        this.analyzeSchedulingAndExecution(shared),
        this.analyzeErrorsAndBottlenecks(shared),
        this.analyzeGoalsAndTargets(shared),
      ]);

    const isEmptyPeriod =
      snap.tasks.length === 0 &&
      snap.evidence.length === 0 &&
      snap.testAttempts.length === 0 &&
      snap.learningSessions.length === 0 &&
      snap.reviews.length === 0 &&
      snap.errors.length === 0;

    const missingDataWarnings = [];
    if (isEmptyPeriod) {
      missingDataWarnings.push(
        `لا توجد سجلات تنفيذ أو تعلم أو تقييم محفوظة خلال الفترة (${bounds.startDate} → ${bounds.endDate}).`
      );
    }
    if (snap.testAttempts.length === 0) {
      missingDataWarnings.push(
        'لم يتم تسجيل أي اختبارات كفاءة (Test Attempts) خلال هذه الفترة.'
      );
    }
    if (snap.reviews.length === 0 && periodType !== 'daily') {
      missingDataWarnings.push(
        'لم يتم تسجيل فحوصات صيانة أو احتفاظ طويل المدى (Retention Reviews) خلال هذه الفترة.'
      );
    }

    const improvedSkills = trends.skills
      .filter((s) => s.recentTrend === 'IMPROVING' || s.currentMeasuredState.status === 'MASTERED')
      .map((s) => ({ id: s.id, name: s.name, status: s.currentMeasuredState.status }));

    const stagnatedOrRegressedSkills = trends.skills
      .filter(
        (s) =>
          s.recentTrend === 'DECLINING' ||
          s.currentMeasuredState.currentRetentionStatus === 'RETENTION_DECAY_RELEARNING'
      )
      .map((s) => ({ id: s.id, name: s.name, trend: s.recentTrend }));

    const snapshot = {
      periodType: bounds.periodType,
      periodKey: bounds.periodKey,
      startDate: bounds.startDate,
      endDate: bounds.endDate,
      dayCount: bounds.dayCount,
      isEmptyPeriod,
      missingDataWarnings,
      plannedVsCompleted: {
        plannedMinutes: execAnalysis.plannedMinutes,
        actualMinutes: execAnalysis.actualMinutes,
        scheduledTasksCount: execAnalysis.counts.totalScheduled,
        completedTasksCount: execAnalysis.counts.completed,
        partiallyCompletedCount: execAnalysis.counts.partiallyCompleted,
        skippedTasksCount: execAnalysis.counts.skipped,
        deferredForBufferCount: execAnalysis.counts.deferredForBufferProtection,
      },
      meaningfulEvidenceRecorded: snap.evidence.map((e) => ({
        id: e.id,
        skillId: e.skillId,
        type: e.type,
        title: e.title,
        qualityScore: e.qualityScore,
      })),
      missedOrPartialTasks: snap.tasks
        .filter((t) => t.status === 'skipped' || t.status === 'partially_completed')
        .map((t) => ({
          id: t.id,
          title: t.title,
          status: t.status,
          partialCompletionPct: t.partialCompletionPct,
          skipReason: t.skipReason,
          diagnosisSummary: t.diagnosis?.summaryText || null,
        })),
      errorsAndBlockers: errorAnalysis.unresolvedErrors.map((e) => ({
        id: e.id,
        skillId: e.skillId,
        category: e.category,
        severity: e.severity,
        description: e.description,
      })),
      remediationEffectiveness: errorAnalysis.remediationOutcomes,
      improvedSkills,
      stagnatedOrRegressedSkills,
      retentionAndMasterySustained: {
        masteredSkillsCount: nineDims.dimensions.mastery.currentMasteredSkillsCount,
        historicalMasteryCount: nineDims.dimensions.mastery.historicalMasterySkillsCount,
        retentionScorePct: nineDims.dimensions.retention.value,
        deterioratedSkillsCount: errorAnalysis.deterioratedSkills.length,
      },
      longTermBottlenecks: errorAnalysis.downstreamBottlenecks.slice(0, 5),
      goalProgressSummary: goalAnalysis.goals.map((g) => ({
        goalId: g.goalId,
        title: g.title,
        configuredProgressPct: g.configuredProgressPct,
        measuredSkillMasteryPct: g.measuredSkillMasteryPct,
        forecastLabel: g.completionForecast.label,
      })),
      recommendedNextPriorities: [
        ...errorAnalysis.unresolvedErrors.slice(0, 2).map(
          (e) => `إغلاق الخطأ المفتوح (${e.category}): ${e.description}`
        ),
        ...errorAnalysis.downstreamBottlenecks.slice(0, 2).map(
          (b) => `فك اختناق المهارة المتطلبة: ${b.bottleneckSkillName} (تفتح ${b.blockedDownstreamSkillIds.length} مهارات تالية)`
        ),
        ...execAnalysis.recommendations.map((r) => r.title),
      ],
    };

    return {
      periodType: bounds.periodType,
      periodKey: bounds.periodKey,
      startDate: bounds.startDate,
      endDate: bounds.endDate,
      snapshot,
    };
  }

  /**
   * Persists a Daily, Weekly, or Monthly review in `periodic_reviews` store.
   * Preserves historical reviews rather than overwriting them (each saved review has a unique ID
   * and immutable period snapshot, plus user-authored notes, decisions, and nextActions).
   */
  async savePeriodicReview(payload = {}) {
    const {
      periodType = 'daily',
      referenceDate = '2026-10-14',
      userNotes = '',
      decisions = [],
      nextActions = [],
    } = payload;

    const draft = await this.generateReviewDraft(periodType, referenceDate);
    const existingForPeriod = await this.db.queryByField(
      'periodic_reviews',
      'periodKey',
      draft.periodKey
    );
    const revisionNumber = existingForPeriod.length + 1;
    const nowIso = new Date().toISOString();

    const normalizedDecisions = Array.isArray(decisions)
      ? decisions
      : String(decisions || '')
          .split(/\n|[،,]/)
          .map((s) => s.trim())
          .filter(Boolean);

    const normalizedNextActions = Array.isArray(nextActions)
      ? nextActions
      : String(nextActions || '')
          .split(/\n|[،,]/)
          .map((s) => s.trim())
          .filter(Boolean);

    const record = {
      id:
        payload.id ||
        `prev_${draft.periodKey}_v${revisionNumber}_${Date.now()}_${Math.random()
          .toString(36)
          .slice(2, 5)}`,
      periodType: draft.periodType,
      periodKey: draft.periodKey,
      startDate: draft.startDate,
      endDate: draft.endDate,
      revisionNumber,
      userNotes: String(userNotes || '').trim(),
      decisions: normalizedDecisions,
      nextActions: normalizedNextActions,
      snapshot: draft.snapshot,
      createdAt: payload.createdAt || nowIso,
    };

    return this.db.put('periodic_reviews', record);
  }

  async getPeriodicReviews(periodType = null) {
    const all = await this.db.getAll('periodic_reviews');
    const filtered = periodType ? all.filter((r) => r.periodType === periodType) : all;
    return filtered.sort((a, b) =>
      String(b.createdAt || '').localeCompare(String(a.createdAt || ''))
    );
  }

  // =========================================================================
  // 6 & 7. COMPREHENSIVE ANALYTICS BUNDLE & PRACTICAL REPORT EXPORTS (JSON, CSV, MARKDOWN)
  // =========================================================================

  async getComprehensiveAnalyticsReport(filters = {}) {
    const referenceDate = filters.referenceDate || filters.endDate || '2026-10-14';
    const baseSnap = await this._loadReadOnlySnapshot(filters);
    const sharedFilters = { ...filters, _preloadedSnap: baseSnap };
    const [
      nineDims,
      developmentTrends,
      schedulingAnalysis,
      errorAndBottleneckAnalysis,
      goalAndTargetAnalysis,
      dailyDraft,
      weeklyDraft,
      monthlyDraft,
      savedReviews,
    ] = await Promise.all([
      this.computeNineDimensions(sharedFilters),
      this.analyzeDevelopmentTrends(sharedFilters),
      this.analyzeSchedulingAndExecution(sharedFilters),
      this.analyzeErrorsAndBottlenecks(sharedFilters),
      this.analyzeGoalsAndTargets(sharedFilters),
      this.generateReviewDraft('daily', referenceDate),
      this.generateReviewDraft('weekly', referenceDate),
      this.generateReviewDraft('monthly', referenceDate),
      this.getPeriodicReviews(),
    ]);

    const dataLimitations = [
      'جميع المؤشرات مشتقة حصرياً من السجلات المحفوظة فعلياً في قاعدة البيانات دون أي تقديرات مصطنعة.',
      'المقاييس التي يكون مقامها صفراً (مثل عدم وجود اختبارات أو فحوصات احتفاظ) تُرجع null (Insufficient data) بدلاً من نسب مئوية مضللة.',
      'الأسباب الجذرية المقترحة للأخطاء أو التعثر تمثل فرضيات مدعومة بالأدلة المتاحة وليست علاقة سببية قطعية.',
    ];

    return {
      generatedAt: new Date().toISOString(),
      referenceDate,
      filtersApplied: {
        startDate: filters.startDate || null,
        endDate: filters.endDate || null,
        goalId: filters.goalId || null,
        capabilityId: filters.capabilityId || null,
        skillId: filters.skillId || null,
      },
      isEmptyDatabase: developmentTrends.isEmpty,
      metricDefinitions: NINE_DIMENSIONS_METADATA,
      dataLimitations,
      nineDimensions: nineDims.dimensions,
      evidencePartitionAudit: nineDims.evidencePartitionAudit,
      developmentTrends,
      schedulingAnalysis,
      errorAndBottleneckAnalysis,
      goalAndTargetAnalysis,
      reviewDrafts: {
        daily: dailyDraft,
        weekly: weeklyDraft,
        monthly: monthlyDraft,
      },
      savedPeriodicReviews: savedReviews,
    };
  }

  async exportReportJSON(filters = {}) {
    const report = await this.getComprehensiveAnalyticsReport(filters);
    return JSON.stringify(report, null, 2);
  }

  async exportReportCSV(filters = {}) {
    const report = await this.getComprehensiveAnalyticsReport(filters);
    const rows = [];

    // Header Row
    rows.push(
      [
        'Section',
        'EntityIdOrKey',
        'NameOrLabel',
        'StatusOrTrend',
        'ValueOrScore',
        'Unit',
        'Numerator',
        'Denominator',
        'Target',
        'NotesAndLimitations',
      ]
        .map(escapeCsvCell)
        .join(',')
    );

    // Metadata Row
    rows.push(
      [
        'REPORT_METADATA',
        'phase6_analytics',
        'WHITE ROOM OS Phase 6 Analytics Report',
        report.isEmptyDatabase ? 'EMPTY_DATABASE' : 'ACTIVE_DATA',
        '',
        '',
        '',
        '',
        `${report.filtersApplied.startDate || 'ALL'}..${report.filtersApplied.endDate || 'ALL'}`,
        report.dataLimitations.join(' | '),
      ]
        .map(escapeCsvCell)
        .join(',')
    );

    // 1. 9 Dimensions Rows
    for (const dim of Object.values(report.nineDimensions)) {
      rows.push(
        [
          'DIMENSION_METRIC',
          dim.key,
          dim.labelAr,
          dim.statusLabel,
          dim.value !== null ? dim.value : 'INSUFFICIENT_DATA',
          dim.unit,
          dim.numerator,
          dim.denominator,
          100,
          `${dim.definition} [Exclusions: ${dim.exclusions}]`,
        ]
          .map(escapeCsvCell)
          .join(',')
      );
    }

    // 2. Skill Trends Rows
    for (const sk of report.developmentTrends.skills) {
      rows.push(
        [
          'SKILL_TREND',
          sk.id,
          sk.name,
          `${sk.currentMeasuredState.status} (${sk.recentTrend})`,
          sk.currentMeasuredState.directlyMeasuredScore !== null
            ? sk.currentMeasuredState.directlyMeasuredScore
            : 'UNMEASURED',
          '%',
          sk.observationCount,
          2,
          `Lv ${sk.configuredTarget.targetLevel} (${sk.configuredTarget.minTestScore}%)`,
          sk.evidenceSufficiency.reason,
        ]
          .map(escapeCsvCell)
          .join(',')
      );
    }

    // 3. Goal Analysis Rows
    for (const g of report.goalAndTargetAnalysis.goals) {
      rows.push(
        [
          'GOAL_ANALYSIS',
          g.goalId,
          g.title,
          g.status,
          g.measuredSkillMasteryPct,
          '%',
          g.milestones.masteredSkills,
          g.milestones.totalSkills,
          g.configuredTargetDate || 'No Deadline',
          g.completionForecast.label,
        ]
          .map(escapeCsvCell)
          .join(',')
      );
    }

    // 4. Unresolved Errors Rows
    for (const err of report.errorAndBottleneckAnalysis.unresolvedErrors) {
      rows.push(
        [
          'UNRESOLVED_ERROR',
          err.id,
          err.description,
          err.status,
          err.failureCount || 1,
          'failures',
          '',
          '',
          '0 open errors',
          `Category: ${err.category} | Severity: ${err.severity}`,
        ]
          .map(escapeCsvCell)
          .join(',')
      );
    }

    return rows.join('\n');
  }

  async exportReportMarkdown(filters = {}) {
    const report = await this.getComprehensiveAnalyticsReport(filters);
    const periodLabel =
      report.filtersApplied.startDate || report.filtersApplied.endDate
        ? `${report.filtersApplied.startDate || 'البداية'} → ${report.filtersApplied.endDate || 'الآن'}`
        : `شامل حتى ${report.referenceDate}`;

    const lines = [
      `# WHITE ROOM OS — تقرير التحليلات والأداء والمراجعات (Phase 6)`,
      `- **تاريخ التوليد (Generated At):** ${report.generatedAt}`,
      `- **نطاق التقرير (Report Period):** ${periodLabel}`,
      `- **حالة قاعدة البيانات:** ${report.isEmptyDatabase ? 'فارغة (Empty State)' : 'بيانات فعلية موثقة'}`,
      `- **التحقق من عدم ازدواجية عدّ الأدلة (Zero Double-Counting):** ${
        report.evidencePartitionAudit.zeroDoubleCountingVerified ? 'VERIFIED ✅' : 'CHECK'
      }`,
      ``,
      `## 1. المقاييس التسعة المستقلة (9 Performance Dimensions)`,
      `| المقياس | القيمة | البسط / المقام | التعريف والقيود |`,
      `| :--- | :--- | :--- | :--- |`,
    ];

    for (const dim of Object.values(report.nineDimensions)) {
      lines.push(
        `| **${dim.labelAr}** | ${dim.statusLabel} | ${dim.numerator} / ${dim.denominator} | ${dim.definition} |`
      );
    }

    lines.push(``, `## 2. اتجاهات تطور المهارات (Skill Development Trends)`);
    if (report.developmentTrends.skills.length === 0) {
      lines.push(`- لا توجد مهارات مطابقة للنطاق المحدد.`);
    } else {
      lines.push(`| المهارة | الحالة | الدرجة المقاسة | خط الأساس والتغير | الاتجاه الحديث | كفاية الأدلة |`);
      lines.push(`| :--- | :--- | :--- | :--- | :--- | :--- |`);
      for (const sk of report.developmentTrends.skills) {
        const baseStr = sk.baseline
          ? `${sk.baseline.value}% (${sk.changeSinceBaseline !== null ? (sk.changeSinceBaseline >= 0 ? '+' : '') + sk.changeSinceBaseline + '%' : 'قياس وحيد'})`
          : 'لا يوجد خط أساس';
        lines.push(
          `| **${sk.name}** | ${sk.currentMeasuredState.status} | ${
            sk.currentMeasuredState.directlyMeasuredScore !== null
              ? sk.currentMeasuredState.directlyMeasuredScore + '%'
              : 'غير مقاس بعد'
          } | ${baseStr} | ${sk.recentTrend} | ${sk.evidenceSufficiency.status} (${sk.observationCount}) |`
        );
      }
    }

    lines.push(``, `## 3. تحليل الجدولة والتنفيذ والحمل (Scheduling & Execution)`);
    lines.push(
      `- **الدقائق المخططة مقابل الفعلية:** ${report.schedulingAnalysis.actualMinutes} د فعلي / ${report.schedulingAnalysis.plannedMinutes} د مخطط`
    );
    lines.push(
      `- **توزيع حالات المهام:** مكتمل (${report.schedulingAnalysis.counts.completed}) • جزئي (${report.schedulingAnalysis.counts.partiallyCompleted}) • متخطى (${report.schedulingAnalysis.counts.skipped}) • معاد جدولته (${report.schedulingAnalysis.counts.rescheduled})`
    );
    lines.push(
      `- **أيام الحمل الزائد (Overload Days):** ${report.schedulingAnalysis.overloadDaysCount}`
    );

    lines.push(``, `## 4. الاختناقات والأخطاء المفتوحة (Errors & Bottlenecks)`);
    if (report.errorAndBottleneckAnalysis.downstreamBottlenecks.length === 0) {
      lines.push(`- لا توجد اختناقات حرجة حالياً.`);
    } else {
      for (const b of report.errorAndBottleneckAnalysis.downstreamBottlenecks) {
        lines.push(
          `- **اختناق:** ${b.bottleneckSkillName} (${b.status}) — يوقف (${b.blockedDownstreamSkillIds.length}) مهارات تالية، أخطاء مفتوحة: ${b.openErrorsCount}`
        );
      }
    }

    lines.push(``, `## 5. تحليل الأهداف طويلة المدى (Goals & Targets)`);
    for (const g of report.goalAndTargetAnalysis.goals) {
      lines.push(
        `- **${g.title}** (${g.status}): إتقان المهارات المرتبطة ${g.milestones.masteredSkills}/${g.milestones.totalSkills} (${g.measuredSkillMasteryPct}%) — التوقع: ${g.completionForecast.label}`
      );
    }

    lines.push(``, `## 6. القيود المنهجية (Data Limitations)`);
    for (const lim of report.dataLimitations) {
      lines.push(`- ${lim}`);
    }

    return lines.join('\n');
  }
}
