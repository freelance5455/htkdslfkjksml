/**
 * WHITE ROOM OS — Backup & Restore Engine (Supports v1 and v2 schemas)
 * Exports deterministic, versioned JSON snapshots of all IndexedDB stores
 * and validates/normalizes schema integrity before restoring.
 */

import { DB_NAME, DB_VERSION, ALL_STORES_SCHEMAS } from '../core/db.js';
import { validateEntity } from '../core/schema.js';

export function computeSimpleChecksum(str) {
  let hash = 2166136261;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

export class BackupRestoreEngine {
  constructor(db) {
    this.db = db;
  }

  async exportBackup() {
    await this.db.open();
    const storesData = {};
    let totalRecords = 0;

    for (const storeName of Object.keys(ALL_STORES_SCHEMAS)) {
      const records = await this.db.getAll(storeName);
      storesData[storeName] = records;
      totalRecords += records.length;
    }

    const payloadJson = JSON.stringify(storesData);
    const checksum = computeSimpleChecksum(payloadJson);

    return {
      magic: 'WHITE_ROOM_OS_BACKUP',
      schemaVersion: DB_VERSION,
      dbName: DB_NAME,
      exportedAt: new Date().toISOString(),
      totalRecords,
      checksum,
      stores: storesData,
    };
  }

  validateBackupBundle(bundle) {
    if (!bundle || typeof bundle !== 'object') {
      throw new Error('Backup bundle must be a valid JSON object');
    }
    if (bundle.magic !== 'WHITE_ROOM_OS_BACKUP') {
      throw new Error('Invalid backup header: magic must be WHITE_ROOM_OS_BACKUP');
    }
    if (!bundle.stores || typeof bundle.stores !== 'object') {
      throw new Error('Backup bundle is missing stores object');
    }
    if (typeof bundle.schemaVersion !== 'number' || bundle.schemaVersion < 1 || bundle.schemaVersion > DB_VERSION) {
      throw new Error(
        `Unsupported schemaVersion: ${bundle.schemaVersion} (supported: 1..${DB_VERSION})`
      );
    }

    // Verify checksum if provided
    if (bundle.checksum) {
      const actualChecksum = computeSimpleChecksum(JSON.stringify(bundle.stores));
      if (actualChecksum !== bundle.checksum) {
        throw new Error(
          `Backup checksum mismatch: expected ${bundle.checksum}, got ${actualChecksum}`
        );
      }
    }

    // Pre-validate every record in every known store BEFORE touching the database
    for (const [storeName, records] of Object.entries(bundle.stores)) {
      if (!ALL_STORES_SCHEMAS[storeName]) continue;
      if (!Array.isArray(records)) {
        throw new Error(`Store ${storeName} in backup must be an array`);
      }
      for (const rec of records) {
        validateEntity(storeName, rec);
      }
    }

    return true;
  }

  async restoreBackup(bundle, options = { clearExisting: true }) {
    this.validateBackupBundle(bundle);
    await this.db.open();

    if (options.clearExisting) {
      await this.db.clearAll();
    }

    let restoredCount = 0;
    for (const [storeName, records] of Object.entries(bundle.stores)) {
      if (!ALL_STORES_SCHEMAS[storeName]) continue;
      if (records.length > 0) {
        await this.db.bulkPut(storeName, records);
        restoredCount += records.length;
      }
    }

    return {
      restoredAt: new Date().toISOString(),
      restoredCount,
      schemaVersion: bundle.schemaVersion,
    };
  }
}
