/**
 * WHITE ROOM OS — Pure Priority, Eligibility, Time-Block & Adaptive Rescheduling Domain Functions (Phase 4)
 * 100% pure, deterministic functions independent of UI and database persistence.
 *
 * Documented Priority Factors & Default Weights (Sum = 1.00):
 *  1. strategicImportance (0.18): Alignment with active Long-Term Goals & Vision priority
 *  2. prerequisiteBlocking (0.16): Number of downstream skills, subskills, or objectives unlocked by this item
 *  3. criticalErrorUrgency (0.18): Unresolved critical/high errors, active remediation tasks, or ready retests
 *  4. overdueReviewUrgency (0.14): Overdue spaced-repetition flashcards & retention reviews
 *  5. deadlineUrgency (0.10): Proximity to goal or test target dates
 *  6. learningPathRelevance (0.10): Active step on a current Learning Path
 *  7. weaknessAndBenefit (0.08): Competence/mastery gap and expected skill gain
 *  8. energyAndDurationFit (0.06): Match between task difficulty/duration and available energy/window
 *
 * Note: Heuristic scores are decision-support rankings, not absolute measures of human value.
 */

import { getDayNameFromDateString, parseTimeHHMM } from './timeEngine.js';

export const DEFAULT_PRIORITY_WEIGHTS = Object.freeze({
  strategicImportance: 0.18,
  prerequisiteBlocking: 0.16,
  criticalErrorUrgency: 0.18,
  overdueReviewUrgency: 0.14,
  deadlineUrgency: 0.10,
  learningPathRelevance: 0.10,
  weaknessAndBenefit: 0.08,
  energyAndDurationFit: 0.06,
});

export function timeStringToMinutes(hhmm) {
  const [h, m] = String(hhmm || '00:00').split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function minutesToTimeString(totalMinutes) {
  const clamped = Math.max(0, Math.min(23 * 60 + 59, Math.round(totalMinutes)));
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function addDaysToDate(dateStr, daysOffset) {
  const [y, m, d] = String(dateStr).split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  dt.setUTCDate(dt.getUTCDate() + Number(daysOffset || 0));
  return dt.toISOString().slice(0, 10);
}

/**
 * 1. PURE ELIGIBILITY CHECK
 * Verifies whether a candidate task's linked Skill, Subskill, and LearningObjective prerequisites are satisfied.
 */
export function checkCandidateEligibility(candidate, context = {}) {
  const { skillsMap = {}, subskillsMap = {}, objectivesMap = {} } = context;
  const blockingIds = [];
  const reasons = [];

  if (candidate.skillId && skillsMap[candidate.skillId]) {
    const skill = skillsMap[candidate.skillId];
    if (skill.status === 'LOCKED') {
      blockingIds.push(skill.id);
      reasons.push(`المهارة "${skill.nameAr || skill.name}" مقفلة (LOCKED) لعدم إتقان متطلباتها السابقة`);
    }
    for (const prereqId of skill.prerequisites || []) {
      const pSkill = skillsMap[prereqId];
      if (pSkill && pSkill.status !== 'MASTERED' && pSkill.status !== 'MAINTENANCE') {
        blockingIds.push(prereqId);
        reasons.push(`يتطلب إتقان المهارة السابقة: ${pSkill.nameAr || pSkill.name}`);
      }
    }
  }

  if (candidate.subskillId && subskillsMap[candidate.subskillId]) {
    const sub = subskillsMap[candidate.subskillId];
    if (sub.masteryState === 'LOCKED') {
      blockingIds.push(sub.id);
      reasons.push(`المهارة الفرعية "${sub.name}" مقفلة (LOCKED)`);
    }
    for (const prereqSubId of sub.prerequisites || []) {
      const pSub = subskillsMap[prereqSubId];
      if (pSub && pSub.masteryState !== 'MASTERED' && pSub.masteryState !== 'MAINTENANCE') {
        blockingIds.push(prereqSubId);
        reasons.push(`يتطلب إتقان المهارة الفرعية السابقة: ${pSub.name}`);
      }
    }
  }

  if (candidate.objectiveId && objectivesMap[candidate.objectiveId]) {
    const obj = objectivesMap[candidate.objectiveId];
    if (obj.status === 'LOCKED') {
      blockingIds.push(obj.id);
      reasons.push(`الهدف التعلمي "${obj.title}" مقفل (LOCKED)`);
    }
    for (const prereqObjId of obj.prerequisites || []) {
      const pObj = objectivesMap[prereqObjId];
      if (pObj && pObj.status !== 'MASTERED' && pObj.status !== 'MAINTENANCE') {
        blockingIds.push(prereqObjId);
        reasons.push(`يتطلب إتقان الهدف التعلمي السابق: ${pObj.title}`);
      }
    }
  }

  const uniqueBlocking = [...new Set(blockingIds)];
  const eligible = uniqueBlocking.length === 0;

  return {
    eligible,
    prerequisiteStatus: eligible ? 'SATISFIED' : 'BLOCKED',
    blockingIds: uniqueBlocking,
    reason: eligible
      ? 'جميع المتطلبات السابقة مستوفاة (Prerequisites Satisfied)'
      : reasons.join(' | '),
  };
}

/**
 * 2. PURE DETERMINISTIC PRIORITY SCORING ENGINE
 * Computes a transparent 0..100 priority score with documented factor contributions and human-readable explanations.
 */
export function calculatePriorityScore(candidate, context = {}, customWeights = {}) {
  const weights = { ...DEFAULT_PRIORITY_WEIGHTS, ...customWeights };
  const {
    skillsMap = {},
    goalsMap = {},
    errorsMap = {},
    allSkills = [],
    allSubskills = [],
    allObjectives = [],
    learningPaths = [],
    currentDate = '2026-10-14',
    energyLevel = 7,
    availableNetMin = 180,
  } = context;

  const skill = candidate.skillId ? skillsMap[candidate.skillId] : null;
  const goal =
    (skill?.goalId && goalsMap[skill.goalId]) ||
    Object.values(goalsMap).find((g) => g.capabilityId === skill?.capabilityId) ||
    null;

  // Factor 1: Strategic Importance (0..100)
  const skillPriorityRank = Number(skill?.priority || candidate.priority || 2);
  const goalActiveBoost = goal?.status === 'active' ? 25 : 10;
  const strategicImportance = Math.min(
    100,
    Math.max(20, (6 - skillPriorityRank) * 15 + goalActiveBoost)
  );

  // Factor 2: Prerequisite Blocking Power (0..100)
  const unlockedSkillsCount = allSkills.filter((s) =>
    (s.prerequisites || []).includes(candidate.skillId)
  ).length;
  const unlockedSubsCount = candidate.subskillId
    ? allSubskills.filter((sub) => (sub.prerequisites || []).includes(candidate.subskillId)).length
    : 0;
  const unlockedObjsCount = candidate.objectiveId
    ? allObjectives.filter((o) => (o.prerequisites || []).includes(candidate.objectiveId)).length
    : 0;
  const totalDependents = unlockedSkillsCount + unlockedSubsCount + unlockedObjsCount;
  const prerequisiteBlocking = Math.min(
    100,
    totalDependents * 35 + (candidate.category === 'Primary' || candidate.category === 'Remediation' ? 25 : 0)
  );

  // Factor 3: Critical Error & Remediation Urgency (0..100)
  let criticalErrorUrgency = 0;
  const linkedErr = candidate.errorId ? errorsMap[candidate.errorId] : null;
  const skillOpenErrors = Object.values(errorsMap).filter(
    (e) => e.skillId === candidate.skillId && e.status !== 'resolved'
  );
  if (candidate.isCorrective || candidate.category === 'Remediation' || linkedErr) {
    const sev = linkedErr?.severity || 'high';
    criticalErrorUrgency = sev === 'critical' ? 100 : sev === 'high' ? 96 : 85;
  } else if (candidate.isRetestReady) {
    criticalErrorUrgency = 98;
  } else if (skillOpenErrors.length > 0) {
    criticalErrorUrgency = Math.min(80, 40 + skillOpenErrors.length * 15);
  }

  // Factor 4: Overdue Spaced-Repetition / Retention Review Urgency (0..100)
  let overdueReviewUrgency = 0;
  if (candidate.category === 'Reviews' || candidate.isOverdueReview || candidate.category === 'Maintenance') {
    const daysOverdue = Number(candidate.daysOverdue ?? 1);
    overdueReviewUrgency = Math.min(92, 60 + daysOverdue * 8);
  }

  // Factor 5: Deadline Urgency (0..100)
  let deadlineUrgency = 30;
  const targetDateStr = candidate.deadline || goal?.targetDate || null;
  if (targetDateStr && /^\d{4}-\d{2}-\d{2}$/.test(targetDateStr)) {
    const daysLeft = Math.max(
      1,
      Math.round((Date.parse(targetDateStr) - Date.parse(currentDate)) / 86400000)
    );
    deadlineUrgency = daysLeft <= 7 ? 95 : daysLeft <= 30 ? 75 : daysLeft <= 90 ? 55 : 35;
  }

  // Factor 6: Learning Path & Skill Relevance (0..100)
  const isOnActivePath = learningPaths.some(
    (lp) =>
      lp.skillId === candidate.skillId ||
      (candidate.objectiveId && (lp.objectiveIds || []).includes(candidate.objectiveId))
  );
  const learningPathRelevance = isOnActivePath ? 88 : candidate.category === 'Primary' ? 75 : 45;

  // Factor 7: Current Weakness & Expected Benefit (0..100)
  const levelGap = skill ? Math.max(1, skill.targetLevel - skill.currentLevel) : 3;
  const competenceGap = skill?.progress ? Math.max(0, 100 - (skill.progress.competence || 0)) : 50;
  const weaknessAndBenefit = Math.min(100, Math.round(levelGap * 10 + competenceGap * 0.45));

  // Factor 8: Energy & Duration Fit (0..100)
  const taskDiff = Number(candidate.difficulty || 5);
  const durationMin = Number(candidate.plannedDurationMin || 35);
  const energyDelta = Math.abs(energyLevel - taskDiff);
  const fitsTime = durationMin <= availableNetMin ? 30 : 0;
  const energyAndDurationFit = Math.max(
    10,
    Math.min(100, Math.round(70 - energyDelta * 8 + fitsTime))
  );

  const factors = {
    strategicImportance,
    prerequisiteBlocking,
    criticalErrorUrgency,
    overdueReviewUrgency,
    deadlineUrgency,
    learningPathRelevance,
    weaknessAndBenefit,
    energyAndDurationFit,
  };

  let weightedSum =
    factors.strategicImportance * weights.strategicImportance +
    factors.prerequisiteBlocking * weights.prerequisiteBlocking +
    factors.criticalErrorUrgency * weights.criticalErrorUrgency +
    factors.overdueReviewUrgency * weights.overdueReviewUrgency +
    factors.deadlineUrgency * weights.deadlineUrgency +
    factors.learningPathRelevance * weights.learningPathRelevance +
    factors.weaknessAndBenefit * weights.weaknessAndBenefit +
    factors.energyAndDurationFit * weights.energyAndDurationFit;

  // Critical blocker boost: active remediation / ready retest for an unresolved error blocks mastery gates directly
  if (candidate.category === 'Remediation' || candidate.isCorrective || candidate.isRetestReady) {
    weightedSum += 18;
  }

  const rawNormalized =
    candidate.category === 'Recovery'
      ? Math.max(62, Math.round(weightedSum))
      : Math.round(weightedSum);

  const priorityScore = Math.max(1, Math.min(100, rawNormalized));
  const priorityRank =
    priorityScore >= 80
      ? 1
      : priorityScore >= 65
      ? 2
      : priorityScore >= 50
      ? 3
      : priorityScore >= 35
      ? 4
      : 5;

  const topReasons = [];
  if (criticalErrorUrgency >= 75) {
    topReasons.push('يعالج خطأً حرجاً/مفتوحاً يمنع عبور بوابة الإتقان');
  }
  if (prerequisiteBlocking >= 35) {
    topReasons.push(`يفتح ${totalDependents} مهارة/هدفاً تالياً يعتمد عليه كمتطلب سابق`);
  }
  if (overdueReviewUrgency >= 60) {
    topReasons.push('مراجعة استرجاع متباعد مستحقة لمنع تلاشي الذاكرة');
  }
  if (strategicImportance >= 70) {
    topReasons.push(`مرتبط بهدف استراتيجي نشط ذي أولوية عالية (${goal?.title || skill?.nameAr || ''})`);
  }
  if (weaknessAndBenefit >= 65) {
    topReasons.push('يسد فجوة كفاءة حالية ويحقق عائداً مباشراً في الإتقان');
  }
  if (candidate.category === 'Recovery') {
    topReasons.push('ضروري للاستشفاء البدني والذهني وحماية الاستمرارية طويلة المدى');
  }
  if (topReasons.length === 0) {
    topReasons.push('يدعم التقدم التراكمي المتوازن في مسار التعلم الحالي');
  }

  const consequenceIfSkipped =
    criticalErrorUrgency >= 75
      ? 'سيظل الخطأ المفتوح يمنع إتقان المهارة واجتياز البوابة'
      : prerequisiteBlocking >= 35
      ? `ستبقى ${totalDependents} مهارات/أهداف تالية مقفلة (LOCKED)`
      : overdueReviewUrgency >= 60
      ? 'يرتفع خطر نسيان المفهوم والحاجة لإعادة تعلمه من البداية'
      : 'تأخر جزئي في جدول المسار ويتم ترحيل المهمة تلقائياً لليوم التالي';

  return {
    priorityScore,
    priorityRank,
    factors,
    weightsUsed: weights,
    explanation: topReasons.join(' + '),
    consequenceIfSkipped,
  };
}

/**
 * 3. PURE AVAILABLE TIME & BUFFER CALCULATION
 */
export function calculateAvailableTimeAndBuffers(
  scheduleConfig,
  dateStr,
  energyLevel = 7,
  customFixedBlocks = []
) {
  const dayName = getDayNameFromDateString(dateStr);
  const isCollegeDay = (scheduleConfig.collegeDays || []).includes(dayName);

  const startH = parseTimeHHMM(scheduleConfig.collegeStart || '06:00');
  const endH = parseTimeHHMM(scheduleConfig.collegeEnd || '18:00');
  const rawCollegeHours = endH >= startH ? endH - startH : 24 - startH + endH;
  const collegeHours = isCollegeDay ? Number(rawCollegeHours.toFixed(2)) : 0;

  const sleepHours = Number(scheduleConfig.sleepHours ?? 7.5);
  const mealsAndPrayerHours = Number(scheduleConfig.mealsAndPrayerHours ?? 1.5);
  const otherCommitmentsHours = Number(scheduleConfig.otherCommitmentsHours ?? 1.0);

  const extraFixedMin = (customFixedBlocks || [])
    .filter((b) => b.isFixed && b.blockType === 'fixed_commitment')
    .reduce((sum, b) => {
      const dur = Math.max(0, timeStringToMinutes(b.endTime) - timeStringToMinutes(b.startTime));
      return sum + dur;
    }, 0);

  const totalCommittedHours = Number(
    (
      collegeHours +
      sleepHours +
      mealsAndPrayerHours +
      otherCommitmentsHours +
      extraFixedMin / 60
    ).toFixed(2)
  );

  const rawFreeHours = Number(Math.max(0, 24 - totalCommittedHours).toFixed(2));
  const rawFreeMin = Math.round(rawFreeHours * 60);

  const bufferRatio = Number(scheduleConfig.bufferRatio ?? 0.2);
  const bufferMin = Math.max(15, Math.round(rawFreeMin * bufferRatio));
  const unbufferedFreeMin = Math.max(0, rawFreeMin - bufferMin);

  const configuredMaxMin = isCollegeDay
    ? Number(scheduleConfig.maxCollegeDayWorkloadMin ?? 110)
    : Number(scheduleConfig.maxDailyWorkloadMin ?? 360);

  const energyScale = Math.max(0.5, Math.min(1.1, 0.55 + (Number(energyLevel) / 10) * 0.5));
  const energyAdjustedCeilingMin = Math.round(configuredMaxMin * energyScale);

  const schedulableWorkMin = Math.max(
    0,
    Math.min(unbufferedFreeMin, configuredMaxMin, energyAdjustedCeilingMin)
  );

  return {
    date: dateStr,
    dayName,
    isCollegeDay,
    collegeWindow: isCollegeDay
      ? `${scheduleConfig.collegeStart}–${scheduleConfig.collegeEnd}`
      : 'يوم حر (بدون كلية)',
    collegeHours,
    sleepHours,
    mealsAndPrayerHours,
    otherCommitmentsHours,
    extraFixedMin,
    totalCommittedHours,
    netFreeHours: rawFreeHours,
    rawFreeMin,
    bufferRatio,
    bufferMin,
    configuredMaxMin,
    energyLevel: Number(energyLevel),
    schedulableWorkMin,
    recommendedDeepWorkHours: Number((schedulableWorkMin / 60).toFixed(2)),
    recommendedTotalMissionMin: schedulableWorkMin,
  };
}

/**
 * 4. PURE TIME-BLOCK CONFLICT DETECTION
 */
export function detectTimeBlockConflicts(blocks = []) {
  const conflicts = [];
  const sorted = [...blocks].sort(
    (a, b) => timeStringToMinutes(a.startTime) - timeStringToMinutes(b.startTime)
  );

  for (let i = 0; i < sorted.length; i++) {
    const a = sorted[i];
    const aStart = timeStringToMinutes(a.startTime);
    const aEnd = timeStringToMinutes(a.endTime);
    if (aEnd <= aStart) continue;

    for (let j = i + 1; j < sorted.length; j++) {
      const b = sorted[j];
      if (a.date && b.date && a.date !== b.date) continue;
      const bStart = timeStringToMinutes(b.startTime);
      const bEnd = timeStringToMinutes(b.endTime);
      if (bEnd <= bStart) continue;

      if (aStart < bEnd && bStart < aEnd) {
        conflicts.push({
          blockAId: a.id,
          blockATitle: a.title,
          blockBId: b.id,
          blockBTitle: b.title,
          overlapWindow: `${minutesToTimeString(Math.max(aStart, bStart))}–${minutesToTimeString(
            Math.min(aEnd, bEnd)
          )}`,
          reason: `تعارض زمني بين "${a.title}" (${a.startTime}–${a.endTime}) و"${b.title}" (${b.startTime}–${b.endTime})`,
        });
      }
    }
  }

  return {
    hasConflicts: conflicts.length > 0,
    conflicts,
  };
}

/**
 * 5. PURE TASK SELECTION & DEFERRAL ENGINE
 */
export function selectAndDeferTasks(scoredEligibleCandidates = [], timeBudget) {
  const maxWorkMin = Number(timeBudget.schedulableWorkMin ?? 120);
  const maxReviewMin = Math.max(25, Math.round(maxWorkMin * 0.4));

  const seenKeys = new Set();
  const uniqueCandidates = [];
  for (const cand of scoredEligibleCandidates) {
    const dedupKey = cand.id || `${cand.skillId}_${cand.category}_${cand.title}`;
    if (seenKeys.has(dedupKey)) continue;
    seenKeys.add(dedupKey);
    uniqueCandidates.push(cand);
  }

  const sorted = [...uniqueCandidates].sort((a, b) => b.priorityScore - a.priorityScore);

  const selectedTasks = [];
  const deferredTasks = [];
  let usedMin = 0;
  let usedReviewMin = 0;

  const hasFoundationalWork = sorted.some((c) =>
    ['Primary', 'Remediation', 'Practice', 'Tests'].includes(c.category)
  );

  for (let idx = 0; idx < sorted.length; idx++) {
    const task = sorted[idx];
    const dur = Number(task.plannedDurationMin || 30);
    const isReviewType = task.category === 'Reviews' || task.isOverdueReview;

    if (
      isReviewType &&
      hasFoundationalWork &&
      usedReviewMin > 0 &&
      usedReviewMin + dur > maxReviewMin
    ) {
      deferredTasks.push({
        ...task,
        status: 'deferred',
        executionState: 'deferred',
        deferralReason: `تم تأجيل المراجعة الإضافية لمنع استهلاك كامل وقت اليوم في المراجعات على حساب العمل التأسيسي (الحد الأقصى للمراجعات اليوم: ${maxReviewMin} د)`,
        limitingConstraint: 'REVIEW_CROWDING_CAP',
      });
      continue;
    }

    if (usedMin + dur > maxWorkMin) {
      deferredTasks.push({
        ...task,
        status: 'deferred',
        executionState: 'deferred',
        deferralReason: `تجاوز الميزانية الزمنية الآمنة لليوم (${usedMin + dur} د > المتاح ${maxWorkMin} د مع الحفاظ على ${timeBudget.bufferMin} د وقت احتياطي Buffer)`,
        limitingConstraint: timeBudget.isCollegeDay ? 'COLLEGE_DAY_TIME_BUDGET' : 'DAILY_SAFE_WORKLOAD_LIMIT',
      });
      continue;
    }

    const nextAlternative = sorted[idx + 1];
    const whyOverAlt = nextAlternative
      ? `تم اختيارها قبل "${nextAlternative.title}" لأن درجة أولويتها (${task.priorityScore}) أعلى من (${nextAlternative.priorityScore})`
      : 'المهمة الأعلى ملاءمة ضمن الوقت المتبقي المتاح اليوم';

    selectedTasks.push({
      ...task,
      priority: Math.min(5, selectedTasks.length + 1),
      whySelectedOverAlternatives: whyOverAlt,
    });

    usedMin += dur;
    if (isReviewType) usedReviewMin += dur;
  }

  return {
    selectedTasks,
    deferredTasks,
    plannedWorkloadMin: usedMin,
    remainingAvailableMin: Math.max(0, maxWorkMin - usedMin),
    bufferPreservedMin: timeBudget.bufferMin,
  };
}

/**
 * 6. PURE WORKLOAD & RECOVERY PROTECTION VALIDATOR
 */
export function validateWorkloadAndRecovery(plannedTasks = [], timeBudget, scheduleConfig = {}) {
  const warnings = [];
  const totalPlannedMin = plannedTasks
    .filter((t) => t.status !== 'skipped' && t.status !== 'deferred' && t.status !== 'cancelled')
    .reduce((sum, t) => sum + Number(t.plannedDurationMin || 0), 0);

  const safeCeilingMin = Number(timeBudget.schedulableWorkMin ?? 180);
  const sleepHours = Number(timeBudget.sleepHours ?? scheduleConfig.sleepHours ?? 7.5);
  const hasRecoveryTask = plannedTasks.some(
    (t) => t.category === 'Recovery' && t.status !== 'skipped'
  );

  const isOverloaded = totalPlannedMin > safeCeilingMin;
  if (isOverloaded) {
    warnings.push(
      `تحذير حمل زائد (Overload): المهام المخططة (${totalPlannedMin} د) تتجاوز السقف الآمن لليوم (${safeCeilingMin} د). يُنصح بتأجيل المهام الثانوية وليس تقليص النوم.`
    );
  }

  if (sleepHours < 6.5) {
    warnings.push(
      `حماية النوم والاستشفاء: ساعات النوم المحددة (${sleepHours} س) أقل من الحد الصحي الآمن (6.5 س). النظام يرفض التوصية بالسهر لتعويض المهام.`
    );
  }

  if (!hasRecoveryTask && totalPlannedMin >= 90) {
    warnings.push(
      'تنبيه التوازن: لا توجد فترة استشفاء أو حركة بدنية (Recovery) ضمن الجدول الحالي.'
    );
  }

  return {
    isOverloaded,
    totalPlannedMin,
    safeCeilingMin,
    utilizationPct:
      safeCeilingMin > 0 ? Math.min(150, Math.round((totalPlannedMin / safeCeilingMin) * 100)) : 0,
    sleepProtected: sleepHours >= 6.5,
    hasRecoveryTask,
    warnings,
  };
}

/**
 * 7. PURE ROOT-CAUSE DIAGNOSIS & ADAPTIVE RESCHEDULING
 */
export function diagnoseTaskIssueAndRecommendAdjustment(task, outcomePayload = {}, timeBudget = {}) {
  const skipCount = Number(task.skipCount || 0) + (outcomePayload.eventType === 'SKIPPED' ? 1 : 0);
  const plannedMin = Number(task.plannedDurationMin ?? 45);
  const energyReported = Number(outcomePayload.energy ?? timeBudget.energyLevel ?? 6);
  const difficultyReported = Number(outcomePayload.difficulty ?? task.difficulty ?? 6);
  const skipReason = String(outcomePayload.skipReason || '').toLowerCase();

  const causes = [];
  const tomorrowAdjustments = [];
  let recommendedNextDurationMin = plannedMin;
  let recommendedDifficulty = Number(task.difficulty || 5);

  if (plannedMin > 60 || skipReason.includes('طويل') || skipReason.includes('وقت') || skipReason.includes('duration')) {
    causes.push('DURATION_TOO_LONG: مدة المهمة طويلة جداً بالنسبة للنافذة الزمنية المتاحة');
    recommendedNextDurationMin = Math.max(20, Math.round(plannedMin * 0.6));
    tomorrowAdjustments.push(
      `تقسيم المهمة غداً إلى جلسة أقصر (${recommendedNextDurationMin} دقيقة بدلاً من ${plannedMin} دقيقة) دون مضاعفة الحمل`
    );
  }

  if (difficultyReported >= 8 || skipReason.includes('صعب') || skipReason.includes('difficult')) {
    causes.push('DIFFICULTY_SPIKE: صعوبة المهمة تتجاوز الجاهزية الحالية أو تتطلب خطوة تمهيدية');
    recommendedDifficulty = Math.max(2, recommendedDifficulty - 2);
    tomorrowAdjustments.push(
      'تخفيض حجم الخطوة التدريبية (Step-down Granularity) والبدء بمراجعة المفهوم الأساسي أولاً'
    );
  }

  if (energyReported <= 4 || timeBudget.isCollegeDay) {
    causes.push('TIMING_OR_ENERGY_MISMATCH: تعارض توقيت المهمة مع إرهاق يوم الكلية أو انخفاض الطاقة');
    tomorrowAdjustments.push(
      'نقل المهمة إلى أول فترة تركيز صباحية في يوم حر بدلاً من نهاية يوم مزدحم'
    );
  }

  if (skipCount >= 2) {
    causes.push(`REPEATED_MISS (${skipCount}x): تكرر تخطي هذه المهمة مما يشير إلى عائق هيكلي في التصميم أو الحمل اليومي`);
    recommendedNextDurationMin = Math.min(recommendedNextDurationMin, 25);
    tomorrowAdjustments.push(
      'تحويل المهمة إلى جلسة بداية سريعة (Micro-Session 25 د) لكسر حاجز البدء دون عقوبة أو تكديس'
    );
  }

  if (causes.length === 0) {
    causes.push('TEMPORARY_INTERRUPTION: ظرف طارئ أو انقطاع مؤقت خلال اليوم');
    tomorrowAdjustments.push(
      'إعادة جدولة الجزء المتبقي بهدوء ضمن الميزانية الطبيعية لليوم القادم دون تجاوز السقف الآمن'
    );
  }

  const completionPct = Number(outcomePayload.completionPct ?? 0);
  if (completionPct > 0 && completionPct < 100) {
    const remainingRatio = (100 - completionPct) / 100;
    recommendedNextDurationMin = Math.max(15, Math.round(plannedMin * remainingRatio));
  }

  return {
    taskId: task.id,
    skipCount,
    diagnosedCauses: causes,
    recommendedNextDurationMin,
    recommendedDifficulty,
    tomorrowAdjustments,
    summaryText: `${causes[0]} → ${tomorrowAdjustments[0]}`,
  };
}
